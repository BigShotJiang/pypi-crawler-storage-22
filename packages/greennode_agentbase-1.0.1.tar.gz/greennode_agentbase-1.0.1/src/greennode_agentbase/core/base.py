"""Base API client with dynamic method generation."""

import logging
from typing import Any, Dict, Optional

from ..exceptions import GreenNodeConfigurationError
from .http_client import HTTPClientProtocol
from .loader import load_spec
from .method_generator import generate_method

logger = logging.getLogger("greennode_agentbase.core")


class BaseAPIClient:
    """Base class for data-driven API clients.

    This class provides dynamic method generation based on API specifications
    stored in compressed JSON files. Subclasses should set SERVICE_NAME and
    optionally override DEFAULT_BASE_URL.

    Args:
        service_name: Name of the service (must match spec directory name)
        base_url: Base URL for the API (defaults to spec's base_url)
        http_client: Optional HTTP client implementation
        ensure_authenticated: Optional async callable to ensure authentication before requests
    """

    SERVICE_NAME: Optional[str] = None
    DEFAULT_BASE_URL: Optional[str] = None

    def __init__(
        self,
        service_name: Optional[str] = None,
        base_url: Optional[str] = None,
        http_client: Optional[HTTPClientProtocol] = None,
        ensure_authenticated: Optional[Any] = None,
    ) -> None:
        """Initialize the base API client."""
        self._service_name = service_name or self.SERVICE_NAME
        if not self._service_name:
            raise GreenNodeConfigurationError(
                "SERVICE_NAME must be set on class or passed as service_name parameter"
            )

        # Load spec to get default base_url if not provided
        try:
            spec = load_spec(self._service_name)
            self._spec = spec
            self._base_url = base_url or spec.get("base_url") or self.DEFAULT_BASE_URL
            if not self._base_url:
                raise GreenNodeConfigurationError(
                    f"No base_url specified for service '{self._service_name}'"
                )
        except Exception as e:
            raise GreenNodeConfigurationError(
                f"Failed to load API specification for service '{self._service_name}': {e}"
            ) from e

        self._http_client = http_client
        self._ensure_authenticated = ensure_authenticated
        self._generated_methods: Dict[str, Any] = {}

    def __getattr__(self, name: str) -> Any:
        """Dynamically generate methods based on API specification.

        Args:
            name: Method name to generate

        Returns:
            Generated method

        Raises:
            AttributeError: If the operation is not found in the spec
        """
        # Check if we've already generated this method
        if name in self._generated_methods:
            return self._generated_methods[name]

        # Check if operation exists in spec
        operations = self._spec.get("operations", {})
        if name not in operations:
            raise AttributeError(
                f"'{self.__class__.__name__}' has no attribute '{name}'. "
                f"Available operations: {list(operations.keys())[:10]}..."
            )

        # Generate the method
        operation_spec = operations[name]
        try:
            method = generate_method(
                operation_name=name,
                operation_spec=operation_spec,
                http_client=self._http_client,
                base_url=self._base_url,
                ensure_authenticated=self._ensure_authenticated,
            )
            # Cache the generated method
            self._generated_methods[name] = method
            return method
        except Exception as e:
            raise AttributeError(
                f"Failed to generate method '{name}': {e}"
            ) from e

