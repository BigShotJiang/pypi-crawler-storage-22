"""HTTP client implementations for GreenNode AgentBase SDK.

Provides abstract HTTP client protocol and concrete httpx-based implementation
for use across all service clients.
"""

import json
from typing import Any, Dict, Optional

from typing_extensions import Protocol

try:
    import httpx
except ImportError:
    httpx = None  # type: ignore

from ..exceptions import GreenNodeConfigurationError, GreenNodeRequestError


class HTTPClientProtocol(Protocol):
    """Protocol for HTTP client implementations.

    This abstract interface allows for different HTTP client implementations
    and easy mocking in tests.
    """

    async def get(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Perform an HTTP GET request.

        Args:
            url: The URL to request
            headers: Optional request headers
            params: Optional query parameters

        Returns:
            Response data as a dictionary

        Raises:
            GreenNodeRequestError: If the request fails
        """
        ...

    async def post(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        json: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Perform an HTTP POST request.

        Args:
            url: The URL to request
            headers: Optional request headers
            json: Optional JSON body
            data: Optional form data body

        Returns:
            Response data as a dictionary

        Raises:
            GreenNodeRequestError: If the request fails
        """
        ...

    async def put(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        json: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Perform an HTTP PUT request.

        Args:
            url: The URL to request
            headers: Optional request headers
            json: Optional JSON body

        Returns:
            Response data as a dictionary

        Raises:
            GreenNodeRequestError: If the request fails
        """
        ...

    async def delete(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Perform an HTTP DELETE request.

        Args:
            url: The URL to request
            headers: Optional request headers

        Returns:
            Response data as a dictionary

        Raises:
            GreenNodeRequestError: If the request fails
        """
        ...


class HttpxClient:
    """HTTP client implementation using httpx library.

    This is the default HTTP client implementation for all service clients.
    It uses httpx for async HTTP requests with OAuth2 authentication support.

    Args:
        base_url: Base URL for the API
        access_token: Optional OAuth2 access token for authentication
        timeout: Request timeout in seconds (default: 30.0)

    Example:
        >>> client = HttpxClient("https://api.example.com")
        >>> response = await client.get("/api/v1/resource")
    """

    def __init__(
        self,
        base_url: str,
        access_token: Optional[str] = None,
        timeout: float = 30.0,
    ) -> None:
        """Initialize the httpx client."""
        if httpx is None:
            raise GreenNodeConfigurationError(
                "httpx is required but not installed. Please install it with: pip install httpx"
            )

        self.base_url = base_url.rstrip("/")
        self.access_token = access_token
        self.timeout = timeout
        self._client: Optional[httpx.AsyncClient] = None

    async def update_access_token(self, access_token: Optional[str]) -> None:
        """Update the access token and recreate the client if needed.

        Args:
            access_token: New access token to use for authentication
        """
        if self.access_token != access_token:
            self.access_token = access_token
            # Close existing client so it will be recreated with new token
            if self._client is not None:
                await self._client.aclose()
                self._client = None

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create the httpx async client."""
        if self._client is None:
            headers: Dict[str, str] = {}
            if self.access_token:
                headers["Authorization"] = f"Bearer {self.access_token}"

            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                headers=headers,
                timeout=self.timeout,
            )
        return self._client

    async def _handle_response(self, response: httpx.Response) -> Dict[str, Any]:
        """Handle HTTP response and convert to dictionary."""
        try:
            response.raise_for_status()
            # APIs may return only status (e.g. 204 No Content or 200 with empty body)
            if response.status_code == 204 or not response.content or response.content.strip() == b"":
                return {}
            try:
                return response.json()
            except (json.JSONDecodeError, ValueError):
                return {}
        except httpx.HTTPStatusError as e:
            status_code = e.response.status_code
            try:
                error_data = e.response.json()
                error_msg = error_data.get("message", e.response.text)
            except Exception:
                error_msg = e.response.text or str(e)

            raise GreenNodeRequestError(
                f"HTTP {status_code} error: {error_msg}",
                status_code=status_code,
                cause=e,
            ) from e
        except httpx.RequestError as e:
            raise GreenNodeRequestError(
                f"Request failed: {str(e)}",
                cause=e,
            ) from e

    async def get(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Perform an HTTP GET request."""
        client = await self._get_client()
        request_headers = dict(client.headers) if client.headers else {}
        if headers:
            request_headers.update(headers)

        try:
            response = await client.get(url, headers=request_headers, params=params)
            return await self._handle_response(response)
        except GreenNodeRequestError:
            raise
        except Exception as e:
            raise GreenNodeRequestError(f"GET request failed: {str(e)}", cause=e) from e

    async def post(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        json: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Perform an HTTP POST request."""
        client = await self._get_client()
        request_headers = dict(client.headers) if client.headers else {}
        if headers:
            request_headers.update(headers)

        try:
            if json is not None:
                response = await client.post(url, headers=request_headers, json=json)
            elif data is not None:
                response = await client.post(url, headers=request_headers, data=data)
            else:
                response = await client.post(url, headers=request_headers)
            return await self._handle_response(response)
        except GreenNodeRequestError:
            raise
        except Exception as e:
            raise GreenNodeRequestError(f"POST request failed: {str(e)}", cause=e) from e

    async def put(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        json: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Perform an HTTP PUT request."""
        client = await self._get_client()
        request_headers = dict(client.headers) if client.headers else {}
        if headers:
            request_headers.update(headers)

        try:
            response = await client.put(url, headers=request_headers, json=json)
            return await self._handle_response(response)
        except GreenNodeRequestError:
            raise
        except Exception as e:
            raise GreenNodeRequestError(f"PUT request failed: {str(e)}", cause=e) from e

    async def delete(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Perform an HTTP DELETE request."""
        client = await self._get_client()
        request_headers = dict(client.headers) if client.headers else {}
        if headers:
            request_headers.update(headers)

        try:
            response = await client.delete(url, headers=request_headers)
            return await self._handle_response(response)
        except GreenNodeRequestError:
            raise
        except Exception as e:
            raise GreenNodeRequestError(f"DELETE request failed: {str(e)}", cause=e) from e

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self) -> "HttpxClient":
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Async context manager exit."""
        await self.close()
