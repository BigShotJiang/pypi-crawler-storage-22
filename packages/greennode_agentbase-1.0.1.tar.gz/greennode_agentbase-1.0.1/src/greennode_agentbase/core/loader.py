"""Spec loading and caching for API clients."""

import gzip
import json
import logging
from importlib import resources
from typing import Any, Dict, Optional

from .logging import configure_logger

logger = logging.getLogger("greennode_agentbase.core")
configure_logger(logger)

# Global cache for loaded specs
_spec_cache: Dict[str, Dict[str, Any]] = {}


def load_spec(service_name: str) -> Dict[str, Any]:
    """Load and decompress API specification for a service.

    Args:
        service_name: Name of the service (e.g., "identity")

    Returns:
        Decompressed and parsed API specification dictionary

    Raises:
        FileNotFoundError: If the spec file cannot be found
        ValueError: If the spec file is invalid JSON
    """
    # Check cache first
    if service_name in _spec_cache:
        return _spec_cache[service_name]

    # Try to load from package resources first
    try:
        spec_path = f"specs.{service_name}.api.json.gz"
        with resources.files("greennode_agentbase").joinpath(
            f"specs/{service_name}/api.json.gz"
        ).open("rb") as f:
            compressed_data = f.read()
    except (FileNotFoundError, ModuleNotFoundError, ValueError):
        # Fallback to file system (for development)
        import os

        current_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
        spec_path = os.path.join(current_dir, "specs", service_name, "api.json.gz")
        if not os.path.exists(spec_path):
            raise FileNotFoundError(
                f"API specification not found for service '{service_name}'. "
                f"Expected at: {spec_path}"
            )
        with open(spec_path, "rb") as f:
            compressed_data = f.read()

    # Decompress and parse
    try:
        decompressed_data = gzip.decompress(compressed_data)
        spec = json.loads(decompressed_data.decode("utf-8"))
    except (gzip.BadGzipFile, json.JSONDecodeError) as e:
        raise ValueError(f"Invalid API specification format: {e}") from e

    # Cache the spec
    _spec_cache[service_name] = spec
    logger.debug(f"Loaded API specification for service '{service_name}'")
    return spec


def clear_cache(service_name: Optional[str] = None) -> None:
    """Clear the spec cache.

    Args:
        service_name: Optional service name to clear. If None, clears all caches.
    """
    if service_name:
        _spec_cache.pop(service_name, None)
    else:
        _spec_cache.clear()

