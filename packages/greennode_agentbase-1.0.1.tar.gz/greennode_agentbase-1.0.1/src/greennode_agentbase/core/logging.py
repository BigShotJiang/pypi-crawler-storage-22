"""Centralized logging configuration for GreenNode AgentBase SDK.

Provides GreenNode Base-style rich colored logging formatter and logger configuration utilities.
"""

import logging
import os
import traceback
from contextvars import ContextVar
from datetime import datetime, timezone
from typing import Any, Dict, Optional

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.text import Text
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False

from ..runtime.context import GreenNodeAgentBaseContext

# Global debug mode context variable
_debug_mode: ContextVar[Optional[bool]] = ContextVar("debug_mode", default=None)


def _is_debug_mode() -> bool:
    """Check if debug mode is enabled.

    Checks environment variable GREENNODE_DEBUG first, then context variable.

    Returns:
        True if debug mode is enabled, False otherwise
    """
    # Check environment variable
    env_debug = os.getenv("GREENNODE_DEBUG", "").lower()
    if env_debug in ("1", "true", "yes"):
        return True

    # Check context variable
    try:
        ctx_debug = _debug_mode.get()
        if ctx_debug is not None:
            return ctx_debug
    except LookupError:
        pass

    return False


def set_debug_mode(enabled: bool) -> None:
    """Set debug mode in context.

    Args:
        enabled: Whether to enable debug mode
    """
    _debug_mode.set(enabled)


class GreenNodeBaseLogFormatter(logging.Formatter):
    """GreenNode Base-style rich colored log formatter.

    Formats log records with rich colors and styling for better developer experience.
    Includes request and session context when available. Shows error details in formatted panels.

    Example:
        >>> formatter = GreenNodeBaseLogFormatter()
        >>> handler = logging.StreamHandler()
        >>> handler.setFormatter(formatter)
        >>> logger.addHandler(handler)
    """

    # Color scheme for different log levels
    LEVEL_COLORS: Dict[str, str] = {
        "DEBUG": "dim white",
        "INFO": "blue",
        "WARNING": "yellow",
        "ERROR": "red",
        "CRITICAL": "bold red",
    }

    def __init__(self) -> None:
        """Initialize the formatter with a rich Console."""
        super().__init__()
        if RICH_AVAILABLE:
            self.console = Console()
        else:
            self.console = None

    def _get_level_color(self, levelname: str) -> str:
        """Get color for log level.

        Args:
            levelname: Log level name (DEBUG, INFO, WARNING, ERROR, CRITICAL)

        Returns:
            Color string for the level
        """
        return self.LEVEL_COLORS.get(levelname, "white")

    def format(self, record: logging.LogRecord) -> str:
        """Format log record with rich colors and styling.

        Args:
            record: The log record to format

        Returns:
            Formatted log entry string with ANSI color codes
        """
        # Convert timestamp from record.created (seconds since epoch) to human-readable format
        dt = datetime.fromtimestamp(record.created, tz=timezone.utc)
        timestamp = dt.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

        # Get log level color
        level_color = self._get_level_color(record.levelname)

        # Build the main log line
        if RICH_AVAILABLE and self.console:
            # Use rich Text for colored output
            log_text = Text()
            log_text.append(f"[{timestamp}] ", style="dim")
            log_text.append(f"{record.levelname:8s} ", style=level_color)
            log_text.append(f"{record.name} ", style="cyan")
            log_text.append(record.getMessage(), style="white")

            # Add request context if available
            request_id = GreenNodeAgentBaseContext.get_request_id()
            session_id = GreenNodeAgentBaseContext.get_session_id()

            context_parts = []
            if request_id:
                context_parts.append(f"requestId={request_id}")
            if session_id:
                context_parts.append(f"sessionId={session_id}")

            if context_parts:
                log_text.append(" | ", style="dim")
                log_text.append(" ".join(context_parts), style="dim cyan")

            # For ERROR level and above, add location
            if record.levelno >= logging.ERROR:
                location = f"{record.pathname}:{record.funcName}:{record.lineno}"
                log_text.append("\n", style="dim")
                log_text.append(f"  Location: {location}", style="dim")

            # Build complete output with error panel if needed
            output_parts = [log_text]

            # Add error details panel for ERROR+ logs with exception info
            if record.levelno >= logging.ERROR and record.exc_info:
                error_type = record.exc_info[0].__name__
                error_message = str(record.exc_info[1])

                # Create error details panel
                error_content = f"[bold red]{error_type}[/bold red]: {error_message}\n\n"
                error_content += "[dim]Stack Trace:[/dim]\n"
                error_content += "".join(traceback.format_exception(*record.exc_info))

                error_panel = Panel(
                    error_content,
                    title="[bold red]Error Details[/bold red]",
                    border_style="red",
                    expand=False,
                )
                output_parts.append(error_panel)

            # Render all parts to string
            with self.console.capture() as capture:
                for part in output_parts:
                    self.console.print(part)

            return capture.get()
        else:
            # Fallback to plain text if rich is not available
            log_line = f"[{timestamp}] {record.levelname:8s} {record.name} {record.getMessage()}"

            # Add request context if available
            request_id = GreenNodeAgentBaseContext.get_request_id()
            session_id = GreenNodeAgentBaseContext.get_session_id()

            context_parts = []
            if request_id:
                context_parts.append(f"requestId={request_id}")
            if session_id:
                context_parts.append(f"sessionId={session_id}")

            if context_parts:
                log_line += f" | {' '.join(context_parts)}"

            # For ERROR level and above, add location and error details
            if record.levelno >= logging.ERROR:
                location = f"{record.pathname}:{record.funcName}:{record.lineno}"
                log_line += f"\n  Location: {location}"

                if record.exc_info:
                    error_type = record.exc_info[0].__name__
                    error_message = str(record.exc_info[1])
                    log_line += f"\n  Error: {error_type}: {error_message}"
                    log_line += "\n  Stack Trace:\n" + "".join(traceback.format_exception(*record.exc_info))

            return log_line


def configure_logger(logger: logging.Logger) -> None:
    """Configure a logger with GreenNode Base rich formatter and appropriate log level.

    Applies the GreenNodeBaseLogFormatter to the logger if it doesn't already have
    a handler with this formatter. Sets log level based on debug mode.

    Args:
        logger: The logger to configure

    Example:
        >>> logger = logging.getLogger("my.module")
        >>> configure_logger(logger)
    """
    # Check if logger already has a handler with GreenNodeBaseLogFormatter
    has_formatter = False
    for handler in logger.handlers:
        if isinstance(handler.formatter, GreenNodeBaseLogFormatter):
            has_formatter = True
            break

    if not has_formatter:
        handler = logging.StreamHandler()
        formatter = GreenNodeBaseLogFormatter()
        handler.setFormatter(formatter)
        logger.addHandler(handler)

    # Disable propagation to prevent duplicate logs from root logger
    logger.propagate = False

    # Set log level based on debug mode
    if _is_debug_mode():
        logger.setLevel(logging.DEBUG)
    else:
        logger.setLevel(logging.INFO)
