"""Method generation logic for dynamic API methods."""

import importlib
import inspect
import logging
from typing import Any, Callable, Dict, Optional, Tuple, Type

from ..exceptions import GreenNodeRequestError
from .logging import configure_logger


def get_model_class(module_path: str, model_name: str) -> Type[Any]:
    """Dynamically import a model class.

    Args:
        module_path: Full module path (e.g., "greennode_agentbase.identity.models")
        model_name: Name of the model class (e.g., "AgentIdentityResponse")

    Returns:
        The model class

    Raises:
        ImportError: If the module or class cannot be imported
    """
    try:
        module = importlib.import_module(module_path)
        model_class = getattr(module, model_name)
        return model_class
    except (ImportError, AttributeError) as e:
        raise ImportError(
            f"Cannot import {model_name} from {module_path}: {e}"
        ) from e


def build_url(path_template: str, path_params: Dict[str, Any]) -> str:
    """Build URL from template and path parameters.

    Args:
        path_template: URL template with placeholders (e.g., "/api/v1/agent-identities/{name}")
        path_params: Dictionary of path parameters

    Returns:
        Built URL with parameters substituted
    """
    url = path_template
    for key, value in path_params.items():
        placeholder = f"{{{key}}}"
        if placeholder not in url:
            raise ValueError(
                f"Path parameter '{key}' not found in template '{path_template}'"
            )
        url = url.replace(placeholder, str(value))
    return url


def extract_path_params(
    path_template: str, kwargs: Dict[str, Any]
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Extract path parameters from kwargs based on template.

    Args:
        path_template: URL template with placeholders
        kwargs: All keyword arguments

    Returns:
        Tuple of (path_params, remaining_kwargs)
    """
    # Find all placeholders in the template
    import re

    placeholders = re.findall(r"{(\w+)}", path_template)
    path_params = {}
    remaining = kwargs.copy()

    for placeholder in placeholders:
        if placeholder in remaining:
            path_params[placeholder] = remaining.pop(placeholder)

    return path_params, remaining


def generate_method(
    operation_name: str,
    operation_spec: Dict[str, Any],
    http_client: Any,
    base_url: str,
    ensure_authenticated: Optional[Callable[[], Any]] = None,
) -> Callable[..., Any]:
    """Generate a dynamic method for an API operation.

    Args:
        operation_name: Name of the operation (e.g., "get_agent_identity_async")
        operation_spec: Operation specification from API model
        http_client: HTTP client instance (must implement HTTPClientProtocol)
        base_url: Base URL for the API
        ensure_authenticated: Optional async callable to ensure authentication

    Returns:
        Generated method function
    """
    method = operation_spec["method"]
    path_template = operation_spec["path"]
    params_spec = operation_spec.get("params", {})
    response_model_name = operation_spec.get("response_model")
    response_module = operation_spec.get("module")
    is_array_response = operation_spec.get("is_array_response", False)
    is_async = operation_spec.get("async", False)

    # Get response model class if specified
    response_model = None
    if response_model_name and response_module:
        try:
            response_model = get_model_class(response_module, response_model_name)
        except ImportError as e:
            # Log warning but continue - will return raw dict
            logger = logging.getLogger("greennode_agentbase.core")
            configure_logger(logger)
            logger.warning(f"Could not import response model {response_model_name}: {e}")

    async def async_method(**kwargs: Any) -> Any:
        """Generated async method."""
        # Ensure authentication if needed
        if ensure_authenticated:
            await ensure_authenticated()

        # Extract path, query, and body parameters
        path_params, remaining = extract_path_params(path_template, kwargs)
        url = build_url(path_template, path_params)

        # Separate query params and body
        query_params = {}
        body_data = None
        request_body = None

        # Handle query parameters
        query_param_names = params_spec.get("query", [])
        for param_name in query_param_names:
            if param_name in remaining:
                query_params[param_name] = remaining.pop(param_name)

        # Handle header parameters
        header_params = {}
        header_param_names = params_spec.get("header", [])
        for param_name in header_param_names:
            if param_name in remaining:
                # Convert header values to strings (headers must be strings)
                value = remaining.pop(param_name)
                header_params[param_name] = str(value) if value is not None else ""

        # Handle request body
        body_spec = params_spec.get("body")
        if body_spec:
            if isinstance(body_spec, dict):
                # Check if it's an array body
                if body_spec.get("is_array"):
                    body_model_name = body_spec.get("model")
                    body_module = body_spec.get("module")
                    # Find the body parameter in kwargs
                    body_value = None
                    for key in ["request", "body", "data", *remaining.keys()]:
                        if key in remaining:
                            body_value = remaining.pop(key)
                            break
                    
                    if body_value is None:
                        raise ValueError(f"Missing required body parameter for {operation_name}")
                    
                    # If it's an array of models, convert each item
                    if body_model_name and body_module and isinstance(body_value, list):
                        body_model_class = get_model_class(body_module, body_model_name)
                        request_body = [
                            item.model_dump(by_alias=True) if isinstance(item, body_model_class)
                            else body_model_class(**item).model_dump(by_alias=True) if isinstance(item, dict)
                            else item
                            for item in body_value
                        ]
                    else:
                        # Simple array (e.g., list of strings)
                        request_body = body_value
                else:
                    # Body is a model
                    body_model_name = body_spec.get("model")
                    body_module = body_spec.get("module")
                    if body_model_name and body_module:
                        body_model_class = get_model_class(body_module, body_model_name)
                        # Find the body parameter in kwargs
                        # Usually it's named "request" or matches the model name (lowercase)
                        body_value = None
                        for key in ["request", body_model_name.lower(), *remaining.keys()]:
                            if key in remaining:
                                body_value = remaining.pop(key)
                                break

                        if body_value is None:
                            # Try to construct from remaining kwargs
                            try:
                                body_value = body_model_class(**remaining)
                            except Exception:
                                raise ValueError(
                                    f"Missing required body parameter for {operation_name}"
                                )
                        elif not isinstance(body_value, body_model_class):
                            # Convert dict to model
                            body_value = body_model_class(**body_value)

                        request_body = body_value.model_dump(by_alias=True)
            else:
                # Body is a simple value
                for key in list(remaining.keys()):
                    request_body = remaining.pop(key)
                    break

        # Make HTTP request
        try:
            request_headers = header_params if header_params else None
            if method == "GET":
                response_data = await http_client.get(
                    url, params=query_params if query_params else None, headers=request_headers
                )
            elif method == "POST":
                if request_body is not None:
                    response_data = await http_client.post(url, json=request_body, headers=request_headers)
                else:
                    response_data = await http_client.post(url, headers=request_headers)
            elif method == "PUT":
                if request_body is not None:
                    response_data = await http_client.put(url, json=request_body, headers=request_headers)
                else:
                    response_data = await http_client.put(url, headers=request_headers)
            elif method == "DELETE":
                response_data = await http_client.delete(url, headers=request_headers)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")

            # Convert response to model if specified
            if response_model:
                if is_array_response and isinstance(response_data, list):
                    # Handle array responses
                    return [response_model(**item) if isinstance(item, dict) else item for item in response_data]
                elif isinstance(response_data, dict):
                    return response_model(**response_data)
            return response_data

        except Exception as e:
            if isinstance(e, GreenNodeRequestError):
                raise
            raise GreenNodeRequestError(
                f"Request failed for {operation_name}: {str(e)}", cause=e
            ) from e

    def sync_method(**kwargs: Any) -> Any:
        """Generated sync method."""
        import asyncio

        return asyncio.run(async_method(**kwargs))

    # Return appropriate method based on async flag
    if is_async:
        return async_method
    return sync_method

