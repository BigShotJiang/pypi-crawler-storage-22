"""Unified error handling for GreenNode AgentBase SDK.

All SDK-specific errors inherit from GreenNodeAgentBaseError to provide
consistent error handling across the SDK.
"""

from typing import Any, Dict, Optional


class GreenNodeAgentBaseError(Exception):
    """Base exception class for all GreenNode AgentBase SDK errors.

    All SDK-specific exceptions should inherit from this class to ensure
    consistent error handling. External library exceptions should be wrapped
    in appropriate SDK exception types.

    Args:
        message: Error message describing what went wrong
        details: Optional additional details about the error
        cause: Optional underlying exception that caused this error

    Example:
        >>> raise GreenNodeAgentBaseError("Operation failed", details={"key": "value"})
        Traceback (most recent call last):
        ...
        GreenNodeAgentBaseError: Operation failed
    """

    def __init__(
        self,
        message: str,
        details: Optional[Dict[str, Any]] = None,
        cause: Optional[Exception] = None,
    ) -> None:
        """Initialize the error with message, optional details, and cause."""
        super().__init__(message)
        self.message = message
        self.details = details or {}
        self.cause = cause

    def __str__(self) -> str:
        """Return string representation of the error."""
        if self.details:
            return f"{self.message} (Details: {self.details})"
        return self.message

    def __repr__(self) -> str:
        """Return detailed representation of the error."""
        parts = [f"message={self.message!r}"]
        if self.details:
            parts.append(f"details={self.details!r}")
        if self.cause:
            parts.append(f"cause={type(self.cause).__name__}")
        return f"{self.__class__.__name__}({', '.join(parts)})"


class GreenNodeValidationError(GreenNodeAgentBaseError):
    """Exception raised for validation errors.

    This exception is raised when input validation fails, such as invalid
    parameter values, missing required fields, or type mismatches.

    Args:
        message: Error message describing the validation failure
        details: Optional additional details about the validation error
        cause: Optional underlying exception that caused this error

    Example:
        >>> raise GreenNodeValidationError("Invalid parameter value", details={"param": "value"})
        Traceback (most recent call last):
        ...
        GreenNodeValidationError: Invalid parameter value
    """

    pass


class GreenNodeRuntimeError(GreenNodeAgentBaseError):
    """Exception raised for runtime errors.

    This exception is raised when an error occurs during execution that is
    not related to validation or configuration, such as resource unavailability
    or unexpected runtime conditions.

    Args:
        message: Error message describing the runtime error
        details: Optional additional details about the runtime error
        cause: Optional underlying exception that caused this error

    Example:
        >>> raise GreenNodeRuntimeError("Resource unavailable", details={"resource": "database"})
        Traceback (most recent call last):
        ...
        GreenNodeRuntimeError: Resource unavailable
    """

    pass


class GreenNodeConfigurationError(GreenNodeAgentBaseError):
    """Exception raised for configuration errors.

    This exception is raised when there are issues with SDK configuration,
    such as missing required configuration values or invalid configuration
    settings.

    Args:
        message: Error message describing the configuration error
        details: Optional additional details about the configuration error
        cause: Optional underlying exception that caused this error

    Example:
        >>> raise GreenNodeConfigurationError("Missing required config", details={"key": "api_key"})
        Traceback (most recent call last):
        ...
        GreenNodeConfigurationError: Missing required config
    """

    pass


class GreenNodeRequestError(GreenNodeAgentBaseError):
    """Exception raised for HTTP request errors.

    This exception is raised when HTTP requests fail, such as network errors,
    timeout errors, or HTTP error status codes. External HTTP library
    exceptions should be wrapped in this exception type.

    Args:
        message: Error message describing the request error
        status_code: Optional HTTP status code if available
        details: Optional additional details about the request error
        cause: Optional underlying exception that caused this error

    Example:
        >>> raise GreenNodeRequestError("Request failed", status_code=500)
        Traceback (most recent call last):
        ...
        GreenNodeRequestError: Request failed
    """

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        details: Optional[Dict[str, Any]] = None,
        cause: Optional[Exception] = None,
    ) -> None:
        """Initialize the request error with optional status code."""
        super().__init__(message, details=details, cause=cause)
        self.status_code = status_code
        if status_code is not None:
            self.details = self.details or {}
            self.details["status_code"] = status_code

