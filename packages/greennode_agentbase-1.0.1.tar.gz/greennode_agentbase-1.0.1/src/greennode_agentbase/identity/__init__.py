"""GreenNode AgentBase Identity SDK - Public API.

This module provides authentication, authorization, and credential management
for agent-based systems.
"""

from .auth import requires_access_token, requires_api_key, TokenPoller
from .client import IdentityClient
from .credentials import IAMCredentials
from ..core.http_client import HttpxClient, HTTPClientProtocol
from .models import (
    AgentIdentityResponse,
    ApikeyProviderResponse,
    ApikeyResponse,
    CreateAgentIdentityRequest,
    CreateApikeyProviderRequest,
    CreateDelegatedApiKeyProviderRequest,
    CreateOauth2ProviderRequest,
    DelegatedApiKeyProviderResponse,
    GetDelegatedApiKeyRequest,
    GetDelegatedApiKeyResponse,
    GetM2mTokenRequest,
    Oauth2ProviderResponse,
    PagedResponseAgentIdentityResponse,
    ThreeLoTokenRequest,
    TokenResponse,
    UpdateAgentIdentityRequest,
    UpdateApikeyProviderRequest,
    UpdateOauth2ProviderRequest,
)

__all__ = [
    # Client classes
    "IdentityClient",
    "HTTPClientProtocol",
    "HttpxClient",
    # Credentials
    "IAMCredentials",
    # Auth decorators
    "requires_access_token",
    "requires_api_key",
    "TokenPoller",
    # Models (commonly used)
    "AgentIdentityResponse",
    "CreateAgentIdentityRequest",
    "UpdateAgentIdentityRequest",
    "Oauth2ProviderResponse",
    "CreateOauth2ProviderRequest",
    "UpdateOauth2ProviderRequest",
    "TokenResponse",
    "GetM2mTokenRequest",
    "ThreeLoTokenRequest",
    "ApikeyProviderResponse",
    "CreateApikeyProviderRequest",
    "UpdateApikeyProviderRequest",
    "ApikeyResponse",
    "DelegatedApiKeyProviderResponse",
    "CreateDelegatedApiKeyProviderRequest",
    "GetDelegatedApiKeyRequest",
    "GetDelegatedApiKeyResponse",
    "PagedResponseAgentIdentityResponse",
]

