"""Authentication decorators and utilities for GreenNode AgentBase Identity SDK.

Provides decorators for automatically fetching OAuth2 access tokens and API keys
before calling decorated functions.
"""

import asyncio
import contextvars
import logging
import os
from functools import wraps
from typing import Any, Callable, Dict, List, Optional

from typing_extensions import Literal

from ..core.logging import configure_logger
from ..exceptions import GreenNodeConfigurationError
from ..runtime.context import GreenNodeAgentBaseContext
from .client import IdentityClient
from .config import get_config_value, save_config_value
from .credentials import IAMCredentials
from .models import (
    DelegatedApiKeyStatus,
    GetDelegatedApiKeyRequest,
    GetDelegatedApiKeyResponse,
    GetM2mTokenRequest,
    ThreeLoTokenRequest,
)

logger = logging.getLogger("greennode_agentbase.identity.auth")
configure_logger(logger)


class TokenPoller:
    """Abstract base class for token polling implementations."""

    async def poll_for_token(self) -> str:
        """Poll for a token and return it when available.

        Raises:
            NotImplementedError: Must be implemented by subclasses
        """
        raise NotImplementedError


# Default configuration for the polling mechanism
DEFAULT_POLLING_INTERVAL_SECONDS = 5
DEFAULT_POLLING_TIMEOUT_SECONDS = 600


class _DefaultTokenPoller(TokenPoller):
    """Default implementation of token polling."""

    def __init__(self, auth_url: str, polling_func: Callable[[], str | None]):
        """Initialize the token poller with auth URL and polling function."""
        self.auth_url = auth_url
        self.polling_func = polling_func
        self.logger = logging.getLogger("greennode_agentbase.identity.default_token_poller")
        configure_logger(self.logger)

    async def poll_for_token(self) -> str:
        """Poll for a token until it becomes available or timeout occurs."""
        import time

        start_time = time.time()
        while time.time() - start_time < DEFAULT_POLLING_TIMEOUT_SECONDS:
            await asyncio.sleep(DEFAULT_POLLING_INTERVAL_SECONDS)

            self.logger.info("Polling for token for authorization url: %s", self.auth_url)
            resp = self.polling_func()
            if resp is not None:
                self.logger.info("Token is ready")
                return resp

        raise asyncio.TimeoutError(
            f"Polling timed out after {DEFAULT_POLLING_TIMEOUT_SECONDS} seconds. "
            + "User may not have completed authorization."
        )


class _AsyncTokenPoller(TokenPoller):
    """Async implementation of token polling for API keys."""

    def __init__(self, auth_url: str, polling_func: Callable[[], Any]):
        """Initialize the async token poller with auth URL and async polling function."""
        self.auth_url = auth_url
        self.polling_func = polling_func
        self.logger = logging.getLogger("greennode_agentbase.identity.async_token_poller")
        configure_logger(self.logger)

    async def poll_for_token(self) -> str:
        """Poll for a token until it becomes available or timeout occurs."""
        import time

        start_time = time.time()
        while time.time() - start_time < DEFAULT_POLLING_TIMEOUT_SECONDS:
            await asyncio.sleep(DEFAULT_POLLING_INTERVAL_SECONDS)

            self.logger.info("Polling for token for authorization url: %s", self.auth_url)
            resp = await self.polling_func()
            if resp is not None:
                self.logger.info("Token is ready")
                return resp

        raise asyncio.TimeoutError(
            f"Polling timed out after {DEFAULT_POLLING_TIMEOUT_SECONDS} seconds. "
            + "User may not have completed authorization."
        )


def requires_access_token(
    *,
    provider_name: str,
    into: str = "access_token",
    scopes: List[str],
    on_auth_url: Optional[Callable[[str], Any]] = None,
    auth_flow: Literal["M2M", "USER_FEDERATION"],
    callback_url: Optional[str] = None,
    force_authentication: bool = False,
    token_poller: Optional[TokenPoller] = None,
    custom_state: Optional[str] = None,
    custom_parameters: Optional[Dict[str, str]] = None,
    identity_client: Optional[IdentityClient] = None,
    iam_credentials: Optional[IAMCredentials] = None,
) -> Callable:
    """Decorator that fetches an OAuth2 access token before calling the decorated function.

    Args:
        provider_name: The credential provider name
        into: Parameter name to inject the token into
        scopes: OAuth2 scopes to request
        on_auth_url: Callback for handling authorization URLs
        auth_flow: Authentication flow type ("M2M" or "USER_FEDERATION")
        callback_url: OAuth2 callback URL
        force_authentication: Force re-authentication
        token_poller: Custom token poller implementation
        custom_state: A state that allows applications to verify the validity of callbacks to callback_url
        custom_parameters: A map of custom parameters to include in authorization request to the credential provider
        identity_client: Optional IdentityClient instance (creates new one if not provided)
        iam_credentials: Optional IAM credentials (used if workload access token is needed)

    Returns:
        Decorator function

    Example:
        >>> @requires_access_token(
        ...     provider_name="my-provider",
        ...     scopes=["read", "write"],
        ...     auth_flow="M2M"
        ... )
        >>> async def my_function(access_token: str):
        ...     # Use access_token here
        ...     pass
    """

    def decorator(func: Callable) -> Callable:
    
        async def _get_token(agent_identity_token: str, agent_identity_name: str) -> str:
            """Common token fetching logic."""
            client = IdentityClient(iam_credentials=IAMCredentials())
            if auth_flow == "M2M":
                request = GetM2mTokenRequest(scopes=scopes)
                response = await client.get_m2m_token_async(
                    provider_name=provider_name,
                    agent_identity_name=agent_identity_name,
                    request=request,
                )
                return response.access_token or ""
            else:  # USER_FEDERATION (3LO)
                # Get callback URL
                oauth2_callback_url = callback_url or GreenNodeAgentBaseContext.get_oauth2_callback_url()
                if not oauth2_callback_url:
                    raise ValueError("callback_url is required for USER_FEDERATION flow")

                # Get agent user ID from context or generate one
                agent_user_id = GreenNodeAgentBaseContext.get_user_id()
                logger.info("Agent user ID: %s", agent_user_id)
                request = ThreeLoTokenRequest(
                    agent_user_id=agent_user_id,
                    scopes=scopes,
                    return_url=oauth2_callback_url,
                    custom_state=custom_state,
                    custom_parameters=custom_parameters,
                    force_authentication=force_authentication,
                )

                response = await client.get_3lo_token_async(
                    provider_name=provider_name,
                    agent_identity_name=agent_identity_name,
                    request=request,
                )

                # Phase 1: If we got a token directly, return it
                if response.access_token:
                    return response.access_token

                # Phase 2: If we got an authorization URL, handle the OAuth flow
                if response.authorization_url:
                    auth_url = response.authorization_url
                    session_id = response.session_id
                    
                    if not session_id:
                        raise ValueError(
                            "Authorization URL received but no session_id provided. "
                            "Cannot proceed with OAuth2 federation flow."
                        )
                    
                    # Call on_auth_url callback if provided
                    if on_auth_url:
                        if asyncio.iscoroutinefunction(on_auth_url):
                            await on_auth_url(auth_url)
                        else:
                            on_auth_url(auth_url)
                    
                    # Phase 2: Poll with session_id until access_token is available
                    poll_request = ThreeLoTokenRequest(
                        agent_user_id=agent_user_id,
                        scopes=scopes,
                        return_url=oauth2_callback_url,
                        session_id=session_id,
                        custom_state=custom_state,
                        custom_parameters=custom_parameters,
                        # force_authentication=force_authentication,
                    )
                    
                    async def poll_for_completion() -> Optional[str]:
                        """Poll for OAuth2 completion by checking for access_token."""
                        try:
                            poll_response = await client.get_3lo_token_async(
                                provider_name=provider_name,
                                agent_identity_name=agent_identity_name,
                                request=poll_request,
                            )
                            logger.info("Polling for OAuth2 token completion")
                            
                            # If we got an access_token, return completion indicator
                            if poll_response.access_token:
                                return "COMPLETED"
                            
                            # Continue polling if no access_token yet
                            return None
                        except Exception as e:
                            logger.debug(f"Polling error: {e}")
                            # Re-raise if it's a ValueError (authorization failed)
                            if isinstance(e, ValueError):
                                raise
                            return None
                    
                    # Use async token poller (default or custom) to poll until COMPLETED
                    if token_poller:
                        poller = token_poller
                    else:
                        poller = _AsyncTokenPoller(auth_url, poll_for_completion)
                    
                    # Poll until access_token is available
                    await poller.poll_for_token()
                    
                    # Phase 3: Final request without session_id to get the final access_token
                    final_request = ThreeLoTokenRequest(
                        agent_user_id=agent_user_id,
                        scopes=scopes,
                        return_url=oauth2_callback_url,
                        custom_state=custom_state,
                        custom_parameters=custom_parameters,
                        # force_authentication=force_authentication,
                        # session_id is NOT included in final request
                    )
                    
                    final_response = await client.get_3lo_token_async(
                        provider_name=provider_name,
                        agent_identity_name=agent_identity_name,
                        request=final_request,
                    )
                    
                    # Return the access_token from final response
                    if final_response.access_token:
                        return final_response.access_token
                    
                    # If final request doesn't return access_token, raise error
                    raise ValueError("OAuth2 federation completed but final request did not return access token")
                
                # If we have an authorization URL, we should have handled it above
                # If we get here without an authorization URL and no access_token, something is wrong
                if not response.authorization_url and not response.access_token:
                    raise ValueError(
                        "OAuth2 federation response is invalid: no authorization URL and no access token. "
                        "Cannot proceed with USER_FEDERATION flow."
                    )
                
                # Fallback: if we have an authorization URL but no clear path forward
                raise ValueError(
                    f"OAuth2 federation response is unclear. "
                    f"Has access token: {bool(response.access_token)}, "
                    f"Has authorization URL: {bool(response.authorization_url)}"
                )

        async def _get_workload_access_token() -> str:
            """Get workload access token from context or IAM credentials."""
            client = IdentityClient(iam_credentials=IAMCredentials())
            
            token = GreenNodeAgentBaseContext.get_workload_access_token()
            if token is not None:
                return token

            # Try to get from IAM credentials
            creds = iam_credentials or IAMCredentials()
            if creds.is_available():
                # Get or create workload identity name
                workload_name = get_config_value("GREENNODE_ACCESS_CONTROL_NAME")
                
                # If workload identity name not found, create one
                if not workload_name:
                    logger.info("Workload identity name not found, creating new workload identity")
                    identity_response = await client.create_workload_identity_async()
                    workload_name = identity_response.name
                    
                    # Save to both environment variable and config file
                    if workload_name:
                        os.environ["GREENNODE_ACCESS_CONTROL_NAME"] = workload_name
                        save_config_value("access_control_name", workload_name)
                        logger.info(f"Created and saved workload identity: {workload_name}")
                
                return await client.get_workload_access_token_async(workload_name)

            # If in Docker container, raise error
            if get_config_value("DOCKER_CONTAINER") == "1":
                raise ValueError(
                    "Workload access token has not been set. If invoking agent runtime via OAuth2 inbound auth, "
                    "please specify the X-GreenNode-AgentBase-Access-Token header and retry."
                )

            # For local dev, try to create/get workload identity
            # Only if IAM credentials are available (service account is compulsory)
            if creds.is_available():
                workload_name = get_config_value("GREENNODE_ACCESS_CONTROL_NAME")
                if not workload_name:
                    logger.info("Workload identity name not found, creating new workload identity")
                    identity_response = await client.create_workload_identity_async()
                    workload_name = identity_response.name
                    if workload_name:
                        os.environ["GREENNODE_ACCESS_CONTROL_NAME"] = workload_name
                        save_config_value("access_control_name", workload_name)
                        logger.info(f"Created and saved workload identity: {workload_name}")
                return await client.get_workload_access_token_async(workload_name)
            
            raise GreenNodeConfigurationError(
                "IAM credentials (service account) are required but not available. "
                "Please provide access_key_id and secret_access_key via constructor, "
                "environment variables, or config file."
            )

        @wraps(func)
        async def async_wrapper(*args: Any, **kwargs_func: Any) -> Any:
            agent_identity_token = await _get_workload_access_token()
            # Use workload identity name as agent identity name
            agent_identity_name = get_config_value("GREENNODE_ACCESS_CONTROL_NAME", "default-workload")
            token = await _get_token(agent_identity_token, agent_identity_name)
            kwargs_func[into] = token
            return await func(*args, **kwargs_func)

        @wraps(func)
        def sync_wrapper(*args: Any, **kwargs_func: Any) -> Any:
            agent_identity_name = get_config_value("GREENNODE_ACCESS_CONTROL_NAME", "default-workload")
            if _has_running_loop():
                # for async env, eg. runtime
                ctx = contextvars.copy_context()
                import concurrent.futures

                with concurrent.futures.ThreadPoolExecutor() as executor:
                    future = executor.submit(
                        ctx.run,
                        asyncio.run,
                        _get_workload_access_token(),
                    )
                    agent_identity_token = future.result()

                    future = executor.submit(
                        ctx.run,
                        asyncio.run,
                        _get_token(agent_identity_token, agent_identity_name),
                    )
                    token = future.result()
            else:
                # for sync env, eg. local dev
                agent_identity_token = asyncio.run(_get_workload_access_token())
                token = asyncio.run(_get_token(agent_identity_token, agent_identity_name))

            kwargs_func[into] = token
            return func(*args, **kwargs_func)

        # Return appropriate wrapper based on function type
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper

    return decorator


def requires_api_key(
    *,
    provider_name: str,
    into: str = "api_key",
    callback_url: Optional[str] = None,
    on_auth_url: Optional[Callable[[str], Any]] = None,
    token_poller: Optional[TokenPoller] = None,
    custom_state: Optional[str] = None,
    force_delegation: Optional[bool] = False,
    identity_client: Optional[IdentityClient] = None,
    iam_credentials: Optional[IAMCredentials] = None,
    auth_flow: Optional[Literal["M2M", "USER_FEDERATION"]] = None,
) -> Callable:
    """Decorator that fetches an API key before calling the decorated function.

    Supports both static (M2M) and delegated (USER_FEDERATION) API key providers.
    Use auth_flow="M2M" for machine-to-machine static API keys; use
    auth_flow="USER_FEDERATION" when a user delegation flow (callback_url) is required.
    If auth_flow is None, the provider type is detected automatically (try delegated then static).

    Args:
        provider_name: The credential provider name
        into: Parameter name to inject the API key into
        callback_url: Optional callback URL for delegation flow
        on_auth_url: Callback for handling authorization URLs
        token_poller: Optional custom token poller implementation
        custom_state: Optional custom state for delegation flow
        force_delegation: Force delegation flow even if return_url not provided
        identity_client: Optional IdentityClient instance (creates new one if not provided)
        iam_credentials: Optional IAM credentials (used if workload access token is needed)
        auth_flow: When "M2M", use only static API key path; when "USER_FEDERATION", use
            delegation flow (callback_url/return_url required). When None, auto-detect.

    Returns:
        Decorator function

    Example:
        >>> @requires_api_key(provider_name="my-provider", auth_flow="M2M")
        >>> async def my_function(api_key: str):
        ...     # Use api_key here
        ...     pass
    """

    def decorator(func: Callable) -> Callable:
        logger.info("Getting API key in decorator")
        # Use provided client or create new one with provided credentials
        client = identity_client or IdentityClient(iam_credentials=IAMCredentials())

        async def _get_api_key(agent_identity_token: str, agent_identity_name: str) -> str:
            """Get API key for agent identity, supporting both static and delegated providers."""
            return_url = callback_url or GreenNodeAgentBaseContext.get_oauth2_callback_url()

            # M2M: use only static API key path (no delegation)
            if auth_flow == "M2M":
                response = await client.get_api_key_for_agent_identity_async(
                    provider_name=provider_name,
                    agent_identity_name=agent_identity_name,
                )
                return response.apikey or ""

            # USER_FEDERATION: require callback/return URL for delegation
            if auth_flow == "USER_FEDERATION":
                if not (return_url or force_delegation):
                    raise GreenNodeConfigurationError(
                        "auth_flow is USER_FEDERATION but no callback_url or return_url was provided. "
                        "Please provide callback_url parameter or set it in context."
                    )

            # Delegation flow when return_url/callback_url is provided (or auto-detect when auth_flow is None)
            if return_url or force_delegation:
                # Use delegation flow
                agent_user_id = GreenNodeAgentBaseContext.get_user_id()
                
                request = GetDelegatedApiKeyRequest(
                    agent_user_id=agent_user_id,
                    return_url=return_url or "",
                    custom_state=custom_state,
                    force_delegation=force_delegation,
                )
                
                response = await client.get_delegated_api_key_for_agent_identity_async(
                    provider_name=provider_name,
                    agent_identity_name=agent_identity_name,
                    request=request,
                )
                
                # Check for FAILED status in initial response
                if response.status == DelegatedApiKeyStatus.FAILED:
                    raise ValueError("API key delegation failed")
                
                # If we got an API key directly, return it
                if response.apikey:
                    return response.apikey
                
                # If we got an authorization URL, handle the delegation flow
                if response.authorization_url:
                    auth_url = response.authorization_url
                    session_id = response.session_id
                    
                    # Call on_auth_url callback if provided (similar to OAuth2 flow)
                    if on_auth_url:
                        if asyncio.iscoroutinefunction(on_auth_url):
                            await on_auth_url(auth_url)
                        else:
                            on_auth_url(auth_url)
                    
                    # Phase 2: Poll with session_id until status is COMPLETED
                    poll_request = GetDelegatedApiKeyRequest(
                        agent_user_id=agent_user_id,
                        return_url=return_url or "",
                        session_id=session_id,
                        force_delegation=force_delegation,
                    )
                    
                    async def poll_for_completion() -> Optional[str]:
                        """Poll for delegation completion by checking status."""
                        try:
                            poll_response = await client.get_delegated_api_key_for_agent_identity_async(
                                provider_name=provider_name,
                                agent_identity_name=agent_identity_name,
                                request=poll_request,
                            )
                            logger.info(f"Poll response status: {poll_response.status}")
                            
                            # Check if status is FAILED
                            if poll_response.status == DelegatedApiKeyStatus.FAILED:
                                raise ValueError("API key delegation failed during polling")
                            
                            # Return special indicator when COMPLETED
                            if poll_response.status == DelegatedApiKeyStatus.COMPLETED or not poll_response.status:
                                return "COMPLETED"
                            
                            # Continue polling if IN_PROGRESS or other status
                            return None
                        except Exception as e:
                            logger.debug(f"Polling error: {e}")
                            # Re-raise if it's a ValueError (delegation failed)
                            if isinstance(e, ValueError):
                                raise
                            return None
                    
                    # Use async token poller (default or custom) to poll until COMPLETED
                    if token_poller:
                        poller = token_poller
                    else:
                        poller = _AsyncTokenPoller(auth_url, poll_for_completion)
                    
                    # Poll until status is COMPLETED
                    await poller.poll_for_token()
                    
                    # Phase 3: Final request without session_id to get the final api_key
                    final_request = GetDelegatedApiKeyRequest(
                        agent_user_id=agent_user_id,
                        return_url=return_url or "",
                        custom_state=custom_state,
                        # force_delegation=force_delegation,
                        # session_id is NOT included in final request
                    )
                    
                    final_response = await client.get_delegated_api_key_for_agent_identity_async(
                        provider_name=provider_name,
                        agent_identity_name=agent_identity_name,
                        request=final_request,
                    )
                    
                    # Return the api_key from final response
                    if final_response.apikey:
                        return final_response.apikey
                    
                    # If final request doesn't return api_key, raise error
                    raise ValueError("Delegation completed but final request did not return API key")
                
                # If we have an authorization URL, we should have handled it above
                # If we get here without an authorization URL and no apikey, something is wrong
                if not response.authorization_url and not response.apikey:
                    raise ValueError(
                        "API key delegation response is invalid: no authorization URL and no API key. "
                        f"Status: {response.status}"
                    )
                
                # If status is IN_PROGRESS but no authorization URL, something unexpected happened
                if response.status == DelegatedApiKeyStatus.IN_PROGRESS and not response.authorization_url:
                    raise ValueError(
                        "API key delegation is IN_PROGRESS but no authorization URL provided. "
                        "Cannot proceed with delegation flow."
                    )
                
                # Fallback: if we have a status but no clear path forward
                raise ValueError(
                    f"API key delegation response is unclear. Status: {response.status}, "
                    f"Has API key: {bool(response.apikey)}, Has authorization URL: {bool(response.authorization_url)}"
                )
            
            # Priority 2: Auto-detect provider type only when auth_flow is None
            if auth_flow is None:
                # Try delegated provider first, then static
                is_delegated = False
                is_static = False

                try:
                    await client.get_delegated_api_key_provider_async(name=provider_name)
                    is_delegated = True
                except Exception as e:
                    from ..exceptions import GreenNodeRequestError
                    if isinstance(e, GreenNodeRequestError) and getattr(e, 'status_code', None) >= 400:
                        try:
                            await client.get_api_key_provider_async(name=provider_name)
                            is_static = True
                        except Exception as e2:
                            if isinstance(e2, GreenNodeRequestError) and getattr(e2, 'status_code', None) >= 400:
                                raise GreenNodeConfigurationError(
                                    f"API key provider '{provider_name}' not found. "
                                    "Neither delegated nor static provider exists with this name."
                                ) from e2
                            raise
                    else:
                        raise

                if is_delegated:
                    raise GreenNodeConfigurationError(
                        f"Provider '{provider_name}' is a delegated API key provider, "
                        "but no callback_url or return_url was provided. "
                        "Please provide callback_url parameter or set it in context."
                    )

            # Static provider - use existing flow (auth_flow is None and static, or M2M already returned above)
            response = await client.get_api_key_for_agent_identity_async(
                provider_name=provider_name,
                agent_identity_name=agent_identity_name,
            )
            return response.apikey or ""

        async def _get_workload_access_token() -> str:
            """Get workload access token from context or IAM credentials."""
            # Use the same client instance from outer scope, or create one with provided credentials
            workload_client = identity_client or IdentityClient(iam_credentials=iam_credentials or IAMCredentials())
            token = GreenNodeAgentBaseContext.get_workload_access_token()
            if token is not None:
                return token

            # Try to get from IAM credentials
            creds = iam_credentials or IAMCredentials()
            if creds.is_available():
                # Get or create workload identity name
                workload_name = get_config_value("GREENNODE_ACCESS_CONTROL_NAME")
                
                # If workload identity name not found, create one
                if not workload_name:
                    logger.info("Workload identity name not found, creating new workload identity")
                    identity_response = await workload_client.create_workload_identity_async()
                    workload_name = identity_response.name
                    
                    # Save to both environment variable and config file
                    if workload_name:
                        os.environ["GREENNODE_ACCESS_CONTROL_NAME"] = workload_name
                        save_config_value("access_control_name", workload_name)
                        logger.info(f"Created and saved workload identity: {workload_name}")
                
                return await workload_client.get_workload_access_token_async(workload_name)

            # If in Docker container, raise error
            if get_config_value("DOCKER_CONTAINER") == "1":
                raise ValueError(
                    "Workload access token has not been set. If invoking agent runtime via OAuth2 inbound auth, "
                    "please specify the X-GreenNode-AgentBase-Access-Token header and retry."
                )

            # For local dev, try to create/get workload identity
            # Only if IAM credentials are available (service account is compulsory)
            if creds.is_available():
                workload_name = get_config_value("GREENNODE_ACCESS_CONTROL_NAME")
                if not workload_name:
                    logger.info("Workload identity name not found, creating new workload identity")
                    identity_response = await workload_client.create_workload_identity_async()
                    workload_name = identity_response.name
                    if workload_name:
                        os.environ["GREENNODE_ACCESS_CONTROL_NAME"] = workload_name
                        save_config_value("access_control_name", workload_name)
                        logger.info(f"Created and saved workload identity: {workload_name}")
                return await workload_client.get_workload_access_token_async(workload_name)
            
            raise GreenNodeConfigurationError(
                "IAM credentials (service account) are required but not available. "
                "Please provide access_key_id and secret_access_key via constructor, "
                "environment variables, or config file."
            )

        async def get_credentials() -> str:
            """Get credentials from context or IAM credentials."""
            token = await _get_workload_access_token()
            agent_identity_name = get_config_value("GREENNODE_ACCESS_CONTROL_NAME")
            key = await _get_api_key(token, agent_identity_name)
            return key

        @wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            logger.info("Getting API key in async wrapper")
            agent_identity_token = await _get_workload_access_token()
            # Use workload identity name as agent identity name
            agent_identity_name = get_config_value("GREENNODE_ACCESS_CONTROL_NAME", "default-workload")
            api_key = await _get_api_key(agent_identity_token, agent_identity_name)
            # Ensure api_key is a string
            if not isinstance(api_key, str):
                raise TypeError(
                    f"Expected API key to be a string, but got {type(api_key).__name__}: {api_key}. "
                    f"This may indicate an issue with the API key retrieval for provider '{provider_name}'."
                )
            kwargs[into] = api_key
            return await func(*args, **kwargs)

        @wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            logger.info("Getting API key in sync wrapper")
            if _has_running_loop():
                # for async env, eg. runtime
                ctx = contextvars.copy_context()
                import concurrent.futures

                with concurrent.futures.ThreadPoolExecutor() as executor:
                    future = executor.submit(
                        ctx.run,
                        asyncio.run,
                        get_credentials(),
                    )
                    api_key = future.result()
            else:
                # for sync env, eg. local dev
                api_key = asyncio.run(get_credentials())

            # Ensure api_key is a string
            if not isinstance(api_key, str):
                raise TypeError(
                    f"Expected API key to be a string, but got {type(api_key).__name__}: {api_key}. "
                    f"This may indicate an issue with the API key retrieval for provider '{provider_name}'."
                )
            kwargs[into] = api_key
            return func(*args, **kwargs)

        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper

    return decorator


def _has_running_loop() -> bool:
    """Check if there is a running event loop."""
    try:
        asyncio.get_running_loop()
        return True
    except RuntimeError:
        return False

