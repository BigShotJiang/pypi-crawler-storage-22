"""Identity client for GreenNode AgentBase Identity SDK.

Provides IdentityClient for interacting with the Identity API, with abstract HTTP client
interface for testability and flexibility.
"""

import asyncio
import logging
from typing import List, Optional

from ..core import AuthenticatedAPIClient
from ..core.http_client import HttpxClient, HTTPClientProtocol
from ..core.logging import configure_logger
from .credentials import IAMCredentials
from .models import (
    AgentIdentityResponse,
    CreateAgentIdentityRequest,
    UpdateAgentIdentityRequest,
)

logger = logging.getLogger("greennode_agentbase.identity")
configure_logger(logger)


class IdentityClient(AuthenticatedAPIClient):
    """High-level client for GreenNode AgentBase Identity API.

    This client provides methods for interacting with the Identity API, including
    agent identity management, OAuth2 providers, API key providers, and token retrieval.

    All API methods automatically authenticate using IAM credentials with OAuth2
    client_credentials flow (basic auth). IAM credentials can be provided via:
    - Constructor parameter
    - Environment variables (GREENNODE_CLIENT_ID, GREENNODE_CLIENT_SECRET)
    - Config file (.greennode.json in current directory)

    Tokens are automatically cached and refreshed when expired to minimize
    authentication requests.

    Args:
        base_url: Base URL for the Identity API (default: from spec)
        http_client: Optional HTTP client implementation (default: HttpxClient)
        iam_credentials: Optional IAM credentials for authentication. If not provided,
            will attempt to load from environment variables or config file.
        access_token: Optional OAuth2 access token for API authentication (backward
            compatibility). If IAM credentials are available, they will be preferred.

    Example:
        >>> # Using IAM credentials from environment variables
        >>> client = IdentityClient()
        >>> identity = await client.get_agent_identity_async("my-identity")
        >>> 
        >>> # Using IAM credentials explicitly
        >>> from greennode_agentbase.identity import IAMCredentials
        >>> creds = IAMCredentials(access_key_id="key", secret_access_key="secret")
        >>> client = IdentityClient(iam_credentials=creds)
        >>> token = await client.get_m2m_token_async(
        ...     provider_name="my-provider",
        ...     agent_identity_name="my-identity",
        ...     request=GetM2mTokenRequest(scopes=["read", "write"])
        ... )
    """

    SERVICE_NAME = "identity"

    async def get_workload_access_token_async(
        self,
        workload_identity_name: str,
        user_id: Optional[str] = None,
    ) -> str:
        """Get workload access token (requires IAM credentials).

        This method uses IAM credentials to authenticate and get a workload access token,
        which can be used as the agent identity token in API calls.

        Args:
            workload_identity_name: Name of the workload identity (used as agent identity name)
            user_id: Optional user ID for user-scoped tokens

        Returns:
            Workload access token string

        Raises:
            GreenNodeConfigurationError: If IAM credentials are not available
            GreenNodeRequestError: If the request fails

        Example:
            >>> token = await client.get_workload_access_token_async("my-workload")
        """
        # Get OAuth2 token first
        oauth2_token = await self._get_oauth2_token()

        # Update the HTTP client's access token for subsequent API calls
        if isinstance(self._http_client, HttpxClient):
            await self._http_client.update_access_token(oauth2_token)

        # For now, we'll use a simplified approach - in a real implementation,
        # this would call a specific endpoint. For the SDK, we'll use the OAuth2 token
        # as the workload access token, but this should be replaced with actual API call
        # when the endpoint is available.
        return oauth2_token

    def get_workload_access_token(
        self,
        workload_identity_name: str,
        user_id: Optional[str] = None,
    ) -> str:
        """Synchronous version of get_workload_access_token_async."""
        return asyncio.run(self.get_workload_access_token_async(workload_identity_name, user_id))

    # Workload Identity Methods (require IAM credentials)
    async def create_workload_identity_async(
        self,
        name: Optional[str] = None,
        allowed_return_urls: Optional[List[str]] = None,
    ) -> AgentIdentityResponse:
        """Create a workload identity (requires IAM credentials).

        The workload identity name is used as the agent identity name in the API.
        This method requires IAM credentials to be available.

        Args:
            name: Optional name for the workload identity (auto-generated if not provided)
            allowed_return_urls: Optional list of allowed return URLs for OAuth2 callbacks

        Returns:
            Created agent identity response

        Raises:
            GreenNodeConfigurationError: If IAM credentials are not available
            GreenNodeRequestError: If the request fails

        Example:
            >>> identity = await client.create_workload_identity_async("my-workload")
        """
        self.iam_credentials.require()

        # Generate name if not provided
        if name is None:
            import uuid
            name = f"workload-{uuid.uuid4().hex[:8]}"

        # Create agent identity using the workload identity name
        request = CreateAgentIdentityRequest(
            name=name,
            allowed_return_urls=allowed_return_urls or [],
        )

        return await self.create_agent_identity_async(request=request)

    def create_workload_identity(
        self,
        name: Optional[str] = None,
        allowed_return_urls: Optional[List[str]] = None,
    ) -> AgentIdentityResponse:
        """Synchronous version of create_workload_identity_async."""
        return asyncio.run(self.create_workload_identity_async(name, allowed_return_urls))

    async def update_workload_identity_async(
        self,
        name: str,
        allowed_return_urls: List[str],
    ) -> AgentIdentityResponse:
        """Update a workload identity (requires IAM credentials).

        The workload identity name is used as the agent identity name in the API.
        This method requires IAM credentials to be available.

        Args:
            name: Name of the workload identity (used as agent identity name)
            allowed_return_urls: List of allowed return URLs for OAuth2 callbacks

        Returns:
            Updated agent identity response

        Raises:
            GreenNodeConfigurationError: If IAM credentials are not available
            GreenNodeRequestError: If the request fails

        Example:
            >>> identity = await client.update_workload_identity_async(
            ...     "my-workload",
            ...     ["https://example.com/callback"]
            ... )
        """
        self.iam_credentials.require()

        # Update agent identity using the workload identity name
        request = UpdateAgentIdentityRequest(allowed_return_urls=allowed_return_urls)
        return await self.update_agent_identity_async(name, request)

    def update_workload_identity(
        self,
        name: str,
        allowed_return_urls: List[str],
    ) -> AgentIdentityResponse:
        """Synchronous version of update_workload_identity_async."""
        return asyncio.run(self.update_workload_identity_async(name, allowed_return_urls))
