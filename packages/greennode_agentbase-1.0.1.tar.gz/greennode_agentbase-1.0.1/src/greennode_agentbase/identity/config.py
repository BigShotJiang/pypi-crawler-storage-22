"""Configuration utility for GreenNode AgentBase Identity SDK.

Provides centralized configuration management with support for environment variables
and .greennode.json config file, following the priority: env → config file → default.
"""

import json
import logging
import os
from pathlib import Path
from typing import Optional

from ..core.logging import configure_logger

logger = logging.getLogger("greennode_agentbase.identity.config")
configure_logger(logger)

# Cache for config file contents to avoid repeated file reads
_config_cache: Optional[dict] = None
_config_file_path = Path(".greennode.json")


def _load_config_file() -> Optional[dict]:
    """Load configuration from .greennode.json config file.

    Returns:
        Dictionary with config values if file exists and is valid, None otherwise
    """
    global _config_cache

    # Return cached config if available
    if _config_cache is not None:
        return _config_cache

    if not _config_file_path.exists():
        _config_cache = {}
        return _config_cache

    try:
        with open(_config_file_path, "r", encoding="utf-8") as file:
            config = json.load(file)
            if isinstance(config, dict):
                _config_cache = config
                return _config_cache
    except (json.JSONDecodeError, OSError) as e:
        logger.warning(f"Failed to load config file {_config_file_path}: {e}")
        _config_cache = {}
        return _config_cache

    _config_cache = {}
    return _config_cache


def get_config_value(key: str, default: Optional[str] = None) -> Optional[str]:
    """Get configuration value with priority: environment variable → config file → default.

    Args:
        key: Configuration key name (e.g., "GREENNODE_ACCESS_CONTROL_NAME")
        default: Default value to return if not found in env or config file

    Returns:
        Configuration value if found, default if provided, None otherwise

    Example:
        >>> access_control_name = get_config_value("GREENNODE_ACCESS_CONTROL_NAME", "default-workload")
        >>> docker_flag = get_config_value("DOCKER_CONTAINER")
    """
    # Priority 1: Environment variable
    env_value = os.getenv(key)
    if env_value is not None:
        return env_value

    # Priority 2: Config file
    config = _load_config_file()
    if config:
        # Convert key to config file format (e.g., GREENNODE_ACCESS_CONTROL_NAME -> access_control_name)
        # Remove GREENNODE_ prefix and convert to lowercase
        config_key = key.lower()
        if config_key.startswith("greennode_"):
            config_key = config_key[len("greennode_"):]
        
        # Try both the converted key and the original key
        value = config.get(config_key) or config.get(key)
        if value is not None:
            return str(value)

    # Priority 3: Default
    return default


def save_config_value(key: str, value: str) -> None:
    """Save configuration value to .greennode.json config file.

    This function updates the config file, preserving existing values.
    It also updates the in-memory cache.

    Args:
        key: Configuration key name (will be stored as-is in config file)
        value: Configuration value to save

    Example:
        >>> save_config_value("access_control_name", "my-workload")
    """
    global _config_cache

    # Load existing config
    config = _load_config_file() or {}
    if not isinstance(config, dict):
        config = {}

    # Update config with new value
    config[key] = value

    # Write to file
    try:
        with open(_config_file_path, "w", encoding="utf-8") as file:
            json.dump(config, file, indent=2)
        # Update cache
        _config_cache = config
        logger.info(f"Saved config value {key} to {_config_file_path}")
    except OSError as e:
        logger.warning(f"Failed to save config value {key} to {_config_file_path}: {e}")


def clear_config_cache() -> None:
    """Clear the in-memory config cache.

    This is useful for testing or when the config file might have been
    modified externally.
    """
    global _config_cache
    _config_cache = None
