"""IAM credentials management for GreenNode AgentBase Identity SDK.

Provides IAMCredentials class for managing access key ID and secret access key
with support for multiple credential sources (constructor, environment variables, config file).
"""

import json
import os
from pathlib import Path
from typing import Optional

from ..exceptions import GreenNodeConfigurationError
from .config import get_config_value


class IAMCredentials:
    """Manages IAM credentials (access key ID and secret access key).

    Supports multiple credential sources with the following priority order:
    1. Constructor parameters
    2. Environment variables (GREENNODE_CLIENT_ID, GREENNODE_CLIENT_SECRET)
    3. Config file (.greennode.json in current directory)

    Args:
        access_key_id: Optional access key ID (if not provided, will try env vars and config file)
        secret_access_key: Optional secret access key (if not provided, will try env vars and config file)

    Example:
        >>> # From constructor
        >>> creds = IAMCredentials(access_key_id="key", secret_access_key="secret")
        >>> # From environment variables
        >>> # Set GREENNODE_CLIENT_ID and GREENNODE_CLIENT_SECRET
        >>> creds = IAMCredentials()
        >>> # From config file
        >>> # Create .greennode.json with {"access_key_id": "...", "secret_access_key": "..."}
        >>> creds = IAMCredentials()
    """

    def __init__(
        self,
        access_key_id: Optional[str] = None,
        secret_access_key: Optional[str] = None,
    ) -> None:
        """Initialize IAM credentials from multiple sources."""
        self._access_key_id: Optional[str] = access_key_id
        self._secret_access_key: Optional[str] = secret_access_key

        # Try environment variables and config file if not provided
        # Use centralized config utility for consistency
        if self._access_key_id is None:
            self._access_key_id = get_config_value("GREENNODE_CLIENT_ID")
        if self._secret_access_key is None:
            self._secret_access_key = get_config_value("GREENNODE_CLIENT_SECRET")
        
        # Fallback to direct config file loading for backward compatibility
        # (in case config file uses different key names)
        if self._access_key_id is None or self._secret_access_key is None:
            config = self._load_config_file()
            if config:
                if self._access_key_id is None:
                    self._access_key_id = config.get("access_key_id")
                if self._secret_access_key is None:
                    self._secret_access_key = config.get("secret_access_key")

    @property
    def access_key_id(self) -> Optional[str]:
        """Get the access key ID.

        Returns:
            The access key ID if available, None otherwise
        """
        return self._access_key_id

    @property
    def secret_access_key(self) -> Optional[str]:
        """Get the secret access key.

        Returns:
            The secret access key if available, None otherwise
        """
        return self._secret_access_key

    def is_available(self) -> bool:
        """Check if both credentials are available.

        Returns:
            True if both access_key_id and secret_access_key are set, False otherwise
        """
        return self._access_key_id is not None and self._secret_access_key is not None

    def require(self) -> None:
        """Require that credentials are available, raising an error if not.

        Raises:
            GreenNodeConfigurationError: If credentials are not available

        Example:
            >>> creds = IAMCredentials()
            >>> creds.require()  # Raises if credentials not available
        """
        if not self.is_available():
            raise GreenNodeConfigurationError(
                "IAM credentials are required but not available. "
                "Please provide access_key_id and secret_access_key via constructor, "
                "environment variables (GREENNODE_CLIENT_ID, GREENNODE_CLIENT_SECRET), "
                "or config file (.greennode.json)."
            )

    @staticmethod
    def _load_config_file() -> Optional[dict]:
        """Load credentials from .greennode.json config file.

        Returns:
            Dictionary with access_key_id and secret_access_key if file exists and is valid, None otherwise
        """
        config_path = Path(".greennode.json")
        if not config_path.exists():
            return None

        try:
            with open(config_path, "r", encoding="utf-8") as file:
                config = json.load(file)
                if isinstance(config, dict):
                    return config
        except (json.JSONDecodeError, OSError):
            # Silently ignore config file errors
            pass

        return None

