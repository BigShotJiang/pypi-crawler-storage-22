"""Pydantic models for GreenNode AgentBase Identity API.

All request and response models are defined here based on the OpenAPI specification.
"""

from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional

from pydantic import BaseModel, Field, field_validator


# Enums
class OAuth2ProviderStatus(str, Enum):
    """Status enum for OAuth2 providers."""

    ACTIVE = "ACTIVE"
    UPDATING = "UPDATING"
    REFRESHING_TOKEN = "REFRESHING_TOKEN"
    DELETING = "DELETING"
    DELETED = "DELETED"


class ApiKeyProviderStatus(str, Enum):
    """Status enum for API key providers."""

    ACTIVE = "ACTIVE"
    UPDATING = "UPDATING"
    DELETING = "DELETING"
    DELETED = "DELETED"


class DelegatedApiKeyProviderStatus(str, Enum):
    """Status enum for delegated API key providers."""

    ACTIVE = "ACTIVE"
    UPDATING = "UPDATING"
    DELETED = "DELETED"


class DelegatedApiKeyStatus(str, Enum):
    """Status enum for delegated API key operations."""

    IN_PROGRESS = "IN_PROGRESS"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"


# Agent Identity Models
class CreateAgentIdentityRequest(BaseModel):
    """Request model for creating an agent identity."""

    name: str = Field(..., min_length=3, max_length=50, pattern=r"^[a-zA-Z0-9_-]+$")
    description: Optional[str] = Field(None, min_length=0, max_length=500)
    allowed_return_urls: Optional[List[str]] = Field(
        None, min_length=0, max_items=10, alias="allowedReturnUrls"
    )

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class UpdateAgentIdentityRequest(BaseModel):
    """Request model for updating an agent identity."""

    description: Optional[str] = Field(None, min_length=0, max_length=500)
    allowed_return_urls: Optional[List[str]] = Field(
        None, min_length=0, max_items=10, alias="allowedReturnUrls"
    )

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class AgentIdentityResponse(BaseModel):
    """Response model for agent identity."""

    id: Optional[str] = None
    name: Optional[str] = None
    description: Optional[str] = None
    allowed_return_urls: Optional[List[str]] = Field(None, alias="allowedReturnUrls")
    created_at: Optional[datetime] = Field(None, alias="createdAt")
    updated_at: Optional[datetime] = Field(None, alias="updatedAt")

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


# OAuth2 Provider Models
class CreateOauth2ProviderRequest(BaseModel):
    """Request model for creating an OAuth2 provider."""

    name: str = Field(..., min_length=3, max_length=50, pattern=r"^[a-zA-Z0-9_-]+$")
    client_id: str = Field(..., min_length=1, max_length=100, alias="clientId")
    client_secret: str = Field(..., min_length=1, max_length=100, alias="clientSecret")
    authorization_url: str = Field(..., min_length=0, max_length=1000, alias="authorizationUrl")
    token_url: str = Field(..., min_length=0, max_length=1000, alias="tokenUrl")

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class UpdateOauth2ProviderRequest(BaseModel):
    """Request model for updating an OAuth2 provider."""

    client_id: str = Field(..., min_length=1, max_length=100, alias="clientId")
    client_secret: str = Field(..., min_length=1, max_length=100, alias="clientSecret")
    authorization_url: str = Field(..., min_length=0, max_length=1000, alias="authorizationUrl")
    token_url: str = Field(..., min_length=0, max_length=1000, alias="tokenUrl")

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class Oauth2ProviderResponse(BaseModel):
    """Response model for OAuth2 provider."""

    id: Optional[str] = None
    name: Optional[str] = None
    client_id: Optional[str] = Field(None, alias="clientId")
    authorization_url: Optional[str] = Field(None, alias="authorizationUrl")
    token_url: Optional[str] = Field(None, alias="tokenUrl")
    status: Optional[OAuth2ProviderStatus] = None
    callback_url: Optional[str] = Field(None, alias="callbackUrl")
    created_at: Optional[datetime] = Field(None, alias="createdAt")
    updated_at: Optional[datetime] = Field(None, alias="updatedAt")

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


# OAuth2 Token Models
class GetM2mTokenRequest(BaseModel):
    """Request model for getting M2M (machine-to-machine) OAuth2 token."""

    scopes: List[str] = Field(..., min_length=1)

    @field_validator("scopes")
    @classmethod
    def validate_scopes(cls, v: List[str]) -> List[str]:
        """Validate scopes."""
        for scope in v:
            if not (1 <= len(scope) <= 1000):
                raise ValueError("Each scope must be between 1 and 1000 characters")
        return v


class ThreeLoTokenRequest(BaseModel):
    """Request model for getting 3LO (3-legged OAuth) token."""

    agent_user_id: str = Field(..., min_length=1, alias="agentUserId")
    scopes: List[str] = Field(..., min_length=1)
    return_url: Optional[str] = Field(None, min_length=0, max_length=1000, alias="returnUrl")
    session_id: Optional[str] = Field(
        None, pattern=r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", alias="sessionId"
    )
    custom_parameters: Optional[Dict[str, str]] = Field(None, alias="customParameters")
    custom_state: Optional[str] = Field(None, min_length=1, max_length=100, alias="customState")
    force_authentication: Optional[bool] = Field(None, alias="forceAuthentication")

    @field_validator("scopes")
    @classmethod
    def validate_scopes(cls, v: List[str]) -> List[str]:
        """Validate scopes."""
        for scope in v:
            if not (1 <= len(scope) <= 1000):
                raise ValueError("Each scope must be between 1 and 1000 characters")
        return v

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class TokenResponse(BaseModel):
    """Response model for OAuth2 token."""

    access_token: Optional[str] = Field(None, alias="accessToken")
    token_type: Optional[str] = Field(None, alias="tokenType")
    authorization_url: Optional[str] = Field(None, alias="authorizationUrl")
    session_id: Optional[str] = Field(None, alias="sessionId")

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


# API Key Provider Models
class CreateApikeyProviderRequest(BaseModel):
    """Request model for creating an API key provider."""

    name: str = Field(..., min_length=3, max_length=50, pattern=r"^[a-zA-Z0-9_-]+$")
    apikey: str = Field(..., min_length=1, max_length=1000)

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class UpdateApikeyProviderRequest(BaseModel):
    """Request model for updating an API key provider."""

    apikey: str = Field(..., min_length=1, max_length=1000)


class ApikeyProviderResponse(BaseModel):
    """Response model for API key provider."""

    id: Optional[str] = None
    name: Optional[str] = None
    status: Optional[ApiKeyProviderStatus] = None
    created_at: Optional[datetime] = Field(None, alias="createdAt")
    updated_at: Optional[datetime] = Field(None, alias="updatedAt")

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class ApikeyResponse(BaseModel):
    """Response model for API key."""

    apikey: Optional[str] = None


# Delegated API Key Provider Models
class CreateDelegatedApiKeyProviderRequest(BaseModel):
    """Request model for creating a delegated API key provider."""

    name: str = Field(..., min_length=3, max_length=50, pattern=r"^[a-zA-Z0-9_-]+$")


class DelegatedApiKeyProviderResponse(BaseModel):
    """Response model for delegated API key provider."""

    id: Optional[str] = None
    name: Optional[str] = None
    status: Optional[DelegatedApiKeyProviderStatus] = None
    created_at: Optional[datetime] = Field(None, alias="createdAt")
    updated_at: Optional[datetime] = Field(None, alias="updatedAt")

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class GetDelegatedApiKeyRequest(BaseModel):
    """Request model for getting a delegated API key."""

    agent_user_id: str = Field(..., min_length=1, alias="agentUserId")
    return_url: str = Field(..., min_length=1, alias="returnUrl")
    custom_state: Optional[str] = Field(None, min_length=1, max_length=50, alias="customState")
    session_id: Optional[str] = Field(
        None, pattern=r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", alias="sessionId"
    )
    force_delegation: Optional[bool] = Field(None, alias="forceDelegation")

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class GetDelegatedApiKeyResponse(BaseModel):
    """Response model for delegated API key."""

    apikey: Optional[str] = None
    authorization_url: Optional[str] = Field(None, alias="authorizationUrl")
    session_id: Optional[str] = Field(None, alias="sessionId")
    status: Optional[DelegatedApiKeyStatus] = None

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class AuthorizeDelegatedApiKeyRequest(BaseModel):
    """Request model for authorizing a delegated API key."""

    apikey: str = Field(..., min_length=1)


class AuthorizeDelegatedApiKeyResponse(BaseModel):
    """Response model for authorizing a delegated API key."""

    message: Optional[str] = None
    redirect_url: Optional[str] = Field(None, alias="redirectUrl")
    success: Optional[bool] = None

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


# Pagination Models
class PagedResponseAgentIdentityResponse(BaseModel):
    """Paged response model for agent identities."""

    content: Optional[List[AgentIdentityResponse]] = None
    page: Optional[int] = None
    size: Optional[int] = None
    total_elements: Optional[int] = Field(None, alias="totalElements")
    total_pages: Optional[int] = Field(None, alias="totalPages")
    first: Optional[bool] = None
    last: Optional[bool] = None
    has_next: Optional[bool] = Field(None, alias="hasNext")
    has_previous: Optional[bool] = Field(None, alias="hasPrevious")

    class Config:
        """Pydantic configuration."""

        populate_by_name = True

