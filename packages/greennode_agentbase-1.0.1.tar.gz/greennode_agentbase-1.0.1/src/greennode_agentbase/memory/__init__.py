"""GreenNode AgentBase Memory Package.

This package contains the memory API client and models for GreenNode AgentBase:
- MemoryClient: Client for Memory API operations
- Memory models: Request and response models for memory operations
"""

from .models import (
    AutomaticMemoryRecordGeneration,
    AutomaticMemoryRecordGenerationEntity,
    ChatMessage,
    EventCreateRequest,
    EventEntity,
    ListResponseMemoryEntity,
    MemoryCreateRequest,
    MemoryEntity,
    MemoryRecord,
    MemoryRecordSearchRequest,
    SessionEntity,
)

# MemoryClient is conditionally imported to avoid circular dependencies
try:
    from .client import MemoryClient
    _client_available = True
except ImportError:
    _client_available = False

__all__ = [
    "AutomaticMemoryRecordGeneration",
    "AutomaticMemoryRecordGenerationEntity",
    "ChatMessage",
    "EventCreateRequest",
    "EventEntity",
    "ListResponseMemoryEntity",
    "MemoryCreateRequest",
    "MemoryEntity",
    "MemoryRecord",
    "MemoryRecordSearchRequest",
    "SessionEntity",
]

if _client_available:
    __all__.append("MemoryClient")
