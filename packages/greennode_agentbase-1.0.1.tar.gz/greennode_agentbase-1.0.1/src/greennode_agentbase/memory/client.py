"""Memory client for GreenNode AgentBase Memory SDK.

Provides MemoryClient for interacting with the Memory API, with abstract HTTP client
interface for testability and flexibility.
"""

import logging

from ..core import AuthenticatedAPIClient
from ..core.logging import configure_logger

logger = logging.getLogger("greennode_agentbase.memory")
configure_logger(logger)


class MemoryClient(AuthenticatedAPIClient):
    """High-level client for GreenNode AgentBase Memory API.

    This client provides methods for interacting with the Memory API, including
    memory management, memory records, sessions, and events.

    All API methods automatically authenticate using IAM credentials. IAM credentials
    can be provided via:
    - Constructor parameter
    - Environment variables (GREENNODE_CLIENT_ID, GREENNODE_CLIENT_SECRET)
    - Config file (.greennode.json in current directory)

    Args:
        base_url: Base URL for the Memory API (default: from spec)
        http_client: Optional HTTP client implementation (default: HttpxClient)
        iam_credentials: Optional IAM credentials for authentication. If not provided,
            will attempt to load from environment variables or config file.
        access_token: Optional OAuth2 access token for API authentication (backward
            compatibility). If IAM credentials are available, they will be preferred.

    Example:
        >>> # Using IAM credentials from environment variables
        >>> client = MemoryClient()
        >>> memories = await client.list_async(page=1, size=10)
        >>> 
        >>> # Using IAM credentials explicitly
        >>> from greennode_agentbase.identity import IAMCredentials
        >>> creds = IAMCredentials(access_key_id="key", secret_access_key="secret")
        >>> client = MemoryClient(iam_credentials=creds)
        >>> memory = await client.create_async(
        ...     request=MemoryCreateRequest(name="test", description="test")
        ... )
    """

    SERVICE_NAME = "memory"
