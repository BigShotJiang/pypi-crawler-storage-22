"""Pydantic models for GreenNode AgentBase Memory API.

All request and response models are defined here based on the OpenAPI specification.
"""

from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field


class AutomaticMemoryRecordGeneration(BaseModel):
    """Model for automatic memory record generation configuration."""

    enabled: Optional[bool] = None
    namespace_template: Optional[str] = Field(None, alias="namespaceTemplate")

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class AutomaticMemoryRecordGenerationEntity(BaseModel):
    """Entity model for automatic memory record generation configuration."""

    enabled: Optional[bool] = None
    namespace_template: Optional[str] = Field(None, alias="namespaceTemplate")

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class MemoryCreateRequest(BaseModel):
    """Request model for creating a memory."""

    name: str = Field(..., min_length=1)
    description: str = Field(...)
    event_expiry_duration: Optional[int] = Field(None, alias="eventExpiryDuration")
    automatic_memory_record_generation: Optional[AutomaticMemoryRecordGeneration] = Field(
        None, alias="automaticMemoryRecordGeneration"
    )

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class MemoryEntity(BaseModel):
    """Response model for memory entity."""

    id: Optional[str] = None
    name: Optional[str] = None
    description: Optional[str] = None
    automatic_memory_record_generation: Optional[AutomaticMemoryRecordGenerationEntity] = Field(
        None, alias="automaticMemoryRecordGeneration"
    )
    portal_user_id: Optional[int] = Field(None, alias="portalUserId")
    status: Optional[str] = None
    created_at: Optional[datetime] = Field(None, alias="createdAt")
    updated_at: Optional[datetime] = Field(None, alias="updatedAt")

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class ListResponseMemoryEntity(BaseModel):
    """Response model for listing memories."""

    list_data: Optional[List[MemoryEntity]] = Field(None, alias="listData")
    page: Optional[int] = None
    page_size: Optional[int] = Field(None, alias="pageSize")
    total_page: Optional[int] = Field(None, alias="totalPage")
    total_item: Optional[int] = Field(None, alias="totalItem")

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class MemoryRecordSearchRequest(BaseModel):
    """Request model for searching memory records."""

    query: str = Field(..., min_length=1)

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class MemoryRecord(BaseModel):
    """Response model for memory record."""

    id: Optional[str] = None
    memory: Optional[str] = None
    score: Optional[float] = None
    created_at: Optional[datetime] = Field(None, alias="created_at")
    updated_at: Optional[datetime] = Field(None, alias="updated_at")

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class ChatMessage(BaseModel):
    """Model for chat message."""

    role: Optional[str] = None
    content: Optional[str] = None

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class EventCreateRequest(BaseModel):
    """Request model for creating an event."""

    payload: Optional[ChatMessage] = None
    event_timestamp: str = Field(..., min_length=1, alias="eventTimestamp")

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class EventEntity(BaseModel):
    """Response model for event entity."""

    id: Optional[str] = None
    actor_id: Optional[str] = Field(None, alias="actorId")
    session_id: Optional[str] = Field(None, alias="sessionId")
    role: Optional[str] = None
    content: Optional[str] = None
    event_timestamp: Optional[datetime] = Field(None, alias="eventTimestamp")

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class SessionEntity(BaseModel):
    """Response model for session entity."""

    memory_id: Optional[str] = Field(None, alias="memoryId")
    actor_id: Optional[str] = Field(None, alias="actorId")
    session_id: Optional[str] = Field(None, alias="sessionId")
    last_processed_event_timestamp: Optional[datetime] = Field(None, alias="lastProcessedEventTimestamp")
    portal_user_id: Optional[int] = Field(None, alias="portalUserId")
    status: Optional[str] = None

    class Config:
        """Pydantic configuration."""

        populate_by_name = True
