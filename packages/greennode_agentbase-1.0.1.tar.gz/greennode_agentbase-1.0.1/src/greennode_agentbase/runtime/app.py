"""GreenNode AgentBase base implementation.

Provides a Starlette-based web server that wraps user functions as HTTP endpoints.
"""

import asyncio
import contextvars
import inspect
import json
import logging
import threading
import time
import uuid
from collections import deque
from collections.abc import Sequence
from typing import Any, Callable, Dict, Optional

from starlette.applications import Starlette
from starlette.middleware import Middleware
from starlette.responses import JSONResponse, Response, StreamingResponse
from starlette.routing import Route
from starlette.types import Lifespan

from ..core.logging import configure_logger, set_debug_mode
from ..exceptions import (
    GreenNodeAgentBaseError,
    GreenNodeConfigurationError,
    GreenNodeRequestError,
    GreenNodeRuntimeError,
    GreenNodeValidationError,
)
from .context import GreenNodeAgentBaseContext, RequestContext
from .models import (
    ACCESS_TOKEN_HEADER,
    AUTHORIZATION_HEADER,
    CUSTOM_HEADER_PREFIX,
    OAUTH2_CALLBACK_URL_HEADER,
    USER_ID_HEADER,
    REQUEST_ID_HEADER,
    SESSION_HEADER,
    TASK_ACTION_CLEAR_FORCED_STATUS,
    TASK_ACTION_FORCE_BUSY,
    TASK_ACTION_FORCE_HEALTHY,
    TASK_ACTION_JOB_STATUS,
    TASK_ACTION_PING_STATUS,
    PingStatus,
)
from .utils import convert_complex_objects, is_docker_running


class GreenNodeAgentBaseApp(Starlette):
    """GreenNode AgentBase application class that extends Starlette for AI agent deployment.

    This class provides a web server framework for deploying AI agents with support for:
    - HTTP endpoint handling (/invocations, /health)
    - Async task tracking
    - Health status monitoring
    - Request context management
    - Streaming responses
    - Unified error handling

    Example:
        >>> app = GreenNodeAgentBaseApp()
        >>> @app.entrypoint
        ... def my_handler(request):
        ...     return {"result": "success"}
        >>> app.run(port=8080)
    """

    def __init__(
        self,
        debug: bool = False,
        lifespan: Optional[Lifespan] = None,
        middleware: Sequence[Middleware] | None = None,
    ) -> None:
        """Initialize GreenNode AgentBase application.

        Args:
            debug: Enable debug actions for task management (default: False)
            lifespan: Optional lifespan context manager for startup/shutdown
            middleware: Optional sequence of Starlette Middleware objects

        Raises:
            GreenNodeConfigurationError: If initialization fails
        """
        try:
            self.handlers: Dict[str, Callable] = {}
            self._ping_handler: Optional[Callable] = None
            self._active_tasks: Dict[int, Dict[str, Any]] = {}
            self._task_counter_lock: threading.Lock = threading.Lock()
            self._forced_ping_status: Optional[PingStatus] = None
            self._last_status_update_time: float = time.time()
            self._port: int = 8080  # Default port, can be updated via run()

            routes = [
                Route("/invocations", self._handle_invocation, methods=["POST"]),
                Route("/health", self._handle_ping, methods=["GET"]),
            ]
            super().__init__(routes=routes, lifespan=lifespan, middleware=middleware)
            self.debug = debug  # Set after super().__init__ to avoid override

            # Set debug mode in context for global access
            set_debug_mode(self.debug)

            self.logger = logging.getLogger("greennode_agentbase.app")
            configure_logger(self.logger)

            # Display configuration checklist
            self._check_and_display_config()
        except Exception as e:
            from ..exceptions import GreenNodeConfigurationError

            raise GreenNodeConfigurationError(
                "Failed to initialize GreenNode AgentBase application",
                details={"debug": debug},
                cause=e,
            ) from e

    def _check_and_display_config(self) -> None:
        """Check and display basic configuration status using rich visualization.

        Displays a checklist of basic configuration items (IAM credentials and workload identity).
        Only displays if not in runtime environment and rich is available.
        """
        import os
        from pathlib import Path

        try:
            from ..identity.config import get_config_value
        except ImportError:
            return

        # Skip display in runtime environment
        if get_config_value("GREENNODE_RUNTIME"):
            return

        # Try to import rich, gracefully skip if not available
        try:
            from rich.console import Console
            from rich.panel import Panel
        except ImportError:
            self.logger.debug("rich package not available, skipping configuration checklist display")
            return

        console = Console()

        # Check basic configurations
        client_id = get_config_value("GREENNODE_CLIENT_ID")
        client_secret = get_config_value("GREENNODE_CLIENT_SECRET")
        access_control_name = get_config_value("GREENNODE_ACCESS_CONTROL_NAME")

        # Build basic configuration panel content
        basic_lines = []
        basic_lines.append(self._format_config_item("GREENNODE_CLIENT_ID", client_id is not None, required=True))
        basic_lines.append(self._format_config_item("GREENNODE_CLIENT_SECRET", client_secret is not None, required=True))
        basic_lines.append(self._format_config_item("GREENNODE_ACCESS_CONTROL_NAME", access_control_name is not None, required=False))

        basic_panel = Panel(
            "\n".join(basic_lines),
            title="Basic Configuration",
            border_style="blue",
        )

        # Display basic configuration panel
        console.print(basic_panel)

    def _check_and_display_deploy_config(self) -> tuple[bool, dict[str, bool]]:
        """Check and display deployment configuration status.

        Displays a checklist of deployment-specific configuration items using rich visualization.
        Returns whether all required conditions are met and a status dictionary.

        Returns:
            Tuple of (all_required_met: bool, status_dict: dict) where status_dict contains
            the presence status of each configuration item.
        """
        import os
        from pathlib import Path

        try:
            from ..identity.config import get_config_value
        except ImportError:
            return self._check_deploy_config_status()

        # Try to import rich, gracefully skip if not available
        try:
            from rich.console import Console
            from rich.panel import Panel
        except ImportError:
            self.logger.debug("rich package not available, skipping deployment configuration checklist display")
            # Still check and return status even without rich
            return self._check_deploy_config_status()

        console = Console()

        # Check deployment configurations
        registry_url = get_config_value("GREENNODE_REGISTRY_URL")
        registry_username = get_config_value("GREENNODE_REGISTRY_USERNAME")
        registry_password = get_config_value("GREENNODE_REGISTRY_PASSWORD")
        requirements_exists = Path("requirements.txt").exists()
        dockerfile_exists = Path("Dockerfile").exists()
        docker_running = is_docker_running()

        # Build deployment configuration panel content
        deploy_lines = []
        deploy_lines.append(self._format_config_item("GREENNODE_REGISTRY_URL", registry_url is not None, required=True))
        deploy_lines.append(self._format_config_item("GREENNODE_REGISTRY_USERNAME", registry_username is not None, required=True))
        deploy_lines.append(self._format_config_item("GREENNODE_REGISTRY_PASSWORD", registry_password is not None, required=True))
        deploy_lines.append(self._format_config_item("requirements.txt", requirements_exists, required=True, is_file=True))
        deploy_lines.append(self._format_config_item("Dockerfile", dockerfile_exists, required=True, is_file=True))
        deploy_lines.append(self._format_config_item("Docker", docker_running, required=True))

        deploy_panel = Panel(
            "\n".join(deploy_lines),
            title="Deployment Configuration",
            border_style="yellow",
        )

        # Display deployment configuration panel
        console.print(deploy_panel)

        # Check if all required conditions are met
        all_required_met = (
            registry_url is not None
            and registry_username is not None
            and registry_password is not None
            and requirements_exists
            and dockerfile_exists
            and docker_running
        )

        status_dict = {
            "GREENNODE_REGISTRY_URL": registry_url is not None,
            "GREENNODE_REGISTRY_USERNAME": registry_username is not None,
            "GREENNODE_REGISTRY_PASSWORD": registry_password is not None,
            "requirements.txt": requirements_exists,
            "Dockerfile": dockerfile_exists,
            "Docker": docker_running,
        }

        return all_required_met, status_dict

    def _check_deploy_config_status(self) -> tuple[bool, dict[str, bool]]:
        """Check deployment configuration status without displaying.

        Returns:
            Tuple of (all_required_met: bool, status_dict: dict)
        """
        import os
        from pathlib import Path

        try:
            from ..identity.config import get_config_value
        except ImportError:
            registry_url = os.environ.get("GREENNODE_REGISTRY_URL")
            registry_username = os.environ.get("GREENNODE_REGISTRY_USERNAME")
            registry_password = os.environ.get("GREENNODE_REGISTRY_PASSWORD")
        else:
            registry_url = get_config_value("GREENNODE_REGISTRY_URL")
            registry_username = get_config_value("GREENNODE_REGISTRY_USERNAME")
            registry_password = get_config_value("GREENNODE_REGISTRY_PASSWORD")
        requirements_exists = Path("requirements.txt").exists()
        dockerfile_exists = Path("Dockerfile").exists()
        docker_running = is_docker_running()

        all_required_met = (
            registry_url is not None
            and registry_username is not None
            and registry_password is not None
            and requirements_exists
            and dockerfile_exists
            and docker_running
        )

        status_dict = {
            "GREENNODE_REGISTRY_URL": registry_url is not None,
            "GREENNODE_REGISTRY_USERNAME": registry_username is not None,
            "GREENNODE_REGISTRY_PASSWORD": registry_password is not None,
            "requirements.txt": requirements_exists,
            "Dockerfile": dockerfile_exists,
            "Docker": docker_running,
        }

        return all_required_met, status_dict

    def _format_config_item(self, name: str, is_present: bool, required: bool = True, is_file: bool = False) -> str:
        """Format a configuration item for display.

        Args:
            name: Configuration item name
            is_present: Whether the configuration is present
            required: Whether the configuration is required
            is_file: Whether this is a file check (not an env var)

        Returns:
            Formatted string with checkmark and color coding using rich markup
        """
        if is_present:
            if required:
                checkmark = "[green]✓[/green]"
            else:
                checkmark = "[dim green]○[/dim green]"
        else:
            if required:
                checkmark = "[red]✗[/red]"
            else:
                checkmark = "[dim]○[/dim]"

        if not required:
            suffix = " [dim](optional)[/dim]"
        else:
            suffix = ""

        return f"{checkmark} {name}{suffix}"

    def _secure_display_value(self, value: str) -> str:
        """Display a secure value showing only first 10 characters.

        Args:
            value: The value to display securely

        Returns:
            Secure display string with first 10 chars visible, rest as asterisks
        """
        if not value or len(value) <= 10:
            return "*" * len(value) if value else "(empty)"
        return value[:10] + "*" * (len(value) - 10)

    def entrypoint(self, func: Callable) -> Callable:
        """Decorator to register a function as the main entrypoint.

        Args:
            func: The function to register as entrypoint

        Returns:
            The decorated function with added run method

        Example:
            >>> app = GreenNodeAgentBaseApp()
            >>> @app.entrypoint
            ... def handler(request):
            ...     return {"result": "success"}
        """
        self.handlers["main"] = func
        func.run = lambda port=8080, host=None: self.run(port, host)  # type: ignore[attr-defined]
        return func

    def ping(self, func: Callable) -> Callable:
        """Decorator to register a custom ping status handler.

        Args:
            func: The function to register as ping status handler

        Returns:
            The decorated function

        Example:
            >>> app = GreenNodeAgentBaseApp()
            >>> @app.ping
            ... def custom_ping():
            ...     return PingStatus.HEALTHY
        """
        self._ping_handler = func
        return func

    def async_task(self, func: Callable) -> Callable:
        """Decorator to track async tasks for ping status.

        When a function is decorated with @async_task, it will:
        - Set ping status to HEALTHY_BUSY while running
        - Revert to HEALTHY when complete

        Args:
            func: The async function to decorate

        Returns:
            Wrapped async function with task tracking

        Raises:
            GreenNodeValidationError: If func is not an async function

        Example:
            >>> app = GreenNodeAgentBaseApp()
            >>> @app.async_task
            ... async def background_work():
            ...     await asyncio.sleep(1)
        """
        if not asyncio.iscoroutinefunction(func):
            raise GreenNodeValidationError("@async_task can only be applied to async functions")

        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            task_id = self.add_async_task(func.__name__)

            try:
                self.logger.debug("Starting async task: %s", func.__name__)
                start_time = time.time()
                result = await func(*args, **kwargs)
                duration = time.time() - start_time
                self.logger.info("Async task completed: %s (%.3fs)", func.__name__, duration)
                return result
            except GreenNodeAgentBaseError:
                duration = time.time() - start_time
                self.logger.exception("Async task failed: %s (%.3fs)", func.__name__, duration)
                raise
            except Exception as e:
                duration = time.time() - start_time
                self.logger.exception("Async task failed: %s (%.3fs)", func.__name__, duration)
                raise GreenNodeRuntimeError(
                    f"Async task '{func.__name__}' failed",
                    details={"task_name": func.__name__, "duration": duration},
                    cause=e,
                ) from e
            finally:
                self.complete_async_task(task_id)

        wrapper.__name__ = func.__name__
        return wrapper

    def get_current_ping_status(self) -> PingStatus:
        """Get current ping status (forced > custom > automatic).

        Returns:
            Current ping status based on forced status, custom handler, or active tasks

        Example:
            >>> app = GreenNodeAgentBaseApp()
            >>> status = app.get_current_ping_status()
            >>> print(status)
            PingStatus.HEALTHY
        """
        current_status: Optional[PingStatus] = None

        if self._forced_ping_status is not None:
            current_status = self._forced_ping_status
        elif self._ping_handler:
            try:
                result = self._ping_handler()
                if isinstance(result, str):
                    current_status = PingStatus(result)
                else:
                    current_status = result
            except Exception as e:
                self.logger.warning(
                    "Custom ping handler failed, falling back to automatic: %s: %s", type(e).__name__, e
                )

        if current_status is None:
            current_status = PingStatus.HEALTHY_BUSY if self._active_tasks else PingStatus.HEALTHY
        if not hasattr(self, "_last_known_status") or self._last_known_status != current_status:
            self._last_known_status = current_status
            self._last_status_update_time = time.time()

        return current_status

    def force_ping_status(self, status: PingStatus) -> None:
        """Force ping status to a specific value.

        Args:
            status: The ping status to force

        Example:
            >>> app = GreenNodeAgentBaseApp()
            >>> app.force_ping_status(PingStatus.HEALTHY_BUSY)
        """
        self._forced_ping_status = status

    def clear_forced_ping_status(self) -> None:
        """Clear forced status and resume automatic status detection.

        Example:
            >>> app = GreenNodeAgentBaseApp()
            >>> app.clear_forced_ping_status()
        """
        self._forced_ping_status = None

    def get_async_task_info(self) -> Dict[str, Any]:
        """Get info about running async tasks.

        Returns:
            Dictionary containing active task count and running job details

        Example:
            >>> app = GreenNodeAgentBaseApp()
            >>> info = app.get_async_task_info()
            >>> print(info)
            {'active_count': 0, 'running_jobs': []}
        """
        running_jobs = []
        for task_info in self._active_tasks.values():
            try:
                running_jobs.append(
                    {"name": task_info.get("name", "unknown"), "duration": time.time() - task_info.get("start_time", time.time())}
                )
            except Exception as e:
                self.logger.warning("Caught exception while processing task info, continuing...: %s", e)
                continue

        return {"active_count": len(self._active_tasks), "running_jobs": running_jobs}

    def add_async_task(self, name: str, metadata: Optional[Dict[str, Any]] = None) -> int:
        """Register an async task for interactive health tracking.

        This method provides granular control over async task lifecycle,
        allowing developers to interactively start tracking tasks for health monitoring.
        Use this when you need precise control over when tasks begin and end.

        Args:
            name: Human-readable task name for monitoring
            metadata: Optional additional task metadata

        Returns:
            Task ID for tracking and completion

        Example:
            >>> app = GreenNodeAgentBaseApp()
            >>> task_id = app.add_async_task("file_processing", {"file": "data.csv"})
            >>> # ... do background work ...
            >>> app.complete_async_task(task_id)
        """
        with self._task_counter_lock:
            task_id = hash(str(uuid.uuid4()))  # Generate truly unique hash-based ID

            # Register task start with same structure as @async_task decorator
            task_info: Dict[str, Any] = {"name": name, "start_time": time.time()}
            if metadata:
                task_info["metadata"] = metadata

            self._active_tasks[task_id] = task_info

        self.logger.info("Async task started: %s (ID: %s)", name, task_id)
        return task_id

    def complete_async_task(self, task_id: int) -> bool:
        """Mark an async task as complete for interactive health tracking.

        This method provides granular control over async task lifecycle,
        allowing developers to interactively complete tasks for health monitoring.
        Call this when your background work finishes.

        Args:
            task_id: Task ID returned from add_async_task

        Returns:
            True if task was found and completed, False otherwise

        Example:
            >>> app = GreenNodeAgentBaseApp()
            >>> task_id = app.add_async_task("file_processing")
            >>> # ... do background work ...
            >>> completed = app.complete_async_task(task_id)
        """
        with self._task_counter_lock:
            task_info = self._active_tasks.pop(task_id, None)
            if task_info:
                task_name = task_info.get("name", "unknown")
                duration = time.time() - task_info.get("start_time", time.time())

                self.logger.info("Async task completed: %s (ID: %s, Duration: %.2fs)", task_name, task_id, duration)
                return True
            else:
                self.logger.warning("Attempted to complete unknown task ID: %s", task_id)
                return False

    def _build_request_context(self, request: Any) -> RequestContext:
        """Build request context and setup all context variables.

        Args:
            request: Starlette request object

        Returns:
            RequestContext with extracted metadata

        Raises:
            GreenNodeRequestError: If context building fails
        """
        try:
            headers = request.headers
            request_id = headers.get(REQUEST_ID_HEADER)
            if not request_id:
                request_id = str(uuid.uuid4())

            session_id = headers.get(SESSION_HEADER)
            GreenNodeAgentBaseContext.set_request_context(request_id, session_id)

            agent_identity_token = headers.get(ACCESS_TOKEN_HEADER)
            if agent_identity_token:
                GreenNodeAgentBaseContext.set_workload_access_token(agent_identity_token)

            user_id = headers.get(USER_ID_HEADER)
            if user_id:
                GreenNodeAgentBaseContext.set_user_id(user_id)

            oauth2_callback_url = headers.get(OAUTH2_CALLBACK_URL_HEADER)
            if oauth2_callback_url:
                GreenNodeAgentBaseContext.set_oauth2_callback_url(oauth2_callback_url)

            # Collect relevant request headers (Authorization + Custom headers)
            request_headers: Dict[str, str] = {}

            # Add Authorization header if present
            authorization_header = headers.get(AUTHORIZATION_HEADER)
            if authorization_header is not None:
                request_headers[AUTHORIZATION_HEADER] = authorization_header

            # Add custom headers with the specified prefix
            for header_name, header_value in headers.items():
                if header_name.lower().startswith(CUSTOM_HEADER_PREFIX.lower()):
                    request_headers[header_name] = header_value

            # Set in context if any headers were found
            if request_headers:
                GreenNodeAgentBaseContext.set_request_headers(request_headers)

            # Get the headers from context to pass to RequestContext
            req_headers = GreenNodeAgentBaseContext.get_request_headers()

            return RequestContext(
                session_id=session_id,
                request_headers=req_headers,
                request=request,  # Pass through the Starlette request object
            )
        except Exception as e:
            self.logger.warning("Failed to build request context: %s: %s", type(e).__name__, e)
            request_id = str(uuid.uuid4())
            GreenNodeAgentBaseContext.set_request_context(request_id, None)
            # Return a basic context even if building fails
            return RequestContext(session_id=None, request_headers=None, request=request)

    def _takes_context(self, handler: Callable) -> bool:
        """Check if handler function takes a context parameter.

        Args:
            handler: The handler function to check

        Returns:
            True if handler takes context as second parameter, False otherwise
        """
        try:
            params = list(inspect.signature(handler).parameters.keys())
            return len(params) >= 2 and params[1] == "context"
        except Exception:
            return False

    async def _handle_invocation(self, request: Any) -> Response:
        """Handle invocation requests to the /invocations endpoint.

        Args:
            request: Starlette request object

        Returns:
            Response with handler result or error
        """
        request_context = self._build_request_context(request)

        start_time = time.time()

        try:
            payload = await request.json()
            self.logger.debug("Processing invocation request")

            if self.debug:
                task_response = self._handle_task_action(payload)
                if task_response:
                    duration = time.time() - start_time
                    self.logger.info("Debug action completed (%.3fs)", duration)
                    return task_response

            handler = self.handlers.get("main")
            if not handler:
                self.logger.error("No entrypoint defined")
                error = GreenNodeRuntimeError("No entrypoint defined")
                return JSONResponse({"error": error.message, "error_type": type(error).__name__}, status_code=500)

            takes_context = self._takes_context(handler)

            handler_name = handler.__name__ if hasattr(handler, "__name__") else "unknown"
            self.logger.debug("Invoking handler: %s", handler_name)
            result = await self._invoke_handler(handler, request_context, takes_context, payload)

            duration = time.time() - start_time
            if inspect.isgenerator(result):
                self.logger.info("Returning streaming response (generator) (%.3fs)", duration)
                return StreamingResponse(self._sync_stream_with_error_handling(result), media_type="text/event-stream")
            elif inspect.isasyncgen(result):
                self.logger.info("Returning streaming response (async generator) (%.3fs)", duration)
                return StreamingResponse(self._stream_with_error_handling(result), media_type="text/event-stream")

            self.logger.info("Invocation completed successfully (%.3fs)", duration)
            # Use safe serialization for consistency with streaming paths
            safe_json_string = self._safe_serialize_to_json_string(result)
            return Response(safe_json_string, media_type="application/json")

        except json.JSONDecodeError as e:
            duration = time.time() - start_time
            self.logger.warning("Invalid JSON in request (%.3fs): %s", duration, e)
            error = GreenNodeRequestError(
                "Invalid JSON in request",
                status_code=400,
                details={"error": str(e)},
                cause=e,
            )
            return JSONResponse(
                {"error": error.message, "error_type": type(error).__name__, "details": error.details},
                status_code=400,
            )
        except GreenNodeAgentBaseError as e:
            duration = time.time() - start_time
            self.logger.exception("Invocation failed (%.3fs)", duration)
            status_code = getattr(e, "status_code", 500)
            return JSONResponse(
                {"error": e.message, "error_type": type(e).__name__, "details": e.details},
                status_code=status_code,
            )
        except Exception as e:
            duration = time.time() - start_time
            self.logger.exception("Invocation failed (%.3fs)", duration)
            error = GreenNodeRuntimeError(
                "Invocation handler failed",
                details={"duration": duration},
                cause=e,
            )
            return JSONResponse(
                {"error": error.message, "error_type": type(error).__name__, "details": error.details},
                status_code=500,
            )

    def _handle_ping(self, request: Any) -> JSONResponse:
        """Handle ping requests to the /health endpoint.

        Args:
            request: Starlette request object

        Returns:
            JSONResponse with ping status
        """
        try:
            status = self.get_current_ping_status()
            self.logger.debug("Ping request - status: %s", status.value)
            return JSONResponse({"status": status.value, "time_of_last_update": int(self._last_status_update_time)})
        except Exception as e:
            self.logger.exception("Ping endpoint failed")
            error = GreenNodeRuntimeError(
                "Ping endpoint failed",
                cause=e,
            )
            return JSONResponse(
                {"status": PingStatus.HEALTHY.value, "time_of_last_update": int(time.time()), "error": error.message},
                status_code=500,
            )

    def run(self, port: int = 8080, host: Optional[str] = None, **kwargs: Any) -> None:
        """Start the GreenNode AgentBase server.

        Args:
            port: Port to serve on, defaults to 8080
            host: Host to bind to, auto-detected if None
            **kwargs: Additional arguments passed to uvicorn.run()

        Raises:
            GreenNodeRuntimeError: If server startup fails

        Example:
            >>> app = GreenNodeAgentBaseApp()
            >>> app.run(port=8080)
        """
        import os

        import uvicorn

        if host is None:
            if os.path.exists("/.dockerenv"):
                host = "0.0.0.0"  # nosec B104 - Docker needs this to expose the port
            else:
                try:
                    from ..identity.config import get_config_value
                    if get_config_value("DOCKER_CONTAINER"):
                        host = "0.0.0.0"  # nosec B104
                    else:
                        host = "127.0.0.1"
                except ImportError:
                    if os.environ.get("DOCKER_CONTAINER"):
                        host = "0.0.0.0"  # nosec B104
                    else:
                        host = "127.0.0.1"

        # Store port for deployment use
        self._port = port

        # Set default uvicorn parameters, allow kwargs to override
        uvicorn_params = {
            "host": host,
            "port": port,
            "access_log": self.debug,
            "log_level": "info" if self.debug else "warning",
        }
        uvicorn_params.update(kwargs)

        try:
            uvicorn.run(self, **uvicorn_params)
        except Exception as e:
            raise GreenNodeRuntimeError(
                "Failed to start GreenNode AgentBase server",
                details={"host": host, "port": port},
                cause=e,
            ) from e

    def _format_docker_log_chunk(self, chunk: Dict[str, Any]) -> Optional[str]:
        """Format a Docker API log chunk into a displayable string.

        Args:
            chunk: Docker API log chunk dictionary

        Returns:
            Formatted log line string, or None if chunk should be skipped
        """
        if "stream" in chunk:
            line = chunk["stream"].strip()
            return line if line else None
        elif "status" in chunk:
            status = chunk["status"]
            if "progress" in chunk:
                progress = chunk["progress"]
                return f"{status} {progress}"
            return status
        elif "error" in chunk:
            return f"ERROR: {chunk['error']}"
        elif "errorDetail" in chunk:
            error_detail = chunk["errorDetail"]
            message = error_detail.get("message", "Unknown error")
            return f"ERROR: {message}"
        return None

    async def _invoke_handler(self, handler: Callable, request_context: RequestContext, takes_context: bool, payload: Any) -> Any:
        """Invoke the handler function with appropriate arguments.

        Args:
            handler: The handler function to invoke
            request_context: Request context object
            takes_context: Whether handler accepts context parameter
            payload: Request payload

        Returns:
            Handler result

        Raises:
            GreenNodeRuntimeError: If handler invocation fails
        """
        try:
            args = (payload, request_context) if takes_context else (payload,)

            if asyncio.iscoroutinefunction(handler):
                return await handler(*args)
            else:
                loop = asyncio.get_event_loop()
                ctx = contextvars.copy_context()
                return await loop.run_in_executor(None, ctx.run, handler, *args)
        except GreenNodeAgentBaseError:
            handler_name = getattr(handler, "__name__", "unknown")
            self.logger.debug("Handler '%s' execution failed", handler_name)
            raise
        except Exception as e:
            handler_name = getattr(handler, "__name__", "unknown")
            self.logger.debug("Handler '%s' execution failed", handler_name)
            raise GreenNodeRuntimeError(
                f"Handler '{handler_name}' execution failed",
                details={"handler_name": handler_name, "takes_context": takes_context},
                cause=e,
            ) from e

    def _handle_task_action(self, payload: Dict[str, Any]) -> Optional[JSONResponse]:
        """Handle task management actions if present in payload.

        Args:
            payload: Request payload dictionary

        Returns:
            JSONResponse if action was handled, None otherwise

        Raises:
            GreenNodeRequestError: If action is invalid or fails
        """
        action = payload.get("_agent_base_app_action")
        if not action:
            return None

        self.logger.debug("Processing debug action: %s", action)

        try:
            actions = {
                TASK_ACTION_PING_STATUS: lambda: JSONResponse(
                    {
                        "status": self.get_current_ping_status().value,
                        "time_of_last_update": int(self._last_status_update_time),
                    }
                ),
                TASK_ACTION_JOB_STATUS: lambda: JSONResponse(self.get_async_task_info()),
                TASK_ACTION_FORCE_HEALTHY: lambda: (
                    self.force_ping_status(PingStatus.HEALTHY),
                    self.logger.info("Ping status forced to Healthy"),
                    JSONResponse({"forced_status": "Healthy"}),
                )[2],
                TASK_ACTION_FORCE_BUSY: lambda: (
                    self.force_ping_status(PingStatus.HEALTHY_BUSY),
                    self.logger.info("Ping status forced to HealthyBusy"),
                    JSONResponse({"forced_status": "HealthyBusy"}),
                )[2],
                TASK_ACTION_CLEAR_FORCED_STATUS: lambda: (
                    self.clear_forced_ping_status(),
                    self.logger.info("Forced ping status cleared"),
                    JSONResponse({"forced_status": "Cleared"}),
                )[2],
            }

            if action in actions:
                response = actions[action]()
                self.logger.debug("Debug action '%s' completed successfully", action)
                return response

            self.logger.warning("Unknown debug action requested: %s", action)
            raise GreenNodeRequestError(
                f"Unknown action: {action}",
                status_code=400,
                details={"action": action},
            )
        except GreenNodeAgentBaseError:
            raise
        except Exception as e:
            self.logger.exception("Debug action '%s' failed", action)
            raise GreenNodeRuntimeError(
                "Debug action failed",
                details={"action": action},
                cause=e,
            ) from e

    async def _stream_with_error_handling(self, generator: Any) -> Any:
        """Wrap async generator to handle errors and convert to SSE format.

        Args:
            generator: Async generator to wrap

        Yields:
            SSE-formatted bytes

        Raises:
            GreenNodeRuntimeError: If streaming fails
        """
        try:
            async for value in generator:
                yield self._convert_to_sse(value)
        except GreenNodeAgentBaseError:
            raise
        except Exception as e:
            self.logger.exception("Error in async streaming")
            error_event = {
                "error": str(e),
                "error_type": type(e).__name__,
                "message": "An error occurred during streaming",
            }
            yield self._convert_to_sse(error_event)
            raise GreenNodeRuntimeError(
                "Error in async streaming",
                cause=e,
            ) from e

    def _safe_serialize_to_json_string(self, obj: Any) -> str:
        """Safely serialize object directly to JSON string with progressive fallback handling.

        This method eliminates double JSON encoding by returning the JSON string directly,
        avoiding the test-then-encode pattern that leads to redundant json.dumps() calls.
        Used by both streaming and non-streaming responses for consistent behavior.

        Args:
            obj: Object to serialize

        Returns:
            JSON string representation of the object

        Raises:
            GreenNodeRuntimeError: If serialization fails completely

        Example:
            >>> app = GreenNodeAgentBaseApp()
            >>> result = app._safe_serialize_to_json_string({"key": "value"})
            >>> print(result)
            {"key": "value"}
        """
        try:
            # First attempt: direct JSON serialization with Unicode support
            return json.dumps(obj, ensure_ascii=False)
        except (TypeError, ValueError, UnicodeEncodeError):
            try:
                # Second attempt: convert to serializable dictionaries, then JSON encode
                converted_obj = convert_complex_objects(obj)
                return json.dumps(converted_obj, ensure_ascii=False)
            except Exception:
                try:
                    # Third attempt: convert to string, then JSON encode the string
                    return json.dumps(str(obj), ensure_ascii=False)
                except Exception as e:
                    # Final fallback: JSON encode error object with ASCII fallback
                    self.logger.warning("Failed to serialize object: %s: %s", type(e).__name__, e)
                    error_obj = {"error": "Serialization failed", "original_type": type(obj).__name__}
                    raise GreenNodeRuntimeError(
                        "Failed to serialize response object",
                        details={"object_type": type(obj).__name__},
                        cause=e,
                    ) from e

    def _convert_to_sse(self, obj: Any) -> bytes:
        """Convert object to Server-Sent Events format using safe serialization.

        Args:
            obj: Object to convert to SSE format

        Returns:
            SSE-formatted data ready for streaming
        """
        json_string = self._safe_serialize_to_json_string(obj)
        sse_data = f"data: {json_string}\n\n"
        return sse_data.encode("utf-8")

    def _sync_stream_with_error_handling(self, generator: Any) -> Any:
        """Wrap sync generator to handle errors and convert to SSE format.

        Args:
            generator: Sync generator to wrap

        Yields:
            SSE-formatted bytes

        Raises:
            GreenNodeRuntimeError: If streaming fails
        """
        try:
            for value in generator:
                yield self._convert_to_sse(value)
        except GreenNodeAgentBaseError:
            raise
        except Exception as e:
            self.logger.exception("Error in sync streaming")
            error_event = {
                "error": str(e),
                "error_type": type(e).__name__,
                "message": "An error occurred during streaming",
            }
            yield self._convert_to_sse(error_event)
            raise GreenNodeRuntimeError(
                "Error in sync streaming",
                cause=e,
            ) from e

