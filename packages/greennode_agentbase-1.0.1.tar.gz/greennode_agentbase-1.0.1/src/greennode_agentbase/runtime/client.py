"""Runtime client for GreenNode AgentBase Runtime SDK.

Provides RuntimeClient for interacting with the Runtime API, with abstract HTTP client
interface for testability and flexibility.
"""

import logging

from ..core import AuthenticatedAPIClient
from ..core.logging import configure_logger

logger = logging.getLogger("greennode_agentbase.runtime")
configure_logger(logger)


class RuntimeClient(AuthenticatedAPIClient):
    """High-level client for GreenNode AgentBase Runtime API.

    This client provides methods for interacting with the Runtime API, including
    runtime management, versioning, and endpoint management.

    All API methods automatically authenticate using IAM credentials with OAuth2
    client_credentials flow (basic auth). IAM credentials can be provided via:
    - Constructor parameter
    - Environment variables (GREENNODE_CLIENT_ID, GREENNODE_CLIENT_SECRET)
    - Config file (.greennode.json in current directory)

    Tokens are automatically cached and refreshed when expired to minimize
    authentication requests.

    Args:
        base_url: Base URL for the Runtime API (default: from spec)
        http_client: Optional HTTP client implementation (default: HttpxClient)
        iam_credentials: Optional IAM credentials for authentication. If not provided,
            will attempt to load from environment variables or config file.
        access_token: Optional OAuth2 access token for API authentication (backward
            compatibility). If IAM credentials are available, they will be preferred.

    Example:
        >>> # Using IAM credentials from environment variables
        >>> client = RuntimeClient()
        >>> runtime = await client.create_async(
        ...     request=AgentRuntimeCreateRequest(
        ...         name="my-runtime",
        ...         image_url="my-image",
        ...         flavor_id="flavor-id",
        ...         autoscaling=AgentRuntimeAutoscaling()
        ...     )
        ... )
        >>> 
        >>> # Using IAM credentials explicitly
        >>> from greennode_agentbase.identity import IAMCredentials
        >>> creds = IAMCredentials(access_key_id="key", secret_access_key="secret")
        >>> client = RuntimeClient(iam_credentials=creds)
    """

    SERVICE_NAME = "runtime"
