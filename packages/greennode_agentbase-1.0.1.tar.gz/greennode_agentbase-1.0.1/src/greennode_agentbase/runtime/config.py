"""Configuration utility for GreenNode AgentBase Runtime SDK.

Provides centralized configuration management for runtime deployment with support
for .greennode_runtime.json config file.
"""

import json
import logging
import os
from pathlib import Path
from typing import Any, Dict, Optional

from ..core.logging import configure_logger

logger = logging.getLogger("greennode_agentbase.runtime.config")
configure_logger(logger)

# Cache for config file contents to avoid repeated file reads
_config_cache: Optional[dict] = None
_config_file_path = Path(".greennode_runtime.json")


def _load_config_file() -> dict:
    """Load configuration from .greennode_runtime.json config file.

    Returns:
        Dictionary with config values if file exists and is valid, empty dict otherwise
    """
    global _config_cache

    # Return cached config if available
    if _config_cache is not None:
        return _config_cache

    if not _config_file_path.exists():
        _config_cache = {"env": {}, "runtime": {}}
        return _config_cache

    try:
        with open(_config_file_path, "r", encoding="utf-8") as file:
            config = json.load(file)
            if isinstance(config, dict):
                # Ensure required keys exist
                if "env" not in config:
                    config["env"] = {}
                if "runtime" not in config:
                    config["runtime"] = {}
                _config_cache = config
                return _config_cache
    except (json.JSONDecodeError, OSError) as e:
        logger.warning(f"Failed to load config file {_config_file_path}: {e}")
        _config_cache = {"env": {}, "runtime": {}}
        return _config_cache

    _config_cache = {"env": {}, "runtime": {}}
    return _config_cache


def save_config_file(config: dict) -> None:
    """Save configuration to .greennode_runtime.json config file.

    Args:
        config: Configuration dictionary to save
    """
    global _config_cache

    try:
        with open(_config_file_path, "w", encoding="utf-8") as file:
            json.dump(config, file, indent=2, ensure_ascii=False)
        _config_cache = config
        logger.debug(f"Saved config to {_config_file_path}")
    except OSError as e:
        logger.error(f"Failed to save config file {_config_file_path}: {e}")
        raise


def get_runtime_config_value(key: str, default: Optional[str] = None) -> Optional[str]:
    """Get configuration value from runtime config file.

    Priority: environment variable → config file → default

    Args:
        key: Configuration key name (e.g., "GREENNODE_CLIENT_ID")
        default: Default value to return if not found

    Returns:
        Configuration value if found, default if provided, None otherwise
    """
    # Priority 1: Environment variable
    env_value = os.getenv(key)
    if env_value is not None:
        return env_value

    # Priority 2: Config file
    config = _load_config_file()
    env_vars = config.get("env", {})
    if key in env_vars:
        return str(env_vars[key])

    # Priority 3: Default
    return default


def save_runtime_config_value(key: str, value: str) -> None:
    """Save configuration value to runtime config file.

    Args:
        key: Configuration key name
        value: Configuration value to save
    """
    config = _load_config_file()
    if "env" not in config:
        config["env"] = {}
    config["env"][key] = value
    save_config_file(config)


def get_runtime_env_vars() -> Dict[str, str]:
    """Get all environment variables from runtime config.

    Returns:
        Dictionary of environment variable key-value pairs
    """
    config = _load_config_file()
    return config.get("env", {}).copy()


def save_runtime_env_vars(env_vars: Dict[str, str]) -> None:
    """Save environment variables to runtime config.

    Preserves existing values and only adds missing required ones.

    Args:
        env_vars: Dictionary of environment variable key-value pairs
    """
    config = _load_config_file()
    existing_env = config.get("env", {})
    # Merge: preserve existing values, only add missing ones from env_vars
    merged_env = {**existing_env, **env_vars}
    config["env"] = merged_env
    save_config_file(config)


def ensure_runtime_config_exists() -> None:
    """Ensure .greennode_runtime.json exists with default structure.

    Creates the file if it doesn't exist. If it exists, preserves all existing values.
    """
    if not _config_file_path.exists():
        default_config = {"env": {}, "runtime": {}}
        save_config_file(default_config)
        logger.debug(f"Created default runtime config file: {_config_file_path}")
    else:
        # Load existing config to ensure structure is valid
        _load_config_file()


def get_runtime_config() -> Dict[str, Any]:
    """Get the full runtime config dictionary.

    Returns:
        Full runtime config dictionary
    """
    return _load_config_file().copy()
def get_runtime_config_key(key: str, default: Any = None) -> Any:
    """Get a value from the runtime config (not env vars).

    Args:
        key: Key path in runtime config (e.g., "runtime.flavorId" or just "flavorId")
        default: Default value if not found

    Returns:
        Config value or default
    """
    config = _load_config_file()
    if "." in key:
        # Handle nested keys like "runtime.flavorId"
        parts = key.split(".")
        value = config
        for part in parts:
            if isinstance(value, dict):
                value = value.get(part)
                if value is None:
                    return default
            else:
                return default
        return value
    else:
        # Check in runtime section first, then root
        return config.get("runtime", {}).get(key) or config.get(key, default)


def save_runtime_config_key(key: str, value: Any) -> None:
    """Save a value to the runtime config (not env vars).

    Args:
        key: Key path in runtime config (e.g., "runtime.flavorId" or just "flavorId")
        value: Value to save
    """
    config = _load_config_file()
    if "." in key:
        # Handle nested keys
        parts = key.split(".")
        current = config
        for i, part in enumerate(parts[:-1]):
            if part not in current:
                current[part] = {}
            current = current[part]
        current[parts[-1]] = value
    else:
        # Save to runtime section
        if "runtime" not in config:
            config["runtime"] = {}
        config["runtime"][key] = value
    save_config_file(config)
