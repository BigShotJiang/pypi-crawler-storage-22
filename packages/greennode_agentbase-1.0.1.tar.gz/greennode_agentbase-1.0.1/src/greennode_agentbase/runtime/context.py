"""Request context models for GreenNode AgentBase Server.

Contains metadata extracted from HTTP requests that handlers can optionally access.
"""

from contextvars import ContextVar
from typing import Any, Dict, Optional

from pydantic import BaseModel, Field


class RequestContext(BaseModel):
    """Request context containing metadata from HTTP requests.

    This model contains request-scoped information that can be accessed
    by handler functions, such as session ID, request headers, and the
    underlying request object.

    Args:
        session_id: Optional session identifier for the request
        user_id: Optional user identifier for the request
        request_headers: Optional dictionary of request headers
        request: Optional underlying Starlette request object

    Example:
        >>> context = RequestContext(
        ...     session_id="session-123",
        ...     user_id="user-123",
        ...     request_headers={"Authorization": "Bearer token"}
        ... )
        >>> print(context.session_id)
        session-123
    """

    session_id: Optional[str] = Field(None, description="Session identifier for the request")
    user_id: Optional[str] = Field(None, description="User identifier for the request")
    request_headers: Optional[Dict[str, str]] = Field(None, description="Request headers dictionary")
    request: Optional[Any] = Field(None, description="The underlying Starlette request object")

    class Config:
        """Pydantic configuration to allow non-serializable types like Starlette Request."""

        arbitrary_types_allowed = True


class GreenNodeAgentBaseContext:
    """Unified context manager for GreenNode AgentBase.

    This class provides thread-safe context variable management for request-scoped
    data such as request IDs, session IDs, access tokens, and request headers.
    All context variables are stored using Python's contextvars module, ensuring
    proper isolation across async tasks.

    Example:
        >>> GreenNodeAgentBaseContext.set_request_context("req-123", "session-456")
        >>> request_id = GreenNodeAgentBaseContext.get_request_id()
        >>> print(request_id)
        req-123
    """

    _workload_access_token: ContextVar[Optional[str]] = ContextVar("workload_access_token")
    _oauth2_callback_url: ContextVar[Optional[str]] = ContextVar("oauth2_callback_url")
    _user_id: ContextVar[Optional[str]] = ContextVar("user_id")
    _request_id: ContextVar[Optional[str]] = ContextVar("request_id")
    _session_id: ContextVar[Optional[str]] = ContextVar("session_id")
    _request_headers: ContextVar[Optional[Dict[str, str]]] = ContextVar("request_headers")

    @classmethod
    def set_workload_access_token(cls, token: str) -> None:
        """Set the workload access token in the context.

        Args:
            token: The access token to store in the context

        Example:
            >>> GreenNodeAgentBaseContext.set_workload_access_token("token-123")
        """
        cls._workload_access_token.set(token)

    @classmethod
    def get_workload_access_token(cls) -> Optional[str]:
        """Get the workload access token from the context.

        Returns:
            The access token if set, None otherwise

        Example:
            >>> token = GreenNodeAgentBaseContext.get_workload_access_token()
        """
        try:
            return cls._workload_access_token.get()
        except LookupError:
            return None

    @classmethod
    def set_oauth2_callback_url(cls, callback_url: str) -> None:
        """Set the OAuth2 callback URL in the context.

        Args:
            callback_url: The OAuth2 callback URL to store in the context

        Example:
            >>> GreenNodeAgentBaseContext.set_oauth2_callback_url("https://example.com/callback")
        """
        cls._oauth2_callback_url.set(callback_url)

    @classmethod
    def get_oauth2_callback_url(cls) -> Optional[str]:
        """Get the OAuth2 callback URL from the context.

        Returns:
            The callback URL if set, None otherwise

        Example:
            >>> url = GreenNodeAgentBaseContext.get_oauth2_callback_url()
        """
        try:
            return cls._oauth2_callback_url.get()
        except LookupError:
            return None

    @classmethod
    def get_user_id(cls) -> Optional[str]:
        """Get the user ID from the context.

        Returns:
            The user ID if set, None otherwise
        """
        try:
            return cls._user_id.get()
        except LookupError:
            return None

    @classmethod
    def set_user_id(cls, user_id: str) -> None:
        """Set the user ID in the context.

        Args:
            user_id: The user ID to store in the context
        """
        cls._user_id.set(user_id)

    @classmethod
    def set_request_context(cls, request_id: str, session_id: Optional[str] = None) -> None:
        """Set request-scoped identifiers.

        Args:
            request_id: Unique identifier for the request
            session_id: Optional session identifier

        Example:
            >>> GreenNodeAgentBaseContext.set_request_context("req-123", "session-456")
        """
        cls._request_id.set(request_id)
        if session_id is not None:
            cls._session_id.set(session_id)

    @classmethod
    def get_request_id(cls) -> Optional[str]:
        """Get current request ID.

        Returns:
            The request ID if set, None otherwise

        Example:
            >>> request_id = GreenNodeAgentBaseContext.get_request_id()
        """
        try:
            return cls._request_id.get()
        except LookupError:
            return None

    @classmethod
    def get_session_id(cls) -> Optional[str]:
        """Get current session ID.

        Returns:
            The session ID if set, None otherwise

        Example:
            >>> session_id = GreenNodeAgentBaseContext.get_session_id()
        """
        try:
            return cls._session_id.get()
        except LookupError:
            return None

    @classmethod
    def set_request_headers(cls, headers: Dict[str, str]) -> None:
        """Set request headers in the context.

        Args:
            headers: Dictionary of request headers to store

        Example:
            >>> headers = {"Authorization": "Bearer token"}
            >>> GreenNodeAgentBaseContext.set_request_headers(headers)
        """
        cls._request_headers.set(headers)

    @classmethod
    def get_request_headers(cls) -> Optional[Dict[str, str]]:
        """Get request headers from the context.

        Returns:
            Dictionary of request headers if set, None otherwise

        Example:
            >>> headers = GreenNodeAgentBaseContext.get_request_headers()
        """
        try:
            return cls._request_headers.get()
        except LookupError:
            return None

