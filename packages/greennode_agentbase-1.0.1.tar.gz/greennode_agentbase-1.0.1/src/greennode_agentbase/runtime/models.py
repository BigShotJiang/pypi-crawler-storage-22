"""Models for GreenNode AgentBase runtime.

Contains data models and enums used throughout the runtime system.
"""

from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional

from pydantic import BaseModel, Field


class PingStatus(str, Enum):
    """Ping status enum for health check responses.

    Used to indicate the health status of the agent runtime.

    Attributes:
        HEALTHY: Agent is healthy and ready to process requests
        HEALTHY_BUSY: Agent is healthy but currently processing requests

    Example:
        >>> status = PingStatus.HEALTHY
        >>> print(status.value)
        Healthy
    """

    HEALTHY = "Healthy"
    HEALTHY_BUSY = "HealthyBusy"


# Header constants for GreenNode AgentBase
SESSION_HEADER = "X-GreenNode-AgentBase-Session-Id"
REQUEST_ID_HEADER = "X-GreenNode-AgentBase-Request-Id"
ACCESS_TOKEN_HEADER = "X-GreenNode-AgentBase-Access-Token"
USER_ID_HEADER = "X-GreenNode-AgentBase-User-Id"
OAUTH2_CALLBACK_URL_HEADER = "X-GreenNode-AgentBase-OAuth2-Callback-Url"
AUTHORIZATION_HEADER = "Authorization"
CUSTOM_HEADER_PREFIX = "X-GreenNode-AgentBase-Custom-"

# Task action constants for debug mode
TASK_ACTION_PING_STATUS = "ping_status"
TASK_ACTION_JOB_STATUS = "job_status"
TASK_ACTION_FORCE_HEALTHY = "force_healthy"
TASK_ACTION_FORCE_BUSY = "force_busy"
TASK_ACTION_CLEAR_FORCED_STATUS = "clear_forced_status"


# Runtime API Models
class AgentRuntimeImageAuth(BaseModel):
    """Model for agent runtime image authentication."""

    enabled: bool = Field(default=True)
    username: str = Field(..., min_length=1)
    password: str = Field(..., min_length=1)

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class AgentRuntimeAutoscaling(BaseModel):
    """Model for agent runtime autoscaling configuration."""

    min_replicas: int = Field(default=1, ge=1, le=10, alias="minReplicas")
    max_replicas: int = Field(default=1, ge=1, le=10, alias="maxReplicas")
    cpu_utilization: int = Field(default=25, ge=25, le=75, alias="cpuUtilization")
    memory_utilization: int = Field(default=25, ge=25, le=75, alias="memoryUtilization")

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class AgentRuntimeCreateRequest(BaseModel):
    """Request model for creating an agent runtime."""

    name: str = Field(..., min_length=1)
    description: str = Field(default="")
    image_url: str = Field(..., min_length=1, alias="imageUrl")
    image_auth: Optional[AgentRuntimeImageAuth] = Field(None, alias="imageAuth")
    command: List[str] = Field(default_factory=list)
    args: List[str] = Field(default_factory=list)
    environment_variables: Dict[str, str] = Field(default_factory=dict, alias="environmentVariables")
    flavor_id: str = Field(..., min_length=1, alias="flavorId")
    autoscaling: AgentRuntimeAutoscaling = Field(default_factory=lambda: AgentRuntimeAutoscaling())

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class AgentRuntimeUpdateRequest(BaseModel):
    """Request model for updating an agent runtime."""

    image_url: Optional[str] = Field(None, min_length=1, alias="imageUrl")
    image_auth: Optional[AgentRuntimeImageAuth] = Field(None, alias="imageAuth")
    command: Optional[List[str]] = None
    args: Optional[List[str]] = None
    environment_variables: Optional[Dict[str, str]] = Field(None, alias="environmentVariables")
    flavor_id: Optional[str] = Field(None, min_length=1, alias="flavorId")
    autoscaling: Optional[AgentRuntimeAutoscaling] = None

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class AgentRuntimeDto(BaseModel):
    """Response model for agent runtime."""

    id: Optional[str] = None
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None
    created_at: Optional[datetime] = Field(None, alias="createdAt")
    updated_at: Optional[datetime] = Field(None, alias="updatedAt")

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class AgentRuntimeVersionEntity(BaseModel):
    """Response model for agent runtime version."""

    agent_runtime_id: Optional[str] = Field(None, alias="agentRuntimeId")
    version: Optional[int] = None
    image_url: Optional[str] = Field(None, alias="imageUrl")
    image_auth: Optional[AgentRuntimeImageAuth] = Field(None, alias="imageAuth")
    command: Optional[List[str]] = None
    args: Optional[List[str]] = None
    environment_variables: Optional[Dict[str, str]] = Field(None, alias="environmentVariables")
    flavor_id: Optional[str] = Field(None, alias="flavorId")
    autoscaling: Optional[AgentRuntimeAutoscaling] = None
    created_at: Optional[datetime] = Field(None, alias="createdAt")

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class AgentRuntimeVersionListResponse(BaseModel):
    """Response model for listing agent runtime versions."""

    list_data: Optional[List[AgentRuntimeVersionEntity]] = Field(None, alias="listData")
    page: Optional[int] = None
    page_size: Optional[int] = Field(None, alias="pageSize")
    total_page: Optional[int] = Field(None, alias="totalPage")
    total_item: Optional[int] = Field(None, alias="totalItem")

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class AgentRuntimeListResponse(BaseModel):
    """Response model for listing agent runtimes."""

    list_data: Optional[List[AgentRuntimeDto]] = Field(None, alias="listData")
    page: Optional[int] = None
    page_size: Optional[int] = Field(None, alias="pageSize")
    total_page: Optional[int] = Field(None, alias="totalPage")
    total_item: Optional[int] = Field(None, alias="totalItem")

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class AgentRuntimeEndpointCreateRequest(BaseModel):
    """Request model for creating an agent runtime endpoint."""

    name: str = Field(..., min_length=1)
    version: Optional[int] = Field(None, ge=1)

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class AgentRuntimeEndpointDto(BaseModel):
    """Response model for agent runtime endpoint."""

    id: Optional[str] = None
    agent_runtime_id: Optional[str] = Field(None, alias="agentRuntimeId")
    name: Optional[str] = None
    version: Optional[int] = None
    url: Optional[str] = None
    status: Optional[str] = None
    created_at: Optional[datetime] = Field(None, alias="createdAt")
    updated_at: Optional[datetime] = Field(None, alias="updatedAt")

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class AgentRuntimeEndpointListResponse(BaseModel):
    """Response model for listing agent runtime endpoints."""

    list_data: Optional[List[AgentRuntimeEndpointDto]] = Field(None, alias="listData")
    page: Optional[int] = None
    page_size: Optional[int] = Field(None, alias="pageSize")
    total_page: Optional[int] = Field(None, alias="totalPage")
    total_item: Optional[int] = Field(None, alias="totalItem")

    class Config:
        """Pydantic configuration."""

        populate_by_name = True


class FlavorEntity(BaseModel):
    """Model for flavor entity."""

    id: Optional[str] = None
    name: Optional[str] = None
    cpu: Optional[int] = None
    ram: Optional[int] = None
    enabled: Optional[bool] = None
    deleted: Optional[bool] = None

    class Config:
        """Pydantic configuration."""

        populate_by_name = True

