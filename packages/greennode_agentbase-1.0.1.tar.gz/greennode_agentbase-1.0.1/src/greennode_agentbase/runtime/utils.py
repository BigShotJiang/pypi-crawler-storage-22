"""GreenNode AgentBase runtime utilities for object conversion and serialization."""

from dataclasses import asdict, is_dataclass
from typing import Any

from ..exceptions import GreenNodeRuntimeError


def convert_complex_objects(obj: Any, _depth: int = 0) -> Any:
    """Recursively convert complex objects to serializable dictionaries.

    This function handles Pydantic models, dataclasses, dictionaries, lists,
    tuples, and sets, converting them to JSON-serializable formats. It prevents
    infinite recursion by limiting the depth.

    Args:
        obj: The object to convert to a serializable format
        _depth: Internal parameter to track recursion depth (max 50)

    Returns:
        A JSON-serializable representation of the input object

    Raises:
        GreenNodeRuntimeError: If conversion fails or depth limit is exceeded

    Example:
        >>> from pydantic import BaseModel
        >>> class User(BaseModel):
        ...     name: str
        ...     age: int
        >>> user = User(name="Alice", age=30)
        >>> result = convert_complex_objects(user)
        >>> print(result)
        {'name': 'Alice', 'age': 30}
    """
    # Prevent infinite recursion
    if _depth > 50:
        raise GreenNodeRuntimeError(
            "Maximum recursion depth exceeded while converting complex objects",
            details={"max_depth": 50, "current_depth": _depth},
        )

    try:
        # Handle Pydantic models (like AIMessage)
        if hasattr(obj, "model_dump"):
            return obj.model_dump()

        # Handle dataclasses (like AgentResult)
        elif is_dataclass(obj):
            return asdict(obj)

        # Handle dictionaries recursively
        elif isinstance(obj, dict):
            return {k: convert_complex_objects(v, _depth + 1) for k, v in obj.items()}

        # Handle lists and tuples recursively
        elif isinstance(obj, (list, tuple)):
            return [convert_complex_objects(item, _depth + 1) for item in obj]

        # Handle sets (convert to list)
        elif isinstance(obj, set):
            return [convert_complex_objects(item, _depth + 1) for item in obj]

        # Return primitives as-is
        else:
            return obj
    except Exception as e:
        raise GreenNodeRuntimeError(
            "Failed to convert complex object to serializable format",
            details={"object_type": type(obj).__name__, "depth": _depth},
            cause=e,
        ) from e


def is_docker_running() -> bool:
    """Check if Docker is running."""
    import docker
    try:
        docker.from_env().ping()
        return True
    except docker.errors.DockerException:
        return False