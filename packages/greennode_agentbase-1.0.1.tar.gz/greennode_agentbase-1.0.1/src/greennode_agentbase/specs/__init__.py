"""API specifications directory."""

