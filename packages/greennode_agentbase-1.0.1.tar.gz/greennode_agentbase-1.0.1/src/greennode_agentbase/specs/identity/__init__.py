"""Identity API specification."""

