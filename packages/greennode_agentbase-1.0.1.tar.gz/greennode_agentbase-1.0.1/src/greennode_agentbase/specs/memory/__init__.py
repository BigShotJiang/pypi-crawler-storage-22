"""Memory API specification package."""
