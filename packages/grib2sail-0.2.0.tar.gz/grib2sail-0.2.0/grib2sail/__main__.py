from grib2sail.cli import app

app()
