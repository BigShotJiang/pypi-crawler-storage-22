MODELS = ['arome_antilles', 'arome001']
STEPS = ['1h', '3h', '6h', '12h']
DATAS = ['wind', 'wind_gust', 'pressure', 'cloud', 'rain']
