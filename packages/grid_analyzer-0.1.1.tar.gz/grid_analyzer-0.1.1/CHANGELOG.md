# Changelog

All notable changes to GRID Analyzer will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-02-04

### Added
- Initial release of GRID Analyzer
- `analyze` command for codebase indexing
- `query` command for natural language questions
- `map` command for relationship visualization
- `config` command for configuration management
- `license` command for tier management
- Support for Python, JavaScript, TypeScript, and more
- Multi-format output (text, JSON, markdown)
- Interactive HTML graph visualization
- Free tier with 10K file limit
- Professional/Team/Enterprise pricing tiers
- Local-first privacy architecture
- AST-based code analysis
- Pattern detection (MVC, REST API, etc.)
- Colored CLI output
- Progress bars for long operations
- Auto-update checking
- Configuration file support

### Features
- Privacy-first: All analysis happens locally
- Fast indexing: Handles 100K+ files
- Multi-language support: Python, JS, TS, Java, C++, Go, Rust, etc.
- Natural language queries
- Visual relationship mapping
- Pattern detection
- Zero configuration setup

### Documentation
- Comprehensive README with examples
- Quick start guide
- Use case documentation
- API reference
- Contributing guidelines

## [Unreleased]

### Planned
- Enhanced RAG integration with embeddings
- GitHub integration for PR analysis
- VS Code extension
- Slack/Discord bot integration
- Custom model training
- Team collaboration features
- API server mode
- Docker container support
- Jupyter notebook support
- Real-time code watching
- Incremental indexing
- More language support (Kotlin, Swift, Scala)
- Advanced pattern detection
- Code quality metrics
- Security vulnerability detection
- Dependency graph analysis
- Performance profiling integration

---

**Full Changelog**: https://github.com/yourusername/grid-analyzer/commits/main
