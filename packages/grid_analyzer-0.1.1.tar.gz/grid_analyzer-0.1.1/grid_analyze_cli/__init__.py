"""
GRID Analyzer - Understand any codebase in minutes with local-first AI

Privacy-first code analysis that uses local AI models to map relationships,
answer questions, and detect patterns—without sending your code to external APIs.
"""

__version__ = "0.1.1"
__author__ = "GRID Team"
__license__ = "MIT"

from .cli import main

__all__ = ['main']
