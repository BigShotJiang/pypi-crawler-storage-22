"""
Allow running the package as a module: python -m grid_analyze_cli

This provides an alternative entry point when the 'grid' command
isn't available in the system PATH.

Usage:
    python -m grid_analyze_cli [command] [args]

Examples:
    python -m grid_analyze_cli --help
    python -m grid_analyze_cli analyze ./my-project
    python -m grid_analyze_cli query "What does main.py do?"
"""

import sys
from .cli import main

if __name__ == "__main__":
    sys.exit(main())
