"""
GRID Analyzer CLI - Main entry point

Commands:
- grid analyze <directory>    : Analyze codebase and create index
- grid query "<question>"     : Ask questions about your code
- grid map --output <file>    : Generate visual relationship graph
- grid config                 : Configuration management
- grid license <key>          : Activate paid license
"""

import sys
import argparse
import logging
from pathlib import Path
from typing import Optional

from .commands.analyze import AnalyzeCommand
from .commands.query import QueryCommand
from .commands.map import MapCommand
from .commands.config import ConfigCommand
from .commands.license import LicenseCommand
from .utils.logger import setup_logger
from .utils.version import check_for_updates
from . import __version__

logger = logging.getLogger(__name__)


def create_parser() -> argparse.ArgumentParser:
    """Create and configure argument parser"""

    parser = argparse.ArgumentParser(
        prog='grid',
        description='GRID Analyzer - Understand any codebase in minutes with local-first AI',
        epilog='Visit https://grid-analyzer.com for documentation and examples'
    )

    parser.add_argument(
        '--version',
        action='version',
        version=f'GRID Analyzer {__version__}'
    )

    parser.add_argument(
        '-v', '--verbose',
        action='store_true',
        help='Enable verbose output'
    )

    parser.add_argument(
        '--no-color',
        action='store_true',
        help='Disable colored output'
    )

    # Create subcommands
    subparsers = parser.add_subparsers(
        dest='command',
        help='Available commands'
    )

    # ANALYZE command
    analyze_parser = subparsers.add_parser(
        'analyze',
        help='Analyze codebase and create index'
    )
    analyze_parser.add_argument(
        'directory',
        type=str,
        help='Directory to analyze'
    )
    analyze_parser.add_argument(
        '--language',
        type=str,
        help='Primary programming language (auto-detected if not specified)'
    )
    analyze_parser.add_argument(
        '--exclude',
        type=str,
        action='append',
        help='Patterns to exclude (can be repeated)'
    )
    analyze_parser.add_argument(
        '--output',
        type=str,
        default='.grid',
        help='Output directory for index (default: .grid)'
    )

    # QUERY command
    query_parser = subparsers.add_parser(
        'query',
        help='Ask questions about your code'
    )
    query_parser.add_argument(
        'question',
        type=str,
        help='Question to ask about the codebase'
    )
    query_parser.add_argument(
        '--format',
        type=str,
        choices=['text', 'json', 'markdown'],
        default='text',
        help='Output format'
    )
    query_parser.add_argument(
        '--limit',
        type=int,
        default=10,
        help='Maximum number of results (default: 10)'
    )

    # MAP command
    map_parser = subparsers.add_parser(
        'map',
        help='Generate visual relationship graph'
    )
    map_parser.add_argument(
        '--output',
        type=str,
        required=True,
        help='Output file path (supports .svg, .pdf, .html, .json)'
    )
    map_parser.add_argument(
        '--style',
        type=str,
        choices=['default', 'compact', 'detailed'],
        default='default',
        help='Graph style'
    )
    map_parser.add_argument(
        '--focus',
        type=str,
        help='Focus on specific file or module'
    )

    # CONFIG command
    config_parser = subparsers.add_parser(
        'config',
        help='Configuration management'
    )
    config_parser.add_argument(
        'action',
        type=str,
        choices=['show', 'set', 'get', 'reset'],
        help='Configuration action'
    )
    config_parser.add_argument(
        'key',
        type=str,
        nargs='?',
        help='Configuration key'
    )
    config_parser.add_argument(
        'value',
        type=str,
        nargs='?',
        help='Configuration value (for set action)'
    )

    # LICENSE command
    license_parser = subparsers.add_parser(
        'license',
        help='Manage license key'
    )
    license_parser.add_argument(
        'action',
        type=str,
        choices=['activate', 'show', 'deactivate'],
        help='License action'
    )
    license_parser.add_argument(
        'key',
        type=str,
        nargs='?',
        help='License key (for activate action)'
    )

    return parser


def main(argv: Optional[list] = None) -> int:
    """
    Main CLI entry point

    Args:
        argv: Command line arguments (defaults to sys.argv)

    Returns:
        Exit code (0 for success, non-zero for error)
    """

    # Parse arguments
    parser = create_parser()
    args = parser.parse_args(argv)

    # Setup logging
    log_level = logging.DEBUG if args.verbose else logging.INFO
    setup_logger(log_level, use_color=not args.no_color)

    try:
        # Check for updates (async, non-blocking)
        check_for_updates(__version__)

        # Route to appropriate command
        if args.command == 'analyze':
            command = AnalyzeCommand(args)
            return command.execute()

        elif args.command == 'query':
            command = QueryCommand(args)
            return command.execute()

        elif args.command == 'map':
            command = MapCommand(args)
            return command.execute()

        elif args.command == 'config':
            command = ConfigCommand(args)
            return command.execute()

        elif args.command == 'license':
            command = LicenseCommand(args)
            return command.execute()

        else:
            # No command specified, show help
            parser.print_help()
            return 0

    except KeyboardInterrupt:
        logger.info("\n\nInterrupted by user")
        return 130

    except Exception as e:
        logger.error(f"Error: {e}")
        if args.verbose:
            logger.exception("Full traceback:")
        return 1


if __name__ == '__main__':
    sys.exit(main())
