"""
GRID Analyzer - Analyze Command

Analyzes a codebase and creates a searchable index using local RAG.
"""

import logging
from pathlib import Path
from typing import List, Optional
import time

from .base import BaseCommand
from ..core.indexer import CodebaseIndexer
from ..utils.progress import ProgressBar
from ..utils.license_check import check_license, LicenseTier

logger = logging.getLogger(__name__)


class AnalyzeCommand(BaseCommand):
    """Command to analyze codebase and create index"""

    def execute(self) -> int:
        """Execute analyze command"""

        directory = Path(self.args.directory).resolve()

        # Validate directory exists
        if not directory.exists():
            logger.error(f"Directory not found: {directory}")
            return 1

        if not directory.is_dir():
            logger.error(f"Not a directory: {directory}")
            return 1

        # Check license for file limits
        license_info = check_license()
        max_files = self._get_max_files(license_info['tier'])

        logger.info(f"🔍 Analyzing codebase: {directory}")
        logger.info(f"📦 License: {license_info['tier']} (max {max_files:,} files)")

        # Count files first
        file_count = self._count_files(directory, self.args.exclude or [])

        if file_count > max_files:
            logger.error(f"\n❌ Codebase has {file_count:,} files, but your license allows {max_files:,}")
            logger.error(f"   Upgrade to Professional for unlimited files: https://grid-analyzer.com/pricing")
            return 1

        logger.info(f"📊 Found {file_count:,} files to analyze")

        # Create output directory
        output_dir = Path(self.args.output)
        output_dir.mkdir(parents=True, exist_ok=True)

        try:
            # Initialize indexer
            indexer = CodebaseIndexer(
                directory=directory,
                output_dir=output_dir,
                language=self.args.language,
                exclude_patterns=self.args.exclude or []
            )

            # Run analysis with progress bar
            start_time = time.time()

            with ProgressBar(total=file_count, desc="Indexing") as progress:
                def update_progress(current, total):
                    progress.update(current)

                results = indexer.analyze(progress_callback=update_progress)

            elapsed = time.time() - start_time

            # Display results
            logger.info(f"\n✅ Analysis complete in {elapsed:.1f}s")
            logger.info(f"   📁 Files indexed: {results['files_indexed']:,}")
            logger.info(f"   🔤 Total lines: {results['total_lines']:,}")
            logger.info(f"   🧩 Functions found: {results['functions']:,}")
            logger.info(f"   🔗 Relationships: {results['relationships']:,}")
            logger.info(f"   📐 Patterns detected: {results['patterns']:,}")

            if results.get('warnings'):
                logger.warning(f"\n⚠️  {len(results['warnings'])} warnings:")
                for warning in results['warnings'][:5]:  # Show first 5
                    logger.warning(f"   {warning}")

            logger.info(f"\n💡 Next steps:")
            logger.info(f"   $ grid query \"Where is user authentication handled?\"")
            logger.info(f"   $ grid map --output relationships.svg")

            return 0

        except Exception as e:
            logger.error(f"❌ Analysis failed: {e}")
            if self.args.verbose:
                logger.exception("Full traceback:")
            return 1

    def _get_max_files(self, tier: str) -> int:
        """Get maximum files allowed for license tier"""
        limits = {
            'free': 10_000,
            'professional': float('inf'),
            'team': float('inf'),
            'enterprise': float('inf')
        }
        return limits.get(tier, 10_000)

    def _count_files(self, directory: Path, exclude_patterns: List[str]) -> int:
        """Count files in directory (excluding patterns)"""
        # Default exclusions
        default_exclude = [
            '*.git', '__pycache__', 'node_modules', 'venv', '.venv',
            '*.pyc', '*.pyo', '*.so', '*.dylib', '*.dll',
            'dist', 'build', 'target', '*.egg-info'
        ]

        exclude = default_exclude + exclude_patterns

        # TODO: Implement proper file counting with exclusions
        # For now, simple count
        count = 0
        for path in directory.rglob('*'):
            if path.is_file():
                # Check exclusions
                if not any(path.match(pattern) for pattern in exclude):
                    count += 1

        return count
