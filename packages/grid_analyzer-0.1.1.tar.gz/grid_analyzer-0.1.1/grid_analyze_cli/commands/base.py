"""
Base command class for GRID Analyzer CLI
"""

from abc import ABC, abstractmethod
from argparse import Namespace


class BaseCommand(ABC):
    """Base class for all CLI commands"""

    def __init__(self, args: Namespace):
        """
        Initialize command with parsed arguments

        Args:
            args: Parsed command line arguments
        """
        self.args = args

    @abstractmethod
    def execute(self) -> int:
        """
        Execute the command

        Returns:
            Exit code (0 for success, non-zero for error)
        """
        pass
