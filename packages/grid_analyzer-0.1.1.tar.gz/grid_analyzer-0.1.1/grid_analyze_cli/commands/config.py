"""
GRID Analyzer - Config Command

Manages configuration settings.
"""

import logging
import json
from pathlib import Path
from typing import Optional

from .base import BaseCommand

logger = logging.getLogger(__name__)


class ConfigCommand(BaseCommand):
    """Command to manage configuration"""

    def __init__(self, args):
        super().__init__(args)
        self.config_file = Path.home() / '.grid' / 'config.json'

    def execute(self) -> int:
        """Execute config command"""

        action = self.args.action

        if action == 'show':
            return self._show_config()
        elif action == 'get':
            return self._get_value(self.args.key)
        elif action == 'set':
            return self._set_value(self.args.key, self.args.value)
        elif action == 'reset':
            return self._reset_config()
        else:
            logger.error(f"❌ Unknown action: {action}")
            return 1

    def _load_config(self) -> dict:
        """Load configuration from file"""
        if not self.config_file.exists():
            return self._get_default_config()

        try:
            with open(self.config_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            logger.warning(f"⚠️  Failed to load config: {e}")
            return self._get_default_config()

    def _save_config(self, config: dict):
        """Save configuration to file"""
        self.config_file.parent.mkdir(parents=True, exist_ok=True)
        with open(self.config_file, 'w') as f:
            json.dump(config, f, indent=2)

    def _get_default_config(self) -> dict:
        """Get default configuration"""
        return {
            'language': 'auto',
            'exclude_patterns': [
                '*.git',
                '__pycache__',
                'node_modules',
                'venv',
                '.venv',
                'dist',
                'build'
            ],
            'max_file_size_mb': 10,
            'use_color': True,
            'check_updates': True,
            'analytics_enabled': False
        }

    def _show_config(self) -> int:
        """Show current configuration"""
        config = self._load_config()

        print("\n📋 Current Configuration:\n")
        for key, value in config.items():
            if isinstance(value, list):
                print(f"  {key}:")
                for item in value:
                    print(f"    - {item}")
            else:
                print(f"  {key}: {value}")
        print(f"\n📁 Config file: {self.config_file}\n")

        return 0

    def _get_value(self, key: Optional[str]) -> int:
        """Get specific configuration value"""
        if not key:
            logger.error("❌ Key required for 'get' action")
            return 1

        config = self._load_config()

        if key not in config:
            logger.error(f"❌ Unknown configuration key: {key}")
            return 1

        value = config[key]
        if isinstance(value, list):
            print(f"{key}:")
            for item in value:
                print(f"  - {item}")
        else:
            print(f"{key}: {value}")

        return 0

    def _set_value(self, key: Optional[str], value: Optional[str]) -> int:
        """Set configuration value"""
        if not key or not value:
            logger.error("❌ Key and value required for 'set' action")
            return 1

        config = self._load_config()

        # Parse value
        parsed_value = self._parse_value(value)

        config[key] = parsed_value
        self._save_config(config)

        logger.info(f"✅ Set {key} = {parsed_value}")
        return 0

    def _reset_config(self) -> int:
        """Reset configuration to defaults"""
        default_config = self._get_default_config()
        self._save_config(default_config)
        logger.info("✅ Configuration reset to defaults")
        return 0

    def _parse_value(self, value: str):
        """Parse string value to appropriate type"""
        # Try boolean
        if value.lower() in ('true', 'yes', '1'):
            return True
        if value.lower() in ('false', 'no', '0'):
            return False

        # Try number
        try:
            if '.' in value:
                return float(value)
            return int(value)
        except ValueError:
            pass

        # Try list (comma-separated)
        if ',' in value:
            return [item.strip() for item in value.split(',')]

        # Return as string
        return value
