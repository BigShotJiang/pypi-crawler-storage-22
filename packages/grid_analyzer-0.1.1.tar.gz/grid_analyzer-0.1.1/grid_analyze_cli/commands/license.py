"""
GRID Analyzer - License Command

Manages license key activation and verification.
"""

import logging
from pathlib import Path
from typing import Optional

from .base import BaseCommand
from ..utils.license_check import LicenseManager, validate_license_key

logger = logging.getLogger(__name__)


class LicenseCommand(BaseCommand):
    """Command to manage license"""

    def __init__(self, args):
        super().__init__(args)
        self.license_manager = LicenseManager()

    def execute(self) -> int:
        """Execute license command"""

        action = self.args.action

        if action == 'activate':
            return self._activate_license(self.args.key)
        elif action == 'show':
            return self._show_license()
        elif action == 'deactivate':
            return self._deactivate_license()
        else:
            logger.error(f"❌ Unknown action: {action}")
            return 1

    def _activate_license(self, key: Optional[str]) -> int:
        """Activate license key"""
        if not key:
            logger.error("❌ License key required")
            logger.info("   Usage: grid license activate <LICENSE_KEY>")
            return 1

        logger.info("🔐 Validating license key...")

        # Validate format and signature
        validation = validate_license_key(key)
        if not validation['valid']:
            logger.error(f"❌ Invalid license key: {validation['error']}")
            return 1

        # Activate online (verify with server)
        try:
            activation_result = self.license_manager.activate(key)

            if not activation_result['success']:
                logger.error(f"❌ Activation failed: {activation_result['error']}")
                return 1

            logger.info(f"✅ License activated successfully!")
            logger.info(f"   Tier: {activation_result['tier']}")
            logger.info(f"   Valid until: {activation_result['expires_at']}")

            if activation_result.get('features'):
                logger.info(f"   Features:")
                for feature in activation_result['features']:
                    logger.info(f"     • {feature}")

            return 0

        except Exception as e:
            logger.error(f"❌ Activation error: {e}")
            if self.args.verbose:
                logger.exception("Full traceback:")
            return 1

    def _show_license(self) -> int:
        """Show current license information"""
        license_info = self.license_manager.get_license_info()

        print("\n📜 License Information:\n")
        print(f"  Tier: {license_info['tier']}")
        print(f"  Status: {license_info['status']}")

        if license_info['tier'] != 'free':
            print(f"  Valid until: {license_info.get('expires_at', 'N/A')}")
            print(f"  Activated: {license_info.get('activated_at', 'N/A')}")

        print(f"\n  Limits:")
        print(f"    Max files: {license_info['limits']['max_files']}")
        print(f"    API calls/day: {license_info['limits']['api_calls_per_day']}")
        print(f"    Concurrent queries: {license_info['limits']['concurrent_queries']}")

        if license_info.get('features'):
            print(f"\n  Features:")
            for feature in license_info['features']:
                print(f"    • {feature}")

        if license_info['tier'] == 'free':
            print(f"\n💡 Upgrade to Professional for unlimited files:")
            print(f"   Visit: https://grid-analyzer.com/pricing")

        print()
        return 0

    def _deactivate_license(self) -> int:
        """Deactivate current license"""
        license_info = self.license_manager.get_license_info()

        if license_info['tier'] == 'free':
            logger.info("ℹ️  No active license to deactivate")
            return 0

        logger.info("🔓 Deactivating license...")

        try:
            result = self.license_manager.deactivate()

            if result['success']:
                logger.info("✅ License deactivated")
                logger.info("   You're now on the Free tier")
                return 0
            else:
                logger.error(f"❌ Deactivation failed: {result['error']}")
                return 1

        except Exception as e:
            logger.error(f"❌ Deactivation error: {e}")
            if self.args.verbose:
                logger.exception("Full traceback:")
            return 1
