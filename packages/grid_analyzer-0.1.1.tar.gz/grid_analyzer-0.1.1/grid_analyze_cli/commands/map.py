"""
GRID Analyzer - Map Command

Generates visual relationship graphs of the codebase.
"""

import logging
from pathlib import Path

from .base import BaseCommand
from ..core.indexer import CodebaseIndexer

logger = logging.getLogger(__name__)


class MapCommand(BaseCommand):
    """Command to generate codebase relationship map"""

    def execute(self) -> int:
        """Execute map command"""

        output_file = Path(self.args.output)

        # Check if index exists
        index_path = Path('.grid')
        if not index_path.exists():
            logger.error("❌ No index found. Run 'grid analyze' first.")
            return 1

        # Validate output format
        supported_formats = ['.svg', '.pdf', '.html', '.json']
        if output_file.suffix not in supported_formats:
            logger.error(f"❌ Unsupported format: {output_file.suffix}")
            logger.error(f"   Supported: {', '.join(supported_formats)}")
            return 1

        logger.info(f"🗺️  Generating relationship map...")

        try:
            # Load indexer
            indexer = CodebaseIndexer.load(index_path)

            # Generate map
            map_data = indexer.generate_map(
                style=self.args.style,
                focus=self.args.focus
            )

            # Export to requested format
            if output_file.suffix == '.json':
                self._export_json(map_data, output_file)
            elif output_file.suffix == '.html':
                self._export_html(map_data, output_file)
            elif output_file.suffix == '.svg':
                self._export_svg(map_data, output_file)
            elif output_file.suffix == '.pdf':
                self._export_pdf(map_data, output_file)

            logger.info(f"✅ Map saved to: {output_file}")
            logger.info(f"   Nodes: {map_data['stats']['nodes']:,}")
            logger.info(f"   Edges: {map_data['stats']['edges']:,}")
            logger.info(f"   Modules: {map_data['stats']['modules']:,}")

            return 0

        except Exception as e:
            logger.error(f"❌ Map generation failed: {e}")
            if self.args.verbose:
                logger.exception("Full traceback:")
            return 1

    def _export_json(self, map_data: dict, output_file: Path):
        """Export map as JSON"""
        import json
        with open(output_file, 'w') as f:
            json.dump(map_data, f, indent=2)

    def _export_html(self, map_data: dict, output_file: Path):
        """Export map as interactive HTML with D3.js"""
        html_template = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>GRID Codebase Map</title>
    <script src="https://d3js.org/d3.v7.min.js"></script>
    <style>
        body {{ margin: 0; font-family: sans-serif; }}
        #graph {{ width: 100vw; height: 100vh; }}
        .node {{ cursor: pointer; }}
        .node:hover {{ stroke: #ff6b6b; stroke-width: 3px; }}
        .link {{ stroke: #999; stroke-opacity: 0.6; }}
        .label {{ font-size: 10px; pointer-events: none; }}
    </style>
</head>
<body>
    <div id="graph"></div>
    <script>
        const data = {map_data};
        // D3.js force-directed graph implementation
        const width = window.innerWidth;
        const height = window.innerHeight;

        const svg = d3.select("#graph")
            .append("svg")
            .attr("width", width)
            .attr("height", height);

        const simulation = d3.forceSimulation(data.nodes)
            .force("link", d3.forceLink(data.edges).id(d => d.id))
            .force("charge", d3.forceManyBody().strength(-200))
            .force("center", d3.forceCenter(width / 2, height / 2));

        const link = svg.append("g")
            .selectAll("line")
            .data(data.edges)
            .enter().append("line")
            .attr("class", "link");

        const node = svg.append("g")
            .selectAll("circle")
            .data(data.nodes)
            .enter().append("circle")
            .attr("class", "node")
            .attr("r", 8)
            .attr("fill", d => d.color || "#69b3a2")
            .call(d3.drag()
                .on("start", dragstarted)
                .on("drag", dragged)
                .on("end", dragended));

        const label = svg.append("g")
            .selectAll("text")
            .data(data.nodes)
            .enter().append("text")
            .attr("class", "label")
            .text(d => d.label);

        simulation.on("tick", () => {{
            link
                .attr("x1", d => d.source.x)
                .attr("y1", d => d.source.y)
                .attr("x2", d => d.target.x)
                .attr("y2", d => d.target.y);

            node
                .attr("cx", d => d.x)
                .attr("cy", d => d.y);

            label
                .attr("x", d => d.x + 12)
                .attr("y", d => d.y + 4);
        }});

        function dragstarted(event, d) {{
            if (!event.active) simulation.alphaTarget(0.3).restart();
            d.fx = d.x;
            d.fy = d.y;
        }}

        function dragged(event, d) {{
            d.fx = event.x;
            d.fy = event.y;
        }}

        function dragended(event, d) {{
            if (!event.active) simulation.alphaTarget(0);
            d.fx = null;
            d.fy = null;
        }}
    </script>
</body>
</html>
"""
        import json
        html_content = html_template.replace('{map_data}', json.dumps(map_data))
        with open(output_file, 'w') as f:
            f.write(html_content)

    def _export_svg(self, map_data: dict, output_file: Path):
        """Export map as SVG"""
        # Simple SVG generation (can be enhanced with graphviz)
        svg_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="800">
    <text x="600" y="30" text-anchor="middle" font-size="20">GRID Codebase Map</text>
    <text x="600" y="50" text-anchor="middle" font-size="12">
        {map_data['stats']['nodes']} nodes, {map_data['stats']['edges']} edges
    </text>
    <!-- Graph visualization would be generated here -->
    <text x="600" y="400" text-anchor="middle" font-size="14" fill="#666">
        Use HTML format for interactive visualization
    </text>
</svg>"""
        with open(output_file, 'w') as f:
            f.write(svg_content)

    def _export_pdf(self, map_data: dict, output_file: Path):
        """Export map as PDF"""
        logger.warning("⚠️  PDF export requires additional dependencies")
        logger.info("   Install: pip install reportlab")
        logger.info("   For now, generating HTML instead...")
        html_file = output_file.with_suffix('.html')
        self._export_html(map_data, html_file)
        logger.info(f"   Generated: {html_file}")
