"""
GRID Analyzer - Query Command

Asks questions about the codebase using the created index.
"""

import logging
import json
from pathlib import Path

from .base import BaseCommand
from ..core.indexer import CodebaseIndexer

logger = logging.getLogger(__name__)


class QueryCommand(BaseCommand):
    """Command to query the codebase"""

    def execute(self) -> int:
        """Execute query command"""

        question = self.args.question

        # Check if index exists
        index_path = Path('.grid')
        if not index_path.exists():
            logger.error("❌ No index found. Run 'grid analyze' first.")
            logger.info("   $ grid analyze .")
            return 1

        logger.info(f"🔍 Searching codebase for: {question}")

        try:
            # Load indexer
            indexer = CodebaseIndexer.load(index_path)

            # Execute query
            results = indexer.query(
                question=question,
                limit=self.args.limit
            )

            # Format output based on requested format
            if self.args.format == 'json':
                self._output_json(results)
            elif self.args.format == 'markdown':
                self._output_markdown(results)
            else:
                self._output_text(results)

            return 0

        except Exception as e:
            logger.error(f"❌ Query failed: {e}")
            if self.args.verbose:
                logger.exception("Full traceback:")
            return 1

    def _output_text(self, results: dict):
        """Output results as formatted text"""
        print(f"\n📊 Found {len(results['matches'])} relevant results:\n")

        for i, match in enumerate(results['matches'], 1):
            print(f"{i}. {match['file']}:{match.get('line', '?')}")
            print(f"   Score: {match['score']:.2f}")
            print(f"   {match['snippet'][:100]}...")
            if match.get('context'):
                print(f"   Context: {match['context']}")
            print()

        if results.get('summary'):
            print(f"💡 Summary:\n{results['summary']}\n")

    def _output_json(self, results: dict):
        """Output results as JSON"""
        print(json.dumps(results, indent=2))

    def _output_markdown(self, results: dict):
        """Output results as Markdown"""
        print(f"# Query Results\n")
        print(f"**Question:** {self.args.question}\n")
        print(f"**Matches:** {len(results['matches'])}\n")

        for i, match in enumerate(results['matches'], 1):
            print(f"## {i}. {match['file']}")
            print(f"- **Line:** {match.get('line', 'N/A')}")
            print(f"- **Score:** {match['score']:.2f}")
            print(f"\n```\n{match['snippet']}\n```\n")
            if match.get('context'):
                print(f"**Context:** {match['context']}\n")

        if results.get('summary'):
            print(f"## Summary\n{results['summary']}\n")
