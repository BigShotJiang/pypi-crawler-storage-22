"""Core functionality for GRID Analyzer"""

from .indexer import CodebaseIndexer

__all__ = ['CodebaseIndexer']
