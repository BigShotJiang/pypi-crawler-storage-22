"""
GRID Analyzer - Codebase Indexer

Indexes codebases using local RAG for semantic search and relationship mapping.
"""

import logging
import json
from pathlib import Path
from typing import List, Dict, Any, Optional, Callable
import ast
import re

logger = logging.getLogger(__name__)


class CodebaseIndexer:
    """Indexes and analyzes codebases"""

    def __init__(
        self,
        directory: Path,
        output_dir: Path,
        language: Optional[str] = None,
        exclude_patterns: Optional[List[str]] = None
    ):
        """
        Initialize indexer

        Args:
            directory: Directory to index
            output_dir: Output directory for index
            language: Primary language (auto-detected if None)
            exclude_patterns: Patterns to exclude
        """
        self.directory = directory
        self.output_dir = output_dir
        self.language = language
        self.exclude_patterns = exclude_patterns or []
        self.index_data = {
            'files': {},
            'functions': {},
            'relationships': [],
            'patterns': [],
            'metadata': {}
        }

    def analyze(self, progress_callback: Optional[Callable] = None) -> Dict[str, Any]:
        """
        Analyze codebase and create index

        Args:
            progress_callback: Callback function for progress updates

        Returns:
            Analysis results
        """
        logger.info("Starting codebase analysis...")

        # Get all files to analyze
        files = self._get_files_to_analyze()
        total_files = len(files)

        # Analyze each file
        files_indexed = 0
        total_lines = 0
        functions_found = 0
        warnings = []

        for i, file_path in enumerate(files):
            try:
                file_data = self._analyze_file(file_path)

                self.index_data['files'][str(file_path)] = file_data
                total_lines += file_data['lines']
                functions_found += len(file_data['functions'])
                files_indexed += 1

                if progress_callback:
                    progress_callback(i + 1, total_files)

            except Exception as e:
                warning = f"Failed to analyze {file_path}: {e}"
                logger.warning(warning)
                warnings.append(warning)

        # Extract relationships
        self._extract_relationships()

        # Detect patterns
        self._detect_patterns()

        # Save index
        self._save_index()

        # Return results
        results = {
            'files_indexed': files_indexed,
            'total_lines': total_lines,
            'functions': functions_found,
            'relationships': len(self.index_data['relationships']),
            'patterns': len(self.index_data['patterns']),
            'warnings': warnings
        }

        return results

    def _get_files_to_analyze(self) -> List[Path]:
        """Get list of files to analyze"""
        files = []

        # Common code file extensions
        code_extensions = {
            '.py', '.js', '.ts', '.jsx', '.tsx',
            '.java', '.cpp', '.c', '.h', '.hpp',
            '.cs', '.go', '.rs', '.rb', '.php',
            '.swift', '.kt', '.scala', '.sh'
        }

        for file_path in self.directory.rglob('*'):
            if not file_path.is_file():
                continue

            # Check exclusions
            if any(file_path.match(pattern) for pattern in self.exclude_patterns):
                continue

            # Check if it's a code file
            if file_path.suffix in code_extensions:
                files.append(file_path.relative_to(self.directory))

        return sorted(files)

    def _analyze_file(self, file_path: Path) -> Dict[str, Any]:
        """Analyze a single file"""
        full_path = self.directory / file_path

        with open(full_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()

        # Basic analysis
        lines = content.split('\n')
        file_data = {
            'path': str(file_path),
            'lines': len(lines),
            'size': len(content),
            'language': self._detect_language(file_path),
            'functions': [],
            'classes': [],
            'imports': []
        }

        # Language-specific analysis
        if file_data['language'] == 'python':
            file_data.update(self._analyze_python(content))
        elif file_data['language'] in ('javascript', 'typescript'):
            file_data.update(self._analyze_javascript(content))

        return file_data

    def _detect_language(self, file_path: Path) -> str:
        """Detect programming language from file extension"""
        extension_map = {
            '.py': 'python',
            '.js': 'javascript',
            '.ts': 'typescript',
            '.jsx': 'javascript',
            '.tsx': 'typescript',
            '.java': 'java',
            '.cpp': 'cpp',
            '.c': 'c',
            '.h': 'c',
            '.cs': 'csharp',
            '.go': 'go',
            '.rs': 'rust',
            '.rb': 'ruby',
            '.php': 'php'
        }
        return extension_map.get(file_path.suffix, 'unknown')

    def _analyze_python(self, content: str) -> Dict[str, Any]:
        """Analyze Python code"""
        result = {
            'functions': [],
            'classes': [],
            'imports': []
        }

        try:
            tree = ast.parse(content)

            for node in ast.walk(tree):
                # Extract functions
                if isinstance(node, ast.FunctionDef):
                    result['functions'].append({
                        'name': node.name,
                        'line': node.lineno,
                        'args': [arg.arg for arg in node.args.args],
                        'is_async': isinstance(node, ast.AsyncFunctionDef)
                    })

                # Extract classes
                elif isinstance(node, ast.ClassDef):
                    methods = [n.name for n in node.body if isinstance(n, ast.FunctionDef)]
                    result['classes'].append({
                        'name': node.name,
                        'line': node.lineno,
                        'methods': methods
                    })

                # Extract imports
                elif isinstance(node, (ast.Import, ast.ImportFrom)):
                    if isinstance(node, ast.Import):
                        for alias in node.names:
                            result['imports'].append(alias.name)
                    else:
                        module = node.module or ''
                        for alias in node.names:
                            result['imports'].append(f"{module}.{alias.name}")

        except SyntaxError as e:
            logger.debug(f"Syntax error in Python file: {e}")

        return result

    def _analyze_javascript(self, content: str) -> Dict[str, Any]:
        """Analyze JavaScript/TypeScript code"""
        result = {
            'functions': [],
            'classes': [],
            'imports': []
        }

        # Simple regex-based analysis (can be enhanced with proper parser)
        # Extract function declarations
        func_pattern = r'function\s+(\w+)\s*\('
        for match in re.finditer(func_pattern, content):
            result['functions'].append({
                'name': match.group(1),
                'type': 'function'
            })

        # Extract arrow functions
        arrow_pattern = r'const\s+(\w+)\s*=\s*\([^)]*\)\s*=>'
        for match in re.finditer(arrow_pattern, content):
            result['functions'].append({
                'name': match.group(1),
                'type': 'arrow'
            })

        # Extract classes
        class_pattern = r'class\s+(\w+)'
        for match in re.finditer(class_pattern, content):
            result['classes'].append({
                'name': match.group(1)
            })

        # Extract imports
        import_pattern = r'import\s+.*\s+from\s+[\'"]([^\'"]+)[\'"]'
        for match in re.finditer(import_pattern, content):
            result['imports'].append(match.group(1))

        return result

    def _extract_relationships(self):
        """Extract relationships between files"""
        for file_path, file_data in self.index_data['files'].items():
            for import_path in file_data.get('imports', []):
                # Try to resolve import to actual file
                resolved = self._resolve_import(import_path, file_data['language'])
                if resolved:
                    self.index_data['relationships'].append({
                        'from': file_path,
                        'to': resolved,
                        'type': 'imports'
                    })

    def _resolve_import(self, import_path: str, language: str) -> Optional[str]:
        """Resolve import path to actual file"""
        # Simplified resolution (can be enhanced)
        if language == 'python':
            # Convert module.name to module/name.py
            parts = import_path.split('.')
            possible_path = '/'.join(parts) + '.py'
            if possible_path in self.index_data['files']:
                return possible_path

        return None

    def _detect_patterns(self):
        """Detect common patterns in codebase"""
        patterns = []

        # Check for common architectural patterns
        has_models = any('model' in path.lower() for path in self.index_data['files'])
        has_views = any('view' in path.lower() for path in self.index_data['files'])
        has_controllers = any('controller' in path.lower() for path in self.index_data['files'])

        if has_models and has_views and has_controllers:
            patterns.append('MVC Architecture')

        # Check for API structure
        has_api = any('api' in path.lower() for path in self.index_data['files'])
        has_routes = any('route' in path.lower() for path in self.index_data['files'])

        if has_api or has_routes:
            patterns.append('REST API')

        self.index_data['patterns'] = patterns

    def _save_index(self):
        """Save index to disk"""
        self.output_dir.mkdir(parents=True, exist_ok=True)

        index_file = self.output_dir / 'index.json'
        with open(index_file, 'w') as f:
            json.dump(self.index_data, f, indent=2)

        logger.info(f"Index saved to: {index_file}")

    @classmethod
    def load(cls, index_path: Path) -> 'CodebaseIndexer':
        """Load existing index"""
        index_file = index_path / 'index.json'
        if not index_file.exists():
            raise FileNotFoundError(f"Index not found: {index_file}")

        with open(index_file, 'r') as f:
            index_data = json.load(f)

        # Create indexer instance
        indexer = cls(
            directory=Path(index_data.get('metadata', {}).get('directory', '.')),
            output_dir=index_path
        )
        indexer.index_data = index_data

        return indexer

    def query(self, question: str, limit: int = 10) -> Dict[str, Any]:
        """
        Query the indexed codebase

        Args:
            question: Question to answer
            limit: Maximum number of results

        Returns:
            Query results with matches and summary
        """
        # Simple keyword-based search (can be enhanced with embeddings)
        keywords = question.lower().split()
        matches = []

        for file_path, file_data in self.index_data['files'].items():
            score = 0

            # Check file path
            if any(kw in file_path.lower() for kw in keywords):
                score += 2

            # Check function names
            for func in file_data.get('functions', []):
                if any(kw in func['name'].lower() for kw in keywords):
                    score += 5
                    matches.append({
                        'file': file_path,
                        'line': func.get('line', 0),
                        'snippet': f"Function: {func['name']}",
                        'score': score,
                        'context': f"Function with {len(func.get('args', []))} arguments"
                    })

            # Check class names
            for cls in file_data.get('classes', []):
                if any(kw in cls['name'].lower() for kw in keywords):
                    score += 5
                    matches.append({
                        'file': file_path,
                        'line': cls.get('line', 0),
                        'snippet': f"Class: {cls['name']}",
                        'score': score,
                        'context': f"Class with {len(cls.get('methods', []))} methods"
                    })

        # Sort by score and limit
        matches.sort(key=lambda x: x['score'], reverse=True)
        matches = matches[:limit]

        # Generate summary
        summary = self._generate_summary(question, matches)

        return {
            'question': question,
            'matches': matches,
            'summary': summary
        }

    def _generate_summary(self, question: str, matches: List[Dict]) -> str:
        """Generate summary of query results"""
        if not matches:
            return "No relevant matches found in the codebase."

        top_match = matches[0]
        return f"Found {len(matches)} relevant locations. Most relevant: {top_match['snippet']} in {top_match['file']}"

    def generate_map(self, style: str = 'default', focus: Optional[str] = None) -> Dict[str, Any]:
        """
        Generate relationship map

        Args:
            style: Map style (default, compact, detailed)
            focus: Optional file/module to focus on

        Returns:
            Map data with nodes and edges
        """
        nodes = []
        edges = []

        # Create nodes for each file
        for file_path, file_data in self.index_data['files'].items():
            if focus and focus not in file_path:
                continue

            nodes.append({
                'id': file_path,
                'label': Path(file_path).name,
                'type': 'file',
                'language': file_data['language'],
                'functions': len(file_data.get('functions', [])),
                'classes': len(file_data.get('classes', []))
            })

        # Create edges for relationships
        for rel in self.index_data['relationships']:
            if focus and focus not in rel['from'] and focus not in rel['to']:
                continue

            edges.append({
                'source': rel['from'],
                'target': rel['to'],
                'type': rel['type']
            })

        return {
            'nodes': nodes,
            'edges': edges,
            'stats': {
                'nodes': len(nodes),
                'edges': len(edges),
                'modules': len(set(str(Path(n['id']).parent) for n in nodes))
            }
        }
