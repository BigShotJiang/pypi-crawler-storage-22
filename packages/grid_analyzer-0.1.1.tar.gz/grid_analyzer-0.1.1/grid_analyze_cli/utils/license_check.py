"""
GRID Analyzer - License Management

Handles license validation and tier management.
"""

import logging
import json
import hashlib
import hmac
from pathlib import Path
from typing import Dict, Any, Optional
from enum import Enum
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


class LicenseTier(Enum):
    """License tiers"""
    FREE = 'free'
    PROFESSIONAL = 'professional'
    TEAM = 'team'
    ENTERPRISE = 'enterprise'


class LicenseManager:
    """Manages license activation and validation"""

    def __init__(self):
        """Initialize license manager"""
        self.license_file = Path.home() / '.grid' / 'license.json'
        self.license_file.parent.mkdir(parents=True, exist_ok=True)

    def get_license_info(self) -> Dict[str, Any]:
        """Get current license information"""
        if not self.license_file.exists():
            return self._get_free_tier_info()

        try:
            with open(self.license_file, 'r') as f:
                license_data = json.load(f)

            # Validate expiration
            expires_at = license_data.get('expires_at')
            if expires_at:
                expiry_date = datetime.fromisoformat(expires_at)
                if datetime.now() > expiry_date:
                    logger.warning("⚠️  License expired")
                    return self._get_free_tier_info()

            return self._format_license_info(license_data)

        except Exception as e:
            logger.warning(f"Failed to load license: {e}")
            return self._get_free_tier_info()

    def activate(self, license_key: str) -> Dict[str, Any]:
        """
        Activate license key

        Args:
            license_key: License key to activate

        Returns:
            Activation result
        """
        # Validate key format
        validation = validate_license_key(license_key)
        if not validation['valid']:
            return {'success': False, 'error': validation['error']}

        # TODO: Verify with license server
        # For now, decode key locally
        try:
            tier_code = license_key.split('-')[1]
            tier_map = {
                'PRO': LicenseTier.PROFESSIONAL,
                'TEAM': LicenseTier.TEAM,
                'ENT': LicenseTier.ENTERPRISE
            }

            tier = tier_map.get(tier_code, LicenseTier.FREE)

            # Create license data
            license_data = {
                'key': license_key,
                'tier': tier.value,
                'activated_at': datetime.now().isoformat(),
                'expires_at': (datetime.now() + timedelta(days=365)).isoformat(),
                'status': 'active'
            }

            # Save license
            with open(self.license_file, 'w') as f:
                json.dump(license_data, f, indent=2)

            return {
                'success': True,
                'tier': tier.value,
                'expires_at': license_data['expires_at'],
                'features': self._get_tier_features(tier)
            }

        except Exception as e:
            return {'success': False, 'error': str(e)}

    def deactivate(self) -> Dict[str, Any]:
        """Deactivate current license"""
        try:
            if self.license_file.exists():
                self.license_file.unlink()
            return {'success': True}
        except Exception as e:
            return {'success': False, 'error': str(e)}

    def _get_free_tier_info(self) -> Dict[str, Any]:
        """Get free tier information"""
        return {
            'tier': LicenseTier.FREE.value,
            'status': 'active',
            'limits': {
                'max_files': 10_000,
                'api_calls_per_day': 100,
                'concurrent_queries': 1
            },
            'features': [
                'Local-first analysis',
                'Basic code indexing',
                'Simple queries'
            ]
        }

    def _format_license_info(self, license_data: Dict[str, Any]) -> Dict[str, Any]:
        """Format license data for display"""
        tier = LicenseTier(license_data['tier'])

        return {
            'tier': tier.value,
            'status': license_data.get('status', 'active'),
            'activated_at': license_data.get('activated_at'),
            'expires_at': license_data.get('expires_at'),
            'limits': self._get_tier_limits(tier),
            'features': self._get_tier_features(tier)
        }

    def _get_tier_limits(self, tier: LicenseTier) -> Dict[str, Any]:
        """Get limits for tier"""
        limits = {
            LicenseTier.FREE: {
                'max_files': 10_000,
                'api_calls_per_day': 100,
                'concurrent_queries': 1
            },
            LicenseTier.PROFESSIONAL: {
                'max_files': float('inf'),
                'api_calls_per_day': 10_000,
                'concurrent_queries': 5
            },
            LicenseTier.TEAM: {
                'max_files': float('inf'),
                'api_calls_per_day': 100_000,
                'concurrent_queries': 20
            },
            LicenseTier.ENTERPRISE: {
                'max_files': float('inf'),
                'api_calls_per_day': float('inf'),
                'concurrent_queries': float('inf')
            }
        }
        result = limits[tier]
        # Format infinity for display
        return {k: ('unlimited' if v == float('inf') else v) for k, v in result.items()}

    def _get_tier_features(self, tier: LicenseTier) -> list:
        """Get features for tier"""
        features = {
            LicenseTier.FREE: [
                'Local-first analysis',
                'Basic code indexing',
                'Simple queries',
                'Up to 10K files'
            ],
            LicenseTier.PROFESSIONAL: [
                'Everything in Free',
                'Unlimited files',
                'Advanced queries',
                'Relationship mapping',
                'Pattern detection',
                'Priority support'
            ],
            LicenseTier.TEAM: [
                'Everything in Professional',
                'Team collaboration',
                'Shared indexes',
                'Custom integrations',
                'SSO support'
            ],
            LicenseTier.ENTERPRISE: [
                'Everything in Team',
                'On-premise deployment',
                'Custom model training',
                'SLA guarantee',
                'Dedicated support'
            ]
        }
        return features.get(tier, [])


def check_license() -> Dict[str, Any]:
    """
    Check current license status

    Returns:
        License information dictionary
    """
    manager = LicenseManager()
    return manager.get_license_info()


def validate_license_key(key: str) -> Dict[str, Any]:
    """
    Validate license key format

    Args:
        key: License key to validate

    Returns:
        Validation result
    """
    # Expected format: GRID-{TIER}-{HASH}
    # Example: GRID-PRO-A1B2C3D4E5F6

    if not key or not isinstance(key, str):
        return {'valid': False, 'error': 'Invalid key format'}

    parts = key.split('-')
    if len(parts) != 3:
        return {'valid': False, 'error': 'Invalid key format (expected GRID-TIER-HASH)'}

    prefix, tier, hash_part = parts

    if prefix != 'GRID':
        return {'valid': False, 'error': 'Invalid key prefix'}

    valid_tiers = ['PRO', 'TEAM', 'ENT']
    if tier not in valid_tiers:
        return {'valid': False, 'error': f'Invalid tier (must be one of: {", ".join(valid_tiers)})'}

    if len(hash_part) < 8:
        return {'valid': False, 'error': 'Invalid hash length'}

    return {'valid': True, 'tier': tier}
