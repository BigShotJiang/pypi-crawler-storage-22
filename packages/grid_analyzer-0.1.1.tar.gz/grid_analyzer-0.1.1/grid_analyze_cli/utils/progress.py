"""
GRID Analyzer - Progress Bar

Simple progress bar for CLI operations.
"""

import sys
from typing import Optional


class ProgressBar:
    """Simple progress bar for terminal"""

    def __init__(self, total: int, desc: str = "Progress", width: int = 50):
        """
        Initialize progress bar

        Args:
            total: Total number of items
            desc: Description text
            width: Width of progress bar in characters
        """
        self.total = total
        self.desc = desc
        self.width = width
        self.current = 0

    def __enter__(self):
        """Context manager entry"""
        self._display()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        if exc_type is None:
            # Successful completion
            self.current = self.total
            self._display()
        print()  # New line after progress bar

    def update(self, n: int = 1):
        """
        Update progress

        Args:
            n: Number of items completed
        """
        self.current = min(n, self.total)
        self._display()

    def _display(self):
        """Display progress bar"""
        if not sys.stdout.isatty():
            # Don't show progress bar in non-TTY environments
            return

        percent = self.current / self.total if self.total > 0 else 0
        filled = int(self.width * percent)
        bar = '█' * filled + '░' * (self.width - filled)

        # ANSI escape codes for cursor control
        print(f'\r{self.desc}: |{bar}| {self.current}/{self.total} ({percent:.1%})', end='', flush=True)
