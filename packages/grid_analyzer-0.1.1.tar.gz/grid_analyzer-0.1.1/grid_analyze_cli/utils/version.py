"""
GRID Analyzer - Version Checker

Checks for updates from PyPI.
"""

import logging
from typing import Optional
import requests
from packaging import version

logger = logging.getLogger(__name__)


def check_for_updates(current_version: str, timeout: int = 2):
    """
    Check for updates from PyPI

    Args:
        current_version: Current version string
        timeout: Request timeout in seconds
    """
    try:
        # Query PyPI API
        response = requests.get(
            'https://pypi.org/pypi/grid-analyzer/json',
            timeout=timeout
        )

        if response.status_code == 200:
            data = response.json()
            latest_version = data['info']['version']

            # Compare versions
            if version.parse(latest_version) > version.parse(current_version):
                logger.info(f"\n📦 Update available: {current_version} → {latest_version}")
                logger.info(f"   Run: pip install --upgrade grid-analyzer\n")

    except Exception as e:
        # Silently fail - don't interrupt user workflow
        logger.debug(f"Failed to check for updates: {e}")
