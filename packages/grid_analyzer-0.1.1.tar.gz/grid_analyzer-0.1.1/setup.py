"""
GRID Analyzer - Setup Configuration

Package configuration for PyPI distribution.
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read long description from README
readme_file = Path(__file__).parent / 'README.md'
long_description = readme_file.read_text(encoding='utf-8') if readme_file.exists() else ''

# Read version from package
version_file = Path(__file__).parent / 'grid_analyze_cli' / '__init__.py'
version = '0.1.0'
if version_file.exists():
    for line in version_file.read_text().split('\n'):
        if line.startswith('__version__'):
            version = line.split('=')[1].strip().strip('"').strip("'")
            break

setup(
    name='grid-analyzer',
    version=version,
    description='Understand any codebase in minutes with local-first AI',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='GRID Team',
    author_email='caraxesthebloodwyrm02@gmail.com',
    url='https://zesty-muffin-4423d8.netlify.app',
    project_urls={
        'Homepage': 'https://zesty-muffin-4423d8.netlify.app',
        'PyPI': 'https://pypi.org/project/grid-analyzer/',
    },
    packages=find_packages(),
    include_package_data=True,
    python_requires='>=3.8',
    install_requires=[
        'requests>=2.28.0',
        'packaging>=21.0',
    ],
    extras_require={
        'dev': [
            'pytest>=7.0.0',
            'pytest-cov>=4.0.0',
            'black>=22.0.0',
            'flake8>=5.0.0',
            'mypy>=0.990',
        ],
        'visualization': [
            'reportlab>=3.6.0',
        ]
    },
    entry_points={
        'console_scripts': [
            'grid=grid_analyze_cli.cli:main',
        ],
    },
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Code Generators',
        'Topic :: Software Development :: Documentation',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Operating System :: OS Independent',
        'Environment :: Console',
    ],
    keywords='code-analysis ai rag codebase-understanding developer-tools',
    license='MIT',
    zip_safe=False,
)
