"""
Tests for CodebaseIndexer
"""

import pytest
from pathlib import Path
import tempfile
import shutil

from grid_analyze_cli.core.indexer import CodebaseIndexer


@pytest.fixture
def temp_codebase():
    """Create a temporary codebase for testing"""
    temp_dir = Path(tempfile.mkdtemp())

    # Create sample Python file
    (temp_dir / "main.py").write_text("""
def hello_world():
    print("Hello, World!")

class Calculator:
    def add(self, a, b):
        return a + b

    def subtract(self, a, b):
        return a - b
""")

    # Create sample JavaScript file
    (temp_dir / "app.js").write_text("""
function greet(name) {
    console.log(`Hello, ${name}!`);
}

class User {
    constructor(name) {
        this.name = name;
    }
}
""")

    yield temp_dir

    # Cleanup
    shutil.rmtree(temp_dir)


@pytest.fixture
def indexer(temp_codebase):
    """Create an indexer instance"""
    output_dir = temp_codebase / '.grid'
    return CodebaseIndexer(
        directory=temp_codebase,
        output_dir=output_dir
    )


def test_indexer_initialization(indexer, temp_codebase):
    """Test indexer initialization"""
    assert indexer.directory == temp_codebase
    assert indexer.output_dir == temp_codebase / '.grid'


def test_get_files_to_analyze(indexer):
    """Test file discovery"""
    files = indexer._get_files_to_analyze()

    # Should find both Python and JavaScript files
    assert len(files) == 2
    assert any(f.name == 'main.py' for f in files)
    assert any(f.name == 'app.js' for f in files)


def test_detect_language(indexer):
    """Test language detection"""
    assert indexer._detect_language(Path('test.py')) == 'python'
    assert indexer._detect_language(Path('test.js')) == 'javascript'
    assert indexer._detect_language(Path('test.ts')) == 'typescript'
    assert indexer._detect_language(Path('test.java')) == 'java'
    assert indexer._detect_language(Path('test.unknown')) == 'unknown'


def test_analyze_python(indexer, temp_codebase):
    """Test Python code analysis"""
    content = (temp_codebase / "main.py").read_text()
    result = indexer._analyze_python(content)

    # Should find function
    assert len(result['functions']) == 1
    assert result['functions'][0]['name'] == 'hello_world'

    # Should find class and methods
    assert len(result['classes']) == 1
    assert result['classes'][0]['name'] == 'Calculator'
    assert 'add' in result['classes'][0]['methods']
    assert 'subtract' in result['classes'][0]['methods']


def test_analyze_javascript(indexer, temp_codebase):
    """Test JavaScript code analysis"""
    content = (temp_codebase / "app.js").read_text()
    result = indexer._analyze_javascript(content)

    # Should find function
    assert any(f['name'] == 'greet' for f in result['functions'])

    # Should find class
    assert any(c['name'] == 'User' for c in result['classes'])


def test_full_analysis(indexer):
    """Test full codebase analysis"""
    results = indexer.analyze()

    # Check results
    assert results['files_indexed'] == 2
    assert results['total_lines'] > 0
    assert results['functions'] > 0

    # Check index data
    assert len(indexer.index_data['files']) == 2
    assert 'main.py' in str(indexer.index_data['files'])
    assert 'app.js' in str(indexer.index_data['files'])


def test_query(indexer):
    """Test query functionality"""
    # First analyze
    indexer.analyze()

    # Query for function
    results = indexer.query("hello")
    assert len(results['matches']) > 0
    assert 'hello' in results['matches'][0]['snippet'].lower()


def test_generate_map(indexer):
    """Test map generation"""
    # First analyze
    indexer.analyze()

    # Generate map
    map_data = indexer.generate_map()

    assert 'nodes' in map_data
    assert 'edges' in map_data
    assert 'stats' in map_data
    assert map_data['stats']['nodes'] > 0


def test_save_and_load(indexer, temp_codebase):
    """Test index persistence"""
    # Analyze and save
    indexer.analyze()

    # Load from disk
    loaded_indexer = CodebaseIndexer.load(temp_codebase / '.grid')

    # Check data persisted
    assert len(loaded_indexer.index_data['files']) == 2


def test_exclude_patterns(temp_codebase):
    """Test file exclusion"""
    # Create files to exclude
    (temp_codebase / "test.pyc").write_text("compiled")
    (temp_codebase / "node_modules").mkdir()
    (temp_codebase / "node_modules" / "lib.js").write_text("library")

    indexer = CodebaseIndexer(
        directory=temp_codebase,
        output_dir=temp_codebase / '.grid',
        exclude_patterns=['*.pyc', 'node_modules']
    )

    files = indexer._get_files_to_analyze()

    # Should not include excluded files
    assert not any('pyc' in f.name for f in files)
    assert not any('node_modules' in str(f) for f in files)
