"""Embeddings service module."""
