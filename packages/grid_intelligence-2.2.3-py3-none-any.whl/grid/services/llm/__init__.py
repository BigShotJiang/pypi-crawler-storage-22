"""LLM service module."""
