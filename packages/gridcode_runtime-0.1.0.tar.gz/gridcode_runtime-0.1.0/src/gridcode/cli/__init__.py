"""GridCode CLI - Command Line Interface for GridCode Runtime."""

from gridcode.cli.main import app

__all__ = ["app"]
