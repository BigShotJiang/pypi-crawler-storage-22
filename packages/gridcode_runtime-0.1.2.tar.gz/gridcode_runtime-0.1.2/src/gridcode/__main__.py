"""GridCode CLI entry point for `python -m gridcode`."""

from gridcode.cli.main import app

if __name__ == "__main__":
    app()
