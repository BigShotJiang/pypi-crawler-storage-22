"""Entry point for python -m gridcode.cli execution."""

from gridcode.cli.main import app

if __name__ == "__main__":
    app()
