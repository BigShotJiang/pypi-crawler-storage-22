from setuptools import setup

setup(  name= 'gridifys', 
        version='1.0.2', 
        description='gridifys', 
        packages=['gridifys'],
		author='ops',
		license="Python Script",
        install_requires = ["blessings ~= 1.7"],
        extras_require={
            "dev": [
                "pytest>=3.2",
            ],
        },
    )

