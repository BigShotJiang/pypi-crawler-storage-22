"""Reusable HuggingFace parameters."""
