"""Version 0.65.5 backward compatibility checks.

This version includes backward compatibility for removed parameters in
Flux2ImageGeneration: 'prompt_upsampling' and 'aspect_ratio'.
"""
