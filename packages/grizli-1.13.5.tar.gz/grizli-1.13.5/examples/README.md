23 May 2022
===========

Notebooks have been moved to https://github.com/gbrammer/grizli-notebooks.

For example, for the main pipeline functionality see [Grizli-Pipeline.ipynb](https://github.com/gbrammer/grizli-notebooks/blob/main/Grizli-Pipeline.ipynb).
