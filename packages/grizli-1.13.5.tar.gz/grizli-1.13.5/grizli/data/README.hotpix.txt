# SW additional hot pixels

jwst_nircam_newhot* from Chris Willott

Oringal filenames:

    jwst_nircam_newhot_a1_0062_extra20231129.fits     jwst_nircam_newhot_NRCA1_extra20231129.fits     
    jwst_nircam_newhot_a2_0068_extra20231129.fits     jwst_nircam_newhot_NRCA2_extra20231129.fits     
    jwst_nircam_newhot_a3_0067_extra20231129.fits     jwst_nircam_newhot_NRCA3_extra20231129.fits     
    jwst_nircam_newhot_a4_0066_extra20231129.fits     jwst_nircam_newhot_NRCA4_extra20231129.fits     
    jwst_nircam_newhot_b1_0060_extra20231129.fits     jwst_nircam_newhot_NRCB1_extra20231129.fits     
    jwst_nircam_newhot_b2_0064_extra20231129.fits     jwst_nircam_newhot_NRCB2_extra20231129.fits     
    jwst_nircam_newhot_b3_0069_extra20231129.fits     jwst_nircam_newhot_NRCB3_extra20231129.fits     
    jwst_nircam_newhot_b4_0061_extra20231129.fits     jwst_nircam_newhot_NRCB4_extra20231129.fits     
    jwst_nircam_newhot_blong_0065_extra20231129.fits  jwst_nircam_newhot_NRCBLONG_extra20231129.fits 
    jwst_nircam_newhot_along_0063_extra20231129.fits  jwst_nircam_newhot_NRCALONG_extra20231129.fits  