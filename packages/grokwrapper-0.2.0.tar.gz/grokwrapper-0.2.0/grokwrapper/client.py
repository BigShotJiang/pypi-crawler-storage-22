import time
import json
import random
import requests
from typing import Generator, Optional, Dict, Any
from bs4 import BeautifulSoup
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .config import config
from .exceptions import (
    RateLimitError,
    AuthenticationError,
    BlockedError,
    APIError,
    NetworkError,
    ParsingError,
    CAPTCHAError,
)
from .utils import (
    exponential_backoff,
    save_session,
    load_session,
    detect_captcha,
    detect_rate_limit,
    detect_block,
)


class GrokClient:
    def __init__(
        self,
        proxy: Optional[str] = None,
        user_agent: Optional[str] = None,
        timeout: Optional[int] = None,
        delay: Optional[float] = None,
        auto_retry: bool = True
    ):
        self.session = requests.Session()
        self.auto_retry = auto_retry
        
        # Load configuration
        self.proxy = proxy or config.proxy
        self.user_agent = user_agent or config.user_agent
        self.timeout = timeout or config.timeout
        self.delay = delay or config.request_delay
        
        # Setup session
        self._setup_session()
        
        # Load saved session if available
        self._load_saved_session()
        
        # Rate limiting
        self._last_request_time = 0.0
        
        # Statistics
        self._request_count = 0
    
    def _setup_session(self) -> None:
        """Configure session with headers, proxies, and retry logic"""
        # Headers
        self.session.headers.update({
            "User-Agent": self.user_agent,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "none",
        })
        
        # Proxy
        if self.proxy:
            self.session.proxies.update({
                "http": self.proxy,
                "https": self.proxy,
            })
        
        # Retry strategy
        retry_strategy = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["HEAD", "GET", "OPTIONS", "POST"]
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)
    
    def _load_saved_session(self) -> None:
        session_data = load_session(config.session_file)
        if session_data:
            if "cookies" in session_data:
                self.session.cookies.update(session_data["cookies"])
    
    def _save_session(self) -> None:
        session_data = {
            "cookies": dict(self.session.cookies),
            "last_updated": time.time(),
        }
        save_session(session_data, config.session_file)
    
    def _enforce_rate_limit(self) -> None:
        elapsed = time.time() - self._last_request_time
        if elapsed < self.delay:
            sleep_time = self.delay - elapsed + random.uniform(0.1, 0.5)
            time.sleep(sleep_time)
        self._last_request_time = time.time()
    
    def _check_response(self, response: requests.Response) -> None:
        if response.status_code == 401:
            raise AuthenticationError("Authentication failed. Session may have expired.")
        
        if response.status_code == 403:
            if detect_block(response.text):
                raise BlockedError("Access blocked. Your IP or session may be restricted.")
            raise AuthenticationError("Forbidden access.")
        
        if response.status_code == 429:
            raise RateLimitError("Rate limit exceeded. Please wait before making more requests.")
        
        if response.status_code >= 500:
            raise APIError(f"Server error: {response.status_code}")
        
        # Check for CAPTCHA
        if detect_captcha(response.text):
            raise CAPTCHAError("CAPTCHA detected. Cannot proceed automatically.")
        
        # Check for rate limiting in response body
        if detect_rate_limit(response.text):
            raise RateLimitError("Rate limit detected in response.")
    
    def _parse_chat_response(self, html: str) -> str:
        try:
            soup = BeautifulSoup(html, "html.parser")
            
            # Try multiple selectors (Grok's actual structure may vary)
            selectors = [
                '[data-testid="chat-response"]',
                '.chat-response',
                '[class*="response"]',
                'div[data-message-type="assistant"]',
                'div[role="presentation"]',
            ]
            
            for selector in selectors:
                element = soup.select_one(selector)
                if element:
                    return element.get_text(strip=True)
            
            # Fallback: look for any div with response-like content
            response_divs = soup.find_all("div")
            for div in response_divs:
                text = div.get_text(strip=True)
                if len(text) > 10 and not any(x in text.lower() for x in ["login", "sign in", "error"]):
                    return text
            
            raise ParsingError("Could not find response in HTML")
            
        except Exception as e:
            raise ParsingError(f"Failed to parse response: {e}")
    
    def _parse_stream_chunk(self, line: str) -> Optional[str]:
        try:
            # Try to parse as JSON
            if line.startswith("data: "):
                data = json.loads(line[6:])
                if "content" in data:
                    return data["content"]
            return None
        except (json.JSONDecodeError, ValueError):
            return None
    
    def chat(self, prompt: str, model: str = "grok-3") -> str:
        self._enforce_rate_limit()
        
        for attempt in range(config.max_retries if self.auto_retry else 1):
            try:
                # Prepare request
                payload = {
                    "messages": [{"role": "user", "content": prompt}],
                    "model": model,
                }
                
                response = self.session.post(
                    config.chat_endpoint,
                    json=payload,
                    timeout=self.timeout,
                )
                
                self._check_response(response)
                
                # Parse response
                if response.headers.get("Content-Type", "").startswith("application/json"):
                    data = response.json()
                    if "choices" in data and len(data["choices"]) > 0:
                        return data["choices"][0]["message"]["content"]
                else:
                    return self._parse_chat_response(response.text)
                
            except (requests.RequestException, requests.ConnectionError) as e:
                if attempt < config.max_retries - 1:
                    delay = exponential_backoff(attempt, config.retry_delay)
                    time.sleep(delay)
                    continue
                raise NetworkError(f"Network error: {e}")
            except (RateLimitError, AuthenticationError, BlockedError, CAPTCHAError) as e:
                raise
            except Exception as e:
                if attempt < config.max_retries - 1:
                    delay = exponential_backoff(attempt, config.retry_delay)
                    time.sleep(delay)
                    continue
                raise APIError(f"Unexpected error: {e}")
        
        raise APIError("Max retries exceeded")
    
    def stream_chat(self, prompt: str, model: str = "grok-3") -> Generator[str, None, None]:
        self._enforce_rate_limit()
        
        for attempt in range(config.max_retries if self.auto_retry else 1):
            try:
                payload = {
                    "messages": [{"role": "user", "content": prompt}],
                    "model": model,
                    "stream": True,
                }
                
                with self.session.post(
                    config.stream_endpoint,
                    json=payload,
                    stream=True,
                    timeout=self.timeout,
                ) as response:
                    self._check_response(response)
                    
                    for line in response.iter_lines():
                        if line:
                            chunk = self._parse_stream_chunk(line.decode("utf-8"))
                            if chunk:
                                yield chunk
                    return
                    
            except (requests.RequestException, requests.ConnectionError) as e:
                if attempt < config.max_retries - 1:
                    delay = exponential_backoff(attempt, config.retry_delay)
                    time.sleep(delay)
                    continue
                raise NetworkError(f"Network error: {e}")
            except (RateLimitError, AuthenticationError, BlockedError, CAPTCHAError) as e:
                raise
            except Exception as e:
                if attempt < config.max_retries - 1:
                    delay = exponential_backoff(attempt, config.retry_delay)
                    time.sleep(delay)
                    continue
                raise APIError(f"Unexpected error: {e}")
        
        raise APIError("Max retries exceeded")
    
    def generate_image(self, prompt: str) -> str:
        raise NotImplementedError("Image generation is not yet supported")
    
    def get_stats(self) -> Dict[str, Any]:
        return {
            "requests_made": self._request_count,
            "proxy_enabled": bool(self.proxy),
            "session_active": len(self.session.cookies) > 0,
        }
    
    def close(self) -> None:
        self._save_session()
        self.session.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()