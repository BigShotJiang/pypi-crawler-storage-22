import os
from typing import Optional
from dotenv import load_dotenv

load_dotenv()


class Config:
    """Configuration manager for GrokWrapper"""
    
    def __init__(self):
        self.proxy: Optional[str] = os.getenv("GROK_PROXY")
        self.user_agent: str = os.getenv(
            "USER_AGENT",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        )
        self.request_delay: float = float(os.getenv("REQUEST_DELAY", "2.0"))
        self.timeout: int = int(os.getenv("REQUEST_TIMEOUT", "30"))
        self.base_url: str = "https://grok.x.ai"
        self.api_endpoint: str = f"{self.base_url}/api"
        self.chat_endpoint: str = f"{self.api_endpoint}/chat"
        self.stream_endpoint: str = f"{self.api_endpoint}/chat/stream"
        self.image_endpoint: str = f"{self.api_endpoint}/image/generate"
        
        # Session management
        self.session_file: str = ".grok_session.json"
        
        # Retry settings
        self.max_retries: int = 3
        self.retry_delay: float = 5.0


config = Config()