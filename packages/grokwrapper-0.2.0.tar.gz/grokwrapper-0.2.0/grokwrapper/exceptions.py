class GrokError(Exception):
    """Base exception for all GrokWrapper errors"""
    pass


class RateLimitError(GrokError):
    """Raised when rate limit is exceeded"""
    pass


class AuthenticationError(GrokError):
    """Raised when authentication fails"""
    pass


class BlockedError(GrokError):
    """Raised when IP or session is blocked"""
    pass


class APIError(GrokError):
    """Raised when API returns an error"""
    pass


class NetworkError(GrokError):
    """Raised when network request fails"""
    pass


class ParsingError(GrokError):
    """Raised when response parsing fails"""
    pass


class CAPTCHAError(GrokError):
    """Raised when CAPTCHA is required"""
    pass