import time
import json
import random
import string
from typing import Dict, Any, Optional
from pathlib import Path


def generate_random_string(length: int = 16) -> str:
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))


def exponential_backoff(attempt: int, base_delay: float = 1.0, max_delay: float = 60.0) -> float:
    delay = min(base_delay * (2 ** attempt), max_delay)
    return delay + random.uniform(0, 0.1 * delay)


def save_session(session_data: Dict[str, Any], filepath: str = ".grok_session.json") -> None:
    try:
        with open(filepath, 'w') as f:
            json.dump(session_data, f, indent=2)
    except Exception:
        pass  # Fail silently


def load_session(filepath: str = ".grok_session.json") -> Optional[Dict[str, Any]]:
    try:
        if Path(filepath).exists():
            with open(filepath, 'r') as f:
                return json.load(f)
    except Exception:
        pass
    return None


def detect_captcha(html: str) -> bool:
    captcha_indicators = [
        "captcha",
        "verify you're human",
        "recaptcha",
        "hcaptcha",
        "please verify",
    ]
    html_lower = html.lower()
    return any(indicator in html_lower for indicator in captcha_indicators)


def detect_rate_limit(html: str) -> bool:
    rate_limit_indicators = [
        "rate limit",
        "too many requests",
        "429",
        "slow down",
        "try again later",
    ]
    html_lower = html.lower()
    return any(indicator in html_lower for indicator in rate_limit_indicators)


def detect_block(html: str) -> bool:
    block_indicators = [
        "blocked",
        "access denied",
        "forbidden",
        "403",
        "suspicious activity",
    ]
    html_lower = html.lower()
    return any(indicator in html_lower for indicator in block_indicators)