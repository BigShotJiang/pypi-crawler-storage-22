"""Configuration for GrowFlow Billing Client."""

import os
from dataclasses import dataclass


@dataclass
class GrowFlowConfig:
    """Configuration settings for the GrowFlow Billing Client."""

    api_key: str
    base_url: str = "https://billing.growflow.studio/api/v1"
    timeout: float = 30.0
    max_retries: int = 3
    retry_delay: float = 1.0

    @classmethod
    def from_env(cls) -> "GrowFlowConfig":
        """Create config from environment variables.

        Environment variables:
            GROWFLOW_BILLING_API_KEY: API key (required)
            GROWFLOW_BILLING_URL: Base URL (optional)
            GROWFLOW_BILLING_TIMEOUT: Timeout in seconds (optional)
        """
        api_key = os.environ.get("GROWFLOW_BILLING_API_KEY")
        if not api_key:
            raise ValueError("GROWFLOW_BILLING_API_KEY environment variable is required")

        return cls(
            api_key=api_key,
            base_url=os.environ.get(
                "GROWFLOW_BILLING_URL", "https://billing.growflow.studio/api/v1"
            ),
            timeout=float(os.environ.get("GROWFLOW_BILLING_TIMEOUT", "30.0")),
        )
