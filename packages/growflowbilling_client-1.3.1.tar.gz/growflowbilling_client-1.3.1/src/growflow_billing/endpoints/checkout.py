"""Checkout and portal session API endpoint mixin."""

from typing import TYPE_CHECKING, Any

from growflow_billing.models.checkout import CheckoutSession, PortalSession

if TYPE_CHECKING:
    from growflow_billing.client import GrowFlowBillingClient


class CheckoutMixin:
    """Mixin for checkout and portal session API calls."""

    async def create_checkout_session(
        self: "GrowFlowBillingClient",
        customer_external_id: str,
        plan_slug: str,
        success_url: str,
        cancel_url: str,
        billing_cycle: str = "monthly",
        email: str | None = None,
        name: str | None = None,
        company_name: str | None = None,
        vat_number: str | None = None,
        coupon_code: str | None = None,
        custom_data: dict[str, Any] | None = None,
    ) -> CheckoutSession:
        """Create a Stripe checkout session for subscription.

        Args:
            customer_external_id: Your internal customer ID
            plan_slug: Plan to subscribe to (e.g., "pro")
            success_url: URL to redirect on successful payment
            cancel_url: URL to redirect if user cancels
            billing_cycle: "monthly" or "yearly" (default: "monthly")
            email: Customer email (for new subscribers)
            name: Customer name (for new subscribers)
            company_name: Company name
            vat_number: VAT/Tax ID
            coupon_code: Discount coupon code
            custom_data: Custom metadata to store

        Returns:
            CheckoutSession with checkout_url to redirect user

        Example:
            session = await client.create_checkout_session(
                customer_external_id="store_123",
                plan_slug="pro",
                billing_cycle="monthly",
                success_url="https://app.com/billing?status=success",
                cancel_url="https://app.com/billing?status=canceled",
            )
            # Redirect user to: session.checkout_url
        """
        payload: dict[str, Any] = {
            "external_id": customer_external_id,
            "plan_slug": plan_slug,
            "billing_cycle": billing_cycle,
            "success_url": success_url,
            "cancel_url": cancel_url,
        }
        if email:
            payload["email"] = email
        if name:
            payload["name"] = name
        if company_name:
            payload["company_name"] = company_name
        if vat_number:
            payload["vat_number"] = vat_number
        if coupon_code:
            payload["coupon_code"] = coupon_code
        if custom_data:
            payload["custom_data"] = custom_data

        response = await self._request("POST", "/public/checkout", json=payload)
        return CheckoutSession(**response)

    async def create_portal_session(
        self: "GrowFlowBillingClient",
        customer_external_id: str,
        return_url: str,
    ) -> PortalSession:
        """Create a Stripe customer portal session.

        The portal allows customers to:
        - Update payment method
        - View invoices
        - Cancel subscription
        - Change plan (if configured)

        Args:
            customer_external_id: Your internal customer ID
            return_url: URL to redirect after portal session

        Returns:
            PortalSession with portal_url to redirect user

        Example:
            portal = await client.create_portal_session(
                customer_external_id="store_123",
                return_url="https://app.com/billing"
            )
            # Redirect user to: portal.portal_url
        """
        response = await self._request(
            "POST",
            "/checkout/portal",
            json={
                "subscriber_external_id": customer_external_id,
                "return_url": return_url,
            },
        )
        return PortalSession(**response)
