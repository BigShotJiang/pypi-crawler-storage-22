"""Plans API endpoint mixin."""

from typing import TYPE_CHECKING

from growflow_billing.models.plan import Plan

if TYPE_CHECKING:
    from growflow_billing.client import GrowFlowBillingClient


class PlansMixin:
    """Mixin for plans-related API calls."""

    async def get_plans(self: "GrowFlowBillingClient", is_active: bool = True) -> list[Plan]:
        """Get available subscription plans.

        Args:
            is_active: Filter by active status (default: True)

        Returns:
            List of Plan objects

        Example:
            plans = await client.get_plans()
            for plan in plans:
                print(f"{plan.name}: {plan.price_monthly}")
        """
        response = await self._request(
            "GET",
            "/plans",
            params={"is_active": str(is_active).lower()},
        )
        return [Plan(**p) for p in response]

    async def get_plan(self: "GrowFlowBillingClient", plan_slug: str) -> Plan | None:
        """Get a specific plan by slug.

        Args:
            plan_slug: Plan identifier (e.g., "pro")

        Returns:
            Plan object or None if not found
        """
        plans = await self.get_plans()
        for plan in plans:
            if plan.slug == plan_slug:
                return plan
        return None
