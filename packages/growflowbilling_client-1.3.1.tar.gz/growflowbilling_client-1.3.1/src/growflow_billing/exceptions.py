"""Custom exceptions for GrowFlow Billing Client."""

from typing import Any


class GrowFlowBillingError(Exception):
    """Base exception for all GrowFlow Billing errors."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        response: dict[str, Any] | None = None,
    ) -> None:
        self.message = message
        self.status_code = status_code
        self.response = response
        super().__init__(message)

    def __str__(self) -> str:
        if self.status_code:
            return f"[{self.status_code}] {self.message}"
        return self.message


class AuthenticationError(GrowFlowBillingError):
    """Raised when API key is invalid or missing."""

    pass


class NotFoundError(GrowFlowBillingError):
    """Raised when a requested resource is not found."""

    pass


class ConflictError(GrowFlowBillingError):
    """Raised when a resource already exists (409 Conflict)."""

    pass


class ValidationError(GrowFlowBillingError):
    """Raised when request data is invalid (422 Unprocessable Entity)."""

    pass


class RateLimitError(GrowFlowBillingError):
    """Raised when rate limit is exceeded (429 Too Many Requests)."""

    pass


class ServerError(GrowFlowBillingError):
    """Raised when server returns 5xx error."""

    pass
