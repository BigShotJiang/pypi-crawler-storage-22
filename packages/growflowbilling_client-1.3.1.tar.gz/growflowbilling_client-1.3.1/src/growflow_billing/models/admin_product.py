"""Admin Product model for product management."""

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


class AdminProduct(BaseModel):
    """Admin-managed product in GrowFlow Billing.

    This model represents products that are managed via the admin API,
    typically used for add-ons, one-time purchases, or feature unlocks.
    """

    id: str = Field(..., description="Product ID (UUID)")
    name: str = Field(..., description="Product name")
    description: str | None = Field(default=None, description="Product description")
    price_cents: int = Field(..., description="Price in cents (e.g., 1999 for €19.99)")
    currency: str = Field(default="eur", description="Currency code")
    recurring_interval: str | None = Field(
        default=None,
        description="Billing interval: 'month', 'year', or None for one-time"
    )
    category: str | None = Field(default=None, description="Product category")
    feature_slug: str | None = Field(
        default=None,
        description="Feature slug for access control"
    )
    extra_data: dict[str, Any] | None = Field(
        default=None,
        description="Additional metadata"
    )
    is_active: bool = Field(default=True, description="Is product active")

    # Stripe sync fields
    stripe_product_id: str | None = Field(
        default=None,
        description="Stripe product ID (if synced)"
    )
    stripe_price_id: str | None = Field(
        default=None,
        description="Stripe price ID (if synced)"
    )

    # Timestamps
    created_at: datetime | None = Field(default=None, description="Creation timestamp")
    updated_at: datetime | None = Field(default=None, description="Last update timestamp")

    @property
    def price_decimal(self) -> float:
        """Get price as decimal (not cents)."""
        return self.price_cents / 100

    @property
    def is_recurring(self) -> bool:
        """Check if product has recurring billing."""
        return self.recurring_interval is not None

    @property
    def is_synced_to_stripe(self) -> bool:
        """Check if product is synced to Stripe."""
        return self.stripe_product_id is not None and self.stripe_price_id is not None

    class Config:
        from_attributes = True
