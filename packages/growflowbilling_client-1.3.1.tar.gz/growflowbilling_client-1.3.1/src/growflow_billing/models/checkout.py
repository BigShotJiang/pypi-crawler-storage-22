"""Checkout and portal session models."""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field


class CheckoutSession(BaseModel):
    """Stripe checkout session."""

    checkout_url: str = Field(..., description="URL to redirect user to Stripe checkout")
    session_id: str = Field(..., description="Stripe session ID")
    expires_at: datetime | None = Field(default=None, description="Session expiration time")
    subscriber_id: UUID | None = Field(default=None, description="GrowFlow subscriber ID")
    is_new_subscriber: bool = Field(default=False, description="Whether subscriber was created")

    class Config:
        from_attributes = True


class PortalSession(BaseModel):
    """Stripe customer portal session."""

    portal_url: str = Field(..., description="URL to redirect user to Stripe portal")
    session_id: str | None = Field(default=None, description="Portal session ID")
    return_url: str | None = Field(default=None, description="Return URL after portal")

    class Config:
        from_attributes = True


class CheckoutRequest(BaseModel):
    """Request data for creating a checkout session."""

    customer_external_id: str = Field(..., description="Your internal customer ID")
    plan_slug: str = Field(..., description="Plan to subscribe to")
    billing_cycle: str = Field(default="monthly", description="monthly or yearly")
    success_url: str = Field(..., description="Redirect URL on success")
    cancel_url: str = Field(..., description="Redirect URL on cancel")
    email: str | None = Field(default=None, description="Customer email (for new subscribers)")
    name: str | None = Field(default=None, description="Customer name (for new subscribers)")
    company_name: str | None = Field(default=None, description="Company name")
    vat_number: str | None = Field(default=None, description="VAT number")
    coupon_code: str | None = Field(default=None, description="Discount coupon code")


class PortalRequest(BaseModel):
    """Request data for creating a portal session."""

    customer_external_id: str = Field(..., description="Your internal customer ID")
    return_url: str = Field(..., description="Return URL after portal")
