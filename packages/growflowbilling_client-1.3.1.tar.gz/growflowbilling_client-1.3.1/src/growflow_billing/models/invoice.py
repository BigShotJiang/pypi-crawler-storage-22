"""Invoice models."""

from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class InvoiceStatus(str, Enum):
    """Invoice status values."""

    DRAFT = "draft"
    OPEN = "open"
    PAID = "paid"
    VOID = "void"
    UNCOLLECTIBLE = "uncollectible"


class InvoiceLineItem(BaseModel):
    """Invoice line item."""

    description: str | None = Field(default=None)
    quantity: int = Field(default=1)
    amount: int = Field(..., description="Amount in cents")
    currency: str = Field(default="eur")


class Invoice(BaseModel):
    """Invoice record."""

    id: str = Field(..., description="Invoice ID (Stripe ID)")
    number: str | None = Field(default=None, description="Invoice number")
    status: InvoiceStatus | str | None = Field(default=None, description="Invoice status")
    amount_due: int = Field(default=0, description="Amount due in cents")
    amount_paid: int = Field(default=0, description="Amount paid in cents")
    amount_remaining: int = Field(default=0, description="Amount remaining in cents")
    subtotal: int = Field(default=0, description="Subtotal in cents")
    tax: int | None = Field(default=None, description="Tax amount in cents")
    total: int = Field(default=0, description="Total in cents")
    currency: str = Field(default="eur", description="Currency code")
    description: str | None = Field(default=None, description="Invoice description")
    customer_email: str | None = Field(default=None, description="Customer email")
    customer_name: str | None = Field(default=None, description="Customer name")
    hosted_invoice_url: str | None = Field(default=None, description="Stripe hosted page URL")
    invoice_pdf: str | None = Field(default=None, description="PDF download URL")
    line_items: list[InvoiceLineItem] | None = Field(default=None, description="Line items")
    metadata: dict[str, Any] | None = Field(default=None, description="Metadata")
    due_date: datetime | None = Field(default=None, description="Due date")
    paid_at: datetime | None = Field(default=None, description="Payment timestamp")
    created: int | None = Field(default=None, description="Creation timestamp (Unix)")
    created_at: datetime | None = Field(default=None, description="Creation timestamp")

    @property
    def is_paid(self) -> bool:
        """Check if invoice is paid."""
        return self.status == InvoiceStatus.PAID or self.status == "paid"

    @property
    def is_open(self) -> bool:
        """Check if invoice is open/unpaid."""
        return self.status == InvoiceStatus.OPEN or self.status == "open"

    @property
    def amount_paid_decimal(self) -> float:
        """Get amount paid as decimal (not cents)."""
        return self.amount_paid / 100

    @property
    def amount_due_decimal(self) -> float:
        """Get amount due as decimal (not cents)."""
        return self.amount_due / 100

    @property
    def total_decimal(self) -> float:
        """Get total as decimal (not cents)."""
        return self.total / 100

    class Config:
        from_attributes = True
