"""Product and price models for add-on purchases."""

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


class Price(BaseModel):
    """Product price."""

    id: str = Field(..., description="Price ID")
    product_id: str = Field(..., description="Product ID")
    unit_amount: int = Field(..., description="Price in cents")
    currency: str = Field(default="eur", description="Currency code")
    recurring: bool = Field(default=False, description="Is recurring price")
    interval: str | None = Field(default=None, description="Billing interval if recurring")
    active: bool = Field(default=True, description="Is price active")

    @property
    def amount_decimal(self) -> float:
        """Get amount as decimal (not cents)."""
        return self.unit_amount / 100

    class Config:
        from_attributes = True


class Product(BaseModel):
    """Product for add-on purchases."""

    id: str = Field(..., description="Product ID")
    name: str = Field(..., description="Product name")
    description: str | None = Field(default=None, description="Product description")
    active: bool = Field(default=True, description="Is product active")
    prices: list[Price] | None = Field(default=None, description="Available prices")
    default_price_id: str | None = Field(default=None, description="Default price ID")
    metadata: dict[str, Any] | None = Field(default=None, description="Product metadata")
    images: list[str] | None = Field(default=None, description="Product images")
    created_at: datetime | None = Field(default=None, description="Creation timestamp")

    @property
    def default_price(self) -> Price | None:
        """Get default price object."""
        if not self.prices or not self.default_price_id:
            return None
        for price in self.prices:
            if price.id == self.default_price_id:
                return price
        return self.prices[0] if self.prices else None

    class Config:
        from_attributes = True


class ProductCheckoutRequest(BaseModel):
    """Request for product checkout."""

    customer_external_id: str = Field(..., description="Your internal customer ID")
    price_id: str = Field(..., description="Price ID to purchase")
    quantity: int = Field(default=1, ge=1, description="Quantity")
    success_url: str = Field(..., description="Redirect URL on success")
    cancel_url: str = Field(..., description="Redirect URL on cancel")


class ProductCheckoutSession(BaseModel):
    """Product checkout session."""

    checkout_url: str = Field(..., description="URL to redirect to Stripe checkout")
    session_id: str = Field(..., description="Stripe session ID")

    class Config:
        from_attributes = True
