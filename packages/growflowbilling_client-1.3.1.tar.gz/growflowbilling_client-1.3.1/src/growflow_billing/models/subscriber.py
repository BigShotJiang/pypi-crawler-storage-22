"""Subscriber models."""

from datetime import datetime
from typing import Any, Literal
from uuid import UUID

from pydantic import BaseModel, EmailStr, Field


class BillingAddress(BaseModel):
    """Billing address."""

    line1: str | None = Field(default=None, description="Street address line 1")
    line2: str | None = Field(default=None, description="Street address line 2")
    city: str | None = Field(default=None, description="City")
    state: str | None = Field(default=None, description="State/Province")
    postal_code: str | None = Field(default=None, description="Postal/ZIP code")
    country: str | None = Field(default=None, description="Country code (ISO 3166-1 alpha-2)")


class Subscriber(BaseModel):
    """Billing subscriber (customer)."""

    id: UUID | None = Field(default=None, description="GrowFlow internal ID")
    external_id: str = Field(..., description="Your internal customer ID")
    email: EmailStr = Field(..., description="Subscriber email")
    name: str | None = Field(default=None, description="Subscriber name")

    # Customer type
    customer_type: Literal["individual", "business"] = Field(
        default="individual", description="Customer type: individual or business",
    )

    # Individual (Persona Fisica) fields
    first_name: str | None = Field(default=None, description="First name")
    last_name: str | None = Field(default=None, description="Last name")
    fiscal_code: str | None = Field(
        default=None, description="Italian tax ID (Codice Fiscale)",
    )

    # Business (Azienda) fields
    company_name: str | None = Field(default=None, description="Company name")
    vat_number: str | None = Field(
        default=None, description="VAT/Tax ID (Partita IVA)",
    )
    pec_email: EmailStr | None = Field(
        default=None, description="PEC email for electronic invoicing",
    )
    sdi_code: str | None = Field(
        default=None, description="SDI code (Sistema di Interscambio)",
    )

    # Contact
    phone: str | None = Field(default=None, description="Contact phone number")

    # Billing
    billing_address: BillingAddress | None = Field(default=None, description="Billing address")
    stripe_customer_id: str | None = Field(default=None, description="Stripe customer ID")
    custom_data: dict[str, Any] | None = Field(default=None, description="Custom metadata")
    is_active: bool = Field(default=True, description="Is subscriber active")
    created_at: datetime | None = Field(default=None, description="Creation timestamp")
    updated_at: datetime | None = Field(default=None, description="Last update timestamp")

    class Config:
        from_attributes = True


class SubscriberCreate(BaseModel):
    """Data for creating a new subscriber."""

    external_id: str = Field(..., description="Your internal customer ID")
    email: EmailStr = Field(..., description="Subscriber email")
    name: str | None = Field(default=None, description="Subscriber name")

    # Customer type
    customer_type: Literal["individual", "business"] | None = Field(
        default=None, description="Customer type: individual or business",
    )

    # Individual fields
    first_name: str | None = Field(default=None, description="First name")
    last_name: str | None = Field(default=None, description="Last name")
    fiscal_code: str | None = Field(
        default=None, description="Italian tax ID (Codice Fiscale)",
    )

    # Business fields
    company_name: str | None = Field(default=None, description="Company name")
    vat_number: str | None = Field(
        default=None, description="VAT/Tax ID (Partita IVA)",
    )
    pec_email: EmailStr | None = Field(
        default=None, description="PEC email for electronic invoicing",
    )
    sdi_code: str | None = Field(
        default=None, description="SDI code (Sistema di Interscambio)",
    )

    # Contact
    phone: str | None = Field(default=None, description="Contact phone number")

    # Other
    billing_address: BillingAddress | None = Field(default=None, description="Billing address")
    custom_data: dict[str, Any] | None = Field(default=None, description="Custom metadata")
