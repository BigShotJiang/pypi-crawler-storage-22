"""Pytest configuration and fixtures."""

import pytest
import respx

from growflow_billing import GrowFlowBillingClient


@pytest.fixture
def api_key() -> str:
    """Test API key."""
    return "sk_test_growflow_test_key"


@pytest.fixture
def base_url() -> str:
    """Test base URL."""
    return "https://billing.growflow.studio/api/v1"


@pytest.fixture
async def client(api_key: str, base_url: str):
    """GrowFlow Billing client fixture."""
    async with GrowFlowBillingClient(api_key=api_key, base_url=base_url) as client:
        yield client


@pytest.fixture
def mock_api(base_url: str):
    """Mock API fixture using respx."""
    with respx.mock(base_url=base_url, assert_all_called=False) as respx_mock:
        yield respx_mock
