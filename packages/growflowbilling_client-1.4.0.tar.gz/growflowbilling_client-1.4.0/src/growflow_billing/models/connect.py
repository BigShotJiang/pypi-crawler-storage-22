"""Stripe Connect models."""

from pydantic import BaseModel, Field


class ConnectAccount(BaseModel):
    """Stripe Connect Express account."""

    id: str = Field(..., description="Stripe account ID (acct_xxx)")
    email: str = Field(..., description="Account email")
    country: str = Field(default="IT", description="Two-letter country code")
    business_type: str = Field(default="individual", description="Account business type")
    charges_enabled: bool = Field(default=False, description="Whether charges are enabled")
    payouts_enabled: bool = Field(default=False, description="Whether payouts are enabled")
    details_submitted: bool = Field(default=False, description="Whether onboarding is complete")
    created_at: str | None = Field(default=None, description="Creation timestamp")
    metadata: dict[str, str] = Field(default_factory=dict, description="Account metadata")

    @property
    def is_fully_onboarded(self) -> bool:
        """Check if account has completed onboarding."""
        return self.charges_enabled and self.payouts_enabled and self.details_submitted

    class Config:
        from_attributes = True


class ConnectAccountLink(BaseModel):
    """Stripe Account Link for onboarding."""

    url: str = Field(..., description="Onboarding URL")
    expires_at: str | None = Field(default=None, description="Link expiration timestamp")


class ConnectLoginLink(BaseModel):
    """Stripe Express dashboard login link."""

    url: str = Field(..., description="Dashboard login URL")
    created: str | None = Field(default=None, description="Creation timestamp")


class ConnectTransfer(BaseModel):
    """Stripe transfer to a Connect account."""

    id: str = Field(..., description="Transfer ID (tr_xxx)")
    amount: int = Field(..., description="Amount in cents")
    currency: str = Field(default="eur", description="Three-letter currency code")
    destination: str = Field(..., description="Destination account ID")
    description: str | None = Field(default=None, description="Transfer description")
    created_at: str | None = Field(default=None, description="Creation timestamp")

    @property
    def amount_decimal(self) -> float:
        """Get amount as decimal (e.g., 1000 -> 10.00)."""
        return self.amount / 100

    class Config:
        from_attributes = True


class ConnectBalance(BaseModel):
    """Balance for a Connect account."""

    available: list[dict[str, int | str]] = Field(
        default_factory=list, description="Available balance per currency"
    )
    pending: list[dict[str, int | str]] = Field(
        default_factory=list, description="Pending balance per currency"
    )


class ConnectAccountsPage(BaseModel):
    """Paginated list of Connect accounts."""

    data: list[ConnectAccount] = Field(default_factory=list, description="Account list")
    has_more: bool = Field(default=False, description="Whether more results exist")


class ConnectTransfersPage(BaseModel):
    """Paginated list of Connect transfers."""

    data: list[ConnectTransfer] = Field(default_factory=list, description="Transfer list")
    has_more: bool = Field(default=False, description="Whether more results exist")
