# Publishing growflowbooking-client (Python SDK)

## Overview

The Python SDK is published to PyPI as `growflowbooking-client`.
Publishing is automated via GitHub Actions on push to `main` when files in `sdk/python/` change.

**Note**: The distribution name is `growflowbooking-client` but the Python import path remains `growflow_booking`:

```python
from growflow_booking import GrowFlowBookingClient
```

## How It Works

1. **Version detection**: CI compares `pyproject.toml` version against the published PyPI version
2. **If version changed**: lint, type-check, test, build, publish to PyPI, create git tag
3. **If version unchanged**: CI skips publishing

## Publishing a New Version

```bash
cd sdk/python

# 1. Make your changes
# 2. Bump version in pyproject.toml

# 3. Commit and push
git add pyproject.toml
git commit -m "chore(sdk): bump booking python SDK to vX.Y.Z"
git push origin main
```

CI will automatically:
- Run `ruff` linting and `mypy` type checking
- Run `pytest`
- Build with `python -m build`
- Publish to PyPI via OIDC Trusted Publisher (no tokens needed)
- Create a git tag `growflowbooking-python-sdk-vX.Y.Z`

## PyPI Trusted Publisher (OIDC)

Publishing uses PyPI's Trusted Publisher mechanism — no API tokens required.

**Setup (one-time, already done):**
1. PyPI → Manage → Publishing → Add trusted publisher for `growflowbooking-client`
   - Owner: `giuliogarofalo`, Repo: `growflow-booking`, Workflow: `publish-python-sdk.yml`, Environment: `pypi`
2. GitHub → `growflow-booking` repo → Settings → Environments → Create `pypi` environment

## Consumer Usage

```bash
pip install growflowbooking-client
```

```python
from growflow_booking import GrowFlowBookingClient

async with GrowFlowBookingClient(base_url="...", api_key="...") as client:
    tenants = await client.get_tenants()
```
