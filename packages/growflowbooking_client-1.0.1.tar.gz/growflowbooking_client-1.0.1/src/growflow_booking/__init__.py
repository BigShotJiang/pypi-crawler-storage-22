"""GrowFlow Booking SDK - Python client for GrowFlow Booking API."""

from growflow_booking.client import GrowFlowBookingClient
from growflow_booking.config import GrowFlowBookingConfig
from growflow_booking.exceptions import (
    AuthenticationError,
    ConflictError,
    GrowFlowBookingError,
    NotFoundError,
    QuotaExhaustedError,
    RateLimitError,
    ServerError,
    SlotUnavailableError,
    ValidationError,
)
from growflow_booking.models import (
    AvailableDate,
    AvailableSlots,
    Booking,
    BookingResult,
    BookingStatus,
    Branding,
    Customer,
    CustomerCredits,
    Quota,
    Service,
    Tenant,
    TenantPublic,
    TimeSlot,
)

__version__ = "1.0.0"

__all__ = [
    # Client
    "GrowFlowBookingClient",
    "GrowFlowBookingConfig",
    # Exceptions
    "GrowFlowBookingError",
    "AuthenticationError",
    "NotFoundError",
    "ConflictError",
    "ValidationError",
    "RateLimitError",
    "ServerError",
    "QuotaExhaustedError",
    "SlotUnavailableError",
    # Models
    "Tenant",
    "TenantPublic",
    "Service",
    "Branding",
    "Booking",
    "BookingResult",
    "BookingStatus",
    "TimeSlot",
    "AvailableDate",
    "AvailableSlots",
    "Customer",
    "Quota",
    "CustomerCredits",
]
