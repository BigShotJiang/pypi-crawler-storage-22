"""GrowFlow Booking Client - Main client class."""

import asyncio
from typing import Any

import httpx

from growflow_booking.config import GrowFlowBookingConfig
from growflow_booking.endpoints.availability import AvailabilityMixin
from growflow_booking.endpoints.bookings import BookingsMixin
from growflow_booking.endpoints.customers import CustomersMixin
from growflow_booking.endpoints.quotas import QuotasMixin
from growflow_booking.endpoints.tenants import TenantsMixin
from growflow_booking.exceptions import (
    AuthenticationError,
    ConflictError,
    GrowFlowBookingError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)


class GrowFlowBookingClient(
    TenantsMixin,
    BookingsMixin,
    AvailabilityMixin,
    CustomersMixin,
    QuotasMixin,
):
    """Async HTTP client for GrowFlow Booking API.

    Usage as context manager (recommended):
        async with GrowFlowBookingClient(api_key="bk_live_xxx") as client:
            slots = await client.get_available_slots("my-business", "2024-03-15")

    Usage without context manager:
        client = GrowFlowBookingClient(api_key="bk_live_xxx")
        try:
            slots = await client.get_available_slots("my-business", "2024-03-15")
        finally:
            await client.close()

    Args:
        api_key: GrowFlow Booking API key (bk_xxx)
        base_url: API base URL (default: https://booking.growflow.studio/api/v1)
        timeout: Request timeout in seconds (default: 30.0)
        max_retries: Maximum retry attempts for failed requests (default: 3)
        retry_delay: Base delay between retries in seconds (default: 1.0)

    Example:
        async with GrowFlowBookingClient(api_key="bk_live_xxx") as client:
            # Get available slots
            slots = await client.get_available_slots(
                tenant_slug="my-business",
                date="2024-03-15",
                service_id="uuid-here",
            )

            # Create a booking
            result = await client.create_simple_booking(
                tenant_slug="my-business",
                service_id="uuid-here",
                date="2024-03-15",
                slot="10:00",
                customer_name="Mario Rossi",
                customer_email="mario@example.com",
            )
            if result.success:
                print(f"Booking code: {result.booking.booking_code}")
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str = "https://booking.growflow.studio/api/v1",
        timeout: float = 30.0,
        max_retries: int = 3,
        retry_delay: float = 1.0,
    ) -> None:
        if api_key:
            self.config = GrowFlowBookingConfig(
                api_key=api_key,
                base_url=base_url,
                timeout=timeout,
                max_retries=max_retries,
                retry_delay=retry_delay,
            )
        else:
            # Try to load from environment
            self.config = GrowFlowBookingConfig.from_env()
            self.config.base_url = base_url
            self.config.timeout = timeout
            self.config.max_retries = max_retries
            self.config.retry_delay = retry_delay

        self._client: httpx.AsyncClient | None = None

    async def __aenter__(self) -> "GrowFlowBookingClient":
        """Enter async context manager."""
        self._client = httpx.AsyncClient(
            base_url=self.config.base_url,
            timeout=self.config.timeout,
            headers=self._get_headers(),
        )
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Exit async context manager."""
        await self.close()

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client:
            await self._client.aclose()
            self._client = None

    def _get_headers(self) -> dict[str, str]:
        """Get default headers for requests."""
        return {
            "Authorization": f"Bearer {self.config.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "X-API-Key": self.config.api_key,
        }

    def _get_client(self) -> httpx.AsyncClient:
        """Get or create HTTP client."""
        if not self._client:
            self._client = httpx.AsyncClient(
                base_url=self.config.base_url,
                timeout=self.config.timeout,
                headers=self._get_headers(),
            )
        return self._client

    async def _request(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> Any:
        """Make an HTTP request with retry logic.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE, PATCH)
            path: API path (e.g., "/tenants/my-business")
            params: Query parameters
            json: JSON body

        Returns:
            Parsed JSON response

        Raises:
            GrowFlowBookingError: On API errors
        """
        client = self._get_client()
        last_error: Exception | None = None

        for attempt in range(self.config.max_retries):
            try:
                response = await client.request(
                    method=method,
                    url=path,
                    params=params,
                    json=json,
                )

                # Handle successful responses
                if response.status_code < 400:
                    if response.status_code == 204:
                        return None
                    return self._parse_response(response)

                # Handle errors
                self._handle_error(response)

            except (httpx.TimeoutException, httpx.ConnectError) as e:
                last_error = e
                if attempt < self.config.max_retries - 1:
                    await asyncio.sleep(self.config.retry_delay * (attempt + 1))
                continue

            except GrowFlowBookingError:
                raise

        if last_error:
            raise GrowFlowBookingError(
                f"Request failed after {self.config.max_retries} attempts: {last_error}"
            )
        raise GrowFlowBookingError("Request failed")

    def _parse_response(self, response: httpx.Response) -> Any:
        """Parse JSON response safely."""
        try:
            return response.json()
        except Exception:
            return None

    def _handle_error(self, response: httpx.Response) -> None:
        """Handle error response and raise appropriate exception."""
        status = response.status_code
        try:
            data = response.json()
            message = data.get("detail", data.get("message", str(data)))
        except Exception:
            message = response.text or f"HTTP {status}"

        # Map status codes to exceptions
        if status == 401:
            raise AuthenticationError(message, status, data if 'data' in dir() else None)
        elif status == 404:
            raise NotFoundError(message, status, data if 'data' in dir() else None)
        elif status == 409:
            raise ConflictError(message, status, data if 'data' in dir() else None)
        elif status == 422:
            raise ValidationError(message, status, data if 'data' in dir() else None)
        elif status == 429:
            raise RateLimitError(message, status, data if 'data' in dir() else None)
        elif status >= 500:
            raise ServerError(message, status, data if 'data' in dir() else None)
        else:
            raise GrowFlowBookingError(message, status, data if 'data' in dir() else None)

    async def health_check(self) -> bool:
        """Check if the API is healthy.

        Returns:
            True if healthy, False otherwise
        """
        try:
            client = self._get_client()
            response = await client.get("/health")
            return response.status_code == 200
        except Exception:
            return False
