"""Configuration for GrowFlow Booking Client."""

import os
from dataclasses import dataclass


@dataclass
class GrowFlowBookingConfig:
    """Configuration settings for the GrowFlow Booking Client."""

    api_key: str
    base_url: str = "https://booking.growflow.studio/api/v1"
    timeout: float = 30.0
    max_retries: int = 3
    retry_delay: float = 1.0

    @classmethod
    def from_env(cls) -> "GrowFlowBookingConfig":
        """Create config from environment variables.

        Environment variables:
            GROWFLOW_BOOKING_API_KEY: API key (required)
            GROWFLOW_BOOKING_URL: Base URL (optional)
            GROWFLOW_BOOKING_TIMEOUT: Timeout in seconds (optional)
        """
        api_key = os.environ.get("GROWFLOW_BOOKING_API_KEY")
        if not api_key:
            raise ValueError("GROWFLOW_BOOKING_API_KEY environment variable is required")

        return cls(
            api_key=api_key,
            base_url=os.environ.get(
                "GROWFLOW_BOOKING_URL", "https://booking.growflow.studio/api/v1"
            ),
            timeout=float(os.environ.get("GROWFLOW_BOOKING_TIMEOUT", "30.0")),
        )
