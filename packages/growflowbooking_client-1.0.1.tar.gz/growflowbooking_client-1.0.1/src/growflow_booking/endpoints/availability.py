"""Availability API endpoint mixin."""

from datetime import date
from typing import TYPE_CHECKING
from uuid import UUID

from growflow_booking.models.availability import AvailableDates, AvailableSlots

if TYPE_CHECKING:
    from growflow_booking.client import GrowFlowBookingClient


class AvailabilityMixin:
    """Mixin for availability-related API calls."""

    async def get_available_dates(
        self: "GrowFlowBookingClient",
        tenant_slug: str,
        start_date: date | str,
        end_date: date | str,
        service_id: UUID | str | None = None,
        experience_type_id: UUID | str | None = None,
    ) -> AvailableDates:
        """Get available dates in a date range.

        Args:
            tenant_slug: Tenant identifier
            start_date: Start of date range
            end_date: End of date range
            service_id: Filter by service (optional)
            experience_type_id: Filter by experience type (optional)

        Returns:
            AvailableDates with list of dates and availability status

        Example:
            dates = await client.get_available_dates(
                tenant_slug="my-business",
                start_date="2024-03-01",
                end_date="2024-03-31",
            )
            available = [d for d in dates.dates if d.available]
        """
        params = {
            "start": str(start_date),
            "end": str(end_date),
        }
        if service_id:
            params["service_id"] = str(service_id)
        if experience_type_id:
            params["experience_type_id"] = str(experience_type_id)

        response = await self._request(
            "GET",
            f"/tenants/{tenant_slug}/availability/dates",
            params=params,
        )
        return AvailableDates(**response)

    async def get_available_slots(
        self: "GrowFlowBookingClient",
        tenant_slug: str,
        date: date | str,
        service_id: UUID | str | None = None,
        experience_type_id: UUID | str | None = None,
        resource_id: UUID | str | None = None,
        participants: int = 1,
    ) -> AvailableSlots:
        """Get available time slots for a specific date.

        Args:
            tenant_slug: Tenant identifier
            date: Date to check
            service_id: Service UUID (for simple bookings)
            experience_type_id: Experience type UUID (for experience bookings)
            resource_id: Resource UUID (optional)
            participants: Number of participants (for experience bookings)

        Returns:
            AvailableSlots with list of time slots

        Example:
            slots = await client.get_available_slots(
                tenant_slug="my-business",
                date="2024-03-15",
                service_id="uuid-here",
            )
            available = [s for s in slots.slots if s.available]
            print(f"Available times: {[s.time for s in available]}")
        """
        params = {"date": str(date), "participants": participants}
        if service_id:
            params["service_id"] = str(service_id)
        if experience_type_id:
            params["experience_type_id"] = str(experience_type_id)
        if resource_id:
            params["resource_id"] = str(resource_id)

        response = await self._request(
            "GET",
            f"/tenants/{tenant_slug}/availability/slots",
            params=params,
        )
        return AvailableSlots(**response)
