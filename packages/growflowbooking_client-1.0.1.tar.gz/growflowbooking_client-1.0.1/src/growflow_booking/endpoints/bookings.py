"""Bookings API endpoint mixin."""

from datetime import date
from typing import TYPE_CHECKING
from uuid import UUID

from growflow_booking.models.booking import Booking, BookingList, BookingResult, BookingStatus

if TYPE_CHECKING:
    from growflow_booking.client import GrowFlowBookingClient


class BookingsMixin:
    """Mixin for booking-related API calls."""

    async def create_simple_booking(
        self: "GrowFlowBookingClient",
        tenant_slug: str,
        service_id: UUID | str,
        date: date | str,
        slot: str,
        customer_name: str,
        customer_email: str,
        customer_phone: str | None = None,
        notes: str | None = None,
        locale: str = "it",
    ) -> BookingResult:
        """Create a simple booking (single service, fixed duration).

        Args:
            tenant_slug: Tenant identifier
            service_id: Service UUID
            date: Booking date (YYYY-MM-DD)
            slot: Time slot (HH:MM)
            customer_name: Customer name
            customer_email: Customer email
            customer_phone: Customer phone (optional)
            notes: Booking notes (optional)
            locale: Language for notifications (it/en)

        Returns:
            BookingResult with created booking

        Example:
            result = await client.create_simple_booking(
                tenant_slug="my-business",
                service_id="uuid-here",
                date="2024-03-15",
                slot="10:00",
                customer_name="Mario Rossi",
                customer_email="mario@example.com"
            )
            if result.success:
                print(f"Booking code: {result.booking.booking_code}")
        """
        data = {
            "service_id": str(service_id),
            "date": str(date),
            "slot": slot,
            "customer_name": customer_name,
            "customer_email": customer_email,
            "locale": locale,
        }
        if customer_phone:
            data["customer_phone"] = customer_phone
        if notes:
            data["notes"] = notes

        response = await self._request(
            "POST",
            f"/tenants/{tenant_slug}/bookings/simple",
            json=data,
        )
        return BookingResult(**response)

    async def create_experience_booking(
        self: "GrowFlowBookingClient",
        tenant_slug: str,
        experience_type_id: UUID | str,
        date: date | str,
        slot: str,
        participants: int,
        customer_name: str,
        customer_email: str,
        customer_phone: str | None = None,
        notes: str | None = None,
        resource_id: UUID | str | None = None,
        locale: str = "it",
    ) -> BookingResult:
        """Create an experience booking (group experience with participants).

        Args:
            tenant_slug: Tenant identifier
            experience_type_id: Experience type UUID
            date: Booking date (YYYY-MM-DD)
            slot: Time slot (HH:MM)
            participants: Number of participants
            customer_name: Customer name
            customer_email: Customer email
            customer_phone: Customer phone (optional)
            notes: Booking notes (optional)
            resource_id: Resource UUID (optional)
            locale: Language for notifications (it/en)

        Returns:
            BookingResult with created booking
        """
        data = {
            "experience_type_id": str(experience_type_id),
            "date": str(date),
            "slot": slot,
            "participants": participants,
            "customer_name": customer_name,
            "customer_email": customer_email,
            "locale": locale,
        }
        if customer_phone:
            data["customer_phone"] = customer_phone
        if notes:
            data["notes"] = notes
        if resource_id:
            data["resource_id"] = str(resource_id)

        response = await self._request(
            "POST",
            f"/tenants/{tenant_slug}/bookings/experience",
            json=data,
        )
        return BookingResult(**response)

    async def get_booking(
        self: "GrowFlowBookingClient",
        booking_id: UUID | str,
        email: str,
    ) -> Booking:
        """Get booking by ID with email verification.

        Args:
            booking_id: Booking UUID
            email: Customer email for verification

        Returns:
            Booking object
        """
        response = await self._request(
            "GET",
            f"/bookings/{booking_id}",
            params={"email": email},
        )
        return Booking(**response)

    async def list_bookings(
        self: "GrowFlowBookingClient",
        date_from: date | str | None = None,
        date_to: date | str | None = None,
        status: BookingStatus | str | None = None,
        customer_email: str | None = None,
        service_id: UUID | str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> BookingList:
        """List bookings (requires authentication).

        Args:
            date_from: Filter by start date
            date_to: Filter by end date
            status: Filter by status
            customer_email: Filter by customer email
            service_id: Filter by service
            page: Page number
            page_size: Items per page

        Returns:
            BookingList with pagination
        """
        params = {"page": page, "page_size": page_size}
        if date_from:
            params["date_from"] = str(date_from)
        if date_to:
            params["date_to"] = str(date_to)
        if status:
            params["status"] = str(status.value if isinstance(status, BookingStatus) else status)
        if customer_email:
            params["customer_email"] = customer_email
        if service_id:
            params["service_id"] = str(service_id)

        response = await self._request("GET", "/bookings", params=params)
        return BookingList(**response)

    async def update_booking_status(
        self: "GrowFlowBookingClient",
        booking_id: UUID | str,
        status: BookingStatus | str,
        cancel_reason: str | None = None,
    ) -> Booking:
        """Update booking status.

        Args:
            booking_id: Booking UUID
            status: New status
            cancel_reason: Reason for cancellation (if cancelling)

        Returns:
            Updated Booking object
        """
        data = {
            "status": str(status.value if isinstance(status, BookingStatus) else status)
        }
        if cancel_reason:
            data["cancel_reason"] = cancel_reason

        response = await self._request(
            "PUT",
            f"/bookings/{booking_id}/status",
            json=data,
        )
        return Booking(**response)

    async def cancel_booking(
        self: "GrowFlowBookingClient",
        booking_id: UUID | str,
        reason: str | None = None,
    ) -> None:
        """Cancel a booking.

        Args:
            booking_id: Booking UUID
            reason: Cancellation reason (optional)
        """
        params = {}
        if reason:
            params["reason"] = reason

        await self._request(
            "DELETE",
            f"/bookings/{booking_id}",
            params=params if params else None,
        )
