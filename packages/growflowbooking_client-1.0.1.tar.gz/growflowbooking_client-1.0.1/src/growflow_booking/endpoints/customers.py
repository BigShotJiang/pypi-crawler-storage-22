"""Customers API endpoint mixin."""

from typing import TYPE_CHECKING
from uuid import UUID

from growflow_booking.models.customer import Customer, CustomerList

if TYPE_CHECKING:
    from growflow_booking.client import GrowFlowBookingClient


class CustomersMixin:
    """Mixin for customer-related API calls."""

    async def list_customers(
        self: "GrowFlowBookingClient",
        search: str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> CustomerList:
        """List customers (requires authentication).

        Args:
            search: Search by name, email, or phone
            page: Page number
            page_size: Items per page

        Returns:
            CustomerList with pagination
        """
        params = {"page": page, "page_size": page_size}
        if search:
            params["search"] = search

        response = await self._request("GET", "/customers", params=params)
        return CustomerList(**response)

    async def get_customer(
        self: "GrowFlowBookingClient",
        customer_id: UUID | str,
    ) -> Customer:
        """Get customer by ID.

        Args:
            customer_id: Customer UUID

        Returns:
            Customer object
        """
        response = await self._request("GET", f"/customers/{customer_id}")
        return Customer(**response)

    async def create_customer(
        self: "GrowFlowBookingClient",
        name: str,
        email: str,
        phone: str | None = None,
        notes: str | None = None,
        external_id: str | None = None,
    ) -> Customer:
        """Create a new customer.

        Args:
            name: Customer name
            email: Customer email
            phone: Customer phone (optional)
            notes: Notes (optional)
            external_id: External system ID (optional)

        Returns:
            Created Customer object
        """
        data = {"name": name, "email": email}
        if phone:
            data["phone"] = phone
        if notes:
            data["notes"] = notes
        if external_id:
            data["external_id"] = external_id

        response = await self._request("POST", "/customers", json=data)
        return Customer(**response)

    async def update_customer(
        self: "GrowFlowBookingClient",
        customer_id: UUID | str,
        name: str | None = None,
        phone: str | None = None,
        notes: str | None = None,
        external_id: str | None = None,
    ) -> Customer:
        """Update a customer.

        Args:
            customer_id: Customer UUID
            name: New name (optional)
            phone: New phone (optional)
            notes: New notes (optional)
            external_id: New external ID (optional)

        Returns:
            Updated Customer object
        """
        data = {}
        if name is not None:
            data["name"] = name
        if phone is not None:
            data["phone"] = phone
        if notes is not None:
            data["notes"] = notes
        if external_id is not None:
            data["external_id"] = external_id

        response = await self._request("PATCH", f"/customers/{customer_id}", json=data)
        return Customer(**response)

    async def delete_customer(
        self: "GrowFlowBookingClient",
        customer_id: UUID | str,
    ) -> None:
        """Delete a customer.

        Args:
            customer_id: Customer UUID
        """
        await self._request("DELETE", f"/customers/{customer_id}")
