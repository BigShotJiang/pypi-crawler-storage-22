"""Quotas API endpoint mixin."""

from datetime import datetime
from typing import TYPE_CHECKING
from uuid import UUID

from growflow_booking.models.quota import CustomerCredits, Quota, QuotaUsage

if TYPE_CHECKING:
    from growflow_booking.client import GrowFlowBookingClient


class QuotasMixin:
    """Mixin for quota-related API calls."""

    async def create_quota(
        self: "GrowFlowBookingClient",
        customer_external_id: str,
        total_credits: int,
        expires_at: datetime | str | None = None,
        source: str | None = None,
        source_reference: str | None = None,
    ) -> Quota:
        """Create a new quota for a customer.

        Args:
            customer_external_id: External customer ID (e.g., from SweatMate)
            total_credits: Number of booking credits
            expires_at: Expiration datetime (optional)
            source: Source system (e.g., "sweatmate")
            source_reference: Reference in source system (e.g., subscription ID)

        Returns:
            Created Quota object

        Example:
            quota = await client.create_quota(
                customer_external_id="user_123",
                total_credits=10,
                source="sweatmate",
                source_reference="sub_abc"
            )
        """
        data = {
            "customer_external_id": customer_external_id,
            "total_credits": total_credits,
        }
        if expires_at:
            data["expires_at"] = str(expires_at) if isinstance(expires_at, datetime) else expires_at
        if source:
            data["source"] = source
        if source_reference:
            data["source_reference"] = source_reference

        response = await self._request("POST", "/quotas", json=data)
        return Quota(**response)

    async def get_quota(
        self: "GrowFlowBookingClient",
        quota_id: UUID | str,
    ) -> Quota:
        """Get quota by ID.

        Args:
            quota_id: Quota UUID

        Returns:
            Quota object
        """
        response = await self._request("GET", f"/quotas/{quota_id}")
        return Quota(**response)

    async def use_quota(
        self: "GrowFlowBookingClient",
        quota_id: UUID | str,
        credits: int = 1,
        booking_id: UUID | str | None = None,
        notes: str | None = None,
    ) -> QuotaUsage:
        """Use credits from a quota.

        Args:
            quota_id: Quota UUID
            credits: Number of credits to use (default: 1)
            booking_id: Associated booking UUID (optional)
            notes: Usage notes (optional)

        Returns:
            QuotaUsage with updated quota info
        """
        data = {"credits": credits}
        if booking_id:
            data["booking_id"] = str(booking_id)
        if notes:
            data["notes"] = notes

        response = await self._request("POST", f"/quotas/{quota_id}/use", json=data)
        return QuotaUsage(**response)

    async def deactivate_quota(
        self: "GrowFlowBookingClient",
        quota_id: UUID | str,
    ) -> Quota:
        """Deactivate a quota.

        Args:
            quota_id: Quota UUID

        Returns:
            Deactivated Quota object
        """
        response = await self._request("POST", f"/quotas/{quota_id}/deactivate")
        return Quota(**response)

    async def get_customer_credits(
        self: "GrowFlowBookingClient",
        customer_external_id: str,
    ) -> CustomerCredits:
        """Get credits summary for a customer.

        Args:
            customer_external_id: External customer ID

        Returns:
            CustomerCredits with total, used, and remaining credits

        Example:
            credits = await client.get_customer_credits("user_123")
            print(f"Remaining: {credits.remaining_credits}")
        """
        response = await self._request("GET", f"/quotas/customers/{customer_external_id}/credits")
        return CustomerCredits(**response)
