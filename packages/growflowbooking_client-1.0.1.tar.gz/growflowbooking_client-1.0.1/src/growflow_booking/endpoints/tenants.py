"""Tenants API endpoint mixin."""

from typing import TYPE_CHECKING

from growflow_booking.models.tenant import Service, Tenant, TenantPublic

if TYPE_CHECKING:
    from growflow_booking.client import GrowFlowBookingClient


class TenantsMixin:
    """Mixin for tenant-related API calls."""

    async def get_tenant_public(
        self: "GrowFlowBookingClient",
        slug: str,
    ) -> TenantPublic:
        """Get public tenant info for widget display.

        Args:
            slug: Tenant identifier (e.g., "my-business")

        Returns:
            TenantPublic object with services and branding

        Example:
            tenant = await client.get_tenant_public("my-business")
            print(f"Welcome: {tenant.branding.welcome_message}")
        """
        response = await self._request("GET", f"/tenants/{slug}")
        return TenantPublic(**response)

    async def get_tenant_services(
        self: "GrowFlowBookingClient",
        slug: str,
    ) -> list[Service]:
        """Get list of services for a tenant.

        Args:
            slug: Tenant identifier

        Returns:
            List of Service objects
        """
        response = await self._request("GET", f"/tenants/{slug}/services")
        return [Service(**s) for s in response]

    async def list_tenant_products(self: "GrowFlowBookingClient") -> list[dict]:
        """List products/services for the authenticated tenant.

        Uses the authenticated ``GET /tenant/products`` endpoint (X-API-Key required).
        This returns the Product table records, not the legacy ``tenant.services`` JSON field.

        Returns:
            List of product dicts with id, name, duration_minutes, price, etc.

        Example:
            async with GrowFlowBookingClient(api_key="bk_live_xxx") as client:
                products = await client.list_tenant_products()
                for p in products:
                    print(p["name"], p["id"])
        """
        response = await self._request("GET", "/tenant/products")
        return response if isinstance(response, list) else []

    async def get_tenant_detail(
        self: "GrowFlowBookingClient",
        slug: str,
    ) -> Tenant:
        """Get detailed tenant info (requires authentication).

        Args:
            slug: Tenant identifier

        Returns:
            Full Tenant object
        """
        response = await self._request("GET", f"/tenants/{slug}/detail")
        return Tenant(**response)

    async def update_tenant(
        self: "GrowFlowBookingClient",
        slug: str,
        name: str | None = None,
        phone: str | None = None,
        booking_mode: str | None = None,
    ) -> Tenant:
        """Update tenant basic info.

        Args:
            slug: Tenant identifier
            name: New name
            phone: New phone
            booking_mode: New booking mode (simple, experience, both)

        Returns:
            Updated Tenant object
        """
        data = {}
        if name is not None:
            data["name"] = name
        if phone is not None:
            data["phone"] = phone
        if booking_mode is not None:
            data["booking_mode"] = booking_mode

        response = await self._request("PATCH", f"/tenants/{slug}", json=data)
        return Tenant(**response)

    async def update_tenant_settings(
        self: "GrowFlowBookingClient",
        slug: str,
        **settings,
    ) -> dict:
        """Update tenant settings.

        Args:
            slug: Tenant identifier
            **settings: Settings to update (timezone, currency, min_notice_hours, etc.)

        Returns:
            Updated settings dict
        """
        response = await self._request("PATCH", f"/tenants/{slug}/settings", json=settings)
        return response

    async def update_tenant_branding(
        self: "GrowFlowBookingClient",
        slug: str,
        **branding,
    ) -> dict:
        """Update tenant branding.

        Args:
            slug: Tenant identifier
            **branding: Branding to update (primary_color, logo_url, etc.)

        Returns:
            Updated branding dict
        """
        response = await self._request("PATCH", f"/tenants/{slug}/branding", json=branding)
        return response
