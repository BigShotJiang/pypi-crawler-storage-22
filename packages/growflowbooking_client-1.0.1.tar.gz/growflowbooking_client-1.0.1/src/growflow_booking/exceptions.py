"""Custom exceptions for GrowFlow Booking Client."""

from typing import Any


class GrowFlowBookingError(Exception):
    """Base exception for all GrowFlow Booking errors."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        response: dict[str, Any] | None = None,
    ) -> None:
        self.message = message
        self.status_code = status_code
        self.response = response
        super().__init__(message)

    def __str__(self) -> str:
        if self.status_code:
            return f"[{self.status_code}] {self.message}"
        return self.message


class AuthenticationError(GrowFlowBookingError):
    """Raised when API key is invalid or missing."""

    pass


class NotFoundError(GrowFlowBookingError):
    """Raised when a requested resource is not found."""

    pass


class ConflictError(GrowFlowBookingError):
    """Raised when a resource already exists (409 Conflict)."""

    pass


class ValidationError(GrowFlowBookingError):
    """Raised when request data is invalid (422 Unprocessable Entity)."""

    pass


class RateLimitError(GrowFlowBookingError):
    """Raised when rate limit is exceeded (429 Too Many Requests)."""

    pass


class ServerError(GrowFlowBookingError):
    """Raised when server returns 5xx error."""

    pass


class QuotaExhaustedError(GrowFlowBookingError):
    """Raised when booking quota is exhausted."""

    pass


class SlotUnavailableError(GrowFlowBookingError):
    """Raised when requested time slot is not available."""

    pass
