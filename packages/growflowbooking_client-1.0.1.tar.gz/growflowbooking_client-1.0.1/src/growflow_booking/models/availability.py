"""Availability models for GrowFlow Booking."""

from datetime import date
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class TimeSlot(BaseModel):
    """Available time slot."""

    model_config = ConfigDict(from_attributes=True)

    time: str  # HH:MM format
    available: bool = True
    remaining_capacity: int | None = None  # For experience bookings


class AvailableDate(BaseModel):
    """Date with availability status."""

    model_config = ConfigDict(from_attributes=True)

    date: date
    available: bool
    has_slots: bool = True


class AvailableSlots(BaseModel):
    """Available slots for a specific date."""

    model_config = ConfigDict(from_attributes=True)

    date: date
    service_id: UUID | None = None
    experience_type_id: UUID | None = None
    slots: list[TimeSlot]


class AvailableDates(BaseModel):
    """Available dates in a date range."""

    model_config = ConfigDict(from_attributes=True)

    start_date: date
    end_date: date
    dates: list[AvailableDate]
