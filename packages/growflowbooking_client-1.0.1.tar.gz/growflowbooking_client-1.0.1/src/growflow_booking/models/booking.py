"""Booking models for GrowFlow Booking."""

from datetime import date, datetime
from enum import Enum
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class BookingStatus(str, Enum):
    """Booking status values."""

    PENDING = "pending"
    CONFIRMED = "confirmed"
    CHECKED_IN = "checked_in"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    NO_SHOW = "no_show"


class Booking(BaseModel):
    """Booking model."""

    model_config = ConfigDict(from_attributes=True)

    id: UUID
    booking_code: str
    tenant_id: UUID
    service_id: UUID | None = None
    service_name: str | None = None
    experience_type_id: UUID | None = None
    experience_type_name: str | None = None
    resource_id: UUID | None = None
    resource_name: str | None = None
    date: date
    start_time: str
    end_time: str
    duration_minutes: int
    participants: int = 1
    customer_name: str
    customer_email: str
    customer_phone: str | None = None
    notes: str | None = None
    status: BookingStatus
    total_price: float | None = None
    currency: str = "EUR"
    google_event_id: str | None = None
    created_at: datetime
    updated_at: datetime | None = None


class BookingResult(BaseModel):
    """Result of booking creation."""

    model_config = ConfigDict(from_attributes=True)

    success: bool
    booking: Booking | None = None
    message: str | None = None
    calendar_event_created: bool = False
    notification_sent: bool = False


class BookingList(BaseModel):
    """Paginated list of bookings."""

    model_config = ConfigDict(from_attributes=True)

    items: list[Booking]
    total: int
    page: int
    page_size: int
    total_pages: int
