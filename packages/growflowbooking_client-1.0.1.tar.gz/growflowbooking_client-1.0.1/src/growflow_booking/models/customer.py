"""Customer models for GrowFlow Booking."""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class Customer(BaseModel):
    """Customer model."""

    model_config = ConfigDict(from_attributes=True)

    id: UUID
    tenant_id: UUID
    name: str
    email: str
    phone: str | None = None
    notes: str | None = None
    external_id: str | None = None
    total_bookings: int = 0
    created_at: datetime
    updated_at: datetime | None = None


class CustomerList(BaseModel):
    """Paginated list of customers."""

    model_config = ConfigDict(from_attributes=True)

    items: list[Customer]
    total: int
    page: int
    page_size: int
    total_pages: int
