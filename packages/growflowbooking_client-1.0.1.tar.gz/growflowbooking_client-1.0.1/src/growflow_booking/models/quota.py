"""Quota models for GrowFlow Booking."""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class Quota(BaseModel):
    """Booking quota model."""

    model_config = ConfigDict(from_attributes=True)

    id: UUID
    tenant_id: UUID
    customer_external_id: str
    total_credits: int
    used_credits: int
    remaining_credits: int
    expires_at: datetime | None = None
    source: str | None = None
    source_reference: str | None = None
    is_active: bool
    created_at: datetime
    updated_at: datetime | None = None


class CustomerCredits(BaseModel):
    """Customer credits summary."""

    model_config = ConfigDict(from_attributes=True)

    customer_external_id: str
    total_credits: int
    used_credits: int
    remaining_credits: int
    quotas: list[Quota] = []


class QuotaUsage(BaseModel):
    """Result of using quota credits."""

    model_config = ConfigDict(from_attributes=True)

    success: bool
    quota: Quota
    credits_used: int
    remaining_credits: int
    message: str | None = None
