"""Tenant models for GrowFlow Booking."""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class Service(BaseModel):
    """Service offered by a tenant."""

    model_config = ConfigDict(from_attributes=True)

    id: UUID
    name: str
    name_en: str | None = None
    duration: int  # minutes
    price: float | None = None
    description: str | None = None
    description_en: str | None = None


class Branding(BaseModel):
    """Tenant branding settings."""

    model_config = ConfigDict(from_attributes=True)

    primary_color: str = "#3B82F6"
    logo_url: str | None = None
    welcome_message: str = "Prenota un appuntamento"
    welcome_message_en: str = "Book an appointment"
    confirmation_message: str = "Prenotazione confermata!"
    confirmation_message_en: str = "Booking confirmed!"


class TenantPublic(BaseModel):
    """Public tenant info for widget display."""

    model_config = ConfigDict(from_attributes=True)

    slug: str
    name: str
    phone: str | None = None
    services: list[Service] = []
    branding: Branding
    show_branding: bool = True
    booking_mode: str = "simple"
    use_experience_types: bool = False


class TenantSettings(BaseModel):
    """Tenant settings."""

    model_config = ConfigDict(from_attributes=True)

    timezone: str = "Europe/Rome"
    currency: str = "EUR"
    min_notice_hours: int = 24
    max_advance_days: int = 90
    appointment_duration: int | None = None
    buffer_minutes: int | None = None
    working_hours: dict | None = None
    working_days: list[int] | None = None
    slot_interval: int | None = None


class Tenant(BaseModel):
    """Full tenant model."""

    model_config = ConfigDict(from_attributes=True)

    id: UUID
    slug: str
    name: str
    email: str
    phone: str | None = None
    booking_mode: str
    plan: str
    settings: TenantSettings | None = None
    branding: Branding | None = None
    services: list[Service] = []
    google_connected: bool = False
    google_calendar_id: str | None = None
    webhook_url: str | None = None
    is_super_admin: bool = False
    created_at: datetime
    updated_at: datetime | None = None
