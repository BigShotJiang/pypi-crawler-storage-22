"""Pytest configuration and fixtures."""

import pytest
import respx

from growflow_booking import GrowFlowBookingClient


@pytest.fixture
def api_key() -> str:
    """Test API key."""
    return "bk_test_growflow_test_key"


@pytest.fixture
def base_url() -> str:
    """Test base URL."""
    return "https://booking.growflow.studio/api/v1"


@pytest.fixture
async def client(api_key: str, base_url: str):
    """GrowFlow Booking client fixture."""
    async with GrowFlowBookingClient(api_key=api_key, base_url=base_url) as client:
        yield client


@pytest.fixture
def mock_api(base_url: str):
    """Mock API fixture using respx."""
    with respx.mock(base_url=base_url, assert_all_called=False) as respx_mock:
        yield respx_mock
