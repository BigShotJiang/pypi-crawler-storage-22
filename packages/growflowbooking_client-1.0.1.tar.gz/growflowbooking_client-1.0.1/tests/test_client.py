"""Tests for GrowFlowBookingClient."""

import pytest
import respx
from httpx import Response

from growflow_booking import GrowFlowBookingClient, GrowFlowBookingConfig
from growflow_booking.exceptions import (
    AuthenticationError,
    GrowFlowBookingError,
    NotFoundError,
    ServerError,
)


# =============================================================================
# Client basics
# =============================================================================


@pytest.mark.asyncio
async def test_client_context_manager(api_key: str):
    """Test client as context manager."""
    async with GrowFlowBookingClient(api_key=api_key) as client:
        assert client._client is not None
    assert client._client is None


@pytest.mark.asyncio
async def test_client_without_context_manager(api_key: str):
    """Test client without context manager."""
    client = GrowFlowBookingClient(api_key=api_key)
    assert client._client is None
    http_client = client._get_client()
    assert http_client is not None
    await client.close()
    assert client._client is None


@pytest.mark.asyncio
async def test_client_config(api_key: str):
    """Test client configuration."""
    client = GrowFlowBookingClient(
        api_key=api_key,
        base_url="https://custom.api.com/v1",
        timeout=60.0,
        max_retries=5,
        retry_delay=2.0,
    )
    assert client.config.api_key == api_key
    assert client.config.base_url == "https://custom.api.com/v1"
    assert client.config.timeout == 60.0
    assert client.config.max_retries == 5
    assert client.config.retry_delay == 2.0
    await client.close()


def test_config_from_env(monkeypatch: pytest.MonkeyPatch):
    """Test config from environment variables."""
    monkeypatch.setenv("GROWFLOW_BOOKING_API_KEY", "bk_test_env")
    monkeypatch.setenv("GROWFLOW_BOOKING_URL", "https://custom.com/api/v1")
    config = GrowFlowBookingConfig.from_env()
    assert config.api_key == "bk_test_env"
    assert config.base_url == "https://custom.com/api/v1"


def test_config_from_env_missing_key():
    """Test config from env raises without API key."""
    with pytest.raises(ValueError, match="GROWFLOW_BOOKING_API_KEY"):
        GrowFlowBookingConfig.from_env()


# =============================================================================
# Health check
# =============================================================================


@pytest.mark.asyncio
async def test_health_check(client: GrowFlowBookingClient, mock_api):
    """Test health check returns True on 200."""
    mock_api.get("/health").mock(return_value=Response(200, json={"status": "ok"}))
    result = await client.health_check()
    assert result is True


@pytest.mark.asyncio
async def test_health_check_unhealthy(client: GrowFlowBookingClient, mock_api):
    """Test health check returns False on error."""
    mock_api.get("/health").mock(return_value=Response(503))
    result = await client.health_check()
    assert result is False


# =============================================================================
# Error handling
# =============================================================================


@pytest.mark.asyncio
async def test_authentication_error(client: GrowFlowBookingClient, mock_api):
    """Test 401 raises AuthenticationError."""
    mock_api.get("/tenants/test").mock(
        return_value=Response(401, json={"detail": "Invalid API key"})
    )
    with pytest.raises(AuthenticationError):
        await client._request("GET", "/tenants/test")


@pytest.mark.asyncio
async def test_not_found_error(client: GrowFlowBookingClient, mock_api):
    """Test 404 raises NotFoundError."""
    mock_api.get("/tenants/missing").mock(
        return_value=Response(404, json={"detail": "Not found"})
    )
    with pytest.raises(NotFoundError):
        await client._request("GET", "/tenants/missing")


@pytest.mark.asyncio
async def test_server_error(client: GrowFlowBookingClient, mock_api):
    """Test 500 raises ServerError."""
    mock_api.get("/tenants/err").mock(
        return_value=Response(500, json={"detail": "Internal error"})
    )
    with pytest.raises(ServerError):
        await client._request("GET", "/tenants/err")


def test_error_string_representation():
    """Test error __str__ output."""
    error_with_code = GrowFlowBookingError("test error", status_code=400)
    assert str(error_with_code) == "[400] test error"

    error_without_code = GrowFlowBookingError("plain error")
    assert str(error_without_code) == "plain error"
