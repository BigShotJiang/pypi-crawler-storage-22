# GrowthCharts

**GrowthCharts** is a pediatric growth chart analyzer for infants (0–2 years) and children (2–20 years).  
It provides Z-score calculation, percentiles, and growth chart visualization based on CDC growth standards.

---

## Installation

Install from PyPI (once uploaded):

```bash
pip install growthcharts
Or install locally for development:

pip install -e .
Requirements:

pandas

matplotlib

scipy

Quickstart
Infant example (0–24 months)
from growthcharts import Infant

# Create an Infant object
baby = Infant(sex='m', age=6, wt=7.5, length=65.0, hc=42.0)

# Plot growth charts
baby.plot_wtage(title="Weight-for-Age")
baby.plot_lenageinf(title="Length-for-Age")
baby.plot_hcageinf(title="Head Circumference-for-Age")
baby.plot_wtleninf(title="Weight-for-Length")

# Calculate Z-scores and percentiles
print(baby.analyze_wtageinf())   # Example: {'Z': -0.23, 'Percentile': 41.0, 'Interpretation': 'Normal'}
print(baby.analyze_lenageinf())  # Example: {'Z': 0.12, 'Percentile': 55.0, 'Interpretation': 'Normal'}
print(baby.analyze_hcageinf())   # Example: {'Z': 0.30, 'Percentile': 62.0, 'Interpretation': 'Normal'}
print(baby.analyze_wtleninf())   # Example: {'Z': -0.15, 'Percentile': 44.0, 'Interpretation': 'Normal'}
Child example (2–20 years)
from growthcharts import Child

# Create a Child object
child = Child(sex='f', age=36, wt=15.5, length=95.0)

# Plot growth charts
child.plot_wtage(title="Weight-for-Age")
child.plot_lenage(title="Height-for-Age")
child.plot_bmiage(title="BMI-for-Age")

# Calculate Z-scores and percentiles
print(child.analyze_wtage())  # Example: {'Z': 0.12, 'Percentile': 55.0, 'Interpretation': 'Normal'}
print(child.analyze_lenage())  # Example: {'Z': -0.08, 'Percentile': 47.0, 'Interpretation': 'Normal'}
print(child.analyze_bmiage())  # Example: {'Z': 0.05, 'Percentile': 52.0, 'Interpretation': 'Normal'}
Classes
Patient
Base class storing sex, age, weight, and length.
Calculates BMI if both weight and length are provided.

Infant(Patient)
Handles infants 0–24 months.

Plotting methods:

plot_wtage

plot_lenageinf

plot_hcageinf

plot_wtleninf

Analysis methods:

analyze_wtageinf

analyze_lenageinf

analyze_hcageinf

analyze_wtleninf

Child(Patient)
Handles children 2–20 years.

Plotting methods:

plot_wtage

plot_lenage

plot_bmiage

Analysis methods:

analyze_wtage

analyze_lenage

analyze_bmiage

Data
CSV data files for growth standards are included with the package under the data/ folder.

Infant: wtageinf.csv, lenageinf.csv, hcageinf.csv, wtleninf.csv
Child: wtage.csv, lenage.csv, bmiage.csv

These are loaded automatically by the classes and do not need separate downloading.

License
This project is licensed under the MIT License.