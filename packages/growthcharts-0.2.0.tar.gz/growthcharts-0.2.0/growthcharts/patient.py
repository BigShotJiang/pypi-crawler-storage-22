class Patient:
    """
    Represents a pediatric patient for growth chart analysis.

    This class stores basic patient information such as sex, age,
    weight, and length, and calculates BMI if both weight and length
    are provided.

    It also defines standard column names and percentile indices
    used for growth chart visualization.

    Attributes:
        highlight_indices (list[int]):
            Indices of key percentiles for highlighting (P3, P50, P97).

        agecolumns (list[str]):
            Column names used for age-based growth charts.

        lencolumns (list[str]):
            Column names used for length-based growth charts.

        sex (str):
            Patient sex (e.g., 'm', 'f', '1', '2').

        age (int):
            Age of the patient in months.

        wt (float | None):
            Weight in kilograms. Optional.

        length (float | None):
            Length/height in centimeters. Optional.

        bmi (float, optional):
            Body Mass Index, calculated only if both wt and length
            are provided.
    """

    highlight_indices = [0, 3, 6]  # P3 (0)، P50 (3)، P97 (6)

    agecolumns = ['Agemos','P3','P10','P25','P50','P75','P90','P97']

    lencolumns = ['Length','P3','P10','P25','P50','P75','P90','P97']

    def __init__(self, sex: str, age: int, wt: float = None, length: float = None):
        """
        Initialize a Patient object.

        At least one of weight (wt) or length must be provided.
        If both are provided, BMI will be calculated automatically.

        Args:
            sex (str):
                Patient sex.

            age (int):
                Age in months.

            wt (float, optional):
                Weight in kilograms.

            length (float, optional):
                Length/height in centimeters.

        Raises:
            ValueError:
                If both wt and length are None.
        """

        # Ensure that at least weight or length is provided
        if wt is None and length is None:
            raise ValueError("At least wt or length must be provided")

        # Store basic patient information
        self.sex = sex
        self.age = age
        self.wt = wt
        self.length = length

        # Calculate BMI if both weight and length are available
        if wt is not None and length is not None:
            length_m = self.length / 100  # Convert cm to meters
            self.bmi = self.wt / (length_m * length_m)

    def _normalize_sex(self):
        s = str(self.sex).lower()
        if s in ['m', '1']:
            return '1'
        if s in ['f', '2']:
            return '2'
        raise TypeError("define sex as m or f")
    
    def _interpret_z(self, z):

        if z < -3:
            return "Severely Low"
        elif -3 <= z < -2:
            return "Low"
        elif -2 <= z <= 2:
            return "Normal"
        elif 2 < z <= 3:
            return "High"
        else:
            return "Severely High"
        
    def _interpret_percentile(self, p):

        if p < 3:
            return "Severely Low"
        elif 3 <= p < 10:
            return "Low"
        elif 10 <= p <= 90:
            return "Normal"
        elif 90 < p <= 97:
            return "High"
        else:
            return "Severely High"



