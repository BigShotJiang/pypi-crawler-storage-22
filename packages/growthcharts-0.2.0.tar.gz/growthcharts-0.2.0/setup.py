# setup.py
from setuptools import setup, find_packages

setup(
    name="growthcharts",
    version="0.2.0",
    author="Javad Dehghani MD",
    author_email="j.dehghani@gmail.com",
    description="Pediatric Growth Chart Analyzer",
    long_description=open("README.md", "r", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://drdehghani.ir/",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "growthcharts": ["data/*.csv"]
    },
    install_requires=[
        "pandas",
        "matplotlib",
        "scipy"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",  
        "Operating System :: OS Independent",
        "Intended Audience :: Healthcare Industry",
        "Topic :: Scientific/Engineering :: Visualization"
    ],
    python_requires=">=3.7",
    keywords="growth chart pediatric infant child BMI CDC",
)
