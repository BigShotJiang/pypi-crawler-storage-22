# Design descriptions and details for used Python package template

> Author: Henry Webel

[packaging.python.org](https://packaging.python.org/en/latest/tutorials/packaging-projects/)
has an excellent tutorial on how to package a Python project. I read and used insights from
that website to help create the template which is available on GitHub at
[biosustain/python_package](https://github.com/biosustain/python_package),
which was used to build this project.

See the notes
[here](https://python-package-template-biosustain.readthedocs.io/developing.html).
