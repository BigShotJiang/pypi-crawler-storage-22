from .gs2decompiler import *

__doc__ = gs2decompiler.__doc__
if hasattr(gs2decompiler, "__all__"):
    __all__ = gs2decompiler.__all__