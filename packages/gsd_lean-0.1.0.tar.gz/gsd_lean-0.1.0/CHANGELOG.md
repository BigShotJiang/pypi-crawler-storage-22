## [unreleased]

### 🚀 Features

- Add ralph scripts and PRD skill
- Add Claude Code plugin scaffolding
- Ralph scaffolding and Makefile improvements ([#5](https://github.com/Bifurcate-Loops/gsd-lean/issues/5))
- Add code-simplifier agent to gsd-lite plugin ([#7](https://github.com/Bifurcate-Loops/gsd-lean/issues/7))
- Add statusline hook with git info and context window bar ([#8](https://github.com/Bifurcate-Loops/gsd-lean/issues/8))
- Phase 1 State System + fix pre-commit for Docker sandbox ([#9](https://github.com/Bifurcate-Loops/gsd-lean/issues/9))
- Phase 2 workflow planning engine (PRD 003)
- Enable PyPI publishing via trusted OIDC ([#14](https://github.com/Bifurcate-Loops/gsd-lean/issues/14))

### ⚙️ Miscellaneous Tasks

- Initialize project scaffolding
- Add Claude Code docs and config fixes ([#6](https://github.com/Bifurcate-Loops/gsd-lean/issues/6))
- Add Serena MCP server config + docs ([#10](https://github.com/Bifurcate-Loops/gsd-lean/issues/10))
- Remove Serena MCP server in favour of built-in LSP tool
- Rename gsd-lite → gsd-lean (PyPI name conflict)
- Update plugin.json repo URL to gsd-lean
