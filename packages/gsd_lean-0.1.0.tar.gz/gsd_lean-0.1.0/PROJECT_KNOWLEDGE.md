# Project Knowledge: GSD-Lean Architecture

> **Quick Links**: [CLAUDE.md](./CLAUDE.md) for operational commands | [TROUBLESHOOTING.md](./TROUBLESHOOTING.md) for debugging | [RELEASE.md](./RELEASE.md) for release process

---

## System Overview

GSD-Lean is a lightweight Python reimplementation of [Get-Shit-Done](https://github.com/glittercowboy/get-shit-done), packaged as a Claude Code plugin. It provides meta-prompting and spec-driven development workflows — skills, subagents, and hooks — that streamline common engineering tasks directly from the CLI.

### Core Capabilities

- **Skills** (slash commands): `/commit`, `/verify`, `/pr`, `/merge`, `/release`, `/prd`
- **Subagents**: `code-simplifier` (installed via plugin), `verify-plugin`
- **Hooks**: PostToolUse auto-format on Write/Edit (ruff check --fix + ruff format)
- **Ralph**: Autonomous Docker-based agent for background issue processing (`ralph/`)

### System Diagram

```mermaid
graph TD
    CC[Claude Code CLI] --> Plugin[gsd-lean plugin]
    Plugin --> Skills[Skills<br>/commit /verify /pr<br>/merge /release /prd]
    Plugin --> Agents[Subagents<br>code-simplifier<br>verify-plugin]
    Plugin --> Hooks[Hooks<br>PostToolUse auto-format]
    Ralph[Ralph<br>Docker agent] --> CC
    Ralph --> Issues[GitHub Issues]
```

---

## Architecture

### Repo Structure

```
gsd-lean/
├── .claude/               # Claude Code config
│   ├── agents/            # Subagent definitions
│   ├── skills/            # Skill definitions
│   └── settings.json      # Claude Code settings/config
├── src/gsd_lean/          # Python package source
├── tests/                 # pytest tests
├── .claude-plugin/        # Metadata directory
│   └── plugin.json        # Plugin manifest
├── agents/                # Default agent location
├── skills/                # Agent Skills
├── hooks/                 # Hook configurations
│   └── hooks.json         # Main hook config
├── scripts/               # Hook and utility scripts
├── ralph/                 # Autonomous Docker agent (ralph loop)
│   ├── ralph.sh           # Entry script
│   ├── prompt.md          # Agent prompt
│   └── issues/            # Issue tracking
├── docs/prds/             # Product requirement docs
├── .github/workflows/     # CI pipeline
├── pyproject.toml         # Project metadata + tool config
├── Makefile               # Dev commands
├── mise.toml              # uv version pin
└── uv.lock                # Dependency lockfile
```

---

## Core Stack

### Runtime: uv

[uv](https://github.com/astral-sh/uv) is a fast Python package manager that replaces pip, pip-tools, and virtualenv. All dev commands run through `uv run` (via Makefile). Dependencies are locked in `uv.lock`. Version pinned to `0.9.25` in `mise.toml`.

---

## Build & Deployment

### CI/CD Pipeline Architecture

GitHub Actions CI runs on push/PR to `main` with 5 jobs:

1. **lint** — pre-commit (ruff, mypy, yamllint, file checks) on Python 3.14
2. **test** — pytest + coverage on Python 3.12, 3.13, 3.14 (matrix)
3. **coverage** — combines coverage artifacts, enforces 90% minimum
4. **check** — alls-green gate; ensures lint + test + coverage all pass
5. **github-release** — triggered on `v*` tag push; creates GitHub release

```mermaid
graph LR
    lint --> check
    test --> coverage --> check
    check --> github-release
```

---

## Code Quality Philosophy

Automated quality enforcement via ruff (lint + format) and mypy (strict types), gated by pre-commit hooks and CI.

### Ruff Standards

**What is Ruff?**

Fast Python linter and formatter written in Rust. Replaces flake8, isort, black, and pyflakes in a single tool.

**Key Principles**:

- Single quotes for code, double quotes for docstrings
- Google-style docstrings (pydocstyle convention)
- Line length: 130 characters
- Auto-fix on file save via PostToolUse hook

**Configuration** (`pyproject.toml`):

Configured under `[tool.ruff]`. Enabled rule sets:
- `E` — pycodestyle
- `F` — pyflakes
- `UP` — pyupgrade
- `B` — flake8-bugbear
- `SIM` — flake8-simplify
- `I` — isort
- `D` — pydocstyle
- `PL` — pylint

Key ignores: `D100` (module docstring), `D104` (package docstring), `D106`/`D107` (nested/init docstring), `PLR2004` (magic values), `PLR0912`/`PLR0913`/`PLR0915` (complexity limits).

---

## Key File Locations

### Configuration Files

| File | Purpose |
|------|---------|
| `pyproject.toml` | Project metadata, deps, ruff/mypy/pytest/coverage config |
| `Makefile` | Dev commands (sync, ruff, mypy, tests, clean) |
| `.pre-commit-config.yaml` | Pre-commit hook definitions |
| `.github/workflows/ci.yml` | CI pipeline |
| `mise.toml` | uv version pin (0.9.25) |
| `.claude/settings.json` | Plugin config (code-simplifier, pyright-lsp) |
| `hooks/hooks.json` | PostToolUse auto-format hook (ruff check --fix + format) |

---

- **[CLAUDE.md](./CLAUDE.md)**: Operational commands and AI assistant guidelines
- **[TROUBLESHOOTING.md](./TROUBLESHOOTING.md)**: Common issues and debugging workflows
- **[RELEASE.md](./RELEASE.md)**: Release management
- **Skills**: Implementation patterns and commands in `.claude/skills/`
