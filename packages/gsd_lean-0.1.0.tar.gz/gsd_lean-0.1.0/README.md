# GSD-Lean

> A lightweight Python plugin/add-on for [Get-Shit-Done](https://github.com/glittercowboy/get-shit-done)

## What is GSD?

[GSD](https://github.com/glittercowboy/get-shit-done) is a meta-prompting, context engineering, and spec-driven development system for Claude Code. It solves context rot by breaking projects into phases with fresh contexts per task, using a discuss → plan → execute → verify loop. Written in JavaScript.

## What is GSD-Lean?

A Python reimplementation of GSD's core ideas as a lightweight plugin. Rather than the full system, GSD-Lean focuses on being minimal and easy to extend.

**Status:** Early development — not yet functional.
