---
description: Run enriched discuss phase — research, probe preferences, populate requirements and decisions
argument-hint: <feature or change description>
allowed-tools: Read, Write, Edit, Glob, Grep, Bash(gsd-lean:*), Bash(git:*), Task, WebSearch, WebFetch, LSP
---

## Current State

**Phase:** !`gsd-lean status --path . 2>/dev/null | grep -A1 "Current Phase" | tail -1 | tr -d '`'`
**Project:** !`head -1 .planning/PROJECT.md 2>/dev/null || echo "Not initialized"`

## Instructions

You are running the **discuss phase** of GSD-Lite's development workflow. Your goal: deeply understand what the user wants to build, research the codebase, and capture everything in REQUIREMENTS.md and DECISIONS.md.

### Step 1: Verify Phase

Read `.planning/STATE.md`. If not in `discuss` phase, run:
```
gsd-lean transition discuss --path . --force
```

### Step 2: Read Existing State

Read these files to understand current context:
- `.planning/PROJECT.md`
- `.planning/REQUIREMENTS.md`
- `.planning/DECISIONS.md`

### Step 3: Spawn Research Subagent

Use the Task tool to spawn a research subagent with `subagent_type=Explore`. Pass this prompt (fill in {feature_description} from $ARGUMENTS):

---BEGIN SUBAGENT PROMPT---
You are a research subagent for GSD-Lean. Investigate the codebase and external resources for the following feature:

**Feature:** {feature_description}

**Research tasks:**

1. **Codebase investigation** (use LSP tools if available, otherwise Glob/Grep/Read):
   - Find existing code patterns relevant to this feature
   - Identify files/modules that will be affected
   - Check for existing utilities, helpers, or patterns to reuse
   - Note architectural constraints or conventions

2. **External research** (use WebSearch):
   - Best practices for this type of feature
   - Common pitfalls and edge cases
   - Relevant library documentation if new deps needed

**Output format:**

## Codebase Findings
- [finding]: description + file paths

## External Research
- [finding]: description + source

## Suggested Requirements
- [req]

## Suggested Decisions
- [decision]: rationale

## Risks & Considerations
- [risk]

Be thorough but concise. Cite file paths and URLs.
---END SUBAGENT PROMPT---

### Step 4: Probe User Preferences

While research runs (or after), actively ask the user about:
- **Architecture:** preferred patterns, module structure, dependency approach
- **Error handling:** style (exceptions vs result types), granularity, user-facing messages
- **Testing:** coverage expectations, test patterns, integration test needs
- **Naming:** conventions for functions, files, classes
- **Constraints:** performance, backwards compatibility, API surface
- **Scope:** what's explicitly in/out

Use `AskUserQuestion` with specific options, not open-ended questions. Ask 2-4 questions max per round.

### Step 5: Update State Files

Merge research findings + user answers into:

1. **REQUIREMENTS.md** — update User Intent, Functional Requirements, Non-Functional Requirements sections. Replace template placeholders with real content.

2. **DECISIONS.md** — update Architecture, Style & Preferences, Constraints sections. Each decision should have a one-line rationale.

### Step 6: Summary

Print a summary of what was captured:
- Key requirements (bulleted)
- Key decisions (bulleted)
- Any gaps or open questions

Then suggest: "Requirements and decisions captured. Run `/plan` when ready to generate a plan."
