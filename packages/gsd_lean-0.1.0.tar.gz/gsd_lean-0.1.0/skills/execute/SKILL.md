---
description: Execute next task from plan (Phase 3 — not yet implemented)
allowed-tools: Read, Bash(gsd-lean:*)
---

## Not Yet Implemented

The execute phase is implemented in Phase 3. For now:

1. Read `.planning/PLAN.md` to see pending tasks
2. Run `gsd-lean plan-status --path .` to see progress summary
3. Implement tasks manually, updating task status in PLAN.md as you go
4. Run `/verify` after each task
5. Run `/commit` after verification passes

To manually set the execute phase: `gsd-lean transition execute --path . --force`
