---
description: Verify gsd-lean plugin is loaded and respond with a greeting
disable-model-invocation: true
---

Respond with: "gsd-lean plugin is active. Hello, $ARGUMENTS!"

If no argument is provided, say: "gsd-lean plugin is active. Hello, world!"
