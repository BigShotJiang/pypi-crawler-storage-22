---
description: Generate structured plan from requirements and decisions, then verify it
argument-hint: [additional planning context]
allowed-tools: Read, Write, Edit, Glob, Grep, Bash(gsd-lean:*), Bash(git:*), Task, LSP
---

## Current State

**Phase:** !`gsd-lean status --path . 2>/dev/null | grep -A1 "Current Phase" | tail -1 | tr -d '`'`

## Instructions

You are running the **plan phase** of GSD-Lite's development workflow. Your goal: decompose requirements into structured tasks, write PLAN.md, and verify it passes review.

### Step 1: Transition Phase

Run:
```
gsd-lean transition plan --path .
```

If this fails with a precondition error, tell the user to run `/discuss` first.

### Step 2: Read Inputs

Read these files:
- `.planning/REQUIREMENTS.md` — what to build
- `.planning/DECISIONS.md` — how to build it
- `.planning/PROJECT.md` — stack, constraints

### Step 3: Decompose Into Tasks

Break requirements into discrete, committable tasks. For each task:
- **ID:** `T-NNN` format (zero-padded 3 digits, e.g. T-001, T-002)
- **Wave:** integer for execution ordering (wave 1 before wave 2, etc.)
- **Title:** short imperative description
- **Files:** which files are created/modified
- **Verification:** specific, runnable criteria (test commands, lint checks, manual checks)
- **Dependencies:** which other T-NNN tasks must complete first (or "none")

Guidelines:
- Each task touches at most ~5 files (split larger tasks)
- Wave 1 = foundational work (modules, types, core logic)
- Wave 2 = features built on wave 1 (CLI commands, integrations)
- Wave 3 = skills, docs, polish
- Every requirement must map to at least one task
- Every decision must be respected in task design

### Step 4: Write PLAN.md

Write `.planning/PLAN.md` using this exact format:

````markdown
# Plan

> **Status:** draft
> **Created:** <ISO 8601 UTC timestamp>
> **Waves:** <total wave count>
> **Source:** REQUIREMENTS.md

## Tasks

| ID | Wave | Status | Title | Files | Verification |
|----|------|--------|-------|-------|-------------|
| T-001 | 1 | pending | <title> | `<file1>`, `<file2>` | <brief verification> |
| T-002 | 1 | pending | <title> | `<file>` | <brief verification> |
| T-003 | 2 | pending | <title> | `<file>` | <brief verification> |

## Task Details

### T-001: <title>

**Description:** <1-3 sentences explaining what this task does and why>

**Files:**
- `path/to/file.py` (create | modify)

**Verification:**
- [ ] <specific check, e.g. "unit tests in tests/test_foo.py pass">
- [ ] <specific check, e.g. "mypy src/module/ clean">

**Dependencies:** none

---

### T-002: <title>

**Description:** ...

**Files:**
- `path/to/file.py` (modify)

**Verification:**
- [ ] ...

**Dependencies:** T-001

---
````

Important:
- Status header MUST be `draft` initially
- Every task in the summary table MUST have a corresponding Task Details section
- Task IDs must be sequential and zero-padded to 3 digits
- Status values: `pending`, `in-progress`, `done`, `blocked`
- Files column uses backtick-wrapped paths, comma-separated

### Step 5: Verify Plan

Use the Task tool to spawn a plan-review subagent with `subagent_type=general-purpose`. Pass this prompt:

---BEGIN SUBAGENT PROMPT---
You are a plan verification subagent for GSD-Lean. Review the plan for completeness and correctness.

Read these files:
- `.planning/PLAN.md` — the plan to review
- `.planning/REQUIREMENTS.md` — requirements it must satisfy
- `.planning/DECISIONS.md` — decisions it must respect

**Checklist:**

1. FORMAT
   - [ ] Plan has Status header (must be `draft` or `verified`)
   - [ ] Every task has: ID (T-NNN), wave, status, title, files, verification
   - [ ] Task Details section exists for every task in the summary table
   - [ ] Each task detail has: description, files with actions, verification checklist, dependencies

2. COMPLETENESS
   - [ ] Every functional requirement in REQUIREMENTS.md maps to at least one task
   - [ ] Every non-functional requirement is addressed (testing, linting, types)
   - [ ] No orphan tasks (tasks that don't trace to any requirement)

3. DECISIONS
   - [ ] Architecture decisions in DECISIONS.md are reflected in task design
   - [ ] Style preferences are captured in relevant verification criteria
   - [ ] Constraints are respected (no tasks violating stated constraints)

4. ORDERING
   - [ ] Wave 1 tasks have no dependencies on later-wave tasks
   - [ ] No circular dependencies
   - [ ] Wave ordering makes logical sense (foundations before features)

5. ATOMICITY
   - [ ] Each task is a discrete committable unit
   - [ ] No task touches more than ~5 files (flag if larger)
   - [ ] Verification criteria are specific and runnable (not vague like "works correctly")

**Output format:**

## Verdict: PASS | FAIL

## Issues (if FAIL)
1. [CATEGORY] description of issue — suggested fix
2. [CATEGORY] description of issue — suggested fix

## Suggestions (optional, non-blocking)
- suggestion

Be strict on format and completeness. Be lenient on subjective design choices.
---END SUBAGENT PROMPT---

### Step 6: Handle Review Result

**If PASS:**
- Update PLAN.md Status header from `draft` to `verified`
- Print: "Plan verified. {N} tasks across {W} waves. Run `/execute` when ready."

**If FAIL:**
- Print the issues found
- Revise PLAN.md to address each issue
- Re-run the verification subagent (same prompt as Step 5)
- If second review also fails: print issues and ask user to resolve manually
- If second review passes: update Status to `verified`

Maximum 1 revision loop (2 total verification attempts).

### Step 7: Update State

The phase transition in Step 1 already updated STATE.md. No further state updates needed unless you need to note blockers.
