"""CLI application entry point."""

import json
from collections import Counter
from pathlib import Path

import click

from gsd_lean.state import PHASES, get_plan_status, init_planning, parse_plan_tasks, read_plan, read_state
from gsd_lean.workflow import PreconditionError
from gsd_lean.workflow import transition as workflow_transition


@click.group(invoke_without_command=True)
@click.pass_context
def cli(ctx: click.Context) -> None:
    """GSD-Lean: spec-driven development workflow."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@cli.command()
@click.option('--force', is_flag=True, help='Overwrite existing files.')
@click.option(
    '--path', type=click.Path(exists=True, path_type=Path), default='.', help='Project root (default: current directory).'
)
def init(force: bool, path: Path) -> None:
    """Scaffold .planning/ directory with template files."""
    root = path.resolve()
    try:
        created = init_planning(root, force=force)
    except FileExistsError as e:
        click.echo(f'Error: {e}', err=True)
        raise SystemExit(1) from None

    for filepath in created:
        click.echo(f'  created {filepath.relative_to(root)}')
    click.echo(f'\nInitialized .planning/ with {len(created)} file(s).')


@cli.command()
@click.option(
    '--path', type=click.Path(exists=True, path_type=Path), default='.', help='Project root (default: current directory).'
)
def status(path: Path) -> None:
    """Display current workflow state."""
    root = path.resolve()
    try:
        content = read_state(root)
    except FileNotFoundError as e:
        click.echo(f'Error: {e}', err=True)
        raise SystemExit(1) from None

    click.echo(content, nl=False)


@cli.command()
@click.argument('phase', type=click.Choice(PHASES))
@click.option('--force', is_flag=True, help='Bypass precondition checks.')
@click.option(
    '--path', type=click.Path(exists=True, path_type=Path), default='.', help='Project root (default: current directory).'
)
@click.option('--note', default='', help='Note for history table.')
def transition(phase: str, force: bool, path: Path, note: str) -> None:
    """Transition workflow to a new phase."""
    root = path.resolve()
    try:
        new_phase = workflow_transition(root, phase, force=force, note=note)
    except FileNotFoundError as e:
        click.echo(f'Error: {e}', err=True)
        raise SystemExit(1) from None
    except ValueError as e:
        click.echo(f'Error: {e}', err=True)
        raise SystemExit(1) from None
    except PreconditionError as e:
        click.echo(f'Error: {e}', err=True)
        raise SystemExit(1) from None

    click.echo(f'Transitioned to: {new_phase}')


@cli.command('plan-status')
@click.option('--json', 'as_json', is_flag=True, help='Output as JSON (for ralph).')
@click.option(
    '--path', type=click.Path(exists=True, path_type=Path), default='.', help='Project root (default: current directory).'
)
def plan_status(as_json: bool, path: Path) -> None:
    """Display plan progress summary."""
    root = path.resolve()
    try:
        content = read_plan(root)
    except FileNotFoundError as e:
        click.echo(f'Error: {e}', err=True)
        raise SystemExit(1) from None

    tasks = parse_plan_tasks(content)
    try:
        status = get_plan_status(content)
    except ValueError as e:
        click.echo(f'Error: {e}', err=True)
        raise SystemExit(1) from None

    counts = Counter(t.status for t in tasks)
    total = len(tasks)
    done = counts.get('done', 0)
    waves = sorted({t.wave for t in tasks})
    current_wave = min((t.wave for t in tasks if t.status != 'done'), default=max(waves, default=0))
    next_task = next((t for t in tasks if t.status == 'pending'), None)

    if as_json:
        click.echo(
            json.dumps(
                {
                    'status': status,
                    'total': total,
                    'done': done,
                    'pending': counts.get('pending', 0),
                    'in_progress': counts.get('in-progress', 0),
                    'blocked': counts.get('blocked', 0),
                    'current_wave': current_wave,
                    'total_waves': len(waves),
                    'next_task': next_task.id if next_task else None,
                }
            )
        )
    else:
        click.echo(f'Plan: {status} | Wave: {current_wave}/{len(waves)} | Tasks: {done}/{total} done', nl=False)
        if next_task:
            click.echo(f' | Next: {next_task.id}')
        else:
            click.echo()


def main() -> None:
    """Entry point for gsd-lean CLI."""
    cli(standalone_mode=False)
    # standalone_mode=False means Click won't call sys.exit itself;
    # we handle exit via SystemExit in command handlers.
