"""Planning state management for the .planning/ directory."""

import re
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

PLANNING_DIR = '.planning'

PHASES = ('discuss', 'plan', 'execute', 'verify', 'complete')

PLANNING_FILES: dict[str, str] = {
    'PROJECT.md': """\
# Project Overview

> Fill in project details during the discuss phase.

## Stack

- **Language:**
- **Framework:**
- **Key dependencies:**

## Constraints

- (none yet)

## Notes

- (none yet)
""",
    'REQUIREMENTS.md': """\
# Requirements

> Captured during the discuss phase. Updated as understanding evolves.

## User Intent

- (not yet defined)

## Functional Requirements

- (none yet)

## Non-Functional Requirements

- (none yet)
""",
    'DECISIONS.md': """\
# Decisions

> Key decisions, preferences, and constraints captured during discussion.

## Architecture

- (none yet)

## Style & Preferences

- (none yet)

## Constraints

- (none yet)
""",
    'ROADMAP.md': """\
# Roadmap

> High-level plan and phase tracking.

## Phases

| Phase | Description | Status |
|-------|-------------|--------|
| 1     |             | pending |

## Notes

- (none yet)
""",
    'STATE.md': """\
# Workflow State

## Current Phase

`discuss`

## Active Task

(none)

## Blockers

(none)

## History

| Timestamp | Phase | Note |
|-----------|-------|------|
""",
}


@dataclass(frozen=True)
class PlanTask:
    """A single task parsed from PLAN.md."""

    id: str
    wave: int
    status: str
    title: str
    files: str
    verification: str


PLAN_TEMPLATE = """\
# Plan

> **Status:** draft
> **Created:** {created}
> **Waves:** 0
> **Source:** REQUIREMENTS.md

## Tasks

| ID | Wave | Status | Title | Files | Verification |
|----|------|--------|-------|-------|-------------|

## Task Details

(No tasks yet. Run /plan to generate.)
"""

_VALID_PLAN_STATUSES = frozenset({'draft', 'verified', 'in-progress', 'complete'})
_VALID_TASK_STATUSES = frozenset({'pending', 'in-progress', 'done', 'blocked'})


def init_planning(root: Path, *, force: bool = False) -> list[Path]:
    """Scaffold the .planning/ directory with template files.

    Args:
        root: Project root directory where .planning/ will be created.
        force: If True, overwrite existing files. If False, skip files that already exist.

    Returns:
        List of file paths that were created or overwritten.

    Raises:
        FileExistsError: If .planning/ exists and force is False and all files already exist.
    """
    planning_dir = root / PLANNING_DIR
    planning_dir.mkdir(parents=True, exist_ok=True)

    created: list[Path] = []
    skipped: list[Path] = []

    for filename, content in PLANNING_FILES.items():
        filepath = planning_dir / filename
        if filepath.exists() and not force:
            skipped.append(filepath)
            continue
        filepath.write_text(content)
        created.append(filepath)

    if not created and skipped:
        raise FileExistsError(f'{PLANNING_DIR}/ already exists with all files. Use --force to overwrite.')

    return created


def read_state(root: Path) -> str:
    """Read and return the contents of STATE.md.

    Args:
        root: Project root directory containing .planning/.

    Returns:
        Contents of STATE.md as a string.

    Raises:
        FileNotFoundError: If .planning/STATE.md does not exist.
    """
    state_file = root / PLANNING_DIR / 'STATE.md'
    if not state_file.exists():
        raise FileNotFoundError(f'{PLANNING_DIR}/STATE.md not found. Run `gsd-lean init` first.')
    return state_file.read_text()


def write_state(root: Path, phase: str, note: str = '') -> None:
    """Update STATE.md with a new phase and append a history row.

    Args:
        root: Project root containing .planning/.
        phase: New phase name (must be one of PHASES).
        note: Optional note for the history table row.

    Raises:
        FileNotFoundError: If .planning/STATE.md does not exist.
        ValueError: If phase is not a valid phase name or STATE.md format is unexpected.
    """
    if phase not in PHASES:
        raise ValueError(f'Invalid phase: {phase!r}. Must be one of {PHASES}.')

    state_file = root / PLANNING_DIR / 'STATE.md'
    if not state_file.exists():
        raise FileNotFoundError(f'{PLANNING_DIR}/STATE.md not found. Run `gsd-lean init` first.')

    content = state_file.read_text()

    # Replace the phase line (first backtick-wrapped word after ## Current Phase)
    new_content, count = re.subn(
        r'(## Current Phase\s*\n\s*)`\w+`',
        rf'\1`{phase}`',
        content,
        count=1,
    )
    if count == 0:
        raise ValueError('STATE.md has unexpected format: could not find phase line under ## Current Phase.')

    # Append history row
    timestamp = datetime.now(UTC).strftime('%Y-%m-%dT%H:%M:%SZ')
    history_row = f'| {timestamp} | {phase} | {note} |\n'
    new_content = new_content.rstrip('\n') + '\n' + history_row

    state_file.write_text(new_content)


def read_plan(root: Path) -> str:
    """Read and return contents of PLAN.md.

    Args:
        root: Project root containing .planning/.

    Returns:
        Contents of PLAN.md as a string.

    Raises:
        FileNotFoundError: If .planning/PLAN.md does not exist.
    """
    plan_file = root / PLANNING_DIR / 'PLAN.md'
    if not plan_file.exists():
        raise FileNotFoundError(f'{PLANNING_DIR}/PLAN.md not found. Run `/plan` to generate a plan.')
    return plan_file.read_text()


def parse_plan_tasks(content: str) -> list[PlanTask]:
    """Parse the task table from PLAN.md content.

    Args:
        content: Raw PLAN.md file content.

    Returns:
        List of PlanTask dataclasses. Returns empty list if no tasks found.
        Malformed rows are skipped with no error.
    """
    tasks: list[PlanTask] = []
    for match in re.finditer(
        r'^\|\s*(T-\d{3})\s*\|\s*(\d+)\s*\|\s*(\S+)\s*\|\s*(.+?)\s*\|\s*(.+?)\s*\|\s*(.+?)\s*\|',
        content,
        re.MULTILINE,
    ):
        task_id, wave_str, status, title, files, verification = match.groups()
        if status not in _VALID_TASK_STATUSES:
            continue
        try:
            wave = int(wave_str)
        except ValueError:
            continue
        tasks.append(
            PlanTask(
                id=task_id,
                wave=wave,
                status=status,
                title=title.strip(),
                files=files.strip(),
                verification=verification.strip(),
            )
        )
    return tasks


def get_plan_status(content: str) -> str:
    """Extract the Status header value from PLAN.md content.

    Args:
        content: Raw PLAN.md file content.

    Returns:
        Status string ('draft', 'verified', 'in-progress', 'complete').

    Raises:
        ValueError: If Status header is missing or has invalid value.
    """
    match = re.search(r'>\s*\*\*Status:\*\*\s*(\S+)', content)
    if not match:
        raise ValueError('PLAN.md is missing the Status header.')
    status = match.group(1).strip()
    if status not in _VALID_PLAN_STATUSES:
        raise ValueError(f'Invalid plan status: {status!r}. Must be one of {sorted(_VALID_PLAN_STATUSES)}.')
    return status
