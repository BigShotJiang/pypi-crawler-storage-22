"""Integration tests for CLI subcommands."""

import json

from click.testing import CliRunner

from gsd_lean.cli.app import cli
from gsd_lean.state.planning import PLANNING_DIR, PLANNING_FILES


class TestInitCommand:
    """Tests for the gsd-lean init subcommand."""

    def test_init_creates_files(self, tmp_path):
        """Test that init creates all planning files and prints output."""
        runner = CliRunner()
        result = runner.invoke(cli, ['init', '--path', str(tmp_path)])
        assert result.exit_code == 0
        assert 'Initialized .planning/' in result.output
        assert '5 file(s)' in result.output

        for filename in PLANNING_FILES:
            assert (tmp_path / PLANNING_DIR / filename).exists()

    def test_init_fails_if_exists(self, tmp_path):
        """Test that init fails when .planning/ already has all files."""
        runner = CliRunner()
        # First init
        runner.invoke(cli, ['init', '--path', str(tmp_path)])

        # Second init should fail
        result = runner.invoke(cli, ['init', '--path', str(tmp_path)])
        assert result.exit_code == 1
        assert 'already exists' in result.output

    def test_init_force_overwrites(self, tmp_path):
        """Test that init --force overwrites existing files."""
        runner = CliRunner()
        runner.invoke(cli, ['init', '--path', str(tmp_path)])

        result = runner.invoke(cli, ['init', '--force', '--path', str(tmp_path)])
        assert result.exit_code == 0
        assert '5 file(s)' in result.output


class TestStatusCommand:
    """Tests for the gsd-lean status subcommand."""

    def test_status_shows_state(self, tmp_path):
        """Test that status displays STATE.md content."""
        runner = CliRunner()
        # Init first
        runner.invoke(cli, ['init', '--path', str(tmp_path)])

        # Then status
        result = runner.invoke(cli, ['status', '--path', str(tmp_path)])
        assert result.exit_code == 0
        assert '# Workflow State' in result.output
        assert '`discuss`' in result.output

    def test_status_fails_without_init(self, tmp_path):
        """Test that status fails when .planning/ does not exist."""
        runner = CliRunner()
        result = runner.invoke(cli, ['status', '--path', str(tmp_path)])
        assert result.exit_code == 1
        assert 'not found' in result.output


_POPULATED_REQUIREMENTS = """\
# Requirements

> Captured during the discuss phase. Updated as understanding evolves.

## User Intent

- Build a widget system

## Functional Requirements

- Widget CRUD operations

## Non-Functional Requirements

- 90% test coverage
"""

_VERIFIED_PLAN = """\
# Plan

> **Status:** verified
> **Created:** 2026-02-01T14:30:00Z
> **Waves:** 1
> **Source:** REQUIREMENTS.md

## Tasks

| ID | Wave | Status | Title | Files | Verification |
|----|------|--------|-------|-------|-------------|
| T-001 | 1 | done | Create widget module | `src/widget.py` | unit tests pass |

## Task Details

### T-001: Create widget module
...
"""

_MULTI_WAVE_PLAN = """\
# Plan

> **Status:** verified
> **Created:** 2026-02-01T14:30:00Z
> **Waves:** 3
> **Source:** REQUIREMENTS.md

## Tasks

| ID | Wave | Status | Title | Files | Verification |
|----|------|--------|-------|-------|-------------|
| T-001 | 1 | done | Create workflow module | `src/workflow.py` | unit tests pass |
| T-002 | 1 | done | Add state functions | `src/state.py` | unit tests pass |
| T-003 | 2 | done | Add preconditions | `src/workflow.py` | tests pass |
| T-004 | 2 | done | Add transition CLI | `src/cli.py` | tests pass |
| T-005 | 2 | in-progress | Add plan-status CLI | `src/cli.py` | tests pass |
| T-006 | 3 | pending | Create discuss skill | `skills/discuss/SKILL.md` | skill loads |
| T-007 | 3 | pending | Create plan skill | `skills/plan/SKILL.md` | skill loads |
| T-008 | 3 | blocked | Update CLAUDE.md | `CLAUDE.md` | table updated |
"""


class TestTransitionCommand:
    """Tests for the gsd-lean transition subcommand."""

    def test_transition_happy_path(self, tmp_path):
        """Test happy path: exit 0, 'Transitioned to: plan' output."""
        runner = CliRunner()
        runner.invoke(cli, ['init', '--path', str(tmp_path)])
        # Populate requirements to satisfy precondition
        (tmp_path / PLANNING_DIR / 'REQUIREMENTS.md').write_text(_POPULATED_REQUIREMENTS)

        result = runner.invoke(cli, ['transition', 'plan', '--path', str(tmp_path)])
        assert result.exit_code == 0
        assert 'Transitioned to: plan' in result.output

    def test_transition_invalid_phase(self, tmp_path):
        """Test that an invalid phase name produces an error."""
        runner = CliRunner()
        runner.invoke(cli, ['init', '--path', str(tmp_path)])

        result = runner.invoke(cli, ['transition', 'foo', '--path', str(tmp_path)])
        assert result.exit_code != 0

    def test_transition_precondition_fail(self, tmp_path):
        """Test exit 1 and precondition error message when requirements unpopulated."""
        runner = CliRunner()
        runner.invoke(cli, ['init', '--path', str(tmp_path)])

        result = runner.invoke(cli, ['transition', 'plan', '--path', str(tmp_path)])
        assert result.exit_code == 1
        assert 'template placeholders' in result.output

    def test_transition_force(self, tmp_path):
        """Test exit 0 despite failed precondition when --force is used."""
        runner = CliRunner()
        runner.invoke(cli, ['init', '--path', str(tmp_path)])

        result = runner.invoke(cli, ['transition', 'plan', '--force', '--path', str(tmp_path)])
        assert result.exit_code == 0
        assert 'Transitioned to: plan' in result.output

    def test_transition_with_note(self, tmp_path):
        """Test that --note adds text to the history row."""
        runner = CliRunner()
        runner.invoke(cli, ['init', '--path', str(tmp_path)])
        (tmp_path / PLANNING_DIR / 'REQUIREMENTS.md').write_text(_POPULATED_REQUIREMENTS)

        result = runner.invoke(cli, ['transition', 'plan', '--note', 'Starting planning', '--path', str(tmp_path)])
        assert result.exit_code == 0

        content = (tmp_path / PLANNING_DIR / 'STATE.md').read_text()
        assert 'Starting planning' in content


class TestPlanStatusCommand:
    """Tests for the gsd-lean plan-status subcommand."""

    def test_plan_status_human(self, tmp_path):
        """Test human-readable output format."""
        runner = CliRunner()
        runner.invoke(cli, ['init', '--path', str(tmp_path)])
        (tmp_path / PLANNING_DIR / 'PLAN.md').write_text(_MULTI_WAVE_PLAN)

        result = runner.invoke(cli, ['plan-status', '--path', str(tmp_path)])
        assert result.exit_code == 0
        assert 'Plan: verified' in result.output
        assert 'Wave: 2/3' in result.output
        assert 'Tasks: 4/8 done' in result.output
        assert 'Next: T-006' in result.output

    def test_plan_status_json(self, tmp_path):
        """Test JSON output contains all expected fields."""
        runner = CliRunner()
        runner.invoke(cli, ['init', '--path', str(tmp_path)])
        (tmp_path / PLANNING_DIR / 'PLAN.md').write_text(_MULTI_WAVE_PLAN)

        result = runner.invoke(cli, ['plan-status', '--json', '--path', str(tmp_path)])
        assert result.exit_code == 0

        data = json.loads(result.output)
        assert data['status'] == 'verified'
        assert data['total'] == 8
        assert data['done'] == 4
        assert data['pending'] == 2
        assert data['in_progress'] == 1
        assert data['blocked'] == 1
        assert data['current_wave'] == 2
        assert data['total_waves'] == 3
        assert data['next_task'] == 'T-006'

    def test_plan_status_no_plan(self, tmp_path):
        """Test exit 1 when PLAN.md does not exist."""
        runner = CliRunner()
        runner.invoke(cli, ['init', '--path', str(tmp_path)])

        result = runner.invoke(cli, ['plan-status', '--path', str(tmp_path)])
        assert result.exit_code == 1
        assert 'not found' in result.output
