"""Tests for the state management module."""

import re

import pytest

from gsd_lean.state.planning import (
    PLANNING_DIR,
    PLANNING_FILES,
    PlanTask,
    get_plan_status,
    init_planning,
    parse_plan_tasks,
    read_plan,
    read_state,
    write_state,
)


class TestInitPlanning:
    """Tests for init_planning function."""

    def test_creates_planning_directory(self, tmp_path):
        """Test that init creates the .planning/ directory."""
        init_planning(tmp_path)
        assert (tmp_path / PLANNING_DIR).is_dir()

    def test_creates_all_five_files(self, tmp_path):
        """Test that init creates all 5 core planning files."""
        created = init_planning(tmp_path)
        assert len(created) == 5
        for filename in PLANNING_FILES:
            assert (tmp_path / PLANNING_DIR / filename).exists()

    def test_file_contents_match_templates(self, tmp_path):
        """Test that created files contain the expected template content."""
        init_planning(tmp_path)
        for filename, expected_content in PLANNING_FILES.items():
            actual = (tmp_path / PLANNING_DIR / filename).read_text()
            assert actual == expected_content

    def test_returns_created_paths(self, tmp_path):
        """Test that init returns the list of created file paths."""
        created = init_planning(tmp_path)
        filenames = {p.name for p in created}
        assert filenames == set(PLANNING_FILES.keys())

    def test_raises_if_all_files_exist(self, tmp_path):
        """Test that init raises FileExistsError when all files already exist."""
        init_planning(tmp_path)
        with pytest.raises(FileExistsError, match='already exists'):
            init_planning(tmp_path)

    def test_skips_existing_creates_missing(self, tmp_path):
        """Test that init only creates missing files, skipping existing ones."""
        init_planning(tmp_path)

        # Remove one file
        (tmp_path / PLANNING_DIR / 'STATE.md').unlink()

        # Re-init without force should create only the missing file
        created = init_planning(tmp_path)
        assert len(created) == 1
        assert created[0].name == 'STATE.md'

    def test_force_overwrites_existing(self, tmp_path):
        """Test that --force overwrites all files."""
        init_planning(tmp_path)

        # Modify a file
        state_file = tmp_path / PLANNING_DIR / 'STATE.md'
        state_file.write_text('modified content')

        # Force re-init should overwrite
        created = init_planning(tmp_path, force=True)
        assert len(created) == 5
        assert state_file.read_text() == PLANNING_FILES['STATE.md']

    def test_state_md_has_discuss_phase(self, tmp_path):
        """Test that STATE.md defaults to discuss phase."""
        init_planning(tmp_path)
        content = (tmp_path / PLANNING_DIR / 'STATE.md').read_text()
        assert '`discuss`' in content


class TestReadState:
    """Tests for read_state function."""

    def test_reads_state_content(self, tmp_path):
        """Test that read_state returns STATE.md contents."""
        init_planning(tmp_path)
        content = read_state(tmp_path)
        assert '# Workflow State' in content
        assert '`discuss`' in content

    def test_raises_if_not_initialized(self, tmp_path):
        """Test that read_state raises FileNotFoundError when not initialized."""
        with pytest.raises(FileNotFoundError, match='not found'):
            read_state(tmp_path)


class TestWriteState:
    """Tests for write_state function."""

    def test_updates_phase(self, tmp_path):
        """Test that write_state changes the phase line from discuss to plan."""
        init_planning(tmp_path)
        write_state(tmp_path, 'plan')
        content = (tmp_path / PLANNING_DIR / 'STATE.md').read_text()
        assert '`plan`' in content
        assert '`discuss`' not in content

    def test_appends_history_row(self, tmp_path):
        """Test that write_state appends a new row with ISO timestamp to the history table."""
        init_planning(tmp_path)
        write_state(tmp_path, 'plan', note='Starting planning')
        content = (tmp_path / PLANNING_DIR / 'STATE.md').read_text()
        assert '| plan | Starting planning |' in content
        # Check ISO 8601 timestamp format
        assert re.search(r'\| \d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z \|', content)

    def test_preserves_other_content(self, tmp_path):
        """Test that write_state preserves Active Task, Blockers, and other sections."""
        init_planning(tmp_path)
        write_state(tmp_path, 'plan')
        content = (tmp_path / PLANNING_DIR / 'STATE.md').read_text()
        assert '## Active Task' in content
        assert '## Blockers' in content
        assert '## History' in content
        assert '# Workflow State' in content

    def test_invalid_phase(self, tmp_path):
        """Test that write_state raises ValueError for invalid phase name."""
        init_planning(tmp_path)
        with pytest.raises(ValueError, match='Invalid phase'):
            write_state(tmp_path, 'invalid')

    def test_missing_file(self, tmp_path):
        """Test that write_state raises FileNotFoundError if STATE.md is absent."""
        with pytest.raises(FileNotFoundError, match='not found'):
            write_state(tmp_path, 'plan')

    def test_broken_format(self, tmp_path):
        """Test that write_state raises ValueError if STATE.md has unexpected format."""
        init_planning(tmp_path)
        state_file = tmp_path / PLANNING_DIR / 'STATE.md'
        state_file.write_text('# Completely different content\n')
        with pytest.raises(ValueError, match='unexpected format'):
            write_state(tmp_path, 'plan')


class TestReadPlan:
    """Tests for read_plan function."""

    def test_reads_plan_content(self, tmp_path):
        """Test that read_plan returns PLAN.md contents."""
        init_planning(tmp_path)
        plan_file = tmp_path / PLANNING_DIR / 'PLAN.md'
        plan_file.write_text('# Plan\n\n> **Status:** draft\n')
        content = read_plan(tmp_path)
        assert '# Plan' in content

    def test_raises_if_missing(self, tmp_path):
        """Test that read_plan raises FileNotFoundError when PLAN.md does not exist."""
        init_planning(tmp_path)
        with pytest.raises(FileNotFoundError, match='PLAN.md not found'):
            read_plan(tmp_path)


SAMPLE_PLAN = """\
# Plan

> **Status:** verified
> **Created:** 2026-02-01T14:30:00Z
> **Waves:** 2
> **Source:** REQUIREMENTS.md

## Tasks

| ID | Wave | Status | Title | Files | Verification |
|----|------|--------|-------|-------|-------------|
| T-001 | 1 | done | Create workflow module | `src/workflow.py` | unit tests pass |
| T-002 | 1 | in-progress | Add state functions | `src/state.py` | unit tests pass |
| T-003 | 2 | pending | Add CLI commands | `src/cli.py` | CLI tests pass |

## Task Details

### T-001: Create workflow module
...
"""


class TestParsePlanTasks:
    """Tests for parse_plan_tasks function."""

    def test_happy_path(self, tmp_path):
        """Test that parse_plan_tasks parses a valid table into PlanTask list."""
        tasks = parse_plan_tasks(SAMPLE_PLAN)
        assert len(tasks) == 3
        assert tasks[0] == PlanTask(
            id='T-001',
            wave=1,
            status='done',
            title='Create workflow module',
            files='`src/workflow.py`',
            verification='unit tests pass',
        )
        assert tasks[1].status == 'in-progress'
        assert tasks[2].id == 'T-003'
        assert tasks[2].wave == 2

    def test_empty(self):
        """Test that parse_plan_tasks returns empty list when no tasks are found."""
        content = '# Plan\n\n> **Status:** draft\n\n## Tasks\n\n| ID | Wave | ... |\n|----|------|\n'
        tasks = parse_plan_tasks(content)
        assert tasks == []

    def test_malformed_row(self):
        """Test that parse_plan_tasks skips malformed rows and parses valid ones."""
        content = """\
| ID | Wave | Status | Title | Files | Verification |
|----|------|--------|-------|-------|-------------|
| T-001 | 1 | done | Good task | `file.py` | tests pass |
| broken row with missing columns |
| T-002 | abc | done | Bad wave | `file.py` | tests pass |
| T-003 | 2 | invalid_status | Bad status | `file.py` | tests pass |
| T-004 | 2 | pending | Also good | `file2.py` | lint pass |
"""
        tasks = parse_plan_tasks(content)
        assert len(tasks) == 2
        assert tasks[0].id == 'T-001'
        assert tasks[1].id == 'T-004'


class TestGetPlanStatus:
    """Tests for get_plan_status function."""

    def test_extracts_verified(self):
        """Test that get_plan_status extracts 'verified' from header."""
        assert get_plan_status(SAMPLE_PLAN) == 'verified'

    def test_extracts_draft(self):
        """Test that get_plan_status extracts 'draft' from header."""
        content = '# Plan\n\n> **Status:** draft\n'
        assert get_plan_status(content) == 'draft'

    def test_missing_header(self):
        """Test that get_plan_status raises ValueError when Status header is missing."""
        with pytest.raises(ValueError, match='missing the Status header'):
            get_plan_status('# Plan\n\nNo status here.\n')

    def test_invalid_status_value(self):
        """Test that get_plan_status raises ValueError for invalid status values."""
        with pytest.raises(ValueError, match='Invalid plan status'):
            get_plan_status('> **Status:** unknown\n')
