## [unreleased]

### 🚀 Features

- Fail hard in /init when uvx is not installed ([#77](https://github.com/Bifurcate-Loops/gsd-lean/issues/77))
- *(execute)* Block /execute on default branch ([#81](https://github.com/Bifurcate-Loops/gsd-lean/issues/81))

### 🐛 Bug Fixes

- *(execute)* Scope task loop to user-specified target set ([#80](https://github.com/Bifurcate-Loops/gsd-lean/issues/80))
- *(execute)* Scope verify subagent commits to changed files only ([#82](https://github.com/Bifurcate-Loops/gsd-lean/issues/82))

### 📚 Documentation

- Update README and PROJECT_KNOWLEDGE with init phase, Quick Start, Caveats ([#79](https://github.com/Bifurcate-Loops/gsd-lean/issues/79))
## [0.5.0] - 2026-02-11

### 🚀 Features

- Add tracer bullet concept to /plan skill (PRD-017) ([#64](https://github.com/Bifurcate-Loops/gsd-lean/issues/64))

### 🐛 Bug Fixes

- Add verify subagent to config.yaml scaffold template ([#60](https://github.com/Bifurcate-Loops/gsd-lean/issues/60))

### 💼 Other

- Rewrite /init skill with two-phase flow (PRD-015) ([#61](https://github.com/Bifurcate-Loops/gsd-lean/issues/61))
- Move PLAN.md update & commit into verify subagent (PRD-016) ([#62](https://github.com/Bifurcate-Loops/gsd-lean/issues/62))

### ⚙️ Miscellaneous Tasks

- Release v0.5.0 ([#65](https://github.com/Bifurcate-Loops/gsd-lean/issues/65))
## [0.4.1] - 2026-02-11

### 🐛 Bug Fixes

- Replace skill invocations with subagents in /execute loop (PRD-014) ([#55](https://github.com/Bifurcate-Loops/gsd-lean/issues/55))
- Prefix skill output references with gsd-lean: ([#46](https://github.com/Bifurcate-Loops/gsd-lean/issues/46))

### ⚙️ Miscellaneous Tasks

- Release v0.4.1 ([#57](https://github.com/Bifurcate-Loops/gsd-lean/issues/57))
## [0.4.0] - 2026-02-11

### 🚀 Features

- Documentation refactoring — static/ephemeral split (PRD-013) ([#50](https://github.com/Bifurcate-Loops/gsd-lean/issues/50))

### ⚙️ Miscellaneous Tasks

- Release v0.4.0 ([#51](https://github.com/Bifurcate-Loops/gsd-lean/issues/51))
## [0.3.0] - 2026-02-10

### 🚀 Features

- Always copy statusline script, inform user if already configured ([#40](https://github.com/Bifurcate-Loops/gsd-lean/issues/40))
- Init skill detection improvements (PRD-012) ([#44](https://github.com/Bifurcate-Loops/gsd-lean/issues/44))

### ⚙️ Miscellaneous Tasks

- Release v0.3.0 ([#45](https://github.com/Bifurcate-Loops/gsd-lean/issues/45))
## [0.2.1] - 2026-02-10

### ⚙️ Miscellaneous Tasks

- Release v0.2.1 ([#39](https://github.com/Bifurcate-Loops/gsd-lean/issues/39))
## [0.2.1a1] - 2026-02-10

### 🐛 Bug Fixes

- Sync plugin.json version before tagging ([#38](https://github.com/Bifurcate-Loops/gsd-lean/issues/38))

### ⚙️ Miscellaneous Tasks

- Sync plugin version to v0.2.0 [skip ci]
- Sync plugin version to v0.2.1a1
## [0.2.0] - 2026-02-10

### 🚀 Features

- Configurable subagent settings (PRD-011)

### 🐛 Bug Fixes

- Skill quote formatting + CLI version command ([#34](https://github.com/Bifurcate-Loops/gsd-lean/issues/34))
- Ralph early exit after verify + ctrl+c support ([#36](https://github.com/Bifurcate-Loops/gsd-lean/issues/36))

### ⚙️ Miscellaneous Tasks

- Sync plugin version to v0.2.0a2 [skip ci]
- Release v0.2.0 ([#37](https://github.com/Bifurcate-Loops/gsd-lean/issues/37))
## [0.2.0a2] - 2026-02-09

### 🚀 Features

- Add plan mode + CLAUDE.md reading to /init skill
- Expand /discuss skill with codebase exploration, context7 MCP, verification subagent ([#32](https://github.com/Bifurcate-Loops/gsd-lean/issues/32))

### 🐛 Bug Fixes

- Remove old hello skill

### ⚙️ Miscellaneous Tasks

- Sync plugin version to v0.2.0a1 [skip ci]
- Move marketplace.json to bifurcate-plugins repo
## [0.2.0a1] - 2026-02-09

### 🚀 Features

- Add pre-release support (alpha/beta/RC) ([#16](https://github.com/Bifurcate-Loops/gsd-lean/issues/16))
- Add statusline hook installer with non-git support ([#18](https://github.com/Bifurcate-Loops/gsd-lean/issues/18))
- Phase 3 execution loop (PRD-004) ([#23](https://github.com/Bifurcate-Loops/gsd-lean/issues/23))
- Add /init skill with project stack auto-detection (PRD-005)
- Add plan mode enforcement to /discuss and /plan skills (PRD-006)
- Sync plugin.json version with git tag on release (PRD-008) ([#29](https://github.com/Bifurcate-Loops/gsd-lean/issues/29))

### 🐛 Bug Fixes

- Backtick parsing in skill template expansions ([#17](https://github.com/Bifurcate-Loops/gsd-lean/issues/17))
- Replace $() substitution with xargs pipe in skill context commands
- Update argument hint in pre-release and release skills
- Allow xargs in skill context commands for tag-based log queries

### 📚 Documentation

- Add 5-phase workflow state machine to README and PROJECT_KNOWLEDGE
- Add LSP-first guidance to PRD skill codebase exploration
- Add tracer bullet guidance to PRD skill template

### ⚙️ Miscellaneous Tasks

- Small restructure, remove coverage files from docker sandbox session
- Migrate type checking from mypy to pyright ([#28](https://github.com/Bifurcate-Loops/gsd-lean/issues/28))
## [0.1.0] - 2026-02-06

### 🚀 Features

- Add ralph scripts and PRD skill
- Add Claude Code plugin scaffolding
- Ralph scaffolding and Makefile improvements ([#5](https://github.com/Bifurcate-Loops/gsd-lean/issues/5))
- Add code-simplifier agent to gsd-lite plugin ([#7](https://github.com/Bifurcate-Loops/gsd-lean/issues/7))
- Add statusline hook with git info and context window bar ([#8](https://github.com/Bifurcate-Loops/gsd-lean/issues/8))
- Phase 1 State System + fix pre-commit for Docker sandbox ([#9](https://github.com/Bifurcate-Loops/gsd-lean/issues/9))
- Phase 2 workflow planning engine (PRD 003)
- Enable PyPI publishing via trusted OIDC ([#14](https://github.com/Bifurcate-Loops/gsd-lean/issues/14))
- Add git-cliff changelog generation ([#15](https://github.com/Bifurcate-Loops/gsd-lean/issues/15))

### 🐛 Bug Fixes

- Add contents:read permission to pypi-publish job

### ⚙️ Miscellaneous Tasks

- Initialize project scaffolding
- Add Claude Code docs and config fixes ([#6](https://github.com/Bifurcate-Loops/gsd-lean/issues/6))
- Add Serena MCP server config + docs ([#10](https://github.com/Bifurcate-Loops/gsd-lean/issues/10))
- Remove Serena MCP server in favour of built-in LSP tool
- Rename gsd-lite → gsd-lean (PyPI name conflict)
- Update plugin.json repo URL to gsd-lean
