#!/bin/bash

# Read JSON input from stdin
input=$(cat)
cwd=$(echo "$input" | jq -r '.workspace.current_dir')

# Colors
CYAN='\033[36m'
GREEN='\033[32m'
YELLOW='\033[33m'
DIM='\033[2m'
RESET='\033[0m'

# Context window bar (always shown)
ctx=""
remaining=$(echo "$input" | jq -r '.context_window.remaining_percentage // empty')
if [ -n "$remaining" ]; then
    remaining_int=$(printf '%.0f' "$remaining")
    used=$((100 - remaining_int))
    [ "$used" -lt 0 ] && used=0
    [ "$used" -gt 100 ] && used=100

    # Build 10-segment bar
    filled=$((used / 10))
    empty=$((10 - filled))
    bar=""
    [ "$filled" -gt 0 ] && bar=$(printf '%0.s█' $(seq 1 $filled))
    [ "$empty" -gt 0 ] && bar="${bar}$(printf '%0.s░' $(seq 1 $empty))"

    # Color by threshold
    if [ "$used" -lt 50 ]; then
        ctx=" \033[32m${bar} ${used}%\033[0m"
    elif [ "$used" -lt 65 ]; then
        ctx=" \033[33m${bar} ${used}%\033[0m"
    elif [ "$used" -lt 80 ]; then
        ctx=" \033[38;5;208m${bar} ${used}%\033[0m"
    else
        ctx=" \033[5;31m💀 ${bar} ${used}%\033[0m"
    fi
fi

# Check if we're in a git repository
if cd "$cwd" 2>/dev/null && git rev-parse --git-dir > /dev/null 2>&1; then
    # Get repository root path
    repo_root=$(git rev-parse --show-toplevel 2>/dev/null)
    repo_name=$(basename "$repo_root")
    repo_parent=$(basename "$(dirname "$repo_root")")

    # Format as parent/repo (e.g., bifurcate/gsd-lean)
    repo_display="${repo_parent}/${repo_name}"

    # Get current branch
    branch=$(git branch --show-current 2>/dev/null || echo 'detached')

    # Get git status counts (skip optional locks)
    git_status=$(git -c core.useBuiltinFSMonitor=false status --porcelain 2>/dev/null)
    staged=$(echo "$git_status" | grep -c '^[AMDRC]')
    unstaged=$(echo "$git_status" | grep -c '^.[MD]')
    untracked=$(git ls-files --others --exclude-standard 2>/dev/null | wc -l | tr -d ' ')

    echo -e "${CYAN}${repo_display}${RESET} | ${GREEN}${branch}${RESET} | S: ${YELLOW}${staged}${RESET} | U: ${YELLOW}${unstaged}${RESET} | A: ${YELLOW}${untracked}${RESET} |${ctx}"
else
    folder_name=$(basename "$cwd")
    echo -e "${CYAN}${folder_name}${RESET} | ${DIM}no git${RESET} |${ctx}"
fi
