"""Project stack auto-detection from repository files."""

from __future__ import annotations

import json
import logging
import re
import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, cast

logger = logging.getLogger(__name__)

MANIFEST_MAP: dict[str, str] = {
    'pyproject.toml': 'python',
    'setup.py': 'python',
    'setup.cfg': 'python',
    'requirements.txt': 'python',
    'package.json': 'javascript',
    'tsconfig.json': 'typescript',
    'Cargo.toml': 'rust',
    'go.mod': 'go',
    'Gemfile': 'ruby',
    'build.gradle': 'java',
    'build.gradle.kts': 'kotlin',
    'pom.xml': 'java',
    'mix.exs': 'elixir',
    'pubspec.yaml': 'dart',
    'composer.json': 'php',
    'CMakeLists.txt': 'cpp',
    'Makefile': '',
}

CI_CONFIGS: dict[str, str] = {
    '.github/workflows': 'GitHub Actions',
    '.gitlab-ci.yml': 'GitLab CI',
    'Jenkinsfile': 'Jenkins',
    '.circleci/config.yml': 'CircleCI',
    '.travis.yml': 'Travis CI',
    'azure-pipelines.yml': 'Azure Pipelines',
}


@dataclass
class McpPluginInfo:
    """Detected MCP servers and plugins."""

    mcp_servers: list[str] = field(default_factory=list[str])
    plugins: list[str] = field(default_factory=list[str])


@dataclass
class StackInfo:
    """Detected project stack information."""

    language: str = ''
    language_version: str = ''
    framework: str = ''
    build_tool: str = ''
    test_runner: str = ''
    linter: str = ''
    formatter: str = ''
    type_checker: str = ''
    ci_platform: str = ''
    runtime_manager: str = ''
    key_dependencies: list[str] = field(default_factory=list[str])


def _parse_dep_name(dep: str) -> str:
    """Extract bare package name from a dependency specifier."""
    for sep in ('>=', '==', '<', '>', '!=', '~=', '[', ';'):
        dep = dep.split(sep, maxsplit=1)[0]
    return dep.strip().lower()


def _detect_python_stack(root: Path) -> StackInfo:
    """Detect Python project details from pyproject.toml."""
    info = StackInfo(language='python')
    pyproject = root / 'pyproject.toml'
    if not pyproject.exists():
        return info

    try:
        with pyproject.open('rb') as f:
            data = tomllib.load(f)
    except tomllib.TOMLDecodeError:
        logger.warning('Failed to parse pyproject.toml — skipping detailed detection.')
        return info

    # Python version
    requires_python = data.get('project', {}).get('requires-python', '')
    if requires_python:
        info.language_version = requires_python

    # Build tool
    build_backend = data.get('build-system', {}).get('build-backend', '')
    for pattern, tool in [('hatchling', 'hatch'), ('setuptools', 'setuptools'), ('flit', 'flit'), ('poetry', 'poetry')]:
        if pattern in build_backend:
            info.build_tool = tool
            break

    # Framework detection from dependencies
    deps = data.get('project', {}).get('dependencies', [])
    dep_names = [_parse_dep_name(d) for d in deps]
    for name, framework in [
        ('django', 'Django'),
        ('flask', 'Flask'),
        ('fastapi', 'FastAPI'),
        ('click', 'Click CLI'),
        ('typer', 'Typer CLI'),
    ]:
        if name in dep_names:
            info.framework = framework
            break

    # Key dependencies (top 5)
    info.key_dependencies = dep_names[:5]

    # Dev dependencies from dependency-groups
    dev_dep_names = _collect_dev_dep_names(data)

    # Test runner
    if 'pytest' in dev_dep_names or any('pytest' in d for d in dev_dep_names):
        info.test_runner = 'pytest'

    # Linter/formatter
    tool_section = data.get('tool', {})
    if 'ruff' in dev_dep_names or 'ruff' in tool_section:
        info.linter = 'ruff'
        info.formatter = 'ruff'
    elif 'flake8' in dev_dep_names:
        info.linter = 'flake8'
    if 'black' in dev_dep_names:
        info.formatter = 'black'

    # Type checker
    if 'pyright' in dev_dep_names:
        info.type_checker = 'pyright'
    elif 'mypy' in dev_dep_names:
        info.type_checker = 'mypy'

    return info


def _collect_dev_dep_names(data: dict[str, Any]) -> list[str]:
    """Collect dependency names from all dependency-groups."""
    dep_groups = data.get('dependency-groups')
    if not isinstance(dep_groups, dict):
        return []
    result: list[str] = []
    for group in cast(dict[str, Any], dep_groups).values():
        if not isinstance(group, list):
            continue
        for item in cast(list[Any], group):
            if isinstance(item, str):
                result.append(item)
    return [_parse_dep_name(d) for d in result]


def _detect_js_stack(root: Path) -> StackInfo:
    """Detect JavaScript/TypeScript project details from package.json."""
    language = 'typescript' if (root / 'tsconfig.json').exists() else 'javascript'
    info = StackInfo(language=language)
    pkg_file = root / 'package.json'
    if not pkg_file.exists():
        return info

    try:
        data = json.loads(pkg_file.read_text())
    except (json.JSONDecodeError, OSError):
        logger.warning('Failed to parse package.json — skipping detailed detection.')
        return info

    # Language version from engines.node
    node_version = data.get('engines', {}).get('node', '')
    if node_version:
        info.language_version = node_version

    # Dependencies + devDependencies
    deps = data.get('dependencies', {})
    dev_deps = data.get('devDependencies', {})
    dep_names = [k.lower() for k in deps]
    dev_dep_names = [k.lower() for k in dev_deps]
    all_dep_names = dep_names + dev_dep_names

    # Framework detection
    for name, framework in [
        ('next', 'Next.js'),
        ('nuxt', 'Nuxt'),
        ('react', 'React'),
        ('vue', 'Vue'),
        ('@angular/core', 'Angular'),
        ('svelte', 'Svelte'),
        ('express', 'Express'),
        ('fastify', 'Fastify'),
        ('hono', 'Hono'),
    ]:
        if name in dep_names:
            info.framework = framework
            break

    # Key dependencies (top 5)
    info.key_dependencies = dep_names[:5]

    # Test runner
    for name, runner in [('vitest', 'vitest'), ('jest', 'jest'), ('mocha', 'mocha')]:
        if name in all_dep_names:
            info.test_runner = runner
            break

    # Linter
    for name, linter in [('biome', 'biome'), ('@biomejs/biome', 'biome'), ('eslint', 'eslint')]:
        if name in all_dep_names:
            info.linter = linter
            break

    # Formatter
    for name, formatter in [('biome', 'biome'), ('@biomejs/biome', 'biome'), ('prettier', 'prettier')]:
        if name in all_dep_names:
            info.formatter = formatter
            break

    # Type checker (typescript in devDependencies)
    if 'typescript' in all_dep_names:
        info.type_checker = 'typescript'

    # Build tool
    for name, tool in [('vite', 'vite'), ('webpack', 'webpack'), ('esbuild', 'esbuild'), ('rollup', 'rollup')]:
        if name in all_dep_names:
            info.build_tool = tool
            break

    return info


def _detect_rust_stack(root: Path) -> StackInfo:
    """Detect Rust project details from Cargo.toml."""
    info = StackInfo(language='rust', build_tool='cargo')
    cargo_toml = root / 'Cargo.toml'
    if not cargo_toml.exists():
        return info

    try:
        with cargo_toml.open('rb') as f:
            data = tomllib.load(f)
    except tomllib.TOMLDecodeError:
        logger.warning('Failed to parse Cargo.toml — skipping detailed detection.')
        return info

    # Edition (e.g. "2021")
    edition = data.get('package', {}).get('edition', '')
    if edition:
        info.language_version = str(edition)

    # Key dependencies (top 5)
    deps = data.get('dependencies', {})
    dep_names = [k.lower() for k in deps]
    info.key_dependencies = dep_names[:5]

    # Framework detection
    for name, framework in [
        ('axum', 'Axum'),
        ('actix-web', 'Actix Web'),
        ('rocket', 'Rocket'),
        ('warp', 'Warp'),
        ('clap', 'Clap CLI'),
    ]:
        if name in dep_names:
            info.framework = framework
            break

    # Test runner — Rust uses built-in `cargo test`; check for nextest in config
    info.test_runner = 'cargo test'

    # Linter/formatter — built-in to Rust toolchain
    info.linter = 'clippy'
    info.formatter = 'rustfmt'

    return info


def _detect_go_stack(root: Path) -> StackInfo:
    """Detect Go project details from go.mod."""
    info = StackInfo(language='go', build_tool='go build')
    go_mod = root / 'go.mod'
    if not go_mod.exists():
        return info

    try:
        content = go_mod.read_text()
    except OSError:
        logger.warning('Failed to read go.mod — skipping detailed detection.')
        return info

    # Go version (e.g. "go 1.22")
    version_match = re.search(r'^go\s+(\S+)', content, re.MULTILINE)
    if version_match:
        info.language_version = version_match.group(1)

    # Require directives for dependencies
    dep_names: list[str] = []
    for match in re.finditer(r'^\s+(\S+)\s+v', content, re.MULTILINE):
        dep_names.append(match.group(1))
    info.key_dependencies = dep_names[:5]

    # Framework detection
    for name, framework in [
        ('github.com/gin-gonic/gin', 'Gin'),
        ('github.com/gofiber/fiber', 'Fiber'),
        ('github.com/labstack/echo', 'Echo'),
        ('github.com/gorilla/mux', 'Gorilla Mux'),
        ('github.com/spf13/cobra', 'Cobra CLI'),
    ]:
        if any(name in d for d in dep_names):
            info.framework = framework
            break

    # Test runner — Go uses built-in `go test`
    info.test_runner = 'go test'

    return info


_RUNTIME_MANAGERS: dict[str, list[tuple[str, str]]] = {
    'python': [
        ('uv.lock', 'uv'),
        ('poetry.lock', 'poetry'),
    ],
    'javascript': [
        ('bun.lock', 'bun'),
        ('bun.lockb', 'bun'),
        ('pnpm-lock.yaml', 'pnpm'),
        ('yarn.lock', 'yarn'),
        ('package-lock.json', 'npm'),
    ],
}
# typescript shares javascript managers
_RUNTIME_MANAGERS['typescript'] = _RUNTIME_MANAGERS['javascript']


def _detect_runtime_manager(root: Path, language: str) -> str:
    """Detect runtime/package manager from lockfiles.

    Args:
        root: Project root directory.
        language: Detected primary language (used to scope detection).

    Returns:
        Runtime manager name or empty string.
    """
    for lockfile, manager in _RUNTIME_MANAGERS.get(language, []):
        if (root / lockfile).exists():
            return manager
    return ''


def _detect_ci(root: Path) -> str:
    """Detect CI platform from config files."""
    for path, platform in CI_CONFIGS.items():
        if (root / path).exists():
            return platform
    return ''


def detect_project_stack(root: Path) -> StackInfo:
    """Detect project stack from repository files.

    Scans for manifest files, config files, and CI configs to determine
    the project's language, framework, tooling, and conventions.

    Args:
        root: Project root directory.

    Returns:
        StackInfo with detected fields populated. Fields that cannot
        be determined are left as empty strings.
    """
    # Determine primary language from manifest files
    language = ''
    for manifest, lang in MANIFEST_MAP.items():
        if (root / manifest).exists() and lang:
            language = lang
            break

    if language == 'python':
        info = _detect_python_stack(root)
    elif language in ('javascript', 'typescript'):
        info = _detect_js_stack(root)
    elif language == 'rust':
        info = _detect_rust_stack(root)
    elif language == 'go':
        info = _detect_go_stack(root)
    else:
        info = StackInfo(language=language)

    # CI detection
    info.ci_platform = _detect_ci(root)

    # Runtime manager detection
    info.runtime_manager = _detect_runtime_manager(root, info.language)

    return info


def format_stack_summary(info: StackInfo) -> str:
    """Format StackInfo as a human-readable markdown summary.

    Args:
        info: Detected stack information.

    Returns:
        Markdown-formatted string suitable for display or PROJECT.md insertion.
    """
    lines: list[str] = []
    if info.language:
        version = f' {info.language_version}' if info.language_version else ''
        lines.append(f'- **Language:** {info.language}{version}')
    if info.framework:
        lines.append(f'- **Framework:** {info.framework}')
    if info.build_tool:
        lines.append(f'- **Build tool:** {info.build_tool}')
    if info.key_dependencies:
        lines.append(f'- **Key dependencies:** {", ".join(info.key_dependencies)}')
    if info.runtime_manager:
        lines.append(f'- **Runtime manager:** {info.runtime_manager}')
    if info.test_runner:
        lines.append(f'- **Test runner:** {info.test_runner}')
    if info.linter:
        lines.append(f'- **Linter:** {info.linter}')
    if info.formatter and info.formatter != info.linter:
        lines.append(f'- **Formatter:** {info.formatter}')
    if info.type_checker:
        lines.append(f'- **Type checker:** {info.type_checker}')
    if info.ci_platform:
        lines.append(f'- **CI:** {info.ci_platform}')
    return '\n'.join(lines) if lines else '(no stack detected)'


# Patterns that match empty placeholder lines in PROJECT.md Stack section.
# Each maps a StackInfo field name to the bold-label prefix used in the template.
_FIELD_LABELS: dict[str, str] = {
    'language': 'Language',
    'framework': 'Framework',
    'key_dependencies': 'Key dependencies',
    'runtime_manager': 'Runtime manager',
}


def _build_value(info: StackInfo, field_name: str) -> str:
    """Build the replacement value string for a given field."""
    if field_name == 'language':
        version = f' {info.language_version}' if info.language_version else ''
        return f'{info.language}{version}'
    if field_name == 'key_dependencies':
        return ', '.join(info.key_dependencies)
    return getattr(info, field_name, '')


def merge_into_project_md(root: Path, info: StackInfo) -> bool:
    """Merge detected stack info into existing PROJECT.md non-destructively.

    Only fills in fields that are currently empty or contain template
    placeholders. Does not overwrite user-edited content.

    Args:
        root: Project root containing .planning/.
        info: Detected stack information to merge.

    Returns:
        True if any changes were made, False if PROJECT.md was already populated.

    Raises:
        FileNotFoundError: If .planning/PROJECT.md does not exist.
    """
    project_file = root / '.planning' / 'PROJECT.md'
    if not project_file.exists():
        raise FileNotFoundError('.planning/PROJECT.md not found. Run `gsd-lean init` first.')

    content = project_file.read_text()
    changed = False

    for field_name, label in _FIELD_LABELS.items():
        value = _build_value(info, field_name)
        if not value:
            continue

        # Match a line like "- **Language:**" with nothing (or only whitespace) after the colon
        pattern = rf'(- \*\*{re.escape(label)}:\*\*)\s*$'
        replacement = rf'\1 {value}'
        new_content, count = re.subn(pattern, replacement, content, count=1, flags=re.MULTILINE)
        if count > 0:
            content = new_content
            changed = True

    if changed:
        project_file.write_text(content)

    return changed


def detect_mcp_plugins(root: Path) -> McpPluginInfo:
    """Detect MCP servers from .mcp.json and plugins from .claude/settings.json.

    Args:
        root: Project root directory.

    Returns:
        McpPluginInfo with detected server names and plugin identifiers.
    """
    info = McpPluginInfo()

    # MCP servers from .mcp.json
    mcp_file = root / '.mcp.json'
    if mcp_file.exists():
        try:
            data: dict[str, Any] = json.loads(mcp_file.read_text())
            servers = data.get('mcpServers', {})
            if isinstance(servers, dict):
                info.mcp_servers = sorted(cast(dict[str, Any], servers).keys())
        except (json.JSONDecodeError, OSError):
            logger.warning('Failed to parse .mcp.json — skipping MCP detection.')

    # Plugins from .claude/settings.json
    settings_file = root / '.claude' / 'settings.json'
    if settings_file.exists():
        try:
            settings_data: dict[str, Any] = json.loads(settings_file.read_text())
            plugins = settings_data.get('enabledPlugins', {})
            if isinstance(plugins, dict):
                typed_plugins = cast(dict[str, Any], plugins)
                info.plugins = sorted(str(k) for k, v in typed_plugins.items() if v)
        except (json.JSONDecodeError, OSError):
            logger.warning('Failed to parse .claude/settings.json — skipping plugin detection.')

    return info


def format_mcp_plugin_summary(info: McpPluginInfo) -> str:
    """Format MCP/plugin info as markdown for CONTEXT.md.

    Args:
        info: Detected MCP servers and plugins.

    Returns:
        Markdown-formatted string, or empty string if nothing detected.
    """
    lines: list[str] = []
    if info.mcp_servers:
        lines.append(f'- **MCP servers:** {", ".join(info.mcp_servers)}')
    if info.plugins:
        lines.append(f'- **Plugins:** {", ".join(info.plugins)}')
    return '\n'.join(lines) if lines else ''


def merge_into_context_md(root: Path, mcp_info: McpPluginInfo) -> bool:
    """Merge detected MCP/plugin info into CONTEXT.md Tooling section.

    Only fills in the Tooling section if it still contains the template
    placeholder. Does not overwrite user-edited content.

    Args:
        root: Project root containing .planning/.
        mcp_info: Detected MCP servers and plugins.

    Returns:
        True if any changes were made.

    Raises:
        FileNotFoundError: If .planning/CONTEXT.md does not exist.
    """
    context_file = root / '.planning' / 'CONTEXT.md'
    if not context_file.exists():
        raise FileNotFoundError('.planning/CONTEXT.md not found. Run `gsd-lean init` first.')

    summary = format_mcp_plugin_summary(mcp_info)
    if not summary:
        return False

    content = context_file.read_text()

    # Only replace the placeholder line under ## Tooling
    new_content, count = re.subn(
        r'(## Tooling\n\n)- \(none yet\)',
        rf'\1{summary}',
        content,
        count=1,
    )
    if count == 0:
        return False

    context_file.write_text(new_content)
    return True
