"""Tests for the project stack auto-detection module."""

import pytest

from gsd_lean.state.detector import (
    McpPluginInfo,
    StackInfo,
    detect_mcp_plugins,
    detect_project_stack,
    format_mcp_plugin_summary,
    format_stack_summary,
    merge_into_context_md,
    merge_into_project_md,
)

SAMPLE_PYPROJECT = """\
[project]
name = "my-app"
requires-python = ">=3.12"
dependencies = [
    "click>=8.3.1",
    "httpx>=0.27",
]

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[dependency-groups]
dev = ["pytest>=8.0", "pytest-cov>=5.0"]
lint = ["ruff>=0.8", "mypy>=1.13"]

[tool.ruff]
line-length = 130
"""

SAMPLE_PYPROJECT_DJANGO = """\
[project]
name = "my-django-app"
requires-python = ">=3.11"
dependencies = [
    "django>=5.0",
    "celery>=5.3",
]

[build-system]
requires = ["setuptools"]
build-backend = "setuptools.build_meta"

[dependency-groups]
dev = ["pytest>=8.0", "pytest-django>=4.0"]
lint = ["flake8>=7.0", "black>=24.0", "pyright>=1.1"]
"""

MALFORMED_TOML = """\
[project
name = "broken"
"""


class TestDetectPythonStack:
    """Tests for Python stack detection."""

    def test_detect_python_pyproject(self, tmp_path):
        """Test full Python stack detection from pyproject.toml."""
        (tmp_path / 'pyproject.toml').write_text(SAMPLE_PYPROJECT)
        info = detect_project_stack(tmp_path)

        assert info.language == 'python'
        assert info.language_version == '>=3.12'
        assert info.build_tool == 'hatch'
        assert info.framework == 'Click CLI'
        assert info.test_runner == 'pytest'
        assert info.linter == 'ruff'
        assert info.formatter == 'ruff'
        assert info.type_checker == 'mypy'
        assert info.key_dependencies == ['click', 'httpx']

    def test_detect_python_django_setuptools(self, tmp_path):
        """Test detection with Django, setuptools, flake8, black, pyright."""
        (tmp_path / 'pyproject.toml').write_text(SAMPLE_PYPROJECT_DJANGO)
        info = detect_project_stack(tmp_path)

        assert info.language == 'python'
        assert info.language_version == '>=3.11'
        assert info.build_tool == 'setuptools'
        assert info.framework == 'Django'
        assert info.test_runner == 'pytest'
        assert info.linter == 'flake8'
        assert info.formatter == 'black'
        assert info.type_checker == 'pyright'

    def test_detect_python_no_dev_deps(self, tmp_path):
        """Test detection when pyproject.toml has no dependency-groups."""
        (tmp_path / 'pyproject.toml').write_text('[project]\nname = "minimal"\ndependencies = []\n')
        info = detect_project_stack(tmp_path)

        assert info.language == 'python'
        assert info.test_runner == ''
        assert info.linter == ''
        assert info.type_checker == ''

    def test_detect_malformed_toml(self, tmp_path):
        """Test that malformed pyproject.toml is handled gracefully."""
        (tmp_path / 'pyproject.toml').write_text(MALFORMED_TOML)
        info = detect_project_stack(tmp_path)

        assert info.language == 'python'
        # All detail fields should be empty — parsing failed gracefully
        assert info.build_tool == ''
        assert info.framework == ''
        assert info.test_runner == ''


SAMPLE_PACKAGE_JSON = """\
{
    "name": "my-app",
    "version": "1.0.0",
    "engines": {"node": ">=18"},
    "dependencies": {
        "react": "^18.0",
        "react-dom": "^18.0",
        "axios": "^1.6"
    },
    "devDependencies": {
        "vitest": "^1.0",
        "eslint": "^8.0",
        "prettier": "^3.0",
        "typescript": "^5.0",
        "vite": "^5.0"
    }
}
"""

SAMPLE_PACKAGE_JSON_EXPRESS = """\
{
    "name": "my-api",
    "version": "1.0.0",
    "dependencies": {
        "express": "^4.18",
        "cors": "^2.8"
    },
    "devDependencies": {
        "jest": "^29.0",
        "@biomejs/biome": "^1.0",
        "webpack": "^5.0"
    }
}
"""

MALFORMED_JSON = """\
{ "name": "broken", invalid json
"""


class TestDetectJsStack:
    """Tests for JavaScript/TypeScript stack detection."""

    def test_detect_javascript_package_json(self, tmp_path):
        """Test full JS stack detection from package.json."""
        (tmp_path / 'package.json').write_text(SAMPLE_PACKAGE_JSON)
        info = detect_project_stack(tmp_path)

        assert info.language == 'javascript'
        assert info.language_version == '>=18'
        assert info.framework == 'React'
        assert info.test_runner == 'vitest'
        assert info.linter == 'eslint'
        assert info.formatter == 'prettier'
        assert info.type_checker == 'typescript'
        assert info.build_tool == 'vite'
        assert info.key_dependencies == ['react', 'react-dom', 'axios']

    def test_detect_typescript_with_tsconfig(self, tmp_path):
        """Test that language is typescript when tsconfig.json exists alongside package.json."""
        (tmp_path / 'package.json').write_text(SAMPLE_PACKAGE_JSON)
        (tmp_path / 'tsconfig.json').write_text('{}')
        info = detect_project_stack(tmp_path)

        assert info.language == 'typescript'
        assert info.framework == 'React'
        assert info.type_checker == 'typescript'

    def test_detect_express_with_biome(self, tmp_path):
        """Test detection with Express, jest, biome, webpack."""
        (tmp_path / 'package.json').write_text(SAMPLE_PACKAGE_JSON_EXPRESS)
        info = detect_project_stack(tmp_path)

        assert info.language == 'javascript'
        assert info.framework == 'Express'
        assert info.test_runner == 'jest'
        assert info.linter == 'biome'
        assert info.formatter == 'biome'
        assert info.build_tool == 'webpack'

    def test_detect_js_no_deps(self, tmp_path):
        """Test detection when package.json has no dependencies."""
        (tmp_path / 'package.json').write_text('{"name": "minimal"}')
        info = detect_project_stack(tmp_path)

        assert info.language == 'javascript'
        assert info.framework == ''
        assert info.test_runner == ''
        assert info.linter == ''
        assert info.key_dependencies == []

    def test_detect_malformed_json(self, tmp_path):
        """Test that malformed package.json is handled gracefully."""
        (tmp_path / 'package.json').write_text(MALFORMED_JSON)
        info = detect_project_stack(tmp_path)

        assert info.language == 'javascript'
        assert info.framework == ''
        assert info.build_tool == ''


SAMPLE_CARGO_TOML = """\
[package]
name = "my-app"
version = "0.1.0"
edition = "2021"

[dependencies]
axum = "0.7"
tokio = { version = "1", features = ["full"] }
serde = { version = "1", features = ["derive"] }
serde_json = "1"
tracing = "0.1"
"""

SAMPLE_CARGO_TOML_CLI = """\
[package]
name = "my-cli"
version = "1.0.0"
edition = "2024"

[dependencies]
clap = { version = "4", features = ["derive"] }
anyhow = "1"
"""

MALFORMED_CARGO_TOML = """\
[package
name = "broken"
"""

SAMPLE_GO_MOD = """\
module github.com/example/myapp

go 1.22

require (
\tgithub.com/gin-gonic/gin v1.9.1
\tgithub.com/jackc/pgx/v5 v5.5.0
\tgithub.com/rs/zerolog v1.31.0
)
"""

SAMPLE_GO_MOD_CLI = """\
module github.com/example/mycli

go 1.21

require (
\tgithub.com/spf13/cobra v1.8.0
\tgithub.com/spf13/viper v1.18.0
)
"""


class TestDetectRustStack:
    """Tests for Rust stack detection."""

    def test_detect_rust_cargo(self, tmp_path):
        """Test Rust stack detection from Cargo.toml."""
        (tmp_path / 'Cargo.toml').write_text(SAMPLE_CARGO_TOML)
        info = detect_project_stack(tmp_path)

        assert info.language == 'rust'
        assert info.language_version == '2021'
        assert info.build_tool == 'cargo'
        assert info.framework == 'Axum'
        assert info.test_runner == 'cargo test'
        assert info.linter == 'clippy'
        assert info.formatter == 'rustfmt'
        assert info.key_dependencies == ['axum', 'tokio', 'serde', 'serde_json', 'tracing']

    def test_detect_rust_cli(self, tmp_path):
        """Test Rust CLI detection with clap."""
        (tmp_path / 'Cargo.toml').write_text(SAMPLE_CARGO_TOML_CLI)
        info = detect_project_stack(tmp_path)

        assert info.language == 'rust'
        assert info.language_version == '2024'
        assert info.framework == 'Clap CLI'
        assert info.key_dependencies == ['clap', 'anyhow']

    def test_detect_rust_malformed_toml(self, tmp_path):
        """Test that malformed Cargo.toml is handled gracefully."""
        (tmp_path / 'Cargo.toml').write_text(MALFORMED_CARGO_TOML)
        info = detect_project_stack(tmp_path)

        assert info.language == 'rust'
        assert info.build_tool == 'cargo'
        assert info.framework == ''
        assert info.key_dependencies == []


class TestDetectGoStack:
    """Tests for Go stack detection."""

    def test_detect_go_mod(self, tmp_path):
        """Test Go stack detection from go.mod."""
        (tmp_path / 'go.mod').write_text(SAMPLE_GO_MOD)
        info = detect_project_stack(tmp_path)

        assert info.language == 'go'
        assert info.language_version == '1.22'
        assert info.build_tool == 'go build'
        assert info.framework == 'Gin'
        assert info.test_runner == 'go test'
        assert 'github.com/gin-gonic/gin' in info.key_dependencies
        assert 'github.com/jackc/pgx/v5' in info.key_dependencies

    def test_detect_go_cli(self, tmp_path):
        """Test Go CLI detection with cobra."""
        (tmp_path / 'go.mod').write_text(SAMPLE_GO_MOD_CLI)
        info = detect_project_stack(tmp_path)

        assert info.language == 'go'
        assert info.language_version == '1.21'
        assert info.framework == 'Cobra CLI'

    def test_detect_go_no_mod(self, tmp_path):
        """Test Go detection when go.mod is missing but another Go indicator exists."""
        # go.mod is the manifest, so without it we get empty StackInfo
        info = detect_project_stack(tmp_path)

        assert info.language == ''


class TestDetectNoManifest:
    """Tests for detection when no manifest files are found."""

    def test_detect_no_manifest(self, tmp_path):
        """Test that empty directory returns empty StackInfo."""
        info = detect_project_stack(tmp_path)

        assert info.language == ''
        assert info.framework == ''
        assert info.build_tool == ''
        assert info.key_dependencies == []


class TestDetectCI:
    """Tests for CI platform detection."""

    def test_detect_ci_github_actions(self, tmp_path):
        """Test detection of GitHub Actions from .github/workflows directory."""
        (tmp_path / '.github' / 'workflows').mkdir(parents=True)
        (tmp_path / 'pyproject.toml').write_text('[project]\nname = "x"\ndependencies = []\n')
        info = detect_project_stack(tmp_path)

        assert info.ci_platform == 'GitHub Actions'

    def test_detect_ci_gitlab(self, tmp_path):
        """Test detection of GitLab CI from .gitlab-ci.yml."""
        (tmp_path / '.gitlab-ci.yml').write_text('stages:\n  - build\n')
        info = detect_project_stack(tmp_path)

        assert info.ci_platform == 'GitLab CI'

    def test_detect_no_ci(self, tmp_path):
        """Test that missing CI config returns empty string."""
        info = detect_project_stack(tmp_path)

        assert info.ci_platform == ''


class TestFormatStackSummary:
    """Tests for format_stack_summary function."""

    def test_format_full_stack(self):
        """Test formatting a fully-populated StackInfo."""
        info = StackInfo(
            language='python',
            language_version='>=3.12',
            framework='Click CLI',
            build_tool='hatch',
            test_runner='pytest',
            linter='ruff',
            formatter='ruff',
            type_checker='mypy',
            ci_platform='GitHub Actions',
            key_dependencies=['click', 'httpx'],
        )
        result = format_stack_summary(info)

        assert '- **Language:** python >=3.12' in result
        assert '- **Framework:** Click CLI' in result
        assert '- **Build tool:** hatch' in result
        assert '- **Key dependencies:** click, httpx' in result
        assert '- **Test runner:** pytest' in result
        assert '- **Linter:** ruff' in result
        assert '- **Type checker:** mypy' in result
        assert '- **CI:** GitHub Actions' in result
        # Formatter == linter → formatter line omitted
        assert '**Formatter:**' not in result

    def test_format_empty_stack(self):
        """Test that empty StackInfo returns '(no stack detected)'."""
        info = StackInfo()
        result = format_stack_summary(info)

        assert result == '(no stack detected)'

    def test_format_partial_stack(self):
        """Test formatting with only some fields populated."""
        info = StackInfo(language='go', ci_platform='GitHub Actions')
        result = format_stack_summary(info)

        assert '- **Language:** go' in result
        assert '- **CI:** GitHub Actions' in result
        assert '**Framework:**' not in result

    def test_format_different_linter_formatter(self):
        """Test that formatter line appears when different from linter."""
        info = StackInfo(language='python', linter='flake8', formatter='black')
        result = format_stack_summary(info)

        assert '- **Linter:** flake8' in result
        assert '- **Formatter:** black' in result


# Template matching the one generated by init_planning()
PROJECT_TEMPLATE = """\
# Project Overview

> Fill in project details during the discuss phase.

## Stack

- **Language:**
- **Framework:**
- **Key dependencies:**
- **Runtime manager:**

## Constraints

- (none yet)

## Notes

- (none yet)
"""

PROJECT_USER_EDITED = """\
# Project Overview

> Fill in project details during the discuss phase.

## Stack

- **Language:** rust 2021
- **Framework:** axum
- **Key dependencies:** tokio, serde
- **Runtime manager:** cargo

## Constraints

- (none yet)

## Notes

- (none yet)
"""


def _setup_project_md(tmp_path, content):
    """Helper to create .planning/PROJECT.md with given content."""
    planning_dir = tmp_path / '.planning'
    planning_dir.mkdir()
    project_file = planning_dir / 'PROJECT.md'
    project_file.write_text(content)
    return project_file


class TestMergeIntoProjectMd:
    """Tests for merge_into_project_md function."""

    def test_fills_placeholders(self, tmp_path):
        """Test that empty Stack fields are filled with detected values."""
        _setup_project_md(tmp_path, PROJECT_TEMPLATE)
        info = StackInfo(
            language='python',
            language_version='>=3.12',
            framework='Click CLI',
            key_dependencies=['click', 'httpx'],
        )

        result = merge_into_project_md(tmp_path, info)

        assert result is True
        content = (tmp_path / '.planning' / 'PROJECT.md').read_text()
        assert '- **Language:** python >=3.12' in content
        assert '- **Framework:** Click CLI' in content
        assert '- **Key dependencies:** click, httpx' in content

    def test_preserves_user_content(self, tmp_path):
        """Test that user-edited fields are not overwritten."""
        _setup_project_md(tmp_path, PROJECT_USER_EDITED)
        info = StackInfo(
            language='python',
            language_version='>=3.12',
            framework='FastAPI',
            key_dependencies=['fastapi', 'uvicorn'],
        )

        result = merge_into_project_md(tmp_path, info)

        assert result is False
        content = (tmp_path / '.planning' / 'PROJECT.md').read_text()
        # Original user content preserved
        assert '- **Language:** rust 2021' in content
        assert '- **Framework:** axum' in content
        assert '- **Key dependencies:** tokio, serde' in content

    def test_returns_false_when_populated(self, tmp_path):
        """Test returns False when all fields are already populated."""
        _setup_project_md(tmp_path, PROJECT_USER_EDITED)
        info = StackInfo(language='go')

        result = merge_into_project_md(tmp_path, info)

        assert result is False

    def test_partial_fill(self, tmp_path):
        """Test that only empty fields are filled when some are populated."""
        partial = PROJECT_TEMPLATE.replace('- **Language:**', '- **Language:** go 1.22')
        _setup_project_md(tmp_path, partial)
        info = StackInfo(
            language='python',
            language_version='>=3.12',
            framework='FastAPI',
            key_dependencies=['fastapi'],
        )

        result = merge_into_project_md(tmp_path, info)

        assert result is True
        content = (tmp_path / '.planning' / 'PROJECT.md').read_text()
        # Language preserved (user-set)
        assert '- **Language:** go 1.22' in content
        # Framework and deps filled
        assert '- **Framework:** FastAPI' in content
        assert '- **Key dependencies:** fastapi' in content

    def test_raises_when_no_project_md(self, tmp_path):
        """Test that FileNotFoundError is raised when PROJECT.md is missing."""
        with pytest.raises(FileNotFoundError, match='PROJECT.md not found'):
            merge_into_project_md(tmp_path, StackInfo(language='python'))

    def test_empty_stack_info_no_changes(self, tmp_path):
        """Test that empty StackInfo makes no changes."""
        _setup_project_md(tmp_path, PROJECT_TEMPLATE)
        info = StackInfo()

        result = merge_into_project_md(tmp_path, info)

        assert result is False


class TestDetectRuntimeManager:
    """Tests for runtime manager detection."""

    def test_detect_python_runtime_uv(self, tmp_path):
        """Test that uv.lock present → runtime_manager='uv' end-to-end."""
        (tmp_path / 'pyproject.toml').write_text('[project]\nname = "x"\ndependencies = []\n')
        (tmp_path / 'uv.lock').write_text('version = 1\n')
        info = detect_project_stack(tmp_path)

        assert info.runtime_manager == 'uv'

    def test_detect_python_runtime_poetry(self, tmp_path):
        """Test that poetry.lock present → runtime_manager='poetry'."""
        (tmp_path / 'pyproject.toml').write_text('[project]\nname = "x"\ndependencies = []\n')
        (tmp_path / 'poetry.lock').write_text('')
        info = detect_project_stack(tmp_path)

        assert info.runtime_manager == 'poetry'

    def test_detect_js_runtime_bun(self, tmp_path):
        """Test that bun.lock present → runtime_manager='bun'."""
        (tmp_path / 'package.json').write_text('{"name": "x"}')
        (tmp_path / 'bun.lock').write_text('')
        info = detect_project_stack(tmp_path)

        assert info.runtime_manager == 'bun'

    def test_detect_js_runtime_pnpm(self, tmp_path):
        """Test that pnpm-lock.yaml present → runtime_manager='pnpm'."""
        (tmp_path / 'package.json').write_text('{"name": "x"}')
        (tmp_path / 'pnpm-lock.yaml').write_text('')
        info = detect_project_stack(tmp_path)

        assert info.runtime_manager == 'pnpm'

    def test_detect_js_runtime_yarn(self, tmp_path):
        """Test that yarn.lock present → runtime_manager='yarn'."""
        (tmp_path / 'package.json').write_text('{"name": "x"}')
        (tmp_path / 'yarn.lock').write_text('')
        info = detect_project_stack(tmp_path)

        assert info.runtime_manager == 'yarn'

    def test_detect_js_runtime_npm(self, tmp_path):
        """Test that package-lock.json present → runtime_manager='npm'."""
        (tmp_path / 'package.json').write_text('{"name": "x"}')
        (tmp_path / 'package-lock.json').write_text('{}')
        info = detect_project_stack(tmp_path)

        assert info.runtime_manager == 'npm'

    def test_detect_runtime_priority(self, tmp_path):
        """Test that uv.lock + poetry.lock → uv wins (first match in priority order)."""
        (tmp_path / 'pyproject.toml').write_text('[project]\nname = "x"\ndependencies = []\n')
        (tmp_path / 'uv.lock').write_text('version = 1\n')
        (tmp_path / 'poetry.lock').write_text('')
        info = detect_project_stack(tmp_path)

        assert info.runtime_manager == 'uv'

    def test_detect_no_runtime(self, tmp_path):
        """Test that no lockfile → runtime_manager=''."""
        (tmp_path / 'pyproject.toml').write_text('[project]\nname = "x"\ndependencies = []\n')
        info = detect_project_stack(tmp_path)

        assert info.runtime_manager == ''

    def test_runtime_in_format_summary(self):
        """Test that format_stack_summary() includes runtime manager line."""
        info = StackInfo(language='python', runtime_manager='uv')
        result = format_stack_summary(info)

        assert '- **Runtime manager:** uv' in result

    def test_runtime_merge_into_project_md(self, tmp_path):
        """Test that merge_into_project_md() fills runtime manager placeholder."""
        planning_dir = tmp_path / '.planning'
        planning_dir.mkdir()
        project_md = planning_dir / 'PROJECT.md'
        project_md.write_text(
            '# Project Overview\n\n## Stack\n\n'
            '- **Language:** python\n'
            '- **Framework:**\n'
            '- **Key dependencies:**\n'
            '- **Runtime manager:**\n'
        )
        info = StackInfo(language='python', runtime_manager='uv')

        result = merge_into_project_md(tmp_path, info)

        assert result is True
        content = project_md.read_text()
        assert '- **Runtime manager:** uv' in content


class TestDetectMcpPlugins:
    """Tests for MCP server and plugin detection."""

    def test_detect_mcp_plugins_full(self, tmp_path):
        """Test both .mcp.json and .claude/settings.json parsed correctly."""
        (tmp_path / '.mcp.json').write_text('{"mcpServers": {"context7": {}, "filesystem": {}}}')
        (tmp_path / '.claude').mkdir()
        (tmp_path / '.claude' / 'settings.json').write_text('{"enabledPlugins": {"pyright-lsp": true, "disabled-one": false}}')

        info = detect_mcp_plugins(tmp_path)

        assert info.mcp_servers == ['context7', 'filesystem']
        assert info.plugins == ['pyright-lsp']

    def test_detect_mcp_no_files(self, tmp_path):
        """Test no config files → empty McpPluginInfo."""
        info = detect_mcp_plugins(tmp_path)

        assert info.mcp_servers == []
        assert info.plugins == []

    def test_detect_mcp_malformed_json(self, tmp_path):
        """Test malformed .mcp.json → graceful fallback."""
        (tmp_path / '.mcp.json').write_text('{ broken json')

        info = detect_mcp_plugins(tmp_path)

        assert info.mcp_servers == []
        assert info.plugins == []

    def test_detect_mcp_empty_servers(self, tmp_path):
        """Test empty mcpServers dict → empty list."""
        (tmp_path / '.mcp.json').write_text('{"mcpServers": {}}')

        info = detect_mcp_plugins(tmp_path)

        assert info.mcp_servers == []

    def test_detect_mcp_disabled_plugins(self, tmp_path):
        """Test plugins with false value → filtered out."""
        (tmp_path / '.claude').mkdir()
        (tmp_path / '.claude' / 'settings.json').write_text('{"enabledPlugins": {"a-plugin": false, "b-plugin": false}}')

        info = detect_mcp_plugins(tmp_path)

        assert info.plugins == []


class TestFormatMcpPluginSummary:
    """Tests for format_mcp_plugin_summary function."""

    def test_format_both(self):
        """Test formatting with both servers and plugins."""
        info = McpPluginInfo(mcp_servers=['context7', 'filesystem'], plugins=['pyright-lsp'])
        result = format_mcp_plugin_summary(info)

        assert '- **MCP servers:** context7, filesystem' in result
        assert '- **Plugins:** pyright-lsp' in result

    def test_format_servers_only(self):
        """Test formatting with only servers."""
        info = McpPluginInfo(mcp_servers=['context7'])
        result = format_mcp_plugin_summary(info)

        assert '- **MCP servers:** context7' in result
        assert '**Plugins:**' not in result

    def test_format_empty(self):
        """Test formatting with nothing detected."""
        info = McpPluginInfo()
        result = format_mcp_plugin_summary(info)

        assert result == ''


class TestMergeIntoContextMd:
    """Tests for merge_into_context_md function."""

    def _setup_context_md(self, tmp_path, content):
        """Helper to create .planning/CONTEXT.md."""
        planning_dir = tmp_path / '.planning'
        planning_dir.mkdir(exist_ok=True)
        context_file = planning_dir / 'CONTEXT.md'
        context_file.write_text(content)
        return context_file

    def test_merge_into_context_md(self, tmp_path):
        """Test non-destructive merge into ## Tooling section."""
        template = '# Project Context\n\n## Architecture\n\n- (none yet)\n\n## Tooling\n\n- (none yet)\n'
        self._setup_context_md(tmp_path, template)
        mcp_info = McpPluginInfo(mcp_servers=['context7'], plugins=['pyright-lsp'])

        result = merge_into_context_md(tmp_path, mcp_info)

        assert result is True
        content = (tmp_path / '.planning' / 'CONTEXT.md').read_text()
        assert '- **MCP servers:** context7' in content
        assert '- **Plugins:** pyright-lsp' in content
        assert '- (none yet)' not in content.split('## Tooling')[1]

    def test_merge_context_preserves_user_content(self, tmp_path):
        """Test user-edited Tooling section not overwritten."""
        user_content = '# Project Context\n\n## Architecture\n\n- (none yet)\n\n## Tooling\n\n- User added this manually\n'
        self._setup_context_md(tmp_path, user_content)
        mcp_info = McpPluginInfo(mcp_servers=['context7'])

        result = merge_into_context_md(tmp_path, mcp_info)

        assert result is False
        content = (tmp_path / '.planning' / 'CONTEXT.md').read_text()
        assert '- User added this manually' in content

    def test_merge_context_empty_info(self, tmp_path):
        """Test that empty McpPluginInfo makes no changes."""
        template = '# Project Context\n\n## Tooling\n\n- (none yet)\n'
        self._setup_context_md(tmp_path, template)
        mcp_info = McpPluginInfo()

        result = merge_into_context_md(tmp_path, mcp_info)

        assert result is False

    def test_merge_context_raises_when_missing(self, tmp_path):
        """Test FileNotFoundError when CONTEXT.md is missing."""
        mcp_info = McpPluginInfo(mcp_servers=['context7'])

        with pytest.raises(FileNotFoundError, match='CONTEXT.md not found'):
            merge_into_context_md(tmp_path, mcp_info)
