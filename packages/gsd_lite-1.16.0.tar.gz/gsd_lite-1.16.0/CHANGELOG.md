# CHANGELOG

<!-- version list -->

## v1.16.0 (2026-02-15)


## v1.15.0 (2026-02-15)

### Bug Fixes

- Cli dump to have utf8 support ([#15](https://github.com/luutuankiet/gsd-lite/pull/15),
  [`3baaa7e`](https://github.com/luutuankiet/gsd-lite/commit/3baaa7ea991656a8d564db1f2b4d6e490bca6f3b))

- Parser logic captures tag with dashes in brackets
  ([#15](https://github.com/luutuankiet/gsd-lite/pull/15),
  [`3baaa7e`](https://github.com/luutuankiet/gsd-lite/commit/3baaa7ea991656a8d564db1f2b4d6e490bca6f3b))

### Documentation

- Init plan ([#15](https://github.com/luutuankiet/gsd-lite/pull/15),
  [`3baaa7e`](https://github.com/luutuankiet/gsd-lite/commit/3baaa7ea991656a8d564db1f2b4d6e490bca6f3b))

### Features

- Add first P2 rubric ([#15](https://github.com/luutuankiet/gsd-lite/pull/15),
  [`3baaa7e`](https://github.com/luutuankiet/gsd-lite/commit/3baaa7ea991656a8d564db1f2b4d6e490bca6f3b))

- Add gsd reader script ([#15](https://github.com/luutuankiet/gsd-lite/pull/15),
  [`3baaa7e`](https://github.com/luutuankiet/gsd-lite/commit/3baaa7ea991656a8d564db1f2b4d6e490bca6f3b))

- Add opencode parser for eval ([#15](https://github.com/luutuankiet/gsd-lite/pull/15),
  [`3baaa7e`](https://github.com/luutuankiet/gsd-lite/commit/3baaa7ea991656a8d564db1f2b4d6e490bca6f3b))

- Add vite build script ([#15](https://github.com/luutuankiet/gsd-lite/pull/15),
  [`3baaa7e`](https://github.com/luutuankiet/gsd-lite/commit/3baaa7ea991656a8d564db1f2b4d6e490bca6f3b))

- Publish to simple docker container host ([#15](https://github.com/luutuankiet/gsd-lite/pull/15),
  [`3baaa7e`](https://github.com/luutuankiet/gsd-lite/commit/3baaa7ea991656a8d564db1f2b4d6e490bca6f3b))

- Sticky headers on reader ([#15](https://github.com/luutuankiet/gsd-lite/pull/15),
  [`3baaa7e`](https://github.com/luutuankiet/gsd-lite/commit/3baaa7ea991656a8d564db1f2b4d6e490bca6f3b))

- Vite based hot serve work logs ([#15](https://github.com/luutuankiet/gsd-lite/pull/15),
  [`3baaa7e`](https://github.com/luutuankiet/gsd-lite/commit/3baaa7ea991656a8d564db1f2b4d6e490bca6f3b))


## v1.14.0 (2026-02-07)

### Chores

- Migrate html descriptions from artifact to root agent
  ([#13](https://github.com/luutuankiet/gsd-lite/pull/13),
  [`2f36391`](https://github.com/luutuankiet/gsd-lite/commit/2f3639126e4ead17e92f25763d2e0bc1763598ea))

### Documentation

- Commit worklog execution of adding housekeeping agent
  ([#13](https://github.com/luutuankiet/gsd-lite/pull/13),
  [`2f36391`](https://github.com/luutuankiet/gsd-lite/commit/2f3639126e4ead17e92f25763d2e0bc1763598ea))

### Features

- Add housekeeping agent, decomission housekeeping workflow
  ([#13](https://github.com/luutuankiet/gsd-lite/pull/13),
  [`2f36391`](https://github.com/luutuankiet/gsd-lite/commit/2f3639126e4ead17e92f25763d2e0bc1763598ea))

- Housekeeping agent embeds instruction to use fs-mcp worklog analyzer
  ([#13](https://github.com/luutuankiet/gsd-lite/pull/13),
  [`2f36391`](https://github.com/luutuankiet/gsd-lite/commit/2f3639126e4ead17e92f25763d2e0bc1763598ea))

- **TASK-PROTOCOL-DOCS-001**: Move all html comments from artiacts to main agent gsd-lite.
  decomission the PROTOCOL.md file ([#13](https://github.com/luutuankiet/gsd-lite/pull/13),
  [`2f36391`](https://github.com/luutuankiet/gsd-lite/commit/2f3639126e4ead17e92f25763d2e0bc1763598ea))


## v1.13.2 (2026-02-06)

### Bug Fixes

- Migrate gotchas from WORK to PROTOCOL
  ([`79b7fae`](https://github.com/luutuankiet/gsd-lite/commit/79b7fae3a54a2a59ce83ce6851fc5179e7619ddf))


## v1.13.1 (2026-02-06)

### Bug Fixes

- AGENTS.md update
  ([`5d08296`](https://github.com/luutuankiet/gsd-lite/commit/5d082967019a3a16d12befd719d6d6dbda69b605))


## v1.13.0 (2026-02-06)

### Documentation

- Commit gsd-lite
  ([`daeefba`](https://github.com/luutuankiet/gsd-lite/commit/daeefba7a21e3ccc5d014fa2be974f05659bbbd2))

- README makover
  ([`247ded8`](https://github.com/luutuankiet/gsd-lite/commit/247ded8a835bbb27b210e3de4fadc93d400128fa))

### Features

- Add stateless first protocol
  ([`d53aa04`](https://github.com/luutuankiet/gsd-lite/commit/d53aa0490448a7b815e6f065d813a1bf4cf3db3d))


## v1.12.0 (2026-02-04)

### Chores

- Docs bump
  ([`823e1cc`](https://github.com/luutuankiet/gsd-lite/commit/823e1cc3a7bdc53b2d2d9a75014664f8d0dcd48a))

### Features

- Installation script to integrate opencode
  ([`4d18c11`](https://github.com/luutuankiet/gsd-lite/commit/4d18c1140d485c9be400cded4b0a2268dfab7e9d))


## v1.11.0 (2026-02-03)

### Features

- Revamp moodboard / whiteboard and decomission sitcky notes
  ([`fdae6e3`](https://github.com/luutuankiet/gsd-lite/commit/fdae6e3642425e9e699b7c340d19c1d75e821026))


## v1.10.0 (2026-02-01)

### Bug Fixes

- Add echo-back onboarding protocol to progress workflow
  ([#10](https://github.com/luutuankiet/gsd-lite/pull/10),
  [`46969d2`](https://github.com/luutuankiet/gsd-lite/commit/46969d2237952ea6081528ff57707985433585f4))

### Features

- Add echo-back onboarding protocol to progress workflow
  ([#10](https://github.com/luutuankiet/gsd-lite/pull/10),
  [`46969d2`](https://github.com/luutuankiet/gsd-lite/commit/46969d2237952ea6081528ff57707985433585f4))


## v1.9.1 (2026-02-01)

### Bug Fixes

- Add descriptions to workflow and helper AGENTs.md
  ([`6702209`](https://github.com/luutuankiet/gsd-lite/commit/6702209daf3a3c28c8296c14cf7d9b7daf0388b7))


## v1.9.0 (2026-01-31)

### Features

- Add workflows codebase map and new project ([#9](https://github.com/luutuankiet/gsd-lite/pull/9),
  [`9623be0`](https://github.com/luutuankiet/gsd-lite/commit/9623be06da1602a5527e0cf3de83ef740003a0ce))


## v1.8.0 (2026-01-29)

### Bug Fixes

- Update atomic log format with summary in header line
  ([#8](https://github.com/luutuankiet/gsd-lite/pull/8),
  [`3a9c590`](https://github.com/luutuankiet/gsd-lite/commit/3a9c590dbabc7ef45bcb1c0218f83a3f4c38d53c))

- Use EXAMPLE-LOOP-NNN IDs for example entries in INBOX.md
  ([#8](https://github.com/luutuankiet/gsd-lite/pull/8),
  [`3a9c590`](https://github.com/luutuankiet/gsd-lite/commit/3a9c590dbabc7ef45bcb1c0218f83a3f4c38d53c))

### Features

- Redesign INBOX.md with context-preserving loop entries
  ([#8](https://github.com/luutuankiet/gsd-lite/pull/8),
  [`3a9c590`](https://github.com/luutuankiet/gsd-lite/commit/3a9c590dbabc7ef45bcb1c0218f83a3f4c38d53c))

- Update atomic log format with summary in header line
  ([#8](https://github.com/luutuankiet/gsd-lite/pull/8),
  [`3a9c590`](https://github.com/luutuankiet/gsd-lite/commit/3a9c590dbabc7ef45bcb1c0218f83a3f4c38d53c))


## v1.7.0 (2026-01-27)

### Features

- Revamp artifacts and protocol for grep optimized
  ([#7](https://github.com/luutuankiet/gsd-lite/pull/7),
  [`84a7453`](https://github.com/luutuankiet/gsd-lite/commit/84a7453ca3b9b4d33c8f4004b74061047861b8b9))


## v1.6.0 (2026-01-25)

### Bug Fixes

- **01.4**: Orchestrator corrections - mark phase 1.4 complete, update config
  ([`6c9d757`](https://github.com/luutuankiet/gsd-lite/commit/6c9d75755997889ca5306d47862d118c661937ba))

- **01.4-02**: Clarify WORK.md examples as templates
  ([`cab2d0c`](https://github.com/luutuankiet/gsd-lite/commit/cab2d0cf772f3c96b77ea3af2f48522121faf008))

- **01.4-02**: Update PROTOCOL.md with complete workflow routing
  ([`ff4567a`](https://github.com/luutuankiet/gsd-lite/commit/ff4567afd0a0b32c6b91fe9600877c9aa460331f))

### Chores

- **01.5-02**: Add gitignore for simulation artifacts
  ([`6ac9cbe`](https://github.com/luutuankiet/gsd-lite/commit/6ac9cbead76934c598acd7e77eb2fbb29b34d2c9))

### Documentation

- **01.4**: Capture phase context
  ([`4fd5c27`](https://github.com/luutuankiet/gsd-lite/commit/4fd5c27564d78bbdf37a7b3bf74dbb1eef5a596d))

- **01.4**: Complete enrich checkpoint workflow phase
  ([`7327627`](https://github.com/luutuankiet/gsd-lite/commit/7327627f27a8f912fe60a9e4001f5e4365ec7178))

- **01.4**: Create phase plan
  ([`39986d6`](https://github.com/luutuankiet/gsd-lite/commit/39986d6c8240bcf8e443b25a06f888d84c6ea81a))

- **01.4**: Research phase domain
  ([`a5d55ec`](https://github.com/luutuankiet/gsd-lite/commit/a5d55ecc00f258ae329bef12917b85e36e72021a))

- **01.4-01**: Complete WORK.md enrichment and checkpoint workflow update plan
  ([`f486bad`](https://github.com/luutuankiet/gsd-lite/commit/f486bada2ea9446af2fbe1e84e75240c85d753c3))

- **01.4-02**: Complete revisit workflow and template coherence plan
  ([`9634f71`](https://github.com/luutuankiet/gsd-lite/commit/9634f71f91c7be6bed05e0804d1e68f71c637fa6))

- **01.4-02**: Enhance README with artifact synergy overview
  ([`5d54935`](https://github.com/luutuankiet/gsd-lite/commit/5d549353b7308094d7805173df326d6db21704da))

- **01.5**: Capture phase context
  ([`95974a7`](https://github.com/luutuankiet/gsd-lite/commit/95974a7736d65554c6ebf1e914e2fa80d7f08f59))

- **01.5**: Research phase domain
  ([`b50cd80`](https://github.com/luutuankiet/gsd-lite/commit/b50cd806359a6c7e358ba374d0c8340cc2e3dbac))

- **01.5-01**: Add simulation environment readme
  ([`ec5b204`](https://github.com/luutuankiet/gsd-lite/commit/ec5b204c34bbb48c7e19890bb5c1df65339dfc14))

- **01.5-01**: Complete simulation sandbox setup plan
  ([`8ab4e5c`](https://github.com/luutuankiet/gsd-lite/commit/8ab4e5c1e43f53e08765a12f8781df2b0eb541b3))

- **01.5-02**: Complete evaluation protocol plan
  ([`86c3448`](https://github.com/luutuankiet/gsd-lite/commit/86c34481e54c7308a6502d883c556ec4c9ad4727))

- **01.5-02**: Create driver manual for gsd-lite evaluation
  ([`bfd6ca4`](https://github.com/luutuankiet/gsd-lite/commit/bfd6ca4fddca263c89c3b60de266cc27ea9c55dc))

- **01.5-02**: Create evaluation log template
  ([`dac4ff1`](https://github.com/luutuankiet/gsd-lite/commit/dac4ff15ac3a77f14832fc931c66b3f8e53cc959))

- **01.6**: Capture phase context
  ([`36d0cf3`](https://github.com/luutuankiet/gsd-lite/commit/36d0cf364387c97c4fd6cc28c21714539c4d12f2))

- **01.6**: Create phase plan
  ([`b0c14b1`](https://github.com/luutuankiet/gsd-lite/commit/b0c14b191f3c8620c768e6ffa098cfb579c7568d))

- **01.6**: Research phase domain
  ([`6d51b49`](https://github.com/luutuankiet/gsd-lite/commit/6d51b490c1aa421245138708ac9780d81f736d66))

- **phase-1.5**: Complete evaluation framework phase
  ([`d84b30b`](https://github.com/luutuankiet/gsd-lite/commit/d84b30bbf7bdc65a16f909447ae889fa5092cbe3))

### Features

- **01.4-01**: Enrich WORK.md with Current Understanding and type-tagged session log
  ([`b945246`](https://github.com/luutuankiet/gsd-lite/commit/b945246f5a9044563162ff1b6325a076a4cfb3f1))

- **01.4-01**: Update checkpoint workflow with Current Understanding maintenance
  ([`21f1563`](https://github.com/luutuankiet/gsd-lite/commit/21f1563ad04eca0434b6ddfba145528a62210bfe))

- **01.4-02**: Create revisit workflow for post-whiteboard rethinking
  ([`5a346c4`](https://github.com/luutuankiet/gsd-lite/commit/5a346c48b054f8ccb6f8eb1f34b0d215be32d986))

- **01.5-01**: Create input csv data
  ([`77264d1`](https://github.com/luutuankiet/gsd-lite/commit/77264d15a9c18c9a37d844f1e805d990caf1e2d1))

- **01.5-01**: Implement etl modules
  ([`74987b1`](https://github.com/luutuankiet/gsd-lite/commit/74987b12c3c66e62c4542b0f79a4be9d24949827))

- **01.5-01**: Implement pipeline orchestrator
  ([`abff27e`](https://github.com/luutuankiet/gsd-lite/commit/abff27e3c1a98f6448f6e96a8da48e66f3062289))

### Testing

- **01.5-01**: Add transformation unit tests
  ([`19c4203`](https://github.com/luutuankiet/gsd-lite/commit/19c4203df8cc64ace0b8cff52f27d3b3a3908572))


## v1.5.0 (2026-01-25)

### Documentation

- Update readme
  ([`a09f077`](https://github.com/luutuankiet/gsd-lite/commit/a09f077243a46374121df4485ddf9b0a68441ad8))

### Features

- Add `revisit` workflow and better checkpoint instructions
  ([#5](https://github.com/luutuankiet/gsd-lite/pull/5),
  [`c4f4b7c`](https://github.com/luutuankiet/gsd-lite/commit/c4f4b7cada5a09ca7e05ebc8ddda6373894d8411))


## v1.4.0 (2026-01-25)

### Features

- Context Lifecycle, Coaching Model & Workflow Decomposition
  ([#4](https://github.com/luutuankiet/gsd-lite/pull/4),
  [`bc13fe6`](https://github.com/luutuankiet/gsd-lite/commit/bc13fe6549571d9757779c56058f7731341a740a))


## v1.3.4 (2026-01-24)

### Bug Fixes

- Folder naming bump to gsd-lite
  ([`948ef68`](https://github.com/luutuankiet/gsd-lite/commit/948ef68093f4c3bcc6f8a16e7c6d2841a2f467f7))


## v1.3.3 (2026-01-24)

### Bug Fixes

- Add relpath to not confuse agent
  ([`d538479`](https://github.com/luutuankiet/gsd-lite/commit/d53847954c7e4fd78f9ef6cbf9c3ca8edbf1cebc))


## v1.3.2 (2026-01-24)

### Bug Fixes

- Also scaffold templates dir into state if not exist
  ([`1b267d3`](https://github.com/luutuankiet/gsd-lite/commit/1b267d3bbbbf7d1f226d5ea4f45f0b8458bf0fba))


## v1.3.1 (2026-01-24)

### Bug Fixes

- Broken markdown in protocol
  ([`898c460`](https://github.com/luutuankiet/gsd-lite/commit/898c460be8fc0c91ddc04d43e1ac13de2b5c4d04))


## v1.3.0 (2026-01-23)

### Bug Fixes

- Use native markdown instead
  ([`64bde07`](https://github.com/luutuankiet/gsd-lite/commit/64bde0749e79e9065a3ed6c986fd7bd995ce1aa0))

### Features

- More detailed logging for WORK.md protocol
  ([`2598249`](https://github.com/luutuankiet/gsd-lite/commit/259824963d744b5a7e259a1aa2cd5a6058d8436e))


## v1.2.0 (2026-01-23)

### Features

- Prompt agent to extract vision and collaboratively think with user
  ([`95a942b`](https://github.com/luutuankiet/gsd-lite/commit/95a942b1d72f85ea35aa55e2efebf76814e365d9))


## v1.1.1 (2026-01-23)

### Bug Fixes

- No more ascii art line break
  ([`fe94da4`](https://github.com/luutuankiet/gsd-lite/commit/fe94da4eb3aa7b16c9c2e5c1c59dd0986c8cb1b9))


## v1.1.0 (2026-01-23)

### Features

- Stabilize versioning pipeline
  ([`03b60ae`](https://github.com/luutuankiet/gsd-lite/commit/03b60aea43e157af8f14249c09d3db84eab911af))


## v1.0.0 (2026-01-23)

- Initial Release
