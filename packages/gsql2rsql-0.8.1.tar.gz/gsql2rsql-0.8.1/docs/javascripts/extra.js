// Custom JavaScript for gsql2rsql documentation

// Add custom behaviors here as needed

// Example: Copy button feedback
document.addEventListener('DOMContentLoaded', function() {
    // Add custom event listeners or behaviors
    console.log('gsql2rsql documentation loaded');
});

// Example: Custom analytics tracking (if needed)
// Track clicks on query examples, etc.
