"""Tests for the openCypher transpiler."""
