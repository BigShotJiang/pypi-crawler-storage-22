Source code for `gsrap`. 
