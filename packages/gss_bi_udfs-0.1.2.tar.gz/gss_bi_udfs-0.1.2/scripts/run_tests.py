#!/usr/bin/env python3
import argparse
import datetime as dt
import html
import os
import sys
import unittest


class _CollectingTextTestResult(unittest.TextTestResult):
    def __init__(self, stream, descriptions, verbosity):
        super().__init__(stream, descriptions, verbosity)
        self.successes = []

    def addSuccess(self, test):
        super().addSuccess(test)
        self.successes.append(test)


def _run_tests(start_dir: str, pattern: str, verbosity: int) -> unittest.TestResult:
    suite = unittest.defaultTestLoader.discover(start_dir=start_dir, pattern=pattern)
    runner = unittest.TextTestRunner(verbosity=verbosity, resultclass=_CollectingTextTestResult)
    return runner.run(suite)


def _timestamped_path(path: str) -> str:
    ts = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    base, ext = os.path.splitext(path)
    if ext:
        return f"{base}_{ts}{ext}"
    return f"{path}_{ts}"


def _render_html(result: unittest.TestResult, output_path: str) -> None:
    rows = []
    for test in getattr(result, "successes", []):
        rows.append(("PASS", str(test), ""))

    for test, tb in result.failures + result.errors:
        rows.append(
            (
                "FAIL" if (test, tb) in result.failures else "ERROR",
                str(test),
                tb,
            )
        )

    for test, reason in result.skipped:
        rows.append(("SKIP", str(test), reason))

    status = "PASSED" if result.wasSuccessful() else "FAILED"
    now = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    html_body = [
        "<!doctype html>",
        "<html lang='en'>",
        "<head>",
        "  <meta charset='utf-8'/>",
        "  <title>Unit Test Report</title>",
        "  <style>",
        "    body { font-family: Arial, sans-serif; margin: 24px; }",
        "    .ok { color: #0f5132; }",
        "    .bad { color: #842029; }",
        "    table { border-collapse: collapse; width: 100%; margin-top: 16px; }",
        "    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; vertical-align: top; }",
        "    th { background: #f5f5f5; }",
        "    pre { white-space: pre-wrap; margin: 0; }",
        "  </style>",
        "</head>",
        "<body>",
        f"  <h1>Unit Test Report</h1>",
        f"  <p><strong>Generated:</strong> {html.escape(now)}</p>",
        f"  <p><strong>Status:</strong> <span class='{'ok' if result.wasSuccessful() else 'bad'}'>{status}</span></p>",
        f"  <p><strong>Ran:</strong> {result.testsRun} tests</p>",
        f"  <p><strong>Pass:</strong> {len(getattr(result, 'successes', []))} | <strong>Failures:</strong> {len(result.failures)} | <strong>Errors:</strong> {len(result.errors)} | <strong>Skipped:</strong> {len(result.skipped)}</p>",
        "  <table>",
        "    <thead><tr><th>Type</th><th>Test</th><th>Details</th></tr></thead>",
        "    <tbody>",
    ]

    if rows:
        for row_type, test_name, details in rows:
            html_body.append(
                "      <tr>"
                f"<td>{html.escape(row_type)}</td>"
                f"<td>{html.escape(test_name)}</td>"
                f"<td><pre>{html.escape(details)}</pre></td>"
                "</tr>"
            )
    else:
        html_body.append("      <tr><td colspan='3'>No failures, errors or skipped tests.</td></tr>")

    html_body += [
        "    </tbody>",
        "  </table>",
        "</body>",
        "</html>",
    ]

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(html_body))


def main() -> int:
    parser = argparse.ArgumentParser(description="Run unittests and optionally write HTML report.")
    parser.add_argument("--start-dir", default="tests")
    parser.add_argument("--pattern", default="test*.py")
    parser.add_argument("--verbosity", type=int, default=2)
    parser.add_argument("--html", default="")
    parser.add_argument("--timestamped", action="store_true")
    args = parser.parse_args()

    result = _run_tests(args.start_dir, args.pattern, args.verbosity)

    if args.html:
        output_path = _timestamped_path(args.html) if args.timestamped else args.html
        _render_html(result, output_path)
        print(f"HTML report written to: {output_path}")

    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    sys.exit(main())
