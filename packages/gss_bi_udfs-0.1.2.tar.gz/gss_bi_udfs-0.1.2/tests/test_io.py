import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from gss_bi_udfs import io


class TestIO(unittest.TestCase):
    def test_normalize_path(self):
        self.assertEqual(io._normalize_path("dbfs:/tmp/a.parquet"), "/tmp/a.parquet")
        self.assertEqual(io._normalize_path("/tmp/a.parquet"), "/tmp/a.parquet")

    def test_ls_path_local(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            file_path = Path(tmpdir) / "file.txt"
            file_path.write_text("x", encoding="utf-8")
            (Path(tmpdir) / "folder").mkdir()

            files = io._ls_path(tmpdir)
            names = sorted([f.name for f in files])
            self.assertEqual(names, ["file.txt", "folder"])

        self.assertEqual(io._ls_path("/path/that/does/not/exist"), [])

    @patch("gss_bi_udfs.io._ls_path")
    def test_load_latest_parquet_returns_latest_match(self, mock_ls_path):
        mock_ls_path.return_value = [
            SimpleNamespace(name="clientes_20240101.parquet", path="/tmp/1"),
            SimpleNamespace(name="clientes_20240102.parquet", path="/tmp/2"),
            SimpleNamespace(name="otra_tabla_20240103.parquet", path="/tmp/3"),
        ]
        spark = MagicMock()
        expected_df = object()
        spark.read.parquet.return_value = expected_df

        out = io.load_latest_parquet(spark, "db", "sch", "clientes", env="dev")

        self.assertIs(out, expected_df)
        spark.read.parquet.assert_called_once_with("/tmp/2")

    @patch("gss_bi_udfs.io._ls_path")
    def test_load_latest_parquet_returns_none_without_matches(self, mock_ls_path):
        mock_ls_path.return_value = [SimpleNamespace(name="x.parquet", path="/tmp/x")]
        spark = MagicMock()

        out = io.load_latest_parquet(spark, "db", "sch", "clientes", env="dev")

        self.assertIsNone(out)
        spark.read.parquet.assert_not_called()

    @patch("gss_bi_udfs.io.load_latest_parquet")
    def test_return_parquets_and_register_temp_views(self, mock_load_latest):
        df = MagicMock()
        mock_load_latest.return_value = df
        spark = MagicMock()
        tables_load = {
            "db1": {
                "sch1": [
                    {"table": "t1", "view": "vw_t1"},
                    {"table": "t2", "view": "vw_t2"},
                ]
            }
        }

        out = io.return_parquets_and_register_temp_views(spark, tables_load, env="dev")

        self.assertEqual(set(out.keys()), {"db1.sch1.t1", "db1.sch1.t2"})
        self.assertEqual(mock_load_latest.call_count, 2)
        self.assertEqual(df.createOrReplaceTempView.call_count, 2)

    @patch("gss_bi_udfs.io.load_latest_parquet")
    def test_parquets_register_temp_views(self, mock_load_latest):
        df = MagicMock()
        mock_load_latest.return_value = df
        spark = MagicMock()
        tables_load = {"db1": {"sch1": [{"table": "t1", "view": "vw_t1"}]}}

        io.parquets_register_temp_views(spark, tables_load, env="dev")

        df.createOrReplaceTempView.assert_called_once_with("vw_t1")

    @patch("gss_bi_udfs.io._ls_path")
    @patch("pandas.read_excel")
    def test_load_latest_excel(self, mock_read_excel, mock_ls_path):
        mock_ls_path.return_value = [
            SimpleNamespace(name="a_old", path="dbfs:/tmp/a_old", isFile=lambda: True),
            SimpleNamespace(name="b_new", path="dbfs:/tmp/b_new", isFile=lambda: True),
        ]
        mock_pdf = object()
        mock_read_excel.return_value = mock_pdf
        spark = MagicMock()
        expected_df = object()
        spark.createDataFrame.return_value = expected_df

        out = io.load_latest_excel(spark, "dom/sub/file", env="dev")

        self.assertIs(out, expected_df)
        mock_read_excel.assert_called_once_with("/tmp/b_new", header=0, engine="xlrd")
        spark.createDataFrame.assert_called_once_with(mock_pdf)

    def test_load_and_materialize_views_unknown_action(self):
        out = io.load_and_materialize_views("accion_inexistente")
        self.assertEqual(out, {})

    @patch("gss_bi_udfs.io.get_table_info")
    def test_save_table_to_delta_writes_delta(self, mock_get_table_info):
        mock_get_table_info.return_value = {
            "path": "/tmp/tbl",
            "full_table_name": "cat.sch.tbl",
        }
        df = MagicMock()
        writer = MagicMock()
        writer.format.return_value = writer
        writer.option.return_value = writer
        writer.mode.return_value = writer
        df.write = writer

        io.save_table_to_delta(df, "cat", "sch", "tbl")

        writer.format.assert_called_once_with("delta")
        writer.mode.assert_called_once_with("overwrite")
        writer.saveAsTable.assert_called_once_with("cat.sch.tbl")


if __name__ == "__main__":
    unittest.main()
