import unittest
from unittest.mock import MagicMock, patch

from gss_bi_udfs import merges


class TestMerges(unittest.TestCase):
    def test_merge_scd2_raises_if_business_key_is_missing(self):
        spark = MagicMock()
        df_dim_src = MagicMock()
        df_dim_src.columns = ["id", "descripcion"]

        with self.assertRaises(ValueError):
            merges.merge_scd2(
                spark=spark,
                df_dim_src=df_dim_src,
                table_name="cat.sch.dim",
                business_keys="codigo_negocio",
                surrogate_key="sk_dim",
            )

    @patch("gss_bi_udfs.merges.save_table_to_delta")
    @patch("gss_bi_udfs.merges.add_hashid")
    @patch("gss_bi_udfs.merges.get_table_info")
    def test_merge_scd2_full_load_path(self, mock_get_table_info, mock_add_hashid, mock_save_table):
        spark = MagicMock()
        spark.catalog.tableExists.return_value = False
        mock_get_table_info.return_value = {
            "catalog": "cat_dev",
            "schema": "sch",
            "table": "dim_cliente",
            "full_table_name": "cat_dev.sch.dim_cliente",
        }

        df_dim_src = MagicMock()
        df_dim_src.columns = ["codigo_negocio", "descripcion"]
        df_dim_src.withColumn.return_value = df_dim_src

        df_hashed = MagicMock()
        writer = MagicMock()
        writer.format.return_value = writer
        writer.mode.return_value = writer
        writer.option.return_value = writer
        df_hashed.write = writer
        mock_add_hashid.return_value = df_hashed

        merges.merge_scd2(
            spark=spark,
            df_dim_src=df_dim_src,
            table_name="cat.sch.dim_cliente",
            business_keys="codigo_negocio",
            surrogate_key="sk_dim_cliente",
        )

        mock_add_hashid.assert_called_once()
        add_hashid_args = mock_add_hashid.call_args.args
        self.assertEqual(add_hashid_args[1], ["codigo_negocio", "valid_from"])
        self.assertEqual(add_hashid_args[2], "sk_dim_cliente")

        self.assertEqual(mock_save_table.call_count, 1)
        writer.saveAsTable.assert_called_once_with("cat.sch.dim_cliente")


if __name__ == "__main__":
    unittest.main()
