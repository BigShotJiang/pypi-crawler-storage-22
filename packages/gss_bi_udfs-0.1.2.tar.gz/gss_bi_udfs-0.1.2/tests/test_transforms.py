import unittest
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from gss_bi_udfs import transforms


class _FakeCol:
    def __init__(self, name):
        self.name = name

    def cast(self, dtype):
        return f"{self.name}:{dtype}"


class TestTransforms(unittest.TestCase):
    def test_add_hashid_raises_when_columns_empty(self):
        with self.assertRaises(ValueError):
            transforms.add_hashid(MagicMock(), [])

    @patch("gss_bi_udfs.transforms.xxhash64")
    @patch("gss_bi_udfs.transforms.concat_ws")
    @patch("gss_bi_udfs.transforms.col")
    def test_add_hashid_builds_hash_and_reorders_columns(self, mock_col, mock_concat_ws, mock_xxhash64):
        mock_col.side_effect = lambda name: _FakeCol(name)
        mock_concat_ws.return_value = "concat_expr"
        mock_xxhash64.return_value = "hash_expr"

        df = MagicMock()
        df.columns = ["id", "name"]
        df_with_hash = MagicMock()
        df.withColumn.return_value = df_with_hash
        df_with_hash.select.return_value = "result_df"

        out = transforms.add_hashid(df, ["id", "name"], "hash_pk")

        self.assertEqual(out, "result_df")
        df.withColumn.assert_called_once_with("hash_pk", "hash_expr")
        df_with_hash.select.assert_called_once_with("hash_pk", "id", "name")

    @patch("gss_bi_udfs.transforms.get_default_value_by_type")
    def test_get_default_record_builds_single_row_with_schema_defaults(self, mock_defaults):
        mock_defaults.side_effect = lambda dtype: f"default_for_{dtype}"
        spark = MagicMock()
        expected = object()
        spark.createDataFrame.return_value = expected

        df = MagicMock()
        df.schema = SimpleNamespace(
            fields=[
                SimpleNamespace(name="id", dataType="int"),
                SimpleNamespace(name="desc", dataType="string"),
            ]
        )

        out = transforms.get_default_record(spark, df)

        self.assertIs(out, expected)
        spark.createDataFrame.assert_called_once_with(
            [{"id": "default_for_int", "desc": "default_for_string"}],
            schema=df.schema,
        )


if __name__ == "__main__":
    unittest.main()
