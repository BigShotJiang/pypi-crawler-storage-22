import os
import unittest
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from pyspark.sql.types import (
    BooleanType,
    DateType,
    DecimalType,
    DoubleType,
    FloatType,
    IntegerType,
    LongType,
    StringType,
    TimestampType,
)

from gss_bi_udfs import utils


class TestUtils(unittest.TestCase):
    def test_get_env_uses_default_and_env_var(self):
        with patch.dict(os.environ, {}, clear=True):
            self.assertEqual(utils.get_env(), "dev")
            self.assertEqual(utils.get_env(default="qa"), "qa")

        with patch.dict(os.environ, {"ENV": "prod"}, clear=True):
            self.assertEqual(utils.get_env(), "prod")

    def test_get_env_catalog(self):
        with patch.dict(os.environ, {"ENV": "pro"}, clear=True):
            self.assertEqual(utils.get_env_catalog("fi_comunes"), "fi_comunes")
        with patch.dict(os.environ, {"ENV": "dev"}, clear=True):
            self.assertEqual(utils.get_env_catalog("fi_comunes"), "fi_comunes_dev")

    def test_get_env_table_path(self):
        with patch("gss_bi_udfs.utils.get_env_catalog", return_value="cat_dev"):
            self.assertEqual(
                utils.get_env_table_path("cat", "silver.dim_cliente"),
                "cat_dev.silver.dim_cliente",
            )

    @patch("gss_bi_udfs.utils.get_env_catalog", return_value="cat_dev")
    def test_get_schema_root_location(self, _mock_catalog):
        spark = MagicMock()
        df = MagicMock()
        df.filter.return_value = df
        df.select.return_value = df
        df.collect.return_value = [["s3://bucket/root"]]
        spark.sql.return_value = df

        out = utils.get_schema_root_location(spark, "cat", "silver")

        self.assertEqual(out, "s3://bucket/root")
        spark.sql.assert_called_once_with("DESCRIBE SCHEMA EXTENDED cat_dev.silver")

    def test_get_table_info_validations(self):
        spark = MagicMock()
        with self.assertRaises(ValueError):
            utils.get_table_info(spark, full_table_name="solo.dos")
        with self.assertRaises(ValueError):
            utils.get_table_info(spark)

    @patch("gss_bi_udfs.utils.get_schema_root_location", return_value="s3://bucket/root/silver")
    @patch("gss_bi_udfs.utils.get_env_catalog", return_value="cat_dev")
    def test_get_table_info_when_table_does_not_exist(self, _mock_env_catalog, _mock_root):
        spark = MagicMock()
        spark.catalog.tableExists.return_value = False

        info = utils.get_table_info(spark, full_table_name="cat.silver.dim_cliente")

        self.assertEqual(info["catalog"], "cat_dev")
        self.assertEqual(info["schema"], "silver")
        self.assertEqual(info["table"], "dim_cliente")
        self.assertEqual(info["full_table_name"], "cat_dev.silver.dim_cliente")
        self.assertEqual(info["path"], "s3://bucket/root/silver/dim_cliente")
        self.assertFalse(info["exists"])

    @patch("gss_bi_udfs.utils.get_schema_root_location", return_value="s3://bucket/root/silver")
    @patch("gss_bi_udfs.utils.get_env_catalog", return_value="cat_dev")
    def test_get_table_info_when_table_exists(self, _mock_env_catalog, _mock_root):
        spark = MagicMock()
        spark.catalog.tableExists.return_value = True
        desc_df = MagicMock()
        desc_df.filter.return_value = desc_df
        desc_df.collect.return_value = [
            SimpleNamespace(col_name="Location", data_type="s3://bucket/real/location"),
            SimpleNamespace(col_name="Provider", data_type="delta"),
            SimpleNamespace(col_name="Type", data_type="MANAGED"),
        ]
        spark.sql.return_value = desc_df

        info = utils.get_table_info(spark, full_table_name="cat.silver.dim_cliente")

        self.assertTrue(info["exists"])
        self.assertEqual(info["path"], "s3://bucket/real/location")
        self.assertEqual(info["provider"], "delta")
        self.assertEqual(info["table_type"], "MANAGED")

    def test_get_default_value_by_type_returns_column(self):
        dtypes = [
            IntegerType(),
            LongType(),
            DecimalType(10, 2),
            DoubleType(),
            FloatType(),
            DateType(),
            TimestampType(),
            BooleanType(),
            StringType(),
        ]
        for dtype in dtypes:
            with self.subTest(dtype=dtype):
                out = utils.get_default_value_by_type(dtype)
                self.assertEqual(out.__class__.__name__, "Column")


if __name__ == "__main__":
    unittest.main()
