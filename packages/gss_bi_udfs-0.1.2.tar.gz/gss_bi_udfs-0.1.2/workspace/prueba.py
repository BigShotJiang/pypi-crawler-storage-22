from pyspark.sql import SparkSession

spark = SparkSession.getActiveSession()
if spark is None:
    spark = SparkSession.builder.appName("MiApp").getOrCreate()

df = spark.range(1000 * 1000)
print(df.count())

spark.stop()
