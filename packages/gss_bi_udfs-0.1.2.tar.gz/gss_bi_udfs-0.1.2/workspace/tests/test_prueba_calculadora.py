import pytest
import sys
sys.path.append("/workspace")

from .prueba_calculadora import sumar, restar

def test_sumar():
    assert sumar(2, 3) == 5

def test_restar():
    assert restar(5, 3) == 2

def test_sumar_negativos():
    assert sumar(-1, -2) == -3