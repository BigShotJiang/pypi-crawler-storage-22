"""Remove problematic Unicode characters from GTFS files."""

import csv
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

CHARS_TO_REMOVE: set[str] = {
    '\u00A0',  # Non-breaking space
    '\u200B',  # Zero-width space
    '\u200C',  # Zero-width non-joiner
    '\u200D',  # Zero-width joiner
    '\uFEFF',  # Zero-width no-break space (BOM)
}


def clean_value(value: str) -> str:
    """Remove problematic characters from a string."""
    if not isinstance(value, str):
        return value
    for char in CHARS_TO_REMOVE:
        value = value.replace(char, '')
    return value.strip()


def clean_file(filepath: Path) -> None:
    """Clean a single CSV file."""
    if not filepath.exists():
        logger.warning("Skipping %s (not found)", filepath.name)
        return
    
    rows = []
    with open(filepath, encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        header = reader.fieldnames
        
        for row in reader:
            cleaned_row = {k: clean_value(v) for k, v in row.items()}
            rows.append(cleaned_row)
    
    with open(filepath, 'w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=header)
        writer.writeheader()
        writer.writerows(rows)
    
    logger.info("Cleaned %s", filepath.name)


def clean_feed(feed_dir: Path | str) -> None:
    """Clean all GTFS files in feed directory.
    
    Args:
        feed_dir: Path to feed directory containing .txt files
    """
    feed_dir = Path(feed_dir)
    
    if not feed_dir.exists():
        raise FileNotFoundError(f"Feed directory not found: {feed_dir}")
    
    for txt_file in sorted(feed_dir.glob("*.txt")):
        clean_file(txt_file)
    
    logger.info("Feed cleaning completed")
