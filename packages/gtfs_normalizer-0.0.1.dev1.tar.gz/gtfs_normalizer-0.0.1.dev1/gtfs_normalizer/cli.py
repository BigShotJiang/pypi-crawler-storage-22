"""Command-line interface for gtfs-tools."""

import argparse
import logging
import sys
from pathlib import Path

from .clean_feed import clean_feed as clean_feed_func
from .fix_routes import fix_routes as fix_routes_func
from .fix_blocks import fix_overlapping_blocks as fix_blocks_func
from .round_shapes import round_shapes as round_shapes_func

logging.basicConfig(
    level=logging.INFO,
    format="%(levelname)s: %(message)s"
)
logger = logging.getLogger(__name__)


def clean(args: list[str] | None = None) -> None:
    """Clean GTFS feed command."""
    parser = argparse.ArgumentParser(description="Clean GTFS feed by removing problematic Unicode characters")
    parser.add_argument("feed_dir", nargs="?", default="feed", help="Path to GTFS feed directory (default: feed)")
    
    parsed = parser.parse_args(args)
    feed_dir = Path(parsed.feed_dir)
    
    try:
        clean_feed_func(feed_dir)
        logger.info("✓ Feed cleaned successfully")
    except Exception as e:
        logger.error(f"✗ Error: {e}")
        sys.exit(1)


def fix_routes(args: list[str] | None = None) -> None:
    """Fix route names command."""
    parser = argparse.ArgumentParser(description="Fix route names by converting ALL CAPS to Title Case")
    parser.add_argument("feed_dir", nargs="?", default="feed", help="Path to GTFS feed directory (default: feed)")
    
    parsed = parser.parse_args(args)
    feed_dir = Path(parsed.feed_dir)
    
    try:
        fix_routes_func(feed_dir)
        logger.info("✓ Routes fixed successfully")
    except Exception as e:
        logger.error(f"✗ Error: {e}")
        sys.exit(1)


def fix_blocks(args: list[str] | None = None) -> None:
    """Fix overlapping blocks command."""
    parser = argparse.ArgumentParser(description="Fix overlapping block assignments in trips")
    parser.add_argument("feed_dir", nargs="?", default="feed", help="Path to GTFS feed directory (default: feed)")
    
    parsed = parser.parse_args(args)
    feed_dir = Path(parsed.feed_dir)
    
    try:
        fix_blocks_func(feed_dir)
        logger.info("✓ Blocks fixed successfully")
    except Exception as e:
        logger.error(f"✗ Error: {e}")
        sys.exit(1)


def round_shapes(args: list[str] | None = None) -> None:
    """Round shapes and distances command."""
    parser = argparse.ArgumentParser(description="Round geographic coordinates and distances in GTFS feed")
    parser.add_argument("feed_dir", nargs="?", default="feed", help="Path to GTFS feed directory (default: feed)")
    
    parsed = parser.parse_args(args)
    feed_dir = Path(parsed.feed_dir)
    
    try:
        round_shapes_func(feed_dir)
        logger.info("✓ Shapes rounded successfully")
    except Exception as e:
        logger.error(f"✗ Error: {e}")
        sys.exit(1)
