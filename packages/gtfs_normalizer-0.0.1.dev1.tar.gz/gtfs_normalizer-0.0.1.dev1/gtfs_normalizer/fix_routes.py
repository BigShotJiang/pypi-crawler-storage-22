"""Fix route names by using route_desc as Title Case reference."""

import csv
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def find_fragment_in_text(fragment: str, text: str) -> Optional[str]:
    """Find fragment in text (case-insensitive) and return with original casing.
    
    Args:
        fragment: Text to find
        text: Text to search in
        
    Returns:
        Fragment with original casing from text, or None if not found
    """
    fragment_lower = fragment.lower()
    text_lower = text.lower()
    
    pos = text_lower.find(fragment_lower)
    if pos != -1:
        return text[pos:pos + len(fragment)]
    
    return None


def extract_matching_prefix(all_caps: str, title_case: str) -> str:
    """Split all_caps by ' - ', find each part in title_case, reconstruct properly.
    
    Args:
        all_caps: Route name in ALL CAPS
        title_case: Route description to use as Title Case reference
        
    Returns:
        Fixed route name with proper casing
    """
    if not title_case:
        return ' '.join(word.capitalize() for word in all_caps.split())
    
    parts = all_caps.split(' - ')
    fixed_parts = []
    
    for part in parts:
        matched = find_fragment_in_text(part, title_case)
        if matched:
            fixed_parts.append(matched)
        else:
            fixed_parts.append(' '.join(word.capitalize() for word in part.split()))
    
    return ' - '.join(fixed_parts)


def fix_routes(feed_dir: Path | str) -> None:
    """Fix route_long_name case using route_desc, remove duplicates.
    
    Args:
        feed_dir: Path to GTFS feed directory
    """
    feed_dir = Path(feed_dir)
    filepath = feed_dir / "routes.txt"
    
    if not filepath.exists():
        raise FileNotFoundError(f"routes.txt not found in {feed_dir}")
    
    rows = []
    fixed_from_desc = 0
    removed_desc = 0
    
    with open(filepath, encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        header = reader.fieldnames
        
        for row in reader:
            long_name = row.get('route_long_name', '').strip()
            desc = row.get('route_desc', '').strip()
            
            # Fix ALL CAPS using route_desc reference
            if long_name and long_name.isupper() and desc:
                new_long_name = extract_matching_prefix(long_name, desc)
                if new_long_name != long_name:
                    row['route_long_name'] = new_long_name
                    fixed_from_desc += 1
            
            # Remove duplicate route_desc
            long_name = row.get('route_long_name', '').strip()
            if desc and long_name and desc.lower() == long_name.lower():
                row['route_desc'] = ''
                removed_desc += 1
            
            rows.append(row)
    
    with open(filepath, 'w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=header)
        writer.writeheader()
        writer.writerows(rows)
    
    logger.info(f"Fixed {fixed_from_desc} route names using route_desc as reference")
    logger.info(f"Removed {removed_desc} duplicate route descriptions")
