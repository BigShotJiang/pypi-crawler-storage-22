"""Round geographic and distance values in GTFS feed."""

import csv
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def round_file(filepath: Path, columns_precision: dict[str, int]) -> None:
    """Round specified columns in a CSV file to given decimal places.
    
    Args:
        filepath: Path to CSV file
        columns_precision: Dict of {column_name: decimal_places}
    """
    if not filepath.exists():
        logger.warning(f"Skipping {filepath.name} (not found)")
        return
    
    rows: list[dict[str, str]] = []
    with open(filepath, encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        header = reader.fieldnames
        
        for row in reader:
            for col, decimals in columns_precision.items():
                val = row.get(col, '')
                if val and val.strip():
                    try:
                        num = float(val)
                        row[col] = f"{num:.{decimals}f}"
                    except ValueError:
                        pass
            rows.append(row)
    
    with open(filepath, 'w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=header)
        writer.writeheader()
        writer.writerows(rows)
    
    logger.info(f"Rounded values in {filepath.name}")


def round_shapes(feed_dir: Path | str) -> None:
    """Round geographic and distance values in GTFS feed.
    
    Args:
        feed_dir: Path to GTFS feed directory
    """
    feed_dir = Path(feed_dir)
    
    # Round shapes.txt: lat/lon to 6 decimals (~1.1m accuracy), distance to 2 decimals
    round_file(feed_dir / "shapes.txt", {
        'shape_pt_lat': 6,
        'shape_pt_lon': 6,
        'shape_dist_traveled': 2,
    })
    
    # Round stop_times.txt: distance to 2 decimals
    round_file(feed_dir / "stop_times.txt", {
        'shape_dist_traveled': 2,
    })
