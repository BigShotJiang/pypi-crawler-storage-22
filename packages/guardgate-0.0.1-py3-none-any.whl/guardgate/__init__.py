"""GuardGate — QAOA solution validation gate. Part of the QubitBoost platform."""
__version__ = "0.0.1"
