# guardianhub_sdk/workflows/specialist_workflow.py

from typing import Dict, Any
from temporalio import workflow
from .constants import get_activity_options
from guardianhub.config.settings import settings

MISSION_COMPLETION = "transmit_mission_completion"

INTELLIGENCE_DEBRIEF = "summarize_intelligence_debrief"

AFTER_ACTION_REPORT = "commit_mission_after_action_report"

OBJECTIVE_ATTAINMENT = "verify_objective_attainment"

DIRECT_INTERVENTION = "execute_direct_intervention"

CONDUCT_RECONNAISSANCE = "conduct_reconnaissance"


@workflow.defn(name="SpecialistMissionWorkflow")
class SpecialistMissionWorkflow:
    @workflow.run
    async def run(self, plan: Dict[str, Any]) -> Dict[str, Any]:
        mapping = settings.workflow_settings.activity_mapping

        # 1. RECONNAISSANCE
        intelligence = await workflow.execute_activity(
            mapping[CONDUCT_RECONNAISSANCE], args=[plan], **get_activity_options(CONDUCT_RECONNAISSANCE)
        )

        # 2. ITERATIVE INTERVENTION
        results = []
        for step in plan.get("steps", []):
            # The Action
            outcome = await workflow.execute_activity(
                mapping[DIRECT_INTERVENTION], args=[step, intelligence], **get_activity_options(DIRECT_INTERVENTION)
            )

            # The Local Reflection/Validation
            is_valid = await workflow.execute_activity(
                mapping[OBJECTIVE_ATTAINMENT], args=[outcome], **get_activity_options(OBJECTIVE_ATTAINMENT)
            )

            results.append({"step": step, "outcome": outcome, "verified": is_valid})

        # 3. AFTER-ACTION REPORT (Learning)
        await workflow.execute_activity(
            mapping[AFTER_ACTION_REPORT], args=[results], **get_activity_options(AFTER_ACTION_REPORT)
        )

        # 4. DEBRIEF & COMPLETION
        debrief = await workflow.execute_activity(
            mapping[INTELLIGENCE_DEBRIEF], args=[results], **get_activity_options(INTELLIGENCE_DEBRIEF)
        )

        await workflow.execute_activity(
            mapping[MISSION_COMPLETION], args=[debrief], **get_activity_options(MISSION_COMPLETION)
        )

        return {"status": "SUCCESS", "mission_id": plan.get("mission_id")}