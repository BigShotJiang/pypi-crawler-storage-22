from typing import Any
from gudb.core.guardian import Guardian
from gudb.core.interceptor import GudbConnectionWrapper
from gudb.exceptions import DisasterBlockedError
from gudb.providers.base import LocalProvider

__version__ = "0.2.1"

class Gudb:
    """The main entry point for gudb."""
    def __init__(self, provider=None):
        self._guardian = Guardian(provider=provider)

    def monitor(self, conn: Any) -> Any:
        """
        Wraps a database connection to provide real-time guarding.
        
        Args:
            conn: A PEP 249 compliant connection object (e.g., psycopg2).
            
        Returns:
            A wrapped connection object.
        """
        return GudbConnectionWrapper(conn, self._guardian)

# Singleton for easy access
gudb = Gudb()

def monitor(conn: Any, provider=None) -> Any:
    """Convenience function for gudb.monitor(conn)."""
    if provider:
        return Gudb(provider=provider).monitor(conn)
    return gudb.monitor(conn)

def configure(**kwargs):
    """Configure gudb settings programmatically."""
    from gudb.config import settings
    for key, value in kwargs.items():
        if hasattr(settings, key):
            setattr(settings, key, value)
        else:
            raise ValueError(f"Unknown configuration key: {key}")

__all__ = ["monitor", "Guardian", "Gudb", "DisasterBlockedError", "configure", "LocalProvider"]
