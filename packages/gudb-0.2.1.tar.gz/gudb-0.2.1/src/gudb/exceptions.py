from typing import Optional
import sys

class GudbError(Exception):
    """Base exception for all gudb related errors."""
    pass

class ConfigurationError(GudbError):
    """Raised when the SDK is misconfigured."""
    pass

class InterceptionError(GudbError):
    """Raised when there is an issue intercepting a database query."""
    pass

class DisasterBlockedError(GudbError):
    """
    Raised when a query is blocked because it was identified as a 
    production-halting disaster.
    """
    def __init__(self, message: str, issue: str, impact: str, fix: Optional[str] = None):
        self.issue = issue
        self.impact = impact
        self.fix = fix
        
        # Plain text for production logging
        parts = [f"[gudb] ACCESS DENIED"]
        parts.append(f"ISSUE: {issue}")
        parts.append(f"IMPACT: {impact}")
        if fix:
            parts.append(f"FIX: {fix}")
        
        plain_message = " | ".join(parts)
        super().__init__(plain_message)
    
    def format_pretty(self) -> str:
        """Format with ANSI colors for CLI output (only if TTY)."""
        if not sys.stdout.isatty():
            return str(self)
        
        # ANSI Colors for terminal output
        RED = "\033[91m"
        YELLOW = "\033[93m"
        CYAN = "\033[96m"
        BOLD = "\033[1m"
        RESET = "\033[0m"
        
        banner = f"\n{RED}{BOLD}🛑 [gudb] ACCESS DENIED - DATABASE SEATBELT ACTIVATED{RESET}"
        issue_line = f"   {BOLD}ISSUE:{RESET}  {YELLOW}{self.issue}{RESET}"
        impact_line = f"   {BOLD}IMPACT:{RESET} {RED}{self.impact}{RESET}"
        fix_line = f"   {BOLD}FIX:{RESET}    {CYAN}{self.fix}{RESET}" if self.fix else ""
        
        try:
            from gudb.config import settings
            recommendation = f"\n📈 {BOLD}For more recommendations, visit:{RESET} {CYAN}{settings.dashboard_url}{RESET}\n"
        except:
            recommendation = ""
        
        return f"{banner}\n{issue_line}\n{impact_line}\n{fix_line}{recommendation}"

class ProviderError(GudbError):
    """Raised when the AI provider (Remote/Local) fails or times out."""
    pass
