Release notes
=============

This section contains the release notes for all versions of :mod:`guidata`, documenting
new features, improvements, bug fixes, and breaking changes.

.. toctree::
    :maxdepth: 1
    :glob:
    :reversed:

    release_*