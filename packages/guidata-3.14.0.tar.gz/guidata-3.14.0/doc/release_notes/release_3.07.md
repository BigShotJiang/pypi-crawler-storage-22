# Version 3.7 #

## Version 3.7.1 ##

ℹ️ Changes:

* Fixed `ResourceWarning: unclosed file` on some platforms (e.g. CentOS Stream 8).
* Update GitHub Actions to use setup-python@v5 and checkout@v4

## Version 3.7.0 ##

Drop support for Python 3.8.
