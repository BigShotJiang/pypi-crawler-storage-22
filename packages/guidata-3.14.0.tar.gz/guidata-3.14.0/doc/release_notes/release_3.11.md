# Version 3.11 #

## Version 3.11.0 ##

💥 New features:

* New `utils.genreqs` module for generating installation requirements files:
  * Function `generate_requirements_txt` generates a `requirements.txt` file
  * Function `generate_requirements_rst` generates a `requirements.rst` file
  * The module is used by the new command line script `guidata-genreqs`
