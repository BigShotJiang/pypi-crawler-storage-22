# guido-common

Contract package for the [Guido](https://github.com/northseadev/guido) model ecosystem. Config schemas, tokenizer contracts, tensor manifests, and the `.cart` cartridge format.

**No torch dependency** — pure Python with pydantic + tiktoken.

## Installation

```bash
pip install guido-common
```

## What's Inside

| Module | Description |
|--------|-------------|
| `guido_common.config` | `GuidoConfig` dataclass with 5 presets (300M → 7B), HF config round-trip |
| `guido_common.tokenizer` | Special token definitions, frozen tokenizer contract, validation |
| `guido_common.manifest` | Expected weight keys and shapes per config — the tensor naming contract |
| `guido_common.cartridge` | `.cart` format v0.1 spec — portable neural memory states |
| `guido_common.protocol` | Shared request/response types for inference APIs |

## Quick Start

```python
from guido_common.config import GuidoConfig, GUIDO_3B_CONFIG
from guido_common.config.schema import to_hf_config_dict
from guido_common.manifest.tensor_manifest import expected_keys

config = GUIDO_3B_CONFIG
print(f"Hidden: {config.hidden_size}, Layers: {config.num_layers}, Experts: {config.num_experts}")

hf_config = to_hf_config_dict(config)
keys = expected_keys(config)
print(f"Expected {len(keys)} weight keys")
```

See the [monorepo README](../../README.md) for full documentation.
