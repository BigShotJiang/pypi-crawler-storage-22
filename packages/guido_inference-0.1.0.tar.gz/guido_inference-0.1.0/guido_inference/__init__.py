from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("guido-inference")
except PackageNotFoundError:
    __version__ = "0.0.0-dev"

from guido_inference.loader import load_model

__all__ = ["load_model", "__version__"]

# Note: Cartridge load/save/reset exposed via model instance methods:
#   model, tokenizer = load_model("northsea-ai/Guido-3B")
#   model.save_memory("./respondent.cart")   # Save evolved memory state
#   model.load_memory("./respondent.cart")   # Restore memory state
#   model.reset_memory()                     # Clear memory to blank slate
#
# Memory updates happen automatically during inference (Titans architecture).
# Each forward pass computes surprise → gradients → memory state update.
# This is the architecture, not a feature — the model was trained with memory updates active.
