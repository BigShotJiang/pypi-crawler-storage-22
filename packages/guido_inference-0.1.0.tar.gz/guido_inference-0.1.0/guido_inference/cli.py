"""CLI entry point for the `guido` command."""

from __future__ import annotations


def main() -> None:
    """Entry point for `guido run` / `guido info` CLI.

    Raises:
        NotImplementedError: Stub — will be implemented during code extraction (Phase 2).
    """
    raise NotImplementedError("guido CLI is a stub — implementation comes in Phase 2 (code extraction).")
