"""Model loader — loads Guido models from HuggingFace Hub or local SafeTensors."""

from __future__ import annotations

from typing import Any


def load_model(model_id: str, **kwargs: Any) -> Any:
    """Load a Guido model from HuggingFace Hub or a local path.

    Args:
        model_id: HuggingFace model ID (e.g. "northsea-ai/Guido-3B") or local path.
        **kwargs: Additional arguments for model loading.

    Returns:
        Tuple of (model, tokenizer).

    Raises:
        NotImplementedError: Stub — will be implemented during code extraction (Phase 2).
    """
    raise NotImplementedError("load_model() is a stub — implementation comes in Phase 2 (code extraction).")
