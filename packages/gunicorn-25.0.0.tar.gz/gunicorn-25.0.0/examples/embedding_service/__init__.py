# Embedding service package
