"""gutenfetchen - Download e-texts from Project Gutenberg."""

__version__ = "0.1.0"
