"""Support running as: python -m gutenfetchen."""

from gutenfetchen.cli import main

raise SystemExit(main())
