# Hackatime Progress Bar
Hackatime progress bar lives in the corner of your screen constantly reminding you about your goal and how you should work on it!

Works on windows and linux (might work on mac?)

It is fully configurable, set your own goal and title. 

## Config
Default Config:
```json
{
 "hackatime_token": "00000000-0000-0000-0000-000000000000",
 "username": "jan",
 "daily_goal": 5,
 "goal": "no goal :(, Set one in config"
}
```
> Make sure to Set your hackatime token and username to track!

## Installation

Installation is easy just use pip!

```commandline
pip install hackatimeprogressbar
```

and run with
```commandline
hackatimeprogressbar
```


## Images
![img.png](img.png)
![img_1.png](img_1.png)