from hackatimeprogressbar.main import main

__all__ = ['main']
