import json
import os

CONFIG_PATH = os.path.expanduser("~/.hackatimeProgressBar/config.json")

default_config = """
{
 "hackatime_token": "00000000-0000-0000-0000-000000000000",
 "username": "jan",
 "daily_goal": 5,
 "goal": "no goal :(, Set one in config"
}
"""

class Config:
    def __init__(self):
        if not os.path.exists(CONFIG_PATH):
            os.makedirs(os.path.dirname(CONFIG_PATH))
            with open(CONFIG_PATH, "w") as f:
                f.write(default_config)

        pass

    def get(self, key, default=None):
        if os.path.exists(CONFIG_PATH):
            with open(CONFIG_PATH, "r") as f:
                data = json.load(f)
                return data.get(key, default)
        return default

    def set(self, key, value):
        if os.path.exists(CONFIG_PATH):
            with open(CONFIG_PATH, "r") as f:
                prev = json.load(f)
                prev[key] = value
                with open(CONFIG_PATH, "w") as f1:
                    json.dump(prev, f1)
