import os
import sys

import PyQt6
from PyQt6.QtGui import QIntValidator
from PyQt6.QtWidgets import QApplication, QMainWindow, QVBoxLayout
from PyQt6.QtCore import Qt

import signal

from hackatimeprogressbar.config.config import Config


def run(parent=None):
    window1 = QMainWindow(parent)
    window1.setWindowTitle("HackatimeProgressBar config")

    window1.setMinimumWidth(300)

    window1.setWindowFlags(window1.windowFlags() & ~Qt.WindowType.WindowCloseButtonHint)

    main = PyQt6.QtWidgets.QWidget()
    window1.setCentralWidget(main)

    window1.setAttribute(Qt.WidgetAttribute.WA_QuitOnClose, False)

    layout = QVBoxLayout()

    cfg = Config()


    goal_label = PyQt6.QtWidgets.QLabel("Goal Title:", window1,)
    goal = PyQt6.QtWidgets.QLineEdit(window1)
    goal.setText(cfg.get("goal"))


    hrspd_label = PyQt6.QtWidgets.QLabel("hrs/d Goal:", window1)
    hrs_per_day = PyQt6.QtWidgets.QLineEdit(window1)
    hrs_per_day.setValidator(QIntValidator(0, 999))
    hrs_per_day.setText(str(cfg.get("daily_goal")))

    hackatime_label = PyQt6.QtWidgets.QLabel("Hackatime Token:", window1)
    hackatime_token = PyQt6.QtWidgets.QLineEdit(window1)
    hackatime_token.setText(str(cfg.get("hackatime_token")))


    username_label = PyQt6.QtWidgets.QLabel("Username to Track:", window1)
    username = PyQt6.QtWidgets.QLineEdit(window1)
    username.setText(str(cfg.get("username")))

    submit_button = PyQt6.QtWidgets.QPushButton("Submit", window1)
    cancel_button = PyQt6.QtWidgets.QPushButton("Cancel", window1)


    layout.addWidget(goal_label)
    layout.addWidget(goal)
    layout.addWidget(hrspd_label)
    layout.addWidget(hrs_per_day)
    layout.addWidget(hackatime_label)
    layout.addWidget(hackatime_token)
    layout.addWidget(username_label)
    layout.addWidget(username)
    layout.addWidget(submit_button)
    layout.addWidget(cancel_button)
    main.setLayout(layout)


    def cancel():
        window1.close()

    def submit():
        cfg.set("goal", goal.text())
        cfg.set("hackatime_token", hackatime_token.text())
        cfg.set("username", username.text())
        cfg.set("daily_goal", hrs_per_day.text())

        os.execvp("hackatimeprogressbar", ["hackatimeprogressbar"])


    cancel_button.clicked.connect(cancel)
    submit_button.clicked.connect(submit)

    window1.show()


    return window1


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = run()
    sys.exit(app.exec())

