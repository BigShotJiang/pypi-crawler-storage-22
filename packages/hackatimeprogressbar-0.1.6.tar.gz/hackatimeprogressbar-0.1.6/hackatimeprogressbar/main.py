import sys

import requests

import  signal

from hackatimeprogressbar.gui_setup import gui_setup
from hackatimeprogressbar.config.config import Config

signal.signal(signal.SIGINT, signal.SIG_DFL)

from PyQt6.QtCore import Qt, QPropertyAnimation, QPoint, QEasingCurve, QTimer
from PyQt6.QtWidgets import QApplication, QMainWindow, QProgressBar, QLabel, QGraphicsOpacityEffect, QVBoxLayout, \
    QWidget, QHBoxLayout, QMenu



def main():
    percentage = 0
    config_window = None

    app = QApplication(sys.argv)

    app.setStyle("Fusion")

    window = QMainWindow()
    window.setWindowFlags(
        Qt.WindowType.FramelessWindowHint |  # no border
        Qt.WindowType.WindowStaysOnTopHint |
        Qt.WindowType.Tool # doesnt show in taskbar
    )

    window.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

    def open_config_window():
        nonlocal config_window
        if config_window is None or not config_window.isVisible():
            config_window = gui_setup.run()
        else:
            config_window.raise_()
            config_window.activateWindow()

    def fetch_data():
        nonlocal percentage
        print("yes very important data")


        headers = {
            "Authorization": f"Bearer {token}",
        }

        r = requests.get(f"https://hackatime.hackclub.com/api/hackatime/v1/users/{user_id}/statusbar/today", headers=headers )

        if r.status_code != 200:
            print("ya fucked! status code: "+str(r.status_code))
            spawn_floating_text(window, "ERROR", QPoint(50, 30))
            return

        print(r.json())

        data = r.json()["data"]

        hours_today = (data["grand_total"]["total_seconds"] / 60) / 60

        percentage1 = hours_today / (goal / 100)

        text1.setText(f"{round(percentage1)}%")

        text2.setText(f"{round(hours_today, 2)}/{goal}h")

        progress.setValue(round(percentage1))

        spawn_floating_text(window, f"+{round(percentage1-percentage, 3)}%", QPoint(50, 30))
        percentage = round(percentage1, 2)


    def show_context_menu(pos):
        menu = QMenu(window)

        action1 = menu.addAction("Update")
        action2 = menu.addAction("Open Config GUI")
        action3 = menu.addAction("Exit")


        action = menu.exec(window.mapToGlobal(pos))

        if action == action1:
            fetch_data()
        elif action == action2:
            open_config_window()
        elif action  == action3:
            app.quit()

    def spawn_floating_text(parrent, text, start_pos):
        label = QLabel(text, parrent)
        label.setStyleSheet("""
        QLabel {
            color: #fff;
            font-size: 14px;
            font-weight: bold;
        }
        """)
        label.adjustSize()
        label.move(start_pos)
        label.show()

        opacity = QGraphicsOpacityEffect(label)
        label.setGraphicsEffect(opacity)

        move_anim = QPropertyAnimation(label, b"pos")
        move_anim.setDuration(800)
        move_anim.setStartValue(start_pos)
        move_anim.setEndValue(start_pos - QPoint(0, 25))
        move_anim.setEasingCurve(QEasingCurve.Type.OutCubic)

        fade_anim = QPropertyAnimation(opacity, b"opacity")
        fade_anim.setDuration(800)
        fade_anim.setStartValue(1.0)
        fade_anim.setEndValue(0.0)

        fade_anim.finished.connect(label.deleteLater)

        label.move_anim = move_anim
        label.fade_anim = fade_anim

        move_anim.start()
        fade_anim.start()


    #make window transparent


    window.setFixedSize(300, 75)

    container = QWidget()


    cfg = Config()

    percentage = 0
    user_id = cfg.get("username")
    token = cfg.get("hackatime_token")
    goal = float(cfg.get("daily_goal")) # In hours/DAY
    goal_text = cfg.get("goal")




    text1 = QLabel(window)
    text1.setText(f"{percentage}%")

    text2 = QLabel(window)
    text2.setText(f"Loading/{goal}h")


    text3 = QLabel(window)
    text3.setText(goal_text)

    progress = QProgressBar()

    progress.setMaximum(100)
    progress.setValue(percentage)
    progress.setFixedSize(250, 10)
    progress.setTextVisible(False)


    label_layout = QHBoxLayout()
    label_layout.setContentsMargins(0, 0, 0, 0)
    label_layout.addWidget(text1, alignment=Qt.AlignmentFlag.AlignLeft)
    label_layout.addWidget(text2, alignment=Qt.AlignmentFlag.AlignRight)

    layout = QVBoxLayout(container)
    layout.setContentsMargins(0, 0, 0, 0)
    layout.setAlignment(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignBottom)


    layout.addWidget(text3)
    layout.addWidget(progress)
    layout.addLayout(label_layout)








    fetch_timer = QTimer()
    fetch_timer.timeout.connect(fetch_data)
    fetch_timer.start(30000)

    window.setCentralWidget(container)

    #put it above taskbar
    screen = app.primaryScreen()
    rect = screen.availableGeometry()
    x = rect.right() - window.width() - 20
    y  = rect.bottom() - window.height() - 20
    window.move(x, y)

    window.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
    window.customContextMenuRequested.connect(show_context_menu)

    window.show()
    fetch_data()
    app.exec()