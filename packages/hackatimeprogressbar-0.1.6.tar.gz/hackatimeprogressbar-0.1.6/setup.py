from pathlib import Path

from setuptools import setup, find_packages

here = Path(__file__).parent

setup(
    name="hackatimeprogressbar",
    version="0.1.6",
    packages=find_packages(),
    package_data={
        'hackatimeprogressbar': ['*.txt'],
    },
    include_package_data=True,
    description="Display your set goal for Hackclub's Wakatime fork",
    long_description=open(here / "README.md").read(),
    long_description_content_type="text/markdown",
    author="Jan Koch",
    install_requires=["requests", "PyQt6"],
    url="https://github.com/meepstertron/HackatimeProgressBar",
    entry_points = {
        "console_scripts": [
            "hackatimeprogressbar=hackatimeprogressbar.main:main",
        ],
        "gui_scripts": [
            "hackatimeprogressbar-gui=hackatimeprogressbar.main:main",
        ]
    }
)