class RequiredParameterException(Exception):
    pass
