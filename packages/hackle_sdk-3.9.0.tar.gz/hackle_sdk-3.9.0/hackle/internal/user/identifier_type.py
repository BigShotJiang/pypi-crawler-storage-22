class IdentifierType(object):
    ID = '$id'
    USER = '$userId'
    DEVICE = '$deviceId'
