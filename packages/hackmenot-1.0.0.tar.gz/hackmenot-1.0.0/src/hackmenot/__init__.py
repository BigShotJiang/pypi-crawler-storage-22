"""hackmenot - AI-Era Code Security Scanner."""

__version__ = "1.0.0"
