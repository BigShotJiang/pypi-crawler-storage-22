"""Main CLI entry point using Typer."""

import json
from enum import Enum
from pathlib import Path

import typer
from rich.console import Console

from hackmenot import __version__
from hackmenot.cli.git import get_changed_files, get_staged_files, is_git_repo
from hackmenot.cli.interactive import (
    InteractiveFixer,
    apply_fixes_auto,
    write_fixed_files,
)
from hackmenot.core.config import ConfigLoader
from hackmenot.core.constants import SUPPORTED_EXTENSIONS
from hackmenot.core.models import ScanResult, Severity
from hackmenot.core.parallel_scanner import ParallelScanner
from hackmenot.core.scanner import Scanner
from hackmenot.fixes.diff import DiffGenerator
from hackmenot.graph.analyzer import RiskAnalysis
from hackmenot.reporters.terminal import TerminalReporter

app = typer.Typer(
    name="hackmenot",
    help="AI-Era Code Security Scanner",
    add_completion=False,
)
console = Console()


class OutputFormat(str, Enum):
    """Output format options."""

    terminal = "terminal"
    json = "json"
    sarif = "sarif"


def version_callback(value: bool) -> None:
    """Print version and exit."""
    if value:
        console.print(f"hackmenot {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool | None = typer.Option(
        None,
        "--version",
        "-v",
        help="Show version and exit.",
        callback=version_callback,
        is_eager=True,
    ),
) -> None:
    """hackmenot - AI-Era Code Security Scanner."""
    pass


@app.command()
def scan(
    paths: list[Path] | None = typer.Argument(
        None,
        help="Paths to scan (files or directories)",
    ),
    format: OutputFormat = typer.Option(
        OutputFormat.terminal,
        "--format",
        "-f",
        help="Output format",
    ),
    severity: str = typer.Option(
        "low",
        "--severity",
        "-s",
        help="Minimum severity to report: critical, high, medium, low",
    ),
    fail_on: str = typer.Option(
        "high",
        "--fail-on",
        help="Minimum severity to return non-zero exit code",
    ),
    fix: bool = typer.Option(
        False,
        "--fix",
        help="Automatically apply all available fixes",
    ),
    fix_interactive: bool = typer.Option(
        False,
        "--fix-interactive",
        help="Interactively apply fixes (prompt for each)",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Preview fixes without applying them (requires --fix)",
    ),
    diff: bool = typer.Option(
        False,
        "--diff",
        help="Show unified diff output (requires --fix --dry-run)",
    ),
    full: bool = typer.Option(
        False,
        "--full",
        help="Bypass cache, perform full scan",
    ),
    ci: bool = typer.Option(
        False,
        "--ci",
        help="CI-friendly output (no colors, machine-readable exit codes)",
    ),
    staged: bool = typer.Option(
        False,
        "--staged",
        help="Scan only git staged files (for pre-commit hooks)",
    ),
    changed_since: str | None = typer.Option(
        None,
        "--changed-since",
        help="Only scan files changed since this git ref (commit, branch, tag)",
    ),
    pr_comment: bool = typer.Option(
        False,
        "--pr-comment",
        help="Output markdown for PR comments",
    ),
    config_file: Path | None = typer.Option(
        None,
        "--config",
        "-c",
        help="Path to config file",
    ),
    include_deps: bool = typer.Option(
        False,
        "--include-deps",
        help="Also scan dependency files for security issues",
    ),
    parallel: bool = typer.Option(
        True,
        "--parallel/--no-parallel",
        help="Use parallel scanning (default: enabled in v2.0)",
    ),
    workers: int | None = typer.Option(
        None,
        "--workers",
        "-w",
        help="Number of worker processes for parallel scanning (default: CPU count)",
    ),
) -> None:
    """Scan code for security vulnerabilities."""
    # Use CI-friendly console if --ci flag is set
    scan_console = Console(force_terminal=False, no_color=True) if ci else console

    # Validate --fix and --fix-interactive are mutually exclusive
    if fix and fix_interactive:
        scan_console.print("Error: --fix and --fix-interactive cannot be used together")
        raise typer.Exit(1)

    # Validate --staged and --changed-since are mutually exclusive
    if staged and changed_since:
        scan_console.print("Error: --staged and --changed-since cannot be used together")
        raise typer.Exit(1)

    # Validate --dry-run requires --fix
    if dry_run and not fix:
        scan_console.print("Error: --dry-run requires --fix")
        raise typer.Exit(1)

    # Validate --diff requires --dry-run
    if diff and not dry_run:
        scan_console.print("Error: --diff requires --dry-run")
        raise typer.Exit(1)

    # Handle --staged flag
    if staged:
        if not is_git_repo():
            scan_console.print("Error: --staged requires a git repository")
            raise typer.Exit(1)

        staged_files = get_staged_files()
        if not staged_files:
            scan_console.print("No staged files to scan")
            raise typer.Exit(0)

        # Filter to supported extensions
        supported_extensions = SUPPORTED_EXTENSIONS
        scan_paths = [f for f in staged_files if f.suffix in supported_extensions and f.exists()]

        if not scan_paths:
            scan_console.print("No supported files in staged changes")
            raise typer.Exit(0)
    # Handle --changed-since flag
    elif changed_since:
        if not is_git_repo():
            scan_console.print("Error: --changed-since requires a git repository")
            raise typer.Exit(1)

        changed_files = get_changed_files(changed_since)
        if not changed_files:
            scan_console.print(f"No files changed since {changed_since}")
            raise typer.Exit(0)

        # Filter to supported extensions and existing files
        supported_extensions = SUPPORTED_EXTENSIONS
        scan_paths = [f for f in changed_files if f.suffix in supported_extensions and f.exists()]

        if not scan_paths:
            scan_console.print("No supported files in changes")
            raise typer.Exit(0)
    else:
        # Use provided paths
        if not paths:
            scan_console.print("Error: No paths provided")
            raise typer.Exit(1)
        scan_paths = list(paths)

    # Validate paths exist
    for path in scan_paths:
        if not path.exists():
            scan_console.print(f"Error: Path does not exist: {path}")
            raise typer.Exit(1)

    try:
        # Load configuration
        config_loader = ConfigLoader()
        if config_file is not None:
            if not config_file.exists():
                scan_console.print(f"Error: Config file not found: {config_file}")
                raise typer.Exit(1)
            config = config_loader.load_from_file(config_file)
        else:
            # Use current directory or first path's parent for config discovery
            project_dir = scan_paths[0].parent if scan_paths[0].is_file() else scan_paths[0]
            config = config_loader.load(project_dir)

        # Parse severity levels (CLI args override config)
        try:
            min_severity = Severity.from_string(severity)
            # Use config fail_on if not explicitly set on CLI
            effective_fail_on = fail_on if fail_on != "high" else config.fail_on
            fail_severity = Severity.from_string(effective_fail_on)
        except KeyError as e:
            scan_console.print(f"Error: Invalid severity level: {e}")
            raise typer.Exit(1)

        # Run scan with parallel or sequential scanner
        if parallel:
            # Use parallel scanner (v2.0)
            parallel_scanner = ParallelScanner(num_workers=workers, config=config)
            parallel_results = parallel_scanner.scan(scan_paths)

            # Convert ParallelScanner results to Scanner format
            # ParallelScanner returns (file_path, findings) tuples
            # Need to convert to Finding objects for compatibility
            findings_list = []
            for file_path, file_findings in parallel_results.findings:
                findings_list.extend(file_findings)

            result = ScanResult(
                files_scanned=parallel_results.files_scanned,
                findings=findings_list,
                scan_time_ms=0,  # Parallel scanner doesn't track time yet
            )
        else:
            # Use sequential scanner (v1.x, bypass cache if --full is set)
            scanner = Scanner(config=config)
            result = scanner.scan(scan_paths, min_severity=min_severity, use_cache=not full)

        # Include dependency scanning if requested
        if include_deps:
            from hackmenot.deps.scanner import DependencyScanner

            dep_scanner = DependencyScanner()
            project_dir = scan_paths[0].parent if scan_paths[0].is_file() else scan_paths[0]
            dep_result = dep_scanner.scan(project_dir)
            # Merge findings
            result = ScanResult(
                files_scanned=result.files_scanned + dep_result.files_scanned,
                findings=result.findings + dep_result.findings,
                scan_time_ms=result.scan_time_ms + dep_result.scan_time_ms,
            )

        # Output results (before applying fixes)
        if pr_comment:
            from hackmenot.reporters.markdown import MarkdownReporter

            md_reporter = MarkdownReporter()
            print(md_reporter.render(result))
        elif format == OutputFormat.terminal:
            reporter = TerminalReporter(console=scan_console)
            reporter.render(result)
        elif format == OutputFormat.json:
            _output_json(result)
        elif format == OutputFormat.sarif:
            from hackmenot.reporters.sarif import SARIFReporter

            reporter = SARIFReporter()
            print(reporter.render(result))
    except typer.Exit:
        raise
    except Exception as e:
        if ci:
            scan_console.print(f"Error during scan: {e}")
            raise typer.Exit(2)
        raise

    # Handle fix modes
    if (fix or fix_interactive) and result.has_findings:
        # Read file contents for findings
        original_contents: dict[str, str] = {}
        for finding in result.findings:
            if finding.file_path not in original_contents:
                try:
                    original_contents[finding.file_path] = Path(finding.file_path).read_text()
                except OSError as e:
                    scan_console.print(f"Error reading {finding.file_path}: {e}")

        if fix_interactive:
            # Interactive mode
            fixer = InteractiveFixer(console=scan_console)
            modified_contents = fixer.run(result.findings, original_contents)
        else:
            # Auto-fix mode (with optional dry-run)
            modified_contents, _ = apply_fixes_auto(
                result.findings, original_contents, console=scan_console if not dry_run else None
            )

        if dry_run:
            # Preview mode: show diffs, don't write files
            diff_gen = DiffGenerator(console=scan_console)
            diffs = diff_gen.generate_diffs(original_contents, modified_contents)
            if diff:
                # Full unified diff output
                diff_gen.print_diff(diffs)
            else:
                # Summary only
                diff_gen.print_summary(diffs)
            if diffs:
                scan_console.print("\n[dim]Run without --dry-run to apply these fixes.[/dim]")
        else:
            # Write modified files back to disk
            files_written = write_fixed_files(modified_contents, original_contents)
            if files_written > 0:
                scan_console.print(f"Modified {files_written} file(s)")

    # Exit code based on findings
    if result.findings_at_or_above(fail_severity):
        raise typer.Exit(1)


def _output_json(result: ScanResult) -> None:
    """Output results as JSON."""
    data = {
        "files_scanned": result.files_scanned,
        "scan_time_ms": result.scan_time_ms,
        "findings": [
            {
                "rule_id": f.rule_id,
                "rule_name": f.rule_name,
                "severity": str(f.severity),
                "message": f.message,
                "file_path": f.file_path,
                "line_number": f.line_number,
                "column": f.column,
                "code_snippet": f.code_snippet,
                "fix_suggestion": f.fix_suggestion,
                "education": f.education,
            }
            for f in result.findings
        ],
        "summary": {str(sev): count for sev, count in result.summary_by_severity().items()},
    }
    print(json.dumps(data, indent=2))


@app.command()
def rules(
    show_id: str | None = typer.Argument(
        None,
        help="Rule ID to show details for",
    ),
) -> None:
    """List available security rules."""
    from hackmenot.rules.registry import RuleRegistry

    registry = RuleRegistry()
    registry.load_all()

    if show_id:
        rule = registry.get_rule(show_id)
        if rule:
            console.print(f"\n[bold cyan]{rule.id}[/bold cyan]: {rule.name}")
            console.print(f"[dim]Severity:[/dim] {rule.severity}")
            console.print(f"[dim]Category:[/dim] {rule.category}")
            console.print(f"\n{rule.description}")
            if rule.education:
                console.print(f"\n[blue]Education:[/blue]\n{rule.education}")
        else:
            console.print(f"[red]Rule not found: {show_id}[/red]")
    else:
        console.print("\n[bold]Available Rules[/bold]\n")
        for rule in registry.get_all_rules():
            sev_color = {
                Severity.CRITICAL: "red",
                Severity.HIGH: "yellow",
                Severity.MEDIUM: "bright_yellow",
                Severity.LOW: "green",
            }[rule.severity]
            console.print(
                f"  [{sev_color}]{rule.severity.name:8}[/{sev_color}] "
                f"[cyan]{rule.id}[/cyan] - {rule.name}"
            )


@app.command()
def deps(
    path: Path = typer.Argument(..., help="Directory to scan for dependency files"),
    check_vulns: bool = typer.Option(False, "--check-vulns", help="Check for CVEs via OSV API"),
    format: OutputFormat = typer.Option(
        OutputFormat.terminal, "--format", "-f", help="Output format"
    ),
    fail_on: str = typer.Option("high", "--fail-on", help="Minimum severity for non-zero exit"),
    ci: bool = typer.Option(False, "--ci", help="CI-friendly output"),
) -> None:
    """Scan dependencies for security issues."""
    from hackmenot.deps.scanner import DependencyScanner

    scan_console = Console(force_terminal=False, no_color=True) if ci else console

    if not path.exists():
        scan_console.print(f"Error: Path does not exist: {path}")
        raise typer.Exit(1)
    if not path.is_dir():
        scan_console.print(f"Error: Path must be a directory: {path}")
        raise typer.Exit(1)

    try:
        scanner = DependencyScanner()
        result = scanner.scan(path, check_vulns=check_vulns)

        if format == OutputFormat.terminal:
            reporter = TerminalReporter(console=scan_console)
            reporter.render(result)
        elif format == OutputFormat.json:
            _output_json(result)
        elif format == OutputFormat.sarif:
            from hackmenot.reporters.sarif import SARIFReporter

            reporter = SARIFReporter()
            print(reporter.render(result))
    except typer.Exit:
        raise
    except Exception as e:
        if ci:
            scan_console.print(f"Error: {e}")
            raise typer.Exit(2)
        raise

    try:
        fail_severity = Severity.from_string(fail_on)
    except KeyError:
        scan_console.print(f"Error: Invalid severity: {fail_on}")
        raise typer.Exit(1)

    if result.findings_at_or_above(fail_severity):
        raise typer.Exit(1)


@app.command()
def surface(
    paths: list[Path] = typer.Argument(
        ...,
        help="Files or directories to analyze",
    ),
    public_only: bool = typer.Option(
        False,
        "--public-only",
        help="Show only public (unauthenticated) entry points",
    ),
    format: OutputFormat = typer.Option(
        OutputFormat.terminal,
        "--format",
        "-f",
        help="Output format: terminal, json",
    ),
) -> None:
    """Map the attack surface by detecting all entry points.

    Entry points are locations where untrusted data enters your application:
    - API endpoints (Flask, FastAPI routes)
    - CLI commands (Typer, Click)
    - User input (input(), stdin)

    Example:
        hackmenot surface . --public-only
    """
    from hackmenot.graph.surface import SurfaceMapper

    # Validate paths exist
    for path in paths:
        if not path.exists():
            console.print(f"Error: Path does not exist: {path}")
            raise typer.Exit(1)

    # Map the attack surface
    mapper = SurfaceMapper()
    attack_surface = mapper.map_surface(paths)

    # Filter if needed
    entry_points = attack_surface.entry_points
    if public_only:
        entry_points = [ep for ep in entry_points if not ep.auth_required]

    if format == OutputFormat.json:
        # JSON output
        output = {
            "total_entry_points": attack_surface.total_count,
            "public_entry_points": attack_surface.public_count,
            "authenticated_entry_points": attack_surface.authenticated_count,
            "entry_points": [
                {
                    "name": ep.name,
                    "type": ep.type.value,
                    "file": str(ep.file),
                    "line": ep.line,
                    "http_method": ep.http_method,
                    "route": ep.route,
                    "auth_required": ep.auth_required,
                    "framework": ep.framework,
                }
                for ep in entry_points
            ],
        }
        console.print_json(json.dumps(output, indent=2))
    else:
        # Terminal output
        from rich.table import Table

        # Summary
        console.print()
        console.print("[bold]Attack Surface Summary[/bold]")
        console.print(f"  Total entry points: {attack_surface.total_count}")
        console.print(
            f"  Public (no auth): {attack_surface.public_count} "
            + ("[yellow]⚠️[/yellow]" if attack_surface.public_count > 0 else "")
        )
        console.print(f"  Authenticated: {attack_surface.authenticated_count}")
        console.print()

        if not entry_points:
            console.print("[dim]No entry points found[/dim]")
            return

        # Group by type
        from hackmenot.graph.surface import EntryPointType

        by_type: dict[EntryPointType, list] = {}
        for ep in entry_points:
            if ep.type not in by_type:
                by_type[ep.type] = []
            by_type[ep.type].append(ep)

        # Print each type
        for ep_type, eps in by_type.items():
            title = f"{ep_type.value.replace('_', ' ').title()} ({len(eps)})"
            if public_only:
                title += " - Public Only"

            table = Table(title=title, show_header=True)
            table.add_column("Name", style="cyan")
            table.add_column("Location", style="dim")

            if ep_type == EntryPointType.API_ENDPOINT:
                table.add_column("Method", style="green")
                table.add_column("Route", style="yellow")
                table.add_column("Auth", style="red")
                table.add_column("Framework", style="dim")

                for ep in eps:
                    table.add_row(
                        ep.name,
                        f"{ep.file.name}:{ep.line}",
                        ep.http_method or "?",
                        ep.route or "?",
                        "✓" if ep.auth_required else "[red]✗[/red]",
                        ep.framework or "?",
                    )
            elif ep_type == EntryPointType.CLI_COMMAND:
                table.add_column("Framework", style="dim")

                for ep in eps:
                    table.add_row(
                        ep.name,
                        f"{ep.file.name}:{ep.line}",
                        ep.framework or "?",
                    )
            else:
                for ep in eps:
                    table.add_row(
                        ep.name,
                        f"{ep.file.name}:{ep.line}",
                    )

            console.print(table)
            console.print()


@app.command()
def flows(
    paths: list[Path] = typer.Argument(
        ...,
        help="Files or directories to analyze",
    ),
    format: OutputFormat = typer.Option(
        OutputFormat.terminal,
        "--format",
        "-f",
        help="Output format: terminal, json",
    ),
    show_sanitized: bool = typer.Option(
        False,
        "--show-sanitized",
        help="Show flows that appear to be sanitized",
    ),
) -> None:
    """Trace data flows from entry points to security sinks.

    Identifies paths where untrusted input from entry points flows to
    security-sensitive operations (SQL queries, shell commands, etc.)
    without proper sanitization.

    Example:
        hackmenot flows .
        hackmenot flows src/ --format json
    """
    from hackmenot.graph.dataflow import DataFlowTracker

    # Validate paths exist
    for path in paths:
        if not path.exists():
            console.print(f"Error: Path does not exist: {path}")
            raise typer.Exit(1)

    # Analyze data flows
    tracker = DataFlowTracker()
    flow_paths = tracker.analyze(paths)

    # Filter out sanitized flows unless requested
    if not show_sanitized:
        flow_paths = [flow for flow in flow_paths if not flow.sanitized]

    if format == OutputFormat.json:
        # JSON output
        output = {
            "total_flows": len(flow_paths),
            "unsanitized_flows": sum(1 for f in flow_paths if not f.sanitized),
            "flows": [
                {
                    "source": {
                        "entry_point": flow.source.entry_point.name,
                        "parameter": flow.source.parameter,
                        "file": str(flow.source.file),
                        "line": flow.source.line,
                    },
                    "sink": {
                        "type": flow.sink.type.value,
                        "operation": flow.sink.operation,
                        "file": str(flow.sink.file),
                        "line": flow.sink.line,
                    },
                    "sanitized": flow.sanitized,
                    "path_length": len(flow.path),
                }
                for flow in flow_paths
            ],
        }
        console.print_json(json.dumps(output, indent=2))
    else:
        # Terminal output
        from rich.table import Table

        console.print()
        console.print("[bold]Data Flow Analysis[/bold]")
        console.print(f"  Total flows: {len(flow_paths)}")
        console.print(
            f"  Unsanitized flows: {sum(1 for f in flow_paths if not f.sanitized)} "
            + ("[yellow]⚠️[/yellow]" if any(not f.sanitized for f in flow_paths) else "")
        )
        console.print()

        if not flow_paths:
            console.print("[dim]No data flows detected[/dim]")
            return

        table = Table(title="Data Flows from Entry Points to Sinks", show_header=True)
        table.add_column("Source", style="cyan")
        table.add_column("Sink", style="red")
        table.add_column("Type", style="yellow")
        table.add_column("Sanitized", style="green")

        for flow in flow_paths:
            source_desc = f"{flow.source.entry_point.name}() [{flow.source.parameter}]"
            sink_desc = f"{flow.sink.operation} ({flow.sink.file.name}:{flow.sink.line})"
            sink_type = flow.sink.type.value.replace("_", " ").title()
            sanitized = "✓" if flow.sanitized else "[red]✗[/red]"

            table.add_row(source_desc, sink_desc, sink_type, sanitized)

        console.print(table)
        console.print()


@app.command()
def graph(
    paths: list[Path] = typer.Argument(
        ...,
        help="Files or directories to analyze",
    ),
    output: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Output file path (.dot extension)",
    ),
    format: str = typer.Option(
        "dot",
        "--format",
        "-f",
        help="Output format: dot, stats",
    ),
) -> None:
    """Generate security graph visualization.

    Creates a GraphViz DOT file showing relationships between entry points,
    data flows, and security sinks. The graph can be rendered using GraphViz:

        dot -Tpng security-graph.dot -o security-graph.png

    Example usage:
        hackmenot graph . --output security.dot
        hackmenot graph src/ --format stats
    """
    from hackmenot.graph.builder import SecurityGraphBuilder

    # Validate paths exist
    for path in paths:
        if not path.exists():
            console.print(f"Error: Path does not exist: {path}")
            raise typer.Exit(1)

    # Build security graph
    console.print("[dim]Building security graph...[/dim]")
    builder = SecurityGraphBuilder()
    builder.build(paths)

    if format == "stats":
        # Show statistics
        stats = builder.get_stats()
        console.print()
        console.print("[bold]Security Graph Statistics[/bold]")
        console.print(f"  Total nodes: {stats['total_nodes']}")
        console.print(f"  Entry points: {stats['entry_points']}")
        console.print(f"  Security sinks: {stats['sinks']}")
        console.print(f"  Data flows: {stats['total_edges']}")
        console.print(
            f"  Vulnerable flows: {stats['vulnerable_flows']} "
            + ("[red]⚠️[/red]" if stats["vulnerable_flows"] > 0 else "")
        )
        console.print()
    else:
        # Generate DOT output
        if output:
            builder.write_dot(output)
            console.print(f"[green]✓[/green] Security graph written to: {output}")
            console.print()
            console.print("[dim]To visualize:[/dim]")
            console.print(f"  dot -Tpng {output} -o {output.stem}.png")
            console.print(f"  dot -Tsvg {output} -o {output.stem}.svg")
        else:
            # Output to stdout
            dot_content = builder.to_dot()
            console.print(dot_content)


@app.command()
def analyze(
    paths: list[Path] = typer.Argument(
        ...,
        help="Files or directories to analyze",
    ),
    format: str = typer.Option(
        "table",
        "--format",
        "-f",
        help="Output format: table, json, summary",
    ),
    show_chains: bool = typer.Option(
        True,
        "--show-chains/--no-chains",
        help="Show exploit chains",
    ),
    show_steps: bool = typer.Option(
        False,
        "--show-steps",
        help="Show detailed exploit steps for each path",
    ),
) -> None:
    """Analyze attack paths and calculate risk scores.

    Performs comprehensive risk analysis of the codebase by:
    - Scoring attack paths from entry points to security sinks
    - Detecting exploit chains (multiple vulnerabilities through one entry point)
    - Prioritizing vulnerabilities for remediation
    - Generating actionable recommendations

    Example usage:
        hackmenot analyze . --show-chains
        hackmenot analyze src/ --format json
        hackmenot analyze . --show-steps
    """
    from hackmenot.graph.analyzer import AttackPathAnalyzer
    from hackmenot.graph.dataflow import DataFlowTracker
    from hackmenot.graph.surface import SurfaceMapper

    # Validate paths exist
    for path in paths:
        if not path.exists():
            console.print(f"Error: Path does not exist: {path}")
            raise typer.Exit(1)

    # Analyze attack surface and data flows
    console.print("[dim]Analyzing attack surface...[/dim]")
    surface_mapper = SurfaceMapper()
    attack_surface = surface_mapper.map_surface(paths)

    console.print("[dim]Tracing data flows...[/dim]")
    flow_tracker = DataFlowTracker()
    data_flows = flow_tracker.analyze(paths)

    console.print("[dim]Calculating risk scores...[/dim]")
    analyzer = AttackPathAnalyzer()
    analysis = analyzer.analyze(attack_surface, data_flows)

    console.print()

    if format == "json":
        # JSON output
        import json

        output = {
            "total_paths": analysis.total_paths,
            "overall_risk_score": analysis.overall_risk_score,
            "critical_paths": len(analysis.critical_paths),
            "high_risk_paths": len(analysis.high_risk_paths),
            "medium_risk_paths": len(analysis.medium_risk_paths),
            "low_risk_paths": len(analysis.low_risk_paths),
            "exploit_chains": len(analysis.exploit_chains),
            "recommendations": analysis.top_recommendations,
            "attack_paths": [
                {
                    "entry_point": path.entry_point_name,
                    "file": str(path.entry_point_file),
                    "line": path.entry_point_line,
                    "sink_type": path.sink_type.value,
                    "sink_operation": path.sink_operation,
                    "risk_score": path.risk_score,
                    "risk_level": path.risk_level.value,
                    "authenticated": path.authenticated,
                    "sanitized": path.sanitized,
                }
                for path in (
                    analysis.critical_paths + analysis.high_risk_paths + analysis.medium_risk_paths
                )
            ],
        }
        print(json.dumps(output, indent=2))

    elif format == "summary":
        # Summary output
        console.print("[bold]Risk Analysis Summary[/bold]")
        console.print()
        console.print(f"Overall Risk Score: [red]{analysis.overall_risk_score}/100[/red]")
        console.print(f"Total Attack Paths: {analysis.total_paths}")
        console.print()
        console.print(f"[red]●[/red] Critical: {len(analysis.critical_paths)}")
        console.print(f"[yellow]●[/yellow] High: {len(analysis.high_risk_paths)}")
        console.print(f"[blue]●[/blue] Medium: {len(analysis.medium_risk_paths)}")
        console.print(f"[dim]●[/dim] Low: {len(analysis.low_risk_paths)}")
        console.print()

        if analysis.exploit_chains:
            console.print(f"[red]⚠️  {len(analysis.exploit_chains)} exploit chain(s) detected[/red]")
            console.print()

        console.print("[bold]Top Recommendations:[/bold]")
        for rec in analysis.top_recommendations:
            console.print(f"  • {rec}")
        console.print()

    else:
        # Table output (default)
        _display_risk_analysis(analysis, show_chains, show_steps)


def _display_risk_analysis(analysis: RiskAnalysis, show_chains: bool, show_steps: bool) -> None:
    """Display risk analysis in table format.

    Args:
        analysis: Risk analysis results.
        show_chains: Whether to show exploit chains.
        show_steps: Whether to show detailed exploit steps.
    """
    from rich.table import Table

    # Overall summary
    console.print("[bold]Attack Path Risk Analysis[/bold]")
    console.print()
    console.print(f"Overall Risk Score: [red]{analysis.overall_risk_score}/100[/red]")
    console.print(f"Total Attack Paths: {analysis.total_paths}")
    console.print()

    # Show critical paths
    if analysis.critical_paths:
        console.print("[bold red]Critical Risk Paths[/bold red]")
        table = Table(show_header=True, header_style="bold red")
        table.add_column("Entry Point", style="cyan")
        table.add_column("Sink", style="red")
        table.add_column("Risk", style="red", justify="right")
        table.add_column("Auth", justify="center")
        table.add_column("Mitigation", style="yellow")

        for path in analysis.critical_paths[:10]:  # Top 10
            auth = "✓" if path.authenticated else "[red]✗[/red]"
            table.add_row(
                f"{path.entry_point_name}()\n{path.entry_point_file.name}:{path.entry_point_line}",
                f"{path.sink_type.value}\n{path.sink_operation}",
                f"{path.risk_score}",
                auth,
                path.mitigation,
            )

            if show_steps:
                console.print(table)
                table = Table(show_header=True, header_style="bold red")
                table.add_column("Entry Point", style="cyan")
                table.add_column("Sink", style="red")
                table.add_column("Risk", style="red", justify="right")
                table.add_column("Auth", justify="center")
                table.add_column("Mitigation", style="yellow")

                console.print(f"\n[bold]Exploit Steps for {path.entry_point_name}():[/bold]")
                for i, step in enumerate(path.exploit_steps, 1):
                    console.print(f"  {i}. {step}")
                console.print()

        if not show_steps:
            console.print(table)
            console.print()

    # Show high risk paths
    if analysis.high_risk_paths:
        console.print("[bold yellow]High Risk Paths[/bold yellow]")
        table = Table(show_header=True, header_style="bold yellow")
        table.add_column("Entry Point", style="cyan")
        table.add_column("Sink", style="red")
        table.add_column("Risk", style="yellow", justify="right")
        table.add_column("Auth", justify="center")

        for path in analysis.high_risk_paths[:5]:  # Top 5
            auth = "✓" if path.authenticated else "[red]✗[/red]"
            table.add_row(
                f"{path.entry_point_name}()\n{path.entry_point_file.name}:{path.entry_point_line}",
                f"{path.sink_type.value}\n{path.sink_operation}",
                f"{path.risk_score}",
                auth,
            )

        console.print(table)
        console.print()

    # Show exploit chains
    if show_chains and analysis.exploit_chains:
        console.print("[bold red]Exploit Chains[/bold red]")
        for chain in analysis.exploit_chains:
            console.print(f"\n[red]{chain.chain_id}[/red] (Risk: {chain.combined_risk_score}/100)")
            console.print(f"  {chain.description}")
            console.print(f"  [dim]{chain.exploit_scenario}[/dim]")
            console.print(f"  Paths in chain: {len(chain.attack_paths)}")
        console.print()

    # Show recommendations
    console.print("[bold]Top Recommendations:[/bold]")
    for rec in analysis.top_recommendations:
        console.print(f"  • {rec}")
    console.print()
