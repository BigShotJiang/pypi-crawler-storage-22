import argparse
import requests
import json
import sys

API_URL = "https://callapp.hackpurgatory.org/callapp"


def main():
    parser = argparse.ArgumentParser(
        prog="hackpurgatory-callapp",
        description="HackPurgatory CallApp API"
    )

    parser.add_argument(
        "-n",
        "--number",
        required=True,
        help="Número telefónico en formato internacional"
    )

    args = parser.parse_args()

    try:
        response = requests.get(
            API_URL,
            params={"number": args.number},
            timeout=20
        )

        response.raise_for_status()

        data = response.json()

        print(json.dumps(data, indent=2, ensure_ascii=False))

    except requests.RequestException as e:
        print(f"Error HTTP: {e}", file=sys.stderr)
        sys.exit(1)

    except json.JSONDecodeError:
        print("Error", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
