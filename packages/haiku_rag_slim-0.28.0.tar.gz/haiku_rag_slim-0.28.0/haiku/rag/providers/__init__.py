"""Provider clients for external services."""

from haiku.rag.providers.docling_serve import DoclingServeClient

__all__ = ["DoclingServeClient"]
