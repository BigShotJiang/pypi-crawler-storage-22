from haiku.rag.agents.chat.agent import (
    DEFAULT_FEATURES,
    FEATURE_ANALYSIS,
    FEATURE_DOCUMENTS,
    FEATURE_QA,
    FEATURE_SEARCH,
    ChatDeps,
    build_chat_toolkit,
    create_chat_agent,
    prepare_chat_context,
    run_chat_agent,
    trigger_background_summarization,
)
from haiku.rag.agents.chat.prompts import build_chat_prompt
from haiku.rag.agents.chat.state import (
    AGUI_STATE_KEY,
    ChatSessionState,
    _rebuild_models,
)
from haiku.rag.tools.qa import QAHistoryEntry

_rebuild_models(QAHistoryEntry)

__all__ = [
    "AGUI_STATE_KEY",
    "DEFAULT_FEATURES",
    "FEATURE_ANALYSIS",
    "FEATURE_DOCUMENTS",
    "FEATURE_QA",
    "FEATURE_SEARCH",
    "build_chat_prompt",
    "build_chat_toolkit",
    "create_chat_agent",
    "prepare_chat_context",
    "run_chat_agent",
    "trigger_background_summarization",
    "ChatDeps",
    "ChatSessionState",
]
