# 🚀 **Hakalab Framework**

Un framework completo y profesional de pruebas funcionales que utiliza **Playwright** para automatización web moderna y **Behave** para BDD (Behavior Driven Development). Diseñado para casos de uso empresariales con capacidades avanzadas de simulación humana y procesamiento de datos.

## ✨ **Características Principales v1.3.0**

### 🎯 **Core Features**
- **🎭 Playwright**: Automatización web moderna, rápida y confiable
- **🥒 Behave**: Framework BDD para Python con soporte completo para Gherkin
- **🌍 Multiidioma**: Soporte para pasos en inglés, español o mixto
- **📋 Page Object Model**: Elementos organizados en archivos JSON
- **🔤 Variables Dinámicas**: Sistema completo de manejo y generación de variables
- **📊 Reportes HTML**: Reportes HTML personalizados con screenshots integrados
- **🎨 Scenario Outlines**: Soporte completo para pruebas parametrizadas

### 🆕 **Nuevas Funcionalidades v1.3.0**
- **🌐 Manipulación de Elementos Web**: Control completo del DOM, atributos, estilos y eventos
- **📝 Manejo Avanzado de Formularios**: Validación, auto-llenado, extracción de datos
- **🌐 Control Total del Navegador**: Cookies, localStorage, sessionStorage, JavaScript
- **🗄️ Testing de Bases de Datos**: Conexiones SQLite, consultas, validaciones
- **📧 Testing de Email**: SMTP, IMAP, verificación de códigos, comunicaciones
- **🔗 Integración Jira/Xray AUTOMÁTICA**: Configuración automática sin código adicional
- **📊 Procesamiento CSV**: Carga, análisis, filtrado y manipulación de archivos CSV
- **⌨️ Entrada Avanzada**: Simulación de escritura humana con errores y velocidades variables
- **⏱️ Control de Tiempos**: Cronómetros, esperas inteligentes y medición de rendimiento
- **🔤 Variables Mejoradas**: Generación automática de texto, números, fechas y timestamps
- **🎭 Simulación Realista**: Comportamiento humano con delays aleatorios y errores simulados
- **📈 Medición de Rendimiento**: Cronometraje de operaciones críticas
- **🎯 Drag & Drop Mejorado**: Sistema rediseñado con múltiples fallbacks y timing preciso

### 🔧 **Capacidades Avanzadas**
- **🎯 Drag & Drop**: Arrastrar y soltar elementos con precisión y confiabilidad mejorada
- **🚨 Alerts & Modales**: Manejo completo de diálogos y ventanas emergentes
- **🖼️ iFrames**: Navegación y interacción con contenido embebido
- **📁 File Upload/Download**: Gestión completa de archivos con validación
- **🔍 Búsquedas Avanzadas**: Múltiples estrategias de localización de elementos
- **📱 Responsive Testing**: Pruebas en diferentes resoluciones y dispositivos
- **🎬 Video Recording**: Grabación automática de ejecuciones de prueba
- **♿ Accessibility Testing**: Validaciones ARIA, contraste, navegación por teclado
- **⚡ Performance Testing**: Medición de tiempos, respuesta y métricas avanzadas

## 🚀 **Instalación Rápida**

> **📢 Importante**: A partir de la versión 1.2.23+, el framework se distribuye exclusivamente a través de GitHub. Ya no está disponible en PyPI.

### Instalación desde GitHub
```bash
pip install git+https://github.com/pipefariashaka/hakalab-framework.git
python -m playwright install
hakalab-init my-project
cd my-project
behave
```

### Instalación de Versión Específica
```bash
# Instalar versión específica
pip install git+https://github.com/pipefariashaka/hakalab-framework.git@v1.2.23

# Instalar desde rama específica
pip install git+https://github.com/pipefariashaka/hakalab-framework.git@main
pip install git+https://github.com/pipefariashaka/hakalab-framework.git@develop
```

### Actualización del Framework
```bash
# Actualizar a la última versión
pip install --upgrade git+https://github.com/pipefariashaka/hakalab-framework.git
```

### Instalación en Modo Desarrollo
```bash
# Para desarrollo y contribuciones
git clone https://github.com/pipefariashaka/hakalab-framework.git
cd hakalab-framework
pip install -e .
python -m playwright install
behave
```

## 📁 **Estructura del Proyecto**

```
my-project/
├── 📂 features/
│   ├── 📄 example_login.feature    # Feature de ejemplo
│   ├── 📄 environment.py           # Configuración de Behave
│   └── 📂 steps/
│       └── 📄 custom_steps.py      # Steps personalizados
├── 📂 json_poms/
│   ├── 📄 LOGIN.json              # Page Objects en JSON
│   └── 📄 DASHBOARD.json          # Elementos de dashboard
├── 📂 hakalab_framework/
│   ├── 📂 core/                   # Núcleo del framework
│   ├── 📂 steps/                  # Steps predefinidos
│   │   ├── 📄 navigation_steps.py  # Navegación y URLs
│   │   ├── 📄 interaction_steps.py # Clicks, hover, formularios
│   │   ├── 📄 assertion_steps.py   # Verificaciones
│   │   ├── 📄 wait_steps.py        # Esperas y timing
│   │   ├── 📄 window_steps.py      # Ventanas y pestañas
│   │   ├── 📄 advanced_steps.py    # JavaScript y screenshots
│   │   ├── 📄 drag_drop_steps.py   # Arrastrar y soltar (MEJORADO v1.2.14)
│   │   ├── 📄 modal_steps.py       # Modales y diálogos
│   │   ├── 📄 combobox_steps.py    # Selects y dropdowns
│   │   ├── 📄 iframe_steps.py      # Interacción con iframes
│   │   ├── 📄 file_steps.py        # Upload y download
│   │   ├── 📄 table_steps.py       # Tablas avanzadas
│   │   ├── 📄 keyboard_mouse_steps.py # Interacciones avanzadas
│   │   ├── 📄 salesforce_steps.py  # Automatización Salesforce
│   │   ├── 📄 environment_steps.py # Variables de entorno
│   │   ├── 📄 data_extraction_steps.py # Extracción de datos
│   │   ├── 📄 csv_file_steps.py    # Procesamiento CSV (NUEVO v1.2.12)
│   │   ├── 📄 timing_steps.py      # Control avanzado de tiempos (NUEVO v1.2.12)
│   │   ├── 📄 advanced_input_steps.py # Entrada sofisticada (NUEVO v1.2.12)
│   │   └── 📄 variable_steps.py    # Variables dinámicas (NUEVO v1.2.12)
│   └── 📂 utils/                  # Utilidades y helpers
├── 📂 html-reports/               # Reportes HTML generados
├── 📂 screenshots/                # Capturas de pantalla
├── 📂 videos/                     # Grabaciones de video
├── 📂 downloads/                  # Archivos descargados
├── 📄 .env                        # Variables de entorno
├── 📄 behave.ini                  # Configuración de Behave
└── 📚 Documentación/
    ├── 📄 GUIA_COMPLETA_STEPS.md      # Guía completa de steps
    ├── 📄 FUNCIONALIDADES_AVANZADAS_v1.2.14.md # Nuevas funcionalidades
    ├── 📄 GUIA_INSTALACION.md         # Guía de instalación
    ├── 📄 STEPS_AVANZADOS.md          # Steps avanzados
    ├── 📄 STEPS_SALESFORCE.md         # Automatización Salesforce
    ├── 📄 VARIABLES_ENTORNO.md        # Variables de entorno
    └── 📄 GUIA_STEPS_PERSONALIZADOS.md # Crear steps personalizados
```

## 🎯 **Steps Disponibles (485 funciones únicas / 1072 variantes)**

### 🧭 **Navigation Steps** - Navegación y URLs
```gherkin
Given voy a la url "https://example.com"
When recargo la página
When voy hacia atrás
When espero 5 segundos
When abro una nueva pestaña
```

### 🖱️ **Interaction Steps** - Clicks, hover, formularios
```gherkin
When hago click en el elemento "button_login" con identificador "id"
When relleno el campo "username" con "admin" con identificador "name"
When selecciono la opción "España" del dropdown "country" con identificador "name"
When marco el checkbox "terms" con identificador "id"
```

### ✅ **Assertion Steps** - Verificaciones y validaciones
```gherkin
Then debería ver el texto "Bienvenido"
Then el título de la página debería ser "Dashboard"
Then el elemento "welcome_message" debería estar visible con identificador "id"
Then la url actual debería contener "dashboard"
```

### 🌐 **Web Elements Steps** - Manipulación avanzada del DOM (NUEVO v1.3.0)
```gherkin
# Manipulación de atributos y estilos
When establezco el atributo "data-test" con valor "active" en el elemento "button" con identificador "id"
When establezco el estilo CSS "background-color" con valor "red" en el elemento "div" con identificador "class"

# Control de foco y eventos
When enfoco el elemento "input" con identificador "id"
When disparo el evento "change" en el elemento "select" con identificador "css"

# Información de elementos
When obtengo las dimensiones del elemento y las guardo en variables ancho="width" alto="height" para elemento "container" con identificador "id"
```

### 📝 **Form Handling Steps** - Manejo avanzado de formularios (NUEVO v1.3.0)
```gherkin
# Operaciones de formulario
When envío el formulario "login_form" con identificador "id"
When reseteo el formulario "contact_form" con identificador "name"

# Llenado automático y validación
When auto-relleno el formulario "user_form" con datos de prueba usando identificador "class"
When valido el formulario "checkout" con identificador "id"
When verifico los campos requeridos en el formulario "profile" con identificador "name"
```

### 🌐 **Browser Control Steps** - Control del navegador (NUEVO v1.3.0)
```gherkin
# Gestión de cookies y storage
When establezco la cookie "session_id" con valor "abc123"
When establezco el item de localStorage "theme" con valor "dark"
When establezco el item de sessionStorage "temp_id" con valor "xyz789"

# Configuración del navegador
When establezco el viewport del navegador a "1366x768"
When ejecuto JavaScript "document.title" y guardo el resultado en la variable "page_title"
```

### 🗄️ **Database Steps** - Testing de bases de datos (NUEVO v1.3.0)
```gherkin
# Conexión y consultas
When me conecto a la base de datos SQLite "test_database.db"
When ejecuto la consulta SQL "SELECT * FROM users WHERE active = 1" y guardo el resultado en la variable "active_users"

# Validaciones y gestión
When verifico que el resultado de la consulta SQL tiene "5" filas
When creo la tabla "test_users" con columnas "id INTEGER PRIMARY KEY, name TEXT, email TEXT"
```

### 📧 **Email Steps** - Testing de email (NUEVO v1.3.0)
```gherkin
# Envío y recepción
When envío email a "recipient@example.com" con asunto "Test Email" y cuerpo "This is a test message" usando SMTP "smtp.gmail.com" puerto "587"
When me conecto al servidor IMAP "imap.gmail.com" puerto "993" con usuario "test@company.com" contraseña "password123"

# Verificación y extracción
When verifico que se recibió un email con asunto "Welcome" dentro de "30" segundos
When extraigo el código de verificación del cuerpo del email y lo guardo en la variable "verification_code"
```

### 🎯 **Drag & Drop Steps** - Arrastrar y soltar (MEJORADO v1.2.14)
```gherkin
# Drag & Drop básico con timing mejorado
When arrastro el elemento "source_item" al elemento "target_area" con identificadores "id" y "class"

# Drag & Drop lento para elementos sensibles (20 pasos incrementales)
When arrastro lentamente el elemento "delicate_slider" al elemento "target" con identificadores "css" y "id"

# Hover antes de arrastrar (para elementos que requieren activación)
When paso el mouse sobre el elemento antes de arrastrar "menu_item" con identificador "class"

# Drag & Drop avanzado con múltiples fallbacks (API nativa + manual + HTML5)
When realizo drag and drop avanzado desde "complex_element" hasta "target" con identificadores "xpath" y "css"

# Verificación de drag & drop exitoso
Then verifico que el drag and drop fue exitoso comprobando la posición del elemento "moved_item" con identificador "id"

# Drag & Drop de archivos
When arrastro y suelto el archivo "test_document.pdf" al elemento "upload_zone" con identificador "id"

# Drag & Drop por coordenadas específicas
When arrastro el elemento "item" a las coordenadas x="300" y="200" con identificador "id"

# Drag & Drop por desplazamiento relativo
When arrastro el elemento "box" por desplazamiento x="100" y="-50" con identificador "class"
```

### 📋 **Combobox Steps** - Selects y dropdowns avanzados
```gherkin
When selecciono por texto visible "Opción 1" del elemento "dropdown" con identificador "id"
When escribo y selecciono "Madrid" en el combobox buscable "city" con identificador "id"
```

### 💬 **Modal Steps** - Modales y diálogos
```gherkin
When espero a que aparezca el modal
When cierro el modal haciendo clic en el botón de cerrar
Then el modal debería contener el texto "Confirmar acción"
```

### 📁 **File Steps** - Upload, download y archivos
```gherkin
When subo el archivo "documents/test.pdf" al campo "file_upload" con identificador "id"
Then el archivo "report.pdf" debería estar descargado
Then el archivo descargado "data.csv" debería contener "usuario,email"
```

## 🔧 **Configuración**

### Variables de Entorno (.env)
```bash
# === CONFIGURACIÓN DEL NAVEGADOR ===
BROWSER=chromium              # chromium, firefox, webkit
HEADLESS=false               # true/false
TIMEOUT=30000                # Timeout en milisegundos
WINDOW_SIZE=1920,1080        # Tamaño de ventana

# === RUTAS Y DIRECTORIOS ===
JSON_POMS_PATH=json_poms     # Carpeta de Page Objects
SCREENSHOTS_DIR=screenshots   # Directorio de screenshots
HTML_REPORTS_DIR=html-reports # Directorio de reportes HTML
DOWNLOADS_DIR=downloads       # Directorio de descargas
VIDEOS_DIR=videos            # Directorio de videos

# === INTEGRACIÓN JIRA/XRAY (AUTOMÁTICA) ===
JIRA_ENABLED=true                    # true=habilitar, false=deshabilitar
JIRA_URL=https://empresa.atlassian.net
JIRA_EMAIL=tu-email@empresa.com
JIRA_TOKEN=tu_api_token_de_jira
JIRA_PROJECT=PROJ                    # Clave del proyecto
JIRA_COMMENT_MESSAGE=Reporte QA      # Mensaje para comentarios

# Xray (opcional)
XRAY_AUTHORIZATION_TOKEN=tu_token_xray
XRAY_BASE_URL=https://xray.cloud.getxray.app

# === FUNCIONALIDADES AVANZADAS ===
HTML_REPORT_CAPTURE_ALL_STEPS=true  # Screenshots en cada step
SCREENSHOT_FULL_PAGE=true            # Screenshots de página completa
VIDEO_RECORDING=false                # Grabación de video
CLEANUP_OLD_FILES=true               # Limpieza automática
CLEANUP_MAX_AGE_HOURS=24            # Edad máxima de archivos

# === VARIABLES DE PRUEBA ===
BASE_URL=https://example.com
TEST_EMAIL=test@example.com
TEST_PASSWORD=password123
API_KEY=your-api-key-here
DATABASE_URL=postgresql://localhost/testdb
```

### 🔗 **Integración Jira/Xray Automática**

El framework detecta automáticamente si Jira/Xray está habilitado y configura toda la integración **SIN CÓDIGO ADICIONAL**:

#### ✅ **Configuración Simple**
1. Configura las variables de entorno en `.env`
2. Usa el template `environment_simple.py`
3. ¡Listo! Todo funciona automáticamente

#### 🎯 **Funcionalidades Automáticas**
- **Adjuntar reportes HTML**: Los reportes se adjuntan automáticamente a las issues de Jira
- **Test Executions en Xray**: Se crean automáticamente con todos los tests del feature
- **Estados actualizados**: Mapeo automático de passed/failed/skipped
- **Vinculación a HU**: Test Executions se vinculan a Historias de Usuario
- **CERO configuración manual**: El framework maneja todo automáticamente

#### 📋 **Uso de Tags**
```gherkin
@PROJ-123
Feature: Login de usuarios
  # El reporte HTML se adjuntará automáticamente a PROJ-123
  
  @PROJ-124
  Scenario: Login exitoso
    # Este test se incluirá automáticamente en Xray
```

Ver [Guía Completa de Integración Jira/Xray](hakalab_framework/documentacion/GUIA_INTEGRACION_JIRA_XRAY.md) para más detalles.

## 🎬 **Ejemplos de Uso**

### 1. Feature Básico
```gherkin
# language: es
Feature: Login de usuario
  Como usuario del sistema
  Quiero poder iniciar sesión
  Para acceder a mi cuenta

  Background:
    Given voy a la url "${BASE_URL}/login"

  Scenario: Login exitoso
    When relleno el campo "email" con "${TEST_EMAIL}" con identificador "$.LOGIN.email_field"
    And relleno el campo "password" con "${TEST_PASSWORD}" con identificador "$.LOGIN.password_field"
    And hago click en el elemento "login_button" con identificador "$.LOGIN.login_button"
    Then debería ver el elemento "welcome_message" con identificador "$.DASHBOARD.welcome_message"
    And la url actual debería contener "dashboard"
```

### 2. Procesamiento de CSV (NUEVO v1.2.12)
```gherkin
Feature: Pruebas con datos CSV
  
  Scenario: Procesamiento de empleados desde CSV
    Given cargo el archivo CSV "test_data/empleados.csv" en la variable "empleados"
    And muestro un resumen del CSV "empleados"
    When filtro el CSV "empleados" donde "departamento" contiene "Desarrollo" y guardo como "desarrolladores"
    And obtengo el valor de la fila 0 columna "nombre" del CSV "desarrolladores" y lo guardo en "mejor_dev"
    Then verifico que la variable "mejor_dev" contiene "Juan"
```

### 3. Drag & Drop Mejorado (NUEVO v1.2.14)
```gherkin
Feature: Drag and Drop avanzado
  
  Scenario: Reordenamiento de elementos con verificación
    Given voy a la url "https://example.com/sortable-list"
    When paso el mouse sobre el elemento antes de arrastrar "item_1" con identificador "css:.sortable-item:first-child"
    And arrastro lentamente el elemento "item_1" al elemento "drop_zone" con identificadores "css:.sortable-item:first-child" y "css:.drop-zone"
    Then verifico que el drag and drop fue exitoso comprobando la posición del elemento "item_1" con identificador "css:.sortable-item:first-child"
```

## 📊 **Reportes**

### Reportes HTML Automáticos
- **Generación automática**: Reportes HTML se crean en cada ejecución
- **Screenshots integrados**: Capturas automáticas en fallos y steps críticos
- **Navegación intuitiva**: Interface web para revisar resultados
- **Estadísticas detalladas**: Tiempos, éxitos, fallos por feature y scenario

### Comandos de Reporte
```bash
# Ejecutar con reporte HTML
behave -f html -o html-reports/report.html

# Abrir reporte generado
open html-reports/report.html  # Mac
start html-reports/report.html # Windows
xdg-open html-reports/report.html # Linux
```

## 🔄 **Changelog**

### **v1.3.0** - 2026-01-09 ⭐ **NUEVA VERSIÓN MAYOR**

#### ✨ **Nuevas Funcionalidades**
- **🌐 Web Elements Steps**: 15 funciones para manipulación avanzada del DOM (atributos, estilos, eventos, foco)
- **📝 Form Handling Steps**: 12 funciones para manejo completo de formularios (validación, auto-llenado, extracción)
- **🌐 Browser Control Steps**: 20 funciones para control total del navegador (cookies, storage, JavaScript, viewport)
- **🗄️ Database Steps**: 12 funciones para testing de bases de datos SQLite (conexiones, consultas, validaciones)
- **📧 Email Steps**: 12 funciones para testing de email (SMTP, IMAP, verificación, extracción de códigos)
- **🔧 API Testing Expandido**: 40 funciones adicionales para testing completo de APIs REST

#### 🔧 **Mejoras Técnicas**
- **498 funciones únicas** implementadas (99.6% de la meta de 500)
- **1111 variantes lingüísticas** (inglés/español) - ¡Meta de 1000+ SUPERADA!
- **34 módulos especializados** para máxima organización
- Cobertura completa de testing moderno: DOM, formularios, navegador, datos, comunicaciones
- Arquitectura modular mejorada para fácil extensión

#### 📁 **Archivos Nuevos**
- `hakalab_framework/steps/web_elements_steps.py` - Manipulación del DOM
- `hakalab_framework/steps/form_handling_steps.py` - Manejo de formularios
- `hakalab_framework/steps/browser_control_steps.py` - Control del navegador
- `hakalab_framework/steps/database_steps.py` - Testing de bases de datos
- `hakalab_framework/steps/email_steps.py` - Testing de email

#### 📝 **Archivos Mejorados**
- `hakalab_framework/steps/api_testing_steps.py` - **Expandido significativamente** (40 funciones adicionales)

### **v1.2.14** - 2026-01-06 ⭐ **VERSIÓN ANTERIOR**

#### ✨ **Funcionalidades Previas**
- **📊 Manejo Avanzado de CSV**: 15+ steps para procesamiento completo de archivos CSV
- **🔤 Variables Dinámicas**: 20+ steps para generación y manipulación automática de variables
- **⏱️ Control de Tiempos**: 15+ steps para cronómetros, esperas inteligentes y medición de rendimiento
- **⌨️ Entrada Avanzada**: 25+ steps para simulación de escritura humana y manipulación sofisticada de texto
- **🎯 Drag & Drop Mejorado**: Sistema completamente rediseñado con múltiples métodos de fallback

## 📖 **Documentación Completa**

### 📖 **Guías Disponibles**
- **[GUIA_COMPLETA_STEPS.md](GUIA_COMPLETA_STEPS.md)** - Referencia completa de todos los steps (300+)
- **[FUNCIONALIDADES_AVANZADAS_v1.2.14.md](FUNCIONALIDADES_AVANZADAS_v1.2.14.md)** - Nuevas funcionalidades detalladas
- **[GUIA_INSTALACION.md](GUIA_INSTALACION.md)** - Guía detallada de instalación
- **[STEPS_AVANZADOS.md](STEPS_AVANZADOS.md)** - Steps avanzados y casos de uso
- **[STEPS_SALESFORCE.md](STEPS_SALESFORCE.md)** - Automatización específica de Salesforce
- **[VARIABLES_ENTORNO.md](VARIABLES_ENTORNO.md)** - Configuración de variables de entorno
- **[GUIA_STEPS_PERSONALIZADOS.md](GUIA_STEPS_PERSONALIZADOS.md)** - Crear steps personalizados

### 🎬 **Ejemplos Prácticos**
- **features/advanced_features_demo.feature** - Demostración de funcionalidades avanzadas
- **features/csv_handling_demo.feature** - Ejemplos de procesamiento CSV
- **features/example_login.feature** - Login básico
- **features/example_forms.feature** - Formularios complejos

## 🤝 **Contribuir**

### Proceso de Contribución
1. Fork el proyecto
2. Crea una rama para tu feature (`git checkout -b feature/nueva-funcionalidad`)
3. Commit tus cambios (`git commit -am 'Agregar nueva funcionalidad'`)
4. Push a la rama (`git push origin feature/nueva-funcionalidad`)
5. Crea un Pull Request

### Desarrollo Local
```bash
git clone https://github.com/pipefariashaka/hakalab-framework.git
cd hakalab-framework
pip install -e .
python -m pytest tests/
behave features/
```

## 📄 **Licencia**

Este proyecto está bajo la Licencia MIT - ver el archivo [LICENSE](LICENSE) para detalles.

## 🚀 **¡Comienza Ahora!**

```bash
# Instalación rápida
pip install git+https://github.com/pipefariashaka/hakalab-framework.git
python -m playwright install

# Crear proyecto
hakalab-init mi-proyecto
cd mi-proyecto

# Ejecutar primera prueba
behave
```

**El Hakalab Framework está listo para llevar tus pruebas automatizadas al siguiente nivel!**

Con **485 funciones únicas** que se expanden a **1072 variantes lingüísticas**, simulación de comportamiento humano, procesamiento de CSV, cronómetros de rendimiento, variables dinámicas, **drag & drop mejorado**, manipulación completa del DOM, manejo avanzado de formularios, control total del navegador, testing de bases de datos y comunicaciones por email, tienes todo lo necesario para crear automatizaciones de nivel empresarial.

### 🎉 **Logros Históricos v1.3.0**
- ✅ **485 funciones únicas** (97% de la meta de 500)
- ✅ **1072 variantes lingüísticas** - ¡Meta de 1000+ SUPERADA!
- ✅ **34 módulos especializados** para máxima organización
- ✅ **6 nuevas categorías** de testing avanzado
- ✅ **Cobertura completa** de testing moderno
- ✅ **Proyecto limpio** - Duplicados eliminados para máxima estabilidad