# Ejemplo de Testing con Gemini usando Documentos Técnicos como Contexto
# ========================================================================

Feature: Validar Documentación Técnica Generada por IA

  # ============================================================================
  # EJEMPLO 1: Validar Documentación de API Generada
  # ============================================================================
  
  Background:
    Given el contexto de reglas de negocio "api_spec" está cargado desde el archivo "context/api_specification_example.txt"

  Scenario: Validar documentación básica del endpoint POST /orders
    When establezco la respuesta del SUT como "Para crear una orden, envía un POST a /api/v2/orders con customer_id (UUID), items (array con product_id, quantity, price), shipping_address (street, city, postal_code, country) y payment_method. Recibirás un order_id, status y total en la respuesta."
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.85
    And guardo la evaluación del Juez en el archivo "evaluations/api_docs_basic.json"

  Scenario: Validar documentación completa con validaciones
    When establezco la respuesta del SUT como "El endpoint POST /api/v2/orders crea una nueva orden. Requiere autenticación Bearer Token. El customer_id debe existir en la base de datos. Cada product_id debe estar disponible y la quantity no puede exceder el stock. El price debe coincidir con el precio actual del producto. La respuesta incluye order_id, status (pending/confirmed/processing), total calculado y estimated_delivery."
    Then el Juez Gemini debe validar la respuesta con criterios personalizados "menciona autenticación,incluye validaciones principales,describe respuesta completa" y umbral 0.9
    And guardo la evaluación del Juez en el archivo "evaluations/api_docs_complete.json"

  Scenario: Validar documentación de códigos de error
    When establezco la respuesta del SUT como "Los códigos de error incluyen: invalid_customer (cliente no existe), invalid_product (producto no disponible), insufficient_stock (sin stock suficiente), price_mismatch (precio no coincide), invalid_address (dirección inválida). Todos retornan 400 Bad Request excepto invalid_customer que puede retornar 404."
    Then el Juez Gemini debe validar la respuesta con criterios personalizados "menciona códigos de error principales,explica significado,menciona códigos HTTP" y umbral 0.85

  Scenario: Validar documentación incompleta (debe fallar)
    When establezco la respuesta del SUT como "Envía un POST a /api/orders con los datos del cliente y recibirás una confirmación."
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.8
    # Este test debería fallar porque la documentación es muy vaga

  # ============================================================================
  # EJEMPLO 2: Validar Ejemplos de Uso Generados
  # ============================================================================

  Scenario: Validar ejemplo de request correcto
    When establezco la respuesta del SUT como "Ejemplo de request: POST /api/v2/orders con Authorization Bearer token. Body: {customer_id: 'uuid', items: [{product_id: 'uuid', quantity: 2, price: 29.99}], shipping_address: {street: '123 Main St', city: 'New York', state: 'NY', postal_code: '10001', country: 'US'}, payment_method: 'credit_card'}"
    Then el Juez Gemini debe validar la respuesta con criterios personalizados "ejemplo sintácticamente correcto,incluye campos requeridos,usa formatos correctos" y umbral 0.85

  Scenario: Validar explicación de cálculos
    When establezco la respuesta del SUT como "El total se calcula así: subtotal = suma de (precio × cantidad) de todos los items, tax = subtotal × tasa de impuesto del país, shipping_cost = calculado según peso y destino, total = subtotal + tax + shipping_cost."
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.9

  # ============================================================================
  # EJEMPLO 3: Validar Respuestas de Soporte Técnico
  # ============================================================================

  Scenario: Validar respuesta sobre error de validación
    When establezco la respuesta del SUT como "El error 'price_mismatch' ocurre cuando el precio enviado no coincide con el precio actual del producto en la base de datos. Verifica que estás usando el precio más reciente. Hay una tolerancia de ±0.01 para diferencias de redondeo."
    Then el Juez Gemini debe validar la respuesta con criterios personalizados "explica causa del error,ofrece solución,menciona tolerancia" y umbral 0.85

  Scenario: Validar respuesta sobre autenticación
    When establezco la respuesta del SUT como "Para autenticarte, incluye el header 'Authorization: Bearer tu_token'. Si recibes 401 Unauthorized, verifica que el token es válido y no ha expirado."
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.85

  # ============================================================================
  # EJEMPLO 4: Validar Traducciones Técnicas
  # ============================================================================

  Scenario: Validar traducción al español de documentación
    When establezco la respuesta del SUT como "Para crear un pedido, envía una petición POST a /api/v2/orders con customer_id (UUID del cliente), items (array de productos con product_id, quantity y price), shipping_address (dirección de envío con street, city, postal_code y country) y payment_method (método de pago). La respuesta incluirá order_id, status y total."
    Then el Juez Gemini debe validar la respuesta con criterios personalizados "traducción precisa,mantiene términos técnicos correctos,no pierde información" y umbral 0.85

  # ============================================================================
  # EJEMPLO 5: Validar Documentación de Seguridad
  # ============================================================================

  Scenario: Validar documentación de rate limiting
    When establezco la respuesta del SUT como "El API tiene límites de tasa: 100 requests por minuto y 1000 requests por hora por cliente. Si excedes el límite, recibirás un error 429 Too Many Requests. Implementa exponential backoff en tu cliente."
    Then el Juez Gemini debe validar la respuesta con criterios personalizados "menciona límites correctos,explica código de error,sugiere solución" y umbral 0.85

  # ============================================================================
  # EJEMPLO 6: Validar Documentación de Migración
  # ============================================================================

  Scenario: Validar guía de migración de v1 a v2
    When establezco la respuesta del SUT como "Cambios en v2.0: Se agregó el campo opcional 'notes' al request. La respuesta ahora incluye 'estimated_delivery'. La validación de direcciones es más estricta. Se agregó soporte para más países. La v1.0 será deprecada el 2026-06-01."
    Then el Juez Gemini debe validar la respuesta con criterios personalizados "menciona cambios principales,incluye fecha de deprecación,explica breaking changes" y umbral 0.85

  # ============================================================================
  # EJEMPLO 7: Validar Documentación desde Archivo
  # ============================================================================

  Scenario: Validar documentación extensa desde archivo
    When cargo la respuesta del SUT desde el archivo "responses/api_documentation_generated.txt"
    Then el Juez Gemini debe validar la respuesta con criterios personalizados "completa,precisa,incluye ejemplos,menciona validaciones" y umbral 0.9
    And guardo la evaluación del Juez en el archivo "evaluations/api_docs_full_eval.json"
    And el score de la última evaluación debe ser mayor o igual a 0.9

# ============================================================================
# NOTAS DE USO
# ============================================================================

# Este ejemplo demuestra cómo usar documentos técnicos como contexto para:
# 1. Validar documentación de APIs generada por IA
# 2. Verificar que las respuestas de soporte son técnicamente correctas
# 3. Validar traducciones técnicas
# 4. Asegurar que la documentación cumple con estándares
# 5. Validar guías de migración y cambios de versión

# El documento técnico (api_specification_example.txt) contiene:
# - Especificación completa del endpoint
# - Reglas de validación detalladas
# - Códigos de error
# - Ejemplos de uso
# - Notas importantes

# Gemini usa este contexto para evaluar si las respuestas generadas:
# - Son técnicamente precisas
# - Incluyen información importante
# - No omiten validaciones críticas
# - Usan la terminología correcta
# - Proporcionan ejemplos útiles
