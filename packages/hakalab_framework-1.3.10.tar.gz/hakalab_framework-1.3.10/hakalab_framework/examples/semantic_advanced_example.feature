# language: es
Característica: Validación Semántica Avanzada con IA
  Como tester de QA avanzado
  Quiero usar capacidades avanzadas de IA
  Para análisis de sentimiento, clasificación, detección de idioma y más

  Escenario: Análisis de sentimiento de comentarios
    Given uso la configuración semántica por defecto
    
    # Analizar sentimientos positivos
    Then el sentimiento del texto "Me encanta este producto, es excelente" debe ser "positivo"
    Then el sentimiento del texto "Fantástico servicio, muy recomendado" debe ser "positivo"
    
    # Analizar sentimientos negativos
    Then el sentimiento del texto "Terrible experiencia, muy decepcionado" debe ser "negativo"
    Then el sentimiento del texto "Pésimo servicio, no lo recomiendo" debe ser "negativo"
    
    # Analizar sentimientos neutrales
    Then el sentimiento del texto "El producto es normal, nada especial" debe ser "neutral"

  Escenario: Análisis de sentimiento de variables
    Given uso la configuración semántica por defecto
    And guardo "El servicio fue excelente y el personal muy amable" en la variable "comentario"
    
    Then el sentimiento de la variable "comentario" debe ser "positivo"

  Escenario: Clasificación de mensajes de sistema
    Given uso la configuración semántica por defecto
    
    # Clasificar diferentes tipos de mensajes
    Then el texto "No se pudo conectar al servidor" debe pertenecer a la categoría "error" de "error,éxito,advertencia,información"
    Then el texto "Operación completada exitosamente" debe pertenecer a la categoría "éxito" de "error,éxito,advertencia,información"
    Then el texto "Ten cuidado con esta acción" debe pertenecer a la categoría "advertencia" de "error,éxito,advertencia,información"
    Then el texto "El sistema está funcionando normalmente" debe pertenecer a la categoría "información" de "error,éxito,advertencia,información"

  Escenario: Clasificación y almacenamiento
    Given uso la configuración semántica por defecto
    
    # Clasificar y guardar resultado
    Then clasifico el texto "Error al procesar el pago" en las categorías "error,éxito,advertencia" y guardo el resultado en "tipo_mensaje"
    
    # Usar la clasificación
    Then muestro en consola el valor de la variable "tipo_mensaje"
    Then muestro en consola el valor de la variable "tipo_mensaje_confidence"

  Escenario: Detección de idioma
    Given uso la configuración semántica por defecto
    
    # Detectar diferentes idiomas
    Then el idioma del texto "Hello, how are you today?" debe ser "inglés"
    Then el idioma del texto "Hola, ¿cómo estás hoy?" debe ser "español"
    Then el idioma del texto "Olá, como você está hoje?" debe ser "portugués"
    Then el idioma del texto "Bonjour, comment allez-vous?" debe ser "francés"
    Then el idioma del texto "Hallo, wie geht es dir?" debe ser "alemán"

  Escenario: Detección y almacenamiento de idioma
    Given uso la configuración semántica por defecto
    And guardo "Good morning, have a nice day" en la variable "mensaje"
    
    # Detectar idioma de variable
    When extraigo el texto de la variable "mensaje" y lo guardo en "texto_mensaje"
    Then detecto el idioma del texto "${texto_mensaje}" y lo guardo en "idioma_detectado"
    
    # Verificar resultado
    Then muestro en consola el valor de la variable "idioma_detectado"

  Escenario: Búsqueda semántica en lista de opciones
    Given uso la configuración semántica por defecto
    
    # Buscar la opción más similar
    Then busco el texto más similar a "problema de conexión" en la lista "error de red,fallo de autenticación,problema de servidor,datos incorrectos" y lo guardo en "error_similar"
    
    # Verificar resultado
    Then muestro en consola el valor de la variable "error_similar"
    Then muestro en consola el valor de la variable "error_similar_similarity"

  Escenario: Comparación múltiple de textos
    Given uso la configuración semántica por defecto
    
    # Comparar un texto con múltiples referencias
    Then comparo el texto "Error al procesar la solicitud" con múltiples referencias "error de red,problema de servidor,fallo de autenticación,datos inválidos" y muestro las similitudes

  Escenario: Flujo completo de análisis de feedback
    Given navego a "https://example.com/feedback"
    And uso la configuración semántica por defecto
    
    # Extraer comentario del usuario
    When extraigo el texto del elemento "Comentario" con identificador "$.FEEDBACK.comment" y lo guardo en "comentario_usuario"
    
    # Analizar sentimiento
    Then el sentimiento de la variable "comentario_usuario" debe ser "positivo"
    
    # Detectar idioma
    Then detecto el idioma del texto "${comentario_usuario}" y lo guardo en "idioma_comentario"
    
    # Clasificar tipo de feedback
    Then clasifico el texto "${comentario_usuario}" en las categorías "producto,servicio,precio,entrega" y guardo el resultado en "categoria_feedback"
    
    # Mostrar resultados
    Then muestro en consola el valor de la variable "idioma_comentario"
    Then muestro en consola el valor de la variable "categoria_feedback"

  Escenario: Validación de respuestas de chatbot con sentimiento
    Given navego a "https://example.com/chat"
    And uso la configuración semántica por defecto
    
    # Usuario hace una pregunta
    When escribo "Estoy muy molesto con el servicio" en el chat
    And espero 3 segundos
    
    # Extraer respuesta del bot
    And extraigo el texto del elemento "Respuesta Bot" con identificador "$.CHAT.bot_response" y lo guardo en "respuesta_bot"
    
    # Verificar que la respuesta sea empática (sentimiento positivo/neutral)
    Then el sentimiento de la variable "respuesta_bot" debe ser "positivo"
    
    # Verificar que la respuesta sea relevante
    Then el texto de la variable "respuesta_bot" debe ser semánticamente similar a "Lamento que hayas tenido una mala experiencia, déjame ayudarte"

  Escenario: Clasificación de tickets de soporte
    Given uso la configuración semántica por defecto
    
    # Simular diferentes tickets
    And guardo "No puedo acceder a mi cuenta" en la variable "ticket1"
    And guardo "El producto llegó dañado" en la variable "ticket2"
    And guardo "¿Cómo puedo cambiar mi contraseña?" en la variable "ticket3"
    
    # Clasificar cada ticket
    Then clasifico el texto "${ticket1}" en las categorías "técnico,producto,cuenta,consulta" y guardo el resultado en "tipo_ticket1"
    Then clasifico el texto "${ticket2}" en las categorías "técnico,producto,cuenta,consulta" y guardo el resultado en "tipo_ticket2"
    Then clasifico el texto "${ticket3}" en las categorías "técnico,producto,cuenta,consulta" y guardo el resultado en "tipo_ticket3"
    
    # Mostrar clasificaciones
    Then muestro en consola el valor de la variable "tipo_ticket1"
    Then muestro en consola el valor de la variable "tipo_ticket2"
    Then muestro en consola el valor de la variable "tipo_ticket3"

  Escenario: Análisis multilingüe de feedback
    Given configuro el modelo semántico como "paraphrase-multilingual-MiniLM-L12-v2"
    And establezco el umbral de similitud semántica en 0.70
    
    # Analizar feedback en diferentes idiomas
    Then el sentimiento del texto "This product is amazing!" debe ser "positivo"
    Then el sentimiento del texto "Este producto es increíble!" debe ser "positivo"
    Then el sentimiento del texto "Este produto é incrível!" debe ser "positivo"
    
    # Verificar que todos tengan el mismo sentimiento
    Then el texto "This product is amazing!" debe ser semánticamente similar a "Este producto es increíble!"

  Escenario: Búsqueda de FAQ más relevante
    Given uso la configuración semántica por defecto
    And guardo "¿Cómo puedo resetear mi contraseña?" en la variable "pregunta_usuario"
    
    # Buscar la FAQ más similar
    Then busco el texto más similar a "${pregunta_usuario}" en la lista "Cambiar contraseña,Recuperar cuenta,Actualizar perfil,Eliminar cuenta" y lo guardo en "faq_relevante"
    
    # Verificar que encontró la correcta
    Then muestro en consola el valor de la variable "faq_relevante"
