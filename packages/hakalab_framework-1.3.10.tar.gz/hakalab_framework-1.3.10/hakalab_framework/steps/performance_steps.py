#!/usr/bin/env python3
"""
Steps para validaciones de rendimiento y timing
Incluye medición de tiempos de carga, respuesta y rendimiento
"""
import time
from datetime import datetime
from behave import step

@step('I verify page loads in less than "{max_seconds}" seconds')
@step('verifico que la página carga en menos de "{max_seconds}" segundos')
def step_verify_page_load_time(context, max_seconds):
    """Verifica que la página carga en un tiempo específico"""
    max_time = float(max_seconds)
    
    start_time = time.time()
    context.page.wait_for_load_state('networkidle')
    end_time = time.time()
    
    load_time = end_time - start_time
    assert load_time <= max_time, f"Página cargó en {load_time:.2f}s, máximo permitido {max_time}s"

@step('I verify element "{element_name}" appears in less than "{max_seconds}" seconds with identifier "{identifier}"')
@step('verifico que el elemento "{element_name}" aparece en menos de "{max_seconds}" segundos con identificador "{identifier}"')
def step_verify_element_appears_time(context, element_name, max_seconds, identifier):
    """Verifica que un elemento aparece en un tiempo específico"""
    locator = context.element_locator.get_locator(identifier)
    max_time = float(max_seconds) * 1000  # Convertir a milisegundos
    
    start_time = time.time()
    try:
        context.page.wait_for_selector(locator, state='visible', timeout=max_time)
        end_time = time.time()
        actual_time = end_time - start_time
        print(f"✅ Elemento '{element_name}' apareció en {actual_time:.2f}s")
    except Exception:
        raise AssertionError(f"Elemento '{element_name}' no apareció en {max_seconds}s")

@step('I verify click response time on element "{element_name}" is less than "{max_seconds}" seconds with identifier "{identifier}"')
@step('verifico que el tiempo de respuesta del click en elemento "{element_name}" es menor a "{max_seconds}" segundos con identificador "{identifier}"')
def step_verify_click_response_time(context, element_name, max_seconds, identifier):
    """Verifica que la respuesta a un click es rápida"""
    locator = context.element_locator.get_locator(identifier)
    max_time = float(max_seconds)
    
    start_time = time.time()
    context.page.locator(locator).click()
    
    # Esperar a que haya algún cambio (puede ser personalizado según necesidad)
    context.page.wait_for_load_state('networkidle', timeout=max_time * 1000)
    end_time = time.time()
    
    response_time = end_time - start_time
    assert response_time <= max_time, f"Tiempo de respuesta fue {response_time:.2f}s, máximo permitido {max_time}s"

@step('I measure and store page load time in variable "{variable_name}"')
@step('mido y guardo el tiempo de carga de página en la variable "{variable_name}"')
def step_measure_page_load_time(context, variable_name):
    """Mide el tiempo de carga de página y lo guarda en una variable"""
    start_time = time.time()
    context.page.wait_for_load_state('networkidle')
    end_time = time.time()
    
    load_time = round(end_time - start_time, 2)
    context.variable_manager.set_variable(variable_name, load_time)
    print(f"⏱️ Tiempo de carga medido: {load_time}s → variable '{variable_name}'")

@step('I verify network requests complete in less than "{max_seconds}" seconds')
@step('verifico que las peticiones de red se completan en menos de "{max_seconds}" segundos')
def step_verify_network_requests_time(context, max_seconds):
    """Verifica que todas las peticiones de red se completan en tiempo específico"""
    max_time = float(max_seconds) * 1000
    
    start_time = time.time()
    context.page.wait_for_load_state('networkidle', timeout=max_time)
    end_time = time.time()
    
    network_time = end_time - start_time
    max_time_seconds = max_time / 1000
    assert network_time <= max_time_seconds, f"Peticiones de red tardaron {network_time:.2f}s, máximo {max_time_seconds}s"

@step('I verify form submission response time is less than "{max_seconds}" seconds')
@step('verifico que el tiempo de respuesta del envío de formulario es menor a "{max_seconds}" segundos')
def step_verify_form_submission_time(context, max_seconds):
    """Verifica que el envío de formulario responde en tiempo específico"""
    max_time = float(max_seconds)
    
    # Buscar y hacer click en botón de envío
    submit_selectors = [
        'button[type="submit"]',
        'input[type="submit"]',
        'button:has-text("Submit")',
        'button:has-text("Enviar")'
    ]
    
    start_time = time.time()
    
    for selector in submit_selectors:
        submit_button = context.page.locator(selector)
        if submit_button.count() > 0:
            submit_button.first.click()
            break
    
    # Esperar respuesta
    context.page.wait_for_load_state('networkidle', timeout=max_time * 1000)
    end_time = time.time()
    
    submission_time = end_time - start_time
    assert submission_time <= max_time, f"Envío de formulario tardó {submission_time:.2f}s, máximo {max_time}s"

@step('I verify search results appear in less than "{max_seconds}" seconds')
@step('verifico que los resultados de búsqueda aparecen en menos de "{max_seconds}" segundos')
def step_verify_search_results_time(context, max_seconds):
    """Verifica que los resultados de búsqueda aparecen rápidamente"""
    max_time = float(max_seconds) * 1000
    
    # Buscar contenedor de resultados común
    results_selectors = [
        '.search-results',
        '.results',
        '#search-results',
        '[data-testid="search-results"]',
        '.result-list'
    ]
    
    start_time = time.time()
    
    for selector in results_selectors:
        try:
            context.page.wait_for_selector(selector, state='visible', timeout=max_time)
            end_time = time.time()
            search_time = end_time - start_time
            print(f"✅ Resultados de búsqueda aparecieron en {search_time:.2f}s")
            return
        except:
            continue
    
    raise AssertionError(f"Resultados de búsqueda no aparecieron en {max_seconds}s")

@step('I verify image "{image_name}" loads in less than "{max_seconds}" seconds with identifier "{identifier}"')
@step('verifico que la imagen "{image_name}" carga en menos de "{max_seconds}" segundos con identificador "{identifier}"')
def step_verify_image_load_time(context, image_name, max_seconds, identifier):
    """Verifica que una imagen carga en tiempo específico"""
    locator = context.element_locator.get_locator(identifier)
    max_time = float(max_seconds) * 1000
    
    start_time = time.time()
    
    # Esperar a que la imagen esté completamente cargada
    context.page.wait_for_function(f"""
        () => {{
            const img = document.querySelector('{locator}');
            return img && img.complete && img.naturalHeight !== 0;
        }}
    """, timeout=max_time)
    
    end_time = time.time()
    load_time = end_time - start_time
    max_time_seconds = max_time / 1000
    
    assert load_time <= max_time_seconds, f"Imagen '{image_name}' cargó en {load_time:.2f}s, máximo {max_time_seconds}s"

@step('I verify animation completes in less than "{max_seconds}" seconds on element "{element_name}" with identifier "{identifier}"')
@step('verifico que la animación se completa en menos de "{max_seconds}" segundos en elemento "{element_name}" con identificador "{identifier}"')
def step_verify_animation_time(context, max_seconds, element_name, identifier):
    """Verifica que una animación se completa en tiempo específico"""
    locator = context.element_locator.get_locator(identifier)
    max_time = float(max_seconds) * 1000
    
    start_time = time.time()
    
    # Esperar a que termine la animación (no hay transiciones activas)
    context.page.wait_for_function(f"""
        () => {{
            const element = document.querySelector('{locator}');
            if (!element) return false;
            
            const computedStyle = getComputedStyle(element);
            const transition = computedStyle.transition;
            const animation = computedStyle.animation;
            
            return transition === 'none' || transition === '' || 
                   animation === 'none' || animation === '';
        }}
    """, timeout=max_time)
    
    end_time = time.time()
    animation_time = end_time - start_time
    max_time_seconds = max_time / 1000
    
    assert animation_time <= max_time_seconds, f"Animación tardó {animation_time:.2f}s, máximo {max_time_seconds}s"

@step('I verify modal "{modal_name}" opens in less than "{max_seconds}" seconds with identifier "{identifier}"')
@step('verifico que el modal "{modal_name}" se abre en menos de "{max_seconds}" segundos con identificador "{identifier}"')
def step_verify_modal_open_time(context, modal_name, max_seconds, identifier):
    """Verifica que un modal se abre en tiempo específico"""
    locator = context.element_locator.get_locator(identifier)
    max_time = float(max_seconds) * 1000
    
    start_time = time.time()
    context.page.wait_for_selector(locator, state='visible', timeout=max_time)
    end_time = time.time()
    
    open_time = end_time - start_time
    max_time_seconds = max_time / 1000
    
    assert open_time <= max_time_seconds, f"Modal '{modal_name}' se abrió en {open_time:.2f}s, máximo {max_time_seconds}s"

@step('I verify dropdown "{dropdown_name}" expands in less than "{max_seconds}" seconds with identifier "{identifier}"')
@step('verifico que el dropdown "{dropdown_name}" se expande en menos de "{max_seconds}" segundos con identificador "{identifier}"')
def step_verify_dropdown_expand_time(context, dropdown_name, max_seconds, identifier):
    """Verifica que un dropdown se expande en tiempo específico"""
    locator = context.element_locator.get_locator(identifier)
    max_time = float(max_seconds)
    
    # Hacer click para expandir
    start_time = time.time()
    context.page.locator(locator).click()
    
    # Esperar a que aparezcan las opciones
    options_selectors = [
        f'{locator} option',
        f'{locator} .option',
        f'{locator} li',
        '.dropdown-menu',
        '.dropdown-options'
    ]
    
    for selector in options_selectors:
        try:
            context.page.wait_for_selector(selector, state='visible', timeout=max_time * 1000)
            end_time = time.time()
            expand_time = end_time - start_time
            
            assert expand_time <= max_time, f"Dropdown '{dropdown_name}' se expandió en {expand_time:.2f}s, máximo {max_time}s"
            return
        except:
            continue
    
    raise AssertionError(f"Dropdown '{dropdown_name}' no se expandió en {max_seconds}s")

@step('I verify page scroll performance is smooth')
@step('verifico que el rendimiento del scroll de página es suave')
def step_verify_scroll_performance(context):
    """Verifica que el scroll de la página es suave y sin lag"""
    # Realizar scroll y medir el tiempo
    start_time = time.time()
    
    # Scroll hacia abajo
    context.page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
    context.page.wait_for_timeout(100)  # Pequeña pausa
    
    # Scroll hacia arriba
    context.page.evaluate("window.scrollTo(0, 0)")
    context.page.wait_for_timeout(100)
    
    end_time = time.time()
    scroll_time = end_time - start_time
    
    # El scroll debería ser rápido (menos de 1 segundo para scroll completo)
    assert scroll_time <= 1.0, f"Scroll tardó {scroll_time:.2f}s, debería ser más rápido"

@step('I verify memory usage is acceptable after "{actions_count}" actions')
@step('verifico que el uso de memoria es aceptable después de "{actions_count}" acciones')
def step_verify_memory_usage(context, actions_count):
    """Verifica que el uso de memoria del navegador es aceptable"""
    actions = int(actions_count)
    
    # Obtener información de memoria del navegador
    memory_info = context.page.evaluate("""
        () => {
            if (performance.memory) {
                return {
                    used: performance.memory.usedJSHeapSize,
                    total: performance.memory.totalJSHeapSize,
                    limit: performance.memory.jsHeapSizeLimit
                };
            }
            return null;
        }
    """)
    
    if memory_info:
        used_mb = memory_info['used'] / (1024 * 1024)
        total_mb = memory_info['total'] / (1024 * 1024)
        
        # Verificar que no se use más del 80% de la memoria disponible
        usage_percentage = (used_mb / total_mb) * 100
        
        assert usage_percentage <= 80, f"Uso de memoria muy alto: {usage_percentage:.1f}% ({used_mb:.1f}MB de {total_mb:.1f}MB)"
        print(f"✅ Uso de memoria aceptable: {usage_percentage:.1f}% después de {actions} acciones")
    else:
        print("⚠️ Información de memoria no disponible en este navegador")