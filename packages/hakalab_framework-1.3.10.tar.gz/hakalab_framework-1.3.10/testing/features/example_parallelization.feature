@PROD-145
Feature: Ejemplo de Paralelización

  @PROD-91 @Haka-Demo
  Scenario Outline: Navegación básica 1
    Given voy a la url "https://example.com"
    And espero 1 segundo
    
  Examples:
    | nombre        | mail                      |
    | Felipe Farias | felipe.farias@example.com |
    | Juanito perez | juani.perez@example.com   |

  @PROD-92 @Haka-Demo
  Scenario Outline: Navegación básica 2
    Given voy a la url "https://example.com"
    And espero 1 segundo
    
  Examples:
    | nombre        | mail                      |
    | Felipe Farias | felipe.farias@example.com |
    | Juanito perez | juani.perez@example.com   |

  @PROD-93 @Haka-Demo
  Scenario Outline: Navegación básica 3
    Given voy a la url "https://example.com"
    And espero 1 segundo
    
  Examples:
    | nombre        | mail                      |
    | Felipe Farias | felipe.farias@example.com |
    | Juanito perez | juani.perez@example.com   |
