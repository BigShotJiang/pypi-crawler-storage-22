Feature: Manejo de Alertas y Diálogos

  Background:
    Given voy a la url "https://example.com"

  @alert-accept
  Scenario: Aceptar una alerta simple
    When hago click en el botón "Mostrar alerta"
    Then acepto la alerta
    And debería ver el elemento "mensaje de confirmación" con identificador "$.SELECTORS.confirmation"

  @alert-reject
  Scenario: Rechazar una confirmación
    When hago click en el botón "Confirmar acción"
    Then rechazo la alerta
    And debería ver el elemento "mensaje de rechazo" con identificador "$.SELECTORS.rejection_message"

  @alert-prompt
  Scenario: Responder a un prompt
    When hago click en el botón "Solicitar nombre"
    Then acepto la alerta con texto "Juan Pérez"
    And debería ver el elemento "nombre mostrado" con identificador "$.SELECTORS.displayed_name"

  @alert-capture
  Scenario: Capturar mensaje de alerta
    When hago click en el botón "Mostrar mensaje"
    Then obtengo el texto de la alerta y lo guardo en la variable "alert_message"
    And verifico que la variable "alert_message" contiene "éxito"

  @alert-verify-exact
  Scenario: Verificar mensaje exacto de alerta
    When hago click en el botón "Validar datos"
    Then el mensaje de la alerta debería ser "Datos validados correctamente"

  @alert-verify-contains
  Scenario: Verificar que alerta contiene texto
    When hago click en el botón "Procesar"
    Then el mensaje de la alerta debería contener "completado"
    And acepto la alerta

  @alert-store
  Scenario: Guardar mensaje de alerta en variable
    When hago click en el botón "Obtener código"
    Then guardo el mensaje de la alerta en la variable "codigo"
    And verifico que la variable "codigo" no está vacía

  @alert-extract-and-close
  Scenario: Extraer texto del diálogo y cerrarlo
    When hago click en el botón "Validar fecha"
    Then extraigo el texto del diálogo lo guardo en la variable "error_message" y cierro el diálogo
    And verifico que la variable "error_message" contiene "error"
    And debería ver el elemento "formulario" con identificador "$.SELECTORS.form"
