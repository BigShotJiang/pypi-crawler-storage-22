@database @test
Feature: Funcionalidad de Base de Datos del Framework
  Como usuario del framework
  Quiero conectarme y consultar bases de datos
  Para automatizar pruebas que requieren validación de datos

  Background:
    Given me conecto a la base de datos usando configuración del entorno
    And creo base de datos de prueba con datos de ejemplo

  @smoke @database_basic
  Scenario: Consulta básica de usuarios
    When ejecuto la consulta SQL "SELECT * FROM users" y guardo el resultado en la variable "usuarios"
    Then verifico que el resultado de la consulta SQL tiene "3" filas
    And verifico que el resultado SQL contiene una fila con "name" igual a "Juan Pérez"

  @database_advanced
  Scenario: Insertar y validar nuevo usuario
    When ejecuto la actualización SQL "INSERT INTO users (name, email, age) VALUES ('Ana Martín', 'ana@example.com', 28)"
    And ejecuto la consulta SQL "SELECT * FROM users WHERE email = 'ana@example.com'" y guardo el resultado en la variable "nuevo_usuario"
    Then verifico que el resultado de la consulta SQL tiene "1" filas
    And obtengo el valor del resultado SQL de la columna "name" fila "0" y lo guardo en la variable "nombre_usuario"
    And la variable "nombre_usuario" debería ser "Ana Martín"

  @database_products
  Scenario: Consultar productos en stock
    When ejecuto la consulta SQL "SELECT * FROM products WHERE in_stock = 1" y guardo el resultado en la variable "productos_stock"
    Then verifico que el resultado de la consulta SQL tiene "2" filas
    And verifico que el resultado SQL contiene una fila con "name" igual a "Laptop"
    And verifico que el resultado SQL contiene una fila con "name" igual a "Mouse"

  @database_cleanup
  Scenario: Backup y limpieza
    When hago backup de la base de datos al archivo "test_backup.sql"
    Then cierro la conexión a la base de datos