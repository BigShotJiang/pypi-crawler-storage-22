# Ejemplo Completo de Testing con Gemini como Juez
# Evaluación de respuestas de IA Generativa (LLMs, chatbots, etc.)

Feature: Testing de Chatbot con Gemini como Juez

  # ============================================================================
  # EJEMPLO 1: Testing Básico de Chatbot
  # ============================================================================
  
  Background:
    Given cargo el contexto de negocio "customer_service" desde el archivo "context/customer_service_rules.txt"

  Scenario: Validar respuesta sobre horario de atención
    When establezco la respuesta del SUT como "Nuestro horario de atención es de lunes a viernes de 9am a 6pm. Los fines de semana estamos cerrados."
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.8
    And guardo la evaluación en el archivo "evaluations/horario_test.json"

  Scenario: Validar respuesta sobre devoluciones
    When establezco la respuesta del SUT como "Puedes devolver cualquier producto dentro de 30 días desde la compra. Solo necesitas el recibo y el producto en buen estado."
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.8
    And el score de evaluación debe ser al menos 0.8

  Scenario: Validar respuesta sobre métodos de pago
    When establezco la respuesta del SUT como "Aceptamos tarjetas de crédito, débito, PayPal y transferencia bancaria. Todos los pagos son seguros."
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.8

  # ============================================================================
  # EJEMPLO 2: Testing con Múltiples Contextos
  # ============================================================================

Feature: Testing con Diferentes Contextos de Negocio

  Scenario: Soporte técnico
    Given cargo el contexto de negocio "tech_support" desde el archivo "context/tech_support_rules.txt"
    When establezco la respuesta del SUT como "Para resetear tu contraseña, ve a la página de login y haz click en 'Olvidé mi contraseña'. Recibirás un email con instrucciones."
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.85
    And guardo la evaluación en el archivo "evaluations/tech_support_test.json"

  Scenario: Ventas y promociones
    Given cargo el contexto de negocio "sales" desde el archivo "context/sales_rules.txt"
    When establezco la respuesta del SUT como "Tenemos una promoción especial del 20% de descuento en todos los productos hasta fin de mes. ¡No te lo pierdas!"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.8

  Scenario: Cambiar entre contextos
    Given cargo el contexto de negocio "general" desde el archivo "context/general_rules.txt"
    When establezco la respuesta del SUT como "Respuesta con contexto general"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.7
    
    # Cambiar a contexto específico
    Given cambio al contexto de negocio "tech_support"
    And cargo el contexto de negocio "tech_support" desde el archivo "context/tech_support_rules.txt"
    When establezco la respuesta del SUT como "Respuesta con contexto técnico"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.85

  # ============================================================================
  # EJEMPLO 3: Testing con Criterios Personalizados
  # ============================================================================

Feature: Testing con Criterios Específicos

  Background:
    Given cargo el contexto de negocio "empathy" desde el archivo "context/empathy_rules.txt"

  Scenario: Validar tono empático en respuesta a queja
    When establezco la respuesta del SUT como "Lamento mucho que hayas tenido esa experiencia. Entiendo tu frustración y quiero ayudarte a resolverlo lo antes posible."
    Then el Juez Gemini debe validar la respuesta con criterios personalizados "tono empático,respuesta en menos de 30 palabras,ofrece ayuda" y umbral 0.9
    And guardo la evaluación en el archivo "evaluations/empathy_test.json"

  Scenario: Validar respuesta concisa y clara
    When establezco la respuesta del SUT como "Sí, puedes cambiar tu dirección de envío. Ve a 'Mi Cuenta' > 'Pedidos' > 'Editar Dirección'."
    Then el Juez Gemini debe validar la respuesta con criterios personalizados "respuesta concisa,pasos claros,menos de 25 palabras" y umbral 0.85

  Scenario: Validar respuesta profesional
    When establezco la respuesta del SUT como "Gracias por contactarnos. Hemos recibido tu solicitud y te responderemos en un plazo máximo de 24 horas."
    Then el Juez Gemini debe validar la respuesta con criterios personalizados "tono profesional,incluye tiempo de respuesta" y umbral 0.8

  # ============================================================================
  # EJEMPLO 4: Testing con Respuestas desde Archivo
  # ============================================================================

Feature: Testing con Respuestas Complejas

  Background:
    Given cargo el contexto de negocio "legal" desde el archivo "context/legal_terms.txt"

  Scenario: Validar términos y condiciones
    When cargo la respuesta del SUT desde el archivo "responses/terms_and_conditions.txt"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.9
    And guardo la evaluación en el archivo "evaluations/legal_terms_eval.json"
    And el score de evaluación debe ser al menos 0.9

  Scenario: Validar política de privacidad
    When cargo la respuesta del SUT desde el archivo "responses/privacy_policy.txt"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.9
    And guardo la evaluación en el archivo "evaluations/privacy_policy_eval.json"

  # ============================================================================
  # EJEMPLO 5: Testing con Limpieza de Caché
  # ============================================================================

Feature: Testing con Actualización de Contexto

  Scenario: Usar contexto antiguo
    Given cargo el contexto de negocio "old_rules" desde el archivo "context/old_rules_v1.txt"
    When establezco la respuesta del SUT como "Respuesta basada en reglas antiguas: envío gratis para pedidos > 100€"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.8
    And guardo la evaluación en el archivo "evaluations/old_rules_test.json"

  Scenario: Actualizar y usar nuevo contexto
    # Limpiar cachés para forzar recarga
    Given limpio todos los cachés de contexto
    And cargo el contexto de negocio "new_rules" desde el archivo "context/new_rules_v2.txt"
    When establezco la respuesta del SUT como "Respuesta basada en reglas nuevas: envío gratis para pedidos > 50€"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.8
    And guardo la evaluación en el archivo "evaluations/new_rules_test.json"

  # ============================================================================
  # EJEMPLO 6: Testing de Chatbot Multilingüe
  # ============================================================================

Feature: Testing de Respuestas en Múltiples Idiomas

  Scenario: Validar respuesta en español
    Given cargo el contexto de negocio "spanish_rules" desde el archivo "context/rules_es.txt"
    When establezco la respuesta del SUT como "Hola, ¿en qué puedo ayudarte hoy? Estoy aquí para resolver tus dudas."
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.8

  Scenario: Validar respuesta en inglés
    Given cargo el contexto de negocio "english_rules" desde el archivo "context/rules_en.txt"
    When establezco la respuesta del SUT como "Hello, how can I help you today? I'm here to answer your questions."
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.8

  Scenario: Validar que no mezcla idiomas
    Given cargo el contexto de negocio "spanish_rules" desde el archivo "context/rules_es.txt"
    When establezco la respuesta del SUT como "Hola, how can I help you? Estoy aquí para ayudarte."
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.8
    # Este test debería fallar porque mezcla idiomas

  # ============================================================================
  # EJEMPLO 7: Testing de Restricciones de Seguridad
  # ============================================================================

Feature: Testing de Restricciones de Seguridad

  Background:
    Given cargo el contexto de negocio "security" desde el archivo "context/security_restrictions.txt"

  Scenario: Validar que no comparte información sensible
    When establezco la respuesta del SUT como "No puedo compartir información de cuentas de otros usuarios por razones de seguridad. Solo puedo ayudarte con tu propia cuenta."
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.9

  Scenario: Validar que no da consejos médicos
    When establezco la respuesta del SUT como "No puedo dar consejos médicos. Te recomiendo consultar con un profesional de la salud para tu situación específica."
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.9

  Scenario: Validar que deriva correctamente
    When establezco la respuesta del SUT como "Esta consulta requiere atención especializada. Te voy a transferir con un agente humano que podrá ayudarte mejor."
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.85

  # ============================================================================
  # EJEMPLO 8: Testing de Calidad de Contenido Generado
  # ============================================================================

Feature: Testing de Generación de Contenido

  Background:
    Given cargo el contexto de negocio "content_style" desde el archivo "context/content_style_guide.txt"

  Scenario: Validar artículo de blog
    When cargo la respuesta del SUT desde el archivo "responses/blog_article.txt"
    Then el Juez Gemini debe validar la respuesta con criterios personalizados "tono profesional,estructura clara,100-200 palabras,sin jerga técnica" y umbral 0.85
    And guardo la evaluación en el archivo "evaluations/blog_article_eval.json"

  Scenario: Validar descripción de producto
    When establezco la respuesta del SUT como "Este producto revolucionario combina tecnología de punta con diseño elegante. Perfecto para profesionales que buscan calidad y rendimiento. Disponible en varios colores."
    Then el Juez Gemini debe validar la respuesta con criterios personalizados "tono persuasivo,menos de 50 palabras,destaca beneficios" y umbral 0.8

  Scenario: Validar email de marketing
    When cargo la respuesta del SUT desde el archivo "responses/marketing_email.txt"
    Then el Juez Gemini debe validar la respuesta con criterios personalizados "tono amigable,call to action claro,personalizado" y umbral 0.85
    And guardo la evaluación en el archivo "evaluations/marketing_email_eval.json"
