# language: es
Característica: Validación Semántica con IA
  Como tester de QA
  Quiero validar respuestas usando similitud semántica
  Para verificar que los mensajes sean correctos sin depender de texto exacto

  Escenario: Configuración básica y validación simple
    # Configurar el modelo y umbral
    Given uso la configuración semántica por defecto
    
    # Validar similitud directa
    Then el texto "Tu solicitud fue aprobada exitosamente" debe ser semánticamente similar a "Gracias, tu solicitud fue exitosa"
    
    # Validar con variables
    Given guardo "La operación se completó correctamente" en la variable "mensaje_sistema"
    Then el texto de la variable "mensaje_sistema" debe ser semánticamente similar a "Operación exitosa"

  Escenario: Configuración personalizada con umbral estricto
    # Usar un modelo más preciso y umbral más alto
    Given configuro el modelo semántico como "paraphrase-multilingual-mpnet-base-v2"
    And establezco el umbral de similitud semántica en 0.85
    
    # Validar con umbral estricto
    Then el texto "El pago fue procesado exitosamente" debe ser semánticamente similar a "Tu pago se procesó correctamente"

  Escenario: Validación de elementos web
    Given navego a "https://example.com/success"
    And uso la configuración semántica por defecto
    
    # Validar texto de un elemento web
    Then el texto del elemento "Mensaje de éxito" con identificador "$.SUCCESS.message" debe ser semánticamente similar a "Operación completada con éxito"

  Escenario: Calcular y almacenar similitud para análisis
    Given uso la configuración semántica por defecto
    
    # Calcular similitud sin validar
    Then calculo la similitud semántica entre "Hola mundo" y "Hello world" y la guardo en "similitud_hola"
    
    # Usar la similitud calculada
    Then muestro en consola el valor de la variable "similitud_hola"

  Escenario: Validación de respuestas de API
    Given navego a "https://api.example.com"
    And uso la configuración semántica por defecto
    
    # Hacer llamada API y extraer respuesta
    When realizo una petición GET a "https://api.example.com/status"
    And guardo el valor de "response.message" en la variable "api_response"
    
    # Validar semánticamente la respuesta
    Then el texto de la variable "api_response" debe ser semánticamente similar a "Servicio operando normalmente"

  Escenario: Validación multilingüe
    Given configuro el modelo semántico como "paraphrase-multilingual-MiniLM-L12-v2"
    And establezco el umbral de similitud semántica en 0.70
    
    # Validar textos en diferentes idiomas (el modelo es multilingüe)
    Then el texto "La operación fue exitosa" debe ser semánticamente similar a "The operation was successful"
    Then el texto "Erro ao processar" debe ser semánticamente similar a "Error al procesar"

  Escenario: Diferentes niveles de umbral
    Given configuro el modelo semántico como "paraphrase-multilingual-MiniLM-L12-v2"
    
    # Umbral bajo (0.60) - Acepta similitud moderada
    And establezco el umbral de similitud semántica en 0.60
    Then el texto "El sistema está funcionando" debe ser semánticamente similar a "Todo está operativo"
    
    # Umbral medio (0.75) - Similitud alta
    And establezco el umbral de similitud semántica en 0.75
    Then el texto "Pago aprobado" debe ser semánticamente similar a "Tu pago fue aprobado exitosamente"
    
    # Umbral alto (0.90) - Textos casi idénticos
    And establezco el umbral de similitud semántica en 0.90
    Then el texto "Solicitud aprobada" debe ser semánticamente similar a "Tu solicitud fue aprobada"
