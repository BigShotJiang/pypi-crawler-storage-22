"""
Steps para evaluación de IA Generativa usando Gemini como Juez
Incluye Context Caching y RAG para optimización de tokens
"""

from behave import step
import google.generativeai as genai
from google.generativeai import caching
import json
import os
import time
from datetime import datetime, timedelta
import hashlib

# ============================================================================
# CONFIGURACIÓN Y HELPERS INTERNOS
# ============================================================================

def _get_gemini_judge(context):
    """Inicializa y retorna el modelo Gemini para juicio
    
    Usa gemini-1.5-pro-002 que soporta context caching
    """
    # Obtener API Key
    api_key = None
    if hasattr(context, 'config') and hasattr(context.config, 'userdata'):
        api_key = context.config.userdata.get('GEMINI_API_KEY')
    
    if not api_key:
        api_key = os.environ.get('GEMINI_API_KEY')
    
    if not api_key:
        raise ValueError(
            "GEMINI_API_KEY no encontrada. "
            "Configúrala en .env o en behave.ini [behave.userdata]"
        )
    
    # Configurar API
    genai.configure(api_key=api_key)
    
    # Retornar modelo configurado para juicio
    # Nota: El modelo se crea con el caché o system_instruction según corresponda
    return api_key


def _count_tokens(text, model_name="gemini-1.5-pro-002"):
    """Cuenta tokens aproximados de un texto
    
    Usa la API de Gemini para conteo preciso
    """
    try:
        model = genai.GenerativeModel(model_name)
        result = model.count_tokens(text)
        return result.total_tokens
    except Exception as e:
        # Fallback: estimación aproximada (1 token ≈ 4 caracteres)
        return len(text) // 4


def _create_cache_key(content):
    """Crea una clave única para el contenido del caché"""
    return hashlib.md5(content.encode('utf-8')).hexdigest()


def _load_context_file(file_path):
    """Carga el contenido de un archivo de contexto"""
    resolved_path = file_path
    
    try:
        with open(resolved_path, 'r', encoding='utf-8') as file:
            content = file.read()
        return content
    except FileNotFoundError:
        raise FileNotFoundError(f"Archivo de contexto no encontrado: {resolved_path}")
    except Exception as e:
        raise Exception(f"Error leyendo archivo de contexto: {e}")


# ============================================================================
# STEPS - CONFIGURACIÓN DE CONTEXTO
# ============================================================================

@step('el contexto de reglas de negocio "{context_name}" está cargado desde el archivo "{file_path}"')
@step('que el contexto de reglas de negocio "{context_name}" está cargado desde el archivo "{file_path}"')
def step_load_business_context(context, context_name, file_path):
    """Carga el contexto de reglas de negocio usando Context Caching o System Instruction
    
    Si el archivo supera 32k tokens, usa Context Caching de Gemini.
    Si es menor, lo almacena como system_instruction.
    
    Ejemplo:
        Given que el contexto de reglas de negocio "politicas_atencion" está cargado desde el archivo "contexts/politicas.txt"
    """
    resolved_path = context.variable_manager.resolve_variables(file_path)
    
    # Inicializar API Key
    api_key = _get_gemini_judge(context)
    
    # Cargar contenido del archivo
    print(f"📄 Cargando contexto desde: {resolved_path}")
    content = _load_context_file(resolved_path)
    
    # Contar tokens
    token_count = _count_tokens(content)
    print(f"📊 Tokens del contexto: {token_count}")
    
    # Inicializar estructura de contextos si no existe
    if not hasattr(context, 'genai_contexts'):
        context.genai_contexts = {}
    
    if not hasattr(context, 'genai_caches'):
        context.genai_caches = {}
    
    # Decidir estrategia según tamaño
    CACHE_THRESHOLD = 32000  # 32k tokens
    
    if token_count >= CACHE_THRESHOLD:
        # Usar Context Caching
        print(f"🔄 Usando Context Caching (tokens >= {CACHE_THRESHOLD})")
        
        # Verificar si ya existe un caché para este contenido
        cache_key = _create_cache_key(content)
        
        if cache_key in context.genai_caches:
            print(f"✓ Reutilizando caché existente: {cache_key[:8]}...")
            cached_content = context.genai_caches[cache_key]
        else:
            try:
                # Crear nuevo caché
                print(f"⏳ Creando nuevo caché...")
                
                cached_content = caching.CachedContent.create(
                    model='models/gemini-1.5-pro-002',
                    display_name=f'context_{context_name}',
                    system_instruction=(
                        "Eres un Auditor de Calidad estricto. "
                        "Tu trabajo es evaluar respuestas de IA contra el contexto de negocio proporcionado. "
                        "Debes ser objetivo, preciso y crítico."
                    ),
                    contents=[content],
                    ttl=timedelta(hours=1),  # Caché válido por 1 hora
                )
                
                # Guardar referencia del caché
                context.genai_caches[cache_key] = cached_content
                
                print(f"✓ Caché creado exitosamente")
                print(f"  Cache name: {cached_content.name}")
                print(f"  Expira: {cached_content.expire_time}")
                
            except Exception as e:
                print(f"✗ Error creando caché: {e}")
                raise Exception(f"Error creando Context Cache: {e}")
        
        # Guardar referencia del contexto con caché
        context.genai_contexts[context_name] = {
            'type': 'cache',
            'cache': cached_content,
            'cache_key': cache_key,
            'token_count': token_count,
            'file_path': resolved_path
        }
        
    else:
        # Usar System Instruction (sin caché)
        print(f"📝 Usando System Instruction (tokens < {CACHE_THRESHOLD})")
        
        context.genai_contexts[context_name] = {
            'type': 'system_instruction',
            'content': content,
            'token_count': token_count,
            'file_path': resolved_path
        }
        
        print(f"✓ Contexto cargado como System Instruction")
    
    # Establecer contexto activo
    context.active_context_name = context_name
    print(f"✓ Contexto '{context_name}' activado")


@step('cambio al contexto de reglas de negocio "{context_name}"')
def step_switch_context(context, context_name):
    """Cambia al contexto de reglas de negocio especificado
    
    Ejemplo:
        When cambio al contexto de reglas de negocio "politicas_devoluciones"
    """
    if not hasattr(context, 'genai_contexts'):
        raise AssertionError("No hay contextos cargados. Usa 'el contexto de reglas de negocio está cargado' primero.")
    
    if context_name not in context.genai_contexts:
        available = ', '.join(context.genai_contexts.keys())
        raise AssertionError(f"Contexto '{context_name}' no encontrado. Disponibles: {available}")
    
    context.active_context_name = context_name
    print(f"✓ Cambiado a contexto: {context_name}")


@step('limpio todos los cachés de contexto')
def step_clear_caches(context):
    """Limpia todos los cachés de contexto creados
    
    Ejemplo:
        When limpio todos los cachés de contexto
    """
    if not hasattr(context, 'genai_caches'):
        print("⚠ No hay cachés para limpiar")
        return
    
    deleted_count = 0
    for cache_key, cached_content in context.genai_caches.items():
        try:
            cached_content.delete()
            deleted_count += 1
        except Exception as e:
            print(f"⚠ Error eliminando caché {cache_key[:8]}: {e}")
    
    context.genai_caches = {}
    print(f"✓ {deleted_count} cachés eliminados")


# ============================================================================
# STEPS - INTERACCIÓN CON EL SUT (System Under Test)
# ============================================================================

@step('interactúo con la IA con el prompt "{user_query}"')
@step('envío el prompt "{user_query}" a la IA')
def step_interact_with_sut(context, user_query):
    """Interactúa con el Sistema Bajo Prueba (SUT) y guarda la respuesta
    
    NOTA: Este es un placeholder. Debes implementar la llamada real a tu aplicación.
    
    Ejemplo:
        When interactúo con la IA con el prompt "¿Cuál es la política de devoluciones?"
    """
    resolved_query = context.variable_manager.resolve_variables(user_query)
    
    print(f"💬 Prompt enviado al SUT: {resolved_query}")
    
    # ========================================================================
    # PLACEHOLDER: Implementa aquí la llamada a tu aplicación real
    # ========================================================================
    # Ejemplo:
    # response = your_ai_app.generate(resolved_query)
    # context.sut_response = response
    # context.sut_prompt = resolved_query
    # ========================================================================
    
    # Por ahora, guardamos el prompt para que puedas implementar la lógica
    context.sut_prompt = resolved_query
    
    # Si ya hay una respuesta guardada manualmente, la usamos
    if not hasattr(context, 'sut_response'):
        print("⚠ PLACEHOLDER: Implementa la llamada a tu aplicación en este step")
        print("⚠ Por ahora, usa 'establezco la respuesta del SUT como' para simular")
        context.sut_response = None


@step('establezco la respuesta del SUT como "{response_text}"')
@step('la respuesta del SUT es "{response_text}"')
def step_set_sut_response(context, response_text):
    """Establece manualmente la respuesta del SUT (útil para testing)
    
    Ejemplo:
        And establezco la respuesta del SUT como "Puedes devolver productos dentro de 30 días"
    """
    resolved_response = context.variable_manager.resolve_variables(response_text)
    context.sut_response = resolved_response
    print(f"✓ Respuesta del SUT establecida: {resolved_response[:100]}...")


@step('cargo la respuesta del SUT desde el archivo "{file_path}"')
def step_load_sut_response_from_file(context, file_path):
    """Carga la respuesta del SUT desde un archivo
    
    Ejemplo:
        And cargo la respuesta del SUT desde el archivo "responses/chatbot_response.txt"
    """
    resolved_path = context.variable_manager.resolve_variables(file_path)
    
    try:
        with open(resolved_path, 'r', encoding='utf-8') as file:
            response = file.read()
        
        context.sut_response = response
        print(f"✓ Respuesta del SUT cargada desde: {resolved_path}")
        print(f"  Longitud: {len(response)} caracteres")
        
    except FileNotFoundError:
        raise FileNotFoundError(f"Archivo de respuesta no encontrado: {resolved_path}")
    except Exception as e:
        raise Exception(f"Error leyendo archivo de respuesta: {e}")


# ============================================================================
# STEPS - EVALUACIÓN CON GEMINI COMO JUEZ
# ============================================================================

@step('el Juez Gemini debe validar la respuesta con un umbral mínimo de {threshold:f}')
@step('el Juez Gemini valida la respuesta con umbral {threshold:f}')
def step_gemini_judge_validation(context, threshold):
    """Evalúa la respuesta del SUT usando Gemini como Juez
    
    Evalúa:
    1. Precisión de datos
    2. Cumplimiento de restricciones
    3. Tono de marca
    4. Coherencia con el contexto
    
    Ejemplo:
        Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.8
    """
    # Validar que hay contexto activo
    if not hasattr(context, 'active_context_name'):
        raise AssertionError("No hay contexto activo. Usa 'el contexto de reglas de negocio está cargado' primero.")
    
    # Validar que hay respuesta del SUT
    if not hasattr(context, 'sut_response') or context.sut_response is None:
        raise AssertionError("No hay respuesta del SUT. Usa 'interactúo con la IA' o 'establezco la respuesta del SUT' primero.")
    
    # Obtener contexto activo
    context_name = context.active_context_name
    context_data = context.genai_contexts[context_name]
    
    print(f"⚖️ Iniciando evaluación con Juez Gemini")
    print(f"  Contexto: {context_name}")
    print(f"  Tipo: {context_data['type']}")
    print(f"  Umbral: {threshold}")
    
    # Preparar prompt del juez
    judge_system_prompt = """Actúa como un Auditor de Calidad estricto y objetivo.

Tu trabajo es comparar la Respuesta del Usuario contra el Contexto de Negocio proporcionado.

Evalúa los siguientes aspectos:
1. **Precisión de datos**: ¿La información es correcta según el contexto?
2. **Cumplimiento de restricciones**: ¿Se respetan todas las reglas y políticas?
3. **Tono de marca**: ¿El tono es apropiado y profesional?
4. **Coherencia**: ¿La respuesta es coherente con el contexto?

Debes responder EXCLUSIVAMENTE en formato JSON con esta estructura:
{
  "score": 0.85,
  "reasoning": "Explicación detallada de la evaluación",
  "critical_errors": ["Error 1", "Error 2"],
  "strengths": ["Fortaleza 1", "Fortaleza 2"],
  "suggestions": ["Sugerencia 1", "Sugerencia 2"]
}

Donde:
- score: Puntuación de 0.0 a 1.0 (0.0 = completamente incorrecto, 1.0 = perfecto)
- reasoning: Explicación detallada de por qué asignaste ese score
- critical_errors: Lista de errores críticos encontrados (vacía si no hay)
- strengths: Lista de aspectos positivos
- suggestions: Lista de sugerencias de mejora

Sé estricto pero justo. Un score de 0.8+ indica excelencia."""
    
    # Preparar el prompt de evaluación
    user_prompt = context.sut_prompt if hasattr(context, 'sut_prompt') else "N/A"
    
    evaluation_prompt = f"""**PROMPT DEL USUARIO:**
{user_prompt}

**RESPUESTA A EVALUAR:**
{context.sut_response}

Evalúa esta respuesta contra el contexto de negocio proporcionado y responde en formato JSON."""
    
    try:
        # Crear modelo según el tipo de contexto
        if context_data['type'] == 'cache':
            # Usar modelo con caché
            print(f"  Usando Context Cache")
            model = genai.GenerativeModel.from_cached_content(
                cached_content=context_data['cache']
            )
        else:
            # Usar modelo con system instruction
            print(f"  Usando System Instruction")
            full_system_instruction = f"""{judge_system_prompt}

**CONTEXTO DE NEGOCIO:**
{context_data['content']}"""
            
            model = genai.GenerativeModel(
                model_name='gemini-1.5-pro-002',
                system_instruction=full_system_instruction
            )
        
        # Generar evaluación
        print(f"⏳ Generando evaluación...")
        response = model.generate_content(evaluation_prompt)
        
        # Verificar si la respuesta fue bloqueada
        if not response.text:
            if hasattr(response, 'prompt_feedback'):
                feedback = response.prompt_feedback
                raise AssertionError(
                    f"Respuesta bloqueada por filtros de seguridad: {feedback}"
                )
            else:
                raise AssertionError("Gemini no devolvió respuesta (posible bloqueo de seguridad)")
        
        # Parsear respuesta JSON
        response_text = response.text.strip()
        
        # Limpiar markdown si existe
        if response_text.startswith('```json'):
            response_text = response_text.replace('```json', '').replace('```', '').strip()
        elif response_text.startswith('```'):
            response_text = response_text.replace('```', '').strip()
        
        try:
            evaluation = json.loads(response_text)
        except json.JSONDecodeError as e:
            print(f"✗ Error parseando JSON de Gemini:")
            print(f"  Respuesta: {response_text[:500]}")
            raise AssertionError(f"Gemini no devolvió JSON válido: {e}")
        
        # Extraer score
        if 'score' not in evaluation:
            raise AssertionError(f"Respuesta de Gemini no contiene 'score': {evaluation}")
        
        score = float(evaluation['score'])
        reasoning = evaluation.get('reasoning', 'No se proporcionó razonamiento')
        critical_errors = evaluation.get('critical_errors', [])
        strengths = evaluation.get('strengths', [])
        suggestions = evaluation.get('suggestions', [])
        
        # Guardar evaluación en contexto
        context.last_evaluation = {
            'score': score,
            'reasoning': reasoning,
            'critical_errors': critical_errors,
            'strengths': strengths,
            'suggestions': suggestions,
            'threshold': threshold,
            'passed': score >= threshold,
            'timestamp': datetime.now().isoformat()
        }
        
        # Mostrar resultados
        print(f"\n{'='*70}")
        print(f"📊 EVALUACIÓN DEL JUEZ GEMINI")
        print(f"{'='*70}")
        print(f"Score: {score:.2f} / 1.00 (Umbral: {threshold:.2f})")
        print(f"\n💭 Razonamiento:")
        print(f"  {reasoning}")
        
        if critical_errors:
            print(f"\n❌ Errores Críticos:")
            for error in critical_errors:
                print(f"  • {error}")
        
        if strengths:
            print(f"\n✅ Fortalezas:")
            for strength in strengths:
                print(f"  • {strength}")
        
        if suggestions:
            print(f"\n💡 Sugerencias:")
            for suggestion in suggestions:
                print(f"  • {suggestion}")
        
        print(f"{'='*70}\n")
        
        # Validar umbral
        if score >= threshold:
            print(f"✓ EVALUACIÓN APROBADA (Score: {score:.2f} >= {threshold:.2f})")
        else:
            error_msg = f"""EVALUACIÓN REPROBADA

Score obtenido: {score:.2f}
Umbral requerido: {threshold:.2f}
Diferencia: {threshold - score:.2f}

Razonamiento del Juez:
{reasoning}

Errores Críticos:
{chr(10).join(f'• {e}' for e in critical_errors) if critical_errors else 'Ninguno'}

Sugerencias de Mejora:
{chr(10).join(f'• {s}' for s in suggestions) if suggestions else 'Ninguna'}"""
            
            print(f"✗ {error_msg}")
            raise AssertionError(error_msg)
        
    except json.JSONDecodeError as e:
        raise AssertionError(f"Error parseando respuesta de Gemini: {e}")
    except Exception as e:
        if "AssertionError" in str(type(e)):
            raise
        raise AssertionError(f"Error en evaluación de Gemini: {e}")


@step('el Juez Gemini debe validar la respuesta con criterios personalizados "{criteria}" y umbral {threshold:f}')
def step_gemini_judge_custom_criteria(context, criteria, threshold):
    """Evalúa la respuesta del SUT con criterios personalizados
    
    Ejemplo:
        Then el Juez Gemini debe validar la respuesta con criterios personalizados "tono empático,respuesta en menos de 50 palabras" y umbral 0.85
    """
    # Similar al step anterior pero con criterios personalizados
    criteria_list = [c.strip() for c in criteria.split(',')]
    
    # Modificar el system prompt para incluir criterios personalizados
    # (Implementación similar al step anterior con criterios adicionales)
    print(f"⚖️ Evaluación con criterios personalizados: {', '.join(criteria_list)}")
    
    # Por ahora, delegar al step principal
    # TODO: Implementar lógica de criterios personalizados
    step_gemini_judge_validation(context, threshold)


@step('guardo la evaluación del Juez en el archivo "{file_path}"')
def step_save_evaluation(context, file_path):
    """Guarda la última evaluación del Juez en un archivo JSON
    
    Ejemplo:
        And guardo la evaluación del Juez en el archivo "evaluations/test_001.json"
    """
    if not hasattr(context, 'last_evaluation'):
        raise AssertionError("No hay evaluación disponible. Ejecuta 'el Juez Gemini debe validar' primero.")
    
    resolved_path = context.variable_manager.resolve_variables(file_path)
    
    try:
        # Crear directorio si no existe
        os.makedirs(os.path.dirname(resolved_path), exist_ok=True)
        
        # Guardar evaluación
        with open(resolved_path, 'w', encoding='utf-8') as file:
            json.dump(context.last_evaluation, file, indent=2, ensure_ascii=False)
        
        print(f"✓ Evaluación guardada en: {resolved_path}")
        
    except Exception as e:
        raise Exception(f"Error guardando evaluación: {e}")


@step('el score de la última evaluación debe ser mayor o igual a {min_score:f}')
def step_verify_evaluation_score(context, min_score):
    """Verifica que el score de la última evaluación cumple con el mínimo
    
    Ejemplo:
        And el score de la última evaluación debe ser mayor o igual a 0.9
    """
    if not hasattr(context, 'last_evaluation'):
        raise AssertionError("No hay evaluación disponible.")
    
    score = context.last_evaluation['score']
    
    if score >= min_score:
        print(f"✓ Score {score:.2f} >= {min_score:.2f}")
    else:
        raise AssertionError(f"Score {score:.2f} < {min_score:.2f}")
