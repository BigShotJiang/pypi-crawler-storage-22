import os
import time
from behave import step


def _get_element(context, selector, dynamic_value=None):
    """
    Función auxiliar para obtener elementos.
    Soporta tanto selectores CSS como identificadores JSON ($.ARCHIVO.elemento)
    Soporta placeholders dinámicos: $.ARCHIVO.elemento=valor
    Soporta iframes: Si context.current_frame existe, busca dentro del iframe
    """
    # Determinar si estamos dentro de un iframe
    page_or_frame = getattr(context, 'current_frame', None) or context.page
    
    if selector.startswith('$.') and hasattr(context, 'element_locator'):
        return context.element_locator.find(page_or_frame, selector, dynamic_value)
    else:
        return page_or_frame.locator(selector)

@step('I switch to the new window')
@step('cambio a la nueva ventana')
@step('que cambio a la nueva ventana')
def step_switch_to_new_window(context):
    """Cambia a la ventana más reciente"""
    # Intentamos esperar hasta 5 segundos a que aparezca una nueva página
    for _ in range(10):
        # Obtener páginas del contexto actual
        pages = context.page.context.pages
        
        if len(pages) > 1:
            # Seleccionamos la última de la lista
            context.page = pages[-1]
            # Aseguramos que la ventana tenga el foco para interactuar
            context.page.bring_to_front()
            # Opcional: esperar a que la URL no sea 'about:blank'
            context.page.wait_for_load_state("domcontentloaded")
            return
        time.sleep(0.5)
        
    pages = context.page.context.pages
    raise Exception(f"No hay ventanas adicionales disponibles. Páginas detectadas: {len(pages)}")

@step('I close the current window')
@step('cierro la ventana actual')
@step('que cierro la ventana actual')
def step_close_current_window(context):
    """Cierra la ventana actual"""
    context.page.close()
    # Cambiar a la primera ventana disponible si existe
    pages = context.page.context.pages
    if pages:
        context.page = pages[0]

@step('I switch to window with title "{title}"')
@step('cambio a la ventana con título "{title}"')
@step('que cambio a la ventana con título "{title}"')
def step_switch_to_window_by_title(context, title):
    """Cambia a una ventana específica por su título con reintentos"""
    resolved_title = context.variable_manager.resolve_variables(title)
    
    # Damos un margen de hasta 5 segundos (10 reintentos de 0.5s)
    for _ in range(10):
        # Obtener páginas del contexto actual
        pages = context.page.context.pages
        
        for page in pages:
            try:
                # Comparamos si el título contiene la cadena (más flexible que ==)
                if resolved_title.lower() in page.title().lower():
                    context.page = page
                    context.page.bring_to_front() # Foco en la ventana
                    return
            except Exception:
                # A veces una página en carga puede dar error al pedir el título
                continue
        time.sleep(0.5)
        
    # Si falla, mostramos qué títulos sí encontró para debuguear
    pages = context.page.context.pages
    actual_titles = [p.title() for p in pages]
    raise Exception(
        f"No se encontró ventana con título: '{resolved_title}'. "
        f"Títulos disponibles: {actual_titles}"
    )

@step('I switch to window with url containing "{url_part}"')
@step('cambio a la ventana con url que contiene "{url_part}"')
@step('que cambio a la ventana con url que contiene "{url_part}"')
def step_switch_to_window_by_url(context, url_part):
    resolved_url_part = context.variable_manager.resolve_variables(url_part)
    # Reintentamos durante unos segundos porque las ventanas tardan en aparecer
    for _ in range(10):  # Reintenta por 5 segundos aprox
        # Obtener páginas del contexto actual
        pages = context.page.context.pages
        
        for page in pages:
            if resolved_url_part in page.url:
                context.page = page
                context.page.bring_to_front() # Muy importante para interactuar
                return
        time.sleep(0.5)
        
    # Obtener URLs para el mensaje de error
    pages = context.page.context.pages
    urls = [p.url for p in pages]
    raise Exception(f"No se encontró ventana con URL que contenga: {resolved_url_part}. URLs abiertas: {urls}")

@step('I accept the alert')
@step('acepto la alerta')
@step('que acepto la alerta')
def step_accept_alert(context):
    """Acepta una alerta de JavaScript (espera a que aparezca)"""
    # Usar context manager para esperar y manejar el dialog
    with context.page.expect_dialog() as dialog_info:
        # El dialog aparecerá en algún momento durante la ejecución
        # Este context manager espera hasta 30 segundos por defecto
        pass
    
    dialog_info.value.accept()
    print(f"✓ Alerta aceptada: '{dialog_info.value.message}'")

@step('I dismiss the alert')
@step('rechazo la alerta')
@step('que rechazo la alerta')
def step_dismiss_alert(context):
    """Rechaza una alerta de JavaScript (espera a que aparezca)"""
    # Usar context manager para esperar y manejar el dialog
    with context.page.expect_dialog() as dialog_info:
        pass
    
    dialog_info.value.dismiss()
    print(f"✓ Alerta rechazada: '{dialog_info.value.message}'")

@step('I accept the alert with text "{text}"')
@step('acepto la alerta con texto "{text}"')
@step('que acepto la alerta con texto "{text}"')
def step_accept_alert_with_text(context, text):
    """Acepta una alerta y envía texto (para prompts)"""
    resolved_text = context.variable_manager.resolve_variables(text)
    
    # Usar context manager para esperar y manejar el dialog
    with context.page.expect_dialog() as dialog_info:
        pass
    
    dialog_info.value.accept(resolved_text)
    print(f"✓ Alerta aceptada con texto: '{resolved_text}'")

@step('I get the alert text and store it in variable "{variable_name}"')
@step('obtengo el texto de la alerta y lo guardo en la variable "{variable_name}"')
@step('que obtengo el texto de la alerta y lo guardo en la variable "{variable_name}"')
def step_get_alert_text(context, variable_name):
    """Obtiene el texto de una alerta y lo guarda en una variable"""
    # Usar context manager para esperar y manejar el dialog
    with context.page.expect_dialog() as dialog_info:
        pass
    
    message = dialog_info.value.message
    context.variable_manager.set_variable(variable_name, message)
    dialog_info.value.accept()
    print(f"✓ Texto de alerta guardado en '{variable_name}': '{message}'")

@step('I switch to frame "{frame_name}" with identifier "{identifier}"')
@step('cambio al frame "{frame_name}" con identificador "{identifier}"')
@step('que cambio al frame "{frame_name}" con identificador "{identifier}"')
def step_switch_to_frame(context, frame_name, identifier):
    """Cambia a un frame específico"""
    locator = context.element_locator.get_locator(identifier)
    # Usar frame_locator para obtener el FrameLocator
    context.current_frame = context.page.frame_locator(locator)
    print(f"✅ Cambiado al frame: {frame_name}")

@step('I switch to main content')
@step('cambio al contenido principal')
@step('que cambio al contenido principal')
@step('salgo del frame')
@step('que salgo del frame')
def step_switch_to_main_content(context):
    """Vuelve al contenido principal (sale del iframe)"""
    context.current_frame = None
    print(f"✅ Cambiado al contenido principal (fuera del iframe)")

@step('I take a screenshot and save it as "{filename}"')
@step('tomo una captura de pantalla y la guardo como "{filename}"')
@step('que tomo una captura de pantalla y la guardo como "{filename}"')
def step_take_screenshot(context, filename):
    """Toma una captura de pantalla"""
    resolved_filename = context.variable_manager.resolve_variables(filename)
    
    # Usar configuración de página completa
    full_page = os.getenv('SCREENSHOT_FULL_PAGE', 'true').lower() == 'true'
    context.page.screenshot(path=resolved_filename, full_page=full_page, type='png')

@step('I take a screenshot of element "{element_name}" and save it as "{filename}" with identifier "{identifier}"')
@step('tomo una captura del elemento "{element_name}" y la guardo como "{filename}" con identificador "{identifier}"')
@step('que tomo una captura del elemento "{element_name}" y la guardo como "{filename}" con identificador "{identifier}"')
def step_take_element_screenshot(context, element_name, filename, identifier):
    """Toma una captura de pantalla de un elemento específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_filename = context.variable_manager.resolve_variables(filename)
    context.page.locator(locator).screenshot(path=resolved_filename)


@step('the alert message should be "{expected_text}"')
@step('el mensaje de la alerta debería ser "{expected_text}"')
@step('que el mensaje de la alerta debería ser "{expected_text}"')
def step_verify_alert_message_exact(context, expected_text):
    """Verifica que el mensaje de la alerta sea exactamente igual"""
    resolved_text = context.variable_manager.resolve_variables(expected_text)
    
    # Usar context manager para esperar y capturar el dialog
    with context.page.expect_dialog() as dialog_info:
        pass
    
    actual_message = dialog_info.value.message
    
    assert actual_message == resolved_text, (
        f"Mensaje de alerta incorrecto.\n"
        f"Esperado: '{resolved_text}'\n"
        f"Actual: '{actual_message}'"
    )
    
    # Aceptar el dialog después de verificar
    dialog_info.value.accept()
    print(f"✓ Mensaje de alerta verificado: '{actual_message}'")

@step('the alert message should contain "{expected_text}"')
@step('el mensaje de la alerta debería contener "{expected_text}"')
@step('que el mensaje de la alerta debería contener "{expected_text}"')
def step_verify_alert_message_contains(context, expected_text):
    """Verifica que el mensaje de la alerta contenga un texto parcial"""
    resolved_text = context.variable_manager.resolve_variables(expected_text)
    
    # Usar context manager para esperar y capturar el dialog
    with context.page.expect_dialog() as dialog_info:
        pass
    
    actual_message = dialog_info.value.message
    
    assert resolved_text in actual_message, (
        f"Mensaje de alerta no contiene el texto esperado.\n"
        f"Buscando: '{resolved_text}'\n"
        f"Actual: '{actual_message}'"
    )
    
    # Aceptar el dialog después de verificar
    dialog_info.value.accept()
    print(f"✓ Mensaje de alerta contiene: '{resolved_text}'")

@step('I store the alert message in variable "{variable_name}"')
@step('guardo el mensaje de la alerta en la variable "{variable_name}"')
@step('que guardo el mensaje de la alerta en la variable "{variable_name}"')
def step_store_alert_message(context, variable_name):
    """Guarda el mensaje de la alerta en una variable"""
    # Usar context manager para esperar y capturar el dialog
    with context.page.expect_dialog() as dialog_info:
        pass
    
    message = dialog_info.value.message
    
    context.variable_manager.set_variable(variable_name, message)
    
    # Aceptar el dialog después de guardar
    dialog_info.value.accept()
    print(f"✓ Mensaje de alerta guardado en variable '{variable_name}': '{message}'")

@step('I extract dialog message to variable "{variable_name}" and close it')
@step('extraigo el texto del diálogo lo guardo en la variable "{variable_name}" y cierro el diálogo')
@step('que extraigo el texto del diálogo lo guardo en la variable "{variable_name}" y cierro el diálogo')
def step_extract_dialog_and_close(context, variable_name):
    """Extrae el texto del diálogo, lo guarda en una variable y lo cierra
    
    Este step:
    1. Desactiva listeners anteriores
    2. Configura un listener para capturar el diálogo
    3. Espera a que aparezca un diálogo
    4. Captura el mensaje
    5. Lo guarda en la variable especificada
    6. Acepta el diálogo (lo cierra)
    
    IMPORTANTE: Este step desactiva el listener automático anterior.
    Si necesitas que los diálogos se acepten automáticamente, NO uses este step.
    
    Ejemplo:
    When hago click en el botón "Validar"
    Then extraigo el texto del diálogo lo guardo en la variable "error_message" y cierro el diálogo
    And verifico que la variable "error_message" contiene "feriado"
    """
    # Usamos un diccionario para poder modificarlo dentro del closure
    captured_data = {"message": None, "dialog": None}
    handle_dialog_ref = None

    def handle_dialog(dialog):
        # Capturar el mensaje y el dialog ANTES de aceptar
        captured_data["message"] = dialog.message
        captured_data["dialog"] = dialog
        print(f"📢 Dialog capturado: {dialog.message}")

    handle_dialog_ref = handle_dialog

    # 1. Limpiar listeners previos - NO usar remove_listener() sin parámetros
    try:
        # Intentar remover todos los listeners de 'dialog'
        context.page.remove_all_listeners('dialog')
    except:
        # Si no existe remove_all_listeners, usar un enfoque diferente
        pass
    
    # 2. Configurar el listener ANTES de que aparezca el diálogo
    context.page.on('dialog', handle_dialog)

    # 3. Esperar a que se capture el mensaje (máximo 5 segundos)
    try:
        context.page.wait_for_function(
            lambda: captured_data["message"] is not None,
            timeout=5000
        )
    except Exception as e:
        # Limpiar listener en caso de error
        try:
            if handle_dialog_ref:
                context.page.remove_listener('dialog', handle_dialog_ref)
        except:
            pass
        
        # Verificar si es un error de página cerrada
        if "Target page, context or browser has been closed" in str(e):
            raise AssertionError("❌ Error: La página se cerró mientras esperaba el diálogo")
        else:
            raise AssertionError(f"❌ Timeout: No se detectó ningún diálogo en 5 segundos. Error: {e}")

    # 4. Verificar que se capturó el mensaje
    if not captured_data["message"]:
        # Limpiar listener
        try:
            if handle_dialog_ref:
                context.page.remove_listener('dialog', handle_dialog_ref)
        except:
            pass
        raise AssertionError("❌ No se pudo capturar el mensaje del diálogo")

    # 5. Guardar en variable
    message = captured_data["message"]
    context.variable_manager.set_variable(variable_name, message)
    
    # 6. Aceptar el diálogo (cerrarlo)
    try:
        if captured_data["dialog"]:
            captured_data["dialog"].accept()
            print(f"✓ Diálogo aceptado")
    except Exception as e:
        if "Target page, context or browser has been closed" in str(e):
            print(f"⚠ Página cerrada, no se pudo aceptar el diálogo")
        else:
            print(f"⚠ Error aceptando diálogo: {e}")
    
    # 7. Limpieza final - remover el listener específico
    try:
        if handle_dialog_ref:
            context.page.remove_listener('dialog', handle_dialog_ref)
    except Exception as e:
        if "Target page, context or browser has been closed" not in str(e):
            print(f"⚠ Error removiendo listener: {e}")
    
    print(f"✓ Texto guardado en '{variable_name}': '{message}'")