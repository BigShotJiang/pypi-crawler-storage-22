from typing import Dict, Any, Callable, Optional
from rich.pretty import pprint
import json
import hashlib


class DictUtils:
    """
    General-purpose dictionary manipulation utilities.
    """

    @staticmethod
    def flatten(
        d: Dict[str, Any],
        parent_key: str = "",
        sep: str = ".",
        is_leaf_predicate: Optional[Callable[[Any], bool]] = None,
    ) -> Dict[str, Any]:
        """
        Recursively flattens a nested dictionary.

        Args:
            d: The dictionary to flatten.
            parent_key: Prefix for keys (used during recursion).
            sep: Separator for dot-notation keys.
            is_leaf_predicate: Optional function that returns True if a value should
                               be treated as a leaf (value) rather than a branch to recurse.
                               Useful if you have dicts you don't want flattened.
        """
        items = []
        for k, v in d.items():
            new_key = f"{parent_key}{sep}{k}" if parent_key else k

            # Check if we should treat this as a leaf (custom logic)
            if is_leaf_predicate and is_leaf_predicate(v):
                items.append((new_key, v))
            # Standard recursion
            elif isinstance(v, dict):
                items.extend(
                    DictUtils.flatten(
                        v, new_key, sep=sep, is_leaf_predicate=is_leaf_predicate
                    ).items()
                )
            else:
                items.append((new_key, v))
        return dict(items)

    @staticmethod
    def unflatten(flat_dict: Dict[str, Any], sep: str = ".") -> Dict[str, Any]:
        """
        Converts flat dot-notation keys back to nested dictionaries.
        e.g., {'a.b': 1} -> {'a': {'b': 1}}
        """
        nested = {}
        for key, value in flat_dict.items():
            DictUtils.deep_set(nested, key, value, sep=sep)
        return nested

    @staticmethod
    def deep_update(base: Dict[str, Any], update: Dict[str, Any]) -> Dict[str, Any]:
        """
        Recursively merges 'update' dict into 'base' dict.

        Unlike the standard `dict.update()`, which replaces nested dictionaries entirely,
        this method enters nested dictionaries and updates them key-by-key. This preserves
        existing keys in 'base' that are not present in 'update'.

        Args:
            base: The original dictionary to modify.
            update: The dictionary containing new values.

        Returns:
            The modified 'base' dictionary.

        Example:
            >>> base = {'model': {'name': 'v1', 'dropout': 0.5}}
            >>> new_vals = {'model': {'name': 'v2'}}
            >>> # Standard update would delete 'dropout'. deep_update keeps it:
            >>> DictUtils.deep_update(base, new_vals)
            {'model': {'name': 'v2', 'dropout': 0.5}}
        """
        for k, v in update.items():
            if isinstance(v, dict) and k in base and isinstance(base[k], dict):
                DictUtils.deep_update(base[k], v)
            else:
                base[k] = v
        return base

    @staticmethod
    def deep_set(d: Dict[str, Any], dot_key: str, value: Any, sep: str = ".") -> None:
        """
        Sets a value in a nested dictionary using a dot-notation key path.
        Automatically creates any missing intermediate dictionaries.

        Args:
            d: The dictionary to modify.
            dot_key: The path to the value (e.g., "model.backbone.layers").
            value: The value to set.
            sep: The separator used in the key (default is ".").

        Example:
            >>> cfg = {}
            >>> DictUtils.deep_set(cfg, "a.b.c", 10)
            >>> print(cfg)
            {'a': {'b': {'c': 10}}}
        """
        parts = dot_key.split(sep)
        target = d
        for part in parts[:-1]:
            if part not in target:
                target[part] = {}
            target = target[part]
            if not isinstance(target, dict):
                # Handle conflict if a path was previously a value (e.g. overwriting a leaf)
                target = {}
        target[parts[-1]] = value

    @staticmethod
    def get_unique_hash(input_dict, length=12):
        """
        Returns a unique hash string for a dictionary.

        :param input_dict: The dictionary params
        :param length: The desired length of the hash string (default 12)
        """
        assert length >= 12, "Hash length must be at least 12 to ensure uniqueness."
        # 1. Sort keys to ensure {a:1, b:2} == {b:2, a:1}
        config_str = json.dumps(input_dict, sort_keys=True)

        # 2. Generate full SHA-256 hash (64 chars long)
        full_hash = hashlib.sha256(config_str.encode("utf-8")).hexdigest()

        # 3. Truncate to desired length
        return full_hash[:length]


def test_update():
    # --- Setup ---
    base_config = {
        "model": {
            "name": "ResNet50",
            "layers": 50,
            "details": {
                "activation": "relu",
                "dropout": 0.5,  # <--- We want to keep this
            },
        },
        "epochs": 10,
    }

    new_settings = {
        "model": {"details": {"activation": "gelu"}}  # <--- We only want to change this
    }

    b1 = base_config.copy()
    b2 = base_config.copy()
    n1 = new_settings.copy()
    n2 = new_settings.copy()

    pprint("Base Config:")
    pprint(base_config)
    pprint("New Settings:")
    pprint(new_settings)
    print("*" * 40)
    pprint(
        "Task: Update base_config with new_settings, preserving unspecified nested keys."
    )
    print("*" * 40)

    # --- Standard Update (The Problem) ---
    pprint("Normal Update Result:")
    b1.update(n1)
    pprint(b1)  # type: ignore[return-value]

    # --- Deep Update (The Solution) ---
    pprint("Deep Update Result:")
    pprint(DictUtils.deep_update(b2, n2))


def test_hash():
    # --- Usage ---
    cfg1 = {"learning_rate": 0.01, "batch_size": 32, "optimizer": "adam"}
    cfg1_shuffle = {
        "batch_size": 32,
        "optimizer": "adam",
        "learning_rate": 0.01,
    }
    cfg2 = {"learning_rate": 0.02, "batch_size": 32, "optimizer": "adam"}
    hash1 = DictUtils.get_unique_hash(cfg1)
    hash2 = DictUtils.get_unique_hash(cfg1_shuffle)
    hash3 = DictUtils.get_unique_hash(cfg2)
    pprint(f"Config 1 Hash: {hash1}")
    pprint(f"Config 1_shuffle Hash: {hash2}")
    pprint(f"Config 2 Hash: {hash3}")

    assert hash1 == hash2, "Hashes should match for identical dicts."
    assert hash1 != hash3, "Hashes should differ for different dicts."


if __name__ == "__main__":
    test_update()
    test_hash()
