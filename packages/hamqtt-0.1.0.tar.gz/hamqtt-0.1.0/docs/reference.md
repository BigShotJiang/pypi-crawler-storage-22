# API Reference

This reference documentation is automatically generated from the source code docstrings.

## CLI Application

::: hamqtt.main

## Configuration

::: hamqtt.config

## Discovery Models

::: hamqtt.discovery

## MQTT Client

::: hamqtt.mqtt_client
