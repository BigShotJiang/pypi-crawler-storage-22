# Home Assistant MQTT CLI

[![PyPI version](https://badge.fury.io/py/hamqtt.svg)](https://badge.fury.io/py/hamqtt)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python Versions](https://img.shields.io/pypi/pyversions/hamqtt.svg)](https://pypi.org/project/hamqtt/)

A command-line interface (CLI) tool to easily send custom sensor data to [Home Assistant](https://www.home-assistant.io/) using [MQTT Discovery](https://www.home-assistant.io/integrations/mqtt/#mqtt-discovery).

> [!IMPORTANT]
> **Rename Notice**: This project has been renamed from `ha-cli` to `hamqtt` to avoid a name clash with an existing PyPI package.
> Legacy configurations in `~/.config/ha-cli` will be automatically migrated to `~/.config/hamqtt` on the first run.

## Features

- **Easy Configuration**: Interactive setup for MQTT broker connection. Supports `--show` to view and `--reset` to clear configuration.
- **Auto-Discovery**: Automatically registers entities with Home Assistant.
- **Flexible**: Supports sensors, binary sensors, and various device classes.
- **Scriptable**: Output JSON payloads for use with other tools or scripts.

## Installation

Install using `uv` (recommended):

```bash
uv tool install hamqtt
```

Or using `pip`:

```bash
pip install hamqtt
```

## Quick Start

1.  **Configure MQTT Connection**:

    ```bash
    hamqtt configure
    ```
    Follow the prompts to enter your broker details.

2.  **Register a Sensor**:

    ```bash
    hamqtt register --unique-id my_temp_sensor --name "Living Room Temperature" --device-class temperature --unit "°C"
    ```

3.  **Send Data**:

    ```bash
    hamqtt send --unique-id my_temp_sensor --state 22.5
    ```

## Documentation

Full documentation is available at [https://HWiese1980.github.io/hamqtt/](https://HWiese1980.github.io/hamqtt/).

## License

This project is licensed under the terms of the MIT license.
