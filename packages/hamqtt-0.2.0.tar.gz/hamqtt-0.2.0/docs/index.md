# Home Assistant MQTT CLI

A command-line interface (CLI) tool to easily send custom sensor data to [Home Assistant](https://www.home-assistant.io/) using [MQTT Discovery](https://www.home-assistant.io/integrations/mqtt/#mqtt-discovery).

!!! warning "Rename Notice"
    This project has been renamed from `ha-cli` to `hamqtt` to avoid a name clash with an existing PyPI package.
    Legacy configurations in `~/.config/ha-cli` will be automatically migrated to `~/.config/hamqtt` on the first run.

## Features

- **Easy Configuration**: Interactive setup for MQTT broker connection. Supports `--show` to view and `--reset` to clear configuration.
- **Auto-Discovery**: Automatically registers entities with Home Assistant.
- **Flexible**: Supports sensors, binary sensors, and various device classes.
- **Scriptable**: output JSON payloads for use with other tools or scripts.

## Installation

```bash
pip install hamqtt
```

Or using `uv` or `pipx`:

```bash
uv tool install hamqtt
```

## Quick Start

1.  **Configure MQTT Connection**:

    ```bash
    hamqtt configure
    ```
    Follow the prompts to enter your broker details.

2.  **Register a Sensor**:

    ```bash
    hamqtt register --unique-id my_temp_sensor --name "Living Room Temperature" --device-class temperature --unit "°C"
    ```

3.  **Send Data**:

    ```bash
    hamqtt send --unique-id my_temp_sensor --state 22.5
    ```

## CLI Reference

See the [API Reference](reference.md) for detailed documentation on internal modules.

For CLI help, run:

```bash
hamqtt --help
```
