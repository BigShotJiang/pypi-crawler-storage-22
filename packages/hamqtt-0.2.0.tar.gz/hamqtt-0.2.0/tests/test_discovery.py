import json

from hamqtt.discovery import DeviceInfo, DiscoveryEntity


def test_device_info_validation() -> None:
    """Test DeviceInfo model validation"""
    device = DeviceInfo(identifiers=["device-123"], name="Test Device", manufacturer="Acme Corp", model="Model X")
    assert device.identifiers == ["device-123"]
    assert device.name == "Test Device"


def test_discovery_entity_defaults() -> None:
    """Test DiscoveryEntity defaults"""
    entity = DiscoveryEntity(unique_id="sensor_1", name="Sensor 1", state_topic="home/sensor1")
    assert entity.device_class is None
    assert entity.unit_of_measurement is None
    assert entity.device is None


def test_get_topic() -> None:
    """Test discovery topic generation"""
    entity = DiscoveryEntity(unique_id="sensor_1", name="Sensor 1", state_topic="home/sensor1")

    topic = entity.get_topic(prefix="homeassistant", component="sensor")
    assert topic == "homeassistant/sensor/sensor_1/config"

    topic_custom = entity.get_topic(prefix="myha", component="binary_sensor")
    assert topic_custom == "myha/binary_sensor/sensor_1/config"


def test_payload_serialization() -> None:
    """Test that model dumps correct JSON payload"""
    device = DeviceInfo(identifiers=["d1"], name="D1")
    entity = DiscoveryEntity(
        unique_id="s1", name="S1", state_topic="t1", device=device, device_class="temperature", unit_of_measurement="C"
    )

    payload = entity.model_dump_json(exclude_none=True)
    data = json.loads(payload)

    assert data["name"] == "S1"
    assert data["device_class"] == "temperature"
    assert data["unit_of_measurement"] == "C"
    assert data["device"]["identifiers"] == ["d1"]
    assert "icon" not in data
