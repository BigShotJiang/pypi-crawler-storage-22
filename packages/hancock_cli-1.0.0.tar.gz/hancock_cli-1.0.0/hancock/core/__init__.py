"""Core functionality for Hancock."""
