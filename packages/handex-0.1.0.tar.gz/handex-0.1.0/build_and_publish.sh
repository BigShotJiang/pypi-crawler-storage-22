#!/bin/bash
# Build and publish script for handex package

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_info() {
    echo -e "${YELLOW}→ $1${NC}"
}

# Function to display usage
usage() {
    cat << EOF
Usage: $0 [OPTIONS]

Build and publish handex package to PyPI

OPTIONS:
    -t, --test          Publish to Test PyPI instead of production PyPI
    -s, --skip-tests    Skip running tests before building
    -c, --clean-only    Only clean build artifacts, don't build
    -b, --build-only    Only build, don't publish
    -h, --help          Show this help message

EXAMPLES:
    # Build and publish to production PyPI
    $0

    # Build and publish to Test PyPI
    $0 --test

    # Only build (no publish)
    $0 --build-only

    # Clean old build artifacts
    $0 --clean-only

REQUIREMENTS:
    - build package: pip install build
    - twine package: pip install twine
    - PyPI account and credentials configured

EOF
    exit 0
}

# Default options
PUBLISH_TO_TEST=false
SKIP_TESTS=false
CLEAN_ONLY=false
BUILD_ONLY=false

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        -t|--test)
            PUBLISH_TO_TEST=true
            shift
            ;;
        -s|--skip-tests)
            SKIP_TESTS=true
            shift
            ;;
        -c|--clean-only)
            CLEAN_ONLY=true
            shift
            ;;
        -b|--build-only)
            BUILD_ONLY=true
            shift
            ;;
        -h|--help)
            usage
            ;;
        *)
            print_error "Unknown option: $1"
            usage
            ;;
    esac
done

# Print banner
echo "=================================="
echo "  Hand Tracking Teleop Package"
echo "  Build & Publish Script"
echo "=================================="
echo ""

# Step 1: Clean old build artifacts
print_info "Cleaning old build artifacts..."
rm -rf build/
rm -rf dist/
rm -rf *.egg-info
rm -rf src/*.egg-info
find . -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
find . -type f -name "*.pyc" -delete 2>/dev/null || true
print_success "Cleaned build artifacts"

if [ "$CLEAN_ONLY" = true ]; then
    print_success "Clean complete!"
    exit 0
fi

# Step 2: Check for required tools
print_info "Checking required tools..."

if ! command -v python3 &> /dev/null; then
    print_error "python3 is not installed"
    exit 1
fi

if ! python3 -m pip show build &> /dev/null; then
    print_error "build package not installed. Install with: pip install build"
    exit 1
fi

if [ "$BUILD_ONLY" = false ]; then
    if ! python3 -m pip show twine &> /dev/null; then
        print_error "twine package not installed. Install with: pip install twine"
        exit 1
    fi
fi

print_success "All required tools are available"

# Step 3: Run tests (optional)
if [ "$SKIP_TESTS" = false ]; then
    print_info "Running tests..."
    if [ -d "tests" ] && [ "$(ls -A tests)" ]; then
        if python3 -m pip show pytest &> /dev/null; then
            python3 -m pytest tests/ || {
                print_error "Tests failed!"
                exit 1
            }
            print_success "Tests passed"
        else
            print_info "pytest not installed, skipping tests"
        fi
    else
        print_info "No tests found, skipping"
    fi
else
    print_info "Skipping tests (--skip-tests flag)"
fi

# Step 4: Verify package version
print_info "Checking package version..."
VERSION=$(grep "^version" pyproject.toml | sed 's/version = "\(.*\)"/\1/')
if [ -z "$VERSION" ]; then
    VERSION=$(grep "version=" setup.py | sed 's/.*version="\(.*\)".*/\1/')
fi

if [ -z "$VERSION" ]; then
    print_error "Could not determine package version"
    exit 1
fi

print_success "Package version: $VERSION"

# Step 5: Build the package
print_info "Building package..."
python3 -m build || {
    print_error "Build failed!"
    exit 1
}
print_success "Package built successfully"

# List built files
print_info "Built files:"
ls -lh dist/

if [ "$BUILD_ONLY" = true ]; then
    print_success "Build complete! (not publishing due to --build-only flag)"
    echo ""
    echo "To publish manually:"
    if [ "$PUBLISH_TO_TEST" = true ]; then
        echo "  python3 -m twine upload --repository testpypi dist/*"
    else
        echo "  python3 -m twine upload dist/*"
    fi
    exit 0
fi

# Step 6: Check package with twine
print_info "Checking package with twine..."
python3 -m twine check dist/* || {
    print_error "Package check failed!"
    exit 1
}
print_success "Package check passed"

# Step 7: Publish to PyPI
if [ "$PUBLISH_TO_TEST" = true ]; then
    print_info "Publishing to Test PyPI..."
    echo ""
    echo "You will need your Test PyPI credentials"
    echo "Visit: https://test.pypi.org/account/register/"
    echo ""
    python3 -m twine upload --repository testpypi dist/* || {
        print_error "Upload to Test PyPI failed!"
        exit 1
    }
    print_success "Successfully published to Test PyPI!"
    echo ""
    echo "Install from Test PyPI with:"
    echo "  pip install --index-url https://test.pypi.org/simple/ handex"
else
    print_info "Publishing to production PyPI..."
    echo ""
    echo "⚠️  WARNING: You are about to publish to PRODUCTION PyPI!"
    echo "   Package: handex"
    echo "   Version: $VERSION"
    echo ""
    read -p "Are you sure you want to continue? (yes/no): " confirm
    
    if [ "$confirm" != "yes" ]; then
        print_info "Publication cancelled"
        exit 0
    fi
    
    echo ""
    echo "You will need your PyPI credentials"
    echo "Visit: https://pypi.org/account/register/"
    echo ""
    python3 -m twine upload dist/* || {
        print_error "Upload to PyPI failed!"
        exit 1
    }
    print_success "Successfully published to PyPI!"
    echo ""
    echo "Install from PyPI with:"
    echo "  pip install handex"
fi

echo ""
print_success "All done! 🎉"
