#!/usr/bin/env python3
"""
Example usage of the hand tracker with integrated 3D visualization.
"""

import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from hand_tracking.hand_detector import HandDetector


def main():
    """Example usage."""
    print("Hand Tracker - Example Usage")
    print("=" * 50)
    print()
    
    # Initialize detector
    detector = HandDetector()
    
    print("Choose visualization mode:")
    print("1. 2D (OpenCV window)")
    print("2. 3D (matplotlib with coordinate axes)")
    print("3. Combined (2D + 3D side by side)")
    print("4. Rerun (modern 3D viewer with timeline)")

    choice = input("\nEnter choice (1-4): ").strip()

    if choice == "1":
        print("\nStarting 2D visualization...")
        detector.run_interactive(mode='2d')
    elif choice == "2":
        print("\nStarting 3D visualization...")
        print("Features:")
        print("  - Coordinate axes at wrist and fingertips")
        print("  - X axis = red, Y axis = green, Z axis = blue")
        print("  - Color-coded finger bones")
        print()
        detector.run_interactive(mode='3d')
    elif choice == "3":
        print("\nStarting combined visualization...")
        print("Features:")
        print("  - Camera feed on left")
        print("  - 3D plots with axes on right")
        print("  - Real-time statistics")
        print()
        detector.run_interactive(mode='combined')
    elif choice == "4":
        print("\nStarting Rerun visualization...")
        print("Features:")
        print("  - Modern 3D viewer with smooth interaction")
        print("  - Timeline scrubbing and playback")
        print("  - Side-by-side 2D camera + 3D hands view")
        print("  - Color-coded finger visualization")
        print()
        print("Note: Requires rerun-sdk (pip install rerun-sdk)")
        print()
        detector.run_interactive(mode='rerun')
    else:
        print("Invalid choice, using 3D mode...")
        detector.run_interactive(mode='3d')


if __name__ == "__main__":
    main()

