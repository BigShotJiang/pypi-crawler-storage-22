#!/usr/bin/env python3
"""
Hand detection using MediaPipe for data collection.

This module handles real-time hand landmark detection and tracking.
Supports both legacy MediaPipe (< 0.10) and new Tasks API (>= 0.10).
"""

import cv2
import numpy as np
from typing import Dict, List, Optional, Tuple, NamedTuple
import yaml
from dataclasses import dataclass
from pathlib import Path
import urllib.request
import os

# Detect MediaPipe version and import accordingly
import mediapipe as mp

MEDIAPIPE_TASKS_API = False
mp_tasks = None
vision = None

try:
    # Check if new Tasks API is available (MediaPipe >= 0.10)
    from mediapipe.tasks import python as mp_tasks
    from mediapipe.tasks.python import vision
    MEDIAPIPE_TASKS_API = True
except (ImportError, AttributeError):
    pass


@dataclass
class HandLandmarks:
    """Container for hand landmark data."""
    landmarks: np.ndarray  # Shape: (21, 3) - x, y, z in pixels
    handedness: str  # "Left" or "Right"
    confidence: float
    bbox: Tuple[int, int, int, int]  # x, y, width, height

    @property
    def landmarks_3d(self) -> np.ndarray:
        """Get landmarks in 3D metric space (meters). Shape: (21, 3)."""
        return self.get_normalized_landmarks()

    def get_normalized_landmarks(self, palm_size_meters: float = 0.08,
                                 image_center: Tuple[float, float] = (640, 360),
                                 reference_distance_m: float = 0.5,
                                 reference_palm_width_px: float = 180.0) -> np.ndarray:
        """
        Get landmarks scaled to realistic hand proportions with depth estimation.

        Centers on image center (not wrist) so hand position tracks movement in frame.
        Scales so palm width ≈ palm_size_meters with uniform scaling on all axes.
        Estimates Z depth from palm size using perspective geometry.

        Args:
            palm_size_meters: Target palm width in meters (default 0.08m for adult hand)
            image_center: Center of image in pixels (x, y), default (640, 360) for 1280x720
            reference_distance_m: Distance from camera during calibration in meters
            reference_palm_width_px: Palm width in pixels at reference distance

        Returns:
            np.ndarray: Normalized landmarks in meters, shape (21, 3)
        """
        # Calculate current palm width in pixels (wrist to middle finger MCP)
        wrist = self.landmarks[0]
        middle_mcp = self.landmarks[9]
        palm_width_px = np.sqrt((middle_mcp[0] - wrist[0])**2 +
                                (middle_mcp[1] - wrist[1])**2)

        # Scale factor: convert pixels to meters based on palm size
        if palm_width_px > 1.0:
            scale = palm_size_meters / palm_width_px
        else:
            scale = 0.001  # fallback for invalid detection

        # Estimate camera distance from palm size (perspective geometry)
        # closer hand = bigger palm, farther = smaller
        if palm_width_px > 1.0:
            estimated_distance_m = reference_distance_m * (reference_palm_width_px / palm_width_px)
        else:
            estimated_distance_m = reference_distance_m

        # Z offset from reference distance (positive = farther, negative = closer)
        z_base = estimated_distance_m - reference_distance_m

        # Center on IMAGE CENTER (not wrist) and scale all axes uniformly
        # This allows the hand to move in 3D space as it moves in the frame
        normalized = self.landmarks.copy()
        normalized[:, 0] = (self.landmarks[:, 0] - image_center[0]) * scale
        normalized[:, 1] = (self.landmarks[:, 1] - image_center[1]) * scale
        # MediaPipe z is relative finger depth within hand - add to estimated camera distance
        normalized[:, 2] = z_base + (self.landmarks[:, 2] * scale)

        return normalized
    
    def get_palm_width(self) -> float:
        """
        Get the palm width in pixels (distance between wrist and middle finger MCP).
        
        Returns:
            float: Palm width in pixels
        """
        wrist = self.landmarks[0]
        middle_mcp = self.landmarks[9]
        return np.sqrt((middle_mcp[0] - wrist[0])**2 + (middle_mcp[1] - wrist[1])**2)


class HandDetector:
    """Real-time hand detection and tracking using MediaPipe."""
    
    def __init__(self, config_path: Optional[str] = None):
        """Initialize hand detector with configuration."""
        self.config = self._load_config(config_path)
        self._setup_mediapipe()
        self._setup_camera()
        
        # Load calibrated reference palm width if available
        self.reference_palm_width = self._get_reference_palm_width()

        # Load calibration parameters for metric conversion
        self.reference_distance_m, self.calibrated_palm_width_px = self._get_calibration_params()

        # Tracking state
        self.is_tracking = False
        self.frame_count = 0
        self.last_landmarks = {}
        self.last_hands = []  # Cache for frame skipping
        
    def _load_config(self, config_path: Optional[str]) -> Dict:
        """Load configuration from YAML file."""
        if config_path is None:
            # Default configuration
            return {
                'hand_tracking': {
                    'camera': {'device_id': 0, 'width': 1280, 'height': 720, 'fps': 30},
                    'mediapipe': {
                        'max_num_hands': 2,
                        'min_detection_confidence': 0.7,
                        'min_tracking_confidence': 0.5,
                        'model_complexity': 1
                    },
                    'landmarks': {'smoothing_factor': 0.8, 'confidence_threshold': 0.6},
                    'display': {
                        'show_landmarks': True,
                        'show_connections': True,
                        'show_bounding_box': True,
                        'window_name': 'Hand Tracking'
                    }
                }
            }
        
        with open(config_path, 'r') as f:
            return yaml.safe_load(f)
    
    def _get_reference_palm_width(self) -> float:
        """Get reference palm width from config or use default."""
        # Check for calibrated value first
        if 'hand_tracking' in self.config:
            if 'normalization' in self.config['hand_tracking']:
                ref = self.config['hand_tracking']['normalization'].get('reference_palm_width')
                if ref is not None:
                    print(f"✓ Using calibrated reference palm width: {ref:.2f}px")
                    return float(ref)

        # Check old calibration format
        if 'calibration' in self.config:
            ref = self.config['calibration'].get('reference_palm_width')
            if ref is not None:
                print(f"✓ Using calibrated reference palm width: {ref:.2f}px")
                return float(ref)

        # Default value
        return 100.0

    def _get_calibration_params(self) -> Tuple[float, float]:
        """Get calibration parameters from config.

        Returns:
            Tuple of (reference_distance_m, calibrated_palm_width_px)
        """
        if 'calibration' in self.config:
            ref_dist = self.config['calibration'].get('reference_distance_cm', 50.0) / 100.0  # convert to meters
            ref_palm = self.config['calibration'].get('reference_palm_width', 166.37)
            return ref_dist, ref_palm
        return 0.50, 166.37  # defaults in meters

    def _get_reference_distance_m(self) -> float:
        """Get reference distance in meters from config."""
        if 'calibration' in self.config:
            ref_cm = self.config['calibration'].get('reference_distance_cm', 50.0)
            return ref_cm / 100.0
        return 0.50
    
    def _setup_mediapipe(self):
        """Initialize MediaPipe hands solution."""
        mp_config = self.config['hand_tracking']['mediapipe']

        if MEDIAPIPE_TASKS_API:
            # New Tasks API (MediaPipe >= 0.10)
            self._setup_mediapipe_tasks(mp_config)
        else:
            # Legacy API (MediaPipe < 0.10)
            self._setup_mediapipe_legacy(mp_config)

    def _setup_mediapipe_tasks(self, mp_config: Dict):
        """Initialize MediaPipe using the new Tasks API (>= 0.10)."""
        # Download model if needed
        model_path = self._get_hand_landmarker_model()

        # Configure options
        base_options = mp_tasks.BaseOptions(model_asset_path=str(model_path))
        options = vision.HandLandmarkerOptions(
            base_options=base_options,
            running_mode=vision.RunningMode.VIDEO,
            num_hands=mp_config['max_num_hands'],
            min_hand_detection_confidence=mp_config['min_detection_confidence'],
            min_hand_presence_confidence=mp_config['min_tracking_confidence'],
            min_tracking_confidence=mp_config['min_tracking_confidence'],
        )
        self.hand_landmarker = vision.HandLandmarker.create_from_options(options)
        self._frame_timestamp_ms = 0

        # For drawing, try to use solutions if available (some installs have both)
        try:
            self.mp_hands = mp.solutions.hands
            self.mp_drawing = mp.solutions.drawing_utils
            self.mp_drawing_styles = mp.solutions.drawing_styles
            self._can_draw_mp = True
        except AttributeError:
            # Solutions not available - will use OpenCV fallback for drawing
            self._can_draw_mp = False

    def _setup_mediapipe_legacy(self, mp_config: Dict):
        """Initialize MediaPipe using legacy API (< 0.10)."""
        self.mp_hands = mp.solutions.hands
        self.mp_drawing = mp.solutions.drawing_utils
        self.mp_drawing_styles = mp.solutions.drawing_styles
        self._can_draw_mp = True

        self.hands = self.mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=mp_config['max_num_hands'],
            min_detection_confidence=mp_config['min_detection_confidence'],
            min_tracking_confidence=mp_config['min_tracking_confidence'],
            model_complexity=mp_config['model_complexity']
        )

    def _get_hand_landmarker_model(self) -> Path:
        """Download the hand landmarker model if not present."""
        # Store in user's cache directory
        cache_dir = Path.home() / '.cache' / 'handex'
        cache_dir.mkdir(parents=True, exist_ok=True)
        model_path = cache_dir / 'hand_landmarker.task'

        if not model_path.exists():
            print("Downloading hand landmarker model...")
            url = "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/latest/hand_landmarker.task"
            urllib.request.urlretrieve(url, model_path)
            print(f"Model saved to {model_path}")

        return model_path
    
    def _setup_camera(self):
        """Initialize camera capture."""
        camera_config = self.config['hand_tracking']['camera']
        self.cap = cv2.VideoCapture(camera_config['device_id'])
        
        # Set camera properties
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, camera_config['width'])
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, camera_config['height'])
        self.cap.set(cv2.CAP_PROP_FPS, camera_config['fps'])
        
        if not self.cap.isOpened():
            raise RuntimeError(f"Failed to open camera {camera_config['device_id']}")
    
    def start_tracking(self):
        """Start hand tracking."""
        self.is_tracking = True
        self.frame_count = 0
        print("Hand tracking started. Press 'q' to quit.")
    
    def stop_tracking(self):
        """Stop hand tracking."""
        self.is_tracking = False
        print("Hand tracking stopped.")
    
    def get_frame(self) -> Optional[np.ndarray]:
        """Capture a frame from the camera."""
        if not self.cap.isOpened():
            return None
            
        ret, frame = self.cap.read()
        if not ret:
            return None
            
        # Flip frame horizontally for mirror effect
        frame = cv2.flip(frame, 1)
        return frame
    
    def detect_hands(self, frame: np.ndarray) -> List[HandLandmarks]:
        """Detect hands in the given frame."""
        if frame is None:
            return []

        if MEDIAPIPE_TASKS_API:
            return self._detect_hands_tasks(frame)
        else:
            return self._detect_hands_legacy(frame)

    def _detect_hands_tasks(self, frame: np.ndarray) -> List[HandLandmarks]:
        """Detect hands using the new Tasks API (>= 0.10)."""
        # Convert BGR to RGB
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        # Create MediaPipe Image
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb_frame)

        # Process frame
        self._frame_timestamp_ms += 33  # ~30fps
        results = self.hand_landmarker.detect_for_video(mp_image, self._frame_timestamp_ms)

        detected_hands = []

        if results.hand_landmarks and results.handedness:
            for hand_landmarks, handedness in zip(results.hand_landmarks, results.handedness):
                # Extract landmark coordinates
                landmarks = self._extract_landmarks_tasks(hand_landmarks, frame.shape)

                # Get handedness (Tasks API returns list of Category)
                hand_label = handedness[0].category_name
                confidence = handedness[0].score

                # Calculate bounding box
                bbox = self._calculate_bbox(landmarks, frame.shape)

                # Apply smoothing if we have previous landmarks
                if hand_label in self.last_landmarks:
                    landmarks = self._apply_smoothing(landmarks, self.last_landmarks[hand_label])

                # Store current landmarks for next frame
                self.last_landmarks[hand_label] = landmarks.copy()

                # Create HandLandmarks object
                hand_data = HandLandmarks(
                    landmarks=landmarks,
                    handedness=hand_label,
                    confidence=confidence,
                    bbox=bbox
                )

                detected_hands.append(hand_data)

        return detected_hands

    def _detect_hands_legacy(self, frame: np.ndarray) -> List[HandLandmarks]:
        """Detect hands using the legacy API (< 0.10)."""
        # Convert BGR to RGB (MediaPipe requires RGB)
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        # Improve performance by marking the image as not writeable
        rgb_frame.flags.writeable = False

        # Process frame with MediaPipe
        results = self.hands.process(rgb_frame)

        # Mark image as writeable again
        rgb_frame.flags.writeable = True

        detected_hands = []

        if results.multi_hand_landmarks and results.multi_handedness:
            for hand_landmarks, handedness in zip(results.multi_hand_landmarks, results.multi_handedness):
                # Extract landmark coordinates
                landmarks = self._extract_landmarks(hand_landmarks, frame.shape)

                # Get handedness
                hand_label = handedness.classification[0].label
                confidence = handedness.classification[0].score

                # Calculate bounding box
                bbox = self._calculate_bbox(landmarks, frame.shape)

                # Apply smoothing if we have previous landmarks
                if hand_label in self.last_landmarks:
                    landmarks = self._apply_smoothing(landmarks, self.last_landmarks[hand_label])

                # Store current landmarks for next frame
                self.last_landmarks[hand_label] = landmarks.copy()

                # Create HandLandmarks object
                hand_data = HandLandmarks(
                    landmarks=landmarks,
                    handedness=hand_label,
                    confidence=confidence,
                    bbox=bbox
                )

                detected_hands.append(hand_data)

        return detected_hands
    
    def _extract_landmarks(self, hand_landmarks, frame_shape: Tuple[int, int, int]) -> np.ndarray:
        """Extract landmark coordinates from MediaPipe results (legacy API)."""
        height, width = frame_shape[:2]
        landmarks = np.zeros((21, 3))

        for i, landmark in enumerate(hand_landmarks.landmark):
            landmarks[i] = [
                landmark.x * width,   # x in pixel space
                landmark.y * height,  # y in pixel space
                landmark.z * width    # z in pixel space (same scale as x per MediaPipe docs)
            ]

        return landmarks

    def _extract_landmarks_tasks(self, hand_landmarks, frame_shape: Tuple[int, int, int]) -> np.ndarray:
        """Extract landmark coordinates from MediaPipe Tasks API results."""
        height, width = frame_shape[:2]
        landmarks = np.zeros((21, 3))

        for i, landmark in enumerate(hand_landmarks):
            landmarks[i] = [
                landmark.x * width,   # x in pixel space
                landmark.y * height,  # y in pixel space
                landmark.z * width    # z in pixel space
            ]

        return landmarks
    
    def _calculate_bbox(self, landmarks: np.ndarray, frame_shape: Tuple[int, int, int]) -> Tuple[int, int, int, int]:
        """Calculate bounding box around hand landmarks."""
        x_coords = landmarks[:, 0]
        y_coords = landmarks[:, 1]
        
        x_min, x_max = int(np.min(x_coords)), int(np.max(x_coords))
        y_min, y_max = int(np.min(y_coords)), int(np.max(y_coords))
        
        # Add padding
        padding = 20
        x_min = max(0, x_min - padding)
        y_min = max(0, y_min - padding)
        x_max = min(frame_shape[1], x_max + padding)
        y_max = min(frame_shape[0], y_max + padding)
        
        return (x_min, y_min, x_max - x_min, y_max - y_min)
    
    def _apply_smoothing(self, current_landmarks: np.ndarray, previous_landmarks: np.ndarray) -> np.ndarray:
        """Apply temporal smoothing to landmarks."""
        alpha = self.config['hand_tracking']['landmarks']['smoothing_factor']
        return alpha * previous_landmarks + (1 - alpha) * current_landmarks
    
    def draw_landmarks(self, frame: np.ndarray, hands: List[HandLandmarks]) -> np.ndarray:
        """Draw hand landmarks and connections on the frame."""
        display_config = self.config['hand_tracking']['display']

        for hand in hands:
            if display_config['show_landmarks']:
                if getattr(self, '_can_draw_mp', False):
                    # Use MediaPipe drawing utilities if available
                    mp_landmarks = self._landmarks_to_mediapipe(hand.landmarks, frame.shape)
                    self.mp_drawing.draw_landmarks(
                        frame,
                        mp_landmarks,
                        self.mp_hands.HAND_CONNECTIONS,
                        self.mp_drawing_styles.get_default_hand_landmarks_style(),
                        self.mp_drawing_styles.get_default_hand_connections_style()
                    )
                else:
                    # Fallback: draw landmarks manually with OpenCV
                    self._draw_landmarks_opencv(frame, hand.landmarks)

            if display_config['show_bounding_box']:
                # Draw bounding box
                x, y, w, h = hand.bbox
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

                # Draw hand label
                label = f"{hand.handedness} ({hand.confidence:.2f})"
                cv2.putText(frame, label, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

        return frame

    def _draw_landmarks_opencv(self, frame: np.ndarray, landmarks: np.ndarray):
        """Draw landmarks using pure OpenCV (fallback when mp.solutions unavailable)."""
        # Hand connections (matching MediaPipe HAND_CONNECTIONS)
        connections = [
            (0, 1), (1, 2), (2, 3), (3, 4),  # Thumb
            (0, 5), (5, 6), (6, 7), (7, 8),  # Index
            (0, 9), (9, 10), (10, 11), (11, 12),  # Middle
            (0, 13), (13, 14), (14, 15), (15, 16),  # Ring
            (0, 17), (17, 18), (18, 19), (19, 20),  # Pinky
            (5, 9), (9, 13), (13, 17),  # Palm
        ]

        # Draw connections
        for start, end in connections:
            pt1 = (int(landmarks[start, 0]), int(landmarks[start, 1]))
            pt2 = (int(landmarks[end, 0]), int(landmarks[end, 1]))
            cv2.line(frame, pt1, pt2, (0, 255, 0), 2)

        # Draw landmarks
        for i, lm in enumerate(landmarks):
            pt = (int(lm[0]), int(lm[1]))
            color = (255, 0, 0) if i in [4, 8, 12, 16, 20] else (0, 0, 255)  # Fingertips in blue
            cv2.circle(frame, pt, 5, color, -1)
    
    def _landmarks_to_mediapipe(self, landmarks: np.ndarray, frame_shape: Tuple[int, int, int]):
        """Convert landmarks back to MediaPipe format for drawing."""
        try:
            from mediapipe.framework.formats import landmark_pb2
        except ImportError:
            # If protobuf format not available, return None (will use OpenCV fallback)
            return None

        height, width = frame_shape[:2]

        # Create proper MediaPipe NormalizedLandmarkList
        landmark_list = landmark_pb2.NormalizedLandmarkList()

        for i in range(21):
            landmark = landmark_list.landmark.add()
            landmark.x = landmarks[i, 0] / width
            landmark.y = landmarks[i, 1] / height
            landmark.z = landmarks[i, 2]

        return landmark_list
    
    def run_interactive(self, mode='combined'):
        """Run interactive hand tracking with visualization.

        Args:
            mode: '2d' for OpenCV window, '3d' for matplotlib 3D,
                  'combined' for both, 'rerun' for Rerun SDK visualization
        """
        if mode == '3d':
            return self.run_3d_visualization()
        elif mode == 'combined':
            return self.run_combined_visualization()
        elif mode == 'rerun':
            return self.run_rerun_visualization()
        
        # Default 2D mode
        self.start_tracking()
        
        try:
            while self.is_tracking:
                frame = self.get_frame()
                if frame is None:
                    break
                
                # Detect hands
                hands = self.detect_hands(frame)
                
                # Draw landmarks
                frame = self.draw_landmarks(frame, hands)
                
                # Add frame info
                cv2.putText(frame, f"Frame: {self.frame_count}", (10, 30), 
                           cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
                cv2.putText(frame, f"Hands: {len(hands)}", (10, 70), 
                           cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
                
                # Display frame
                window_name = self.config['hand_tracking']['display']['window_name']
                cv2.imshow(window_name, frame)
                
                # Check for quit
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
                
                self.frame_count += 1
                
        except KeyboardInterrupt:
            print("\nInterrupted by user")
        finally:
            self.cleanup()
    
    def run_3d_visualization(self):
        """Run 3D visualization using matplotlib."""
        try:
            import matplotlib.pyplot as plt
            from matplotlib.animation import FuncAnimation
            from mpl_toolkits.mplot3d import Axes3D
            import matplotlib
            matplotlib.use('TkAgg')
        except ImportError:
            print("❌ matplotlib is required for 3D visualization")
            print("Install with: pip install matplotlib")
            return
        
        from .visualizer_3d import Hand3DVisualizer
        visualizer = Hand3DVisualizer(self)
        visualizer.run()
    
    def run_combined_visualization(self):
        """Run combined 2D + 3D visualization."""
        try:
            import matplotlib.pyplot as plt
            from matplotlib.animation import FuncAnimation
            from mpl_toolkits.mplot3d import Axes3D
            import matplotlib
            matplotlib.use('TkAgg')
        except ImportError:
            print("❌ matplotlib is required for combined visualization")
            print("Install with: pip install matplotlib")
            return

        from .visualizer_combined import CombinedVisualizer
        visualizer = CombinedVisualizer(self)
        visualizer.run()

    def run_rerun_visualization(self):
        """Run Rerun-based visualization.

        Provides improved real-time performance and better 3D interaction
        compared to matplotlib-based visualization.
        """
        try:
            import rerun as rr
        except ImportError:
            print("❌ Rerun is required for this visualization mode")
            print("Install with: pip install rerun-sdk")
            return

        from .visualizer_rerun import RerunVisualizer
        visualizer = RerunVisualizer(self)
        visualizer.run()

    def cleanup(self):
        """Clean up resources."""
        self.stop_tracking()
        try:
            if hasattr(self, 'cap') and self.cap is not None:
                self.cap.release()
        except Exception:
            pass
        try:
            if hasattr(self, 'hand_landmarker') and self.hand_landmarker is not None:
                self.hand_landmarker.close()
        except Exception:
            pass
        try:
            if hasattr(self, 'hands') and self.hands is not None:
                self.hands.close()
        except Exception:
            pass
        try:
            cv2.destroyAllWindows()
        except Exception:
            pass

    def __del__(self):
        """Destructor to ensure cleanup."""
        try:
            self.cleanup()
        except Exception:
            pass


if __name__ == "__main__":
    # Test the hand detector
    detector = HandDetector()
    detector.run_interactive()
