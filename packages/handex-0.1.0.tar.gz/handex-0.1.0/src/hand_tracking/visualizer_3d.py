"""3D visualization module for hand tracking."""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from mpl_toolkits.mplot3d import Axes3D
import matplotlib


class Hand3DVisualizer:
    """3D visualization of hand landmarks using matplotlib."""
    
    # MediaPipe hand connections
    HAND_CONNECTIONS = [
        (0, 1), (1, 2), (2, 3), (3, 4),      # Thumb
        (0, 5), (5, 6), (6, 7), (7, 8),      # Index
        (0, 9), (9, 10), (10, 11), (11, 12), # Middle
        (0, 13), (13, 14), (14, 15), (15, 16), # Ring
        (0, 17), (17, 18), (18, 19), (19, 20), # Pinky
        (5, 9), (9, 13), (13, 17)            # Palm
    ]
    
    FINGER_COLORS = {
        'thumb': '#FF6B6B',
        'index': '#4ECDC4',
        'middle': '#45B7D1',
        'ring': '#96CEB4',
        'pinky': '#FFEAA7',
        'palm': '#DFE6E9'
    }
    
    def __init__(self, detector):
        """Initialize with hand detector."""
        self.detector = detector
        self.is_running = False
        
        # Create figure
        self.fig = plt.figure(figsize=(15, 6))
        
        # 3D plots
        self.ax_left = self.fig.add_subplot(121, projection='3d')
        self.ax_left.set_title('Left Hand', fontsize=14, fontweight='bold')
        
        self.ax_right = self.fig.add_subplot(122, projection='3d')
        self.ax_right.set_title('Right Hand', fontsize=14, fontweight='bold')
        
        # Setup axes
        for ax in [self.ax_left, self.ax_right]:
            self._setup_axis(ax)
        
        # Initialize plots
        self.left_hand_plots = self._init_hand_plots(self.ax_left)
        self.right_hand_plots = self._init_hand_plots(self.ax_right)
        
        plt.tight_layout()
    
    def _setup_axis(self, ax):
        """Setup 3D axis with metric units (meters).

        Axis limits accommodate hand movement across the frame:
        - X/Y: ±0.3m (hand can be ~300px from center, 300 * ~0.0005 scale ≈ 0.15m)
        - Z: ±0.15m (depth range for hand distance variations)
        """
        ax.set_xlim([-0.30, 0.30])
        ax.set_ylim([-0.30, 0.30])
        ax.set_zlim([-0.15, 0.15])
        ax.set_xlabel('X (m)', fontsize=10)
        ax.set_ylabel('Y (m)', fontsize=10)
        ax.set_zlabel('Z (m)', fontsize=10)
        ax.view_init(elev=15, azim=45)
        ax.grid(True, alpha=0.3)
    
    def _init_hand_plots(self, ax):
        """Initialize plot elements."""
        plots = {}
        
        # Landmarks
        plots['landmarks'] = ax.scatter([], [], [], c='red', s=50, alpha=0.8)
        
        # Connections
        plots['connections'] = []
        for _ in self.HAND_CONNECTIONS:
            line, = ax.plot([], [], [], 'b-', linewidth=2, alpha=0.6)
            plots['connections'].append(line)
        
        # Coordinate axes for key landmarks
        plots['axes'] = []
        key_landmarks = [0, 4, 8, 12, 16, 20]
        for _ in key_landmarks:
            x_axis, = ax.plot([], [], [], 'r-', linewidth=1, alpha=0.7)
            y_axis, = ax.plot([], [], [], 'g-', linewidth=1, alpha=0.7)
            z_axis, = ax.plot([], [], [], 'b-', linewidth=1, alpha=0.7)
            plots['axes'].append([x_axis, y_axis, z_axis])
        
        # Text
        plots['text'] = ax.text2D(0.05, 0.95, '', transform=ax.transAxes,
                                 fontsize=10, verticalalignment='top')
        
        return plots
    
    def _get_connection_color(self, conn_idx):
        """Get color for connection."""
        start, end = self.HAND_CONNECTIONS[conn_idx]
        
        if max(start, end) <= 4:
            return self.FINGER_COLORS['thumb']
        elif max(start, end) <= 8:
            return self.FINGER_COLORS['index']
        elif max(start, end) <= 12:
            return self.FINGER_COLORS['middle']
        elif max(start, end) <= 16:
            return self.FINGER_COLORS['ring']
        elif max(start, end) <= 20:
            return self.FINGER_COLORS['pinky']
        else:
            return self.FINGER_COLORS['palm']
    
    def _update_hand_plot(self, ax, plots, hand_data):
        """Update 3D plot for one hand."""
        if hand_data is None:
            plots['landmarks']._offsets3d = ([], [], [])
            for line in plots['connections']:
                line.set_data([], [])
                line.set_3d_properties([])
            for axis_lines in plots['axes']:
                for line in axis_lines:
                    line.set_data([], [])
                    line.set_3d_properties([])
            plots['text'].set_text('No hand detected')
            return
        
        # Get normalized landmarks in meters (palm width ≈ 0.08m)
        # Pass calibration params for depth estimation from palm size
        normalized = hand_data.get_normalized_landmarks(
            palm_size_meters=0.08,
            reference_distance_m=self.detector.reference_distance_m,
            reference_palm_width_px=self.detector.calibrated_palm_width_px
        )
        
        # Update landmarks
        plots['landmarks']._offsets3d = (normalized[:, 0], normalized[:, 1], normalized[:, 2])
        
        # Update connections
        for idx, (start, end) in enumerate(self.HAND_CONNECTIONS):
            x_data = [normalized[start, 0], normalized[end, 0]]
            y_data = [normalized[start, 1], normalized[end, 1]]
            z_data = [normalized[start, 2], normalized[end, 2]]
            plots['connections'][idx].set_data(x_data, y_data)
            plots['connections'][idx].set_3d_properties(z_data)
            plots['connections'][idx].set_color(self._get_connection_color(idx))
        
        # Update coordinate axes
        key_landmarks = [0, 4, 8, 12, 16, 20]
        axis_length = 0.01  # 1cm axis lines in meters
        
        for i, landmark_idx in enumerate(key_landmarks):
            if i < len(plots['axes']):
                point = normalized[landmark_idx]
                
                # X axis (red)
                plots['axes'][i][0].set_data([point[0], point[0] + axis_length], [point[1], point[1]])
                plots['axes'][i][0].set_3d_properties([point[2], point[2]])
                
                # Y axis (green)
                plots['axes'][i][1].set_data([point[0], point[0]], [point[1], point[1] + axis_length])
                plots['axes'][i][1].set_3d_properties([point[2], point[2]])
                
                # Z axis (blue)
                plots['axes'][i][2].set_data([point[0], point[0]], [point[1], point[1]])
                plots['axes'][i][2].set_3d_properties([point[2], point[2] + axis_length])
        
        # Update text (show wrist position to verify hand tracking in 3D space)
        wrist = normalized[0]
        plots['text'].set_text(f"{hand_data.handedness}\nConf: {hand_data.confidence:.2f}\nWrist: ({wrist[0]*100:.1f}, {wrist[1]*100:.1f}, {wrist[2]*100:.1f})cm")
    
    def update(self, frame_num):
        """Animation update."""
        frame = self.detector.get_frame()
        if frame is None:
            return []
        
        hands = self.detector.detect_hands(frame)
        
        left_hand = next((h for h in hands if h.handedness == 'Left'), None)
        right_hand = next((h for h in hands if h.handedness == 'Right'), None)
        
        self._update_hand_plot(self.ax_left, self.left_hand_plots, left_hand)
        self._update_hand_plot(self.ax_right, self.right_hand_plots, right_hand)
        
        self.fig.suptitle(f'3D Hand Tracking - Frame: {self.detector.frame_count}',
                         fontsize=16, fontweight='bold')
        
        self.detector.frame_count += 1
        return []
    
    def run(self):
        """Run visualization."""
        print("Starting 3D visualization...")
        print("Controls: Rotate (drag), Zoom (scroll), Close window to exit")
        
        self.is_running = True
        
        try:
            anim = FuncAnimation(self.fig, self.update, interval=33, blit=False)
            plt.show()
        except KeyboardInterrupt:
            print("\nVisualization stopped")
        finally:
            self.cleanup()
    
    def cleanup(self):
        """Cleanup."""
        self.is_running = False
        plt.close('all')
