"""Rerun-based visualization module for hand tracking.

This module provides real-time hand visualization using the Rerun SDK,
offering improved performance and better 3D interaction compared to matplotlib.
"""

import numpy as np
import cv2
from typing import Optional, List

try:
    import rerun as rr
    import rerun.blueprint as rrb
    RERUN_AVAILABLE = True
except ImportError:
    RERUN_AVAILABLE = False


class RerunVisualizer:
    """Real-time hand visualization using Rerun SDK."""

    # MediaPipe hand connections grouped by finger
    FINGER_CONNECTIONS = {
        'thumb': [(0, 1), (1, 2), (2, 3), (3, 4)],
        'index': [(0, 5), (5, 6), (6, 7), (7, 8)],
        'middle': [(0, 9), (9, 10), (10, 11), (11, 12)],
        'ring': [(0, 13), (13, 14), (14, 15), (15, 16)],
        'pinky': [(0, 17), (17, 18), (18, 19), (19, 20)],
        'palm': [(5, 9), (9, 13), (13, 17)],
    }

    # Colors for each finger (RGB format)
    FINGER_COLORS = {
        'thumb': [255, 107, 107],   # Red
        'index': [78, 205, 196],    # Teal
        'middle': [69, 183, 209],   # Blue
        'ring': [150, 206, 180],    # Green
        'pinky': [255, 234, 167],   # Yellow
        'palm': [223, 230, 233],    # Gray
    }

    # Landmark indices for each finger
    FINGER_LANDMARKS = {
        'thumb': [1, 2, 3, 4],
        'index': [5, 6, 7, 8],
        'middle': [9, 10, 11, 12],
        'ring': [13, 14, 15, 16],
        'pinky': [17, 18, 19, 20],
        'palm': [0],  # Wrist
    }

    def __init__(self, detector):
        """Initialize with hand detector.

        Args:
            detector: HandDetector instance for accessing camera and detection.
        """
        if not RERUN_AVAILABLE:
            raise ImportError(
                "Rerun SDK is required for this visualization mode.\n"
                "Install with: pip install rerun-sdk"
            )

        self.detector = detector
        self.is_running = False
        self._setup_rerun()

    def _setup_rerun(self):
        """Initialize Rerun recording and send blueprint."""
        # Initialize Rerun with application name
        rr.init("hand_tracking", spawn=True)

        # Create blueprint for layout
        blueprint = rrb.Horizontal(
            rrb.Spatial2DView(
                name="Camera",
                origin="world/camera",
            ),
            rrb.Spatial3DView(
                name="3D Hands",
                origin="world/hands_3d",
            ),
            column_shares=[1, 1],
        )

        # Send the blueprint
        rr.send_blueprint(blueprint)

        # Log initial coordinate system info
        rr.log("world/hands_3d", rr.ViewCoordinates.RIGHT_HAND_Y_DOWN, static=True)

    def _get_landmark_color(self, landmark_idx: int) -> List[int]:
        """Get color for a specific landmark index.

        Args:
            landmark_idx: Index of the landmark (0-20).

        Returns:
            RGB color as list of 3 integers.
        """
        for finger, indices in self.FINGER_LANDMARKS.items():
            if landmark_idx in indices:
                return self.FINGER_COLORS[finger]
        return self.FINGER_COLORS['palm']

    def _log_hand_3d(self, hand_data, handedness: str):
        """Log 3D hand landmarks and connections to Rerun.

        Args:
            hand_data: HandLandmarks object with detection data.
            handedness: 'left' or 'right'.
        """
        if hand_data is None:
            # Clear the hand data if no detection
            rr.log(f"world/hands_3d/{handedness}/landmarks", rr.Clear(recursive=False))
            for finger in self.FINGER_CONNECTIONS:
                rr.log(f"world/hands_3d/{handedness}/{finger}", rr.Clear(recursive=False))
            return

        # Get normalized landmarks in meters (palm width ≈ 0.08m)
        # Pass calibration params for depth estimation from palm size
        normalized = hand_data.get_normalized_landmarks(
            palm_size_meters=0.08,
            reference_distance_m=self.detector.reference_distance_m,
            reference_palm_width_px=self.detector.calibrated_palm_width_px
        )

        # Prepare landmark data with colors
        # Radii in meters (coordinates are now metric)
        positions = normalized.tolist()
        colors = [self._get_landmark_color(i) for i in range(21)]
        radii = [0.008 if i == 0 else 0.005 for i in range(21)]  # ~8mm wrist, ~5mm joints

        # Log landmarks as 3D points
        rr.log(
            f"world/hands_3d/{handedness}/landmarks",
            rr.Points3D(
                positions=positions,
                colors=colors,
                radii=radii,
            )
        )

        # Log connections as line strips for each finger
        for finger, connections in self.FINGER_CONNECTIONS.items():
            strips = []
            for start_idx, end_idx in connections:
                strips.append([
                    normalized[start_idx].tolist(),
                    normalized[end_idx].tolist()
                ])

            rr.log(
                f"world/hands_3d/{handedness}/{finger}",
                rr.LineStrips3D(
                    strips=strips,
                    colors=[self.FINGER_COLORS[finger]],
                    radii=[0.002],  # ~2mm line thickness
                )
            )

        # Log metadata as text (positions now in meters)
        wrist_pos = normalized[0]
        rr.log(
            f"world/hands_3d/{handedness}/info",
            rr.TextLog(
                f"{hand_data.handedness} Hand | "
                f"Conf: {hand_data.confidence:.2f} | "
                f"Wrist: ({wrist_pos[0]:.3f}m, {wrist_pos[1]:.3f}m, {wrist_pos[2]:.3f}m)"
            )
        )

    def _log_camera_frame(self, frame: np.ndarray, hands: List):
        """Log camera frame with optional overlay to Rerun.

        Args:
            frame: BGR image from camera.
            hands: List of detected HandLandmarks.
        """
        if frame is None:
            return

        # Draw landmarks on frame
        frame_with_landmarks = self.detector.draw_landmarks(frame.copy(), hands)

        # Convert BGR to RGB for Rerun
        frame_rgb = cv2.cvtColor(frame_with_landmarks, cv2.COLOR_BGR2RGB)

        # Log the image
        rr.log("world/camera/image", rr.Image(frame_rgb))

        # Log frame metadata
        rr.log(
            "world/camera/info",
            rr.TextLog(f"Frame: {self.detector.frame_count} | Hands: {len(hands)}")
        )

    def update(self) -> bool:
        """Process one frame and log to Rerun.

        Returns:
            True if frame was processed successfully, False otherwise.
        """
        frame = self.detector.get_frame()
        if frame is None:
            return False

        # Detect hands
        hands = self.detector.detect_hands(frame)

        # Log camera frame with overlays
        self._log_camera_frame(frame, hands)

        # Find left and right hands
        left_hand = next((h for h in hands if h.handedness == 'Left'), None)
        right_hand = next((h for h in hands if h.handedness == 'Right'), None)

        # Log 3D hand data
        self._log_hand_3d(left_hand, 'left')
        self._log_hand_3d(right_hand, 'right')

        self.detector.frame_count += 1
        return True

    def run(self):
        """Run the main visualization loop."""
        print("Starting Rerun visualization...")
        print("The Rerun viewer should open automatically.")
        print("Features:")
        print("  - 2D camera view with landmark overlay")
        print("  - 3D hand visualization with color-coded fingers")
        print("  - Timeline scrubbing and playback controls")
        print("Press Ctrl+C to stop.")

        self.is_running = True

        try:
            while self.is_running:
                if not self.update():
                    print("Failed to get frame, stopping...")
                    break

                # Check for OpenCV window quit (optional backup)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break

        except KeyboardInterrupt:
            print("\nVisualization stopped by user")
        finally:
            self.cleanup()

    def cleanup(self):
        """Clean up resources."""
        self.is_running = False
        print("Rerun visualization cleanup complete.")
