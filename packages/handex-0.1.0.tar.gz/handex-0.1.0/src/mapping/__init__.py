"""
Kinematic mapping module for data collection.

This module provides hand-to-robot kinematic mapping, including:
- Hand landmark to joint angle conversion
- Inverse kinematics for arm positioning
- Finger gesture to gripper mapping
"""

from .kinematic_mapper import KinematicMapper

__all__ = ['KinematicMapper'] 