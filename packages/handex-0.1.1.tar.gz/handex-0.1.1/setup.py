#!/usr/bin/env python3
"""Setup script for handex package."""

from setuptools import setup, find_packages
from pathlib import Path

# Read the README file
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text()

# Read requirements
requirements = []
with open('requirements.txt') as f:
    requirements = [line.strip() for line in f if line.strip() and not line.startswith('#')]

setup(
    name="handex",
    version="0.1.1",
    author="Bruk Gebregziabher",
    author_email="bruk@signalbotics.com",
    description="Hand tracking system for robot teleoperation using MediaPipe",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/signalbotics/handex",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    extras_require={
        "dev": [
            "pytest>=7.0",
            "pytest-cov>=4.0",
            "black>=23.0",
            "flake8>=6.0",
            "mypy>=1.0",
        ],
        "vis": [
            "matplotlib>=3.5",
        ],
        "rerun": [
            "rerun-sdk>=0.18.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "hand-tracking=hand_tracking.cli:main",
            "handex-3d=hand_tracking.cli:main_3d",
            "handex-combined=hand_tracking.cli:main_combined",
            "handex-rerun=hand_tracking.cli:main_rerun",
            "handex-calibrate=hand_tracking.cli:calibrate",
        ],
    },
    include_package_data=True,
    package_data={
        "hand_tracking": ["../config/*.yaml"],
    },
)
