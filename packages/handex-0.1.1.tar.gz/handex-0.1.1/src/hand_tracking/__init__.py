"""Hand tracking package for robot teleoperation.

This package provides real-time hand tracking using MediaPipe with
scale-invariant 3D coordinate normalization for robust robot control.
"""

__version__ = "0.1.1"
__author__ = "Bruk Gebregziabher"
__email__ = "bruk@signalbotics.com"

from .hand_detector import HandDetector, HandLandmarks

__all__ = [
    "HandDetector",
    "HandLandmarks",
    "__version__",
]
