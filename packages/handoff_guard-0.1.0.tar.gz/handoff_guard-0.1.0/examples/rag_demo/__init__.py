"""RAG Pipeline Demo for handoff-guard."""
