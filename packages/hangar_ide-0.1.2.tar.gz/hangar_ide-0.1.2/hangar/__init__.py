"""Hangar — Orchestration-first IDE for spec-driven AI development."""
