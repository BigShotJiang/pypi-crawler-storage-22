"""Project configuration for Hangar."""

from pathlib import Path

from pydantic import BaseModel


class ProjectConfig(BaseModel):
    """Configuration for the loaded project."""

    path: Path
    has_beads: bool = False
    has_openspec: bool = False

    @classmethod
    def from_path(cls, path: Path) -> "ProjectConfig":
        """Create config by detecting tools in a project directory."""
        resolved = path.resolve()
        return cls(
            path=resolved,
            has_beads=(resolved / ".beads").is_dir(),
            has_openspec=(resolved / "openspec").is_dir(),
        )
