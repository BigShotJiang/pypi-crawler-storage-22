"""FastAPI dependency injection for services."""

import os
from pathlib import Path

from hangar.services.beads import BeadsService
from hangar.services.gitdiff import GitDiffService
from hangar.services.importsync import ImportSyncService
from hangar.services.openspec import OpenSpecService
from hangar.services.stats import StatsService
from hangar.services.timeline import TimelineService
from hangar.services.wizard import SpecWizardService

# Default project path — walk up from cwd to find .beads/ or openspec/ dir
def _discover_project_path() -> Path:
    """Resolve project path from HANGAR_PROJECT_PATH env var or by walking up from cwd.

    Walk-up boundaries (prevents escaping into unrelated projects):
    - Never use the home directory itself as project root
    - Stop at git repo root (don't cross into a parent repo)
    If no markers are found, default to cwd (fresh projects are fine —
    the agent will initialize .beads/ and openspec/ later).
    """
    env_path = os.environ.get("HANGAR_PROJECT_PATH")
    if env_path:
        resolved = Path(env_path).resolve()
        if resolved.is_dir():
            return resolved
    current = Path.cwd().resolve()
    home = Path.home().resolve()
    for parent in [current, *current.parents]:
        if parent == home:
            break  # never adopt ~ as project root
        if (parent / ".beads").is_dir() or (parent / "openspec").is_dir():
            return parent
        if (parent / ".git").exists() and parent != current:
            break  # don't escape the current git repo
    return current

_project_path: Path = _discover_project_path()

_beads_service: BeadsService | None = None
_openspec_service: OpenSpecService | None = None
_gitdiff_service: GitDiffService | None = None
_importsync_service: ImportSyncService | None = None
_wizard_service: SpecWizardService | None = None
_timeline_service: TimelineService | None = None
_stats_service: StatsService | None = None


def set_project_path(path: Path) -> None:
    """Set the project path and reset service instances."""
    global _project_path, _beads_service, _openspec_service, _gitdiff_service, _importsync_service, _wizard_service, _timeline_service, _stats_service
    _project_path = path.resolve()
    _beads_service = None
    _openspec_service = None
    _gitdiff_service = None
    _importsync_service = None
    _wizard_service = None
    _timeline_service = None
    _stats_service = None


def get_project_path() -> Path:
    """Get the current project path."""
    return _project_path


def get_beads_service() -> BeadsService:
    """Get or create the BeadsService singleton."""
    global _beads_service
    if _beads_service is None:
        _beads_service = BeadsService(project_path=_project_path)
    return _beads_service


def get_openspec_service() -> OpenSpecService:
    """Get or create the OpenSpecService singleton."""
    global _openspec_service
    if _openspec_service is None:
        _openspec_service = OpenSpecService(project_path=_project_path)
    return _openspec_service


def get_gitdiff_service() -> GitDiffService:
    """Get or create the GitDiffService singleton."""
    global _gitdiff_service
    if _gitdiff_service is None:
        _gitdiff_service = GitDiffService(project_path=_project_path)
    return _gitdiff_service


def get_wizard_service() -> SpecWizardService:
    """Get or create the SpecWizardService singleton."""
    global _wizard_service
    if _wizard_service is None:
        _wizard_service = SpecWizardService(project_path=_project_path)
    return _wizard_service


def get_importsync_service() -> ImportSyncService:
    """Get or create the ImportSyncService singleton."""
    global _importsync_service
    if _importsync_service is None:
        _importsync_service = ImportSyncService(
            project_path=_project_path,
            beads_service=get_beads_service(),
        )
    return _importsync_service


def get_timeline_service() -> TimelineService:
    """Get or create the TimelineService singleton."""
    global _timeline_service
    if _timeline_service is None:
        _timeline_service = TimelineService(
            beads_service=get_beads_service(),
        )
    return _timeline_service


def get_stats_service() -> StatsService:
    """Get or create the StatsService singleton."""
    global _stats_service
    if _stats_service is None:
        _stats_service = StatsService(
            beads_service=get_beads_service(),
        )
    return _stats_service
