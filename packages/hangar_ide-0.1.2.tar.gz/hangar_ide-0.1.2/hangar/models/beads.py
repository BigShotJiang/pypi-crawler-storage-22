"""Pydantic models for bd CLI JSON output."""

from datetime import datetime

from pydantic import BaseModel, Field


class BeadsDependencyRef(BaseModel):
    """A dependency reference as returned in bd list --json."""

    issue_id: str = ""
    depends_on_id: str = ""
    type: str = "blocks"
    created_at: datetime | None = None
    created_by: str = ""


class BeadsDependencyDetail(BaseModel):
    """A detailed dependency as returned in bd show --json."""

    id: str
    title: str
    description: str = ""
    status: str = "open"
    priority: int = 2
    issue_type: str = "task"
    assignee: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    closed_at: datetime | None = None
    dependency_type: str = "blocks"


class BeadsTask(BaseModel):
    """A beads task as returned by bd list/show --json."""

    id: str
    title: str
    description: str = ""
    status: str = "open"
    priority: int = 2
    issue_type: str = "task"
    assignee: str | None = None
    labels: list[str] = Field(default_factory=list)
    estimate: int | None = None
    notes: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    closed_at: datetime | None = None
    close_reason: str | None = None

    # From bd list --json
    dependencies: list[BeadsDependencyRef] = Field(default_factory=list)
    dependency_count: int = 0
    dependent_count: int = 0
    comment_count: int = 0

    # From bd show --json (detailed view with full dependency objects)
    dependents: list[BeadsDependencyDetail] = Field(default_factory=list)


class BeadsTaskList(BaseModel):
    """Wrapper for a list of beads tasks."""

    tasks: list[BeadsTask]

    @classmethod
    def from_json(cls, data: list[dict]) -> "BeadsTaskList":
        """Parse a list of task dicts from bd CLI output."""
        return cls(tasks=[BeadsTask.model_validate(t) for t in data])
