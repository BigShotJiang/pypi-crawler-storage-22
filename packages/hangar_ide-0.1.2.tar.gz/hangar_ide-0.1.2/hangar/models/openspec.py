"""Pydantic models for openspec CLI JSON output."""

from datetime import datetime

from pydantic import BaseModel, Field


class OpenSpecArtifact(BaseModel):
    """An artifact within an openspec change."""

    id: str
    output_path: str = Field(alias="outputPath")
    status: str = "pending"

    model_config = {"populate_by_name": True}


class OpenSpecChangeStatus(BaseModel):
    """Detailed status of a change from openspec status --json."""

    change_name: str = Field(alias="changeName")
    schema_name: str = Field(alias="schemaName")
    is_complete: bool = Field(alias="isComplete", default=False)
    apply_requires: list[str] = Field(alias="applyRequires", default_factory=list)
    artifacts: list[OpenSpecArtifact] = Field(default_factory=list)

    model_config = {"populate_by_name": True}


class OpenSpecChangeSummary(BaseModel):
    """A change summary as returned by openspec list --json."""

    name: str
    completed_tasks: int = Field(alias="completedTasks", default=0)
    total_tasks: int = Field(alias="totalTasks", default=0)
    last_modified: datetime | None = Field(alias="lastModified", default=None)
    status: str = "in-progress"
    is_archived: bool = False

    model_config = {"populate_by_name": True}


class OpenSpecChangeList(BaseModel):
    """Wrapper for openspec list --json output."""

    changes: list[OpenSpecChangeSummary]

    @classmethod
    def from_json(cls, data: dict) -> "OpenSpecChangeList":
        """Parse the openspec list --json output."""
        return cls.model_validate(data)


class OpenSpecArtifactContent(BaseModel):
    """An artifact with its rendered markdown content."""

    id: str
    output_path: str
    status: str = "pending"
    content: str = ""
