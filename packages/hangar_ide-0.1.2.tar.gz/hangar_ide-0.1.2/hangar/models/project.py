"""Pydantic models for project management."""

from pydantic import BaseModel


class ProjectInfo(BaseModel):
    """Current project information."""

    name: str
    path: str


class OpenProjectRequest(BaseModel):
    """Request to open/switch to a different project."""

    path: str
