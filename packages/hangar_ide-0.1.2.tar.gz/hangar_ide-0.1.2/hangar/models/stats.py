"""Pydantic models for project statistics."""

from datetime import datetime

from pydantic import BaseModel, Field


class EpicStats(BaseModel):
    """Statistics for a single epic."""

    epic_id: str
    epic_title: str
    task_count: int = 0
    closed_count: int = 0
    time_span_days: float | None = None
    first_created: datetime | None = None
    last_closed: datetime | None = None
    close_reason: str | None = None


class ProjectStats(BaseModel):
    """Aggregate project statistics."""

    total_tasks: int = 0
    closed_tasks: int = 0
    in_progress_tasks: int = 0
    open_tasks: int = 0
    completion_rate: float = 0.0
    avg_lead_time_hours: float | None = None
    time_span_days: float | None = None
    first_task_created: datetime | None = None
    last_task_closed: datetime | None = None
    throughput_per_day: float | None = None
    epic_stats: list[EpicStats] = Field(default_factory=list)
