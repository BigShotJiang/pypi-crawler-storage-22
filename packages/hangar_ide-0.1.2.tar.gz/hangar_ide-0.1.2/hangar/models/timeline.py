"""Pydantic models for timeline events."""

from datetime import datetime

from pydantic import BaseModel, Field


class TimelineEvent(BaseModel):
    """A single event in the project timeline."""

    event_type: str  # "created", "claimed", "closed"
    task_id: str
    task_title: str
    timestamp: datetime
    close_reason: str | None = None
    epic_id: str | None = None
    epic_title: str | None = None


class EpicGroup(BaseModel):
    """A group of timeline events under a single epic."""

    epic_id: str
    epic_title: str
    task_count: int
    events: list[TimelineEvent]


class TimelineResponse(BaseModel):
    """Response for the /api/timeline endpoint."""

    events: list[TimelineEvent] = Field(default_factory=list)
    epic_groups: list[EpicGroup] = Field(default_factory=list)
    total_events: int = 0
