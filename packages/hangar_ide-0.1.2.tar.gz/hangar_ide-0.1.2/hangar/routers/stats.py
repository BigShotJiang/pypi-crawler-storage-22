"""API router for project statistics."""

from fastapi import APIRouter, Depends, HTTPException

from hangar.dependencies import get_stats_service
from hangar.models.stats import ProjectStats
from hangar.services.stats import StatsService

router = APIRouter(prefix="/api/stats", tags=["stats"])


@router.get("")
async def get_stats(
    service: StatsService = Depends(get_stats_service),
) -> ProjectStats:
    """Get aggregate project statistics."""
    try:
        return await service.get_stats()
    except RuntimeError as e:
        raise HTTPException(status_code=502, detail=str(e))
