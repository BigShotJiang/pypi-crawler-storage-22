"""API router for project timeline."""

from fastapi import APIRouter, Depends, HTTPException

from hangar.dependencies import get_timeline_service
from hangar.models.timeline import TimelineResponse
from hangar.services.timeline import TimelineService

router = APIRouter(prefix="/api/timeline", tags=["timeline"])


@router.get("")
async def get_timeline(
    service: TimelineService = Depends(get_timeline_service),
) -> TimelineResponse:
    """Get the chronological project timeline."""
    try:
        return await service.get_timeline()
    except RuntimeError as e:
        raise HTTPException(status_code=502, detail=str(e))
