"""Shared test helpers for Hangar backend tests."""

import json
from pathlib import Path
from unittest.mock import AsyncMock

FIXTURES = Path(__file__).parent / "fixtures"

# ── Sample content ─────────────────────────────────────────────────

SAMPLE_TASKS_MD = """\
# Tasks — test-feature

## Phase 1: Foundation

- [ ] **1.1** Initialize project structure
  - Tests: verify directory layout exists
- [ ] **1.2** Create configuration module

## Phase 2: Core Logic

- [ ] **2.1** Implement data models
  - Tests: model validation round-trips
"""

SAMPLE_CONFIG_YAML = """\
context: "Test project for integration testing"
rules:
  proposal:
    - Keep it brief
  tasks:
    - One agent session per task
"""


def load_fixture(name: str) -> dict | list:
    """Read a JSON fixture file from tests/fixtures/."""
    return json.loads((FIXTURES / name).read_text())


def make_mock_process(
    stdout: str = "",
    stderr: str = "",
    returncode: int = 0,
) -> AsyncMock:
    """Factory for mock asyncio.subprocess.Process objects.

    Usage::

        proc = make_mock_process(stdout='{"id": "hangar-abc"}')
        with patch("asyncio.create_subprocess_exec", return_value=proc):
            ...
    """
    proc = AsyncMock()
    proc.communicate.return_value = (stdout.encode(), stderr.encode())
    proc.returncode = returncode
    # For wizard service timeout tests
    proc.kill = AsyncMock()
    proc.wait = AsyncMock()
    return proc
