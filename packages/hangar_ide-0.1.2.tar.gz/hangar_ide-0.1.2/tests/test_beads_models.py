"""Tests for beads Pydantic models."""

import json
from pathlib import Path

from hangar.models.beads import BeadsDependencyRef, BeadsTask, BeadsTaskList

FIXTURES = Path(__file__).parent / "fixtures"


def test_parse_bd_list_json() -> None:
    """Parse the full bd list --json output into models."""
    data = json.loads((FIXTURES / "bd_list.json").read_text())
    task_list = BeadsTaskList.from_json(data)

    assert len(task_list.tasks) > 0
    for task in task_list.tasks:
        assert task.id.startswith("hangar-")
        assert task.title
        assert task.status in ("open", "in_progress", "closed")
        assert task.issue_type == "task"


def test_parse_bd_ready_json() -> None:
    """Parse the bd ready --json output into models."""
    data = json.loads((FIXTURES / "bd_ready.json").read_text())
    task_list = BeadsTaskList.from_json(data)

    assert len(task_list.tasks) > 0
    for task in task_list.tasks:
        assert task.id.startswith("hangar-")


def test_parse_bd_show_json() -> None:
    """Parse the bd show --json output (includes dependents/dependencies)."""
    data = json.loads((FIXTURES / "bd_show.json").read_text())
    # bd show returns an array with one element
    task = BeadsTask.model_validate(data[0])

    assert task.id.startswith("hangar-")
    assert task.title


def test_task_with_dependencies() -> None:
    """Task model should handle dependency references."""
    task_data = {
        "id": "hangar-test",
        "title": "Test task",
        "status": "open",
        "priority": 1,
        "issue_type": "task",
        "dependencies": [
            {
                "issue_id": "hangar-test",
                "depends_on_id": "hangar-dep1",
                "type": "blocks",
                "created_by": "test",
            }
        ],
        "dependency_count": 1,
        "dependent_count": 0,
    }
    task = BeadsTask.model_validate(task_data)
    assert len(task.dependencies) == 1
    assert task.dependencies[0].depends_on_id == "hangar-dep1"
    assert task.dependency_count == 1


def test_task_minimal_fields() -> None:
    """Task model should work with only required fields."""
    task = BeadsTask(id="hangar-min", title="Minimal task")
    assert task.status == "open"
    assert task.priority == 2
    assert task.dependencies == []
    assert task.assignee is None
    assert task.close_reason is None


def test_task_with_close_reason() -> None:
    """Task model should parse close_reason for closed tasks."""
    task_data = {
        "id": "hangar-closed",
        "title": "Completed task",
        "status": "closed",
        "priority": 1,
        "issue_type": "task",
        "closed_at": "2026-02-08T01:00:00+01:00",
        "close_reason": "Implemented feature X with tests passing",
    }
    task = BeadsTask.model_validate(task_data)
    assert task.close_reason == "Implemented feature X with tests passing"
    assert task.status == "closed"


def test_task_closed_without_close_reason() -> None:
    """Task model should handle closed tasks with no close_reason."""
    task_data = {
        "id": "hangar-no-reason",
        "title": "Closed without reason",
        "status": "closed",
        "priority": 2,
        "issue_type": "task",
    }
    task = BeadsTask.model_validate(task_data)
    assert task.close_reason is None
