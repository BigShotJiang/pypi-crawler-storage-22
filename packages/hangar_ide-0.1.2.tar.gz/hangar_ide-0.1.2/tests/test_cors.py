"""Tests for CORS configuration."""

from fastapi.testclient import TestClient


def test_cors_allows_frontend_origin(client: TestClient) -> None:
    """CORS should allow requests from the SvelteKit dev server."""
    response = client.options(
        "/api/health",
        headers={
            "Origin": "http://localhost:5173",
            "Access-Control-Request-Method": "GET",
        },
    )
    assert response.headers.get("access-control-allow-origin") == "http://localhost:5173"


def test_cors_blocks_unknown_origin(client: TestClient) -> None:
    """CORS should not reflect arbitrary origins."""
    response = client.options(
        "/api/health",
        headers={
            "Origin": "http://evil.example.com",
            "Access-Control-Request-Method": "GET",
        },
    )
    assert response.headers.get("access-control-allow-origin") != "http://evil.example.com"
