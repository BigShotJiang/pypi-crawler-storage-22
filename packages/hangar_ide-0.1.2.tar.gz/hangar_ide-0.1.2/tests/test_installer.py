"""Tests for installer — run_full_init() and detect_init_status()."""

import subprocess

from hangar.installer import detect_init_status, run_full_init


# ── run_full_init ─────────────────────────────────────────────────


def test_full_init_fresh_dir(tmp_path):
    """Fresh directory gets git, skills, and AGENTS.md."""
    run_full_init(tmp_path)

    assert (tmp_path / ".git").is_dir()
    assert (tmp_path / ".claude" / "skills" / "openspec" / "SKILL.md").is_file()
    assert (tmp_path / ".claude" / "skills" / "beads" / "SKILL.md").is_file()

    content = (tmp_path / "AGENTS.md").read_text()
    assert "OpenSpec" in content
    assert "Beads" in content
    assert "# Agent Instructions" in content


def test_full_init_idempotent(tmp_path):
    """Running init twice doesn't duplicate content."""
    run_full_init(tmp_path)
    mtime = (tmp_path / "AGENTS.md").stat().st_mtime

    run_full_init(tmp_path)
    assert (tmp_path / "AGENTS.md").stat().st_mtime == mtime


def test_full_init_appends_to_existing_agents_md(tmp_path):
    """Existing AGENTS.md without workflow section gets it appended."""
    (tmp_path / "AGENTS.md").write_text("# My Project\n\nExisting content.\n")

    run_full_init(tmp_path)

    content = (tmp_path / "AGENTS.md").read_text()
    assert "Existing content" in content
    assert "OpenSpec" in content
    assert "Beads" in content


def test_full_init_existing_git(tmp_path):
    """Existing git repo is not re-initialized."""
    subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True, check=True)
    head_before = (tmp_path / ".git" / "HEAD").read_text()

    run_full_init(tmp_path)

    assert (tmp_path / ".git").is_dir()
    assert (tmp_path / ".git" / "HEAD").read_text() == head_before


def test_full_init_does_not_append_when_keywords_present(tmp_path):
    """AGENTS.md that already mentions openspec and beads is left alone."""
    existing = "# Agent Instructions\n\nUses openspec and beads.\n"
    (tmp_path / "AGENTS.md").write_text(existing)

    run_full_init(tmp_path)

    assert (tmp_path / "AGENTS.md").read_text() == existing


# ── detect_init_status ────────────────────────────────────────────


def test_detect_status_fresh_dir(tmp_path):
    """Fresh directory has nothing initialized."""
    status = detect_init_status(tmp_path)
    assert status == {"git": False, "skills": False, "agents_md": False}


def test_detect_status_fully_initialized(tmp_path):
    """After full init, all checks pass."""
    run_full_init(tmp_path)
    status = detect_init_status(tmp_path)
    assert status == {"git": True, "skills": True, "agents_md": True}


def test_detect_status_partial_git_only(tmp_path):
    """Only git initialized."""
    subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True, check=True)
    status = detect_init_status(tmp_path)
    assert status["git"] is True
    assert status["skills"] is False
    assert status["agents_md"] is False


def test_detect_status_agents_md_without_keywords(tmp_path):
    """AGENTS.md exists but lacks workflow keywords."""
    (tmp_path / "AGENTS.md").write_text("# My Project\n\nSome content.\n")
    status = detect_init_status(tmp_path)
    assert status["agents_md"] is False
