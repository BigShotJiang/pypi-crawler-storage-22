# hanifx

Advanced Security & Utility Toolkit for Python  
Powerful module for web crawling, numeric parameter detection, and security analysis.

---

## Features

- Crawl websites to detect numeric parameters in URLs and forms  
- Detect hidden input fields with numeric values  
- Extract numeric parameters from links and query strings  
- Threaded crawling for faster scanning  
- Clean, duplicate-free output  
- Optional colored output  

---

## Installation

```bash
pip install hanifx



Usage:

import hanifx

# Scan a website for numeric parameters
params = hanifx.crawl_params("https://example.com", max_depth=2)

# Print results
for url, key, val in params:
    print(f"{key}={val} found at {url}")
