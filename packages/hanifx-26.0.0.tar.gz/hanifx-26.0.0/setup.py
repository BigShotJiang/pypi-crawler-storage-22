from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="hanifx",
    version="26.0.0",
    author="Hanif",
    author_email="sajim4653@gmail.com",
    description="Advanced Security & Utility Toolkit for Python",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://pypi.org/project/hanifx/",  # পরে update করবেন যদি PyPI তে upload করেন
    packages=find_packages(),
    install_requires=[
        "requests>=2.28",
        "beautifulsoup4>=4.12",
    ],
    python_requires=">=3.7",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Security :: Analysis",
        "Topic :: Utilities",
    ],
)
