import re

from click.types import StringParamType


class HaploHubIdParamType(StringParamType):
    name = "haplohub_id"
    regex = r"^[a-zA-Z0-9-]+$"

    def convert(self, value, param, ctx):
        value = super().convert(value, param, ctx)

        if not re.match(self.regex, value):
            self.fail(f"{value!r} is not a valid HaploHub id", param, ctx)

        return value


class FilePathParamType(StringParamType):
    name = "file_path"


HAPLOHUB_ID = HaploHubIdParamType()
FILE_PATH = FilePathParamType()
