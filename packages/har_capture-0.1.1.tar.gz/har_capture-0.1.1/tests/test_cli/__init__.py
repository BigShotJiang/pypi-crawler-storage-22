"""Tests for CLI module."""
