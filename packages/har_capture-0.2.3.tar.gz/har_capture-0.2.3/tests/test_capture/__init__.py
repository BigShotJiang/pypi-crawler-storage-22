"""Tests for capture module."""
