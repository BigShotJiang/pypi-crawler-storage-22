"""Tests for patterns module."""
