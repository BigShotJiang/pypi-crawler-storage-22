# Changelog

All notable changes to hardixx-code will be documented in this file.

The format is based on Keep a Changelog, and this project adheres to Semantic Versioning.

## [1.0.0] - 2024-02-03

### Added

- Initial release of hardixx-code
- FFCrypto module for AES-256-CBC encryption/decryption
  - Decrypt Free Fire game packets
  - Encrypt data with AES-CBC
  - Support for hex string input/output
  - Custom key and IV support
- ProtobufHandler module for Protocol Buffer decoding
  - Decode protobuf messages without schema
  - Extract strings from protobuf data
  - Field filtering and extraction
  - Pretty printing of decoded fields
- PacketHandler module for complete packet processing
  - Full pipeline: decrypt -> decode -> analyze
  - Batch processing of multiple packets
  - Packet logging and statistics
  - Field extraction and analysis
- PacketSniffer module for network packet capture
  - Raw socket packet capture
  - Port-based filtering
  - PCAP file export
  - Free Fire port detection
- FFTelegramBot module for Telegram integration
  - Interactive bot for packet analysis
  - Decrypt command
  - Full analysis command
  - Status and help commands
  - Session management
- CLI tool (hardixx-cli)
  - Interactive mode
  - Command-line packet processing
  - Batch processing
  - Processing log
- Comprehensive documentation
  - API documentation
  - Usage examples
  - Quick start guide
  - Troubleshooting guide
- Example scripts
  - Basic decryption example
  - Full analysis example
  - Batch processing example
  - Telegram bot example

### Security

- Uses official Free Fire AES keys (public knowledge)
- PKCS7 padding for AES encryption
- Proper error handling for invalid input

## Future Releases

### Planned for 1.1.0

- Support for multiple encryption algorithms
- Advanced protobuf schema support
- Real-time packet monitoring
- Database storage for packet analysis
- Web dashboard for visualization
- Performance optimizations

### Under Consideration

- Support for other games
- Machine learning for packet classification
- Automated vulnerability detection
- Integration with Wireshark
- Mobile app for packet analysis
