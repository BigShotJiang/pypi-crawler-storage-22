# Contributing to hardixx-code

Thank you for your interest in contributing to hardixx-code! This document provides guidelines and instructions for contributing.

## Code of Conduct

- Be respectful and professional
- No harassment or discrimination
- Follow all applicable laws and regulations
- Respect the Free Fire Terms of Service

## How to Contribute

### Reporting Bugs

1. Check if the bug has already been reported
2. Create a new issue with a clear title and description
3. Include steps to reproduce the bug
4. Provide example code if possible
5. Include your environment details (Python version, OS, etc.)

### Suggesting Features

1. Check if the feature has already been suggested
2. Create a new issue with "Feature Request" in the title
3. Clearly describe the feature and its benefits
4. Explain why this feature would be useful

### Submitting Code

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/your-feature-name`
3. Make your changes
4. Add tests for new functionality
5. Ensure all tests pass: `pytest`
6. Commit with clear messages: `git commit -m "Add feature description"`
7. Push to your fork: `git push origin feature/your-feature-name`
8. Create a Pull Request with a clear description

## Code Style

- Follow PEP 8 guidelines
- Use meaningful variable and function names
- Add docstrings to all functions and classes
- Keep functions focused and modular
- Use type hints where appropriate

## Testing

- Write tests for new functionality
- Ensure existing tests still pass
- Aim for good code coverage
- Use pytest for testing

## Documentation

- Update README.md if adding new features
- Add docstrings to all public functions
- Include examples for new features
- Keep documentation up to date

## Commit Messages

- Use clear, descriptive commit messages
- Start with a verb (Add, Fix, Update, etc.)
- Keep the first line under 50 characters
- Add more details in the body if needed

Example:
```
Add packet filtering by field number

- Implement filter_by_field_number() in ProtobufHandler
- Add unit tests for new functionality
- Update documentation with examples
```

## Pull Request Process

1. Update the README.md with any new features
2. Update the version number following semantic versioning
3. Ensure all tests pass
4. Request review from maintainers
5. Address any feedback or requested changes

## Legal

By contributing to hardixx-code, you agree that:
- Your contributions will be licensed under the MIT License
- You have the right to contribute the code
- The code does not violate any laws or third-party rights

## Questions?

Feel free to open an issue for questions or discussions.

Thank you for contributing!
