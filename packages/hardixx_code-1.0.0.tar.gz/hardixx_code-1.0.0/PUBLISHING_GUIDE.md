# دليل نشر مكتبة hardixx-code

هذا الدليل يشرح كيفية نشر المكتبة على PyPI و GitHub.

## المتطلبات الأساسية

قبل البدء، تأكد من أن لديك:

1. حساب GitHub
2. حساب PyPI
3. Python 3.8+ مثبت
4. Git مثبت

## الخطوة 1: إعداد بيئة التطوير

### تثبيت الأدوات المطلوبة

```bash
pip install build twine wheel setuptools
```

### التحقق من ملفات المشروع

تأكد من وجود هذه الملفات في جذر المشروع:

```
setup.py              # إعدادات التثبيت
README.md             # التوثيق الرئيسي
LICENSE               # الترخيص
requirements.txt      # المكتبات المطلوبة
MANIFEST.in          # ملفات إضافية للنشر
```

## الخطوة 2: إنشاء ملف MANIFEST.in

أنشئ ملف `MANIFEST.in` في جذر المشروع:

```
include README.md
include LICENSE
include requirements.txt
include CHANGELOG.md
include CONTRIBUTING.md
recursive-include hardixx_code *.py
recursive-include docs *.md
recursive-include examples *.py
```

## الخطوة 3: بناء المكتبة محلياً

### اختبار البناء

```bash
python -m build
```

هذا سينشئ مجلد `dist/` يحتوي على:
- `hardixx-code-1.0.0.tar.gz` (مصدر)
- `hardixx_code-1.0.0-py3-none-any.whl` (wheel)

### اختبار التثبيت محلياً

```bash
pip install dist/hardixx_code-1.0.0-py3-none-any.whl
python -c "import hardixx_code; print(hardixx_code.__version__)"
```

## الخطوة 4: نشر على PyPI

### إنشاء حساب PyPI

1. اذهب إلى https://pypi.org/account/register/
2. أنشئ حسابك
3. تحقق من بريدك الإلكتروني

### إنشاء API Token

1. اذهب إلى https://pypi.org/manage/account/
2. اضغط على "Add API token"
3. اختر "Entire account"
4. انسخ التوكن

### إعداد بيانات اعتماد PyPI

أنشئ ملف `~/.pypirc`:

```ini
[distutils]
index-servers =
    pypi

[pypi]
repository = https://upload.pypi.org/legacy/
username = __token__
password = pypi_YOUR_TOKEN_HERE
```

### نشر المكتبة

```bash
# بناء المكتبة
python -m build

# نشر على PyPI
twine upload dist/*
```

أو بشكل تفاعلي:

```bash
twine upload dist/hardixx-code-1.0.0.tar.gz
twine upload dist/hardixx_code-1.0.0-py3-none-any.whl
```

### التحقق من النشر

```bash
pip install hardixx-code
python -c "from hardixx_code import FFCrypto; print('Success!')"
```

## الخطوة 5: نشر على GitHub

### إنشاء مستودع GitHub

1. اذهب إلى https://github.com/new
2. أنشئ مستودع باسم `hardixx-code`
3. اختر "Public"
4. لا تختر أي template

### تهيئة Git محلياً

```bash
cd hardixx-code
git init
git add .
git commit -m "Initial commit: hardixx-code v1.0.0"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/hardixx-code.git
git push -u origin main
```

### إضافة Tags للإصدارات

```bash
git tag -a v1.0.0 -m "Release version 1.0.0"
git push origin v1.0.0
```

### إنشاء Release على GitHub

1. اذهب إلى https://github.com/YOUR_USERNAME/hardixx-code/releases
2. اضغط "Create a new release"
3. اختر Tag `v1.0.0`
4. أضف الوصف:

```markdown
# hardixx-code v1.0.0

Advanced Free Fire packet analysis and reverse engineering library.

## Features

- AES-256-CBC Decryption
- Protobuf Decoding
- Packet Handler
- Packet Sniffer
- Telegram Bot Integration
- CLI Tool

## Installation

pip install hardixx-code

## Documentation

- README.md - Complete API documentation
- docs/QUICKSTART.md - Quick start guide
- docs/ADVANCED_EXAMPLES.md - Advanced usage

## Links

- PyPI: https://pypi.org/project/hardixx-code/
- Documentation: https://github.com/YOUR_USERNAME/hardixx-code
```

5. اضغط "Publish release"

## الخطوة 6: تحديث README على GitHub

تأكد من أن README.md يحتوي على:

```markdown
# hardixx-code

[![PyPI version](https://badge.fury.io/py/hardixx-code.svg)](https://badge.fury.io/py/hardixx-code)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Advanced Free Fire packet analysis library...

## Installation

pip install hardixx-code

## Quick Start

...
```

## الخطوة 7: إعداد CI/CD (اختياري)

### GitHub Actions

أنشئ `.github/workflows/publish.yml`:

```yaml
name: Publish to PyPI

on:
  release:
    types: [created]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: '3.9'
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install build twine
    - name: Build
      run: python -m build
    - name: Publish
      env:
        TWINE_USERNAME: __token__
        TWINE_PASSWORD: ${{ secrets.PYPI_API_TOKEN }}
      run: twine upload dist/*
```

## الخطوة 8: إضافة Badges

أضف هذه الـ badges إلى README.md:

```markdown
[![PyPI version](https://badge.fury.io/py/hardixx-code.svg)](https://badge.fury.io/py/hardixx-code)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![GitHub](https://img.shields.io/badge/github-hardixx--code-blue.svg)](https://github.com/YOUR_USERNAME/hardixx-code)
```

## الخطوة 9: الترويج للمكتبة

### إضافة إلى قوائم Python

- https://awesome-python.com/
- https://github.com/vinta/awesome-python
- https://github.com/topics/freefire
- https://github.com/topics/packet-analysis

### وسائل التواصل

- شارك على Twitter/X
- شارك على Reddit (r/Python, r/learnprogramming)
- أضف إلى مجتمعات البرمجة

### التوثيق

- أضف أمثلة على GitHub
- اكتب مقالات عن الاستخدام
- أنشئ فيديوهات توضيحية

## الخطوة 10: الصيانة المستقبلية

### تحديث الإصدارات

عند إصدار نسخة جديدة:

```bash
# تحديث الإصدار في setup.py
# تحديث CHANGELOG.md
# إنشاء commit جديد
git add .
git commit -m "Release v1.1.0"
git tag -a v1.1.0 -m "Release version 1.1.0"
git push origin main
git push origin v1.1.0

# بناء ونشر
python -m build
twine upload dist/*
```

### مراقبة المكتبة

- راقب GitHub Issues
- استجب للـ Pull Requests
- حدّث التوثيق
- أصلح الأخطاء

## نصائح مهمة

1. **اختبر قبل النشر** - تأكد من أن كل شيء يعمل محلياً
2. **استخدم Semantic Versioning** - MAJOR.MINOR.PATCH
3. **وثّق التغييرات** - حدّث CHANGELOG.md
4. **اطلب التعليقات** - افتح Issues للنقاش
5. **كن محترفاً** - رد على المستخدمين بسرعة

## استكشاف الأخطاء

### خطأ في PyPI

```bash
# تحقق من بيانات اعتماد PyPI
twine check dist/*

# حاول النشر مرة أخرى
twine upload --skip-existing dist/*
```

### مشاكل Git

```bash
# تحقق من الـ remotes
git remote -v

# أعد محاولة الدفع
git push -u origin main --force
```

## الخطوات التالية

بعد النشر:

1. راقب عدد التنزيلات على PyPI
2. اجمع ملاحظات المستخدمين
3. خطط للإصدارات المستقبلية
4. حسّن التوثيق بناءً على الأسئلة
5. أضف ميزات جديدة بناءً على الطلبات

## موارد مفيدة

- [PyPI Documentation](https://packaging.python.org/)
- [GitHub Documentation](https://docs.github.com/)
- [Semantic Versioning](https://semver.org/)
- [Keep a Changelog](https://keepachangelog.com/)

---

بعد اتباع هذه الخطوات، ستكون مكتبتك متاحة للجميع على PyPI وGitHub!
