# hardixx-code: Free Fire Packet Analysis Library

Advanced Python library for analyzing, decrypting, and manipulating Free Fire game packets. Includes AES decryption, Protobuf decoding, packet sniffing, and Telegram bot integration for developers.

**Version:** 1.0.0  
**Author:** H4RDIXX  
**License:** MIT

---

## Features

- AES-256-CBC Decryption - Decrypt Free Fire game packets using official keys
- Protobuf Decoding - Parse and analyze Protocol Buffer encoded messages without schema
- Packet Handler - Complete pipeline for decrypt → decode → analyze workflow
- Packet Sniffer - Capture and filter network traffic (requires root)
- Telegram Bot - Real-time packet analysis via Telegram
- CLI Tool - Interactive command-line interface
- Batch Processing - Process multiple packets at once
- Comprehensive Logging - Track all packet processing operations

---

## Installation

### From PyPI (Coming Soon)
```bash
pip install hardixx-code
```

### From Source
```bash
git clone https://github.com/hardixx/hardixx-code.git
cd hardixx-code
pip install -r requirements.txt
pip install -e .
```

### Requirements
- Python 3.8+
- pycryptodome
- protobuf
- python-telegram-bot (for Telegram features)
- scapy (for packet sniffing)

---

## Quick Start

### 1. Basic Decryption

```python
from hardixx_code import FFCrypto

crypto = FFCrypto()
hex_packet = "a1b2c3d4e5f6g7h8..."
decrypted = crypto.decrypt(hex_packet)
print(decrypted.hex())
```

### 2. Full Packet Analysis

```python
from hardixx_code import PacketHandler

handler = PacketHandler()
result = handler.process_packet("a1b2c3d4e5f6g7h8...")

if result['success']:
    print(f"Decrypted: {result['decrypted_hex']}")
    print(f"Fields: {len(result['fields'])}")
    for field in result['fields']:
        print(f"  Field {field['field_number']}: {field['value']}")
```

### 3. Extract Strings from Packet

```python
from hardixx_code import PacketHandler

handler = PacketHandler()
result = handler.process_packet("a1b2c3d4e5f6g7h8...")

strings = handler.extract_strings(result['fields'])
for s in strings:
    print(s)
```

### 4. Telegram Bot

```python
from hardixx_code import FFTelegramBot, PacketHandler

handler = PacketHandler()
bot = FFTelegramBot(token="YOUR_BOT_TOKEN", packet_handler=handler)
bot.run()
```

### 5. Command-Line Interface

```bash
# Interactive mode
hardixx-cli

# Decrypt a packet
hardixx-cli -d "a1b2c3d4e5f6..."

# Analyze a packet
hardixx-cli -a "a1b2c3d4e5f6..."
```

---

## API Documentation

### FFCrypto

Handles AES encryption/decryption of game packets.

```python
from hardixx_code import FFCrypto

# Initialize with default keys
crypto = FFCrypto()

# Decrypt hex string
decrypted = crypto.decrypt("a1b2c3d4...")

# Encrypt data
encrypted = crypto.encrypt(b"plaintext")

# Get hex output
hex_encrypted = crypto.encrypt_hex(b"plaintext")

# Custom keys
custom_crypto = FFCrypto(key=b"your_16_byte_key", iv=b"your_16_byte_iv")
```

**Methods:**
- decrypt(ciphertext) - Decrypt AES-CBC encrypted data
- encrypt(plaintext) - Encrypt data with AES-CBC
- decrypt_hex(hex_string) - Decrypt hex-encoded ciphertext
- encrypt_hex(plaintext) - Encrypt and return as hex
- set_key(key) - Change encryption key
- set_iv(iv) - Change initialization vector

### ProtobufHandler

Decodes Protocol Buffer messages without schema.

```python
from hardixx_code import ProtobufHandler

# Decode raw bytes
fields = ProtobufHandler.decode(decrypted_bytes)

# Extract strings
strings = ProtobufHandler.extract_strings(fields)

# Get specific field
field_5 = ProtobufHandler.extract_by_field_number(fields, 5)

# Convert to dictionary
fields_dict = ProtobufHandler.to_dict(fields)

# Format for display
formatted = ProtobufHandler.format_output(fields)
print(formatted)
```

**Methods:**
- decode(data) - Decode protobuf bytes
- extract_strings(fields) - Get all string values
- extract_by_field_number(fields, number) - Get fields by number
- to_dict(fields) - Convert to dictionary
- format_output(fields) - Pretty print fields

### PacketHandler

Complete packet processing pipeline.

```python
from hardixx_code import PacketHandler

handler = PacketHandler()

# Process complete packet
result = handler.process_packet("a1b2c3d4...")

# Decrypt only
decrypted = handler.decrypt_only("a1b2c3d4...")

# Decode only
fields = handler.decode_only(decrypted_bytes)

# Extract strings
strings = handler.extract_strings()

# Get specific field
field = handler.get_field(5)

# Batch process
results = handler.batch_process(["packet1", "packet2", ...])

# Get log
log = handler.get_packet_log()
```

**Methods:**
- process_packet(packet_hex, log=True) - Full processing
- decrypt_only(packet_hex) - Decrypt only
- decode_only(decrypted_bytes) - Decode only
- extract_strings(fields=None) - Extract strings
- get_field(field_number, fields=None) - Get field by number
- batch_process(packets) - Process multiple packets
- get_packet_log() - Get processing log
- clear_log() - Clear log

### PacketSniffer

Capture and analyze network packets.

```python
from hardixx_code import PacketSniffer, PacketHandler

handler = PacketHandler()
sniffer = PacketSniffer(handler)

# Capture packets (requires root)
packets = sniffer.capture_raw_socket(timeout=60)

# Filter by port
filtered = sniffer.filter_by_port(packets, 443)

# Filter by FF ports
ff_packets = sniffer.filter_by_ff_ports(packets)

# Analyze captured
results = sniffer.analyze_captured()

# Export to PCAP
sniffer.export_pcap("output.pcap")
```

**Methods:**
- capture_raw_socket(interface=None, timeout=60) - Capture packets
- filter_by_port(packets, port) - Filter by port
- filter_by_ff_ports(packets) - Filter by FF ports
- analyze_captured() - Analyze all captured packets
- export_pcap(filename) - Export to PCAP file
- stop_sniffing() - Stop capture

### FFTelegramBot

Telegram bot interface for packet analysis.

```python
from hardixx_code import FFTelegramBot, PacketHandler

handler = PacketHandler()
bot = FFTelegramBot(token="YOUR_BOT_TOKEN", packet_handler=handler)

# Setup handlers
bot.setup_handlers()

# Run bot
bot.run()
```

**Telegram Commands:**
- /start - Start bot
- /help - Show help
- /decrypt - Decrypt packet
- /analyze - Full analysis
- /status - Bot status
- /clear - Clear session

---

## Security Notes

- **Keys are embedded** - The default AES keys are public knowledge (extracted from game)
- **For development only** - Use for learning and authorized testing only
- **Respect ToS** - Comply with Free Fire Terms of Service
- **No malicious use** - Do not use for cheating, hacking, or unauthorized access

---

## Examples

### Example 1: Decrypt and Display

```python
from hardixx_code import PacketHandler

handler = PacketHandler()
packet_hex = input("Enter packet hex: ")

result = handler.process_packet(packet_hex)

if result['success']:
    print(" Success!")
    print(f"Decrypted: {result['decrypted_hex']}")
    print(f"\nFields ({len(result['fields'])}):")
    for field in result['fields']:
        print(f"  {field['field_number']}: {field['value']}")
else:
    print(f" Error: {result['error']}")
```

### Example 2: Extract Player Names

```python
from hardixx_code import PacketHandler

handler = PacketHandler()
result = handler.process_packet(packet_hex)

strings = handler.extract_strings(result['fields'])
player_names = [s for s in strings if len(s) > 2 and len(s) < 20]

print("Possible player names:")
for name in player_names:
    print(f"  - {name}")
```

### Example 3: Batch Analysis

```python
from hardixx_code import PacketHandler

handler = PacketHandler()
packets = [
    "a1b2c3d4...",
    "e5f6g7h8...",
    "i9j0k1l2...",
]

results = handler.batch_process(packets)

for i, result in enumerate(results, 1):
    if result['success']:
        print(f"Packet {i}: {len(result['fields'])} fields")
    else:
        print(f"Packet {i}: ERROR - {result['error']}")
```

---

## Telegram Bot Setup

1. **Create a bot** with BotFather on Telegram
2. **Get token** from BotFather
3. **Create script:**

```python
from hardixx_code import FFTelegramBot, PacketHandler

handler = PacketHandler()
bot = FFTelegramBot(token="YOUR_BOT_TOKEN", packet_handler=handler)
bot.run()
```

4. **Run bot:**
```bash
python bot_script.py
```

5. **Use in Telegram:**
   - Send `/start` to bot
   - Send `/decrypt` and paste packet hex
   - Bot will decrypt and analyze

---

## CLI Usage

```bash
# Interactive mode
hardixx-cli

# Decrypt packet
hardixx-cli -d "a1b2c3d4e5f6..."

# Analyze packet
hardixx-cli -a "a1b2c3d4e5f6..."

# Show help
hardixx-cli --help
```

**Interactive Commands:**
- decrypt - Decrypt a packet
- analyze - Full analysis
- batch - Process multiple packets
- status - Show status
- log - Show processing log
- clear - Clear log
- help - Show help
- exit - Exit program

---

## Troubleshooting

### "Invalid HEX" Error
- Make sure packet is valid hex string
- Remove any spaces or special characters
- Hex should only contain 0-9, a-f

### "Decryption failed" Error
- Packet may be corrupted
- Check if packet is actually encrypted with FF keys
- Verify hex format

### "Protobuf decoding error"
- Decrypted data may not be valid protobuf
- Try using `decrypt_only()` to check decryption
- Check packet format

### Telegram Bot Not Responding
- Verify bot token is correct
- Check internet connection
- Ensure python-telegram-bot is installed
- Check bot logs for errors

---

## Contributing

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

---

## License

MIT License - See LICENSE file for details

---

## Credits

- **H4RDIXX** - Original developer
- **Free Fire** - Game and protocol reference
- **Google Protobuf** - Serialization format
- **PyCryptodome** - Cryptography library

---

## Disclaimer

This library is for educational and authorized testing purposes only. Users are responsible for complying with applicable laws and the Free Fire Terms of Service. The author is not responsible for misuse of this library.

---

## Support

For issues, questions, or suggestions:
- GitHub Issues: https://github.com/hardixx/hardixx-code/issues
- Telegram: @lilililililililillliillllililill

---

Made with care by H4RDIXX
