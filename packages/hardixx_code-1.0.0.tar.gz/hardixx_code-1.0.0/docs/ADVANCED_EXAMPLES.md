# Advanced Examples

This document provides advanced usage examples for hardixx-code.

## Custom Encryption Keys

If you have custom AES keys for a specific server:

```python
from hardixx_code import FFCrypto

# Use custom keys
custom_key = b"your_16_byte_key"
custom_iv = b"your_16_byte_iv_"

crypto = FFCrypto(key=custom_key, iv=custom_iv)
decrypted = crypto.decrypt(packet_hex)
```

## Advanced Protobuf Analysis

Extract and analyze specific fields from protobuf data:

```python
from hardixx_code import PacketHandler, ProtobufHandler

handler = PacketHandler()
result = handler.process_packet(packet_hex)

# Get all fields as dictionary
fields_dict = result['fields_dict']
print(fields_dict)

# Extract specific field
field_10 = ProtobufHandler.extract_by_field_number(result['fields'], 10)
for f in field_10:
    print(f"Field 10: {f['value']}")

# Get only string fields
strings = ProtobufHandler.extract_strings(result['fields'])
print(f"Found {len(strings)} strings")
```

## Batch Processing with Error Handling

Process multiple packets with detailed error handling:

```python
from hardixx_code import PacketHandler

handler = PacketHandler()

packets = [
    "packet1_hex",
    "packet2_hex",
    "invalid_hex",
    "packet4_hex",
]

results = handler.batch_process(packets)

for i, result in enumerate(results):
    print(f"\nPacket {i+1}:")
    
    if result['success']:
        print(f"  Status: Success")
        print(f"  Size: {len(result['decrypted'])} bytes")
        print(f"  Fields: {len(result['fields'])}")
        
        # Analyze fields
        for field in result['fields'][:3]:
            print(f"    - Field {field['field_number']}: {field['value']}")
    else:
        print(f"  Status: Failed")
        print(f"  Error: {result['error']}")

# Show processing log
log = handler.get_packet_log()
print(f"\nProcessing Log ({len(log)} entries):")
for entry in log:
    status = "Success" if entry['result'] else "Failed"
    print(f"  {status}: {entry['packet_hex']}")
```

## Custom Packet Filter

Create a custom filter for packet sniffing:

```python
from hardixx_code import PacketSniffer, PacketHandler

def is_ff_packet(packet):
    """Custom filter: check if packet looks like Free Fire data"""
    # Check packet size
    if len(packet) < 20 or len(packet) > 10000:
        return False
    
    # Check for common patterns
    if b'garena' in packet or b'ff' in packet:
        return True
    
    return False

handler = PacketHandler()
sniffer = PacketSniffer(handler)

# Set custom filter
sniffer.set_filter(is_ff_packet)

# Capture packets (requires root)
try:
    packets = sniffer.capture_raw_socket(timeout=30)
    print(f"Captured {len(packets)} packets")
    
    # Analyze captured packets
    results = sniffer.analyze_captured()
    
    # Export to PCAP
    sniffer.export_pcap("ff_packets.pcap")
except PermissionError:
    print("Packet sniffing requires root/administrator privileges")
```

## Real-time Packet Monitoring

Monitor and analyze packets in real-time:

```python
from hardixx_code import PacketHandler
import time

def monitor_packets(packet_source, duration=60):
    """Monitor packets for a specified duration"""
    handler = PacketHandler()
    start_time = time.time()
    
    while time.time() - start_time < duration:
        try:
            packet = next(packet_source)
            result = handler.process_packet(packet, log=True)
            
            if result['success']:
                print(f"Packet: {len(result['fields'])} fields")
                
                # Extract and display strings
                strings = handler.extract_strings(result['fields'])
                if strings:
                    print(f"  Strings: {strings[:3]}")
            
            time.sleep(0.1)  # Avoid overwhelming output
        
        except StopIteration:
            break
        except Exception as e:
            print(f"Error: {str(e)}")

# Usage (requires a packet source)
# monitor_packets(packet_generator, duration=60)
```

## Field-based Packet Classification

Classify packets based on field patterns:

```python
from hardixx_code import PacketHandler

def classify_packet(packet_hex):
    """Classify packet type based on fields"""
    handler = PacketHandler()
    result = handler.process_packet(packet_hex)
    
    if not result['success']:
        return "Unknown"
    
    fields = result['fields']
    field_count = len(fields)
    
    # Classify by field count and content
    if field_count < 5:
        return "Auth"
    elif field_count < 15:
        return "Login"
    elif field_count < 50:
        return "GameData"
    else:
        return "LargeData"

# Usage
packets = ["packet1_hex", "packet2_hex", "packet3_hex"]
for packet in packets:
    classification = classify_packet(packet)
    print(f"Packet: {classification}")
```

## Telegram Bot with Custom Commands

Extend the Telegram bot with custom commands:

```python
from hardixx_code import FFTelegramBot, PacketHandler

class CustomFFBot(FFTelegramBot):
    """Extended Telegram bot with custom commands"""
    
    async def custom_command(self, update, context):
        """Custom command handler"""
        user_id = update.effective_user.id
        
        # Your custom logic here
        await update.message.reply_text("Custom command executed!")

# Usage
handler = PacketHandler()
bot = CustomFFBot(token="YOUR_TOKEN", packet_handler=handler)
bot.run()
```

## Data Export and Reporting

Export analysis results to various formats:

```python
from hardixx_code import PacketHandler
import json
import csv

def export_analysis(packet_hex, output_format="json"):
    """Export packet analysis to file"""
    handler = PacketHandler()
    result = handler.process_packet(packet_hex)
    
    if not result['success']:
        return None
    
    # Prepare data
    data = {
        'success': True,
        'size': len(result['decrypted']),
        'field_count': len(result['fields']),
        'fields': result['fields_dict'],
        'strings': handler.extract_strings(result['fields']),
    }
    
    # Export based on format
    if output_format == "json":
        with open("analysis.json", "w") as f:
            json.dump(data, f, indent=2)
    
    elif output_format == "csv":
        with open("analysis.csv", "w", newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['Field Number', 'Value'])
            for field_num, value in data['fields'].items():
                writer.writerow([field_num, value])
    
    return data

# Usage
result = export_analysis("packet_hex", output_format="json")
print(result)
```

## Performance Optimization

Optimize processing for large batches:

```python
from hardixx_code import PacketHandler
import time

def benchmark_processing(packets, batch_size=100):
    """Benchmark packet processing performance"""
    handler = PacketHandler()
    
    start_time = time.time()
    
    for i in range(0, len(packets), batch_size):
        batch = packets[i:i+batch_size]
        results = handler.batch_process(batch)
        
        successful = sum(1 for r in results if r['success'])
        print(f"Batch {i//batch_size + 1}: {successful}/{len(batch)} successful")
    
    elapsed = time.time() - start_time
    print(f"\nTotal time: {elapsed:.2f}s")
    print(f"Average: {elapsed/len(packets)*1000:.2f}ms per packet")

# Usage
# benchmark_processing(packet_list)
```

## Logging and Debugging

Enable detailed logging for debugging:

```python
import logging
from hardixx_code import PacketHandler

# Configure logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('hardixx.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

# Use packet handler with logging
handler = PacketHandler()
result = handler.process_packet(packet_hex, log=True)

# Get detailed log
log = handler.get_packet_log()
for entry in log:
    logger.info(f"Packet: {entry['packet_hex'][:50]}... - {entry['result']}")
```

## Integration with External Tools

Integrate hardixx-code with other tools:

```python
from hardixx_code import PacketHandler
import subprocess

def send_to_wireshark(packet_hex):
    """Export packet to Wireshark format"""
    handler = PacketHandler()
    result = handler.process_packet(packet_hex)
    
    if result['success']:
        # Create PCAP file
        import struct
        with open("packet.pcap", "wb") as f:
            # PCAP header
            f.write(struct.pack('<4sHHiIII',
                b'\xa1\xb2\xc3\xd4', 2, 4, 0, 0, 65535, 1))
            
            # Packet data
            f.write(struct.pack('<IIII', 0, 0, 
                len(result['decrypted']), len(result['decrypted'])))
            f.write(result['decrypted'])
        
        # Open in Wireshark
        subprocess.run(['wireshark', 'packet.pcap'])

# Usage
# send_to_wireshark("packet_hex")
```

## Conclusion

These advanced examples demonstrate the flexibility and power of hardixx-code. Combine these techniques to build sophisticated packet analysis tools.

For more information, refer to the API documentation and source code.
