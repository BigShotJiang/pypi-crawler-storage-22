# Quick Start Guide - hardixx-code

This guide will help you get started with hardixx-code in minutes.

## Installation

### Option 1: From Source (Recommended for Development)

```bash
git clone https://github.com/hardixx/hardixx-code.git
cd hardixx-code
pip install -r requirements.txt
pip install -e .
```

### Option 2: From PyPI (Coming Soon)

```bash
pip install hardixx-code
```

## Basic Usage

### 1. Decrypt a Packet

The simplest use case: decrypt a Free Fire encrypted packet.

```python
from hardixx_code import FFCrypto

crypto = FFCrypto()
encrypted_hex = "a1b2c3d4e5f6..."  # Your encrypted packet
decrypted = crypto.decrypt(encrypted_hex)
print(decrypted.hex())
```

### 2. Full Packet Analysis

Decrypt and analyze a packet to extract all fields and data.

```python
from hardixx_code import PacketHandler

handler = PacketHandler()
result = handler.process_packet("a1b2c3d4e5f6...")

if result['success']:
    print(f"Decrypted: {result['decrypted_hex']}")
    print(f"Fields: {len(result['fields'])}")
    
    # Extract strings
    strings = handler.extract_strings(result['fields'])
    for s in strings:
        print(f"  - {s}")
```

### 3. Use the CLI Tool

Interactive command-line interface for packet analysis.

```bash
# Run interactive mode
python run_cli.py

# Or use commands directly
python run_cli.py -d "a1b2c3d4..."
python run_cli.py -a "a1b2c3d4..."
```

### 4. Telegram Bot

Create a Telegram bot for real-time packet analysis.

```bash
# Run the bot
python run_telegram_bot.py

# Enter your bot token when prompted
```

Then on Telegram:
- Send `/start` to your bot
- Send `/decrypt` and paste a packet hex
- Bot will decrypt and analyze it

## Common Tasks

### Extract Player Names from Packet

```python
from hardixx_code import PacketHandler

handler = PacketHandler()
result = handler.process_packet(packet_hex)

# Get all strings
strings = handler.extract_strings(result['fields'])

# Filter for player names (usually 3-20 chars)
names = [s for s in strings if 3 < len(s) < 20]
print(names)
```

### Process Multiple Packets

```python
from hardixx_code import PacketHandler

handler = PacketHandler()
packets = ["packet1_hex", "packet2_hex", "packet3_hex"]

results = handler.batch_process(packets)

for i, result in enumerate(results):
    if result['success']:
        print(f"Packet {i}: {len(result['fields'])} fields")
    else:
        print(f"Packet {i}: Failed - {result['error']}")
```

### Get Specific Field

```python
from hardixx_code import PacketHandler

handler = PacketHandler()
result = handler.process_packet(packet_hex)

# Get field number 5
field_5 = handler.get_field(5, result['fields'])
print(field_5)
```

## Troubleshooting

### "Invalid HEX" Error

Make sure your packet is a valid hex string with only 0-9 and a-f characters.

```python
# Good
packet = "a1b2c3d4e5f6"

# Bad (contains spaces or invalid chars)
packet = "a1 b2 c3 d4"
```

### "Decryption failed" Error

The packet might not be encrypted with Free Fire keys, or it could be corrupted.

```python
# Try decrypting only first
decrypted = handler.decrypt_only(packet_hex)
print(decrypted.hex())  # Check if it looks like valid data
```

### Telegram Bot Not Responding

1. Check that your bot token is correct
2. Verify internet connection
3. Install python-telegram-bot: `pip install python-telegram-bot`

## Next Steps

- Read the full API documentation in README.md
- Check out example scripts in the `examples/` directory
- Explore the source code in `hardixx_code/`
- Contribute to the project on GitHub

## Getting Help

- Open an issue on GitHub
- Check the FAQ in README.md
- Review example scripts
- Read the source code documentation

## Important Notes

This library is for educational and authorized testing purposes only. Always respect the Free Fire Terms of Service and applicable laws.
