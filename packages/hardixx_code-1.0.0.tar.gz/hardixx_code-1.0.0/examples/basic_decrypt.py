#!/usr/bin/env python3
"""
Example 1: Basic Packet Decryption
Simple example showing how to decrypt a Free Fire packet
"""

from hardixx_code import FFCrypto

def main():
    # Initialize crypto handler with default FF keys
    crypto = FFCrypto()
    
    # Example encrypted packet (hex string)
    # In real usage, you would get this from network capture or user input
    encrypted_packet = input("Enter encrypted packet (hex): ").strip()
    
    try:
        # Decrypt the packet
        decrypted = crypto.decrypt(encrypted_packet)
        
        print("\n Decryption Successful!\n")
        print(f"Decrypted Size: {len(decrypted)} bytes")
        print(f"\nHex Output:\n{decrypted.hex()}")
        print(f"\nUTF-8 Preview:\n{decrypted[:200].decode('utf-8', errors='ignore')}")
        
    except Exception as e:
        print(f"\n Decryption Failed: {str(e)}")

if __name__ == "__main__":
    main()
