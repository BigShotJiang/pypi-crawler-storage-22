#!/usr/bin/env python3
"""
Example 3: Batch Packet Processing
Process multiple packets at once
"""

from hardixx_code import PacketHandler

def main():
    handler = PacketHandler()
    
    # Example packets (in real usage, read from file or network)
    packets = [
        input(f"Enter packet {i+1} (hex, or empty to skip): ").strip()
        for i in range(3)
    ]
    
    # Filter out empty packets
    packets = [p for p in packets if p]
    
    if not packets:
        print("No packets provided")
        return
    
    print(f"\nProcessing {len(packets)} packets...\n")
    
    # Process all packets
    results = handler.batch_process(packets)
    
    # Show results
    print("="*70)
    print("BATCH PROCESSING RESULTS")
    print("="*70)
    
    for i, result in enumerate(results, 1):
        print(f"\n[Packet {i}]")
        
        if result['success']:
            print(f"   Success")
            print(f"  Size: {len(result['decrypted'])} bytes")
            print(f"  Fields: {len(result['fields'])}")
            
            # Show strings
            strings = [f for f in result['fields'] if f.get('is_string')]
            if strings:
                print(f"  Strings: {len(strings)}")
                for s in strings[:3]:
                    print(f"    - {s['value'][:40]}")
        else:
            print(f"   Failed: {result['error']}")
    
    # Show summary
    successful = sum(1 for r in results if r['success'])
    print(f"\n{'='*70}")
    print(f"Summary: {successful}/{len(results)} packets processed successfully")
    print(f"{'='*70}")
    
    # Show log
    log = handler.get_packet_log()
    print(f"\nProcessing Log ({len(log)} entries):")
    for i, entry in enumerate(log, 1):
        status = "" if entry['result'] else "❌"
        print(f"  {i}. {status} {entry['packet_hex']}")

if __name__ == "__main__":
    main()
