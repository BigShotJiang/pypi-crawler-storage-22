#!/usr/bin/env python3
"""
Example 2: Full Packet Analysis
Complete example showing decrypt + decode + analysis
"""

from hardixx_code import PacketHandler

def main():
    # Initialize packet handler
    handler = PacketHandler()
    
    # Get packet from user
    packet_hex = input("Enter encrypted packet (hex): ").strip()
    
    try:
        # Process packet (decrypt + decode)
        result = handler.process_packet(packet_hex)
        
        if not result['success']:
            print(f" Error: {result['error']}")
            return
        
        print("\n" + "="*70)
        print(" PACKET ANALYSIS COMPLETE")
        print("="*70)
        
        # Show decryption result
        print(f"\n Decryption:")
        print(f"  Size: {len(result['decrypted'])} bytes")
        print(f"  Hex: {result['decrypted_hex'][:100]}...")
        
        # Show protobuf fields
        print(f"\n Protobuf Fields: {len(result['fields'])} fields found")
        print("\nFirst 10 fields:")
        for i, field in enumerate(result['fields'][:10], 1):
            value_str = str(field['value'])[:50]
            print(f"  {i}. Field {field['field_number']} ({field['wire_type']}): {value_str}")
        
        if len(result['fields']) > 10:
            print(f"  ... and {len(result['fields']) - 10} more fields")
        
        # Extract and show strings
        strings = handler.extract_strings(result['fields'])
        if strings:
            print(f"\n Extracted Strings: {len(strings)} strings found")
            for i, s in enumerate(strings[:5], 1):
                print(f"  {i}. {s[:60]}")
            
            if len(strings) > 5:
                print(f"  ... and {len(strings) - 5} more strings")
        
        # Show field dictionary
        print(f"\n Field Dictionary:")
        fields_dict = result['fields_dict']
        for field_num, value in list(fields_dict.items())[:5]:
            value_str = str(value)[:40]
            print(f"  Field {field_num}: {value_str}")
        
        if len(fields_dict) > 5:
            print(f"  ... and {len(fields_dict) - 5} more fields")
        
    except Exception as e:
        print(f" Analysis Failed: {str(e)}")

if __name__ == "__main__":
    main()
