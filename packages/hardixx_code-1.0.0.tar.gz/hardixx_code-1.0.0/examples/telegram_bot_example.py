#!/usr/bin/env python3
"""
Example 4: Telegram Bot Integration
Complete example of using FFTelegramBot for packet analysis
"""

from hardixx_code import FFTelegramBot, PacketHandler

def main():
    # Get bot token from user
    token = input("Enter your Telegram bot token: ").strip()
    
    if not token:
        print("No token provided")
        return
    
    # Initialize packet handler
    packet_handler = PacketHandler()
    
    # Initialize bot
    bot = FFTelegramBot(token=token, packet_handler=packet_handler)
    
    print("\nStarting Free Fire Telegram Bot...")
    print("Send /start to your bot on Telegram to begin")
    print("Press Ctrl+C to stop\n")
    
    try:
        # Run bot
        bot.run()
    except KeyboardInterrupt:
        print("\nBot stopped")
    except Exception as e:
        print(f"Error: {str(e)}")

if __name__ == "__main__":
    main()
