"""
hardixx-code: Advanced Free Fire Packet Analysis and Reverse Engineering Library
Version: 1.0.0
Author: H4RDIXX

A comprehensive Python library for analyzing, decrypting, and manipulating
Free Fire game packets. Includes AES decryption, Protobuf decoding,
packet sniffing, and Telegram bot integration for developers.
"""

__version__ = "1.0.0"
__author__ = "H4RDIXX"
__license__ = "MIT"

from .crypto import FFCrypto
from .protobuf_handler import ProtobufHandler
from .packet_handler import PacketHandler
from .packet_sniffer import PacketSniffer
from .telegram_bot import FFTelegramBot

__all__ = [
    "FFCrypto",
    "ProtobufHandler",
    "PacketHandler",
    "PacketSniffer",
    "FFTelegramBot",
]
