"""
CLI: Command-line interface for hardixx-code
Provides interactive packet analysis from terminal
"""

import sys
import argparse
from typing import Optional
from .packet_handler import PacketHandler
from .crypto import FFCrypto
from .protobuf_handler import ProtobufHandler


class HardixxCLI:
    """Command-line interface for hardixx-code"""
    
    def __init__(self):
        self.packet_handler = PacketHandler()
    
    def interactive_mode(self):
        """Run interactive mode"""
        print("\n" + "="*70)
        print(" HARDIXX-CODE - Free Fire Packet Analyzer")
        print("="*70)
        print("\nType 'help' for commands, 'exit' to quit\n")
        
        while True:
            try:
                command = input("hardixx> ").strip().lower()
                
                if command == 'exit':
                    print("Goodbye!")
                    break
                elif command == 'help':
                    self.show_help()
                elif command == 'decrypt':
                    self.cmd_decrypt()
                elif command == 'analyze':
                    self.cmd_analyze()
                elif command == 'batch':
                    self.cmd_batch()
                elif command == 'status':
                    self.cmd_status()
                elif command == 'clear':
                    self.packet_handler.clear_log()
                    print(" Log cleared")
                elif command == 'log':
                    self.cmd_show_log()
                elif command == '':
                    continue
                else:
                    print(f"Unknown command: {command}. Type 'help' for commands.")
            
            except KeyboardInterrupt:
                print("\n\nExiting...")
                break
            except Exception as e:
                print(f"Error: {str(e)}")
    
    def show_help(self):
        """Show help message"""
        help_text = """
 Available Commands:

  decrypt    - Decrypt a single packet
  analyze    - Decrypt and analyze a packet
  batch      - Process multiple packets
  status     - Show bot status
  log        - Show processing log
  clear      - Clear log
  help       - Show this help message
  exit       - Exit the program

Example:
  hardixx> decrypt
  HEX CODE: a1b2c3d4e5f6...
  [Output shows decrypted data]
        """
        print(help_text)
    
    def cmd_decrypt(self):
        """Decrypt a packet"""
        packet_hex = input("Enter hex-encoded packet: ").strip()
        
        if not packet_hex:
            print(" No packet provided")
            return
        
        try:
            decrypted = self.packet_handler.decrypt_only(packet_hex)
            print(f"\n Decryption successful!")
            print(f"Decrypted size: {len(decrypted)} bytes")
            print(f"Hex: {decrypted.hex()}")
            print(f"\nPreview (UTF-8):\n{decrypted[:200].decode('utf-8', errors='ignore')}")
        
        except Exception as e:
            print(f" Decryption failed: {str(e)}")
    
    def cmd_analyze(self):
        """Analyze a packet"""
        packet_hex = input("Enter hex-encoded packet: ").strip()
        
        if not packet_hex:
            print(" No packet provided")
            return
        
        try:
            result = self.packet_handler.process_packet(packet_hex, log=True)
            
            if not result['success']:
                print(f" Analysis failed: {result['error']}")
                return
            
            print(f"\n Analysis successful!")
            print(f"Decrypted size: {len(result['decrypted'])} bytes")
            print(f"Fields found: {len(result['fields'])}")
            
            # Show fields
            print("\n" + "="*70)
            print("PROTOBUF FIELDS:")
            print("="*70)
            
            for i, field in enumerate(result['fields'][:20], 1):
                print(f"\n[Field {i}]")
                print(f"  Number: {field['field_number']}")
                print(f"  Type: {field['wire_type']}")
                print(f"  Value: {str(field['value'])[:100]}")
            
            if len(result['fields']) > 20:
                print(f"\n... and {len(result['fields']) - 20} more fields")
            
            # Show extracted strings
            strings = self.packet_handler.extract_strings(result['fields'])
            if strings:
                print("\n" + "="*70)
                print("EXTRACTED STRINGS:")
                print("="*70)
                for i, s in enumerate(strings[:10], 1):
                    print(f"{i}. {s[:100]}")
                
                if len(strings) > 10:
                    print(f"... and {len(strings) - 10} more strings")
        
        except Exception as e:
            print(f" Analysis failed: {str(e)}")
    
    def cmd_batch(self):
        """Process multiple packets"""
        print("Enter packets (one per line, empty line to finish):")
        packets = []
        
        while True:
            packet = input().strip()
            if not packet:
                break
            packets.append(packet)
        
        if not packets:
            print(" No packets provided")
            return
        
        print(f"\nProcessing {len(packets)} packets...")
        results = self.packet_handler.batch_process(packets)
        
        successful = sum(1 for r in results if r['success'])
        failed = len(results) - successful
        
        print(f"\n Batch processing complete!")
        print(f"Successful: {successful}")
        print(f"Failed: {failed}")
    
    def cmd_status(self):
        """Show status"""
        log = self.packet_handler.get_packet_log()
        
        status_text = f"""
 Bot Status

 Status: Online
 Packet Handler: Active
 Crypto Module: Ready
 Protobuf Decoder: Ready

**Statistics:**
• Packets Processed: {len(log)}
• Successful: {sum(1 for p in log if p['result'])}
• Failed: {sum(1 for p in log if not p['result'])}

Version: 1.0.0
Author: H4RDIXX
        """
        print(status_text)
    
    def cmd_show_log(self):
        """Show processing log"""
        log = self.packet_handler.get_packet_log()
        
        if not log:
            print("Log is empty")
            return
        
        print("\n" + "="*70)
        print("PROCESSING LOG:")
        print("="*70)
        
        for i, entry in enumerate(log[-20:], 1):  # Show last 20
            status = "" if entry['result'] else ""
            print(f"\n[{i}] {status}")
            print(f"  Packet: {entry['packet_hex']}")
            if entry['error']:
                print(f"  Error: {entry['error']}")
        
        if len(log) > 20:
            print(f"\n... and {len(log) - 20} more entries")


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description="hardixx-code: Free Fire Packet Analyzer",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  hardixx-cli                    # Interactive mode
  hardixx-cli -d "a1b2c3d4..."   # Decrypt packet
  hardixx-cli -a "a1b2c3d4..."   # Analyze packet
        """
    )
    
    parser.add_argument('-d', '--decrypt', metavar='HEX', 
                       help='Decrypt a packet')
    parser.add_argument('-a', '--analyze', metavar='HEX',
                       help='Analyze a packet')
    parser.add_argument('-i', '--interactive', action='store_true',
                       help='Interactive mode')
    parser.add_argument('-v', '--version', action='version',
                       version='hardixx-code 1.0.0')
    
    args = parser.parse_args()
    cli = HardixxCLI()
    
    if args.decrypt:
        try:
            decrypted = cli.packet_handler.decrypt_only(args.decrypt)
            print(f" Decrypted ({len(decrypted)} bytes):")
            print(decrypted.hex())
        except Exception as e:
            print(f" Error: {str(e)}")
            sys.exit(1)
    
    elif args.analyze:
        try:
            result = cli.packet_handler.process_packet(args.analyze)
            if result['success']:
                print(cli.packet_handler.format_last_result())
            else:
                print(f" Error: {result['error']}")
                sys.exit(1)
        except Exception as e:
            print(f" Error: {str(e)}")
            sys.exit(1)
    
    else:
        # Default to interactive mode
        cli.interactive_mode()


if __name__ == '__main__':
    main()
