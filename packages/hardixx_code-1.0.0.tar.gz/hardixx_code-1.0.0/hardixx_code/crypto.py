"""
FFCrypto: AES Encryption/Decryption module for Free Fire packets
Implements AES-256-CBC with PKCS7 padding
"""

import binascii
from typing import Union, Tuple
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad


class FFCrypto:
    """
    Free Fire Cryptography Handler
    
    Handles AES-256-CBC encryption and decryption of game packets
    using the official Free Fire keys.
    """
    
    # Official Free Fire AES Keys (extracted from game)
    DEFAULT_KEY = b"Yg&tc%DEuh6%Zc^8"
    DEFAULT_IV = b"6oyZDr22E3ychjM%"
    
    def __init__(self, key: bytes = None, iv: bytes = None):
        """
        Initialize FFCrypto with custom or default keys
        
        Args:
            key (bytes): AES encryption key (default: Free Fire key)
            iv (bytes): Initialization vector (default: Free Fire IV)
        """
        self.key = key or self.DEFAULT_KEY
        self.iv = iv or self.DEFAULT_IV
        
        if len(self.key) != 16:
            raise ValueError(f"Key must be 16 bytes, got {len(self.key)}")
        if len(self.iv) != 16:
            raise ValueError(f"IV must be 16 bytes, got {len(self.iv)}")
    
    def encrypt(self, plaintext: Union[bytes, str]) -> bytes:
        """
        Encrypt plaintext using AES-256-CBC
        
        Args:
            plaintext (bytes or str): Data to encrypt
            
        Returns:
            bytes: Encrypted ciphertext
            
        Raises:
            TypeError: If plaintext is not bytes or str
        """
        if isinstance(plaintext, str):
            plaintext = plaintext.encode('utf-8')
        
        if not isinstance(plaintext, bytes):
            raise TypeError("plaintext must be bytes or str")
        
        try:
            cipher = AES.new(self.key, AES.MODE_CBC, self.iv)
            padded_data = pad(plaintext, AES.block_size)
            ciphertext = cipher.encrypt(padded_data)
            return ciphertext
        except Exception as e:
            raise RuntimeError(f"Encryption failed: {str(e)}")
    
    def decrypt(self, ciphertext: Union[bytes, str]) -> bytes:
        """
        Decrypt ciphertext using AES-256-CBC
        
        Args:
            ciphertext (bytes or str): Data to decrypt (can be hex string)
            
        Returns:
            bytes: Decrypted plaintext
            
        Raises:
            ValueError: If decryption or unpadding fails
        """
        # Handle hex string input
        if isinstance(ciphertext, str):
            try:
                ciphertext = binascii.unhexlify(ciphertext.replace(" ", ""))
            except (binascii.Error, ValueError) as e:
                raise ValueError(f"Invalid hex string: {str(e)}")
        
        if not isinstance(ciphertext, bytes):
            raise TypeError("ciphertext must be bytes or hex string")
        
        try:
            cipher = AES.new(self.key, AES.MODE_CBC, self.iv)
            decrypted = cipher.decrypt(ciphertext)
            plaintext = unpad(decrypted, AES.block_size)
            return plaintext
        except ValueError as e:
            raise ValueError(f"Decryption or unpadding failed: {str(e)}")
        except Exception as e:
            raise RuntimeError(f"Decryption failed: {str(e)}")
    
    def encrypt_hex(self, plaintext: Union[bytes, str]) -> str:
        """
        Encrypt plaintext and return as hex string
        
        Args:
            plaintext (bytes or str): Data to encrypt
            
        Returns:
            str: Encrypted data as hex string
        """
        ciphertext = self.encrypt(plaintext)
        return ciphertext.hex()
    
    def decrypt_hex(self, hex_ciphertext: str) -> bytes:
        """
        Decrypt hex string ciphertext
        
        Args:
            hex_ciphertext (str): Hex-encoded ciphertext
            
        Returns:
            bytes: Decrypted plaintext
        """
        return self.decrypt(hex_ciphertext)
    
    def set_key(self, key: bytes):
        """Change the encryption key"""
        if len(key) != 16:
            raise ValueError(f"Key must be 16 bytes, got {len(key)}")
        self.key = key
    
    def set_iv(self, iv: bytes):
        """Change the initialization vector"""
        if len(iv) != 16:
            raise ValueError(f"IV must be 16 bytes, got {len(iv)}")
        self.iv = iv
    
    @staticmethod
    def generate_key_iv_pair() -> Tuple[bytes, bytes]:
        """
        Generate a random AES key and IV pair
        
        Returns:
            Tuple[bytes, bytes]: (key, iv)
        """
        import os
        key = os.urandom(16)
        iv = os.urandom(16)
        return key, iv
