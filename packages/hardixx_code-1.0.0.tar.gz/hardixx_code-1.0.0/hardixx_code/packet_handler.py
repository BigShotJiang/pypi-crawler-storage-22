"""
PacketHandler: Integrated packet processing module
Combines encryption, decryption, and protobuf decoding
"""

from typing import Dict, List, Any, Optional
from .crypto import FFCrypto
from .protobuf_handler import ProtobufHandler


class PacketHandler:
    """
    Complete Packet Handler
    
    Handles the full pipeline of packet processing:
    1. Decrypt AES-encrypted payload
    2. Decode Protobuf message
    3. Extract and analyze data
    """
    
    def __init__(self, key: bytes = None, iv: bytes = None):
        """
        Initialize PacketHandler
        
        Args:
            key (bytes): Custom AES key (optional)
            iv (bytes): Custom AES IV (optional)
        """
        self.crypto = FFCrypto(key, iv)
        self.last_decrypted = None
        self.last_decoded = None
        self.packet_log = []
    
    def process_packet(self, packet_data: str, 
                      log: bool = True) -> Dict[str, Any]:
        """
        Process a complete packet (decrypt + decode)
        
        Args:
            packet_data (str): Hex-encoded encrypted packet
            log (bool): Whether to log the packet
            
        Returns:
            Dict with keys:
                - 'success': bool
                - 'decrypted': bytes
                - 'decrypted_hex': str
                - 'fields': List[Dict]
                - 'fields_dict': Dict
                - 'error': str (if failed)
        """
        result = {
            'success': False,
            'decrypted': None,
            'decrypted_hex': None,
            'fields': None,
            'fields_dict': None,
            'error': None,
        }
        
        try:
            # Step 1: Decrypt
            decrypted = self.crypto.decrypt(packet_data)
            result['decrypted'] = decrypted
            result['decrypted_hex'] = decrypted.hex()
            self.last_decrypted = decrypted
            
            # Step 2: Decode Protobuf
            fields = ProtobufHandler.decode(decrypted)
            result['fields'] = fields
            result['fields_dict'] = ProtobufHandler.to_dict(fields)
            self.last_decoded = fields
            
            result['success'] = True
            
        except Exception as e:
            result['error'] = str(e)
        
        # Log if requested
        if log:
            self.packet_log.append({
                'packet_hex': packet_data[:50] + '...' if len(packet_data) > 50 else packet_data,
                'result': result['success'],
                'error': result['error'],
            })
        
        return result
    
    def decrypt_only(self, packet_data: str) -> bytes:
        """
        Decrypt packet without protobuf decoding
        
        Args:
            packet_data (str): Hex-encoded encrypted packet
            
        Returns:
            bytes: Decrypted data
        """
        return self.crypto.decrypt(packet_data)
    
    def decode_only(self, decrypted_data: bytes) -> List[Dict[str, Any]]:
        """
        Decode protobuf without decryption
        
        Args:
            decrypted_data (bytes): Raw decrypted data
            
        Returns:
            List[Dict]: Decoded fields
        """
        return ProtobufHandler.decode(decrypted_data)
    
    def extract_strings(self, fields: Optional[List[Dict]] = None) -> List[str]:
        """
        Extract all strings from decoded fields
        
        Args:
            fields (List[Dict]): Fields to extract from (uses last_decoded if None)
            
        Returns:
            List[str]: Extracted strings
        """
        if fields is None:
            fields = self.last_decoded
        
        if fields is None:
            return []
        
        return ProtobufHandler.extract_strings(fields)
    
    def get_field(self, field_number: int, 
                 fields: Optional[List[Dict]] = None) -> List[Dict[str, Any]]:
        """
        Get specific field by number
        
        Args:
            field_number (int): Field number to extract
            fields (List[Dict]): Fields to search (uses last_decoded if None)
            
        Returns:
            List[Dict]: Matching fields
        """
        if fields is None:
            fields = self.last_decoded
        
        if fields is None:
            return []
        
        return ProtobufHandler.extract_by_field_number(fields, field_number)
    
    def format_last_result(self) -> str:
        """
        Format the last decoded result for display
        
        Returns:
            str: Formatted output
        """
        if self.last_decoded is None:
            return "No decoded data available"
        
        return ProtobufHandler.format_output(self.last_decoded)
    
    def get_packet_log(self) -> List[Dict[str, Any]]:
        """
        Get the packet processing log
        
        Returns:
            List[Dict]: Log entries
        """
        return self.packet_log
    
    def clear_log(self):
        """Clear the packet log"""
        self.packet_log = []
    
    def set_crypto_key(self, key: bytes):
        """Change the AES encryption key"""
        self.crypto.set_key(key)
    
    def set_crypto_iv(self, iv: bytes):
        """Change the AES IV"""
        self.crypto.set_iv(iv)
    
    def batch_process(self, packets: List[str]) -> List[Dict[str, Any]]:
        """
        Process multiple packets
        
        Args:
            packets (List[str]): List of hex-encoded packets
            
        Returns:
            List[Dict]: Results for each packet
        """
        results = []
        for packet in packets:
            result = self.process_packet(packet, log=True)
            results.append(result)
        return results
