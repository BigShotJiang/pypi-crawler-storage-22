"""
PacketSniffer: Network packet capture and analysis module
Captures and filters Free Fire game traffic
"""

from typing import Callable, Optional, List, Dict, Any
import socket
from .packet_handler import PacketHandler


class PacketSniffer:
    """
    Network Packet Sniffer
    
    Captures network packets and filters for Free Fire traffic.
    Requires root/administrator privileges.
    """
    
    # Known Free Fire server ports
    FF_PORTS = [
        443,    # HTTPS
        8080,   # HTTP
        9000,   # Game protocol
        10000,  # Game protocol
    ]
    
    # Known Free Fire server IPs/domains
    FF_DOMAINS = [
        'garenagame.com',
        'ff.garena.com',
        'ffauth.garena.com',
    ]
    
    def __init__(self, packet_handler: Optional[PacketHandler] = None):
        """
        Initialize PacketSniffer
        
        Args:
            packet_handler (PacketHandler): Handler for processing captured packets
        """
        self.packet_handler = packet_handler or PacketHandler()
        self.is_sniffing = False
        self.captured_packets = []
        self.filter_callback = None
    
    def set_filter(self, callback: Callable[[bytes], bool]):
        """
        Set custom packet filter callback
        
        Args:
            callback: Function that returns True if packet should be captured
        """
        self.filter_callback = callback
    
    def capture_raw_socket(self, interface: Optional[str] = None, 
                          timeout: int = 60) -> List[bytes]:
        """
        Capture packets using raw socket (requires root)
        
        Args:
            interface (str): Network interface to sniff on
            timeout (int): Capture timeout in seconds
            
        Returns:
            List[bytes]: Captured packet data
            
        Note:
            Requires root/administrator privileges
        """
        try:
            # Create raw socket
            if interface:
                sock = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.ntohs(3))
                sock.bind((interface, 0))
            else:
                sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_TCP)
            
            sock.settimeout(timeout)
            self.is_sniffing = True
            
            while self.is_sniffing:
                try:
                    packet, _ = sock.recvfrom(65535)
                    
                    # Apply filter if set
                    if self.filter_callback and not self.filter_callback(packet):
                        continue
                    
                    self.captured_packets.append(packet)
                
                except socket.timeout:
                    break
            
            sock.close()
        
        except PermissionError:
            raise PermissionError("Packet sniffing requires root/administrator privileges")
        except Exception as e:
            raise RuntimeError(f"Packet capture failed: {str(e)}")
        
        return self.captured_packets
    
    def stop_sniffing(self):
        """Stop the packet sniffing process"""
        self.is_sniffing = False
    
    def filter_by_port(self, packets: List[bytes], port: int) -> List[bytes]:
        """
        Filter packets by destination port
        
        Args:
            packets (List[bytes]): Packets to filter
            port (int): Target port
            
        Returns:
            List[bytes]: Filtered packets
        """
        # Basic port filtering (simplified - real implementation would parse TCP/UDP headers)
        filtered = []
        for packet in packets:
            # Check if port appears in packet (very basic)
            port_bytes = port.to_bytes(2, byteorder='big')
            if port_bytes in packet:
                filtered.append(packet)
        return filtered
    
    def filter_by_ff_ports(self, packets: List[bytes]) -> List[bytes]:
        """
        Filter packets by known Free Fire ports
        
        Args:
            packets (List[bytes]): Packets to filter
            
        Returns:
            List[bytes]: Filtered packets
        """
        filtered = []
        for packet in packets:
            for port in self.FF_PORTS:
                port_bytes = port.to_bytes(2, byteorder='big')
                if port_bytes in packet:
                    filtered.append(packet)
                    break
        return filtered
    
    def analyze_captured(self) -> List[Dict[str, Any]]:
        """
        Analyze all captured packets
        
        Returns:
            List[Dict]: Analysis results
        """
        results = []
        for packet in self.captured_packets:
            try:
                # Try to process as hex string
                packet_hex = packet.hex()
                result = self.packet_handler.process_packet(packet_hex, log=False)
                results.append(result)
            except Exception as e:
                results.append({
                    'success': False,
                    'error': str(e),
                })
        return results
    
    def clear_captured(self):
        """Clear the captured packets list"""
        self.captured_packets = []
    
    def get_captured_count(self) -> int:
        """Get the number of captured packets"""
        return len(self.captured_packets)
    
    def export_pcap(self, filename: str):
        """
        Export captured packets to PCAP file
        
        Args:
            filename (str): Output PCAP file path
        """
        try:
            import struct
            
            # PCAP file header
            pcap_header = struct.pack(
                '<4sHHiIII',
                b'\xa1\xb2\xc3\xd4',  # Magic number
                2, 4,                   # Version
                0,                      # Timezone
                0,                      # Timestamp accuracy
                65535,                  # Snapshot length
                1                       # Data link type (Ethernet)
            )
            
            with open(filename, 'wb') as f:
                f.write(pcap_header)
                
                for packet in self.captured_packets:
                    # Packet header
                    import time
                    ts = int(time.time())
                    packet_header = struct.pack(
                        '<IIII',
                        ts,              # Timestamp seconds
                        0,               # Timestamp microseconds
                        len(packet),     # Packet length (captured)
                        len(packet)      # Packet length (original)
                    )
                    f.write(packet_header)
                    f.write(packet)
        
        except Exception as e:
            raise RuntimeError(f"PCAP export failed: {str(e)}")
    
    @staticmethod
    def get_interfaces() -> List[str]:
        """
        Get available network interfaces
        
        Returns:
            List[str]: Interface names
        """
        try:
            import socket
            import fcntl
            import struct
            
            interfaces = []
            for interface in socket.if_nameindex():
                interfaces.append(interface[1])
            return interfaces
        except Exception:
            return []
