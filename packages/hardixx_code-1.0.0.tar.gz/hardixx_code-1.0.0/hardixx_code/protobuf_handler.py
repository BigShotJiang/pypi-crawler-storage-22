"""
ProtobufHandler: Protobuf message decoding and analysis module
Handles parsing of Google Protocol Buffer encoded data
"""

from typing import List, Dict, Any, Tuple
from google.protobuf.internal.decoder import _DecodeVarint32


class ProtobufHandler:
    """
    Protobuf Message Handler
    
    Decodes and analyzes Google Protocol Buffer encoded messages
    without requiring .proto schema definitions.
    """
    
    # Wire type definitions
    WIRE_TYPES = {
        0: "varint",
        1: "64-bit",
        2: "length-delimited",
        5: "32-bit"
    }
    
    @staticmethod
    def decode(data: bytes) -> List[Dict[str, Any]]:
        """
        Decode Protobuf message into field list
        
        Args:
            data (bytes): Raw protobuf encoded data
            
        Returns:
            List[Dict]: List of decoded fields with structure:
                {
                    'field_number': int,
                    'wire_type': str,
                    'wire_type_id': int,
                    'value': Any,
                    'raw_bytes': bytes (for length-delimited)
                }
                
        Raises:
            ValueError: If data is not valid protobuf
        """
        if not isinstance(data, bytes):
            raise TypeError("data must be bytes")
        
        if len(data) == 0:
            return []
        
        i = 0
        results = []
        
        try:
            while i < len(data):
                try:
                    key, i = _DecodeVarint32(data, i)
                except Exception:
                    break
                
                field_number = key >> 3
                wire_type = key & 0x7
                wire_name = ProtobufHandler.WIRE_TYPES.get(wire_type, "unknown")
                
                field_data = {
                    'field_number': field_number,
                    'wire_type': wire_name,
                    'wire_type_id': wire_type,
                }
                
                if wire_type == 0:  # varint
                    value, i = _DecodeVarint32(data, i)
                    field_data['value'] = value
                    results.append(field_data)
                
                elif wire_type == 2:  # length-delimited
                    length, i = _DecodeVarint32(data, i)
                    raw_bytes = data[i:i + length]
                    i += length
                    
                    # Try to decode as UTF-8 string
                    try:
                        decoded_str = raw_bytes.decode("utf-8")
                        field_data['value'] = decoded_str
                        field_data['is_string'] = True
                    except UnicodeDecodeError:
                        field_data['value'] = raw_bytes.hex()
                        field_data['is_string'] = False
                    
                    field_data['raw_bytes'] = raw_bytes
                    field_data['length'] = length
                    results.append(field_data)
                
                elif wire_type == 1:  # 64-bit
                    value = data[i:i+8].hex()
                    i += 8
                    field_data['value'] = value
                    results.append(field_data)
                
                elif wire_type == 5:  # 32-bit
                    value = data[i:i+4].hex()
                    i += 4
                    field_data['value'] = value
                    results.append(field_data)
                
                else:
                    break
        
        except Exception as e:
            raise ValueError(f"Protobuf decoding error: {str(e)}")
        
        return results
    
    @staticmethod
    def format_output(fields: List[Dict[str, Any]]) -> str:
        """
        Format decoded fields for pretty printing
        
        Args:
            fields (List[Dict]): Decoded fields from decode()
            
        Returns:
            str: Formatted output string
        """
        output = []
        output.append("\n" + "="*70)
        output.append("PROTOBUF DECODED FIELDS")
        output.append("="*70)
        
        for i, field in enumerate(fields, 1):
            output.append(f"\n[Field #{i}]")
            output.append(f"  Field Number: {field['field_number']}")
            output.append(f"  Wire Type: {field['wire_type']} ({field['wire_type_id']})")
            output.append(f"  Value: {field['value']}")
            
            if 'is_string' in field:
                output.append(f"  Is String: {field['is_string']}")
            if 'length' in field:
                output.append(f"  Length: {field['length']} bytes")
        
        output.append("\n" + "="*70)
        return "\n".join(output)
    
    @staticmethod
    def extract_strings(fields: List[Dict[str, Any]]) -> List[str]:
        """
        Extract all string values from decoded fields
        
        Args:
            fields (List[Dict]): Decoded fields
            
        Returns:
            List[str]: List of extracted strings
        """
        strings = []
        for field in fields:
            if field.get('is_string', False):
                strings.append(field['value'])
        return strings
    
    @staticmethod
    def extract_by_field_number(fields: List[Dict[str, Any]], 
                               field_number: int) -> List[Dict[str, Any]]:
        """
        Extract fields by field number
        
        Args:
            fields (List[Dict]): Decoded fields
            field_number (int): Target field number
            
        Returns:
            List[Dict]: Matching fields
        """
        return [f for f in fields if f['field_number'] == field_number]
    
    @staticmethod
    def to_dict(fields: List[Dict[str, Any]]) -> Dict[int, Any]:
        """
        Convert field list to dictionary (field_number -> value)
        
        Args:
            fields (List[Dict]): Decoded fields
            
        Returns:
            Dict: Dictionary mapping field numbers to values
        """
        result = {}
        for field in fields:
            fn = field['field_number']
            if fn in result:
                # Handle multiple values for same field
                if not isinstance(result[fn], list):
                    result[fn] = [result[fn]]
                result[fn].append(field['value'])
            else:
                result[fn] = field['value']
        return result
