"""
FFTelegramBot: Telegram bot interface for Free Fire packet analysis
Allows developers to analyze packets directly from Telegram
"""

from typing import Optional, Dict, Any
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class FFTelegramBot:
    """
    Free Fire Telegram Bot
    
    Provides a Telegram interface for packet analysis and decryption.
    Requires python-telegram-bot library and a Telegram bot token.
    """
    
    def __init__(self, token: str, packet_handler=None):
        """
        Initialize FFTelegramBot
        
        Args:
            token (str): Telegram bot token from BotFather
            packet_handler: PacketHandler instance for processing packets
        """
        self.token = token
        self.packet_handler = packet_handler
        self.bot = None
        self.user_sessions = {}
        
        try:
            from telegram import Update
            from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
            self.Update = Update
            self.Application = Application
            self.CommandHandler = CommandHandler
            self.MessageHandler = MessageHandler
            self.filters = filters
            self.ContextTypes = ContextTypes
        except ImportError:
            logger.warning("python-telegram-bot not installed. Install with: pip install python-telegram-bot")
    
    async def start(self, update: 'Update', context: 'ContextTypes'):
        """Handle /start command"""
        user_id = update.effective_user.id
        self.user_sessions[user_id] = {'mode': 'main'}
        
        welcome_text = """
 **FFDevLib - Free Fire Packet Analyzer**

Welcome to the Free Fire packet analysis bot!

**Available Commands:**
/help - Show help message
/decrypt - Decrypt a packet
/analyze - Analyze encrypted packet
/status - Show bot status
/clear - Clear session data

**How to use:**
1. Send /decrypt
2. Paste your hex-encoded encrypted packet
3. Bot will decrypt and decode it

Made with ❤ by H4RDIXX
        """
        
        await update.message.reply_text(welcome_text, parse_mode='Markdown')
    
    async def help_command(self, update: 'Update', context: 'ContextTypes'):
        """Handle /help command"""
        help_text = """
📚 **Help & Documentation**

**Commands:**
• /start - Start the bot
• /decrypt - Decrypt a packet
• /analyze - Full packet analysis
• /status - Check bot status
• /clear - Clear your session

**Packet Format:**
Send packets as hex strings (with or without spaces)
Example: `a1b2c3d4e5f6...`

**Example Usage:**
1. /decrypt
2. Paste: `a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6`
3. Get decrypted data

**Supported Operations:**
 AES-256-CBC Decryption
 Protobuf Decoding
 Field Extraction
 String Extraction
 Batch Processing

For more info: https://github.com/hardixx/hardixx-code
        """
        
        await update.message.reply_text(help_text, parse_mode='Markdown')
    
    async def decrypt_command(self, update: 'Update', context: 'ContextTypes'):
        """Handle /decrypt command"""
        user_id = update.effective_user.id
        self.user_sessions[user_id] = {'mode': 'decrypt', 'step': 1}
        
        await update.message.reply_text(
            " **Decrypt Mode**\n\nPaste your hex-encoded encrypted packet:",
            parse_mode='Markdown'
        )
    
    async def analyze_command(self, update: 'Update', context: 'ContextTypes'):
        """Handle /analyze command"""
        user_id = update.effective_user.id
        self.user_sessions[user_id] = {'mode': 'analyze', 'step': 1}
        
        await update.message.reply_text(
            " **Full Analysis Mode**\n\nPaste your hex-encoded encrypted packet:",
            parse_mode='Markdown'
        )
    
    async def status_command(self, update: 'Update', context: 'ContextTypes'):
        """Handle /status command"""
        status_text = """
 **Bot Status**

 Bot is online and ready
 Packet Handler: Active
 Crypto Module: Ready
 Protobuf Decoder: Ready

**Statistics:**
• Uptime: Always ready
• Processed Packets: ∞
• Errors: 0

Version: 1.0.0
Author: H4RDIXX
        """
        
        await update.message.reply_text(status_text, parse_mode='Markdown')
    
    async def clear_command(self, update: 'Update', context: 'ContextTypes'):
        """Handle /clear command"""
        user_id = update.effective_user.id
        if user_id in self.user_sessions:
            del self.user_sessions[user_id]
        
        await update.message.reply_text(" Session cleared!")
    
    async def handle_message(self, update: 'Update', context: 'ContextTypes'):
        """Handle regular messages"""
        user_id = update.effective_user.id
        message_text = update.message.text
        
        session = self.user_sessions.get(user_id, {'mode': 'main'})
        mode = session.get('mode', 'main')
        
        if mode == 'decrypt':
            await self._handle_decrypt_message(update, context, message_text)
        elif mode == 'analyze':
            await self._handle_analyze_message(update, context, message_text)
        else:
            await update.message.reply_text(
                " Use /help for available commands"
            )
    
    async def _handle_decrypt_message(self, update: 'Update', context: 'ContextTypes', 
                                     packet_hex: str):
        """Handle message in decrypt mode"""
        if not self.packet_handler:
            await update.message.reply_text(" Packet handler not configured")
            return
        
        try:
            # Show processing message
            processing_msg = await update.message.reply_text(" Processing...")
            
            # Decrypt
            decrypted = self.packet_handler.decrypt_only(packet_hex)
            
            # Format response
            response = f"""
 **Decryption Successful**

**Decrypted (Hex):**
```
{decrypted.hex()}
```

**Decrypted (Bytes):**
{len(decrypted)} bytes

**Preview (UTF-8):**
```
{decrypted[:100].decode('utf-8', errors='ignore')}...
```
            """
            
            await processing_msg.delete()
            await update.message.reply_text(response, parse_mode='Markdown')
        
        except Exception as e:
            await update.message.reply_text(f" Error: {str(e)}")
    
    async def _handle_analyze_message(self, update: 'Update', context: 'ContextTypes',
                                     packet_hex: str):
        """Handle message in analyze mode"""
        if not self.packet_handler:
            await update.message.reply_text(" Packet handler not configured")
            return
        
        try:
            # Show processing message
            processing_msg = await update.message.reply_text(" Analyzing packet...")
            
            # Process packet
            result = self.packet_handler.process_packet(packet_hex, log=True)
            
            if not result['success']:
                await processing_msg.delete()
                await update.message.reply_text(f" Error: {result['error']}")
                return
            
            # Extract data
            fields = result['fields']
            strings = self.packet_handler.extract_strings(fields)
            
            # Format response
            response = f"""
 **Packet Analysis Complete**

**Decrypted Size:** {len(result['decrypted'])} bytes

**Protobuf Fields:** {len(fields)} fields found

**Extracted Strings:**
"""
            
            for i, s in enumerate(strings[:5], 1):  # Show first 5 strings
                response += f"\n{i}. `{s[:50]}{'...' if len(s) > 50 else ''}`"
            
            if len(strings) > 5:
                response += f"\n... and {len(strings) - 5} more"
            
            response += f"""

**Field Summary:**
"""
            
            for field in fields[:10]:  # Show first 10 fields
                response += f"\nField {field['field_number']}: {field['wire_type']}"
            
            if len(fields) > 10:
                response += f"\n... and {len(fields) - 10} more fields"
            
            await processing_msg.delete()
            await update.message.reply_text(response, parse_mode='Markdown')
        
        except Exception as e:
            await update.message.reply_text(f" Error: {str(e)}")
    
    def setup_handlers(self):
        """Setup all command and message handlers"""
        if not self.Application:
            logger.error("python-telegram-bot not available")
            return False
        
        app = self.Application.builder().token(self.token).build()
        
        # Add handlers
        app.add_handler(self.CommandHandler("start", self.start))
        app.add_handler(self.CommandHandler("help", self.help_command))
        app.add_handler(self.CommandHandler("decrypt", self.decrypt_command))
        app.add_handler(self.CommandHandler("analyze", self.analyze_command))
        app.add_handler(self.CommandHandler("status", self.status_command))
        app.add_handler(self.CommandHandler("clear", self.clear_command))
        app.add_handler(self.MessageHandler(self.filters.TEXT & ~self.filters.COMMAND, 
                                           self.handle_message))
        
        self.bot = app
        return True
    
    def run(self):
        """Start the bot"""
        if not self.bot:
            if not self.setup_handlers():
                logger.error("Failed to setup bot handlers")
                return
        
        logger.info("Starting FFTelegramBot...")
        self.bot.run_polling()
    
    def run_async(self):
        """Run bot asynchronously"""
        if not self.bot:
            if not self.setup_handlers():
                logger.error("Failed to setup bot handlers")
                return
        
        import asyncio
        asyncio.run(self.bot.run_polling())
