from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="hardixx-code",
    version="1.0.0",
    author="H4RDIXX",
    author_email="adomaderbali@gmail.com",
    description="Advanced Free Fire packet analysis, decryption, and reverse engineering library",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/hardixx/hardixx-code",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.8",
    install_requires=[
        "pycryptodome>=3.15.0",
        "protobuf>=3.20.0",
        "python-telegram-bot>=20.0",
        "requests>=2.28.0",
        "scapy>=2.5.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0",
            "pytest-cov>=4.0",
            "black>=22.0",
            "flake8>=4.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "hardixx-cli=hardixx_code.cli:main",
        ],
    },
)
