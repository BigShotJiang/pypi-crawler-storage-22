# Copyright (c) 2025 Everypin
# GNU General Public License v3.0 (see LICENSE or https://www.gnu.org/licenses/gpl-3.0.txt)

from hardpy.pytest_hardpy.result.report_synchronizer.synchronizer import (
    StandCloudSynchronizer,
)

__all__ = [
    "StandCloudSynchronizer",
]
