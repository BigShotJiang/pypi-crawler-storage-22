# HardwareXtractor

Completa fichas técnicas de hardware en minutos. Introduce el modelo de cada componente y obtén especificaciones verificadas con trazabilidad completa.

## Características

- **Extracción automatizada** de specs desde fuentes oficiales y de referencia
- **Trazabilidad completa**: cada valor incluye origen, URL y nivel de confianza
- **Sistema de fallback**: si una fuente falla, intenta automáticamente la siguiente
- **Detección anti-bot**: identifica protecciones Cloudflare/CAPTCHA y usa Playwright como fallback
- **Múltiples interfaces**: GUI (Tkinter) y CLI interactivo
- **Exportación flexible**: CSV, XLSX (con colores por tier) y Markdown

## Instalación

### Desde PyPI (recomendado)

```bash
pip install hardwarextractor
```

### Dependencias opcionales

```bash
# Para sitios con protección anti-bot (Playwright)
pip install hardwarextractor[browser]

# Para exportación a Excel
pip install hardwarextractor[excel]

# Instalación completa
pip install hardwarextractor[full]
```

### Desde código fuente

```bash
git clone https://github.com/NAZCAMEDIA/hardwarextractor.git
cd hardwarextractor
pip install -e ".[full]"
```

## Uso

### CLI (línea de comandos)

```bash
hxtractor
```

Muestra el menú interactivo con arte ASCII:

```
  ██╗  ██╗██╗  ██╗████████╗██████╗  █████╗  ██████╗████████╗ ██████╗ ██████╗
  ██║  ██║╚██╗██╔╝╚══██╔══╝██╔══██╗██╔══██╗██╔════╝╚══██╔══╝██╔═══██╗██╔══██╗
  ███████║ ╚███╔╝    ██║   ██████╔╝███████║██║        ██║   ██║   ██║██████╔╝
  ██╔══██║ ██╔██╗    ██║   ██╔══██╗██╔══██║██║        ██║   ██║   ██║██╔══██╗
  ██║  ██║██╔╝ ██╗   ██║   ██║  ██║██║  ██║╚██████╗   ██║   ╚██████╔╝██║  ██║
  ╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝   ╚═╝    ╚═════╝ ╚═╝  ╚═╝

                           v1.0.0 - Hardware Specs Extractor
                              © 2025 NAZCAMEDIA

  1) Analizar componente
  2) Exportar ficha
  3) Reset ficha
  4) Salir
```

### GUI (interfaz gráfica)

```bash
hxtractor-gui
```

### Características del CLI

- **Spinner animado** con tiempo transcurrido durante el análisis
- **Mensajes de estado** descriptivos: "Normalizando...", "Clasificando...", "Extrayendo..."
- **Información completa** de cada componente con fuentes y URLs
- **Leyenda de colores** para identificar el origen de cada dato
- **Auto-agregado** a la ficha técnica

### Flujo básico

1. Introduce un componente (ej. `CMK32GX5M2B6000C36` o `intel i7`)
2. El spinner muestra el progreso con tiempo transcurrido
3. El sistema clasifica el tipo (RAM, CPU, GPU, etc.)
4. Busca en fuentes oficiales primero, luego referencias
5. Muestra especificaciones con indicador de tier y fuente
6. Agrega automáticamente a la ficha
7. Repite con más componentes
8. Exporta a CSV/XLSX/MD

### Búsquedas soportadas

- **Por modelo específico**: `i9-14900K`, `RTX 4090`, `CMK32GX5M2B6000C36`
- **Por familia de procesador**: `intel i7`, `intel i5`, `ryzen 9`, `amd ryzen 7`
- **Por part number**: `CMK32GX5M2B5600C36`
- **Por URL**: URL directa a specs del fabricante

## Sistema de Tiers

| Tier | Descripción | Indicador |
|------|-------------|-----------|
| OFFICIAL | Datos del fabricante | ● verde |
| REFERENCE | Bases de datos técnicas (TechPowerUp, WikiChip) | ◐ naranja |
| CALCULATED | Valores derivados de otros campos | ◇ azul |
| UNKNOWN | Sin fuente verificable | gris |

## Componentes soportados

- **CPU**: Intel, AMD
- **RAM**: Corsair, Kingston, G.Skill, Crucial, Samsung
- **GPU**: NVIDIA, AMD, Intel
- **Motherboard**: ASUS, MSI, Gigabyte, ASRock
- **Storage**: Samsung, WD, Seagate, Crucial, Kingston

## Arquitectura

```
hardwarextractor/
├── app/           # Orchestrator principal
├── core/          # Eventos y SourceChain
├── cli/           # Interfaz de línea de comandos
├── ui/            # Interfaz gráfica Tkinter
├── scrape/        # Spiders y engines (Requests/Playwright)
├── engine/        # FichaManager, IPC, Commands
├── export/        # Exportadores (CSV, XLSX, MD)
└── models/        # Schemas y tipos
```

## Exportación

### CSV
```bash
# Desde CLI: opción 3 > csv > ruta
```

### Excel (XLSX)
Incluye:
- Colores por tier (verde=oficial, naranja=referencia)
- Banner de advertencia si hay datos REFERENCE
- Columnas: Sección, Campo, Valor, Unidad, Status, Tier, Fuente, URL

### Markdown
Tabla formateada con secciones y leyenda de tiers.

## Configuración

Archivo `~/.config/hardwarextractor/config.yaml`:

```yaml
enable_tier2: true          # Permitir fuentes REFERENCE
user_agent: "HardwareXtractor/0.2"
retries: 2
throttle_seconds_by_domain:
  crucial.com: 1.0
  corsair.com: 2.0
```

## Desarrollo

```bash
# Instalar dependencias de desarrollo
pip install -e ".[dev]"

# Ejecutar tests
pytest

# Tests con cobertura
pytest --cov=hardwarextractor --cov-report=term-missing
```

## Descargas (macOS)

Binarios precompilados disponibles en:
- `downloads/HardwareXtractor.dmg`
- `downloads/HardwareXtractor.app`

## Licencia

MIT License - Copyright (c) 2026 [NAZCAMEDIA](https://www.nazcamedia.net)

Ver `LICENSE` para más detalles.

## Changelog

### v1.1.0
- **Intel ARK Extractor**: Soporte completo para scraping de Intel ARK (29+ specs por CPU)
- **Búsqueda por familia**: Soporta búsquedas genéricas como "intel i7" o "ryzen 9"
- **Nuevos mappings**: 25+ labels de Intel ARK (P-cores, E-cores, Turbo Boost 3.0, TDP, etc.)
- **macOS App**: Build actualizado con PyInstaller y DMG para distribución
- Fix: Extracción de datos de Intel ARK que antes retornaba 0 specs

### v1.0.0 (CLI)
- Header ASCII art con branding NAZCAMEDIA
- Spinner animado con tiempo transcurrido
- Mensajes de estado descriptivos por fase
- Información completa: specs, fuentes, URLs y leyenda de tiers
- Auto-agregado de componentes a la ficha
- Menú simplificado de 4 opciones
- Filtrado de mensajes de debug

### v0.2.0
- CLI interactivo con menú y colores ANSI
- Sistema SourceChain con fallback automático
- Detección de anti-bot (Cloudflare, CAPTCHA)
- Exportación a XLSX y Markdown
- Eventos detallados para logging en tiempo real
- Soporte para Playwright en sitios protegidos

### v0.1.0
- Release inicial con GUI Tkinter
- Exportación CSV
- Soporte básico para CPU, RAM, GPU, Motherboard, Storage
