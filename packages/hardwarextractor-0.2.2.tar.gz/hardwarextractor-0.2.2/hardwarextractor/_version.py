"""Single source of truth for version."""

__version__ = "0.2.2"
