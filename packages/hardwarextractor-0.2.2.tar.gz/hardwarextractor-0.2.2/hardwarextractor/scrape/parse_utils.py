from __future__ import annotations

from hardwarextractor.scrape.extractors import parse_data_spec_fields, parse_labeled_fields

__all__ = ["parse_data_spec_fields", "parse_labeled_fields"]
