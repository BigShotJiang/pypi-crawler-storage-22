"""Top-level package for Feature Flag Server SDK."""

__author__ = """Harness"""
__email__ = "support@harness.io"
__version__ = '1.7.4'
