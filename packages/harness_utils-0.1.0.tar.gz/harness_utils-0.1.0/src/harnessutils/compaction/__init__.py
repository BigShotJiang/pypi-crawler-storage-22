"""Context compaction strategies."""

from harnessutils.compaction.truncation import TruncationResult, truncate_output

__all__ = ["truncate_output", "TruncationResult"]
