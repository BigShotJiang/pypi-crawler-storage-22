# Context Rot Prevention: Improvement Opportunities

**Document Type:** Technical Analysis & Roadmap
**Date:** 2026-02-12
**Status:** Planning

## Executive Summary

Current implementation uses three tiers (truncation → pruning → summarization) but lacks semantic intelligence. All operations are mechanical (byte counts, FIFO removal, full re-summarization). This leads to:

- **Information loss** - Important context pruned same as noise
- **Inefficiency** - Expensive re-summarization of entire history
- **Context rot** - Relevance decay not modeled, leading to stale context accumulation

## Current State Analysis

### Tier 1: Truncation
**File:** `src/harnessutils/compaction/truncation.py`

**Current Implementation:**
- Fixed thresholds: 2000 lines OR 50KB
- Direction: head or tail only
- Cuts at line boundary
- No content awareness

**Weaknesses:**
- ❌ Cuts mid-structure (JSON, logs, stack traces)
- ❌ No syntax preservation
- ❌ Cuts at char boundary, not token boundary
- ❌ Fixed threshold regardless of content type
- ❌ No importance detection (errors, summaries, conclusions)

### Tier 2: Pruning
**File:** `src/harnessutils/compaction/pruning.py`

**Current Implementation:**
- Token estimation: `chars / 4` heuristic (line 72)
- Protection window: 40K tokens (most recent)
- Minimum savings: 20K tokens
- Protected turns: last 2
- Protected tools: skill_execution, subtask_invocation
- Strategy: Reverse chronological (oldest first)

**Weaknesses:**
- ❌ Inaccurate token counting (10-30% error)
- ❌ No prioritization (all outputs equal value)
- ❌ No duplicate detection
- ❌ Fixed thresholds ignore conversation dynamics
- ❌ Can't detect user-referenced vs forgotten outputs
- ❌ No semantic importance scoring

### Tier 3: Summarization
**File:** `src/harnessutils/compaction/summarization.py`

**Current Implementation:**
- Full conversation re-summarization (line 79-82)
- Generic prompt (line 14-26)
- Reactive overflow detection (after limit exceeded)
- Stops at previous summary marker

**Weaknesses:**
- ❌ Expensive - Re-processes entire history each time
- ❌ Lossy - Fidelity degrades with each cycle
- ❌ No differential approach (only new content)
- ❌ Generic prompt (not agent/domain-aware)
- ❌ No lazy evaluation (summarizes even if conversation ends)
- ❌ No hierarchical granularity (one-size-fits-all)

### Token Counting
**Files:** `src/harnessutils/tokens/estimator.py`, `src/harnessutils/tokens/exact.py`

**Current State:**
- Heuristic: `chars / 4` used for pruning decisions
- Exact: tiktoken available (v0.1.6) but only used for `calculate_context_usage`

**Opportunity:**
- ✅ Already have tiktoken dependency
- ❌ Not using it where it matters (pruning decisions)

---

## Improvement Opportunities

### 1. Smart Truncation (Content-Aware)

**Problem:** Current truncation is blind to content structure.

**Solution:** Semantic truncation with content detection.

**Implementation Strategy:**
```python
def detect_content_type(output: str) -> ContentType:
    """Detect output structure."""
    if looks_like_json(output):
        return ContentType.JSON
    elif looks_like_code(output):
        return ContentType.CODE
    elif looks_like_stacktrace(output):
        return ContentType.STACKTRACE
    elif looks_like_logs(output):
        return ContentType.LOGS
    else:
        return ContentType.TEXT

def smart_truncate(output: str, token_limit: int) -> str:
    """Truncate preserving structure and importance."""
    content_type = detect_content_type(output)

    if content_type == ContentType.JSON:
        # Parse, truncate large arrays/objects, preserve structure
        return truncate_json(output, token_limit)

    elif content_type == ContentType.STACKTRACE:
        # Keep error message + top/bottom of stack
        return truncate_stacktrace(output, token_limit)

    elif content_type == ContentType.CODE:
        # Keep function signatures, truncate bodies
        return truncate_code(output, token_limit)

    elif content_type == ContentType.LOGS:
        # Keep errors/warnings, sample info/debug
        return truncate_logs(output, token_limit)

    else:
        # Keep first + last sections
        return truncate_text(output, token_limit)

def truncate_at_token_boundary(text: str, token_limit: int) -> str:
    """Cut at token boundary using tiktoken."""
    encoding = tiktoken.get_encoding("cl100k_base")
    tokens = encoding.encode(text)

    if len(tokens) <= token_limit:
        return text

    # Cut at token boundary
    head_tokens = tokens[:token_limit // 2]
    tail_tokens = tokens[-(token_limit // 2):]

    head = encoding.decode(head_tokens)
    tail = encoding.decode(tail_tokens)

    removed = len(tokens) - token_limit
    return f"{head}\n\n... {removed} tokens truncated ...\n\n{tail}"
```

**Impact:**
- Better preservation of critical info
- Syntax-valid truncation
- Accurate token-based limits

**Effort:** Medium (2-3 days)

---

### 2. Importance-Scored Pruning

**Problem:** Current pruning treats all outputs equally (FIFO).

**Solution:** Score outputs by importance, prune lowest-value first.

**Implementation Strategy:**
```python
@dataclass
class OutputImportance:
    """Importance score for tool output."""
    recency_score: float      # Exponential decay
    size_penalty: float       # Large outputs penalized
    semantic_score: float     # Contains errors, user refs, etc.
    tool_priority: float      # Tool type importance
    reference_count: int      # How often referenced later

    @property
    def total_score(self) -> float:
        return (
            self.recency_score * 1.0 +
            self.size_penalty * -0.5 +
            self.semantic_score * 2.0 +
            self.tool_priority * 1.5 +
            self.reference_count * 100
        )

def score_tool_output(
    part: ToolPart,
    current_turn: int,
    conversation_history: list[Message]
) -> OutputImportance:
    """Calculate importance score for tool output."""

    # 1. Recency (exponential decay)
    age = current_turn - part.turn_number
    recency = math.exp(-age * 0.1) * 100

    # 2. Size penalty (prefer removing large outputs)
    token_count = count_tokens_exact(part.state.output)
    size_penalty = math.log(token_count + 1) * 10

    # 3. Semantic importance
    semantic = 0
    output = part.state.output.lower()

    if "error" in output or "exception" in output:
        semantic += 500  # Errors are critical

    if "warning" in output:
        semantic += 200

    if part.metadata.get("user_requested"):
        semantic += 300  # User explicitly asked for this

    # 4. Tool type importance
    tool_priority = TOOL_IMPORTANCE_MAP.get(part.tool, 50)

    # 5. Reference count (how often mentioned later)
    references = count_references_to_output(part, conversation_history)

    return OutputImportance(
        recency_score=recency,
        size_penalty=size_penalty,
        semantic_score=semantic,
        tool_priority=tool_priority,
        reference_count=references,
    )

def prune_tool_outputs_smart(
    messages: list[Message],
    config: PruningConfig,
    current_turn: int,
) -> PruningResult:
    """Prune lowest-importance outputs first."""

    # Score all prunable outputs
    scored_parts = []
    for msg in messages:
        for part in msg.parts:
            if is_prunable(part, config):
                score = score_tool_output(part, current_turn, messages)
                scored_parts.append((part, score))

    # Sort by importance (lowest first)
    scored_parts.sort(key=lambda x: x[1].total_score)

    # Prune until we hit token budget
    total_tokens = sum(estimate_tokens(p.state.output) for p, _ in scored_parts)
    pruned = []

    for part, score in scored_parts:
        if total_tokens <= config.prune_protect:
            break

        tokens = estimate_tokens(part.state.output)
        part.state.output = ""
        part.state.compacted = now()

        total_tokens -= tokens
        pruned.append(part)

    return PruningResult(
        pruned=len(pruned),
        tokens_saved=sum(estimate_tokens(p.state.output) for p in pruned)
    )
```

**Configuration:**
```python
@dataclass
class ToolImportanceConfig:
    """Tool type importance weights."""
    importance_map: dict[str, float] = field(default_factory=lambda: {
        "read": 50,           # Neutral
        "write": 100,         # Important - code changes
        "grep": 30,           # Low - often repetitive
        "bash": 70,           # Medium - commands matter
        "skill_execution": 150,  # High - complex operations
        "error": 200,         # Critical - debugging
    })
```

**Impact:**
- Preserve critical information longer
- Remove noise/redundancy faster
- Better token budget allocation

**Effort:** Medium (3-4 days)

---

### 3. Semantic Deduplication

**Problem:** Repeated outputs (same file read 5x) stored fully each time.

**Solution:** Detect duplicates, prune aggressively.

**Implementation Strategy:**
```python
from hashlib import md5
from difflib import SequenceMatcher

def similarity_hash(text: str, n: int = 5) -> set[str]:
    """Generate shingles (n-grams) for similarity detection."""
    words = text.split()
    return {
        " ".join(words[i:i+n])
        for i in range(len(words) - n + 1)
    }

def jaccard_similarity(set1: set, set2: set) -> float:
    """Calculate Jaccard similarity between two sets."""
    if not set1 or not set2:
        return 0.0
    intersection = len(set1 & set2)
    union = len(set1 | set2)
    return intersection / union

def find_duplicate_outputs(
    current_part: ToolPart,
    recent_parts: list[ToolPart],
    threshold: float = 0.8,
) -> ToolPart | None:
    """Find if current output is duplicate of recent output."""

    current_hash = similarity_hash(current_part.state.output)

    for recent in recent_parts:
        if recent.tool != current_part.tool:
            continue  # Different tools unlikely to duplicate

        recent_hash = similarity_hash(recent.state.output)
        similarity = jaccard_similarity(current_hash, recent_hash)

        if similarity >= threshold:
            return recent  # Found duplicate

    return None

def deduplicate_during_pruning(
    messages: list[Message],
    config: PruningConfig,
) -> PruningResult:
    """Aggressive pruning of duplicate outputs."""

    seen_outputs: dict[str, ToolPart] = {}
    duplicates_found = []

    for msg in reversed(messages):  # Newest first
        for part in msg.parts:
            if not isinstance(part, ToolPart):
                continue

            # Check for duplicate
            duplicate = find_duplicate_outputs(
                part,
                list(seen_outputs.values()),
                threshold=0.85,
            )

            if duplicate:
                # This is a duplicate - prune immediately
                if part.turn_number < duplicate.turn_number:
                    # Prune the older one
                    target = part
                else:
                    # Keep newer, prune older duplicate
                    target = duplicate

                target.state.output = f"[Duplicate of {part.tool} output, see turn {duplicate.turn_number}]"
                target.state.compacted = now()
                duplicates_found.append(target)
            else:
                seen_outputs[part.id] = part

    tokens_saved = sum(
        estimate_tokens(p.state.output) for p in duplicates_found
    )

    return PruningResult(
        pruned=len(duplicates_found),
        tokens_saved=tokens_saved,
    )
```

**Impact:**
- Dramatically reduce redundancy
- Faster token budget recovery
- Better signal-to-noise ratio

**Effort:** Medium (2-3 days)

---

### 4. Differential Summarization

**Problem:** Current approach re-summarizes entire history each time (expensive, lossy).

**Solution:** Only summarize new content since last summary.

**Implementation Strategy:**
```python
def differential_summarize(
    messages: list[Message],
    llm_client: LLMClient,
    parent_message_id: str,
    message_id: str,
) -> SummarizationResult:
    """Summarize only new content since last summary."""

    # Find last summary
    last_summary = None
    new_messages = []

    for msg in reversed(messages):
        if msg.summary:
            last_summary = msg
            break
        new_messages.insert(0, msg)

    if last_summary:
        # Differential: merge previous summary + new content
        prompt = f"""You previously summarized this conversation:

{last_summary.parts[0].text}

Since then, the following happened:

{format_messages_for_summary(new_messages)}

Provide an UPDATED summary that:
1. Incorporates new information
2. Preserves critical context from previous summary
3. Maintains chronological coherence
4. Is concise but comprehensive

Focus on:
- What changed or was completed
- New decisions or constraints
- Updated state of work
- Next steps
"""
    else:
        # First summarization - full context
        prompt = f"""Summarize this conversation:

{format_messages_for_summary(messages)}

Include:
- What was done
- Current state
- Files modified
- Key decisions
- User preferences
- Next steps
"""

    # Use cheaper model for summarization
    response = llm_client.invoke(
        messages=[{"role": "user", "content": prompt}],
        system=[SUMMARIZATION_PROMPT],
        model="claude-3-5-haiku-20241022",  # Cheaper
    )

    # ... rest of implementation
```

**Configuration:**
```python
@dataclass
class SummarizationConfig:
    """Summarization strategy configuration."""
    mode: str = "differential"  # "differential" or "full"
    max_new_messages: int = 30  # Max messages since last summary
    cheap_model: str = "claude-3-5-haiku-20241022"
```

**Impact:**
- 60-80% cost reduction
- Faster summarization (smaller input)
- Better fidelity (less compression loss)

**Effort:** Low (1-2 days)

---

### 5. Use Exact Token Counting for Pruning

**Problem:** Line 72 of `pruning.py` uses `estimate_tokens(chars/4)` - inaccurate (10-30% error).

**Solution:** Use tiktoken (already available in 0.1.6) for accurate counts.

**Implementation Strategy:**
```python
# In pruning.py, replace line 72:

# OLD:
token_estimate = estimate_tokens(part.state.output, chars_per_token)

# NEW:
from harnessutils.tokens.exact import count_tokens_exact

token_estimate = count_tokens_exact(
    messages=[{"role": "assistant", "content": part.state.output}],
    model="claude-3-5-sonnet-20241022"
)
```

**Optimization (cache encoding):**
```python
# Cache the encoding to avoid repeated loading
_encoding_cache = None

def get_encoding():
    global _encoding_cache
    if _encoding_cache is None:
        _encoding_cache = tiktoken.get_encoding("cl100k_base")
    return _encoding_cache

def count_tokens_fast(text: str) -> int:
    """Fast exact token counting."""
    encoding = get_encoding()
    return len(encoding.encode(text))
```

**Impact:**
- Accurate pruning decisions
- No under/over-pruning
- Better token budget management

**Effort:** Low (1 hour)

---

### 6. Predictive Overflow Detection

**Problem:** Current detection is reactive (after overflow). Can't prevent proactively.

**Solution:** Predict overflow before it happens, trigger early summarization.

**Implementation Strategy:**
```python
@dataclass
class ConversationVelocity:
    """Track conversation token growth rate."""
    turn_deltas: list[int]  # Token delta per turn
    window_size: int = 10

    def add_turn(self, tokens_added: int):
        """Record token growth for this turn."""
        self.turn_deltas.append(tokens_added)
        if len(self.turn_deltas) > self.window_size:
            self.turn_deltas.pop(0)

    @property
    def avg_growth(self) -> float:
        """Average token growth per turn."""
        if not self.turn_deltas:
            return 0
        return sum(self.turn_deltas) / len(self.turn_deltas)

    @property
    def growth_trend(self) -> float:
        """Growth acceleration (positive = accelerating)."""
        if len(self.turn_deltas) < 5:
            return 0

        recent = sum(self.turn_deltas[-5:]) / 5
        older = sum(self.turn_deltas[-10:-5]) / 5 if len(self.turn_deltas) >= 10 else recent

        return recent - older

def predict_overflow(
    current_tokens: int,
    velocity: ConversationVelocity,
    config: ModelLimitsConfig,
    lookahead_turns: int = 5,
) -> bool:
    """Predict if overflow will occur within N turns."""

    # Project future token count
    projected = current_tokens + (velocity.avg_growth * lookahead_turns)

    # If accelerating, add acceleration factor
    if velocity.growth_trend > 0:
        projected += velocity.growth_trend * (lookahead_turns ** 2) / 2

    # Safety margin (trigger at 80% of limit)
    safety_margin = 0.8
    usable_limit = config.default_context_limit * safety_margin

    return projected >= usable_limit

# Usage in manager.py:
def needs_compaction_predictive(
    self,
    conversation_id: str,
    usage: Usage,
    velocity: ConversationVelocity,
) -> bool:
    """Predictive overflow detection."""

    # Current reactive check
    if is_overflow(usage, self.config.model_limits):
        return True  # Already overflowed

    # Predictive check
    current_tokens = usage.input + usage.cache.read
    return predict_overflow(
        current_tokens,
        velocity,
        self.config.model_limits,
        lookahead_turns=5,
    )
```

**Impact:**
- Prevent overflow before it happens
- Smoother user experience (no sudden stops)
- Better timing for summarization

**Effort:** Medium (2 days)

---

### 7. Hierarchical Summaries

**Problem:** One-size-fits-all summary. Sometimes need high-level, sometimes detailed.

**Solution:** Multi-level summaries (high/medium/detailed).

**Implementation Strategy:**
```python
@dataclass
class HierarchicalSummary:
    """Multi-granularity summary."""
    high_level: str      # 10-50 tokens - "Working on auth system"
    medium: str          # 100-500 tokens - Key decisions + files
    detailed: str        # 1000-5000 tokens - Full context

def generate_hierarchical_summary(
    messages: list[Message],
    llm_client: LLMClient,
) -> HierarchicalSummary:
    """Generate summaries at multiple granularities."""

    # Single LLM call with structured output
    prompt = """Summarize this conversation at THREE levels:

1. HIGH_LEVEL (1-2 sentences, <50 tokens):
   Extreme high-level overview. What is being worked on?

2. MEDIUM (1 paragraph, <500 tokens):
   Key activities, decisions, files modified, current state.

3. DETAILED (<5000 tokens):
   Comprehensive summary with full context for continuation.

Format as JSON:
{
  "high_level": "...",
  "medium": "...",
  "detailed": "..."
}
"""

    response = llm_client.invoke(
        messages=[{"role": "user", "content": prompt}],
        model="claude-3-5-haiku-20241022",
    )

    summaries = json.loads(response["content"])
    return HierarchicalSummary(**summaries)

def load_appropriate_summary_level(
    summary: HierarchicalSummary,
    token_budget: int,
) -> str:
    """Load summary level based on available budget."""

    if token_budget > 5000:
        return summary.detailed
    elif token_budget > 500:
        return summary.medium
    else:
        return summary.high_level
```

**Impact:**
- Flexible context usage
- Better budget allocation
- Faster loading (use high-level when possible)

**Effort:** Medium (2-3 days)

---

### 8. Information Decay Modeling

**Problem:** No model of information "staleness" - recent and old treated equally within window.

**Solution:** Model information half-life, prune when value decays below threshold.

**Implementation Strategy:**
```python
def information_value(
    part: ToolPart,
    current_turn: int,
    half_life_turns: int = 10,
) -> float:
    """Calculate current value of information with decay."""

    # Base value from importance scoring
    base_value = calculate_base_importance(part)

    # Age in turns
    age = current_turn - part.turn_number

    # Exponential decay (half-life model)
    decay_factor = 0.5 ** (age / half_life_turns)

    return base_value * decay_factor

def prune_with_decay(
    messages: list[Message],
    current_turn: int,
    min_value_threshold: float = 10.0,
) -> PruningResult:
    """Prune outputs whose value has decayed below threshold."""

    pruned = []

    for msg in messages:
        for part in msg.parts:
            if not isinstance(part, ToolPart):
                continue

            value = information_value(part, current_turn)

            if value < min_value_threshold:
                # Value has decayed - prune
                tokens = estimate_tokens(part.state.output)
                part.state.output = ""
                part.state.compacted = now()
                pruned.append((part, tokens))

    return PruningResult(
        pruned=len(pruned),
        tokens_saved=sum(t for _, t in pruned),
    )
```

**Configuration:**
```python
@dataclass
class DecayConfig:
    """Information decay configuration."""
    half_life_turns: int = 10  # Info half-life: 10 turns
    min_value: float = 10.0    # Prune below this value

    # Different decay rates per content type
    decay_rates: dict[str, float] = field(default_factory=lambda: {
        "error": 0.3,      # Errors decay slowly
        "file_read": 1.0,  # Normal decay
        "grep_result": 1.5,  # Fast decay (gets stale quickly)
        "user_input": 0.1,   # User input never decays
    })
```

**Impact:**
- Natural pruning of stale info
- Keep recent info longer
- Adaptive to conversation flow

**Effort:** Medium (2-3 days)

---

## Implementation Roadmap

### Phase 1: Quick Wins (1 week)
**Goal:** Immediate impact with minimal effort

1. ✅ **COMPLETED: Use exact token counting** (1 hour)
   - ✅ Replaced `estimate_tokens` in pruning.py with tiktoken
   - ✅ Cached encoding for performance
   - ✅ Added `count_tokens_fast()` function
   - ✅ All tests passing
   - **Impact:** Error rate eliminated (was 16-100% inaccurate)

2. ✅ **COMPLETED: Basic importance scoring** (2 days)
   - ✅ Added OutputImportance dataclass with score components
   - ✅ Implemented recency scoring (exponential decay)
   - ✅ Implemented size penalty (prefer removing large outputs)
   - ✅ Implemented semantic scoring (errors +500, warnings +200, user-requested +300)
   - ✅ Implemented tool priority map (configurable per tool type)
   - ✅ Smart pruning: prunes lowest-value outputs first (not FIFO)
   - ✅ Preserves critical info (errors, warnings) even when old
   - ✅ 11 comprehensive tests added
   - ✅ Enabled by default (can disable to fall back to FIFO)
   - **Impact:** Critical outputs preserved, noise removed faster

3. ✅ **COMPLETED: Duplicate detection** (2-3 days)
   - ✅ Implemented similarity hashing (shingles + Jaccard)
   - ✅ Exact duplicate detection (MD5 hash)
   - ✅ Near-duplicate detection (80% similarity threshold)
   - ✅ Tool-specific matching (prevents cross-tool false positives)
   - ✅ Configurable similarity threshold & lookback window
   - ✅ Prunes older duplicates, keeps most recent
   - ✅ Works with both importance scoring and FIFO modes
   - ✅ 17 comprehensive tests added
   - ✅ Enabled by default
   - **Impact:** Aggressive removal of redundant outputs (same file read 5x = keep 1)

**Expected Impact:**
- 20-30% better token efficiency
- Preserve critical errors/warnings
- Remove redundant outputs

### Phase 2: Smart Strategies (2 weeks)
**Goal:** Semantic intelligence

4. ✅ **Differential summarization** (2 days)
   - Only summarize new content
   - Use cheaper model

5. ✅ **Predictive overflow** (2 days)
   - Track conversation velocity
   - Trigger early summarization

6. ✅ **Content-aware truncation** (3-4 days)
   - Detect JSON/logs/code/stacktraces
   - Structure-preserving truncation

**Expected Impact:**
- 60-80% summarization cost reduction
- Better information preservation
- Smoother overflow handling

### Phase 3: Advanced Features (3 weeks)
**Goal:** Sophisticated context management

7. ✅ **Hierarchical summaries** (3 days)
   - Multi-level summaries
   - Adaptive loading

8. ✅ **Information decay** (3 days)
   - Half-life modeling
   - Value-based pruning

9. ✅ **Agent-specific strategies** (5 days)
   - Custom prompts per agent type
   - Domain-specific preservation rules

10. ✅ **Semantic reference tracking** (5 days)
    - Track which outputs are referenced later
    - Boost score for referenced content

**Expected Impact:**
- Near-optimal token allocation
- Minimal information loss
- Domain-aware preservation

---

## Evaluation Metrics

### Before/After Comparison

**Context Quality:**
- Information retention after pruning (eval on known facts)
- Summary fidelity (can reconstruct key decisions?)
- Error preservation rate

**Efficiency:**
- Tokens pruned per cycle
- Summarization cost ($)
- Time to overflow (turns)

**User Experience:**
- Conversation length before failure
- Context relevance score
- Agent coherence over time

### Benchmark Suite
```python
# tests/evals/test_context_rot.py

def test_information_retention():
    """After pruning, can agent recall key facts?"""

def test_error_preservation():
    """Errors should survive aggressive pruning."""

def test_duplicate_removal():
    """Identical outputs should be deduplicated."""

def test_token_efficiency():
    """Token usage should match configured limits."""

def test_summarization_cost():
    """Differential should be 60%+ cheaper than full."""
```

---

## Configuration Examples

### Aggressive Pruning (Low Memory)
```python
config = HarnessConfig()
config.pruning.prune_protect = 20_000  # Tighter window
config.pruning.prune_minimum = 10_000  # More frequent pruning
config.compaction.auto = True
```

### Conservative (High Fidelity)
```python
config = HarnessConfig()
config.pruning.prune_protect = 80_000  # Larger window
config.pruning.prune_minimum = 40_000  # Less frequent
config.truncation.max_lines = 5000  # Larger outputs
```

### Debugging Mode (Never Lose Errors)
```python
config = HarnessConfig()
config.pruning.protected_tools.extend(["bash", "read", "grep"])
config.importance.boost_errors = True
config.importance.error_score = 1000  # Never prune
```

---

## Next Steps

1. **Review & Prioritize** - Which improvements matter most for your use case?
2. **Implement Phase 1** - Quick wins (1 week)
3. **Build Evals** - Measure before/after
4. **Iterate** - Monitor metrics, adjust thresholds

---

## Questions for Discussion

1. **Priority:** Which phase resonates most with your pain points?
2. **Trade-offs:** Prefer speed (heuristics) or accuracy (exact counting)?
3. **Domain:** Any agent-specific strategies needed?
4. **Budget:** Cost vs quality - optimize for which?

---

**Last Updated:** 2026-02-12
**Status:** Ready for implementation
