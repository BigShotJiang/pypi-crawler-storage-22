"""LLM-as-judge utilities for evaluating conversation quality."""

from typing import Any

from harnessutils.types import LLMClient


def judge_answer_correctness(
    llm: LLMClient,
    original_conversation: str,
    question: str,
    answer: str,
) -> dict[str, Any]:
    """Judge if an answer is correct given the original conversation.

    Args:
        llm: LLM client for judging
        original_conversation: Full conversation text
        question: Question that was asked
        answer: Answer to evaluate

    Returns:
        Dict with score (0-10) and reasoning
    """
    prompt = f"""You are evaluating whether an answer is correct based on a conversation.

Original Conversation:
{original_conversation}

Question: {question}
Answer: {answer}

Based ONLY on information in the original conversation, rate the answer's correctness from 0-10:
- 10: Completely correct and accurate
- 7-9: Mostly correct, minor details wrong
- 4-6: Partially correct
- 1-3: Mostly incorrect
- 0: Completely wrong or unrelated

Respond in this exact format:
SCORE: <number>
REASONING: <brief explanation>"""

    result = llm.invoke(
        messages=[{"role": "user", "content": prompt}],
    )

    response = result["content"]

    # Parse score
    score = 0
    reasoning = ""
    for line in response.split("\n"):
        if line.startswith("SCORE:"):
            try:
                score = int(line.split(":")[1].strip())
            except (ValueError, IndexError):
                score = 0
        elif line.startswith("REASONING:"):
            reasoning = line.split(":", 1)[1].strip()

    return {
        "score": score,
        "reasoning": reasoning,
        "raw_response": response,
    }


def judge_summary_quality(
    llm: LLMClient,
    original_conversation: str,
    summary: str,
) -> dict[str, Any]:
    """Judge if a summary adequately captures the conversation.

    Args:
        llm: LLM client for judging
        original_conversation: Full conversation text
        summary: Summary to evaluate

    Returns:
        Dict with score (0-10) and reasoning
    """
    prompt = f"""You are evaluating the quality of a conversation summary.

Original Conversation:
{original_conversation}

Summary:
{summary}

Rate the summary quality from 0-10 based on:
- Coverage: Does it capture key points?
- Accuracy: Is the information correct?
- Conciseness: Is it appropriately condensed?

Respond in this exact format:
SCORE: <number>
REASONING: <brief explanation>"""

    result = llm.invoke(
        messages=[{"role": "user", "content": prompt}],
    )

    response = result["content"]

    # Parse score
    score = 0
    reasoning = ""
    for line in response.split("\n"):
        if line.startswith("SCORE:"):
            try:
                score = int(line.split(":")[1].strip())
            except (ValueError, IndexError):
                score = 0
        elif line.startswith("REASONING:"):
            reasoning = line.split(":", 1)[1].strip()

    return {
        "score": score,
        "reasoning": reasoning,
        "raw_response": response,
    }
