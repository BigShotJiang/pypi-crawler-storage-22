"""Evals for conversation quality after compaction."""

import json
from pathlib import Path
from typing import Any

from harnessutils import (
    ConversationManager,
    HarnessConfig,
    MemoryStorage,
    Message,
    TextPart,
    ToolPart,
    ToolState,
    generate_id,
)
from harnessutils.types import LLMClient


def load_golden_conversations() -> list[dict[str, Any]]:
    """Load golden conversation dataset."""
    dataset_path = Path(__file__).parent / "datasets" / "golden_conversations.json"
    with open(dataset_path) as f:
        return json.load(f)


def conversation_to_text(messages: list[dict[str, Any]]) -> str:
    """Convert conversation to readable text format."""
    lines = []
    for msg in messages:
        role = msg["role"]
        text = msg.get("text", "")
        lines.append(f"{role.upper()}: {text}")

        if "tool_calls" in msg:
            for tool_call in msg["tool_calls"]:
                tool = tool_call["tool"]
                output = tool_call.get("output", "")
                lines.append(f"[Tool: {tool}]\n{output}")

    return "\n\n".join(lines)


def build_conversation_from_dataset(manager: ConversationManager, conv_data: dict[str, Any]) -> str:
    """Build a conversation from dataset format.

    Args:
        manager: ConversationManager instance
        conv_data: Conversation data from dataset

    Returns:
        Conversation ID
    """
    conv = manager.create_conversation()

    for msg_data in conv_data["messages"]:
        msg = Message(id=generate_id("msg"), role=msg_data["role"])

        if "text" in msg_data:
            msg.add_part(TextPart(text=msg_data["text"]))

        if "tool_calls" in msg_data:
            for tool_call in msg_data["tool_calls"]:
                tool_part = ToolPart(
                    tool=tool_call["tool"],
                    call_id=generate_id("call"),
                    state=ToolState(
                        status="completed",
                        input=tool_call.get("input", {}),
                        output=tool_call.get("output", ""),
                    ),
                )
                msg.add_part(tool_part)

        manager.add_message(conv.id, msg)

    return conv.id


def eval_information_preservation(llm: LLMClient | None = None) -> dict[str, Any]:
    """Eval: Information preservation after compaction.

    Tests if key information is retained after aggressive compaction.

    Returns:
        Eval results with metrics
    """
    if llm is None:
        return {
            "name": "information_preservation",
            "skipped": True,
            "reason": "No LLM client provided",
        }

    from evals.judge import judge_answer_correctness

    golden = load_golden_conversations()
    results = []

    for conv_data in golden:
        config = HarnessConfig()
        config.pruning.prune_protect = 0  # Aggressive pruning
        config.pruning.prune_minimum = 0
        config.pruning.protect_turns = 1  # Only protect last turn

        storage = MemoryStorage()
        manager = ConversationManager(storage, config)

        # Build conversation
        conv_id = build_conversation_from_dataset(manager, conv_data)

        # Compact it
        manager.prune_before_turn(conv_id)
        if llm:
            manager.compact(conv_id, llm, generate_id("msg"))

        # Get compacted messages
        messages = manager.get_messages(conv_id)
        compacted_text = "\n".join(
            f"{m.role}: {m.parts[0].text if m.parts else ''}" for m in messages
        )

        # Test questions
        original_text = conversation_to_text(conv_data["messages"])
        scores = []

        for question in conv_data.get("test_questions", []):
            # Ask question about compacted conversation
            answer_msg = {"role": "user", "content": f"{compacted_text}\n\nQ: {question}"}
            answer_result = llm.invoke([answer_msg])
            answer = answer_result["content"]

            # Judge correctness
            judgment = judge_answer_correctness(llm, original_text, question, answer)
            scores.append(judgment["score"])

        avg_score = sum(scores) / len(scores) if scores else 0

        results.append(
            {
                "conversation_id": conv_data["id"],
                "avg_score": avg_score,
                "scores": scores,
                "num_questions": len(scores),
            }
        )

    overall_avg = sum(r["avg_score"] for r in results) / len(results) if results else 0

    return {
        "name": "information_preservation",
        "overall_score": overall_avg,
        "results": results,
        "num_conversations": len(results),
        "passed": overall_avg >= 7.0,  # Threshold: 7/10
    }


def eval_compaction_ratio() -> dict[str, Any]:
    """Eval: Measure compaction effectiveness.

    Tests how much context is reduced while preserving quality.

    Returns:
        Eval results with metrics
    """
    golden = load_golden_conversations()
    results = []

    for conv_data in golden:
        config = HarnessConfig()
        storage = MemoryStorage()
        manager = ConversationManager(storage, config)

        # Build conversation
        conv_id = build_conversation_from_dataset(manager, conv_data)

        # Measure before compaction
        messages_before = manager.get_messages(conv_id)
        from harnessutils.tokens.estimator import estimate_tokens

        tokens_before = sum(
            estimate_tokens(p.text if hasattr(p, "text") else str(p))
            for m in messages_before
            for p in m.parts
        )

        # Compact
        prune_result = manager.prune_before_turn(conv_id)

        # Measure after
        messages_after = manager.get_messages(conv_id)
        tokens_after = sum(
            estimate_tokens(str(getattr(p, "text", ""))) for m in messages_after for p in m.parts
        )

        ratio = tokens_after / tokens_before if tokens_before > 0 else 1.0

        results.append(
            {
                "conversation_id": conv_data["id"],
                "tokens_before": tokens_before,
                "tokens_after": tokens_after,
                "tokens_saved": prune_result["tokens_saved"],
                "compaction_ratio": ratio,
            }
        )

    avg_ratio = sum(r["compaction_ratio"] for r in results) / len(results) if results else 1.0

    return {
        "name": "compaction_ratio",
        "avg_compaction_ratio": avg_ratio,
        "results": results,
        "num_conversations": len(results),
        "passed": avg_ratio < 0.8,  # Target: <80% of original
    }
