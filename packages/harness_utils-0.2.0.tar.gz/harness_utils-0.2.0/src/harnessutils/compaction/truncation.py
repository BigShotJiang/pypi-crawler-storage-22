"""Tier 1: Output truncation at tool execution boundary.

Prevents large outputs from entering context by truncating at source.
Cost: Free, Latency: 0ms.
"""

import json
import re
from dataclasses import dataclass
from typing import Literal

from harnessutils.config import TruncationConfig

ContentType = Literal["json", "logs", "stacktrace", "code", "text"]


@dataclass
class TruncationResult:
    """Result of truncation operation."""

    content: str
    truncated: bool
    output_path: str | None = None
    bytes_removed: int = 0
    content_type: ContentType = "text"


def detect_content_type(output: str) -> ContentType:
    """Detect the content type of output.

    Args:
        output: The output to analyze

    Returns:
        Detected content type
    """
    stripped = output.strip()

    if not stripped:
        return "text"

    # JSON: starts with { or [, valid JSON parse
    if stripped[0] in ("{", "["):
        try:
            json.loads(stripped)
            return "json"
        except (json.JSONDecodeError, ValueError):
            pass

    # Stacktrace: Python/Java/JS error patterns
    stacktrace_patterns = [
        r"Traceback \(most recent call last\)",
        r"^\s*at\s+.*\(.*:\d+:\d+\)",  # JS stacktrace
        r'^\s*File ".*", line \d+',     # Python stacktrace
        r"Exception in thread",         # Java stacktrace
    ]

    for pattern in stacktrace_patterns:
        if re.search(pattern, output, re.MULTILINE):
            return "stacktrace"

    # Logs: timestamps, log levels
    log_patterns = [
        r"\d{4}-\d{2}-\d{2}[T\s]\d{2}:\d{2}:\d{2}",  # ISO timestamp
        r"\[(?:ERROR|WARN|INFO|DEBUG)\]",             # Log levels
        r"(?:ERROR|WARN|INFO|DEBUG):",                # Alternative format
    ]

    for pattern in log_patterns:
        if re.search(pattern, output):
            return "logs"

    # Code: Python/JS/Java keywords
    code_patterns = [
        r"^\s*(?:def|class|import|from)\s+",    # Python
        r"^\s*(?:function|const|let|var)\s+",   # JavaScript
        r"^\s*(?:public|private|protected)\s+", # Java/C++
    ]

    for pattern in code_patterns:
        if re.search(pattern, output, re.MULTILINE):
            return "code"

    return "text"


def _truncate_json(output: str, max_tokens: int) -> tuple[str, int]:
    """Truncate JSON while preserving structure.

    Args:
        output: JSON string to truncate
        max_tokens: Maximum tokens to keep

    Returns:
        Tuple of (truncated_json, tokens_removed)
    """
    from harnessutils.tokens.exact import count_tokens_fast

    try:
        data = json.loads(output)

        # If it's already under limit, return as-is
        current_tokens = count_tokens_fast(output)
        if current_tokens <= max_tokens:
            return output, 0

        # For arrays, keep first and last N items
        if isinstance(data, list):
            total_items = len(data)
            if total_items > 10:
                # Keep first 5 and last 5
                truncated = data[:5] + data[-5:]
                result = json.dumps(truncated, indent=2)
                result += f"\n\n... {total_items - 10} items truncated ..."
                tokens_removed = current_tokens - count_tokens_fast(result)
                return result, tokens_removed

        # For objects, truncate large string values
        if isinstance(data, dict):
            truncated = {}
            for key, value in data.items():
                if isinstance(value, str) and len(value) > 500:
                    truncated[key] = value[:500] + "... (truncated)"
                elif isinstance(value, list) and len(value) > 10:
                    truncated[key] = value[:5] + ["... (truncated)"] + value[-5:]
                else:
                    truncated[key] = value

            result = json.dumps(truncated, indent=2)
            tokens_removed = current_tokens - count_tokens_fast(result)
            return result, tokens_removed

        return output, 0

    except (json.JSONDecodeError, ValueError):
        # If JSON parsing fails, fallback to text truncation
        return _truncate_text(output, max_tokens)


def _truncate_stacktrace(output: str, max_tokens: int, config: TruncationConfig) -> tuple[str, int]:
    """Truncate stacktrace while preserving error message and key frames.

    Args:
        output: Stacktrace to truncate
        max_tokens: Maximum tokens to keep
        config: Truncation configuration

    Returns:
        Tuple of (truncated_stacktrace, tokens_removed)
    """
    from harnessutils.tokens.exact import count_tokens_fast

    current_tokens = count_tokens_fast(output)
    if current_tokens <= max_tokens:
        return output, 0

    lines = output.split("\n")
    frame_limit = config.stacktrace_frame_limit // 2  # Split between top and bottom

    # Find error message (usually at the end for Python, beginning for JS)
    error_line = None
    for i in range(len(lines) - 1, max(0, len(lines) - 5), -1):
        if lines[i].strip() and not lines[i].startswith(" "):
            error_line = i
            break

    # Keep error message
    result_lines = []
    if error_line is not None:
        result_lines.append(lines[error_line])
        result_lines.append("")

    # Keep top N frames
    result_lines.extend(lines[:frame_limit])
    result_lines.append("")
    result_lines.append(f"... {len(lines) - 2 * frame_limit} frames truncated ...")
    result_lines.append("")

    # Keep bottom N frames (excluding error message)
    if error_line is not None:
        result_lines.extend(lines[max(frame_limit, error_line - frame_limit):error_line])
    else:
        result_lines.extend(lines[-frame_limit:])

    result = "\n".join(result_lines)
    tokens_removed = current_tokens - count_tokens_fast(result)
    return result, tokens_removed


def _truncate_logs(output: str, max_tokens: int, config: TruncationConfig) -> tuple[str, int]:
    """Truncate logs while preserving all errors and warnings.

    Args:
        output: Logs to truncate
        max_tokens: Maximum tokens to keep
        config: Truncation configuration

    Returns:
        Tuple of (truncated_logs, tokens_removed)
    """
    from harnessutils.tokens.exact import count_tokens_fast

    current_tokens = count_tokens_fast(output)
    if current_tokens <= max_tokens:
        return output, 0

    lines = output.split("\n")

    if not config.preserve_errors:
        # Just do head/tail truncation
        return _truncate_text(output, max_tokens)

    # Categorize lines
    error_lines = []
    warning_lines = []
    info_lines = []

    error_pattern = re.compile(r"\[?ERROR\]?|ERROR:", re.IGNORECASE)
    warning_pattern = re.compile(r"\[?WARN(?:ING)?\]?|WARN(?:ING)?:", re.IGNORECASE)

    for i, line in enumerate(lines):
        if error_pattern.search(line):
            error_lines.append((i, line))
        elif warning_pattern.search(line):
            warning_lines.append((i, line))
        else:
            info_lines.append((i, line))

    # Always keep all errors and warnings
    result_lines = []

    if error_lines:
        result_lines.append("=== ERRORS ===")
        result_lines.extend([line for _, line in error_lines])
        result_lines.append("")

    if warning_lines:
        result_lines.append("=== WARNINGS ===")
        result_lines.extend([line for _, line in warning_lines])
        result_lines.append("")

    # Sample info lines (first and last 50)
    if info_lines:
        result_lines.append("=== INFO (sampled) ===")
        if len(info_lines) > 100:
            result_lines.extend([line for _, line in info_lines[:50]])
            result_lines.append(f"... {len(info_lines) - 100} info lines truncated ...")
            result_lines.extend([line for _, line in info_lines[-50:]])
        else:
            result_lines.extend([line for _, line in info_lines])

    result = "\n".join(result_lines)
    tokens_removed = current_tokens - count_tokens_fast(result)
    return result, tokens_removed


def _truncate_code(output: str, max_tokens: int) -> tuple[str, int]:
    """Truncate code while preserving function signatures.

    Args:
        output: Code to truncate
        max_tokens: Maximum tokens to keep

    Returns:
        Tuple of (truncated_code, tokens_removed)
    """
    from harnessutils.tokens.exact import count_tokens_fast

    current_tokens = count_tokens_fast(output)
    if current_tokens <= max_tokens:
        return output, 0

    lines = output.split("\n")
    result_lines = []

    # Patterns for function/class signatures
    signature_patterns = [
        re.compile(r"^\s*(?:def|class)\s+\w+"),       # Python
        re.compile(r"^\s*(?:function|const|let)\s+"),  # JavaScript
        re.compile(r"^\s*(?:public|private|protected)\s+.*\("), # Java/C++
    ]

    for line in lines:
        is_signature = any(pattern.search(line) for pattern in signature_patterns)

        if is_signature:
            result_lines.append(line)
            # Check if tokens exceeded
            if count_tokens_fast("\n".join(result_lines)) > max_tokens:
                result_lines.pop()
                result_lines.append("... (code truncated)")
                break
        elif len(result_lines) < 20:  # Keep first 20 lines regardless
            result_lines.append(line)

    result = "\n".join(result_lines)
    tokens_removed = current_tokens - count_tokens_fast(result)
    return result, tokens_removed


def _truncate_text(output: str, max_tokens: int) -> tuple[str, int]:
    """Truncate text at token boundaries (head + tail).

    Args:
        output: Text to truncate
        max_tokens: Maximum tokens to keep

    Returns:
        Tuple of (truncated_text, tokens_removed)
    """
    from harnessutils.tokens.exact import count_tokens_fast

    current_tokens = count_tokens_fast(output)
    if current_tokens <= max_tokens:
        return output, 0

    # Split tokens 70/30 between head and tail
    head_tokens = int(max_tokens * 0.7)
    tail_tokens = max_tokens - head_tokens

    # Approximate character counts (4 chars per token)
    head_chars = head_tokens * 4
    tail_chars = tail_tokens * 4

    head = output[:head_chars]
    tail = output[-tail_chars:]

    result = f"{head}\n\n... (truncated) ...\n\n{tail}"
    tokens_removed = current_tokens - count_tokens_fast(result)
    return result, tokens_removed


def truncate_output(
    output: str,
    config: TruncationConfig,
    output_id: str | None = None,
    content_type: ContentType | None = None,
) -> TruncationResult:
    """Truncate tool output if it exceeds limits.

    Args:
        output: The tool output to potentially truncate
        config: Truncation configuration
        output_id: ID for saving full output (if None, full output not saved)
        content_type: Override detected content type

    Returns:
        TruncationResult with content and metadata
    """
    from harnessutils.tokens.exact import count_tokens_fast

    # Detect content type if not provided
    detected_type = content_type or detect_content_type(output)

    # Use content-aware truncation if enabled AND max_tokens would trigger
    # (backward compatibility: if only max_lines/max_bytes set, use legacy mode)
    current_tokens = count_tokens_fast(output)
    if config.use_content_aware and current_tokens > config.max_tokens:

        # Route to specialized truncator
        try:
            if detected_type == "json":
                truncated, tokens_removed = _truncate_json(output, config.max_tokens)
            elif detected_type == "stacktrace":
                truncated, tokens_removed = _truncate_stacktrace(output, config.max_tokens, config)
            elif detected_type == "logs":
                truncated, tokens_removed = _truncate_logs(output, config.max_tokens, config)
            elif detected_type == "code":
                truncated, tokens_removed = _truncate_code(output, config.max_tokens)
            else:  # text
                truncated, tokens_removed = _truncate_text(output, config.max_tokens)

            return TruncationResult(
                content=truncated,
                truncated=True,
                output_path=output_id,
                bytes_removed=tokens_removed * 4,  # Approximate
                content_type=detected_type,
            )
        except Exception:
            # Fallback to text truncation on any error
            truncated, tokens_removed = _truncate_text(output, config.max_tokens)
            return TruncationResult(
                content=truncated,
                truncated=True,
                output_path=output_id,
                bytes_removed=tokens_removed * 4,
                content_type="text",
            )

    # Legacy line/byte-based truncation (backward compatibility)
    lines = output.split("\n")
    total_bytes = len(output.encode("utf-8"))

    if len(lines) <= config.max_lines and total_bytes <= config.max_bytes:
        return TruncationResult(
            content=output,
            truncated=False,
            content_type=detected_type,
        )

    preview_lines: list[str] = []
    bytes_accumulated = 0

    if config.direction == "head":
        for i, line in enumerate(lines):
            if i >= config.max_lines:
                break
            line_bytes = len(line.encode("utf-8")) + 1  # +1 for newline
            if bytes_accumulated + line_bytes > config.max_bytes:
                break
            preview_lines.append(line)
            bytes_accumulated += line_bytes
    else:  # tail
        for i in range(len(lines) - 1, -1, -1):
            if len(preview_lines) >= config.max_lines:
                break
            line = lines[i]
            line_bytes = len(line.encode("utf-8")) + 1  # +1 for newline
            if bytes_accumulated + line_bytes > config.max_bytes:
                break
            preview_lines.insert(0, line)
            bytes_accumulated += line_bytes

    preview = "\n".join(preview_lines)
    bytes_removed = total_bytes - bytes_accumulated

    direction: Literal["head", "tail"] = "head" if config.direction == "head" else "tail"
    message = _format_truncated_message(
        preview,
        bytes_removed,
        output_id,
        direction,
    )

    return TruncationResult(
        content=message,
        truncated=True,
        output_path=output_id,
        bytes_removed=bytes_removed,
        content_type=detected_type,
    )


def _format_truncated_message(
    preview: str,
    bytes_removed: int,
    output_path: str | None,
    direction: Literal["head", "tail"],
) -> str:
    """Format the truncated output message.

    Args:
        preview: Preview content (head or tail)
        bytes_removed: Number of bytes that were removed
        output_path: Path where full output was saved
        direction: Direction of truncation

    Returns:
        Formatted message string
    """
    parts = [preview]

    if bytes_removed > 0:
        parts.append("")
        parts.append(f"...{bytes_removed} bytes truncated...")
        parts.append("")

        if output_path:
            parts.append(f"Full output saved to: {output_path}")
            parts.append("Use search tools to query the full content or read specific sections.")
            parts.append("Delegate large file processing to specialized exploration agents.")

    return "\n".join(parts)
