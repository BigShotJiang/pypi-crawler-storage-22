"""Configuration schema for harness-utils."""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class TruncationConfig:
    """Configuration for Tier 1: Output truncation."""

    max_lines: int = 2000
    max_bytes: int = 50 * 1024  # 50KB
    direction: str = "head"  # "head" or "tail"

    # Phase 2: Content-aware truncation
    max_tokens: int = 2000  # Token-based limit
    use_content_aware: bool = True  # Enable content-aware truncation
    preserve_errors: bool = True  # Keep all errors/warnings in logs
    json_array_limit: int = 10  # Keep first/last N items in JSON arrays
    stacktrace_frame_limit: int = 20  # Keep top/bottom N frames in stacktraces


@dataclass
class PruningConfig:
    """Configuration for Tier 2: Selective pruning."""

    prune_protect: int = 40_000  # Keep recent 40K tokens
    prune_minimum: int = 20_000  # Only prune if saves 20K+ tokens
    protect_turns: int = 2  # Protect last 2 turns
    protected_tools: list[str] = field(
        default_factory=lambda: ["skill_execution", "subtask_invocation"]
    )

    # Importance scoring (Phase 1.2)
    use_importance_scoring: bool = True  # Enable smart pruning
    recency_weight: float = 1.0  # Weight for recency score
    size_weight: float = -0.5  # Weight for size penalty (negative)
    semantic_weight: float = 2.0  # Weight for semantic importance
    tool_priority_weight: float = 1.5  # Weight for tool type priority
    recency_decay: float = 0.1  # Exponential decay rate per turn

    # Tool importance map (higher = more important)
    tool_importance: dict[str, float] = field(
        default_factory=lambda: {
            "read": 50.0,
            "write": 100.0,  # Code changes are important
            "edit": 100.0,
            "grep": 30.0,  # Search results often repetitive
            "glob": 30.0,
            "bash": 70.0,
            "skill_execution": 150.0,  # Complex operations
            "subtask_invocation": 150.0,
            "error": 200.0,  # Critical for debugging
        }
    )

    # Semantic boost scores
    error_boost: float = 500.0  # Boost for outputs with errors
    warning_boost: float = 200.0  # Boost for warnings
    user_requested_boost: float = 300.0  # User explicitly asked for this

    # Deduplication (Phase 1.3)
    detect_duplicates: bool = True  # Enable duplicate detection
    similarity_threshold: float = 0.8  # Similarity threshold (0.0-1.0)
    duplicate_lookback: int = 20  # Check last N outputs for duplicates


@dataclass
class TokenConfig:
    """Configuration for token estimation."""

    chars_per_token: int = 4


@dataclass
class ModelLimitsConfig:
    """Configuration for model limits."""

    default_context_limit: int = 200_000
    default_output_limit: int = 8_192


@dataclass
class StorageConfig:
    """Configuration for storage layer."""

    base_path: Path = field(default_factory=lambda: Path("data"))
    retention_days: int = 7  # For truncated outputs


@dataclass
class SummarizationConfig:
    """Configuration for Tier 3: Summarization."""

    mode: str = "differential"  # "differential" or "full"
    differential_model: str = "claude-3-5-haiku-20241022"  # Cheaper model for diffs
    full_model: str = "claude-3-5-sonnet-20241022"  # More capable model for full
    max_messages_since_summary: int = 30  # Force full if exceeded


@dataclass
class CompactionConfig:
    """Configuration for context compaction."""

    auto: bool = True  # Enable auto-summarization
    prune: bool = True  # Enable pruning

    # Phase 2: Predictive overflow detection
    use_predictive: bool = True  # Enable predictive overflow detection
    predictive_lookahead: int = 5  # Predict N turns ahead
    predictive_safety_margin: float = 0.8  # Trigger at 80% of limit


@dataclass
class HarnessConfig:
    """Main configuration for harness-utils.

    Provides all configuration parameters for context window management
    with sensible defaults from the CTXWINARCH.md specification.
    """

    truncation: TruncationConfig = field(default_factory=TruncationConfig)
    pruning: PruningConfig = field(default_factory=PruningConfig)
    tokens: TokenConfig = field(default_factory=TokenConfig)
    model_limits: ModelLimitsConfig = field(default_factory=ModelLimitsConfig)
    storage: StorageConfig = field(default_factory=StorageConfig)
    compaction: CompactionConfig = field(default_factory=CompactionConfig)
    summarization: SummarizationConfig = field(default_factory=SummarizationConfig)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "HarnessConfig":
        """Create configuration from dictionary.

        Args:
            data: Configuration dictionary

        Returns:
            HarnessConfig instance
        """
        config = cls()

        if "truncation" in data:
            config.truncation = TruncationConfig(**data["truncation"])
        if "pruning" in data:
            protected = data["pruning"].get("protected_tools")
            pruning_data = {k: v for k, v in data["pruning"].items() if k != "protected_tools"}
            if protected:
                pruning_data["protected_tools"] = protected
            config.pruning = PruningConfig(**pruning_data)
        if "tokens" in data:
            config.tokens = TokenConfig(**data["tokens"])
        if "model_limits" in data:
            config.model_limits = ModelLimitsConfig(**data["model_limits"])
        if "storage" in data:
            storage_data = data["storage"].copy()
            if "base_path" in storage_data:
                storage_data["base_path"] = Path(storage_data["base_path"])
            config.storage = StorageConfig(**storage_data)
        if "compaction" in data:
            config.compaction = CompactionConfig(**data["compaction"])
        if "summarization" in data:
            config.summarization = SummarizationConfig(**data["summarization"])

        return config

    @classmethod
    def from_toml(cls, path: Path) -> "HarnessConfig":
        """Load configuration from TOML file.

        Args:
            path: Path to TOML configuration file

        Returns:
            HarnessConfig instance
        """
        import tomllib

        with open(path, "rb") as f:
            data = tomllib.load(f)

        return cls.from_dict(data)

    @classmethod
    def from_json(cls, path: Path) -> "HarnessConfig":
        """Load configuration from JSON file.

        Args:
            path: Path to JSON configuration file

        Returns:
            HarnessConfig instance
        """
        import json

        with open(path) as f:
            data = json.load(f)

        return cls.from_dict(data)
