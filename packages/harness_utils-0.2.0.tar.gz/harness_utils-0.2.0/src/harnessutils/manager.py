"""Main ConversationManager API for harness-utils."""

import time
from typing import Any

from harnessutils.compaction.pruning import prune_tool_outputs
from harnessutils.compaction.summarization import is_overflow, summarize_conversation
from harnessutils.compaction.truncation import truncate_output
from harnessutils.config import HarnessConfig
from harnessutils.conversion.to_model import to_model_messages
from harnessutils.models.conversation import Conversation
from harnessutils.models.message import Message
from harnessutils.models.usage import Usage
from harnessutils.storage.memory import MemoryStorage
from harnessutils.types import LLMClient, StorageBackend
from harnessutils.utils.ids import generate_id


class ConversationManager:
    """Main interface for managing conversations with context window management.

    Provides high-level API for:
    - Creating and managing conversations
    - Adding messages
    - Automatic context compaction (truncation, pruning, summarization)
    - Message storage and retrieval
    """

    def __init__(
        self,
        storage: StorageBackend | None = None,
        config: HarnessConfig | None = None,
    ):
        """Initialize conversation manager.

        Args:
            storage: Storage backend (uses in-memory if None)
            config: Configuration (uses defaults if None)
        """
        self.config = config or HarnessConfig()
        self.storage = storage or MemoryStorage()
        self._message_cache: dict[str, list[Message]] = {}

    def create_conversation(
        self,
        conversation_id: str | None = None,
        project_id: str | None = None,
    ) -> Conversation:
        """Create a new conversation.

        Args:
            conversation_id: Optional conversation ID (generated if None)
            project_id: Optional project ID for grouping

        Returns:
            New conversation object
        """
        if conversation_id is None:
            conversation_id = generate_id("conv")

        now = int(time.time() * 1000)
        conversation = Conversation(
            id=conversation_id,
            project_id=project_id,
            created=now,
            updated=now,
        )

        self.storage.save_conversation(conversation_id, conversation.to_dict())
        self._message_cache[conversation_id] = []

        return conversation

    def add_message(self, conversation_id: str, message: Message) -> None:
        """Add a message to a conversation.

        Args:
            conversation_id: Conversation to add message to
            message: Message to add
        """
        self.storage.save_message(conversation_id, message.id, message.to_dict())

        if conversation_id not in self._message_cache:
            self._message_cache[conversation_id] = []
        self._message_cache[conversation_id].append(message)

        # Load conversation and update
        conv_data = self.storage.load_conversation(conversation_id)
        conv = Conversation.from_dict(conv_data)
        conv.updated = int(time.time() * 1000)

        # Track velocity if message has token count
        if message.tokens:
            tokens_added = message.tokens.total
            conv.update_velocity(tokens_added)

        self.storage.save_conversation(conversation_id, conv.to_dict())

    def get_messages(self, conversation_id: str) -> list[Message]:
        """Get all messages for a conversation.

        Args:
            conversation_id: Conversation ID

        Returns:
            List of messages in chronological order
        """
        if conversation_id in self._message_cache:
            return self._message_cache[conversation_id]

        message_ids = self.storage.list_messages(conversation_id)
        messages = [
            Message.from_dict(self.storage.load_message(conversation_id, msg_id))
            for msg_id in message_ids
        ]

        self._message_cache[conversation_id] = messages
        return messages

    def prune_before_turn(
        self,
        conversation_id: str,
        auto_mode: bool = False,
    ) -> dict[str, Any]:
        """Proactively prune old tool outputs before processing a turn.

        This is Tier 2 compaction - removes old tool outputs while
        preserving conversation structure.

        Args:
            conversation_id: Conversation to prune
            auto_mode: Whether this was auto-triggered

        Returns:
            Detailed pruning result with token tracking and breakdown:
            - pruned: Total outputs removed
            - tokens_saved: Total tokens saved
            - tokens_before: Token count before pruning
            - tokens_after: Token count after pruning
            - duplicates_pruned: Outputs removed due to duplication
            - importance_pruned: Outputs removed due to low importance
            - duplicate_tokens_saved: Tokens saved from deduplication
            - importance_tokens_saved: Tokens saved from importance pruning
            - reduction_percent: Percentage reduction in token usage
        """
        if not self.config.compaction.prune and auto_mode:
            return {
                "pruned": 0,
                "tokens_saved": 0,
                "tokens_before": 0,
                "tokens_after": 0,
                "duplicates_pruned": 0,
                "importance_pruned": 0,
                "duplicate_tokens_saved": 0,
                "importance_tokens_saved": 0,
                "reduction_percent": 0,
            }

        messages = self.get_messages(conversation_id)
        result = prune_tool_outputs(
            messages,
            self.config.pruning,
        )

        for msg in messages:
            self.storage.save_message(conversation_id, msg.id, msg.to_dict())

        return result.to_dict()

    def predict_overflow(
        self,
        conversation_id: str,
        current_usage: Usage,
    ) -> bool:
        """Predict if conversation will overflow in next N turns.

        Args:
            conversation_id: Conversation to check
            current_usage: Current token usage

        Returns:
            True if overflow predicted within lookahead window
        """
        if not self.config.compaction.use_predictive:
            return False

        # Load conversation and get velocity
        conv_data = self.storage.load_conversation(conversation_id)
        conv = Conversation.from_dict(conv_data)
        velocity = conv.get_velocity()

        if velocity is None or not velocity.turn_deltas:
            return False  # No velocity data yet

        # Project tokens ahead
        lookahead = self.config.compaction.predictive_lookahead
        predicted_growth = velocity.predict_tokens_ahead(lookahead)

        # Calculate current total and projected total
        current_total = current_usage.input + current_usage.cache.read
        projected_total = current_total + predicted_growth

        # Check against safety margin
        usable_space = (
            self.config.model_limits.default_context_limit
            - self.config.model_limits.default_output_limit
        )
        safety_threshold = usable_space * self.config.compaction.predictive_safety_margin

        return projected_total > safety_threshold

    def needs_compaction(
        self,
        conversation_id: str,
        usage: Usage,
    ) -> bool:
        """Check if conversation needs summarization (Tier 3).

        Uses both reactive (overflow) and predictive checks.

        Args:
            conversation_id: Conversation to check
            usage: Token usage from last turn

        Returns:
            True if summarization needed
        """
        # Reactive check: already overflowed
        if is_overflow(
            usage,
            self.config.model_limits.default_context_limit,
            self.config.model_limits.default_output_limit,
        ):
            return True

        # Predictive check: will overflow soon
        return self.predict_overflow(conversation_id, usage)

    def compact(
        self,
        conversation_id: str,
        llm_client: LLMClient,
        parent_message_id: str,
        model: str | None = None,
        auto_mode: bool = False,
    ) -> dict[str, Any]:
        """Compact conversation using LLM summarization (Tier 3).

        Args:
            conversation_id: Conversation to compact
            llm_client: LLM client for summarization
            parent_message_id: Message that triggered compaction
            model: Optional model to use for summarization
            auto_mode: Whether this was auto-triggered

        Returns:
            Compaction result with summary message and metrics
        """
        if not self.config.compaction.auto and auto_mode:
            return {"summarized": False}

        messages = self.get_messages(conversation_id)
        summary_id = generate_id("msg")

        result = summarize_conversation(
            messages=messages,
            llm_client=llm_client,
            parent_message_id=parent_message_id,
            message_id=summary_id,
            model=model,
            auto_mode=auto_mode,
            config=self.config.summarization,
        )

        self.add_message(conversation_id, result.summary_message)

        return {
            "summarized": True,
            "summary_message_id": summary_id,
            "tokens_used": result.tokens_used.total,
            "cost": result.cost,
        }

    def to_model_format(self, conversation_id: str) -> list[dict[str, Any]]:
        """Convert conversation messages to model format for LLM requests.

        Args:
            conversation_id: Conversation to convert

        Returns:
            List of messages in model format
        """
        messages = self.get_messages(conversation_id)
        return to_model_messages(messages)

    def calculate_context_usage(
        self,
        conversation_id: str,
        model: str = "claude-3-5-sonnet-20241022",
    ) -> int:
        """Calculate exact token count for conversation using tiktoken.

        This counts ALL tokens in the conversation (user messages, assistant
        responses, tool outputs, etc.) that will be sent to the model.

        Args:
            conversation_id: Conversation to calculate usage for
            model: Model name for tokenizer selection

        Returns:
            Exact token count that will be used in context window
        """
        from harnessutils.tokens.exact import count_tokens_exact

        messages = self.to_model_format(conversation_id)
        return count_tokens_exact(messages, model)

    def get_tool_output_tokens(self, conversation_id: str) -> dict[str, Any]:
        """Get detailed breakdown of token usage for tool outputs.

        Args:
            conversation_id: Conversation to analyze

        Returns:
            Dictionary with token breakdown:
            - total: Total tokens in tool outputs
            - by_tool: Token count per tool type
            - prunable: Tokens that could be pruned
            - protected: Tokens in protected outputs
        """
        from harnessutils.compaction.pruning import calculate_context_tokens

        messages = self.get_messages(conversation_id)

        total = calculate_context_tokens(messages)
        by_tool: dict[str, int] = {}
        prunable = 0
        protected = 0
        turns_skipped = 0

        for msg in reversed(messages):
            if msg.role == "user":
                turns_skipped += 1

            for part in msg.parts:
                from harnessutils.models.parts import ToolPart
                from harnessutils.tokens.exact import count_tokens_fast

                if not isinstance(part, ToolPart):
                    continue

                if part.state.status != "completed":
                    continue

                if not part.state.output:
                    continue

                tokens = count_tokens_fast(part.state.output)

                # Track by tool type
                by_tool[part.tool] = by_tool.get(part.tool, 0) + tokens

                # Determine if prunable
                is_protected = (
                    turns_skipped < self.config.pruning.protect_turns
                    or part.tool in self.config.pruning.protected_tools
                    or (part.state.time and part.state.time.compacted)
                )

                if is_protected:
                    protected += tokens
                else:
                    prunable += tokens

        return {
            "total": total,
            "by_tool": by_tool,
            "prunable": prunable,
            "protected": protected,
            "prunability_percent": round((prunable / total * 100) if total > 0 else 0, 1),
        }

    def truncate_tool_output(
        self,
        output: str,
        tool_name: str,
    ) -> str:
        """Truncate tool output if it exceeds limits (Tier 1).

        Args:
            output: Tool output to truncate
            tool_name: Name of the tool

        Returns:
            Potentially truncated output
        """
        output_id = generate_id(f"output_{tool_name}")

        result = truncate_output(
            output=output,
            config=self.config.truncation,
            output_id=output_id,
        )

        if result.truncated and result.output_path:
            self.storage.save_truncated_output(result.output_path, output)

        return result.content
