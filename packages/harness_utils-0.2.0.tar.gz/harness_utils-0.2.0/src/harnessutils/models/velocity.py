"""Conversation velocity tracking for predictive overflow detection."""

from dataclasses import dataclass, field


@dataclass
class ConversationVelocity:
    """Track token growth velocity for predictive overflow detection.

    Tracks recent token deltas to predict future growth and trigger
    compaction before overflow occurs.
    """

    turn_deltas: list[int] = field(default_factory=list)
    window_size: int = 10  # Track last N turns

    @property
    def avg_growth(self) -> float:
        """Calculate average tokens per turn.

        Returns:
            Average token growth across tracked turns
        """
        if not self.turn_deltas:
            return 0.0

        return sum(self.turn_deltas) / len(self.turn_deltas)

    @property
    def growth_trend(self) -> float:
        """Calculate acceleration (recent vs older growth).

        Compares recent half vs older half to detect acceleration.

        Returns:
            Positive = accelerating, Negative = decelerating, 0 = steady
        """
        if len(self.turn_deltas) < 4:
            return 0.0  # Need at least 4 turns for trend

        mid = len(self.turn_deltas) // 2
        recent_avg = sum(self.turn_deltas[mid:]) / len(self.turn_deltas[mid:])
        older_avg = sum(self.turn_deltas[:mid]) / len(self.turn_deltas[:mid])

        return recent_avg - older_avg

    def predict_tokens_ahead(self, turns: int) -> int:
        """Predict token count N turns ahead.

        Uses linear projection with acceleration boost.

        Args:
            turns: Number of turns to project ahead

        Returns:
            Predicted token count increase
        """
        if not self.turn_deltas:
            return 0

        base_prediction = self.avg_growth * turns

        # Add acceleration boost if accelerating
        if self.growth_trend > 0:
            acceleration_boost = self.growth_trend * turns * 0.5
            base_prediction += acceleration_boost

        return int(base_prediction)

    def add_delta(self, tokens: int) -> None:
        """Add a new token delta.

        Args:
            tokens: Token count for this turn
        """
        self.turn_deltas.append(tokens)

        # Keep only last window_size deltas
        if len(self.turn_deltas) > self.window_size:
            self.turn_deltas.pop(0)

    def to_dict(self) -> dict:
        """Convert to dictionary for storage.

        Returns:
            Dictionary representation
        """
        return {
            "turn_deltas": self.turn_deltas,
            "window_size": self.window_size,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "ConversationVelocity":
        """Create from dictionary.

        Args:
            data: Dictionary representation

        Returns:
            ConversationVelocity instance
        """
        return cls(
            turn_deltas=data.get("turn_deltas", []),
            window_size=data.get("window_size", 10),
        )
