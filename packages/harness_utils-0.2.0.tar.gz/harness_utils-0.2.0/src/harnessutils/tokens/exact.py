"""Exact token counting using tiktoken."""

import json
from typing import Any

import tiktoken

# Global encoding cache for performance
_encoding_cache: tiktoken.Encoding | None = None


def count_tokens_exact(
    messages: list[dict[str, Any]], model: str = "claude-3-5-sonnet-20241022"
) -> int:
    """Count exact tokens for messages using tiktoken.

    Args:
        messages: Messages in model format
        model: Model name for tokenizer selection

    Returns:
        Exact token count
    """

    # Map model names to tiktoken encodings
    # Claude models use cl100k_base encoding (same as GPT-4)
    encoding_name = "cl100k_base"

    # For other models, use appropriate encoding
    if "gpt-4" in model.lower():
        encoding_name = "cl100k_base"
    elif "gpt-3.5" in model.lower():
        encoding_name = "cl100k_base"
    elif "claude" in model.lower():
        encoding_name = "cl100k_base"
    else:
        # Default to cl100k_base for unknown models
        encoding_name = "cl100k_base"

    encoding = tiktoken.get_encoding(encoding_name)

    total_tokens = 0

    for message in messages:
        # Count role
        total_tokens += len(encoding.encode(message.get("role", "")))

        # Count content
        content = message.get("content", "")
        if isinstance(content, str):
            total_tokens += len(encoding.encode(content))
        elif isinstance(content, list):
            # Handle structured content (parts)
            for part in content:
                if isinstance(part, dict):
                    if "text" in part:
                        total_tokens += len(encoding.encode(part["text"]))
                    if "type" in part:
                        total_tokens += len(encoding.encode(part["type"]))
                    # Tool use/result structures
                    if "tool_use_id" in part:
                        total_tokens += len(encoding.encode(part["tool_use_id"]))
                    if "name" in part:
                        total_tokens += len(encoding.encode(part["name"]))
                    if "input" in part:
                        # Tool input is usually a dict
                        total_tokens += len(encoding.encode(json.dumps(part["input"])))
                    if "content" in part:
                        total_tokens += len(encoding.encode(str(part["content"])))

        # Message formatting overhead (approximate)
        # Each message has some structural tokens
        total_tokens += 4

    return total_tokens


def get_encoding() -> tiktoken.Encoding:
    """Get cached encoding for performance.

    Caches the encoding globally to avoid repeated loading.
    Uses cl100k_base (GPT-4/Claude tokenizer).

    Returns:
        Cached tiktoken encoding
    """
    global _encoding_cache
    if _encoding_cache is None:
        _encoding_cache = tiktoken.get_encoding("cl100k_base")
    return _encoding_cache


def count_tokens_fast(text: str) -> int:
    """Fast exact token counting for plain text.

    Optimized for pruning decisions where we count many outputs.
    Uses cached encoding to avoid repeated loading.

    Args:
        text: Plain text to count tokens for

    Returns:
        Exact token count
    """
    if not text:
        return 0

    encoding = get_encoding()
    return len(encoding.encode(text))
