"""Tests for duplicate detection and pruning (Phase 1.3)."""

from harnessutils import (
    HarnessConfig,
    Message,
    ToolPart,
    ToolState,
)
from harnessutils.compaction.pruning import (
    compute_content_hash,
    find_duplicate_output,
    generate_shingles,
    jaccard_similarity,
    prune_tool_outputs,
)


def test_generate_shingles_basic():
    """Test shingle generation from text."""
    text = "this is a test of the emergency broadcast system"
    shingles = generate_shingles(text, n=3)

    # Should generate n-grams of size 3
    assert "this is a" in shingles
    assert "is a test" in shingles
    assert "a test of" in shingles
    assert "test of the" in shingles

    # Should have correct count
    words = text.split()
    expected_count = len(words) - 3 + 1
    assert len(shingles) == expected_count


def test_generate_shingles_short_text():
    """Test shingles with text shorter than n."""
    text = "short"
    shingles = generate_shingles(text, n=5)

    # Should return the whole text
    assert "short" in shingles
    assert len(shingles) == 1


def test_generate_shingles_normalization():
    """Test that shingles are case-insensitive."""
    text1 = "This Is A Test"
    text2 = "this is a test"

    shingles1 = generate_shingles(text1, n=2)
    shingles2 = generate_shingles(text2, n=2)

    # Should be identical after normalization
    assert shingles1 == shingles2


def test_jaccard_similarity_identical():
    """Test Jaccard similarity of identical sets."""
    set1 = {"a", "b", "c"}
    set2 = {"a", "b", "c"}

    similarity = jaccard_similarity(set1, set2)
    assert similarity == 1.0


def test_jaccard_similarity_disjoint():
    """Test Jaccard similarity of disjoint sets."""
    set1 = {"a", "b", "c"}
    set2 = {"x", "y", "z"}

    similarity = jaccard_similarity(set1, set2)
    assert similarity == 0.0


def test_jaccard_similarity_partial():
    """Test Jaccard similarity of partially overlapping sets."""
    set1 = {"a", "b", "c", "d"}
    set2 = {"c", "d", "e", "f"}

    similarity = jaccard_similarity(set1, set2)
    # intersection = {c, d} = 2
    # union = {a, b, c, d, e, f} = 6
    # similarity = 2/6 = 0.333...
    assert abs(similarity - 0.333) < 0.01


def test_jaccard_similarity_empty():
    """Test Jaccard similarity with empty sets."""
    set1: set[str] = set()
    set2 = {"a", "b"}

    similarity = jaccard_similarity(set1, set2)
    assert similarity == 0.0


def test_compute_content_hash():
    """Test content hashing for exact duplicates."""
    text1 = "This is a test"
    text2 = "This is a test"
    text3 = "This is different"

    hash1 = compute_content_hash(text1)
    hash2 = compute_content_hash(text2)
    hash3 = compute_content_hash(text3)

    # Identical text = identical hash
    assert hash1 == hash2

    # Different text = different hash
    assert hash1 != hash3


def test_find_duplicate_output_exact():
    """Test finding exact duplicate outputs."""
    # Create two identical tool outputs
    part1 = ToolPart(
        tool="bash",
        call_id="call_1",
        state=ToolState(
            status="completed",
            input={"command": "ls"},
            output="file1.txt\nfile2.txt\nfile3.txt",
        ),
    )

    part2 = ToolPart(
        tool="bash",
        call_id="call_2",
        state=ToolState(
            status="completed",
            input={"command": "ls"},
            output="file1.txt\nfile2.txt\nfile3.txt",  # Identical
        ),
    )

    # Build recent outputs index
    shingles1 = generate_shingles(part1.state.output)
    recent = [(part1, shingles1)]

    # Check if part2 is duplicate
    duplicate = find_duplicate_output(part2, recent, similarity_threshold=0.8)

    assert duplicate is not None
    assert duplicate == part1


def test_find_duplicate_output_similar():
    """Test finding similar (not exact) duplicate outputs."""
    # Create similar but not identical outputs (high overlap)
    output1 = "line one\nline two\nline three\nline four\nline five\nline six\nline seven"
    output2 = "line one\nline two\nline three\nline four\nline five\nline six\nline different"

    part1 = ToolPart(
        tool="read",
        call_id="call_1",
        state=ToolState(
            status="completed",
            input={"file": "test.py"},
            output=output1,
        ),
    )

    part2 = ToolPart(
        tool="read",
        call_id="call_2",
        state=ToolState(
            status="completed",
            input={"file": "test.py"},
            output=output2,
        ),
    )

    # Build recent outputs index
    shingles1 = generate_shingles(part1.state.output)
    recent = [(part1, shingles1)]

    # Check if part2 is duplicate (high similarity - 6/7 lines same)
    duplicate = find_duplicate_output(part2, recent, similarity_threshold=0.7)

    assert duplicate is not None


def test_find_duplicate_output_not_similar():
    """Test that dissimilar outputs are not detected as duplicates."""
    part1 = ToolPart(
        tool="bash",
        call_id="call_1",
        state=ToolState(
            status="completed",
            input={"command": "ls"},
            output="file1.txt\nfile2.txt",
        ),
    )

    part2 = ToolPart(
        tool="bash",
        call_id="call_2",
        state=ToolState(
            status="completed",
            input={"command": "ps"},
            output="PID COMMAND\n1234 python\n5678 bash",
        ),
    )

    # Build recent outputs index
    shingles1 = generate_shingles(part1.state.output)
    recent = [(part1, shingles1)]

    # Check if part2 is duplicate (should not be)
    duplicate = find_duplicate_output(part2, recent, similarity_threshold=0.8)

    assert duplicate is None


def test_find_duplicate_output_different_tools():
    """Test that outputs from different tools are not compared."""
    part1 = ToolPart(
        tool="bash",
        call_id="call_1",
        state=ToolState(
            status="completed",
            input={"command": "echo test"},
            output="test",
        ),
    )

    part2 = ToolPart(
        tool="read",  # Different tool
        call_id="call_2",
        state=ToolState(
            status="completed",
            input={"file": "test.txt"},
            output="test",  # Same output but different tool
        ),
    )

    # Build recent outputs index
    shingles1 = generate_shingles(part1.state.output)
    recent = [(part1, shingles1)]

    # Should not detect as duplicate (different tools)
    duplicate = find_duplicate_output(part2, recent, similarity_threshold=0.8)

    assert duplicate is None


def test_prune_detects_and_removes_duplicates():
    """Test that pruning detects and removes duplicate outputs."""
    config = HarnessConfig()
    config.pruning.detect_duplicates = True
    config.pruning.use_importance_scoring = False  # Disable to test deduplication only
    config.pruning.similarity_threshold = 0.8
    config.pruning.prune_protect = 100000  # High to avoid importance pruning
    config.pruning.prune_minimum = 0  # No minimum threshold
    config.pruning.protect_turns = 0

    # Create messages with duplicate outputs
    msg1 = Message(id="msg_1", role="assistant")
    part1 = ToolPart(
        tool="read",
        call_id="call_1",
        state=ToolState(
            status="completed",
            input={"file": "test.py"},
            output="def foo():\n    return 42\n" * 10,  # Large enough
        ),
    )
    msg1.add_part(part1)

    msg2 = Message(id="msg_2", role="user")

    msg3 = Message(id="msg_3", role="assistant")
    part2 = ToolPart(
        tool="read",
        call_id="call_2",
        state=ToolState(
            status="completed",
            input={"file": "test.py"},
            output="def foo():\n    return 42\n" * 10,  # Duplicate
        ),
    )
    msg3.add_part(part2)

    messages = [msg1, msg2, msg3]

    result = prune_tool_outputs(messages, config.pruning)

    # Should detect and prune duplicate
    assert result.pruned >= 1, f"Expected pruning but got {result}"
    assert result.tokens_saved > 0

    # Older output should be pruned (keeps most recent)
    assert part1.state.output == "", "Older duplicate should be pruned"
    if part1.state.time:  # Only check compacted if time object exists
        assert part1.state.time.compacted > 0

    # Newer output should be kept
    assert part2.state.output != "", "Newer output should be kept"


def test_prune_keeps_first_occurrence():
    """Test that most recent occurrence is kept, older duplicates pruned."""
    config = HarnessConfig()
    config.pruning.detect_duplicates = True
    config.pruning.prune_protect = 100000
    config.pruning.prune_minimum = 0  # No minimum threshold
    config.pruning.protect_turns = 0

    # Create 3 identical outputs with user messages between
    messages = []
    parts = []

    for i in range(3):
        msg = Message(id=f"msg_{i}", role="assistant")
        part = ToolPart(
            tool="bash",
            call_id=f"call_{i}",
            state=ToolState(
                status="completed",
                input={"command": "ls"},
                output="file1.txt\nfile2.txt\n" * 10,
            ),
        )
        msg.add_part(part)
        messages.append(msg)
        parts.append(part)

        if i < 2:
            # Add user message between assistant messages
            messages.append(Message(id=f"msg_user_{i}", role="user"))

    result = prune_tool_outputs(messages, config.pruning)

    # Should prune 2 duplicates (keep most recent)
    assert result.pruned == 2, f"Expected 2 duplicates pruned, got {result.pruned}"

    # Most recent should be kept
    assert parts[-1].state.output != "", "Most recent should be kept"

    # Older duplicates should be pruned
    assert parts[0].state.output == "", "Oldest duplicate should be pruned"
    assert parts[1].state.output == "", "Middle duplicate should be pruned"


def test_prune_deduplication_disabled():
    """Test that disabling deduplication preserves duplicates."""
    config = HarnessConfig()
    config.pruning.detect_duplicates = False  # Disabled
    config.pruning.use_importance_scoring = False
    config.pruning.prune_protect = 100000
    config.pruning.protect_turns = 0

    # Create duplicate outputs
    msg1 = Message(id="msg_1", role="assistant")
    part1 = ToolPart(
        tool="bash",
        call_id="call_1",
        state=ToolState(
            status="completed",
            input={"command": "ls"},
            output="duplicate output\n" * 10,
        ),
    )
    msg1.add_part(part1)

    msg2 = Message(id="msg_2", role="user")

    msg3 = Message(id="msg_3", role="assistant")
    part2 = ToolPart(
        tool="bash",
        call_id="call_2",
        state=ToolState(
            status="completed",
            input={"command": "ls"},
            output="duplicate output\n" * 10,  # Duplicate
        ),
    )
    msg3.add_part(part2)

    messages = [msg1, msg2, msg3]

    result = prune_tool_outputs(messages, config.pruning)

    # Should not prune duplicates when disabled
    assert result.pruned == 0

    # Both outputs preserved
    assert part1.state.output != ""
    assert part2.state.output != ""


def test_prune_duplicate_lookback_limit():
    """Test that duplicate detection respects lookback limit."""
    config = HarnessConfig()
    config.pruning.detect_duplicates = True
    config.pruning.duplicate_lookback = 2  # Only check last 2
    config.pruning.prune_protect = 100000
    config.pruning.protect_turns = 0

    # Create 4 outputs, 1st and 4th are duplicates
    messages = []
    parts = []

    for i in range(4):
        msg = Message(id=f"msg_{i}", role="assistant")
        part = ToolPart(
            tool="bash",
            call_id=f"call_{i}",
            state=ToolState(
                status="completed",
                input={"command": "ls"},
                output="duplicate" if i in [0, 3] else f"different_{i}",
            ),
        )
        msg.add_part(part)
        messages.append(msg)
        parts.append(part)

        if i < 3:
            messages.append(Message(id=f"msg_user_{i}", role="user"))

    result = prune_tool_outputs(messages, config.pruning)

    # Should NOT detect duplicate (lookback=2, but outputs 0 and 3 are 4 apart)
    # Actually, with lookback=2, we only check against the last 2 non-pruned outputs
    # So output 3 won't match output 0 because output 0 is beyond the lookback window
    # This behavior is expected - it prevents expensive comparisons against all history
    assert result.pruned == 0  # No duplicates found within lookback window


def test_deduplication_enabled_by_default():
    """Test that deduplication is enabled by default."""
    config = HarnessConfig()
    assert config.pruning.detect_duplicates is True
    assert config.pruning.similarity_threshold == 0.8
    assert config.pruning.duplicate_lookback == 20
