# Bugfix: Special Token Encoding in tiktoken

## Problem

When conversation content contained special token strings like `<|endoftext|>`, `<|im_start|>`, etc., tiktoken raised a `ValueError`:

```
ValueError: Encountered text corresponding to disallowed special token '<|endoftext|>'.
If you want this text to be encoded as a special token, pass it to `allowed_special`...
If you want this text to be encoded as normal text, disable the check for this token by passing `disallowed_special=()`
```

This caused crashes in production harnesses when:
- User messages discussed special tokens
- Tool outputs contained model-related documentation
- Error messages referenced tokenization

## Root Cause

tiktoken by default prevents encoding strings that look like special tokens to avoid confusion between:
- Actual special tokens used for model control (e.g., `<|endoftext|>` marking end of document)
- Normal text content that happens to contain those strings (e.g., `"The model uses <|endoftext|> as separator"`)

Since harness-utils counts tokens in **conversation content** (not model control sequences), we should treat special token strings as normal text.

## Solution

Added `disallowed_special=()` parameter to all `encoding.encode()` calls in `src/harnessutils/tokens/exact.py`.

**Before:**
```python
total_tokens += len(encoding.encode(content))  # Crashes on special tokens
```

**After:**
```python
total_tokens += len(encoding.encode(content, disallowed_special=()))  # Treats as normal text
```

This tells tiktoken: "Don't check for special tokens - encode everything as normal text."

## Files Changed

- `src/harnessutils/tokens/exact.py`:
  - `count_tokens_exact()`: 9 calls to `encoding.encode()` updated
  - `count_tokens_fast()`: 1 call updated

## Tests Added

New regression test in `tests/test_exact_tokens.py`:
```python
def test_calculate_context_usage_with_special_tokens():
    """Verify special token strings in content are counted as normal text."""
    # Add messages containing <|endoftext|>, <|im_start|>, <|im_end|>
    # Should NOT raise ValueError
    token_count = manager.calculate_context_usage(conv.id)
    assert token_count > 20
```

## Verification

```bash
# All 272 tests pass
uv run pytest tests/ -v

# Including new special token test
uv run pytest tests/test_exact_tokens.py::test_calculate_context_usage_with_special_tokens -v

# Linting clean
uv run ruff check src/harnessutils/tokens/exact.py
uv run mypy src/harnessutils/tokens/exact.py
```

## Impact

**Before:** Harnesses crashed when conversations mentioned special tokens
**After:** Special token strings counted as normal text (expected behavior)

**Severity:** High - production crash
**Frequency:** Rare but unpredictable (depends on conversation content)
**Fix complexity:** Low (1 parameter added to 10 function calls)

## Related

- tiktoken docs: https://github.com/openai/tiktoken#encoding-special-tokens
- Common special tokens: `<|endoftext|>`, `<|im_start|>`, `<|im_end|>`, `<|fim_prefix|>`, `<|fim_suffix|>`
