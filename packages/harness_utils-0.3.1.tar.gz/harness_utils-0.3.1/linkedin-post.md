# LinkedIn Post: harness-utils 0.3.0 - Production Ready

---

**I just shipped harness-utils 0.3.0, and I think it's finally production-ready. Here's why.**

Three months ago, I released 0.1.6 with a simple promise: manage LLM context windows so agents can run indefinitely without hitting token limits.

It worked. But it was naive.

**The problem with 0.1.6:**
- Pruned content blindly (recent 40K tokens kept, rest deleted)
- No visibility into what was being lost
- Token counting was off by 16-100% (estimation vs reality)
- No way to prevent overflow before it happened
- One size fits all - same strategy for every agent

**What changed in 0.3.0:**

📊 **9,425 lines of new code**
🧪 **228 tests (87% coverage)**
📦 **7 new production modules**

**1. Importance-Based Pruning**
Not all context is equal. Errors get +500 boost, warnings +200, user-requested content +300. Tool outputs scored by recency, semantic value, and type priority. Critical content survives, noise doesn't.

**2. Duplicate Detection**
Using Jaccard similarity with 5-word shingles. If you've run `grep` 20 times with similar results, we keep one. Saw 30-40% redundancy reduction in real harnesses.

**3. Content-Aware Truncation**
JSON gets parsed and array-truncated. Stacktraces preserve error message + top/bottom frames. Logs keep ALL errors, sample info lines. No more mid-JSON cuts destroying structure.

**4. Predictive Overflow Prevention**
Tracks conversation velocity (tokens per turn), projects N turns ahead, triggers compaction at 80% before overflow. No more sudden failures mid-conversation.

**5. Differential Summarization**
Only summarizes new content since last summary. 60-80% cost reduction vs full re-summarization. Faster model (Haiku) for incremental, capable model (Sonnet) for full.

**6. Quality Metrics**
Five metrics: information density, redundancy ratio, staleness score, error preservation rate, protected ratio. Health classification (good/degraded/poor) + actionable recommendations. Track degradation before it becomes a problem.

**7. Selective Context Loading**
Multi-agent systems don't need every conversation fully loaded. Query API: load recent N, filter by errors, extract high-importance only. Summaries are lightweight (metadata-only).

**8. Full Observability**
Context inspector shows what's in memory, what's protected, what's prunable. Predict impact before adding content. Rich decision metadata - audit trail for every pruning operation.

**9. Snapshots**
Capture conversation state, restore to baseline, compare outcomes. Reproducibility for debugging. A/B test different context strategies.

**10. Vendor Neutrality**
LLMClient protocol - bring your own model (Claude, GPT-4, Ollama, custom). Library provides primitives, you control the LLM.

**The numbers that matter:**

Before (0.1.6):
- 11 test files
- ~200 lines of core logic
- Blind pruning
- Reactive overflow
- 16-100% token counting error

After (0.3.0):
- 25 test files (228 tests total)
- 9,425 new lines
- Importance-scored pruning with audit trails
- Predictive overflow with velocity tracking
- Exact token counting (tiktoken)
- 60-80% cost reduction (differential summarization)
- 30-40% redundancy reduction (deduplication)
- 87% test coverage

**Production readiness checklist:**
✅ Comprehensive error handling with custom exceptions
✅ Config validation with remediation guidance
✅ Full audit trails (decision metadata on every pruning op)
✅ Quality monitoring (track degradation over time)
✅ Vendor neutrality (no lock-in)
✅ 228 tests covering edge cases
✅ Maintenance utilities (cleanup, dedup, issue detection)
✅ Multi-agent primitives (selective loading, snapshots)

**Who should use this:**

If you're building:
- Long-running agents (hours of conversation)
- Multi-agent systems (main + exploration subagents)
- Production harnesses where overflow = downtime
- Cost-sensitive applications (differential summarization saves real $)
- Debugging agents (error preservation is critical)

**What I learned:**

1. **Observability unlocks trust** - Developers won't use what they can't inspect. Context inspector API was the turning point.

2. **Not all tokens are equal** - Importance scoring (errors +500, warnings +200) preserves what matters. Blind FIFO pruning loses critical context.

3. **Deduplication is underrated** - 30-40% of context is often redundant (repeated grep/read calls). Easy wins.

4. **Predictive > Reactive** - Detecting overflow after it happens is too late. Velocity tracking + 80% threshold prevents failures.

5. **Test coverage = confidence** - 228 tests covering edge cases (duplicate detection, importance scoring, content-aware truncation) means I sleep well.

**Try it:**

```bash
uv add harness-utils
```

Docs: github.com/jgtregunna/harness-utils

I built this because I was tired of agents dying mid-conversation. Now they run indefinitely with full observability.

Ship it.

---

#AI #LLM #MultiAgent #ProductionReady #OpenSource #Python

---

**Optional shorter version:**

**harness-utils 0.3.0: From prototype to production**

Three months, 9,425 lines of code, 228 tests.

What changed:
🎯 Importance-based pruning (errors +500, warnings +200)
🔍 Duplicate detection (30-40% redundancy reduction)
💰 Differential summarization (60-80% cost reduction)
📊 Predictive overflow (velocity tracking, triggers at 80%)
🔬 Full observability (context inspector, quality metrics)
📸 Snapshots (reproducibility, A/B testing)
🔓 Vendor neutral (bring your own LLM)

The result: Agents that run indefinitely without hitting token limits. With full audit trails, quality monitoring, and zero surprises.

87% test coverage. Production ready.

```bash
uv add harness-utils
```

#AI #LLM #OpenSource #Python
