"""harness-utils: Context window management utilities for LLM-based applications."""

__version__ = "0.1.0"

from harnessutils.config import (
    CompactionConfig,
    HarnessConfig,
    ModelLimitsConfig,
    PruningConfig,
    StorageConfig,
    SummarizationConfig,
    TokenConfig,
    TruncationConfig,
)
from harnessutils.exceptions import (
    ConfigurationError,
    HarnessError,
    PruningError,
    SnapshotError,
    StorageError,
    SummarizationError,
    TruncationError,
)
from harnessutils.manager import ConversationManager
from harnessutils.models import (
    CacheUsage,
    CompactionPart,
    Conversation,
    Message,
    Part,
    PatchPart,
    ReasoningPart,
    StepFinishPart,
    StepStartPart,
    SubtaskPart,
    TextPart,
    ToolPart,
    ToolState,
    Usage,
)
from harnessutils.storage import FilesystemStorage, MemoryStorage
from harnessutils.turn import ToolStateMachine, TurnHooks, TurnProcessor, transition_state
from harnessutils.types import LLMClient, StorageBackend
from harnessutils.utils import generate_id

__all__ = [
    "__version__",
    "HarnessConfig",
    "TruncationConfig",
    "PruningConfig",
    "TokenConfig",
    "ModelLimitsConfig",
    "StorageConfig",
    "CompactionConfig",
    "SummarizationConfig",
    "HarnessError",
    "ConfigurationError",
    "PruningError",
    "SummarizationError",
    "TruncationError",
    "SnapshotError",
    "StorageError",
    "Conversation",
    "Message",
    "Part",
    "TextPart",
    "ReasoningPart",
    "ToolPart",
    "ToolState",
    "StepStartPart",
    "StepFinishPart",
    "CompactionPart",
    "PatchPart",
    "SubtaskPart",
    "Usage",
    "CacheUsage",
    "LLMClient",
    "StorageBackend",
    "ConversationManager",
    "FilesystemStorage",
    "MemoryStorage",
    "generate_id",
    "TurnHooks",
    "TurnProcessor",
    "ToolStateMachine",
    "transition_state",
]
