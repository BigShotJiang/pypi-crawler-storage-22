"""Tier 2: Selective pruning of tool outputs.

Removes old tool outputs while preserving conversation structure.
Cost: Cheap (~50ms), Latency: ~50ms.
"""

import hashlib
import math
import time
from dataclasses import dataclass, field
from typing import Any, Literal

from harnessutils.config import PruningConfig
from harnessutils.models.message import Message
from harnessutils.models.parts import ToolPart
from harnessutils.tokens.exact import count_tokens_fast


@dataclass
class PruningDecision:
    """Individual pruning decision for a tool output.

    Tracks why a specific output was kept or pruned, enabling full
    audit trail and debugging of pruning behavior.
    """

    message_id: str  # Message containing this output
    part_id: str  # Tool part ID
    tool: str  # Tool name
    decision: Literal[
        "kept",                    # Output kept in context
        "pruned_duplicate",        # Removed as duplicate
        "pruned_low_importance",   # Removed due to low importance score
        "pruned_fifo",            # Removed by FIFO (oldest first)
        "protected_recent",        # Protected by recency (protect_turns)
        "protected_tool",          # Protected by tool type (protected_tools)
        "protected_summary",       # Protected (after summary boundary)
    ]
    importance_score: float | None = None  # Importance score (if scored)
    duplicate_of: str | None = None  # Part ID of duplicate (if duplicate)
    tokens: int = 0  # Token count of this output
    timestamp: int = 0  # When decision was made (unix ms)
    metadata: dict[str, Any] = field(default_factory=dict)  # Additional context

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "message_id": self.message_id,
            "part_id": self.part_id,
            "tool": self.tool,
            "decision": self.decision,
            "importance_score": self.importance_score,
            "duplicate_of": self.duplicate_of,
            "tokens": self.tokens,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
        }

    @property
    def was_pruned(self) -> bool:
        """Check if this output was pruned."""
        return self.decision.startswith("pruned_")

    @property
    def was_protected(self) -> bool:
        """Check if this output was protected from pruning."""
        return self.decision.startswith("protected_")


@dataclass
class PruningResult:
    """Result of pruning operation with detailed token tracking."""

    pruned: int  # Total outputs pruned
    tokens_saved: int  # Total tokens saved
    tokens_before: int = 0  # Token count before pruning
    tokens_after: int = 0  # Token count after pruning
    duplicates_pruned: int = 0  # Outputs pruned due to duplication
    importance_pruned: int = 0  # Outputs pruned due to low importance
    duplicate_tokens_saved: int = 0  # Tokens saved from deduplication
    importance_tokens_saved: int = 0  # Tokens saved from importance pruning
    decisions: list[PruningDecision] = field(default_factory=list)  # Full decision log

    def to_dict(self) -> dict[str, int | float]:
        """Convert to dictionary for reporting.

        Returns:
            Dictionary with all pruning metrics
        """
        return {
            "pruned": self.pruned,
            "tokens_saved": self.tokens_saved,
            "tokens_before": self.tokens_before,
            "tokens_after": self.tokens_after,
            "duplicates_pruned": self.duplicates_pruned,
            "importance_pruned": self.importance_pruned,
            "duplicate_tokens_saved": self.duplicate_tokens_saved,
            "importance_tokens_saved": self.importance_tokens_saved,
            "reduction_percent": round(
                (self.tokens_saved / self.tokens_before * 100) if self.tokens_before > 0 else 0,
                1,
            ),
        }

    def __str__(self) -> str:
        """Human-readable summary of pruning results."""
        if self.pruned == 0:
            return "No pruning needed"

        lines = [
            f"Pruned {self.pruned} outputs, saved {self.tokens_saved:,} tokens",
            f"  Before: {self.tokens_before:,} tokens",
            f"  After: {self.tokens_after:,} tokens",
            f"  Reduction: {self.to_dict()['reduction_percent']}%",
        ]

        if self.duplicates_pruned > 0:
            lines.append(
                f"  Duplicates: {self.duplicates_pruned} removed "
                f"({self.duplicate_tokens_saved:,} tokens)"
            )

        if self.importance_pruned > 0:
            lines.append(
                f"  Low importance: {self.importance_pruned} removed "
                f"({self.importance_tokens_saved:,} tokens)"
            )

        return "\n".join(lines)

    def get_pruned_decisions(self) -> list[PruningDecision]:
        """Get all decisions that resulted in pruning.

        Returns:
            List of decisions where output was pruned
        """
        return [d for d in self.decisions if d.was_pruned]

    def get_protected_decisions(self) -> list[PruningDecision]:
        """Get all decisions that resulted in protection.

        Returns:
            List of decisions where output was protected
        """
        return [d for d in self.decisions if d.was_protected]

    def get_kept_decisions(self) -> list[PruningDecision]:
        """Get all decisions where output was kept.

        Returns:
            List of decisions where output was kept (not pruned or protected)
        """
        return [d for d in self.decisions if d.decision == "kept"]

    def get_decision_by_part(self, part_id: str) -> PruningDecision | None:
        """Find decision for specific tool part.

        Args:
            part_id: Tool part ID to find

        Returns:
            Decision for that part, or None if not found
        """
        for decision in self.decisions:
            if decision.part_id == part_id:
                return decision
        return None


@dataclass
class OutputImportance:
    """Importance score components for a tool output."""

    recency_score: float  # Exponential decay based on age
    size_penalty: float  # Penalty for large outputs
    semantic_score: float  # Content-based importance (errors, warnings)
    tool_priority: float  # Tool type importance
    token_count: int  # Actual token count

    @property
    def total_score(self) -> float:
        """Calculate weighted total importance score.

        Higher score = more important = keep longer.
        Lower score = less important = prune first.
        """
        return (
            self.recency_score
            + self.size_penalty
            + self.semantic_score
            + self.tool_priority
        )


def generate_shingles(text: str, n: int = 5) -> set[str]:
    """Generate word-level n-grams (shingles) for similarity detection.

    Args:
        text: Text to generate shingles from
        n: Size of n-grams (default: 5 words)

    Returns:
        Set of n-gram strings
    """
    # Normalize text
    words = text.lower().split()

    if len(words) < n:
        # If text too short, use the whole thing
        return {" ".join(words)} if words else set()

    # Generate n-grams
    shingles = set()
    for i in range(len(words) - n + 1):
        shingle = " ".join(words[i : i + n])
        shingles.add(shingle)

    return shingles


def jaccard_similarity(set1: set[str], set2: set[str]) -> float:
    """Calculate Jaccard similarity between two sets.

    Jaccard similarity = |intersection| / |union|
    Returns value between 0.0 (no overlap) and 1.0 (identical).

    Args:
        set1: First set
        set2: Second set

    Returns:
        Similarity score [0.0, 1.0]
    """
    if not set1 or not set2:
        return 0.0

    intersection = len(set1 & set2)
    union = len(set1 | set2)

    if union == 0:
        return 0.0

    return intersection / union


def compute_content_hash(text: str) -> str:
    """Compute fast hash of text content for exact duplicate detection.

    Args:
        text: Text to hash

    Returns:
        MD5 hash hex string
    """
    return hashlib.md5(text.encode("utf-8")).hexdigest()


def find_duplicate_output(
    part: ToolPart,
    recent_parts: list[tuple[ToolPart, set[str]]],
    similarity_threshold: float = 0.8,
) -> ToolPart | None:
    """Find if output is duplicate of a recent output.

    Args:
        part: Tool part to check for duplication
        recent_parts: List of (part, shingles) tuples to compare against
        similarity_threshold: Minimum similarity to consider duplicate (default: 0.8)

    Returns:
        The duplicate part if found, None otherwise
    """
    # Only compare against same tool type
    # Different tools are unlikely to produce identical outputs
    # This prevents false positives across tool types
    same_tool_parts = [
        (p, shingles) for p, shingles in recent_parts if p.tool == part.tool
    ]

    if not same_tool_parts:
        return None

    # Fast path: exact duplicate check (within same tool type)
    current_hash = compute_content_hash(part.state.output)

    for recent_part, _ in same_tool_parts:
        if compute_content_hash(recent_part.state.output) == current_hash:
            return recent_part  # Exact duplicate

    # Generate shingles for current part
    current_shingles = generate_shingles(part.state.output)

    # Check similarity against recent parts of same tool
    for recent_part, recent_shingles in same_tool_parts:
        similarity = jaccard_similarity(current_shingles, recent_shingles)

        if similarity >= similarity_threshold:
            return recent_part  # Found similar output

    return None


def calculate_context_tokens(messages: list[Message]) -> int:
    """Calculate total token count for all tool outputs in conversation.

    Args:
        messages: All conversation messages

    Returns:
        Total token count
    """
    total = 0
    for msg in messages:
        for part in msg.parts:
            if isinstance(part, ToolPart) and part.state.status == "completed":
                if part.state.output:  # Only count non-empty outputs
                    total += count_tokens_fast(part.state.output)
    return total


def calculate_turn_age(messages: list[Message], target_msg: Message) -> int:
    """Calculate how many turns ago a message was created.

    Args:
        messages: All conversation messages
        target_msg: Message to calculate age for

    Returns:
        Number of user turns since this message (0 = current turn)
    """
    turn_count = 0
    for msg in reversed(messages):
        if msg.id == target_msg.id:
            return turn_count
        if msg.role == "user":
            turn_count += 1
    return turn_count


def score_tool_output(
    part: ToolPart,
    message: Message,
    messages: list[Message],
    config: PruningConfig,
) -> OutputImportance:
    """Calculate importance score for a tool output.

    Args:
        part: Tool part to score
        message: Message containing this part
        messages: All conversation messages
        config: Pruning configuration with scoring weights

    Returns:
        OutputImportance with all score components
    """
    token_count = count_tokens_fast(part.state.output)

    # 1. Recency score (exponential decay)
    age = calculate_turn_age(messages, message)
    recency = math.exp(-age * config.recency_decay) * 100 * config.recency_weight

    # 2. Size penalty (prefer removing large outputs)
    size_penalty = math.log(token_count + 1) * 10 * config.size_weight

    # 3. Semantic importance
    semantic = 0.0
    output_lower = part.state.output.lower()

    # Check for errors
    if any(
        keyword in output_lower
        for keyword in ["error", "exception", "traceback", "failed"]
    ):
        semantic += config.error_boost

    # Check for warnings
    if "warning" in output_lower or "warn" in output_lower:
        semantic += config.warning_boost

    # Check if user explicitly requested this
    if part.state.metadata and part.state.metadata.get("user_requested"):
        semantic += config.user_requested_boost

    semantic *= config.semantic_weight

    # 4. Tool type priority
    tool_priority = config.tool_importance.get(part.tool, 50.0) * config.tool_priority_weight

    return OutputImportance(
        recency_score=recency,
        size_penalty=size_penalty,
        semantic_score=semantic,
        tool_priority=tool_priority,
        token_count=token_count,
    )


def prune_tool_outputs(
    messages: list[Message],
    config: PruningConfig,
) -> PruningResult:
    """Prune tool outputs from conversation history.

    Selectively removes old tool outputs while preserving:
    - Tool call metadata (name, input, title, timing)
    - Recent outputs (within protection window)
    - Protected tool outputs
    - Last N turns

    Uses exact token counting via tiktoken for accurate pruning decisions.

    First runs duplicate detection (if enabled), then applies either
    importance-based or FIFO pruning strategy.

    Args:
        messages: Conversation messages (newest first recommended)
        config: Pruning configuration

    Returns:
        PruningResult with detailed token tracking and breakdown
    """
    # Calculate token usage before pruning
    tokens_before = calculate_context_tokens(messages)

    # Phase 1: Duplicate detection (runs regardless of scoring strategy)
    duplicate_result = PruningResult(pruned=0, tokens_saved=0)
    if config.detect_duplicates:
        duplicate_result = _detect_and_prune_duplicates(messages, config)

    # Phase 2: Importance-based or FIFO pruning
    if config.use_importance_scoring:
        pruning_result = _prune_with_importance_scoring_only(messages, config)
    else:
        pruning_result = _prune_simple(messages, config)

    # Calculate token usage after pruning
    tokens_after = calculate_context_tokens(messages)

    # Combine results with detailed tracking
    all_decisions = duplicate_result.decisions + pruning_result.decisions

    return PruningResult(
        pruned=duplicate_result.pruned + pruning_result.pruned,
        tokens_saved=duplicate_result.tokens_saved + pruning_result.tokens_saved,
        tokens_before=tokens_before,
        tokens_after=tokens_after,
        duplicates_pruned=duplicate_result.pruned,
        importance_pruned=pruning_result.pruned,
        duplicate_tokens_saved=duplicate_result.tokens_saved,
        importance_tokens_saved=pruning_result.tokens_saved,
        decisions=all_decisions,
    )


def _prune_simple(
    messages: list[Message],
    config: PruningConfig,
) -> PruningResult:
    """Simple FIFO pruning (original algorithm).

    Prunes oldest outputs first when token budget exceeded.
    """
    total_tokens = 0
    prunable_tokens = 0
    to_prune: list[tuple[Message, ToolPart, int]] = []
    decisions: list[PruningDecision] = []
    turns_skipped = 0
    now_ms = int(time.time() * 1000)

    for msg in reversed(messages):
        if msg.role == "user":
            turns_skipped += 1

        # Check if past summary boundary
        past_summary = msg.summary

        for part in msg.parts:
            if not isinstance(part, ToolPart):
                continue

            if part.state.status != "completed":
                continue

            token_count = count_tokens_fast(part.state.output) if part.state.output else 0

            # Track protection reasons
            if turns_skipped < config.protect_turns:
                decisions.append(
                    PruningDecision(
                        message_id=msg.id,
                        part_id=part.call_id,
                        tool=part.tool,
                        decision="protected_recent",
                        tokens=token_count,
                        timestamp=now_ms,
                        metadata={"turns_back": turns_skipped},
                    )
                )
                continue

            if past_summary:
                decisions.append(
                    PruningDecision(
                        message_id=msg.id,
                        part_id=part.call_id,
                        tool=part.tool,
                        decision="protected_summary",
                        tokens=token_count,
                        timestamp=now_ms,
                    )
                )
                break

            if part.tool in config.protected_tools:
                decisions.append(
                    PruningDecision(
                        message_id=msg.id,
                        part_id=part.call_id,
                        tool=part.tool,
                        decision="protected_tool",
                        tokens=token_count,
                        timestamp=now_ms,
                        metadata={"protected_tools": config.protected_tools},
                    )
                )
                continue

            if part.state.time and part.state.time.compacted:
                # Already compacted, skip (don't track as decision)
                continue

            total_tokens += token_count

            if total_tokens > config.prune_protect:
                prunable_tokens += token_count
                to_prune.append((msg, part, token_count))
            else:
                # Kept within budget
                decisions.append(
                    PruningDecision(
                        message_id=msg.id,
                        part_id=part.call_id,
                        tool=part.tool,
                        decision="kept",
                        tokens=token_count,
                        timestamp=now_ms,
                        metadata={"total_tokens_so_far": total_tokens},
                    )
                )

    if prunable_tokens > config.prune_minimum:
        # Actually prune
        for msg, part, tokens in to_prune:
            part.state.output = ""
            part.state.attachments = []
            if part.state.time:
                part.state.time.compacted = int(time.time() * 1000)

            # Record pruning decision
            decisions.append(
                PruningDecision(
                    message_id=msg.id,
                    part_id=part.call_id,
                    tool=part.tool,
                    decision="pruned_fifo",
                    tokens=tokens,
                    timestamp=now_ms,
                    metadata={
                        "prunable_tokens": prunable_tokens,
                        "prune_minimum": config.prune_minimum,
                    },
                )
            )

        return PruningResult(
            pruned=len(to_prune), tokens_saved=prunable_tokens, decisions=decisions
        )

    # Not enough to prune - mark all candidates as kept
    for msg, part, tokens in to_prune:
        decisions.append(
            PruningDecision(
                message_id=msg.id,
                part_id=part.call_id,
                tool=part.tool,
                decision="kept",
                tokens=tokens,
                timestamp=now_ms,
                metadata={
                    "reason": "below_minimum_threshold",
                    "prunable_tokens": prunable_tokens,
                    "prune_minimum": config.prune_minimum,
                },
            )
        )

    return PruningResult(pruned=0, tokens_saved=0, decisions=decisions)


def _prune_with_importance_scoring_only(
    messages: list[Message],
    config: PruningConfig,
) -> PruningResult:
    """Smart pruning using importance scoring.

    Scores all outputs by importance and prunes lowest-value first.
    Preserves critical outputs (errors, warnings, user-requested).

    Note: Duplicate detection happens separately before this function is called.
    """
    # Collect all prunable outputs with scores
    scored_outputs: list[tuple[Message, ToolPart, OutputImportance]] = []
    decisions: list[PruningDecision] = []
    turns_skipped = 0
    now_ms = int(time.time() * 1000)

    for msg in reversed(messages):
        if msg.role == "user":
            turns_skipped += 1

        past_summary = msg.summary

        for part in msg.parts:
            if not isinstance(part, ToolPart):
                continue

            if part.state.status != "completed":
                continue

            token_count = count_tokens_fast(part.state.output) if part.state.output else 0

            # Track protection reasons (same as FIFO)
            if turns_skipped < config.protect_turns:
                decisions.append(
                    PruningDecision(
                        message_id=msg.id,
                        part_id=part.call_id,
                        tool=part.tool,
                        decision="protected_recent",
                        tokens=token_count,
                        timestamp=now_ms,
                        metadata={"turns_back": turns_skipped},
                    )
                )
                continue

            if past_summary:
                decisions.append(
                    PruningDecision(
                        message_id=msg.id,
                        part_id=part.call_id,
                        tool=part.tool,
                        decision="protected_summary",
                        tokens=token_count,
                        timestamp=now_ms,
                    )
                )
                break

            if part.tool in config.protected_tools:
                decisions.append(
                    PruningDecision(
                        message_id=msg.id,
                        part_id=part.call_id,
                        tool=part.tool,
                        decision="protected_tool",
                        tokens=token_count,
                        timestamp=now_ms,
                        metadata={"protected_tools": config.protected_tools},
                    )
                )
                continue

            if part.state.time and part.state.time.compacted:
                # Already compacted, skip
                continue

            # Score this output
            importance = score_tool_output(part, msg, messages, config)
            scored_outputs.append((msg, part, importance))

    # Calculate total tokens
    total_tokens = sum(imp.token_count for _, _, imp in scored_outputs)

    # If under budget, mark all as kept
    if total_tokens <= config.prune_protect:
        for msg, part, importance in scored_outputs:
            decisions.append(
                PruningDecision(
                    message_id=msg.id,
                    part_id=part.call_id,
                    tool=part.tool,
                    decision="kept",
                    importance_score=importance.total_score,
                    tokens=importance.token_count,
                    timestamp=now_ms,
                    metadata={"total_tokens": total_tokens, "prune_protect": config.prune_protect},
                )
            )
        return PruningResult(pruned=0, tokens_saved=0, decisions=decisions)

    # Sort by importance (lowest score first = prune first)
    scored_outputs.sort(key=lambda x: x[2].total_score)

    # Prune until we're under budget
    to_prune: list[tuple[Message, ToolPart, OutputImportance]] = []
    current_tokens = total_tokens

    for msg, part, importance in scored_outputs:
        if current_tokens <= config.prune_protect:
            # Keep this one
            decisions.append(
                PruningDecision(
                    message_id=msg.id,
                    part_id=part.call_id,
                    tool=part.tool,
                    decision="kept",
                    importance_score=importance.total_score,
                    tokens=importance.token_count,
                    timestamp=now_ms,
                    metadata={
                        "current_tokens": current_tokens,
                        "prune_protect": config.prune_protect,
                    },
                )
            )
        else:
            # Mark for pruning
            to_prune.append((msg, part, importance))
            current_tokens -= importance.token_count

    # Only prune if savings meet minimum threshold
    tokens_saved = sum(imp.token_count for _, _, imp in to_prune)

    if tokens_saved >= config.prune_minimum:
        # Actually prune
        for msg, part, importance in to_prune:
            part.state.output = ""
            part.state.attachments = []
            if part.state.time:
                part.state.time.compacted = int(time.time() * 1000)

            # Record pruning decision with importance score
            decisions.append(
                PruningDecision(
                    message_id=msg.id,
                    part_id=part.call_id,
                    tool=part.tool,
                    decision="pruned_low_importance",
                    importance_score=importance.total_score,
                    tokens=importance.token_count,
                    timestamp=now_ms,
                    metadata={
                        "recency_score": importance.recency_score,
                        "size_penalty": importance.size_penalty,
                        "semantic_score": importance.semantic_score,
                        "tool_priority": importance.tool_priority,
                        "tokens_saved": tokens_saved,
                    },
                )
            )

        return PruningResult(pruned=len(to_prune), tokens_saved=tokens_saved, decisions=decisions)

    # Not enough savings - keep all
    for msg, part, importance in to_prune:
        decisions.append(
            PruningDecision(
                message_id=msg.id,
                part_id=part.call_id,
                tool=part.tool,
                decision="kept",
                importance_score=importance.total_score,
                tokens=importance.token_count,
                timestamp=now_ms,
                metadata={
                    "reason": "below_minimum_threshold",
                    "tokens_saved": tokens_saved,
                    "prune_minimum": config.prune_minimum,
                },
            )
        )

    return PruningResult(pruned=0, tokens_saved=0, decisions=decisions)


def _detect_and_prune_duplicates(
    messages: list[Message],
    config: PruningConfig,
) -> PruningResult:
    """Detect and prune duplicate tool outputs.

    Uses similarity hashing (shingles + Jaccard) to find near-duplicates.
    Aggressively prunes older duplicates while keeping the most recent.

    Args:
        messages: Conversation messages
        config: Pruning configuration

    Returns:
        PruningResult with duplicates pruned
    """
    # Build index of recent outputs with their shingles
    recent_outputs: list[tuple[ToolPart, set[str], Message]] = []
    # (msg, part, tokens, duplicate_of_id)
    duplicates_to_prune: list[tuple[Message, ToolPart, int, str]] = []
    decisions: list[PruningDecision] = []
    turns_skipped = 0
    now_ms = int(time.time() * 1000)

    for msg in reversed(messages):  # Newest first
        if msg.role == "user":
            turns_skipped += 1

        if turns_skipped < config.protect_turns:
            continue

        if msg.summary:
            break

        for part in msg.parts:
            if not isinstance(part, ToolPart):
                continue

            if part.state.status != "completed":
                continue

            if part.tool in config.protected_tools:
                continue

            if part.state.time and part.state.time.compacted:
                continue

            # Check if this is a duplicate
            if len(recent_outputs) > 0:
                # Only check against recent outputs (limited lookback)
                lookback = recent_outputs[-config.duplicate_lookback :]
                duplicate_of = find_duplicate_output(
                    part,
                    [(p, shingles) for p, shingles, _ in lookback],
                    config.similarity_threshold,
                )

                if duplicate_of:
                    # This is a duplicate - mark for pruning
                    token_count = count_tokens_fast(part.state.output)
                    duplicates_to_prune.append((msg, part, token_count, duplicate_of.call_id))
                    continue  # Don't add to recent_outputs

            # Not a duplicate - add to index and record decision
            shingles = generate_shingles(part.state.output)
            recent_outputs.append((part, shingles, msg))

            # Record as kept (unique)
            token_count = count_tokens_fast(part.state.output)
            decisions.append(
                PruningDecision(
                    message_id=msg.id,
                    part_id=part.call_id,
                    tool=part.tool,
                    decision="kept",
                    tokens=token_count,
                    timestamp=now_ms,
                    metadata={
                        "reason": "unique_output",
                        "similarity_threshold": config.similarity_threshold,
                    },
                )
            )

    # Prune duplicates
    tokens_saved = 0
    for msg, part, token_count, duplicate_of_id in duplicates_to_prune:
        part.state.output = ""
        part.state.attachments = []
        if part.state.time:
            part.state.time.compacted = int(time.time() * 1000)

        tokens_saved += token_count

        # Record pruning decision
        decisions.append(
            PruningDecision(
                message_id=msg.id,
                part_id=part.call_id,
                tool=part.tool,
                decision="pruned_duplicate",
                duplicate_of=duplicate_of_id,
                tokens=token_count,
                timestamp=now_ms,
                metadata={
                    "similarity_threshold": config.similarity_threshold,
                    "lookback": config.duplicate_lookback,
                },
            )
        )

    return PruningResult(
        pruned=len(duplicates_to_prune),
        tokens_saved=tokens_saved,
        decisions=decisions,
    )
