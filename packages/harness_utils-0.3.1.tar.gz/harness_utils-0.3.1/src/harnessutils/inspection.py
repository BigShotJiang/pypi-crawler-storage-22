"""Context inspection and debugging utilities.

Provides observability into context state, pruning decisions, and
predicted behavior. Enables agents to understand "what's in context"
and "why was X pruned".
"""

from dataclasses import dataclass
from typing import Any

from harnessutils.compaction.pruning import PruningDecision, calculate_context_tokens
from harnessutils.config import HarnessConfig
from harnessutils.models.conversation import Conversation
from harnessutils.models.message import Message
from harnessutils.models.parts import ToolPart
from harnessutils.tokens.exact import count_tokens_fast


@dataclass
class ContextSummary:
    """High-level summary of context state."""

    total_messages: int
    total_tokens: int
    tool_outputs: int
    tool_outputs_compacted: int
    summaries: int
    protected_tokens: int
    prunable_tokens: int
    health: str  # "good" | "degraded" | "poor"
    recommendations: list[str]


@dataclass
class ImpactPrediction:
    """Prediction of what would happen if tokens are added."""

    would_trigger_pruning: bool
    estimated_pruned_count: int
    would_trigger_overflow: bool
    estimated_tokens_after_pruning: int
    margin_remaining: int  # Tokens before hitting overflow


class ContextInspector:
    """Inspector for querying and analyzing context state.

    Provides full observability into:
    - What's currently in context
    - Why specific items were pruned
    - What would happen if more tokens added
    - Full audit trail of all decisions
    """

    def __init__(
        self,
        messages: list[Message],
        config: HarnessConfig,
        conversation: Conversation | None = None,
    ):
        """Initialize inspector.

        Args:
            messages: Conversation messages to inspect
            config: Harness configuration
            conversation: Optional conversation metadata
        """
        self.messages = messages
        self.config = config
        self.conversation = conversation
        self._decisions: list[PruningDecision] = []

    def summary(self) -> dict[str, Any]:
        """Get high-level summary of context state.

        Returns:
            Dictionary with context metrics:
            - total_messages: Count of all messages
            - total_tokens: Token count in context
            - tool_outputs: Count of tool outputs
            - tool_outputs_compacted: Count of compacted outputs
            - summaries: Count of summary messages
            - protected_tokens: Tokens in protected window
            - prunable_tokens: Tokens eligible for pruning
        """
        total_messages = len(self.messages)
        total_tokens = calculate_context_tokens(self.messages)

        tool_outputs = 0
        tool_outputs_compacted = 0
        summaries = 0
        protected_tokens = 0
        prunable_tokens = 0

        turns_from_end = 0
        for msg in reversed(self.messages):
            if msg.role == "user":
                turns_from_end += 1

            if msg.summary:
                summaries += 1

            for part in msg.parts:
                if not isinstance(part, ToolPart):
                    continue

                if part.state.status != "completed":
                    continue

                tool_outputs += 1

                if part.state.time and part.state.time.compacted:
                    tool_outputs_compacted += 1
                    continue

                tokens = count_tokens_fast(part.state.output) if part.state.output else 0

                # Check if protected
                is_protected = (
                    turns_from_end < self.config.pruning.protect_turns
                    or part.tool in self.config.pruning.protected_tools
                    or msg.summary
                )

                if is_protected:
                    protected_tokens += tokens
                else:
                    prunable_tokens += tokens

        return {
            "total_messages": total_messages,
            "total_tokens": total_tokens,
            "tool_outputs": tool_outputs,
            "tool_outputs_compacted": tool_outputs_compacted,
            "summaries": summaries,
            "protected_tokens": protected_tokens,
            "prunable_tokens": prunable_tokens,
        }

    def get_pruning_decision(
        self, message_id: str, part_id: str
    ) -> dict[str, Any] | None:
        """Get pruning decision for specific tool output.

        Args:
            message_id: Message ID
            part_id: Tool part call_id

        Returns:
            Decision details if found:
            - pruned: Whether this output was pruned
            - reason: Decision type (pruned_fifo, kept, etc.)
            - importance_score: Importance score if available
            - duplicate_of: Part ID of duplicate if applicable
            - tokens_saved: Tokens saved by pruning this
            - timestamp: When decision was made
            - metadata: Additional context

            None if no decision recorded for this part.
        """
        # This will be populated by manager when pruning happens
        # For now, we reconstruct from current state
        for msg in self.messages:
            if msg.id != message_id:
                continue

            for part in msg.parts:
                if not isinstance(part, ToolPart):
                    continue

                if part.call_id != part_id:
                    continue

                # Found the part - determine its status
                was_compacted = part.state.time and part.state.time.compacted

                if was_compacted:
                    return {
                        "pruned": True,
                        "reason": "compacted",
                        "importance_score": None,
                        "duplicate_of": None,
                        "pruned_at": part.state.time.compacted if part.state.time else None,
                        "tokens_saved": 0,  # Unknown
                        "metadata": {},
                    }
                else:
                    return {
                        "pruned": False,
                        "reason": "in_context",
                        "importance_score": None,
                        "duplicate_of": None,
                        "pruned_at": None,
                        "tokens_saved": 0,
                        "metadata": {},
                    }

        return None

    def predict_impact(self, additional_tokens: int) -> dict[str, Any]:
        """Predict what would happen if N tokens added.

        Args:
            additional_tokens: Number of tokens to simulate adding

        Returns:
            Prediction of impact:
            - would_trigger_pruning: Would pruning be triggered
            - estimated_pruned_count: How many outputs would be pruned
            - would_trigger_overflow: Would overflow/summarization trigger
            - estimated_tokens_after_pruning: Projected token count after pruning
            - margin_remaining: Tokens before hitting overflow
        """
        current_tokens = calculate_context_tokens(self.messages)
        projected_tokens = current_tokens + additional_tokens

        # Check if pruning would trigger
        would_trigger_pruning = False
        estimated_pruned_count = 0
        tokens_after_pruning = projected_tokens

        # Simple heuristic: if we exceed prune_protect, estimate pruning
        if projected_tokens > self.config.pruning.prune_protect:
            would_trigger_pruning = True

            # Count prunable outputs
            prunable_count = 0
            prunable_tokens = 0
            turns_from_end = 0

            for msg in reversed(self.messages):
                if msg.role == "user":
                    turns_from_end += 1

                if msg.summary:
                    break

                for part in msg.parts:
                    if not isinstance(part, ToolPart):
                        continue

                    if part.state.status != "completed":
                        continue

                    if turns_from_end < self.config.pruning.protect_turns:
                        continue

                    if part.tool in self.config.pruning.protected_tools:
                        continue

                    if part.state.time and part.state.time.compacted:
                        continue

                    tokens = count_tokens_fast(part.state.output) if part.state.output else 0
                    prunable_count += 1
                    prunable_tokens += tokens

            # Estimate how many would be pruned
            overage = projected_tokens - self.config.pruning.prune_protect
            if prunable_tokens >= overage:
                # Estimate based on average token size
                avg_tokens_per_output = (
                    prunable_tokens / prunable_count if prunable_count > 0 else 0
                )
                if avg_tokens_per_output > 0:
                    estimated_pruned_count = int(overage / avg_tokens_per_output) + 1
                    tokens_after_pruning = projected_tokens - min(overage, prunable_tokens)

        # Check if overflow would trigger
        context_limit = self.config.model_limits.default_context_limit
        output_reserve = self.config.model_limits.default_output_limit
        usable_limit = context_limit - output_reserve

        would_trigger_overflow = tokens_after_pruning >= usable_limit
        margin_remaining = usable_limit - tokens_after_pruning

        return {
            "would_trigger_pruning": would_trigger_pruning,
            "estimated_pruned_count": estimated_pruned_count,
            "would_trigger_overflow": would_trigger_overflow,
            "estimated_tokens_after_pruning": tokens_after_pruning,
            "margin_remaining": max(0, margin_remaining),
        }

    def get_audit_trail(self, limit: int = 50) -> list[dict[str, Any]]:
        """Get full audit trail of pruning decisions.

        Args:
            limit: Maximum number of decisions to return

        Returns:
            List of decision records (most recent first)
        """
        # This would return stored decisions from pruning operations
        # For now, return empty list (will be populated by manager)
        return []

    def get_tool_output_tokens(self) -> dict[str, Any]:
        """Get breakdown of tokens by tool type.

        Returns:
            Dictionary with:
            - total: Total tokens in tool outputs
            - by_tool: Token count per tool type
            - prunable: Tokens that could be pruned
            - protected: Tokens in protected outputs
            - prunability_percent: Percentage that is prunable
        """
        total = 0
        by_tool: dict[str, int] = {}
        prunable = 0
        protected = 0

        turns_from_end = 0
        for msg in reversed(self.messages):
            if msg.role == "user":
                turns_from_end += 1

            for part in msg.parts:
                if not isinstance(part, ToolPart):
                    continue

                if part.state.status != "completed":
                    continue

                if part.state.time and part.state.time.compacted:
                    continue

                tokens = count_tokens_fast(part.state.output) if part.state.output else 0
                total += tokens

                # Track by tool
                by_tool[part.tool] = by_tool.get(part.tool, 0) + tokens

                # Check if protected
                is_protected = (
                    turns_from_end < self.config.pruning.protect_turns
                    or part.tool in self.config.pruning.protected_tools
                    or msg.summary
                )

                if is_protected:
                    protected += tokens
                else:
                    prunable += tokens

        prunability_percent = round((prunable / total * 100) if total > 0 else 0, 1)

        return {
            "total": total,
            "by_tool": by_tool,
            "prunable": prunable,
            "protected": protected,
            "prunability_percent": prunability_percent,
        }
