"""Phase 3D: Cleanup and maintenance operations.

Provides background cleanup, drift detection, and quality issue identification.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Literal

from harnessutils.compaction.pruning import (
    compute_content_hash,
)
from harnessutils.config import PruningConfig
from harnessutils.models.conversation import Conversation
from harnessutils.models.message import Message
from harnessutils.tokens.exact import count_tokens_fast


@dataclass
class CleanupResult:
    """Result of cleanup operation."""

    messages_archived: int = 0
    tokens_freed: int = 0
    duplicates_removed: int = 0
    stale_outputs_pruned: int = 0
    operations: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary.

        Returns:
            Dictionary representation
        """
        return {
            "messages_archived": self.messages_archived,
            "tokens_freed": self.tokens_freed,
            "duplicates_removed": self.duplicates_removed,
            "stale_outputs_pruned": self.stale_outputs_pruned,
            "operations": self.operations,
        }


@dataclass
class ContextIssue:
    """Detected context quality issue."""

    issue_type: Literal[
        "high_redundancy",
        "staleness_accumulation",
        "low_information_density",
        "error_loss",
        "excessive_protection",
    ]
    severity: Literal["info", "warning", "error"]
    description: str
    affected_count: int = 0
    suggested_fix: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary.

        Returns:
            Dictionary representation
        """
        return {
            "issue_type": self.issue_type,
            "severity": self.severity,
            "description": self.description,
            "affected_count": self.affected_count,
            "suggested_fix": self.suggested_fix,
            "metadata": self.metadata,
        }


def cleanup_stale_data(
    messages: list[Message],
    config: PruningConfig,
    max_age_hours: float = 24,
    keep_errors: bool = True,
) -> CleanupResult:
    """Clean up stale conversation data.

    Removes or archives old messages and outputs based on age.

    Args:
        messages: Conversation messages
        config: Pruning configuration
        max_age_hours: Maximum age in hours before considering stale
        keep_errors: Whether to preserve error messages

    Returns:
        CleanupResult with statistics
    """
    result = CleanupResult()
    current_time = int(time.time() * 1000)
    max_age_ms = int(max_age_hours * 3600 * 1000)

    stale_outputs = 0
    tokens_freed = 0

    for msg in messages:
        msg_timestamp = msg.metadata.get("timestamp", current_time)
        age_ms = current_time - msg_timestamp

        # Skip if not stale
        if age_ms < max_age_ms:
            continue

        # Skip errors if keep_errors is True
        if keep_errors and msg.error:
            continue

        # Count stale tool outputs
        for part in msg.parts:
            if part.type == "tool":
                if hasattr(part, "state") and hasattr(part.state, "output"):
                    output = part.state.output
                    if output:
                        # Don't remove if it's an error and keep_errors is True
                        if keep_errors and (
                            part.state.status == "error"
                            or "error" in output.lower()
                        ):
                            continue

                        tokens = count_tokens_fast(output)
                        tokens_freed += tokens
                        stale_outputs += 1
                        # Note: Not actually removing here, just counting
                        # Actual removal would be done by caller

    result.stale_outputs_pruned = stale_outputs
    result.tokens_freed = tokens_freed
    result.operations.append(
        f"Identified {stale_outputs} stale outputs (>{max_age_hours}h old)"
    )

    return result


def scan_and_deduplicate(
    messages: list[Message],
    config: PruningConfig,
) -> CleanupResult:
    """Scan for and remove duplicate outputs.

    Args:
        messages: Conversation messages
        config: Pruning configuration

    Returns:
        CleanupResult with deduplication statistics
    """
    result = CleanupResult()

    seen_hashes: dict[str, str] = {}  # hash -> message_id
    duplicates_found = 0
    tokens_saved = 0

    for msg in messages:
        for part in msg.parts:
            if part.type != "tool":
                continue

            if not hasattr(part, "state") or not hasattr(part.state, "output"):
                continue

            output = part.state.output
            if not output:
                continue

            # Compute hash
            output_hash = compute_content_hash(output)

            # Check if duplicate
            if output_hash in seen_hashes:
                duplicates_found += 1
                tokens_saved += count_tokens_fast(output)
            else:
                seen_hashes[output_hash] = msg.id

    result.duplicates_removed = duplicates_found
    result.tokens_freed = tokens_saved
    result.operations.append(f"Found {duplicates_found} duplicate outputs")

    return result


def detect_context_issues(
    messages: list[Message],
    conversation: Conversation,
    config: PruningConfig,
) -> list[ContextIssue]:
    """Detect quality and drift issues in conversation context.

    Analyzes conversation for:
    - High redundancy (duplicates)
    - Staleness accumulation
    - Low information density
    - Error loss
    - Excessive protection

    Args:
        messages: Conversation messages
        conversation: Conversation object
        config: Pruning configuration

    Returns:
        List of detected issues
    """
    issues: list[ContextIssue] = []

    # 1. Check for high redundancy
    redundancy = _calculate_redundancy(messages)
    if redundancy > 0.25:
        issues.append(
            ContextIssue(
                issue_type="high_redundancy",
                severity="warning" if redundancy > 0.4 else "info",
                description=f"High redundancy detected: {int(redundancy * 100)}% duplicate content",
                affected_count=_count_duplicates(messages),
                suggested_fix="Run scan_and_deduplicate() to remove duplicates",
                metadata={"redundancy_ratio": redundancy},
            )
        )

    # 2. Check for staleness accumulation
    avg_age_turns = _calculate_average_age(messages)
    if avg_age_turns > 15:
        issues.append(
            ContextIssue(
                issue_type="staleness_accumulation",
                severity="info",
                description=f"Context aging: average message age is {avg_age_turns:.1f} turns",
                suggested_fix="Consider running summarization to compress old context",
                metadata={"avg_age_turns": avg_age_turns},
            )
        )

    # 3. Check information density
    density = _calculate_information_density(messages)
    if density < 0.5:
        issues.append(
            ContextIssue(
                issue_type="low_information_density",
                severity="warning",
                description=f"Low information density: {int(density * 100)}% unique content",
                suggested_fix="Run deduplication and compaction",
                metadata={"density": density},
            )
        )

    # 4. Check for error preservation
    error_count = _count_errors(messages)
    if error_count > 0:
        # Check if errors are being lost (this is informational)
        issues.append(
            ContextIssue(
                issue_type="error_loss",
                severity="info",
                description=f"{error_count} error messages in context",
                affected_count=error_count,
                suggested_fix="Ensure preserve_errors config is enabled",
                metadata={"error_count": error_count},
            )
        )

    # 5. Check for excessive protection
    protected_ratio = _calculate_protected_ratio(messages, config)
    if protected_ratio > 0.5:
        issues.append(
            ContextIssue(
                issue_type="excessive_protection",
                severity="warning",
                description=f"Excessive protection: {int(protected_ratio * 100)}% tokens protected",
                suggested_fix="Review protected_tools config - may limit pruning effectiveness",
                metadata={"protected_ratio": protected_ratio},
            )
        )

    return issues


def _calculate_redundancy(messages: list[Message]) -> float:
    """Calculate redundancy ratio (0.0-1.0).

    Args:
        messages: Conversation messages

    Returns:
        Redundancy ratio
    """
    seen_hashes: set[str] = set()
    total_outputs = 0
    duplicate_outputs = 0

    for msg in messages:
        for part in msg.parts:
            if part.type != "tool":
                continue

            if not hasattr(part, "state") or not hasattr(part.state, "output"):
                continue

            output = part.state.output
            if not output:
                continue

            total_outputs += 1
            output_hash = compute_content_hash(output)

            if output_hash in seen_hashes:
                duplicate_outputs += 1
            else:
                seen_hashes.add(output_hash)

    if total_outputs == 0:
        return 0.0

    return duplicate_outputs / total_outputs


def _count_duplicates(messages: list[Message]) -> int:
    """Count duplicate outputs.

    Args:
        messages: Conversation messages

    Returns:
        Number of duplicates
    """
    seen_hashes: set[str] = set()
    duplicates = 0

    for msg in messages:
        for part in msg.parts:
            if part.type != "tool":
                continue

            if not hasattr(part, "state") or not hasattr(part.state, "output"):
                continue

            output = part.state.output
            if not output:
                continue

            output_hash = compute_content_hash(output)
            if output_hash in seen_hashes:
                duplicates += 1
            else:
                seen_hashes.add(output_hash)

    return duplicates


def _calculate_average_age(messages: list[Message]) -> float:
    """Calculate average message age in turns.

    Args:
        messages: Conversation messages

    Returns:
        Average age in turns
    """
    if not messages:
        return 0.0

    total_turns = len(messages)
    total_age = 0.0

    for idx, msg in enumerate(messages):
        age = total_turns - idx - 1
        total_age += age

    return total_age / total_turns


def _calculate_information_density(messages: list[Message]) -> float:
    """Calculate information density (unique content ratio).

    Args:
        messages: Conversation messages

    Returns:
        Density ratio (0.0-1.0)
    """
    # Simple approximation: 1 - redundancy
    redundancy = _calculate_redundancy(messages)
    return 1.0 - redundancy


def _count_errors(messages: list[Message]) -> int:
    """Count error messages.

    Args:
        messages: Conversation messages

    Returns:
        Number of error messages
    """
    error_count = 0

    for msg in messages:
        if msg.error:
            error_count += 1
            continue

        # Check tool outputs for errors
        for part in msg.parts:
            if part.type != "tool":
                continue

            if hasattr(part, "state"):
                if part.state.status == "error":
                    error_count += 1
                    break

                output = getattr(part.state, "output", "")
                if output and "error" in output.lower():
                    error_count += 1
                    break

    return error_count


def _calculate_protected_ratio(
    messages: list[Message], config: PruningConfig
) -> float:
    """Calculate ratio of protected tokens.

    Args:
        messages: Conversation messages
        config: Pruning configuration

    Returns:
        Protected ratio (0.0-1.0)
    """
    total_tokens = 0
    protected_tokens = 0
    turns_skipped = 0

    for msg in reversed(messages):
        if msg.role == "user":
            turns_skipped += 1

        for part in msg.parts:
            if part.type != "tool":
                continue

            if not hasattr(part, "state") or not hasattr(part.state, "output"):
                continue

            output = part.state.output
            if not output:
                continue

            tokens = count_tokens_fast(output)
            total_tokens += tokens

            # Check if protected
            tool = getattr(part, "tool", "")
            is_protected = (
                turns_skipped < config.protect_turns or tool in config.protected_tools
            )

            if is_protected:
                protected_tokens += tokens

    if total_tokens == 0:
        return 0.0

    return protected_tokens / total_tokens
