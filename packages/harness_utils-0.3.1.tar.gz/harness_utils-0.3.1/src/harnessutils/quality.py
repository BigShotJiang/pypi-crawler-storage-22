"""Phase 3B: Quality metrics for context health tracking.

Calculates and tracks quality metrics over time to assess context health
and provide actionable recommendations.
"""

import time
from dataclasses import dataclass, field
from typing import Any, cast

from harnessutils.compaction.pruning import (
    PruningDecision,
    generate_shingles,
)
from harnessutils.config import PruningConfig
from harnessutils.models.message import Message
from harnessutils.models.parts import ToolPart
from harnessutils.tokens.exact import count_tokens_fast


@dataclass
class QualitySnapshot:
    """Single quality measurement at a point in time."""

    timestamp: int  # Unix ms
    information_density: float  # 0.0-1.0, unique info / total tokens
    redundancy_ratio: float  # 0.0-1.0, duplicate tokens / total tokens
    staleness_score: float  # 0.0-1.0, avg age-weighted decay
    error_preservation_rate: float  # 0.0-1.0, errors kept / total errors
    protected_ratio: float  # 0.0-1.0, protected tokens / total tokens
    health: str  # "good" | "degraded" | "poor"
    recommendations: list[str]  # Actionable suggestions

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for storage.

        Returns:
            Dictionary representation
        """
        return {
            "timestamp": self.timestamp,
            "information_density": self.information_density,
            "redundancy_ratio": self.redundancy_ratio,
            "staleness_score": self.staleness_score,
            "error_preservation_rate": self.error_preservation_rate,
            "protected_ratio": self.protected_ratio,
            "health": self.health,
            "recommendations": self.recommendations,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "QualitySnapshot":
        """Create from dictionary.

        Args:
            data: Dictionary representation

        Returns:
            QualitySnapshot instance
        """
        return cls(
            timestamp=data["timestamp"],
            information_density=data["information_density"],
            redundancy_ratio=data["redundancy_ratio"],
            staleness_score=data["staleness_score"],
            error_preservation_rate=data["error_preservation_rate"],
            protected_ratio=data["protected_ratio"],
            health=data["health"],
            recommendations=data["recommendations"],
        )


@dataclass
class QualityHistory:
    """Time-series tracking of quality metrics."""

    snapshots: list[QualitySnapshot] = field(default_factory=list)
    max_snapshots: int = 50  # Keep last 50 measurements

    def add_snapshot(self, snapshot: QualitySnapshot) -> None:
        """Add quality snapshot to history.

        Prepends new snapshot and trims to max_snapshots.

        Args:
            snapshot: Quality snapshot to add
        """
        self.snapshots.insert(0, snapshot)

        # Trim to max_snapshots
        if len(self.snapshots) > self.max_snapshots:
            self.snapshots = self.snapshots[: self.max_snapshots]

    def get_trend(self, metric_name: str, window: int = 20) -> list[tuple[int, float]]:
        """Extract trend data for a specific metric.

        Args:
            metric_name: Name of metric to extract
            window: Number of most recent snapshots to return

        Returns:
            List of (timestamp, value) tuples, most recent first
        """
        trend_data = []

        for snapshot in self.snapshots[:window]:
            value = getattr(snapshot, metric_name, None)
            if value is not None:
                trend_data.append((snapshot.timestamp, value))

        return trend_data

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for storage.

        Returns:
            Dictionary representation
        """
        return {
            "snapshots": [s.to_dict() for s in self.snapshots],
            "max_snapshots": self.max_snapshots,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "QualityHistory":
        """Create from dictionary.

        Args:
            data: Dictionary representation

        Returns:
            QualityHistory instance
        """
        snapshots = [QualitySnapshot.from_dict(s) for s in data.get("snapshots", [])]
        return cls(
            snapshots=snapshots,
            max_snapshots=data.get("max_snapshots", 50),
        )


def calculate_information_density(messages: list[Message]) -> float:
    """Calculate unique information ratio using shingling.

    Strategy:
    1. Extract all tool outputs
    2. Generate 5-word shingles for each output
    3. Calculate total unique shingles / total shingles
    4. Return ratio (1.0 = all unique, 0.0 = all duplicate)

    Args:
        messages: Conversation messages

    Returns:
        Information density ratio (0.0-1.0)
    """
    unique_shingles = set()
    total_shingles = 0

    for msg in messages:
        for part in msg.parts:
            if part.type != "tool":
                continue

            tool_part = cast(ToolPart, part)
            output = getattr(tool_part.state, "output", "")
            if not output:
                continue

            # Generate 5-word shingles
            shingles = generate_shingles(output, n=5)

            # Count unique shingles
            unique_shingles.update(shingles)

            # Count total shingles (including duplicates across outputs)
            total_shingles += len(shingles)

    if total_shingles == 0:
        return 1.0  # No outputs = perfect density

    return len(unique_shingles) / total_shingles


def calculate_redundancy_ratio(
    messages: list[Message], config: PruningConfig
) -> float:
    """Calculate duplicate content ratio.

    Strategy:
    1. Run find_duplicate_output() for each output
    2. Count tokens in duplicates
    3. Return duplicate_tokens / total_tokens

    Args:
        messages: Conversation messages
        config: Pruning config for duplicate detection

    Returns:
        Redundancy ratio (0.0-1.0)
    """
    from harnessutils.compaction.pruning import compute_content_hash

    duplicate_tokens = 0
    total_tokens = 0

    # Build list of all tool parts with outputs
    tool_parts: list[tuple[ToolPart, str, int]] = []  # (part, output, tokens)
    for msg in messages:
        for part in msg.parts:
            if part.type == "tool":
                tool_part = cast(ToolPart, part)
                output = getattr(tool_part.state, "output", "")
                if output:
                    tokens = count_tokens_fast(output)
                    tool_parts.append((tool_part, output, tokens))
                    total_tokens += tokens

    # Check each output for duplicates using content hash
    seen_hashes: dict[str, int] = {}  # hash -> first occurrence index

    for i, (part, output, tokens) in enumerate(tool_parts):
        output_hash = compute_content_hash(output)

        # Check if we've seen this exact output before (within lookback)
        if output_hash in seen_hashes:
            first_idx = seen_hashes[output_hash]
            if i - first_idx <= config.duplicate_lookback:
                # Within lookback window - count as duplicate
                duplicate_tokens += tokens
        else:
            # First time seeing this output
            seen_hashes[output_hash] = i

    if total_tokens == 0:
        return 0.0  # No outputs = no redundancy

    return duplicate_tokens / total_tokens


def calculate_staleness_score(messages: list[Message]) -> float:
    """Calculate age-weighted staleness.

    Strategy:
    1. For each message, calculate age in turns
    2. Apply exponential decay: exp(-age * 0.1)
    3. Weight by token count
    4. Return weighted average (0.0 = fresh, 1.0 = stale)

    Args:
        messages: Conversation messages

    Returns:
        Staleness score (0.0-1.0, lower is fresher)
    """
    import math

    if not messages:
        return 0.0

    total_tokens = 0
    weighted_staleness = 0.0
    total_turns = len(messages)

    for turn_idx, msg in enumerate(messages):
        msg_tokens = msg.tokens.total if msg.tokens else 0

        if msg_tokens == 0:
            continue

        # Age in turns (0 for most recent)
        age = total_turns - turn_idx - 1

        # Exponential decay: exp(-age * 0.1)
        # Inverted to staleness: 1 - exp(-age * 0.1)
        freshness = math.exp(-age * 0.1)
        staleness = 1.0 - freshness

        weighted_staleness += staleness * msg_tokens
        total_tokens += msg_tokens

    if total_tokens == 0:
        return 0.0

    return weighted_staleness / total_tokens


def calculate_error_preservation_rate(
    messages: list[Message],
    decisions: list[PruningDecision] | None = None,
) -> float:
    """Calculate ratio of errors still in context.

    Strategy:
    1. Count total error outputs (status="error" or output contains "error"/"exception")
    2. Count error outputs with decision="kept"
    3. Return kept_errors / total_errors (1.0 if no errors exist)

    Args:
        messages: Conversation messages
        decisions: Optional pruning decisions

    Returns:
        Error preservation rate (0.0-1.0)
    """
    total_errors = 0
    kept_errors = 0

    # Build error detection
    error_keywords = ["error", "exception", "traceback", "failed"]

    for msg in messages:
        for part in msg.parts:
            if part.type != "tool":
                continue

            tool_part = cast(ToolPart, part)
            # Check if error
            is_error = False
            status = getattr(tool_part.state, "status", "")
            output = getattr(tool_part.state, "output", "")

            if status == "error":
                is_error = True
            else:
                # Check output for error keywords
                output_lower = output.lower()
                if any(keyword in output_lower for keyword in error_keywords):
                    is_error = True

            if not is_error:
                continue

            total_errors += 1

            # If decisions available, check if kept
            if decisions:
                # Find decision for this output
                call_id = getattr(tool_part, "call_id", None)
                if call_id:
                    for decision in decisions:
                        if decision.part_id == call_id and decision.decision == "kept":
                            kept_errors += 1
                            break
                else:
                    # No decision info, assume kept if still in messages
                    kept_errors += 1
            else:
                # No decisions = all errors still present
                kept_errors += 1

    if total_errors == 0:
        return 1.0  # No errors = perfect preservation

    return kept_errors / total_errors


def calculate_protected_ratio(messages: list[Message], config: PruningConfig) -> float:
    """Calculate ratio of protected tokens.

    Strategy:
    1. Count tool output tokens and determine protection status
    2. Return protected_tokens / total_tokens

    Args:
        messages: Conversation messages
        config: Pruning config

    Returns:
        Protected ratio (0.0-1.0)
    """
    total_tokens = 0
    protected_tokens = 0
    turns_skipped = 0

    for msg in reversed(messages):
        if msg.role == "user":
            turns_skipped += 1

        for part in msg.parts:
            if part.type != "tool":
                continue

            tool_part = cast(ToolPart, part)
            output = getattr(tool_part.state, "output", "")
            if not output:
                continue

            tokens = count_tokens_fast(output)
            total_tokens += tokens

            # Check protection status
            tool = tool_part.tool
            is_protected = (
                turns_skipped < config.protect_turns
                or tool in config.protected_tools
            )

            if is_protected:
                protected_tokens += tokens

    if total_tokens == 0:
        return 0.0

    return protected_tokens / total_tokens


def calculate_health(snapshot: QualitySnapshot) -> str:
    """Classify health based on metric thresholds.

    Thresholds:
    - "good": density > 0.7, redundancy < 0.2, staleness < 0.3, error_rate > 0.9
    - "poor": density < 0.5, redundancy > 0.4, staleness > 0.5, error_rate < 0.7
    - "degraded": everything else

    Args:
        snapshot: Quality snapshot to classify

    Returns:
        Health classification
    """
    # Good thresholds
    is_good = (
        snapshot.information_density > 0.7
        and snapshot.redundancy_ratio < 0.2
        and snapshot.staleness_score < 0.3
        and snapshot.error_preservation_rate > 0.9
    )

    if is_good:
        return "good"

    # Poor thresholds
    is_poor = (
        snapshot.information_density < 0.5
        or snapshot.redundancy_ratio > 0.4
        or snapshot.staleness_score > 0.5
        or snapshot.error_preservation_rate < 0.7
    )

    if is_poor:
        return "poor"

    return "degraded"


def generate_recommendations(snapshot: QualitySnapshot) -> list[str]:
    """Generate actionable recommendations.

    Rules:
    - redundancy > 0.2: "Consider deduplication - {X}% redundancy"
    - protected_ratio > 0.4: "Protected ratio high - may limit pruning"
    - staleness > 0.4: "Context aging - consider summarization"
    - error_rate < 0.8: "Error messages being lost - check pruning config"
    - density < 0.6: "Low information density - run compaction"

    Args:
        snapshot: Quality snapshot

    Returns:
        List of recommendations
    """
    recommendations = []

    if snapshot.redundancy_ratio > 0.2:
        pct = int(snapshot.redundancy_ratio * 100)
        recommendations.append(f"Consider deduplication - {pct}% redundancy")

    if snapshot.protected_ratio > 0.4:
        recommendations.append("Protected ratio high - may limit pruning")

    if snapshot.staleness_score > 0.4:
        recommendations.append("Context aging - consider summarization")

    if snapshot.error_preservation_rate < 0.8:
        recommendations.append("Error messages being lost - check pruning config")

    if snapshot.information_density < 0.6:
        recommendations.append("Low information density - run compaction")

    return recommendations


def assess_quality(
    messages: list[Message],
    config: PruningConfig,
    decisions: list[PruningDecision] | None = None,
) -> QualitySnapshot:
    """Calculate all quality metrics and generate assessment.

    Args:
        messages: Conversation messages
        config: Pruning config for thresholds
        decisions: Optional pruning decisions for error tracking

    Returns:
        Complete quality snapshot
    """
    snapshot = QualitySnapshot(
        timestamp=int(time.time() * 1000),
        information_density=calculate_information_density(messages),
        redundancy_ratio=calculate_redundancy_ratio(messages, config),
        staleness_score=calculate_staleness_score(messages),
        error_preservation_rate=calculate_error_preservation_rate(
            messages, decisions
        ),
        protected_ratio=calculate_protected_ratio(messages, config),
        health="",  # Set below
        recommendations=[],  # Set below
    )

    snapshot.health = calculate_health(snapshot)
    snapshot.recommendations = generate_recommendations(snapshot)

    return snapshot
