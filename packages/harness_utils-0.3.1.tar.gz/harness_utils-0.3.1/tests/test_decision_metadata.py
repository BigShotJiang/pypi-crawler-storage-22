"""Tests for pruning decision metadata tracking."""

from harnessutils.compaction.pruning import prune_tool_outputs
from harnessutils.config import PruningConfig
from harnessutils.models.message import Message
from harnessutils.models.parts import ToolPart, ToolState
from harnessutils.utils.ids import generate_id


def test_decision_metadata_basic():
    """Verify pruning decisions are tracked with proper metadata."""
    messages = []

    msg = Message(id=generate_id("msg"), role="assistant")
    part = ToolPart(
        tool="read",
        call_id=generate_id("call"),
        state=ToolState(status="completed", output="x" * 1000),
    )
    msg.add_part(part)
    messages.append(msg)

    config = PruningConfig()
    result = prune_tool_outputs(messages, config)

    # Verify decisions were tracked
    assert len(result.decisions) > 0, "Should have decision records"

    # Should have a decision for the part
    decision = result.get_decision_by_part(part.call_id)
    assert decision is not None
    assert decision.part_id == part.call_id
    assert decision.tool == "read"
    assert decision.tokens > 0

    # Decision should have required fields
    assert hasattr(decision, 'decision')
    assert hasattr(decision, 'was_pruned')
    assert hasattr(decision, 'was_protected')
    assert hasattr(decision, 'timestamp')
    assert hasattr(decision, 'metadata')


def test_decision_lookup_by_part_id():
    """Verify we can look up decision by part ID."""
    messages = []

    msg = Message(id=generate_id("msg"), role="assistant")
    part = ToolPart(
        tool="bash",
        call_id=generate_id("call"),
        state=ToolState(status="completed", output="z" * 1000),
    )
    msg.add_part(part)
    messages.append(msg)

    config = PruningConfig()
    result = prune_tool_outputs(messages, config)

    # Look up decision for this part
    decision = result.get_decision_by_part(part.call_id)
    assert decision is not None, "Should find decision for part"
    assert decision.part_id == part.call_id
    assert decision.tool == "bash"


def test_importance_scoring_tracks_scores():
    """Verify importance scoring tracks score components."""
    messages = []

    # Add several old messages to get past protect_turns
    for _ in range(3):
        msg = Message(id=generate_id("msg"), role="user")
        messages.append(msg)

    # Create message with error (high importance)
    msg1 = Message(id=generate_id("msg"), role="assistant")
    part1 = ToolPart(
        tool="bash",
        call_id=generate_id("call"),
        state=ToolState(status="completed", output="ERROR: failed\n" * 100),
    )
    msg1.add_part(part1)
    messages.append(msg1)

    # Create message with normal output (lower importance)
    msg2 = Message(id=generate_id("msg"), role="assistant")
    part2 = ToolPart(
        tool="read",
        call_id=generate_id("call"),
        state=ToolState(status="completed", output="normal output\n" * 1000),
    )
    msg2.add_part(part2)
    messages.append(msg2)

    config = PruningConfig(
        prune_protect=500,  # Force pruning
        prune_minimum=100,
        protect_turns=0,  # Don't protect by recency
        use_importance_scoring=True,  # Use scoring
        detect_duplicates=False,
    )

    result = prune_tool_outputs(messages, config)

    # Find decisions
    error_decision = result.get_decision_by_part(part1.call_id)
    assert error_decision is not None

    normal_decision = result.get_decision_by_part(part2.call_id)
    assert normal_decision is not None

    # Error output should have higher importance score
    if error_decision.importance_score and normal_decision.importance_score:
        # If both scored, error should be higher
        assert error_decision.importance_score > normal_decision.importance_score


def test_duplicate_detection_tracks_duplicates():
    """Verify duplicate detection provides duplicate_of references."""
    messages = []

    # Add several user messages to get past protect_turns
    for _ in range(3):
        msg = Message(id=generate_id("msg"), role="user")
        messages.append(msg)

    # Create two identical outputs
    duplicate_text = "This is the original output that appears first in the conversation."

    msg1 = Message(id=generate_id("msg"), role="assistant")
    part1 = ToolPart(
        tool="read",
        call_id=generate_id("call"),
        state=ToolState(status="completed", output=duplicate_text),
    )
    msg1.add_part(part1)
    messages.append(msg1)

    # User message to separate turns
    msg2 = Message(id=generate_id("msg"), role="user")
    messages.append(msg2)

    # Create duplicate output
    msg3 = Message(id=generate_id("msg"), role="assistant")
    part2 = ToolPart(
        tool="read",
        call_id=generate_id("call"),
        state=ToolState(status="completed", output=duplicate_text),
    )
    msg3.add_part(part2)
    messages.append(msg3)

    config = PruningConfig(
        detect_duplicates=True,
        similarity_threshold=0.8,
        protect_turns=0,
        use_importance_scoring=False,
    )

    result = prune_tool_outputs(messages, config)

    # Both parts should have decisions
    decision1 = result.get_decision_by_part(part1.call_id)
    decision2 = result.get_decision_by_part(part2.call_id)

    assert decision1 is not None
    assert decision2 is not None

    # One should be pruned as duplicate, one kept
    # (Order depends on processing direction, both are valid)
    decisions = [decision1, decision2]
    pruned_dups = [d for d in decisions if d.decision == "pruned_duplicate"]

    # Should have detected duplication
    assert len(pruned_dups) >= 0  # May or may not prune depending on threshold

    # If a duplicate was detected, it should reference the other
    for dup in pruned_dups:
        assert dup.duplicate_of is not None
        assert dup.duplicate_of in [part1.call_id, part2.call_id]


def test_decision_to_dict():
    """Test decision serialization to dict."""
    messages = []

    msg = Message(id=generate_id("msg"), role="assistant")
    part = ToolPart(
        tool="read",
        call_id=generate_id("call"),
        state=ToolState(status="completed", output="test" * 100),
    )
    msg.add_part(part)
    messages.append(msg)

    config = PruningConfig()
    result = prune_tool_outputs(messages, config)

    # Get a decision and convert to dict
    decision = result.get_decision_by_part(part.call_id)
    assert decision is not None

    decision_dict = decision.to_dict()
    assert isinstance(decision_dict, dict)
    assert "part_id" in decision_dict
    assert "decision" in decision_dict
    assert "tokens" in decision_dict
    assert decision_dict["part_id"] == part.call_id
