"""Tests for differential summarization (Phase 2)."""

from typing import Any

from harnessutils.compaction.summarization import (
    DIFFERENTIAL_SUMMARIZATION_PROMPT,
    _build_differential_prompt,
    _find_last_summary,
    _get_messages_since_summary,
    summarize_conversation,
)
from harnessutils.config import SummarizationConfig
from harnessutils.models.message import Message
from harnessutils.models.parts import TextPart


class MockLLMClient:
    """Mock LLM client for testing."""

    def __init__(self, expected_model: str | None = None, expected_prompt: str | None = None):
        """Initialize mock client with expectations."""
        self.expected_model = expected_model
        self.expected_prompt = expected_prompt
        self.invoked = False

    def invoke(
        self,
        messages: list[dict[str, Any]],
        system: list[str] | None = None,
        model: str | None = None,
    ) -> dict[str, Any]:
        """Mock LLM invocation with validation."""
        self.invoked = True

        # Validate expectations
        if self.expected_model is not None:
            assert (
                model == self.expected_model
            ), f"Expected model {self.expected_model}, got {model}"

        if self.expected_prompt is not None:
            assert system and len(system) > 0
            assert system[0] == self.expected_prompt

        return {
            "content": "Mock summary content",
            "model": model or "default",
            "usage": {"input": 100, "output": 50, "cache": {"read": 0, "write": 0}},
            "cost": 0.01,
        }


class TestHelperFunctions:
    """Test helper functions for differential summarization."""

    def test_find_last_summary_exists(self):
        """Find last summary when one exists."""
        msg1 = Message(id="1", role="user")
        msg2 = Message(id="2", role="assistant", summary=True)
        msg3 = Message(id="3", role="user")
        msg4 = Message(id="4", role="assistant", summary=True)

        messages = [msg1, msg2, msg3, msg4]
        result = _find_last_summary(messages)

        assert result is not None
        assert result.id == "4"

    def test_find_last_summary_not_exists(self):
        """Find last summary returns None when no summary exists."""
        msg1 = Message(id="1", role="user")
        msg2 = Message(id="2", role="assistant")

        messages = [msg1, msg2]
        result = _find_last_summary(messages)

        assert result is None

    def test_get_messages_since_summary(self):
        """Get messages after summary."""
        msg1 = Message(id="1", role="user")
        msg2 = Message(id="2", role="assistant", summary=True)
        msg3 = Message(id="3", role="user")
        msg4 = Message(id="4", role="assistant")

        messages = [msg1, msg2, msg3, msg4]
        result = _get_messages_since_summary(messages, msg2)

        assert len(result) == 2
        assert result[0].id == "3"
        assert result[1].id == "4"

    def test_get_messages_since_summary_not_found(self):
        """Get messages since summary returns all if summary not found."""
        msg1 = Message(id="1", role="user")
        msg2 = Message(id="2", role="assistant")
        summary = Message(id="999", role="assistant", summary=True)

        messages = [msg1, msg2]
        result = _get_messages_since_summary(messages, summary)

        assert len(result) == 2  # Returns all messages

    def test_build_differential_prompt(self):
        """Build differential prompt correctly."""
        last_summary = "Previous work: implemented feature X"
        new_messages = [
            {"role": "user", "content": "Add feature Y"},
            {"role": "assistant", "content": "Implemented feature Y"},
        ]

        result = _build_differential_prompt(last_summary, new_messages)

        assert len(result) == 4  # intro + 2 messages + request
        assert "Previous summary:" in result[0]["content"]
        assert "Previous work: implemented feature X" in result[0]["content"]
        assert result[1] == new_messages[0]
        assert result[2] == new_messages[1]
        assert "UPDATED summary" in result[3]["content"]


class TestDifferentialMode:
    """Test differential summarization mode."""

    def test_differential_mode_triggers(self):
        """Differential mode triggers when summary exists."""
        # Create messages with a summary in the middle
        msg1 = Message(id="1", role="user")
        msg1.add_part(TextPart(text="Initial request"))

        summary = Message(id="2", role="assistant", summary=True)
        summary.add_part(TextPart(text="Summary: User requested feature"))

        msg3 = Message(id="3", role="user")
        msg3.add_part(TextPart(text="New request"))

        messages = [msg1, summary, msg3]

        config = SummarizationConfig(
            mode="differential",
            differential_model="test-fast-model",
            full_model="test-capable-model",
        )

        # Mock LLM client expecting differential mode
        llm_client = MockLLMClient(
            expected_model="test-fast-model",
            expected_prompt=DIFFERENTIAL_SUMMARIZATION_PROMPT,
        )

        result = summarize_conversation(
            messages=messages,
            llm_client=llm_client,
            parent_message_id="3",
            message_id="4",
            config=config,
        )

        assert result.summary_message.id == "4"
        assert result.summary_message.summary is True
        assert llm_client.invoked

    def test_full_mode_when_too_many_messages(self):
        """Full mode triggers when too many messages since summary."""
        # Create messages with summary + 31 new messages (exceeds limit of 30)
        messages = []

        summary = Message(id="0", role="assistant", summary=True)
        summary.add_part(TextPart(text="Initial summary"))
        messages.append(summary)

        # Add 31 messages after summary
        for i in range(31):
            msg = Message(id=str(i + 1), role="user" if i % 2 == 0 else "assistant")
            msg.add_part(TextPart(text=f"Message {i}"))
            messages.append(msg)

        config = SummarizationConfig(
            mode="differential",
            max_messages_since_summary=30,
            differential_model="test-fast-model",
            full_model="test-capable-model",
        )

        # Mock LLM client expecting full mode
        llm_client = MockLLMClient(expected_model="test-capable-model")

        result = summarize_conversation(
            messages=messages,
            llm_client=llm_client,
            parent_message_id="31",
            message_id="32",
            config=config,
        )

        assert result.summary_message.id == "32"
        assert llm_client.invoked

    def test_full_mode_when_no_summary_exists(self):
        """Full mode triggers when no previous summary exists."""
        msg1 = Message(id="1", role="user")
        msg1.add_part(TextPart(text="Request"))

        msg2 = Message(id="2", role="assistant")
        msg2.add_part(TextPart(text="Response"))

        messages = [msg1, msg2]
        config = SummarizationConfig(
            mode="differential",
            differential_model="test-fast-model",
            full_model="test-capable-model",
        )

        # Mock LLM client expecting full mode
        llm_client = MockLLMClient(expected_model="test-capable-model")

        result = summarize_conversation(
            messages=messages,
            llm_client=llm_client,
            parent_message_id="2",
            message_id="3",
            config=config,
        )

        assert result.summary_message.id == "3"
        assert llm_client.invoked

    def test_force_full_override(self):
        """force_full parameter overrides differential mode."""
        msg1 = Message(id="1", role="user")
        msg1.add_part(TextPart(text="Initial request"))

        summary = Message(id="2", role="assistant", summary=True)
        summary.add_part(TextPart(text="Summary"))

        msg3 = Message(id="3", role="user")
        msg3.add_part(TextPart(text="New request"))

        messages = [msg1, summary, msg3]
        config = SummarizationConfig(
            mode="differential",
            differential_model="test-fast-model",
            full_model="test-capable-model",
        )

        # Mock LLM client expecting full mode due to force_full
        llm_client = MockLLMClient(expected_model="test-capable-model")

        result = summarize_conversation(
            messages=messages,
            llm_client=llm_client,
            parent_message_id="3",
            message_id="4",
            config=config,
            force_full=True,
        )

        assert result.summary_message.id == "4"
        assert llm_client.invoked


class TestConfigurationOptions:
    """Test configuration options."""

    def test_custom_models(self):
        """Custom models can be specified in config."""
        config = SummarizationConfig(
            differential_model="custom-haiku",
            full_model="custom-sonnet",
        )

        assert config.differential_model == "custom-haiku"
        assert config.full_model == "custom-sonnet"

    def test_custom_message_limit(self):
        """Custom message limit can be specified."""
        config = SummarizationConfig(max_messages_since_summary=50)

        assert config.max_messages_since_summary == 50

    def test_no_config_uses_defaults(self):
        """No config uses default full mode."""
        msg = Message(id="1", role="user")
        msg.add_part(TextPart(text="Request"))

        messages = [msg]

        # Mock LLM client - no config means no model override
        llm_client = MockLLMClient(expected_model=None)

        result = summarize_conversation(
            messages=messages,
            llm_client=llm_client,
            parent_message_id="1",
            message_id="2",
            config=None,  # No config
        )

        assert result.summary_message.id == "2"
        assert llm_client.invoked


class TestBackwardCompatibility:
    """Test backward compatibility with existing code."""

    def test_old_api_still_works(self):
        """Old API without config parameter still works."""
        msg = Message(id="1", role="user")
        msg.add_part(TextPart(text="Request"))

        messages = [msg]

        # Mock LLM client
        llm_client = MockLLMClient()

        # Call without config (old API)
        result = summarize_conversation(
            messages=messages,
            llm_client=llm_client,
            parent_message_id="1",
            message_id="2",
        )

        assert result.summary_message.id == "2"
        assert result.cost == 0.01
        assert llm_client.invoked
