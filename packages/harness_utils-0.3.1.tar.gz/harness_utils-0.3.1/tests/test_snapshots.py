"""Tests for context snapshot functionality."""

import json
import tempfile
from pathlib import Path

from harnessutils import ConversationManager
from harnessutils.models.message import Message
from harnessutils.models.parts import TextPart, ToolPart, ToolState
from harnessutils.utils.ids import generate_id


def test_create_snapshot_basic():
    """Test basic snapshot creation."""
    manager = ConversationManager()
    conv = manager.create_conversation()

    # Add a message
    msg = Message(id=generate_id("msg"), role="user")
    msg.add_part(TextPart(text="Hello"))
    manager.add_message(conv.id, msg)

    # Create snapshot
    snapshot = manager.create_snapshot(conv.id)

    assert snapshot is not None
    assert snapshot.conversation_id == conv.id
    assert snapshot.snapshot_id is not None
    assert len(snapshot.messages) == 1
    assert snapshot.timestamp > 0


def test_snapshot_with_metadata():
    """Test snapshot with custom metadata."""
    manager = ConversationManager()
    conv = manager.create_conversation()

    snapshot = manager.create_snapshot(
        conv.id,
        metadata={"reason": "test_baseline", "version": "1.0"}
    )

    assert snapshot.metadata["reason"] == "test_baseline"
    assert snapshot.metadata["version"] == "1.0"


def test_restore_snapshot():
    """Test restoring conversation from snapshot."""
    manager = ConversationManager()
    conv = manager.create_conversation()

    # Add messages
    msg1 = Message(id=generate_id("msg"), role="user")
    msg1.add_part(TextPart(text="First message"))
    manager.add_message(conv.id, msg1)

    msg2 = Message(id=generate_id("msg"), role="assistant")
    msg2.add_part(TextPart(text="Response"))
    manager.add_message(conv.id, msg2)

    # Create snapshot
    snapshot = manager.create_snapshot(conv.id)

    # Add more messages
    msg3 = Message(id=generate_id("msg"), role="user")
    msg3.add_part(TextPart(text="Third message"))
    manager.add_message(conv.id, msg3)

    assert len(manager.get_messages(conv.id)) == 3

    # Restore snapshot
    restored_conv_id = manager.restore_snapshot(snapshot.snapshot_id)

    assert restored_conv_id == conv.id

    # Should have original 2 messages
    restored_messages = manager.get_messages(restored_conv_id)
    assert len(restored_messages) == 2
    # Check that correct messages are present (order may vary due to alphabetic sort)
    restored_ids = {msg.id for msg in restored_messages}
    assert msg1.id in restored_ids
    assert msg2.id in restored_ids
    assert msg3.id not in restored_ids


def test_compare_snapshots():
    """Test comparing two snapshots."""
    manager = ConversationManager()
    conv = manager.create_conversation()

    # Add initial message
    msg1 = Message(id=generate_id("msg"), role="user")
    msg1.add_part(TextPart(text="Initial"))
    manager.add_message(conv.id, msg1)

    # Create first snapshot
    snap1 = manager.create_snapshot(conv.id)

    # Add more messages
    msg2 = Message(id=generate_id("msg"), role="assistant")
    msg2.add_part(TextPart(text="Response"))
    manager.add_message(conv.id, msg2)

    msg3 = Message(id=generate_id("msg"), role="user")
    msg3.add_part(TextPart(text="Follow-up"))
    manager.add_message(conv.id, msg3)

    # Create second snapshot
    snap2 = manager.create_snapshot(conv.id)

    # Compare
    diff = manager.compare_snapshots(snap1.snapshot_id, snap2.snapshot_id)

    assert diff is not None
    assert diff.messages_added == 2
    assert diff.messages_removed == 0
    assert len(diff.message_changes) > 0


def test_export_import_snapshot():
    """Test exporting and importing snapshots to/from JSON."""
    manager = ConversationManager()
    conv = manager.create_conversation()

    # Add message
    msg = Message(id=generate_id("msg"), role="user")
    msg.add_part(TextPart(text="Test message"))
    manager.add_message(conv.id, msg)

    # Create snapshot
    original_snap = manager.create_snapshot(conv.id, metadata={"test": "export"})

    # Export to temp file
    with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".json") as f:
        temp_path = f.name

    try:
        manager.export_snapshot(original_snap.snapshot_id, temp_path)

        # Verify file exists and is valid JSON
        assert Path(temp_path).exists()

        with open(temp_path) as f:
            data = json.load(f)

        assert data["snapshot_id"] == original_snap.snapshot_id
        assert data["metadata"]["test"] == "export"

        # Import into new manager
        manager2 = ConversationManager()
        imported_snap = manager2.import_snapshot(temp_path)

        assert imported_snap.snapshot_id == original_snap.snapshot_id
        assert imported_snap.conversation_id == original_snap.conversation_id
        assert len(imported_snap.messages) == len(original_snap.messages)
        assert imported_snap.metadata["test"] == "export"

    finally:
        # Cleanup
        Path(temp_path).unlink()


def test_snapshot_with_tool_outputs():
    """Test snapshot preserves tool outputs."""
    manager = ConversationManager()
    conv = manager.create_conversation()

    # Add message with tool output
    msg = Message(id=generate_id("msg"), role="assistant")
    part = ToolPart(
        tool="read",
        call_id=generate_id("call"),
        state=ToolState(status="completed", output="File contents here"),
    )
    msg.add_part(part)
    manager.add_message(conv.id, msg)

    # Create snapshot
    snapshot = manager.create_snapshot(conv.id)

    # Verify tool output is preserved
    assert len(snapshot.messages) == 1
    msg_data = snapshot.messages[0]
    assert len(msg_data["parts"]) == 1
    part_data = msg_data["parts"][0]
    assert part_data["tool"] == "read"
    assert part_data["state"]["output"] == "File contents here"


def test_snapshot_manager_list_snapshots():
    """Test listing snapshots for a conversation."""
    manager = ConversationManager()
    conv1 = manager.create_conversation()
    conv2 = manager.create_conversation()

    # Create snapshots
    snap1 = manager.create_snapshot(conv1.id)
    snap2 = manager.create_snapshot(conv1.id)
    snap3 = manager.create_snapshot(conv2.id)

    # List all snapshots for conv1
    conv1_snaps = manager.snapshot_manager.list_snapshots(conv1.id)

    assert len(conv1_snaps) == 2
    assert snap1.snapshot_id in [s.snapshot_id for s in conv1_snaps]
    assert snap2.snapshot_id in [s.snapshot_id for s in conv1_snaps]
    assert snap3.snapshot_id not in [s.snapshot_id for s in conv1_snaps]


def test_snapshot_manager_delete_snapshot():
    """Test deleting a snapshot."""
    manager = ConversationManager()
    conv = manager.create_conversation()

    snapshot = manager.create_snapshot(conv.id)

    # Verify snapshot exists
    assert manager.snapshot_manager.get_snapshot(snapshot.snapshot_id) is not None

    # Delete snapshot
    deleted = manager.snapshot_manager.delete_snapshot(snapshot.snapshot_id)

    assert deleted is True
    assert manager.snapshot_manager.get_snapshot(snapshot.snapshot_id) is None


def test_snapshot_serialization():
    """Test snapshot to_dict and from_dict."""
    manager = ConversationManager()
    conv = manager.create_conversation()

    msg = Message(id=generate_id("msg"), role="user")
    msg.add_part(TextPart(text="Test"))
    manager.add_message(conv.id, msg)

    original = manager.create_snapshot(conv.id)

    # Serialize and deserialize
    data = original.to_dict()
    from harnessutils.snapshots import Snapshot

    restored = Snapshot.from_dict(data)

    assert restored.snapshot_id == original.snapshot_id
    assert restored.conversation_id == original.conversation_id
    assert restored.timestamp == original.timestamp
    assert len(restored.messages) == len(original.messages)


def test_snapshot_comparison_no_changes():
    """Test comparing identical snapshots."""
    manager = ConversationManager()
    conv = manager.create_conversation()

    msg = Message(id=generate_id("msg"), role="user")
    msg.add_part(TextPart(text="Same"))
    manager.add_message(conv.id, msg)

    snap1 = manager.create_snapshot(conv.id)
    snap2 = manager.create_snapshot(conv.id)  # Same state

    diff = manager.compare_snapshots(snap1.snapshot_id, snap2.snapshot_id)

    assert diff is not None
    assert diff.messages_added == 0
    assert diff.messages_removed == 0


def test_restore_snapshot_not_found():
    """Test restoring non-existent snapshot raises error."""
    manager = ConversationManager()

    try:
        manager.restore_snapshot("nonexistent_snapshot_id")
        assert False, "Should have raised FileNotFoundError"
    except FileNotFoundError as e:
        assert "not found" in str(e).lower()


def test_export_snapshot_not_found():
    """Test exporting non-existent snapshot raises error."""
    manager = ConversationManager()

    with tempfile.NamedTemporaryFile(suffix=".json") as f:
        try:
            manager.export_snapshot("nonexistent_snapshot_id", f.name)
            assert False, "Should have raised FileNotFoundError"
        except FileNotFoundError as e:
            assert "not found" in str(e).lower()
