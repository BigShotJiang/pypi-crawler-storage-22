Harnice is a free, open source electrical system CAD tool. 

It designs harnesses for you... and does so much more... *nicely!*

Please visit...
 - [harnice.io](https://harnice.io/) for documentation
 - https://github.com/harnice/harnice/issues to report a bug or feature request
 - harnice.io@gmail.com to send me an email

Made by Kenyon Shutt