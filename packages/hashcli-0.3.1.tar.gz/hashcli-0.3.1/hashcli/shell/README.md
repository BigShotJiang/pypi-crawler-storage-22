# Hashcmd hashcli shell integration
