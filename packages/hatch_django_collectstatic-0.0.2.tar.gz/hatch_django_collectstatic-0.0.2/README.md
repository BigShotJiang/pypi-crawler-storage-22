# hatch-django-collectstatic

Collect a django project's static files into its binary distribution
archive.

Example usage:

```
[build-system]
requires = ["hatchling >= 1.26", "hatch-django-collectstatic"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel.hooks.django-collectstatic]
settings = "ppr.project.settings"

[tool.hatch.build.targets.wheel.shared-data]
"static" = "share/static"
```
