from hatchling.plugin import hookimpl

from .plugin import DjangoCollectstaticBuildHook


@hookimpl
def hatch_register_build_hook():
    return DjangoCollectstaticBuildHook
