hathaway_analytics
==================

`hathaway_analytics` is a minimal, non-blocking data analytics system designed for Flask apps. It collects metadata from each incoming request and forwards it to a centralized analytics server for logging and real-time processing.

Features
--------

- Non-blocking data transmission via threading
- Compatible with Flask and Flask-SQLAlchemy
- Supports WebSocket broadcasting of incoming logs
- Configurable endpoint and authentication via Python config module
- Designed for simple integration across multiple microservices

Installation
------------

To install the package:

    pip install hathaway_analytics

Or install from a local build:

    pip install ./dist/hathaway_analytics-0.2.0-py3-none-any.whl

Usage
-----

In your Flask app:

    from hathaway_analytics import send_data_analytics

    @app.before_request
    def log_request():
        send_data_analytics()

At your centralized analytics server:

    from hathaway_analytics import receive_data_analytics

    @app.route('/log', methods=['POST'])
    def log():
        return receive_data_analytics()

Configuration
-------------

Place a `hathaway_analytics_config.py` file alongside your application with contents like:

    HA_ANALYTICS_ENDPOINT = "https://analytics.hathaway.llc/log"
    HA_ANALYTICS_SECRET = "your-secret-token"
    HA_ALLOWED_IPS = ["192.0.2.1", "198.51.100.42"]
    HA_LOGS = "minimal"

Lookup order for this module is:
1) current working directory
2) bundled package location (legacy centralized/default location, fallback)

Identical Python config modules should be placed alongside both your flask app and your centralized server.
Your secret will not be checked if it is left blank and your allowed_ips will not be checked if they are left blank.
In other words, to disable a verification method simply leave it blank in the config module.

`HA_LOGS` controls console output and supports `"silent"`, `"minimal"`, or `"full"` (default: `"minimal"`).

License
-------

GPL v3. See the LICENSE file for details.
