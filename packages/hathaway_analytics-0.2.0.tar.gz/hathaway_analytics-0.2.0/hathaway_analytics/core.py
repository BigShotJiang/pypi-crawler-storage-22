import importlib.util
import os
import threading
from importlib.metadata import PackageNotFoundError, version

import requests
from flask import abort, request
from flask_login import current_user
from flask_sqlalchemy import SQLAlchemy
from user_agents import parse as parse_user_agent
from datetime import datetime

# Initialize SQLAlchemy (must be initialized in your Flask app)
db = SQLAlchemy()


def _load_config_module():
    """Load config from local working directory first, then bundled location."""
    local_path = os.path.join(os.getcwd(), "hathaway_analytics_config.py")
    default_path = os.path.join(os.path.dirname(__file__), "hathaway_analytics_config.py")
    config_path = local_path if os.path.isfile(local_path) else default_path

    spec = importlib.util.spec_from_file_location("hathaway_analytics_runtime_config", config_path)
    if not spec or not spec.loader:
        return None

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _normalize_allowed_ips(raw_value):
    if not raw_value:
        return False

    if isinstance(raw_value, str):
        items = [ip.strip() for ip in raw_value.split(",") if ip.strip()]
    elif isinstance(raw_value, (list, tuple, set)):
        items = [str(ip).strip() for ip in raw_value if str(ip).strip()]
    else:
        return False

    return set(items) or False


def _normalize_logs(raw_value):
    value = str(raw_value or "minimal").strip().lower()
    return value if value in {"silent", "minimal", "full"} else "minimal"


def _get_package_version():
    try:
        return version("hathaway_analytics")
    except PackageNotFoundError:
        return "unknown"
    except Exception:
        return "unknown"


config = _load_config_module()

try:
    ANALYTICS_SECRET = getattr(config, "HA_ANALYTICS_SECRET", "")
    ANALYTICS_SECRET = str(ANALYTICS_SECRET).strip() if ANALYTICS_SECRET else False
except Exception:
    ANALYTICS_SECRET = False

try:
    ANALYTICS_ENDPOINT = getattr(config, "HA_ANALYTICS_ENDPOINT", "")
    ANALYTICS_ENDPOINT = str(ANALYTICS_ENDPOINT).strip() if ANALYTICS_ENDPOINT else False
except Exception:
    ANALYTICS_ENDPOINT = False

try:
    ALLOWED_IPS = _normalize_allowed_ips(getattr(config, "HA_ALLOWED_IPS", []))
except Exception:
    ALLOWED_IPS = False

try:
    LOGS = _normalize_logs(getattr(config, "HA_LOGS", "minimal"))
except Exception:
    LOGS = "minimal"


def _log_startup(message):
    if LOGS in {"minimal", "full"}:
        print(message)


def _log_full(message):
    if LOGS == "full":
        print(message)


_log_startup(f"[Analytics Config] ANALYTICS_SECRET: {repr(ANALYTICS_SECRET)}")
_log_startup(f"[Analytics Config] ANALYTICS_ENDPOINT: {ANALYTICS_ENDPOINT}")
_log_startup(f"[Analytics Config] ALLOWED_IPS: {ALLOWED_IPS}")
_log_startup(f"[Analytics Config] LOGS: {LOGS}")
_log_startup(f"[Analytics Config] VERSION: {_get_package_version()}")


class Log(db.Model):
    __tablename__ = 'log'
    id = db.Column(db.Integer, primary_key=True)
    ip = db.Column(db.String)
    timestamp = db.Column(db.Integer)
    domain = db.Column(db.String)
    path = db.Column(db.String)
    method = db.Column(db.String)
    query = db.Column(db.Text)
    os = db.Column(db.String)
    browser = db.Column(db.String)
    device = db.Column(db.String)
    referrer = db.Column(db.Text)
    user = db.Column(db.String)


def send_data_analytics():
    """
    Collects request metadata and sends it to the central analytics server.
    Safe to call from Flask's @app.before_request. Runs in a thread to avoid blocking.
    """
    try:
        ip = request.headers.get("X-Real-IP", request.remote_addr)

        try:
            user = str(current_user.get_id()) if current_user.is_authenticated else None
        except Exception:
            user = None

        data = {
            "ip": ip,
            "timestamp": int(datetime.utcnow().timestamp()),
            "domain": request.host,
            "path": request.path,
            "method": request.method,
            "query": request.query_string.decode(),
            "referrer": request.referrer,
            "user": user,
            "user_agent": request.headers.get("User-Agent", "")
        }

        headers = {
            "Content-Type": "application/json"
        }
        if ANALYTICS_SECRET:
            headers["X-Analytics-Token"] = ANALYTICS_SECRET

        def _send():
            try:
                _log_full(f"[Analytics] Sending data to {ANALYTICS_ENDPOINT}")
                response = requests.post(
                    ANALYTICS_ENDPOINT,
                    json=data,
                    headers=headers,
                    timeout=0.5
                )
                _log_full(f"[Analytics] Response code: {response.status_code}")
            except Exception as e:
                _log_full(f"[Analytics] Failed to send analytics: {e}")

        threading.Thread(target=_send, daemon=True).start()

    except Exception as e:
        _log_full(f"[Analytics] Error preparing analytics data: {e}")


def receive_data_analytics():
    """
    Flask route handler to receive and store analytics data.
    Enforces secret token and IP filtering if configured.
    """
    if ANALYTICS_SECRET:
        if request.headers.get("X-Analytics-Token") != ANALYTICS_SECRET:
            return abort(403)

    client_ip = request.headers.get("X-Forwarded-For", request.remote_addr).split(',')[0].strip()

    if ALLOWED_IPS and client_ip not in ALLOWED_IPS:
        _log_full(f"[Analytics] Blocked IP: {client_ip}")
        return abort(403)

    data = request.get_json(silent=True)
    if not data:
        return abort(400)

    # Parse user-agent string
    ua_string = data.get("user_agent", "")
    ua = parse_user_agent(ua_string)

    try:
        log = Log(
            ip=data.get("ip"),
            timestamp=data.get("timestamp"),
            domain=data.get("domain"),
            path=data.get("path"),
            method=data.get("method"),
            query=data.get("query"),
            os=ua.os.family,
            browser=ua.browser.family,
            device="Mobile" if ua.is_mobile else "Tablet" if ua.is_tablet else "PC" if ua.is_pc else "Other",
            referrer=data.get("referrer"),
            user=data.get("user")
        )
        db.session.add(log)
        db.session.commit()
        return '', 204
    except Exception as e:
        db.session.rollback()
        _log_full(f"Failed to log analytics: {str(e)}")
        return abort(500)
