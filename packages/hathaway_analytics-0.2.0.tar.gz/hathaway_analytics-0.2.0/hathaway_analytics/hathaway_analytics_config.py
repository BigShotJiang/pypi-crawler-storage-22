"""Default runtime configuration for hathaway_analytics.

Override these values by placing a `hathaway_analytics_config.py` file in your app's
working directory with the same variable names.
"""

HA_ANALYTICS_ENDPOINT = "https://example.com/log"
HA_ANALYTICS_SECRET = "your-secret-here"
HA_ALLOWED_IPS = ["192.168.0.1", "192.168.0.2"]
HA_LOGS = "minimal"
