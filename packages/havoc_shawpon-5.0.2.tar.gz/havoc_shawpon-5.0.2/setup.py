from setuptools import setup, find_packages

setup(
    name="havoc-shawpon",
    version="5.0.2",  # নতুন version
    author="Black Spammer Bd",
    description="⚡ ULTIMATE - World's Most Powerful Load Testing Tool",
    long_description="EXTREME POWER LOAD TESTING - BREAKS ALL LIMITS",
    packages=find_packages(include=['havoc_shawpon', 'havoc_shawpon.*']),
    python_requires=">=3.7",
    install_requires=[
        "aiohttp>=3.9.0",
        "colorama>=0.4.6",
    ],
    entry_points={
        "console_scripts": [
            "havoc=havoc_shawpon.cli:main",
            "ultra-havoc=havoc_shawpon.cli:main",
        ],
    },
)
