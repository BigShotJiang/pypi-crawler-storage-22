"""Hawaii Disco widgets module."""
