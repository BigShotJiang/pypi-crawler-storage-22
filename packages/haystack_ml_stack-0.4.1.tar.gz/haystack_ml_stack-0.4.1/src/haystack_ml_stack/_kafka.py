from confluent_kafka.aio import AIOProducer
import orjson
from google.protobuf.message import Message
import base64
import os
import logging
from .settings import Settings
from ._version import __version__
import hashlib

logger = logging.getLogger(__name__)
SECURITY_PROTOCOL = "SASL_SSL"
SASL_MECHANISM = "SCRAM-SHA-512"


async def send_to_kafka(
    producer: AIOProducer,
    topic: str,
    user: dict,
    streams: list[dict],
    playlist: dict,
    state: dict,
    model_output: dict,
    monitoring_meta: dict,
) -> None:
    if topic is None or producer is None:
        return
    message = {
        "userid": user.get("userid"),
        "client_os": playlist.get("clientOs"),
        "model_input": {"user": user, "streams": streams, "playlist": playlist},
        "model_output": model_output,
        "model_name": state["model_name"].replace(".pkl", "")
        if state["model_name"]
        else None,
        "model_type": "streams",
        "meta": {
            "monitoring": monitoring_meta,
            "haystack_ml_stack_version": __version__,
            "playlist_category": playlist.get("category"),
            "user_features": state.get("user_features", []),
            "stream_features": state.get("stream_features", []),
        },
    }
    delivery_future = await producer.produce(
        topic, orjson.dumps(message, default=default_serialization)
    )
    await delivery_future
    return


def default_serialization(obj):
    if isinstance(obj, Message):
        return {
            "version": obj.version,
            "proto": base64.b64encode(obj.SerializeToString()).decode("ascii"),
        }
    raise orjson.JSONEncodeError("Unknown data type to serialize!")


def initialize_kafka_producer(app_config: Settings) -> AIOProducer:
    secret_keys = orjson.loads(os.getenv("SECRET_KEYS") or "{}")
    if not secret_keys:
        raise ValueError("No Kafka credentials found.")
    with open("/tmp/ca.pem", "w") as f:
        f.write(base64.b64decode(secret_keys["KAFKA_BROKER_CA_CERTIFICATE"]).decode())
    kafka_config = {
        "bootstrap.servers": app_config.kafka_bootstrap_servers,
        "security.protocol": SECURITY_PROTOCOL,
        "sasl.username": secret_keys["KAFKA_WRITER_USER"],
        "sasl.password": secret_keys["KAFKA_WRITER_PASSWORD"],
        "sasl.mechanism": SASL_MECHANISM,
        "ssl.ca.location": "/tmp/ca.pem",
        "compression.type": "lz4",
    }
    logger.info(
        "Initializing kafka producer pushing to topic %s", app_config.kafka_topic
    )
    producer = AIOProducer(kafka_config)
    logger.info("Producer initialized!")
    return producer


def should_log_user(userid: str, kafka_fraction: float) -> bool:
    if not userid:
        return False
    hash_value = int(hashlib.sha256(userid.encode()).hexdigest(), 16) / (2**256)
    return hash_value < kafka_fraction
