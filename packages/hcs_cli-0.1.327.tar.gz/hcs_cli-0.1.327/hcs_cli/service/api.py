from typing import Optional
from hcs_core.sglib.client_util import hdc_service_client, is_regional_service, regional_service_client
from hcs_core.util.query_util import PageRequest


def _parse_path(path: str, hdc: str = None, region: str = None):
    service_path = path.split("/")[1]
    api_path = path[len(service_path) + 1 :]
    if is_regional_service(service_path):
        client = regional_service_client(service_path, region=region)
    else:
        client = hdc_service_client(service_path, hdc=hdc)
    return api_path, client


def _get(
    path: str, headers: Optional[dict] = None, all_pages: bool = False, raise_on_404: bool = False, hdc: str = None, region: str = None
):
    api_path, client = _parse_path(path, hdc=hdc, region=region)
    if all_pages:

        def _get_page(query_string):
            url = api_path
            if url.find("?") > 0:
                url += "&" + query_string
            else:
                url += "?" + query_string
            ret = client.get(url)
            return ret

        return PageRequest(_get_page, size=100, limit=0).get()
    else:
        return client.get(api_path, headers=headers, raise_on_404=raise_on_404)


def _post(
    path: str, headers: Optional[dict] = None, text: Optional[str] = None, json: Optional[dict] = None, hdc: str = None, region: str = None
):
    api_path, client = _parse_path(path, hdc=hdc, region=region)
    return client.post(api_path, text=text, json=json, headers=headers)


def _put(
    path: str, headers: Optional[dict] = None, text: Optional[str] = None, json: Optional[dict] = None, hdc: str = None, region: str = None
):
    api_path, client = _parse_path(path, hdc=hdc, region=region)
    return client.put(api_path, text=text, json=json, headers=headers)


def _delete(path: str, headers: Optional[dict] = None, raise_on_404: bool = False, hdc: str = None, region: str = None):
    api_path, client = _parse_path(path, hdc=hdc, region=region)
    return client.delete(api_path, headers=headers, raise_on_404=raise_on_404)


def _patch(
    path: str, headers: Optional[dict] = None, text: Optional[str] = None, json: Optional[dict] = None, hdc: str = None, region: str = None
):
    api_path, client = _parse_path(path, hdc=hdc, region=region)
    return client.patch(api_path, text=text, json=json, headers=headers)


class APIContext:
    """Context-aware API wrapper that maintains hdc and region for all requests."""

    def __init__(self, hdc: str = None, region: str = None):
        self.hdc = hdc
        self.region = region

    def get(self, path: str, headers: Optional[dict] = None, all_pages: bool = False, raise_on_404: bool = False):
        return _get(path, headers=headers, all_pages=all_pages, raise_on_404=raise_on_404, hdc=self.hdc, region=self.region)

    def post(self, path: str, headers: Optional[dict] = None, text: Optional[str] = None, json: Optional[dict] = None):
        return _post(path, headers=headers, text=text, json=json, hdc=self.hdc, region=self.region)

    def put(self, path: str, headers: Optional[dict] = None, text: Optional[str] = None, json: Optional[dict] = None):
        return _put(path, headers=headers, text=text, json=json, hdc=self.hdc, region=self.region)

    def delete(self, path: str, headers: Optional[dict] = None, raise_on_404: bool = False):
        return _delete(path, headers=headers, raise_on_404=raise_on_404, hdc=self.hdc, region=self.region)

    def patch(self, path: str, headers: Optional[dict] = None, text: Optional[str] = None, json: Optional[dict] = None):
        return _patch(path, headers=headers, text=text, json=json, hdc=self.hdc, region=self.region)


def with_context(hdc: str = None, region: str = None):
    """Create a context-aware API wrapper with the specified hdc and region.

    Args:
        hdc: HDC name for global services
        region: Region name for regional services

    Returns:
        APIContext: An object with get(), post(), put(), delete(), patch() methods
    """
    return APIContext(hdc=hdc, region=region)


_no_context_api = APIContext()

get = _no_context_api.get
post = _no_context_api.post
put = _no_context_api.put
delete = _no_context_api.delete
patch = _no_context_api.patch
