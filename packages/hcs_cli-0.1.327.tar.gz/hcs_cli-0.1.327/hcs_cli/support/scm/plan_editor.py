import json
from datetime import datetime
from os import path

from yumako import template

from hcs_cli.support.scm.html_util import show_html


def _timestamp_to_date(timestamp: int):
    return datetime.utcfromtimestamp(timestamp / 1000).strftime("%Y-%m-%dT%H:%M")


def _process_usage_data(usage_api: dict, template_name: str):
    """Process usage API data for the usage chart."""
    if not usage_api:
        return None

    x_axis = []
    consumed_capacity = []
    spare_capacity = []
    no_spare_error = []
    powered_on_vms = []
    consumed_capacity_predicated = []
    spare_capacity_predicated = []
    no_spare_error_predicated = []
    optimized_capacity = []

    history = usage_api.get("history", {})
    prediction = usage_api.get("prediction", {})
    timeslot_ms = usage_api.get("timeslotMs", 0)

    start_timestamp = history.get("startTimestamp", 0)
    for i in range(len(history.get("maxCapacity", []))):
        t = start_timestamp + i * timeslot_ms
        x_axis.append(_timestamp_to_date(t))
        max_capacity = history["maxCapacity"][i]
        min_free = history["minFree"][i]
        consumed_capacity.append(history["poweredOnAssignedVms"][i])
        spare_capacity.append(max_capacity - consumed_capacity[-1])
        no_spare_error.append(history["noSpare"][i])
        # Calculate poweredOnVms = poweredOnAssignedVms + poweredOnUnassignedVms
        assigned = history.get("poweredOnAssignedVms", [0])[i] if i < len(history.get("poweredOnAssignedVms", [])) else 0
        unassigned = history.get("poweredOnUnassignedVms", [0])[i] if i < len(history.get("poweredOnUnassignedVms", [])) else 0
        powered_on_vms.append(assigned + unassigned)

    start_timestamp = prediction.get("startTimestamp", 0)
    for i in range(len(prediction.get("maxCapacity", []))):
        t = start_timestamp + i * timeslot_ms
        x_axis.append(_timestamp_to_date(t))
        max_capacity = prediction["maxCapacity"][i]
        min_free = prediction["minFree"][i]
        ideal_capacity = prediction["idealCapacity"][i]
        consumed_capacity_predicated.append(ideal_capacity)
        spare_capacity_predicated.append(min_free)
        optimized_capacity.append(ideal_capacity)
        no_spare_error_predicated.append(prediction["noSpare"][i])

    # split_index marks where real data ends and predicted data begins
    split_index = len(consumed_capacity)

    n = len(consumed_capacity) - 1
    consumed_capacity_predicated = [0] * n + [consumed_capacity[-1]] + consumed_capacity_predicated
    spare_capacity_predicated = [0] * n + [0] + spare_capacity_predicated
    optimized_capacity = [0] * n + [0] + optimized_capacity
    no_spare_error_predicated = [0] * n + [no_spare_error[-1]] + no_spare_error_predicated

    # Calculate predicated powered on vms based on historical data
    # Structure: [zeros for historical period] + [predictions for 7 days (336 slots)]
    # Each week is 336 time slots (48 slots/day * 7 days)
    # Formula: slot[N] = 0.85 * slot[N-336] + 0.15 * (slot[N-336*2] + slot[N-336*3] + slot[N-336*4]) / 3
    powered_on_vms_predicated = []
    total_historical_slots = len(powered_on_vms)

    # First part: zeros for the historical period
    powered_on_vms_predicated.extend([0] * total_historical_slots)

    # Second part: 7 days of predictions (336 slots)
    for day_offset in range(7):  # 7 days
        for slot_in_day in range(48):  # 48 slots per day
            slot_index = day_offset * 48 + slot_in_day

            # Calculate which slot in the future we're predicting
            # This is relative to the end of historical data
            predict_slot = total_historical_slots + slot_index

            # Look back to find corresponding slots from previous weeks
            weeks_ago_1 = predict_slot - 336

            # Get the value from 1 week ago if available
            value_1_week = 0
            if weeks_ago_1 >= 0 and weeks_ago_1 < total_historical_slots:
                value_1_week = powered_on_vms[weeks_ago_1]

            # Collect values from 2, 3, 4 weeks ago for averaging
            secondary_values = []
            for weeks in [2, 3, 4]:
                weeks_ago = predict_slot - 336 * weeks
                if weeks_ago >= 0 and weeks_ago < total_historical_slots:
                    secondary_values.append(powered_on_vms[weeks_ago])

            # Calculate the average of secondary values
            if secondary_values:
                avg_secondary = sum(secondary_values) / len(secondary_values)
            else:
                avg_secondary = value_1_week

            # Apply formula: 0.85 * week_1_ago + 0.15 * avg(weeks_2_3_4_ago)
            value = 0.85 * value_1_week + 0.15 * avg_secondary
            powered_on_vms_predicated.append(value)

    return {
        "x_axis": x_axis,
        "consumed_capacity": consumed_capacity,
        "spare_capacity": spare_capacity,
        "no_spare_error": no_spare_error,
        "powered_on_vms": powered_on_vms,
        "powered_on_vms_predicated": powered_on_vms_predicated,
        "consumed_capacity_predicated": consumed_capacity_predicated,
        "spare_capacity_predicated": spare_capacity_predicated,
        "no_spare_error_predicated": no_spare_error_predicated,
        "optimized_capacity": optimized_capacity,
        "split_index": split_index,
    }


def edit_plan(plan: dict, template_name: str, usage_api: dict = None, template_id: str = None, org_id: str = None):
    # Start a local server to host plan-editor3.
    file_path = path.join(path.dirname(__file__), "plan-editor.html.template")
    with open(file_path, "r") as f:
        html_template = f.read()

    usage = plan["meta"]
    x_axis = []
    consumed_capacity = []
    spare_capacity = []
    no_spare_error = []
    consumed_capacity_predicated = []
    spare_capacity_predicated = []
    no_spare_error_predicated = []
    optimized_capacity = []
    history = usage["history"]
    prediction = usage["prediction"]
    timeslot_ms = usage["timeslotMs"]
    start_timestamp = history["startTimestamp"]
    for i in range(len(history["maxCapacity"])):
        t = start_timestamp + i * timeslot_ms
        x_axis.append(_timestamp_to_date(t))
        max_capacity = history["maxCapacity"][i]
        min_free = history["minFree"][i]
        consumed_capacity.append(max_capacity - min_free)
        spare_capacity.append(min_free)
        no_spare_error.append(history["noSpare"][i])

    start_timestamp = prediction["startTimestamp"]
    for i in range(len(prediction["maxCapacity"])):
        t = start_timestamp + i * timeslot_ms
        x_axis.append(_timestamp_to_date(t))
        max_capacity = prediction["maxCapacity"][i]
        min_free = prediction["minFree"][i]
        ideal_capacity = prediction["idealCapacity"][i]
        consumed_capacity_predicated.append(ideal_capacity - min_free)
        spare_capacity_predicated.append(min_free)
        optimized_capacity.append(ideal_capacity)
        no_spare_error_predicated.append(prediction["noSpare"][i])
    n = len(consumed_capacity) - 1
    consumed_capacity_predicated = [0] * n + [consumed_capacity[-1]] + consumed_capacity_predicated
    # spare_capacity_predicated = [0] * n + [spare_capacity[-1]] + spare_capacity_predicated
    spare_capacity_predicated = [0] * n + [0] + spare_capacity_predicated
    optimized_capacity = [0] * n + [0] + optimized_capacity
    no_spare_error_predicated = [0] * n + [no_spare_error[-1]] + no_spare_error_predicated

    del usage["history"]
    del usage["prediction"]
    del usage["timeslotMs"]

    # Process usage API data for the usage chart
    usage_chart_data = _process_usage_data(usage_api, template_name)

    # Format the template ID path
    template_id_path = ""
    if org_id and template_id:
        template_id_path = f"org/{org_id}/pool/{template_id}"
    elif template_id:
        template_id_path = template_id

    html_template = template.replace(
        html_template,
        {
            "PLAN_DATA": json.dumps(plan),
            "TEMPLATE_NAME": template_name,
            "TEMPLATE_ID_PATH": template_id_path,
            "x_axis": x_axis,
            "template_name": template_name,
            "spare_capacity": spare_capacity,
            "no_spare_error": no_spare_error,
            "consumed_capacity_predicated": consumed_capacity_predicated,
            "spare_capacity_predicated": spare_capacity_predicated,
            "no_spare_error_predicated": no_spare_error_predicated,
            "optimized_capacity": optimized_capacity,
            "USAGE_CHART_DATA": json.dumps(usage_chart_data) if usage_chart_data else "null",
        },
        True,
        False,
    )

    show_html(html_template, "plan-editor")
