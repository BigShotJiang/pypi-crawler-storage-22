"""
- HDpip: A pip GUI based on maliang
- Copyright © 2025 寒冬利刃.
- License: MPL-2.0

本文件是GUI基础轮子，~~屎山2号💩~~。
"""

from typing import Callable, Any, Sequence

import maliang

class MoveCanvas(maliang.animation.Animation):
    """
    针对马良的`Canvas`写的移动动画。
    """

    def __init__(
        self,
        canvas: maliang.Canvas | Sequence[maliang.Canvas], 
        offset: tuple[float, float], 
        duration: int, 
        *, 
        controller: Callable[[float], float] = maliang.animation.controllers.linear, 
        end: Callable[[], Any] | None = None, 
        fps: int = 30, 
        repeat: int = 0, 
        repeat_delay: int = 0, 
    ) -> None:
        """
        :param self: `MoveCanvas`类
        :param canvas: 要移动的画布
        :type canvas: maliang.Canvas | Sequence[maliang.Canvas]
        :param offset: 相对位移
        :type offset: tuple[float, float]
        :param duration: 持续时长
        :type duration: int
        :param controller: 控制函数
        :type controller: Callable[[float], float]
        :param end: 结束函数
        :type end: Callable[[], Any] | None
        :param fps: 每秒帧数
        :type fps: int
        :param repeat: 重复次数
        :type repeat: int
        :param repeat_delay: 重复前的延时
        :type repeat_delay: int
        """

        if isinstance(canvas, Sequence):
            def command(p: float) -> None:
                dx, dy = offset[0] * p, offset[1] * p
                for w in canvas:
                    w.move(dx, dy)
        else:
            def command(p: float) -> None:
                canvas.move(offset[0] * p, offset[1] * p)

        super().__init__(duration, command, controller = controller, end = end, fps = fps, repeat = repeat, repeat_delay = repeat_delay, derivation = True)