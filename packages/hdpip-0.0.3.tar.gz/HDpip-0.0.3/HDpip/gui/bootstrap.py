"""
- HDpip: A pip GUI based on maliang
- Copyright © 2025 寒冬利刃.
- License: MPL-2.0

本文件是参照Bootstrap写的UI构件。
"""

from typing import *

import maliang

blue = primary = "#0d6efd"
indigo = "#6610f2"
purple = "#6f42c1"
pink = "#d63384"
red = danger = "#dc3545"
orange = "#fd7e14"
yellow = warning = "#ffc107"
green = success = "#198754"
teal = "#20c997"
cyan = info = "#0dcaf0"
black = "#000"
white = "#fff"
gray = "#6c757d"
gray_dark = "#343a40"
gray_100 = light = "#f8f9fa"
gray_200 = "#e9ecef"
gray_300 = "#dee2e6"
gray_400 = "#ced4da"
gray_500 = "#adb5bd"
gray_600 = secondary = "#6c757d"
gray_700 = "#495057"
gray_800 = "#343a40"
gray_900 = dark = "#212529"
primary_subtle = "#cfe2ff"
secondary_subtle = "#e2e3e5"
success_subtle = "#d1e7dd"
info_subtle = "#cff4fc"
warning_subtle = "#fff3cd"
danger_subtle = "#f8d7da"
light_subtle = "#e9ecef"
dark_subtle = "#adb5bd"

colors = {
    "primary": [primary, primary_subtle], 
    "secondary": [secondary, secondary_subtle], 
    "success": [success, success_subtle], 
    "info": [info, info_subtle], 
    "warning": [warning, warning_subtle], 
    "danger": [danger, danger_subtle], 
    "light": [light, light_subtle], 
    "dark": [dark, dark_subtle]
}

class Button(maliang.Button):
    def __init__(
        self,
        master: maliang.containers.Canvas | maliang.core.virtual.Widget,
        position: tuple[int, int],
        size: tuple[int, int] | None = None,
        *,
        attribute: Literal[
            "default", 
            "primary", 
            "secondary", 
            "success", 
            "info", 
            "warning", 
            "danger", 
            "light", 
            "dark", 
            "outline-default", 
            "outline-primary", 
            "outline-secondary", 
            "outline-success", 
            "outline-info", 
            "outline-warning", 
            "outline-danger", 
            "outline-light", 
            "outline-dark"
        ] = "default",
        text: str = "",
        family: str | None = None,
        fontsize: int | None = None,
        weight: Literal['normal', 'bold'] = "normal",
        slant: Literal['roman', 'italic'] = "roman",
        underline: bool = False,
        overstrike: bool = False,
        justify: Literal["left", "center", "right"] = "left",
        command: Callable | None = None,
        image: maliang.toolbox.enhanced.PhotoImage | None = None,
        anchor: Literal["n", "e", "w", "s", "nw", "ne", "sw", "se", "center"] = "nw",
        capture_events: bool | None = None,
        gradient_animation: bool | None = None,
        auto_update: bool | None = None,
        style: type[maliang.core.virtual.Style] | None = None,
    ):
        super().__init__(
            master, 
            position, 
            size, 
            text = text, 
            family = family, 
            fontsize = fontsize, 
            weight = weight, 
            slant = slant, 
            underline = underline, 
            overstrike = overstrike, 
            justify = justify, 
            command = command, 
            image = image, 
            anchor = anchor, 
            capture_events = capture_events,
            gradient_animation = gradient_animation, 
            auto_update = auto_update, 
            style = style
        )

        _ = attribute.split("outline-")
        if len(_) == 1:
            self.color = _[0]
            self.outline = False
        elif len(_) == 2:
            self.color = _[1]
            self.outline = True

        if not self.outline:
            if self.color == "default":
                self.style.set("light", fg = dark, bg = light, ol = dark)
                self.style.set("dark", fg = light, bg = dark, ol = light)
            elif self.color == "light":
                self.style.set(fg = dark, bg = light, ol = dark)
            elif self.color == "dark":
                self.style.set(fg = light, bg = dark, ol = light)
            else:
                self.style.set(fg = light, bg = colors[self.color][0], ol = colors[self.color][0])
        elif self.outline:
            if self.color == "default":
                self.style.set("light", fg = (light, dark), bg = (master.cget("bg"), light), ol = (light, dark))
                self.style.set("dark", fg = (dark, light), bg = (master.cget("bg"), dark), ol = (dark, light))
            elif self.color == "light":
                self.style.set(fg = (light, dark), bg = (master.cget("bg"), light), ol = (light, dark))
            elif self.color == "dark":
                self.style.set(fg = (dark, light), bg = (master.cget("bg"), dark), ol = (dark, light))
            else:
                self.style.set(fg = (colors[self.color][0], light), bg = (master.cget("bg"), colors[self.color][0]), ol = colors[self.color][0])
        self.update()

    def disable(self, value = True) -> None:
        if not value:
            if not self.outline:
                if self.color == "default":
                    self.style.set("light", fg = dark, bg = light, ol = dark)
                    self.style.set("dark", fg = light, bg = dark, ol = light)
                elif self.color == "light":
                    self.style.set(fg = dark, bg = light, ol = dark)
                elif self.color == "dark":
                    self.style.set(fg = light, bg = dark, ol = light)
                else:
                    self.style.set(fg = light, bg = colors[self.color][0], ol = colors[self.color][0])
            elif self.outline:
                if self.color == "default":
                    self.style.set("light", fg = (light, dark), bg = (self.master.cget("bg"), light), ol = (light, dark))
                    self.style.set("dark", fg = (dark, light), bg = (self.master.cget("bg"), dark), ol = (dark, light))
                elif self.color == "light":
                    self.style.set(fg = (light, dark), bg = (self.master.cget("bg"), light), ol = (light, dark))
                elif self.color == "dark":
                    self.style.set(fg = (dark, light), bg = (self.master.cget("bg"), dark), ol = (dark, light))
                else:
                    self.style.set(fg = (colors[self.color][0], light), bg = (self.master.cget("bg"), colors[self.color][0]), ol = colors[self.color][0])
        elif value:
            if not self.outline:
                if self.color == "default":
                    self.style.set("light", fg = dark_subtle, bg = light_subtle, ol = dark_subtle)
                    self.style.set("dark", fg = light_subtle, bg = dark_subtle, ol = light_subtle)
                elif self.color == "light":
                    self.style.set(fg = dark_subtle, bg = light_subtle, ol = dark_subtle)
                elif self.color == "dark":
                    self.style.set(fg = light_subtle, bg = dark_subtle, ol = light_subtle)
                else:
                    self.style.set(fg = light_subtle, bg = colors[self.color][1], ol = colors[self.color][1])
            elif self.outline:
                if self.color == "default":
                    self.style.set("light", fg = light_subtle, bg = self.master.cget("bg"), ol = light_subtle)
                    self.style.set("dark", fg = dark_subtle, bg = self.master.cget("bg"), ol = dark_subtle)
                elif self.color == "light":
                    self.style.set(fg = light_subtle, bg = self.master.cget("bg"), ol = light_subtle)
                elif self.color == "dark":
                    self.style.set(fg = dark_subtle, bg = self.master.cget("bg"), ol = dark_subtle)
                else:
                    self.style.set(fg = colors[self.color][1], bg = self.master.cget("bg"), ol = colors[self.color][1])
        self.update()
        super().disable(value)
        self.disabled = value
        self.update()
