"""
- HDpip: A pip GUI based on maliang
- Copyright © 2025 寒冬利刃.
- License: MPL-2.0

本文件是欢迎页面。
"""

import time
import maliang
from maliang.core import configs
from maliang import theme, animation

try:
    from .. import core
except ImportError:
    import sys
    import pathlib
    base_dir = pathlib.Path(__file__).parents[1].resolve()
    sys.path.append(str(base_dir))
    import core

try:
    from . import bootstrap
except ImportError:
    import bootstrap

class LanguageCanvas(maliang.Canvas):
    """
    语言选择画布，用于显示语言选择界面。
    """

    def __init__(self, master: maliang.Canvas | maliang.Tk | maliang.Toplevel):
        super().__init__(master, expand = "xy", auto_zoom = True, auto_update = True)

class ContentCanvas(maliang.Canvas):
    """
    内容画布，包含欢迎页面的主要内容区域。
    """

    def __init__(self, master: maliang.Canvas | maliang.Tk | maliang.Toplevel):
        super().__init__(master, expand = "xy", auto_zoom = True, auto_update = True)
        self.canvas_index = 0

        LanguageCanvas(self).place(x = 0 * 1200, y = 0, width = 1200, height = 800)

    def bindButtonCanvas(self, button_canvas):
        """
        绑定按钮画布，建立与按钮区域的关联。

        :param self: `ContentCanvas`类
        :param button_canvas: `ButtonCanvas`类
        :type button_canvas: ButtonCanvas
        """

        self.button_canvas = button_canvas

class ButtonCanvas(maliang.Canvas):
    """
    按钮画布，包含欢迎页面的底部按钮区域。
    """

    def __init__(self, master: maliang.Canvas | maliang.Tk | maliang.Toplevel):
        super().__init__(master, expand = "xy", auto_zoom = True, auto_update = True)

    def bindContentCanvas(self, content_canvas):
        """
        绑定内容画布，建立与内容区域的关联。

        :param self: `ButtonCanvas`类
        :param content_canvas: `ContentCanvas`类
        :type content_canvas: ContentCanvas
        """

        self.content_canvas = content_canvas

    def start(self) -> None:
        """
        启动按钮画布的动画效果。

        :param self: `ButtonCanvas`类
        """

        self.buttonbar = self.create_rectangle(0, 0, 1200, 100, outline = "")
        def _() -> None:
            self.configure(bg = bootstrap.primary)
            def _() -> None:
                animation.MoveTkWidget(self.content_canvas, (0, -1000), 1000, controller = animation.ease_in, end = self.content_canvas.destroy, fps = 60).start()
                animation.MoveElement(self.button, (0, 200), 500, controller = animation.smooth, end = self.button.destroy, fps = 60).start()

                self.content_canvas = ContentCanvas(self.master)
            self.button = bootstrap.Button(self, (600, 50), (400, 50), attribute = "outline-light", text = "让我们开始吧！ Let's begin!", anchor = "center", command = _)
            self.delete(self.buttonbar)
        animation.GradientItem(self, self.buttonbar, "fill", (bootstrap.light, bootstrap.primary), 500, controller = animation.smooth, fps = 60, end = _).start(delay = 2500)


class Welcome(maliang.Tk):
    """
    欢迎窗口，HDpip的主欢迎界面。
    """

    def __init__(self):
        super().__init__((1200, 800), title = "寒冬pip(HDpip) - 欢迎 Welcome")
        self.alpha(0)
        self.icon_ = maliang.PhotoImage(file = str(core.base.getBaseDir() / "asset" / "image" / "icon.png"))
        self.iconphoto(True, self.icon_)
        self.wm_iconphoto(True, self.icon_)
        configs.Env.system = "Windows11"
        self.center()
        theme.customize_window(self, disable_maximize_button = True)
        self.resizable(False, False)

        for i in range(1, 21):
            self.alpha(0.05 * i)
            time.sleep(0.025)

        self.content_canvas = maliang.Canvas(self, expand = "xy", auto_zoom = True, auto_update = True)
        self.content_canvas.place(width = 1200, height = 700, x = 0, y = 0)
        self.button_canvas = ButtonCanvas(self)
        self.button_canvas.bindContentCanvas(self.content_canvas)
        self.button_canvas.place(width = 1200, height = 100, x = 0, y = 700)

        self.icon_show = maliang.Image(self.content_canvas, (600, 1000), (256, 256), image = self.icon_, anchor = "center")
        animation.MoveWidget(self.icon_show, (0, 350 - 1000), 1000, controller = animation.rebound, fps = 60).start()
        self.title_ = maliang.Text(self.content_canvas, (600, 1000), (1200, 50), text = "寒冬pip(HDpip)", fontsize = 40, weight = "bold", anchor = "center")
        animation.MoveWidget(self.icon_show, (0, 200 - 350), 500, controller = animation.smooth, fps = 60).start(delay = 1250)
        animation.MoveWidget(self.title_, (0, 400 - 1000), 500, controller = animation.smooth, fps =60).start(delay = 1250)
        self.subtitle_ = maliang.Text(self.content_canvas, (600, 1000), (1200, 50), text = "一个基于马良框架的pip GUI\nA pip GUI based on maliang", fontsize = 30, anchor = "center")
        animation.MoveWidget(self.subtitle_, (0, 500 - 1000), 500, controller = animation.smooth, fps = 60).start(delay = 1500)
        self.button_canvas.start()

if __name__ == "__main__":
    master = Welcome()
    master.mainloop()
