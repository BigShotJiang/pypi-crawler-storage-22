"""
HDSP Agent Server

AI Agent Server for IDE integrations - provides intelligent code assistance
for JupyterLab, VS Code, PyCharm, and other development environments.
"""

__version__ = "1.0.0"
