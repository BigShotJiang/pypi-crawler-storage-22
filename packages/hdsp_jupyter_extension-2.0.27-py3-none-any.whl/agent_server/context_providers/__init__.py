"""
Context Providers Module

Provides context injection for LLM prompts (e.g., @file, @notebook, @selection).
Also provides action commands (e.g., @reset).
Inspired by jupyter-ai's context provider architecture.
"""

from .actions import ResetContextProvider
from .base import BaseContextProvider, ContextCommand, find_commands
from .file import FileContextProvider
from .processor import ContextProcessor, process_context_commands

__all__ = [
    "ContextCommand",
    "BaseContextProvider",
    "FileContextProvider",
    "ResetContextProvider",
    "ContextProcessor",
    "find_commands",
    "process_context_commands",
]
