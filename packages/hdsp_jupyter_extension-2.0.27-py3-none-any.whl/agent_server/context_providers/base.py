"""
Base Context Provider Module

Defines the base classes and utilities for context providers.
Based on jupyter-ai's context provider architecture.
"""

import re
from abc import ABC, abstractmethod
from typing import Optional

from pydantic import BaseModel


class ContextCommand(BaseModel):
    """
    Represents a context command in user input (e.g., @file:path/to/file.py).

    Properties:
        cmd: Full command string (e.g., "@file:path/to/file.py")
        id: Command identifier (e.g., "@file")
        arg: Optional argument after the colon (e.g., "path/to/file.py")
    """

    cmd: str

    @property
    def id(self) -> str:
        """Extract command ID (e.g., '@file' from '@file:path')"""
        return self.cmd.partition(":")[0]

    @property
    def arg(self) -> Optional[str]:
        """
        Extract argument after colon.
        Handles quoted paths and escaped spaces.
        """
        if ":" not in self.cmd:
            return None

        arg = self.cmd.partition(":")[2]
        if not arg:
            return None

        # Remove surrounding quotes if present
        arg = arg.strip("'\"")
        # Handle escaped spaces
        arg = arg.replace("\\ ", " ")

        return arg


class ListOptionsEntry(BaseModel):
    """Entry for autocomplete options list."""

    id: str  # e.g., "@file"
    label: str  # e.g., "@file:" or "@file:path/to/file.py"
    description: str  # e.g., "Include file contents" or "Python file"
    only_start: bool = False  # Whether command only works at start of prompt
    is_complete: bool = True  # Whether this option completes the command


class ListOptionsResponse(BaseModel):
    """Response for autocomplete options."""

    options: list[ListOptionsEntry] = []


class ContextProviderException(Exception):
    """Exception raised by context providers."""

    pass


class BaseContextProvider(ABC):
    """
    Base class for context providers.

    Context providers handle @commands in user input, providing context
    to the LLM from external sources (files, notebooks, etc.).
    """

    # Unique identifier for this provider (e.g., "@file")
    id: str = ""

    # Human-readable description
    description: str = ""

    # Whether this provider requires an argument after the colon
    requires_arg: bool = True

    # Whether this command only works at the start of the prompt
    only_start: bool = False

    def __init__(self, base_dir: str = "."):
        """
        Initialize the context provider.

        Args:
            base_dir: Base directory for resolving relative paths
        """
        self.base_dir = base_dir

    @property
    def command_id(self) -> str:
        """Get the command ID (e.g., '@file')."""
        return self.id

    @property
    def pattern(self) -> str:
        """
        Regex pattern to match this context command.

        Handles:
        - @file:path/to/file
        - @file:'path with spaces'
        - @file:"path with spaces"
        - @file:path\\ with\\ escaped\\ spaces
        """
        if self.requires_arg:
            # Pattern for commands with arguments
            # Matches: @file:path, @file:'quoted path', @file:"quoted path", @file:escaped\\ path
            return (
                rf"(?<![^\s.]){re.escape(self.command_id)}:"
                rf"(?:'[^']+'|\"[^\"]+\"|[^\s\\]+(?:\\ [^\s\\]*)*)"
            )
        else:
            # Pattern for commands without arguments
            return rf"(?<![^\s.]){re.escape(self.command_id)}(?![^\s.])"

    @abstractmethod
    def get_arg_options(self, arg_prefix: str) -> list[ListOptionsEntry]:
        """
        Get autocomplete options for the command argument.

        Args:
            arg_prefix: Current argument prefix (e.g., "src/" for "@file:src/")

        Returns:
            List of autocomplete options
        """
        pass

    @abstractmethod
    def make_context(self, command: ContextCommand) -> str:
        """
        Generate context content for this command.

        Args:
            command: The parsed context command

        Returns:
            Context string to inject into the prompt

        Raises:
            ContextProviderException: If context cannot be generated
        """
        pass

    def replace_command(self, command: ContextCommand) -> str:
        """
        Get the replacement text for this command in the cleaned prompt.

        By default, replaces @file:path with 'path'.

        Args:
            command: The parsed context command

        Returns:
            Replacement text
        """
        if command.arg:
            return f"'{command.arg}'"
        return ""

    def get_provider_option(self) -> ListOptionsEntry:
        """Get the autocomplete option for this provider itself."""
        return ListOptionsEntry(
            id=self.command_id,
            label=f"{self.command_id}:" if self.requires_arg else self.command_id,
            description=self.description,
            only_start=self.only_start,
            is_complete=not self.requires_arg,
        )


def _is_inside_code_block(match: re.Match, text: str) -> bool:
    """
    Check if a regex match is inside a code block (backticks).

    Args:
        match: Regex match object
        text: Full text being searched

    Returns:
        True if match is inside backticks
    """
    start = match.start()
    before = text[:start]

    # Count backticks before the match
    # If odd number, we're inside a code block
    single_backticks = before.count("`") - before.count("```") * 3
    triple_backticks = before.count("```")

    # Inside code block if odd number of backticks/triple backticks
    return single_backticks % 2 == 1 or triple_backticks % 2 == 1


def find_commands(provider: BaseContextProvider, text: str) -> list[ContextCommand]:
    """
    Find all context commands for a provider in the given text.

    Args:
        provider: The context provider to match
        text: Text to search

    Returns:
        List of found context commands
    """
    matches = list(re.finditer(provider.pattern, text))
    results = []

    for match in matches:
        # Skip if inside code block
        if _is_inside_code_block(match, text):
            continue

        results.append(ContextCommand(cmd=match.group()))

    return results
