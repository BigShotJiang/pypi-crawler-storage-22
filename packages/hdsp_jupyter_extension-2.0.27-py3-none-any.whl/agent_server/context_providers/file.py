"""
File Context Provider

Provides @file: context injection for including file contents in prompts.
Based on jupyter-ai's FileContextProvider.
"""

import glob
import os
from typing import Optional

import nbformat

from .base import (
    BaseContextProvider,
    ContextCommand,
    ContextProviderException,
    ListOptionsEntry,
)

# Supported file extensions
SUPPORTED_EXTS = {
    ".py",
    ".md",
    ".txt",
    ".json",
    ".yaml",
    ".yml",
    ".toml",
    ".ini",
    ".cfg",
    ".sh",
    ".bash",
    ".ipynb",
    ".js",
    ".ts",
    ".jsx",
    ".tsx",
    ".html",
    ".css",
    ".scss",
    ".sql",
    ".r",
    ".R",
    ".Rmd",
    ".jl",
    ".csv",
    ".xml",
    ".env",
    ".gitignore",
    ".dockerignore",
    "Dockerfile",
    "Makefile",
    ".tex",
}

# Template for file context
FILE_CONTEXT_TEMPLATE = """The following is the content of the file `{filepath}`:

```
{content}
```"""


class FileContextProvider(BaseContextProvider):
    """
    Context provider for including file contents in prompts.

    Usage:
        @file:path/to/file.py
        @file:'path with spaces/file.py'
        @file:"another/path.py"
    """

    id = "@file"
    description = "Include file contents in the prompt"
    requires_arg = True
    only_start = False

    def __init__(self, base_dir: str = "."):
        super().__init__(base_dir)

    def get_arg_options(self, arg_prefix: str) -> list[ListOptionsEntry]:
        """
        Get autocomplete options for file paths.

        Args:
            arg_prefix: Current path prefix (e.g., "src/" or "data/train")

        Returns:
            List of matching file/directory options
        """
        options = []

        # Resolve the path prefix
        if os.path.isabs(arg_prefix):
            path_prefix = arg_prefix
        else:
            path_prefix = os.path.join(self.base_dir, arg_prefix)

        # Normalize path (handle .. and .)
        path_prefix = os.path.normpath(path_prefix)

        # If the original prefix ends with / and it's a directory, list contents
        if arg_prefix.endswith("/") and os.path.isdir(path_prefix):
            glob_pattern = os.path.join(path_prefix, "*")
        else:
            # Otherwise, use the prefix to match
            glob_pattern = path_prefix + "*"

        # Use glob to find matching paths
        try:
            path_matches = glob.glob(glob_pattern)
        except Exception:
            path_matches = []

        # Sort: directories first, then files
        path_matches = sorted(
            path_matches,
            key=lambda p: (not os.path.isdir(p), os.path.basename(p).lower()),
        )

        # Limit results
        for path in path_matches[:20]:
            is_dir = os.path.isdir(path)

            # For files, check if extension is supported
            if not is_dir:
                ext = os.path.splitext(path)[1]
                basename = os.path.basename(path)
                # Check extension or special filenames
                if ext not in SUPPORTED_EXTS and basename not in SUPPORTED_EXTS:
                    continue

            # Make relative path for display
            try:
                if os.path.isabs(arg_prefix):
                    display_path = path
                else:
                    display_path = os.path.relpath(path, self.base_dir)
            except ValueError:
                display_path = path

            # Add trailing slash for directories
            label_path = display_path + "/" if is_dir else display_path

            # Handle paths with spaces
            if " " in label_path:
                label_path = f"'{label_path}'"

            options.append(
                ListOptionsEntry(
                    id=self.command_id,
                    label=f"{self.command_id}:{label_path}",
                    description="Directory"
                    if is_dir
                    else self._get_file_description(path),
                    only_start=self.only_start,
                    is_complete=not is_dir,  # Complete only for files
                )
            )

        return options

    def _get_file_description(self, filepath: str) -> str:
        """Get a description for a file based on its extension."""
        ext = os.path.splitext(filepath)[1].lower()
        basename = os.path.basename(filepath)

        descriptions = {
            ".py": "Python file",
            ".ipynb": "Jupyter notebook",
            ".md": "Markdown file",
            ".txt": "Text file",
            ".json": "JSON file",
            ".yaml": "YAML file",
            ".yml": "YAML file",
            ".toml": "TOML file",
            ".js": "JavaScript file",
            ".ts": "TypeScript file",
            ".tsx": "TypeScript React file",
            ".jsx": "JavaScript React file",
            ".html": "HTML file",
            ".css": "CSS file",
            ".sql": "SQL file",
            ".sh": "Shell script",
            ".csv": "CSV file",
            ".r": "R file",
            ".R": "R file",
            ".jl": "Julia file",
        }

        # Check special filenames
        if basename == "Dockerfile":
            return "Dockerfile"
        if basename == "Makefile":
            return "Makefile"

        return descriptions.get(ext, "File")

    def make_context(self, command: ContextCommand) -> str:
        """
        Read file contents and format for LLM.

        Args:
            command: The @file command

        Returns:
            Formatted file context

        Raises:
            ContextProviderException: If file cannot be read
        """
        filepath = command.arg
        if not filepath:
            raise ContextProviderException("No file path specified")

        # Resolve path
        if not os.path.isabs(filepath):
            filepath = os.path.join(self.base_dir, filepath)

        filepath = os.path.normpath(filepath)

        # Validation
        if not os.path.exists(filepath):
            raise ContextProviderException(f"File not found: {filepath}")

        if os.path.isdir(filepath):
            raise ContextProviderException(f"Cannot read directory: {filepath}")

        # Check extension
        ext = os.path.splitext(filepath)[1]
        basename = os.path.basename(filepath)
        if ext not in SUPPORTED_EXTS and basename not in SUPPORTED_EXTS:
            raise ContextProviderException(
                f"Unsupported file type: {ext}. "
                f"Supported types: {', '.join(sorted(SUPPORTED_EXTS))}"
            )

        # Read file
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                content = f.read()
        except UnicodeDecodeError:
            raise ContextProviderException(
                f"Cannot read file (encoding error): {filepath}"
            )
        except PermissionError:
            raise ContextProviderException(f"Permission denied: {filepath}")
        except Exception as e:
            raise ContextProviderException(f"Error reading file: {e}")

        # Process content (special handling for notebooks)
        content = self._process_file(content, filepath)

        # Truncate if too long (100K chars max)
        max_chars = 100_000
        if len(content) > max_chars:
            content = (
                content[:max_chars]
                + f"\n\n... [truncated, {len(content) - max_chars} more characters]"
            )

        # Format with template
        return FILE_CONTEXT_TEMPLATE.format(
            filepath=filepath,
            content=content,
        )

    def _process_file(self, content: str, filepath: str) -> str:
        """
        Process file content, with special handling for certain file types.

        Args:
            content: Raw file content
            filepath: Path to the file

        Returns:
            Processed content
        """
        if filepath.endswith(".ipynb"):
            # Extract cell contents from Jupyter notebook
            try:
                nb = nbformat.reads(content, as_version=4)
                cells = []
                for i, cell in enumerate(nb.cells):
                    cell_type = cell.cell_type
                    source = cell.source
                    cells.append(f"# Cell {i + 1} ({cell_type}):\n{source}")
                return "\n\n".join(cells)
            except Exception:
                # If parsing fails, return raw content
                return content

        return content

    def replace_command(self, command: ContextCommand) -> str:
        """
        Get replacement text for the command in the cleaned prompt.

        Replaces @file:path with 'path'.
        """
        filepath = command.arg or ""
        return f"'{filepath}'"


# Singleton instance with default base directory
_file_provider: Optional[FileContextProvider] = None


def get_file_provider(base_dir: str = ".") -> FileContextProvider:
    """Get or create the file context provider singleton."""
    global _file_provider
    if _file_provider is None or _file_provider.base_dir != base_dir:
        _file_provider = FileContextProvider(base_dir=base_dir)
    return _file_provider
