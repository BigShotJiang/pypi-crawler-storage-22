"""
Context Processor

Processes context commands in user input, injecting file contents and other
context into the LLM prompt.
"""

import logging
from typing import Optional

from .base import BaseContextProvider, ContextProviderException, find_commands
from .file import FileContextProvider

logger = logging.getLogger(__name__)


class ContextProcessor:
    """
    Processes context commands (@file, etc.) in user input.

    This class:
    1. Finds context commands in the user's message
    2. Builds context content from the commands
    3. Cleans the original message by replacing commands with references
    """

    def __init__(self, base_dir: str = "."):
        """
        Initialize the context processor.

        Args:
            base_dir: Base directory for resolving relative file paths
        """
        self.base_dir = base_dir
        self.providers: dict[str, BaseContextProvider] = {
            "@file": FileContextProvider(base_dir=base_dir),
        }

    def process_message(self, message: str) -> tuple[str, str, list[str]]:
        """
        Process context commands in a message.

        Args:
            message: The user's message containing context commands

        Returns:
            Tuple of:
            - context: Combined context string to prepend to the prompt
            - cleaned_message: Message with commands replaced by references
            - errors: List of error messages (if any commands failed)
        """
        context_parts = []
        errors = []
        cleaned_message = message

        # Process each provider
        for provider_id, provider in self.providers.items():
            commands = find_commands(provider, message)

            for command in commands:
                try:
                    # Generate context for this command
                    context = provider.make_context(command)
                    context_parts.append(context)

                    # Replace command in message
                    replacement = provider.replace_command(command)
                    cleaned_message = cleaned_message.replace(
                        command.cmd, replacement, 1
                    )

                    logger.info(f"Processed context command: {command.cmd}")

                except ContextProviderException as e:
                    errors.append(str(e))
                    logger.warning(f"Context command failed: {command.cmd} - {e}")

        # Combine all context
        combined_context = "\n\n".join(context_parts) if context_parts else ""

        return combined_context, cleaned_message, errors

    def has_context_commands(self, message: str) -> bool:
        """
        Check if a message contains any context commands.

        Args:
            message: The message to check

        Returns:
            True if message contains context commands
        """
        for provider in self.providers.values():
            if find_commands(provider, message):
                return True
        return False

    def build_prompt_with_context(
        self,
        message: str,
        system_context: Optional[str] = None,
    ) -> tuple[str, list[str]]:
        """
        Build a complete prompt with injected context.

        Args:
            message: The user's message
            system_context: Optional additional system context

        Returns:
            Tuple of:
            - prompt: Complete prompt with context
            - errors: List of any errors that occurred
        """
        context, cleaned_message, errors = self.process_message(message)

        # Build the final prompt
        parts = []

        if context:
            parts.append("### Provided Context ###")
            parts.append(context)
            parts.append("### End of Context ###\n")

        if system_context:
            parts.append(system_context)

        parts.append(cleaned_message)

        prompt = "\n\n".join(parts)

        return prompt, errors


def process_context_commands(
    message: str,
    base_dir: str = ".",
) -> tuple[str, str, list[str]]:
    """
    Convenience function to process context commands.

    Args:
        message: User's message
        base_dir: Base directory for file resolution

    Returns:
        Tuple of (context, cleaned_message, errors)
    """
    processor = ContextProcessor(base_dir=base_dir)
    return processor.process_message(message)
