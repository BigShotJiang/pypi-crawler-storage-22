"""
Agent Factory

Main module for creating agents in the multi-agent architecture.
Based on Deep Agents library pattern (benchmarked, not installed).

Provides:
- create_main_agent(): Main supervisor agent (executes code, orchestrates)
- create_subagent(): Specialized subagents (python_developer, researcher, athena_query)
- create_multi_agent_system(): Complete multi-agent setup

Architecture:
- Main Agent: Executes code (jupyter_cell_tool, write_file_tool) and orchestrates
- Subagents: Generate code/analysis but do NOT execute (like Athena Query generates SQL)
"""

import logging
from typing import Any, Dict, Optional

from agent_server.langchain.agent_prompts.planner_prompt import (
    PLANNER_SYSTEM_PROMPT,
)
from agent_server.langchain.custom_middleware import (
    create_continuation_control_middleware,
    create_handle_empty_response_middleware,
    create_limit_tool_calls_middleware,
    create_normalize_tool_args_middleware,
    create_patch_tool_calls_middleware,
)
from agent_server.langchain.hitl_config import get_hitl_interrupt_config
from agent_server.langchain.llm_factory import create_llm, create_summarization_llm
from agent_server.langchain.middleware.skill_middleware import get_skill_middleware
from agent_server.langchain.middleware.subagent_middleware import (
    create_task_tool,
    set_subagent_factory,
)
from agent_server.langchain.subagents.base import (
    get_available_subagents_for_planner,
    get_subagent_config,
)
from agent_server.langchain.tools.tool_registry import get_tools_for_agent

logger = logging.getLogger(__name__)


def create_subagent(
    agent_type: str,
    llm_config: Dict[str, Any],
    checkpointer: Optional[object] = None,
    enable_hitl: bool = True,
    system_prompt_override: Optional[str] = None,
) -> Any:
    """
    Create a specialized subagent.

    Subagents are stateless and run in isolated context.
    They generate code/analysis but do NOT execute - Main Agent handles execution.

    Args:
        agent_type: Type of subagent (python_developer, researcher, athena_query)
        llm_config: LLM configuration
        checkpointer: Optional checkpointer (usually None for subagents)
        enable_hitl: Enable Human-in-the-Loop for tools that need approval
        system_prompt_override: Optional custom system prompt for this subagent

    Returns:
        Compiled agent graph
    """
    try:
        from langchain.agents import create_agent
        from langchain.agents.middleware import (
            HumanInTheLoopMiddleware,
            ModelCallLimitMiddleware,
        )
        from langgraph.checkpoint.memory import InMemorySaver
    except ImportError as e:
        logger.error(f"Failed to import LangChain components: {e}")
        raise

    # Get subagent configuration
    config = get_subagent_config(agent_type)

    # Create LLM (may use override from config)
    llm = create_llm(llm_config)

    # Get tools for this agent type
    tools = get_tools_for_agent(agent_type)

    # Configure middleware
    middleware = []

    # Add HITL middleware if enabled (for tools that need approval)
    if enable_hitl:
        hitl_middleware = HumanInTheLoopMiddleware(
            interrupt_on=get_hitl_interrupt_config(),
            description_prefix=f"[{agent_type}] Tool execution pending approval",
        )
        middleware.append(hitl_middleware)

    # Add nested subagent support for python_developer
    if config.can_call_subagents:
        # Python Developer can call athena_query
        task_tool = create_task_tool(
            caller_name=agent_type,
            allowed_subagents=config.can_call_subagents,
        )
        tools = tools + [task_tool]
        logger.info(f"Subagent '{agent_type}' can call: {config.can_call_subagents}")

    # Add SkillMiddleware for python_developer (code generation agent)
    skill_prompt_section = ""
    if agent_type == "python_developer":
        skill_middleware = get_skill_middleware()
        tools = tools + skill_middleware.get_tools()
        skill_prompt_section = skill_middleware.get_prompt_section()
        logger.info(
            f"SkillMiddleware added to '{agent_type}': "
            f"{len(skill_middleware.skills)} skills available"
        )

    # Add model call limit to prevent infinite loops
    model_limit = ModelCallLimitMiddleware(
        run_limit=15,  # Subagents have lower limit
        exit_behavior="end",
    )
    middleware.append(model_limit)

    # Determine system prompt (use override if provided)
    base_prompt = (
        system_prompt_override if system_prompt_override else config.system_prompt
    )

    # Inject skill prompt section for python_developer
    if skill_prompt_section:
        system_prompt = f"{base_prompt}\n\n{skill_prompt_section}"
        logger.info(
            f"Injected skills prompt section ({len(skill_prompt_section)} chars)"
        )
    else:
        system_prompt = base_prompt

    # Create the subagent
    agent = create_agent(
        model=llm,
        tools=tools,
        middleware=middleware,
        checkpointer=checkpointer or InMemorySaver(),  # Needed for HITL
        system_prompt=system_prompt,
    )

    logger.info(
        f"Created subagent '{agent_type}' with {len(tools)} tools, "
        f"HITL={enable_hitl}, nested_calls={config.can_call_subagents}"
    )

    return agent


def create_main_agent(
    llm_config: Dict[str, Any],
    checkpointer: Optional[object] = None,
    enable_hitl: bool = True,
    enable_todo_list: bool = True,
    system_prompt_override: Optional[str] = None,
    agent_prompts: Optional[Dict[str, str]] = None,
) -> Any:
    """
    Create the Main Agent (Supervisor).

    The Main Agent is the central agent that:
    - Analyzes user requests
    - Creates todo lists
    - Executes code directly (jupyter_cell_tool, write_file_tool, etc.)
    - Delegates analysis/generation tasks to subagents via task()
    - Synthesizes results

    Args:
        llm_config: LLM configuration
        checkpointer: Checkpointer for state persistence
        enable_hitl: Enable Human-in-the-Loop
        enable_todo_list: Enable TodoListMiddleware
        system_prompt_override: Optional custom system prompt for Main Agent
        agent_prompts: Optional dict of per-agent system prompts

    Returns:
        Compiled Main Agent graph
    """
    try:
        from langchain.agents import create_agent
        from langchain.agents.middleware import (
            AgentMiddleware,
            HumanInTheLoopMiddleware,
            ModelCallLimitMiddleware,
            SummarizationMiddleware,
            TodoListMiddleware,
            ToolCallLimitMiddleware,
            wrap_model_call,
        )
        from langchain_core.messages import ToolMessage as LCToolMessage
        from langgraph.checkpoint.memory import InMemorySaver
        from langgraph.types import Overwrite
    except ImportError as e:
        logger.error(f"Failed to import LangChain components: {e}")
        raise

    # Initialize the subagent factory for nested calls with custom prompts
    # NOTE: Subagents run with HITL disabled because:
    # 1. They're already authorized by the Main Agent's task delegation
    # 2. HITL interrupts from subagents don't bubble up properly in synchronous invoke()
    # 3. The Main Agent's task() call is the authorization checkpoint
    def subagent_factory_with_prompts(name: str, cfg: Dict[str, Any]) -> Any:
        prompt_override = agent_prompts.get(name) if agent_prompts else None
        return create_subagent(
            name,
            cfg,
            enable_hitl=False,  # Subagents auto-approve (Main Agent authorizes via task delegation)
            system_prompt_override=prompt_override,
        )

    set_subagent_factory(
        factory_func=subagent_factory_with_prompts,
        llm_config=llm_config,
    )

    # Create LLM
    llm = create_llm(llm_config)

    # Get Main Agent's direct tools (including code execution tools)
    # Using "planner" for backward compatibility with tool_registry
    tools = get_tools_for_agent("planner")

    # Create task tool for calling subagents
    available_subagents = [
        config.name for config in get_available_subagents_for_planner()
    ]
    task_tool = create_task_tool(
        caller_name="planner",
        allowed_subagents=None,  # Main Agent (Planner) can call all non-restricted subagents
    )
    tools = tools + [task_tool]

    # Configure middleware
    middleware = []

    # Add empty response handler middleware (critical for Gemini compatibility)
    handle_empty_response = create_handle_empty_response_middleware(wrap_model_call)
    middleware.append(handle_empty_response)

    # Add tool call limiter middleware
    limit_tool_calls = create_limit_tool_calls_middleware(wrap_model_call)
    middleware.append(limit_tool_calls)

    # Add tool args normalization middleware
    normalize_tool_args = create_normalize_tool_args_middleware(
        wrap_model_call, tools=tools
    )
    middleware.append(normalize_tool_args)

    # Add unified continuation control middleware
    # - Injects continuation prompts after non-HITL tool execution
    # - Strips write_todos from responses containing summary JSON
    continuation_control = create_continuation_control_middleware(wrap_model_call)
    middleware.append(continuation_control)

    # Add patch tool calls middleware
    patch_tool_calls = create_patch_tool_calls_middleware(
        AgentMiddleware, LCToolMessage, Overwrite
    )
    middleware.append(patch_tool_calls)

    # Add TodoListMiddleware for task planning
    # NOTE: system_prompt removed to avoid multi-part content array
    if enable_todo_list:
        todo_middleware = TodoListMiddleware(
            tool_description="Create and manage a todo list for tracking tasks. All items in Korean.",
        )
        middleware.append(todo_middleware)

    # Add HITL middleware
    if enable_hitl:
        hitl_middleware = HumanInTheLoopMiddleware(
            interrupt_on=get_hitl_interrupt_config(),
            description_prefix="[Main Agent] Tool execution pending approval",
        )
        middleware.append(hitl_middleware)

    # Add model call limit
    model_limit = ModelCallLimitMiddleware(
        run_limit=50,  # Higher limit for Main Agent (orchestrates multiple subagents)
        exit_behavior="end",
    )
    middleware.append(model_limit)
    logger.info("Added ModelCallLimitMiddleware with run_limit=50")

    # ToolCallLimitMiddleware: Prevent write_todos from being called too many times
    write_todos_limit = ToolCallLimitMiddleware(
        tool_name="write_todos",
        run_limit=20,  # Max 20 write_todos calls per user message
        exit_behavior="continue",
    )
    middleware.append(write_todos_limit)
    logger.info("Added ToolCallLimitMiddleware for write_todos (20/msg)")

    # Add summarization middleware
    summary_llm = create_summarization_llm(llm_config)
    if summary_llm:
        try:
            summarization = SummarizationMiddleware(
                model=summary_llm,
                trigger=("tokens", 10000),  # Higher trigger for multi-agent
                keep=("messages", 15),
            )
            middleware.append(summarization)
            logger.info("Added SummarizationMiddleware to Main Agent")
        except Exception as e:
            logger.warning(f"Failed to add SummarizationMiddleware: {e}")

    # Build system prompt with priority: system_prompt_override > agent_prompts.planner > default
    logger.info(
        "Main Agent prompt sources: system_prompt_override=%s (len=%d), "
        "agent_prompts.planner=%s",
        bool(system_prompt_override),
        len(system_prompt_override) if system_prompt_override else 0,
        bool(agent_prompts.get("planner") if agent_prompts else None),
    )

    if system_prompt_override and system_prompt_override.strip():
        system_prompt = system_prompt_override.strip()
        logger.info("Using system_prompt_override (length=%d)", len(system_prompt))
    elif agent_prompts and agent_prompts.get("planner"):
        system_prompt = agent_prompts["planner"]
        logger.info("Using agent_prompts.planner (length=%d)", len(system_prompt))
    else:
        system_prompt = PLANNER_SYSTEM_PROMPT
        logger.info("Using PLANNER_SYSTEM_PROMPT (length=%d)", len(system_prompt))

    # Log provider info for debugging
    provider = llm_config.get("provider", "")
    logger.info(f"Creating Main Agent with provider: {provider}")

    # Create the Main Agent
    agent = create_agent(
        model=llm,
        tools=tools,
        middleware=middleware,
        checkpointer=checkpointer or InMemorySaver(),
        system_prompt=system_prompt,
    )

    logger.info(
        f"Created Main Agent with {len(tools)} tools, "
        f"HITL={enable_hitl}, TodoList={enable_todo_list}, "
        f"available_subagents={available_subagents}"
    )

    return agent


# Alias for backward compatibility
create_planner_agent = create_main_agent


def create_multi_agent_system(
    llm_config: Dict[str, Any],
    checkpointer: Optional[object] = None,
    enable_hitl: bool = True,
    enable_todo_list: bool = True,
    system_prompt_override: Optional[str] = None,
    agent_prompts: Optional[Dict[str, str]] = None,
) -> Any:
    """
    Create the complete multi-agent system.

    This is the main entry point that returns the Main Agent,
    which orchestrates all subagents.

    Args:
        llm_config: LLM configuration
        checkpointer: Checkpointer for state persistence
        enable_hitl: Enable Human-in-the-Loop
        enable_todo_list: Enable TodoListMiddleware
        system_prompt_override: Optional custom system prompt for Main Agent
        agent_prompts: Optional dict of per-agent system prompts
                       {"planner": "...", "main_agent": "...", "python_developer": "...", etc.}

    Returns:
        Compiled Main Agent (which can call subagents)
    """
    return create_main_agent(
        llm_config=llm_config,
        checkpointer=checkpointer,
        enable_hitl=enable_hitl,
        enable_todo_list=enable_todo_list,
        system_prompt_override=system_prompt_override,
        agent_prompts=agent_prompts,
    )


# Alias for backwards compatibility
create_agent_v2 = create_multi_agent_system
