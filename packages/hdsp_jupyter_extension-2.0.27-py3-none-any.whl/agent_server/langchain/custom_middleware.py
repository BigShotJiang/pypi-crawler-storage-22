"""
Custom middleware for LangChain agent.

Provides middleware for handling empty responses, limiting tool calls,
injecting continuation prompts, and patching dangling tool calls.
"""

import json
import logging
import re
import uuid
from typing import Any, Dict, Optional

from json_repair import repair_json
from langchain_core.messages import AIMessage, HumanMessage

from agent_server.langchain.logging_utils import (
    _format_middleware_marker,
    _pretty_json,
    _serialize_message,
    _with_middleware_logging,
)
from agent_server.langchain.prompts import JSON_TOOL_SCHEMA, NON_HITL_TOOLS

logger = logging.getLogger(__name__)


def parse_json_tool_call(text) -> Optional[Dict[str, Any]]:
    """Parse JSON tool call from text response.

    Args:
        text: Raw text that may contain a JSON tool call (str or list)

    Returns:
        Parsed dictionary with 'tool' and 'arguments' keys, or None
    """
    if not text:
        return None

    # Handle list content (multimodal responses from Gemini)
    if isinstance(text, list):
        text_parts = []
        for part in text:
            if isinstance(part, str):
                text_parts.append(part)
            elif isinstance(part, dict) and part.get("type") == "text":
                text_parts.append(part.get("text", ""))
        text = "\n".join(text_parts)

    if not isinstance(text, str) or not text:
        return None

    # Clean up response
    text = text.strip()
    if text.startswith("```json"):
        text = text[7:]
    elif text.startswith("```"):
        text = text[3:]
    if text.endswith("```"):
        text = text[:-3]
    text = text.strip()

    # Try direct JSON parse
    try:
        data = json.loads(text)
        if "tool" in data:
            return data
    except json.JSONDecodeError:
        pass

    # Try to find JSON object in response
    json_match = re.search(r"\{[\s\S]*\}", text)
    if json_match:
        try:
            data = json.loads(json_match.group())
            if "tool" in data:
                return data
        except json.JSONDecodeError:
            pass

    # Try json-repair for malformed JSON from LLMs
    try:
        repaired = repair_json(text, return_objects=True)
        if isinstance(repaired, dict) and "tool" in repaired:
            logger.info(f"Repaired malformed JSON tool call: {repaired.get('tool')}")
            return repaired
    except Exception as e:
        logger.debug(f"json-repair failed: {e}")

    return None


def normalize_tool_name(tool_name: str) -> str:
    """Normalize tool name to match registered tool names.

    Rules:
    - write_todos_tool → write_todos (TodoListMiddleware exception)
    - task → task_tool (SubAgentMiddleware uses task_tool)
    - other tools without _tool suffix → add _tool suffix
    """
    if tool_name == "write_todos_tool":
        return "write_todos"
    if tool_name == "task":
        return "task_tool"
    if not tool_name.endswith("_tool") and tool_name not in ("write_todos",):
        return f"{tool_name}_tool"
    return tool_name


def repair_tool_call_arguments(arguments: str) -> Optional[Dict[str, Any]]:
    """Repair malformed tool call arguments from LLMs.

    Some LLMs (e.g., gpt-oss-120b) return arguments without leading '{' or
    with other JSON formatting issues.

    Args:
        arguments: Raw arguments string from LLM

    Returns:
        Parsed dictionary or None if repair failed
    """
    if not arguments or not isinstance(arguments, str):
        return None

    arguments = arguments.strip()

    # Try direct parse first
    try:
        return json.loads(arguments)
    except json.JSONDecodeError:
        pass

    # Use json-repair for malformed arguments
    try:
        repaired = repair_json(arguments, return_objects=True)
        if isinstance(repaired, dict):
            logger.info("Repaired malformed tool arguments")
            return repaired
    except Exception as e:
        logger.debug(f"json-repair failed for arguments: {e}")

    return None


def try_extract_tool_calls_from_additional_kwargs(
    response_message,
) -> Optional[AIMessage]:
    """Try to extract and repair tool_calls from additional_kwargs.

    Some LLMs put tool_calls in additional_kwargs but with malformed arguments.
    This function tries to repair them and create a proper AIMessage.

    Args:
        response_message: AIMessage with potential tool_calls in additional_kwargs

    Returns:
        New AIMessage with repaired tool_calls, or None if extraction failed
    """
    if not response_message:
        return None

    additional_kwargs = getattr(response_message, "additional_kwargs", {})
    raw_tool_calls = additional_kwargs.get("tool_calls", [])

    if not raw_tool_calls:
        return None

    # IMPORTANT: Only use the first tool_call to prevent parallel execution issues
    # LLM sometimes generates multiple tool_calls despite prompt instructions
    if len(raw_tool_calls) > 1:
        first_tc = raw_tool_calls[0]
        first_name = first_tc.get("function", {}).get("name", "unknown")
        ignored_names = [
            tc.get("function", {}).get("name", "unknown") for tc in raw_tool_calls[1:]
        ]
        logger.warning(
            "Multiple tool_calls in additional_kwargs (%d), using only first one: %s. Ignored: %s",
            len(raw_tool_calls),
            first_name,
            ignored_names,
        )
        raw_tool_calls = raw_tool_calls[:1]

    repaired_tool_calls = []
    for tc in raw_tool_calls:
        func = tc.get("function", {})
        name = func.get("name")
        arguments = func.get("arguments", "")
        tc_id = tc.get("id", str(uuid.uuid4()))

        if not name:
            continue

        # Try to repair arguments
        args = repair_tool_call_arguments(arguments)
        if args is not None:
            repaired_tool_calls.append(
                {
                    "name": normalize_tool_name(name),
                    "args": args,
                    "id": tc_id,
                    "type": "tool_call",
                }
            )

    if repaired_tool_calls:
        logger.info(
            f"Extracted {len(repaired_tool_calls)} tool calls from additional_kwargs"
        )
        return AIMessage(
            content=getattr(response_message, "content", "") or "",
            tool_calls=repaired_tool_calls,
        )

    return None


def create_tool_call_message(tool_name: str, arguments: Dict[str, Any]) -> AIMessage:
    """Create AIMessage with tool_calls from parsed JSON.

    Args:
        tool_name: Name of the tool to call
        arguments: Tool arguments dictionary

    Returns:
        AIMessage with properly formatted tool_calls
    """
    tool_name = normalize_tool_name(tool_name)

    return AIMessage(
        content="",
        tool_calls=[
            {
                "name": tool_name,
                "args": arguments,
                "id": str(uuid.uuid4()),
                "type": "tool_call",
            }
        ],
    )


def create_handle_empty_response_middleware(wrap_model_call):
    """Create middleware to detect and handle empty LLM responses with JSON fallback.

    For models that don't support native tool calling well (e.g., Gemini 2.5 Flash),
    this middleware:
    1. Detects empty or text-only responses (no tool_calls)
    2. Retries with JSON schema prompt to force structured output
    3. Parses JSON response and injects tool_calls into AIMessage
    4. Falls back to synthetic write_todos completion if all else fails

    Args:
        wrap_model_call: LangChain's wrap_model_call decorator

    Returns:
        Middleware function
    """

    @wrap_model_call
    @_with_middleware_logging("handle_empty_response")
    def handle_empty_response(request, handler):
        max_retries = 2

        # Check if all todos are completed - if so, return empty response to stop agent
        # Method 1: Check state.todos
        todos = request.state.get("todos", [])
        logger.debug(
            "handle_empty_response: state.todos=%s",
            json.dumps(todos, ensure_ascii=False) if todos else "[]",
        )
        if todos:
            pending_todos = [
                t for t in todos if t.get("status") in ("pending", "in_progress")
            ]
            if not pending_todos:
                # Check if summary already exists AFTER the last REAL HumanMessage
                # (to avoid false positives from previous task summaries)
                # Note: Skip system-injected messages like "[SYSTEM] Tool completed..."
                summary_exists = False
                messages = request.messages

                # Find index of last REAL HumanMessage (not system-injected)
                last_human_idx = -1
                for i, msg in enumerate(messages):
                    msg_type = getattr(msg, "type", "") or type(msg).__name__
                    if msg_type in ("human", "HumanMessage"):
                        msg_content = getattr(msg, "content", "") or ""
                        # Skip system-injected messages
                        if not msg_content.startswith("[SYSTEM]"):
                            last_human_idx = i

                # Only check messages after last REAL HumanMessage for summary
                messages_to_check = (
                    messages[last_human_idx + 1 :]
                    if last_human_idx >= 0
                    else messages[-10:]
                )
                for msg in messages_to_check:
                    content = getattr(msg, "content", "") or ""
                    if '"summary"' in content and '"next_items"' in content:
                        summary_exists = True
                        break

                if summary_exists:
                    logger.info(
                        "All %d todos completed and summary exists after last user message - stopping agent (no LLM call)",
                        len(todos),
                    )
                    return AIMessage(content="", tool_calls=[])
                else:
                    # Allow one more LLM call for summary generation
                    logger.info(
                        "All %d todos completed but no summary yet after last user message - allowing LLM call for summary",
                        len(todos),
                    )

        # Method 2: Check last message if it's a write_todos ToolMessage with all completed
        # Note: We now allow one more LLM call for summary generation when all todos are completed
        # This check is skipped to let the agent produce a summary

        # Check if summary todo is completed
        # IMPORTANT: Only consider summary completed if it's the LAST todo item and ALL todos are done
        # This prevents false positives when a previous summary is completed but new tasks are added
        all_todos_completed = all(t.get("status") == "completed" for t in todos)
        last_todo_is_summary = (
            len(todos) > 0
            and "작업 요약" in todos[-1].get("content", "")
            and "다음 단계" in todos[-1].get("content", "")
            and todos[-1].get("status") == "completed"
        )
        summary_todo_completed = all_todos_completed and last_todo_is_summary

        if not summary_todo_completed and any(
            t.get("status") == "completed" and "작업 요약" in t.get("content", "")
            for t in todos
        ):
            logger.debug(
                "Previous summary todo completed but new tasks exist - NOT treating as final summary"
            )

        # Check if summary content exists in messages
        messages = request.messages
        summary_exists = False
        for msg in messages[-15:]:
            msg_content = getattr(msg, "content", "") or ""
            if '"summary"' in msg_content and '"next_items"' in msg_content:
                summary_exists = True
                break
            if any(
                kw in msg_content
                for kw in [
                    "다음 단계 제안",
                    "다음 단계:",
                    "### 다음 단계",
                    "## 다음 단계",
                    "**다음 단계**",
                    "모든 작업이 완료",
                    "**작업 요약**",
                    "### 작업 요약",
                    "## 작업 요약",
                ]
            ):
                summary_exists = True
                break

        for attempt in range(max_retries + 1):
            response = handler(request)

            # If summary todo is completed AND summary content exists, accept empty response
            # This prevents infinite loop when inject_continuation_middleware returns empty AIMessage
            response_message = _extract_ai_message(response)
            if summary_todo_completed and summary_exists:
                has_content_check = (
                    bool(getattr(response_message, "content", None))
                    if response_message
                    else False
                )
                has_tool_calls_check = (
                    bool(getattr(response_message, "tool_calls", None))
                    if response_message
                    else False
                )
                if not has_content_check and not has_tool_calls_check:
                    logger.info(
                        "Summary todo completed AND summary exists - accepting empty response (agent should stop)"
                    )
                    return response

            # Extract AIMessage from response
            response_message = _extract_ai_message(response)

            has_content = (
                bool(getattr(response_message, "content", None))
                if response_message
                else False
            )
            has_tool_calls = (
                bool(getattr(response_message, "tool_calls", None))
                if response_message
                else False
            )

            logger.info(
                "handle_empty_response: attempt=%d, type=%s, content=%s, tool_calls=%s",
                attempt + 1,
                type(response_message).__name__ if response_message else None,
                has_content,
                has_tool_calls,
            )

            # Valid response with tool_calls
            if has_tool_calls:
                return response

            # Try to extract and repair tool_calls from additional_kwargs
            # Some LLMs (e.g., gpt-oss-120b) put tool_calls in additional_kwargs
            # but with malformed arguments (missing '{', broken JSON, etc.)
            if response_message and not has_tool_calls:
                repaired_message = try_extract_tool_calls_from_additional_kwargs(
                    response_message
                )
                if repaired_message and repaired_message.tool_calls:
                    logger.info(
                        "Repaired tool_calls from additional_kwargs: %d calls",
                        len(repaired_message.tool_calls),
                    )
                    response = _replace_ai_message_in_response(
                        response, repaired_message
                    )
                    return response

            # Try to parse JSON from content
            if has_content and response_message:
                parsed = parse_json_tool_call(response_message.content)
                if parsed:
                    tool_name = parsed.get("tool", "")
                    arguments = parsed.get("arguments", {})
                    logger.info(
                        "Parsed JSON tool call from content: tool=%s",
                        tool_name,
                    )

                    new_message = create_tool_call_message(tool_name, arguments)
                    response = _replace_ai_message_in_response(response, new_message)
                    return response

                # Check if content is summary JSON (for summary todo)
                # Summary JSON has "summary" and "next_items" but no "tool"
                # IMPORTANT: Check for summary JSON pattern FIRST, regardless of current todo
                # This handles cases where LLM outputs summary JSON mixed with other content
                content = response_message.content
                if isinstance(content, list):
                    content = " ".join(str(p) for p in content)

                # Check if content contains summary JSON pattern
                has_summary_pattern = (
                    '"summary"' in content or "'summary'" in content
                ) and ('"next_items"' in content or "'next_items'" in content)

                if has_summary_pattern:
                    # Check if pending todos exist - if so, don't force complete
                    current_todos = request.state.get("todos", [])
                    pending_todos = [
                        t
                        for t in current_todos
                        if isinstance(t, dict) and t.get("status") == "pending"
                    ]
                    if pending_todos:
                        logger.warning(
                            "Summary JSON detected but pending todos remain - not forcing completion: %s",
                            [t.get("content", "")[:30] for t in pending_todos],
                        )
                        # Don't synthesize completion, return response as-is
                        # Let LLM continue working on pending todos
                    else:
                        # No pending todos, safe to synthesize completion
                        # Try to extract and repair summary JSON from mixed content
                        try:
                            # Try to find JSON object containing summary
                            import re

                            json_match = re.search(
                                r'\{[^{}]*"summary"[^{}]*"next_items"[^{}]*\}',
                                content,
                                re.DOTALL,
                            )
                            if json_match:
                                repaired_summary = repair_json(
                                    json_match.group(), return_objects=True
                                )
                            else:
                                repaired_summary = repair_json(
                                    content, return_objects=True
                                )

                            if (
                                isinstance(repaired_summary, dict)
                                and "summary" in repaired_summary
                                and "next_items" in repaired_summary
                            ):
                                # Create new message with repaired JSON content
                                repaired_content = json.dumps(
                                    repaired_summary, ensure_ascii=False
                                )
                                logger.info(
                                    "Detected and repaired summary JSON in content (pattern-based detection)"
                                )
                                # Create message with repaired content
                                repaired_response_message = AIMessage(
                                    content=repaired_content,
                                    tool_calls=getattr(
                                        response_message, "tool_calls", []
                                    )
                                    or [],
                                )
                                synthetic_message = _create_synthetic_completion(
                                    request,
                                    repaired_response_message,
                                    has_content=True,
                                )
                                response = _replace_ai_message_in_response(
                                    response, synthetic_message
                                )
                                return response
                        except Exception as e:
                            logger.debug(
                                f"Failed to extract summary JSON from mixed content: {e}"
                            )

                        # Fallback: accept as-is if repair failed but looks like summary
                        logger.info(
                            "Detected summary JSON pattern in content - accepting and synthesizing write_todos"
                        )
                        synthetic_message = _create_synthetic_completion(
                            request, response_message, has_content=True
                        )
                        response = _replace_ai_message_in_response(
                            response, synthetic_message
                        )
                        return response

                # Legacy: Also check if current todo is a summary todo (backward compatibility)
                todos = request.state.get("todos", [])
                in_progress_todos = [
                    t for t in todos if t.get("status") == "in_progress"
                ]
                pending_todos = [t for t in todos if t.get("status") == "pending"]
                current_todo = (
                    in_progress_todos[0]
                    if in_progress_todos
                    else pending_todos[0]
                    if pending_todos
                    else None
                )
                if current_todo:
                    summary_keywords = [
                        "작업 요약",
                        "결과 요약",
                        "분석 요약",
                        "요약 및",
                        "다음단계",
                        "다음 단계",
                        "next step",
                    ]
                    is_summary_todo = any(
                        kw in current_todo.get("content", "") for kw in summary_keywords
                    )
                    if is_summary_todo and (
                        '"summary"' in content or "'summary'" in content
                    ):
                        # This is a summary todo with summary content - accept it
                        logger.info(
                            "Summary todo with summary content detected - accepting"
                        )
                        synthetic_message = _create_synthetic_completion(
                            request, response_message, has_content=True
                        )
                        response = _replace_ai_message_in_response(
                            response, synthetic_message
                        )
                        return response

            # Invalid response - retry with JSON schema prompt
            if response_message and attempt < max_retries:
                reason = "text-only" if has_content else "empty"

                json_prompt = _build_json_prompt(request, response_message, has_content)

                # If _build_json_prompt returns None, skip retry and synthesize write_todos
                # This happens when: all todos completed OR current todo is summary/next_steps
                if json_prompt is None:
                    logger.info(
                        "Skipping retry for %s response, synthesizing write_todos with content",
                        reason,
                    )
                    # Synthesize write_todos while preserving the content (summary)
                    synthetic_message = _create_synthetic_completion(
                        request, response_message, has_content
                    )
                    response = _replace_ai_message_in_response(
                        response, synthetic_message
                    )
                    return response

                logger.warning(
                    "Invalid AIMessage (%s) detected (attempt %d/%d). "
                    "Retrying with JSON schema prompt...",
                    reason,
                    attempt + 1,
                    max_retries + 1,
                )
                if reason == "text-only":
                    _log_invalid_ai_message(response_message, reason)

                request = request.override(
                    messages=request.messages + [HumanMessage(content=json_prompt)]
                )
                continue

            # Max retries exhausted - synthesize write_todos to complete
            if response_message:
                # Check if todos are already all completed - if so, just return
                todos = request.state.get("todos", [])
                pending_todos = [
                    t for t in todos if t.get("status") in ("pending", "in_progress")
                ]
                if todos and not pending_todos:
                    logger.info(
                        "Max retries exhausted but all todos completed - returning response as-is"
                    )
                    return response

                logger.warning(
                    "Max retries exhausted. Synthesizing write_todos to complete."
                )
                synthetic_message = _create_synthetic_completion(
                    request, response_message, has_content
                )
                response = _replace_ai_message_in_response(response, synthetic_message)
                return response

            return response

        return response

    return handle_empty_response


def _extract_ai_message(response):
    """Extract AIMessage from various response formats."""
    if hasattr(response, "result"):
        result = response.result
        if isinstance(result, list):
            for msg in reversed(result):
                if isinstance(msg, AIMessage):
                    return msg
        elif isinstance(result, AIMessage):
            return result
    elif hasattr(response, "message"):
        return response.message
    elif hasattr(response, "messages") and response.messages:
        return response.messages[-1]
    elif isinstance(response, AIMessage):
        return response
    return None


def _log_invalid_ai_message(response_message, reason: str) -> None:
    """Log full AIMessage details for invalid (text-only) responses."""
    if not response_message:
        return
    try:
        payload = _serialize_message(response_message)
    except Exception as exc:
        logger.warning(
            "Invalid AIMessage detail (%s): failed to serialize (%s). Raw=%r",
            reason,
            exc,
            response_message,
        )
        return
    logger.warning("Invalid AIMessage detail (%s): %s", reason, _pretty_json(payload))


def _replace_ai_message_in_response(response, new_message):
    """Replace AIMessage in response with a new one."""
    if hasattr(response, "result"):
        if isinstance(response.result, list):
            new_result = [
                new_message if isinstance(m, AIMessage) else m for m in response.result
            ]
            response.result = new_result
        else:
            response.result = new_message
    return response


def _build_json_prompt(request, response_message, has_content):
    """Build JSON-forcing prompt based on context."""
    todos = request.state.get("todos", [])
    pending_todos = [t for t in todos if t.get("status") in ("pending", "in_progress")]
    in_progress_todos = [t for t in todos if t.get("status") == "in_progress"]

    # Check if CURRENT todo (first in_progress or first pending) is summary/next_steps
    # Not checking ALL pending todos - only the one we should be working on now
    summary_keywords = [
        "작업 요약",
        "결과 요약",
        "분석 요약",
        "요약 및",
        "다음단계",
        "다음 단계",
        "next step",
    ]
    current_todo = (
        in_progress_todos[0]
        if in_progress_todos
        else pending_todos[0]
        if pending_todos
        else None
    )
    is_summary_todo = current_todo is not None and any(
        kw in current_todo.get("content", "") for kw in summary_keywords
    )

    if has_content:
        # If all todos completed, don't force another tool call
        if todos and not pending_todos:
            return None  # Signal to skip retry

        # If current todo is "작업 요약 및 다음단계 제시", accept text-only response
        # The LLM is outputting the summary, we'll synthesize write_todos
        if is_summary_todo:
            summary_todo = next(
                (
                    t
                    for t in pending_todos
                    if any(kw in t.get("content", "") for kw in summary_keywords)
                ),
                {"content": "summary"},
            )
            logger.info(
                "Current todo is summary/next steps ('%s'), accepting text-only response",
                summary_todo.get("content", "")[:30],
            )
            return (
                None  # Signal to skip retry - will synthesize write_todos with content
            )

        return (
            f"{JSON_TOOL_SCHEMA}\n\n"
            f"Your previous response was text, not JSON. "
            f"Call the next appropriate tool to continue.\n"
            f'Example: {{"tool": "jupyter_cell_tool", "arguments": {{"code": "print(\'hello\')"}}}}'
        )
    elif is_summary_todo:
        # Empty response but current todo is summary - force summary JSON output
        logger.info(
            "Empty response but current todo is summary/next steps - forcing summary JSON prompt"
        )
        return (
            f"{JSON_TOOL_SCHEMA}\n\n"
            f"You MUST output a summary JSON with next_items. This is the final step.\n"
            f"출력 형식 (반드시 이 형식으로 출력):\n"
            f'{{"summary": "완료된 작업 요약 (한국어)", "next_items": [{{"subject": "다음 작업 제목", "description": "설명"}}]}}\n\n'
            f"Do NOT call any tool. Just output the summary JSON directly in your response."
        )
    elif pending_todos:
        todo_list = ", ".join(t.get("content", "")[:20] for t in pending_todos[:3])
        example_json = '{"tool": "jupyter_cell_tool", "arguments": {"code": "import pandas as pd\\ndf = pd.read_csv(\'titanic.csv\')\\nprint(df.head())"}}'
        return (
            f"{JSON_TOOL_SCHEMA}\n\n"
            f"Pending tasks: {todo_list}\n"
            f"Call jupyter_cell_tool with Python code to complete the next task.\n"
            f"Example: {example_json}"
        )
    elif not todos:
        # No todos yet = new task starting, LLM must create todos or call a tool
        # This happens when LLM returns empty response at the start of a new task
        logger.info("No todos exist yet - forcing retry to create todos or call tool")
        return (
            f"{JSON_TOOL_SCHEMA}\n\n"
            f"Your response was empty. You MUST call a tool to proceed.\n"
            f"한국어로 응답하고, write_todos로 작업 목록을 만들거나 jupyter_cell_tool/read_file_tool을 호출하세요.\n"
            f'Example: {{"tool": "write_todos", "arguments": {{"todos": [{{"content": "데이터 분석", "status": "in_progress"}}]}}}}'
        )
    else:
        # Todos exist but all completed - ask for summary
        logger.info("All todos completed but response empty - asking for summary")
        return (
            f"{JSON_TOOL_SCHEMA}\n\n"
            f"All tasks completed. Call markdown_tool to provide a summary in Korean.\n"
            f"한국어로 작업 요약을 작성하세요.\n"
            f'Example: {{"tool": "markdown_tool", "arguments": {{"content": "작업이 완료되었습니다."}}}}'
        )


def _create_synthetic_completion(request, response_message, has_content):
    """Create synthetic write_todos call to mark all todos as completed.

    This triggers automatic session termination via router's all_todos_completed check.
    Preserves the LLM's text content (summary) if present.
    """
    todos = request.state.get("todos", [])

    # Warn if there are pending todos being force-completed
    pending_count = sum(1 for t in todos if t.get("status") == "pending")
    if pending_count > 0:
        logger.warning(
            "Force-completing %d pending todos that were never started: %s",
            pending_count,
            [t.get("content") for t in todos if t.get("status") == "pending"],
        )

    # Mark all todos as completed
    completed_todos = (
        [{**todo, "status": "completed"} for todo in todos]
        if todos
        else [{"content": "작업 완료", "status": "completed"}]
    )

    # Preserve original content (summary JSON) if present
    original_content = ""
    if has_content and response_message and response_message.content:
        original_content = response_message.content
        logger.info(
            "Creating synthetic write_todos with preserved content (length=%d)",
            len(original_content),
        )
    else:
        logger.info(
            "Creating synthetic write_todos to mark %d todos as completed",
            len(completed_todos),
        )

    return AIMessage(
        content=original_content,  # Preserve the summary content for UI
        tool_calls=[
            {
                "name": "write_todos",
                "args": {"todos": completed_todos},
                "id": str(uuid.uuid4()),
                "type": "tool_call",
            }
        ],
    )


def create_limit_tool_calls_middleware(wrap_model_call):
    """Create middleware to limit model to one tool call at a time.

    Some models (like vLLM GPT) return multiple tool calls in a single response.
    This causes conflicts with TodoListMiddleware when processing multiple decisions.
    By limiting to one tool call, we ensure the agent processes actions sequentially.

    Args:
        wrap_model_call: LangChain's wrap_model_call decorator

    Returns:
        Middleware function
    """

    @wrap_model_call
    @_with_middleware_logging("limit_tool_calls_to_one")
    def limit_tool_calls_to_one(request, handler):
        response = handler(request)

        if hasattr(response, "result"):
            result = response.result
            messages = result if isinstance(result, list) else [result]

            for msg in messages:
                if isinstance(msg, AIMessage) and hasattr(msg, "tool_calls"):
                    tool_calls = msg.tool_calls
                    if tool_calls and len(tool_calls) > 1:
                        logger.info(
                            "Limiting tool calls from %d to 1 (keeping first: %s)",
                            len(tool_calls),
                            tool_calls[0].get("name", "unknown")
                            if tool_calls
                            else "none",
                        )
                        msg.tool_calls = [tool_calls[0]]

                    # Remove additional_kwargs["tool_calls"] entirely when
                    # msg.tool_calls exists. ChatOpenAI duplicates tool_calls
                    # into additional_kwargs, and leftover entries pollute the
                    # conversation context - LLM sees them and assumes all
                    # listed tool calls were executed.
                    additional_kwargs = getattr(msg, "additional_kwargs", {})
                    if msg.tool_calls and additional_kwargs.get("tool_calls"):
                        removed_count = len(additional_kwargs["tool_calls"])
                        del additional_kwargs["tool_calls"]
                        logger.info(
                            "Removed %d tool_calls from additional_kwargs "
                            "(canonical source: msg.tool_calls)",
                            removed_count,
                        )

                    # Clear content when tool_calls exist to avoid duplicate information
                    # Some models return both content and tool_calls, causing redundant
                    # "thinking" text in the conversation history
                    if msg.tool_calls and msg.content:
                        logger.info(
                            "Clearing AIMessage content (len=%d) because tool_calls exist",
                            len(msg.content),
                        )
                        msg.content = ""

        return response

    return limit_tool_calls_to_one


def _get_string_params_from_tools(tools) -> Dict[str, set]:
    """Extract string parameter names from tool schemas.

    Analyzes each tool's Pydantic args_schema to determine which parameters
    should be strings (not arrays).

    Args:
        tools: List of LangChain tools

    Returns:
        Dict mapping tool names to sets of string parameter names
    """
    from typing import get_args, get_origin

    tool_string_params: Dict[str, set] = {}

    for tool in tools:
        tool_name = getattr(tool, "name", None)
        if not tool_name:
            continue

        args_schema = getattr(tool, "args_schema", None)
        if not args_schema:
            continue

        string_params = set()

        # Get field annotations from Pydantic model
        try:
            annotations = getattr(args_schema, "__annotations__", {})
            for field_name, field_type in annotations.items():
                origin = get_origin(field_type)

                # Check if it's a simple str type
                if field_type is str:
                    string_params.add(field_name)
                # Check if it's Optional[str] (Union[str, None])
                elif origin is type(None) or str(origin) == "typing.Union":
                    args = get_args(field_type)
                    if str in args:
                        string_params.add(field_name)
        except Exception as e:
            logger.debug("Failed to analyze schema for tool %s: %s", tool_name, e)

        if string_params:
            tool_string_params[tool_name] = string_params
            logger.debug("Tool %s string params: %s", tool_name, string_params)

    return tool_string_params


def create_normalize_tool_args_middleware(wrap_model_call, tools=None):
    """Create middleware to normalize tool call arguments.

    Gemini sometimes returns tool call arguments with list values instead of strings.
    This middleware converts list arguments to strings ONLY for parameters that
    are defined as str in the tool's Pydantic schema.

    Args:
        wrap_model_call: LangChain's wrap_model_call decorator
        tools: Optional list of tools to analyze for type information

    Returns:
        Middleware function
    """

    # Build tool -> string params mapping from tool schemas
    tool_string_params: Dict[str, set] = {}
    if tools:
        tool_string_params = _get_string_params_from_tools(tools)
        logger.info(
            "Initialized normalize_tool_args with %d tools: %s",
            len(tool_string_params),
            {k: list(v) for k, v in tool_string_params.items()},
        )

    @wrap_model_call
    @_with_middleware_logging("normalize_tool_args")
    def normalize_tool_args(request, handler):
        response = handler(request)

        if hasattr(response, "result"):
            result = response.result
            messages = result if isinstance(result, list) else [result]

            for msg in messages:
                if isinstance(msg, AIMessage) and hasattr(msg, "tool_calls"):
                    tool_calls = msg.tool_calls
                    if tool_calls:
                        for tool_call in tool_calls:
                            tool_name = tool_call.get("name", "")
                            # Normalize tool name (e.g., write_todos_tool → write_todos)
                            normalized_name = normalize_tool_name(tool_name)
                            if normalized_name != tool_name:
                                logger.info(
                                    "Normalized tool name: %s → %s",
                                    tool_name,
                                    normalized_name,
                                )
                                tool_call["name"] = normalized_name
                                tool_name = normalized_name
                            string_params = tool_string_params.get(tool_name, set())

                            if "args" in tool_call and isinstance(
                                tool_call["args"], dict
                            ):
                                args = tool_call["args"]
                                # Normalize list arguments to strings for str-typed params
                                for key, value in args.items():
                                    if key in string_params and isinstance(value, list):
                                        # Join list items into a single string
                                        text_parts = []
                                        for part in value:
                                            if isinstance(part, str):
                                                text_parts.append(part)
                                            elif (
                                                isinstance(part, dict)
                                                and part.get("type") == "text"
                                            ):
                                                text_parts.append(part.get("text", ""))

                                        if text_parts:
                                            normalized_value = "\n".join(text_parts)
                                            logger.info(
                                                "Normalized list argument '%s' to string (length=%d) for tool '%s'",
                                                key,
                                                len(normalized_value),
                                                tool_name,
                                            )
                                            args[key] = normalized_value

                                # Validate write_todos: Only ONE item should be in_progress at a time
                                if tool_name == "write_todos" and "todos" in args:
                                    todos = args["todos"]
                                    if isinstance(todos, list) and len(todos) > 0:
                                        # Validate: Only ONE item should be in_progress at a time
                                        # If multiple in_progress, keep only the first one
                                        in_progress_count = sum(
                                            1
                                            for t in todos
                                            if isinstance(t, dict)
                                            and t.get("status") == "in_progress"
                                        )
                                        if in_progress_count > 1:
                                            found_first = False
                                            for todo in todos:
                                                if not isinstance(todo, dict):
                                                    continue
                                                if todo.get("status") == "in_progress":
                                                    if found_first:
                                                        # Reset subsequent in_progress to pending
                                                        todo["status"] = "pending"
                                                        logger.info(
                                                            "Reset duplicate in_progress todo to pending: %s",
                                                            todo.get("content", "")[
                                                                :30
                                                            ],
                                                        )
                                                    else:
                                                        found_first = True

                                        # Validate: "작업 요약 및 다음 단계 제시" cannot be in_progress if pending todos exist
                                        # This prevents LLM from skipping pending tasks
                                        summary_keywords = [
                                            "작업 요약",
                                            "다음 단계 제시",
                                        ]
                                        for i, todo in enumerate(todos):
                                            if not isinstance(todo, dict):
                                                continue
                                            content = todo.get("content", "")
                                            is_summary_todo = any(
                                                kw in content for kw in summary_keywords
                                            )

                                            if (
                                                is_summary_todo
                                                and todo.get("status") == "in_progress"
                                            ):
                                                # Check if there are pending todos before this one
                                                pending_before = [
                                                    t
                                                    for t in todos[:i]
                                                    if isinstance(t, dict)
                                                    and t.get("status") == "pending"
                                                ]
                                                if pending_before:
                                                    # Revert summary todo to pending
                                                    todo["status"] = "pending"
                                                    # Set the first pending todo to in_progress
                                                    for t in todos:
                                                        if (
                                                            isinstance(t, dict)
                                                            and t.get("status")
                                                            == "pending"
                                                        ):
                                                            t["status"] = "in_progress"
                                                            logger.warning(
                                                                "Reverted summary todo to pending, set '%s' to in_progress (pending todos exist)",
                                                                t.get("content", "")[
                                                                    :30
                                                                ],
                                                            )
                                                            break
                                                    break

        return response

    return normalize_tool_args


def create_continuation_control_middleware(wrap_model_call):
    """Create unified middleware for continuation control.

    This middleware combines two functions:
    1. BEFORE handler: Inject continuation prompt after non-HITL tool execution
       - Checks for summary completion and stops if done
       - Injects "[SYSTEM] Tool completed..." messages to guide LLM
    2. AFTER handler: Prevent auto-continuation after summary JSON output
       - Strips write_todos from responses containing summary JSON
       - Prevents agent from auto-creating new todos after task completion

    Args:
        wrap_model_call: LangChain's wrap_model_call decorator

    Returns:
        Middleware function
    """

    def _check_summary_exists(messages, last_real_human_idx: int) -> bool:
        """Check if summary content exists in messages after last real user message."""
        messages_to_check = (
            messages[last_real_human_idx + 1 :]
            if last_real_human_idx >= 0
            else messages[-15:]
        )
        for msg in messages_to_check:
            msg_content = getattr(msg, "content", "") or ""
            # Check for summary JSON
            if '"summary"' in msg_content and '"next_items"' in msg_content:
                return True
            # Check for markdown summary (common patterns)
            if any(
                kw in msg_content
                for kw in [
                    "다음 단계 제안",
                    "다음 단계:",
                    "### 다음 단계",
                    "## 다음 단계",
                    "**다음 단계**",
                    "모든 작업이 완료",
                    "**작업 요약**",
                    "### 작업 요약",
                    "## 작업 요약",
                ]
            ):
                return True
        return False

    def _find_last_real_human_idx(messages) -> int:
        """Find index of last real HumanMessage (not system-injected)."""
        last_real_human_idx = -1
        for i, msg in enumerate(messages):
            msg_type = getattr(msg, "type", "") or type(msg).__name__
            if msg_type in ("human", "HumanMessage"):
                msg_content = getattr(msg, "content", "") or ""
                if not msg_content.startswith("[SYSTEM]"):
                    last_real_human_idx = i
        return last_real_human_idx

    @wrap_model_call
    @_with_middleware_logging("continuation_control")
    def continuation_control(request, handler):
        messages = request.messages

        # ===== BEFORE HANDLER: Inject continuation prompt =====
        if messages:
            last_msg = messages[-1]
            if getattr(last_msg, "type", "") == "tool":
                tool_name = getattr(last_msg, "name", "") or ""

                # Try to extract tool name from content
                if not tool_name:
                    try:
                        content_json = json.loads(last_msg.content)
                        tool_name = content_json.get("tool", "")
                    except (json.JSONDecodeError, TypeError, AttributeError):
                        pass

                if tool_name in NON_HITL_TOOLS:
                    todos = request.state.get("todos", [])

                    last_real_human_idx = _find_last_real_human_idx(messages)
                    summary_exists = _check_summary_exists(
                        messages, last_real_human_idx
                    )

                    # STOP if summary exists (regardless of todo status)
                    if summary_exists:
                        logger.info(
                            "Summary exists after tool: %s - stopping agent (user must request next steps)",
                            tool_name,
                        )
                        return AIMessage(content="", tool_calls=[])

                    pending_todos = [
                        t
                        for t in todos
                        if t.get("status") in ("pending", "in_progress")
                    ]

                    # If all todos completed but no summary yet, allow LLM call for summary
                    if not pending_todos and todos:
                        logger.info(
                            "All %d todos completed, no summary yet after tool: %s - allowing LLM for summary",
                            len(todos),
                            tool_name,
                        )

                    logger.info(
                        "Injecting continuation prompt after non-HITL tool: %s",
                        tool_name,
                    )

                    # Skip continuation injection for write_todos
                    # This prevents auto-continuation to next task after completing one
                    # Agent will decide next action based on its own reasoning
                    if tool_name == "write_todos":
                        logger.info(
                            "Skipping continuation prompt after write_todos - "
                            "agent decides next action (pending: %d)",
                            len(pending_todos) if pending_todos else 0,
                        )
                        # Don't inject continuation - let agent naturally continue or stop
                    elif pending_todos:
                        pending_list = ", ".join(
                            t.get("content", "")[:30] for t in pending_todos[:3]
                        )
                        continuation = (
                            f"Tool '{tool_name}' completed. "
                            f"Continue with pending tasks: {pending_list}. "
                            f"Call jupyter_cell_tool or the next appropriate tool."
                        )
                        new_messages = list(messages) + [
                            HumanMessage(content=f"[SYSTEM] {continuation}")
                        ]
                        request = request.override(messages=new_messages)
                    else:
                        continuation = (
                            f"Tool '{tool_name}' completed. "
                            f"Create a todo list with write_todos if needed."
                        )
                        new_messages = list(messages) + [
                            HumanMessage(content=f"[SYSTEM] {continuation}")
                        ]
                        request = request.override(messages=new_messages)

        # ===== CALL HANDLER =====
        response = handler(request)

        # ===== AFTER HANDLER: Strip write_todos if summary JSON present =====
        response_message = _extract_ai_message(response)
        if not response_message:
            return response

        # Get content - handle both string and list formats
        content = getattr(response_message, "content", "") or ""
        if isinstance(content, list):
            content = " ".join(
                str(p) if isinstance(p, str) else p.get("text", "")
                for p in content
                if isinstance(p, (str, dict))
            )

        # Check if content contains summary JSON pattern
        has_summary_json = '"summary"' in content and '"next_items"' in content

        if has_summary_json:
            tool_calls = getattr(response_message, "tool_calls", []) or []
            write_todos_calls = [
                tc for tc in tool_calls if tc.get("name") == "write_todos"
            ]

            if write_todos_calls:
                logger.info(
                    "Summary JSON 감지 - write_todos 호출 제거 (자동 계속 방지). "
                    "제거된 write_todos 호출 수: %d",
                    len(write_todos_calls),
                )

                filtered_tool_calls = [
                    tc for tc in tool_calls if tc.get("name") != "write_todos"
                ]

                new_message = AIMessage(
                    content=response_message.content,
                    tool_calls=filtered_tool_calls,
                    additional_kwargs=getattr(
                        response_message, "additional_kwargs", {}
                    ),
                    response_metadata=getattr(
                        response_message, "response_metadata", {}
                    ),
                )

                response = _replace_ai_message_in_response(response, new_message)

        return response

    return continuation_control


# Backward compatibility aliases
def create_inject_continuation_middleware(wrap_model_call):
    """Deprecated: Use create_continuation_control_middleware instead."""
    return create_continuation_control_middleware(wrap_model_call)


def create_prevent_auto_continuation_middleware(wrap_model_call):
    """Deprecated: Use create_continuation_control_middleware instead."""
    return create_continuation_control_middleware(wrap_model_call)


def create_patch_tool_calls_middleware(AgentMiddleware, ToolMessage, Overwrite):
    """Create middleware to patch dangling tool calls.

    When a new user message arrives before a tool call completes, we need to
    add synthetic ToolMessage responses for those dangling calls so the
    conversation can continue properly.

    Args:
        AgentMiddleware: LangChain's AgentMiddleware base class
        ToolMessage: LangChain's ToolMessage class
        Overwrite: LangGraph's Overwrite type

    Returns:
        PatchToolCallsMiddleware class instance
    """

    class PatchToolCallsMiddleware(AgentMiddleware):
        """Patch dangling tool calls so the agent can continue."""

        def before_agent(self, state, runtime):
            logger.info(
                "%s",
                _format_middleware_marker(
                    "PatchToolCallsMiddleware.before_agent", "START"
                ),
            )
            messages = state.get("messages", [])
            if not messages:
                logger.info(
                    "%s",
                    _format_middleware_marker(
                        "PatchToolCallsMiddleware.before_agent", "NOOP"
                    ),
                )
                return None

            patched = []
            for i, msg in enumerate(messages):
                patched.append(msg)
                if getattr(msg, "type", "") == "ai" and getattr(
                    msg, "tool_calls", None
                ):
                    for tool_call in msg.tool_calls:
                        tool_call_id = tool_call.get("id")
                        if not tool_call_id:
                            continue
                        has_tool_msg = any(
                            (
                                getattr(m, "type", "") == "tool"
                                and getattr(m, "tool_call_id", None) == tool_call_id
                            )
                            for m in messages[i:]
                        )
                        if not has_tool_msg:
                            tool_msg = (
                                f"Tool call {tool_call.get('name', 'unknown')} with id {tool_call_id} "
                                "was cancelled - another message came in before it could be completed."
                            )
                            patched.append(
                                ToolMessage(
                                    content=tool_msg,
                                    name=tool_call.get("name", "unknown"),
                                    tool_call_id=tool_call_id,
                                )
                            )

            if patched == messages:
                logger.info(
                    "%s",
                    _format_middleware_marker(
                        "PatchToolCallsMiddleware.before_agent", "NOOP"
                    ),
                )
                return None
            logger.info(
                "%s",
                _format_middleware_marker(
                    "PatchToolCallsMiddleware.before_agent", "PATCHED"
                ),
            )
            return {"messages": Overwrite(patched)}

    return PatchToolCallsMiddleware()
