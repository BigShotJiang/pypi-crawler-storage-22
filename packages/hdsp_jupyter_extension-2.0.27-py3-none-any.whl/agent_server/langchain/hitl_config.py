"""
Human-in-the-Loop (HITL) configuration for LangChain agent.

Defines which tools require user approval and their approval settings.
"""

from typing import Any, Dict


def get_hitl_interrupt_config() -> Dict[str, Any]:
    """Return HITL interrupt config for client-side tool execution.

    Returns:
        Dictionary mapping tool names to their HITL configuration:
        - False: No approval needed, execute immediately
        - Dict with allowed_decisions and description: Require approval

    The allowed_decisions can include:
        - "approve": Execute the tool as requested
        - "edit": Modify the tool arguments before execution
        - "reject": Cancel the tool execution
    """
    return {
        # Require approval before executing code
        "jupyter_cell_tool": {
            "allowed_decisions": ["approve", "edit", "reject"],
            "description": "코드 실행 승인 필요",
            "icon": "code",
        },
        # Ask user tool - requires user input (HITL)
        # Uses 'edit' decision to pass user's response via modified args
        "ask_user_tool": {
            "allowed_decisions": ["approve", "edit", "reject"],
            "description": "사용자 입력 대기 중",
            "icon": "help",
        },
        # Safe operations - no approval needed
        "markdown_tool": False,
        "read_file_tool": {
            "allowed_decisions": ["approve", "edit"],
            "description": "파일 읽기 실행 중",
            "icon": "description",
        },
        "write_todos": False,  # Todo updates don't need approval
        # Search tools need HITL for client-side execution (auto-approved by frontend)
        # Uses 'edit' decision to pass execution_result back
        "search_notebook_cells_tool": {
            "allowed_decisions": ["approve", "edit"],
            "description": "노트북 셀 검색 중",
            "icon": "search",
        },
        # Resource check tool for client-side execution (auto-approved by frontend)
        "check_resource_tool": {
            "allowed_decisions": ["approve", "edit"],
            "description": "시스템 리소스 확인 중",
            "icon": "analytics",
        },
        # Workspace exploration tools for client-side execution (auto-approved by frontend)
        "list_workspace_tool": {
            "allowed_decisions": ["approve", "edit"],
            "description": "작업 공간 파일 목록 조회 중",
            "icon": "folder",
        },
        "search_files_tool": {
            "allowed_decisions": ["approve", "edit"],
            "description": "파일 내용 검색 중",
            "icon": "search",
        },
        "execute_command_tool": {
            "allowed_decisions": ["approve", "edit", "reject"],
            "description": "쉘 명령어 실행 승인 필요",
            "icon": "terminal",
        },
        # File write requires approval
        "write_file_tool": {
            "allowed_decisions": ["approve", "edit", "reject"],
            "description": "파일 쓰기 승인 필요",
            "icon": "save",
        },
        # File edit requires approval (string replacement with diff preview)
        "edit_file_tool": {
            "allowed_decisions": ["approve", "edit", "reject"],
            "description": "파일 수정 승인 필요",
            "icon": "edit",
        },
        # Multi-edit requires approval (multiple string replacements atomically)
        "multiedit_file_tool": {
            "allowed_decisions": ["approve", "edit", "reject"],
            "description": "다중 파일 수정 승인 필요",
            "icon": "edit",
        },
    }
