"""
Middleware Module

Custom middleware for the multi-agent architecture:
- SubAgentMiddleware: Handles subagent delegation via task tool
- SkillMiddleware: Progressive skill loading for code generation agents
- Existing middleware from custom_middleware.py is also available
"""

from agent_server.langchain.middleware.skill_middleware import (
    SkillMiddleware,
    get_skill_middleware,
)
from agent_server.langchain.middleware.subagent_middleware import (
    SubAgentMiddleware,
    create_task_tool,
)

__all__ = [
    "SubAgentMiddleware",
    "create_task_tool",
    "SkillMiddleware",
    "get_skill_middleware",
]
