"""
CodeHistoryMiddleware

Middleware that tracks code execution history and automatically injects it
into subagent context when calling python_developer.

Features:
- Tracks jupyter_cell_tool, write_file_tool, edit_file_tool, multiedit_file_tool
- Automatically injects code history into task_tool context for python_developer
- Summarizes older history if total context exceeds 50k tokens
"""

import logging
import threading
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

import tiktoken

logger = logging.getLogger(__name__)

# Token limit for context (including system prompt)
MAX_CONTEXT_TOKENS = 50000
# Number of recent history entries to keep in full detail
RECENT_HISTORY_COUNT = 3
# Approximate system prompt token count for python_developer
PYTHON_DEV_SYSTEM_PROMPT_TOKENS = 2000


@dataclass
class CodeHistoryEntry:
    """Represents a single code execution or file operation."""

    tool_name: (
        str  # jupyter_cell_tool, write_file_tool, edit_file_tool, multiedit_file_tool
    )
    timestamp: datetime = field(default_factory=datetime.now)

    # For jupyter_cell_tool
    code: Optional[str] = None
    output: Optional[str] = None

    # For file operations
    file_path: Optional[str] = None
    content: Optional[str] = None  # For write_file
    old_content: Optional[str] = None  # For edit_file
    new_content: Optional[str] = None  # For edit_file
    edits: Optional[List[Dict[str, str]]] = None  # For multiedit_file

    def to_context_string(self) -> str:
        """Convert entry to a formatted string for context injection."""
        timestamp_str = self.timestamp.strftime("%H:%M:%S")

        if self.tool_name == "jupyter_cell_tool":
            output_preview = (
                self._truncate(self.output, 500) if self.output else "(no output)"
            )
            return f"""## Cell ({timestamp_str})
```python
{self.code}
```
Output:
```
{output_preview}
```"""

        elif self.tool_name == "write_file_tool":
            content_preview = self._truncate(self.content, 300) if self.content else ""
            return f"""## File Write ({timestamp_str})
Path: {self.file_path}
```
{content_preview}
```"""

        elif self.tool_name == "edit_file_tool":
            return f"""## File Edit ({timestamp_str})
Path: {self.file_path}
Change: `{self._truncate(self.old_content, 50)}` → `{self._truncate(self.new_content, 50)}`"""

        elif self.tool_name == "multiedit_file_tool":
            edit_count = len(self.edits) if self.edits else 0
            return f"""## File MultiEdit ({timestamp_str})
Path: {self.file_path}
Changes: {edit_count} edits applied"""

        return f"## Unknown ({timestamp_str})"

    def to_summary_string(self) -> str:
        """Convert entry to a brief summary string."""
        if self.tool_name == "jupyter_cell_tool":
            # Extract first meaningful line of code
            if self.code:
                first_line = self.code.strip().split("\n")[0][:60]
                return f"- Cell: {first_line}..."
            return "- Cell: (empty)"

        elif self.tool_name == "write_file_tool":
            return f"- Write: {self.file_path}"

        elif self.tool_name == "edit_file_tool":
            return f"- Edit: {self.file_path}"

        elif self.tool_name == "multiedit_file_tool":
            edit_count = len(self.edits) if self.edits else 0
            return f"- MultiEdit: {self.file_path} ({edit_count} changes)"

        return "- Unknown operation"

    @staticmethod
    def _truncate(text: Optional[str], max_length: int) -> str:
        """Truncate text to max_length."""
        if not text:
            return ""
        if len(text) <= max_length:
            return text
        return text[:max_length] + "..."


class CodeHistoryTracker:
    """
    Thread-safe tracker for code execution history.

    Tracks all code-related tool executions and provides methods to:
    - Add new entries
    - Get formatted history for context injection
    - Summarize old entries when context is too large
    """

    def __init__(self):
        self._history: List[CodeHistoryEntry] = []
        self._lock = threading.Lock()
        self._tokenizer = None

    def _get_tokenizer(self):
        """Lazy load tokenizer."""
        if self._tokenizer is None:
            try:
                self._tokenizer = tiktoken.get_encoding("cl100k_base")
            except Exception:
                self._tokenizer = None
        return self._tokenizer

    def _count_tokens(self, text: str) -> int:
        """Count tokens in text."""
        tokenizer = self._get_tokenizer()
        if tokenizer:
            try:
                return len(tokenizer.encode(text))
            except Exception:
                pass
        # Fallback: rough estimate (4 chars per token for mixed content)
        return len(text) // 4

    def add_jupyter_cell(self, code: str, output: str) -> None:
        """Track a jupyter_cell_tool execution."""
        with self._lock:
            entry = CodeHistoryEntry(
                tool_name="jupyter_cell_tool",
                code=code,
                output=output,
            )
            self._history.append(entry)
            logger.info(
                f"CodeHistory: Added jupyter_cell (total: {len(self._history)})"
            )

    def add_write_file(self, file_path: str, content: str) -> None:
        """Track a write_file_tool execution."""
        with self._lock:
            entry = CodeHistoryEntry(
                tool_name="write_file_tool",
                file_path=file_path,
                content=content,
            )
            self._history.append(entry)
            logger.info(
                f"CodeHistory: Added write_file {file_path} (total: {len(self._history)})"
            )

    def add_edit_file(self, file_path: str, old_content: str, new_content: str) -> None:
        """Track an edit_file_tool execution."""
        with self._lock:
            entry = CodeHistoryEntry(
                tool_name="edit_file_tool",
                file_path=file_path,
                old_content=old_content,
                new_content=new_content,
            )
            self._history.append(entry)
            logger.info(
                f"CodeHistory: Added edit_file {file_path} (total: {len(self._history)})"
            )

    def add_multiedit_file(self, file_path: str, edits: List[Dict[str, str]]) -> None:
        """Track a multiedit_file_tool execution."""
        with self._lock:
            entry = CodeHistoryEntry(
                tool_name="multiedit_file_tool",
                file_path=file_path,
                edits=edits,
            )
            self._history.append(entry)
            logger.info(
                f"CodeHistory: Added multiedit_file {file_path} (total: {len(self._history)})"
            )

    def get_context_for_subagent(
        self,
        existing_context: Optional[str] = None,
        max_tokens: int = MAX_CONTEXT_TOKENS,
        system_prompt_tokens: int = PYTHON_DEV_SYSTEM_PROMPT_TOKENS,
    ) -> str:
        """
        Get formatted code history for subagent context injection.

        If total context exceeds max_tokens, older entries are summarized.

        Args:
            existing_context: Existing context from task_tool call
            max_tokens: Maximum total tokens allowed
            system_prompt_tokens: Estimated tokens for system prompt

        Returns:
            Formatted context string with code history
        """
        with self._lock:
            if not self._history:
                return existing_context or ""

            # Calculate available tokens for history
            existing_tokens = (
                self._count_tokens(existing_context) if existing_context else 0
            )
            available_tokens = (
                max_tokens - system_prompt_tokens - existing_tokens - 500
            )  # 500 buffer

            # Build full history string
            full_history = self._build_full_history()
            full_history_tokens = self._count_tokens(full_history)

            logger.info(
                f"CodeHistory: existing={existing_tokens}, "
                f"history={full_history_tokens}, "
                f"available={available_tokens}, "
                f"entries={len(self._history)}"
            )

            # Check if we need to summarize
            if full_history_tokens <= available_tokens:
                # No summarization needed
                history_section = full_history
            else:
                # Need to summarize older entries
                history_section = self._build_summarized_history(available_tokens)

            # Combine with existing context
            if existing_context:
                return f"""{existing_context}

[코드 히스토리]
{history_section}"""
            else:
                return f"""[코드 히스토리]
{history_section}"""

    def _build_full_history(self) -> str:
        """Build full history string without summarization."""
        if not self._history:
            return ""

        parts = []
        for i, entry in enumerate(self._history, 1):
            parts.append(f"### {i}. {entry.to_context_string()}")

        return "\n\n".join(parts)

    def _build_summarized_history(self, available_tokens: int) -> str:
        """Build history with older entries summarized."""
        if len(self._history) <= RECENT_HISTORY_COUNT:
            # Not enough entries to summarize, just truncate
            return self._build_full_history()

        # Split into old (to summarize) and recent (keep full)
        old_entries = self._history[:-RECENT_HISTORY_COUNT]
        recent_entries = self._history[-RECENT_HISTORY_COUNT:]

        # Build summary of old entries
        summary_parts = ["[이전 작업 요약]"]
        for entry in old_entries:
            summary_parts.append(entry.to_summary_string())
        summary_section = "\n".join(summary_parts)

        # Build full recent entries
        recent_parts = ["\n[최근 코드 상세]"]
        for i, entry in enumerate(recent_entries, len(old_entries) + 1):
            recent_parts.append(f"### {i}. {entry.to_context_string()}")
        recent_section = "\n\n".join(recent_parts)

        combined = f"{summary_section}\n{recent_section}"

        # Check if still too long
        combined_tokens = self._count_tokens(combined)
        if combined_tokens > available_tokens:
            logger.warning(
                f"CodeHistory: Even summarized history ({combined_tokens}) "
                f"exceeds available tokens ({available_tokens}). Truncating."
            )
            # Further truncate by reducing recent entries
            recent_parts = ["\n[최근 코드 (일부)]"]
            for entry in recent_entries[-2:]:  # Keep only last 2
                recent_parts.append(entry.to_context_string())
            recent_section = "\n\n".join(recent_parts)
            combined = f"{summary_section}\n{recent_section}"

        return combined

    def clear(self) -> None:
        """Clear all history."""
        with self._lock:
            self._history.clear()
            logger.info("CodeHistory: Cleared all history")

    def get_entry_count(self) -> int:
        """Get number of history entries."""
        with self._lock:
            return len(self._history)


# Global tracker instances per threadId
_code_history_trackers: Dict[str, CodeHistoryTracker] = {}
_trackers_lock = threading.Lock()


def get_code_history_tracker(thread_id: Optional[str] = None) -> CodeHistoryTracker:
    """
    Get the CodeHistoryTracker instance for the given thread_id.

    Args:
        thread_id: Thread ID for session isolation. If None, returns a temporary tracker.

    Returns:
        CodeHistoryTracker instance for the thread
    """
    if thread_id is None:
        logger.warning(
            "get_code_history_tracker called without thread_id - using temporary tracker"
        )
        return CodeHistoryTracker()

    with _trackers_lock:
        if thread_id not in _code_history_trackers:
            _code_history_trackers[thread_id] = CodeHistoryTracker()
            logger.info(f"CodeHistory: Created new tracker for thread_id={thread_id}")
        return _code_history_trackers[thread_id]


def track_jupyter_cell(code: str, output: str, thread_id: Optional[str] = None) -> None:
    """Convenience function to track jupyter_cell_tool execution."""
    get_code_history_tracker(thread_id).add_jupyter_cell(code, output)


def track_write_file(
    file_path: str, content: str, thread_id: Optional[str] = None
) -> None:
    """Convenience function to track write_file_tool execution."""
    get_code_history_tracker(thread_id).add_write_file(file_path, content)


def track_edit_file(
    file_path: str,
    old_content: str,
    new_content: str,
    thread_id: Optional[str] = None,
) -> None:
    """Convenience function to track edit_file_tool execution."""
    get_code_history_tracker(thread_id).add_edit_file(
        file_path, old_content, new_content
    )


def track_multiedit_file(
    file_path: str,
    edits: List[Dict[str, str]],
    thread_id: Optional[str] = None,
) -> None:
    """Convenience function to track multiedit_file_tool execution."""
    get_code_history_tracker(thread_id).add_multiedit_file(file_path, edits)


def get_context_with_history(
    existing_context: Optional[str] = None,
    thread_id: Optional[str] = None,
) -> str:
    """Get context string with code history injected."""
    return get_code_history_tracker(thread_id).get_context_for_subagent(
        existing_context
    )


def clear_code_history(thread_id: Optional[str] = None) -> None:
    """
    Clear code history for a specific thread or all threads.

    Args:
        thread_id: Thread ID to clear. If None, clears all threads.
    """
    if thread_id is None:
        # Clear all trackers
        with _trackers_lock:
            for tid, tracker in _code_history_trackers.items():
                tracker.clear()
                logger.info(f"CodeHistory: Cleared history for thread_id={tid}")
            _code_history_trackers.clear()
            logger.info("CodeHistory: Cleared all thread trackers")
    else:
        # Clear specific thread
        with _trackers_lock:
            if thread_id in _code_history_trackers:
                _code_history_trackers[thread_id].clear()
                del _code_history_trackers[thread_id]
                logger.info(
                    f"CodeHistory: Cleared and removed tracker for thread_id={thread_id}"
                )
            else:
                logger.info(f"CodeHistory: No tracker found for thread_id={thread_id}")


def track_tool_execution(
    tool_name: str,
    args: Dict[str, Any],
    thread_id: Optional[str] = None,
) -> None:
    """
    Track a tool execution from HITL decision processing.

    This function is called from langchain_agent.py when an EDIT decision
    is processed with execution_result.

    Args:
        tool_name: Name of the tool (jupyter_cell_tool, write_file_tool, etc.)
        args: Tool arguments including execution_result
        thread_id: Thread ID for session isolation
    """
    if not args:
        return

    execution_result = args.get("execution_result", {})
    if not execution_result:
        return

    tracker = get_code_history_tracker(thread_id)

    if tool_name == "jupyter_cell_tool":
        code = args.get("code", "")
        output = execution_result.get("output", "")
        if code:
            tracker.add_jupyter_cell(code, output)
            logger.info(
                f"CodeHistory: Tracked jupyter_cell execution "
                f"(code len={len(code)}, thread_id={thread_id})"
            )

    elif tool_name == "write_file_tool":
        file_path = args.get("path", "")
        content = args.get("content", "")
        if file_path:
            tracker.add_write_file(file_path, content)
            logger.info(
                f"CodeHistory: Tracked write_file to {file_path} (thread_id={thread_id})"
            )

    elif tool_name == "edit_file_tool":
        file_path = args.get("path", "")
        old_string = args.get("old_string", "")
        new_string = args.get("new_string", "")
        if file_path:
            tracker.add_edit_file(file_path, old_string, new_string)
            logger.info(
                f"CodeHistory: Tracked edit_file to {file_path} (thread_id={thread_id})"
            )

    elif tool_name == "multiedit_file_tool":
        file_path = args.get("path", "")
        edits = args.get("edits", [])
        if file_path:
            # Convert edits to list of dicts if needed
            edits_as_dicts = []
            for edit in edits:
                if hasattr(edit, "model_dump"):
                    edits_as_dicts.append(edit.model_dump())
                elif hasattr(edit, "dict"):
                    edits_as_dicts.append(edit.dict())
                elif isinstance(edit, dict):
                    edits_as_dicts.append(edit)
            tracker.add_multiedit_file(file_path, edits_as_dicts)
            logger.info(
                f"CodeHistory: Tracked multiedit_file to {file_path} "
                f"({len(edits)} edits, thread_id={thread_id})"
            )
