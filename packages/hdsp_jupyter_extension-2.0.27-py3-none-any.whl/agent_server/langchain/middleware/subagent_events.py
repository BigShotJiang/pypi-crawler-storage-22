"""
Subagent Event Queue

Provides a thread-safe queue for subagent events that can be
consumed by the main streaming loop for UI display.

Events include:
- subagent_start: When a subagent is invoked
- subagent_tool_call: When a subagent calls a tool
- subagent_complete: When a subagent finishes
"""

import logging
import threading
from dataclasses import dataclass, field
from datetime import datetime
from queue import Empty, Queue
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# Thread-local storage for current subagent context
_subagent_context = threading.local()

# Global event queue (thread-safe)
_event_queue: Queue = Queue()


@dataclass
class SubagentEvent:
    """Represents a subagent event for UI display."""

    event_type: str  # subagent_start, subagent_tool_call, subagent_complete
    subagent_name: str
    tool_name: Optional[str] = None
    tool_args: Optional[Dict[str, Any]] = None
    description: Optional[str] = None
    result_preview: Optional[str] = None
    timestamp: datetime = field(default_factory=datetime.now)

    def to_debug_message(self) -> str:
        """Convert to debug message for UI display (legacy, for logging)."""
        if self.event_type == "subagent_start":
            desc_preview = self.description[:80] + "..." if self.description and len(self.description) > 80 else self.description
            return f"Subagent - {self.subagent_name} - 작업 시작: {desc_preview}"
        elif self.event_type == "subagent_tool_call":
            return f"Subagent - {self.subagent_name} - Tool 실행: {self.tool_name}"
        elif self.event_type == "subagent_complete":
            return f"Subagent - {self.subagent_name} - 완료"
        else:
            return f"Subagent - {self.subagent_name} - {self.event_type}"

    def to_status_dict(self) -> Dict[str, Any]:
        """Convert to status dict with icon for SSE streaming."""
        if self.event_type == "subagent_start":
            desc_preview = self.description[:80] + "..." if self.description and len(self.description) > 80 else self.description
            return {
                "status": f"Subagent - {self.subagent_name} - 작업 시작: {desc_preview}",
                "icon": "subagentStart"
            }
        elif self.event_type == "subagent_tool_call":
            return {
                "status": f"Subagent - {self.subagent_name} - Tool 실행: {self.tool_name}",
                "icon": "tool"
            }
        elif self.event_type == "subagent_complete":
            return {
                "status": f"Subagent - {self.subagent_name} - 완료",
                "icon": "subagentComplete"
            }
        else:
            return {
                "status": f"Subagent - {self.subagent_name} - {self.event_type}",
                "icon": "info"
            }


def set_current_subagent(name: str) -> None:
    """Set the current subagent context (for tool call tracking)."""
    _subagent_context.name = name
    logger.debug(f"Subagent context set: {name}")


def get_current_subagent() -> Optional[str]:
    """Get the current subagent name, if any."""
    return getattr(_subagent_context, "name", None)


def clear_current_subagent() -> None:
    """Clear the current subagent context."""
    _subagent_context.name = None


def emit_subagent_event(event: SubagentEvent) -> None:
    """Emit a subagent event to the queue."""
    _event_queue.put(event)
    logger.info(f"Subagent event: {event.to_debug_message()}")


def emit_subagent_start(name: str, description: str) -> None:
    """Emit a subagent start event."""
    emit_subagent_event(SubagentEvent(
        event_type="subagent_start",
        subagent_name=name,
        description=description,
    ))


def emit_subagent_tool_call(
    tool_name: str,
    tool_args: Optional[Dict] = None,
    subagent_name: Optional[str] = None,
) -> None:
    """
    Emit a subagent tool call event.

    Args:
        tool_name: Name of the tool being called
        tool_args: Optional arguments passed to the tool
        subagent_name: Explicit subagent name (fallback to thread-local context)
    """
    # Use explicit subagent_name or fall back to thread-local context
    name = subagent_name or get_current_subagent()

    if name:
        emit_subagent_event(SubagentEvent(
            event_type="subagent_tool_call",
            subagent_name=name,
            tool_name=tool_name,
            tool_args=tool_args,
        ))
    else:
        # Log warning but still emit with generic name for visibility
        logger.warning(f"No subagent context for tool call: {tool_name}")
        emit_subagent_event(SubagentEvent(
            event_type="subagent_tool_call",
            subagent_name="subagent",  # Generic fallback
            tool_name=tool_name,
            tool_args=tool_args,
        ))


def emit_subagent_complete(name: str, result_preview: Optional[str] = None) -> None:
    """Emit a subagent complete event."""
    emit_subagent_event(SubagentEvent(
        event_type="subagent_complete",
        subagent_name=name,
        result_preview=result_preview,
    ))


def drain_subagent_events() -> List[SubagentEvent]:
    """
    Drain all pending subagent events from the queue.

    Returns:
        List of SubagentEvent objects
    """
    events = []
    while True:
        try:
            event = _event_queue.get_nowait()
            events.append(event)
        except Empty:
            break
    return events


def get_pending_event_count() -> int:
    """Get the number of pending events in the queue."""
    return _event_queue.qsize()
