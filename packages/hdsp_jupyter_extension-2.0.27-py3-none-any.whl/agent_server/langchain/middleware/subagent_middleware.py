"""
SubAgentMiddleware

Middleware that enables subagent delegation via the `task` tool.
Based on Deep Agents library pattern (benchmarked, not installed).

Key features:
- Provides task(agent_name, description) tool for subagent invocation
- Context isolation: subagents run in clean context
- Synchronous execution: subagent returns result directly to caller
- Nested subagent support: python_developer can call athena_query
- Subagent caching: compiled agents are cached to avoid recompilation overhead
"""

import contextvars
import hashlib
import json
import logging
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from langchain_core.tools import tool
from pydantic import BaseModel, Field

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)

# Context variable to track the current main agent's thread_id
_current_thread_id: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "current_thread_id", default=None
)

# Global registry for subagent factories (set by AgentFactory)
_subagent_factory = None
_current_llm_config = None
# Subagent cache: key = "{agent_name}_{config_hash}" -> compiled agent
_subagent_cache: Dict[str, Any] = {}


def set_subagent_factory(factory_func, llm_config: Dict[str, Any]):
    """
    Set the subagent factory function.
    Called by AgentFactory during initialization.
    """
    global _subagent_factory, _current_llm_config, _subagent_cache
    _subagent_factory = factory_func
    _current_llm_config = llm_config
    # Clear cache when factory changes (new LLM config)
    _subagent_cache.clear()
    logger.info("SubAgentMiddleware factory initialized (cache cleared)")


def get_subagent_factory():
    """Get the current subagent factory function."""
    return _subagent_factory, _current_llm_config


def _get_config_hash(llm_config: Dict[str, Any]) -> str:
    """Generate a hash of llm_config for caching."""
    config_str = json.dumps(llm_config, sort_keys=True, default=str)
    return hashlib.md5(config_str.encode()).hexdigest()[:12]


def get_or_create_subagent(
    agent_name: str, factory_func, llm_config: Dict[str, Any]
) -> Any:
    """
    Get cached subagent or create new one.

    Caching avoids expensive recompilation of LangGraph agents.
    Cache key = "{agent_name}_{config_hash}" to handle different LLM configs.
    """
    global _subagent_cache

    config_hash = _get_config_hash(llm_config)
    cache_key = f"{agent_name}_{config_hash}"

    if cache_key in _subagent_cache:
        logger.info(f"Using cached subagent '{agent_name}' (key={cache_key})")
        return _subagent_cache[cache_key]

    logger.info(f"Creating new subagent '{agent_name}' (key={cache_key})...")
    subagent = factory_func(agent_name, llm_config)
    _subagent_cache[cache_key] = subagent
    logger.info(
        f"Cached subagent '{agent_name}' (total cached: {len(_subagent_cache)})"
    )

    return subagent


def clear_subagent_cache():
    """Clear the subagent cache. Useful for testing or config changes."""
    global _subagent_cache
    count = len(_subagent_cache)
    _subagent_cache.clear()
    logger.info(f"Subagent cache cleared ({count} entries removed)")


def set_current_thread_id(thread_id: str) -> None:
    """Set the current main agent's thread_id for code history tracking."""
    _current_thread_id.set(thread_id)
    logger.debug(f"Set current thread_id: {thread_id}")


def get_current_thread_id() -> Optional[str]:
    """Get the current main agent's thread_id."""
    return _current_thread_id.get()


def create_task_tool(
    caller_name: str,
    allowed_subagents: Optional[List[str]] = None,
):
    """
    Create a task tool for calling subagents.

    The task tool executes subagents synchronously and returns their result.
    Subagents like python_developer return generated code/analysis,
    which the Main Agent can then execute if needed.

    Args:
        caller_name: Name of the agent creating this tool (for logging/validation)
        allowed_subagents: Optional list of subagent names this agent can call.
                          If None, all subagents are allowed (for Main Agent).

    Returns:
        A tool that can be used to delegate tasks to subagents.
    """
    from agent_server.langchain.subagents.base import (
        SUBAGENT_CONFIGS,
        get_subagent_config,
    )

    # Build description based on allowed subagents
    if allowed_subagents:
        available = [
            f"- {name}: {SUBAGENT_CONFIGS[name].description}"
            for name in allowed_subagents
            if name in SUBAGENT_CONFIGS
        ]
    else:
        # Main Agent (planner) can call non-restricted subagents OR those explicitly allowing "planner"
        available = [
            f"- {config.name}: {config.description}"
            for config in SUBAGENT_CONFIGS.values()
            if not config.callable_by or caller_name in config.callable_by
        ]

    available_str = "\n".join(available)

    # Create Pydantic schema for the task tool (required for Gemini compatibility)
    class TaskInput(BaseModel):
        """Input schema for task tool"""

        agent_name: str = Field(
            description=f"Name of the subagent to invoke. Available: {', '.join(allowed_subagents) if allowed_subagents else 'python_developer, researcher, athena_query'}"
        )
        description: str = Field(
            description="Detailed task description for the subagent (Korean preferred)"
        )
        context: Optional[str] = Field(
            default=None,
            description="Additional context for the subagent: resource info (file sizes, memory), previous code, variable state, etc.",
        )

    @tool(args_schema=TaskInput)
    def task_tool(
        agent_name: str, description: str, context: Optional[str] = None
    ) -> str:
        """
        Delegate a task to a specialized subagent.

        The subagent will execute the task and return its result (code, analysis, etc.).
        Code execution tools (jupyter_cell_tool, write_file_tool) are handled by Main Agent.

        Args:
            agent_name: Name of the subagent to invoke
            description: Detailed task description for the subagent
            context: Additional context (resource info, previous code, etc.)

        Returns:
            Result from the subagent execution (string summary or generated code)
        """
        # Validate subagent exists
        if agent_name not in SUBAGENT_CONFIGS:
            return f"Error: Unknown agent '{agent_name}'. Available agents:\n{available_str}"

        # Validate caller is allowed to call this subagent
        config = get_subagent_config(agent_name)
        if allowed_subagents and agent_name not in allowed_subagents:
            return f"Error: '{caller_name}' cannot call '{agent_name}'. Allowed: {allowed_subagents}"

        if config.callable_by and caller_name not in config.callable_by:
            return f"Error: '{agent_name}' can only be called by: {config.callable_by}"

        logger.info(
            f"[{caller_name}] Invoking subagent '{agent_name}': {description[:100]}..."
        )

        # Import subagent event emitters
        from agent_server.langchain.middleware.subagent_events import (
            clear_current_subagent,
            emit_subagent_complete,
            emit_subagent_start,
            set_current_subagent,
        )

        # Emit subagent start event for UI
        emit_subagent_start(agent_name, description)

        # Get the factory and config
        factory_func, llm_config = get_subagent_factory()
        if factory_func is None:
            return "Error: SubAgentMiddleware not initialized. Call set_subagent_factory first."

        try:
            import time

            # Set current subagent context for tool call tracking
            set_current_subagent(agent_name)

            # Get or create the subagent (cached for performance)
            # Avoids expensive LangGraph recompilation on each call
            t0 = time.time()
            subagent = get_or_create_subagent(agent_name, factory_func, llm_config)
            t1 = time.time()
            logger.info(f"[TIMING] get_or_create_subagent took {t1-t0:.2f}s")

            # Execute subagent synchronously with clean context
            # The subagent runs in isolation, receiving task description + optional context
            import uuid

            subagent_thread_id = f"subagent-{agent_name}-{uuid.uuid4().hex[:8]}"
            subagent_config = {
                "configurable": {
                    "thread_id": subagent_thread_id,
                }
            }

            # Inject code history for python_developer
            enhanced_context = context
            if agent_name == "python_developer":
                try:
                    t2 = time.time()
                    from agent_server.langchain.middleware.code_history_middleware import (
                        get_code_history_tracker,
                        get_context_with_history,
                    )

                    # Get main agent's thread_id for session-scoped history
                    main_thread_id = get_current_thread_id()
                    tracker = get_code_history_tracker(main_thread_id)
                    if tracker.get_entry_count() > 0:
                        enhanced_context = get_context_with_history(
                            context, main_thread_id
                        )
                        t3 = time.time()
                        logger.info(
                            f"[TIMING] code history injection took {t3-t2:.2f}s "
                            f"(entries={tracker.get_entry_count()}, "
                            f"thread_id={main_thread_id}, "
                            f"context_len={len(enhanced_context) if enhanced_context else 0})"
                        )
                except Exception as e:
                    logger.warning(f"Failed to inject code history: {e}")

            # Build the message content with optional context
            if enhanced_context:
                message_content = f"""## Task
{description}

## Context (provided by Main Agent)
{enhanced_context}"""
            else:
                message_content = description

            logger.info(
                f"[{caller_name}] Subagent message length: {len(message_content)}"
            )

            # Execute the subagent
            t_invoke_start = time.time()
            logger.info(f"[TIMING] About to invoke subagent '{agent_name}'...")
            result = subagent.invoke(
                {"messages": [{"role": "user", "content": message_content}]},
                config=subagent_config,
            )
            t_invoke_end = time.time()
            logger.info(
                f"[TIMING] subagent.invoke() took {t_invoke_end-t_invoke_start:.2f}s"
            )

            # Extract the final message from the result
            messages = result.get("messages", [])
            if messages:
                final_message = messages[-1]
                if hasattr(final_message, "content"):
                    response = final_message.content
                else:
                    response = str(final_message)
            else:
                response = "Subagent completed but returned no messages."

            logger.info(
                f"[{caller_name}] Subagent '{agent_name}' returned: {str(response)[:200]}..."
            )

            # Extract description from python_developer response for auto-injection
            if agent_name == "python_developer":
                try:
                    from agent_server.langchain.middleware.description_injector import (
                        process_task_tool_response,
                    )

                    process_task_tool_response(agent_name, str(response))
                except Exception as e:
                    logger.warning(f"Failed to extract description: {e}")

            # Emit subagent complete event for UI
            emit_subagent_complete(agent_name, str(response)[:100])

            return response

        except Exception as e:
            error_msg = f"Subagent '{agent_name}' failed: {str(e)}"
            logger.error(error_msg, exc_info=True)
            # Emit complete event even on error
            emit_subagent_complete(agent_name, f"Error: {str(e)[:50]}")
            return f"Error: {error_msg}"
        finally:
            # Always clear subagent context
            clear_current_subagent()

    # Update tool docstring with available agents
    task_tool.__doc__ = f"""Delegate a task to a specialized subagent.

Available agents:
{available_str}

The subagent will analyze the task and return its result.
- python_developer: Returns generated Python code and analysis
- researcher: Returns search results and findings
- athena_query: Returns SQL query string

For code execution (running Python, writing files), use Main Agent's tools directly.

IMPORTANT: For python_developer, ALWAYS provide context with:
- Resource info (file sizes, memory) from check_resource_tool
- Previous code context if building on existing work
- Variable names and their current state

Args:
    agent_name: Name of the subagent to invoke
    description: Detailed task description for the subagent
    context: Additional context (resource info, previous code, etc.)

Returns:
    Result from the subagent execution
"""

    return task_tool


class SubAgentMiddleware:
    """
    Middleware that adds subagent delegation capability.

    This middleware:
    1. Adds the `task` tool to the agent's toolset
    2. The task tool executes subagents synchronously
    3. Subagent results are returned directly to the caller

    Usage:
        middleware = SubAgentMiddleware(
            caller_name="main_agent",
            allowed_subagents=["python_developer", "researcher"],
        )

        agent = create_agent(
            model=llm,
            tools=tools,
            middleware=[middleware, ...],
        )
    """

    def __init__(
        self,
        caller_name: str,
        allowed_subagents: Optional[List[str]] = None,
    ):
        """
        Initialize SubAgentMiddleware.

        Args:
            caller_name: Name of the agent using this middleware
            allowed_subagents: List of subagents this agent can call.
                             None means all non-restricted subagents.
        """
        self.caller_name = caller_name
        self.allowed_subagents = allowed_subagents
        self.task_tool = create_task_tool(caller_name, allowed_subagents)

        logger.info(
            f"SubAgentMiddleware initialized for '{caller_name}' "
            f"with allowed_subagents={allowed_subagents}"
        )

    def get_tools(self) -> List[Any]:
        """Get the tools provided by this middleware."""
        return [self.task_tool]

    def __call__(self, tools: List[Any]) -> List[Any]:
        """
        Add task tool to the agent's toolset.

        This is called during agent creation to augment the tool list.
        """
        return tools + [self.task_tool]
