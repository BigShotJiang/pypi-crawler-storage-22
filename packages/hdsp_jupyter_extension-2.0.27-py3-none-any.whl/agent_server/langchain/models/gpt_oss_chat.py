"""
ChatGPTOSS: Custom ChatModel for gpt-oss (Harmony format).

gpt-oss uses a different instruction hierarchy:
- developer: behavioral rules/instructions (highest priority)
- system: metadata (date, cutoff, tools)
- user: actual questions

LangChain's ChatOpenAI sends everything as 'system', which gpt-oss treats as low-priority metadata.
This class converts SystemMessage to 'developer' role for proper instruction following.
"""

import json
import logging
import uuid
from typing import Any, Dict, Iterator, List, Optional, Union

from langchain_core.callbacks import CallbackManagerForLLMRun
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import (
    AIMessage,
    AIMessageChunk,
    BaseMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)
from langchain_core.outputs import ChatGeneration, ChatGenerationChunk, ChatResult
from langchain_core.tools import BaseTool
from openai import OpenAI
from pydantic import Field

logger = logging.getLogger(__name__)


class ChatGPTOSS(BaseChatModel):
    """ChatModel for gpt-oss with developer role support.

    Converts SystemMessage to 'developer' role for proper instruction hierarchy
    in gpt-oss (Harmony format) models.
    """

    client: Any = Field(default=None, exclude=True)
    model: str = Field(default="openai/gpt-oss-120b")
    base_url: str = Field(default="http://localhost:8000/v1")
    api_key: str = Field(default="dummy")
    temperature: float = Field(default=0.0)
    max_tokens: int = Field(default=8192)
    streaming: bool = Field(default=False)

    # Tool-related fields (private, not exposed to pydantic)
    _tools: Optional[List[Dict[str, Any]]] = None
    _tool_choice: Optional[Union[str, Dict[str, Any]]] = None

    def __init__(self, callbacks=None, **kwargs):
        # Remove callbacks from kwargs before super().__init__ if present
        # BaseChatModel handles callbacks through its own mechanism
        super().__init__(callbacks=callbacks, **kwargs)
        # Initialize OpenAI client
        self.client = OpenAI(
            base_url=self.base_url,
            api_key=self.api_key,
        )
        self._tools = None
        self._tool_choice = None

    @property
    def _llm_type(self) -> str:
        return "gpt-oss"

    @property
    def _identifying_params(self) -> Dict[str, Any]:
        return {
            "model": self.model,
            "base_url": self.base_url,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
        }

    def bind_tools(
        self,
        tools: List[Union[BaseTool, Dict[str, Any]]],
        *,
        tool_choice: Optional[Union[str, Dict[str, Any]]] = None,
        **kwargs,
    ) -> "ChatGPTOSS":
        """Bind tools to the model.

        Returns a new instance with tools bound.
        """
        # Convert tools to OpenAI format
        formatted_tools = []
        for tool in tools:
            if isinstance(tool, BaseTool):
                # Convert LangChain tool to OpenAI format
                tool_schema = {
                    "type": "function",
                    "function": {
                        "name": tool.name,
                        "description": tool.description or "",
                        "parameters": tool.args_schema.schema()
                        if tool.args_schema
                        else {"type": "object", "properties": {}},
                    },
                }
                formatted_tools.append(tool_schema)
            elif isinstance(tool, dict):
                # Already in dict format, ensure it has correct structure
                if "type" not in tool:
                    tool = {"type": "function", "function": tool}
                formatted_tools.append(tool)

        # Create new instance with tools bound
        new_instance = ChatGPTOSS(
            model=self.model,
            base_url=self.base_url,
            api_key=self.api_key,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
            streaming=self.streaming,
            callbacks=self.callbacks,  # Preserve callbacks (e.g., LLMTraceLogger)
        )
        new_instance._tools = formatted_tools
        new_instance._tool_choice = tool_choice
        return new_instance

    def _convert_messages(self, messages: List[BaseMessage]) -> List[Dict[str, Any]]:
        """Convert LangChain messages to OpenAI format with developer role.

        Key conversion: SystemMessage -> role=developer
        """
        result = []

        for msg in messages:
            if isinstance(msg, SystemMessage):
                # Convert system to developer for gpt-oss instruction hierarchy
                result.append(
                    {
                        "role": "developer",
                        "content": msg.content,
                    }
                )
            elif isinstance(msg, HumanMessage):
                result.append(
                    {
                        "role": "user",
                        "content": msg.content,
                    }
                )
            elif isinstance(msg, AIMessage):
                ai_msg: Dict[str, Any] = {
                    "role": "assistant",
                    "content": msg.content or "",
                }
                # Include tool calls if present
                tool_calls = getattr(msg, "tool_calls", None)
                if tool_calls:
                    ai_msg["tool_calls"] = [
                        {
                            "id": tc.get("id", str(uuid.uuid4())[:8]),
                            "type": "function",
                            "function": {
                                "name": tc["name"],
                                "arguments": json.dumps(tc["args"])
                                if isinstance(tc["args"], dict)
                                else tc["args"],
                            },
                        }
                        for tc in tool_calls
                    ]
                result.append(ai_msg)
            elif isinstance(msg, ToolMessage):
                result.append(
                    {
                        "role": "tool",
                        "tool_call_id": msg.tool_call_id,
                        "content": msg.content,
                    }
                )
            else:
                # Fallback for other message types
                role = getattr(msg, "role", "user")
                result.append(
                    {
                        "role": role,
                        "content": msg.content,
                    }
                )

        return result

    def _create_chat_result(self, response) -> ChatResult:
        """Convert OpenAI response to LangChain ChatResult."""
        choice = response.choices[0]
        message = choice.message

        # Build AIMessage
        content = message.content or ""
        additional_kwargs: Dict[str, Any] = {}
        tool_calls_list = []

        if message.tool_calls:
            # IMPORTANT: Only use the first tool_call to prevent parallel execution issues
            # LLM sometimes generates multiple tool_calls despite prompt instructions
            tool_calls_to_use = message.tool_calls[:1]
            if len(message.tool_calls) > 1:
                logger.warning(
                    "Multiple tool_calls detected (%d), using only first one: %s. Ignored: %s",
                    len(message.tool_calls),
                    message.tool_calls[0].function.name,
                    [tc.function.name for tc in message.tool_calls[1:]],
                )

            # Convert to LangChain tool_calls format only
            # Do NOT put tool_calls in additional_kwargs to avoid duplicate/conflicting data
            for tc in tool_calls_to_use:
                try:
                    args = json.loads(tc.function.arguments)
                except json.JSONDecodeError:
                    args = {"raw": tc.function.arguments}
                tool_calls_list.append(
                    {
                        "name": tc.function.name,
                        "args": args,
                        "id": tc.id,
                        "type": "tool_call",
                    }
                )

        ai_message = AIMessage(
            content=content,
            additional_kwargs=additional_kwargs,
            tool_calls=tool_calls_list if tool_calls_list else [],
            response_metadata={
                "model_name": response.model,
                "finish_reason": choice.finish_reason,
                "id": response.id,
            },
        )

        # Add usage metadata if available
        if response.usage:
            ai_message.usage_metadata = {
                "input_tokens": response.usage.prompt_tokens,
                "output_tokens": response.usage.completion_tokens,
                "total_tokens": response.usage.total_tokens,
            }

        generation = ChatGeneration(message=ai_message)
        return ChatResult(generations=[generation])

    def _generate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs,
    ) -> ChatResult:
        """Generate a response from the model."""
        openai_messages = self._convert_messages(messages)

        # Build request kwargs
        request_kwargs: Dict[str, Any] = {
            "model": self.model,
            "messages": openai_messages,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
        }

        if stop:
            request_kwargs["stop"] = stop

        if self._tools:
            request_kwargs["tools"] = self._tools
            if self._tool_choice:
                request_kwargs["tool_choice"] = self._tool_choice

        # Make API call
        logger.debug(
            f"ChatGPTOSS request: model={self.model}, messages_count={len(openai_messages)}"
        )
        response = self.client.chat.completions.create(**request_kwargs)

        return self._create_chat_result(response)

    def _stream(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs,
    ) -> Iterator[ChatGenerationChunk]:
        """Stream responses from the model."""
        openai_messages = self._convert_messages(messages)

        # Build request kwargs
        request_kwargs: Dict[str, Any] = {
            "model": self.model,
            "messages": openai_messages,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "stream": True,
        }

        if stop:
            request_kwargs["stop"] = stop

        if self._tools:
            request_kwargs["tools"] = self._tools
            if self._tool_choice:
                request_kwargs["tool_choice"] = self._tool_choice

        # Make streaming API call
        response = self.client.chat.completions.create(**request_kwargs)

        # Accumulate tool calls across chunks
        tool_calls_accum: Dict[int, Dict[str, Any]] = {}

        for chunk in response:
            if not chunk.choices:
                continue

            choice = chunk.choices[0]
            delta = choice.delta

            content = delta.content or ""
            additional_kwargs: Dict[str, Any] = {}
            tool_call_chunks = []

            # Handle tool calls in streaming
            # IMPORTANT: Only process the first tool_call (index 0) to prevent parallel execution
            if delta.tool_calls:
                for tc in delta.tool_calls:
                    idx = tc.index
                    # Only accumulate the first tool_call (index 0)
                    if idx > 0:
                        if idx == 1 and tc.function and tc.function.name:
                            # Log warning only once when we first see index 1
                            logger.warning(
                                "Multiple tool_calls in stream, ignoring index %d: %s",
                                idx,
                                tc.function.name,
                            )
                        continue

                    if idx not in tool_calls_accum:
                        tool_calls_accum[idx] = {
                            "id": tc.id or "",
                            "name": "",
                            "arguments": "",
                        }
                    if tc.id:
                        tool_calls_accum[idx]["id"] = tc.id
                    if tc.function:
                        if tc.function.name:
                            tool_calls_accum[idx]["name"] = tc.function.name
                        if tc.function.arguments:
                            tool_calls_accum[idx]["arguments"] += tc.function.arguments

                    # Build tool call chunk for LangChain
                    tool_call_chunks.append(
                        {
                            "index": idx,
                            "id": tool_calls_accum[idx]["id"],
                            "name": tool_calls_accum[idx]["name"],
                            "args": tool_calls_accum[idx]["arguments"],
                        }
                    )

            # Create chunk message
            chunk_message = AIMessageChunk(
                content=content,
                additional_kwargs=additional_kwargs,
                tool_call_chunks=tool_call_chunks if tool_call_chunks else [],
            )

            # Add finish reason on last chunk
            if choice.finish_reason:
                chunk_message.response_metadata = {
                    "finish_reason": choice.finish_reason,
                }

            yield ChatGenerationChunk(message=chunk_message)
