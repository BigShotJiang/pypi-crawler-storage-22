"""
Subagents Module

Defines specialized subagents for the multi-agent architecture:
- PythonDeveloper: Code execution and file modifications
- Researcher: READ-ONLY search and information gathering
- AthenaQuery: SQL generation using Qdrant RAG
"""

from agent_server.langchain.subagents.base import (
    SubAgentConfig,
    SUBAGENT_CONFIGS,
    get_subagent_config,
)

__all__ = [
    "SubAgentConfig",
    "SUBAGENT_CONFIGS",
    "get_subagent_config",
]
