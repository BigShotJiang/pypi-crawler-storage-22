"""
Subagent Base Configuration

Defines the configuration structure for subagents and provides
the registry of all available subagents.

Based on Deep Agents library pattern (benchmarked, not installed):
- SubAgent TypedDict with name, description, system_prompt, tools
- Optional model override and middleware
- callable_by and can_call_subagents for nested calling

Architecture:
- Subagents are analysis/generation specialists
- They do NOT execute code - Main Agent handles execution
- python_developer: Generates Python code, analyzes with LSP
- researcher: Searches and reads files (READ-ONLY)
- athena_query: Generates SQL queries via RAG
"""

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from agent_server.langchain.agent_prompts.python_developer_prompt import (
    PYTHON_DEVELOPER_SYSTEM_PROMPT,
)
from agent_server.langchain.agent_prompts.researcher_prompt import RESEARCHER_SYSTEM_PROMPT
from agent_server.langchain.agent_prompts.athena_query_prompt import (
    ATHENA_QUERY_SYSTEM_PROMPT,
)

logger = logging.getLogger(__name__)


@dataclass
class SubAgentConfig:
    """
    Configuration for a subagent.

    Attributes:
        name: Unique identifier for the subagent
        description: Description shown in task tool (helps Main Agent choose)
        system_prompt: System prompt for the subagent
        tools: List of tool names this subagent can use
        model: Optional model override (uses parent's model if None)
        middleware: Optional additional middleware for this subagent
        can_call_subagents: List of subagents this agent can call (nested)
        callable_by: List of agents that can call this subagent
    """
    name: str
    description: str
    system_prompt: str
    tools: List[str]
    model: Optional[str] = None
    middleware: List[Any] = field(default_factory=list)
    can_call_subagents: List[str] = field(default_factory=list)
    callable_by: List[str] = field(default_factory=list)


# Registry of all subagent configurations
SUBAGENT_CONFIGS: Dict[str, SubAgentConfig] = {
    "python_developer": SubAgentConfig(
        name="python_developer",
        description="Generate Python code for data analysis, visualization, ML. Analyze code with LSP tools. Returns generated code for Main Agent to execute.",
        system_prompt=PYTHON_DEVELOPER_SYSTEM_PROMPT,
        tools=[
            # Read files for context (NO write/edit)
            "read_file_tool",
            # Shell tools for exploration
            "execute_command_tool",
            # LSP tools for code analysis
            "diagnostics_tool",
            "references_tool",
        ],
        can_call_subagents=["athena_query"],  # Can call athena_query for SQL
    ),
    "researcher": SubAgentConfig(
        name="researcher",
        description="Search files, explore workspace, Qdrant RAG search (READ-ONLY). Cannot modify files.",
        system_prompt=RESEARCHER_SYSTEM_PROMPT,
        tools=[
            "read_file_tool",
            "search_notebook_cells_tool",
            "execute_command_tool",
            # LSP tools
            "diagnostics_tool",
            "references_tool",
            # RAG tools
            "qdrant_search_tool",
        ],
    ),
    "athena_query": SubAgentConfig(
        name="athena_query",
        description="Generate optimized Athena SQL queries using Qdrant RAG for DB/table metadata. Returns SQL + description.",
        system_prompt=ATHENA_QUERY_SYSTEM_PROMPT,
        tools=[
            "qdrant_search_tool",
        ],
        callable_by=["planner", "python_developer"],  # Main Agent and Python Developer can call this
    ),
}


def get_subagent_config(name: str) -> SubAgentConfig:
    """
    Get configuration for a specific subagent.

    Args:
        name: Subagent name

    Returns:
        SubAgentConfig for the requested subagent

    Raises:
        ValueError: If subagent is not found
    """
    if name not in SUBAGENT_CONFIGS:
        raise ValueError(
            f"Unknown subagent: '{name}'. Available: {list(SUBAGENT_CONFIGS.keys())}"
        )
    return SUBAGENT_CONFIGS[name]


def get_available_subagents_for_planner() -> List[SubAgentConfig]:
    """
    Get list of subagents that Main Agent (Planner) can directly call.

    Returns:
        List of SubAgentConfig for Main Agent-callable subagents
    """
    # Main Agent can call subagents with no restrictions OR those explicitly allowing "planner"
    return [
        config for name, config in SUBAGENT_CONFIGS.items()
        if not config.callable_by or "planner" in config.callable_by
    ]


# Alias for backward compatibility
get_available_subagents_for_main_agent = get_available_subagents_for_planner


def get_subagents_for_agent(caller_name: str) -> List[SubAgentConfig]:
    """
    Get list of subagents that a specific agent can call.

    Args:
        caller_name: Name of the calling agent

    Returns:
        List of SubAgentConfig that this agent can call
    """
    result = []
    for name, config in SUBAGENT_CONFIGS.items():
        # Can call if: no restrictions OR caller is in callable_by
        if not config.callable_by or caller_name in config.callable_by:
            result.append(config)
    return result


def format_subagents_for_prompt(subagents: List[SubAgentConfig]) -> str:
    """
    Format subagent list for inclusion in system prompt.

    Args:
        subagents: List of subagent configurations

    Returns:
        Formatted string describing available subagents
    """
    lines = ["Available subagents:"]
    for config in subagents:
        lines.append(f"- {config.name}: {config.description}")
    return "\n".join(lines)
