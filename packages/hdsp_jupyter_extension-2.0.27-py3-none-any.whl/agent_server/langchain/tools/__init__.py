"""
LangChain Tools for Jupyter Agent

Tools available:
- jupyter_cell: Execute Python code in notebook
- markdown: Add markdown cell
- ask_user: Request user input (HITL - waits for user response)
- read_file: Read file content
- write_file: Write file content
- edit_file: Edit file with string replacement
- search_notebook_cells: Search cells in notebooks
- execute_command_tool: Run shell commands (client-executed, also for file search)
- check_resource_tool: Check resources before data processing (client-executed)
- diagnostics_tool: Get LSP diagnostics (errors, warnings)
- references_tool: Find symbol references via LSP
"""

from agent_server.langchain.tools.file_tools import (
    edit_file_tool,
    multiedit_file_tool,
    read_file_tool,
    write_file_tool,
)
from agent_server.langchain.tools.jupyter_tools import (
    ask_user_tool,
    jupyter_cell_tool,
    markdown_tool,
)
from agent_server.langchain.tools.lsp_tools import (
    diagnostics_tool,
    references_tool,
)
from agent_server.langchain.tools.resource_tools import check_resource_tool
from agent_server.langchain.tools.search_tools import (
    search_notebook_cells_tool,
)
from agent_server.langchain.tools.shell_tools import execute_command_tool

__all__ = [
    "ask_user_tool",
    "jupyter_cell_tool",
    "markdown_tool",
    "read_file_tool",
    "write_file_tool",
    "edit_file_tool",
    "multiedit_file_tool",
    "search_notebook_cells_tool",
    "execute_command_tool",
    "check_resource_tool",
    "diagnostics_tool",
    "references_tool",
]
