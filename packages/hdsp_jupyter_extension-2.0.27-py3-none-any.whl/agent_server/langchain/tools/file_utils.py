"""
File Utilities for LangChain Agent

Provides utility functions for file operations:
- perform_string_replacement: String replacement with occurrence validation
- compute_unified_diff: Generate unified diff between before/after content
- count_diff_changes: Count additions/deletions from diff
- format_content_with_line_numbers: Format file content with line numbers (cat -n style)
- check_empty_content: Check if content is empty and return warning message
"""

import difflib
from typing import List, Optional, Tuple, Union

# Constants for file reading (aligned with DeepAgents)
EMPTY_CONTENT_WARNING = "System reminder: File exists but has empty contents"
MAX_LINE_LENGTH = 10000  # Chunk lines longer than this
LINE_NUMBER_WIDTH = 6  # Width for line number padding


def check_empty_content(content: str) -> Optional[str]:
    """
    Check if content is empty and return warning message.

    Args:
        content: Content to check

    Returns:
        Warning message if empty, None otherwise
    """
    if not content or content.strip() == "":
        return EMPTY_CONTENT_WARNING
    return None


def format_content_with_line_numbers(
    content: Union[str, List[str]],
    start_line: int = 1,
) -> str:
    """
    Format file content with line numbers (cat -n style).

    Chunks lines longer than MAX_LINE_LENGTH with continuation markers (e.g., 5.1, 5.2).

    Args:
        content: File content as string or list of lines
        start_line: Starting line number (default: 1)

    Returns:
        Formatted content with line numbers and continuation markers
    """
    if isinstance(content, str):
        lines = content.split("\n")
        # Remove trailing empty line if content ends with newline
        if lines and lines[-1] == "":
            lines = lines[:-1]
    else:
        lines = content

    result_lines = []
    for i, line in enumerate(lines):
        line_num = i + start_line

        if len(line) <= MAX_LINE_LENGTH:
            result_lines.append(f"{line_num:{LINE_NUMBER_WIDTH}d}\t{line}")
        else:
            # Split long line into chunks with continuation markers
            num_chunks = (len(line) + MAX_LINE_LENGTH - 1) // MAX_LINE_LENGTH
            for chunk_idx in range(num_chunks):
                start = chunk_idx * MAX_LINE_LENGTH
                end = min(start + MAX_LINE_LENGTH, len(line))
                chunk = line[start:end]
                if chunk_idx == 0:
                    # First chunk: use normal line number
                    result_lines.append(f"{line_num:{LINE_NUMBER_WIDTH}d}\t{chunk}")
                else:
                    # Continuation chunks: use decimal notation (e.g., 5.1, 5.2)
                    continuation_marker = f"{line_num}.{chunk_idx}"
                    result_lines.append(
                        f"{continuation_marker:>{LINE_NUMBER_WIDTH}}\t{chunk}"
                    )

    return "\n".join(result_lines)


def format_read_response(
    content: str,
    offset: int = 0,
    limit: int = 500,
) -> str:
    """
    Format file content for read response with line numbers and pagination.

    Args:
        content: Full file content
        offset: Line offset (0-indexed)
        limit: Maximum number of lines to return

    Returns:
        Formatted content with line numbers, or error/warning message
    """
    # Check for empty content
    empty_msg = check_empty_content(content)
    if empty_msg:
        return empty_msg

    lines = content.splitlines()
    total_lines = len(lines)

    # Validate offset
    if offset >= total_lines:
        return f"Error: Line offset {offset} exceeds file length ({total_lines} lines)"

    # Apply pagination
    start_idx = offset
    end_idx = min(start_idx + limit, total_lines)
    selected_lines = lines[start_idx:end_idx]

    # Format with line numbers
    formatted = format_content_with_line_numbers(
        selected_lines, start_line=start_idx + 1
    )

    # Add pagination info if truncated
    if end_idx < total_lines:
        remaining = total_lines - end_idx
        formatted += f"\n\n[... {remaining} more lines. Use offset={end_idx} to continue reading]"

    return formatted


def _normalize_whitespace(text: str) -> str:
    """Normalize line endings and trailing whitespace per line."""
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    return "\n".join(line.rstrip() for line in lines)


def perform_string_replacement(
    content: str,
    old_string: str,
    new_string: str,
    replace_all: bool = False,
) -> Union[Tuple[str, int], str]:
    """
    Perform string replacement with occurrence validation.

    Includes fallback strategies for more robust matching:
    1. Exact match
    2. Strip leading/trailing newlines from old_string
    3. Normalize whitespace (line endings, trailing spaces)

    Args:
        content: Original file content
        old_string: String to replace
        new_string: Replacement string
        replace_all: Whether to replace all occurrences

    Returns:
        Tuple of (new_content, occurrences) on success,
        or error message string on failure
    """
    # Strategy 1: Exact match
    occurrences = content.count(old_string)

    if occurrences == 0:
        # Strategy 2: Strip leading/trailing newlines from old_string
        stripped_old = old_string.strip("\n")
        occurrences = content.count(stripped_old)
        if occurrences > 0:
            old_string = stripped_old
            # Also strip new_string's leading/trailing newlines to match
            new_string = new_string.strip("\n")

    if occurrences == 0:
        # Strategy 3: Normalize whitespace (line endings, trailing spaces)
        normalized_content = _normalize_whitespace(content)
        normalized_old = _normalize_whitespace(old_string.strip("\n"))
        occurrences = normalized_content.count(normalized_old)

        if occurrences > 0:
            # Find the original text in content that matches normalized version
            # We need to do replacement on the normalized content first
            normalized_new = _normalize_whitespace(new_string.strip("\n"))
            if occurrences > 1 and not replace_all:
                preview = (
                    old_string[:50] + "..." if len(old_string) > 50 else old_string
                )
                return (
                    f"Error: String '{preview}' appears {occurrences} times in file. "
                    "Use replace_all=True to replace all instances, "
                    "or provide a more specific string with surrounding context."
                )
            # Replace on normalized content, then return
            new_content = normalized_content.replace(normalized_old, normalized_new)
            return new_content, occurrences

    if occurrences == 0:
        # All strategies failed
        preview = old_string[:100] + "..." if len(old_string) > 100 else old_string
        return f"Error: String not found in file: '{preview}'"

    if occurrences > 1 and not replace_all:
        preview = old_string[:50] + "..." if len(old_string) > 50 else old_string
        return (
            f"Error: String '{preview}' appears {occurrences} times in file. "
            "Use replace_all=True to replace all instances, "
            "or provide a more specific string with surrounding context."
        )

    new_content = content.replace(old_string, new_string)
    return new_content, occurrences


def compute_unified_diff(
    before: str,
    after: str,
    filepath: str,
    max_lines: int = 100,
    context_lines: int = 3,
) -> Union[str, None]:
    """
    Compute a unified diff between before and after content.

    Args:
        before: Original content
        after: New content
        filepath: Path for display in diff headers
        max_lines: Maximum number of diff lines (None for unlimited)
        context_lines: Number of context lines around changes (default 3)

    Returns:
        Unified diff string or None if no changes
    """
    before_lines = before.splitlines()
    after_lines = after.splitlines()

    diff_lines = list(
        difflib.unified_diff(
            before_lines,
            after_lines,
            fromfile=f"{filepath} (before)",
            tofile=f"{filepath} (after)",
            lineterm="",
            n=context_lines,
        )
    )

    if not diff_lines:
        return None

    if max_lines and len(diff_lines) > max_lines:
        truncated = diff_lines[: max_lines - 1]
        truncated.append(
            f"... [{len(diff_lines) - max_lines + 1} more lines truncated]"
        )
        return "\n".join(truncated)

    return "\n".join(diff_lines)


def count_diff_changes(diff: str) -> Tuple[int, int]:
    """
    Count additions and deletions from unified diff.

    Args:
        diff: Unified diff string

    Returns:
        Tuple of (additions, deletions) line counts
    """
    if not diff:
        return 0, 0

    additions = sum(
        1
        for line in diff.splitlines()
        if line.startswith("+") and not line.startswith("+++")
    )
    deletions = sum(
        1
        for line in diff.splitlines()
        if line.startswith("-") and not line.startswith("---")
    )
    return additions, deletions


def build_edit_preview(
    original_content: str,
    old_string: str,
    new_string: str,
    replace_all: bool,
    filepath: str,
) -> dict:
    """
    Build a preview for edit_file operation including diff.

    Args:
        original_content: Current file content
        old_string: String to replace
        new_string: Replacement string
        replace_all: Whether to replace all occurrences
        filepath: File path for display

    Returns:
        Dict with diff, occurrences, and change counts
    """
    result = perform_string_replacement(
        original_content, old_string, new_string, replace_all
    )

    if isinstance(result, str):
        # Error case
        return {
            "success": False,
            "error": result,
            "diff": None,
            "occurrences": 0,
            "lines_added": 0,
            "lines_removed": 0,
        }

    new_content, occurrences = result
    diff = compute_unified_diff(original_content, new_content, filepath)
    additions, deletions = count_diff_changes(diff) if diff else (0, 0)

    return {
        "success": True,
        "error": None,
        "diff": diff,
        "occurrences": occurrences,
        "lines_added": additions,
        "lines_removed": deletions,
        "new_content": new_content,
    }
