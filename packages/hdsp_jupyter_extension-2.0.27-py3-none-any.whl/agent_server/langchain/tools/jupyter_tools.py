"""
Jupyter Tools for LangChain Agent

Provides tools for interacting with Jupyter notebooks:
- jupyter_cell: Execute Python code in a new cell
- markdown: Add a markdown cell
- ask_user: Request user input and wait for response
"""

from typing import Any, Dict, List, Optional

from langchain_core.tools import tool
from pydantic import BaseModel, Field


class JupyterCellInput(BaseModel):
    """Input schema for jupyter_cell tool"""

    code: str = Field(description="Python code to execute in the notebook cell")
    description: Optional[str] = Field(
        default=None, description="Optional description of what this code does"
    )
    execution_result: Optional[Dict[str, Any]] = Field(
        default=None, description="Optional execution result payload from the client"
    )


class MarkdownInput(BaseModel):
    """Input schema for markdown tool"""

    content: str = Field(description="Markdown content to add to the notebook")


class AskUserInput(BaseModel):
    """Input schema for ask_user tool"""

    question: str = Field(description="사용자에게 보여줄 질문 또는 요청")
    options: Optional[List[str]] = Field(
        default=None, description="선택지 목록 (없으면 자유 입력)"
    )
    input_type: str = Field(
        default="text",
        description="입력 타입: text (텍스트 입력), file (파일 업로드), selection (선택지 중 선택)",
    )
    user_response: Optional[str] = Field(
        default=None,
        description="사용자 응답 (HITL edit decision으로 프론트엔드에서 전달)",
    )


@tool(args_schema=JupyterCellInput)
def jupyter_cell_tool(
    code: str,
    description: Optional[str] = None,
    execution_result: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Execute Python code in a new Jupyter notebook cell.

    This tool adds a new code cell at the end of the notebook and executes it.
    The execution is handled by JupyterExecutionMiddleware.

    Args:
        code: Python code to execute
        description: Optional description of the code's purpose

    Returns:
        Dict containing execution request (actual execution by middleware)
    """
    # Clean code: remove markdown code block wrappers if present
    cleaned_code = code.strip()
    if cleaned_code.startswith("```python"):
        cleaned_code = cleaned_code[9:]
    elif cleaned_code.startswith("```"):
        cleaned_code = cleaned_code[3:]
    if cleaned_code.endswith("```"):
        cleaned_code = cleaned_code[:-3]
    cleaned_code = cleaned_code.strip()

    response: Dict[str, Any] = {
        "tool": "jupyter_cell",
        "parameters": {
            "code": cleaned_code,
            "description": description,
        },
        "status": "pending_execution",
        "message": "Code cell queued for execution by JupyterExecutionMiddleware",
    }
    if execution_result is not None:
        response["execution_result"] = execution_result
        response["status"] = "complete"
        response["message"] = "Code cell executed with client-reported results"
    return response


@tool(args_schema=MarkdownInput)
def markdown_tool(content: str) -> Dict[str, Any]:
    """
    Add a markdown cell to the Jupyter notebook.

    This tool adds a new markdown cell at the end of the notebook.
    Useful for adding explanations, documentation, or section headers.

    Args:
        content: Markdown content to add

    Returns:
        Dict containing the markdown addition request
    """
    return {
        "tool": "markdown",
        "parameters": {
            "content": content,
        },
        "status": "completed",
        "message": "Markdown cell added successfully. Continue with the next task.",
    }


@tool(args_schema=AskUserInput)
def ask_user_tool(
    question: str,
    options: Optional[List[str]] = None,
    input_type: str = "text",
    user_response: Optional[str] = None,
) -> Dict[str, Any]:
    """
    사용자에게 질문하고 응답을 기다리는 도구.

    이 도구 호출 후 에이전트는 사용자 응답을 기다립니다.
    사용자가 응답하면 그 내용이 다음 메시지로 전달됩니다.

    사용 시점:
    - 선택 요청: ask_user_tool(question="어떤 모델을 사용할까요?", options=["Logistic", "RandomForest"])
    - 정보 요청: ask_user_tool(question="API 키를 입력해 주세요", input_type="text")

    주의: 정보 출력용으로는 markdown_tool을 사용하고, 사용자 응답이 필요하면 이 도구를 사용하세요.

    Args:
        question: 사용자에게 보여줄 질문
        options: 선택지 목록 (선택적, input_type="selection"일 때 사용)
        input_type: 입력 타입 - text(텍스트), file(파일 업로드), selection(선택)
        user_response: 사용자 응답 (HITL에서 프론트엔드가 전달)

    Returns:
        Dict containing the user response or waiting status
    """
    # 사용자 응답이 있으면 (HITL edit decision으로 전달됨) 반환
    if user_response is not None:
        return {
            "tool": "ask_user",
            "parameters": {
                "question": question,
                "options": options,
                "input_type": input_type,
            },
            "status": "completed",
            "user_response": user_response,
            "message": f"사용자 응답: {user_response}",
        }

    # 사용자 응답 대기 상태
    return {
        "tool": "ask_user",
        "parameters": {
            "question": question,
            "options": options,
            "input_type": input_type,
        },
        "status": "waiting_for_user",
        "message": "사용자 응답을 기다리는 중입니다...",
    }


class NextItem(BaseModel):
    """Schema for a next step item"""

    subject: str = Field(description="다음 단계 제목")
    description: str = Field(description="다음 단계 설명")


class FinalSummaryInput(BaseModel):
    """Input schema for final_summary tool"""

    summary: str = Field(description="완료된 작업에 대한 요약 (한국어)")
    next_items: List[NextItem] = Field(
        description="다음 단계 제안 목록 (3개 이상)", min_length=3
    )


@tool(args_schema=FinalSummaryInput)
def final_summary_tool(
    summary: str,
    next_items: List[Dict[str, str]],
) -> Dict[str, Any]:
    """
    모든 작업이 완료된 후 최종 요약과 다음 단계를 제시하는 도구.

    이 도구는 반드시 모든 todo가 완료된 후, 마지막 "작업 요약 및 다음 단계 제시" todo를 처리할 때만 호출하세요.

    Args:
        summary: 완료된 작업에 대한 요약 (한국어로 작성)
        next_items: 다음 단계 제안 목록 (각각 subject와 description 포함, 3개 이상)

    Returns:
        Dict containing the summary and next items for frontend display
    """
    return {
        "tool": "final_summary",
        "summary": summary,
        "next_items": next_items,
        "status": "completed",
        "message": "작업 요약이 완료되었습니다.",
    }


# Export all tools
JUPYTER_TOOLS = [
    jupyter_cell_tool,
    markdown_tool,
    ask_user_tool,
    final_summary_tool,
]
