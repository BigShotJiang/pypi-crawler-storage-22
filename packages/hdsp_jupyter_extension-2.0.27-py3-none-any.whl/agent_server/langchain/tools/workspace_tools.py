"""
Workspace Exploration Tools for LangChain Agent

Provides tools for exploring workspace files and content:
- list_workspace_tool: List files/directories (like Glob)
- search_files_tool: Search file contents (like Grep)

Based on Claude Code's search tool patterns.
These tools return pending_execution status for client-side execution.
"""

import logging
from typing import Any, Dict, Optional

from langchain_core.tools import tool
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class ListWorkspaceInput(BaseModel):
    """Input schema for list_workspace tool"""

    path: str = Field(
        default=".",
        description="Directory path to list (relative to workspace root, '.' for root)",
    )
    pattern: str = Field(
        default="*",
        description="Glob pattern to filter files (e.g., '*.csv', '*.py', 'data/*')",
    )
    recursive: bool = Field(
        default=False,
        description="Whether to search subdirectories recursively",
    )
    max_results: int = Field(
        default=50,
        description="Maximum number of results to return",
    )
    execution_result: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Client-side execution result (injected by HITL resume)",
    )


class SearchFilesInput(BaseModel):
    """Input schema for search_files tool"""

    pattern: str = Field(
        description=(
            "Search pattern (text or regex) to find in file contents. "
            "Supports regex syntax including OR operator (|) to search multiple patterns at once. "
            "Example: 'error|warning|exception' to find any of these terms."
        ),
    )
    path: str = Field(
        default=".",
        description="Directory to search (relative to workspace root)",
    )
    file_pattern: str = Field(
        default="*",
        description="Glob pattern to filter which files to search (e.g., '*.py', '*.csv')",
    )
    case_sensitive: bool = Field(
        default=False,
        description="Whether search is case-sensitive",
    )
    max_results: int = Field(
        default=30,
        description="Maximum number of matching lines to return",
    )
    context_lines: int = Field(
        default=0,
        description="Number of context lines before/after each match",
    )
    execution_result: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Client-side execution result (injected by HITL resume)",
    )


@tool(args_schema=ListWorkspaceInput)
def list_workspace_tool(
    path: str = ".",
    pattern: str = "*",
    recursive: bool = False,
    max_results: int = 50,
    execution_result: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    List files and directories in the workspace.

    Use this tool to explore the workspace structure and find files.
    Similar to 'ls' or 'find' command but optimized for the agent.

    Examples:
    - list_workspace_tool(path=".") → List root directory
    - list_workspace_tool(pattern="*.csv") → Find all CSV files
    - list_workspace_tool(path="data", pattern="*.parquet", recursive=True) → Find parquet files in data/

    Args:
        path: Directory to list (relative to workspace root)
        pattern: Glob pattern to filter files
        recursive: Search subdirectories
        max_results: Maximum results

    Returns:
        Dict with pending_execution status or execution result
    """
    logger.info(f"list_workspace_tool: path={path}, pattern={pattern}, recursive={recursive}")

    # Build response for client-side execution
    response: Dict[str, Any] = {
        "tool": "list_workspace_tool",
        "parameters": {
            "path": path,
            "pattern": pattern,
            "recursive": recursive,
            "max_results": max_results,
        },
        "status": "pending_execution",
        "message": "Workspace list queued for execution by client",
    }

    # If execution_result is provided (from client), return it
    if execution_result is not None:
        return execution_result

    return response


@tool(args_schema=SearchFilesInput)
def search_files_tool(
    pattern: str,
    path: str = ".",
    file_pattern: str = "*",
    case_sensitive: bool = False,
    max_results: int = 30,
    context_lines: int = 0,
    execution_result: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Search for a pattern in file contents.

    Use this tool to find specific text or code patterns within files.
    Similar to 'grep' or 'ripgrep' command.
    Supports full regex syntax including OR operator (|) for multi-pattern search.

    Examples:
    - search_files_tool(pattern="import pandas") → Find pandas imports
    - search_files_tool(pattern="def train", file_pattern="*.py") → Find train functions in Python files
    - search_files_tool(pattern="titanic", path="data") → Find titanic references in data/
    - search_files_tool(pattern="error|warning|exception") → Find any of: error, warning, exception
    - search_files_tool(pattern="escapeHtml|sanitize|<svg") → Find multiple related terms at once
    - search_files_tool(pattern="TODO|FIXME|HACK", file_pattern="*.py") → Find code annotations
    - search_files_tool(pattern="class\\s+\\w+Model") → Find class definitions ending with Model (regex)

    Args:
        pattern: Search pattern (text or regex). Use | for OR (e.g., "foo|bar|baz")
        path: Directory to search (relative to workspace root)
        file_pattern: Glob pattern to filter files (e.g., "*.py", "*.ts")
        case_sensitive: Case-sensitive search (default: False)
        max_results: Maximum matching lines to return
        context_lines: Lines of context before/after each match

    Returns:
        Dict with pending_execution status or execution result
    """
    logger.info(f"search_files_tool: pattern={pattern}, path={path}, file_pattern={file_pattern}")

    # Build response for client-side execution
    response: Dict[str, Any] = {
        "tool": "search_files_tool",
        "parameters": {
            "pattern": pattern,
            "path": path,
            "file_pattern": file_pattern,
            "case_sensitive": case_sensitive,
            "max_results": max_results,
            "context_lines": context_lines,
        },
        "status": "pending_execution",
        "message": "File search queued for execution by client",
    }

    # If execution_result is provided (from client), return it
    if execution_result is not None:
        return execution_result

    return response


# Export all tools
WORKSPACE_TOOLS = [
    list_workspace_tool,
    search_files_tool,
]
