"""
Context Router - Context provider autocomplete and resolution

Handles @file and other context command autocomplete and processing.
Inspired by jupyter-ai's autocomplete API.
"""

import logging
import os
from typing import Optional

from fastapi import APIRouter, Query
from pydantic import BaseModel

from agent_server.context_providers import FileContextProvider, ResetContextProvider
from agent_server.context_providers.base import ListOptionsResponse

router = APIRouter()
logger = logging.getLogger(__name__)


# All available providers (context and action)
def _get_all_providers(base_dir: str):
    """Get all available context/action providers."""
    return {
        "@file": FileContextProvider(base_dir=base_dir),
        "@reset": ResetContextProvider(base_dir=base_dir),
    }


class ContextOptionsRequest(BaseModel):
    """Request for context options."""

    partial_command: Optional[str] = None  # e.g., "@file:src/"
    base_dir: Optional[str] = None  # Base directory for file resolution


class FileContentRequest(BaseModel):
    """Request to get file content."""

    filepath: str
    base_dir: Optional[str] = None


class FileContentResponse(BaseModel):
    """Response with file content."""

    content: str
    filepath: str
    error: Optional[str] = None


@router.get("/autocomplete", response_model=ListOptionsResponse)
async def get_autocomplete_options(
    partial_command: Optional[str] = Query(None, alias="partialCommand"),
    base_dir: Optional[str] = Query(None, alias="baseDir"),
) -> ListOptionsResponse:
    """
    Get autocomplete options for context commands.

    Query Parameters:
        partialCommand: Partial command to complete
            - "@" -> list all available commands
            - "@fi" -> list commands starting with "@fi"
            - "@file:" -> list files in current directory
            - "@file:src/" -> list files in src directory
        baseDir: Base directory for file resolution (default: cwd)
    """
    base_directory = base_dir or os.getcwd()
    providers = _get_all_providers(base_directory)

    if not partial_command:
        # Return all available context commands
        options = [p.get_provider_option() for p in providers.values()]
        return ListOptionsResponse(options=options)

    # Check if it's just "@" or a partial command name (no colon)
    if ":" not in partial_command:
        # Filter providers that match the partial command
        options = []
        for cmd_id, provider in providers.items():
            if cmd_id.startswith(partial_command):
                options.append(provider.get_provider_option())
        return ListOptionsResponse(options=options)

    # Has colon - parse the partial command
    cmd_id, _, arg_prefix = partial_command.partition(":")

    # Find matching provider
    if cmd_id in providers:
        provider = providers[cmd_id]
        if provider.requires_arg:
            options = provider.get_arg_options(arg_prefix)
            return ListOptionsResponse(options=options)
        else:
            # For commands without args (like @reset), return the command itself
            return ListOptionsResponse(options=[provider.get_provider_option()])

    # No matching provider
    return ListOptionsResponse(options=[])


@router.post("/file/content", response_model=FileContentResponse)
async def get_file_content(request: FileContentRequest) -> FileContentResponse:
    """
    Get the content of a file for context injection.

    This is used when processing @file commands to include file contents
    in the LLM prompt.
    """
    try:
        base_directory = request.base_dir or os.getcwd()
        file_provider = FileContextProvider(base_dir=base_directory)

        # Create a command object
        from agent_server.context_providers.base import ContextCommand

        cmd = ContextCommand(cmd=f"@file:{request.filepath}")
        content = file_provider.make_context(cmd)

        return FileContentResponse(
            content=content,
            filepath=request.filepath,
        )
    except Exception as e:
        logger.error(f"Failed to read file {request.filepath}: {e}")
        return FileContentResponse(
            content="",
            filepath=request.filepath,
            error=str(e),
        )


@router.get("/providers")
async def list_context_providers():
    """
    List all available context providers.

    Returns information about each context provider including:
    - ID (e.g., "@file")
    - Description
    - Whether it requires an argument
    - Whether it's an action command
    """
    providers = [
        {
            "id": "@file",
            "description": "Include file contents in the prompt",
            "requires_arg": True,
            "is_action": False,
            "usage": "@file:path/to/file.py",
            "examples": [
                "@file:main.py",
                "@file:src/utils.py",
                "@file:'path with spaces/file.py'",
            ],
        },
        {
            "id": "@reset",
            "description": "Clear session and reset agent",
            "requires_arg": False,
            "is_action": True,
            "usage": "@reset",
            "examples": ["@reset"],
        },
    ]

    return {"providers": providers}
