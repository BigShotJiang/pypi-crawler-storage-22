"""
Action Context Providers

These providers handle action commands like /reset that perform actions
rather than providing context to the LLM.
"""

from .base import BaseContextProvider, ContextCommand, ListOptionsEntry


class ResetContextProvider(BaseContextProvider):
    """
    Action provider for resetting the session.

    Usage:
        /reset - Clear conversation history and recreate agent
    """

    id = "/reset"
    description = "세션 초기화 및 에이전트 리셋"
    requires_arg = False
    only_start = False

    def __init__(self, base_dir: str = "."):
        super().__init__(base_dir)

    def get_arg_options(self, arg_prefix: str) -> list[ListOptionsEntry]:
        """No arguments for /reset."""
        return []

    def make_context(self, command: ContextCommand) -> str:
        """/reset doesn't provide context - it's an action command."""
        return ""

    def replace_command(self, command: ContextCommand) -> str:
        """Replace /reset with empty string (it's an action, not context)."""
        return ""

    def is_action_command(self) -> bool:
        """Indicate this is an action command."""
        return True


# Add more action commands here as needed
# Example: @clear, @help, @history, etc.


class CompactContextProvider(BaseContextProvider):
    """
    Action provider for compacting conversation history.

    Usage:
        /compact - Summarize older messages, keep recent 3 intact
    """

    id = "/compact"
    description = "대화 기록 압축 및 요약"
    requires_arg = False
    only_start = False

    def __init__(self, base_dir: str = "."):
        super().__init__(base_dir)

    def get_arg_options(self, arg_prefix: str) -> list[ListOptionsEntry]:
        """No arguments for /compact."""
        return []

    def make_context(self, command: ContextCommand) -> str:
        """/compact doesn't provide context - it's an action command."""
        return ""

    def replace_command(self, command: ContextCommand) -> str:
        """Replace /compact with empty string (it's an action, not context)."""
        return ""

    def is_action_command(self) -> bool:
        """Indicate this is an action command."""
        return True


class HelpContextProvider(BaseContextProvider):
    """
    Action provider for displaying help information.

    Usage:
        /help - Show available commands and features guide
    """

    id = "/help"
    description = "도움말 및 사용 가이드"
    requires_arg = False
    only_start = False

    def __init__(self, base_dir: str = "."):
        super().__init__(base_dir)

    def get_arg_options(self, arg_prefix: str) -> list[ListOptionsEntry]:
        """No arguments for /help."""
        return []

    def make_context(self, command: ContextCommand) -> str:
        """/help doesn't provide context - it's an action command."""
        return ""

    def replace_command(self, command: ContextCommand) -> str:
        """Replace /help with empty string (it's an action, not context)."""
        return ""

    def is_action_command(self) -> bool:
        """Indicate this is an action command."""
        return True
