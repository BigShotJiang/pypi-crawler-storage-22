"""
LangChain Agent

Main agent creation module for multi-agent system.
"""

import logging
from typing import Any, Dict, Optional

from agent_server.langchain.agent_factory import create_multi_agent_system

logger = logging.getLogger(__name__)


def create_agent_system(
    llm_config: Dict[str, Any],
    workspace_root: str = ".",
    enable_hitl: bool = True,
    enable_todo_list: bool = True,
    checkpointer: Optional[object] = None,
    system_prompt_override: Optional[str] = None,
    agent_prompts: Optional[Dict[str, str]] = None,
):
    """
    Create a multi-agent system (Planner + Subagents).

    This is the main entry point for creating agents.

    Args:
        llm_config: LLM configuration
        workspace_root: Root directory for file operations
        enable_hitl: Enable Human-in-the-Loop for code execution
        enable_todo_list: Enable TodoListMiddleware for task planning
        checkpointer: Optional checkpointer for state persistence
        system_prompt_override: Optional custom system prompt
        agent_prompts: Optional dict of per-agent prompts

    Returns:
        Configured multi-agent system
    """
    logger.info("Creating multi-agent system (Planner + Subagents)")
    return create_multi_agent_system(
        llm_config=llm_config,
        checkpointer=checkpointer,
        enable_hitl=enable_hitl,
        enable_todo_list=enable_todo_list,
        system_prompt_override=system_prompt_override,
        agent_prompts=agent_prompts,
    )
