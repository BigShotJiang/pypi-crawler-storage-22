"""
LLM Factory for LangChain agent.

Provides functions to create LangChain LLM instances from configuration.
"""

import logging
from typing import Any, Dict

from agent_server.langchain.logging_utils import LLMTraceLogger

logger = logging.getLogger(__name__)


def create_llm(llm_config: Dict[str, Any]):
    """Create LangChain LLM from config.

    Args:
        llm_config: Configuration dictionary containing:
            - provider: "gemini", "openai", or "vllm"
            - gemini: {apiKey, model} for Gemini
            - openai: {apiKey, model} for OpenAI
            - vllm: {endpoint, model, apiKey} for vLLM

    Returns:
        Configured LangChain LLM instance

    Raises:
        ValueError: If provider is unsupported or API key is missing
    """
    provider = llm_config.get("provider", "gemini")
    callbacks = [LLMTraceLogger()]

    if provider == "gemini":
        return _create_gemini_llm(llm_config, callbacks)
    elif provider == "openai":
        return _create_openai_llm(llm_config, callbacks)
    elif provider == "vllm":
        return _create_vllm_llm(llm_config, callbacks)
    else:
        raise ValueError(f"Unsupported LLM provider: {provider}")


def _create_gemini_llm(llm_config: Dict[str, Any], callbacks):
    """Create Gemini LLM instance."""
    from langchain_google_genai import ChatGoogleGenerativeAI

    gemini_config = llm_config.get("gemini", {})
    api_key = gemini_config.get("apiKey")
    model = gemini_config.get("model", "gemini-2.5-pro")

    if not api_key:
        raise ValueError("Gemini API key not configured")

    logger.info(f"Creating Gemini LLM with model: {model}")

    # Gemini 2.5 Flash has issues with tool calling in LangChain
    # Use convert_system_message_to_human for better compatibility
    return ChatGoogleGenerativeAI(
        model=model,
        google_api_key=api_key,
        temperature=0.0,
        max_output_tokens=8192,
        convert_system_message_to_human=True,  # Better tool calling support
        callbacks=callbacks,
    )


def _create_openai_llm(llm_config: Dict[str, Any], callbacks):
    """Create OpenAI LLM instance."""
    from langchain_openai import ChatOpenAI

    openai_config = llm_config.get("openai", {})
    api_key = openai_config.get("apiKey")
    model = openai_config.get("model", "gpt-4")

    if not api_key:
        raise ValueError("OpenAI API key not configured")

    logger.info(f"Creating OpenAI LLM with model: {model}")

    return ChatOpenAI(
        model=model,
        api_key=api_key,
        temperature=0.0,
        max_tokens=4096,
        callbacks=callbacks,
    )


def _create_vllm_llm(llm_config: Dict[str, Any], callbacks):
    """Create vLLM-compatible LLM instance."""
    from langchain_openai import ChatOpenAI

    vllm_config = llm_config.get("vllm", {})
    endpoint = vllm_config.get("endpoint", "http://localhost:8000/v1")
    model = vllm_config.get("model", "default")
    api_key = vllm_config.get("apiKey", "dummy")
    use_responses_api = vllm_config.get("useResponsesApi", False)
    temperature = vllm_config.get("temperature", 0.0)

    logger.info(
        f"Creating vLLM LLM with model: {model}, endpoint: {endpoint}, "
        f"use_responses_api: {use_responses_api}, temperature: {temperature}"
    )

    # Use ChatGPTOSS for gpt-oss models (Harmony format with developer role)
    # NOTE: OpenRouter doesn't support 'developer' role - only use for direct gpt-oss endpoints
    is_openrouter = "openrouter" in endpoint.lower()
    if "gpt-oss" in model.lower() and not is_openrouter:
        from agent_server.langchain.models import ChatGPTOSS

        logger.info("Using ChatGPTOSS for gpt-oss model (developer role support)")
        return ChatGPTOSS(
            model=model,
            base_url=endpoint,
            api_key=api_key,
            temperature=temperature,
            max_tokens=8192,
            streaming=False,
            callbacks=callbacks,
        )
    elif "gpt-oss" in model.lower() and is_openrouter:
        logger.warning(
            "gpt-oss model via OpenRouter - using standard ChatOpenAI "
            "(developer role not supported by OpenRouter)"
        )

    return ChatOpenAI(
        model=model,
        api_key=api_key,
        base_url=endpoint,  # Use endpoint as-is (no /v1 suffix added)
        streaming=False,  # Agent mode: disable LLM streaming (SSE handled by agent server)
        temperature=temperature,
        max_tokens=8192,
        use_responses_api=use_responses_api,  # Use /v1/responses endpoint if True
        callbacks=callbacks,
    )


def create_summarization_llm(llm_config: Dict[str, Any]):
    """Create LLM for summarization middleware and /compact feature.

    Priority:
    1. If llm_config["summarization"]["enabled"] is True, use that config
    2. Otherwise, fall back to main provider with default summarization model

    Args:
        llm_config: Configuration dictionary

    Returns:
        LLM instance suitable for summarization, or None if unavailable
    """
    try:
        # 1. Check for dedicated summarization config
        summarization_config = llm_config.get("summarization", {})
        if summarization_config.get("enabled"):
            sum_provider = summarization_config.get("provider", "gemini")
            sum_model = summarization_config.get("model")
            logger.info(
                f"Using dedicated summarization LLM: provider={sum_provider}, model={sum_model or 'default'}"
            )
            return _create_llm_for_provider(
                llm_config, sum_provider, sum_model, for_summarization=True
            )

        # 2. Fall back to main provider with default summarization model
        provider = llm_config.get("provider", "gemini")
        logger.info(f"Using main provider for summarization: {provider}")
        return _create_llm_for_provider(
            llm_config, provider, None, for_summarization=True
        )

    except Exception as e:
        logger.warning(f"Failed to create summarization LLM: {e}")
        return None


def _create_llm_for_provider(
    llm_config: Dict[str, Any],
    provider: str,
    model_override: str = None,
    for_summarization: bool = False,
):
    """Create LLM instance for a specific provider.

    Args:
        llm_config: Full configuration dictionary (for credentials)
        provider: Provider to use ('gemini', 'openai', 'vllm')
        model_override: Optional model name override
        for_summarization: If True, use lightweight default models

    Returns:
        LLM instance or None
    """
    if provider == "gemini":
        from langchain_google_genai import ChatGoogleGenerativeAI

        gemini_config = llm_config.get("gemini", {})
        api_key = gemini_config.get("apiKey")
        if not api_key:
            logger.warning("No Gemini API key found")
            return None

        model = model_override or ("gemini-2.5-flash" if for_summarization else gemini_config.get("model", "gemini-2.5-flash"))
        return ChatGoogleGenerativeAI(
            model=model,
            google_api_key=api_key,
            temperature=0.0,
        )

    elif provider == "openai":
        from langchain_openai import ChatOpenAI

        openai_config = llm_config.get("openai", {})
        api_key = openai_config.get("apiKey")
        if not api_key:
            logger.warning("No OpenAI API key found")
            return None

        model = model_override or ("gpt-4o-mini" if for_summarization else openai_config.get("model", "gpt-4"))
        return ChatOpenAI(
            model=model,
            api_key=api_key,
            temperature=0.0,
        )

    elif provider == "vllm":
        vllm_config = llm_config.get("vllm", {})
        endpoint = vllm_config.get("endpoint", "http://localhost:8000/v1")
        api_key = vllm_config.get("apiKey", "dummy")
        model = model_override or vllm_config.get("model", "default")

        # Use ChatGPTOSS for gpt-oss models (but not via OpenRouter)
        is_openrouter = "openrouter" in endpoint.lower()
        if "gpt-oss" in model.lower() and not is_openrouter:
            from agent_server.langchain.models import ChatGPTOSS

            return ChatGPTOSS(
                model=model,
                base_url=endpoint,
                api_key=api_key,
                temperature=0.0,
            )

        from langchain_openai import ChatOpenAI

        return ChatOpenAI(
            model=model,
            api_key=api_key,
            base_url=endpoint,
            temperature=0.0,
        )

    else:
        logger.warning(f"Unknown provider: {provider}")
        return None
