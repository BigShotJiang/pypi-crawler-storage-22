"""
ContentInjectionMiddleware

Injects generated_content from LangGraph state into target tool args.
This eliminates JSON escaping issues when passing code/SQL between agents.

Runs BEFORE HumanInTheLoopMiddleware so HITL shows the full injected content.

Flow:
1. Subagent generates code/SQL → stored in state via Command
2. Main Agent calls target tool (e.g., jupyter_cell_tool) without args
3. This middleware reads state and injects content into tool args
4. HITL middleware sees full content for user approval

content_type → tool injection mapping:
- "python" → jupyter_cell_tool(code=...), write_file_tool(content=...)
- "sql"    → markdown_tool(content="```sql\\n...\\n```")
"""

import logging
from typing import Any, Callable, Union

from langchain.agents.middleware import AgentMiddleware
from langchain_core.messages import ToolMessage

logger = logging.getLogger(__name__)


class ContentInjectionMiddleware(AgentMiddleware):
    """Inject state's generated_content into target tool call args.

    When a subagent generates code/SQL via task_tool, it's stored in
    LangGraph state (generated_content, generated_content_type, content_description).
    This middleware reads the state and injects the content into the
    appropriate tool's arguments before execution.

    This ensures:
    1. Code/SQL bypasses LLM JSON serialization (no escaping issues)
    2. HITL middleware sees the full injected content for approval
    3. Main Agent doesn't need to copy code into tool args

    Usage in agent_factory.py:
        middleware = [
            ContentInjectionMiddleware(),  # BEFORE HITL
            ...,
            hitl_middleware,               # Sees injected content
        ]
    """

    def wrap_tool_call(self, request, handler):
        """Intercept tool calls and inject generated content from state.

        Args:
            request: ToolCallRequest with tool_call, state, runtime
            handler: Next handler in middleware chain

        Returns:
            ToolMessage or Command from handler
        """
        state = request.state
        if not state:
            return handler(request)

        content = state.get("generated_content") if isinstance(state, dict) else getattr(state, "generated_content", None)
        content_type = state.get("generated_content_type") if isinstance(state, dict) else getattr(state, "generated_content_type", None)
        desc = state.get("content_description") if isinstance(state, dict) else getattr(state, "content_description", None)

        if not content or not content_type:
            return handler(request)

        tool_call = request.tool_call
        tool_name = tool_call["name"]
        args = tool_call.get("args", {})

        new_args = None

        # Python code injection
        if content_type == "python":
            if tool_name == "jupyter_cell_tool" and not args.get("code"):
                new_args = {**args, "code": content}
                if desc and not args.get("description"):
                    new_args["description"] = desc
                logger.info(
                    "[ContentInjection] Injected python code (%d chars) into jupyter_cell_tool",
                    len(content),
                )
            elif tool_name == "write_file_tool" and not args.get("content"):
                new_args = {**args, "content": content}
                logger.info(
                    "[ContentInjection] Injected python code (%d chars) into write_file_tool",
                    len(content),
                )

        # SQL query injection
        elif content_type == "sql":
            if tool_name == "markdown_tool" and not args.get("content"):
                sql_markdown = f"```sql\n{content}\n```"
                if desc:
                    sql_markdown = f"{desc}\n\n{sql_markdown}"
                new_args = {**args, "content": sql_markdown}
                logger.info(
                    "[ContentInjection] Injected SQL (%d chars) into markdown_tool",
                    len(content),
                )

        if new_args is not None:
            modified_call = {**tool_call, "args": new_args}
            request = request.override(tool_call=modified_call)

        return handler(request)
