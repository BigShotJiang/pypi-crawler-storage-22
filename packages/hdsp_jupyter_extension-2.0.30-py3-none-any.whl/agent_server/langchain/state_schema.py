"""
HDSP Agent State Schema

Extends LangChain AgentState with custom fields for state-based
content passing between Main Agent and Subagents.

Key fields:
- generated_content: Python code or SQL query from subagents
- generated_content_type: "python" | "sql" to determine injection target
- content_description: [DESCRIPTION] section from subagent response

This eliminates JSON serialization issues when passing code/SQL
between agents — content flows through LangGraph State, not LLM JSON.
"""

from typing import Optional

from langchain.agents import AgentState


class HDSPAgentState(AgentState):
    """Extended agent state for HDSP multi-agent architecture.

    Adds fields for state-based content passing:
    - Subagent writes generated_content via Command
    - ContentInjectionMiddleware reads and injects into tool args
    """

    generated_content: Optional[str]
    """Generated Python code or SQL query from subagent.
    Set by task tool via Command(update={"generated_content": ...})."""

    generated_content_type: Optional[str]
    """Content type: "python" | "sql" | None.
    Determines which tool receives the injection."""

    content_description: Optional[str]
    """Description extracted from [DESCRIPTION] section.
    Injected alongside content into tool args."""

    todo_active: bool
    """True when todo list workflow is active.
    Set to True by TodoActiveMiddleware when write_todos is called.
    Set to False when final_summary_tool is called, user cancels, or new request starts."""
