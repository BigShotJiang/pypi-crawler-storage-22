"""
Chat Router - Chat and streaming endpoints

Handles conversational interactions with the LLM.
Supports @file context injection for including file contents in prompts.
"""

import json
import logging
import os
from typing import Any, AsyncGenerator, Dict, Optional

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from agent_server.config import ServerConfigManager
from hdsp_agent_core.managers.session_manager import ChatMessage, get_session_manager
from hdsp_agent_core.models.chat import ChatRequest, ChatResponse
from pydantic import BaseModel

from agent_server.context_providers import ContextProcessor
from agent_server.core.llm_service import LLMService
from agent_server.langchain.llm_factory import create_summarization_llm


# ═══════════════════════════════════════════════════════════════════════════
# Auto-Compact Configuration (Aligned with Agent mode SummarizationMiddleware)
# ═══════════════════════════════════════════════════════════════════════════
# These values should match agent_factory.py SummarizationMiddleware settings
AUTO_COMPACT_TOKEN_THRESHOLD = 30000  # Trigger when tokens exceed this threshold
AUTO_COMPACT_KEEP_MESSAGES = 15  # Keep last N messages after compaction

# Approximate tokens per character (for Korean/English mixed text)
CHARS_PER_TOKEN = 3.5  # Conservative estimate


def _estimate_tokens(text: str) -> int:
    """Estimate token count from text length."""
    return int(len(text) / CHARS_PER_TOKEN)


def _estimate_session_tokens(messages: list) -> int:
    """Estimate total tokens in session messages."""
    total_chars = sum(len(m.content) for m in messages)
    return int(total_chars / CHARS_PER_TOKEN)


# ═══════════════════════════════════════════════════════════════════════════
# Summarization Prompt (Claude Code Benchmark)
# ═══════════════════════════════════════════════════════════════════════════
SUMMARIZATION_PROMPT = """다음 대화 내용을 요약하여 향후 컨텍스트 윈도우에서 작업을 효율적으로 재개할 수 있도록 해주세요.
이 요약은 대화 히스토리를 대체하므로, 구조화되고 간결하며 실행 가능해야 합니다.

요약에 반드시 포함할 내용:

## 완료된 작업
- 완료된 태스크와 주요 결과물
- 생성/수정된 파일 목록

## 현재 상태
- 진행 중인 작업
- 마지막으로 논의된 주제

## 다음 단계
- 명확한 후속 액션 항목
- 보류 중인 결정 사항

## 핵심 맥락
- 사용자 선호사항 및 제약조건
- 중요한 기술적 결정사항
- 작업 재개에 필수적인 정보

작성 지침:
- 간결하되, 작업이 끊김 없이 계속될 수 있을 정도의 세부사항은 보존
- 불필요한 인사말, 확인 메시지, 중복 내용은 제외
- 코드 스니펫은 핵심적인 경우에만 포함
- 한국어로 작성

대화 내용:
{conversation}

요약:"""


# ═══════════════════════════════════════════════════════════════════════════
# Compact Request/Response Models
# ═══════════════════════════════════════════════════════════════════════════
class CompactRequest(BaseModel):
    """Request for conversation compaction."""

    conversationId: str
    llmConfig: Optional[dict] = None


class CompactResponse(BaseModel):
    """Response from conversation compaction."""

    success: bool
    message: str
    originalMessages: int
    compressedMessages: int
    summary: Optional[str] = None

router = APIRouter()
logger = logging.getLogger(__name__)


def _get_config() -> Dict[str, Any]:
    """Get current configuration from server AdminConfig."""
    return ServerConfigManager.get_instance().get_admin_config()


def _build_llm_config(llm_config) -> Dict[str, Any]:
    """
    Get LLM config from server AdminConfig.

    NOTE: Client-provided llmConfig is IGNORED for LLM settings.
    All LLM configuration (provider, API keys, models) comes from
    the server's AdminConfig managed by administrators.

    Args:
        llm_config: Ignored (kept for backward compatibility)

    Returns:
        Dict with provider, gemini, openai, vllm from server config
    """
    # Always use server config - ignore client-provided config
    admin_config = ServerConfigManager.get_instance().get_admin_config()

    config = {"provider": admin_config.get("provider", "gemini")}

    if admin_config.get("gemini"):
        config["gemini"] = admin_config["gemini"]

    if admin_config.get("openai"):
        config["openai"] = admin_config["openai"]

    if admin_config.get("vllm"):
        config["vllm"] = admin_config["vllm"]

    if admin_config.get("summarization"):
        config["summarization"] = admin_config["summarization"]

    logger.info("Using LLM config from server AdminConfig: provider=%s", config.get("provider"))
    return config


def _get_or_create_conversation(conversation_id: str | None) -> str:
    """Get existing conversation or create new one"""
    session_manager = get_session_manager()
    session = session_manager.get_or_create_session(conversation_id)
    return session.id


def _build_context(conversation_id: str, max_messages: int = 5) -> str | None:
    """Build conversation context from history"""
    session_manager = get_session_manager()
    return session_manager.build_context(conversation_id, max_messages)


def _store_messages(
    conversation_id: str, user_message: str, assistant_response: str
) -> None:
    """Store user and assistant messages in conversation history"""
    session_manager = get_session_manager()
    session_manager.store_messages(conversation_id, user_message, assistant_response)


async def _auto_compact_if_needed(
    conversation_id: str, llm_config: Dict[str, Any]
) -> Optional[str]:
    """
    Automatically compact conversation if token threshold exceeded.

    Aligned with Agent mode SummarizationMiddleware:
    - Trigger: Token count exceeds AUTO_COMPACT_TOKEN_THRESHOLD
    - Keep: Last AUTO_COMPACT_KEEP_MESSAGES messages
    - Result: [summary] + [recent messages]

    Returns:
        Summary string if compacted, None otherwise
    """
    from datetime import datetime

    session_manager = get_session_manager()
    session = session_manager.get_session(conversation_id)

    if not session or not session.messages:
        return None

    # Estimate tokens in session
    estimated_tokens = _estimate_session_tokens(session.messages)

    # Check if auto-compact needed (token-based, same as Agent mode)
    if estimated_tokens <= AUTO_COMPACT_TOKEN_THRESHOLD:
        return None

    # Need at least more messages than we keep
    if len(session.messages) <= AUTO_COMPACT_KEEP_MESSAGES:
        return None

    logger.info(
        f"[Chat] Auto-compact triggered for {conversation_id}: "
        f"~{estimated_tokens} tokens > {AUTO_COMPACT_TOKEN_THRESHOLD} threshold, "
        f"{len(session.messages)} messages"
    )

    try:
        # Split messages: older (to summarize) vs recent (to keep)
        messages_to_summarize = session.messages[:-AUTO_COMPACT_KEEP_MESSAGES]
        recent_messages = session.messages[-AUTO_COMPACT_KEEP_MESSAGES:]

        # Build conversation text for summarization
        conversation_text = "\n".join(
            [
                f"{'사용자' if m.role == 'user' else '어시스턴트'}: {m.content}"
                for m in messages_to_summarize
            ]
        )

        # Create summarization LLM (uses settings from llm_config)
        summarization_llm = create_summarization_llm(llm_config)

        if not summarization_llm:
            logger.warning("[Chat] Auto-compact skipped: no summarization LLM available")
            return None

        # Generate summary using LLM
        prompt = SUMMARIZATION_PROMPT.format(conversation=conversation_text)
        response = await summarization_llm.ainvoke(prompt)
        summary = response.content if hasattr(response, "content") else str(response)

        # Create summary message
        summary_message = ChatMessage(
            role="assistant",
            content=f"[이전 대화 요약]\n\n{summary}",
            timestamp=datetime.now().timestamp(),
        )

        # Replace session messages: [summary] + [last N]
        original_count = len(session.messages)
        session.messages = [summary_message] + list(recent_messages)
        session.updated_at = datetime.now().timestamp()

        # NOTE: Session save disabled - sessions are not loaded/used by frontend
        # session_manager._save_sessions()

        compressed_count = len(session.messages)
        logger.info(
            f"[Chat] Auto-compacted {conversation_id}: "
            f"{original_count} -> {compressed_count} messages"
        )

        return summary

    except Exception as e:
        logger.error(f"[Chat] Auto-compact failed: {e}", exc_info=True)
        return None


@router.post("/message", response_model=ChatResponse)
async def chat_message(request: ChatRequest) -> Dict[str, Any]:
    """
    Send a chat message and get a response.

    Supports @file context injection (e.g., "@file:path/to/file.py").
    Maintains conversation context across messages using conversation ID.
    """
    logger.info(f"Chat message received: {request.message[:100]}...")

    if not request.message:
        raise HTTPException(status_code=400, detail="message is required")

    try:
        # Use client-provided config or fallback to server config
        config = _build_llm_config(request.llmConfig)

        if not config or not config.get("provider"):
            raise HTTPException(
                status_code=400,
                detail="LLM not configured. Please configure LLM settings in Admin panel.",
            )

        # Get or create conversation
        conversation_id = _get_or_create_conversation(request.conversationId)

        # Build context from history
        history_context = _build_context(conversation_id)

        # Process @file and other context commands
        base_dir = getattr(request, 'baseDir', None) or os.getcwd()
        context_processor = ContextProcessor(base_dir=base_dir)
        file_context, cleaned_message, context_errors = context_processor.process_message(
            request.message
        )

        # Log any context processing errors
        if context_errors:
            logger.warning(f"Context processing errors: {context_errors}")

        # Combine all context
        all_context_parts = []
        if file_context:
            all_context_parts.append(file_context)
        if history_context:
            all_context_parts.append(history_context)
        combined_context = "\n\n".join(all_context_parts) if all_context_parts else None

        # Call LLM with client-provided config
        llm_service = LLMService(config)
        response = await llm_service.generate_response(
            cleaned_message, context=combined_context
        )

        # Store messages (use cleaned message for history)
        _store_messages(conversation_id, cleaned_message, response)

        # Auto-compact if token threshold exceeded
        auto_compact_summary = await _auto_compact_if_needed(conversation_id, config)

        # Get model info
        provider = config.get("provider", "unknown")
        model = config.get(provider, {}).get("model", "unknown")

        result = {
            "response": response,
            "conversationId": conversation_id,
            "model": f"{provider}/{model}",
        }

        # Include auto-compact info if triggered
        if auto_compact_summary:
            result["autoCompacted"] = True

        # Include context errors if any
        if context_errors:
            result["contextErrors"] = context_errors

        return result

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Chat failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/stream")
async def chat_stream(request: ChatRequest) -> StreamingResponse:
    """
    Send a chat message and get a streaming response.

    Supports @file context injection (e.g., "@file:path/to/file.py").
    Returns Server-Sent Events (SSE) with partial responses.
    """
    logger.info(f"Stream chat request: {request.message[:100]}...")

    if not request.message:
        raise HTTPException(status_code=400, detail="message is required")

    async def generate() -> AsyncGenerator[str, None]:
        try:
            # Use client-provided config or fallback to server config
            config = _build_llm_config(request.llmConfig)

            if not config or not config.get("provider"):
                yield f"data: {json.dumps({'error': 'LLM not configured. Please configure LLM settings in Admin panel.'})}\n\n"
                return

            # Get or create conversation
            conversation_id = _get_or_create_conversation(request.conversationId)

            # Build context from history
            history_context = _build_context(conversation_id)

            # Process @file and other context commands
            base_dir = getattr(request, 'baseDir', None) or os.getcwd()
            context_processor = ContextProcessor(base_dir=base_dir)
            file_context, cleaned_message, context_errors = context_processor.process_message(
                request.message
            )

            # Send context errors as a warning event
            if context_errors:
                yield f"data: {json.dumps({'warning': 'Context errors: ' + '; '.join(context_errors)})}\n\n"

            # Combine all context
            all_context_parts = []
            if file_context:
                all_context_parts.append(file_context)
            if history_context:
                all_context_parts.append(history_context)
            combined_context = "\n\n".join(all_context_parts) if all_context_parts else None

            # Stream LLM response with client-provided config
            llm_service = LLMService(config)
            full_response = ""

            async for chunk in llm_service.generate_response_stream(
                cleaned_message, context=combined_context
            ):
                full_response += chunk
                yield f"data: {json.dumps({'content': chunk, 'done': False})}\n\n"

            # Store messages after streaming complete (use cleaned message)
            _store_messages(conversation_id, cleaned_message, full_response)

            # Check if auto-compact is needed and send status updates
            session_manager = get_session_manager()
            session = session_manager.get_session(conversation_id)
            if session and session.messages:
                estimated_tokens = _estimate_session_tokens(session.messages)
                if estimated_tokens > AUTO_COMPACT_TOKEN_THRESHOLD and len(session.messages) > AUTO_COMPACT_KEEP_MESSAGES:
                    # Send status: compacting in progress
                    yield f"data: {json.dumps({'status': '대화 컨텍스트 요약 중...', 'icon': 'thinking'})}\n\n"

                    # Auto-compact
                    auto_compact_summary = await _auto_compact_if_needed(conversation_id, config)

                    # Send status: compact complete
                    if auto_compact_summary:
                        yield f"data: {json.dumps({'status': '대화가 자동으로 압축되었습니다.', 'icon': 'check'})}\n\n"

            # Send final chunk with conversation ID
            yield f"data: {json.dumps({'content': '', 'done': True, 'conversationId': conversation_id})}\n\n"

        except Exception as e:
            logger.error(f"Stream chat failed: {e}", exc_info=True)
            yield f"data: {json.dumps({'error': str(e)})}\n\n"

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",  # Disable nginx buffering
        },
    )


# ═══════════════════════════════════════════════════════════════════════════
# Compact Endpoint - LLM-based conversation summarization
# ═══════════════════════════════════════════════════════════════════════════
@router.post("/compact", response_model=CompactResponse)
async def compact_conversation(request: CompactRequest) -> CompactResponse:
    """
    Compact conversation history by summarizing older messages.

    Strategy (Claude Code benchmark):
    - Keep the last 3 messages intact
    - Summarize all older messages using LLM
    - Replace history with [summary] + [last 3 messages]
    """
    logger.info(f"Compact request for conversation: {request.conversationId}")

    session_manager = get_session_manager()
    session = session_manager.get_session(request.conversationId)

    if not session:
        return CompactResponse(
            success=False,
            message="세션을 찾을 수 없습니다.",
            originalMessages=0,
            compressedMessages=0,
        )

    original_count = len(session.messages)

    # Already minimal - no compaction needed
    if original_count <= 3:
        return CompactResponse(
            success=True,
            message="이미 최소 상태입니다. 압축이 필요하지 않습니다.",
            originalMessages=original_count,
            compressedMessages=original_count,
        )

    try:
        # Split messages: older (to summarize) vs recent (to keep)
        messages_to_summarize = session.messages[:-3]
        recent_messages = session.messages[-3:]

        # Build conversation text for summarization
        conversation_text = "\n".join(
            [
                f"{'사용자' if m.role == 'user' else '어시스턴트'}: {m.content}"
                for m in messages_to_summarize
            ]
        )

        # Create summarization LLM (always use server config)
        llm_config = _get_config()
        summarization_llm = create_summarization_llm(llm_config)

        if not summarization_llm:
            return CompactResponse(
                success=False,
                message="요약용 LLM을 생성할 수 없습니다. API 키를 확인해주세요.",
                originalMessages=original_count,
                compressedMessages=original_count,
            )

        # Generate summary using LLM
        prompt = SUMMARIZATION_PROMPT.format(conversation=conversation_text)
        response = await summarization_llm.ainvoke(prompt)
        summary = response.content if hasattr(response, "content") else str(response)

        # Create summary message
        from datetime import datetime

        summary_message = ChatMessage(
            role="assistant",
            content=f"[이전 대화 요약]\n\n{summary}",
            timestamp=datetime.now().timestamp(),
        )

        # Replace session messages: [summary] + [last 3]
        session.messages = [summary_message] + list(recent_messages)
        session.updated_at = datetime.now().timestamp()

        # Persist changes
        session_manager._save_sessions()

        compressed_count = len(session.messages)
        logger.info(
            f"Compacted conversation {request.conversationId}: "
            f"{original_count} -> {compressed_count} messages"
        )

        return CompactResponse(
            success=True,
            message=f"대화가 압축되었습니다. ({original_count}개 → {compressed_count}개 메시지)",
            originalMessages=original_count,
            compressedMessages=compressed_count,
            summary=summary,
        )

    except Exception as e:
        logger.error(f"Compact failed: {e}", exc_info=True)
        return CompactResponse(
            success=False,
            message=f"압축 중 오류가 발생했습니다: {str(e)}",
            originalMessages=original_count,
            compressedMessages=original_count,
        )
