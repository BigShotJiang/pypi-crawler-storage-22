"""
Config Router - Configuration management endpoints

Provides:
- GET/POST /config - Legacy full config (backward compatible)
- GET/POST /config/admin - Admin-only configuration
- GET/POST /config/user - User-only configuration
- GET /config/is-admin - Check if running in admin mode
- GET /config/prompts - Default system prompts
"""

from typing import Any, Dict, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from agent_server.config import ServerConfigManager

from agent_server.langchain.agent_prompts.athena_query_prompt import (
    ATHENA_QUERY_SYSTEM_PROMPT,
)

# Import prompts from centralized location
from agent_server.langchain.agent_prompts.planner_prompt import PLANNER_SYSTEM_PROMPT
from agent_server.langchain.agent_prompts.python_developer_prompt import (
    PYTHON_DEVELOPER_SYSTEM_PROMPT,
)
from agent_server.langchain.agent_prompts.researcher_prompt import (
    RESEARCHER_SYSTEM_PROMPT,
)

# Import new schema models
from agent_server.routers.config_schema import (
    AdminConfigResponse,
    AdminConfigUpdateRequest,
    IsAdminResponse,
    UserConfigResponse,
    UserConfigUpdateRequest,
    is_admin_mode,
)

router = APIRouter()


class ConfigResponse(BaseModel):
    """Configuration response model"""

    provider: str
    gemini: Optional[Dict[str, Any]] = None
    openai: Optional[Dict[str, Any]] = None
    vllm: Optional[Dict[str, Any]] = None


class ConfigUpdateRequest(BaseModel):
    """Configuration update request model"""

    provider: Optional[str] = None
    gemini: Optional[Dict[str, Any]] = None
    openai: Optional[Dict[str, Any]] = None
    vllm: Optional[Dict[str, Any]] = None


@router.get("", response_model=ConfigResponse)
async def get_config() -> ConfigResponse:
    """
    Get current configuration.

    Returns the current LLM provider settings (API keys are masked).
    """
    try:
        config_manager = ServerConfigManager.get_instance()
        config = config_manager.get_config()

        # Mask API keys for security
        masked_config = _mask_api_keys(config)

        return ConfigResponse(
            provider=masked_config.get("provider", "gemini"),
            gemini=masked_config.get("gemini"),
            openai=masked_config.get("openai"),
            vllm=masked_config.get("vllm"),
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("")
async def update_config(request: ConfigUpdateRequest) -> Dict[str, Any]:
    """
    Update configuration.

    Updates LLM provider settings.
    """
    try:
        config_manager = ServerConfigManager.get_instance()

        # Build update dict from request
        updates = {}
        if request.provider:
            updates["provider"] = request.provider
        if request.gemini:
            updates["gemini"] = request.gemini
        if request.openai:
            updates["openai"] = request.openai
        if request.vllm:
            updates["vllm"] = request.vllm

        if updates:
            config_manager.update_config(updates)

        return {"status": "success", "message": "Configuration updated"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


def _mask_api_keys(config: Dict[str, Any]) -> Dict[str, Any]:
    """Mask API keys in configuration for security"""
    masked = config.copy()

    for provider in ["gemini", "openai", "vllm"]:
        if provider in masked and isinstance(masked[provider], dict):
            provider_config = masked[provider].copy()
            if "apiKey" in provider_config and provider_config["apiKey"]:
                key = provider_config["apiKey"]
                if len(key) > 8:
                    provider_config["apiKey"] = f"{key[:4]}...{key[-4:]}"
                else:
                    provider_config["apiKey"] = "***"
            masked[provider] = provider_config

    return masked


# =============================================================================
# Admin Mode Detection API
# =============================================================================


@router.get("/is-admin", response_model=IsAdminResponse)
async def check_admin_mode() -> IsAdminResponse:
    """
    Check if the current environment is in admin mode.

    Admin mode is determined by environment variables:
    - Neither SAGEMAKER_SPACE_NAME nor HDSP_PRJ_ID is set (development env)
    - OR SAGEMAKER_SPACE_NAME contains 'pl2wadmprj'
    - OR HDSP_PRJ_ID equals 'pl2wadmprj'
    """
    is_admin, reason = is_admin_mode()
    return IsAdminResponse(isAdmin=is_admin, reason=reason)


# =============================================================================
# Admin Config API
# =============================================================================


@router.get("/admin", response_model=AdminConfigResponse)
async def get_admin_config() -> AdminConfigResponse:
    """
    Get admin configuration (LLM settings, prompts, server URLs).

    API keys are masked for security.
    """
    try:
        config_manager = ServerConfigManager.get_instance()
        config = config_manager.get_admin_config()

        # Mask API keys
        masked_config = _mask_api_keys(config)

        # Also mask embedding API key if present
        if "embedding" in masked_config and isinstance(
            masked_config["embedding"], dict
        ):
            embedding_config = masked_config["embedding"].copy()
            if "apiKey" in embedding_config and embedding_config["apiKey"]:
                key = embedding_config["apiKey"]
                if len(key) > 8:
                    embedding_config["apiKey"] = f"{key[:4]}...{key[-4:]}"
                else:
                    embedding_config["apiKey"] = "***"
            masked_config["embedding"] = embedding_config

        return AdminConfigResponse(
            provider=masked_config.get("provider", "gemini"),
            gemini=masked_config.get("gemini", {}),
            openai=masked_config.get("openai", {}),
            vllm=masked_config.get("vllm", {}),
            summarization=masked_config.get("summarization", {}),
            embedding=masked_config.get("embedding", {}),
            rag=masked_config.get("rag", {}),
            agentServerUrl=masked_config.get("agentServerUrl", "http://localhost:8000"),
            agentServerTimeout=masked_config.get("agentServerTimeout", 120.0),
            prompts=masked_config.get("prompts", {}),
            useResponsesApi=masked_config.get("useResponsesApi", False),
            idleTimeout=masked_config.get("idleTimeout", 300),
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/admin")
async def update_admin_config(request: AdminConfigUpdateRequest) -> Dict[str, Any]:
    """
    Update admin configuration.

    Only updates provided fields.
    """
    try:
        config_manager = ServerConfigManager.get_instance()

        # Build update dict from request
        updates = {}
        if request.provider is not None:
            updates["provider"] = request.provider
        if request.gemini is not None:
            updates["gemini"] = request.gemini
        if request.openai is not None:
            updates["openai"] = request.openai
        if request.vllm is not None:
            updates["vllm"] = request.vllm
        if request.summarization is not None:
            updates["summarization"] = request.summarization
        if request.embedding is not None:
            updates["embedding"] = request.embedding
        if request.rag is not None:
            updates["rag"] = request.rag
        if request.agentServerUrl is not None:
            updates["agentServerUrl"] = request.agentServerUrl
        if request.agentServerTimeout is not None:
            updates["agentServerTimeout"] = request.agentServerTimeout
        if request.prompts is not None:
            updates["prompts"] = request.prompts
        if request.useResponsesApi is not None:
            updates["useResponsesApi"] = request.useResponsesApi
        if request.idleTimeout is not None:
            updates["idleTimeout"] = request.idleTimeout

        if updates:
            config_manager.update_admin_config(updates)

        return {"status": "success", "message": "Admin configuration updated"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# =============================================================================
# User Config API
# =============================================================================


@router.get("/user", response_model=UserConfigResponse)
async def get_user_config() -> UserConfigResponse:
    """
    Get user configuration (preferences).
    """
    try:
        config_manager = ServerConfigManager.get_instance()
        config = config_manager.get_user_config()

        return UserConfigResponse(
            workspaceRoot=config.get("workspaceRoot", ""),
            temperature=config.get("temperature", 0.7),
            autoApprove=config.get("autoApprove", False),
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/user")
async def update_user_config(request: UserConfigUpdateRequest) -> Dict[str, Any]:
    """
    Update user configuration.

    Only updates provided fields.
    """
    try:
        config_manager = ServerConfigManager.get_instance()

        # Build update dict from request
        updates = {}
        if request.workspaceRoot is not None:
            updates["workspaceRoot"] = request.workspaceRoot
        if request.temperature is not None:
            updates["temperature"] = request.temperature
        if request.autoApprove is not None:
            updates["autoApprove"] = request.autoApprove

        if updates:
            config_manager.update_user_config(updates)

        return {"status": "success", "message": "User configuration updated"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# =============================================================================
# Default Prompts API
# =============================================================================


class DefaultPromptsResponse(BaseModel):
    """Default prompts response model"""

    planner: str  # Multi-agent: Planner/Coordinator prompt
    python_developer: str  # Multi-agent: Python Developer prompt
    researcher: str  # Multi-agent: Researcher prompt
    athena_query: str  # Multi-agent: Athena Query prompt


@router.get("/prompts", response_model=DefaultPromptsResponse)
async def get_default_prompts() -> DefaultPromptsResponse:
    """
    Get default system prompts for multi-agent mode.

    Returns centralized prompts that frontend can use as defaults.
    This ensures prompts are managed in one place (backend).
    """
    return DefaultPromptsResponse(
        planner=PLANNER_SYSTEM_PROMPT,
        python_developer=PYTHON_DEVELOPER_SYSTEM_PROMPT,
        researcher=RESEARCHER_SYSTEM_PROMPT,
        athena_query=ATHENA_QUERY_SYSTEM_PROMPT,
    )
