"""
Config Schema - Pydantic models for Admin/User configuration

Admin Config: LLM settings, prompts, server URLs (managed by administrators)
User Config: Workspace settings, temperature, auto-approve (user preferences)
"""

import os
from enum import Enum
from typing import Any, Dict, Optional

from pydantic import BaseModel, Field

# =============================================================================
# Enums
# =============================================================================


class LLMProvider(str, Enum):
    """Supported LLM providers"""

    GEMINI = "gemini"
    OPENAI = "openai"
    VLLM = "vllm"


# =============================================================================
# Admin Config Models
# =============================================================================


class GeminiConfig(BaseModel):
    """Gemini provider configuration"""

    apiKey: str = ""
    model: str = "gemini-2.5-pro"


class OpenAIConfig(BaseModel):
    """OpenAI provider configuration"""

    apiKey: str = ""
    model: str = "gpt-4o"


class VLLMConfig(BaseModel):
    """vLLM/OpenRouter provider configuration"""

    endpoint: str = "http://localhost:8000"
    apiKey: str = ""
    model: str = "meta-llama/Llama-2-7b-chat-hf"


class SummarizationConfig(BaseModel):
    """Summarization LLM configuration (optional separate LLM)"""

    enabled: bool = False
    provider: LLMProvider = LLMProvider.GEMINI
    model: Optional[str] = None  # If None, use provider's default


class EmbeddingConfig(BaseModel):
    """Embedding model configuration for RAG"""

    provider: str = "openai"
    model: str = "text-embedding-3-small"
    apiKey: Optional[str] = None  # If None, use main provider's key


class RAGConfig(BaseModel):
    """RAG/Qdrant configuration"""

    qdrantUrl: str = "http://localhost:6333"
    collectionName: str = "hdsp_docs"


class AgentPromptsConfig(BaseModel):
    """Custom system prompts for agents"""

    planner: Optional[str] = None
    python_developer: Optional[str] = None
    researcher: Optional[str] = None
    athena_query: Optional[str] = None


class AdminConfig(BaseModel):
    """
    Administrator-managed configuration.

    Includes:
    - LLM provider settings (API keys, models)
    - Summarization LLM settings
    - Embedding configuration
    - RAG/Qdrant settings
    - Agent server URL
    - Agent prompts
    - Idle timeout
    - Use Responses API toggle
    """

    # LLM Provider Settings
    provider: LLMProvider = LLMProvider.GEMINI
    gemini: GeminiConfig = Field(default_factory=GeminiConfig)
    openai: OpenAIConfig = Field(default_factory=OpenAIConfig)
    vllm: VLLMConfig = Field(default_factory=VLLMConfig)

    # Summarization LLM (optional separate LLM for context compression)
    summarization: SummarizationConfig = Field(default_factory=SummarizationConfig)

    # Embedding Configuration
    embedding: EmbeddingConfig = Field(default_factory=EmbeddingConfig)

    # RAG Configuration
    rag: RAGConfig = Field(default_factory=RAGConfig)

    # Agent Server Configuration
    agentServerUrl: str = "http://localhost:8000"
    agentServerTimeout: float = 120.0

    # Agent Prompts (custom overrides)
    prompts: AgentPromptsConfig = Field(default_factory=AgentPromptsConfig)

    # Feature Toggles
    useResponsesApi: bool = False
    idleTimeout: int = 300  # seconds


# =============================================================================
# User Config Models
# =============================================================================


class UserConfig(BaseModel):
    """
    User-managed configuration (preferences).

    Includes:
    - Workspace root path
    - Temperature setting
    - Auto-approve toggle
    """

    workspaceRoot: str = ""
    temperature: float = Field(default=0.7, ge=0.0, le=2.0)
    autoApprove: bool = False


# =============================================================================
# Combined Config
# =============================================================================


class FullConfig(BaseModel):
    """Full configuration combining admin and user settings"""

    admin: AdminConfig = Field(default_factory=AdminConfig)
    user: UserConfig = Field(default_factory=UserConfig)


# =============================================================================
# Admin Mode Detection
# =============================================================================


def is_admin_mode() -> tuple[bool, str | None]:
    """
    Detect if running in admin mode based on environment variables.

    Admin mode conditions:
    1. NEITHER SAGEMAKER_SPACE_NAME NOR HDSP_PRJ_ID is set (development environment)
    2. OR SAGEMAKER_SPACE_NAME contains 'pl2wadmprj' as substring
    3. OR HDSP_PRJ_ID equals 'pl2wadmprj'

    Returns:
        tuple[bool, str | None]: (is_admin, reason)
    """
    sagemaker_space = os.environ.get("SAGEMAKER_SPACE_NAME")
    hdsp_prj_id = os.environ.get("HDSP_PRJ_ID")

    # Development environment: neither env var is set
    if sagemaker_space is None and hdsp_prj_id is None:
        return True, "development_environment"

    # Check SAGEMAKER_SPACE_NAME contains admin project ID
    if sagemaker_space and "pl2wadmprj" in sagemaker_space:
        return True, "sagemaker_admin_space"

    # Check HDSP_PRJ_ID equals admin project ID
    if hdsp_prj_id == "pl2wadmprj":
        return True, "hdsp_admin_project"

    return False, None


# =============================================================================
# API Request/Response Models
# =============================================================================


class AdminConfigResponse(BaseModel):
    """Admin config response (with masked API keys)"""

    provider: str
    gemini: Dict[str, Any]
    openai: Dict[str, Any]
    vllm: Dict[str, Any]
    summarization: Dict[str, Any]
    embedding: Dict[str, Any]
    rag: Dict[str, Any]
    agentServerUrl: str
    agentServerTimeout: float
    prompts: Dict[str, Any]
    useResponsesApi: bool
    idleTimeout: int


class AdminConfigUpdateRequest(BaseModel):
    """Admin config update request"""

    provider: Optional[str] = None
    gemini: Optional[Dict[str, Any]] = None
    openai: Optional[Dict[str, Any]] = None
    vllm: Optional[Dict[str, Any]] = None
    summarization: Optional[Dict[str, Any]] = None
    embedding: Optional[Dict[str, Any]] = None
    rag: Optional[Dict[str, Any]] = None
    agentServerUrl: Optional[str] = None
    agentServerTimeout: Optional[float] = None
    prompts: Optional[Dict[str, Any]] = None
    useResponsesApi: Optional[bool] = None
    idleTimeout: Optional[int] = None


class UserConfigResponse(BaseModel):
    """User config response"""

    workspaceRoot: str
    temperature: float
    autoApprove: bool


class UserConfigUpdateRequest(BaseModel):
    """User config update request"""

    workspaceRoot: Optional[str] = None
    temperature: Optional[float] = None
    autoApprove: Optional[bool] = None


class IsAdminResponse(BaseModel):
    """Response for admin mode check"""

    isAdmin: bool
    reason: Optional[str] = None
