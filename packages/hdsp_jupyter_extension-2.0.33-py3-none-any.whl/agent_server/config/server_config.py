"""
Server Configuration Manager - Agent Server specific settings

This config manager handles all LLM and server settings.
Stored in ~/.hdsp_agent/server_config.json

This is separate from the client-side config which only stores agentServerUrl.
"""

import json
import os
import tempfile
from pathlib import Path
from typing import Any, Dict


class ServerConfigManager:
    """Manage Agent Server configuration persistence"""

    _instance = None
    _config_file = None

    def __init__(self):
        try:
            # 1순위: 환경변수
            config_dir = os.environ.get("HDSP_AGENT_CONFIG_DIR")

            # 2순위: 홈 디렉토리 ~/.hdsp_agent
            if not config_dir:
                try:
                    config_dir = os.path.expanduser("~/.hdsp_agent")
                except Exception:
                    config_dir = None

            # 경로가 유효한지 체크하고, 없으면 생성 시도
            if config_dir:
                config_path = Path(config_dir)
                try:
                    config_path.mkdir(parents=True, exist_ok=True)
                    self._config_file = config_path / "server_config.json"
                except Exception as e:
                    print(f"Warning: Cannot write to {config_dir}: {e}")
                    self._config_file = None

            # 3순위 (비상용): 쓰기 실패했거나 경로가 없으면 /tmp 사용
            if not self._config_file:
                tmp_dir = Path(tempfile.gettempdir()) / "hdsp_agent_server"
                tmp_dir.mkdir(parents=True, exist_ok=True)
                self._config_file = tmp_dir / "server_config.json"
                print(f"Using temporary config path: {self._config_file}")

        except Exception as e:
            print(f"Critical Error in ServerConfigManager init: {e}")
            self._config_file = Path("/tmp/hdsp_agent_server_config_fallback.json")

        self._config = self._load_config()
        print(f"ServerConfigManager initialized: {self._config_file}")

    @classmethod
    def get_instance(cls):
        """Get singleton instance"""
        if cls._instance is None:
            cls._instance = ServerConfigManager()
        return cls._instance

    @classmethod
    def reset_instance(cls):
        """Reset singleton instance (for testing)"""
        cls._instance = None

    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from file"""
        if not self._config_file.exists():
            return self._default_config()

        try:
            with open(self._config_file, "r") as f:
                loaded = json.load(f)
                # Merge with defaults to ensure all keys exist
                defaults = self._default_config()
                defaults.update(loaded)
                return defaults
        except (json.JSONDecodeError, IOError) as e:
            print(f"Error loading server config: {e}")
            return self._default_config()

    def _default_config(self) -> Dict[str, Any]:
        """Get default server configuration"""
        return {
            # LLM Provider Settings
            "provider": "gemini",
            "gemini": {
                "apiKey": "",
                "apiKeys": [],
                "model": "gemini-2.5-flash"
            },
            "openai": {
                "apiKey": "",
                "model": "gpt-4o"
            },
            "vllm": {
                "endpoint": "https://openrouter.ai/api/v1",
                "apiKey": "",
                "model": "openai/gpt-4o",
                "useResponsesApi": False
            },
            # Summarization LLM
            "summarization": {
                "enabled": False,
                "provider": "gemini",
                "model": None,
                "endpoint": "",
                "apiKey": ""
            },
            # Embedding
            "embedding": {
                "provider": "openai",
                "model": "text-embedding-3-small",
                "apiKey": "",
                "endpoint": ""
            },
            # RAG
            "rag": {
                "qdrantUrl": "http://localhost:6333",
                "collectionName": "hdsp_docs"
            },
            # Server Settings
            "agentServerTimeout": 120.0,
            "idleTimeout": 3600,  # 1 hour default
            # Prompts (None = use defaults)
            "prompts": {
                "planner": None,
                "python_developer": None,
                "researcher": None,
                "athena_query": None
            },
            # Feature Toggles
            "useResponsesApi": False,
            # User Settings (can be overridden per-user)
            "workspaceRoot": "",
            "temperature": 0.7,
            "autoApprove": False
        }

    def get_config(self) -> Dict[str, Any]:
        """Get current configuration"""
        self._config = self._load_config()
        return self._config.copy()

    def save_config(self, config: Dict[str, Any]):
        """Save configuration to file"""
        self._config.update(config)
        self._config_file.parent.mkdir(parents=True, exist_ok=True)

        try:
            with open(self._config_file, "w") as f:
                json.dump(self._config, f, indent=2)
        except IOError as e:
            raise RuntimeError(f"Failed to save server config: {e}")

    def get(self, key: str, default=None):
        """Get specific config value"""
        return self._config.get(key, default)

    def set(self, key: str, value: Any):
        """Set specific config value"""
        self._config[key] = value
        self.save_config(self._config)

    def update_config(self, updates: Dict[str, Any]):
        """Update configuration with partial updates (deep merge for nested dicts)"""
        for key, value in updates.items():
            if (
                key in self._config
                and isinstance(self._config[key], dict)
                and isinstance(value, dict)
            ):
                self._config[key].update(value)
            else:
                self._config[key] = value
        self.save_config(self._config)

    def get_admin_config(self) -> Dict[str, Any]:
        """Get all server configuration (for admin API)"""
        config = self.get_config()
        # Return everything except internal keys
        return config.copy()

    def update_admin_config(self, updates: Dict[str, Any]):
        """Update server configuration"""
        self.update_config(updates)

    def get_user_config(self) -> Dict[str, Any]:
        """Get user configuration.

        Returns user-specific settings (workspaceRoot, temperature, autoApprove).
        """
        config = self.get_config()
        return {
            "workspaceRoot": config.get("workspaceRoot", ""),
            "temperature": config.get("temperature", 0.7),
            "autoApprove": config.get("autoApprove", False)
        }

    def update_user_config(self, updates: Dict[str, Any]):
        """Update user configuration.

        Updates user-specific settings in the server config file.
        """
        # Only allow user-configurable fields
        allowed_fields = {"workspaceRoot", "temperature", "autoApprove"}
        filtered_updates = {k: v for k, v in updates.items() if k in allowed_fields}
        if filtered_updates:
            self.update_config(filtered_updates)


def get_server_config_manager() -> ServerConfigManager:
    """Get the singleton ServerConfigManager instance"""
    return ServerConfigManager.get_instance()
