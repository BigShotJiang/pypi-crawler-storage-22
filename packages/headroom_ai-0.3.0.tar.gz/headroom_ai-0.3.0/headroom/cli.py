"""Backwards compatibility - CLI moved to headroom.cli package."""

from headroom.cli import main

if __name__ == "__main__":
    main()
