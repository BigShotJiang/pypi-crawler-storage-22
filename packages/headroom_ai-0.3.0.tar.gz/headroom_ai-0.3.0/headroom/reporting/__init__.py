"""Reporting module for Headroom SDK."""

from .generator import generate_report

__all__ = ["generate_report"]
