"""Tests for the universal compression module."""
