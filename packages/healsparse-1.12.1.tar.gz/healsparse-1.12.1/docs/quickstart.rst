Quickstart
==========

A `jupyter notebook <http://jupyter-notebook.readthedocs.io/en/latest/>`_ is available for tutorial purposes
`here <https://github.com/LSSTDESC/healsparse/tree/master/tutorial/quickstart.ipynb>`_
