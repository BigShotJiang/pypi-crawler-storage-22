from .report_generator import generate_hospital_report
