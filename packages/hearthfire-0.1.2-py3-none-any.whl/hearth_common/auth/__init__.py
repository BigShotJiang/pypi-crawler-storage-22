"""Hearth authentication utilities."""
