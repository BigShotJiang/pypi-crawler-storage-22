"""Hearth communication protocol definitions."""
