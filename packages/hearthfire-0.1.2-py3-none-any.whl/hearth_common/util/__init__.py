"""Hearth utility functions."""
