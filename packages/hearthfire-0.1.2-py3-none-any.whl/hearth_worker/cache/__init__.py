"""Hearth Worker snapshot cache."""
