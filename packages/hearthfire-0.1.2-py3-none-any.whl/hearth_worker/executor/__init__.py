"""Hearth Worker task executor."""
