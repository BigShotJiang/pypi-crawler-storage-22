"""Hearth Worker spool queue."""
