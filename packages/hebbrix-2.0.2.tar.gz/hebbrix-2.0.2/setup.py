"""
Hebbrix Python SDK Setup
Official Python SDK for the Hebbrix Memory API
"""
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="hebbrix",
    version="2.0.0",
    author="Hebbrix Team",
    author_email="support@hebbrix.com",
    description="Advanced Memory API for AI Agents with Reinforcement Learning - 3-line integration",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/hebbrix/hebbrix-python",
    project_urls={
        "Documentation": "https://docs.hebbrix.com",
        "Bug Tracker": "https://github.com/hebbrix/hebbrix-python/issues",
        "Source": "https://github.com/hebbrix/hebbrix-python",
        "API Reference": "https://api.hebbrix.com/docs",
    },
    packages=find_packages(include=["hebbrix", "hebbrix.*"]),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Database",
        "Framework :: AsyncIO",
    ],
    keywords="ai memory agents llm chatbot rag vector-search knowledge-graph reinforcement-learning",
    python_requires=">=3.8",
    install_requires=[
        "httpx>=0.25.0",
        "requests>=2.31.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "pytest-cov>=4.0.0",
            "black>=23.0.0",
            "mypy>=1.0.0",
        ],
    },
)
