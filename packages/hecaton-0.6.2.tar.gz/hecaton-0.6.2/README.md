# hecaton
A solution for self-hosted GPU access from a source that isn't deployed
