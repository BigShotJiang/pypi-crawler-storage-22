# HELIX - LightRAG + Graphiti Hybrid Knowledge Graph System

A plug-and-play RAG (Retrieval-Augmented Generation) system that combines:

- **LightRAG**: Efficient vector retrieval with knowledge graph enhancement
- **Graphiti**: Temporal knowledge graph with bi-temporal tracking
- **Multi-hop Reasoning**: Connect multiple facts for complex queries
- **Hallucination Detection**: Built-in answer verification with CFI scoring

## Quick Start

### Installation

```bash
pip install helix-rag
```

### Basic Usage

```python
from helix import Helix
import asyncio

async def main():
    # Initialize with your credentials
    async with Helix(
        google_api_key="your-gemini-api-key",
        neo4j_uri="neo4j+ssc://your-instance.databases.neo4j.io",
        neo4j_password="your-password"
    ) as h:
        # Ingest documents
        await h.ingest("""
            Albert Einstein developed the theory of special relativity in 1905.
            He later developed general relativity in 1915.
        """)
        
        # Query with temporal awareness
        result = await h.query(
            "When did Einstein develop special relativity?",
            mode="temporal"
        )
        
        print(f"Answer: {result.answer}")
        print(f"Confidence: {result.confidence:.2%}")

asyncio.run(main())
```

### CLI Usage

```bash
# Run demo to test connections
helix demo

# Query the knowledge graph
helix query "What is the capital of France?"

# Ingest a document
helix ingest document.txt

# Run benchmark evaluation
helix eval

# Show version
helix version
```

## Features

### Temporal Queries
Query knowledge at specific points in time:

```python
result = await h.query(
    "Who was the CEO of Apple?",
    query_time="2015-01-01"  # Point-in-time query
)
```

### Multi-hop Reasoning
Automatically connects multiple facts:

```python
result = await h.query(
    "What is the birthplace of the person who wrote Hamlet?",
    mode="multi_hop"
)
```

### Hallucination Detection
Built-in verification with Composite Fidelity Index:

```python
result = await h.query("...", verify=True)
print(f"CFI Score: {result.verification['cfi']}")
print(f"Hallucination: {result.verification['hallucination_detected']}")
```

## Configuration

HELIX can be configured via:

1. **Constructor parameters** (recommended for notebooks)
2. **Environment variables** (recommended for production)
3. **`.env` file** (recommended for local development)

### Environment Variables

```bash
GOOGLE_API_KEY=your-gemini-api-key
NEO4J_URI=neo4j+ssc://your-instance.databases.neo4j.io
NEO4J_USER=neo4j
NEO4J_PASSWORD=your-password
SUPABASE_URL=https://your-project.supabase.co  # Optional
SUPABASE_KEY=your-supabase-key                 # Optional
```

## Requirements

- Python 3.10+
- Neo4j Aura (or self-hosted Neo4j 5.x)
- Google AI API key (for Gemini)

## License

MIT License
