"""HELIX - LightRAG + Graphiti Hybrid Knowledge Graph System

A plug-and-play RAG system combining temporal knowledge graphs
with multi-hop reasoning and hallucination detection.

Quick Start:
    from helix import Helix
    
    async with Helix(google_api_key="...", neo4j_uri="...") as h:
        result = await h.query("When was the Eiffel Tower built?")
        print(result.answer)
"""

__version__ = "0.1.0"
__author__ = "HELIX Research Team"

# Primary API
from helix.core import Helix, QueryResult, create_helix

# Configuration
from helix.config import HELIXConfig, config

# Key components (for advanced usage)
from helix.pipeline.query import HELIXQueryPipeline
from helix.storage.graphiti_storage import GraphitiStorage

__all__ = [
    # Primary API
    "Helix",
    "QueryResult",
    "create_helix",
    
    # Configuration
    "HELIXConfig",
    "config",
    
    # Advanced
    "HELIXQueryPipeline",
    "GraphitiStorage",
    
    # Version
    "__version__",
]
