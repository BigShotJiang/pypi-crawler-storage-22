"""HELIX package entry point for python -m helix"""
import asyncio
from helix.main import main

if __name__ == "__main__":
    asyncio.run(main())
