"""HELIX Command Line Interface

Usage:
    helix demo          Run demo to test connections
    helix query "..."   Query the knowledge graph
    helix ingest FILE   Ingest a document
    helix eval          Run benchmark evaluation
    helix version       Show version
"""
import sys
import asyncio
from pathlib import Path


def main():
    """Main CLI entry point."""
    if len(sys.argv) < 2:
        print(__doc__)
        return
    
    command = sys.argv[1].lower()
    
    if command == "version":
        from helix import __version__
        print(f"HELIX v{__version__}")
        
    elif command == "demo":
        from helix.main import demo
        asyncio.run(demo())
        
    elif command == "query":
        if len(sys.argv) < 3:
            print("Usage: helix query \"your question here\"")
            return
        question = " ".join(sys.argv[2:])
        asyncio.run(_query(question))
        
    elif command == "ingest":
        if len(sys.argv) < 3:
            print("Usage: helix ingest <file_path>")
            return
        file_path = sys.argv[2]
        asyncio.run(_ingest(file_path))
        
    elif command == "eval":
        asyncio.run(_evaluate())
        
    else:
        print(f"Unknown command: {command}")
        print(__doc__)


async def _query(question: str):
    """Query command implementation."""
    from helix import Helix
    
    print(f"Query: {question}")
    print("-" * 40)
    
    async with Helix() as h:
        result = await h.query(question)
        print(f"Answer: {result.answer}")
        print(f"Confidence: {result.confidence:.2%}")
        print(f"Mode: {result.mode}")


async def _ingest(file_path: str):
    """Ingest command implementation."""
    from helix import Helix
    
    path = Path(file_path)
    if not path.exists():
        print(f"File not found: {file_path}")
        return
    
    text = path.read_text(encoding="utf-8")
    print(f"Ingesting {path.name} ({len(text)} chars)...")
    
    async with Helix() as h:
        await h.ingest(text, name=path.stem, source=str(path))
        print("✓ Ingested successfully!")


async def _evaluate():
    """Evaluation command implementation."""
    from helix import Helix
    from helix.evaluation import HELIXEvaluator, BenchmarkCategory
    
    print("HELIX Benchmark Evaluation")
    print("=" * 50)
    
    async with Helix() as h:
        evaluator = HELIXEvaluator(h._pipeline)
        
        # Run on sample data
        for category in BenchmarkCategory:
            print(f"\n{category.value.upper()}")
            results = await evaluator.evaluate_category(category, limit_per_dataset=5)
            
            for dataset, dataset_results in results.items():
                summary = evaluator.summarize(dataset_results)
                print(f"  {dataset}: EM={summary.avg_exact_match:.2f}, F1={summary.avg_f1:.2f}")


if __name__ == "__main__":
    main()
