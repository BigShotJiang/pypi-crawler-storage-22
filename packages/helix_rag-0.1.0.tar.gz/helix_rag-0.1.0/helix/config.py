"""HELIX Configuration Module"""
import os
from pathlib import Path
from dotenv import load_dotenv
from pydantic_settings import BaseSettings

# Load .env from current directory
env_path = Path(__file__).parent / ".env"
load_dotenv(env_path)


class HELIXConfig(BaseSettings):
    """Configuration settings for HELIX system"""
    
    # Google AI / Gemini
    google_api_key: str = os.getenv("GOOGLE_API_KEY", "")
    gemini_model: str = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
    embedding_model: str = os.getenv("EMBEDDING_MODEL", "gemini-embedding-001")
    embedding_dim: int = int(os.getenv("EMBEDDING_DIM", "1536"))
    
    # Neo4j
    neo4j_uri: str = os.getenv("NEO4J_URI", "")
    neo4j_user: str = os.getenv("NEO4J_USER", "")
    neo4j_password: str = os.getenv("NEO4J_PASSWORD", "")
    
    # Supabase (for vector storage)
    supabase_url: str = os.getenv("SUPABASE_URL", "")
    supabase_key: str = os.getenv("SUPABASE_KEY", "")
    
    # Working directory
    working_dir: str = os.getenv("HELIX_WORKING_DIR", "./helix_data")
    
    # Retrieval settings
    max_tokens_per_query: int = 8192
    top_k_entities: int = 20
    max_hops: int = 3
    
    # Hallucination detection thresholds
    hallucination_threshold: float = 0.85
    entity_grounding_weight: float = 0.4
    relation_preservation_weight: float = 0.4
    temporal_consistency_weight: float = 0.2
    
    class Config:
        env_file = ".env"
        extra = "ignore"


config = HELIXConfig()
