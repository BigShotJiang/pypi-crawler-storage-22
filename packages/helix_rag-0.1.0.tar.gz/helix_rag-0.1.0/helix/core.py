"""HELIX - LightRAG + Graphiti Hybrid Knowledge Graph System

A plug-and-play RAG system combining:
- LightRAG's efficient vector retrieval
- Graphiti's temporal knowledge graph
- Multi-hop reasoning capabilities
- Built-in hallucination detection

Example:
    from helix import Helix
    
    # Initialize with your credentials
    h = Helix(
        google_api_key="...",
        neo4j_uri="neo4j+ssc://...",
        neo4j_user="neo4j",
        neo4j_password="..."
    )
    
    # Ingest documents
    await h.ingest("Einstein developed the theory of relativity in 1905.")
    
    # Query with temporal awareness
    result = await h.query("When did Einstein develop relativity?")
    print(result.answer)
"""
from typing import Optional, Dict, Any, List, Union
from dataclasses import dataclass
import asyncio

from helix.config import HELIXConfig


@dataclass
class QueryResult:
    """Result from a HELIX query."""
    answer: str
    confidence: float
    mode: str  # temporal, multi_hop, simple
    sources: List[Dict[str, Any]]
    verification: Optional[Dict[str, Any]] = None
    
    def __str__(self) -> str:
        return self.answer


class Helix:
    """
    Unified HELIX interface for LightRAG + Graphiti hybrid RAG.
    
    This is the primary entry point for using HELIX. It wraps:
    - GraphitiStorage for temporal knowledge graph
    - TemporalQueryHandler for point-in-time queries
    - MultiHopRetriever for complex reasoning
    - HallucinationDetector for answer verification
    
    Example:
        h = Helix(google_api_key="...", neo4j_uri="...")
        await h.initialize()
        result = await h.query("What is the capital of France?")
    """
    
    def __init__(
        self,
        # API Keys
        google_api_key: Optional[str] = None,
        
        # Neo4j Configuration
        neo4j_uri: Optional[str] = None,
        neo4j_user: str = "neo4j",
        neo4j_password: Optional[str] = None,
        
        # Supabase (optional vector storage)
        supabase_url: Optional[str] = None,
        supabase_key: Optional[str] = None,
        
        # Model Configuration (None = use config/env defaults)
        gemini_model: Optional[str] = None,
        embedding_model: Optional[str] = None,
        embedding_dim: Optional[int] = None,
        
        # Workspace
        workspace: str = "default",
        
        # Advanced options (None = use config/env defaults)
        max_hops: Optional[int] = None,
        hallucination_threshold: Optional[float] = None,
        
        # Use existing config
        config: Optional[HELIXConfig] = None
    ):
        """
        Initialize HELIX.
        
        Args:
            google_api_key: Google AI API key for Gemini
            neo4j_uri: Neo4j connection URI (use neo4j+ssc:// for Aura)
            neo4j_user: Neo4j username
            neo4j_password: Neo4j password
            supabase_url: Optional Supabase URL for vector storage
            supabase_key: Optional Supabase API key
            gemini_model: LLM model to use (default: from env/config)
            embedding_model: Embedding model (default: from env/config)
            embedding_dim: Embedding dimensions (default: from env/config)
            workspace: Knowledge graph namespace
            max_hops: Maximum hops for multi-hop retrieval
            hallucination_threshold: CFI threshold for detection
            config: Use existing HELIXConfig instead of parameters
        """
        # Build configuration
        if config:
            self._config = config
        else:
            import os
            
            # Set environment variables for config to pick up
            if google_api_key:
                os.environ["GOOGLE_API_KEY"] = google_api_key
            if neo4j_uri:
                os.environ["NEO4J_URI"] = neo4j_uri
            if neo4j_password:
                os.environ["NEO4J_PASSWORD"] = neo4j_password
            if supabase_url:
                os.environ["SUPABASE_URL"] = supabase_url
            if supabase_key:
                os.environ["SUPABASE_KEY"] = supabase_key
            
            # Create config (picks up from env)
            self._config = HELIXConfig()
            
            # Override with explicit parameters if provided
            if gemini_model is not None:
                self._config.gemini_model = gemini_model
            if embedding_model is not None:
                self._config.embedding_model = embedding_model
            if embedding_dim is not None:
                self._config.embedding_dim = embedding_dim
            if max_hops is not None:
                self._config.max_hops = max_hops
            if hallucination_threshold is not None:
                self._config.hallucination_threshold = hallucination_threshold
            if neo4j_user:
                self._config.neo4j_user = neo4j_user
        
        self.workspace = workspace
        self._pipeline = None
        self._initialized = False
    
    async def initialize(self) -> "Helix":
        """
        Initialize connections to Neo4j and other services.
        
        Returns:
            Self for chaining
        """
        if self._initialized:
            return self
        
        from helix.pipeline.query import HELIXQueryPipeline
        
        self._pipeline = HELIXQueryPipeline(workspace=self.workspace)
        await self._pipeline.initialize()
        self._initialized = True
        
        return self
    
    async def query(
        self,
        question: str,
        mode: str = "auto",
        query_time: Optional[str] = None,
        verify: bool = True
    ) -> QueryResult:
        """
        Query the knowledge graph.
        
        Args:
            question: Natural language question
            mode: Query mode - "auto", "temporal", "multi_hop", or "simple"
            query_time: Point-in-time for temporal queries (ISO format)
            verify: Run hallucination detection on answer
            
        Returns:
            QueryResult with answer, confidence, and sources
        """
        await self.initialize()
        
        result = await self._pipeline.query(
            query_text=question,
            mode=mode,
            query_time=query_time,
            verify=verify
        )
        
        return QueryResult(
            answer=result.get("answer", ""),
            confidence=result.get("confidence", 1.0),
            mode=result.get("mode", "simple"),
            sources=result.get("context", []),
            verification=result.get("verification")
        )
    
    async def ingest(
        self,
        text: str,
        name: Optional[str] = None,
        source: str = "document",
        reference_time: Optional[str] = None
    ) -> bool:
        """
        Ingest text into the knowledge graph.
        
        Args:
            text: Content to ingest
            name: Unique identifier for the content
            source: Source description
            reference_time: Temporal reference (ISO format)
            
        Returns:
            True if successful
        """
        await self.initialize()
        
        if name is None:
            import hashlib
            name = hashlib.md5(text.encode()).hexdigest()[:12]
        
        await self._pipeline.ingest(
            text=text,
            name=name,
            source=source,
            reference_time=reference_time
        )
        
        return True
    
    async def search(
        self,
        query: str,
        num_results: int = 10
    ) -> List[Dict[str, Any]]:
        """
        Search the knowledge graph without generating an answer.
        
        Args:
            query: Search query
            num_results: Maximum results to return
            
        Returns:
            List of matching facts/entities
        """
        await self.initialize()
        
        return await self._pipeline.storage.search(
            query=query,
            num_results=num_results
        )
    
    async def close(self):
        """Close all connections."""
        if self._pipeline:
            await self._pipeline.close()
        self._initialized = False
    
    # Context manager support
    async def __aenter__(self) -> "Helix":
        await self.initialize()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()
    
    @property
    def config(self) -> HELIXConfig:
        """Access the configuration."""
        return self._config
    
    @property
    def storage(self):
        """Access the underlying storage layer."""
        if not self._pipeline:
            raise RuntimeError("HELIX not initialized. Call await helix.initialize() first.")
        return self._pipeline.storage


# Convenience function for quick usage
async def create_helix(**kwargs) -> Helix:
    """
    Create and initialize a HELIX instance.
    
    Example:
        h = await create_helix(google_api_key="...", neo4j_uri="...")
        result = await h.query("What is AI?")
    """
    h = Helix(**kwargs)
    await h.initialize()
    return h
