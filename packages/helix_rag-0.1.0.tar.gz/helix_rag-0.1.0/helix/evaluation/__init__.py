"""HELIX Evaluation Package

Comprehensive evaluation framework for benchmarking HELIX across:
- Temporal QA (Time-LongQA, ECT-QA, MultiTQ)
- Hallucination Detection (Legal QA, Medical QA, FEVER)
- Multi-Hop Reasoning (MuSiQue, 2WikiMHQA, HotpotQA)
- Scalability (UltraDomain, Custom 10M)
"""

from helix.evaluation.metrics import (
    compute_exact_match,
    compute_f1_score,
    compute_hit_at_k,
    compute_cfi_metrics
)
from helix.evaluation.benchmark_loader import BenchmarkLoader, BenchmarkCategory, EvalSample
from helix.evaluation.evaluator import HELIXEvaluator, EvalResult, EvalSummary

__all__ = [
    "BenchmarkLoader",
    "BenchmarkCategory",
    "EvalSample",
    "HELIXEvaluator",
    "EvalResult",
    "EvalSummary",
    "compute_exact_match",
    "compute_f1_score",
    "compute_hit_at_k",
    "compute_cfi_metrics"
]

