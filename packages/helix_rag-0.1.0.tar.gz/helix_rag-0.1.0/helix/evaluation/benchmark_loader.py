"""Benchmark Loader for HELIX Evaluation

Supports loading and standardizing datasets for:
- Temporal: Time-LongQA, ECT-QA, MultiTQ
- Hallucination: Legal QA, Medical QA, FEVER
- Multi-Hop: MuSiQue, 2WikiMHQA, HotpotQA
- Scalability: UltraDomain, Custom datasets
"""
from typing import List, Dict, Any, Optional, Generator
from dataclasses import dataclass
from enum import Enum
import json
import os
from pathlib import Path


class BenchmarkCategory(Enum):
    """Benchmark categories matching evaluation priorities."""
    TEMPORAL = "temporal"
    HALLUCINATION = "hallucination"
    MULTI_HOP = "multi_hop"
    SCALABILITY = "scalability"


@dataclass
class EvalSample:
    """Standardized evaluation sample format."""
    id: str
    question: str
    answer: str
    category: BenchmarkCategory
    dataset: str
    
    # Optional fields for specific benchmarks
    supporting_facts: Optional[List[str]] = None
    temporal_context: Optional[str] = None
    valid_at: Optional[str] = None
    entities: Optional[List[str]] = None
    hops: Optional[int] = None
    metadata: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "question": self.question,
            "answer": self.answer,
            "category": self.category.value,
            "dataset": self.dataset,
            "supporting_facts": self.supporting_facts,
            "temporal_context": self.temporal_context,
            "valid_at": self.valid_at,
            "entities": self.entities,
            "hops": self.hops,
            "metadata": self.metadata
        }


class BenchmarkLoader:
    """
    Load and standardize benchmark datasets.
    
    Usage:
        loader = BenchmarkLoader(data_dir="./datasets")
        
        # Load specific dataset
        samples = loader.load("musique", split="dev")
        
        # Load by category
        temporal_samples = loader.load_category(BenchmarkCategory.TEMPORAL)
    """
    
    # Dataset metadata
    DATASETS = {
        # Temporal
        "time_longqa": {
            "category": BenchmarkCategory.TEMPORAL,
            "file_pattern": "time_longqa_{split}.json",
            "metrics": ["hit@1", "hit@5", "accuracy"]
        },
        "ect_qa": {
            "category": BenchmarkCategory.TEMPORAL,
            "file_pattern": "ect_qa_{split}.json",
            "metrics": ["hit@1", "hit@5", "accuracy"]
        },
        "multitq": {
            "category": BenchmarkCategory.TEMPORAL,
            "file_pattern": "multitq_{split}.json",
            "metrics": ["hit@1", "hit@5", "accuracy"]
        },
        
        # Hallucination
        "legal_qa": {
            "category": BenchmarkCategory.HALLUCINATION,
            "file_pattern": "legal_qa_{split}.json",
            "metrics": ["auc", "eg", "rp", "cfi"]
        },
        "medical_qa": {
            "category": BenchmarkCategory.HALLUCINATION,
            "file_pattern": "medical_qa_{split}.json",
            "metrics": ["auc", "eg", "rp", "cfi"]
        },
        "fever": {
            "category": BenchmarkCategory.HALLUCINATION,
            "file_pattern": "fever_{split}.json",
            "metrics": ["auc", "eg", "rp", "cfi"]
        },
        
        # Multi-Hop
        "musique": {
            "category": BenchmarkCategory.MULTI_HOP,
            "file_pattern": "musique_{split}.json",
            "metrics": ["f1", "em", "retrieval_f1"]
        },
        "2wikimhqa": {
            "category": BenchmarkCategory.MULTI_HOP,
            "file_pattern": "2wikimhqa_{split}.json",
            "metrics": ["f1", "em", "retrieval_f1"]
        },
        "hotpotqa": {
            "category": BenchmarkCategory.MULTI_HOP,
            "file_pattern": "hotpotqa_{split}.json",
            "metrics": ["f1", "em", "retrieval_f1"]
        },
        
        # Scalability
        "ultradomain": {
            "category": BenchmarkCategory.SCALABILITY,
            "file_pattern": "ultradomain_{split}.json",
            "metrics": ["tokens", "latency", "cost"]
        }
    }
    
    def __init__(self, data_dir: str = "./datasets"):
        """
        Initialize benchmark loader.
        
        Args:
            data_dir: Directory containing dataset files
        """
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
    
    def load(
        self, 
        dataset: str, 
        split: str = "dev",
        limit: Optional[int] = None
    ) -> List[EvalSample]:
        """
        Load a specific dataset.
        
        Args:
            dataset: Dataset name (e.g., "musique", "hotpotqa")
            split: Data split ("train", "dev", "test")
            limit: Optional limit on number of samples
            
        Returns:
            List of EvalSample objects
        """
        dataset = dataset.lower().replace("-", "_")
        
        if dataset not in self.DATASETS:
            raise ValueError(f"Unknown dataset: {dataset}. Available: {list(self.DATASETS.keys())}")
        
        meta = self.DATASETS[dataset]
        file_path = self.data_dir / meta["file_pattern"].format(split=split)
        
        if not file_path.exists():
            # Try to create sample data for testing
            return self._generate_sample_data(dataset, meta["category"], limit or 10)
        
        samples = []
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        
        for item in data[:limit] if limit else data:
            sample = self._standardize_sample(item, dataset, meta["category"])
            if sample:
                samples.append(sample)
        
        return samples
    
    def load_category(
        self, 
        category: BenchmarkCategory,
        split: str = "dev",
        limit_per_dataset: Optional[int] = None
    ) -> List[EvalSample]:
        """Load all datasets for a category."""
        samples = []
        
        for dataset_name, meta in self.DATASETS.items():
            if meta["category"] == category:
                try:
                    dataset_samples = self.load(dataset_name, split, limit_per_dataset)
                    samples.extend(dataset_samples)
                except Exception as e:
                    print(f"Warning: Could not load {dataset_name}: {e}")
        
        return samples
    
    def stream(
        self, 
        dataset: str, 
        split: str = "dev"
    ) -> Generator[EvalSample, None, None]:
        """Stream samples one at a time for large datasets."""
        dataset = dataset.lower().replace("-", "_")
        meta = self.DATASETS.get(dataset)
        
        if not meta:
            return
        
        file_path = self.data_dir / meta["file_pattern"].format(split=split)
        
        if not file_path.exists():
            return
        
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        
        for item in data:
            sample = self._standardize_sample(item, dataset, meta["category"])
            if sample:
                yield sample
    
    def _standardize_sample(
        self, 
        item: Dict[str, Any], 
        dataset: str,
        category: BenchmarkCategory
    ) -> Optional[EvalSample]:
        """Convert raw dataset item to standardized EvalSample."""
        try:
            # Handle different dataset formats
            question = item.get("question") or item.get("query") or item.get("claim", "")
            answer = item.get("answer") or item.get("answers", [""])[0] if isinstance(item.get("answers"), list) else item.get("answers", "")
            
            if isinstance(answer, list):
                answer = answer[0] if answer else ""
            
            sample = EvalSample(
                id=str(item.get("id") or item.get("_id") or hash(question)),
                question=question,
                answer=str(answer),
                category=category,
                dataset=dataset,
                supporting_facts=item.get("supporting_facts"),
                temporal_context=item.get("temporal_context") or item.get("time_context"),
                valid_at=item.get("valid_at") or item.get("timestamp"),
                entities=item.get("entities"),
                hops=item.get("hops") or item.get("num_hops"),
                metadata=item.get("metadata", {})
            )
            
            return sample
        except Exception:
            return None
    
    def _generate_sample_data(
        self, 
        dataset: str, 
        category: BenchmarkCategory,
        count: int = 10
    ) -> List[EvalSample]:
        """Generate sample data for testing when real data is unavailable."""
        samples = []
        
        # Sample questions by category
        sample_questions = {
            BenchmarkCategory.TEMPORAL: [
                ("Who was the CEO of Apple in 2011?", "Tim Cook", "2011-08-24"),
                ("What was the population of Tokyo in 2020?", "13.96 million", "2020-01-01"),
                ("When did World War II end?", "1945", "1945-09-02"),
            ],
            BenchmarkCategory.HALLUCINATION: [
                ("Is the Eiffel Tower located in Berlin?", "No", None),
                ("Does water freeze at 0 degrees Celsius?", "Yes", None),
                ("Is the Great Wall of China visible from space?", "No", None),
            ],
            BenchmarkCategory.MULTI_HOP: [
                ("Who directed the movie starring the actor who played Iron Man?", "Jon Favreau", None),
                ("What is the capital of the country where the Eiffel Tower is located?", "Paris", None),
                ("Who wrote the book that inspired the Shawshank Redemption movie?", "Stephen King", None),
            ],
            BenchmarkCategory.SCALABILITY: [
                ("What are all the products sold by Apple?", "iPhone, iPad, Mac, etc.", None),
                ("List all Nobel Prize winners in Physics", "Many scientists", None),
            ]
        }
        
        category_samples = sample_questions.get(category, sample_questions[BenchmarkCategory.MULTI_HOP])
        
        for i in range(count):
            q, a, t = category_samples[i % len(category_samples)]
            samples.append(EvalSample(
                id=f"{dataset}_sample_{i}",
                question=f"{q} (Sample {i})",
                answer=a,
                category=category,
                dataset=dataset,
                valid_at=t,
                hops=2 if category == BenchmarkCategory.MULTI_HOP else None
            ))
        
        return samples
    
    def get_metrics_for_dataset(self, dataset: str) -> List[str]:
        """Get the evaluation metrics for a specific dataset."""
        dataset = dataset.lower().replace("-", "_")
        meta = self.DATASETS.get(dataset, {})
        return meta.get("metrics", [])
    
    def list_datasets(self, category: Optional[BenchmarkCategory] = None) -> List[str]:
        """List available datasets, optionally filtered by category."""
        if category:
            return [name for name, meta in self.DATASETS.items() if meta["category"] == category]
        return list(self.DATASETS.keys())
