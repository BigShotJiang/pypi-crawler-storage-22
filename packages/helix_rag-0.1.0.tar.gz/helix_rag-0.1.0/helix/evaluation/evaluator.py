"""HELIX Evaluator - End-to-End Benchmark Evaluation

Orchestrates evaluation across all benchmark categories:
- Temporal QA evaluation with Hit@K metrics
- Hallucination detection with CFI scoring
- Multi-hop reasoning with F1/EM metrics
- Scalability testing with token/latency tracking
"""
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field
from datetime import datetime
import json
import asyncio
from pathlib import Path

from helix.evaluation.benchmark_loader import BenchmarkLoader, BenchmarkCategory, EvalSample
from helix.evaluation.metrics import (
    compute_exact_match,
    compute_f1_score,
    compute_hit_at_k,
    compute_cfi_metrics,
    compute_retrieval_f1,
    compute_auc,
    LatencyTracker,
    TokenCounter
)
from helix.config import config


@dataclass
class EvalResult:
    """Result for a single evaluation sample."""
    sample_id: str
    dataset: str
    category: str
    question: str
    ground_truth: str
    prediction: str
    
    # Metrics
    exact_match: float = 0.0
    f1_score: float = 0.0
    hit_at_1: float = 0.0
    hit_at_5: float = 0.0
    
    # Hallucination metrics
    entity_grounding: float = 1.0
    relation_preservation: float = 1.0
    temporal_consistency: float = 1.0
    cfi: float = 1.0
    
    # Retrieval metrics
    retrieval_f1: float = 0.0
    retrieved_facts: List[str] = field(default_factory=list)
    
    # Performance
    latency_ms: float = 0.0
    tokens_used: int = 0
    
    # Metadata
    error: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "sample_id": self.sample_id,
            "dataset": self.dataset,
            "category": self.category,
            "question": self.question,
            "ground_truth": self.ground_truth,
            "prediction": self.prediction,
            "exact_match": self.exact_match,
            "f1_score": self.f1_score,
            "hit_at_1": self.hit_at_1,
            "hit_at_5": self.hit_at_5,
            "entity_grounding": self.entity_grounding,
            "relation_preservation": self.relation_preservation,
            "temporal_consistency": self.temporal_consistency,
            "cfi": self.cfi,
            "retrieval_f1": self.retrieval_f1,
            "latency_ms": self.latency_ms,
            "tokens_used": self.tokens_used,
            "error": self.error
        }


@dataclass
class EvalSummary:
    """Aggregated evaluation summary."""
    dataset: str
    category: str
    total_samples: int
    
    # Aggregated metrics
    avg_exact_match: float = 0.0
    avg_f1: float = 0.0
    avg_hit_at_1: float = 0.0
    avg_hit_at_5: float = 0.0
    avg_cfi: float = 0.0
    avg_retrieval_f1: float = 0.0
    
    # Performance
    avg_latency_ms: float = 0.0
    total_tokens: int = 0
    estimated_cost: float = 0.0
    
    # Error rate
    error_rate: float = 0.0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "dataset": self.dataset,
            "category": self.category,
            "total_samples": self.total_samples,
            "avg_exact_match": self.avg_exact_match,
            "avg_f1": self.avg_f1,
            "avg_hit_at_1": self.avg_hit_at_1,
            "avg_hit_at_5": self.avg_hit_at_5,
            "avg_cfi": self.avg_cfi,
            "avg_retrieval_f1": self.avg_retrieval_f1,
            "avg_latency_ms": self.avg_latency_ms,
            "total_tokens": self.total_tokens,
            "estimated_cost": self.estimated_cost,
            "error_rate": self.error_rate
        }


class HELIXEvaluator:
    """
    End-to-end HELIX evaluation pipeline.
    
    Usage:
        evaluator = HELIXEvaluator(helix_pipeline)
        
        # Evaluate specific dataset
        results = await evaluator.evaluate("musique", split="dev")
        
        # Evaluate entire category
        results = await evaluator.evaluate_category(BenchmarkCategory.MULTI_HOP)
        
        # Full evaluation
        all_results = await evaluator.run_full_evaluation()
    """
    
    def __init__(
        self, 
        pipeline,
        data_dir: str = "./datasets",
        output_dir: str = "./eval_results"
    ):
        """
        Initialize evaluator.
        
        Args:
            pipeline: HELIX query pipeline (HELIXQueryPipeline instance)
            data_dir: Directory containing benchmark datasets
            output_dir: Directory for saving evaluation results
        """
        self.pipeline = pipeline
        self.loader = BenchmarkLoader(data_dir)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        self.latency_tracker = LatencyTracker()
        self.token_counter = TokenCounter()
    
    async def evaluate(
        self,
        dataset: str,
        split: str = "dev",
        limit: Optional[int] = None,
        verbose: bool = True
    ) -> List[EvalResult]:
        """
        Evaluate on a specific dataset.
        
        Args:
            dataset: Dataset name
            split: Data split
            limit: Optional sample limit
            verbose: Print progress
            
        Returns:
            List of EvalResult objects
        """
        samples = self.loader.load(dataset, split, limit)
        results = []
        
        if verbose:
            print(f"Evaluating {dataset} ({len(samples)} samples)...")
        
        for i, sample in enumerate(samples):
            try:
                result = await self._evaluate_sample(sample)
                results.append(result)
                
                if verbose and (i + 1) % 10 == 0:
                    print(f"  Processed {i + 1}/{len(samples)}")
                    
            except Exception as e:
                results.append(EvalResult(
                    sample_id=sample.id,
                    dataset=sample.dataset,
                    category=sample.category.value,
                    question=sample.question,
                    ground_truth=sample.answer,
                    prediction="",
                    error=str(e)
                ))
        
        return results
    
    async def _evaluate_sample(self, sample: EvalSample) -> EvalResult:
        """Evaluate a single sample."""
        self.latency_tracker.start()
        
        # Query HELIX pipeline
        if sample.category == BenchmarkCategory.TEMPORAL:
            response = await self._query_temporal(sample)
        elif sample.category == BenchmarkCategory.HALLUCINATION:
            response = await self._query_with_verification(sample)
        elif sample.category == BenchmarkCategory.MULTI_HOP:
            response = await self._query_multi_hop(sample)
        else:
            response = await self._query_standard(sample)
        
        latency = self.latency_tracker.stop() * 1000  # Convert to ms
        
        # Extract prediction and context
        prediction = response.get("answer", "")
        retrieved_facts = response.get("supporting_facts", [])
        verification = response.get("verification", {})
        
        # Compute metrics
        em = compute_exact_match(prediction, sample.answer)
        f1 = compute_f1_score(prediction, sample.answer)
        
        # Hit@K for temporal
        hit1 = 0.0
        hit5 = 0.0
        if sample.category == BenchmarkCategory.TEMPORAL:
            candidates = response.get("candidates", [prediction])
            hit1 = compute_hit_at_k(candidates, sample.answer, k=1)
            hit5 = compute_hit_at_k(candidates, sample.answer, k=5)
        
        # CFI for hallucination
        eg = verification.get("entity_grounding", 1.0)
        rp = verification.get("relation_preservation", 1.0)
        tc = verification.get("temporal_consistency", 1.0)
        cfi_metrics = compute_cfi_metrics(eg, rp, tc)
        
        # Retrieval F1 for multi-hop
        ret_f1 = 0.0
        if sample.supporting_facts:
            ret_f1 = compute_retrieval_f1(retrieved_facts, sample.supporting_facts)
        
        return EvalResult(
            sample_id=sample.id,
            dataset=sample.dataset,
            category=sample.category.value,
            question=sample.question,
            ground_truth=sample.answer,
            prediction=prediction,
            exact_match=em,
            f1_score=f1,
            hit_at_1=hit1,
            hit_at_5=hit5,
            entity_grounding=eg,
            relation_preservation=rp,
            temporal_consistency=tc,
            cfi=cfi_metrics["cfi"],
            retrieval_f1=ret_f1,
            retrieved_facts=retrieved_facts,
            latency_ms=latency,
            tokens_used=response.get("tokens_used", 0)
        )
    
    async def _query_temporal(self, sample: EvalSample) -> Dict[str, Any]:
        """Query with temporal context."""
        from helix.temporal import TemporalQueryHandler
        
        handler = TemporalQueryHandler(self.pipeline.storage)
        result = await handler.query(
            sample.question,
            query_time=sample.valid_at
        )
        
        return {
            "answer": result.get("answer", ""),
            "candidates": [result.get("answer", "")],
            "supporting_facts": [],
            "tokens_used": 0
        }
    
    async def _query_with_verification(self, sample: EvalSample) -> Dict[str, Any]:
        """Query with hallucination verification."""
        from helix.verification import HallucinationDetector
        
        # Get initial answer
        result = await self.pipeline.query(sample.question)
        answer = result.get("answer", "")
        context = result.get("context", [])
        
        # Verify answer
        detector = HallucinationDetector(self.pipeline.storage)
        verification = await detector.verify_answer(
            sample.question,
            answer,
            context
        )
        
        return {
            "answer": answer,
            "verification": verification,
            "supporting_facts": [],
            "tokens_used": 0
        }
    
    async def _query_multi_hop(self, sample: EvalSample) -> Dict[str, Any]:
        """Query with multi-hop retrieval."""
        from helix.retrieval import MultiHopRetriever
        
        retriever = MultiHopRetriever(self.pipeline.storage)
        result = await retriever.answer_multi_hop(
            sample.question,
            max_hops=sample.hops or 3
        )
        
        # Extract supporting facts from paths
        supporting_facts = []
        for path in result.get("paths", []):
            for edge in path.get("edges", []):
                if edge.get("fact"):
                    supporting_facts.append(edge["fact"])
        
        return {
            "answer": result.get("answer", ""),
            "supporting_facts": supporting_facts,
            "tokens_used": 0
        }
    
    async def _query_standard(self, sample: EvalSample) -> Dict[str, Any]:
        """Standard query without special handling."""
        result = await self.pipeline.query(sample.question)
        return {
            "answer": result.get("answer", ""),
            "supporting_facts": [],
            "tokens_used": 0
        }
    
    async def evaluate_category(
        self,
        category: BenchmarkCategory,
        split: str = "dev",
        limit_per_dataset: Optional[int] = None
    ) -> Dict[str, List[EvalResult]]:
        """Evaluate all datasets in a category."""
        datasets = self.loader.list_datasets(category)
        results = {}
        
        for dataset in datasets:
            results[dataset] = await self.evaluate(dataset, split, limit_per_dataset)
        
        return results
    
    def summarize(self, results: List[EvalResult]) -> EvalSummary:
        """Compute summary statistics from results."""
        if not results:
            return EvalSummary(dataset="", category="", total_samples=0)
        
        dataset = results[0].dataset
        category = results[0].category
        n = len(results)
        
        # Filter out errors for metric computation
        valid_results = [r for r in results if r.error is None]
        n_valid = len(valid_results)
        
        if n_valid == 0:
            return EvalSummary(
                dataset=dataset,
                category=category,
                total_samples=n,
                error_rate=1.0
            )
        
        return EvalSummary(
            dataset=dataset,
            category=category,
            total_samples=n,
            avg_exact_match=sum(r.exact_match for r in valid_results) / n_valid,
            avg_f1=sum(r.f1_score for r in valid_results) / n_valid,
            avg_hit_at_1=sum(r.hit_at_1 for r in valid_results) / n_valid,
            avg_hit_at_5=sum(r.hit_at_5 for r in valid_results) / n_valid,
            avg_cfi=sum(r.cfi for r in valid_results) / n_valid,
            avg_retrieval_f1=sum(r.retrieval_f1 for r in valid_results) / n_valid,
            avg_latency_ms=sum(r.latency_ms for r in valid_results) / n_valid,
            total_tokens=sum(r.tokens_used for r in results),
            error_rate=(n - n_valid) / n
        )
    
    def save_results(
        self,
        results: List[EvalResult],
        filename: Optional[str] = None
    ) -> Path:
        """Save results to JSON file."""
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"eval_results_{timestamp}.json"
        
        output_path = self.output_dir / filename
        
        data = {
            "timestamp": datetime.now().isoformat(),
            "total_samples": len(results),
            "summary": self.summarize(results).to_dict(),
            "results": [r.to_dict() for r in results]
        }
        
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        
        return output_path
    
    async def run_full_evaluation(
        self,
        split: str = "dev",
        limit_per_dataset: Optional[int] = None,
        save: bool = True
    ) -> Dict[str, Dict[str, Any]]:
        """
        Run evaluation across all categories and datasets.
        
        Returns:
            Dictionary with category -> dataset -> summary
        """
        all_results = {}
        
        for category in BenchmarkCategory:
            print(f"\n{'='*50}")
            print(f"Evaluating {category.value.upper()}")
            print(f"{'='*50}")
            
            category_results = await self.evaluate_category(
                category, split, limit_per_dataset
            )
            
            all_results[category.value] = {}
            
            for dataset, results in category_results.items():
                summary = self.summarize(results)
                all_results[category.value][dataset] = summary.to_dict()
                
                print(f"\n{dataset}:")
                print(f"  EM: {summary.avg_exact_match:.3f}")
                print(f"  F1: {summary.avg_f1:.3f}")
                print(f"  CFI: {summary.avg_cfi:.3f}")
                print(f"  Latency: {summary.avg_latency_ms:.1f}ms")
                
                if save:
                    self.save_results(results, f"{dataset}_{split}_results.json")
        
        return all_results
