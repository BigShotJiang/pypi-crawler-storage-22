"""Evaluation Metrics for HELIX

Implements metrics for all evaluation priorities:
- Temporal: Hit@1, Hit@5, Accuracy
- Hallucination: AUC, EG, RP, CFI
- Multi-Hop: F1, EM, Retrieval F1
- Scalability: Tokens, Latency, Cost
"""
from typing import List, Dict, Any, Optional, Tuple
import re
import string
from collections import Counter
import time


def normalize_answer(s: str) -> str:
    """Normalize answer for comparison (lowercase, remove articles/punctuation)."""
    def remove_articles(text):
        return re.sub(r'\b(a|an|the)\b', ' ', text)
    
    def white_space_fix(text):
        return ' '.join(text.split())
    
    def remove_punc(text):
        exclude = set(string.punctuation)
        return ''.join(ch for ch in text if ch not in exclude)
    
    def lower(text):
        return text.lower()
    
    return white_space_fix(remove_articles(remove_punc(lower(s))))


def compute_exact_match(prediction: str, ground_truth: str) -> float:
    """Exact Match (EM) score - 1.0 if normalized strings match, 0.0 otherwise."""
    return float(normalize_answer(prediction) == normalize_answer(ground_truth))


def compute_f1_score(prediction: str, ground_truth: str) -> float:
    """Token-level F1 score between prediction and ground truth."""
    pred_tokens = normalize_answer(prediction).split()
    gt_tokens = normalize_answer(ground_truth).split()
    
    if not pred_tokens or not gt_tokens:
        return float(pred_tokens == gt_tokens)
    
    common = Counter(pred_tokens) & Counter(gt_tokens)
    num_same = sum(common.values())
    
    if num_same == 0:
        return 0.0
    
    precision = num_same / len(pred_tokens)
    recall = num_same / len(gt_tokens)
    f1 = (2 * precision * recall) / (precision + recall)
    
    return f1


def compute_hit_at_k(
    retrieved_items: List[str],
    ground_truth: str,
    k: int = 1
) -> float:
    """Hit@K - 1.0 if ground truth is in top-K retrieved items."""
    gt_normalized = normalize_answer(ground_truth)
    
    for item in retrieved_items[:k]:
        if gt_normalized in normalize_answer(item):
            return 1.0
    
    return 0.0


def compute_retrieval_f1(
    retrieved_facts: List[str],
    supporting_facts: List[str]
) -> float:
    """Compute F1 between retrieved and ground truth supporting facts."""
    if not supporting_facts:
        return 1.0 if not retrieved_facts else 0.0
    
    if not retrieved_facts:
        return 0.0
    
    retrieved_set = set(normalize_answer(f) for f in retrieved_facts)
    gt_set = set(normalize_answer(f) for f in supporting_facts)
    
    intersection = retrieved_set & gt_set
    
    precision = len(intersection) / len(retrieved_set)
    recall = len(intersection) / len(gt_set)
    
    if precision + recall == 0:
        return 0.0
    
    return (2 * precision * recall) / (precision + recall)


def compute_cfi_metrics(
    entity_grounding: float,
    relation_preservation: float,
    temporal_consistency: float,
    weights: Optional[Tuple[float, float, float]] = None
) -> Dict[str, float]:
    """
    Compute Composite Fidelity Index (CFI) and component metrics.
    
    CFI = w1*EG + w2*RP + w3*TC
    
    Args:
        entity_grounding: Entity Grounding score (0-1)
        relation_preservation: Relation Preservation score (0-1)
        temporal_consistency: Temporal Consistency score (0-1)
        weights: Optional (w1, w2, w3) tuple, defaults to (0.4, 0.4, 0.2)
    
    Returns:
        Dictionary with EG, RP, TC, and CFI scores
    """
    if weights is None:
        weights = (0.4, 0.4, 0.2)
    
    w1, w2, w3 = weights
    cfi = w1 * entity_grounding + w2 * relation_preservation + w3 * temporal_consistency
    
    return {
        "entity_grounding": entity_grounding,
        "relation_preservation": relation_preservation,
        "temporal_consistency": temporal_consistency,
        "cfi": cfi
    }


def compute_auc(
    predictions: List[float],
    labels: List[int]
) -> float:
    """Compute Area Under ROC Curve for hallucination detection."""
    if not predictions or not labels:
        return 0.0
    
    # Sort by prediction score descending
    sorted_pairs = sorted(zip(predictions, labels), key=lambda x: -x[0])
    
    tp = 0
    fp = 0
    tps = []
    fps = []
    
    total_pos = sum(labels)
    total_neg = len(labels) - total_pos
    
    if total_pos == 0 or total_neg == 0:
        return 0.5
    
    for pred, label in sorted_pairs:
        if label == 1:
            tp += 1
        else:
            fp += 1
        tps.append(tp / total_pos)
        fps.append(fp / total_neg)
    
    # Trapezoidal AUC
    auc = 0.0
    for i in range(1, len(fps)):
        auc += (fps[i] - fps[i-1]) * (tps[i] + tps[i-1]) / 2
    
    return auc


class LatencyTracker:
    """Track latency for scalability evaluation."""
    
    def __init__(self):
        self.start_time = None
        self.latencies = []
    
    def start(self):
        self.start_time = time.time()
    
    def stop(self) -> float:
        if self.start_time is None:
            return 0.0
        latency = time.time() - self.start_time
        self.latencies.append(latency)
        self.start_time = None
        return latency
    
    def mean_latency(self) -> float:
        return sum(self.latencies) / len(self.latencies) if self.latencies else 0.0
    
    def p95_latency(self) -> float:
        if not self.latencies:
            return 0.0
        sorted_latencies = sorted(self.latencies)
        idx = int(0.95 * len(sorted_latencies))
        return sorted_latencies[min(idx, len(sorted_latencies) - 1)]


class TokenCounter:
    """Track token usage for cost evaluation."""
    
    def __init__(self):
        self.total_tokens = 0
        self.prompt_tokens = 0
        self.completion_tokens = 0
    
    def add(self, prompt: int = 0, completion: int = 0):
        self.prompt_tokens += prompt
        self.completion_tokens += completion
        self.total_tokens += prompt + completion
    
    def estimate_cost(self, prompt_cost_per_1k: float = 0.01, completion_cost_per_1k: float = 0.03) -> float:
        """Estimate cost in USD based on typical Gemini pricing."""
        return (self.prompt_tokens / 1000 * prompt_cost_per_1k + 
                self.completion_tokens / 1000 * completion_cost_per_1k)
