"""HELIX - LightRAG + Graphiti Hybrid Knowledge Graph System

Main entry point for the HELIX system.

Usage:
    # As a module
    python -m helix
    
    # Or run directly
    python helix/main.py
"""
import asyncio
from typing import Optional
from helix.config import config
from helix.pipeline.query import HELIXQueryPipeline


async def create_pipeline(workspace: str = "default") -> HELIXQueryPipeline:
    """
    Create and initialize a HELIX pipeline.
    
    Args:
        workspace: Namespace for the knowledge graph
        
    Returns:
        Initialized HELIXQueryPipeline
    """
    pipeline = HELIXQueryPipeline(workspace=workspace)
    await pipeline.initialize()
    return pipeline


async def demo():
    """Demonstration of HELIX capabilities"""
    print("=" * 60)
    print("HELIX - LightRAG + Graphiti Hybrid System")
    print("=" * 60)
    print()
    
    # Check configuration
    print("Configuration:")
    print(f"  Neo4j URI: {config.neo4j_uri}")
    print(f"  Gemini Model: {config.gemini_model}")
    print(f"  Embedding Model: {config.embedding_model}")
    print(f"  Working Dir: {config.working_dir}")
    print()
    
    # Initialize pipeline
    print("Initializing HELIX pipeline...")
    try:
        pipeline = await create_pipeline()
        print("✓ Pipeline initialized successfully!")
        print()
    except Exception as e:
        print(f"✗ Failed to initialize pipeline: {e}")
        print()
        print("Make sure Neo4j is running and credentials are correct.")
        return
    
    # Test Gemini connection
    print("Testing Gemini API...")
    try:
        from helix.models.gemini_llm import gemini_complete
        response = await gemini_complete("Say 'Hello HELIX!' in one line.", max_tokens=50)
        print(f"✓ Gemini response: {response.strip()}")
        print()
    except Exception as e:
        print(f"✗ Gemini API error: {e}")
        return
    
    # Test embeddings
    print("Testing Gemini Embeddings...")
    try:
        from helix.models.gemini_embeddings import embed_texts
        embeddings = await embed_texts(["test query"])
        print(f"✓ Embedding dimension: {len(embeddings[0])}")
        print()
    except Exception as e:
        print(f"✗ Embedding error: {e}")
        return
    
    # Sample ingestion
    print("Ingesting sample document...")
    sample_text = """
    Alan Turing was born on June 23, 1912 in Maida Vale, London.
    He is widely considered to be the father of theoretical computer science.
    In 1936, Turing published his seminal paper introducing the concept of a 
    Turing machine. During World War II, he worked at Bletchley Park where he 
    played a crucial role in breaking the German Enigma cipher.
    """
    
    try:
        await pipeline.ingest(
            text=sample_text,
            name="turing_biography",
            source="demo",
            reference_time="2024-01-01"
        )
        print("✓ Document ingested successfully!")
        print()
    except Exception as e:
        print(f"✗ Ingestion error: {e}")
    
    # Test query
    print("Testing query pipeline...")
    try:
        result = await pipeline.query(
            "Who is considered the father of computer science?",
            mode="auto",
            verify=True
        )
        
        print(f"✓ Query mode: {result['mode']}")
        print(f"✓ Confidence: {result['confidence']:.2%}")
        print(f"✓ Answer: {result['answer'][:200]}...")
        
        if result.get('verification'):
            v = result['verification']
            print(f"\nVerification:")
            print(f"  Entity Grounding: {v['entity_grounding']:.2%}")
            print(f"  Relation Preservation: {v['relation_preservation']:.2%}")
            print(f"  Hallucination Detected: {v['hallucination_detected']}")
    except Exception as e:
        print(f"✗ Query error: {e}")
    
    # Cleanup
    await pipeline.close()
    print()
    print("=" * 60)
    print("Demo complete!")
    print("=" * 60)


async def main():
    """Main entry point"""
    import sys
    
    if len(sys.argv) > 1:
        command = sys.argv[1]
        
        if command == "demo":
            await demo()
        elif command == "version":
            print("HELIX v0.1.0")
        else:
            print(f"Unknown command: {command}")
            print("Available commands: demo, version")
    else:
        await demo()


if __name__ == "__main__":
    asyncio.run(main())
