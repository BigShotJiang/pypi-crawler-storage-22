"""Gemini Embeddings Integration for HELIX"""
import google.generativeai as genai
from typing import List, Union
import numpy as np
import asyncio
from helix.config import config


# Configure Gemini API
genai.configure(api_key=config.google_api_key)


async def embed_texts(texts: List[str]) -> List[List[float]]:
    """
    Generate embeddings using Gemini text-embedding-005.
    
    This function is compatible with LightRAG's embedding_func interface.
    
    Args:
        texts: List of text strings to embed
        
    Returns:
        List of embedding vectors (768 dimensions each)
    """
    embeddings = []
    
    for text in texts:
        # Handle empty strings
        if not text or not text.strip():
            embeddings.append([0.0] * config.embedding_dim)
            continue
            
        kwargs = {}
        if config.embedding_model == "gemini-embedding-001":
            kwargs["output_dimensionality"] = config.embedding_dim
            
        result = genai.embed_content(
            model=f"models/{config.embedding_model}",
            content=text,
            task_type="retrieval_document",
            **kwargs
        )
        embeddings.append(result['embedding'])
    
    return embeddings


async def embed_query(query: str) -> List[float]:
    """
    Generate query embedding with retrieval_query task type.
    
    Optimized for query-to-document similarity.
    """
    if not query or not query.strip():
        return [0.0] * config.embedding_dim
        
    kwargs = {}
    if config.embedding_model == "gemini-embedding-001":
        kwargs["output_dimensionality"] = config.embedding_dim
        
    result = genai.embed_content(
        model=f"models/{config.embedding_model}",
        content=query,
        task_type="retrieval_query",
        **kwargs
    )
    return result['embedding']


def embed_texts_sync(texts: List[str]) -> List[List[float]]:
    """Synchronous wrapper for embed_texts"""
    return asyncio.run(embed_texts(texts))


class GeminiEmbeddingFunc:
    """
    Embedding function wrapper compatible with LightRAG.
    
    Usage:
        embedding_func = GeminiEmbeddingFunc()
        embeddings = await embedding_func(["text1", "text2"])
    """
    
    def __init__(self):
        self.embedding_dim = config.embedding_dim  # 768
        self.max_token_size = config.max_tokens_per_query
        self._model_name = config.embedding_model
    
    async def __call__(self, texts: Union[str, List[str]]) -> np.ndarray:
        """Generate embeddings for a list of texts"""
        if isinstance(texts, str):
            texts = [texts]
        
        embeddings = await embed_texts(texts)
        return np.array(embeddings, dtype=np.float32)
    
    def __repr__(self):
        return f"GeminiEmbeddingFunc(model={self._model_name}, dim={self.embedding_dim})"


# LightRAG-compatible embedding function
async def lightrag_embedding_func(texts: List[str]) -> np.ndarray:
    """
    LightRAG-compatible embedding function.
    
    Returns numpy array of shape (num_texts, embedding_dim).
    """
    embeddings = await embed_texts(texts)
    return np.array(embeddings, dtype=np.float32)
