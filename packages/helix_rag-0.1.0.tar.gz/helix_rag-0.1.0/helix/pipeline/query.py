"""HELIX Query Pipeline
    
Main query pipeline combining temporal processing, multi-hop retrieval,
and hallucination detection.
"""
from typing import Dict, Any, Optional, List, Union
from helix.config import config
from helix.storage.graphiti_storage import GraphitiStorage
from helix.temporal.query_handler import TemporalQueryHandler
from helix.temporal.incremental_updater import IncrementalUpdater, KnowledgeUpdate
from helix.verification.hallucination_detector import HallucinationDetector
from helix.retrieval.multi_hop_retriever import MultiHopRetriever


class HELIXQueryPipeline:
    """
    Complete HELIX query pipeline.
    
    Combines:
    - Temporal query handling
    - Multi-hop retrieval
    - Hallucination detection
    - Answer generation
    
    Usage:
        pipeline = HELIXQueryPipeline()
        await pipeline.initialize()
        result = await pipeline.query("What is the capital of France?")
    """
    
    def __init__(self, workspace: str = "default"):
        """
        Initialize HELIX pipeline.
        
        Args:
            workspace: Namespace for the knowledge graph
        """
        self.workspace = workspace
        self.storage = GraphitiStorage(namespace=workspace)
        
        # Initialize components
        self.temporal_handler = TemporalQueryHandler(self.storage)
        self.hallucination_detector = HallucinationDetector(self.storage)
        self.multi_hop_retriever = MultiHopRetriever(self.storage)
        self.updater = IncrementalUpdater(self.storage)
        
        self._initialized = False
    
    async def initialize(self):
        """Initialize storage connection"""
        if not self._initialized:
            await self.storage.initialize()
            self._initialized = True
    
    async def query(
        self,
        query_text: str,
        mode: str = "auto",
        verify: bool = True,
        query_time: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Process query through HELIX pipeline.
        
        Args:
            query_text: User question
            mode: Query mode (auto, temporal, multi_hop, simple)
            verify: Whether to run hallucination detection
            query_time: Point-in-time for temporal queries
            
        Returns:
            Dictionary with answer, mode, verification, context, confidence
        """
        await self.initialize()
        
        # Step 1: Classify query type
        if mode == "auto":
            mode = await self._classify_query(query_text)
        
        # Step 2: Route to appropriate handler
        if mode == "temporal":
            result = await self.temporal_handler.query(query_text, query_time)
            context = result.get("context", [])
            answer = result.get("answer", "")
            
        elif mode == "multi_hop":
            result = await self.multi_hop_retriever.answer_multi_hop(query_text)
            context = result.get("paths", [])
            answer = result.get("answer", "")
            
        else:
            # Simple retrieval + generation
            context = await self.storage.search(query_text, num_results=10)
            answer = await self._generate_answer(query_text, context)
        
        # Step 3: Hallucination verification
        verification = None
        if verify and answer:
            # Convert context to list format if needed
            ctx_list = context if isinstance(context, list) else []
            
            verification = await self.hallucination_detector.verify_answer(
                query_text,
                answer,
                ctx_list
            )
            
            # Regenerate if hallucination detected
            if verification.get("hallucination_detected"):
                answer = await self.hallucination_detector.regenerate_with_grounding(
                    query_text,
                    ctx_list,
                    verification
                )
                verification["regenerated"] = True
        
        return {
            "answer": answer,
            "mode": mode,
            "verification": verification,
            "context": context,
            "confidence": verification.get("confidence", 1.0) if verification else 1.0
        }
    
    async def ingest(
        self,
        text: str,
        name: str,
        source: str = "document",
        reference_time: Optional[str] = None,
        use_incremental: bool = True
    ):
        """
        Ingest a document/episode into the knowledge graph.
        
        Args:
            text: Document content
            name: Unique name/ID for the document
            source: Source description
            reference_time: Optional temporal reference (ISO format)
            use_incremental: Whether to use IncrementalUpdater for bi-temporal support
        """
        await self.initialize()
        
        if use_incremental and reference_time:
            # Use IncrementalUpdater for temporal facts
            # 1. Extract facts (using standard storage logic first or LLM)
            # For now, we reuse storage.add_episode but we might want to 
            # parse specific temporal facts here.
            
            # Ideally, we should decompose the text into facts and add them via updater.
            # But GraphitiStorage handles extraction internally.
            # So we let Graphiti do the heavy lifting, then we might want to tag them.
            
            # Strategy: Add episode normally, then post-process for bi-temporal tags if needed?
            # Or better: Implementing 'add_fact' on updater and use manual extraction.
            
            # For HELIX Phase 2: We want to support Delta Updates described in plan.
            # If text is small facts:
            if len(text.split()) < 50:
                 update = KnowledgeUpdate(
                     entity_id=name,
                     entity_name=text.split()[0], # Naive
                     fact=text,
                     valid_from=reference_time,
                     source=source
                 )
                 self.updater.add_update(update)
                 await self.updater.apply_updates()
                 return

        # Default ingestion
        await self.storage.add_episode(
            name=name,
            episode_body=text,
            source_description=source,
            reference_time=reference_time
        )
            
    async def _classify_query(self, query_text: str) -> str:
        """Classify query to determine processing mode"""
        try:
            from helix.models.gemini_llm import gemini_complete_json
            import json
            
            prompt = f"""Classify this query into one of these types:
- "temporal": Asks about past states, changes over time, historical facts
- "multi_hop": Requires connecting multiple pieces of information
- "simple": General factual question

Query: {query_text}

Return JSON: {{"type": "..."}}"""
            
            response = await gemini_complete_json(prompt)
            result = json.loads(response)
            return result.get("type", "simple")
        except Exception:
            return "simple"
    
    async def _generate_answer(
        self, 
        query: str, 
        context: List[Dict[str, Any]]
    ) -> str:
        """Generate answer from context"""
        from helix.models.gemini_llm import gemini_complete
        
        # Build context string
        context_parts = []
        for item in context[:10]:
            name = item.get("name", "")
            fact = item.get("fact") or item.get("summary", "")
            if fact:
                context_parts.append(f"- {name}: {fact}")
        
        context_str = "\n".join(context_parts) if context_parts else "No context available."
        
        prompt = f"""Based on the following context, answer the question.

Context:
{context_str}

Question: {query}

Answer:"""
        
        return await gemini_complete(prompt)
    
    async def close(self):
        """Close storage connection"""
        await self.storage.close()
        self._initialized = False
