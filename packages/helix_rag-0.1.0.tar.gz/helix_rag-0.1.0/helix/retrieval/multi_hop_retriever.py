"""Multi-Hop Retriever for HELIX

Implements multi-hop reasoning through graph traversal with BFS and path ranking.
"""
from typing import List, Dict, Any, Optional
from collections import deque
import numpy as np
from helix.config import config


class MultiHopRetriever:
    """
    Multi-hop retrieval with BFS-based path exploration.
    
    Process:
    1. Find seed nodes from query
    2. BFS expansion to max_hops
    3. Extract candidate paths
    4. Rank paths by relevance
    5. Return top-K paths
    
    Usage:
        retriever = MultiHopRetriever(storage)
        paths = await retriever.retrieve_multi_hop("How are A and B connected?")
        context = retriever.get_path_context(paths)
    """
    
    def __init__(self, storage):
        """
        Initialize with a GraphitiStorage instance.
        
        Args:
            storage: GraphitiStorage or compatible storage backend
        """
        self.storage = storage
        self.max_hops = config.max_hops
        self.top_k = config.top_k_entities
    
    async def retrieve_multi_hop(
        self,
        query: str,
        max_hops: Optional[int] = None,
        top_k_paths: int = 5
    ) -> List[Dict[str, Any]]:
        """
        Retrieve relevant subgraphs for multi-hop reasoning.
        
        Args:
            query: Search query
            max_hops: Maximum traversal depth
            top_k_paths: Number of paths to return
            
        Returns:
            List of ranked paths with nodes and edges
        """
        max_hops = max_hops or self.max_hops
        
        # Step 1: Get query embedding for ranking
        from helix.models.gemini_embeddings import embed_query
        query_embedding = await embed_query(query)
        
        # Step 2: Find seed nodes
        seed_results = await self.storage.search(query=query, num_results=10)
        seed_nodes = [
            r.get("name", str(r)) for r in seed_results if r.get("name")
        ]
        
        if not seed_nodes:
            return []
        
        # Step 3: BFS from seeds
        candidate_paths = await self._bfs_multi_hop(
            seed_nodes,
            max_hops=max_hops,
            max_paths=50
        )
        
        # Step 4: Rank paths by relevance
        scored_paths = await self._rank_paths(candidate_paths, query_embedding)
        
        return scored_paths[:top_k_paths]
    
    async def _bfs_multi_hop(
        self,
        seed_nodes: List[str],
        max_hops: int,
        max_paths: int
    ) -> List[Dict[str, Any]]:
        """Breadth-first search from seed nodes"""
        queue = deque()
        for seed in seed_nodes[:5]:  # Limit seeds
            queue.append({
                "nodes": [seed],
                "edges": [],
                "depth": 0
            })
        
        candidate_paths = []
        visited = set()
        
        while queue and len(candidate_paths) < max_paths:
            current_path = queue.popleft()
            
            if current_path["depth"] >= max_hops:
                candidate_paths.append(current_path)
                continue
            
            current_node = current_path["nodes"][-1]
            neighbors = await self._get_neighbors(current_node)
            
            for neighbor, edge_info in neighbors[:10]:  # Limit neighbors
                if neighbor in current_path["nodes"]:
                    continue  # Avoid cycles
                
                new_path = {
                    "nodes": current_path["nodes"] + [neighbor],
                    "edges": current_path["edges"] + [edge_info],
                    "depth": current_path["depth"] + 1
                }
                
                path_key = tuple(new_path["nodes"])
                if path_key not in visited:
                    visited.add(path_key)
                    queue.append(new_path)
                    
                    # Also add current path as candidate
                    if current_path["depth"] > 0:
                        candidate_paths.append(current_path)
        
        # Add remaining items in queue
        while queue and len(candidate_paths) < max_paths:
            candidate_paths.append(queue.popleft())
        
        return candidate_paths
    
    async def _get_neighbors(self, node: str) -> List[tuple]:
        """Get neighboring nodes from storage"""
        try:
            await self.storage.initialize()
            
            # Query Neo4j for neighbors
            cypher = """
            MATCH (n)-[r]-(neighbor)
            WHERE n.name = $node
            RETURN neighbor.name AS neighbor, 
                   type(r) AS relation,
                   r.fact AS fact
            LIMIT 20
            """
            
            async with self.storage.graphiti.driver.session() as session:
                result = await session.run(cypher, node=node)
                records = await result.data()
                
                return [
                    (r["neighbor"], {
                        "relation": r.get("relation", "related_to"),
                        "fact": r.get("fact", "")
                    })
                    for r in records
                    if r.get("neighbor")
                ]
        except Exception:
            # Fallback: search for related entities
            results = await self.storage.search(query=node, num_results=5)
            return [
                (r.get("name", ""), {"relation": "related", "fact": r.get("fact", "")})
                for r in results
            ]
    
    async def _rank_paths(
        self,
        paths: List[Dict[str, Any]],
        query_embedding: List[float]
    ) -> List[Dict[str, Any]]:
        """Rank paths by semantic similarity to query"""
        if not paths:
            return []
        
        from helix.models.gemini_embeddings import embed_texts
        
        scored_paths = []
        query_vec = np.array(query_embedding)
        
        for path in paths:
            # Create path description
            path_desc = " ".join(path["nodes"])
            for edge in path["edges"]:
                if edge.get("fact"):
                    path_desc += " " + edge["fact"]
            
            # Embed path
            try:
                path_embeddings = await embed_texts([path_desc])
                path_vec = np.array(path_embeddings[0])
                
                # Cosine similarity
                similarity = np.dot(query_vec, path_vec) / (
                    np.linalg.norm(query_vec) * np.linalg.norm(path_vec) + 1e-8
                )
                
                path["score"] = float(similarity)
            except Exception:
                path["score"] = 0.0
            
            scored_paths.append(path)
        
        scored_paths.sort(key=lambda x: x["score"], reverse=True)
        return scored_paths
    
    def get_path_context(self, paths: List[Dict[str, Any]]) -> str:
        """Convert paths to context string for LLM"""
        if not paths:
            return "No relevant paths found."
        
        parts = []
        
        for i, path in enumerate(paths[:5], 1):
            path_str = " → ".join(path["nodes"])
            facts = [
                e.get("fact") or e.get("relation", "") 
                for e in path.get("edges", []) if e
            ]
            
            parts.append(f"Path {i}: {path_str}")
            if facts:
                parts.append(f"  Facts: {'; '.join(f for f in facts if f)}")
        
        return "\n".join(parts)
    
    async def answer_multi_hop(
        self,
        query: str,
        max_hops: int = 3
    ) -> Dict[str, Any]:
        """
        Complete multi-hop QA pipeline.
        
        Retrieves paths and generates answer.
        """
        from helix.models.gemini_llm import gemini_complete
        
        # Retrieve paths
        paths = await self.retrieve_multi_hop(query, max_hops=max_hops)
        context = self.get_path_context(paths)
        
        # Generate answer
        prompt = f"""Based on the following reasoning paths, answer the question.

{context}

Question: {query}

Answer:"""
        
        answer = await gemini_complete(prompt)
        
        return {
            "answer": answer,
            "paths": paths,
            "context": context
        }
