"""Path Ranker for HELIX Multi-Hop Retrieval

Ranks candidate reasoning paths by relevance to the query.
Uses embedding-based similarity with optional structural features.
"""
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
import numpy as np
from helix.config import config


@dataclass
class ScoredPath:
    """A reasoning path with relevance scores."""
    nodes: List[str]
    edges: List[Dict[str, Any]]
    
    # Scores
    semantic_score: float = 0.0    # Embedding similarity
    structural_score: float = 0.0  # Graph structure features
    hop_penalty: float = 0.0       # Penalty for path length
    combined_score: float = 0.0
    
    # Metadata
    depth: int = 0
    
    def __post_init__(self):
        self.depth = len(self.nodes) - 1 if self.nodes else 0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "nodes": self.nodes,
            "edges": self.edges,
            "semantic_score": self.semantic_score,
            "structural_score": self.structural_score,
            "hop_penalty": self.hop_penalty,
            "combined_score": self.combined_score,
            "depth": self.depth
        }


class PathRanker:
    """
    Rank reasoning paths by relevance.
    
    Scoring formula:
        score = α * semantic + β * structural - γ * hop_penalty
    
    Features:
    - Embedding-based semantic similarity
    - Structural features (node degree, path coherence)
    - Hop penalty for longer paths
    
    Usage:
        ranker = PathRanker()
        scored = await ranker.rank_paths(paths, query, query_embedding)
        top_paths = ranker.get_top_k(scored, k=5)
    """
    
    def __init__(
        self,
        semantic_weight: float = 0.6,
        structural_weight: float = 0.2,
        hop_penalty_weight: float = 0.2,
        max_hops: int = 3
    ):
        """
        Initialize path ranker.
        
        Args:
            semantic_weight: Weight for semantic similarity (α)
            structural_weight: Weight for structural features (β)
            hop_penalty_weight: Weight for hop penalty (γ)
            max_hops: Maximum hops for normalization
        """
        self.alpha = semantic_weight
        self.beta = structural_weight
        self.gamma = hop_penalty_weight
        self.max_hops = max_hops
    
    async def rank_paths(
        self,
        paths: List[Dict[str, Any]],
        query: str,
        query_embedding: Optional[List[float]] = None
    ) -> List[ScoredPath]:
        """
        Rank paths by relevance to query.
        
        Args:
            paths: List of path dictionaries with nodes and edges
            query: Original query string
            query_embedding: Pre-computed query embedding (optional)
            
        Returns:
            List of ScoredPath objects, sorted by combined_score
        """
        if not paths:
            return []
        
        # Get query embedding if not provided
        if query_embedding is None:
            from helix.models.gemini_embeddings import embed_query
            query_embedding = await embed_query(query)
        
        query_vec = np.array(query_embedding)
        
        scored_paths = []
        
        for path in paths:
            # Create ScoredPath
            sp = ScoredPath(
                nodes=path.get("nodes", []),
                edges=path.get("edges", [])
            )
            
            # Compute semantic score
            sp.semantic_score = await self._compute_semantic_score(sp, query_vec)
            
            # Compute structural score
            sp.structural_score = self._compute_structural_score(sp)
            
            # Compute hop penalty
            sp.hop_penalty = self._compute_hop_penalty(sp.depth)
            
            # Combined score
            sp.combined_score = (
                self.alpha * sp.semantic_score +
                self.beta * sp.structural_score -
                self.gamma * sp.hop_penalty
            )
            
            scored_paths.append(sp)
        
        # Sort by combined score
        scored_paths.sort(key=lambda x: x.combined_score, reverse=True)
        
        return scored_paths
    
    async def _compute_semantic_score(
        self,
        path: ScoredPath,
        query_vec: np.ndarray
    ) -> float:
        """Compute semantic similarity between path and query."""
        # Build path description
        path_text = " ".join(path.nodes)
        for edge in path.edges:
            fact = edge.get("fact", "")
            if fact:
                path_text += " " + fact
        
        if not path_text.strip():
            return 0.0
        
        try:
            from helix.models.gemini_embeddings import embed_texts
            
            path_embeddings = await embed_texts([path_text])
            if not path_embeddings:
                return 0.0
            
            path_vec = np.array(path_embeddings[0])
            
            # Cosine similarity
            similarity = self._cosine_similarity(query_vec, path_vec)
            return max(0.0, similarity)
            
        except Exception:
            return 0.0
    
    def _compute_structural_score(self, path: ScoredPath) -> float:
        """
        Compute structural score based on path features.
        
        Features:
        - Edge density (facts per hop)
        - Path coherence (how well connected)
        """
        if not path.nodes:
            return 0.0
        
        # Edge density: ratio of edges with facts
        if path.edges:
            facts_count = sum(1 for e in path.edges if e.get("fact"))
            edge_density = facts_count / len(path.edges)
        else:
            edge_density = 0.0
        
        # Path coherence: unique nodes / total nodes (higher = less redundancy)
        unique_nodes = len(set(path.nodes))
        coherence = unique_nodes / len(path.nodes)
        
        # Combine features
        return 0.5 * edge_density + 0.5 * coherence
    
    def _compute_hop_penalty(self, depth: int) -> float:
        """
        Compute penalty for path length.
        
        Longer paths get higher penalty (normalized to [0, 1]).
        """
        if depth <= 1:
            return 0.0
        
        # Linear penalty
        return min(1.0, (depth - 1) / self.max_hops)
    
    def _cosine_similarity(self, a: np.ndarray, b: np.ndarray) -> float:
        """Compute cosine similarity between two vectors."""
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)
        
        if norm_a == 0 or norm_b == 0:
            return 0.0
        
        return float(np.dot(a, b) / (norm_a * norm_b))
    
    def get_top_k(self, scored_paths: List[ScoredPath], k: int = 5) -> List[ScoredPath]:
        """Get top-K paths."""
        return scored_paths[:k]
    
    def filter_by_score(
        self, 
        scored_paths: List[ScoredPath], 
        threshold: float = 0.5
    ) -> List[ScoredPath]:
        """Filter paths by minimum score threshold."""
        return [p for p in scored_paths if p.combined_score >= threshold]
    
    def diversify(
        self,
        scored_paths: List[ScoredPath],
        k: int = 5,
        similarity_threshold: float = 0.8
    ) -> List[ScoredPath]:
        """
        Select diverse top-K paths using MMR-like approach.
        
        Avoids selecting paths that are too similar to each other.
        """
        if not scored_paths or k <= 0:
            return []
        
        selected = [scored_paths[0]]
        remaining = scored_paths[1:]
        
        while len(selected) < k and remaining:
            # Find path most different from selected
            best_idx = -1
            best_score = -float('inf')
            
            for i, path in enumerate(remaining):
                # Compute max similarity to already selected
                max_sim = 0.0
                for sel_path in selected:
                    sim = self._path_similarity(path, sel_path)
                    max_sim = max(max_sim, sim)
                
                # MMR: relevance - λ * max_similarity
                mmr_score = path.combined_score - 0.5 * max_sim
                
                if mmr_score > best_score:
                    best_score = mmr_score
                    best_idx = i
            
            if best_idx >= 0:
                selected.append(remaining.pop(best_idx))
            else:
                break
        
        return selected
    
    def _path_similarity(self, p1: ScoredPath, p2: ScoredPath) -> float:
        """Compute similarity between two paths based on node overlap."""
        nodes1 = set(p1.nodes)
        nodes2 = set(p2.nodes)
        
        if not nodes1 or not nodes2:
            return 0.0
        
        intersection = len(nodes1 & nodes2)
        union = len(nodes1 | nodes2)
        
        return intersection / union if union > 0 else 0.0
