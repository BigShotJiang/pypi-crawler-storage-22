"""Subgraph Pruner for HELIX Multi-Hop Retrieval

Prunes irrelevant nodes and edges from retrieved subgraphs
to improve signal-to-noise ratio.
"""
from typing import List, Dict, Any, Optional, Set
from dataclasses import dataclass
from helix.config import config


@dataclass
class PruningResult:
    """Result of subgraph pruning."""
    nodes: List[str]
    edges: List[Dict[str, Any]]
    removed_nodes: List[str]
    removed_edges: List[Dict[str, Any]]
    
    # Statistics
    original_node_count: int = 0
    original_edge_count: int = 0
    pruned_node_count: int = 0
    pruned_edge_count: int = 0
    
    @property
    def node_reduction(self) -> float:
        if self.original_node_count == 0:
            return 0.0
        return 1.0 - (self.pruned_node_count / self.original_node_count)
    
    @property
    def edge_reduction(self) -> float:
        if self.original_edge_count == 0:
            return 0.0
        return 1.0 - (self.pruned_edge_count / self.original_edge_count)


class SubgraphPruner:
    """
    Prune irrelevant nodes and edges from subgraphs.
    
    Strategies:
    1. Relevance-based: Remove nodes below relevance threshold
    2. Degree-based: Remove leaf nodes with low relevance
    3. Distance-based: Remove nodes too far from query entities
    4. Redundancy-based: Remove duplicate information
    
    Usage:
        pruner = SubgraphPruner(min_relevance=0.3)
        result = await pruner.prune(nodes, edges, query_entities)
    """
    
    def __init__(
        self,
        min_relevance: float = 0.3,
        max_distance: int = 3,
        remove_orphans: bool = True,
        remove_duplicates: bool = True
    ):
        """
        Initialize pruner.
        
        Args:
            min_relevance: Minimum relevance score to keep (0-1)
            max_distance: Maximum hops from query entities
            remove_orphans: Remove disconnected nodes
            remove_duplicates: Remove redundant edges
        """
        self.min_relevance = min_relevance
        self.max_distance = max_distance
        self.remove_orphans = remove_orphans
        self.remove_duplicates = remove_duplicates
    
    async def prune(
        self,
        nodes: List[Dict[str, Any]],
        edges: List[Dict[str, Any]],
        query: str,
        query_entities: Optional[List[str]] = None
    ) -> PruningResult:
        """
        Prune subgraph.
        
        Args:
            nodes: List of node dictionaries
            edges: List of edge dictionaries
            query: Query string for relevance scoring
            query_entities: Key entities from query (optional)
            
        Returns:
            PruningResult with pruned graph and statistics
        """
        original_nodes = len(nodes)
        original_edges = len(edges)
        
        # Step 1: Compute relevance scores
        node_scores = await self._compute_relevance(nodes, query)
        
        # Step 2: Identify query-related nodes
        if query_entities:
            query_related = set(e.lower() for e in query_entities)
        else:
            query_related = await self._extract_query_entities(query)
        
        # Step 3: Apply pruning strategies
        kept_nodes = []
        removed_nodes = []
        
        for node in nodes:
            node_name = node.get("name", "").lower()
            score = node_scores.get(node_name, 0.0)
            
            # Keep if high relevance or query-related
            if score >= self.min_relevance or node_name in query_related:
                kept_nodes.append(node)
            else:
                removed_nodes.append(node)
        
        # Step 4: Prune edges
        kept_node_names = {n.get("name", "").lower() for n in kept_nodes}
        kept_edges = []
        removed_edges = []
        
        for edge in edges:
            source = edge.get("source", "").lower()
            target = edge.get("target", "").lower()
            
            if source in kept_node_names and target in kept_node_names:
                kept_edges.append(edge)
            else:
                removed_edges.append(edge)
        
        # Step 5: Remove orphan nodes if enabled
        if self.remove_orphans:
            connected_nodes = set()
            for edge in kept_edges:
                connected_nodes.add(edge.get("source", "").lower())
                connected_nodes.add(edge.get("target", "").lower())
            
            # Also keep query-related even if orphaned
            connected_nodes.update(query_related)
            
            final_nodes = []
            for node in kept_nodes:
                if node.get("name", "").lower() in connected_nodes:
                    final_nodes.append(node)
                else:
                    removed_nodes.append(node)
            
            kept_nodes = final_nodes
        
        # Step 6: Remove duplicate edges if enabled
        if self.remove_duplicates:
            kept_edges = self._deduplicate_edges(kept_edges)
        
        return PruningResult(
            nodes=[n.get("name", "") for n in kept_nodes],
            edges=kept_edges,
            removed_nodes=[n.get("name", "") for n in removed_nodes],
            removed_edges=removed_edges,
            original_node_count=original_nodes,
            original_edge_count=original_edges,
            pruned_node_count=len(kept_nodes),
            pruned_edge_count=len(kept_edges)
        )
    
    async def _compute_relevance(
        self,
        nodes: List[Dict[str, Any]],
        query: str
    ) -> Dict[str, float]:
        """Compute relevance scores for nodes."""
        if not nodes:
            return {}
        
        try:
            from helix.models.gemini_embeddings import embed_texts, embed_query
            
            # Get query embedding
            query_emb = await embed_query(query)
            query_vec = __import__('numpy').array(query_emb)
            
            # Get node descriptions
            node_texts = []
            for node in nodes:
                text = node.get("name", "")
                fact = node.get("fact") or node.get("summary", "")
                if fact:
                    text += " " + fact
                node_texts.append(text if text else "unknown")
            
            # Embed nodes
            node_embs = await embed_texts(node_texts)
            
            # Compute similarities
            scores = {}
            for i, node in enumerate(nodes):
                name = node.get("name", "").lower()
                if i < len(node_embs):
                    node_vec = __import__('numpy').array(node_embs[i])
                    similarity = self._cosine_similarity(query_vec, node_vec)
                    scores[name] = max(0.0, similarity)
                else:
                    scores[name] = 0.0
            
            return scores
            
        except Exception:
            # Fallback: keyword matching
            return self._keyword_relevance(nodes, query)
    
    def _keyword_relevance(
        self,
        nodes: List[Dict[str, Any]],
        query: str
    ) -> Dict[str, float]:
        """Simple keyword-based relevance."""
        query_words = set(query.lower().split())
        scores = {}
        
        for node in nodes:
            name = node.get("name", "").lower()
            text = name + " " + (node.get("fact") or "")
            text_words = set(text.lower().split())
            
            overlap = len(query_words & text_words)
            total = len(query_words)
            
            scores[name] = overlap / total if total > 0 else 0.0
        
        return scores
    
    async def _extract_query_entities(self, query: str) -> Set[str]:
        """Extract key entities from query."""
        try:
            from helix.models.gemini_llm import gemini_complete_json
            import json
            
            prompt = f"""Extract key entities (nouns, proper nouns) from this query:
Query: {query}

Return JSON: {{"entities": ["entity1", "entity2"]}}"""
            
            response = await gemini_complete_json(prompt)
            data = json.loads(response)
            return set(e.lower() for e in data.get("entities", []))
            
        except Exception:
            # Simple extraction
            import re
            words = re.findall(r'\b[A-Z][a-z]+\b', query)
            return set(w.lower() for w in words)
    
    def _cosine_similarity(self, a, b) -> float:
        """Compute cosine similarity."""
        np = __import__('numpy')
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)
        
        if norm_a == 0 or norm_b == 0:
            return 0.0
        
        return float(np.dot(a, b) / (norm_a * norm_b))
    
    def _deduplicate_edges(self, edges: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Remove duplicate edges."""
        seen = set()
        unique = []
        
        for edge in edges:
            source = edge.get("source", "")
            target = edge.get("target", "")
            relation = edge.get("relation", "")
            
            key = (source.lower(), relation.lower(), target.lower())
            
            if key not in seen:
                seen.add(key)
                unique.append(edge)
        
        return unique
    
    def prune_paths(
        self,
        paths: List[Dict[str, Any]],
        max_paths: int = 10,
        min_score: float = 0.0
    ) -> List[Dict[str, Any]]:
        """
        Prune paths based on score and diversity.
        
        Args:
            paths: List of path dictionaries with scores
            max_paths: Maximum paths to return
            min_score: Minimum score threshold
            
        Returns:
            Pruned list of paths
        """
        # Filter by score
        filtered = [p for p in paths if p.get("score", 0) >= min_score]
        
        # Sort by score
        filtered.sort(key=lambda x: x.get("score", 0), reverse=True)
        
        # Take top-K
        return filtered[:max_paths]
