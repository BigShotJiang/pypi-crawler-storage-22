"""Graphiti Storage Adapter for LightRAG

This module provides a custom storage adapter that connects LightRAG's
retrieval system with Graphiti's temporal knowledge graph capabilities.
"""
from typing import Optional, Dict, Any, List, Union
from datetime import datetime
import asyncio
from helix.config import config


class GraphitiStorage:
    """
    Custom storage adapter that integrates Graphiti's temporal
    knowledge graph with LightRAG's retrieval system.
    
    Key Features:
    - Bi-temporal tracking (event time + ingestion time)
    - Automatic entity deduplication
    - Edge invalidation for conflict resolution
    - Seamless integration with Neo4j via Graphiti
    
    Usage:
        storage = GraphitiStorage(namespace="my_project")
        await storage.initialize()
        await storage.upsert_node("entity_1", {...})
    """
    
    def __init__(
        self, 
        namespace: str = "default",
        workspace: Optional[str] = None,
        **kwargs
    ):
        self.namespace = namespace
        self.workspace = workspace or namespace
        self.group_id = self.workspace
        self._graphiti = None
        self._initialized = False
        
    async def initialize(self):
        """Initialize Graphiti connection and indices"""
        if self._initialized:
            return
            
        try:
            from graphiti_core import Graphiti
            from graphiti_core.llm_client import LLMClient
            from graphiti_core.embedder import EmbedderClient
            
            # Create Graphiti instance with Neo4j
            self._graphiti = Graphiti(
                uri=config.neo4j_uri,
                user=config.neo4j_user,
                password=config.neo4j_password,
            )
            
            # Build indices and constraints
            await self._graphiti.build_indices_and_constraints()
            self._initialized = True
            
        except ImportError as e:
            raise ImportError(
                "graphiti-core is required. Install with: pip install graphiti-core>=0.26.3"
            ) from e
        except Exception as e:
            raise ConnectionError(f"Failed to connect to Neo4j: {e}") from e
    
    @property
    def graphiti(self):
        """Get Graphiti instance (lazy initialization)"""
        if not self._initialized:
            raise RuntimeError("GraphitiStorage not initialized. Call await storage.initialize() first.")
        return self._graphiti
    
    async def upsert_node(self, node_id: str, node_data: Dict[str, Any]):
        """
        Add or update an entity node in Graphiti.
        
        Graphiti automatically:
        - Extracts temporal information
        - Deduplicates entities
        - Tracks creation/modification times
        
        Args:
            node_id: Unique identifier for the node
            node_data: Dictionary containing:
                - entity_name: Name of the entity
                - entity_type: Type/category of entity
                - description: Description text
                - source_id: Source document ID
                - valid_time: Optional temporal validity
        """
        await self.initialize()
        
        entity_name = node_data.get('entity_name', node_id)
        entity_type = node_data.get('entity_type', 'Entity')
        description = node_data.get('description', '')
        source_id = node_data.get('source_id', 'unknown')
        valid_time = node_data.get('valid_time', None)
        
        # Use Graphiti's episodic ingestion
        await self.graphiti.add_episode(
            name=f"entity_{entity_name}",
            episode_body=f"{entity_name} ({entity_type}): {description}",
            source_description=source_id,
            group_id=self.group_id,
            reference_time=valid_time or datetime.now()
        )
    
    async def upsert_edge(
        self, 
        src_id: str, 
        tgt_id: str, 
        edge_data: Dict[str, Any]
    ):
        """
        Add or update a relationship edge in Graphiti.
        
        Graphiti automatically:
        - Sets t_valid based on extracted temporal info
        - Invalidates contradicting edges
        - Maintains full edge history
        
        Args:
            src_id: Source node ID
            tgt_id: Target node ID
            edge_data: Dictionary containing:
                - description: Relationship description
                - source_id: Source document ID
                - valid_time: Optional temporal validity
        """
        await self.initialize()
        
        description = edge_data.get('description', 'relates to')
        source_description = edge_data.get('source_id', 'relation_extraction')
        valid_time = edge_data.get('valid_time', None)
        
        episode_text = f"{src_id} {description} {tgt_id}"
        
        await self.graphiti.add_episode(
            name=f"relation_{src_id}_{tgt_id}",
            episode_body=episode_text,
            source_description=source_description,
            group_id=self.group_id,
            reference_time=valid_time or datetime.now()
        )
    
    async def has_node(self, node_id: str) -> bool:
        """Check if a node exists in the knowledge graph"""
        await self.initialize()
        
        results = await self.graphiti.search(
            query=node_id,
            group_ids=[self.group_id],
            num_results=1
        )
        return len(results) > 0
    
    async def has_edge(self, src_id: str, tgt_id: str) -> bool:
        """Check if an edge exists between two nodes"""
        await self.initialize()
        
        cypher = """
        MATCH (a)-[r]-(b)
        WHERE a.name = $src AND b.name = $tgt
        RETURN r LIMIT 1
        """
        async with self.graphiti.driver.session() as session:
            result = await session.run(cypher, src=src_id, tgt=tgt_id)
            records = await result.data()
            return len(records) > 0
    
    async def get_node(self, node_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve a node by ID"""
        await self.initialize()
        
        results = await self.graphiti.search(
            query=node_id,
            group_ids=[self.group_id],
            num_results=1
        )
        if results:
            node = results[0]
            return {
                "entity_name": getattr(node, 'name', node_id),
                "entity_type": getattr(node, 'labels', ['Entity'])[0] if hasattr(node, 'labels') else 'Entity',
                "description": getattr(node, 'summary', ''),
            }
        return None
    
    async def search(
        self, 
        query: str, 
        num_results: int = 10,
        valid_at: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Search the knowledge graph.
        
        Args:
            query: Search query
            num_results: Maximum results to return
            valid_at: Optional point-in-time filter (ISO format)
            
        Returns:
            List of matching results
        """
        await self.initialize()
        
        results = await self.graphiti.search(
            query=query,
            group_ids=[self.group_id],
            num_results=num_results,
        )
        
        return self._convert_to_dict(results)
    
    async def add_episode(
        self,
        name: str,
        episode_body: str,
        source_description: str = "document",
        reference_time: Optional[Union[str, datetime]] = None
    ):
        """
        Add an episode (document/fact) to Graphiti.
        
        This is the primary method for ingesting content.
        Graphiti automatically extracts entities and relationships.
        """
        await self.initialize()
        
        if isinstance(reference_time, str):
            reference_time = datetime.fromisoformat(reference_time)
        
        await self.graphiti.add_episode(
            name=name,
            episode_body=episode_body,
            source_description=source_description,
            group_id=self.group_id,
            reference_time=reference_time or datetime.now()
        )
    
    def _convert_to_dict(self, results: List[Any]) -> List[Dict[str, Any]]:
        """Convert Graphiti results to dictionary format"""
        converted = []
        for result in results:
            item = {
                "name": getattr(result, 'name', str(result)),
                "type": getattr(result, 'labels', ['Entity'])[0] if hasattr(result, 'labels') else 'Entity',
                "summary": getattr(result, 'summary', ''),
                "fact": getattr(result, 'fact', ''),
                "created_at": str(getattr(result, 'created_at', '')),
                "valid_at": str(getattr(result, 'valid_at', '')),
            }
            converted.append(item)
        return converted
    
    async def close(self):
        """Close the Graphiti connection"""
        if self._graphiti:
            await self._graphiti.close()
            self._initialized = False
