"""Incremental Updater for HELIX

Implements efficient incremental updates to the knowledge graph with:
- Delta-based ingestion for temporal datasets
- Version tracking for knowledge graph state
- Bi-temporal tracking (valid_time, transaction_time)
"""
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime
from dataclasses import dataclass, field
import json
import hashlib
from helix.config import config


@dataclass
class KnowledgeUpdate:
    """Represents a single knowledge graph update."""
    entity_id: str
    entity_name: str
    fact: str
    
    # Bi-temporal timestamps
    valid_from: Optional[str] = None  # When fact became true in reality
    valid_to: Optional[str] = None    # When fact stopped being true
    transaction_time: str = field(default_factory=lambda: datetime.now().isoformat())
    
    # Update metadata
    source: Optional[str] = None
    confidence: float = 1.0
    operation: str = "upsert"  # upsert, delete, invalidate
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "entity_id": self.entity_id,
            "entity_name": self.entity_name,
            "fact": self.fact,
            "valid_from": self.valid_from,
            "valid_to": self.valid_to,
            "transaction_time": self.transaction_time,
            "source": self.source,
            "confidence": self.confidence,
            "operation": self.operation
        }
    
    @property
    def content_hash(self) -> str:
        """Generate hash of fact content for deduplication."""
        content = f"{self.entity_name}:{self.fact}"
        return hashlib.md5(content.encode()).hexdigest()


@dataclass
class VersionedState:
    """Represents a version of the knowledge graph state."""
    version_id: str
    timestamp: str
    update_count: int
    parent_version: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


class IncrementalUpdater:
    """
    Incremental knowledge graph updater with temporal tracking.
    
    Features:
    - Delta-based updates (only changed facts)
    - Bi-temporal model (valid_time & transaction_time)
    - Version tracking for rollback
    - Conflict resolution
    
    Usage:
        updater = IncrementalUpdater(storage)
        
        # Add updates
        updater.add_update(KnowledgeUpdate(...))
        
        # Apply batch
        await updater.apply_updates()
        
        # Get state at point in time
        state = await updater.get_state_at("2023-01-01")
    """
    
    def __init__(self, storage):
        """
        Initialize with a GraphitiStorage instance.
        
        Args:
            storage: GraphitiStorage or compatible storage backend
        """
        self.storage = storage
        self.pending_updates: List[KnowledgeUpdate] = []
        self.versions: List[VersionedState] = []
        self.content_hashes: set = set()
        self._current_version = 0
    
    def add_update(self, update: KnowledgeUpdate) -> bool:
        """
        Add an update to the pending batch.
        
        Returns:
            True if update was added, False if duplicate
        """
        # Check for duplicates
        if update.content_hash in self.content_hashes:
            return False
        
        self.content_hashes.add(update.content_hash)
        self.pending_updates.append(update)
        return True
    
    def add_updates(self, updates: List[KnowledgeUpdate]) -> int:
        """Add multiple updates, returns count of non-duplicate additions."""
        added = 0
        for update in updates:
            if self.add_update(update):
                added += 1
        return added
    
    async def apply_updates(
        self,
        batch_size: int = 100
    ) -> VersionedState:
        """
        Apply all pending updates to the knowledge graph.
        
        Args:
            batch_size: Number of updates per batch
            
        Returns:
            New VersionedState after updates
        """
        if not self.pending_updates:
            return self._get_current_version()
        
        timestamp = datetime.now().isoformat()
        update_count = 0
        
        # Process in batches
        for i in range(0, len(self.pending_updates), batch_size):
            batch = self.pending_updates[i:i + batch_size]
            
            for update in batch:
                try:
                    await self._apply_single_update(update)
                    update_count += 1
                except Exception as e:
                    import traceback
                    traceback.print_exc()
                    print(f"Warning: Failed to apply update {update.entity_id}: {e}")
                    return False
        
        # Create new version
        new_version = VersionedState(
            version_id=f"v{self._current_version + 1}",
            timestamp=timestamp,
            update_count=update_count,
            parent_version=f"v{self._current_version}" if self._current_version > 0 else None,
            metadata={"batch_size": batch_size}
        )
        
        self.versions.append(new_version)
        self._current_version += 1
        
        # Clear pending
        self.pending_updates.clear()
        self.content_hashes.clear()
        
        return new_version
    
    async def _apply_single_update(self, update: KnowledgeUpdate):
        """Apply a single update to the storage."""
        await self.storage.initialize()
        
        if update.operation == "delete":
            await self._delete_entity(update)
        elif update.operation == "invalidate":
            await self._invalidate_fact(update)
        else:
            await self._upsert_fact(update)
    
    async def _upsert_fact(self, update: KnowledgeUpdate):
        """Insert or update a fact with temporal metadata."""
        cypher = """
        MERGE (e:Entity {name: $name})
        ON CREATE SET 
            e.created_at = $transaction_time,
            e.valid_from = $valid_from
        SET 
            e.fact = $fact,
            e.updated_at = $transaction_time,
            e.valid_to = $valid_to,
            e.source = $source,
            e.confidence = $confidence
        RETURN e
        """
        
        params = {
            "name": update.entity_name,
            "fact": update.fact,
            "valid_from": update.valid_from,
            "valid_to": update.valid_to,
            "transaction_time": update.transaction_time,
            "source": update.source,
            "confidence": update.confidence
        }
        
        try:
            async with self.storage.graphiti.driver.session() as session:
                await session.run(cypher, **params)
        except Exception:
            # Fallback: use storage add method if available
            pass
    
    async def _invalidate_fact(self, update: KnowledgeUpdate):
        """Mark a fact as no longer valid (set valid_to)."""
        cypher = """
        MATCH (e:Entity {name: $name})
        WHERE e.fact = $fact
        SET e.valid_to = $valid_to,
            e.invalidated_at = $transaction_time
        RETURN e
        """
        
        try:
            async with self.storage.graphiti.driver.session() as session:
                await session.run(cypher, 
                    name=update.entity_name,
                    fact=update.fact,
                    valid_to=update.valid_to or update.transaction_time,
                    transaction_time=update.transaction_time
                )
        except Exception:
            pass
    
    async def _delete_entity(self, update: KnowledgeUpdate):
        """Soft delete an entity (mark as deleted, preserve history)."""
        cypher = """
        MATCH (e:Entity {name: $name})
        SET e.deleted = true,
            e.deleted_at = $transaction_time
        RETURN e
        """
        
        try:
            async with self.storage.graphiti.driver.session() as session:
                await session.run(cypher,
                    name=update.entity_name,
                    transaction_time=update.transaction_time
                )
        except Exception:
            pass
    
    async def get_state_at(
        self, 
        point_in_time: str,
        entity_filter: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Get knowledge graph state at a specific point in time.
        
        Uses bi-temporal filtering:
        - valid_from <= point_in_time
        - valid_to is null OR valid_to > point_in_time
        
        Args:
            point_in_time: ISO timestamp
            entity_filter: Optional entity name filter
            
        Returns:
            List of valid facts at that time
        """
        await self.storage.initialize()
        
        cypher = """
        MATCH (e:Entity)
        WHERE (e.valid_from IS NULL OR e.valid_from <= $pit)
          AND (e.valid_to IS NULL OR e.valid_to > $pit)
          AND (e.deleted IS NULL OR e.deleted = false)
        """
        
        if entity_filter:
            cypher += " AND e.name CONTAINS $filter"
        
        cypher += """
        RETURN e.name AS name, 
               e.fact AS fact, 
               e.valid_from AS valid_from,
               e.valid_to AS valid_to,
               e.confidence AS confidence
        """
        
        params = {"pit": point_in_time}
        if entity_filter:
            params["filter"] = entity_filter
        
        try:
            async with self.storage.graphiti.driver.session() as session:
                result = await session.run(cypher, **params)
                records = await result.data()
                return records
        except Exception:
            return []
    
    async def get_temporal_evolution(
        self,
        entity_name: str,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Get the temporal evolution of an entity.
        
        Returns all versions of facts about an entity,
        ordered by valid_from.
        """
        await self.storage.initialize()
        
        cypher = """
        MATCH (e:Entity {name: $name})
        """
        
        conditions = []
        if start_time:
            conditions.append("e.valid_from >= $start")
        if end_time:
            conditions.append("(e.valid_to IS NULL OR e.valid_to <= $end)")
        
        if conditions:
            cypher += " WHERE " + " AND ".join(conditions)
        
        cypher += """
        RETURN e.name AS name,
               e.fact AS fact,
               e.valid_from AS valid_from,
               e.valid_to AS valid_to,
               e.created_at AS transaction_time
        ORDER BY e.valid_from
        """
        
        params = {"name": entity_name}
        if start_time:
            params["start"] = start_time
        if end_time:
            params["end"] = end_time
        
        try:
            async with self.storage.graphiti.driver.session() as session:
                result = await session.run(cypher, **params)
                records = await result.data()
                return records
        except Exception:
            return []
    
    def _get_current_version(self) -> VersionedState:
        """Get current version state."""
        if self.versions:
            return self.versions[-1]
        return VersionedState(
            version_id="v0",
            timestamp=datetime.now().isoformat(),
            update_count=0
        )
    
    def get_pending_count(self) -> int:
        """Get count of pending updates."""
        return len(self.pending_updates)
    
    def clear_pending(self):
        """Clear all pending updates without applying."""
        self.pending_updates.clear()
        self.content_hashes.clear()


def create_updates_from_dataset(
    data: List[Dict[str, Any]],
    source: str = "dataset"
) -> List[KnowledgeUpdate]:
    """
    Create KnowledgeUpdate objects from dataset entries.
    
    Expected format:
    {
        "entity": "entity name",
        "fact": "fact text",
        "valid_from": "2020-01-01",  # optional
        "valid_to": null,  # optional
    }
    """
    updates = []
    
    for item in data:
        entity = item.get("entity") or item.get("subject") or item.get("name", "Unknown")
        fact = item.get("fact") or item.get("text") or item.get("claim", "")
        
        if not fact:
            continue
        
        update = KnowledgeUpdate(
            entity_id=str(hash(f"{entity}:{fact}")),
            entity_name=entity,
            fact=fact,
            valid_from=item.get("valid_from") or item.get("start_time"),
            valid_to=item.get("valid_to") or item.get("end_time"),
            source=source,
            confidence=item.get("confidence", 1.0)
        )
        
        updates.append(update)
    
    return updates
