"""Temporal Query Handler for HELIX

Extends standard RAG query processing with temporal awareness,
enabling point-in-time queries and temporal reasoning using bi-temporal data.
"""
from typing import Optional, Dict, Any, List
from datetime import datetime
import json
import re
from helix.config import config


class TemporalQueryHandler:
    """
    Temporal query processing with bi-temporal filtering.
    
    Supports:
    - Point-in-time queries ("What was X in 2020?")
    - Temporal range queries ("How did X change from 2018-2022?")
    - Automatic temporal intent detection
    - Bi-temporal filtering (valid_time vs transaction_time)
    
    Usage:
        handler = TemporalQueryHandler(storage)
        result = await handler.query("What was the CEO of Apple in 2019?")
    """
    
    TEMPORAL_KEYWORDS = [
        "when", "was", "were", "before", "after", "during",
        "changed", "became", "previously", "currently", "now",
        "at that time", "back then", "used to be", "in 19", "in 20",
        "last year", "last month", "since", "until", "from", "to",
        "timeline", "evolution", "history"
    ]
    
    def __init__(self, storage):
        """
        Initialize with a GraphitiStorage instance.
        
        Args:
            storage: GraphitiStorage or compatible storage backend
        """
        self.storage = storage
    
    async def query(
        self, 
        query_text: str, 
        query_time: Optional[str] = None,
        num_results: int = 20
    ) -> Dict[str, Any]:
        """
        Process temporal queries with bi-temporal filtering.
        
        Args:
            query_text: User question
            query_time: Point-in-time to query (ISO format)
            num_results: Number of results to retrieve
            
        Returns:
            Dictionary with answer, temporal_params, and context
        """
        # Step 1: Detect temporal intent
        has_temporal = await self._detect_temporal_intent(query_text)
        
        # Step 2: Extract temporal parameters
        temporal_params = await self._extract_temporal_params(
            query_text, query_time
        )
        temporal_params["is_temporal"] = has_temporal
        
        # Step 3: Search with temporal context
        # If specific time requested, we might want to filter at retrieval time
        # For now, we retrieve then filter
        search_results = await self.storage.search(
            query=query_text,
            num_results=num_results * 2  # Retrieve more for filtering
        )
        
        # Step 4: Filter by temporal validity
        if temporal_params.get("valid_at") or temporal_params.get("valid_range"):
            filtered_results = self._filter_by_time(
                search_results, 
                temporal_params
            )
        else:
            filtered_results = search_results
            
        if len(filtered_results) < 5:
             # If filtering was too aggressive, fall back to mixed results but warn
             filtered_results = search_results[:num_results]
        else:
             filtered_results = filtered_results[:num_results]
        
        # Step 5: Build context and generate answer
        context_str = self._build_context(filtered_results, temporal_params)
        answer = await self._generate_answer(query_text, context_str, temporal_params)
        
        return {
            "answer": answer,
            "temporal_params": temporal_params,
            "context": filtered_results,
            "context_str": context_str
        }
    
    async def _detect_temporal_intent(self, query_text: str) -> bool:
        """Classify if query requires temporal reasoning"""
        query_lower = query_text.lower()
        
        # Quick keyword check
        if any(kw in query_lower for kw in self.TEMPORAL_KEYWORDS):
            return True
        
        # Regex for years
        if re.search(r'\b(19|20)\d{2}\b', query_text):
            return True
            
        return False
    
    async def _extract_temporal_params(
        self, 
        query_text: str, 
        query_time: Optional[str]
    ) -> Dict[str, Any]:
        """Extract temporal parameters from query"""
        params = {
            "valid_at": query_time,
            "valid_range": None,
            "temporal_type": "current",
            "reference_time": datetime.now().isoformat()
        }
        
        # Use LLM for extraction
        try:
            from helix.models.gemini_llm import gemini_complete_json
            
            prompt = f"""Extract temporal information from this query.
            
Query: {query_text}
Reference Date: {params['reference_time'].split('T')[0]}

Return JSON with:
- "valid_at": specific date (YYYY-MM-DD) if asking about point in time
- "valid_range": {{ "start": "YYYY-MM-DD", "end": "YYYY-MM-DD" }} if period
- "temporal_type": "point", "range", "evolution", "comparison" or "current"

JSON:"""
            
            response = await gemini_complete_json(prompt)
            extracted = json.loads(response)
            
            # Merge extracted with defaults/overrides
            if extracted.get("valid_at"):
                params["valid_at"] = extracted["valid_at"]
                
            if extracted.get("valid_range"):
                params["valid_range"] = extracted["valid_range"]
                
            if extracted.get("temporal_type"):
                params["temporal_type"] = extracted["temporal_type"]
                
        except Exception:
            # Fallback regex extraction
            years = re.findall(r'\b(19|20)\d{2}\b', query_text)
            if years:
                if len(years) == 1:
                    if not params["valid_at"]:
                        params["valid_at"] = f"{years[0]}-01-01"
                        params["temporal_type"] = "point"
                elif len(years) >= 2:
                    years = sorted(years)
                    params["valid_range"] = {
                        "start": f"{years[0]}-01-01",
                        "end": f"{years[-1]}-12-31"
                    }
                    params["temporal_type"] = "range"
        
        return params
    
    def _filter_by_time(
        self, 
        results: List[Dict[str, Any]], 
        params: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """
        Filter results by temporal validity.
        
        Logic:
           fact is valid IF (valid_from <= target_time) AND (valid_to > target_time OR valid_to IS NULL)
        """
        target_at = params.get("valid_at")
        target_range = params.get("valid_range")
        
        if not target_at and not target_range:
            return results
        
        filtered = []
        for result in results:
            if self._is_temporally_relevant(result, target_at, target_range):
                filtered.append(result)
        
        return filtered
    
    def _is_temporally_relevant(
        self,
        result: Dict[str, Any],
        target_at: Optional[str],
        target_range: Optional[Dict[str, str]]
    ) -> bool:
        """Check if a single result overlaps with target time."""
        # Get result validity bounds
        res_from = result.get("valid_from") or result.get("start_date")
        res_to = result.get("valid_to") or result.get("end_date")
        
        # If result has no temporal info, assume it's valid generally
        if not res_from and not res_to:
            return True
            
        try:
            # Convert to datetime for comparison
            r_start = datetime.fromisoformat(res_from.split('T')[0]) if res_from else datetime.min
            r_end = datetime.fromisoformat(res_to.split('T')[0]) if res_to else datetime.max
            
            # Check Point-in-Time
            if target_at:
                t_point = datetime.fromisoformat(target_at.split('T')[0])
                # Check containment: start <= point < end
                return r_start <= t_point and t_point < r_end
            
            # Check Range Overlap
            if target_range:
                t_start = datetime.fromisoformat(target_range.get("start", datetime.min.isoformat()).split('T')[0])
                t_end = datetime.fromisoformat(target_range.get("end", datetime.max.isoformat()).split('T')[0])
                
                # Overlap: (StartA <= EndB) and (EndA >= StartB)
                return r_start <= t_end and r_end >= t_start
                
        except (ValueError, TypeError, AttributeError):
            pass
            
        return True
    
    def _build_context(
        self, 
        results: List[Dict[str, Any]], 
        params: Dict[str, Any]
    ) -> str:
        """Build context string for LLM generation with temporal markers."""
        parts = []
        
        # Add temporal header
        if params.get("valid_at"):
            parts.append(f"[Temporal Context: State as of {params['valid_at']}]")
        elif params.get("valid_range"):
            r = params["valid_range"]
            parts.append(f"[Temporal Context: Period {r.get('start')} to {r.get('end')}]")
        
        # Format facts
        for result in results:
            name = result.get("name", "Unknown")
            fact = result.get("fact") or result.get("summary", "")
            
            # Format validity info
            valid_from = result.get("valid_from")
            valid_to = result.get("valid_to")
            
            time_str = ""
            if valid_from and valid_to:
                time_str = f" ({valid_from} to {valid_to})"
            elif valid_from:
                time_str = f" (from {valid_from})"
            elif valid_to:
                time_str = f" (until {valid_to})"
                
            if fact:
                parts.append(f"- {name}{time_str}: {fact}")
        
        return "\n".join(parts) if parts else "No relevant information found for this time period."
    
    async def _generate_answer(
        self,
        query: str,
        context: str,
        params: Dict[str, Any]
    ) -> str:
        """Generate answer using Gemini with temporal context"""
        from helix.models.gemini_llm import gemini_complete
        
        system = """You are a temporal knowledge assistant. 
Answer questions based ONLY on the provided context.
Pay close attention to the validity dates of facts.
- If a fact was valid in the past but not now, specify "in [Year]".
- If asking about a specific year, use facts valid during that year.
- If tracking evolution, describe the changes over time.
- If data is missing for the requested time, admit it.
"""
        
        prompt = f"""Context:
{context}

Question: {query}

Answer:"""
        
        return await gemini_complete(prompt, system_prompt=system)
