"""Test script for HELIX components"""
import asyncio
import sys
import os
# Add parent directory to sys.path so we can import helix when running from inside helix/
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from helix.config import config


async def test_gemini_llm():
    """Test Gemini LLM"""
    print("Testing Gemini LLM...")
    try:
        from helix.models.gemini_llm import gemini_complete
        response = await gemini_complete("Tell me a short fact about space.", max_tokens=50)
        print(f"  ✓ Prompt 1: {response.strip()}")
        
        # Try a different model if blocked
        if "Error: No text" in response:
            print("  ! Attempting fallback to gemini-2.0-flash...")
            from helix.models.gemini_llm import gemini_complete as complete_v2
            # Temporarily override model in config for testing
            old_model = config.gemini_model
            config.gemini_model = "gemini-2.0-flash"
            response_v2 = await complete_v2("Hello", max_tokens=10)
            print(f"  ✓ Fallback Response: {response_v2.strip()}")
            config.gemini_model = old_model
            
        return True
    except Exception as e:
        print(f"  ✗ Error: {e}")
        return False


async def test_embeddings():
    """Test Gemini Embeddings"""
    print("Testing Gemini Embeddings...")
    try:
        import google.generativeai as genai
        genai.configure(api_key=config.google_api_key)
        
        # Use configured model
        from helix.models.gemini_embeddings import embed_texts
        embeddings = await embed_texts(["Hello world"])
        
        print(f"  ✓ Embedding dim: {len(embeddings[0])}")
        print(f"  ✓ First 3 values: {embeddings[0][:3]}")
        return True
    except Exception as e:
        print(f"  ✗ Error: {e}")
        return False


async def test_neo4j():
    """Test Neo4j connection"""
    print("Testing Neo4j connection...")
    protocols = [
        config.neo4j_uri, 
        config.neo4j_uri.replace("neo4j+s://", "neo4j+ssc://"),
        config.neo4j_uri.replace("neo4j+s://", "bolt+s://"),
        config.neo4j_uri.replace("neo4j+s://", "bolt+ssc://")
    ]
    
    import ssl
    from neo4j import GraphDatabase, TrustAll
    
    for uri in protocols:
        print(f"  Trying {uri}...")
        try:
            # When using +s or +ssc, we shouldn't pass 'encrypted' as it's repetitive
            driver_kwargs = {
                "auth": (config.neo4j_user, config.neo4j_password),
            }
            
            # If we're forcing TrustAll on a non-ssc URI (for debugging)
            if "+ssc" not in uri and uri.startswith("bolt"):
                driver_kwargs["encrypted"] = True
                driver_kwargs["trusted_certificates"] = TrustAll()
                
            driver = GraphDatabase.driver(uri, **driver_kwargs)
            with driver.session() as session:
                result = session.run("RETURN 1 AS one")
                record = result.single()
                if record and record["one"] == 1:
                    print(f"  ✓ Neo4j connected via {uri}!")
                    driver.close()
                    return True
            driver.close()
        except Exception as e:
            print(f"  ! Protocol {uri.split('://')[0]} failed: {e}")
            
    return False


async def main():
    print("=" * 50)
    print("HELIX Component Tests")
    print("=" * 50)
    print()
    
    results = {
        "Gemini LLM": await test_gemini_llm(),
        "Embeddings": await test_embeddings(),
        "Neo4j": await test_neo4j(),
    }
    
    print()
    print("=" * 50)
    print("Results Summary:")
    for name, passed in results.items():
        status = "✓ PASS" if passed else "✗ FAIL"
        print(f"  {name}: {status}")
    print("=" * 50)


if __name__ == "__main__":
    asyncio.run(main())
