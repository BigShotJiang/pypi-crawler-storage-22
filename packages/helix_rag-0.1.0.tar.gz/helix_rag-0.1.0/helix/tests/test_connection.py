import pytest
import asyncio
from helix.storage.graphiti_storage import GraphitiStorage
from helix.config import config
import traceback

@pytest.mark.asyncio
async def test_graphiti_connection():
    try:
        print(f"Connecting to {config.neo4j_uri}...")
        storage = GraphitiStorage(namespace="test_conn")
        await storage.initialize()
        print("Graphiti initialized successfully!")
    except Exception as e:
        traceback.print_exc()
        # Print inner exception if available
        if hasattr(e, '__cause__') and e.__cause__:
             print(f"Caused by: {e.__cause__}")
        raise e

if __name__ == "__main__":
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(test_graphiti_connection())
