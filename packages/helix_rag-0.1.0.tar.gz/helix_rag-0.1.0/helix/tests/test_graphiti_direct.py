import asyncio
from graphiti_core import Graphiti
from helix.config import config
import traceback

async def test_direct():
    print(f"URI: {config.neo4j_uri}")
    try:
        g = Graphiti(
            uri=config.neo4j_uri,
            user=config.neo4j_user,
            password=config.neo4j_password
        )
        print("Graphiti instantiated.")
        await g.build_indices_and_constraints()
        print("Indices built.")
        await g.close()
    except Exception:
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_direct())
