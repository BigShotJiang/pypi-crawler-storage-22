"""Claim Extractor for HELIX Verification

Extracts structured claims from LLM responses for verification:
- Factual claims (entity facts)
- Relational claims (entity relationships)
- Temporal claims (time-bound assertions)
"""
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field
from enum import Enum
import json
from helix.config import config


class ClaimType(Enum):
    """Types of claims that can be extracted."""
    FACTUAL = "factual"      # Simple entity facts
    RELATIONAL = "relational" # Entity-relation-entity
    TEMPORAL = "temporal"     # Time-bound claims
    QUANTITATIVE = "quantitative"  # Numerical claims
    COMPARATIVE = "comparative"    # Comparisons


@dataclass
class Claim:
    """Represents an extracted claim."""
    claim_type: ClaimType
    text: str               # Original claim text
    subject: str            # Main entity
    predicate: str          # Relation/property
    object: str             # Value or target entity
    
    # Temporal bounds
    valid_from: Optional[str] = None
    valid_to: Optional[str] = None
    
    # Verification status
    verified: Optional[bool] = None
    confidence: float = 0.0
    source: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "claim_type": self.claim_type.value,
            "text": self.text,
            "subject": self.subject,
            "predicate": self.predicate,
            "object": self.object,
            "valid_from": self.valid_from,
            "valid_to": self.valid_to,
            "verified": self.verified,
            "confidence": self.confidence,
            "source": self.source
        }


@dataclass
class ClaimExtractionResult:
    """Result of claim extraction."""
    claims: List[Claim]
    raw_text: str
    extraction_method: str = "llm"
    
    @property
    def factual_claims(self) -> List[Claim]:
        return [c for c in self.claims if c.claim_type == ClaimType.FACTUAL]
    
    @property
    def relational_claims(self) -> List[Claim]:
        return [c for c in self.claims if c.claim_type == ClaimType.RELATIONAL]
    
    @property
    def temporal_claims(self) -> List[Claim]:
        return [c for c in self.claims if c.claim_type == ClaimType.TEMPORAL]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "raw_text": self.raw_text,
            "extraction_method": self.extraction_method,
            "claim_count": len(self.claims),
            "claims": [c.to_dict() for c in self.claims]
        }


class ClaimExtractor:
    """
    Extract structured claims from LLM responses.
    
    Usage:
        extractor = ClaimExtractor()
        result = await extractor.extract(answer)
        
        for claim in result.factual_claims:
            print(f"{claim.subject} - {claim.predicate} - {claim.object}")
    """
    
    TEMPORAL_KEYWORDS = [
        "was", "were", "became", "used to", "previously", "currently",
        "in 2", "during", "before", "after", "since", "until",
        "from", "to", "as of", "at that time"
    ]
    
    COMPARATIVE_KEYWORDS = [
        "larger", "smaller", "bigger", "more", "less", "greater",
        "higher", "lower", "better", "worse", "than"
    ]
    
    async def extract(self, text: str) -> ClaimExtractionResult:
        """
        Extract claims from text using LLM.
        
        Args:
            text: Text to extract claims from
            
        Returns:
            ClaimExtractionResult with structured claims
        """
        try:
            claims = await self._llm_extract(text)
            return ClaimExtractionResult(
                claims=claims,
                raw_text=text,
                extraction_method="llm"
            )
        except Exception:
            # Fallback to rule-based
            claims = self._rule_based_extract(text)
            return ClaimExtractionResult(
                claims=claims,
                raw_text=text,
                extraction_method="rule_based"
            )
    
    async def _llm_extract(self, text: str) -> List[Claim]:
        """Extract claims using LLM."""
        from helix.models.gemini_llm import gemini_complete_json
        
        prompt = f"""Extract all factual claims from this text. For each claim, identify:
- subject: the main entity
- predicate: the relation or property
- object: the value or target entity
- type: "factual", "relational", "temporal", "quantitative", or "comparative"
- time_info: any temporal information (dates, periods)

Text: {text}

Return JSON:
{{
    "claims": [
        {{
            "text": "original claim text",
            "subject": "entity",
            "predicate": "relation",
            "object": "value",
            "type": "factual",
            "time_info": null
        }}
    ]
}}"""
        
        response = await gemini_complete_json(prompt)
        data = json.loads(response)
        
        claims = []
        for item in data.get("claims", []):
            claim_type = self._parse_claim_type(item.get("type", "factual"))
            time_info = item.get("time_info")
            
            claim = Claim(
                claim_type=claim_type,
                text=item.get("text", ""),
                subject=item.get("subject", ""),
                predicate=item.get("predicate", ""),
                object=item.get("object", ""),
                valid_from=time_info if isinstance(time_info, str) else None
            )
            
            claims.append(claim)
        
        return claims
    
    def _rule_based_extract(self, text: str) -> List[Claim]:
        """Simple rule-based claim extraction."""
        claims = []
        
        # Split into sentences
        sentences = text.replace(".", ". ").split(". ")
        
        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence or len(sentence) < 10:
                continue
            
            # Detect claim type
            claim_type = self._detect_claim_type(sentence)
            
            # Extract SPO triple (simplified)
            spo = self._extract_spo(sentence)
            
            if spo:
                subject, predicate, obj = spo
                
                # Check for temporal info
                valid_from = self._extract_date(sentence)
                
                claim = Claim(
                    claim_type=claim_type,
                    text=sentence,
                    subject=subject,
                    predicate=predicate,
                    object=obj,
                    valid_from=valid_from
                )
                
                claims.append(claim)
        
        return claims
    
    def _detect_claim_type(self, sentence: str) -> ClaimType:
        """Detect the type of claim based on keywords."""
        sentence_lower = sentence.lower()
        
        if any(kw in sentence_lower for kw in self.TEMPORAL_KEYWORDS):
            return ClaimType.TEMPORAL
        
        if any(kw in sentence_lower for kw in self.COMPARATIVE_KEYWORDS):
            return ClaimType.COMPARATIVE
        
        # Check for numbers
        if any(c.isdigit() for c in sentence):
            return ClaimType.QUANTITATIVE
        
        # Check for relational patterns
        relational_patterns = [" of ", " with ", " and ", " by ", " from "]
        if any(p in sentence_lower for p in relational_patterns):
            return ClaimType.RELATIONAL
        
        return ClaimType.FACTUAL
    
    def _extract_spo(self, sentence: str) -> Optional[tuple]:
        """Extract Subject-Predicate-Object triple from sentence."""
        import re
        
        # Simple pattern: "X is Y" or "X was Y"
        pattern = r'^(.+?)\s+(is|was|are|were|has|had|have)\s+(.+)$'
        match = re.match(pattern, sentence, re.IGNORECASE)
        
        if match:
            subject = match.group(1).strip()
            predicate = match.group(2).strip()
            obj = match.group(3).strip()
            return (subject, predicate, obj)
        
        # Pattern: "The X of Y is Z"
        pattern2 = r'^The\s+(.+?)\s+of\s+(.+?)\s+(is|was)\s+(.+)$'
        match2 = re.match(pattern2, sentence, re.IGNORECASE)
        
        if match2:
            prop = match2.group(1).strip()
            entity = match2.group(2).strip()
            obj = match2.group(4).strip()
            return (entity, f"has {prop}", obj)
        
        return None
    
    def _extract_date(self, sentence: str) -> Optional[str]:
        """Extract date from sentence."""
        import re
        
        # Year pattern
        year_match = re.search(r'\b(19|20)\d{2}\b', sentence)
        if year_match:
            return f"{year_match.group()}-01-01"
        
        # Full date pattern
        date_match = re.search(r'\b(\d{4}[-/]\d{2}[-/]\d{2})\b', sentence)
        if date_match:
            return date_match.group(1).replace("/", "-")
        
        return None
    
    def _parse_claim_type(self, type_str: str) -> ClaimType:
        """Parse claim type from string."""
        type_map = {
            "factual": ClaimType.FACTUAL,
            "relational": ClaimType.RELATIONAL,
            "temporal": ClaimType.TEMPORAL,
            "quantitative": ClaimType.QUANTITATIVE,
            "comparative": ClaimType.COMPARATIVE
        }
        return type_map.get(type_str.lower(), ClaimType.FACTUAL)
    
    async def extract_and_verify(
        self, 
        text: str, 
        context: List[Dict[str, Any]]
    ) -> ClaimExtractionResult:
        """
        Extract claims and verify against context.
        
        Sets verified=True for claims found in context.
        """
        result = await self.extract(text)
        
        # Build context facts set
        context_facts = set()
        for item in context:
            fact = (item.get("fact") or item.get("summary", "")).lower()
            if fact:
                context_facts.add(fact)
        
        # Verify each claim
        for claim in result.claims:
            claim_text = claim.text.lower()
            
            # Check if claim is supported by context
            for fact in context_facts:
                if self._claim_supported(claim, fact):
                    claim.verified = True
                    claim.confidence = 0.9
                    break
            else:
                claim.verified = False
                claim.confidence = 0.1
        
        return result
    
    def _claim_supported(self, claim: Claim, fact: str) -> bool:
        """Check if a claim is supported by a fact."""
        # Check subject and object presence
        subject_lower = claim.subject.lower()
        object_lower = claim.object.lower()
        
        return subject_lower in fact and object_lower in fact
