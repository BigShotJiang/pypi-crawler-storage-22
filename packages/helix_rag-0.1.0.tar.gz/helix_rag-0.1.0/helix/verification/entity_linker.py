"""Entity Linker for HELIX Verification

Links entities mentioned in LLM responses to knowledge graph entities
for grounding verification.
"""
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
import re
from helix.config import config


@dataclass
class LinkedEntity:
    """Represents an entity linked to the knowledge graph."""
    mention: str           # Text as it appears in response
    entity_id: str         # ID in knowledge graph
    entity_name: str       # Canonical name
    confidence: float      # Linking confidence (0-1)
    is_grounded: bool      # Whether entity exists in KG
    aliases: List[str] = None
    
    def __post_init__(self):
        if self.aliases is None:
            self.aliases = []


class EntityLinker:
    """
    Link entity mentions to knowledge graph entities.
    
    Features:
    - Exact matching
    - Fuzzy matching for typos/variations
    - Alias resolution
    - Confidence scoring
    
    Usage:
        linker = EntityLinker(storage)
        linked = await linker.link_entities(answer, context)
        grounding_score = linker.compute_grounding_score(linked)
    """
    
    def __init__(self, storage):
        """
        Initialize with GraphitiStorage.
        
        Args:
            storage: GraphitiStorage or compatible storage backend
        """
        self.storage = storage
        self._entity_cache: Dict[str, Dict[str, Any]] = {}
    
    async def link_entities(
        self,
        text: str,
        context: List[Dict[str, Any]],
        extract_mentions: bool = True
    ) -> List[LinkedEntity]:
        """
        Link entity mentions in text to knowledge graph.
        
        Args:
            text: Text to analyze (e.g., LLM response)
            context: Retrieved context for local matching
            extract_mentions: Whether to extract mentions from text
            
        Returns:
            List of LinkedEntity objects
        """
        # Step 1: Extract entity mentions
        if extract_mentions:
            mentions = await self._extract_mentions(text)
        else:
            mentions = self._simple_extract(text)
        
        # Step 2: Build context entity index
        context_entities = self._build_context_index(context)
        
        # Step 3: Link each mention
        linked = []
        for mention in mentions:
            link_result = await self._link_mention(mention, context_entities)
            linked.append(link_result)
        
        return linked
    
    async def _extract_mentions(self, text: str) -> List[str]:
        """Extract entity mentions using LLM."""
        try:
            from helix.models.gemini_llm import gemini_complete_json
            import json
            
            prompt = f"""Extract all entity mentions (people, places, organizations, concepts) from this text.
            
Text: {text}

Return JSON: {{"entities": ["entity1", "entity2", ...]}}"""
            
            response = await gemini_complete_json(prompt)
            data = json.loads(response)
            return data.get("entities", [])
        except Exception:
            return self._simple_extract(text)
    
    def _simple_extract(self, text: str) -> List[str]:
        """Simple extraction using capitalization patterns."""
        # Match capitalized words and phrases
        pattern = r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b'
        matches = re.findall(pattern, text)
        
        # Deduplicate while preserving order
        seen = set()
        unique = []
        for m in matches:
            if m.lower() not in seen:
                seen.add(m.lower())
                unique.append(m)
        
        return unique
    
    def _build_context_index(
        self, 
        context: List[Dict[str, Any]]
    ) -> Dict[str, Dict[str, Any]]:
        """Build searchable index from context entities."""
        index = {}
        
        for item in context:
            name = item.get("name", "")
            if name:
                name_lower = name.lower()
                index[name_lower] = {
                    "id": item.get("id", name_lower),
                    "name": name,
                    "fact": item.get("fact") or item.get("summary", ""),
                    "aliases": self._generate_aliases(name)
                }
                
                # Index aliases too
                for alias in index[name_lower]["aliases"]:
                    if alias not in index:
                        index[alias] = index[name_lower]
        
        return index
    
    def _generate_aliases(self, name: str) -> List[str]:
        """Generate common aliases for an entity name."""
        aliases = []
        name_lower = name.lower()
        
        # Add lowercase
        aliases.append(name_lower)
        
        # Remove common prefixes
        for prefix in ["the ", "a ", "an "]:
            if name_lower.startswith(prefix):
                aliases.append(name_lower[len(prefix):])
        
        # Handle acronym generation for multi-word names
        words = name.split()
        if len(words) > 1:
            acronym = "".join(w[0] for w in words).lower()
            aliases.append(acronym)
        
        # Last name only for person names
        if len(words) == 2 and words[0][0].isupper() and words[1][0].isupper():
            aliases.append(words[1].lower())  # Last name
        
        return aliases
    
    async def _link_mention(
        self,
        mention: str,
        context_entities: Dict[str, Dict[str, Any]]
    ) -> LinkedEntity:
        """Link a single mention to knowledge graph."""
        mention_lower = mention.lower()
        
        # Try exact match in context
        if mention_lower in context_entities:
            entity = context_entities[mention_lower]
            return LinkedEntity(
                mention=mention,
                entity_id=entity["id"],
                entity_name=entity["name"],
                confidence=1.0,
                is_grounded=True,
                aliases=entity.get("aliases", [])
            )
        
        # Try fuzzy match in context
        for ctx_name, entity in context_entities.items():
            if self._fuzzy_match(mention_lower, ctx_name):
                return LinkedEntity(
                    mention=mention,
                    entity_id=entity["id"],
                    entity_name=entity["name"],
                    confidence=0.9,
                    is_grounded=True,
                    aliases=entity.get("aliases", [])
                )
            
            # Check aliases
            for alias in entity.get("aliases", []):
                if mention_lower == alias or self._fuzzy_match(mention_lower, alias):
                    return LinkedEntity(
                        mention=mention,
                        entity_id=entity["id"],
                        entity_name=entity["name"],
                        confidence=0.85,
                        is_grounded=True,
                        aliases=entity.get("aliases", [])
                    )
        
        # Try storage search
        try:
            results = await self.storage.search(query=mention, num_results=1)
            if results:
                best = results[0]
                return LinkedEntity(
                    mention=mention,
                    entity_id=str(best.get("id", mention_lower)),
                    entity_name=best.get("name", mention),
                    confidence=0.7,
                    is_grounded=True
                )
        except Exception:
            pass
        
        # Not grounded
        return LinkedEntity(
            mention=mention,
            entity_id=mention_lower,
            entity_name=mention,
            confidence=0.0,
            is_grounded=False
        )
    
    def _fuzzy_match(self, s1: str, s2: str, threshold: float = 0.8) -> bool:
        """Simple fuzzy string matching."""
        if not s1 or not s2:
            return False
        
        # Check substring
        if s1 in s2 or s2 in s1:
            return True
        
        # Check edit distance ratio (simplified)
        common = len(set(s1) & set(s2))
        total = len(set(s1) | set(s2))
        
        if total == 0:
            return False
        
        ratio = common / total
        return ratio >= threshold
    
    def compute_grounding_score(self, linked: List[LinkedEntity]) -> float:
        """
        Compute entity grounding score.
        
        EG = (grounded entities) / (total entities)
        """
        if not linked:
            return 1.0
        
        grounded = sum(1 for e in linked if e.is_grounded)
        return grounded / len(linked)
    
    def compute_weighted_grounding(self, linked: List[LinkedEntity]) -> float:
        """
        Compute confidence-weighted grounding score.
        
        Accounts for linking confidence in the score.
        """
        if not linked:
            return 1.0
        
        total_confidence = sum(e.confidence for e in linked)
        grounded_confidence = sum(e.confidence for e in linked if e.is_grounded)
        
        return grounded_confidence / max(total_confidence, 1.0)
