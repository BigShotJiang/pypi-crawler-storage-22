"""Hallucination Detection Module for HELIX

Detects hallucinations by verifying LLM outputs against the knowledge graph.
Uses Entity Grounding, Relation Preservation, and Temporal Consistency checks.
"""
from typing import Dict, Any, List
import json
from helix.config import config


class HallucinationDetector:
    """
    Detects hallucinations by verifying answers against knowledge graph.
    
    Components:
    1. Entity Grounding (EG): Are entities present in KG?
    2. Relation Preservation (RP): Are relationships in KG?
    3. Temporal Consistency (TC): Are temporal claims valid?
    4. Composite Fidelity Index (CFI): Overall confidence score
    
    Usage:
        detector = HallucinationDetector(storage)
        result = await detector.verify_answer(query, answer, context)
        if result["hallucination_detected"]:
            # Handle low-confidence answer
    """
    
    def __init__(self, storage):
        """
        Initialize with a GraphitiStorage instance.
        
        Args:
            storage: GraphitiStorage or compatible storage backend
        """
        self.storage = storage
        self.threshold = config.hallucination_threshold
    
    async def verify_answer(
        self,
        query: str,
        answer: str,
        context: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Verify answer against knowledge graph.
        
        Args:
            query: Original user question
            answer: Generated answer to verify
            context: Retrieved context used for generation
            
        Returns:
            Dictionary with verification scores and hallucination flag
        """
        # Step 1: Extract claims from answer
        extracted = await self._extract_claims(answer)
        
        # Step 2: Entity Grounding Check
        eg_score = await self._check_entity_grounding(
            extracted.get("entities", []),
            context
        )
        
        # Step 3: Relation Preservation Check
        rp_score = await self._check_relation_preservation(
            extracted.get("relations", []),
            context
        )
        
        # Step 4: Temporal Consistency Check
        tc_score = await self._check_temporal_consistency(
            extracted,
            query
        )
        
        # Step 5: Compute Composite Fidelity Index
        cfi = self._compute_cfi(eg_score, rp_score, tc_score)
        
        # Step 6: Determine hallucination
        hallucination_detected = cfi < self.threshold
        
        return {
            "entity_grounding": eg_score,
            "relation_preservation": rp_score,
            "temporal_consistency": tc_score,
            "composite_fidelity": cfi,
            "hallucination_detected": hallucination_detected,
            "confidence": cfi,
            "extracted_claims": extracted
        }
    
    async def _extract_claims(self, answer: str) -> Dict[str, Any]:
        """Extract entity and relation claims from answer"""
        try:
            from helix.models.gemini_llm import gemini_complete_json
            
            prompt = f"""Extract entities and relations from this answer:

Answer: {answer}

Return JSON:
{{
    "entities": ["entity1", "entity2"],
    "relations": [
        {{"source": "entity1", "relation": "type", "target": "entity2"}}
    ]
}}"""
            
            response = await gemini_complete_json(prompt)
            return json.loads(response)
        except Exception:
            return {"entities": [], "relations": []}
    
    async def _check_entity_grounding(
        self,
        entities: List[str],
        context: List[Dict[str, Any]]
    ) -> float:
        """
        Entity Grounding: % of entities present in KG.
        Target: >95%
        """
        if not entities:
            return 1.0
        
        # Build context entity set
        context_entities = set()
        for item in context:
            name = item.get("name", "").lower()
            if name:
                context_entities.add(name)
        
        grounded = 0
        for entity in entities:
            entity_lower = entity.lower()
            
            # Check in context first
            if entity_lower in context_entities:
                grounded += 1
                continue
            
            # Check partial matches
            if any(entity_lower in ce or ce in entity_lower for ce in context_entities):
                grounded += 1
                continue
            
            # Check in storage
            try:
                results = await self.storage.search(query=entity, num_results=1)
                if results:
                    grounded += 1
            except Exception:
                pass
        
        return grounded / len(entities)
    
    async def _check_relation_preservation(
        self,
        relations: List[Dict[str, str]],
        context: List[Dict[str, Any]]
    ) -> float:
        """
        Relation Preservation: % of relations present in KG.
        Target: >90%
        """
        if not relations:
            return 1.0
        
        # Build context facts set
        context_facts = set()
        for item in context:
            fact = (item.get("fact") or item.get("summary", "")).lower()
            if fact:
                context_facts.add(fact)
        
        verified = 0
        for rel in relations:
            source = rel.get("source", "").lower()
            target = rel.get("target", "").lower()
            relation = rel.get("relation", "").lower()
            
            # Check if relation is mentioned in any context fact
            rel_text = f"{source} {relation} {target}"
            for fact in context_facts:
                if source in fact and target in fact:
                    verified += 1
                    break
            else:
                # Check in storage
                try:
                    results = await self.storage.search(query=rel_text, num_results=1)
                    if results:
                        verified += 1
                except Exception:
                    pass
        
        return verified / len(relations)
    
    async def _check_temporal_consistency(
        self,
        extracted: Dict[str, Any],
        query: str
    ) -> float:
        """
        Temporal Consistency: Are temporal claims valid?
        Uses Graphiti's bi-temporal model.
        """
        # Find temporal claims in relations
        temporal_keywords = ["was", "became", "used to", "previously", "changed"]
        temporal_claims = [
            rel for rel in extracted.get("relations", [])
            if any(kw in rel.get("relation", "").lower() for kw in temporal_keywords)
        ]
        
        if not temporal_claims:
            return 1.0
        
        # For now, basic check - can be enhanced with actual temporal queries
        consistent = len(temporal_claims)  # Assume consistent if properly formatted
        return consistent / len(temporal_claims)
    
    def _compute_cfi(self, eg: float, rp: float, tc: float) -> float:
        """
        Composite Fidelity Index.
        
        CFI = w1*EG + w2*RP + w3*TC
        """
        weights = [
            config.entity_grounding_weight,      # 0.4
            config.relation_preservation_weight, # 0.4
            config.temporal_consistency_weight   # 0.2
        ]
        
        return weights[0] * eg + weights[1] * rp + weights[2] * tc
    
    async def regenerate_with_grounding(
        self,
        query: str,
        context: List[Dict[str, Any]],
        verification: Dict[str, Any]
    ) -> str:
        """
        Regenerate answer with stronger grounding constraints.
        Called when hallucination is detected.
        """
        from helix.models.gemini_llm import gemini_complete
        
        # Build explicit grounding context
        grounded_facts = []
        for item in context[:10]:
            name = item.get("name", "")
            fact = item.get("fact") or item.get("summary", "")
            if fact:
                grounded_facts.append(f"- {name}: {fact}")
        
        system = """You are a fact-grounded assistant.
ONLY use information from the provided facts.
If information is not in the facts, say "I don't have information about that."
Never invent or assume facts not explicitly stated."""
        
        prompt = f"""Verified Facts:
{chr(10).join(grounded_facts) if grounded_facts else "No verified facts available."}

Question: {query}

Answer using ONLY the verified facts above:"""
        
        return await gemini_complete(prompt, system_prompt=system)
