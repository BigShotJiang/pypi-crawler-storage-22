# HELIX Quick Start - Google Colab

This notebook demonstrates how to use HELIX as a plug-and-play RAG system.

## Installation

```python
# Install HELIX (from PyPI when published, or from source)
!pip install helix-rag

# Or install from GitHub
# !pip install git+https://github.com/helix-rag/helix.git
```

## Configuration

```python
# Set your credentials
import os
os.environ["GOOGLE_API_KEY"] = "your-gemini-api-key"
os.environ["NEO4J_URI"] = "neo4j+ssc://your-instance.databases.neo4j.io"
os.environ["NEO4J_USER"] = "neo4j"
os.environ["NEO4J_PASSWORD"] = "your-password"
```

## Basic Usage

```python
from helix import Helix
import asyncio

async def demo():
    async with Helix() as h:
        # Ingest some facts
        await h.ingest("""
            Albert Einstein developed the theory of special relativity in 1905.
            He received the Nobel Prize in Physics in 1921 for the photoelectric effect.
            Einstein became a US citizen in 1940.
        """)
        
        # Query with temporal awareness
        result = await h.query(
            "When did Einstein develop special relativity?",
            mode="temporal"
        )
        print(f"Answer: {result.answer}")
        print(f"Confidence: {result.confidence:.2%}")
        
        # Multi-hop query
        result = await h.query(
            "What other achievements did the person who developed relativity have?",
            mode="multi_hop"
        )
        print(f"Answer: {result.answer}")

# Run in Colab
await demo()
```

## Evaluation on Benchmarks

```python
from helix import Helix
from helix.evaluation import HELIXEvaluator, BenchmarkCategory

async def evaluate_helix():
    async with Helix() as h:
        evaluator = HELIXEvaluator(h._pipeline, data_dir="./datasets")
        
        # Evaluate on Multi-Hop datasets
        results = await evaluator.evaluate("musique", split="dev", limit=50)
        summary = evaluator.summarize(results)
        
        print(f"MuSiQue Results:")
        print(f"  Exact Match: {summary.avg_exact_match:.2%}")
        print(f"  F1 Score: {summary.avg_f1:.2%}")
        print(f"  Retrieval F1: {summary.avg_retrieval_f1:.2%}")

await evaluate_helix()
```

## Advanced: Custom Configuration

```python
from helix import Helix, HELIXConfig

# Create custom config
custom_config = HELIXConfig()
custom_config.gemini_model = "gemini-2.0-flash"
custom_config.max_hops = 5
custom_config.hallucination_threshold = 0.90

# Use custom config
h = Helix(config=custom_config)
```
