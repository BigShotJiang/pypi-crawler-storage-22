"""
Helix API: Unified FastAPI server for the Helix RAG pipeline.

Exposes LightRAG + Graphiti capabilities through a single REST API
with endpoints for temporal queries, multi-hop reasoning, document
ingestion with metadata, and hallucination validation.
"""

from helix.api.server import create_app

__all__ = ["create_app"]
