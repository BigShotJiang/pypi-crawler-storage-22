"""
Helix: Temporal GraphRAG - LightRAG + Graphiti Integration.

Helix combines LightRAG's proven dual-level retrieval with Graphiti's
bi-temporal Knowledge Graph to create a next-generation RAG system.
"""

__version__ = "0.1.5"
__author__ = "Yash Nuhash"

from helix.core import Helix, HelixConfig

__all__ = [
    "__version__",
    "__author__",
    "Helix",
    "HelixConfig",
]
