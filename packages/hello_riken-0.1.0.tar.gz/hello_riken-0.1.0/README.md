# Hello Riken

A simple Python package that prints "Hello Riken!"

## Installation
```bash
pip install hello-riken
```

## Usage
```python
from helloriken import greet

greet()  # Prints: Hello Riken!
```

## License

MIT
```

---

## Step 4: Create LICENSE (1 minute)

### File 4: `LICENSE`

Just copy this (MIT License):
```
MIT License

Copyright (c) 2025 Riken

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

---

## Your folder structure should look like this:
```
hello-riken/
├── helloriken/
│   └── __init__.py
├── setup.py
├── README.md
└── LICENSE