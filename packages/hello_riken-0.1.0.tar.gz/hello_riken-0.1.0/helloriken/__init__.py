def greet():
    print("Hello Riken!")

__version__ = "0.1.0"