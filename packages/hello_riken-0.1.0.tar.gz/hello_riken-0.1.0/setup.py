from setuptools import setup, find_packages

setup(
    name="hello-riken",
    version="0.1.0",
    author="Riken",  # Your name
    author_email="rikenkhadela777@gmail.com",  # Your email
    description="A simple package that prints Hello Riken",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/riken-khadela/hello-riken",  # Your GitHub (or just use #)
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
)