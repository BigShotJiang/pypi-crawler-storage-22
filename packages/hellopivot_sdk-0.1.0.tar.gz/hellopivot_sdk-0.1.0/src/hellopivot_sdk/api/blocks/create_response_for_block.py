from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.create_response_for_block_content import CreateResponseForBlockContent
from ...models.create_response_for_block_response import CreateResponseForBlockResponse
from ...models.status import Status
from ...types import UNSET, Response


def _get_kwargs(
    block_id: str,
    *,
    body: CreateResponseForBlockContent,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/blocks/{block_id}/responses".format(
            block_id=quote(str(block_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CreateResponseForBlockResponse | Status:
    if response.status_code == 200:
        response_200 = CreateResponseForBlockResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)

    try:
        response_default = Status.from_dict(response.json())
    except ValueError:
        response_default = Status.from_dict({})

    return response_default


def _safe_http_status(code: int) -> int | HTTPStatus:
    try:
        return HTTPStatus(code)
    except ValueError:
        return code


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CreateResponseForBlockResponse | Status]:
    return Response(
        status_code=_safe_http_status(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    block_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateResponseForBlockContent,
) -> Response[CreateResponseForBlockResponse | Status]:
    """Create block response

     Creates a new response for a block.

    Args:
        block_id (str):
        body (CreateResponseForBlockContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateResponseForBlockResponse | Status]
    """

    kwargs = _get_kwargs(
        block_id=block_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    block_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateResponseForBlockContent,
) -> CreateResponseForBlockResponse | Status | None:
    """Create block response

     Creates a new response for a block.

    Args:
        block_id (str):
        body (CreateResponseForBlockContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateResponseForBlockResponse | Status
    """

    return sync_detailed(
        block_id=block_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    block_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateResponseForBlockContent,
) -> Response[CreateResponseForBlockResponse | Status]:
    """Create block response

     Creates a new response for a block.

    Args:
        block_id (str):
        body (CreateResponseForBlockContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateResponseForBlockResponse | Status]
    """

    kwargs = _get_kwargs(
        block_id=block_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    block_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateResponseForBlockContent,
) -> CreateResponseForBlockResponse | Status | None:
    """Create block response

     Creates a new response for a block.

    Args:
        block_id (str):
        body (CreateResponseForBlockContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateResponseForBlockResponse | Status
    """

    return (
        await asyncio_detailed(
            block_id=block_id,
            client=client,
            body=body,
        )
    ).parsed
