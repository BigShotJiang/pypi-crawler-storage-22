from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.delete_block_response_attachment_response import DeleteBlockResponseAttachmentResponse
from ...models.status import Status
from ...types import UNSET, Response


def _get_kwargs(
    attachment_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/v1/blocks/responses/attachments/{attachment_id}".format(
            attachment_id=quote(str(attachment_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeleteBlockResponseAttachmentResponse | Status:
    if response.status_code == 200:
        response_200 = DeleteBlockResponseAttachmentResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)

    try:
        response_default = Status.from_dict(response.json())
    except ValueError:
        response_default = Status.from_dict({})

    return response_default


def _safe_http_status(code: int) -> int | HTTPStatus:
    try:
        return HTTPStatus(code)
    except ValueError:
        return code


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeleteBlockResponseAttachmentResponse | Status]:
    return Response(
        status_code=_safe_http_status(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    attachment_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[DeleteBlockResponseAttachmentResponse | Status]:
    """Delete a block response attachment

     Deletes a file attached to a block response.

    Args:
        attachment_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteBlockResponseAttachmentResponse | Status]
    """

    kwargs = _get_kwargs(
        attachment_id=attachment_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    attachment_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> DeleteBlockResponseAttachmentResponse | Status | None:
    """Delete a block response attachment

     Deletes a file attached to a block response.

    Args:
        attachment_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteBlockResponseAttachmentResponse | Status
    """

    return sync_detailed(
        attachment_id=attachment_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    attachment_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[DeleteBlockResponseAttachmentResponse | Status]:
    """Delete a block response attachment

     Deletes a file attached to a block response.

    Args:
        attachment_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteBlockResponseAttachmentResponse | Status]
    """

    kwargs = _get_kwargs(
        attachment_id=attachment_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    attachment_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> DeleteBlockResponseAttachmentResponse | Status | None:
    """Delete a block response attachment

     Deletes a file attached to a block response.

    Args:
        attachment_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteBlockResponseAttachmentResponse | Status
    """

    return (
        await asyncio_detailed(
            attachment_id=attachment_id,
            client=client,
        )
    ).parsed
