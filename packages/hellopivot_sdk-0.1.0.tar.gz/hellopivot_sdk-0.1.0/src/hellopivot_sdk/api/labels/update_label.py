from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.status import Status
from ...models.update_label_content import UpdateLabelContent
from ...models.update_label_response import UpdateLabelResponse
from ...types import UNSET, Response


def _get_kwargs(
    label_id: str,
    *,
    body: UpdateLabelContent,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/v1/labels/{label_id}".format(
            label_id=quote(str(label_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Status | UpdateLabelResponse:
    if response.status_code == 200:
        response_200 = UpdateLabelResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)

    try:
        response_default = Status.from_dict(response.json())
    except ValueError:
        response_default = Status.from_dict({})

    return response_default


def _safe_http_status(code: int) -> int | HTTPStatus:
    try:
        return HTTPStatus(code)
    except ValueError:
        return code


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Status | UpdateLabelResponse]:
    return Response(
        status_code=_safe_http_status(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    label_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateLabelContent,
) -> Response[Status | UpdateLabelResponse]:
    """Update label

     Updates an existing label.

    Args:
        label_id (str):
        body (UpdateLabelContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Status | UpdateLabelResponse]
    """

    kwargs = _get_kwargs(
        label_id=label_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    label_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateLabelContent,
) -> Status | UpdateLabelResponse | None:
    """Update label

     Updates an existing label.

    Args:
        label_id (str):
        body (UpdateLabelContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Status | UpdateLabelResponse
    """

    return sync_detailed(
        label_id=label_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    label_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateLabelContent,
) -> Response[Status | UpdateLabelResponse]:
    """Update label

     Updates an existing label.

    Args:
        label_id (str):
        body (UpdateLabelContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Status | UpdateLabelResponse]
    """

    kwargs = _get_kwargs(
        label_id=label_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    label_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateLabelContent,
) -> Status | UpdateLabelResponse | None:
    """Update label

     Updates an existing label.

    Args:
        label_id (str):
        body (UpdateLabelContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Status | UpdateLabelResponse
    """

    return (
        await asyncio_detailed(
            label_id=label_id,
            client=client,
            body=body,
        )
    ).parsed
