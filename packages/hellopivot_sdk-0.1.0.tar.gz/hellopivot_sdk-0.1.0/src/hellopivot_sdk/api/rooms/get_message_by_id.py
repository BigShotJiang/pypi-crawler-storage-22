import datetime
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx
from dateutil.parser import isoparse

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_message_by_id_response import GetMessageByIdResponse
from ...models.status import Status
from ...types import UNSET, Response, Unset


def _get_kwargs(
    room_id: str,
    message_id: str,
    *,
    sent_at: datetime.datetime | Unset = UNSET,
    thread_parent_message_id: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_sent_at: str | Unset = UNSET
    if not isinstance(sent_at, Unset):
        json_sent_at = sent_at.isoformat()
    params["sentAt"] = json_sent_at

    params["threadParentMessageId"] = thread_parent_message_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/rooms/{room_id}/messages/{message_id}".format(
            room_id=quote(str(room_id), safe=""),
            message_id=quote(str(message_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetMessageByIdResponse | Status:
    if response.status_code == 200:
        response_200 = GetMessageByIdResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)

    try:
        response_default = Status.from_dict(response.json())
    except ValueError:
        response_default = Status.from_dict({})

    return response_default


def _safe_http_status(code: int) -> int | HTTPStatus:
    try:
        return HTTPStatus(code)
    except ValueError:
        return code


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetMessageByIdResponse | Status]:
    return Response(
        status_code=_safe_http_status(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    room_id: str,
    message_id: str,
    *,
    client: AuthenticatedClient | Client,
    sent_at: datetime.datetime | Unset = UNSET,
    thread_parent_message_id: str | Unset = UNSET,
) -> Response[GetMessageByIdResponse | Status]:
    """Get message by ID

     Retrieves a single message by ID.

    The `sent_at` parameter is currently optional but will become required in a future release. For
    thread messages, `thread_parent_message_id` will also become required. Clients should start passing
    these parameters now to ensure continued functionality after the migration.

    Args:
        room_id (str):
        message_id (str):
        sent_at (datetime.datetime | Unset):
        thread_parent_message_id (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetMessageByIdResponse | Status]
    """

    kwargs = _get_kwargs(
        room_id=room_id,
        message_id=message_id,
        sent_at=sent_at,
        thread_parent_message_id=thread_parent_message_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    room_id: str,
    message_id: str,
    *,
    client: AuthenticatedClient | Client,
    sent_at: datetime.datetime | Unset = UNSET,
    thread_parent_message_id: str | Unset = UNSET,
) -> GetMessageByIdResponse | Status | None:
    """Get message by ID

     Retrieves a single message by ID.

    The `sent_at` parameter is currently optional but will become required in a future release. For
    thread messages, `thread_parent_message_id` will also become required. Clients should start passing
    these parameters now to ensure continued functionality after the migration.

    Args:
        room_id (str):
        message_id (str):
        sent_at (datetime.datetime | Unset):
        thread_parent_message_id (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetMessageByIdResponse | Status
    """

    return sync_detailed(
        room_id=room_id,
        message_id=message_id,
        client=client,
        sent_at=sent_at,
        thread_parent_message_id=thread_parent_message_id,
    ).parsed


async def asyncio_detailed(
    room_id: str,
    message_id: str,
    *,
    client: AuthenticatedClient | Client,
    sent_at: datetime.datetime | Unset = UNSET,
    thread_parent_message_id: str | Unset = UNSET,
) -> Response[GetMessageByIdResponse | Status]:
    """Get message by ID

     Retrieves a single message by ID.

    The `sent_at` parameter is currently optional but will become required in a future release. For
    thread messages, `thread_parent_message_id` will also become required. Clients should start passing
    these parameters now to ensure continued functionality after the migration.

    Args:
        room_id (str):
        message_id (str):
        sent_at (datetime.datetime | Unset):
        thread_parent_message_id (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetMessageByIdResponse | Status]
    """

    kwargs = _get_kwargs(
        room_id=room_id,
        message_id=message_id,
        sent_at=sent_at,
        thread_parent_message_id=thread_parent_message_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    room_id: str,
    message_id: str,
    *,
    client: AuthenticatedClient | Client,
    sent_at: datetime.datetime | Unset = UNSET,
    thread_parent_message_id: str | Unset = UNSET,
) -> GetMessageByIdResponse | Status | None:
    """Get message by ID

     Retrieves a single message by ID.

    The `sent_at` parameter is currently optional but will become required in a future release. For
    thread messages, `thread_parent_message_id` will also become required. Clients should start passing
    these parameters now to ensure continued functionality after the migration.

    Args:
        room_id (str):
        message_id (str):
        sent_at (datetime.datetime | Unset):
        thread_parent_message_id (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetMessageByIdResponse | Status
    """

    return (
        await asyncio_detailed(
            room_id=room_id,
            message_id=message_id,
            client=client,
            sent_at=sent_at,
            thread_parent_message_id=thread_parent_message_id,
        )
    ).parsed
