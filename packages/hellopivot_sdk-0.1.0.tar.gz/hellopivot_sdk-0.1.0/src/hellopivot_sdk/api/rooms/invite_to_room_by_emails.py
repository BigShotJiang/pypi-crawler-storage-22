from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.invite_to_room_by_emails_content import InviteToRoomByEmailsContent
from ...models.invite_to_room_by_emails_response import InviteToRoomByEmailsResponse
from ...models.status import Status
from ...types import UNSET, Response


def _get_kwargs(
    room_id: str,
    *,
    body: InviteToRoomByEmailsContent,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/rooms/{room_id}/invites".format(
            room_id=quote(str(room_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> InviteToRoomByEmailsResponse | Status:
    if response.status_code == 200:
        response_200 = InviteToRoomByEmailsResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)

    try:
        response_default = Status.from_dict(response.json())
    except ValueError:
        response_default = Status.from_dict({})

    return response_default


def _safe_http_status(code: int) -> int | HTTPStatus:
    try:
        return HTTPStatus(code)
    except ValueError:
        return code


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[InviteToRoomByEmailsResponse | Status]:
    return Response(
        status_code=_safe_http_status(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    room_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: InviteToRoomByEmailsContent,
) -> Response[InviteToRoomByEmailsResponse | Status]:
    """Invite to room

     Invites users to a room by email.

    Args:
        room_id (str):
        body (InviteToRoomByEmailsContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[InviteToRoomByEmailsResponse | Status]
    """

    kwargs = _get_kwargs(
        room_id=room_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    room_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: InviteToRoomByEmailsContent,
) -> InviteToRoomByEmailsResponse | Status | None:
    """Invite to room

     Invites users to a room by email.

    Args:
        room_id (str):
        body (InviteToRoomByEmailsContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        InviteToRoomByEmailsResponse | Status
    """

    return sync_detailed(
        room_id=room_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    room_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: InviteToRoomByEmailsContent,
) -> Response[InviteToRoomByEmailsResponse | Status]:
    """Invite to room

     Invites users to a room by email.

    Args:
        room_id (str):
        body (InviteToRoomByEmailsContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[InviteToRoomByEmailsResponse | Status]
    """

    kwargs = _get_kwargs(
        room_id=room_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    room_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: InviteToRoomByEmailsContent,
) -> InviteToRoomByEmailsResponse | Status | None:
    """Invite to room

     Invites users to a room by email.

    Args:
        room_id (str):
        body (InviteToRoomByEmailsContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        InviteToRoomByEmailsResponse | Status
    """

    return (
        await asyncio_detailed(
            room_id=room_id,
            client=client,
            body=body,
        )
    ).parsed
