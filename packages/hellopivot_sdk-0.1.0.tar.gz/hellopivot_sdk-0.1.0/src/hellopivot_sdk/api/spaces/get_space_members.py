from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_space_members_response import GetSpaceMembersResponse
from ...models.status import Status
from ...types import UNSET, Response


def _get_kwargs(
    organization_id: str,
    space_id: str,
    offset: int,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/organizations/{organization_id}/spaces/{space_id}/members/{offset}".format(
            organization_id=quote(str(organization_id), safe=""),
            space_id=quote(str(space_id), safe=""),
            offset=quote(str(offset), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetSpaceMembersResponse | Status:
    if response.status_code == 200:
        response_200 = GetSpaceMembersResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)

    try:
        response_default = Status.from_dict(response.json())
    except ValueError:
        response_default = Status.from_dict({})

    return response_default


def _safe_http_status(code: int) -> int | HTTPStatus:
    try:
        return HTTPStatus(code)
    except ValueError:
        return code


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetSpaceMembersResponse | Status]:
    return Response(
        status_code=_safe_http_status(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    organization_id: str,
    space_id: str,
    offset: int,
    *,
    client: AuthenticatedClient | Client,
) -> Response[GetSpaceMembersResponse | Status]:
    """List space members

     Returns members of a space.

    Args:
        organization_id (str):
        space_id (str):
        offset (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetSpaceMembersResponse | Status]
    """

    kwargs = _get_kwargs(
        organization_id=organization_id,
        space_id=space_id,
        offset=offset,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    organization_id: str,
    space_id: str,
    offset: int,
    *,
    client: AuthenticatedClient | Client,
) -> GetSpaceMembersResponse | Status | None:
    """List space members

     Returns members of a space.

    Args:
        organization_id (str):
        space_id (str):
        offset (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetSpaceMembersResponse | Status
    """

    return sync_detailed(
        organization_id=organization_id,
        space_id=space_id,
        offset=offset,
        client=client,
    ).parsed


async def asyncio_detailed(
    organization_id: str,
    space_id: str,
    offset: int,
    *,
    client: AuthenticatedClient | Client,
) -> Response[GetSpaceMembersResponse | Status]:
    """List space members

     Returns members of a space.

    Args:
        organization_id (str):
        space_id (str):
        offset (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetSpaceMembersResponse | Status]
    """

    kwargs = _get_kwargs(
        organization_id=organization_id,
        space_id=space_id,
        offset=offset,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    organization_id: str,
    space_id: str,
    offset: int,
    *,
    client: AuthenticatedClient | Client,
) -> GetSpaceMembersResponse | Status | None:
    """List space members

     Returns members of a space.

    Args:
        organization_id (str):
        space_id (str):
        offset (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetSpaceMembersResponse | Status
    """

    return (
        await asyncio_detailed(
            organization_id=organization_id,
            space_id=space_id,
            offset=offset,
            client=client,
        )
    ).parsed
