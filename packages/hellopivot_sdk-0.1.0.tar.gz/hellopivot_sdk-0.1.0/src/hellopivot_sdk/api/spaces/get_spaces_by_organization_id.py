from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_spaces_by_organization_id_response import GetSpacesByOrganizationIdResponse
from ...models.get_spaces_by_organization_id_sort_by import GetSpacesByOrganizationIdSortBy
from ...models.get_spaces_by_organization_id_status import GetSpacesByOrganizationIdStatus
from ...models.status import Status
from ...types import UNSET, Response, Unset


def _get_kwargs(
    organization_id: str,
    offset: int,
    *,
    status: GetSpacesByOrganizationIdStatus | Unset = UNSET,
    sort_by: GetSpacesByOrganizationIdSortBy | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_status: str | Unset = UNSET
    if not isinstance(status, Unset):
        json_status = status.value

    params["status"] = json_status

    json_sort_by: str | Unset = UNSET
    if not isinstance(sort_by, Unset):
        json_sort_by = sort_by.value

    params["sortBy"] = json_sort_by

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/organizations/{organization_id}/spaces/{offset}".format(
            organization_id=quote(str(organization_id), safe=""),
            offset=quote(str(offset), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetSpacesByOrganizationIdResponse | Status:
    if response.status_code == 200:
        response_200 = GetSpacesByOrganizationIdResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)

    try:
        response_default = Status.from_dict(response.json())
    except ValueError:
        response_default = Status.from_dict({})

    return response_default


def _safe_http_status(code: int) -> int | HTTPStatus:
    try:
        return HTTPStatus(code)
    except ValueError:
        return code


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetSpacesByOrganizationIdResponse | Status]:
    return Response(
        status_code=_safe_http_status(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    organization_id: str,
    offset: int,
    *,
    client: AuthenticatedClient | Client,
    status: GetSpacesByOrganizationIdStatus | Unset = UNSET,
    sort_by: GetSpacesByOrganizationIdSortBy | Unset = UNSET,
) -> Response[GetSpacesByOrganizationIdResponse | Status]:
    """List spaces

     Returns spaces in the organization. Filter by status using 'active', 'archived', 'hidden', or
    'deleted'. If no status is provided, defaults to returning only active spaces. Sort results using
    sort_by: 'created_at_asc' (default), 'created_at_desc', 'last_activity_asc', or
    'last_activity_desc'.

    Args:
        organization_id (str):
        offset (int):
        status (GetSpacesByOrganizationIdStatus | Unset):
        sort_by (GetSpacesByOrganizationIdSortBy | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetSpacesByOrganizationIdResponse | Status]
    """

    kwargs = _get_kwargs(
        organization_id=organization_id,
        offset=offset,
        status=status,
        sort_by=sort_by,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    organization_id: str,
    offset: int,
    *,
    client: AuthenticatedClient | Client,
    status: GetSpacesByOrganizationIdStatus | Unset = UNSET,
    sort_by: GetSpacesByOrganizationIdSortBy | Unset = UNSET,
) -> GetSpacesByOrganizationIdResponse | Status | None:
    """List spaces

     Returns spaces in the organization. Filter by status using 'active', 'archived', 'hidden', or
    'deleted'. If no status is provided, defaults to returning only active spaces. Sort results using
    sort_by: 'created_at_asc' (default), 'created_at_desc', 'last_activity_asc', or
    'last_activity_desc'.

    Args:
        organization_id (str):
        offset (int):
        status (GetSpacesByOrganizationIdStatus | Unset):
        sort_by (GetSpacesByOrganizationIdSortBy | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetSpacesByOrganizationIdResponse | Status
    """

    return sync_detailed(
        organization_id=organization_id,
        offset=offset,
        client=client,
        status=status,
        sort_by=sort_by,
    ).parsed


async def asyncio_detailed(
    organization_id: str,
    offset: int,
    *,
    client: AuthenticatedClient | Client,
    status: GetSpacesByOrganizationIdStatus | Unset = UNSET,
    sort_by: GetSpacesByOrganizationIdSortBy | Unset = UNSET,
) -> Response[GetSpacesByOrganizationIdResponse | Status]:
    """List spaces

     Returns spaces in the organization. Filter by status using 'active', 'archived', 'hidden', or
    'deleted'. If no status is provided, defaults to returning only active spaces. Sort results using
    sort_by: 'created_at_asc' (default), 'created_at_desc', 'last_activity_asc', or
    'last_activity_desc'.

    Args:
        organization_id (str):
        offset (int):
        status (GetSpacesByOrganizationIdStatus | Unset):
        sort_by (GetSpacesByOrganizationIdSortBy | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetSpacesByOrganizationIdResponse | Status]
    """

    kwargs = _get_kwargs(
        organization_id=organization_id,
        offset=offset,
        status=status,
        sort_by=sort_by,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    organization_id: str,
    offset: int,
    *,
    client: AuthenticatedClient | Client,
    status: GetSpacesByOrganizationIdStatus | Unset = UNSET,
    sort_by: GetSpacesByOrganizationIdSortBy | Unset = UNSET,
) -> GetSpacesByOrganizationIdResponse | Status | None:
    """List spaces

     Returns spaces in the organization. Filter by status using 'active', 'archived', 'hidden', or
    'deleted'. If no status is provided, defaults to returning only active spaces. Sort results using
    sort_by: 'created_at_asc' (default), 'created_at_desc', 'last_activity_asc', or
    'last_activity_desc'.

    Args:
        organization_id (str):
        offset (int):
        status (GetSpacesByOrganizationIdStatus | Unset):
        sort_by (GetSpacesByOrganizationIdSortBy | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetSpacesByOrganizationIdResponse | Status
    """

    return (
        await asyncio_detailed(
            organization_id=organization_id,
            offset=offset,
            client=client,
            status=status,
            sort_by=sort_by,
        )
    ).parsed
