from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.status import Status
from ...models.update_space_content import UpdateSpaceContent
from ...models.update_space_response import UpdateSpaceResponse
from ...types import UNSET, Response


def _get_kwargs(
    organization_id: str,
    space_id: str,
    *,
    body: UpdateSpaceContent,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/v1/organizations/{organization_id}/spaces/{space_id}".format(
            organization_id=quote(str(organization_id), safe=""),
            space_id=quote(str(space_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Status | UpdateSpaceResponse:
    if response.status_code == 200:
        response_200 = UpdateSpaceResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)

    try:
        response_default = Status.from_dict(response.json())
    except ValueError:
        response_default = Status.from_dict({})

    return response_default


def _safe_http_status(code: int) -> int | HTTPStatus:
    try:
        return HTTPStatus(code)
    except ValueError:
        return code


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Status | UpdateSpaceResponse]:
    return Response(
        status_code=_safe_http_status(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    organization_id: str,
    space_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateSpaceContent,
) -> Response[Status | UpdateSpaceResponse]:
    """Update space

     Updates space settings or metadata.

    Args:
        organization_id (str):
        space_id (str):
        body (UpdateSpaceContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Status | UpdateSpaceResponse]
    """

    kwargs = _get_kwargs(
        organization_id=organization_id,
        space_id=space_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    organization_id: str,
    space_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateSpaceContent,
) -> Status | UpdateSpaceResponse | None:
    """Update space

     Updates space settings or metadata.

    Args:
        organization_id (str):
        space_id (str):
        body (UpdateSpaceContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Status | UpdateSpaceResponse
    """

    return sync_detailed(
        organization_id=organization_id,
        space_id=space_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    organization_id: str,
    space_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateSpaceContent,
) -> Response[Status | UpdateSpaceResponse]:
    """Update space

     Updates space settings or metadata.

    Args:
        organization_id (str):
        space_id (str):
        body (UpdateSpaceContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Status | UpdateSpaceResponse]
    """

    kwargs = _get_kwargs(
        organization_id=organization_id,
        space_id=space_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    organization_id: str,
    space_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateSpaceContent,
) -> Status | UpdateSpaceResponse | None:
    """Update space

     Updates space settings or metadata.

    Args:
        organization_id (str):
        space_id (str):
        body (UpdateSpaceContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Status | UpdateSpaceResponse
    """

    return (
        await asyncio_detailed(
            organization_id=organization_id,
            space_id=space_id,
            client=client,
            body=body,
        )
    ).parsed
