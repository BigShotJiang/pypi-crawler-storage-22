from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.delete_verified_user_or_remove_from_org_response import DeleteVerifiedUserOrRemoveFromOrgResponse
from ...models.status import Status
from ...types import UNSET, Response


def _get_kwargs(
    organization_id: str,
    user_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/v1/organizations/{organization_id}/users/{user_id}/membership".format(
            organization_id=quote(str(organization_id), safe=""),
            user_id=quote(str(user_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeleteVerifiedUserOrRemoveFromOrgResponse | Status:
    if response.status_code == 200:
        response_200 = DeleteVerifiedUserOrRemoveFromOrgResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)

    try:
        response_default = Status.from_dict(response.json())
    except ValueError:
        response_default = Status.from_dict({})

    return response_default


def _safe_http_status(code: int) -> int | HTTPStatus:
    try:
        return HTTPStatus(code)
    except ValueError:
        return code


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeleteVerifiedUserOrRemoveFromOrgResponse | Status]:
    return Response(
        status_code=_safe_http_status(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    organization_id: str,
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[DeleteVerifiedUserOrRemoveFromOrgResponse | Status]:
    """Delete or remove user

     Deletes the user if verified by the org; otherwise removes org memberships.

    Args:
        organization_id (str):
        user_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteVerifiedUserOrRemoveFromOrgResponse | Status]
    """

    kwargs = _get_kwargs(
        organization_id=organization_id,
        user_id=user_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    organization_id: str,
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> DeleteVerifiedUserOrRemoveFromOrgResponse | Status | None:
    """Delete or remove user

     Deletes the user if verified by the org; otherwise removes org memberships.

    Args:
        organization_id (str):
        user_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteVerifiedUserOrRemoveFromOrgResponse | Status
    """

    return sync_detailed(
        organization_id=organization_id,
        user_id=user_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    organization_id: str,
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[DeleteVerifiedUserOrRemoveFromOrgResponse | Status]:
    """Delete or remove user

     Deletes the user if verified by the org; otherwise removes org memberships.

    Args:
        organization_id (str):
        user_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteVerifiedUserOrRemoveFromOrgResponse | Status]
    """

    kwargs = _get_kwargs(
        organization_id=organization_id,
        user_id=user_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    organization_id: str,
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> DeleteVerifiedUserOrRemoveFromOrgResponse | Status | None:
    """Delete or remove user

     Deletes the user if verified by the org; otherwise removes org memberships.

    Args:
        organization_id (str):
        user_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteVerifiedUserOrRemoveFromOrgResponse | Status
    """

    return (
        await asyncio_detailed(
            organization_id=organization_id,
            user_id=user_id,
            client=client,
        )
    ).parsed
