from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.asset_type import AssetType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.transcript import Transcript


T = TypeVar("T", bound="Asset")


@_attrs_define
class Asset:
    """
    Attributes:
        id (str | Unset):
        reference_prefix (str | Unset):
        reference_id (str | Unset):
        type_ (AssetType | Unset):
        transcript (Transcript | Unset):
        created_at (datetime.datetime | Unset):
    """

    id: str | Unset = UNSET
    reference_prefix: str | Unset = UNSET
    reference_id: str | Unset = UNSET
    type_: AssetType | Unset = UNSET
    transcript: Transcript | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.transcript import Transcript

        id = self.id

        reference_prefix = self.reference_prefix

        reference_id = self.reference_id

        type_: str | Unset = UNSET
        if not isinstance(self.type_, Unset):
            type_ = self.type_.value

        transcript: dict[str, Any] | Unset = UNSET
        if not isinstance(self.transcript, Unset):
            transcript = self.transcript.to_dict()

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if reference_prefix is not UNSET:
            field_dict["referencePrefix"] = reference_prefix
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if type_ is not UNSET:
            field_dict["type"] = type_
        if transcript is not UNSET:
            field_dict["transcript"] = transcript
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.transcript import Transcript

        d = dict(src_dict)
        id = d.pop("id", UNSET)

        reference_prefix = d.pop("referencePrefix", UNSET)

        reference_id = d.pop("referenceId", UNSET)

        _type_ = d.pop("type", UNSET)
        type_: AssetType | Unset
        if isinstance(_type_, Unset):
            type_ = UNSET
        else:
            type_ = AssetType(_type_)

        _transcript = d.pop("transcript", UNSET)
        transcript: Transcript | Unset
        if isinstance(_transcript, Unset):
            transcript = UNSET
        else:
            transcript = Transcript.from_dict(_transcript)

        _created_at = d.pop("createdAt", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        asset = cls(
            id=id,
            reference_prefix=reference_prefix,
            reference_id=reference_id,
            type_=type_,
            transcript=transcript,
            created_at=created_at,
        )

        asset.additional_properties = d
        return asset

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
