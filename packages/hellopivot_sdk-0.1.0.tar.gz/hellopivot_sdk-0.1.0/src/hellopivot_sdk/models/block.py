from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.block_current_user_access_level import BlockCurrentUserAccessLevel
from ..models.block_default_layout import BlockDefaultLayout
from ..models.block_organization_sharing_level import BlockOrganizationSharingLevel
from ..models.block_public_sharing_level import BlockPublicSharingLevel
from ..models.block_space_member_sharing_level import BlockSpaceMemberSharingLevel
from ..models.block_template_type import BlockTemplateType
from ..models.block_type import BlockType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.block_ancestor import BlockAncestor
    from ..models.block_attachment import BlockAttachment
    from ..models.last_seen_info import LastSeenInfo


T = TypeVar("T", bound="Block")


@_attrs_define
class Block:
    """
    Attributes:
        id (str | Unset):
        description_space_id (str | Unset):
        home_space_id (str | Unset):
        attached_to_message_id (str | Unset):
        parent_block_id (str | Unset):
        type_ (BlockType | Unset):
        rich_content (str | Unset):
        icon (str | Unset):
        created_by (str | Unset):
        updated_by (str | Unset):
        v_order (float | Unset):
        h_order (float | Unset):
        hide_after (datetime.datetime | Unset):
        unhide_after (datetime.datetime | Unset):
        start_at (datetime.datetime | Unset):
        end_at (datetime.datetime | Unset):
        is_locked (bool | Unset):
        allow_responses_start (datetime.datetime | Unset):
        allow_responses_end (datetime.datetime | Unset):
        responses_are_editable (bool | Unset):
        url (str | Unset):
        default_layout (BlockDefaultLayout | Unset):
        template_type (BlockTemplateType | Unset):
        media_thumbnail_time (float | Unset):
        programming_language (str | Unset):
        override_display_number (bool | Unset):
        public_allow_duplicate_as_template (bool | Unset):
        public_link_expires_at (datetime.datetime | Unset):
        public_sharing_level (BlockPublicSharingLevel | Unset):
        organization_sharing_level (BlockOrganizationSharingLevel | Unset):
        space_member_sharing_level (BlockSpaceMemberSharingLevel | Unset):
        updated_at (datetime.datetime | Unset):
        created_at (datetime.datetime | Unset):
        deleted_at (datetime.datetime | Unset):
        deleted_by (str | Unset):
        jwt_token (str | Unset):
        pilot_token (str | Unset):
        corresponding_room_id (str | Unset):
        user_is_complete (bool | Unset): Block user data
        last_user_view_id (str | Unset):
        last_seen_info (list[LastSeenInfo] | Unset):
        content (str | Unset):
        ancestors (list[BlockAncestor] | Unset): ordered list of the ancestors of the block
        attachments (list[BlockAttachment] | Unset):
        current_user_access_level (BlockCurrentUserAccessLevel | Unset):
        rich_text_crdt_version (int | Unset):
    """

    id: str | Unset = UNSET
    description_space_id: str | Unset = UNSET
    home_space_id: str | Unset = UNSET
    attached_to_message_id: str | Unset = UNSET
    parent_block_id: str | Unset = UNSET
    type_: BlockType | Unset = UNSET
    rich_content: str | Unset = UNSET
    icon: str | Unset = UNSET
    created_by: str | Unset = UNSET
    updated_by: str | Unset = UNSET
    v_order: float | Unset = UNSET
    h_order: float | Unset = UNSET
    hide_after: datetime.datetime | Unset = UNSET
    unhide_after: datetime.datetime | Unset = UNSET
    start_at: datetime.datetime | Unset = UNSET
    end_at: datetime.datetime | Unset = UNSET
    is_locked: bool | Unset = UNSET
    allow_responses_start: datetime.datetime | Unset = UNSET
    allow_responses_end: datetime.datetime | Unset = UNSET
    responses_are_editable: bool | Unset = UNSET
    url: str | Unset = UNSET
    default_layout: BlockDefaultLayout | Unset = UNSET
    template_type: BlockTemplateType | Unset = UNSET
    media_thumbnail_time: float | Unset = UNSET
    programming_language: str | Unset = UNSET
    override_display_number: bool | Unset = UNSET
    public_allow_duplicate_as_template: bool | Unset = UNSET
    public_link_expires_at: datetime.datetime | Unset = UNSET
    public_sharing_level: BlockPublicSharingLevel | Unset = UNSET
    organization_sharing_level: BlockOrganizationSharingLevel | Unset = UNSET
    space_member_sharing_level: BlockSpaceMemberSharingLevel | Unset = UNSET
    updated_at: datetime.datetime | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    deleted_at: datetime.datetime | Unset = UNSET
    deleted_by: str | Unset = UNSET
    jwt_token: str | Unset = UNSET
    pilot_token: str | Unset = UNSET
    corresponding_room_id: str | Unset = UNSET
    user_is_complete: bool | Unset = UNSET
    last_user_view_id: str | Unset = UNSET
    last_seen_info: list[LastSeenInfo] | Unset = UNSET
    content: str | Unset = UNSET
    ancestors: list[BlockAncestor] | Unset = UNSET
    attachments: list[BlockAttachment] | Unset = UNSET
    current_user_access_level: BlockCurrentUserAccessLevel | Unset = UNSET
    rich_text_crdt_version: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.block_ancestor import BlockAncestor
        from ..models.block_attachment import BlockAttachment
        from ..models.last_seen_info import LastSeenInfo

        id = self.id

        description_space_id = self.description_space_id

        home_space_id = self.home_space_id

        attached_to_message_id = self.attached_to_message_id

        parent_block_id = self.parent_block_id

        type_: str | Unset = UNSET
        if not isinstance(self.type_, Unset):
            type_ = self.type_.value

        rich_content = self.rich_content

        icon = self.icon

        created_by = self.created_by

        updated_by = self.updated_by

        v_order = self.v_order

        h_order = self.h_order

        hide_after: str | Unset = UNSET
        if not isinstance(self.hide_after, Unset):
            hide_after = self.hide_after.isoformat()

        unhide_after: str | Unset = UNSET
        if not isinstance(self.unhide_after, Unset):
            unhide_after = self.unhide_after.isoformat()

        start_at: str | Unset = UNSET
        if not isinstance(self.start_at, Unset):
            start_at = self.start_at.isoformat()

        end_at: str | Unset = UNSET
        if not isinstance(self.end_at, Unset):
            end_at = self.end_at.isoformat()

        is_locked = self.is_locked

        allow_responses_start: str | Unset = UNSET
        if not isinstance(self.allow_responses_start, Unset):
            allow_responses_start = self.allow_responses_start.isoformat()

        allow_responses_end: str | Unset = UNSET
        if not isinstance(self.allow_responses_end, Unset):
            allow_responses_end = self.allow_responses_end.isoformat()

        responses_are_editable = self.responses_are_editable

        url = self.url

        default_layout: str | Unset = UNSET
        if not isinstance(self.default_layout, Unset):
            default_layout = self.default_layout.value

        template_type: str | Unset = UNSET
        if not isinstance(self.template_type, Unset):
            template_type = self.template_type.value

        media_thumbnail_time = self.media_thumbnail_time

        programming_language = self.programming_language

        override_display_number = self.override_display_number

        public_allow_duplicate_as_template = self.public_allow_duplicate_as_template

        public_link_expires_at: str | Unset = UNSET
        if not isinstance(self.public_link_expires_at, Unset):
            public_link_expires_at = self.public_link_expires_at.isoformat()

        public_sharing_level: str | Unset = UNSET
        if not isinstance(self.public_sharing_level, Unset):
            public_sharing_level = self.public_sharing_level.value

        organization_sharing_level: str | Unset = UNSET
        if not isinstance(self.organization_sharing_level, Unset):
            organization_sharing_level = self.organization_sharing_level.value

        space_member_sharing_level: str | Unset = UNSET
        if not isinstance(self.space_member_sharing_level, Unset):
            space_member_sharing_level = self.space_member_sharing_level.value

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        deleted_at: str | Unset = UNSET
        if not isinstance(self.deleted_at, Unset):
            deleted_at = self.deleted_at.isoformat()

        deleted_by = self.deleted_by

        jwt_token = self.jwt_token

        pilot_token = self.pilot_token

        corresponding_room_id = self.corresponding_room_id

        user_is_complete = self.user_is_complete

        last_user_view_id = self.last_user_view_id

        last_seen_info: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.last_seen_info, Unset):
            last_seen_info = []
            for last_seen_info_item_data in self.last_seen_info:
                last_seen_info_item = last_seen_info_item_data.to_dict()
                last_seen_info.append(last_seen_info_item)

        content = self.content

        ancestors: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.ancestors, Unset):
            ancestors = []
            for ancestors_item_data in self.ancestors:
                ancestors_item = ancestors_item_data.to_dict()
                ancestors.append(ancestors_item)

        attachments: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.attachments, Unset):
            attachments = []
            for attachments_item_data in self.attachments:
                attachments_item = attachments_item_data.to_dict()
                attachments.append(attachments_item)

        current_user_access_level: str | Unset = UNSET
        if not isinstance(self.current_user_access_level, Unset):
            current_user_access_level = self.current_user_access_level.value

        rich_text_crdt_version = self.rich_text_crdt_version

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if description_space_id is not UNSET:
            field_dict["descriptionSpaceId"] = description_space_id
        if home_space_id is not UNSET:
            field_dict["homeSpaceId"] = home_space_id
        if attached_to_message_id is not UNSET:
            field_dict["attachedToMessageId"] = attached_to_message_id
        if parent_block_id is not UNSET:
            field_dict["parentBlockId"] = parent_block_id
        if type_ is not UNSET:
            field_dict["type"] = type_
        if rich_content is not UNSET:
            field_dict["richContent"] = rich_content
        if icon is not UNSET:
            field_dict["icon"] = icon
        if created_by is not UNSET:
            field_dict["createdBy"] = created_by
        if updated_by is not UNSET:
            field_dict["updatedBy"] = updated_by
        if v_order is not UNSET:
            field_dict["vOrder"] = v_order
        if h_order is not UNSET:
            field_dict["hOrder"] = h_order
        if hide_after is not UNSET:
            field_dict["hideAfter"] = hide_after
        if unhide_after is not UNSET:
            field_dict["unhideAfter"] = unhide_after
        if start_at is not UNSET:
            field_dict["startAt"] = start_at
        if end_at is not UNSET:
            field_dict["endAt"] = end_at
        if is_locked is not UNSET:
            field_dict["isLocked"] = is_locked
        if allow_responses_start is not UNSET:
            field_dict["allowResponsesStart"] = allow_responses_start
        if allow_responses_end is not UNSET:
            field_dict["allowResponsesEnd"] = allow_responses_end
        if responses_are_editable is not UNSET:
            field_dict["responsesAreEditable"] = responses_are_editable
        if url is not UNSET:
            field_dict["url"] = url
        if default_layout is not UNSET:
            field_dict["defaultLayout"] = default_layout
        if template_type is not UNSET:
            field_dict["templateType"] = template_type
        if media_thumbnail_time is not UNSET:
            field_dict["mediaThumbnailTime"] = media_thumbnail_time
        if programming_language is not UNSET:
            field_dict["programmingLanguage"] = programming_language
        if override_display_number is not UNSET:
            field_dict["overrideDisplayNumber"] = override_display_number
        if public_allow_duplicate_as_template is not UNSET:
            field_dict["publicAllowDuplicateAsTemplate"] = public_allow_duplicate_as_template
        if public_link_expires_at is not UNSET:
            field_dict["publicLinkExpiresAt"] = public_link_expires_at
        if public_sharing_level is not UNSET:
            field_dict["publicSharingLevel"] = public_sharing_level
        if organization_sharing_level is not UNSET:
            field_dict["organizationSharingLevel"] = organization_sharing_level
        if space_member_sharing_level is not UNSET:
            field_dict["spaceMemberSharingLevel"] = space_member_sharing_level
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if deleted_at is not UNSET:
            field_dict["deletedAt"] = deleted_at
        if deleted_by is not UNSET:
            field_dict["deletedBy"] = deleted_by
        if jwt_token is not UNSET:
            field_dict["jwtToken"] = jwt_token
        if pilot_token is not UNSET:
            field_dict["pilotToken"] = pilot_token
        if corresponding_room_id is not UNSET:
            field_dict["correspondingRoomId"] = corresponding_room_id
        if user_is_complete is not UNSET:
            field_dict["userIsComplete"] = user_is_complete
        if last_user_view_id is not UNSET:
            field_dict["lastUserViewId"] = last_user_view_id
        if last_seen_info is not UNSET:
            field_dict["lastSeenInfo"] = last_seen_info
        if content is not UNSET:
            field_dict["content"] = content
        if ancestors is not UNSET:
            field_dict["ancestors"] = ancestors
        if attachments is not UNSET:
            field_dict["attachments"] = attachments
        if current_user_access_level is not UNSET:
            field_dict["currentUserAccessLevel"] = current_user_access_level
        if rich_text_crdt_version is not UNSET:
            field_dict["richTextCrdtVersion"] = rich_text_crdt_version

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.block_ancestor import BlockAncestor
        from ..models.block_attachment import BlockAttachment
        from ..models.last_seen_info import LastSeenInfo

        d = dict(src_dict)
        id = d.pop("id", UNSET)

        description_space_id = d.pop("descriptionSpaceId", UNSET)

        home_space_id = d.pop("homeSpaceId", UNSET)

        attached_to_message_id = d.pop("attachedToMessageId", UNSET)

        parent_block_id = d.pop("parentBlockId", UNSET)

        _type_ = d.pop("type", UNSET)
        type_: BlockType | Unset
        if isinstance(_type_, Unset):
            type_ = UNSET
        else:
            type_ = BlockType(_type_)

        rich_content = d.pop("richContent", UNSET)

        icon = d.pop("icon", UNSET)

        created_by = d.pop("createdBy", UNSET)

        updated_by = d.pop("updatedBy", UNSET)

        v_order = d.pop("vOrder", UNSET)

        h_order = d.pop("hOrder", UNSET)

        _hide_after = d.pop("hideAfter", UNSET)
        hide_after: datetime.datetime | Unset
        if isinstance(_hide_after, Unset):
            hide_after = UNSET
        else:
            hide_after = isoparse(_hide_after)

        _unhide_after = d.pop("unhideAfter", UNSET)
        unhide_after: datetime.datetime | Unset
        if isinstance(_unhide_after, Unset):
            unhide_after = UNSET
        else:
            unhide_after = isoparse(_unhide_after)

        _start_at = d.pop("startAt", UNSET)
        start_at: datetime.datetime | Unset
        if isinstance(_start_at, Unset):
            start_at = UNSET
        else:
            start_at = isoparse(_start_at)

        _end_at = d.pop("endAt", UNSET)
        end_at: datetime.datetime | Unset
        if isinstance(_end_at, Unset):
            end_at = UNSET
        else:
            end_at = isoparse(_end_at)

        is_locked = d.pop("isLocked", UNSET)

        _allow_responses_start = d.pop("allowResponsesStart", UNSET)
        allow_responses_start: datetime.datetime | Unset
        if isinstance(_allow_responses_start, Unset):
            allow_responses_start = UNSET
        else:
            allow_responses_start = isoparse(_allow_responses_start)

        _allow_responses_end = d.pop("allowResponsesEnd", UNSET)
        allow_responses_end: datetime.datetime | Unset
        if isinstance(_allow_responses_end, Unset):
            allow_responses_end = UNSET
        else:
            allow_responses_end = isoparse(_allow_responses_end)

        responses_are_editable = d.pop("responsesAreEditable", UNSET)

        url = d.pop("url", UNSET)

        _default_layout = d.pop("defaultLayout", UNSET)
        default_layout: BlockDefaultLayout | Unset
        if isinstance(_default_layout, Unset):
            default_layout = UNSET
        else:
            default_layout = BlockDefaultLayout(_default_layout)

        _template_type = d.pop("templateType", UNSET)
        template_type: BlockTemplateType | Unset
        if isinstance(_template_type, Unset):
            template_type = UNSET
        else:
            template_type = BlockTemplateType(_template_type)

        media_thumbnail_time = d.pop("mediaThumbnailTime", UNSET)

        programming_language = d.pop("programmingLanguage", UNSET)

        override_display_number = d.pop("overrideDisplayNumber", UNSET)

        public_allow_duplicate_as_template = d.pop("publicAllowDuplicateAsTemplate", UNSET)

        _public_link_expires_at = d.pop("publicLinkExpiresAt", UNSET)
        public_link_expires_at: datetime.datetime | Unset
        if isinstance(_public_link_expires_at, Unset):
            public_link_expires_at = UNSET
        else:
            public_link_expires_at = isoparse(_public_link_expires_at)

        _public_sharing_level = d.pop("publicSharingLevel", UNSET)
        public_sharing_level: BlockPublicSharingLevel | Unset
        if isinstance(_public_sharing_level, Unset):
            public_sharing_level = UNSET
        else:
            public_sharing_level = BlockPublicSharingLevel(_public_sharing_level)

        _organization_sharing_level = d.pop("organizationSharingLevel", UNSET)
        organization_sharing_level: BlockOrganizationSharingLevel | Unset
        if isinstance(_organization_sharing_level, Unset):
            organization_sharing_level = UNSET
        else:
            organization_sharing_level = BlockOrganizationSharingLevel(_organization_sharing_level)

        _space_member_sharing_level = d.pop("spaceMemberSharingLevel", UNSET)
        space_member_sharing_level: BlockSpaceMemberSharingLevel | Unset
        if isinstance(_space_member_sharing_level, Unset):
            space_member_sharing_level = UNSET
        else:
            space_member_sharing_level = BlockSpaceMemberSharingLevel(_space_member_sharing_level)

        _updated_at = d.pop("updatedAt", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)

        _created_at = d.pop("createdAt", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        _deleted_at = d.pop("deletedAt", UNSET)
        deleted_at: datetime.datetime | Unset
        if isinstance(_deleted_at, Unset):
            deleted_at = UNSET
        else:
            deleted_at = isoparse(_deleted_at)

        deleted_by = d.pop("deletedBy", UNSET)

        jwt_token = d.pop("jwtToken", UNSET)

        pilot_token = d.pop("pilotToken", UNSET)

        corresponding_room_id = d.pop("correspondingRoomId", UNSET)

        user_is_complete = d.pop("userIsComplete", UNSET)

        last_user_view_id = d.pop("lastUserViewId", UNSET)

        _last_seen_info = d.pop("lastSeenInfo", UNSET)
        last_seen_info: list[LastSeenInfo] | Unset = UNSET
        if _last_seen_info is not UNSET:
            last_seen_info = []
            for last_seen_info_item_data in _last_seen_info:
                last_seen_info_item = LastSeenInfo.from_dict(last_seen_info_item_data)

                last_seen_info.append(last_seen_info_item)

        content = d.pop("content", UNSET)

        _ancestors = d.pop("ancestors", UNSET)
        ancestors: list[BlockAncestor] | Unset = UNSET
        if _ancestors is not UNSET:
            ancestors = []
            for ancestors_item_data in _ancestors:
                ancestors_item = BlockAncestor.from_dict(ancestors_item_data)

                ancestors.append(ancestors_item)

        _attachments = d.pop("attachments", UNSET)
        attachments: list[BlockAttachment] | Unset = UNSET
        if _attachments is not UNSET:
            attachments = []
            for attachments_item_data in _attachments:
                attachments_item = BlockAttachment.from_dict(attachments_item_data)

                attachments.append(attachments_item)

        _current_user_access_level = d.pop("currentUserAccessLevel", UNSET)
        current_user_access_level: BlockCurrentUserAccessLevel | Unset
        if isinstance(_current_user_access_level, Unset):
            current_user_access_level = UNSET
        else:
            current_user_access_level = BlockCurrentUserAccessLevel(_current_user_access_level)

        rich_text_crdt_version = d.pop("richTextCrdtVersion", UNSET)

        block = cls(
            id=id,
            description_space_id=description_space_id,
            home_space_id=home_space_id,
            attached_to_message_id=attached_to_message_id,
            parent_block_id=parent_block_id,
            type_=type_,
            rich_content=rich_content,
            icon=icon,
            created_by=created_by,
            updated_by=updated_by,
            v_order=v_order,
            h_order=h_order,
            hide_after=hide_after,
            unhide_after=unhide_after,
            start_at=start_at,
            end_at=end_at,
            is_locked=is_locked,
            allow_responses_start=allow_responses_start,
            allow_responses_end=allow_responses_end,
            responses_are_editable=responses_are_editable,
            url=url,
            default_layout=default_layout,
            template_type=template_type,
            media_thumbnail_time=media_thumbnail_time,
            programming_language=programming_language,
            override_display_number=override_display_number,
            public_allow_duplicate_as_template=public_allow_duplicate_as_template,
            public_link_expires_at=public_link_expires_at,
            public_sharing_level=public_sharing_level,
            organization_sharing_level=organization_sharing_level,
            space_member_sharing_level=space_member_sharing_level,
            updated_at=updated_at,
            created_at=created_at,
            deleted_at=deleted_at,
            deleted_by=deleted_by,
            jwt_token=jwt_token,
            pilot_token=pilot_token,
            corresponding_room_id=corresponding_room_id,
            user_is_complete=user_is_complete,
            last_user_view_id=last_user_view_id,
            last_seen_info=last_seen_info,
            content=content,
            ancestors=ancestors,
            attachments=attachments,
            current_user_access_level=current_user_access_level,
            rich_text_crdt_version=rich_text_crdt_version,
        )

        block.additional_properties = d
        return block

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
