from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.block_response_status import BlockResponseStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.block_response_attachment import BlockResponseAttachment
    from ..models.block_response_reaction import BlockResponseReaction
    from ..models.rich_content import RichContent


T = TypeVar("T", bound="BlockResponse")


@_attrs_define
class BlockResponse:
    """
    Attributes:
        id (str | Unset):
        block_id (str | Unset):
        parent_block_response_id (str | Unset):
        rich_content (RichContent | Unset):
        created_at (datetime.datetime | Unset):
        updated_at (datetime.datetime | Unset):
        status (BlockResponseStatus | Unset):
        created_by (str | Unset):
        attachments (list[BlockResponseAttachment] | Unset):
        reactions (list[BlockResponseReaction] | Unset):
    """

    id: str | Unset = UNSET
    block_id: str | Unset = UNSET
    parent_block_response_id: str | Unset = UNSET
    rich_content: RichContent | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    updated_at: datetime.datetime | Unset = UNSET
    status: BlockResponseStatus | Unset = UNSET
    created_by: str | Unset = UNSET
    attachments: list[BlockResponseAttachment] | Unset = UNSET
    reactions: list[BlockResponseReaction] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.block_response_attachment import BlockResponseAttachment
        from ..models.block_response_reaction import BlockResponseReaction
        from ..models.rich_content import RichContent

        id = self.id

        block_id = self.block_id

        parent_block_response_id = self.parent_block_response_id

        rich_content: dict[str, Any] | Unset = UNSET
        if not isinstance(self.rich_content, Unset):
            rich_content = self.rich_content.to_dict()

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        created_by = self.created_by

        attachments: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.attachments, Unset):
            attachments = []
            for attachments_item_data in self.attachments:
                attachments_item = attachments_item_data.to_dict()
                attachments.append(attachments_item)

        reactions: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.reactions, Unset):
            reactions = []
            for reactions_item_data in self.reactions:
                reactions_item = reactions_item_data.to_dict()
                reactions.append(reactions_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if block_id is not UNSET:
            field_dict["blockId"] = block_id
        if parent_block_response_id is not UNSET:
            field_dict["parentBlockResponseId"] = parent_block_response_id
        if rich_content is not UNSET:
            field_dict["richContent"] = rich_content
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at
        if status is not UNSET:
            field_dict["status"] = status
        if created_by is not UNSET:
            field_dict["createdBy"] = created_by
        if attachments is not UNSET:
            field_dict["attachments"] = attachments
        if reactions is not UNSET:
            field_dict["reactions"] = reactions

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.block_response_attachment import BlockResponseAttachment
        from ..models.block_response_reaction import BlockResponseReaction
        from ..models.rich_content import RichContent

        d = dict(src_dict)
        id = d.pop("id", UNSET)

        block_id = d.pop("blockId", UNSET)

        parent_block_response_id = d.pop("parentBlockResponseId", UNSET)

        _rich_content = d.pop("richContent", UNSET)
        rich_content: RichContent | Unset
        if isinstance(_rich_content, Unset):
            rich_content = UNSET
        else:
            rich_content = RichContent.from_dict(_rich_content)

        _created_at = d.pop("createdAt", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        _updated_at = d.pop("updatedAt", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)

        _status = d.pop("status", UNSET)
        status: BlockResponseStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = BlockResponseStatus(_status)

        created_by = d.pop("createdBy", UNSET)

        _attachments = d.pop("attachments", UNSET)
        attachments: list[BlockResponseAttachment] | Unset = UNSET
        if _attachments is not UNSET:
            attachments = []
            for attachments_item_data in _attachments:
                attachments_item = BlockResponseAttachment.from_dict(attachments_item_data)

                attachments.append(attachments_item)

        _reactions = d.pop("reactions", UNSET)
        reactions: list[BlockResponseReaction] | Unset = UNSET
        if _reactions is not UNSET:
            reactions = []
            for reactions_item_data in _reactions:
                reactions_item = BlockResponseReaction.from_dict(reactions_item_data)

                reactions.append(reactions_item)

        block_response = cls(
            id=id,
            block_id=block_id,
            parent_block_response_id=parent_block_response_id,
            rich_content=rich_content,
            created_at=created_at,
            updated_at=updated_at,
            status=status,
            created_by=created_by,
            attachments=attachments,
            reactions=reactions,
        )

        block_response.additional_properties = d
        return block_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
