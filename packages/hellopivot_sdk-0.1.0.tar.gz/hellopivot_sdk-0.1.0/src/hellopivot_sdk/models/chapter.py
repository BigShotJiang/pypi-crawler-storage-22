from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="Chapter")


@_attrs_define
class Chapter:
    """
    Attributes:
        gist (str | Unset):
        start (float | Unset):
        end (float | Unset):
        headline (str | Unset):
        summary (str | Unset):
    """

    gist: str | Unset = UNSET
    start: float | Unset = UNSET
    end: float | Unset = UNSET
    headline: str | Unset = UNSET
    summary: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        gist = self.gist

        start = self.start

        end = self.end

        headline = self.headline

        summary = self.summary

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if gist is not UNSET:
            field_dict["gist"] = gist
        if start is not UNSET:
            field_dict["start"] = start
        if end is not UNSET:
            field_dict["end"] = end
        if headline is not UNSET:
            field_dict["headline"] = headline
        if summary is not UNSET:
            field_dict["summary"] = summary

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        gist = d.pop("gist", UNSET)

        start = d.pop("start", UNSET)

        end = d.pop("end", UNSET)

        headline = d.pop("headline", UNSET)

        summary = d.pop("summary", UNSET)

        chapter = cls(
            gist=gist,
            start=start,
            end=end,
            headline=headline,
            summary=summary,
        )

        chapter.additional_properties = d
        return chapter

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
