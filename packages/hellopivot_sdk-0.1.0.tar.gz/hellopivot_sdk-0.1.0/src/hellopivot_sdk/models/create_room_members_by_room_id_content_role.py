from enum import Enum


class CreateRoomMembersByRoomIdContentRole(str, Enum):
    ROOM_ROLE_HOST = "ROOM_ROLE_HOST"
    ROOM_ROLE_PARTICIPANT = "ROOM_ROLE_PARTICIPANT"
    ROOM_ROLE_UNSPECIFIED = "ROOM_ROLE_UNSPECIFIED"

    def __str__(self) -> str:
        return str(self.value)
