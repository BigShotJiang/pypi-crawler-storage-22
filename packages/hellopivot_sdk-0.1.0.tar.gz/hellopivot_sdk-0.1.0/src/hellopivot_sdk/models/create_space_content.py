from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.create_space_content_link_sharing import CreateSpaceContentLinkSharing
from ..models.create_space_content_organization_sharing import CreateSpaceContentOrganizationSharing
from ..models.create_space_content_public_sharing import CreateSpaceContentPublicSharing
from ..models.create_space_content_type import CreateSpaceContentType
from ..types import UNSET, Unset

T = TypeVar("T", bound="CreateSpaceContent")


@_attrs_define
class CreateSpaceContent:
    """
    Attributes:
        name (str):
        type_ (CreateSpaceContentType):
        other_type_name (str | Unset):
        organization_sharing (CreateSpaceContentOrganizationSharing | Unset):
        link_sharing (CreateSpaceContentLinkSharing | Unset):
        public_sharing (CreateSpaceContentPublicSharing | Unset):
        tags (list[str] | Unset):
        template_type (str | Unset):
        icon_name (str | Unset):
        enable_progress_tracking (bool | Unset):
        only_allow_existing_organization_members (bool | Unset):
        allow_block_sharing_organization_members (bool | Unset):
        allow_block_sharing_public (bool | Unset):
        allow_block_sharing_users (bool | Unset):
    """

    name: str
    type_: CreateSpaceContentType
    other_type_name: str | Unset = UNSET
    organization_sharing: CreateSpaceContentOrganizationSharing | Unset = UNSET
    link_sharing: CreateSpaceContentLinkSharing | Unset = UNSET
    public_sharing: CreateSpaceContentPublicSharing | Unset = UNSET
    tags: list[str] | Unset = UNSET
    template_type: str | Unset = UNSET
    icon_name: str | Unset = UNSET
    enable_progress_tracking: bool | Unset = UNSET
    only_allow_existing_organization_members: bool | Unset = UNSET
    allow_block_sharing_organization_members: bool | Unset = UNSET
    allow_block_sharing_public: bool | Unset = UNSET
    allow_block_sharing_users: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        type_ = self.type_.value

        other_type_name = self.other_type_name

        organization_sharing: str | Unset = UNSET
        if not isinstance(self.organization_sharing, Unset):
            organization_sharing = self.organization_sharing.value

        link_sharing: str | Unset = UNSET
        if not isinstance(self.link_sharing, Unset):
            link_sharing = self.link_sharing.value

        public_sharing: str | Unset = UNSET
        if not isinstance(self.public_sharing, Unset):
            public_sharing = self.public_sharing.value

        tags: list[str] | Unset = UNSET
        if not isinstance(self.tags, Unset):
            tags = self.tags

        template_type = self.template_type

        icon_name = self.icon_name

        enable_progress_tracking = self.enable_progress_tracking

        only_allow_existing_organization_members = self.only_allow_existing_organization_members

        allow_block_sharing_organization_members = self.allow_block_sharing_organization_members

        allow_block_sharing_public = self.allow_block_sharing_public

        allow_block_sharing_users = self.allow_block_sharing_users

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "type": type_,
            }
        )
        if other_type_name is not UNSET:
            field_dict["otherTypeName"] = other_type_name
        if organization_sharing is not UNSET:
            field_dict["organizationSharing"] = organization_sharing
        if link_sharing is not UNSET:
            field_dict["linkSharing"] = link_sharing
        if public_sharing is not UNSET:
            field_dict["publicSharing"] = public_sharing
        if tags is not UNSET:
            field_dict["tags"] = tags
        if template_type is not UNSET:
            field_dict["templateType"] = template_type
        if icon_name is not UNSET:
            field_dict["iconName"] = icon_name
        if enable_progress_tracking is not UNSET:
            field_dict["enableProgressTracking"] = enable_progress_tracking
        if only_allow_existing_organization_members is not UNSET:
            field_dict["onlyAllowExistingOrganizationMembers"] = only_allow_existing_organization_members
        if allow_block_sharing_organization_members is not UNSET:
            field_dict["allowBlockSharingOrganizationMembers"] = allow_block_sharing_organization_members
        if allow_block_sharing_public is not UNSET:
            field_dict["allowBlockSharingPublic"] = allow_block_sharing_public
        if allow_block_sharing_users is not UNSET:
            field_dict["allowBlockSharingUsers"] = allow_block_sharing_users

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        type_ = CreateSpaceContentType(d.pop("type"))

        other_type_name = d.pop("otherTypeName", UNSET)

        _organization_sharing = d.pop("organizationSharing", UNSET)
        organization_sharing: CreateSpaceContentOrganizationSharing | Unset
        if isinstance(_organization_sharing, Unset):
            organization_sharing = UNSET
        else:
            organization_sharing = CreateSpaceContentOrganizationSharing(_organization_sharing)

        _link_sharing = d.pop("linkSharing", UNSET)
        link_sharing: CreateSpaceContentLinkSharing | Unset
        if isinstance(_link_sharing, Unset):
            link_sharing = UNSET
        else:
            link_sharing = CreateSpaceContentLinkSharing(_link_sharing)

        _public_sharing = d.pop("publicSharing", UNSET)
        public_sharing: CreateSpaceContentPublicSharing | Unset
        if isinstance(_public_sharing, Unset):
            public_sharing = UNSET
        else:
            public_sharing = CreateSpaceContentPublicSharing(_public_sharing)

        _tags = d.pop("tags", UNSET)
        tags: list[str] | Unset
        if isinstance(_tags, Unset):
            tags = UNSET
        else:
            tags = cast(list[str], _tags)

        template_type = d.pop("templateType", UNSET)

        icon_name = d.pop("iconName", UNSET)

        enable_progress_tracking = d.pop("enableProgressTracking", UNSET)

        only_allow_existing_organization_members = d.pop("onlyAllowExistingOrganizationMembers", UNSET)

        allow_block_sharing_organization_members = d.pop("allowBlockSharingOrganizationMembers", UNSET)

        allow_block_sharing_public = d.pop("allowBlockSharingPublic", UNSET)

        allow_block_sharing_users = d.pop("allowBlockSharingUsers", UNSET)

        create_space_content = cls(
            name=name,
            type_=type_,
            other_type_name=other_type_name,
            organization_sharing=organization_sharing,
            link_sharing=link_sharing,
            public_sharing=public_sharing,
            tags=tags,
            template_type=template_type,
            icon_name=icon_name,
            enable_progress_tracking=enable_progress_tracking,
            only_allow_existing_organization_members=only_allow_existing_organization_members,
            allow_block_sharing_organization_members=allow_block_sharing_organization_members,
            allow_block_sharing_public=allow_block_sharing_public,
            allow_block_sharing_users=allow_block_sharing_users,
        )

        create_space_content.additional_properties = d
        return create_space_content

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
