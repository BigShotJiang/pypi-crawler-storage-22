from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.create_space_role_content_permissions_item import CreateSpaceRoleContentPermissionsItem
from ..models.create_space_role_content_type import CreateSpaceRoleContentType
from ..types import UNSET, Unset

T = TypeVar("T", bound="CreateSpaceRoleContent")


@_attrs_define
class CreateSpaceRoleContent:
    """
    Attributes:
        name (str):
        permissions (list[CreateSpaceRoleContentPermissionsItem]):
        type_ (CreateSpaceRoleContentType | Unset):
    """

    name: str
    permissions: list[CreateSpaceRoleContentPermissionsItem]
    type_: CreateSpaceRoleContentType | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        permissions = []
        for permissions_item_data in self.permissions:
            permissions_item = permissions_item_data.value
            permissions.append(permissions_item)

        type_: str | Unset = UNSET
        if not isinstance(self.type_, Unset):
            type_ = self.type_.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "permissions": permissions,
            }
        )
        if type_ is not UNSET:
            field_dict["type"] = type_

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        permissions = []
        _permissions = d.pop("permissions")
        for permissions_item_data in _permissions:
            permissions_item = CreateSpaceRoleContentPermissionsItem(permissions_item_data)

            permissions.append(permissions_item)

        _type_ = d.pop("type", UNSET)
        type_: CreateSpaceRoleContentType | Unset
        if isinstance(_type_, Unset):
            type_ = UNSET
        else:
            type_ = CreateSpaceRoleContentType(_type_)

        create_space_role_content = cls(
            name=name,
            permissions=permissions,
            type_=type_,
        )

        create_space_role_content.additional_properties = d
        return create_space_role_content

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
