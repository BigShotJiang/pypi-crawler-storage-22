from enum import Enum


class CustomWebViewStatus(str, Enum):
    CUSTOM_WEB_VIEW_STATUS_ACTIVE = "CUSTOM_WEB_VIEW_STATUS_ACTIVE"
    CUSTOM_WEB_VIEW_STATUS_DELETED = "CUSTOM_WEB_VIEW_STATUS_DELETED"
    CUSTOM_WEB_VIEW_STATUS_UNSPECIFIED = "CUSTOM_WEB_VIEW_STATUS_UNSPECIFIED"

    def __str__(self) -> str:
        return str(self.value)
