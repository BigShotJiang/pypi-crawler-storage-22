from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.block import Block


T = TypeVar("T", bound="GetBlockByIdResponse")


@_attrs_define
class GetBlockByIdResponse:
    """
    Attributes:
        block (Block | Unset):
    """

    block: Block | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.block import Block

        block: dict[str, Any] | Unset = UNSET
        if not isinstance(self.block, Unset):
            block = self.block.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if block is not UNSET:
            field_dict["block"] = block

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.block import Block

        d = dict(src_dict)
        _block = d.pop("block", UNSET)
        block: Block | Unset
        if isinstance(_block, Unset):
            block = UNSET
        else:
            block = Block.from_dict(_block)

        get_block_by_id_response = cls(
            block=block,
        )

        get_block_by_id_response.additional_properties = d
        return get_block_by_id_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
