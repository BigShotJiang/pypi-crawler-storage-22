from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.room_recording import RoomRecording


T = TypeVar("T", bound="GetRoomRecordingByIdResponse")


@_attrs_define
class GetRoomRecordingByIdResponse:
    """
    Attributes:
        room_recording (RoomRecording | Unset):
    """

    room_recording: RoomRecording | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.room_recording import RoomRecording

        room_recording: dict[str, Any] | Unset = UNSET
        if not isinstance(self.room_recording, Unset):
            room_recording = self.room_recording.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if room_recording is not UNSET:
            field_dict["roomRecording"] = room_recording

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.room_recording import RoomRecording

        d = dict(src_dict)
        _room_recording = d.pop("roomRecording", UNSET)
        room_recording: RoomRecording | Unset
        if isinstance(_room_recording, Unset):
            room_recording = UNSET
        else:
            room_recording = RoomRecording.from_dict(_room_recording)

        get_room_recording_by_id_response = cls(
            room_recording=room_recording,
        )

        get_room_recording_by_id_response.additional_properties = d
        return get_room_recording_by_id_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
