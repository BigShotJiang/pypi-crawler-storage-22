from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.room_recording import RoomRecording


T = TypeVar("T", bound="GetRoomRecordingsByRoomIdResponse")


@_attrs_define
class GetRoomRecordingsByRoomIdResponse:
    """
    Attributes:
        room_recordings (list[RoomRecording] | Unset):
        next_cursor_created_at (datetime.datetime | Unset):
        next_cursor_id (str | Unset):
        has_more (bool | Unset):
    """

    room_recordings: list[RoomRecording] | Unset = UNSET
    next_cursor_created_at: datetime.datetime | Unset = UNSET
    next_cursor_id: str | Unset = UNSET
    has_more: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.room_recording import RoomRecording

        room_recordings: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.room_recordings, Unset):
            room_recordings = []
            for room_recordings_item_data in self.room_recordings:
                room_recordings_item = room_recordings_item_data.to_dict()
                room_recordings.append(room_recordings_item)

        next_cursor_created_at: str | Unset = UNSET
        if not isinstance(self.next_cursor_created_at, Unset):
            next_cursor_created_at = self.next_cursor_created_at.isoformat()

        next_cursor_id = self.next_cursor_id

        has_more = self.has_more

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if room_recordings is not UNSET:
            field_dict["roomRecordings"] = room_recordings
        if next_cursor_created_at is not UNSET:
            field_dict["nextCursorCreatedAt"] = next_cursor_created_at
        if next_cursor_id is not UNSET:
            field_dict["nextCursorId"] = next_cursor_id
        if has_more is not UNSET:
            field_dict["hasMore"] = has_more

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.room_recording import RoomRecording

        d = dict(src_dict)
        _room_recordings = d.pop("roomRecordings", UNSET)
        room_recordings: list[RoomRecording] | Unset = UNSET
        if _room_recordings is not UNSET:
            room_recordings = []
            for room_recordings_item_data in _room_recordings:
                room_recordings_item = RoomRecording.from_dict(room_recordings_item_data)

                room_recordings.append(room_recordings_item)

        _next_cursor_created_at = d.pop("nextCursorCreatedAt", UNSET)
        next_cursor_created_at: datetime.datetime | Unset
        if isinstance(_next_cursor_created_at, Unset):
            next_cursor_created_at = UNSET
        else:
            next_cursor_created_at = isoparse(_next_cursor_created_at)

        next_cursor_id = d.pop("nextCursorId", UNSET)

        has_more = d.pop("hasMore", UNSET)

        get_room_recordings_by_room_id_response = cls(
            room_recordings=room_recordings,
            next_cursor_created_at=next_cursor_created_at,
            next_cursor_id=next_cursor_id,
            has_more=has_more,
        )

        get_room_recordings_by_room_id_response.additional_properties = d
        return get_room_recordings_by_room_id_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
