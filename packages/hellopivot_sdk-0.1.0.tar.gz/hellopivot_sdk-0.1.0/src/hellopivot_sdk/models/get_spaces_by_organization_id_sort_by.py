from enum import Enum


class GetSpacesByOrganizationIdSortBy(str, Enum):
    CREATED_AT_ASC = "created_at_asc"
    CREATED_AT_DESC = "created_at_desc"
    LAST_ACTIVITY_ASC = "last_activity_asc"
    LAST_ACTIVITY_DESC = "last_activity_desc"

    def __str__(self) -> str:
        return str(self.value)
