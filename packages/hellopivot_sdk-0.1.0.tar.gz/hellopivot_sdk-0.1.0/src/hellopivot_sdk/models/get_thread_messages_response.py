from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.message import Message


T = TypeVar("T", bound="GetThreadMessagesResponse")


@_attrs_define
class GetThreadMessagesResponse:
    """
    Attributes:
        messages (list[Message] | Unset):
        next_cursor_sent_at (datetime.datetime | Unset): Cursor for next page. Only populated when has_more is true.
             Pass these values as cursor_sent_at and cursor_message_id in the next request.
        next_cursor_message_id (str | Unset):
        has_more (bool | Unset): True if there are more messages available in this thread. When false, all thread
            messages
             have been retrieved. Unlike room messages, threads exist on a single partition, so there
             is no shard-awareness needed.
    """

    messages: list[Message] | Unset = UNSET
    next_cursor_sent_at: datetime.datetime | Unset = UNSET
    next_cursor_message_id: str | Unset = UNSET
    has_more: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.message import Message

        messages: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.messages, Unset):
            messages = []
            for messages_item_data in self.messages:
                messages_item = messages_item_data.to_dict()
                messages.append(messages_item)

        next_cursor_sent_at: str | Unset = UNSET
        if not isinstance(self.next_cursor_sent_at, Unset):
            next_cursor_sent_at = self.next_cursor_sent_at.isoformat()

        next_cursor_message_id = self.next_cursor_message_id

        has_more = self.has_more

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if messages is not UNSET:
            field_dict["messages"] = messages
        if next_cursor_sent_at is not UNSET:
            field_dict["nextCursorSentAt"] = next_cursor_sent_at
        if next_cursor_message_id is not UNSET:
            field_dict["nextCursorMessageId"] = next_cursor_message_id
        if has_more is not UNSET:
            field_dict["hasMore"] = has_more

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.message import Message

        d = dict(src_dict)
        _messages = d.pop("messages", UNSET)
        messages: list[Message] | Unset = UNSET
        if _messages is not UNSET:
            messages = []
            for messages_item_data in _messages:
                messages_item = Message.from_dict(messages_item_data)

                messages.append(messages_item)

        _next_cursor_sent_at = d.pop("nextCursorSentAt", UNSET)
        next_cursor_sent_at: datetime.datetime | Unset
        if isinstance(_next_cursor_sent_at, Unset):
            next_cursor_sent_at = UNSET
        else:
            next_cursor_sent_at = isoparse(_next_cursor_sent_at)

        next_cursor_message_id = d.pop("nextCursorMessageId", UNSET)

        has_more = d.pop("hasMore", UNSET)

        get_thread_messages_response = cls(
            messages=messages,
            next_cursor_sent_at=next_cursor_sent_at,
            next_cursor_message_id=next_cursor_message_id,
            has_more=has_more,
        )

        get_thread_messages_response.additional_properties = d
        return get_thread_messages_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
