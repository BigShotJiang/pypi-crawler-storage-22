from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.group import Group
    from ..models.space_member import SpaceMember
    from ..models.user import User


T = TypeVar("T", bound="GetUserContextByOrganizationIdResponse")


@_attrs_define
class GetUserContextByOrganizationIdResponse:
    """
    Attributes:
        user (User | Unset):
        space_memberships (list[SpaceMember] | Unset):
        groups (list[Group] | Unset):
    """

    user: User | Unset = UNSET
    space_memberships: list[SpaceMember] | Unset = UNSET
    groups: list[Group] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.group import Group
        from ..models.space_member import SpaceMember
        from ..models.user import User

        user: dict[str, Any] | Unset = UNSET
        if not isinstance(self.user, Unset):
            user = self.user.to_dict()

        space_memberships: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.space_memberships, Unset):
            space_memberships = []
            for space_memberships_item_data in self.space_memberships:
                space_memberships_item = space_memberships_item_data.to_dict()
                space_memberships.append(space_memberships_item)

        groups: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.groups, Unset):
            groups = []
            for groups_item_data in self.groups:
                groups_item = groups_item_data.to_dict()
                groups.append(groups_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if user is not UNSET:
            field_dict["user"] = user
        if space_memberships is not UNSET:
            field_dict["spaceMemberships"] = space_memberships
        if groups is not UNSET:
            field_dict["groups"] = groups

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.group import Group
        from ..models.space_member import SpaceMember
        from ..models.user import User

        d = dict(src_dict)
        _user = d.pop("user", UNSET)
        user: User | Unset
        if isinstance(_user, Unset):
            user = UNSET
        else:
            user = User.from_dict(_user)

        _space_memberships = d.pop("spaceMemberships", UNSET)
        space_memberships: list[SpaceMember] | Unset = UNSET
        if _space_memberships is not UNSET:
            space_memberships = []
            for space_memberships_item_data in _space_memberships:
                space_memberships_item = SpaceMember.from_dict(space_memberships_item_data)

                space_memberships.append(space_memberships_item)

        _groups = d.pop("groups", UNSET)
        groups: list[Group] | Unset = UNSET
        if _groups is not UNSET:
            groups = []
            for groups_item_data in _groups:
                groups_item = Group.from_dict(groups_item_data)

                groups.append(groups_item)

        get_user_context_by_organization_id_response = cls(
            user=user,
            space_memberships=space_memberships,
            groups=groups,
        )

        get_user_context_by_organization_id_response.additional_properties = d
        return get_user_context_by_organization_id_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
