from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.webhook_log import WebhookLog


T = TypeVar("T", bound="GetWebhookLogsResponse")


@_attrs_define
class GetWebhookLogsResponse:
    """Response message for getting webhook logs

    Attributes:
        logs (list[WebhookLog] | Unset):
        next_before_time (str | Unset):
    """

    logs: list[WebhookLog] | Unset = UNSET
    next_before_time: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.webhook_log import WebhookLog

        logs: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.logs, Unset):
            logs = []
            for logs_item_data in self.logs:
                logs_item = logs_item_data.to_dict()
                logs.append(logs_item)

        next_before_time = self.next_before_time

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if logs is not UNSET:
            field_dict["logs"] = logs
        if next_before_time is not UNSET:
            field_dict["nextBeforeTime"] = next_before_time

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.webhook_log import WebhookLog

        d = dict(src_dict)
        _logs = d.pop("logs", UNSET)
        logs: list[WebhookLog] | Unset = UNSET
        if _logs is not UNSET:
            logs = []
            for logs_item_data in _logs:
                logs_item = WebhookLog.from_dict(logs_item_data)

                logs.append(logs_item)

        next_before_time = d.pop("nextBeforeTime", UNSET)

        get_webhook_logs_response = cls(
            logs=logs,
            next_before_time=next_before_time,
        )

        get_webhook_logs_response.additional_properties = d
        return get_webhook_logs_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
