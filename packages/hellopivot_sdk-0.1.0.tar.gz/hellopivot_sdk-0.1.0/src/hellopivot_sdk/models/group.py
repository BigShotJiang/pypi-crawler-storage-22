from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.custom_web_view import CustomWebView


T = TypeVar("T", bound="Group")


@_attrs_define
class Group:
    """
    Attributes:
        id (str | Unset):
        name (str | Unset):
        status (str | Unset):
        organization_id (str | Unset):
        custom_web_views (list[CustomWebView] | Unset):
        created_at (datetime.datetime | Unset):
        updated_at (datetime.datetime | Unset):
        created_by_id (str | Unset):
        updated_by_id (str | Unset):
        is_member (bool | Unset):
    """

    id: str | Unset = UNSET
    name: str | Unset = UNSET
    status: str | Unset = UNSET
    organization_id: str | Unset = UNSET
    custom_web_views: list[CustomWebView] | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    updated_at: datetime.datetime | Unset = UNSET
    created_by_id: str | Unset = UNSET
    updated_by_id: str | Unset = UNSET
    is_member: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.custom_web_view import CustomWebView

        id = self.id

        name = self.name

        status = self.status

        organization_id = self.organization_id

        custom_web_views: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.custom_web_views, Unset):
            custom_web_views = []
            for custom_web_views_item_data in self.custom_web_views:
                custom_web_views_item = custom_web_views_item_data.to_dict()
                custom_web_views.append(custom_web_views_item)

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        created_by_id = self.created_by_id

        updated_by_id = self.updated_by_id

        is_member = self.is_member

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if name is not UNSET:
            field_dict["name"] = name
        if status is not UNSET:
            field_dict["status"] = status
        if organization_id is not UNSET:
            field_dict["organizationId"] = organization_id
        if custom_web_views is not UNSET:
            field_dict["customWebViews"] = custom_web_views
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at
        if created_by_id is not UNSET:
            field_dict["createdById"] = created_by_id
        if updated_by_id is not UNSET:
            field_dict["updatedById"] = updated_by_id
        if is_member is not UNSET:
            field_dict["isMember"] = is_member

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.custom_web_view import CustomWebView

        d = dict(src_dict)
        id = d.pop("id", UNSET)

        name = d.pop("name", UNSET)

        status = d.pop("status", UNSET)

        organization_id = d.pop("organizationId", UNSET)

        _custom_web_views = d.pop("customWebViews", UNSET)
        custom_web_views: list[CustomWebView] | Unset = UNSET
        if _custom_web_views is not UNSET:
            custom_web_views = []
            for custom_web_views_item_data in _custom_web_views:
                custom_web_views_item = CustomWebView.from_dict(custom_web_views_item_data)

                custom_web_views.append(custom_web_views_item)

        _created_at = d.pop("createdAt", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        _updated_at = d.pop("updatedAt", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)

        created_by_id = d.pop("createdById", UNSET)

        updated_by_id = d.pop("updatedById", UNSET)

        is_member = d.pop("isMember", UNSET)

        group = cls(
            id=id,
            name=name,
            status=status,
            organization_id=organization_id,
            custom_web_views=custom_web_views,
            created_at=created_at,
            updated_at=updated_at,
            created_by_id=created_by_id,
            updated_by_id=updated_by_id,
            is_member=is_member,
        )

        group.additional_properties = d
        return group

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
