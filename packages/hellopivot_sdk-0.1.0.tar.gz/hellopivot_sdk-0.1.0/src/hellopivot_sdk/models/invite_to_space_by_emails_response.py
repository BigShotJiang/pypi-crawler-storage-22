from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.invite import Invite


T = TypeVar("T", bound="InviteToSpaceByEmailsResponse")


@_attrs_define
class InviteToSpaceByEmailsResponse:
    """
    Attributes:
        invites (list[Invite] | Unset):
        added_users_ids (list[str] | Unset):
    """

    invites: list[Invite] | Unset = UNSET
    added_users_ids: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.invite import Invite

        invites: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.invites, Unset):
            invites = []
            for invites_item_data in self.invites:
                invites_item = invites_item_data.to_dict()
                invites.append(invites_item)

        added_users_ids: list[str] | Unset = UNSET
        if not isinstance(self.added_users_ids, Unset):
            added_users_ids = self.added_users_ids

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if invites is not UNSET:
            field_dict["invites"] = invites
        if added_users_ids is not UNSET:
            field_dict["addedUsersIds"] = added_users_ids

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.invite import Invite

        d = dict(src_dict)
        _invites = d.pop("invites", UNSET)
        invites: list[Invite] | Unset = UNSET
        if _invites is not UNSET:
            invites = []
            for invites_item_data in _invites:
                invites_item = Invite.from_dict(invites_item_data)

                invites.append(invites_item)

        added_users_ids = cast(list[str], d.pop("addedUsersIds", UNSET))

        invite_to_space_by_emails_response = cls(
            invites=invites,
            added_users_ids=added_users_ids,
        )

        invite_to_space_by_emails_response.additional_properties = d
        return invite_to_space_by_emails_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
