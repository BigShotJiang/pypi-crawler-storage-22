from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="MemberInfo")


@_attrs_define
class MemberInfo:
    """
    Attributes:
        user_id (str):
        role_ids (list[str] | Unset):
        title (str | Unset):
    """

    user_id: str
    role_ids: list[str] | Unset = UNSET
    title: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        user_id = self.user_id

        role_ids: list[str] | Unset = UNSET
        if not isinstance(self.role_ids, Unset):
            role_ids = self.role_ids

        title = self.title

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "userId": user_id,
            }
        )
        if role_ids is not UNSET:
            field_dict["roleIds"] = role_ids
        if title is not UNSET:
            field_dict["title"] = title

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        user_id = d.pop("userId")

        _role_ids = d.pop("roleIds", UNSET)
        role_ids: list[str] | Unset
        if isinstance(_role_ids, Unset):
            role_ids = UNSET
        else:
            role_ids = cast(list[str], _role_ids)

        title = d.pop("title", UNSET)

        member_info = cls(
            user_id=user_id,
            role_ids=role_ids,
            title=title,
        )

        member_info.additional_properties = d
        return member_info

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
