from enum import Enum


class MessageStatus(str, Enum):
    MESSAGE_STATUS_DELETED = "MESSAGE_STATUS_DELETED"
    MESSAGE_STATUS_DRAFT = "MESSAGE_STATUS_DRAFT"
    MESSAGE_STATUS_SENT = "MESSAGE_STATUS_SENT"
    MESSAGE_STATUS_UNSPECIFIED = "MESSAGE_STATUS_UNSPECIFIED"

    def __str__(self) -> str:
        return str(self.value)
