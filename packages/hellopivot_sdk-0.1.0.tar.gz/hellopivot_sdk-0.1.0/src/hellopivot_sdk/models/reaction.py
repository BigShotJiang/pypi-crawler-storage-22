from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.reaction_emoji import ReactionEmoji


T = TypeVar("T", bound="Reaction")


@_attrs_define
class Reaction:
    """
    Attributes:
        user_id (str | Unset):
        emojis (ReactionEmoji | Unset):
        updated_at (datetime.datetime | Unset):
    """

    user_id: str | Unset = UNSET
    emojis: ReactionEmoji | Unset = UNSET
    updated_at: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.reaction_emoji import ReactionEmoji

        user_id = self.user_id

        emojis: dict[str, Any] | Unset = UNSET
        if not isinstance(self.emojis, Unset):
            emojis = self.emojis.to_dict()

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if user_id is not UNSET:
            field_dict["userId"] = user_id
        if emojis is not UNSET:
            field_dict["emojis"] = emojis
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.reaction_emoji import ReactionEmoji

        d = dict(src_dict)
        user_id = d.pop("userId", UNSET)

        _emojis = d.pop("emojis", UNSET)
        emojis: ReactionEmoji | Unset
        if isinstance(_emojis, Unset):
            emojis = UNSET
        else:
            emojis = ReactionEmoji.from_dict(_emojis)

        _updated_at = d.pop("updatedAt", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)

        reaction = cls(
            user_id=user_id,
            emojis=emojis,
            updated_at=updated_at,
        )

        reaction.additional_properties = d
        return reaction

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
