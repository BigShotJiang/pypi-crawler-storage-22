from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.rich_content_paragraph import RichContentParagraph


T = TypeVar("T", bound="RichContent")


@_attrs_define
class RichContent:
    """
    Attributes:
        children (list[RichContentParagraph] | Unset):
        direction (str | Unset):
        format_ (str | Unset):
        indent (int | Unset):
        type_ (str | Unset):
        version (int | Unset):
    """

    children: list[RichContentParagraph] | Unset = UNSET
    direction: str | Unset = UNSET
    format_: str | Unset = UNSET
    indent: int | Unset = UNSET
    type_: str | Unset = UNSET
    version: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.rich_content_paragraph import RichContentParagraph

        children: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.children, Unset):
            children = []
            for children_item_data in self.children:
                children_item = children_item_data.to_dict()
                children.append(children_item)

        direction = self.direction

        format_ = self.format_

        indent = self.indent

        type_ = self.type_

        version = self.version

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if children is not UNSET:
            field_dict["children"] = children
        if direction is not UNSET:
            field_dict["direction"] = direction
        if format_ is not UNSET:
            field_dict["format"] = format_
        if indent is not UNSET:
            field_dict["indent"] = indent
        if type_ is not UNSET:
            field_dict["type"] = type_
        if version is not UNSET:
            field_dict["version"] = version

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.rich_content_paragraph import RichContentParagraph

        d = dict(src_dict)
        _children = d.pop("children", UNSET)
        children: list[RichContentParagraph] | Unset = UNSET
        if _children is not UNSET:
            children = []
            for children_item_data in _children:
                children_item = RichContentParagraph.from_dict(children_item_data)

                children.append(children_item)

        direction = d.pop("direction", UNSET)

        format_ = d.pop("format", UNSET)

        indent = d.pop("indent", UNSET)

        type_ = d.pop("type", UNSET)

        version = d.pop("version", UNSET)

        rich_content = cls(
            children=children,
            direction=direction,
            format_=format_,
            indent=indent,
            type_=type_,
            version=version,
        )

        rich_content.additional_properties = d
        return rich_content

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
