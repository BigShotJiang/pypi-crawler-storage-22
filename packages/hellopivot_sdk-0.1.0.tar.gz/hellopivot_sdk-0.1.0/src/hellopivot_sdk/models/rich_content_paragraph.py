from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.rich_content_segment import RichContentSegment


T = TypeVar("T", bound="RichContentParagraph")


@_attrs_define
class RichContentParagraph:
    """
    Attributes:
        children (list[RichContentSegment] | Unset):
        direction (str | Unset):
        format_ (str | Unset):
        indent (int | Unset):
        type_ (str | Unset):
        text_format (int | Unset):
        text_style (str | Unset):
        version (int | Unset):
        tag (str | Unset):
        start (int | Unset):
        list_type (str | Unset):
        language (str | Unset):
    """

    children: list[RichContentSegment] | Unset = UNSET
    direction: str | Unset = UNSET
    format_: str | Unset = UNSET
    indent: int | Unset = UNSET
    type_: str | Unset = UNSET
    text_format: int | Unset = UNSET
    text_style: str | Unset = UNSET
    version: int | Unset = UNSET
    tag: str | Unset = UNSET
    start: int | Unset = UNSET
    list_type: str | Unset = UNSET
    language: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.rich_content_segment import RichContentSegment

        children: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.children, Unset):
            children = []
            for children_item_data in self.children:
                children_item = children_item_data.to_dict()
                children.append(children_item)

        direction = self.direction

        format_ = self.format_

        indent = self.indent

        type_ = self.type_

        text_format = self.text_format

        text_style = self.text_style

        version = self.version

        tag = self.tag

        start = self.start

        list_type = self.list_type

        language = self.language

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if children is not UNSET:
            field_dict["children"] = children
        if direction is not UNSET:
            field_dict["direction"] = direction
        if format_ is not UNSET:
            field_dict["format"] = format_
        if indent is not UNSET:
            field_dict["indent"] = indent
        if type_ is not UNSET:
            field_dict["type"] = type_
        if text_format is not UNSET:
            field_dict["textFormat"] = text_format
        if text_style is not UNSET:
            field_dict["textStyle"] = text_style
        if version is not UNSET:
            field_dict["version"] = version
        if tag is not UNSET:
            field_dict["tag"] = tag
        if start is not UNSET:
            field_dict["start"] = start
        if list_type is not UNSET:
            field_dict["listType"] = list_type
        if language is not UNSET:
            field_dict["language"] = language

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.rich_content_segment import RichContentSegment

        d = dict(src_dict)
        _children = d.pop("children", UNSET)
        children: list[RichContentSegment] | Unset = UNSET
        if _children is not UNSET:
            children = []
            for children_item_data in _children:
                children_item = RichContentSegment.from_dict(children_item_data)

                children.append(children_item)

        direction = d.pop("direction", UNSET)

        format_ = d.pop("format", UNSET)

        indent = d.pop("indent", UNSET)

        type_ = d.pop("type", UNSET)

        text_format = d.pop("textFormat", UNSET)

        text_style = d.pop("textStyle", UNSET)

        version = d.pop("version", UNSET)

        tag = d.pop("tag", UNSET)

        start = d.pop("start", UNSET)

        list_type = d.pop("listType", UNSET)

        language = d.pop("language", UNSET)

        rich_content_paragraph = cls(
            children=children,
            direction=direction,
            format_=format_,
            indent=indent,
            type_=type_,
            text_format=text_format,
            text_style=text_style,
            version=version,
            tag=tag,
            start=start,
            list_type=list_type,
            language=language,
        )

        rich_content_paragraph.additional_properties = d
        return rich_content_paragraph

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
