from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.rich_content_sub_segment import RichContentSubSegment


T = TypeVar("T", bound="RichContentSegment")


@_attrs_define
class RichContentSegment:
    """
    Attributes:
        children (list[RichContentSubSegment] | Unset):
        detail (int | Unset):
        format_ (int | Unset):
        mode (str | Unset):
        style (str | Unset):
        text (str | Unset):
        type_ (str | Unset):
        mention_name (str | Unset):
        is_unlinked (bool | Unset):
        rel (str | Unset):
        target (str | Unset):
        title (str | Unset):
        url (str | Unset):
        direction (str | Unset):
        indent (int | Unset):
        version (int | Unset):
        checked (bool | Unset):
        value (int | Unset):
        language (str | Unset):
        list_type (str | Unset):
        text_format (int | Unset):
        text_style (str | Unset):
        mention_user_id (str | Unset):
    """

    children: list[RichContentSubSegment] | Unset = UNSET
    detail: int | Unset = UNSET
    format_: int | Unset = UNSET
    mode: str | Unset = UNSET
    style: str | Unset = UNSET
    text: str | Unset = UNSET
    type_: str | Unset = UNSET
    mention_name: str | Unset = UNSET
    is_unlinked: bool | Unset = UNSET
    rel: str | Unset = UNSET
    target: str | Unset = UNSET
    title: str | Unset = UNSET
    url: str | Unset = UNSET
    direction: str | Unset = UNSET
    indent: int | Unset = UNSET
    version: int | Unset = UNSET
    checked: bool | Unset = UNSET
    value: int | Unset = UNSET
    language: str | Unset = UNSET
    list_type: str | Unset = UNSET
    text_format: int | Unset = UNSET
    text_style: str | Unset = UNSET
    mention_user_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.rich_content_sub_segment import RichContentSubSegment

        children: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.children, Unset):
            children = []
            for children_item_data in self.children:
                children_item = children_item_data.to_dict()
                children.append(children_item)

        detail = self.detail

        format_ = self.format_

        mode = self.mode

        style = self.style

        text = self.text

        type_ = self.type_

        mention_name = self.mention_name

        is_unlinked = self.is_unlinked

        rel = self.rel

        target = self.target

        title = self.title

        url = self.url

        direction = self.direction

        indent = self.indent

        version = self.version

        checked = self.checked

        value = self.value

        language = self.language

        list_type = self.list_type

        text_format = self.text_format

        text_style = self.text_style

        mention_user_id = self.mention_user_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if children is not UNSET:
            field_dict["children"] = children
        if detail is not UNSET:
            field_dict["detail"] = detail
        if format_ is not UNSET:
            field_dict["format"] = format_
        if mode is not UNSET:
            field_dict["mode"] = mode
        if style is not UNSET:
            field_dict["style"] = style
        if text is not UNSET:
            field_dict["text"] = text
        if type_ is not UNSET:
            field_dict["type"] = type_
        if mention_name is not UNSET:
            field_dict["mentionName"] = mention_name
        if is_unlinked is not UNSET:
            field_dict["isUnlinked"] = is_unlinked
        if rel is not UNSET:
            field_dict["rel"] = rel
        if target is not UNSET:
            field_dict["target"] = target
        if title is not UNSET:
            field_dict["title"] = title
        if url is not UNSET:
            field_dict["url"] = url
        if direction is not UNSET:
            field_dict["direction"] = direction
        if indent is not UNSET:
            field_dict["indent"] = indent
        if version is not UNSET:
            field_dict["version"] = version
        if checked is not UNSET:
            field_dict["checked"] = checked
        if value is not UNSET:
            field_dict["value"] = value
        if language is not UNSET:
            field_dict["language"] = language
        if list_type is not UNSET:
            field_dict["listType"] = list_type
        if text_format is not UNSET:
            field_dict["textFormat"] = text_format
        if text_style is not UNSET:
            field_dict["textStyle"] = text_style
        if mention_user_id is not UNSET:
            field_dict["mentionUserId"] = mention_user_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.rich_content_sub_segment import RichContentSubSegment

        d = dict(src_dict)
        _children = d.pop("children", UNSET)
        children: list[RichContentSubSegment] | Unset = UNSET
        if _children is not UNSET:
            children = []
            for children_item_data in _children:
                children_item = RichContentSubSegment.from_dict(children_item_data)

                children.append(children_item)

        detail = d.pop("detail", UNSET)

        format_ = d.pop("format", UNSET)

        mode = d.pop("mode", UNSET)

        style = d.pop("style", UNSET)

        text = d.pop("text", UNSET)

        type_ = d.pop("type", UNSET)

        mention_name = d.pop("mentionName", UNSET)

        is_unlinked = d.pop("isUnlinked", UNSET)

        rel = d.pop("rel", UNSET)

        target = d.pop("target", UNSET)

        title = d.pop("title", UNSET)

        url = d.pop("url", UNSET)

        direction = d.pop("direction", UNSET)

        indent = d.pop("indent", UNSET)

        version = d.pop("version", UNSET)

        checked = d.pop("checked", UNSET)

        value = d.pop("value", UNSET)

        language = d.pop("language", UNSET)

        list_type = d.pop("listType", UNSET)

        text_format = d.pop("textFormat", UNSET)

        text_style = d.pop("textStyle", UNSET)

        mention_user_id = d.pop("mentionUserId", UNSET)

        rich_content_segment = cls(
            children=children,
            detail=detail,
            format_=format_,
            mode=mode,
            style=style,
            text=text,
            type_=type_,
            mention_name=mention_name,
            is_unlinked=is_unlinked,
            rel=rel,
            target=target,
            title=title,
            url=url,
            direction=direction,
            indent=indent,
            version=version,
            checked=checked,
            value=value,
            language=language,
            list_type=list_type,
            text_format=text_format,
            text_style=text_style,
            mention_user_id=mention_user_id,
        )

        rich_content_segment.additional_properties = d
        return rich_content_segment

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
