from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.room_call_type import RoomCallType
from ..models.room_status import RoomStatus
from ..models.room_type import RoomType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.member_presence_info import MemberPresenceInfo
    from ..models.persisted_breakout_data import PersistedBreakoutData
    from ..models.room_invitation import RoomInvitation


T = TypeVar("T", bound="Room")


@_attrs_define
class Room:
    """
    Attributes:
        id (str | Unset):
        name (str | Unset):
        topic (str | Unset):
        type_ (RoomType | Unset):
        status (RoomStatus | Unset):
        corresponding_room_block_id (str | Unset):
        allow_join_secret_link (bool | Unset):
        link_secret (str | Unset):
        upcoming_scheduled_time (datetime.datetime | Unset):
        created_at (datetime.datetime | Unset):
        updated_at (datetime.datetime | Unset):
        archived_at (datetime.datetime | Unset):
        deleted_at (datetime.datetime | Unset):
        presence_info (list[MemberPresenceInfo] | Unset):
        created_by_id (str | Unset):
        updated_by_id (str | Unset):
        call_type (RoomCallType | Unset):
        record_automatically (bool | Unset):
        hide_recordings_by_default (bool | Unset):
        unread_count (str | Unset):
        hide_recording_transcript (bool | Unset):
        allow_recording_download (bool | Unset):
        open_invites (list[RoomInvitation] | Unset):
        persisted_breakout_data (PersistedBreakoutData | Unset):
    """

    id: str | Unset = UNSET
    name: str | Unset = UNSET
    topic: str | Unset = UNSET
    type_: RoomType | Unset = UNSET
    status: RoomStatus | Unset = UNSET
    corresponding_room_block_id: str | Unset = UNSET
    allow_join_secret_link: bool | Unset = UNSET
    link_secret: str | Unset = UNSET
    upcoming_scheduled_time: datetime.datetime | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    updated_at: datetime.datetime | Unset = UNSET
    archived_at: datetime.datetime | Unset = UNSET
    deleted_at: datetime.datetime | Unset = UNSET
    presence_info: list[MemberPresenceInfo] | Unset = UNSET
    created_by_id: str | Unset = UNSET
    updated_by_id: str | Unset = UNSET
    call_type: RoomCallType | Unset = UNSET
    record_automatically: bool | Unset = UNSET
    hide_recordings_by_default: bool | Unset = UNSET
    unread_count: str | Unset = UNSET
    hide_recording_transcript: bool | Unset = UNSET
    allow_recording_download: bool | Unset = UNSET
    open_invites: list[RoomInvitation] | Unset = UNSET
    persisted_breakout_data: PersistedBreakoutData | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.member_presence_info import MemberPresenceInfo
        from ..models.persisted_breakout_data import PersistedBreakoutData
        from ..models.room_invitation import RoomInvitation

        id = self.id

        name = self.name

        topic = self.topic

        type_: str | Unset = UNSET
        if not isinstance(self.type_, Unset):
            type_ = self.type_.value

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        corresponding_room_block_id = self.corresponding_room_block_id

        allow_join_secret_link = self.allow_join_secret_link

        link_secret = self.link_secret

        upcoming_scheduled_time: str | Unset = UNSET
        if not isinstance(self.upcoming_scheduled_time, Unset):
            upcoming_scheduled_time = self.upcoming_scheduled_time.isoformat()

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        archived_at: str | Unset = UNSET
        if not isinstance(self.archived_at, Unset):
            archived_at = self.archived_at.isoformat()

        deleted_at: str | Unset = UNSET
        if not isinstance(self.deleted_at, Unset):
            deleted_at = self.deleted_at.isoformat()

        presence_info: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.presence_info, Unset):
            presence_info = []
            for presence_info_item_data in self.presence_info:
                presence_info_item = presence_info_item_data.to_dict()
                presence_info.append(presence_info_item)

        created_by_id = self.created_by_id

        updated_by_id = self.updated_by_id

        call_type: str | Unset = UNSET
        if not isinstance(self.call_type, Unset):
            call_type = self.call_type.value

        record_automatically = self.record_automatically

        hide_recordings_by_default = self.hide_recordings_by_default

        unread_count = self.unread_count

        hide_recording_transcript = self.hide_recording_transcript

        allow_recording_download = self.allow_recording_download

        open_invites: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.open_invites, Unset):
            open_invites = []
            for open_invites_item_data in self.open_invites:
                open_invites_item = open_invites_item_data.to_dict()
                open_invites.append(open_invites_item)

        persisted_breakout_data: dict[str, Any] | Unset = UNSET
        if not isinstance(self.persisted_breakout_data, Unset):
            persisted_breakout_data = self.persisted_breakout_data.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if name is not UNSET:
            field_dict["name"] = name
        if topic is not UNSET:
            field_dict["topic"] = topic
        if type_ is not UNSET:
            field_dict["type"] = type_
        if status is not UNSET:
            field_dict["status"] = status
        if corresponding_room_block_id is not UNSET:
            field_dict["correspondingRoomBlockId"] = corresponding_room_block_id
        if allow_join_secret_link is not UNSET:
            field_dict["allowJoinSecretLink"] = allow_join_secret_link
        if link_secret is not UNSET:
            field_dict["linkSecret"] = link_secret
        if upcoming_scheduled_time is not UNSET:
            field_dict["upcomingScheduledTime"] = upcoming_scheduled_time
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at
        if archived_at is not UNSET:
            field_dict["archivedAt"] = archived_at
        if deleted_at is not UNSET:
            field_dict["deletedAt"] = deleted_at
        if presence_info is not UNSET:
            field_dict["presenceInfo"] = presence_info
        if created_by_id is not UNSET:
            field_dict["createdById"] = created_by_id
        if updated_by_id is not UNSET:
            field_dict["updatedById"] = updated_by_id
        if call_type is not UNSET:
            field_dict["callType"] = call_type
        if record_automatically is not UNSET:
            field_dict["recordAutomatically"] = record_automatically
        if hide_recordings_by_default is not UNSET:
            field_dict["hideRecordingsByDefault"] = hide_recordings_by_default
        if unread_count is not UNSET:
            field_dict["unreadCount"] = unread_count
        if hide_recording_transcript is not UNSET:
            field_dict["hideRecordingTranscript"] = hide_recording_transcript
        if allow_recording_download is not UNSET:
            field_dict["allowRecordingDownload"] = allow_recording_download
        if open_invites is not UNSET:
            field_dict["openInvites"] = open_invites
        if persisted_breakout_data is not UNSET:
            field_dict["persistedBreakoutData"] = persisted_breakout_data

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.member_presence_info import MemberPresenceInfo
        from ..models.persisted_breakout_data import PersistedBreakoutData
        from ..models.room_invitation import RoomInvitation

        d = dict(src_dict)
        id = d.pop("id", UNSET)

        name = d.pop("name", UNSET)

        topic = d.pop("topic", UNSET)

        _type_ = d.pop("type", UNSET)
        type_: RoomType | Unset
        if isinstance(_type_, Unset):
            type_ = UNSET
        else:
            type_ = RoomType(_type_)

        _status = d.pop("status", UNSET)
        status: RoomStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = RoomStatus(_status)

        corresponding_room_block_id = d.pop("correspondingRoomBlockId", UNSET)

        allow_join_secret_link = d.pop("allowJoinSecretLink", UNSET)

        link_secret = d.pop("linkSecret", UNSET)

        _upcoming_scheduled_time = d.pop("upcomingScheduledTime", UNSET)
        upcoming_scheduled_time: datetime.datetime | Unset
        if isinstance(_upcoming_scheduled_time, Unset):
            upcoming_scheduled_time = UNSET
        else:
            upcoming_scheduled_time = isoparse(_upcoming_scheduled_time)

        _created_at = d.pop("createdAt", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        _updated_at = d.pop("updatedAt", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)

        _archived_at = d.pop("archivedAt", UNSET)
        archived_at: datetime.datetime | Unset
        if isinstance(_archived_at, Unset):
            archived_at = UNSET
        else:
            archived_at = isoparse(_archived_at)

        _deleted_at = d.pop("deletedAt", UNSET)
        deleted_at: datetime.datetime | Unset
        if isinstance(_deleted_at, Unset):
            deleted_at = UNSET
        else:
            deleted_at = isoparse(_deleted_at)

        _presence_info = d.pop("presenceInfo", UNSET)
        presence_info: list[MemberPresenceInfo] | Unset = UNSET
        if _presence_info is not UNSET:
            presence_info = []
            for presence_info_item_data in _presence_info:
                presence_info_item = MemberPresenceInfo.from_dict(presence_info_item_data)

                presence_info.append(presence_info_item)

        created_by_id = d.pop("createdById", UNSET)

        updated_by_id = d.pop("updatedById", UNSET)

        _call_type = d.pop("callType", UNSET)
        call_type: RoomCallType | Unset
        if isinstance(_call_type, Unset):
            call_type = UNSET
        else:
            call_type = RoomCallType(_call_type)

        record_automatically = d.pop("recordAutomatically", UNSET)

        hide_recordings_by_default = d.pop("hideRecordingsByDefault", UNSET)

        unread_count = d.pop("unreadCount", UNSET)

        hide_recording_transcript = d.pop("hideRecordingTranscript", UNSET)

        allow_recording_download = d.pop("allowRecordingDownload", UNSET)

        _open_invites = d.pop("openInvites", UNSET)
        open_invites: list[RoomInvitation] | Unset = UNSET
        if _open_invites is not UNSET:
            open_invites = []
            for open_invites_item_data in _open_invites:
                open_invites_item = RoomInvitation.from_dict(open_invites_item_data)

                open_invites.append(open_invites_item)

        _persisted_breakout_data = d.pop("persistedBreakoutData", UNSET)
        persisted_breakout_data: PersistedBreakoutData | Unset
        if isinstance(_persisted_breakout_data, Unset):
            persisted_breakout_data = UNSET
        else:
            persisted_breakout_data = PersistedBreakoutData.from_dict(_persisted_breakout_data)

        room = cls(
            id=id,
            name=name,
            topic=topic,
            type_=type_,
            status=status,
            corresponding_room_block_id=corresponding_room_block_id,
            allow_join_secret_link=allow_join_secret_link,
            link_secret=link_secret,
            upcoming_scheduled_time=upcoming_scheduled_time,
            created_at=created_at,
            updated_at=updated_at,
            archived_at=archived_at,
            deleted_at=deleted_at,
            presence_info=presence_info,
            created_by_id=created_by_id,
            updated_by_id=updated_by_id,
            call_type=call_type,
            record_automatically=record_automatically,
            hide_recordings_by_default=hide_recordings_by_default,
            unread_count=unread_count,
            hide_recording_transcript=hide_recording_transcript,
            allow_recording_download=allow_recording_download,
            open_invites=open_invites,
            persisted_breakout_data=persisted_breakout_data,
        )

        room.additional_properties = d
        return room

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
