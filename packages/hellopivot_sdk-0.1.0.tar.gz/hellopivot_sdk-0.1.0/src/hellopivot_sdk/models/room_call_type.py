from enum import Enum


class RoomCallType(str, Enum):
    CALL_TYPE_AUDIO = "CALL_TYPE_AUDIO"
    CALL_TYPE_UNSPECIFIED = "CALL_TYPE_UNSPECIFIED"
    CALL_TYPE_VIDEO = "CALL_TYPE_VIDEO"

    def __str__(self) -> str:
        return str(self.value)
