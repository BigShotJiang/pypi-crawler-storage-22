from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="RoomInfo")


@_attrs_define
class RoomInfo:
    """
    Attributes:
        block_id (str | Unset):
        room_id (str | Unset):
        room_name (str | Unset):
        room_type (str | Unset):
    """

    block_id: str | Unset = UNSET
    room_id: str | Unset = UNSET
    room_name: str | Unset = UNSET
    room_type: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        block_id = self.block_id

        room_id = self.room_id

        room_name = self.room_name

        room_type = self.room_type

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if block_id is not UNSET:
            field_dict["blockId"] = block_id
        if room_id is not UNSET:
            field_dict["roomId"] = room_id
        if room_name is not UNSET:
            field_dict["roomName"] = room_name
        if room_type is not UNSET:
            field_dict["roomType"] = room_type

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        block_id = d.pop("blockId", UNSET)

        room_id = d.pop("roomId", UNSET)

        room_name = d.pop("roomName", UNSET)

        room_type = d.pop("roomType", UNSET)

        room_info = cls(
            block_id=block_id,
            room_id=room_id,
            room_name=room_name,
            room_type=room_type,
        )

        room_info.additional_properties = d
        return room_info

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
