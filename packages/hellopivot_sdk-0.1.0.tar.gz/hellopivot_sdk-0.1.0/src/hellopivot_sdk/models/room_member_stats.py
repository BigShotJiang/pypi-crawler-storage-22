from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="RoomMemberStats")


@_attrs_define
class RoomMemberStats:
    """
    Attributes:
        user_id (str | Unset):
        count_non_thread_messages (int | Unset):
        count_thread_reply_messages (int | Unset):
    """

    user_id: str | Unset = UNSET
    count_non_thread_messages: int | Unset = UNSET
    count_thread_reply_messages: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        user_id = self.user_id

        count_non_thread_messages = self.count_non_thread_messages

        count_thread_reply_messages = self.count_thread_reply_messages

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if user_id is not UNSET:
            field_dict["userId"] = user_id
        if count_non_thread_messages is not UNSET:
            field_dict["countNonThreadMessages"] = count_non_thread_messages
        if count_thread_reply_messages is not UNSET:
            field_dict["countThreadReplyMessages"] = count_thread_reply_messages

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        user_id = d.pop("userId", UNSET)

        count_non_thread_messages = d.pop("countNonThreadMessages", UNSET)

        count_thread_reply_messages = d.pop("countThreadReplyMessages", UNSET)

        room_member_stats = cls(
            user_id=user_id,
            count_non_thread_messages=count_non_thread_messages,
            count_thread_reply_messages=count_thread_reply_messages,
        )

        room_member_stats.additional_properties = d
        return room_member_stats

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
