from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="SpaceInvite")


@_attrs_define
class SpaceInvite:
    """
    Attributes:
        email (str):
        role_ids (list[str] | Unset):
        title (str | Unset):
        group_ids (list[str] | Unset):
    """

    email: str
    role_ids: list[str] | Unset = UNSET
    title: str | Unset = UNSET
    group_ids: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        email = self.email

        role_ids: list[str] | Unset = UNSET
        if not isinstance(self.role_ids, Unset):
            role_ids = self.role_ids

        title = self.title

        group_ids: list[str] | Unset = UNSET
        if not isinstance(self.group_ids, Unset):
            group_ids = self.group_ids

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "email": email,
            }
        )
        if role_ids is not UNSET:
            field_dict["roleIds"] = role_ids
        if title is not UNSET:
            field_dict["title"] = title
        if group_ids is not UNSET:
            field_dict["groupIds"] = group_ids

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        email = d.pop("email")

        role_ids = cast(list[str], d.pop("roleIds", UNSET))

        title = d.pop("title", UNSET)

        group_ids = cast(list[str], d.pop("groupIds", UNSET))

        space_invite = cls(
            email=email,
            role_ids=role_ids,
            title=title,
            group_ids=group_ids,
        )

        space_invite.additional_properties = d
        return space_invite

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
