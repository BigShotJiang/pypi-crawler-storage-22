from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.space_role_permissions_item import SpaceRolePermissionsItem
from ..models.space_role_type import SpaceRoleType
from ..types import UNSET, Unset

T = TypeVar("T", bound="SpaceRole")


@_attrs_define
class SpaceRole:
    """
    Attributes:
        id (str | Unset):
        space_id (str | Unset):
        name (str | Unset):
        type_ (SpaceRoleType | Unset):
        classification (str | Unset):
        permissions (list[SpaceRolePermissionsItem] | Unset):
        created_at (datetime.datetime | Unset):
        updated_at (datetime.datetime | Unset):
    """

    id: str | Unset = UNSET
    space_id: str | Unset = UNSET
    name: str | Unset = UNSET
    type_: SpaceRoleType | Unset = UNSET
    classification: str | Unset = UNSET
    permissions: list[SpaceRolePermissionsItem] | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    updated_at: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        space_id = self.space_id

        name = self.name

        type_: str | Unset = UNSET
        if not isinstance(self.type_, Unset):
            type_ = self.type_.value

        classification = self.classification

        permissions: list[str] | Unset = UNSET
        if not isinstance(self.permissions, Unset):
            permissions = []
            for permissions_item_data in self.permissions:
                permissions_item = permissions_item_data.value
                permissions.append(permissions_item)

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if space_id is not UNSET:
            field_dict["spaceId"] = space_id
        if name is not UNSET:
            field_dict["name"] = name
        if type_ is not UNSET:
            field_dict["type"] = type_
        if classification is not UNSET:
            field_dict["classification"] = classification
        if permissions is not UNSET:
            field_dict["permissions"] = permissions
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id", UNSET)

        space_id = d.pop("spaceId", UNSET)

        name = d.pop("name", UNSET)

        _type_ = d.pop("type", UNSET)
        type_: SpaceRoleType | Unset
        if isinstance(_type_, Unset):
            type_ = UNSET
        else:
            type_ = SpaceRoleType(_type_)

        classification = d.pop("classification", UNSET)

        _permissions = d.pop("permissions", UNSET)
        permissions: list[SpaceRolePermissionsItem] | Unset = UNSET
        if _permissions is not UNSET:
            permissions = []
            for permissions_item_data in _permissions:
                permissions_item = SpaceRolePermissionsItem(permissions_item_data)

                permissions.append(permissions_item)

        _created_at = d.pop("createdAt", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        _updated_at = d.pop("updatedAt", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)

        space_role = cls(
            id=id,
            space_id=space_id,
            name=name,
            type_=type_,
            classification=classification,
            permissions=permissions,
            created_at=created_at,
            updated_at=updated_at,
        )

        space_role.additional_properties = d
        return space_role

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
