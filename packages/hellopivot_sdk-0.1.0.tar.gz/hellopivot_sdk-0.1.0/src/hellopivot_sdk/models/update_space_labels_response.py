from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.space import Space


T = TypeVar("T", bound="UpdateSpaceLabelsResponse")


@_attrs_define
class UpdateSpaceLabelsResponse:
    """
    Attributes:
        space (Space | Unset):
    """

    space: Space | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.space import Space

        space: dict[str, Any] | Unset = UNSET
        if not isinstance(self.space, Unset):
            space = self.space.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if space is not UNSET:
            field_dict["space"] = space

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.space import Space

        d = dict(src_dict)
        _space = d.pop("space", UNSET)
        space: Space | Unset
        if isinstance(_space, Unset):
            space = UNSET
        else:
            space = Space.from_dict(_space)

        update_space_labels_response = cls(
            space=space,
        )

        update_space_labels_response.additional_properties = d
        return update_space_labels_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
