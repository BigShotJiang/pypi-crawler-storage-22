from enum import Enum


class UserStatus(str, Enum):
    USER_STATUS_ACTIVE = "USER_STATUS_ACTIVE"
    USER_STATUS_BANNED = "USER_STATUS_BANNED"
    USER_STATUS_DELETED = "USER_STATUS_DELETED"
    USER_STATUS_UNSPECIFIED = "USER_STATUS_UNSPECIFIED"

    def __str__(self) -> str:
        return str(self.value)
