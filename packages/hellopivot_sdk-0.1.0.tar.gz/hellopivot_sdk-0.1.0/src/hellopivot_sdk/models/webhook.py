from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.webhook_status import WebhookStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.webhook_subscription import WebhookSubscription


T = TypeVar("T", bound="Webhook")


@_attrs_define
class Webhook:
    """
    Attributes:
        id (str | Unset):
        organization_id (str | Unset):
        name (str | Unset):
        description (str | Unset):
        endpoint_url (str | Unset):
        status (WebhookStatus | Unset):
        created_by_id (str | Unset):
        updated_by_id (str | Unset):
        created_at (datetime.datetime | Unset):
        updated_at (datetime.datetime | Unset):
        subscriptions (list[WebhookSubscription] | Unset):
    """

    id: str | Unset = UNSET
    organization_id: str | Unset = UNSET
    name: str | Unset = UNSET
    description: str | Unset = UNSET
    endpoint_url: str | Unset = UNSET
    status: WebhookStatus | Unset = UNSET
    created_by_id: str | Unset = UNSET
    updated_by_id: str | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    updated_at: datetime.datetime | Unset = UNSET
    subscriptions: list[WebhookSubscription] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.webhook_subscription import WebhookSubscription

        id = self.id

        organization_id = self.organization_id

        name = self.name

        description = self.description

        endpoint_url = self.endpoint_url

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        created_by_id = self.created_by_id

        updated_by_id = self.updated_by_id

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        subscriptions: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.subscriptions, Unset):
            subscriptions = []
            for subscriptions_item_data in self.subscriptions:
                subscriptions_item = subscriptions_item_data.to_dict()
                subscriptions.append(subscriptions_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if organization_id is not UNSET:
            field_dict["organizationId"] = organization_id
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if endpoint_url is not UNSET:
            field_dict["endpointUrl"] = endpoint_url
        if status is not UNSET:
            field_dict["status"] = status
        if created_by_id is not UNSET:
            field_dict["createdById"] = created_by_id
        if updated_by_id is not UNSET:
            field_dict["updatedById"] = updated_by_id
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at
        if subscriptions is not UNSET:
            field_dict["subscriptions"] = subscriptions

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.webhook_subscription import WebhookSubscription

        d = dict(src_dict)
        id = d.pop("id", UNSET)

        organization_id = d.pop("organizationId", UNSET)

        name = d.pop("name", UNSET)

        description = d.pop("description", UNSET)

        endpoint_url = d.pop("endpointUrl", UNSET)

        _status = d.pop("status", UNSET)
        status: WebhookStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = WebhookStatus(_status)

        created_by_id = d.pop("createdById", UNSET)

        updated_by_id = d.pop("updatedById", UNSET)

        _created_at = d.pop("createdAt", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        _updated_at = d.pop("updatedAt", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)

        _subscriptions = d.pop("subscriptions", UNSET)
        subscriptions: list[WebhookSubscription] | Unset = UNSET
        if _subscriptions is not UNSET:
            subscriptions = []
            for subscriptions_item_data in _subscriptions:
                subscriptions_item = WebhookSubscription.from_dict(subscriptions_item_data)

                subscriptions.append(subscriptions_item)

        webhook = cls(
            id=id,
            organization_id=organization_id,
            name=name,
            description=description,
            endpoint_url=endpoint_url,
            status=status,
            created_by_id=created_by_id,
            updated_by_id=updated_by_id,
            created_at=created_at,
            updated_at=updated_at,
            subscriptions=subscriptions,
        )

        webhook.additional_properties = d
        return webhook

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
