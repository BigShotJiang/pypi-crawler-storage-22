from enum import Enum


class WebhookStatus(str, Enum):
    WEBHOOK_STATUS_ACTIVE = "WEBHOOK_STATUS_ACTIVE"
    WEBHOOK_STATUS_INACTIVE = "WEBHOOK_STATUS_INACTIVE"
    WEBHOOK_STATUS_PAUSED = "WEBHOOK_STATUS_PAUSED"
    WEBHOOK_STATUS_UNSPECIFIED = "WEBHOOK_STATUS_UNSPECIFIED"

    def __str__(self) -> str:
        return str(self.value)
