from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.webhook_subscription_subject_type import WebhookSubscriptionSubjectType
from ..models.webhook_subscription_subscription_type import WebhookSubscriptionSubscriptionType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.webhook_filter import WebhookFilter


T = TypeVar("T", bound="WebhookSubscription")


@_attrs_define
class WebhookSubscription:
    """WebhookSubscription represents a subscription for a webhook

    Attributes:
        subject_type (WebhookSubscriptionSubjectType | Unset):
        subject_id (str | Unset):
        subscription_type (WebhookSubscriptionSubscriptionType | Unset):
        filter_ (WebhookFilter | Unset): WebhookFilter defines filter criteria for webhook subscriptions
    """

    subject_type: WebhookSubscriptionSubjectType | Unset = UNSET
    subject_id: str | Unset = UNSET
    subscription_type: WebhookSubscriptionSubscriptionType | Unset = UNSET
    filter_: WebhookFilter | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.webhook_filter import WebhookFilter

        subject_type: str | Unset = UNSET
        if not isinstance(self.subject_type, Unset):
            subject_type = self.subject_type.value

        subject_id = self.subject_id

        subscription_type: str | Unset = UNSET
        if not isinstance(self.subscription_type, Unset):
            subscription_type = self.subscription_type.value

        filter_: dict[str, Any] | Unset = UNSET
        if not isinstance(self.filter_, Unset):
            filter_ = self.filter_.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if subject_type is not UNSET:
            field_dict["subjectType"] = subject_type
        if subject_id is not UNSET:
            field_dict["subjectId"] = subject_id
        if subscription_type is not UNSET:
            field_dict["subscriptionType"] = subscription_type
        if filter_ is not UNSET:
            field_dict["filter"] = filter_

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.webhook_filter import WebhookFilter

        d = dict(src_dict)
        _subject_type = d.pop("subjectType", UNSET)
        subject_type: WebhookSubscriptionSubjectType | Unset
        if isinstance(_subject_type, Unset):
            subject_type = UNSET
        else:
            subject_type = WebhookSubscriptionSubjectType(_subject_type)

        subject_id = d.pop("subjectId", UNSET)

        _subscription_type = d.pop("subscriptionType", UNSET)
        subscription_type: WebhookSubscriptionSubscriptionType | Unset
        if isinstance(_subscription_type, Unset):
            subscription_type = UNSET
        else:
            subscription_type = WebhookSubscriptionSubscriptionType(_subscription_type)

        _filter_ = d.pop("filter", UNSET)
        filter_: WebhookFilter | Unset
        if isinstance(_filter_, Unset):
            filter_ = UNSET
        else:
            filter_ = WebhookFilter.from_dict(_filter_)

        webhook_subscription = cls(
            subject_type=subject_type,
            subject_id=subject_id,
            subscription_type=subscription_type,
            filter_=filter_,
        )

        webhook_subscription.additional_properties = d
        return webhook_subscription

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
