from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.webhook_subscription_input_subject_type import WebhookSubscriptionInputSubjectType
from ..models.webhook_subscription_input_subscription_type import WebhookSubscriptionInputSubscriptionType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.webhook_filter import WebhookFilter


T = TypeVar("T", bound="WebhookSubscriptionInput")


@_attrs_define
class WebhookSubscriptionInput:
    """
    Attributes:
        subject_type (WebhookSubscriptionInputSubjectType):
        subject_id (str):
        subscription_type (WebhookSubscriptionInputSubscriptionType):
        filter_ (WebhookFilter | Unset): WebhookFilter defines filter criteria for webhook subscriptions
    """

    subject_type: WebhookSubscriptionInputSubjectType
    subject_id: str
    subscription_type: WebhookSubscriptionInputSubscriptionType
    filter_: WebhookFilter | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.webhook_filter import WebhookFilter

        subject_type = self.subject_type.value

        subject_id = self.subject_id

        subscription_type = self.subscription_type.value

        filter_: dict[str, Any] | Unset = UNSET
        if not isinstance(self.filter_, Unset):
            filter_ = self.filter_.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "subjectType": subject_type,
                "subjectId": subject_id,
                "subscriptionType": subscription_type,
            }
        )
        if filter_ is not UNSET:
            field_dict["filter"] = filter_

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.webhook_filter import WebhookFilter

        d = dict(src_dict)
        subject_type = WebhookSubscriptionInputSubjectType(d.pop("subjectType"))

        subject_id = d.pop("subjectId")

        subscription_type = WebhookSubscriptionInputSubscriptionType(d.pop("subscriptionType"))

        _filter_ = d.pop("filter", UNSET)
        filter_: WebhookFilter | Unset
        if isinstance(_filter_, Unset):
            filter_ = UNSET
        else:
            filter_ = WebhookFilter.from_dict(_filter_)

        webhook_subscription_input = cls(
            subject_type=subject_type,
            subject_id=subject_id,
            subscription_type=subscription_type,
            filter_=filter_,
        )

        webhook_subscription_input.additional_properties = d
        return webhook_subscription_input

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
