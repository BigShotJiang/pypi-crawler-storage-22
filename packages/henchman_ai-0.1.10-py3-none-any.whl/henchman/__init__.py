"""Henchman-AI: A model-agnostic AI agent CLI in Python."""

from henchman.version import VERSION

__version__ = VERSION

__all__ = ["__version__"]
