"""MLG CLI application entry point."""

from __future__ import annotations

import asyncio
import os
from typing import TYPE_CHECKING

import anyio
import click
from rich.console import Console

from henchman.version import VERSION

if TYPE_CHECKING:
    from henchman.providers.base import ModelProvider

console = Console()


def _get_provider() -> ModelProvider:
    """Get the configured model provider.

    Returns:
        A ModelProvider instance.

    Raises:
        click.ClickException: If no provider is configured.
    """
    from henchman.providers import DeepSeekProvider, get_default_registry

    # Check environment for API key
    api_key = os.environ.get("DEEPSEEK_API_KEY") or os.environ.get("HENCHMAN_API_KEY")

    if api_key:
        return DeepSeekProvider(api_key=api_key)

    # Try to load from settings
    try:
        from henchman.config import load_settings

        settings = load_settings()
        registry = get_default_registry()

        provider_name = settings.providers.default or "deepseek"
        provider_settings = getattr(settings.providers, provider_name, {})

        if isinstance(provider_settings, dict):
            # Ensure api_key is handled correctly (backward compatibility or env var)
            kwargs = provider_settings.copy()
            if not kwargs.get("api_key"):
                kwargs["api_key"] = os.environ.get("ANTHROPIC_API_KEY") if provider_name == "anthropic" else os.environ.get("HENCHMAN_API_KEY")
            
            return registry.create(
                provider_name,
                **kwargs
            )
    except Exception:  # pragma: no cover
        pass

    raise click.ClickException(  # pragma: no cover
        "No API key configured. Set DEEPSEEK_API_KEY or configure in ~/.henchman/settings.yaml"
    )


def _run_interactive(output_format: str, plan_mode: bool = False, yes: bool = False) -> None:
    """Run interactive REPL mode.

    Args:
        output_format: Output format (text, json, stream-json, json-complete).
        plan_mode: Whether to start in plan mode.
        yes: Auto-approve all tool executions.
    """
    from pathlib import Path
    from henchman.cli.repl import Repl, ReplConfig
    from henchman.config import ContextLoader, load_settings
    from henchman.core.session import SessionManager
    from henchman.rag import initialize_rag

    provider = _get_provider()
    settings = load_settings()

    # Load context from MLG.md files
    context_loader = ContextLoader()
    system_prompt = context_loader.load()

    config = ReplConfig(system_prompt=system_prompt, auto_approve_tools=yes)
    repl = Repl(
        provider=provider,
        console=console,
        config=config,
        settings=settings
    )

    # Initialize session management
    session_manager = SessionManager()
    project_hash = session_manager.compute_project_hash(Path.cwd())
    session = session_manager.create_session(project_hash)
    
    repl.session_manager = session_manager
    repl.session = session

    # Initialize RAG system
    rag_system = initialize_rag(settings.rag, console=console, index=False)
    if rag_system:
        repl.tool_registry.register(rag_system.search_tool)
        repl.rag_system = rag_system

    # Set plan mode if requested
    if plan_mode and repl.session:
        repl.session.plan_mode = True
        repl.tool_registry.set_plan_mode(True)
        # Add plan mode prompt to system prompt
        from henchman.cli.commands.plan import PLAN_MODE_PROMPT
        repl.agent.system_prompt += PLAN_MODE_PROMPT

    if output_format == "text":
        anyio.run(repl.run)
    else:  # pragma: no cover
        console.print(
            "[yellow]Warning: JSON output formats not supported in interactive mode. "
            "Using text format.[/yellow]"
        )
        anyio.run(repl.run)


def _run_headless(prompt: str, output_format: str, plan_mode: bool = False, yes: bool = False) -> None:
    """Run headless mode with a single prompt.

    Args:
        prompt: The prompt to process.
        output_format: Output format (text, json, stream-json, json-complete).
        plan_mode: Whether to run in plan mode.
        yes: Auto-approve all tool executions.
    """
    from pathlib import Path
    from henchman.cli.json_output import JsonOutputRenderer
    from henchman.cli.repl import Repl, ReplConfig
    from henchman.config import ContextLoader, load_settings
    from henchman.core.events import EventType
    from henchman.core.session import SessionManager
    from henchman.rag import initialize_rag

    provider = _get_provider()
    settings = load_settings()

    # Load context from MLG.md files
    context_loader = ContextLoader()
    system_prompt = context_loader.load()

    # Add plan mode prompt if requested
    if plan_mode:  # pragma: no cover
        from henchman.cli.commands.plan import PLAN_MODE_PROMPT
        system_prompt += PLAN_MODE_PROMPT

    config = ReplConfig(system_prompt=system_prompt, auto_approve_tools=yes)
    repl = Repl(provider=provider, console=console, config=config, settings=settings)

    # Initialize session management
    session_manager = SessionManager()
    project_hash = session_manager.compute_project_hash(Path.cwd())
    session = session_manager.create_session(project_hash)
    
    repl.session_manager = session_manager
    repl.session = session

    # Initialize RAG system
    rag_system = initialize_rag(settings.rag, index=False)  # No console output in headless
    if rag_system:
        repl.tool_registry.register(rag_system.search_tool)
        repl.rag_system = rag_system

    # Set plan mode if requested
    if plan_mode and repl.session:  # pragma: no cover
        repl.session.plan_mode = True
        repl.tool_registry.set_plan_mode(True)

    async def run_single_prompt_text() -> None:  # pragma: no cover
        """Process a single prompt and exit with text output."""
        if repl.rag_system:
            asyncio.create_task(repl.rag_system.index_async())
        await repl.process_input(prompt)

    async def run_single_prompt_json() -> None:
        """Process a single prompt and exit with JSON output."""
        from henchman.core.events import AgentEvent, EventType
        from henchman.providers.base import ToolCall
        from collections.abc import AsyncIterator

        if repl.rag_system:
            asyncio.create_task(repl.rag_system.index_async())

        json_renderer = JsonOutputRenderer(console)
        
        # We need to manually run the tool loop for JSON output
        # to ensure all events are rendered as JSON
        async def run_and_render(stream: AsyncIterator[AgentEvent]) -> None:
            pending_tool_calls = []
            async for event in stream:
                json_renderer.render(event)
                if event.type == EventType.TOOL_CALL_REQUEST:
                    pending_tool_calls.append(event.data)
            
            if pending_tool_calls:
                # Execute tool calls
                for tool_call in pending_tool_calls:
                    result = await repl.tool_registry.execute(tool_call.name, tool_call.arguments)
                    repl.agent.submit_tool_result(tool_call.id, result.content)
                    # Emit tool result event
                    json_renderer.render(AgentEvent(type=EventType.TOOL_RESULT, data=result))
                
                # Continue
                await run_and_render(repl.agent.continue_with_tool_results())

        await run_and_render(repl.agent.run(prompt))

    async def run_single_prompt_stream_json() -> None:
        """Process a single prompt and exit with streaming JSON output."""
        from henchman.core.events import AgentEvent, EventType
        from henchman.providers.base import ToolCall
        from collections.abc import AsyncIterator

        if repl.rag_system:
            asyncio.create_task(repl.rag_system.index_async())

        json_renderer = JsonOutputRenderer(console)
        
        async def run_and_render_stream(stream: AsyncIterator[AgentEvent]) -> None:
            pending_tool_calls = []
            async for event in stream:
                json_renderer.render_stream_json(event)
                if event.type == EventType.TOOL_CALL_REQUEST:
                    pending_tool_calls.append(event.data)
            
            if pending_tool_calls:
                for tool_call in pending_tool_calls:
                    result = await repl.tool_registry.execute(tool_call.name, tool_call.arguments)
                    repl.agent.submit_tool_result(tool_call.id, result.content)
                    json_renderer.render_stream_json(AgentEvent(type=EventType.TOOL_RESULT, data=result))
                
                await run_and_render_stream(repl.agent.continue_with_tool_results())

        await run_and_render_stream(repl.agent.run(prompt))

    async def run_single_prompt_json_complete() -> None:
        """Process a single prompt and exit with complete JSON output."""
        from henchman.core.events import AgentEvent, EventType
        from henchman.providers.base import ToolCall
        from collections.abc import AsyncIterator

        if repl.rag_system:
            asyncio.create_task(repl.rag_system.index_async())

        json_renderer = JsonOutputRenderer(console)
        all_events: list[AgentEvent] = []
        
        async def run_and_collect(stream: AsyncIterator[AgentEvent]) -> None:
            pending_tool_calls = []
            async for event in stream:
                all_events.append(event)
                if event.type == EventType.TOOL_CALL_REQUEST:
                    pending_tool_calls.append(event.data)
            
            if pending_tool_calls:
                for tool_call in pending_tool_calls:
                    result = await repl.tool_registry.execute(tool_call.name, tool_call.arguments)
                    repl.agent.submit_tool_result(tool_call.id, result.content)
                    all_events.append(AgentEvent(type=EventType.TOOL_RESULT, data=result))
                
                await run_and_collect(repl.agent.continue_with_tool_results())

        await run_and_collect(repl.agent.run(prompt))
        json_renderer.render_final_json(all_events)

    if output_format == "text":
        anyio.run(run_single_prompt_text)
    elif output_format == "json":
        anyio.run(run_single_prompt_json)
    elif output_format == "stream-json":
        anyio.run(run_single_prompt_stream_json)
    elif output_format == "json-complete":
        anyio.run(run_single_prompt_json_complete)
    else:  # pragma: no cover
        pass


@click.command()
@click.version_option(version=VERSION, prog_name="henchman")
@click.option("-p", "--prompt", help="Run with a single prompt and exit")
@click.option(
    "--output-format",
    type=click.Choice(["text", "json", "stream-json", "json-complete"]),
    default="text",
    help="Output format for responses",
)
@click.option(
    "--plan",
    is_flag=True,
    default=False,
    help="Start in plan mode (read-only)",
)
@click.option(
    "-y",
    "--yes",
    is_flag=True,
    default=False,
    help="Auto-approve all tool executions (non-interactive mode)",
)
def cli(prompt: str | None, output_format: str, plan: bool, yes: bool) -> None:
    """Henchman-AI: A model-agnostic AI agent CLI.

    Start an interactive session or run with --prompt for headless mode.
    """
    if prompt:
        _run_headless(prompt, output_format, plan, yes)
    else:
        _run_interactive(output_format, plan, yes)


def main() -> None:  # pragma: no cover
    """Main entry point for the CLI."""
    cli()


if __name__ == "__main__":  # pragma: no cover
    main()
