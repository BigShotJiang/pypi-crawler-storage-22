"""Orchestrator for multi-agent development team."""

from collections.abc import AsyncIterator
from datetime import datetime
from typing import Any

from henchman.agents.pool import AgentPool
from henchman.agents.presets import get_default_team
from henchman.config.schema import Settings
from henchman.core.agent import Agent
from henchman.core.eventbus import EventBus
from henchman.core.events import AgentEvent, EventType
from henchman.providers.base import ModelProvider, ToolCall
from henchman.providers.registry import ProviderRegistry
from henchman.tools.builtins.delegate import DelegateTaskTool
from henchman.tools.registry import ToolRegistry


class Orchestrator:
    """Orchestrates a team of agents to solve complex tasks."""

    def __init__(
        self,
        default_provider: ModelProvider,
        provider_registry: ProviderRegistry | None = None,
        tool_registry: ToolRegistry | None = None,
        event_bus: EventBus | None = None,
        settings: Settings | None = None,
        system_prompt: str | None = None,
    ) -> None:
        """Initialize the Orchestrator.

        Args:
            default_provider: The default model provider.
            provider_registry: Registry for provider overrides.
            tool_registry: Registry containing all available tools.
            event_bus: Optional existing event bus.
            settings: Optional application settings.
            system_prompt: Optional override for Tech Lead system prompt.
        """
        self.default_provider = default_provider
        self.provider_registry = provider_registry
        self.tool_registry = tool_registry or ToolRegistry()
        self.event_bus = event_bus or EventBus()
        self.settings = settings or Settings()

        # Load agent configs
        agent_configs = get_default_team()
        if self.settings.agents.agents:
            # Merge custom configs/overrides
            for role, config in self.settings.agents.agents.items():
                agent_configs[role] = config

        self.pool = AgentPool(
            configs=agent_configs,
            default_provider=default_provider,
            provider_registry=provider_registry,
            parent_tool_registry=self.tool_registry,
            event_bus=self.event_bus,
        )

        # Shared context history
        self.shared_context: list[dict[str, Any]] = []

        # Create Tech Lead agent
        # Tech Lead uses the parent tool_registry directly (not a copy)
        # so that tools added later (MCP, extensions, tests) are visible.
        # DelegateTaskTool and SendMessageTool are registered on the parent;
        # delegated agents won't see them because create_scoped_registry
        # filters by each agent's allowed_tools list.
        from henchman.tools.builtins.send_message import SendMessageTool
        if not self.tool_registry.get("delegate_task"):
            self.tool_registry.register(DelegateTaskTool())
        if not self.tool_registry.get("send_message"):
            self.tool_registry.register(SendMessageTool(self.event_bus))

        from henchman.agents.prompts import get_agent_prompt

        team_members = [
            f"{c.name} ({c.role})" for c in agent_configs.values() if c.enabled
        ]

        tl_prompt = system_prompt or get_agent_prompt(
            role="tech_lead",
            team_members=team_members,
            delegatable_agents=[c.role for c in agent_configs.values() if c.enabled]
        )

        from henchman.agents.identity import AgentIdentity
        tl_identity = AgentIdentity(
            id="tech_lead",
            name="Tech Lead",
            role="tech_lead",
            description="Team orchestrator and strategist",
        )

        self.tech_lead = Agent(
            provider=default_provider,
            tool_registry=self.tool_registry,
            system_prompt=tl_prompt,
            identity=tl_identity,
        )

    async def run(self, user_input: str) -> AsyncIterator[AgentEvent]:
        """Run the orchestrator with user input.

        Args:
            user_input: The user's request.

        Yields:
            AgentEvent stream from the orchestration.
        """
        yield AgentEvent(
            type=EventType.AGENT_STARTED,
            data={"agent": "tech_lead"},
            source_agent="orchestrator"
        )

        async for event in self._run_agent_loop(self.tech_lead, user_input):
            yield event

        yield AgentEvent(
            type=EventType.AGENT_COMPLETED,
            data={"agent": "tech_lead"},
            source_agent="orchestrator"
        )

    async def run_direct(self, role: str, user_input: str) -> AsyncIterator[AgentEvent]:
        """Run a specific agent directly, bypassing the Tech Lead.

        Args:
            role: The role ID of the agent to run.
            user_input: The user's request.

        Yields:
            AgentEvent stream from the agent.
        """
        agent = self.pool.get_agent(role)

        yield AgentEvent(
            type=EventType.AGENT_STARTED,
            data={"agent": role},
            source_agent="orchestrator"
        )

        async for event in self._run_agent_loop(agent, user_input):
            yield event

        yield AgentEvent(
            type=EventType.AGENT_COMPLETED,
            data={"agent": role},
            source_agent="orchestrator"
        )

    async def _run_agent_loop(self, agent: Agent, user_input: str, depth: int = 0) -> AsyncIterator[AgentEvent]:
        """Handle the run loop for an agent, executing tools and intercepting delegations.

        This method is the core execution engine. It:
        1. Runs the agent and collects events
        2. Collects ALL tool calls from a single LLM response
        3. Executes regular tools via the agent's tool registry
        4. Intercepts ``delegate_task`` calls and runs sub-agent loops
        5. Submits all results back to the agent and continues

        Args:
            agent: The agent to run.
            user_input: Initial input for the agent.
            depth: Current delegation depth.

        Yields:
            AgentEvents from the agent loop.
        """
        generator: AsyncIterator[AgentEvent] = agent.run(user_input)

        while True:
            # Drain the current generator, collecting tool calls
            pending_tool_calls: list[ToolCall] = []

            try:
                async for event in generator:
                    if event.type == EventType.TOOL_CALL_REQUEST:
                        pending_tool_calls.append(event.data)
                        # Yield for UI display
                        yield event
                    else:
                        yield event
            except StopAsyncIteration:
                pass

            if not pending_tool_calls:
                # Agent finished with no tool calls — we're done
                break

            # Process all pending tool calls: execute regular tools,
            # intercept delegate_task for sub-agent routing.
            for tool_call in pending_tool_calls:
                if tool_call.name == "delegate_task":
                    target = tool_call.arguments.get("agent", "")
                    task = tool_call.arguments.get("task", "")
                    context = tool_call.arguments.get("context")

                    yield AgentEvent(
                        type=EventType.AGENT_DELEGATED,
                        data={
                            "from": agent.identity.id if agent.identity else "unknown",
                            "to": target,
                            "task": task,
                        },
                        source_agent="orchestrator",
                    )

                    # Run delegation and collect summary
                    result_content = ""
                    async for sub_event in self._run_delegation(target, task, context, depth + 1):
                        if sub_event.type == EventType.AGENT_COMPLETED:
                            result_content = sub_event.data.get("summary", "Completed.")
                        yield sub_event

                    if not result_content:
                        result_content = "Delegation completed (no output)."

                    agent.submit_tool_result(tool_call.id, result_content)

                    yield AgentEvent(
                        type=EventType.TOOL_CALL_RESULT,
                        data={"tool_call_id": tool_call.id, "result": "Delegation completed."},
                        source_agent=agent.identity.id if agent.identity else None,
                    )
                else:
                    # Execute regular tool via the agent's own (scoped) registry
                    result = await agent.tool_registry.execute(tool_call.name, tool_call.arguments)
                    agent.submit_tool_result(tool_call.id, result.content or "")

                    yield AgentEvent(
                        type=EventType.TOOL_CALL_RESULT,
                        data={
                            "tool_call_id": tool_call.id,
                            "tool_name": tool_call.name,
                            "result": (result.content or "")[:500],
                            "success": result.success,
                        },
                        source_agent=agent.identity.id if agent.identity else None,
                    )

            # All tool results submitted — continue the agent
            generator = agent.continue_with_tool_results()

    async def _run_delegation(self, target_role: str, task: str, context: str | None, depth: int) -> AsyncIterator[AgentEvent]:
        """Execute a delegation to a specialist agent.

        Args:
            target_role: The role ID of the specialist.
            task: The task description.
            context: Additional context for the specialist.
            depth: Current recursion depth.

        Yields:
            AgentEvents from the specialist agent.
        """
        if depth > self.settings.agents.max_delegation_depth:
            yield AgentEvent(
                type=EventType.ERROR,
                data=f"Error: Maximum delegation depth ({self.settings.agents.max_delegation_depth}) exceeded.",
                source_agent="orchestrator"
            )
            yield AgentEvent(
                type=EventType.AGENT_COMPLETED,
                data={"summary": "Max depth exceeded"},
                source_agent="orchestrator"
            )
            return

        try:
            target_agent = self.pool.get_agent(target_role)
        except ValueError as e:
            yield AgentEvent(
                type=EventType.ERROR,
                data=str(e),
                source_agent="orchestrator"
            )
            yield AgentEvent(
                type=EventType.AGENT_COMPLETED,
                data={"summary": f"Agent {target_role} not found"},
                source_agent="orchestrator"
            )
            return

        yield AgentEvent(
            type=EventType.AGENT_STARTED,
            data={"agent": target_role},
            source_agent="orchestrator"
        )

        # Inject shared context into the task description
        shared_brief = "\n".join([
            f"- {item['agent']}: {item['summary']}"
            for item in self.shared_context[-5:]
        ])

        full_task = task
        if shared_brief:
            full_task = f"Context from team:\n{shared_brief}\n\nTask: {task}"
        if context:
            full_task = f"{full_task}\n\nAdditional Data:\n{context}"

        collected_content = []
        async for event in self._run_agent_loop(target_agent, full_task, depth):
            if event.type == EventType.CONTENT:
                collected_content.append(event.data)
            yield event

        summary = "".join(collected_content)

        # Update shared context
        self.shared_context.append({
            "agent": target_role,
            "summary": summary[:500],
            "timestamp": datetime.now().isoformat()
        })

        yield AgentEvent(
            type=EventType.AGENT_COMPLETED,
            data={"agent": target_role, "summary": summary},
            source_agent="orchestrator"
        )

    def get_pool(self) -> AgentPool:
        """Get the agent pool."""
        return self.pool

    def get_event_bus(self) -> EventBus:
        """Get the event bus."""
        return self.event_bus
