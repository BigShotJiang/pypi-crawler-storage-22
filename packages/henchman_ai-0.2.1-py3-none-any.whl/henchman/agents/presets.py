"""Default agent team presets."""

from henchman.agents.config import AgentConfig


def get_default_team() -> dict[str, AgentConfig]:
    """Get the default 7-agent software development team configuration.

    Returns:
        Dictionary mapping role ID to AgentConfig.
    """
    return {
        "architect": AgentConfig(
            name="Architect",
            role="architect",
            description="System design and technical planning",
            tools=["read_file", "ls", "glob", "grep", "web_fetch", "rag_search"],
            can_delegate_to=["researcher"],
        ),
        "coder": AgentConfig(
            name="Coder",
            role="coder",
            description="Implementation and refactoring",
            tools=["read_file", "write_file", "edit_file", "ls", "glob", "grep", "shell"],
            can_delegate_to=["researcher"],
        ),
        "reviewer": AgentConfig(
            name="Reviewer",
            role="reviewer",
            description="Code review and quality assurance",
            tools=["read_file", "ls", "glob", "grep", "rag_search"],
        ),
        "tester": AgentConfig(
            name="Tester",
            role="tester",
            description="Test implementation and verification",
            tools=["read_file", "write_file", "edit_file", "ls", "glob", "grep", "shell"],
        ),
        "devops": AgentConfig(
            name="DevOps",
            role="devops",
            description="CI/CD, build and environment management",
            tools=["read_file", "write_file", "edit_file", "ls", "glob", "grep", "shell", "web_fetch"],
        ),
        "researcher": AgentConfig(
            name="Researcher",
            role="researcher",
            description="Information gathering and documentation research",
            tools=["read_file", "ls", "glob", "grep", "web_fetch", "web_search", "rag_search"],
        ),
        "technical_writer": AgentConfig(
            name="Technical Writer",
            role="technical_writer",
            description="Documentation and technical communication",
            tools=["read_file", "write_file", "edit_file", "ls", "glob", "grep"],
            can_delegate_to=["researcher"],
        ),
    }
