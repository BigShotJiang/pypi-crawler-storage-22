"""Delegate task tool implementation."""

from typing import Any

from henchman.tools.base import Tool, ToolKind, ToolResult


class DelegateTaskTool(Tool):
    """Tool for delegating a task to a specialist agent.

    This tool is intercepted by the Orchestrator to route the task to
    the appropriate specialist.
    """

    @property
    def name(self) -> str:
        """Tool name."""
        return "delegate_task"

    @property
    def description(self) -> str:
        """Tool description."""
        return (
            "Delegate a task to a specialist agent in the team. "
            "Use this to hand off specific parts of a plan to the most qualified agent."
        )

    @property
    def parameters(self) -> dict[str, object]:
        """JSON Schema for parameters."""
        return {
            "type": "object",
            "properties": {
                "agent": {
                    "type": "string",
                    "description": "The role of the specialist agent to delegate to (e.g., 'coder', 'tester')",
                },
                "task": {
                    "type": "string",
                    "description": "Detailed description of the task to perform",
                },
                "context": {
                    "type": "string",
                    "description": "Optional relevant context, file contents, or previous decisions",
                },
            },
            "required": ["agent", "task"],
        }

    @property
    def kind(self) -> ToolKind:
        """Tool kind - READ is auto-approved."""
        return ToolKind.READ

    async def execute(  # type: ignore[override]
        self, agent: str = "", task: str = "", context: str | None = None, **kwargs: Any
    ) -> ToolResult:
        """Stub execution - should be intercepted by Orchestrator.

        Args:
            agent: Target agent role.
            task: Task description.
            context: Optional context.
            **kwargs: Additional arguments.

        Returns:
            ToolResult indicating delegation was handled.
        """
        return ToolResult(
            content="Delegation handled by orchestrator",
            success=True
        )
