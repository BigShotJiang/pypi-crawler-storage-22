"""Send message tool implementation for inter-agent communication."""

from typing import TYPE_CHECKING, Any

from henchman.core.events import AgentEvent, EventType
from henchman.tools.base import Tool, ToolKind, ToolResult

if TYPE_CHECKING:
    from henchman.core.eventbus import EventBus


class SendMessageTool(Tool):
    """Tool for sending messages to other agents via the EventBus."""

    def __init__(self, event_bus: "EventBus") -> None:
        """Initialize the tool.

        Args:
            event_bus: The event bus to publish messages to.
        """
        self.event_bus = event_bus

    @property
    def name(self) -> str:
        """Tool name."""
        return "send_message"

    @property
    def description(self) -> str:
        """Tool description."""
        return (
            "Send a message to another agent in the team. "
            "Use this to ask for help, request information, or provide updates to peers."
        )

    @property
    def parameters(self) -> dict[str, object]:
        """JSON Schema for parameters."""
        return {
            "type": "object",
            "properties": {
                "to_agent": {
                    "type": "string",
                    "description": "The role of the agent to send the message to (e.g., 'researcher', 'coder')",
                },
                "message": {
                    "type": "string",
                    "description": "The message content",
                },
                "context": {
                    "type": "string",
                    "description": "Optional additional context or data relevant to the message",
                },
            },
            "required": ["to_agent", "message"],
        }

    @property
    def kind(self) -> ToolKind:
        """Tool kind - READ is auto-approved."""
        return ToolKind.READ

    async def execute(  # type: ignore[override]
        self, to_agent: str = "", message: str = "", context: str | None = None, **kwargs: Any
    ) -> ToolResult:
        """Send message via EventBus.

        Args:
            to_agent: Target agent role.
            message: Message content.
            context: Optional context.
            **kwargs: Additional arguments (ignored).

        Returns:
            ToolResult indicating if message was sent.
        """
        try:
            event = AgentEvent(
                type=EventType.AGENT_MESSAGE,
                data={
                    "to": to_agent,
                    "message": message,
                    "context": context,
                }
            )
            await self.event_bus.publish(event)
            return ToolResult(
                content=f"Message sent to {to_agent}.",
                success=True
            )
        except Exception as e:
            return ToolResult(
                content=f"Error sending message: {e}",
                success=False,
                error=str(e)
            )
