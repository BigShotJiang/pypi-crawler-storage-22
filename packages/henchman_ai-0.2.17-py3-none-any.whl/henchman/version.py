"""Version information for Henchman-AI."""

VERSION_TUPLE = (0, 2, 17)
VERSION = ".".join(str(v) for v in VERSION_TUPLE)

__all__ = ["VERSION", "VERSION_TUPLE"]
