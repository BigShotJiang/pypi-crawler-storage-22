"""Version information for Henchman-AI."""

VERSION_TUPLE = (0, 2, 18)
VERSION = ".".join(str(v) for v in VERSION_TUPLE)

__all__ = ["VERSION", "VERSION_TUPLE"]
