This device requires additional binary drivers to run.

.. warning::

   The PCIe Driver only works with very specific (and often outdated) kernel versions.
   If you need the PCIe driver you will likely need to build a docker image yourself or run it without docker.

The following script can be :external:ref:`used with BOSS <boss-additional-deps>` to automatically build and install the driver inside a docker container.

.. code-block:: bash
   :caption: pvcam.boss.sh

   SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )

   # Install prerequisites
   apt-get update && apt-get install -y sudo git

   # Install the vendor library itself
   # We have to agree to some licenses here so we use the "yes" command.
   # The EUID=1 is a little hack to trick the installer into thinking we're not root.
   /bin/sh -c 'yes | /bin/bash '"${SCRIPT_DIR}"'/pvcam/pvcam__install_helper-Ubuntu.sh'

   # Remove build files after installation to make image a bit smaller
   rm -rf /pvcam

   # We need to point the python api to the correct library path
   export PVCAM_SDK_PATH="/opt/pvcam/sdk"
   # Install python API
   pip install --break-system-packages PyVCAM

Place the ``pvcam`` folder from the archive you can download `here <https://www.teledynevisionsolutions.com/products/pvcam-sdk-amp-driver/>`_ in the same folder as the script.
Finally, add the following lines to your docker compose file:

.. code-block:: yaml

    environment:
      - PVCAM_SDK_PATH=/opt/pvcam/sdk
      - PVCAM_UMD_PATH=/opt/pvcam/drivers/user-mode
      - PVCAM_VERSION=3.10.2.5 # Adjust this to your version


.. important::

   To access the camera from within the docker container follow :external+boss:std:ref:`this guide <boss-docker-device-access>`.
   Note, that pvcam cameras are not linked to a nice name but are only accessible via their usb path like
   ``/dev/bus/usb/004/004``. To find this path run

   .. code-block:: bash

      lsusb | grep <NAME> |  awk '{ sub(/:/, "", $4); print "/dev/bus/usb/" $2 "/" $4 }'

   Replace ``<NAME>`` with the name of your device as shown by ``lsusb``.
