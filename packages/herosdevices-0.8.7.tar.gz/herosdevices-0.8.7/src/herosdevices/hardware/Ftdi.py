from herosdevices.helper import log  # noqa: N999, D100

from .ftdi import *  # noqa: F403

log.warning("herosdevices.hardware.Ftdi was moved to herosdevices.hardware.ftdi and is deprecated! Will be removed!")
