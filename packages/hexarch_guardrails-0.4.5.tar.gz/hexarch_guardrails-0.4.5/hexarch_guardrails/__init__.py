"""
Hexarch Guardrails Python SDK
Lightweight policy-driven API protection for developers
"""

from .guardian import Guardian
from .exceptions import (
    GuardrailException,
    OPAConnectionError,
    OPAPolicyError,
    PolicyViolation,
    PolicyWarning,
    PolicyConfigError,
)
from .confirmation import (
    ConfirmationStore,
    MemoryConfirmationStore,
    RedisConfirmationStore,
    InteractiveConfirmation,
    HTTPConfirmationGateway,
    ConfirmationWorkflow,
)

__version__ = "0.4.5"
__author__ = "Hexarch"

__all__ = [
    "Guardian",
    "GuardrailException",
    "OPAConnectionError",
    "OPAPolicyError",
    "PolicyViolation",
    "PolicyWarning",
    "PolicyConfigError",
    "ConfirmationStore",
    "MemoryConfirmationStore",
    "RedisConfirmationStore",
    "InteractiveConfirmation",
    "HTTPConfirmationGateway",
    "ConfirmationWorkflow",
]
