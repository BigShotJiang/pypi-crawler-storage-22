"""
Confirmation helpers for interactive and distributed approval workflows

This module provides three patterns for handling policy confirmations:
1. Interactive CLI prompts (for development/local)
2. HTTP callbacks (for microservices/APIs)
3. Token-based persistence (for distributed/async workflows)

Use these helpers to collect user approval when a policy requires confirmation,
then retry the guarded function with confirmation_token passed in context.
"""

import json
import uuid
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, Callable
from datetime import datetime, timedelta


class ConfirmationStore(ABC):
    """Abstract base for confirmation token persistence"""
    
    @abstractmethod
    def store_pending(self, token: str, metadata: Dict[str, Any], ttl_seconds: int = 300) -> None:
        """Store a pending confirmation request"""
        pass
    
    @abstractmethod
    def get_pending(self, token: str) -> Optional[Dict[str, Any]]:
        """Retrieve a pending confirmation request"""
        pass
    
    @abstractmethod
    def approve(self, token: str, approved_by: str = "auto") -> bool:
        """Mark a token as approved. Returns True if found and approved."""
        pass
    
    @abstractmethod
    def reject(self, token: str, rejected_by: str = "auto") -> bool:
        """Mark a token as rejected. Returns True if found and rejected."""
        pass
    
    @abstractmethod
    def is_approved(self, token: str) -> bool:
        """Check if a token has been approved"""
        pass


class MemoryConfirmationStore(ConfirmationStore):
    """In-memory confirmation store (perfect for dev/testing)"""
    
    def __init__(self):
        self.store: Dict[str, Dict[str, Any]] = {}
        self.approvals: Dict[str, bool] = {}
    
    def store_pending(self, token: str, metadata: Dict[str, Any], ttl_seconds: int = 300) -> None:
        """Store pending confirmation with TTL"""
        self.store[token] = {
            "metadata": metadata,
            "created_at": datetime.utcnow(),
            "ttl_seconds": ttl_seconds
        }
    
    def get_pending(self, token: str) -> Optional[Dict[str, Any]]:
        """Retrieve pending confirmation if not expired"""
        if token not in self.store:
            return None
        
        entry = self.store[token]
        elapsed = (datetime.utcnow() - entry["created_at"]).total_seconds()
        
        if elapsed > entry["ttl_seconds"]:
            del self.store[token]
            return None
        
        return entry["metadata"]
    
    def approve(self, token: str, approved_by: str = "auto") -> bool:
        """Mark token as approved"""
        if token in self.store:
            self.approvals[token] = True
            return True
        return False
    
    def reject(self, token: str, rejected_by: str = "auto") -> bool:
        """Mark token as rejected"""
        if token in self.store:
            self.approvals[token] = False
            return True
        return False
    
    def is_approved(self, token: str) -> bool:
        """Check if token is approved"""
        return self.approvals.get(token, False)


class RedisConfirmationStore(ConfirmationStore):
    """
    Redis-backed confirmation store for distributed systems
    
    Example:
        import redis
        store = RedisConfirmationStore(redis.Redis(host='localhost', port=6379))
        token = store.create_pending({"operation": "delete", "resource_id": 123})
        # Later, after user approval...
        store.approve(token)
    """
    
    def __init__(self, redis_client, prefix: str = "hexarch:confirm:"):
        """
        Args:
            redis_client: redis.Redis instance
            prefix: Key prefix for all stored tokens
        """
        self.redis = redis_client
        self.prefix = prefix
    
    def store_pending(self, token: str, metadata: Dict[str, Any], ttl_seconds: int = 300) -> None:
        """Store pending confirmation in Redis with TTL"""
        key = f"{self.prefix}{token}"
        self.redis.setex(key, ttl_seconds, json.dumps({
            "metadata": metadata,
            "created_at": datetime.utcnow().isoformat(),
            "status": "pending"
        }))
    
    def get_pending(self, token: str) -> Optional[Dict[str, Any]]:
        """Retrieve pending confirmation from Redis"""
        key = f"{self.prefix}{token}"
        data = self.redis.get(key)
        
        if not data:
            return None
        
        entry = json.loads(data)
        if entry.get("status") == "pending":
            return entry.get("metadata")
        
        return None
    
    def approve(self, token: str, approved_by: str = "auto") -> bool:
        """Mark token as approved in Redis"""
        key = f"{self.prefix}{token}"
        data = self.redis.get(key)
        
        if data:
            entry = json.loads(data)
            entry["status"] = "approved"
            entry["approved_by"] = approved_by
            entry["approved_at"] = datetime.utcnow().isoformat()
            self.redis.setex(key, 3600, json.dumps(entry))  # Keep for 1 hour
            return True
        
        return False
    
    def reject(self, token: str, rejected_by: str = "auto") -> bool:
        """Mark token as rejected in Redis"""
        key = f"{self.prefix}{token}"
        data = self.redis.get(key)
        
        if data:
            entry = json.loads(data)
            entry["status"] = "rejected"
            entry["rejected_by"] = rejected_by
            entry["rejected_at"] = datetime.utcnow().isoformat()
            self.redis.setex(key, 3600, json.dumps(entry))  # Keep for 1 hour
            return True
        
        return False
    
    def is_approved(self, token: str) -> bool:
        """Check if token is approved in Redis"""
        key = f"{self.prefix}{token}"
        data = self.redis.get(key)
        
        if data:
            entry = json.loads(data)
            return entry.get("status") == "approved"
        
        return False


class InteractiveConfirmation:
    """Interactive CLI confirmation for development"""
    
    @staticmethod
    def prompt_user(reason: str, operation: str = "Operation") -> bool:
        """
        Prompt user on CLI for confirmation
        
        Args:
            reason: Why confirmation is needed (from policy decision)
            operation: What operation needs approval
        
        Returns:
            True if user approves, False otherwise
        
        Example:
            if InteractiveConfirmation.prompt_user(
                reason="Budget limit exceeded",
                operation="Delete 500 records"
            ):
                # Proceed with operation
        """
        print(f"\n{'='*60}")
        print(f"⚠️  CONFIRMATION REQUIRED")
        print(f"{'='*60}")
        print(f"Operation: {operation}")
        print(f"Reason: {reason}")
        print(f"{'='*60}")
        
        response = input("Approve? (yes/no): ").strip().lower()
        approved = response in ['yes', 'y', 'approve']
        
        if approved:
            print("✅ Approved\n")
        else:
            print("❌ Rejected\n")
        
        return approved


class HTTPConfirmationGateway:
    """
    HTTP callback for distributed approval workflows
    
    Instead of blocking for user input, notify a remote service
    and provide a token that can be used to retry after approval.
    
    Example:
        gateway = HTTPConfirmationGateway(
            webhook_url="https://api.example.com/approve",
            on_retry_hint=lambda token: print(f"Retry with token: {token}")
        )
        
        token = gateway.notify_pending_approval(
            reason="Quota exceeded",
            operation="SendEmail",
            metadata={"recipients": ["user@example.com"]}
        )
    """
    
    def __init__(
        self,
        webhook_url: str,
        headers: Optional[Dict[str, str]] = None,
        on_retry_hint: Optional[Callable[[str], None]] = None
    ):
        """
        Args:
            webhook_url: Remote endpoint to POST approval request to
            headers: Additional HTTP headers (e.g., auth tokens)
            on_retry_hint: Callback to show user the retry token
        """
        self.webhook_url = webhook_url
        self.headers = headers or {}
        self.on_retry_hint = on_retry_hint
    
    def notify_pending_approval(
        self,
        reason: str,
        operation: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Send approval request to remote webhook
        
        Args:
            reason: Why confirmation needed
            operation: What operation needs approval
            metadata: Additional context
        
        Returns:
            Confirmation token for later retry
        
        Note:
            In real implementation, would HTTP POST to webhook_url.
            This stub demonstrates the pattern.
        """
        token = str(uuid.uuid4())
        
        payload = {
            "token": token,
            "reason": reason,
            "operation": operation,
            "metadata": metadata or {},
            "requested_at": datetime.utcnow().isoformat()
        }
        
        # In production, this would POST to webhook_url:
        # response = requests.post(self.webhook_url, json=payload, headers=self.headers)
        # response.raise_for_status()
        
        print(f"📧 Sent approval request to {self.webhook_url}")
        print(f"   Token: {token}")
        
        if self.on_retry_hint:
            self.on_retry_hint(token)
        
        return token


class ConfirmationWorkflow:
    """
    High-level helper for the confirm-then-retry pattern
    
    Typical flow:
    1. Function call blocked by policy requiring confirmation
    2. Catch PolicyViolation and check if requires_confirmation
    3. Collect approval (CLI, HTTP, etc.)
    4. Retry function with confirmation_token in context
    
    Example:
        from hexarch import Guardian
        from hexarch.confirmation import ConfirmationWorkflow, MemoryConfirmationStore
        
        guardian = Guardian(policy_file="hexarch.yaml")
        workflow = ConfirmationWorkflow(guardian, MemoryConfirmationStore())
        
        try:
            workflow.execute_with_confirmation(
                policy_id="sensitive_delete",
                func=delete_records,
                func_args=(record_ids,),
                interactive=True
            )
        except Exception as e:
            print(f"Failed: {e}")
    """
    
    def __init__(self, guardian, confirmation_store: ConfirmationStore):
        """
        Args:
            guardian: Guardian instance
            confirmation_store: Where to persist confirmation tokens
        """
        self.guardian = guardian
        self.store = confirmation_store
    
    def execute_with_confirmation(
        self,
        policy_id: str,
        func: Callable,
        func_args: tuple = (),
        func_kwargs: Optional[Dict] = None,
        context: Optional[Dict[str, Any]] = None,
        interactive: bool = True,
        reason: Optional[str] = None,
        ttl_seconds: int = 300
    ) -> Any:
        """
        Execute a function with interactive confirmation on policy violation
        
        Args:
            policy_id: Policy to check
            func: Function to execute
            func_args: Positional arguments to pass to func
            func_kwargs: Keyword arguments to pass to func
            context: Additional context for policy evaluation
            interactive: If True, prompt user; if False, just store token
            reason: Why confirmation needed (from policy decision)
            ttl_seconds: How long to keep pending confirmation
        
        Returns:
            Result of func() if approved, raises PolicyViolation if rejected
        
        Raises:
            PolicyViolation: If policy blocks and user rejects confirmation
        """
        from .exceptions import PolicyViolation
        
        func_kwargs = func_kwargs or {}
        check_context = context or {}
        
        # Attempt to execute function
        try:
            guarded_func = self.guardian.check(policy_id, check_context)(func)
            return guarded_func(*func_args, **func_kwargs)
        
        except PolicyViolation as e:
            reason = reason or str(e)
            
            # Check if this operation allows confirmation
            policy = self.guardian.get_policy(policy_id)
            if not policy.get("requires_confirmation", False):
                raise  # No confirmation available, re-raise
            
            # Create pending confirmation token
            token = str(uuid.uuid4())
            metadata = {
                "policy_id": policy_id,
                "function": func.__name__,
                "reason": reason,
                "context": check_context,
                "args": func_args,
                "kwargs": func_kwargs
            }
            
            self.store.store_pending(token, metadata, ttl_seconds)
            
            # Collect approval
            if interactive:
                approved = InteractiveConfirmation.prompt_user(reason, func.__name__)
                
                if approved:
                    self.store.approve(token)
                else:
                    self.store.reject(token)
                    raise PolicyViolation(f"{reason} (Confirmation rejected)")
            else:
                # Non-interactive: return token for external approval
                raise PolicyViolation(f"{reason} (Requires confirmation token: {token})")
            
            # Retry with confirmation token
            check_context["confirmation_token"] = token
            guarded_func = self.guardian.check(policy_id, check_context)(func)
            return guarded_func(*func_args, **func_kwargs)


__all__ = [
    "ConfirmationStore",
    "MemoryConfirmationStore",
    "RedisConfirmationStore",
    "InteractiveConfirmation",
    "HTTPConfirmationGateway",
    "ConfirmationWorkflow",
]
