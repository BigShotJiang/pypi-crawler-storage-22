"""Execution context for async-safe cross-cutting concerns."""

from hexdag.core.context.execution_context import (
    ExecutionContext,
    clear_execution_context,
    get_current_graph,
    get_current_node_name,
    get_node_results,
    get_observer_manager,
    get_port,
    get_ports,
    get_run_id,
    set_current_graph,
    set_current_node_name,
    set_node_results,
    set_observer_manager,
    set_ports,
    set_run_id,
)

__all__ = [
    "ExecutionContext",
    "clear_execution_context",
    "get_current_graph",
    "get_current_node_name",
    "get_node_results",
    "get_observer_manager",
    "get_port",
    "get_ports",
    "get_run_id",
    "set_current_graph",
    "set_current_node_name",
    "set_node_results",
    "set_observer_manager",
    "set_ports",
    "set_run_id",
]
