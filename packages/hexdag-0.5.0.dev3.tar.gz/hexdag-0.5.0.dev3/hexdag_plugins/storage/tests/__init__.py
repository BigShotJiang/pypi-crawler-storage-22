"""Tests for hexdag-storage."""
