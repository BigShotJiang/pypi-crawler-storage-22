"""Google Antigravity OAuth (Cloud Code Assist sandbox) auth module."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlencode

import httpx

from core.auth.utils import advisory_lock_key, generate_pkce, needs_refresh, now_ms

# Constants (from OpenClaw extensions/google-antigravity-auth/index.ts)
GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
GOOGLE_USERINFO_URL = "https://www.googleapis.com/oauth2/v1/userinfo?alt=json"

ANTIGRAVITY_REDIRECT_URI = "http://localhost:51121/oauth-callback"
ANTIGRAVITY_DEFAULT_PROJECT_ID = "rising-fact-p41fc"

# Extra scopes beyond Gemini CLI
ANTIGRAVITY_SCOPES = [
    "https://www.googleapis.com/auth/cloud-platform",
    "https://www.googleapis.com/auth/userinfo.email",
    "https://www.googleapis.com/auth/userinfo.profile",
    "https://www.googleapis.com/auth/cclog",
    "https://www.googleapis.com/auth/experimentsandconfigs",
]

CODE_ASSIST_ENDPOINTS = [
    "https://cloudcode-pa.googleapis.com",
    "https://daily-cloudcode-pa.sandbox.googleapis.com",
]

ANTIGRAVITY_CONFIG_KEY = "oauth.google_antigravity"
_ANTIGRAVITY_LOCK_KEY = advisory_lock_key(ANTIGRAVITY_CONFIG_KEY)


def _get_client_credentials() -> tuple[str, str]:
    """Resolve client ID and secret from env vars only."""
    client_id = os.getenv("ANTIGRAVITY_OAUTH_CLIENT_ID")
    client_secret = os.getenv("ANTIGRAVITY_OAUTH_CLIENT_SECRET")
    if not client_id or not client_secret:
        raise RuntimeError(
            "Google Antigravity OAuth requires ANTIGRAVITY_OAUTH_CLIENT_ID and "
            "ANTIGRAVITY_OAUTH_CLIENT_SECRET environment variables."
        )
    return client_id, client_secret


@dataclass(frozen=True)
class AntigravityCredentials:
    access: str
    refresh: str
    expires_ms: int
    project_id: str
    email: str | None = None


def build_authorize_url(*, challenge: str, state: str) -> str:
    client_id, _ = _get_client_credentials()
    params = {
        "client_id": client_id,
        "response_type": "code",
        "redirect_uri": ANTIGRAVITY_REDIRECT_URI,
        "scope": " ".join(ANTIGRAVITY_SCOPES),
        "code_challenge": challenge,
        "code_challenge_method": "S256",
        "state": state,
        "access_type": "offline",
        "prompt": "consent",
    }
    return f"{GOOGLE_AUTH_URL}?{urlencode(params)}"


async def exchange_code(*, code: str, verifier: str) -> dict[str, Any]:
    client_id, client_secret = _get_client_credentials()
    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.post(
            GOOGLE_TOKEN_URL,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            data={
                "client_id": client_id,
                "client_secret": client_secret,
                "code": code,
                "grant_type": "authorization_code",
                "redirect_uri": ANTIGRAVITY_REDIRECT_URI,
                "code_verifier": verifier,
            },
        )
    if resp.status_code < 200 or resp.status_code >= 300:
        raise RuntimeError(f"Google Antigravity token exchange failed: HTTP {resp.status_code}: {resp.text}")
    return resp.json()


async def refresh_access_token(refresh_token: str) -> tuple[str, int]:
    client_id, client_secret = _get_client_credentials()
    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.post(
            GOOGLE_TOKEN_URL,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            data={
                "client_id": client_id,
                "client_secret": client_secret,
                "grant_type": "refresh_token",
                "refresh_token": refresh_token,
            },
        )
    if resp.status_code < 200 or resp.status_code >= 300:
        raise RuntimeError(f"Google Antigravity token refresh failed: HTTP {resp.status_code}: {resp.text}")
    data = resp.json()
    access = data.get("access_token")
    expires_in = data.get("expires_in", 3600)
    if not isinstance(access, str):
        raise RuntimeError("Google Antigravity token refresh: missing access_token.")
    return access, now_ms() + int(expires_in) * 1000


async def fetch_user_email(access_token: str) -> str | None:
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(
                GOOGLE_USERINFO_URL,
                headers={"Authorization": f"Bearer {access_token}"},
            )
        if resp.status_code == 200:
            return resp.json().get("email")
    except Exception:
        pass
    return None


async def discover_project(access_token: str) -> str:
    """Try Cloud Code Assist endpoints, fall back to default project."""
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
        "User-Agent": "google-api-nodejs-client/9.15.1",
        "X-Goog-Api-Client": "google-cloud-sdk vscode_cloudshelleditor/0.1",
        "Client-Metadata": json.dumps({
            "ideType": "IDE_UNSPECIFIED",
            "platform": "PLATFORM_UNSPECIFIED",
            "pluginType": "GEMINI",
        }),
    }
    body = json.dumps({
        "metadata": {
            "ideType": "IDE_UNSPECIFIED",
            "platform": "PLATFORM_UNSPECIFIED",
            "pluginType": "GEMINI",
        },
    })

    for endpoint in CODE_ASSIST_ENDPOINTS:
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                resp = await client.post(
                    f"{endpoint}/v1internal:loadCodeAssist",
                    headers=headers,
                    content=body,
                )
            if resp.status_code == 200:
                data = resp.json()
                project = data.get("cloudaicompanionProject")
                if isinstance(project, str):
                    return project
                if isinstance(project, dict) and project.get("id"):
                    return project["id"]
        except Exception:
            continue

    return ANTIGRAVITY_DEFAULT_PROJECT_ID


async def complete_login(code: str, verifier: str) -> AntigravityCredentials:
    token_data = await exchange_code(code=code, verifier=verifier)
    access = token_data["access_token"]
    refresh = token_data.get("refresh_token", "")
    expires_in = token_data.get("expires_in", 3600)
    expires_ms = now_ms() + int(expires_in) * 1000

    email = await fetch_user_email(access)
    project_id = await discover_project(access)

    return AntigravityCredentials(
        access=access,
        refresh=refresh,
        expires_ms=expires_ms,
        project_id=project_id,
        email=email,
    )


# ---------------------------------------------------------------------------
# Persistence (filesystem – survives DB resets)
# ---------------------------------------------------------------------------

def credentials_to_dict(creds: AntigravityCredentials) -> dict[str, Any]:
    d: dict[str, Any] = {
        "access": creds.access,
        "refresh": creds.refresh,
        "expires_ms": creds.expires_ms,
        "project_id": creds.project_id,
    }
    if creds.email:
        d["email"] = creds.email
    return d


def credentials_from_value(value: Any) -> AntigravityCredentials | None:
    if value is None:
        return None
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except Exception:
            return None
    if not isinstance(value, dict):
        return None
    access = value.get("access")
    refresh = value.get("refresh", "")
    expires_ms = value.get("expires_ms")
    project_id = value.get("project_id")
    if not isinstance(access, str) or not isinstance(project_id, str):
        return None
    if not isinstance(expires_ms, (int, float)):
        return None
    return AntigravityCredentials(
        access=access,
        refresh=refresh,
        expires_ms=int(expires_ms),
        project_id=project_id,
        email=value.get("email"),
    )


def load_credentials() -> AntigravityCredentials | None:
    from core.auth.store import load_auth
    return credentials_from_value(load_auth(ANTIGRAVITY_CONFIG_KEY))


def save_credentials(creds: AntigravityCredentials) -> None:
    from core.auth.store import save_auth
    save_auth(ANTIGRAVITY_CONFIG_KEY, credentials_to_dict(creds))


def delete_credentials() -> None:
    from core.auth.store import delete_auth
    delete_auth(ANTIGRAVITY_CONFIG_KEY)


async def ensure_fresh_credentials(*, skew_seconds: int = 300) -> AntigravityCredentials:
    from core.auth.store import auth_lock

    with auth_lock(ANTIGRAVITY_CONFIG_KEY):
        creds = load_credentials()
        if not creds:
            raise RuntimeError("Google Antigravity is not configured. Run: `hexis auth google-antigravity login`")
        if not needs_refresh(creds.expires_ms, skew_seconds):
            return creds
        if not creds.refresh:
            raise RuntimeError("Google Antigravity credentials expired and no refresh token. Re-login required.")
        access, expires_ms = await refresh_access_token(creds.refresh)
        refreshed = AntigravityCredentials(
            access=access,
            refresh=creds.refresh,
            expires_ms=expires_ms,
            project_id=creds.project_id,
            email=creds.email,
        )
        save_credentials(refreshed)
        return refreshed
