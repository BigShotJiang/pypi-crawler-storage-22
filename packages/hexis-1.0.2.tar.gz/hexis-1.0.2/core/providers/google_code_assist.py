"""Google Cloud Code Assist SSE streaming client.

Used by ``google-gemini-cli`` and ``google-antigravity`` providers.
Implements the Gemini REST API via SSE (``alt=sse``) as used by Google's
Cloud Code Assist service (not the public Gemini API).
"""

from __future__ import annotations

import json
import uuid
from typing import Any

import httpx

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_GEMINI_CLI_USER_AGENT = "google-api-nodejs-client/9.15.1"
_GEMINI_CLI_API_CLIENT = "google-cloud-sdk"

_ANTIGRAVITY_USER_AGENT = "google-api-nodejs-client/9.15.1"
_ANTIGRAVITY_API_CLIENT = "google-cloud-sdk vscode_cloudshelleditor/0.1"

_CLIENT_METADATA_GEMINI = json.dumps({
    "ideType": "IDE_UNSPECIFIED",
    "platform": "PLATFORM_UNSPECIFIED",
    "pluginType": "GEMINI",
})

_CLIENT_METADATA_ANTIGRAVITY = json.dumps({
    "ideType": "IDE_UNSPECIFIED",
    "platform": "PLATFORM_UNSPECIFIED",
    "pluginType": "GEMINI",
})


# ---------------------------------------------------------------------------
# Message / Tool conversion
# ---------------------------------------------------------------------------

def _convert_messages(messages: list[dict[str, Any]]) -> tuple[str | None, list[dict[str, Any]]]:
    """Convert Chat Completions messages to Gemini ``contents`` format.

    Returns (system_instruction, contents).
    """
    system_parts: list[str] = []
    contents: list[dict[str, Any]] = []

    for msg in messages:
        role = msg.get("role", "")
        content = msg.get("content", "") or ""

        if role == "system":
            if isinstance(content, str) and content.strip():
                system_parts.append(content)
            continue

        if role == "user":
            contents.append({
                "role": "user",
                "parts": [{"text": str(content)}],
            })
            continue

        if role == "assistant":
            parts: list[dict[str, Any]] = []
            if content:
                parts.append({"text": str(content)})
            for tc in msg.get("tool_calls") or []:
                fn = tc.get("function", {})
                args = fn.get("arguments", "{}")
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except Exception:
                        args = {}
                parts.append({
                    "functionCall": {
                        "name": fn.get("name", ""),
                        "args": args,
                    }
                })
            if parts:
                contents.append({"role": "model", "parts": parts})
            continue

        if role == "tool":
            # Tool result → functionResponse
            tool_content = content
            if isinstance(tool_content, str):
                try:
                    tool_content = json.loads(tool_content)
                except Exception:
                    tool_content = {"result": tool_content}
            contents.append({
                "role": "function",
                "parts": [{
                    "functionResponse": {
                        "name": msg.get("name") or msg.get("tool_call_id") or "tool",
                        "response": tool_content if isinstance(tool_content, dict) else {"result": str(tool_content)},
                    }
                }],
            })

    system = "\n\n".join(p for p in system_parts if p.strip()) or None
    return system, contents


def _convert_tools(tools: list[dict[str, Any]] | None) -> list[dict[str, Any]] | None:
    """Convert OpenAI-format tools to Gemini ``functionDeclarations``."""
    if not tools:
        return None
    decls: list[dict[str, Any]] = []
    for tool in tools:
        fn = tool.get("function", {})
        name = fn.get("name")
        if not name:
            continue
        decl: dict[str, Any] = {
            "name": name,
            "description": fn.get("description", ""),
        }
        params = fn.get("parameters")
        if params:
            decl["parameters"] = params
        decls.append(decl)
    if not decls:
        return None
    return [{"functionDeclarations": decls}]


# ---------------------------------------------------------------------------
# Request building
# ---------------------------------------------------------------------------

def _build_headers(access_token: str, project_id: str, *, is_antigravity: bool) -> dict[str, str]:
    headers: dict[str, str] = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
        "User-Agent": _ANTIGRAVITY_USER_AGENT if is_antigravity else _GEMINI_CLI_USER_AGENT,
        "X-Goog-Api-Client": _ANTIGRAVITY_API_CLIENT if is_antigravity else _GEMINI_CLI_API_CLIENT,
    }
    if project_id:
        headers["X-Goog-User-Project"] = project_id
    # Client-Metadata
    headers["Client-Metadata"] = _CLIENT_METADATA_ANTIGRAVITY if is_antigravity else _CLIENT_METADATA_GEMINI
    return headers


def _build_request_body(
    messages: list[dict[str, Any]],
    tools: list[dict[str, Any]] | None,
    *,
    system_prompt: str | None,
    project_id: str,
) -> dict[str, Any]:
    system_from_msgs, contents = _convert_messages(messages)
    gemini_tools = _convert_tools(tools)

    body: dict[str, Any] = {
        "contents": contents,
    }

    # System instruction
    sys_text = system_prompt or system_from_msgs
    if sys_text:
        body["systemInstruction"] = {
            "parts": [{"text": sys_text}],
        }

    if gemini_tools:
        body["tools"] = gemini_tools

    # Generation config
    body["generationConfig"] = {
        "candidateCount": 1,
    }

    return body


def _build_url(endpoint: str, model: str, *, stream: bool) -> str:
    base = endpoint.rstrip("/")
    method = "streamGenerateContent" if stream else "generateContent"
    url = f"{base}/v1internal/{model}:{method}"
    if stream:
        url += "?alt=sse"
    return url


# ---------------------------------------------------------------------------
# SSE parsing
# ---------------------------------------------------------------------------

def _parse_candidates(data: dict[str, Any]) -> tuple[str, list[dict[str, Any]]]:
    """Extract text + tool calls from a Gemini response/chunk."""
    text_parts: list[str] = []
    tool_calls: list[dict[str, Any]] = []

    for candidate in data.get("candidates") or []:
        content = candidate.get("content") or {}
        for part in content.get("parts") or []:
            if "text" in part:
                text_parts.append(part["text"])
            if "functionCall" in part:
                fc = part["functionCall"]
                tool_calls.append({
                    "id": str(uuid.uuid4()),
                    "name": fc.get("name", ""),
                    "arguments": fc.get("args") or {},
                })

    return "".join(text_parts), tool_calls


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

async def google_code_assist_completion(
    endpoint: str,
    access_token: str,
    project_id: str,
    model: str,
    messages: list[dict[str, Any]],
    tools: list[dict[str, Any]] | None,
    *,
    is_antigravity: bool = False,
    system_prompt: str | None = None,
) -> dict[str, Any]:
    """Non-streaming Cloud Code Assist completion."""
    url = _build_url(endpoint, model, stream=False)
    headers = _build_headers(access_token, project_id, is_antigravity=is_antigravity)
    body = _build_request_body(
        messages, tools, system_prompt=system_prompt, project_id=project_id,
    )

    timeout = httpx.Timeout(connect=30.0, read=120.0, write=30.0, pool=30.0)
    async with httpx.AsyncClient(timeout=timeout) as client:
        resp = await client.post(url, headers=headers, json=body)
    if resp.status_code < 200 or resp.status_code >= 300:
        raise RuntimeError(
            f"Google Code Assist request failed: HTTP {resp.status_code}: {resp.text}"
        )

    data = resp.json()
    text, tool_calls = _parse_candidates(data)
    return {"content": text, "tool_calls": tool_calls, "raw": data}


async def stream_google_code_assist_completion(
    endpoint: str,
    access_token: str,
    project_id: str,
    model: str,
    messages: list[dict[str, Any]],
    tools: list[dict[str, Any]] | None,
    *,
    is_antigravity: bool = False,
    system_prompt: str | None = None,
    on_text_delta: Any | None = None,
) -> dict[str, Any]:
    """Streaming Cloud Code Assist completion via SSE.

    Returns the same shape as ``google_code_assist_completion()``.
    Optionally calls ``on_text_delta(text)`` for each text token.
    """
    import asyncio

    url = _build_url(endpoint, model, stream=True)
    headers = _build_headers(access_token, project_id, is_antigravity=is_antigravity)
    body = _build_request_body(
        messages, tools, system_prompt=system_prompt, project_id=project_id,
    )

    all_text: list[str] = []
    all_tool_calls: list[dict[str, Any]] = []

    timeout = httpx.Timeout(connect=30.0, read=120.0, write=30.0, pool=30.0)
    async with httpx.AsyncClient(timeout=timeout) as client:
        async with client.stream("POST", url, headers=headers, json=body) as resp:
            if resp.status_code < 200 or resp.status_code >= 300:
                error_text = await resp.aread()
                raise RuntimeError(
                    f"Google Code Assist request failed: HTTP {resp.status_code}: "
                    f"{error_text.decode('utf-8', errors='replace')}"
                )

            # Parse SSE: each event has `data: {...}` lines
            async for line in resp.aiter_lines():
                if not line.startswith("data: "):
                    continue
                data_str = line[6:].strip()
                if not data_str or data_str == "[DONE]":
                    continue
                try:
                    chunk = json.loads(data_str)
                except Exception:
                    continue

                text, tool_calls = _parse_candidates(chunk)
                if text:
                    all_text.append(text)
                    if on_text_delta:
                        result = on_text_delta(text)
                        if asyncio.iscoroutine(result):
                            await result
                if tool_calls:
                    all_tool_calls.extend(tool_calls)

    return {"content": "".join(all_text), "tool_calls": all_tool_calls, "raw": None}
