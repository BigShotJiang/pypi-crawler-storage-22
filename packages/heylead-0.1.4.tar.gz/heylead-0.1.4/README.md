# 🎯 HeyLead

**Your AI sales rep. One command to fill your pipeline.**

HeyLead is an MCP-native autonomous LinkedIn SDR that runs inside Cursor. No dashboard. No web app. Just chat with your AI and say "find me leads."

> ⚠️ **Alpha** — Under active development. All 5 tools are live. Feedback welcome!

---

## Getting Started (Never used MCP before? Start here!)

MCP (Model Context Protocol) lets AI assistants use external tools. HeyLead is one of those tools — it gives Cursor's AI the ability to do LinkedIn outreach for you.

**You need:** [Cursor](https://cursor.com) (free tier available) — the AI code editor.

> Also works with Claude Code, Windsurf, and any MCP-compatible editor.

### Step 1: Install HeyLead (one click)

[**Install in Cursor**](cursor://anysphere.cursor-deeplink/mcp/install?name=heylead&config=eyJjb21tYW5kIjoidXZ4IiwiYXJncyI6WyJoZXlsZWFkIl19)

Click the link above → Cursor opens → click **Install**. Done.

<details>
<summary>Manual install or using another editor?</summary>

**Cursor (manual):** Settings → MCP → "Add new MCP server" → Name: `heylead`, Command: `uvx heylead`

**Claude Code:** `claude mcp add heylead -- uvx heylead`
</details>

### Step 2: Set up your account

Open Cursor's AI chat (**Cmd+L**) and say:

> **"Set up my HeyLead profile"**

The AI gives you a link → sign in with Google → connect LinkedIn → copy token → paste it back. That's it. ~1 minute, no API keys.

### Step 3: Find leads

```
"Find me CTOs at fintech startups in New York"
"Send outreach to the campaign"
"Check my replies"
"How's my outreach doing?"
```

---

## What It Does

HeyLead gives your AI assistant 5 tools:

| Tool | What it does |
|------|-------------|
| `setup_profile` | Connects your LinkedIn and creates your voice signature — so messages sound like you |
| `create_campaign` | Takes "find me fintech CTOs" and creates a targeted outreach campaign |
| `generate_and_send` | Writes personalized invitations and sends them (or queues for your review) |
| `check_replies` | Checks for new replies, classifies sentiment, surfaces hot leads |
| `show_status` | Your dashboard — stats, acceptance rates, hot leads, account health |

## How It Works

1. **You describe your target** → "Find me freelance consultants who need scheduling tools"
2. **HeyLead finds them** → Searches LinkedIn, scores prospects, builds a campaign
3. **AI writes personalized messages** → Sounds like YOU (voice matching), not a bot
4. **Copilot mode** → Review messages before sending, then switch to Autopilot when ready
5. **You get replies** → HeyLead surfaces hot leads right in your chat

## Requirements

- Cursor (or any MCP-compatible AI editor)
- LinkedIn account (free tier works)
- That's it! No API keys needed.

> **Power users:** If you want to use your own LLM key (Gemini/Claude/OpenAI), you can pass it during setup. But it's completely optional — HeyLead's backend handles AI for you.

## Pricing

| Plan | Price | What you get |
|------|-------|-------------|
| **Free** | $0 | 50 invitations/month, 1 campaign |
| **Pro** | $29/mo | Unlimited invitations, multiple campaigns, follow-ups, RAG knowledge base |

## Privacy

Your data stays on your machine:
- Contacts and messages → local SQLite database
- LinkedIn auth → encrypted locally (AES-256)
- AI calls → routed through HeyLead's backend (Gemini 2.0 Flash) or your own key
- We don't store your messages or contacts on our servers

## Troubleshooting

**"uvx: command not found"**
Install `uv` first: `curl -LsSf https://astral.sh/uv/install.sh | sh` (or `brew install uv` on Mac)

**"MCP server not connecting"**
Restart Cursor after adding the MCP server. Check Settings → MCP — the server should show a green dot.

**"Setup failed" or "LinkedIn not connected"**
Make sure you clicked "Connect LinkedIn Now" on the sign-in page and completed the LinkedIn login. Then run setup again.

**Need help?** Open an [issue](https://github.com/D4umak/heylead/issues) or ask in our Discord.

## Links

- 📦 [PyPI](https://pypi.org/project/heylead/)
- 🐛 [Issues](https://github.com/D4umak/heylead/issues)
- 💬 Discord (coming soon)

## License

MIT (code) — see [LICENSE](LICENSE)

Knowledge base and prompt configurations are proprietary.
