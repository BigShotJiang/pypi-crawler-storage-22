"""HeyLead — MCP-native autonomous LinkedIn SDR."""

__version__ = "0.1.3"
