# hf-vespa-feed

## What This Is

A CLI tool that streams Hugging Face datasets into Vespa's JSON feed format with comprehensive type support. Designed for processing millions of rows efficiently with support for hex-encoded tensors, sparse/mixed tensors, and scalar types. Users define field mappings via YAML config or CLI args, and pipe output directly to `vespa feed -`.

## Core Value

Fast, memory-efficient streaming of HF datasets to Vespa without intermediate files or full dataset loading.

## Current State

**Shipped:** v2.0 (2026-02-03)
**Source code:** 1,788 lines Python
**Tests:** 1,899 lines Python (165 tests)
**Documentation:** 778-line README with type reference
**Tech stack:** Python 3.10+, typer, datasets, orjson, pydantic, tqdm, ruamel.yaml, pytest-benchmark

## v2.0 Delivered

**Hex Tensor Encoding:**
- int8, bfloat16, float32, float64 with IEEE 754 compliance
- Range validation with row-level error context

**Sparse and Mixed Tensors:**
- Sparse tensor (Vespa cells notation) for term weights
- Mixed tensor (blocks notation) for ColBERT-style multi-vectors
- Mixed tensor hex with configurable cell types

**Scalar Types:**
- Position (geo coordinates with range validation)
- Weighted set (key-weight pairs)
- Map (key-value pairs with key stringification)

**Testing Infrastructure:**
- Vespa doc-verified correctness tests
- Round-trip byte pattern validation
- 52 benchmark tests with GitHub Actions CI

## Current Milestone: v2.1 Clean Exit

**Goal:** Fix the "Bad file descriptor" error that appears after successful processing.

**Bug:** After processing completes, users see ugly error messages from HuggingFace's HTTP retry logic even though the process exits successfully. This is confusing and unprofessional.

**Root cause:** The `_cleanup_hf_resources()` function calls `close_session()` which triggers cleanup of HTTP connections in a bad state, causing the error to be printed before `os._exit()` runs.

**Fix approach:**
1. Suppress HuggingFace HTTP logger at module startup
2. Remove counterproductive `close_session()` call from cleanup

## Requirements

### Validated

- ✓ Stream HF dataset to Vespa JSON feed format — v1.0
- ✓ Config-driven field mapping (YAML file or CLI args) — v1.0
- ✓ Column selection (include only specified columns) — v1.0
- ✓ Column renaming (HF column → Vespa field name) — v1.0
- ✓ Type conversion (list → tensor format) — v1.0
- ✓ Auto-increment document ID — v1.0
- ✓ Document ID from dataset column — v1.0
- ✓ Configurable namespace and doctype — v1.0
- ✓ `--limit N` flag for preview — v1.0
- ✓ Configurable error handling (fail/skip) — v1.0
- ✓ Progress indicators and completion statistics — v1.0
- ✓ Use HF cache (no re-download) — v1.0
- ✓ Graceful SIGPIPE handling — v1.0
- ✓ Config bootstrapping from dataset inspection — v1.1
- ✓ Shell completion installation command — v1.1
- ✓ Comprehensive README with usage guide and cookbook — v1.1
- ✓ --num-workers flag for parallel loading — v1.1
- ✓ Converter caching with lru_cache — v1.1
- ✓ Hex tensor encoding (int8, bfloat16, float32, float64) — v2.0
- ✓ Sparse tensor format support — v2.0
- ✓ Mixed tensor format support — v2.0
- ✓ Position (geo) type conversion — v2.0
- ✓ Weighted set type conversion — v2.0
- ✓ Map type conversion — v2.0
- ✓ Throughput benchmarking with pytest-benchmark — v2.0
- ✓ Correctness tests based on Vespa docs examples — v2.0

### Active

- [ ] Clean exit without "Bad file descriptor" error message — v2.1
- [ ] No visible warnings from HF/PyArrow cleanup on exit — v2.1

### Out of Scope

- Field concatenation — defer to v3
- Row filtering — defer to v3
- Default values for missing fields — defer to v3
- DuckDB integration — defer to v3
- GUI or web interface — CLI-only tool

## Context

- Target users work with large HF datasets (millions of rows) and Vespa search infrastructure
- HF datasets library uses Arrow backend, enabling memory-mapped streaming
- Vespa feed CLI handles progress display, so this tool outputs clean JSON only
- Vespa document JSON format: `{"put": "id:ns:type::id", "fields": {...}}`
- HF datasets are cached locally by the library, avoiding redundant downloads

## Constraints

- **Language**: Python — HF datasets library is Python-native, and streaming/Arrow integration is mature
- **Memory**: Must stream, not load entire dataset — millions of rows won't fit in memory
- **Output**: Valid JSONL that `vespa feed -` accepts without modification
- **Dependencies**: Minimize — HF datasets, PyYAML for config, standard library otherwise

## Key Decisions

| Decision | Rationale | Outcome |
|----------|-----------|---------|
| Pure HF datasets (no DuckDB for v1) | Simpler architecture, HF handles column ops natively | ✓ Good |
| YAML config format | Readable, supports nested field definitions | ✓ Good |
| Default ID format `id:doc:doc::N` | Common pattern, namespace/doctype configurable | ✓ Good |
| Error handling as CLI flag | Different use cases need different behavior | ✓ Good |
| Source layout (src/) | Modern Python packaging best practice | ✓ Good |
| Registry pattern for type converters | Extensible design for future converters | ✓ Good |
| TTY-aware progress bar | Prevents progress bar from corrupting piped output | ✓ Good |
| 1-based row numbering in errors | More user-friendly for debugging | ✓ Good |
| ruamel.yaml for YAML generation | Only library supporting comments in output | ✓ Good |
| Explicit install-completion command | Cleaner UX than Typer's default flag | ✓ Good |
| Cache function lookups not results | Prevents memory exhaustion with diverse inputs | ✓ Good |
| Accept num_workers but document streaming limitation | HuggingFace limitation, reserved for future | ✓ Good |
| Int8 validates range before struct.pack | Clear error messages with index/row context | ✓ Good |
| Bfloat16 truncates (not rounds) precision | Matches IEEE 754 bfloat16 behavior | ✓ Good |
| Sparse tensor uses Vespa cells notation | Standard format for single mapped dimension | ✓ Good |
| Mixed tensor blocks reuse hex encoders | Consistent encoding, no code duplication | ✓ Good |
| 10% benchmark regression threshold | Catches regressions without false positives | ✓ Good |

---
*Last updated: 2026-02-03 after v2.1 milestone started*
