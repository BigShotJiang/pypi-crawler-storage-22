# Roadmap: hf-vespa-feed

## Milestones

- **v1.0 MVP** — Phases 1-3 (shipped 2026-02-02)
- **v1.1 User Experience** — Phases 4-7 (shipped 2026-02-03)
- **v2.0 Vespa Types** — Phases 8-11 (shipped 2026-02-03)
- **v2.1 Clean Exit** — Phase 12 (active)

## Phases

<details>
<summary>v1.0 MVP (Phases 1-3) — SHIPPED 2026-02-02</summary>

- [x] Phase 1: Foundation (2/2 plans) — completed 2026-02-02
- [x] Phase 2: Core Streaming (2/2 plans) — completed 2026-02-02
- [x] Phase 3: Configuration (2/2 plans) — completed 2026-02-02

See: `.planning/milestones/v1.0-ROADMAP.md` (if exists)

</details>

<details>
<summary>v1.1 User Experience (Phases 4-7) — SHIPPED 2026-02-03</summary>

- [x] Phase 4: Init Command (1/1 plans) — completed 2026-02-02
- [x] Phase 5: Shell Completion (1/1 plans) — completed 2026-02-03
- [x] Phase 6: Documentation (3/3 plans) — completed 2026-02-03
- [x] Phase 7: Performance (2/2 plans) — completed 2026-02-03

See: `.planning/milestones/v1.1-ROADMAP.md`

</details>

<details>
<summary>v2.0 Vespa Types (Phases 8-11) — SHIPPED 2026-02-03</summary>

- [x] Phase 8: Scalar Types (1/1 plans) — completed 2026-02-03
- [x] Phase 9: Dense Hex Encoding (2/2 plans) — completed 2026-02-03
- [x] Phase 10: Sparse and Mixed Tensors (2/2 plans) — completed 2026-02-03
- [x] Phase 11: Testing and Benchmarks (4/4 plans) — completed 2026-02-03

See: `.planning/milestones/v2.0-ROADMAP.md`

</details>

### v2.1 Clean Exit (Phase 12) — COMPLETE

- [x] Phase 12: Clean Exit (1/1 plans) — completed 2026-02-03

**Phase 12: Clean Exit**

**Goal:** Fix the "Bad file descriptor" error that appears after successful processing.

**Requirements:** EXIT-01, EXIT-02, EXIT-03, EXIT-04

**Success criteria:**
1. Running `hf-vespa-feed ... --limit 1000 > /dev/null` shows no error messages on stderr (only progress bar and completion stats)
2. Process exits with code 0
3. No visible warnings from HF/PyArrow cleanup
4. Existing test `test_feed_does_not_hang_on_exit` passes

**Implementation approach (from research):**
1. Add `logging.getLogger('huggingface_hub.utils._http').setLevel(logging.CRITICAL)` at module top of cli.py
2. Remove `close_session()` call from `_cleanup_hf_resources()` — it triggers the error and isn't needed since `os._exit()` follows
3. Keep existing `os._exit()` — required to prevent hang from HF retry loop
4. Update/fix the existing test to verify clean stderr output

## Progress

**Execution Order:**
Phases execute in numeric order: 1 -> 2 -> 3 -> 4 -> 5 -> 6 -> 7 -> 8 -> 9 -> 10 -> 11 -> 12

| Phase | Milestone | Plans Complete | Status | Completed |
|-------|-----------|----------------|--------|-----------|
| 1. Foundation | v1.0 | 2/2 | Complete | 2026-02-02 |
| 2. Core Streaming | v1.0 | 2/2 | Complete | 2026-02-02 |
| 3. Configuration | v1.0 | 2/2 | Complete | 2026-02-02 |
| 4. Init Command | v1.1 | 1/1 | Complete | 2026-02-02 |
| 5. Shell Completion | v1.1 | 1/1 | Complete | 2026-02-03 |
| 6. Documentation | v1.1 | 3/3 | Complete | 2026-02-03 |
| 7. Performance | v1.1 | 2/2 | Complete | 2026-02-03 |
| 8. Scalar Types | v2.0 | 1/1 | Complete | 2026-02-03 |
| 9. Dense Hex Encoding | v2.0 | 2/2 | Complete | 2026-02-03 |
| 10. Sparse and Mixed Tensors | v2.0 | 2/2 | Complete | 2026-02-03 |
| 11. Testing and Benchmarks | v2.0 | 4/4 | Complete | 2026-02-03 |
| 12. Clean Exit | v2.1 | 1/1 | Complete | 2026-02-03 |

---
*Roadmap created: 2026-02-02*
*Last updated: 2026-02-03 after phase 12 complete*
