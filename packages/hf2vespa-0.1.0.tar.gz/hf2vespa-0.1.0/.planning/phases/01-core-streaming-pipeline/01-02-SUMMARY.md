---
phase: 01-core-streaming-pipeline
plan: 02
subsystem: pipeline
tags: [huggingface, datasets, streaming, vespa, orjson, typer, cli]

# Dependency graph
requires:
  - phase: 01-01
    provides: Project structure, dependencies, CLI entry point
provides:
  - Streaming pipeline for HF datasets to Vespa JSONL format
  - CLI with column filtering and renaming
  - SIGPIPE handling for clean pipe exit
  - Vespa document ID generation
affects: [02-config-mapping, 03-production-hardening]

# Tech tracking
tech-stack:
  added: [datasets streaming API, orjson serialization]
  patterns: [Generator-based streaming architecture, CLI option patterns with Typer]

key-files:
  created:
    - src/hf_vespa_feed/utils.py
    - src/hf_vespa_feed/pipeline.py
  modified:
    - src/hf_vespa_feed/cli.py

key-decisions:
  - "Added config parameter for datasets requiring configuration (e.g., glue/ax)"
  - "Generator pipeline architecture for constant O(1) memory usage"
  - "Flush every 100 records for streaming UX feedback"
  - "Parse rename as 'old:new' format with validation"

patterns-established:
  - "Generator chaining: stream_dataset() -> format_vespa_put() -> stdout"
  - "SIGPIPE context manager pattern for clean pipe exits"
  - "Vespa ID format: id:namespace:doctype::N with auto-increment"

# Metrics
duration: 4.87min
completed: 2026-02-01
---

# Phase 01 Plan 02: Core Streaming Pipeline Summary

**CLI tool streaming HuggingFace datasets to Vespa JSONL with column filtering, renaming, and configurable document IDs**

## Performance

- **Duration:** 4.87 min
- **Started:** 2026-02-01T18:35:05Z
- **Completed:** 2026-02-01T18:39:57Z
- **Tasks:** 3
- **Files modified:** 3

## Accomplishments
- Complete streaming pipeline from HuggingFace datasets to Vespa JSONL format
- CLI supports all Phase 1 requirements: streaming, column ops, ID customization
- O(1) memory usage with generator-based architecture
- Clean exit handling when piped to head/tail
- HuggingFace dataset caching automatic

## Task Commits

Each task was committed atomically:

1. **Task 1: Implement utility functions for SIGPIPE and ID generation** - `c98415d` (feat)
2. **Task 2: Implement streaming pipeline with Vespa formatting** - `d465294` (feat)
3. **Task 3: Implement CLI with Typer app and all options** - `7e365ae` (feat)

## Files Created/Modified
- `src/hf_vespa_feed/utils.py` - SIGPIPE context manager and Vespa ID generation
- `src/hf_vespa_feed/pipeline.py` - Generator pipeline for streaming with column ops
- `src/hf_vespa_feed/cli.py` - Full Typer CLI with all streaming options

## Decisions Made

**1. Added config parameter for HuggingFace datasets**
- **Rationale:** Some datasets like "glue" require a configuration name (e.g., "ax", "cola"). Added optional `--config` parameter to support these datasets.
- **Impact:** Makes tool more flexible for multi-config datasets.

**2. Flush stdout every 100 records**
- **Rationale:** Provides streaming feedback to users without excessive syscalls.
- **Impact:** Better UX for long-running streams.

**3. Parse rename as 'old:new' string format**
- **Rationale:** Simple, intuitive CLI syntax. Validates format and provides clear error messages.
- **Impact:** User-friendly rename interface.

## Deviations from Plan

**1. [Rule 2 - Missing Critical] Added config parameter to stream_dataset()**
- **Found during:** Task 2 (Implementing streaming pipeline)
- **Issue:** HuggingFace datasets like "glue" require a config name to load. Plan didn't account for multi-config datasets.
- **Fix:** Added `config: str | None = None` parameter to `stream_dataset()` and corresponding `--config` CLI option. Updated load_dataset() call to pass config as second positional argument.
- **Files modified:** src/hf_vespa_feed/pipeline.py, src/hf_vespa_feed/cli.py
- **Verification:** Successfully streamed glue/ax dataset with `--config ax`
- **Committed in:** d465294, 7e365ae (Task 2 and 3 commits)

---

**Total deviations:** 1 auto-fixed (missing critical functionality)
**Impact on plan:** Essential for supporting common HuggingFace datasets. No scope creep - config parameter aligns with plan's goal of streaming arbitrary HF datasets.

## Issues Encountered
None - all planned functionality implemented successfully.

## User Setup Required
None - no external service configuration required.

## Verification Results

All Phase 1 requirements verified:

- **STRM-01:** Outputs valid JSONL lines ✓
- **STRM-02:** Each line has "put" and "fields" keys ✓
- **STRM-03:** HuggingFace cache used automatically ✓
- **STRM-04:** Clean exit when piped to head (no BrokenPipeError) ✓
- **DOCID-01:** IDs auto-increment (::0, ::1, ::2...) ✓
- **DOCID-02:** Custom namespace/doctype via CLI options ✓
- **FMAP-01:** Column filtering with --include ✓
- **FMAP-02:** Column renaming with --rename old:new ✓

**Integration test passed:**
```bash
hf-vespa-feed glue --split test --config ax \
  --include premise --include hypothesis \
  --rename premise:text \
  --namespace test --doctype doc | head -5
```
Output: Valid Vespa JSONL with id:test:doc::{0..4}, fields contain "text" and "hypothesis"

## Next Phase Readiness

**Ready for Phase 2 (Config & Advanced Mapping):**
- Core streaming pipeline complete
- CLI interface established
- All Phase 1 requirements satisfied

**Foundation for Phase 2:**
- YAML config can build on existing CLI options
- Nested field mapping will extend current column operations
- Type mapping can wrap format_vespa_put() generator

**No blockers identified.**

---
*Phase: 01-core-streaming-pipeline*
*Completed: 2026-02-01*
