# Phase 1: Core Streaming Pipeline - Research

**Researched:** 2026-02-01
**Domain:** Python CLI streaming data pipeline (HuggingFace to Vespa)
**Confidence:** HIGH

## Summary

This phase builds a Python CLI tool that streams HuggingFace datasets to stdout in Vespa JSONL format. The research covers the standard stack (Typer, HuggingFace datasets, orjson, PyYAML, Pydantic v2), streaming architecture patterns using generator pipelines, and critical implementation details for production-quality CLI tools.

The standard approach for this type of tool is:
- **Typer 0.21.1** for CLI with rich terminal output and type-safe arguments/options
- **HuggingFace datasets 4.5.0** with streaming=True for O(1) memory usage
- **orjson 3.11.6** for 10-15x faster JSON serialization with OPT_APPEND_NEWLINE for JSONL
- **Generator pipeline architecture** for constant memory usage regardless of dataset size
- **Proper SIGPIPE handling** via BrokenPipeError exception handling for graceful exits when piped

The Vespa feed format is straightforward: each line is `{"put": "id:namespace:doctype::N", "fields": {...}}` where fields contains the actual data. Column selection and renaming in HuggingFace datasets is handled natively via `select_columns()`, `rename_columns()`, and `remove_columns()` methods on IterableDataset.

**Primary recommendation:** Use generator pipeline pattern with IterableDataset.map() for transformations, orjson.dumps() with OPT_APPEND_NEWLINE for output, and wrap main() in try/except for BrokenPipeError to handle SIGPIPE gracefully.

## Standard Stack

The established libraries/tools for Python CLI streaming pipelines:

### Core
| Library | Version | Purpose | Why Standard |
|---------|---------|---------|--------------|
| typer | 0.21.1 | CLI framework | Type-safe args/options via Python type hints, auto-completion, rich output, 102M+ monthly downloads |
| datasets | 4.5.0 | HuggingFace datasets access | Official library, streaming support, built-in caching, column operations, 4.5.0 released Jan 2026 |
| orjson | 3.11.6 | Fast JSON serialization | 10-15x faster than stdlib json, native bytes output, OPT_APPEND_NEWLINE for JSONL, released Jan 2026 |

### Supporting
| Library | Version | Purpose | When to Use |
|---------|---------|---------|-------------|
| pydantic | 2.12.5+ | Config validation | Validating YAML config files with type safety and clear error messages |
| pyyaml | 6.0.3 | YAML parsing | Loading configuration files, standard library for YAML in Python |

### Alternatives Considered
| Instead of | Could Use | Tradeoff |
|------------|-----------|----------|
| typer | click | Click is more flexible but requires more boilerplate; Typer provides better DX with type hints |
| orjson | stdlib json | stdlib json is 10-15x slower but has no external dependencies |
| typer | argparse | argparse is stdlib but verbose and lacks auto-completion; Typer is more modern |

**Installation:**
```bash
pip install typer[all] datasets orjson pyyaml pydantic
```

Or in pyproject.toml:
```toml
[project]
dependencies = [
    "typer[all]>=0.21.0",
    "datasets>=4.5.0",
    "orjson>=3.11.0",
    "pyyaml>=6.0.0",
    "pydantic>=2.12.0",
]
```

## Architecture Patterns

### Recommended Project Structure
```
hf-vespa-feed/
├── pyproject.toml           # Project metadata and dependencies
├── README.md
└── src/
    └── hf_vespa_feed/
        ├── __init__.py
        ├── __main__.py      # Enables python -m hf_vespa_feed
        ├── cli.py           # Typer app and main CLI entry point
        ├── models.py        # Pydantic models for config validation
        ├── pipeline.py      # Generator pipeline functions
        └── utils.py         # Helper functions (ID generation, etc.)
```

**Source:** [Creating and packaging command-line tools - Python Packaging User Guide](https://packaging.python.org/en/latest/guides/creating-command-line-tools/)

### Pattern 1: Generator Pipeline for O(1) Memory

**What:** Chain generators together where each yields one item at a time, enabling streaming processing with constant memory usage regardless of dataset size.

**When to use:** Always for streaming large datasets. Each transformation (load, select columns, rename, format) should be a generator function.

**Example:**
```python
# Source: Multiple sources on generator patterns, synthesized pattern
from datasets import load_dataset
from typing import Generator, Dict, Any

def load_streaming_dataset(dataset_name: str, split: str = "train") -> Generator[Dict[str, Any], None, None]:
    """Load dataset in streaming mode and yield records."""
    dataset = load_dataset(dataset_name, split=split, streaming=True)
    for record in dataset:
        yield record

def select_and_rename_columns(
    records: Generator[Dict[str, Any], None, None],
    include: list[str] | None = None,
    rename: dict[str, str] | None = None
) -> Generator[Dict[str, Any], None, None]:
    """Select and rename columns on the fly."""
    for record in records:
        # Select columns
        if include:
            record = {k: v for k, v in record.items() if k in include}

        # Rename columns
        if rename:
            record = {rename.get(k, k): v for k, v in record.items()}

        yield record

def format_vespa_put(
    records: Generator[Dict[str, Any], None, None],
    namespace: str,
    doctype: str
) -> Generator[Dict[str, Any], None, None]:
    """Wrap records in Vespa put format with auto-increment IDs."""
    for idx, record in enumerate(records):
        yield {
            "put": f"id:{namespace}:{doctype}::{idx}",
            "fields": record
        }
```

**Key insight:** Generator pipelines provide O(1) memory complexity and allow the pipeline to start producing output immediately without waiting for all data to be loaded.

### Pattern 2: HuggingFace Datasets Native Operations

**What:** Use IterableDataset's built-in methods for column operations instead of manual filtering.

**When to use:** When working with HuggingFace datasets in streaming mode, prefer native operations as they're optimized and well-tested.

**Example:**
```python
# Source: https://huggingface.co/docs/datasets/stream
from datasets import load_dataset

# Load with streaming
dataset = load_dataset('squad', split='train', streaming=True)

# Select only specific columns (more efficient than manual filtering)
dataset = dataset.select_columns(['context', 'question'])

# Rename columns
dataset = dataset.rename_columns({
    'context': 'text',
    'question': 'query'
})

# Remove unwanted columns
dataset = dataset.remove_columns(['id'])

# Now iterate - all operations are applied lazily
for record in dataset:
    print(record)  # Only has 'text' and 'query' fields
```

### Pattern 3: Typer CLI with Multiple Values Options

**What:** Use `list[str]` type annotation with `typer.Option()` to allow users to specify an option multiple times.

**When to use:** For column selection where users need to specify multiple columns (--include col1 --include col2).

**Example:**
```python
# Source: https://typer.tiangolo.com/tutorial/multiple-values/multiple-options/
from typing import Annotated
import typer

app = typer.Typer()

@app.command()
def main(
    dataset: str,
    include: Annotated[list[str] | None, typer.Option(help="Columns to include (can be specified multiple times)")] = None,
    rename: Annotated[list[str] | None, typer.Option(help="Rename columns as 'old:new' (can be specified multiple times)")] = None,
    namespace: Annotated[str, typer.Option(help="Vespa namespace")] = "doc",
    doctype: Annotated[str, typer.Option(help="Vespa document type")] = "doc",
):
    """Stream HuggingFace dataset to Vespa JSONL format."""
    # Parse rename mappings
    rename_map = {}
    if rename:
        for mapping in rename:
            old, new = mapping.split(':', 1)
            rename_map[old] = new

    # Process dataset...
```

### Pattern 4: orjson JSONL Streaming to stdout

**What:** Use orjson.dumps() with OPT_APPEND_NEWLINE and write bytes directly to sys.stdout.buffer.

**When to use:** Always for JSONL output - it's 10-15x faster than stdlib json and returns bytes directly.

**Example:**
```python
# Source: https://github.com/ijl/orjson README
import sys
import orjson

def write_jsonl(records):
    """Write records as JSONL to stdout."""
    for record in records:
        # orjson.dumps returns bytes, OPT_APPEND_NEWLINE adds \n
        json_bytes = orjson.dumps(record, option=orjson.OPT_APPEND_NEWLINE)
        sys.stdout.buffer.write(json_bytes)

        # Optional: flush every N records for better streaming UX
        # (user sees output sooner when piped to other tools)
```

### Pattern 5: SIGPIPE Handling with Context Manager

**What:** Wrap main logic in try/except to catch BrokenPipeError and redirect remaining output to /dev/null.

**When to use:** Always in CLI tools that output to stdout and may be piped to commands that close early (head, grep).

**Example:**
```python
# Source: https://adamj.eu/tech/2025/07/20/python-fix-brokenpipeerror/
import os
import sys
from contextlib import contextmanager

@contextmanager
def handle_broken_pipe():
    """Handle SIGPIPE gracefully when output is closed early."""
    try:
        yield
        sys.stdout.flush()
    except BrokenPipeError:
        # Redirect remaining output to /dev/null
        devnull = os.open(os.devnull, os.O_WRONLY)
        os.dup2(devnull, sys.stdout.fileno())

def main():
    with handle_broken_pipe():
        # All your output code here
        for record in generate_records():
            print(record)

if __name__ == "__main__":
    main()
```

### Pattern 6: Entry Points in pyproject.toml

**What:** Define console_scripts entry point to make CLI command available after pip install.

**When to use:** Always for distributable CLI tools.

**Example:**
```toml
# Source: https://packaging.python.org/en/latest/guides/creating-command-line-tools/
[project]
name = "hf-vespa-feed"
version = "0.1.0"

[project.scripts]
hf-vespa-feed = "hf_vespa_feed.cli:app"

[build-system]
requires = ["setuptools>=61.0"]
build-backend = "setuptools.build_meta"
```

### Anti-Patterns to Avoid

- **Loading entire dataset into memory**: Never use `dataset.to_dict()` or collect all records into a list. Always use streaming=True and iterate with generators.
- **Using stdlib json for large-scale output**: 10-15x slower than orjson. For a streaming tool outputting thousands/millions of records, this compounds quickly.
- **Setting SIGPIPE to SIG_DFL**: This causes unexpected exits and breaks socket connections. Use BrokenPipeError exception handling instead.
- **Manual column filtering in Python**: HuggingFace datasets provides `select_columns()` and `remove_columns()` which are optimized and should be preferred.
- **Buffering all output**: Flush periodically (e.g., every 100 records) for better streaming UX so users see output immediately when piped.

## Don't Hand-Roll

Problems that look simple but have existing solutions:

| Problem | Don't Build | Use Instead | Why |
|---------|-------------|-------------|-----|
| JSON serialization | Custom JSON encoder | orjson | 10-15x faster, handles datetime/numpy/dataclasses, well-tested, 820 MB/s throughput |
| CLI argument parsing | Manual sys.argv parsing | Typer | Type safety, auto-completion, validation, help generation, 102M monthly downloads |
| SIGPIPE handling | Signal handlers, ignoring errors | BrokenPipeError exception with context manager | Python's default SIGPIPE translation to exception is the right approach; signal handlers can break socket connections |
| Dataset caching | Custom cache logic | HuggingFace datasets built-in cache | Automatic, fingerprint-based, handles concurrent access, configurable via HF_HOME |
| Column selection | Manual dict filtering in loop | IterableDataset.select_columns() | Optimized, consistent with HF API, less error-prone |
| YAML validation | Manual type checking | Pydantic v2 models | Comprehensive validation, clear error messages, type safety, supports complex schemas |

**Key insight:** The Python CLI streaming ecosystem has mature, battle-tested solutions for all common operations. Custom implementations are slower, more bug-prone, and harder to maintain.

## Common Pitfalls

### Pitfall 1: Not Flushing stdout in Streaming Context

**What goes wrong:** User pipes output to another command and sees no data for a long time, or output comes in large chunks instead of streaming smoothly.

**Why it happens:** By default, stdout is fully buffered when piped (not connected to TTY), so data accumulates in buffer until it's full (usually 4KB-8KB).

**How to avoid:** Flush sys.stdout periodically (e.g., every 100 records) or after each record if real-time output is critical.

```python
import sys

count = 0
for record in records:
    sys.stdout.buffer.write(orjson.dumps(record, option=orjson.OPT_APPEND_NEWLINE))
    count += 1
    if count % 100 == 0:
        sys.stdout.flush()
```

**Warning signs:** Users report "tool seems to hang" or "nothing happens for a while then lots of output at once."

**Source:** [Python Flush STDOUT: A Comprehensive Guide](https://coderivers.org/blog/python-flush-stdout/)

### Pitfall 2: Forgetting streaming=True in load_dataset

**What goes wrong:** Tool tries to download entire dataset (could be terabytes), waits forever, or runs out of disk space.

**Why it happens:** HuggingFace datasets defaults to downloading and caching the entire dataset when streaming=True is not specified.

**How to avoid:** Always use `streaming=True` for CLI streaming tools:

```python
# WRONG - downloads entire dataset
dataset = load_dataset('squad', split='train')

# RIGHT - streams data on-demand
dataset = load_dataset('squad', split='train', streaming=True)
```

**Warning signs:** Unexpected network activity, long startup time, disk space usage, memory growth.

**Source:** [HuggingFace Datasets Streaming Documentation](https://huggingface.co/docs/datasets/stream)

### Pitfall 3: Ignoring BrokenPipeError

**What goes wrong:** Tool crashes with traceback when piped to `head` or when user closes pipe early. Poor user experience.

**Why it happens:** When downstream process closes pipe (e.g., `head -n 10` after seeing 10 lines), writing to stdout raises BrokenPipeError.

**How to avoid:** Wrap main logic in try/except to catch BrokenPipeError and exit cleanly:

```python
import os
import sys

try:
    for record in generate_records():
        sys.stdout.buffer.write(orjson.dumps(record, option=orjson.OPT_APPEND_NEWLINE))
    sys.stdout.flush()
except BrokenPipeError:
    # Redirect to /dev/null to avoid second BrokenPipeError on cleanup
    devnull = os.open(os.devnull, os.O_WRONLY)
    os.dup2(devnull, sys.stdout.fileno())
```

**Warning signs:** Users report crashes when piping to `head`, `grep`, or pressing Ctrl+C on downstream process.

**Source:** [Python Fix BrokenPipeError](https://adamj.eu/tech/2025/07/20/python-fix-brokenpipeerror/)

### Pitfall 4: Manual Column Selection Without Using Native Methods

**What goes wrong:** Code is slower, more verbose, and misses optimization opportunities like Parquet column pruning.

**Why it happens:** Developers aren't aware of IterableDataset's built-in column operations or fall back to manual Python dict filtering.

**How to avoid:** Use native methods which are lazy and optimized:

```python
# WRONG - manual filtering, not optimized
for record in dataset:
    filtered = {k: v for k, v in record.items() if k in columns}
    yield filtered

# RIGHT - uses native optimization
dataset = dataset.select_columns(columns)
for record in dataset:
    yield record
```

**Warning signs:** Slow performance on Parquet datasets, verbose code, unexpected memory usage.

**Source:** [HuggingFace Datasets Stream Documentation](https://huggingface.co/docs/datasets/stream)

### Pitfall 5: Using String Formatting for Document IDs

**What goes wrong:** IDs may contain characters that need escaping in Vespa ID format, or inconsistent ID generation leads to duplicate/invalid IDs.

**Why it happens:** Developer uses f-strings or .format() without considering Vespa ID format rules.

**How to avoid:** Use a dedicated ID generation function that validates format:

```python
def generate_vespa_id(namespace: str, doctype: str, key: str | int) -> str:
    """Generate valid Vespa document ID.

    Format: id:namespace:doctype::key
    """
    # Validate namespace and doctype don't contain invalid chars
    if ':' in namespace or ':' in doctype:
        raise ValueError("Namespace and doctype cannot contain ':'")

    return f"id:{namespace}:{doctype}::{key}"
```

**Warning signs:** Vespa feed errors about invalid document IDs, duplicate key errors.

**Source:** [Vespa Document JSON Format](https://docs.vespa.ai/en/reference/schemas/document-json-format.html)

### Pitfall 6: Not Testing with Actual vespa feed Command

**What goes wrong:** JSON output looks correct but fails when fed to Vespa due to subtle format issues.

**Why it happens:** Developer tests by printing to terminal or redirecting to file, but doesn't test actual integration with `vespa feed`.

**How to avoid:** Always test with the actual command:

```bash
# Test streaming to head
hf-vespa-feed squad --split train | head -n 10

# Test feeding to Vespa
hf-vespa-feed squad --split train | vespa feed -

# Test with column selection
hf-vespa-feed squad --include context --include question | head -n 5
```

**Warning signs:** JSON looks correct visually but Vespa rejects documents.

**Source:** [Vespa CLI Documentation](https://docs.vespa.ai/en/reference/vespa-cli/vespa_feed.html)

## Code Examples

Verified patterns from official sources:

### Complete Streaming Pipeline

```python
# Source: Synthesized from HuggingFace docs and best practices
import sys
import os
from typing import Annotated
import typer
import orjson
from datasets import load_dataset

app = typer.Typer()

def handle_sigpipe(func):
    """Decorator to handle SIGPIPE gracefully."""
    def wrapper(*args, **kwargs):
        try:
            result = func(*args, **kwargs)
            sys.stdout.flush()
            return result
        except BrokenPipeError:
            devnull = os.open(os.devnull, os.O_WRONLY)
            os.dup2(devnull, sys.stdout.fileno())
    return wrapper

@app.command()
@handle_sigpipe
def main(
    dataset_name: str,
    split: Annotated[str, typer.Option(help="Dataset split to use")] = "train",
    include: Annotated[list[str] | None, typer.Option(help="Columns to include")] = None,
    namespace: Annotated[str, typer.Option(help="Vespa namespace")] = "doc",
    doctype: Annotated[str, typer.Option(help="Vespa document type")] = "doc",
):
    """Stream HuggingFace dataset to Vespa JSONL format."""
    # Load dataset in streaming mode
    dataset = load_dataset(dataset_name, split=split, streaming=True)

    # Apply column selection if specified
    if include:
        dataset = dataset.select_columns(include)

    # Stream records with Vespa format
    count = 0
    for record in dataset:
        vespa_doc = {
            "put": f"id:{namespace}:{doctype}::{count}",
            "fields": record
        }

        # Write as JSONL
        json_bytes = orjson.dumps(vespa_doc, option=orjson.OPT_APPEND_NEWLINE)
        sys.stdout.buffer.write(json_bytes)

        count += 1
        # Flush periodically for streaming UX
        if count % 100 == 0:
            sys.stdout.flush()

if __name__ == "__main__":
    app()
```

### Configuration Loading with Pydantic

```python
# Source: https://betterprogramming.pub/validating-yaml-configs-made-easy-with-pydantic-594522612db5
import yaml
from pydantic import BaseModel, Field
from typing import Optional

class FieldMapping(BaseModel):
    """Field mapping configuration."""
    source: str = Field(..., description="Source field name in dataset")
    target: str = Field(..., description="Target field name in Vespa")

class FeedConfig(BaseModel):
    """Configuration for HF to Vespa feed."""
    namespace: str = Field(default="doc", description="Vespa namespace")
    doctype: str = Field(default="doc", description="Vespa document type")
    include_columns: Optional[list[str]] = Field(default=None, description="Columns to include")
    field_mappings: Optional[list[FieldMapping]] = Field(default=None, description="Field renames")

def load_config(config_path: str) -> FeedConfig:
    """Load and validate configuration from YAML file."""
    with open(config_path) as f:
        data = yaml.safe_load(f)
    return FeedConfig.model_validate(data)

# Usage
config = load_config("feed_config.yaml")
```

### Generator Pipeline Pattern

```python
# Source: Synthesized from multiple streaming best practices articles
from typing import Generator, Dict, Any, Callable

def pipeline_stage(func: Callable) -> Callable:
    """Decorator to mark a function as a pipeline stage."""
    def wrapper(*args, **kwargs) -> Generator:
        yield from func(*args, **kwargs)
    return wrapper

@pipeline_stage
def load_records(dataset_name: str, split: str = "train"):
    """Stage 1: Load dataset in streaming mode."""
    from datasets import load_dataset
    dataset = load_dataset(dataset_name, split=split, streaming=True)
    for record in dataset:
        yield record

@pipeline_stage
def transform_columns(records, include=None, rename=None):
    """Stage 2: Select and rename columns."""
    for record in records:
        if include:
            record = {k: v for k, v in record.items() if k in include}
        if rename:
            record = {rename.get(k, k): v for k, v in record.items()}
        yield record

@pipeline_stage
def add_vespa_wrapper(records, namespace: str, doctype: str):
    """Stage 3: Wrap in Vespa put format."""
    for idx, record in enumerate(records):
        yield {
            "put": f"id:{namespace}:{doctype}::{idx}",
            "fields": record
        }

# Chain pipeline stages
records = load_records("squad", "train")
records = transform_columns(records, include=["context", "question"])
records = add_vespa_wrapper(records, "squad", "doc")

# Consume pipeline
for doc in records:
    print(doc)  # Each stage executes lazily
```

## State of the Art

| Old Approach | Current Approach | When Changed | Impact |
|--------------|------------------|--------------|--------|
| datasets without streaming | datasets with streaming=True | v1.18+ (2021) | O(N) to O(1) memory, can handle TB-scale datasets |
| stdlib json | orjson | Available since 2019, matured | 10-15x faster serialization, native bytes output |
| Signal handling for SIGPIPE | BrokenPipeError exception | Python 3.x default | Cleaner, more Pythonic, avoids signal handler issues |
| argparse for CLI | Typer with type hints | Typer 0.3+ (2020+) | Better DX, auto-completion, less boilerplate |
| Manual column filtering | select_columns() + Parquet pruning | datasets 2.0+ (2022) | Faster, especially for Parquet; can skip reading unwanted columns |
| Pydantic v1 | Pydantic v2 | v2.0 (2023) | Much faster validation, better error messages, native Rust core |

**Deprecated/outdated:**
- **datasets.load_dataset() without streaming for large datasets**: Now considered anti-pattern for datasets >10GB
- **Setting SIGPIPE signal handler in Python CLI**: Python's BrokenPipeError approach is standard
- **Manual sys.argv parsing**: Replaced by modern frameworks like Typer/Click
- **json.dumps() for performance-critical serialization**: orjson is now standard for high-throughput JSON

## Open Questions

Things that couldn't be fully resolved:

1. **HuggingFace datasets cache behavior with streaming**
   - What we know: Streaming mode uses HuggingFace Hub cache at ~/.cache/huggingface/hub for downloaded files; datasets library cache for Arrow files not used in pure streaming mode
   - What's unclear: Exact behavior when same streaming dataset is loaded multiple times - does it re-download or use cached data files?
   - Recommendation: Test with network disconnect to verify cache hits; document cache environment variables (HF_HOME, HF_DATASETS_CACHE) for user control

2. **Optimal flush frequency for streaming UX**
   - What we know: Flushing every record is too expensive; never flushing causes large delays; 100 records is a common heuristic
   - What's unclear: Optimal flush frequency depends on record size, network conditions, and downstream processing speed
   - Recommendation: Start with flush every 100 records; make it configurable via environment variable for users to tune; monitor performance impact

3. **Column renaming vs map() for transformations**
   - What we know: IterableDataset.rename_columns() is optimized for simple renames; map() is more flexible for complex transformations
   - What's unclear: Performance implications of chaining multiple rename_columns() calls vs single map() with dict comprehension
   - Recommendation: Use rename_columns() for simple 1:1 renames; use map() for complex field transformations or computed fields

## Sources

### Primary (HIGH confidence)
- [Typer Documentation](https://typer.tiangolo.com/) - CLI framework, type hints, multiple values options
- [HuggingFace Datasets Streaming](https://huggingface.co/docs/datasets/stream) - Streaming API, IterableDataset methods, column operations
- [orjson GitHub](https://github.com/ijl/orjson) - Performance characteristics, OPT_APPEND_NEWLINE usage, bytes output
- [Vespa Document JSON Format](https://docs.vespa.ai/en/reference/schemas/document-json-format.html) - Put operation format, document ID structure
- [Python Packaging Guide - CLI Tools](https://packaging.python.org/en/latest/guides/creating-command-line-tools/) - Project structure, entry points
- [Python Fix BrokenPipeError - Adam Johnson](https://adamj.eu/tech/2025/07/20/python-fix-brokenpipeerror/) - SIGPIPE handling pattern

### Secondary (MEDIUM confidence)
- [Typer CLI Best Practices - Project Rules](https://www.projectrules.ai/rules/typer) - Project structure recommendations
- [Building a Package - Typer](https://typer.tiangolo.com/tutorial/package/) - Distribution and packaging
- [Pydantic YAML Validation - Better Programming](https://betterprogramming.pub/validating-yaml-configs-made-easy-with-pydantic-594522612db5) - Config validation patterns
- [Python Flush STDOUT - CodeRivers](https://coderivers.org/blog/python-flush-stdout/) - Buffering and flush strategies
- [HuggingFace Datasets Cache Management](https://huggingface.co/docs/datasets/cache) - Cache locations and configuration

### Tertiary (LOW confidence)
- Various WebSearch results on generator pipelines, streaming patterns - patterns are well-established but specific implementation details vary

## Metadata

**Confidence breakdown:**
- Standard stack: HIGH - All libraries verified via official PyPI and documentation, versions confirmed as of Jan 2026
- Architecture: HIGH - Generator pipeline pattern and streaming approaches are well-established, documented in official HuggingFace docs
- Pitfalls: HIGH - Common pitfalls identified from official sources, bug reports, and best practice guides with clear solutions
- Vespa format: HIGH - Verified from official Vespa documentation
- Performance claims: MEDIUM - orjson performance numbers from official benchmarks but may vary by use case

**Research date:** 2026-02-01
**Valid until:** 2026-03-01 (30 days - stable domain, library versions shouldn't change significantly)
