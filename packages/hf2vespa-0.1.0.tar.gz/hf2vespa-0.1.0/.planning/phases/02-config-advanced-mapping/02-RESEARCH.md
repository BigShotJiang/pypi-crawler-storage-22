# Phase 2: Config & Advanced Mapping - Research

**Researched:** 2026-02-01
**Domain:** YAML configuration, field mapping, type conversion, CLI validation
**Confidence:** HIGH

## Summary

Phase 2 extends the core streaming pipeline with YAML configuration support, advanced field mapping with type conversions (particularly list-to-tensor for Vespa), custom document ID strategies from dataset columns, and a --limit flag for preview functionality. The research focused on identifying the standard Python stack for config validation, patterns for extensible type conversion, and best practices for fail-fast validation with clear error messages.

The standard approach uses PyYAML with yaml.safe_load() for security, Pydantic BaseModel for schema validation with automatic error messages, and Typer's custom types/callbacks for CLI validation. Type conversion should use a registry pattern for extensibility, allowing users to define conversions like list→tensor in YAML config. Config validation must happen at startup (fail-fast) with field reference validation to catch invalid dataset column references before any streaming begins.

Key architectural decisions: config file is optional (CLI args work standalone), config values are overridden by explicit CLI flags, and type converters form a pluggable registry that can be extended without modifying core code.

**Primary recommendation:** Use Pydantic BaseModel for config schema with field validators, yaml.safe_load() for parsing, and a TypeConverter registry pattern for extensible type transformations.

## Standard Stack

The established libraries/tools for this domain:

### Core
| Library | Version | Purpose | Why Standard |
|---------|---------|---------|--------------|
| PyYAML | 6.0.3+ | YAML parsing | De-facto standard for YAML in Python, battle-tested security with safe_load() |
| Pydantic | 2.12.0+ | Config validation | Industry standard for data validation, excellent error messages, type safety |
| Typer | 0.21.0+ | CLI framework | Already in use (Phase 1), supports custom types and validation callbacks |

### Supporting
| Library | Version | Purpose | When to Use |
|---------|---------|---------|-------------|
| pydantic-yaml | N/A - skip | YAML+Pydantic integration | Not needed - yaml.safe_load() + model_validate() is cleaner |
| click-config-file | N/A - skip | Click config support | Not applicable - using Typer, manual integration is simple |

### Alternatives Considered
| Instead of | Could Use | Tradeoff |
|------------|-----------|----------|
| PyYAML | strictyaml | More restrictive, avoids "Norway problem" but less flexible |
| Pydantic | cerberus/yamale | Schema-based but less Pythonic, weaker typing |
| BaseModel | dataclass + validation | More verbose, manual error handling |

**Installation:**
```bash
# Already in pyproject.toml:
# pyyaml>=6.0.0
# pydantic>=2.12.0
# typer[all]>=0.21.0
```

## Architecture Patterns

### Recommended Project Structure
```
src/hf_vespa_feed/
├── cli.py              # CLI entry point (exists)
├── pipeline.py         # Streaming pipeline (exists)
├── config.py           # NEW: Config schema and validation
├── converters.py       # NEW: Type converter registry
└── utils.py            # Utilities (exists)
```

### Pattern 1: Pydantic Config Schema with YAML
**What:** Define config structure as Pydantic BaseModel, parse YAML, validate in one step
**When to use:** For all config file validation - guarantees type safety and clear errors
**Example:**
```python
# config.py
from pydantic import BaseModel, Field, field_validator
import yaml

class FieldMapping(BaseModel):
    source: str = Field(description="Source column name in dataset")
    target: str = Field(description="Target field name in Vespa")
    type: str | None = Field(None, description="Type conversion (e.g., 'tensor')")

    @field_validator('type')
    @classmethod
    def validate_type(cls, v):
        if v is not None and v not in ['tensor', 'string', 'int']:
            raise ValueError(f"Unknown type: {v}")
        return v

class VespaConfig(BaseModel):
    namespace: str = "doc"
    doctype: str = "doc"
    id_column: str | None = None  # If set, use this dataset column as ID
    mappings: list[FieldMapping] = []

    @classmethod
    def from_yaml(cls, path: str) -> "VespaConfig":
        with open(path) as f:
            data = yaml.safe_load(f)
        return cls.model_validate(data)
```

### Pattern 2: Type Converter Registry
**What:** Pluggable registry mapping type names to converter functions
**When to use:** For extensible type conversions without modifying core code
**Example:**
```python
# converters.py
from typing import Callable, Any

class ConverterRegistry:
    def __init__(self):
        self._converters: dict[str, Callable] = {}

    def register(self, name: str, func: Callable[[Any], Any]):
        """Register a converter function."""
        self._converters[name] = func

    def convert(self, value: Any, type_name: str) -> Any:
        """Apply converter by name."""
        if type_name not in self._converters:
            raise ValueError(f"Unknown converter: {type_name}")
        return self._converters[type_name](value)

# Global registry
converters = ConverterRegistry()

# Built-in converters
def list_to_tensor(value: list) -> dict:
    """Convert Python list to Vespa indexed tensor format."""
    return {"values": value}

converters.register("tensor", list_to_tensor)
```

### Pattern 3: Config + CLI Override
**What:** Config file provides defaults, CLI flags override config values
**When to use:** Standard CLI pattern - config for convenience, flags for control
**Example:**
```python
# cli.py
def main(
    dataset: str,
    config_file: str | None = None,
    namespace: str | None = None,  # Override config
    limit: int | None = None,
):
    # Load config if provided
    config = VespaConfig() if config_file is None else VespaConfig.from_yaml(config_file)

    # CLI flags override config
    if namespace is not None:
        config.namespace = namespace

    # Apply limit by taking first N records
    records = stream_dataset(dataset, ...)
    if limit is not None:
        records = itertools.islice(records, limit)
```

### Pattern 4: Fail-Fast Validation
**What:** Validate config against dataset schema before streaming any records
**When to use:** Always - catch errors at startup, not mid-stream
**Example:**
```python
def validate_config_against_dataset(config: VespaConfig, dataset_info):
    """Validate field mappings reference actual dataset columns."""
    dataset_columns = set(dataset_info.features.keys())

    # Validate id_column exists
    if config.id_column and config.id_column not in dataset_columns:
        raise ValueError(
            f"id_column '{config.id_column}' not found in dataset. "
            f"Available columns: {sorted(dataset_columns)}"
        )

    # Validate mapping sources exist
    for mapping in config.mappings:
        if mapping.source not in dataset_columns:
            raise ValueError(
                f"Mapping source '{mapping.source}' not found in dataset. "
                f"Available columns: {sorted(dataset_columns)}"
            )
```

### Anti-Patterns to Avoid
- **Lazy validation:** Don't validate field references mid-stream - always fail fast at startup
- **Silent type coercion:** Don't guess type conversions - require explicit declaration in config
- **yaml.load() instead of yaml.safe_load():** Security risk - safe_load prevents arbitrary code execution
- **Ignoring ValidationError details:** Pydantic provides excellent error messages - surface them to users
- **Config with no CLI override:** Users need to override config values without editing files

## Don't Hand-Roll

Problems that look simple but have existing solutions:

| Problem | Don't Build | Use Instead | Why |
|---------|-------------|-------------|-----|
| YAML parsing | Custom YAML parser | yaml.safe_load() | Security-hardened, handles edge cases (Norway problem, anchors, types) |
| Data validation | Manual type checking | Pydantic BaseModel | Automatic validation, clear error messages, type hints |
| Nested field access | String splitting "a.b.c" | Use flat structure or pydash | Edge cases (keys with dots, escaping, lists) harder than they look |
| Type coercion | isinstance() chains | Registry pattern | Extensibility - adding types shouldn't modify core code |
| Error formatting | String templates | Pydantic ValidationError | Structured errors with field paths, line numbers, multiple errors |

**Key insight:** Config validation looks trivial until you hit edge cases. PyYAML + Pydantic solve 90% of problems you haven't thought of yet (type mismatches, missing fields, invalid references, nested validation). The 10% you need custom code for is business logic (field existence in dataset), not parsing/validation infrastructure.

## Common Pitfalls

### Pitfall 1: Using yaml.load() Instead of yaml.safe_load()
**What goes wrong:** yaml.load() can execute arbitrary Python code, creating security vulnerabilities
**Why it happens:** yaml.load() is the obvious function name, security implications not clear
**How to avoid:** Always use yaml.safe_load() for untrusted input (user config files)
**Warning signs:** Security scanners flag yaml.load() usage

### Pitfall 2: Validating Field References Too Late
**What goes wrong:** Config references non-existent dataset column, error appears after streaming starts
**Why it happens:** Dataset schema not available until load_dataset() call
**How to avoid:** Load dataset with streaming=True, call dataset.info() to get schema, validate before processing records
**Warning signs:** Errors appearing after "Loading dataset..." message

### Pitfall 3: No Config Override Mechanism
**What goes wrong:** Users can't test different namespaces/limits without editing config file
**Why it happens:** Config file seems like "the source of truth"
**How to avoid:** CLI flags always override config values, config provides defaults only
**Warning signs:** Users maintaining multiple config files for simple variations

### Pitfall 4: Silent Type Conversion Failures
**What goes wrong:** Type converter fails on some records, produces invalid Vespa JSON
**Why it happens:** Not all lists are valid tensors (wrong dimensions, types)
**How to avoid:** Type converters raise ValueError on invalid input, caught and reported with record context
**Warning signs:** Vespa feed fails on some records but not others, no clear error

### Pitfall 5: The Norway Problem
**What goes wrong:** YAML interprets "NO" as boolean False instead of string "NO"
**Why it happens:** YAML 1.1 spec treats YES/NO as booleans
**How to avoid:** PyYAML safe_load() handles this, but be aware for config design (quote strings if ambiguous)
**Warning signs:** Country codes, boolean-like strings appearing as actual booleans

### Pitfall 6: Ignoring Pydantic Validation Errors
**What goes wrong:** ValidationError raised but caught and re-raised as generic error, losing detail
**Why it happens:** Generic exception handling catches ValidationError
**How to avoid:** Let ValidationError propagate to top level, or format errors explicitly with .errors()
**Warning signs:** Error messages say "validation failed" without saying which field or why

## Code Examples

Verified patterns from official sources:

### Loading and Validating YAML Config
```python
# Source: Pydantic docs + PyYAML best practices
import yaml
from pydantic import BaseModel, ValidationError

class VespaConfig(BaseModel):
    namespace: str = "doc"
    doctype: str = "doc"
    id_column: str | None = None

def load_config(path: str) -> VespaConfig:
    """Load and validate YAML config file."""
    try:
        with open(path) as f:
            data = yaml.safe_load(f)  # Always use safe_load
        return VespaConfig.model_validate(data)
    except FileNotFoundError:
        raise ValueError(f"Config file not found: {path}")
    except yaml.YAMLError as e:
        raise ValueError(f"Invalid YAML in {path}: {e}")
    except ValidationError as e:
        # Pydantic provides excellent error formatting
        raise ValueError(f"Invalid config in {path}:\n{e}")
```

### Type Converter with Vespa Tensor Format
```python
# Source: Vespa tensor documentation + research findings
def list_to_indexed_tensor(value: list) -> dict:
    """
    Convert Python list to Vespa indexed tensor format.

    Vespa indexed tensor format for single dimension:
    {"values": [1.0, 2.0, 3.0]}
    """
    if not isinstance(value, list):
        raise ValueError(f"Expected list, got {type(value)}")

    if not value:
        raise ValueError("Cannot convert empty list to tensor")

    # Vespa expects numeric values for tensors
    if not all(isinstance(v, (int, float)) for v in value):
        raise ValueError("Tensor values must be numeric")

    return {"values": value}
```

### Applying Field Mappings with Type Conversion
```python
# Source: Research findings + registry pattern
def apply_mappings(record: dict, mappings: list[FieldMapping], converters: ConverterRegistry) -> dict:
    """Apply field mappings and type conversions to a record."""
    result = {}

    for mapping in mappings:
        if mapping.source not in record:
            raise ValueError(f"Source field '{mapping.source}' not in record")

        value = record[mapping.source]

        # Apply type conversion if specified
        if mapping.type:
            try:
                value = converters.convert(value, mapping.type)
            except Exception as e:
                raise ValueError(
                    f"Type conversion failed for field '{mapping.source}': {e}"
                )

        result[mapping.target] = value

    return result
```

### CLI with --limit Flag
```python
# Source: Typer documentation + Click patterns
import itertools
from typing import Annotated

def main(
    dataset: str,
    limit: Annotated[int | None, typer.Option(help="Process only first N records")] = None,
):
    """Stream dataset with optional limit for preview."""
    records = stream_dataset(dataset, ...)

    # Use itertools.islice for efficient limiting
    if limit is not None:
        if limit <= 0:
            raise typer.BadParameter("--limit must be positive")
        records = itertools.islice(records, limit)

    for record in records:
        # Process record
        pass
```

### Custom ID from Dataset Column
```python
# Source: Research findings
def format_vespa_put_with_config(
    records: Generator[dict, None, None],
    config: VespaConfig,
) -> Generator[dict, None, None]:
    """Format records using config-specified ID strategy."""
    for idx, record in enumerate(records):
        # Use column value as ID if configured
        if config.id_column:
            if config.id_column not in record:
                raise ValueError(
                    f"id_column '{config.id_column}' not in record at index {idx}"
                )
            doc_id = str(record[config.id_column])
            vespa_id = f"id:{config.namespace}:{config.doctype}::{doc_id}"
        else:
            # Fall back to auto-increment
            vespa_id = f"id:{config.namespace}:{config.doctype}::{idx}"

        yield {"put": vespa_id, "fields": record}
```

## State of the Art

| Old Approach | Current Approach | When Changed | Impact |
|--------------|------------------|--------------|--------|
| yaml.load() default | yaml.safe_load() required | PyYAML 5.1 (2019) | Security - prevents code execution |
| Pydantic parse_obj() | model_validate() | Pydantic 2.0 (2023) | Better error messages, clearer API |
| argparse validation | Typer custom types | Ongoing | More declarative, better UX |
| Config-only tools | Config + CLI override | Modern practice | More flexible, better testing |

**Deprecated/outdated:**
- **yaml.load() without Loader:** Deprecated in PyYAML 5.1, removed in 6.0 - always specify safe_load
- **Pydantic parse_obj():** Replaced by model_validate() in Pydantic 2.0
- **click-config-file for Typer:** Not updated for Typer, manual integration cleaner

## Open Questions

Things that couldn't be fully resolved:

1. **Vespa tensor validation depth**
   - What we know: Vespa supports indexed tensors with {"values": [...]} format
   - What's unclear: Whether validation should check tensor dimensions/types against Vespa schema
   - Recommendation: Start with basic format validation, add schema validation in Phase 3 if needed

2. **Config file discovery pattern**
   - What we know: Common patterns are ./vespa-config.yaml or .vespa/config.yaml
   - What's unclear: Whether to auto-discover config or require explicit --config flag
   - Recommendation: Require explicit flag for v1 (simpler, more predictable)

3. **Nested field mapping syntax**
   - What we know: Users might want to map nested fields like "metadata.title"
   - What's unclear: Whether Phase 2 scope includes nested field access
   - Recommendation: Start with flat field mapping, defer nested access to future phase

## Sources

### Primary (HIGH confidence)
- PyYAML 6.0.3 official PyPI page - current version, installation, security notes
- Pydantic official docs - dataclasses, validation, error handling patterns
- Click 8.3.1 GitHub - current version, parameter types, validation
- Vespa documentation - tensor format (search results, though direct fetch failed)

### Secondary (MEDIUM confidence)
- [Working with YAML Files in Python - Better Stack](https://betterstack.com/community/guides/scaling-python/yaml-files-in-python/)
- [A simple guide to configure your Python project with Pydantic and a YAML file - Medium](https://medium.com/@jonathan_b/a-simple-guide-to-configure-your-python-project-with-pydantic-and-a-yaml-file-bef76888f366)
- [PyYAML yaml.load(input) Deprecation - GitHub Wiki](https://github.com/yaml/pyyaml/wiki/PyYAML-yaml.load(input)-Deprecation)
- [Parameter Types - Click Documentation](https://click.palletsprojects.com/en/stable/parameter-types/)
- [Python Registry Pattern - DEV Community](https://dev.to/dentedlogic/stop-writing-giant-if-else-chains-master-the-python-registry-pattern-ldm)
- [Things I've learned about building CLI tools in Python - Simon Willison](https://simonwillison.net/2023/Sep/30/cli-tools-python/)

### Tertiary (LOW confidence)
- Multiple WebSearch results on type conversion patterns (need verification with actual usage)
- Vespa tensor format specifics (official docs exist but WebFetch failed - need manual verification)

## Metadata

**Confidence breakdown:**
- Standard stack: HIGH - PyYAML, Pydantic, Typer are industry standard, well-documented
- Architecture: HIGH - Patterns verified from official docs and established best practices
- Pitfalls: MEDIUM-HIGH - Common issues documented in official sources and community blogs
- Code examples: HIGH - Based on official documentation patterns and verified approaches
- Vespa tensor format: MEDIUM - Found documentation references but need implementation verification

**Research date:** 2026-02-01
**Valid until:** 2026-03-01 (30 days - stable domain, slow-changing APIs)

**Notes for planner:**
- PyYAML and Pydantic already in pyproject.toml (Phase 1 decision)
- Existing CLI uses Typer (not Click) - all patterns adapted accordingly
- Existing pipeline.py has stream_dataset() and format_vespa_put() - extend, don't replace
- Phase 1 uses generator pipeline architecture - maintain for Phase 2
- Focus on fail-fast validation to honor "fail fast with clear errors" success criteria
