# Phase 3: Production Hardening - Research

**Researched:** 2026-02-02
**Domain:** Python CLI error handling, progress reporting, and completion statistics
**Confidence:** HIGH

## Summary

Production hardening for Python CLI data pipelines involves three core concerns: configurable error handling modes (fail-fast vs skip-and-warn), progress visibility during processing, and completion statistics reporting. The Python ecosystem provides mature solutions for all three.

For error handling, the pattern is to wrap generator processing in try-except blocks that either re-raise (fail-fast) or log and continue (skip-and-warn), controlled by a CLI flag implemented as a Python Enum. For progress reporting, tqdm is the standard library with 60ns overhead per iteration, writes to stderr by default, and automatically detects TTY environments. For completion statistics, collections.Counter provides an accumulator pattern perfectly suited to tracking successes/errors/totals, while time.perf_counter_ns() offers nanosecond-precision throughput measurement.

The existing architecture (Typer CLI, generator-based pipeline, stdout for data/stderr for status) aligns perfectly with these patterns. The key implementation challenge is maintaining generator composition while adding error context (row number, field name) to exceptions.

**Primary recommendation:** Use tqdm for progress (disable in non-TTY), collections.Counter for statistics, time.perf_counter_ns() for throughput, and Enum-based --on-error flag controlling try-except behavior in the pipeline generator.

## Standard Stack

The established libraries/tools for this domain:

### Core
| Library | Version | Purpose | Why Standard |
|---------|---------|---------|--------------|
| tqdm | 4.x (latest) | Progress bars and status reporting | Industry standard with 60ns overhead, 30.9k GitHub stars, auto-detects TTY, writes to stderr by default |
| collections.Counter | stdlib (3.x) | Statistics accumulation | Built-in, zero-overhead, perfect for counting successes/errors/totals |
| time.perf_counter_ns | stdlib (3.7+) | High-precision timing | Official Python recommendation for performance measurement, nanosecond precision avoids float loss |
| enum.Enum | stdlib (3.x) | CLI choice restrictions | Typer's native pattern for --on-error flag with automatic validation |

### Supporting
| Library | Version | Purpose | When to Use |
|---------|---------|---------|-------------|
| sys.stderr.isatty() | stdlib | TTY detection | Disable progress bars when output is redirected or piped |
| dataclasses | stdlib (3.7+) | Statistics structure | Optional: wrap Counter in @dataclass for type safety and computed properties |
| rich | 13.x (latest) | Advanced progress UI | Alternative to tqdm if visual enhancement desired (Typer recommends it), but adds dependency |

### Alternatives Considered
| Instead of | Could Use | Tradeoff |
|------------|-----------|----------|
| tqdm | rich.progress | More features and prettier output, but adds dependency (existing tool uses orjson for speed, tqdm aligns with minimal deps) |
| collections.Counter | Manual dict | Counter provides built-in increment, most_common(), total() methods - no reason to hand-roll |
| time.perf_counter_ns | time.time | perf_counter_ns is monotonic and higher resolution, time.time can go backwards with system clock changes |

**Installation:**
```bash
pip install tqdm  # Only new dependency; rest is stdlib
```

## Architecture Patterns

### Recommended Project Structure
```
src/hf_vespa_feed/
├── cli.py              # Add --on-error flag, statistics reporting
├── pipeline.py         # Add error-handling wrapper generator
├── stats.py            # NEW: Statistics accumulator with Counter
├── config.py           # Add error_mode to VespaConfig (optional)
└── utils.py            # Existing handle_broken_pipe stays here
```

### Pattern 1: Configurable Error Handling with Generator Wrapper
**What:** Wrap the existing generator pipeline with error-handling logic controlled by a mode flag.
**When to use:** When you need to preserve generator composition while adding error resilience.
**Example:**
```python
# stats.py
from collections import Counter
from dataclasses import dataclass, field

@dataclass
class ProcessingStats:
    """Accumulator for pipeline statistics."""
    counter: Counter = field(default_factory=Counter)

    def record_success(self) -> None:
        self.counter['success'] += 1

    def record_error(self, error_type: str = 'error') -> None:
        self.counter[error_type] += 1

    @property
    def total_processed(self) -> int:
        return self.counter.total()

    @property
    def error_count(self) -> int:
        return sum(count for key, count in self.counter.items() if key != 'success')

# pipeline.py
from enum import Enum
from typing import Generator
import sys

class ErrorMode(str, Enum):
    fail = "fail"
    skip = "skip"

def with_error_handling(
    records: Generator[dict, None, None],
    error_mode: ErrorMode,
    stats: ProcessingStats,
    operation_name: str = "processing"
) -> Generator[dict, None, None]:
    """
    Wrap a generator with configurable error handling.

    Args:
        records: Source generator
        error_mode: 'fail' re-raises, 'skip' logs and continues
        stats: Statistics accumulator
        operation_name: Description for error messages

    Yields:
        Records that successfully process
    """
    for idx, record in enumerate(records, start=1):
        try:
            # Process happens in caller's generator
            yield record
            stats.record_success()
        except Exception as e:
            error_msg = f"Row {idx} error during {operation_name}: {e}"

            if error_mode == ErrorMode.fail:
                # Re-raise with context
                raise ValueError(error_msg) from e
            else:
                # Log to stderr and continue
                print(error_msg, file=sys.stderr)
                stats.record_error()
                continue

# cli.py usage
from enum import Enum

@app.command()
def main(
    dataset: str,
    on_error: Annotated[ErrorMode, typer.Option(help="Error handling mode")] = ErrorMode.fail,
    # ... other params
):
    stats = ProcessingStats()

    # Existing pipeline
    records = stream_dataset(dataset, split, include, rename, config)
    vespa_docs = format_vespa_put(records, namespace, doctype, config=vespa_config)

    # Wrap with error handling
    resilient_docs = with_error_handling(vespa_docs, on_error, stats, "Vespa formatting")

    # ... write loop with stats
```

### Pattern 2: Progress Reporting with TTY Detection
**What:** Show progress bars to stderr only when running interactively (not piped).
**When to use:** CLI tools that process large datasets and write data to stdout.
**Example:**
```python
import sys
from tqdm import tqdm

# TTY detection
show_progress = sys.stderr.isatty()

# Wrap the output loop
with handle_broken_pipe():
    # Create progress bar wrapper (no-op if not TTY)
    iterator = tqdm(vespa_docs, disable=not show_progress,
                   desc="Processing records", unit="rec", file=sys.stderr)

    for doc in iterator:
        json_bytes = orjson.dumps(doc, option=orjson.OPT_APPEND_NEWLINE)
        sys.stdout.buffer.write(json_bytes)

        # Periodic flush (existing pattern)
        if count % 100 == 0:
            sys.stdout.flush()
```

### Pattern 3: Row-Level Error Context with enumerate
**What:** Track row numbers for error messages using enumerate with 1-based indexing.
**When to use:** Streaming pipelines where you need to report which row failed.
**Example:**
```python
def apply_mappings_with_context(record: dict, mappings: list[FieldMapping], row_num: int) -> dict:
    """Apply mappings with row-level error context."""
    result = {}
    for mapping in mappings:
        try:
            value = record[mapping.source]
            if mapping.type is not None:
                value = converters.convert(value, mapping.type)
            result[mapping.target] = value
        except KeyError as e:
            raise ValueError(f"Row {row_num}: Missing field '{mapping.source}'") from e
        except Exception as e:
            raise ValueError(f"Row {row_num}, field '{mapping.source}': {e}") from e
    return result

# In format_vespa_put, use 1-based row numbering
for row_num, record in enumerate(records, start=1):
    if config is not None and config.mappings:
        fields = apply_mappings_with_context(record, config.mappings, row_num)
    # ...
```

### Pattern 4: Completion Statistics with Throughput
**What:** Report summary statistics at the end, including records/second throughput.
**When to use:** Long-running CLI tools where users want performance feedback.
**Example:**
```python
import sys
import time

def report_completion(stats: ProcessingStats, elapsed_ns: int) -> None:
    """Print completion statistics to stderr."""
    elapsed_sec = elapsed_ns / 1_000_000_000  # nanoseconds to seconds
    total = stats.total_processed
    errors = stats.error_count
    throughput = total / elapsed_sec if elapsed_sec > 0 else 0

    print("\n--- Completion Statistics ---", file=sys.stderr)
    print(f"Total records processed: {total:,}", file=sys.stderr)
    print(f"Successful: {stats.counter['success']:,}", file=sys.stderr)
    print(f"Errors: {errors:,}", file=sys.stderr)
    print(f"Throughput: {throughput:.1f} records/sec", file=sys.stderr)
    print(f"Elapsed time: {elapsed_sec:.2f}s", file=sys.stderr)

# In main()
start = time.perf_counter_ns()

with handle_broken_pipe():
    # ... processing loop with stats
    pass

end = time.perf_counter_ns()
report_completion(stats, end - start)
```

### Anti-Patterns to Avoid
- **Catching all exceptions blindly:** Don't catch `KeyboardInterrupt` or `SystemExit` in the error handler - let them propagate for clean shutdown
- **Progress bars to stdout:** Always use stderr for progress (file=sys.stderr) to avoid corrupting data output
- **Buffering issues:** Don't forget sys.stdout.flush() is still needed even with tqdm (independent streams)
- **Float timing for nanosecond precision:** Use perf_counter_ns(), not perf_counter(), to avoid float precision loss over long runs
- **Zero-based row numbering in errors:** Users expect "Row 1" for the first record, use enumerate(records, start=1)

## Don't Hand-Roll

Problems that look simple but have existing solutions:

| Problem | Don't Build | Use Instead | Why |
|---------|-------------|-------------|-----|
| Progress bars | Custom print-based progress | tqdm | Handles terminal width, TTY detection, rate calculation, ETA prediction, and cleanup automatically |
| Statistics counting | Dict with manual increment | collections.Counter | Missing keys default to 0, provides total(), most_common(), and arithmetic operations (+, -, &, \|) |
| Performance timing | time.time() subtraction | time.perf_counter_ns() | Monotonic clock (won't go backwards), nanosecond precision, designed for benchmarking |
| CLI choice validation | String comparison with if/elif | enum.Enum with Typer | Automatic validation, help text generation, and type safety |
| TTY detection | os.system() checks | sys.stderr.isatty() | Cross-platform, stdlib, instant |

**Key insight:** CLI robustness is a solved problem in Python's standard library and tqdm. The challenge is integration, not implementation. Don't reinvent progress bars, statistics accumulators, or timing - compose the existing tools correctly.

## Common Pitfalls

### Pitfall 1: Generator Error Handling Breaks Composition
**What goes wrong:** Adding try-except inside format_vespa_put breaks the generator chain, or errors bypass the handler entirely.
**Why it happens:** Generators don't execute until consumed. If you wrap the generator creation in try-except, errors in the generator body aren't caught. You must catch errors during iteration (yield).
**How to avoid:** Use a wrapper generator that wraps the *iteration* (with enumerate) and catches during yield, not a try-except around the generator function call.
**Warning signs:** Error handler never executes, or you're forced to materialize the entire generator into a list.

### Pitfall 2: stdout/stderr Buffering Interleaving
**What goes wrong:** Progress bars (stderr) and data (stdout) appear out of order, or progress bar corrupts JSON output.
**Why it happens:** stdout and stderr are independently buffered and may flush at different times, both writing to the same terminal.
**How to avoid:**
1. Always explicitly set file=sys.stderr for tqdm
2. Call sys.stdout.flush() before creating progress bars
3. Keep the existing 100-record flush pattern
**Warning signs:** JSON output contains ANSI escape codes, or progress bar appears after data that should have come later.

### Pitfall 3: Non-TTY Progress Spam
**What goes wrong:** When piped (e.g., | head), progress bar writes hundreds of lines to stderr log files.
**Why it happens:** tqdm defaults to showing progress even when not attached to a terminal.
**How to avoid:** Always use `disable=not sys.stderr.isatty()` to automatically suppress progress when redirected.
**Warning signs:** Log files contain thousands of progress bar update lines, CI logs are unreadable.

### Pitfall 4: Skip Mode Without User Feedback
**What goes wrong:** In skip-and-warn mode, users don't realize errors occurred because they're lost in progress bar output.
**Why it happens:** tqdm overwrites the terminal line where error messages were printed.
**How to avoid:**
1. Use tqdm.write() to print errors through the progress bar
2. Or print errors after closing the progress bar
3. Or keep count and show in final stats
**Warning signs:** Users report "it worked" when actually hundreds of records failed silently.

### Pitfall 5: Float Precision Loss in Long-Running Jobs
**What goes wrong:** Throughput calculation becomes inaccurate after hours of processing.
**Why it happens:** time.perf_counter() returns float seconds, which loses precision at nanosecond scale over long durations.
**How to avoid:** Use time.perf_counter_ns() for integer nanoseconds, only convert to seconds at display time.
**Warning signs:** Throughput shows as 0.0 or NaN after processing millions of records.

### Pitfall 6: Error Context Lost in Generator Chain
**What goes wrong:** Error says "conversion failed" but not which row or field.
**Why it happens:** Exceptions raised deep in apply_mappings() don't know the row number (that's in format_vespa_put's enumerate).
**How to avoid:** Pass row_num as parameter to apply_mappings_with_context(), re-raise with f"Row {row_num}, field '{field}': {e}"
**Warning signs:** Bug reports like "fails on row 45,983" but you can't reproduce because you don't know what record that was.

## Code Examples

Verified patterns from official sources:

### Using tqdm with TTY Detection
```python
# Source: https://github.com/tqdm/tqdm official examples
import sys
from tqdm import tqdm

# Automatic TTY detection
show_progress = sys.stderr.isatty()

# Wrap any iterable
for item in tqdm(iterable, disable=not show_progress, desc="Processing",
                 unit="rec", file=sys.stderr):
    process(item)
```

### collections.Counter for Statistics
```python
# Source: https://docs.python.org/3/library/collections.html
from collections import Counter

c = Counter()
for item in items:
    try:
        process(item)
        c['success'] += 1
    except Exception:
        c['error'] += 1

print(f"Total: {c.total()}, Success: {c['success']}, Errors: {c['error']}")
```

### High-Precision Timing
```python
# Source: https://docs.python.org/3/library/time.html
import time

start = time.perf_counter_ns()
# ... processing ...
end = time.perf_counter_ns()

elapsed_sec = (end - start) / 1_000_000_000
throughput = record_count / elapsed_sec
print(f"Processed {throughput:.1f} records/sec")
```

### Typer Enum for CLI Flags
```python
# Source: https://typer.tiangolo.com/tutorial/parameter-types/enum/
from enum import Enum
import typer

class ErrorMode(str, Enum):
    fail = "fail"
    skip = "skip"

@app.command()
def main(
    on_error: Annotated[ErrorMode, typer.Option(help="Error handling mode")] = ErrorMode.fail,
):
    if on_error == ErrorMode.skip:
        # Handle errors gracefully
        pass
```

### Generator Error Handling with Context
```python
# Source: WebSearch pattern compilation (community best practice)
def safe_generator(source_gen, error_mode, stats):
    """Wrap generator with error handling that preserves context."""
    for row_num, item in enumerate(source_gen, start=1):
        try:
            yield item
            stats.counter['success'] += 1
        except Exception as e:
            error_msg = f"Row {row_num}: {e}"
            if error_mode == ErrorMode.fail:
                raise ValueError(error_msg) from e
            else:
                print(error_msg, file=sys.stderr)
                stats.counter['error'] += 1
                continue  # Skip to next item
```

## State of the Art

| Old Approach | Current Approach | When Changed | Impact |
|--------------|------------------|--------------|--------|
| progressbar2 (800ns overhead) | tqdm (60ns overhead) | 2015-2016 | 13x faster, tqdm became standard for high-throughput pipelines |
| time.time() for benchmarking | time.perf_counter_ns() | Python 3.7 (2018) | Monotonic clock prevents backwards time jumps, nanosecond precision |
| Print-based progress | tqdm with TTY detection | 2015+ | Automatic cleanup, no terminal spam in logs |
| Manual dict for counting | collections.Counter | Always stdlib, formalized patterns 2010+ | Safer (no KeyError), cleaner (total() method), supports arithmetic |
| click.progressbar() | rich.progress or tqdm | 2020+ | Typer recommends rich, but tqdm is lighter and faster |

**Deprecated/outdated:**
- progressbar/progressbar2: Slower and less feature-complete than tqdm
- time.clock(): Removed in Python 3.8, replaced by perf_counter
- Custom print-based "progress" with \r: Doesn't handle terminal width, cleanup, or TTY detection

## Open Questions

Things that couldn't be fully resolved:

1. **Should error counts be per-error-type or aggregated?**
   - What we know: Counter supports both (can track 'validation_error', 'conversion_error', etc.)
   - What's unclear: Whether users want fine-grained error categories or just success/error binary
   - Recommendation: Start with binary (success/error), easy to extend to categories later if needed

2. **Should progress bar show during fail-fast mode?**
   - What we know: Progress bar adds overhead (60ns/iter, negligible but non-zero)
   - What's unclear: If user passes --on-error=fail, do they want to see "Processing 1000/10000" before the crash?
   - Recommendation: Show progress regardless of error mode (helps identify "failed at row 5,234")

3. **Field-level error reporting: full field path or just source field?**
   - What we know: apply_mappings knows mapping.source (dataset field) and mapping.target (Vespa field)
   - What's unclear: Should error say "field 'text'" (source) or "field 'content' (from 'text')" (both)?
   - Recommendation: Report source field since that's what users can check in the dataset, mention target in verbose mode

## Sources

### Primary (HIGH confidence)
- [tqdm GitHub](https://github.com/tqdm/tqdm) - Official repository with 30.9k stars, current as of 2026
- [Python time module documentation](https://docs.python.org/3/library/time.html) - perf_counter_ns() official docs
- [Python collections documentation](https://docs.python.org/3/library/collections.html) - Counter official docs
- [Typer Enum documentation](https://typer.tiangolo.com/tutorial/parameter-types/enum/) - Official Enum parameter guide
- [Typer Progress Bar documentation](https://typer.tiangolo.com/tutorial/progressbar/) - Official progress bar integration

### Secondary (MEDIUM confidence)
- [Python CLI progress bar best practices 2026](https://www.datacamp.com/tutorial/progress-bars-in-python) - tqdm vs alternatives comparison
- [Python stderr vs stdout best practices](https://julienharbulot.com/python-cli-streams.html) - CLI stream separation patterns
- [Python error handling patterns streaming data](https://towardsdatascience.com/mastering-data-streaming-in-python-a88d4b3abf8b/) - Generator error handling
- [Python enumerate for row tracking](https://runebook.dev/en/docs/python/library/csv/csv.csvreader.line_num) - CSV line number tracking patterns
- [Python TTY detection with isatty()](https://thelinuxcode.com/python-file-isatty-method/) - Terminal detection patterns

### Tertiary (LOW confidence)
- [tqdm stdout/stderr flush discussion](https://github.com/tqdm/tqdm/issues/1177) - Known buffering issue, proposed workarounds
- [Generator error handling patterns](https://labex.io/tutorials/python-how-to-manage-generator-exceptions-safely-430752) - Community patterns (not official docs)

## Metadata

**Confidence breakdown:**
- Standard stack: HIGH - tqdm, Counter, perf_counter_ns, Enum all verified from official docs and widely used
- Architecture: HIGH - Patterns verified in existing codebase (cli.py, pipeline.py use generators, Typer, stdout/stderr split)
- Pitfalls: MEDIUM - Based on GitHub issues, community experience, and WebSearch (not all from official sources)

**Research date:** 2026-02-02
**Valid until:** ~2026-03-02 (30 days, stable domain - CLI patterns don't change rapidly)
