# Phase 04 Plan 01: Init Command Implementation Summary

**Completed:** 2026-02-02
**Duration:** ~11 minutes

## One-Liner

Implemented `hf-vespa-feed init <dataset>` command that generates commented YAML config from HuggingFace dataset schema, with backward-compatible CLI restructure.

## What Was Built

### Components Added

1. **init.py module** (`src/hf_vespa_feed/init.py`)
   - `is_list_feature()` - Detects Sequence/List/LargeList types
   - `get_value_dtype()` - Human-readable dtype strings for comments
   - `suggest_type()` - Returns "tensor" for numeric list columns
   - `inspect_dataset_schema()` - Uses `load_dataset_builder()` (no download)
   - `generate_config_yaml()` - Creates YAML with CommentedMap for comments
   - `init_command()` - Entry point with multi-config detection

2. **CLI restructure** (`src/hf_vespa_feed/cli.py`)
   - Added `run()` entry point with backward compatibility handling
   - `feed` command - Explicit streaming to Vespa JSON
   - `init` command - Generate YAML config from dataset schema
   - Backward compat: `hf-vespa-feed <dataset>` still works (defaults to feed)

3. **Dependencies** (`pyproject.toml`)
   - Added `ruamel.yaml>=0.19.0` for YAML generation with comments

### Generated YAML Format

```yaml
# Generated config for dataset: glue
# Config: ax, Split: test
# Edit this file to customize field mappings.
namespace: doc  # Vespa namespace for document IDs
doctype: doc # Vespa document type
id_column: # Column to use as document ID (null = auto-increment)

# Field mappings: source (dataset) -> target (Vespa)
mappings:
  - source: premise
    target: premise
    type:  # string
  - source: hypothesis
    target: hypothesis
    type:  # string
```

For numeric list columns (e.g., embeddings):
```yaml
  - source: embedding
    target: embedding
    type: tensor  # Sequence[float32] -> suggested: tensor
```

## Decisions Made

| Decision | Rationale |
|----------|-----------|
| Use `run()` wrapper for backward compat | Allows checking first arg before Typer parses, inserting 'feed' if needed |
| ruamel.yaml for YAML generation | Only library supporting comment preservation in output |
| `load_dataset_builder()` for schema | Avoids downloading data files, faster inspection |
| Numeric list columns suggest tensor | Most Sequence[float32] columns are embeddings |

## Deviations from Plan

None - plan executed exactly as written.

## Files Changed

| File | Change Type | Description |
|------|-------------|-------------|
| `pyproject.toml` | Modified | Added ruamel.yaml dependency, updated entry point |
| `src/hf_vespa_feed/init.py` | Created | Schema inspection and YAML generation |
| `src/hf_vespa_feed/cli.py` | Modified | Multi-command CLI with backward compat |

## Commits

| Hash | Type | Description |
|------|------|-------------|
| `91b8593` | feat | Add ruamel.yaml dependency and create init module |
| `eb12cac` | feat | Restructure CLI for multi-command support |

## Verification Results

| Criteria | Status |
|----------|--------|
| INIT-01: `hf-vespa-feed init <dataset>` exists | PASS |
| INIT-02: Uses load_dataset_builder (no download) | PASS |
| INIT-03: Generates YAML with all columns | PASS |
| INIT-04: List columns show tensor suggestion | PASS |
| INIT-05: `--output` flag works | PASS |
| INIT-06: Generated config has comments | PASS |
| INIT-07: `--split` flag works | PASS |
| INIT-08: `--config` flag works | PASS |
| COMPAT-01: `hf-vespa-feed <dataset>` works | PASS |
| COMPAT-02: `hf-vespa-feed feed <dataset>` works | PASS |

## Test Commands Used

```bash
# Init command
hf-vespa-feed init glue --config ax --split test --output /tmp/test-config.yaml

# Verify config loads
python -c "from hf_vespa_feed.config import VespaConfig; VespaConfig.from_yaml('/tmp/test-config.yaml')"

# Error handling
hf-vespa-feed init glue  # Multi-config error
hf-vespa-feed init nonexistent-dataset  # Not found error
hf-vespa-feed init glue --config ax --split nonexistent  # Split not found

# Backward compatibility
hf-vespa-feed glue --config ax --split test --limit 1
hf-vespa-feed feed glue --config ax --split test --limit 1
```

## Next Phase Readiness

Phase 04 Plan 01 complete. Ready for:
- Phase 04 Plan 02 (if exists): Additional init command features
- Phase 05: Shell completion or documentation

No blockers or concerns identified.
