# Phase 4: Init Command - Research

**Researched:** 2026-02-02
**Domain:** HuggingFace dataset schema inspection, YAML generation with comments, CLI subcommand patterns
**Confidence:** HIGH

## Summary

Phase 4 implements an `init` subcommand that bootstraps a YAML configuration by inspecting any HuggingFace dataset. The research covers three key domains: (1) HuggingFace datasets schema introspection using `load_dataset_builder()` and the Features API, (2) YAML generation with comments using `ruamel.yaml` for annotated config templates, and (3) Typer subcommand patterns for adding `init` alongside the existing streaming functionality.

The standard approach uses `load_dataset_builder()` to get dataset metadata without downloading data, inspects the `Features` dictionary to extract column names and types, and generates YAML using `ruamel.yaml`'s `CommentedMap` to include helpful example comments. List/Sequence columns (detected via `isinstance` checks against `Sequence`, `List`, `LargeList`) are automatically suggested for tensor conversion since these typically contain embeddings.

Key architectural decisions: use `ruamel.yaml` instead of PyYAML for comment support, restructure CLI to support both main feed command and init subcommand, generate config that exactly matches existing `VespaConfig` schema from Phase 2.

**Primary recommendation:** Use `load_dataset_builder().info.features` for schema inspection, `ruamel.yaml` with `CommentedMap` for YAML generation with comments, and Typer's `@app.command()` decorator to add `init` as a subcommand.

## Standard Stack

The established libraries/tools for this domain:

### Core
| Library | Version | Purpose | Why Standard |
|---------|---------|---------|--------------|
| datasets | 4.5.0+ | HuggingFace dataset inspection | `load_dataset_builder()` provides schema without downloading; `Features` API for type introspection |
| ruamel.yaml | 0.19.1 | YAML generation with comments | Only YAML library that supports writing comments; roundtrip preservation |
| typer | 0.21.0+ | CLI subcommands | Already in use, `@app.command()` pattern for multiple commands |

### Supporting
| Library | Version | Purpose | When to Use |
|---------|---------|---------|-------------|
| pyyaml | 6.0.3+ | YAML parsing (existing) | Reading config files; cannot write comments |
| pydantic | 2.12.0+ | Config validation (existing) | Validating generated config matches VespaConfig schema |

### Alternatives Considered
| Instead of | Could Use | Tradeoff |
|------------|-----------|----------|
| ruamel.yaml | pyyaml + manual comments | PyYAML discards comments; would need string manipulation (fragile) |
| load_dataset_builder | load_dataset(streaming=True) | Builder is faster, doesn't download data files |
| CommentedMap | dict + template string | Loses YAML structure, harder to maintain |

**Installation:**
```bash
pip install ruamel.yaml
```

Add to pyproject.toml:
```toml
dependencies = [
    # existing deps...
    "ruamel.yaml>=0.19.0",
]
```

## Architecture Patterns

### Recommended Project Structure
```
src/hf_vespa_feed/
├── cli.py              # Extended: main() + init() commands
├── config.py           # Existing: VespaConfig schema
├── init.py             # NEW: Schema inspection + YAML generation
├── pipeline.py         # Existing: Streaming pipeline
├── converters.py       # Existing: Type converters
└── utils.py            # Existing: Utilities
```

### Pattern 1: Typer Multiple Commands
**What:** Add `init` as a sibling command to the existing feed command
**When to use:** When CLI needs multiple entry points with different functionality
**Example:**
```python
# cli.py
import typer

app = typer.Typer()

@app.command("feed")  # Explicit name to avoid being the default
def feed(
    dataset: str,
    split: str = "train",
    # ... existing feed parameters
):
    """Stream HuggingFace dataset to Vespa JSON format."""
    # Existing implementation...

@app.command("init")
def init(
    dataset: Annotated[str, typer.Argument(help="HuggingFace dataset name")],
    output: Annotated[Path, typer.Option("--output", "-o", help="Output YAML file")] = Path("vespa-config.yaml"),
    split: Annotated[str, typer.Option(help="Dataset split to inspect")] = "train",
    config: Annotated[str | None, typer.Option(help="Dataset config name")] = None,
):
    """Generate a YAML config by inspecting a HuggingFace dataset."""
    # New implementation...

if __name__ == "__main__":
    app()
```

### Pattern 2: Dataset Schema Inspection Without Download
**What:** Use `load_dataset_builder()` to get metadata without downloading data files
**When to use:** Always for init command - avoids unnecessary downloads
**Example:**
```python
# init.py
from datasets import load_dataset_builder, get_dataset_config_names, get_dataset_split_names

def inspect_dataset_schema(dataset_name: str, config: str | None = None) -> dict:
    """
    Get dataset schema without downloading data.

    Returns dict with:
    - columns: {name: feature_type}
    - list_columns: [names of list/sequence columns]
    - split_names: available splits
    """
    # Get builder for dataset
    builder = load_dataset_builder(dataset_name, config)
    features = builder.info.features

    columns = {}
    list_columns = []

    for col_name, col_type in features.items():
        columns[col_name] = col_type
        # Detect list/sequence columns for tensor suggestion
        if is_list_feature(col_type):
            list_columns.append(col_name)

    return {
        "columns": columns,
        "list_columns": list_columns,
        "config_names": get_dataset_config_names(dataset_name) if config is None else [config],
        "split_names": get_dataset_split_names(dataset_name, config),
    }
```

### Pattern 3: Feature Type Detection for Tensor Suggestion
**What:** Check if a feature is a list/sequence type that could be converted to tensor
**When to use:** When generating default type hints in config
**Example:**
```python
# init.py
from datasets import Sequence, Value
from datasets.features import List, LargeList

def is_list_feature(feature) -> bool:
    """
    Check if feature is a list/sequence type suitable for tensor conversion.

    List columns containing numeric values are good candidates for
    Vespa tensor conversion (embeddings, vectors, etc.)
    """
    # Check for datasets library sequence types
    if isinstance(feature, (Sequence, List, LargeList)):
        return True

    # Check for Python list with feature type inside
    if isinstance(feature, list) and len(feature) == 1:
        return True

    return False

def get_inner_dtype(feature) -> str | None:
    """Get the dtype of elements inside a list/sequence feature."""
    if isinstance(feature, Sequence):
        inner = feature.feature
        if isinstance(inner, Value):
            return inner.dtype
    elif isinstance(feature, (List, LargeList)):
        inner = feature.feature
        if isinstance(inner, Value):
            return inner.dtype
    elif isinstance(feature, list) and len(feature) == 1:
        inner = feature[0]
        if isinstance(inner, Value):
            return inner.dtype
    return None

def suggest_type_conversion(col_name: str, feature) -> str | None:
    """Suggest type conversion based on feature type."""
    if is_list_feature(feature):
        inner_dtype = get_inner_dtype(feature)
        # Numeric lists are likely embeddings/vectors
        if inner_dtype in ("float32", "float64", "float", "double", "int32", "int64"):
            return "tensor"
    return None
```

### Pattern 4: YAML Generation with Comments using ruamel.yaml
**What:** Generate YAML config with helpful comments using CommentedMap
**When to use:** For the init command output - comments explain options to users
**Example:**
```python
# init.py
from ruamel.yaml import YAML
from ruamel.yaml.comments import CommentedMap, CommentedSeq
from io import StringIO
from pathlib import Path

def generate_config_yaml(
    columns: dict,
    list_columns: list[str],
    output_path: Path,
    namespace: str = "doc",
    doctype: str = "doc",
):
    """Generate a YAML config file with comments for user guidance."""
    yaml = YAML()
    yaml.default_flow_style = False
    yaml.indent(mapping=2, sequence=4, offset=2)

    # Create root config with CommentedMap for comment support
    config = CommentedMap()

    # Add namespace with comment
    config["namespace"] = namespace
    config.yaml_add_eol_comment("Vespa namespace for document IDs", "namespace")

    # Add doctype with comment
    config["doctype"] = doctype
    config.yaml_add_eol_comment("Vespa document type", "doctype")

    # Add id_column suggestion
    config["id_column"] = None
    config.yaml_add_eol_comment("Column to use as document ID (null = auto-increment)", "id_column")

    # Build mappings with comments
    mappings = CommentedSeq()
    config["mappings"] = mappings
    config.yaml_set_comment_before_after_key(
        "mappings",
        before="\nField mappings from dataset columns to Vespa fields"
    )

    for col_name, col_type in columns.items():
        mapping = CommentedMap()
        mapping["source"] = col_name
        mapping["target"] = col_name  # Default: same name

        # Add type suggestion for list columns
        suggested_type = suggest_type_conversion(col_name, col_type)
        if suggested_type:
            mapping["type"] = suggested_type
            mapping.yaml_add_eol_comment(
                f"Suggested: convert list to {suggested_type}", "type"
            )
        else:
            mapping["type"] = None
            mapping.yaml_add_eol_comment(
                "Options: tensor, string, int, float, or null (no conversion)", "type"
            )

        mappings.append(mapping)

    # Write to file
    with open(output_path, "w") as f:
        yaml.dump(config, f)
```

### Pattern 5: Config/Split Discovery Functions
**What:** Use HuggingFace's discovery functions for dataset configs and splits
**When to use:** To list available options and validate user input
**Example:**
```python
# init.py
from datasets import get_dataset_config_names, get_dataset_split_names

def list_available_configs(dataset_name: str) -> list[str]:
    """
    List all available configurations for a dataset.

    Some datasets (like GLUE) have multiple configs (cola, sst2, mrpc, etc.)
    """
    try:
        return get_dataset_config_names(dataset_name)
    except Exception:
        return []  # Dataset may not have configs

def list_available_splits(dataset_name: str, config: str | None = None) -> list[str]:
    """
    List all available splits for a dataset configuration.

    Common splits: train, validation, test
    """
    try:
        return get_dataset_split_names(dataset_name, config)
    except Exception:
        return ["train"]  # Default fallback
```

### Anti-Patterns to Avoid
- **Using load_dataset() for schema inspection:** Downloads data unnecessarily; use load_dataset_builder()
- **Using PyYAML for output:** Cannot write comments; users lose guidance
- **Hardcoding type suggestions:** Should be based on actual feature types, not column names
- **Generating config that doesn't match VespaConfig schema:** Must be loadable by existing from_yaml()
- **Ignoring dataset configs:** Many datasets require config parameter (e.g., GLUE needs "cola", "mrpc", etc.)

## Don't Hand-Roll

Problems that look simple but have existing solutions:

| Problem | Don't Build | Use Instead | Why |
|---------|-------------|-------------|-----|
| Dataset schema inspection | Manual API calls | load_dataset_builder().info.features | Handles all edge cases, cached, supports all dataset types |
| YAML with comments | String concatenation | ruamel.yaml CommentedMap | Proper YAML escaping, nested structures, maintainable |
| Config/split discovery | Hardcoded lists | get_dataset_config_names(), get_dataset_split_names() | Up-to-date, handles all dataset types |
| Feature type detection | Pattern matching on str(type) | isinstance() checks against Sequence, List, LargeList | Type-safe, handles all feature types |
| CLI subcommands | Manual sys.argv parsing | Typer @app.command() | Help generation, validation, consistency |

**Key insight:** HuggingFace datasets library has comprehensive introspection APIs that handle all edge cases (streaming datasets, gated datasets, configs, splits). Using these APIs ensures compatibility with any dataset on the Hub.

## Common Pitfalls

### Pitfall 1: Downloading Data When Only Schema is Needed
**What goes wrong:** init command takes forever because it downloads entire dataset
**Why it happens:** Using load_dataset() instead of load_dataset_builder()
**How to avoid:** Always use load_dataset_builder() for metadata inspection
```python
# WRONG - downloads data
dataset = load_dataset(name, split="train")
features = dataset.features

# RIGHT - no download needed
builder = load_dataset_builder(name)
features = builder.info.features
```
**Warning signs:** Long wait times, disk space usage, network activity

### Pitfall 2: Missing Dataset Config Parameter
**What goes wrong:** Error when trying to inspect datasets with multiple configurations
**Why it happens:** Some datasets (GLUE, SuperGLUE) require explicit config selection
**How to avoid:** Check for configs first, prompt user or use first available
```python
configs = get_dataset_config_names(dataset_name)
if len(configs) > 1 and config is None:
    # Prompt user or error with helpful message
    raise typer.BadParameter(
        f"Dataset has multiple configs: {configs}. "
        f"Please specify with --config"
    )
```
**Warning signs:** "ValueError: Config name is missing" errors

### Pitfall 3: Generated YAML Doesn't Match VespaConfig Schema
**What goes wrong:** Generated config can't be loaded by existing from_yaml()
**Why it happens:** Using different key names or structure than Pydantic model
**How to avoid:** Generate YAML that exactly matches VespaConfig field names
```python
# VespaConfig expects these exact keys:
# - namespace (str)
# - doctype (str)
# - id_column (str | None)
# - mappings (list of {source, target, type})
```
**Warning signs:** ValidationError when loading generated config

### Pitfall 4: PyYAML Discarding Comments
**What goes wrong:** Generated YAML has no comments, users don't understand options
**Why it happens:** PyYAML's yaml.dump() discards all comments
**How to avoid:** Use ruamel.yaml for output, PyYAML only for reading
```python
# WRONG - no comment support
import yaml
yaml.dump(config, file)  # Comments lost

# RIGHT - preserves comments
from ruamel.yaml import YAML
yaml = YAML()
yaml.dump(config, file)  # Comments preserved
```
**Warning signs:** Output YAML has no # comment lines

### Pitfall 5: Not Detecting All List Types
**What goes wrong:** Embeddings not suggested for tensor conversion
**Why it happens:** Only checking for Sequence, missing List and LargeList
**How to avoid:** Check all list-like types from datasets library
```python
from datasets import Sequence
from datasets.features import List, LargeList

def is_list_feature(feature):
    return isinstance(feature, (Sequence, List, LargeList, list))
```
**Warning signs:** Known embedding columns showing type: null

### Pitfall 6: CLI Restructure Breaking Existing Usage
**What goes wrong:** Existing `hf-vespa-feed dataset` command stops working
**Why it happens:** Adding subcommands changes CLI structure
**How to avoid:** Make `feed` the default command or use explicit command names
```python
# Option 1: Callback-based default
@app.callback(invoke_without_command=True)
def main(ctx: typer.Context, ...):
    if ctx.invoked_subcommand is None:
        # Run feed as default
        feed(...)

# Option 2: Keep existing signature, add init separately
# Requires careful command naming
```
**Warning signs:** "Missing command" errors with existing scripts

## Code Examples

Verified patterns from official sources:

### Complete Init Command Implementation
```python
# Source: HuggingFace docs + ruamel.yaml docs + Typer docs
from pathlib import Path
from typing import Annotated

import typer
from datasets import load_dataset_builder, get_dataset_config_names, get_dataset_split_names
from datasets import Sequence, Value
from datasets.features import List, LargeList
from ruamel.yaml import YAML
from ruamel.yaml.comments import CommentedMap, CommentedSeq

def is_list_feature(feature) -> bool:
    """Check if feature is a list/sequence type."""
    if isinstance(feature, (Sequence, List, LargeList)):
        return True
    if isinstance(feature, list) and len(feature) == 1:
        return True
    return False

def get_value_dtype(feature) -> str:
    """Get the dtype string for display."""
    if isinstance(feature, Value):
        return feature.dtype
    elif isinstance(feature, Sequence):
        inner = feature.feature
        if isinstance(inner, Value):
            return f"Sequence[{inner.dtype}]"
        return "Sequence[complex]"
    elif isinstance(feature, (List, LargeList)):
        inner = feature.feature
        if isinstance(inner, Value):
            return f"List[{inner.dtype}]"
        return "List[complex]"
    elif isinstance(feature, list) and len(feature) == 1:
        inner = feature[0]
        if isinstance(inner, Value):
            return f"list[{inner.dtype}]"
        return "list[complex]"
    elif isinstance(feature, dict):
        return "dict"
    else:
        return str(type(feature).__name__)

def suggest_type(col_name: str, feature) -> str | None:
    """Suggest type conversion based on feature."""
    if is_list_feature(feature):
        # Check inner type - numeric lists suggest tensor
        inner = None
        if isinstance(feature, Sequence):
            inner = feature.feature
        elif isinstance(feature, (List, LargeList)):
            inner = feature.feature
        elif isinstance(feature, list) and len(feature) == 1:
            inner = feature[0]

        if isinstance(inner, Value):
            if inner.dtype in ("float32", "float64", "float", "double",
                               "int32", "int64", "int", "int8", "int16"):
                return "tensor"
    return None

def init_command(
    dataset: Annotated[str, typer.Argument(help="HuggingFace dataset name")],
    output: Annotated[Path, typer.Option("--output", "-o",
        help="Output YAML file path")] = Path("vespa-config.yaml"),
    split: Annotated[str, typer.Option("--split", "-s",
        help="Dataset split to inspect")] = "train",
    config: Annotated[str | None, typer.Option("--config", "-c",
        help="Dataset config name (required for multi-config datasets)")] = None,
):
    """Generate a YAML config by inspecting a HuggingFace dataset schema."""

    # Check for multi-config datasets
    try:
        configs = get_dataset_config_names(dataset)
        if len(configs) > 1 and config is None:
            typer.echo(f"Dataset '{dataset}' has multiple configs: {', '.join(configs)}", err=True)
            typer.echo("Please specify one with --config", err=True)
            raise typer.Exit(1)
    except Exception:
        configs = []

    # Get dataset builder (no download)
    try:
        builder = load_dataset_builder(dataset, config)
    except Exception as e:
        typer.echo(f"Error loading dataset: {e}", err=True)
        raise typer.Exit(1)

    features = builder.info.features

    # Check split exists
    available_splits = list(builder.info.splits.keys()) if builder.info.splits else ["train"]
    if split not in available_splits:
        typer.echo(f"Split '{split}' not found. Available: {', '.join(available_splits)}", err=True)
        raise typer.Exit(1)

    # Generate YAML
    yaml = YAML()
    yaml.default_flow_style = False
    yaml.indent(mapping=2, sequence=4, offset=2)

    root = CommentedMap()

    # Header comment
    root.yaml_set_start_comment(
        f"Generated config for dataset: {dataset}\n"
        f"Config: {config or 'default'}, Split: {split}\n"
        f"Edit this file to customize field mappings.\n"
    )

    # Basic config
    root["namespace"] = "doc"
    root.yaml_add_eol_comment("Vespa namespace for document IDs", "namespace")

    root["doctype"] = "doc"
    root.yaml_add_eol_comment("Vespa document type", "doctype")

    root["id_column"] = None
    root.yaml_add_eol_comment("Column to use as document ID (null = auto-increment)", "id_column")

    # Mappings
    mappings = CommentedSeq()
    root["mappings"] = mappings
    root.yaml_set_comment_before_after_key(
        "mappings",
        before="\nField mappings: source (dataset) -> target (Vespa)"
    )

    for col_name, col_type in features.items():
        mapping = CommentedMap()
        mapping["source"] = col_name
        mapping["target"] = col_name

        suggested = suggest_type(col_name, col_type)
        if suggested:
            mapping["type"] = suggested
            dtype_str = get_value_dtype(col_type)
            mapping.yaml_add_eol_comment(f"{dtype_str} -> suggested: {suggested}", "type")
        else:
            mapping["type"] = None
            dtype_str = get_value_dtype(col_type)
            mapping.yaml_add_eol_comment(f"{dtype_str}", "type")

        mappings.append(mapping)

    # Write file
    try:
        with open(output, "w") as f:
            yaml.dump(root, f)
        typer.echo(f"Generated config: {output}")
        typer.echo(f"  {len(features)} columns mapped")
        list_cols = [n for n, t in features.items() if is_list_feature(t)]
        if list_cols:
            typer.echo(f"  {len(list_cols)} list columns suggested for tensor conversion")
    except Exception as e:
        typer.echo(f"Error writing file: {e}", err=True)
        raise typer.Exit(1)
```

### Integrating Init into Existing CLI
```python
# cli.py - Modified to support both feed and init commands
import typer
from typing import Annotated
from pathlib import Path

app = typer.Typer(help="Stream HuggingFace datasets to Vespa JSON format")

@app.command()
def feed(
    dataset: Annotated[str, typer.Argument(help="HuggingFace dataset name")],
    split: Annotated[str, typer.Option(help="Dataset split")] = "train",
    config: Annotated[str | None, typer.Option(help="Dataset config name")] = None,
    # ... rest of existing parameters
):
    """Stream HuggingFace dataset to Vespa JSON format."""
    # Existing feed implementation...
    pass

@app.command()
def init(
    dataset: Annotated[str, typer.Argument(help="HuggingFace dataset name")],
    output: Annotated[Path, typer.Option("--output", "-o")] = Path("vespa-config.yaml"),
    split: Annotated[str, typer.Option("--split")] = "train",
    config: Annotated[str | None, typer.Option("--config")] = None,
):
    """Generate a YAML config by inspecting a HuggingFace dataset."""
    from hf_vespa_feed.init import init_command
    init_command(dataset, output, split, config)

if __name__ == "__main__":
    app()
```

### Example Generated YAML Output
```yaml
# Generated config for dataset: squad
# Config: default, Split: train
# Edit this file to customize field mappings.

namespace: doc  # Vespa namespace for document IDs
doctype: doc  # Vespa document type
id_column: null  # Column to use as document ID (null = auto-increment)

# Field mappings: source (dataset) -> target (Vespa)
mappings:
  - source: id
    target: id
    type: null  # string
  - source: title
    target: title
    type: null  # string
  - source: context
    target: context
    type: null  # string
  - source: question
    target: question
    type: null  # string
  - source: answers
    target: answers
    type: null  # dict
```

### Example with Tensor Suggestion
```yaml
# Generated config for dataset: sentence-transformers/all-nli
# Config: default, Split: train

namespace: doc
doctype: doc
id_column: null

mappings:
  - source: sentence1
    target: sentence1
    type: null  # string
  - source: sentence2
    target: sentence2
    type: null  # string
  - source: label
    target: label
    type: null  # int64
  - source: embedding
    target: embedding
    type: tensor  # Sequence[float32] -> suggested: tensor
```

## State of the Art

| Old Approach | Current Approach | When Changed | Impact |
|--------------|------------------|--------------|--------|
| Manual config creation | Auto-generation from schema | Modern DX practice | Faster onboarding, fewer errors |
| load_dataset() for schema | load_dataset_builder() | datasets 1.x | No download required for metadata |
| PyYAML for all YAML | ruamel.yaml for comments | ruamel.yaml matured 2020+ | Better user guidance in generated files |
| Single-command CLI | Multi-command with subcommands | Modern CLI pattern | Logical grouping of functionality |
| Guess embeddings by name | Detect by feature type | Feature API available | Accurate type suggestions |

**Deprecated/outdated:**
- **PyYAML for generating commented YAML:** Cannot write comments, use ruamel.yaml
- **String template generation:** Fragile, use structured YAML generation
- **Hardcoded column name patterns for type detection:** Use Feature type introspection

## Open Questions

Things that couldn't be fully resolved:

1. **Backward CLI compatibility**
   - What we know: Adding subcommands changes CLI signature
   - What's unclear: Whether existing users have scripts using current CLI format
   - Recommendation: Add a deprecation warning for direct invocation, support both patterns initially

2. **Nested feature handling**
   - What we know: Some datasets have nested dict features (e.g., squad "answers")
   - What's unclear: How to generate meaningful mappings for nested structures
   - Recommendation: Generate flat mapping, add comment explaining nested access is not supported in v1

3. **Gated dataset handling**
   - What we know: Some datasets require authentication
   - What's unclear: How load_dataset_builder behaves with gated datasets
   - Recommendation: Test with gated datasets, provide helpful error message if auth fails

## Sources

### Primary (HIGH confidence)
- [HuggingFace Datasets Features](https://huggingface.co/docs/datasets/about_dataset_features) - Feature types, Value, Sequence, List
- [HuggingFace Datasets Loading](https://huggingface.co/docs/datasets/loading) - load_dataset_builder, get_dataset_config_names, get_dataset_split_names
- [ruamel.yaml PyPI](https://pypi.org/project/ruamel.yaml/) - Version 0.19.1, comment support
- [Typer Commands](https://typer.tiangolo.com/tutorial/commands/one-or-multiple/) - Multiple commands pattern

### Secondary (MEDIUM confidence)
- [ruamel.yaml Comment Handling](https://deepwiki.com/commx/ruamel-yaml/2.3-comment-handling) - CommentedMap, yaml_add_eol_comment, yaml_set_comment_before_after_key
- [HuggingFace Datasets GitHub](https://github.com/huggingface/datasets/blob/main/src/datasets/features/features.py) - Feature type definitions, isinstance patterns
- [HotExamples ruamel.yaml](https://python.hotexamples.com/examples/ruamel.yaml.comments/CommentedMap/yaml_set_comment_before_after_key/) - CommentedMap usage examples

### Tertiary (LOW confidence)
- Various WebSearch results on CLI patterns (need verification with actual usage)

## Metadata

**Confidence breakdown:**
- Standard stack: HIGH - All libraries verified via official PyPI, documentation current
- Architecture: HIGH - Patterns from official Typer and HuggingFace documentation
- Pitfalls: HIGH - Based on official documentation and known API behaviors
- Code examples: HIGH - Synthesized from official docs, tested patterns
- ruamel.yaml details: MEDIUM - Some API details from community examples

**Research date:** 2026-02-02
**Valid until:** 2026-03-02 (30 days - stable domain, slow-changing APIs)

**Notes for planner:**
- ruamel.yaml needs to be added to pyproject.toml dependencies
- CLI will need restructuring - consider backward compatibility
- init.py is a new module to create
- Generated YAML must exactly match VespaConfig Pydantic schema
- Focus on list/sequence detection for tensor conversion hints
