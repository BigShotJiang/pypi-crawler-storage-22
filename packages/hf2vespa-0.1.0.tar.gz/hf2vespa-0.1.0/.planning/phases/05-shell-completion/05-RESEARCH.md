# Phase 5: Shell Completion - Research

**Researched:** 2026-02-02
**Domain:** CLI shell completion with Typer
**Confidence:** HIGH

## Summary

This phase implements an `install-completion` subcommand for the `hf-vespa-feed` CLI tool. Typer (the CLI framework already in use) has built-in shell completion support, but it exposes this as `--install-completion` options rather than a subcommand. The requirements specify users should run `hf-vespa-feed install-completion`, so we need to create a custom subcommand that wraps Typer's internal completion installation functionality.

Typer's completion system is built on Click's shell completion (since Typer is built on Click) and supports bash, zsh, and fish shells. The `shellingham` library (included with Typer by default) provides automatic shell detection. Completion scripts modify shell configuration files (`~/.bashrc`, `~/.zshrc`, or `~/.config/fish/completions/`).

**Primary recommendation:** Create an `install-completion` subcommand using Typer's internal `typer._completion_shared` module functions. Disable the default `--install-completion` option with `add_completion=False` to avoid duplication, then implement a custom command that detects the shell and installs the appropriate completion script.

## Standard Stack

The established libraries/tools for this domain:

### Core
| Library | Version | Purpose | Why Standard |
|---------|---------|---------|--------------|
| typer | 0.21.1 | CLI framework | Already in use; has built-in completion support |
| shellingham | (bundled) | Shell detection | Included with typer by default; detects bash/zsh/fish automatically |
| click | (bundled) | Underlying CLI | Typer is built on Click; completion scripts use Click's pattern |

### Supporting
| Library | Version | Purpose | When to Use |
|---------|---------|---------|-------------|
| pathlib | stdlib | Path handling | For constructing shell config file paths |
| os | stdlib | Environment vars | For detecting HOME, XDG paths |
| subprocess | stdlib | Shell commands | Only if needing to detect shell via `echo $SHELL` fallback |

### Alternatives Considered
| Instead of | Could Use | Tradeoff |
|------------|-----------|----------|
| Typer built-in completion | Manual Click completion | More control but more code; Typer's is well-tested |
| shellingham | Manual `$SHELL` detection | Less reliable; shellingham handles edge cases |
| Custom install-completion | Default `--install-completion` | Requirements specify subcommand, not option |

**Installation:**
```bash
# No new dependencies - typer already includes shellingham
pip install typer  # Already installed
```

## Architecture Patterns

### Recommended Project Structure
```
src/hf_vespa_feed/
├── cli.py            # Main CLI with install-completion command
└── completion.py     # (Optional) Completion logic if complex
```

For this phase, completion logic can live directly in `cli.py` since it's straightforward.

### Pattern 1: Custom Subcommand Wrapping Typer's Internal Completion
**What:** Disable default completion options, create explicit `install-completion` subcommand
**When to use:** When requirements specify completion as a subcommand (like this phase)
**Example:**
```python
# Source: https://github.com/fastapi/typer
import typer
from typer._completion_shared import install, Shells

# Disable default --install-completion option
app = typer.Typer(
    help="Stream HuggingFace datasets to Vespa JSON format.",
    add_completion=False,  # KEY: Removes default --install-completion
)

@app.command("install-completion")
def install_completion(
    shell: Annotated[
        str | None,
        typer.Argument(help="Shell type (bash, zsh, fish). Auto-detected if not specified.")
    ] = None,
) -> None:
    """Install shell completion for hf-vespa-feed.

    Detects your shell automatically, or specify: bash, zsh, fish
    """
    # Shell detection
    if shell is None:
        try:
            import shellingham
            shell, _ = shellingham.detect_shell()
        except Exception:
            typer.echo("Could not detect shell. Please specify: bash, zsh, or fish", err=True)
            raise typer.Exit(1)

    shell = shell.lower()
    if shell not in ("bash", "zsh", "fish"):
        typer.echo(f"Unsupported shell: {shell}. Supported: bash, zsh, fish", err=True)
        raise typer.Exit(1)

    # Install completion using Typer's internal function
    try:
        shell_enum = Shells(shell)
        path = install(shell=shell_enum)
        typer.echo(f"Completion installed for {shell}")
        typer.echo(f"Configuration added to: {path}")
        typer.echo("Restart your terminal or run 'source {path}' to activate.")
    except Exception as e:
        typer.echo(f"Failed to install completion: {e}", err=True)
        raise typer.Exit(1)
```

### Pattern 2: Show Completion Script (Optional Enhancement)
**What:** Allow users to see the completion script without installing
**When to use:** For users who want manual control over installation
**Example:**
```python
@app.command("show-completion")
def show_completion(
    shell: Annotated[str | None, typer.Argument()] = None,
) -> None:
    """Show the shell completion script without installing."""
    from typer._completion_shared import get_completion_script

    if shell is None:
        import shellingham
        shell, _ = shellingham.detect_shell()

    prog_name = "hf-vespa-feed"
    complete_var = "_HF_VESPA_FEED_COMPLETE"
    script = get_completion_script(prog_name, complete_var, shell)
    typer.echo(script)
```

### Anti-Patterns to Avoid
- **Using both default and custom completion:** Don't forget `add_completion=False`; having both creates confusion
- **Hardcoding shell paths:** Use Typer's `install()` function which handles path differences across OS/shells
- **Ignoring shell detection failures:** Always catch `shellingham.ShellDetectionFailure` and provide helpful error messages
- **Forgetting to tell users to restart terminal:** Completion only works after shell restart or sourcing

## Don't Hand-Roll

Problems that look simple but have existing solutions:

| Problem | Don't Build | Use Instead | Why |
|---------|-------------|-------------|-----|
| Shell detection | Custom `$SHELL` parsing | `shellingham.detect_shell()` | Handles edge cases, process tree inspection |
| Completion script generation | String templates | `typer._completion_shared.get_completion_script()` | Tested across shells, handles escaping |
| Config file location | Hardcoded `~/.bashrc` | `typer._completion_shared.install()` | OS-aware, handles zsh `fpath`, fish config dirs |
| Completion script content | Manual Click env vars | Typer's built-in scripts | Properly escapes program names, handles arguments |

**Key insight:** Typer reimplemented Click's completion system with improvements. Using Typer's internal functions ensures compatibility with the CLI framework already in use and avoids subtle bugs in shell escaping.

## Common Pitfalls

### Pitfall 1: Forgetting add_completion=False
**What goes wrong:** Both `--install-completion` option AND `install-completion` subcommand exist
**Why it happens:** Typer adds completion options by default
**How to avoid:** Always set `add_completion=False` when creating custom completion commands
**Warning signs:** Help output shows both `--install-completion` and `install-completion`

### Pitfall 2: Shell Detection in Non-Interactive Contexts
**What goes wrong:** `shellingham.detect_shell()` raises `ShellDetectionFailure`
**Why it happens:** Running in cron, CI, scripts without TTY, or unusual shell setups
**How to avoid:** Wrap detection in try/except, provide clear error message, allow explicit shell argument
**Warning signs:** "Could not detect shell" errors in CI or scripts

### Pitfall 3: Completion Not Working After Install
**What goes wrong:** User runs install-completion, restarts terminal, still no completions
**Why it happens:** Various causes - shell not sourcing config file, completion script path issues
**How to avoid:**
1. Tell user exact file modified
2. Suggest `source ~/.bashrc` (or equivalent)
3. Verify program is accessible via PATH (installed package, not `python cli.py`)
**Warning signs:** User reports "ran install-completion but nothing happens"

### Pitfall 4: Package Not Installed via Entry Point
**What goes wrong:** Completion script runs but can't find the command
**Why it happens:** Completion only works with installed packages (entry points in pyproject.toml)
**How to avoid:** Verify `hf-vespa-feed` is accessible in PATH before installing completion
**Warning signs:** "command not found" errors during tab completion

### Pitfall 5: Fish Uses Different Directory Structure
**What goes wrong:** Fish completion installed to wrong location
**Why it happens:** Fish uses `~/.config/fish/completions/` not a config file
**How to avoid:** Use Typer's `install()` function which handles this correctly
**Warning signs:** Fish users report completion not working

## Code Examples

Verified patterns from official sources:

### Shell Detection with Fallback
```python
# Source: https://github.com/sarugaku/shellingham
def detect_shell_with_fallback() -> tuple[str, str | None]:
    """Detect current shell, with fallback to $SHELL."""
    try:
        import shellingham
        name, path = shellingham.detect_shell()
        return name.lower(), path
    except shellingham.ShellDetectionFailure:
        # Fallback for POSIX systems
        import os
        shell_env = os.environ.get("SHELL", "")
        if shell_env:
            name = os.path.basename(shell_env).lower()
            return name, shell_env
        return "", None
```

### Completion Installation Function
```python
# Source: https://github.com/fastapi/typer/blob/master/typer/_completion_shared.py
from typer._completion_shared import Shells, install

def install_shell_completion(shell_name: str) -> str:
    """Install completion for the given shell, return path of modified file."""
    shell_enum = Shells(shell_name)  # Validates shell name
    installed_path = install(shell=shell_enum)
    return str(installed_path)
```

### Complete install-completion Command
```python
# Source: Synthesized from Typer documentation
from typing import Annotated
import typer

@app.command("install-completion")
def install_completion_cmd(
    shell: Annotated[
        str | None,
        typer.Argument(
            help="Shell to install completion for (bash, zsh, fish). Auto-detected if omitted."
        )
    ] = None,
) -> None:
    """Install shell tab-completion for hf-vespa-feed.

    Examples:
        hf-vespa-feed install-completion        # Auto-detect shell
        hf-vespa-feed install-completion bash   # Explicit bash
        hf-vespa-feed install-completion zsh    # Explicit zsh
    """
    from typer._completion_shared import Shells, install

    # Detect shell if not provided
    if shell is None:
        try:
            import shellingham
            detected_name, _ = shellingham.detect_shell()
            shell = detected_name.lower()
            typer.echo(f"Detected shell: {shell}")
        except Exception:
            typer.echo(
                "Could not auto-detect your shell.\n"
                "Please specify: hf-vespa-feed install-completion [bash|zsh|fish]",
                err=True
            )
            raise typer.Exit(1)

    # Validate shell
    shell = shell.lower()
    supported = {"bash", "zsh", "fish"}
    if shell not in supported:
        typer.echo(f"Unsupported shell: {shell}", err=True)
        typer.echo(f"Supported shells: {', '.join(sorted(supported))}", err=True)
        raise typer.Exit(1)

    # Install completion
    try:
        shell_enum = Shells(shell)
        path = install(shell=shell_enum)

        # Success message with clear instructions
        typer.echo(f"\nShell completion installed for {shell}!")
        typer.echo(f"Modified: {path}")
        typer.echo("\nTo activate, either:")
        typer.echo(f"  1. Restart your terminal, OR")
        if shell == "fish":
            typer.echo(f"  2. Run: source {path}")
        else:
            typer.echo(f"  2. Run: source {path}")

    except Exception as e:
        typer.echo(f"Failed to install completion: {e}", err=True)
        raise typer.Exit(1)
```

### Shell Config File Locations (Reference)
```python
# Source: https://click.palletsprojects.com/en/stable/shell-completion/
# These are the standard locations Typer's install() uses:

COMPLETION_PATHS = {
    "bash": {
        "script": "~/.bash_completions/{prog_name}.sh",
        "config": "~/.bashrc",
    },
    "zsh": {
        "script": "~/.zfunc/_{prog_name}",
        "config": "~/.zshrc",
    },
    "fish": {
        "script": "~/.config/fish/completions/{prog_name}.fish",
        "config": None,  # Fish sources completions dir automatically
    },
}
```

## State of the Art

| Old Approach | Current Approach | When Changed | Impact |
|--------------|------------------|--------------|--------|
| click-completion library | Built-in Click 8.0 completion | Click 8.0 (2021) | No extra dependency needed |
| Manual completion scripts | Typer automatic completion | Typer 0.4.0+ | Just use `--install-completion` |
| Shell-specific setup | shellingham auto-detection | shellingham integration | Users don't need to specify shell |

**Deprecated/outdated:**
- click-completion: Only for Click < 8.0, not needed with modern Click/Typer
- Manual completion script generation: Typer handles this internally now

## Open Questions

Things that couldn't be fully resolved:

1. **PowerShell support scope**
   - What we know: Typer supports PowerShell and pwsh
   - What's unclear: Requirements only mention bash/zsh/fish
   - Recommendation: Implement for bash/zsh/fish per requirements; PowerShell can be added later if requested

2. **Entry point naming**
   - What we know: Completion uses the entry point name (`hf-vespa-feed`)
   - What's unclear: Backward compatibility wrapper `run()` might affect completion
   - Recommendation: Test that completion works with the actual installed entry point

3. **Typer internal API stability**
   - What we know: `typer._completion_shared` is internal (underscore prefix)
   - What's unclear: Whether this API is stable across Typer versions
   - Recommendation: Use it (it's the only way), but pin Typer version in dependencies

## Sources

### Primary (HIGH confidence)
- Typer official documentation (https://typer.tiangolo.com/) - completion features, installation
- Click documentation (https://click.palletsprojects.com/en/stable/shell-completion/) - underlying completion system
- PyPI Typer 0.21.1 (https://pypi.org/project/typer/) - current version, dependencies

### Secondary (MEDIUM confidence)
- GitHub Typer source (https://github.com/fastapi/typer) - internal implementation details
- GitHub shellingham (https://github.com/sarugaku/shellingham) - shell detection mechanism
- GitHub issue #54 (https://github.com/fastapi/typer/issues/54) - known issues with completion

### Tertiary (LOW confidence)
- Community blog posts on shell completion - general patterns

## Metadata

**Confidence breakdown:**
- Standard stack: HIGH - Typer/shellingham already in use, well-documented
- Architecture: HIGH - Pattern follows Typer conventions, verified from source
- Pitfalls: HIGH - Documented issues from GitHub issues and official docs

**Research date:** 2026-02-02
**Valid until:** 30 days (stable domain, Typer has been stable for years)
