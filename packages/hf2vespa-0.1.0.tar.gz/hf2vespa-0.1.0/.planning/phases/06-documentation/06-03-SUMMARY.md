---
phase: 06-documentation
plan: 03
subsystem: documentation
tags: [README, troubleshooting, cookbook, examples, HuggingFace-datasets]

# Dependency graph
requires:
  - phase: 06-02
    provides: YAML Configuration and CLI Reference documentation
  - phase: 01-core
    provides: Core streaming functionality for testing examples
  - phase: 04-init-command
    provides: init command for generating configs
provides:
  - Troubleshooting section with solutions for auth, memory, type, multi-config, and dataset not found errors
  - Cookbook with 5 real-world examples using SQuAD, GLUE, MS MARCO, Wikipedia, and embeddings
  - Contributing and License sections completing professional README
affects: [future-users, v2-features]

# Tech tracking
tech-stack:
  added: []
  patterns: [symptom-cause-solution troubleshooting format, copy-paste ready cookbook examples]

key-files:
  created: []
  modified: [README.md]

key-decisions:
  - "Use symptom -> cause -> solution pattern for troubleshooting clarity"
  - "Test all cookbook examples against real HuggingFace datasets"
  - "Focus on copy-paste ready examples (no placeholders)"
  - "Fixed GLUE ax example to use --split test (only has test split)"

patterns-established:
  - "Troubleshooting section structure: symptom, cause, solution with code examples"
  - "Cookbook examples show full workflow: init -> preview -> full stream"
  - "Include output format descriptions for each dataset example"

# Metrics
duration: 3min 17sec
completed: 2026-02-03
---

# Phase 6 Plan 3: Troubleshooting and Cookbook Summary

**Complete README documentation with troubleshooting for common errors and 5 tested real-world dataset examples (SQuAD, GLUE, MS MARCO, Wikipedia, embeddings)**

## Performance

- **Duration:** 3 min 17 sec
- **Started:** 2026-02-03T05:56:59Z
- **Completed:** 2026-02-03T06:00:16Z
- **Tasks:** 3
- **Files modified:** 1

## Accomplishments

- Troubleshooting section with 5 common issues: authentication, memory, type conversion, multi-config, dataset not found
- Cookbook with 5 real-world examples using public HuggingFace datasets
- All cookbook examples tested and verified working
- Contributing and License sections added
- Complete professional README (527 lines)

## Task Commits

Each task was committed atomically:

1. **Task 1: Write Troubleshooting section** - `0c5e11b` (docs)
2. **Task 2: Write Cookbook section** - `231b6bf` (docs)
3. **Task 3: Final polish and verification** - `64bd2c2` (docs)

## Files Created/Modified

- `README.md` - Added Troubleshooting (92 lines), Cookbook (109 lines), Contributing/License (7 lines)

## Decisions Made

**Use symptom -> cause -> solution pattern for troubleshooting**
- Rationale: Users can quickly scan symptoms to find their issue, then get actionable solution. Follows standard troubleshooting best practices.

**Test all cookbook examples against real HuggingFace datasets**
- Rationale: Ensures examples work and datasets exist. Discovered GLUE ax only has test split during testing.

**Focus on copy-paste ready examples**
- Rationale: No placeholders or fictional datasets. Every command can be run immediately by users.

**Fixed GLUE ax example to use --split test**
- Rationale: GLUE ax config only has test split. Testing revealed error, fixed inline with `--split test` flag.

## Deviations from Plan

### Auto-fixed Issues

**1. [Rule 1 - Bug] Fixed GLUE ax example missing --split test flag**
- **Found during:** Task 3 (Testing cookbook examples)
- **Issue:** Command `hf-vespa-feed feed glue --config ax --limit 2` failed with "Bad split: train. Available splits: ['test']"
- **Fix:** Added `--split test` flag to GLUE ax example with comment "(ax only has test split)"
- **Files modified:** README.md
- **Verification:** Command succeeded with --split test flag
- **Committed in:** `64bd2c2` (Task 3 commit)

---

**Total deviations:** 1 auto-fixed (1 bug)
**Impact on plan:** Bug fix essential for cookbook examples to work. No scope creep.

## Issues Encountered

None - all examples tested successfully after fixing GLUE ax split.

## User Setup Required

None - documentation complete.

## Next Phase Readiness

Phase 6 (Documentation) complete:
- README has all 6 sections: Description, Installation, Quick Start, YAML Config, CLI Reference, Cookbook, Troubleshooting, Contributing, License
- All DOCS requirements satisfied (DOCS-01 through DOCS-06)
- All examples tested and working

Ready to proceed to Phase 7 (Performance optimizations) or ship v1.1.

---
*Phase: 06-documentation*
*Completed: 2026-02-03*
