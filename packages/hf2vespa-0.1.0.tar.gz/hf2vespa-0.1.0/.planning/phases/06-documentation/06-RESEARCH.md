# Phase 6: Documentation - Research

**Researched:** 2026-02-03
**Domain:** Python CLI tool documentation and technical writing
**Confidence:** HIGH

## Summary

Documentation for Python CLI tools follows well-established patterns that prioritize progressive disclosure and examples-first learning. The research focused on modern best practices for README structure, CLI reference documentation, troubleshooting sections, and cookbook patterns. Current industry standards emphasize human-readable output, minimal working examples, and modular content organization.

Key findings reveal that successful CLI documentation in 2026 follows a two-tier approach: terminal-based help for immediate access and web-based documentation for comprehensive reference. READMEs should follow a specific section order that prioritizes quick-start accessibility while providing clear paths to deeper documentation. The "Command Line Interface Guidelines" (clig.dev) and pyOpenSci Python Packaging Guide provide authoritative patterns that align well with Typer's documentation philosophy.

For the hf-vespa-feed project, documentation should mirror the progressive complexity model seen in successful projects like Typer and HuggingFace's datasets library. The README needs comprehensive installation instructions (pip and from-source), a minimal working example that demonstrates core streaming functionality, detailed YAML configuration reference covering all field types, full CLI command documentation with examples, a troubleshooting section addressing authentication, memory, and type errors, and a cookbook with real HuggingFace dataset examples.

**Primary recommendation:** Write documentation in Markdown following the pyOpenSci section order pattern, emphasizing examples-first presentation with inline code blocks that users can copy without modification, and link to external resources for complex topics.

## Standard Stack

Documentation for Python CLI tools doesn't require specialized libraries but follows established conventions and formats.

### Core

| Tool | Version | Purpose | Why Standard |
|------|---------|---------|--------------|
| Markdown | CommonMark | README format | Universal GitHub support, readable as plain text, PyPI compatible |
| YAML | 1.2.2 | Configuration syntax | Human-readable, widely adopted for config files, supports comments |

### Supporting

| Tool | Version | Purpose | When to Use |
|------|---------|---------|-------------|
| MkDocs | Latest | Static site generator for docs | If building separate documentation site (NOT NEEDED for Phase 6) |
| Sphinx | Latest | Documentation generator with autodoc | If auto-generating API docs from docstrings (NOT NEEDED for Phase 6) |
| mkdocstrings | Latest | MkDocs plugin for docstring rendering | If using MkDocs and need API reference (NOT NEEDED for Phase 6) |
| typer-cli | Latest | Generate Markdown docs from Typer apps | If auto-generating CLI reference (OPTIONAL - manual writing preferred) |

### Alternatives Considered

| Instead of | Could Use | Tradeoff |
|------------|-----------|----------|
| Markdown README | reStructuredText | reStructuredText has more features but Markdown is more widely known and easier to read |
| Manual CLI reference | typer-cli auto-generation | Auto-generation is faster but manual writing provides better narrative flow and examples |
| Single README | Separate docs site (MkDocs/Sphinx) | Docs site is more comprehensive but README-only is simpler for small projects |

**Note on tooling:** Phase 6 focuses on README.md documentation only. No additional documentation generation tools are needed. The README should be manually written for maximum clarity and user-friendliness.

## Architecture Patterns

### Recommended README Structure

Based on pyOpenSci guidelines and CLI best practices from clig.dev:

```markdown
# Project Name

[Brief badges: PyPI version, Python versions supported]

## Description
[1-3 sentences explaining what it does]

## Installation

### From PyPI
[Simple pip install command]

### From Source
[Clone and pip install -e . commands]

## Quick Start

[Minimal working example showing core functionality]
[Include expected output]

## YAML Configuration

[Deep-dive into config format with all field types documented]
[Include examples for each field type]

## CLI Reference

[Comprehensive documentation of all commands]
[All flags with descriptions and examples]

## Cookbook

[Real-world examples with actual datasets]
[Copy-paste ready commands with explanations]

## Troubleshooting

[Common issues with solutions]
[Organized by error category]

## Contributing / License / Citation
[Links to other files or brief inline content]
```

### Pattern 1: Progressive Disclosure

**What:** Start with simplest example, gradually introduce complexity
**When to use:** Throughout all documentation sections
**Example:**
```markdown
## Quick Start

Basic usage:
```bash
hf-vespa-feed feed glue --config ax
```

Filter specific columns:
```bash
hf-vespa-feed feed glue --config ax --include premise --include hypothesis
```

Use configuration file:
```bash
hf-vespa-feed feed glue --config ax --config-file mappings.yaml
```
```

### Pattern 2: Examples-First Documentation

**What:** Lead with concrete examples before abstract descriptions
**When to use:** CLI reference, troubleshooting, cookbook sections
**Example:**
```markdown
## Troubleshooting

### Authentication Errors

If you see `401 Unauthorized`:

```bash
# Set HuggingFace token
export HF_TOKEN=your_token_here
hf-vespa-feed feed private-dataset
```

Why this happens: Private datasets require authentication...
```

### Pattern 3: Copy-Paste Ready Commands

**What:** Provide commands that work without modification (except placeholders)
**When to use:** All code examples
**Example:**
```bash
# Good - can copy and run (with dataset substitution)
hf-vespa-feed feed <your-dataset> --limit 10

# Bad - requires editing multiple parts
hf-vespa-feed feed dataset_name --split your_split --config your_config
```

### Pattern 4: Inline Output Demonstration

**What:** Show expected output alongside commands
**When to use:** Quick start, cookbook, troubleshooting examples
**Example:**
```markdown
```bash
hf-vespa-feed feed glue --config ax --limit 2
```

Output:
```json
{"put":"id:doc:doc::0","fields":{"premise":"...", "hypothesis":"..."}}
{"put":"id:doc:doc::1","fields":{"premise":"...", "hypothesis":"..."}}
```

--- Completion Statistics ---
Total records processed: 2
...
```
```

### Pattern 5: Hierarchical CLI Documentation

**What:** Document commands hierarchically: command → flags → examples
**When to use:** CLI reference section
**Example:**
```markdown
### `hf-vespa-feed feed`

Stream HuggingFace dataset to Vespa JSON format.

**Arguments:**
- `dataset` - HuggingFace dataset name (required)

**Options:**
- `--split` - Dataset split (default: train)
- `--config` - Dataset config name
- `--config-file` - YAML config file path
...

**Examples:**
[Concrete examples here]
```

### Anti-Patterns to Avoid

- **Abstract-first documentation:** Don't start with theory before showing examples
- **Incomplete examples:** Don't show code that won't run without additions
- **Scattered reference:** Don't split related flags across multiple sections
- **Missing output:** Don't show commands without indicating what they produce
- **Outdated examples:** Don't use deprecated flags or old syntax in examples

## Don't Hand-Roll

Problems that look simple but have existing solutions or established conventions:

| Problem | Don't Build | Use Instead | Why |
|---------|-------------|-------------|-----|
| CLI documentation format | Custom structure | pyOpenSci README guidelines + clig.dev patterns | Industry-standard section order ensures users find what they need |
| YAML config examples | Ad-hoc format | Field type tables with inline examples | Consistent structure makes reference documentation scannable |
| Troubleshooting organization | Alphabetical error list | Category-based grouping (auth, memory, types) | Users think in terms of problem domains, not error messages |
| Installation instructions | Single method only | Multiple methods (pip + from-source) | Different users have different needs (end-users vs developers) |
| CLI reference | Narrative prose | Structured format (command → args → options → examples) | Scannable structure enables quick lookups |
| Cookbook examples | Toy datasets | Real HuggingFace datasets (Wikipedia, BEIR, embeddings) | Real examples build confidence and show actual use cases |

**Key insight:** Documentation has well-established conventions that readers expect. Deviating from standard patterns increases cognitive load and makes documentation harder to use. Follow the established conventions even if they seem verbose.

## Common Pitfalls

### Pitfall 1: Installation Instructions Too Minimal

**What goes wrong:** Users can't successfully install and run first command
**Why it happens:** Authors assume knowledge of Python packaging, virtual environments, dependencies
**How to avoid:**
- Provide both `pip install` AND from-source instructions
- Mention Python version requirements explicitly
- Show complete command sequences (create venv, activate, install)
- Note any system-level dependencies (none for this project)
**Warning signs:** GitHub issues asking "how do I install this?"

### Pitfall 2: Missing Expected Output in Examples

**What goes wrong:** Users don't know if command worked correctly
**Why it happens:** Authors know what output looks like, forget readers don't
**How to avoid:**
- Show actual output (full or truncated) for every command example
- Include progress bars, statistics, error messages in examples
- Indicate when output is truncated with `...`
**Warning signs:** Questions like "is this normal output?"

### Pitfall 3: Abstract Config Documentation Without Examples

**What goes wrong:** Users can't write valid YAML configs without trial-and-error
**Why it happens:** Field descriptions alone don't show syntax or valid values
**How to avoid:**
- Provide complete YAML example for each field type
- Show nested field structures with indentation
- Include comments in YAML examples explaining each field
- Document valid values for type field (tensor, string, int, float)
**Warning signs:** Config validation errors in issues

### Pitfall 4: Troubleshooting Section Missing or Hidden

**What goes wrong:** Users create duplicate issues for known problems
**Why it happens:** Common issues not documented, or buried in other sections
**How to avoid:**
- Dedicated "Troubleshooting" section in README
- Cover the big three: authentication, memory, type errors
- Organize by symptom (error message) with solution
- Link to troubleshooting from error messages if possible
**Warning signs:** Repeated issues with same error messages

### Pitfall 5: Cookbook Examples Not Copy-Paste Ready

**What goes wrong:** Users can't reproduce examples successfully
**Why it happens:** Examples use non-existent datasets, require undocumented setup, or have typos
**How to avoid:**
- Use real public HuggingFace datasets (Wikipedia, BEIR, etc.)
- Test every command in cookbook before documenting
- Include dataset config names where required (e.g., `glue --config ax`)
- Show complete commands with all required flags
**Warning signs:** "Your example doesn't work" issues

### Pitfall 6: CLI Reference Incomplete or Out of Sync

**What goes wrong:** Users don't discover important flags, get confused by undocumented behavior
**Why it happens:** Documentation written once and not updated as CLI evolves
**How to avoid:**
- Document ALL commands: feed, init, install-completion
- Document ALL flags for each command
- Include default values in documentation
- Verify docs match actual CLI behavior with --help
**Warning signs:** Questions about flags that aren't documented

### Pitfall 7: PyPI-Incompatible README Markup

**What goes wrong:** README renders incorrectly or not at all on PyPI
**Why it happens:** Using Markdown features not supported by PyPI's renderer
**How to avoid:**
- Use standard Markdown (CommonMark compatible)
- Avoid: Sphinx directives, complex nested structures, HTML
- Test: Render README locally before publishing
- Stick to: Headers, lists, code blocks, links, emphasis
**Warning signs:** README looks fine on GitHub but broken on PyPI

## Code Examples

Verified patterns from official sources and established conventions:

### Minimal Working Example (Quick Start)

```bash
# Install
pip install hf-vespa-feed

# Stream a dataset
hf-vespa-feed feed glue --config ax --limit 10
```

Pattern: Installation + simplest command that produces output
Source: Typer README structure, pyOpenSci guidelines

### CLI Reference Entry Format

```markdown
### `hf-vespa-feed feed`

Stream HuggingFace dataset to Vespa JSON format.

**Usage:**
```bash
hf-vespa-feed feed DATASET [OPTIONS]
```

**Arguments:**
- `DATASET` - HuggingFace dataset name (required)

**Options:**
- `--split TEXT` - Dataset split to use [default: train]
- `--config TEXT` - Dataset config name (for multi-config datasets)
- `--config-file PATH` - YAML configuration file for field mappings
- `--limit INTEGER` - Process only first N records
- `--namespace TEXT` - Vespa namespace for document IDs [default: doc]
- `--doctype TEXT` - Vespa document type [default: doc]
- `--id-column TEXT` - Dataset column to use as document ID
- `--on-error [fail|skip]` - Error handling mode [default: fail]
- `--include TEXT` - Columns to include (repeatable)
- `--rename TEXT` - Rename columns as 'old:new' (repeatable)

**Examples:**

Basic streaming:
```bash
hf-vespa-feed feed glue --config ax
```

Filter columns:
```bash
hf-vespa-feed feed glue --config ax --include premise --include hypothesis
```

Use config file:
```bash
hf-vespa-feed feed squad --config-file vespa-config.yaml
```

Preview first 10 records:
```bash
hf-vespa-feed feed squad --limit 10
```
```

Pattern: Structured command documentation with progressive examples
Source: clig.dev CLI guidelines, Google Developer Documentation Style Guide

### YAML Config Documentation Format

```markdown
## YAML Configuration

Configuration files define field mappings and document ID settings.

### Basic Structure

```yaml
# Vespa document settings
namespace: doc              # Namespace for document IDs
doctype: doc               # Document type name
id_column: id              # Dataset column to use as document ID (optional)

# Field mappings (optional)
mappings:
  - source: text           # Dataset column name
    target: body           # Vespa field name
    type: string          # Type converter to apply
```

### Field Types

| Type | Purpose | Example |
|------|---------|---------|
| `string` | Text data | Converting numeric to string |
| `int` | Integer values | ID fields, counts |
| `float` | Decimal values | Scores, percentages |
| `tensor` | Vector embeddings | Embedding fields as Vespa tensors |

### Complete Example

```yaml
# Example: Wikipedia with embeddings
namespace: wiki
doctype: article
id_column: id

mappings:
  - source: title
    target: title
    type: string

  - source: embedding
    target: vector
    type: tensor

  - source: views
    target: view_count
    type: int
```
```

Pattern: Structure → field reference table → complete example
Source: YAML documentation patterns, Home Assistant YAML docs

### Troubleshooting Entry Format

```markdown
### Authentication Errors

**Symptom:** `401 Unauthorized` or `403 Forbidden` when loading private datasets

**Cause:** HuggingFace authentication token not provided or invalid

**Solution:**

```bash
# Option 1: Environment variable (recommended)
export HF_TOKEN=your_token_here
hf-vespa-feed feed your-private-dataset

# Option 2: HuggingFace CLI login
pip install huggingface_hub
huggingface-cli login
hf-vespa-feed feed your-private-dataset
```

**Get a token:** https://huggingface.co/settings/tokens
```

Pattern: Symptom → cause → solution with multiple approaches
Source: Node.js CLI Best Practices, clig.dev troubleshooting guidance

### Cookbook Entry Format

```markdown
## Cookbook

### Example 1: Wikipedia with Embeddings

Stream Wikipedia articles with pre-computed embeddings to Vespa:

```bash
# Create config file
cat > wikipedia-config.yaml << EOF
namespace: wiki
doctype: article
id_column: id

mappings:
  - source: title
    target: title
    type: string

  - source: text
    target: body
    type: string

  - source: embedding
    target: vector
    type: tensor
EOF

# Stream dataset
hf-vespa-feed feed wikipedia --split train --config-file wikipedia-config.yaml --limit 1000 > wikipedia-feed.jsonl
```

**Output:** 1000 Vespa documents with title, body, and vector fields
```

Pattern: Real dataset + config + command + expected outcome
Source: HuggingFace Cookbook patterns, CLI best practices

## State of the Art

Documentation practices have evolved toward modularity and AI-assisted workflows in 2026.

| Old Approach | Current Approach | When Changed | Impact |
|--------------|------------------|--------------|--------|
| Single massive README | Modular docs with external links | 2023-2024 | READMEs remain concise, deep docs live elsewhere |
| Theory-first documentation | Examples-first with progressive disclosure | Ongoing | Users learn faster with concrete examples |
| CLI help only | Two-tier: terminal help + web docs | 2024+ | Terminal for quick ref, web for comprehensive |
| Manual CLI reference | Auto-generated with tools (typer-cli, mkdocs-click) | 2023+ | Reduces docs drift but manual still preferred for narrative |

**Deprecated/outdated:**
- **reStructuredText for READMEs:** Markdown has won for README files. reST remains relevant for Sphinx but not READMEs
- **Comprehensive inline docs:** Modern approach prefers concise README with links to external comprehensive docs
- **Abstract-first writing:** Examples-first is now standard practice per clig.dev and modern tech writing

**2026 trends:**
- **AI-assisted documentation:** Tools help generate but humans maintain editorial control
- **Modular, reusable content:** Write once, reference many times
- **Audience-first organization:** Structure by user journey, not by technical architecture

## Open Questions

Things that couldn't be fully resolved:

1. **Auto-generation vs manual CLI reference**
   - What we know: typer-cli can generate Markdown from Typer apps
   - What's unclear: Whether auto-generated docs are better than manually written narrative
   - Recommendation: Start with manual writing for Phase 6. Auto-generation can be added later if docs drift becomes a problem

2. **Cookbook dataset selection**
   - What we know: Need real HuggingFace datasets (Wikipedia, BEIR, embeddings)
   - What's unclear: Which specific dataset paths/configs are best examples
   - Recommendation: Test popular datasets during planning and choose 3-4 with diverse field types

3. **Troubleshooting completeness**
   - What we know: Should cover auth, memory, type errors
   - What's unclear: What other common issues users will encounter
   - Recommendation: Start with known issue categories. Expand based on real issues after release

4. **README length vs external docs**
   - What we know: READMEs should be concise but comprehensive
   - What's unclear: At what point to split into separate docs site
   - Recommendation: Single README for Phase 6 (v1.1). Consider MkDocs if README exceeds ~1000 lines

## Sources

### Primary (HIGH confidence)

- [Command Line Interface Guidelines (clig.dev)](https://clig.dev/) - Authoritative CLI best practices including documentation patterns, help text organization, troubleshooting guidance
- [pyOpenSci Python Packaging Guide - README Best Practices](https://www.pyopensci.org/python-package-guide/documentation/repository-files/readme-file-best-practices.html) - Official Python package README structure and section ordering
- [Typer Official Documentation](https://typer.tiangolo.com/) - Examples of progressive disclosure and CLI documentation patterns
- [HuggingFace Datasets Library Documentation](https://huggingface.co/docs/datasets/) - Quick start patterns and authentication documentation
- [YAML 1.2.2 Specification](https://yaml.org/spec/1.2.2/) - Official YAML syntax reference for configuration documentation
- [Google Developer Documentation Style Guide - CLI Syntax](https://developers.google.com/style/code-syntax) - Standards for documenting command-line syntax

### Secondary (MEDIUM confidence)

- [Real Python - Python Project Documentation with MkDocs](https://realpython.com/python-project-documentation-with-mkdocs/) - Documentation tooling overview (verified with official MkDocs docs)
- [Node.js CLI Apps Best Practices](https://github.com/lirantal/nodejs-cli-apps-best-practices) - Troubleshooting patterns cross-verified with clig.dev
- [HuggingFace Hub CLI Documentation](https://huggingface.co/docs/huggingface_hub/en/guides/cli) - Authentication token patterns verified with official docs
- [Python Packaging User Guide - Installing Packages](https://packaging.python.org/installing/) - Installation instruction patterns

### Tertiary (LOW confidence - marked for validation)

- WebSearch findings about 2026 technical writing trends - No verification with authoritative source
- WebSearch findings about READMEs getting 4x more stars - Interesting claim but not verified
- Various Medium articles and blog posts - Used for pattern discovery but not cited as authoritative

## Metadata

**Confidence breakdown:**
- Standard stack: HIGH - Markdown and YAML are well-established standards with official specifications
- Architecture patterns: HIGH - Based on multiple authoritative sources (clig.dev, pyOpenSci, Typer) with consistent guidance
- Pitfalls: MEDIUM-HIGH - Derived from best practices documentation and common GitHub issue patterns, less direct verification
- Code examples: HIGH - Based on official documentation patterns and style guides

**Research date:** 2026-02-03
**Valid until:** 2026-05-03 (90 days - documentation conventions are stable)

**Research focus:** Documentation conventions and patterns, not implementation details. Implementation decisions (exact wording, specific examples) deferred to planning phase.
