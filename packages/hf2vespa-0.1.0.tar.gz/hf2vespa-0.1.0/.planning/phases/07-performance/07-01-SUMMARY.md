---
phase: 07-performance
plan: 01
subsystem: pipeline
tags: [multiprocessing, parallel, performance, streaming, cli]

# Dependency graph
requires:
  - phase: 01-foundation
    provides: Basic CLI and pipeline structure
  - phase: 06-documentation
    provides: Documentation patterns
provides:
  - CLI flag for parallel processing (--num-workers)
  - API foundation for future non-streaming parallelization
  - Test infrastructure (test_cli.py, test_pipeline.py)
affects: [future-non-streaming-features]

# Tech tracking
tech-stack:
  added: [pytest-typer-integration]
  patterns: [CLI parameter validation, streaming limitation documentation]

key-files:
  created:
    - tests/test_cli.py
    - tests/test_pipeline.py
  modified:
    - src/hf_vespa_feed/cli.py
    - src/hf_vespa_feed/pipeline.py

key-decisions:
  - "Accept num_workers parameter but don't use with streaming=True due to HuggingFace limitation"
  - "Document limitation clearly in help text and docstrings for transparency"
  - "Auto-detect CPU count as default (os.cpu_count())"
  - "Reserve parameter for future non-streaming dataset support"

patterns-established:
  - "Typer CliRunner for testing CLI commands"
  - "Accept parameters for API consistency even when not immediately usable"

# Metrics
duration: 4min
completed: 2026-02-03
---

# Phase 7 Plan 1: Parallel Loading Summary

**Added --num-workers CLI flag with CPU auto-detection, discovered HuggingFace streaming limitation, documented constraint for future non-streaming support**

## Performance

- **Duration:** 4 min
- **Started:** 2026-02-03T06:44:12Z
- **Completed:** 2026-02-03T06:48:35Z
- **Tasks:** 3
- **Files modified:** 4

## Accomplishments
- CLI accepts --num-workers flag with auto-detection (os.cpu_count())
- Pipeline accepts num_proc parameter for API consistency
- Discovered and documented HuggingFace limitation: streaming=True incompatible with num_proc
- Created test infrastructure with test_cli.py and test_pipeline.py
- All tests pass with proper handling of streaming constraint

## Task Commits

Each task was committed atomically:

1. **Task 1: Add --num-workers CLI flag to feed command** - `306bcc1` (feat)
2. **Task 2: Wire num_workers through pipeline to load_dataset** - `01e5890` (feat)
3. **Task 3: Add test coverage for num_workers parameter** - `0a81f64` (test)

## Files Created/Modified
- `src/hf_vespa_feed/cli.py` - Added os import, num_workers parameter to feed_impl() and feed(), auto-detection via os.cpu_count(), validation
- `src/hf_vespa_feed/pipeline.py` - Added num_proc parameter to stream_dataset(), documented streaming limitation, removed num_proc from load_dataset call
- `tests/test_cli.py` - Created with CLI flag tests (acceptance test, zero validation)
- `tests/test_pipeline.py` - Created with pipeline parameter test (verifies parameter accepted)

## Decisions Made
- **Accept but don't use num_proc with streaming:** HuggingFace datasets library explicitly rejects num_proc when streaming=True (raises NotImplementedError). Parameter accepted for API consistency and reserved for future non-streaming mode support.
- **Document limitation prominently:** Updated help text to clearly state "Not supported with streaming mode. Reserved for future use with non-streaming datasets." Prevents user confusion.
- **Auto-detect CPU count:** Default num_workers=None triggers os.cpu_count() detection, providing sensible default for future non-streaming use.

## Deviations from Plan

### Auto-fixed Issues

**1. [Rule 1 - Bug] Removed num_proc from load_dataset call with streaming=True**
- **Found during:** Task 3 (test execution)
- **Issue:** HuggingFace datasets library raises NotImplementedError when num_proc is passed with streaming=True. Tests failed with: "Loading a streaming dataset in parallel with `num_proc` is not implemented."
- **Fix:** Removed num_proc parameter from load_dataset() call in pipeline.py. Parameter still accepted by stream_dataset() for API consistency but not forwarded to load_dataset. Updated docstrings to document this limitation and explain alternative (PyTorch DataLoader with num_workers for parallel streaming).
- **Files modified:** src/hf_vespa_feed/pipeline.py (removed num_proc from load_dataset call, updated docstring), src/hf_vespa_feed/cli.py (updated help text), tests/test_pipeline.py (updated test comments)
- **Verification:** All tests pass. CLI accepts flag without error. Streaming functionality unchanged.
- **Committed in:** 0a81f64 (Task 3 commit)

---

**Total deviations:** 1 auto-fixed (1 bug - library limitation)
**Impact on plan:** Auto-fix necessary due to upstream library constraint. Parameter infrastructure complete and ready for future non-streaming mode. No scope creep - discovered limitation during planned testing phase.

## Issues Encountered
- **HuggingFace streaming limitation:** Discovered that load_dataset explicitly doesn't support num_proc with streaming=True. This is a fundamental library limitation, not a bug in our code. Resolution: Accept parameter for API consistency but don't use it with streaming. Document clearly for users. Reserve for future non-streaming dataset support.

## User Setup Required

None - no external service configuration required.

## Next Phase Readiness
- CLI flag infrastructure complete and tested
- Parameter plumbing ready for future non-streaming datasets
- Test infrastructure established (test_cli.py, test_pipeline.py) for future test expansion
- Documentation updated to prevent user confusion about streaming limitation
- No blockers for future performance work

**Note for future work:** When/if non-streaming mode is added, num_workers parameter will flow through to load_dataset(num_proc=...) for actual parallel loading.

---
*Phase: 07-performance*
*Completed: 2026-02-03*
