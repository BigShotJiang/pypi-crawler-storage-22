# Phase 7: Performance - Context

**Gathered:** 2026-02-03
**Status:** Ready for planning

<domain>
## Phase Boundary

Optimize throughput with multiprocessing, caching, and performance tuning for the hf-vespa-feed CLI tool. Focus on large dataset handling (10M+ records). This phase improves existing functionality — no new features or commands.

</domain>

<decisions>
## Implementation Decisions

### Parallelization Strategy
- Auto-detect CPU cores as default, but allow `--num-workers` CLI flag to override
- Always parallel (no serial mode) — users can set num_workers=1 if needed
- Target use case: large datasets (10M+ records) where throughput is critical

### Caching Behavior
- Transparent caching (users don't configure, it just works faster)
- Keep implementation simple to modest effort — functools.lru_cache or similar
- Primary pain point: dataset loading is slow (not conversion/processing)
- Worth adding caching if meaningful gains without major complexity

### Claude's Discretion
- Where to apply parallelism (dataset loading via num_proc, record processing, or both)
- What specifically to cache (type converters, schema inspection, etc.)
- Whether to rely primarily on HuggingFace's built-in caching vs adding custom caching
- Memory management approach for large datasets

</decisions>

<specifics>
## Specific Ideas

- User mentioned functools cache for common operations — consider lru_cache for repeated conversions
- Dataset loading identified as the slow part, not the JSON conversion step
- Tool should handle 10M+ record datasets gracefully

</specifics>

<deferred>
## Deferred Ideas

None — discussion stayed within phase scope

</deferred>

---

*Phase: 07-performance*
*Context gathered: 2026-02-03*
