# Phase 8: Scalar Types - Research

**Researched:** 2026-02-03
**Domain:** Vespa scalar types (position, weighted sets, maps) and Python validation patterns
**Confidence:** HIGH

## Summary

Phase 8 adds support for three Vespa scalar types: position (geographic coordinates), weighted sets (key-weight dictionaries), and maps (key-value dictionaries). All three types have well-documented JSON formats in the official Vespa documentation, and their Python conversion follows simple patterns that extend the existing converter registry.

Position fields in Vespa use a `{"lat": float, "lng": float}` format where latitude must be -90 to +90 and longitude must be -180 to +180. Weighted sets use `{"key": weight}` format where all keys become strings and weights are 32-bit signed integers. Maps use `{"key": value}` format where keys are always stringified regardless of schema type. All three types treat empty dictionaries as unset fields.

The implementation follows the established converter registry pattern: register three new converters (`position`, `weightedset`, `map`) with validation functions, update the config validator to recognize these types, and add comprehensive tests. No new dependencies are required; Pydantic 2.12+ (already a dependency) provides validation primitives, and the existing pattern of raising `ValueError` with descriptive messages handles validation errors.

**Primary recommendation:** Implement three converter functions (`dict_to_position`, `dict_to_weightedset`, `dict_to_map`) following the existing `list_to_tensor` pattern with input validation, register them in the module-level `converters` registry, and update `config.py`'s `valid_types` set to include the new type names.

## Standard Stack

### Core
| Library | Version | Purpose | Why Standard |
|---------|---------|---------|--------------|
| pydantic | >=2.12.0 | Already used for config validation | Existing dependency, provides validation patterns |
| stdlib (typing) | 3.10+ | Type hints for Any, dict | Standard library solution |

### Supporting
| Library | Version | Purpose | When to Use |
|---------|---------|---------|-------------|
| orjson | >=3.11.0 | JSON serialization (existing) | Already in pipeline for output |

### Alternatives Considered
| Instead of | Could Use | Tradeoff |
|------------|-----------|----------|
| Manual validation | pydantic-extra-types Latitude/Longitude | Adds dependency for minimal benefit; simple range checks suffice |
| Manual key stringification | json.dumps for keys | json.dumps adds quotes; simple str() matches Vespa expectations |
| Strict type enforcement | Duck typing | Validation catches errors early; duck typing allows silent failures |

**Installation:**
No additional dependencies required - all implementations use existing dependencies or stdlib.

## Architecture Patterns

### Recommended Project Structure
```
src/hf_vespa_feed/
├── converters.py    # Add dict_to_position, dict_to_weightedset, dict_to_map
├── config.py        # Update valid_types set to include position, weightedset, map
└── ...
tests/
└── test_converters.py  # Add tests for new converters
```

### Pattern 1: Converter Function with Input Validation
**What:** Each converter function validates input structure and value ranges, returning the Vespa-compatible format or raising `ValueError` with a descriptive message.

**When to use:** All new scalar type converters.

**Example:**
```python
# Source: Extends existing list_to_tensor pattern from converters.py
def dict_to_position(value: Any) -> dict[str, float]:
    """
    Convert lat/lng dict to Vespa position format.

    Args:
        value: Dict with 'lat' and 'lng' keys

    Returns:
        Dict in Vespa position format: {"lat": float, "lng": float}

    Raises:
        ValueError: If input is invalid (missing keys, wrong types, out of range)
    """
    if not isinstance(value, dict):
        raise ValueError(f"Expected dict for position conversion, got {type(value).__name__}")

    if "lat" not in value or "lng" not in value:
        raise ValueError(f"Position requires 'lat' and 'lng' keys, got: {list(value.keys())}")

    lat, lng = value["lat"], value["lng"]

    if not isinstance(lat, (int, float)) or not isinstance(lng, (int, float)):
        raise ValueError(f"Position lat/lng must be numeric, got lat={type(lat).__name__}, lng={type(lng).__name__}")

    if not (-90 <= lat <= 90):
        raise ValueError(f"Latitude must be -90 to +90, got {lat}")

    if not (-180 <= lng <= 180):
        raise ValueError(f"Longitude must be -180 to +180, got {lng}")

    return {"lat": float(lat), "lng": float(lng)}
```

### Pattern 2: Weighted Set with Key Stringification
**What:** Weighted set converter stringifies all keys (as required by JSON) and validates that weights are numeric.

**When to use:** Converting dict-like structures to Vespa weighted set format.

**Example:**
```python
# Source: Vespa document JSON format reference
def dict_to_weightedset(value: Any) -> dict[str, int]:
    """
    Convert key-weight pairs to Vespa weighted set format.

    Args:
        value: Dict with any keys and numeric weights

    Returns:
        Dict with stringified keys and integer weights: {"key1": 1, "key2": 2}

    Raises:
        ValueError: If input is not a dict or weights are non-numeric
    """
    if not isinstance(value, dict):
        raise ValueError(f"Expected dict for weightedset conversion, got {type(value).__name__}")

    result = {}
    for key, weight in value.items():
        if not isinstance(weight, (int, float)):
            raise ValueError(f"Weighted set weight must be numeric, got {type(weight).__name__} for key '{key}'")
        # Keys must be strings in JSON; weights are 32-bit signed integers in Vespa
        result[str(key)] = int(weight)

    return result
```

### Pattern 3: Map with Key Stringification
**What:** Map converter stringifies keys and preserves values (primitives, nested structures, or structs).

**When to use:** Converting dict-like structures to Vespa map format.

**Example:**
```python
# Source: Vespa document JSON format reference
def dict_to_map(value: Any) -> dict[str, Any]:
    """
    Convert key-value pairs to Vespa map format.

    Args:
        value: Dict with any keys and values

    Returns:
        Dict with stringified keys: {"key1": value1, "key2": value2}

    Raises:
        ValueError: If input is not a dict
    """
    if not isinstance(value, dict):
        raise ValueError(f"Expected dict for map conversion, got {type(value).__name__}")

    # Keys are always stringified in JSON format
    return {str(key): val for key, val in value.items()}
```

### Anti-Patterns to Avoid
- **Silent coercion without validation:** Don't accept invalid lat/lng values and silently clamp them. Raise clear errors.
- **Accepting None as empty dict:** Vespa treats empty dict `{}` as unset, but None should raise an error (data integrity issue).
- **Integer-only weights:** While Vespa stores weights as 32-bit integers, accept float and truncate (with warning if decimal part is lost).

## Don't Hand-Roll

| Problem | Don't Build | Use Instead | Why |
|---------|-------------|-------------|-----|
| Coordinate validation | Custom regex or string parsing | Simple numeric range checks | Lat/lng are floats with fixed ranges; regex is overkill |
| Key stringification | json.dumps() for each key | str(key) | json.dumps adds quotes around strings; str() matches Vespa expectations |
| Weight range checking | Custom bounds checking | int() truncation + optional warning | Python int() handles float-to-int; Vespa handles overflow as 32-bit |
| Type introspection | isinstance chains | isinstance with tuple | Cleaner code: `isinstance(v, (int, float))` |

**Key insight:** Vespa scalar types have simple, well-defined formats. The complexity is in validation and error messages, not in the conversion itself. Focus on clear error messages that help users identify which row/field has invalid data.

## Common Pitfalls

### Pitfall 1: Accepting String Coordinates
**What goes wrong:** User passes `{"lat": "37.4", "lng": "-122.0"}` (strings) and converter silently fails or produces wrong output.

**Why it happens:** HuggingFace datasets may store coordinates as strings if read from CSV without type inference.

**How to avoid:** Check `isinstance(lat, (int, float))` and raise helpful error: "Position lat must be numeric, got str. Consider adding a 'float' converter upstream."

**Warning signs:** Position values appear as `{"lat": "NaN", "lng": "NaN"}` in output.

### Pitfall 2: Losing Precision on Integer Coordinates
**What goes wrong:** Position like `{"lat": 37, "lng": -122}` (integers) gets passed through without float conversion, causing downstream type mismatches.

**Why it happens:** Python accepts int where float is expected, but some systems distinguish.

**How to avoid:** Always return `float(lat), float(lng)` even for integer inputs. This ensures consistent output type.

**Warning signs:** Type mismatches in downstream Vespa processing.

### Pitfall 3: Empty Weighted Set Interpretation
**What goes wrong:** Passing `{}` to weighted set converter succeeds, but Vespa treats it as "field not set" rather than "empty set".

**Why it happens:** Vespa JSON format explicitly states: "Feeding an empty weightedset (setting the field value to {}) is equivalent to not feeding a value."

**How to avoid:** Document this behavior clearly. Optionally warn on empty dict input: "Empty weighted set will be treated as unset by Vespa".

**Warning signs:** Field appears missing in Vespa documents despite being mapped in config.

### Pitfall 4: Non-Integer Weights Silently Truncated
**What goes wrong:** User passes `{"tag1": 1.5, "tag2": 2.7}` and weights become `{1, 2}` without warning, losing the decimal precision.

**Why it happens:** Vespa weighted sets use 32-bit signed integers for weights. Python `int()` truncates toward zero.

**How to avoid:** Check if weight has non-zero decimal part and emit warning (to stderr): "Weight 1.5 truncated to 1 for key 'tag1'". Continue processing but inform user.

**Warning signs:** Ranking results differ from expected because weights were truncated.

## Code Examples

Verified patterns from official sources.

### Position Converter (Complete Implementation)
```python
# Source: https://docs.vespa.ai/en/querying/geo-search.html
# Source: https://docs.vespa.ai/en/reference/schemas/document-json-format.html

def dict_to_position(value: Any) -> dict[str, float]:
    """
    Convert lat/lng dict to Vespa position format.

    Vespa position format: {"lat": float, "lng": float}
    - Latitude: -90 to +90 (positive = north, negative = south)
    - Longitude: -180 to +180 (positive = east, negative = west)

    Examples:
        >>> dict_to_position({"lat": 37.4181488, "lng": -122.0256157})
        {'lat': 37.4181488, 'lng': -122.0256157}
        >>> dict_to_position({"lat": 90, "lng": 180})  # Integers accepted
        {'lat': 90.0, 'lng': 180.0}
    """
    if not isinstance(value, dict):
        raise ValueError(f"Expected dict for position conversion, got {type(value).__name__}")

    if "lat" not in value or "lng" not in value:
        raise ValueError(
            f"Position requires 'lat' and 'lng' keys, got: {sorted(value.keys())}"
        )

    lat, lng = value["lat"], value["lng"]

    if not isinstance(lat, (int, float)):
        raise ValueError(
            f"Position lat must be numeric (int or float), got {type(lat).__name__}"
        )
    if not isinstance(lng, (int, float)):
        raise ValueError(
            f"Position lng must be numeric (int or float), got {type(lng).__name__}"
        )

    if not (-90 <= lat <= 90):
        raise ValueError(f"Latitude must be between -90 and +90, got {lat}")

    if not (-180 <= lng <= 180):
        raise ValueError(f"Longitude must be between -180 and +180, got {lng}")

    return {"lat": float(lat), "lng": float(lng)}
```

### Weighted Set Converter (Complete Implementation)
```python
# Source: https://docs.vespa.ai/en/reference/schemas/document-json-format.html
# Note: In Vespa 8+, both document API and search API use {"key": weight} format

def dict_to_weightedset(value: Any) -> dict[str, int]:
    """
    Convert key-weight pairs to Vespa weighted set format.

    Vespa weighted set format: {"key1": weight1, "key2": weight2}
    - Keys are stringified (JSON requirement)
    - Weights are 32-bit signed integers (-2147483648 to 2147483647)

    Examples:
        >>> dict_to_weightedset({"item1": 10, "item2": 20})
        {'item1': 10, 'item2': 20}
        >>> dict_to_weightedset({123: 5, 456: 10})  # Integer keys stringified
        {'123': 5, '456': 10}
    """
    if not isinstance(value, dict):
        raise ValueError(f"Expected dict for weightedset conversion, got {type(value).__name__}")

    result = {}
    for key, weight in value.items():
        if not isinstance(weight, (int, float)):
            raise ValueError(
                f"Weighted set weight must be numeric, got {type(weight).__name__} for key '{key}'"
            )

        # Convert float weights to int (Vespa uses 32-bit signed int)
        int_weight = int(weight)

        # Keys are always strings in JSON format
        result[str(key)] = int_weight

    return result
```

### Map Converter (Complete Implementation)
```python
# Source: https://docs.vespa.ai/en/reference/schemas/document-json-format.html

def dict_to_map(value: Any) -> dict[str, Any]:
    """
    Convert key-value pairs to Vespa map format.

    Vespa map format: {"key1": value1, "key2": value2}
    - Keys are stringified (JSON requirement)
    - Values can be primitives or nested structures

    Note: Maps in Vespa do not support ranking, only matching and filtering.

    Examples:
        >>> dict_to_map({"a": 1, "b": 2})
        {'a': 1, 'b': 2}
        >>> dict_to_map({1: "one", 2: "two"})  # Integer keys stringified
        {'1': 'one', '2': 'two'}
    """
    if not isinstance(value, dict):
        raise ValueError(f"Expected dict for map conversion, got {type(value).__name__}")

    # Keys are always strings in JSON format
    return {str(key): val for key, val in value.items()}
```

### Config Update (valid_types)
```python
# Source: Existing config.py pattern

@field_validator("type")
@classmethod
def validate_type(cls, v: str | None) -> str | None:
    if v is None:
        return v

    # Extended set including new scalar types
    valid_types = {"tensor", "string", "int", "float", "position", "weightedset", "map"}
    if v not in valid_types:
        raise ValueError(
            f"Unknown type converter '{v}'. Must be one of: {', '.join(sorted(valid_types))}"
        )
    return v
```

### Converter Registration
```python
# Source: Existing converters.py pattern

# Create module-level registry instance
converters = ConverterRegistry()

# Register built-in converters
converters.register("tensor", list_to_tensor)
converters.register("string", str)
converters.register("int", int)
converters.register("float", float)

# Register scalar type converters (Phase 8)
converters.register("position", dict_to_position)
converters.register("weightedset", dict_to_weightedset)
converters.register("map", dict_to_map)
```

## State of the Art

| Old Approach | Current Approach | When Changed | Impact |
|--------------|------------------|--------------|--------|
| Weighted set array format | Weighted set dict format | Vespa 8 (2022) | Search API now returns `{"key": weight}` instead of `[{"item": key, "weight": weight}]` |
| Separate position X/Y fields | Single position object | Vespa 8 (2022) | Position is now `{"lat": float, "lng": float}` instead of two separate fields |

**Deprecated/outdated:**
- **Array format for weighted sets:** Vespa 7 search API used `[{"item": ..., "weight": ...}]` format. Vespa 8+ uses consistent `{"key": weight}` format across all APIs.
- **Legacy position formats (Vespa 5-7):** Still accepted as input but should use current `{"lat": ..., "lng": ...}` format for new implementations.

## Open Questions

### 1. Warning on Weight Truncation
- **What we know:** Vespa uses 32-bit signed integers for weighted set weights. Float values will be truncated.
- **What's unclear:** Should we emit a warning when `1.5` becomes `1`? This could be noisy for large datasets.
- **Recommendation:** Do NOT warn by default. Truncation is documented behavior. Users who pass floats should expect truncation. Add a debug/verbose mode later if requested.

### 2. Position Validation Strictness
- **What we know:** Vespa accepts positions with lat/lng outside normal ranges but they may produce unexpected geo-search results.
- **What's unclear:** Should we allow slightly out-of-range values (e.g., lat=90.00001 due to floating point)?
- **Recommendation:** Strictly validate -90 to +90 and -180 to +180. Floating point edge cases should be handled by users rounding before conversion. Clear boundaries prevent subtle bugs.

### 3. Empty Dict Handling
- **What we know:** Vespa treats `{}` as "field not set" for weighted sets and maps.
- **What's unclear:** Should converter reject empty dicts, accept them silently, or accept with warning?
- **Recommendation:** Accept empty dicts silently. This matches Vespa behavior. Document that empty dict = unset field. Do not warn (too noisy for datasets with optional fields).

## Sources

### Primary (HIGH confidence)
- [Vespa Geo Search](https://docs.vespa.ai/en/querying/geo-search.html) - Position field format, lat/lng conventions
- [Vespa Document JSON Format Reference](https://docs.vespa.ai/en/reference/schemas/document-json-format.html) - Position, weighted set, map JSON formats
- [Vespa Schema Reference](https://docs.vespa.ai/en/reference/schemas/schemas.html) - Field type definitions, indexing options
- [Vespa Searching Multivalued Fields](https://docs.vespa.ai/en/querying/searching-multivalue-fields.html) - Weighted set ranking and usage

### Secondary (MEDIUM confidence)
- [GitHub Issue #8251: Weighted set representation](https://github.com/vespa-engine/vespa/issues/8251) - Confirmed Vespa 8 unified format
- [Pydantic Coordinate Types](https://docs.pydantic.dev/latest/api/pydantic_extra_types_coordinate/) - Latitude/longitude validation patterns (not used but referenced)

### Tertiary (LOW confidence)
- None - all findings verified with official Vespa documentation

## Metadata

**Confidence breakdown:**
- Standard stack: HIGH - Uses existing dependencies (pydantic, stdlib)
- Architecture: HIGH - Extends well-established converter registry pattern
- Pitfalls: HIGH - Drawn from official Vespa documentation edge cases

**Research date:** 2026-02-03
**Valid until:** 2026-05-03 (90 days - Vespa JSON format is stable, unlikely to change)

**Key assumptions:**
1. Vespa 8+ is the target version (uses consistent weighted set format)
2. Existing converter registry pattern is maintained
3. Error messages follow existing ValueError pattern with descriptive messages
4. No new dependencies should be added for this phase
