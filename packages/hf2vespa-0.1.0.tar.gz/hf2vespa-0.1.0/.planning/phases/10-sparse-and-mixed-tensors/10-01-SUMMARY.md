---
phase: 10-sparse-and-mixed-tensors
plan: 01
subsystem: type-converters
tags: [sparse-tensor, dict-conversion, vespa-cells, type-validation]

dependency_graph:
  requires:
    - 09-02  # Hex tensor converter patterns
    - 08-01  # Core type converter infrastructure
  provides:
    - sparse_tensor converter function
    - Vespa cells notation for mapped tensors
  affects:
    - 10-02  # Mixed tensor implementation (will use similar cells pattern)

tech_stack:
  added: []
  patterns:
    - Sparse tensor cells notation with address-value pairs
    - Dict-to-cells converter pattern

file_tracking:
  created: []
  modified:
    - src/hf_vespa_feed/converters.py
    - src/hf_vespa_feed/config.py
    - tests/test_converters.py

decisions:
  - id: sparse-cells-format
    choice: Use Vespa cells notation for sparse tensors
    rationale: Standard Vespa format for single mapped dimension tensors
    alternatives: ["custom format", "direct dict"]
    impacts: [10-02]
  - id: key-stringification
    choice: Convert all keys to strings automatically
    rationale: Vespa addresses require string keys
    alternatives: ["reject non-string keys", "preserve types"]
    impacts: []
  - id: value-float-conversion
    choice: Convert all numeric values to floats
    rationale: Vespa tensors use float values
    alternatives: ["preserve int/float distinction"]
    impacts: []

metrics:
  duration: "1m 43s"
  completed: 2026-02-03
  test_delta: "+10 tests (60 → 70)"
---

# Phase 10 Plan 01: Sparse Tensor Converter Summary

**One-liner:** Dict-to-cells converter for single mapped dimension sparse tensors with string keys and float values

## What Was Built

Implemented `dict_to_sparse_tensor` converter enabling Vespa sparse tensor format for key-value numeric data. Supports use cases like term weights, feature importance scores, and other mapped numeric data.

**Core functionality:**
- Converts Python dict to Vespa cells notation: `{"cells": [{"address": {"key": "..."}, "value": ...}, ...]}`
- Validates input type (must be dict)
- Rejects empty dicts with clear error message
- Validates values are numeric (int or float)
- Converts keys to strings, values to floats
- Includes row context in error messages for dataset processing

**Example usage:**
```python
from hf_vespa_feed.converters import dict_to_sparse_tensor

result = dict_to_sparse_tensor({"term1": 0.8, "term2": 0.5})
# {'cells': [{'address': {'key': 'term1'}, 'value': 0.8},
#            {'address': {'key': 'term2'}, 'value': 0.5}]}
```

## Tasks Completed

| Task | Description | Commit | Files Modified |
|------|-------------|--------|----------------|
| 1 | Implement dict_to_sparse_tensor converter | eaffc8d | converters.py |
| 2 | Add sparse_tensor to config valid_types | f226ef2 | config.py |
| 3 | Add sparse tensor tests | 375cc37 | test_converters.py |

## Technical Details

**Converter implementation:**
- Function signature: `dict_to_sparse_tensor(value: Any, row_num: int | None = None) -> dict[str, list]`
- Input validation: type check, empty dict check, numeric value check
- Output format: Vespa cells notation with address-value pairs
- Error messages: Include key name and optional row context

**Config validation:**
- Added "sparse_tensor" to valid_types set in FieldMapping
- Enables config YAML to specify sparse_tensor type for field mappings

**Test coverage:**
- 10 new tests covering happy path and error cases
- Basic conversion with string/integer keys
- Integer values converted to float
- Empty dict and non-dict inputs rejected
- Non-numeric values rejected with clear errors
- Row context included in error messages
- List values rejected (hint to use mixed tensor instead)
- Config validation test

## Decisions Made

### 1. Sparse Tensor Cells Format
**Decision:** Use Vespa cells notation for sparse tensors
**Rationale:** Standard Vespa format for single mapped dimension tensors (`tensor<float>(key{})`)
**Alternatives:** Custom format or direct dict passthrough
**Impact:** Consistent with Vespa documentation, enables proper tensor indexing

### 2. Automatic Key Stringification
**Decision:** Convert all keys to strings automatically
**Rationale:** Vespa addresses require string keys, common use case is integer keys
**Example:** `{1: 0.5, 2: 0.3}` → `{"1": 0.5, "2": 0.3}`

### 3. Automatic Value Float Conversion
**Decision:** Convert all numeric values to floats
**Rationale:** Vespa tensors use float values, matches other tensor converters
**Example:** `{"a": 1, "b": 2}` → floats in output

## Testing Results

**Test suite:**
- 10 new sparse tensor tests
- All 70 tests passing (60 existing + 10 new)
- 0 regressions
- Test execution time: 0.26s

**Coverage:**
- Basic conversion: ✓
- Edge cases (empty, single key): ✓
- Type conversion (int keys/values): ✓
- Error cases (non-dict, non-numeric): ✓
- Row context in errors: ✓
- Config validation: ✓

## Integration Points

**Converter registry:**
- Registered as "sparse_tensor" in module-level converters instance
- Available via `converters.convert(value, "sparse_tensor")`

**Config validation:**
- Accepted in FieldMapping type field
- Example config:
  ```yaml
  mappings:
    - source: term_weights
      target: weights
      type: sparse_tensor
  ```

**Error handling:**
- Clear error messages with key names
- Optional row context for batch processing
- Consistent with other converter error patterns

## Next Phase Readiness

**Ready for Phase 10-02 (Mixed Tensors):**
- Cells notation pattern established
- Dict-to-cells conversion validated
- Can extend to mixed indexed+mapped tensors

**No blockers.**

## Deviations from Plan

None - plan executed exactly as written.

## Performance Notes

- No performance optimization needed for sparse tensor conversion
- Dict iteration is efficient for typical sparse tensor sizes
- Memory usage: O(n) where n is number of keys (creates cells list)

## Documentation Added

**Docstring:**
- Full function documentation with args, returns, raises, examples
- Clear explanation of Vespa cells notation format
- Examples showing both dict-like and output format

**Test documentation:**
- Each test has descriptive docstring explaining what it validates
- Section header clearly marks sparse tensor test section
