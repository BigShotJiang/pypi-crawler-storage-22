# Phase 11: Testing and Benchmarks - Context

**Gathered:** 2026-02-03
**Status:** Ready for planning

<domain>
## Phase Boundary

Comprehensive correctness tests verifying all converters match Vespa documentation, plus performance benchmarks with CI integration and GitHub Pages visualization. No new converter functionality — this phase validates existing work.

</domain>

<decisions>
## Implementation Decisions

### Benchmark Infrastructure
- Use pytest-benchmark for all performance measurements
- GitHub Actions runs benchmarks on every new tag
- Results published to GitHub Pages as line charts over time
- Fail CI if regression exceeds 10% (blocks release)

### Benchmark Scope
- Individual converter benchmarks (int8_hex, bfloat16_hex, float32_hex, float64_hex, sparse, mixed, etc.)
- Full pipeline throughput benchmark (realistic config with multiple converters)
- Multiple input sizes: 100, 1K, 10K records to show scaling behavior

### Correctness Tests
- Hardcode expected values from Vespa documentation in test assertions
- Use static snapshots of doc examples as test fixtures (committed to repo)
- Reference doc URLs in comments for traceability

### Claude's Discretion
- Test organization structure (by converter type vs. by category vs. existing pattern)
- Test categories to cover (boundaries, round-trip, errors, realistic data)
- Specific embedding dimensions and tensor sizes for benchmarks
- pytest-benchmark configuration details
- GitHub Pages theme/layout

</decisions>

<specifics>
## Specific Ideas

- "I want the tests to be relevant and comparable over time"
- Benchmark graphs should show performance trends across releases
- 10% regression threshold chosen to catch significant regressions without false positives

</specifics>

<deferred>
## Deferred Ideas

None — discussion stayed within phase scope

</deferred>

---

*Phase: 11-testing-and-benchmarks*
*Context gathered: 2026-02-03*
