# Phase 11: Testing and Benchmarks - Research

**Researched:** 2026-02-03
**Domain:** Python testing with pytest-benchmark, CI/CD with GitHub Actions, benchmark visualization
**Confidence:** HIGH

## Summary

This phase validates all converter functionality through correctness tests against Vespa documentation, and establishes performance benchmarks with CI integration. The research confirms pytest-benchmark 5.2.3 as the standard tool for Python benchmarking, with github-action-benchmark providing GitHub Pages visualization and regression detection.

The locked decisions specify pytest-benchmark for measurements, GitHub Actions on tags, GitHub Pages charts, and a 10% regression threshold to block releases. The existing test structure (92 tests in `tests/test_converters.py`) provides a solid foundation to extend with doc-verified correctness tests and benchmark infrastructure.

**Primary recommendation:** Use pytest-benchmark with `--benchmark-json` output, integrate with `benchmark-action/github-action-benchmark@v1` for GitHub Pages visualization and 10% regression detection via `alert-threshold: '110'`.

## Standard Stack

The established libraries/tools for this domain:

### Core
| Library | Version | Purpose | Why Standard |
|---------|---------|---------|--------------|
| pytest-benchmark | 5.2.3 | Micro-benchmark fixture for pytest | De facto standard, auto-calibration, JSON export, regression detection |
| github-action-benchmark | v1 | CI benchmark integration | Official action for pytest, GitHub Pages charts, alert thresholds |

### Supporting
| Library | Version | Purpose | When to Use |
|---------|---------|---------|-------------|
| pytest | 8.3.x | Test framework | Required foundation |
| pygal + pygaljs | latest | Local histogram generation | Optional local visualization with `--benchmark-histogram` |

### Alternatives Considered
| Instead of | Could Use | Tradeoff |
|------------|-----------|----------|
| pytest-benchmark | timeit | Manual, no fixtures, no JSON, no CI integration |
| github-action-benchmark | pytest-benchmark-commenter | Only PR comments, no historical charts |
| GitHub Pages | External dashboard | More setup, leaves GitHub ecosystem |

**Installation:**
```bash
pip install pytest-benchmark
# Optional for local histograms:
pip install pytest-benchmark[histogram]
```

**pyproject.toml addition:**
```toml
[project.optional-dependencies]
dev = [
    "pytest>=8.0.0",
    "pytest-benchmark>=5.2.0",
]
```

## Architecture Patterns

### Recommended Test Structure
```
tests/
├── __init__.py
├── test_converters.py      # Existing 92 tests (extend with doc-verified cases)
├── test_cli.py             # Existing CLI tests
├── test_pipeline.py        # Existing pipeline tests
├── benchmarks/             # NEW: Benchmark test directory
│   ├── __init__.py
│   ├── conftest.py         # Benchmark fixtures (data generators)
│   ├── test_converter_benchmarks.py  # Individual converter perf
│   └── test_pipeline_benchmarks.py   # Full pipeline throughput
└── fixtures/               # NEW: Static test data
    └── vespa_doc_examples.py  # Hardcoded Vespa doc examples
```

### Pattern 1: Benchmark Test Structure
**What:** Each benchmark test uses the `benchmark` fixture with a pure function
**When to use:** All benchmark tests
**Example:**
```python
# Source: https://pytest-benchmark.readthedocs.io/en/latest/usage.html
import pytest
from hf_vespa_feed.converters import list_to_tensor_int8_hex

def test_int8_hex_100(benchmark):
    """Benchmark int8 hex encoder with 100 values."""
    data = list(range(-50, 50))  # 100 int8 values
    result = benchmark(list_to_tensor_int8_hex, data)
    assert "values" in result

@pytest.mark.benchmark(group="int8_hex")
@pytest.mark.parametrize("size", [100, 1000, 10000])
def test_int8_hex_scaling(benchmark, size):
    """Benchmark int8 hex encoder across sizes."""
    data = [i % 256 - 128 for i in range(size)]
    benchmark(list_to_tensor_int8_hex, data)
```

### Pattern 2: Doc-Verified Correctness Test
**What:** Test with expected values from Vespa documentation
**When to use:** Correctness tests for all converters
**Example:**
```python
# Source: https://docs.vespa.ai/en/reference/schemas/document-json-format.html
def test_int8_hex_vespa_doc_example():
    """Verify int8 hex matches Vespa documentation example.

    Doc: tensor<int8>(x[6]):[-1,0,17,-128,34,-2] -> "FF00118022FE"
    Source: https://docs.vespa.ai/en/reference/schemas/document-json-format.html
    """
    from hf_vespa_feed.converters import list_to_tensor_int8_hex

    result = list_to_tensor_int8_hex([-1, 0, 17, -128, 34, -2])
    # Vespa uses uppercase, our implementation uses lowercase - both valid hex
    assert result["values"].upper() == "FF00118022FE"
```

### Pattern 3: Parametrized Size Testing
**What:** Test multiple input sizes to show scaling behavior
**When to use:** Benchmark tests requiring size comparison
**Example:**
```python
@pytest.mark.parametrize("size,expected_min_ops", [
    (100, 10000),      # Expect >10K ops/sec for small inputs
    (1000, 5000),      # Expect >5K ops/sec for medium inputs
    (10000, 1000),     # Expect >1K ops/sec for large inputs
])
def test_float32_hex_minimum_throughput(benchmark, size, expected_min_ops):
    """Verify minimum throughput for float32 hex encoding."""
    data = [float(i) for i in range(size)]
    result = benchmark(list_to_tensor_float32_hex, data)
    # Ops/sec available in benchmark.stats after run
    assert benchmark.stats["ops"] >= expected_min_ops
```

### Anti-Patterns to Avoid
- **Benchmarking with I/O:** Never include file/network I/O in benchmark timing - isolate pure computation
- **Using `@benchmark` decorator:** Less accurate than `benchmark(func, args)` for micro-benchmarks
- **Multiple benchmark calls per test:** Only one `benchmark()` call allowed per test function
- **Benchmarking setup code:** Use `benchmark.pedantic(func, setup=setup_fn)` if setup needed
- **Ignoring warmup on PyPy:** Always enable warmup if PyPy support needed

## Don't Hand-Roll

Problems that look simple but have existing solutions:

| Problem | Don't Build | Use Instead | Why |
|---------|-------------|-------------|-----|
| Timing measurement | Manual `time.time()` loops | pytest-benchmark fixture | Auto-calibration, statistical analysis, CI integration |
| Historical tracking | Custom JSON storage | github-action-benchmark | Charts, alerts, gh-pages integration |
| Regression detection | Manual threshold checks | `--benchmark-compare-fail` or action alerts | Automatic comparison, CI-integrated failure |
| Chart generation | Custom plotting code | github-action-benchmark Chart.js | Auto-generated, responsive, historical |
| Timer calibration | Manual round counting | pytest-benchmark calibration | Accounts for timer resolution, automatic |

**Key insight:** Benchmarking has subtle issues (timer resolution, warmup, calibration, statistical validity) that pytest-benchmark handles automatically. Hand-rolled solutions miss these edge cases.

## Common Pitfalls

### Pitfall 1: Inconsistent Benchmark Environment
**What goes wrong:** Results vary wildly between CI runs
**Why it happens:** CPU throttling, other processes, Turbo Boost, VM overhead
**How to avoid:**
- Use GitHub Actions' hosted runners (consistent but shared)
- Set reasonable alert thresholds (10% accounts for noise)
- Use `mean` or `median` instead of `min` for comparisons
**Warning signs:** High standard deviation, spikes in min values

### Pitfall 2: Testing Too Large Code Chunks
**What goes wrong:** Benchmarks measure irrelevant overhead
**Why it happens:** Including setup, I/O, or multiple operations
**How to avoid:** Benchmark pure functions only, isolate converter logic
**Warning signs:** Results dominated by non-target operations

### Pitfall 3: Incorrect JSON Output Path
**What goes wrong:** github-action-benchmark fails to find results
**Why it happens:** Relative vs absolute paths, wrong directory
**How to avoid:** Use explicit path: `--benchmark-json=benchmark-results.json`
**Warning signs:** "No benchmark results found" in CI logs

### Pitfall 4: Benchmarking Empty or Trivial Data
**What goes wrong:** Results don't reflect real-world performance
**Why it happens:** Using tiny test cases (1-2 elements)
**How to avoid:** Use realistic sizes (100, 1K, 10K elements)
**Warning signs:** Sub-microsecond timings dominated by overhead

### Pitfall 5: Not Grouping Related Benchmarks
**What goes wrong:** Hard to compare related converters
**Why it happens:** Missing `@pytest.mark.benchmark(group="...")`
**How to avoid:** Group benchmarks by converter type or operation
**Warning signs:** Unorganized output tables, hard to find regressions

### Pitfall 6: Alert Threshold Too Tight
**What goes wrong:** False positive CI failures
**Why it happens:** Natural variance in CI environment
**How to avoid:** Use 10% threshold (110% in action config means 10% regression)
**Warning signs:** Frequent benchmark failures without code changes

## Code Examples

Verified patterns from official sources:

### Benchmark Configuration (pytest.ini or pyproject.toml)
```toml
# Source: https://pytest-benchmark.readthedocs.io/en/latest/usage.html
[tool.pytest.ini_options]
# Benchmark-specific settings
addopts = "--benchmark-disable"  # Disable by default, enable explicitly
markers = [
    "benchmark: marks tests as benchmarks (deselect with '-m \"not benchmark\"')",
]
```

### GitHub Actions Workflow for Benchmarks
```yaml
# Source: https://github.com/benchmark-action/github-action-benchmark
name: Benchmark

on:
  push:
    tags:
      - 'v*'  # Run on version tags only

permissions:
  contents: write
  deployments: write

jobs:
  benchmark:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.12'

      - name: Install dependencies
        run: |
          pip install -e ".[dev]"

      - name: Run benchmarks
        run: |
          pytest tests/benchmarks/ \
            --benchmark-json=benchmark-results.json \
            --benchmark-min-rounds=5 \
            --benchmark-warmup=on

      - name: Store benchmark result
        uses: benchmark-action/github-action-benchmark@v1
        with:
          name: 'Converter Benchmarks'
          tool: 'pytest'
          output-file-path: benchmark-results.json
          github-token: ${{ secrets.GITHUB_TOKEN }}
          auto-push: true
          alert-threshold: '110%'  # 10% regression threshold
          fail-on-alert: true      # Block release on regression
          comment-on-alert: true
          alert-comment-cc-users: '@maintainer'
```

### Benchmark Test with Data Generator Fixture
```python
# tests/benchmarks/conftest.py
import pytest

@pytest.fixture
def embedding_data():
    """Generate embedding data for various sizes."""
    def _generate(size: int, dim: int = 768) -> list[dict]:
        """Generate list of embedding dicts."""
        return [
            {"embedding": [float(i + j) for j in range(dim)]}
            for i in range(size)
        ]
    return _generate

@pytest.fixture
def sparse_data():
    """Generate sparse tensor data."""
    def _generate(size: int, vocab_size: int = 100) -> list[dict]:
        """Generate sparse tensor dicts."""
        return [
            {f"word_{j % vocab_size}": float(j) for j in range(i % vocab_size + 1)}
            for i in range(size)
        ]
    return _generate
```

### Correctness Test with Vespa Doc Reference
```python
# tests/test_converters.py (additions)

class TestVespaDocVerification:
    """Tests verifying output matches Vespa documentation examples.

    All expected values are hardcoded from official Vespa documentation.
    """

    def test_int8_hex_doc_example(self):
        """Verify int8 hex encoding matches Vespa doc.

        Source: https://docs.vespa.ai/en/reference/schemas/document-json-format.html
        Example: tensor<int8>(x[6]):[-1,0,17,-128,34,-2] -> "FF00118022FE"
        """
        from hf_vespa_feed.converters import list_to_tensor_int8_hex

        result = list_to_tensor_int8_hex([-1, 0, 17, -128, 34, -2])
        assert result["values"].upper() == "FF00118022FE"

    def test_bfloat16_hex_known_values(self):
        """Verify bfloat16 hex encoding matches IEEE 754 truncation.

        1.0 as float32 = 0x3F800000, bfloat16 = 0x3F80
        -1.0 as float32 = 0xBF800000, bfloat16 = 0xBF80
        """
        from hf_vespa_feed.converters import list_to_tensor_bfloat16_hex

        result = list_to_tensor_bfloat16_hex([1.0, -1.0])
        assert result["values"] == "3f80bf80"

    def test_float32_hex_ieee754(self):
        """Verify float32 hex encoding matches IEEE 754.

        1.0 as float32 = 0x3F800000
        2.0 as float32 = 0x40000000
        """
        from hf_vespa_feed.converters import list_to_tensor_float32_hex

        result = list_to_tensor_float32_hex([1.0, 2.0])
        assert result["values"] == "3f80000040000000"

    def test_float64_hex_ieee754(self):
        """Verify float64 hex encoding matches IEEE 754.

        1.0 as float64 = 0x3FF0000000000000
        pi as float64 = 0x400921FB54442D18
        """
        from hf_vespa_feed.converters import list_to_tensor_float64_hex

        result = list_to_tensor_float64_hex([1.0])
        assert result["values"] == "3ff0000000000000"

        result = list_to_tensor_float64_hex([3.141592653589793])
        assert result["values"] == "400921fb54442d18"
```

### Full Pipeline Throughput Benchmark
```python
# tests/benchmarks/test_pipeline_benchmarks.py
import pytest
from hf_vespa_feed.pipeline import apply_mappings
from hf_vespa_feed.config import FieldMapping

@pytest.mark.benchmark(group="pipeline")
class TestPipelineThroughput:
    """Benchmark full pipeline throughput with realistic configs."""

    @pytest.fixture
    def realistic_config(self):
        """Config with multiple converter types."""
        return [
            FieldMapping(source="embedding", target="embedding", type="tensor_float32_hex"),
            FieldMapping(source="sparse", target="sparse", type="sparse_tensor"),
            FieldMapping(source="title", target="title", type="string"),
            FieldMapping(source="score", target="score", type="float"),
        ]

    @pytest.fixture
    def realistic_record(self):
        """Single realistic record."""
        return {
            "embedding": [float(i) for i in range(768)],
            "sparse": {f"word_{i}": float(i) for i in range(50)},
            "title": "Example document title",
            "score": 0.95,
        }

    @pytest.mark.parametrize("batch_size", [100, 1000, 10000])
    def test_pipeline_throughput(self, benchmark, realistic_config, realistic_record, batch_size):
        """Measure records/sec for full pipeline."""
        records = [realistic_record.copy() for _ in range(batch_size)]

        def process_batch():
            return [apply_mappings(r, realistic_config, row_num=i) for i, r in enumerate(records)]

        benchmark(process_batch)
```

## State of the Art

| Old Approach | Current Approach | When Changed | Impact |
|--------------|------------------|--------------|--------|
| Manual timeit loops | pytest-benchmark fixture | ~2018 | Auto-calibration, CI integration |
| Screenshot results | github-action-benchmark charts | ~2020 | Automated historical tracking |
| Local comparisons only | CI-integrated regression detection | ~2021 | Block regressions before merge |
| Python 3.8 support | Python 3.9+ only | 2025 | Modern type hints, faster |

**Deprecated/outdated:**
- pytest-benchmark `--benchmark-cprofile` is deprecated, use `--benchmark-cprofile-loops` instead
- Python 3.8 support dropped in pytest-benchmark 5.x

## Open Questions

Things that couldn't be fully resolved:

1. **Exact ops/sec thresholds for each converter**
   - What we know: Need to establish baseline performance
   - What's unclear: Acceptable minimum throughput values
   - Recommendation: Run initial benchmarks, set thresholds at 80% of baseline

2. **Vespa documentation hex format case sensitivity**
   - What we know: Vespa docs show uppercase (FF00), our implementation uses lowercase (ff00)
   - What's unclear: Whether Vespa accepts both
   - Recommendation: Test both cases, compare `.upper()` in tests for safety

3. **GitHub Pages branch setup timing**
   - What we know: Need gh-pages branch before first workflow run
   - What's unclear: Whether workflow auto-creates it
   - Recommendation: Manually create orphan gh-pages branch before enabling workflow

## Sources

### Primary (HIGH confidence)
- [pytest-benchmark 5.2.3 documentation](https://pytest-benchmark.readthedocs.io/) - Usage, CLI options, FAQ
- [github-action-benchmark](https://github.com/benchmark-action/github-action-benchmark) - CI integration, workflow examples
- [Vespa document-json-format](https://docs.vespa.ai/en/reference/schemas/document-json-format.html) - Hex encoding examples

### Secondary (MEDIUM confidence)
- [pytest-benchmark PyPI](https://pypi.org/project/pytest-benchmark/) - Version 5.2.3, Python 3.9+ requirement
- [Vespa tensor-user-guide](https://docs.vespa.ai/en/ranking/tensor-user-guide.html) - Tensor formats (cells, blocks, values)

### Tertiary (LOW confidence)
- WebSearch results on pytest-benchmark best practices - Common patterns verified with docs

## Metadata

**Confidence breakdown:**
- Standard stack: HIGH - pytest-benchmark and github-action-benchmark are well-documented, actively maintained
- Architecture: HIGH - Test patterns verified from official pytest-benchmark documentation
- Pitfalls: MEDIUM - Some derived from general benchmarking knowledge, verified where possible

**Research date:** 2026-02-03
**Valid until:** 2026-03-03 (30 days - stable ecosystem)
