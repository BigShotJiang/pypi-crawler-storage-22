# Phase 12 Plan 01: Fix Bad File Descriptor Error Summary

## Frontmatter

```yaml
phase: 12
plan: 01
subsystem: cli
tags: [exit-handling, cleanup, pyarrow-bug, huggingface]

# Dependency graph for future context retrieval
dependency-graph:
  requires:
    - phases/04-polish/04-02-SUMMARY.md  # CLI structure
  provides:
    - Clean CLI exit without error messages
    - Prevention of PyArrow cleanup hang bug
  affects:
    - Any future streaming dataset usage

# Tech stack changes
tech-stack:
  patterns:
    - os._exit() for immediate exit
    - Logger suppression at module load
    - Environment variable cleanup control

# Key files for retrieval
key-files:
  created: []
  modified:
    - src/hf_vespa_feed/cli.py
    - tests/test_cli.py

# Decisions made
decisions:
  - id: 12-01-01
    choice: Suppress HF HTTP logger at module startup
    rationale: Prevents error messages from any cleanup path
  - id: 12-01-02
    choice: Use os._exit() instead of normal exit
    rationale: Skip Python cleanup that triggers PyArrow bug
  - id: 12-01-03
    choice: Set HF_HUB_OFFLINE before cleanup
    rationale: Prevents HTTP retry loops during garbage collection

# Performance metrics
metrics:
  duration: ~5 minutes
  completed: 2026-02-03
```

## One-liner

Fix "Bad file descriptor" error on exit by suppressing HF HTTP logger and using os._exit() to prevent PyArrow cleanup hangs.

## What Was Done

### Task 1: Add logging suppression and cleanup infrastructure
- Added logging suppression for `huggingface_hub.utils._http` at module startup (before docstring)
- Added warnings filter for multiprocessing `resource_tracker` leaked semaphore warnings
- Added `gc` import for garbage collection
- Created `_cleanup_hf_resources()` function that:
  - Sets `HF_HUB_OFFLINE=1` to prevent HTTP retry loops
  - Forces garbage collection to trigger finalizers early

### Task 2: Add cleanup call in feed_impl
- Added `_cleanup_hf_resources()` call in the `finally:` block after `report_completion()`
- Cleanup runs immediately after processing, before iterator garbage collection

### Task 3: Update run() to use os._exit()
- Wrapped `app()` call in try/except to capture SystemExit exit code
- Added `_cleanup_hf_resources()` call before exit
- Flush stdout/stderr before exit
- Use `os._exit(exit_code)` to skip Python's cleanup phase

### Task 4: Create test for clean exit behavior
- Added subprocess-based test that runs CLI as separate process
- Verifies exit code 0
- Verifies no "Errno", "Bad file descriptor", or "Retrying" in stderr
- Uses 60s timeout to detect hangs
- Clears HF_HUB_OFFLINE from environment to prevent test pollution

### Task 5: Run tests to verify fix
- All 177 tests pass
- Manual verification shows clean exit with no error messages

## Commits

| Hash | Type | Description |
|------|------|-------------|
| d488467 | feat | add logging suppression and cleanup infrastructure |
| e048ca0 | feat | add cleanup call in feed_impl finally block |
| c26cfa1 | fix | update run() to use os._exit() to prevent hangs |
| 4e256ee | test | add test for clean exit without hanging |
| 41dce7b | fix | suppress multiprocessing resource_tracker warnings on exit |

## Decisions Made

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Where to suppress logger | Module top (before docstring) | Earliest possible point, before any HF imports |
| Exit method | os._exit() | Required to skip Python cleanup that triggers bug |
| Cleanup timing | Both in feed_impl and run() | Belt and suspenders for all code paths |

## Artifacts

### Modified: `src/hf_vespa_feed/cli.py`

Key additions:
```python
# At module top (before docstring)
import logging as _logging
_logging.getLogger('huggingface_hub.utils._http').setLevel(_logging.CRITICAL)
del _logging

# New cleanup function
def _cleanup_hf_resources() -> None:
    """Clean up HuggingFace Hub resources to prevent exit hangs."""
    os.environ["HF_HUB_OFFLINE"] = "1"
    gc.collect()

# Updated run() with os._exit()
def run() -> None:
    exit_code = 0
    try:
        app()
    except SystemExit as e:
        exit_code = e.code if isinstance(e.code, int) else 1
    _cleanup_hf_resources()
    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(exit_code)
```

### Modified: `tests/test_cli.py`

New test function `test_feed_does_not_hang_on_exit()` that verifies clean exit behavior using subprocess.

## Deviations from Plan

None - plan executed exactly as written.

## Next Phase Readiness

**Phase 12 Complete**: The v2.1 Clean Exit milestone is complete. The "Bad file descriptor" error no longer appears after successful processing.

**Verification results**:
- `hf-vespa-feed glue --config ax --split test --limit 10` completes with exit code 0
- No error messages in stderr (only progress bar and completion stats)
- All 177 tests pass
