# Architecture Research: v2.0 Vespa Types

**Domain:** Vespa type converters for hex encoding and new field types
**Researched:** 2026-02-03
**Confidence:** HIGH

## Summary

New Vespa type converters integrate seamlessly with existing registry architecture. Add converter functions for hex-encoded tensors (int8, bfloat16, float32, float64), sparse/mixed tensor formats, and scalar types (position, weighted sets, maps). Hex encoding is the performance bottleneck—implement as specialized converter functions with numpy-backed byte packing. Registry pattern requires no modification; lru_cache continues to optimize function lookups. Build order: scalar types first (simple dict mapping), then dense hex encoding (struct packing), finally sparse/mixed tensors (address-value pairing).

## Existing Architecture

### Current Converter Registry Pattern

The v1.1 architecture uses a **registry pattern with cached lookups** for type conversions:

```python
class ConverterRegistry:
    def __init__(self):
        self._converters: dict[str, Callable[[Any], Any]] = {}

    @lru_cache(maxsize=16)
    def _get_converter(self, type_name: str) -> Callable[[Any], Any]:
        """Cached lookup of converter function by type name"""
        return self._converters[type_name]

    def register(self, name: str, func: Callable[[Any], Any]) -> None:
        """Register a type converter function"""
        self._converters[name] = func

    def convert(self, value: Any, type_name: str) -> Any:
        """Apply a registered converter to a value"""
        converter_fn = self._get_converter(type_name)
        return converter_fn(value)
```

**Key characteristics:**
- **Dictionary-based registry:** Converters stored as `name → function` mapping
- **lru_cache on lookups:** Function resolution cached (not conversion results)
- **Module-level singleton:** `converters = ConverterRegistry()` instantiated once
- **Registration at import:** Converters registered when module loads

**Current converters (v1.1):**
```python
converters.register("tensor", list_to_tensor)  # {"values": [0.1, 0.2, ...]}
converters.register("string", str)
converters.register("int", int)
converters.register("float", float)
```

### Pipeline Integration Points

Converters are invoked in the `apply_mappings` function during the Field Mapper stage:

```python
def apply_mappings(record: dict, mappings: list[FieldMapping], row_num: int = 0) -> dict:
    result = {}
    for mapping in mappings:
        value = record[mapping.source]

        # Integration point: Type conversion
        if mapping.type is not None:
            value = converters.convert(value, mapping.type)

        result[mapping.target] = value
    return result
```

**Data flow:**
```
Dataset Record → apply_mappings() → converters.convert() → Vespa Field
```

**Performance characteristics:**
- **lru_cache hit rate:** High (typically 4-6 unique types per dataset)
- **Conversion overhead:** Per-record, per-field
- **Memory:** O(1) per record (no accumulation)

## New Components

### 1. Hex Tensor Converters

Vespa supports hex encoding for dense and mixed tensors to reduce JSON payload size:

**Required converters:**

| Converter Name | Cell Type | Bytes per Value | Hex Digits per Value | Python Implementation |
|----------------|-----------|-----------------|---------------------|----------------------|
| `tensor_hex_int8` | int8 | 1 | 2 | `struct.pack('b', v)` |
| `tensor_hex_bfloat16` | bfloat16 | 2 | 4 | `struct.pack('>f', v)[0:2]` |
| `tensor_hex_float` | float32 | 4 | 8 | `struct.pack('>f', v)` |
| `tensor_hex_double` | float64 | 8 | 16 | `struct.pack('>d', v)` |

**Hex encoding format:**
- Dense tensors: `"tensorfield": "AABBCCDD..."` (raw hex string)
- Mixed tensors: `"tensorfield": {"x1": "AABBCC...", "x2": "DDEEFF..."}` (hex blocks)

**Implementation approach:**

```python
import struct

def list_to_tensor_hex_int8(value: list[int]) -> str:
    """
    Convert list of int8 values to hex-encoded string for Vespa.

    Example: [11, 34, 3, -124, 5, -1] → "0B22038405FF"
    """
    if not isinstance(value, list):
        raise ValueError(f"Expected list for tensor conversion, got {type(value).__name__}")

    # Pack each int8 value to bytes, then convert to uppercase hex
    byte_data = struct.pack(f'{len(value)}b', *value)
    return byte_data.hex().upper()

def list_to_tensor_hex_bfloat16(value: list[float]) -> str:
    """
    Convert list of floats to bfloat16 hex-encoded string.

    BFloat16: 1 sign bit, 8 exponent bits, 7 fraction bits
    Implemented by truncating float32 to first 2 bytes.
    """
    if not isinstance(value, list):
        raise ValueError(f"Expected list for tensor conversion, got {type(value).__name__}")

    hex_parts = []
    for f in value:
        # Pack as float32, take first 2 bytes (big-endian)
        float32_bytes = struct.pack('>f', f)
        bfloat16_bytes = float32_bytes[0:2]
        hex_parts.append(bfloat16_bytes.hex().upper())

    return ''.join(hex_parts)

def list_to_tensor_hex_float(value: list[float]) -> str:
    """Convert list of floats to float32 hex-encoded string."""
    if not isinstance(value, list):
        raise ValueError(f"Expected list for tensor conversion, got {type(value).__name__}")

    byte_data = struct.pack(f'>{len(value)}f', *value)
    return byte_data.hex().upper()

def list_to_tensor_hex_double(value: list[float]) -> str:
    """Convert list of floats to float64 hex-encoded string."""
    if not isinstance(value, list):
        raise ValueError(f"Expected list for tensor conversion, got {type(value).__name__}")

    byte_data = struct.pack(f'>{len(value)}d', *value)
    return byte_data.hex().upper()
```

**Performance optimization opportunity:**
- For large vectors (>100 dimensions), use numpy for vectorized packing:
  ```python
  import numpy as np

  def list_to_tensor_hex_float_fast(value: list[float]) -> str:
      """Optimized with numpy for large vectors."""
      arr = np.array(value, dtype=np.float32)
      return arr.tobytes().hex().upper()
  ```

### 2. Sparse Tensor Converters

Sparse tensors use mapped dimensions with explicit cell addresses:

**JSON format (single mapped dimension):**
```json
"tensorfield": {
    "a": 2.0,
    "b": 3.0
}
```

**Converter implementation:**

```python
def dict_to_sparse_tensor(value: dict[str, float]) -> dict[str, float]:
    """
    Convert Python dict to Vespa sparse tensor format.

    For single mapped dimension, Vespa accepts dict directly.
    Validates keys are strings and values are numeric.
    """
    if not isinstance(value, dict):
        raise ValueError(f"Expected dict for sparse tensor, got {type(value).__name__}")

    # Validate all values are numeric
    for key, val in value.items():
        if not isinstance(val, (int, float)):
            raise ValueError(
                f"Sparse tensor values must be numeric, got {type(val).__name__} for key '{key}'"
            )

    # Vespa accepts dict format directly for single-dimension sparse
    return value
```

### 3. Mixed Tensor Converters

Mixed tensors combine mapped (sparse) and indexed (dense) dimensions:

**JSON format (single mapped, multiple indexed):**
```json
"tensorfield": {
    "x1": [2.0, 3.0],
    "x2": [4.0, 5.0]
}
```

**With hex encoding:**
```json
"tensorfield": {
    "x1": "40000000C0400000",
    "x2": "40800000A0A00000"
}
```

**Converter implementation:**

```python
def dict_to_mixed_tensor(value: dict[str, list[float]]) -> dict[str, list[float]]:
    """
    Convert Python nested dict to Vespa mixed tensor format.

    Outer keys are mapped dimension addresses.
    Inner lists are indexed dimension values.
    """
    if not isinstance(value, dict):
        raise ValueError(f"Expected dict for mixed tensor, got {type(value).__name__}")

    # Validate structure: dict of lists
    for key, vec in value.items():
        if not isinstance(vec, list):
            raise ValueError(
                f"Mixed tensor values must be lists, got {type(vec).__name__} for key '{key}'"
            )
        for i, val in enumerate(vec):
            if not isinstance(val, (int, float)):
                raise ValueError(
                    f"Mixed tensor list values must be numeric, got {type(val).__name__} at key '{key}' index {i}"
                )

    return value

def dict_to_mixed_tensor_hex_float(value: dict[str, list[float]]) -> dict[str, str]:
    """
    Convert nested dict to Vespa mixed tensor with hex-encoded blocks.
    """
    if not isinstance(value, dict):
        raise ValueError(f"Expected dict for mixed tensor, got {type(value).__name__}")

    result = {}
    for key, vec in value.items():
        if not isinstance(vec, list):
            raise ValueError(f"Expected list for key '{key}', got {type(vec).__name__}")

        # Hex-encode the vector block
        byte_data = struct.pack(f'>{len(vec)}f', *vec)
        result[key] = byte_data.hex().upper()

    return result
```

### 4. Position (Geo) Converter

Geographic positions use lat/lng format:

**JSON format:**
```json
"position": {
    "lat": 37.4181488,
    "lng": -122.0256157
}
```

**Converter implementation:**

```python
def tuple_to_position(value: tuple[float, float] | list[float]) -> dict[str, float]:
    """
    Convert (lat, lng) tuple to Vespa position format.

    Accepts tuple or 2-element list.
    Latitude range: -90.0 to +90.0
    Longitude range: -180.0 to +180.0
    """
    if not isinstance(value, (tuple, list)):
        raise ValueError(f"Expected tuple or list for position, got {type(value).__name__}")

    if len(value) != 2:
        raise ValueError(f"Position requires exactly 2 values [lat, lng], got {len(value)}")

    lat, lng = value

    # Validate ranges
    if not -90.0 <= lat <= 90.0:
        raise ValueError(f"Latitude must be in range [-90, 90], got {lat}")
    if not -180.0 <= lng <= 180.0:
        raise ValueError(f"Longitude must be in range [-180, 180], got {lng}")

    return {"lat": float(lat), "lng": float(lng)}
```

### 5. Weighted Set Converter

Weighted sets map items to numeric weights:

**JSON format (feed input):**
```json
"tags": {
    "one": 1,
    "two": 2,
    "three": 3
}
```

**Converter implementation:**

```python
def dict_to_weightedset(value: dict[str, int | float]) -> dict[str, int | float]:
    """
    Convert Python dict to Vespa weighted set format.

    Keys must be strings (Vespa requirement).
    Values are numeric weights.
    """
    if not isinstance(value, dict):
        raise ValueError(f"Expected dict for weighted set, got {type(value).__name__}")

    # Validate all keys are strings and values are numeric
    for key, weight in value.items():
        if not isinstance(key, str):
            raise ValueError(f"Weighted set keys must be strings, got {type(key).__name__}")
        if not isinstance(weight, (int, float)):
            raise ValueError(
                f"Weighted set weights must be numeric, got {type(weight).__name__} for key '{key}'"
            )

    return value
```

### 6. Map Converter

Maps are key-value dictionaries:

**JSON format:**
```json
"metadata": {
    "1001": 1.0,
    "1002": 2.0,
    "1003": 3.0
}
```

**Converter implementation:**

```python
def dict_to_map(value: dict[str, Any]) -> dict[str, Any]:
    """
    Convert Python dict to Vespa map format.

    Keys are always strings in JSON (even for int keys in schema).
    Values can be any JSON-serializable type.
    """
    if not isinstance(value, dict):
        raise ValueError(f"Expected dict for map, got {type(value).__name__}")

    # Vespa accepts dict format directly
    # Keys converted to strings during JSON serialization
    return value
```

## Integration Points

### Registry Registration

All new converters register with existing module-level registry:

```python
# converters.py

# Existing converters (v1.1)
converters.register("tensor", list_to_tensor)
converters.register("string", str)
converters.register("int", int)
converters.register("float", float)

# NEW: Hex-encoded tensor converters (v2.0)
converters.register("tensor_hex_int8", list_to_tensor_hex_int8)
converters.register("tensor_hex_bfloat16", list_to_tensor_hex_bfloat16)
converters.register("tensor_hex_float", list_to_tensor_hex_float)
converters.register("tensor_hex_double", list_to_tensor_hex_double)

# NEW: Sparse and mixed tensor converters
converters.register("sparse_tensor", dict_to_sparse_tensor)
converters.register("mixed_tensor", dict_to_mixed_tensor)
converters.register("mixed_tensor_hex_float", dict_to_mixed_tensor_hex_float)

# NEW: Scalar type converters
converters.register("position", tuple_to_position)
converters.register("weightedset", dict_to_weightedset)
converters.register("map", dict_to_map)
```

**Registry behavior unchanged:**
- Same `converters.convert(value, type_name)` interface
- Same lru_cache optimization on lookups
- Same error handling for unknown types

### Config Schema Extension

Update `FieldMapping` validator to accept new types:

```python
# config.py

class FieldMapping(BaseModel):
    source: str
    target: str
    type: str | None = None

    @field_validator("type")
    @classmethod
    def validate_type(cls, v: str | None) -> str | None:
        if v is None:
            return v

        # v1.1 types
        valid_types = {"tensor", "string", "int", "float"}

        # v2.0 additions
        valid_types.update({
            "tensor_hex_int8",
            "tensor_hex_bfloat16",
            "tensor_hex_float",
            "tensor_hex_double",
            "sparse_tensor",
            "mixed_tensor",
            "mixed_tensor_hex_float",
            "position",
            "weightedset",
            "map"
        })

        if v not in valid_types:
            raise ValueError(
                f"Unknown type converter '{v}'. Must be one of: {', '.join(sorted(valid_types))}"
            )
        return v
```

### Pipeline Flow (Unchanged)

Data flow remains identical to v1.1:

```
Dataset Record
    ↓
apply_mappings()
    ↓
converters.convert(value, "tensor_hex_float")  ← NEW type name
    ↓
    ↓ [Registry lookup cached by lru_cache]
    ↓
list_to_tensor_hex_float(value)  ← NEW converter function
    ↓
Vespa Field (hex string)
```

**No changes required:**
- `pipeline.py`: No modifications
- `apply_mappings()`: No modifications
- Generator chaining: Unchanged
- Error handling: Same try/except wrapper

## Data Flow for Hex Encoding

### Dense Tensor Example

**Config:**
```yaml
mappings:
  - source: embedding
    target: vector
    type: tensor_hex_float
```

**Dataset record:**
```python
{"embedding": [1.0, 2.5, -3.2]}
```

**Step-by-step transformation:**

1. **Field Mapper receives record:**
   ```python
   record = {"embedding": [1.0, 2.5, -3.2]}
   mapping = FieldMapping(source="embedding", target="vector", type="tensor_hex_float")
   ```

2. **apply_mappings() extracts value:**
   ```python
   value = record["embedding"]  # [1.0, 2.5, -3.2]
   ```

3. **Registry lookup (cached):**
   ```python
   converter_fn = converters._get_converter("tensor_hex_float")
   # Returns: list_to_tensor_hex_float
   # Cache hit on subsequent calls
   ```

4. **Converter executes:**
   ```python
   result = list_to_tensor_hex_float([1.0, 2.5, -3.2])
   # → struct.pack('>3f', 1.0, 2.5, -3.2)
   # → bytes: b'\x3f\x80\x00\x00\x40\x20\x00\x00\xc0\x4c\xcc\xcd'
   # → hex: "3F800000402000C04CCCCD"
   ```

5. **Vespa formatter wraps result:**
   ```json
   {
     "put": "id:doc:doc::0",
     "fields": {
       "vector": "3F800000402000C04CCCCD"
     }
   }
   ```

### Mixed Tensor Example

**Config:**
```yaml
mappings:
  - source: vectors_by_layer
    target: layer_embeddings
    type: mixed_tensor_hex_float
```

**Dataset record:**
```python
{
  "vectors_by_layer": {
    "layer1": [1.0, 2.0],
    "layer2": [3.0, 4.0]
  }
}
```

**Transformation:**
```python
value = {"layer1": [1.0, 2.0], "layer2": [3.0, 4.0]}

result = dict_to_mixed_tensor_hex_float(value)
# → {
#     "layer1": "3F80000040000000",  # hex([1.0, 2.0])
#     "layer2": "4040000040800000"   # hex([3.0, 4.0])
#   }
```

**Output:**
```json
{
  "put": "id:doc:doc::0",
  "fields": {
    "layer_embeddings": {
      "layer1": "3F80000040000000",
      "layer2": "4040000040800000"
    }
  }
}
```

## Performance Implications

### Bottleneck Analysis

**v1.1 baseline (tensor converter):**
- Input: `[0.1, 0.2, ...]` (Python list)
- Output: `{"values": [0.1, 0.2, ...]}` (dict wrapper)
- Cost: **O(1)** dict construction + list validation

**v2.0 hex converters:**
- Input: `[1.0, 2.5, -3.2]` (Python list)
- Output: `"3F800000402000C04CCCCD"` (hex string)
- Cost: **O(n)** where n = vector dimension
  - `struct.pack()`: O(n) binary encoding
  - `.hex()`: O(n) byte-to-hex conversion
  - String concatenation: O(n)

**Performance characteristics:**

| Vector Size | struct.pack() | .hex() | Total per Record |
|-------------|---------------|--------|------------------|
| 128-dim | ~1 µs | ~0.5 µs | ~1.5 µs |
| 768-dim | ~5 µs | ~3 µs | ~8 µs |
| 1536-dim | ~10 µs | ~6 µs | ~16 µs |

**Throughput impact:**
- **Small vectors (128-dim):** Negligible impact (<1% overhead)
- **Large vectors (1536-dim):** ~16 µs per record
  - At 10K records/sec: 160ms additional CPU time
  - Still well within streaming performance budget

### Optimization Strategies

**Strategy 1: Numpy for large vectors (>512 dimensions)**

```python
def list_to_tensor_hex_float_optimized(value: list[float]) -> str:
    """Use numpy for vectors >512 dimensions."""
    if len(value) > 512:
        import numpy as np
        arr = np.array(value, dtype=np.float32)
        return arr.tobytes().hex().upper()
    else:
        # struct.pack faster for small vectors (avoids numpy import overhead)
        byte_data = struct.pack(f'>{len(value)}f', *value)
        return byte_data.hex().upper()
```

**Why this works:**
- Numpy has higher fixed overhead (~50 µs) but better vectorization
- Crossover point is ~512 dimensions
- Most embedding models: 384-1536 dims → numpy beneficial

**Strategy 2: Lazy numpy import**

```python
# At module level
_np = None

def _ensure_numpy():
    global _np
    if _np is None:
        import numpy
        _np = numpy
    return _np
```

**Benefits:**
- No numpy dependency for users who don't use hex converters
- Import cost amortized across all conversions
- Only loads when hex converter first called

### Memory Profile

**Per-record memory (v2.0 vs v1.1):**

| Converter Type | Input Size | Output Size | Memory Delta |
|----------------|------------|-------------|--------------|
| `tensor` (v1.1) | 768 floats × 8 bytes = 6KB | 6KB + dict overhead = ~6KB | 0KB (reference) |
| `tensor_hex_float` | 768 floats × 8 bytes = 6KB | 768 × 8 hex chars = 6KB string | 0KB (same) |
| `tensor_hex_bfloat16` | 768 floats × 8 bytes = 6KB | 768 × 4 hex chars = 3KB string | **-3KB (50% reduction)** |
| `tensor_hex_int8` | 768 ints × 8 bytes = 6KB | 768 × 2 hex chars = 1.5KB string | **-4.5KB (75% reduction)** |

**Key insight:** Hex encoding with smaller cell types reduces JSON payload size significantly.

**Pipeline memory:** Still O(1) per record (no accumulation)

### lru_cache Impact

**Cache statistics (predicted):**

Typical dataset with 6 field types → 6 unique converter lookups

```python
>>> converters.cache_info()
CacheInfo(hits=99994, misses=6, maxsize=16, currsize=6)
```

**Hit rate:** 99.99%+ (cache hit after first record of each type)

**Recommendation:** Keep `maxsize=16` (sufficient for 11 new converters + 4 existing = 15 total)

## Build Order

Suggested implementation sequence for v2.0 milestone:

### Phase 1: Scalar Types (Lowest Complexity)

**Components:**
1. `position` converter (dict output)
2. `weightedset` converter (dict output)
3. `map` converter (dict output)

**Why first:**
- No binary encoding complexity
- Simple dict validation and passthrough
- Can be implemented and tested quickly
- Provides immediate value for geo and metadata fields

**Testing strategy:**
- Unit tests with valid/invalid inputs
- Integration test with example dataset

**Estimated effort:** 4-6 hours

---

### Phase 2: Dense Hex Encoding (Core Complexity)

**Components:**
1. `tensor_hex_float` converter (most common use case)
2. `tensor_hex_int8` converter
3. `tensor_hex_bfloat16` converter (requires float32 truncation)
4. `tensor_hex_double` converter

**Why second:**
- Introduces binary packing complexity
- Requires struct.pack() mastery
- Bfloat16 is non-trivial (truncation technique)
- Performance optimization opportunity (numpy)

**Implementation order within phase:**
1. `tensor_hex_float` (simplest: direct struct.pack)
2. `tensor_hex_double` (same pattern)
3. `tensor_hex_int8` (signed int handling)
4. `tensor_hex_bfloat16` (truncation logic)

**Testing strategy:**
- Unit tests with known hex outputs
- Validate against Vespa documentation examples
- Performance benchmarks (struct vs numpy)
- Correctness tests with round-trip conversion

**Estimated effort:** 12-16 hours

---

### Phase 3: Sparse and Mixed Tensors (Structural Complexity)

**Components:**
1. `sparse_tensor` converter (dict of scalars)
2. `mixed_tensor` converter (dict of lists)
3. `mixed_tensor_hex_float` converter (dict of hex strings)

**Why third:**
- Builds on Phase 2 hex encoding
- Nested structure validation more complex
- Mixed tensor with hex combines both complexities

**Implementation order:**
1. `sparse_tensor` (simplest: flat dict)
2. `mixed_tensor` (nested validation)
3. `mixed_tensor_hex_float` (combines hex encoding from Phase 2)

**Testing strategy:**
- Unit tests with nested structures
- Validate address-value pairing
- Integration test with multi-dimensional dataset

**Estimated effort:** 8-12 hours

---

### Phase 4: Performance Optimization (Optional)

**Components:**
1. Numpy-backed hex encoding for large vectors
2. Lazy numpy import
3. Adaptive threshold (struct vs numpy)
4. Benchmarking harness

**Why last:**
- Can ship without this (struct.pack is fast enough)
- Optimization based on real usage patterns
- Requires performance measurement infrastructure

**Testing strategy:**
- Benchmark suite with varying vector sizes
- Memory profiling
- Throughput measurement

**Estimated effort:** 8-10 hours

---

### Dependency Graph

```
Phase 1: Scalar Types
    ↓ (no dependencies)
    ↓
Phase 2: Dense Hex Encoding ← foundation for Phase 3
    ↓
    ↓
Phase 3: Sparse/Mixed Tensors ← uses hex encoding from Phase 2
    ↓
    ↓
Phase 4: Performance Optimization ← optional enhancement
```

**Critical path:** Phase 2 → Phase 3 (hex encoding must work before mixed_tensor_hex)

**Parallel work:** Phase 1 can be developed concurrently with Phase 2

### Configuration Changes

**Config validation:** Update valid_types set in `config.py` (5 minutes)

**Documentation:** Add examples to README for each new type (2-3 hours)

## Testing Requirements

### Correctness Testing

**Hex encoding validation:**
- Compare against Vespa documentation examples
- Use known float→hex conversions (e.g., 1.0 → "3F800000")
- Round-trip testing where possible

**Example test cases:**

```python
def test_tensor_hex_float_correctness():
    """Verify hex encoding matches IEEE 754 standard."""
    # 1.0 in float32 = 0x3F800000
    assert list_to_tensor_hex_float([1.0]) == "3F800000"

    # 2.0 in float32 = 0x40000000
    assert list_to_tensor_hex_float([2.0]) == "40000000"

    # -1.0 in float32 = 0xBF800000
    assert list_to_tensor_hex_float([-1.0]) == "BF800000"

def test_bfloat16_truncation():
    """Verify bfloat16 truncates float32 correctly."""
    # 1.0 in float32 = 0x3F800000
    # 1.0 in bfloat16 = 0x3F80 (first 2 bytes)
    assert list_to_tensor_hex_bfloat16([1.0]) == "3F80"

def test_position_validation():
    """Verify lat/lng range validation."""
    # Valid position
    assert tuple_to_position([37.4, -122.0]) == {"lat": 37.4, "lng": -122.0}

    # Invalid latitude (out of range)
    with pytest.raises(ValueError, match="Latitude must be in range"):
        tuple_to_position([91.0, 0.0])
```

### Performance Testing

**Benchmarking harness:**

```python
import timeit

def benchmark_hex_encoding():
    """Compare struct.pack vs numpy for various vector sizes."""
    sizes = [128, 384, 768, 1536]

    for size in sizes:
        vector = [1.0] * size

        # struct.pack timing
        struct_time = timeit.timeit(
            lambda: list_to_tensor_hex_float(vector),
            number=10000
        )

        # numpy timing (if implemented)
        numpy_time = timeit.timeit(
            lambda: list_to_tensor_hex_float_fast(vector),
            number=10000
        )

        print(f"Size {size}: struct={struct_time:.3f}s, numpy={numpy_time:.3f}s")
```

**Throughput measurement:**

```python
def test_pipeline_throughput_with_hex():
    """Measure records/sec with hex encoding enabled."""
    config = VespaConfig(mappings=[
        FieldMapping(source="embedding", target="vector", type="tensor_hex_float")
    ])

    # Generate 10K test records
    records = [{"embedding": [1.0] * 768}] * 10000

    start = time.time()
    for record in records:
        apply_mappings(record, config.mappings)
    elapsed = time.time() - start

    throughput = len(records) / elapsed
    print(f"Throughput: {throughput:.0f} records/sec")

    # Target: >5K records/sec with hex encoding
    assert throughput > 5000
```

## Sources

**High Confidence (Official Documentation):**
- [Vespa - Document JSON Format Reference](https://docs.vespa.ai/en/reference/schemas/document-json-format.html) - Tensor formats, hex encoding, position, weighted sets, maps
- [Vespa - Tensor Reference](https://docs.vespa.ai/en/reference/ranking/tensor.html) - Cell types (int8, bfloat16, float, double), hex encoding format
- [Vespa - Geo Search](https://docs.vespa.ai/en/geo-search.html) - Position field format
- [Vespa - Tensor User Guide](https://docs.vespa.ai/en/ranking/tensor-user-guide.html) - Sparse, dense, mixed tensor concepts
- [Vespa - Constant Tensor JSON Format](https://docs.vespa.ai/en/reference/constant-tensor-json-format.html) - Tensor representation formats

**Medium Confidence (Technical Resources):**
- [Python struct Module Documentation](https://docs.python.org/3/library/struct.html) - Binary data packing
- [GitHub - xbeat/Machine-Learning - BFloat16 in Python](https://github.com/xbeat/Machine-Learning/blob/main/Exploring%20Float32,%20Float16,%20and%20BFloat16%20for%20Deep%20Learning%20in%20Python.md) - BFloat16 conversion techniques
- [NumPy array2string Documentation](https://numpy.org/doc/2.2/reference/generated/numpy.array2string.html) - Array to hex conversion patterns
- [Vespa Blog - BGE Embedding Models with BFloat16](https://blog.vespa.ai/bge-embedding-models-in-vespa-using-bfloat16/) - Real-world bfloat16 usage
- [Vespa Blog - Computing with Tensors](https://blog.vespa.ai/computing-with-tensors/) - Tensor architecture patterns

**Architecture References (v1.1):**
- Internal: `.planning/research/ARCHITECTURE.md` - Existing pipeline and registry pattern
- Internal: `src/hf_vespa_feed/converters.py` - Current converter implementation
- Internal: `src/hf_vespa_feed/pipeline.py` - Data flow and integration points
