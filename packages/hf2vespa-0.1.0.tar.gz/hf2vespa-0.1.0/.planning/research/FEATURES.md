# Features Research: v2.0 Vespa Type Support

**Domain:** CLI data conversion tool (HuggingFace datasets → Vespa JSON feed)
**Research Focus:** Vespa type converter features for v2.0 milestone
**Researched:** 2026-02-03
**Confidence:** HIGH (based on official Vespa documentation and data pipeline best practices)

## Summary

Users expect a Vespa type converter CLI tool to accurately transform HuggingFace dataset values into Vespa's JSON document format with zero data loss, clear error messages, and performance that doesn't become the bottleneck. The v2.0 milestone adds support for Vespa's specialized types (hex-encoded tensors, sparse/mixed tensors, weighted sets, maps, position), requiring table-stakes features like format correctness, overflow protection, and validation, plus differentiators like memory-efficient hex encoding and comprehensive error context.

## Table Stakes

Features users expect. Missing = product feels incomplete.

| Feature | Why Expected | Complexity | Notes |
|---------|--------------|------------|-------|
| **Hex tensor encoding for int8** | Memory-efficient binary format is standard for int8 tensors in Vespa | Medium | Vespa docs specify exact hex format: 2 hex digits per int8 cell |
| **Hex tensor encoding for bfloat16** | 50% memory savings vs float32, commonly used for embeddings | Medium | Requires IEEE 754 bfloat16 conversion (16-bit float) |
| **Hex tensor encoding for float32** | Standard 32-bit float encoding | Medium | 8 hex digits per cell (IEEE 754) |
| **Hex tensor encoding for float64** | Full-precision encoding when needed | Medium | 16 hex digits per cell (IEEE 754) |
| **Sparse tensor format (single mapped dim)** | Common pattern for categorical features, user-item matrices | Low | JSON object: `{"key1": value1, "key2": value2}` |
| **Sparse tensor format (multiple mapped dims)** | Multi-dimensional sparse data (e.g., user × product × time) | Medium | Blocks format with address + values |
| **Mixed tensor format** | Combines sparse keys with dense arrays (e.g., word embeddings) | Medium | `{"word1": [0.1, 0.2], "word2": [0.3, 0.4]}` |
| **Position (geo) type conversion** | Geo-search is table stakes for location-based search apps | Low | `{"lat": float, "lng": float}` format |
| **Weighted set support** | Common Vespa type for categorical data with scores | Low | JSON object: `{"item1": weight1, "item2": weight2}` |
| **Map type support** | Generic key-value mappings in Vespa documents | Low | JSON object (keys always strings in JSON) |
| **Overflow detection** | Prevent silent data corruption during type conversion | Medium | Detect when values exceed target type range (e.g., 128 → int8) |
| **Format validation** | Verify output matches Vespa JSON spec before output | Medium | Catch malformed tensors, invalid lat/lng, etc. |
| **Empty value handling** | Clear behavior for null, empty lists, empty objects | Low | Fail-fast or skip with warning, not silent pass-through |
| **Type mismatch errors** | Clear error when source data doesn't match converter expectation | Low | "Expected list for tensor, got string" type messages |
| **Error context in messages** | Show row number, column name, value that failed | Low | Already exists in v1.x, extend to new types |
| **Dimension inference for tensors** | Auto-detect tensor dimensions from first value | Medium | For indexed tensors: `[N]` from list length |

## Differentiators

Features that set product apart. Not expected, but valued.

| Feature | Value Proposition | Complexity | Notes |
|---------|-------------------|------------|-------|
| **Auto-detect optimal cell type** | Suggest int8 if embeddings fit range, bfloat16 for moderate precision | High | Analyze value distribution: range, precision needs |
| **Memory usage comparison** | Show "hex int8: 1MB vs float32: 4MB" for user to choose | Low | Simple calculation from tensor dimensions |
| **Compression metrics in stats** | Report "Converted 1M tensors, saved 75% memory with int8" | Low | Track bytes saved vs uncompressed float32 |
| **Dry-run validation mode** | `--validate-only` flag to check conversions without output | Low | Catches errors before long feed operations |
| **Sample-based type inference** | Inspect first N rows to recommend converters | Medium | For init command: suggest hex encoding if embeddings detected |
| **Batch conversion optimization** | Vectorized operations for array conversions (NumPy-style) | High | Significant speedup for large tensor columns |
| **Progressive validation** | Early validation during streaming (fail-fast on first error) | Low | Avoid processing 1M rows before discovering config error |
| **Converter chaining** | Compose converters: normalize → quantize → hex | High | Defer to v3.x, complex API design |
| **Round-trip correctness tests** | Verify Vespa can parse generated JSON | Medium | Use Vespa's JSON parser in test suite |
| **Per-column error thresholds** | Skip rows with errors in non-critical columns | Medium | `--max-errors-per-column 100` flag |
| **Hex encoding format choice** | Support both uppercase and lowercase hex | Low | Vespa accepts both, user preference |

## Anti-Features

Features to explicitly NOT build. Common mistakes in this domain.

| Anti-Feature | Why Avoid | What to Do Instead |
|--------------|-----------|-------------------|
| **Automatic type coercion without validation** | Silent data corruption (e.g., 300 → int8 = 44 after overflow) | Explicit overflow detection, fail with clear error |
| **Lossy conversions without warnings** | User doesn't know precision was lost (float64 → bfloat16) | Document precision implications, optional warnings |
| **In-memory batch processing** | Breaks streaming model, causes OOM on large datasets | Maintain row-by-row streaming for all converters |
| **Custom tensor formats** | Incompatible with Vespa, user must debug in production | Only output Vespa-documented JSON formats |
| **Automatic dimension reordering** | Silent behavior changes break user expectations | Document dimension ordering (alphabetical by name), error if mismatch |
| **Implicit null handling** | Unclear behavior: skip row? empty tensor? zero? | Explicit config or fail with clear error |
| **Binary output formats** | Not compatible with `vespa feed -` piping model | Keep JSONL output, use hex encoding within JSON |
| **Complex expression language for conversions** | Adds learning curve, maintenance burden | Simple type converters only, defer complex transforms to preprocessing |
| **Auto-scaling precision** | E.g., auto-choose int8 vs float32 per-row | Consistent types across all rows, defined at config time |

## Feature Dependencies

```
Hex Encoding (all cell types)
  ↓ requires
Format Validation
  ↓ requires
Overflow Detection

Sparse Tensors
  ↓ requires
Empty Value Handling

Mixed Tensors
  ↓ requires
Sparse Tensors (for mapped dimension)
  + Indexed Tensors (for dense dimension, v1.x)

Position Type
  ↓ requires
Range Validation (lat: -90 to 90, lng: -180 to 180)

Weighted Sets / Maps
  ↓ requires
Type Coercion (keys always strings in JSON)
```

## MVP Recommendation (v2.0 Scope)

For v2.0, prioritize correctness over optimization:

### Must Have (Phase 1):
1. **Hex tensor encoding** (all 4 cell types: int8, bfloat16, float32, float64)
2. **Overflow detection and validation** (prevents silent data corruption)
3. **Sparse tensor format** (single mapped dimension)
4. **Error context improvements** (extend existing error handling to new types)

### Should Have (Phase 2):
5. **Mixed tensor format** (builds on sparse + indexed from v1.x)
6. **Position type** (geo data is common use case)
7. **Weighted sets and maps** (both use same JSON object pattern)
8. **Format validation** (ensure output matches Vespa spec)

### Nice to Have (Phase 3):
9. **Dry-run validation mode** (`--validate-only` flag)
10. **Memory usage reporting** (compression stats for hex encoding)
11. **Sample-based type inference** (extend `init` command)

### Defer to v3.x:
- Batch conversion optimization (requires NumPy, breaks simplicity)
- Converter chaining (complex API design)
- Auto-detect optimal cell type (analysis complexity)
- Round-trip correctness tests (requires Vespa test environment)

## Implementation Patterns from Domain Research

### Pattern 1: Type-Safe Hex Encoding

**From:** NumPy dtype best practices and Vespa hex format spec

**Pattern:**
```python
def to_hex_int8(value: float) -> str:
    """Convert float to int8 with overflow detection."""
    if value < -128 or value > 127:
        raise ValueError(f"Value {value} out of range for int8 [-128, 127]")

    int_val = int(round(value))
    # Two hex digits, big-endian
    return f"{int_val & 0xFF:02X}"
```

**Why:** Explicit validation prevents silent overflow. Vespa expects exact hex format (2/4/8/16 digits per cell).

### Pattern 2: Progressive Validation

**From:** ETL pipeline validation best practices

**Pattern:**
```python
# Validate on first row to fail-fast
if row_num == 1:
    validate_tensor_format(value, expected_dims)

# Then convert
hex_tensor = convert_to_hex(value, cell_type)
```

**Why:** Don't process 1M rows before discovering config error. Validation on first row catches 90% of issues.

### Pattern 3: Error Isolation

**From:** Data pipeline error handling patterns

**Pattern:**
```python
try:
    converted = converter.convert(value, row_num, col_name)
except ConversionError as e:
    if error_mode == "fail":
        raise
    elif error_mode == "skip":
        log_error(e, row_num, col_name)
        return None  # Skip this row
```

**Why:** Different use cases need different error tolerance. Preview wants fail-fast, production might skip errors.

### Pattern 4: IEEE 754 Hex Encoding

**From:** Vespa document JSON format specification

**Pattern:**
```python
import struct

def to_hex_float32(value: float) -> str:
    """Convert float to IEEE 754 32-bit hex (8 hex digits)."""
    bytes_val = struct.pack('>f', value)  # Big-endian float
    return bytes_val.hex().upper()

def to_hex_bfloat16(value: float) -> str:
    """Convert float to bfloat16 hex (4 hex digits)."""
    # bfloat16 = truncate float32 to 16 bits (keep sign + exponent + 7 mantissa bits)
    float32_bytes = struct.pack('>f', value)
    bfloat16_bytes = float32_bytes[:2]  # First 2 bytes
    return bfloat16_bytes.hex().upper()
```

**Why:** Vespa expects exact IEEE 754 binary representation in hex. No ambiguity in encoding.

## Vespa Type Reference

Key details from official Vespa documentation for implementation.

### Tensor Formats

**Indexed tensor (dense):**
```json
{"tensorfield": [2.0, 3.0, 5.0, 7.0]}
```

**Sparse tensor (single mapped dim):**
```json
{"tensorfield": {"a": 2.0, "b": 3.0}}
```

**Mixed tensor (mapped + indexed):**
```json
{"tensorfield": {"x1": [2.0, 3.0], "x2": [4.0, 5.0]}}
```

**Multi-mapped sparse (blocks format):**
```json
{
  "tensorfield": {
    "blocks": [
      {"address": {"x": "x1", "y": "y2"}, "values": [2.0, 3.0]},
      {"address": {"x": "x2", "y": "y2"}, "values": [4.0, 5.0]}
    ]
  }
}
```

### Hex Encoding

**int8 hex (2 digits per cell):**
```json
{"tensorfield": {"values": "FF00118022FE"}}
```
Represents: `[-1, 0, 17, -128, 34, -2]`

**float32 hex (8 digits per cell):**
```json
{"mixedtensor": {
  "foo": "3DE38E393E638E393EAAAAAB",
  "bar": "3EE38E393F0E38E43F2AAAAB"
}}
```

### Other Types

**Position (geo):**
```json
{"mypos": {"lat": 37.4181488, "lng": -122.0256157}}
```

**Weighted set:**
```json
{"int_weighted_set": {"123": 2, "456": 78}}
```

**Map:**
```json
{"int_to_string_map": {"123": "foo", "456": "bar"}}
```

## Correctness Requirements

Based on Vespa JSON format specification:

1. **Hex encoding must be big-endian** (network byte order)
2. **int8 range: -128 to 127** (signed byte)
3. **Latitude range: -90.0 to 90.0** (degrees)
4. **Longitude range: -180.0 to 180.0** (degrees)
5. **Map keys always strings in JSON** (even for int/float key types)
6. **Weighted set values are integers** (weights, not arbitrary floats)
7. **Tensor dimension names ordered alphabetically** in blocks format
8. **Empty tensors not allowed** (must have at least one cell)

## Test Coverage Requirements

From Vespa docs examples, test suite must cover:

| Test Category | Example Cases |
|---------------|---------------|
| **Hex encoding correctness** | `[1.0, 2.0]` → verify bytes match IEEE 754 spec |
| **Overflow detection** | `128` → int8 should raise error |
| **Range validation** | `lat: 95.0` → should reject (> 90) |
| **Empty value handling** | `embedding: []` → should error with context |
| **Type mismatches** | `weighted_set` on list → should error |
| **Dimension ordering** | Multi-mapped sparse → verify alphabetical order |
| **Precision loss** | float64 → bfloat16 → verify acceptable loss |
| **Round-trip parsing** | Generate JSON, verify Vespa can parse it |

## User Experience Expectations

From CLI tool and data pipeline best practices research:

1. **Responsive feedback** - Print something within 100ms (progress bar, validation message)
2. **Exit codes** - 0 on success, non-zero on error (embeddable in shell scripts)
3. **Stderr for errors** - Keep stdout clean for piping to `vespa feed -`
4. **Actionable errors** - "Value 300 out of range for int8 [-128, 127] at row 1234, column 'embedding'"
5. **Validation before conversion** - Check config validity before processing data
6. **Statistics on completion** - "Converted 1M tensors, 750MB hex encoding, 0 errors"
7. **Progress indicators** - Only on TTY (already implemented in v1.x)
8. **Fail-fast on config errors** - Don't start processing if config is invalid

## Sources

**Vespa Official Documentation (HIGH confidence):**
- [Document JSON format reference](https://docs.vespa.ai/en/reference/schemas/document-json-format.html)
- [Tensor Guide](https://docs.vespa.ai/en/ranking/tensor-user-guide.html)
- [Constant Tensor JSON Format](https://docs.vespa.ai/en/reference/constant-tensor-json-format.html)
- [Tensor Reference](https://docs.vespa.ai/en/reference/ranking/tensor.html)

**Vespa Blog & Community (HIGH-MEDIUM confidence):**
- [Representing BGE embedding models in Vespa using bfloat16](https://blog.vespa.ai/bge-embedding-models-in-vespa-using-bfloat16/)
- [Matryoshka & Binary vectors: Slash vector search costs](https://blog.vespa.ai/combining-matryoshka-with-binary-quantization-using-embedder/)
- [Add support for int8 and bfloat16 tensor type (Issue #17118)](https://github.com/vespa-engine/vespa/issues/17118)
- [Weighted set representation differs in V8 (Issue #8251)](https://github.com/vespa-engine/vespa/issues/8251)
- [Constant tensor short form validation issue (Issue #26549)](https://github.com/vespa-engine/vespa/issues/26549)

**Data Pipeline Best Practices (MEDIUM confidence):**
- [Data Validation in ETL - 2026 Guide](https://www.integrate.io/blog/data-validation-etl/)
- [Command Line Interface Guidelines](https://clig.dev/)
- [Data Pipeline Design Patterns in Python](https://www.startdataengineering.com/post/code-patterns/)
- [Data Validation and Error Handling Best Practices](https://echobind.com/post/data-validation-error-handling-best-practices)

**NumPy & Type Conversion (HIGH confidence):**
- [NumPy Data Types Manual (v2.4)](https://numpy.org/doc/stable/user/basics.types.html)
- [Type Conversion in Programming Guide (2025)](https://www.kaashivinfotech.com/blog/type-conversion-in-programming-guide/)
