# Pitfalls Research: v2.0 Vespa Types

**Domain:** Hex tensor encoding and Vespa type converters
**Researched:** 2026-02-03
**Confidence:** MEDIUM (verified with official Vespa docs, Python struct documentation, and numpy dtype specifications)

## Summary

Implementing hex tensor encoding for Vespa requires careful attention to endianness, type width validation, and precision handling. The most critical risks are: (1) silent endianness mismatches causing wrong tensor values in production, (2) bfloat16 requiring special handling since numpy doesn't support it natively, (3) incorrect hex string length validation allowing malformed data to reach Vespa, and (4) precision loss during float64→float32→int8 conversions. These issues are preventable with explicit endianness specification, round-trip testing, and validation at encoding boundaries.

## Critical Pitfalls

### Pitfall 1: Endianness Mismatch in Binary Encoding

**What goes wrong:**
Python's `struct.pack()` defaults to native byte order (`@` format), which varies by platform. When encoding tensors to hex without explicit endianness specification, little-endian x86 machines produce different hex strings than big-endian systems (now rare but still exist in mainframes, some ARM configurations). Vespa expects consistent byte order across feeds.

**Why it happens:**
Developers use `struct.pack('f', value)` instead of `struct.pack('<f', value)`, assuming native order is portable. The format character is easy to forget since code works on developer's machine.

**Consequences:**
- Float values decode as garbage on different architectures
- Example: `struct.pack('f', 3.14)` on little-endian vs big-endian produces reversed byte order
- Silent corruption - no error, just wrong embeddings affecting search quality
- Cross-platform data corruption when hex strings generated on one platform, consumed on another

**Prevention:**
1. **Always specify endianness explicitly in struct format strings:**
   - Use `'<f'` (little-endian float), `'<d'` (little-endian double), `'>H'` (big-endian uint16)
   - Never use `'f'`, `'d'`, `'H'` without prefix
2. **Standardize on little-endian** (most common, matches x86/ARM little-endian mode)
3. **Document the choice** in code comments and type converter docstrings
4. **Add validation tests** that encode→decode on both byte orders

**Detection:**
- Round-trip tests fail: `decode(encode(value)) != value`
- Hex strings from same input differ across machines
- Search quality degrades mysteriously when deploying to different infrastructure

**Code example (prevention):**
```python
import struct

# WRONG - platform-dependent
hex_wrong = struct.pack('f', 3.14159).hex()

# RIGHT - explicitly little-endian
hex_correct = struct.pack('<f', 3.14159).hex()

# Vespa hex format expects consistent byte order
# Always use '<' prefix for little-endian
```

**Phase impact:** Phase 2 (Core Implementation) must establish endianness standard. All subsequent phases inherit this decision.

---

### Pitfall 2: bfloat16 Native Support Gap in numpy

**What goes wrong:**
Numpy doesn't natively support bfloat16 dtype. Attempting `np.dtype('bfloat16')` raises `TypeError`. Most ML models train in bfloat16, but converting to numpy for processing breaks. Developers try `.numpy()` on PyTorch bfloat16 tensors and get errors or automatic upcasting to float32, losing the memory advantage.

**Why it happens:**
Numpy maintainers explicitly decided not to add bfloat16 support. Developers assume numpy has all float types since it's foundational for scientific computing.

**Consequences:**
- Pipeline breaks when HF dataset contains bfloat16 embeddings
- Forced conversion to float32 doubles memory usage (defeats purpose of bfloat16)
- Accuracy loss if converting through float16 instead: float32→float16→bfloat16 loses precision differently than float32→bfloat16
- Performance penalty from unnecessary type conversions

**Prevention:**
1. **Use ml_dtypes library** for bfloat16 support: `pip install ml-dtypes`
2. **For PyTorch tensors, use view trick** to avoid copies:
   ```python
   import ml_dtypes
   import torch

   # Convert PyTorch bfloat16 to numpy bfloat16 without copy
   bf16_np = tensor.cpu().view(dtype=torch.uint16).numpy().view(ml_dtypes.bfloat16)
   ```
3. **Implement bfloat16 encoding using struct operations** on the 2-byte representation:
   ```python
   import struct

   def float_to_bfloat16(f):
       """Convert float32 to bfloat16 as uint16."""
       # Take upper 2 bytes of float32 (sign + exponent + 7 bits mantissa)
       return struct.unpack('>H', struct.pack('>f', f)[0:2])[0]
   ```
4. **Document ml_dtypes as required dependency** for v2.0
5. **Add type detection** in converter registry to route bfloat16 through special path

**Detection:**
- `TypeError: data type 'bfloat16' not understood`
- Converter raises exception on bfloat16 input
- Memory usage doubles unexpectedly (automatic float32 conversion)

**Phase impact:** Phase 1 (Foundation) must establish bfloat16 strategy. Phase 3 (Testing) needs bfloat16-specific round-trip tests.

---

### Pitfall 3: Incorrect Hex String Length Validation

**What goes wrong:**
Hex encoding requires exact byte counts per type: int8=2 hex digits, bfloat16=4, float32=8, float64=16. Missing or extra characters create misaligned data. Vespa may reject the feed (best case) or silently truncate/pad (worst case), causing tensor shape mismatches.

**Why it happens:**
- Off-by-one errors in length calculation: `len(values) * 2` for int8 forgets tensor has multiple dimensions
- Forgetting to pad hex strings to even length: `hex(255)` is "ff" but `hex(15)` is "f" not "0f"
- Not validating generated hex before sending to Vespa

**Consequences:**
- Vespa feed errors: "Invalid hex string for tensor"
- Tensor shape mismatch: declared `tensor<int8>(x[384])` but hex encodes 383 or 385 values
- Silent padding with zeros changes embedding values
- Debugging difficulty: error manifests downstream in Vespa, not in Python code

**Prevention:**
1. **Validate hex string length before returning:**
   ```python
   def validate_hex_length(hex_str: str, cell_type: str, expected_cells: int):
       """Validate hex string has correct length for tensor type."""
       bytes_per_cell = {'int8': 1, 'bfloat16': 2, 'float': 4, 'double': 8}
       expected_chars = expected_cells * bytes_per_cell[cell_type] * 2  # 2 hex chars per byte
       if len(hex_str) != expected_chars:
           raise ValueError(
               f"Hex string length mismatch: expected {expected_chars} chars "
               f"for {expected_cells} {cell_type} cells, got {len(hex_str)}"
           )
   ```
2. **Use zfill() for single-byte hex formatting:**
   ```python
   # int8 to 2-digit hex with leading zero if needed
   hex_str = ''.join(f'{b:02x}' for b in byte_array)
   ```
3. **Add regex validation for hex characters only:**
   ```python
   import re
   if not re.fullmatch(r'[0-9a-fA-F]+', hex_str):
       raise ValueError("Hex string contains invalid characters")
   ```
4. **Test edge cases:** single value, odd-length arrays, empty tensors

**Detection:**
- Length assertion fails in validation
- Vespa returns HTTP 400 with "malformed hex tensor"
- Round-trip decode produces different array length

**Phase impact:** Phase 2 (Core Implementation) must include validation. Phase 3 (Testing) should test all length edge cases.

---

### Pitfall 4: Precision Loss in Multi-Step Conversions

**What goes wrong:**
Converting float64→float32→int8 loses precision at each step. Quantization to int8 requires specific scaling (typically `int8 = clip(round(float32 * 127), -128, 127)`), but developers sometimes: (1) skip intermediate rounding, (2) use wrong scale factor, (3) lose precision in float64→float32 step for large values, or (4) forget that Python's `int()` truncates rather than rounds.

**Why it happens:**
- Chaining conversions without considering cumulative precision loss
- Using automatic type coercion: `int(float_value)` instead of `round(float_value)`
- Not understanding float32's 24-bit mantissa can't exactly represent all float64 values

**Consequences:**
- Embeddings differ from expected values after quantization
- Search quality degrades silently (no error raised)
- Round-trip tests pass for small values, fail for large ones
- Different results on different platforms due to rounding mode differences

**Prevention:**
1. **Minimize conversion steps:** go directly from source type to target, don't chain
2. **Use explicit rounding:**
   ```python
   # WRONG - truncates
   int8_wrong = int(float_value * 127)

   # RIGHT - rounds to nearest
   int8_correct = round(float_value * 127)

   # BEST - clip to valid range
   import numpy as np
   int8_best = np.clip(np.round(float_value * 127), -128, 127).astype(np.int8)
   ```
3. **Document expected precision loss** in docstrings
4. **Use proper quantization formula** for int8:
   - For normalized float in [-1, 1]: `int8 = round(float * 127)`
   - For float in [0, 1]: `int8 = round((float * 2 - 1) * 127)`
5. **Test with boundary values:** 0, ±1, ±0.5, values near int8 limits

**Detection:**
- Round-trip error exceeds expected quantization error
- Test with `numpy.isclose(decoded, original, atol=0.01)` for quantized types
- Compare with reference implementation (e.g., TensorFlow Lite quantization)

**Phase impact:** Phase 2 (Core Implementation) must define quantization strategy. Phase 3 (Testing) needs precision tolerance tests.

---

### Pitfall 5: Forgetting Two's Complement for Negative int8 Values

**What goes wrong:**
int8 uses two's complement representation: values 0-127 are positive, 128-255 represent -128 to -1. When encoding to hex, `struct.pack('b', value)` handles this automatically, but manual implementations often forget. When decoding, `int.from_bytes(bytes, signed=True)` is required, not `signed=False`.

**Why it happens:**
- Developers think hex represents unsigned values like HTML colors
- Copying code from uint8 examples without adjusting for signed types
- Not understanding two's complement encoding

**Consequences:**
- Negative embeddings encode as large positive values (128+ instead of -128 to -1)
- Decoding interprets negative values as 128-255 range
- Example: -1 should be 0xFF, but unsigned interpretation gives 255

**Prevention:**
1. **Always use signed format in struct:**
   ```python
   # int8 (signed)
   struct.pack('<b', -1)  # Lowercase 'b' for signed byte

   # NOT uint8 (unsigned)
   struct.pack('<B', -1)  # Would raise error or wrap incorrectly
   ```
2. **When decoding from hex:**
   ```python
   int_value = int.from_bytes(bytes.fromhex(hex_str), byteorder='little', signed=True)
   ```
3. **Test negative values explicitly:** -128, -1, -64
4. **Use numpy's int8 dtype** which handles signing automatically

**Detection:**
- Negative test values round-trip as positive
- Values > 127 appear where negative values expected
- Assertion `decoded_value < 0` fails for negative inputs

**Phase impact:** Phase 2 (Core Implementation) must handle signed correctly. Phase 3 (Testing) must include negative value tests.

---

## Moderate Pitfalls

### Pitfall 6: Caching Converter Functions Instead of Results

**What goes wrong:**
The existing codebase caches converter function lookups (`@lru_cache` on `_get_converter`) but NOT conversion results. This is correct for diverse inputs (millions of unique embeddings), but developers might add result caching thinking it improves performance. Caching results causes memory exhaustion on large datasets.

**Why it happens:**
- Misunderstanding the difference between function lookup caching vs result caching
- Following general "cache for performance" advice without considering cardinality

**Prevention:**
- Keep existing design: cache function lookups only
- Document in code comments why result caching is incorrect for this use case
- Add memory profiling to catch result caching mistakes

**Detection:**
- Memory usage grows linearly with dataset size
- OOM errors on large datasets that previously worked

**Phase impact:** Phase 2 must maintain current caching strategy, Phase 4 (Performance) should document the rationale.

---

### Pitfall 7: Missing Validation for Hex Character Set

**What goes wrong:**
Generated hex strings might contain invalid characters (G-Z, special characters) due to bugs in conversion logic. Vespa silently rejects or parser errors are cryptic.

**Prevention:**
```python
import re

def validate_hex_string(s: str) -> bool:
    """Ensure string contains only valid hex characters."""
    return bool(re.fullmatch(r'[0-9a-fA-F]+', s))
```

**Detection:**
- Vespa feed returns parse error
- Regex validation fails

**Phase impact:** Phase 2 (Core Implementation) should add validation, Phase 3 (Testing) should test malformed inputs.

---

### Pitfall 8: Incorrect Dense Tensor Cell Count Calculation

**What goes wrong:**
Multi-dimensional indexed tensors require multiplying all dimension sizes: `tensor<int8>(x[2],y[3])` has 6 cells (2×3), not 2+3. Hex string must contain exactly 12 hex chars (6 bytes × 2 chars/byte).

**Prevention:**
```python
def calculate_cell_count(dimensions: list[int]) -> int:
    """Calculate total cells in dense tensor."""
    from functools import reduce
    import operator
    return reduce(operator.mul, dimensions, 1)
```

**Detection:**
- Vespa rejects feed with shape mismatch
- Test tensors with multiple dimensions

**Phase impact:** Phase 2 (Core Implementation) for multi-dimensional tensors.

---

### Pitfall 9: Float.hex() Ambiguity with Hex Encoding

**What goes wrong:**
Python's `float.hex()` method produces a different format than Vespa's hex encoding. `float.hex()` returns strings like "0x1.921fb54442d18p+1" (hexadecimal floating-point literal), NOT the byte-level hex encoding Vespa expects.

**Why it happens:**
- Method name collision: "hex encoding" could mean `float.hex()` or binary-to-hex
- Developers searching "Python float to hex" find `float.hex()` first

**Prevention:**
- Never use `float.hex()` for Vespa encoding
- Use `struct.pack('<f', value).hex()` instead
- Document this explicitly in type converter code

**Detection:**
- Hex string contains 'x', 'p', '+' characters (invalid for Vespa)
- Length wrong: `float.hex()` produces variable length

**Phase impact:** Phase 1 (Foundation) should document correct approach.

---

### Pitfall 10: Not Handling NaN and Infinity in Float Encoding

**What goes wrong:**
IEEE 754 floats support NaN and Infinity, which encode to specific bit patterns. If dataset contains these, hex encoding succeeds but Vespa behavior is undefined (might reject, might store).

**Prevention:**
1. Detect and handle special values:
   ```python
   import math

   def validate_float(value: float) -> None:
       if math.isnan(value):
           raise ValueError("NaN not allowed in tensor")
       if math.isinf(value):
           raise ValueError("Infinity not allowed in tensor")
   ```
2. Add `--allow-special-floats` flag if use case requires them
3. Document Vespa's handling of NaN/Inf (check official docs)

**Detection:**
- Round-trip tests with NaN/Inf
- Feed validation errors from Vespa

**Phase impact:** Phase 2 (Core Implementation) should decide on policy, Phase 3 (Testing) should test edge cases.

---

## Type-Specific Gotchas

### int8 Gotchas

1. **Range is -128 to 127, not 0 to 255:** Remember it's signed
2. **Struct format is 'b' (signed) not 'B' (unsigned)**
3. **Each value is exactly 2 hex chars:** Use `f'{val:02x}'` with proper signing
4. **Quantization requires clipping:** Don't let values exceed [-128, 127]

### bfloat16 Gotchas

1. **No native numpy support:** Requires ml_dtypes or manual struct operations
2. **Not the same as float16:** Different bit layout (8-bit exponent vs 5-bit)
3. **Truncation, not rounding:** Takes upper 16 bits of float32 (sign + exponent + 7 mantissa bits)
4. **Limited precision:** Only ~3 decimal digits (vs 7 for float32)
5. **Each value is exactly 4 hex chars** (2 bytes)
6. **Requires big-endian struct.pack for correctness:**
   ```python
   # Get upper 2 bytes of float32
   bf16_bytes = struct.pack('>f', float_val)[0:2]
   hex_str = bf16_bytes.hex()
   ```

### float32 Gotchas

1. **8 hex chars per value** (4 bytes)
2. **Precision is ~7 decimal digits:** Rounding errors accumulate
3. **Struct format is '<f' (little-endian float)**
4. **Not all float64 values representable:** Loses precision on conversion
5. **Denormalized numbers exist:** Very small values near zero have reduced precision

### float64 Gotchas

1. **16 hex chars per value** (8 bytes)
2. **Doubles memory and bandwidth:** Often unnecessary for embeddings
3. **Struct format is '<d' (little-endian double)**
4. **Python float is float64:** No conversion needed from Python float
5. **Still can't represent all decimals exactly:** 0.1 still has rounding error

---

## Testing Recommendations

### 1. Round-Trip Testing Protocol

For every type converter, implement round-trip tests:

```python
def test_roundtrip(original_value, cell_type):
    """Verify encode→decode returns original (within precision tolerance)."""
    # Encode to hex
    hex_str = encode_tensor(original_value, cell_type)

    # Validate hex format
    assert validate_hex_string(hex_str)
    assert len(hex_str) == expected_length(cell_type, len(original_value))

    # Decode back
    decoded_value = decode_tensor(hex_str, cell_type)

    # Compare with appropriate tolerance
    if cell_type == 'int8':
        assert decoded_value == original_value  # Exact
    elif cell_type in ('float', 'double'):
        assert numpy.allclose(decoded_value, original_value, rtol=1e-6)
    elif cell_type == 'bfloat16':
        # bfloat16 has ~3 decimal digits precision
        assert numpy.allclose(decoded_value, original_value, rtol=1e-2)
```

### 2. Boundary Value Testing

Test edge cases for each type:

| Type | Edge Cases to Test |
|------|-------------------|
| int8 | -128, -1, 0, 1, 127 |
| bfloat16 | 0, ±1, ±0.001, max/min normal values |
| float32 | 0, ±1, ±1e-38 (min), ±3e38 (max), 0.1 (rounding) |
| float64 | 0, ±1, ±2e-308 (min), ±1e308 (max) |
| All floats | NaN, Infinity, -Infinity (if allowed) |

### 3. Endianness Verification

Force different byte orders and verify consistency:

```python
def test_endianness_explicit():
    """Verify little-endian encoding is consistent."""
    value = 3.14159
    hex_le = struct.pack('<f', value).hex()

    # Should always get same result regardless of platform
    assert hex_le == "d00f4940"  # Known little-endian encoding of 3.14159

    # Verify big-endian is different
    hex_be = struct.pack('>f', value).hex()
    assert hex_be != hex_le
```

### 4. Length Validation Tests

```python
def test_hex_length_validation():
    """Verify hex strings have correct length for type."""
    test_cases = [
        (10, 'int8', 20),      # 10 values × 2 chars/value
        (384, 'bfloat16', 1536),  # 384 values × 4 chars/value
        (128, 'float', 1024),   # 128 values × 8 chars/value
        (64, 'double', 1024),   # 64 values × 16 chars/value
    ]
    for num_values, cell_type, expected_chars in test_cases:
        values = [0.0] * num_values
        hex_str = encode_tensor(values, cell_type)
        assert len(hex_str) == expected_chars
```

### 5. Vespa Integration Tests

Use Vespa's official documentation examples as test vectors:

```python
def test_vespa_example_int8():
    """Test against Vespa docs example."""
    # From: https://docs.vespa.ai/en/reference/schemas/document-json-format.html
    # tensor<int8>(x[2],y[3]): "0B22038405FF"
    hex_input = "0B22038405FF"
    expected = [[11, 34, 3], [-124, 5, -1]]

    decoded = decode_int8_tensor(hex_input, shape=[2, 3])
    assert decoded == expected
```

### 6. Memory and Performance Tests

```python
def test_no_result_caching_memory_growth():
    """Verify converter doesn't cache results (memory leak)."""
    import tracemalloc

    tracemalloc.start()
    initial_memory = tracemalloc.get_traced_memory()[0]

    # Convert 10k unique embeddings
    for i in range(10000):
        unique_value = [float(i + j) for j in range(384)]
        _ = converters.convert(unique_value, "tensor")

    final_memory = tracemalloc.get_traced_memory()[0]
    tracemalloc.stop()

    # Memory growth should be minimal (< 1MB)
    # If caching results, would grow by ~15MB (10k × 384 × 4 bytes)
    assert (final_memory - initial_memory) < 1_000_000
```

### 7. Cross-Platform Consistency Tests

Run identical tests on different platforms and compare outputs:

```python
def test_platform_consistency():
    """Generate hex strings and compare across platforms."""
    test_values = [1.0, -1.0, 0.0, 3.14159, 2.71828]

    for value in test_values:
        hex_str = encode_float32([value])
        # Log hex string and platform info
        print(f"Platform: {sys.platform}, Value: {value}, Hex: {hex_str}")

    # Compare logs from different CI runners (Linux, macOS, Windows)
```

### 8. Fuzz Testing for Robustness

Generate random inputs and verify no crashes:

```python
import hypothesis
from hypothesis import strategies as st

@hypothesis.given(st.lists(st.floats(allow_nan=False, allow_infinity=False), min_size=1, max_size=1000))
def test_float32_encoding_never_crashes(values):
    """Fuzz test: any valid float list should encode without error."""
    try:
        hex_str = encode_tensor(values, 'float')
        assert isinstance(hex_str, str)
        assert validate_hex_string(hex_str)
    except ValueError as e:
        # Only acceptable errors are validation failures
        assert "precision" in str(e).lower() or "range" in str(e).lower()
```

---

## Phase-Specific Warnings

| Phase | Likely Pitfalls | Mitigation |
|-------|----------------|------------|
| Phase 1: Foundation & Research | Misunderstanding Vespa hex format, choosing wrong endianness standard | Read Vespa docs thoroughly, document endianness decision, prototype int8 first |
| Phase 2: Core Implementation | Endianness mismatch, bfloat16 numpy gap, incorrect length validation | Use explicit '<' prefix in all struct.pack calls, add ml_dtypes dependency, implement length validation |
| Phase 3: Testing & Validation | Insufficient edge case coverage, missing round-trip tests, not testing negative int8 | Follow testing recommendations above, test all boundary values, compare against Vespa doc examples |
| Phase 4: Integration & Performance | Accidentally caching results (memory leak), not benchmarking hex vs JSON | Profile memory usage, benchmark throughput, document performance characteristics |
| Phase 5: Documentation & Examples | Not explaining endianness choice, missing bfloat16 setup instructions | Document endianness standard, add ml_dtypes to installation guide, provide type conversion examples |

---

## Research Confidence Assessment

| Topic | Confidence | Source Quality | Notes |
|-------|------------|---------------|-------|
| Vespa hex format spec | HIGH | Official Vespa docs via WebFetch | int8 documented, extrapolated to other types |
| Endianness issues | HIGH | Python struct docs, official numpy docs | Well-documented, standard behavior |
| bfloat16 handling | HIGH | Multiple sources (PyTorch, ml_dtypes, manual implementations) | Consistent across sources |
| struct.pack pitfalls | HIGH | Official Python documentation | Authoritative source |
| int8 quantization | MEDIUM | TensorFlow/TensorRT docs, multiple ML frameworks | Standard approaches but Vespa-specific behavior unverified |
| Validation strategies | MEDIUM | General testing best practices, WebSearch results | Principles apply but Vespa-specific validation unverified |

---

## Sources

### Official Documentation
- [Vespa Tensor Reference](https://docs.vespa.ai/en/reference/ranking/tensor.html) - Hex encoding specification
- [Vespa Document JSON Format](https://docs.vespa.ai/en/reference/schemas/document-json-format.html) - Tensor feeding format
- [Python struct module](https://docs.python.org/3/library/struct.html) - Binary data packing
- [NumPy dtype byte order](https://numpy.org/doc/stable/reference/generated/numpy.dtype.byteorder.html) - Endianness handling
- [NumPy data types](https://numpy.org/doc/stable/user/basics.types.html) - Type precision and conversion

### Library-Specific Resources
- [ml_dtypes package](https://pypi.org/project/ml-dtypes/) - bfloat16 support for NumPy
- [bfloat16 Wikipedia](https://en.wikipedia.org/wiki/Bfloat16_floating-point_format) - Format specification

### Blog Posts and Technical Articles
- [Vespa Blog: BGE with bfloat16](https://blog.vespa.ai/bge-embedding-models-in-vespa-using-bfloat16/) - bfloat16 usage patterns
- [xbeat/Machine-Learning: bfloat16 guide](https://github.com/xbeat/Machine-Learning/blob/main/Exploring%20Float32,%20Float16,%20and%20BFloat16%20for%20Deep%20Learning%20in%20Python.md) - Conversion implementations

### Testing and Validation
- [TensorFlow correctness validation](https://www.tensorflow.org/guide/migrate/validate_correctness) - Testing strategies
- [NVIDIA TensorRT INT8 quantization](https://developer.nvidia.com/blog/achieving-fp32-accuracy-for-int8-inference-using-quantization-aware-training-with-tensorrt/) - Quantization best practices
- [LiteRT quantization spec](https://www.tensorflow.org/lite/performance/quantization_spec) - int8 encoding specification

### Community Resources and Issues
- [NumPy bfloat16 support issue](https://github.com/numpy/numpy/issues/19808) - Why numpy lacks bfloat16
- [PyTorch bfloat16 .numpy() issue](https://github.com/pytorch/pytorch/issues/90574) - Conversion challenges
- [TensorFlow endianness issue](https://github.com/tensorflow/tensorflow/issues/16364) - Cross-platform serialization
- [NumPy precision loss issues](https://github.com/numpy/numpy/issues/25836) - float32 conversion behavior

### Testing Best Practices
- [Round-trip format conversion - Wikipedia](https://en.wikipedia.org/wiki/Round-trip_format_conversion) - Testing methodology
- [Microsoft: Round Trip Testing](https://learn.microsoft.com/en-us/archive/blogs/dustin_andrews/add-round-trip-testing-to-your-toolset) - Implementation patterns
- [xUnit: Round trip test pattern](http://xunitpatterns.com/round%20trip%20test.html) - Testing pattern

---

## Open Questions for Roadmap Planning

1. **Vespa's endianness requirement:** Documentation implies little-endian but doesn't state explicitly. Should we verify with Vespa maintainers or assume little-endian based on x86 dominance?

2. **NaN/Infinity policy:** Should these be rejected, allowed, or configurable? Need to test Vespa's actual behavior.

3. **Quantization formula standardization:** Should v2.0 define a standard int8 quantization approach (symmetric, asymmetric, per-tensor, per-channel)?

4. **bfloat16 performance vs correctness:** Using ml_dtypes adds dependency. Alternative is pure Python struct operations (faster, no dependency). Trade-off?

5. **Validation strictness:** Should validation be opt-in (--strict flag) or always-on? Some users may want maximum speed over safety.

6. **Test coverage threshold:** What percentage of edge cases warrant explicit tests vs fuzz testing? Balance test suite runtime vs confidence.

These questions suggest Phase 1 (Foundation) should include a small prototyping spike to verify Vespa's actual behavior with different endianness, NaN handling, and validation responses.
