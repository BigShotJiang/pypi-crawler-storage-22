# Stack Research: v2.0 Vespa Types

**Project:** hf-vespa-feed
**Research Date:** 2026-02-03
**Milestone:** v2.0 Vespa Type Support
**Focus:** Stack additions for hex tensor encoding and additional Vespa type support

---

## Summary

To support hex tensor encoding for all Vespa cell types (int8, bfloat16, float32, float64) and additional Vespa types (sparse/mixed tensors, position, weighted sets, maps), the project needs **minimal stack additions**: Python's built-in `struct` module for hex encoding and `ml-dtypes` for bfloat16 support. The existing `orjson` serialization pipeline remains unchanged. This approach maintains the project's "minimize dependencies" constraint while enabling complete Vespa type coverage.

## Current Stack (v1.1)

| Library | Version | Purpose |
|---------|---------|---------|
| typer | >=0.21.0 | CLI framework |
| datasets | >=4.5.0 | HuggingFace dataset streaming |
| orjson | >=3.11.0 | Fast JSON serialization |
| pyyaml | >=6.0.0 | YAML parsing |
| pydantic | >=2.12.0 | Config validation |
| tqdm | >=4.66.0 | Progress bars |
| ruamel.yaml | >=0.19.0 | YAML generation with comments |

**Note:** The `datasets` library includes NumPy as a transitive dependency (Arrow backend uses NumPy arrays).

---

## Recommended Additions

### 1. ml-dtypes (bfloat16 support) ✅

| Property | Value |
|----------|-------|
| **Package** | ml-dtypes |
| **Version** | >=0.5.4 |
| **Purpose** | bfloat16 dtype for NumPy |
| **Why needed** | Python has no native bfloat16 type; ml-dtypes provides NumPy-compatible bfloat16 |
| **Installation** | `pip install ml-dtypes` |
| **License** | Apache 2.0 (source), MPL 2.0 (wheels with EIGEN) |
| **Python support** | 3.9-3.14 (tested 3.9-3.12, wheels for 3.13-3.14) |
| **Release date** | 0.5.4 released November 17, 2025 |

**Rationale:**
- Official JAX/Google project, actively maintained
- Integrates seamlessly with NumPy (registers dtype automatically on import)
- Pre-compiled wheels for all platforms (no build dependencies)
- Handles bfloat16 arithmetic and conversion correctly
- Used by JAX, TensorFlow, PyTorch ecosystem
- Lightweight (no ML framework overhead)

**Usage example:**
```python
from ml_dtypes import bfloat16
import numpy as np

# Create bfloat16 array
arr = np.array([1.5, 2.5, 3.5], dtype=bfloat16)

# Convert to hex for Vespa
for val in arr:
    packed = struct.pack('>H', val.view(np.uint16))
    print(packed.hex())  # 4-char hex string per value
```

**Alternatives considered:**
- `bfloat16` package (GitHub: GreenWaves-Technologies/bfloat16): Less maintained, requires compilation, no wheels
- Manual bit manipulation: Error-prone, no type safety
- TensorFlow/PyTorch: 500MB+ dependencies for simple dtype conversion

**Confidence:** 🟢 High (95%)

**Sources:**
- [ml-dtypes PyPI](https://pypi.org/project/ml-dtypes/) - Official package page, v0.5.4, installation and usage
- [ml-dtypes GitHub](https://github.com/jax-ml/ml_dtypes) - Source code and documentation

---

### 2. struct (standard library) ✅

| Property | Value |
|----------|-------|
| **Module** | struct |
| **Version** | Built-in (Python 3.10+) |
| **Purpose** | Binary packing/unpacking for hex encoding |
| **Why needed** | Convert numeric types to bytes for hex string representation |

**Format codes:**
- `'b'`: signed int8 (1 byte)
- `'B'`: unsigned int8 (1 byte)
- `'f'`: float32 (4 bytes, IEEE 754 binary32)
- `'d'`: float64 (8 bytes, IEEE 754 binary64)
- `'H'`: unsigned short (2 bytes, for bfloat16 as uint16)

**Byte order:** Use `'>'` (big-endian/network order) for consistent cross-platform hex output.

**Usage example:**
```python
import struct

# int8 → 2 hex chars
packed = struct.pack('>b', -124)
print(packed.hex())  # "84"

# float32 → 8 hex chars
packed = struct.pack('>f', 3.14)
print(packed.hex())  # "4048f5c3"

# float64 → 16 hex chars
packed = struct.pack('>d', 3.14159265359)
print(packed.hex())  # "400921fb54442d18"
```

**Confidence:** 🟢 High (100%)

**Sources:**
- [Python struct documentation](https://docs.python.org/3/library/struct.html) - Format codes and byte order specifications

---

## Hex Encoding Approach

Vespa accepts hex-encoded tensor values for compact representation. Each cell type requires specific encoding:

### int8 (1 byte → 2 hex chars)

```python
import struct

def int8_to_hex(value: int) -> str:
    """Convert int8 (-128 to 127) to 2-character hex string."""
    packed = struct.pack('>b', value)  # Big-endian signed byte
    return packed.hex()
```

**Example:** `tensor<int8>(x[3])` with values `[11, -124, -1]` → Hex: `"0B84FF"`

**Rationale:** Direct struct packing. Big-endian ensures consistent output. 1 byte per value = 2 hex chars.

**Vespa docs verification:** From [Tensor Reference](https://docs.vespa.ai/en/reference/ranking/tensor.html): "For a tensor typed as `tensor<int8>(x[2],y[3])`, the hexadecimal input `0B22038405FF` converts to `[[11, 34, 3], [-124, 5, -1]]`."

---

### bfloat16 (2 bytes → 4 hex chars)

```python
import struct
import numpy as np
from ml_dtypes import bfloat16

def bfloat16_to_hex(value: float) -> str:
    """Convert float to bfloat16, then to 4-character hex string."""
    # Method 1: ml-dtypes (when input is already bfloat16)
    bf16 = np.float32(value).astype(bfloat16)
    packed = struct.pack('>H', bf16.view(np.uint16))
    return packed.hex()

# Alternative: direct truncation (faster, no ml-dtypes dependency)
def float32_to_bfloat16_hex(value: float) -> str:
    """Convert float32 to bfloat16 by truncating lower 16 bits."""
    packed_f32 = struct.pack('>f', value)  # 4 bytes float32
    return packed_f32[:2].hex()  # First 2 bytes are bfloat16
```

**Example:** `tensor<bfloat16>(x[3])` with values `[1.5, 2.5, 3.5]` → Hex: `"3FC04020402C"` (4 hex chars per value)

**Rationale:** bfloat16 is the upper 16 bits of float32 (sign + 8-bit exponent + 7-bit mantissa). Two approaches:
1. **ml-dtypes method:** Proper type conversion with NumPy ecosystem compatibility. Use when users have bfloat16 embeddings from models.
2. **Truncation method:** Faster, no extra dependency, mathematically equivalent. Use for converting float32 to bfloat16.

**Recommendation:** Implement both, auto-detect input type. If input is `np.ndarray` with `bfloat16` dtype, use ml-dtypes path. Otherwise, use truncation.

**Vespa docs verification:** From [Brain floating-point format - WikiChip](https://en.wikichip.org/wiki/brain_floating-point_format): "bfloat16 is a 16-bit format using the upper 16 bits of IEEE 754 single-precision (float32)."

---

### float32 (4 bytes → 8 hex chars)

```python
import struct

def float32_to_hex(value: float) -> str:
    """Convert float to float32, then to 8-character hex string."""
    packed = struct.pack('>f', value)  # Big-endian float32
    return packed.hex()
```

**Example:** `tensor<float>(x[3])` with values `[1.5, 2.5, 3.5]` → Hex: `"3FC000004020000040600000"`

**Rationale:** Standard IEEE 754 binary32. 4 bytes per value = 8 hex chars.

---

### float64 (8 bytes → 16 hex chars)

```python
import struct

def float64_to_hex(value: float) -> str:
    """Convert float to float64, then to 16-character hex string."""
    packed = struct.pack('>d', value)  # Big-endian float64
    return packed.hex()
```

**Example:** `tensor<double>(x[2])` with values `[1.5, 2.5]` → Hex: `"3FF80000000000004004000000000000"`

**Rationale:** Standard IEEE 754 binary64. 8 bytes per value = 16 hex chars. Python's native float is float64, so no precision loss.

---

### Consolidated Hex Tensor Converter

```python
from typing import List, Union
import struct

def tensor_to_hex(values: List[Union[int, float]], cell_type: str) -> str:
    """
    Convert list of numeric values to hex-encoded string for Vespa.

    Args:
        values: List of numeric values
        cell_type: One of "int8", "bfloat16", "float", "double"

    Returns:
        Hex-encoded string (uppercase)

    Example:
        >>> tensor_to_hex([11, 34, 3], "int8")
        "0B2203"
        >>> tensor_to_hex([1.5, 2.5], "bfloat16")
        "3FC04020"
    """
    encoders = {
        'int8': lambda v: struct.pack('>b', v),
        'bfloat16': lambda v: struct.pack('>f', v)[:2],  # Truncate to upper 16 bits
        'float': lambda v: struct.pack('>f', v),
        'double': lambda v: struct.pack('>d', v),
    }

    if cell_type not in encoders:
        raise ValueError(f"Unknown cell type: {cell_type}")

    encoder = encoders[cell_type]
    hex_bytes = b''.join(encoder(v) for v in values)
    return hex_bytes.hex().upper()
```

**Integration point:** Add to `converters.py` as new converter types:
```python
converters.register("tensor_int8_hex", tensor_to_hex_int8)
converters.register("tensor_bfloat16_hex", tensor_to_hex_bfloat16)
converters.register("tensor_float_hex", tensor_to_hex_float)
converters.register("tensor_double_hex", tensor_to_hex_double)
```

---

## Sparse and Mixed Tensor Formats

**No new dependencies required.** These are JSON structure changes, handled by existing `orjson` serialization.

### Sparse Tensor (mapped dimensions only)

```python
def list_to_sparse_tensor(value: dict) -> dict:
    """
    Convert dict to Vespa sparse tensor format.

    Args:
        value: Dict mapping labels to cell values

    Returns:
        Sparse tensor in Vespa "cells" format

    Example:
        >>> list_to_sparse_tensor({"tag": 2.5, "another": 2.75})
        {"cells": {"tag": 2.5, "another": 2.75}}
    """
    return {"cells": value}
```

**Vespa docs verification:** From [Tensor Guide](https://docs.vespa.ai/en/ranking/tensor-user-guide.html): "For tensors with only one mapped dimension, a simple JSON object can be used as input: `{ 'type': 'tensor(category{})', 'cells': { 'tag': 2.5, 'another': 2.75 } }`"

---

### Mixed Tensor (mapped + indexed dimensions)

```python
def list_to_mixed_tensor(value: dict) -> dict:
    """
    Convert dict to Vespa mixed tensor format.

    Args:
        value: Dict mapping labels to blocks (lists of values)

    Returns:
        Mixed tensor in Vespa "blocks" format

    Example:
        >>> list_to_mixed_tensor({"foo": [1.0, 2.0, 3.0], "bar": [4.0, 5.0, 6.0]})
        {"blocks": {"foo": [1.0, 2.0, 3.0], "bar": [4.0, 5.0, 6.0]}}
    """
    return {"blocks": value}
```

**Vespa docs verification:** From [Tensor Guide](https://docs.vespa.ai/en/ranking/tensor-user-guide.html): "Tensors with both mapped and indexed dimensions can use a 'blocks' format; this is similar to the 'cells' formats for sparse tensors, but instead of a single cell value you get a block of values for each address."

**Integration:** Add to converter registry, let `orjson` handle serialization.

---

## Position (Geo) Type

**No new dependencies required.** Position is a JSON object with `lat` and `lng` fields.

```python
def tuple_to_position(value: tuple[float, float]) -> dict:
    """
    Convert (latitude, longitude) tuple to Vespa position format.

    Args:
        value: (lat, lng) tuple where lat is -90.0 to 90.0, lng is -180.0 to 180.0

    Returns:
        Position object with "lat" and "lng" fields

    Example:
        >>> tuple_to_position((37.4181488, -122.0256157))
        {"lat": 37.4181488, "lng": -122.0256157}
    """
    lat, lng = value
    if not (-90.0 <= lat <= 90.0):
        raise ValueError(f"Latitude must be between -90.0 and 90.0, got {lat}")
    if not (-180.0 <= lng <= 180.0):
        raise ValueError(f"Longitude must be between -180.0 and 180.0, got {lng}")
    return {"lat": lat, "lng": lng}
```

**Format:** Matches Google Places API format for broad compatibility.

**Vespa docs verification:** From [Geo Search](https://docs.vespa.ai/en/geo-search.html): "Positions are rendered with two JSON fields 'lat' and 'lng', both having a floating-point value. The 'lat' field is latitude (going from -90.0 at the South Pole to +90.0 at the North Pole). The 'lng' field is longitude (going from -180.0 at the dateline seen as extreme west, via 0.0 at the Greenwich meridian, to +180.0 at the dateline again, now as extreme east)."

---

## Weighted Sets and Maps

**No new dependencies required.** Both are simple JSON objects.

### Weighted Set

```python
def dict_to_weightedset(value: dict) -> dict:
    """
    Convert dict to Vespa weightedset format.

    Args:
        value: Dict mapping keys to integer weights

    Returns:
        Same dict (identity transform, Vespa accepts direct JSON object)

    Example:
        >>> dict_to_weightedset({"one": 1, "two": 2, "three": 3})
        {"one": 1, "two": 2, "three": 3}
    """
    return value  # Identity transform, Vespa accepts {"key": weight} directly
```

**Vespa docs verification:** From [Document JSON format reference](https://docs.vespa.ai/en/reference/schemas/document-json-format.html): "For weightedset types, the JSON input representation for feeding is a JSON object, for example `{'one':1, 'two':2,'three':3}` for a weightedset<string> field."

---

### Map

```python
def dict_to_map(value: dict) -> dict:
    """
    Convert dict to Vespa map format.

    Args:
        value: Dict mapping keys to values (any JSON-serializable type)

    Returns:
        Same dict (identity transform, Vespa accepts direct JSON object)

    Example:
        >>> dict_to_map({"1001": 1.0, "1002": 2.0, "1003": 3.0})
        {"1001": 1.0, "1002": 2.0, "1003": 3.0}
    """
    return value  # Identity transform, Vespa accepts {"key": value} directly
```

**Vespa docs verification:** From [Document JSON format reference](https://docs.vespa.ai/en/reference/schemas/document-json-format.html): "For map types, the JSON input representation for feeding is a JSON object; for example `{'1001':1.0, '1002':2.0, '1003':3.0}` for a map<int,float> field."

**Note:** For weightedset and map, the converter is essentially a pass-through with validation. The main work is in user documentation about expected input formats.

---

## Integration Notes

### 1. orjson Compatibility

All new converters return Python dicts/lists/strings that `orjson` serializes natively. **No changes needed to serialization pipeline.**

- Hex strings: Python `str`, orjson serializes as JSON string
- Sparse/mixed tensors: Python `dict` with `"cells"`/`"blocks"` keys
- Position: Python `dict` with `"lat"`/`"lng"` keys
- Weighted sets/maps: Python `dict`, orjson serializes as JSON object

### 2. Converter Registry Extension

Current `converters.py` uses `lru_cache` on `_get_converter()`. This pattern continues to work:

```python
# In converters.py
converters.register("tensor_int8_hex", tensor_to_hex_int8)
converters.register("tensor_bfloat16_hex", tensor_to_hex_bfloat16)
converters.register("tensor_float_hex", tensor_to_hex_float)
converters.register("tensor_double_hex", tensor_to_hex_double)
converters.register("sparse_tensor", list_to_sparse_tensor)
converters.register("mixed_tensor", list_to_mixed_tensor)
converters.register("position", tuple_to_position)
converters.register("weightedset", dict_to_weightedset)
converters.register("map", dict_to_map)
```

Cache hit rate should remain high since converter lookups are by type name.

### 3. Performance Considerations

**Hex encoding overhead:**
- `struct.pack()` is C-level fast (< 1µs per value)
- `bytes.hex()` is also C-level (< 0.5µs per byte)
- For 1536-dim float32 tensor: ~6KB bytes → 12KB hex string = ~2ms total

**ml-dtypes overhead:**
- bfloat16 conversion via truncation: ~0.1µs per value (no ml-dtypes needed)
- bfloat16 via ml-dtypes: ~1µs per value (NumPy array conversion)
- Recommendation: Use truncation method for better throughput

**Streaming compatibility:**
All converters process one value at a time, maintaining the streaming architecture. No batch loading required.

### 4. Error Handling

Existing error handling in `converters.py` continues to work:

```python
# Current pattern in ConverterRegistry.convert()
try:
    converter_fn = self._get_converter(type_name)
    return converter_fn(value)
except ValueError as e:
    # Propagate converter-specific errors (e.g., invalid lat/lng)
    raise
```

New converters raise `ValueError` for invalid inputs (out-of-range lat/lng, non-numeric tensor values, etc.), consistent with existing `list_to_tensor()`.

---

## Do Not Add

### NumPy (direct dependency)

**Why not:** Already available as transitive dependency via `datasets` (Arrow backend). Adding as direct dependency would duplicate and potentially version-conflict.

**Evidence:** HuggingFace `datasets>=4.5.0` includes NumPy support. The library uses Arrow tables backed by NumPy arrays. From [datasets PyPI](https://pypi.org/project/datasets/) (2026-01-14): "The library has built-in interoperability with NumPy, PyTorch, TensorFlow 2, JAX, Pandas, Polars and more."

**When to use:** Import as `import numpy as np` in converter functions. It's available in the environment.

**Confidence:** 🟡 Medium (should verify in tests that NumPy is available)

---

### TensorFlow/PyTorch

**Why not:** Massive dependencies (500MB+ each) for simple dtype conversions. The `ml-dtypes` library provides bfloat16 without ML framework overhead.

**Alternative:** `ml-dtypes` is extracted from JAX specifically to avoid framework dependencies.

**Confidence:** 🟢 High (100%)

---

### bitstring, bitarray

**Why not:** Python's built-in `struct` module handles all binary packing needs. These libraries add no value for tensor encoding.

**Confidence:** 🟢 High (100%)

---

### Alternative bfloat16 libraries

| Library | Why Not |
|---------|---------|
| `bfloat16` (GreenWaves-Technologies) | Requires compilation, no pre-built wheels, less maintained |
| TensorFlow's bfloat16 | Requires entire TensorFlow stack (500MB+) |
| PyTorch's bfloat16 | Requires entire PyTorch stack (700MB+) |
| Manual bit manipulation | Error-prone, no type safety, harder to test |

**Confidence:** 🟢 High (95%)

---

### JSON libraries (besides orjson)

**Why not:** `orjson` already handles all Vespa JSON format needs:
- Sparse tensors: `{"cells": {...}}`
- Mixed tensors: `{"blocks": {...}}`
- Position: `{"lat": ..., "lng": ...}`
- Weighted sets/maps: `{...}` direct objects

No special JSON features needed. Standard serialization works.

**Confidence:** 🟢 High (100%)

---

## Installation

### Updated pyproject.toml dependencies section

```toml
[project]
dependencies = [
    "typer>=0.21.0",
    "datasets>=4.5.0",
    "orjson>=3.11.0",
    "pyyaml>=6.0.0",
    "pydantic>=2.12.0",
    "tqdm>=4.66.0",
    "ruamel.yaml>=0.19.0",
    "ml-dtypes>=0.5.4",  # NEW: bfloat16 support
]
```

### Installation command

```bash
pip install ml-dtypes>=0.5.4
```

### Development installation

```bash
pip install -e ".[dev]"
```

---

## Testing Requirements

For correctness validation, need to verify:

1. **Hex encoding correctness:**
   - int8: Test positive/negative/zero values
   - bfloat16: Test against known conversions from Vespa examples
   - float32/float64: Test against IEEE 754 reference values

2. **Vespa format compliance:**
   - Sparse tensors: Compare with Vespa docs examples
   - Mixed tensors: Multi-dimensional block format
   - Position: Valid lat/lng ranges

3. **Cross-platform consistency:**
   - Big-endian byte order ensures same hex output on all platforms
   - Test on Linux (CI) and macOS/Windows (local dev)

**Testing tools needed:** pytest (already in dev dependencies).

---

## Version Rationale

| Library | Version | Why This Version |
|---------|---------|------------------|
| ml-dtypes | >=0.5.4 | Latest stable (2025-11-17), includes Python 3.13/3.14 support |
| struct | Built-in | No version constraint, stable API since Python 2 |

**Version pinning strategy:** Use `>=` for ml-dtypes to allow patch updates. The bfloat16 dtype API is stable.

---

## Confidence Assessment

| Area | Confidence | Rationale |
|------|-----------|-----------|
| Hex encoding approach | 🟢 High (98%) | Verified with Vespa official docs. `struct` module is standard. |
| ml-dtypes for bfloat16 | 🟢 High (95%) | Verified on PyPI (v0.5.4, 2025-11-17). Official JAX/Google project. |
| Sparse/mixed tensor formats | 🟢 High (98%) | Verified with Vespa docs examples. Standard JSON serialization. |
| Position format | 🟢 High (98%) | Verified with Vespa geo-search docs. Matches Google Places API. |
| Weighted sets/maps | 🟢 High (98%) | Verified with Vespa docs. Simple JSON object format. |
| NumPy availability | 🟡 Medium (70%) | Inferred from `datasets` dependency. Should verify in tests. |
| Performance estimates | 🟡 Medium (60%) | Based on typical `struct`/hex performance, not benchmarked. |

**Overall Confidence:** 🟢 High (92%)

---

## Sources

### Vespa Documentation (Official)

- [Tensor Reference](https://docs.vespa.ai/en/reference/ranking/tensor.html) - Cell types and hex encoding format
- [Document JSON format reference](https://docs.vespa.ai/en/reference/schemas/document-json-format.html) - Feed format specifications
- [Tensor Guide](https://docs.vespa.ai/en/ranking/tensor-user-guide.html) - Sparse and mixed tensor examples
- [Geo Search](https://docs.vespa.ai/en/geo-search.html) - Position field format with lat/lng

### Vespa Blog Posts

- [Representing BGE embedding models in Vespa using bfloat16](https://blog.vespa.ai/bge-embedding-models-in-vespa-using-bfloat16/) - bfloat16 benefits and memory savings
- [GitHub Issue #17118: Add support for int8 and bfloat16 tensor type](https://github.com/vespa-engine/vespa/issues/17118) - Feature introduction and format details

### Python Libraries

- [ml-dtypes PyPI](https://pypi.org/project/ml-dtypes/) - Official package page, v0.5.4 (2025-11-17), installation and usage
- [ml-dtypes GitHub](https://github.com/jax-ml/ml_dtypes) - Source code and documentation
- [Python struct documentation](https://docs.python.org/3/library/struct.html) - Format codes and byte order specifications
- [HuggingFace datasets PyPI](https://pypi.org/project/datasets/) - Dependency and NumPy interoperability

### Technical References

- [Brain floating-point format (bfloat16) - WikiChip](https://en.wikichip.org/wiki/brain_floating-point_format) - bfloat16 specification and truncation explanation

---

## Next Steps for v2.0 Implementation

1. Add `ml-dtypes>=0.5.4` to `pyproject.toml`
2. Create hex encoding converters in `converters.py`
3. Register new converter types (9 new converters total)
4. Add unit tests with Vespa docs examples as test cases
5. Document new converter types in README with examples
6. Benchmark hex encoding performance (target: >10k tensors/sec)
7. Verify cross-platform consistency (Linux, macOS, Windows)
