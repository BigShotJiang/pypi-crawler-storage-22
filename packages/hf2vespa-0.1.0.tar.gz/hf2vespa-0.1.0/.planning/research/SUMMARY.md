# Project Research Summary

**Project:** hf-vespa-feed
**Domain:** Vespa type converters and hex tensor encoding for ML embeddings
**Researched:** 2026-02-03
**Confidence:** HIGH

## Executive Summary

The v2.0 milestone adds support for Vespa's specialized types: hex-encoded tensors (int8, bfloat16, float32, float64), sparse/mixed tensors, and scalar types (position, weighted sets, maps). Research shows this is a straightforward extension of the existing converter registry pattern. The recommended approach uses Python's built-in struct module for binary packing, ml-dtypes for bfloat16 support, and maintains the existing streaming architecture. Hex encoding reduces memory footprint by 50-75% for int8/bfloat16 embeddings, making it essential for production-scale vector search.

The critical risk is endianness mismatches in binary encoding, which would cause silent data corruption across platforms. Prevention is simple: explicitly specify little-endian byte order in all struct.pack() calls. Secondary risks include bfloat16 handling (numpy lacks native support, requires ml-dtypes), hex string length validation (missing validation allows malformed data), and precision loss during type conversions (especially float64 to int8). All risks are mitigable through explicit validation, round-trip testing, and following established IEEE 754 encoding patterns.

The architecture requires no changes to the pipeline or registry pattern. New converters register identically to existing ones, maintain O(1) memory per record, and benefit from existing lru_cache optimization. Implementation complexity is moderate: scalar types are trivial (dict passthrough), dense hex encoding requires struct mastery, and sparse/mixed tensors add nested structure validation. Build order should prioritize correctness over optimization: implement scalar types first (low complexity), then dense hex encoding (core complexity), finally sparse/mixed tensors (structural complexity).

## Key Findings

### Recommended Stack

The existing v1.1 stack requires minimal additions. Add ml-dtypes (>=0.5.4) for bfloat16 support and use Python's built-in struct module for binary packing. The struct module provides IEEE 754-compliant encoding for all Vespa cell types with explicit byte order control. ml-dtypes is the official JAX/Google library for bfloat16, offers pre-compiled wheels for all platforms, and integrates seamlessly with numpy arrays from HuggingFace datasets.

**Core technologies:**
- **ml-dtypes (>=0.5.4)**: bfloat16 dtype for numpy — official JAX project, maintained by Google, 0KB overhead vs TensorFlow/PyTorch (500MB+ each)
- **struct (stdlib)**: binary packing for hex encoding — IEEE 754 compliant, explicit endianness control, C-level performance (<1µs per value)
- **orjson (existing)**: JSON serialization — unchanged, handles all new dict/list structures natively

**Do not add:**
- NumPy as direct dependency (already available via datasets library)
- TensorFlow/PyTorch (500MB+ for simple dtype conversion)
- Alternative bfloat16 libraries (require compilation, no wheels)

### Expected Features

Users expect accurate type conversion with zero data loss, clear error messages, and performance that doesn't bottleneck the pipeline. The v2.0 milestone focuses on correctness over optimization.

**Must have (table stakes):**
- Hex tensor encoding for all cell types (int8, bfloat16, float32, float64) — memory-efficient format is standard for Vespa embeddings
- Overflow detection and validation — prevent silent data corruption when values exceed type range
- Sparse tensor format (single mapped dimension) — common for categorical features, user-item matrices
- Error context improvements — extend existing row/column error reporting to new types

**Should have (competitive):**
- Mixed tensor format — combines sparse keys with dense arrays (word embeddings, multi-modal data)
- Position type — geo-search is table stakes for location-based apps
- Weighted sets and maps — generic key-value mappings in Vespa documents
- Format validation — verify output matches Vespa JSON spec before output

**Defer (v2+):**
- Auto-detect optimal cell type (analyze value distribution to recommend int8 vs bfloat16)
- Batch conversion optimization (vectorized numpy operations for large tensors)
- Converter chaining (compose converters: normalize → quantize → hex)
- Round-trip correctness tests with Vespa parser integration

**Anti-features (explicitly avoid):**
- Automatic type coercion without validation (300 → int8 should fail, not silently overflow to 44)
- In-memory batch processing (breaks streaming model, causes OOM)
- Custom tensor formats incompatible with Vespa documentation
- Result caching (causes memory exhaustion on large datasets)

### Architecture Approach

New converters integrate seamlessly with the existing registry pattern. No changes required to pipeline.py, apply_mappings(), or generator chaining. The registry's lru_cache optimization continues to work (caches function lookups, not results). All new converters return JSON-serializable types (str, dict, list) that orjson handles natively.

**Major components:**
1. **Hex tensor converters** — Dense tensor encoding using struct.pack() for binary-to-hex conversion, 4 variants (int8, bfloat16, float32, float64)
2. **Sparse/mixed tensor converters** — Nested structure validation, dict-of-lists format, optional hex encoding for mixed tensor blocks
3. **Scalar type converters** — Position (lat/lng dict), weighted sets (key→weight), maps (key→value), all use dict passthrough with validation

**Integration points:**
- Registry registration: Same pattern as v1.1, register 9 new converter types
- Config validation: Extend valid_types set in FieldMapping validator
- Pipeline flow: Unchanged, converters.convert(value, type_name) interface identical

**Performance characteristics:**
- Hex encoding overhead: ~1.5µs per 128-dim vector, ~16µs per 1536-dim vector
- Memory profile: O(1) per record (no accumulation), 50-75% payload reduction for int8/bfloat16
- Throughput: >5K records/sec with hex encoding (struct.pack is C-level fast)
- Optimization opportunity: Use numpy for vectors >512 dimensions (crossover point for numpy overhead)

### Critical Pitfalls

1. **Endianness mismatch in binary encoding** — Using struct.pack('f', value) instead of struct.pack('<f', value) causes platform-dependent hex strings. Little-endian x86 produces different output than big-endian systems. Prevention: Always use explicit '<' prefix (little-endian) in all struct.pack() calls, test on multiple platforms.

2. **bfloat16 native support gap in numpy** — numpy.dtype('bfloat16') raises TypeError, breaking pipelines with bfloat16 embeddings from ML models. Prevention: Use ml-dtypes library for bfloat16 support, or implement truncation method (upper 2 bytes of float32). Document ml-dtypes as required dependency.

3. **Incorrect hex string length validation** — Missing or extra hex characters create misaligned data. int8 requires exactly 2 hex chars per value, bfloat16=4, float32=8, float64=16. Off-by-one errors in length calculation allow malformed data to reach Vespa. Prevention: Validate hex string length before returning, use f'{val:02x}' for proper padding, test edge cases (single value, odd-length arrays).

4. **Precision loss in multi-step conversions** — Chaining float64→float32→int8 loses precision at each step. Using int() instead of round() causes truncation errors. Quantization requires specific scaling (clip(round(float * 127), -128, 127)). Prevention: Minimize conversion steps, use explicit rounding, document expected precision loss, test boundary values.

5. **Two's complement handling for negative int8** — int8 uses two's complement: 0-127 are positive, 128-255 represent -128 to -1. Manual implementations forget this. struct.pack('b', value) handles automatically, but decoding requires signed=True. Prevention: Use lowercase 'b' (signed) not uppercase 'B' (unsigned), test negative values explicitly (-128, -1, -64).

## Implications for Roadmap

Based on research, recommend 3-phase implementation prioritizing correctness over optimization:

### Phase 1: Scalar Types
**Rationale:** Lowest complexity, no binary encoding, provides immediate value for geo/metadata fields. Builds confidence before tackling hex encoding complexity.

**Delivers:** Position, weighted set, and map converters. Simple dict validation and passthrough, can be implemented and tested quickly (4-6 hours).

**Addresses:** Table-stakes features for geo-search and key-value fields. Extends existing converter registry without new dependencies.

**Avoids:** Binary encoding pitfalls. Establishes validation patterns before complex hex encoding.

### Phase 2: Dense Hex Encoding
**Rationale:** Core complexity of v2.0. Introduces binary packing, requires struct mastery, includes bfloat16 truncation technique. Foundation for Phase 3's mixed tensor hex encoding.

**Delivers:** Four hex tensor converters (tensor_hex_int8, tensor_hex_bfloat16, tensor_hex_float, tensor_hex_double). Overflow detection, format validation, explicit endianness handling.

**Uses:** ml-dtypes for bfloat16, struct module for binary packing. Implements IEEE 754 hex encoding per Vespa specification.

**Implements:** Core hex encoding pattern. Estimated 12-16 hours including testing against Vespa documentation examples.

**Avoids:** Critical endianness mismatch pitfall (Pitfall #1), bfloat16 numpy gap (Pitfall #2), hex length validation issues (Pitfall #3).

### Phase 3: Sparse and Mixed Tensors
**Rationale:** Builds on Phase 2 hex encoding. Nested structure validation more complex than flat arrays. Mixed tensor with hex combines both Phase 1 validation and Phase 2 hex encoding.

**Delivers:** Sparse tensor (dict of scalars), mixed tensor (dict of lists), mixed tensor with hex encoding (dict of hex strings).

**Uses:** Phase 2 hex encoding functions for mixed tensor blocks. Implements address-value pairing per Vespa specification.

**Implements:** Nested validation architecture. Estimated 8-12 hours including multi-dimensional dataset testing.

**Avoids:** Structural pitfalls from incorrect dimension ordering, empty value handling.

### Phase Ordering Rationale

- **Dependencies:** Phase 3 (mixed_tensor_hex_float) requires Phase 2 (hex encoding functions) to exist. Phase 1 has no dependencies, can be developed concurrently with Phase 2.
- **Complexity gradient:** Scalar → Dense → Nested progression builds team confidence. Each phase adds one layer of complexity.
- **Risk mitigation:** Phase 2 addresses all critical pitfalls before Phase 3 compounds them with nested structures.
- **Value delivery:** Phase 1 delivers immediate value (geo-search, metadata), Phase 2 unlocks memory savings (int8/bfloat16), Phase 3 completes feature parity with Vespa's type system.

### Research Flags

Phases with standard patterns (skip research-phase):
- **Phase 1 (Scalar Types):** Well-documented dict formats in Vespa docs, straightforward validation
- **Phase 2 (Dense Hex Encoding):** IEEE 754 is standard, Python struct module is authoritative, multiple worked examples in research
- **Phase 3 (Sparse/Mixed Tensors):** Vespa docs provide complete examples, builds on proven Phase 1+2 patterns

**No phases need deeper research.** All patterns are well-documented in official Vespa documentation and Python standard library docs. Proceed directly to implementation.

Optional Phase 4 (Performance Optimization) could benefit from targeted research:
- **Phase 4 (Performance):** Benchmark struct vs numpy for hex encoding, determine optimal threshold (currently estimated at 512 dimensions). Profile memory usage to verify O(1) per record. Measure throughput impact of hex encoding on pipeline.

## Confidence Assessment

| Area | Confidence | Notes |
|------|------------|-------|
| Stack | HIGH (95%) | ml-dtypes verified on PyPI (v0.5.4, 2025-11-17), struct module is stdlib, minimal dependencies |
| Features | HIGH (95%) | Verified with official Vespa documentation examples, user expectations clear from data pipeline best practices |
| Architecture | HIGH (98%) | Existing registry pattern proven in v1.1, no modifications required, integration points well-defined |
| Pitfalls | MEDIUM (70%) | Endianness/bfloat16/validation pitfalls verified, but Vespa-specific NaN/Infinity handling needs testing |

**Overall confidence:** HIGH (90%)

### Gaps to Address

- **Vespa's endianness requirement:** Documentation implies little-endian but doesn't state explicitly. Assume little-endian based on x86 dominance, verify during Phase 2 integration testing.

- **NaN/Infinity policy:** IEEE 754 supports NaN and Infinity, which encode to specific bit patterns. Vespa behavior undefined in docs. Decision needed: reject, allow, or make configurable. Test Vespa's actual handling during Phase 2.

- **NumPy availability verification:** Inferred that datasets library includes NumPy (Arrow backend uses numpy arrays), but not explicitly documented. Verify in Phase 1 unit tests that numpy import succeeds.

- **Quantization formula standardization:** Multiple approaches exist (symmetric, asymmetric, per-tensor, per-channel). Phase 2 should document chosen approach for int8 quantization (recommend: symmetric, per-tensor, scale=127).

- **Performance optimization threshold:** Struct vs numpy crossover point estimated at 512 dimensions based on typical overhead. Needs benchmarking in Phase 4 to confirm or adjust threshold.

- **Cross-platform consistency:** Hex encoding should produce identical output on Linux, macOS, Windows. Verify in CI during Phase 2 with explicit endianness tests.

## Sources

### Primary (HIGH confidence)
- [Vespa Document JSON Format Reference](https://docs.vespa.ai/en/reference/schemas/document-json-format.html) — Tensor formats, hex encoding, position, weighted sets, maps
- [Vespa Tensor Reference](https://docs.vespa.ai/en/reference/ranking/tensor.html) — Cell types (int8, bfloat16, float, double), hex encoding format specification
- [Python struct Module Documentation](https://docs.python.org/3/library/struct.html) — Binary data packing, format codes, byte order specifications
- [ml-dtypes PyPI](https://pypi.org/project/ml-dtypes/) — Official package page, v0.5.4 (2025-11-17), bfloat16 support
- [Vespa Geo Search](https://docs.vespa.ai/en/geo-search.html) — Position field format specification

### Secondary (MEDIUM confidence)
- [Vespa Blog: BGE with bfloat16](https://blog.vespa.ai/bge-embedding-models-in-vespa-using-bfloat16/) — Real-world bfloat16 usage patterns, memory savings
- [NumPy Data Types Manual](https://numpy.org/doc/stable/user/basics.types.html) — Type conversion and precision handling
- [GitHub: ml_dtypes](https://github.com/jax-ml/ml_dtypes) — Source code, bfloat16 implementation details
- [WikiChip: Brain Floating-Point Format](https://en.wikichip.org/wiki/brain_floating-point_format) — bfloat16 specification and truncation explanation
- [Data Pipeline Best Practices](https://www.startdataengineering.com/post/code-patterns/) — Error handling patterns, validation strategies

### Tertiary (LOW confidence)
- [GitHub: xbeat/Machine-Learning BFloat16 Guide](https://github.com/xbeat/Machine-Learning/blob/main/Exploring%20Float32,%20Float16,%20and%20BFloat16%20for%20Deep%20Learning%20in%20Python.md) — Conversion techniques (community resource)
- [TensorFlow INT8 Quantization](https://developer.nvidia.com/blog/achieving-fp32-accuracy-for-int8-inference-using-quantization-aware-training-with-tensorrt/) — Quantization best practices (context differs but principles apply)

---
*Research completed: 2026-02-03*
*Ready for roadmap: yes*
