from hf2vespa.cli import app

if __name__ == "__main__":
    app()
