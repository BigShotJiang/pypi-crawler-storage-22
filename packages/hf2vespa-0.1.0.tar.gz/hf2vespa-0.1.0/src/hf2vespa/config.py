"""Configuration schema for Vespa feed generation."""

from pathlib import Path

import yaml
from pydantic import BaseModel, field_validator


class FieldMapping(BaseModel):
    """
    Field mapping configuration from dataset column to Vespa field.

    Attributes:
        source: Source column name in the dataset
        target: Target field name in Vespa document
        type: Type conversion to apply (e.g., "tensor", "string", "int", "float")

    Examples:
        >>> m = FieldMapping(source="embedding", target="vector", type="tensor")
        >>> m.source
        'embedding'
        >>> m.type
        'tensor'
    """

    source: str
    target: str
    type: str | None = None

    @field_validator("type")
    @classmethod
    def validate_type(cls, v: str | None) -> str | None:
        """
        Validate that type is one of the known converter types.

        Args:
            v: Type string to validate

        Returns:
            Validated type string or None

        Raises:
            ValueError: If type is not one of the known types
        """
        if v is None:
            return v

        valid_types = {
            # Basic types
            "tensor",
            "string",
            "int",
            "float",
            # Scalar types (Phase 8)
            "position",
            "weightedset",
            "map",
            # Hex tensor types (Phase 9)
            "tensor_int8_hex",
            "tensor_bfloat16_hex",
            "tensor_float32_hex",
            "tensor_float64_hex",
            # Sparse and mixed tensor types (Phase 10)
            "sparse_tensor",
            "mixed_tensor",
            "mixed_tensor_hex",
        }
        if v not in valid_types:
            raise ValueError(
                f"Unknown type converter '{v}'. Must be one of: {', '.join(sorted(valid_types))}"
            )
        return v


class VespaConfig(BaseModel):
    """
    Configuration for Vespa feed generation.

    Attributes:
        namespace: Vespa namespace for document IDs (default: "doc")
        doctype: Vespa document type for document IDs (default: "doc")
        id_column: Dataset column to use as document ID (default: None, uses sequential numbering)
        mappings: List of field mappings from dataset to Vespa format

    Examples:
        >>> cfg = VespaConfig()
        >>> cfg.namespace
        'doc'
        >>> cfg.mappings
        []
    """

    namespace: str = "doc"
    doctype: str = "doc"
    id_column: str | None = None
    mappings: list[FieldMapping] = []

    @classmethod
    def from_yaml(cls, path: str | Path) -> "VespaConfig":
        """
        Load configuration from a YAML file.

        Args:
            path: Path to YAML configuration file

        Returns:
            VespaConfig instance with validated configuration

        Raises:
            ValueError: If file not found, YAML parsing fails, or validation fails

        Examples:
            >>> # Assuming config.yaml exists with valid configuration
            >>> cfg = VespaConfig.from_yaml("config.yaml")  # doctest: +SKIP
            >>> isinstance(cfg, VespaConfig)  # doctest: +SKIP
            True
        """
        path_obj = Path(path)

        try:
            with open(path_obj, "r") as f:
                data = yaml.safe_load(f)
        except FileNotFoundError:
            raise ValueError(f"Configuration file not found: {path}")
        except yaml.YAMLError as e:
            raise ValueError(f"Failed to parse YAML from {path}: {e}")

        try:
            return cls(**data)
        except Exception as e:
            raise ValueError(f"Failed to validate configuration from {path}: {e}")
