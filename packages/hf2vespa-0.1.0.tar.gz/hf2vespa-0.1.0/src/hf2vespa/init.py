"""Schema inspection and YAML config generation for HuggingFace datasets."""

from pathlib import Path
from typing import Any

import typer
from datasets import Sequence, Value, load_dataset_builder, get_dataset_config_names
from datasets.features import List, LargeList
from ruamel.yaml import YAML
from ruamel.yaml.comments import CommentedMap, CommentedSeq


def is_list_feature(feature: Any) -> bool:
    """
    Check if feature is a list/sequence type suitable for tensor conversion.

    List columns containing numeric values are good candidates for
    Vespa tensor conversion (embeddings, vectors, etc.)

    Args:
        feature: A HuggingFace datasets Feature object

    Returns:
        True if feature is a list/sequence type

    Examples:
        >>> from datasets import Sequence, Value
        >>> is_list_feature(Sequence(feature=Value("float32")))
        True
        >>> is_list_feature(Value("string"))
        False
    """
    # Check for datasets library sequence types
    if isinstance(feature, (Sequence, List, LargeList)):
        return True

    # Check for Python list with feature type inside
    if isinstance(feature, list) and len(feature) == 1:
        return True

    return False


def get_value_dtype(feature: Any) -> str:
    """
    Get the dtype string for display in YAML comments.

    Args:
        feature: A HuggingFace datasets Feature object

    Returns:
        Human-readable dtype string (e.g., "string", "Sequence[float32]")

    Examples:
        >>> from datasets import Sequence, Value
        >>> get_value_dtype(Value("string"))
        'string'
        >>> get_value_dtype(Sequence(feature=Value("float32")))
        'Sequence[float32]'
    """
    if isinstance(feature, Value):
        return feature.dtype
    elif isinstance(feature, Sequence):
        inner = feature.feature
        if isinstance(inner, Value):
            return f"Sequence[{inner.dtype}]"
        return "Sequence[complex]"
    elif isinstance(feature, (List, LargeList)):
        inner = feature.feature
        if isinstance(inner, Value):
            return f"List[{inner.dtype}]"
        return "List[complex]"
    elif isinstance(feature, list) and len(feature) == 1:
        inner = feature[0]
        if isinstance(inner, Value):
            return f"list[{inner.dtype}]"
        return "list[complex]"
    elif isinstance(feature, dict):
        return "dict"
    else:
        return str(type(feature).__name__)


def suggest_type(col_name: str, feature: Any) -> str | None:
    """
    Suggest type conversion based on feature type.

    For list columns with numeric inner types, suggests "tensor" conversion.
    For other columns, returns None (no conversion needed).

    Args:
        col_name: Column name (not currently used but available for name-based heuristics)
        feature: A HuggingFace datasets Feature object

    Returns:
        "tensor" for numeric list columns, None otherwise

    Examples:
        >>> from datasets import Sequence, Value
        >>> suggest_type("embedding", Sequence(feature=Value("float32")))
        'tensor'
        >>> suggest_type("name", Value("string"))

    """
    if is_list_feature(feature):
        # Get inner type
        inner = None
        if isinstance(feature, Sequence):
            inner = feature.feature
        elif isinstance(feature, (List, LargeList)):
            inner = feature.feature
        elif isinstance(feature, list) and len(feature) == 1:
            inner = feature[0]

        # Check if inner type is numeric
        if isinstance(inner, Value):
            numeric_types = (
                "float32",
                "float64",
                "float",
                "double",
                "int32",
                "int64",
                "int",
                "int8",
                "int16",
            )
            if inner.dtype in numeric_types:
                return "tensor"
    return None


def inspect_dataset_schema(
    dataset_name: str,
    config: str | None = None,
) -> dict[str, Any]:
    """
    Get dataset schema without downloading data files.

    Uses load_dataset_builder() to access metadata without downloading
    the actual data files.

    Args:
        dataset_name: HuggingFace dataset name (e.g., "glue", "squad")
        config: Dataset configuration name (required for multi-config datasets)

    Returns:
        Dict containing:
        - columns: {name: feature_type} mapping
        - list_columns: List of column names that are list/sequence types
        - available_splits: List of available split names

    Raises:
        ValueError: If dataset cannot be loaded or config is required but not provided

    Examples:
        >>> schema = inspect_dataset_schema("glue", config="ax")  # doctest: +SKIP
        >>> "premise" in schema["columns"]  # doctest: +SKIP
        True
    """
    # Get builder for dataset (no download)
    builder = load_dataset_builder(dataset_name, config)
    features = builder.info.features

    columns = {}
    list_columns = []

    for col_name, col_type in features.items():
        columns[col_name] = col_type
        # Detect list/sequence columns for tensor suggestion
        if is_list_feature(col_type):
            list_columns.append(col_name)

    # Get available splits
    available_splits = (
        list(builder.info.splits.keys()) if builder.info.splits else ["train"]
    )

    return {
        "columns": columns,
        "list_columns": list_columns,
        "available_splits": available_splits,
    }


def generate_config_yaml(
    features: dict[str, Any],
    output_path: Path,
    dataset_name: str,
    config: str | None = None,
    split: str = "train",
    namespace: str = "doc",
    doctype: str = "doc",
) -> None:
    """
    Generate a YAML config file with comments for user guidance.

    Uses ruamel.yaml's CommentedMap to include helpful comments
    explaining each configuration option.

    Args:
        features: Dict mapping column names to feature types
        output_path: Path to write the YAML file
        dataset_name: Name of the dataset (for header comment)
        config: Dataset config name (for header comment)
        split: Dataset split name (for header comment)
        namespace: Default Vespa namespace
        doctype: Default Vespa document type

    Examples:
        >>> from pathlib import Path
        >>> features = {"id": Value("string"), "text": Value("string")}  # doctest: +SKIP
        >>> generate_config_yaml(features, Path("/tmp/test.yaml"), "test-dataset")  # doctest: +SKIP
    """
    yaml = YAML()
    yaml.default_flow_style = False
    yaml.indent(mapping=2, sequence=4, offset=2)

    # Create root config with CommentedMap for comment support
    root = CommentedMap()

    # Header comment
    root.yaml_set_start_comment(
        f"Generated config for dataset: {dataset_name}\n"
        f"Config: {config or 'default'}, Split: {split}\n"
        f"Edit this file to customize field mappings.\n"
    )

    # Basic config with comments
    root["namespace"] = namespace
    root.yaml_add_eol_comment("Vespa namespace for document IDs", "namespace")

    root["doctype"] = doctype
    root.yaml_add_eol_comment("Vespa document type", "doctype")

    root["id_column"] = None
    root.yaml_add_eol_comment(
        "Column to use as document ID (null = auto-increment)", "id_column"
    )

    # Mappings section
    mappings = CommentedSeq()
    root["mappings"] = mappings
    root.yaml_set_comment_before_after_key(
        "mappings", before="\nField mappings: source (dataset) -> target (Vespa)"
    )

    for col_name, col_type in features.items():
        mapping = CommentedMap()
        mapping["source"] = col_name
        mapping["target"] = col_name  # Default: same name

        # Add type suggestion for list columns
        suggested = suggest_type(col_name, col_type)
        dtype_str = get_value_dtype(col_type)

        if suggested:
            mapping["type"] = suggested
            mapping.yaml_add_eol_comment(
                f"{dtype_str} -> suggested: {suggested}", "type"
            )
        else:
            mapping["type"] = None
            mapping.yaml_add_eol_comment(dtype_str, "type")

        mappings.append(mapping)

    # Write to file
    with open(output_path, "w") as f:
        yaml.dump(root, f)


def init_command(
    dataset: str,
    output: Path,
    split: str = "train",
    config: str | None = None,
) -> None:
    """
    Generate a YAML config by inspecting a HuggingFace dataset schema.

    Main entry point for the init command. Inspects the dataset schema
    without downloading data and generates a commented YAML config file.

    Args:
        dataset: HuggingFace dataset name
        output: Output YAML file path
        split: Dataset split to inspect (default: "train")
        config: Dataset config name (required for multi-config datasets)

    Raises:
        typer.Exit: On error (with helpful message printed to stderr)
    """
    # Check for multi-config datasets
    try:
        configs = get_dataset_config_names(dataset)
        if len(configs) > 1 and config is None:
            typer.echo(
                f"Dataset '{dataset}' has multiple configs: {', '.join(configs)}",
                err=True,
            )
            typer.echo("Please specify one with --config", err=True)
            raise typer.Exit(1)
    except Exception as e:
        # Some datasets don't have configs - that's fine
        if "multiple configs" not in str(e):
            configs = []

    # Get dataset builder (no download)
    try:
        builder = load_dataset_builder(dataset, config)
    except Exception as e:
        typer.echo(f"Error loading dataset: {e}", err=True)
        raise typer.Exit(1)

    features = builder.info.features

    # Check split exists
    available_splits = (
        list(builder.info.splits.keys()) if builder.info.splits else ["train"]
    )
    if split not in available_splits:
        typer.echo(
            f"Split '{split}' not found. Available: {', '.join(available_splits)}",
            err=True,
        )
        raise typer.Exit(1)

    # Generate YAML config
    try:
        generate_config_yaml(
            features=features,
            output_path=output,
            dataset_name=dataset,
            config=config,
            split=split,
        )
    except Exception as e:
        typer.echo(f"Error writing file: {e}", err=True)
        raise typer.Exit(1)

    # Print summary
    typer.echo(f"Generated config: {output}", err=True)
    typer.echo(f"  {len(features)} columns mapped", err=True)

    list_cols = [n for n, t in features.items() if is_list_feature(t)]
    if list_cols:
        typer.echo(
            f"  {len(list_cols)} list columns suggested for tensor conversion",
            err=True,
        )
