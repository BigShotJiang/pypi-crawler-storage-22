"""Streaming pipeline for HuggingFace datasets to Vespa format."""

from typing import Generator

from datasets import load_dataset

from .config import FieldMapping, VespaConfig
from .converters import converters
from .utils import generate_vespa_id


def stream_dataset(
    dataset_name: str,
    split: str,
    include: list[str] | None = None,
    rename: dict[str, str] | None = None,
    config: str | None = None,
    num_proc: int | None = None,
) -> Generator[dict, None, None]:
    """
    Stream a HuggingFace dataset with optional column filtering and renaming.

    Args:
        dataset_name: HuggingFace dataset identifier (e.g., "glue", "squad")
        split: Dataset split to stream (e.g., "train", "test", "validation")
        include: List of column names to include. If None, include all columns.
        rename: Dictionary mapping old column names to new names. Applied after filtering.
        config: Dataset configuration name (e.g., "ax" for glue dataset)
        num_proc: Number of parallel workers for dataset operations. Note: HuggingFace
            datasets library does not support num_proc with streaming=True. This parameter
            is accepted for API consistency but is not passed to load_dataset. For parallel
            processing with streaming datasets, wrap the dataset with PyTorch DataLoader
            using num_workers > 1 instead.

    Yields:
        Dictionary records from the dataset

    Examples:
        >>> records = stream_dataset("glue", "ax", include=["premise", "hypothesis"], config="ax")
        >>> first = next(records)
        >>> "premise" in first and "hypothesis" in first
        True
    """
    # Load dataset in streaming mode for O(1) memory usage
    # Note: num_proc is not supported with streaming=True by HuggingFace datasets
    # library. Parameter is accepted but not used. For parallel streaming, users
    # should wrap the output with PyTorch DataLoader.
    dataset = load_dataset(
        dataset_name,
        config,
        split=split,
        streaming=True,
    )

    # Apply column filtering if specified
    if include is not None:
        dataset = dataset.select_columns(include)

    # Apply column renaming if specified
    if rename is not None:
        dataset = dataset.rename_columns(rename)

    # Yield records one at a time
    yield from dataset


def validate_config(config: VespaConfig, dataset_columns: set[str]) -> None:
    """
    Validate that config references only columns that exist in the dataset.

    Args:
        config: VespaConfig to validate
        dataset_columns: Set of column names available in the dataset

    Raises:
        ValueError: If id_column or any mapping source references a non-existent column

    Examples:
        >>> cfg = VespaConfig(id_column="idx", mappings=[FieldMapping(source="text", target="content")])
        >>> validate_config(cfg, {"idx", "text", "label"})  # No error
        >>> validate_config(VespaConfig(id_column="missing"), {"idx", "text"})  # doctest: +SKIP
        Traceback (most recent call last):
        ...
        ValueError: id_column 'missing' not found in dataset. Available columns: idx, text
    """
    # Validate id_column exists if set
    if config.id_column is not None and config.id_column not in dataset_columns:
        available = ", ".join(sorted(dataset_columns))
        raise ValueError(
            f"id_column '{config.id_column}' not found in dataset. Available columns: {available}"
        )

    # Validate each mapping source exists
    for mapping in config.mappings:
        if mapping.source not in dataset_columns:
            available = ", ".join(sorted(dataset_columns))
            raise ValueError(
                f"Mapping source '{mapping.source}' not found in dataset. Available columns: {available}"
            )


def apply_mappings(
    record: dict, mappings: list[FieldMapping], row_num: int = 0
) -> dict:
    """
    Apply field mappings and type conversions to a record.

    Args:
        record: Source record from dataset
        mappings: List of field mappings to apply
        row_num: Row number for error context (1-based, default 0 for unspecified)

    Returns:
        New dictionary with mapped and converted fields

    Raises:
        ValueError: If field is missing or type conversion fails.
            Error message includes row number and field name for debugging.

    Examples:
        >>> mappings = [
        ...     FieldMapping(source="vec", target="embedding", type="tensor"),
        ...     FieldMapping(source="name", target="title")
        ... ]
        >>> record = {"vec": [1.0, 2.0, 3.0], "name": "test"}
        >>> result = apply_mappings(record, mappings, row_num=1)
        >>> result
        {'embedding': {'values': [1.0, 2.0, 3.0]}, 'title': 'test'}

        >>> # Missing field error includes row and field context
        >>> apply_mappings({"x": 1}, [FieldMapping(source="missing", target="out")], row_num=42)
        Traceback (most recent call last):
        ...
        ValueError: Row 42: Missing field 'missing'
    """
    result = {}
    for mapping in mappings:
        try:
            value = record[mapping.source]
        except KeyError:
            raise ValueError(f"Row {row_num}: Missing field '{mapping.source}'")

        # Apply type conversion if specified
        if mapping.type is not None:
            try:
                value = converters.convert(value, mapping.type)
            except Exception as e:
                raise ValueError(f"Row {row_num}, field '{mapping.source}': {e}")

        result[mapping.target] = value

    return result


def format_vespa_put(
    records: Generator[dict, None, None],
    namespace: str,
    doctype: str,
    config: VespaConfig | None = None,
) -> Generator[dict, None, None]:
    """
    Format dataset records as Vespa PUT operations.

    Args:
        records: Generator of dataset records
        namespace: Vespa namespace for document IDs
        doctype: Vespa document type for document IDs
        config: Optional VespaConfig for field mappings and custom ID column

    Yields:
        Vespa PUT operation dictionaries with structure:
        {"put": "id:namespace:doctype::N", "fields": {...}}

    Examples:
        >>> records = iter([{"text": "hello"}, {"text": "world"}])
        >>> vespa = format_vespa_put(records, "test", "doc")
        >>> doc = next(vespa)
        >>> doc["put"]
        'id:test:doc::0'
        >>> doc["fields"]["text"]
        'hello'
    """
    for idx, record in enumerate(records, start=1):
        # Determine document ID
        if config is not None and config.id_column is not None:
            doc_id = str(record[config.id_column])
        else:
            doc_id = str(idx - 1)  # Keep 0-based IDs for compatibility

        vespa_id = generate_vespa_id(namespace, doctype, doc_id)

        # Apply field mappings if configured
        if config is not None and config.mappings:
            fields = apply_mappings(record, config.mappings, row_num=idx)
        else:
            fields = record

        yield {"put": vespa_id, "fields": fields}
