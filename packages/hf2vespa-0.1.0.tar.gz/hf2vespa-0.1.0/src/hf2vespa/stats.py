"""Statistics tracking for pipeline processing."""

from collections import Counter
from dataclasses import dataclass, field
from enum import Enum


class ErrorMode(str, Enum):
    """
    Error handling mode for pipeline processing.

    Values:
        fail: Stop processing on first error (default)
        skip: Skip erroring records and continue processing

    Examples:
        >>> ErrorMode.fail.value
        'fail'
        >>> ErrorMode.skip.value
        'skip'
    """

    fail = "fail"
    skip = "skip"


@dataclass
class ProcessingStats:
    """
    Statistics accumulator for tracking processing success and errors.

    Attributes:
        counter: Counter tracking success/error counts by type

    Examples:
        >>> stats = ProcessingStats()
        >>> stats.record_success()
        >>> stats.record_success()
        >>> stats.record_error()
        >>> stats.total_processed
        3
        >>> stats.success_count
        2
        >>> stats.error_count
        1
    """

    counter: Counter = field(default_factory=Counter)

    def record_success(self) -> None:
        """Increment the success counter."""
        self.counter["success"] += 1

    def record_error(self, error_type: str = "error") -> None:
        """
        Increment an error counter.

        Args:
            error_type: Type of error to record (default: "error")
        """
        self.counter[error_type] += 1

    @property
    def total_processed(self) -> int:
        """Return total number of records processed (success + errors)."""
        return self.counter.total()

    @property
    def success_count(self) -> int:
        """Return number of successfully processed records."""
        return self.counter["success"]

    @property
    def error_count(self) -> int:
        """Return total number of errors (all non-success counts)."""
        return sum(count for key, count in self.counter.items() if key != "success")
