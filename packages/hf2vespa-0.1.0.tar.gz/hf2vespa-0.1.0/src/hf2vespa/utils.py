"""Utility functions for Vespa feed generation."""

import os
import sys
from contextlib import contextmanager


@contextmanager
def handle_broken_pipe():
    """
    Context manager to handle SIGPIPE/BrokenPipeError gracefully.

    When piped to tools like `head`, the pipe may close before all output is written.
    This prevents ugly tracebacks by redirecting remaining output to /dev/null.

    Usage:
        with handle_broken_pipe():
            # Write to stdout
            sys.stdout.buffer.write(data)
    """
    try:
        sys.stdout.flush()
        yield
    except BrokenPipeError:
        # Redirect stdout to /dev/null to suppress further errors
        devnull = os.open(os.devnull, os.O_WRONLY)
        os.dup2(devnull, sys.stdout.fileno())
        sys.exit(0)


def generate_vespa_id(namespace: str, doctype: str, key: str | int) -> str:
    """
    Generate a Vespa document ID in the format: id:namespace:doctype::key

    Args:
        namespace: Vespa namespace (must not contain ':')
        doctype: Vespa document type (must not contain ':')
        key: Unique identifier (typically an integer)

    Returns:
        Formatted Vespa document ID

    Raises:
        ValueError: If namespace or doctype contains invalid characters

    Examples:
        >>> generate_vespa_id("myns", "doc", 42)
        'id:myns:doc::42'
        >>> generate_vespa_id("test", "article", "abc123")
        'id:test:article::abc123'
    """
    if ":" in namespace:
        raise ValueError(f"Namespace cannot contain ':' character: {namespace}")
    if ":" in doctype:
        raise ValueError(f"Doctype cannot contain ':' character: {doctype}")

    return f"id:{namespace}:{doctype}::{key}"
