"""Benchmark fixtures for data generation."""

import pytest


@pytest.fixture
def int8_data():
    """Generate int8 data for benchmarks."""

    def _generate(size: int) -> list[int]:
        """Generate list of int8 values."""
        return [i % 256 - 128 for i in range(size)]

    return _generate


@pytest.fixture
def float_data():
    """Generate float data for benchmarks."""

    def _generate(size: int) -> list[float]:
        """Generate list of float values."""
        return [float(i) * 0.001 for i in range(size)]

    return _generate


@pytest.fixture
def embedding_data():
    """Generate embedding-like data (768-dim vectors)."""

    def _generate(size: int, dim: int = 768) -> list[list[float]]:
        """Generate list of embedding vectors."""
        return [[float(i + j) * 0.001 for j in range(dim)] for i in range(size)]

    return _generate


@pytest.fixture
def sparse_data():
    """Generate sparse tensor data."""

    def _generate(size: int, vocab_size: int = 100) -> list[dict]:
        """Generate list of sparse tensor dicts."""
        return [
            {
                f"word_{j % vocab_size}": float(j) * 0.1
                for j in range(i % vocab_size + 1)
            }
            for i in range(size)
        ]

    return _generate


@pytest.fixture
def mixed_tensor_data():
    """Generate mixed tensor data (sparse + dense)."""

    def _generate(size: int, num_keys: int = 10, dim: int = 64) -> list[dict]:
        """Generate list of mixed tensor dicts."""
        return [
            {
                f"key_{k}": [float(i + k + d) * 0.001 for d in range(dim)]
                for k in range(num_keys)
            }
            for i in range(size)
        ]

    return _generate


@pytest.fixture
def realistic_record():
    """Generate a realistic record with multiple field types."""
    return {
        "embedding": [float(i) * 0.001 for i in range(768)],
        "sparse": {f"word_{i}": float(i) * 0.1 for i in range(50)},
        "title": "Example document title with some content",
        "score": 0.95,
        "id": "doc_12345",
    }
