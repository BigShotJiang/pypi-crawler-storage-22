"""Benchmark tests for individual converters.

Run with: pytest tests/benchmarks/ --benchmark-enable -v
"""

import pytest

from hf2vespa.converters import (
    list_to_tensor,
    list_to_tensor_int8_hex,
    list_to_tensor_bfloat16_hex,
    list_to_tensor_float32_hex,
    list_to_tensor_float64_hex,
    dict_to_sparse_tensor,
    dict_to_mixed_tensor,
    dict_to_mixed_tensor_hex,
    dict_to_position,
    dict_to_weightedset,
    dict_to_map,
)


# =============================================================================
# Basic tensor converter benchmarks
# =============================================================================


@pytest.mark.benchmark(group="tensor_basic")
class TestTensorBasicBenchmarks:
    """Benchmarks for basic tensor converter."""

    @pytest.mark.parametrize("size", [100, 1000, 10000])
    def test_list_to_tensor(self, benchmark, float_data, size):
        """Benchmark basic tensor conversion."""
        data = float_data(size)
        benchmark(list_to_tensor, data)


# =============================================================================
# Hex encoder benchmarks (int8, bfloat16, float32, float64)
# =============================================================================


@pytest.mark.benchmark(group="hex_int8")
class TestInt8HexBenchmarks:
    """Benchmarks for int8 hex encoder."""

    @pytest.mark.parametrize("size", [100, 1000, 10000])
    def test_int8_hex_scaling(self, benchmark, int8_data, size):
        """Benchmark int8 hex encoding at different sizes."""
        data = int8_data(size)
        benchmark(list_to_tensor_int8_hex, data)


@pytest.mark.benchmark(group="hex_bfloat16")
class TestBfloat16HexBenchmarks:
    """Benchmarks for bfloat16 hex encoder."""

    @pytest.mark.parametrize("size", [100, 1000, 10000])
    def test_bfloat16_hex_scaling(self, benchmark, float_data, size):
        """Benchmark bfloat16 hex encoding at different sizes."""
        data = float_data(size)
        benchmark(list_to_tensor_bfloat16_hex, data)


@pytest.mark.benchmark(group="hex_float32")
class TestFloat32HexBenchmarks:
    """Benchmarks for float32 hex encoder."""

    @pytest.mark.parametrize("size", [100, 1000, 10000])
    def test_float32_hex_scaling(self, benchmark, float_data, size):
        """Benchmark float32 hex encoding at different sizes."""
        data = float_data(size)
        benchmark(list_to_tensor_float32_hex, data)


@pytest.mark.benchmark(group="hex_float64")
class TestFloat64HexBenchmarks:
    """Benchmarks for float64 hex encoder."""

    @pytest.mark.parametrize("size", [100, 1000, 10000])
    def test_float64_hex_scaling(self, benchmark, float_data, size):
        """Benchmark float64 hex encoding at different sizes."""
        data = float_data(size)
        benchmark(list_to_tensor_float64_hex, data)


# =============================================================================
# Embedding-sized hex encoding benchmarks (realistic 768-dim)
# =============================================================================


@pytest.mark.benchmark(group="embedding_hex")
class TestEmbeddingHexBenchmarks:
    """Benchmarks for embedding-sized hex encoding (768-dim vectors)."""

    def test_float32_hex_768dim(self, benchmark, embedding_data):
        """Benchmark float32 hex with 768-dim embedding."""
        embeddings = embedding_data(1, dim=768)
        benchmark(list_to_tensor_float32_hex, embeddings[0])

    def test_bfloat16_hex_768dim(self, benchmark, embedding_data):
        """Benchmark bfloat16 hex with 768-dim embedding."""
        embeddings = embedding_data(1, dim=768)
        benchmark(list_to_tensor_bfloat16_hex, embeddings[0])

    def test_int8_hex_768dim(self, benchmark, int8_data):
        """Benchmark int8 hex with 768-dim embedding."""
        data = int8_data(768)
        benchmark(list_to_tensor_int8_hex, data)


# =============================================================================
# Sparse tensor benchmarks
# =============================================================================


@pytest.mark.benchmark(group="sparse")
class TestSparseTensorBenchmarks:
    """Benchmarks for sparse tensor converter."""

    @pytest.mark.parametrize("vocab_size", [10, 100, 1000])
    def test_sparse_tensor_vocab_scaling(self, benchmark, vocab_size):
        """Benchmark sparse tensor with different vocabulary sizes."""
        data = {f"word_{i}": float(i) * 0.1 for i in range(vocab_size)}
        benchmark(dict_to_sparse_tensor, data)


# =============================================================================
# Mixed tensor benchmarks
# =============================================================================


@pytest.mark.benchmark(group="mixed")
class TestMixedTensorBenchmarks:
    """Benchmarks for mixed tensor converters."""

    @pytest.mark.parametrize("num_keys", [5, 10, 50])
    def test_mixed_tensor_key_scaling(self, benchmark, num_keys):
        """Benchmark mixed tensor with different key counts."""
        data = {f"key_{k}": [float(d) for d in range(64)] for k in range(num_keys)}
        benchmark(dict_to_mixed_tensor, data)

    @pytest.mark.parametrize("num_keys", [5, 10, 50])
    def test_mixed_tensor_hex_key_scaling(self, benchmark, num_keys):
        """Benchmark mixed tensor hex with different key counts."""
        data = {f"key_{k}": [float(d) for d in range(64)] for k in range(num_keys)}
        benchmark(dict_to_mixed_tensor_hex, data, cell_type="float32")


# =============================================================================
# Scalar type benchmarks
# =============================================================================


@pytest.mark.benchmark(group="scalar")
class TestScalarBenchmarks:
    """Benchmarks for scalar converters (position, weightedset, map)."""

    def test_position_conversion(self, benchmark):
        """Benchmark position converter."""
        data = {"lat": 37.4, "lng": -122.0}
        benchmark(dict_to_position, data)

    def test_weightedset_small(self, benchmark):
        """Benchmark small weighted set (10 items)."""
        data = {f"tag_{i}": i * 10 for i in range(10)}
        benchmark(dict_to_weightedset, data)

    def test_weightedset_large(self, benchmark):
        """Benchmark large weighted set (100 items)."""
        data = {f"tag_{i}": i * 10 for i in range(100)}
        benchmark(dict_to_weightedset, data)

    def test_map_small(self, benchmark):
        """Benchmark small map (10 items)."""
        data = {f"key_{i}": f"value_{i}" for i in range(10)}
        benchmark(dict_to_map, data)

    def test_map_large(self, benchmark):
        """Benchmark large map (100 items)."""
        data = {f"key_{i}": f"value_{i}" for i in range(100)}
        benchmark(dict_to_map, data)
