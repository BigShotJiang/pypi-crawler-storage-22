"""Benchmark tests for full pipeline throughput.

Run with: pytest tests/benchmarks/ --benchmark-enable -v
"""

import pytest

from hf2vespa.pipeline import apply_mappings
from hf2vespa.config import FieldMapping


# =============================================================================
# Pipeline throughput benchmarks
# =============================================================================


@pytest.mark.benchmark(group="pipeline")
class TestPipelineThroughput:
    """Benchmarks for full pipeline throughput with realistic configs."""

    @pytest.fixture
    def simple_config(self):
        """Config with basic types only."""
        return [
            FieldMapping(source="title", target="title", type="string"),
            FieldMapping(source="score", target="score", type="float"),
            FieldMapping(source="id", target="doc_id", type="string"),
        ]

    @pytest.fixture
    def embedding_config(self):
        """Config with tensor conversion."""
        return [
            FieldMapping(source="embedding", target="embedding", type="tensor"),
            FieldMapping(source="title", target="title", type="string"),
        ]

    @pytest.fixture
    def hex_config(self):
        """Config with hex tensor conversion."""
        return [
            FieldMapping(
                source="embedding", target="embedding", type="tensor_float32_hex"
            ),
            FieldMapping(source="title", target="title", type="string"),
        ]

    @pytest.fixture
    def mixed_config(self):
        """Config with multiple converter types."""
        return [
            FieldMapping(
                source="embedding", target="embedding", type="tensor_float32_hex"
            ),
            FieldMapping(source="sparse", target="sparse", type="sparse_tensor"),
            FieldMapping(source="title", target="title", type="string"),
            FieldMapping(source="score", target="score", type="float"),
        ]

    def test_simple_mapping_100(self, benchmark, simple_config, realistic_record):
        """Benchmark simple mapping with 100 records."""
        records = [realistic_record.copy() for _ in range(100)]

        def process_batch():
            return [
                apply_mappings(r, simple_config, row_num=i)
                for i, r in enumerate(records)
            ]

        benchmark(process_batch)

    def test_simple_mapping_1000(self, benchmark, simple_config, realistic_record):
        """Benchmark simple mapping with 1000 records."""
        records = [realistic_record.copy() for _ in range(1000)]

        def process_batch():
            return [
                apply_mappings(r, simple_config, row_num=i)
                for i, r in enumerate(records)
            ]

        benchmark(process_batch)

    def test_embedding_mapping_100(self, benchmark, embedding_config, realistic_record):
        """Benchmark tensor mapping with 100 records."""
        records = [realistic_record.copy() for _ in range(100)]

        def process_batch():
            return [
                apply_mappings(r, embedding_config, row_num=i)
                for i, r in enumerate(records)
            ]

        benchmark(process_batch)

    def test_hex_mapping_100(self, benchmark, hex_config, realistic_record):
        """Benchmark hex tensor mapping with 100 records."""
        records = [realistic_record.copy() for _ in range(100)]

        def process_batch():
            return [
                apply_mappings(r, hex_config, row_num=i) for i, r in enumerate(records)
            ]

        benchmark(process_batch)

    def test_hex_mapping_1000(self, benchmark, hex_config, realistic_record):
        """Benchmark hex tensor mapping with 1000 records."""
        records = [realistic_record.copy() for _ in range(1000)]

        def process_batch():
            return [
                apply_mappings(r, hex_config, row_num=i) for i, r in enumerate(records)
            ]

        benchmark(process_batch)

    @pytest.mark.parametrize("batch_size", [100, 1000, 10000])
    def test_pipeline_throughput(
        self, benchmark, mixed_config, realistic_record, batch_size
    ):
        """Benchmark mixed config at different batch sizes."""
        records = [realistic_record.copy() for _ in range(batch_size)]

        def process_batch():
            return [
                apply_mappings(r, mixed_config, row_num=i)
                for i, r in enumerate(records)
            ]

        benchmark(process_batch)


# =============================================================================
# Converter comparison benchmarks
# =============================================================================


@pytest.mark.benchmark(group="comparison")
class TestConverterComparison:
    """Benchmarks comparing different encoding strategies for same data."""

    @pytest.fixture
    def embedding_768(self):
        """768-dimension embedding vector."""
        return [float(i) * 0.001 for i in range(768)]

    def test_tensor_vs_hex_float32(self, benchmark, embedding_768):
        """Compare tensor (list) vs hex float32 encoding."""
        from hf2vespa.converters import list_to_tensor

        benchmark(list_to_tensor, embedding_768)

    def test_hex_float32_768(self, benchmark, embedding_768):
        """Hex float32 encoding for 768-dim."""
        from hf2vespa.converters import list_to_tensor_float32_hex

        benchmark(list_to_tensor_float32_hex, embedding_768)

    def test_hex_bfloat16_768(self, benchmark, embedding_768):
        """Hex bfloat16 encoding for 768-dim."""
        from hf2vespa.converters import list_to_tensor_bfloat16_hex

        benchmark(list_to_tensor_bfloat16_hex, embedding_768)

    def test_hex_int8_768(self, benchmark):
        """Hex int8 encoding for 768-dim (quantized)."""
        from hf2vespa.converters import list_to_tensor_int8_hex

        data = [i % 256 - 128 for i in range(768)]
        benchmark(list_to_tensor_int8_hex, data)
