"""Real-world benchmarks using Cohere Wikipedia embeddings.

These benchmarks use actual embeddings from Cohere/wikipedia-2023-11-embed-multilingual-v3
to measure converter performance with production-like data.

Run with: pytest tests/benchmarks/test_realworld_benchmarks.py --benchmark-enable -v

Note: First run may be slower due to dataset download/caching.
Dataset: https://huggingface.co/datasets/Cohere/wikipedia-2023-11-embed-multilingual-v3
"""

import pytest

# Skip all tests in this module if datasets unavailable or download fails
pytestmark = pytest.mark.skipif(
    False,  # Will be set dynamically in fixtures
    reason="Cohere Wikipedia dataset not available",
)


@pytest.fixture(scope="module")
def cohere_embeddings():
    """Load sample embeddings from Cohere Wikipedia dataset.

    Uses streaming to avoid downloading the full 165GB dataset.
    Caches 1000 embeddings for benchmark reuse.
    """
    try:
        from datasets import load_dataset

        # Load streaming dataset (English subset, 1024-dim embeddings)
        dataset = load_dataset(
            "Cohere/wikipedia-2023-11-embed-multilingual-v3",
            "en",  # English subset
            split="train",
            streaming=True,
        )

        # Extract first 1000 embeddings for benchmarking
        embeddings = []
        for i, record in enumerate(dataset):
            if i >= 1000:
                break
            # Dataset has 'emb' field with 1024-dimensional embeddings
            embeddings.append(record["emb"])

        if len(embeddings) < 100:
            pytest.skip("Could not load enough embeddings from dataset")

        return embeddings

    except Exception as e:
        pytest.skip(f"Could not load Cohere dataset: {e}")


@pytest.fixture(scope="module")
def cohere_records():
    """Load sample records with metadata from Cohere Wikipedia dataset.

    Returns full records including title, text, and embeddings.
    """
    try:
        from datasets import load_dataset

        dataset = load_dataset(
            "Cohere/wikipedia-2023-11-embed-multilingual-v3",
            "en",
            split="train",
            streaming=True,
        )

        records = []
        for i, record in enumerate(dataset):
            if i >= 100:
                break
            records.append(
                {
                    "title": record.get("title", f"doc_{i}"),
                    "text": record.get("text", ""),
                    "embedding": record["emb"],
                    "url": record.get("url", ""),
                    "_id": record.get("_id", str(i)),
                }
            )

        if len(records) < 50:
            pytest.skip("Could not load enough records from dataset")

        return records

    except Exception as e:
        pytest.skip(f"Could not load Cohere dataset: {e}")


# =============================================================================
# Real-world hex encoding benchmarks
# =============================================================================


@pytest.mark.benchmark(group="realworld_hex")
class TestRealWorldHexEncoding:
    """Benchmarks for hex encoding with real Cohere embeddings (1024-dim)."""

    def test_float32_hex_cohere_single(self, benchmark, cohere_embeddings):
        """Benchmark float32 hex encoding for single Cohere embedding."""
        from hf2vespa.converters import list_to_tensor_float32_hex

        embedding = cohere_embeddings[0]
        result = benchmark(list_to_tensor_float32_hex, embedding)

        # Verify output size: 1024 * 8 = 8192 hex chars
        assert len(result["values"]) == 8192

    def test_bfloat16_hex_cohere_single(self, benchmark, cohere_embeddings):
        """Benchmark bfloat16 hex encoding for single Cohere embedding."""
        from hf2vespa.converters import list_to_tensor_bfloat16_hex

        embedding = cohere_embeddings[0]
        result = benchmark(list_to_tensor_bfloat16_hex, embedding)

        # Verify output size: 1024 * 4 = 4096 hex chars
        assert len(result["values"]) == 4096

    def test_float32_hex_cohere_batch_100(self, benchmark, cohere_embeddings):
        """Benchmark float32 hex encoding for 100 Cohere embeddings."""
        from hf2vespa.converters import list_to_tensor_float32_hex

        embeddings = cohere_embeddings[:100]

        def encode_batch():
            return [list_to_tensor_float32_hex(e) for e in embeddings]

        results = benchmark(encode_batch)
        assert len(results) == 100

    def test_bfloat16_hex_cohere_batch_100(self, benchmark, cohere_embeddings):
        """Benchmark bfloat16 hex encoding for 100 Cohere embeddings."""
        from hf2vespa.converters import list_to_tensor_bfloat16_hex

        embeddings = cohere_embeddings[:100]

        def encode_batch():
            return [list_to_tensor_bfloat16_hex(e) for e in embeddings]

        results = benchmark(encode_batch)
        assert len(results) == 100


# =============================================================================
# Real-world pipeline benchmarks
# =============================================================================


@pytest.mark.benchmark(group="realworld_pipeline")
class TestRealWorldPipeline:
    """Benchmarks for full pipeline with real Cohere records."""

    def test_pipeline_cohere_records_hex(self, benchmark, cohere_records):
        """Benchmark full pipeline with hex encoding for Cohere records."""
        from hf2vespa.pipeline import apply_mappings
        from hf2vespa.config import FieldMapping

        config = [
            FieldMapping(
                source="embedding", target="embedding", type="tensor_float32_hex"
            ),
            FieldMapping(source="title", target="title", type="string"),
            FieldMapping(source="_id", target="doc_id", type="string"),
        ]

        def process_batch():
            return [
                apply_mappings(r, config, row_num=i)
                for i, r in enumerate(cohere_records)
            ]

        results = benchmark(process_batch)
        assert len(results) == len(cohere_records)

    def test_pipeline_cohere_records_tensor(self, benchmark, cohere_records):
        """Benchmark full pipeline with tensor (no hex) for Cohere records."""
        from hf2vespa.pipeline import apply_mappings
        from hf2vespa.config import FieldMapping

        config = [
            FieldMapping(source="embedding", target="embedding", type="tensor"),
            FieldMapping(source="title", target="title", type="string"),
            FieldMapping(source="_id", target="doc_id", type="string"),
        ]

        def process_batch():
            return [
                apply_mappings(r, config, row_num=i)
                for i, r in enumerate(cohere_records)
            ]

        results = benchmark(process_batch)
        assert len(results) == len(cohere_records)


# =============================================================================
# Hex encoding comparison with real data
# =============================================================================


@pytest.mark.benchmark(group="realworld_comparison")
class TestRealWorldComparison:
    """Compare different hex encoding strategies with real embeddings."""

    def test_float32_vs_bfloat16_size(self, cohere_embeddings):
        """Compare output sizes for float32 vs bfloat16 encoding."""
        from hf2vespa.converters import (
            list_to_tensor_float32_hex,
            list_to_tensor_bfloat16_hex,
        )

        embedding = cohere_embeddings[0]

        f32_result = list_to_tensor_float32_hex(embedding)
        bf16_result = list_to_tensor_bfloat16_hex(embedding)

        # bfloat16 should be half the size
        assert len(bf16_result["values"]) == len(f32_result["values"]) // 2

        # Both should work for 1024-dim embeddings
        assert len(f32_result["values"]) == 1024 * 8  # 8 hex chars per float32
        assert len(bf16_result["values"]) == 1024 * 4  # 4 hex chars per bfloat16

    def test_encoding_throughput_comparison(self, benchmark, cohere_embeddings):
        """Benchmark to establish baseline throughput with real data."""
        from hf2vespa.converters import list_to_tensor_float32_hex

        # Use 500 embeddings for throughput measurement
        embeddings = cohere_embeddings[:500]

        def encode_all():
            return [list_to_tensor_float32_hex(e) for e in embeddings]

        benchmark(encode_all)
