"""Static test fixtures from Vespa documentation.

All expected values are hardcoded from official Vespa documentation.
Source: https://docs.vespa.ai/en/reference/schemas/document-json-format.html
"""

# Int8 hex encoding examples
# tensor<int8>(x[6]):[-1,0,17,-128,34,-2] -> "FF00118022FE"
VESPA_INT8_HEX_EXAMPLES = [
    {"input": [-1, 0, 17, -128, 34, -2], "expected": "ff00118022fe"},
    {"input": [0], "expected": "00"},
    {"input": [127], "expected": "7f"},
    {"input": [-128], "expected": "80"},
]

# IEEE 754 float32 known values (verified with struct.pack)
IEEE754_FLOAT32_EXAMPLES = [
    {"input": [1.0], "expected": "3f800000"},
    {"input": [2.0], "expected": "40000000"},
    {"input": [-1.0], "expected": "bf800000"},
    {"input": [0.0], "expected": "00000000"},
    {"input": [1.0, 2.0], "expected": "3f80000040000000"},
]

# IEEE 754 float64 known values
IEEE754_FLOAT64_EXAMPLES = [
    {"input": [1.0], "expected": "3ff0000000000000"},
    {"input": [2.0], "expected": "4000000000000000"},
    {"input": [-1.0], "expected": "bff0000000000000"},
    {"input": [3.141592653589793], "expected": "400921fb54442d18"},  # pi
]

# Bfloat16 examples (upper 2 bytes of float32)
BFLOAT16_EXAMPLES = [
    {"input": [1.0], "expected": "3f80"},
    {"input": [-1.0], "expected": "bf80"},
    {"input": [0.0], "expected": "0000"},
    {"input": [2.0], "expected": "4000"},
    {"input": [1.0, -1.0], "expected": "3f80bf80"},
]

# Boundary values for int8
INT8_BOUNDARY_VALUES = {
    "min": -128,
    "max": 127,
    "zero": 0,
    "positive_one": 1,
    "negative_one": -1,
}

# Special float values
FLOAT_SPECIAL_VALUES = [
    float("inf"),
    float("-inf"),
    0.0,
    -0.0,
]
