# Smoke test to verify package installs and imports correctly
import hf2vespa

print(f"hf2vespa version: {hf2vespa.__version__}")

# Verify core modules are importable
from hf2vespa import cli, pipeline, config

print("All core modules imported successfully")
