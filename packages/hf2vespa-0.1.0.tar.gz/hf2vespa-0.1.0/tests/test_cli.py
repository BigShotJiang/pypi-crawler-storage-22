"""Tests for CLI commands."""

import subprocess
import sys

import pytest
from typer.testing import CliRunner
from hf2vespa.cli import app


@pytest.fixture
def runner():
    """Provide a Typer CLI test runner."""
    return CliRunner()


def test_feed_num_workers_flag(runner):
    """Verify --num-workers flag is accepted."""
    result = runner.invoke(
        app,
        [
            "feed",
            "glue",
            "--config",
            "ax",
            "--split",
            "test",
            "--limit",
            "1",
            "--num-workers",
            "2",
        ],
    )
    # Should complete without error (flag is accepted)
    assert result.exit_code == 0


def test_feed_num_workers_invalid_zero(runner):
    """Verify --num-workers rejects zero."""
    result = runner.invoke(
        app, ["feed", "glue", "--config", "ax", "--split", "test", "--num-workers", "0"]
    )
    assert result.exit_code == 1
    assert "positive" in result.output.lower() or "positive" in result.stderr.lower()


def test_feed_does_not_hang_on_exit():
    """Test that feed command exits cleanly without hanging.

    This tests the fix for the issue where HuggingFace HTTP cleanup
    caused "Bad file descriptor" errors and process hangs.
    """
    import os

    # Ensure HF_HUB_OFFLINE is not set (can leak from other tests via cleanup function)
    env = os.environ.copy()
    env.pop("HF_HUB_OFFLINE", None)

    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "hf2vespa",
            "feed",
            "glue",
            "--config",
            "ax",
            "--split",
            "test",
            "--limit",
            "10",
        ],
        capture_output=True,
        text=True,
        timeout=60,  # Should complete well under this
        env=env,
    )
    # Check it completed successfully
    assert result.returncode == 0
    # Check completion stats were printed
    assert "Completion Statistics" in result.stderr
    # Check no error messages in stderr (only progress bar and completion stats)
    assert "Errno" not in result.stderr, f"Error in stderr: {result.stderr}"
    assert "Bad file descriptor" not in result.stderr, (
        f"Error in stderr: {result.stderr}"
    )
    assert "Retrying" not in result.stderr, f"Retry message in stderr: {result.stderr}"
    assert "resource_tracker" not in result.stderr, (
        f"Resource tracker warning in stderr: {result.stderr}"
    )
