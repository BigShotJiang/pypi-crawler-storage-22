"""Tests for type converter registry."""

import pytest

from tests.fixtures.vespa_doc_examples import (
    VESPA_INT8_HEX_EXAMPLES,
    IEEE754_FLOAT32_EXAMPLES,
    IEEE754_FLOAT64_EXAMPLES,
    BFLOAT16_EXAMPLES,
    INT8_BOUNDARY_VALUES,
)


def test_converter_lookup_is_cached():
    """Verify converter function lookups are cached."""
    from hf2vespa.converters import ConverterRegistry

    registry = ConverterRegistry()
    registry.register("test_cached", str)  # Unique name to avoid collision

    # Get baseline cache state
    initial = registry.cache_info()
    initial_misses = initial.misses
    initial_hits = initial.hits

    # First lookup - cache miss
    registry.convert(1, "test_cached")
    info = registry.cache_info()
    assert info.misses == initial_misses + 1

    # Second lookup - cache hit
    registry.convert(2, "test_cached")
    info = registry.cache_info()
    assert info.hits == initial_hits + 1

    # Third lookup - another cache hit
    registry.convert(3, "test_cached")
    info = registry.cache_info()
    assert info.hits == initial_hits + 2


def test_cache_info_available():
    """Verify cache_info() method is available and returns valid data."""
    from hf2vespa.converters import converters

    info = converters.cache_info()
    # CacheInfo has these attributes
    assert hasattr(info, "hits")
    assert hasattr(info, "misses")
    assert hasattr(info, "maxsize")
    assert hasattr(info, "currsize")
    assert info.maxsize == 16  # Our configured maxsize


def test_module_converters_cache_is_shared():
    """Verify the module-level converters instance maintains cache across calls."""
    from hf2vespa.converters import converters

    # Get initial cache state
    initial = converters.cache_info()
    initial_total = initial.hits + initial.misses

    # Make some calls
    converters.convert([1.0, 2.0], "tensor")
    converters.convert("test", "string")

    # Cache should have grown
    after = converters.cache_info()
    after_total = after.hits + after.misses
    assert after_total >= initial_total


# =============================================================================
# Position converter tests
# =============================================================================


def test_position_basic():
    """Valid lat/lng dict returns correct Vespa position format."""
    from hf2vespa.converters import dict_to_position

    result = dict_to_position({"lat": 37.4, "lng": -122.0})
    assert result == {"lat": 37.4, "lng": -122.0}


def test_position_integers():
    """Integer coordinates are converted to floats."""
    from hf2vespa.converters import dict_to_position

    result = dict_to_position({"lat": 45, "lng": -90})
    assert result == {"lat": 45.0, "lng": -90.0}
    assert isinstance(result["lat"], float)
    assert isinstance(result["lng"], float)


def test_position_boundary():
    """Edge case coordinates at boundaries are accepted."""
    from hf2vespa.converters import dict_to_position

    # Max latitude
    result = dict_to_position({"lat": 90, "lng": 0})
    assert result == {"lat": 90.0, "lng": 0.0}

    # Min latitude
    result = dict_to_position({"lat": -90, "lng": 0})
    assert result == {"lat": -90.0, "lng": 0.0}

    # Max longitude
    result = dict_to_position({"lat": 0, "lng": 180})
    assert result == {"lat": 0.0, "lng": 180.0}

    # Min longitude
    result = dict_to_position({"lat": 0, "lng": -180})
    assert result == {"lat": 0.0, "lng": -180.0}


def test_position_invalid_type():
    """Non-dict input raises ValueError."""
    from hf2vespa.converters import dict_to_position

    with pytest.raises(ValueError, match="Expected dict for position"):
        dict_to_position([37.4, -122.0])

    with pytest.raises(ValueError, match="Expected dict for position"):
        dict_to_position("37.4,-122.0")


def test_position_missing_keys():
    """Missing lat or lng key raises ValueError."""
    from hf2vespa.converters import dict_to_position

    with pytest.raises(ValueError, match="must contain 'lat' key"):
        dict_to_position({"lng": -122.0})

    with pytest.raises(ValueError, match="must contain 'lng' key"):
        dict_to_position({"lat": 37.4})


def test_position_non_numeric():
    """String lat/lng values raise ValueError."""
    from hf2vespa.converters import dict_to_position

    with pytest.raises(ValueError, match="Latitude must be numeric"):
        dict_to_position({"lat": "37.4", "lng": -122.0})

    with pytest.raises(ValueError, match="Longitude must be numeric"):
        dict_to_position({"lat": 37.4, "lng": "-122.0"})


def test_position_out_of_range_lat():
    """Latitude outside -90 to 90 raises ValueError."""
    from hf2vespa.converters import dict_to_position

    with pytest.raises(ValueError, match="Latitude must be between -90 and 90"):
        dict_to_position({"lat": 91, "lng": 0})

    with pytest.raises(ValueError, match="Latitude must be between -90 and 90"):
        dict_to_position({"lat": -91, "lng": 0})


def test_position_out_of_range_lng():
    """Longitude outside -180 to 180 raises ValueError."""
    from hf2vespa.converters import dict_to_position

    with pytest.raises(ValueError, match="Longitude must be between -180 and 180"):
        dict_to_position({"lat": 0, "lng": 181})

    with pytest.raises(ValueError, match="Longitude must be between -180 and 180"):
        dict_to_position({"lat": 0, "lng": -181})


# =============================================================================
# Weighted set converter tests
# =============================================================================


def test_weightedset_basic():
    """Valid dict returns with int weights."""
    from hf2vespa.converters import dict_to_weightedset

    result = dict_to_weightedset({"tag1": 10, "tag2": 5})
    assert result == {"tag1": 10, "tag2": 5}


def test_weightedset_string_keys():
    """String keys remain as strings."""
    from hf2vespa.converters import dict_to_weightedset

    result = dict_to_weightedset({"alpha": 1, "beta": 2})
    assert result == {"alpha": 1, "beta": 2}
    assert all(isinstance(k, str) for k in result.keys())


def test_weightedset_int_keys():
    """Integer keys are converted to strings."""
    from hf2vespa.converters import dict_to_weightedset

    result = dict_to_weightedset({1: 100, 2: 50})
    assert result == {"1": 100, "2": 50}
    assert "1" in result
    assert "2" in result


def test_weightedset_float_weights():
    """Float weights are truncated to int."""
    from hf2vespa.converters import dict_to_weightedset

    result = dict_to_weightedset({"a": 10.9, "b": 5.1})
    assert result == {"a": 10, "b": 5}
    assert isinstance(result["a"], int)
    assert isinstance(result["b"], int)


def test_weightedset_empty():
    """Empty dict returns empty dict."""
    from hf2vespa.converters import dict_to_weightedset

    result = dict_to_weightedset({})
    assert result == {}


def test_weightedset_invalid_type():
    """Non-dict input raises ValueError."""
    from hf2vespa.converters import dict_to_weightedset

    with pytest.raises(ValueError, match="Expected dict for weightedset"):
        dict_to_weightedset([("a", 1), ("b", 2)])

    with pytest.raises(ValueError, match="Expected dict for weightedset"):
        dict_to_weightedset("a:1,b:2")


def test_weightedset_non_numeric_weight():
    """Non-numeric weight raises ValueError."""
    from hf2vespa.converters import dict_to_weightedset

    with pytest.raises(ValueError, match="Weight for key 'tag' must be numeric"):
        dict_to_weightedset({"tag": "high"})


# =============================================================================
# Map converter tests
# =============================================================================


def test_map_basic():
    """Valid dict returns with stringified keys."""
    from hf2vespa.converters import dict_to_map

    result = dict_to_map({"key": "value", "foo": "bar"})
    assert result == {"key": "value", "foo": "bar"}


def test_map_int_keys():
    """Integer keys are converted to strings."""
    from hf2vespa.converters import dict_to_map

    result = dict_to_map({1: "one", 2: "two"})
    assert result == {"1": "one", "2": "two"}
    assert "1" in result
    assert "2" in result


def test_map_nested_values():
    """Nested dicts are preserved as values."""
    from hf2vespa.converters import dict_to_map

    result = dict_to_map({"nested": {"inner": "value"}, "list": [1, 2, 3]})
    assert result == {"nested": {"inner": "value"}, "list": [1, 2, 3]}


def test_map_empty():
    """Empty dict returns empty dict."""
    from hf2vespa.converters import dict_to_map

    result = dict_to_map({})
    assert result == {}


def test_map_invalid_type():
    """Non-dict input raises ValueError."""
    from hf2vespa.converters import dict_to_map

    with pytest.raises(ValueError, match="Expected dict for map"):
        dict_to_map([("a", 1), ("b", 2)])

    with pytest.raises(ValueError, match="Expected dict for map"):
        dict_to_map("key=value")


# =============================================================================
# Int8 hex tensor converter tests
# =============================================================================


def test_int8_hex_basic():
    """Basic int8 list converts to hex with 2 chars per value."""
    from hf2vespa.converters import list_to_tensor_int8_hex

    result = list_to_tensor_int8_hex([11, 34, 3, -124, 5, -1])
    assert result == {"values": "0b22038405ff"}


def test_int8_hex_boundaries():
    """Edge values 0, 127, -128 encode correctly."""
    from hf2vespa.converters import list_to_tensor_int8_hex

    result = list_to_tensor_int8_hex([0, 127, -128])
    assert result == {"values": "007f80"}


def test_int8_hex_single_value():
    """Single value list works."""
    from hf2vespa.converters import list_to_tensor_int8_hex

    result = list_to_tensor_int8_hex([42])
    assert result == {"values": "2a"}


def test_int8_hex_negative():
    """Negative values encode as two's complement."""
    from hf2vespa.converters import list_to_tensor_int8_hex

    result = list_to_tensor_int8_hex([-1])
    assert result == {"values": "ff"}

    result = list_to_tensor_int8_hex([-128])
    assert result == {"values": "80"}


def test_int8_hex_range_error_positive():
    """Value 128 raises ValueError with index info."""
    from hf2vespa.converters import list_to_tensor_int8_hex

    with pytest.raises(ValueError, match="Value 128 at index 0 outside int8 range"):
        list_to_tensor_int8_hex([128])


def test_int8_hex_range_error_negative():
    """Value -129 raises ValueError with index info."""
    from hf2vespa.converters import list_to_tensor_int8_hex

    with pytest.raises(ValueError, match="Value -129 at index 0 outside int8 range"):
        list_to_tensor_int8_hex([-129])


def test_int8_hex_range_error_with_row():
    """Out-of-range with row_num includes row in error message."""
    from hf2vespa.converters import list_to_tensor_int8_hex

    with pytest.raises(ValueError, match=r"index 0 \(row 5\) outside int8 range"):
        list_to_tensor_int8_hex([128], row_num=5)


def test_int8_hex_range_error_mid_list():
    """Error at index 2 reports correct index."""
    from hf2vespa.converters import list_to_tensor_int8_hex

    with pytest.raises(ValueError, match="Value 200 at index 2 outside int8 range"):
        list_to_tensor_int8_hex([1, 2, 200, 4])


def test_int8_hex_empty_list():
    """Empty list raises ValueError."""
    from hf2vespa.converters import list_to_tensor_int8_hex

    with pytest.raises(ValueError, match="Cannot convert empty list to tensor"):
        list_to_tensor_int8_hex([])


def test_int8_hex_invalid_type():
    """Non-list input raises ValueError."""
    from hf2vespa.converters import list_to_tensor_int8_hex

    with pytest.raises(ValueError, match="Expected list for tensor conversion"):
        list_to_tensor_int8_hex("not a list")

    with pytest.raises(ValueError, match="Expected list for tensor conversion"):
        list_to_tensor_int8_hex(42)


# =============================================================================
# Bfloat16 hex tensor converter tests
# =============================================================================


def test_bfloat16_hex_basic():
    """Basic float list converts to hex with 4 chars per value."""
    from hf2vespa.converters import list_to_tensor_bfloat16_hex

    result = list_to_tensor_bfloat16_hex([1.0, -1.0, 0.0])
    assert result == {"values": "3f80bf800000"}


def test_bfloat16_hex_truncation():
    """Float precision is truncated to bfloat16 (upper 2 bytes of float32)."""
    from hf2vespa.converters import list_to_tensor_bfloat16_hex

    # 3.14159 as float32 is 0x40490fdb, bfloat16 truncates to 0x4049
    result = list_to_tensor_bfloat16_hex([3.14159])
    assert result == {"values": "4049"}


def test_bfloat16_hex_single_value():
    """Single value list works."""
    from hf2vespa.converters import list_to_tensor_bfloat16_hex

    result = list_to_tensor_bfloat16_hex([1.0])
    assert result == {"values": "3f80"}


def test_bfloat16_hex_integers():
    """Integer inputs are converted to floats."""
    from hf2vespa.converters import list_to_tensor_bfloat16_hex

    # 2 as float32 is 0x40000000, bfloat16 is 0x4000
    result = list_to_tensor_bfloat16_hex([2])
    assert result == {"values": "4000"}


def test_bfloat16_hex_special_values():
    """Special float values encode correctly."""
    from hf2vespa.converters import list_to_tensor_bfloat16_hex

    # 0.0 -> 0x00000000 -> 0x0000
    result = list_to_tensor_bfloat16_hex([0.0])
    assert result == {"values": "0000"}


def test_bfloat16_hex_empty_list():
    """Empty list raises ValueError."""
    from hf2vespa.converters import list_to_tensor_bfloat16_hex

    with pytest.raises(ValueError, match="Cannot convert empty list to tensor"):
        list_to_tensor_bfloat16_hex([])


def test_bfloat16_hex_invalid_type():
    """Non-list input raises ValueError."""
    from hf2vespa.converters import list_to_tensor_bfloat16_hex

    with pytest.raises(ValueError, match="Expected list for tensor conversion"):
        list_to_tensor_bfloat16_hex("not a list")

    with pytest.raises(ValueError, match="Expected list for tensor conversion"):
        list_to_tensor_bfloat16_hex(42.0)


# =============================================================================
# Float32 hex tensor converter tests
# =============================================================================


def test_float32_hex_basic():
    """Basic float list converts to hex with 8 chars per value."""
    from hf2vespa.converters import list_to_tensor_float32_hex

    # [1.0, 2.0, 3.0] -> 3f800000 40000000 40400000
    result = list_to_tensor_float32_hex([1.0, 2.0, 3.0])
    assert result == {"values": "3f8000004000000040400000"}


def test_float32_hex_known_ieee754():
    """Known IEEE 754 values encode correctly."""
    from hf2vespa.converters import list_to_tensor_float32_hex

    # 3.14159 as float32 is 0x40490fdb (approximately)
    result = list_to_tensor_float32_hex([3.14159])
    # Allow slight variation due to float precision
    assert result["values"].startswith("40490f")


def test_float32_hex_single_value():
    """Single value list works."""
    from hf2vespa.converters import list_to_tensor_float32_hex

    result = list_to_tensor_float32_hex([1.0])
    assert result == {"values": "3f800000"}


def test_float32_hex_negative():
    """Negative values encode correctly."""
    from hf2vespa.converters import list_to_tensor_float32_hex

    # -1.0 as float32 is 0xbf800000
    result = list_to_tensor_float32_hex([-1.0])
    assert result == {"values": "bf800000"}


def test_float32_hex_integers():
    """Integer inputs are converted to floats."""
    from hf2vespa.converters import list_to_tensor_float32_hex

    result = list_to_tensor_float32_hex([2])
    assert result == {"values": "40000000"}


def test_float32_hex_empty_list():
    """Empty list raises ValueError."""
    from hf2vespa.converters import list_to_tensor_float32_hex

    with pytest.raises(ValueError, match="Cannot convert empty list to tensor"):
        list_to_tensor_float32_hex([])


def test_float32_hex_invalid_type():
    """Non-list input raises ValueError."""
    from hf2vespa.converters import list_to_tensor_float32_hex

    with pytest.raises(ValueError, match="Expected list for tensor conversion"):
        list_to_tensor_float32_hex("not a list")

    with pytest.raises(ValueError, match="Expected list for tensor conversion"):
        list_to_tensor_float32_hex(42.0)


# =============================================================================
# Float64 hex tensor converter tests
# =============================================================================


def test_float64_hex_basic():
    """Basic float list converts to hex with 16 chars per value."""
    from hf2vespa.converters import list_to_tensor_float64_hex

    # [1.0, 2.0] -> 3ff0000000000000 4000000000000000
    result = list_to_tensor_float64_hex([1.0, 2.0])
    assert result == {"values": "3ff00000000000004000000000000000"}


def test_float64_hex_known_ieee754():
    """Known IEEE 754 double precision values encode correctly."""
    from hf2vespa.converters import list_to_tensor_float64_hex

    # 3.141592653589793 as float64 is 0x400921fb54442d18
    result = list_to_tensor_float64_hex([3.141592653589793])
    assert result == {"values": "400921fb54442d18"}


def test_float64_hex_single_value():
    """Single value list works."""
    from hf2vespa.converters import list_to_tensor_float64_hex

    result = list_to_tensor_float64_hex([1.0])
    assert result == {"values": "3ff0000000000000"}


def test_float64_hex_negative():
    """Negative values encode correctly."""
    from hf2vespa.converters import list_to_tensor_float64_hex

    # -1.0 as float64 is 0xbff0000000000000
    result = list_to_tensor_float64_hex([-1.0])
    assert result == {"values": "bff0000000000000"}


def test_float64_hex_integers():
    """Integer inputs are converted to floats."""
    from hf2vespa.converters import list_to_tensor_float64_hex

    result = list_to_tensor_float64_hex([2])
    assert result == {"values": "4000000000000000"}


def test_float64_hex_precision():
    """Float64 preserves more precision than float32."""
    from hf2vespa.converters import list_to_tensor_float64_hex

    # A number that would lose precision in float32
    result = list_to_tensor_float64_hex([1.0000001])
    # This should encode differently than 1.0
    assert result != {"values": "3ff0000000000000"}


def test_float64_hex_empty_list():
    """Empty list raises ValueError."""
    from hf2vespa.converters import list_to_tensor_float64_hex

    with pytest.raises(ValueError, match="Cannot convert empty list to tensor"):
        list_to_tensor_float64_hex([])


def test_float64_hex_invalid_type():
    """Non-list input raises ValueError."""
    from hf2vespa.converters import list_to_tensor_float64_hex

    with pytest.raises(ValueError, match="Expected list for tensor conversion"):
        list_to_tensor_float64_hex("not a list")

    with pytest.raises(ValueError, match="Expected list for tensor conversion"):
        list_to_tensor_float64_hex(42.0)


# =============================================================================
# Config validation tests for hex tensor types
# =============================================================================


def test_config_accepts_tensor_int8_hex():
    """Config validates tensor_int8_hex as valid type."""
    from hf2vespa.config import FieldMapping

    m = FieldMapping(source="vec", target="vec", type="tensor_int8_hex")
    assert m.type == "tensor_int8_hex"


def test_config_accepts_tensor_bfloat16_hex():
    """Config validates tensor_bfloat16_hex as valid type."""
    from hf2vespa.config import FieldMapping

    m = FieldMapping(source="vec", target="vec", type="tensor_bfloat16_hex")
    assert m.type == "tensor_bfloat16_hex"


def test_config_accepts_tensor_float32_hex():
    """Config validates tensor_float32_hex as valid type."""
    from hf2vespa.config import FieldMapping

    m = FieldMapping(source="vec", target="vec", type="tensor_float32_hex")
    assert m.type == "tensor_float32_hex"


def test_config_accepts_tensor_float64_hex():
    """Config validates tensor_float64_hex as valid type."""
    from hf2vespa.config import FieldMapping

    m = FieldMapping(source="vec", target="vec", type="tensor_float64_hex")
    assert m.type == "tensor_float64_hex"


def test_config_rejects_invalid_hex_type():
    """Config rejects invalid tensor hex type names."""
    from hf2vespa.config import FieldMapping

    with pytest.raises(ValueError, match="Unknown type converter"):
        FieldMapping(source="vec", target="vec", type="tensor_int16_hex")


# =============================================================================
# Sparse tensor converter tests
# =============================================================================


def test_sparse_tensor_basic():
    """Valid dict returns cells format."""
    from hf2vespa.converters import dict_to_sparse_tensor

    result = dict_to_sparse_tensor({"word1": 0.5, "word2": 0.3})
    assert result == {
        "cells": [
            {"address": {"key": "word1"}, "value": 0.5},
            {"address": {"key": "word2"}, "value": 0.3},
        ]
    }


def test_sparse_tensor_single_key():
    """Single key dict works."""
    from hf2vespa.converters import dict_to_sparse_tensor

    result = dict_to_sparse_tensor({"only": 1.0})
    assert result == {"cells": [{"address": {"key": "only"}, "value": 1.0}]}


def test_sparse_tensor_integer_values():
    """Integer values converted to float."""
    from hf2vespa.converters import dict_to_sparse_tensor

    result = dict_to_sparse_tensor({"a": 1, "b": 2})
    assert result == {
        "cells": [
            {"address": {"key": "a"}, "value": 1.0},
            {"address": {"key": "b"}, "value": 2.0},
        ]
    }
    # Verify values are floats
    assert isinstance(result["cells"][0]["value"], float)
    assert isinstance(result["cells"][1]["value"], float)


def test_sparse_tensor_integer_keys():
    """Integer keys converted to strings."""
    from hf2vespa.converters import dict_to_sparse_tensor

    result = dict_to_sparse_tensor({1: 0.5, 2: 0.3})
    assert result == {
        "cells": [
            {"address": {"key": "1"}, "value": 0.5},
            {"address": {"key": "2"}, "value": 0.3},
        ]
    }
    # Verify keys are strings
    assert result["cells"][0]["address"]["key"] == "1"
    assert result["cells"][1]["address"]["key"] == "2"


def test_sparse_tensor_empty_dict():
    """Empty dict raises ValueError."""
    from hf2vespa.converters import dict_to_sparse_tensor

    with pytest.raises(ValueError, match="empty dict"):
        dict_to_sparse_tensor({})


def test_sparse_tensor_invalid_type():
    """Non-dict raises ValueError."""
    from hf2vespa.converters import dict_to_sparse_tensor

    with pytest.raises(ValueError, match="Expected dict"):
        dict_to_sparse_tensor([("a", 1)])

    with pytest.raises(ValueError, match="Expected dict"):
        dict_to_sparse_tensor("a:1")


def test_sparse_tensor_non_numeric_value():
    """Non-numeric value raises ValueError."""
    from hf2vespa.converters import dict_to_sparse_tensor

    with pytest.raises(ValueError, match="Value for key 'a' must be numeric"):
        dict_to_sparse_tensor({"a": "high"})


def test_sparse_tensor_non_numeric_with_row():
    """Error includes row context."""
    from hf2vespa.converters import dict_to_sparse_tensor

    with pytest.raises(ValueError, match=r"key 'a' \(row 5\) must be numeric"):
        dict_to_sparse_tensor({"a": "bad"}, row_num=5)


def test_sparse_tensor_list_value_rejected():
    """List value raises with hint."""
    from hf2vespa.converters import dict_to_sparse_tensor

    with pytest.raises(ValueError, match="Value for key 'a' must be numeric"):
        dict_to_sparse_tensor({"a": [1.0, 2.0]})


def test_config_accepts_sparse_tensor():
    """Config validates sparse_tensor type."""
    from hf2vespa.config import FieldMapping

    m = FieldMapping(source="terms", target="term_weights", type="sparse_tensor")
    assert m.type == "sparse_tensor"


# =============================================================================
# Mixed tensor converter tests (non-hex)
# =============================================================================


def test_mixed_tensor_basic():
    """Valid nested dict returns blocks format."""
    from hf2vespa.converters import dict_to_mixed_tensor

    result = dict_to_mixed_tensor({"word1": [1.0, 2.0, 3.0], "word2": [4.0, 5.0, 6.0]})
    assert result == {"blocks": {"word1": [1.0, 2.0, 3.0], "word2": [4.0, 5.0, 6.0]}}


def test_mixed_tensor_single_block():
    """Single key works."""
    from hf2vespa.converters import dict_to_mixed_tensor

    result = dict_to_mixed_tensor({"only": [1.0, 2.0]})
    assert result == {"blocks": {"only": [1.0, 2.0]}}


def test_mixed_tensor_integer_keys():
    """Integer keys converted to strings."""
    from hf2vespa.converters import dict_to_mixed_tensor

    result = dict_to_mixed_tensor({1: [1.0, 2.0], 2: [3.0, 4.0]})
    assert result == {"blocks": {"1": [1.0, 2.0], "2": [3.0, 4.0]}}
    assert "1" in result["blocks"]
    assert "2" in result["blocks"]


def test_mixed_tensor_empty_dict():
    """Empty dict raises ValueError."""
    from hf2vespa.converters import dict_to_mixed_tensor

    with pytest.raises(ValueError, match="empty dict"):
        dict_to_mixed_tensor({})


def test_mixed_tensor_invalid_type():
    """Non-dict raises ValueError."""
    from hf2vespa.converters import dict_to_mixed_tensor

    with pytest.raises(ValueError, match="Expected dict"):
        dict_to_mixed_tensor([[1, 2], [3, 4]])


def test_mixed_tensor_non_list_value():
    """Non-list value raises ValueError."""
    from hf2vespa.converters import dict_to_mixed_tensor

    with pytest.raises(ValueError, match="must be list"):
        dict_to_mixed_tensor({"a": 1.0, "b": 2.0})


def test_mixed_tensor_empty_list_value():
    """Empty list raises ValueError."""
    from hf2vespa.converters import dict_to_mixed_tensor

    with pytest.raises(ValueError, match="cannot be empty list"):
        dict_to_mixed_tensor({"a": [], "b": [1.0]})


def test_mixed_tensor_dimension_mismatch():
    """Inconsistent shapes raise ValueError."""
    from hf2vespa.converters import dict_to_mixed_tensor

    with pytest.raises(ValueError, match="dimension mismatch"):
        dict_to_mixed_tensor({"a": [1, 2, 3], "b": [4, 5]})

    # Verify error message includes both keys and shapes
    try:
        dict_to_mixed_tensor({"a": [1, 2, 3], "b": [4, 5]})
    except ValueError as e:
        assert "a" in str(e)
        assert "b" in str(e)
        assert "[3]" in str(e)
        assert "[2]" in str(e)


def test_mixed_tensor_dimension_mismatch_with_row():
    """Error includes row context."""
    from hf2vespa.converters import dict_to_mixed_tensor

    with pytest.raises(ValueError, match=r"row 7"):
        dict_to_mixed_tensor({"a": [1, 2], "b": [3, 4, 5]}, row_num=7)


def test_mixed_tensor_non_numeric_value():
    """Non-numeric in list raises ValueError."""
    from hf2vespa.converters import dict_to_mixed_tensor

    with pytest.raises(ValueError, match="must be numeric"):
        dict_to_mixed_tensor({"a": [1.0, "bad", 3.0]})

    # Verify error includes key and index info
    try:
        dict_to_mixed_tensor({"a": [1.0, "bad", 3.0]})
    except ValueError as e:
        assert "a" in str(e)
        assert "index 1" in str(e)


# =============================================================================
# Mixed tensor hex converter tests
# =============================================================================


def test_mixed_tensor_hex_int8():
    """int8 cell type works."""
    from hf2vespa.converters import dict_to_mixed_tensor_hex

    result = dict_to_mixed_tensor_hex(
        {"w1": [11, 34, 3], "w2": [-124, 5, -1]}, cell_type="int8"
    )
    assert result == {"blocks": {"w1": "0b2203", "w2": "8405ff"}}


def test_mixed_tensor_hex_float32():
    """float32 cell type works."""
    from hf2vespa.converters import dict_to_mixed_tensor_hex

    result = dict_to_mixed_tensor_hex({"a": [1.0], "b": [2.0]}, cell_type="float32")
    assert "blocks" in result
    assert result["blocks"]["a"] == "3f800000"  # 1.0 as float32
    assert result["blocks"]["b"] == "40000000"  # 2.0 as float32
    # Verify 8 hex chars per value
    assert len(result["blocks"]["a"]) == 8
    assert len(result["blocks"]["b"]) == 8


def test_mixed_tensor_hex_default_float32():
    """Default cell_type is float32."""
    from hf2vespa.converters import dict_to_mixed_tensor_hex

    result = dict_to_mixed_tensor_hex({"a": [1.0]})
    assert result["blocks"]["a"] == "3f800000"  # float32 encoding


def test_mixed_tensor_hex_bfloat16():
    """bfloat16 cell type works."""
    from hf2vespa.converters import dict_to_mixed_tensor_hex

    result = dict_to_mixed_tensor_hex({"a": [1.0]}, cell_type="bfloat16")
    assert result["blocks"]["a"] == "3f80"
    # Verify 4 hex chars per value
    assert len(result["blocks"]["a"]) == 4


def test_mixed_tensor_hex_float64():
    """float64 cell type works."""
    from hf2vespa.converters import dict_to_mixed_tensor_hex

    result = dict_to_mixed_tensor_hex({"a": [1.0]}, cell_type="float64")
    assert result["blocks"]["a"] == "3ff0000000000000"
    # Verify 16 hex chars per value
    assert len(result["blocks"]["a"]) == 16


def test_mixed_tensor_hex_invalid_cell_type():
    """Invalid cell_type raises ValueError."""
    from hf2vespa.converters import dict_to_mixed_tensor_hex

    with pytest.raises(ValueError, match="Unknown cell type"):
        dict_to_mixed_tensor_hex({"a": [1]}, cell_type="int16")


def test_mixed_tensor_hex_dimension_mismatch():
    """Dimension validation works."""
    from hf2vespa.converters import dict_to_mixed_tensor_hex

    with pytest.raises(ValueError, match="dimension mismatch"):
        dict_to_mixed_tensor_hex({"a": [1, 2], "b": [3]})


def test_mixed_tensor_hex_empty_dict():
    """Empty dict raises ValueError."""
    from hf2vespa.converters import dict_to_mixed_tensor_hex

    with pytest.raises(ValueError, match="empty dict"):
        dict_to_mixed_tensor_hex({})


def test_mixed_tensor_hex_int8_out_of_range():
    """Out-of-range value shows key context."""
    from hf2vespa.converters import dict_to_mixed_tensor_hex

    with pytest.raises(ValueError, match="key 'bad'"):
        dict_to_mixed_tensor_hex({"good": [1, 2], "bad": [128, 1]}, cell_type="int8")

    # Verify error mentions the range issue
    try:
        dict_to_mixed_tensor_hex({"good": [1, 2], "bad": [128, 1]}, cell_type="int8")
    except ValueError as e:
        assert "outside int8 range" in str(e)


def test_mixed_tensor_hex_propagates_row_num():
    """Row number reaches hex encoder."""
    from hf2vespa.converters import dict_to_mixed_tensor_hex

    with pytest.raises(ValueError, match=r"row 3"):
        dict_to_mixed_tensor_hex({"a": [200]}, cell_type="int8", row_num=3)


# =============================================================================
# Config validation tests for mixed tensor types
# =============================================================================


def test_config_accepts_mixed_tensor():
    """Config validates mixed_tensor type."""
    from hf2vespa.config import FieldMapping

    m = FieldMapping(source="tokens", target="token_embeddings", type="mixed_tensor")
    assert m.type == "mixed_tensor"


def test_config_accepts_mixed_tensor_hex():
    """Config validates mixed_tensor_hex type."""
    from hf2vespa.config import FieldMapping

    m = FieldMapping(
        source="tokens", target="token_embeddings", type="mixed_tensor_hex"
    )
    assert m.type == "mixed_tensor_hex"


# =============================================================================
# Vespa documentation verification tests (TEST-01)
# =============================================================================


class TestVespaDocVerification:
    """Tests verifying output matches Vespa documentation examples.

    All expected values are hardcoded from official Vespa documentation.
    Source: https://docs.vespa.ai/en/reference/schemas/document-json-format.html
    """

    @pytest.mark.parametrize("example", VESPA_INT8_HEX_EXAMPLES)
    def test_int8_hex_vespa_doc(self, example):
        """Verify int8 hex encoding matches Vespa documentation."""
        from hf2vespa.converters import list_to_tensor_int8_hex

        result = list_to_tensor_int8_hex(example["input"])
        assert result["values"] == example["expected"]

    @pytest.mark.parametrize("example", IEEE754_FLOAT32_EXAMPLES)
    def test_float32_hex_ieee754(self, example):
        """Verify float32 hex encoding matches IEEE 754 standard."""
        from hf2vespa.converters import list_to_tensor_float32_hex

        result = list_to_tensor_float32_hex(example["input"])
        assert result["values"] == example["expected"]

    @pytest.mark.parametrize("example", IEEE754_FLOAT64_EXAMPLES)
    def test_float64_hex_ieee754(self, example):
        """Verify float64 hex encoding matches IEEE 754 standard."""
        from hf2vespa.converters import list_to_tensor_float64_hex

        result = list_to_tensor_float64_hex(example["input"])
        assert result["values"] == example["expected"]

    @pytest.mark.parametrize("example", BFLOAT16_EXAMPLES)
    def test_bfloat16_hex_ieee754(self, example):
        """Verify bfloat16 hex encoding (upper 2 bytes of float32)."""
        from hf2vespa.converters import list_to_tensor_bfloat16_hex

        result = list_to_tensor_bfloat16_hex(example["input"])
        assert result["values"] == example["expected"]


# =============================================================================
# Round-trip encoding tests (TEST-02)
# =============================================================================


class TestRoundTrip:
    """Tests validating encoding produces expected byte patterns.

    These tests verify the round-trip property: encoding then decoding
    returns the original value (within precision limits).
    """

    def test_int8_round_trip(self):
        """Int8 values encode to correct byte patterns."""
        import struct
        from hf2vespa.converters import list_to_tensor_int8_hex

        # Test all boundary values
        test_values = [-128, -1, 0, 1, 127]
        result = list_to_tensor_int8_hex(test_values)

        # Decode hex back to bytes and verify
        hex_str = result["values"]
        for i, expected in enumerate(test_values):
            byte_hex = hex_str[i * 2 : (i + 1) * 2]
            decoded = struct.unpack(">b", bytes.fromhex(byte_hex))[0]
            assert decoded == expected, f"Value {expected} round-tripped to {decoded}"

    def test_float32_round_trip(self):
        """Float32 values encode to correct IEEE 754 bytes."""
        import struct
        from hf2vespa.converters import list_to_tensor_float32_hex

        test_values = [0.0, 1.0, -1.0, 3.14159, 1e10, -1e-10]
        result = list_to_tensor_float32_hex(test_values)

        # Decode hex back and verify within float32 precision
        hex_str = result["values"]
        for i, expected in enumerate(test_values):
            byte_hex = hex_str[i * 8 : (i + 1) * 8]
            decoded = struct.unpack(">f", bytes.fromhex(byte_hex))[0]
            # Float32 has ~7 decimal digits precision
            assert (
                abs(decoded - expected) < abs(expected) * 1e-6
                or abs(decoded - expected) < 1e-10
            )

    def test_float64_round_trip(self):
        """Float64 values encode to correct IEEE 754 bytes."""
        import struct
        from hf2vespa.converters import list_to_tensor_float64_hex

        test_values = [0.0, 1.0, -1.0, 3.141592653589793, 1e100, -1e-100]
        result = list_to_tensor_float64_hex(test_values)

        # Decode hex back and verify exact (float64 is Python's native float)
        hex_str = result["values"]
        for i, expected in enumerate(test_values):
            byte_hex = hex_str[i * 16 : (i + 1) * 16]
            decoded = struct.unpack(">d", bytes.fromhex(byte_hex))[0]
            assert decoded == expected, f"Value {expected} round-tripped to {decoded}"

    def test_bfloat16_truncation_round_trip(self):
        """Bfloat16 truncates (not rounds) precision."""
        import struct
        from hf2vespa.converters import list_to_tensor_bfloat16_hex

        # 1.5 in float32 is 0x3FC00000, bfloat16 truncates to 0x3FC0
        result = list_to_tensor_bfloat16_hex([1.5])
        assert result["values"] == "3fc0"

        # Verify by decoding: pad with zeros to get float32
        padded = result["values"] + "0000"
        decoded = struct.unpack(">f", bytes.fromhex(padded))[0]
        assert decoded == 1.5


# =============================================================================
# Boundary condition tests (TEST-03)
# =============================================================================


class TestBoundaryConditions:
    """Tests covering edge cases for all tensor types."""

    def test_int8_all_boundaries(self):
        """Int8 handles all boundary values correctly."""
        from hf2vespa.converters import list_to_tensor_int8_hex

        # Min, max, zero
        result = list_to_tensor_int8_hex([INT8_BOUNDARY_VALUES["min"]])
        assert result["values"] == "80"

        result = list_to_tensor_int8_hex([INT8_BOUNDARY_VALUES["max"]])
        assert result["values"] == "7f"

        result = list_to_tensor_int8_hex([INT8_BOUNDARY_VALUES["zero"]])
        assert result["values"] == "00"

    def test_single_value_tensors(self):
        """Single-element tensors work for all types."""
        from hf2vespa.converters import (
            list_to_tensor_int8_hex,
            list_to_tensor_bfloat16_hex,
            list_to_tensor_float32_hex,
            list_to_tensor_float64_hex,
        )

        # All should accept single-value lists
        assert list_to_tensor_int8_hex([42])["values"] == "2a"
        assert list_to_tensor_bfloat16_hex([1.0])["values"] == "3f80"
        assert list_to_tensor_float32_hex([1.0])["values"] == "3f800000"
        assert list_to_tensor_float64_hex([1.0])["values"] == "3ff0000000000000"

    def test_large_tensors(self):
        """Large tensors (10K elements) encode correctly."""
        from hf2vespa.converters import list_to_tensor_float32_hex

        # 10K element tensor
        data = [float(i) for i in range(10000)]
        result = list_to_tensor_float32_hex(data)

        # Should be 10000 * 8 = 80000 hex chars
        assert len(result["values"]) == 80000

        # First and last values should match
        assert result["values"][:8] == "00000000"  # 0.0
        # 9999.0 as float32 = 0x461C3C00
        assert result["values"][-8:] == "461c3c00"

    def test_float_special_infinity(self):
        """Infinity encodes correctly in float32/64."""
        from hf2vespa.converters import (
            list_to_tensor_float32_hex,
            list_to_tensor_float64_hex,
        )

        # Float32 infinity: 0x7F800000
        result = list_to_tensor_float32_hex([float("inf")])
        assert result["values"] == "7f800000"

        # Float32 negative infinity: 0xFF800000
        result = list_to_tensor_float32_hex([float("-inf")])
        assert result["values"] == "ff800000"

        # Float64 infinity: 0x7FF0000000000000
        result = list_to_tensor_float64_hex([float("inf")])
        assert result["values"] == "7ff0000000000000"

    def test_sparse_tensor_single_key(self):
        """Sparse tensor with single key works."""
        from hf2vespa.converters import dict_to_sparse_tensor

        result = dict_to_sparse_tensor({"only_key": 1.0})
        assert len(result["cells"]) == 1
        assert result["cells"][0]["address"]["key"] == "only_key"
        assert result["cells"][0]["value"] == 1.0

    def test_mixed_tensor_single_block(self):
        """Mixed tensor with single block works."""
        from hf2vespa.converters import dict_to_mixed_tensor

        result = dict_to_mixed_tensor({"only": [1.0, 2.0, 3.0]})
        assert len(result["blocks"]) == 1
        assert result["blocks"]["only"] == [1.0, 2.0, 3.0]

    def test_mixed_tensor_hex_dimension_one(self):
        """Mixed tensor hex with dimension=1 works."""
        from hf2vespa.converters import dict_to_mixed_tensor_hex

        result = dict_to_mixed_tensor_hex({"a": [1.0], "b": [2.0]}, cell_type="float32")
        assert result["blocks"]["a"] == "3f800000"
        assert result["blocks"]["b"] == "40000000"
