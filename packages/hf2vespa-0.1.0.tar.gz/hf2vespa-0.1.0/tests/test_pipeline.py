"""Tests for pipeline streaming functionality."""

from hf2vespa.pipeline import stream_dataset


def test_stream_dataset_accepts_num_proc():
    """Verify stream_dataset accepts num_proc parameter without error."""
    # num_proc is accepted for API consistency but not used with streaming=True
    # (HuggingFace datasets library limitation)
    records = stream_dataset(
        dataset_name="glue",
        split="test",
        config="ax",
        num_proc=2,
    )
    # Take first record to verify it works (parameter doesn't break streaming)
    first = next(iter(records))
    assert "premise" in first or "hypothesis" in first
