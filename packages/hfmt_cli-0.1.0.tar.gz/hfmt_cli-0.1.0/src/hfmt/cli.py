# -*- coding: utf-8 -*-

####################################################################################
# - COPYRIGHT -
####################################################################################

"""
hfmt-cli — A simple CLI utility for generating formatted text headers.

Copyright (c) 2025 Bogdan Pricope
SPDX-License-Identifier: BSD-3-Clause
"""

####################################################################################
# - MODULES -
####################################################################################

import argparse
import sys
import warnings

####################################################################################
# - FUNCTIONS -
####################################################################################

def hfmt(head: str, args) -> str:
    """ This function takes a string and formats it as a header, using the
    specified style, width and character."""

    ########################### - BOXED HEADER FORMAT - ############################

    formatted_head: str = f" {head} "
    char_len: int = len(args.char)

    if char_len > 1:
        char0: str = args.char[0]
        char1:  str = args.char[-1]
        if char_len > 2:
            chars: str = args.char[1:-1]
        else:
            chars: str = ""
    else:
        char0: str = args.char
        char1:  str = args.char
        chars: str = ""

    width: int = get_width(args.width, args.box, args.style, char_len, formatted_head)
    align: str = get_align(args.align, args.box, args.style)

    border: str = char1*width if char_len == 1 else char0 + char1*(width-2) + char0

    if args.border_only:
        return border

    if args.box != 'none':
        return draw_boxed(formatted_head, args.box, width, align)

    ############################ - CHAR HEADER FORMAT - ############################

    if args.style == 'multi':
        return (
            f"{border}\n"
            f"{char0*char_len}{formatted_head:{align}{width-char_len}}\n"
            f"{border}"
        )
    if args.style == 'boxed':
        return (
            f"{border}\n{char0}{char1 * (char_len-1)}"
            f"{formatted_head:{align}{width-2*char_len}}"
            f"{char1 * (char_len-1)}{char0}\n{border}"
        )
    return f"{char0}{chars}{formatted_head:{char1}{align}{width - 2*(1 + len(chars))}}{chars[::-1]}{char0}"

################################### FORMAT WIDTH ###################################

def get_width(width: str, box: str, style: str, char_len: int, fmt_header: str) -> int:
    """Determine the width of the header based on input parameters."""

    default: int = 84
    header_width: int = len(fmt_header) + 2 * char_len

    is_auto_width: list[bool] = [
        width.lower() == "auto",
        width.lower() == "default" and style.lower() == "boxed",
        width.lower() == "default" and box.lower() != "none"
    ]

    if width.lower() == 'default' and box.lower() == 'none':
        return default
    if any(is_auto_width):
        return header_width
    try:
        _width = int(width)
        if _width <= 0:
            warnings.warn(f"Invalid option {width}, using default (84).")
            return default
        return max(_width, header_width)
    except ValueError:
        warnings.warn(f"Invalid option {width}, using default (84).")
        return default

################################# FORMAT ALIGNMENT #################################

def get_align(align: str, box: str, style: str) -> str:
    """Determine the alignment of the header based on input parameters."""

    is_default_center: list[bool] = [
        align.lower() == "default" and box.lower() != "none",
        style.lower() == "single",
        style.lower() == "boxed"
    ]

    if align.lower() == "left":
        return "<"
    if align.lower() == "right":
        return ">"
    if align.lower() == "center":
        return "^"
    if any(is_default_center):
        return "^"
    if align.lower() == "default" and style.lower() == "multi":
        return "<"
    warnings.warn(f"Invalid option {align}. Using default (center).")
    return "^"

################################ BOX HEADER FORMAT #################################

def draw_boxed(head, box: str, width: int, align: str) -> str:
    """Draw a box around the header text based on the specified box style."""

    if box == 'thick': # style 3
        v  = "┃" # vertical
        h  = "━" # horizontal
        ul = "┏" # upper left
        ur = "┓" # upper right
        bl = "┗" # bottom left
        br = "┛" # bottom right
    elif box == 'round': # style 4
        v  = "│" # vertical
        h  = "─" # horizontal
        ul = "╭" # upper left
        ur = "╮" # upper right
        bl = "╰" # bottom left
        br = "╯" # bottom right
    elif box == 'double': # style 1
        v  = "║" # vertical
        h  = "═" # horizontal
        ul = "╔" # upper left
        ur = "╗" # upper right
        bl = "╚" # bottom left
        br = "╝" # bottom right
    else:
        # Default
        v  = "│" # vertical
        h  = "─" # horizontal
        ul = "┌" # upper left
        ur = "┐" # upper right
        bl = "└" # bottom left
        br = "┘" # bottom right

    top     = ul + h * (width - 2) + ur
    bottom  = bl + h * (width - 2) + br

    return f"{top}\n{v}{head:{align}{width - 2}}{v}\n{bottom}"

####################################################################################
# - MAIN -
####################################################################################

def main():
    """ Main function to parse arguments and generate the header. """

    ############################### - PARSER SETUP - ###############################

    parser = argparse.ArgumentParser(
        description="Format a title with a border.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ####################### - VALUE OPTIONS CONFIGURATION - ########################

    parser.add_argument("head", nargs="?", help="The header text")

    parser.add_argument(
        "-H", "--head", dest="header",
        help="The header text (alternative flag form)."
    )
    parser.add_argument(
        "-s", "--style", choices=["single", "multi", "boxed"],
        default="single", help="Border style."
    )
    parser.add_argument(
        "-c", "--char", default="#",
        help="Character to use for the border."
    )
    parser.add_argument(
        "-w", "--width", default='default',
        help="Width of the rows.", type=str
    )
    parser.add_argument(
        "-b", "--box", choices=["thin", "thick", "round", "double"],
        default='none', help="Used do display boxed text.", type=str
    )
    parser.add_argument(
        "-a", "--align", choices=['left', 'right', 'center'],
        default='default', help="Used do display boxed text.", type=str
    )
    parser.add_argument(
        "--border-only", action="store_true",
        help="Display only the border without the header text."
    )

    ####################### - BOOLEAN FLAGS CONFIGURATION - ########################

    case_group = parser.add_mutually_exclusive_group()
    case_group.add_argument(
        "-U", "--upper", action="store_true",
        help="Converts header to UPPERCASE."
    )
    case_group.add_argument(
        "-L" ,"--lower", action="store_true",
        help="Converts header to lowercase."
    )
    case_group.add_argument(
        "-T", "--title", action="store_true",
        help="Converts header to Title_Case."
    )
    case_group.add_argument(
        "-S", "--swapcase", action="store_true",
        help="Converts header to sWAPcASE."
    )

    ############################# - ARGUMENT PARSING - #############################

    args = parser.parse_args()

    ############################ - HEADER FORMATTING - #############################

    # Prefer --head flag over positional head
    head = args.header or args.head

    if not head:
        # If neither positional nor flag provided, read from stdin (pipe)
        if not sys.stdin.isatty():
            head = sys.stdin.read().strip()
        else:

            if not args.border_only:
                parser.error(
                    "No header text provided. Use positional argument,"
                    "-H/--head flag, or pipe input."
                )

            head = ""

    if args.upper:
        head = head.upper()
    elif args.lower:
        head = head.lower()
    elif args.title:
        head = head.title()
    elif args.swapcase:
        head = head.swapcase()

    ############################## - FUNCTION CALL - ###############################

    print(hfmt(head, args))

####################################################################################
# - EXEC -
####################################################################################

if __name__ == "__main__":
    main()

####################################################################################
# - END -
####################################################################################
