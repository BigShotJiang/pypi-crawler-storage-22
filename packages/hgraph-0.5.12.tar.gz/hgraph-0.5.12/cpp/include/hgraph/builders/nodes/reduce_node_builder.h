//
// Created by Howard Henson on 26/12/2024.
//

#ifndef REDUCE_NODE_BUILDER_H
#define REDUCE_NODE_BUILDER_H

#include <hgraph/builders/node_builder.h>
#include <hgraph/builders/graph_builder.h>
#include <tuple>

namespace hgraph {
    /**
     * Non-templated ReduceNodeBuilder.
     * The key type is handled dynamically via the TSD input.
     */
    struct ReduceNodeBuilder : BaseNodeBuilder {
        ReduceNodeBuilder(node_signature_s_ptr signature_, nb::dict scalars_,
                          std::optional<input_builder_s_ptr> input_builder_ = std::nullopt,
                          std::optional<output_builder_s_ptr> output_builder_ = std::nullopt,
                          std::optional<output_builder_s_ptr> error_builder_ = std::nullopt,
                          std::optional<output_builder_s_ptr> recordable_state_builder_ = std::nullopt,
                          graph_builder_s_ptr nested_graph_builder = {},
                          const std::tuple<int64_t, int64_t> &input_node_ids = {}, int64_t output_node_id = -1);

        node_s_ptr make_instance(const std::vector<int64_t> &owning_graph_id, int64_t node_ndx) const override;

        graph_builder_s_ptr nested_graph_builder;
        std::tuple<int64_t, int64_t> input_node_ids;
        int64_t output_node_id;
    };

    void reduce_node_builder_register_with_nanobind(nb::module_ & m);
} // namespace hgraph

#endif  // REDUCE_NODE_BUILDER_H
