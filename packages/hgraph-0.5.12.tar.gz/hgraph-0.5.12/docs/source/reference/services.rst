Services
========

Other than the decorator definitions that can be found in :doc:`decorator`.
There are a number of useful functions that are used to implement services.
These include:

.. autofunction:: hgraph.get_service_inputs

.. autofunction:: hgraph.set_service_output
