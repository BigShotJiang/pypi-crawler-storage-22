import json
from typing import overload
from hgraph import (
    K,
    OUT,
    TS,
    TS_SCHEMA,
    TSB,
    TSD,
    combine,
    compute_node,
    SCALAR,
    JSON,
    convert,
    getattr_,
    getitem_,
    json_decode,
    json_encode,
    operator,
    Type,
    DEFAULT,
    LOGGER
)


@compute_node(overloads=json_decode)
def json_decode_str(ts: TS[str], _log: LOGGER = None) -> TS[JSON]:
    try:
        return JSON(json.loads(ts.value))
    except:
        _log.error(f"Failed to decode JSON {ts.value}")


@compute_node(overloads=json_decode)
def json_decode_bytes(ts: TS[bytes], _log: LOGGER = None) -> TS[JSON]:
    try:
        return JSON(json.loads(ts.value))
    except:
        _log.error(f"Failed to decode JSON {ts.value}")



@compute_node(overloads=json_encode)
def json_encode_str(ts: TS[JSON], _tp: Type[str] = DEFAULT[SCALAR], _log: LOGGER = None) -> TS[str]:
    try:
        return json.dumps(ts.value.json)
    except:
        _log.error(f"Failed to encode JSON {ts.value.json}")



@compute_node(overloads=json_encode)
def json_encode_bytes(ts: TS[JSON], _tp: Type[bytes] = DEFAULT[SCALAR], _log: LOGGER = None) -> TS[bytes]:
    try:
        return json.dumps(ts.value.json).encode("utf-8")
    except:
        _log.error(f"Failed to encode JSON {ts.value.json}")


@compute_node(overloads=getattr_, requires=lambda m, attr: attr == "str")
def getattr_json_str(ts: TS[JSON], attr: str) -> TS[str]:
    return ts.value.json


@compute_node(overloads=getattr_, requires=lambda m, attr: attr == "bool")
def getattr_json_bool(ts: TS[JSON], attr: str) -> TS[bool]:
    return ts.value.json


@compute_node(overloads=getattr_, requires=lambda m, attr: attr == "int")
def getattr_json_int(ts: TS[JSON], attr: str) -> TS[int]:
    return ts.value.json


@compute_node(overloads=getattr_, requires=lambda m, attr: attr == "float")
def getattr_json_float(ts: TS[JSON], attr: str) -> TS[float]:
    return ts.value.json


@compute_node(overloads=getattr_, requires=lambda m, attr: attr == "obj")
def getattr_json_obj(ts: TS[JSON], attr: str) -> TS[object]:
    return ts.value.json


@compute_node(overloads=getitem_)
def getitem_json_str(ts: TS[JSON], key: str, _log: LOGGER = None) -> TS[JSON]:
    try:
        value = ts.value.json.get(key)
        if value is None:
            return
        else:
            return JSON(value)
    except:
        _log.error(f"Cannot get '{key}' from JSON '{ts.value.json}'")



@compute_node(overloads=getitem_)
def getitem_json_int(ts: TS[JSON], key: int, _log: LOGGER = None) -> TS[JSON]:
    try:
        value = ts.value.json[key]
        if value is None:
            return
        else:
            return JSON(value)
    except:
        _log.error(f"Cannot get '{key}' from JSON '{ts.value.json}'")


@compute_node(
    overloads=combine,
    all_valid=lambda m, __strict__: ("bundle",) if __strict__ else None,
)
def combine_json(
    tp_out_: Type[TS[JSON]] = DEFAULT[OUT],
    __strict__: bool = True,
    **bundle: TSB[TS_SCHEMA],
) -> TS[JSON]:
    return JSON({k: v if type(v) is not JSON else v.json for k, v in bundle.value.items() if v is not None})


@compute_node(overloads=convert, requires=lambda m: m[OUT].py_type == TS[JSON])
def convert_tsd_to_json(
    ts: TSD[K, TS[JSON]],
    to: Type[TS[JSON]] = DEFAULT[OUT],
) -> TS[JSON]:
    return JSON({k: v.value.json for k, v in ts.valid_items()})
