__version__ = "2.0.0"

import hidroconta.types
import hidroconta.time
import hidroconta.endpoints
import hidroconta.hist
import hidroconta.api