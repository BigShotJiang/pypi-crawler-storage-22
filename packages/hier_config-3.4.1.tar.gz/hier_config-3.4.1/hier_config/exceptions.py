class DuplicateChildError(Exception):
    """Raised when attempting to add a duplicate child."""
