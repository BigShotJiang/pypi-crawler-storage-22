"""Role-Based Access Control (RBAC) definitions."""

from enum import Enum


class Role(str, Enum):
    ADMIN = "admin"
    EDITOR = "editor"  # Can read/write memories, but not manage tenant
    VIEWER = "viewer"  # Read-only access to memories


class Permission(str, Enum):
    READ_MEMORY = "read:memory"
    WRITE_MEMORY = "write:memory"
    DELETE_MEMORY = "delete:memory"
    MANAGE_TENANT = "manage:tenant"
    MANAGE_REALMS = "manage:realms"


# Role to Permission mapping
ROLE_PERMISSIONS = {
    Role.ADMIN: {
        Permission.READ_MEMORY,
        Permission.WRITE_MEMORY,
        Permission.DELETE_MEMORY,
        Permission.MANAGE_TENANT,
        Permission.MANAGE_REALMS,
    },
    Role.EDITOR: {
        Permission.READ_MEMORY,
        Permission.WRITE_MEMORY,
        Permission.DELETE_MEMORY,
    },
    Role.VIEWER: {
        Permission.READ_MEMORY,
    },
}


def has_permission(role: str, permission: Permission) -> bool:
    """Check if a role has a specific permission."""
    try:
        role_enum = Role(role)
    except ValueError:
        return False
    perms = ROLE_PERMISSIONS.get(role_enum, set())
    return permission in perms
