"""
# Phase 2 verified
routes/__init__.py
------------------
Unified router loader for the HIEROMEM API.

This initializer automatically registers all route modules
(memory, events, health, admin) with a FastAPI app instance.

Enterprise features (billing, dashboard) are conditionally loaded
based on the HIEROMEM_ENTERPRISE environment variable.

Usage:
    from hieromem_api.routes import init_routes
    app = FastAPI()
    init_routes(app)

This design keeps main.py clean while ensuring that each
functional module (cognition, narration, health, admin)
remains independently testable and extendable.

Author: Sai Rishi Kiran Mannava
"""

import os
import structlog

from hieromem_api.routes import (
    health,
    memory,
    export,
    import_memory,
    events,
    admin,
    multimodal,
    auth,
    policies,
    reasoning,
    temporal,
    realms,
    replay,
)
from fastapi import FastAPI

logger = structlog.get_logger(__name__)

# Enterprise feature flag
ENTERPRISE_ENABLED = os.getenv("HIEROMEM_ENTERPRISE", "0").lower() in ("1", "true", "yes")


def init_routes(app: FastAPI) -> None:
    """Register all routers with the FastAPI application.

    Core routes are always registered. Enterprise routes (billing, dashboard)
    are only registered when HIEROMEM_ENTERPRISE=1.
    """
    registered_routes = []

    # Core routes (always enabled)
    app.include_router(health.router, prefix="", tags=["Health"])
    app.include_router(memory.router, prefix="", tags=["Memory"])
    app.include_router(export.router, prefix="", tags=["Memory"])
    app.include_router(import_memory.router, prefix="", tags=["Memory"])
    app.include_router(events.router)
    app.include_router(admin.router)
    app.include_router(multimodal.router, prefix="", tags=["Memory"])
    app.include_router(auth.router)
    app.include_router(policies.router)
    app.include_router(reasoning.router)
    app.include_router(temporal.router)
    app.include_router(realms.router)
    app.include_router(replay.router)
    registered_routes.extend([
        "/memory", "/events", "/system", "/admin", "/policies",
        "/reasoning", "/temporal", "/realms", "/replay"
    ])

    # Enterprise routes (conditionally enabled)
    if ENTERPRISE_ENABLED:
        from hieromem_api.routes import billing, dashboard
        app.include_router(billing.router)
        app.include_router(dashboard.router)
        registered_routes.extend(["/billing", "/dashboard"])
        logger.info("enterprise_features_enabled", features=["billing", "dashboard"])
    else:
        logger.info("enterprise_features_disabled", hint="Set HIEROMEM_ENTERPRISE=1 to enable")

    logger.info("routes_registered", routes=registered_routes, enterprise=ENTERPRISE_ENABLED)


__all__ = ["init_routes"]
