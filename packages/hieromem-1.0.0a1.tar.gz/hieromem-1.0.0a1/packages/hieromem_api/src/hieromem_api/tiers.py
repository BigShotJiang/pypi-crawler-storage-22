"""Tier configuration and limits for HIEROMEM SaaS."""

from typing import Optional


# Tier-based limits and features
TIER_LIMITS = {
    "free": {
        "memories_per_month": 1000,
        "recalls_per_day": 100,
        "namespaces": 1,
        "retention_days": 7,
        "rate_limit_per_minute": 60,
        "features": ["vector_search", "api_access"],
        "price_monthly": 0,
    },
    "pro": {
        "memories_per_month": 10000,
        "recalls_per_day": None,  # unlimited
        "namespaces": 5,
        "retention_days": None,  # unlimited
        "rate_limit_per_minute": 1000,
        "features": [
            "vector_search",
            "graph_search",
            "dual_recall",
            "multi_modal",
            "api_access",
            "export",
            "custom_params",
        ],
        "price_monthly": 19,
    },
    "team": {
        "memories_per_month": 50000,
        "recalls_per_day": None,
        "namespaces": None,  # unlimited
        "retention_days": None,
        "rate_limit_per_minute": 5000,
        "features": [
            "vector_search",
            "graph_search",
            "dual_recall",
            "multi_modal",
            "api_access",
            "export",
            "custom_params",
            "team_collaboration",
            "rbac",
            "sso",
            "analytics",
            "webhooks",
        ],
        "price_monthly": 49,
    },
    "enterprise": {
        "memories_per_month": None,  # unlimited
        "recalls_per_day": None,
        "namespaces": None,
        "retention_days": None,
        "rate_limit_per_minute": None,  # unlimited
        "features": [
            "all",
            "dedicated_infrastructure",
            "custom_sla",
            "compliance",
            "white_label",
            "custom_integrations",
            "dedicated_support",
        ],
        "price_monthly": None,  # custom pricing
    },
}


def get_tier_limit(tier: str, limit_name: str) -> Optional[int]:
    """Get a specific limit for a tier."""
    tier_config = TIER_LIMITS.get(tier, TIER_LIMITS["free"])
    return tier_config.get(limit_name)


def has_feature(tier: str, feature: str) -> bool:
    """Check if a tier has access to a specific feature."""
    tier_config = TIER_LIMITS.get(tier, TIER_LIMITS["free"])
    features = tier_config.get("features", [])
    return "all" in features or feature in features


__all__ = ["TIER_LIMITS", "get_tier_limit", "has_feature"]
