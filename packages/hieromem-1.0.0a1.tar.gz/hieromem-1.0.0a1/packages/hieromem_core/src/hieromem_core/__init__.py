"""Core primitives for the HIEROMEM platform."""

__all__: list[str] = []
