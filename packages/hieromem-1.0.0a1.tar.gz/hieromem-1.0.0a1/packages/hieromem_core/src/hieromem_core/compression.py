"""Compression strategy stubs for long-term memory."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Iterable, List

from hieromem_core.episode import Episode


class CompressionStrategy:
    """Base class for compression strategies."""

    def select(self, episodes: Iterable[Episode]) -> List[Episode]:
        return list(episodes)

    def compress(self, episodes: Iterable[Episode]) -> List[Episode]:
        return list(episodes)

    def maybe_compress(self, episodes: Iterable[Episode]) -> List[Episode]:
        targets = self.select(episodes)
        return self.compress(targets)


class NoOpCompressionStrategy(CompressionStrategy):
    """Default placeholder strategy that leaves episodes unchanged."""

    pass


@dataclass
class TimeBasedCompressionConfig:
    cutoff_days: int = 30


class TimeBasedCompressionStrategy(CompressionStrategy):
    def __init__(self, config: TimeBasedCompressionConfig |
                 None = None) -> None:
        self.config = config or TimeBasedCompressionConfig()

    def select(self, episodes: Iterable[Episode]) -> List[Episode]:
        cutoff = datetime.now() - timedelta(days=self.config.cutoff_days)
        return [ep for ep in episodes if ep.tocc < cutoff]

    def compress(self, episodes: Iterable[Episode]) -> List[Episode]:
        # Placeholder: in the future this could summarise or downsample
        # vectors.
        return list(episodes)
