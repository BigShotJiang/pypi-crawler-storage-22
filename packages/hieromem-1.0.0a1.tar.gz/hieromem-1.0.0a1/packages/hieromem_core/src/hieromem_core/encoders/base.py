from abc import ABC, abstractmethod
from typing import Any
import numpy as np


class BaseEncoder(ABC):
    """Abstract base class for all encoders."""

    @abstractmethod
    def encode(self, data: Any) -> np.ndarray:
        """
        Encode data into a vector.

        Args:
            data: Input data (text string, image path/bytes, audio path/bytes)

        Returns:
            Numpy array representing the embedding vector
        """
        pass

    @property
    @abstractmethod
    def dimension(self) -> int:
        """Return the dimension of the embedding vector."""
        pass
