from typing import Dict
from .base import BaseEncoder
from .text import TextEncoder
from .image import ImageEncoder
from .audio import AudioEncoder


class EncoderFactory:
    """Factory for creating and managing encoder instances."""

    _instances: Dict[str, BaseEncoder] = {}

    @classmethod
    def get_encoder(cls, media_type: str = "text") -> BaseEncoder:
        """
        Get an encoder instance for the specified media type.

        Args:
            media_type: Type of media ('text', 'image', 'audio')

        Returns:
            Encoder instance
        """
        if media_type in cls._instances:
            return cls._instances[media_type]

        encoder: BaseEncoder
        if media_type == "text":
            encoder = TextEncoder()
        elif media_type == "image":
            encoder = ImageEncoder()
        elif media_type == "audio":
            encoder = AudioEncoder()
        else:
            raise ValueError(f"Unsupported media type: {media_type}")

        cls._instances[media_type] = encoder
        return encoder

    @classmethod
    def clear_cache(cls):
        """Clear cached encoder instances."""
        cls._instances.clear()
