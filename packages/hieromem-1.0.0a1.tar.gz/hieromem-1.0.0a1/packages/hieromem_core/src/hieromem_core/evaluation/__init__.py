"""
Evaluation subpackage - built-in benchmarking for HIEROMEM.

Components:
- Evaluator: Main evaluation engine with metrics
- EvaluationResult: Result dataclass with recall, NDCG, etc.
- ComparisonResult: Compare graph vs dense retrieval
- Bundled datasets for testing
- Benchmark loaders (HotpotQA, NQ)
- Visualization tools
"""
from .framework import (
    Evaluator,
    EvaluationExample,
    EvaluationResult,
    ComparisonResult,
    create_example,
)
from .datasets import (
    TestDataset,
    TestDocument,
    TestQuery,
    get_dataset,
    list_datasets,
)
from .benchmarks import (
    BenchmarkLoader,
    BenchmarkExample,
    load_hotpotqa,
    load_natural_questions,
)
from .visualization import (
    format_comparison_table,
    visualize_query_analysis,
    print_comparison,
)

__all__ = [
    # Framework
    "Evaluator",
    "EvaluationExample",
    "EvaluationResult",
    "ComparisonResult",
    "create_example",
    # Datasets
    "TestDataset",
    "TestDocument",
    "TestQuery",
    "get_dataset",
    "list_datasets",
    # Benchmarks
    "BenchmarkLoader",
    "BenchmarkExample",
    "load_hotpotqa",
    "load_natural_questions",
    # Visualization
    "format_comparison_table",
    "visualize_query_analysis",
    "print_comparison",
]
