"""
Extraction subpackage - pluggable entity extraction with always-on normalization.

Components:
- EntityNormalizer: Ensures consistent entity representation
- EntityLinker: Cross-references entities across documents
- ExtractionPipeline: Configurable extraction pipeline
"""
from .normalizer import EntityNormalizer, NormalizedEntity, get_normalizer
from .linker import EntityLinker, LinkedEntity, get_linker
from .pipeline import (
    ExtractionPipeline,
    ExtractionResult,
    create_regex_pipeline,
    create_llm_pipeline,
    create_hybrid_pipeline,
)

__all__ = [
    # Normalizer
    "EntityNormalizer",
    "NormalizedEntity",
    "get_normalizer",
    # Linker
    "EntityLinker",
    "LinkedEntity",
    "get_linker",
    # Pipeline
    "ExtractionPipeline",
    "ExtractionResult",
    "create_regex_pipeline",
    "create_llm_pipeline",
    "create_hybrid_pipeline",
]
