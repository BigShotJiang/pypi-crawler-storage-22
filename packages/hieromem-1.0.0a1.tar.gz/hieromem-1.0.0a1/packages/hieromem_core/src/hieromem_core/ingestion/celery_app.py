"""
celery_app.py
-------------
Celery application configuration for async episode ingestion.

Author: HIEROMEM Team
"""

from celery import Celery
import os

# Get Redis URL from environment
REDIS_URL = os.getenv("HIEROMEM_CELERY_BROKER", "redis://localhost:6379/1")

# Create Celery app
app = Celery(
    'hieromem_ingestion',
    broker=REDIS_URL,
    backend=REDIS_URL,
    include=['hieromem_core.ingestion.tasks']
)

# Configure Celery
app.conf.update(
    # Serialization
    task_serializer='json',
    accept_content=['json'],
    result_serializer='json',

    # Task execution
    task_track_started=True,
    task_time_limit=300,  # 5 minutes max per task
    task_soft_time_limit=240,  # 4 minutes soft limit

    # Worker configuration
    worker_prefetch_multiplier=4,
    worker_max_tasks_per_child=1000,

    # Result backend
    result_expires=3600,  # 1 hour

    # Retry configuration
    task_acks_late=True,
    task_reject_on_worker_lost=True,

    # Timezone
    timezone='UTC',
    enable_utc=True,
)

if __name__ == '__main__':
    app.start()
