"""
HIEROMEM Policy Engine
======================

Provides configurable memory policies for retention, decay, summarization,
and governance. Policies can be defined in YAML or Python and are evaluated
at insert, summarize, and forget operations.

Usage:
    from hieromem_core.policy import MemoryPolicy, PolicyEngine

    # Load from YAML
    policy = MemoryPolicy.from_yaml("policies/user_chat.yaml")

    # Or create programmatically
    policy = MemoryPolicy(
        name="user-chat",
        retention=RetentionPolicy(horizon_days=7, decay_curve="exponential"),
        governance=GovernancePolicy(forbidden_relations=["personal_medical"])
    )

    # Attach to memory
    engine = PolicyEngine(policy)
    memory = Memory(policy_engine=engine)
"""

from hieromem_core.policy.schema import (
    MemoryPolicy,
    RetentionPolicy,
    SummarizationPolicy,
    GraphPolicy,
    GovernancePolicy,
    PriorityPolicy,
    DecayCurve,
)
from hieromem_core.policy.parser import (
    PolicyParser,
    PolicyParseError,
    PolicyValidationError,
    load_policy,
)
from hieromem_core.policy.evaluator import (
    PolicyEvaluator,
    PolicyDecision,
    PolicyEngine,
    PolicyAction,
    PolicyResult,
    EvaluationContext,
    MemoryPolicyEvaluator,
)
from hieromem_core.policy.events import (
    PolicyEvent,
    PolicyEventType,
    PolicyEventEmitter,
    PolicyEventHandler,
    LoggingEventHandler,
    FileEventHandler,
    CallbackEventHandler,
    FilteredEventHandler,
    get_default_emitter,
    setup_default_logging,
)
from hieromem_core.policy.hooks import (
    PolicyAwareMemory,
    PolicyViolationError,
    create_policy_memory,
)

__all__ = [
    # Schema
    "MemoryPolicy",
    "RetentionPolicy",
    "SummarizationPolicy",
    "GraphPolicy",
    "GovernancePolicy",
    "PriorityPolicy",
    "DecayCurve",
    # Parser
    "PolicyParser",
    "PolicyParseError",
    "PolicyValidationError",
    "load_policy",
    # Evaluator
    "PolicyEvaluator",
    "PolicyDecision",
    "PolicyEngine",
    "PolicyAction",
    "PolicyResult",
    "EvaluationContext",
    "MemoryPolicyEvaluator",
    # Events
    "PolicyEvent",
    "PolicyEventType",
    "PolicyEventEmitter",
    "PolicyEventHandler",
    "LoggingEventHandler",
    "FileEventHandler",
    "CallbackEventHandler",
    "FilteredEventHandler",
    "get_default_emitter",
    "setup_default_logging",
    # Hooks
    "PolicyAwareMemory",
    "PolicyViolationError",
    "create_policy_memory",
]
