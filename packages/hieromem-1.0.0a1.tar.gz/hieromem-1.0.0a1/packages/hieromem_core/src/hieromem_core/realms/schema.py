"""
schema.py
---------
Data models for Memory Realms.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Literal

PermissionType = Literal["read", "write", "admin"]
RealmType = Literal["shared", "private", "hybrid"]
IsolationLevel = Literal["logical", "cryptographic"]


@dataclass
class RealmParticipant:
    """An agent participating in a realm."""
    agent_id: str
    permissions: List[PermissionType] = field(default_factory=lambda: ["read"])


@dataclass
class MemoryRealm:
    """
    Configuration for a Memory Realm.

    A Realm is a distinct memory space that can be shared or private.
    """
    name: str
    type: RealmType = "private"
    participants: List[RealmParticipant] = field(default_factory=list)
    inheritance_from: Optional[str] = None
    isolation_level: IsolationLevel = "logical"

    def get_permissions(self, agent_id: str) -> List[PermissionType]:
        """Get permissions for a specific agent."""
        for p in self.participants:
            if p.agent_id == agent_id:
                return p.permissions
        return []
