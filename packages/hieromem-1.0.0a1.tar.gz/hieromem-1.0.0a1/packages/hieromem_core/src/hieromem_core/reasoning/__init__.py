"""
HIEROMEM Reasoning Module
=========================

Provides cognitive reasoning capabilities over episodic memory:

- **Contradiction Detection**: Detect semantic, temporal, and graph conflicts
- **Temporal Reasoning**: Before/after queries, time ranges, sequence reconstruction
- **Counterfactual Edges**: Track contradicts/supersedes/obsoletes relationships
- **Sequence Reconstruction**: Rebuild event sequences from memory

Usage:
    from hieromem_core.reasoning import (
        ContradictionDetector,
        TemporalReasoner,
        CounterfactualGraph,
        SequenceReconstructor,
    )

    # Detect contradictions on insert
    detector = ContradictionDetector()
    result = detector.detect_contradictions(new_episode, existing_episodes)

    # Temporal queries
    reasoner = TemporalReasoner()
    events = reasoner.recall_before(reference_episode, limit=10)

    # Counterfactual tracking
    graph = CounterfactualGraph()
    graph.add_edge(CounterfactualEdge(...))
    latest = graph.get_latest_version(episode_id)

    # Sequence reconstruction
    reconstructor = SequenceReconstructor()
    sequence = reconstructor.reconstruct_temporal(episodes)
"""

# Contradiction Detection
from hieromem_core.reasoning.contradiction import (
    ContradictionType,
    ResolutionStrategy,
    Contradiction,
    ContradictionResult,
    ContradictionDetector,
    ContradictionResolver,
)

# Temporal Reasoning
from hieromem_core.reasoning.temporal import (
    TemporalQuery,
    TemporalEvent,
    TemporalSequence,
    TemporalIndex,
    TemporalReasoner,
)

# Counterfactual Edges
from hieromem_core.reasoning.counterfactual import (
    CounterfactualEdgeType,
    CounterfactualEdge,
    CounterfactualChain,
    CounterfactualGraph,
    CounterfactualLinker,
)

# Sequence Reconstruction
from hieromem_core.reasoning.sequence import (
    SequenceType,
    SequenceNode,
    SequenceGap,
    ReconstructedSequence,
    SequenceReconstructor,
)

__all__ = [
    # Contradiction Detection
    "ContradictionType",
    "ResolutionStrategy",
    "Contradiction",
    "ContradictionResult",
    "ContradictionDetector",
    "ContradictionResolver",
    # Temporal Reasoning
    "TemporalQuery",
    "TemporalEvent",
    "TemporalSequence",
    "TemporalIndex",
    "TemporalReasoner",
    # Counterfactual Edges
    "CounterfactualEdgeType",
    "CounterfactualEdge",
    "CounterfactualChain",
    "CounterfactualGraph",
    "CounterfactualLinker",
    # Sequence Reconstruction
    "SequenceType",
    "SequenceNode",
    "SequenceGap",
    "ReconstructedSequence",
    "SequenceReconstructor",
]
