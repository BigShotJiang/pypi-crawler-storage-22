"""
Retrieval Module.

Contains:
- DualRetriever: Heuristic-based hybrid retrieval.
- LearnedRetriever: Machine-learning based ranking (requires torch).
- ConfidenceEvaluator: Confidence scoring with low-confidence callbacks.
"""

from .dual import (
    DualRetriever,
    DualRetrievalResult,
    DualRetrievalConfig,
    DualRetrievalInput
)
from .confidence import (
    ConfidenceWeights,
    compute_confidence,
    freshness_score,
    ConfidenceConfig,
    ConfidenceEvaluator,
    ConfidenceResult,
    ConfidenceComponents,
    LowConfidenceAction,
    LowConfidenceCallback,
    create_ask_clarification_callback,
    create_expand_search_callback,
)
from .explanation import ExplanationPayload, build_explanation

# Lazy import for LearnedRetriever (requires torch)
try:
    from .learned import LearnedRetriever, LearnedConfig
    _HAS_TORCH = True
except ImportError:
    LearnedRetriever = None  # type: ignore[misc,assignment]
    LearnedConfig = None  # type: ignore[misc,assignment]
    _HAS_TORCH = False

__all__ = [
    "DualRetriever",
    "DualRetrievalResult",
    "DualRetrievalConfig",
    "DualRetrievalInput",
    "LearnedRetriever",
    "LearnedConfig",
    "ConfidenceWeights",
    "compute_confidence",
    "freshness_score",
    "ConfidenceConfig",
    "ConfidenceEvaluator",
    "ConfidenceResult",
    "ConfidenceComponents",
    "LowConfidenceAction",
    "LowConfidenceCallback",
    "create_ask_clarification_callback",
    "create_expand_search_callback",
    "ExplanationPayload",
    "build_explanation",
]
