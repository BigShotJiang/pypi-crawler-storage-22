"""Utility helpers for the HIEROMEM core package."""
