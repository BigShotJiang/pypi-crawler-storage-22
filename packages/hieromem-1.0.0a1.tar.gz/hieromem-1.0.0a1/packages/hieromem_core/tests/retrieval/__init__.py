"""Retrieval module tests."""
