"""Meta package to expose workspace configuration for development tooling."""

__all__ = ["__version__"]
__version__ = "0.1.0"
