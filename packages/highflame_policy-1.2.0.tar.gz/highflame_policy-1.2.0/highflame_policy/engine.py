"""
Highflame Policy Engine - Python Wrapper
Wraps cedarpy with Highflame-specific types
"""

import json
from dataclasses import dataclass, field
from typing import Any, Optional

import cedarpy

from .entities import EntityType
from .actions import ActionType


# Default validation limits - consistent across all SDK packages
@dataclass
class ValidationLimits:
    """Limits for input validation to prevent DoS attacks."""
    max_context_keys: int = 100
    max_string_length: int = 1_000_000
    max_nesting_depth: int = 10
    max_context_size_bytes: int = 10_000_000


DEFAULT_LIMITS = ValidationLimits()


class InputValidationError(Exception):
    """Raised when input validation fails."""
    pass


@dataclass
class EngineOptions:
    """Configuration options for PolicyEngine."""
    limits: Optional[ValidationLimits] = None
    skip_validation: bool = False


@dataclass
class EntityUID:
    """Cedar entity unique identifier."""
    type: str
    id: str


@dataclass
class Decision:
    """Result of a policy evaluation."""
    effect: str  # "Allow" or "Deny"
    determining_policies: list[str]
    reason: Optional[str] = None

    def is_allowed(self) -> bool:
        return self.effect == "Allow"

    def is_denied(self) -> bool:
        return self.effect == "Deny"


class PolicyEngine:
    """
    PolicyEngine wraps cedarpy with Highflame schema types.

    Example:
        engine = PolicyEngine()
        engine.load_policies_from_file("policies/palisade/policy.cedar")

        decision = engine.evaluate(
            principal_type=EntityType.SCANNER,
            principal_id="palisade",
            action=ActionType.SCAN_ARTIFACT,
            resource_type=EntityType.ARTIFACT,
            resource_id="/path/to/model.safetensors",
            context={
                "artifact_format": "safetensors",
                "severity": "HIGH",
                "environment": "production",
            }
        )

        if decision.is_denied():
            print(f"Blocked by: {decision.determining_policies}")
    """

    def __init__(self, options: Optional[EngineOptions] = None):
        self._policies: str = ""
        self._schema: Optional[str] = None
        self._limits = options.limits if options and options.limits else DEFAULT_LIMITS
        self._skip_validation = options.skip_validation if options else False

    def load_policies_from_file(self, path: str) -> None:
        """Load Cedar policies from a file."""
        with open(path, "r") as f:
            self._policies = f.read()

    def load_policies(self, policies: str) -> None:
        """Load Cedar policies from a string."""
        self._policies = policies

    def load_schema_from_file(self, path: str) -> None:
        """Load Cedar schema from a file."""
        with open(path, "r") as f:
            self._schema = f.read()

    def load_schema(self, schema: str) -> None:
        """Load Cedar schema from a string."""
        self._schema = schema

    def evaluate(
        self,
        principal_type: str,
        principal_id: str,
        action: str,
        resource_type: str,
        resource_id: str,
        context: Optional[dict[str, Any]] = None,
    ) -> Decision:
        """
        Evaluate a policy request and return a decision.

        Args:
            principal_type: Entity type of the principal (e.g., EntityType.USER)
            principal_id: ID of the principal
            action: Action being performed (e.g., ActionType.SCAN_ARTIFACT)
            resource_type: Entity type of the resource (e.g., EntityType.ARTIFACT)
            resource_id: ID of the resource
            context: Optional context attributes for the request

        Returns:
            Decision with effect, determining policies, and optional reason

        Raises:
            InputValidationError: If context validation fails
        """
        # Validate context if validation is enabled
        if not self._skip_validation and context:
            self._validate_context(context)

        # Format entity UIDs for Cedar
        principal = f'{principal_type}::"{principal_id}"'
        action_uid = f'Action::"{action}"'
        resource = f'{resource_type}::"{resource_id}"'

        # Call cedarpy (v4.8.0+ uses request dict instead of separate args)
        request = {
            "principal": principal,
            "action": action_uid,
            "resource": resource,
            "context": context or {},
        }
        result = cedarpy.is_authorized(
            request=request,
            policies=self._policies,
            entities=[],
        )

        # Map result to Decision (using result.allowed for cleaner API)
        return Decision(
            effect="Allow" if result.allowed else "Deny",
            determining_policies=list(result.diagnostics.reasons) if result.diagnostics else [],
            reason="; ".join(result.diagnostics.errors) if result.diagnostics and result.diagnostics.errors else None,
        )

    def validate_policies(self, policies: str) -> list[str]:
        """
        Validate policies against the loaded schema.

        Returns:
            List of validation error messages, or empty list if valid.
        """
        if not self._schema:
            return ["No schema loaded for validation"]

        result = cedarpy.validate(
            policies=policies,
            schema=self._schema,
        )

        if result.validation_errors:
            return [str(e) for e in result.validation_errors]
        return []

    def _validate_context(self, context: dict[str, Any]) -> None:
        """
        Validate context against configured limits.

        Raises:
            InputValidationError: If validation fails
        """
        # Check total number of keys
        if len(context) > self._limits.max_context_keys:
            raise InputValidationError(
                f"context exceeds maximum key count: {len(context)} > {self._limits.max_context_keys}"
            )

        # Check total size (approximate via JSON)
        try:
            context_json = json.dumps(context)
            if len(context_json.encode("utf-8")) > self._limits.max_context_size_bytes:
                raise InputValidationError(
                    f"context exceeds maximum size: {len(context_json)} bytes > {self._limits.max_context_size_bytes} bytes"
                )
        except (TypeError, ValueError) as e:
            raise InputValidationError(
                f"context is invalid or too complex: {str(e)}"
            )

        # Validate each value recursively
        for key, value in context.items():
            self._validate_value(value, depth=0, key=key)

    def _validate_value(self, value: Any, depth: int, key: str = "") -> None:
        """
        Recursively validate a value against configured limits.

        Raises:
            InputValidationError: If validation fails
        """
        # Check nesting depth
        if depth > self._limits.max_nesting_depth:
            raise InputValidationError(
                f"value exceeds maximum nesting depth: {depth} > {self._limits.max_nesting_depth}"
            )

        if isinstance(value, str):
            if len(value) > self._limits.max_string_length:
                raise InputValidationError(
                    f"string exceeds maximum length: {len(value)} > {self._limits.max_string_length}"
                )
        elif isinstance(value, list):
            for item in value:
                self._validate_value(item, depth + 1, key)
        elif isinstance(value, dict):
            for k, v in value.items():
                self._validate_value(v, depth + 1, k)
