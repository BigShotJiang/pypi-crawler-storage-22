"""
Cedar Policy Parser

Converts Cedar policy text to structured PolicyRule format using the
official Cedar engine (cedarpy) for parsing.

Architecture:
1. Cedar text → Cedar JSON (via cedarpy.policies_to_json_str)
2. Cedar JSON → PolicyRule (simple JSON mapping)
"""

import json
from dataclasses import dataclass, field
from typing import Any, Optional, Union

import cedarpy

from .rule import (
    PolicyRule,
    PolicyCondition,
    PolicyEntity,
    PolicyEffect,
    ConditionOperator,
    new_policy_rule,
    new_policy_entity,
    new_policy_condition,
)


@dataclass
class ParseResult:
    """Result of parsing Cedar policies."""

    # Policies successfully converted to PolicyRule format
    rules: list[PolicyRule] = field(default_factory=list)
    # Policies that couldn't be fully represented (raw Cedar text)
    unstructured: list[str] = field(default_factory=list)
    # Any parsing errors encountered
    errors: list[str] = field(default_factory=list)


def parse_cedar_to_rules(cedar_text: str) -> ParseResult:
    """
    Parse Cedar policy text and convert to PolicyRule format.

    Uses the official Cedar engine (cedarpy) for parsing.
    Policies with features that can't be represented as PolicyRule (e.g.,
    unless clauses, complex expressions) are returned in the unstructured list.

    Args:
        cedar_text: Cedar policy text to parse

    Returns:
        ParseResult with structured rules, unstructured policies, and errors
    """
    result = ParseResult()

    try:
        # Use cedarpy to convert Cedar text to JSON
        json_str = cedarpy.policies_to_json_str(cedar_text)
        policy_set = json.loads(json_str)

        # Process each static policy
        static_policies = policy_set.get("staticPolicies", {})
        for index, (policy_id, policy) in enumerate(static_policies.items()):
            rule, raw, error = _cedar_json_to_rule(policy, policy_id, index, cedar_text)

            if error:
                result.errors.append(f"Policy {policy_id}: {error}")

            if rule:
                result.rules.append(rule)
            elif raw:
                result.unstructured.append(raw)

        # Templates can't be represented as PolicyRule
        templates = policy_set.get("templates", {})
        for template_id in templates:
            result.unstructured.append(
                f"// Template: {template_id} (templates not supported as PolicyRule)"
            )

    except Exception as e:
        result.errors.append(f"Parse error: {str(e)}")

    return result


def _cedar_json_to_rule(
    policy: dict[str, Any],
    policy_id: str,
    index: int,
    original_cedar: str,
) -> tuple[Optional[PolicyRule], Optional[str], Optional[str]]:
    """
    Convert Cedar JSON policy to PolicyRule.
    This is pure JSON mapping - no parsing logic.

    Returns:
        Tuple of (rule, raw_cedar, error)
    """
    try:
        # Check if this policy can be represented as PolicyRule
        if not _can_represent_as_rule(policy):
            # Return raw Cedar for this policy (best effort extraction)
            raw = _extract_policy_cedar(policy_id, original_cedar)
            return None, raw, None

        annotations = policy.get("annotations", {})

        rule = new_policy_rule(
            id=annotations.get("id", policy_id),
            name=annotations.get("name", annotations.get("id", policy_id)),
            effect=policy["effect"],
            action=_map_action_scope(policy.get("action", {})),
            enabled=True,
            order=index,
            description=annotations.get("description"),
            principal=_map_scope_to_entity(policy.get("principal", {})),
            resource=_map_scope_to_entity(policy.get("resource", {})),
        )

        # Map conditions
        conditions, raw_condition = _map_conditions(policy.get("conditions", []))
        rule["conditions"] = conditions
        if raw_condition:
            rule["rawCondition"] = raw_condition

        return rule, None, None

    except Exception as e:
        return None, None, str(e)


def _can_represent_as_rule(policy: dict[str, Any]) -> bool:
    """Check if a Cedar policy can be represented as PolicyRule."""
    # Unless clauses can't be represented
    for cond in policy.get("conditions", []):
        if cond.get("kind") == "unless":
            return False

    # Template slots can't be represented
    principal = policy.get("principal", {})
    resource = policy.get("resource", {})
    if principal.get("slot") or resource.get("slot"):
        return False

    # Multiple entity "in" constraints are complex
    if principal.get("op") == "in":
        entities = principal.get("entities", [])
        if len(entities) > 1:
            return False

    if resource.get("op") == "in":
        entities = resource.get("entities", [])
        if len(entities) > 1:
            return False

    return True


def _extract_policy_cedar(policy_id: str, original_cedar: str) -> str:
    """Extract raw Cedar for a policy that can't be represented as PolicyRule."""
    # Simple fallback - return a comment with the policy ID
    # In production, you'd want to use cedarpy_conversor.convert_json_to_cedar_policies
    return f"// Complex policy: {policy_id}"


def _map_scope_to_entity(scope: dict[str, Any]) -> Optional[PolicyEntity]:
    """Map Cedar scope constraint to PolicyEntity."""
    op = scope.get("op", "All")

    if op == "All":
        return None
    elif op == "==":
        entity = scope.get("entity", {})
        if entity:
            return new_policy_entity(entity.get("type", ""), entity.get("id"))
    elif op == "is":
        entity_type = scope.get("entity_type", "")
        if entity_type:
            return new_policy_entity(entity_type)
    elif op == "in":
        # Single entity "in" - treat as specific entity
        entities = scope.get("entities", [])
        if len(entities) == 1:
            return new_policy_entity(entities[0].get("type", ""), entities[0].get("id"))
        # Single entity reference
        entity = scope.get("entity", {})
        if entity:
            return new_policy_entity(entity.get("type", ""), entity.get("id"))

    return None


def _map_action_scope(scope: dict[str, Any]) -> Union[str, list[str]]:
    """Map action scope to action string(s)."""
    op = scope.get("op", "All")

    if op == "All":
        return "*"
    elif op == "==":
        entity = scope.get("entity", {})
        return entity.get("id", "")
    elif op == "in":
        entities = scope.get("entities", [])
        if entities:
            actions = [e.get("id", "") for e in entities]
            return actions[0] if len(actions) == 1 else actions
        entity = scope.get("entity", {})
        return entity.get("id", "")

    return ""


def _map_conditions(
    conditions: list[dict[str, Any]],
) -> tuple[list[PolicyCondition], Optional[str]]:
    """Map Cedar conditions to PolicyCondition list."""
    result: list[PolicyCondition] = []
    raw_parts: list[str] = []

    for cond in conditions:
        if cond.get("kind") != "when":
            continue

        parsed, raw = _map_condition_body(cond.get("body", {}))
        if parsed:
            result.append(parsed)
        elif raw:
            raw_parts.append(raw)

    raw_condition = " && ".join(raw_parts) if raw_parts else None
    return result, raw_condition


def _map_condition_body(
    body: dict[str, Any],
) -> tuple[Optional[PolicyCondition], Optional[str]]:
    """
    Map a Cedar expression body to PolicyCondition.

    Cedar JSON expressions use nested objects with operator keys.
    Format: {"==": {"left": {".": {"left": {"Var": "context"}, "attr": "field"}}, "right": {"Value": "x"}}}
    """
    for op, args in body.items():
        if op in ("==", "!=", "<", "<=", ">", ">="):
            condition = _map_comparison(op, args)
            if condition:
                return condition, None
        elif op == "contains":
            condition = _map_contains(args)
            if condition:
                return condition, None
        elif op == "like":
            condition = _map_like(args)
            if condition:
                return condition, None

    # Can't map - return as raw JSON
    return None, json.dumps(body)


def _map_comparison(op: str, args: Any) -> Optional[PolicyCondition]:
    """Map a comparison expression to PolicyCondition."""
    if not isinstance(args, dict):
        return None

    left = args.get("left")
    right = args.get("right")
    if not left or not right:
        return None

    field = _extract_context_field(left)
    if not field:
        return None

    value = _extract_literal_value(right)
    if value is None:
        return None

    operator = _map_operator(op)
    if not operator:
        return None

    return new_policy_condition(field, operator, value)


def _map_contains(args: Any) -> Optional[PolicyCondition]:
    """Map a contains expression to PolicyCondition."""
    if not isinstance(args, dict):
        return None

    left = args.get("left")
    right = args.get("right")
    if not left or not right:
        return None

    field = _extract_context_field(left)
    if not field:
        return None

    value = _extract_literal_value(right)
    if value is None:
        return None

    return new_policy_condition(field, "contains", value)


def _map_like(args: Any) -> Optional[PolicyCondition]:
    """Map a like expression to PolicyCondition."""
    if not isinstance(args, dict):
        return None

    left = args.get("left")
    pattern = args.get("pattern")
    if not left or pattern is None:
        return None

    field = _extract_context_field(left)
    if not field:
        return None

    # Convert pattern list to string (e.g., ["Wildcard", {"Literal": "foo"}] -> "*foo")
    pattern_str = ""
    for p in pattern:
        if p == "Wildcard":
            pattern_str += "*"
        elif isinstance(p, dict) and "Literal" in p:
            pattern_str += p["Literal"]

    return new_policy_condition(field, "like", pattern_str)


def _extract_context_field(expr: Any) -> Optional[str]:
    """
    Extract field name from context.field access pattern.
    Pattern: {".": {"left": {"Var": "context"}, "attr": "field_name"}}
    """
    if not isinstance(expr, dict):
        return None

    dot_access = expr.get(".")
    if not isinstance(dot_access, dict):
        return None

    left = dot_access.get("left")
    if not isinstance(left, dict) or left.get("Var") != "context":
        return None

    attr = dot_access.get("attr")
    return attr if isinstance(attr, str) else None


def _extract_literal_value(
    expr: Any,
) -> Optional[Union[str, int, float, bool, list[str]]]:
    """
    Extract literal value from Cedar JSON.
    Pattern: {"Value": <literal>}
    """
    if not isinstance(expr, dict):
        return None

    value = expr.get("Value")
    if value is None:
        return None

    if isinstance(value, (str, int, float, bool)):
        return value

    if isinstance(value, list) and all(isinstance(v, str) for v in value):
        return value

    return None


def _map_operator(cedar_op: str) -> Optional[ConditionOperator]:
    """Map Cedar operator to ConditionOperator."""
    mapping: dict[str, ConditionOperator] = {
        "==": "eq",
        "!=": "neq",
        "<": "lt",
        "<=": "lte",
        ">": "gt",
        ">=": "gte",
    }
    return mapping.get(cedar_op)
