import aiko_services.main

__version__ = "v0.6"
__id__ = "2025-11-09_a"

from aiko_services.main import *
aiko.id = __id__        # aiko = main.process.ProcessData
process = aiko.process
