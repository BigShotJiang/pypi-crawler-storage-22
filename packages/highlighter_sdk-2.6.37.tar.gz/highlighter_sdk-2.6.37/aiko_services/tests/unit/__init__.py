# Declaration order is based on the dependency on static references
#
# To Do
# ~~~~~
# - None, yet !

from .common import do_create_pipeline
