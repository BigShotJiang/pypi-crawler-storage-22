SUPPORTED_IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png"}
