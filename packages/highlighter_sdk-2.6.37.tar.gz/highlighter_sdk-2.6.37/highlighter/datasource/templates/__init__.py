"""Template utilities for data sources."""
