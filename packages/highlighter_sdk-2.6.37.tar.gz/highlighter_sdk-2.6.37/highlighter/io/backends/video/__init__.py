"""Video backend implementations (PyAV, GStreamer, etc.)."""
