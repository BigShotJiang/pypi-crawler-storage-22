# {{ cookiecutter.title }}

{{ cookiecutter.short_description  }}

## Development

```shell
python -m venv venv
source venv/bin/activate
pip install -U pip -e .
```
