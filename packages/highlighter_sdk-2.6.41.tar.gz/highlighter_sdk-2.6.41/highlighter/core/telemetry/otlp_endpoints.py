from __future__ import annotations


def signal_endpoint(endpoint: str, signal: str) -> str:
    base = endpoint.rstrip("/")
    signals = ("traces", "metrics", "logs")
    if base.endswith(tuple(f"/{item}" for item in signals)) and "/v1/" not in base:
        return base
    for suffix in (f"/v1/{item}" for item in signals):
        if base.endswith(suffix):
            base = base[: -len(suffix)]
            break
    if base.endswith("/otlp"):
        base = f"{base}/v1"
    if not base.endswith("/v1") and "/otlp/v1" not in base:
        base = f"{base}/v1"
    return f"{base}/{signal}"
