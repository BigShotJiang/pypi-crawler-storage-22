"""ONNX Runtime (ORT) helpers for predictor modules."""
