#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "highs::highs" for configuration "Release"
set_property(TARGET highs::highs APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(highs::highs PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhighs.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhighs.dylib"
  )

list(APPEND _cmake_import_check_targets highs::highs )
list(APPEND _cmake_import_check_files_for_highs::highs "${_IMPORT_PREFIX}/lib/libhighs.dylib" )

# Import target "highs::OpenBLAS" for configuration "Release"
set_property(TARGET highs::OpenBLAS APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(highs::OpenBLAS PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libopenblas.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libopenblas.dylib"
  )

list(APPEND _cmake_import_check_targets highs::OpenBLAS )
list(APPEND _cmake_import_check_files_for_highs::OpenBLAS "${_IMPORT_PREFIX}/lib/libopenblas.dylib" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
