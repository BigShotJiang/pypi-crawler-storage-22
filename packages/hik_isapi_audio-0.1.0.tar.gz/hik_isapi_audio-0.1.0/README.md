
# hik_isapi_audio

`hik_isapi_audio` 是一个轻量级、高性能的 Python 异步客户端，专门用于与海康威视（Hikvision）摄像头进行 **ISAPI** 协议交互。

与市面上现有的库不同，本项目除了支持基础的云台操作外，**核心亮点在于对音频数据（Audio Data）的封装**，支持实时语音对讲、广播以及音频流的获取。

## ✨ 核心特性

* **语音对讲 (Audio Two-way):** 支持基于 `System/TwoWayAudio` 的音频流处理。
* **云台控制 (Access Control):** 轻松实现摄像头的旋转\倾斜操作。
* **简单易用:** 基于 `aiohttp` 的封装，自动处理 Digest 摘要认证。
* **流式传输:** 支持处理海康私有的音频打包格式，方便接入 AI 语音识别或播放器。

## 安装

### use pip
```shell
pip install hik_isapi_audio
pip install 'hik_isapi_audio[mic]'  # 可选依赖: 支持麦克风
```

### use uv
```shell
uv add hik_isapi_audio
uv add hik_isapi_audio --extra mic  # 可选依赖: 支持麦克风
```

## 🚀 快速开始

```python
import asyncio
from hik_isapi_audio import HikCameraControl

cam = HikCameraControl("192.168.1.64", "admin", "password")

# 1. 播放g711a格式音频文件
asyncio.run(cam.play_audio("tests/data/test.g711a"))

# 2. 云台移动
asyncio.run(cam.ptz_move(pan=50, duration=2))
asyncio.run(cam.ptz_move(pan=0, tilt=-10, duration=2))


# 3. 麦克风实时录制播放
async def test_mic_capture_task(cam):

    from hik_isapi_audio.mic import mic_capture_task, mic_data_generator

    queue = asyncio.Queue(maxsize=15)
    token = await cam.get_token_for_audio_data()
    await cam.voice_open()
    try:
        async with asyncio.TaskGroup() as tg:
            tg.create_task(mic_capture_task(queue))
            tg.create_task(cam.socket_send_task(mic_data_generator(queue), token))
    finally:
        await cam.voice_close()

asyncio.run(test_mic_capture_task(cam))
```

