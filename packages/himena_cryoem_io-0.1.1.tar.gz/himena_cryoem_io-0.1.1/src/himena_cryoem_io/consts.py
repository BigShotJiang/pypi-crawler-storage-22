class Type:
    IMOD_MODEL = "imodmodel"
    NAV = "text.serialem-nav"
    STAR = "text.star"


class MenuId:
    CRYOEM = "tools/cryoem"
    STAR = "tools/cryoem/star"
