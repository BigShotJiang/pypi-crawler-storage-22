"""Hindsight embedded CLI - local memory operations without a server."""

__version__ = "0.4.7"
