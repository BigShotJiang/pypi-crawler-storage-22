"""Tests for hindsight-embed."""
