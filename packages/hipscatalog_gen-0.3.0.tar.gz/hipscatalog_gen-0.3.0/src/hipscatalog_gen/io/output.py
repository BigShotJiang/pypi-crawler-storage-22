"""Writers for HiPS tiles, metadata, MOC, and density map products."""

from __future__ import annotations

import json
import os
from html import escape
from pathlib import Path
from typing import Any, Dict, List

import numpy as np
import pandas as pd
from astropy.io import fits
from astropy.io.votable import from_table
from astropy.io.votable import writeto as vot_writeto
from astropy.table import Table
from mocpy import MOC

from .. import __version__
from ..config import OutputCfg
from ..utils import _mkdirs, _now_str, _write_text

__all__ = [
    "TSVTileWriter",
    "write_properties",
    "write_arguments",
    "write_metadata_xml",
    "write_moc",
    "write_densmap_fits",
    "write_index_html",
    "finalize_write_tiles",
    "build_header_line_from_keep",
]


# =============================================================================
# Tile writer (TSV) and Allsky helpers
# =============================================================================


class TSVTileWriter:
    """Helper for writing HiPS catalogue tiles in TSV format.

    Args:
        out_dir: HiPS root output directory.
        depth: HiPS order (NorderX).
        header_line: Header line for TSV tiles (without completeness line).
    """

    def __init__(self, out_dir: Path, depth: int, header_line: str):
        """Initialize tile writer for a given depth.

        Args:
            out_dir: HiPS root output directory.
            depth: HiPS order (NorderX).
            header_line: Header line for TSV tiles (without completeness line).
        """
        self.depth = depth
        self.out_dir = out_dir
        self.norder_dir = out_dir / f"Norder{depth}"
        _mkdirs(self.norder_dir)
        self.header_line = header_line

    def _dir_for_ipix(self, ipix: int) -> Path:
        """Return directory path for a given HEALPix pixel."""
        base = (ipix // 10_000) * 10_000
        p = self.norder_dir / f"Dir{base}"
        _mkdirs(p)
        return p

    def allsky_tmp(self) -> Path:
        """Return temporary path for Allsky.tsv."""
        return self.norder_dir / ".Allsky.tsv"

    def allsky_path(self) -> Path:
        """Return final path for Allsky.tsv."""
        return self.norder_dir / "Allsky.tsv"

    def cell_tmp(self, ipix: int) -> Path:
        """Return temporary path for a given Npix tile."""
        return self._dir_for_ipix(ipix) / f".Npix{ipix}.tsv"

    def cell_path(self, ipix: int) -> Path:
        """Return final path for a given Npix tile."""
        return self._dir_for_ipix(ipix) / f"Npix{ipix}.tsv"


def finalize_write_tiles(
    out_dir: Path,
    depth: int,
    header_line: str,
    ra_col: str,
    dec_col: str,
    counts: np.ndarray,
    selected: pd.DataFrame,
    order_desc: bool,
    allsky_collect: bool = False,
) -> tuple[Dict[int, int], pd.DataFrame | None]:
    """Write one TSV per HEALPix cell and build optional Allsky dataframe.

    The function:
        * Writes a completeness header line.
        * Writes a single header line per tile.
        * Writes rows in the same column order as the header.
        * Uses atomic rename to avoid partial tiles.

    Args:
        out_dir: HiPS root output directory.
        depth: HiPS order.
        header_line: Header line for tiles.
        ra_col: RA column name (unused here but kept for interface stability).
        dec_col: DEC column name (unused here but kept for interface stability).
        counts: Densmap counts for this depth.
        selected: DataFrame with selected rows for this depth.
        order_desc: Whether scores were sorted in descending order (unused here).
        allsky_collect: If True, return a concatenated Allsky dataframe.

    Returns:
        Tuple (written, allsky_df) where:
            written: Mapping ipix -> number of rows written.
            allsky_df: DataFrame with all rows (if allsky_collect=True), else None.

    Raises:
        OSError: If tile files cannot be written or renamed.
    """
    writer = TSVTileWriter(out_dir, depth, header_line)
    npix = len(counts)
    written: Dict[int, int] = {}
    allsky_rows: List[List[str]] = []

    header_cols = header_line.strip("\n").split("\t")
    internal = {"__ipix__", "__score__", "__icov__"}
    tile_cols = [c for c in header_cols if c not in internal and c in selected.columns]

    if selected is None or len(selected) == 0 or len(tile_cols) == 0:
        return {}, None

    for pid, g in selected.groupby("__ipix__"):
        ip = int(pid)
        if ip < 0 or ip >= npix:
            continue

        n_src_cell = int(counts[ip])

        g_tile = g[tile_cols].copy()
        n_written = int(len(g_tile))
        written[ip] = n_written
        n_remaining = max(0, n_src_cell - n_written)

        completeness_header = f"# Completeness = {n_remaining} / {n_src_cell}\n"

        final_path = writer.cell_path(ip)
        final_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = final_path.with_name(f".Npix{ip}.tsv.tmp")

        # 1) Write completeness + header.
        with tmp.open("w", encoding="utf-8", newline="") as f:
            f.write(completeness_header)
            f.write(header_line)

        # Sanitize string columns (NestedFrame-safe: operate column by column).
        # On object columns containing only nulls, pandas replace(regex=True)
        # may hit a NumPy vectorize(empty) path and raise ValueError.
        obj_cols = list(g_tile.select_dtypes(include=["object", "string"]).columns)
        for col in obj_cols:
            col_values = g_tile[col]
            non_null_mask = col_values.notna()
            if not bool(non_null_mask.any()):
                continue
            g_tile.loc[non_null_mask, col] = (
                col_values.loc[non_null_mask].astype("string").str.replace(r"[\t\r\n]", " ", regex=True)
            )

        # 2) Append rows.
        g_tile.to_csv(
            tmp,
            sep="\t",
            index=False,
            header=False,
            mode="a",
            encoding="utf-8",
            lineterminator="\n",
        )

        os.replace(tmp, final_path)

        if allsky_collect and n_written > 0:
            allsky_rows.extend(g_tile.values.tolist())

    allsky_df: pd.DataFrame | None = None
    if allsky_collect and allsky_rows:
        allsky_df = pd.DataFrame(allsky_rows, columns=tile_cols)

    return written, allsky_df


def build_header_line_from_keep(keep_cols: List[str]) -> str:
    """Build header line from a list of column names."""
    return "\t".join([str(c) for c in keep_cols]) + "\n"


# =============================================================================
# Metadata writers (properties, metadata.xml, MOC, densmaps, arguments)
# =============================================================================


def write_properties(
    out_dir: Path,
    output_cfg: OutputCfg,
    level_limit: int,
    n_src: int,
    tile_format: str = "tsv",
) -> None:
    """Write HiPS 'properties' file for a catalogue HiPS.

    Args:
        out_dir: HiPS root output directory.
        output_cfg: Output configuration object.
        level_limit: Deepest HiPS order.
        n_src: Total number of catalogue sources.
        tile_format: Tile format string (usually "tsv").
    """
    now_iso = _now_str()
    label = output_cfg.cat_name

    publisher_did = output_cfg.creator_did or f"ivo://PRIVATE_USER/{label}"
    obs_title = output_cfg.obs_title or label
    publisher_id = "ivo://PRIVATE_USER"

    buf: List[str] = []
    buf.append("# Generated by the hipscatalog_gen tool (inspired by the CDS HiPS catalog tools).\n")
    buf.append(f"# hips_release_date generated at {now_iso} (UTC)\n")

    # Mandatory HiPS 1.4 keywords.
    buf.append(f"publisher_did   = {publisher_did}\n")
    buf.append(f"obs_title       = {obs_title}\n")
    buf.append("dataproduct_type  = catalog\n")
    buf.append("hips_version    = 1.4\n")
    buf.append(f"hips_release_date = {now_iso}\n")
    buf.append("hips_status     = public master unclonable\n")
    buf.append("hips_frame      = equatorial\n")
    buf.append(f"hips_order      = {level_limit}\n")
    buf.append(f"hips_tile_format  = {tile_format}\n")

    # Recommended/extra keywords.
    buf.append(f"publisher_id    = {publisher_id}\n")
    buf.append(f"hips_service_url  = {str(out_dir).rstrip('/')}/{label}\n")
    buf.append(f"hips_builder    = linea-it/hipscatalog_gen v{__version__}\n")
    buf.append(f"hips_cat_nrows  = {n_src}\n")

    # Optional initial view center.
    try:
        ra0, dec0 = output_cfg.target.split()
    except Exception:
        ra0, dec0 = "0", "0"
    buf.append(f"hips_initial_ra = {ra0}\n")
    buf.append(f"hips_initial_dec = {dec0}\n")

    # Legacy fields kept for compatibility.
    buf.append("# Deprecated but still kept for compatibility with some clients\n")
    buf.append(f"label={label}\n")
    buf.append("coordsys=C\n")

    _write_text(out_dir / "properties", "".join(buf))


def write_arguments(out_dir: Path, args_text: str) -> None:
    """Write command-line arguments used to run the pipeline.

    Args:
        out_dir: HiPS root output directory.
        args_text: Text blob to persist under ``arguments``.
    """
    _write_text(out_dir / "arguments", args_text)


def write_index_html(out_dir: Path, output_cfg: OutputCfg) -> None:
    """Write a simple index.html page for quick local catalog inspection."""
    cat_name = escape(output_cfg.cat_name)
    html_doc = f"""<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{cat_name} HiPS catalogue</title>
    <style>
      body {{ font-family: Arial, sans-serif; margin: 20px; line-height: 1.4; }}
      h1 {{ margin-bottom: 6px; }}
      .sub {{ color: #555; margin-top: 0; }}
      .layout {{ display: flex; gap: 20px; flex-wrap: wrap; }}
      #aladin-lite-div {{ width: 500px; height: 500px; max-width: 100%; border: 1px solid #ddd; }}
      #viewerStatus {{
        max-width: 500px;
        color: #8a4500;
        background: #fff4e8;
        padding: 8px 10px;
        border-radius: 6px;
      }}
      ul {{ margin: 0; padding-left: 18px; }}
      li {{ margin-bottom: 6px; }}
      code {{ background: #f5f5f5; padding: 2px 4px; border-radius: 4px; }}
    </style>
    <link rel="stylesheet" href="https://aladin.cds.unistra.fr/AladinLite/api/v3/latest/aladin.css">
    <script src="https://aladin.cds.unistra.fr/AladinLite/api/v3/latest/aladin.js"></script>
    <script>
      function baseUrl() {{
        const href = window.location.href;
        return href.substring(0, href.lastIndexOf("/") + 1);
      }}

      function setLink(id, url, text) {{
        const a = document.getElementById(id);
        a.href = url;
        if (text) a.textContent = text;
      }}

      window.addEventListener("load", function() {{
        const tabName = "{cat_name}";
        const isFile = window.location.protocol === "file:";
        const url = isFile ? "./" : baseUrl();
        document.querySelectorAll(".hipsNameSpan").forEach(el => el.textContent = tabName);

        setLink("hrefMetadata", url + "metadata.xml");
        setLink("hrefProperties", url + "properties");
        setLink("hrefMOC", url + "Moc.fits");
        setLink("hrefAll1", url + "Norder1/Allsky.tsv");
        setLink("hrefAll2", url + "Norder2/Allsky.tsv");
        setLink("hipsBase", url, url);
        document.getElementById("tilesUrl").innerHTML =
          url + "Norder<i>[0-orderMax]</i>/Dir<i>[0-9]*</i>/Npix<i>[0-ipixMax]</i>.tsv";

        const status = document.getElementById("viewerStatus");
        if (isFile) {{
          status.textContent =
            "Aladin preview is disabled in file:// mode (browser CORS). " +
            "Option 1: open a terminal in this same output directory (the one containing index.html), " +
            "run: python -m http.server 8000, then open http://localhost:8000/index.html. " +
            "Option 2: run: hipscatalog-gen serve --out <dir>";
          return;
        }}

        if (window.A && A.aladin && A.catalogHiPS) {{
          try {{
            const aladin = A.aladin("#aladin-lite-div", {{
              target: "0 +0",
              fov: 55,
              survey: "P/2MASS/color"
            }});
            const hips = A.catalogHiPS(url, {{ onClick: "showTable", name: tabName }});
            aladin.addCatalog(hips);
            status.textContent = "Aladin preview loaded.";
          }} catch (err) {{
            status.textContent = "Failed to initialize Aladin preview: " + String(err);
          }}
        }} else {{
          status.textContent = "Aladin script was not loaded. Check your network connection.";
        }}
      }});
    </script>
  </head>
  <body>
    <h1><span class="hipsNameSpan"></span> progressive catalogue</h1>
    <p class="sub">Quick local inspection page for a generated HiPS catalogue.</p>
    <div class="layout">
      <div>
        <div id="aladin-lite-div"></div>
        <p id="viewerStatus"></p>
      </div>
      <div>
        <ul>
          <li><b>Label:</b> <span class="hipsNameSpan"></span></li>
          <li><b>Type:</b> HiPS table</li>
          <li><b>Raw property file:</b> <a id="hrefProperties" href="">properties</a></li>
          <li><b>Metadata:</b> <a id="hrefMetadata" href="">metadata.xml</a></li>
          <li><b>Associated coverage map:</b> <a id="hrefMOC" href="">Moc.fits</a></li>
          <li><b>Base URL:</b> <a id="hipsBase" href=""></a></li>
          <li><b>Allsky level 1:</b> <a id="hrefAll1" href="">Allsky.tsv</a></li>
          <li><b>Allsky level 2:</b> <a id="hrefAll2" href="">Allsky.tsv</a></li>
          <li><b>Tiles URL format:</b> <span id="tilesUrl"></span></li>
        </ul>
      </div>
    </div>
  </body>
</html>
"""
    _write_text(out_dir / "index.html", html_doc)


def write_metadata_xml(
    out_dir: Path,
    columns: List[tuple[str, str, str | None]],
    ra_idx: int,
    dec_idx: int,
) -> None:
    """Write VOTable metadata (metadata.xml and Metadata.xml).

    Marks RA/DEC columns with appropriate UCDs.

    Args:
        out_dir: HiPS root output directory.
        columns: List of ``(name, dtype, ucd)`` tuples.
        ra_idx: Index of RA column in ``columns``.
        dec_idx: Index of DEC column in ``columns``.
    """
    table = Table()
    for name, dtype, _ucd in columns:  # _ucd intentionally unused here
        # Ensure consistent typing for mypy by declaring a neutral dtype
        np_dt: np.dtype[Any]
        dts = str(dtype)
        if dts.startswith("float"):
            np_dt = np.dtype("float64")
        elif dts.startswith("int"):
            np_dt = np.dtype("int64")
        else:
            np_dt = np.dtype("U1")
        table[name] = np.array([], dtype=np_dt)

    vot = from_table(table)
    res = vot.resources[0]
    vtab = res.tables[0]

    for i, field in enumerate(vtab.fields):
        field.name = columns[i][0]
        if i == ra_idx:
            field.ucd = "pos.eq.ra;meta.main"
        elif i == dec_idx:
            field.ucd = "pos.eq.dec;meta.main"
        else:
            field.ucd = columns[i][2] or field.ucd

    path_lower = str(out_dir / "metadata.xml")
    path_upper = str(out_dir / "Metadata.xml")
    try:
        vot_writeto(vot, path_lower)
    except TypeError:
        with open(path_lower, "wb") as fh:
            vot.to_xml(fh)
    try:
        vot_writeto(vot, path_upper)
    except TypeError:
        with open(path_upper, "wb") as fh:
            vot.to_xml(fh)


def write_moc(out_dir: Path, moc_order: int, dens_counts: np.ndarray) -> None:
    """Build and write MOC from densmap counts.

    Outputs both FITS (Moc.fits) and JSON (Moc.json) representations.

    Args:
        out_dir: HiPS root output directory.
        moc_order: HEALPix order used for the MOC.
        dens_counts: Densmap counts at the MOC order.

    Raises:
        RuntimeError: If MOC construction fails for all attempted mocpy builders.
    """
    order = int(moc_order)
    ipix = np.flatnonzero(dens_counts > 0)

    if ipix.size == 0:
        moc = MOC.empty(order)
    else:
        ipix_list = [int(x) for x in np.asarray(ipix, dtype=np.int64).tolist()]
        nside = 1 << order
        ipix_arr = np.asarray(ipix_list, dtype=np.uint64)
        depth_arr = np.full(ipix_arr.shape, order, dtype=np.uint8)

        moc = None
        last_err: Exception | None = None
        # Prefer explicit keyword signatures first to avoid ambiguous positional
        # calls that can be interpreted differently across mocpy versions.
        candidates = [
            # mocpy >= 0.19
            lambda: MOC.from_healpix_cells(ipix=ipix_arr, depth=depth_arr, max_depth=order),
            lambda: MOC.from_healpix_cells(ipix=ipix_arr, depth=order, max_depth=order),
            # older/alternate mocpy variants
            lambda: MOC.from_healpix_cells(nside=nside, ipix=ipix_list, max_depth=order, nested=True),
            lambda: MOC.from_healpix_cells(nside=nside, ipix=ipix_list, max_depth=order),
            lambda: MOC.from_healpix_cells(ipix=ipix_list, max_depth=order, nested=True),
            lambda: MOC.from_healpix_cells(ipix=ipix_list, max_depth=order),
            lambda: MOC.from_healpix_cells(ipix=ipix_list, depth=order, nested=True),
            lambda: MOC.from_healpix_cells(ipix=ipix_list, depth=order),
            # Legacy fallbacks (positional variants used in older mocpy builds).
            lambda: MOC.from_healpix_cells(nside, ipix_list, order, True),
            lambda: MOC.from_healpix_cells(nside, ipix_list, order),
            lambda: MOC.from_healpix_cells(order, ipix_list, True),
            lambda: MOC.from_healpix_cells(order, ipix_list),
            lambda: MOC.from_healpix_cells(ipix_list, order, True),
            lambda: MOC.from_healpix_cells(ipix_list, order),
        ]
        for builder in candidates:
            try:
                moc = builder()
                break
            except Exception as e:  # noqa: PERF203
                last_err = e
                continue
        if moc is None:
            raise RuntimeError(
                "Failed to build MOC with your mocpy version. "
                f"Last error: {type(last_err).__name__}: {last_err}"
            )

    fits_path = out_dir / "Moc.fits"
    try:
        try:
            moc.save(str(fits_path), "fits")
        except TypeError:
            moc.save(str(fits_path), format="fits")
    except Exception:
        moc.write(fits_path, overwrite=True)

    json_path = out_dir / "Moc.json"
    data = moc.serialize(format="json")
    with json_path.open("w", encoding="utf-8") as f:
        if isinstance(data, str):
            f.write(data)
        elif isinstance(data, bytes):
            f.write(data.decode("utf-8"))
        else:
            json.dump(data, f)


def write_densmap_fits(out_dir: Path, depth: int, counts: np.ndarray) -> None:
    """Write densmap_o<depth>.fits for depths < 13.

    Args:
        out_dir: HiPS root output directory.
        depth: HEALPix order (depth).
        counts: Counts per pixel at this depth.
    """
    if depth >= 13:
        return
    hdu0 = fits.PrimaryHDU()
    col = fits.Column(name="VALUE", array=counts.astype(np.int64), format="K")
    hdu1 = fits.BinTableHDU.from_columns([col])
    fits.HDUList([hdu0, hdu1]).writeto(out_dir / f"densmap_o{depth}.fits", overwrite=True)
