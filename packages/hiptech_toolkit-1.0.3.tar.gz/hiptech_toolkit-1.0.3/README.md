<p align="center">
  <img src="./assets/logo.png" width="160" />
</p>

<h1 align="center">HIPTECH Toolkit</h1>

<p align="center">
  Internal Python toolkit by HIPTECH Solution Company Limited
</p>

[![Odoo Version](https://img.shields.io/badge/Odoo-19.x-blue)](https://www.odoo.com)
[![License](https://img.shields.io/badge/License-Proprietary-red)]()
[![Status](https://img.shields.io/badge/Status-Active-green)]()

**HIPTECH Toolkit** is a proprietary Python utility library developed and owned by  
**HIPTECH Solution Company Limited**.

The toolkit provides standardized, reusable components for internal software
development, including Odoo modules, backend services, and third-party system
integrations.

---

## Purpose

The purpose of this library is to:

- Centralize common technical utilities
- Enforce consistent API integration patterns
- Reduce duplicated code across projects
- Improve maintainability and code quality

This package is intended **strictly for internal or licensed use**.

---

## Features

- HTTP client abstraction with retry and timeout handling
- Authentication helpers (Bearer, custom headers, signatures)
- Manager and service layers for external API integrations
- Designed for enterprise and Odoo-based architectures

---

## Package Structure

```text
hiptech/
    └── http/
        ├── __init__.py
        ├── auth.py
        ├── connector.py
        └── manager.py
```

## 🧩 Usage Example

```py

from hiptech.http import ConnectorRegistry


# New Connection
conn = ConnectorRegistry(
    base_url="https://api.example.com",
    token="YOUR_TOKEN"
)

response = manager.get("/v1/users")

# Cleanup connection
ConnectorRegistry.cleanup()

```
