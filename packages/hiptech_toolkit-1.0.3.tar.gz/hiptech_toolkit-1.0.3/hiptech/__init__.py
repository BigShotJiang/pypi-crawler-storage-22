# Proprietary and Confidential
# Copyright (c) HIPTECH Solution Company Limited
