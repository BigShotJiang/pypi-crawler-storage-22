# Proprietary and Confidential
# Copyright (c) HIPTECH Solution Company Limited

# -*- coding: utf-8 -*-
import time
import logging
from typing import Optional, Dict, Any
import requests
import json
from ..http.connector import BaseAPIConnector

_logger = logging.getLogger(__name__)


class HaravanAPIConnector(BaseAPIConnector):
    def __init__(
        self,
        base_url: str,
        timeout: int = 30,
        default_headers: Optional[Dict[str, str]] = None,
        retries: int = 3,
        backoff_factor: float = 0.5,
        auth=None,
        rate_limit_retry: bool = True,
        rate_limit_max_wait: int = 60,
    ):
        """
        Initialize Haravan API Connector
        
        Args:
            base_url: Base URL for the API
            timeout: Request timeout in seconds
            default_headers: Default headers for all requests
            retries: Number of retries on error
            backoff_factor: Backoff factor for retry
            auth: Authentication strategy
            rate_limit_retry: Whether to retry on rate limit (429)
            rate_limit_max_wait: Maximum wait time for rate limit (seconds)
        """
        super().__init__(
            base_url=base_url,
            timeout=timeout,
            default_headers=default_headers,
            retries=retries,
            backoff_factor=backoff_factor,
            auth=auth,
        )
        self.rate_limit_retry = rate_limit_retry
        self.rate_limit_max_wait = rate_limit_max_wait

    def _handle_rate_limit(self, response: requests.Response) -> Optional[int]:
        """
        Handle rate limit response by reading headers from 429 response
        """
        if response.status_code != 429:
            return None
        
        if not self.rate_limit_retry:
            return None
        
        retry_after = response.headers.get("Retry-After")
        if retry_after:
            try:
                wait_time = int(retry_after)
                # Cap at max_wait
                wait_time = min(wait_time, self.rate_limit_max_wait)
                _logger.warning(
                    "Rate limit hit (429), waiting %d seconds from Retry-After header: %s",
                    wait_time,
                    retry_after
                )
                return wait_time
            except (ValueError, TypeError) as e:
                _logger.warning(
                    "Invalid Retry-After header value: %s, error: %s",
                    retry_after,
                    e
                )
        
        # Default wait time if no header available
        default_wait = 5
        _logger.warning(
            "Rate limit hit (429), no Retry-After header found. "
            "Using default wait time: %d seconds. Headers: %s",
            default_wait,
            dict(response.headers)
        )
        return default_wait

    def request(
        self,
        method: str,
        endpoint: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        data: Any = None,
        json: Any = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: Optional[int] = None,
        max_rate_limit_retries: int = 3,
    ):
        """
        Make HTTP request with rate limit handling
        
        Args:
            method: HTTP method
            endpoint: API endpoint (will be normalized with .json suffix)
            params: Query parameters
            data: Form data
            json: JSON data
            headers: Additional headers
            timeout: Request timeout
            max_rate_limit_retries: Maximum retries for rate limit
            
        Returns:
            Response object
        """
        
        # Retry loop for rate limiting
        rate_limit_retries = 0
        resp = None
        while rate_limit_retries <= max_rate_limit_retries:
            resp = super(HaravanAPIConnector, self).request(
                method=method,
                endpoint=endpoint,
                params=params,
                data=data,
                json=json,
                headers=headers,
                timeout=timeout,
            )

            # Handle rate limit - read wait time from headers
            if resp.status_code == 429:
                wait_time = self._handle_rate_limit(resp)
                if wait_time and rate_limit_retries < max_rate_limit_retries:
                    time.sleep(wait_time)
                    rate_limit_retries += 1
                    continue
                else:
                    # Max retries reached or should not retry
                    url = f"{self.base_url}/{endpoint.lstrip('/')}"
                    _logger.error(
                        "Rate limit exceeded after %d retries: %s %s",
                        rate_limit_retries,
                        method.upper(),
                        url
                    )
                    # Raise error for rate limit
                    resp.raise_for_status()
                    return resp

            return resp

        if resp is None:
            raise RuntimeError("No response received after rate limit retries")
        return resp