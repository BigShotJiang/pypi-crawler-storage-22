# Proprietary and Confidential
# Copyright (c) HIPTECH Solution Company Limited

# -*- coding: utf-8 -*-
from .manager import ConnectorRegistry

__all__ = ["ConnectorRegistry"]
