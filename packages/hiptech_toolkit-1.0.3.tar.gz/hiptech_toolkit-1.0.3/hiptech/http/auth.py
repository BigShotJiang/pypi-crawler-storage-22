# Proprietary and Confidential
# Copyright (c) HIPTECH Solution Company Limited

# -*- coding: utf-8 -*-
from abc import ABC, abstractmethod
import base64
from typing import Dict


class BaseAuthStrategy(ABC):
    """
    Base authentication strategy interface.

    All authentication strategies must implement `get_headers`.
    """

    @abstractmethod
    def get_headers(self) -> Dict[str, str]:
        """
        Return HTTP headers used for authentication.
        """
        raise NotImplementedError


class NoAuthStrategy(BaseAuthStrategy):
    """
    No authentication.
    Useful for public or internal APIs.
    """

    def get_headers(self) -> Dict[str, str]:
        return {}


class BasicAuthStrategy(BaseAuthStrategy):
    """
    HTTP Basic Authentication strategy.
    """

    def __init__(self, username: str, password: str):
        self.username = username
        self.password = password

    def get_headers(self) -> Dict[str, str]:
        raw = f"{self.username}:{self.password}".encode("utf-8")
        token = base64.b64encode(raw).decode("utf-8")
        return {
            "Authorization": f"Basic {token}",
        }


class BearerAuthStrategy(BaseAuthStrategy):
    """
    Bearer token authentication strategy (JWT, OAuth access token, etc).
    """

    def __init__(self, token: str):
        self.token = token

    def get_headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.token}",
        }


class ApiKeyAuthStrategy(BaseAuthStrategy):
    """
    API Key authentication strategy.
    """

    def __init__(self, api_key: str, header_name: str = "X-API-KEY"):
        self.api_key = api_key
        self.header_name = header_name

    def get_headers(self) -> Dict[str, str]:
        return {
            self.header_name: self.api_key,
        }


class CustomHeaderAuthStrategy(BaseAuthStrategy):
    """
    Custom header-based authentication strategy.
    """

    def __init__(self, headers: Dict[str, str]):
        self.headers = dict(headers)

    def get_headers(self) -> Dict[str, str]:
        return dict(self.headers)


__all__ = [
    "BaseAuthStrategy",
    "NoAuthStrategy",
    "BasicAuthStrategy",
    "BearerAuthStrategy",
    "ApiKeyAuthStrategy",
    "OAuth2AuthStrategy",
    "CustomHeaderAuthStrategy",
]
