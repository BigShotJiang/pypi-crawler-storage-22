# Proprietary and Confidential
# Copyright (c) HIPTECH Solution Company Limited


# -*- coding: utf-8 -*-
import time
import logging
from typing import Any, Dict, Optional
import requests
import json
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

_logger = logging.getLogger(__name__)


class BaseAPIConnector:
    def __init__(
        self,
        base_url: str,
        timeout: int = 30,
        default_headers: Optional[Dict[str, str]] = None,
        retries: int = 3,
        backoff_factor: float = 0.5,
        auth=None,
    ):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.default_headers = default_headers or {}
        self.auth = auth

        self.session = requests.Session()
        self._init_retry(retries, backoff_factor)

    def _init_retry(self, retries: int, backoff_factor: float):
        retry = Retry(
            total=retries,
            read=retries,
            connect=retries,
            status=retries,
            backoff_factor=backoff_factor,
            status_forcelist=(429, 500, 502, 503, 504),
            allowed_methods=frozenset(
                ["GET", "POST", "PUT", "DELETE", "PATCH"]),
            raise_on_status=False,
        )
        adapter = HTTPAdapter(
            max_retries=retry, pool_connections=10, pool_maxsize=10)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)

    def build_headers(self) -> Dict[str, str]:
        headers = {}
        headers.update(self.default_headers)

        if self.auth:
            headers.update(self.auth.get_headers())

        return headers

    def request(
        self,
        method: str,
        endpoint: str,
        *,
        params=None,
        data=None,
        json=None,
        headers=None,
        timeout=None,
    ):
        url = f"{self.base_url}/{endpoint.lstrip('/')}"

        req_headers = self.build_headers()
        if headers:
            req_headers.update(headers)

        start = time.time()
        resp = self.session.request(
            method=method.upper(),
            url=url,
            params=params,
            data=data,
            json=json,
            headers=req_headers,
            timeout=timeout or self.timeout,
        )
        elapsed = time.time() - start

        _logger.info(
            "API %s %s -> %s (%.2fs)",
            method.upper(),
            url,
            resp.status_code,
            elapsed,
        )

        return resp
    
    def handle_response(self, response: requests.Response) -> Any:
        """
        Parse JSON response or return text
        
        Args:
            response: Response object
            
        Returns:
            Parsed JSON data or text content
        """
        if not response.ok:
            _logger.error(
                "Haravan API Error %s %s - %s",
                response.status_code,
                response.url,
                response.text[:500],
            )
            response.raise_for_status()

        return json.loads(response.text)
    
    def get(self, endpoint, **kw):
        return self.request("GET", endpoint, **kw)

    def post(self, endpoint, **kw):
        return self.request("POST", endpoint, **kw)

    def put(self, endpoint, **kw):
        return self.request("PUT", endpoint, **kw)

    def delete(self, endpoint, **kw):
        return self.request("DELETE", endpoint, **kw)
