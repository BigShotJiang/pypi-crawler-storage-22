# Proprietary and Confidential
# Copyright (c) HIPTECH Solution Company Limited

# -*- coding: utf-8 -*-
import time
from threading import Lock
from .connector import BaseAPIConnector
from .auth import BasicAuthStrategy,BearerAuthStrategy,ApiKeyAuthStrategy,CustomHeaderAuthStrategy

class ConnectorRegistry:
    _lock = Lock()
    _cache = {}
    _last_used = {}
    _TTL = 60 * 30

    @classmethod
    def factory(cls, base_url: str, auth:BasicAuthStrategy | BearerAuthStrategy | ApiKeyAuthStrategy | CustomHeaderAuthStrategy):
        if isinstance(auth, BasicAuthStrategy):
            key = (base_url, auth.username)
        elif isinstance(auth, BearerAuthStrategy):
            key = (base_url, auth.token)
        elif isinstance(auth, ApiKeyAuthStrategy):
            key = (base_url, auth.api_key)
        else:
            key = (base_url, auth.headers) 
            

        now = time.time()
        with cls._lock:
            conn = cls._cache.get(key)

            if not conn:
                conn = BaseAPIConnector(base_url=base_url, auth=auth)
                cls._cache[key] = conn

            cls._last_used[key] = now
            return conn

    @classmethod
    def cleanup(cls):
        now = time.time()
        with cls._lock:
            for key in list(cls._cache.keys()):
                last = cls._last_used.get(key, 0)
                if now - last > cls._TTL:
                    conn = cls._cache.pop(key)
                    cls._last_used.pop(key, None)
                    try:
                        conn.session.close()
                    except Exception:
                        pass
