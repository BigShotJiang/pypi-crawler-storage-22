# Hisia Python SDK

Official Python SDK for the Hisia Climate Intelligence Platform - Earth observation and climate data APIs for Africa.

[![PyPI version](https://badge.fury.io/py/hisia-sdk.svg)](https://badge.fury.io/py/hisia-sdk)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Installation

```bash
pip install hisia-sdk
```

## Quick Start

```python
from hisia import Hisia

# Initialize client (uses HISIA_API_KEY env var by default)
client = Hisia(api_key="hs_...")

# List available datasets
datasets = client.datasets.list(limit=10)
for ds in datasets:
    print(f"{ds.name}: {ds.description}")

# Search satellite imagery by location
imagery = client.satellite.search(
    bbox=[36.7, -1.3, 36.9, -1.1],  # Nairobi area
    sensor="sentinel-2-l2a",
    start_date="2025-01-01",
    end_date="2025-01-31"
)

# Calculate vegetation indices
ndvi = client.indices.calculate(
    latitude=-1.2921,
    longitude=36.8219,
    index="NDVI",
    start_date="2025-01-01",
    end_date="2025-06-30"
)
```

## Async Support

```python
from hisia import AsyncHisia
import asyncio

async def main():
    async with AsyncHisia(api_key="hs_...") as client:
        datasets = await client.datasets.list()
        print(datasets)

asyncio.run(main())
```

## Configuration

| Environment Variable | Description |
|---------------------|-------------|
| `HISIA_API_KEY` | Your API key (get one at https://akili.hisia.space/developer/keys) |
| `HISIA_BASE_URL` | API base URL (default: https://api.hisia.space/v1) |

## Available Resources

- **datasets** - Browse and query climate datasets
- **satellite** - Search satellite imagery (Sentinel-2, Landsat, etc.)
- **indices** - Calculate vegetation indices (NDVI, EVI, SAVI, etc.)
- **pipelines** - Run data processing pipelines
- **models** - Access ML models for predictions

## Documentation

Full documentation: https://docs.hisia.space/sdk/python

## Support

- Issues: https://github.com/Hisia-Space/Akili/issues
- Email: support@hisia.space

