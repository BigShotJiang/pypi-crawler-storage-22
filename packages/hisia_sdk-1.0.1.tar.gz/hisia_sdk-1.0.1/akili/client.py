"""
Akili SDK Client

Main client class with resource-based API access (like OpenAI SDK).

Usage:
    from akili import Akili
    
    client = Akili(api_key="your-key")
    
    # Segmentation
    job = client.segment.create(...)
    result = client.segment.get(job.job_id)
    
    # Evidence
    pack = client.evidence.create(execution_id=result.job_id)
    
    # Data access
    veg = client.data.vegetation(lat=-1.29, lon=36.82, ...)
"""

from __future__ import annotations

import os
import time
from typing import Any, Dict, List, Optional, Union
from urllib.parse import urljoin

import httpx

from .errors import (
    AkiliAPIError,
    AkiliAuthenticationError,
    AkiliConnectionError,
    AkiliNotFoundError,
    AkiliRateLimitError,
    AkiliTimeoutError,
)
from .types import (
    CertificationType,
    Dataset,
    EvidenceFormat,
    EvidencePackRequest,
    EvidencePackResponse,
    GeoJSONPolygon,
    JobStatus,
    JobStatusResponse,
    ModelInfo,
    OutputFormat,
    ProvenanceChain,
    ProvenanceInfo,
    RainfallResponse,
    SegmentationModel,
    SegmentationRequest,
    SegmentationResponse,
    VegetationResponse,
)


DEFAULT_BASE_URL = "https://api.akili.ai/api/v1"
DEFAULT_TIMEOUT = 60.0
SDK_VERSION = "1.0.0"


class Akili:
    """
    Akili Climate Intelligence API Client.

    Args:
        api_key: API key for authentication. If not provided, reads from
            AKILI_API_KEY environment variable.
        base_url: Base URL for the API. Defaults to production.
        timeout: Request timeout in seconds.
        max_retries: Maximum number of retries for failed requests.

    Example:
        >>> from akili import Akili
        >>> client = Akili(api_key="ak-...")
        >>> job = client.segment.create(
        ...     aoi={"type": "Polygon", "coordinates": [...]},
        ...     datetime_range=["2025-01-01", "2025-01-15"],
        ...     model="prithvi-flood-v1"
        ... )
        >>> print(job.job_id)
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: Optional[str] = None,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = 3,
    ) -> None:
        self.api_key = api_key or os.environ.get("AKILI_API_KEY")
        if not self.api_key:
            raise AkiliAuthenticationError(
                "No API key provided. Pass api_key or set AKILI_API_KEY environment variable."
            )

        self.base_url = (
            base_url or os.environ.get("AKILI_BASE_URL", DEFAULT_BASE_URL)
        ).rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries

        # HTTP client with retries
        self._client = httpx.Client(
            base_url=self.base_url,
            timeout=timeout,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "User-Agent": f"akili-python/{SDK_VERSION}",
                "Accept": "application/json",
            },
        )

        # Resource namespaces (like OpenAI's client.chat.completions)
        self.segment = SegmentResource(self)
        self.evidence = EvidenceResource(self)
        self.data = DataResource(self)
        self.search = SearchResource(self)

    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self) -> "Akili":
        return self

    def __exit__(self, *args) -> None:
        self.close()

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Make an HTTP request with retry logic."""
        last_error: Optional[Exception] = None

        for attempt in range(self.max_retries + 1):
            try:
                response = self._client.request(
                    method=method,
                    url=path,
                    params=params,
                    json=json,
                )

                # Handle errors
                if response.status_code == 401:
                    raise AkiliAuthenticationError()

                if response.status_code == 404:
                    body = response.json()
                    raise AkiliNotFoundError("Resource", path)

                if response.status_code == 429:
                    retry_after = response.headers.get("Retry-After")
                    raise AkiliRateLimitError(
                        retry_after=int(retry_after) if retry_after else None
                    )

                if response.status_code >= 400:
                    body = response.json()
                    raise AkiliAPIError.from_response(response.status_code, body)

                return response.json()

            except httpx.TimeoutException as e:
                last_error = AkiliTimeoutError(self.timeout)
                if attempt < self.max_retries:
                    time.sleep(2**attempt)  # Exponential backoff
                    continue
                raise last_error

            except httpx.ConnectError as e:
                last_error = AkiliConnectionError(str(e), e)
                if attempt < self.max_retries:
                    time.sleep(2**attempt)
                    continue
                raise last_error

            except AkiliRateLimitError as e:
                last_error = e
                if attempt < self.max_retries and e.retry_after:
                    time.sleep(min(e.retry_after, 60))
                    continue
                raise

        raise last_error or AkiliConnectionError("Request failed after retries")


# =============================================================================
# Resource Classes (OpenAI-style)
# =============================================================================


class SegmentResource:
    """Segmentation API resource.

    Usage:
        job = client.segment.create(aoi=..., model="prithvi-flood-v1")
        result = client.segment.get(job.job_id)
        provenance = client.segment.provenance(job.job_id)
    """

    def __init__(self, client: Akili) -> None:
        self._client = client

    def create(
        self,
        aoi: Union[GeoJSONPolygon, Dict[str, Any]],
        datetime_range: List[str],
        *,
        model: Union[SegmentationModel, str] = SegmentationModel.PRITHVI_FLOOD_V1,
        sensors: Optional[List[str]] = None,
        output_format: Union[OutputFormat, str] = OutputFormat.BOTH,
        cloud_cover_max: float = 30.0,
        min_confidence: float = 0.5,
    ) -> SegmentationResponse:
        """
        Create a segmentation job.

        Args:
            aoi: Area of Interest as GeoJSON Polygon
            datetime_range: [start_date, end_date] in YYYY-MM-DD format
            model: Segmentation model to use
            sensors: List of sensors (default: ["sentinel-2"])
            output_format: Output format (cog, geojson, both)
            cloud_cover_max: Maximum cloud cover percentage
            min_confidence: Minimum confidence threshold

        Returns:
            SegmentationResponse with job_id and initial status
        """
        request = SegmentationRequest(
            aoi=aoi,
            datetime_range=datetime_range,
            model=SegmentationModel(model) if isinstance(model, str) else model,
            sensors=sensors or ["sentinel-2"],
            output_format=(
                OutputFormat(output_format)
                if isinstance(output_format, str)
                else output_format
            ),
            cloud_cover_max=cloud_cover_max,
            min_confidence=min_confidence,
        )

        response = self._client._request(
            "POST", "/modele/segment", json=request.to_dict()
        )
        return SegmentationResponse.from_dict(response)

    def get(self, job_id: str) -> JobStatusResponse:
        """
        Get the status and results of a segmentation job.

        Args:
            job_id: The job ID returned from create()

        Returns:
            JobStatusResponse with status and results if complete
        """
        response = self._client._request("GET", f"/modele/segment/{job_id}")
        return JobStatusResponse.from_dict(response)

    def provenance(self, job_id: str) -> ProvenanceInfo:
        """
        Get provenance information for a completed job.

        Args:
            job_id: The job ID

        Returns:
            ProvenanceInfo with data lineage details
        """
        response = self._client._request("GET", f"/modele/segment/{job_id}/provenance")
        return ProvenanceInfo.from_dict(response)

    def models(self) -> List[ModelInfo]:
        """
        List available segmentation models.

        Returns:
            List of ModelInfo objects
        """
        response = self._client._request("GET", "/modele/segment/models")
        return [ModelInfo.from_dict(m) for m in response]

    def wait_for_completion(
        self,
        job_id: str,
        *,
        poll_interval: float = 5.0,
        timeout: float = 600.0,
    ) -> SegmentationResponse:
        """
        Wait for a job to complete, polling periodically.

        Args:
            job_id: The job ID
            poll_interval: Seconds between status checks
            timeout: Maximum seconds to wait

        Returns:
            SegmentationResponse with final results

        Raises:
            AkiliTimeoutError: If job doesn't complete within timeout
            AkiliAPIError: If job fails
        """
        start = time.time()
        while True:
            status = self.get(job_id)

            if status.status == JobStatus.COMPLETED:
                return status.result

            if status.status == JobStatus.FAILED:
                raise AkiliAPIError(
                    message=status.message or "Job failed",
                    status_code=500,
                    error_code="job_failed",
                )

            if time.time() - start > timeout:
                raise AkiliTimeoutError(timeout, f"Job {job_id}")

            time.sleep(poll_interval)


class EvidenceResource:
    """Evidence Pack API resource.

    Usage:
        pack = client.evidence.create(execution_id="...")
        chain = client.evidence.provenance(execution_id="...")
    """

    def __init__(self, client: Akili) -> None:
        self._client = client

    def create(
        self,
        execution_id: str,
        *,
        format: Union[EvidenceFormat, str] = EvidenceFormat.JSON,
        include_imagery: bool = True,
        include_masks: bool = True,
        sign: bool = True,
        certification_type: Optional[Union[CertificationType, str]] = None,
    ) -> EvidencePackResponse:
        """
        Generate an evidence pack for a completed job.

        Args:
            execution_id: Job/execution ID to package
            format: Output format (json, pdf, zip)
            include_imagery: Include original imagery
            include_masks: Include segmentation masks
            sign: Generate cryptographic signature
            certification_type: Certification standard to follow

        Returns:
            EvidencePackResponse with download URL
        """
        cert_type = None
        if certification_type:
            cert_type = (
                CertificationType(certification_type)
                if isinstance(certification_type, str)
                else certification_type
            )

        request = EvidencePackRequest(
            execution_id=execution_id,
            format=EvidenceFormat(format) if isinstance(format, str) else format,
            include_imagery=include_imagery,
            include_masks=include_masks,
            sign=sign,
            certification_type=cert_type,
        )

        response = self._client._request(
            "POST", "/modele/evidence", json=request.to_dict()
        )
        return EvidencePackResponse.from_dict(response)

    def provenance(self, execution_id: str) -> ProvenanceChain:
        """
        Get the full provenance chain for an execution.

        Args:
            execution_id: The execution/job ID

        Returns:
            ProvenanceChain with complete data lineage
        """
        response = self._client._request(
            "GET", f"/modele/evidence/{execution_id}/provenance"
        )
        return ProvenanceChain.from_dict(response)

    def certifications(self) -> List[Dict[str, Any]]:
        """
        List supported certification standards.

        Returns:
            List of certification info dicts
        """
        response = self._client._request("GET", "/modele/evidence/certifications")
        return response.get("certifications", [])


class DataResource:
    """Data Access API resource.

    Usage:
        veg = client.data.vegetation(lat=-1.29, lon=36.82, ...)
        rain = client.data.rainfall(lat=-1.29, lon=36.82, ...)
    """

    def __init__(self, client: Akili) -> None:
        self._client = client

    def vegetation(
        self,
        lat: float,
        lon: float,
        start_date: str,
        end_date: str,
    ) -> VegetationResponse:
        """
        Get vegetation indices time series.

        Args:
            lat: Latitude
            lon: Longitude
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)

        Returns:
            VegetationResponse with NDVI, EVI, etc.
        """
        response = self._client._request(
            "GET",
            "/flow/satellite/vegetation",
            params={
                "lat": lat,
                "lon": lon,
                "start_date": start_date,
                "end_date": end_date,
            },
        )
        return VegetationResponse.from_dict(response)

    def rainfall(
        self,
        lat: float,
        lon: float,
        start_date: str,
        end_date: str,
        *,
        frequency: str = "daily",
    ) -> RainfallResponse:
        """
        Get rainfall data time series.

        Args:
            lat: Latitude
            lon: Longitude
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            frequency: "daily" or "monthly"

        Returns:
            RainfallResponse with rainfall_mm values
        """
        response = self._client._request(
            "GET",
            "/flow/satellite/rainfall",
            params={
                "lat": lat,
                "lon": lon,
                "start_date": start_date,
                "end_date": end_date,
                "frequency": frequency,
            },
        )
        return RainfallResponse.from_dict(response)

    def search_imagery(
        self,
        bbox: List[float],
        datetime: str,
        *,
        collections: Optional[List[str]] = None,
        cloud_cover_max: float = 30.0,
        limit: int = 10,
    ) -> Dict[str, Any]:
        """
        Search for satellite imagery.

        Args:
            bbox: Bounding box [west, south, east, north]
            datetime: Date range (e.g., "2025-01-01/2025-01-15")
            collections: STAC collections to search
            cloud_cover_max: Maximum cloud cover %
            limit: Maximum results

        Returns:
            STAC FeatureCollection
        """
        response = self._client._request(
            "POST",
            "/flow/satellite/search",
            json={
                "bbox": bbox,
                "datetime": datetime,
                "collections": collections or ["sentinel-2-l2a"],
                "cloud_cover_max": cloud_cover_max,
                "limit": limit,
            },
        )
        return response


class SearchResource:
    """Search/Discovery API resource.

    Usage:
        datasets = client.search.datasets(category="satellite")
    """

    def __init__(self, client: Akili) -> None:
        self._client = client

    def datasets(
        self,
        *,
        category: Optional[str] = None,
        region: Optional[str] = None,
    ) -> List[Dataset]:
        """
        List available datasets.

        Args:
            category: Filter by category (satellite, weather, sensor, derived)
            region: Filter by region (e.g., "east-africa", "kenya")

        Returns:
            List of Dataset objects
        """
        params = {}
        if category:
            params["category"] = category
        if region:
            params["region"] = region

        response = self._client._request("GET", "/flow/datasets", params=params)
        return [Dataset.from_dict(d) for d in response]
