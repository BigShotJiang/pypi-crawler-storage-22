"""
Akili SDK Error Classes

Standardized error handling for all API interactions.
"""

from __future__ import annotations

from typing import Any, Dict, Optional


class AkiliError(Exception):
    """Base exception for all Akili SDK errors."""

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)


class AkiliAPIError(AkiliError):
    """Error returned from the Akili API.

    Attributes:
        status_code: HTTP status code
        error_code: API error code (e.g., 'rate_limited', 'invalid_request')
        message: Human-readable error message
        request_id: Request ID for debugging
    """

    def __init__(
        self,
        message: str,
        status_code: int,
        error_code: Optional[str] = None,
        request_id: Optional[str] = None,
        response_body: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.error_code = error_code
        self.request_id = request_id
        self.response_body = response_body

    def __str__(self) -> str:
        parts = [f"[{self.status_code}]"]
        if self.error_code:
            parts.append(f"({self.error_code})")
        parts.append(self.message)
        if self.request_id:
            parts.append(f"[request_id: {self.request_id}]")
        return " ".join(parts)

    @classmethod
    def from_response(cls, status_code: int, body: Dict[str, Any]) -> "AkiliAPIError":
        """Create an error from an API response body."""
        error = body.get("error", {})
        if isinstance(error, str):
            return cls(
                message=body.get("message", error),
                status_code=status_code,
                error_code=error,
                response_body=body,
            )
        return cls(
            message=error.get("message", str(body)),
            status_code=status_code,
            error_code=error.get("code") or error.get("error"),
            request_id=error.get("request_id"),
            response_body=body,
        )


class AkiliValidationError(AkiliError):
    """Invalid request parameters before sending to API."""

    def __init__(self, message: str, field: Optional[str] = None) -> None:
        super().__init__(message)
        self.field = field

    def __str__(self) -> str:
        if self.field:
            return f"Validation error on '{self.field}': {self.message}"
        return f"Validation error: {self.message}"


class AkiliTimeoutError(AkiliError):
    """Request timed out."""

    def __init__(self, timeout: float, operation: str = "request") -> None:
        super().__init__(f"{operation} timed out after {timeout}s")
        self.timeout = timeout
        self.operation = operation


class AkiliConnectionError(AkiliError):
    """Failed to connect to API."""

    def __init__(
        self, message: str, original_error: Optional[Exception] = None
    ) -> None:
        super().__init__(message)
        self.original_error = original_error


class AkiliAuthenticationError(AkiliAPIError):
    """Authentication failed (401)."""

    def __init__(self, message: str = "Invalid or missing API key") -> None:
        super().__init__(message, status_code=401, error_code="unauthorized")


class AkiliRateLimitError(AkiliAPIError):
    """Rate limit exceeded (429).

    Attributes:
        retry_after: Seconds to wait before retrying
    """

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        retry_after: Optional[int] = None,
    ) -> None:
        super().__init__(message, status_code=429, error_code="rate_limited")
        self.retry_after = retry_after

    def __str__(self) -> str:
        msg = super().__str__()
        if self.retry_after:
            msg += f" (retry after {self.retry_after}s)"
        return msg


class AkiliNotFoundError(AkiliAPIError):
    """Resource not found (404)."""

    def __init__(self, resource: str, resource_id: str) -> None:
        super().__init__(
            message=f"{resource} '{resource_id}' not found",
            status_code=404,
            error_code="not_found",
        )
        self.resource = resource
        self.resource_id = resource_id
