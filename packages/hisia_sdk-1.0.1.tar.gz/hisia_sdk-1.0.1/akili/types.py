"""
Akili SDK Type Definitions

Auto-generated from OpenAPI spec. Do not edit directly.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Literal, Optional, Union


# =============================================================================
# Enums
# =============================================================================


class SegmentationModel(str, Enum):
    """Available segmentation models."""

    PRITHVI_FLOOD_V1 = "prithvi-flood-v1"
    PRITHVI_BURN_SCAR_V1 = "prithvi-burn-scar-v1"
    PRITHVI_CROP_V1 = "prithvi-crop-v1"
    PRITHVI_LAND_COVER_V1 = "prithvi-land-cover-v1"
    CLAY_FLOOD_V1 = "clay-flood-v1"


class OutputFormat(str, Enum):
    """Output format for segmentation results."""

    COG = "cog"
    GEOJSON = "geojson"
    BOTH = "both"


class JobStatus(str, Enum):
    """Status of an async job."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class CertificationType(str, Enum):
    """Supported certification standards."""

    ISO14064 = "iso14064"
    VERRA = "verra"
    GOLD_STANDARD = "gold_standard"
    PARAMETRIC_INSURANCE = "parametric_insurance"


class EvidenceFormat(str, Enum):
    """Evidence pack output formats."""

    JSON = "json"
    PDF = "pdf"
    ZIP = "zip"


# =============================================================================
# GeoJSON Types
# =============================================================================


@dataclass
class GeoJSONPolygon:
    """GeoJSON Polygon geometry."""

    type: Literal["Polygon", "MultiPolygon"] = "Polygon"
    coordinates: List[List[List[float]]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {"type": self.type, "coordinates": self.coordinates}

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "GeoJSONPolygon":
        return cls(
            type=data.get("type", "Polygon"), coordinates=data.get("coordinates", [])
        )


# =============================================================================
# Segmentation Types
# =============================================================================


@dataclass
class SegmentationRequest:
    """Request body for creating a segmentation job."""

    aoi: Union[GeoJSONPolygon, Dict[str, Any]]
    datetime_range: List[str]
    model: SegmentationModel = SegmentationModel.PRITHVI_FLOOD_V1
    sensors: List[str] = field(default_factory=lambda: ["sentinel-2"])
    output_format: OutputFormat = OutputFormat.BOTH
    cloud_cover_max: float = 30.0
    min_confidence: float = 0.5

    def to_dict(self) -> Dict[str, Any]:
        aoi_dict = (
            self.aoi.to_dict() if isinstance(self.aoi, GeoJSONPolygon) else self.aoi
        )
        return {
            "aoi": aoi_dict,
            "datetime_range": self.datetime_range,
            "model": (
                self.model.value
                if isinstance(self.model, SegmentationModel)
                else self.model
            ),
            "sensors": self.sensors,
            "output_format": (
                self.output_format.value
                if isinstance(self.output_format, OutputFormat)
                else self.output_format
            ),
            "cloud_cover_max": self.cloud_cover_max,
            "min_confidence": self.min_confidence,
        }


@dataclass
class SegmentationOutputs:
    """URLs for segmentation outputs."""

    mask_cog_url: Optional[str] = None
    polygons_geojson_url: Optional[str] = None
    confidence_cog_url: Optional[str] = None
    thumbnail_url: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SegmentationOutputs":
        return cls(
            mask_cog_url=data.get("mask_cog_url"),
            polygons_geojson_url=data.get("polygons_geojson_url"),
            confidence_cog_url=data.get("confidence_cog_url"),
            thumbnail_url=data.get("thumbnail_url"),
        )


@dataclass
class SegmentationSummary:
    """Summary statistics for segmentation results."""

    total_area_km2: Optional[float] = None
    segmented_area_km2: Optional[float] = None
    segmented_percentage: Optional[float] = None
    confidence_mean: Optional[float] = None
    confidence_std: Optional[float] = None
    class_distribution: Optional[Dict[str, float]] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SegmentationSummary":
        return cls(
            total_area_km2=data.get("total_area_km2"),
            segmented_area_km2=data.get("segmented_area_km2"),
            segmented_percentage=data.get("segmented_percentage"),
            confidence_mean=data.get("confidence_mean"),
            confidence_std=data.get("confidence_std"),
            class_distribution=data.get("class_distribution"),
        )


@dataclass
class ProvenanceInfo:
    """Provenance information for a segmentation job."""

    model_version: Optional[str] = None
    model_weights_hash: Optional[str] = None
    input_scenes: Optional[List[str]] = None
    input_bands: Optional[List[str]] = None
    processing_timestamp: Optional[str] = None
    processing_duration_seconds: Optional[float] = None
    cloud_cover_actual: Optional[float] = None
    aoi_area_km2: Optional[float] = None
    tile_count: Optional[int] = None
    software_version: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ProvenanceInfo":
        return cls(
            model_version=data.get("model_version"),
            model_weights_hash=data.get("model_weights_hash"),
            input_scenes=data.get("input_scenes"),
            input_bands=data.get("input_bands"),
            processing_timestamp=data.get("processing_timestamp"),
            processing_duration_seconds=data.get("processing_duration_seconds"),
            cloud_cover_actual=data.get("cloud_cover_actual"),
            aoi_area_km2=data.get("aoi_area_km2"),
            tile_count=data.get("tile_count"),
            software_version=data.get("software_version"),
        )


@dataclass
class SegmentationResponse:
    """Response from segmentation job creation or retrieval."""

    job_id: str
    status: JobStatus
    model: str
    created_at: str
    completed_at: Optional[str] = None
    outputs: Optional[SegmentationOutputs] = None
    summary: Optional[SegmentationSummary] = None
    provenance: Optional[ProvenanceInfo] = None
    error: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SegmentationResponse":
        return cls(
            job_id=data["job_id"],
            status=JobStatus(data["status"]),
            model=data["model"],
            created_at=data["created_at"],
            completed_at=data.get("completed_at"),
            outputs=(
                SegmentationOutputs.from_dict(data["outputs"])
                if data.get("outputs")
                else None
            ),
            summary=(
                SegmentationSummary.from_dict(data["summary"])
                if data.get("summary")
                else None
            ),
            provenance=(
                ProvenanceInfo.from_dict(data["provenance"])
                if data.get("provenance")
                else None
            ),
            error=data.get("error"),
        )

    @property
    def is_complete(self) -> bool:
        return self.status == JobStatus.COMPLETED

    @property
    def is_failed(self) -> bool:
        return self.status == JobStatus.FAILED

    @property
    def is_pending(self) -> bool:
        return self.status in (JobStatus.PENDING, JobStatus.RUNNING)


@dataclass
class JobStatusResponse:
    """Response from job status check."""

    job_id: str
    status: JobStatus
    progress: float
    message: Optional[str] = None
    result: Optional[SegmentationResponse] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "JobStatusResponse":
        return cls(
            job_id=data["job_id"],
            status=JobStatus(data["status"]),
            progress=data.get("progress", 0.0),
            message=data.get("message"),
            result=(
                SegmentationResponse.from_dict(data["result"])
                if data.get("result")
                else None
            ),
        )


# =============================================================================
# Evidence Types
# =============================================================================


@dataclass
class EvidencePackRequest:
    """Request body for creating an evidence pack."""

    execution_id: str
    format: EvidenceFormat = EvidenceFormat.JSON
    include_imagery: bool = True
    include_masks: bool = True
    sign: bool = True
    certification_type: Optional[CertificationType] = None

    def to_dict(self) -> Dict[str, Any]:
        result = {
            "execution_id": self.execution_id,
            "format": (
                self.format.value
                if isinstance(self.format, EvidenceFormat)
                else self.format
            ),
            "include_imagery": self.include_imagery,
            "include_masks": self.include_masks,
            "sign": self.sign,
        }
        if self.certification_type:
            result["certification_type"] = (
                self.certification_type.value
                if isinstance(self.certification_type, CertificationType)
                else self.certification_type
            )
        return result


@dataclass
class DataSource:
    """Data source in provenance chain."""

    source_id: str
    source_type: str
    collection: Optional[str] = None
    scene_id: Optional[str] = None
    datetime: Optional[str] = None
    url: Optional[str] = None
    checksum: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DataSource":
        return cls(
            source_id=data["source_id"],
            source_type=data["source_type"],
            collection=data.get("collection"),
            scene_id=data.get("scene_id"),
            datetime=data.get("datetime"),
            url=data.get("url"),
            checksum=data.get("checksum"),
        )


@dataclass
class ModelDetail:
    """Model details in provenance chain."""

    model_id: str
    model_name: str
    version: Optional[str] = None
    license: Optional[str] = None
    source_url: Optional[str] = None
    weights_checksum: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ModelDetail":
        return cls(
            model_id=data["model_id"],
            model_name=data["model_name"],
            version=data.get("version"),
            license=data.get("license"),
            source_url=data.get("source_url"),
            weights_checksum=data.get("weights_checksum"),
        )


@dataclass
class ProvenanceChain:
    """Full provenance chain for evidence pack."""

    execution_id: str
    generated_at: str
    data_sources: List[DataSource] = field(default_factory=list)
    model: Optional[ModelDetail] = None
    processing_steps: List[Dict[str, Any]] = field(default_factory=list)
    aoi_geojson: Optional[Dict[str, Any]] = None
    datetime_range: Optional[Dict[str, Any]] = None
    total_area_km2: Optional[float] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ProvenanceChain":
        return cls(
            execution_id=data["execution_id"],
            generated_at=data["generated_at"],
            data_sources=[
                DataSource.from_dict(ds) for ds in data.get("data_sources", [])
            ],
            model=ModelDetail.from_dict(data["model"]) if data.get("model") else None,
            processing_steps=data.get("processing_steps", []),
            aoi_geojson=data.get("aoi_geojson"),
            datetime_range=data.get("datetime_range"),
            total_area_km2=data.get("total_area_km2"),
        )


@dataclass
class EvidencePackMetadata:
    """Metadata for an evidence pack."""

    pack_id: str
    execution_id: str
    created_at: str
    format: str
    checksum_sha256: Optional[str] = None
    file_size_bytes: Optional[int] = None
    certification_type: Optional[str] = None
    signed: bool = False

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EvidencePackMetadata":
        return cls(
            pack_id=data["pack_id"],
            execution_id=data["execution_id"],
            created_at=data["created_at"],
            format=data["format"],
            checksum_sha256=data.get("checksum_sha256"),
            file_size_bytes=data.get("file_size_bytes"),
            certification_type=data.get("certification_type"),
            signed=data.get("signed", False),
        )


@dataclass
class EvidencePackResponse:
    """Response from evidence pack creation."""

    success: bool
    pack_id: str
    metadata: Optional[EvidencePackMetadata] = None
    provenance: Optional[ProvenanceChain] = None
    download_url: Optional[str] = None
    artifacts: Optional[List[Dict[str, Any]]] = None
    summary: Optional[Dict[str, Any]] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EvidencePackResponse":
        return cls(
            success=data["success"],
            pack_id=data["pack_id"],
            metadata=(
                EvidencePackMetadata.from_dict(data["metadata"])
                if data.get("metadata")
                else None
            ),
            provenance=(
                ProvenanceChain.from_dict(data["provenance"])
                if data.get("provenance")
                else None
            ),
            download_url=data.get("download_url"),
            artifacts=data.get("artifacts"),
            summary=data.get("summary"),
        )


# =============================================================================
# Model Info
# =============================================================================


@dataclass
class ModelInfo:
    """Information about an available model."""

    id: str
    name: str
    description: Optional[str] = None
    input_bands: Optional[List[str]] = None
    supports_sar: bool = False

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ModelInfo":
        return cls(
            id=data["id"],
            name=data["name"],
            description=data.get("description"),
            input_bands=data.get("input_bands"),
            supports_sar=data.get("supports_sar", False),
        )


# =============================================================================
# Data Access Types
# =============================================================================


@dataclass
class VegetationDataPoint:
    """Single vegetation data point."""

    date: str
    ndvi: Optional[float] = None
    evi: Optional[float] = None
    ndwi: Optional[float] = None
    savi: Optional[float] = None
    lai: Optional[float] = None
    fpar: Optional[float] = None
    quality_score: Optional[float] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "VegetationDataPoint":
        return cls(
            date=data["date"],
            ndvi=data.get("ndvi"),
            evi=data.get("evi"),
            ndwi=data.get("ndwi"),
            savi=data.get("savi"),
            lai=data.get("lai"),
            fpar=data.get("fpar"),
            quality_score=data.get("quality_score"),
        )


@dataclass
class VegetationResponse:
    """Response from vegetation indices endpoint."""

    location: Dict[str, float]
    data: List[VegetationDataPoint]

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "VegetationResponse":
        return cls(
            location=data["location"],
            data=[VegetationDataPoint.from_dict(d) for d in data.get("data", [])],
        )


@dataclass
class RainfallDataPoint:
    """Single rainfall data point."""

    date: str
    rainfall_mm: float
    quality: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RainfallDataPoint":
        return cls(
            date=data["date"],
            rainfall_mm=data["rainfall_mm"],
            quality=data.get("quality"),
        )


@dataclass
class RainfallResponse:
    """Response from rainfall endpoint."""

    location: Dict[str, float]
    frequency: str
    data: List[RainfallDataPoint]

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RainfallResponse":
        return cls(
            location=data["location"],
            frequency=data["frequency"],
            data=[RainfallDataPoint.from_dict(d) for d in data.get("data", [])],
        )


@dataclass
class Dataset:
    """Dataset information."""

    id: str
    name: str
    description: Optional[str] = None
    category: Optional[str] = None
    provider: Optional[str] = None
    temporal_resolution: Optional[str] = None
    spatial_resolution: Optional[str] = None
    coverage: Optional[List[str]] = None
    license: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Dataset":
        return cls(
            id=data["id"],
            name=data["name"],
            description=data.get("description"),
            category=data.get("category"),
            provider=data.get("provider"),
            temporal_resolution=data.get("temporal_resolution"),
            spatial_resolution=data.get("spatial_resolution"),
            coverage=data.get("coverage"),
            license=data.get("license"),
        )
