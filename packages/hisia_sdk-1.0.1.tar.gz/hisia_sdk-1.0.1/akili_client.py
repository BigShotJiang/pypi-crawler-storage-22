"""Compatibility layer for the Akili SDK.

Preferred import (installed package):
    from akili_sdk import AkiliClient
"""

from akili_sdk import AkiliClient, AkiliError, AkiliHTTPError, AkiliResponseError

__all__ = ["AkiliClient", "AkiliError", "AkiliHTTPError", "AkiliResponseError"]
