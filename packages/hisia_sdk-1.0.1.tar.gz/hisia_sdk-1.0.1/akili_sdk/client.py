from __future__ import annotations

import os
from typing import Any, Dict, Iterable, Optional, Tuple, Union

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .errors import AkiliHTTPError, AkiliResponseError

Timeout = Union[float, Tuple[float, float]]


class AkiliClient:
    """Production-ready Akili API client (sync).

    - Connection pooling via `requests.Session`
    - Configurable retries for transient failures
    - Typed, consistent error surface
    """

    def __init__(
        self,
        base_url: str,
        api_key: Optional[str] = None,
        *,
        timeout: Timeout = (5.0, 30.0),
        user_agent: str = "akili-sdk-python/0.1.0",
        max_retries: int = 3,
        retry_statuses: Iterable[int] = (429, 500, 502, 503, 504),
        retry_methods: Iterable[str] = ("GET", "HEAD", "OPTIONS"),
        session: Optional[requests.Session] = None,
    ):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key or os.getenv("AKILI_API_KEY", "")
        self.timeout = timeout
        self.user_agent = user_agent

        self._session = session or requests.Session()
        if session is None:
            self._mount_retries(
                max_retries=max_retries,
                retry_statuses=tuple(retry_statuses),
                retry_methods=tuple(retry_methods),
            )

    def __enter__(self) -> "AkiliClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    @classmethod
    def from_env(cls) -> "AkiliClient":
        base = os.getenv("AKILI_API_URL", "http://localhost:8000")
        key = os.getenv("AKILI_API_KEY", "")
        return cls(base, api_key=key)

    def close(self) -> None:
        self._session.close()

    def _mount_retries(
        self,
        *,
        max_retries: int,
        retry_statuses: Tuple[int, ...],
        retry_methods: Tuple[str, ...],
    ) -> None:
        retry = Retry(
            total=max_retries,
            connect=max_retries,
            read=max_retries,
            status=max_retries,
            backoff_factor=0.5,
            status_forcelist=retry_statuses,
            allowed_methods=frozenset(m.upper() for m in retry_methods),
            raise_on_status=False,
            respect_retry_after_header=True,
        )
        adapter = HTTPAdapter(max_retries=retry)
        self._session.mount("https://", adapter)
        self._session.mount("http://", adapter)

    def _headers(
        self, extra_headers: Optional[Dict[str, str]] = None
    ) -> Dict[str, str]:
        headers: Dict[str, str] = {
            "Accept": "application/json",
            "User-Agent": self.user_agent,
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        if extra_headers:
            headers.update(extra_headers)
        return headers

    def request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: Optional[Timeout] = None,
    ) -> Any:
        url = f"{self.base_url}{path}"
        resp = self._session.request(
            method=method,
            url=url,
            params=params,
            json=json,
            headers=self._headers(headers),
            timeout=timeout or self.timeout,
        )

        if resp.status_code >= 400:
            raise AkiliHTTPError(
                status_code=resp.status_code,
                method=method.upper(),
                url=url,
                response_text=(resp.text or "")[:10_000],
                request_id=resp.headers.get("x-request-id")
                or resp.headers.get("x-correlation-id"),
            )

        try:
            return resp.json()
        except ValueError as e:
            raise AkiliResponseError(
                f"Non-JSON response from {method.upper()} {url}"
            ) from e

    # Insights
    def get_indices(self, tenant_id: str, field_id: str) -> Dict[str, Any]:
        return self.request(
            "GET",
            "/api/v1/insights/indices",
            params={"tenant_id": tenant_id, "field_id": field_id},
        )

    # Recommendations
    def generate_recommendation(
        self,
        tenant_id: str,
        scope_entity_type: str,
        scope_entity_id: str,
        rec_type: str,
    ) -> Dict[str, Any]:
        return self.request(
            "POST",
            "/api/v1/recommendations/generate",
            params={
                "tenant_id": tenant_id,
                "scope_entity_type": scope_entity_type,
                "scope_entity_id": scope_entity_id,
                "rec_type": rec_type,
            },
        )

    def get_recommendation(self, recommendation_id: str) -> Dict[str, Any]:
        return self.request("GET", f"/api/v1/recommendations/{recommendation_id}")

    def list_recommendations(
        self, tenant_id: Optional[str] = None, page: int = 1, page_size: int = 50
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {"page": page, "page_size": page_size}
        if tenant_id:
            params["tenant_id"] = tenant_id
        return self.request("GET", "/api/v1/recommendations", params=params)

    # Agents
    def start_agent_run(self, tenant_id: str, template: str) -> Dict[str, Any]:
        return self.request(
            "POST",
            "/api/v1/agents/runs",
            params={"tenant_id": tenant_id, "template": template},
        )

    def get_agent_run(self, run_id: str) -> Dict[str, Any]:
        return self.request("GET", f"/api/v1/agents/runs/{run_id}")

    def list_agent_runs(
        self, tenant_id: Optional[str] = None, limit: int = 50
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {"limit": limit}
        if tenant_id:
            params["tenant_id"] = tenant_id
        return self.request("GET", "/api/v1/agents/runs", params=params)
