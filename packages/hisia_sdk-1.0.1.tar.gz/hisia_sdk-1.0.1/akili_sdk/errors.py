from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


class AkiliError(Exception):
    """Base SDK error."""


@dataclass
class AkiliHTTPError(AkiliError):
    """Raised for non-2xx responses."""

    status_code: int
    method: str
    url: str
    response_text: str = ""
    request_id: Optional[str] = None

    def __str__(self) -> str:
        rid = f" request_id={self.request_id}" if self.request_id else ""
        body = f" body={self.response_text}" if self.response_text else ""
        return f"HTTP {self.status_code} calling {self.method} {self.url}{rid}{body}"


class AkiliResponseError(AkiliError):
    """Raised when the server response cannot be parsed as expected."""
