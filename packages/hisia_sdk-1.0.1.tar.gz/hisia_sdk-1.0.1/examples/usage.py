"""
Akili SDK Usage Examples

Examples of how to use the Akili Python SDK.
"""

# =============================================================================
# Basic Usage
# =============================================================================

from akili import Akili

# Initialize client
client = Akili(api_key="your-api-key")

# Or from environment variable
# export AKILI_API_KEY=your-api-key
# client = Akili()


# =============================================================================
# Segmentation (Flood Detection)
# =============================================================================

# Define area of interest
aoi = {
    "type": "Polygon",
    "coordinates": [
        [[36.8, -1.3], [37.0, -1.3], [37.0, -1.1], [36.8, -1.1], [36.8, -1.3]]
    ],
}

# Create segmentation job
job = client.segment.create(
    aoi=aoi,
    datetime_range=["2025-01-01", "2025-01-15"],
    model="prithvi-flood-v1",
    sensors=["sentinel-2"],
    cloud_cover_max=30.0,
)

print(f"Job created: {job.job_id}")
print(f"Status: {job.status}")

# Wait for completion (polls automatically)
result = client.segment.wait_for_completion(
    job.job_id,
    poll_interval=5.0,  # Check every 5 seconds
    timeout=600.0,  # Max 10 minutes
)

print(f"Completed: {result.completed_at}")
print(f"Flooded area: {result.summary.segmented_area_km2} km²")
print(f"Download mask: {result.outputs.mask_cog_url}")


# =============================================================================
# Evidence Pack Generation
# =============================================================================

# Generate insurance-grade evidence pack
evidence = client.evidence.create(
    execution_id=result.job_id,
    format="json",
    include_imagery=True,
    include_masks=True,
    sign=True,
    certification_type="parametric_insurance",
)

print(f"Evidence pack: {evidence.pack_id}")
print(f"Download: {evidence.download_url}")
print(f"Checksum: {evidence.metadata.checksum_sha256}")


# =============================================================================
# Data Access
# =============================================================================

# Get vegetation indices
veg = client.data.vegetation(
    lat=-1.2921,
    lon=36.8219,
    start_date="2025-01-01",
    end_date="2025-01-31",
)

for point in veg.data:
    print(f"{point.date}: NDVI={point.ndvi:.3f}")


# Get rainfall data
rain = client.data.rainfall(
    lat=-1.2921,
    lon=36.8219,
    start_date="2025-01-01",
    end_date="2025-01-31",
    frequency="daily",
)

total_rain = sum(p.rainfall_mm for p in rain.data)
print(f"Total rainfall: {total_rain:.1f} mm")


# Search satellite imagery
imagery = client.data.search_imagery(
    bbox=[36.8, -1.3, 37.0, -1.1],
    datetime="2025-01-01/2025-01-15",
    collections=["sentinel-2-l2a"],
    cloud_cover_max=30,
    limit=10,
)

print(f"Found {len(imagery['features'])} scenes")


# =============================================================================
# Discovery
# =============================================================================

# List available datasets
datasets = client.search.datasets(category="satellite", region="east-africa")

for ds in datasets:
    print(f"- {ds.name}: {ds.description}")


# List available models
models = client.segment.models()

for model in models:
    print(f"- {model.id}: {model.name}")
    if model.supports_sar:
        print("  (Supports SAR imagery)")


# =============================================================================
# Error Handling
# =============================================================================

from akili import AkiliAPIError, AkiliRateLimitError, AkiliNotFoundError

try:
    result = client.segment.get("non-existent-job")
except AkiliNotFoundError as e:
    print(f"Job not found: {e.resource_id}")
except AkiliRateLimitError as e:
    print(f"Rate limited! Retry after {e.retry_after}s")
except AkiliAPIError as e:
    print(f"API error [{e.status_code}]: {e.message}")
