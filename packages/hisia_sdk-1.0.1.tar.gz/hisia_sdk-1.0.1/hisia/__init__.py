"""
Hisia Climate Intelligence SDK

Official Python SDK for the Hisia API - Earth observation and climate
intelligence for Africa.

Usage:
    from hisia import Hisia

    # Initialize (uses HISIA_API_KEY env var by default)
    client = Hisia()

    # List datasets
    datasets = client.datasets.list(limit=10)

    # Search satellite imagery
    imagery = client.satellite.search(
        bbox=[36.7, -1.3, 36.9, -1.1],
        sensor="sentinel-2-l2a",
        start_date="2025-01-01",
        end_date="2025-01-31"
    )

    # Calculate vegetation indices
    ndvi = client.indices.calculate(
        latitude=-1.2,
        longitude=36.8,
        index="NDVI",
        start_date="2025-01-01",
        end_date="2025-06-30"
    )

Async Usage:
    from hisia import AsyncHisia

    async with AsyncHisia() as client:
        datasets = await client.datasets.list()
"""

from .client import Hisia, AsyncHisia
from .errors import (
    HisiaError,
    HisiaAPIError,
    HisiaAuthError,
    HisiaNotFoundError,
    HisiaRateLimitError,
    HisiaTimeoutError,
)
from .resources import Datasets, Satellite, Indices, Pipelines, Models

__version__ = "1.0.1"

__all__ = [
    # Main clients
    "Hisia",
    "AsyncHisia",
    # Resources
    "Datasets",
    "Satellite",
    "Indices",
    "Pipelines",
    "Models",
    # Errors
    "HisiaError",
    "HisiaAPIError",
    "HisiaAuthError",
    "HisiaNotFoundError",
    "HisiaRateLimitError",
    "HisiaTimeoutError",
]
