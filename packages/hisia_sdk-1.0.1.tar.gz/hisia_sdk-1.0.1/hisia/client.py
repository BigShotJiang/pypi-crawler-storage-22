"""
Hisia SDK Client

Main entry point for the Hisia API.
"""

from __future__ import annotations

import os
from typing import Any, Dict, Optional, Tuple, Union

import httpx

from .errors import (
    HisiaAPIError,
    HisiaAuthError,
    HisiaNotFoundError,
    HisiaRateLimitError,
    HisiaTimeoutError,
)

Timeout = Union[float, Tuple[float, float]]

# Default API base URLs
DEFAULT_API_URL = "https://api.akili.hisia.space"
STAGING_API_URL = "https://staging.akili.hisia.space"


class BaseClient:
    """Base HTTP client with retry logic and error handling."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Timeout = (10.0, 60.0),
        max_retries: int = 3,
    ):
        self.api_key = api_key or os.getenv("HISIA_API_KEY", "")
        self.base_url = (base_url or os.getenv("HISIA_API_URL", DEFAULT_API_URL)).rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries

        if not self.api_key:
            raise HisiaAuthError(
                "API key required. Set HISIA_API_KEY environment variable or pass api_key parameter."
            )

    def _headers(self, extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "User-Agent": "hisia-python/1.0.0",
            "Authorization": f"Bearer {self.api_key}",
        }
        if extra:
            headers.update(extra)
        return headers

    def _handle_response(self, response: httpx.Response, request_id: Optional[str] = None) -> Any:
        """Process response and raise appropriate errors."""
        # Extract request ID from response headers
        rid = request_id or response.headers.get("x-request-id")

        if response.status_code == 401:
            raise HisiaAuthError(
                message="Invalid or expired API key",
                request_id=rid,
            )

        if response.status_code == 404:
            try:
                data = response.json()
                resource = data.get("resource", "Resource")
                resource_id = data.get("resource_id", "unknown")
            except Exception:
                resource = "Resource"
                resource_id = "unknown"
            raise HisiaNotFoundError(resource=resource, resource_id=resource_id, request_id=rid)

        if response.status_code == 429:
            retry_after = response.headers.get("Retry-After")
            raise HisiaRateLimitError(
                message="Rate limit exceeded. Please wait before retrying.",
                retry_after=int(retry_after) if retry_after else None,
                request_id=rid,
            )

        if response.status_code >= 400:
            try:
                data = response.json()
                error_type = data.get("error", {}).get("type", "api_error")
                message = data.get("error", {}).get("detail", response.text)
            except Exception:
                error_type = "api_error"
                message = response.text or f"HTTP {response.status_code}"

            raise HisiaAPIError(
                status_code=response.status_code,
                error_type=error_type,
                message=message,
                request_id=rid,
            )

        # Parse JSON response
        if response.headers.get("content-type", "").startswith("application/json"):
            data = response.json()
            # Handle wrapped responses (data key)
            if isinstance(data, dict) and "data" in data:
                return data["data"]
            return data

        return response.text


class Hisia(BaseClient):
    """
    Hisia Climate Intelligence SDK - Synchronous Client

    Usage:
        from hisia import Hisia

        client = Hisia()  # Uses HISIA_API_KEY env var

        # List datasets
        datasets = client.datasets.list(limit=10)

        # Search satellite imagery
        imagery = client.satellite.search(
            bbox=[36.7, -1.3, 36.9, -1.1],
            sensor="sentinel-2-l2a"
        )

    Args:
        api_key: Your Hisia API key. Defaults to HISIA_API_KEY env var.
        base_url: API base URL. Defaults to https://api.akili.hisia.space
        timeout: Request timeout in seconds. Tuple of (connect, read) timeouts.
        max_retries: Number of retries for transient failures.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Timeout = (10.0, 60.0),
        max_retries: int = 3,
    ):
        super().__init__(api_key, base_url, timeout, max_retries)

        # Initialize HTTP client
        transport = httpx.HTTPTransport(retries=max_retries)
        self._client = httpx.Client(
            base_url=self.base_url,
            headers=self._headers(),
            timeout=httpx.Timeout(connect=timeout[0], read=timeout[1], write=timeout[1], pool=timeout[0]) if isinstance(timeout, tuple) else httpx.Timeout(timeout),
            transport=transport,
        )

        # Initialize resources
        from .resources import Datasets, Satellite, Indices, Pipelines, Models

        self.datasets = Datasets(self)
        self.satellite = Satellite(self)
        self.indices = Indices(self)
        self.pipelines = Pipelines(self)
        self.models = Models(self)

    def __enter__(self) -> "Hisia":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    def close(self) -> None:
        """Close the HTTP client connection."""
        self._client.close()

    def request(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> Any:
        """Make an HTTP request to the API."""
        try:
            response = self._client.request(
                method=method.upper(),
                url=path,
                params=params,
                json=json,
                headers=headers,
            )
            return self._handle_response(response)
        except httpx.TimeoutException:
            raise HisiaTimeoutError(
                timeout=self.timeout[1] if isinstance(self.timeout, tuple) else self.timeout,
                url=f"{self.base_url}{path}",
            )

    def get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Any:
        """Make a GET request."""
        return self.request("GET", path, params=params)

    def post(
        self,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Make a POST request."""
        return self.request("POST", path, params=params, json=json)

    def put(self, path: str, json: Optional[Dict[str, Any]] = None) -> Any:
        """Make a PUT request."""
        return self.request("PUT", path, json=json)

    def delete(self, path: str) -> Any:
        """Make a DELETE request."""
        return self.request("DELETE", path)


class AsyncHisia(BaseClient):
    """
    Hisia Climate Intelligence SDK - Asynchronous Client

    Usage:
        from hisia import AsyncHisia

        async with AsyncHisia() as client:
            datasets = await client.datasets.list(limit=10)

    Args:
        api_key: Your Hisia API key. Defaults to HISIA_API_KEY env var.
        base_url: API base URL. Defaults to https://api.akili.hisia.space
        timeout: Request timeout in seconds.
        max_retries: Number of retries for transient failures.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Timeout = (10.0, 60.0),
        max_retries: int = 3,
    ):
        super().__init__(api_key, base_url, timeout, max_retries)

        # Initialize async HTTP client
        transport = httpx.AsyncHTTPTransport(retries=max_retries)
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers=self._headers(),
            timeout=httpx.Timeout(connect=timeout[0], read=timeout[1], write=timeout[1], pool=timeout[0]) if isinstance(timeout, tuple) else httpx.Timeout(timeout),
            transport=transport,
        )

        # Initialize resources (async versions)
        from .resources import AsyncDatasets, AsyncSatellite, AsyncIndices, AsyncPipelines, AsyncModels

        self.datasets = AsyncDatasets(self)
        self.satellite = AsyncSatellite(self)
        self.indices = AsyncIndices(self)
        self.pipelines = AsyncPipelines(self)
        self.models = AsyncModels(self)

    async def __aenter__(self) -> "AsyncHisia":
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        await self.close()

    async def close(self) -> None:
        """Close the async HTTP client connection."""
        await self._client.aclose()

    async def request(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> Any:
        """Make an async HTTP request to the API."""
        try:
            response = await self._client.request(
                method=method.upper(),
                url=path,
                params=params,
                json=json,
                headers=headers,
            )
            return self._handle_response(response)
        except httpx.TimeoutException:
            raise HisiaTimeoutError(
                timeout=self.timeout[1] if isinstance(self.timeout, tuple) else self.timeout,
                url=f"{self.base_url}{path}",
            )

    async def get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Any:
        """Make an async GET request."""
        return await self.request("GET", path, params=params)

    async def post(
        self,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Make an async POST request."""
        return await self.request("POST", path, params=params, json=json)

    async def put(self, path: str, json: Optional[Dict[str, Any]] = None) -> Any:
        """Make an async PUT request."""
        return await self.request("PUT", path, json=json)

    async def delete(self, path: str) -> Any:
        """Make an async DELETE request."""
        return await self.request("DELETE", path)
