"""
Hisia SDK Exceptions

Typed exception hierarchy for better error handling.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional


class HisiaError(Exception):
    """Base exception for all Hisia SDK errors."""

    def __init__(self, message: str):
        self.message = message
        super().__init__(message)


@dataclass
class HisiaAPIError(HisiaError):
    """
    Raised when the Hisia API returns an error response.

    Attributes:
        status_code: HTTP status code
        error_type: API error type (e.g., "validation_error")
        message: Human-readable error message
        request_id: Request ID for debugging (if available)
        details: Additional error details from the API
    """

    status_code: int
    error_type: str
    message: str
    request_id: Optional[str] = None
    details: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        super(HisiaError, self).__init__(self.message)

    def __str__(self) -> str:
        parts = [f"[{self.status_code}] {self.error_type}: {self.message}"]
        if self.request_id:
            parts.append(f"(request_id: {self.request_id})")
        return " ".join(parts)


class HisiaAuthError(HisiaAPIError):
    """
    Raised when authentication fails (401 Unauthorized).

    Common causes:
    - Missing API key
    - Invalid API key
    - Expired API key
    - Insufficient permissions
    """

    def __init__(
        self,
        message: str = "Authentication failed",
        request_id: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(
            status_code=401,
            error_type="authentication_error",
            message=message,
            request_id=request_id,
            details=details or {},
        )


class HisiaNotFoundError(HisiaAPIError):
    """
    Raised when a requested resource is not found (404 Not Found).
    """

    def __init__(
        self,
        resource: str,
        resource_id: str,
        request_id: Optional[str] = None,
    ):
        super().__init__(
            status_code=404,
            error_type="not_found",
            message=f"{resource} '{resource_id}' not found",
            request_id=request_id,
            details={"resource": resource, "resource_id": resource_id},
        )


class HisiaRateLimitError(HisiaAPIError):
    """
    Raised when rate limits are exceeded (429 Too Many Requests).

    Attributes:
        retry_after: Seconds to wait before retrying (if provided)
    """

    retry_after: Optional[int] = None

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        retry_after: Optional[int] = None,
        request_id: Optional[str] = None,
    ):
        super().__init__(
            status_code=429,
            error_type="rate_limit_exceeded",
            message=message,
            request_id=request_id,
            details={"retry_after": retry_after} if retry_after else {},
        )
        self.retry_after = retry_after


class HisiaTimeoutError(HisiaError):
    """
    Raised when a request times out.
    """

    def __init__(self, timeout: float, url: str):
        self.timeout = timeout
        self.url = url
        super().__init__(f"Request to {url} timed out after {timeout}s")


class HisiaValidationError(HisiaAPIError):
    """
    Raised when request validation fails (422 Unprocessable Entity).
    """

    def __init__(
        self,
        message: str,
        field_errors: Optional[Dict[str, str]] = None,
        request_id: Optional[str] = None,
    ):
        super().__init__(
            status_code=422,
            error_type="validation_error",
            message=message,
            request_id=request_id,
            details={"field_errors": field_errors or {}},
        )
