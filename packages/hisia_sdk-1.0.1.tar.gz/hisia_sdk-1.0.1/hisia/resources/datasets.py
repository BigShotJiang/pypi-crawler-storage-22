"""
Datasets Resource

Access and manage geospatial datasets.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from ..client import Hisia, AsyncHisia


class Datasets:
    """
    Datasets resource for synchronous operations.

    Usage:
        client = Hisia()

        # List all datasets
        datasets = client.datasets.list(limit=10)

        # Get a specific dataset
        dataset = client.datasets.get("ds_abc123")

        # Search datasets by location
        kenya_data = client.datasets.list(
            bbox=[33.9, -4.7, 41.9, 5.0],
            tags=["agriculture", "satellite"]
        )
    """

    def __init__(self, client: "Hisia"):
        self._client = client

    def list(
        self,
        limit: int = 20,
        offset: int = 0,
        bbox: Optional[List[float]] = None,
        tags: Optional[List[str]] = None,
        search: Optional[str] = None,
        sort_by: str = "created_at",
        order: str = "desc",
    ) -> List[Dict[str, Any]]:
        """
        List available datasets.

        Args:
            limit: Maximum number of results (default: 20, max: 100)
            offset: Pagination offset
            bbox: Bounding box filter [min_lon, min_lat, max_lon, max_lat]
            tags: Filter by tags
            search: Full-text search query
            sort_by: Field to sort by (created_at, name, size)
            order: Sort order (asc, desc)

        Returns:
            List of dataset objects
        """
        params: Dict[str, Any] = {
            "limit": limit,
            "offset": offset,
            "sort_by": sort_by,
            "order": order,
        }
        if bbox:
            params["bbox"] = ",".join(str(b) for b in bbox)
        if tags:
            params["tags"] = ",".join(tags)
        if search:
            params["search"] = search

        return self._client.get("/flow/datasets", params=params)

    def get(self, dataset_id: str) -> Dict[str, Any]:
        """
        Get a specific dataset by ID.

        Args:
            dataset_id: The dataset ID

        Returns:
            Dataset object with metadata
        """
        return self._client.get(f"/flow/datasets/{dataset_id}")

    def get_schema(self, dataset_id: str) -> Dict[str, Any]:
        """
        Get the schema for a dataset.

        Args:
            dataset_id: The dataset ID

        Returns:
            Dataset schema definition
        """
        return self._client.get(f"/flow/datasets/{dataset_id}/schema")

    def sample(
        self,
        dataset_id: str,
        limit: int = 10,
        format: str = "json",
    ) -> Dict[str, Any]:
        """
        Get sample rows from a dataset.

        Args:
            dataset_id: The dataset ID
            limit: Number of sample rows (default: 10, max: 100)
            format: Output format (json, csv, geojson)

        Returns:
            Sample data from the dataset
        """
        return self._client.get(
            f"/flow/datasets/{dataset_id}/sample",
            params={"limit": limit, "format": format},
        )

    def download_url(self, dataset_id: str, expires_in: int = 3600) -> str:
        """
        Get a signed download URL for a dataset.

        Args:
            dataset_id: The dataset ID
            expires_in: URL expiration time in seconds (default: 1 hour)

        Returns:
            Signed download URL
        """
        result = self._client.get(
            f"/flow/data/download/dataset/{dataset_id}",
            params={"expires_in": expires_in},
        )
        return result.get("download_url", result)


class AsyncDatasets:
    """
    Datasets resource for asynchronous operations.

    Usage:
        async with AsyncHisia() as client:
            datasets = await client.datasets.list(limit=10)
    """

    def __init__(self, client: "AsyncHisia"):
        self._client = client

    async def list(
        self,
        limit: int = 20,
        offset: int = 0,
        bbox: Optional[List[float]] = None,
        tags: Optional[List[str]] = None,
        search: Optional[str] = None,
        sort_by: str = "created_at",
        order: str = "desc",
    ) -> List[Dict[str, Any]]:
        """List available datasets asynchronously."""
        params: Dict[str, Any] = {
            "limit": limit,
            "offset": offset,
            "sort_by": sort_by,
            "order": order,
        }
        if bbox:
            params["bbox"] = ",".join(str(b) for b in bbox)
        if tags:
            params["tags"] = ",".join(tags)
        if search:
            params["search"] = search

        return await self._client.get("/flow/datasets", params=params)

    async def get(self, dataset_id: str) -> Dict[str, Any]:
        """Get a specific dataset by ID asynchronously."""
        return await self._client.get(f"/flow/datasets/{dataset_id}")

    async def get_schema(self, dataset_id: str) -> Dict[str, Any]:
        """Get the schema for a dataset asynchronously."""
        return await self._client.get(f"/flow/datasets/{dataset_id}/schema")

    async def sample(
        self,
        dataset_id: str,
        limit: int = 10,
        format: str = "json",
    ) -> Dict[str, Any]:
        """Get sample rows from a dataset asynchronously."""
        return await self._client.get(
            f"/flow/datasets/{dataset_id}/sample",
            params={"limit": limit, "format": format},
        )

    async def download_url(self, dataset_id: str, expires_in: int = 3600) -> str:
        """Get a signed download URL for a dataset asynchronously."""
        result = await self._client.get(
            f"/flow/data/download/dataset/{dataset_id}",
            params={"expires_in": expires_in},
        )
        return result.get("download_url", result)
