"""
Indices Resource

Calculate vegetation and spectral indices from satellite data.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional, Union

if TYPE_CHECKING:
    from ..client import Hisia, AsyncHisia

# GeoJSON types
GeoJSON = Dict[str, Any]


class Indices:
    """
    Indices resource for synchronous operations.

    Usage:
        client = Hisia()

        # Calculate NDVI for a point
        ndvi = client.indices.calculate(
            latitude=-1.2,
            longitude=36.8,
            index="NDVI",
            start_date="2025-01-01",
            end_date="2025-06-30"
        )

        # Calculate NDVI for a polygon
        ndvi = client.indices.calculate(
            aoi={"type": "Polygon", "coordinates": [...]},
            index="NDVI",
            start_date="2025-01-01",
            end_date="2025-06-30"
        )
    """

    def __init__(self, client: "Hisia"):
        self._client = client

    def calculate(
        self,
        index: str = "NDVI",
        latitude: Optional[float] = None,
        longitude: Optional[float] = None,
        aoi: Optional[GeoJSON] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        sensor: str = "sentinel-2-l2a",
        aggregation: str = "mean",
    ) -> Dict[str, Any]:
        """
        Calculate a vegetation or spectral index.

        Args:
            index: Index to calculate (NDVI, EVI, SAVI, NDWI, NDBI)
            latitude: Point latitude (alternative to aoi)
            longitude: Point longitude (alternative to aoi)
            aoi: Area of interest as GeoJSON Polygon
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            sensor: Satellite sensor to use
            aggregation: Aggregation method (mean, median, max, min)

        Returns:
            Index calculation results with time series data
        """
        payload: Dict[str, Any] = {
            "index": index,
            "sensor": sensor,
            "aggregation": aggregation,
        }

        if aoi:
            payload["aoi"] = aoi
        elif latitude is not None and longitude is not None:
            payload["latitude"] = latitude
            payload["longitude"] = longitude
        else:
            raise ValueError("Either aoi or latitude/longitude must be provided")

        if start_date:
            payload["start_date"] = start_date
        if end_date:
            payload["end_date"] = end_date

        return self._client.post("/clear/indices", json=payload)

    def ndvi(
        self,
        latitude: Optional[float] = None,
        longitude: Optional[float] = None,
        aoi: Optional[GeoJSON] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Calculate Normalized Difference Vegetation Index (NDVI).

        NDVI measures vegetation health: -1 to 1, where higher values
        indicate healthier vegetation.
        """
        return self.calculate(
            index="NDVI",
            latitude=latitude,
            longitude=longitude,
            aoi=aoi,
            start_date=start_date,
            end_date=end_date,
        )

    def evi(
        self,
        latitude: Optional[float] = None,
        longitude: Optional[float] = None,
        aoi: Optional[GeoJSON] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Calculate Enhanced Vegetation Index (EVI).

        EVI is similar to NDVI but more sensitive to high biomass regions
        and corrects for atmospheric and canopy background effects.
        """
        return self.calculate(
            index="EVI",
            latitude=latitude,
            longitude=longitude,
            aoi=aoi,
            start_date=start_date,
            end_date=end_date,
        )

    def list_available(self) -> List[Dict[str, Any]]:
        """
        List available indices and their descriptions.

        Returns:
            List of index information
        """
        return self._client.get("/clear/indices/available")


class AsyncIndices:
    """
    Indices resource for asynchronous operations.

    Usage:
        async with AsyncHisia() as client:
            ndvi = await client.indices.calculate(
                latitude=-1.2,
                longitude=36.8,
                index="NDVI"
            )
    """

    def __init__(self, client: "AsyncHisia"):
        self._client = client

    async def calculate(
        self,
        index: str = "NDVI",
        latitude: Optional[float] = None,
        longitude: Optional[float] = None,
        aoi: Optional[GeoJSON] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        sensor: str = "sentinel-2-l2a",
        aggregation: str = "mean",
    ) -> Dict[str, Any]:
        """Calculate a vegetation or spectral index asynchronously."""
        payload: Dict[str, Any] = {
            "index": index,
            "sensor": sensor,
            "aggregation": aggregation,
        }

        if aoi:
            payload["aoi"] = aoi
        elif latitude is not None and longitude is not None:
            payload["latitude"] = latitude
            payload["longitude"] = longitude
        else:
            raise ValueError("Either aoi or latitude/longitude must be provided")

        if start_date:
            payload["start_date"] = start_date
        if end_date:
            payload["end_date"] = end_date

        return await self._client.post("/clear/indices", json=payload)

    async def ndvi(
        self,
        latitude: Optional[float] = None,
        longitude: Optional[float] = None,
        aoi: Optional[GeoJSON] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Calculate NDVI asynchronously."""
        return await self.calculate(
            index="NDVI",
            latitude=latitude,
            longitude=longitude,
            aoi=aoi,
            start_date=start_date,
            end_date=end_date,
        )

    async def evi(
        self,
        latitude: Optional[float] = None,
        longitude: Optional[float] = None,
        aoi: Optional[GeoJSON] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Calculate EVI asynchronously."""
        return await self.calculate(
            index="EVI",
            latitude=latitude,
            longitude=longitude,
            aoi=aoi,
            start_date=start_date,
            end_date=end_date,
        )

    async def list_available(self) -> List[Dict[str, Any]]:
        """List available indices asynchronously."""
        return await self._client.get("/clear/indices/available")
