"""
Models Resource

Run AI/ML models for segmentation and analysis.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional
import time

if TYPE_CHECKING:
    from ..client import Hisia, AsyncHisia

# GeoJSON types
GeoJSON = Dict[str, Any]


class Models:
    """
    Models resource for synchronous operations.

    Usage:
        client = Hisia()

        # Run flood detection
        job = client.models.segment(
            aoi={"type": "Polygon", "coordinates": [...]},
            model="prithvi-flood-v1",
            start_date="2025-01-01",
            end_date="2025-01-15"
        )

        # Wait for completion
        result = client.models.wait_for_job(job["job_id"])

        # Generate evidence pack
        evidence = client.models.create_evidence(
            execution_id=result["job_id"],
            format="pdf"
        )
    """

    def __init__(self, client: "Hisia"):
        self._client = client

    def segment(
        self,
        aoi: GeoJSON,
        model: str = "prithvi-flood-v1",
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        cloud_cover_max: int = 30,
        output_format: str = "geojson",
    ) -> Dict[str, Any]:
        """
        Run AI segmentation on satellite imagery.

        Args:
            aoi: Area of interest as GeoJSON Polygon
            model: Model to use (prithvi-flood-v1, burn-scar-v1, crop-v1)
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            cloud_cover_max: Maximum cloud cover percentage
            output_format: Output format (geojson, cog, both)

        Returns:
            Job information with job_id for tracking
        """
        payload: Dict[str, Any] = {
            "aoi": aoi,
            "model": model,
            "cloud_cover_max": cloud_cover_max,
            "output_format": output_format,
        }
        if start_date:
            payload["datetime_range"] = [start_date, end_date or start_date]

        return self._client.post("/modele/segment", json=payload)

    def get_job(self, job_id: str) -> Dict[str, Any]:
        """
        Get the status of a segmentation job.

        Args:
            job_id: The job ID

        Returns:
            Job status and results (if complete)
        """
        return self._client.get(f"/modele/segment/{job_id}")

    def wait_for_job(
        self,
        job_id: str,
        timeout: int = 300,
        poll_interval: int = 5,
    ) -> Dict[str, Any]:
        """
        Wait for a segmentation job to complete.

        Args:
            job_id: The job ID
            timeout: Maximum time to wait (seconds)
            poll_interval: Time between status checks (seconds)

        Returns:
            Completed job with results

        Raises:
            TimeoutError: If job doesn't complete within timeout
        """
        start_time = time.time()
        while time.time() - start_time < timeout:
            result = self.get_job(job_id)
            status = result.get("status", "").lower()

            if status in ("completed", "succeeded", "success"):
                return result
            if status in ("failed", "error"):
                raise Exception(f"Job failed: {result.get('error', 'Unknown error')}")

            time.sleep(poll_interval)

        raise TimeoutError(f"Job {job_id} did not complete within {timeout} seconds")

    def list_models(self) -> List[Dict[str, Any]]:
        """
        List available segmentation models.

        Returns:
            List of model information
        """
        return self._client.get("/modele/segment/models")

    def create_evidence(
        self,
        execution_id: str,
        format: str = "pdf",
        certification_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Generate an evidence pack from a model execution.

        Args:
            execution_id: The execution/job ID
            format: Output format (pdf, json)
            certification_type: Certification standard (ISO14064, Verra, GoldStandard)

        Returns:
            Evidence pack with download URL
        """
        payload: Dict[str, Any] = {
            "execution_id": execution_id,
            "format": format,
        }
        if certification_type:
            payload["certification_type"] = certification_type

        return self._client.post("/modele/evidence", json=payload)

    def get_provenance(self, job_id: str) -> Dict[str, Any]:
        """
        Get the provenance chain for a job.

        Args:
            job_id: The job ID

        Returns:
            Full provenance information for audit trail
        """
        return self._client.get(f"/modele/segment/{job_id}/provenance")


class AsyncModels:
    """
    Models resource for asynchronous operations.

    Usage:
        async with AsyncHisia() as client:
            job = await client.models.segment(
                aoi={"type": "Polygon", "coordinates": [...]},
                model="prithvi-flood-v1"
            )
            result = await client.models.wait_for_job(job["job_id"])
    """

    def __init__(self, client: "AsyncHisia"):
        self._client = client

    async def segment(
        self,
        aoi: GeoJSON,
        model: str = "prithvi-flood-v1",
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        cloud_cover_max: int = 30,
        output_format: str = "geojson",
    ) -> Dict[str, Any]:
        """Run AI segmentation asynchronously."""
        payload: Dict[str, Any] = {
            "aoi": aoi,
            "model": model,
            "cloud_cover_max": cloud_cover_max,
            "output_format": output_format,
        }
        if start_date:
            payload["datetime_range"] = [start_date, end_date or start_date]

        return await self._client.post("/modele/segment", json=payload)

    async def get_job(self, job_id: str) -> Dict[str, Any]:
        """Get job status asynchronously."""
        return await self._client.get(f"/modele/segment/{job_id}")

    async def wait_for_job(
        self,
        job_id: str,
        timeout: int = 300,
        poll_interval: int = 5,
    ) -> Dict[str, Any]:
        """Wait for job completion asynchronously."""
        import asyncio

        start_time = time.time()
        while time.time() - start_time < timeout:
            result = await self.get_job(job_id)
            status = result.get("status", "").lower()

            if status in ("completed", "succeeded", "success"):
                return result
            if status in ("failed", "error"):
                raise Exception(f"Job failed: {result.get('error', 'Unknown error')}")

            await asyncio.sleep(poll_interval)

        raise TimeoutError(f"Job {job_id} did not complete within {timeout} seconds")

    async def list_models(self) -> List[Dict[str, Any]]:
        """List available models asynchronously."""
        return await self._client.get("/modele/segment/models")

    async def create_evidence(
        self,
        execution_id: str,
        format: str = "pdf",
        certification_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Generate evidence pack asynchronously."""
        payload: Dict[str, Any] = {
            "execution_id": execution_id,
            "format": format,
        }
        if certification_type:
            payload["certification_type"] = certification_type

        return await self._client.post("/modele/evidence", json=payload)

    async def get_provenance(self, job_id: str) -> Dict[str, Any]:
        """Get provenance chain asynchronously."""
        return await self._client.get(f"/modele/segment/{job_id}/provenance")
