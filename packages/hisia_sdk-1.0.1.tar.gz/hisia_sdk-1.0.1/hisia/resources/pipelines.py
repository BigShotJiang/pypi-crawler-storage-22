"""
Pipelines Resource

Execute and manage data processing pipelines.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from ..client import Hisia, AsyncHisia


class Pipelines:
    """
    Pipelines resource for synchronous operations.

    Usage:
        client = Hisia()

        # List available pipelines
        pipelines = client.pipelines.list()

        # Execute a pipeline
        result = client.pipelines.execute(
            pipeline_id="pipe_abc123",
            input_data={
                "latitude": -1.2,
                "longitude": 36.8,
                "start_date": "2025-01-01",
                "end_date": "2025-01-31"
            }
        )

        # Check execution status
        status = client.pipelines.get_execution("exec_xyz789")
    """

    def __init__(self, client: "Hisia"):
        self._client = client

    def list(
        self,
        limit: int = 20,
        offset: int = 0,
        tags: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """
        List available pipelines.

        Args:
            limit: Maximum number of results
            offset: Pagination offset
            tags: Filter by tags

        Returns:
            List of pipeline metadata
        """
        params: Dict[str, Any] = {"limit": limit, "offset": offset}
        if tags:
            params["tags"] = ",".join(tags)

        return self._client.get("/clear/pipelines", params=params)

    def get(self, pipeline_id: str) -> Dict[str, Any]:
        """
        Get pipeline details.

        Args:
            pipeline_id: The pipeline ID

        Returns:
            Pipeline metadata and configuration
        """
        return self._client.get(f"/clear/pipelines/{pipeline_id}")

    def execute(
        self,
        pipeline_id: str,
        input_data: Dict[str, Any],
        async_execution: bool = False,
    ) -> Dict[str, Any]:
        """
        Execute a pipeline with input data.

        Args:
            pipeline_id: The pipeline ID to execute
            input_data: Input parameters for the pipeline
            async_execution: If True, return immediately with execution ID

        Returns:
            Pipeline execution result or execution ID (if async)
        """
        endpoint = f"/clear/pipelines/{pipeline_id}/execute-with-data"
        if async_execution:
            endpoint = f"/clear/pipelines/{pipeline_id}/execute-async"

        return self._client.post(endpoint, json={"input_data": input_data})

    def get_execution(self, execution_id: str) -> Dict[str, Any]:
        """
        Get the status and result of a pipeline execution.

        Args:
            execution_id: The execution ID

        Returns:
            Execution status and results
        """
        return self._client.get(f"/clear/executions/{execution_id}")

    def list_executions(
        self,
        pipeline_id: Optional[str] = None,
        limit: int = 20,
        status: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        List pipeline executions.

        Args:
            pipeline_id: Filter by pipeline ID
            limit: Maximum number of results
            status: Filter by status (pending, running, completed, failed)

        Returns:
            List of execution records
        """
        params: Dict[str, Any] = {"limit": limit}
        if pipeline_id:
            params["pipeline_id"] = pipeline_id
        if status:
            params["status"] = status

        return self._client.get("/clear/executions", params=params)


class AsyncPipelines:
    """
    Pipelines resource for asynchronous operations.

    Usage:
        async with AsyncHisia() as client:
            result = await client.pipelines.execute(
                pipeline_id="pipe_abc123",
                input_data={"latitude": -1.2, "longitude": 36.8}
            )
    """

    def __init__(self, client: "AsyncHisia"):
        self._client = client

    async def list(
        self,
        limit: int = 20,
        offset: int = 0,
        tags: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """List available pipelines asynchronously."""
        params: Dict[str, Any] = {"limit": limit, "offset": offset}
        if tags:
            params["tags"] = ",".join(tags)

        return await self._client.get("/clear/pipelines", params=params)

    async def get(self, pipeline_id: str) -> Dict[str, Any]:
        """Get pipeline details asynchronously."""
        return await self._client.get(f"/clear/pipelines/{pipeline_id}")

    async def execute(
        self,
        pipeline_id: str,
        input_data: Dict[str, Any],
        async_execution: bool = False,
    ) -> Dict[str, Any]:
        """Execute a pipeline asynchronously."""
        endpoint = f"/clear/pipelines/{pipeline_id}/execute-with-data"
        if async_execution:
            endpoint = f"/clear/pipelines/{pipeline_id}/execute-async"

        return await self._client.post(endpoint, json={"input_data": input_data})

    async def get_execution(self, execution_id: str) -> Dict[str, Any]:
        """Get execution status asynchronously."""
        return await self._client.get(f"/clear/executions/{execution_id}")

    async def list_executions(
        self,
        pipeline_id: Optional[str] = None,
        limit: int = 20,
        status: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """List pipeline executions asynchronously."""
        params: Dict[str, Any] = {"limit": limit}
        if pipeline_id:
            params["pipeline_id"] = pipeline_id
        if status:
            params["status"] = status

        return await self._client.get("/clear/executions", params=params)
