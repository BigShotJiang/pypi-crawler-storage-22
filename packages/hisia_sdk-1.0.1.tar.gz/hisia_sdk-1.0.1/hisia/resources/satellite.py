"""
Satellite Resource

Access satellite imagery and Earth observation data.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from ..client import Hisia, AsyncHisia


class Satellite:
    """
    Satellite imagery resource for synchronous operations.

    Usage:
        client = Hisia()

        # Search for Sentinel-2 imagery
        imagery = client.satellite.search(
            bbox=[36.7, -1.3, 36.9, -1.1],
            sensor="sentinel-2-l2a",
            start_date="2025-01-01",
            end_date="2025-01-31",
            cloud_cover_max=30
        )

        # Get imagery by coordinates
        scenes = client.satellite.imagery(
            latitude=-1.2,
            longitude=36.8,
            sensor="sentinel-2-l2a"
        )
    """

    def __init__(self, client: "Hisia"):
        self._client = client

    def search(
        self,
        bbox: Optional[List[float]] = None,
        latitude: Optional[float] = None,
        longitude: Optional[float] = None,
        sensor: str = "sentinel-2-l2a",
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        cloud_cover_max: int = 30,
        limit: int = 10,
    ) -> List[Dict[str, Any]]:
        """
        Search for satellite imagery.

        Args:
            bbox: Bounding box [min_lon, min_lat, max_lon, max_lat]
            latitude: Center latitude (alternative to bbox)
            longitude: Center longitude (alternative to bbox)
            sensor: Satellite sensor (sentinel-2-l2a, landsat-8, modis)
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            cloud_cover_max: Maximum cloud cover percentage (0-100)
            limit: Maximum number of results

        Returns:
            List of satellite scene metadata
        """
        params: Dict[str, Any] = {
            "sensor": sensor,
            "cloud_cover_max": cloud_cover_max,
            "limit": limit,
        }
        if bbox:
            params["bbox"] = ",".join(str(b) for b in bbox)
        if latitude is not None:
            params["latitude"] = latitude
        if longitude is not None:
            params["longitude"] = longitude
        if start_date:
            params["start_date"] = start_date
        if end_date:
            params["end_date"] = end_date

        return self._client.get("/flow/internal/satellite/imagery", params=params)

    def imagery(
        self,
        latitude: float,
        longitude: float,
        sensor: str = "sentinel-2-l2a",
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        cloud_cover_max: int = 30,
        limit: int = 10,
    ) -> List[Dict[str, Any]]:
        """
        Get satellite imagery for a specific location.

        Args:
            latitude: Location latitude
            longitude: Location longitude
            sensor: Satellite sensor
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            cloud_cover_max: Maximum cloud cover percentage
            limit: Maximum number of results

        Returns:
            List of satellite scene metadata
        """
        return self.search(
            latitude=latitude,
            longitude=longitude,
            sensor=sensor,
            start_date=start_date,
            end_date=end_date,
            cloud_cover_max=cloud_cover_max,
            limit=limit,
        )

    def vegetation(
        self,
        latitude: float,
        longitude: float,
        start_date: str,
        end_date: str,
        index: str = "NDVI",
    ) -> Dict[str, Any]:
        """
        Get vegetation indices for a location.

        Args:
            latitude: Location latitude
            longitude: Location longitude
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            index: Vegetation index (NDVI, EVI, SAVI)

        Returns:
            Time series of vegetation index values
        """
        return self._client.get(
            "/flow/satellite/vegetation",
            params={
                "latitude": latitude,
                "longitude": longitude,
                "start_date": start_date,
                "end_date": end_date,
                "index": index,
            },
        )

    def rainfall(
        self,
        latitude: float,
        longitude: float,
        start_date: str,
        end_date: str,
        source: str = "chirps",
    ) -> Dict[str, Any]:
        """
        Get rainfall data for a location.

        Args:
            latitude: Location latitude
            longitude: Location longitude
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            source: Data source (chirps, gpm, era5)

        Returns:
            Time series of rainfall values
        """
        return self._client.get(
            "/flow/satellite/rainfall",
            params={
                "latitude": latitude,
                "longitude": longitude,
                "start_date": start_date,
                "end_date": end_date,
                "source": source,
            },
        )

    def sensors(self) -> List[Dict[str, Any]]:
        """
        List available satellite sensors.

        Returns:
            List of sensor information
        """
        return self._client.get("/flow/satellite/sensors")


class AsyncSatellite:
    """
    Satellite imagery resource for asynchronous operations.

    Usage:
        async with AsyncHisia() as client:
            imagery = await client.satellite.search(
                bbox=[36.7, -1.3, 36.9, -1.1],
                sensor="sentinel-2-l2a"
            )
    """

    def __init__(self, client: "AsyncHisia"):
        self._client = client

    async def search(
        self,
        bbox: Optional[List[float]] = None,
        latitude: Optional[float] = None,
        longitude: Optional[float] = None,
        sensor: str = "sentinel-2-l2a",
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        cloud_cover_max: int = 30,
        limit: int = 10,
    ) -> List[Dict[str, Any]]:
        """Search for satellite imagery asynchronously."""
        params: Dict[str, Any] = {
            "sensor": sensor,
            "cloud_cover_max": cloud_cover_max,
            "limit": limit,
        }
        if bbox:
            params["bbox"] = ",".join(str(b) for b in bbox)
        if latitude is not None:
            params["latitude"] = latitude
        if longitude is not None:
            params["longitude"] = longitude
        if start_date:
            params["start_date"] = start_date
        if end_date:
            params["end_date"] = end_date

        return await self._client.get("/flow/internal/satellite/imagery", params=params)

    async def imagery(
        self,
        latitude: float,
        longitude: float,
        sensor: str = "sentinel-2-l2a",
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        cloud_cover_max: int = 30,
        limit: int = 10,
    ) -> List[Dict[str, Any]]:
        """Get satellite imagery for a specific location asynchronously."""
        return await self.search(
            latitude=latitude,
            longitude=longitude,
            sensor=sensor,
            start_date=start_date,
            end_date=end_date,
            cloud_cover_max=cloud_cover_max,
            limit=limit,
        )

    async def vegetation(
        self,
        latitude: float,
        longitude: float,
        start_date: str,
        end_date: str,
        index: str = "NDVI",
    ) -> Dict[str, Any]:
        """Get vegetation indices for a location asynchronously."""
        return await self._client.get(
            "/flow/satellite/vegetation",
            params={
                "latitude": latitude,
                "longitude": longitude,
                "start_date": start_date,
                "end_date": end_date,
                "index": index,
            },
        )

    async def rainfall(
        self,
        latitude: float,
        longitude: float,
        start_date: str,
        end_date: str,
        source: str = "chirps",
    ) -> Dict[str, Any]:
        """Get rainfall data for a location asynchronously."""
        return await self._client.get(
            "/flow/satellite/rainfall",
            params={
                "latitude": latitude,
                "longitude": longitude,
                "start_date": start_date,
                "end_date": end_date,
                "source": source,
            },
        )

    async def sensors(self) -> List[Dict[str, Any]]:
        """List available satellite sensors asynchronously."""
        return await self._client.get("/flow/satellite/sensors")
