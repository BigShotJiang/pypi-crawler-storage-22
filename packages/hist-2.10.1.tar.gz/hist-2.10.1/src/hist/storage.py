from __future__ import annotations

from boost_histogram.storage import (
    AtomicInt64,
    Double,
    Int64,
    Mean,
    Storage,
    Unlimited,
    Weight,
    WeightedMean,
)

__all__ = [
    "AtomicInt64",
    "Double",
    "Int64",
    "Mean",
    "Storage",
    "Unlimited",
    "Weight",
    "WeightedMean",
]

try:
    # pylint: disable-next=unused-import
    from boost_histogram.storage import MultiCell

    __all__ += ["MultiCell"]
except ImportError:
    pass
