======
sfplot
======


.. image:: https://img.shields.io/pypi/v/sfplot.svg
        :target: https://pypi.python.org/pypi/sfplot

.. image:: https://img.shields.io/travis/hutaobo/sfplot.svg
        :target: https://travis-ci.com/hutaobo/sfplot

.. image:: https://readthedocs.org/projects/sfplot/badge/?version=latest
        :target: https://sfplot.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status


.. image:: https://pyup.io/repos/github/hutaobo/sfplot/shield.svg
     :target: https://pyup.io/repos/github/hutaobo/sfplot/
     :alt: Updates



For plotting the Search and Find Plot (SFplot).


* Free software: MIT license
* Documentation: https://sfplot.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
