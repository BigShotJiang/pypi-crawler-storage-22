HistoSeg
========

.. toctree::
   :maxdepth: 2
   :caption: Tutorials

   tutorials/pattern1_isoline
