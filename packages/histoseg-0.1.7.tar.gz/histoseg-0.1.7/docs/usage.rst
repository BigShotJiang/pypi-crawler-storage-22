=====
Usage
=====

To use sfplot in a project::

    import sfplot
