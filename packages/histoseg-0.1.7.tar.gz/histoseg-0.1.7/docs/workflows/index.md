```{toctree}
:maxdepth: 1

../../workflows/contour_generation_pattern1
