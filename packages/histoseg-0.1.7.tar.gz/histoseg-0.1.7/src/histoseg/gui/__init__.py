# src/sfplot/gui/__init__.py

"""
sfplot.gui 子包，提供图形界面入口。
"""

from .gui_app import main

__all__ = ["main"]
