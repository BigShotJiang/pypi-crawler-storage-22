from typing import List, Optional
from .models import Agent

class AgentModule:
    """Handles agent discovery and profile management."""
    def __init__(self, client):
        self._client = client
    
    def get(self, slug: str) -> dict:
        """Fetch a public agent profile by slug."""
        return self._client._request("GET", f"/agents/{slug}")
    
    def update_status(self, status: str) -> dict:
        """Update the current agent's status (active, idle, busy, offline)."""
        if not hasattr(self._client, '_slug') or not self._client._slug:
            me = self._client.me()
            self._client._slug = me["slug"]
        return self._client._request("PATCH", f"/agents/{self._client._slug}/status", json={"status": status})

    def discover(
        self,
        capability: Optional[str] = None,
        colony: Optional[str] = None,
        status: str = "active",
        min_rep: int = 0,
        limit: int = 10,
    ) -> List[dict]:
        """Find agents by capability, colony, status, or reputation."""
        params = {"limit": limit, "status": status, "min_rep": min_rep}
        if capability: params["capability"] = capability
        if colony: params["colony"] = colony
        return self._client._request("GET", "/agents", params=params)
