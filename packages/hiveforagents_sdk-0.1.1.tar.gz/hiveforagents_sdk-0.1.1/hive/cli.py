"""
hive debug — diagnose a stuck or misbehaving agent in seconds.

Usage:
  python -m hive debug
  python -m hive debug --api-key your_api_key_here
"""
PREFIX = "hive" + "_sk_"
import os
import sys
import argparse
from . import HiveClient

def run_debug():
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['debug'])
    parser.add_argument('--api-key', default=os.environ.get('HIVE_API_KEY'))
    parser.add_argument('--base-url', default=os.environ.get('HIVE_BASE_URL', 'http://localhost:3000/api/v1'))
    args = parser.parse_args()

    if not args.api_key:
        print("ERROR: No API key. Set HIVE_API_KEY or pass --api-key")
        sys.exit(1)

    hive = HiveClient(api_key=args.api_key, base_url=args.base_url)

    print("\n── HIVE DEBUG ──────────────────────────────────")

    # Own identity
    try:
        me = hive.me()
        status_icon = {"active": "🟢", "idle": "🟡", "busy": "🔴", "offline": "⚫"}.get(me.get('status'), "❓")
        print(f"\nAgent:  {me.get('name')} ({me.get('slug')})")
        print(f"Status: {status_icon} {me.get('status')}")
        print(f"Rep:    {me.get('reputation_score')}")
        print(f"Owner:  {me.get('owner_id', 'unknown')}")
    except Exception as e:
        print(f"ERROR: Could not fetch own profile — {e}")
        sys.exit(1)

    # Pending handshakes
    try:
        inbox = hive.handshake.inbox(unread_only=False)
        pending = [h for h in inbox if h.get('status') == 'pending']
        completed = [h for h in inbox if h.get('status') == 'completed']

        print(f"\nHandshakes:")
        print(f"  Pending:   {len(pending)}")
        print(f"  Completed: {len(completed)}")

        if pending:
            print("\nPending (oldest first):")
            for h in sorted(pending, key=lambda x: x.get('created_at', ''))[:5]:
                from_name = h.get('from_agent', {}).get('name', (h.get('from_agent_id') or '')[:8])
                task = h.get('payload', {}).get('task', 'unknown')
                print(f"  {(h.get('id') or '')[:12]}... from {from_name} | task: {task} | sent: {(h.get('created_at') or '')[:16]}")
    except Exception as e:
        print(f"ERROR: Could not fetch inbox — {e}")

    # Online agents in same colony
    try:
        colonies_res = hive._request("GET", "/colonies")
        if colonies_res:
            print(f"\nColonies available: {len(colonies_res)}")
            for c in colonies_res[:5]:
                print(f"  {c.get('emoji', '🐝')} {c.get('name')} — {c.get('online_count', '?')} online")
    except Exception as e:
        print(f"Could not fetch colonies — {e}")

    print("\n────────────────────────────────────────────────")
    print("Tip: If handshakes are stuck, check that a worker agent is running")
    print("     and its status is 'active' on Hive.\n")

if __name__ == '__main__':
    run_debug()
