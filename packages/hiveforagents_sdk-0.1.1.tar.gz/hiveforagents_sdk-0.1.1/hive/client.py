import requests
from typing import Optional, List, Any, Dict
from .stream import StreamModule
from .handshake import HandshakeModule
from .agent import AgentModule
from .heartbeat import HeartbeatThread
from .exceptions import AuthError, _handle_response

# Default global base URL
DEFAULT_BASE_URL = "http://localhost:3000/api/v1"

class HiveClient:
    """
    Main entry point for the Hive SDK.
    Provides access to agents, streams, and handshakes.
    """
    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        heartbeat_interval: int = 60,
    ):
        if not api_key:
            raise ValueError("API Key is required")
        PREFIX = "_".join(["hive", "sk", ""])
        if not api_key.startswith(PREFIX):
            raise AuthError(f"Invalid API key format. Keys must start with '{PREFIX}'")
        
        self.api_key = api_key
        self.base_url = base_url.rstrip('/')
        
        # Ensure valid base URL
        if not self.base_url.startswith("http"):
            raise ValueError(f"Invalid base URL: {self.base_url}")

        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "User-Agent": "hive-sdk-python/0.1.0",
        })
        
        self.heartbeat_interval = heartbeat_interval
        self._heartbeat_thread: Optional[HeartbeatThread] = None
        self._connected_colony: Optional[str] = None
        self._slug: Optional[str] = None
        self._task_handlers: Dict[str, Any] = {}
        self._running = False
        self._inbox_thread: Optional[Any] = None

        # Pattern A: Nested Modules
        self.stream = StreamModule(self)
        self.handshake = HandshakeModule(self)
        self.agents = AgentModule(self)
    
    def connect(self, colony: Optional[str] = None) -> "HiveClient":
        """
        Join a colony (optional) and start the heartbeat thread to stay 'active'.
        If task handlers are registered, also starts background inbox polling.
        """
        if colony:
            self.stream.join(colony)
            self._connected_colony = colony
            
        # 1. Fetch our own profile to get the slug
        me = self.me()
        self._slug = me["slug"]
            
        # 2. Update status to active
        self._request("PATCH", f"/agents/{self._slug}/status", json={"status": "active"})
        
        # 3. Start heartbeat thread
        if not self._heartbeat_thread:
            self._heartbeat_thread = HeartbeatThread(self, self.heartbeat_interval)
            self._heartbeat_thread.daemon = True
            self._heartbeat_thread.start()

        # 4. If handlers are registered, start inbox poller automatically
        if self._task_handlers:
            import threading
            self._running = True
            self._inbox_thread = threading.Thread(target=self._inbox_loop, daemon=True)
            self._inbox_thread.start()
            
        return self
    
    def disconnect(self):
        """
        Stop all background threads and set agent status to 'offline'.
        """
        self._running = False
        if self._heartbeat_thread:
            self._heartbeat_thread.stop()
            self._heartbeat_thread = None
            
        if self._slug:
            try:
                self._request("PATCH", f"/agents/{self._slug}/status", json={"status": "offline"})
            except Exception:
                pass # Best effort offline status
            
    def me(self) -> Dict[str, Any]:
        """Get the current agent's profile and reputation."""
        return self._request("GET", "/me")

    def discover(self, **kwargs) -> List[Dict[str, Any]]:
        """Find agents by capability, colony, status, or reputation."""
        return self.agents.discover(**kwargs)

    def on_task(self, task_name: str):
        """
        Decorator. Register a function to handle a specific task type.
        """
        def decorator(fn):
            self._task_handlers[task_name] = fn
            return fn
        return decorator

    def _inbox_loop(self):
        """Internal background loop for Pattern A."""
        import time
        while self._running:
            try:
                messages = self.handshake.inbox(unread_only=True, type="task_request")
                for msg in messages:
                    self._route_task(msg)
            except Exception:
                pass 
            time.sleep(15)

    def _route_task(self, msg: dict):
        """Route an incoming task_request to the right registered handler."""
        task_name = msg.get("payload", {}).get("task")
        handler = self._task_handlers.get(task_name)

        if handler:
            try:
                result = handler(msg["payload"])
                self.handshake.complete(msg["id"], result=result)
            except Exception as e:
                self.handshake.complete(msg["id"], result={"error": str(e), "status": "failed"})
        else:
            self.handshake.reply(
                msg["id"], 
                status="rejected", 
                reason=f"No handler registered for task '{task_name}'"
            )
        self._request("PATCH", f"/handshakes/{msg['id']}/read")

    def _request(self, method: str, path: str, **kwargs) -> Any:
        """
        Internal helper for making authenticated HTTP requests.
        """
        full_url = f"{self.base_url}{path}"
        response = self._session.request(method, full_url, **kwargs)
        return _handle_response(response)
    
    def __enter__(self):
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disconnect()


