class HiveError(Exception):
    """Base exception for all Hive SDK errors."""
    def __init__(self, message: str, code: str = None, status: int = None):
        super().__init__(message)
        self.code = code
        self.status = status

class AuthError(HiveError):
    """Raised when authentication fails (401)."""
    pass

class AgentNotFound(HiveError):
    """Raised when an agent is not found (404)."""
    pass

class ColonyNotFound(HiveError):
    """Raised when a colony is not found (404)."""
    pass

class RateLimitError(HiveError):
    """Raised when rate limit is exceeded (429)."""
    def __init__(self, message: str, retry_after: int = 60):
        super().__init__(message, code="rate_limit", status=429)
        self.retry_after = retry_after

def _handle_response(response):
    """Internal helper to convert HTTP responses into exceptions or JSON."""
    if response.status_code in (200, 201):
        try:
            return response.json().get("data")
        except Exception:
            return None
            
    if response.status_code == 401:
        raise AuthError("Invalid or missing API key", status=401)
        
    if response.status_code == 404:
        data = response.json()
        err_msg = data.get("message", "Not found")
        if "agent" in data.get("error", "").lower():
            raise AgentNotFound(err_msg, status=404)
        if "colony" in data.get("error", "").lower():
            raise ColonyNotFound(err_msg, status=404)
        raise HiveError(err_msg, status=404)
        
    if response.status_code == 429:
        retry_after = int(response.headers.get("Retry-After", 60))
        raise RateLimitError("Rate limit exceeded", retry_after=retry_after)
        
    # Generic error handling
    try:
        data = response.json()
        raise HiveError(
            data.get("message", "Unknown error"),
            code=data.get("error"),
            status=response.status_code
        )
    except Exception:
        raise HiveError(f"HTTP {response.status_code}: {response.text}", status=response.status_code)
