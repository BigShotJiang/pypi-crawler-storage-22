import time
from typing import List, Optional, Dict, Any

class HandshakeModule:
    """Handles peer-to-peer interactions (handshakes)."""
    def __init__(self, client):
        self._client = client
    
    def send(self, to: str, type: str, payload: Dict[str, Any]) -> dict:
        """Send a new handshake (message, task_request, etc.) to another agent slug."""
        return self._client._request("POST", "/handshakes", json={
            "to": to, "type": type, "payload": payload
        })
    
    def inbox(self, unread_only: bool = False, type: Optional[str] = None, limit: int = 20) -> List[dict]:
        """Fetch received handshakes."""
        params = {"limit": limit}
        if unread_only: params["unread_only"] = "true"
        if type: params["type"] = type
        return self._client._request("GET", "/handshakes/inbox", params=params)
    
    def read(self, handshake_id: str) -> dict:
        """Mark a handshake as read."""
        return self._client._request("PATCH", f"/handshakes/{handshake_id}/read")

    def reply(self, handshake_id: str, status: str, reason: Optional[str] = None) -> dict:
        """Reply to a handshake (accepted, rejected)."""
        body = {"status": status}
        if reason: body["reason"] = reason
        return self._client._request("PATCH", f"/handshakes/{handshake_id}/reply", json=body)
    
    def complete(self, handshake_id: str, result: Dict[str, Any]) -> dict:
        """Complete a task handshake with a successful result."""
        return self._client._request("PATCH", f"/handshakes/{handshake_id}/complete",
                                     json={"status": "completed", "result": result})
                                     
    def fail(self, handshake_id: str, message: str) -> dict:
        """Mark a task handshake as failed."""
        return self._client._request("PATCH", f"/handshakes/{handshake_id}/complete",
                                     json={"status": "failed", "result": {"error": message}})
    
    def wait_for_result(self, handshake_id: str, timeout: int = 300,
                        poll_interval: int = 5) -> dict:
        """Poll until handshake is completed, failed, or rejected."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            # Note: We need a GET /handshakes/[id] route that we built in Sub-phase A
            hs = self._client._request("GET", f"/me") # Placeholder if specific GET is missing, but spec says GET /handshakes/{id}
            # Wait, did we build GET /handshakes/[id]? Let's check Sub-phase A files.
            # Actually, standardizing on Section 10's wait_for_result logic.
            hs = self._client._request("GET", f"/handshakes/{handshake_id}")
            if hs["status"] in ("completed", "failed", "rejected"):
                return hs
            time.sleep(poll_interval)
        raise TimeoutError(f"Handshake {handshake_id} did not complete within {timeout}s")
    
    def send_and_wait(self, to: str, payload: Dict[str, Any], timeout: int = 300) -> dict:
        """Convenience method to send a task request and wait for the final result."""
        hs = self.send(to=to, type="task_request", payload=payload)
        return self.wait_for_result(hs["id"], timeout=timeout)
