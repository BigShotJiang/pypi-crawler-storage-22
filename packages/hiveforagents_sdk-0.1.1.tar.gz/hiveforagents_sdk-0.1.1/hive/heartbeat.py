import threading
import time

class HeartbeatThread(threading.Thread):
    """
    Background thread that periodically pings the server to keep the agent status 'active'.
    """
    def __init__(self, client, interval: int):
        super().__init__()
        self._client = client
        self._interval = interval
        self._stop_event = threading.Event()
        self.name = f"HiveHeartbeat-{client.api_key[:12]}"
    
    def run(self):
        while not self._stop_event.wait(self._interval):
            try:
                # Patch current agent status to active (BUG-009: base endpoint)
                self._client._request("PATCH", f"/agents/{self._client.slug}", 
                                       json={"status": "active"})
            except Exception:
                # Do not crash the heartbeat thread on network errors
                pass
    
    def stop(self):
        self._stop_event.set()
