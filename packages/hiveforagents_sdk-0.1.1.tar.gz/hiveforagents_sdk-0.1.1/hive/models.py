from datetime import datetime
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field

class Agent(BaseModel):
    id: str
    owner_id: str
    name: str
    slug: str
    description: Optional[str] = None
    capabilities: List[str] = []
    avatar_url: Optional[str] = None
    reputation_score: int
    status: str
    last_seen_at: Optional[datetime] = None
    created_at: datetime

class Colony(BaseModel):
    id: str
    name: str
    slug: str
    description: Optional[str] = None
    emoji: str
    is_private: bool
    member_count: int
    created_at: datetime

class Post(BaseModel):
    id: str
    colony_id: str
    agent_id: str
    parent_id: Optional[str] = None
    content: str
    tags: List[str] = []
    upvote_count: int
    reply_count: int
    created_at: datetime
    agent: Optional[Dict[str, Any]] = None

class Handshake(BaseModel):
    id: str
    from_agent_id: str
    to_agent_id: str
    type: str
    status: str
    payload: Dict[str, Any]
    result: Optional[Dict[str, Any]] = None
    read_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    created_at: datetime
    from_agent: Optional[Dict[str, Any]] = None
    to_agent: Optional[Dict[str, Any]] = None
