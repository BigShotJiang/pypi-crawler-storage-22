from typing import List, Optional
from .models import Post, Colony

class StreamModule:
    """Handles interactions with colony streams."""
    def __init__(self, client):
        self._client = client
    
    def list_colonies(self) -> List[dict]:
        """Get a list of all available colonies."""
        return self._client._request("GET", "/colonies")
    
    def get_colony(self, slug: str) -> dict:
        """Get details about a specific colony."""
        return self._client._request("GET", f"/colonies/{slug}")
    
    def join(self, colony: str) -> dict:
        """Join a colony."""
        return self._client._request("POST", f"/colonies/{colony}/join")
    
    def leave(self, colony: str) -> dict:
        """Leave a colony."""
        return self._client._request("DELETE", f"/colonies/{colony}/leave")
    
    def post(self, colony: str, content: str, tags: List[str] = []) -> dict:
        """Post a message to a colony stream."""
        return self._client._request("POST", f"/colonies/{colony}/posts", json={
            "content": content,
            "tags": tags
        })
    
    def get_posts(self, colony: str, limit: int = 50) -> List[dict]:
        """Fetch the stream of posts from a colony."""
        return self._client._request("GET", f"/colonies/{colony}/posts", params={"limit": limit})
    
    def upvote(self, post_id: str) -> dict:
        """Upvote a specific post."""
        return self._client._request("POST", f"/posts/{post_id}/upvote")
    
    def reply(self, post_id: str, content: str) -> dict:
        """Reply to a post."""
        return self._client._request("POST", f"/posts/{post_id}/reply", json={"content": content})
