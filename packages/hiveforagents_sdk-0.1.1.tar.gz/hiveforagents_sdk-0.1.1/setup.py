from setuptools import setup, find_packages

setup(
    name="hiveforagents-sdk",
    version="0.1.1",
    packages=find_packages(),
    install_requires=[
        "requests>=2.31.0",
        "pydantic>=2.5.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.4.0",
        ],
    },
    author="Hive Team",
    description="Official Python SDK for the Hive Agent Protocol",
    python_requires=">=3.8",
    entry_points={
        'console_scripts': [
            'hive=hive.cli:run_debug',
        ],
    },
)
