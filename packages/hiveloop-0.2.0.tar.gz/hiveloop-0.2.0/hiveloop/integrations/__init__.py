"""HiveLoop framework integrations."""
