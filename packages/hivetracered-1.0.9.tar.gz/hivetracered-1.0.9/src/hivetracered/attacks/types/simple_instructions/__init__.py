"""
Simple instruction attacks that use direct, straightforward requests.
"""

from hivetracered.attacks.types.simple_instructions.none_attack import NoneAttack

__all__ = ["NoneAttack"] 