"""Configuration for Heimdall SDK."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Optional, Dict, Any


@dataclass
class HeimdallConfig:
    """Configuration for the Heimdall observability client.

    Attributes:
        api_key: API key for authenticating with Heimdall platform.
        endpoint: The Heimdall platform endpoint URL.
        service_name: Name of the service being instrumented.
        environment: Deployment environment (e.g., 'production', 'staging').
        org_id: Organization ID from Heimdall dashboard.
        project_id: Project ID to associate traces with in Heimdall.
        session_id: Session ID to associate with all spans. Useful for tracking
            requests from the same MCP client session.
        user_id: User ID to associate with all spans. Can be overridden per-span
            using user_extractor option in decorators.
        enabled: Whether tracing is enabled.
        debug: Enable debug logging.
        batch_size: Number of spans to batch before sending.
        flush_interval_ms: Interval in milliseconds to flush spans.
        max_queue_size: Maximum number of spans to queue.
        metadata: Additional metadata to attach to all spans.
    """

    api_key: Optional[str] = field(
        default_factory=lambda: os.environ.get("HEIMDALL_API_KEY")
    )
    endpoint: str = field(
        default_factory=lambda: os.environ.get(
            "HEIMDALL_ENDPOINT", "http://localhost:4318"
        )
    )
    service_name: str = field(
        default_factory=lambda: os.environ.get("HEIMDALL_SERVICE_NAME", "mcp-server")
    )
    environment: str = field(
        default_factory=lambda: os.environ.get("HEIMDALL_ENVIRONMENT", "development")
    )
    org_id: str = field(
        default_factory=lambda: os.environ.get("HEIMDALL_ORG_ID", "default")
    )
    project_id: str = field(
        default_factory=lambda: os.environ.get("HEIMDALL_PROJECT_ID", "default")
    )
    session_id: Optional[str] = field(
        default_factory=lambda: os.environ.get("HEIMDALL_SESSION_ID")
    )
    user_id: Optional[str] = field(
        default_factory=lambda: os.environ.get("HEIMDALL_USER_ID")
    )
    enabled: bool = field(
        default_factory=lambda: os.environ.get("HEIMDALL_ENABLED", "true").lower() == "true"
    )
    debug: bool = field(
        default_factory=lambda: os.environ.get("HEIMDALL_DEBUG", "false").lower() == "true"
    )
    batch_size: int = field(
        default_factory=lambda: int(os.environ.get("HEIMDALL_BATCH_SIZE", "100"))
    )
    flush_interval_ms: int = field(
        default_factory=lambda: int(os.environ.get("HEIMDALL_FLUSH_INTERVAL_MS", "5000"))
    )
    max_queue_size: int = field(
        default_factory=lambda: int(os.environ.get("HEIMDALL_MAX_QUEUE_SIZE", "1000"))
    )
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def validate(self) -> None:
        """Validate the configuration."""
        # API key is optional for local development
        if self.batch_size < 1:
            raise ValueError("batch_size must be at least 1")
        if self.flush_interval_ms < 100:
            raise ValueError("flush_interval_ms must be at least 100")
        if self.max_queue_size < self.batch_size:
            raise ValueError("max_queue_size must be at least batch_size")
    
    @classmethod
    def from_env(cls) -> "HeimdallConfig":
        """Create configuration from environment variables."""
        return cls()

