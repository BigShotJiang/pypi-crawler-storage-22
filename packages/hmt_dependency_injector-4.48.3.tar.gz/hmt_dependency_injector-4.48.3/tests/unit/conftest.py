"""Fixtures module."""

import sys
import os.path


# Add current package to import samples/ dir
sys.path.append(os.path.dirname(__file__))
