"""Tests for coroutine providers."""
