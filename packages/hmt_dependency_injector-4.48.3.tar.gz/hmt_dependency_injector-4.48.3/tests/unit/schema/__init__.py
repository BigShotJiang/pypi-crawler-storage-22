"""Schema tests."""
