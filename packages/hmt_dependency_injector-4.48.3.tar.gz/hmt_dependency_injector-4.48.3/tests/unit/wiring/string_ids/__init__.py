"""Tests for wiring based on provider string name identification."""
