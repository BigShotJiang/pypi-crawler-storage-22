
Attribution
===========


* Macaw example taken from image in the public domain.

* Penguins image taken from wikimedia commons, licensed under Creative Commons Attribution 2.0 Generic license.

  Author: Ian Duffy
  https://commons.wikimedia.org/wiki/File:Aptenodytes_forsteri_-Snow_Hill_Island,_Antarctica_-adults_and_juvenile-8.jpg
