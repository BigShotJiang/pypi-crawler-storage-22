import pytest

pytest.importorskip("matplotlib")
