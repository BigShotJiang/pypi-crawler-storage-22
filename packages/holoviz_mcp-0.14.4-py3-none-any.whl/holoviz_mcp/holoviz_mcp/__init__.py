"""docs_mcp package."""
