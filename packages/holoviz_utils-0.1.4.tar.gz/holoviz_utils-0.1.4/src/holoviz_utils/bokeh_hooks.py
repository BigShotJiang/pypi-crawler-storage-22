class BokehHooks:
    def hook_no_logo(self, plot, element):
        plot.state.toolbar.logo = None

    def hook_no_yaxis(self, plot, element):
        plot.state.yaxis.visible = False  # turn off y-axis

    def hook_no_toolbar(self, plot, element):
        plot.state.toolbar_location = None  # turn off the toolbar

    def hook_transparent_border(self, plot, element):
        plot.state.border_fill_alpha = 0.0

    def beige_background(self, plot, element):
        plot.state.background_fill_color = "LightGray"
        plot.state.background_fill_alpha = 1.0
        plot.state.outline_line_alpha = 0.0

    def no_xlabel(self, plot, element):
        plot.state.xaxis.axis_label = ""

    def horizontal_grid(self, plot, element):
        plot.state.ygrid.grid_line_alpha = 0.95
        plot.state.ygrid.grid_line_color = "White"
        plot.state.ygrid.grid_line_dash = [6, 4]

    def fine_horizontal_grid(self, plot, element):
        plot.state.ygrid.grid_line_alpha = 0.5
        plot.state.ygrid.grid_line_width = 0.5
        plot.state.ygrid.grid_line_color = "Black"
        plot.state.ygrid.grid_line_dash = [2, 2]

    def vertical_grid(self, plot, element):
        plot.state.xgrid.grid_line_alpha = 0.95
        plot.state.xgrid.grid_line_color = "White"
        plot.state.xgrid.grid_line_dash = [6, 4]

    def ylabel_space(self, plot, element, spacing=75):
        plot.state.min_border_left = spacing
