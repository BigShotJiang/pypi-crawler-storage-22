"""Test suite for Home Assistant Stream Deck YAML."""
