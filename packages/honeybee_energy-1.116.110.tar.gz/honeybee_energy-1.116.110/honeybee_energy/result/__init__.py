"""honeybee-energy simulation settings."""
