def main():
    print("Hello from honeymcp!")


if __name__ == "__main__":
    main()
