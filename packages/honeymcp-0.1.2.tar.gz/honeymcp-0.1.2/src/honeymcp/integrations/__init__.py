"""External integrations for HoneyMCP."""

__all__: list[str] = []
