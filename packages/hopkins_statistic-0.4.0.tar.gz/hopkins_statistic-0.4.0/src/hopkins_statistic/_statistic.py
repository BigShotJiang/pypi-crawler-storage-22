import math
import numbers
from typing import Any

import numpy as np
from numpy.typing import ArrayLike
from scipy.spatial import KDTree

from hopkins_statistic._typing import RNGLike, SeedLike


def hopkins(
    X: ArrayLike,
    *,
    m: int | float = 0.1,
    toroidal: bool = False,
    power: int | float | None = None,
    rng: RNGLike | SeedLike | None = None,
) -> float:
    """Compute the Hopkins statistic.

    The Hopkins statistic measures clustering tendency by comparing
    nearest-neighbor distances of sampled data points with those of
    points placed uniformly at random in the sampling frame, here
    approximated by the axis-aligned bounding box of `X`.

    Args:
        X: Array-like of shape `(n, d)`, with `n >= 3` observations
            in `d >= 1` dimensions. Must contain only finite values.
        m: Sample size, or its fraction of `n`.
            - If int, this must satisfy `1 <= m <= n`.
            - If float, this must satisfy `0 < m <= 1`,
              and the sample size is `ceil(m * n)`.
        toroidal: If True, compute distances with periodic boundary conditions.
        power: Exponent applied to Euclidean distances. Defaults to `d`.
            Must be positive and finite.
        rng: Random number generator or seed passed to
            `numpy.random.default_rng`. Specify for repeatable behavior.

    Returns:
        The Hopkins statistic, a value between 0 and 1 (NaN if undefined).

    """
    X = np.asarray(X, dtype=float)

    n, d = _validate_shape(X)
    m = _parse_m(m, n)
    toroidal = _parse_toroidal(toroidal)
    power = _parse_power(power, d)
    rng = np.random.default_rng(rng)

    if not np.isfinite(X).all():
        msg = "X must contain only finite values; found NaN or inf."
        raise ValueError(msg)

    lower, upper = X.min(axis=0), X.max(axis=0)

    boxsize = None
    if toroidal:
        X = np.asarray(X - lower)
        lower, upper = 0, upper - lower
        boxsize = np.nextafter(upper, np.inf)

    null_sample = rng.uniform(lower, upper, size=(m, d))
    data_sample = X[rng.choice(n, size=m, replace=False)]

    tree = KDTree(X, boxsize=boxsize)
    u = tree.query(null_sample, k=1)[0]
    w = np.asarray(tree.query(data_sample, k=2)[0])[:, 1]  # 1st NN is itself

    u_sum = np.sum(u**power)
    w_sum = np.sum(w**power)

    return float(u_sum / (u_sum + w_sum))


def _validate_shape(
    X: np.ndarray[Any, np.dtype[np.float64]],
) -> tuple[int, int]:
    if X.ndim != 2:
        msg = f"X must be a 2D array of shape (n, d); got shape {X.shape}."
        raise ValueError(msg)

    n, d = X.shape
    if n < 3:
        msg = f"X must contain at least 3 observations; got n={n}."
        raise ValueError(msg)
    if d < 1:
        msg = "X must have at least 1 feature (d >= 1); got d=0."
        raise ValueError(msg)

    return n, d


def _parse_m(m: int | float, n: int) -> int:
    if isinstance(m, numbers.Integral) and not isinstance(m, bool):
        if not 1 <= m <= n:
            msg = f"m must satisfy 1 <= m <= n; got m={m}, n={n}."
            raise ValueError(msg)
        return int(m)

    if isinstance(m, numbers.Real) and not isinstance(m, bool):
        if not 0 < m <= 1:
            msg = f"If m is a float, it must satisfy 0 < m <= 1; got m={m}."
            raise ValueError(msg)
        return math.ceil(m * n)

    msg = f"m must be int or float; got {type(m).__name__}."
    raise TypeError(msg)


def _parse_toroidal(toroidal: bool) -> bool:  # noqa: FBT001
    if isinstance(toroidal, (bool, np.bool_)):
        return bool(toroidal)
    msg = f"toroidal must be bool; got {type(toroidal).__name__}"
    raise TypeError(msg)


def _parse_power(power: int | float | None, d: int) -> int | float:
    if power is None:
        return d

    if not isinstance(power, numbers.Real) or isinstance(power, bool):
        msg = f"power must be a real number; got {type(power).__name__}."
        raise TypeError(msg)

    if not math.isfinite(power):
        msg = f"power must be finite; got power={power}."
        raise ValueError(msg)
    if power <= 0:
        msg = f"power must be positive; got power={power}."
        raise ValueError(msg)

    return power
