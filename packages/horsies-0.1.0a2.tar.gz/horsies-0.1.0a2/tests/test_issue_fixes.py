"""Tests for issue fixes from ISSUES.TXT."""

import logging
import pytest

from horsies.core.errors import (
    WorkflowValidationError,
    ErrorCode,
    HorsiesError,
)
from horsies.core.models.workflow import slugify, NODE_ID_PATTERN
from horsies.core.logging import get_logger, set_default_level, _default_level


class TestSlugify:
    """Tests for Issue #1: slugify() function and workflow name handling."""

    def test_slugify_replaces_spaces_with_underscores(self) -> None:
        assert slugify("Hello World") == "Hello_World"
        assert slugify("My Workflow Name") == "My_Workflow_Name"

    def test_slugify_preserves_valid_characters(self) -> None:
        # Colons, dots, hyphens are valid
        assert slugify("task:v2.0") == "task:v2.0"
        assert slugify("my-task-name") == "my-task-name"
        assert slugify("prefix.suffix") == "prefix.suffix"

    def test_slugify_removes_invalid_characters(self) -> None:
        assert slugify("Hello!World") == "HelloWorld"
        assert slugify("test@#$%chars") == "testchars"
        assert slugify("parentheses(removed)") == "parenthesesremoved"

    def test_slugify_handles_mixed_input(self) -> None:
        # Spaces become underscores, invalid chars removed
        assert slugify("My App: v2.0!") == "My_App:_v2.0"
        assert slugify("Company Name (Inc.)") == "Company_Name_Inc."

    def test_slugify_returns_underscore_for_empty_result(self) -> None:
        assert slugify("!@#$%") == "_"
        assert slugify("") == "_"

    def test_slugify_output_matches_node_id_pattern(self) -> None:
        test_inputs = [
            "Hello World",
            "My Company Name GmbH",
            "task:v2.0",
            "special!@#chars",
            "mixed Input-with_stuff.here",
        ]
        for input_str in test_inputs:
            result = slugify(input_str)
            assert NODE_ID_PATTERN.match(result) is not None, (
                f"slugify({input_str!r}) = {result!r} doesn't match NODE_ID_PATTERN"
            )


class TestLogLevel:
    """Tests for Issue #2: Log level propagation."""

    def test_set_default_level_changes_module_variable(self) -> None:
        from horsies.core import logging as horsies_logging

        original = horsies_logging._default_level

        set_default_level(logging.DEBUG)
        assert horsies_logging._default_level == logging.DEBUG

        set_default_level(logging.WARNING)
        assert horsies_logging._default_level == logging.WARNING

        # Restore
        set_default_level(original)

    def test_new_logger_uses_default_level(self) -> None:
        from horsies.core import logging as horsies_logging

        # Set a specific level
        set_default_level(logging.WARNING)

        # Create a new logger with unique name to avoid caching
        import uuid
        unique_name = f"test_{uuid.uuid4().hex[:8]}"
        logger = get_logger(unique_name)

        assert logger.level == logging.WARNING

        # Restore default
        set_default_level(logging.INFO)

    def test_logger_handler_respects_default_level(self) -> None:
        from horsies.core import logging as horsies_logging

        set_default_level(logging.ERROR)

        import uuid
        unique_name = f"test_{uuid.uuid4().hex[:8]}"
        logger = get_logger(unique_name)

        # Handler should also have the level set
        assert len(logger.handlers) > 0
        for handler in logger.handlers:
            assert handler.level == logging.ERROR

        # Restore
        set_default_level(logging.INFO)


class TestErrorFormatting:
    """Tests for Issue #3: Plain text in error __str__()."""

    def test_str_does_not_contain_ansi_codes(self) -> None:
        err = WorkflowValidationError(
            message="test error message",
            code=ErrorCode.WORKFLOW_INVALID_NODE_ID,
            notes=["note one", "note two"],
            help_text="helpful suggestion",
        )

        error_str = str(err)

        # Check for common ANSI escape sequences
        assert '\033[' not in error_str, "Found ANSI escape in str()"
        assert '\x1b[' not in error_str, "Found ANSI escape in str()"
        assert '[0m' not in error_str, "Found ANSI reset code in str()"
        assert '[91m' not in error_str, "Found ANSI color code in str()"

    def test_format_rust_style_with_colors_contains_ansi(self) -> None:
        err = WorkflowValidationError(
            message="test error message",
            code=ErrorCode.WORKFLOW_INVALID_NODE_ID,
        )

        colored = err.format_rust_style(use_colors=True)

        # Should contain ANSI codes
        assert '\033[' in colored or '\x1b[' in colored, (
            "format_rust_style(use_colors=True) should contain ANSI codes"
        )

    def test_format_rust_style_without_colors_no_ansi(self) -> None:
        err = WorkflowValidationError(
            message="test error message",
            code=ErrorCode.WORKFLOW_INVALID_NODE_ID,
        )

        plain = err.format_rust_style(use_colors=False)

        assert '\033[' not in plain
        assert '\x1b[' not in plain

    def test_error_str_contains_message_and_code(self) -> None:
        err = WorkflowValidationError(
            message="my specific error",
            code=ErrorCode.WORKFLOW_INVALID_NODE_ID,
            notes=["important note"],
            help_text="try this fix",
        )

        error_str = str(err)

        assert "my specific error" in error_str
        assert "E003" in error_str  # WORKFLOW_INVALID_NODE_ID
        assert "important note" in error_str
        assert "try this fix" in error_str

    def test_error_str_safe_for_json_serialization(self) -> None:
        import json

        err = WorkflowValidationError(
            message="workflow name too long",
            code=ErrorCode.WORKFLOW_INVALID_NODE_ID,
            notes=["workflow name: 'My Long Name'"],
            help_text="use a shorter name",
        )

        # Should be JSON-serializable without issues
        error_str = str(err)
        json_data = {"error": error_str}
        serialized = json.dumps(json_data)
        deserialized = json.loads(serialized)

        assert deserialized["error"] == error_str
        # No ANSI codes should appear in the JSON
        assert '\u001b' not in serialized


class TestWorkflowNameErrorMessages:
    """Tests for error message clarity (workflow name vs node_id)."""

    def test_error_message_for_workflow_name_too_long(self) -> None:
        # This tests that error messages correctly blame workflow name
        # when node_id is auto-generated from a long workflow name
        from horsies.core.models.workflow import WorkflowSpec, TaskNode

        # We can't easily test the full workflow without a broker,
        # but we can verify the slugify behavior for long names
        long_name = "A" * 200
        slugified = slugify(long_name)

        # Slugified name should be same length (no invalid chars to remove)
        assert len(slugified) == 200

        # node_id would be f"{slugified}:0" = 202 chars, exceeding 128 limit
        # The error should mention "workflow name too long" not "node_id too long"


class TestNodeIdValidation:
    """Tests for node_id pattern validation."""

    def test_valid_node_ids(self) -> None:
        valid_ids = [
            "simple",
            "with_underscore",
            "with-hyphen",
            "with:colon",
            "with.dot",
            "MixedCase123",
            "workflow_name:0",
            "my-task.v2:42",
        ]
        for node_id in valid_ids:
            assert NODE_ID_PATTERN.match(node_id) is not None, (
                f"{node_id!r} should be valid"
            )

    def test_invalid_node_ids(self) -> None:
        invalid_ids = [
            "with space",
            "with!exclaim",
            "with@at",
            "with#hash",
            "with$dollar",
            "with%percent",
            "(parentheses)",
            "",
        ]
        for node_id in invalid_ids:
            match = NODE_ID_PATTERN.match(node_id)
            assert match is None, f"{node_id!r} should be invalid"
