"""CLI模块"""

from .cli import CLI

__all__ = ['CLI']
