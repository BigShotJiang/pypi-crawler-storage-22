"""Markdown到HTML格式转换器"""

from typing import Any, Optional, Dict
from hos_m2f.converters.base_converter import BaseConverter
import mistune


class MDToHTMLConverter(BaseConverter):
    """Markdown到HTML格式转换器"""
    
    def convert(self, input_content: str, options: Optional[Dict[str, Any]] = None) -> bytes:
        """将Markdown转换为HTML
        
        Args:
            input_content: Markdown内容
            options: 转换选项
            
        Returns:
            bytes: HTML文件的二进制数据
        """
        if options is None:
            options = {}
        
        # 解析Markdown
        markdown = mistune.create_markdown()

        
        # 转换为HTML
        html_content = markdown(input_content)
        
        # 生成完整的HTML文档
        full_html = f'''
        <!DOCTYPE html>
        <html>
        <head>
            <title>{options.get('title', 'Untitled')}</title>
            <meta charset="utf-8" />
            <style>
                body {{
                    font-family: Arial, sans-serif;
                    line-height: 1.6;
                    margin: 20px;
                    max-width: 800px;
                }}
                h1, h2, h3, h4, h5, h6 {{
                    color: #333;
                }}
                code {{
                    background-color: #f4f4f4;
                    padding: 2px 4px;
                    border-radius: 3px;
                }}
                pre {{
                    background-color: #f4f4f4;
                    padding: 10px;
                    border-radius: 3px;
                    overflow-x: auto;
                }}
                table {{
                    border-collapse: collapse;
                    width: 100%;
                    margin: 20px 0;
                }}
                th, td {{
                    border: 1px solid #ddd;
                    padding: 8px;
                    text-align: left;
                }}
                th {{
                    background-color: #f2f2f2;
                }}
                img {{
                    max-width: 100%;
                    height: auto;
                }}
            </style>
        </head>
        <body>
            {html_content}
        </body>
        </html>
        '''
        
        return full_html.encode('utf-8')
    
    def get_supported_formats(self) -> tuple:
        """获取支持的格式"""
        return ('markdown', 'html')
