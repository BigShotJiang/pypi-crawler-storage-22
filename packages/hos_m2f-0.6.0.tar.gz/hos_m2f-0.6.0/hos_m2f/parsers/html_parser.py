"""HTML解析器"""

from typing import Dict, Any, Optional, Union
from bs4 import BeautifulSoup

from hos_m2f.model.universal_model import UniversalDocumentModel
from hos_m2f.parsers.base_parser import BaseParser


class HTMLParser(BaseParser):
    """HTML解析器"""
    
    def parse(self, content: Union[str, bytes], options: Optional[Dict[str, Any]] = None) -> UniversalDocumentModel:
        """解析HTML内容为中间模型
        
        Args:
            content: HTML内容
            options: 解析选项
            
        Returns:
            UniversalDocumentModel: 通用文档模型
        """
        options = options or {}
        
        # 确保content是字符串
        content = self._normalize_content(content)
        
        # 创建通用文档模型
        model = UniversalDocumentModel()
        
        # 1. 解析HTML
        soup = BeautifulSoup(content, 'html.parser')
        
        # 2. 提取元数据
        meta = self._extract_meta(soup)
        model.set_meta(meta)
        
        # 3. 提取HTML内容
        html_content = self._extract_html_content(soup)
        model.set_html_content(html_content)
        
        # 4. 分析文档结构
        structure = self._analyze_structure(soup)
        for item in structure:
            model.add_structure_item(item)
        
        # 5. 提取语义信息
        semantics = self._extract_semantics(soup)
        model.get_json()["semantics"].update(semantics)
        
        return model
    
    def _extract_meta(self, soup: BeautifulSoup) -> Dict[str, Any]:
        """提取元数据
        
        Args:
            soup: BeautifulSoup对象
            
        Returns:
            Dict[str, Any]: 元数据字典
        """
        meta = {}
        
        # 提取标题
        title_tag = soup.find('title')
        if title_tag:
            meta["title"] = title_tag.get_text().strip()
        
        # 提取meta标签中的信息
        meta_tags = soup.find_all('meta')
        for tag in meta_tags:
            if tag.get('name') == 'description':
                meta["description"] = tag.get('content', '').strip()
            elif tag.get('name') == 'author':
                meta["author"] = tag.get('content', '').strip()
            elif tag.get('name') == 'keywords':
                keywords = tag.get('content', '').strip()
                if keywords:
                    meta["tags"] = [k.strip() for k in keywords.split(',')]
        
        # 提取Open Graph标签
        og_tags = soup.find_all('meta', property=lambda x: x and x.startswith('og:'))
        for tag in og_tags:
            property_name = tag.get('property', '').replace('og:', '')
            if property_name == 'title' and 'title' not in meta:
                meta["title"] = tag.get('content', '').strip()
            elif property_name == 'description' and 'description' not in meta:
                meta["description"] = tag.get('content', '').strip()
            elif property_name == 'image':
                meta["cover_image"] = tag.get('content', '').strip()
        
        return meta
    
    def _extract_html_content(self, soup: BeautifulSoup) -> str:
        """提取HTML内容
        
        Args:
            soup: BeautifulSoup对象
            
        Returns:
            str: HTML内容
        """
        # 提取body内容
        body = soup.find('body')
        if body:
            return str(body)
        
        # 如果没有body标签，返回整个HTML
        return str(soup)
    
    def _analyze_structure(self, soup: BeautifulSoup) -> list:
        """分析文档结构
        
        Args:
            soup: BeautifulSoup对象
            
        Returns:
            list: 结构项列表
        """
        structure = []
        
        # 分析标题层级
        for level in range(1, 7):
            headings = soup.find_all(f'h{level}')
            for i, heading in enumerate(headings):
                structure.append({
                    "type": "heading",
                    "level": level,
                    "title": heading.get_text().strip(),
                    "id": heading.get('id', '')
                })
        
        # 分析表格
        tables = soup.find_all('table')
        for i, table in enumerate(tables):
            structure.append({
                "type": "table",
                "id": table.get('id', f"table-{i+1}")
            })
        
        # 分析图片
        images = soup.find_all('img')
        for i, img in enumerate(images):
            structure.append({
                "type": "image",
                "src": img.get('src', ''),
                "alt": img.get('alt', '')
            })
        
        # 分析列表
        lists = soup.find_all(['ul', 'ol'])
        for i, lst in enumerate(lists):
            list_type = "ordered" if lst.name == 'ol' else "unordered"
            structure.append({
                "type": "list",
                "list_type": list_type,
                "id": lst.get('id', f"list-{i+1}")
            })
        
        # 分析代码块
        code_blocks = soup.find_all('pre')
        for i, code_block in enumerate(code_blocks):
            structure.append({
                "type": "code_block",
                "id": code_block.get('id', f"code-{i+1}")
            })
        
        return structure
    
    def _extract_semantics(self, soup: BeautifulSoup) -> Dict[str, Any]:
        """提取语义信息
        
        Args:
            soup: BeautifulSoup对象
            
        Returns:
            Dict[str, Any]: 语义信息字典
        """
        semantics = {
            "domain_tag": "",
            "section_id": {},
            "table_type": {},
            "list_type": {}
        }
        
        # 提取章节ID
        section_counter = 1
        for level in range(1, 7):
            headings = soup.find_all(f'h{level}')
            for heading in headings:
                section_id = heading.get('id', f"sec-{section_counter}")
                semantics["section_id"][section_id] = {
                    "title": heading.get_text().strip(),
                    "level": level
                }
                section_counter += 1
        
        # 识别表格类型
        tables = soup.find_all('table')
        for i, table in enumerate(tables):
            table_id = table.get('id', f"table-{i+1}")
            # 简单的表格类型识别
            if 'class' in table.attrs and any('data' in cls.lower() for cls in table['class']):
                table_type = "data"
            else:
                table_type = "general"
            semantics["table_type"][table_id] = table_type
        
        # 识别列表类型
        lists = soup.find_all(['ul', 'ol'])
        for i, lst in enumerate(lists):
            list_id = lst.get('id', f"list-{i+1}")
            list_type = "ordered" if lst.name == 'ol' else "unordered"
            semantics["list_type"][list_id] = list_type
        
        return semantics
