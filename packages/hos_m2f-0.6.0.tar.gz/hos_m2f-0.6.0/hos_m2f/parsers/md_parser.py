"""Markdown解析器"""

import re
from typing import Dict, Any, Optional, Union
import mistune

from hos_m2f.model.universal_model import UniversalDocumentModel
from hos_m2f.parsers.base_parser import BaseParser


class MDParser(BaseParser):
    """Markdown解析器"""
    
    def parse(self, content: Union[str, bytes], options: Optional[Dict[str, Any]] = None) -> UniversalDocumentModel:
        """解析Markdown内容为中间模型
        
        Args:
            content: Markdown内容
            options: 解析选项
            
        Returns:
            UniversalDocumentModel: 通用文档模型
        """
        options = options or {}
        
        # 确保content是字符串
        if isinstance(content, bytes):
            content = content.decode('utf-8')
        
        # 创建通用文档模型
        model = UniversalDocumentModel()
        
        # 1. 提取YAML头信息
        meta = self._extract_yaml_front_matter(content)
        model.set_meta(meta)
        
        # 2. 移除YAML头信息，获取纯Markdown内容
        markdown_content = self._remove_yaml_front_matter(content)
        
        # 3. 解析Markdown为HTML
        html_content = self._markdown_to_html(markdown_content, options)
        model.set_html_content(html_content)
        
        # 4. 分析文档结构
        structure = self._analyze_structure(markdown_content)
        for item in structure:
            model.add_structure_item(item)
        
        # 5. 提取语义信息
        semantics = self._extract_semantics(markdown_content)
        model.get_json()["semantics"].update(semantics)
        
        return model
    
    def _extract_yaml_front_matter(self, content: str) -> Dict[str, Any]:
        """提取YAML头信息
        
        Args:
            content: Markdown内容
            
        Returns:
            Dict[str, Any]: 元数据字典
        """
        import yaml
        
        # 检查是否有YAML头信息
        yaml_pattern = re.compile(r'^---\s*$((?:.|\n)*?)^---\s*$', re.MULTILINE)
        match = yaml_pattern.match(content)
        
        if match:
            try:
                yaml_content = match.group(1)
                meta = yaml.safe_load(yaml_content)
                if isinstance(meta, dict):
                    return meta
            except Exception as e:
                print(f"Warning: Failed to parse YAML front matter: {e}")
        
        # 从内容中提取基本元数据
        return self._extract_basic_meta(content)
    
    def _extract_basic_meta(self, content: str) -> Dict[str, Any]:
        """提取基本元数据
        
        Args:
            content: Markdown内容
            
        Returns:
            Dict[str, Any]: 基本元数据
        """
        meta = {}
        
        # 提取标题
        title_pattern = re.compile(r'^#\s+(.*)$', re.MULTILINE)
        title_match = title_pattern.search(content)
        if title_match:
            meta["title"] = title_match.group(1).strip()
        
        # 提取标签
        tags_pattern = re.compile(r'^tags:\s*\[(.*?)\]$', re.MULTILINE)
        tags_match = tags_pattern.search(content)
        if tags_match:
            tags = [tag.strip() for tag in tags_match.group(1).split(',')]
            meta["tags"] = tags
        
        return meta
    
    def _remove_yaml_front_matter(self, content: str) -> str:
        """移除YAML头信息
        
        Args:
            content: Markdown内容
            
        Returns:
            str: 纯Markdown内容
        """
        yaml_pattern = re.compile(r'^---\s*$((?:.|\n)*?)^---\s*$', re.MULTILINE)
        return yaml_pattern.sub('', content).strip()
    
    def _markdown_to_html(self, markdown_content: str, options: Dict[str, Any]) -> str:
        """将Markdown转换为HTML
        
        Args:
            markdown_content: Markdown内容
            options: 转换选项
            
        Returns:
            str: HTML内容
        """
        # 创建Markdown渲染器
        markdown = mistune.create_markdown(
            plugins=[
                'url',
                'task_lists',
                'table',
                'strikethrough',
                'footnotes'
            ]
        )
        
        # 转换为HTML
        html = markdown(markdown_content)
        
        return html
    
    def _analyze_structure(self, markdown_content: str) -> list:
        """分析文档结构
        
        Args:
            markdown_content: Markdown内容
            
        Returns:
            list: 结构项列表
        """
        structure = []
        
        # 分析标题层级
        lines = markdown_content.split('\n')
        for i, line in enumerate(lines):
            # 匹配标题
            heading_match = re.match(r'^(#{1,6})\s+(.*)$', line)
            if heading_match:
                level = len(heading_match.group(1))
                title = heading_match.group(2).strip()
                structure.append({
                    "type": "heading",
                    "level": level,
                    "title": title,
                    "position": i
                })
            
            # 匹配表格
            elif re.match(r'^\|.*\|$', line) and i > 0 and re.match(r'^\|.*\|$', lines[i-1]):
                if not any(item.get('type') == 'table' and item.get('position') == i-1 for item in structure):
                    structure.append({
                        "type": "table",
                        "position": i-1
                    })
            
            # 匹配代码块
            elif re.match(r'^```', line):
                structure.append({
                    "type": "code_block",
                    "position": i
                })
            
            # 匹配图片
            elif re.match(r'^!\[.*\]\(.*\)$', line):
                structure.append({
                    "type": "image",
                    "position": i
                })
            
            # 匹配列表
            elif re.match(r'^(\*|\-|\+|\d+\.)\s+', line):
                list_type = "ordered" if re.match(r'^\d+\.', line) else "unordered"
                if not any(item.get('type') == 'list' and item.get('position') == i for item in structure):
                    structure.append({
                        "type": "list",
                        "list_type": list_type,
                        "position": i
                    })
        
        return structure
    
    def _extract_semantics(self, markdown_content: str) -> Dict[str, Any]:
        """提取语义信息
        
        Args:
            markdown_content: Markdown内容
            
        Returns:
            Dict[str, Any]: 语义信息字典
        """
        semantics = {
            "domain_tag": "",
            "section_id": {},
            "table_type": {},
            "list_type": {}
        }
        
        # 提取章节ID
        lines = markdown_content.split('\n')
        section_counter = 1
        for i, line in enumerate(lines):
            heading_match = re.match(r'^(#{1,6})\s+(.*)$', line)
            if heading_match:
                level = len(heading_match.group(1))
                title = heading_match.group(2).strip()
                section_id = f"sec-{section_counter}"
                semantics["section_id"][section_id] = {
                    "title": title,
                    "level": level,
                    "position": i
                }
                section_counter += 1
        
        # 识别列表类型
        list_position = 0
        for i, line in enumerate(lines):
            if re.match(r'^\d+\.', line):
                semantics["list_type"][f"list-{list_position}"] = "ordered"
                list_position += 1
            elif re.match(r'^(\*|\-|\+)\s+', line):
                semantics["list_type"][f"list-{list_position}"] = "unordered"
                list_position += 1
        
        return semantics
