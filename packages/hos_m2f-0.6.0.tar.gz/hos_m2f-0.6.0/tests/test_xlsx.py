"""测试Excel相关功能模块"""

import unittest
import os
import tempfile
import io
import openpyxl
from hos_m2f.parsers.xlsx_parser import XLSXParser
from hos_m2f.renderers.xlsx_renderer import XLSXRenderer
from hos_m2f.engine.engine import Engine


class TestXLSX(unittest.TestCase):
    """测试Excel相关功能"""
    
    def setUp(self):
        """设置测试环境"""
        # 创建测试用的Excel文件
        self.test_xlsx_content = self._create_test_xlsx()
        
        # 创建测试用的Markdown内容
        self.test_md_content = """
# 测试文档

这是一个测试文档，用于测试Excel格式转换。

## 表格测试

| 姓名 | 年龄 | 职业 |
| --- | --- | --- |
| 张三 | 25 | 工程师 |
| 李四 | 30 | 设计师 |
| 王五 | 35 | 产品经理 |
        "".strip()
    
    def _create_test_xlsx(self) -> bytes:
        """创建测试用的Excel文件
        
        Returns:
            bytes: Excel文件内容
        """
        # 创建Excel工作簿
        workbook = openpyxl.Workbook()
        
        # 创建第一个工作表
        sheet1 = workbook.active
        sheet1.title = "Sheet1"
        
        # 填充数据
        sheet1["A1"] = "姓名"
        sheet1["B1"] = "年龄"
        sheet1["C1"] = "职业"
        sheet1["A2"] = "张三"
        sheet1["B2"] = 25
        sheet1["C2"] = "工程师"
        sheet1["A3"] = "李四"
        sheet1["B3"] = 30
        sheet1["C3"] = "设计师"
        sheet1["A4"] = "王五"
        sheet1["B4"] = 35
        sheet1["C4"] = "产品经理"
        
        # 创建第二个工作表
        sheet2 = workbook.create_sheet(title="Sheet2")
        sheet2["A1"] = "产品"
        sheet2["B1"] = "价格"
        sheet2["C1"] = "库存"
        sheet2["A2"] = "产品1"
        sheet2["B2"] = 100
        sheet2["C2"] = 10
        sheet2["A3"] = "产品2"
        sheet2["B3"] = 200
        sheet2["C3"] = 20
        
        # 保存到内存
        output = io.BytesIO()
        workbook.save(output)
        output.seek(0)
        
        return output.getvalue()
    
    def test_xlsx_parser(self):
        """测试XLSX解析器"""
        parser = XLSXParser()
        result = parser.parse(self.test_xlsx_content)
        
        # 验证解析结果
        self.assertIsNotNone(result)
        self.assertIsInstance(result.get_html(), str)
        self.assertGreater(len(result.get_html()), 0)
        
        # 验证JSON结构
        json_data = result.get_json()
        self.assertIsInstance(json_data, dict)
        self.assertIn("meta", json_data)
        self.assertIn("structure", json_data)
        self.assertIn("semantics", json_data)
        
        # 验证元数据
        meta = json_data["meta"]
        self.assertIn("title", meta)
        self.assertIn("sheet_count", meta)
        self.assertEqual(meta["sheet_count"], 2)
        
        # 验证结构
        structure = json_data["structure"]
        self.assertGreater(len(structure), 0)
        
        # 验证语义信息
        semantics = json_data["semantics"]
        self.assertIn("domain_tag", semantics)
        self.assertEqual(semantics["domain_tag"], "spreadsheet")
        self.assertIn("sheet_info", semantics)
    
    def test_xlsx_renderer(self):
        """测试XLSX渲染器"""
        # 首先使用XLSX解析器解析Excel文件
        parser = XLSXParser()
        model = parser.parse(self.test_xlsx_content)
        
        # 创建渲染数据
        render_data = {
            "json": model.get_json(),
            "html": model.get_html()
        }
        
        # 使用XLSX渲染器渲染
        renderer = XLSXRenderer()
        result = renderer.render(render_data)
        
        # 验证渲染结果
        self.assertIsInstance(result, bytes)
        self.assertGreater(len(result), 0)
        
        # 保存为临时文件，以便手动检查
        with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as tmp:
            tmp.write(result)
            tmp_path = tmp.name
        
        try:
            # 验证文件存在且大小大于0
            self.assertTrue(os.path.exists(tmp_path))
            self.assertGreater(os.path.getsize(tmp_path), 0)
            
            # 尝试打开生成的Excel文件，验证其有效性
            workbook = openpyxl.load_workbook(tmp_path)
            self.assertIsInstance(workbook, openpyxl.Workbook)
            self.assertGreater(len(workbook.sheetnames), 0)
        finally:
            # 清理临时文件
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)
    
    def test_engine_xlsx_conversion(self):
        """测试引擎的Excel转换功能"""
        engine = Engine()
        
        # 测试Excel到HTML转换
        html_result = engine.convert_content('xlsx', 'html', self.test_xlsx_content)
        self.assertIsInstance(html_result, bytes)
        self.assertGreater(len(html_result), 0)
        
        # 测试Excel到JSON转换
        json_result = engine.convert_content('xlsx', 'json', self.test_xlsx_content)
        self.assertIsInstance(json_result, bytes)
        self.assertGreater(len(json_result), 0)
        
        # 测试Markdown到Excel转换
        xlsx_result = engine.convert_content('md', 'xlsx', self.test_md_content)
        self.assertIsInstance(xlsx_result, bytes)
        self.assertGreater(len(xlsx_result), 0)
        
        # 保存为临时文件，以便手动检查
        with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as tmp:
            tmp.write(xlsx_result)
            tmp_path = tmp.name
        
        try:
            # 验证文件存在且大小大于0
            self.assertTrue(os.path.exists(tmp_path))
            self.assertGreater(os.path.getsize(tmp_path), 0)
            
            # 尝试打开生成的Excel文件，验证其有效性
            workbook = openpyxl.load_workbook(tmp_path)
            self.assertIsInstance(workbook, openpyxl.Workbook)
        finally:
            # 清理临时文件
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)


if __name__ == '__main__':
    unittest.main()
