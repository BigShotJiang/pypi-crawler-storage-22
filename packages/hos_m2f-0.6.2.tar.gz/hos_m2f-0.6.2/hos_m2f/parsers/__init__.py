"""解析器包"""

from hos_m2f.parsers.md_parser import MDParser
from hos_m2f.parsers.html_parser import HTMLParser
from hos_m2f.parsers.json_parser import JSONParser
from hos_m2f.parsers.docx_parser import DOCXParser
from hos_m2f.parsers.epub_parser import EPUBParser
from hos_m2f.parsers.xml_parser import XMLParser
from hos_m2f.parsers.xlsx_parser import XLSXParser

__all__ = [
    "MDParser",
    "HTMLParser",
    "JSONParser",
    "DOCXParser",
    "EPUBParser",
    "XMLParser",
    "XLSXParser"
]
