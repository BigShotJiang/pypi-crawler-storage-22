"""CLI for hpc-runner."""
