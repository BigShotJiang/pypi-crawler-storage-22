import subprocess
from pathlib import Path

from ase.calculators.calculator import CalculationFailed
from lasp_ase.lasp import Lasp as ase_Lasp

from hpc_task.hpc import HPCTask


class Lasp(ase_Lasp):

    def __init__(self,
                 restart=None,
                 label='lasp',
                 atoms=None,
                 hpctask: HPCTask = None,
                 **kwargs):
        super().__init__(
            atoms=atoms,
            restart=restart,
            label=label,
            **kwargs)
        self.hpctask = hpctask


    def execute(self):
        if self.hpctask is not None:
            remote_cmd =  f"gosh-remote -vv client run '{self.command}'"
            returncode, stderr, stdout = self.hpctask.execute(remote_cmd)
            if returncode:
                raise CalculationFailed(
                    '{} in {} returned an error: {:d} stderr {}'.format(
                        self.name, Path(self.directory).resolve(), returncode,
                        stderr))
        else:
            self.profile.execute(self)