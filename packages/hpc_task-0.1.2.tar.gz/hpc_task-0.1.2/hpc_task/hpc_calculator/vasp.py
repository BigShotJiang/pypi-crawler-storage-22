import subprocess

from ase.calculators.vasp import Vasp as ase_Vasp
from hpc_task.hpc import HPCTask


class Vasp(ase_Vasp):
    def __init__(self,
                 atoms=None,
                 restart=None,
                 directory='.',
                 label='vasp',
                 command=None,
                 hpctask:HPCTask=None,
                 **kwargs):
        super().__init__(
            atoms=atoms,
            restart=restart,
            directory=directory,
            label=label,
            command=command,
            **kwargs
        )
        self.hpctask = hpctask

    def _run(self, command=None, out=None, directory=None):
        """Method to explicitly execute VASP"""
        if command is None:
            command = self.command

        if self.hpctask is not None:
            remote_cmd = f"gosh-remote -vv client run '{command}'"
            returncode, stderr, stdout = self.hpctask.execute(remote_cmd)

        else:
            result = subprocess.run(command,
                                    shell=True,
                                    cwd=directory,
                                    capture_output=True,
                                    text=True)
            stdout = result.stdout
            returncode = result.returncode
            stderr = result.stderr
        if out is not None:
            out.write(stdout)
        return returncode, stderr
