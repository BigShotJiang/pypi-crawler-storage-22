
QSUB = {
    'pbs': 'qsub',
    'slurm': 'sbatch',
    'lsf': 'bsub <',
}

QDEL = {
    'pbs': 'qdel',
    'slurm': 'scancel',
    'lsf': 'bkill',
}

QSTAT = {
    'pbs': 'qstat -f',
    'slurm': 'squeue --noheader -o %T --states=all -j',
    'lsf': 'bjobs -noheader',
}

NCPU = {  # get number of cpu
    'pbs': None,
    'slurm' : 'scontrol show partition',  #  | grep -E "(TotalCPUs=[0-9]+)" | awk -F"TotalCPUs=" '{print $2}' | awk '{print $1}'
    'lsf': '',
}

CWD = {  # get remote work dir
    'pbs': "qstat -f {job_id} | grep -oP 'PBS_O_WORKDIR = \K.*'",
    'slurm' : "scontrol show job {jobid} | grep -oP 'WorkDir=\K[^\s]*'",
    'lsf': "bjobs -l {job_id} | grep -oP 'CWD:\s*\K.*'",
}