import os
import subprocess
from pathlib import Path

from ase.calculators import calculator
from ase.calculators.vasp import Vasp as ase_Vasp
import ase.io
from hpc_task.hpc import HPCTask


class Vasp(ase_Vasp):
    def __init__(self,
                 atoms=None,
                 restart=None,
                 directory='.',
                 label='vasp',
                 command=None,
                 hpctask:HPCTask=None,
                 **kwargs):
        super().__init__(
            atoms=atoms,
            restart=restart,
            directory=directory,
            label=label,
            command=command,
            **kwargs
        )
        self.hpctask = hpctask

    def _run(self, command=None, out=None, directory=None):
        """Method to explicitly execute VASP"""
        if command is None:
            command = self.command

        if self.hpctask is not None:
            remote_cmd = f"gosh-remote -vv client run '{command}'"
            returncode, stderr, stdout = self.hpctask.execute(remote_cmd)

        else:
            result = subprocess.run(command,
                                    shell=True,
                                    cwd=directory,
                                    capture_output=True,
                                    text=True)
            stdout = result.stdout
            returncode = result.returncode
            stderr = result.stderr
        if out is not None:
            out.write(stdout)
        return returncode, stderr

    def execute_only(self):
        """
        仅仅执行 command 命令，从文件夹中读取 INCAR、POTCAR、POSCAR、KPOINTS
        """
        self.read_potcar(filename=self._indir('POTCAR'))
        self.read_incar(filename=self._indir('INCAR'))
        self.read_kpoints(filename=self._indir('KPOINTS'))
        atoms = ase.io.read(filename=self._indir('POSCAR'))
        # 需要读进去ase-sort.dat，否则结果会报错
        sortfile = self._indir('ase-sort.dat')
        if os.path.isfile(sortfile):
            self.sort = []
            self.resort = []
            with open(sortfile) as fd:
                for line in fd:
                    sort, resort = line.split()
                    self.sort.append(int(sort))
                    self.resort.append(int(resort))
        else:
            # Redo the sorting
            self.initialize(atoms)

        command = self.make_command(self.command)
        with self._txt_outstream() as out:
            errorcode, stderr = self._run(command=command,
                                          out=out,
                                          directory=self.directory)

        if errorcode:
            raise calculator.CalculationFailed(
                '{} in {} returned an error: {:d} stderr {}'.format(
                    self.name, Path(self.directory).resolve(), errorcode,
                    stderr))

        # Read results from calculation
        self.update_atoms(atoms)
        self.read_results()