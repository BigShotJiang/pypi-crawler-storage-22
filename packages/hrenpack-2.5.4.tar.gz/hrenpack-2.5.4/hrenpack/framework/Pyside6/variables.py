from hrenpack.classes import DataClass

file_dialog_templates = DataClass(images="Изображения (*.jpg *.jpeg *.png *.tif *.tiff)", all="Все файлы (*)",
                                  txt="Текстовый документ (*.txt)", srt="Субтитры SRT (*.srt)")