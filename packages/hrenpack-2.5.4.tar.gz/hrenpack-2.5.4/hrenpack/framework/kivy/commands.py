def toggle_down(instance, *args):
    instance.state = 'down'
