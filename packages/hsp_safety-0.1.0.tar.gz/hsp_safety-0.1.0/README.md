# HSP Safety Logger

**The Global Standard for AI Compliance & Safety Monitoring.**

Protect your LLM applications from regulatory fines (EU AI Act, GDPR, US Executive Order) with a single line of code.

## Installation

```bash
pip install hsp-safety
```

## Quick Start

Just decorate your LLM function to automatically log safety audits:

```python
from hsp_safety import monitor

@monitor
def generate_text(prompt):
    # Your LLM call here (OpenAI, Anthropic, Llama)
    return llm.predict(prompt)
```

## Features

- **Automatic Risk Scoring:** Detects if your AI is generating hazardous content.
- **Audit Trail:** Creates a cryptographic proof of your safety checks.
- **Free Tier:** Up to 10,000 requests/day for research and testing.

## Enterprise

For high-volume production use, please upgrade to the Enterprise License at [hsp-protocol.com](https://hsp-protocol.com).
