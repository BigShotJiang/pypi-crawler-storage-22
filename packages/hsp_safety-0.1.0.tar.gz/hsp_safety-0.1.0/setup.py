from setuptools import setup, find_packages

setup(
    name="hsp-safety",
    version="0.1.0",
    author="HSP Protocol Foundation",
    author_email="security@hsp-protocol.com",
    description="Standard AI Safety Logger & Compliance Check for LLMs.",
    long_description="HSP Safety Logger\n=================\n\nProtect your AI from hallucinations and ensure EU AI Act compliance.\n\nUsage:\n\n    from hsp_safety import monitor\n\n    @monitor\n    def my_ai_function():\n        ...",
    long_description_content_type="text/markdown",
    url="https://hsp-protocol.com",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    install_requires=[
        "requests",
    ],
)
