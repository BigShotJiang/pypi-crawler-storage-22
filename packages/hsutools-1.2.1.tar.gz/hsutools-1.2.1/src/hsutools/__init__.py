"""hsutools package."""

__all__ = ["__version__"]
__version__ = "1.2.1"
