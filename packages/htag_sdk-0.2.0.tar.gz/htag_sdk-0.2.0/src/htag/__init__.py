"""HtAG AI Python SDK.

The official Python client for the HtAG AI API, providing access to
Australian address data, property sales records, and market analytics.

Quick start::

    from htag import HtAgApi

    client = HtAgApi(api_key="sk-...", environment="prod")
    results = client.address.search("100 George St Sydney")

For async usage::

    from htag import AsyncHtAgApi

    async_client = AsyncHtAgApi(api_key="sk-...", environment="prod")
    results = await async_client.address.search("100 George St Sydney")
"""

from htag._async_client import AsyncHtAgApi
from htag._client import HtAgApi
from htag._exceptions import (
    AuthenticationError,
    ConnectionError,
    HtAgError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)

# Domain models -- address
from htag.address.models import (
    AddressInsightsResponse,
    AddressRecord,
    AddressSearchResponse,
    AddressSearchResult,
    AustralianAddressComponents,
    BatchStandardiseResponse,
    StandardiseResult,
)

# Domain models -- property
from htag.property.models import (
    SoldPropertiesResponse,
    SoldPropertyRecord,
)

# Domain models -- intent hub
from htag.intent_hub.models import (
    ClassifiedEvent,
    EventCategory,
    EventType,
    Integration,
    IntegrationStatus,
    IntegrationType,
    PaginatedEvents,
    Sentiment,
    SourceType,
    Subscription,
    TagInfo,
    Urgency,
)

# Domain models -- markets
from htag.markets.models import (
    AdvancedSearchBody,
    BaseResponse,
    DemandProfileOut,
    EssentialsOut,
    FSDMonthlyOut,
    FSDQuarterlyOut,
    FSDYearlyOut,
    GRCOut,
    LevelEnum,
    MarketSnapshot,
    PriceHistoryOut,
    PropertyTypeEnum,
    RentHistoryOut,
    YieldHistoryOut,
)

__version__ = "0.1.1"

__all__ = [
    # Clients
    "HtAgApi",
    "AsyncHtAgApi",
    # Exceptions
    "HtAgError",
    "AuthenticationError",
    "ConnectionError",
    "NotFoundError",
    "RateLimitError",
    "ServerError",
    "ValidationError",
    # Address models
    "AddressInsightsResponse",
    "AddressRecord",
    "AddressSearchResponse",
    "AddressSearchResult",
    "AustralianAddressComponents",
    "BatchStandardiseResponse",
    "StandardiseResult",
    # Property models
    "SoldPropertiesResponse",
    "SoldPropertyRecord",
    # Intent Hub models
    "ClassifiedEvent",
    "EventCategory",
    "EventType",
    "Integration",
    "IntegrationStatus",
    "IntegrationType",
    "PaginatedEvents",
    "Sentiment",
    "SourceType",
    "Subscription",
    "TagInfo",
    "Urgency",
    # Markets models
    "AdvancedSearchBody",
    "BaseResponse",
    "DemandProfileOut",
    "EssentialsOut",
    "FSDMonthlyOut",
    "FSDQuarterlyOut",
    "FSDYearlyOut",
    "GRCOut",
    "LevelEnum",
    "MarketSnapshot",
    "PriceHistoryOut",
    "PropertyTypeEnum",
    "RentHistoryOut",
    "YieldHistoryOut",
]
