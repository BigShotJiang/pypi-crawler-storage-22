"""Address API domain — search, insights, and standardisation."""

from htag.address.async_client import AsyncAddressClient
from htag.address.client import AddressClient
from htag.address.models import (
    AddressInsightsResponse,
    AddressRecord,
    AddressSearchResponse,
    AddressSearchResult,
    AustralianAddressComponents,
    BatchStandardiseResponse,
    StandardiseResult,
)

__all__ = [
    "AddressClient",
    "AsyncAddressClient",
    "AddressInsightsResponse",
    "AddressRecord",
    "AddressSearchResponse",
    "AddressSearchResult",
    "AustralianAddressComponents",
    "BatchStandardiseResponse",
    "StandardiseResult",
]
