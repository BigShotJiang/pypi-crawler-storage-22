"""Pydantic models for the Intent Hub API domain."""

from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

# ---------------------------------------------------------------------------
# Literal type aliases (SDK is standalone -- no enum.Enum)
# ---------------------------------------------------------------------------

SourceType = Literal["AGENT", "PLATFORM", "PARTNER", "INTERNAL"]
IntegrationType = Literal["WEBHOOK", "SQS", "SNS"]
IntegrationStatus = Literal["ACTIVE", "DEGRADED", "DISABLED"]
Sentiment = Literal["POSITIVE", "NEUTRAL", "NEGATIVE", "MIXED"]
Urgency = Literal["IMMEDIATE", "STANDARD", "BATCHED"]

# ---------------------------------------------------------------------------
# Event models
# ---------------------------------------------------------------------------


class ClassifiedEvent(BaseModel):
    """A classified event returned by the Intent Hub."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    raw_event_id: Optional[str] = None
    status: Optional[str] = None
    event_type: Optional[str] = None
    category: Optional[str] = None
    primary_intent: Optional[str] = None
    sub_intents: Optional[List[str]] = None
    confidence: Optional[float] = None
    sentiment: Optional[str] = None
    entities: Optional[Dict[str, Any]] = None
    tags: Optional[List[str]] = None
    urgency: Optional[str] = None
    classifier_model: Optional[str] = None
    classifier_version: Optional[str] = None
    classified_at: Optional[str] = None
    occurred_at: Optional[str] = None


class PaginatedEvents(BaseModel):
    """Paginated list of classified events."""

    model_config = ConfigDict(populate_by_name=True)

    events: List[ClassifiedEvent] = []
    total: int = 0
    cursor: Optional[str] = None


# ---------------------------------------------------------------------------
# Integration models
# ---------------------------------------------------------------------------


class Integration(BaseModel):
    """An integration endpoint (webhook, SQS, or SNS)."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    org_id: Optional[str] = Field(None, alias="orgId")
    type: str
    name: str
    url: Optional[str] = None
    status: Optional[str] = None
    consecutive_failures: Optional[int] = Field(None, alias="consecutiveFailures")
    last_success_at: Optional[str] = Field(None, alias="lastSuccessAt")
    last_failure_at: Optional[str] = Field(None, alias="lastFailureAt")
    created_at: Optional[str] = Field(None, alias="createdAt")


# ---------------------------------------------------------------------------
# Subscription models
# ---------------------------------------------------------------------------


class Subscription(BaseModel):
    """A subscription linking event patterns to an integration."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    org_id: Optional[str] = Field(None, alias="orgId")
    integration_id: Optional[str] = Field(None, alias="integrationId")
    event_type_slug: Optional[str] = Field(None, alias="eventTypeSlug")
    tag: Optional[str] = None
    intent_pattern: Optional[str] = Field(None, alias="intentPattern")
    is_active: Optional[bool] = Field(None, alias="isActive")
    created_at: Optional[str] = Field(None, alias="createdAt")


# ---------------------------------------------------------------------------
# Catalog models
# ---------------------------------------------------------------------------


class EventCategory(BaseModel):
    """An event category in the taxonomy."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    slug: str
    name: str
    description: Optional[str] = None
    sort_order: Optional[int] = Field(None, alias="sortOrder")


class EventType(BaseModel):
    """An event type in the taxonomy."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    slug: str
    name: str
    category_id: Optional[str] = Field(None, alias="categoryId")
    classification_hint: Optional[str] = Field(None, alias="classificationHint")
    default_urgency: Optional[str] = Field(None, alias="defaultUrgency")
    visibility: Optional[str] = None


class TagInfo(BaseModel):
    """A tag with its usage count."""

    model_config = ConfigDict(populate_by_name=True)

    tag: str
    count: int
