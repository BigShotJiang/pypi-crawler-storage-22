"""Property API domain — sold property search and data."""

from htag.property.async_client import AsyncPropertyClient
from htag.property.client import PropertyClient
from htag.property.models import (
    SoldPropertiesResponse,
    SoldPropertyRecord,
)

__all__ = [
    "AsyncPropertyClient",
    "PropertyClient",
    "SoldPropertiesResponse",
    "SoldPropertyRecord",
]
