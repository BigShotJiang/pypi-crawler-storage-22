"""
HTB CLI - Command Line Interface for Hack The Box Labs.

A clean, modular Python CLI for the HTB API.
"""

__version__ = "1.0.0"
