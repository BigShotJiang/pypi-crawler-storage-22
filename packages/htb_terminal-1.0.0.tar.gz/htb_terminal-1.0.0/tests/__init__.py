"""HTB CLI tests."""
