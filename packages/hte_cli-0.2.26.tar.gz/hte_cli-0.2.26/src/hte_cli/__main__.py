"""Allow running as python -m hte_cli."""

from hte_cli import main

if __name__ == "__main__":
    main()
