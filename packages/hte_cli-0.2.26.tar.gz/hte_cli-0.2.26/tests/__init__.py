# Tests for hte-cli
