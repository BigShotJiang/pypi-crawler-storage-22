# Unit tests for hte-cli
