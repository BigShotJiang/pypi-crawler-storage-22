"""Tests for multi-session terminal log collection.

Verifies that when multiple container sessions write recordings to the same
volume-mounted directory, all recordings are collected by _read_session_logs()
and properly stored in HumanAgentState.logs.

This is the critical data preservation test: if an expert works across 3
containers (due to disconnections/restarts), the eval file must contain
terminal logs from ALL containers, not just the last one.
"""

from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


# Simulated recording files from three container sessions.
# The script command creates timestamped files per container.
CONTAINER_1_FILES = {
    "root_20260211_093010.input": "ls\ncat /etc/passwd\nid\n",
    "root_20260211_093010.output": "uid=0(root) gid=0(root)\n",
    "root_20260211_093010.timing": "O 0.5 100\nI 1.0 3\nO 0.1 50\n",
}

CONTAINER_2_FILES = {
    "root_20260211_132710.input": "python3 solve.py\ncat flag.txt\n",
    "root_20260211_132710.output": "Running solver...\nflag{test}\n",
    "root_20260211_132710.timing": "O 0.3 200\nI 2.0 15\nO 0.5 30\n",
}

CONTAINER_3_FILES = {
    "root_20260211_153010.input": "task score 'flag{test}'\ntask submit 'flag{test}'\ny\n",
    "root_20260211_153010.output": "Score: C\nSubmitting...\n",
    "root_20260211_153010.timing": "O 0.7 3557\nI 2.0 1\n",
}

ALL_FILES = {**CONTAINER_1_FILES, **CONTAINER_2_FILES, **CONTAINER_3_FILES}


class TestMultiSessionLogCollection:
    """Tests that _read_session_logs collects recordings from multiple containers."""

    @pytest.mark.asyncio
    async def test_collects_all_files_from_multiple_sessions(self):
        """All recording files from 3 container sessions are read."""
        from inspect_ai.agent._human.commands.submit import SessionEndCommand

        cmd = SessionEndCommand(record_session=True)

        # Mock sandbox to return all files
        mock_sandbox = MagicMock()
        mock_exec_result = MagicMock()
        mock_exec_result.success = True
        mock_exec_result.stdout = "\n".join(sorted(ALL_FILES.keys()))
        mock_sandbox.exec = AsyncMock(return_value=mock_exec_result)
        mock_sandbox.read_file = AsyncMock(side_effect=lambda path: ALL_FILES[Path(path).name])

        with patch("inspect_ai.agent._human.commands.submit.sandbox", return_value=mock_sandbox):
            logs = await cmd._read_session_logs()

        # All 9 files should be collected (3 files x 3 containers)
        assert len(logs) == 9
        for filename in ALL_FILES:
            assert filename in logs, f"Missing recording: {filename}"
            assert logs[filename] == ALL_FILES[filename]

    @pytest.mark.asyncio
    async def test_files_keyed_by_filename_preserving_timestamps(self):
        """Dict keys are filenames with timestamps, allowing container identification."""
        from inspect_ai.agent._human.commands.submit import SessionEndCommand

        cmd = SessionEndCommand(record_session=True)

        mock_sandbox = MagicMock()
        mock_exec_result = MagicMock()
        mock_exec_result.success = True
        mock_exec_result.stdout = "\n".join(sorted(ALL_FILES.keys()))
        mock_sandbox.exec = AsyncMock(return_value=mock_exec_result)
        mock_sandbox.read_file = AsyncMock(side_effect=lambda path: ALL_FILES[Path(path).name])

        with patch("inspect_ai.agent._human.commands.submit.sandbox", return_value=mock_sandbox):
            logs = await cmd._read_session_logs()

        # Can identify which container each recording came from by timestamp
        container_timestamps = set()
        for filename in logs:
            # Extract timestamp: root_YYYYMMDD_HHMMSS.type -> YYYYMMDD_HHMMSS
            parts = filename.rsplit(".", 1)[0]  # strip extension
            timestamp = parts.split("_", 1)[1]  # strip username prefix
            container_timestamps.add(timestamp)

        assert len(container_timestamps) == 3, (
            f"Expected 3 distinct container timestamps, got {container_timestamps}"
        )

    @pytest.mark.asyncio
    async def test_input_logs_contain_commands_from_all_sessions(self):
        """The .input files collectively contain commands from every container."""
        from inspect_ai.agent._human.commands.submit import SessionEndCommand

        cmd = SessionEndCommand(record_session=True)

        mock_sandbox = MagicMock()
        mock_exec_result = MagicMock()
        mock_exec_result.success = True
        mock_exec_result.stdout = "\n".join(sorted(ALL_FILES.keys()))
        mock_sandbox.exec = AsyncMock(return_value=mock_exec_result)
        mock_sandbox.read_file = AsyncMock(side_effect=lambda path: ALL_FILES[Path(path).name])

        with patch("inspect_ai.agent._human.commands.submit.sandbox", return_value=mock_sandbox):
            logs = await cmd._read_session_logs()

        # Collect all input logs
        all_input = "\n".join(
            content for name, content in sorted(logs.items()) if name.endswith(".input")
        )

        # Commands from container 1 (exploration)
        assert "cat /etc/passwd" in all_input
        # Commands from container 2 (solve work)
        assert "python3 solve.py" in all_input
        # Commands from container 3 (submission)
        assert "task submit" in all_input

    @pytest.mark.asyncio
    async def test_handles_single_session_gracefully(self):
        """Works fine with just one session (the common case)."""
        from inspect_ai.agent._human.commands.submit import SessionEndCommand

        cmd = SessionEndCommand(record_session=True)

        mock_sandbox = MagicMock()
        mock_exec_result = MagicMock()
        mock_exec_result.success = True
        mock_exec_result.stdout = "\n".join(sorted(CONTAINER_3_FILES.keys()))
        mock_sandbox.exec = AsyncMock(return_value=mock_exec_result)
        mock_sandbox.read_file = AsyncMock(
            side_effect=lambda path: CONTAINER_3_FILES[Path(path).name]
        )

        with patch("inspect_ai.agent._human.commands.submit.sandbox", return_value=mock_sandbox):
            logs = await cmd._read_session_logs()

        assert len(logs) == 3

    @pytest.mark.asyncio
    async def test_handles_empty_directory(self):
        """Returns empty dict when no recordings exist."""
        from inspect_ai.agent._human.commands.submit import SessionEndCommand

        cmd = SessionEndCommand(record_session=True)

        mock_sandbox = MagicMock()
        mock_exec_result = MagicMock()
        mock_exec_result.success = True
        mock_exec_result.stdout = ""
        mock_sandbox.exec = AsyncMock(return_value=mock_exec_result)

        with patch("inspect_ai.agent._human.commands.submit.sandbox", return_value=mock_sandbox):
            logs = await cmd._read_session_logs()

        assert logs == {}

    @pytest.mark.asyncio
    async def test_survives_partial_read_failure(self):
        """If one file fails to read, the others are still collected."""
        from inspect_ai.agent._human.commands.submit import SessionEndCommand

        cmd = SessionEndCommand(record_session=True)

        files = {
            "root_20260211_093010.input": "ls\n",
            "root_20260211_093010.output": "output\n",
            "root_20260211_093010.timing": "timing\n",
        }

        async def flaky_read(path):
            name = Path(path).name
            if name.endswith(".timing"):
                raise OSError("Permission denied")
            return files[name]

        mock_sandbox = MagicMock()
        mock_exec_result = MagicMock()
        mock_exec_result.success = True
        mock_exec_result.stdout = "\n".join(sorted(files.keys()))
        mock_sandbox.exec = AsyncMock(return_value=mock_exec_result)
        mock_sandbox.read_file = AsyncMock(side_effect=flaky_read)

        with patch("inspect_ai.agent._human.commands.submit.sandbox", return_value=mock_sandbox):
            logs = await cmd._read_session_logs()

        # Should have 2 out of 3 files (timing read failed)
        assert len(logs) == 2
        assert "root_20260211_093010.input" in logs
        assert "root_20260211_093010.output" in logs


class TestVolumePreservesAcrossContainers:
    """Tests that the volume mount setup ensures recordings survive restarts.

    These tests verify the on-disk behavior - that the persistent directory
    is correctly set up and would survive container lifecycle events.
    """

    def test_recordings_dir_is_deterministic_for_session(self):
        """Same session_id always maps to the same host directory."""
        from hte_cli.config import get_session_recordings_dir

        dir1 = get_session_recordings_dir("session-abc-123")
        dir2 = get_session_recordings_dir("session-abc-123")
        assert dir1 == dir2

    def test_different_sessions_get_different_dirs(self):
        """Different session IDs map to different directories."""
        from hte_cli.config import get_session_recordings_dir

        dir1 = get_session_recordings_dir("session-1")
        dir2 = get_session_recordings_dir("session-2")
        assert dir1 != dir2

    @patch("hte_cli.config.get_data_dir")
    def test_simulated_multi_container_lifecycle(self, mock_data_dir, tmp_path):
        """Simulates the full lifecycle: container 1 writes, dies, container 2 reads all."""
        from hte_cli.config import get_session_recordings_dir
        from hte_cli.runner import TaskRunner

        mock_data_dir.return_value = tmp_path / "data"
        session_id = "test-lifecycle-session"
        recordings_dir = get_session_recordings_dir(session_id)
        recordings_dir.mkdir(parents=True, exist_ok=True)

        # Container 1: writes recordings
        (recordings_dir / "root_20260211_093010.input").write_text("ls\nwhoami\n")
        (recordings_dir / "root_20260211_093010.output").write_text("root\n")
        (recordings_dir / "root_20260211_093010.timing").write_text("I 0.5 2\n")

        # Container 1 dies (nothing to simulate - files persist on host)

        # Container 2: writes more recordings (different timestamp)
        (recordings_dir / "root_20260211_153010.input").write_text("task submit 'flag'\ny\n")
        (recordings_dir / "root_20260211_153010.output").write_text("Submitted\n")
        (recordings_dir / "root_20260211_153010.timing").write_text("I 1.0 12\n")

        # Verify: all 6 files exist and would be visible inside the container
        all_files = sorted(f.name for f in recordings_dir.iterdir())
        assert len(all_files) == 6
        assert "root_20260211_093010.input" in all_files  # from container 1
        assert "root_20260211_153010.input" in all_files  # from container 2

        # Verify: volume mount in compose points to this directory
        compose = "services:\n  default:\n    image: test:latest\n"
        result = TaskRunner._inject_recordings_volume(compose, session_id)

        import yaml
        parsed = yaml.safe_load(result)
        volume = parsed["services"]["default"]["volumes"][0]
        host_path = volume.split(":")[0]
        assert host_path == str(recordings_dir)
