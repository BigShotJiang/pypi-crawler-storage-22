"""
HtmlGraph FastAPI Backend - Real-time Agent Observability Dashboard

Provides REST API and WebSocket support for viewing:
- Agent activity feed with real-time event streaming
- Orchestration chains and delegation handoffs
- Feature tracker with Kanban views
- Session metrics and performance analytics

Architecture:
- FastAPI backend querying SQLite database
- Jinja2 templates for server-side rendering
- HTMX for interactive UI without page reloads
- WebSocket for real-time event streaming

This module contains the app factory and initialization logic.
Route handlers are organized in the routes/ subpackage.
"""

import logging
import sqlite3
from pathlib import Path

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from htmlgraph.api.cache import QueryCache, init_cache_backend
from htmlgraph.api.dependencies import Dependencies
from htmlgraph.api.filters import register_filters
from htmlgraph.api.routes import (
    analytics_router,
    dashboard_router,
    orchestration_router,
    presence_router,
)
from htmlgraph.api.routes.analytics import init_analytics_routes
from htmlgraph.api.routes.dashboard import init_dashboard_routes
from htmlgraph.api.routes.orchestration import init_orchestration_routes
from htmlgraph.api.routes.presence import init_presence_routes

logger = logging.getLogger(__name__)


def _ensure_database_initialized(db_path: str) -> None:
    """
    Ensure SQLite database exists and has correct schema.

    Args:
        db_path: Path to SQLite database file
    """
    db_file = Path(db_path)
    db_file.parent.mkdir(parents=True, exist_ok=True)

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = cursor.fetchall()
        table_names = [t[0] for t in tables]

        if not table_names:
            logger.info(f"Creating database schema at {db_path}")
            from htmlgraph.db.schema import HtmlGraphDB

            db = HtmlGraphDB(db_path)
            db.connect()
            db.create_tables()
            db.disconnect()
            logger.info("Database schema created successfully")
        else:
            logger.debug(f"Database already initialized with tables: {table_names}")

        conn.close()

    except sqlite3.Error as e:
        logger.warning(f"Database check warning: {e}")
        try:
            from htmlgraph.db.schema import HtmlGraphDB

            db = HtmlGraphDB(db_path)
            db.connect()
            db.create_tables()
            db.disconnect()
        except Exception as create_error:
            logger.error(f"Failed to create database: {create_error}")
            raise


def get_app(db_path: str) -> FastAPI:
    """
    Create and configure FastAPI application.

    Args:
        db_path: Path to SQLite database file

    Returns:
        Configured FastAPI application instance
    """
    # Ensure database is initialized
    _ensure_database_initialized(db_path)

    app = FastAPI(
        title="HtmlGraph Dashboard API",
        description="Real-time agent observability dashboard",
        version="0.1.0",
    )

    # Store database path and query cache in app state
    app.state.db_path = db_path
    app.state.query_cache = QueryCache(ttl_seconds=1.0)

    # Initialize fastapi-cache2 backend
    @app.on_event("startup")
    async def startup_cache() -> None:
        """Initialize cache backend on startup."""
        await init_cache_backend()

    # Setup Jinja2 templates
    template_dir = Path(__file__).parent / "templates"
    template_dir.mkdir(parents=True, exist_ok=True)
    templates = Jinja2Templates(directory=str(template_dir))

    # Register custom filters
    register_filters(templates)

    # Setup static files
    static_dir = Path(__file__).parent / "static"
    static_dir.mkdir(parents=True, exist_ok=True)
    if static_dir.exists():
        app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

    # Create shared dependencies
    deps = Dependencies(db_path=db_path, query_cache=app.state.query_cache)

    # Initialize route modules with dependencies
    init_dashboard_routes(templates, deps)
    init_orchestration_routes(templates, deps)
    init_analytics_routes(deps)
    init_presence_routes(deps, db_path)

    # Register routers
    app.include_router(dashboard_router)
    app.include_router(orchestration_router)
    app.include_router(analytics_router)
    app.include_router(presence_router)

    return app


# Create default app instance
def create_app(db_path: str | None = None) -> FastAPI:
    """Create FastAPI app with default database path."""
    if db_path is None:
        db_path = str(Path.home() / ".htmlgraph" / "htmlgraph.db")

    return get_app(db_path)


# Export for uvicorn
app = create_app()
