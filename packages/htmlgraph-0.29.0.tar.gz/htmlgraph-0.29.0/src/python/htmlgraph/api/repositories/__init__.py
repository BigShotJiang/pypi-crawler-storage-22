"""Repository layer for HtmlGraph API.

Provides abstraction over database access with repository pattern.
Repositories encapsulate all SQL queries for specific entities.
"""

from .base_repository import BaseRepository
from .events_repository import EventsRepository
from .features_repository import FeaturesRepository
from .sessions_repository import SessionsRepository

__all__ = [
    "BaseRepository",
    "EventsRepository",
    "FeaturesRepository",
    "SessionsRepository",
]
