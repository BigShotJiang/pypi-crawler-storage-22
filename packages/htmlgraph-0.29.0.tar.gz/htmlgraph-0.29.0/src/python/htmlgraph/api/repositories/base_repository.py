"""Base repository class with common query patterns and utilities."""

import logging
import time
from typing import Any

import aiosqlite

logger = logging.getLogger(__name__)


class BaseRepository:
    """Base class for all repositories providing common query utilities."""

    def __init__(self, db: aiosqlite.Connection):
        """Initialize repository with database connection.

        Args:
            db: aiosqlite database connection.
        """
        self.db = db

    async def execute_query(
        self, query: str, params: tuple | None = None
    ) -> list[dict[str, Any]]:
        """Execute a SELECT query and return results as list of dicts.

        Args:
            query: SQL SELECT query string.
            params: Optional query parameters tuple.

        Returns:
            List of result rows as dictionaries.
        """
        start_time = time.time()
        try:
            cursor = await self.db.execute(query, params or ())
            rows = await cursor.fetchall()
            elapsed_ms = (time.time() - start_time) * 1000

            # Convert rows to dicts if db.row_factory is Row
            result = []
            for row in rows:
                if hasattr(row, "keys"):
                    result.append(dict(row))
                else:
                    result.append({"value": row})

            logger.debug(
                f"Query executed in {elapsed_ms:.2f}ms, returned {len(result)} rows"
            )
            return result
        except Exception as e:
            logger.error(f"Query execution failed: {e}")
            raise

    async def execute_single(
        self, query: str, params: tuple | None = None
    ) -> dict[str, Any] | None:
        """Execute a SELECT query and return single result.

        Args:
            query: SQL SELECT query string.
            params: Optional query parameters tuple.

        Returns:
            Single result row as dictionary, or None if no results.
        """
        results = await self.execute_query(query, params)
        return results[0] if results else None

    async def execute_scalar(self, query: str, params: tuple | None = None) -> Any:
        """Execute a query and return single scalar value.

        Args:
            query: SQL query returning single value.
            params: Optional query parameters tuple.

        Returns:
            Scalar value from first column of first row.
        """
        cursor = await self.db.execute(query, params or ())
        row = await cursor.fetchone()
        return row[0] if row else None

    async def list_paginated(
        self,
        query: str,
        count_query: str,
        params: tuple | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict[str, Any]:
        """Execute paginated query returning results and total count.

        Args:
            query: SQL SELECT query (should include LIMIT and OFFSET).
            count_query: SQL COUNT query for total results.
            params: Optional query parameters tuple.
            limit: Number of results per page.
            offset: Starting row offset.

        Returns:
            Dictionary with 'items', 'limit', 'offset', and 'total' keys.
        """
        items = await self.execute_query(query, params)
        total = await self.execute_scalar(count_query, params)

        return {
            "items": items,
            "limit": limit,
            "offset": offset,
            "total": total or 0,
        }
