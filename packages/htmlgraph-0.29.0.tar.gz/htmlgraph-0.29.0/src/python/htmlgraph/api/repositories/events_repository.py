"""Repository for agent events queries."""

import logging
from typing import Any

from .base_repository import BaseRepository

logger = logging.getLogger(__name__)


class EventsRepository(BaseRepository):
    """Repository for all agent event queries."""

    async def get_agent_stats(self) -> list[dict[str, Any]]:
        """Get agent statistics aggregated from events.

        Returns:
            List of agent stats including event count, token usage, and performance metrics.
        """
        query = """
            SELECT
                e.agent_id,
                COUNT(*) as event_count,
                SUM(e.cost_tokens) as total_tokens,
                COUNT(DISTINCT e.session_id) as session_count,
                MAX(e.timestamp) as last_activity,
                MAX(e.model) as model,
                s.status,
                AVG(
                    CAST((
                        CAST(julianday(s.ended_at) AS FLOAT) -
                        CAST(julianday(s.started_at) AS FLOAT)
                    ) * 86400 AS FLOAT)
                ) as avg_duration,
                COUNT(CASE WHEN e.status = 'error' THEN 1 END) as error_count,
                CASE
                    WHEN COUNT(*) > 0 THEN
                        ROUND(
                            100.0 * COUNT(CASE WHEN e.status = 'completed' THEN 1 END) / COUNT(*),
                            2
                        )
                    ELSE 0
                END as success_rate
            FROM agent_events e
            LEFT JOIN sessions s ON e.session_id = s.session_id
            WHERE e.agent_id IS NOT NULL
            GROUP BY e.agent_id, s.status
            ORDER BY event_count DESC
        """
        return await self.execute_query(query)

    async def get_events_list(
        self,
        limit: int = 50,
        offset: int = 0,
        session_id: str | None = None,
        agent_id: str | None = None,
    ) -> dict[str, Any]:
        """Get paginated list of events with optional filters.

        Args:
            limit: Number of events to return.
            offset: Starting position.
            session_id: Filter by session (optional).
            agent_id: Filter by agent (optional).

        Returns:
            Dictionary with events list and pagination info.
        """
        where_clauses = ["1=1"]
        params: list[Any] = []

        if session_id:
            where_clauses.append("e.session_id = ?")
            params.append(session_id)

        if agent_id:
            where_clauses.append("e.agent_id = ?")
            params.append(agent_id)

        where_sql = " AND ".join(where_clauses)

        query = f"""
            SELECT e.event_id, e.agent_id, e.event_type, e.timestamp, e.tool_name,
                   e.input_summary, e.tool_input, e.output_summary, e.session_id,
                   e.feature_id, e.parent_event_id, e.status, e.model
            FROM agent_events e
            WHERE {where_sql}
            ORDER BY e.timestamp DESC
            LIMIT ? OFFSET ?
        """
        params.extend([limit, offset])

        count_query = f"SELECT COUNT(*) FROM agent_events e WHERE {where_sql}"

        return await self.list_paginated(
            query, count_query, tuple(params), limit, offset
        )

    async def get_event_by_id(self, event_id: str) -> dict[str, Any] | None:
        """Get single event by ID.

        Args:
            event_id: Event ID to retrieve.

        Returns:
            Event dictionary or None if not found.
        """
        query = """
            SELECT event_id, agent_id, event_type, timestamp, tool_name,
                   input_summary, output_summary, session_id,
                   feature_id, parent_event_id, status, model,
                   cost_tokens, input_tokens, output_tokens
            FROM agent_events
            WHERE event_id = ?
        """
        return await self.execute_single(query, (event_id,))

    async def get_event_children(self, parent_event_id: str) -> list[dict[str, Any]]:
        """Get child events of a parent event.

        Args:
            parent_event_id: Parent event ID.

        Returns:
            List of child event dictionaries.
        """
        query = """
            SELECT event_id, agent_id, event_type, timestamp, tool_name,
                   input_summary, output_summary, session_id,
                   feature_id, parent_event_id, status, model
            FROM agent_events
            WHERE parent_event_id = ?
            ORDER BY timestamp ASC
        """
        return await self.execute_query(query, (parent_event_id,))

    async def get_events_by_session(
        self, session_id: str, limit: int = 100
    ) -> list[dict[str, Any]]:
        """Get all events in a session.

        Args:
            session_id: Session ID to query.
            limit: Maximum number of events to return.

        Returns:
            List of event dictionaries.
        """
        query = """
            SELECT event_id, agent_id, event_type, timestamp, tool_name,
                   input_summary, output_summary, session_id,
                   feature_id, parent_event_id, status, model
            FROM agent_events
            WHERE session_id = ?
            ORDER BY timestamp DESC
            LIMIT ?
        """
        return await self.execute_query(query, (session_id, limit))

    async def get_user_queries(
        self, limit: int = 50, offset: int = 0
    ) -> dict[str, Any]:
        """Get user query events (UserQuery event type).

        Args:
            limit: Number of queries to return.
            offset: Starting position.

        Returns:
            Dictionary with user queries and pagination info.
        """
        query = """
            SELECT event_id, session_id, timestamp, input_summary as query_text,
                   model, cost_tokens
            FROM agent_events
            WHERE event_type = 'UserQuery'
            ORDER BY timestamp DESC
            LIMIT ? OFFSET ?
        """
        count_query = "SELECT COUNT(*) FROM agent_events WHERE event_type = 'UserQuery'"
        params = (limit, offset)

        return await self.list_paginated(query, count_query, params, limit, offset)

    async def get_events_grouped_by_prompt(
        self, limit: int = 50, offset: int = 0
    ) -> dict[str, Any]:
        """Get events grouped by user prompt (conversation turns).

        Args:
            limit: Number of turns to return.
            offset: Starting position.

        Returns:
            Dictionary with conversation turns grouped by UserQuery parent.
        """
        # Get user query events (conversation turns)
        query = """
            SELECT event_id, session_id, timestamp, input_summary as query_text,
                   model, cost_tokens, agent_id
            FROM agent_events
            WHERE event_type = 'UserQuery'
            ORDER BY timestamp DESC
            LIMIT ? OFFSET ?
        """

        params = (limit, offset)
        turns = await self.execute_query(query, params)

        # For each turn, get child events
        for turn in turns:
            children = await self.get_event_children(turn["event_id"])
            turn["children"] = children
            turn["child_count"] = len(children)

        count_query = "SELECT COUNT(*) FROM agent_events WHERE event_type = 'UserQuery'"
        total = await self.execute_scalar(count_query)

        return {
            "conversation_turns": turns,
            "total_turns": total or 0,
            "limit": limit,
            "offset": offset,
        }

    async def get_events_by_status(
        self, status: str, limit: int = 50
    ) -> list[dict[str, Any]]:
        """Get events filtered by status.

        Args:
            status: Event status to filter (e.g., 'completed', 'error').
            limit: Maximum number to return.

        Returns:
            List of event dictionaries.
        """
        query = """
            SELECT event_id, agent_id, event_type, timestamp, tool_name,
                   input_summary, output_summary, session_id,
                   feature_id, parent_event_id, status, model
            FROM agent_events
            WHERE status = ?
            ORDER BY timestamp DESC
            LIMIT ?
        """
        return await self.execute_query(query, (status, limit))

    async def get_tool_usage(self) -> list[dict[str, Any]]:
        """Get statistics on tool usage across all events.

        Returns:
            List of tool usage statistics.
        """
        query = """
            SELECT tool_name, COUNT(*) as usage_count,
                   AVG(cost_tokens) as avg_tokens,
                   SUM(cost_tokens) as total_tokens,
                   COUNT(CASE WHEN status = 'error' THEN 1 END) as error_count
            FROM agent_events
            WHERE tool_name IS NOT NULL
            GROUP BY tool_name
            ORDER BY usage_count DESC
        """
        return await self.execute_query(query)

    async def get_error_events(self, limit: int = 50) -> list[dict[str, Any]]:
        """Get recent error events.

        Args:
            limit: Maximum number to return.

        Returns:
            List of error event dictionaries.
        """
        query = """
            SELECT event_id, agent_id, event_type, timestamp, tool_name,
                   input_summary, output_summary, session_id,
                   feature_id, parent_event_id, status, model
            FROM agent_events
            WHERE status = 'error'
            ORDER BY timestamp DESC
            LIMIT ?
        """
        return await self.execute_query(query, (limit,))
