"""Repository for feature/work item queries."""

import logging
from typing import Any

from .base_repository import BaseRepository

logger = logging.getLogger(__name__)


class FeaturesRepository(BaseRepository):
    """Repository for all feature/work item queries."""

    async def get_features_list(
        self,
        limit: int = 50,
        offset: int = 0,
        feature_type: str | None = None,
        status: str | None = None,
    ) -> dict[str, Any]:
        """Get paginated list of features with optional filters.

        Args:
            limit: Number of features to return.
            offset: Starting position.
            feature_type: Filter by type (feature, bug, spike, etc.) - optional.
            status: Filter by status (open, in_progress, completed) - optional.

        Returns:
            Dictionary with features list and pagination info.
        """
        where_clauses = ["1=1"]
        params: list[Any] = []

        if feature_type:
            where_clauses.append("type = ?")
            params.append(feature_type)

        if status:
            where_clauses.append("status = ?")
            params.append(status)

        where_sql = " AND ".join(where_clauses)

        query = f"""
            SELECT id, type, title, description, status, priority,
                   assigned_to, created_at, updated_at, completed_at
            FROM features
            WHERE {where_sql}
            ORDER BY created_at DESC
            LIMIT ? OFFSET ?
        """
        params.extend([limit, offset])

        count_query = f"SELECT COUNT(*) FROM features WHERE {where_sql}"

        return await self.list_paginated(
            query, count_query, tuple(params), limit, offset
        )

    async def get_feature_by_id(self, feature_id: str) -> dict[str, Any] | None:
        """Get single feature by ID.

        Args:
            feature_id: Feature ID to retrieve.

        Returns:
            Feature dictionary or None if not found.
        """
        query = """
            SELECT id, type, title, description, status, priority,
                   assigned_to, created_at, updated_at, completed_at
            FROM features
            WHERE id = ?
        """
        return await self.execute_single(query, (feature_id,))

    async def get_features_by_type(
        self, feature_type: str, limit: int = 50
    ) -> list[dict[str, Any]]:
        """Get all features of a specific type.

        Args:
            feature_type: Type of feature (feature, bug, spike, chore, epic).
            limit: Maximum number to return.

        Returns:
            List of feature dictionaries.
        """
        query = """
            SELECT id, type, title, description, status, priority,
                   assigned_to, created_at, updated_at, completed_at
            FROM features
            WHERE type = ?
            ORDER BY created_at DESC
            LIMIT ?
        """
        return await self.execute_query(query, (feature_type, limit))

    async def get_features_by_status(
        self, status: str, limit: int = 50
    ) -> list[dict[str, Any]]:
        """Get features filtered by status.

        Args:
            status: Feature status (open, in_progress, completed, blocked).
            limit: Maximum number to return.

        Returns:
            List of feature dictionaries.
        """
        query = """
            SELECT id, type, title, description, status, priority,
                   assigned_to, created_at, updated_at, completed_at
            FROM features
            WHERE status = ?
            ORDER BY created_at DESC
            LIMIT ?
        """
        return await self.execute_query(query, (status, limit))

    async def get_features_by_assignee(
        self, assigned_to: str, limit: int = 50
    ) -> list[dict[str, Any]]:
        """Get features assigned to a person/agent.

        Args:
            assigned_to: Agent ID or person name.
            limit: Maximum number to return.

        Returns:
            List of feature dictionaries.
        """
        query = """
            SELECT id, type, title, description, status, priority,
                   assigned_to, created_at, updated_at, completed_at
            FROM features
            WHERE assigned_to = ?
            ORDER BY created_at DESC
            LIMIT ?
        """
        return await self.execute_query(query, (assigned_to, limit))

    async def get_feature_stats(self) -> dict[str, Any]:
        """Get overall statistics on features.

        Returns:
            Dictionary with feature statistics by type and status.
        """
        stats = {}

        # Get count by type
        type_query = """
            SELECT type, COUNT(*) as count
            FROM features
            GROUP BY type
        """
        type_stats = await self.execute_query(type_query)
        stats["by_type"] = {row["type"]: row["count"] for row in type_stats}

        # Get count by status
        status_query = """
            SELECT status, COUNT(*) as count
            FROM features
            GROUP BY status
        """
        status_stats = await self.execute_query(status_query)
        stats["by_status"] = {row["status"]: row["count"] for row in status_stats}

        # Get total count
        total_query = "SELECT COUNT(*) as total FROM features"
        total = await self.execute_scalar(total_query)
        stats["total"] = int(total or 0)  # type: ignore[assignment]

        return stats

    async def get_open_features(self, limit: int = 50) -> list[dict[str, Any]]:
        """Get all open (not completed) features.

        Args:
            limit: Maximum number to return.

        Returns:
            List of open feature dictionaries.
        """
        query = """
            SELECT id, type, title, description, status, priority,
                   assigned_to, created_at, updated_at, completed_at
            FROM features
            WHERE status != 'completed'
            ORDER BY priority DESC, created_at DESC
            LIMIT ?
        """
        return await self.execute_query(query, (limit,))

    async def get_recent_features(
        self, days: int = 7, limit: int = 50
    ) -> list[dict[str, Any]]:
        """Get features created or updated in last N days.

        Args:
            days: Number of days to look back.
            limit: Maximum number to return.

        Returns:
            List of recent feature dictionaries.
        """
        query = """
            SELECT id, type, title, description, status, priority,
                   assigned_to, created_at, updated_at, completed_at
            FROM features
            WHERE updated_at > datetime('now', ? || ' days')
            ORDER BY updated_at DESC
            LIMIT ?
        """
        return await self.execute_query(query, (f"-{days}", limit))
