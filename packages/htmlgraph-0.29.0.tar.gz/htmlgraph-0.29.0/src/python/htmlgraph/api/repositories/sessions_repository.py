"""Repository for session queries."""

import logging
from typing import Any

from .base_repository import BaseRepository

logger = logging.getLogger(__name__)


class SessionsRepository(BaseRepository):
    """Repository for all session queries."""

    async def get_sessions_list(
        self,
        limit: int = 50,
        offset: int = 0,
        status: str | None = None,
    ) -> dict[str, Any]:
        """Get paginated list of sessions with optional filters.

        Args:
            limit: Number of sessions to return.
            offset: Starting position.
            status: Filter by status (active, completed) - optional.

        Returns:
            Dictionary with sessions list and pagination info.
        """
        where_clauses = ["1=1"]
        params: list[Any] = []

        if status:
            where_clauses.append("status = ?")
            params.append(status)

        where_sql = " AND ".join(where_clauses)

        query = f"""
            SELECT session_id, agent, status, started_at, ended_at,
                   (SELECT COUNT(*) FROM agent_events WHERE session_id = sessions.session_id) as event_count,
                   CASE WHEN ended_at IS NOT NULL THEN
                       CAST((julianday(ended_at) - julianday(started_at)) * 86400 AS INT)
                   ELSE NULL END as duration_seconds
            FROM sessions
            WHERE {where_sql}
            ORDER BY started_at DESC
            LIMIT ? OFFSET ?
        """
        params.extend([limit, offset])

        count_query = f"SELECT COUNT(*) FROM sessions WHERE {where_sql}"

        return await self.list_paginated(
            query, count_query, tuple(params), limit, offset
        )

    async def get_session_by_id(self, session_id: str) -> dict[str, Any] | None:
        """Get single session by ID.

        Args:
            session_id: Session ID to retrieve.

        Returns:
            Session dictionary or None if not found.
        """
        query = """
            SELECT session_id, agent, status, started_at, ended_at,
                   (SELECT COUNT(*) FROM agent_events WHERE session_id = sessions.session_id) as event_count,
                   CASE WHEN ended_at IS NOT NULL THEN
                       CAST((julianday(ended_at) - julianday(started_at)) * 86400 AS INT)
                   ELSE NULL END as duration_seconds
            FROM sessions
            WHERE session_id = ?
        """
        return await self.execute_single(query, (session_id,))

    async def get_active_sessions(self) -> list[dict[str, Any]]:
        """Get all active sessions (not ended).

        Returns:
            List of active session dictionaries.
        """
        query = """
            SELECT session_id, agent, status, started_at, ended_at,
                   (SELECT COUNT(*) FROM agent_events WHERE session_id = sessions.session_id) as event_count,
                   CASE WHEN ended_at IS NOT NULL THEN
                       CAST((julianday(ended_at) - julianday(started_at)) * 86400 AS INT)
                   ELSE NULL END as duration_seconds
            FROM sessions
            WHERE status = 'active' OR ended_at IS NULL
            ORDER BY started_at DESC
        """
        return await self.execute_query(query)

    async def get_sessions_by_agent(
        self, agent_id: str, limit: int = 50
    ) -> list[dict[str, Any]]:
        """Get all sessions for a specific agent.

        Args:
            agent_id: Agent ID to query.
            limit: Maximum number to return.

        Returns:
            List of session dictionaries.
        """
        query = """
            SELECT session_id, agent, status, started_at, ended_at,
                   (SELECT COUNT(*) FROM agent_events WHERE session_id = sessions.session_id) as event_count,
                   CASE WHEN ended_at IS NOT NULL THEN
                       CAST((julianday(ended_at) - julianday(started_at)) * 86400 AS INT)
                   ELSE NULL END as duration_seconds
            FROM sessions
            WHERE agent = ?
            ORDER BY started_at DESC
            LIMIT ?
        """
        return await self.execute_query(query, (agent_id, limit))

    async def get_session_stats(self) -> dict[str, Any]:
        """Get overall statistics on sessions.

        Returns:
            Dictionary with session statistics.
        """
        stats = {}

        # Get total sessions
        total_query = "SELECT COUNT(*) as total FROM sessions"
        total = await self.execute_scalar(total_query)
        stats["total_sessions"] = total or 0

        # Get active sessions
        active_query = (
            "SELECT COUNT(*) FROM sessions WHERE status = 'active' OR ended_at IS NULL"
        )
        active = await self.execute_scalar(active_query)
        stats["active_sessions"] = active or 0

        # Get completed sessions
        completed_query = "SELECT COUNT(*) FROM sessions WHERE status = 'completed' AND ended_at IS NOT NULL"
        completed = await self.execute_scalar(completed_query)
        stats["completed_sessions"] = completed or 0

        # Get average duration
        avg_duration_query = """
            SELECT AVG(
                CAST((julianday(ended_at) - julianday(started_at)) * 86400 AS FLOAT)
            ) as avg_duration
            FROM sessions
            WHERE ended_at IS NOT NULL
        """
        avg_duration = await self.execute_scalar(avg_duration_query)
        stats["avg_duration_seconds"] = avg_duration or 0

        # Get total events across all sessions
        events_query = "SELECT COUNT(*) FROM agent_events"
        events = await self.execute_scalar(events_query)
        stats["total_events"] = events or 0

        return stats

    async def get_recent_sessions(
        self, days: int = 7, limit: int = 50
    ) -> list[dict[str, Any]]:
        """Get sessions started in last N days.

        Args:
            days: Number of days to look back.
            limit: Maximum number to return.

        Returns:
            List of recent session dictionaries.
        """
        query = """
            SELECT session_id, agent, status, started_at, ended_at,
                   (SELECT COUNT(*) FROM agent_events WHERE session_id = sessions.session_id) as event_count,
                   CASE WHEN ended_at IS NOT NULL THEN
                       CAST((julianday(ended_at) - julianday(started_at)) * 86400 AS INT)
                   ELSE NULL END as duration_seconds
            FROM sessions
            WHERE started_at > datetime('now', ? || ' days')
            ORDER BY started_at DESC
            LIMIT ?
        """
        return await self.execute_query(query, (f"-{days}", limit))

    async def get_sessions_by_status(
        self, status: str, limit: int = 50
    ) -> list[dict[str, Any]]:
        """Get sessions filtered by status.

        Args:
            status: Session status (active, completed, error).
            limit: Maximum number to return.

        Returns:
            List of session dictionaries.
        """
        query = """
            SELECT session_id, agent, status, started_at, ended_at,
                   (SELECT COUNT(*) FROM agent_events WHERE session_id = sessions.session_id) as event_count,
                   CASE WHEN ended_at IS NOT NULL THEN
                       CAST((julianday(ended_at) - julianday(started_at)) * 86400 AS INT)
                   ELSE NULL END as duration_seconds
            FROM sessions
            WHERE status = ?
            ORDER BY started_at DESC
            LIMIT ?
        """
        return await self.execute_query(query, (status, limit))

    async def get_session_event_summary(self, session_id: str) -> dict[str, Any]:
        """Get summary of events in a session grouped by type.

        Args:
            session_id: Session ID to query.

        Returns:
            Dictionary with event type counts.
        """
        query = """
            SELECT event_type, COUNT(*) as count
            FROM agent_events
            WHERE session_id = ?
            GROUP BY event_type
        """
        events = await self.execute_query(query, (session_id,))
        return {row["event_type"]: row["count"] for row in events}
