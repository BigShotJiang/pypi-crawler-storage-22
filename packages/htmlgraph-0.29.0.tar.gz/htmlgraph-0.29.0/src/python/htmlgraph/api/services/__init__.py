"""
Service Layer for HtmlGraph API - Business Logic & Aggregation.

Services handle complex business logic and data aggregation, bridging the gap
between thin routes and data repositories. This decouples API routes from
implementation details.

## Service Architecture

Each service encapsulates a domain of business logic:

- **ActivityService**: Activity feed aggregation (grouped events, conversation turns)
- **OrchestrationService**: Orchestration summaries, delegation tracking, model detection
- **AnalyticsService**: Cost analysis, metrics aggregation, performance analytics

## Design Patterns

### Dependency Injection
Services receive dependencies (DB connection, cache, logger) in constructor.
Makes services testable and reusable across contexts.

```python
activity_service = ActivityService(db=db, cache=cache, logger=logger)
result = await activity_service.get_grouped_events(limit=50)
```

### Bulk Fetching
Services minimize N+1 queries by fetching all needed data upfront in bulk,
then aggregating in-memory.

```python
# Bad (N+1 queries):
for prompt in prompts:
    children = db.get_children(prompt.id)  # N queries!

# Good (bulk fetch):
prompts = db.get_all_prompts()
children_by_prompt = db.get_children_by_prompts([p.id for p in prompts])
```

### Caching Strategy
- Services check cache before querying DB
- Services manage cache invalidation
- Cache keys based on query parameters
- Metrics tracked per service method

## Testing Services

Services are testable via dependency injection:

```python
# Mock DB for testing
mock_db = MagicMock()
service = ActivityService(db=mock_db, cache=mock_cache)
result = await service.get_grouped_events(limit=10)
```

## See Also

- `base_service.py` - Base service class
- `activity_service.py` - Activity feed aggregation
- `orchestration_service.py` - Orchestration summaries
- `analytics_service.py` - Cost analysis and metrics
"""

from .activity_service import ActivityService
from .analytics_service import AnalyticsService
from .base_service import BaseService
from .orchestration_service import OrchestrationService

__all__ = [
    "BaseService",
    "ActivityService",
    "OrchestrationService",
    "AnalyticsService",
]
