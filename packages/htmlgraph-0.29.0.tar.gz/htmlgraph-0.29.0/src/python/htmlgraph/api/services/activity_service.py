"""
Activity Service - Activity Feed Aggregation & Grouping.

Handles:
- Fetching and grouping events by conversation turns (UserQuery events)
- Building hierarchical event trees (parent-child nesting)
- Aggregating statistics per conversation turn
- Bulk fetching to eliminate N+1 queries
"""

import json
from typing import Any

from .base_service import BaseService


class ActivityService(BaseService[dict[str, Any]]):
    """Service for activity feed aggregation and event grouping."""

    async def get_grouped_events(
        self, limit: int = 50, cache_ttl: float = 30.0
    ) -> dict[str, Any]:
        """
        Get activity events grouped by conversation turn (UserQuery events).

        Implements bulk fetching to avoid N+1 queries:
        1. Fetch all UserQuery events (most recent first)
        2. Fetch all child events for those UserQuery events in single query
        3. Group children by parent_event_id in-memory
        4. Build hierarchical tree structure
        5. Aggregate statistics per conversation turn

        Args:
            limit: Maximum number of conversation turns to return
            cache_ttl: Cache TTL in seconds (unused, kept for consistency)

        Returns:
            Dictionary with conversation_turns list and metadata
        """
        cache_key = self._get_cache_key("activity:grouped_events", limit=limit)

        async def fetch_grouped_events() -> dict[str, Any]:
            """Fetch and group events by conversation turn."""
            # Step 1: Fetch all UserQuery events (conversation turns)
            user_queries = await self._fetch_user_queries(limit)

            if not user_queries:
                return {
                    "timestamp": self._get_iso_timestamp(),
                    "total_turns": 0,
                    "conversation_turns": [],
                    "note": "No conversation turns found",
                }

            # Extract event IDs for bulk fetch
            user_query_ids = [uq["event_id"] for uq in user_queries]

            # Step 2: Fetch all child events in bulk
            children_by_parent = await self._fetch_children_by_parents(
                user_query_ids, max_depth=4
            )

            # Step 3: Build conversation turn objects
            conversation_turns = []
            for user_query in user_queries:
                uq_id = user_query["event_id"]
                children = children_by_parent.get(uq_id, [])

                # Build conversation turn with stats
                turn = await self._build_conversation_turn(user_query, children)
                conversation_turns.append(turn)

            # Build response
            return {
                "timestamp": self._get_iso_timestamp(),
                "total_turns": len(conversation_turns),
                "conversation_turns": conversation_turns,
                "note": "Groups events by UserQuery prompt (conversation turn). "
                "Child events are linked via parent_event_id.",
            }

        return await self._execute_with_cache(cache_key, fetch_grouped_events)  # type: ignore[no-any-return]

    async def _fetch_user_queries(self, limit: int) -> list[dict[str, Any]]:
        """
        Fetch UserQuery events (conversation turns).

        Args:
            limit: Maximum number to fetch

        Returns:
            List of UserQuery event dictionaries
        """
        query = """
            SELECT
                event_id,
                timestamp,
                input_summary,
                execution_duration_seconds,
                status,
                agent_id
            FROM agent_events
            WHERE tool_name = 'UserQuery'
            ORDER BY timestamp DESC
            LIMIT ?
        """

        rows = await self._execute_query(query, [limit])

        user_queries = []
        for row in rows:
            user_queries.append(
                {
                    "event_id": row[0],
                    "timestamp": row[1],
                    "prompt": row[2] or "",
                    "duration_seconds": row[3] or 0.0,
                    "status": row[4],
                    "agent_id": row[5],
                }
            )

        return user_queries

    async def _fetch_children_by_parents(
        self, parent_ids: list[str], max_depth: int = 4
    ) -> dict[str, list[dict[str, Any]]]:
        """
        Fetch all child events for multiple parents in bulk.

        Uses recursive approach to handle nested children at any depth.

        Args:
            parent_ids: List of parent event IDs
            max_depth: Maximum nesting depth

        Returns:
            Dictionary mapping parent_event_id -> list of child event dicts
        """
        children_by_parent: dict[str, list[dict[str, Any]]] = {
            pid: [] for pid in parent_ids
        }

        if not parent_ids:
            return children_by_parent

        # Recursively fetch children
        await self._fetch_children_recursive(
            parent_ids, children_by_parent, depth=0, max_depth=max_depth
        )

        return children_by_parent

    async def _fetch_children_recursive(
        self,
        parent_ids: list[str],
        children_by_parent: dict[str, list[dict[str, Any]]],
        depth: int = 0,
        max_depth: int = 4,
    ) -> None:
        """
        Recursively fetch children for multiple parents.

        Args:
            parent_ids: List of parent IDs to fetch children for
            children_by_parent: Accumulator dict to populate
            depth: Current recursion depth
            max_depth: Maximum allowed depth
        """
        if depth >= max_depth or not parent_ids:
            return

        # Fetch all children for these parents in one query
        placeholders = ",".join("?" * len(parent_ids))
        query = f"""
            SELECT
                event_id,
                parent_event_id,
                tool_name,
                timestamp,
                input_summary,
                execution_duration_seconds,
                status,
                agent_id,
                model,
                context,
                subagent_type,
                feature_id
            FROM agent_events
            WHERE parent_event_id IN ({placeholders})
            ORDER BY timestamp ASC
        """

        rows = await self._execute_query(query, parent_ids)

        # Build child objects and track next-level parents
        next_level_parents: set[str] = set()

        for row in rows:
            child = {
                "event_id": row[0],
                "tool_name": row[2],
                "timestamp": row[3],
                "summary": self._truncate_text(row[4], 80),
                "duration_seconds": round(row[5] or 0.0, 2),
                "agent": row[7] or "unknown",
                "depth": depth,
                "model": row[8],
                "feature_id": row[11],
            }

            # Parse context for spawner metadata
            context = self._parse_context(row[9])
            spawner_type = context.get("spawner_type")
            spawned_agent = context.get("spawned_agent")

            # Handle subagent_type as alternative spawner indicator
            subagent_type = row[10]
            if not spawner_type and subagent_type:
                spawner_type = (
                    subagent_type.split(":")[-1]
                    if ":" in subagent_type
                    else subagent_type
                )
                spawned_agent = row[7]  # Use agent_id as spawned agent

            # Include spawner metadata if present
            if spawner_type:
                child["spawner_type"] = spawner_type
            if spawned_agent:
                child["spawned_agent"] = spawned_agent
            if subagent_type:
                child["subagent_type"] = subagent_type

            # Add to parent's children list
            parent_id = row[1]
            children_by_parent[parent_id].append(child)
            next_level_parents.add(row[0])

        # Recursively fetch children of these children
        if next_level_parents:
            await self._fetch_children_recursive(
                list(next_level_parents),
                children_by_parent,
                depth=depth + 1,
                max_depth=max_depth,
            )

    async def _build_conversation_turn(
        self, user_query: dict[str, Any], children: list[dict[str, Any]]
    ) -> dict[str, Any]:
        """
        Build conversation turn object with aggregated statistics.

        Args:
            user_query: UserQuery event dictionary
            children: List of child event dictionaries

        Returns:
            Conversation turn with userQuery, children, and stats
        """
        # Calculate statistics from user query and children
        total_duration = user_query["duration_seconds"]
        success_count = 1 if user_query["status"] in ("recorded", "success") else 0
        error_count = 0 if user_query["status"] in ("recorded", "success") else 1

        # Add children stats
        for child in children:
            total_duration += child["duration_seconds"]
            # Status field not always present in children, assume success for now
            success_count += 1

        # Check if any child has spawner metadata
        has_spawner = self._has_spawner_in_children(children)

        return {
            "userQuery": {
                "event_id": user_query["event_id"],
                "timestamp": user_query["timestamp"],
                "prompt": user_query["prompt"][:200],  # Truncate for display
                "duration_seconds": round(user_query["duration_seconds"], 2),
                "agent_id": user_query["agent_id"],
            },
            "children": children,
            "has_spawner": has_spawner,
            "stats": {
                "tool_count": len(children),
                "total_duration": round(total_duration, 2),
                "success_count": success_count,
                "error_count": error_count,
            },
        }

    def _has_spawner_in_children(self, children: list[dict[str, Any]]) -> bool:
        """
        Recursively check if any child has spawner metadata.

        Args:
            children: List of child event dictionaries

        Returns:
            True if any child has spawner_type or spawned_agent
        """
        for child in children:
            if child.get("spawner_type") or child.get("spawned_agent"):
                return True
            # Check nested children if present
            if "children" in child and self._has_spawner_in_children(child["children"]):
                return True
        return False

    def _parse_context(self, context_json: str | None) -> dict[str, Any]:
        """
        Parse JSON context string.

        Args:
            context_json: JSON string from context column

        Returns:
            Parsed dictionary or empty dict if invalid
        """
        if not context_json:
            return {}

        try:
            return json.loads(context_json)  # type: ignore[no-any-return]
        except (json.JSONDecodeError, TypeError):
            return {}

    @staticmethod
    def _truncate_text(text: str | None, max_length: int) -> str:
        """Truncate text to max_length with ellipsis."""
        if not text:
            return ""
        if len(text) > max_length:
            return text[:max_length] + "..."
        return text

    @staticmethod
    def _get_iso_timestamp() -> str:
        """Get current timestamp in ISO format."""
        from datetime import datetime

        return datetime.now().isoformat()
