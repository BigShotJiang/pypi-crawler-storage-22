"""
Analytics Service - Cost Analysis & Metrics Aggregation.

Handles:
- Cost token aggregation and analysis
- Performance metrics (duration, success rates)
- Per-agent and per-tool cost analysis
- Cost trends over time
"""

from typing import Any

from .base_service import BaseService


class AnalyticsService(BaseService[dict[str, Any]]):
    """Service for cost analysis and performance metrics."""

    async def get_cost_summary(
        self,
        session_id: str | None = None,
        agent_id: str | None = None,
        cache_ttl: float = 60.0,
    ) -> dict[str, Any]:
        """
        Get cost summary with token aggregation and breakdown.

        Args:
            session_id: Optional session filter
            agent_id: Optional agent filter
            cache_ttl: Cache TTL in seconds

        Returns:
            Dictionary with cost totals and breakdowns by tool/agent/model
        """
        cache_key = self._get_cache_key(
            "analytics:cost_summary",
            session_id=session_id,
            agent_id=agent_id,
        )

        async def fetch_summary() -> dict[str, Any]:
            """Fetch cost summary."""
            # Fetch total costs
            total_cost = await self._fetch_total_cost(session_id, agent_id)

            # Fetch cost by tool
            cost_by_tool = await self._fetch_cost_by_tool(session_id, agent_id)

            # Fetch cost by model
            cost_by_model = await self._fetch_cost_by_model(session_id, agent_id)

            # Fetch cost by agent
            cost_by_agent = await self._fetch_cost_by_agent(session_id)

            # Calculate cost metrics
            total_tokens = total_cost["total_tokens"]
            total_events = total_cost["total_events"]
            avg_cost_per_event = (
                (total_tokens / total_events) if total_events > 0 else 0
            )

            return {
                "timestamp": self._get_iso_timestamp(),
                "filters": {
                    "session_id": session_id,
                    "agent_id": agent_id,
                },
                "summary": {
                    "total_tokens": total_tokens,
                    "total_events": total_events,
                    "avg_tokens_per_event": round(avg_cost_per_event, 2),
                },
                "by_tool": cost_by_tool,
                "by_model": cost_by_model,
                "by_agent": cost_by_agent,
            }

        return await self._execute_with_cache(cache_key, fetch_summary)  # type: ignore[no-any-return]

    async def _fetch_total_cost(
        self, session_id: str | None = None, agent_id: str | None = None
    ) -> dict[str, Any]:
        """
        Fetch total cost tokens and event count.

        Args:
            session_id: Optional session filter
            agent_id: Optional agent filter

        Returns:
            Dictionary with total_tokens and total_events
        """
        query = """
            SELECT
                SUM(cost_tokens) as total_tokens,
                COUNT(*) as total_events
            FROM agent_events
            WHERE 1=1
        """
        params: list[Any] = []

        if session_id:
            query += " AND session_id = ?"
            params.append(session_id)

        if agent_id:
            query += " AND agent_id = ?"
            params.append(agent_id)

        row = await self._execute_query_one(query, params)

        if not row or row[0] is None:
            return {"total_tokens": 0, "total_events": 0}

        return {"total_tokens": int(row[0]), "total_events": int(row[1])}

    async def _fetch_cost_by_tool(
        self, session_id: str | None = None, agent_id: str | None = None
    ) -> list[dict[str, Any]]:
        """
        Fetch cost breakdown by tool type.

        Args:
            session_id: Optional session filter
            agent_id: Optional agent filter

        Returns:
            List of cost statistics per tool
        """
        query = """
            SELECT
                tool_name,
                COUNT(*) as call_count,
                SUM(cost_tokens) as total_tokens,
                AVG(cost_tokens) as avg_tokens,
                AVG(execution_duration_seconds) as avg_duration
            FROM agent_events
            WHERE tool_name IS NOT NULL
        """
        params: list[Any] = []

        if session_id:
            query += " AND session_id = ?"
            params.append(session_id)

        if agent_id:
            query += " AND agent_id = ?"
            params.append(agent_id)

        query += " GROUP BY tool_name ORDER BY total_tokens DESC"

        rows = await self._execute_query(query, params)

        cost_by_tool = []
        for row in rows:
            cost_by_tool.append(
                {
                    "tool_name": row[0],
                    "call_count": row[1],
                    "total_tokens": int(row[2] or 0),
                    "avg_tokens": round(row[3] or 0, 2),
                    "avg_duration": round(row[4] or 0, 2),
                }
            )

        return cost_by_tool

    async def _fetch_cost_by_model(
        self, session_id: str | None = None, agent_id: str | None = None
    ) -> list[dict[str, Any]]:
        """
        Fetch cost breakdown by model.

        Args:
            session_id: Optional session filter
            agent_id: Optional agent filter

        Returns:
            List of cost statistics per model
        """
        query = """
            SELECT
                model,
                COUNT(*) as event_count,
                SUM(cost_tokens) as total_tokens,
                AVG(cost_tokens) as avg_tokens,
                COUNT(DISTINCT agent_id) as agent_count
            FROM agent_events
            WHERE model IS NOT NULL
        """
        params: list[Any] = []

        if session_id:
            query += " AND session_id = ?"
            params.append(session_id)

        if agent_id:
            query += " AND agent_id = ?"
            params.append(agent_id)

        query += " GROUP BY model ORDER BY total_tokens DESC"

        rows = await self._execute_query(query, params)

        cost_by_model = []
        for row in rows:
            cost_by_model.append(
                {
                    "model": row[0] or "unknown",
                    "event_count": row[1],
                    "total_tokens": int(row[2] or 0),
                    "avg_tokens": round(row[3] or 0, 2),
                    "agent_count": row[4],
                }
            )

        return cost_by_model

    async def _fetch_cost_by_agent(
        self, session_id: str | None = None
    ) -> list[dict[str, Any]]:
        """
        Fetch cost breakdown by agent.

        Args:
            session_id: Optional session filter

        Returns:
            List of cost statistics per agent
        """
        query = """
            SELECT
                agent_id,
                COUNT(*) as event_count,
                SUM(cost_tokens) as total_tokens,
                AVG(cost_tokens) as avg_tokens,
                COUNT(DISTINCT session_id) as session_count
            FROM agent_events
            WHERE agent_id IS NOT NULL
        """
        params: list[Any] = []

        if session_id:
            query += " AND session_id = ?"
            params.append(session_id)

        query += " GROUP BY agent_id ORDER BY total_tokens DESC"

        rows = await self._execute_query(query, params)

        cost_by_agent = []
        for row in rows:
            cost_by_agent.append(
                {
                    "agent_id": row[0],
                    "event_count": row[1],
                    "total_tokens": int(row[2] or 0),
                    "avg_tokens": round(row[3] or 0, 2),
                    "session_count": row[4],
                }
            )

        return cost_by_agent

    async def get_performance_metrics(
        self,
        session_id: str | None = None,
        agent_id: str | None = None,
        cache_ttl: float = 60.0,
    ) -> dict[str, Any]:
        """
        Get performance metrics (execution time, success rates).

        Args:
            session_id: Optional session filter
            agent_id: Optional agent filter
            cache_ttl: Cache TTL in seconds

        Returns:
            Dictionary with performance metrics
        """
        cache_key = self._get_cache_key(
            "analytics:performance_metrics",
            session_id=session_id,
            agent_id=agent_id,
        )

        async def fetch_metrics() -> dict[str, Any]:
            """Fetch performance metrics."""
            # Fetch duration stats
            duration_stats = await self._fetch_duration_stats(session_id, agent_id)

            # Fetch success rates
            success_rates = await self._fetch_success_rates(session_id, agent_id)

            # Fetch tool performance
            tool_perf = await self._fetch_tool_performance(session_id, agent_id)

            return {
                "timestamp": self._get_iso_timestamp(),
                "filters": {
                    "session_id": session_id,
                    "agent_id": agent_id,
                },
                "duration": duration_stats,
                "success_rates": success_rates,
                "tools": tool_perf,
            }

        return await self._execute_with_cache(cache_key, fetch_metrics)  # type: ignore[no-any-return]

    async def _fetch_duration_stats(
        self, session_id: str | None = None, agent_id: str | None = None
    ) -> dict[str, Any]:
        """Fetch execution duration statistics."""
        query = """
            SELECT
                AVG(execution_duration_seconds) as avg,
                MIN(execution_duration_seconds) as min,
                MAX(execution_duration_seconds) as max
            FROM agent_events
            WHERE execution_duration_seconds IS NOT NULL
        """
        params: list[Any] = []

        if session_id:
            query += " AND session_id = ?"
            params.append(session_id)

        if agent_id:
            query += " AND agent_id = ?"
            params.append(agent_id)

        row = await self._execute_query_one(query, params)

        if not row:
            return {"avg": 0, "min": 0, "max": 0}

        return {
            "avg": round(row[0] or 0, 2),
            "min": round(row[1] or 0, 2),
            "max": round(row[2] or 0, 2),
        }

    async def _fetch_success_rates(
        self, session_id: str | None = None, agent_id: str | None = None
    ) -> dict[str, Any]:
        """Fetch success/error rates."""
        query = """
            SELECT
                COUNT(*) as total,
                COUNT(CASE WHEN status IN ('recorded', 'success') THEN 1 END) as success,
                COUNT(CASE WHEN status NOT IN ('recorded', 'success') THEN 1 END) as error
            FROM agent_events
        """
        params: list[Any] = []

        if session_id:
            query += " WHERE session_id = ?"
            params.append(session_id)
        elif agent_id:
            query += " WHERE agent_id = ?"
            params.append(agent_id)

        # Fix: Add AND for second condition if session_id exists
        if session_id and agent_id:
            query = """
                SELECT
                    COUNT(*) as total,
                    COUNT(CASE WHEN status IN ('recorded', 'success') THEN 1 END) as success,
                    COUNT(CASE WHEN status NOT IN ('recorded', 'success') THEN 1 END) as error
                FROM agent_events
                WHERE session_id = ? AND agent_id = ?
            """
            params = [session_id, agent_id]

        row = await self._execute_query_one(query, params)

        if not row or row[0] == 0:
            return {"total": 0, "success": 0, "error": 0, "success_rate": 0}

        success_rate = (row[1] / row[0] * 100) if row[0] > 0 else 0

        return {
            "total": row[0],
            "success": row[1],
            "error": row[2],
            "success_rate": round(success_rate, 1),
        }

    async def _fetch_tool_performance(
        self, session_id: str | None = None, agent_id: str | None = None
    ) -> list[dict[str, Any]]:
        """Fetch performance metrics per tool."""
        query = """
            SELECT
                tool_name,
                AVG(execution_duration_seconds) as avg_duration,
                MIN(execution_duration_seconds) as min_duration,
                MAX(execution_duration_seconds) as max_duration,
                COUNT(CASE WHEN status IN ('recorded', 'success') THEN 1 END) as success_count,
                COUNT(CASE WHEN status NOT IN ('recorded', 'success') THEN 1 END) as error_count
            FROM agent_events
            WHERE tool_name IS NOT NULL
        """
        params: list[Any] = []

        if session_id:
            query += " AND session_id = ?"
            params.append(session_id)

        if agent_id:
            query += " AND agent_id = ?"
            params.append(agent_id)

        query += " GROUP BY tool_name ORDER BY avg_duration DESC"

        rows = await self._execute_query(query, params)

        tool_perf = []
        for row in rows:
            total = row[4] + row[5]
            success_rate = (row[4] / total * 100) if total > 0 else 0

            tool_perf.append(
                {
                    "tool_name": row[0],
                    "avg_duration": round(row[1] or 0, 2),
                    "min_duration": round(row[2] or 0, 2),
                    "max_duration": round(row[3] or 0, 2),
                    "success_count": row[4],
                    "error_count": row[5],
                    "success_rate": round(success_rate, 1),
                }
            )

        return tool_perf

    @staticmethod
    def _get_iso_timestamp() -> str:
        """Get current timestamp in ISO format."""
        from datetime import datetime

        return datetime.now().isoformat()
