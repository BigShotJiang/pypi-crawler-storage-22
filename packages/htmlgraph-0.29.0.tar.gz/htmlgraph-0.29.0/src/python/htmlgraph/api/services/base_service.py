"""
Base Service Class - Foundation for all service implementations.

Provides common functionality:
- Database connection management
- Query caching with metrics
- Logging and error handling
- Common helper methods
"""

import logging
import time
from typing import Any, Generic, TypeVar

import aiosqlite

T = TypeVar("T")


class BaseService(Generic[T]):
    """
    Base service class providing common functionality for all services.

    Attributes:
        db: Database connection (aiosqlite)
        cache: Query cache instance with TTL support
        logger: Logger instance for this service
    """

    def __init__(
        self,
        db: aiosqlite.Connection,
        cache: Any,  # QueryCache from main.py
        logger: logging.Logger | None = None,
    ) -> None:
        """
        Initialize service with dependencies.

        Args:
            db: aiosqlite database connection
            cache: Query cache with get/set/record_metric methods
            logger: Logger instance (uses module logger if None)
        """
        self.db = db
        self.cache = cache
        self.logger = logger or logging.getLogger(self.__class__.__name__)

    def _get_cache_key(self, base_key: str, **params: Any) -> str:
        """
        Generate cache key from base key and parameters.

        Args:
            base_key: Base cache key string
            **params: Parameters to include in key

        Returns:
            Unique cache key string
        """
        if not params:
            return base_key

        # Sort params for consistent key generation
        param_strs = [f"{k}={v}" for k, v in sorted(params.items())]
        return f"{base_key}:{':'.join(param_strs)}"

    async def _execute_with_cache(
        self,
        cache_key: str,
        query_func: Any,
        cache_ttl: float = 30.0,
    ) -> Any:
        """
        Execute async function with cache support.

        Checks cache first, falls back to executing query_func if not cached.
        Records metrics for cache hits/misses.

        Args:
            cache_key: Cache key for this query
            query_func: Async function to execute if not cached
            cache_ttl: Cache TTL (seconds) - used for metrics only

        Returns:
            Cached or newly computed result
        """
        query_start_time = time.time()

        # Check cache first
        cached_result = self.cache.get(cache_key)
        if cached_result is not None:
            query_time_ms = (time.time() - query_start_time) * 1000
            self.cache.record_metric(cache_key, query_time_ms, cache_hit=True)
            self.logger.debug(f"Cache HIT for {cache_key} (time={query_time_ms:.2f}ms)")
            return cached_result

        # Execute query if not cached
        exec_start = time.time()
        result = await query_func()
        exec_time_ms = (time.time() - exec_start) * 1000

        # Cache the result
        self.cache.set(cache_key, result)
        query_time_ms = (time.time() - query_start_time) * 1000
        self.cache.record_metric(cache_key, exec_time_ms, cache_hit=False)
        self.logger.debug(
            f"Cache MISS for {cache_key} "
            f"(db_time={exec_time_ms:.2f}ms, total_time={query_time_ms:.2f}ms)"
        )

        return result

    async def _execute_query(self, sql: str, params: list[Any] | None = None) -> Any:
        """
        Execute SQL query and return all rows.

        Args:
            sql: SQL query string
            params: Query parameters

        Returns:
            List of rows (as tuples)
        """
        if params is None:
            params = []

        async with self.db.execute(sql, params) as cursor:
            rows = await cursor.fetchall()
        return rows

    async def _execute_query_one(
        self, sql: str, params: list[Any] | None = None
    ) -> Any:
        """
        Execute SQL query and return first row.

        Args:
            sql: SQL query string
            params: Query parameters

        Returns:
            First row as tuple, or None if no rows
        """
        if params is None:
            params = []

        async with self.db.execute(sql, params) as cursor:
            row = await cursor.fetchone()
        return row
