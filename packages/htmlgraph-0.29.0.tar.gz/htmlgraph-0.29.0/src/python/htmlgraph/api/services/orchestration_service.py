"""
Orchestration Service - Orchestration Summaries & Delegation Tracking.

Handles:
- Aggregating events by tool type (Bash, Read, etc.)
- Counting successes/failures per tool
- Detecting models used in orchestration chains
- Grouping events by agent/model
- Calculating orchestration metrics
"""

from typing import Any

from .base_service import BaseService


class OrchestrationService(BaseService[dict[str, Any]]):
    """Service for orchestration summaries and delegation tracking."""

    async def get_orchestration_summary(
        self,
        session_id: str | None = None,
        agent_id: str | None = None,
        cache_ttl: float = 30.0,
    ) -> dict[str, Any]:
        """
        Get orchestration summary with tool usage and model detection.

        Aggregates events by tool type and detects models used in orchestration.

        Args:
            session_id: Optional session filter
            agent_id: Optional agent filter
            cache_ttl: Cache TTL in seconds

        Returns:
            Dictionary with tool summaries, model distribution, and metrics
        """
        cache_key = self._get_cache_key(
            "orchestration:summary",
            session_id=session_id,
            agent_id=agent_id,
        )

        async def fetch_summary() -> dict[str, Any]:
            """Fetch and aggregate orchestration data."""
            # Fetch tool usage statistics
            tool_stats = await self._fetch_tool_statistics(session_id, agent_id)

            # Fetch model distribution
            model_dist = await self._fetch_model_distribution(session_id, agent_id)

            # Fetch agent orchestration patterns
            agent_patterns = await self._fetch_agent_patterns(session_id)

            # Calculate aggregate metrics
            total_tools = len(tool_stats)
            total_calls = sum(t["count"] for t in tool_stats)
            total_success = sum(t["success_count"] for t in tool_stats)
            total_errors = sum(t["error_count"] for t in tool_stats)
            success_rate = (total_success / total_calls * 100) if total_calls > 0 else 0

            return {
                "timestamp": self._get_iso_timestamp(),
                "filters": {
                    "session_id": session_id,
                    "agent_id": agent_id,
                },
                "summary": {
                    "total_tools": total_tools,
                    "total_calls": total_calls,
                    "total_success": total_success,
                    "total_errors": total_errors,
                    "success_rate": round(success_rate, 1),
                },
                "tools": tool_stats,
                "models": model_dist,
                "agents": agent_patterns,
            }

        return await self._execute_with_cache(cache_key, fetch_summary)  # type: ignore[no-any-return]

    async def _fetch_tool_statistics(
        self, session_id: str | None = None, agent_id: str | None = None
    ) -> list[dict[str, Any]]:
        """
        Fetch aggregated statistics for each tool type.

        Args:
            session_id: Optional session filter
            agent_id: Optional agent filter

        Returns:
            List of tool statistics (count, success/error, duration)
        """
        query = """
            SELECT
                tool_name,
                COUNT(*) as count,
                COUNT(CASE WHEN status IN ('recorded', 'success') THEN 1 END) as success_count,
                COUNT(CASE WHEN status NOT IN ('recorded', 'success') THEN 1 END) as error_count,
                AVG(execution_duration_seconds) as avg_duration,
                MAX(execution_duration_seconds) as max_duration,
                MIN(execution_duration_seconds) as min_duration,
                COUNT(DISTINCT agent_id) as agent_count
            FROM agent_events
            WHERE tool_name IS NOT NULL
        """
        params: list[Any] = []

        if session_id:
            query += " AND session_id = ?"
            params.append(session_id)

        if agent_id:
            query += " AND agent_id = ?"
            params.append(agent_id)

        query += " GROUP BY tool_name ORDER BY count DESC"

        rows = await self._execute_query(query, params)

        tool_stats = []
        for row in rows:
            tool_stats.append(
                {
                    "name": row[0],
                    "count": row[1],
                    "success_count": row[2],
                    "error_count": row[3],
                    "avg_duration": round(row[4] or 0.0, 2),
                    "max_duration": round(row[5] or 0.0, 2),
                    "min_duration": round(row[6] or 0.0, 2),
                    "agent_count": row[7],
                    "success_rate": round(
                        (row[2] / row[1] * 100) if row[1] > 0 else 0, 1
                    ),
                }
            )

        return tool_stats

    async def _fetch_model_distribution(
        self, session_id: str | None = None, agent_id: str | None = None
    ) -> list[dict[str, Any]]:
        """
        Fetch model usage distribution in orchestration.

        Args:
            session_id: Optional session filter
            agent_id: Optional agent filter

        Returns:
            List of model usage statistics
        """
        query = """
            SELECT
                model,
                COUNT(*) as count,
                COUNT(DISTINCT agent_id) as agent_count,
                COUNT(DISTINCT session_id) as session_count
            FROM agent_events
            WHERE model IS NOT NULL
        """
        params: list[Any] = []

        if session_id:
            query += " AND session_id = ?"
            params.append(session_id)

        if agent_id:
            query += " AND agent_id = ?"
            params.append(agent_id)

        query += " GROUP BY model ORDER BY count DESC"

        rows = await self._execute_query(query, params)

        model_dist = []
        for row in rows:
            model_dist.append(
                {
                    "name": row[0] or "unknown",
                    "count": row[1],
                    "agent_count": row[2],
                    "session_count": row[3],
                }
            )

        return model_dist

    async def _fetch_agent_patterns(
        self, session_id: str | None = None
    ) -> list[dict[str, Any]]:
        """
        Fetch orchestration patterns per agent.

        Args:
            session_id: Optional session filter

        Returns:
            List of agent orchestration patterns
        """
        query = """
            SELECT
                agent_id,
                COUNT(*) as event_count,
                COUNT(DISTINCT tool_name) as tool_diversity,
                COUNT(DISTINCT session_id) as session_count,
                AVG(execution_duration_seconds) as avg_duration,
                COUNT(DISTINCT CASE WHEN subagent_type IS NOT NULL THEN 1 END) as delegation_count
            FROM agent_events
            WHERE agent_id IS NOT NULL
        """
        params: list[Any] = []

        if session_id:
            query += " AND session_id = ?"
            params.append(session_id)

        query += " GROUP BY agent_id ORDER BY event_count DESC"

        rows = await self._execute_query(query, params)

        agent_patterns = []
        for row in rows:
            agent_patterns.append(
                {
                    "agent_id": row[0],
                    "event_count": row[1],
                    "tool_diversity": row[2],
                    "session_count": row[3],
                    "avg_duration": round(row[4] or 0.0, 2),
                    "delegation_count": row[5] or 0,
                }
            )

        return agent_patterns

    async def get_delegation_chain(self, root_event_id: str) -> dict[str, Any]:
        """
        Trace a delegation chain starting from root event.

        Follows parent_event_id relationships to show orchestration hierarchy.

        Args:
            root_event_id: Root event ID to trace

        Returns:
            Dictionary with delegation chain structure
        """
        cache_key = self._get_cache_key(
            "orchestration:delegation_chain",
            root_event_id=root_event_id,
        )

        async def fetch_chain() -> dict[str, Any]:
            """Fetch delegation chain."""
            # Get root event
            root_query = """
                SELECT
                    event_id, agent_id, tool_name, timestamp,
                    input_summary, status, model
                FROM agent_events
                WHERE event_id = ?
            """
            root_row = await self._execute_query_one(root_query, [root_event_id])

            if not root_row:
                return {
                    "error": "Root event not found",
                    "root_event_id": root_event_id,
                }

            # Build delegation chain
            chain = await self._build_delegation_chain(root_event_id)

            return {
                "timestamp": self._get_iso_timestamp(),
                "root_event_id": root_event_id,
                "root_agent": root_row[1],
                "root_tool": root_row[2],
                "chain": chain,
            }

        return await self._execute_with_cache(cache_key, fetch_chain)  # type: ignore[no-any-return]

    async def _build_delegation_chain(
        self, event_id: str, depth: int = 0, max_depth: int = 10
    ) -> list[dict[str, Any]]:
        """
        Recursively build delegation chain from event.

        Args:
            event_id: Event ID to trace
            depth: Current recursion depth
            max_depth: Maximum depth to trace

        Returns:
            List of events in delegation chain
        """
        if depth >= max_depth:
            return []

        # Get children of this event
        query = """
            SELECT
                event_id, agent_id, tool_name, timestamp,
                input_summary, status, subagent_type
            FROM agent_events
            WHERE parent_event_id = ?
            ORDER BY timestamp ASC
        """
        rows = await self._execute_query(query, [event_id])

        chain = []
        for row in rows:
            child_id = row[0]
            child = {
                "event_id": child_id,
                "depth": depth,
                "agent_id": row[1],
                "tool_name": row[2],
                "timestamp": row[3],
                "summary": self._truncate_text(row[4], 80),
                "status": row[5],
                "subagent_type": row[6],
            }

            # Recursively get this child's children
            nested_chain = await self._build_delegation_chain(
                child_id, depth + 1, max_depth
            )
            if nested_chain:
                child["children"] = nested_chain

            chain.append(child)

        return chain

    @staticmethod
    def _truncate_text(text: str | None, max_length: int) -> str:
        """Truncate text to max_length with ellipsis."""
        if not text:
            return ""
        if len(text) > max_length:
            return text[:max_length] + "..."
        return text

    @staticmethod
    def _get_iso_timestamp() -> str:
        """Get current timestamp in ISO format."""
        from datetime import datetime

        return datetime.now().isoformat()
