"""Tests for Pydantic integration in CLI commands.

Verifies that argparse arguments are validated through Pydantic models
and that validation errors are properly formatted for user-friendly output.
"""

from __future__ import annotations

import pytest
from htmlgraph.cli.models import (
    FeatureCreateConfig,
    FeatureFilter,
    InitConfig,
    ServeApiConfig,
    ServeConfig,
    SessionEndConfig,
    SessionStartConfig,
    TrackNewConfig,
    format_validation_error,
    validate_args,
)
from pydantic import ValidationError


class TestServeConfig:
    """Test ServeConfig model validation."""

    def test_valid_config(self):
        """Test valid serve configuration."""
        config = ServeConfig(
            port=8080,
            host="0.0.0.0",
            graph_dir=".htmlgraph",
            static_dir=".",
            no_watch=False,
            auto_port=False,
        )
        assert config.port == 8080
        assert config.host == "0.0.0.0"

    def test_port_validation_too_high(self):
        """Test port validation rejects values above 65535."""
        with pytest.raises(ValidationError) as exc_info:
            ServeConfig(port=99999)

        assert "port" in str(exc_info.value)
        assert "65535" in str(exc_info.value)

    def test_port_validation_too_low(self):
        """Test port validation rejects values below 1024."""
        with pytest.raises(ValidationError) as exc_info:
            ServeConfig(port=500)

        assert "port" in str(exc_info.value)
        assert "1024" in str(exc_info.value)

    def test_host_validation_empty(self):
        """Test host validation rejects empty strings."""
        with pytest.raises(ValidationError) as exc_info:
            ServeConfig(host="")

        assert "host" in str(exc_info.value).lower()

    def test_default_values(self):
        """Test default values are applied."""
        config = ServeConfig()
        assert config.port == 8080
        assert config.host == "0.0.0.0"
        assert config.graph_dir == ".htmlgraph"
        assert config.no_watch is False


class TestServeApiConfig:
    """Test ServeApiConfig model validation."""

    def test_valid_config(self):
        """Test valid serve-api configuration."""
        config = ServeApiConfig(
            port=8000,
            host="127.0.0.1",
            auto_port=False,
            reload=True,
        )
        assert config.port == 8000
        assert config.reload is True

    def test_port_validation(self):
        """Test port validation works same as ServeConfig."""
        with pytest.raises(ValidationError):
            ServeApiConfig(port=100000)


class TestInitConfig:
    """Test InitConfig model validation."""

    def test_valid_config(self):
        """Test valid init configuration."""
        config = InitConfig(
            dir="/tmp/test",
            install_hooks=True,
            interactive=False,
            no_index=False,
            no_update_gitignore=False,
            no_events_keep=False,
        )
        assert config.dir == "/tmp/test"
        assert config.install_hooks is True

    def test_default_values(self):
        """Test default values for init."""
        config = InitConfig()
        assert config.dir == "."
        assert config.install_hooks is False


class TestFeatureFilter:
    """Test FeatureFilter model validation."""

    def test_valid_status(self):
        """Test valid status values."""
        for status in ["todo", "in_progress", "completed", "blocked", "all"]:
            filter_model = FeatureFilter(status=status)
            assert filter_model.status == status

    def test_invalid_status(self):
        """Test invalid status is rejected."""
        with pytest.raises(ValidationError) as exc_info:
            FeatureFilter(status="invalid_status")

        assert "status" in str(exc_info.value).lower()

    def test_valid_priority(self):
        """Test valid priority values."""
        for priority in ["high", "medium", "low", "critical", "all"]:
            filter_model = FeatureFilter(priority=priority)
            assert filter_model.priority == priority

    def test_invalid_priority(self):
        """Test invalid priority is rejected."""
        with pytest.raises(ValidationError) as exc_info:
            FeatureFilter(priority="invalid_priority")

        assert "priority" in str(exc_info.value).lower()


class TestFeatureCreateConfig:
    """Test FeatureCreateConfig model validation."""

    def test_valid_config(self):
        """Test valid feature creation config."""
        config = FeatureCreateConfig(
            title="Test Feature",
            description="Test description",
            priority="high",
            steps=5,
        )
        assert config.title == "Test Feature"
        assert config.priority == "high"

    def test_empty_title_rejected(self):
        """Test empty title is rejected."""
        with pytest.raises(ValidationError) as exc_info:
            FeatureCreateConfig(title="")

        assert "title" in str(exc_info.value).lower()

    def test_whitespace_title_stripped(self):
        """Test title whitespace is stripped."""
        config = FeatureCreateConfig(title="  Test  ")
        assert config.title == "Test"

    def test_negative_steps_rejected(self):
        """Test negative steps are rejected."""
        with pytest.raises(ValidationError) as exc_info:
            FeatureCreateConfig(title="Test", steps=-1)

        assert "steps" in str(exc_info.value).lower()


class TestSessionStartConfig:
    """Test SessionStartConfig model validation."""

    def test_valid_config(self):
        """Test valid session start config."""
        config = SessionStartConfig(
            session_id="sess-123",
            agent="claude",
            title="Test Session",
        )
        assert config.session_id == "sess-123"
        assert config.agent == "claude"

    def test_default_agent(self):
        """Test default agent value."""
        config = SessionStartConfig()
        assert config.agent == "claude-code"


class TestSessionEndConfig:
    """Test SessionEndConfig model validation."""

    def test_valid_config(self):
        """Test valid session end config."""
        config = SessionEndConfig(
            session_id="sess-123",
            notes="Test notes",
            recommend="Next steps",
            blockers=["blocker1", "blocker2"],
        )
        assert config.session_id == "sess-123"
        assert len(config.blockers) == 2

    def test_empty_session_id_rejected(self):
        """Test empty session_id is rejected."""
        with pytest.raises(ValidationError) as exc_info:
            SessionEndConfig(session_id="")

        assert "session_id" in str(exc_info.value).lower()

    def test_whitespace_session_id_stripped(self):
        """Test session_id whitespace is stripped."""
        config = SessionEndConfig(session_id="  sess-123  ")
        assert config.session_id == "sess-123"


class TestTrackNewConfig:
    """Test TrackNewConfig model validation."""

    def test_valid_config(self):
        """Test valid track creation config."""
        config = TrackNewConfig(
            title="Test Track",
            description="Track description",
            priority="high",
        )
        assert config.title == "Test Track"
        assert config.priority == "high"

    def test_empty_title_rejected(self):
        """Test empty title is rejected."""
        with pytest.raises(ValidationError) as exc_info:
            TrackNewConfig(title="")

        assert "title" in str(exc_info.value).lower()

    def test_invalid_priority_rejected(self):
        """Test invalid priority is rejected."""
        with pytest.raises(ValidationError) as exc_info:
            TrackNewConfig(title="Test", priority="invalid")

        assert "priority" in str(exc_info.value).lower()


class TestValidationHelpers:
    """Test validation helper functions."""

    def test_format_validation_error(self):
        """Test formatting of ValidationError for user output."""
        try:
            ServeConfig(port=99999, host="")
        except ValidationError as e:
            formatted = format_validation_error(e)
            assert "Validation error:" in formatted
            assert "port:" in formatted
            assert "host:" in formatted

    def test_validate_args_with_namespace(self):
        """Test validate_args with argparse Namespace."""
        from argparse import Namespace

        args = Namespace(port=8080, host="0.0.0.0", no_watch=False)
        config = validate_args(ServeConfig, args)

        assert config.port == 8080
        assert config.host == "0.0.0.0"

    def test_validate_args_with_dict(self):
        """Test validate_args with dict."""
        args_dict = {"port": 8000, "host": "127.0.0.1"}
        config = validate_args(ServeApiConfig, args_dict)

        assert config.port == 8000
        assert config.host == "127.0.0.1"

    def test_validate_args_filters_command_fields(self):
        """Test that command routing fields are filtered out."""
        from argparse import Namespace

        args = Namespace(
            port=8080,
            command="serve",
            func=lambda x: x,
            feature_command="list",
        )
        config = validate_args(ServeConfig, args)

        # Should not raise error about unexpected fields
        assert config.port == 8080


class TestEndToEndValidation:
    """Test end-to-end validation scenarios."""

    def test_serve_command_validation(self):
        """Test full serve command validation flow."""
        from argparse import Namespace

        # Simulate argparse output
        args = Namespace(
            port=8080,
            host="0.0.0.0",
            graph_dir=".htmlgraph",
            static_dir=".",
            no_watch=False,
            auto_port=False,
            command="serve",
        )

        # Validate through model
        config = validate_args(ServeConfig, args)
        assert config.port == 8080

    def test_feature_create_validation(self):
        """Test full feature create validation flow."""
        from argparse import Namespace

        args = Namespace(
            title="Test Feature",
            description="Description",
            priority="high",
            steps=3,
            collection="features",
            track=None,
            agent="claude",
        )

        config = validate_args(FeatureCreateConfig, args)
        assert config.title == "Test Feature"
        assert config.steps == 3
