"""htmpl project template generator."""

__version__ = "0.0.1"
