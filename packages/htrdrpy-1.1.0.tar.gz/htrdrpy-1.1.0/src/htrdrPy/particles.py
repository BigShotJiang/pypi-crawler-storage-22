import numpy as np
import scipy.constants as cst
from scipy.spatial import Delaunay

from htrdrPy.include.meshgen import *
from htrdrPy.include.meshvisual import *
from htrdrPy.include.write import *
from htrdrPy.include.read import *

from htrdrPy.data import Data
from htrdrPy.helperFunctions import *


class Particle:
    _count = 0

    def __init__(self, master: Data, dim, data, sameGrid, nTheta, nPhi):
        Particle._count += 1
        self.id = Particle._count
        self.master = master
        self.geometry = f'{master.inputPath}particle_{self.id}_Geometry.bin'
        self.opticalProperties = f'{master.inputPath}particleOpticalProperties_{self.id}.bin'
        self.phaseFunctionList = f'{master.inputPath}phaseFunctionList_{self.id}.txt'
        self.phaseFunctionFile = f'{master.inputPath}phaseFunction_{self.id}.bin'
        if nTheta is None:
            self.nTheta = master.nTheta
        else:
            self.nTheta = nTheta
        if nPhi is None:
            self.nPhi = master.nPhi
        else:
            self.nPhi = nPhi
        if dim == 0: self.__PP(data, sameGrid)
        if dim == 1: self.__from1D(data, sameGrid)
        if dim == 2: self.__from2D(data, sameGrid)
        if dim == 3: self.__from3D(data, sameGrid)
        return

    def __from1D(self, data, sameGrid):
        if sameGrid:
            self.nLevel = self.master.nLevel
            indices = self.master.indices
            self.wavelengths = self.master.wavelengths
            bandLow = self.master.atmosphere['bands low']
            bandUp = self.master.atmosphere['bands up']
            node_coord = self.master.atmosphere['nodes coordinates']
            cell_ids = self.master.atmosphere['cells ids']
        else:
            self.altitudes = data["altitude (m)"] + self.master.radius
            self.latitudes = np.linspace(-90, 90, self.nTheta, endpoint=False)
            self.longitudes = np.linspace(0, 360, self.nPhi, endpoint=False)
            self.nLevel = data["nLevel"]
            self.nWavelength = data["nWavelengths"]
            self.wavelengths = data["wavelength"] / cst.nano
            bandLow = np.array(data["band low"]) / cst.nano
            bandUp = np.array(data["band up"]) / cst.nano
            ##############################################################
            # generating the mesh
            node_coord,cell_ids = spherical_mesh_control_cell(self.nTheta,
                                                              self.nPhi,
                                                              self.altitudes)
            self.nNodes = len(node_coord)

            print("Assigning data to nodes ...")
            alt = np.linalg.norm(node_coord, axis=1)                # calculate corresponding altitude
            diffs = np.abs(self.altitudes[None, :] - alt[:, None])  # find the indices corresponding
            indices = np.argmin(diffs, axis=1)                      # to nodes altitudes altitude

        ##############################################################
        # writing the file containing the list of phase functions
        if "phaseFunc" in data.keys():
            angles = data["angles (°)"]
            with open(self.phaseFunctionList, 'w') as f:
                f.write(str(self.nLevel))
                for k in range(self.nLevel):
                    phaseFunctions = np.array(data["phaseFunc"][:,k,:]).T
                    arr = [angles, self.wavelengths, phaseFunctions]
                    fileName = f"{self.master.inputPath}phase_function_{self.id}_alt{k}.dat"
                    write_phase_function_decrete_dat(fileName, arr)
                    f.write(f"\n{fileName}")
        elif "asymmetry" in data.keys():
            with open(self.phaseFunctionList, 'w') as f:
                f.write(str(self.nLevel))
                for k in range(self.nLevel):
                    fileName = f"{self.master.inputPath}phase_function_{self.id}_alt{k}.dat"
                    writeHGphaseFunction(self.wavelengths, fileName, data["asymmetry"][:,k])
                    f.write(f"\n{fileName}")
        else: raise KeyError("phase function or asymmetry parameter not found in the data dictionnary")

        phaseFunctionsIndices = np.copy(indices)   # asigning phase function
        scatt = np.array(data["scattering (m-1)"]) # retrieving scattering coefficients
        scattering = scatt[:,indices]              # asigning scattering coefficients
        abso = np.array(data["absorption (m-1)"] ) # retrieving absorption coefficients
        absorption = abso[:,indices]               # asigning absorption coefficients

        ##############################################################
        self.nWavelength = len(self.wavelengths)
        self.nodesCoord = node_coord
        self.cellIds = cell_ids
        self.bandLow = bandLow
        self.bandUp = bandUp
        self.absorption = absorption
        self.scattering = scattering
        self.phaseFunctionsIndices = phaseFunctionsIndices
        return

    def __from2D(self, data, sameGrid):
        if sameGrid:
            self.nLevel = self.master.nLevel
            self.latitudes = self.master.latitudes
            self.wavelengths = self.master.wavelengths
            bandLow = self.master.atmosphere['bands low']
            bandUp = self.master.atmosphere['bands up']
            self.nNodes = self.master.nNodes
            node_coord = self.master.atmosphere['nodes coordinates']
            cell_ids = self.master.atmosphere['cells ids']
        else:
            nLevel = data["nLevel"]
            self.nLevel = nLevel
            self.nTheta = data["nLat"]
            self.nNodes = self.nLevel * self.nTheta * self.nPhi
            self.altitudes = data["altitude (m)"] + self.master.radius
            self.latitudes = data["latitude (°)"]
            self.longitudes = np.linspace(0, 360, self.nPhi, endpoint=False)
            self.nWavelength = data["nWavelengths"]
            self.wavelengths = data["wavelength"] / cst.nano
            bandLow = np.array(data["band low"]) / cst.nano
            bandUp = np.array(data["band up"]) / cst.nano
            ##############################################################
            # generating the mesh
            coords = np.zeros((self.nLevel, self.nTheta, self.nPhi, 3)) # shape=(nLevel, nLat, nPhi, 3)
            for i,j,k in np.ndindex(self.nLevel,self.nTheta,self.nPhi):
                coords[i,j,k] = np.array([self.altitudes[i,j],
                                          self.latitudes[j],
                                          self.longitudes[k]])
            coords = coords.reshape((self.nNodes,3))
            node_coord = np.array([sphere2cart(coords[i]) for i in range(self.nNodes)]) # shape=(nNodes, 3)
            cell_ids = Delaunay(node_coord).simplices

        self.nWavelength = len(self.wavelengths)

        ##############################################################
        phaseFunctionsIndices = - np.ones((self.nLevel, self.nTheta, self.nPhi))
        # writing the file containing the list of phase functions
        if "phaseFunc" in data.keys():
            angles = data["angles (°)"]
            count = 0
            with open(self.phaseFunctionList, 'w') as f:
                f.write(str(self.nLevel*self.nTheta))
                wavelength = np.array(data["wavelength"]) / cst.nano
                for k,j in np.ndindex(self.nLevel,self.nTheta):
                    phaseFunctions = np.array(data["phaseFunc"][:,k,j,:]).T
                    arr = [angles, wavelength, phaseFunctions]
                    fileName = f"{self.master.inputPath}phase_function_{self.id}_alt{k}_{j}.dat"
                    write_phase_function_decrete_dat(fileName, arr)
                    f.write(f"\n{fileName}")
                    phaseFunctionsIndices[k,j,:] = count
                    count += 1
        elif "asymmetry" in data.keys():
            count = 0
            with open(self.phaseFunctionList, 'w') as f:
                f.write(str(self.nLevel*self.nTheta))
                for k,j in np.ndindex(self.nLevel,self.nTheta):
                    fileName = f"{self.master.inputPath}phase_function_{self.id}_alt{k}_{j}.dat"
                    writeHGphaseFunction(self.wavelengths, fileName,
                                         data["asymmetry"][:,k,j])
                    f.write(f"\n{fileName}")
                    phaseFunctionsIndices[k,j,:] = count
                    count += 1
        else: raise KeyError("phase function or asymmetry parameter not found in the data dictionnary")

        phaseFunctionsIndices = phaseFunctionsIndices.reshape(self.nNodes).astype(int)

        if any(phaseFunctionsIndices == -1): raise ValueError("Wrong index for phase function: -1")

        scattering = np.tile(data["scattering (m-1)"][:,:,:,None],
                             (1,1,1,self.nPhi))   # shape=(nWavelengths, nLevel, nLat, nLon, nCoeff)
        absorption = np.tile(data["absorption (m-1)"][:,:,:,None],
                             (1,1,1,self.nPhi))   # shape=(nWavelengths, nLevel, nLat, nLon, nCoeff)
        scattering = scattering.reshape((self.nWavelength, self.nNodes))
        absorption = absorption.reshape((self.nWavelength, self.nNodes))

        ##############################################################
        self.nodesCoord = node_coord
        self.cellIds = cell_ids
        self.bandLow = bandLow
        self.bandUp = bandUp
        self.absorption = absorption
        self.scattering = scattering
        self.phaseFunctionsIndices = phaseFunctionsIndices
        return

    def __from3D(self, data, sameGrid):
        if sameGrid:
            self.nLevel = self.master.nLevel
            self.latitudes = self.master.latitudes
            self.longitudes = self.master.longitudes
            self.wavelengths = self.master.wavelengths
            bandLow = self.master.atmosphere['bands low']
            bandUp = self.master.atmosphere['bands up']
            self.nNodes = self.master.nNodes
            node_coord = self.master.atmosphere['nodes coordinates']
            cell_ids = self.master.atmosphere['cells ids']
        else:
            nLevel = data["nLevel"]
            self.nLevel = nLevel
            self.nTheta = data["nLat"]
            self.nPhi = data["nLon"]
            self.nNodes = self.nLevel * self.nTheta * self.nPhi
            self.altitudes = data["altitude (m)"] + self.master.radius
            self.latitudes = data["latitude (°)"]
            self.longitudes = data["longitude (°)"]
            self.nWavelength = data["nWavelengths"]
            self.wavelengths = data["wavelength"] / cst.nano
            bandLow = np.array(data["band low"]) / cst.nano
            bandUp = np.array(data["band up"]) / cst.nano
            ##############################################################
            # generating the mesh
            coords = np.zeros((self.nLevel, self.nTheta, self.nPhi, 3)) # shape=(nLevel, nLat, nPhi, 3)
            for i,j,k in np.ndindex(self.nLevel,self.nTheta,self.nPhi):
                coords[i,j,k] = np.array([self.altitudes[i,j,k],
                                          self.latitudes[j],
                                          self.longitudes[k]])
            coords = coords.reshape((self.nNodes,3))
            node_coord = np.array([sphere2cart(coords[i]) for i in range(self.nNodes)]) # shape=(nNodes, 3)
            cell_ids = Delaunay(node_coord).simplices

        self.nWavelength = len(self.wavelengths)

        ##############################################################
        phaseFunctionsIndices = - np.ones((self.nLevel, self.nTheta, self.nPhi))
        # writing the file containing the list of phase functions
        if "phaseFunc" in data.keys():
            angles = data["angles (°)"]
            count = 0
            with open(self.phaseFunctionList, 'w') as f:
                f.write(str(self.nLevel*self.nTheta*self.nPhi))
                wavelength = np.array(data["wavelength"]) / cst.nano
                for k,j,l in np.ndindex(self.nLevel,self.nTheta,self.nPhi):
                    phaseFunctions = np.array(data["phaseFunc"][:,k,j,l,:]).T
                    arr = [angles, wavelength, phaseFunctions]
                    fileName = f"{self.master.inputPath}phase_function_{self.id}_alt{k}_{j}_{l}.dat"
                    write_phase_function_decrete_dat(fileName, arr)
                    f.write(f"\n{fileName}")
                    phaseFunctionsIndices[k,j,l] = count
                    count += 1
        elif "asymmetry" in data.keys():
            count = 0
            with open(self.phaseFunctionList, 'w') as f:
                f.write(str(self.nLevel*self.nTheta*self.nPhi))
                for k,j,l in np.ndindex(self.nLevel,self.nTheta,self.nPhi):
                    fileName = f"{self.master.inputPath}phase_function_{self.id}_alt{k}_{j}_{l}.dat"
                    writeHGphaseFunction(self.wavelengths, fileName,
                                         data["asymmetry"][:,k,j,l])
                    f.write(f"\n{fileName}")
                    phaseFunctionsIndices[k,j,l] = count
                    count += 1
        else: raise KeyError("phase function or asymmetry parameter not found in the data dictionnary")

        phaseFunctionsIndices = phaseFunctionsIndices.reshape(self.nNodes).astype(int)

        if any(phaseFunctionsIndices == -1): raise ValueError("Wrong index for phase function: -1")

        scattering = data["scattering (m-1)"]
        absorption = data["absorption (m-1)"]
        scattering = scattering.reshape((self.nWavelength, self.nNodes))
        absorption = absorption.reshape((self.nWavelength, self.nNodes))

        ##############################################################
        self.nodesCoord = node_coord
        self.cellIds = cell_ids
        self.bandLow = bandLow
        self.bandUp = bandUp
        self.absorption = absorption
        self.scattering = scattering
        self.phaseFunctionsIndices = phaseFunctionsIndices
        return

    def __PP(self, data, sameGrid):
        if sameGrid:
            self.nLevel = self.master.nLevel
            indices = self.master.indices
            self.wavelengths = self.master.wavelengths
            bandLow = self.master.atmosphere['bands low']
            bandUp = self.master.atmosphere['bands up']
            node_coord = self.master.atmosphere['nodes coordinates']
            cell_ids = self.master.atmosphere['cells ids']
        else:
            self.altitudes = data["altitude (m)"] + self.master.radius
            self.latitudes = np.linspace(-90, 90, self.nTheta, endpoint=False)
            self.longitudes = np.linspace(0, 360, self.nPhi, endpoint=False)
            self.nLevel = data["nLevel"]
            self.nWavelength = data["nWavelengths"]
            self.wavelengths = data["wavelength"] / cst.nano
            bandLow = np.array(data["band low"]) / cst.nano
            bandUp = np.array(data["band up"]) / cst.nano
            ##############################################################
            # generating the mesh
            node_coord,cell_ids = plan_atm_mesh(altitude, self.radius, self.radius)
            self.nNodes = len(node_coord)

            print("Assigning data to nodes ...")
            alt = node_coord[:,0]                               # calculate corresponding altitude
            diffs = np.abs(self.altitude[None, :] - alt[:, None])    # find the indices corresponding
            indices = np.argmin(diffs, axis=1)                  # to nodes altitudes altitude

        ##############################################################
        # writing the file containing the list of phase functions
        if "phaseFunc" in data.keys():
            angles = data["angles (°)"]
            with open(self.phaseFunctionList, 'w') as f:
                f.write(str(self.nLevel))
                for k in range(self.nLevel):
                    phaseFunctions = np.array(data["phaseFunc"][:,k,:]).T
                    arr = [angles, self.wavelengths, phaseFunctions]
                    fileName = f"{self.master.inputPath}phase_function_{self.id}_alt{k}.dat"
                    write_phase_function_decrete_dat(fileName, arr)
                    f.write(f"\n{fileName}")
        elif "asymmetry" in data.keys():
            with open(self.phaseFunctionList, 'w') as f:
                f.write(str(self.nLevel))
                for k in range(self.nLevel):
                    fileName = f"{self.master.inputPath}phase_function_{self.id}_alt{k}.dat"
                    writeHGphaseFunction(self.wavelengths, fileName, data["asymmetry"][:,k])
                    f.write(f"\n{fileName}")
        else: raise KeyError("phase function or asymmetry parameter not found in the data dictionnary")

        phaseFunctionsIndices = np.copy(indices)   # asigning phase function
        scatt = np.array(data["scattering (m-1)"]) # retrieving scattering coefficients
        scattering = scatt[:,indices]              # asigning scattering coefficients
        abso = np.array(data["absorption (m-1)"] ) # retrieving absorption coefficients
        absorption = abso[:,indices]               # asigning absorption coefficients

        ##############################################################
        self.nWavelength = len(self.wavelengths)
        self.nodesCoord = node_coord
        self.cellIds = cell_ids
        self.bandLow = bandLow
        self.bandUp = bandUp
        self.absorption = absorption
        self.scattering = scattering
        self.phaseFunctionsIndices = phaseFunctionsIndices
        return

    def writeInputs(self):
        print(f'generating haze_{self.id} mesh bin file...')
        write_binary_file_grid(self.geometry, 4096,
                               self.nodesCoord,
                               self.cellIds)
        print('bin generation completed.')

        print('generating haze properties bin file...')
        write_binary_file_k_haze(self.opticalProperties,4096,
                                 self.bandLow,
                                 self.bandUp,
                                 self.absorption,
                                 self.scattering)
        print('bin generation completed.')

        print('generating haze phase function bin file...')
        write_binary_file_phase_function_het(self.phaseFunctionFile,4096,
                                             self.phaseFunctionsIndices)
        print('bin generation completed.')
        return

    def writeVTK(self):
        self.geometryVTK = f'{self.master.vtkPath}particle_{self.id}_Geometry.vtk'
        self.absorptionVTK = [f'{self.master.vtkPath}absorption_Particle_{self.id}_{i}.vtk'
                              for i in range(self.nWavelength)]
        self.scatteringVTK = [f'{self.master.vtkPath}scattering_Particle_{self.id}_{i}.vtk'
                              for i in range(self.nWavelength)]

        print("generating Atmosphere geometry VTK file ...")
        write_vtk_tetr(self.nodesCoord, self.cellIds, self.geometryVTK)
        print("VTK file written.")

        print("generating Scattering and Absorption properties VTK file ...")
        for i in range(self.nWavelength):
            attach_values_to_nodes(self.geometryVTK,
                                   self.scattering[i,:],
                                   self.scatteringVTK[i])
            attach_values_to_nodes(self.geometryVTK, 
                                   self.absorption[i,:],
                                   self.absorptionVTK[i])
        print("VTK file written.")
        return

