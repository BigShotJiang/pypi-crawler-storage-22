from playwright.sync_api import sync_playwright, Page
from playwright._impl._errors import TimeoutError as PlaywrightTimeoutError


PRESETS = {
    # For sites checking User-Agent (no extra wait)
    'stealth': {
        'user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'viewport': (1920, 1080),
        'extra_wait': 0,
    },
    # For Cloudflare-protected sites (needs JS challenge time)
    'cloudflare': {
        'user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'viewport': (1920, 1080),
        'extra_wait': 5.0,
    },
}


def fetch_html(
    url: str,
    wait_until: str = "auto",
    timeout: int = 30000,
    wait_for: str | None = None,
    preset: str | None = None,
    user_agent: str | None = None,
    viewport: tuple[int, int] | None = None,
    extra_wait: float = 0,
) -> str:
    """
    Fetches the raw HTML content of a URL using Playwright.

    Args:
        url: The URL to fetch.
        wait_until: Wait strategy. Options:
            - 'auto': Combined strategy (networkidle with fallback) - DEFAULT
            - 'load', 'domcontentloaded', 'networkidle', 'commit': Playwright built-in
        timeout: Maximum time to wait in milliseconds (default 30s).
        wait_for: Optional CSS selector to wait for before extracting content.
        preset: Preset config name ('cloudflare', 'stealth'). Explicit params override preset.
        user_agent: Custom User-Agent string.
        viewport: Custom viewport as (width, height) tuple.
        extra_wait: Additional wait time in seconds after page load.
    """
    # Apply preset defaults
    if preset and preset in PRESETS:
        p = PRESETS[preset]
        user_agent = user_agent or p.get('user_agent')
        viewport = viewport or p.get('viewport')
        extra_wait = extra_wait or p.get('extra_wait', 0)

    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=True)

        # Build context options
        context_opts = {}
        if user_agent:
            context_opts['user_agent'] = user_agent
        if viewport:
            context_opts['viewport'] = {'width': viewport[0], 'height': viewport[1]}

        context = browser.new_context(**context_opts)
        page = context.new_page()

        _navigate_and_wait(page, url, wait_until, timeout, wait_for)

        # Extra wait for anti-bot systems
        if extra_wait > 0:
            page.wait_for_timeout(int(extra_wait * 1000))

        html = page.content()
        browser.close()
        return html


def fetch_html_and_links(
    url: str,
    wait_until: str = "auto",
    timeout: int = 30000,
    wait_for: str | None = None,
    preset: str | None = None,
    user_agent: str | None = None,
    viewport: tuple[int, int] | None = None,
    extra_wait: float = 0,
) -> tuple[str, list[str]]:
    """
    Fetches HTML and extracts links from the RENDERED DOM (after JavaScript execution).

    Args:
        url: The URL to fetch.
        wait_until: Wait strategy ('auto', 'load', 'domcontentloaded', 'networkidle', 'commit').
        timeout: Maximum time to wait in milliseconds (default 30s).
        wait_for: Optional CSS selector to wait for.
        preset: Preset config name ('cloudflare', 'stealth'). Explicit params override preset.
        user_agent: Custom User-Agent string.
        viewport: Custom viewport as (width, height) tuple.
        extra_wait: Additional wait time in seconds after page load.

    Returns:
        Tuple of (html_content, list_of_absolute_urls)
    """
    # Apply preset defaults
    if preset and preset in PRESETS:
        p = PRESETS[preset]
        user_agent = user_agent or p.get('user_agent')
        viewport = viewport or p.get('viewport')
        extra_wait = extra_wait or p.get('extra_wait', 0)

    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=True)

        # Build context options
        context_opts = {}
        if user_agent:
            context_opts['user_agent'] = user_agent
        if viewport:
            context_opts['viewport'] = {'width': viewport[0], 'height': viewport[1]}

        context = browser.new_context(**context_opts)
        page = context.new_page()

        _navigate_and_wait(page, url, wait_until, timeout, wait_for)

        # Extra wait for anti-bot systems
        if extra_wait > 0:
            page.wait_for_timeout(int(extra_wait * 1000))
        
        # Auto-scroll to bottom to trigger lazy loading
        try:
            page.evaluate("""async () => {
                await new Promise((resolve) => {
                    let totalHeight = 0;
                    const distance = 100;
                    const timer = setInterval(() => {
                        const scrollHeight = document.body.scrollHeight;
                        window.scrollBy(0, distance);
                        totalHeight += distance;
                        if(totalHeight >= scrollHeight){
                            clearInterval(timer);
                            resolve();
                        }
                    }, 100);
                });
            }""")
            # Wait a bit after scrolling for final content to settle
            page.wait_for_timeout(1000)
        except Exception:
            # Ignore scrolling errors
            pass
        
        html = page.content()
        
        # Extract links from rendered DOM using JavaScript
        links = page.evaluate("""() => {
            const links = [];
            const anchors = document.querySelectorAll('a[href]');
            anchors.forEach(a => {
                const href = a.href;  // This gives absolute URL
                if (href && !href.startsWith('javascript:') && !href.startsWith('mailto:') && !href.startsWith('tel:')) {
                    links.push(href);
                }
            });
            return [...new Set(links)];  // Remove duplicates
        }""")
        
        browser.close()
        return html, links


def _navigate_and_wait(page: Page, url: str, wait_until: str, timeout: int, wait_for: str | None) -> None:
    """Navigate to URL and wait according to strategy."""
    if wait_until == "auto":
        try:
            page.goto(url, wait_until="networkidle", timeout=timeout)
        except PlaywrightTimeoutError:
            # If networkidle times out, we already have content loaded
            pass
    else:
        page.goto(url, wait_until=wait_until, timeout=timeout)
    
    if wait_for:
        page.wait_for_selector(wait_for, timeout=timeout)
