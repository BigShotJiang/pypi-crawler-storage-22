"""
Tests for CLI crawler functionality (sync and async modes).

Usage:
    pytest tests/test_cli_crawler.py -v -s
    pytest tests/test_cli_crawler.py -m "not slow" -v  # skip slow tests
"""

import asyncio
import os
import subprocess
import sys
import pytest
from unittest.mock import Mock, patch, AsyncMock

from http2md.crawler import fetch_html
from http2md.crawler_site import crawl_site, normalize_url, url_to_filename
from http2md.crawler_async import crawl_site_async


# --- Fixtures ---

@pytest.fixture
def tmp_outdir(tmp_path):
    """Temporary output directory."""
    return str(tmp_path)


@pytest.fixture
def mock_html():
    """Sample HTML content."""
    return """
    <!DOCTYPE html>
    <html>
    <head><title>Test Page</title></head>
    <body>
        <h1>Hello World</h1>
        <p>Test content.</p>
        <a href="/page2">Link 1</a>
        <a href="/page3">Link 2</a>
    </body>
    </html>
    """


@pytest.fixture
def mock_fetch(mock_html):
    """Mock fetch_html_and_links."""
    with patch('http2md.crawler_site.fetch_html_and_links') as mock:
        mock.return_value = (mock_html, ['https://example.com/page2', 'https://example.com/page3'])
        yield mock


@pytest.fixture
def mock_async_crawler(mock_html):
    """Mock AsyncCrawler.fetch_page."""
    with patch('http2md.crawler_async.AsyncCrawler.fetch_page', new_callable=AsyncMock) as mock:
        mock.return_value = (mock_html, ['https://example.com/page2', 'https://example.com/page3'])
        yield mock


@pytest.fixture
def progress_events():
    """Capture progress callback events."""
    events = []

    def callback(url, status, current, total, html, markdown):
        events.append({'url': url, 'status': status, 'current': current, 'total': total})

    return events, callback


# --- URL Normalization Tests ---

def test_normalize_url_removes_fragment():
    assert normalize_url("https://example.com/page#section") == "https://example.com/page"


def test_normalize_url_removes_trailing_slash():
    assert normalize_url("https://example.com/page/") == "https://example.com/page"


def test_normalize_url_preserves_root():
    assert normalize_url("https://example.com/") == "https://example.com/"


def test_normalize_url_preserves_query():
    assert normalize_url("https://example.com/page?foo=bar") == "https://example.com/page?foo=bar"


# --- URL to Filename Tests ---

def test_url_to_filename_root():
    assert url_to_filename("https://example.com/", "https://example.com/") == "index.md"


def test_url_to_filename_simple_path():
    assert url_to_filename("https://example.com/about", "https://example.com/") == "about.md"


def test_url_to_filename_nested_path():
    assert url_to_filename("https://example.com/docs/api/v1", "https://example.com/") == "docs_api_v1.md"


# --- Sync Crawl Tests (Mocked) ---

def test_crawl_site_depth_0_mocked(mock_fetch, tmp_outdir):
    """Crawl single page with mocked fetch."""
    results = crawl_site("https://example.com", depth=0, outdir=tmp_outdir)

    assert len(results) == 1
    assert results[0]['status'] == 'success'
    assert 'Hello World' in results[0]['content']
    assert os.path.exists(os.path.join(tmp_outdir, 'index.md'))


def test_crawl_site_depth_1_mocked(mock_fetch, tmp_outdir):
    """Crawl with depth=1, should follow links."""
    results = crawl_site("https://example.com", depth=1, outdir=tmp_outdir)

    # Start page + 2 linked pages
    assert len(results) == 3
    assert mock_fetch.call_count == 3


def test_crawl_site_same_domain_filter(mock_fetch):
    """Test same_domain filter."""
    mock_fetch.return_value = ("<html></html>", [
        'https://example.com/internal',
        'https://other.com/external',
    ])

    results = crawl_site("https://example.com", depth=1, same_domain=True)

    # Should only crawl example.com pages
    urls = [r['url'] for r in results]
    assert 'https://other.com/external' not in urls


def test_crawl_site_callback(mock_fetch, progress_events):
    """Test progress callback."""
    events, callback = progress_events

    crawl_site("https://example.com", depth=0, callback=callback)

    assert len(events) >= 2
    assert any(e['status'] == 'fetching' for e in events)
    assert any(e['status'] == 'done' for e in events)


def test_crawl_site_html_output(mock_fetch):
    """Test HTML output mode."""
    results = crawl_site("https://example.com", depth=0, output_html=True)

    assert '<html>' in results[0]['content'].lower()


def test_crawl_site_markdown_output(mock_fetch):
    """Test Markdown output mode."""
    results = crawl_site("https://example.com", depth=0, output_html=False)

    # Markdown should contain text but not HTML tags
    assert 'Hello World' in results[0]['content']
    assert '<html>' not in results[0]['content'].lower()


# --- Async Crawl Tests (Mocked) ---

def test_async_crawl_depth_0_mocked(mock_async_crawler, tmp_outdir):
    """Async crawl single page."""
    results = asyncio.run(crawl_site_async(
        "https://example.com", depth=0, outdir=tmp_outdir, jobs=1
    ))

    assert len(results) == 1
    assert results[0]['status'] == 'success'


def test_async_crawl_multiple_jobs(mock_async_crawler):
    """Test async with multiple concurrent jobs."""
    results = asyncio.run(crawl_site_async(
        "https://example.com", depth=0, jobs=5
    ))

    assert len(results) == 1
    assert results[0]['status'] == 'success'


def test_async_crawl_html_output(mock_async_crawler):
    """Test async HTML output mode."""
    results = asyncio.run(crawl_site_async(
        "https://example.com", depth=0, output_html=True, jobs=1
    ))

    assert '<html>' in results[0]['content'].lower()


# --- Real Network Tests ---

@pytest.fixture
def real_url():
    """Stable test URL."""
    return "https://example.com"


@pytest.mark.network
def test_fetch_html_real(real_url):
    """Fetch real page."""
    html = fetch_html(real_url)

    assert len(html) > 100
    assert "<html" in html.lower()
    assert "example" in html.lower()


@pytest.mark.network
def test_fetch_html_with_preset(real_url):
    """Fetch with stealth preset."""
    html = fetch_html(real_url, preset='stealth')

    assert len(html) > 100


@pytest.mark.network
def test_crawl_site_real(real_url, tmp_outdir):
    """Real sync crawl."""
    results = crawl_site(real_url, depth=0, outdir=tmp_outdir)

    assert len(results) == 1
    assert results[0]['status'] == 'success'
    assert os.listdir(tmp_outdir)


@pytest.mark.network
def test_async_crawl_real(real_url, tmp_outdir):
    """Real async crawl."""
    results = asyncio.run(crawl_site_async(
        real_url, depth=0, outdir=tmp_outdir, jobs=1
    ))

    assert len(results) == 1
    assert results[0]['status'] == 'success'


@pytest.mark.network
def test_sync_vs_async_same_results(real_url):
    """Sync and async produce same results."""
    sync_results = crawl_site(real_url, depth=0)
    async_results = asyncio.run(crawl_site_async(real_url, depth=0, jobs=1))

    assert len(sync_results) == len(async_results)
    assert sync_results[0]['status'] == async_results[0]['status']


# --- CLI Tests ---

@pytest.mark.network
def test_cli_single_page(real_url):
    """CLI single page fetch."""
    result = subprocess.run(
        [sys.executable, "-m", "http2md.cli", real_url],
        capture_output=True, text=True, timeout=30
    )

    assert result.returncode == 0
    assert "example" in result.stdout.lower()


@pytest.mark.network
def test_cli_html_flag(real_url):
    """CLI with --html flag."""
    result = subprocess.run(
        [sys.executable, "-m", "http2md.cli", real_url, "--html"],
        capture_output=True, text=True, timeout=30
    )

    assert result.returncode == 0
    assert "<html" in result.stdout.lower()


@pytest.mark.network
def test_cli_crawl_sync(real_url, tmp_outdir):
    """CLI sync crawl."""
    result = subprocess.run(
        [sys.executable, "-m", "http2md.cli", real_url, "--depth", "0", "--outdir", tmp_outdir, "-q"],
        capture_output=True, text=True, timeout=30
    )

    assert result.returncode == 0
    assert "Crawled 1/1" in result.stdout
    assert os.listdir(tmp_outdir)


@pytest.mark.network
def test_cli_crawl_async(real_url, tmp_outdir):
    """CLI async crawl."""
    result = subprocess.run(
        [sys.executable, "-m", "http2md.cli", "async", real_url, "--depth", "0", "--outdir", tmp_outdir, "-q"],
        capture_output=True, text=True, timeout=30
    )

    assert result.returncode == 0
    assert "Async crawled 1/1" in result.stdout


@pytest.mark.network
def test_cli_async_with_jobs(real_url, tmp_outdir):
    """CLI async with -j flag."""
    result = subprocess.run(
        [sys.executable, "-m", "http2md.cli", "async", real_url, "--depth", "0", "-j", "3", "--outdir", tmp_outdir, "-q"],
        capture_output=True, text=True, timeout=30
    )

    assert result.returncode == 0
    assert "Async crawled" in result.stdout


# --- Slow Tests ---

@pytest.mark.slow
@pytest.mark.network
def test_crawl_httpbin_sync():
    """Crawl httpbin.org (multiple pages)."""
    results = crawl_site("https://httpbin.org", depth=1, same_domain=True)

    success = sum(1 for r in results if r['status'] == 'success')
    assert success >= 1


@pytest.mark.slow
@pytest.mark.network
def test_crawl_httpbin_async():
    """Async crawl httpbin.org."""
    results = asyncio.run(crawl_site_async(
        "https://httpbin.org", depth=1, jobs=3, same_domain=True
    ))

    success = sum(1 for r in results if r['status'] == 'success')
    assert success >= 1


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
