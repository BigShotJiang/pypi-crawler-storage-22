from httpfpt.enums import StrEnum


class QueryFetchType(StrEnum):
    ONE = 'one'
    ALL = 'all'
