from httpfpt.enums import StrEnum


class EnginType(StrEnum):
    requests = 'requests'
    httpx = 'httpx'
