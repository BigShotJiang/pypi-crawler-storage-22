from httplint.field.list_field import HttpListField
from httplint.field.tests import FieldTest
from httplint.note import categories
from httplint.syntax import rfc9110
from httplint.types import AddNoteMethodType


class authentication_info(HttpListField):
    canonical_name = "Authentication-Info"
    description = """\
The `Authentication-Info` header field is used to communicate information after 
the client's authentication credentials have been accepted."""
    reference = f"{rfc9110.SPEC_URL}#field.authentication-info"
    syntax = rfc9110.Authentication_Info
    category = categories.SECURITY
    deprecated = False
    valid_in_requests = False
    valid_in_responses = True

    def evaluate(self, add_note: AddNoteMethodType) -> None:
        pass


class AuthenticationInfoTest(FieldTest):
    name = "Authentication-Info"
    inputs = [
        b'nextnonce="5Yg8-VL198_7ulNinj-Vfs4567-32n3-84333", '
        b'qop="auth", '
        b'rspauth="6629fae49393a05397450978507c4ef1", '
        b'cnonce="0a4f113b", '
        b"nc=00000001"
    ]
    expected_out = [
        'nextnonce="5Yg8-VL198_7ulNinj-Vfs4567-32n3-84333"',
        'qop="auth"',
        'rspauth="6629fae49393a05397450978507c4ef1"',
        'cnonce="0a4f113b"',
        "nc=00000001",
    ]
