from typing import Tuple

from httplint.field.singleton_field import SingletonField
from httplint.field.tests import FieldTest
from httplint.syntax import rfc9110
from httplint.types import AddNoteMethodType, ParamDictType
from httplint.field.utils import parse_params


class content_type(SingletonField):
    canonical_name = "Content-Type"
    description = """\
The `Content-Type` header indicates the media type of the content sent to the recipient or, in the
case of responses to the HEAD method, the media type that would have been sent had the request been
a GET."""
    reference = f"{rfc9110.SPEC_URL}#field.content-type"
    syntax = rfc9110.Content_Type
    deprecated = False
    valid_in_requests = True
    valid_in_responses = True

    def parse(self, field_value: str, add_note: AddNoteMethodType) -> Tuple[str, ParamDictType]:
        try:
            media_type, param_str = field_value.split(";", 1)
        except ValueError:
            media_type, param_str = field_value, ""
        media_type = media_type.lower()
        param_dict = parse_params(param_str, add_note, ["charset"])
        return media_type, param_dict


class BasicCTTest(FieldTest):
    name = "Content-Type"
    inputs = [b"text/plain; charset=utf-8"]
    expected_out = ("text/plain", {"charset": "utf-8"})
