import time

import jwt
from cryptography.hazmat.primitives import serialization

TOKEN_LIFETIME_SECONDS = 60


def create_auth_token(agent_id: str, private_key: str, gateway_url: str) -> str:
    algorithm = _detect_algorithm(private_key)

    now = int(time.time())
    payload = {
        "sub": agent_id,
        "iss": agent_id,
        "aud": gateway_url,
        "iat": now,
        "exp": now + TOKEN_LIFETIME_SECONDS,
    }

    token: str = jwt.encode(payload, private_key, algorithm=algorithm)
    return token


def _detect_algorithm(private_key: str) -> str:
    try:
        key = serialization.load_pem_private_key(private_key.encode(), password=None)
        from cryptography.hazmat.primitives.asymmetric import ec

        if isinstance(key, ec.EllipticCurvePrivateKey):
            return "ES256"
    except Exception:
        pass
    return "RS256"
