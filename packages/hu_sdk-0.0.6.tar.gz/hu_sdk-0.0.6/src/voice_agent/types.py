"""
Type definitions for the Voice Agent SDK.

This module contains all Pydantic models, enums, and type aliases
used throughout the SDK.
"""

import sys
from datetime import datetime
from enum import Enum
from typing import Any, Awaitable, Callable, Protocol

from pydantic import BaseModel, Field

if sys.version_info >= (3, 11):
    from enum import StrEnum
else:
    class StrEnum(str, Enum):
        pass


class Tier(StrEnum):
    """
    Data access tiers for agent routing.

    Determines what data an agent receives when matched.
    """

    FULL = "full"
    """Agent receives all utterances with full context."""

    FILTERED = "filtered"
    """Agent receives matching utterances plus context window."""

    SUMMARY = "summary"
    """Agent receives only entities and topics (no text/context)."""


class MessageType(StrEnum):
    """
    Message types used in the Voice Gateway protocol.

    These define all possible message types exchanged between agents and the gateway.
    """

    UTTERANCE = "utterance"
    """User speech transcription from the gateway."""

    RESPONSE = "response"
    """Complete response (non-streaming)."""

    RESPONSE_DELTA = "response.text.delta"
    """Streaming response chunk."""

    RESPONSE_DONE = "response.text.done"
    """End of streaming response."""

    SESSION_START = "session_start"
    """Session started event."""

    SESSION_END = "session_end"
    """Session ended event."""

    AGENT_STATUS = "agent_status"
    """Agent status update."""

    ERROR = "error"
    """Error message."""

    INTERRUPT = "interrupt"
    """Interrupt signal (user started speaking, lost arbitration, etc.)."""

    FRAME_REQUEST = "frame_request"
    """Request video frames from the session."""

    FRAME_RESPONSE = "frame_response"
    """Response containing video frames."""

    MEMORY_QUERY = "memory_query"
    """Query user memory/facts."""

    MEMORY_RESPONSE = "memory_response"
    """Response containing memory facts."""

    SESSION_QUERY = "session_query"
    """Query session messages (current conversation)."""

    SESSION_RESPONSE = "session_response"
    """Response containing session messages."""

    FILTER_UPDATE = "filter_update"
    """Update agent's routing filters."""


class ConnectionMode(StrEnum):
    """Connection modes supported by the SDK."""

    WEBSOCKET = "websocket"
    """WebSocket connection (recommended) - full-duplex, lower latency."""

    SSE = "sse"
    """Server-Sent Events with HTTP POST for sending - works in browsers."""


class UserInfo(BaseModel):
    """
    User information provided to agents with appropriate scopes.

    Requires `profile`, `email`, or `location` scope.
    """

    name: str | None = None
    """User's display name (requires `profile` scope)."""

    email: str | None = None
    """User's email address (requires `email` scope)."""

    ip: str | None = None
    """User's IP address (requires `location` scope)."""


class VisionContext(BaseModel):
    """
    Vision context automatically analyzed from the user's video feed.

    Requires `vision` scope.
    """

    description: str | None = None
    """Natural language description of what's visible."""

    timestamp: int | None = None
    """Unix timestamp (ms) when the analysis was performed."""

    available: bool
    """Whether vision data is available for this utterance."""


class EntityInfo(BaseModel):
    """An extracted entity from the user's speech (NER result)."""

    text: str
    """The entity text (e.g., "John", "New York")."""

    type: str
    """The entity type (e.g., "PERSON", "LOCATION", "ORG")."""


class ContextUtterance(BaseModel):
    """A previous utterance included for context."""

    speaker: str
    """Who spoke: "user" or "agent:<agent_id>"."""

    text: str
    """The utterance text."""

    entities: list[EntityInfo] | None = None
    """Entities extracted from this utterance."""

    topics: list[str] | None = None
    """Topics detected in this utterance."""


class UtterancePayload(BaseModel):
    """Payload for utterance messages from the gateway."""

    text: str
    """The transcribed text from the user."""

    is_final: bool
    """Whether this is a final transcript (vs. interim/partial)."""

    user: UserInfo | None = None
    """User information (if scopes granted)."""

    vision: VisionContext | None = None
    """Vision context (if vision scope granted and video available)."""

    entities: list[EntityInfo] | None = None
    """Entities extracted from the utterance (NER)."""

    topics: list[str] | None = None
    """Topics detected in the utterance."""

    context: list[ContextUtterance] | None = None
    """Previous utterances for context (if IncludeContext filter is set)."""


class ResponseDeltaPayload(BaseModel):
    """Payload for streaming response delta messages."""

    delta: str
    """The text chunk to append."""

    from_agent: str | None = None
    """Agent that generated this delta."""


class ResponseDonePayload(BaseModel):
    """Payload for response done messages (end of stream)."""

    text: str
    """The complete response text."""

    from_agent: str | None = None
    """Agent that generated this response."""


class ResponsePayload(BaseModel):
    """Payload for complete (non-streaming) response messages."""

    text: str
    """The complete response text."""

    from_agent: str | None = None
    """Agent that generated this response."""


class InterruptPayload(BaseModel):
    """Payload for interrupt messages."""

    reason: str
    """Reason for the interrupt: "new_user_speech", "lost_arbitration", or "supersede"."""


class SessionStartPayload(BaseModel):
    """Payload for session start messages."""

    user: UserInfo | None = None
    """User information (if available)."""

    scopes: list[str] | None = None
    """Scopes granted for this session."""


class SessionEndPayload(BaseModel):
    """Payload for session end messages."""

    reason: str | None = None
    """Reason for session ending."""


class FrameRequestPayload(BaseModel):
    """Payload for frame request messages sent to the gateway."""

    start_time: int | None = None
    """Start of time range (Unix ms)."""

    end_time: int | None = None
    """End of time range (Unix ms)."""

    limit: int | None = None
    """Maximum number of frames to return."""

    raw_base64: bool | None = None
    """If true, return raw base64 image data instead of descriptions."""


class FrameData(BaseModel):
    """A single video frame with timestamp and optional image data."""

    timestamp: int
    """Unix timestamp (ms) when frame was captured."""

    base64: str | None = None
    """Base64-encoded image data (if raw_base64 was requested)."""


class FrameResponsePayload(BaseModel):
    """Response payload containing video frames or descriptions."""

    frames: list[FrameData] | None = None
    """Raw frame data (if raw_base64 was true)."""

    descriptions: list[str] | None = None
    """Natural language descriptions of frames (if raw_base64 was false)."""

    error: str | None = None
    """Error message if the request failed."""


class MemoryQueryPayload(BaseModel):
    """Payload for memory query messages sent to the gateway."""

    query: str
    """Natural language query to search for."""

    top_k: int | None = None
    """Maximum number of facts to return."""

    threshold: float | None = None
    """Minimum similarity threshold (0-1)."""

    types: list[str] | None = None
    """Filter by fact types (e.g., ["preference", "fact"])."""


class MemoryFact(BaseModel):
    """A single fact retrieved from user memory."""

    id: str
    """Unique identifier for this fact."""

    type: str
    """Type of fact (e.g., "preference", "fact", "event")."""

    content: str
    """The fact content."""

    score: float
    """Similarity score to the query (0-1)."""

    confidence: float
    """Confidence score for this fact (0-1)."""

    source_id: str | None = None
    """Source identifier (e.g., session ID where fact was learned)."""

    citation: str | None = None
    """Human-readable citation."""

    metadata: dict[str, str] | None = None
    """Additional metadata."""


class MemoryResponsePayload(BaseModel):
    """Response payload containing memory query results."""

    facts: list[MemoryFact] | None = None
    """Retrieved facts matching the query."""

    total_found: int
    """Total number of facts found (may be more than returned)."""

    query_time_ms: int
    """Time taken to execute the query (ms)."""

    error: str | None = None
    """Error message if the request failed."""


class SessionQueryPayload(BaseModel):
    """
    Payload for session query messages sent to the gateway.

    Retrieves messages from the current conversation session.
    """

    limit: int | None = None
    """Maximum number of recent messages to return."""


class SessionMessageData(BaseModel):
    """A single message from the session history."""

    role: str
    """Role of the message sender ("user" or "assistant")."""

    content: str
    """The message content."""

    timestamp: int
    """Unix timestamp when the message was sent."""

    metadata: dict[str, str] | None = None
    """Additional metadata about the message."""


class SessionResponsePayload(BaseModel):
    """Response payload containing session messages."""

    messages: list[SessionMessageData] | None = None
    """Messages from the session (most recent last)."""

    total_count: int
    """Total number of messages in the session."""

    error: str | None = None
    """Error message if the request failed."""


class GatewayMessage(BaseModel):
    """Message received from the Voice Gateway."""

    type: MessageType
    """The type of message."""

    request_id: str
    """Unique identifier for this request."""

    session_id: str
    """Session identifier."""

    agent_id: str | None = None
    """Agent identifier (if applicable)."""

    user_id: str | None = None
    """User identifier (if applicable)."""

    room_id: str | None = None
    """Room identifier (if applicable)."""

    timestamp: str
    """ISO 8601 timestamp."""

    payload: Any
    """Message-specific payload."""


class AgentEvent(BaseModel):
    """Event sent from agent to the gateway."""

    type: str | MessageType
    """Message type."""

    session_id: str
    """Session ID."""

    request_id: str
    """Request ID (must match the utterance request_id for responses)."""

    timestamp: str
    """ISO 8601 timestamp."""

    agent_id: str | None = None
    """Agent ID (optional, usually set by the connection)."""

    payload: Any | None = None
    """Message-specific payload."""

    model_config = {"use_enum_values": True}


class FrameRequestOptions(BaseModel):
    """Options for requesting video frames."""

    start_time: int | None = None
    """Start of time range (Unix ms). Default: 30 seconds ago."""

    end_time: int | None = None
    """End of time range (Unix ms). Default: now."""

    limit: int | None = None
    """Maximum number of frames. Default: 5."""

    raw_base64: bool | None = None
    """If true, return raw base64 images. Default: false (returns descriptions)."""


class MemoryQueryOptions(BaseModel):
    """Options for querying user memory."""

    query: str
    """Natural language query to search for."""

    top_k: int | None = None
    """Maximum number of facts to return. Default: 10."""

    threshold: float | None = None
    """Minimum similarity threshold (0-1). Default: 0.5."""

    types: list[str] | None = None
    """Filter by fact types."""


class SessionQueryOptions(BaseModel):
    """Options for querying session messages."""

    limit: int | None = None
    """Maximum number of recent messages to return. Default: all messages."""


class FilterUpdatePayload(BaseModel):
    """
    Payload for filter update messages sent to the gateway.

    Configures which utterances should be routed to this agent.
    """

    entities: list[str] | None = None
    """Entity types or values to match (e.g., ["PERSON", "John"])."""

    topics: list[str] | None = None
    """Topics to match (e.g., ["weather", "travel"])."""

    keywords: list[str] | None = None
    """Keywords to match in the utterance text."""

    speakers: list[str] | None = None
    """Speaker types to match (e.g., ["user"])."""

    include_context: int | None = None
    """Number of previous utterances to include for context (used with "filtered" tier)."""

    tier: Tier | None = None
    """Data access tier: "full" (everything), "filtered" (matching + context), "summary" (entities/topics only)."""


class VoiceAgentConfig(BaseModel):
    """Configuration options for the VoiceAgent."""

    agent_id: str
    """Agent ID for authentication."""

    private_key: str
    """Private key (PEM format) for signing authentication JWTs."""

    gateway_url: str
    """Gateway URL (WebSocket or HTTP endpoint)."""

    mode: ConnectionMode = ConnectionMode.WEBSOCKET
    """Connection mode: WEBSOCKET (default) or SSE."""

    reconnect: bool = True
    """Whether to automatically reconnect on disconnect."""

    reconnect_interval: float = 1.0
    """Base reconnect interval in seconds."""

    max_reconnect_attempts: int | None = None
    """Maximum reconnect attempts (None = unlimited)."""


class UtteranceContext(Protocol):
    """
    Protocol defining the context object provided to utterance handlers.

    Contains the user's input and methods to send responses.
    """

    @property
    def text(self) -> str:
        """The user's transcribed speech."""
        ...

    @property
    def is_final(self) -> bool:
        """Whether this is a final transcript."""
        ...

    @property
    def user(self) -> UserInfo | None:
        """User information (requires appropriate scopes)."""
        ...

    @property
    def vision(self) -> VisionContext | None:
        """Vision context (requires vision scope)."""
        ...

    @property
    def entities(self) -> list[EntityInfo]:
        """Entities extracted from the utterance (NER)."""
        ...

    @property
    def topics(self) -> list[str]:
        """Topics detected in the utterance."""
        ...

    @property
    def context(self) -> list[ContextUtterance]:
        """Previous utterances for context (if IncludeContext filter is set)."""
        ...

    @property
    def session_id(self) -> str:
        """Current session ID."""
        ...

    @property
    def request_id(self) -> str:
        """Current request ID (must be echoed in responses)."""
        ...

    @property
    def user_id(self) -> str | None:
        """User ID."""
        ...

    @property
    def timestamp(self) -> datetime:
        """When the utterance was received."""
        ...

    @property
    def is_aborted(self) -> bool:
        """Whether the context was interrupted."""
        ...

    def send_delta(self, delta: str) -> None:
        """
        Send a streaming text chunk to the user.

        Args:
            delta: The text chunk to send.
        """
        ...

    def done(self, final_text: str | None = None) -> None:
        """
        Complete the response.

        Args:
            final_text: Optional final text. If not provided, uses buffered deltas.
        """
        ...

    async def request_frames(
        self, options: FrameRequestOptions | None = None
    ) -> FrameResponsePayload:
        """
        Request video frames from the user's session.

        Requires `vision` scope.

        Args:
            options: Frame request options.

        Returns:
            Frame data or descriptions.
        """
        ...

    async def query_memory(self, options: MemoryQueryOptions) -> MemoryResponsePayload:
        """
        Query the user's memory for relevant facts.

        Requires `memory` scope.

        Args:
            options: Memory query options.

        Returns:
            Matching facts.
        """
        ...

    async def query_session(
        self, options: SessionQueryOptions | None = None
    ) -> SessionResponsePayload:
        """
        Query session messages from the current conversation.

        Useful for getting context from other agents in the same session.
        Requires `memory` scope.

        Args:
            options: Session query options.

        Returns:
            Session messages.
        """
        ...


UtteranceHandler = Callable[[UtteranceContext], Awaitable[None] | None]
"""Handler function called when an utterance is received. Can be sync or async."""

InterruptHandler = Callable[[str, str], None]
"""Handler function called when an interrupt is received. Args: session_id, reason."""

ErrorHandler = Callable[[Exception], None]
"""Handler function called when an error occurs."""

ConnectHandler = Callable[[], None]
"""Handler function called when connected to the gateway."""

DisconnectHandler = Callable[[], None]
"""Handler function called when disconnected from the gateway."""

SessionStartHandler = Callable[[str, str | None, UserInfo | None], None]
"""Handler function called when a user session starts. Args: session_id, user_id, user."""

SessionEndHandler = Callable[[str, str | None], None]
"""Handler function called when a user session ends. Args: session_id, reason."""
