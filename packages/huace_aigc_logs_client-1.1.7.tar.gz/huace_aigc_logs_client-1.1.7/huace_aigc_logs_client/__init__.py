"""
Huace AIGC Logs Client - 智能日志框架集成 SDK

提供统一的日志接口，支持多种日志框架（loguru、structlog、logging），
自动检测并复用现有日志配置，提供 trace_id 追踪功能和远程日志上报。

主要功能:
    - 智能日志框架检测（loguru / structlog / logging）
    - 统一的 trace_id 管理（支持同步和异步）
    - Web 框架中间件集成（Flask / FastAPI / Django / Tornado / Sanic）
    - 函数装饰器（同步和异步）
    - 远程日志服务上报

快速开始:
    >>> from huace_aigc_logs_client import logger, log_function
    >>> 
    >>> @log_function()
    >>> def my_function():
    >>>     logger.info("Hello World")
    >>> 
    >>> my_function()

环境变量配置:
    - EXISTING_LOGGER_NAME: 指定要复用的 logger 名称
    - LOG_LEVEL: 日志级别（DEBUG/INFO/WARNING/ERROR）
    - SERVICE_NAME: 服务名称
    - LOG_SERVICE_URL: 远程日志服务地址
    - LOG_SERVICE_ACCESS_KEY: 远程日志服务访问密钥（用于安全认证）
    - LOG_FORCE_READ_STREAM_RESPONSE: 是否强制记录流式响应（true/false）

作者: Huace AIGC Team
版本: 1.0.0
许可: MIT License
"""

from .logger_sdk import (
    # 核心日志实例
    logger,
    logger_framework,
    
    # trace_id 管理
    get_trace_id,
    set_trace_id,
    clear_trace_id,
    generate_trace_id,
    
    # 函数装饰器
    log_function,
    async_log_function,
    
    # 远程日志
    setup_remote_logging,
    
    # Web 框架集成
    init_flask_app_logger,
    init_fastapi_app_logger,
    get_django_logger_middleware,
    init_tornado_app_logger,
    init_sanic_app_logger,
)

__version__ = '1.0.0'
__author__ = 'Huace AIGC Team'
__license__ = 'MIT'

__all__ = [
    # 核心组件
    'logger',
    'logger_framework',
    
    # trace_id 功能
    'get_trace_id',
    'set_trace_id',
    'clear_trace_id',
    'generate_trace_id',
    
    # 装饰器
    'log_function',
    'async_log_function',
    
    # 远程日志
    'setup_remote_logging',
    
    # Web 框架中间件
    'init_flask_app_logger',
    'init_fastapi_app_logger',
    'get_django_logger_middleware',
    'init_tornado_app_logger',
    'init_sanic_app_logger',
    
    # 版本信息
    '__version__',
    '__author__',
    '__license__',
]

# 模块级别文档
__doc__ = """
Huace AIGC Logs Client
======================

智能日志框架集成 SDK，支持自动检测和复用现有日志配置。

核心特性:
----------
1. **智能框架检测**: 自动检测 loguru、structlog、logging
2. **trace_id 追踪**: 统一的请求追踪，支持同步和异步
3. **零侵入集成**: 不破坏现有日志配置
4. **远程上报**: 支持批量上报到远程日志服务
5. **安全认证**: 支持 Access Key 认证机制

基础用法:
----------
    from huace_aigc_logs_client import logger, log_function
    
    @log_function()
    def example():
        logger.info("自动包含 trace_id")

Web 框架集成:
--------------
    # Flask
    from flask import Flask
    from huace_aigc_logs_client import init_flask_app_logger
    
    app = Flask(__name__)
    init_flask_app_logger(app)
    
    # FastAPI
    from fastapi import FastAPI
    from huace_aigc_logs_client import init_fastapi_app_logger
    
    app = FastAPI()
    init_fastapi_app_logger(app)

远程日志配置:
--------------
    # 1. 设置环境变量
    export LOG_SERVICE_URL="http://log-server:8080"
    export LOG_SERVICE_ACCESS_KEY="your-secret-key"
    
    # 2. 启用远程日志
    from huace_aigc_logs_client import setup_remote_logging
    setup_remote_logging()

更多文档请访问: https://github.com/huace-aigc/logs-client
"""
