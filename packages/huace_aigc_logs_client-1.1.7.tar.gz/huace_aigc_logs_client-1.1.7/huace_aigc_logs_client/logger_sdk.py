"""
日志模块，提供统一的日志格式和追踪 ID 功能
支持自动检测和复用项目中已有的日志框架（loguru、structlog 等）
"""
import logging
import os
import uuid
import time
from functools import wraps
import threading
from contextvars import ContextVar
import sys

# 使用 threading.local() 存储同步上下文的 trace_id（兼容多线程）
local = threading.local()

# 使用 contextvars.ContextVar 存储异步上下文的 trace_id（兼容异步任务）
async_trace_id: ContextVar[str] = ContextVar('trace_id', default='N/A')

# 从环境变量获取 access key，用于远程日志服务认证
ACCESS_KEY = os.getenv('LOG_SERVICE_ACCESS_KEY', '')


# ============ 智能日志框架检测和复用 ============
def _try_get_existing_logger():
    """
    尝试从项目中检测并获取已存在的日志实例
    按优先级依次尝试：loguru > structlog > 已配置的 logging
    """
    logger_info = {"logger": None, "framework": None, "needs_setup": True}
    
    # 1. 尝试使用 loguru（最流行的第三方日志库）
    try:
        from loguru import logger as loguru_logger
        # 检查 loguru 是否已经被配置（有 handlers）
        if hasattr(loguru_logger, '_core') and loguru_logger._core.handlers:
            logger_info["logger"] = loguru_logger
            logger_info["framework"] = "loguru"
            logger_info["needs_setup"] = False
            print(f"[logger_sdk] ✅ 检测到已配置的 loguru，将复用现有配置")
            return logger_info
    except ImportError:
        pass
    
    # 2. 尝试使用 structlog（结构化日志库）
    try:
        import structlog
        # 检查 structlog 是否已经被配置
        if structlog.is_configured():
            logger_info["logger"] = structlog.get_logger()
            logger_info["framework"] = "structlog"
            logger_info["needs_setup"] = False
            print(f"[logger_sdk] ✅ 检测到已配置的 structlog，将复用现有配置")
            return logger_info
    except (ImportError, Exception):
        pass
    
    # 3. 检查是否有已配置的 logging.Logger（通过环境变量或项目约定）
    try:
        # 尝试从环境变量获取 logger 名称
        existing_logger_name = os.getenv('EXISTING_LOGGER_NAME')
        if existing_logger_name:
            existing_logger = logging.getLogger(existing_logger_name)
            if existing_logger.handlers:
                logger_info["logger"] = existing_logger
                logger_info["framework"] = "logging"
                logger_info["needs_setup"] = False
                print(f"[logger_sdk] ✅ 检测到已配置的 logging.Logger: {existing_logger_name}")
                return logger_info
        
        # 检查 root logger 是否已配置
        root_logger = logging.getLogger()
        if root_logger.handlers and len(root_logger.handlers) > 0:
            # 排除默认的 lastResort handler
            real_handlers = [h for h in root_logger.handlers if not isinstance(h, logging.Handler) or h.get_name() != 'lastResort']
            if real_handlers:
                logger_info["logger"] = root_logger
                logger_info["framework"] = "logging"
                logger_info["needs_setup"] = False
                print(f"[logger_sdk] ✅ 检测到已配置的 root logger，将复用现有配置")
                return logger_info
    except Exception:
        pass
    
    # 4. 都没有，返回 None，稍后创建
    print(f"[logger_sdk] ℹ️ 未检测到已配置的日志框架，将创建新的 logging 实例")
    return logger_info


def _create_logging_logger():
    """创建标准的 logging.Logger 实例（回退方案）"""
    # 确保日志目录存在
    log_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs')
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    
    # 配置日志格式
    log_formatter = logging.Formatter(
        '%(asctime)s [%(levelname)s] [%(trace_id)s] [%(filename)s:%(lineno)d] - %(message)s'
    )
    
    # 创建文件处理器
    log_file_path = os.path.join(log_dir, f'app_{time.strftime("%Y%m%d")}.log')
    file_handler = logging.FileHandler(log_file_path, encoding='utf-8')
    file_handler.setFormatter(log_formatter)
    
    # 创建控制台处理器
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(log_formatter)
    
    # 获取 logger 实例
    logger = logging.getLogger(os.getenv('SERVICE_NAME', 'app-logger'))
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    
    # 从环境变量获取日志级别
    log_level = os.getenv('LOG_LEVEL', 'INFO').upper()
    logger.setLevel(getattr(logging, log_level, logging.INFO))
    
    print(f"[logger_sdk] ✅ 已创建新的 logging 实例: {logger.name}")
    return logger, "logging"


def _setup_loguru_integration(loguru_logger):
    """为 loguru 添加 trace_id 支持"""
    try:
        # loguru 不需要特殊处理，我们创建一个包装器来自动 bind trace_id
        # 保存原始方法
        original_info = loguru_logger.info
        original_debug = loguru_logger.debug
        original_warning = loguru_logger.warning
        original_error = loguru_logger.error
        original_critical = loguru_logger.critical
        
        def make_wrapper(original_method):
            def wrapper(message, *args, **kwargs):
                # 使用 loguru 的 bind 方法绑定 trace_id
                return original_method(message, *args, **kwargs)
            return wrapper
        
        # 我们不包装方法，而是在配置中添加 trace_id
        # loguru 会自动从 extra 中读取，我们只需要在格式中添加 {extra[trace_id]}
        print(f"[logger_sdk] ✅ loguru 已就绪（请在日志格式中使用 {{extra[trace_id]}} 显示 trace_id）")
        print(f"[logger_sdk] ℹ️ 使用 logger.bind(trace_id=get_trace_id()) 来手动绑定")
    except Exception as e:
        print(f"[logger_sdk] ⚠️ loguru 集成失败: {e}")


def _setup_structlog_integration():
    """为 structlog 添加 trace_id 支持"""
    try:
        import structlog
        
        # 添加 trace_id 处理器
        def add_trace_id(logger, method_name, event_dict):
            event_dict['trace_id'] = get_trace_id()
            return event_dict
        
        # 获取现有的处理器链
        current_processors = structlog.get_config().get('processors', [])
        if add_trace_id not in current_processors:
            current_processors.insert(0, add_trace_id)
            structlog.configure(processors=current_processors)
            print(f"[logger_sdk] ✅ 已为 structlog 添加 trace_id 处理器")
    except Exception as e:
        print(f"[logger_sdk] ⚠️ structlog 集成失败: {e}")


# ============ 初始化日志系统 ============
logger_info = _try_get_existing_logger()

if logger_info["logger"] is None:
    # 没有检测到现有日志框架，创建新的
    logger, logger_framework = _create_logging_logger()
else:
    logger = logger_info["logger"]
    logger_framework = logger_info["framework"]
    
    # 为检测到的框架添加 trace_id 支持
    if logger_framework == "loguru":
        _setup_loguru_integration(logger)
    elif logger_framework == "structlog":
        _setup_structlog_integration()

# 导出当前使用的框架名称，方便调试
__logger_framework__ = logger_framework


# ============ 通用辅助函数 ============
def get_log_level():
    """从环境变量获取日志级别，默认为 INFO"""
    log_level = os.getenv('LOG_LEVEL', 'INFO').upper()
# ============ 通用辅助函数 ============
def get_log_level():
    """从环境变量获取日志级别，默认为 INFO"""
    log_level = os.getenv('LOG_LEVEL', 'INFO').upper()
    return getattr(logging, log_level, logging.INFO)

# ============ 为 logging 框架添加 TraceIDFilter ============
# 定义 TraceIDFilter 类（只用于 logging）
class TraceIDFilter(logging.Filter):
    def filter(self, record):
        """从统一的上下文中获取 trace_id（框架无关，同时支持同步和异步）"""
        record.trace_id = get_trace_id()
        return True

# 只在使用 logging 框架时才添加过滤器
if logger_framework == "logging":
    logger.addFilter(TraceIDFilter())
    print(f"[logger_sdk] ✅ 已为 logging 添加 TraceIDFilter")


# ============ trace_id 管理函数 ============
# 生成唯一的追踪 ID
def generate_trace_id():
    """生成唯一的追踪 ID"""
    return str(uuid.uuid4())

# 统一的 trace_id 管理函数（框架无关）
def get_trace_id():
    """获取当前上下文的 trace_id（同时支持同步和异步）"""
    # 优先从 async context 获取（异步场景）
    async_id = async_trace_id.get('N/A')
    if async_id != 'N/A':
        return async_id
    # 从 threading.local 获取（同步场景）
    return getattr(local, 'trace_id', 'N/A')

def set_trace_id(trace_id: str):
    """设置当前上下文的 trace_id（同时支持同步和异步）
    
    注意：对于 loguru 框架，中间件层设置的 trace_id 会被 remote_sink 
    通过调用 get_trace_id() 自动读取，无需手动 bind
    """
    # 同时设置两个上下文，确保兼容性
    local.trace_id = trace_id
    async_trace_id.set(trace_id)

def clear_trace_id():
    """清理当前上下文的 trace_id"""
    if hasattr(local, 'trace_id'):
        delattr(local, 'trace_id')
    # ContextVar 不需要手动清理，会自动管理

# ============ 日志辅助函数 ============
def _log_with_trace_id(level, message):
    """统一的日志输出函数，自动处理不同框架的 trace_id 注入"""
    trace_id = get_trace_id()
    
    if logger_framework == "loguru":
        # loguru 使用 bind 绑定上下文
        bound_logger = logger.bind(trace_id=trace_id)
        getattr(bound_logger, level.lower())(message)
    elif logger_framework == "structlog":
        # structlog 会自动从 processor 中获取 trace_id
        getattr(logger, level.lower())(message)
    else:
        # logging 通过 TraceIDFilter 自动注入
        getattr(logger, level.lower())(message)

# 函数拦截器，用于非请求上下文中的日志记录
def log_function(new_trace_id=False):
    """函数日志装饰器，用于非请求上下文中的日志记录（支持同步函数）
    
    参数:
        new_trace_id: bool, 默认 False
            - False: 优先复用当前上下文的 trace_id，如果不存在才生成新的（推荐）
            - True: 强制为此函数调用生成新的 trace_id（覆盖现有的）
    
    使用示例:
        @log_function()  # 默认复用 trace_id
        def my_func1():
            pass
        
        @log_function(new_trace_id=True)  # 强制生成新的 trace_id
        def my_func2():
            pass
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # 判断是否需要生成新的 trace_id
            existing_trace_id = get_trace_id()
            
            if new_trace_id or existing_trace_id == 'N/A':
                # 生成新的 trace_id
                trace_id = generate_trace_id()
                set_trace_id(trace_id)
                should_clear = True
                _log_with_trace_id('DEBUG', f"调用函数 {func.__name__} 开始 [新trace_id: {trace_id}]， 入参: args={args}, kwargs={kwargs}")
            else:
                # 复用现有的 trace_id
                should_clear = False
                _log_with_trace_id('DEBUG', f"调用函数 {func.__name__} 开始 [复用trace_id: {existing_trace_id}]， 入参: args={args}, kwargs={kwargs}")
            
            try:
                result = func(*args, **kwargs)
                _log_with_trace_id('DEBUG', f"调用函数 {func.__name__} 结束，出参: {result}")
                return result
            except Exception as e:
                _log_with_trace_id('ERROR', f"调用函数 {func.__name__} 发生异常: {str(e)}")
                raise
            finally:
                if should_clear:
                    clear_trace_id()
        return wrapper
    return decorator

# 异步函数拦截器
def async_log_function(new_trace_id=False):
    """异步函数日志装饰器，用于异步函数的日志记录
    
    参数:
        new_trace_id: bool, 默认 False
            - False: 优先复用当前上下文的 trace_id，如果不存在才生成新的（推荐）
            - True: 强制为此函数调用生成新的 trace_id（覆盖现有的）
    
    使用示例:
        @async_log_function()  # 默认复用 trace_id
        async def my_async_func1():
            pass
        
        @async_log_function(new_trace_id=True)  # 强制生成新的 trace_id
        async def my_async_func2():
            pass
    """
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # 判断是否需要生成新的 trace_id
            existing_trace_id = get_trace_id()
            
            if new_trace_id or existing_trace_id == 'N/A':
                # 生成新的 trace_id
                trace_id = generate_trace_id()
                set_trace_id(trace_id)
                should_clear = True
                _log_with_trace_id('DEBUG', f"调用异步函数 {func.__name__} 开始 [新trace_id: {trace_id}]， 入参: args={args}, kwargs={kwargs}")
            else:
                # 复用现有的 trace_id
                should_clear = False
                _log_with_trace_id('DEBUG', f"调用异步函数 {func.__name__} 开始 [复用trace_id: {existing_trace_id}]， 入参: args={args}, kwargs={kwargs}")
            
            try:
                result = await func(*args, **kwargs)
                _log_with_trace_id('DEBUG', f"调用异步函数 {func.__name__} 结束，出参: {result}")
                return result
            except Exception as e:
                _log_with_trace_id('ERROR', f"调用异步函数 {func.__name__} 发生异常: {str(e)}")
                raise
            finally:
                if should_clear:
                    clear_trace_id()
        return wrapper
    return decorator

# 添加远程日志处理器（如果配置了 LOG_SERVICE_URL）
def setup_remote_logging():
    """设置远程日志收集（支持 loguru 和 logging）"""
    log_service_url = os.getenv('LOG_SERVICE_URL')
    if not log_service_url:
        return
    
    try:
        import requests
        import queue
        import threading
        from datetime import datetime, timezone, timedelta
        
        # 中国时区 (UTC+8)
        CN_TZ = timezone(timedelta(hours=8))
        service_name = os.getenv('SERVICE_NAME', 'app-demo')
        
        # 检测当前使用的日志框架
        if logger_framework == "loguru":
            # ========== loguru 专用处理 ==========
            try:
                from loguru import logger as loguru_logger
                
                # 检查是否已经添加过远程日志 sink（通过检查配置的标记）
                if hasattr(loguru_logger, '_remote_logging_enabled'):
                    return
                
                # 创建发送队列和工作线程
                log_queue = queue.Queue()
                
                def send_worker():
                    """后台线程批量发送日志"""
                    buffer = []
                    url = log_service_url.rstrip('/') + '/api/logs/batch'
                    # 准备请求头，包含 access key
                    headers = {'Content-Type': 'application/json'}
                    if ACCESS_KEY:
                        headers['X-Access-Key'] = ACCESS_KEY
                    
                    while True:
                        try:
                            log = log_queue.get(timeout=2)
                            buffer.append(log)
                            if len(buffer) >= 10:
                                try:
                                    requests.post(url, json=buffer, headers=headers, timeout=3)
                                except Exception:
                                    pass  # 静默失败，避免影响应用主流程
                                buffer = []
                        except queue.Empty:
                            if buffer:
                                try:
                                    requests.post(url, json=buffer, headers=headers, timeout=3)
                                except Exception:
                                    pass  # 静默失败，避免影响应用主流程
                                buffer = []
                
                # 启动发送线程
                thread = threading.Thread(target=send_worker, daemon=True)
                thread.start()
                
                # 定义 loguru sink 函数
                def remote_sink(message):
                    """loguru sink 函数，将日志发送到远程"""
                    try:
                        # loguru 的 sink 函数接收的是 Message 对象，record 是其属性
                        record = message.record
                        
                        # 优先从 record['extra'] 获取（如果用户使用了 logger.bind(trace_id=xxx)）
                        # 否则从统一的上下文管理中获取（threading.local / contextvars）
                        trace_id = record['extra'].get('trace_id')
                        if not trace_id or trace_id == 'N/A':
                            # 从统一的 trace_id 存储中获取（支持中间件设置的 trace_id）
                            trace_id = get_trace_id()
                        
                        log_data = {
                            'timestamp': record['time'].astimezone(CN_TZ).isoformat(),
                            'level': record['level'].name,
                            'service': service_name,
                            'filename': record['file'].name,
                            'lineno': record['line'],
                            'message': record['message'],
                            'trace_id': trace_id
                        }
                        log_queue.put(log_data)
                    except Exception:
                        pass  # 静默失败，避免影响应用主流程
                
                # 添加远程 sink
                loguru_logger.add(remote_sink, format="{message}")
                
                # 标记已启用
                loguru_logger._remote_logging_enabled = True
                
            except Exception:
                pass  # 静默失败，避免影响应用主流程
        
        else:
            # ========== logging 标准库处理 ==========
            class RemoteLogHandler(logging.Handler):
                """远程日志处理器"""
                def __init__(self, url, service_name):
                    super().__init__()
                    self.url = url.rstrip('/') + '/api/logs/batch'
                    self.service_name = service_name
                    self.queue = queue.Queue()
                    self.running = True
                    threading.Thread(target=self._worker, daemon=True).start()
                
                def emit(self, record):
                    try:
                        log_data = {
                            'timestamp': datetime.fromtimestamp(record.created, tz=CN_TZ).isoformat(),
                            'level': record.levelname,
                            'service': self.service_name,
                            'filename': record.filename,
                            'lineno': record.lineno,
                            'message': record.getMessage(),
                            'trace_id': getattr(record, 'trace_id', 'N/A')
                        }
                        self.queue.put(log_data)
                    except:
                        pass
                
                def _worker(self):
                    buffer = []
                    while self.running:
                        try:
                            log = self.queue.get(timeout=2)
                            buffer.append(log)
                            if len(buffer) >= 10:
                                self._send(buffer)
                                buffer = []
                        except queue.Empty:
                            if buffer:
                                self._send(buffer)
                                buffer = []
                
                def _send(self, logs):
                    try:
                        # 准备请求头，包含 access key
                        headers = {'Content-Type': 'application/json'}
                        if ACCESS_KEY:
                            headers['X-Access-Key'] = ACCESS_KEY
                        requests.post(self.url, json=logs, headers=headers, timeout=3)
                    except:
                        pass
            
            # 检查是否已经添加过 RemoteLogHandler
            for existing_handler in logger.handlers:
                if isinstance(existing_handler, RemoteLogHandler):
                    logger.info(f"远程日志已启用，跳过重复添加")
                    return
            
            handler = RemoteLogHandler(log_service_url, service_name)
            logger.addHandler(handler)
            logger.info(f"远程日志已启用: {log_service_url}")
            
    except Exception as e:
        print(f"[logger_sdk] ⚠️ 远程日志初始化失败: {e}")

# 注意：移除了自动调用 setup_remote_logging()
# 请确保在项目的日志初始化代码（如 log.py 的 init()）中手动调用
# 这样可以确保在 loguru 配置完成后再添加远程 sink
# 
# 使用方法：
# from app.common.logger_sdk import setup_remote_logging
# setup_remote_logging()  # 在 loguru 配置完成后调用


#------- 为 Flask 应用初始化日志功能 -------#

def init_flask_app_logger(app, enable_remote_logging=True):
    """
    初始化应用，添加日志和验证功能
    
    参数:
        app: Flask 应用实例
        enable_remote_logging: bool, 默认 True
            - True: 自动调用 setup_remote_logging() 启用远程日志
            - False: 不启用远程日志（需要手动调用）
    """
    from flask import request, g, Flask
    
    # 自动启用远程日志（如果配置了环境变量）
    if enable_remote_logging:
        setup_remote_logging()
    
    def request_logger_middleware(app):
        """请求日志中间件，为每个请求生成追踪 ID"""
        @app.before_request
        def before_request():
            trace_id = request.headers.get("X-Trace-ID")
            if not trace_id:
                # 为每个请求生成唯一的追踪 ID（使用统一的管理函数）
                trace_id = generate_trace_id()
            set_trace_id(trace_id)
            # 同时保存到 g 对象（方便 Flask 应用内部使用）
            g.trace_id = trace_id
            # 记录请求开始时间
            g.start_time = time.time()
            logger.info(f"接收到请求: {request.method} {request.path} --Header {dict(request.headers)} --Query {dict(request.args)} --Body {request.get_data(as_text=True)} --form {dict(request.form)}")

        @app.after_request
        def after_request(response):
            # 计算请求处理时间
            process_time = time.time() - g.start_time
            
            # 安全地读取响应内容
            try:
                if response.direct_passthrough:
                    response_preview = "<direct passthrough> 类型响应（防止影响返回,不读取响应内容)"
                elif response.is_streamed:
                    response_preview = "<streamed> 类型响应（防止影响返回,不读取响应内容)"
                else:
                    response_data = response.get_data(as_text=True)
                    # 尝试解析并美化 JSON 响应
                    try:
                        import json
                        json_obj = json.loads(response_data)
                        # 使用 ensure_ascii=False 保留中文字符
                        response_preview = json.dumps(json_obj, ensure_ascii=False, indent=2)
                    except:
                        response_preview = response_data
            except Exception as e:
                response_preview = f"<error reading response: {e}>"
            
            logger.info(f"请求处理完成: {request.method} {request.path} --StatusCode: {response.status_code} --ProcessTime: {process_time:.4f}s --ResponsePreview: {response_preview}")
            return response
        
        @app.teardown_request
        def teardown_request(exception):
            if exception:
                logger.error(f"请求处理异常: {str(exception)}")
    # 注册请求日志中间件
    request_logger_middleware(app)
    # 将自定义 logger 赋值给 Flask app 的 logger 属性
    app.logger = logger  
    
    return app

# ------- FastAPI 日志初始化 ------- #
def init_fastapi_app_logger(app, enable_remote_logging=True):
    """
    初始化 FastAPI 应用，添加日志和追踪功能
    
    参数:
        app: FastAPI 应用实例
        enable_remote_logging: bool, 默认 True
            - True: 自动调用 setup_remote_logging() 启用远程日志
            - False: 不启用远程日志（需要手动调用）
    """
    from fastapi import Request, Response
    from starlette.middleware.base import BaseHTTPMiddleware
    import json
    
    # 自动启用远程日志（如果配置了环境变量）
    if enable_remote_logging:
        setup_remote_logging()
    
    class LoggerMiddleware(BaseHTTPMiddleware):
        async def dispatch(self, request: Request, call_next):
            trace_id = request.headers.get("X-Trace-ID")
            if not trace_id:
                # 为每个请求生成唯一的追踪 ID（使用统一的管理函数）
                trace_id = generate_trace_id()
            set_trace_id(trace_id)
            # 同时保存到 request.state（方便 FastAPI 应用内部使用）
            request.state.trace_id = trace_id
            
            # 记录请求开始时间
            start_time = time.time()
            
            # 读取请求体（需要特殊处理以避免消耗流）
            body = b""
            if request.method in ["POST", "PUT", "PATCH"]:
                try:
                    body = await request.body()
                except:
                    pass
            
            logger.info(
                f"接收到请求: {request.method} {request.url.path} "
                f"--Header {dict(request.headers)} "
                f"--Query {dict(request.query_params)} "
                f"--Body {body.decode('utf-8', errors='ignore')} "
                f"--form {dict(await request.form())}"
            )
            
            # 处理请求
            try:
                response = await call_next(request)
                
                # 计算请求处理时间
                process_time = time.time() - start_time
                
                # 安全地读取响应内容（参考 Flask 的实现）
                response_preview = ""
                try:
                    from starlette.responses import StreamingResponse, FileResponse, Response as StarletteResponse
                    
                    # 调试：记录响应类型信息（可选，生产环境可注释）
                    # logger.debug(f"响应类型: {type(response).__name__}, 是否有body: {hasattr(response, 'body')}, 是否StreamingResponse: {isinstance(response, StreamingResponse)}")
                    
                    # 检查是否强制读取流式响应（通过环境变量控制）
                    force_read_stream = os.getenv('LOG_FORCE_READ_STREAM_RESPONSE', 'false').lower() == 'true'
                    
                    # 优先判断是否有 body 属性（JSONResponse、HTMLResponse、Response 等都有）
                    # 这些响应类型的 body 已经是完整的字节串，可以直接读取
                    if hasattr(response, 'body') and not isinstance(response, StreamingResponse):
                        # 普通 Response 对象，直接读取 body 属性（已经是字节串）
                        response_body = response.body
                        response_text = response_body.decode('utf-8', errors='ignore')
                        
                        # 尝试解析并美化 JSON 响应
                        try:
                            json_obj = json.loads(response_text)
                            response_preview = json.dumps(json_obj, ensure_ascii=False, indent=2)
                        except:
                            # 如果不是 JSON，截断显示
                            response_preview = response_text[:200] if len(response_text) > 200 else response_text
                    elif isinstance(response, StreamingResponse):
                        # 流式响应处理
                        if force_read_stream and not isinstance(response, FileResponse):
                            # 强制读取流式响应内容（需要消耗迭代器并生成新响应）
                            try:
                                # 读取所有流式内容
                                body_chunks = []
                                async for chunk in response.body_iterator:
                                    body_chunks.append(chunk)
                                
                                # 合并所有块
                                full_body = b''.join(body_chunks)
                                response_text = full_body.decode('utf-8', errors='ignore')
                                
                                # 尝试解析并美化 JSON
                                try:
                                    json_obj = json.loads(response_text)
                                    response_preview = json.dumps(json_obj, ensure_ascii=False, indent=2)
                                except:
                                    # 如果不是 JSON，截断显示
                                    response_preview = response_text[:200] if len(response_text) > 200 else response_text
                                
                                # 创建新的普通响应对象（因为原迭代器已被消耗）
                                response = StarletteResponse(
                                    content=full_body,
                                    status_code=response.status_code,
                                    headers=dict(response.headers),
                                    media_type=response.media_type
                                )
                            except Exception as e:
                                response_preview = f"<强制读取StreamingResponse失败: {e}>"
                        else:
                            # 不读取流式响应内容
                            if isinstance(response, FileResponse):
                                response_preview = f"<{response.__class__.__name__}> 文件响应（不读取内容）"
                            else:
                                response_preview = f"<{response.__class__.__name__}> 流式响应（不读取内容，可设置 LOG_FORCE_READ_STREAM_RESPONSE=true 强制读取）"
                    else:
                        response_preview = f"<{response.__class__.__name__}> 类型响应（未处理读取，需要读取请自行修改)"
                except Exception as e:
                    response_preview = f"<error reading response: {e}>"
                
                logger.info(
                    f"请求处理完成: {request.method} {request.url.path} "
                    f"--StatusCode: {response.status_code} "
                    f"--ProcessTime: {process_time:.4f}s "
                    f"--ResponsePreview: {response_preview}"
                )
                
                return response
            except Exception as e:
                logger.error(f"请求处理异常: {str(e)}")
                raise
            finally:
                # 清理 trace_id
                clear_trace_id()
    
    # 添加中间件
    app.add_middleware(LoggerMiddleware)
    
    return app


# ------- Django 日志初始化 ------- #
def get_django_logger_middleware(enable_remote_logging=True):
    """
    返回 Django 中间件类，用于日志记录和追踪
    
    参数:
        enable_remote_logging: bool, 默认 True
            - True: 自动调用 setup_remote_logging() 启用远程日志
            - False: 不启用远程日志（需要手动调用）
    
    使用方法：
        在 settings.py 的 MIDDLEWARE 中添加：
        'ability.logger_sdk.DjangoLoggerMiddleware'
        
        或者在 settings.py 中手动初始化：
        from ability.logger_sdk import get_django_logger_middleware
        DjangoLoggerMiddleware = get_django_logger_middleware(enable_remote_logging=True)
    """
    # 自动启用远程日志（如果配置了环境变量）
    if enable_remote_logging:
        setup_remote_logging()
    
    class DjangoLoggerMiddleware:
        def __init__(self, get_response):
            self.get_response = get_response
        
        def __call__(self, request):
            trace_id = request.headers.get("X-Trace-ID")
            if not trace_id:
                # 为每个请求生成唯一的追踪 ID（使用统一的管理函数）
                trace_id = generate_trace_id()
            set_trace_id(trace_id)
            # 同时保存到 request 对象（方便 Django 应用内部使用）
            request.trace_id = trace_id
            
            # 记录请求开始时间
            start_time = time.time()
            
            # 读取请求体
            try:
                body = request.body.decode('utf-8', errors='ignore')
            except:
                body = ""
            
            logger.info(
                f"接收到请求: {request.method} {request.path} "
                f"--Header {dict(request.headers)} "
                f"--Query {dict(request.GET)} "
                f"--Body {body} "
            )
            
            # 处理请求
            try:
                response = self.get_response(request)
                
                # 计算请求处理时间
                process_time = time.time() - start_time
                
                # 读取响应内容
                try:
                    if hasattr(response, 'content'):
                        response_preview = response.content.decode('utf-8', errors='ignore')
                        # 尝试解析并美化 JSON
                        try:
                            import json
                            json_obj = json.loads(response_preview)
                            response_preview = json.dumps(json_obj, ensure_ascii=False, indent=2)
                        except:
                            pass
                    else:
                        response_preview = "<streaming response>"
                except:
                    response_preview = "<error reading response>"
                
                logger.info(
                    f"请求处理完成: {request.method} {request.path} "
                    f"--StatusCode: {response.status_code} "
                    f"--ProcessTime: {process_time:.4f}s "
                    f"--ResponsePreview: {response_preview}"
                )
                
                return response
            except Exception as e:
                logger.error(f"请求处理异常: {str(e)}")
                raise
            finally:
                # 清理 trace_id
                clear_trace_id()
    
    return DjangoLoggerMiddleware


# ------- Tornado 日志初始化 ------- #
def init_tornado_app_logger(app, enable_remote_logging=True):
    """
    初始化 Tornado 应用，添加日志和追踪功能
    
    参数:
        app: Tornado Application 实例
        enable_remote_logging: bool, 默认 True
            - True: 自动调用 setup_remote_logging() 启用远程日志
            - False: 不启用远程日志（需要手动调用）
        
    使用方法：
        需要在每个 RequestHandler 中继承 LoggingRequestHandler
        或者在 Application 初始化时设置：
        app = tornado.web.Application(handlers, log_function=log_request)
    """
    import tornado.web
    
    # 自动启用远程日志（如果配置了环境变量）
    if enable_remote_logging:
        setup_remote_logging()
    
    def log_request(handler):
        """Tornado 请求日志函数"""
        if handler.get_status() < 400:
            log_method = logger.info
        elif handler.get_status() < 500:
            log_method = logger.warning
        else:
            log_method = logger.error
        
        request_time = 1000.0 * handler.request.request_time()
        log_method(
            f"请求处理完成: {handler.request.method} {handler.request.uri} "
            f" --StatusCode: {handler.get_status()} "
            f"--ProcessTime: {request_time:.2f}ms"
        )
    
    # 保存原始的 log_function
    original_log_function = app.settings.get('log_function')
    
    # 设置新的 log_function
    app.settings['log_function'] = log_request
    
    # 创建 BaseHandler 类供继承使用
    class LoggingRequestHandler(tornado.web.RequestHandler):
        def prepare(self):
            """在请求处理前执行"""
            trace_id = self.request.headers.get("X-Trace-ID")
            if not trace_id:
                # 为每个请求生成唯一的追踪 ID（使用统一的管理函数）
                trace_id = generate_trace_id()
            set_trace_id(trace_id)
            # 同时保存到 handler 实例（方便 Tornado 应用内部使用）
            self.trace_id = trace_id
            self.start_time = time.time()
            
            # 读取请求体
            body = self.request.body.decode('utf-8', errors='ignore') if self.request.body else ""
            
            logger.info(
                f"接收到请求: {self.request.method} {self.request.uri} "
                f"--Header {dict(self.request.headers)} "
                f"--Body {body} "
                f"--form {dict(self.request.arguments)}"
            )
        
        def on_finish(self):
            """在请求处理完成后执行"""
            # 清理 trace_id
            clear_trace_id()
        
        def log_exception(self, typ, value, tb):
            """记录异常"""
            logger.error(f"请求处理异常: {value}", exc_info=(typ, value, tb))
    
    # 将 LoggingRequestHandler 附加到 app 上供使用
    app.LoggingRequestHandler = LoggingRequestHandler
    
    return app


# ------- Sanic 日志初始化 ------- #
def init_sanic_app_logger(app, enable_remote_logging=True):
    """
    初始化 Sanic 应用，添加日志和追踪功能
    
    参数:
        app: Sanic 应用实例
        enable_remote_logging: bool, 默认 True
            - True: 自动调用 setup_remote_logging() 启用远程日志
            - False: 不启用远程日志（需要手动调用）
    """
    from sanic import Request, HTTPResponse
    
    # 自动启用远程日志（如果配置了环境变量）
    if enable_remote_logging:
        setup_remote_logging()
    
    @app.middleware('request')
    async def log_request(request: Request):
        """请求前中间件"""
        trace_id = request.headers.get("X-Trace-ID")
        if not trace_id:
            # 为每个请求生成唯一的追踪 ID（使用统一的管理函数）
            trace_id = generate_trace_id()
        set_trace_id(trace_id)
        # 同时保存到 request.ctx（方便 Sanic 应用内部使用）
        request.ctx.trace_id = trace_id
        request.ctx.start_time = time.time()
        
        # 读取请求体
        body = ""
        if request.body:
            try:
                body = request.body.decode('utf-8', errors='ignore')
            except:
                pass
        
        logger.info(
            f"接收到请求: {request.method} {request.path} "
            f"--Header {dict(request.headers)} "
            f"--Query {dict(request.args)} "
            f"--Body {body} "
            f"--form {dict(request.form)}"
        )
    
    @app.middleware('response')
    async def log_response(request: Request, response: HTTPResponse):
        """响应后中间件"""
        # 计算请求处理时间
        process_time = time.time() - request.ctx.start_time
        
        # 读取响应内容
        try:
            if hasattr(response, 'body'):
                response_preview = response.body.decode('utf-8', errors='ignore')
                # 尝试解析并美化 JSON
                try:
                    import json
                    json_obj = json.loads(response_preview)
                    response_preview = json.dumps(json_obj, ensure_ascii=False, indent=2)
                except:
                    pass
            else:
                response_preview = "<streaming response>"
        except:
            response_preview = "<error reading response>"
        
        logger.info(
            f"请求处理完成: {request.method} {request.path} "
            f"--StatusCode: {response.status} "
            f"--ProcessTime: {process_time:.4f}s "
            f"--ResponsePreview: {response_preview}"
        )
        
        # 清理 trace_id
        clear_trace_id()
    
    @app.exception(Exception)
    async def log_exception(request: Request, exception: Exception):
        """异常处理"""
        logger.error(f"请求处理异常: {str(exception)}")
        # 清理 trace_id
        clear_trace_id()
    
    return app


# ------- 使用说明 ------- #
"""
【统一的 trace_id 管理方案】
本模块使用 threading.local() 和 contextvars.ContextVar 统一管理 trace_id，完全框架无关。

核心优势：
1. ✅ 框架无关 - 不依赖任何特定框架（Flask g、FastAPI request.state 等）
2. ✅ 线程安全 - 使用 threading.local() 确保多线程环境下的隔离
3. ✅ 异步支持 - 使用 contextvars 支持 asyncio 和异步框架
4. ✅ 自动管理 - 请求开始时自动生成，结束时自动清理
5. ✅ 灵活复用 - 支持嵌套调用时复用父级 trace_id

各框架的 trace_id 存储对比：
- Flask:      g.trace_id (基于 LocalProxy)
- FastAPI:    request.state.trace_id (请求对象属性)
- Django:     request.trace_id (请求对象属性)
- Tornado:    self.trace_id (handler 实例属性)
- Sanic:      request.ctx.trace_id (上下文对象)
- 本模块:     threading.local() + contextvars (统一管理)

使用示例：

1. Flask:
    from flask import Flask
    from ability.logger_sdk import init_flask_app_logger, logger
    
    app = Flask(__name__)
    init_flask_app_logger(app)
    
    @app.route('/test')
    def test():
        # trace_id 自动注入，无需手动管理
        logger.info("处理请求")
        return "ok"

2. FastAPI:
    from fastapi import FastAPI
    from ability.logger_sdk import init_fastapi_app_logger, logger
    
    app = FastAPI()
    init_fastapi_app_logger(app)
    
    @app.get("/test")
    async def test():
        # trace_id 自动注入，支持异步
        logger.info("处理异步请求")
        return {"status": "ok"}

3. Django:
    在 settings.py 的 MIDDLEWARE 中添加：
    MIDDLEWARE = [
        ...
        'ability.logger_sdk.DjangoLoggerMiddleware',
        ...
    ]
    
    然后在视图中使用：
    from ability.logger_sdk import logger
    
    def my_view(request):
        # trace_id 自动注入
        logger.info("处理 Django 请求")
        return HttpResponse("ok")

4. Tornado:
    import tornado.web
    from ability.logger_sdk import init_tornado_app_logger, logger
    
    app = tornado.web.Application(handlers)
    init_tornado_app_logger(app)
    
    # 在 Handler 中继承 LoggingRequestHandler
    class MyHandler(app.LoggingRequestHandler):
        def get(self):
            # trace_id 自动注入
            logger.info("处理 Tornado 请求")
            self.write("ok")

5. Sanic:
    from sanic import Sanic
    from ability.logger_sdk import init_sanic_app_logger, logger
    
    app = Sanic("my_app")
    init_sanic_app_logger(app)
    
    @app.get("/test")
    async def test(request):
        # trace_id 自动注入，支持异步
        logger.info("处理 Sanic 异步请求")
        return {"status": "ok"}

6. 同步函数使用 @log_function (推荐用法):
    from ability.logger_sdk import log_function, logger
    
    # 方式1: 默认行为 - 优先复用现有 trace_id（推荐）
    @log_function()  # 注意：现在需要加括号
    def process_data(param):
        # 如果在请求上下文中，会复用请求的 trace_id
        # 如果不在请求上下文中，会自动生成新的 trace_id
        logger.info(f"处理数据: {param}")
        return "result"
    
    @log_function()  # 与上面的函数共享同一个 trace_id（如果在同一上下文）
    def save_result(result):
        logger.info(f"保存结果: {result}")
        return True
    
    # 方式2: 强制生成新的 trace_id（特殊场景）
    @log_function(new_trace_id=True)
    def independent_task():
        # 强制生成新的 trace_id，不复用父级的
        # 适用于后台任务、独立的业务逻辑等
        logger.info("执行独立任务")
        return "done"
    
    # 实际调用示例
    def handle_request():
        # 整个请求链路使用同一个 trace_id
        data = process_data("input")    # 使用请求的 trace_id
        result = save_result(data)       # 复用同一个 trace_id
        independent_task()               # 生成新的 trace_id

7. 异步函数使用 @async_log_function:
    from ability.logger_sdk import async_log_function, logger
    
    # 默认行为 - 复用 trace_id
    @async_log_function()  # 注意：现在需要加括号
    async def async_process(param):
        logger.info(f"异步处理: {param}")
        await some_async_operation()
        return "result"
    
    # 强制生成新的 trace_id
    @async_log_function(new_trace_id=True)
    async def background_job():
        logger.info("后台异步任务")
        await long_running_task()
        return "done"

8. 手动管理 trace_id（高级用法）:
    from ability.logger_sdk import set_trace_id, get_trace_id, clear_trace_id, logger
    
    # 设置自定义 trace_id
    set_trace_id("my-custom-trace-id")
    logger.info("使用自定义 trace_id")
    
    # 获取当前 trace_id
    current_trace_id = get_trace_id()
    print(f"当前 trace_id: {current_trace_id}")
    
    # 清理 trace_id
    clear_trace_id()

9. 跨线程/协程传递 trace_id:
    import threading
    from ability.logger_sdk import get_trace_id, set_trace_id, logger
    
    def parent_function():
        # 主线程有 trace_id
        parent_trace_id = get_trace_id()
        
        def child_thread():
            # 子线程需要手动设置
            set_trace_id(parent_trace_id)
            logger.info("子线程中的日志")
            clear_trace_id()
        
        thread = threading.Thread(target=child_thread)
        thread.start()
        thread.join()

技术说明：
- threading.local() 用于同步场景，确保每个线程有独立的 trace_id
- contextvars.ContextVar 用于异步场景，确保每个协程有独立的 trace_id
- TraceIDFilter 优先从 contextvars 获取（异步），其次从 threading.local 获取（同步）
- 所有框架的中间件都会同时设置 threading.local 和 contextvars，确保完全兼容
"""