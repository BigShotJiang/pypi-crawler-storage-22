# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListProductsRespMonthly:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'name': 'str',
        'version': 'str',
        'values': 'list[ListProductsRespValues1]'
    }

    attribute_map = {
        'name': 'name',
        'version': 'version',
        'values': 'values'
    }

    def __init__(self, name=None, version=None, values=None):
        r"""ListProductsRespMonthly

        The model defined in huaweicloud sdk

        :param name: **参数解释**： 消息引擎的名称，该字段显示为kafka。 **取值范围**： 不涉及。
        :type name: str
        :param version: **参数解释**： 消息引擎的版本。 **取值范围**： [- 3.8.35](tag:hws,hws_hk,hws_eu,cmcc,ctc,sbc,hk_sbc,g42,hk_g42,tm,hk_tm,ax,srg) [- 3.12.13](tag:srg) [- 3.13.7](tag:dt) [- AMQP-0-9-1](tag:hws,hws_hk,hws_eu)
        :type version: str
        :param values: **参数解释**： 产品规格列表。
        :type values: list[:class:`huaweicloudsdkrabbitmq.v2.ListProductsRespValues1`]
        """
        
        

        self._name = None
        self._version = None
        self._values = None
        self.discriminator = None

        if name is not None:
            self.name = name
        if version is not None:
            self.version = version
        if values is not None:
            self.values = values

    @property
    def name(self):
        r"""Gets the name of this ListProductsRespMonthly.

        **参数解释**： 消息引擎的名称，该字段显示为kafka。 **取值范围**： 不涉及。

        :return: The name of this ListProductsRespMonthly.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this ListProductsRespMonthly.

        **参数解释**： 消息引擎的名称，该字段显示为kafka。 **取值范围**： 不涉及。

        :param name: The name of this ListProductsRespMonthly.
        :type name: str
        """
        self._name = name

    @property
    def version(self):
        r"""Gets the version of this ListProductsRespMonthly.

        **参数解释**： 消息引擎的版本。 **取值范围**： [- 3.8.35](tag:hws,hws_hk,hws_eu,cmcc,ctc,sbc,hk_sbc,g42,hk_g42,tm,hk_tm,ax,srg) [- 3.12.13](tag:srg) [- 3.13.7](tag:dt) [- AMQP-0-9-1](tag:hws,hws_hk,hws_eu)

        :return: The version of this ListProductsRespMonthly.
        :rtype: str
        """
        return self._version

    @version.setter
    def version(self, version):
        r"""Sets the version of this ListProductsRespMonthly.

        **参数解释**： 消息引擎的版本。 **取值范围**： [- 3.8.35](tag:hws,hws_hk,hws_eu,cmcc,ctc,sbc,hk_sbc,g42,hk_g42,tm,hk_tm,ax,srg) [- 3.12.13](tag:srg) [- 3.13.7](tag:dt) [- AMQP-0-9-1](tag:hws,hws_hk,hws_eu)

        :param version: The version of this ListProductsRespMonthly.
        :type version: str
        """
        self._version = version

    @property
    def values(self):
        r"""Gets the values of this ListProductsRespMonthly.

        **参数解释**： 产品规格列表。

        :return: The values of this ListProductsRespMonthly.
        :rtype: list[:class:`huaweicloudsdkrabbitmq.v2.ListProductsRespValues1`]
        """
        return self._values

    @values.setter
    def values(self, values):
        r"""Sets the values of this ListProductsRespMonthly.

        **参数解释**： 产品规格列表。

        :param values: The values of this ListProductsRespMonthly.
        :type values: list[:class:`huaweicloudsdkrabbitmq.v2.ListProductsRespValues1`]
        """
        self._values = values

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListProductsRespMonthly):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
