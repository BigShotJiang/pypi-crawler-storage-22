# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class TaskOutputWebhook:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'url': 'str',
        'headers': 'object',
        'data_category': 'list[str]'
    }

    attribute_map = {
        'url': 'url',
        'headers': 'headers',
        'data_category': 'data_category'
    }

    def __init__(self, url=None, headers=None, data_category=None):
        r"""TaskOutputWebhook

        The model defined in huaweicloud sdk

        :param url: 结果回调地址，选用webhook类型输出时必填。
        :type url: str
        :param headers: 结果回调时需要携带的请求头，选用webhook类型输出时必填。整体呈json格式，以键值对的形式表示请求头和取值，至少1组，至多10组。
        :type headers: object
        :param data_category: 作业输出数据类别的列表，选填，仅部分服务需要。当输出类型下有这个列表时，表示希望这个输出类型下存放dataCategory列表内的数据。
        :type data_category: list[str]
        """
        
        

        self._url = None
        self._headers = None
        self._data_category = None
        self.discriminator = None

        self.url = url
        self.headers = headers
        if data_category is not None:
            self.data_category = data_category

    @property
    def url(self):
        r"""Gets the url of this TaskOutputWebhook.

        结果回调地址，选用webhook类型输出时必填。

        :return: The url of this TaskOutputWebhook.
        :rtype: str
        """
        return self._url

    @url.setter
    def url(self, url):
        r"""Sets the url of this TaskOutputWebhook.

        结果回调地址，选用webhook类型输出时必填。

        :param url: The url of this TaskOutputWebhook.
        :type url: str
        """
        self._url = url

    @property
    def headers(self):
        r"""Gets the headers of this TaskOutputWebhook.

        结果回调时需要携带的请求头，选用webhook类型输出时必填。整体呈json格式，以键值对的形式表示请求头和取值，至少1组，至多10组。

        :return: The headers of this TaskOutputWebhook.
        :rtype: object
        """
        return self._headers

    @headers.setter
    def headers(self, headers):
        r"""Sets the headers of this TaskOutputWebhook.

        结果回调时需要携带的请求头，选用webhook类型输出时必填。整体呈json格式，以键值对的形式表示请求头和取值，至少1组，至多10组。

        :param headers: The headers of this TaskOutputWebhook.
        :type headers: object
        """
        self._headers = headers

    @property
    def data_category(self):
        r"""Gets the data_category of this TaskOutputWebhook.

        作业输出数据类别的列表，选填，仅部分服务需要。当输出类型下有这个列表时，表示希望这个输出类型下存放dataCategory列表内的数据。

        :return: The data_category of this TaskOutputWebhook.
        :rtype: list[str]
        """
        return self._data_category

    @data_category.setter
    def data_category(self, data_category):
        r"""Sets the data_category of this TaskOutputWebhook.

        作业输出数据类别的列表，选填，仅部分服务需要。当输出类型下有这个列表时，表示希望这个输出类型下存放dataCategory列表内的数据。

        :param data_category: The data_category of this TaskOutputWebhook.
        :type data_category: list[str]
        """
        self._data_category = data_category

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, TaskOutputWebhook):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
