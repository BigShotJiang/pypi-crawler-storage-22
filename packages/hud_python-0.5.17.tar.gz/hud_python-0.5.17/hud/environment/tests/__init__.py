"""Tests for hud.environment module."""
