"""
Module: main
Description: Main CLI entry point for Huitzo

Implements:
    - docs/cli/reference.md
    - docs/guides/developer-environment.md#cli-interface

See Also:
    - docs/architecture/overview.md (for platform architecture)
"""

from typing import Optional

import typer
from rich.console import Console

from huitzo_cli.commands.auth import auth_app, login, logout
from huitzo_cli.commands.build import build_app
from huitzo_cli.commands.config_cmd import config_app
from huitzo_cli.commands.dashboard import dashboard_app
from huitzo_cli.commands.dev import dev_app
from huitzo_cli.commands.init import init_app
from huitzo_cli.commands.registry import publish, registry_app, run
from huitzo_cli.commands.secrets import secrets_app
from huitzo_cli.commands.test import test_app
from huitzo_cli.commands.validate import validate_app
from huitzo_cli.version import get_version

console = Console()
app = typer.Typer(help="Huitzo CLI for developing Intelligence Packs")


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: bool = typer.Option(False, "--version", help="Show version and exit"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Enable verbose output"),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output"),
    config: Optional[str] = typer.Option(None, "--config", help="Path to config file"),
) -> None:
    """Huitzo CLI for developing Intelligence Packs."""
    if version:
        console.print(f"huitzo-cli {get_version()}")
        raise typer.Exit(0)

    # Store options in context for subcommands
    ctx.obj = {
        "verbose": verbose,
        "quiet": quiet,
        "config": config,
    }

    if ctx.invoked_subcommand is None and not version:
        console.print(ctx.get_help())


# Top-level shortcuts for common commands
app.command("login")(login)
app.command("logout")(logout)
app.command("publish")(publish)
app.command("run")(run)

# Register command groups
app.add_typer(auth_app, name="auth", help="Authentication commands")
app.add_typer(init_app, name="init", help="Initialize a new Intelligence Pack")
app.add_typer(validate_app, name="validate", help="Validate pack structure")
app.add_typer(test_app, name="test", help="Run pack tests")
app.add_typer(build_app, name="build", help="Build pack")
app.add_typer(dev_app, name="dev", help="Start development session")
app.add_typer(registry_app, name="registry", help="Registry operations")
app.add_typer(config_app, name="config", help="Manage configuration")
app.add_typer(secrets_app, name="secrets", help="Manage secrets")
app.add_typer(dashboard_app, name="dashboard", help="Dashboard operations")


if __name__ == "__main__":
    app()
