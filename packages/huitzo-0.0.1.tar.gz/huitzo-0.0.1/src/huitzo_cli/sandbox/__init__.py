"""
Module: sandbox
Description: Local development sandbox for testing pack commands.

Implements:
    - docs/guides/developer-environment.md#development-session-flow
    - docs/cli/reference.md#huitzo-dev
"""
