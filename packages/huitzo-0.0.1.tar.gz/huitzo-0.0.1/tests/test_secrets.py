"""
Module: test_secrets
Description: Tests for secrets management

Implements:
    - docs/cli/reference.md#huitzo-secrets
"""

from pathlib import Path

import pytest
from typer.testing import CliRunner

from huitzo_cli.commands.secrets import SecretsStore, secrets_app


def test_secrets_store_set(temp_dir: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Test setting a secret."""

    def mock_get_secrets_dir():
        return temp_dir / "secrets"

    monkeypatch.setattr(SecretsStore, "_get_secrets_dir", mock_get_secrets_dir)

    SecretsStore.set("test_key", "test_value")

    secrets = SecretsStore.list_secrets()
    assert "test_key" in secrets
    assert secrets["test_key"] == "test_value"


def test_secrets_store_get(temp_dir: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Test getting a secret."""

    def mock_get_secrets_dir():
        return temp_dir / "secrets"

    monkeypatch.setattr(SecretsStore, "_get_secrets_dir", mock_get_secrets_dir)

    SecretsStore.set("test_key", "test_value")
    value = SecretsStore.get("test_key")

    assert value == "test_value"


def test_secrets_store_remove(temp_dir: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Test removing a secret."""

    def mock_get_secrets_dir():
        return temp_dir / "secrets"

    monkeypatch.setattr(SecretsStore, "_get_secrets_dir", mock_get_secrets_dir)

    SecretsStore.set("test_key", "test_value")
    SecretsStore.remove("test_key")

    value = SecretsStore.get("test_key")
    assert value is None


def test_secrets_command_set(
    cli_runner: CliRunner, temp_dir: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Test setting secret via command."""

    def mock_get_secrets_dir():
        return temp_dir / "secrets"

    monkeypatch.setattr(SecretsStore, "_get_secrets_dir", mock_get_secrets_dir)

    result = cli_runner.invoke(secrets_app, ["set", "test_key", "test_value"])
    assert result.exit_code == 0
    assert "Secret 'test_key' set" in result.stdout


def test_secrets_command_list(
    cli_runner: CliRunner, temp_dir: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Test listing secrets via command."""

    def mock_get_secrets_dir():
        return temp_dir / "secrets"

    monkeypatch.setattr(SecretsStore, "_get_secrets_dir", mock_get_secrets_dir)

    SecretsStore.set("test_key", "test_value")

    result = cli_runner.invoke(secrets_app, ["list-secrets"])
    assert result.exit_code == 0
    assert "test_key" in result.stdout


def test_secrets_command_remove(
    cli_runner: CliRunner, temp_dir: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Test removing secret via command."""

    def mock_get_secrets_dir():
        return temp_dir / "secrets"

    monkeypatch.setattr(SecretsStore, "_get_secrets_dir", mock_get_secrets_dir)

    SecretsStore.set("test_key", "test_value")

    result = cli_runner.invoke(secrets_app, ["remove", "test_key"])
    assert result.exit_code == 0
    assert "removed" in result.stdout
