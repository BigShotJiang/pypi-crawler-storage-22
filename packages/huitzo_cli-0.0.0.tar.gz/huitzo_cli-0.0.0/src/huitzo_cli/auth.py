"""
Module: auth
Description: Authentication client and token storage

Implements:
    - docs/cli/reference.md#huitzo-login
    - docs/guides/developer-environment.md#authentication

See Also:
    - docs/reference/secrets.md (for secure storage patterns)
"""

import os
from pathlib import Path
from typing import Any, Optional

from huitzo_cli.config import ConfigManager


class TokenStore:
    """Manages authentication tokens securely."""

    def __init__(self) -> None:
        """Initialize token store."""
        self.token_path = self._get_token_path()

    @staticmethod
    def _get_token_path() -> Path:
        """Get platform-specific token file path."""
        if os.name == "nt":  # Windows
            base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
            return base / "huitzo" / "token"
        else:  # Unix-like
            return Path.home() / ".huitzo" / "token"

    def save(self, token: str) -> None:
        """Save token to secure storage.

        Args:
            token: Authentication token to save
        """
        self.token_path.parent.mkdir(parents=True, exist_ok=True)

        # Save token
        with open(self.token_path, "w") as f:
            f.write(token)

        # Set restrictive permissions (Unix-like only)
        if os.name != "nt":
            self.token_path.chmod(0o600)
            self.token_path.parent.chmod(0o700)

    def load(self) -> Optional[str]:
        """Load token from secure storage.

        Returns:
            Token if it exists, None otherwise
        """
        if not self.token_path.exists():
            return None

        try:
            with open(self.token_path) as f:
                return f.read().strip()
        except OSError:
            return None

    def delete(self) -> None:
        """Delete stored token."""
        if self.token_path.exists():
            try:
                self.token_path.unlink()
            except OSError:
                pass


class AuthClient:
    """Client for handling authentication with Huitzo Cloud.

    Note: Huitzo Cloud is not yet available. This is a placeholder implementation.
    """

    def __init__(self, config_manager: ConfigManager) -> None:
        """Initialize auth client.

        Args:
            config_manager: Configuration manager instance
        """
        self.config = config_manager
        self.token_store = TokenStore()

    def login(self, token: Optional[str] = None) -> None:
        """Login to Huitzo Cloud.

        Args:
            token: Optional token for testing. If None, will attempt cloud auth (not yet available).
        """
        if token:
            # Save token for testing
            self.token_store.save(token)
            self.config.set("auth.token", token, scope="user")
        else:
            # Cloud authentication would happen here
            raise RuntimeError("Huitzo Cloud is not yet available")

    def logout(self) -> None:
        """Logout and remove stored token."""
        self.token_store.delete()
        self.config.set("auth.token", None, scope="user")

    def get_token(self) -> Optional[str]:
        """Get current authentication token.

        Returns:
            Token if authenticated, None otherwise
        """
        # Try config first
        config_token = self.config.get("auth.token")
        if config_token is not None and isinstance(config_token, str):
            return str(config_token)

        # Try token file
        token = self.token_store.load()
        if token:
            return token

        return None

    def is_authenticated(self) -> bool:
        """Check if user is authenticated.

        Returns:
            True if authenticated, False otherwise
        """
        return self.get_token() is not None

    def get_current_user(self) -> Optional[dict[str, Any]]:
        """Get current authenticated user info.

        Note: Returns None until cloud is available.

        Returns:
            User info dict if authenticated, None otherwise
        """
        # Cloud API would be called here
        return None
