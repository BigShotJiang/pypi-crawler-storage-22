"""
Module: auth_command
Description: Login and logout commands

Implements:
    - docs/cli/reference.md#huitzo-login
    - docs/guides/developer-environment.md#authentication
"""

from typing import Optional

import typer
from rich.console import Console

from huitzo_cli.auth import AuthClient
from huitzo_cli.config import ConfigManager

console = Console()
auth_app = typer.Typer(help="Authentication commands", invoke_without_command=True)


@auth_app.command()
def login(
    token: Optional[str] = typer.Option(
        None,
        "--token",
        help="Authentication token (for testing only)",
    ),
) -> None:
    """Login to Huitzo Cloud.

    Note: Huitzo Cloud is not yet available. Use --token for testing.
    """
    config = ConfigManager()
    auth_client = AuthClient(config)

    if not token:
        console.print("[yellow]ℹ️  Huitzo Cloud is not yet available[/yellow]")
        console.print("Use [bold]--token <value>[/bold] for testing")
        raise typer.Exit(1)

    try:
        auth_client.login(token=token)
        console.print("[green]✅ Logged in successfully[/green]")
    except Exception as e:
        console.print(f"[red]❌ Login failed: {e}[/red]")
        raise typer.Exit(1)


@auth_app.command()
def logout() -> None:
    """Logout from Huitzo Cloud."""
    config = ConfigManager()
    auth_client = AuthClient(config)

    try:
        auth_client.logout()
        console.print("[green]✅ Logged out successfully[/green]")
    except Exception as e:
        console.print(f"[red]❌ Logout failed: {e}[/red]")
        raise typer.Exit(1)
