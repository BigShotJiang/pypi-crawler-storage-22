"""
Module: init_command
Description: Pack initialization command with scaffolding

Implements:
    - docs/cli/reference.md#huitzo-init
"""

import re
from pathlib import Path
from typing import Optional

import typer
from jinja2 import Environment, PackageLoader
from rich.console import Console

console = Console()
init_app = typer.Typer(help="Initialize a new Intelligence Pack")


def validate_name(name: str) -> bool:
    """Validate pack name (lowercase with hyphens only)."""
    return bool(re.match(r"^[a-z0-9]([a-z0-9-]*[a-z0-9])?$", name))


def validate_namespace(namespace: str) -> bool:
    """Validate namespace (lowercase with hyphens only)."""
    return bool(re.match(r"^[a-z0-9]([a-z0-9-]*[a-z0-9])?$", namespace))


def name_to_module(name: str) -> str:
    """Convert pack name to Python module name."""
    return name.replace("-", "_")


@init_app.command()
def init(
    name: Optional[str] = typer.Argument(None, help="Pack name (e.g., my-pack)"),
    namespace: Optional[str] = typer.Option(None, "--namespace", help="Pack namespace"),
    author: Optional[str] = typer.Option(None, "--author", help="Author name"),
    author_email: Optional[str] = typer.Option(None, "--email", help="Author email"),
    description: Optional[str] = typer.Option(None, "--description", help="Pack description"),
) -> None:
    """Initialize a new Intelligence Pack with scaffolding.

    Creates a project structure with:
    - pyproject.toml (package configuration)
    - huitzo.yaml (pack manifest)
    - Example command and tests
    - README and gitignore
    """
    # Get pack name
    if not name:
        name = typer.prompt("Pack name (lowercase, hyphens OK)")

    if not validate_name(name):
        console.print(
            "[red]❌ Invalid pack name. Use lowercase letters, numbers, and hyphens.[/red]"
        )
        raise typer.Exit(1)

    # Get namespace
    if not namespace:
        namespace = typer.prompt("Namespace (lowercase, hyphens OK)", default=name)

    if not validate_namespace(namespace):
        console.print(
            "[red]❌ Invalid namespace. Use lowercase letters, numbers, and hyphens.[/red]"
        )
        raise typer.Exit(1)

    # Get author info
    if not author:
        author = typer.prompt("Author name", default="Developer")

    if not author_email:
        author_email = typer.prompt("Author email", default="dev@example.com")

    # Get description
    if not description:
        description = typer.prompt("Description", default=f"Intelligence Pack: {name}")

    # Create project directory
    project_root = Path.cwd() / name
    if project_root.exists():
        console.print(f"[red]❌ Directory '{name}' already exists[/red]")
        raise typer.Exit(1)

    project_root.mkdir(parents=True, exist_ok=True)
    module_name = name_to_module(name)

    # Set up Jinja2 environment
    env = Environment(loader=PackageLoader("huitzo_cli", "templates/pack"))

    # Template context
    context = {
        "pack_name": name,
        "namespace": namespace,
        "module_name": module_name,
        "author": author,
        "author_email": author_email,
        "description": description,
    }

    # Create directory structure
    src_dir = project_root / "src" / module_name
    src_dir.mkdir(parents=True, exist_ok=True)

    commands_dir = src_dir / "commands"
    commands_dir.mkdir(parents=True, exist_ok=True)

    tests_dir = project_root / "tests"
    tests_dir.mkdir(parents=True, exist_ok=True)

    # Render templates
    files_to_create = {
        "pyproject.toml.j2": project_root / "pyproject.toml",
        "huitzo.yaml.j2": project_root / "huitzo.yaml",
        "README.md.j2": project_root / "README.md",
        ".gitignore.j2": project_root / ".gitignore",
        "__init__.py.j2": src_dir / "__init__.py",
        "hello.py.j2": commands_dir / "hello.py",
        "test_hello.py.j2": tests_dir / "test_hello.py",
    }

    for template_name, target_path in files_to_create.items():
        template = env.get_template(template_name)
        content = template.render(**context)
        target_path.write_text(content)

    # Create __init__.py for commands directory
    (commands_dir / "__init__.py").write_text('"""Commands for this pack."""\n')

    # Create __init__.py for tests directory
    (tests_dir / "__init__.py").write_text('"""Tests for this pack."""\n')

    console.print(f"\n[green]✅ Pack '{name}' initialized successfully![/green]")
    console.print("\n[bold]Next steps:[/bold]")
    console.print(f"  cd {name}")
    console.print("  huitzo validate")
    console.print("  huitzo test")
    console.print("  huitzo dev")
