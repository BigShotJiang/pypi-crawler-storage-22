"""
Module: registry_command
Description: Registry operations (publish, install, list, run)

Implements:
    - docs/cli/reference.md#huitzo-publish
    - docs/cli/reference.md#huitzo-install
    - docs/cli/reference.md#huitzo-list
    - docs/cli/reference.md#huitzo-run
"""

import subprocess
from pathlib import Path

import typer
from rich.console import Console

console = Console()
registry_app = typer.Typer(help="Registry operations")


@registry_app.command()
def publish() -> None:
    """Publish pack to Huitzo Registry.

    Note: Requires Huitzo Cloud (not yet available).
    """
    console.print("[yellow]ℹ️  Huitzo Cloud Registry is not yet available[/yellow]")
    console.print("This feature is coming soon!")
    raise typer.Exit(1)


@registry_app.command()
def install(
    package: str = typer.Argument(..., help="Package name or path to .whl file"),
) -> None:
    """Install a pack from registry or local file.

    Args:
        package: Package name (from registry) or path to .whl file
    """
    # Check if it's a local file
    if package.endswith(".whl"):
        path = Path(package)
        if not path.exists():
            console.print(f"[red]❌ File not found: {package}[/red]")
            raise typer.Exit(1)

        console.print(f"[bold]Installing from: {package}[/bold]")
        try:
            result = subprocess.run(["pip", "install", str(path)], check=False)
            if result.returncode != 0:
                raise typer.Exit(result.returncode)
            console.print("[green]✅ Installation successful[/green]")
        except FileNotFoundError:
            console.print("[red]❌ pip not found[/red]")
            raise typer.Exit(1)
    else:
        # Try to install from registry
        console.print(f"[bold]Installing: {package}[/bold]")
        console.print("[yellow]ℹ️  Huitzo Cloud Registry is not yet available[/yellow]")
        console.print("Use a local .whl file or install from PyPI")
        raise typer.Exit(1)


@registry_app.command()
def list_packs() -> None:
    """List installed packs."""
    console.print("[bold]Installed Huitzo Packs:[/bold]")

    try:
        result = subprocess.run(
            ["pip", "list", "--format", "json"],
            capture_output=True,
            text=True,
            check=True,
        )
        import json

        packages = json.loads(result.stdout)
        huitzo_packs = [p for p in packages if "pack" in p["name"].lower()]

        if huitzo_packs:
            for pack in huitzo_packs:
                console.print(f"  • {pack['name']} ({pack['version']})")
        else:
            console.print("  (none installed)")
    except (FileNotFoundError, json.JSONDecodeError):
        console.print("[yellow]⚠️  Could not list packages[/yellow]")


@registry_app.command()
def run(
    pack_command: str = typer.Argument(..., help="Pack command (e.g., my-pack:hello)"),
) -> None:
    """Run a pack command.

    Note: Requires Huitzo Cloud (not yet available).

    Args:
        pack_command: Pack and command name (format: pack-name:command-name)
    """
    console.print("[yellow]ℹ️  Cloud execution is not yet available[/yellow]")
    console.print("This feature is coming soon!")
    raise typer.Exit(1)
