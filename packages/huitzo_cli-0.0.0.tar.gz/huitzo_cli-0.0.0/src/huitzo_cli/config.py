"""
Module: config
Description: Configuration management with hierarchy support

Implements:
    - docs/guides/developer-environment.md#configuration
    - docs/cli/reference.md#huitzo-config

See Also:
    - docs/cli/reference.md (for configuration schema)
"""

import os
from pathlib import Path
from typing import Any, Dict, Optional

import yaml
from pydantic import BaseModel, ConfigDict


class AuthConfig(BaseModel):
    """Authentication configuration."""

    model_config = ConfigDict(extra="allow")

    token: Optional[str] = None
    token_file: Optional[str] = None


class DevConfig(BaseModel):
    """Development configuration."""

    model_config = ConfigDict(extra="allow")

    port: int = 8080
    verbose: bool = False
    auto_reload: bool = True
    persist_sandbox: bool = False


class CLIConfig(BaseModel):
    """Main CLI configuration."""

    model_config = ConfigDict(extra="allow")

    api_url: str = "https://api.huitzo.dev"
    auth: AuthConfig = AuthConfig()
    dev: DevConfig = DevConfig()


class ConfigManager:
    """Manages CLI configuration with hierarchy support.

    Configuration hierarchy (highest to lowest priority):
    1. Environment variables (HUITZO_*)
    2. Command-line options passed to ConfigManager
    3. User config (~/.config/huitzo/config.yaml)
    4. Project config (./huitzo.yaml)
    5. Defaults (built-in)
    """

    def __init__(self, project_root: Optional[Path] = None) -> None:
        """Initialize configuration manager.

        Args:
            project_root: Root directory for project config. If None, uses current directory.
        """
        self.project_root = project_root or Path.cwd()
        self._config = self._load_config()

    @staticmethod
    def _get_config_dir() -> Path:
        """Get platform-specific config directory."""
        if os.name == "nt":  # Windows
            base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
            return base / "huitzo"
        else:  # Unix-like
            xdg_config = os.environ.get("XDG_CONFIG_HOME")
            if xdg_config:
                return Path(xdg_config) / "huitzo"
            return Path.home() / ".config" / "huitzo"

    @staticmethod
    def _get_token_file() -> Path:
        """Get platform-specific token file path."""
        if os.name == "nt":  # Windows
            base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
            return base / "huitzo" / "token"
        else:  # Unix-like
            return Path.home() / ".huitzo" / "token"

    def _load_from_env(self) -> Dict[str, Any]:
        """Load configuration from environment variables."""
        config: Dict[str, Any] = {}

        if api_url := os.environ.get("HUITZO_API_URL"):
            config["api_url"] = api_url

        if token := os.environ.get("HUITZO_TOKEN"):
            config.setdefault("auth", {})
            config["auth"]["token"] = token

        if dev_port := os.environ.get("HUITZO_DEV_PORT"):
            config.setdefault("dev", {})
            config["dev"]["port"] = int(dev_port)

        return config

    def _load_from_yaml(self, path: Path) -> Dict[str, Any]:
        """Load configuration from YAML file."""
        if not path.exists():
            return {}

        try:
            with open(path) as f:
                data = yaml.safe_load(f)
                return data or {}
        except (OSError, yaml.YAMLError):
            return {}

    def _load_config(self) -> CLIConfig:
        """Load and merge configuration from all sources."""
        config_dict: Dict[str, Any] = {}

        # 1. Project config (lowest priority)
        project_config_path = self.project_root / "huitzo.yaml"
        project_config = self._load_from_yaml(project_config_path)
        config_dict.update(project_config)

        # 2. User config
        user_config_path = self._get_config_dir() / "config.yaml"
        user_config = self._load_from_yaml(user_config_path)
        config_dict.update(user_config)

        # 3. Environment variables (highest priority)
        env_config = self._load_from_env()
        config_dict.update(env_config)

        # Parse into CLIConfig model
        return CLIConfig(**config_dict)

    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value by dot-notation key.

        Examples:
            - "api_url"
            - "auth.token"
            - "dev.port"
        """
        parts = key.split(".")
        value: Any = self._config

        for part in parts:
            if isinstance(value, dict):
                value = value.get(part)
            elif hasattr(value, part):
                value = getattr(value, part)
            else:
                return default

            if value is None:
                return default

        return value

    def set(self, key: str, value: Any, scope: str = "user") -> None:
        """Set configuration value and save to file.

        Args:
            key: Configuration key (e.g., "auth.token")
            value: Value to set
            scope: Where to save ("user" or "project")
        """
        if scope == "user":
            config_path = self._get_config_dir() / "config.yaml"
            config_path.parent.mkdir(parents=True, exist_ok=True)
            # Set restrictive permissions on parent directory
            config_path.parent.chmod(0o700)
        else:
            config_path = self.project_root / "huitzo.yaml"

        # Load existing config
        existing = self._load_from_yaml(config_path) if config_path.exists() else {}

        # Update nested value
        parts = key.split(".")
        current = existing
        for part in parts[:-1]:
            if part not in current:
                current[part] = {}
            current = current[part]
        current[parts[-1]] = value

        # Save to file
        config_path.parent.mkdir(parents=True, exist_ok=True)
        with open(config_path, "w") as f:
            yaml.dump(existing, f, default_flow_style=False)

        # Set restrictive permissions on config file (Unix-like only)
        if os.name != "nt":
            config_path.chmod(0o600)

        # Reload configuration
        self._config = self._load_config()

    def to_dict(self) -> Dict[str, Any]:
        """Get configuration as dictionary."""
        return self._config.model_dump()

    def get_config_path(self, scope: str = "user") -> Path:
        """Get the path to the config file.

        Args:
            scope: "user" or "project"
        """
        if scope == "user":
            return self._get_config_dir() / "config.yaml"
        else:
            return self.project_root / "huitzo.yaml"
