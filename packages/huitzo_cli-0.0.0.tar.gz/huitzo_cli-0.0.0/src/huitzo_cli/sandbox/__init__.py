"""Cloud sandbox integration."""
