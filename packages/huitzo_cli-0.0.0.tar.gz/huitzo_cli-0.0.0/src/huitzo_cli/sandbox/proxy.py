"""
Module: proxy
Description: Local proxy to cloud sandbox (STUBBED - cloud not yet available)

Implements:
    - docs/guides/developer-environment.md#development-session-flow
"""

from typing import Optional


class SandboxProxy:
    """Local proxy for cloud sandbox.

    Note: Huitzo Cloud is not yet available. This is a placeholder implementation.
    Future implementation will:
    - Upload pack to cloud sandbox
    - Provide localhost proxy for development
    - Handle file watching and auto-reload
    """

    def __init__(self, api_url: str = "https://api.huitzo.dev") -> None:
        """Initialize sandbox proxy.

        Args:
            api_url: URL of Huitzo Cloud API
        """
        self.api_url = api_url
        self.proxy_url = "http://localhost:8080"

    def start(self, pack_path: str, port: int = 8080) -> None:
        """Start local proxy to sandbox.

        Args:
            pack_path: Path to pack to upload
            port: Local port for proxy

        Raises:
            RuntimeError: If cloud is not available
        """
        raise RuntimeError("Huitzo Cloud is not yet available")

    def stop(self) -> None:
        """Stop local proxy."""
        pass

    def upload_pack(self, pack_path: str) -> Optional[str]:
        """Upload pack to sandbox.

        Args:
            pack_path: Path to pack to upload

        Returns:
            Sandbox ID if successful, None otherwise

        Raises:
            RuntimeError: If cloud is not available
        """
        raise RuntimeError("Huitzo Cloud is not yet available")

    def watch_files(self, pack_path: str) -> None:
        """Watch pack files for changes and auto-reload.

        Args:
            pack_path: Path to pack to watch
        """
        pass

    def cleanup(self, sandbox_id: str) -> None:
        """Clean up cloud sandbox.

        Args:
            sandbox_id: ID of sandbox to clean up
        """
        pass
