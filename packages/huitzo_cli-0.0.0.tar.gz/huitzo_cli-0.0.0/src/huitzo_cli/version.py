"""
Module: version
Description: Version management for Huitzo CLI

Implements:
    - docs/cli/reference.md#version-management
"""

__version__ = "0.0.0"


def get_version() -> str:
    """Get the current version of Huitzo CLI."""
    return __version__
