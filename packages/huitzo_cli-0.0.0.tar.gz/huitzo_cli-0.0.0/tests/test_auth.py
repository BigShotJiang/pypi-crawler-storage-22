"""
Module: test_auth
Description: Tests for authentication

Implements:
    - docs/cli/reference.md#huitzo-login
"""

from pathlib import Path
from typing import Generator
from unittest.mock import patch

import pytest
from typer.testing import CliRunner

from huitzo_cli.auth import AuthClient, TokenStore
from huitzo_cli.commands.auth import auth_app
from huitzo_cli.config import ConfigManager


@pytest.fixture
def temp_token_file(temp_dir: Path) -> Generator[Path, None, None]:
    """Provide a temporary token file."""
    token_file = temp_dir / "token"
    with patch.object(TokenStore, "_get_token_path", return_value=token_file):
        yield token_file


def test_token_store_save(temp_token_file: Path) -> None:
    """Test saving token."""
    store = TokenStore()
    store.save("test-token")

    assert temp_token_file.exists()
    assert temp_token_file.read_text().strip() == "test-token"


def test_token_store_load(temp_token_file: Path) -> None:
    """Test loading token."""
    temp_token_file.parent.mkdir(parents=True, exist_ok=True)
    temp_token_file.write_text("test-token")

    store = TokenStore()
    assert store.load() == "test-token"


def test_token_store_load_missing() -> None:
    """Test loading when token doesn't exist."""
    store = TokenStore()
    # Mock the token path to a non-existent location
    with patch.object(TokenStore, "_get_token_path", return_value=Path("/nonexistent/token")):
        store = TokenStore()
        assert store.load() is None


def test_token_store_delete(temp_token_file: Path) -> None:
    """Test deleting token."""
    temp_token_file.parent.mkdir(parents=True, exist_ok=True)
    temp_token_file.write_text("test-token")

    store = TokenStore()
    store.delete()

    assert not temp_token_file.exists()


def test_auth_client_login(temp_dir: Path, temp_token_file: Path) -> None:
    """Test auth client login."""
    config = ConfigManager(project_root=temp_dir)
    auth_client = AuthClient(config)

    auth_client.login(token="test-token")

    assert auth_client.is_authenticated()
    assert auth_client.get_token() == "test-token"


def test_auth_client_logout(temp_dir: Path, temp_token_file: Path) -> None:
    """Test auth client logout."""
    config = ConfigManager(project_root=temp_dir)
    auth_client = AuthClient(config)

    auth_client.login(token="test-token")
    assert auth_client.is_authenticated()

    auth_client.logout()
    assert not auth_client.is_authenticated()


def test_auth_client_get_token(temp_dir: Path, temp_token_file: Path) -> None:
    """Test getting token from client."""
    config = ConfigManager(project_root=temp_dir)
    auth_client = AuthClient(config)

    auth_client.login(token="test-token")
    assert auth_client.get_token() == "test-token"


def test_auth_command_login_with_token(
    cli_runner: CliRunner, temp_dir: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Test login command with token."""
    # Mock config directory
    config_dir = temp_dir / "config"
    monkeypatch.setattr(ConfigManager, "_get_config_dir", staticmethod(lambda: config_dir))

    # Mock token store
    token_file = temp_dir / "token"
    monkeypatch.setattr(TokenStore, "_get_token_path", staticmethod(lambda: token_file))

    result = cli_runner.invoke(auth_app, ["login", "--token", "test-token"])

    assert result.exit_code == 0
    assert "Logged in successfully" in result.stdout


def test_auth_command_login_without_token(cli_runner: CliRunner) -> None:
    """Test login command without token shows cloud not available."""
    result = cli_runner.invoke(auth_app, ["login"])

    assert result.exit_code == 1
    assert "Huitzo Cloud is not yet available" in result.stdout


def test_auth_command_logout(
    cli_runner: CliRunner, temp_dir: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Test logout command."""
    # Mock config directory
    config_dir = temp_dir / "config"
    monkeypatch.setattr(ConfigManager, "_get_config_dir", staticmethod(lambda: config_dir))

    # Mock token store
    token_file = temp_dir / "token"
    token_file.parent.mkdir(parents=True, exist_ok=True)
    token_file.write_text("test-token")
    monkeypatch.setattr(TokenStore, "_get_token_path", staticmethod(lambda: token_file))

    result = cli_runner.invoke(auth_app, ["logout"])

    assert result.exit_code == 0
    assert "Logged out successfully" in result.stdout
