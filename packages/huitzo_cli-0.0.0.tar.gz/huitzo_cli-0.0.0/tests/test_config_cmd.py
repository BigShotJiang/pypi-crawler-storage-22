"""
Module: test_config_cmd
Description: Tests for configuration management commands

Implements:
    - docs/cli/reference.md#huitzo-config
"""

from pathlib import Path

from typer.testing import CliRunner

from huitzo_cli.commands.config_cmd import config_app
from huitzo_cli.config import ConfigManager


def test_config_get(cli_runner: CliRunner, temp_dir: Path, monkeypatch) -> None:
    """Test getting config value."""
    monkeypatch.setattr(ConfigManager, "_get_config_dir", staticmethod(lambda: temp_dir / "config"))

    result = cli_runner.invoke(config_app, ["get", "api_url"])
    assert result.exit_code == 0
    assert "https://api.huitzo.dev" in result.stdout


def test_config_set(cli_runner: CliRunner, temp_dir: Path, monkeypatch) -> None:
    """Test setting config value."""
    monkeypatch.setattr(ConfigManager, "_get_config_dir", staticmethod(lambda: temp_dir / "config"))

    result = cli_runner.invoke(config_app, ["set", "api_url", "https://test.example.com"])
    assert result.exit_code == 0
    assert "set to" in result.stdout


def test_config_list(cli_runner: CliRunner, temp_dir: Path, monkeypatch) -> None:
    """Test listing config values."""
    monkeypatch.setattr(ConfigManager, "_get_config_dir", staticmethod(lambda: temp_dir / "config"))

    result = cli_runner.invoke(config_app, ["list-config"])
    assert result.exit_code == 0
    assert "api_url" in result.stdout


def test_config_path(cli_runner: CliRunner, temp_dir: Path, monkeypatch) -> None:
    """Test showing config path."""
    monkeypatch.setattr(ConfigManager, "_get_config_dir", staticmethod(lambda: temp_dir / "config"))

    result = cli_runner.invoke(config_app, ["path"])
    assert result.exit_code == 0
    assert "config.yaml" in result.stdout
