"""
Module: test_dashboard
Description: Tests for dashboard commands

Implements:
    - docs/cli/reference.md#dashboard-commands
"""

from pathlib import Path
from unittest.mock import patch

from typer.testing import CliRunner

from huitzo_cli.commands.dashboard import dashboard_app


def test_dashboard_new(temp_dir: Path) -> None:
    """Test creating new dashboard."""
    runner = CliRunner()

    import os

    old_cwd = os.getcwd()
    try:
        os.chdir(temp_dir)

        result = runner.invoke(dashboard_app, ["new", "test-dashboard"])

        assert result.exit_code == 0
        assert "created" in result.stdout

        # Verify structure
        dashboard_dir = temp_dir / "test-dashboard"
        assert (dashboard_dir / "package.json").exists()
        assert (dashboard_dir / "vite.config.ts").exists()
        assert (dashboard_dir / "index.html").exists()
        assert (dashboard_dir / "src" / "main.tsx").exists()

    finally:
        os.chdir(old_cwd)


def test_dashboard_new_exists(temp_dir: Path) -> None:
    """Test creating dashboard when directory exists."""
    runner = CliRunner()

    dashboard_dir = temp_dir / "existing"
    dashboard_dir.mkdir()

    import os

    old_cwd = os.getcwd()
    try:
        os.chdir(temp_dir)

        result = runner.invoke(dashboard_app, ["new", "existing"])
        assert result.exit_code == 1
        assert "already exists" in result.stdout

    finally:
        os.chdir(old_cwd)


def test_dashboard_dev(cli_runner: CliRunner) -> None:
    """Test dev command."""
    with patch("subprocess.run") as mock_run:
        mock_run.return_value.returncode = 0

        _result = cli_runner.invoke(dashboard_app, ["dev"])
        # Should attempt to run npm


def test_dashboard_build(cli_runner: CliRunner) -> None:
    """Test build command."""
    with patch("subprocess.run") as mock_run:
        mock_run.return_value.returncode = 0

        _result = cli_runner.invoke(dashboard_app, ["build"])
        # Should attempt to run npm


def test_dashboard_publish(cli_runner: CliRunner) -> None:
    """Test publish shows not available."""
    result = cli_runner.invoke(dashboard_app, ["publish"])
    assert result.exit_code == 1
    assert "not yet available" in result.stdout


def test_dashboard_grant(cli_runner: CliRunner) -> None:
    """Test grant shows not available."""
    result = cli_runner.invoke(dashboard_app, ["grant", "--user", "test@example.com"])
    assert result.exit_code == 1
    assert "not yet available" in result.stdout


def test_dashboard_share(cli_runner: CliRunner) -> None:
    """Test share shows not available."""
    result = cli_runner.invoke(dashboard_app, ["share"])
    assert result.exit_code == 1
    assert "not yet available" in result.stdout
