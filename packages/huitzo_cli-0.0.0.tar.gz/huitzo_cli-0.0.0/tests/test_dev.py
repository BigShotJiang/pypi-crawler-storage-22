"""
Module: test_dev
Description: Tests for development session command

Implements:
    - docs/cli/reference.md#huitzo-dev
"""

from pathlib import Path
from unittest.mock import patch


from huitzo_cli.sandbox.proxy import SandboxProxy
from huitzo_cli.docs_server.server import DocsServer


def test_sandbox_proxy_not_available() -> None:
    """Test that sandbox proxy raises error when cloud not available."""
    proxy = SandboxProxy()

    try:
        proxy.start(".")
        assert False, "Should have raised RuntimeError"
    except RuntimeError as e:
        assert "not yet available" in str(e)


def test_docs_server_init() -> None:
    """Test docs server initialization."""
    server = DocsServer(port=8124)
    assert server.port == 8124
    assert not server.is_running()


def test_docs_server_manifest() -> None:
    """Test getting MCP manifest."""
    server = DocsServer()
    manifest = server.get_mcp_manifest()

    assert "name" in manifest
    assert "version" in manifest
    assert "endpoints" in manifest


def test_docs_server_ensure_docs(temp_dir: Path) -> None:
    """Test docs directory creation."""
    docs_dir = temp_dir / "docs"

    server = DocsServer(docs_dir=docs_dir)

    # Mock git to avoid actual clone
    with patch("subprocess.run") as mock_run:
        mock_run.return_value.returncode = 0

        # Create the directory to avoid clone attempt
        docs_dir.mkdir(parents=True, exist_ok=True)

        result = server.ensure_docs()
        assert result.exists()


def test_docs_server_stop_without_start() -> None:
    """Test stopping server when not running."""
    server = DocsServer()
    server.stop()  # Should not raise error
