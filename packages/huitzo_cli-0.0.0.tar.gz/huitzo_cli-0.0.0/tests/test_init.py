"""
Module: test_init
Description: Tests for pack initialization

Implements:
    - docs/cli/reference.md#huitzo-init
"""

from pathlib import Path

from typer.testing import CliRunner

from huitzo_cli.commands.init import init_app, validate_name, validate_namespace


def test_validate_name_valid() -> None:
    """Test valid pack names."""
    assert validate_name("my-pack")
    assert validate_name("hello-world")
    assert validate_name("pack123")
    assert validate_name("a")


def test_validate_name_invalid() -> None:
    """Test invalid pack names."""
    assert not validate_name("MyPack")  # uppercase
    assert not validate_name("my_pack")  # underscore
    assert not validate_name("-my-pack")  # starts with hyphen
    assert not validate_name("my-pack-")  # ends with hyphen
    assert not validate_name("")  # empty


def test_validate_namespace_valid() -> None:
    """Test valid namespaces."""
    assert validate_namespace("my-namespace")
    assert validate_namespace("hello")
    assert validate_namespace("ns123")


def test_validate_namespace_invalid() -> None:
    """Test invalid namespaces."""
    assert not validate_namespace("MyNamespace")  # uppercase
    assert not validate_namespace("my_namespace")  # underscore


def test_init_command_with_args(temp_dir: Path) -> None:
    """Test init command with all arguments provided."""
    runner = CliRunner()

    # Change to temp directory
    import os

    old_cwd = os.getcwd()
    try:
        os.chdir(temp_dir)

        result = runner.invoke(
            init_app,
            [
                "test-pack",
                "--namespace",
                "test",
                "--author",
                "Test Author",
                "--email",
                "test@example.com",
                "--description",
                "Test Pack",
            ],
        )

        assert result.exit_code == 0
        assert "Pack 'test-pack' initialized successfully!" in result.stdout

        # Verify structure
        pack_dir = temp_dir / "test-pack"
        assert (pack_dir / "pyproject.toml").exists()
        assert (pack_dir / "huitzo.yaml").exists()
        assert (pack_dir / "README.md").exists()
        assert (pack_dir / ".gitignore").exists()
        assert (pack_dir / "src" / "test_pack" / "__init__.py").exists()
        assert (pack_dir / "src" / "test_pack" / "commands" / "hello.py").exists()
        assert (pack_dir / "tests" / "test_hello.py").exists()

    finally:
        os.chdir(old_cwd)


def test_init_invalid_name(temp_dir: Path) -> None:
    """Test init with invalid pack name."""
    runner = CliRunner()

    import os

    old_cwd = os.getcwd()
    try:
        os.chdir(temp_dir)

        result = runner.invoke(init_app, ["InvalidPack", "--author", "Test"])
        assert result.exit_code == 1
        assert "Invalid pack name" in result.stdout

    finally:
        os.chdir(old_cwd)


def test_init_directory_exists(temp_dir: Path) -> None:
    """Test init when directory already exists."""
    runner = CliRunner()

    # Create pack directory first
    pack_dir = temp_dir / "existing-pack"
    pack_dir.mkdir(parents=True)

    import os

    old_cwd = os.getcwd()
    try:
        os.chdir(temp_dir)

        result = runner.invoke(
            init_app,
            [
                "existing-pack",
                "--namespace",
                "test",
                "--author",
                "Test",
                "--email",
                "test@example.com",
                "--description",
                "Test Pack",
            ],
        )

        assert result.exit_code == 1
        assert "already exists" in result.stdout

    finally:
        os.chdir(old_cwd)
