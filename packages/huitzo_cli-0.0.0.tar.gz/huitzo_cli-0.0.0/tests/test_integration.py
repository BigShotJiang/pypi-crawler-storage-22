"""
Module: test_integration
Description: End-to-end integration tests for CLI workflows

Implements:
    - docs/cli/reference.md#testing
"""

import os
from pathlib import Path
from unittest.mock import patch

from typer.testing import CliRunner

from huitzo_cli.main import app


def test_pack_creation_workflow(temp_dir: Path) -> None:
    """Test complete pack creation workflow.

    1. init pack
    2. validate pack
    3. test pack
    """
    runner = CliRunner()

    old_cwd = os.getcwd()
    try:
        os.chdir(temp_dir)

        # 1. Init pack - provide all required arguments to avoid prompts
        # CLI structure: huitzo init init <args>
        result = runner.invoke(
            app,
            [
                "init",
                "init",
                "test-pack",
                "--namespace",
                "test",
                "--author",
                "Test",
                "--email",
                "test@example.com",
                "--description",
                "Test Pack",
            ],
        )
        assert result.exit_code == 0
        assert "initialized" in result.stdout

        # 2. Validate pack
        os.chdir(temp_dir / "test-pack")
        # CLI structure: huitzo validate validate
        result = runner.invoke(app, ["validate", "validate"])
        # May have warnings but should be valid
        assert "Validation:" in result.stdout

    finally:
        os.chdir(old_cwd)


def test_help_commands(cli_runner: CliRunner) -> None:
    """Test all help commands."""
    result = cli_runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "init" in result.stdout
    assert "dev" in result.stdout
    assert "registry" in result.stdout


def test_version_command(cli_runner: CliRunner) -> None:
    """Test version command."""
    result = cli_runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert "huitzo-cli" in result.stdout


def test_config_workflow(cli_runner: CliRunner, temp_dir: Path, monkeypatch) -> None:
    """Test configuration workflow."""
    from huitzo_cli.config import ConfigManager

    monkeypatch.setattr(ConfigManager, "_get_config_dir", staticmethod(lambda: temp_dir / "config"))

    # Set value
    result = cli_runner.invoke(app, ["config", "set", "test_key", "test_value"])
    assert result.exit_code == 0

    # Get value
    result = cli_runner.invoke(app, ["config", "get", "test_key"])
    assert result.exit_code == 0
    assert "test_value" in result.stdout


def test_validation_on_invalid_pack(temp_dir: Path) -> None:
    """Test validation fails on invalid pack."""
    runner = CliRunner()

    old_cwd = os.getcwd()
    try:
        os.chdir(temp_dir)

        # Try to validate empty directory
        # CLI structure: huitzo validate validate
        result = runner.invoke(app, ["validate", "validate"])
        # Exit code 1 for validation failure
        assert result.exit_code == 1
        assert "pyproject.toml" in result.stdout or "not found" in result.stdout.lower()

    finally:
        os.chdir(old_cwd)


def test_secrets_workflow(cli_runner: CliRunner, temp_dir: Path, monkeypatch) -> None:
    """Test secrets workflow."""
    from huitzo_cli.commands.secrets import SecretsStore

    monkeypatch.setattr(
        SecretsStore, "_get_secrets_dir", staticmethod(lambda: temp_dir / "secrets")
    )

    # Set secret
    result = cli_runner.invoke(app, ["secrets", "set", "api_key", "secret123"])
    assert result.exit_code == 0

    # List secrets
    result = cli_runner.invoke(app, ["secrets", "list-secrets"])
    assert result.exit_code == 0
    assert "api_key" in result.stdout

    # Remove secret
    result = cli_runner.invoke(app, ["secrets", "remove", "api_key"])
    assert result.exit_code == 0


def test_auth_workflow(cli_runner: CliRunner, temp_dir: Path, monkeypatch) -> None:
    """Test authentication workflow."""
    from huitzo_cli.auth import TokenStore
    from huitzo_cli.config import ConfigManager

    token_file = temp_dir / "token"
    config_dir = temp_dir / "config"

    monkeypatch.setattr(TokenStore, "_get_token_path", staticmethod(lambda: token_file))
    monkeypatch.setattr(ConfigManager, "_get_config_dir", staticmethod(lambda: config_dir))

    # Login
    result = cli_runner.invoke(app, ["auth", "login", "--token", "test-token"])
    assert result.exit_code == 0
    assert "Logged in" in result.stdout

    # Logout
    result = cli_runner.invoke(app, ["auth", "logout"])
    assert result.exit_code == 0
    assert "Logged out" in result.stdout


def test_cloud_features_not_available(cli_runner: CliRunner) -> None:
    """Test that cloud features show appropriate messages."""
    # publish
    result = cli_runner.invoke(app, ["registry", "publish"])
    assert result.exit_code == 1
    assert "not yet available" in result.stdout

    # dev (without valid pack)
    with patch("huitzo_cli.commands.dev.PackValidator") as mock_validator:
        mock_validator.return_value.validate.return_value.valid = False
        mock_validator.return_value.validate.return_value.errors = []

        result = cli_runner.invoke(app, ["dev"])
        # Exit code 1 for validation failure
        assert result.exit_code in (1, 2)
