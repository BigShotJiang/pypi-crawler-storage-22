"""
Module: test_registry
Description: Tests for registry commands

Implements:
    - docs/cli/reference.md#registry-commands
"""

from pathlib import Path
from unittest.mock import patch

from typer.testing import CliRunner

from huitzo_cli.commands.registry import registry_app


def test_publish_not_available(cli_runner: CliRunner) -> None:
    """Test publish shows cloud not available."""
    result = cli_runner.invoke(registry_app, ["publish"])
    assert result.exit_code == 1
    assert "not yet available" in result.stdout


def test_install_from_file(cli_runner: CliRunner, temp_dir: Path) -> None:
    """Test installing from local .whl file."""
    # Create a fake wheel file
    wheel_file = temp_dir / "test-pack-0.0.0-py3-none-any.whl"
    wheel_file.write_text("fake wheel")

    with patch("subprocess.run") as mock_run:
        mock_run.return_value.returncode = 0
        result = cli_runner.invoke(registry_app, ["install", str(wheel_file)])
        assert result.exit_code == 0
        mock_run.assert_called_once()


def test_install_missing_file(cli_runner: CliRunner) -> None:
    """Test installing from missing file."""
    result = cli_runner.invoke(registry_app, ["install", "/nonexistent/pack.whl"])
    assert result.exit_code == 1
    assert "File not found" in result.stdout


def test_install_from_registry(cli_runner: CliRunner) -> None:
    """Test installing from registry shows not available."""
    result = cli_runner.invoke(registry_app, ["install", "my-pack"])
    assert result.exit_code == 1
    assert "not yet available" in result.stdout


def test_list_packs(cli_runner: CliRunner) -> None:
    """Test listing packs."""
    with patch("subprocess.run") as mock_run:
        mock_run.return_value.stdout = "[]"
        mock_run.return_value.returncode = 0

        result = cli_runner.invoke(registry_app, ["list-packs"])
        # Should not error
        assert result.exit_code == 0


def test_run_not_available(cli_runner: CliRunner) -> None:
    """Test run shows cloud not available."""
    result = cli_runner.invoke(registry_app, ["run", "my-pack:hello"])
    assert result.exit_code == 1
    assert "not yet available" in result.stdout
