"""
Module: huitzo_sdk
Description: Huitzo SDK for building Intelligence Packs.

Implements:
    - docs/sdk/overview.md
    - docs/sdk/commands.md
    - docs/sdk/context.md
    - docs/sdk/error-handling.md

See Also:
    - docs/sdk/storage.md
    - docs/sdk/storage-backends.md
    - docs/sdk/integrations.md
"""

from huitzo_sdk.command import HuitzoCommand, command
from huitzo_sdk.context import Context
from huitzo_sdk.errors import (
    CommandError,
    ConfigurationError,
    EmailError,
    ExternalAPIError,
    HTTPError,
    HTTPSecurityError,
    HuitzoError,
    IntegrationError,
    LLMError,
    PackExecutionError,
    PermissionError,
    RateLimitError,
    SecretsError,
    StorageError,
    TimeoutError,
    ValidationError,
)
from huitzo_sdk.integrations import (
    EmailClient,
    FileClient,
    FileStorageBackend,
    HTTPClient,
    LLMClient,
    TelegramClient,
)
from huitzo_sdk.storage import InMemoryBackend, StorageBackend, StorageNamespace
from huitzo_sdk.types import CommandMetadata, DeploymentMode, Result

__all__ = [
    # Core
    "command",
    "HuitzoCommand",
    "Context",
    # Integrations
    "LLMClient",
    "EmailClient",
    "HTTPClient",
    "TelegramClient",
    "FileClient",
    "FileStorageBackend",
    # Storage
    "StorageBackend",
    "InMemoryBackend",
    "StorageNamespace",
    # Types
    "CommandMetadata",
    "DeploymentMode",
    "Result",
    # Errors
    "HuitzoError",
    "CommandError",
    "ValidationError",
    "TimeoutError",
    "StorageError",
    "SecretsError",
    "ExternalAPIError",
    "IntegrationError",
    "LLMError",
    "EmailError",
    "HTTPError",
    "HTTPSecurityError",
    "PackExecutionError",
    "PermissionError",
    "ConfigurationError",
    "RateLimitError",
]
