"""
Module: command
Description: @command decorator and HuitzoCommand base class for defining Intelligence Pack commands.

Implements:
    - docs/sdk/commands.md#the-command-decorator
    - docs/sdk/commands.md#decorator-parameters
    - docs/sdk/commands.md#class-based-commands
    - docs/sdk/commands.md#sync-vs-async-commands

See Also:
    - docs/sdk/context.md (for Context API)
    - docs/sdk/error-handling.md (for error patterns)
"""

from __future__ import annotations

import asyncio
import functools
import inspect
from typing import Any, Callable, TypeVar, get_type_hints

from pydantic import BaseModel

from huitzo_sdk.context import Context
from huitzo_sdk.types import CommandMetadata, Result

F = TypeVar("F", bound=Callable[..., Any])


def command(
    name: str,
    namespace: str,
    *,
    version: str = "1.0.0",
    timeout: int = 60,
    retries: int = 3,
    retry_backoff: float = 1.0,
    retry_max_wait: int = 60,
    queue: str = "default",
    output_format: str = "auto",
    description: str | None = None,
) -> Callable[[F], F]:
    """Decorator to register a function as a Huitzo command.

    Stores CommandMetadata on the function, validates Pydantic args,
    and supports both sync and async functions.
    """
    metadata = CommandMetadata(
        name=name,
        namespace=namespace,
        version=version,
        timeout=timeout,
        retries=retries,
        retry_backoff=retry_backoff,
        retry_max_wait=retry_max_wait,
        queue=queue,
        output_format=output_format,
        description=description,
    )

    def decorator(fn: F) -> F:
        is_async = asyncio.iscoroutinefunction(fn)
        hints = get_type_hints(fn)

        # Find the Pydantic model type for args (first parameter)
        params = list(inspect.signature(fn).parameters.keys())
        args_type: type[BaseModel] | None = None
        if params:
            first_hint = hints.get(params[0])
            if (
                first_hint is not None
                and isinstance(first_hint, type)
                and issubclass(first_hint, BaseModel)
            ):
                args_type = first_hint

        @functools.wraps(fn)
        async def wrapper(args: Any, ctx: Context | None = None) -> Result:
            # Validate args via Pydantic if type-annotated
            validated_args = args
            if args_type is not None and isinstance(args, dict):
                validated_args = args_type.model_validate(args)

            # Inject context if not provided
            if ctx is None:
                ctx = Context(
                    command_name=metadata.name,
                    namespace=metadata.namespace,
                    command_version=metadata.version,
                )

            if is_async:
                result: Result = await fn(validated_args, ctx)
            else:
                result = await asyncio.to_thread(fn, validated_args, ctx)
            return result

        wrapper._huitzo_command = metadata  # type: ignore[attr-defined]
        return wrapper  # type: ignore[return-value]

    return decorator


class HuitzoCommand:
    """Base class for class-based commands with lifecycle hooks.

    Subclass and implement execute(). Optionally override lifecycle hooks.
    """

    name: str = ""
    namespace: str = ""
    version: str = "1.0.0"
    timeout: int = 60
    retries: int = 3
    retry_backoff: float = 1.0
    retry_max_wait: int = 60
    queue: str = "default"
    output_format: str = "auto"

    def __init__(self) -> None:
        self.configure()
        self._metadata = CommandMetadata(
            name=self.name,
            namespace=self.namespace,
            version=self.version,
            timeout=self.timeout,
            retries=self.retries,
            retry_backoff=self.retry_backoff,
            retry_max_wait=self.retry_max_wait,
            queue=self.queue,
            output_format=self.output_format,
        )

    @property
    def metadata(self) -> CommandMetadata:
        return self._metadata

    def configure(self) -> None:
        """Override to set options before execution."""

    def on_start(self, args: Any) -> None:
        """Called when command starts."""

    def on_progress(self, percent: int, message: str) -> None:
        """Called to report progress."""

    def on_retry(self, attempt: int, error: Exception) -> None:
        """Called before each retry."""

    def on_complete(self, result: Any) -> None:
        """Called after successful completion."""

    def on_error(self, error: Exception) -> None:
        """Called on failure."""

    def update_state(self, **kwargs: Any) -> None:
        """Update command state (e.g., progress). Stub for runtime integration."""

    async def execute(self, args: Any, ctx: Context) -> Result:
        """Main execution logic. Must be overridden."""
        raise NotImplementedError("Subclasses must implement execute()")

    async def run(self, args: Any, ctx: Context | None = None) -> Result:
        """Execute the command with lifecycle hooks."""
        if ctx is None:
            ctx = Context(
                command_name=self.name,
                namespace=self.namespace,
                command_version=self.version,
            )

        self.on_start(args)
        try:
            result = await self.execute(args, ctx)
            self.on_complete(result)
            return result
        except Exception as e:
            self.on_error(e)
            raise
