"""
Module: context
Description: Context object passed to every command with identity, metadata, and platform services.

Implements:
    - docs/sdk/context.md#context-properties
    - docs/sdk/context.md#services
    - docs/sdk/integrations.md

See Also:
    - docs/sdk/commands.md (for command patterns)
    - docs/sdk/storage.md (for storage API)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
from uuid import UUID, uuid4

from huitzo_sdk.integrations.email import EmailClient
from huitzo_sdk.integrations.files import FileClient
from huitzo_sdk.integrations.http import HTTPClient
from huitzo_sdk.integrations.llm import LLMClient
from huitzo_sdk.integrations.telegram import TelegramClient
from huitzo_sdk.types import DeploymentMode


_NOT_WIRED = (
    "not available. This integration is injected by the Huitzo backend at runtime. "
    "If you see this in production, contact support."
)

# Services still stubbed for future PRs
_FUTURE_STUBS: dict[str, str] = {
    "storage": "Storage implemented in PR-4.",
    "log": "Logging planned for PR-6+.",
    "env": "Environment access planned for PR-6+.",
    "config": "Configuration access planned for PR-6+.",
    "secrets": "Secrets access planned for PR-6+.",
}


@dataclass
class Context:
    """Context object passed to every command execution.

    Provides identity, metadata, and access to platform services.
    """

    # Identity
    user_id: UUID = field(default_factory=uuid4)
    tenant_id: UUID = field(default_factory=uuid4)
    session_id: UUID = field(default_factory=uuid4)
    correlation_id: str = field(default_factory=lambda: str(uuid4()))

    # Command metadata
    command_name: str = ""
    namespace: str = ""
    command_version: str = "1.0.0"
    deployment_mode: DeploymentMode = DeploymentMode.CLOUD

    # Integration clients (injected by backend at runtime)
    _llm: LLMClient | None = field(default=None, repr=False)
    _email: EmailClient | None = field(default=None, repr=False)
    _http: HTTPClient | None = field(default=None, repr=False)
    _telegram: TelegramClient | None = field(default=None, repr=False)
    _files: FileClient | None = field(default=None, repr=False)

    @property
    def llm(self) -> LLMClient:
        """LLM integration client."""
        if self._llm is None:
            raise NotImplementedError(f"ctx.llm is {_NOT_WIRED}")
        return self._llm

    @property
    def email(self) -> EmailClient:
        """Email integration client."""
        if self._email is None:
            raise NotImplementedError(f"ctx.email is {_NOT_WIRED}")
        return self._email

    @property
    def http(self) -> HTTPClient:
        """HTTP integration client."""
        if self._http is None:
            raise NotImplementedError(f"ctx.http is {_NOT_WIRED}")
        return self._http

    @property
    def telegram(self) -> TelegramClient:
        """Telegram integration client."""
        if self._telegram is None:
            raise NotImplementedError(f"ctx.telegram is {_NOT_WIRED}")
        return self._telegram

    @property
    def files(self) -> FileClient:
        """File integration client."""
        if self._files is None:
            raise NotImplementedError(f"ctx.files is {_NOT_WIRED}")
        return self._files

    def __getattr__(self, name: str) -> Any:
        if name.startswith("_"):
            raise AttributeError(f"'Context' has no attribute '{name}'")
        if name in _FUTURE_STUBS:
            raise NotImplementedError(f"ctx.{name} is not yet implemented. {_FUTURE_STUBS[name]}")
        raise AttributeError(f"'Context' has no attribute '{name}'")

    async def execute(
        self,
        pack: str,
        command: str,
        args: dict[str, Any],
        timeout: int | None = None,
    ) -> Any:
        """Execute a command from another pack. Not yet implemented."""
        raise NotImplementedError(
            "ctx.execute() for cross-pack calls is not yet implemented. Implemented in PR-6."
        )
