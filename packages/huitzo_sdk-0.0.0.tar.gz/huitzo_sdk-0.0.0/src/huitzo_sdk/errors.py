"""
Module: errors
Description: SDK exception hierarchy for structured error handling.

Implements:
    - docs/sdk/error-handling.md#sdk-exception-hierarchy
    - docs/sdk/error-handling.md#exception-reference

See Also:
    - docs/sdk/commands.md (for command error patterns)
"""

from __future__ import annotations

from typing import Any


class HuitzoError(Exception):
    """Base exception for all Huitzo SDK errors."""

    code: str = "HUITZO_ERROR"
    http_status: int = 500
    retryable: bool = False

    def __init__(self, message: str, *, details: dict[str, Any] | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.details = details or {}


class CommandError(HuitzoError):
    """General command execution failure."""

    code = "COMMAND_FAILED"

    def __init__(
        self,
        message: str,
        *,
        exit_code: int = 1,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message, details=details)
        self.exit_code = exit_code


class ValidationError(HuitzoError):
    """Input validation failed."""

    code = "VALIDATION_FAILED"
    http_status = 400

    def __init__(self, *, field: str, value: Any, message: str) -> None:
        super().__init__(message)
        self.field = field
        self.value = value


class TimeoutError(HuitzoError):
    """Command exceeded its configured timeout."""

    code = "TIMEOUT"
    http_status = 408
    retryable = True

    def __init__(self, *, timeout_seconds: int, elapsed_seconds: float) -> None:
        super().__init__(
            f"Command timed out after {elapsed_seconds:.1f}s (limit: {timeout_seconds}s)"
        )
        self.timeout_seconds = timeout_seconds
        self.elapsed_seconds = elapsed_seconds


class StorageError(HuitzoError):
    """Storage operation failed."""

    code = "STORAGE_ERROR"

    def __init__(self, *, operation: str, key: str | None = None, message: str) -> None:
        super().__init__(message)
        self.operation = operation
        self.key = key


class SecretsError(HuitzoError):
    """User secret access failure."""

    code = "SECRET_MISSING"
    http_status = 400

    def __init__(self, *, secret_name: str, message: str) -> None:
        super().__init__(message)
        self.secret_name = secret_name


class ExternalAPIError(HuitzoError):
    """User-configured external API failure."""

    code = "EXTERNAL_API_ERROR"
    http_status = 502

    def __init__(self, *, service: str, message: str) -> None:
        super().__init__(message)
        self.service = service


class IntegrationError(HuitzoError):
    """Platform service failure (base for LLM, Email, HTTP errors)."""

    code = "INTEGRATION_ERROR"
    http_status = 502
    retryable = True

    def __init__(
        self,
        *,
        service: str,
        message: str,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message, details=details)
        self.service = service


class LLMError(IntegrationError):
    """LLM provider error."""

    code = "LLM_ERROR"

    def __init__(
        self,
        *,
        provider: str,
        model: str | None = None,
        status_code: int | None = None,
        message: str,
    ) -> None:
        super().__init__(service=f"llm:{provider}", message=message)
        self.provider = provider
        self.model = model
        self.status_code = status_code


class EmailError(IntegrationError):
    """Email sending error."""

    code = "EMAIL_ERROR"

    def __init__(self, *, message: str) -> None:
        super().__init__(service="email", message=message)


class HTTPError(IntegrationError):
    """HTTP request error."""

    code = "HTTP_ERROR"

    def __init__(
        self,
        *,
        url: str,
        method: str,
        status_code: int | None = None,
        response_body: str | None = None,
        message: str,
    ) -> None:
        super().__init__(service="http", message=message)
        self.url = url
        self.method = method
        self.status_code = status_code
        self.response_body = response_body


class HTTPSecurityError(HuitzoError):
    """Request to disallowed domain."""

    code = "HTTP_SECURITY_ERROR"
    http_status = 403

    def __init__(self, *, domain: str, message: str | None = None) -> None:
        super().__init__(message or f"Domain not allowed: {domain}")
        self.domain = domain


class PackExecutionError(HuitzoError):
    """Cross-pack command execution failed."""

    code = "PACK_EXECUTION_ERROR"

    def __init__(
        self,
        *,
        pack: str,
        command: str,
        original_error: Exception | None = None,
        message: str,
    ) -> None:
        super().__init__(message)
        self.pack = pack
        self.command = command
        self.original_error = original_error


class PermissionError(HuitzoError):
    """Insufficient permissions."""

    code = "PERMISSION_DENIED"
    http_status = 403

    def __init__(self, *, message: str) -> None:
        super().__init__(message)


class ConfigurationError(HuitzoError):
    """Invalid configuration."""

    code = "CONFIGURATION_ERROR"

    def __init__(self, *, message: str) -> None:
        super().__init__(message)


class RateLimitError(HuitzoError):
    """Rate limit exceeded."""

    code = "RATE_LIMITED"
    http_status = 429
    retryable = True

    def __init__(
        self,
        *,
        retry_after: float,
        limit: str | None = None,
        current: int | None = None,
        message: str | None = None,
    ) -> None:
        super().__init__(message or f"Rate limit exceeded. Retry after {retry_after}s")
        self.retry_after = retry_after
        self.limit = limit
        self.current = current
