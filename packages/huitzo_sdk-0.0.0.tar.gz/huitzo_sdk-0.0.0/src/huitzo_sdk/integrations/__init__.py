"""
Module: integrations
Description: Built-in platform integration clients for the Huitzo SDK.

Implements:
    - docs/sdk/integrations.md

See Also:
    - docs/sdk/context.md (for Context wiring)
    - docs/sdk/error-handling.md (for integration errors)
"""

from huitzo_sdk.integrations.email import EmailClient
from huitzo_sdk.integrations.files import FileClient, FileStorageBackend
from huitzo_sdk.integrations.http import HTTPClient
from huitzo_sdk.integrations.llm import LLMClient
from huitzo_sdk.integrations.telegram import TelegramClient

__all__ = [
    "LLMClient",
    "EmailClient",
    "HTTPClient",
    "TelegramClient",
    "FileClient",
    "FileStorageBackend",
]
