"""
Module: integrations.email
Description: Email integration client for sending emails and templates.

Implements:
    - docs/sdk/integrations.md#email-integration

See Also:
    - docs/sdk/error-handling.md (for EmailError)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class EmailBackend(Protocol):
    """Backend protocol for email providers."""

    async def send(
        self,
        *,
        to: str | list[str],
        subject: str,
        body: str | None,
        html: str | None,
        cc: list[str] | None,
        bcc: list[str] | None,
        attachments: list[dict[str, Any]] | None,
    ) -> None: ...

    async def send_template(
        self,
        *,
        to: str | list[str],
        template_id: str,
        template_data: dict[str, Any] | None,
    ) -> None: ...


@dataclass
class EmailClient:
    """Client for sending emails.

    This is the SDK-side interface. The backend injects a real implementation
    at runtime (SendGrid, SMTP, etc.).
    """

    _backend: EmailBackend

    async def send(
        self,
        *,
        to: str | list[str],
        subject: str,
        body: str | None = None,
        html: str | None = None,
        cc: list[str] | None = None,
        bcc: list[str] | None = None,
        attachments: list[dict[str, Any]] | None = None,
    ) -> None:
        """Send an email.

        Args:
            to: Recipient(s).
            subject: Email subject.
            body: Plain text body.
            html: HTML body.
            cc: CC recipients.
            bcc: BCC recipients.
            attachments: List of attachment dicts with filename, content, content_type.

        Raises:
            EmailError: If sending fails.
        """
        await self._backend.send(
            to=to,
            subject=subject,
            body=body,
            html=html,
            cc=cc,
            bcc=bcc,
            attachments=attachments,
        )

    async def send_template(
        self,
        *,
        to: str | list[str],
        template_id: str,
        template_data: dict[str, Any] | None = None,
    ) -> None:
        """Send a templated email.

        Args:
            to: Recipient(s).
            template_id: Provider template ID.
            template_data: Template variable substitutions.

        Raises:
            EmailError: If sending fails.
        """
        await self._backend.send_template(
            to=to,
            template_id=template_id,
            template_data=template_data,
        )
