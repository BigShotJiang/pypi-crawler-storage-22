"""
Module: integrations.files
Description: File integration client for reading and writing files with backend abstraction.

Implements:
    - docs/sdk/integrations.md#files-integration

See Also:
    - docs/sdk/context.md (for Context wiring)
"""

from __future__ import annotations

import builtins
from dataclasses import dataclass
from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class FileStorageBackend(Protocol):
    """Backend protocol for file storage (local, S3, Azure, GCS)."""

    async def read(self, path: str) -> bytes: ...

    async def write(self, path: str, content: bytes) -> None: ...

    async def info(self, path: str) -> dict[str, Any]: ...

    async def list(self, prefix: str) -> builtins.list[dict[str, Any]]: ...

    async def exists(self, path: str) -> bool: ...

    async def get_url(self, path: str, *, expires: int) -> str: ...


@dataclass
class FileClient:
    """Client for reading and writing files.

    Backend-agnostic: works with local filesystem, S3, Azure Blob, or GCS.
    Tenant path isolation is handled automatically by the backend.
    """

    _backend: FileStorageBackend

    async def read_excel(
        self,
        path: str,
        *,
        sheet: str | None = None,
    ) -> Any:
        """Read an Excel file and return a DataFrame.

        Args:
            path: Relative file path.
            sheet: Specific sheet name (default: first sheet).

        Returns:
            pandas DataFrame.

        Raises:
            ImportError: If pandas is not installed.
            IntegrationError: If the backend read fails.
        """
        data = await self._backend.read(path)
        import io

        try:
            import pandas as pd
        except ImportError as exc:
            raise ImportError("pandas is required for read_excel") from exc
        kwargs: dict[str, Any] = {}
        if sheet is not None:
            kwargs["sheet_name"] = sheet
        return pd.read_excel(io.BytesIO(data), **kwargs)

    async def read_csv(
        self,
        path: str,
        *,
        delimiter: str = ",",
        encoding: str = "utf-8",
    ) -> Any:
        """Read a CSV file and return a DataFrame.

        Args:
            path: Relative file path.
            delimiter: Column delimiter.
            encoding: File encoding.

        Returns:
            pandas DataFrame.

        Raises:
            ImportError: If pandas is not installed.
            IntegrationError: If the backend read fails.
        """
        data = await self._backend.read(path)
        import io

        try:
            import pandas as pd
        except ImportError as exc:
            raise ImportError("pandas is required for read_csv") from exc
        return pd.read_csv(io.BytesIO(data), delimiter=delimiter, encoding=encoding)

    async def read_json(self, path: str) -> Any:
        """Read a JSON file.

        Args:
            path: Relative file path.

        Returns:
            Parsed JSON data.

        Raises:
            IntegrationError: If the backend read fails.
            json.JSONDecodeError: If file content is not valid JSON.
        """
        import json

        data = await self._backend.read(path)
        return json.loads(data)

    async def write(
        self,
        path: str,
        content: str | bytes,
        *,
        binary: bool = False,
    ) -> None:
        """Write content to a file.

        Args:
            path: Relative file path.
            content: File content (string or bytes).
            binary: If True, content is bytes.

        Raises:
            IntegrationError: If the backend write fails.
        """
        if isinstance(content, str):
            raw = content.encode("utf-8")
        else:
            raw = content
        await self._backend.write(path, raw)

    async def info(self, path: str) -> dict[str, Any]:
        """Get file metadata.

        Args:
            path: Relative file path.

        Returns:
            Dict with size, created, modified, type.
        """
        return await self._backend.info(path)

    async def list(self, prefix: str = "") -> builtins.list[dict[str, Any]]:
        """List files matching a prefix.

        Args:
            prefix: Path prefix (e.g. "uploads/").

        Returns:
            List of file info dicts.
        """
        return await self._backend.list(prefix)

    async def exists(self, path: str) -> bool:
        """Check if a file exists.

        Args:
            path: Relative file path.
        """
        return await self._backend.exists(path)

    async def get_url(self, path: str, *, expires: int = 3600) -> str:
        """Generate a download URL for a file.

        Args:
            path: Relative file path.
            expires: URL expiration in seconds.

        Returns:
            Presigned download URL.
        """
        return await self._backend.get_url(path, expires=expires)
