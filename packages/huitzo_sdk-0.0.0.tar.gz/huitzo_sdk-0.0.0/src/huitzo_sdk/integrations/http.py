"""
Module: integrations.http
Description: HTTP integration client for external API requests with domain restrictions.

Implements:
    - docs/sdk/integrations.md#http-integration

See Also:
    - docs/sdk/error-handling.md (for HTTPError, HTTPSecurityError)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable
from urllib.parse import urlparse

from huitzo_sdk.errors import HTTPSecurityError


@runtime_checkable
class HTTPBackend(Protocol):
    """Backend protocol for HTTP requests."""

    async def request(
        self,
        method: str,
        url: str,
        *,
        headers: dict[str, str] | None,
        params: dict[str, Any] | None,
        json: Any | None,
        data: dict[str, Any] | None,
        files: dict[str, bytes] | None,
        timeout: int | None,
    ) -> Any: ...


@dataclass
class HTTPClient:
    """Client for making HTTP requests to external APIs.

    Supports domain restrictions to limit which external services
    a pack can communicate with.
    """

    _backend: HTTPBackend
    _allowed_domains: list[str] = field(default_factory=list)

    def _check_domain(self, url: str) -> None:
        """Validate the URL domain against allowed domains."""
        if not self._allowed_domains:
            return
        parsed = urlparse(url)
        domain = parsed.hostname or ""
        for allowed in self._allowed_domains:
            if allowed.startswith("*."):
                base = allowed[2:]  # e.g. "trusted-domain.org"
                if domain.endswith("." + base):
                    return
            elif domain == allowed:
                return
        raise HTTPSecurityError(domain=domain)

    async def get(
        self,
        url: str,
        *,
        headers: dict[str, str] | None = None,
        params: dict[str, Any] | None = None,
        timeout: int | None = None,
    ) -> Any:
        """Send a GET request.

        Raises:
            HTTPError: If the request fails.
            HTTPSecurityError: If domain not allowed.
        """
        self._check_domain(url)
        return await self._backend.request(
            "GET",
            url,
            headers=headers,
            params=params,
            json=None,
            data=None,
            files=None,
            timeout=timeout,
        )

    async def post(
        self,
        url: str,
        *,
        headers: dict[str, str] | None = None,
        params: dict[str, Any] | None = None,
        json: Any | None = None,
        data: dict[str, Any] | None = None,
        files: dict[str, bytes] | None = None,
        timeout: int | None = None,
    ) -> Any:
        """Send a POST request.

        Raises:
            HTTPError: If the request fails.
            HTTPSecurityError: If domain not allowed.
        """
        self._check_domain(url)
        return await self._backend.request(
            "POST",
            url,
            headers=headers,
            params=params,
            json=json,
            data=data,
            files=files,
            timeout=timeout,
        )

    async def put(
        self,
        url: str,
        *,
        headers: dict[str, str] | None = None,
        params: dict[str, Any] | None = None,
        json: Any | None = None,
        data: dict[str, Any] | None = None,
        files: dict[str, bytes] | None = None,
        timeout: int | None = None,
    ) -> Any:
        """Send a PUT request.

        Raises:
            HTTPError: If the request fails.
            HTTPSecurityError: If domain not allowed.
        """
        self._check_domain(url)
        return await self._backend.request(
            "PUT",
            url,
            headers=headers,
            params=params,
            json=json,
            data=data,
            files=files,
            timeout=timeout,
        )

    async def delete(
        self,
        url: str,
        *,
        headers: dict[str, str] | None = None,
        params: dict[str, Any] | None = None,
        timeout: int | None = None,
    ) -> Any:
        """Send a DELETE request.

        Raises:
            HTTPError: If the request fails.
            HTTPSecurityError: If domain not allowed.
        """
        self._check_domain(url)
        return await self._backend.request(
            "DELETE",
            url,
            headers=headers,
            params=params,
            json=None,
            data=None,
            files=None,
            timeout=timeout,
        )
