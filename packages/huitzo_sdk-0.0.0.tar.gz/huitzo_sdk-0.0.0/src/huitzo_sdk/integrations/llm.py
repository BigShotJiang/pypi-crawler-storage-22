"""
Module: integrations.llm
Description: LLM integration client for AI completions and streaming.

Implements:
    - docs/sdk/integrations.md#llm-integration

See Also:
    - docs/sdk/error-handling.md (for LLMError)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Protocol, runtime_checkable


@runtime_checkable
class LLMBackend(Protocol):
    """Backend protocol for LLM providers."""

    async def complete(
        self,
        *,
        prompt: str,
        system: str | None,
        model: str,
        temperature: float,
        max_tokens: int | None,
        top_p: float | None,
        stop: list[str] | None,
        response_format: str | None,
        schema: type[Any] | None,
    ) -> str: ...

    def stream(
        self,
        *,
        prompt: str,
        system: str | None,
        model: str,
        temperature: float,
        max_tokens: int | None,
        top_p: float | None,
        stop: list[str] | None,
    ) -> AsyncIterator[str]: ...


@dataclass
class TokenUsage:
    """Token usage tracking for a single LLM call."""

    prompt_tokens: int = 0
    completion_tokens: int = 0

    @property
    def total_tokens(self) -> int:
        return self.prompt_tokens + self.completion_tokens


@dataclass
class LLMClient:
    """Client for LLM completions and streaming.

    This is the SDK-side interface. The backend injects a real implementation
    at runtime that handles actual API calls.
    """

    _backend: LLMBackend
    _usage: list[TokenUsage] = field(default_factory=list, init=False)

    async def complete(
        self,
        prompt: str,
        *,
        model: str = "gpt-4o-mini",
        system: str | None = None,
        temperature: float = 1.0,
        max_tokens: int | None = None,
        top_p: float | None = None,
        stop: list[str] | None = None,
        response_format: str | None = None,
        schema: type[Any] | None = None,
    ) -> str:
        """Generate a completion from an LLM.

        Args:
            prompt: The user prompt.
            model: Model identifier (e.g. "gpt-4o", "claude-3-5-sonnet").
            system: Optional system message.
            temperature: Sampling temperature (0.0-2.0).
            max_tokens: Maximum response tokens.
            top_p: Nucleus sampling parameter.
            stop: Stop sequences.
            response_format: "json" for structured output.
            schema: Pydantic model for JSON mode validation.

        Returns:
            The completion text.

        Raises:
            LLMError: If the LLM call fails.
        """
        return await self._backend.complete(
            prompt=prompt,
            system=system,
            model=model,
            temperature=temperature,
            max_tokens=max_tokens,
            top_p=top_p,
            stop=stop,
            response_format=response_format,
            schema=schema,
        )

    def stream(
        self,
        prompt: str,
        *,
        model: str = "gpt-4o-mini",
        system: str | None = None,
        temperature: float = 1.0,
        max_tokens: int | None = None,
        top_p: float | None = None,
        stop: list[str] | None = None,
    ) -> AsyncIterator[str]:
        """Stream a completion from an LLM.

        Args:
            prompt: The user prompt.
            model: Model identifier.
            system: Optional system message.
            temperature: Sampling temperature.
            max_tokens: Maximum response tokens.
            top_p: Nucleus sampling parameter.
            stop: Stop sequences.

        Returns:
            An async iterator yielding text chunks.

        Raises:
            LLMError: If the LLM call fails.
        """
        return self._backend.stream(
            prompt=prompt,
            system=system,
            model=model,
            temperature=temperature,
            max_tokens=max_tokens,
            top_p=top_p,
            stop=stop,
        )

    @property
    def usage(self) -> list[TokenUsage]:
        """Token usage records for this client."""
        return list(self._usage)
