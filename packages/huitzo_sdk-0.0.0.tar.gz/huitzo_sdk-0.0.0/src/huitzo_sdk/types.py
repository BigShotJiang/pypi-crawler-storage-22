"""
Module: types
Description: Core type definitions for the Huitzo SDK.

Implements:
    - docs/sdk/commands.md#decorator-parameters
    - docs/sdk/context.md#deployment-mode

See Also:
    - docs/sdk/overview.md (for SDK design philosophy)
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Union

from pydantic import BaseModel


class DeploymentMode(Enum):
    """Deployment mode for the Huitzo platform."""

    CLOUD = "cloud"
    SELF_HOSTED = "self_hosted"
    EDGE = "edge"


@dataclass(frozen=True)
class CommandMetadata:
    """Metadata stored on decorated command functions."""

    name: str
    namespace: str
    version: str = "1.0.0"
    timeout: int = 60
    retries: int = 3
    retry_backoff: float = 1.0
    retry_max_wait: int = 60
    queue: str = "default"
    output_format: str = "auto"
    description: str | None = None


# Result can be a dict, Pydantic model, str, int, or None
Result = Union[dict[str, Any], BaseModel, str, int, None]
