"""Tests for the @command decorator and HuitzoCommand base class."""

import pytest
from pydantic import BaseModel

from huitzo_sdk import Context, HuitzoCommand, command
from huitzo_sdk.types import CommandMetadata


class AddArgs(BaseModel):
    a: int
    b: int


class GreetArgs(BaseModel):
    name: str
    greeting: str = "Hello"


# --- Decorator tests ---


class TestCommandDecorator:
    def test_stores_metadata(self) -> None:
        @command("add", namespace="math")
        async def add(args: AddArgs, ctx: Context) -> dict:
            return {"result": args.a + args.b}

        meta: CommandMetadata = add._huitzo_command  # type: ignore[attr-defined]
        assert meta.name == "add"
        assert meta.namespace == "math"
        assert meta.version == "1.0.0"
        assert meta.timeout == 60
        assert meta.retries == 3

    def test_stores_custom_metadata(self) -> None:
        @command(
            "analyze",
            namespace="data",
            version="2.0.0",
            timeout=3600,
            retries=5,
            queue="long",
            output_format="json",
            description="Analyze data",
        )
        async def analyze(args: AddArgs, ctx: Context) -> dict:
            return {}

        meta: CommandMetadata = analyze._huitzo_command  # type: ignore[attr-defined]
        assert meta.version == "2.0.0"
        assert meta.timeout == 3600
        assert meta.retries == 5
        assert meta.queue == "long"
        assert meta.output_format == "json"
        assert meta.description == "Analyze data"

    @pytest.mark.asyncio
    async def test_async_execution(self) -> None:
        @command("add", namespace="math")
        async def add(args: AddArgs, ctx: Context) -> dict:
            return {"result": args.a + args.b}

        result = await add(AddArgs(a=2, b=3))
        assert result == {"result": 5}

    @pytest.mark.asyncio
    async def test_sync_execution(self) -> None:
        @command("greet", namespace="example")
        def greet(args: GreetArgs, ctx: Context) -> str:
            return f"{args.greeting}, {args.name}!"

        result = await greet(GreetArgs(name="World"))
        assert result == "Hello, World!"

    @pytest.mark.asyncio
    async def test_dict_args_validated(self) -> None:
        @command("add", namespace="math")
        async def add(args: AddArgs, ctx: Context) -> dict:
            return {"result": args.a + args.b}

        result = await add({"a": 10, "b": 20})
        assert result == {"result": 30}

    @pytest.mark.asyncio
    async def test_invalid_dict_args_rejected(self) -> None:
        @command("add", namespace="math")
        async def add(args: AddArgs, ctx: Context) -> dict:
            return {"result": args.a + args.b}

        with pytest.raises(Exception):  # Pydantic ValidationError
            await add({"a": "not_a_number", "b": 20})

    @pytest.mark.asyncio
    async def test_context_injected(self) -> None:
        @command("whoami", namespace="utils")
        async def whoami(args: GreetArgs, ctx: Context) -> dict:
            return {"command": ctx.command_name, "ns": ctx.namespace}

        result = await whoami(GreetArgs(name="test"))
        assert result["command"] == "whoami"
        assert result["ns"] == "utils"

    @pytest.mark.asyncio
    async def test_explicit_context(self) -> None:
        @command("test", namespace="demo")
        async def test_cmd(args: GreetArgs, ctx: Context) -> str:
            return ctx.correlation_id

        ctx = Context(correlation_id="custom-id")
        result = await test_cmd(GreetArgs(name="x"), ctx)
        assert result == "custom-id"


# --- Class-based command tests ---


class TestHuitzoCommand:
    @pytest.mark.asyncio
    async def test_execute(self) -> None:
        class AddCommand(HuitzoCommand):
            name = "add"
            namespace = "math"

            async def execute(self, args: AddArgs, ctx: Context) -> dict:
                return {"result": args.a + args.b}

        cmd = AddCommand()
        result = await cmd.run(AddArgs(a=5, b=7))
        assert result == {"result": 12}

    @pytest.mark.asyncio
    async def test_configure_hook(self) -> None:
        class SlowCommand(HuitzoCommand):
            name = "slow"
            namespace = "tasks"

            def configure(self) -> None:
                self.timeout = 7200
                self.retries = 5
                self.queue = "long"

            async def execute(self, args: AddArgs, ctx: Context) -> dict:
                return {}

        cmd = SlowCommand()
        assert cmd.metadata.timeout == 7200
        assert cmd.metadata.retries == 5
        assert cmd.metadata.queue == "long"

    @pytest.mark.asyncio
    async def test_lifecycle_hooks(self) -> None:
        events: list[str] = []

        class TrackedCommand(HuitzoCommand):
            name = "tracked"
            namespace = "test"

            def on_start(self, args: AddArgs) -> None:  # type: ignore[override]
                events.append("start")

            def on_complete(self, result: dict) -> None:  # type: ignore[override]
                events.append("complete")

            async def execute(self, args: AddArgs, ctx: Context) -> dict:
                return {"ok": True}

        cmd = TrackedCommand()
        await cmd.run(AddArgs(a=1, b=2))
        assert events == ["start", "complete"]

    @pytest.mark.asyncio
    async def test_on_error_hook(self) -> None:
        errors: list[Exception] = []

        class FailingCommand(HuitzoCommand):
            name = "fail"
            namespace = "test"

            def on_error(self, error: Exception) -> None:
                errors.append(error)

            async def execute(self, args: AddArgs, ctx: Context) -> dict:
                raise RuntimeError("boom")

        cmd = FailingCommand()
        with pytest.raises(RuntimeError, match="boom"):
            await cmd.run(AddArgs(a=1, b=2))

        assert len(errors) == 1
        assert str(errors[0]) == "boom"

    def test_metadata_property(self) -> None:
        class MyCommand(HuitzoCommand):
            name = "my-cmd"
            namespace = "test"
            version = "2.0.0"

        cmd = MyCommand()
        assert cmd.metadata.name == "my-cmd"
        assert cmd.metadata.namespace == "test"
        assert cmd.metadata.version == "2.0.0"
