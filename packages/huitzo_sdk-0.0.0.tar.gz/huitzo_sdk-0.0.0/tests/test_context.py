"""Tests for the Context class."""

import pytest
from uuid import UUID

from huitzo_sdk import Context, DeploymentMode


class TestContextCreation:
    def test_default_values(self) -> None:
        ctx = Context()
        assert isinstance(ctx.user_id, UUID)
        assert isinstance(ctx.tenant_id, UUID)
        assert isinstance(ctx.session_id, UUID)
        assert isinstance(ctx.correlation_id, str)
        assert ctx.deployment_mode == DeploymentMode.CLOUD

    def test_custom_identity(self) -> None:
        uid = UUID("12345678-1234-1234-1234-123456789abc")
        tid = UUID("abcdefab-abcd-abcd-abcd-abcdefabcdef")
        ctx = Context(user_id=uid, tenant_id=tid)
        assert ctx.user_id == uid
        assert ctx.tenant_id == tid

    def test_command_metadata(self) -> None:
        ctx = Context(
            command_name="test-cmd",
            namespace="demo",
            command_version="2.0.0",
        )
        assert ctx.command_name == "test-cmd"
        assert ctx.namespace == "demo"
        assert ctx.command_version == "2.0.0"

    def test_deployment_mode(self) -> None:
        ctx = Context(deployment_mode=DeploymentMode.SELF_HOSTED)
        assert ctx.deployment_mode == DeploymentMode.SELF_HOSTED
        assert ctx.deployment_mode.value == "self_hosted"


class TestContextStubs:
    """Test that future services still raise NotImplementedError."""

    STUBBED_SERVICES = [
        "storage",
        "log",
        "env",
        "config",
        "secrets",
    ]

    @pytest.mark.parametrize("service", STUBBED_SERVICES)
    def test_stubbed_service_raises(self, service: str) -> None:
        ctx = Context()
        with pytest.raises(NotImplementedError, match=f"ctx.{service}"):
            getattr(ctx, service)

    @pytest.mark.asyncio
    async def test_execute_raises(self) -> None:
        ctx = Context()
        with pytest.raises(NotImplementedError, match="ctx.execute"):
            await ctx.execute("pack", "cmd", {})

    def test_unknown_attribute_raises_attribute_error(self) -> None:
        ctx = Context()
        with pytest.raises(AttributeError):
            _ = ctx.nonexistent_thing


class TestContextIntegrationProperties:
    """Test that integration properties raise when not wired."""

    INTEGRATION_SERVICES = ["llm", "email", "http", "telegram", "files"]

    @pytest.mark.parametrize("service", INTEGRATION_SERVICES)
    def test_unwired_integration_raises(self, service: str) -> None:
        ctx = Context()
        with pytest.raises(NotImplementedError, match=f"ctx.{service}"):
            getattr(ctx, service)


class TestDeploymentMode:
    def test_all_modes(self) -> None:
        assert DeploymentMode.CLOUD.value == "cloud"
        assert DeploymentMode.SELF_HOSTED.value == "self_hosted"
        assert DeploymentMode.EDGE.value == "edge"

    def test_comparison(self) -> None:
        ctx = Context(deployment_mode=DeploymentMode.EDGE)
        assert ctx.deployment_mode == DeploymentMode.EDGE
        assert ctx.deployment_mode != DeploymentMode.CLOUD
