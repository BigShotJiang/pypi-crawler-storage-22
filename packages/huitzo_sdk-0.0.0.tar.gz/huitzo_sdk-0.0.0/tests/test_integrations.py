"""Tests for integration clients (LLM, Email, HTTP, Telegram, Files)."""

from __future__ import annotations

import builtins
import json
from typing import Any, AsyncIterator
from unittest.mock import AsyncMock

import pytest

from huitzo_sdk import Context
from huitzo_sdk.errors import HTTPSecurityError
from huitzo_sdk.integrations.email import EmailClient
from huitzo_sdk.integrations.files import FileClient
from huitzo_sdk.integrations.http import HTTPClient
from huitzo_sdk.integrations.llm import LLMClient
from huitzo_sdk.integrations.telegram import TelegramClient


# ---------------------------------------------------------------------------
# LLM
# ---------------------------------------------------------------------------


class TestLLMClient:
    @pytest.fixture
    def backend(self) -> AsyncMock:
        return AsyncMock()

    @pytest.fixture
    def client(self, backend: AsyncMock) -> LLMClient:
        return LLMClient(_backend=backend)

    @pytest.mark.asyncio
    async def test_complete(self, client: LLMClient, backend: AsyncMock) -> None:
        backend.complete.return_value = "Hello world"
        result = await client.complete("Say hello", model="gpt-4o")
        assert result == "Hello world"
        backend.complete.assert_awaited_once()
        call_kwargs = backend.complete.call_args.kwargs
        assert call_kwargs["prompt"] == "Say hello"
        assert call_kwargs["model"] == "gpt-4o"

    @pytest.mark.asyncio
    async def test_complete_defaults(self, client: LLMClient, backend: AsyncMock) -> None:
        backend.complete.return_value = "ok"
        await client.complete("test")
        call_kwargs = backend.complete.call_args.kwargs
        assert call_kwargs["model"] == "gpt-4o-mini"
        assert call_kwargs["temperature"] == 1.0
        assert call_kwargs["system"] is None

    @pytest.mark.asyncio
    async def test_complete_with_options(self, client: LLMClient, backend: AsyncMock) -> None:
        backend.complete.return_value = "result"
        await client.complete(
            "prompt",
            model="claude-3-5-sonnet",
            system="Be helpful",
            temperature=0.5,
            max_tokens=100,
            top_p=0.9,
            stop=["\n"],
            response_format="json",
        )
        kw = backend.complete.call_args.kwargs
        assert kw["system"] == "Be helpful"
        assert kw["temperature"] == 0.5
        assert kw["max_tokens"] == 100
        assert kw["stop"] == ["\n"]
        assert kw["response_format"] == "json"

    @pytest.mark.asyncio
    async def test_stream(self) -> None:
        async def _chunks(**kwargs: Any) -> AsyncIterator[str]:
            yield "Hello "
            yield "world"

        backend = AsyncMock()
        backend.stream = _chunks
        client = LLMClient(_backend=backend)
        stream = client.stream("Say hello")
        chunks = [c async for c in stream]
        assert chunks == ["Hello ", "world"]


# ---------------------------------------------------------------------------
# Email
# ---------------------------------------------------------------------------


class TestEmailClient:
    @pytest.fixture
    def backend(self) -> AsyncMock:
        return AsyncMock()

    @pytest.fixture
    def client(self, backend: AsyncMock) -> EmailClient:
        return EmailClient(_backend=backend)

    @pytest.mark.asyncio
    async def test_send_basic(self, client: EmailClient, backend: AsyncMock) -> None:
        await client.send(to="user@example.com", subject="Test", body="Hello")
        backend.send.assert_awaited_once()
        kw = backend.send.call_args.kwargs
        assert kw["to"] == "user@example.com"
        assert kw["subject"] == "Test"
        assert kw["body"] == "Hello"

    @pytest.mark.asyncio
    async def test_send_html(self, client: EmailClient, backend: AsyncMock) -> None:
        await client.send(to="a@b.com", subject="S", html="<h1>Hi</h1>")
        kw = backend.send.call_args.kwargs
        assert kw["html"] == "<h1>Hi</h1>"
        assert kw["body"] is None

    @pytest.mark.asyncio
    async def test_send_multiple_recipients(self, client: EmailClient, backend: AsyncMock) -> None:
        await client.send(
            to=["a@b.com", "c@d.com"],
            subject="S",
            body="Hi",
            cc=["e@f.com"],
            bcc=["g@h.com"],
        )
        kw = backend.send.call_args.kwargs
        assert kw["to"] == ["a@b.com", "c@d.com"]
        assert kw["cc"] == ["e@f.com"]

    @pytest.mark.asyncio
    async def test_send_template(self, client: EmailClient, backend: AsyncMock) -> None:
        await client.send_template(
            to="user@example.com",
            template_id="d-abc123",
            template_data={"name": "John"},
        )
        backend.send_template.assert_awaited_once()
        kw = backend.send_template.call_args.kwargs
        assert kw["template_id"] == "d-abc123"
        assert kw["template_data"] == {"name": "John"}

    @pytest.mark.asyncio
    async def test_send_template_no_data(self, client: EmailClient, backend: AsyncMock) -> None:
        await client.send_template(to="a@b.com", template_id="t-1")
        kw = backend.send_template.call_args.kwargs
        assert kw["template_data"] is None


# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------


class TestHTTPClient:
    @pytest.fixture
    def backend(self) -> AsyncMock:
        return AsyncMock()

    @pytest.fixture
    def client(self, backend: AsyncMock) -> HTTPClient:
        return HTTPClient(_backend=backend)

    @pytest.fixture
    def restricted_client(self, backend: AsyncMock) -> HTTPClient:
        return HTTPClient(_backend=backend, _allowed_domains=["api.example.com", "*.trusted.org"])

    @pytest.mark.asyncio
    async def test_get(self, client: HTTPClient, backend: AsyncMock) -> None:
        backend.request.return_value = {"data": 1}
        result = await client.get("https://api.example.com/data")
        assert result == {"data": 1}
        backend.request.assert_awaited_once()
        args = backend.request.call_args
        assert args[0] == ("GET", "https://api.example.com/data")

    @pytest.mark.asyncio
    async def test_post(self, client: HTTPClient, backend: AsyncMock) -> None:
        backend.request.return_value = {"ok": True}
        result = await client.post("https://api.example.com/submit", json={"key": "val"})
        assert result == {"ok": True}
        kw = backend.request.call_args.kwargs
        assert kw["json"] == {"key": "val"}

    @pytest.mark.asyncio
    async def test_post_with_files(self, client: HTTPClient, backend: AsyncMock) -> None:
        await client.post(
            "https://api.example.com/upload",
            data={"field": "value"},
            files={"document": b"file-data"},
        )
        kw = backend.request.call_args.kwargs
        assert kw["files"] == {"document": b"file-data"}
        assert kw["data"] == {"field": "value"}

    @pytest.mark.asyncio
    async def test_put(self, client: HTTPClient, backend: AsyncMock) -> None:
        await client.put("https://api.example.com/r/1", json={"updated": True})
        args = backend.request.call_args
        assert args[0][0] == "PUT"

    @pytest.mark.asyncio
    async def test_delete(self, client: HTTPClient, backend: AsyncMock) -> None:
        await client.delete("https://api.example.com/r/1")
        args = backend.request.call_args
        assert args[0][0] == "DELETE"

    @pytest.mark.asyncio
    async def test_domain_allowed(self, restricted_client: HTTPClient, backend: AsyncMock) -> None:
        await restricted_client.get("https://api.example.com/data")
        backend.request.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_domain_wildcard_allowed(
        self, restricted_client: HTTPClient, backend: AsyncMock
    ) -> None:
        await restricted_client.get("https://sub.trusted.org/path")
        backend.request.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_domain_wildcard_nested_subdomain(self, backend: AsyncMock) -> None:
        client = HTTPClient(_backend=backend, _allowed_domains=["*.example.com"])
        await client.get("https://deep.api.example.com/path")
        backend.request.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_domain_wildcard_blocks_base_domain(self, backend: AsyncMock) -> None:
        """Wildcard *.example.com should NOT match example.com itself."""
        client = HTTPClient(_backend=backend, _allowed_domains=["*.example.com"])
        with pytest.raises(HTTPSecurityError):
            await client.get("https://example.com/path")

    @pytest.mark.asyncio
    async def test_domain_wildcard_blocks_suffix_attack(self, backend: AsyncMock) -> None:
        """*.example.com must NOT match evilexample.com."""
        client = HTTPClient(_backend=backend, _allowed_domains=["*.example.com"])
        with pytest.raises(HTTPSecurityError):
            await client.get("https://evilexample.com/steal")

    @pytest.mark.asyncio
    async def test_domain_blocked(self, restricted_client: HTTPClient) -> None:
        with pytest.raises(HTTPSecurityError):
            await restricted_client.get("https://evil.com/steal")

    @pytest.mark.asyncio
    async def test_no_restrictions(self, client: HTTPClient, backend: AsyncMock) -> None:
        await client.get("https://any-domain.com/anything")
        backend.request.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_headers_and_params(self, client: HTTPClient, backend: AsyncMock) -> None:
        await client.get(
            "https://api.example.com/data",
            headers={"Authorization": "Bearer tok"},
            params={"page": 1},
            timeout=30,
        )
        kw = backend.request.call_args.kwargs
        assert kw["headers"] == {"Authorization": "Bearer tok"}
        assert kw["params"] == {"page": 1}
        assert kw["timeout"] == 30


# ---------------------------------------------------------------------------
# Telegram
# ---------------------------------------------------------------------------


class TestTelegramClient:
    @pytest.fixture
    def backend(self) -> AsyncMock:
        return AsyncMock()

    @pytest.fixture
    def client(self, backend: AsyncMock) -> TelegramClient:
        return TelegramClient(_backend=backend)

    @pytest.mark.asyncio
    async def test_send(self, client: TelegramClient, backend: AsyncMock) -> None:
        await client.send(chat_id="123", message="Hello")
        backend.send.assert_awaited_once()
        kw = backend.send.call_args.kwargs
        assert kw["chat_id"] == "123"
        assert kw["message"] == "Hello"
        assert kw["parse_mode"] is None

    @pytest.mark.asyncio
    async def test_send_with_parse_mode(self, client: TelegramClient, backend: AsyncMock) -> None:
        await client.send(chat_id="123", message="*bold*", parse_mode="Markdown")
        kw = backend.send.call_args.kwargs
        assert kw["parse_mode"] == "Markdown"

    @pytest.mark.asyncio
    async def test_send_document(self, client: TelegramClient, backend: AsyncMock) -> None:
        await client.send_document(
            chat_id="123", document=b"pdf-data", filename="report.pdf", caption="Report"
        )
        backend.send_document.assert_awaited_once()
        kw = backend.send_document.call_args.kwargs
        assert kw["filename"] == "report.pdf"

    @pytest.mark.asyncio
    async def test_send_photo(self, client: TelegramClient, backend: AsyncMock) -> None:
        await client.send_photo(chat_id="123", photo=b"img-data", caption="Chart")
        backend.send_photo.assert_awaited_once()


# ---------------------------------------------------------------------------
# Files
# ---------------------------------------------------------------------------


class TestFileClient:
    @pytest.fixture
    def backend(self) -> AsyncMock:
        return AsyncMock()

    @pytest.fixture
    def client(self, backend: AsyncMock) -> FileClient:
        return FileClient(_backend=backend)

    @pytest.mark.asyncio
    async def test_read_json(self, client: FileClient, backend: AsyncMock) -> None:
        backend.read.return_value = json.dumps({"key": "val"}).encode()
        result = await client.read_json("data.json")
        assert result == {"key": "val"}

    @pytest.mark.asyncio
    async def test_write_string(self, client: FileClient, backend: AsyncMock) -> None:
        await client.write("out.txt", "hello")
        backend.write.assert_awaited_once()
        args = backend.write.call_args
        assert args[0] == ("out.txt", b"hello")

    @pytest.mark.asyncio
    async def test_write_bytes(self, client: FileClient, backend: AsyncMock) -> None:
        await client.write("out.bin", b"\x00\x01", binary=True)
        args = backend.write.call_args
        assert args[0] == ("out.bin", b"\x00\x01")

    @pytest.mark.asyncio
    async def test_info(self, client: FileClient, backend: AsyncMock) -> None:
        backend.info.return_value = {"size": 1024, "type": "json"}
        result = await client.info("data.json")
        assert result["size"] == 1024

    @pytest.mark.asyncio
    async def test_list(self, client: FileClient, backend: AsyncMock) -> None:
        backend.list.return_value = [{"name": "a.csv"}, {"name": "b.csv"}]
        result = await client.list("uploads/")
        assert len(result) == 2

    @pytest.mark.asyncio
    async def test_exists(self, client: FileClient, backend: AsyncMock) -> None:
        backend.exists.return_value = True
        assert await client.exists("data.json") is True

    @pytest.mark.asyncio
    async def test_get_url(self, client: FileClient, backend: AsyncMock) -> None:
        backend.get_url.return_value = "https://cdn.example.com/file?sig=abc"
        url = await client.get_url("report.pdf", expires=7200)
        assert "cdn.example.com" in url
        backend.get_url.assert_awaited_once_with("report.pdf", expires=7200)

    @pytest.mark.asyncio
    async def test_read_excel_requires_pandas(
        self, client: FileClient, backend: AsyncMock, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """read_excel raises ImportError when pandas is not installed."""
        backend.read.return_value = b"fake-excel-data"
        real_import = builtins.__import__

        def _mock_import(name: str, *args: Any, **kwargs: Any) -> Any:
            if name == "pandas":
                raise ImportError("No module named 'pandas'")
            return real_import(name, *args, **kwargs)

        monkeypatch.setattr(builtins, "__import__", _mock_import)
        with pytest.raises(ImportError, match="pandas is required"):
            await client.read_excel("test.xlsx")

    @pytest.mark.asyncio
    async def test_read_csv_requires_pandas(
        self, client: FileClient, backend: AsyncMock, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """read_csv raises ImportError when pandas is not installed."""
        backend.read.return_value = b"a,b\n1,2"
        real_import = builtins.__import__

        def _mock_import(name: str, *args: Any, **kwargs: Any) -> Any:
            if name == "pandas":
                raise ImportError("No module named 'pandas'")
            return real_import(name, *args, **kwargs)

        monkeypatch.setattr(builtins, "__import__", _mock_import)
        with pytest.raises(ImportError, match="pandas is required"):
            await client.read_csv("test.csv")


# ---------------------------------------------------------------------------
# Context wiring
# ---------------------------------------------------------------------------


class TestContextWiring:
    @pytest.mark.asyncio
    async def test_wired_llm(self) -> None:
        backend = AsyncMock()
        backend.complete.return_value = "hi"
        client = LLMClient(_backend=backend)
        ctx = Context(_llm=client)
        result = await ctx.llm.complete("test")
        assert result == "hi"

    @pytest.mark.asyncio
    async def test_wired_email(self) -> None:
        backend = AsyncMock()
        client = EmailClient(_backend=backend)
        ctx = Context(_email=client)
        await ctx.email.send(to="a@b.com", subject="S", body="B")
        backend.send.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_wired_http(self) -> None:
        backend = AsyncMock()
        backend.request.return_value = {"ok": True}
        client = HTTPClient(_backend=backend)
        ctx = Context(_http=client)
        result = await ctx.http.get("https://example.com")
        assert result == {"ok": True}

    @pytest.mark.asyncio
    async def test_wired_telegram(self) -> None:
        backend = AsyncMock()
        client = TelegramClient(_backend=backend)
        ctx = Context(_telegram=client)
        await ctx.telegram.send(chat_id="1", message="hi")
        backend.send.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_wired_files(self) -> None:
        backend = AsyncMock()
        backend.exists.return_value = True
        client = FileClient(_backend=backend)
        ctx = Context(_files=client)
        assert await ctx.files.exists("test.txt") is True
