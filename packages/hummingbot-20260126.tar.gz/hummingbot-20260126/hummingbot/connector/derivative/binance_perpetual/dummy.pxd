cdef class dummy():
    pass
