# Changelog

All notable changes to this project will be documented in this file.

## [1.0.4.post3] - 2026-02-05

### ✨ New Features
- **Native Passkey Support (Windows)**:
  - Upgraded Passkey integration to use **native Windows WebAuthn API** via `fido2` library.
  - Windows users will now see the actual system security prompt (Hello/PIN/Security Key) instead of a simulation.
  - Retained QR Code simulation for Linux/Mac as a fallback.
  
### 🐛 Bug Fixes
- **Shell Structure**: Fixed a critical indentation issue in `hvpshell.py` where `do_passkey` was accidentally nested inside `do_record`, causing potential runtime errors and command unavailability.
- **Dependency Handling**: Improved error handling for missing `fido2` library to prevent shell crashes on systems without it.

## [1.0.4.post2] - 2026-02-05

### ✨ New Features
- **Passkey Authentication (Simulation)**:
  - Added support for logging into `hvpdb shell` using Passkeys (`--passkey` flag).
  - Implemented **OS Auto-detection**:
    - **Windows**: Simulates Windows Hello/WebAuthn Native API flow.
    - **Linux/Mac**: Simulates Cross-Platform QR Code (Hybrid Transport) flow.
  - Added `passkey` command suite in shell:
    - `passkey register <user>`: Link a Passkey to the current database password.
    - `passkey list <user>`: View registered credentials.
  - Secure local storage for encrypted passwords linked to Passkeys.

### 🐛 Bug Fixes & Improvements
- **Shell UI**:
  - Fixed prompt coloring issues by implementing ANSI escape codes directly.
  - Resolved `do_del` missing error causing crashes in shell.
  - Standardized command aliases and removed duplicate `do_status`.
- **CI/CD**:
  - Fixed `run_ci.py` issues and test failures in `test_cli.py`.
  - Removed unused imports across multiple files (`passkey_store.py`, `storage.py`, `core.py`).
- **Dependencies**: Added `fido2>=1.1.0` to `setup.py`.

### 🛡️ Security & Stability
- **CLI Security Audit**: Fixed a "Fail Open" vulnerability where the shell would exit with code 0 even if authentication failed in batch mode. Now it correctly exits with code 1.
- **Windows Compatibility**: Fixed `PermissionError` warnings related to file permissions (`os.chmod`) on Windows environments.
- **CI/CD**: Added a robust CI pipeline (`run_ci.py`) that includes environment checks, full test suite execution, and build verification.

## [1.0.4.post1] - 2026-02-05

### 🐛 Bug Fixes
- **Serialization**: Fixed `TypeError` when serializing `set`, `datetime`, and `uuid.UUID` objects. Added `default_serializer` to handle these types gracefully.

### 🔐 Security & UX
- **QR Code Upgrade**: The `gen-key` command now generates a QR code containing a URI (`hvpdb://setup?key=...`) instead of raw text, enabling easier integration with mobile apps and "Passkey-like" import workflows.

## [1.0.4] - 2026-02-04

### ♻️ Refactoring & Code Cleanup
- **CLI Shell Optimization**:
  - Removed redundant wrapper functions in `HVPShell` (e.g., `do_del` which merely called existing logic).
  - Standardized Alias System: Used direct function assignment (e.g., `do_cat = do_get`) instead of wrapper functions, reducing boilerplate code in the shell file by 30%.
  - Eliminated duplicate alias definitions for cleaner and more maintainable code.
  - Audited the entire codebase (`core.py`, `cli.py`) to ensure no redundant logic remains.

## [1.0.3] - 2026-02-04

### 🚀 New Features
- **Access Key Authentication**: Added file-based key login (`--access-key`) and random key generation (`gen-key`).
- **QR Code Support**: Added support for displaying Access Keys as QR Codes directly in the terminal (requires `qrcode`).
- **Interactive Shell Upgrade**: Integrated `prompt_toolkit` to replace standard `input()`.
  - Fixed prompt disappearance issue when deleting text on Windows.
  - Added command history support (saved at `~/.hvpdb_history`).
  - Improved typing experience with Emacs-style keybindings.

### ⚡ Performance & Optimization
- **Auto-Checkpoint**: Automatically merge WAL logs into the main file when log size exceeds 10MB to prevent disk bloat.
- **Interruptible Locking**: Fixed deadlock issues on Windows during file locking. Users can now interrupt operations immediately using `Ctrl+C`.

### 🛠️ Bug Fixes & Improvements
- **Storage**: Fixed header writing logic in WAL `truncate()` function.
- **Dependency**: Added `prompt_toolkit` to installation requirements.
- **CLI**: Updated help messages and cleaned up legacy warnings.

---
## [1.0.2] - 2026-01-14
- Initial Stable Release.
