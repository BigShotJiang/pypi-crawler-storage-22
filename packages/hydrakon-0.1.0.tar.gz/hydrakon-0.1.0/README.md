# Hydrakon CLI

Hydrakon CLI is a diagnostic and validation tool designed for autonomous racing systems. It provides a suite of utilities to verify system health, validate ROS 2 topics against strict configurations, and visualize coordinate transform (TF) trees in real-time.

This tool simplifies the pre-race check procedure by automating the verification of hardware interfaces, sensor data streams, and software states.

## Installation

### From PyPI
To install the latest stable version:

```bash
pip install hydrakon
```

### From Source (Development)
For active development or deployment on specific hardware (e.g., NVIDIA Jetson):

```bash
git clone https://github.com/Atlas-Racing/Hydrakon-CLI.git
cd Hydrakon-CLI
pip install -e .
```

## Configuration

Hydrakon uses a `hydrakon.yaml` file in the working directory to define expected system states.

### Structure

```yaml
topics:
  - name: /scan
    type: sensor_msgs/msg/LaserScan
    hz: 10
    tolerance: 0.1  # Allow +/- 10% deviation

  - name: /odometry/filtered
    exists: true    # Only check if topic is active

frames:
  - name: map
  - name: odom
  - name: base_link
```

## Commands

### Interface Testing
Checks for the presence and operational state of specific hardware interfaces.

**Command:**
```bash
hdk test can0
```
**Behavior:**
- Verifies if the network interface `can0` exists.
- Checks if the interface state is `UP`.
- Returns an error code if the interface is missing or down.

### Topic Validation
Validates active ROS 2 topics against the `hydrakon.yaml` configuration.

**Command:**
```bash
hdk test topics
```

**Options:**
- `--all`: Lists all active topics on the system, highlighting those that are present but not configured in the YAML file.
- `--config <path>`: Specify a custom configuration file path (default: `hydrakon.yaml`).

**Checks Performed:**
1. **Existence**: Is the topic published?
2. **Type**: Does the message type match the configuration?
3. **Frequency (Hz)**: Is the publishing rate within the specified tolerance?

### TF Visualization
Captures and displays the Transform (TF) tree structure directly in the terminal.

**Command:**
```bash
hdk show tfs
```

**Options:**
- `--all`: Displays the entire TF tree found on the system, ignoring filters.
- `--duration <seconds>`: Sets the listening duration (default: 5.0s).
- `--debug`: Prints raw capture data and parsing logs for troubleshooting.

**Behavior:**
- Listens to `/tf` and `/tf_static` for the specified duration.
- Parses the transform hierarchy.
- Renders an ASCII tree view of the coordinate frames.
- By default, filters the view to show only frames listed in `hydrakon.yaml` to reduce noise.

## Release Process

To release a new version to PyPI:

1. Run the release helper script:
   ```bash
   python release_helper.py
   ```
2. Enter the new version number when prompted.
3. Select the target repository (TestPyPI or PyPI).
4. Provide credentials when requested.