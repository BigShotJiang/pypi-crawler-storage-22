import dataclasses
import enum
from collections import OrderedDict

from _hydrogenlib_cli.base.metadata.argument import Argument


class ArgTypes(str, enum.Enum):
    POSITION = 'position'
    KEYWORD = 'keyword'
    SWITCH = 'switch'


@dataclasses.dataclass
class CommandSpec:
    name: str
    command: str
    description: str

    args: OrderedDict[str, Argument] = dataclasses.field(default_factory=OrderedDict)
    kwargs: dict[str, Argument] = dataclasses.field(default_factory=dict)
    switches: dict[str, Argument] = dataclasses.field(default_factory=dict)

    mutually_exclusive: set[str] = None
    requires: set[str] = None

    _short_names_: dict[str, str] = dataclasses.field(init=False, default=None)
    _all_names_: dict[str, str] = dataclasses.field(init=False, default=None)

    def __post_init__(self):
        self._short_names_ = {}
        self._all_names_ = {}

        for arg in self.args.values():
            self._short_names_[arg.short_name] = arg.name
            self._all_names_[arg.name] = ArgTypes.POSITION

        for arg in self.kwargs.values():
            self._short_names_[arg.short_name] = arg.name
            self._all_names_[arg.name] = ArgTypes.KEYWORD

        for arg in self.switches.values():
            self._short_names_[arg.short_name] = arg.name
            self._all_names_[arg.name] = ArgTypes.SWITCH

    def get_fullname(self, name_or_short_name: str):
        if name_or_short_name in self._short_names_:
            return self._short_names_[name_or_short_name]
        elif name_or_short_name in self._all_names_:
            return name_or_short_name
        else:
            raise KeyError(name_or_short_name)

    def get_argument(self, name: str):
        name = self.get_fullname(name)

        # if arg := self.args.get(name):
        #     return arg
        # elif arg := self.kwargs.get(name):
        #     return arg
        # elif arg := self.switches.get(name):
        #     return arg
        # else:
        #     return None

        return self.args.get(name) or self.kwargs.get(name) or self.switches.get(name)
