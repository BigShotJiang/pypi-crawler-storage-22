from collections.abc import Callable
from typing import Any

from ..base import Runner, CommandSpec


class CommandRunner(Runner):
    spec: CommandSpec
    func: Callable[[...], Any]

    def run(self, argv):
        ...
