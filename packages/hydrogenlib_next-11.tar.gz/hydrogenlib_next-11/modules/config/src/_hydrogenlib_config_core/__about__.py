# SPDX-FileCopyrightText: 2025-present LittleSong2024 <LittleSong2024@outlook.com>
#
# SPDX-License-Identifier: HydrogenLib License

version = '3.0'
