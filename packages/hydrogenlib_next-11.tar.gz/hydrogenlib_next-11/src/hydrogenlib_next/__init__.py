raise ImportError(
    "The `hydrogenlib_next` module is just for install use. Please import from `hydrogenlib` instead."
)
