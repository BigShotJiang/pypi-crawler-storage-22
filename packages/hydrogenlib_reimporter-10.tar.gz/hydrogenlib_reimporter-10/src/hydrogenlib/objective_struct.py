from _hydrogenlib_objective_struct import *
