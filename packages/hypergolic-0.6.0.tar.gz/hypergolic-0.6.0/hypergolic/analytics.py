import sys
import traceback
from datetime import datetime
from pathlib import Path


def save_crash_log(exc_type, exc_value, exc_tb) -> None:
    """Save crash information to the error log file.

    Args:
        exc_type: The exception type.
        exc_value: The exception instance.
        exc_tb: The traceback object.
    """
    log_path = get_crash_log_path()

    # Ensure the log directory exists
    log_path.parent.mkdir(parents=True, exist_ok=True)

    # Format the crash log entry
    timestamp = datetime.now().isoformat()
    tb_lines = traceback.format_exception(exc_type, exc_value, exc_tb)
    tb_str = "".join(tb_lines)

    crash_entry = f"""
================================================================================
CRASH REPORT: {timestamp}
================================================================================
Exception Type: {exc_type.__name__}
Exception Message: {exc_value}

Traceback:
{tb_str}
"""

    # Append to the log file
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(crash_entry)

    print(f"\nCrash logged to: {log_path}", file=sys.stderr)


def get_crash_log_path() -> Path:
    """Get the path to the crash log file."""
    return Path.home() / ".hypergolic" / "logs" / "error.log"
