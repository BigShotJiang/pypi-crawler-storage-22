import logging
from contextlib import contextmanager

from hypergolic.session_context import SessionContext
from hypergolic.version_control import (
    BranchCleanupResult,
    checkout_agent_branch,
    checkout_original_branch,
    cleanup_agent_branch,
    create_agent_branch,
    stash_dirty_branch,
    unstash_dirty_branch,
)

logger = logging.getLogger(__name__)


@contextmanager
def HypergolicLifespan(session_context: SessionContext, merge_on_exit: bool = False):
    start(session_context)
    try:
        yield
    finally:
        end(session_context, merge_on_exit=merge_on_exit)


def start(session_context: SessionContext):
    print("Starting session...")
    stash_dirty_branch(session_context)
    create_agent_branch(session_context)
    checkout_agent_branch(session_context)


def end(session_context: SessionContext, merge_on_exit: bool = False):
    print("Ending session...")

    checkout_original_branch(session_context)

    result = cleanup_agent_branch(session_context, merge_if_changes=merge_on_exit)

    match result:
        case BranchCleanupResult.DELETED:
            print(f"Cleaned up empty branch: {session_context.agent_branch}")
        case BranchCleanupResult.MERGED:
            print(
                f"✅ Merged {session_context.agent_branch} into {session_context.original_branch}"
            )
        case BranchCleanupResult.PRESERVED:
            print(f"⚠️  Branch preserved with changes: {session_context.agent_branch}")
            print(f"   To merge: git merge {session_context.agent_branch}")
            print(f"   To delete: git branch -D {session_context.agent_branch}")
        case BranchCleanupResult.NOT_FOUND:
            pass  # Branch was already cleaned up somehow

    unstash_dirty_branch(session_context)
