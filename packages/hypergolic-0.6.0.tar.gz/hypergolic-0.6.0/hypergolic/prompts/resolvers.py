from pathlib import Path
from typing import Any, cast

from anthropic.types import CacheControlEphemeralParam, MessageParam, TextBlockParam

from hypergolic.config import PROJECT_PROMPT_FILENAME, USER_PROMPT_PATH
from hypergolic.session_context import SessionContext

BUILTIN_PROMPTS_DIR = Path(__file__).parent

EPHEMERAL_CACHE: CacheControlEphemeralParam = {"type": "ephemeral"}


def _read_optional_prompt(path: Path) -> str | None:
    if path.is_file():
        return path.read_text().strip() or None
    return None


def build_operator_system_prompt(
    session_context: SessionContext,
) -> list[TextBlockParam]:
    blocks: list[TextBlockParam] = []

    base_prompt = (BUILTIN_PROMPTS_DIR / "system_prompt.md").read_text().strip()
    blocks.append({"type": "text", "text": base_prompt})

    user_content = _read_optional_prompt(USER_PROMPT_PATH)
    user_section = f"<!-- USER PROMPT -->\n{user_content or 'None'}"
    blocks.append({"type": "text", "text": user_section})

    project_path = session_context.git_root / PROJECT_PROMPT_FILENAME
    project_content = _read_optional_prompt(project_path)
    project_section = f"<!-- PROJECT PROMPT -->\n{project_content or 'None'}"
    blocks.append({"type": "text", "text": project_section})

    session_section = f"<!--SESSION CONTEXT -->\n{session_context.model_dump()}"
    blocks.append({"type": "text", "text": session_section})

    return blocks


def build_code_reviewer_system_prompt() -> list[TextBlockParam]:
    prompt = (
        (BUILTIN_PROMPTS_DIR / "code_reviewer_system_prompt.md").read_text().strip()
    )
    return [{"type": "text", "text": prompt, "cache_control": EPHEMERAL_CACHE}]


def update_message_cache_headers(messages: list[MessageParam]) -> None:
    """Rolling cache breakpoint: only the last message gets cache_control."""
    for message in messages:
        content = message["content"]
        if isinstance(content, list):
            for item in content:
                if isinstance(item, dict):
                    item_dict = cast(dict[str, Any], item)
                    if "cache_control" in item_dict:
                        del item_dict["cache_control"]

    if messages:
        last_content = messages[-1]["content"]
        if isinstance(last_content, list) and len(last_content) > 0:
            last_item = last_content[-1]
            if isinstance(last_item, dict):
                item_dict = cast(dict[str, Any], last_item)
                item_dict["cache_control"] = EPHEMERAL_CACHE
