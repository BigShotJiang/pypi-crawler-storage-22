The conversation has grown long and needs to be condensed to continue effectively. Generate a comprehensive summary that will allow you to seamlessly continue the work.

Include:

**Goal**: What the user is trying to accomplish (the high-level objective)

**Work Completed**: 
- Files created, modified, or deleted
- Key code changes and their purpose
- Commands run and their outcomes
- Decisions made and their rationale

**Current State**:
- Where the work stands right now
- Any incomplete tasks or pending steps
- Files currently being worked on

**Key Findings**:
- Important results from tool calls (file contents, search results, test outputs)
- Errors encountered and how they were resolved (or not)
- Any blockers or issues discovered

**Context & Preferences**:
- User preferences or constraints that emerged
- Important technical decisions and why they were made
- Any conventions or patterns being followed

**Next Steps** (if discussed):
- What was planned to happen next
- Any specific approaches agreed upon

Format as markdown. Be thorough—this summary replaces the full conversation history. Include specific file paths, function names, and code snippets where they're essential for continuing the work.

Note: After this summary, you can use `git diff` and `git log` to review the actual changes made during this session if you need more detail.
