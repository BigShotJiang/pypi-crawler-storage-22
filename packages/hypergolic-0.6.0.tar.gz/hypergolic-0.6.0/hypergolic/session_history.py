import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any

from anthropic.types import MessageParam

from hypergolic.session_context import SessionContext

logger = logging.getLogger(__name__)

SESSION_LOGS_DIR = Path.home() / ".hypergolic" / "logs" / "sessions"

# Content truncation settings for log files
MAX_CONTENT_LENGTH = 500  # Truncate content longer than this
TRUNCATION_SUFFIX = "...[truncated]"


class SessionHistoryManager:
    """
    Manages session history persistence.

    Handles both initial saves and appending to existing session files
    (used when summarization occurs mid-session).
    """

    def __init__(self, session_context: SessionContext):
        self.session_context = session_context
        self._filepath: Path | None = None
        self._segment_count = 0

    @property
    def filepath(self) -> Path | None:
        return self._filepath

    def save(
        self,
        messages: list[MessageParam],
        stats: dict[str, Any],
        sub_agent_traces: dict[str, dict[str, Any]] | None = None,
        is_summarization: bool = False,
        usage_snapshots: list[dict[str, Any]] | None = None,
    ) -> Path | None:
        """
        Save session history.

        If this is a summarization save and we already have a file,
        append to the existing file. Otherwise create a new file.

        Args:
            messages: Conversation messages to save
            stats: Final session statistics
            sub_agent_traces: Optional traces from sub-agents
            is_summarization: Whether this save is due to summarization
            usage_snapshots: List of usage snapshots, one per API response
        """
        if not messages:
            return None

        SESSION_LOGS_DIR.mkdir(parents=True, exist_ok=True)
        now = datetime.now()

        if self._filepath and self._filepath.exists() and is_summarization:
            return self._append_segment(
                messages, stats, sub_agent_traces, now, usage_snapshots
            )

        return self._create_new_file(
            messages, stats, sub_agent_traces, now, usage_snapshots
        )

    def _create_new_file(
        self,
        messages: list[MessageParam],
        stats: dict[str, Any],
        sub_agent_traces: dict[str, dict[str, Any]] | None,
        now: datetime,
        usage_snapshots: list[dict[str, Any]] | None = None,
    ) -> Path:
        """Create a new session history file."""
        timestamp = now.strftime("%Y-%m-%d_%H-%M-%S")
        session_id = self.session_context.agent_branch.split("-")[-1]
        filename = f"{timestamp}_{self.session_context.project_name}_{session_id}.json"
        self._filepath = SESSION_LOGS_DIR / filename

        session_data = build_session_data(
            self.session_context, messages, stats, now, sub_agent_traces,
            usage_snapshots=usage_snapshots,
        )

        # Wrap in segments structure for potential future appends
        wrapped_data = {
            "metadata": session_data["metadata"],
            "segments": [
                {
                    "segment_index": 0,
                    "timestamp": now.isoformat(),
                    "stats": session_data["stats"],
                    "messages": session_data["messages"],
                }
            ],
        }

        if sub_agent_traces:
            wrapped_data["segments"][0]["sub_agent_traces"] = sub_agent_traces

        with open(self._filepath, "w", encoding="utf-8") as f:
            json.dump(wrapped_data, f, indent=2, default=str)

        self._segment_count = 1
        logger.info("Created session history: %s", self._filepath)
        return self._filepath

    def _append_segment(
        self,
        messages: list[MessageParam],
        stats: dict[str, Any],
        sub_agent_traces: dict[str, dict[str, Any]] | None,
        now: datetime,
        usage_snapshots: list[dict[str, Any]] | None = None,
    ) -> Path:
        """Append a new segment to existing session history."""
        if not self._filepath:
            raise RuntimeError("No existing file to append to")

        with open(self._filepath, encoding="utf-8") as f:
            data = json.load(f)

        formatted_messages = format_messages_with_snapshots(messages, usage_snapshots)

        new_segment: dict[str, Any] = {
            "segment_index": self._segment_count,
            "timestamp": now.isoformat(),
            "stats": stats,
            "messages": formatted_messages,
            "is_post_summarization": True,
        }

        if sub_agent_traces:
            new_segment["sub_agent_traces"] = sub_agent_traces

        data["segments"].append(new_segment)

        with open(self._filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, default=str)

        self._segment_count += 1
        logger.info(
            "Appended segment %d to session history: %s",
            self._segment_count - 1,
            self._filepath,
        )
        return self._filepath


def save_session_history(
    session_context: SessionContext,
    messages: list[MessageParam],
    stats: dict[str, Any],
    sub_agent_traces: dict[str, dict[str, Any]] | None = None,
) -> Path | None:
    """
    Legacy function for simple session saves.

    For new code that needs summarization support, use SessionHistoryManager instead.
    """
    if not messages:
        return None

    SESSION_LOGS_DIR.mkdir(parents=True, exist_ok=True)

    now = datetime.now()
    timestamp = now.strftime("%Y-%m-%d_%H-%M-%S")
    session_id = session_context.agent_branch.split("-")[-1]
    filename = f"{timestamp}_{session_context.project_name}_{session_id}.json"
    filepath = SESSION_LOGS_DIR / filename

    session_data = build_session_data(
        session_context, messages, stats, now, sub_agent_traces
    )

    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(session_data, f, indent=2, default=str)

    return filepath


def build_session_data(
    session_context: SessionContext,
    messages: list[MessageParam],
    stats: dict[str, Any],
    timestamp: datetime,
    sub_agent_traces: dict[str, dict[str, Any]] | None = None,
    usage_snapshots: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    formatted_messages = format_messages_with_snapshots(messages, usage_snapshots)

    data: dict[str, Any] = {
        "metadata": {
            "timestamp": timestamp.isoformat(),
            "project": session_context.project_name,
            "branch": session_context.agent_branch,
            "original_branch": session_context.original_branch,
            "base_commit": session_context.base_commit,
            "git_root": str(session_context.git_root),
        },
        "stats": stats,
        "messages": formatted_messages,
    }

    if sub_agent_traces:
        data["sub_agent_traces"] = sub_agent_traces

    return data


def format_messages_with_snapshots(
    messages: list[MessageParam],
    usage_snapshots: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    """
    Format messages, attaching usage snapshots to assistant messages.

    Each assistant message corresponds to one API response, so we pair
    them with snapshots in order.
    """
    formatted = []
    snapshot_index = 0
    snapshots = usage_snapshots or []

    for msg in messages:
        role = msg.get("role", "unknown")

        # Attach snapshot to assistant messages (each = one API call)
        if role == "assistant" and snapshot_index < len(snapshots):
            formatted.append(format_message(msg, snapshots[snapshot_index]))
            snapshot_index += 1
        else:
            formatted.append(format_message(msg))

    return formatted


def format_message(
    message: MessageParam, usage_snapshot: dict[str, Any] | None = None
) -> dict[str, Any]:
    role = message.get("role", "unknown")
    content = message.get("content", [])

    formatted: dict[str, Any] = {"role": role}

    if usage_snapshot:
        formatted["usage_snapshot"] = usage_snapshot

    if isinstance(content, str):
        content_length = len(content)
        formatted["content_length"] = content_length
        formatted["content"] = truncate_text(content)
        return formatted

    formatted["content"] = []
    total_length = 0
    for block in content:
        formatted_block, block_length = format_content_block(block)
        formatted["content"].append(formatted_block)
        total_length += block_length
    formatted["content_length"] = total_length

    return formatted


def truncate_text(text: str) -> str:
    """Truncate text if it exceeds MAX_CONTENT_LENGTH."""
    if len(text) <= MAX_CONTENT_LENGTH:
        return text
    return text[:MAX_CONTENT_LENGTH] + TRUNCATION_SUFFIX


def format_content_block(block: Any) -> tuple[dict[str, Any], int]:
    """Format a content block, returning (formatted_block, content_length)."""
    if isinstance(block, dict):
        return format_dict_block(block)

    block_type = getattr(block, "type", None)

    if block_type == "text":
        text = block.text
        return {
            "type": "text",
            "text": truncate_text(text),
            "content_length": len(text),
        }, len(text)

    if block_type == "tool_use":
        input_str = json.dumps(block.input) if block.input else ""
        return {
            "type": "tool_use",
            "id": block.id,
            "name": block.name,
            "input": block.input,
        }, len(input_str)

    if block_type == "tool_result":
        return format_tool_result_block(block)

    raw = str(block)
    return {"type": block_type or "unknown", "raw": truncate_text(raw)}, len(raw)


def format_dict_block(block: dict) -> tuple[dict[str, Any], int]:
    """Format a dict content block, returning (formatted_block, content_length)."""
    block_type = block.get("type")

    if block_type == "text":
        text = block.get("text", "")
        return {
            "type": "text",
            "text": truncate_text(text),
            "content_length": len(text),
        }, len(text)

    if block_type == "tool_use":
        input_data = block.get("input")
        input_str = json.dumps(input_data) if input_data else ""
        return {
            "type": "tool_use",
            "id": block.get("id"),
            "name": block.get("name"),
            "input": input_data,
        }, len(input_str)

    if block_type == "tool_result":
        return format_tool_result_dict_block(block)

    # Unknown block type - return as-is with estimated length
    block_str = json.dumps(block)
    return block, len(block_str)


def format_tool_result_dict_block(block: dict) -> tuple[dict[str, Any], int]:
    """Format a tool_result dict block with truncation."""
    content = block.get("content")
    content_length = 0
    truncated_content = content

    if isinstance(content, str):
        content_length = len(content)
        truncated_content = truncate_text(content)
    elif isinstance(content, list):
        truncated_content = []
        for item in content:
            if isinstance(item, dict) and item.get("type") == "text":
                text = item.get("text", "")
                content_length += len(text)
                truncated_content.append({
                    "type": "text",
                    "text": truncate_text(text),
                    "content_length": len(text),
                })
            else:
                item_str = str(item)
                content_length += len(item_str)
                truncated_content.append(item)

    return {
        "type": "tool_result",
        "tool_use_id": block.get("tool_use_id"),
        "content": truncated_content,
        "content_length": content_length,
        "is_error": block.get("is_error", False),
    }, content_length


def format_tool_result_block(block: Any) -> tuple[dict[str, Any], int]:
    """Format a tool_result block with truncation, returning (formatted, length)."""
    content = getattr(block, "content", None)
    content_length = 0
    formatted_content: Any = content

    if isinstance(content, str):
        content_length = len(content)
        formatted_content = truncate_text(content)
    elif isinstance(content, list):
        formatted_content = []
        for item in content:
            if hasattr(item, "type") and item.type == "text":
                text = item.text
                content_length += len(text)
                formatted_content.append({
                    "type": "text",
                    "text": truncate_text(text),
                    "content_length": len(text),
                })
            else:
                item_str = str(item)
                content_length += len(item_str)
                formatted_content.append(item_str)

    return {
        "type": "tool_result",
        "tool_use_id": block.tool_use_id,
        "content": formatted_content,
        "content_length": content_length,
        "is_error": getattr(block, "is_error", False),
    }, content_length
