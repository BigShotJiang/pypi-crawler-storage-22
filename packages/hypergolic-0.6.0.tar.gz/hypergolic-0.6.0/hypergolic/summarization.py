"""
Context window summarization management.

Handles automatic summarization when the context window grows too large,
preventing API errors and maintaining conversation quality.
"""

import logging
from dataclasses import dataclass
from enum import Enum, auto

from anthropic import AsyncAnthropic
from anthropic.types import MessageParam, TextBlock

from hypergolic.prompts.paths import SUMMARIZE_CONTEXT_PROMPT_PATH

logger = logging.getLogger(__name__)


class SummarizationAction(Enum):
    """Action to take based on context size."""

    NONE = auto()
    SUGGEST = auto()  # Soft threshold - prompt user once
    FORCE = auto()  # Hard threshold - must summarize


@dataclass
class SummarizationConfig:
    """Configuration for context summarization thresholds."""

    # Soft threshold: suggest summarization to user (once per session)
    soft_threshold: int = 150_000

    # Hard threshold: force summarization to prevent API errors
    hard_threshold: int = 180_000


class SummarizationManager:
    """Manages context window summarization decisions and execution."""

    def __init__(self, config: SummarizationConfig | None = None):
        self.config = config or SummarizationConfig()
        self._soft_threshold_prompted = False

    def check_context_size(self, input_tokens: int) -> SummarizationAction:
        """
        Check if summarization is needed based on input token count.

        Args:
            input_tokens: The input_tokens from the most recent API response

        Returns:
            SummarizationAction indicating what action to take
        """
        if input_tokens >= self.config.hard_threshold:
            logger.warning(
                "Context size %d exceeds hard threshold %d, forcing summarization",
                input_tokens,
                self.config.hard_threshold,
            )
            return SummarizationAction.FORCE

        if input_tokens >= self.config.soft_threshold:
            if not self._soft_threshold_prompted:
                logger.info(
                    "Context size %d exceeds soft threshold %d, suggesting summarization",
                    input_tokens,
                    self.config.soft_threshold,
                )
                return SummarizationAction.SUGGEST

        return SummarizationAction.NONE

    def mark_soft_threshold_prompted(self) -> None:
        """Mark that the user has been prompted about soft threshold."""
        self._soft_threshold_prompted = True

    def reset(self) -> None:
        """Reset state for a new session."""
        self._soft_threshold_prompted = False


async def generate_context_summary(
    client: AsyncAnthropic,
    messages: list[MessageParam],
    model: str,
) -> str:
    """
    Generate a summary of the conversation for context window management.

    This is used for mid-session summarization to reduce context size
    while preserving the ability to continue work.

    Args:
        client: The Anthropic client
        messages: The conversation messages to summarize
        model: The model to use for summarization

    Returns:
        A structured summary string
    """
    if not messages:
        return "No messages to summarize."

    logger.info(
        "Generating context summary for %d messages using model %s",
        len(messages),
        model,
    )

    system_prompt = SUMMARIZE_CONTEXT_PROMPT_PATH.read_text().strip()

    # Convert messages to a transcript string
    transcript = _format_transcript_for_summary(messages)

    if not transcript.strip():
        logger.warning("No content found in messages to summarize")
        return "No content to summarize."

    # Wrap transcript in a single user message to prevent the model
    # from continuing the conversation instead of summarizing it
    summary_request = [{"role": "user", "content": f"Please summarize this conversation:\n\n{transcript}"}]

    try:
        response = await client.messages.create(
            model=model,
            max_tokens=4096,  # Allow longer summaries for context preservation
            system=system_prompt,
            messages=summary_request,
        )
    except Exception as e:
        logger.exception("Failed to generate context summary: %s", e)
        raise

    logger.info(
        "Summary generated: stop_reason=%s, usage=%s",
        response.stop_reason,
        response.usage,
    )

    text_parts = [
        block.text for block in response.content if isinstance(block, TextBlock)
    ]

    if text_parts:
        return "\n\n".join(text_parts)

    logger.warning("Summary generation returned no text content")
    return "Summary generation failed - no content returned."


def _format_transcript_for_summary(messages: list[MessageParam]) -> str:
    """
    Convert messages to a transcript string suitable for summarization.

    Extracts text content and provides summaries of tool calls/results.
    """
    from hypergolic.tui.summarizer import _format_conversation_as_transcript

    return _format_conversation_as_transcript(messages)


def format_context_summary_as_message(summary: str) -> str:
    """Format the summary as a user message for the continued conversation."""
    return f"""*Context Summary (conversation condensed to manage context window)*

{summary}

---
*The conversation continues from here. You can use `git diff` and `git log` to review recent changes if needed.*"""
