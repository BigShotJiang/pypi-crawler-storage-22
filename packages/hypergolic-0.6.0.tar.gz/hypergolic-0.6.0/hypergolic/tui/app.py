from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

from anthropic import AsyncAnthropic
from anthropic.types import MessageParam, TextBlockParam
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.widgets import Footer

from hypergolic.agent_runner import AgentRunner
from hypergolic.config import HypergolicConfig
from hypergolic.conversation_manager import ConversationManager
from hypergolic.session_context import SessionContext
from hypergolic.session_history import SessionHistoryManager
from hypergolic.session_stats import SessionStats
from hypergolic.tools.approval_manager import ApprovalManager
from hypergolic.tools.tool_list import get_tools
from hypergolic.tui.callbacks import TUICallbacks
from hypergolic.tui.sidebar_observer import SidebarStatsObserver
from hypergolic.tui.streaming import StreamingController
from hypergolic.tui.summarizer import (
    format_summary_as_user_message,
    generate_conversation_summary,
)
from hypergolic.tui.tool_executor import ToolExecutor
from hypergolic.tui.tool_ui_handler import ToolUIHandler
from hypergolic.tui.widgets.clear_confirmation import (
    ClearAction,
    ClearConfirmationResult,
    ClearConfirmationScreen,
)
from hypergolic.tui.widgets.conversation import AgentMessage, ConversationView
from hypergolic.tui.widgets.file_browser import FileBrowser, FileBrowserFileSelected
from hypergolic.tui.widgets.header import HypergolicHeader
from hypergolic.tui.widgets.prompt_input import PromptInput
from hypergolic.tui.widgets.sidebar import SessionSidebar

if TYPE_CHECKING:
    from hypergolic.app import App as HypergolicApp

logger = logging.getLogger(__name__)


class TUI(App):
    CSS_PATH = "styles.tcss"

    BINDINGS = [
        Binding("ctrl+c", "quit", "Quit", show=True, priority=True),
        Binding("ctrl+l", "clear_conversation", "Clear", show=True),
        Binding("ctrl+b", "toggle_sidebar", "Sidebar", show=True),
        Binding("ctrl+e", "toggle_file_browser", "Files", show=True),
        Binding("escape", "cancel", "Cancel", show=False),
    ]

    def __init__(
        self,
        app: HypergolicApp,
        session_context: SessionContext,
        config: HypergolicConfig,
        client: AsyncAnthropic,
        system_prompt: list[TextBlockParam],
        stats: SessionStats,
        conversation: ConversationManager,
    ):
        super().__init__()
        self._app = app
        self.session_context = session_context
        self.config = config
        self.client = client
        self.system_prompt = system_prompt
        self.stats = stats
        self.conversation = conversation

        self._current_agent_message: AgentMessage | None = None

        # Set up callbacks that bridge events to UI
        self._callbacks = TUICallbacks(tui=self, message_manager=self)
        self.stats.observer = SidebarStatsObserver(
            query_sidebar=lambda: self.query_one("#sidebar", SessionSidebar)
        )

        # Create approval manager (consolidates all approval logic)
        project_id = session_context.remote_url or session_context.project_name
        self._approval_manager = ApprovalManager(
            config=self.config,
            project_id=project_id,
        )

        self._tool_handler = ToolUIHandler(
            ui_callbacks=self._callbacks,
            client=self.client,
            config=self.config,
            session_context=session_context,
            approval_manager=self._approval_manager,
            stats_increment_tool=self.stats.increment_tool_count,
        )

        self._tool_executor = ToolExecutor(
            approval_manager=self._approval_manager, callbacks=self._tool_handler
        )

        # Create the runner and store it on the parent app
        self._streaming = StreamingController(client=self.client)
        self._runner = AgentRunner(
            client=self.client,
            config=self.config,
            system_prompt=self.system_prompt,
            tools=get_tools(),
            conversation=self.conversation,
            stats=self.stats,
            tool_executor=self._tool_executor,
            streaming=self._streaming,
            callbacks=self._callbacks,
        )
        self._app.runner = self._runner

        # Session history manager for save/append support
        self._history_manager = SessionHistoryManager(session_context)

    @property
    def messages(self) -> list[MessageParam]:
        return self.conversation.messages

    @property
    def is_busy(self) -> bool:
        return self._runner.is_busy

    def compose(self) -> ComposeResult:
        yield HypergolicHeader(self.session_context)
        with Horizontal(id="main-content"):
            yield FileBrowser(
                self.session_context.git_root,
                expand_to=self.session_context.cwd,
                id="file-browser",
            )
            yield ConversationView(id="conversation")
            yield SessionSidebar(self.session_context, id="sidebar")
        yield Vertical(
            PromptInput(
                id="prompt-input",
                tab_behavior="focus",
                placeholder="Enter your message... (Shift+Enter for newline)",
            ),
            id="input-area",
        )
        yield Footer()

    def on_mount(self) -> None:
        prompt_input = self.query_one("#prompt-input", PromptInput)
        prompt_input.focus()

    # AgentMessageManager protocol implementation

    def get_current_message(self) -> AgentMessage | None:
        return self._current_agent_message

    def set_current_message(self, msg: AgentMessage | None) -> None:
        self._current_agent_message = msg

    def cleanup_message(self, mark_interrupted: bool = False) -> None:
        if self._current_agent_message:
            has_content = bool(self._current_agent_message.content_text.strip())
            if has_content:
                if mark_interrupted:
                    self._current_agent_message.mark_interrupted()
            else:
                self._current_agent_message.remove()
        self._current_agent_message = None

    # Input handling

    def on_prompt_input_submitted(self, event: PromptInput.Submitted) -> None:
        prompt_input = self.query_one("#prompt-input", PromptInput)
        message = prompt_input.text.strip()
        if message:
            prompt_input.clear()
            if self.is_busy:
                self._request_interrupt(message)
            else:
                self._handle_user_message(message)

    # Interrupt handling

    def _request_interrupt(self, message: str) -> None:
        # Clean up current agent message before interrupt
        self.cleanup_message(mark_interrupted=True)

        # Show interrupt in UI
        conversation_view = self.query_one("#conversation", ConversationView)
        conversation_view.add_user_message(
            f"[Interrupt] {message}", is_interrupt=True
        )

        # Cancel tool handler's token
        if self._tool_handler.cancellation_token:
            self._tool_handler.cancellation_token.cancel()

        # Tell runner to interrupt
        self._runner.interrupt(message)

    # User message handling

    def _handle_user_message(self, message: str) -> None:
        conversation_view = self.query_one("#conversation", ConversationView)
        conversation_view.add_user_message(message)

        # Runner handles the entire agent loop asynchronously
        self._runner.submit_message(message)

    def _show_summary(self, summary: str) -> None:
        conversation_view = self.query_one("#conversation", ConversationView)
        self.conversation.clear()

        formatted_summary = format_summary_as_user_message(summary)
        conversation_view.add_summary_message(formatted_summary)
        self.conversation.add_user_message(formatted_summary)
        self._focus_input()

    # Summarization handling (called from callbacks)

    def show_summarization_prompt(self) -> None:
        """Show prompt asking user if they want to summarize (soft threshold)."""
        from hypergolic.tui.widgets.summarization_prompt import (
            SummarizationPromptResult,
            SummarizationPromptScreen,
        )

        async def do_summarize() -> None:
            # Disable input while summarizing to prevent race conditions
            prompt_input = self.query_one("#prompt-input", PromptInput)
            prompt_input.disabled = True
            try:
                await self._runner.summarize_now()
            finally:
                prompt_input.disabled = False
                self._focus_input()

        def handle_result(result: SummarizationPromptResult | None) -> None:
            if result and result.should_summarize:
                asyncio.create_task(do_summarize())
            else:
                self._focus_input()

        self.push_screen(SummarizationPromptScreen(), handle_result)

    def handle_summarization_complete(self, summary: str) -> None:
        """Handle completion of automatic summarization.

        Called BEFORE the conversation messages are replaced with the summary,
        so we can save the original messages to history.
        """
        # Save current (original) messages before they're replaced
        self._history_manager.save(
            messages=self.conversation.messages,
            stats=self.stats.to_dict(),
            sub_agent_traces=self._tool_handler.get_sub_agent_traces() or None,
            is_summarization=True,
            usage_snapshots=[s.to_dict() for s in self.stats.get_all_snapshots()],
        )

        # Clear UI and show summary
        conversation_view = self.query_one("#conversation", ConversationView)
        conversation_view.clear()

        from hypergolic.summarization import format_context_summary_as_message
        formatted_summary = format_context_summary_as_message(summary)
        conversation_view.add_summary_message(formatted_summary)
        # Note: conversation.replace_with_summary will be called by runner after this

    def _focus_input(self) -> None:
        self.query_one("#prompt-input", PromptInput).focus()

    # Actions

    def action_clear_conversation(self) -> None:
        has_messages = len(self.conversation.messages) > 0
        self.push_screen(
            ClearConfirmationScreen(has_messages=has_messages),
            self._handle_clear_confirmation,
        )

    def _handle_clear_confirmation(
        self, result: ClearConfirmationResult | None
    ) -> None:
        if result is None or result.action == ClearAction.CANCEL:
            self._focus_input()
            return

        if result.action == ClearAction.CLEAR:
            self._do_clear_conversation()
        elif result.action == ClearAction.SUMMARIZE:
            self._do_summarize_and_clear()

    def _do_clear_conversation(self, summary: str | None = None) -> None:
        conversation_view = self.query_one("#conversation", ConversationView)
        conversation_view.clear()
        self.conversation.clear()

        if summary:
            formatted_summary = format_summary_as_user_message(summary)
            conversation_view.add_summary_message(formatted_summary)
            self.conversation.add_user_message(formatted_summary)

        self._focus_input()

    def _do_summarize_and_clear(self) -> None:
        # Clear the UI but keep messages for the API call
        conversation_view = self.query_one("#conversation", ConversationView)
        conversation_view.clear()

        # Show loading indicator
        self._current_agent_message = conversation_view.add_agent_message(
            "Generating summary..."
        )

        # Run as async task
        asyncio.create_task(self._generate_summary_async())

    async def _generate_summary_async(self) -> None:
        try:
            summary = await generate_conversation_summary(
                client=self.client,
                messages=self.conversation.messages,
                model=self.config.provider.model,
            )
            if self._current_agent_message:
                self._current_agent_message.remove()
                self._current_agent_message = None
            self._show_summary(summary)
        except Exception as e:
            if self._current_agent_message:
                self._current_agent_message.remove()
                self._current_agent_message = None
            self._show_summary(f"Summarization failed. Error: {e}")

    def action_toggle_sidebar(self) -> None:
        sidebar = self.query_one("#sidebar", SessionSidebar)
        sidebar.toggle()

    def action_toggle_file_browser(self) -> None:
        file_browser = self.query_one("#file-browser", FileBrowser)
        file_browser.toggle()

    def on_file_browser_file_selected(self, event: FileBrowserFileSelected) -> None:
        """Handle file selection from the file browser."""
        # For now, just focus back to input - later this will open in editor
        path = event.path
        relative_path = path.relative_to(self.session_context.git_root)
        self.notify(f"Selected: {relative_path}", title="File")
        self._focus_input()

    def action_cancel(self) -> None:
        if self._tool_handler.cancellation_token:
            self._tool_handler.cancellation_token.cancel()

        self._runner.cancel()

        for worker in self.workers:
            if worker.is_running:
                worker.cancel()

    def action_quit(self) -> None:
        self._save_session_history()
        self.exit()

    def _save_session_history(self) -> None:
        try:
            filepath = self._history_manager.save(
                messages=self.conversation.messages,
                stats=self.stats.to_dict(),
                sub_agent_traces=self._tool_handler.get_sub_agent_traces() or None,
                usage_snapshots=[s.to_dict() for s in self.stats.get_all_snapshots()],
            )
            if filepath:
                logger.info("Session history saved to %s", filepath)
        except Exception as e:
            logger.warning("Failed to save session history: %s", e)


