import logging
from typing import Any

from anthropic import AsyncAnthropic
from anthropic.types import MessageParam, TextBlock

from hypergolic.prompts.paths import SUMMARIZE_CONVERSATION_PROMPT_PATH

logger = logging.getLogger(__name__)


def _extract_text_from_content(content: str | list[Any]) -> str:
    if isinstance(content, str):
        return content

    text_parts = []
    for block in content:
        if isinstance(block, dict):
            block_type = block.get("type")
            if block_type == "text":
                text_parts.append(block.get("text", ""))
            elif block_type == "tool_use":
                tool_name = block.get("name", "unknown")
                tool_input = block.get("input", {})
                text_parts.append(f"[Called tool: {tool_name} with {tool_input}]")
            elif block_type == "tool_result":
                result_content = block.get("content", "")
                if isinstance(result_content, str):
                    # Truncate long tool results
                    if len(result_content) > 500:
                        result_content = result_content[:500] + "...[truncated]"
                    text_parts.append(f"[Tool result: {result_content}]")
        elif hasattr(block, "type"):
            if block.type == "text":
                text_parts.append(block.text)
            elif block.type == "tool_use":
                text_parts.append(f"[Called tool: {block.name} with {block.input}]")

    return "\n".join(text_parts)


def _format_conversation_as_transcript(messages: list[MessageParam]) -> str:
    """Convert messages into a readable transcript for summarization.

    Rather than passing messages as a conversation to continue, we serialize
    them into a transcript that the model can summarize.
    """
    lines: list[str] = []

    for msg in messages:
        role = msg.get("role", "user")
        content = msg.get("content", "")
        text = _extract_text_from_content(content)

        if not text.strip():
            continue

        prefix = "USER" if role == "user" else "ASSISTANT"
        lines.append(f"{prefix}: {text}")

    return "\n\n".join(lines)


async def generate_conversation_summary(
    client: AsyncAnthropic,
    messages: list[MessageParam],
    model: str,
) -> str:
    if not messages:
        logger.info("No messages to summarize")
        return "No messages to summarize."

    logger.info(
        "Generating summary for %d original messages using model %s",
        len(messages),
        model,
    )

    # Convert messages to a transcript string
    transcript = _format_conversation_as_transcript(messages)
    logger.info("Converted to transcript of %d chars", len(transcript))

    if not transcript.strip():
        logger.warning("No text content found in messages")
        return "No text content to summarize."

    system_prompt = SUMMARIZE_CONVERSATION_PROMPT_PATH.read_text().strip()

    # Wrap transcript in a single user message asking for summary
    # This prevents the model from continuing the conversation
    summary_request = [{"role": "user", "content": f"Please summarize this conversation:\n\n{transcript}"}]

    try:
        response = await client.messages.create(
            model=model,
            max_tokens=2048,
            system=system_prompt,
            messages=summary_request,
        )
    except Exception as e:
        logger.exception("API call failed during summary generation: %s", e)
        raise

    logger.info(
        "API response received: stop_reason=%s, content_blocks=%d, usage=%s",
        response.stop_reason,
        len(response.content),
        response.usage,
    )

    # Log each content block
    for i, block in enumerate(response.content):
        block_type = type(block).__name__
        if isinstance(block, TextBlock):
            text_preview = (
                block.text[:200] + "..." if len(block.text) > 200 else block.text
            )
            logger.debug(
                "Content block %d: type=%s, text=%r", i, block_type, text_preview
            )
        else:
            logger.debug("Content block %d: type=%s, block=%s", i, block_type, block)

    text_parts = [
        block.text for block in response.content if isinstance(block, TextBlock)
    ]
    if text_parts:
        summary = "\n\n".join(text_parts)
        logger.info("Summary generated successfully, length: %d chars", len(summary))
        return summary

    logger.warning(
        "Summary generation returned no text content. "
        "Stop reason: %s, Content blocks: %d, Block types: %s",
        response.stop_reason,
        len(response.content),
        [type(b).__name__ for b in response.content],
    )
    return "Summary generation returned empty response."


def format_summary_as_user_message(summary: str) -> str:
    return f"*Previous session summary:*\n\n{summary}"
