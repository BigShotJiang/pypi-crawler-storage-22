def test_runner_works():
    assert 1 + 1 != 3
