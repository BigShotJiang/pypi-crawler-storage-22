"""Code analysis passes for different languages."""
