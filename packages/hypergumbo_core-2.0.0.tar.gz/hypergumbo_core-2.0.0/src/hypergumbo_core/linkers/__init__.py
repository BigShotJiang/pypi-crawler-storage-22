"""Cross-language linkers for hypergumbo.

Linkers create edges between symbols from different language analyzers,
enabling cross-language call graph construction.
"""
