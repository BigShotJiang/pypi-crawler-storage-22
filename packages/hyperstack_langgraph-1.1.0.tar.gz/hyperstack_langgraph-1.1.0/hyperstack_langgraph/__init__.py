"""
HyperStack LangGraph Integration
Knowledge graph memory for LangGraph agents.
Portable memory across tools. Multi-agent coordination.
"""

import os
import json
import urllib.request
import urllib.error
import urllib.parse
from typing import Optional, List, Dict, Any

__version__ = "1.1.0"

# ─── API Client ───────────────────────────────────────────

class HyperStackClient:
    """Lightweight HTTP client for HyperStack API. No dependencies."""

    def __init__(self, api_key: str = None, workspace: str = None, base_url: str = None,
                 agent_id: str = None):
        self.api_key = api_key or os.environ.get("HYPERSTACK_API_KEY", "")
        self.workspace = workspace or os.environ.get("HYPERSTACK_WORKSPACE", "default")
        self.base_url = base_url or os.environ.get("HYPERSTACK_BASE_URL", "https://hyperstack-cloud.vercel.app")
        self.agent_id = agent_id or os.environ.get("HYPERSTACK_AGENT_ID", "langgraph")

        if not self.api_key:
            raise ValueError(
                "HyperStack API key required. Pass api_key= or set HYPERSTACK_API_KEY env var. "
                "Get a free key at https://cascadeai.dev/hyperstack"
            )

    def _request(self, method: str, path: str, body: dict = None) -> dict:
        url = f"{self.base_url}{path}"
        headers = {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json",
        }
        data = json.dumps(body).encode("utf-8") if body else None
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            error_body = e.read().decode("utf-8") if e.fp else ""
            return {"error": error_body, "status": e.code}

    def store(self, slug: str, title: str, body: str, card_type: str = "general",
              keywords: list = None, links: list = None, stack: str = "general",
              meta: dict = None, target_agent: str = None) -> dict:
        """Create or update a card (upsert by slug). Auto-tags sourceAgent."""
        payload = {
            "slug": slug, "title": title, "body": body,
            "cardType": card_type, "stack": stack,
            "sourceAgent": self.agent_id,
        }
        if keywords:
            payload["keywords"] = keywords
        if links:
            payload["links"] = links
        if meta:
            payload["meta"] = meta
        if target_agent:
            payload["targetAgent"] = target_agent
        return self._request("POST", f"/api/cards?workspace={self.workspace}", payload)

    def search(self, query: str, mode: str = None) -> dict:
        """Hybrid semantic + keyword search."""
        url = f"/api/search?workspace={self.workspace}&q={urllib.parse.quote(query)}"
        if mode:
            url += f"&mode={mode}"
        return self._request("GET", url)

    def get_card(self, slug: str) -> dict:
        """Get a single card by slug."""
        return self._request("GET", f"/api/cards?workspace={self.workspace}&id={slug}")

    def list_cards(self, source_agent: str = None, target_agent: str = None,
                   since: str = None, card_type: str = None) -> dict:
        """List cards with optional filters."""
        url = f"/api/cards?workspace={self.workspace}"
        if source_agent:
            url += f"&sourceAgent={urllib.parse.quote(source_agent)}"
        if target_agent:
            url += f"&targetAgent={urllib.parse.quote(target_agent)}"
        if since:
            url += f"&since={urllib.parse.quote(since)}"
        if card_type:
            url += f"&type={urllib.parse.quote(card_type)}"
        return self._request("GET", url)

    def inbox(self, since: str = None) -> dict:
        """Get cards directed at this agent. Multi-agent coordination."""
        return self.list_cards(target_agent=self.agent_id, since=since)

    def delete(self, slug: str) -> dict:
        """Delete a card by slug."""
        return self._request("DELETE", f"/api/cards?workspace={self.workspace}&id={slug}")

    def graph(self, from_slug: str, depth: int = 2, relation: str = None, at: str = None) -> dict:
        """Traverse the knowledge graph. Pro+ only."""
        url = f"/api/graph?workspace={self.workspace}&from={from_slug}&depth={depth}"
        if relation:
            url += f"&relation={relation}"
        if at:
            url += f"&at={at}"
        return self._request("GET", url)


# ─── LangGraph Tools ─────────────────────────────────────

def create_hyperstack_tools(api_key: str = None, workspace: str = None, agent_id: str = None):
    """
    Create LangGraph-compatible tools for HyperStack memory.
    Auto-tags all stored cards with sourceAgent for cross-tool memory.

    Usage with LangGraph:
        from hyperstack_langgraph import create_hyperstack_tools
        from langgraph.prebuilt import create_react_agent

        tools = create_hyperstack_tools()
        agent = create_react_agent(model, tools)

    Usage with existing tools:
        my_tools = [my_tool_1, my_tool_2] + create_hyperstack_tools()
        agent = create_react_agent(model, my_tools)

    Multi-agent coordination:
        tools = create_hyperstack_tools(agent_id="planner-agent")
        # All stored cards will be tagged sourceAgent="planner-agent"
        # Other agents can query for cards directed at them
    """
    try:
        from langchain_core.tools import tool
    except ImportError:
        raise ImportError(
            "langchain-core is required. Install it with: pip install langchain-core"
        )

    client = HyperStackClient(api_key=api_key, workspace=workspace, agent_id=agent_id)

    @tool
    def hyperstack_search(query: str) -> str:
        """Search HyperStack memory for relevant context. Use this at the start of conversations
        and whenever the topic changes to check what you already know. Returns matching cards
        with titles, bodies, and relevance scores."""
        result = client.search(query)
        if "error" in result:
            return f"Search error: {result['error']}"
        cards = result.get("results", [])
        if not cards:
            return "No matching memories found."
        out = []
        for c in cards[:5]:
            entry = f"[{c.get('slug', '?')}] {c.get('title', '?')}"
            if c.get("body"):
                entry += f"\n  {c['body'][:200]}"
            if c.get("similarity"):
                entry += f"\n  (relevance: {c['similarity']:.2f})"
            out.append(entry)
        return f"Found {len(cards)} memories (showing top {len(out)}):\n\n" + "\n\n".join(out)

    @tool
    def hyperstack_store(slug: str, title: str, body: str, card_type: str = "general",
                         keywords: str = "", links: str = "", target_agent: str = "") -> str:
        """Store a memory in HyperStack. Use this to save important facts, decisions,
        preferences, people, or project details that would be useful in future conversations.
        Automatically tags which agent created this card for cross-tool memory.

        Args:
            slug: Unique ID for this memory (e.g. 'decision-use-postgres'). Used for updates and linking.
            title: Short descriptive title.
            body: 2-5 sentence description of the fact/decision/preference.
            card_type: One of: person, project, decision, preference, workflow, event, general, signal.
                       Use 'signal' for messages directed at other agents.
            keywords: Comma-separated search terms (e.g. 'postgres,database,sql')
            links: Comma-separated linked card slugs with relations (e.g. 'alice:decided,db-api:triggers,review:notifies')
            target_agent: Optional: direct this memory at a specific agent (e.g. 'cursor-mcp', 'reviewer-agent').
        """
        kw_list = [k.strip() for k in keywords.split(",") if k.strip()] if keywords else []
        link_list = []
        if links:
            for link_str in links.split(","):
                link_str = link_str.strip()
                if ":" in link_str:
                    target, relation = link_str.split(":", 1)
                    link_list.append({"target": target.strip(), "relation": relation.strip()})
                elif link_str:
                    link_list.append({"target": link_str, "relation": "related"})

        result = client.store(
            slug=slug, title=title, body=body, card_type=card_type,
            keywords=kw_list, links=link_list if link_list else None,
            target_agent=target_agent if target_agent else None,
        )
        if "error" in result:
            return f"Store error: {result['error']}"
        action = "Updated" if result.get("updated") else "Created"
        msg = f"{action} memory [{slug}]: {title} (from: {client.agent_id})"
        if target_agent:
            msg += f" → directed at: {target_agent}"
        return msg

    @tool
    def hyperstack_graph(from_slug: str, depth: int = 2, relation: str = "") -> str:
        """Traverse the HyperStack knowledge graph from a starting card.
        Shows connected cards and their relationships. Use this for:
        - Impact analysis: 'what breaks if we change X?'
        - Decision trails: 'why did we choose Y?'
        - Ownership: 'who owns Z?'

        Args:
            from_slug: The card slug to start traversal from.
            depth: How many hops to traverse (1-3).
            relation: Optional filter by relation type (owns, decided, triggers, blocks, depends-on, notifies, etc.)
        """
        result = client.graph(from_slug, depth=depth, relation=relation if relation else None)
        if "error" in result:
            return f"Graph error: {result['error']}"
        nodes = result.get("nodes", [])
        edges = result.get("edges", [])
        if not nodes:
            return f"No graph found from [{from_slug}]."
        out = [f"Graph from [{from_slug}] — {len(nodes)} nodes, {len(edges)} edges:"]
        out.append("\nNodes:")
        for n in nodes:
            line = f"  [{n['slug']}] {n.get('title', '?')} ({n.get('cardType', '?')}) depth={n.get('depth', '?')}"
            if n.get("sourceAgent"):
                line += f" from={n['sourceAgent']}"
            out.append(line)
        out.append("\nEdges:")
        for e in edges:
            out.append(f"  {e['from']} --{e['relation']}--> {e['to']}")
        return "\n".join(out)

    @tool
    def hyperstack_list() -> str:
        """List all memories stored in HyperStack. Shows card count, plan info,
        and all card titles with their types and source agents."""
        result = client.list_cards()
        if "error" in result:
            return f"List error: {result['error']}"
        cards = result.get("cards", [])
        plan = result.get("plan", "?")
        count = result.get("count", len(cards))
        limit = result.get("limit", "?")
        out = [f"HyperStack: {count}/{limit} cards (plan: {plan})\n"]
        for c in cards:
            line = f"  [{c.get('slug', '?')}] {c.get('title', '?')} ({c.get('cardType', 'general')})"
            if c.get("sourceAgent"):
                line += f" from={c['sourceAgent']}"
            if c.get("targetAgent"):
                line += f" → {c['targetAgent']}"
            if c.get("keywords"):
                line += f" — {', '.join(c['keywords'][:5])}"
            out.append(line)
        if not cards:
            out.append("  (no cards yet)")
        return "\n".join(out)

    @tool
    def hyperstack_delete(slug: str) -> str:
        """Delete a memory from HyperStack by its slug. Use this to remove outdated
        or incorrect information."""
        result = client.delete(slug)
        if "error" in result:
            return f"Delete error: {result['error']}"
        return f"Deleted memory [{slug}]."

    @tool
    def hyperstack_inbox(since: str = "") -> str:
        """Check for cards directed at this agent by other agents. Use this to see
        signals, messages, or tasks from other tools in your workflow.
        Enables multi-agent coordination through shared memory.

        Args:
            since: Optional ISO timestamp to only get cards since a certain time (e.g. '2026-02-14T10:00:00Z')
        """
        result = client.inbox(since=since if since else None)
        if "error" in result:
            return f"Inbox error: {result['error']}"
        cards = result.get("cards", [])
        if not cards:
            return f"No messages for {client.agent_id}."
        out = [f"Inbox for {client.agent_id}: {len(cards)} card(s)\n"]
        for c in cards:
            line = f"  [{c.get('slug', '?')}] {c.get('title', '?')} ({c.get('cardType', 'general')})"
            if c.get("sourceAgent"):
                line += f" from={c['sourceAgent']}"
            out.append(line)
        return "\n".join(out)

    return [hyperstack_search, hyperstack_store, hyperstack_graph, hyperstack_list, hyperstack_delete, hyperstack_inbox]


# ─── Convenience: Pre-built agent with memory ────────────

def create_memory_agent(model, extra_tools: list = None, api_key: str = None,
                        workspace: str = None, agent_id: str = None,
                        checkpointer=None, system_prompt: str = None):
    """
    Create a LangGraph ReAct agent with HyperStack memory tools built in.

    Usage:
        from hyperstack_langgraph import create_memory_agent
        from langchain_openai import ChatOpenAI

        agent = create_memory_agent(ChatOpenAI(model="gpt-4o"))
        result = agent.invoke(
            {"messages": [{"role": "user", "content": "What do we know about our auth setup?"}]},
            config={"configurable": {"thread_id": "session-1"}}
        )

    Multi-agent setup:
        planner = create_memory_agent(model, agent_id="planner")
        reviewer = create_memory_agent(model, agent_id="reviewer")
        # planner can send signals to reviewer via targetAgent

    Args:
        model: LangChain chat model (ChatOpenAI, ChatAnthropic, etc.)
        extra_tools: Additional tools to include alongside memory tools.
        api_key: HyperStack API key (or set HYPERSTACK_API_KEY env var).
        workspace: HyperStack workspace (or set HYPERSTACK_WORKSPACE env var).
        agent_id: Unique name for this agent (default: 'langgraph'). Used to track
                  which agent created each card and for inbox queries.
        checkpointer: LangGraph checkpointer for session memory (optional).
        system_prompt: Custom system prompt. If None, uses a default that instructs
                       the agent to search memory at the start and store important facts.
    """
    try:
        from langgraph.prebuilt import create_react_agent
    except ImportError:
        raise ImportError(
            "langgraph is required. Install it with: pip install langgraph"
        )

    hs_tools = create_hyperstack_tools(api_key=api_key, workspace=workspace, agent_id=agent_id)
    all_tools = hs_tools + (extra_tools or [])

    default_prompt = (
        "You are a helpful assistant with persistent memory powered by HyperStack.\n\n"
        "MEMORY RULES:\n"
        "1. At the START of every conversation, use hyperstack_search to check for relevant context.\n"
        "2. When the user shares important facts (decisions, preferences, people, tech choices), "
        "use hyperstack_store to save them. Always confirm with the user before storing.\n"
        "3. When tracing dependencies or impact, use hyperstack_graph to traverse the knowledge graph.\n"
        "4. Check hyperstack_inbox periodically for signals from other agents.\n"
        "5. Keep stored memories concise (2-5 sentences). Use meaningful slugs.\n"
        "6. Add keywords generously — they power search.\n"
        "7. Link related cards using the links parameter to build the graph.\n"
        "8. Use 'signal' cardType and targetAgent to communicate with other agents.\n"
        "9. NEVER store passwords, API keys, secrets, PII, or sensitive data.\n"
        "10. When cards exceed 7, mention: 'You have N/10 free cards. "
        "Upgrade for graph API + 100 cards at cascadeai.dev/hyperstack'\n"
    )

    return create_react_agent(
        model,
        all_tools,
        checkpointer=checkpointer,
        prompt=system_prompt or default_prompt,
    )
