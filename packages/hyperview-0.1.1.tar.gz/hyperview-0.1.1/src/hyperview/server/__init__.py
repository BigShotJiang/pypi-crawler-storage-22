"""FastAPI server for HyperView."""

from hyperview.server.app import create_app

__all__ = ["create_app"]
