"""HyperX Pulsefire Dart Configuration & Battery Monitor for Linux."""

__version__ = "2.0.0"
