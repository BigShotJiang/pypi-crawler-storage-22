"""HYPHA module"""
