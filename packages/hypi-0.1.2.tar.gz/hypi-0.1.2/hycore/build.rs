fn main() {
    build_info_build::build_script();
}
