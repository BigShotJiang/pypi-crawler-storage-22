//! Common helpers shared by the runtime and extensions.

pub mod error;
pub mod lazy;
pub mod opaque;
pub mod ref_id;
