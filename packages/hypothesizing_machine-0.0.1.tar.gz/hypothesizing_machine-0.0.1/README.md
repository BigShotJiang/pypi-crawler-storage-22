# Hypothesizing Machine
Hypothesizing machine comes up with hypotheses.
<pre>
  pip install hypothesizing-machine
</pre>
Then:
```Python
  # Python
  import hypothesizing_machine
```
