# IA Cost Tracker

[![PyPI version](https://badge.fury.io/py/ia-cost-tracker.svg)](https://badge.fury.io/py/ia-cost-tracker)
[![Python Versions](https://img.shields.io/pypi/pyversions/ia-cost-tracker.svg)](https://pypi.org/project/ia-cost-tracker/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://pepy.tech/badge/ia-cost-tracker)](https://pepy.tech/project/ia-cost-tracker)

Rastreie custos de APIs de IA (Maritaca, Anthropic) automaticamente.

Biblioteca Python para rastreamento e auditoria de custos de APIs de IA (Maritaca, Anthropic).

## Instalação

```bash
pip install ia_tracker_qca

```

Uso básico (não recomendado pois demora mais por causa que busca os valores atualizados na hora!):

```python
from ia_tracker_qca import IATracker

# Inicializar
tracker = IATracker(
    db_connection_string="postgresql://user:pass@localhost/db",
    maritaca_api_key="sua-chave",
    anthropic_api_key="sua-chave"
)

# Sincronizar preços dos modelos
tracker.sincronizar_precos_maritaca() #essa chamada a api demora uns 10segs as vezes.
tracker.sincronizar_precos_anthropic()

# Registrar uma chamada
tracker.registrar_chamada(
    provedor="maritaca",
    modelo="sabia-2-medium",
    tokens_input=150,
    tokens_output=75,
    aplicacao="meu-app",
    tag_funcionalidade="chat",
    usuario="usuario@email.com"
)

# Obter estatísticas
stats = tracker.obter_estatisticas_aplicacao("meu-app")
print(f"Custo total: R$ {stats['custo_total']}")
print(f"Total de chamadas: {stats['total_chamadas']}")

```


Exemplo de uso em uma aplicação em produção:
```python
from ia_tracker_qca import IATracker

tracker = IATracker(db_connection_string=os.getenv("DB_CONNECTION_STRING"))

# Após chamar a IA
tracker.registrar_chamada(
    provedor="maritaca",  # ou "anthropic"
    modelo="sabia-4",
    tokens_input=150,
    tokens_output=75,
    aplicacao="meu-app",
    tag_funcionalidade="chat",
    usuario="user@email.com"  # opcional
)
```

Desenvolvimento:

```bash
# Clonar repositório
git clone https://github.com/suaempresa/ia-cost-tracker
cd ia-cost-tracker

# Instalar em modo desenvolvimento
pip install -e ".[dev]"

# Rodar testes
pytest

# Formatar código
black src/
isort src/
```

Consultar Custos:

```python
from datetime import datetime, timedelta

# Últimos 7 dias
data_inicio = datetime.now() - timedelta(days=7)
stats = tracker.obter_estatisticas_aplicacao(
    aplicacao="meu-app",
    data_inicio=data_inicio
)

# Listar modelos disponíveis
modelos = tracker.listar_modelos(provedor="maritaca")
for modelo in modelos:
    print(f"{modelo.nome_modelo}: "
          f"R$ {modelo.custo_input_por_1k}/1k input, "
          f"R$ {modelo.custo_output_por_1k}/1k output")

```

# Para att a lib:

# ⚠️ ANTES DE RODAR O COMANDO:
# 1. Editar arquivos (código/README)
# 2. Mudar version em pyproject.toml
# 3. Mudar __version__ em src/ia_cost_tracker/__init__.py
# 4. Mudar v0.1.X abaixo para a nova versão

```bash
Remove-Item -Recurse -Force dist, build -ErrorAction SilentlyContinue; Get-ChildItem -Recurse -Filter "*.egg-info" | Remove-Item -Recurse -Force; python -m build; python -m twine upload dist/*; git add .; git commit -m "Release v0.1.X"; git tag v0.1.X; git push origin main; git push --tags

```

# ✅ Depois disso NÃO precisa fazer mais NADA!
