"""
IA Cost Tracker - Biblioteca para rastreamento de custos de APIs de IA.

Esta biblioteca permite rastrear e auditar custos de chamadas a APIs de IA
como Maritaca e Anthropic, salvando informações detalhadas em banco de dados.

Para Maritaca: sincroniza preços via API
Para Anthropic: usa preços mantidos no banco de dados
"""

__version__ = "0.1.2"

from .tracker import IATracker
from .exceptions import (
    IATrackerError,
    DatabaseError,
    ProviderError,
    ModelNotFoundError,
)

__all__ = [
    "IATracker",
    "IATrackerError",
    "DatabaseError",
    "ProviderError",
    "ModelNotFoundError",
]