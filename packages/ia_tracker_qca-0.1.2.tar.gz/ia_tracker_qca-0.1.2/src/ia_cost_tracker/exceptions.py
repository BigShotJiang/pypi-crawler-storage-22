"""Exceções personalizadas para o IA Cost Tracker."""


class IATrackerError(Exception):
    """Exceção base para erros do IA Cost Tracker."""
    pass


class DatabaseError(IATrackerError):
    """Exceção para erros relacionados ao banco de dados."""
    pass


class ProviderError(IATrackerError):
    """Exceção para erros relacionados aos provedores de IA."""
    pass


class ModelNotFoundError(IATrackerError):
    """Exceção quando um modelo não é encontrado no banco de dados."""
    pass


class ConfigurationError(IATrackerError):
    """Exceção para erros de configuração."""
    pass