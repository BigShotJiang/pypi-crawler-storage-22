"""Modelos de dados para o IA Cost Tracker."""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class ModeloIA:
    """
    Representa um modelo de IA com seus custos.
    
    Attributes:
        id_modelo: ID do modelo no banco de dados
        provedor: Nome do provedor (maritaca, anthropic, etc)
        nome_modelo: Nome do modelo
        custo_input_por_1k: Custo por 1000 tokens de entrada
        custo_output_por_1k: Custo por 1000 tokens de saída
        ativo: Se o modelo está ativo
        criado_em: Data de criação do registro
    """
    provedor: str
    nome_modelo: str
    custo_input_por_1k: float
    custo_output_por_1k: float
    id_modelo: Optional[int] = None
    ativo: bool = True
    criado_em: Optional[datetime] = None


@dataclass
class UsoToken:
    """
    Representa um registro de uso de tokens.
    
    Attributes:
        id_modelo: ID do modelo utilizado
        tokens_input: Quantidade de tokens de entrada
        tokens_output: Quantidade de tokens de saída
        custo_input: Custo total da entrada
        custo_output: Custo total da saída
        tag_funcionalidade: Tag para identificar a funcionalidade
        aplicacao: Nome da aplicação que fez a chamada
        usuario: Usuário que realizou a chamada
        tempo_resposta_ms: Tempo de resposta em milissegundos
        erro: Se houve erro na chamada
        mensagem_erro: Mensagem de erro, se houver
        id_uso: ID do registro (gerado pelo banco)
        timestamp_uso: Timestamp do uso
        tokens_total: Total de tokens (calculado)
        custo_total: Custo total (calculado)
    """
    id_modelo: int
    tokens_input: int
    tokens_output: int
    custo_input: float
    custo_output: float
    tag_funcionalidade: Optional[str] = None
    aplicacao: Optional[str] = None
    usuario: Optional[str] = None
    tempo_resposta_ms: Optional[int] = None
    erro: bool = False
    mensagem_erro: Optional[str] = None
    id_uso: Optional[int] = None
    timestamp_uso: Optional[datetime] = field(default_factory=datetime.now)
    tokens_total: Optional[int] = field(init=False)
    custo_total: Optional[float] = field(init=False)
    
    def __post_init__(self):
        """Calcula campos derivados."""
        self.tokens_total = self.tokens_input + self.tokens_output
        self.custo_total = self.custo_input + self.custo_output