"""Provider para Anthropic (Claude)."""

from typing import List, Dict, Optional
import logging

from .base import BaseProvider
from ..models import ModeloIA
from ..exceptions import ProviderError

logger = logging.getLogger(__name__)


class AnthropicProvider(BaseProvider):
    """
    Provider para integração com Anthropic (Claude).
    
    Busca modelos e preços diretamente do banco de dados,
    já que a Anthropic não possui API pública para consulta de preços.
    
    Os preços devem ser mantidos atualizados manualmente no banco.
    """
    
    def __init__(self, db_manager=None):
        """
        Inicializa o provider da Anthropic.
        
        Args:
            db_manager: Instância do DatabaseManager para buscar preços do banco
        """
        super().__init__("anthropic")
        self.db_manager = db_manager
    
    def buscar_modelos_disponiveis(self) -> List[ModeloIA]:
        """
        Busca modelos disponíveis da Anthropic do banco de dados.
        
        Returns:
            Lista de ModeloIA com modelos e preços
        
        Raises:
            ProviderError: Se o DatabaseManager não estiver configurado
        """
        if not self.db_manager:
            raise ProviderError(
                "DatabaseManager não configurado para AnthropicProvider. "
                "Os modelos da Anthropic são gerenciados diretamente no banco de dados."
            )
        
        modelos = self.db_manager.listar_modelos(
            provedor=self.provider_name,
            apenas_ativos=True
        )
        
        logger.info(f"Buscados {len(modelos)} modelos da Anthropic do banco de dados")
        return modelos
    
    def calcular_custo(self, nome_modelo: str, tokens_input: int, 
                      tokens_output: int, custo_input_1k: float,
                      custo_output_1k: float) -> Dict[str, float]:
        """
        Calcula o custo de uma chamada à Anthropic.
        
        Args:
            nome_modelo: Nome do modelo utilizado
            tokens_input: Quantidade de tokens de entrada
            tokens_output: Quantidade de tokens de saída
            custo_input_1k: Custo por 1000 tokens de entrada
            custo_output_1k: Custo por 1000 tokens de saída
        
        Returns:
            Dicionário com custos calculados
        """
        custo_input = (tokens_input / 1000) * custo_input_1k
        custo_output = (tokens_output / 1000) * custo_output_1k
        custo_total = custo_input + custo_output
        
        return {
            'custo_input': round(custo_input, 6),
            'custo_output': round(custo_output, 6),
            'custo_total': round(custo_total, 6)
        }