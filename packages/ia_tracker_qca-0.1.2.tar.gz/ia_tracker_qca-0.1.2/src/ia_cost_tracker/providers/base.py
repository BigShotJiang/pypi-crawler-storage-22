"""Classe base para provedores de IA."""

from abc import ABC, abstractmethod
from typing import Dict, List
from ..models import ModeloIA


class BaseProvider(ABC):
    """
    Classe base abstrata para provedores de IA.
    
    Cada provedor (Maritaca, Anthropic, etc) deve herdar desta classe
    e implementar os métodos abstratos.
    """
    
    def __init__(self, provider_name: str):
        """
        Inicializa o provedor base.
        
        Args:
            provider_name: Nome do provedor
        """
        self.provider_name = provider_name
    
    @abstractmethod
    def buscar_modelos_disponiveis(self) -> List[ModeloIA]:
        """
        Busca a lista de modelos disponíveis do provedor.
        
        Returns:
            Lista de objetos ModeloIA com os modelos e preços
        
        Raises:
            ProviderError: Se houver erro ao buscar os modelos
        """
        pass
    
    @abstractmethod
    def calcular_custo(self, nome_modelo: str, tokens_input: int, 
                      tokens_output: int, custo_input_1k: float,
                      custo_output_1k: float) -> Dict[str, float]:
        """
        Calcula o custo de uma chamada.
        
        Args:
            nome_modelo: Nome do modelo utilizado
            tokens_input: Quantidade de tokens de entrada
            tokens_output: Quantidade de tokens de saída
            custo_input_1k: Custo por 1000 tokens de entrada
            custo_output_1k: Custo por 1000 tokens de saída
        
        Returns:
            Dicionário com 'custo_input', 'custo_output' e 'custo_total'
        """
        pass