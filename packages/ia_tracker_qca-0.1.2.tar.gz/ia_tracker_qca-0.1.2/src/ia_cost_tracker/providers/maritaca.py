"""Provider para Maritaca AI."""

import requests
from typing import List, Dict
import logging

from .base import BaseProvider
from ..models import ModeloIA
from ..exceptions import ProviderError

logger = logging.getLogger(__name__)


class MaritacaProvider(BaseProvider):
    """
    Provider para integração com Maritaca AI.
    
    Busca modelos e preços através da API da Maritaca.
    """
    
    def __init__(self, api_key: str, base_url: str = "https://chat.maritaca.ai"):
        """
        Inicializa o provider da Maritaca.
        
        Args:
            api_key: Chave de API da Maritaca
            base_url: URL base da API (padrão: https://chat.maritaca.ai)
        """
        super().__init__("maritaca")
        self.api_key = api_key
        self.base_url = base_url.rstrip('/')
    
    def buscar_modelos_disponiveis(self) -> List[ModeloIA]:
        """
        Busca modelos disponíveis da API da Maritaca.
        
        A API retorna um dicionário com:
        - models: dict com modelos ativos (chave = nome do modelo)
        - deprecated_models: dict com modelos deprecados
        
        Cada modelo contém:
        - input_price: preço por token de entrada
        - output_price: preço por token de saída
        - offpeak_input_price: preço reduzido em horário de pico
        - offpeak_output_price: preço reduzido em horário de pico
        - batch_input_price: preço para lote
        - batch_output_price: preço para lote
        
        Returns:
            Lista de ModeloIA com modelos e preços
        
        Raises:
            ProviderError: Se houver erro ao buscar os modelos
        """
        url = f"{self.base_url}/api/chat/models"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        try:
            response = requests.get(url, headers=headers, timeout=30)
            response.raise_for_status()
            
            data = response.json()
            modelos = []
            
            # Processar modelos ativos
            if 'models' in data and isinstance(data['models'], dict):
                for nome_modelo, detalhes in data['models'].items():
                    # Preços vêm por token, convertemos para por 1k tokens
                    input_price_per_token = detalhes.get('input_price', 0)
                    output_price_per_token = detalhes.get('output_price', 0)
                    
                    # Converter para preço por 1k tokens
                    custo_input_por_1k = input_price_per_token * 1000
                    custo_output_por_1k = output_price_per_token * 1000
                    
                    modelo = ModeloIA(
                        provedor=self.provider_name,
                        nome_modelo=nome_modelo,
                        custo_input_por_1k=custo_input_por_1k,
                        custo_output_por_1k=custo_output_por_1k,
                        ativo=True
                    )
                    modelos.append(modelo)
                    
                    logger.debug(
                        f"Modelo {nome_modelo}: "
                        f"input={custo_input_por_1k:.6f}, "
                        f"output={custo_output_por_1k:.6f} por 1k tokens"
                    )
            
            # Opcional: Processar modelos deprecados (marcados como inativos)
            if 'deprecated_models' in data and isinstance(data['deprecated_models'], dict):
                for nome_modelo, detalhes in data['deprecated_models'].items():
                    # Modelos deprecados podem não ter preços, usar 0
                    modelo = ModeloIA(
                        provedor=self.provider_name,
                        nome_modelo=nome_modelo,
                        custo_input_por_1k=0.0,
                        custo_output_por_1k=0.0,
                        ativo=False
                    )
                    modelos.append(modelo)
                    
                    logger.debug(f"Modelo deprecado: {nome_modelo}")
            
            logger.info(f"Buscados {len(modelos)} modelos da Maritaca "
                       f"({sum(1 for m in modelos if m.ativo)} ativos)")
            return modelos
            
        except requests.RequestException as e:
            raise ProviderError(f"Erro ao buscar modelos da Maritaca: {str(e)}")
        except (KeyError, ValueError, TypeError) as e:
            raise ProviderError(f"Erro ao processar resposta da Maritaca: {str(e)}")
    
    def calcular_custo(self, nome_modelo: str, tokens_input: int, 
                      tokens_output: int, custo_input_1k: float,
                      custo_output_1k: float) -> Dict[str, float]:
        """
        Calcula o custo de uma chamada à Maritaca.
        
        Args:
            nome_modelo: Nome do modelo utilizado
            tokens_input: Quantidade de tokens de entrada
            tokens_output: Quantidade de tokens de saída
            custo_input_1k: Custo por 1000 tokens de entrada
            custo_output_1k: Custo por 1000 tokens de saída
        
        Returns:
            Dicionário com custos calculados
        """
        custo_input = (tokens_input / 1000) * custo_input_1k
        custo_output = (tokens_output / 1000) * custo_output_1k
        custo_total = custo_input + custo_output
        
        return {
            'custo_input': round(custo_input, 6),
            'custo_output': round(custo_output, 6),
            'custo_total': round(custo_total, 6)
        }