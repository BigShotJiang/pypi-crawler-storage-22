"""
Teste de integração para Anthropic.
Testa o rastreamento sem fazer chamadas reais à API.
"""

import os
import sys
from datetime import datetime
from dotenv import load_dotenv

# Adicionar o src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from ia_cost_tracker import IATracker

load_dotenv()


def test_listar_modelos_anthropic():
    """Testa a listagem de modelos da Anthropic do banco."""
    print("\n" + "="*70)
    print("TESTE 1: Listar Modelos da Anthropic do Banco")
    print("="*70)
    
    tracker = IATracker(
        db_connection_string=os.getenv("DB_CONNECTION_STRING")
    )
    
    modelos = tracker.listar_modelos_anthropic()
    
    print(f"\n✅ {len(modelos)} modelos encontrados:\n")
    
    for modelo in modelos:
        print(f"  📦 {modelo.nome_modelo}")
        print(f"     Input:  R$ {modelo.custo_input_por_1k:.6f} / 1k tokens")
        print(f"     Output: R$ {modelo.custo_output_por_1k:.6f} / 1k tokens")
        print(f"     Ativo:  {'✓' if modelo.ativo else '✗'}")
        print()
    
    return tracker, modelos


def test_registrar_chamada_anthropic(tracker):
    """Testa o registro de uma chamada simulada à Anthropic."""
    print("\n" + "="*70)
    print("TESTE 2: Registrar Chamada Simulada à Anthropic")
    print("="*70)
    
    # Simular uma chamada ao Claude
    modelo_teste = "claude-3-5-sonnet-20241022"
    tokens_input = 150
    tokens_output = 75
    
    print(f"\n📝 Registrando chamada simulada:")
    print(f"   Modelo: {modelo_teste}")
    print(f"   Tokens Input: {tokens_input}")
    print(f"   Tokens Output: {tokens_output}")
    
    try:
        id_uso = tracker.registrar_chamada(
            provedor="anthropic",
            modelo=modelo_teste,
            tokens_input=tokens_input,
            tokens_output=tokens_output,
            aplicacao="test-app-anthropic",
            tag_funcionalidade="teste-integracao",
            usuario="teste@exemplo.com",
            tempo_resposta_ms=1234,
            erro=False
        )
        
        print(f"\n✅ Chamada registrada com sucesso!")
        print(f"   ID do registro: {id_uso}")
        
        # Buscar modelo para mostrar custo
        modelo_db = tracker.db.buscar_modelo("anthropic", modelo_teste)
        custo_input = (tokens_input / 1000) * modelo_db.custo_input_por_1k
        custo_output = (tokens_output / 1000) * modelo_db.custo_output_por_1k
        custo_total = custo_input + custo_output
        
        print(f"\n💰 Custos calculados:")
        print(f"   Input:  R$ {custo_input:.6f}")
        print(f"   Output: R$ {custo_output:.6f}")
        print(f"   Total:  R$ {custo_total:.6f}")
        
        return id_uso
        
    except Exception as e:
        print(f"\n❌ Erro ao registrar chamada: {str(e)}")
        raise


def test_estatisticas_anthropic(tracker):
    """Testa a consulta de estatísticas."""
    print("\n" + "="*70)
    print("TESTE 3: Consultar Estatísticas da Aplicação")
    print("="*70)
    
    stats = tracker.obter_estatisticas_aplicacao("test-app-anthropic")
    
    print(f"\n📊 Estatísticas da aplicação 'test-app-anthropic':\n")
    print(f"   Total de chamadas:     {stats.get('total_chamadas', 0)}")
    print(f"   Total de tokens:       {stats.get('total_tokens', 0):,}")
    print(f"   Tokens de input:       {stats.get('total_tokens_input', 0):,}")
    print(f"   Tokens de output:      {stats.get('total_tokens_output', 0):,}")
    print(f"   Custo total:           R$ {stats.get('custo_total', 0):.6f}")
    print(f"   Custo médio/chamada:   R$ {stats.get('custo_medio', 0):.6f}")
    print(f"   Tempo médio resposta:  {stats.get('tempo_medio_resposta_ms', 0):.0f} ms")
    print(f"   Total de erros:        {stats.get('total_erros', 0)}")


def test_chamada_com_erro_anthropic(tracker):
    """Testa o registro de uma chamada com erro."""
    print("\n" + "="*70)
    print("TESTE 4: Registrar Chamada com Erro")
    print("="*70)
    
    print(f"\n📝 Registrando chamada com erro simulado...")
    
    try:
        id_uso = tracker.registrar_chamada(
            provedor="anthropic",
            modelo="claude-3-5-sonnet-20241022",
            tokens_input=50,
            tokens_output=0,  # Nenhum output por causa do erro
            aplicacao="test-app-anthropic",
            tag_funcionalidade="teste-erro",
            usuario="teste@exemplo.com",
            tempo_resposta_ms=500,
            erro=True,
            mensagem_erro="Rate limit exceeded - teste simulado"
        )
        
        print(f"✅ Erro registrado com sucesso! ID: {id_uso}")
        
    except Exception as e:
        print(f"❌ Erro ao registrar: {str(e)}")
        raise


def test_modelo_inexistente(tracker):
    """Testa o comportamento com modelo que não existe no banco."""
    print("\n" + "="*70)
    print("TESTE 5: Tentar Usar Modelo Inexistente")
    print("="*70)
    
    print(f"\n📝 Tentando registrar chamada com modelo inexistente...")
    
    try:
        tracker.registrar_chamada(
            provedor="anthropic",
            modelo="claude-99-nao-existe",
            tokens_input=100,
            tokens_output=50,
            aplicacao="test-app-anthropic"
        )
        print("❌ ERRO: Deveria ter lançado exceção!")
        
    except Exception as e:
        print(f"✅ Exceção esperada capturada:")
        print(f"   {type(e).__name__}: {str(e)}")


if __name__ == "__main__":
    print("\n" + "="*70)
    print("TESTES DE INTEGRAÇÃO - ANTHROPIC")
    print("="*70)
    
    try:
        # Teste 1: Listar modelos
        tracker, modelos = test_listar_modelos_anthropic()
        
        if not modelos:
            print("\n⚠️  AVISO: Nenhum modelo da Anthropic encontrado no banco!")
            print("Execute o SQL fornecido para popular os modelos.")
            sys.exit(1)
        
        # Teste 2: Registrar chamada
        test_registrar_chamada_anthropic(tracker)
        
        # Teste 3: Consultar estatísticas
        test_estatisticas_anthropic(tracker)
        
        # Teste 4: Registrar erro
        test_chamada_com_erro_anthropic(tracker)
        
        # Teste 5: Modelo inexistente
        test_modelo_inexistente(tracker)
        
        print("\n" + "="*70)
        print("✅ TODOS OS TESTES PASSARAM!")
        print("="*70 + "\n")
        
    except Exception as e:
        print("\n" + "="*70)
        print("❌ ERRO NOS TESTES")
        print("="*70)
        print(f"\n{type(e).__name__}: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)