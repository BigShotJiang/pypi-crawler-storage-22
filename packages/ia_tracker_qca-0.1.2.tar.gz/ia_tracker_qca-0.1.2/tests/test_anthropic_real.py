"""
Teste com chamadas REAIS à API da Anthropic.
ATENÇÃO: Isso vai consumir créditos da sua conta!
"""

import os
import sys
from dotenv import load_dotenv

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from ia_cost_tracker import IATracker

load_dotenv()

# Verificar se tem a chave da API
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")
if not ANTHROPIC_API_KEY:
    print("❌ ANTHROPIC_API_KEY não encontrada no .env")
    print("Configure a chave antes de executar este teste.")
    sys.exit(1)


def test_chamada_real_com_tracking():
    """Faz uma chamada real à Anthropic com tracking automático."""
    from anthropic import Anthropic
    
    print("\n" + "="*70)
    print("TESTE COM CHAMADA REAL À ANTHROPIC")
    print("⚠️  ATENÇÃO: Isso vai consumir créditos!")
    print("="*70)
    
    # Inicializar tracker
    tracker = IATracker(
        db_connection_string=os.getenv("DB_CONNECTION_STRING")
    )
    
    # Inicializar cliente Anthropic
    client = Anthropic(api_key=ANTHROPIC_API_KEY)
    
    # Modelo a usar
    modelo = "claude-3-5-haiku-20241022"  # Mais barato para teste
    
    print(f"\n📞 Fazendo chamada ao modelo: {modelo}")
    print("   Prompt: 'Diga apenas: Olá! Teste funcionando.'")
    
    try:
        # Fazer a chamada
        response = client.messages.create(
            model=modelo,
            max_tokens=50,
            messages=[
                {"role": "user", "content": "Diga apenas: Olá! Teste funcionando."}
            ]
        )
        
        print(f"\n✅ Resposta recebida:")
        print(f"   {response.content[0].text}")
        
        # Extrair informações de uso
        tokens_input = response.usage.input_tokens
        tokens_output = response.usage.output_tokens
        
        print(f"\n📊 Uso de tokens:")
        print(f"   Input:  {tokens_input}")
        print(f"   Output: {tokens_output}")
        print(f"   Total:  {tokens_input + tokens_output}")
        
        # Registrar no tracker
        print(f"\n💾 Registrando no banco de dados...")
        
        id_uso = tracker.registrar_chamada(
            provedor="anthropic",
            modelo=modelo,
            tokens_input=tokens_input,
            tokens_output=tokens_output,
            aplicacao="test-real-anthropic",
            tag_funcionalidade="teste-api-real",
            usuario="teste@exemplo.com"
        )
        
        print(f"✅ Registrado com ID: {id_uso}")
        
        # Buscar custo
        modelo_db = tracker.db.buscar_modelo("anthropic", modelo)
        custo_input = (tokens_input / 1000) * modelo_db.custo_input_por_1k
        custo_output = (tokens_output / 1000) * modelo_db.custo_output_por_1k
        custo_total = custo_input + custo_output
        
        print(f"\n💰 Custo desta chamada:")
        print(f"   Input:  R$ {custo_input:.6f}")
        print(f"   Output: R$ {custo_output:.6f}")
        print(f"   Total:  R$ {custo_total:.6f}")
        
        return True
        
    except Exception as e:
        print(f"\n❌ Erro na chamada: {str(e)}")
        
        # Registrar o erro
        tracker.registrar_chamada(
            provedor="anthropic",
            modelo=modelo,
            tokens_input=0,
            tokens_output=0,
            aplicacao="test-real-anthropic",
            tag_funcionalidade="teste-api-real",
            usuario="teste@exemplo.com",
            erro=True,
            mensagem_erro=str(e)
        )
        
        raise


def test_decorator_real():
    """Testa o decorator com chamada real."""
    from anthropic import Anthropic
    
    print("\n" + "="*70)
    print("TESTE DO DECORATOR COM CHAMADA REAL")
    print("="*70)
    
    tracker = IATracker(
        db_connection_string=os.getenv("DB_CONNECTION_STRING")
    )
    
    client = Anthropic(api_key=ANTHROPIC_API_KEY)
    modelo = "claude-3-5-haiku-20241022"
    
    # Definir função com decorator
    @tracker.track_call(
        provedor="anthropic",
        modelo=modelo,
        aplicacao="test-decorator",
        tag_funcionalidade="teste-decorator-real"
    )
    def chat_simples(mensagem):
        return client.messages.create(
            model=modelo,
            max_tokens=50,
            messages=[{"role": "user", "content": mensagem}]
        )
    
    print(f"\n📞 Chamando função decorada...")
    
    response = chat_simples("Diga apenas: Decorator funcionando!")
    
    print(f"\n✅ Resposta: {response.content[0].text}")
    print(f"📊 Tokens: {response.usage.input_tokens} in / {response.usage.output_tokens} out")
    print(f"💾 Registro criado automaticamente pelo decorator!")


if __name__ == "__main__":
    print("\n⚠️  ATENÇÃO: Este teste faz chamadas REAIS à API da Anthropic!")
    resposta = input("Deseja continuar? (sim/não): ")
    
    if resposta.lower() not in ['sim', 's', 'yes', 'y']:
        print("Teste cancelado.")
        sys.exit(0)
    
    try:
        # Teste 1: Chamada manual
        test_chamada_real_com_tracking()
        
        # Teste 2: Com decorator
        test_decorator_real()
        
        print("\n" + "="*70)
        print("✅ TESTES REAIS CONCLUÍDOS COM SUCESSO!")
        print("="*70 + "\n")
        
    except Exception as e:
        print("\n" + "="*70)
        print("❌ ERRO NO TESTE")
        print("="*70)
        print(f"\n{str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)