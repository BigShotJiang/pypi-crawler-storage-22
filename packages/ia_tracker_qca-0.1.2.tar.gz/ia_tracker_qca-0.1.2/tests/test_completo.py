"""
Script de teste completo - testa ambos provedores.
"""

import os
import sys
from dotenv import load_dotenv

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from ia_cost_tracker import IATracker

load_dotenv()


def main():
    print("\n" + "="*70)
    print("TESTE COMPLETO - IA COST TRACKER")
    print("="*70)
    
    # Verificar configuração
    db_conn = os.getenv("DB_CONNECTION_STRING")
    maritaca_key = os.getenv("MARITACA_API_KEY")
    
    if not db_conn:
        print("\n❌ DB_CONNECTION_STRING não configurada no .env")
        sys.exit(1)
    
    print("\n✅ Configuração carregada:")
    print(f"   Database: {db_conn.split('@')[1] if '@' in db_conn else 'configurado'}")
    print(f"   Maritaca: {'✓' if maritaca_key else '✗'}")
    
    # Inicializar tracker
    tracker = IATracker(
        db_connection_string=db_conn,
        maritaca_api_key=maritaca_key if maritaca_key else None
    )
    
    print("\n" + "="*70)
    print("TESTANDO ANTHROPIC")
    print("="*70)
    
    # Listar modelos Anthropic
    modelos_anthropic = tracker.listar_modelos(provedor="anthropic")
    print(f"\n📦 {len(modelos_anthropic)} modelos Anthropic encontrados")
    
    if modelos_anthropic:
        # Testar registro
        print("\n💾 Testando registro de chamada Anthropic...")
        tracker.registrar_chamada(
            provedor="anthropic",
            modelo=modelos_anthropic[0].nome_modelo,
            tokens_input=100,
            tokens_output=50,
            aplicacao="test-completo",
            tag_funcionalidade="teste"
        )
        print("✅ Registro Anthropic OK")
    else:
        print("⚠️  Nenhum modelo Anthropic no banco")
    
    if maritaca_key:
        print("\n" + "="*70)
        print("TESTANDO MARITACA")
        print("="*70)
        
        # Sincronizar modelos
        print("\n📡 Sincronizando modelos Maritaca...")
        count = tracker.sincronizar_precos_maritaca()
        print(f"✅ {count} modelos sincronizados")
        
        # Listar modelos
        modelos_maritaca = tracker.listar_modelos(provedor="maritaca")
        
        if modelos_maritaca:
            # Testar registro
            print("\n💾 Testando registro de chamada Maritaca...")
            tracker.registrar_chamada(
                provedor="maritaca",
                modelo=modelos_maritaca[0].nome_modelo,
                tokens_input=150,
                tokens_output=75,
                aplicacao="test-completo",
                tag_funcionalidade="teste"
            )
            print("✅ Registro Maritaca OK")
    else:
        print("\n⚠️  Maritaca não configurada (sem API key)")
    
    # Estatísticas gerais
    print("\n" + "="*70)
    print("ESTATÍSTICAS GERAIS")
    print("="*70)
    
    stats = tracker.obter_estatisticas_aplicacao("test-completo")
    
    print(f"\n📊 Aplicação 'test-completo':")
    print(f"   Chamadas: {stats.get('total_chamadas', 0)}")
    print(f"   Tokens:   {stats.get('total_tokens', 0):,}")
    print(f"   Custo:    R$ {stats.get('custo_total', 0):.6f}")
    
    # Listar todos os modelos
    print("\n" + "="*70)
    print("TODOS OS MODELOS NO BANCO")
    print("="*70)
    
    todos_modelos = tracker.listar_modelos()
    
    por_provedor = {}
    for modelo in todos_modelos:
        if modelo.provedor not in por_provedor:
            por_provedor[modelo.provedor] = []
        por_provedor[modelo.provedor].append(modelo)
    
    for provedor, modelos in por_provedor.items():
        print(f"\n{provedor.upper()}: {len(modelos)} modelos")
        for m in modelos[:3]:  # Mostrar apenas 3 primeiros
            print(f"  • {m.nome_modelo}")
        if len(modelos) > 3:
            print(f"  ... e mais {len(modelos) - 3}")
    
    print("\n" + "="*70)
    print("✅ TESTE COMPLETO FINALIZADO!")
    print("="*70 + "\n")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\n❌ ERRO: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)