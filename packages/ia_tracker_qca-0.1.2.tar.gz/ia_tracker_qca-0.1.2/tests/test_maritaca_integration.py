"""
Teste de integração para Maritaca.
"""

import os
import sys
from dotenv import load_dotenv

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from ia_cost_tracker import IATracker

load_dotenv()


def test_sincronizar_modelos_maritaca():
    """Testa a sincronização de modelos da Maritaca."""
    print("\n" + "="*70)
    print("TESTE 1: Sincronizar Modelos da Maritaca")
    print("="*70)
    
    maritaca_key = os.getenv("MARITACA_API_KEY")
    
    if not maritaca_key:
        print("\n⚠️  MARITACA_API_KEY não encontrada no .env")
        print("Configure a chave para testar a sincronização.")
        return None
    
    tracker = IATracker(
        db_connection_string=os.getenv("DB_CONNECTION_STRING"),
        maritaca_api_key=maritaca_key
    )
    
    print("\n📡 Buscando modelos da API da Maritaca...")
    
    try:
        count = tracker.sincronizar_precos_maritaca()
        print(f"\n✅ {count} modelos sincronizados com sucesso!")
        
        # Listar modelos sincronizados
        modelos = tracker.listar_modelos(provedor="maritaca")
        
        print(f"\n📦 Modelos da Maritaca no banco:\n")
        for modelo in modelos:
            print(f"  • {modelo.nome_modelo}")
            print(f"    Input:  R$ {modelo.custo_input_por_1k:.6f} / 1k")
            print(f"    Output: R$ {modelo.custo_output_por_1k:.6f} / 1k")
            print()
        
        return tracker
        
    except Exception as e:
        print(f"\n❌ Erro ao sincronizar: {str(e)}")
        raise


def test_registrar_chamada_maritaca(tracker):
    """Testa o registro de uma chamada simulada à Maritaca."""
    print("\n" + "="*70)
    print("TESTE 2: Registrar Chamada Simulada à Maritaca")
    print("="*70)
    
    # Buscar um modelo disponível
    modelos = tracker.listar_modelos(provedor="maritaca")
    
    if not modelos:
        print("\n⚠️  Nenhum modelo da Maritaca encontrado!")
        print("Execute a sincronização primeiro.")
        return
    
    modelo_teste = modelos[0].nome_modelo
    tokens_input = 200
    tokens_output = 100
    
    print(f"\n📝 Registrando chamada simulada:")
    print(f"   Modelo: {modelo_teste}")
    print(f"   Tokens Input: {tokens_input}")
    print(f"   Tokens Output: {tokens_output}")
    
    try:
        id_uso = tracker.registrar_chamada(
            provedor="maritaca",
            modelo=modelo_teste,
            tokens_input=tokens_input,
            tokens_output=tokens_output,
            aplicacao="test-app-maritaca",
            tag_funcionalidade="teste-integracao",
            usuario="teste@exemplo.com",
            tempo_resposta_ms=2500
        )
        
        print(f"\n✅ Chamada registrada com sucesso!")
        print(f"   ID do registro: {id_uso}")
        
        # Buscar modelo para mostrar custo
        modelo_db = tracker.db.buscar_modelo("maritaca", modelo_teste)
        custo_input = (tokens_input / 1000) * modelo_db.custo_input_por_1k
        custo_output = (tokens_output / 1000) * modelo_db.custo_output_por_1k
        custo_total = custo_input + custo_output
        
        print(f"\n💰 Custos calculados:")
        print(f"   Input:  R$ {custo_input:.6f}")
        print(f"   Output: R$ {custo_output:.6f}")
        print(f"   Total:  R$ {custo_total:.6f}")
        
    except Exception as e:
        print(f"\n❌ Erro ao registrar: {str(e)}")
        raise


def test_estatisticas_maritaca(tracker):
    """Testa a consulta de estatísticas."""
    print("\n" + "="*70)
    print("TESTE 3: Consultar Estatísticas")
    print("="*70)
    
    stats = tracker.obter_estatisticas_aplicacao("test-app-maritaca")
    
    print(f"\n📊 Estatísticas da aplicação 'test-app-maritaca':\n")
    print(f"   Total de chamadas:     {stats.get('total_chamadas', 0)}")
    print(f"   Total de tokens:       {stats.get('total_tokens', 0):,}")
    print(f"   Custo total:           R$ {stats.get('custo_total', 0):.6f}")
    print(f"   Custo médio/chamada:   R$ {stats.get('custo_medio', 0):.6f}")
    print(f"   Tempo médio resposta:  {stats.get('tempo_medio_resposta_ms', 0):.0f} ms")


if __name__ == "__main__":
    print("\n" + "="*70)
    print("TESTES DE INTEGRAÇÃO - MARITACA")
    print("="*70)
    
    try:
        # Teste 1: Sincronizar modelos
        tracker = test_sincronizar_modelos_maritaca()
        
        if tracker is None:
            print("\n⚠️  Testes da Maritaca pulados (sem API key)")
            sys.exit(0)
        
        # Teste 2: Registrar chamada
        test_registrar_chamada_maritaca(tracker)
        
        # Teste 3: Estatísticas
        test_estatisticas_maritaca(tracker)
        
        print("\n" + "="*70)
        print("✅ TODOS OS TESTES PASSARAM!")
        print("="*70 + "\n")
        
    except Exception as e:
        print("\n" + "="*70)
        print("❌ ERRO NOS TESTES")
        print("="*70)
        print(f"\n{str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)