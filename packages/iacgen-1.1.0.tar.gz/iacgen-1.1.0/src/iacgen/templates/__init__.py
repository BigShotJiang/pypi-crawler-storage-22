"""
Jinja2 templates for Terraform module generation.
"""
