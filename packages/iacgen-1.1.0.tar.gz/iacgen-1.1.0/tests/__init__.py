"""
Test suite for iacgen package.
"""
