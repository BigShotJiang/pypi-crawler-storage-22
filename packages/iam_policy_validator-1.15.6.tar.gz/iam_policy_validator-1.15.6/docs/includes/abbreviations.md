_[IAM]: Identity and Access Management
_[ARN]: Amazon Resource Name
_[AWS]: Amazon Web Services
_[CLI]: Command Line Interface
_[SDK]: Software Development Kit
_[API]: Application Programming Interface
_[CI/CD]: Continuous Integration/Continuous Deployment
_[JSON]: JavaScript Object Notation
_[YAML]: YAML Ain't Markup Language
_[MFA]: Multi-Factor Authentication
_[STS]: Security Token Service
_[RCP]: Resource Control Policy
_[SCP]: Service Control Policy
_[OIDC]: OpenID Connect
_[SAML]: Security Assertion Markup Language
_[PR]: Pull Request \*[SHA]: Secure Hash Algorithm
