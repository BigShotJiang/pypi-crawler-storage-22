# ibkr-porez

Automated PPDG-3R tax reports for Interactive Brokers. It automatically pulls your data and generates a ready-to-upload XML file with all prices converted to RSD.


### Дополнительно

Чтобы увидеть все параметры, используйте:
```bash
ibkr-porez --help
```
