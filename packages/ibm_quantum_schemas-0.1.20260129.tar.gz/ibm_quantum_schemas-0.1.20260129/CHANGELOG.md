## [0.1.20260129](https://github.com/Qiskit/ibm-quantum-schemas/tree/0.1.20260129) - 2026-01-29

### Added

- `executor` model version `0.1`
- `noise-learner-v3` model version `0.1`
- `executor` model version `0.2_dev`
- `noise-learner-v3` model version `0.2_dev`
