# This code is a Qiskit project.
#
# (C) Copyright IBM 2025.
#
# This code is licensed under the Apache License, Version 2.0. You may
# obtain a copy of this license in the LICENSE.txt file in the root directory
# of this source tree or at http://www.apache.org/licenses/LICENSE-2.0.
#
# Any modifications or derivative works of this code must retain this
# copyright notice, and modified files need to carry a notice indicating
# that they have been altered from the originals.

"""PauliLindbladMapModel"""

from pydantic import BaseModel, Field
from qiskit.quantum_info import PauliLindbladMap


class PauliLindbladMapModel(BaseModel):
    """Encoding of a sparse Pauli Lindblad map."""

    sparse_terms: list[tuple[str, list[int], float]]
    """The Pauli Lindblad terms in the sparse form ``(pauli_string, qubit_idxs, rate)``."""

    num_qubits: int = Field(ge=0)
    """The total number of qubits the map applies to."""

    @classmethod
    def from_pauli_lindblad_map(
        cls, pauli_lindblad_map: PauliLindbladMap
    ) -> "PauliLindbladMapModel":
        """Encode a :class:`qiskit.quantum_info.PauliLindbladMap` into this model."""
        return cls(
            sparse_terms=pauli_lindblad_map.to_sparse_list(),
            num_qubits=pauli_lindblad_map.num_qubits,
        )

    def to_pauli_lindblad_map(self) -> PauliLindbladMap:
        """Decode this model into a :class:`qiskit.quantum_info.PauliLindbladMap`."""
        return PauliLindbladMap.from_sparse_list(self.sparse_terms, self.num_qubits)
