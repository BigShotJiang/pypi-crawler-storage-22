# coding: utf-8

# Copyright 2020, 2024 IBM All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import re
import base64
import logging
from typing import Union, List, Dict, Any, Optional
from io import BufferedReader, BytesIO

from ibm_watson_openscale.utils.sanitization_config import (
    SUSPICIOUS_PATTERNS,
    SANITIZATION_CONFIG
)

logger = logging.getLogger(__name__)


def load_patterns_from_file(file_path: str) -> List[str]:
    """
    Load suspicious patterns from a file.

    :param file_path: Path to the patterns file
    :return: List of patterns
    """
    try:
        with open(file_path, 'r') as f:
            patterns = [line.strip() for line in f if line.strip() and not line.startswith('#')]
        logger.info(f"Loaded {len(patterns)} patterns from {file_path}")
        return patterns
    except Exception as e:
        logger.error(f"Error loading patterns from {file_path}: {e}")
        raise


class InputSanitizer:
    """
    Sanitizes input data to prevent Cloudflare WAF triggers.
    
    Supports multiple input formats:
    - CSV data (BufferedReader)
    - List of dictionaries
    - List of PayloadRecord objects (as JSON)
    """
    
    def __init__(self, patterns: Optional[List[str]] = None, config: Optional[Dict] = None):
        """
        Initialize the sanitizer.
        
        :param patterns: List of regex patterns to sanitize (optional)
        :param config: Configuration dictionary (optional)
        """
        self.patterns = patterns or SUSPICIOUS_PATTERNS
        self.config = config or SANITIZATION_CONFIG
        self.enabled = self.config.get('enabled', True)
        self.case_sensitive = self.config.get('case_sensitive', False)
        self.log_sanitization = self.config.get('log_sanitization', True)
        
        # Compile regex patterns for efficiency
        flags = 0 if self.case_sensitive else re.IGNORECASE
        self.compiled_patterns = [
            re.compile(pattern, flags) for pattern in self.patterns
        ]
    
    def _contains_suspicious_pattern(self, text: str) -> bool:
        """
        Check if text contains any suspicious patterns.
        
        :param text: Text to check
        :return: True if suspicious pattern found
        """
        if not isinstance(text, str):
            return False
        
        for pattern in self.compiled_patterns:
            if pattern.search(text):
                if self.log_sanitization:
                    logger.info(f"Found pattern '{pattern.pattern}' in text")
                return True
        return False
    
    def _sanitize_string(self, value: str) -> str:
        """
        Sanitize a string value by escaping forward slashes.
        Replaces '/' with '\/' to avoid Cloudflare WAF triggers.
        
        :param value: String value to sanitize
        :return: Sanitized string with escaped forward slashes
        """
        if not isinstance(value, str) or not self._contains_suspicious_pattern(value):
            return value
        
        # Escape forward slashes to avoid pattern detection
        # /etc/passwd becomes \/etc\/passwd
        sanitized_value = value.replace('/', '\\/')
        
        if self.log_sanitization:
            logger.info(f"Sanitized: {value[:50]}... → {sanitized_value[:50]}...")
        
        return sanitized_value
    
    def _sanitize_value(self, value: Any) -> Any:
        """
        Sanitize a single value (handles different types).
        
        :param value: Value to sanitize
        :return: Sanitized value
        """
        if isinstance(value, str):
            return self._sanitize_string(value)
        elif isinstance(value, (list, tuple)):
            return [self._sanitize_value(item) for item in value]
        elif isinstance(value, dict):
            return {k: self._sanitize_value(v) for k, v in value.items()}
        else:
            return value
    
    def sanitize_dict(self, data: Dict) -> Dict:
        """
        Sanitize a dictionary.
        
        :param data: Dictionary to sanitize
        :return: Sanitized dictionary
        """
        if not self.enabled:
            return data
        
        return self._sanitize_value(data)
    
    def sanitize_list(self, data: List) -> List:
        """
        Sanitize a list of records.
        
        :param data: List to sanitize
        :return: Sanitized list
        """
        if not self.enabled:
            return data
        
        return [self._sanitize_value(item) for item in data]
    
    def sanitize_csv_stream(self, csv_stream: BufferedReader) -> Union[BufferedReader, BytesIO]:
        """
        Sanitize CSV data from a BufferedReader.
        
        :param csv_stream: BufferedReader containing CSV data
        :return: BufferedReader or BytesIO with sanitized CSV data
        """
        if not self.enabled:
            return csv_stream
        
        try:
            csv_content = csv_stream.read()
            csv_text = csv_content.decode('utf-8') if isinstance(csv_content, bytes) else csv_content
            
            # Quick check - if no patterns, return original
            if not self._contains_suspicious_pattern(csv_text):
                csv_stream.seek(0)
                return csv_stream
            
            # Sanitize lines containing patterns
            sanitized_lines = [
                self._sanitize_string(line) if self._contains_suspicious_pattern(line) else line
                for line in csv_text.split('\n')
            ]
            
            sanitized_content = '\n'.join(sanitized_lines)
            return BytesIO(sanitized_content.encode('utf-8'))
            
        except Exception as e:
            logger.error(f"Error sanitizing CSV stream: {e}")
            csv_stream.seek(0)
            return csv_stream
    
    def sanitize_records(self, records: Union[List[Dict], List]) -> Union[List[Dict], List]:
        """
        Sanitize a list of records (dictionaries or other objects).
        
        :param records: List of records to sanitize
        :return: Sanitized list of records
        """
        if not self.enabled:
            return records
        
        if self.log_sanitization:
            logger.info(f"Processing {len(records)} records")

        result = self.sanitize_list(records)

        if self.log_sanitization:
            logger.info(f"Completed {len(records)} records")

        return result


# Global sanitizer instance
_default_sanitizer = None


def get_sanitizer() -> InputSanitizer:
    """
    Get the default sanitizer instance (singleton pattern).
    
    :return: InputSanitizer instance
    """
    global _default_sanitizer
    if _default_sanitizer is None:
        _default_sanitizer = InputSanitizer()
    return _default_sanitizer