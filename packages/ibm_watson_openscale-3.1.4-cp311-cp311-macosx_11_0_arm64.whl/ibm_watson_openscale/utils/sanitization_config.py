# coding: utf-8

# Copyright 2020, 2024 IBM All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


# Patterns that trigger Cloudflare WAF rules
# These will be URL-encoded when found in input data
SUSPICIOUS_PATTERNS = [
    r'/etc/passwd',
    r'/etc/password',  # Added: variant of passwd
    r'/etc/shadow',
    r'/etc/hosts',
    r'\.\./.*',  # Path traversal patterns
    r'\.\.\\.*',  # Windows path traversal
]

# Sanitization configuration
SANITIZATION_CONFIG = {
    'enabled': False,  # Disabled by default - must be explicitly enabled
    'strategy': 'url_encode',  # Strategy: 'url_encode', 'base64', or 'replace'
    'case_sensitive': False,
    'log_sanitization': True,  # Log when sanitization occurs
}