"""Foundation models with vLLM bug fixes."""

from ibm_watsonx_ai_120b.foundation_models.model_inference import ModelInference

__all__ = ["ModelInference"]