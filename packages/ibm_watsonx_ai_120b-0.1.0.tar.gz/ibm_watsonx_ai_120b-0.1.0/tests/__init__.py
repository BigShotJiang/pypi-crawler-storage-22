"""Tests for ibm-watsonx-ai-120b."""
