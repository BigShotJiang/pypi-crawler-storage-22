#!/bin/python3
"""
@copyright: IBM
"""

from ibmvia_autoconf import configurator

configurator.configure()
