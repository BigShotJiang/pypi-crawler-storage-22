"""Library for parsing rfc5545 ics files."""
