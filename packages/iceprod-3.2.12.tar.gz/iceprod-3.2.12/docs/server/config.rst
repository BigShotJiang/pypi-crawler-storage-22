.. index:: config
.. _config:


Detailed Configuration
======================

.. automodule:: iceprod.server.config