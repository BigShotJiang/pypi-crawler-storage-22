REST API - Jobs
===============

.. automodule:: iceprod.rest.handlers.jobs
