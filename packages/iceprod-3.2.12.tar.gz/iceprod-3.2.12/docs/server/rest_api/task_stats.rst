REST API - Task Stats
=====================

.. automodule:: iceprod.rest.handlers.task_stats
