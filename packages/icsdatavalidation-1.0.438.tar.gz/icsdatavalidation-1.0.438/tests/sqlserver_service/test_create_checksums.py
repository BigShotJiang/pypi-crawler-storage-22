from unittest.mock import MagicMock, patch

import pytest

from icsDataValidation.core.database_objects import DatabaseObject, DatabaseObjectType
from icsDataValidation.services.database_services.sqlserver_service import SQLServerService


@pytest.fixture
def sqlserver_service():
    """Create a SQLServerService instance with mocked connection."""
    connection_params = {
        'Driver': 'ODBC Driver 18 for SQL Server',
        'Server': 'localhost',
        'Port': '1433',
        'Database': 'testdb',
        'User': 'sa',
        'Password': 'password',
        'Encrypt': True,
        'TrustServerCertificate': True
    }
    service = SQLServerService(connection_params=connection_params)
    service.sqlserver_connection = MagicMock()
    return service


@pytest.fixture
def mock_database_object():
    """Create a mock DatabaseObject."""
    return DatabaseObject(
        object_identifier="TestDB.dbo.TestTable",
        object_type=DatabaseObjectType.TABLE
    )


class TestCreateChecksumsParametrized:
    """Parametrized tests for SQLServerService.create_checksums."""

    @pytest.mark.parametrize(
        "column_intersections,where_clause,numeric_scale,execute_behavior," \
        "expected_columns,expected_errors,expect_retry,expected_execute_calls",
        [
            (  # success path
                ['amount', 'name'],
                'WHERE amount > 0',
                2,
                {
                    "return_value": [
                        [{'SUM_AMOUNT': 10, 'COUNTDISTINCT_NAME': 3}],
                        [{'COUNTNULLS_AMOUNT': 1, 'COUNTNULLS_NAME': 0}]
                    ]
                },
                {
                    'AMOUNT': ['SUM', 10, 1],
                    'NAME': ['COUNTDISTINCT', 3, 0]
                },
                [],
                False,
                1
            ),
            (  # arithmetic overflow triggers retry
                ['amount'],
                '',
                None,
                {
                    "side_effect": [
                        Exception('checksum_sql|||Arithmetic overflow error converting numeric to data type numeric'),
                        [[{'SUM_AMOUNT': 5}], [{'COUNTNULLS_AMOUNT': 0}]]
                    ]
                },
                {
                    'AMOUNT': ['SUM', 5, 0]
                },
                [],
                True,
                2
            ),
            (  # non-overflow error surfaces in TESTATM_ERRORS
                ['amount'],
                '',
                None,
                {
                    "side_effect": Exception('checksum_sql|||Some other error')
                },
                {},
                [['ERROR', 'checksum_sql', 'Some other error']],
                False,
                1
            ),
        ],
    )
    def test_create_checksums(
        self,
        sqlserver_service,
        mock_database_object,
        column_intersections,
        where_clause,
        numeric_scale,
        execute_behavior,
        expected_columns,
        expected_errors,
        expect_retry,
        expected_execute_calls
    ):
        """Test create_checksums behavior across success, retry, and error scenarios."""
        sqlserver_service.create_checksum_statement = MagicMock(return_value='checksum_retry_sql')

        with patch.object(sqlserver_service, '_get_checksum_statement', return_value='checksum_sql') as mock_checksum_stmt, \
             patch.object(sqlserver_service, '_get_countnulls_statement', return_value='countnulls_sql') as mock_countnulls_stmt, \
             patch.object(sqlserver_service, 'execute_queries') as mock_execute:

            if 'side_effect' in execute_behavior:
                mock_execute.side_effect = execute_behavior['side_effect']
            else:
                mock_execute.return_value = execute_behavior['return_value']

            result = sqlserver_service.create_checksums(
                object=mock_database_object,
                column_intersections=column_intersections,
                where_clause=where_clause,
                exclude_columns=[],
                numeric_scale=numeric_scale,
                enclose_column_by_double_quotes=False
            )

            mock_checksum_stmt.assert_called_once_with(
                object=mock_database_object,
                column_intersections=column_intersections,
                where_clause=where_clause,
                exclude_columns=[],
                numeric_scale=numeric_scale
            )
            mock_countnulls_stmt.assert_called_once_with(
                object=mock_database_object,
                column_intersections=column_intersections,
                where_clause=where_clause,
                exclude_columns=[]
            )
            assert mock_execute.call_count == expected_execute_calls

            if expect_retry:
                sqlserver_service.create_checksum_statement.assert_called_once()
                retry_kwargs = sqlserver_service.create_checksum_statement.call_args.kwargs
                assert retry_kwargs['bool_cast_before_sum'] is True
            else:
                sqlserver_service.create_checksum_statement.assert_not_called()

            for column, expected in expected_columns.items():
                assert result[column] == expected

            expected_keys = set(expected_columns.keys()) | {'TESTATM_ERRORS'}
            assert set(result.keys()) == expected_keys
            assert result['TESTATM_ERRORS'] == expected_errors
