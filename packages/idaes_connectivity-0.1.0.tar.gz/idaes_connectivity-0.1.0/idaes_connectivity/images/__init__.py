"""Image assets bundled with idaes_connectivity."""
