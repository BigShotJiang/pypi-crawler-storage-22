
# IDDB System v0.2.0 (Beta)

**Internal Discord Database System — The Enterprise Event Engine**

Stop paying for expensive logging tiers. IDDB turns your Discord channels into a high-performance, structured, and machine-readable database. Designed for massive bots, it handles rate limits, data integrity, and complex event tracking with ease.

**For full documentation and all features, view:** [IDDB GitHub Repository](https://github.com/Oria-Developer/IDDB-System-)

---

## Key Features

* **Fluent Coding Language**: Write logs like sentences.
* **Burst Protection**: Bundles multiple events into single messages to save API limits.
* **Digital Signatures**: Tamper-proof logs with SHA-256 verification.
* **Action Chains**: Link related events together to form a history.
* **Priority Queueing**: Ensure critical security alerts skip the line.

**For detailed usage examples and explanations, see the full documentation:** [IDDB GitHub Repository](https://github.com/Oria-Developer/IDDB-System-)

---

## How to Use the IDDB Language

### 1. Installation

```bash
pip install iddb-system
```

**Full setup instructions available here:** [IDDB GitHub Repository](https://github.com/Oria-Developer/IDDB-System-)

---

### 2. Initialization

```python
from iddb.core import IDDBClient, Actions

# Initialize with one or more channel IDs for sharding
iddb = IDDBClient(bot, channel_ids=[1465966978618495028])
await iddb.start()
```

**See the full documentation for advanced initialization options:** [IDDB GitHub Repository](https://github.com/Oria-Developer/IDDB-System-)

---

### 3. The "Fluent" Logging Syntax

Logging is now a sentence. Use `.from_context()` to let the bot automatically handle IDs.

```python
@bot.command()
async def ban(ctx, member: discord.Member, *, reason):
    await member.ban(reason=reason)
    
    # Simple, readable, professional logging:
    await iddb.entry() \
        .from_context(ctx) \
        .as_type(Actions.MODERATION) \
        .with_tags(["#ban", "#security"]) \
        .with_data({"target": member.id, "reason": reason}) \
        .high_priority() \
        .commit()
```

**See all logging methods and examples here:** [IDDB GitHub Repository](https://github.com/Oria-Developer/IDDB-System-)

---

### 4. Burst Protection

If your bot performs 100 actions in a second, IDDB will "bundle" them into groups (default 5) so you don't get rate-limited. This makes it safe for bots in 10,000+ servers.

**Full explanation of burst settings available here:** [IDDB GitHub Repository](https://github.com/Oria-Developer/IDDB-System-)

---

### 5. Action Chains (Relational Data)

Link a "Warn" to a "Kick" by using `.linked_to(parent_id)`. This allows you to trace the entire history of a user's behavior.

**For full relational examples, see the documentation:** [IDDB GitHub Repository](https://github.com/Oria-Developer/IDDB-System-)

---

## Operational Behavior

IDDB operates as a background worker. When you `.commit()`, the event is pushed to a PriorityQueue. A worker drains this queue, bundles the data, and signs it with a digital signature before persisting it to your Discord "Database" channel.

**Learn more about the internal workflow and advanced operations here:** [IDDB GitHub Repository](https://github.com/Oria-Developer/IDDB-System-)

---

**For full documentation, installation instructions, examples, and advanced features, view:** [IDDB GitHub Repository](https://github.com/Oria-Developer/IDDB-System-)
