import asyncio
import json
import logging
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional, Union

import discord
from discord.ext import commands

# New Imports from our sub-files
from .models import LogEntry
from .utils import generate_signature, verify_log_integrity

class Actions:
    MODERATION = "ACTION_MOD"
    SECURITY = "ACTION_SEC"
    ECONOMY = "ACTION_ECO"
    SYSTEM = "ACTION_SYS"
    DATABASE = "ACTION_DB"
    URGENT = "ACTION_URGENT"

class LogBuilder:
    def __init__(self, client: 'IDDBClient'):
        self.client = client
        self._guild_id = 0
        self._type = Actions.SYSTEM
        self._data = {}
        self._tags = []
        self._priority = False
        self._parent_id = None

    def from_context(self, ctx: Union[commands.Context, discord.Interaction]) -> 'LogBuilder':
        if isinstance(ctx, discord.Interaction):
            self._guild_id = ctx.guild_id or 0
            self._data["triggered_by"] = ctx.user.id
        else:
            self._guild_id = ctx.guild.id if ctx.guild else 0
            self._data["triggered_by"] = ctx.author.id
        return self

    def as_type(self, action_type: str) -> 'LogBuilder':
        self._type = action_type
        return self

    def with_data(self, data: Dict[str, Any]) -> 'LogBuilder':
        self._data.update(data)
        return self

    def with_tags(self, tags: List[str]) -> 'LogBuilder':
        self._tags.extend(tags)
        return self

    def high_priority(self) -> 'LogBuilder':
        self._priority = True
        return self

    async def commit(self) -> str:
        action_id = self.client._generate_id()
        timestamp = datetime.utcnow().isoformat()
        
        # Using Utility function
        sig = generate_signature(action_id, self._guild_id, timestamp, self._data)

        # Using Model
        entry = LogEntry(
            id=action_id,
            sig=sig,
            guild=self._guild_id,
            type=self._type,
            time=timestamp,
            tags=self._tags,
            parent=self._parent_id,
            data=self._data
        )

        await self.client._enqueue(entry.to_dict(), self._priority)
        return action_id

class IDDBClient:
    def __init__(self, bot: discord.Client, channel_ids: List[int], buffer_size: int = 5):
        self.bot = bot
        self.channels = channel_ids
        self.buffer_size = buffer_size
        self.queue = asyncio.PriorityQueue()
        self._worker_task = None
        self.logger = logging.getLogger("IDDB_v0.2.0")

    def entry(self) -> LogBuilder:
        return LogBuilder(self)

    async def start(self):
        if not self._worker_task:
            self._worker_task = asyncio.create_task(self._process_queue())
            self.logger.info("IDDB v0.2.0 Engine Online with Utils/Models.")

    def _generate_id(self) -> str:
        unique_part = f"{uuid.uuid4()}-{uuid.uuid1()}"
        return (unique_part + ("0" * (240 - len(unique_part))))[:240]

    async def _enqueue(self, entry: Dict, priority: bool):
        p_val = 0 if priority else 1
        await self.queue.put((p_val, datetime.utcnow(), entry))

    async def _process_queue(self):
        await self.bot.wait_until_ready()
        buffer = []
        while True:
            try:
                while len(buffer) < self.buffer_size:
                    p_val, ts, entry = await asyncio.wait_for(self.queue.get(), timeout=1.0)
                    buffer.append(entry)
            except asyncio.TimeoutError:
                pass

            if buffer:
                await self._send_bundle(buffer)
                buffer = []
                await asyncio.sleep(3.0)

    async def _send_bundle(self, logs: List[Dict]):
        channel = self.bot.get_channel(self.channels[0])
        if channel:
            payload = json.dumps(logs, indent=2)
            await channel.send(f"