from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

@dataclass
class LogEntry:
    """The formal structure of an IDDB Log."""
    id: str
    sig: str
    guild: int
    type: str
    time: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    tags: List[str] = field(default_factory=list)
    parent: Optional[str] = None
    data: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Converts the model to a dictionary for JSON storage."""
        return {
            "id": self.id,
            "sig": self.sig,
            "guild": self.guild,
            "type": self.type,
            "time": self.time,
            "tags": self.tags,
            "parent": self.parent,
            "data": self.data
        }