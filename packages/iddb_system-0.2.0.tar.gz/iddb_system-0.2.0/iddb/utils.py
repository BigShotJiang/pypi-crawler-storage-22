import hashlib
import json
from typing import Dict, Any

def generate_signature(action_id: str, guild_id: int, timestamp: str, data: Dict[str, Any]) -> str:
    """Generates a tamper-proof SHA-256 signature."""
    raw_payload = f"{action_id}{guild_id}{timestamp}{json.dumps(data)}"
    return hashlib.sha256(raw_payload.encode()).hexdigest()[:16]

def verify_log_integrity(entry_dict: Dict[str, Any]) -> bool:
    """Verifies if a log entry has been tampered with."""
    try:
        expected = generate_signature(
            entry_dict["id"], 
            entry_dict["guild"], 
            entry_dict["time"], 
            entry_dict["data"]
        )
        return entry_dict["sig"] == expected
    except KeyError:
        return False

def format_id_display(action_id: str) -> str:
    """Shortens the massive 240-char ID for UI display."""
    return f"{action_id[:8]}...{action_id[-8:]}"