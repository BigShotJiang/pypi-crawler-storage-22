.. _usinas_hidreletricas:

=======================================================
Dados das Usinas Hidrelétricas
=======================================================

.. currentmodule:: idecomp.libs.usinas_hidreletricas

As informações de usinas hidrelétricas no DECOMP,
localizadas no arquivos das LIBS que são indicados
no indices.csv com as respectivas funcionalidades,
são armazenados na classe:

.. autoclass:: UsinasHidreletricas
   :members:
