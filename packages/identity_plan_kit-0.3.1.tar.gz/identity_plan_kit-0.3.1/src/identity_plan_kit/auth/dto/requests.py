"""Auth request DTOs."""

from pydantic import Field

from identity_plan_kit.shared.schemas import BaseRequest


class OAuthCallbackRequest(BaseRequest):
    """OAuth callback request data."""

    code: str = Field(
        ...,
        description="Authorization code from OAuth provider",
    )
    state: str | None = Field(
        default=None,
        description="State parameter for CSRF protection",
    )
    error: str | None = Field(
        default=None,
        description="Error code if authentication failed",
    )
    error_description: str | None = Field(
        default=None,
        description="Human-readable error description",
    )


class RefreshTokenRequest(BaseRequest):
    """Refresh token request."""

    refresh_token: str | None = Field(
        default=None,
        description="Refresh token (if not in cookie)",
    )


class LogoutRequest(BaseRequest):
    """Logout request."""

    everywhere: bool = Field(
        default=False,
        description="Revoke all sessions (logout everywhere)",
    )
