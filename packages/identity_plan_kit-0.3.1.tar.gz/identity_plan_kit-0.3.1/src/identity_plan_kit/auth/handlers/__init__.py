"""Auth HTTP handlers."""

from identity_plan_kit.auth.handlers.oauth_routes import create_auth_router

__all__ = ["create_auth_router"]
