"""Plan cache for fast plan lookups."""

import asyncio
import time
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta

from identity_plan_kit.plans.domain.entities import Plan
from identity_plan_kit.shared.logging import get_logger

logger = get_logger(__name__)


@dataclass
class PlanCacheEntry:
    """Cache entry with expiration and fetch timestamp for race condition prevention."""

    plan: Plan
    expires_at: datetime
    # Monotonic timestamp when this entry was fetched from DB
    # Used to detect stale writes after invalidation
    fetched_at: float = field(default_factory=time.monotonic)

    @property
    def is_expired(self) -> bool:
        """Check if entry has expired."""
        return datetime.now(UTC) > self.expires_at


class PlanCache:
    """
    In-memory plan cache.

    Caches plan data (by code) to reduce database queries.
    Plans are static reference data that rarely change, so a simple
    in-memory cache with TTL is sufficient.

    For cache invalidation on plan updates, call invalidate() or invalidate_all().

    **Race Condition Prevention:**

    This cache prevents stale writes after invalidation using a timestamp-based
    approach. When invalidate() is called, it records the invalidation time.
    Subsequent set() calls only succeed if their fetch timestamp is newer than
    the last invalidation. This prevents the following race:

    1. Request A: get() cache miss, starts DB fetch at T=100
    2. Admin: update_plan() called, invalidate() called at T=101
    3. Request A: set() called with plan fetched at T=100 - REJECTED (T=100 < T=101)

    Note: Uses fine-grained locking to minimize contention. Read operations
    (get) are lock-free since dict operations are atomic in Python. Write
    operations (set, invalidate) use a lock only for cache-wide operations.
    """

    def __init__(self, ttl_seconds: int = 300) -> None:
        """
        Initialize plan cache.

        Args:
            ttl_seconds: Cache TTL in seconds (default: 5 minutes, 0 to disable)
        """
        self._ttl = timedelta(seconds=ttl_seconds)
        self._cache: dict[str, PlanCacheEntry] = {}
        self._write_lock = asyncio.Lock()
        self._enabled = ttl_seconds > 0
        # Track when each key was last invalidated (monotonic time)
        # Used to reject stale writes that started before invalidation
        self._invalidated_at: dict[str, float] = {}
        # Global invalidation timestamp for invalidate_all()
        self._global_invalidated_at: float = 0.0

    async def get(self, plan_code: str) -> Plan | None:
        """
        Get cached plan by code.

        This operation is lock-free for better performance under high concurrency.
        Expired entries are lazily cleaned up on next write operation.

        Args:
            plan_code: Plan code (e.g., "free", "pro")

        Returns:
            Plan entity or None if not cached/expired
        """
        if not self._enabled:
            return None

        # Lock-free read - dict.get() is atomic in Python
        entry = self._cache.get(plan_code)

        if entry is None:
            return None

        if entry.is_expired:
            # Don't delete here to avoid race conditions
            # Expired entries will be cleaned up on next write
            return None

        return entry.plan

    def get_fetch_timestamp(self) -> float:
        """
        Get a monotonic timestamp to associate with a DB fetch.

        Call this BEFORE fetching from the database, then pass the timestamp
        to set() to enable stale write prevention.

        Example::

            fetch_ts = cache.get_fetch_timestamp()
            plan = await db.get_plan(plan_code)  # Slow DB query
            await cache.set(plan_code, plan, fetched_at=fetch_ts)

        Returns:
            Monotonic timestamp
        """
        return time.monotonic()

    async def set(
        self,
        plan_code: str,
        plan: Plan,
        fetched_at: float | None = None,
    ) -> bool:
        """
        Cache plan by code.

        Args:
            plan_code: Plan code
            plan: Plan entity to cache
            fetched_at: Monotonic timestamp when the plan was fetched from DB.
                If provided, the cache will reject stale writes that occurred
                before the last invalidation. If not provided, the write is
                always accepted (for backwards compatibility).

        Returns:
            True if the entry was cached, False if rejected as stale
        """
        if not self._enabled:
            return False

        # Check for stale write if fetched_at is provided
        if fetched_at is not None:
            # Check global invalidation
            if fetched_at < self._global_invalidated_at:
                logger.debug(
                    "plan_cache_stale_write_rejected",
                    plan_code=plan_code,
                    reason="global_invalidation",
                    fetched_at=fetched_at,
                    invalidated_at=self._global_invalidated_at,
                )
                return False

            # Check key-specific invalidation
            key_invalidated_at = self._invalidated_at.get(plan_code, 0.0)
            if fetched_at < key_invalidated_at:
                logger.debug(
                    "plan_cache_stale_write_rejected",
                    plan_code=plan_code,
                    reason="key_invalidation",
                    fetched_at=fetched_at,
                    invalidated_at=key_invalidated_at,
                )
                return False

        entry = PlanCacheEntry(
            plan=plan,
            expires_at=datetime.now(UTC) + self._ttl,
            fetched_at=fetched_at or time.monotonic(),
        )
        # dict assignment is atomic in Python, no lock needed for single key
        self._cache[plan_code] = entry
        return True

    async def invalidate(self, plan_code: str) -> None:
        """
        Invalidate cached plan by code.

        Records the invalidation timestamp to prevent stale writes from
        concurrent requests that fetched data before invalidation.

        Args:
            plan_code: Plan code to invalidate
        """
        # Record invalidation timestamp BEFORE removing entry
        # This ensures any concurrent set() with older fetch_ts will be rejected
        self._invalidated_at[plan_code] = time.monotonic()
        # dict.pop() is atomic in Python
        self._cache.pop(plan_code, None)
        logger.debug("plan_cache_invalidated", plan_code=plan_code)

    async def invalidate_all(self) -> None:
        """
        Invalidate all cached plans.

        Records a global invalidation timestamp to prevent any stale writes
        from concurrent requests that fetched data before invalidation.
        """
        async with self._write_lock:
            # Record global invalidation timestamp BEFORE clearing
            self._global_invalidated_at = time.monotonic()
            self._cache.clear()
            # Also clear key-specific invalidation timestamps to prevent memory growth
            self._invalidated_at.clear()
            logger.info("plan_cache_cleared")

    async def cleanup_expired(self) -> int:
        """
        Remove expired entries from cache.

        Call this periodically to prevent memory growth from expired entries.

        Returns:
            Number of entries removed
        """
        async with self._write_lock:
            expired_keys = [
                key for key, entry in self._cache.items() if entry.is_expired
            ]
            for key in expired_keys:
                del self._cache[key]

            if expired_keys:
                logger.debug(
                    "plan_cache_cleanup",
                    removed_count=len(expired_keys),
                )

            return len(expired_keys)

    @property
    def size(self) -> int:
        """Get current cache size."""
        return len(self._cache)
