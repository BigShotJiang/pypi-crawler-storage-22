"""User plan cache for fast user plan lookups."""

import asyncio
import time
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from uuid import UUID

from identity_plan_kit.plans.domain.entities import Plan, UserPlan
from identity_plan_kit.shared.logging import get_logger

logger = get_logger(__name__)


@dataclass
class UserPlanCacheEntry:
    """Cache entry for user plan with expiration."""

    user_plan: UserPlan
    plan: Plan
    expires_at: datetime
    fetched_at: float = field(default_factory=time.monotonic)

    @property
    def is_expired(self) -> bool:
        """Check if entry has expired."""
        return datetime.now(UTC) > self.expires_at


class UserPlanCache:
    """
    In-memory user plan cache.

    Caches user plan assignments (by user_id) to reduce database queries.
    User plans change less frequently than usage, so caching provides
    significant benefit for quota check operations.

    Cache key: user_id (UUID)
    Cache value: (UserPlan, Plan) tuple with full plan details

    **Invalidation:**

    Call invalidate() when:
    - User's plan is assigned/changed
    - User's plan is cancelled
    - User's plan is extended
    - User's custom limits are updated

    **TTL:**

    Default TTL is 5 minutes. This balances:
    - Reducing database load (cache hits avoid 2-4 queries)
    - Ensuring plan changes propagate within reasonable time
    - Memory usage (entries expire and get cleaned up)
    """

    def __init__(self, ttl_seconds: int = 300) -> None:
        """
        Initialize user plan cache.

        Args:
            ttl_seconds: Cache TTL in seconds (default: 5 minutes, 0 to disable)
        """
        self._ttl = timedelta(seconds=ttl_seconds)
        self._cache: dict[UUID, UserPlanCacheEntry] = {}
        self._write_lock = asyncio.Lock()
        self._enabled = ttl_seconds > 0
        self._invalidated_at: dict[UUID, float] = {}
        self._global_invalidated_at: float = 0.0

    async def get(self, user_id: UUID) -> tuple[UserPlan, Plan] | None:
        """
        Get cached user plan by user ID.

        Args:
            user_id: User UUID

        Returns:
            Tuple of (UserPlan, Plan) or None if not cached/expired
        """
        if not self._enabled:
            return None

        entry = self._cache.get(user_id)

        if entry is None:
            return None

        if entry.is_expired:
            return None

        return entry.user_plan, entry.plan

    def get_fetch_timestamp(self) -> float:
        """
        Get a monotonic timestamp to associate with a DB fetch.

        Call this BEFORE fetching from the database, then pass the timestamp
        to set() to enable stale write prevention.

        Returns:
            Monotonic timestamp
        """
        return time.monotonic()

    async def set(
        self,
        user_id: UUID,
        user_plan: UserPlan,
        plan: Plan,
        fetched_at: float | None = None,
    ) -> bool:
        """
        Cache user plan by user ID.

        Args:
            user_id: User UUID
            user_plan: UserPlan entity to cache
            plan: Plan entity with full details (permissions, limits)
            fetched_at: Monotonic timestamp when data was fetched from DB

        Returns:
            True if the entry was cached, False if rejected as stale
        """
        if not self._enabled:
            return False

        if fetched_at is not None:
            if fetched_at < self._global_invalidated_at:
                logger.debug(
                    "user_plan_cache_stale_write_rejected",
                    user_id=str(user_id),
                    reason="global_invalidation",
                )
                return False

            key_invalidated_at = self._invalidated_at.get(user_id, 0.0)
            if fetched_at < key_invalidated_at:
                logger.debug(
                    "user_plan_cache_stale_write_rejected",
                    user_id=str(user_id),
                    reason="key_invalidation",
                )
                return False

        entry = UserPlanCacheEntry(
            user_plan=user_plan,
            plan=plan,
            expires_at=datetime.now(UTC) + self._ttl,
            fetched_at=fetched_at or time.monotonic(),
        )
        self._cache[user_id] = entry
        return True

    async def invalidate(self, user_id: UUID) -> None:
        """
        Invalidate cached user plan by user ID.

        Call this when a user's plan changes (assigned, cancelled, extended, etc.).

        Args:
            user_id: User UUID to invalidate
        """
        self._invalidated_at[user_id] = time.monotonic()
        self._cache.pop(user_id, None)
        logger.debug("user_plan_cache_invalidated", user_id=str(user_id))

    async def invalidate_all(self) -> None:
        """
        Invalidate all cached user plans.

        Call this when plans are modified globally.
        """
        async with self._write_lock:
            self._global_invalidated_at = time.monotonic()
            self._cache.clear()
            self._invalidated_at.clear()
            logger.info("user_plan_cache_cleared")

    async def cleanup_expired(self) -> int:
        """
        Remove expired entries from cache.

        Returns:
            Number of entries removed
        """
        async with self._write_lock:
            expired_keys = [
                key for key, entry in self._cache.items() if entry.is_expired
            ]
            for key in expired_keys:
                del self._cache[key]

            if expired_keys:
                logger.debug(
                    "user_plan_cache_cleanup",
                    removed_count=len(expired_keys),
                )

            return len(expired_keys)

    @property
    def size(self) -> int:
        """Get current cache size."""
        return len(self._cache)
