"""Plans handlers module."""

from identity_plan_kit.plans.handlers.plan_routes import create_plans_router

__all__ = ["create_plans_router"]
