"""RBAC repositories."""

from identity_plan_kit.rbac.repositories.rbac_repo import RBACRepository

__all__ = ["RBACRepository"]
