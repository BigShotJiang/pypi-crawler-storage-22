"""RBAC services."""

from identity_plan_kit.rbac.services.rbac_service import RBACService

__all__ = ["RBACService"]
