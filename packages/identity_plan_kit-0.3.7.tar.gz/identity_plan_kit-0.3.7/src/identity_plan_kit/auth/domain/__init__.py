"""Auth domain - entities and exceptions."""
