"""Extension tests for model/entity customization."""
