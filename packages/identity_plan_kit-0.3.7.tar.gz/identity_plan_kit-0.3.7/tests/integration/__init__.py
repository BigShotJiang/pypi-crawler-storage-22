"""Integration tests using real database (testcontainers)."""
