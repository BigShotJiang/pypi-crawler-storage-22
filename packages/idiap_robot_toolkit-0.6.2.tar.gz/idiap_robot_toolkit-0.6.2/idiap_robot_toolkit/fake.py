# coding=utf-8

# SPDX-FileCopyrightText: 2024-2026 Idiap Research Institute <contact@idiap.ch>
# SPDX-FileContributor: Olivier Canévet <olivier.canevet@idiap.ch>
# SPDX-License-Identifier: MIT

import cv2

from loguru import logger

from .robot import factory
from .robot import Robot

DEFAULT_CAMERA = 0


class FakeRobot(Robot):
    """A class to emulate a Robot with a webcam"""

    def __init__(self, name="Fake", camera_index=DEFAULT_CAMERA):
        super().__init__(name)

        self.camera = cv2.VideoCapture(camera_index)

    def __repr__(self):
        s = f"Fake robot '{self.name}'"
        return s

    def say(self, text):
        logger.info(text)

    def look_at(self, coordinates):
        """Move the camera/arm/head towards the coordinates"""
        logger.info(f"Looking at {coordinates}")

    def get_frame(self, camera=DEFAULT_CAMERA):
        """Parameter `camera` is not used"""
        success, frame = self.camera.read()
        return success, frame


def fake_robot_builder(name="Fake", camera_index=DEFAULT_CAMERA, **_ignored):
    return FakeRobot(name=name, camera_index=camera_index)


factory.register("fake", fake_robot_builder)
