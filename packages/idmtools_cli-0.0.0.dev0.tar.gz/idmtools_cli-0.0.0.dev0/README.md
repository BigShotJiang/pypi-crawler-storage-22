# idmtools-cli

**PLACEHOLDER PACKAGE - NOT FOR USE**

This package is a placeholder to reserve the name `idmtools-cli` on PyPI.

The actual package implementation will be released in the future.

## Purpose

This placeholder ensures the package name is reserved and prevents name squatting.

## Status

This is version 0.0.0.dev0 - a minimal placeholder release.

## Future Release

The full implementation of idmtools-cli will be published when ready.

For more information, visit: https://github.com/InstituteforDiseaseModeling/idmtools
