"""
idmtools-platform-container - Placeholder Package

This is a placeholder package to reserve the name on PyPI.
The actual package will be published later.
"""

__version__ = "0.0.0.dev0"
