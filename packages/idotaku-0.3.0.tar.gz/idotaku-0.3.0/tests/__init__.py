"""Tests for idotaku."""
