"""Agent templates package."""
