
import base64
import time
from io import BytesIO
import cv2

from openai import OpenAI
from pydantic import BaseModel, Field
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
    force=True
)

PROMPT_FRONT = """
Extract ALL fields from this Palestine Passport **front side** image with high accuracy.

Return a JSON object with the following fields (use the exact field names):

    - dob: Date of birth exactly as shown on the card, strictly convert to accurate DD/MM/YYYY format
    - expiry_date: Date of expiry exactly as shown on the card, strictly convert to accurate DD/MM/YYYY format
    - mrz1: First line of the MRZ, 
    - mrz2: Second line of the MRZ, 
    - full_name: Full name as printed on the card (extract exactly as written)
    - gender: Gender as either MALE or FEMALE (extract exactly as printed)
    - mother_name: Mother's Name (extract exactly as printed)
    - place_of_birth: Place of birth in English (extract exactly as printed)
    - issuing_date: Date of issue exactly as shown on the card, strictly convert to accurate DD/MM/YYYY format
    - place_of_issue: Place of issue as printed on the card
    - id_number: ID number as printed on the card (exactly 9 characters)
    - passport_number: Passport number as printed beside N° or No (exactly 7 characters)
    - header_verified: Return True if any of these texts are present in the image: P<PSE, PSE, PALESTINIAN AUTHORITY, or PALESTINE; otherwise False.
    - first_name: First name extracted from full_name (if full_name contains multiple words, use the first word)
    - last_name: Last name extracted from full_name (if full_name contains multiple words, use the last word)
    - gender_mrz: Gender extracted from MRZ line 2: 'M' for Male, 'F' for Female.
    - expiry_date_mrz: Expiry date extracted from MRZ line 2 in DD/MM/YYYY format.
    - dob_mrz: Date of birth extracted from MRZ line 2 in DD/MM/YYYY format.
    - id_number_mrz: ID number extracted from MRZ line 2.
    - passport_number_mrz: Passport number extracted from MRZ line 2 which has only digits.


Instructions:
    - Do NOT guess or hallucinate any values. If unclear, return empty string.
    - Only use information

"""
class PalestinePassportFront(BaseModel):
   

    dob: str = Field(...,
        description = "The date of birth exactly as shown on the card,convert to accurate DD/MM/YYYY format",
    )
    expiry_date: str = Field(...,
        description = "The date of expiry exactly as shown on the card ,convert to accurate DD/MM/YYYY format",
    )

    mrz1: str = Field(..., 
        description="First line of the MRZ"
    )

    mrz2: str = Field(...,
        description="Second line of the MRZ"
    )

    full_name: str = Field(...,
                      description="Full name as printed on the card (extract exactly as written on the card)"
                      )

    gender: str = Field(...,
        description="Gender as either MALE or FEMALE , (printed as Sex, extract exactly as written on the card)"
    )

    mother_name: str = Field(
        ...,
        description="Mother's Name of the person (printed as Mother Name, extract exactly as written on the card)"
    )

    place_of_birth: str = Field(...,
        description = "The place of birth in english(printed as Birth Place, extract exactly as written on the card)",
    )

   
   
    issuing_date: str = Field(...,
        description = "The date of issue exactly as shown on the card,convert to accurate DD/MM/YYYY format" ,
    )

    place_of_issue: str = Field(...,
        description = "Place of issue as printed on the card.",
    )

    id_number: str = Field(..., min_length=9, max_length=9,
        description = "ID number as printed on the card, extract exactly as written on the card "
    )

    passport_number: str = Field(..., min_length=7, max_length=7,
        description = "Passport number as printed on the left side of passport beside i.e N° or No, extract exactly as written on the card"
    )

    header_verified: bool = Field(
        ...,
        description=" Return True if one of the texts present in the image P<PSE OR PSE OR PALESTINIAN AUTHORITY OR PALESTINE ",
    )

    first_name:  str = Field(
        ...,
        description="First name extracted from full_name",
    )
    last_name: str = Field(
        ...,
        description="Last name extracted from full_name",
    )
    
    gender_mrz: str = Field(...,description="Gender extracted from MRZ line 2:Return 'M' for Male, 'F' for female.")  
    expiry_date_mrz: str = Field(...,description="Expiry date extracted from MRZ line 2 in DD/MM/YYYY format.")
    dob_mrz: str = Field(...,description="Date of birth extracted from MRZ line 2 in DD/MM/YYYY format.")  
    passport_number_mrz: str = Field(..., min_length = 7, max_length= 7,description="Passport number extracted from MRZ line 2 which has only digits.")
    id_number_mrz: str = Field(...,min_length= 9, max_length =9, description="ID number extracted from MRZ line 2.")
    
def process_image(side):

    if side == "first" or side=='page1':
        prompt = PROMPT_FRONT
        model = PalestinePassportFront

    else:
        raise ValueError("Invalid document side specified. please upload front side of passport'.")

    return model, prompt



def get_openai_response(prompt: str, model_type, image: BytesIO, genai_key):
    b64_image = base64.b64encode(image.getvalue()).decode("utf-8")
    for attempt in range(3):
        try:
            client = OpenAI(api_key=genai_key)
            response = client.responses.parse(
                model="gpt-4.1-mini",
                input=[
                    {
                        "role": "system",
                        "content": "You are an expert at extracting information from identity documents.",
                    },
                    {
                        "role": "user",
                        "content": [
                            {"type": "input_text", "text": prompt},
                            {
                                "type": "input_image",
                                "image_url": f"data:image/jpeg;base64,{b64_image}",
                                "detail": "low",
                            },
                        ],
                    },
                ],
                text_format=model_type,
            )
            return response.output_parsed
        except Exception as e:
            logging.info(f"[ERROR] Attempt {attempt + 1} failed: {str(e)}")
            time.sleep(2)
    return None


def _image_to_jpeg_bytesio(image) -> BytesIO:
    """
    Accepts: numpy.ndarray (OpenCV BGR), PIL.Image.Image, bytes/bytearray, or io.BytesIO
    Returns: io.BytesIO containing JPEG bytes (ready for get_openai_response)
    """
    import numpy as np

    if isinstance(image, BytesIO):
        image.seek(0)
        return image

    if isinstance(image, (bytes, bytearray)):
        return BytesIO(image)

    try:
        from PIL.Image import Image as _PILImage

        if isinstance(image, _PILImage):
            buf = BytesIO()
            image.convert("RGB").save(buf, format="JPEG", quality=95)
            buf.seek(0)
            return buf
    except Exception:
        pass

    if isinstance(image, np.ndarray):
        success, enc = cv2.imencode(".jpg", image)
        if not success:
            raise ValueError("cv2.imencode failed")
        return BytesIO(enc.tobytes())

    raise TypeError(
        "Unsupported image type. Provide numpy.ndarray, PIL.Image.Image, bytes, or io.BytesIO."
    )


def get_response_from_openai_pse(image, side, country, openai_key):
    logging.info("Processing image for Palestinian passport extraction OPENAI......")
    logging.info(f" and type: {type(image)}")
    try:
        image = _image_to_jpeg_bytesio(image)
    except Exception as e:
        logging.error(f"Error encoding image: {e}")
        return {"error": "Image encoding failed"}
    try:
        model, prompt = process_image(side)
        logging.info(f"Using model: {model.__name__} and prompt {prompt[:100]}")
    except ValueError as ve:
        logging.error(f"Error: {ve}")
        return {"error": str(ve)}

    try:
        response = get_openai_response(prompt, model, image, openai_key)
    except Exception as e:
        logging.error(f"Error during OpenAI request: {e}")
        return {"error": "OpenAI request failed"}

    response_data = vars(response)
    logging.info(f"Openai response: {response}")
    return response_data
