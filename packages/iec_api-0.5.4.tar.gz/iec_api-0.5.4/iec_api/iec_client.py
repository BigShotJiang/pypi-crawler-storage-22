import asyncio
import atexit
import logging
from datetime import datetime
from typing import List, Optional

import aiofiles
import aiohttp
import jwt
from aiohttp import ClientSession

from iec_api import commons, data, fault_portal_data, login, masa_data, static_data
from iec_api.fault_portal_models.accounts_transactions import AccountsTransactionsResponse
from iec_api.fault_portal_models.outages import FaultPortalOutage
from iec_api.fault_portal_models.user_profile import UserProfile
from iec_api.masa_api_models.cities import City
from iec_api.masa_api_models.contact_account_user_profile import MasaMainPortalContactAccountUserProfile
from iec_api.masa_api_models.equipment import GetEquipmentResponse
from iec_api.masa_api_models.lookup import GetLookupResponse
from iec_api.masa_api_models.order_lookup import OrderCategory
from iec_api.masa_api_models.titles import GetTitleResponse
from iec_api.masa_api_models.user_profile import MasaUserProfile
from iec_api.masa_api_models.volt_levels import VoltLevel
from iec_api.models.account import Account
from iec_api.models.contract import Contract
from iec_api.models.contract_check import ContractCheck
from iec_api.models.customer import Customer
from iec_api.models.customer_mobile import CustomerMobileResponse
from iec_api.models.device import Device, Devices
from iec_api.models.device_identity import DeviceDetails
from iec_api.models.device_in import DeviceInResponse
from iec_api.models.device_type import DeviceType
from iec_api.models.efs import EfsMessage
from iec_api.models.electric_bill import ElectricBill
from iec_api.models.exceptions import IECLoginError
from iec_api.models.invoice import GetInvoicesBody
from iec_api.models.jwt import JWT
from iec_api.models.meter_reading import MeterReadings
from iec_api.models.outages import Outage
from iec_api.models.remote_reading import ReadingResolution, RemoteReadingResponse
from iec_api.models.social_discount import SocialDiscount
from iec_api.models.touz_compatibility import TouzCompatibility
from iec_api.usage_calculator.calculator import UsageCalculator

logger = logging.getLogger(__name__)


class IecClient:
    """IEC API Client."""

    def __init__(self, user_id: str | int, session: Optional[ClientSession] = None):
        """
        Initializes the class with the provided user ID and optionally logs in automatically.

        Args:
        session (ClientSession): The aiohttp ClientSession object.
        user_id (str): The user ID (SSN) to be associated with the instance.
        automatically_login (bool): Whether to automatically log in the user. Default is False.
        """

        if not commons.is_valid_israeli_id(user_id):
            raise ValueError("User ID must be a valid Israeli ID.")

        # Custom Logger to the session
        trace_config = aiohttp.TraceConfig()
        trace_config.on_request_start.append(commons.on_request_start_debug)
        trace_config.on_request_chunk_sent.append(commons.on_request_chunk_sent_debug)
        trace_config.on_request_end.append(commons.on_request_end_debug)
        trace_config.freeze()

        if not session:
            session = aiohttp.ClientSession(trace_configs=[trace_config])
            atexit.register(self._shutdown)
        else:
            session.trace_configs.append(trace_config)

        self._session = session

        self._state_token: Optional[str] = None  # Token for maintaining the state of the user's session
        self._factor_id: Optional[str] = None  # Factor ID for multifactor authentication
        self._session_token: Optional[str] = None  # Token for maintaining the user's session
        self._otp_factor_type: Optional[str] = None  # OTP Factor Type (email, sms) of the otp
        self.logged_in: bool = False  # Flag to indicate if the user is logged in
        self._token: JWT = JWT(
            access_token="", refresh_token="", token_type="", expires_in=0, scope="", id_token=""
        )  # Token for authentication
        self._user_id: str = str(user_id)  # User ID associated with the instance
        self._bp_number: Optional[str] = None  # BP Number associated with the instance
        self._contract_id: Optional[str] = None  # Contract ID associated with the instance
        self._account_id: Optional[str] = None  # Account ID associated with the instance
        self._masa_connection_size_map: Optional[dict[int, str]] = None

    def _shutdown(self):
        if not self._session.closed:
            asyncio.run(self._session.close())

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit - properly close the session."""
        await self._session.close()

    # -------------
    # Data methods:
    # -------------

    async def get_customer(self) -> Optional[Customer]:
        """
        Get consumer data response from IEC API.
        :return: Customer data
        """
        await self.check_token()
        customer = await data.get_customer(self._session, self._token)
        if customer:
            self._bp_number = customer.bp_number
        return customer

    async def get_customer_mobile(self, contract_id: Optional[str]) -> CustomerMobileResponse:
        """
        Get customer mobile data response from IEC API.
        :param contract_number: The contract number to query
        :return: Customer mobile data
        """
        await self.check_token()

        if not contract_id:
            contract_id = self._contract_id

        if not contract_id:
            raise ValueError("Contract id must be provided")

        return await data.get_customer_mobile(self._session, self._token, contract_id)

    async def get_accounts(self) -> Optional[List[Account]]:
        """
        Get consumer data response from IEC API.
        :return: Customer data
        """
        await self.check_token()
        accounts = await data.get_accounts(self._session, self._token)

        if accounts and len(accounts) > 0:
            self._bp_number = accounts[0].account_number
            self._account_id = str(accounts[0].id)

        return accounts

    async def get_default_account(self) -> Account:
        """
        Get consumer data response from IEC API.
        :return: Customer data
        """
        accounts = await self.get_accounts()
        return accounts[0]

    async def get_default_contract(self, bp_number: str = None) -> Optional[Contract]:
        """
        This function retrieves the default contract based on the given BP number.
        :param bp_number: A string representing the BP number
        :return: Contract object containing the contract information
        """

        await self.check_token()

        if not bp_number and self._bp_number:
            bp_number = self._bp_number

        if not bp_number:
            raise ValueError("BP number must be provided")

        get_contract_response = await data.get_contracts(self._session, self._token, bp_number)
        if get_contract_response:
            contracts = get_contract_response.contracts
            if contracts and len(contracts) > 0:
                self._contract_id = contracts[0].contract_id
            return contracts[0]
        return None

    async def get_contracts(
        self, bp_number: Optional[str] = None, count: Optional[int] = None, contract_number: Optional[str] = None
    ) -> list[Contract]:
        """
        This function retrieves contracts based on the given BP number.
        :param bp_number: A string representing the BP number
        :param count: Optional limit on number of contracts to return
        :param contract_number: Optional specific contract number to filter by
        :return: list of Contract objects
        """

        await self.check_token()

        if not bp_number:
            bp_number = self._bp_number

        if not bp_number:
            raise ValueError("BP number must be provided")

        get_contract_response = await data.get_contracts(
            self._session, self._token, bp_number, count=count, contract_number=contract_number
        )
        if get_contract_response:
            contracts = get_contract_response.contracts
            if contracts and len(contracts) > 0:
                self._contract_id = contracts[0].contract_id
            return contracts
        return []

    async def get_contract_check(self, contract_id: Optional[str] = None) -> Optional[ContractCheck]:
        """
        Get contract check for the contract
        Args:
            self: The instance of the class.
            contract_id (str): The Contract ID of the meter.
        Returns:
            ContractCheck: a contract check
        """
        await self.check_token()

        if not contract_id:
            contract_id = self._contract_id

        if not contract_id:
            raise ValueError("Contract Id must be provided")

        return await data.get_contract_check(self._session, self._token, contract_id)

    async def get_last_meter_reading(
        self, bp_number: Optional[str] = None, contract_id: Optional[str] = None
    ) -> Optional[MeterReadings]:
        """
        Retrieves a last meter reading for a specific contract and user.
        Args:
            self: The instance of the class.
            bp_number (str): The BP number of the meter.
            contract_id (str): The contract ID associated with the meter.
        Returns:
            MeterReadings: The response containing the meter readings.
        """
        await self.check_token()
        if not bp_number:
            bp_number = self._bp_number

        if not bp_number:
            raise ValueError("BP number must be provided")

        if not contract_id:
            contract_id = self._contract_id

        if not contract_id:
            raise ValueError("Contract ID must be provided")

        return await data.get_last_meter_reading(self._session, self._token, bp_number, contract_id)

    async def get_electric_bill(
        self, bp_number: Optional[str] = None, contract_id: Optional[str] = None
    ) -> Optional[ElectricBill]:
        """
        Retrieves a remote reading for a specific meter using the provided parameters.
        Args:
            self: The instance of the class.
            bp_number (str): The BP number of the meter.
            contract_id (str): The contract ID associated with the meter.
        Returns:
            ElectricBill: The Invoices/Electric Bills for the user with the contract_id
        """
        await self.check_token()

        if not bp_number:
            bp_number = self._bp_number

        if not bp_number:
            raise ValueError("BP number must be provided")

        if not contract_id:
            contract_id = self._contract_id

        if not contract_id:
            raise ValueError("Contract ID must be provided")

        return await data.get_electric_bill(self._session, self._token, bp_number, contract_id)

    async def save_invoice_pdf_to_file(
        self,
        file_path: str,
        invoice_number: str | int,
        bp_number: Optional[str | int] = None,
        contract_id: Optional[str | int] = None,
    ):
        """
        Get PDF of invoice from IEC api
        Args:
            self: The instance of the class.
            file_path (str): Path to save the bill to
            invoice_number (str): The requested invoice number
            bp_number (str): The BP number of the meter.
            contract_id (str): The contract ID associated with the meter.
        """
        await self.check_token()

        if not bp_number:
            bp_number = self._bp_number

        if not bp_number:
            raise ValueError("BP number must be provided")

        if not contract_id:
            contract_id = self._contract_id

        if not contract_id:
            raise ValueError("Contract ID must be provided")

        response_bytes = await data.get_invoice_pdf(self._session, self._token, bp_number, contract_id, invoice_number)
        if response_bytes:
            async with aiofiles.open(file_path, "wb") as f:
                await f.write(response_bytes)

    async def send_consumption_report_to_mail(
        self,
        email: str,
        contract_id: Optional[str | int] = None,
        device_id: Optional[str | int] = None,
        device_code: Optional[str | int] = None,
    ) -> bool:
        """
        Send Consumption Report to Mail
        Args:
            self: The instance of the class.
            email (str): Email to send the report to
            contract_id (str): The contract ID associated with the meter.
            device_id: Meter Id,
            device_code: Meter Code
        """
        await self.check_token()

        if not contract_id:
            contract_id = self._contract_id

        if not contract_id:
            raise ValueError("Contract ID must be provided")

        if not device_id:
            devices = await self.get_devices()

            if not devices:
                raise ValueError("No Devices found")
            device_id = devices[0].device_number

        if not device_id:
            raise ValueError("Device ID must be provided")

        if not device_code:
            devices = await self.get_devices()

            if not devices:
                raise ValueError("No Devices found")
            device_code = devices[0].device_code

        if not device_code:
            raise ValueError("Device Code must be provided")

        return await data.send_consumption_report_to_mail(
            self._session, self._token, contract_id, email, device_code, device_id
        )

    async def get_devices(self, contract_id: Optional[str] = None) -> Optional[List[Device]]:
        """
        Get a list of devices for the user
        Args:
            self: The instance of the class.
            contract_id (str): The Contract ID of the meter.
        Returns:
            list[Device]: List of devices
        """
        await self.check_token()

        if not contract_id:
            contract_id = self._contract_id

        if not contract_id:
            raise ValueError("Contract Id must be provided")

        return await data.get_devices(self._session, self._token, contract_id)

    async def get_device_by_device_id(self, device_id: str, contract_id: Optional[str] = None) -> Optional[Devices]:
        """
        Get a list of devices for the user
        Args:
            self: The instance of the class.
            device_id (str): The Device code.
            contract_id (str): The Contract ID of the user.
        Returns:
            list[Device]: List of devices
        """
        await self.check_token()

        if not contract_id:
            contract_id = self._contract_id

        if not contract_id:
            raise ValueError("Contract ID must be provided")

        return await data.get_device_by_device_id(self._session, self._token, contract_id, device_id)

    async def get_device_details_by_device_id(self, device_id: str) -> Optional[List[DeviceDetails]]:
        """
        Get a list of devices for the user
        Args:
            self: The instance of the class.
            device_id (str): The Device id.
        Returns:
            list[DeviceDetails]: List of device details or None
        """
        await self.check_token()

        return await data.get_device_details(self._session, self._token, device_id)

    async def get_device_details_by_device_id_and_code(
        self, device_id: str, device_code: str
    ) -> Optional[DeviceDetails]:
        """
        Get a list of devices for the user
        Args:
            self: The instance of the class.
            device_id (str): The Device id.
            device_code (str): The Device code.
        Returns:
            DeviceDetails: Device details or None
        """
        await self.check_token()

        return await data.get_device_details_by_code(self._session, self._token, device_id, device_code)

    async def get_remote_reading(
        self,
        meter_serial_number: str,
        meter_code: int,
        last_invoice_date: datetime,
        from_date: datetime,
        resolution: ReadingResolution = ReadingResolution.DAILY,
        contract_id: Optional[str] = None,
    ) -> Optional[RemoteReadingResponse]:
        """
        Retrieves a remote reading for a specific meter using the provided parameters.
        Args:
            self: The instance of the class.
            meter_serial_number (str): The serial number of the meter.
            meter_code (int): The code associated with the meter.
            last_invoice_date (str): The date of the last invoice.
            from_date (str): The start date for the remote reading.
            resolution (int): The resolution of the remote reading.
            contract_id (str): The contract id.
        Returns:
            RemoteReadingResponse: The response containing the remote reading or None if not found
        """
        await self.check_token()
        if not contract_id and self._contract_id:
            contract_id = self._contract_id

        return await data.get_remote_reading(
            self._session,
            self._token,
            contract_id,
            meter_serial_number,
            meter_code,
            last_invoice_date,
            from_date,
            resolution,
        )

    async def get_device_type(
        self, bp_number: Optional[str] = None, contract_id: Optional[str] = None
    ) -> Optional[DeviceType]:
        """
        Get a list of devices for the user
        Args:
            self: The instance of the class.
            bp_number (str): The BP number of the meter.
            contract_id (str: The Contract ID
        Returns:
            DeviceType
        """
        await self.check_token()

        if not bp_number:
            bp_number = self._bp_number

        if not bp_number:
            raise ValueError("BP number must be provided")

        if not contract_id:
            contract_id = self._contract_id

        if not contract_id:
            raise ValueError("Contract ID must be provided")

        return await data.get_device_type(self._session, self._token, bp_number, contract_id)

    async def get_billing_invoices(
        self,
        bp_number: Optional[str] = None,
        contract_id: Optional[str] = None,
        only_open: Optional[bool] = None,
    ) -> Optional[GetInvoicesBody]:
        """
        Get billing invoices for the user
        Args:
            self: The instance of the class.
            bp_number (str): The BP number of the meter.
            contract_id (str): The Contract ID
            only_open (bool): If True, only return open invoices
        Returns:
            Billing Invoices data
        """
        await self.check_token()

        if not bp_number:
            bp_number = self._bp_number

        if not bp_number:
            raise ValueError("BP number must be provided")

        if not contract_id:
            contract_id = self._contract_id

        if not contract_id:
            raise ValueError("Contract ID must be provided")

        return await data.get_billing_invoices(self._session, self._token, bp_number, contract_id, only_open=only_open)

    async def get_kwh_tariff(self) -> float:
        """Get kWh tariff"""
        return await static_data.get_kwh_tariff(self._session)

    async def get_distribution_tariff(self, phase_count: Optional[int] = None) -> float:
        """Get get_distribution tariff"""

        if not phase_count:
            devices = await self.get_devices()

            if not devices:
                raise ValueError("No Devices found")
            device = devices[0]

            device_details = await self.get_device_by_device_id(device.device_number)
            if not device_details:
                raise ValueError("No Device Details")

            phase_count = device_details.counter_devices[0].connection_size.phase

        return await static_data.get_distribution_tariff(self._session, phase_count)

    async def get_delivery_tariff(self, phase_count: Optional[int] = None) -> float:
        """Get delivery tariff"""

        if not phase_count:
            devices = await self.get_devices()

            if not devices:
                raise ValueError("No Devices found")
            device = devices[0]

            device_details = await self.get_device_by_device_id(device.device_number)
            if not device_details:
                raise ValueError("No Device Details")

            phase_count = device_details.counter_devices[0].connection_size.phase

        return await static_data.get_delivery_tariff(self._session, phase_count)

    async def get_kva_tariff(self) -> float:
        """Get KVA tariff"""
        return await static_data.get_kva_tariff(self._session)

    async def get_power_size(self, connection: Optional[str] = None) -> float:
        """Get delivery tariff"""

        if not connection:
            devices = await self.get_devices()

            if not devices:
                raise ValueError("No Devices found")
            device = devices[0]

            device_details = await self.get_device_by_device_id(device.device_number)
            if not device_details:
                raise ValueError("No Device Details")

            connection = device_details.counter_devices[0].connection_size.representative_connection_size

        if "X" not in connection:  # Solve cases where the connection size is "25"
            connection = "1X" + connection

        return await static_data.get_power_size(self._session, connection)

    async def get_usage_calculator(self) -> UsageCalculator:
        """
        Get Usage Calculator module
        Returns:
            UsageCalculator
        """
        return await static_data.get_usage_calculator(self._session)

    async def get_efs_messages(
        self, contract_id: Optional[str] = None, service_code: Optional[int] = None
    ) -> Optional[List[EfsMessage]]:
        """Get EFS Messages for the contract
        Args:
            self: The instance of the class.
            contract_id (str): The Contract ID of the meter.
            service_code (str): Specific EFS Service code
        Returns:
            list[EfsMessage]: List of EFS Messages
        """
        await self.check_token()

        if not contract_id:
            contract_id = self._contract_id

        if not contract_id:
            raise ValueError("Contract Id must be provided")

        return await data.get_efs_messages(self._session, self._token, contract_id, service_code)

    async def get_social_discount(self, bp_number: Optional[str] = None) -> Optional[SocialDiscount]:
        """
        Get social discount for the contract
        Args:
            self: The instance of the class.
            bp_number (str): The BP number of the meter.
        Returns:
            SocialDiscount: a social discount
        """
        await self.check_token()

        if not bp_number:
            bp_number = self._bp_number

        if not bp_number:
            raise ValueError("BP number must be provided")

        return await data.get_social_discount(self._session, self._token, bp_number)

    async def get_device_in(self, bp_number: Optional[str] = None) -> Optional[DeviceInResponse]:
        """
        Get device information for active devices
        Args:
            self: The instance of the class.
            bp_number (str): The BP number. Defaults to client's BP number.
        Returns:
            DeviceInResponse: Device information including status and device list
        """
        await self.check_token()

        if not bp_number:
            bp_number = self._bp_number

        if not bp_number:
            raise ValueError("BP number must be provided")

        return await data.get_device_in(self._session, self._token, bp_number)

    async def get_touz_compatibility(
        self, contract_id: Optional[str] = None, bp_number: Optional[str] = None
    ) -> Optional[TouzCompatibility]:
        """Get TOU (Time of Use) tariff compatibility for a contract."""
        await self.check_token()

        if not contract_id:
            contract_id = self._contract_id

        if not contract_id:
            raise ValueError("Contract ID must be provided")

        if not bp_number:
            bp_number = self._bp_number

        if not bp_number:
            raise ValueError("BP number must be provided")

        return await data.get_touz_compatibility(self._session, self._token, contract_id, bp_number)

    async def get_outages_by_account(self, account_id: Optional[str] = None) -> Optional[List[Outage]]:
        """Get Outages for the Account
        Args:
            self: The instance of the class.
            account_id (str): The Account ID of the meter.
        Returns:
            list[Outage]: List of the Outages Messages
        """
        await self.check_token()

        if not account_id:
            account_id = self._account_id

        if not account_id:
            raise ValueError("Account Id must be provided")

        return await data.get_outages_by_account(self._session, self._token, account_id)

    # ----------------
    # Masa API Flow
    # ----------------

    async def get_masa_equipment_by_account(self, account_id: Optional[str] = None) -> GetEquipmentResponse:
        """Get Equipment for the Account
        Args:
            self: The instance of the class.
            account_id (str): The Account ID of the meter.
        Returns:
            GetEquipmentResponse: Get Equipment Response
        """
        await self.check_token()

        if not account_id:
            account_id = self._account_id

        if not account_id:
            raise ValueError("Account Id must be provided")

        return await masa_data.get_masa_equipments(self._session, self._token, account_id)

    async def get_masa_user_profile(self) -> MasaUserProfile:
        """Get Masa User Profile
        Args:
            self: The instance of the class.
        Returns:
            MasaUserProfile: Masa User Profile
        """
        await self.check_token()

        return await masa_data.get_masa_user_profile(self._session, self._token)

    async def get_masa_contact_account_user_profile(self) -> MasaMainPortalContactAccountUserProfile:
        """Get Masa Contact Account User Profile with detailed account and contract information.
        Args:
            self: The instance of the class.
        Returns:
            MasaMainPortalContactAccountUserProfile: Contact Account User Profile with accounts and connections.
        """
        await self.check_token()

        return await masa_data.get_masa_contact_account_user_profile(self._session, self._token)

    async def get_masa_cities(self) -> List[City]:
        """Get Masa Cities
        Args:
            self: The instance of the class.
        Returns:
            list[City]: List of Cities
        """
        await self.check_token()

        return await masa_data.get_masa_cities(self._session, self._token)

    async def get_masa_order_categories(self) -> List[OrderCategory]:
        """Get Masa Cities for the Account
        Args:
            self: The instance of the class.
        Returns:
            list[OrderCategory]: List of Order Categories
        """
        await self.check_token()

        return await masa_data.get_masa_order_categories(self._session, self._token)

    async def get_masa_volt_levels(self) -> List[VoltLevel]:
        """Get Masa Volt Level
        Args:
            self: The instance of the class.
        Returns:
            list[VoltLevel]: List of Volt Levelts
        """
        await self.check_token()
        return await masa_data.get_masa_volt_levels(self._session, self._token)

    async def get_masa_order_titles(self, account_id: Optional[str] = None) -> GetTitleResponse:
        """Get Masa Cities
        Args:
            self: The instance of the class.
            account_id (str): The Account ID of the meter.
        Returns:
            GetTitleResponse: Get Title Response
        """
        await self.check_token()

        if not account_id:
            account_id = self._account_id

        if not account_id:
            raise ValueError("Account Id must be provided")

        return await masa_data.get_masa_order_titles(self._session, self._token, account_id)

    async def get_masa_lookup(self) -> GetLookupResponse:
        """Get Masa Lookup
        Args:
            self: The instance of the class.
        Returns:
            GetLookupResponse: Get Title Response
        """
        await self.check_token()
        return await masa_data.get_masa_lookup(self._session, self._token)

    async def get_masa_connection_size_from_masa(self, account_id: Optional[str] = None) -> Optional[str]:
        if not self._masa_connection_size_map:
            lookup = await self.get_masa_lookup()
            self._masa_connection_size_map = {obj.size_type: obj.name for obj in lookup.connection_size_types}

        equipment = await self.get_masa_equipment_by_account(account_id)

        if not equipment or len(equipment.items) < 1 or len(equipment.items[0].connections) < 1:
            return None

        connection_size = equipment.items[0].connections[0].power_connection_size

        return self._masa_connection_size_map.get(connection_size)

    # ----------------
    # Fault Portal Endpoints
    # ----------------

    async def get_fault_portal_user_profile(self) -> Optional[UserProfile]:
        """Get User Profile for the Account from Fault Portal
        Args:
            self: The instance of the class.
        Returns:
            list[UserProfile]: The User Profile
        """
        await self.check_token()

        return await fault_portal_data.get_user_profile(self._session, self._token)

    async def get_fault_portal_outages_by_account(
        self, account_id: Optional[str] = None
    ) -> Optional[List[FaultPortalOutage]]:
        """Get Outages for the Account from Fault Portal
        Args:
            self: The instance of the class.
            account_id (str): The Account ID of the meter.
        Returns:
            list[Outage]: List of the Outages Messages
        """
        await self.check_token()

        if not account_id:
            account_id = self._account_id

        if not account_id:
            raise ValueError("Account Id must be provided")

        return await fault_portal_data.get_outages_by_account(self._session, self._token, account_id)

    async def post_fault_portal_accounts_transactions(
        self, accounts: List[str], state_code: int = 0
    ) -> AccountsTransactionsResponse:
        """Post Accounts Transactions to Fault Portal
        Args:
            self: The instance of the class.
            accounts (List[str]): List of account UUIDs to query.
            state_code (int): The state code filter (default 0).
        Returns:
            AccountsTransactionsResponse: The accounts transactions response.
        """
        await self.check_token()

        return await fault_portal_data.post_accounts_transactions(self._session, self._token, accounts, state_code)

    # ----------------
    # Login/Token Flow
    # ----------------

    async def login_with_id(self) -> Optional[str]:
        """
        Login with ID and wait for OTP
        Returns:
            str: The OTP factor type
        """
        state_token, factor_id, session_token, otp_factor_type = await login.first_login(self._session, self._user_id)
        self._state_token = state_token
        self._factor_id = factor_id
        self._session_token = session_token
        self._otp_factor_type = otp_factor_type
        return self._otp_factor_type

    async def verify_otp(self, otp_code: str | int) -> bool:
        """
        Verify the OTP code and return the token
        :param otp_code: The OTP code to be verified
        :return: The token
        """
        if not self._factor_id or not self._state_token:
            raise IECLoginError(-1, "OTP wasn't sent during login")

        jwt_token = await login.verify_otp_code(self._session, self._factor_id, self._state_token, str(otp_code))
        self._token = jwt_token
        self.logged_in = True
        return True

    async def manual_login(self):
        """
        Logs the user in by obtaining an authorization token, setting the authorization header,
        and updating the login status and token attribute.
        """
        token = await login.manual_authorization(self._session, self._user_id)
        self.logged_in = True
        self._token = token

    def get_token(self) -> JWT:
        """
        Return the JWT token.
        """
        return self._token

    async def load_jwt_token(self, token: JWT):
        """
        Set the token and mark the user as logged in.
        :param token: The new token to be set.
        :return: None
        """
        self._token = token
        if await self.check_token():
            self.logged_in = True
        else:
            raise IECLoginError(-1, "Invalid JWT token")

    async def override_id_token(self, id_token):
        """
        Set the token and mark the user as logged in.
        :param id_token: The new token to be set.
        :return: None
        """
        logger.debug(f"Overriding jwt.py token: {id_token}")
        self._token = JWT(access_token="", refresh_token="", token_type="", expires_in=0, scope="", id_token=id_token)
        self._token.id_token = id_token
        self.logged_in = True

    async def check_token(self) -> bool:
        """
        Check the validity of the jwt.py token and refresh in the case of expired signature errors.
        """
        should_refresh = False

        try:
            remaining_to_expiration = login.get_token_remaining_time_to_expiration(self._token)
            if remaining_to_expiration < 0:
                should_refresh = True

        except jwt.exceptions.ExpiredSignatureError as e:
            raise IECLoginError(-1, "Expired JWT token") from e

        if should_refresh:
            logger.debug("jwt.py token expired, refreshing token")
            self.logged_in = False
            await self.refresh_token()

        return True

    async def refresh_token(self):
        """
        Refresh IEC JWT token.
        """
        self._token = await login.refresh_token(self._session, self._token)
        if self._token:
            self.logged_in = True

    async def load_token_from_file(self, file_path: str = "token.json"):
        """
        Load token from file.
        """
        self._token = await login.load_token_from_file(file_path)
        self.logged_in = True

    async def save_token_to_file(self, file_path: str = "token.json"):
        """
        Save token to file.
        """
        await login.save_token_to_file(self._token, file_path)
