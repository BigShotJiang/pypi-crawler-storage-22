# IEUM (이음)

**Integrated Execution & Unified Mediation**

AI coding agent across TUI, WEB, and VS Code.

> This is a placeholder release. Full package coming soon.
