# The MIT License (MIT)
#
# Copyright (c) 2025-2026 Thorsten Simons (sw@snomis.eu)
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import sys
import OpenSSL
import socket


def getservercertificate(fqdn: str = '', port: int = 443) -> str:
    """
    Get the certificate presented the server <fqdn>.

    :param fqdn:  the server's full qualified domain name
    :param port:  the port to talk to
    :returns:     the server's certificates in PEM format
    """
    try:
        sock = socket.create_connection((fqdn, port,))
    except socket.gaierror as e:
        sys.exit(f'Fatal: connection failed: {e}')

    context = OpenSSL.SSL.Context(OpenSSL.SSL.TLSv1_2_METHOD)
    connection = OpenSSL.SSL.Connection(context, sock)
    connection.set_connect_state()
    try:
        connection.do_handshake()
        cert = OpenSSL.crypto.dump_certificate(OpenSSL.crypto.FILETYPE_PEM,
                                               connection.get_peer_certificate(as_cryptography=False)).decode()
        return cert
    except Exception as e:
        sys.exit(f'Fatal: failed to get certificate: {e}')

if __name__ == '__main__':
    print(getservercertificate(fqdn='s3.edc.vsp1o.coe.hitachivantara.com',
                               port=443))