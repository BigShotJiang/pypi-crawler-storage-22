# The MIT License (MIT)
#
# Copyright (c) 2025-2026 Thorsten Simons (sw@snomis.eu)
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.


template = [{'Instructions': ['Replace all values with <text> with your matching content.',
                              'HCPS: the other values can be changed as needed.'
                              'ARRAY: do not change the other values.',
                              '',
                              'Duplicate sections to create multiple storage components,'
                              'at once, if needed.',
                              '',
                              '!!! Delete this Instructions dictionary before use !!!'
                              ]
             },
            {'storageType': 'HCPS_S3',
             'storageComponentConfig': {'label': '<the storage label>',
                                        'host': '<storage FQDN>',
                                        'storageClass': '<the storage class name>',
                                        'storageFaultDomain': '<the storage fault domain name>',
                                        'uriScheme': '<HTTP or HTTPS>',
                                        'port': '<80 or 443>',
                                        'bucket': '<the HCP-S bucket name>',
                                        'region': 'us-east-1',
                                        'authType': 'V2',
                                        'accessKey': '<*****>',
                                        'secretKey': '<*****>',
                                        'useProxy': False,
                                        'proxyHost': None,
                                        'proxyPort': None,
                                        'proxyUserName': None,
                                        'proxyPassword': None,
                                        'managementUser': '<mgmt user name>',
                                        'managementPassword': '<*****>',
                                        'managementProtocol': '<HTTP or HTTP>',
                                        'managementHost': '<MAPI FQDN>',
                                        'usePathStyleAlways': True,
                                        'activateNow': True
                                        }
             },
            {'storageType': 'ARRAY',
             'storageComponentConfig': {'label': '<the storage label>',
                                        'storageClass': '<the storage class name>',
                                        'storageFaultDomain': '<the storage fault domain name>',
                                        'arrayName': '<the Array name from add_array_to_cluster.sh>',
                                        'arrayStorageTier': '<NVMe-QLC or NVMe-TLC>',
                                        'activateNow': True
                                        }
             }
            ]
