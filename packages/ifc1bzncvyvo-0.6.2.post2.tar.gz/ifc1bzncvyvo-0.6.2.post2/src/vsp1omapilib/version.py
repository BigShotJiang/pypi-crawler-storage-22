# The MIT License (MIT)
#
# Copyright (c) 2025-2026 Thorsten Simons (sw@snomis.eu)
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.


# initialized needed variables
#
class Gvars:
    """
    Holds constants and variables that need to be present within the
    whole project.
    """
    # Builder:
    s_builder_version = '0.0.1'

        # version control
    s_builddate = '2026-02-06'
    s_version = "0.6.2post2"
    s_build = "{}/Sm".format(s_builddate)
    s_minPython = "3.9"
    s_description = "vsp1omapilib"
    s_dependencies = ['']
    s_identifier = b'dFdTOTd6M1ZKeEUwaFdKM0RxSFVyS1hRMkNzbjgwcnB4STRqcm1Fd1NvQT0='

    # constants
    Version = "v.{} ({})".format(s_version, s_build)
    Description = 'VSP One Object MAPI library'
    Author = "Thorsten Simons"
    AuthorMail = "sw@snomis.eu"
    AuthorCorp = ""
    AppURL = "https://gitlab.com/simont3/vsp1omapilib"
    License = "MIT"
