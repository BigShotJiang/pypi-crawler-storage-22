---
title: Children and YA Genre Conventions
summary: Genre conventions specific to Children's and Young Adult fiction—The Chosen One, Found Family, School Settings, and Coming of Age.
topics:
  - children-fiction
  - young-adult
  - middle-grade
  - tropes
  - coming-of-age
  - school-setting
  - found-family
  - chosen-one
  - masquerade
cluster: genre-conventions
---

# Children and YA Genre Conventions

Craft guidance on the specific genre tropes and narrative patterns found in Children's (Middle Grade) and Young Adult (YA) fiction.

---

## Key Archetypes

### The Chosen One (Reimagined)

While a classic fantasy trope, in YA/MG it specifically represents **adolescent empowerment**.

* **MG Version:** Wonder and wish fulfillment. "I am special/magical." The discovery that the world is bigger and you matter in it
* **YA Version:** Burden and responsibility. "Why me? I didn't ask for this." The discovery that mattering comes with cost

**Variations:**

* **The Unchosen One** — the sidekick who must save the day when the "real" chosen one fails, dies, or turns out to be wrong. Resonates with teens who feel overlooked
* **The Chosen Who Chooses Differently** — accepts the power but rejects the expected path. Uses destiny as a starting point, not a script
* **The Reluctant Inheritor** — didn't choose this power; it was passed down. The burden of legacy (family expectations, inherited trauma) reframed as fantasy
* **The Anti-Chosen** — discovers they are the prophesied villain, not the hero. Must decide whether to fight their nature or embrace it

**For Interactive Fiction:**

* Let players define what "chosen" means to them through choices: accept destiny, rewrite it, or reject it entirely
* The Unchosen path — where the player is explicitly not special — can be the most compelling IF storyline

### The Absent Adult

To give young protagonists agency, adults must be removed or incapacitated.

* **The Orphan:** Classic removal of safety net. Freedom through loss
* **The Clueless Parent:** Loving but doesn't understand the magic/stakes. Creates guilt in the protagonist who must lie to protect them
* **The Antagonistic Authority:** Adults represent oppressive systems (dystopian). The enemy is not a person but a generation's values
* **The Failing Adult:** Trying their best but overwhelmed. More realistic than incompetent — the adult sees the danger but cannot protect the child from all of it
* **The Absent-by-Choice:** The parent or guardian who left. Abandonment as wound that drives the protagonist's need to prove themselves

**For Interactive Fiction:**

* Adult absence creates space for player agency. The missing guardian means the player makes the hard calls
* Adult figures who return mid-story force the player to decide: accept authority again or maintain independence?

### The Found Family

A core emotional anchor in YA. Protagonists find belonging not in blood relations, but in a ragtag group of misfits.

**Variations:**

* **The Reluctant Assembly** — the group does not choose each other. Circumstance forces them together; genuine bonds form through shared ordeal
* **The Fractured Family** — the found family breaks apart mid-story (betrayal, disagreement, external pressure). Reassembly is earned, not guaranteed
* **The Toxic Found Family** — the group provides belonging but also enables destructive behavior. Cult dynamics, gang loyalty, codependency. The protagonist must recognize the difference between belonging and entrapment
* **The Expanding Circle** — starts with a pair, grows by accumulation. Each new member changes the group dynamic

**Mechanics:** Party banter, loyalty missions, group dynamic choices, internal conflict that strengthens bonds when resolved.

**For Interactive Fiction:**

* Found family members should have individual relationships with the player, not just group membership
* Betrayal within the found family hits hardest when the player chose to trust

### The Rival

A key archetype in YA that drives growth through competition and comparison.

* **The Academic Rival** — competes for grades, positions, teacher approval. Mirrors the protagonist's ambition
* **The Social Rival** — competes for status, friendships, romantic attention. The stakes are emotional, not material
* **The Rival Who Becomes the Friend** — competition reveals mutual respect. The rival understands the protagonist better than their friends do
* **The Rival Who Was Right** — the protagonist's enemy held the correct position all along. Growth requires admitting this

### The Mentor Figure

In YA, mentors are complicated by the adolescent's suspicion of adult authority.

* **The Cool Teacher** — the one adult who "gets it." Risk: idealization that the story must eventually complicate
* **The Older Student** — a peer mentor only slightly ahead. More relatable, less authoritative, and more fallible
* **The Reluctant Guide** — doesn't want to mentor anyone. Their refusal forces the protagonist to earn guidance
* **The Mentor Who Betrays** — the adult who seemed trustworthy but prioritized their own agenda. Devastating in YA because it confirms the adolescent fear that adults cannot be trusted

---

## Narrative Structures

### Coming of Age (Bildungsroman)

The journey from innocence to experience.

1. **Status Quo:** Childlike dependence.
2. **Inciting Incident:** Separation from home/safety.
3. **Trials:** Learning skills, failing, understanding complexity.
4. **Resolution:** Return as an independent individual (Adult).

### The School Setting

A microcosm of society.

* **Sortings/Factions:** Defines identity (Houses, Cliques).
* **The Academic Year:** Provides natural pacing (Term start, Holidays, Finals/Climax).
* **Dual Life:** Balancing homework with saving the world.

### The Masquerade (Secret Magic)

Common in Urban Fantasy YA.

* The protagonist discovers a hidden world overlapping the mundane one.
* *Tension:* Keeping the secret from parents/friends.
* *Metaphor:* Often represents the "secret self" (queer identity, neurodivergence) finding community.

---

## Middle Grade (MG) vs. Young Adult (YA)

| Feature | Middle Grade (8-12) | Young Adult (13-18) |
| :--- | :--- | :--- |
| **Focus** | Family, Friends, Adventure | Identity, Romance, Society |
| **Romance** | Crushes, hand-holding, "Ew/Cute" | Central plot, angst, sexual tension |
| **Violence** | Stylized, bloodless | Visceral, consequential |
| **Ending** | Hopeful, order restored | Bittersweet, world changed |
| **Voice** | Earnest, observant | Introspective, sometimes cynical |

---

## Writing Dystopian YA

**Core Convention:** The personal is political.

* The teen's rebellion against strict rules mirrors their internal rebellion against childhood constraints.
* *Trope:* The Love Triangle as a choice between two futures/ideologies (e.g., Safe Tradition vs. Dangerous Freedom).

---

## Quick Reference

| Trope | Purpose |
| :--- | :--- |
| **The Sorting** | Rapid character identity definition. |
| **Absent Parents** | Forces protagonist agency. |
| **First Love** | High stakes emotion; everything feels new/intense. |
| **The Rebellion** | Externalizing the internal teen struggle for autonomy. |

---

## See Also

* [Audience Targeting](../audience-and-access/audience_targeting.md) (Age appropriateness)
* [Fantasy Conventions](fantasy_conventions.md)
* [School Settings](../world-and-setting/worldbuilding_patterns.md)
