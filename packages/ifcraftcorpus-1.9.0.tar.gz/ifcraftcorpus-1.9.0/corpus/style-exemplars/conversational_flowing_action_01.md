---
title: Conversational Present Second-Person — Action
tags:
  pov: second
  tense: present
  register: conversational
  rhythm: flowing
  genre: [fantasy, adventure]
  mode: action
  language: en
source: "Original / inspired by friendly adventure narrator"
cluster: style-exemplars
---

# Conversational Present Second-Person — Action

You grab the rope bridge just as the planks beneath your feet decide they've had enough of holding together, and for one truly unpleasant moment you're dangling over the gorge with nothing below you but mist and a very long way down. Your arms are burning, but you get a knee over the side rail and haul yourself up onto what's left of the walkway.

On the far side, the bridge is still mostly intact, so you scramble across on hands and knees, trying not to think about the creaking. The wind picks up and the whole thing sways like a hammock, which honestly does not help.

You make it to solid ground and allow yourself one deep breath before the arrow thuds into the post beside your head. Right. The goblins haven't given up, then. You duck behind the stone archway and fumble for the amulet the old merchant pressed into your hand back in Ketterdam. It's warm to the touch now, humming faintly, and the runes along its edge have started to glow.

Whatever it does, now seems like a fine time to find out.
