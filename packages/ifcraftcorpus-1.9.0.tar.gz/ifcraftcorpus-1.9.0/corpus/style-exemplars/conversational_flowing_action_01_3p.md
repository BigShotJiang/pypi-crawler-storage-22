---
title: Conversational Past Third-Limited — Action
tags:
  pov: third_limited
  tense: past
  register: conversational
  rhythm: flowing
  genre: [fantasy, ya]
  mode: action
  language: en
source: "Original / inspired by YA fantasy action"
cluster: style-exemplars
---

# Conversational Past Third-Limited — Action

Mira had exactly zero seconds to feel sorry for herself before the bridge started collapsing. The stones went out from under her in a ripple, like the whole thing had just decided it was done being a bridge, and she did the only reasonable thing a person could do in that situation, which was run.

She ran really, really fast.

The troll was still behind her, which was honestly insulting because the thing had legs like tree stumps and should not have been able to keep up. It bellowed something that was probably rude in Troll, and a chunk of railing exploded where her head had been a second ago.

She hit the far bank at a dead sprint, grabbed a fistful of hanging root, and swung herself up onto the ledge above the gorge just as the last slab of stone tumbled away into the dark. The troll skidded to a halt at the broken edge, swaying, too heavy and too stubborn to fall.

Mira waved at it. "Better luck next time, gorgeous."

It screamed. She climbed.
