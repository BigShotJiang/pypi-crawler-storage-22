---
title: Conversational Past Third-Limited — Dialogue
tags:
  pov: third_limited
  tense: past
  register: conversational
  rhythm: flowing
  genre: [literary, ya]
  mode: dialogue
  language: en
source: "Original / inspired by Natural speech patterns"
cluster: style-exemplars
---

# Conversational Past Third-Limited — Dialogue

"The thing is," Mara said, pulling her knees up onto the bench, "I don't actually think she meant it like that. Like, she was upset, obviously, but that doesn't mean she was trying to hurt you specifically."

Jamie picked at the label on his water bottle. "Yeah, no, I get that. I do. But it's like — okay, you know when someone says something and you know logically they're just venting, but it still kind of lands? It still gets in there?"

"Totally. A hundred percent."

"So that's where I'm at. I'm not mad. I'm just, I don't know." He let out a long breath and looked across the parking lot where the after-school traffic was thinning out. "I'm just tired of being the person people vent at, you know? Like, just once I'd love to be the one someone checks on instead of the one everyone assumes is fine."

Mara was quiet for a second. "You're not fine?"

He almost smiled. "See, that — that right there. That's all I wanted."
