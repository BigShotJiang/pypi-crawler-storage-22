---
title: Conversational Past Third-Limited — Introspection
tags:
  pov: third_limited
  tense: past
  register: conversational
  rhythm: flowing
  genre: [literary]
  mode: introspection
  language: en
source: "Original / inspired by Warm, personal reflection"
cluster: style-exemplars
---

# Conversational Past Third-Limited — Introspection

She kept thinking about it on the walk home, the way you do when a conversation snags on something and won't let go. It wasn't what David had said exactly — it was the way he'd said it, like it was obvious, like everyone already knew and she was just catching up.

And maybe they did. Maybe that was the part that stung.

The evening air was doing that early-autumn thing where it couldn't decide between warm and cool, and she had her jacket half on, half draped over one shoulder, which probably looked ridiculous but felt about right for how the day had gone. Half committed. Not quite sure where it was headed.

She passed the bakery on Elm that always smelled like butter and cinnamon and thought, not for the first time, that some version of a good life was just finding a place that made you feel the way that bakery smelled. Warm without trying. Sweet without being too much about it.

She didn't have that yet. But the walk was nice.
