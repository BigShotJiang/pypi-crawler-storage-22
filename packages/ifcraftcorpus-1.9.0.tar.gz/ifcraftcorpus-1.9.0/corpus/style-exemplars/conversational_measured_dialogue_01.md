---
title: Conversational Past First-Person — Dialogue
tags:
  pov: first
  tense: past
  register: conversational
  rhythm: measured
  genre: [mystery, noir]
  mode: dialogue
  language: en
source: "Original / inspired by detective recounting a conversation"
cluster: style-exemplars
---

# Conversational Past First-Person — Dialogue

I found Delaney at the bar on Vine, same stool he always used, the one nearest the back door. I sat down next to him and ordered a coffee I didn't want.

I asked him about the Sorrento job. He said he didn't know anything about any Sorrento job. I told him that was interesting, because his prints were on the service entrance door and the security footage had him arriving at ten and leaving at half past midnight.

He went quiet for a while. Stirred his drink. Then he said, "You ever consider that maybe I was there for personal reasons?"

"At a warehouse," I said. "At ten at night."

"I know people in the neighborhood."

I let that sit. Sometimes you learn more from the pauses than from the answers. He kept stirring that drink, slow circles, not looking at me.

"Delaney," I said. "The owner's in the hospital. Somebody worked him over pretty good. I'm not here to jam you up, but I need to know who else was in that building."

He set the glass down. "You're buying the next round," he said. And then he started talking.
