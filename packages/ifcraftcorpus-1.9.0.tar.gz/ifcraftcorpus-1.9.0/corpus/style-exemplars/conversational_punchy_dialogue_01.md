---
title: Conversational Present Second-Person — Dialogue
tags:
  pov: second
  tense: present
  register: conversational
  rhythm: punchy
  genre: [mystery]
  mode: dialogue
  language: en
source: "Original / inspired by IF NPC interrogation"
cluster: style-exemplars
---

# Conversational Present Second-Person — Dialogue

You lean against the counter and ask Deluca where he was Tuesday night.

"Home," he says. Doesn't look up from his coffee.

You mention the security footage from the parking garage. The footage that puts his car on level two at half past eleven.

He stirs his coffee. "Someone borrowed it."

You ask who.

"A friend."

You tell him his friend left blood on the steering column. You watch his jaw tighten. There it is.

"I want a lawyer," he says.

You remind him this is a conversation, not an arrest. Just two people talking. He's free to leave whenever he wants. You gesture at the door.

He doesn't move.

You pull the photograph from your jacket and slide it across the counter. The woman in the red coat. You ask if he recognizes her.

Deluca looks at the photo for a long time. Something shifts behind his eyes. When he speaks again his voice is quieter, and the bravado has gone out of it like air from a tire.

"Yeah," he says. "I know her."

You wait.

"She's my sister."
