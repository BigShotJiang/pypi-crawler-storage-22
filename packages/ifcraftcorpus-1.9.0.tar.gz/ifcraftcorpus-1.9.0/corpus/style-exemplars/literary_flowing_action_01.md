---
title: Literary Past Third-Limited — Action
tags:
  pov: third_limited
  tense: past
  register: literary
  rhythm: flowing
  genre: [fantasy, literary]
  mode: action
  language: en
source: "Original / inspired by Evocative action with imagery"
cluster: style-exemplars
---

# Literary Past Third-Limited — Action

The wyvern broke through the canopy in a shower of splintered oak and torn leaves, and Sera threw herself sideways into the ravine without thinking, the world tilting as the ground vanished beneath her boots. She hit the slope rolling, bracken and loose stone tearing at her palms, the beast's shadow sweeping over her like a stain across the sun.

It banked hard above the tree line, and in the half-second it took to turn she found her footing, found the bow, nocked an arrow with fingers that had gone electric and strange. The wyvern came back low, skimming the canopy, its wingspan bending the birches like a gale. She could see the pale scarring along its throat where the old wounds had healed silver.

She drew. The string sang against her cheek. The arrow climbed into the corridor of light between the trees, rising toward the creature's turning bulk with a patience that felt borrowed from some calmer, more deliberate world than the one she was standing in.
