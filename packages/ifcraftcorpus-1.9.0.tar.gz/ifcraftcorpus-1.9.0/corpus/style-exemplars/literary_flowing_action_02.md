---
title: Literary Present Second-Person — Action
tags:
  pov: second
  tense: present
  register: literary
  rhythm: flowing
  genre: [fantasy]
  mode: action
  language: en
source: "Original / inspired by epic fantasy IF combat"
cluster: style-exemplars
---

# Literary Present Second-Person — Action

You raise your blade and the world narrows to the space between you and the knight, his armor catching the last of the torchlight as he advances through the shattered gate. The flagstones are slick with rain and something darker, and your boots find their grip in the grooves between the stones as you settle into the old stance, the one your master drilled into your body long before your mind understood its purpose.

He comes fast. The longsword sweeps in from the left in a heavy arc meant to end things quickly, and you turn it aside with a parry that rings through your wrists and up into your shoulders like a bell struck too hard. The force of it drives you back a step. Two.

You let the momentum carry you, pivoting on your heel, and when the second blow falls you are no longer beneath it. Your counter comes low, a cut that traces a bright line across the gap in his plate where the hip meets the thigh. He staggers. The torch on the wall gutters in a wind that smells of smoke and iron, and you press forward into the space his pain has opened, your blade rising again, sure and singing.
