---
title: Literary Past First-Person — Introspection
tags:
  pov: first
  tense: past
  register: literary
  rhythm: flowing
  genre: [literary]
  mode: introspection
  language: en
source: "Original / inspired by unreliable narrator tradition"
cluster: style-exemplars
---

# Literary Past First-Person — Introspection

I have given this account as faithfully as I am able, though I confess that faithfulness and accuracy are not always the same thing. There were details I chose to omit at the time, small elisions that seemed merciful then and which have since calcified into something less forgivable. A silence sustained long enough becomes its own kind of lie, and I had sustained mine for years.

What I told Margaret that evening on the terrace was not, strictly speaking, untrue. I had been at the college. I had spoken with Fenwick. These things happened in the order I described, and yet the shape I gave them — the causal thread I drew so neatly from one event to the next — was my own invention. The world is not so tidy. I made it tidy because I needed her to see a version of events in which my choices were, if not admirable, then at least inevitable. Whether she believed me, I never could determine. She had a way of listening that revealed nothing, and I, who prided myself on reading others, found in her a text I could not parse.

I tell you this now not as confession but as context. Draw from it what conclusions you will.
