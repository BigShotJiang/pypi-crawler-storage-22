---
title: Literary Past Third-Limited — Measured Action
tags:
  pov: third_limited
  tense: past
  register: literary
  rhythm: measured
  genre: [horror, psychological]
  mode: action
  language: en
source: "Original / inspired by psychological horror slow dread"
cluster: style-exemplars
---

# Literary Past Third-Limited — Measured Action

The hallway was longer than it had been that morning. Helen was certain of this. She had walked it a thousand times in the four years since they moved in, and she knew its rhythm the way she knew the space between her own heartbeats. Fourteen steps from the bedroom door to the top of the stairs. She counted them now.

Fifteen. Sixteen.

She stopped. The landing light hummed at a frequency she could feel in her back teeth. The wallpaper — William Morris, the trellis pattern she had chosen herself — repeated in a way it should not have, the same vine curling past the same cracked seam twice before the corner came.

She put her hand against the wall. The plaster was warm. Not sun-warm. Warm the way skin is warm.

Behind her, very softly, a door she had already passed clicked shut.

Helen did not turn around. She understood, with the calm clarity that comes just before real fear, that turning around was no longer the correct thing to do. She walked forward. The hallway continued.
