---
title: Literary Present Second-Person — Exposition
tags:
  pov: second
  tense: present
  register: literary
  rhythm: measured
  genre: [fantasy]
  mode: exposition
  language: en
source: "Original / inspired by literary IF room description"
cluster: style-exemplars
---

# Literary Present Second-Person — Exposition

You stand at the threshold of the observatory, and the room opens before you like the interior of a vast, overturned bell. The walls curve upward in pale stone, fitted so precisely that the joins have vanished into a single unbroken surface, cool and faintly luminous in the afternoon light.

The orrery dominates the center. Its rings of tarnished brass hold spheres of colored glass — jade, amber, a deep arterial red — suspended in slow, soundless rotation. You can hear the mechanism beneath the floor, a patient ticking that rises through the stone into the soles of your boots.

Tall windows line the eastern wall, their glass warped with age, bending the garden outside into something liquid and uncertain. The smell of old paper and lamp oil saturates the air. Bookshelves crowd the spaces between the windows, their contents spilling sideways into leaning towers on the floor.

A writing desk sits beneath the largest window. Its surface holds an open journal, a compass whose needle drifts without settling, and a single white moth resting on the inkwell, wings closed like hands folded in prayer.
