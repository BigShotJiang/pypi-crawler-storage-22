---
title: Literary Past Third-Limited — Dialogue
tags:
  pov: third_limited
  tense: past
  register: literary
  rhythm: punchy
  genre: [mystery, literary]
  mode: dialogue
  language: en
source: "Original / inspired by charged literary interrogation"
cluster: style-exemplars
---

# Literary Past Third-Limited — Dialogue

The detective set the photograph between them, face up. Maren did not look at it.

"You know her," he said.

"Everyone knew her."

"That's not what I asked."

Maren's fingers found the edge of the table. Pressed until the nails went white. "We were close. Once."

"How close?"

"Close enough to know she'd never go to that part of the river alone."

He let that sit. The fluorescent light above them ticked with the quiet insistence of a thought not yet spoken.

"Your car was seen on Deschutes Road at eleven forty."

"I drive that road every night. I live off Deschutes."

"You live off Carver. Deschutes is the long way home."

She met his eyes for the first time. Something precise and deliberate moved behind her expression, the way a hand moves behind a curtain.

"I wanted the drive," she said. "I needed to think."

"About what?"

Silence. The clock on the wall marked the seconds like a court stenographer, faithful and indifferent.

"About how to sit in this chair," she said, "and answer these questions without falling apart."
