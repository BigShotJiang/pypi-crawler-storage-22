---
title: Ornate Present Second-Person — Action
tags:
  pov: second
  tense: present
  register: ornate
  rhythm: flowing
  genre: [horror, gothic]
  mode: action
  language: en
source: "Original / inspired by gothic horror atmosphere"
cluster: style-exemplars
---

# Ornate Present Second-Person — Action

You descend the staircase and the darkness below receives you with the intimacy of an embrace, wrapping itself around your shoulders, pressing its cold mouth against your throat. The banister beneath your fingers is slick with a moisture you choose not to examine, and each step downward carries you further from the lamplight above until it dwindles to a pale and trembling star, impossibly distant, as though the house has stretched itself between you and any hope of return.

Something is breathing in the cellar. You hear it before you reach the bottom — a slow, deliberate respiration that rises and falls with a rhythm almost but not quite human, as though whatever draws that air has learned the motion through careful study rather than necessity. The sound fills the space entirely, pressing against the walls, against your skin, against the fragile architecture of your resolve.

Your foot finds the cellar floor and the breathing stops. The silence that follows is worse, a vast and predatory stillness that gathers itself around you with the patient attention of something that has been waiting here for a very long time and is not disappointed by what has finally arrived.
