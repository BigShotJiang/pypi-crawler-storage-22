---
title: Sparse Past Third-Limited — Exposition
tags:
  pov: third_limited
  tense: past
  register: sparse
  rhythm: flowing
  genre: [sci-fi]
  mode: exposition
  language: en
source: "Original / inspired by spare sci-fi world description"
cluster: style-exemplars
---

# Sparse Past Third-Limited — Exposition

The station held six thousand people and the memory of twice that. Kepler-9 had been built for expansion, its outer ring still raw alloy, corridors unsealed, pressure doors bolted across passages that led nowhere yet. The core spun at a third of a G, enough to keep water in pipes and bones from going soft, not enough to fool anyone into thinking they stood on solid ground.

Light came from strips set into the ceiling every ten meters, a pale blue chosen by committee and hated by everyone. The air tasted of scrubbers and the faint mineral bite of recycled water. Plants grew in racks along the main concourse, soy and kale and a strain of wheat engineered for low gravity, their roots threaded through polymer mesh under lamps that never turned off.

Beyond the viewport, the planet filled half the sky. Brown and amber, banded with storms, beautiful in the way that dangerous things often are when seen from sufficient distance.
