---
title: Sparse Present Second-Person — Exposition
tags:
  pov: second
  tense: present
  register: sparse
  rhythm: measured
  genre: [sci-fi]
  mode: exposition
  language: en
source: "Original / inspired by terse sci-fi habitat description"
cluster: style-exemplars
---

# Sparse Present Second-Person — Exposition

You step through the pressure door into Spoke Three. The corridor runs straight for forty meters, narrowing slightly toward the hub. Overhead lighting panels cast an even white glow. Every third panel is dark. Nobody has replaced them.

The air recyclers hum behind the walls. The sound is constant here, a low vibration you feel in your sternum more than hear. Temperature reads sixteen degrees on the bulkhead display. Standard for an unoccupied spoke.

Supply crates line the left wall, mag-locked to the deck plates. Their labels have faded under years of UV exposure, but you can make out medical markings on the nearest two. The seals appear intact.

Halfway down the corridor, a viewport offers a narrow slice of exterior view. Dust and carbon scoring obscure most of the glass. Through the remaining clear patch you can see the docking ring and, beyond it, the slow rotation of the stars.

The access panel to the maintenance crawlway is open. It should not be. A thin cable trails from inside it and disappears under the nearest crate.
