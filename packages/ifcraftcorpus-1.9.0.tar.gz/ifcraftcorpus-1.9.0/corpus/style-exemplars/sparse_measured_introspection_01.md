---
title: Sparse Past Third-Limited — Introspection
tags:
  pov: third_limited
  tense: past
  register: sparse
  rhythm: measured
  genre: [literary, mystery]
  mode: introspection
  language: en
source: "Original / inspired by Hemingway-style reflection"
cluster: style-exemplars
---

# Sparse Past Third-Limited — Introspection

He sat on the porch and watched the lake. The water was flat and gray and the trees on the far shore were dark against the sky. It would rain later. He could feel it in the stillness.

He thought about the letter. He had read it twice and then folded it and put it in his jacket and that was where it stayed. There was nothing in it he did not already know. She was not coming back. She had found something better or different and the distinction did not matter because the result was the same.

The dog came and lay beside his chair. He put his hand on its head. The fur was warm.

He had been a man who planned things once. Now he sat on porches. It was not the worst thing.
