---
title: Sparse Past Third-Limited — Action
tags:
  pov: third_limited
  tense: past
  register: sparse
  rhythm: punchy
  genre: [mystery, noir, thriller]
  mode: action
  language: en
source: "Original / inspired by Chandler-style noir"
cluster: style-exemplars
---

# Sparse Past Third-Limited — Action

The door gave on the second kick. He went in low, shoulder first, the .38 already up.

Dark room. Venetian blinds cutting the streetlight into slats across the floor. A desk. A chair turned wrong. The smell hit him next — copper and something older, something sweet gone bad.

He found Malloy behind the desk. What was left of him. The blood had pooled wide and black in the dim light, soaking into cheap carpet that had never been clean to begin with.

Something scraped behind him. He spun. The muzzle flash lit the room white. Plaster exploded from the wall six inches left of his ear.

He fired twice. The shape folded. Hit the doorframe on its way down and stayed there.

The ringing took a long time to stop.
