---
title: Sparse Present Second-Person — Action
tags:
  pov: second
  tense: present
  register: sparse
  rhythm: punchy
  genre: [mystery, thriller]
  mode: action
  language: en
source: "Original / inspired by hardboiled IF parser tradition"
cluster: style-exemplars
---

# Sparse Present Second-Person — Action

You kick the door open. It swings hard into the wall and stays there.

Dark room. Stale air. The television is on with the sound off. Blue light crawls over everything. A coffee table. An overturned glass. The carpet is wet underneath it.

Someone has been here recently. You can smell cigarettes. The cheap kind.

You move left along the wall. Your hand finds a light switch. You flip it. Nothing happens.

The floorboard behind you groans. You spin. Something catches you across the jaw. Hard. Your teeth click together and you taste copper.

You grab the arm. Twist. A grunt. You drive your elbow back and connect with something solid. The shape drops.

You pin a wrist to the floor. The blue light from the television shows you a face. You know this face. This changes things.
