---
title: Sparse Past First-Person — Action
tags:
  pov: first
  tense: past
  register: sparse
  rhythm: punchy
  genre: [horror, thriller]
  mode: action
  language: en
source: "Original / inspired by survival horror first-person"
cluster: style-exemplars
---

# Sparse Past First-Person — Action

I heard it before I saw it. A wet sound. Something heavy dragging across tile.

I killed the flashlight. Pressed myself flat against the wall. My hands were shaking so badly I almost dropped the thing.

The dragging stopped.

I held my breath. Counted. Got to four before the smell reached me — rot, thick and warm, like meat left in the sun. My stomach clenched. I bit down on nothing and stayed still.

Then the breathing started. Not mine. Close. Too close. Right on the other side of the wall, separated from me by drywall and paint and absolutely nothing that would matter.

I ran.

I didn't choose to. My legs decided before I did. Down the corridor, past the nurses' station, sneakers slapping linoleum. I hit the stairwell door with both palms and took the stairs three at a time, not looking back, because looking back was how you found out exactly how little distance you had actually gained.

I made it outside. I think. The rest is just cold air and shaking.
