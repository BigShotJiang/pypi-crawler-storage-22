---
title: Sparse Past Third-Limited — Dialogue
tags:
  pov: third_limited
  tense: past
  register: sparse
  rhythm: punchy
  genre: [mystery, thriller]
  mode: dialogue
  language: en
source: "Original / inspired by Terse exchange"
cluster: style-exemplars
---

# Sparse Past Third-Limited — Dialogue

She set the envelope on the table between them. He didn't touch it.

"That's everything," she said.

"It's not."

"It's what you're getting."

He looked at the envelope, then at her. She held steady. Good poker face. Not good enough.

"The photos," he said.

"There are no photos."

"Krause had a camera. Krause always had a camera."

Something shifted behind her eyes. Small. Fast. Gone before she could catch it.

"Krause is dead," she said.

"People die. Cameras don't." He leaned back. "I'll ask once more."

She was quiet for a while. The coffee machine behind the counter hissed and spat.

"Double what we agreed," she said.

"Fine."

She reached into her coat. He let his hand drift under the table. Just in case.
