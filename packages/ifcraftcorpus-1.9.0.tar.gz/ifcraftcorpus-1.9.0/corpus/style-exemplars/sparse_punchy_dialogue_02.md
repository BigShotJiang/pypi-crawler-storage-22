---
title: Sparse Present Second-Person — Dialogue
tags:
  pov: second
  tense: present
  register: sparse
  rhythm: punchy
  genre: [mystery, noir]
  mode: dialogue
  language: en
source: "Original / inspired by noir IF interrogation"
cluster: style-exemplars
---

# Sparse Present Second-Person — Dialogue

You lean forward. The chair creaks. Duvall watches you from the other side of the desk, hands flat on the blotter.

"Where were you last night?" you say.

"Home."

"Anyone confirm that?"

"My cat." He doesn't blink. "She's not a talker."

You pull the matchbook from the evidence bag. Set it on the desk. The Anchor Club logo, faded gold on black.

"This was in Paulson's coat."

"Lot of people go to the Anchor."

"Lot of people didn't owe Paulson thirty grand."

Something tightens around his mouth. Small. You file it away.

"I paid that debt," he says.

"When?"

"Tuesday."

"Paulson died Wednesday."

"Coincidence."

You stand. Walk to the window. Rain streaks the glass. The city blurs.

"Here's what I think," you say. "I think you went to the Anchor. I think you argued. I think it got loud."

"You think a lot."

You turn back to him. "The bartender remembers you, Duvall."

Silence. His hands are still flat on the blotter, but the knuckles have gone pale.

"I want a lawyer," he says.

You pick up the matchbook. Pocket it.

"Smart move."
