# =====================================
# generator=datazen
# version=3.2.3
# hash=5034f9a62b77ba48c2781e8fc34d3161
# =====================================

"""
Useful defaults and other package metadata.
"""

DESCRIPTION = "An interface generator for distributed computing."
PKG_NAME = "ifgen"
VERSION = "4.6.3"
