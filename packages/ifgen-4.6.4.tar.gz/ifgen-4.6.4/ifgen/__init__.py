# =====================================
# generator=datazen
# version=3.2.3
# hash=9a809736c8f98a941940dc0dc8ebfd69
# =====================================

"""
Useful defaults and other package metadata.
"""

DESCRIPTION = "An interface generator for distributed computing."
PKG_NAME = "ifgen"
VERSION = "4.6.4"
