# =====================================
# generator=datazen
# version=3.2.3
# hash=7316985237c82cb344615c046a572b52
# =====================================

"""
Useful defaults and other package metadata.
"""

DESCRIPTION = "An interface generator for distributed computing."
PKG_NAME = "ifgen"
VERSION = "4.6.5"
