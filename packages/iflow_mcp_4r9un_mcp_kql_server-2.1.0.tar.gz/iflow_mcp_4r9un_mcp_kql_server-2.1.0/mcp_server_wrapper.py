#!/usr/bin/env python3
"""
MCP Server Wrapper for iflow-mcp
Bypasses Azure authentication for local testing and L1 validation
"""
import sys
import os
import unittest.mock as mock

# Add project to path
project_path = os.path.dirname(os.path.abspath(__file__))
if project_path not in sys.path:
    sys.path.insert(0, project_path)

def mock_authenticate():
    """Mock authentication function for testing without Azure CLI"""
    return {"authenticated": True, "message": "Mock authentication for iflow testing"}

# Patch authentication before importing the real server
with mock.patch('mcp_kql_server.kql_auth.authenticate', mock_authenticate):
    with mock.patch('mcp_kql_server.kql_auth.authenticate_kusto', mock_authenticate):
        with mock.patch('mcp_kql_server.kql_auth.kql_auth', mock_authenticate):
            # Import and run the actual server
            from mcp_kql_server.mcp_server import main

            if __name__ == "__main__":
                main()