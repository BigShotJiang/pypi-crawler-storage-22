#!/usr/bin/env python3
"""
Test script to bypass Azure authentication for local testing
"""
import sys
import os

# Add project to path
sys.path.insert(0, '/app/auto-mcp-upload/data/3763')

# Mock authentication
import unittest.mock as mock

# Mock the authenticate function to return success without actual Azure login
def mock_authenticate():
    return {"authenticated": True, "message": "Mock authentication for testing"}

# Patch the authentication before importing the server
with mock.patch('mcp_kql_server.kql_auth.authenticate', mock_authenticate):
    with mock.patch('mcp_kql_server.kql_auth.authenticate_kusto', mock_authenticate):
        with mock.patch('mcp_kql_server.kql_auth.kql_auth', mock_authenticate):
            # Import the server after patching
            from mcp_kql_server.mcp_server import mcp

            print("MCP Server created successfully!")
            print(f"Server name: {mcp.name}")

            # List available tools
            tools = mcp._tool_manager.list_tools()
            print(f"\nAvailable tools ({len(tools)}):")
            for tool in tools:
                print(f"  - {tool.name}: {tool.description[:100]}...")

            print("\n✅ Test passed! Server can be initialized without Azure authentication")
            sys.exit(0)