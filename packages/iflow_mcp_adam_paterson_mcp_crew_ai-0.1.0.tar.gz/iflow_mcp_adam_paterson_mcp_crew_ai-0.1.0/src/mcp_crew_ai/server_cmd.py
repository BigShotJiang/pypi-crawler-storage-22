#!/usr/bin/env python3
"""
MCP Crew AI Server - Standalone executable
This module provides a direct command-line interface to run the server via uvx
"""
from mcp_crew_ai.server import server

if __name__ == "__main__":
    server.run()