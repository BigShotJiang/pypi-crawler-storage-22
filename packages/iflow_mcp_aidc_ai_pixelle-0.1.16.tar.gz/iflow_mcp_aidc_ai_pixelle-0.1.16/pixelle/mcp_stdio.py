# Copyright (C) 2025 AIDC-AI
# This project is licensed under the MIT License (SPDX-License-identifier: MIT).

"""MCP stdio entry point for testing purposes."""

from pixelle.mcp_core import mcp

if __name__ == "__main__":
    # FastMCP's run() method handles asyncio internally
    mcp.run()