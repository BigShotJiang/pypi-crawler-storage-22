---
name: "⭐ Submit a feature request"
about: Surface a feature or problem that you think should be solved
title: ""
labels: enhancement
assignees: ""
---

### Describe the feature or problem you’d like to solve

A clear and concise description of what the feature or problem is.

### Proposed solution

How will it benefit GitHub MCP Server and its users?

### Additional context

Add any other context like screenshots or mockups are helpful, if applicable.
