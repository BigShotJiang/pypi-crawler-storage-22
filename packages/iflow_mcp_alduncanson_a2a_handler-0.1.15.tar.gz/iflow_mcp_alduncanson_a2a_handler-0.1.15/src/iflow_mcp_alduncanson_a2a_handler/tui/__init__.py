"""Handler TUI application.

Provides an interactive terminal interface for communicating with A2A agents.
"""

from iflow_mcp_alduncanson_a2a_handler.tui.app import HandlerTUI, main

__all__ = ["HandlerTUI", "main"]
