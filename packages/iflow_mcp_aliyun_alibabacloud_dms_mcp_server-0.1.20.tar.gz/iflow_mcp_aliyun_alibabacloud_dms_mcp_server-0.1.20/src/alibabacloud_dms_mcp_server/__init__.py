def main() -> None:
    print("Hello from alibabacloud-dms-mcp-server!")
