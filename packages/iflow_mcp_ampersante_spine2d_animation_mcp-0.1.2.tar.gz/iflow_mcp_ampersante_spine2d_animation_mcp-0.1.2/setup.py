from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="iflow-mcp_ampersante-spine2d-animation-mcp",
    version="0.1.2",
    author="",
    author_email="",
    description="MCP server for generating SPINE2D animations from PSD files using natural language",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/spine2d-animation-mcp",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 3 - Alpha",
        "Topic :: Multimedia :: Graphics :: 3D Modeling",
        "Topic :: Multimedia :: Graphics :: Editors :: Vector-Based",
    ],
    python_requires=">=3.6",
    install_requires=[
        "flask>=2.0.0",
        "pydantic>=1.8.0",
        "pillow>=9.0.0",
        "psd-tools>=1.9.0",
        "openai>=0.27.0",
        "requests>=2.28.0",
        "python-dotenv>=0.19.0",
    ],
    entry_points={
        "console_scripts": [
            "spine2d-mcp=src.main:main",
        ],
    },
)
