"""
Main entry point for the itmcp package.
"""

import asyncio
from . import main

if __name__ == "__main__":
    asyncio.run(main())