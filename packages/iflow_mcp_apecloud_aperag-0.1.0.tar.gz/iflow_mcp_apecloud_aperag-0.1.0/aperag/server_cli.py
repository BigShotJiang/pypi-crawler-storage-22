#!/usr/bin/env python3
# Copyright 2025 ApeCloud, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
ApeRAG MCP Server - stdio entry point

This script runs the ApeRAG MCP server in stdio mode for MCP client integration.
"""

import asyncio
import os
import sys

# Set a default API key for MCP stdio mode if not provided
if not os.getenv("APERAG_API_KEY"):
    os.environ["APERAG_API_KEY"] = "sk-test-aperag"

from aperag.mcp_server import mcp_server


async def main():
    """Run the MCP server in stdio mode"""
    try:
        await mcp_server.run_stdio_async()
    except KeyboardInterrupt:
        print("MCP server stopped by user", file=sys.stderr)
        sys.exit(0)
    except Exception as e:
        print(f"Error running MCP server: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())