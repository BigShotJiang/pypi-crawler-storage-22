"""MCP Agents Workshop - Educational MCP server examples."""

__version__ = "0.1.0"