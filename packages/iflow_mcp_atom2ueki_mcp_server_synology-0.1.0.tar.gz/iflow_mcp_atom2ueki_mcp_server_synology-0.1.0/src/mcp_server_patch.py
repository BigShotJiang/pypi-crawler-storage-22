# Patch to modify main() function in mcp_server.py
import re

# Read the file
with open('/app/auto-mcp-upload/data/5586/src/mcp_server.py', 'r') as f:
    content = f.read()

# Replace the main() function
old_main = '''async def main():
    """Main entry point."""
    server = SynologyMCPServer()
    await server.run()'''

new_main = '''async def main():
    """Main entry point."""
    server = SynologyMCPServer()
    
    # Skip auto-login in test mode
    if config.test_mode:
        print("⚠️  Running in TEST MODE - skipping auto-login", file=sys.stderr)
    else:
        # Try auto-login if configured
        try:
            await server._auto_login_if_configured()
        except Exception as e:
            if config.debug:
                import traceback
                traceback.print_exc(file=sys.stderr)
            # Don't fail if auto-login doesn't work, user can login manually
    
    await server.run()'''

content = content.replace(old_main, new_main)

# Write back
with open('/app/auto-mcp-upload/data/5586/src/mcp_server.py', 'w') as f:
    f.write(content)

print("✅ Patched mcp_server.py to support test mode")