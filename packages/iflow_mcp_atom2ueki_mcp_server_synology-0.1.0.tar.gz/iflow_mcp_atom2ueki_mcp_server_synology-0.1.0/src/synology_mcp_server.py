#!/usr/bin/env python3
"""
Entry point for Synology MCP Server package.
This module re-exports the main function from main.py
"""

from main import main

if __name__ == "__main__":
    main()