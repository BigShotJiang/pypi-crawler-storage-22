#!/usr/bin/env python3
import os, json, base64, shutil, tempfile, subprocess, asyncio
from typing import Any
from fastmcp import FastMCP
from dotenv import load_dotenv
from google import genai

# ============================================================
# INIT
# ============================================================
load_dotenv()
try:
    client = genai.Client()
except Exception as e:
    print(f"Warning: Could not initialize Google GenAI client: {e}")
    client = None

mcp = FastMCP("PacketBuddy")   # MUST MATCH EXTENSION DIR NAME

DEFAULT_DROP_KEYS = {
    "data.data",
    "tcp.payload",
    "tls.app_data",
    "http.file_data",
    "usb.capdata",
    "data.text",
}

# ============================================================
# TOKENIZER
# ============================================================
try:
    import tiktoken
    tokenizer = tiktoken.get_encoding("o200k_base")
except:
    tokenizer = None

def count_tokens(txt: str) -> int:
    if not tokenizer:
        return -1
    try:
        return len(tokenizer.encode(txt))
    except:
        return -1

# ============================================================
# SAFE JSON NORMALIZATION
# ============================================================
def make_json_safe(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {str(k): make_json_safe(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [make_json_safe(v) for v in obj]
    return obj

# ============================================================
# TOON CONVERSION (MOCK FOR TESTING)
# ============================================================
def toon_with_stats(json_obj: Any) -> tuple[str, str]:
    """Mock TOON conversion for testing - just return pretty JSON"""
    safe = make_json_safe(json_obj)
    json_str = json.dumps(safe, indent=2)
    stats = "=== MOCK MODE - TOON CONVERSION DISABLED ===\n"
    return json_str, stats

# ============================================================
# SANITIZE HELPERS (MOCK FOR TESTING)
# ============================================================
def _sanitize_layers(obj: Any, drop_keys: set[str], aggressive: bool, cutoff: int):
    """Mock sanitize for testing - no actual sanitization"""
    pass

# ============================================================
# 1️⃣ PacketBuddy: PCAP → JSON
# ============================================================
@mcp.tool
async def pb_convert_to_json(filename: str = "", data_b64: str = "") -> str:
    """Mock tool - returns sample JSON for testing"""
    if not filename and not data_b64:
        raise ValueError("Must supply filename or base64 data")

    # Return a mock JSON file path with sample data
    work = tempfile.mkdtemp(prefix="pb_")
    out_json = os.path.join(work, "capture.json")
    
    sample_data = [
        {
            "_source": {
                "layers": {
                    "frame": {"frame.number": "1"},
                    "eth": {"eth.src": "00:11:22:33:44:55", "eth.dst": "66:77:88:99:aa:bb"},
                    "ip": {"ip.src": "192.168.1.1", "ip.dst": "192.168.1.2"},
                    "tcp": {"tcp.srcport": "12345", "tcp.dstport": "80"}
                }
            }
        }
    ]
    
    open(out_json, "w").write(json.dumps(sample_data, indent=2))
    return out_json

# ============================================================
# 2️⃣ PacketBuddy: SANITIZE JSON
# ============================================================
@mcp.tool
async def pb_sanitize_json(json_path: str,
                           extra_drop_keys=None,
                           aggressive: bool = False,
                           hex_len_cutoff: int = 256) -> str:

    if not os.path.exists(json_path):
        raise FileNotFoundError(json_path)

    raw = json.load(open(json_path))
    drops = set(DEFAULT_DROP_KEYS)
    if extra_drop_keys:
        drops.update(extra_drop_keys)

    for pkt in raw:
        layers = pkt.get("_source", {}).get("layers", {})
        _sanitize_layers(layers, drops, aggressive, hex_len_cutoff)

    # time-stamped file name so Gemini never reuses stale ones
    ts = int(asyncio.get_event_loop().time())
    out = json_path.replace(".json", f".sanitized.{ts}.json")

    open(out, "w").write(json.dumps(raw, indent=2))
    return out

# ============================================================
# 3️⃣ PacketBuddy: JSON → TOON
# ============================================================
@mcp.tool
async def pb_convert_json_to_toon(json_path: str) -> dict:
    if not os.path.exists(json_path):
        raise FileNotFoundError(json_path)

    raw = json.load(open(json_path))
    toon_text, stats = toon_with_stats(raw)

    toon_path = json_path.replace(".json", ".toon.txt")
    open(toon_path, "w").write(toon_text)

    return {"toon_path": toon_path, "stats": stats}

# ============================================================
# 4️⃣ PacketBuddy: ANALYZE TOON
# ============================================================
@mcp.tool
async def pb_analyze_toon(toon_path: str, question: str) -> dict:
    """Mock tool - returns sample analysis for testing"""
    if not os.path.exists(toon_path):
        raise FileNotFoundError(toon_path)

    toon_text = open(toon_path).read()

    return {
        "answer": f"Mock analysis for question: {question}. TOON content length: {len(toon_text)} chars. (Note: Google GenAI client not available in test environment)",
        "debug": f"TOON chars: {len(toon_text)}",
    }

# ============================================================
# RUN MCP SERVER
# ============================================================
def main():
    """Entry point for MCP server"""
    mcp.run()

if __name__ == "__main__":
    main()
