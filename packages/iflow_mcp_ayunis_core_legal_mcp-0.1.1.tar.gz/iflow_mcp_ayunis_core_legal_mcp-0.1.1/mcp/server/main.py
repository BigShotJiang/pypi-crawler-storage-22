"""
ABOUTME: Legal MCP Server providing tools for querying German legal texts
ABOUTME: Standalone version with mock data for local testing

A FastMCP server providing tools for querying German legal texts.
This is a standalone version that uses mock data for demonstration purposes.
"""

from fastmcp import FastMCP
from pydantic import BaseModel, Field
from typing import List, Optional
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastMCP server
mcp = FastMCP(
    name="Legal MCP Server",
    include_fastmcp_meta=True,
)


class LegalTextResult(BaseModel):
    """Result from legal text query"""
    text: str
    code: str
    section: str
    sub_section: str
    similarity_score: Optional[float] = None


# Mock data for demonstration purposes
MOCK_LEGAL_TEXTS = {
    "bgb": [
        {
            "text": "Bürgerliches Gesetzbuch (BGB) - § 1: Begin der Rechtsfähigkeit",
            "section": "§ 1",
            "sub_section": "",
            "content": "Die Rechtsfähigkeit des Menschen beginnt mit der Vollendung der Geburt."
        },
        {
            "text": "Bürgerliches Gesetzbuch (BGB) - § 2: Volljährigkeit",
            "section": "§ 2",
            "sub_section": "",
            "content": "Volljährig ist, wer das 18. Lebensjahr vollendet hat."
        },
        {
            "text": "Bürgerliches Gesetzbuch (BGB) - § 433: Vertragstypische Pflichten beim Kaufvertrag",
            "section": "§ 433",
            "sub_section": "",
            "content": "(1) Durch den Kaufvertrag wird der Verkäufer einer Sache verpflichtet, dem Käufer die Sache zu übergeben und das Eigentum an der Sache zu verschaffen. (2) Der Käufer ist verpflichtet, dem Verkäufer den vereinbarten Kaufpreis zu zahlen und die gekaufte Sache abzunehmen."
        }
    ],
    "stgb": [
        {
            "text": "Strafgesetzbuch (StGB) - § 1: Keine Strafe ohne Gesetz",
            "section": "§ 1",
            "sub_section": "",
            "content": "Eine Tat kann nur bestraft werden, wenn die Strafbarkeit gesetzlich bestimmt war, bevor die Tat begangen wurde."
        },
        {
            "text": "Strafgesetzbuch (StGB) - § 2: Zeitliche Geltung",
            "section": "§ 2",
            "sub_section": "",
            "content": "Die Strafe und ihre Nebenfolgen bestimmen sich nach dem Gesetz, das zur Zeit der Tat gilt."
        }
    ],
    "gg": [
        {
            "text": "Grundgesetz (GG) - Art. 1: Menschenwürde",
            "section": "Art 1",
            "sub_section": "",
            "content": "(1) Die Würde des Menschen ist unantastbar. Sie zu achten und zu schützen ist Verpflichtung aller staatlichen Gewalt. (2) Das Deutsche Volk bekennt sich darum zu unverletzlichen und unveräußerlichen Menschenrechten als Grundlage jeder menschlichen Gemeinschaft, des Friedens und der Gerechtigkeit in der Welt."
        }
    ]
}


@mcp.tool()
async def search_legal_texts(
    query: str = Field(description="The search query text"),
    code: str = Field(description="Legal code identifier (e.g., 'bgb', 'stgb')"),
    limit: int = Field(default=5, description="Maximum number of results", ge=1, le=20),
    cutoff: float = Field(
        default=0.7,
        description="Similarity threshold (0-2, lower is more similar)",
        ge=0.0,
        le=2.0,
    ),
) -> List[LegalTextResult]:
    """
    Perform semantic search on German legal texts.
    
    Searches through legal codes using semantic similarity to find relevant
    sections based on the query text. Lower similarity scores indicate better matches.
    
    Args:
        query: Natural language search query
        code: Legal code to search (bgb=Civil Code, stgb=Criminal Code)
        limit: Maximum number of results to return (1-20)
        cutoff: Maximum similarity distance threshold (0-2)
    
    Returns:
        List of matching legal text sections with similarity scores
    """
    try:
        # Simple keyword-based search for demonstration
        results = []
        code_lower = code.lower()
        
        if code_lower not in MOCK_LEGAL_TEXTS:
            return []
        
        for text_data in MOCK_LEGAL_TEXTS[code_lower]:
            content = text_data["content"].lower()
            query_lower = query.lower()
            
            # Simple matching: check if query words appear in content
            words = query_lower.split()
            match_count = sum(1 for word in words if word in content)
            
            if match_count > 0:
                # Calculate a mock similarity score
                similarity_score = max(0.0, 1.0 - (match_count / len(words)))
                results.append(
                    LegalTextResult(
                        text=text_data["content"],
                        code=code,
                        section=text_data["section"],
                        sub_section=text_data["sub_section"],
                        similarity_score=similarity_score,
                    )
                )
        
        # Sort by similarity score and limit results
        results.sort(key=lambda x: x.similarity_score or 0)
        return results[:limit]
    except Exception as e:
        logger.error(f"Error searching legal texts: {e}")
        raise RuntimeError(f"Error searching legal texts: {str(e)}")


@mcp.tool()
async def get_legal_section(
    code: str = Field(description="Legal code identifier (e.g., 'bgb', 'stgb')"),
    section: str = Field(description="Section identifier (e.g., '§ 1', 'Art 1')"),
    sub_section: Optional[str] = Field(
        default=None,
        description="Optional sub-section identifier (e.g., '1', '2a')",
    ),
) -> List[LegalTextResult]:
    """
    Retrieve specific legal text sections by code and section number.
    
    Gets the exact text of a specific legal section or sub-section from
    German legal codes.
    
    Args:
        code: Legal code identifier (bgb, stgb, etc.)
        section: Section identifier (e.g., '§ 1')
        sub_section: Optional sub-section identifier
    
    Returns:
        List of legal text sections matching the criteria
    """
    try:
        code_lower = code.lower()
        if code_lower not in MOCK_LEGAL_TEXTS:
            return []
        
        results = []
        for text_data in MOCK_LEGAL_TEXTS[code_lower]:
            # Match section
            section_match = text_data["section"].lower() == section.lower() or \
                          text_data["section"].lower().replace(" ", "") == section.lower().replace(" ", "")
            
            # Match sub-section if provided
            sub_section_match = True
            if sub_section:
                sub_section_match = text_data["sub_section"] == sub_section
            
            if section_match and sub_section_match:
                results.append(
                    LegalTextResult(
                        text=text_data["content"],
                        code=code,
                        section=text_data["section"],
                        sub_section=text_data["sub_section"],
                    )
                )
        
        return results
    except Exception as e:
        logger.error(f"Error getting legal section: {e}")
        raise RuntimeError(f"Error getting legal section: {str(e)}")


@mcp.tool()
async def get_available_codes() -> List[str]:
    """
    Get all available legal codes in the database.

    Returns a list of legal code identifiers that have been imported
    and are available for querying and searching.

    Returns:
        List of available legal code identifiers (e.g., ['bgb', 'stgb', 'gg'])
    """
    try:
        return list(MOCK_LEGAL_TEXTS.keys())
    except Exception as e:
        logger.error(f"Error getting available codes: {e}")
        raise RuntimeError(f"Error getting available codes: {str(e)}")


def main():
    """Entry point for the MCP server"""
    # Run with stdio transport for local testing
    mcp.run()


# For running with the FastMCP CLI or directly
if __name__ == "__main__":
    main()