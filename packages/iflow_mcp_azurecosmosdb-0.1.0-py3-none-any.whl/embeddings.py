from openai import AzureOpenAI
import os
import tiktoken

def get_aoai_client():
    """Get or create Azure OpenAI client lazily."""
    OPENAI_API_KEY = os.getenv('openai_key')
    OPENAI_API_ENDPOINT = os.getenv('openai_endpoint')
    OPENAI_API_VERSION = os.getenv('openai_api_version')
    EMBEDDING_MODEL_DEPLOYMENT_NAME = os.getenv('openai_embeddings_deployment')

    return AzureOpenAI(
        api_key=OPENAI_API_KEY,
        azure_endpoint=OPENAI_API_ENDPOINT,
        azure_deployment=EMBEDDING_MODEL_DEPLOYMENT_NAME,
        api_version=OPENAI_API_VERSION)

def get_tokenizer():
    """Load tokenizer for text-embedding-3-large."""
    return tiktoken.get_encoding("cl100k_base")

def truncate_text(text, max_tokens=8192):
    tokenizer = get_tokenizer()
    tokens = tokenizer.encode(text)
    if len(tokens) > max_tokens:
        truncated_tokens = tokens[:max_tokens]
        text = tokenizer.decode(truncated_tokens)
    return text

def generate_embeddings(text: str):
    EMBEDDING_MODEL_NAME = os.getenv('openai_embeddings_model')
    if EMBEDDING_MODEL_NAME is None:
        raise ValueError("Embedding model deployment name is not set.")

    text = truncate_text(text)
    client = get_aoai_client()
    response = client.embeddings.create(input=text, model=EMBEDDING_MODEL_NAME)
    embeddings = response.model_dump()
    return embeddings['data'][0]['embedding']