import asyncio
from fastapi import FastAPI, Request, Depends
from mcp.server.sse import SseServerTransport
from mcp.server.stdio import stdio_server
from starlette.routing import Mount
from cosmosdb_mcp import mcp
import uvicorn

from dotenv import load_dotenv

load_dotenv()

app = FastAPI(docs_url=None, redoc_url=None)

sse = SseServerTransport("/messages/")
app.router.routes.append(Mount("/messages", app=sse.handle_post_message))

@app.get("/sse", tags=["MCP"])
async def handle_sse(request: Request):
    async with sse.connect_sse(request.scope, request.receive, request._send) as (
        read_stream,
        write_stream,
    ):
        init_options = mcp._mcp_server.create_initialization_options()

        await mcp._mcp_server.run(
            read_stream,
            write_stream,
            init_options,
        )

def main():
    """Main entry point for stdio transport."""
    mcp.run()

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "--http":
        uvicorn.run(app, host="0.0.0.0", port=8000)
    else:
        main()