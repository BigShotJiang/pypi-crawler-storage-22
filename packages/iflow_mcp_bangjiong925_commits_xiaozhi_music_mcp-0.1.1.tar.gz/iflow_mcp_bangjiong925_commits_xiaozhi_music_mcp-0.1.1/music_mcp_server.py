#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
免费音乐MCP服务器
适用于小智AI音响的音乐控制服务
"""

import asyncio
import json
import sys
from typing import Any, Dict, List, Optional
import httpx
import logging

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 当前播放状态
playback_state = {
    "current_song": None,
    "playlist": [],
    "is_playing": False,
    "volume": 50,
    "position": 0
}

async def search_music_api(query: str, limit: int = 10) -> List[Dict[str, Any]]:
    """调用免费音乐API搜索歌曲"""
    # 这里使用模拟数据，实际使用时可以接入真实的免费音乐API
    mock_results = [
        {
            "id": f"song_{i}",
            "name": f"搜索结果 {i}: {query}",
            "artist": f"歌手 {i}",
            "album": f"专辑 {i}",
            "duration": 240,
            "url": f"https://music.example.com/song_{i}.mp3"
        }
        for i in range(1, min(limit + 1, 6))
    ]

    return mock_results

# 工具处理函数
async def search_music_handler(arguments: Dict[str, Any]) -> str:
    query = arguments["query"]
    limit = arguments.get("limit", 10)

    results = await search_music_api(query, limit)

    response = f"搜索 '{query}' 的结果：\n\n"
    for i, song in enumerate(results, 1):
        response += f"{i}. {song['name']} - {song['artist']}\n"
        response += f"   专辑: {song['album']}\n"
        response += f"   时长: {song['duration']}秒\n"
        response += f"   ID: {song['id']}\n\n"

    return response

async def play_music_handler(arguments: Dict[str, Any]) -> str:
    song_id = arguments["song_id"]
    song_name = arguments.get("song_name", "未知歌曲")
    artist = arguments.get("artist", "未知歌手")

    playback_state["current_song"] = {
        "id": song_id,
        "name": song_name,
        "artist": artist
    }
    playback_state["is_playing"] = True
    playback_state["position"] = 0

    return f"正在播放: {song_name} - {artist}"

async def pause_music_handler(arguments: Dict[str, Any]) -> str:
    playback_state["is_playing"] = False
    return "音乐已暂停"

async def resume_music_handler(arguments: Dict[str, Any]) -> str:
    playback_state["is_playing"] = True
    current = playback_state["current_song"]
    if current:
        return f"继续播放: {current['name']} - {current['artist']}"
    else:
        return "没有可继续播放的歌曲"

async def stop_music_handler(arguments: Dict[str, Any]) -> str:
    playback_state["is_playing"] = False
    playback_state["current_song"] = None
    playback_state["position"] = 0
    return "音乐已停止"

async def set_volume_handler(arguments: Dict[str, Any]) -> str:
    volume = arguments["volume"]
    playback_state["volume"] = volume
    return f"音量已设置为: {volume}%"

async def add_to_playlist_handler(arguments: Dict[str, Any]) -> str:
    song_id = arguments["song_id"]
    song_name = arguments.get("song_name", "未知歌曲")
    artist = arguments.get("artist", "未知歌手")

    song = {
        "id": song_id,
        "name": song_name,
        "artist": artist
    }
    playback_state["playlist"].append(song)

    return f"已添加到播放列表: {song_name} - {artist}"

async def get_playlist_handler(arguments: Dict[str, Any]) -> str:
    playlist = playback_state["playlist"]
    if not playlist:
        return "播放列表为空"

    response = "当前播放列表:\n\n"
    for i, song in enumerate(playlist, 1):
        response += f"{i}. {song['name']} - {song['artist']}\n"

    return response

async def clear_playlist_handler(arguments: Dict[str, Any]) -> str:
    playback_state["playlist"] = []
    return "播放列表已清空"

async def next_song_handler(arguments: Dict[str, Any]) -> str:
    playlist = playback_state["playlist"]
    current = playback_state["current_song"]

    if not playlist:
        return "播放列表为空，无法切换到下一首"

    if current:
        try:
            current_index = next(i for i, song in enumerate(playlist) if song["id"] == current["id"])
            next_index = (current_index + 1) % len(playlist)
        except StopIteration:
            next_index = 0
    else:
        next_index = 0

    next_song = playlist[next_index]
    playback_state["current_song"] = next_song
    playback_state["is_playing"] = True

    return f"下一首: {next_song['name']} - {next_song['artist']}"

async def previous_song_handler(arguments: Dict[str, Any]) -> str:
    playlist = playback_state["playlist"]
    current = playback_state["current_song"]

    if not playlist:
        return "播放列表为空，无法切换到上一首"

    if current:
        try:
            current_index = next(i for i, song in enumerate(playlist) if song["id"] == current["id"])
            prev_index = (current_index - 1) % len(playlist)
        except StopIteration:
            prev_index = len(playlist) - 1
    else:
        prev_index = len(playlist) - 1

    prev_song = playlist[prev_index]
    playback_state["current_song"] = prev_song
    playback_state["is_playing"] = True

    return f"上一首: {prev_song['name']} - {prev_song['artist']}"

# 定义工具列表
TOOLS = [
    {
        "name": "search_music",
        "description": "搜索音乐",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "搜索关键词"},
                "limit": {"type": "integer", "description": "返回结果数量", "default": 10}
            },
            "required": ["query"]
        }
    },
    {
        "name": "play_music",
        "description": "播放音乐",
        "inputSchema": {
            "type": "object",
            "properties": {
                "song_id": {"type": "string", "description": "歌曲ID"},
                "song_name": {"type": "string", "description": "歌曲名称"},
                "artist": {"type": "string", "description": "歌手名称"}
            },
            "required": ["song_id"]
        }
    },
    {
        "name": "pause_music",
        "description": "暂停音乐",
        "inputSchema": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "resume_music",
        "description": "继续播放音乐",
        "inputSchema": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "stop_music",
        "description": "停止音乐",
        "inputSchema": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "set_volume",
        "description": "设置音量",
        "inputSchema": {
            "type": "object",
            "properties": {
                "volume": {"type": "integer", "description": "音量百分比 (0-100)", "minimum": 0, "maximum": 100}
            },
            "required": ["volume"]
        }
    },
    {
        "name": "add_to_playlist",
        "description": "添加到播放列表",
        "inputSchema": {
            "type": "object",
            "properties": {
                "song_id": {"type": "string", "description": "歌曲ID"},
                "song_name": {"type": "string", "description": "歌曲名称"},
                "artist": {"type": "string", "description": "歌手名称"}
            },
            "required": ["song_id"]
        }
    },
    {
        "name": "get_playlist",
        "description": "获取播放列表",
        "inputSchema": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "clear_playlist",
        "description": "清空播放列表",
        "inputSchema": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "next_song",
        "description": "下一首歌",
        "inputSchema": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "previous_song",
        "description": "上一首歌",
        "inputSchema": {
            "type": "object",
            "properties": {}
        }
    }
]

# 工具处理器映射
TOOL_HANDLERS = {
    "search_music": search_music_handler,
    "play_music": play_music_handler,
    "pause_music": pause_music_handler,
    "resume_music": resume_music_handler,
    "stop_music": stop_music_handler,
    "set_volume": set_volume_handler,
    "add_to_playlist": add_to_playlist_handler,
    "get_playlist": get_playlist_handler,
    "clear_playlist": clear_playlist_handler,
    "next_song": next_song_handler,
    "previous_song": previous_song_handler
}

async def handle_request(request: dict) -> dict:
    """处理MCP请求"""
    method = request.get('method')
    params = request.get('params', {})
    request_id = request.get('id')

    logger.info(f"处理请求: {method}")

    if method == 'initialize':
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "result": {
                "protocolVersion": "2024-11-05",
                "capabilities": {
                    "tools": {
                        "listChanged": False
                    },
                    "resources": {
                        "subscribe": False,
                        "listChanged": False
                    }
                },
                "serverInfo": {
                    "name": "xiaozhi-music-mcp",
                    "version": "0.1.0"
                }
            }
        }

    elif method == 'tools/list':
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "result": {
                "tools": TOOLS
            }
        }

    elif method == 'tools/call':
        tool_name = params.get('name')
        arguments = params.get('arguments', {})

        if tool_name in TOOL_HANDLERS:
            try:
                result = await TOOL_HANDLERS[tool_name](arguments)
                return {
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "result": {
                        "content": [
                            {
                                "type": "text",
                                "text": result
                            }
                        ]
                    }
                }
            except Exception as e:
                logger.error(f"工具执行错误: {e}")
                return {
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "error": {
                        "code": -32603,
                        "message": f"工具执行错误: {str(e)}"
                    }
                }
        else:
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "error": {
                    "code": -32601,
                    "message": f"未知工具: {tool_name}"
                }
            }

    elif method == 'resources/list':
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "result": {
                "resources": [
                    {
                        "uri": "music://playlist",
                        "name": "当前播放列表",
                        "description": "显示当前的音乐播放列表"
                    },
                    {
                        "uri": "music://current",
                        "name": "当前播放",
                        "description": "显示当前正在播放的歌曲信息"
                    }
                ]
            }
        }

    elif method == 'resources/read':
        uri = params.get('uri')
        if uri == "music://playlist":
            content = await get_playlist_handler({})
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": {
                    "contents": [
                        {
                            "uri": uri,
                            "mimeType": "text/plain",
                            "text": content
                        }
                    ]
                }
            }
        elif uri == "music://current":
            current = playback_state["current_song"]
            if current:
                content = f"当前播放: {current['name']} - {current['artist']}\n状态: {'播放中' if playback_state['is_playing'] else '已暂停'}\n音量: {playback_state['volume']}%"
            else:
                content = "当前没有播放歌曲"
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": {
                    "contents": [
                        {
                            "uri": uri,
                            "mimeType": "text/plain",
                            "text": content
                        }
                    ]
                }
            }
        else:
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "error": {
                    "code": -32602,
                    "message": f"未知资源: {uri}"
                }
            }

    else:
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "error": {
                "code": -32601,
                "message": f"未知方法: {method}"
            }
        }

async def run_stdio():
    """运行stdio服务器"""
    logger.info("启动免费音乐MCP服务器...")

    while True:
        try:
            line = await asyncio.get_event_loop().run_in_executor(None, sys.stdin.readline)
            if not line:
                break

            request = json.loads(line.strip())
            response = await handle_request(request)

            print(json.dumps(response, ensure_ascii=False))
            sys.stdout.flush()

        except json.JSONDecodeError as e:
            logger.error(f"JSON解析错误: {e}")
            error_response = {
                "jsonrpc": "2.0",
                "id": None,
                "error": {
                    "code": -32700,
                    "message": "JSON解析错误"
                }
            }
            print(json.dumps(error_response, ensure_ascii=False))
            sys.stdout.flush()

        except Exception as e:
            logger.error(f"处理请求错误: {e}")
            error_response = {
                "jsonrpc": "2.0",
                "id": None,
                "error": {
                    "code": -32603,
                    "message": f"内部错误: {str(e)}"
                }
            }
            print(json.dumps(error_response, ensure_ascii=False))
            sys.stdout.flush()

async def main():
    """主函数"""
    await run_stdio()

def run():
    """同步运行函数，用于entry point"""
    asyncio.run(main())

if __name__ == "__main__":
    run()