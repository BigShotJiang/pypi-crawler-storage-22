#!/usr/bin/env python3
"""
CLI entry point for Bio-MCP BLAST server - synchronous wrapper
"""
if __name__ == "__main__":
    import asyncio
    import logging
    
    # Import and run the server using absolute import
    import iflow_mcp_bio_mcp_bio_mcp_blast.src.server_standalone as server_standalone
    
    logging.basicConfig(level=logging.INFO)
    asyncio.run(server_standalone.main())