import json
import logging
from typing import List

from .models import (
    CloudProvider,
    AllInstanceTypeObj,
    InstanceType,
)
from .api import get_instance_types

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("instance-types")


async def get_provider_instance_types(provider: CloudProvider)-> str:
    try:
        all_instance_types_json = await get_instance_types()
        return all_instance_types_json
    except Exception as e:
        logger.error(f"Error getting instance types: {str(e)}")
        raise RuntimeError(f"Failed to get instance types: {str(e)}")