"""Geographic resolution package."""
