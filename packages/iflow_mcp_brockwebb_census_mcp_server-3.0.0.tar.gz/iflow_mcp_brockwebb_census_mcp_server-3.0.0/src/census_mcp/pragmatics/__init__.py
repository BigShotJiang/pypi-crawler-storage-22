"""Pragmatic consultation engine package."""
