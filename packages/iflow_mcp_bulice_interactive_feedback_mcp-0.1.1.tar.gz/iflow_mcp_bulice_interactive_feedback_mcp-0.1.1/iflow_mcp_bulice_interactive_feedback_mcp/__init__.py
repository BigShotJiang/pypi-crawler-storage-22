"""Interactive Feedback MCP - 交互式反馈收集器"""

__version__ = "0.1.0"