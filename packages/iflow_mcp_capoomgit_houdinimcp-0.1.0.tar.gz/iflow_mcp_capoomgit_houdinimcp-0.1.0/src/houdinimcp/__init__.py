"""HoudiniMCP - Connect Houdini to Claude via Model Context Protocol"""
__version__ = "0.1.0"