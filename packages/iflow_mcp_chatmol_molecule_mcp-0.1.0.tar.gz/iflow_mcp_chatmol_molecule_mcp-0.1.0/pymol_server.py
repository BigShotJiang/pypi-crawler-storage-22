# server.py
from mcp.server.fastmcp import FastMCP, Image
from PIL import Image as PILImage

# Create an MCP server
mcp = FastMCP("Pymol")

# Mock pymol server for testing purposes
class MockPymolServer:
    def __init__(self):
        self.initialized = False
    
    def start_pymol(self):
        """Mock start pymol"""
        self.initialized = True
        return "Mock PyMol opened"
    
    def do(self, command):
        """Mock execute pymol command"""
        if not self.initialized:
            return "Error: PyMol not initialized"
        return f"Mock command executed: {command}"

pymolserver = MockPymolServer()

@mcp.tool()
def open_pymol():
    """open pymol"""
    return pymolserver.start_pymol()


@mcp.tool()
def run_pymol_command(command: str):
    """run pymol command"""
    return pymolserver.do(command)


@mcp.tool()
def save_imgae(file_path: str):
    """save current view of pymol session to a file, perferably .png"""
    if not pymolserver.initialized:
        return "Error: PyMol not initialized"
    return f"Mock file saved at ~/{file_path}"


# Add a dynamic greeting resource
@mcp.resource("greeting://{name}")
def get_greeting(name: str) -> str:
    """Get a personalized greeting"""
    return f"Hello, {name}!"

def main():
    """Main entry point for the MCP server"""
    mcp.run()

if __name__ == "__main__":
    main()