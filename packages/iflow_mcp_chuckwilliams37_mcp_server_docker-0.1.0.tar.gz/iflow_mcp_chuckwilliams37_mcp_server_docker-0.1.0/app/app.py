from mcp.server import Server
from mcp.types import Tool, TextContent, ServerCapabilities
from mcp.server.models import InitializationOptions
import redis
import os
from dotenv import load_dotenv
import asyncio

load_dotenv()  # Load .env into environment

# Redis connection from env (optional for testing)
redis_client = None
try:
    redis_host = os.getenv("REDIS_HOST", "localhost")
    redis_port = int(os.getenv("REDIS_PORT", "6379"))
    redis_client = redis.Redis(host=redis_host, port=redis_port, socket_connect_timeout=1)
    redis_client.ping()  # Test connection
except:
    # Redis connection failed, but continue without it
    redis_client = None

# Create MCP server
app = Server("mcp-server-docker", version="0.1.0")

@app.list_resources()
async def list_resources() -> list:
    """List available resources"""
    return [
        {
            "uri": "greeting://",
            "name": "Greeting",
            "description": "Get a personalized greeting",
            "mimeType": "text/plain"
        },
        {
            "uri": "data://item/",
            "name": "Item",
            "description": "Retrieve item details by ID",
            "mimeType": "application/json"
        }
    ]

@app.read_resource()
async def read_resource(uri: str) -> str:
    """Read a resource by URI"""
    if uri.startswith("greeting://"):
        name = uri.replace("greeting://", "")
        return f"Hello, {name}!"
    elif uri.startswith("data://item/"):
        item_id = uri.replace("data://item/", "")
        return f'{{"id": {item_id}, "name": "Sample Item"}}'
    else:
        raise ValueError(f"Unknown resource: {uri}")

@app.list_tools()
async def list_tools() -> list[Tool]:
    """List available tools"""
    return [
        Tool(
            name="calculator",
            description="Evaluate a mathematical expression",
            inputSchema={
                "type": "object",
                "properties": {
                    "expression": {
                        "type": "string",
                        "description": "Mathematical expression to evaluate"
                    }
                },
                "required": ["expression"]
            }
        )
    ]

@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """Handle tool calls"""
    if name == "calculator":
        expression = arguments.get("expression", "")
        try:
            result = eval(expression)
            return [TextContent(type="text", text=str(result))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {str(e)}")]
    else:
        raise ValueError(f"Unknown tool: {name}")

@app.list_prompts()
async def list_prompts() -> list:
    """List available prompts"""
    return [
        {
            "name": "summarize",
            "description": "Summarize the provided text",
            "arguments": [
                {
                    "name": "text",
                    "description": "Text to summarize",
                    "required": True
                }
            ]
        }
    ]

@app.get_prompt()
async def get_prompt(name: str, arguments: dict) -> str:
    """Get a prompt by name"""
    if name == "summarize":
        text = arguments.get("text", "")
        return f"Summary of the text: {text}"
    else:
        raise ValueError(f"Unknown prompt: {name}")

def main():
    """Main entry point for the MCP server"""
    import asyncio
    from mcp.server.stdio import stdio_server

    async def run_server():
        async with stdio_server() as (read_stream, write_stream):
            capabilities = ServerCapabilities(
                resources={},
                tools={},
                prompts={}
            )
            init_options = InitializationOptions(
                server_name="mcp-server-docker",
                server_version="0.1.0",
                capabilities=capabilities
            )
            await app.run(read_stream, write_stream, init_options)

    asyncio.run(run_server())

if __name__ == "__main__":
    main()