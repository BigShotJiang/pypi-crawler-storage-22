def main() -> None:
    print("Hello from attestable-mcp-server!")
