# scripts module initialization
