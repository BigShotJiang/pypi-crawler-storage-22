# utils module initialization
