from setuptools import setup, find_packages

setup(
    name="iflow-mcp_danielmeppiel-oracle-mcp-server",
    packages=find_packages(),
    py_modules=["main"],
)
