"""MSSQL MCP Server entry point"""
import asyncio
import sys
import os

# 确保src目录在Python路径中
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from .server import main

def main_sync():
    """同步入口点，供setuptools使用"""
    asyncio.run(main())

if __name__ == "__main__":
    main_sync()