"""MSSQL MCP Server entry point wrapper"""
import asyncio
from .server import main

def run():
    """同步入口点，供setuptools使用"""
    asyncio.run(main())

if __name__ == "__main__":
    run()