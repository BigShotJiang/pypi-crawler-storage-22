"""
REST API modules for Protein Data Bank MCP.
"""
