PDB_API_URL = "https://data.rcsb.org/rest/v1"
MCP_SERVER_PORT = 8080
