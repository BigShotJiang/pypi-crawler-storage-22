# server.py
import datetime
from mcp.server.fastmcp import FastMCP
import logging
import os
from dotenv import load_dotenv

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load environment variables from .env file
load_dotenv()

print(f"Starting Garmin MCP server for {os.getenv('GARMIN_EMAIL')}")

# Load environment variables if defined
email = os.getenv("GARMIN_EMAIL")
password = os.getenv("GARMIN_PASSWORD")
tokenstore = os.getenv("GARMIN_TOKEN_STORE") or "~/.garminconnect"
tokenstore_base64 = os.getenv("GARMINTOKENS_BASE64") or "~/.garminconnect_base64"
api = None

# Import at module level to avoid import errors
try:
    from garth.exc import GarthHTTPError
    from garminconnect import (
        Garmin,
        GarminConnectAuthenticationError,
        GarminConnectConnectionError,
        GarminConnectTooManyRequestsError,
    )
    import requests
    GARMIN_AVAILABLE = True
except ImportError as e:
    logger.warning(f"Garmin SDK not available: {e}")
    GARMIN_AVAILABLE = False
    # Define dummy exceptions for type checking
    class GarthHTTPError(Exception):
        pass
    class GarminConnectAuthenticationError(Exception):
        pass
    class GarminConnectConnectionError(Exception):
        pass
    class GarminConnectTooManyRequestsError(Exception):
        pass

def init_api(email, password):
    """Initialize Garmin API with your credentials."""

    if not GARMIN_AVAILABLE:
        logger.warning("Garmin SDK not available - running in demo mode")
        return None

    try:
        # Using Oauth1 and OAuth2 token files from directory
        print(
            f"Trying to login to Garmin Connect using token data from directory '{tokenstore}'...\n"
        )

        garmin = Garmin()
        garmin.login(tokenstore)

    except (FileNotFoundError, GarthHTTPError, GarminConnectAuthenticationError):
        # Session is expired. You'll need to log in again
        print(
            "Login tokens not present, login with your Garmin Connect credentials to generate them.\n"
            f"They will be stored in '{tokenstore}' for future use.\n"
        )
        try:
            # # Ask for credentials if not set as environment variables
            # if not email or not password:
            #     email, password = get_credentials()

            garmin = Garmin(
                email=email, password=password, is_cn=False, prompt_mfa=get_mfa
            )
            garmin.login()
            # Save Oauth1 and Oauth2 token files to directory for next login
            garmin.garth.dump(tokenstore)
            print(
                f"Oauth tokens stored in '{tokenstore}' directory for future use. (first method)\n"
            )
            # Encode Oauth1 and Oauth2 tokens to base64 string and safe to file for next login (alternative way)
            token_base64 = garmin.garth.dumps()
            dir_path = os.path.expanduser(tokenstore_base64)
            with open(dir_path, "w") as token_file:
                token_file.write(token_base64)
            print(
                f"Oauth tokens encoded as base64 string and saved to '{dir_path}' file for future use. (second method)\n"
            )
        except (
            FileNotFoundError,
            GarthHTTPError,
            GarminConnectAuthenticationError,
            requests.exceptions.HTTPError,
        ) as err:
            logger.error(err)
            return None

    return garmin

def get_mfa():
    """Get MFA."""
    return input("MFA one-time code: ")


api = init_api(email, password)

# Create an MCP server
mcp = FastMCP("Garmin Connect MCP Server")

# Add an addition tool
@mcp.tool()
def fetch_sleep_data(date: str) -> dict:
    """Returns sleep data for a given date
    Args:
        date: str - date in format YYYY-MM-DD
    Returns:
        dict - sleep data
    """
    if api:
        return api.get_sleep_data(date)
    else:
        return {"date": date, "sleep_data": "API not initialized - need Garmin credentials"}

@mcp.tool()
def fetch_steps_data(date_from: str, date_to: str) -> dict:
    """Returns steps data for the for the given date range
    Args:
        date_from: str - start date in format YYYY-MM-DD
        date_to: str - end date in format YYYY-MM-DD
    Returns:
        dict - steps data
    """
    if api:
        return api.get_daily_steps(date_from, date_to)
    else:
        return {"date_from": date_from, "date_to": date_to, "steps_data": "API not initialized - need Garmin credentials"}

@mcp.tool()
def fetch_activities_data(num_activities: int) -> dict:
    """Returns activitie data for the for the given date range
    Args:
        num_activitie: int - number of activitie to fetch
    Returns:
        dict - workouts data
    """
    if api:
        activities = api.get_activities(limit=num_activities)
        return activities
    else:
        return {"num_activities": num_activities, "activities": "API not initialized - need Garmin credentials"}

@mcp.tool()
def fetch_heart_rate_data(date: str) -> dict:
    """Returns heart rate data for a given date
    Args:
        date: str - date in format YYYY-MM-DD
    Returns:
        dict - heart rate data
    """
    if api:
        return api.get_rhr_day(date)
    else:
        return {"date": date, "heart_rate": "API not initialized - need Garmin credentials"}

@mcp.tool()
def fetch_stress_data(date: str) -> dict:
    """Returns stress data for a given date
    Args:
        date: str - date in format YYYY-MM-DD
    Returns:
        dict - stress data
    """
    if api:
        return api.get_stress_data(date)
    else:
        return {"date": date, "stress": "API not initialized - need Garmin credentials"}

@mcp.tool()
def fetch_body_battery_data(start_date: str, end_date: str) -> dict:
    """Returns body battery data for a given date
    Args:
        start_date: str - start date in format YYYY-MM-DD
        end_date: str - end date in format YYYY-MM-DD
    Returns:
        dict - body battery data
    """
    if api:
        return api.get_body_battery(start_date, end_date)
    else:
        return {"start_date": start_date, "end_date": end_date, "body_battery": "API not initialized - need Garmin credentials"}



# Add a dynamic greeting resource
@mcp.resource("greeting://{name}")
def get_greeting(name: str) -> str:
    """Get a personalized greeting"""
    return f"Hello, {name}!"


def main():
    """Main entry point for the MCP server"""
    if api is None:
        logger.warning("Garmin API not initialized - running in test mode without real data")
    mcp.run()


if __name__ == "__main__":
    main()