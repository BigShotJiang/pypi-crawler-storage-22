import asyncio
from mcp.server.fastmcp import FastMCP

# 创建IoT MCP服务器
mcp = FastMCP("IoT-MCP-Server")

@mcp.tool()
async def read_temperature() -> dict:
    """
    Read temperature from IoT sensor.

    Returns:
    A dictionary with temperature value and timestamp.
    """
    return {
        "sensor": "temperature",
        "value": 22.5,
        "unit": "°C",
        "timestamp": "2024-01-01T12:00:00Z"
    }

@mcp.tool()
async def read_humidity() -> dict:
    """
    Read humidity from IoT sensor.

    Returns:
    A dictionary with humidity value and timestamp.
    """
    return {
        "sensor": "humidity",
        "value": 45.0,
        "unit": "%",
        "timestamp": "2024-01-01T12:00:00Z"
    }

@mcp.tool()
async def list_sensors() -> dict:
    """
    List all available IoT sensors.

    Returns:
    A dictionary with list of available sensors.
    """
    return {
        "sensors": [
            {"name": "DHT11", "type": "temperature_humidity", "status": "online"},
            {"name": "MPU6050", "type": "accelerometer_gyroscope", "status": "online"},
            {"name": "DS18x20", "type": "temperature", "status": "online"},
            {"name": "BH1750", "type": "light", "status": "online"},
            {"name": "TMP36", "type": "temperature", "status": "online"}
        ]
    }

def main():
    """Main entry point for the IoT MCP server."""
    mcp.run()

if __name__ == "__main__":
    main()