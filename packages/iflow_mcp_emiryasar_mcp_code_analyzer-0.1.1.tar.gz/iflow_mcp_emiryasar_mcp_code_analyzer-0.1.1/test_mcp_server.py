#!/usr/bin/env python3
"""简单的MCP服务器测试脚本"""
import asyncio
import sys
import os

# 添加项目路径到Python路径
sys.path.insert(0, '/app/auto-mcp-upload/data/5778')

from mcp.server.stdio import stdio_server
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

async def test_mcp_server():
    """测试MCP服务器"""
    print("🔄 启动MCP服务器测试...")

    # 创建服务器参数
    server_params = StdioServerParameters(
        command="/app/auto-mcp-upload/.venv/bin/python",
        args=["-m", "mcp_code_analyzer"],
        env=None
    )

    try:
        async with stdio_client(server_params) as (read, write):
            async with ClientSession(read, write) as session:
                # 初始化
                await session.initialize()
                print("✅ 服务器初始化成功")

                # 列出工具
                tools = await session.list_tools()
                print(f"✅ 成功获取工具列表，共 {len(tools.tools)} 个工具:")

                for tool in tools.tools:
                    print(f"  - {tool.name}: {tool.description}")

                print("\n✅ 测试成功！")
                return True

    except Exception as e:
        print(f"❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = asyncio.run(test_mcp_server())
    sys.exit(0 if success else 1)