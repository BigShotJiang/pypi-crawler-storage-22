"""Graph RAG MCP Server package for Obsidian vault integration."""
