from __future__ import annotations
import re
import json
import frontmatter
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Dict, List, Tuple, Any
from pydantic import BaseModel

WIKILINK_PATTERN = re.compile(r"\[\[([^\]]+)\]\]")
TAG_PATTERN = re.compile(r"(#\w[\w/-]+)")

class NoteDoc(BaseModel):
    """A document representing a parsed note with metadata."""
    id: str
    text: str
    path: Path
    title: str
    tags: List[str]
    links: List[str]
    meta: Dict[str, Any]
    frontmatter: Dict[str, Any]

def discover_files(vaults: Iterable[Path], supported_extensions: List[str]) -> Iterable[Path]:
    for root in vaults:
        for p in root.rglob("*"):
            if p.suffix.lower() in {ext.lower() for ext in supported_extensions}:
                if not any(part.startswith('.') for part in p.parts):
                    yield p

def is_protected_test_content(path: Path) -> bool:
    """Return True if the path is within a test environment folder.

    We treat any path that has a path segment that starts with test-related prefixes
    as protected to avoid accidental modification of test content.
    """
    try:
        # Protect temporary test directories and fixture content
        test_prefixes = {
            'test_vault_', 'eval_', 'temp_', 'standard_test_', 'planets_only_'
        }
        test_paths = {'fixtures', 'content'}
        
        return any(
            any(part.startswith(prefix) for prefix in test_prefixes) or part in test_paths
            for part in path.parts
        )
    except Exception:
        return False

def load_text(path: Path) -> Tuple[str, Dict]:
    if path.suffix.lower() == ".excalidraw":
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            labels = []
            for el in data.get("elements", []):
                txt = el.get("text")
                if txt:
                    labels.append(txt)
            return "\n".join(labels) or path.stem, {}
        except Exception:
            return path.stem, {}
    
    try:
        with open(path, 'r', encoding='utf-8') as f:
            post = frontmatter.load(f)
            return post.content, post.metadata
    except Exception:
        try:
            raw_text = path.read_text(encoding="utf-8", errors="ignore")
            return raw_text, {}
        except Exception:
            return path.stem, {}

def parse_note(path: Path) -> NoteDoc:
    raw_text, frontmatter_data = load_text(path)
    
    links = WIKILINK_PATTERN.findall(raw_text)
    tags_from_content = [t.strip("#") for t in TAG_PATTERN.findall(raw_text)]
    tags_from_frontmatter = frontmatter_data.get("tags", [])
    
    if isinstance(tags_from_frontmatter, str):
        tags_from_frontmatter = [tags_from_frontmatter]
    elif not isinstance(tags_from_frontmatter, list):
        tags_from_frontmatter = []
    
    all_tags = sorted(set(tags_from_content + tags_from_frontmatter))
    
    # Ensure title is never None
    title = frontmatter_data.get("title") or path.stem or "Untitled"
    if not isinstance(title, str):
        title = str(title) if title is not None else "Untitled"
    
    nid = str(path.relative_to(path.parents[len(path.parents)-1])).replace("\\", "/")
    
    # Convert tags list to comma-separated string for ChromaDB compatibility
    meta: Dict[str, Any] = {
        "path": str(path),
        "title": title,
        "tags": ", ".join(all_tags) if all_tags else "",
        "vault": str(path.parents[len(path.parents)-1])
    }

    # Capture basic file system metadata for downstream filtering/display
    try:
        stat = path.stat()
        modified_dt = datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc)
        meta["file.mtime"] = float(stat.st_mtime)
        meta["file.mtime_iso"] = modified_dt.isoformat()
        meta["file.size"] = int(stat.st_size)

        created_ts = getattr(stat, "st_ctime", None)
        if created_ts is not None:
            created_dt = datetime.fromtimestamp(created_ts, tz=timezone.utc)
            meta["file.ctime"] = float(created_ts)
            meta["file.ctime_iso"] = created_dt.isoformat()
    except OSError:
        # If we cannot read file metadata (unlikely), proceed without it
        pass
    
    # Add frontmatter fields to metadata, ensuring ChromaDB compatibility
    # Only include specific metadata fields to avoid storing large content in metadata
    for key, value in frontmatter_data.items():
        if key not in ["title", "tags"]:  # Skip already handled fields
            # Skip content-like fields that might be large
            if key.lower() in ["content", "body", "text", "description", "summary", "abstract"]:
                continue
                
            if isinstance(value, list):
                # Convert lists to comma-separated strings, limit size
                items = [str(v)[:100] for v in value[:20]]  # Max 20 items, 100 chars each
                meta[key] = ", ".join(items)
            elif isinstance(value, (dict, set)):
                # For complex types, just indicate they exist rather than storing full content
                meta[key] = f"[{type(value).__name__} with {len(value)} items]"
            elif value is None:
                meta[key] = ""
            elif isinstance(value, str):
                # Limit string length for metadata fields
                meta[key] = value[:500] if len(value) <= 500 else value[:497] + "..."
            elif isinstance(value, (int, float, bool)):
                # Numeric and boolean types are fine
                meta[key] = value
            else:
                # For other types, store type info only
                meta[key] = f"[{type(value).__name__}]"
    
    return NoteDoc(
        id=nid,
        text=raw_text.strip(),
        path=path,
        title=title,
        tags=all_tags,
        links=links,
        meta=meta,
        frontmatter=frontmatter_data
    )

def chunk_text(text: str, max_chars: int, overlap: int) -> List[str]:
    if len(text) <= max_chars:
        return [text]
    
    chunks = []
    start = 0
    
    while start < len(text):
        end = min(start + max_chars, len(text))
        
        if end < len(text):
            last_space = text.rfind(' ', start, end)
            last_newline = text.rfind('\n', start, end)
            
            best_break = max(last_space, last_newline)
            if best_break > start:
                end = best_break
        
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        
        if end >= len(text):
            break
            
        start = max(start + 1, end - overlap)
    
    return chunks

def extract_backlinks(note: NoteDoc, all_notes: Dict[str, NoteDoc]) -> List[str]:
    backlinks = []
    note_title = note.title.lower() if note.title else ""
    note_stem = note.path.stem.lower()
    
    for other_note in all_notes.values():
        if other_note.id == note.id:
            continue
            
        for link in other_note.links:
            link_lower = link.lower()
            if link_lower == note_title or link_lower == note_stem:
                backlinks.append(other_note.id)
                break
    
    return backlinks

def resolve_links(note: NoteDoc, all_notes: Dict[str, NoteDoc]) -> List[str]:
    resolved = []
    
    for link in note.links:
        link_lower: str = link.lower()
        
        for other_note in all_notes.values():
            other_title: str = other_note.title.lower() if other_note.title else ""
            if (other_title == link_lower or 
                other_note.path.stem.lower() == link_lower):
                resolved.append(other_note.id)
                break
    
    return resolved
