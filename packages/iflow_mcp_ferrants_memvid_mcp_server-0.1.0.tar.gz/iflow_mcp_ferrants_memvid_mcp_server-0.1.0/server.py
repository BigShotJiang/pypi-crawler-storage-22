import os
from mcp.server.fastmcp import FastMCP

PORT = os.getenv("PORT", "3000")

# Create an MCP server
mcp = FastMCP("memvid", port=PORT, debug=True, log_level="DEBUG")

# Add an addition tool
@mcp.tool()
def add_chunks(chunks: list[str]) -> str:
    """Add chunks to memory video"""
    return "added chunks to memory.mp4 (demo mode)"


@mcp.tool()
def search(query: str, top_k: int = 5) -> str:
    """Search memory chunks"""
    return f"Demo search results for query: {query} (demo mode)"


def main():
    print(f"Running on port {PORT}")
    mcp.run(transport="streamable-http")


if __name__ == "__main__":
    main()
