from setuptools import setup, find_packages

setup(
    name="iflow-mcp_ferrants_memvid-mcp-server",
    version="0.1.0",
    description="Memvid MCP Server - Video memory search and retrieval",
    packages=find_packages(),
    py_modules=["server"],
    install_requires=[
        "mcp>=1.9.4",
    ],
    entry_points={
        "console_scripts": [
            "memvid-mcp=server:main",
        ],
    },
)
