#!/usr/bin/env python3
"""
Test mode FastMCP server for Basecamp integration.
This version bypasses OAuth checks for testing purposes.
"""

import logging
import os
import sys

# Add project root to path
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, PROJECT_ROOT)

from typing import Any, Dict, List, Optional
from mcp.server.fastmcp import FastMCP

# Set up logging to stderr only
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler(sys.stderr)]
)
logger = logging.getLogger('basecamp_test_server')

# Initialize FastMCP server
mcp = FastMCP("basecamp-test")

# Mock tools list for testing
@mcp.tool()
def get_projects() -> str:
    """Get all Basecamp projects (test mode)."""
    return "[]"

@mcp.tool()
def get_project(project_id: str) -> str:
    """Get details for a specific project (test mode)."""
    return f'{{"id": "{project_id}", "name": "Test Project"}}'

@mcp.tool()
def get_todolists(project_id: str) -> str:
    """Get todo lists for a project (test mode)."""
    return f'{{"project_id": "{project_id}", "todolists": []}}'

@mcp.tool()
def get_todos(project_id: str, todolist_id: str) -> str:
    """Get todos from a todo list (test mode)."""
    return f'{{"project_id": "{project_id}", "todolist_id": "{todolist_id}", "todos": []}}'

@mcp.tool()
def search_basecamp(query: str) -> str:
    """Search across Basecamp (test mode)."""
    return f'{{"query": "{query}", "results": []}}'

# Add more mock tools to show the full capability
@mcp.tool()
def create_todo(project_id: str, todolist_id: str, content: str) -> str:
    """Create a new todo item (test mode)."""
    return f'{{"id": "test-todo-1", "content": "{content}"}}'

@mcp.tool()
def get_campfire_lines(project_id: str) -> str:
    """Get recent campfire messages (test mode)."""
    return f'{{"project_id": "{project_id}", "lines": []}}'

@mcp.tool()
def get_message_board(project_id: str) -> str:
    """Get message board for project (test mode)."""
    return f'{{"project_id": "{project_id}", "messages": []}}'

@mcp.tool()
def get_comments(bucket_type: str, recording_id: str) -> str:
    """Get comments for a Basecamp item (test mode)."""
    return f'{{"bucket_type": "{bucket_type}", "recording_id": "{recording_id}", "comments": []}}'

if __name__ == "__main__":
    logger.info("Starting Basecamp FastMCP server in TEST mode")
    mcp.run(transport='stdio')