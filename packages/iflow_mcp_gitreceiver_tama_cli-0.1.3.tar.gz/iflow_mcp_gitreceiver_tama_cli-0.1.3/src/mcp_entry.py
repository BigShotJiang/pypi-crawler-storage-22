#!/usr/bin/env python
import sys
import os

# 添加src到Python路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.mcp_server import mcp

if __name__ == "__main__":
    mcp.run()
