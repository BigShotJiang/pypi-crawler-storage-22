# 读取文件
with open('server.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

# 找到if __name__ == "__main__"的位置并替换
new_lines = []
for i, line in enumerate(lines):
    if line.strip().startswith('if __name__ == "__main__":'):
        # 添加main函数
        new_lines.append('\n')
        new_lines.append('def main():\n')
        new_lines.append('    """Main entry point for the YOLO MCP server"""\n')
        new_lines.append('    logger.info("Starting YOLO MCP service")\n')
        new_lines.append('    \n')
        new_lines.append('    # Start the camera watchdog thread\n')
        new_lines.append('    watchdog_thread = start_watchdog()\n')
        new_lines.append('    \n')
        new_lines.append('    # Initialize and run server\n')
        new_lines.append('    mcp.run(transport=\'stdio\')\n')
        new_lines.append('\n')
        # 修改if __name__部分
        new_lines.append('if __name__ == "__main__":\n')
        new_lines.append('    main()\n')
        # 跳过原来的if __name__块（接下来的几行）
        while i + 1 < len(lines) and not lines[i+1].strip() and lines[i+1].strip() != '':
            i += 1
    else:
        new_lines.append(line)

# 写回文件
with open('server.py', 'w', encoding='utf-8') as f:
    f.writelines(new_lines)

print("main()函数添加成功")
