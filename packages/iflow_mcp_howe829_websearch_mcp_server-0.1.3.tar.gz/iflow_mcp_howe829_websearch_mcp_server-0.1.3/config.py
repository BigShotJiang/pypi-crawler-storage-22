from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False
    )

    bing_search_base_url: str = "https://www.bing.com"
    google_search_base_url: str = "https://www.google.com"
    cc: str = "us"
    language: str = "en"
    impersonate: str = "edge"
    host: str = "127.0.0.1"
    port: int = 8002
    server_mode: str = "stdio"
    llm_base_url: str = "https://api.openai.com/v1"
    llm_api_key: str = "sk-test-key"
    llm_model_name: str = "gpt-4"


try:
    settings = Settings()
except Exception as e:
    import os
    print(f"Settings init error: {e}")
    settings = Settings(
        bing_search_base_url=os.getenv("BING_SEARCH_BASE_URL", "https://www.bing.com"),
        google_search_base_url=os.getenv("GOOGLE_SEARCH_BASE_URL", "https://www.google.com"),
        cc=os.getenv("CC", "us"),
        language=os.getenv("LANGUAGE", "en"),
        impersonate=os.getenv("IMPERSONATE", "edge"),
        host=os.getenv("HOST", "127.0.0.1"),
        port=int(os.getenv("PORT", "8002")),
        server_mode=os.getenv("SERVER_MODE", "stdio"),
        llm_base_url=os.getenv("LLM_BASE_URL", "https://api.openai.com/v1"),
        llm_api_key=os.getenv("LLM_API_KEY", "sk-test-key"),
        llm_model_name=os.getenv("LLM_MODEL_NAME", "gpt-4")
    )