"""Django-MCP - Seamless Integration of Model Context Protocol with Django.

Django-MCP makes it effortless to expose your Django application's
functionality to AI assistants through the Model Context Protocol.
"""

__version__ = "0.1.0"
