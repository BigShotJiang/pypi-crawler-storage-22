"""
Management commands package for Django-MCP.
"""
