"""
Management commands for Django-MCP.
"""
