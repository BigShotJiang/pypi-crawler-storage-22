"""URL configuration for tests."""

urlpatterns = [
    # Add test-specific URLs here if needed
]
