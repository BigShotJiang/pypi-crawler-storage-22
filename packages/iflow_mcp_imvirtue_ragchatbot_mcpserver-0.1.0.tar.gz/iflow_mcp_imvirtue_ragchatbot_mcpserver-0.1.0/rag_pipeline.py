from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain_community.document_loaders import PDFPlumberLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.vectorstores import InMemoryVectorStore
from langchain_core.prompts import ChatPromptTemplate
from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# Init components
embeddings = OpenAIEmbeddings()
vector_store = InMemoryVectorStore(embeddings)
model = ChatOpenAI(model="gpt-4")

template = """
You are a Rag chatbot assistant. Your responsibility is retrieving information from a PDF file and answering the user's questions.
Question: {question}
Context: {context}
Answer:
"""

# Setup prompt template
prompt = ChatPromptTemplate.from_template(template)
chain = prompt | model

# Global flag to track if PDF is loaded
_pdf_loaded = False

def load_and_index_pdf(pdf_path: str = None):
    """Load and index PDF from given path"""
    global _pdf_loaded, vector_store

    if pdf_path is None:
        pdf_path = os.getenv("PDF_PATH", "")

    if not pdf_path or not os.path.exists(pdf_path):
        print(f"PDF file not found at {pdf_path}. Using empty vector store.")
        _pdf_loaded = False
        return

    try:
        loader = PDFPlumberLoader(pdf_path)
        documents = loader.load()

        # Split and index
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200,
            add_start_index=True
        )
        chunks = text_splitter.split_documents(documents)
        vector_store.add_documents(chunks)
        _pdf_loaded = True
        print(f"PDF loaded and indexed: {len(chunks)} chunks")
    except Exception as e:
        print(f"Error loading PDF: {e}")
        _pdf_loaded = False

def ask_from_pdf(question: str) -> str:
    """Query and answer questions from a preloaded PDF document"""
    if not _pdf_loaded:
        return "No PDF document has been loaded. Please set PDF_PATH environment variable and restart the server."

    try:
        relevant_docs = vector_store.similarity_search(question)
        if not relevant_docs:
            return "No relevant information found in the document."

        context = "\n\n".join([doc.page_content for doc in relevant_docs])
        result = chain.invoke({"question": question, "context": context})
        return result.content
    except Exception as e:
        return f"Error processing question: {e}"

# Try to load PDF on module import if PDF_PATH is set
pdf_path = os.getenv("PDF_PATH", "")
if pdf_path and os.path.exists(pdf_path):
    load_and_index_pdf(pdf_path)