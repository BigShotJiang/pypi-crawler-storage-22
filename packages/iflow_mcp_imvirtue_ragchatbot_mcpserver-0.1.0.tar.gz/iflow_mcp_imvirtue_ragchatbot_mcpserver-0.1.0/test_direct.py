#!/usr/bin/env python3
import subprocess
import json
import time

# Start the server
proc = subprocess.Popen(
    ["/app/auto-mcp-upload/.venv/bin/ragchatbot-mcp"],
    stdin=subprocess.PIPE,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    text=True
)

try:
    time.sleep(3)

    # Check if process is still running
    if proc.poll() is not None:
        stderr = proc.stderr.read()
        print(f"Server exited early. stderr: {stderr}")
        exit(1)

    # Send initialize request
    init_request = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "initialize",
        "params": {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {
                "name": "test-client",
                "version": "1.0.0"
            }
        }
    }

    proc.stdin.write(json.dumps(init_request) + "\n")
    proc.stdin.flush()

    # Read response with timeout
    line = proc.stdout.readline()
    print(f"Init response: {line}")

    # Send tools/list request
    list_request = {
        "jsonrpc": "2.0",
        "id": 2,
        "method": "tools/list"
    }

    proc.stdin.write(json.dumps(list_request) + "\n")
    proc.stdin.flush()

    # Read response
    line = proc.stdout.readline()
    print(f"Tools response: {line}")

    # Parse and display
    try:
        response = json.loads(line)
        if "result" in response:
            tools = response["result"].get("tools", [])
            print(f"\nFound {len(tools)} tools:")
            for tool in tools:
                print(f"  - {tool['name']}: {tool.get('description', 'No description')}")
    except Exception as e:
        print(f"Error parsing response: {e}")

except Exception as e:
    print(f"Test error: {e}")
    stderr = proc.stderr.read()
    print(f"stderr: {stderr}")

finally:
    # Cleanup
    proc.terminate()
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait()
