from cursor_db_mcp.server import main

__all__ = ["main"]