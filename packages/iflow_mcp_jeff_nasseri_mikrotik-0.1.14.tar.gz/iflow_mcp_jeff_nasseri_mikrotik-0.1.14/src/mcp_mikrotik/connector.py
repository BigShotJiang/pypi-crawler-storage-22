import os
from .logger import app_logger
from .mikrotik_ssh_client import MikroTikSSHClient
from .settings.configuration import mikrotik_config


MOCK_MIKROTIK = os.getenv("MOCK_MIKROTIK", "false").lower() == "true"


def get_mock_response(command: str) -> str:
    """Generate mock response for testing purposes."""
    app_logger.info(f"Using mock response for command: {command}")
    
    # Mock responses based on command patterns
    if "vlan" in command.lower() and "print" in command.lower():
        return """Columns: NAME, INTERFACE, VLAN-ID
  0 name=office interface=ether1 vlan-id=10
  1 name=guest interface=ether2 vlan-id=20"""
    elif "ip address" in command.lower() and "print" in command.lower():
        return """Columns: ADDRESS, NETWORK, INTERFACE
  0 address=192.168.1.1/24 network=192.168.1.0 interface=ether1
  1 address=10.0.0.1/24 network=10.0.0.0 interface=ether2"""
    elif "dhcp" in command.lower() and "print" in command.lower():
        return """Columns: NAME, INTERFACE
  0 name=dhcp1 interface=ether1"""
    elif "user" in command.lower() and "print" in command.lower():
        return """Columns: NAME, GROUP
  0 name=admin group=full
  1 name=readonly group=read"""
    elif "backup" in command.lower():
        return "Backup created successfully"
    elif "log" in command.lower() and "print" in command.lower():
        return """Columns: TIME, TOPIC, MESSAGE
  0 time=10:00:00 topic=system message="System started"
  1 time=10:01:00 topic=firewall message="Rule added" """
    elif "route" in command.lower() and "print" in command.lower():
        return """Columns: DST-ADDRESS, GATEWAY
  0 dst-address=0.0.0.0/0 gateway=192.168.1.254"""
    elif "dns" in command.lower() and "print" in command.lower():
        return """Columns: NAME, ADDRESS
  0 name=google.com address=8.8.8.8
  1 name=example.com address=93.184.216.34"""
    elif "firewall" in command.lower() and "print" in command.lower():
        return """Columns: CHAIN, ACTION
  0 chain=input action=accept
  1 chain=forward action=accept"""
    elif "wireless" in command.lower() and "print" in command.lower():
        return """Columns: NAME, SSID
  0 name=wlan1 ssid=MyNetwork"""
    else:
        return "Command executed successfully (mock)"


def execute_mikrotik_command(command: str) -> str:
    """
    Execute a MikroTik command via SSH and return the output.
    """
    app_logger.info(f"Executing MikroTik command: {command}")
    
    # Use mock mode if enabled
    if MOCK_MIKROTIK:
        return get_mock_response(command)
    
    ssh_client = MikroTikSSHClient(
        host=mikrotik_config.host,
        username=mikrotik_config.username,
        password=mikrotik_config.password,
        key_filename=mikrotik_config.key_filename,
        port=mikrotik_config.port
    )
    
    try:
        if not ssh_client.connect():
            return "Error: Failed to connect to MikroTik device"
        
        result = ssh_client.execute_command(command)
        app_logger.info(f"Command result: {repr(result)}") 
        return result
    except Exception as e:
        error_msg = f"Error executing command: {str(e)}"
        app_logger.error(error_msg)
        return error_msg
    finally:
        ssh_client.disconnect()
