#!/usr/bin/env python3
"""测试MCP服务器"""
import subprocess
import json
import sys

proc = subprocess.Popen(
    ['/app/auto-mcp-upload/.venv/bin/python', '-m', 'oci_documentation_mcp_server.server'],
    stdin=subprocess.PIPE,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    cwd='/app/auto-mcp-upload/data/3025'
)

# 发送初始化请求
init_req = {
    'jsonrpc': '2.0',
    'id': 1,
    'method': 'initialize',
    'params': {
        'protocolVersion': '2024-11-05',
        'capabilities': {},
        'clientInfo': {'name': 'test', 'version': '1.0'}
    }
}
proc.stdin.write((json.dumps(init_req) + '\n').encode())
proc.stdin.flush()

# 读取初始化响应
response_line = proc.stdout.readline()
response = json.loads(response_line.decode())
print(f'初始化响应: {response.get("result", {}).get("serverInfo", {})}')

# 发送初始化完成通知
notified_req = {
    'jsonrpc': '2.0',
    'method': 'notifications/initialized'
}
proc.stdin.write((json.dumps(notified_req) + '\n').encode())
proc.stdin.flush()

# 发送工具列表请求
tools_req = {
    'jsonrpc': '2.0',
    'id': 2,
    'method': 'tools/list'
}
proc.stdin.write((json.dumps(tools_req) + '\n').encode())
proc.stdin.flush()

# 读取工具列表响应
response_line = proc.stdout.readline()
response = json.loads(response_line.decode())

if 'result' in response and 'tools' in response['result']:
    tools = response['result']['tools']
    print(f'✅ 测试成功！发现 {len(tools)} 个工具:')
    for tool in tools:
        print(f'  - {tool["name"]}: {tool["description"][:80]}...' if len(tool["description"]) > 80 else f'  - {tool["name"]}: {tool["description"]}')
    proc.terminate()
    sys.exit(0)
else:
    print(f'❌ 测试失败: {response}')
    proc.terminate()
    sys.exit(1)