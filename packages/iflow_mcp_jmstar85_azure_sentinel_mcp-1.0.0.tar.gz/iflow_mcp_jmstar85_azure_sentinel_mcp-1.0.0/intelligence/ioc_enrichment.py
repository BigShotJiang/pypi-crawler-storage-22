"""
IoC (Indicators of Compromise) Extraction and Enrichment
Threat indicator analysis for IP, Domain, Hash, URL, etc.
"""

import re
import logging
import hashlib
from typing import Dict, List, Optional, Set
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger(__name__)


@dataclass
class IoC:
    """Indicator of Compromise"""
    ioc_type: str  # ip, domain, hash, url, email
    value: str
    first_seen: Optional[datetime] = None
    last_seen: Optional[datetime] = None
    confidence: str = "Unknown"  # High, Medium, Low, Unknown
    severity: str = "Unknown"  # Critical, High, Medium, Low, Unknown
    threat_types: List[str] = field(default_factory=list)
    sources: List[str] = field(default_factory=list)
    context: Dict = field(default_factory=dict)


class IoCExtractor:
    """Extract IoC from log/event data"""

    # Regular expression patterns
    IP_PATTERN = re.compile(
        r'\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}'
        r'(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b'
    )

    DOMAIN_PATTERN = re.compile(
        r'\b(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}\b'
    )

    EMAIL_PATTERN = re.compile(
        r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    )

    URL_PATTERN = re.compile(
        r'https?://(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}'
        r'\b(?:[-a-zA-Z0-9()@:%_\+.~#?&/=]*)'
    )

    # MD5, SHA1, SHA256
    HASH_PATTERN = re.compile(
        r'\b(?:[a-fA-F0-9]{32}|[a-fA-F0-9]{40}|[a-fA-F0-9]{64})\b'
    )

    # Private IP ranges (for exclusion)
    PRIVATE_IP_PATTERNS = [
        re.compile(r'^10\.'),
        re.compile(r'^172\.(1[6-9]|2[0-9]|3[0-1])\.'),
        re.compile(r'^192\.168\.'),
        re.compile(r'^127\.'),
        re.compile(r'^169\.254\.'),
    ]

    def __init__(self, exclude_private_ips: bool = True):
        """
        Args:
            exclude_private_ips: Whether to exclude private IPs
        """
        self.exclude_private_ips = exclude_private_ips

    def extract_from_text(self, text: str) -> Dict[str, List[str]]:
        """
        Extract IoC from text

        Args:
            text: Text to analyze

        Returns:
            Dictionary of IoC values by type
        """
        if not text:
            return {}

        iocs = {
            "ips": [],
            "domains": [],
            "emails": [],
            "urls": [],
            "hashes": []
        }

        # Extract IPs
        ips = self.IP_PATTERN.findall(text)
        if self.exclude_private_ips:
            ips = [ip for ip in ips if not self._is_private_ip(ip)]
        iocs["ips"] = list(set(ips))

        # Extract Domains (exclude IPs)
        domains = self.DOMAIN_PATTERN.findall(text)
        domains = [d for d in domains if not self.IP_PATTERN.match(d)]
        iocs["domains"] = list(set(domains))

        # Extract Emails
        emails = self.EMAIL_PATTERN.findall(text)
        iocs["emails"] = list(set(emails))

        # Extract URLs
        urls = self.URL_PATTERN.findall(text)
        iocs["urls"] = list(set(urls))

        # Extract Hashes
        hashes = self.HASH_PATTERN.findall(text)
        iocs["hashes"] = list(set(hashes))

        return iocs

    def extract_from_alert(self, alert_data: Dict) -> List[IoC]:
        """
        Extract IoC from Sentinel Alert

        Args:
            alert_data: Sentinel SecurityAlert data

        Returns:
            List of IoC objects
        """
        ioc_objects = []

        # Extract text from key fields
        text_fields = [
            alert_data.get("Description", ""),
            alert_data.get("AlertName", ""),
            alert_data.get("ExtendedProperties", {}).get("User Account", ""),
            str(alert_data.get("Entities", [])),
        ]

        combined_text = " ".join([str(f) for f in text_fields if f])

        # Extract IoC
        extracted = self.extract_from_text(combined_text)

        # Timestamp
        time_generated = alert_data.get("TimeGenerated")
        if isinstance(time_generated, str):
            try:
                time_generated = datetime.fromisoformat(time_generated.replace("Z", "+00:00"))
            except:
                time_generated = None

        # IP addresses
        for ip in extracted["ips"]:
            ioc_objects.append(IoC(
                ioc_type="ip",
                value=ip,
                first_seen=time_generated,
                last_seen=time_generated,
                confidence=alert_data.get("AlertSeverity", "Unknown"),
                sources=["Sentinel Alert"],
                context={"alert_name": alert_data.get("AlertName")}
            ))

        # Domains
        for domain in extracted["domains"]:
            ioc_objects.append(IoC(
                ioc_type="domain",
                value=domain,
                first_seen=time_generated,
                last_seen=time_generated,
                sources=["Sentinel Alert"],
                context={"alert_name": alert_data.get("AlertName")}
            ))

        # Hashes
        for hash_val in extracted["hashes"]:
            hash_type = self._identify_hash_type(hash_val)
            ioc_objects.append(IoC(
                ioc_type=hash_type,
                value=hash_val,
                first_seen=time_generated,
                last_seen=time_generated,
                sources=["Sentinel Alert"],
                context={"alert_name": alert_data.get("AlertName")}
            ))

        # URL
        for url in extracted["urls"]:
            ioc_objects.append(IoC(
                ioc_type="url",
                value=url,
                first_seen=time_generated,
                last_seen=time_generated,
                sources=["Sentinel Alert"],
                context={"alert_name": alert_data.get("AlertName")}
            ))

        return ioc_objects

    def _is_private_ip(self, ip: str) -> bool:
        """Check if IP is private"""
        for pattern in self.PRIVATE_IP_PATTERNS:
            if pattern.match(ip):
                return True
        return False

    def _identify_hash_type(self, hash_val: str) -> str:
        """Identify hash type"""
        length = len(hash_val)
        if length == 32:
            return "md5"
        elif length == 40:
            return "sha1"
        elif length == 64:
            return "sha256"
        return "hash"


class IoCEnricher:
    """IoC Enrichment (External Threat Intelligence Integration)"""

    def __init__(self):
        """Initialize enrichment engine"""
        # In production, integrate with VirusTotal, AbuseIPDB, AlienVault OTX, etc. APIs
        self.reputation_db = self._load_reputation_db()

    def _load_reputation_db(self) -> Dict:
        """
        Load reputation database (sample)
        In production, use threat intelligence feeds
        """
        return {
            "known_malicious_ips": set([
                # Sample malicious IPs (use threat intel feeds in production)
            ]),
            "known_malicious_domains": set([
                # Sample malicious domains
            ]),
            "known_malicious_hashes": set([
                # Sample malicious hashes
            ])
        }

    async def enrich_ioc(self, ioc: IoC) -> IoC:
        """
        IoC Enrichment

        Args:
            ioc: IoC to enrich

        Returns:
            Enriched IoC
        """
        if ioc.ioc_type == "ip":
            return await self._enrich_ip(ioc)
        elif ioc.ioc_type == "domain":
            return await self._enrich_domain(ioc)
        elif ioc.ioc_type in ["md5", "sha1", "sha256", "hash"]:
            return await self._enrich_hash(ioc)
        elif ioc.ioc_type == "url":
            return await self._enrich_url(ioc)

        return ioc

    async def _enrich_ip(self, ioc: IoC) -> IoC:
        """IP address enrichment"""
        # In production, use AbuseIPDB, GreyNoise, Shodan, etc.
        # Here, only perform simple local checks

        # Reputation check
        if ioc.value in self.reputation_db["known_malicious_ips"]:
            ioc.severity = "High"
            ioc.confidence = "High"
            ioc.threat_types.append("Known Malicious")

        # Geo IP information (sample)
        ioc.context["geo"] = {
            "country": "Unknown",
            "city": "Unknown",
            "asn": "Unknown"
        }

        # Port scan history (sample)
        ioc.context["port_scan_activity"] = False

        return ioc

    async def _enrich_domain(self, ioc: IoC) -> IoC:
        """Domain enrichment"""
        # In production, use VirusTotal, URLhaus, PhishTank, etc.

        # Reputation check
        if ioc.value in self.reputation_db["known_malicious_domains"]:
            ioc.severity = "High"
            ioc.confidence = "High"
            ioc.threat_types.append("Known Malicious Domain")

        # WHOIS information (sample)
        ioc.context["whois"] = {
            "registrar": "Unknown",
            "creation_date": "Unknown",
            "expiration_date": "Unknown"
        }

        # DNS records (sample)
        ioc.context["dns_records"] = {
            "A": [],
            "MX": [],
            "TXT": []
        }

        return ioc

    async def _enrich_hash(self, ioc: IoC) -> IoC:
        """File hash enrichment"""
        # In production, use VirusTotal, MalwareBazaar, etc.

        # Reputation check
        if ioc.value in self.reputation_db["known_malicious_hashes"]:
            ioc.severity = "Critical"
            ioc.confidence = "High"
            ioc.threat_types.append("Known Malware")

        # File information (sample)
        ioc.context["file_info"] = {
            "file_type": "Unknown",
            "file_size": "Unknown",
            "detection_ratio": "0/0"
        }

        return ioc

    async def _enrich_url(self, ioc: IoC) -> IoC:
        """URL enrichment"""
        # In production, use Google Safe Browsing, PhishTank, etc.

        # Extract domain
        import urllib.parse
        parsed = urllib.parse.urlparse(ioc.value)
        domain = parsed.netloc

        # Domain reputation check
        if domain in self.reputation_db["known_malicious_domains"]:
            ioc.severity = "High"
            ioc.confidence = "High"
            ioc.threat_types.append("Malicious URL")

        ioc.context["url_info"] = {
            "domain": domain,
            "path": parsed.path,
            "scheme": parsed.scheme
        }

        return ioc


def correlate_iocs(iocs: List[IoC], time_window_minutes: int = 60) -> Dict:
    """
    IoC Correlation Analysis

    Args:
        iocs: List of IoCs
        time_window_minutes: Time window (minutes)

    Returns:
        Correlation analysis results
    """
    if not iocs:
        return {"clusters": [], "statistics": {}}

    # Statistics by IoC type
    stats = {
        "total_iocs": len(iocs),
        "by_type": {},
        "by_severity": {},
        "unique_sources": set()
    }

    for ioc in iocs:
        # Count by type
        stats["by_type"][ioc.ioc_type] = stats["by_type"].get(ioc.ioc_type, 0) + 1

        # Count by severity
        stats["by_severity"][ioc.severity] = stats["by_severity"].get(ioc.severity, 0) + 1

        # Sources
        stats["unique_sources"].update(ioc.sources)

    stats["unique_sources"] = list(stats["unique_sources"])

    # Clustering (time-based)
    clusters = []
    # TODO: Implement time window-based clustering logic

    return {
        "clusters": clusters,
        "statistics": stats
    }
