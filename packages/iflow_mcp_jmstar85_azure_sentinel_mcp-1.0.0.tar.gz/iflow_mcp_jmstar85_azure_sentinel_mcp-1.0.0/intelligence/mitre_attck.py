"""
MITRE ATT&CK Framework Integration
Tactics, Techniques, and Sub-techniques mapping and analysis
"""

import json
import logging
from typing import Dict, List, Optional, Set
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class MITRETechnique:
    """MITRE ATT&CK technique"""
    technique_id: str
    name: str
    description: str
    tactics: List[str] = field(default_factory=list)
    detection: str = ""
    mitigation: str = ""
    data_sources: List[str] = field(default_factory=list)
    platforms: List[str] = field(default_factory=list)
    kill_chain_phases: List[str] = field(default_factory=list)


@dataclass
class MITRETactic:
    """MITRE ATT&CK tactic"""
    tactic_id: str
    name: str
    description: str
    techniques: List[str] = field(default_factory=list)


class MITREAttackFramework:
    """MITRE ATT&CK framework database"""

    def __init__(self):
        """Initialize MITRE ATT&CK data"""
        self.techniques: Dict[str, MITRETechnique] = {}
        self.tactics: Dict[str, MITRETactic] = {}
        self._initialize_data()

    def _initialize_data(self):
        """Load core MITRE ATT&CK data"""
        # Main tactics (Kill Chain Phases)
        tactics_data = [
            ("TA0001", "Initial Access", "Infiltration attempt stage"),
            ("TA0002", "Execution", "Malicious code execution stage"),
            ("TA0003", "Persistence", "Persistence establishment stage"),
            ("TA0004", "Privilege Escalation", "Privilege escalation stage"),
            ("TA0005", "Defense Evasion", "Defense evasion stage"),
            ("TA0006", "Credential Access", "Credential theft stage"),
            ("TA0007", "Discovery", "Internal information gathering stage"),
            ("TA0008", "Lateral Movement", "Lateral movement stage"),
            ("TA0009", "Collection", "Data collection stage"),
            ("TA0010", "Exfiltration", "Data exfiltration stage"),
            ("TA0011", "Command and Control", "C2 communication stage"),
            ("TA0040", "Impact", "Impact occurrence stage"),
        ]

        for tactic_id, name, desc in tactics_data:
            self.tactics[tactic_id] = MITRETactic(
                tactic_id=tactic_id,
                name=name,
                description=desc
            )

        # Main techniques (in real environment, use MITRE ATT&CK API or JSON file)
        techniques_data = [
            # Initial Access
            ("T1190", "Exploit Public-Facing Application", "TA0001",
             "Exploit public-facing web application vulnerabilities", ["Application Log", "Network Traffic"]),
            ("T1133", "External Remote Services", "TA0001",
             "Exploit external remote services like VPN, RDP", ["Authentication Log"]),
            ("T1566", "Phishing", "TA0001",
             "Initial infiltration via phishing emails", ["Email Gateway", "Office 365 Log"]),

            # Execution
            ("T1059", "Command and Scripting Interpreter", "TA0002",
             "Execute scripts like PowerShell, Bash", ["Process Monitoring", "Command History"]),
            ("T1204", "User Execution", "TA0002",
             "Trick user into executing malicious files", ["Process Monitoring", "File Monitoring"]),

            # Persistence
            ("T1053", "Scheduled Task/Job", "TA0003",
             "Establish persistence via scheduled tasks", ["Windows Event Log 4698", "Sysmon Event 1"]),
            ("T1136", "Create Account", "TA0003",
             "Secure backdoor by creating new account", ["Windows Event Log 4720"]),
            ("T1098", "Account Manipulation", "TA0003",
             "Maintain access by modifying existing accounts", ["Azure AD Audit Log"]),

            # Privilege Escalation
            ("T1078", "Valid Accounts", "TA0004",
             "Use stolen legitimate accounts", ["Authentication Log"]),
            ("T1068", "Exploitation for Privilege Escalation", "TA0004",
             "Escalate privileges by exploiting vulnerabilities", ["System Log", "Process Monitoring"]),

            # Defense Evasion
            ("T1070", "Indicator Removal", "TA0005",
             "Remove traces like log deletion", ["Windows Event Log 1102", "Syslog"]),
            ("T1562", "Impair Defenses", "TA0005",
             "Disable security solutions", ["Windows Event Log", "Defender Log"]),
            ("T1036", "Masquerading", "TA0005",
             "Masquerade as legitimate process", ["Process Monitoring"]),

            # Credential Access
            ("T1110", "Brute Force", "TA0006",
             "Brute force attack", ["Failed Login Attempts", "Azure AD Sign-in Log"]),
            ("T1003", "OS Credential Dumping", "TA0006",
             "Dump credentials from memory/files", ["Sysmon Event 10", "Process Monitoring"]),
            ("T1555", "Credentials from Password Stores", "TA0006",
             "Steal passwords from browser/keychain", ["File Monitoring"]),

            # Discovery
            ("T1087", "Account Discovery", "TA0007",
             "Discover account information", ["PowerShell Log", "Command History"]),
            ("T1083", "File and Directory Discovery", "TA0007",
             "Explore file system", ["Process Monitoring"]),
            ("T1018", "Remote System Discovery", "TA0007",
             "Discover systems in network", ["Network Traffic", "DNS Query"]),

            # Lateral Movement
            ("T1021", "Remote Services", "TA0008",
             "Move via remote services like RDP, SSH", ["Windows Event Log 4624", "Network Traffic"]),
            ("T1080", "Taint Shared Content", "TA0008",
             "Spread through shared folders", ["File Monitoring"]),

            # Collection
            ("T1005", "Data from Local System", "TA0009",
             "Collect data from local system", ["File Access Log"]),
            ("T1114", "Email Collection", "TA0009",
             "Collect email data", ["Office 365 Activity Log"]),

            # Exfiltration
            ("T1041", "Exfiltration Over C2 Channel", "TA0010",
             "Exfiltrate data via C2 channel", ["Network Traffic"]),
            ("T1567", "Exfiltration Over Web Service", "TA0010",
             "Exfiltrate data to cloud service", ["Cloud App Security Log"]),

            # Command and Control
            ("T1071", "Application Layer Protocol", "TA0011",
             "Exploit application protocols like HTTP/DNS", ["Network Traffic", "DNS Log"]),
            ("T1573", "Encrypted Channel", "TA0011",
             "C2 communication via encrypted channel", ["Network Traffic Analysis"]),

            # Impact
            ("T1486", "Data Encrypted for Impact", "TA0040",
             "Ransomware encryption", ["File Monitoring", "Process Monitoring"]),
            ("T1490", "Inhibit System Recovery", "TA0040",
             "Prevent system recovery", ["Windows Event Log", "Backup Log"]),
        ]

        for tech_id, name, tactic_id, desc, data_sources in techniques_data:
            technique = MITRETechnique(
                technique_id=tech_id,
                name=name,
                description=desc,
                tactics=[tactic_id],
                data_sources=data_sources
            )
            self.techniques[tech_id] = technique

            # Link technique to tactic
            if tactic_id in self.tactics:
                self.tactics[tactic_id].techniques.append(tech_id)

        logger.info(f"MITRE ATT&CK initialization complete: {len(self.techniques)} techniques, {len(self.tactics)} tactics")

    def get_technique(self, technique_id: str) -> Optional[MITRETechnique]:
        """Query technique information"""
        return self.techniques.get(technique_id)

    def get_tactic(self, tactic_id: str) -> Optional[MITRETactic]:
        """Query tactic information"""
        return self.tactics.get(tactic_id)

    def get_techniques_by_tactic(self, tactic_id: str) -> List[MITRETechnique]:
        """Query all techniques for specific tactic"""
        tactic = self.tactics.get(tactic_id)
        if not tactic:
            return []
        return [self.techniques[tid] for tid in tactic.techniques if tid in self.techniques]

    def map_alert_to_mitre(self, alert_data: Dict) -> Dict:
        """
        Map Sentinel alert to MITRE ATT&CK

        Args:
            alert_data: Sentinel SecurityAlert data

        Returns:
            Mapped MITRE information
        """
        tactics = alert_data.get("Tactics", []) or []
        techniques = alert_data.get("Techniques", []) or []

        mapped_tactics = []
        mapped_techniques = []

        # Map tactics
        for tactic_name in tactics:
            for tactic_id, tactic in self.tactics.items():
                if tactic.name.lower() in tactic_name.lower():
                    mapped_tactics.append({
                        "id": tactic_id,
                        "name": tactic.name,
                        "description": tactic.description
                    })
                    break

        # Map techniques
        for tech_str in techniques:
            # Extract technique ID (e.g., "T1059.001" or "T1059")
            tech_id = tech_str.split()[0] if " " in tech_str else tech_str
            tech_id = tech_id.split(".")[0]  # Remove sub-technique

            if tech_id in self.techniques:
                tech = self.techniques[tech_id]
                mapped_techniques.append({
                    "id": tech.technique_id,
                    "name": tech.name,
                    "description": tech.description,
                    "data_sources": tech.data_sources,
                    "tactics": tech.tactics
                })

        return {
            "tactics": mapped_tactics,
            "techniques": mapped_techniques,
            "kill_chain_phase": self._get_kill_chain_phase(mapped_tactics)
        }

    def _get_kill_chain_phase(self, tactics: List[Dict]) -> str:
        """
        Estimate Kill Chain phase

        Args:
            tactics: Mapped tactics list

        Returns:
            Kill Chain phase
        """
        if not tactics:
            return "Unknown"

        # Tactic priority (Kill Chain order)
        priority_order = [
            "Initial Access", "Execution", "Persistence",
            "Privilege Escalation", "Defense Evasion", "Credential Access",
            "Discovery", "Lateral Movement", "Collection",
            "Exfiltration", "Command and Control", "Impact"
        ]

        for phase in priority_order:
            for tactic in tactics:
                if phase.lower() in tactic["name"].lower():
                    return phase

        return "Unknown"

    def get_detection_coverage(self, available_data_sources: List[str]) -> Dict:
        """
        Calculate detection coverage based on available data sources

        Args:
            available_data_sources: Currently available data sources list

        Returns:
            Coverage statistics
        """
        total_techniques = len(self.techniques)
        covered_techniques = 0

        for technique in self.techniques.values():
            # Covered if at least one data source matches
            if any(ds in available_data_sources for ds in technique.data_sources):
                covered_techniques += 1

        coverage_pct = (covered_techniques / total_techniques * 100) if total_techniques > 0 else 0

        return {
            "total_techniques": total_techniques,
            "covered_techniques": covered_techniques,
            "coverage_percentage": round(coverage_pct, 2),
            "available_data_sources": available_data_sources
        }

    def suggest_next_techniques(self, observed_techniques: List[str]) -> List[Dict]:
        """
        Suggest next expected techniques based on observed techniques

        Args:
            observed_techniques: Observed technique ID list

        Returns:
            Expected next techniques list
        """
        if not observed_techniques:
            return []

        # Identify current Kill Chain phase
        current_tactics = set()
        for tech_id in observed_techniques:
            tech_id = tech_id.split(".")[0]  # Remove sub-technique
            if tech_id in self.techniques:
                current_tactics.update(self.techniques[tech_id].tactics)

        # Find next phase tactics
        tactic_order = [
            "TA0001", "TA0002", "TA0003", "TA0004", "TA0005", "TA0006",
            "TA0007", "TA0008", "TA0009", "TA0010", "TA0011", "TA0040"
        ]

        next_tactics = []
        max_current_idx = -1

        for tactic_id in current_tactics:
            if tactic_id in tactic_order:
                max_current_idx = max(max_current_idx, tactic_order.index(tactic_id))

        if max_current_idx >= 0 and max_current_idx < len(tactic_order) - 1:
            # Next 2-3 phase tactics
            next_tactics = tactic_order[max_current_idx + 1:max_current_idx + 4]

        # Recommend next phase techniques
        suggestions = []
        for tactic_id in next_tactics:
            tactic = self.tactics.get(tactic_id)
            if tactic:
                for tech_id in tactic.techniques[:3]:  # Top 3
                    if tech_id in self.techniques:
                        tech = self.techniques[tech_id]
                        suggestions.append({
                            "technique_id": tech.technique_id,
                            "name": tech.name,
                            "tactic": tactic.name,
                            "description": tech.description,
                            "likelihood": "High" if tactic_id == next_tactics[0] else "Medium"
                        })

        return suggestions[:5]  # Return top 5


# Global instance (singleton)
_mitre_framework = None


def get_mitre_framework() -> MITREAttackFramework:
    """MITRE ATT&CK framework singleton instance"""
    global _mitre_framework
    if _mitre_framework is None:
        _mitre_framework = MITREAttackFramework()
    return _mitre_framework
