"""
Attack Graph Analysis and Timeline Reconstruction
Attack path visualization through event correlation analysis
"""

import logging
from typing import Dict, List, Optional, Tuple, Set
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from collections import defaultdict

logger = logging.getLogger(__name__)


@dataclass
class AttackNode:
    """Attack graph node"""
    node_id: str
    node_type: str  # alert, entity, technique, asset
    timestamp: Optional[datetime] = None
    properties: Dict = field(default_factory=dict)
    connections: List[str] = field(default_factory=list)


@dataclass
class AttackEdge:
    """Attack graph edge"""
    source_id: str
    target_id: str
    edge_type: str  # caused_by, leads_to, uses, targets
    confidence: float = 0.0
    properties: Dict = field(default_factory=dict)


@dataclass
class AttackPath:
    """Attack path"""
    path_id: str
    nodes: List[AttackNode]
    edges: List[AttackEdge]
    confidence: float
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    severity: str = "Unknown"


class AttackGraphBuilder:
    """Attack graph building and analysis"""

    def __init__(self):
        """Initialize graph builder"""
        self.nodes: Dict[str, AttackNode] = {}
        self.edges: List[AttackEdge] = {}
        self.paths: List[AttackPath] = []

    def add_alert_node(self, alert_data: Dict) -> AttackNode:
        """Add alert as node"""
        node_id = f"alert_{alert_data.get('SystemAlertId', 'unknown')}"

        node = AttackNode(
            node_id=node_id,
            node_type="alert",
            timestamp=alert_data.get("TimeGenerated"),
            properties={
                "name": alert_data.get("AlertName"),
                "severity": alert_data.get("AlertSeverity"),
                "tactics": alert_data.get("Tactics", []),
                "techniques": alert_data.get("Techniques", []),
                "description": alert_data.get("Description", "")
            }
        )

        self.nodes[node_id] = node
        return node

    def add_entity_nodes(self, entities: List[Dict], parent_alert_id: str) -> List[AttackNode]:
        """Add entities as nodes (IP, account, host, etc.)"""
        entity_nodes = []

        for entity in entities:
            entity_type = entity.get("Type", "unknown")
            entity_name = entity.get("Name", entity.get("Address", "unknown"))

            node_id = f"entity_{entity_type}_{entity_name}"

            if node_id not in self.nodes:
                node = AttackNode(
                    node_id=node_id,
                    node_type="entity",
                    properties={
                        "entity_type": entity_type,
                        "name": entity_name,
                        "properties": entity
                    }
                )
                self.nodes[node_id] = node
            else:
                node = self.nodes[node_id]

            # Connect to alert
            self.add_edge(parent_alert_id, node_id, "involves", confidence=0.9)
            entity_nodes.append(node)

        return entity_nodes

    def add_edge(
        self,
        source_id: str,
        target_id: str,
        edge_type: str,
        confidence: float = 0.8,
        **properties
    ):
        """Add edge"""
        edge = AttackEdge(
            source_id=source_id,
            target_id=target_id,
            edge_type=edge_type,
            confidence=confidence,
            properties=properties
        )

        edge_key = f"{source_id}_{target_id}_{edge_type}"
        self.edges[edge_key] = edge

        # Update node connections
        if source_id in self.nodes:
            if target_id not in self.nodes[source_id].connections:
                self.nodes[source_id].connections.append(target_id)

    def build_from_alerts(self, alerts: List[Dict]) -> "AttackGraphBuilder":
        """Build graph from alert list"""
        logger.info(f"Starting attack graph construction: {len(alerts)} alerts")

        # Step 1: Add all alerts as nodes
        for alert in alerts:
            alert_node = self.add_alert_node(alert)

            # Add entities
            entities = alert.get("Entities", [])
            if entities and isinstance(entities, list):
                self.add_entity_nodes(entities, alert_node.node_id)

        # Step 2: Analyze temporal/logical correlations
        self._correlate_temporal_relationships()
        self._correlate_entity_relationships()

        # Step 3: Identify attack paths
        self._identify_attack_paths()

        logger.info(f"Graph construction complete: {len(self.nodes)} nodes, {len(self.edges)} edges")
        return self

    def _correlate_temporal_relationships(self):
        """Analyze temporal correlations"""
        # Time-sorted alert nodes
        alert_nodes = [
            node for node in self.nodes.values()
            if node.node_type == "alert" and node.timestamp
        ]
        alert_nodes.sort(key=lambda x: x.timestamp)

        # Connect consecutive alerts within time window (30 minutes)
        time_window = timedelta(minutes=30)

        for i in range(len(alert_nodes) - 1):
            current = alert_nodes[i]
            next_alert = alert_nodes[i + 1]

            time_diff = next_alert.timestamp - current.timestamp

            if time_diff <= time_window:
                # Connect temporally close alerts
                confidence = 1.0 - (time_diff.total_seconds() / time_window.total_seconds()) * 0.3

                self.add_edge(
                    current.node_id,
                    next_alert.node_id,
                    "precedes",
                    confidence=confidence,
                    time_diff_seconds=time_diff.total_seconds()
                )

    def _correlate_entity_relationships(self):
        """Analyze entity-based correlations"""
        # Connect alerts containing the same entity
        entity_to_alerts = defaultdict(set)

        for edge_key, edge in self.edges.items():
            if edge.edge_type == "involves":
                # Map alerts containing entity
                alert_id = edge.source_id
                entity_id = edge.target_id

                entity_to_alerts[entity_id].add(alert_id)

        # Connect alerts sharing the same entity
        for entity_id, alert_ids in entity_to_alerts.items():
            alert_list = list(alert_ids)
            for i in range(len(alert_list)):
                for j in range(i + 1, len(alert_list)):
                    self.add_edge(
                        alert_list[i],
                        alert_list[j],
                        "shares_entity",
                        confidence=0.7,
                        shared_entity=entity_id
                    )

    def _identify_attack_paths(self):
        """Identify attack paths (DFS-based)"""
        # Find start nodes (Initial Access related alerts)
        start_nodes = []
        for node in self.nodes.values():
            if node.node_type == "alert":
                tactics = node.properties.get("tactics", [])
                if any("InitialAccess" in t or "Initial Access" in t for t in tactics):
                    start_nodes.append(node)

        # If no start nodes, use earliest alert
        if not start_nodes:
            alert_nodes = [n for n in self.nodes.values() if n.node_type == "alert" and n.timestamp]
            if alert_nodes:
                start_nodes = [min(alert_nodes, key=lambda x: x.timestamp)]

        # Explore paths from each start point
        for start_node in start_nodes:
            paths = self._dfs_find_paths(start_node.node_id, visited=set(), max_depth=10)

            for path_nodes in paths:
                if len(path_nodes) > 1:  # Minimum 2 nodes
                    self._create_attack_path(path_nodes)

    def _dfs_find_paths(
        self,
        node_id: str,
        visited: Set[str],
        max_depth: int,
        current_depth: int = 0
    ) -> List[List[str]]:
        """Path exploration with DFS"""
        if current_depth >= max_depth or node_id in visited:
            return [[node_id]]

        visited = visited.copy()
        visited.add(node_id)

        node = self.nodes.get(node_id)
        if not node or not node.connections:
            return [[node_id]]

        all_paths = []
        for next_id in node.connections:
            sub_paths = self._dfs_find_paths(next_id, visited, max_depth, current_depth + 1)
            for sub_path in sub_paths:
                all_paths.append([node_id] + sub_path)

        return all_paths if all_paths else [[node_id]]

    def _create_attack_path(self, node_ids: List[str]):
        """Create attack path from node ID list"""
        nodes = [self.nodes[nid] for nid in node_ids if nid in self.nodes]

        if not nodes:
            return

        # Collect path edges
        path_edges = []
        for i in range(len(node_ids) - 1):
            source = node_ids[i]
            target = node_ids[i + 1]

            # Find edge
            for edge_key, edge in self.edges.items():
                if edge.source_id == source and edge.target_id == target:
                    path_edges.append(edge)
                    break

        # Calculate confidence (average of edge confidences)
        confidence = sum(e.confidence for e in path_edges) / len(path_edges) if path_edges else 0.5

        # Nodes with timestamps
        timestamped_nodes = [n for n in nodes if n.timestamp]

        # Severity (use highest severity)
        severity_order = {"Critical": 4, "High": 3, "Medium": 2, "Low": 1, "Informational": 0}
        max_severity = "Unknown"
        max_severity_score = -1

        for node in nodes:
            if node.node_type == "alert":
                sev = node.properties.get("severity", "Unknown")
                score = severity_order.get(sev, -1)
                if score > max_severity_score:
                    max_severity_score = score
                    max_severity = sev

        path = AttackPath(
            path_id=f"path_{len(self.paths)}",
            nodes=nodes,
            edges=path_edges,
            confidence=confidence,
            start_time=min(n.timestamp for n in timestamped_nodes) if timestamped_nodes else None,
            end_time=max(n.timestamp for n in timestamped_nodes) if timestamped_nodes else None,
            severity=max_severity
        )

        self.paths.append(path)

    def get_attack_timeline(self) -> List[Dict]:
        """Generate attack timeline (chronological events)"""
        events = []

        for node in self.nodes.values():
            if node.node_type == "alert" and node.timestamp:
                events.append({
                    "timestamp": node.timestamp.isoformat(),
                    "event_type": "alert",
                    "name": node.properties.get("name"),
                    "severity": node.properties.get("severity"),
                    "tactics": node.properties.get("tactics", []),
                    "techniques": node.properties.get("techniques", [])
                })

        # Sort chronologically
        events.sort(key=lambda x: x["timestamp"])

        return events

    def get_critical_paths(self, top_k: int = 3) -> List[Dict]:
        """
        Extract critical attack paths

        Args:
            top_k: Number of paths to return

        Returns:
            List of path information
        """
        # Sort based on severity and confidence
        severity_scores = {"Critical": 4, "High": 3, "Medium": 2, "Low": 1, "Unknown": 0}

        scored_paths = []
        for path in self.paths:
            severity_score = severity_scores.get(path.severity, 0)
            composite_score = (severity_score * 0.6) + (path.confidence * 0.4)

            scored_paths.append((path, composite_score))

        scored_paths.sort(key=lambda x: x[1], reverse=True)

        # Format top k paths
        critical_paths = []
        for path, score in scored_paths[:top_k]:
            # Summarize path nodes
            alert_nodes = [n for n in path.nodes if n.node_type == "alert"]
            entity_nodes = [n for n in path.nodes if n.node_type == "entity"]

            critical_paths.append({
                "path_id": path.path_id,
                "severity": path.severity,
                "confidence": round(path.confidence, 3),
                "score": round(score, 3),
                "start_time": path.start_time.isoformat() if path.start_time else None,
                "end_time": path.end_time.isoformat() if path.end_time else None,
                "duration_minutes": (path.end_time - path.start_time).total_seconds() / 60
                    if (path.start_time and path.end_time) else None,
                "alert_count": len(alert_nodes),
                "entity_count": len(entity_nodes),
                "techniques": list(set(
                    tech
                    for node in alert_nodes
                    for tech in node.properties.get("techniques", [])
                ))
            })

        return critical_paths

    def to_dict(self) -> Dict:
        """Convert graph to dictionary (for visualization)"""
        return {
            "nodes": [
                {
                    "id": node.node_id,
                    "type": node.node_type,
                    "timestamp": node.timestamp.isoformat() if node.timestamp else None,
                    "properties": node.properties
                }
                for node in self.nodes.values()
            ],
            "edges": [
                {
                    "source": edge.source_id,
                    "target": edge.target_id,
                    "type": edge.edge_type,
                    "confidence": edge.confidence,
                    "properties": edge.properties
                }
                for edge in self.edges.values()
            ],
            "paths": [
                {
                    "path_id": path.path_id,
                    "node_ids": [n.node_id for n in path.nodes],
                    "confidence": path.confidence,
                    "severity": path.severity
                }
                for path in self.paths
            ]
        }


def reconstruct_attack_timeline(alerts: List[Dict]) -> Dict:
    """
    Reconstruct attack timeline from alert list

    Args:
        alerts: List of Sentinel SecurityAlerts

    Returns:
        Timeline and graph analysis results
    """
    builder = AttackGraphBuilder()
    builder.build_from_alerts(alerts)

    timeline = builder.get_attack_timeline()
    critical_paths = builder.get_critical_paths(top_k=3)

    return {
        "timeline": timeline,
        "critical_paths": critical_paths,
        "graph": builder.to_dict(),
        "statistics": {
            "total_alerts": len([n for n in builder.nodes.values() if n.node_type == "alert"]),
            "total_entities": len([n for n in builder.nodes.values() if n.node_type == "entity"]),
            "total_paths": len(builder.paths),
            "time_span_minutes": (
                (max(n.timestamp for n in builder.nodes.values() if n.timestamp and n.node_type == "alert") -
                 min(n.timestamp for n in builder.nodes.values() if n.timestamp and n.node_type == "alert")).total_seconds() / 60
            ) if any(n.timestamp for n in builder.nodes.values()) else 0
        }
    }
