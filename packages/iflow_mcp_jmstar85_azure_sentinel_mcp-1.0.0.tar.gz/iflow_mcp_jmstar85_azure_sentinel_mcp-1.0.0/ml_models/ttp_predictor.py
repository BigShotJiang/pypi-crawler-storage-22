"""
TTP (Tactics, Techniques, Procedures) Prediction Model
Machine learning-based prediction of next attack techniques
"""

import logging
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from collections import defaultdict, Counter
import json

logger = logging.getLogger(__name__)


@dataclass
class TTPSequence:
    """TTP Sequence"""
    techniques: List[str]
    tactics: List[str]
    timestamps: List[str]
    confidence: float = 0.0


class TTPPredictor:
    """
    TTP Prediction Engine

    In production, use deep learning models like LSTM, Transformer
    Here, using pattern-based heuristic approach
    """

    def __init__(self):
        """Initialize prediction model"""
        self.transition_matrix = self._build_transition_matrix()
        self.common_sequences = self._load_common_sequences()

    def _build_transition_matrix(self) -> Dict[str, Dict[str, float]]:
        """
        Build transition matrix

        In production, train from historical incident data
        Here, using MITRE ATT&CK statistics-based heuristics
        """
        # Tactic -> Next Tactic transition probabilities
        # (In production, learn from historical data)
        tactic_transitions = {
            "TA0001": {  # Initial Access
                "TA0002": 0.85,  # Execution
                "TA0007": 0.10,  # Discovery
                "TA0003": 0.05   # Persistence
            },
            "TA0002": {  # Execution
                "TA0003": 0.60,  # Persistence
                "TA0004": 0.20,  # Privilege Escalation
                "TA0007": 0.15,  # Discovery
                "TA0005": 0.05   # Defense Evasion
            },
            "TA0003": {  # Persistence
                "TA0004": 0.50,  # Privilege Escalation
                "TA0005": 0.30,  # Defense Evasion
                "TA0007": 0.20   # Discovery
            },
            "TA0004": {  # Privilege Escalation
                "TA0006": 0.45,  # Credential Access
                "TA0007": 0.35,  # Discovery
                "TA0005": 0.20   # Defense Evasion
            },
            "TA0005": {  # Defense Evasion
                "TA0006": 0.40,  # Credential Access
                "TA0007": 0.35,  # Discovery
                "TA0008": 0.25   # Lateral Movement
            },
            "TA0006": {  # Credential Access
                "TA0007": 0.50,  # Discovery
                "TA0008": 0.40,  # Lateral Movement
                "TA0009": 0.10   # Collection
            },
            "TA0007": {  # Discovery
                "TA0008": 0.50,  # Lateral Movement
                "TA0009": 0.30,  # Collection
                "TA0006": 0.20   # Credential Access
            },
            "TA0008": {  # Lateral Movement
                "TA0009": 0.60,  # Collection
                "TA0007": 0.25,  # Discovery
                "TA0006": 0.15   # Credential Access
            },
            "TA0009": {  # Collection
                "TA0010": 0.70,  # Exfiltration
                "TA0011": 0.20,  # Command and Control
                "TA0040": 0.10   # Impact
            },
            "TA0010": {  # Exfiltration
                "TA0040": 0.60,  # Impact
                "TA0011": 0.40   # Command and Control
            },
            "TA0011": {  # Command and Control
                "TA0009": 0.50,  # Collection
                "TA0010": 0.30,  # Exfiltration
                "TA0040": 0.20   # Impact
            },
            "TA0040": {  # Impact (terminal)
                "TA0040": 1.0
            }
        }

        return tactic_transitions

    def _load_common_sequences(self) -> List[TTPSequence]:
        """
        Load common attack sequence patterns

        In production, use APT group-specific pattern database
        """
        sequences = [
            # APT-style attack
            TTPSequence(
                techniques=["T1566", "T1059", "T1053", "T1078", "T1083", "T1021", "T1005", "T1041"],
                tactics=["TA0001", "TA0002", "TA0003", "TA0004", "TA0007", "TA0008", "TA0009", "TA0010"],
                timestamps=[],
                confidence=0.85
            ),
            # Ransomware attack
            TTPSequence(
                techniques=["T1190", "T1059", "T1070", "T1083", "T1486", "T1490"],
                tactics=["TA0001", "TA0002", "TA0005", "TA0007", "TA0040", "TA0040"],
                timestamps=[],
                confidence=0.90
            ),
            # Credential stuffing attack
            TTPSequence(
                techniques=["T1110", "T1078", "T1087", "T1003", "T1021", "T1114"],
                tactics=["TA0006", "TA0004", "TA0007", "TA0006", "TA0008", "TA0009"],
                timestamps=[],
                confidence=0.75
            ),
        ]

        return sequences

    def predict_next_tactics(
        self,
        observed_tactics: List[str],
        top_k: int = 3
    ) -> List[Dict]:
        """
        Predict next tactics based on observed tactics

        Args:
            observed_tactics: List of observed tactic IDs
            top_k: Number of top predictions to return

        Returns:
            List of predicted tactics (with probabilities)
        """
        if not observed_tactics:
            # Predict initial infiltration
            return [{
                "tactic_id": "TA0001",
                "name": "Initial Access",
                "probability": 0.85,
                "rationale": "Attack starting phase"
            }]

        # Most recent tactic
        last_tactic = observed_tactics[-1]

        # Query transition probabilities
        if last_tactic not in self.transition_matrix:
            return []

        next_tactics = self.transition_matrix[last_tactic]

        # Sort top k
        sorted_tactics = sorted(
            next_tactics.items(),
            key=lambda x: x[1],
            reverse=True
        )[:top_k]

        # Tactic name mapping (simplified)
        tactic_names = {
            "TA0001": "Initial Access",
            "TA0002": "Execution",
            "TA0003": "Persistence",
            "TA0004": "Privilege Escalation",
            "TA0005": "Defense Evasion",
            "TA0006": "Credential Access",
            "TA0007": "Discovery",
            "TA0008": "Lateral Movement",
            "TA0009": "Collection",
            "TA0010": "Exfiltration",
            "TA0011": "Command and Control",
            "TA0040": "Impact"
        }

        predictions = []
        for tactic_id, prob in sorted_tactics:
            predictions.append({
                "tactic_id": tactic_id,
                "name": tactic_names.get(tactic_id, "Unknown"),
                "probability": round(prob, 3),
                "rationale": self._get_prediction_rationale(last_tactic, tactic_id)
            })

        return predictions

    def predict_next_techniques(
        self,
        observed_techniques: List[str],
        next_tactic: Optional[str] = None,
        top_k: int = 5
    ) -> List[Dict]:
        """
        Predict next techniques

        Args:
            observed_techniques: List of observed techniques
            next_tactic: Expected next tactic (optional)
            top_k: Number of top predictions to return

        Returns:
            List of predicted techniques
        """
        # Common sequence matching
        matched_sequences = []
        for seq in self.common_sequences:
            match_count = sum(1 for tech in observed_techniques if tech in seq.techniques)
            if match_count > 0:
                match_score = match_count / len(seq.techniques)
                matched_sequences.append((seq, match_score))

        # Select most similar sequence
        if matched_sequences:
            matched_sequences.sort(key=lambda x: x[1], reverse=True)
            best_sequence = matched_sequences[0][0]

            # Find next technique in sequence
            predictions = []
            for tech in best_sequence.techniques:
                if tech not in observed_techniques:
                    predictions.append({
                        "technique_id": tech,
                        "confidence": best_sequence.confidence,
                        "sequence_match": matched_sequences[0][1],
                        "rationale": "Prediction based on similar attack pattern"
                    })

                    if len(predictions) >= top_k:
                        break

            return predictions

        # Default heuristics
        return self._fallback_technique_prediction(observed_techniques, next_tactic, top_k)

    def _fallback_technique_prediction(
        self,
        observed_techniques: List[str],
        next_tactic: Optional[str],
        top_k: int
    ) -> List[Dict]:
        """Fallback technique prediction (heuristic)"""
        # In production, use statistical models
        # Here, using simple rule-based approach

        common_next_techniques = {
            "TA0001": ["T1566", "T1190", "T1133"],  # Initial Access
            "TA0002": ["T1059", "T1204", "T1106"],  # Execution
            "TA0003": ["T1053", "T1136", "T1098"],  # Persistence
            "TA0004": ["T1078", "T1068", "T1134"],  # Privilege Escalation
            "TA0005": ["T1070", "T1562", "T1036"],  # Defense Evasion
            "TA0006": ["T1110", "T1003", "T1555"],  # Credential Access
            "TA0007": ["T1087", "T1083", "T1018"],  # Discovery
            "TA0008": ["T1021", "T1080", "T1091"],  # Lateral Movement
            "TA0009": ["T1005", "T1114", "T1113"],  # Collection
            "TA0010": ["T1041", "T1567", "T1048"],  # Exfiltration
            "TA0011": ["T1071", "T1573", "T1090"],  # Command and Control
            "TA0040": ["T1486", "T1490", "T1485"]   # Impact
        }

        if next_tactic and next_tactic in common_next_techniques:
            techniques = common_next_techniques[next_tactic][:top_k]
            return [{
                "technique_id": tech,
                "confidence": 0.6,
                "rationale": f"Common {next_tactic} technique"
            } for tech in techniques]

        return []

    def _get_prediction_rationale(self, from_tactic: str, to_tactic: str) -> str:
        """Prediction rationale explanation"""
        rationales = {
            ("TA0001", "TA0002"): "Transition to code execution after initial infiltration",
            ("TA0002", "TA0003"): "Attempting to establish persistence after execution",
            ("TA0003", "TA0004"): "Attempting privilege escalation after establishing persistence",
            ("TA0004", "TA0006"): "Attempting credential theft after privilege escalation",
            ("TA0006", "TA0007"): "Internal reconnaissance after obtaining credentials",
            ("TA0007", "TA0008"): "Starting lateral movement after reconnaissance",
            ("TA0008", "TA0009"): "Target data collection after lateral movement",
            ("TA0009", "TA0010"): "Attempting exfiltration after data collection",
            ("TA0010", "TA0040"): "Trace removal or destruction after data exfiltration",
        }

        return rationales.get((from_tactic, to_tactic), "Based on Kill Chain progression pattern")

    def calculate_attack_likelihood(
        self,
        observed_tactics: List[str],
        observed_techniques: List[str],
        time_elapsed_minutes: int
    ) -> Dict:
        """
        Calculate attack progression likelihood

        Args:
            observed_tactics: Observed tactics
            observed_techniques: Observed techniques
            time_elapsed_minutes: Elapsed time (minutes)

        Returns:
            Likelihood analysis results
        """
        # Kill Chain progress
        total_phases = 12
        current_phase = len(set(observed_tactics))
        progress_pct = (current_phase / total_phases) * 100

        # Speed analysis (techniques per minute)
        techniques_per_minute = len(observed_techniques) / max(time_elapsed_minutes, 1)

        # Risk calculation
        if progress_pct > 70:
            threat_level = "Critical"
            urgency = "Immediate response required"
        elif progress_pct > 50:
            threat_level = "High"
            urgency = "Rapid response required"
        elif progress_pct > 30:
            threat_level = "Medium"
            urgency = "Monitoring and investigation"
        else:
            threat_level = "Low"
            urgency = "Continue observation"

        # Predict next phase
        next_likely_phase = "Unknown"
        if current_phase < total_phases:
            next_tactics = self.predict_next_tactics(observed_tactics, top_k=1)
            if next_tactics:
                next_likely_phase = next_tactics[0]["name"]

        return {
            "threat_level": threat_level,
            "urgency": urgency,
            "kill_chain_progress_pct": round(progress_pct, 1),
            "current_phase": current_phase,
            "total_phases": total_phases,
            "attack_velocity": round(techniques_per_minute, 3),
            "next_likely_phase": next_likely_phase,
            "estimated_time_to_impact_minutes": self._estimate_time_to_impact(
                current_phase, techniques_per_minute
            )
        }

    def _estimate_time_to_impact(
        self,
        current_phase: int,
        velocity: float
    ) -> Optional[int]:
        """Estimated time to Impact phase (minutes)"""
        if current_phase >= 11:  # Already at Impact
            return 0

        remaining_phases = 12 - current_phase

        if velocity > 0:
            # Simple linear estimation
            estimated_minutes = int(remaining_phases / velocity)
            return estimated_minutes

        return None


# Global instance
_ttp_predictor = None


def get_ttp_predictor() -> TTPPredictor:
    """TTP predictor singleton"""
    global _ttp_predictor
    if _ttp_predictor is None:
        _ttp_predictor = TTPPredictor()
    return _ttp_predictor
