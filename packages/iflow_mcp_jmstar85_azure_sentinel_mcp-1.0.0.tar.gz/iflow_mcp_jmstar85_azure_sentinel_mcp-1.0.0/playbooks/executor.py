"""
Playbook execution engine
Response action automation and approval workflow management
"""

import logging
from typing import Dict, List, Optional
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

logger = logging.getLogger(__name__)


class ActionStatus(Enum):
    """Action status"""
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXECUTING = "executing"
    COMPLETED = "completed"
    FAILED = "failed"


class ActionType(Enum):
    """Action type"""
    ISOLATE_HOST = "isolate_host"
    BLOCK_IP = "block_ip"
    DISABLE_ACCOUNT = "disable_account"
    RESET_PASSWORD = "reset_password"
    QUARANTINE_FILE = "quarantine_file"
    RUN_SCRIPT = "run_script"
    NOTIFY = "notify"
    CREATE_TICKET = "create_ticket"


@dataclass
class ResponseAction:
    """Response action"""
    action_id: str
    action_type: ActionType
    target: str  # Target (host, IP, account, etc.)
    parameters: Dict = field(default_factory=dict)
    status: ActionStatus = ActionStatus.PENDING
    requires_approval: bool = True
    approved_by: Optional[str] = None
    executed_by: Optional[str] = None
    created_at: Optional[datetime] = None
    executed_at: Optional[datetime] = None
    result: Optional[Dict] = None
    error: Optional[str] = None


@dataclass
class ResponsePlaybook:
    """Response playbook"""
    playbook_id: str
    name: str
    description: str
    trigger_conditions: Dict
    actions: List[ResponseAction] = field(default_factory=list)
    execution_mode: str = "manual"  # manual, semi_auto, auto
    created_at: Optional[datetime] = None
    last_executed: Optional[datetime] = None


class PlaybookExecutor:
    """Playbook execution engine"""

    def __init__(self):
        """Initialize execution engine"""
        self.playbooks: Dict[str, ResponsePlaybook] = {}
        self.action_queue: List[ResponseAction] = []
        self._load_default_playbooks()

    def _load_default_playbooks(self):
        """Load default playbooks"""

        # 1. 랜섬웨어 Response playbook
        ransomware_playbook = ResponsePlaybook(
            playbook_id="pb_ransomware_001",
            name="Ransomware Detection Response",
            description="Automated response when ransomware attack detected",
            trigger_conditions={
                "alert_name_contains": ["ransomware", "encryption"],
                "severity": ["Critical", "High"],
                "techniques": ["T1486", "T1490"]
            },
            actions=[
                ResponseAction(
                    action_id="act_001",
                    action_type=ActionType.ISOLATE_HOST,
                    target="affected_host",
                    requires_approval=False,  # Emergency - Auto-approved
                    parameters={"reason": "Ransomware detected"}
                ),
                ResponseAction(
                    action_id="act_002",
                    action_type=ActionType.DISABLE_ACCOUNT,
                    target="affected_account",
                    requires_approval=True,
                    parameters={"reason": "Potential compromise"}
                ),
                ResponseAction(
                    action_id="act_003",
                    action_type=ActionType.CREATE_TICKET,
                    target="soc_team",
                    requires_approval=False,
                    parameters={
                        "priority": "Critical",
                        "category": "Security Incident"
                    }
                ),
                ResponseAction(
                    action_id="act_004",
                    action_type=ActionType.NOTIFY,
                    target="security_team",
                    requires_approval=False,
                    parameters={
                        "channels": ["email", "teams", "sms"],
                        "message": "Critical: Ransomware activity detected"
                    }
                )
            ],
            execution_mode="semi_auto"
        )

        # 2. 크리덴셜 도용 Response playbook
        credential_theft_playbook = ResponsePlaybook(
            playbook_id="pb_credential_001",
            name="Credential Theft Response",
            description="Response when credential theft attempt detected",
            trigger_conditions={
                "tactics": ["TA0006"],  # Credential Access
                "techniques": ["T1110", "T1003", "T1555"],
                "severity": ["High", "Critical"]
            },
            actions=[
                ResponseAction(
                    action_id="act_011",
                    action_type=ActionType.RESET_PASSWORD,
                    target="affected_accounts",
                    requires_approval=True,
                    parameters={"force_mfa": True}
                ),
                ResponseAction(
                    action_id="act_012",
                    action_type=ActionType.BLOCK_IP,
                    target="source_ips",
                    requires_approval=False,
                    parameters={"duration_hours": 24}
                ),
                ResponseAction(
                    action_id="act_013",
                    action_type=ActionType.NOTIFY,
                    target="affected_users",
                    requires_approval=False,
                    parameters={
                        "message": "Suspicious login activity detected - password reset required"
                    }
                )
            ],
            execution_mode="manual"
        )

        # 3. Malicious IP Blocking 플레이북
        malicious_ip_playbook = ResponsePlaybook(
            playbook_id="pb_network_001",
            name="Malicious IP Blocking",
            description="Block known malicious IP communication when detected",
            trigger_conditions={
                "ioc_type": ["ip"],
                "threat_confidence": ["High"],
                "severity": ["High", "Critical"]
            },
            actions=[
                ResponseAction(
                    action_id="act_021",
                    action_type=ActionType.BLOCK_IP,
                    target="malicious_ips",
                    requires_approval=False,  # Auto-block
                    parameters={"scope": "firewall", "duration_hours": 72}
                ),
                ResponseAction(
                    action_id="act_022",
                    action_type=ActionType.CREATE_TICKET,
                    target="network_team",
                    requires_approval=False,
                    parameters={
                        "priority": "High",
                        "description": "Malicious IP communication blocked"
                    }
                )
            ],
            execution_mode="auto"
        )

        self.playbooks = {
            ransomware_playbook.playbook_id: ransomware_playbook,
            credential_theft_playbook.playbook_id: credential_theft_playbook,
            malicious_ip_playbook.playbook_id: malicious_ip_playbook
        }

        logger.info(f"✅ {len(self.playbooks)} playbooks loaded")

    def match_playbook(self, incident_data: Dict) -> List[ResponsePlaybook]:
        """
        Find matching playbook for incident

        Args:
            incident_data: Incident/alert data

        Returns:
            List of matched playbooks
        """
        matched = []

        for playbook in self.playbooks.values():
            if self._check_trigger_conditions(incident_data, playbook.trigger_conditions):
                matched.append(playbook)

        return matched

    def _check_trigger_conditions(self, data: Dict, conditions: Dict) -> bool:
        """Check trigger conditions"""
        # Alert name condition
        if "alert_name_contains" in conditions:
            alert_name = data.get("alert_name", "").lower()
            if not any(keyword.lower() in alert_name for keyword in conditions["alert_name_contains"]):
                return False

        # Severity condition
        if "severity" in conditions:
            severity = data.get("severity", "")
            if severity not in conditions["severity"]:
                return False

        # Technique condition
        if "techniques" in conditions:
            techniques = data.get("techniques", [])
            if not any(tech in techniques for tech in conditions["techniques"]):
                return False

        # Tactic condition
        if "tactics" in conditions:
            tactics = data.get("tactics", [])
            if not any(tactic in tactics for tactic in conditions["tactics"]):
                return False

        # IoC 타입 조건
        if "ioc_type" in conditions:
            ioc_type = data.get("ioc_type", "")
            if ioc_type not in conditions["ioc_type"]:
                return False

        return True

    def create_response_plan(
        self,
        playbook_id: str,
        incident_data: Dict,
        auto_approve_non_critical: bool = False
    ) -> Dict:
        """
        Generate response plan

        Args:
            playbook_id: 플레이북 ID
            incident_data: Incident data
            auto_approve_non_critical: Auto-approve non-critical actions

        Returns:
            Response plan
        """
        playbook = self.playbooks.get(playbook_id)
        if not playbook:
            return {"error": f"Playbook {playbook_id} not found"}

        # Instantiate actions
        plan_actions = []
        for template_action in playbook.actions:
            action = ResponseAction(
                action_id=f"{template_action.action_id}_{datetime.utcnow().timestamp()}",
                action_type=template_action.action_type,
                target=self._resolve_target(template_action.target, incident_data),
                parameters=template_action.parameters.copy(),
                requires_approval=template_action.requires_approval,
                created_at=datetime.utcnow()
            )

            # Auto-approval logic
            if auto_approve_non_critical and not template_action.requires_approval:
                action.status = ActionStatus.APPROVED
                action.approved_by = "system_auto"

            plan_actions.append(action)

        return {
            "playbook_id": playbook_id,
            "playbook_name": playbook.name,
            "execution_mode": playbook.execution_mode,
            "actions": [self._action_to_dict(a) for a in plan_actions],
            "total_actions": len(plan_actions),
            "requires_approval_count": sum(1 for a in plan_actions if a.requires_approval),
            "created_at": datetime.utcnow().isoformat()
        }

    def _resolve_target(self, target_template: str, incident_data: Dict) -> str:
        """Resolve target template"""
        # In production, complex variable substitution logic
        target_map = {
            "affected_host": incident_data.get("host", "unknown"),
            "affected_account": incident_data.get("account", "unknown"),
            "source_ips": str(incident_data.get("source_ip", [])),
            "malicious_ips": str(incident_data.get("malicious_ips", [])),
            "affected_accounts": str(incident_data.get("accounts", [])),
            "affected_users": str(incident_data.get("users", [])),
            "soc_team": "SOC",
            "security_team": "Security Operations",
            "network_team": "Network Operations"
        }

        return target_map.get(target_template, target_template)

    def approve_action(self, action_id: str, approver: str) -> Dict:
        """
        Action approval

        Args:
            action_id: 액션 ID
            approver: Approver

        Returns:
            Approval result
        """
        # 실제로는 데이터베이스에서 액션 조회
        return {
            "action_id": action_id,
            "status": "approved",
            "approved_by": approver,
            "approved_at": datetime.utcnow().isoformat()
        }

    def execute_action(self, action: ResponseAction) -> Dict:
        """
        Execute action (simulation)

        Args:
            action: Action to execute

        Returns:
            Execution result
        """
        if action.status != ActionStatus.APPROVED and action.requires_approval:
            return {
                "success": False,
                "error": "Action requires approval"
            }

        action.status = ActionStatus.EXECUTING
        action.executed_at = datetime.utcnow()

        # In production, call Azure Logic Apps, Playbooks API
        # Here, simulation

        logger.info(f"🔧 Executing: {action.action_type.value} on {action.target}")

        try:
            if action.action_type == ActionType.ISOLATE_HOST:
                result = self._simulate_host_isolation(action.target)
            elif action.action_type == ActionType.BLOCK_IP:
                result = self._simulate_ip_block(action.target)
            elif action.action_type == ActionType.DISABLE_ACCOUNT:
                result = self._simulate_account_disable(action.target)
            elif action.action_type == ActionType.RESET_PASSWORD:
                result = self._simulate_password_reset(action.target)
            elif action.action_type == ActionType.NOTIFY:
                result = self._simulate_notification(action.target, action.parameters)
            elif action.action_type == ActionType.CREATE_TICKET:
                result = self._simulate_ticket_creation(action.target, action.parameters)
            else:
                result = {"message": "Action type not implemented"}

            action.status = ActionStatus.COMPLETED
            action.result = result

            return {
                "success": True,
                "action_id": action.action_id,
                "action_type": action.action_type.value,
                "target": action.target,
                "result": result,
                "executed_at": action.executed_at.isoformat()
            }

        except Exception as e:
            action.status = ActionStatus.FAILED
            action.error = str(e)
            logger.error(f"❌ Action execution failed: {e}")

            return {
                "success": False,
                "action_id": action.action_id,
                "error": str(e)
            }

    def _simulate_host_isolation(self, target: str) -> Dict:
        """Host isolation simulation"""
        return {
            "action": "host_isolation",
            "target_host": target,
            "status": "isolated",
            "message": f"Host {target} has been isolated from network"
        }

    def _simulate_ip_block(self, target: str) -> Dict:
        """IP blocking simulation"""
        return {
            "action": "ip_block",
            "blocked_ips": target,
            "status": "blocked",
            "message": f"IP(s) {target} blocked in firewall"
        }

    def _simulate_account_disable(self, target: str) -> Dict:
        """Account disable simulation"""
        return {
            "action": "account_disable",
            "target_account": target,
            "status": "disabled",
            "message": f"Account {target} has been disabled"
        }

    def _simulate_password_reset(self, target: str) -> Dict:
        """Password reset simulation"""
        return {
            "action": "password_reset",
            "target_accounts": target,
            "status": "reset_required",
            "message": f"Password reset required for {target}"
        }

    def _simulate_notification(self, target: str, parameters: Dict) -> Dict:
        """Notification sending simulation"""
        return {
            "action": "notification",
            "recipients": target,
            "channels": parameters.get("channels", ["email"]),
            "message": parameters.get("message", "Security alert"),
            "status": "sent"
        }

    def _simulate_ticket_creation(self, target: str, parameters: Dict) -> Dict:
        """Ticket creation simulation"""
        ticket_id = f"INC-{datetime.utcnow().timestamp()}"
        return {
            "action": "ticket_creation",
            "ticket_id": ticket_id,
            "assigned_to": target,
            "priority": parameters.get("priority", "Medium"),
            "status": "created"
        }

    def _action_to_dict(self, action: ResponseAction) -> Dict:
        """Convert action to dictionary"""
        return {
            "action_id": action.action_id,
            "action_type": action.action_type.value,
            "target": action.target,
            "parameters": action.parameters,
            "status": action.status.value,
            "requires_approval": action.requires_approval,
            "approved_by": action.approved_by,
            "executed_at": action.executed_at.isoformat() if action.executed_at else None,
            "result": action.result,
            "error": action.error
        }

    def get_all_playbooks(self) -> List[Dict]:
        """Query all playbooks"""
        return [
            {
                "playbook_id": pb.playbook_id,
                "name": pb.name,
                "description": pb.description,
                "execution_mode": pb.execution_mode,
                "action_count": len(pb.actions),
                "trigger_conditions": pb.trigger_conditions
            }
            for pb in self.playbooks.values()
        ]


# 글로벌 인스턴스
_executor = None


def get_playbook_executor() -> PlaybookExecutor:
    """Playbook executor singleton"""
    global _executor
    if _executor is None:
        _executor = PlaybookExecutor()
    return _executor
