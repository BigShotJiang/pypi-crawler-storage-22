#!/usr/bin/env python3
"""
Azure Sentinel MCP Server - Fixed Version
KQL query and field name corrections
Added TEST_MODE for local testing without Azure dependencies
"""

import os
import sys
import logging
from typing import Optional
from datetime import datetime, timedelta
import asyncio

# Configure logging to stderr
logging.basicConfig(
    level=logging.WARNING,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    stream=sys.stderr
)
logger = logging.getLogger(__name__)

# Test mode - skip Azure dependencies for local testing
TEST_MODE = os.getenv("TEST_MODE", "false").lower() == "true"

from mcp.server.fastmcp import FastMCP

# Only import Azure modules in non-test mode
if not TEST_MODE:
    from azure.identity import DefaultAzureCredential
    from azure.monitor.query import LogsQueryClient, LogsQueryStatus
    from azure.core.exceptions import HttpResponseError

# Create MCP server
mcp = FastMCP("Azure Sentinel MCP")

# Load Azure settings from environment variables
AZURE_SUBSCRIPTION_ID = os.getenv("AZURE_SUBSCRIPTION_ID", "")
AZURE_RESOURCE_GROUP = os.getenv("AZURE_RESOURCE_GROUP", "")
AZURE_WORKSPACE_NAME = os.getenv("AZURE_WORKSPACE_NAME", "")
AZURE_WORKSPACE_ID = os.getenv("AZURE_WORKSPACE_ID", "")

# Initialize Azure clients (lazy initialization)
_credential = None
_logs_client = None

if not TEST_MODE:
    def get_credential():
        """Get Azure credentials"""
        global _credential
        if _credential is None:
            _credential = DefaultAzureCredential()
        return _credential

    def get_logs_client():
        """Get Log Analytics client"""
        global _logs_client
        if _logs_client is None:
            _logs_client = LogsQueryClient(get_credential())
        return _logs_client

def parse_timespan(timespan_str: str) -> timedelta:
    """Convert timespan string to timedelta"""
    import re
    match = re.match(r'(\d+)([dhm])', timespan_str.lower())
    if not match:
        return timedelta(days=1)
    
    value, unit = match.groups()
    value = int(value)
    
    if unit == 'd':
        return timedelta(days=value)
    elif unit == 'h':
        return timedelta(hours=value)
    elif unit == 'm':
        return timedelta(minutes=value)
    return timedelta(days=1)

async def run_kql_query(query: str, timespan: str = "7d"):
    """Execute KQL query (improved error handling)"""
    # Test mode: return mock data
    if TEST_MODE:
        return {
            "success": True,
            "data": [],
            "row_count": 0
        }
    
    try:
        client = get_logs_client()
        timespan_delta = parse_timespan(timespan)
        
        logger.info(f"Executing query: {query[:100]}...")

        # Execute synchronous function asynchronously
        loop = asyncio.get_event_loop()
        response = await loop.run_in_executor(
            None,
            lambda: client.query_workspace(
                workspace_id=AZURE_WORKSPACE_ID,
                query=query,
                timespan=timespan_delta
            )
        )
        
        if response.status == LogsQueryStatus.SUCCESS:
            results = []
            if response.tables:
                table = response.tables[0]

                # Handle columns - they might be strings or objects
                columns = []
                for col in table.columns:
                    if isinstance(col, str):
                        columns.append(col)
                    else:
                        columns.append(col.name)

                for row in table.rows:
                    row_dict = {}
                    for i, col_name in enumerate(columns):
                        value = row[i]
                        # Convert datetime objects to strings
                        if isinstance(value, datetime):
                            value = value.isoformat()
                        row_dict[col_name] = value
                    results.append(row_dict)
            return {
                "success": True,
                "data": results,
                "row_count": len(results)
            }
        elif response.status == LogsQueryStatus.PARTIAL:
            return {
                "success": False,
                "error": "Query returned partial results",
                "partial_error": str(response.partial_error) if response.partial_error else "Unknown"
            }
        else:
            return {
                "success": False,
                "error": f"Query failed with status: {response.status}"
            }
            
    except HttpResponseError as e:
        error_msg = str(e)
        logger.error(f"HTTP Error: {error_msg}", exc_info=True)
        return {
            "success": False,
            "error": f"Azure API Error: {error_msg}",
            "error_type": "HttpResponseError"
        }
    except Exception as e:
        logger.error(f"Query execution error: {str(e)}", exc_info=True)
        return {
            "success": False,
            "error": str(e),
            "error_type": type(e).__name__
        }

# ============================================
# Schema Discovery Tools
# ============================================

@mcp.tool()
async def get_table_schema(table_name: str = "SecurityIncident") -> dict:
    """
    Query table schema (column information)

    Args:
        table_name: Table name (default: SecurityIncident)

    Returns:
        Table schema information
    """
    query = f"""
    {table_name}
    | getschema
    | project ColumnName, ColumnType
    """
    
    result = await run_kql_query(query, "1d")
    return result

@mcp.tool()
async def list_available_tables() -> dict:
    """
    Query all available tables

    Returns:
        Table list
    """
    query = """
    search *
    | distinct $table
    | sort by $table asc
    """
    
    result = await run_kql_query(query, "1d")
    
    if result["success"]:
        tables = [row.get("$table", "") for row in result["data"]]
        return {
            "success": True,
            "tables": tables,
            "count": len(tables)
        }
    return result

# ============================================
# Sentinel Data Query Tools (Simplified)
# ============================================

@mcp.tool()
async def list_incidents_simple(
    timespan: str = "7d",
    top: int = 50
) -> dict:
    """
    Query Azure Sentinel incidents list (simple version)

    Args:
        timespan: Query period (e.g., 7d, 24h) - default: 7d
        top: Maximum number of results (default: 50)

    Returns:
        Incident list
    """
    # Start with a very simple query
    query = f"""
    SecurityIncident
    | take {top}
    """
    
    result = await run_kql_query(query, timespan)
    
    if result["success"]:
        return {
            "success": True,
            "incidents": result["data"],
            "count": result["row_count"],
            "message": f"Found {result['row_count']} incidents"
        }
    else:
        return result

@mcp.tool()
async def list_incidents(
    timespan: str = "7d",
    severity: Optional[str] = None,
    status: Optional[str] = None,
    top: int = 50
) -> dict:
    """
    Query Azure Sentinel incidents list

    Args:
        timespan: Query period (e.g., 7d, 24h) - default: 7d
        severity: Severity filter (High, Medium, Low, Informational)
        status: Status filter (New, Active, Closed)
        top: Maximum number of results (default: 50)

    Returns:
        Incident list
    """
    # Basic query
    query_parts = [f"SecurityIncident"]

    # Add time filter
    query_parts.append(f"| where TimeGenerated > ago({timespan})")

    # Severity filter
    if severity:
        query_parts.append(f"| where Severity == '{severity}'")

    # Status filter
    if status:
        query_parts.append(f"| where Status == '{status}'")

    # Sort and limit
    query_parts.append("| sort by TimeGenerated desc")
    query_parts.append(f"| take {top}")

    # Select basic fields only (exclude non-existent fields)
    query_parts.append("""| project 
        TimeGenerated,
        IncidentNumber,
        Title,
        Severity,
        Status
    """)
    
    query = "\n".join(query_parts)
    
    result = await run_kql_query(query, timespan)
    
    if result["success"]:
        return {
            "success": True,
            "incidents": result["data"],
            "count": result["row_count"],
            "filters": {
                "timespan": timespan,
                "severity": severity,
                "status": status
            }
        }
    else:
        return result

@mcp.tool()
async def get_incident_by_number(incident_number: int) -> dict:
    """
    Query specific incident by number

    Args:
        incident_number: Incident number

    Returns:
        Incident details
    """
    query = f"""
    SecurityIncident
    | where IncidentNumber == {incident_number}
    | take 1
    """
    
    result = await run_kql_query(query, "90d")
    
    if result["success"] and result["data"]:
        return {
            "success": True,
            "incident": result["data"][0]
        }
    else:
        return {
            "success": False,
            "error": f"Incident number {incident_number} not found"
        }

@mcp.tool()
async def list_security_alerts(
    timespan: str = "7d",
    severity: Optional[str] = None,
    top: int = 50
) -> dict:
    """
    Query Azure Sentinel security alerts list

    Args:
        timespan: Query period (default: 7d)
        severity: Severity filter (High, Medium, Low, Informational)
        top: Maximum number of results (default: 50)

    Returns:
        Security alerts list
    """
    query_parts = ["SecurityAlert"]
    query_parts.append(f"| where TimeGenerated > ago({timespan})")
    
    if severity:
        query_parts.append(f"| where AlertSeverity == '{severity}'")
    
    query_parts.append("| sort by TimeGenerated desc")
    query_parts.append(f"| take {top}")
    query_parts.append("""| project 
        TimeGenerated,
        AlertName,
        AlertSeverity,
        Description
    """)
    
    query = "\n".join(query_parts)
    result = await run_kql_query(query, timespan)
    
    if result["success"]:
        return {
            "success": True,
            "alerts": result["data"],
            "count": result["row_count"]
        }
    return result

@mcp.tool()
async def search_events(
    keyword: str,
    timespan: str = "7d",
    top: int = 100
) -> dict:
    """
    Search security events by keyword

    Args:
        keyword: Keyword to search
        timespan: Query period (default: 7d)
        top: Maximum number of results (default: 100)

    Returns:
        Search results
    """
    query = f"""
    search "{keyword}"
    | where TimeGenerated > ago({timespan})
    | take {top}
    | project TimeGenerated, $table, *
    """
    
    result = await run_kql_query(query, timespan)
    return result

@mcp.tool()
async def get_incident_statistics(timespan: str = "30d") -> dict:
    """
    Query incident statistics

    Args:
        timespan: Query period (default: 30d)

    Returns:
        Incident statistics
    """
    query = f"""
    SecurityIncident
    | where TimeGenerated > ago({timespan})
    | summarize 
        TotalIncidents = count(),
        HighSeverity = countif(Severity == "High"),
        MediumSeverity = countif(Severity == "Medium"),
        LowSeverity = countif(Severity == "Low")
    """
    
    result = await run_kql_query(query, timespan)
    
    if result["success"] and result["data"]:
        return {
            "success": True,
            "timespan": timespan,
            "statistics": result["data"][0]
        }
    return result

@mcp.tool()
async def run_custom_kql(query: str, timespan: str = "7d") -> dict:
    """
    Execute custom KQL query

    Args:
        query: KQL query string
        timespan: Query period (default: 7d)

    Returns:
        Query execution results
    """
    result = await run_kql_query(query, timespan)
    return result

# ============================================
# Utility Tools
# ============================================

@mcp.tool()
def get_workspace_info() -> dict:
    """Azure Sentinel workspace information"""
    if TEST_MODE:
        return {
            "workspace_name": "TestWorkspace",
            "workspace_id": "test-workspace-id",
            "subscription_id": "test-subscription-id",
            "resource_group": "TestResourceGroup",
            "connection_status": "configured (TEST MODE)",
            "test_mode": True
        }
    return {
        "workspace_name": AZURE_WORKSPACE_NAME,
        "workspace_id": AZURE_WORKSPACE_ID,
        "subscription_id": AZURE_SUBSCRIPTION_ID,
        "resource_group": AZURE_RESOURCE_GROUP,
        "connection_status": "configured" if all([
            AZURE_WORKSPACE_ID,
            AZURE_SUBSCRIPTION_ID,
            AZURE_RESOURCE_GROUP,
            AZURE_WORKSPACE_NAME
        ]) else "not_configured"
    }

@mcp.tool()
def ping() -> str:
    """Check server status"""
    return "pong - Azure Sentinel MCP Server is running"

@mcp.tool()
def list_available_playbooks() -> dict:
    """List available playbooks"""
    return {
        "success": True,
        "playbooks": [
            {"id": "pb_ransomware_001", "name": "Ransomware Response", "category": "malware"},
            {"id": "pb_phishing_001", "name": "Phishing Response", "category": "phishing"},
            {"id": "pb_lateral_movement_001", "name": "Lateral Movement Response", "category": "movement"}
        ]
    }

def main():
    """Main entry point for the MCP server"""
    mcp.run()

if __name__ == "__main__":
    main()