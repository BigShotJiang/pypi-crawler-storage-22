#!/usr/bin/env python3
"""
Azure Sentinel MCP Server - Test Version
Modified for local testing without Azure dependencies
"""

import os
import sys
import logging
from typing import Optional
from datetime import datetime, timedelta
import asyncio

# Configure logging to stderr
logging.basicConfig(
    level=logging.WARNING,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    stream=sys.stderr
)
logger = logging.getLogger(__name__)

from mcp.server.fastmcp import FastMCP

# Create MCP server
mcp = FastMCP("Azure Sentinel MCP")

# Test mode flag
TEST_MODE = os.getenv("TEST_MODE", "true").lower() == "true"

# ============================================
# Schema Discovery Tools
# ============================================

@mcp.tool()
async def get_table_schema(table_name: str = "SecurityIncident") -> dict:
    """
    Query table schema (column information) - TEST MODE

    Args:
        table_name: Table name (default: SecurityIncident)

    Returns:
        Table schema information
    """
    if TEST_MODE:
        return {
            "success": True,
            "data": [
                {"ColumnName": "TimeGenerated", "ColumnType": "datetime"},
                {"ColumnName": "IncidentNumber", "ColumnType": "int"},
                {"ColumnName": "Title", "ColumnType": "string"},
                {"ColumnName": "Severity", "ColumnType": "string"},
                {"ColumnName": "Status", "ColumnType": "string"}
            ]
        }

@mcp.tool()
async def list_available_tables() -> dict:
    """
    Query all available tables - TEST MODE

    Returns:
        Table list
    """
    if TEST_MODE:
        return {
            "success": True,
            "tables": ["SecurityIncident", "SecurityAlert", "SigninLogs"],
            "count": 3
        }

# ============================================
# Sentinel Data Query Tools (Simplified)
# ============================================

@mcp.tool()
async def list_incidents_simple(
    timespan: str = "7d",
    top: int = 50
) -> dict:
    """
    Query Azure Sentinel incidents list (simple version) - TEST MODE

    Args:
        timespan: Query period (e.g., 7d, 24h) - default: 7d
        top: Maximum number of results (default: 50)

    Returns:
        Incident list
    """
    if TEST_MODE:
        return {
            "success": True,
            "incidents": [
                {"TimeGenerated": "2025-01-01T00:00:00Z", "IncidentNumber": 12345, "Title": "Test Incident 1"},
                {"TimeGenerated": "2025-01-02T00:00:00Z", "IncidentNumber": 12346, "Title": "Test Incident 2"}
            ],
            "count": 2,
            "message": "Found 2 incidents (TEST MODE)"
        }

@mcp.tool()
async def list_incidents(
    timespan: str = "7d",
    severity: Optional[str] = None,
    status: Optional[str] = None,
    top: int = 50
) -> dict:
    """
    Query Azure Sentinel incidents list - TEST MODE

    Args:
        timespan: Query period (e.g., 7d, 24h) - default: 7d
        severity: Severity filter (High, Medium, Low, Informational)
        status: Status filter (New, Active, Closed)
        top: Maximum number of results (default: 50)

    Returns:
        Incident list
    """
    if TEST_MODE:
        return {
            "success": True,
            "incidents": [
                {"TimeGenerated": "2025-01-01T00:00:00Z", "IncidentNumber": 12345, "Title": "Test Incident 1", "Severity": "High", "Status": "Active"}
            ],
            "count": 1,
            "filters": {
                "timespan": timespan,
                "severity": severity,
                "status": status
            }
        }

@mcp.tool()
async def get_incident_by_number(incident_number: int) -> dict:
    """
    Query specific incident by number - TEST MODE

    Args:
        incident_number: Incident number

    Returns:
        Incident details
    """
    if TEST_MODE:
        return {
            "success": True,
            "incident": {
                "IncidentNumber": incident_number,
                "Title": f"Test Incident {incident_number}",
                "Severity": "High",
                "Status": "Active"
            }
        }

@mcp.tool()
async def list_security_alerts(
    timespan: str = "7d",
    severity: Optional[str] = None,
    top: int = 50
) -> dict:
    """
    Query Azure Sentinel security alerts list - TEST MODE

    Args:
        timespan: Query period (default: 7d)
        severity: Severity filter (High, Medium, Low, Informational)
        top: Maximum number of results (default: 50)

    Returns:
        Security alerts list
    """
    if TEST_MODE:
        return {
            "success": True,
            "alerts": [
                {"TimeGenerated": "2025-01-01T00:00:00Z", "AlertName": "Test Alert 1", "AlertSeverity": "High", "Description": "Test alert description"}
            ],
            "count": 1
        }

@mcp.tool()
async def search_events(
    keyword: str,
    timespan: str = "7d",
    top: int = 100
) -> dict:
    """
    Search security events by keyword - TEST MODE

    Args:
        keyword: Keyword to search
        timespan: Query period (default: 7d)
        top: Maximum number of results (default: 100)

    Returns:
        Search results
    """
    if TEST_MODE:
        return {
            "success": True,
            "data": [
                {"TimeGenerated": "2025-01-01T00:00:00Z", "$table": "SecurityIncident"}
            ]
        }

@mcp.tool()
async def get_incident_statistics(timespan: str = "30d") -> dict:
    """
    Query incident statistics - TEST MODE

    Args:
        timespan: Query period (default: 30d)

    Returns:
        Incident statistics
    """
    if TEST_MODE:
        return {
            "success": True,
            "timespan": timespan,
            "statistics": {
                "TotalIncidents": 10,
                "HighSeverity": 5,
                "MediumSeverity": 3,
                "LowSeverity": 2
            }
        }

@mcp.tool()
async def run_custom_kql(query: str, timespan: str = "7d") -> dict:
    """
    Execute custom KQL query - TEST MODE

    Args:
        query: KQL query string
        timespan: Query period (default: 7d)

    Returns:
        Query execution results
    """
    if TEST_MODE:
        return {
            "success": True,
            "data": []
        }

# ============================================
# Utility Tools
# ============================================

@mcp.tool()
def get_workspace_info() -> dict:
    """Azure Sentinel workspace information - TEST MODE"""
    if TEST_MODE:
        return {
            "workspace_name": "TestWorkspace",
            "workspace_id": "test-workspace-id",
            "subscription_id": "test-subscription-id",
            "resource_group": "TestResourceGroup",
            "connection_status": "configured",
            "test_mode": True
        }

@mcp.tool()
def ping() -> str:
    """Check server status"""
    return "pong - Azure Sentinel MCP Server is running (TEST MODE)"

@mcp.tool()
def list_available_playbooks() -> dict:
    """List available playbooks - TEST MODE"""
    if TEST_MODE:
        return {
            "success": True,
            "playbooks": [
                {"id": "pb_ransomware_001", "name": "Ransomware Response", "category": "malware"},
                {"id": "pb_phishing_001", "name": "Phishing Response", "category": "phishing"},
                {"id": "pb_lateral_movement_001", "name": "Lateral Movement Response", "category": "movement"}
            ]
        }

def main():
    """Main entry point for the MCP server"""
    mcp.run()

if __name__ == "__main__":
    main()