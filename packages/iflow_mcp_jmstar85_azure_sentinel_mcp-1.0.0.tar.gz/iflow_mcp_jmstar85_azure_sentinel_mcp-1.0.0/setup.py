from setuptools import setup, find_packages

setup(
    name="iflow-mcp_jmstar85_azure-sentinel-mcp",
    version="1.0.0",
    description="Advanced Microsoft Sentinel Threat Analysis and Automated Response System",
    py_modules=["server"],
    install_requires=[
        "mcp>=0.9.0",
        "azure-identity>=1.15.0",
        "azure-mgmt-authorization>=4.0.0",
        "azure-mgmt-loganalytics>=12.0.0",
        "azure-mgmt-securityinsight>=1.0.0",
        "azure-monitor-query>=1.2.0",
        "azure-core>=1.29.0",
        "msal>=1.25.0",
        "msal-extensions>=1.0.0",
        "cryptography>=41.0.0",
        "pyjwt>=2.8.0",
        "python-dotenv>=1.0.0",
        "cachetools>=5.3.0",
        "httpx>=0.25.0",
        "pydantic>=2.5.0",
        "pydantic-settings>=2.1.0",
    ],
    entry_points={
        "console_scripts": [
            "azure-sentinel-mcp=server:main",
        ],
    },
)