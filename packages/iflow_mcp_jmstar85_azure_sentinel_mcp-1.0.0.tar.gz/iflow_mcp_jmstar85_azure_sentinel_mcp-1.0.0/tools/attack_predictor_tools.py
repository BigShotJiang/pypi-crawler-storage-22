"""
Attack Path Predictor Tools
Attack path prediction, Kill Chain analysis, timeline reconstruction
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from typing import Dict, List
from datetime import datetime, timedelta

from mcp.server.fastmcp import Context, FastMCP
from tools.base import MCPToolBase
from utilities.task_manager import run_in_thread
from ml_models.ttp_predictor import get_ttp_predictor
from ml_models.attack_graph import reconstruct_attack_timeline, AttackGraphBuilder
from intelligence.mitre_attck import get_mitre_framework


class NextTTPPredictionTool(MCPToolBase):
    """Next TTP (Tactics, Techniques, Procedures) prediction tool"""

    name = "next_ttp_prediction"
    description = """
    Predict next attack phase based on observed TTPs (ML-based).
    Parameters:
    - observed_tactics: 관찰된 전술 ID 리스트 (예: ["TA0001", "TA0002"])
    - observed_techniques: 관찰된 기법 ID 리스트 (예: ["T1566", "T1059"])
    - time_elapsed_minutes: Time elapsed since attack start (minutes, optional)
    - top_k: Number of predictions to return (default: 5)
    """

    async def run(self, ctx: Context, **kwargs) -> Dict:
        observed_tactics = self._extract_param(kwargs, "observed_tactics", [])
        observed_techniques = self._extract_param(kwargs, "observed_techniques", [])
        time_elapsed = self._extract_param(kwargs, "time_elapsed_minutes", 60)
        top_k = self._extract_param(kwargs, "top_k", 5)

        predictor = get_ttp_predictor()
        mitre = get_mitre_framework()

        # Predict next tactics
        next_tactics = predictor.predict_next_tactics(observed_tactics, top_k=3)

        # Predict next techniques
        next_techniques = predictor.predict_next_techniques(
            observed_techniques,
            next_tactic=next_tactics[0]["tactic_id"] if next_tactics else None,
            top_k=top_k
        )

        # Add technique details
        enriched_techniques = []
        for pred_tech in next_techniques:
            tech_id = pred_tech["technique_id"]
            technique = mitre.get_technique(tech_id)

            if technique:
                enriched_techniques.append({
                    **pred_tech,
                    "name": technique.name,
                    "description": technique.description,
                    "data_sources": technique.data_sources
                })

        # Attack likelihood analysis
        likelihood = predictor.calculate_attack_likelihood(
            observed_tactics,
            observed_techniques,
            time_elapsed
        )

        return self.wrap_result({
            "prediction_timestamp": datetime.utcnow().isoformat(),
            "observed_summary": {
                "tactics_count": len(observed_tactics),
                "techniques_count": len(observed_techniques),
                "time_elapsed_minutes": time_elapsed
            },
            "next_tactics": next_tactics,
            "next_techniques": enriched_techniques,
            "attack_likelihood": likelihood,
            "recommendations": self._generate_defensive_recommendations(
                next_tactics, enriched_techniques, likelihood
            )
        })

    def _generate_defensive_recommendations(
        self,
        next_tactics: List[Dict],
        next_techniques: List[Dict],
        likelihood: Dict
    ) -> List[str]:
        """Generate defensive recommendations"""
        recommendations = []

        # Based on urgency
        if likelihood["threat_level"] == "Critical":
            recommendations.append("🚨 Urgent: Immediate incident response required")
            recommendations.append("🔒 Consider isolating affected systems")

        # Defense based on expected tactics
        for tactic in next_tactics[:2]:
            tactic_name = tactic["name"]

            if "Lateral Movement" in tactic_name:
                recommendations.append("🛡️ Enhance internal network segment monitoring")
                recommendations.append("🔐 Enhance privileged account activity monitoring")

            elif "Exfiltration" in tactic_name:
                recommendations.append("🚫 외부 통신 차단 고려 (Data exfiltration 방지)")
                recommendations.append("📊 Activate large data transfer detection rules")

            elif "Impact" in tactic_name:
                recommendations.append("💾 Immediately backup critical systems")
                recommendations.append("🔐 Verify ransomware defense system")

        # Defense based on expected techniques
        for tech in next_techniques[:2]:
            if "Credential" in tech.get("name", ""):
                recommendations.append("🔑 Strengthen account security: Enforce MFA, reset passwords")

            if "Scheduled Task" in tech.get("name", ""):
                recommendations.append("⏰ Inspect scheduled tasks and Cron jobs")

        # Based on time to Impact
        eti = likelihood.get("estimated_time_to_impact_minutes")
        if eti is not None and eti < 60:
            recommendations.append(f"⏱️ Estimated time to Impact: approximately {eti} minutes - rapid response required")

        return recommendations


class KillChainAnalysisTool(MCPToolBase):
    """Kill Chain analysis tool"""

    name = "kill_chain_analysis"
    description = """
    Analyze current attack Kill Chain phase and assess progress.
    Parameters:
    - incident_number: Incident number (optional)
    - timespan: Analysis period (default: 24h)
    """

    async def run(self, ctx: Context, **kwargs) -> Dict:
        incident_number = self._extract_param(kwargs, "incident_number")
        timespan = self._extract_param(kwargs, "timespan", "24h")

        logs_client, workspace_id = self.get_logs_client_and_workspace(ctx)
        mitre = get_mitre_framework()

        # Query alerts
        if incident_number:
            query = f"""
            SecurityIncident
            | where IncidentNumber == {incident_number}
            | mv-expand AlertIds
            | join kind=inner (
                SecurityAlert
            ) on $left.AlertIds == $right.SystemAlertId
            | project TimeGenerated, AlertName, Tactics, Techniques, Severity
            """
        else:
            query = f"""
            SecurityAlert
            | where TimeGenerated > ago({timespan})
            | where AlertSeverity in ("High", "Critical")
            | project TimeGenerated, AlertName, Tactics, Techniques, AlertSeverity
            | order by TimeGenerated asc
            """

        # Execute query
        timespan_obj = self._parse_timespan(timespan)
        response = await run_in_thread(
            logs_client.query_workspace,
            workspace_id=workspace_id,
            query=query,
            timespan=timespan_obj,
            name="kill_chain_analysis"
        )

        if not response.rows:
            return self.wrap_result({
                "message": "No data to analyze.",
                "kill_chain_phases": []
            })

        # Collect tactics/techniques
        all_tactics = set()
        all_techniques = set()
        events = []

        for row in response.rows:
            event_data = {col.name: val for col, val in zip(response.columns, row)}

            tactics = event_data.get("Tactics", []) or []
            techniques = event_data.get("Techniques", []) or []

            if isinstance(tactics, str):
                tactics = [tactics]
            if isinstance(techniques, str):
                techniques = [techniques]

            all_tactics.update(tactics)
            all_techniques.update(techniques)

            events.append({
                "timestamp": event_data.get("TimeGenerated").isoformat()
                    if event_data.get("TimeGenerated") else None,
                "alert_name": event_data.get("AlertName"),
                "tactics": tactics,
                "techniques": techniques
            })

        # MITRE 매핑
        mapped_tactics = []
        for tactic_id in all_tactics:
            tactic = mitre.get_tactic(tactic_id)
            if tactic:
                mapped_tactics.append({
                    "id": tactic.tactic_id,
                    "name": tactic.name,
                    "description": tactic.description
                })

        # Kill Chain 진행도
        total_phases = 12
        progress_pct = (len(all_tactics) / total_phases * 100) if all_tactics else 0

        # 현재 단계 판별
        phase_order = [
            "Initial Access", "Execution", "Persistence",
            "Privilege Escalation", "Defense Evasion", "Credential Access",
            "Discovery", "Lateral Movement", "Collection",
            "Exfiltration", "Command and Control", "Impact"
        ]

        current_phase = "Unknown"
        max_phase_idx = -1

        for tactic in mapped_tactics:
            tactic_name = tactic["name"]
            if tactic_name in phase_order:
                idx = phase_order.index(tactic_name)
                if idx > max_phase_idx:
                    max_phase_idx = idx
                    current_phase = tactic_name

        return self.wrap_result({
            "analysis_timestamp": datetime.utcnow().isoformat(),
            "kill_chain_progress": {
                "current_phase": current_phase,
                "completed_phases": len(all_tactics),
                "total_phases": total_phases,
                "progress_percentage": round(progress_pct, 1)
            },
            "observed_tactics": mapped_tactics,
            "observed_techniques_count": len(all_techniques),
            "events_analyzed": len(events),
            "timeline": events[:10]  # 최근 10개
        })


class AttackTimelineReconstructionTool(MCPToolBase):
    """Attack timeline reconstruction tool"""

    name = "attack_timeline_reconstruction"
    description = """
    Reconstruct attack timeline and visualize attack paths through event correlation.
    Parameters:
    - incident_number: Incident number (optional)
    - timespan: Analysis period (default: 24h)
    - include_graph: Whether to include graph data (default: false)
    """

    async def run(self, ctx: Context, **kwargs) -> Dict:
        incident_number = self._extract_param(kwargs, "incident_number")
        timespan = self._extract_param(kwargs, "timespan", "24h")
        include_graph = self._extract_param(kwargs, "include_graph", False)

        logs_client, workspace_id = self.get_logs_client_and_workspace(ctx)

        # Query alerts and entities
        if incident_number:
            query = f"""
            SecurityIncident
            | where IncidentNumber == {incident_number}
            | mv-expand AlertIds
            | join kind=inner (
                SecurityAlert
                | extend Entities = parse_json(Entities)
            ) on $left.AlertIds == $right.SystemAlertId
            | project TimeGenerated, SystemAlertId, AlertName, AlertSeverity,
                      Description, Tactics, Techniques, Entities, ExtendedProperties
            | order by TimeGenerated asc
            """
        else:
            query = f"""
            SecurityAlert
            | where TimeGenerated > ago({timespan})
            | extend Entities = parse_json(Entities)
            | project TimeGenerated, SystemAlertId, AlertName, AlertSeverity,
                      Description, Tactics, Techniques, Entities, ExtendedProperties
            | order by TimeGenerated asc
            | take 50
            """

        # Execute query
        timespan_obj = self._parse_timespan(timespan)
        response = await run_in_thread(
            logs_client.query_workspace,
            workspace_id=workspace_id,
            query=query,
            timespan=timespan_obj,
            name="attack_timeline_reconstruction"
        )

        if not response.rows:
            return self.wrap_result({
                "message": "No data to reconstruct.",
                "timeline": []
            })

        # Transform alert data
        alerts = []
        for row in response.rows:
            alert_data = {col.name: val for col, val in zip(response.columns, row)}
            alerts.append(alert_data)

        # Reconstruct timeline
        reconstruction = reconstruct_attack_timeline(alerts)

        result = {
            "reconstruction_timestamp": datetime.utcnow().isoformat(),
            "timeline": reconstruction["timeline"],
            "critical_paths": reconstruction["critical_paths"],
            "statistics": reconstruction["statistics"],
            "insights": self._generate_timeline_insights(
                reconstruction["timeline"],
                reconstruction["critical_paths"]
            )
        }

        if include_graph:
            result["graph"] = reconstruction["graph"]

        return self.wrap_result(result)

    def _generate_timeline_insights(
        self,
        timeline: List[Dict],
        critical_paths: List[Dict]
    ) -> List[str]:
        """Generate timeline insights"""
        insights = []

        if not timeline:
            return ["Insufficient events to analyze."]

        # Time compression
        if len(timeline) > 1:
            first_event = datetime.fromisoformat(timeline[0]["timestamp"])
            last_event = datetime.fromisoformat(timeline[-1]["timestamp"])
            duration_minutes = (last_event - first_event).total_seconds() / 60

            events_per_hour = len(timeline) / max(duration_minutes / 60, 0.1)

            if events_per_hour > 10:
                insights.append(f"⚡ High attack speed: approximately {events_per_hour:.1f} events per hour")
            elif events_per_hour > 5:
                insights.append(f"⚠️ Medium attack speed: approximately {events_per_hour:.1f} events per hour")

        # Severity analysis
        severity_counts = {}
        for event in timeline:
            sev = event.get("severity", "Unknown")
            severity_counts[sev] = severity_counts.get(sev, 0) + 1

        if severity_counts.get("Critical", 0) > 3:
            insights.append(f"🚨 다수의 Critical 알림 ({severity_counts['Critical']}개)")

        # Path analysis
        if critical_paths:
            longest_path = max(critical_paths, key=lambda p: p.get("alert_count", 0))
            insights.append(
                f"🔗 가장 긴 공격 경로: {longest_path['alert_count']}개 연관 알림"
            )

        return insights


# Register tools
def register_tools(mcp: FastMCP):
    """Attack Path Predictor Register tools"""
    NextTTPPredictionTool.register(mcp)
    KillChainAnalysisTool.register(mcp)
    AttackTimelineReconstructionTool.register(mcp)
