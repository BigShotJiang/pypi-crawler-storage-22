"""
Automation Executor Tools
Automated response action execution and approval workflow management
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from typing import Dict, List
from datetime import datetime

from mcp.server.fastmcp import Context, FastMCP
from tools.base import MCPToolBase
from playbooks.executor import get_playbook_executor, ResponseAction, ActionStatus, ActionType


class ExecuteResponseActionTool(MCPToolBase):
    """Response action execution tool"""

    name = "execute_response_action"
    description = """
    Execute approved response actions (simulation mode)

    ⚠️ Warning: This tool can affect actual systems.
    Additional approval process required in production environment.

    Parameters:
    - action_type: Action type (isolate_host, block_ip, disable_account, reset_password, notify, create_ticket)
    - target: Target (hostname, IP, account, etc.)
    - parameters: Additional parameters (dict, optional)
    - require_approval: Whether approval required (default: true)
    - approver: Approver (optional if require_approval=false)
    """

    async def run(self, ctx: Context, **kwargs) -> Dict:
        action_type_str = self._extract_param(kwargs, "action_type")
        target = self._extract_param(kwargs, "target")
        parameters = self._extract_param(kwargs, "parameters", {})
        require_approval = self._extract_param(kwargs, "require_approval", True)
        approver = self._extract_param(kwargs, "approver", "system")

        # Convert action type
        try:
            action_type = ActionType[action_type_str.upper()]
        except KeyError:
            return self.wrap_error(
                f"Invalid action_type: {action_type_str}. "
                f"Valid types: {', '.join([a.name.lower() for a in ActionType])}"
            )

        executor = get_playbook_executor()

        # Create action
        action = ResponseAction(
            action_id=f"manual_{datetime.utcnow().timestamp()}",
            action_type=action_type,
            target=target,
            parameters=parameters,
            requires_approval=require_approval,
            created_at=datetime.utcnow()
        )

        # Process approval
        if not require_approval:
            action.status = ActionStatus.APPROVED
            action.approved_by = approver
        else:
            # In production, trigger approval workflow
            return self.wrap_result({
                "action_created": True,
                "action_id": action.action_id,
                "status": "pending_approval",
                "message": "Action created and waiting for approval",
                "action_details": {
                    "action_type": action_type.value,
                    "target": target,
                    "parameters": parameters
                }
            })

        # Execute action
        result = executor.execute_action(action)

        return self.wrap_result({
            "execution_timestamp": datetime.utcnow().isoformat(),
            "action_executed": result["success"],
            **result
        })


class ApproveResponseActionTool(MCPToolBase):
    """Response action approval tool"""

    name = "approve_response_action"
    description = """
    Approve pending response actions.

    Parameters:
    - action_id: 액션 ID
    - approver: 승인자 이름
    - comments: Approval comment (optional)
    """

    async def run(self, ctx: Context, **kwargs) -> Dict:
        action_id = self._extract_param(kwargs, "action_id")
        approver = self._extract_param(kwargs, "approver")
        comments = self._extract_param(kwargs, "comments", "")

        executor = get_playbook_executor()

        # Process approval
        approval_result = executor.approve_action(action_id, approver)

        return self.wrap_result({
            "approval_timestamp": datetime.utcnow().isoformat(),
            "action_id": action_id,
            "approver": approver,
            "comments": comments,
            **approval_result
        })


class ListAvailablePlaybooksTool(MCPToolBase):
    """Available playbook listing tool"""

    name = "list_available_playbooks"
    description = """
    Query all available automation playbooks.

    Parameters: 없음
    """

    async def run(self, ctx: Context, **kwargs) -> Dict:
        executor = get_playbook_executor()

        playbooks = executor.get_all_playbooks()

        return self.wrap_result({
            "total_playbooks": len(playbooks),
            "playbooks": playbooks
        })


class ExecutePlaybookTool(MCPToolBase):
    """Playbook execution tool"""

    name = "execute_playbook"
    description = """
    Execute specific playbook to generate response plan and perform actions.

    Parameters:
    - playbook_id: 플레이북 ID
    - incident_data: 인시던트 데이터 (dict)
    - auto_approve: Auto-execute actions not requiring approval (default: false)
    - execute_immediately: Immediate execution (default: false, if true execute approved actions immediately)
    """

    async def run(self, ctx: Context, **kwargs) -> Dict:
        playbook_id = self._extract_param(kwargs, "playbook_id")
        incident_data = self._extract_param(kwargs, "incident_data", {})
        auto_approve = self._extract_param(kwargs, "auto_approve", False)
        execute_immediately = self._extract_param(kwargs, "execute_immediately", False)

        executor = get_playbook_executor()

        # 대응 계획 생성
        response_plan = executor.create_response_plan(
            playbook_id,
            incident_data,
            auto_approve_non_critical=auto_approve
        )

        if "error" in response_plan:
            return self.wrap_error(response_plan["error"])

        # Immediate execution option
        execution_results = []
        if execute_immediately:
            # Execute approved actions
            for action_dict in response_plan.get("actions", []):
                if action_dict["status"] == "approved":
                    # Reconstruct action
                    action = ResponseAction(
                        action_id=action_dict["action_id"],
                        action_type=ActionType[action_dict["action_type"].upper()],
                        target=action_dict["target"],
                        parameters=action_dict["parameters"],
                        status=ActionStatus.APPROVED,
                        requires_approval=action_dict["requires_approval"]
                    )

                    result = executor.execute_action(action)
                    execution_results.append(result)

        return self.wrap_result({
            "playbook_executed": True,
            "playbook_id": playbook_id,
            "response_plan": response_plan,
            "executed_immediately": execute_immediately,
            "execution_results": execution_results if execute_immediately else None,
            "next_steps": self._generate_next_steps(response_plan, execute_immediately)
        })

    def _generate_next_steps(self, response_plan: Dict, executed: bool) -> List[str]:
        """Next steps guide"""
        next_steps = []

        if executed:
            next_steps.append("✅ Approved actions have been executed.")
            next_steps.append("📊 Review execution results.")
            next_steps.append("📝 Update incident logs.")
        else:
            requires_approval_count = response_plan.get("requires_approval_count", 0)

            if requires_approval_count > 0:
                next_steps.append(
                    f"⏳ {requires_approval_count}actions are waiting for approval."
                )
                next_steps.append("👤 Use approve_response_action tool for approval.")

            auto_approved = [
                a for a in response_plan.get("actions", [])
                if a["status"] == "approved"
            ]

            if auto_approved:
                next_steps.append(
                    f"✅ {len(auto_approved)}actions have been auto-approved."
                )
                next_steps.append("▶️ Can be executed immediately with execute_immediately=true.")

        return next_steps


class GetActionStatusTool(MCPToolBase):
    """Action status query tool"""

    name = "get_action_status"
    description = """
    Query status of running or completed actions.

    Parameters:
    - action_id: 액션 ID
    """

    async def run(self, ctx: Context, **kwargs) -> Dict:
        action_id = self._extract_param(kwargs, "action_id")

        # In production, query from database or state store
        # Here, simulation

        return self.wrap_result({
            "action_id": action_id,
            "status": "completed",
            "message": "Action status query is simulated. In production, this would query actual action state.",
            "details": {
                "executed_at": datetime.utcnow().isoformat(),
                "executed_by": "system",
                "result": "success"
            }
        })


class RollbackActionTool(MCPToolBase):
    """Action rollback tool"""

    name = "rollback_action"
    description = """
    Rollback executed action (if possible)

    ⚠️ Warning: Not all actions can be rolled back.

    Parameters:
    - action_id: Action ID to rollback
    - reason: Rollback reason
    """

    async def run(self, ctx: Context, **kwargs) -> Dict:
        action_id = self._extract_param(kwargs, "action_id")
        reason = self._extract_param(kwargs, "reason", "User requested rollback")

        # Rollback simulation
        rollback_result = {
            "rollback_possible": True,
            "action_id": action_id,
            "rollback_status": "completed",
            "reason": reason,
            "rollback_timestamp": datetime.utcnow().isoformat(),
            "message": "Action rollback simulated successfully"
        }

        return self.wrap_result(rollback_result)


# Register tools
def register_tools(mcp: FastMCP):
    """Automation Executor Register tools"""
    ExecuteResponseActionTool.register(mcp)
    ApproveResponseActionTool.register(mcp)
    ListAvailablePlaybooksTool.register(mcp)
    ExecutePlaybookTool.register(mcp)
    GetActionStatusTool.register(mcp)
    RollbackActionTool.register(mcp)
