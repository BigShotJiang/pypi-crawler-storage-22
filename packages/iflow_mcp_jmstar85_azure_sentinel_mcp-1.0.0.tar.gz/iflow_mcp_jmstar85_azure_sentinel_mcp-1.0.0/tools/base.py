"""
Base class for all MCP tools
Base class for all MCP tools
"""

import logging
import warnings
from abc import ABC, abstractmethod
from typing import Any, Optional, Dict

from azure.identity import DefaultAzureCredential
from azure.monitor.query import LogsQueryClient
from azure.mgmt.securityinsight import SecurityInsights
from mcp.server.fastmcp import Context, FastMCP


def get_tool_logger(name: str) -> logging.Logger:
    """Create logger for tool"""
    logger = logging.getLogger(f"tools.{name}")
    logger.setLevel(logging.INFO)
    return logger


class MCPToolBase(ABC):
    """Base class for all MCP tools"""

    name: str = ""
    description: str = ""
    logger: logging.Logger = None

    def __init__(self):
        """Basic initialization"""
        # Azure SDK 경고 억제
        warnings.filterwarnings(
            "ignore",
            message="Datetime with no tzinfo will be considered UTC.",
            module="azure.core.serialization",
        )
        self.logger = get_tool_logger(self.__class__.__name__)

    def get_azure_context(self, ctx: Context):
        """Extract Azure context"""
        azure_ctx = ctx.request_context.lifespan_dependencies[0]
        return azure_ctx

    def get_logs_client_and_workspace(self, ctx: Context):
        """Get Log Analytics client and workspace ID"""
        azure_ctx = self.get_azure_context(ctx)
        return azure_ctx.logs_client, azure_ctx.workspace_id

    def get_workspace_info(self, ctx: Context):
        """Get workspace information"""
        azure_ctx = self.get_azure_context(ctx)
        return {
            "workspace_id": azure_ctx.workspace_id,
            "workspace_name": azure_ctx.workspace_name,
            "subscription_id": azure_ctx.subscription_id,
            "resource_group": azure_ctx.resource_group,
            "tenant_id": azure_ctx.tenant_id
        }

    def get_security_insights_client(self, ctx: Context) -> SecurityInsights:
        """Get Security Insights client"""
        azure_ctx = self.get_azure_context(ctx)
        return azure_ctx.security_insights_client

    def get_credential(self, ctx: Context) -> DefaultAzureCredential:
        """Get Azure credentials"""
        azure_ctx = self.get_azure_context(ctx)
        return azure_ctx.credential

    def _extract_param(self, kwargs: Dict, key: str, default: Any = None) -> Any:
        """Parameter extraction helper"""
        value = kwargs.get(key, default)
        if value is None and default is None:
            # None이 유효한 값인 경우도 있으므로 키 존재 여부 확인
            if key not in kwargs:
                self.logger.warning(f"Parameter '{key}' not provided, using default: {default}")
        return value

    def _parse_timespan(self, timespan: str) -> str:
        """
        Parse timespan (e.g., "1d", "2h", "30m")
        ISO 8601 duration 형식으로 변환
        """
        if not timespan:
            return "PT1H"  # Default: 1 hour

        timespan = timespan.lower().strip()

        # 이미 ISO 8601 형식인 경우
        if timespan.startswith("p"):
            return timespan

        # 간단한 형식 변환
        import re
        match = re.match(r'(\d+)([dhms])', timespan)
        if not match:
            self.logger.warning(f"Invalid timespan format: {timespan}, using default 1h")
            return "PT1H"

        value, unit = match.groups()
        unit_map = {
            'd': f'P{value}D',      # days
            'h': f'PT{value}H',     # hours
            'm': f'PT{value}M',     # minutes
            's': f'PT{value}S'      # seconds
        }

        return unit_map.get(unit, "PT1H")

    def wrap_result(self, data: Any, metadata: Optional[Dict] = None) -> Dict:
        """Wrap result in standard format"""
        result = {
            "success": True,
            "data": data
        }
        if metadata:
            result["metadata"] = metadata
        return result

    def wrap_error(self, error: str, error_type: str = "ToolError") -> Dict:
        """Wrap error in standard format"""
        return {
            "success": False,
            "error": error,
            "error_type": error_type
        }

    @abstractmethod
    async def run(self, ctx: Context, **kwargs) -> Any:
        """
        Tool execution - must be implemented in subclass

        Args:
            ctx: MCP Context
            **kwargs: 도구별 파라미터

        Returns:
            Execution result (dict)
        """
        pass

    async def __call__(self, ctx: Context, **kwargs) -> Any:
        """
        Tool call entry point (with error handling)
        """
        try:
            self.logger.info(f"🔧 {self.name} execution started")
            result = await self.run(ctx, **kwargs)
            self.logger.info(f"✅ {self.name} execution completed")
            return result
        except Exception as e:
            self.logger.error(f"❌ {self.name} execution failed: {str(e)}", exc_info=True)
            return self.wrap_error(str(e), type(e).__name__)

    @classmethod
    def register(cls, mcp: FastMCP):
        """Register tool to MCP server"""
        instance = cls()
        if not instance.name or not instance.description:
            raise ValueError(f"{cls.__name__} must define 'name' and 'description'")

        # Create wrapper function
        async def tool_wrapper(ctx: Context, **kwargs):
            return await instance(ctx, **kwargs)

        tool_wrapper.__name__ = instance.name
        mcp.tool(name=instance.name, description=instance.description)(tool_wrapper)
