"""
Response Coordinator Tools
Business impact assessment, response plan generation, resource prioritization
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from typing import Dict, List
from datetime import datetime

from mcp.server.fastmcp import Context, FastMCP
from tools.base import MCPToolBase
from utilities.task_manager import run_in_thread
from playbooks.executor import get_playbook_executor


class BusinessImpactAssessmentTool(MCPToolBase):
    """Business impact assessment tool"""

    name = "business_impact_assessment"
    description = """
    Assess business impact of security incident.
    Parameters:
    - incident_number: 인시던트 번호
    - affected_assets: List of affected assets (optional)
    - severity: Incident severity (optional)
    """

    async def run(self, ctx: Context, **kwargs) -> Dict:
        incident_number = self._extract_param(kwargs, "incident_number")
        affected_assets = self._extract_param(kwargs, "affected_assets", [])
        severity = self._extract_param(kwargs, "severity", "Unknown")

        logs_client, workspace_id = self.get_logs_client_and_workspace(ctx)

        # Query incident details
        if incident_number:
            query = f"""
            SecurityIncident
            | where IncidentNumber == {incident_number}
            | project IncidentNumber, Title, Severity, Status, Owner,
                      AdditionalData, AlertIds
            | take 1
            """

            timespan_obj = self._parse_timespan("30d")
            response = await run_in_thread(
                logs_client.query_workspace,
                workspace_id=workspace_id,
                query=query,
                timespan=timespan_obj,
                name="incident_details"
            )

            if response.rows:
                incident_data = {col.name: val for col, val in zip(response.columns, response.rows[0])}
                severity = incident_data.get("Severity", severity)

        # Impact assessment
        impact_assessment = self._assess_impact(severity, affected_assets)

        # Calculate business priority
        business_priority = self._calculate_business_priority(
            severity,
            affected_assets,
            impact_assessment
        )

        return self.wrap_result({
            "assessment_timestamp": datetime.utcnow().isoformat(),
            "incident_number": incident_number,
            "severity": severity,
            "impact_assessment": impact_assessment,
            "business_priority": business_priority,
            "recommendations": self._generate_impact_recommendations(
                impact_assessment,
                business_priority
            )
        })

    def _assess_impact(self, severity: str, affected_assets: List[str]) -> Dict:
        """Impact assessment"""

        # Asset criticality mapping (in production, query from CMDB)
        asset_criticality = {
            "domain_controller": "Critical",
            "database_server": "High",
            "web_server": "Medium",
            "workstation": "Low"
        }

        # Severity score
        severity_scores = {
            "Critical": 10,
            "High": 7,
            "Medium": 4,
            "Low": 2,
            "Informational": 1,
            "Unknown": 3
        }

        base_score = severity_scores.get(severity, 3)

        # Analyze affected assets
        asset_impact = []
        max_asset_criticality = 0

        for asset in affected_assets:
            # Infer asset type (simplified)
            asset_type = "workstation"
            for key in asset_criticality:
                if key in asset.lower():
                    asset_type = key
                    break

            criticality = asset_criticality.get(asset_type, "Low")
            criticality_score = severity_scores.get(criticality, 2)
            max_asset_criticality = max(max_asset_criticality, criticality_score)

            asset_impact.append({
                "asset": asset,
                "type": asset_type,
                "criticality": criticality
            })

        # Total impact score
        total_impact_score = base_score + (max_asset_criticality * 0.5)

        # Classify impact category
        if total_impact_score >= 12:
            impact_level = "Critical"
            impact_description = "Critical business impact - core service disruption possible"
        elif total_impact_score >= 8:
            impact_level = "High"
            impact_description = "High business impact - service quality degradation"
        elif total_impact_score >= 5:
            impact_level = "Medium"
            impact_description = "Medium business impact - limited service impact"
        else:
            impact_level = "Low"
            impact_description = "Low business impact - minimal service impact"

        return {
            "impact_level": impact_level,
            "impact_score": round(total_impact_score, 1),
            "description": impact_description,
            "affected_assets": asset_impact,
            "estimated_downtime_hours": self._estimate_downtime(impact_level),
            "affected_users_estimate": self._estimate_affected_users(affected_assets),
            "financial_impact_estimate": self._estimate_financial_impact(impact_level)
        }

    def _estimate_downtime(self, impact_level: str) -> str:
        """Estimate downtime"""
        estimates = {
            "Critical": "24-72 hours",
            "High": "8-24 hours",
            "Medium": "2-8 hours",
            "Low": "< 2 hours"
        }
        return estimates.get(impact_level, "Unknown")

    def _estimate_affected_users(self, affected_assets: List[str]) -> str:
        """Estimate number of affected users"""
        # In production, based on AD/CMDB data
        if len(affected_assets) > 10:
            return "100+ users"
        elif len(affected_assets) > 5:
            return "50-100 users"
        elif len(affected_assets) > 0:
            return "10-50 users"
        else:
            return "< 10 users"

    def _estimate_financial_impact(self, impact_level: str) -> str:
        """Estimate financial impact"""
        estimates = {
            "Critical": "$100K+ (Critical business disruption)",
            "High": "$50K-$100K (Significant impact)",
            "Medium": "$10K-$50K (Moderate impact)",
            "Low": "< $10K (Minimal impact)"
        }
        return estimates.get(impact_level, "Unknown")

    def _calculate_business_priority(
        self,
        severity: str,
        affected_assets: List[str],
        impact_assessment: Dict
    ) -> Dict:
        """Calculate business priority"""

        # Priority score (0-100)
        impact_score = impact_assessment["impact_score"]
        normalized_score = min(impact_score / 15 * 100, 100)

        if normalized_score >= 80:
            priority = "P1 - Critical"
            sla = "< 1 hour"
        elif normalized_score >= 60:
            priority = "P2 - High"
            sla = "< 4 hours"
        elif normalized_score >= 40:
            priority = "P3 - Medium"
            sla = "< 24 hours"
        else:
            priority = "P4 - Low"
            sla = "< 72 hours"

        return {
            "priority": priority,
            "priority_score": round(normalized_score, 1),
            "sla_response_time": sla,
            "escalation_required": normalized_score >= 80,
            "stakeholder_notification_required": normalized_score >= 60
        }

    def _generate_impact_recommendations(
        self,
        impact_assessment: Dict,
        business_priority: Dict
    ) -> List[str]:
        """Impact-based recommendations"""
        recommendations = []

        impact_level = impact_assessment["impact_level"]

        if impact_level == "Critical":
            recommendations.append("🚨 Immediate escalation to management")
            recommendations.append("📞 Assemble emergency response team")
            recommendations.append("📢 Consider activating Business Continuity Plan (BCP)")

        if business_priority["escalation_required"]:
            recommendations.append("⬆️ Immediate escalation to incident manager")

        if business_priority["stakeholder_notification_required"]:
            recommendations.append("📧 Report situation to key stakeholders")

        recommendations.append(f"⏱️ SLA 목표: {business_priority['sla_response_time']}")

        return recommendations


class ResponsePlanGenerationTool(MCPToolBase):
    """Response plan generation tool"""

    name = "response_plan_generation"
    description = """
    Generate automated response plan based on incident data.
    Parameters:
    - incident_number: 인시던트 번호
    - playbook_id: Playbook ID to use (optional)
    - auto_match: Auto playbook matching (default: true)
    """

    async def run(self, ctx: Context, **kwargs) -> Dict:
        incident_number = self._extract_param(kwargs, "incident_number")
        playbook_id = self._extract_param(kwargs, "playbook_id")
        auto_match = self._extract_param(kwargs, "auto_match", True)

        logs_client, workspace_id = self.get_logs_client_and_workspace(ctx)
        executor = get_playbook_executor()

        # Query incident data
        query = f"""
        SecurityIncident
        | where IncidentNumber == {incident_number}
        | extend AlertIdsArray = parse_json(AlertIds)
        | mv-expand AlertId = AlertIdsArray
        | join kind=inner (
            SecurityAlert
        ) on $left.AlertId == $right.SystemAlertId
        | project IncidentNumber, IncidentTitle = Title, IncidentSeverity = Severity,
                  AlertName, AlertSeverity, Tactics, Techniques, Entities
        | take 1
        """

        timespan_obj = self._parse_timespan("30d")
        response = await run_in_thread(
            logs_client.query_workspace,
            workspace_id=workspace_id,
            query=query,
            timespan=timespan_obj,
            name="incident_for_plan"
        )

        if not response.rows:
            return self.wrap_error(f"Incident {incident_number} not found")

        # Parse incident data
        incident_data = {col.name: val for col, val in zip(response.columns, response.rows[0])}

        # Match or specify playbook
        matched_playbooks = []

        if auto_match and not playbook_id:
            # Auto matching
            search_data = {
                "alert_name": incident_data.get("AlertName", ""),
                "severity": incident_data.get("IncidentSeverity", ""),
                "tactics": incident_data.get("Tactics", []) or [],
                "techniques": incident_data.get("Techniques", []) or []
            }

            matched_playbooks = executor.match_playbook(search_data)

            if matched_playbooks:
                playbook_id = matched_playbooks[0].playbook_id

        # 대응 계획 생성
        if playbook_id:
            response_plan = executor.create_response_plan(
                playbook_id,
                incident_data,
                auto_approve_non_critical=False
            )

            return self.wrap_result({
                "plan_created": True,
                "incident_number": incident_number,
                "matched_playbooks": [
                    {"id": pb.playbook_id, "name": pb.name}
                    for pb in matched_playbooks
                ],
                "selected_playbook": playbook_id,
                "response_plan": response_plan
            })
        else:
            # Playbook matching failed - manual recommendation
            all_playbooks = executor.get_all_playbooks()

            return self.wrap_result({
                "plan_created": False,
                "message": "No automatic playbook match found",
                "incident_number": incident_number,
                "available_playbooks": all_playbooks,
                "recommendation": "Please manually select a playbook"
            })


class ResourcePrioritizationTool(MCPToolBase):
    """Resource prioritization tool"""

    name = "resource_prioritization"
    description = """
    Determine response resource priorities for multiple incidents.
    Parameters:
    - timespan: Analysis period (default: 24h)
    - status_filter: Status filter (optional, e.g., ["New", "Active"])
    """

    async def run(self, ctx: Context, **kwargs) -> Dict:
        timespan = self._extract_param(kwargs, "timespan", "24h")
        status_filter = self._extract_param(kwargs, "status_filter", ["New", "Active"])

        logs_client, workspace_id = self.get_logs_client_and_workspace(ctx)

        # Query active incidents
        status_condition = " or ".join([f'Status == "{s}"' for s in status_filter])

        query = f"""
        SecurityIncident
        | where TimeGenerated > ago({timespan})
        | where {status_condition}
        | project IncidentNumber, Title, Severity, Status, Owner,
                  TimeGenerated, LastModifiedTime, AlertsCount
        | order by Severity desc, TimeGenerated desc
        """

        timespan_obj = self._parse_timespan(timespan)
        response = await run_in_thread(
            logs_client.query_workspace,
            workspace_id=workspace_id,
            query=query,
            timespan=timespan_obj,
            name="resource_prioritization"
        )

        if not response.rows:
            return self.wrap_result({
                "message": "No incidents to prioritize.",
                "prioritized_incidents": []
            })

        # Prioritize incidents
        incidents = []
        for row in response.rows:
            incident_data = {col.name: val for col, val in zip(response.columns, row)}
            priority_score = self._calculate_priority_score(incident_data)

            incidents.append({
                "incident_number": incident_data.get("IncidentNumber"),
                "title": incident_data.get("Title"),
                "severity": incident_data.get("Severity"),
                "status": incident_data.get("Status"),
                "owner": incident_data.get("Owner"),
                "time_generated": incident_data.get("TimeGenerated").isoformat()
                    if incident_data.get("TimeGenerated") else None,
                "alerts_count": incident_data.get("AlertsCount", 0),
                "priority_score": priority_score["score"],
                "priority_rank": priority_score["rank"],
                "recommended_action": priority_score["recommended_action"]
            })

        # Sort by priority score
        incidents.sort(key=lambda x: x["priority_score"], reverse=True)

        # Assign rank
        for idx, incident in enumerate(incidents, 1):
            incident["priority_rank"] = idx

        # Recommend resource allocation
        resource_allocation = self._recommend_resource_allocation(incidents)

        return self.wrap_result({
            "prioritization_timestamp": datetime.utcnow().isoformat(),
            "total_incidents": len(incidents),
            "prioritized_incidents": incidents,
            "resource_allocation": resource_allocation
        })

    def _calculate_priority_score(self, incident: Dict) -> Dict:
        """Calculate priority score"""

        # Severity score
        severity_scores = {
            "Critical": 100,
            "High": 70,
            "Medium": 40,
            "Low": 20,
            "Informational": 10
        }

        base_score = severity_scores.get(incident.get("Severity", "Medium"), 40)

        # Time weight (higher priority for older incidents)
        time_generated = incident.get("TimeGenerated")
        if time_generated:
            age_hours = (datetime.utcnow() - time_generated.replace(tzinfo=None)).total_seconds() / 3600
            time_weight = min(age_hours * 2, 30)  # 최대 30점
        else:
            time_weight = 0

        # Alert count weight
        alerts_count = incident.get("AlertsCount", 0)
        alerts_weight = min(alerts_count * 5, 20)  # 최대 20점

        # Unassigned weight
        owner = incident.get("Owner")
        owner_weight = 10 if not owner or owner == "Unassigned" else 0

        # Total score
        total_score = base_score + time_weight + alerts_weight + owner_weight

        # Recommended action
        if total_score >= 120:
            recommended_action = "Immediate response - highest priority"
            rank = "P1"
        elif total_score >= 80:
            recommended_action = "Rapid response - high priority"
            rank = "P2"
        elif total_score >= 50:
            recommended_action = "Standard response - medium priority"
            rank = "P3"
        else:
            recommended_action = "Standard handling - low priority"
            rank = "P4"

        return {
            "score": round(total_score, 1),
            "rank": rank,
            "recommended_action": recommended_action
        }

    def _recommend_resource_allocation(self, incidents: List[Dict]) -> Dict:
        """Recommend resource allocation"""

        p1_count = sum(1 for i in incidents if i["priority_rank"] <= 3)
        p2_count = sum(1 for i in incidents if 4 <= i["priority_rank"] <= 10)
        p3_count = sum(1 for i in incidents if i["priority_rank"] > 10)

        recommendations = []

        if p1_count > 0:
            recommendations.append(f"P1 인시던트 {p1_count}개 - Senior 분석가 {p1_count}명 배정")

        if p2_count > 0:
            analysts_needed = max(1, p2_count // 2)
            recommendations.append(f"P2 인시던트 {p2_count}개 - 분석가 {analysts_needed}명 배정")

        if p3_count > 5:
            recommendations.append(f"P3 인시던트 {p3_count}개 - 티어1 분석가 또는 자동화 처리")

        return {
            "p1_incidents": p1_count,
            "p2_incidents": p2_count,
            "p3_incidents": p3_count,
            "total_analysts_recommended": p1_count + max(1, p2_count // 2),
            "recommendations": recommendations
        }


# Register tools
def register_tools(mcp: FastMCP):
    """Response Coordinator Register tools"""
    BusinessImpactAssessmentTool.register(mcp)
    ResponsePlanGenerationTool.register(mcp)
    ResourcePrioritizationTool.register(mcp)
