"""
Threat Intelligence Analyst Tools
Threat event analysis, MITRE ATT&CK mapping, IoC extraction and enrichment
"""

import sys
import os

# Add parent directory to Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from typing import Dict, List, Any
from datetime import datetime, timedelta

from mcp.server.fastmcp import Context, FastMCP
from tools.base import MCPToolBase
from utilities.task_manager import run_in_thread
from utilities.cache import get_global_cache
from intelligence.mitre_attck import get_mitre_framework
from intelligence.ioc_enrichment import IoCExtractor, IoCEnricher, correlate_iocs


class ThreatEventAnalysisTool(MCPToolBase):
    """Threat event deep analysis tool"""

    name = "threat_event_analysis"
    description = """
    Deep analysis of threat events with MITRE ATT&CK mapping, IoC extraction, and threat context.
    Parameters:
    - incident_number: Incident number (optional)
    - alert_id: Alert ID (optional)
    - timespan: Analysis period (default: 24h)
    """

    async def run(self, ctx: Context, **kwargs) -> Dict:
        incident_number = self._extract_param(kwargs, "incident_number")
        alert_id = self._extract_param(kwargs, "alert_id")
        timespan = self._extract_param(kwargs, "timespan", "24h")

        logs_client, workspace_id = self.get_logs_client_and_workspace(ctx)
        mitre = get_mitre_framework()
        ioc_extractor = IoCExtractor()

        # Query events to analyze
        if incident_number:
            query = f"""
            SecurityIncident
            | where IncidentNumber == {incident_number}
            | project TimeGenerated, IncidentNumber, Title, Severity, Status,
                      Description, AdditionalData, AlertIds
            """
        elif alert_id:
            query = f"""
            SecurityAlert
            | where SystemAlertId == '{alert_id}'
            | project TimeGenerated, AlertName, AlertSeverity, Description,
                      Tactics, Techniques, Entities, ExtendedProperties
            """
        else:
            # Analyze recent High/Critical alerts
            query = f"""
            SecurityAlert
            | where TimeGenerated > ago({timespan})
            | where AlertSeverity in ("High", "Critical")
            | order by TimeGenerated desc
            | take 10
            | project TimeGenerated, SystemAlertId, AlertName, AlertSeverity,
                      Description, Tactics, Techniques, Entities
            """

        # Execute query
        timespan_obj = self._parse_timespan(timespan)
        response = await run_in_thread(
            logs_client.query_workspace,
            workspace_id=workspace_id,
            query=query,
            timespan=timespan_obj,
            name="threat_event_analysis"
        )

        if not response.rows:
            return self.wrap_result({
                "message": "No events to analyze.",
                "events_analyzed": 0
            })

        # Analyze events
        analyzed_events = []
        all_iocs = []

        for row in response.rows:
            event_data = {col.name: val for col, val in zip(response.columns, row)}

            # MITRE ATT&CK 매핑
            mitre_mapping = mitre.map_alert_to_mitre(event_data)

            # IoC 추출
            iocs = ioc_extractor.extract_from_alert(event_data)
            all_iocs.extend(iocs)

            analyzed_events.append({
                "event_id": event_data.get("SystemAlertId") or event_data.get("IncidentNumber"),
                "name": event_data.get("AlertName") or event_data.get("Title"),
                "severity": event_data.get("AlertSeverity") or event_data.get("Severity"),
                "timestamp": event_data.get("TimeGenerated").isoformat() if event_data.get("TimeGenerated") else None,
                "mitre_mapping": mitre_mapping,
                "iocs_count": len(iocs),
                "description": event_data.get("Description", "")[:200]  # 200자 제한
            })

        # IoC correlation analysis
        ioc_correlation = correlate_iocs(all_iocs)

        # Threat summary
        threat_summary = self._generate_threat_summary(analyzed_events, mitre_mapping, ioc_correlation)

        return self.wrap_result({
            "analysis_timestamp": datetime.utcnow().isoformat(),
            "events_analyzed": len(analyzed_events),
            "threat_summary": threat_summary,
            "events": analyzed_events,
            "ioc_statistics": ioc_correlation["statistics"],
            "recommendations": self._generate_recommendations(analyzed_events, mitre_mapping)
        })

    def _generate_threat_summary(self, events: List[Dict], mitre_mapping: Dict, ioc_stats: Dict) -> Dict:
        """Threat summary 생성"""
        severity_counts = {}
        tactics_set = set()
        techniques_set = set()

        for event in events:
            severity = event.get("severity", "Unknown")
            severity_counts[severity] = severity_counts.get(severity, 0) + 1

            mitre = event.get("mitre_mapping", {})
            for tactic in mitre.get("tactics", []):
                tactics_set.add(tactic["name"])
            for technique in mitre.get("techniques", []):
                techniques_set.add(technique["id"])

        return {
            "severity_distribution": severity_counts,
            "unique_tactics": list(tactics_set),
            "unique_techniques": list(techniques_set),
            "total_iocs": ioc_stats.get("statistics", {}).get("total_iocs", 0),
            "kill_chain_phase": mitre_mapping.get("kill_chain_phase", "Unknown")
        }

    def _generate_recommendations(self, events: List[Dict], mitre_mapping: Dict) -> List[str]:
        """Generate response recommendations"""
        recommendations = []

        # Severity-based recommendations
        high_severity_count = sum(1 for e in events if e.get("severity") in ["High", "Critical"])
        if high_severity_count > 5:
            recommendations.append("⚠️ 다수의 High/Critical 알림 감지 - 즉각적인 조사 필요")

        # Kill Chain phase-based recommendations
        phase = mitre_mapping.get("kill_chain_phase", "")
        if "Exfiltration" in phase or "Impact" in phase:
            recommendations.append("🚨 Data exfiltration/impact phase - urgent response required")
        elif "Lateral Movement" in phase:
            recommendations.append("⚠️ Lateral movement detected - need to block further spread")
        elif "Initial Access" in phase:
            recommendations.append("🔍 Initial infiltration detected - analyze and block entry point")

        # Technique-based recommendations
        for event in events:
            techniques = event.get("mitre_mapping", {}).get("techniques", [])
            for tech in techniques:
                if "Credential" in tech.get("name", ""):
                    recommendations.append("🔐 Credential theft attempt - account security enhancement needed")
                    break

        if not recommendations:
            recommendations.append("✅ Continue standard monitoring and analysis")

        return recommendations


class MITREAttackMappingTool(MCPToolBase):
    """MITRE ATT&CK framework mapping tool"""

    name = "mitre_attack_mapping"
    description = """
    Map Sentinel events to MITRE ATT&CK framework.
    Parameters:
    - tactics: Tactics list (optional)
    - techniques: Techniques list (optional)
    - suggest_next: Suggest next expected techniques (default: false)
    """

    async def run(self, ctx: Context, **kwargs) -> Dict:
        tactics = self._extract_param(kwargs, "tactics", [])
        techniques = self._extract_param(kwargs, "techniques", [])
        suggest_next = self._extract_param(kwargs, "suggest_next", False)

        mitre = get_mitre_framework()

        result = {
            "mapped_tactics": [],
            "mapped_techniques": [],
        }

        # Map tactics
        if tactics:
            for tactic_id in tactics:
                tactic = mitre.get_tactic(tactic_id)
                if tactic:
                    result["mapped_tactics"].append({
                        "id": tactic.tactic_id,
                        "name": tactic.name,
                        "description": tactic.description,
                        "technique_count": len(tactic.techniques)
                    })

        # Map techniques
        if techniques:
            for tech_id in techniques:
                tech_id = tech_id.split(".")[0]  # Remove sub-techniques
                technique = mitre.get_technique(tech_id)
                if technique:
                    result["mapped_techniques"].append({
                        "id": technique.technique_id,
                        "name": technique.name,
                        "description": technique.description,
                        "tactics": technique.tactics,
                        "data_sources": technique.data_sources
                    })

        # Predict next techniques
        if suggest_next and techniques:
            suggestions = mitre.suggest_next_techniques(techniques)
            result["next_technique_suggestions"] = suggestions

        return self.wrap_result(result)


class IoCExtractionTool(MCPToolBase):
    """IoC (Indicators of Compromise) extraction and analysis tool"""

    name = "ioc_extraction"
    description = """
    Extract and analyze IoCs like IP, domain, hash, URL from log data.
    Parameters:
    - query: KQL 쿼리 (선택)
    - table_name: Table name (default: SecurityAlert)
    - timespan: Analysis period (default: 24h)
    - enrich: Whether to perform IoC enrichment (default: true)
    """

    async def run(self, ctx: Context, **kwargs) -> Dict:
        query = self._extract_param(kwargs, "query")
        table_name = self._extract_param(kwargs, "table_name", "SecurityAlert")
        timespan = self._extract_param(kwargs, "timespan", "24h")
        do_enrich = self._extract_param(kwargs, "enrich", True)

        logs_client, workspace_id = self.get_logs_client_and_workspace(ctx)
        extractor = IoCExtractor()
        enricher = IoCEnricher()

        # Default query
        if not query:
            query = f"""
            {table_name}
            | where TimeGenerated > ago({timespan})
            | project TimeGenerated, AlertName, Description, Entities, ExtendedProperties
            | take 100
            """

        # Execute query
        timespan_obj = self._parse_timespan(timespan)
        response = await run_in_thread(
            logs_client.query_workspace,
            workspace_id=workspace_id,
            query=query,
            timespan=timespan_obj,
            name="ioc_extraction"
        )

        if not response.rows:
            return self.wrap_result({
                "message": "No data to extract.",
                "iocs": []
            })

        # IoC 추출
        all_iocs = []
        for row in response.rows:
            event_data = {col.name: val for col, val in zip(response.columns, row)}
            iocs = extractor.extract_from_alert(event_data)
            all_iocs.extend(iocs)

        # Enrichment
        if do_enrich:
            for ioc in all_iocs:
                await enricher.enrich_ioc(ioc)

        # Format results
        formatted_iocs = []
        for ioc in all_iocs:
            formatted_iocs.append({
                "type": ioc.ioc_type,
                "value": ioc.value,
                "confidence": ioc.confidence,
                "severity": ioc.severity,
                "threat_types": ioc.threat_types,
                "sources": ioc.sources,
                "first_seen": ioc.first_seen.isoformat() if ioc.first_seen else None,
                "last_seen": ioc.last_seen.isoformat() if ioc.last_seen else None,
                "context": ioc.context
            })

        # Correlation analysis
        correlation = correlate_iocs(all_iocs)

        return self.wrap_result({
            "total_iocs": len(all_iocs),
            "iocs": formatted_iocs,
            "statistics": correlation["statistics"],
            "enrichment_applied": do_enrich
        })


class ThreatActorProfilingTool(MCPToolBase):
    """Threat actor profiling tool"""

    name = "threat_actor_profiling"
    description = """
    Generate threat actor profile based on observed TTPs.
    Parameters:
    - tactics: List of observed tactics
    - techniques: List of observed techniques
    - iocs: List of observed IoCs (optional)
    """

    async def run(self, ctx: Context, **kwargs) -> Dict:
        tactics = self._extract_param(kwargs, "tactics", [])
        techniques = self._extract_param(kwargs, "techniques", [])
        iocs = self._extract_param(kwargs, "iocs", [])

        mitre = get_mitre_framework()

        # Generate profile based on TTPs
        profile = {
            "attack_sophistication": self._assess_sophistication(tactics, techniques),
            "primary_objectives": self._identify_objectives(tactics),
            "attack_pattern": self._analyze_attack_pattern(techniques),
            "infrastructure": self._analyze_infrastructure(iocs),
            "recommended_attribution": "Unknown",  # 실제로는 위협 인텔 DB와 매칭
            "similar_campaigns": []  # 실제로는 과거 캠페인과 유사도 분석
        }

        # Kill Chain 진행도
        observed_tactics_full = []
        for tech_id in techniques:
            tech_id = tech_id.split(".")[0]
            tech = mitre.get_technique(tech_id)
            if tech:
                observed_tactics_full.extend(tech.tactics)

        profile["kill_chain_progress"] = self._calculate_kill_chain_progress(
            list(set(tactics + observed_tactics_full))
        )

        return self.wrap_result(profile)

    def _assess_sophistication(self, tactics: List[str], techniques: List[str]) -> str:
        """Assess attack sophistication"""
        # 기법 수와 다양성 기반 평가
        if len(techniques) > 10 and len(tactics) > 5:
            return "High - APT-level"
        elif len(techniques) > 5:
            return "Medium - Organized attack"
        else:
            return "Low - Basic attack"

    def _identify_objectives(self, tactics: List[str]) -> List[str]:
        """Identify attack objectives"""
        objectives = []

        tactic_names = [t.lower() for t in tactics]

        if any("exfiltration" in t for t in tactic_names):
            objectives.append("Data exfiltration")
        if any("impact" in t for t in tactic_names):
            objectives.append("System destruction/ransomware")
        if any("credential" in t for t in tactic_names):
            objectives.append("자격증명 탈취")
        if any("persistence" in t for t in tactic_names):
            objectives.append("Long-term persistence")

        return objectives if objectives else ["Reconnaissance and intelligence gathering"]

    def _analyze_attack_pattern(self, techniques: List[str]) -> Dict:
        """Analyze attack pattern"""
        return {
            "technique_count": len(techniques),
            "unique_techniques": len(set(techniques)),
            "common_techniques": techniques[:5] if techniques else []
        }

    def _analyze_infrastructure(self, iocs: List[str]) -> Dict:
        """Analyze attack infrastructure"""
        return {
            "ioc_count": len(iocs),
            "infrastructure_type": "Requires verification",
            "ip_ranges": [],
            "domains": []
        }

    def _calculate_kill_chain_progress(self, tactics: List[str]) -> Dict:
        """Calculate Kill Chain progress"""
        all_phases = [
            "Initial Access", "Execution", "Persistence",
            "Privilege Escalation", "Defense Evasion", "Credential Access",
            "Discovery", "Lateral Movement", "Collection",
            "Exfiltration", "Command and Control", "Impact"
        ]

        completed_phases = []
        for tactic_id in tactics:
            mitre = get_mitre_framework()
            tactic = mitre.get_tactic(tactic_id)
            if tactic:
                completed_phases.append(tactic.name)

        progress_pct = (len(completed_phases) / len(all_phases) * 100) if all_phases else 0

        return {
            "completed_phases": completed_phases,
            "total_phases": len(all_phases),
            "progress_percentage": round(progress_pct, 2)
        }


# Tool registration function
def register_tools(mcp: FastMCP):
    """Threat Intelligence Analyst Register tools"""
    ThreatEventAnalysisTool.register(mcp)
    MITREAttackMappingTool.register(mcp)
    IoCExtractionTool.register(mcp)
    ThreatActorProfilingTool.register(mcp)
