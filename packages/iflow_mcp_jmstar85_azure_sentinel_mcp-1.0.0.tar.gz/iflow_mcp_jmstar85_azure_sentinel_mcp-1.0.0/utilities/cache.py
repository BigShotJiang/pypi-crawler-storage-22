"""
Thread-safe caching utility
API call optimization with TTL-based cache
"""

import logging
from threading import RLock
from typing import Any, Optional
from cachetools import TTLCache

logger = logging.getLogger(__name__)


class Cache:
    """TTL-based thread-safe cache"""

    def __init__(self, ttl: int = 600, max_size: int = 1024):
        """
        Args:
            ttl: Time-to-live (초) - 기본 10분
            max_size: Maximum number of cache entries
        """
        self._cache = TTLCache(maxsize=max_size, ttl=ttl)
        self._lock = RLock()
        self._ttl = ttl
        self._max_size = max_size
        logger.info(f"Cache initialized: TTL={ttl}s, MaxSize={max_size}")

    def get(self, key: str) -> Optional[Any]:
        """
        Get value from cache

        Args:
            key: Cache key

        Returns:
            Cached value or None
        """
        with self._lock:
            value = self._cache.get(key, None)
            if value is not None:
                logger.debug(f"Cache HIT: {key}")
            else:
                logger.debug(f"Cache MISS: {key}")
            return value

    def set(self, key: str, value: Any) -> None:
        """
        Store value in cache

        Args:
            key: Cache key
            value: Value to store
        """
        with self._lock:
            self._cache[key] = value
            logger.debug(f"Cache SET: {key}")

    def delete(self, key: str) -> bool:
        """
        Delete item from cache

        Args:
            key: Key to delete

        Returns:
            Whether deletion succeeded
        """
        with self._lock:
            if key in self._cache:
                del self._cache[key]
                logger.debug(f"Cache DELETE: {key}")
                return True
            return False

    def clear(self) -> None:
        """Clear entire cache"""
        with self._lock:
            self._cache.clear()
            logger.info("Cache cleared")

    def get_stats(self) -> dict:
        """Cache statistics"""
        with self._lock:
            return {
                "size": len(self._cache),
                "max_size": self._max_size,
                "ttl": self._ttl
            }


# Global cache instance (singleton pattern)
_global_cache = None


def get_global_cache(ttl: int = 600, max_size: int = 1024) -> Cache:
    """
    Get global cache instance

    Args:
        ttl: Time-to-live (초)
        max_size: Maximum number of cache entries

    Returns:
        Cache 인스턴스
    """
    global _global_cache
    if _global_cache is None:
        _global_cache = Cache(ttl=ttl, max_size=max_size)
    return _global_cache
