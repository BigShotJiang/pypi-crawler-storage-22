"""
Asynchronous task management utility
Safely execute Azure SDK synchronous calls in async context
"""

import asyncio
import logging
from typing import Any, Callable, Optional, Set, TypeVar

logger = logging.getLogger(__name__)

# Track active tasks
active_tasks: Set[asyncio.Task] = set()

R = TypeVar('R')


async def run_in_thread(
    func: Callable[..., R],
    *args: Any,
    timeout: Optional[float] = 60.0,
    name: Optional[str] = None,
    **kwargs: Any,
) -> R:
    """
    Execute synchronous function in thread pool (for Azure SDK calls)

    Args:
        func: Synchronous function to execute
        *args: Positional arguments
        timeout: Timeout (seconds)
        name: Task name
        **kwargs: Keyword arguments

    Returns:
        Function execution result

    Raises:
        asyncio.TimeoutError: When timeout occurs
        Exception: Exception occurred during function execution
    """
    async def thread_task():
        return await asyncio.to_thread(func, *args, **kwargs)

    task = create_tracked_task(thread_task(), timeout=timeout, name=name)
    return await task


def create_tracked_task(
    coro,
    timeout: Optional[float] = None,
    name: Optional[str] = None
) -> asyncio.Task:
    """
    Create trackable task

    Args:
        coro: Coroutine
        timeout: Timeout (seconds)
        name: Task name

    Returns:
        Created task
    """
    if timeout:
        coro = asyncio.wait_for(coro, timeout=timeout)

    task = asyncio.create_task(coro, name=name)
    active_tasks.add(task)
    task.add_done_callback(active_tasks.discard)

    # Logging for debugging
    if name:
        logger.debug(f"Task created: {name}")

    return task


async def cleanup_tasks():
    """Clean up active tasks (called on shutdown)"""
    if not active_tasks:
        return

    logger.info(f"🧹 Cleaning up {len(active_tasks)} active tasks...")

    # Cancel all tasks
    for task in active_tasks:
        if not task.done():
            task.cancel()

    # Wait for completion
    await asyncio.gather(*active_tasks, return_exceptions=True)
    logger.info("✅ Task cleanup completed")


async def run_parallel_tasks(*coros, return_exceptions: bool = True):
    """
    여러 Coroutine을 병렬로 실행

    Args:
        *coros: 실행할 Coroutine들
        return_exceptions: Whether to return exceptions

    Returns:
        각 Coroutine의 실행 결과 리스트
    """
    tasks = [create_tracked_task(coro) for coro in coros]
    return await asyncio.gather(*tasks, return_exceptions=return_exceptions)
