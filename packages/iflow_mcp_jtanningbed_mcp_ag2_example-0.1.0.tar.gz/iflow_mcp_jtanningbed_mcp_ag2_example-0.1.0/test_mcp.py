#!/usr/bin/env python3
import asyncio
import json
import sys

async def test_mcp_server():
    """Test MCP server"""
    cmd = ["/app/auto-mcp-upload/.venv/bin/mcp_local_file_server", "--path", "/tmp/test_mcp"]

    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )

    try:
        # Initialize
        init_req = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {"tools": {}},
                "clientInfo": {"name": "test", "version": "1.0"}
            }
        }
        proc.stdin.write((json.dumps(init_req) + "\n").encode())
        await proc.stdin.drain()

        # Read init response
        line = await asyncio.wait_for(proc.stdout.readline(), timeout=5)
        if line:
            init_response = json.loads(line.decode().strip())
            print("Init Response:", json.dumps(init_response, indent=2))

        # List tools
        tools_req = {
            "jsonrpc": "2.0",
            "id": 2,
            "method": "tools/list",
            "params": {}
        }
        proc.stdin.write((json.dumps(tools_req) + "\n").encode())
        await proc.stdin.drain()

        # Read tools response
        line = await asyncio.wait_for(proc.stdout.readline(), timeout=5)
        if line:
            response = json.loads(line.decode().strip())
            print("\nTools Response:", json.dumps(response, indent=2))

            if "result" in response and "tools" in response["result"]:
                tools = response["result"]["tools"]
                print(f"\n✅ MCP服务器正常运行！发现 {len(tools)} 个工具:")
                for tool in tools:
                    print(f"  - {tool['name']}: {tool.get('description', 'N/A')}")
                return True
    except asyncio.TimeoutError:
        print("❌ 超时")
    except Exception as e:
        print(f"❌ 错误: {e}")
    finally:
        try:
            proc.terminate()
            await proc.wait()
        except:
            pass

    return False

if __name__ == "__main__":
    success = asyncio.run(test_mcp_server())
    sys.exit(0 if success else 1)