from setuptools import setup, find_packages

setup(
    name="iflow-mcp_kahnwong-agent-with-mcp-adk",
    version="0.1.1",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    python_requires=">=3.11",
    install_requires=[
        "fastapi>=0.120.1",
        "google-adk[a2a]>=1.17.0",
        "google-generativeai>=0.8.3",
        "line-bot-sdk>=3.20.0",
        "python-dotenv>=1.2.1",
        "requests>=2.32.5",
        "uvicorn>=0.38.0",
        "fastmcp>=2.14.5",
        "beautifulsoup4>=4.14.3",
        "html2text>=2024.2.26",
    ],
    entry_points={
        "console_scripts": [
            "iflow-mcp-kahnwong-agent-with-mcp-adk=mcp_server:main",
        ],
    },
    include_package_data=True,
)