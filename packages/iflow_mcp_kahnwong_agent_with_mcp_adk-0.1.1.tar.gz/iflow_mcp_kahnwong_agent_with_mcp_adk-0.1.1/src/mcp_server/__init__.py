import os
from .tools import mcp

__all__ = ['mcp']

def main():
    """Main entry point for running the MCP server"""
    transport = os.getenv("MCP_TRANSPORT", "stdio")
    if transport == "sse":
        mcp.run(transport="sse", host="0.0.0.0", port=int(os.getenv("MCP_PORT", "8000")))
    else:
        mcp.run(transport="stdio")