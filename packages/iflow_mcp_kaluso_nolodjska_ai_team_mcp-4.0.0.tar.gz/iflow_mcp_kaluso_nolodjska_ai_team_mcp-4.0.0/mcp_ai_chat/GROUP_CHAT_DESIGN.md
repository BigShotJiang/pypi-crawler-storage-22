# 群聊功能设计文档

> **创建时间**: 2025-11-10  
> **状态**: 📋 设计方案

---

## 🎯 设计目标

1. **项目协作**：按项目创建群组，相关AI集中讨论
2. **消息组织**：按群组分类消息，便于追踪
3. **简单实用**：保持简单，不过度设计
4. **向后兼容**：不影响现有的私聊功能

---

## 📋 功能设计

### 核心功能

1. **创建群组** (`create_group`)
   - 创建项目群组
   - 指定群组名称、描述、成员

2. **加入群组** (`join_group`)
   - AI主动加入群组

3. **发送群组消息** (`send_group_message`)
   - 在群组中发送消息
   - 所有群组成员都能收到

4. **接收群组消息** (`receive_group_messages`)
   - 接收特定群组的消息
   - 支持未读过滤

5. **列出群组** (`list_groups`)
   - 列出所有群组
   - 显示群组成员

6. **离开群组** (`leave_group`)
   - 退出群组

---

## 🔧 数据结构

### 群组信息 (`groups.json`)

```json
{
  "group_id": {
    "name": "知识库本地文件夹挂载项目",
    "description": "实现知识库本地文件夹挂载功能",
    "creator": "manager",
    "creator_session_id": "会话ID",
    "members": ["manager", "a", "b", "c", "d"],
    "created_at": "2025-11-10T12:00:00",
    "active": true
  }
}
```

### 消息格式（扩展）

```json
{
  "id": "消息ID",
  "sender": "发送者",
  "sender_role": "角色",
  "sender_session_id": "会话ID",
  "type": "group",  // "private" 或 "group"
  "group_id": "群组ID",  // 如果是群组消息
  "recipients": ["接收者列表"],  // 私聊时使用
  "content": "消息内容",
  "timestamp": "时间戳",
  "read": {
    "成员1": false,
    "成员2": false
  }
}
```

---

## 💡 使用场景

### 场景1: 创建项目群组

**产品经理**:
```
create_group({
  "name": "知识库本地文件夹挂载项目",
  "description": "实现知识库本地文件夹挂载功能，参考Cursor IDE",
  "members": ["manager", "a", "b", "c", "d"]
})
```

### 场景2: 在群组中讨论

**员工A**:
```
send_group_message({
  "group_id": "GROUP_20251110_001",
  "message": "前端文件选择器已完成，请后端提供API接口"
})
```

**员工B**:
```
send_group_message({
  "group_id": "GROUP_20251110_001",
  "message": "API接口已实现，文档见 docs/api_documentation/KNOWLEDGE_API.md"
})
```

### 场景3: 接收群组消息

**员工C**:
```
receive_group_messages({
  "group_id": "GROUP_20251110_001",
  "unread_only": true
})
```

---

## 🔄 与私聊的关系

### 私聊 vs 群聊

- **私聊** (`send_message`): 点对点或一对多，适合临时沟通
- **群聊** (`send_group_message`): 项目讨论，适合长期协作

### 消息接收

- **私聊消息**: `receive_messages({"recipient": "a"})`
- **群组消息**: `receive_group_messages({"group_id": "xxx"})`
- **所有消息**: `receive_messages({"recipient": "*"})` 包含私聊和群组

---

## ✅ 实施建议

### 优先级

1. **P0**: 创建群组、发送群组消息、接收群组消息
2. **P1**: 列出群组、加入/离开群组
3. **P2**: 群组管理（邀请、踢出成员）

### 实施步骤

1. 扩展消息格式，添加 `type` 和 `group_id` 字段
2. 实现群组存储（`groups.json`）
3. 实现群组管理工具
4. 更新消息接收逻辑，支持群组过滤
5. 更新文档

---

## 📊 优势分析

### 优势

1. ✅ **项目协作更清晰**：按项目建群，讨论集中
2. ✅ **消息组织更好**：按群组分类，便于追踪
3. ✅ **减少重复**：不需要每次列出所有接收者
4. ✅ **上下文连贯**：群组内讨论有更好的连续性
5. ✅ **符合实际场景**：类似真实工作中的项目群

### 注意事项

1. ⚠️ **不要过度设计**：保持简单实用
2. ⚠️ **向后兼容**：不影响现有私聊功能
3. ⚠️ **消息过滤**：需要同时支持私聊和群组消息过滤

---

**文档版本**: v1.0.0  
**创建时间**: 2025-11-10  
**状态**: 📋 设计方案

