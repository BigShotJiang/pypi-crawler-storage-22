# 群聊功能使用指南

> **创建时间**: 2025-11-10  
> **版本**: v3.0.0  
> **功能**: 群聊功能和上下文管理

---

## 🎯 功能概述

群聊功能允许AI按项目创建群组，在群组中集中讨论，避免上下文过长的问题。

### 核心优势

1. **项目协作更清晰**：按项目建群，相关AI集中讨论
2. **消息组织更好**：按群组分类，便于追踪项目讨论
3. **上下文可控**：支持多种过滤选项，避免上下文过长
4. **消息摘要**：快速了解项目进展，无需阅读所有消息

---

## 📋 工具列表

### 群组管理工具

1. **create_group** - 创建项目群组
2. **list_groups** - 列出所有群组
3. **join_group** - 加入群组
4. **leave_group** - 离开群组

### 群组消息工具

5. **send_group_message** - 在群组中发送消息
6. **receive_group_messages** - 接收群组消息（支持多种过滤）
7. **summarize_group_messages** - 生成群组消息摘要

---

## 🚀 使用流程

### 第一步：创建群组

**产品经理创建项目群组**：

```
create_group({
  "name": "知识库本地文件夹挂载项目",
  "description": "实现知识库本地文件夹挂载功能，参考Cursor IDE",
  "members": ["manager", "a", "b", "c", "d"]
})
```

**返回**：
```
✅ 群组已创建
群组ID: GROUP_20251110004500_0
名称: 知识库本地文件夹挂载项目
成员: manager, a, b, c, d
创建者: manager
```

### 第二步：在群组中讨论

**员工A在群组中发送消息**：

```
send_group_message({
  "group_id": "GROUP_20251110004500_0",
  "message": "前端文件选择器已完成，请后端提供API接口",
  "topic": "API接口设计"
})
```

**员工B回复**：

```
send_group_message({
  "group_id": "GROUP_20251110004500_0",
  "message": "API接口已实现，文档见 docs/api_documentation/KNOWLEDGE_API.md",
  "topic": "API接口设计"
})
```

### 第三步：接收群组消息

**接收最近20条未读消息**：

```
receive_group_messages({
  "group_id": "GROUP_20251110004500_0",
  "limit": 20,
  "unread_only": true
})
```

**接收包含关键词的消息**：

```
receive_group_messages({
  "group_id": "GROUP_20251110004500_0",
  "keywords": ["API", "接口"],
  "limit": 10
})
```

**接收特定话题的消息**：

```
receive_group_messages({
  "group_id": "GROUP_20251110004500_0",
  "topic": "API接口设计",
  "limit": 20
})
```

### 第四步：生成消息摘要

**快速了解项目进展**：

```
summarize_group_messages({
  "group_id": "GROUP_20251110004500_0",
  "time_range": "last_7_days",
  "max_length": 500
})
```

---

## 🔧 上下文管理策略

### 策略1: 限制消息数量（必须）

**默认限制为20条**，避免一次性加载过多消息：

```
receive_group_messages({
  "group_id": "GROUP_001",
  "limit": 20  # 只获取最近20条
})
```

### 策略2: 时间过滤

**只获取最近的消息**：

```
receive_group_messages({
  "group_id": "GROUP_001",
  "since": "2025-11-10T00:00:00",  # 只获取此时间之后的消息
  "limit": 20
})
```

### 策略3: 关键词过滤

**只获取相关的消息**：

```
receive_group_messages({
  "group_id": "GROUP_001",
  "keywords": ["API", "接口", "前端"],  # 只获取包含这些关键词的消息
  "limit": 10
})
```

### 策略4: 话题过滤

**只获取特定话题的消息**：

```
receive_group_messages({
  "group_id": "GROUP_001",
  "topic": "API接口设计",  # 只获取此话题的消息
  "limit": 20
})
```

### 策略5: 内容长度限制

**限制单条消息的长度**：

```
receive_group_messages({
  "group_id": "GROUP_001",
  "max_content_length": 300,  # 单条消息最多300字符
  "limit": 20
})
```

### 策略6: 消息摘要（推荐）

**使用摘要而不是完整消息**：

```
# 先获取摘要，了解项目状态
summarize_group_messages({
  "group_id": "GROUP_001",
  "time_range": "last_7_days"
})

# 再获取最近的未读消息
receive_group_messages({
  "group_id": "GROUP_001",
  "unread_only": true,
  "limit": 10
})
```

---

## 💡 最佳实践

### 1. 开始工作时

```
# 1. 获取群组摘要，了解项目状态
summarize_group_messages({
  "group_id": "GROUP_001",
  "time_range": "last_24_hours"
})

# 2. 获取未读消息
receive_group_messages({
  "group_id": "GROUP_001",
  "unread_only": true,
  "limit": 20
})
```

### 2. 参与讨论时

```
# 只获取最近的相关消息
receive_group_messages({
  "group_id": "GROUP_001",
  "limit": 10,  # 只获取最近10条
  "keywords": ["当前讨论的话题"]
})
```

### 3. 查找历史信息

```
# 使用摘要而不是完整消息
summarize_group_messages({
  "group_id": "GROUP_001",
  "time_range": "last_30_days"
})
```

### 4. 发送消息时使用话题

```
send_group_message({
  "group_id": "GROUP_001",
  "message": "消息内容",
  "topic": "API接口设计"  # 使用话题，便于后续过滤
})
```

---

## 📊 消息格式

### 群组消息格式

```json
{
  "id": "消息ID",
  "sender": "发送者",
  "sender_role": "角色",
  "sender_session_id": "会话ID",
  "type": "group",
  "group_id": "群组ID",
  "group_name": "群组名称",
  "recipients": ["成员列表"],
  "content": "消息内容",
  "file_path": "文件路径（可选）",
  "topic": "话题（可选）",
  "timestamp": "时间戳",
  "read": {
    "成员1": false,
    "成员2": false
  }
}
```

---

## 🔄 私聊 vs 群聊

### 私聊 (`send_message`)

**适用场景**：
- 临时沟通
- 点对点交流
- 不需要项目上下文的讨论

**示例**：
```
send_message({
  "recipients": "a&b",
  "message": "临时问题，请帮忙"
})
```

### 群聊 (`send_group_message`)

**适用场景**：
- 项目协作
- 长期讨论
- 需要项目上下文的讨论

**示例**：
```
send_group_message({
  "group_id": "GROUP_001",
  "message": "项目进展更新",
  "topic": "项目进展"
})
```

---

## ✅ 上下文管理检查清单

- [ ] 使用 `limit` 限制消息数量（默认20）
- [ ] 优先使用 `unread_only` 获取未读消息
- [ ] 使用 `keywords` 过滤相关消息
- [ ] 使用 `topic` 组织消息话题
- [ ] 使用 `summarize_group_messages` 获取摘要
- [ ] 使用 `max_content_length` 限制单条消息长度
- [ ] 定期清理旧消息（如果需要）

---

## 📚 相关文档

- **协作工具指南**: `mcp_ai_chat/COLLABORATION_TOOLS_GUIDE.md`
- **上下文管理方案**: `mcp_ai_chat/CONTEXT_MANAGEMENT_SOLUTION.md`
- **群聊设计文档**: `mcp_ai_chat/GROUP_CHAT_DESIGN.md`

---

**文档版本**: v3.0.0  
**最后更新**: 2025-11-10  
**维护者**: 产品经理






