# MCP模块化工具定义 - 使用文档

> **版本**: v4.0.0  
> **创建时间**: 2025-11-10  
> **状态**: ✅ 已完成并验证

---

## 🎯 模块化概述

MCP服务器的工具定义已成功模块化，从单体2700+行拆分为清晰的模块结构。

### 模块结构

```
mcp_ai_chat/
├── tools/                    # 工具定义模块（共28个工具）
│   ├── __init__.py           # 汇总模块 - get_all_tools()
│   ├── message_tools.py      # 消息工具（7个）
│   ├── task_tools.py         # 任务工具（5个）
│   ├── group_tools.py        # 群组工具（11个）
│   └── system_tools.py       # 系统工具（5个）
├── core/                     # 核心模块
│   ├── storage.py            # 数据存储
│   └── session.py            # 会话管理
└── config.py                 # 配置管理
```

---

## 📦 工具分类

### 1. 消息工具（7个）- `message_tools.py`

| 工具名 | 功能 | 用途 |
|--------|------|------|
| `send_message` | 发送消息 | 向其他AI发送消息或文件 |
| `receive_messages` | 接收消息 | 接收并过滤消息 |
| `mark_messages_read` | 标记已读 | 标记消息为已读状态 |
| `request_help` | 请求帮助 | 请求其他AI协助 |
| `request_review` | 请求审查 | 请求代码审查 |
| `notify_completion` | 完成通知 | 通知任务完成情况 |
| `share_code_snippet` | 分享代码 | 分享代码片段 |

### 2. 任务工具（5个）- `task_tools.py`

| 工具名 | 功能 | 用途 |
|--------|------|------|
| `create_task` | 创建任务 | 创建协作任务 |
| `assign_task` | 分配任务 | 分配任务给其他AI |
| `update_task_status` | 更新状态 | 更新任务状态和进度 |
| `get_tasks` | 获取任务 | 查询任务列表 |
| `delete_task` | 删除任务 | 删除任务（软/硬删除） |

### 3. 群组工具（11个）- `group_tools.py`

| 工具名 | 功能 | 用途 |
|--------|------|------|
| `create_group` | 创建群组 | 创建项目群组 |
| `send_group_message` | 发送群组消息 | 在群组中发送消息（支持回复/@提醒/重要性） |
| `receive_group_messages` | 接收群组消息 | 接收并过滤群组消息 |
| `list_groups` | 列出群组 | 查看群组列表（支持预览） |
| `join_group` | 加入群组 | 加入指定群组 |
| `leave_group` | 离开群组 | 退出群组 |
| `summarize_group_messages` | 消息摘要 | 生成群组讨论摘要 |
| `get_unread_counts` | 未读统计 | 统计各群组未读消息 |
| `archive_group` | 归档群组 | 归档已完成的项目群组 |
| `pin_message` | 置顶消息 | 置顶重要消息 |
| `unpin_message` | 取消置顶 | 取消消息置顶 |

### 4. 系统工具（5个）- `system_tools.py`

| 工具名 | 功能 | 用途 |
|--------|------|------|
| `register_agent` | 注册AI | 注册AI代理并创建会话 |
| `set_employee_config` | 配置员工 | 设置.mdc文件路径 |
| `get_current_session` | 获取会话 | 查看当前会话信息 |
| `list_agents` | 列出AI | 查看所有已注册的AI |
| `standby` | 待命模式 | 进入5分钟监听状态 |

---

## 🔧 使用方法

### 方法1：导入所有工具

```python
from mcp_ai_chat.tools import get_all_tools

# 获取所有28个工具
tools = get_all_tools()

# 输出: [Tool(...), Tool(...), ...]
```

### 方法2：按分类导入

```python
from mcp_ai_chat.tools.message_tools import get_message_tools
from mcp_ai_chat.tools.task_tools import get_task_tools
from mcp_ai_chat.tools.group_tools import get_group_tools
from mcp_ai_chat.tools.system_tools import get_system_tools

# 只获取消息相关工具
message_tools = get_message_tools()  # 7个工具

# 只获取任务管理工具
task_tools = get_task_tools()  # 5个工具

# 只获取群组管理工具
group_tools = get_group_tools()  # 11个工具

# 只获取系统工具
system_tools = get_system_tools()  # 5个工具
```

### 方法3：自定义组合

```python
from mcp_ai_chat.tools import get_message_tools, get_task_tools

# 只使用消息和任务工具
my_tools = []
my_tools.extend(get_message_tools())
my_tools.extend(get_task_tools())

# 共12个工具
```

---

## 📝 工具定义格式

所有工具遵循MCP `Tool` 标准格式：

```python
from mcp.types import Tool

Tool(
    name="tool_name",
    description="工具描述",
    inputSchema={
        "type": "object",
        "properties": {
            "param1": {
                "type": "string",
                "description": "参数描述"
            }
        },
        "required": ["param1"]
    }
)
```

---

## ✅ 验证测试

运行测试脚本验证工具定义：

```bash
python test_modular_tools.py
```

**预期输出**:
```
[OK] Tool module imported successfully!
[INFO] Total tools: 28

Tool list:
  1. send_message
  2. receive_messages
  ...
  28. standby

[OK] All tool definitions validated!
```

---

## 🎯 优势对比

### 重构前
- ❌ 单文件2700+行
- ❌ 工具定义混杂在处理逻辑中
- ❌ 难以定位和维护
- ❌ 无法按需导入

### 重构后
- ✅ 4个模块文件，每个<200行
- ✅ 工具定义独立清晰
- ✅ 易于查找和修改
- ✅ 支持按需导入

---

## 📚 相关文档

- **架构设计**: `docs/architecture/MCP_MODULARIZATION_DESIGN.md`
- **重构方案**: `docs/architecture/MCP_REFACTORING_PLAN.md`
- **工具使用**: `mcp_ai_chat/COLLABORATION_TOOLS_GUIDE.md`

---

## 🔄 扩展指南

### 添加新工具

**步骤1**: 在对应的工具文件中添加工具定义

例如在 `message_tools.py` 中添加新的消息工具：

```python
def get_message_tools():
    return [
        # ... 现有工具 ...
        Tool(
            name="new_message_tool",
            description="新消息工具",
            inputSchema={
                "type": "object",
                "properties": {
                    "param": {
                        "type": "string",
                        "description": "参数描述"
                    }
                },
                "required": ["param"]
            }
        )
    ]
```

**步骤2**: 测试验证

```bash
python test_modular_tools.py
```

**步骤3**: 实现处理逻辑（在 `handlers/` 中）

---

## 🎓 最佳实践

1. **按功能分类** - 新工具放在对应的功能模块
2. **保持一致** - 遵循现有工具的格式和命名规范
3. **详细描述** - 工具和参数的描述要清晰完整
4. **验证测试** - 添加后立即运行测试脚本
5. **文档同步** - 更新本文档的工具列表

---

**文档版本**: v1.0.0  
**最后更新**: 2025-11-10  
**维护者**: 员工C（全栈开发工程师）



