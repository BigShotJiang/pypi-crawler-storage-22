# AI聊天群 MCP工具

> **用途**: 允许AI之间互相发送和接收消息，实现AI协作交流

---

## 📋 功能说明

### 核心功能

1. **发送消息** (`send_message`)
   - 向其他AI发送消息
   - 支持发送文件内容
   - 支持同时向多个AI发送

2. **接收消息** (`get_messages`)
   - 获取所有消息 (`get*`)
   - 获取特定接收者的消息
   - 支持只获取未读消息

3. **消息管理**
   - 标记消息为已读
   - 查看消息历史

4. **代理管理**
   - 注册AI代理
   - 列出所有AI代理

---

## 🚀 使用方法

### 配置MCP服务器

在 `.claude/mcp.json` 或 `C:\Users\DELL\.cursor\mcp.json` 中添加：

```json
{
  "mcpServers": {
    "ai-chat-group": {
      "command": "python",
      "args": [
        "D:/developItems/mcp_ai_chat/server.py"
      ],
      "env": {
        "MCP_AI_CHAT_AGENT_NAME": "manager"
      }
    }
  }
}
```

**注意**: 
- 将 `D:/developItems` 替换为你的实际项目路径
- 将 `MCP_AI_CHAT_AGENT_NAME` 设置为当前AI的名称（a/b/c/d/manager）

### 使用示例

#### 1. 发送消息

**格式**: `use <文件名> send@<接收者1>&<接收者2>&...`

**示例**:
```
use docs/team/TASK_EMPLOYEE_A_Frontend.md send@a&b
```

这会向员工A和员工B发送任务文档的内容。

#### 2. 发送纯文本消息

```
send_message({
  "recipients": "a&b",
  "message": "API接口已完成，请前端对接"
})
```

#### 3. 接收所有消息

**格式**: `get*`

```
get_messages({
  "recipient": "*",
  "limit": 50
})
```

#### 4. 接收特定接收者的消息

```
get_messages({
  "recipient": "a",
  "unread_only": true
})
```

#### 5. 注册AI代理

```
register_agent({
  "agent_name": "a",
  "description": "前端开发工程师"
})
```

---

## 📁 文件结构

```
mcp_ai_chat/
├── server.py          # MCP服务器主文件
├── README.md          # 使用文档
└── .mcp_ai_chat/      # 消息存储目录（自动创建）
    ├── messages.json  # 消息历史
    └── agents.json    # AI代理信息
```

---

## 🔧 消息格式

### 消息结构

```json
{
  "id": "消息ID",
  "sender": "发送者名称",
  "recipients": ["接收者1", "接收者2"],
  "content": "消息内容",
  "file_path": "文件路径（可选）",
  "timestamp": "2025-11-10T12:00:00",
  "read": {
    "接收者1": false,
    "接收者2": false
  }
}
```

## 📦 安装步骤

1. **安装依赖**
   ```bash
   pip install mcp
   ```

2. **配置MCP服务器**
   - 编辑 `C:\Users\DELL\.cursor\mcp.json` 或 `.claude/mcp.json`
   - 参考 `mcp_config_example.json` 添加配置
   - 设置 `MCP_AI_CHAT_AGENT_NAME` 环境变量

3. **重启应用**
   - 重启Cursor或Claude Desktop

4. **注册代理**
   - 使用 `register_agent` 工具注册当前AI

详细安装说明见 `install.md`

---

## 💡 使用场景

### 场景1: 任务分配

**产品经理** → **员工A** 和 **员工B**:
```
use docs/team/TASK_EMPLOYEE_A_Frontend.md send@a
use docs/team/TASK_EMPLOYEE_B_Backend.md send@b
```

### 场景2: 协作交流

**员工A** → **员工B**:
```
send_message({
  "recipients": "b",
  "message": "前端API接口已更新，请更新后端接口文档"
})
```

### 场景3: 问题反馈

**员工D** → **产品经理**:
```
send_message({
  "recipients": "manager",
  "message": "测试发现bug，详情见 docs/bugfixes/BUG_001.md"
})
```

---

## ⚙️ 环境变量

- `MCP_AI_CHAT_AGENT_NAME`: 当前AI代理名称（默认: "unknown"）

---

## 📝 注意事项

1. **消息存储**: 消息存储在 `~/.mcp_ai_chat/messages.json`
2. **代理名称**: 建议使用统一的代理名称（a/b/c/d/manager）
3. **文件路径**: 文件路径相对于工作区根目录
4. **消息限制**: 默认最多返回50条消息

---

## 🔄 更新日志

### v1.0.0 (2025-11-10)
- ✅ 初始版本
- ✅ 支持发送消息（文件/文本）
- ✅ 支持接收消息（全部/特定接收者）
- ✅ 支持标记已读
- ✅ 支持代理注册

---

**文档版本**: v1.0.0  
**最后更新**: 2025-11-10  
**维护者**: 产品经理

