"""
MCPサーバーモジュール

Model Context Protocol (MCP)に準拠したサーバーを提供します。
標準のMCP SDKを使用して実装しています。
"""

import logging
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP
from src.transcriber import Transcriber


def setup_logging():
    """ロギングの設定"""
    logger = logging.getLogger("mcp_server")
    logger.setLevel(logging.INFO)

    # ファイルハンドラの設定
    log_dir = Path("logs")
    log_dir.mkdir(exist_ok=True)
    file_handler = logging.FileHandler(log_dir / "mcp_server.log")
    file_handler.setLevel(logging.INFO)

    # フォーマッタの設定
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    file_handler.setFormatter(formatter)

    # ハンドラの追加
    logger.addHandler(file_handler)

    return logger


class MCPServer:
    """
    Model Context Protocol (MCP)に準拠したサーバークラス

    標準のMCP SDKを使用して実装しています。

    Attributes:
        transcriber: Transcriberのインスタンス
        logger: ロガー
        mcp: FastMCPインスタンス
    """

    def __init__(self, model_size="base", output_dir=None):
        """
        MCPServerのコンストラクタ

        Args:
            model_size: 使用するモデルサイズ ("tiny", "base", "small", "medium", "large")
            output_dir: 文字起こし結果の出力ディレクトリ（指定がない場合は一時ディレクトリを使用）
        """
        self.transcriber = Transcriber(model_size=model_size, output_dir=output_dir)
        self.logger = setup_logging()

        # FastMCPサーバーの初期化
        self.mcp = FastMCP(
            name="transcribe",
            instructions="音声・動画ファイルをテキストに変換するMCPサーバーです。"
        )

        # ツールの登録
        self._register_tools()

    def _register_tools(self):
        """ツールをMCPサーバーに登録します"""
        @self.mcp.tool()
        def transcribe(file_path: str, output_path: str = None) -> str:
            """
            音声・動画ファイル（mp3, mp4, wav, mov, avi）をテキストに変換します。

            Args:
                file_path: 文字起こし対象の音声・動画ファイルパス（絶対パス）
                output_path: 文字起こし結果の出力先ファイルパス（絶対パス、オプション）

            Returns:
                文字起こし結果のファイルパス

            Raises:
                FileNotFoundError: ファイルが見つからない場合
                ValueError: 無効なファイル形式の場合
                Exception: 文字起こしに失敗した場合
            """
            try:
                result_path = self.transcriber.transcribe(file_path, output_path)
                return f"音声・動画ファイルの文字起こしが完了しました。出力先: {result_path}"
            except FileNotFoundError:
                raise FileNotFoundError(f"ファイルが見つかりません: {file_path}")
            except ValueError as e:
                raise ValueError(f"無効なファイル: {str(e)}")
            except Exception as e:
                raise Exception(f"文字起こしに失敗しました: {str(e)}")

    def start(self):
        """
        サーバーを起動します。
        """
        self.logger.info("MCPサーバーを起動します...")
        self.mcp.run()