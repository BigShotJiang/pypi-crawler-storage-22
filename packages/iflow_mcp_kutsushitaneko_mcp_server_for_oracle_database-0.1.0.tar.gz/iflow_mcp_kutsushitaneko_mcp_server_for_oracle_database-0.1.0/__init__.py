"""MCP Server for Oracle Database"""
from .oracledb_mcp_server import main

__version__ = "0.1.0"
__all__ = ["main"]