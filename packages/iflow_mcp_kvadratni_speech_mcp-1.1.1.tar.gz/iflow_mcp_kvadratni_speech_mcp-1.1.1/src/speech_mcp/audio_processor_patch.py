"""
Patch for audio_processor.py to make pyaudio optional.
Add this at the beginning of the file, right after the docstring:
"""

import os
import time
import tempfile
import threading
import wave
import numpy as np
from typing import Optional, List, Tuple, Callable, Any, Dict

# Try to import pyaudio, but make it optional
try:
    import pyaudio
    PYAUDIO_AVAILABLE = True
except ImportError:
    PYAUDIO_AVAILABLE = False
    pyaudio = None

# Import the centralized logger
from speech_mcp.utils.logger import get_logger

# Get a logger for this module
logger = get_logger(__name__, component="stt")

# Then replace:
# from speech_mcp.constants import (...)
# with:
from speech_mcp.constants import (
    CHUNK, FORMAT, CHANNELS, RATE,
    SILENCE_THRESHOLD, MAX_SILENCE_DURATION, SILENCE_CHECK_INTERVAL,
    START_LISTENING_SOUND, STOP_LISTENING_SOUND,
    PYAUDIO_AVAILABLE  # Add this
)