import asyncio
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

async def main():
    # Use uvx-like approach with python -m
    server_params = StdioServerParameters(
        command="/app/auto-mcp-upload/.venv/bin/python",
        args=["server.py"],
        env={"PYTHONPATH": "/app/auto-mcp-upload/data/3608"}
    )
    
    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            
            tools = await session.list_tools()
            print(f"✅ 连接成功！发现 {len(tools.tools)} 个工具:")
            for tool in tools.tools:
                print(f"  - {tool.name}: {tool.description}")
            
            return len(tools.tools)

if __name__ == "__main__":
    count = asyncio.run(main())
    if count and count > 0:
        print(f"\n✅ 测试通过！工具数量: {count}")
    else:
        print("\n❌ 测试失败！")
        sys.exit(1)
