import asyncio
import sys
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

async def main():
    # Create server parameters for stdio
    server_params = StdioServerParameters(
        command="/app/auto-mcp-upload/.venv/bin/python",
        args=["-c", "import sys; sys.path.insert(0, '/app/auto-mcp-upload/data/3608'); from server import mcp; asyncio.run(mcp.run(transport='stdio'))"],
    )
    
    # Connect to the server
    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            # Initialize
            await session.initialize()
            
            # List tools
            tools = await session.list_tools()
            print(f"✅ 连接成功！发现 {len(tools.tools)} 个工具:")
            for tool in tools.tools:
                print(f"  - {tool.name}: {tool.description}")
            
            # Test diff_tool_rust_similar
            if any(t.name == "diff_tool_rust_similar" for t in tools.tools):
                result = await session.call_tool("diff_tool_rust_similar", {
                    "original_text": "Hello World",
                    "modified_text": "Hello Python"
                })
                print(f"\n✅ 测试 diff_tool_rust_similar 成功!")
                print(f"结果: {result.content[0].text[:200]}")

if __name__ == "__main__":
    asyncio.run(main())
