import asyncio
import sys
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

async def main():
    server_params = StdioServerParameters(
        command="/app/auto-mcp-upload/.venv/bin/python",
        args=["-c", "import sys; sys.path.insert(0, '/app/auto-mcp-upload/data/3608'); from server import main; main()"],
    )
    
    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            
            tools = await session.list_tools()
            print(f"✅ 连接成功！发现 {len(tools.tools)} 个工具:")
            for tool in tools.tools:
                print(f"  - {tool.name}: {tool.description}")
            
            if len(tools.tools) >= 2:
                print(f"\n✅ 本地测试通过！工具数量: {len(tools.tools)}")
                return 0
            else:
                print(f"\n❌ 本地测试失败！工具数量不足: {len(tools.tools)}")
                return 1

if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
