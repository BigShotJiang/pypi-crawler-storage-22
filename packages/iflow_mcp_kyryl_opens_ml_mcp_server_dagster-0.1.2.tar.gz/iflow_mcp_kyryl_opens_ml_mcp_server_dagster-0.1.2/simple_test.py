#!/usr/bin/env python3
import os
import sys

os.environ['DAGSTER_DEMO_MODE'] = 'true'
sys.path.insert(0, 'src')

try:
    from mcp_dagster.server import mcp
    
    # Try to get tools directly
    if hasattr(mcp, '_tool_manager'):
        tools = mcp._tool_manager._tools
        print(f"✅ MCP Server loaded successfully!")
        print(f"✅ Found {len(tools)} tools:")
        for name, tool in tools.items():
            print(f"  - {name}")
        sys.exit(0)
    else:
        print("❌ Could not find _tool_manager")
        sys.exit(1)
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)