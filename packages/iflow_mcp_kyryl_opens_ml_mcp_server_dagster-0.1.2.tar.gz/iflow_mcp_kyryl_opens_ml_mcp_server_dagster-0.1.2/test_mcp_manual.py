#!/usr/bin/env python3
import asyncio
import os
import sys

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Set demo mode
os.environ['DAGSTER_DEMO_MODE'] = 'true'

from mcp.server.stdio import stdio_server
from mcp.client.session import ClientSession
from mcp import StdioServerParameters


async def test_mcp():
    """Test the MCP server manually"""
    from mcp_dagster.server import mcp
    
    print("MCP Server loaded successfully!")
    print(f"Server name: {mcp.name if hasattr(mcp, 'name') else 'Unknown'}")
    
    # Get tools list
    tools = mcp._mcp_server._tools if hasattr(mcp, '_mcp_server') else []
    print(f"\nAvailable tools ({len(tools)}):")
    for tool in tools:
        name = tool.name if hasattr(tool, 'name') else str(tool)
        desc = tool.description if hasattr(tool, 'description') else 'No description'
        print(f"  - {name}: {desc}")
    
    return len(tools)


if __name__ == "__main__":
    try:
        count = asyncio.run(test_mcp())
        print(f"\n✅ MCP test passed! Found {count} tools.")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ MCP test failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)