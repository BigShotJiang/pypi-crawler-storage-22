#!/usr/bin/env python3
"""OpenGenes MCP Server - Database query interface for OpenGenes aging research data."""

import asyncio
import sqlite3
import os
from pathlib import Path
from typing import List, Dict, Any, Optional
from contextlib import asynccontextmanager
import sys
import tempfile

import typer
from fastmcp import FastMCP
from pydantic import BaseModel, Field
from eliot import start_action

# Import for accessing package data files
if sys.version_info >= (3, 9):
    from importlib import resources
else:
    import importlib_resources as resources

# Hugging Face repository configuration
HF_REPO_ID = "longevity-genie/bio-mcp-data"
HF_SUBFOLDER = "opengenes"

# Get the database path using Hugging Face Hub
def get_database_path() -> Path:
    """Get the path to the database file from Hugging Face Hub."""
    # Try Hugging Face first (will be skipped in offline environments)
    try:
        from huggingface_hub import hf_hub_download
        # Download the database from Hugging Face Hub
        db_path = hf_hub_download(
            repo_id=HF_REPO_ID,
            filename="open_genes.sqlite",
            subfolder=HF_SUBFOLDER,
            repo_type="dataset",  # Specify that this is a dataset repository
            cache_dir=None  # Use default cache directory
        )
        return Path(db_path)
    except Exception:
        pass  # Fallback to local database

    # Fallback to package data if available
    try:
        with resources.as_file(resources.files("opengenes_mcp.data") / "open_genes.sqlite") as db_path:
            return db_path
    except (FileNotFoundError, ModuleNotFoundError):
        pass  # Continue to fallback paths

    # Final fallback to development path structure
    fallback_path = Path(__file__).resolve().parent.parent.parent / "data" / "open_genes.sqlite"
    if fallback_path.exists():
        return fallback_path

    # Create a minimal test database for local testing
    test_db_path = Path(__file__).resolve().parent / "test_database.sqlite"
    if not test_db_path.exists():
        _create_test_database(test_db_path)
    return test_db_path

def _create_test_database(db_path: Path):
    """Create a minimal test database for local testing."""
    conn = sqlite3.connect(str(db_path))
    cursor = conn.cursor()

    # Create lifespan_change table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS lifespan_change (
            HGNC TEXT,
            model_organism TEXT,
            sex TEXT,
            effect_on_lifespan TEXT,
            lifespan_percent_change_mean REAL,
            lifespan_percent_change_max REAL,
            intervention_method TEXT,
            PRIMARY KEY (HGNC, model_organism)
        )
    """)

    # Create gene_criteria table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS gene_criteria (
            HGNC TEXT PRIMARY KEY,
            criteria TEXT
        )
    """)

    # Create gene_hallmarks table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS gene_hallmarks (
            HGNC TEXT PRIMARY KEY,
            "hallmarks of aging" TEXT
        )
    """)

    # Create longevity_associations table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS longevity_associations (
            HGNC TEXT,
            polymorphism_type TEXT,
            ethnicity TEXT,
            study_type TEXT,
            PRIMARY KEY (HGNC, polymorphism_type)
        )
    """)

    # Insert some test data
    cursor.execute("INSERT INTO lifespan_change VALUES (?, ?, ?, ?, ?, ?, ?)",
                  ("FOXO3", "mouse", "all", "increases lifespan", 10.5, 15.0, "overexpression"))
    cursor.execute("INSERT INTO lifespan_change VALUES (?, ?, ?, ?, ?, ?, ?)",
                  ("GHR", "mouse", "all", "increases lifespan", 25.0, 30.0, "knockout"))
    cursor.execute("INSERT INTO gene_criteria VALUES (?, ?)",
                  ("FOXO3", "longevity"))
    cursor.execute("INSERT INTO gene_hallmarks VALUES (?, ?)",
                  ("FOXO3", "mitochondrial dysfunction"))
    cursor.execute("INSERT INTO longevity_associations VALUES (?, ?, ?, ?)",
                  ("FOXO3", "SNP", "Japanese", "GWAS"))

    conn.commit()
    conn.close()

def get_prompt_content() -> str:
    """Get the content of the prompt.txt file from Hugging Face Hub."""
    try:
        from huggingface_hub import hf_hub_download
        # Download the prompt file from Hugging Face Hub
        prompt_path = hf_hub_download(
            repo_id=HF_REPO_ID,
            filename="prompt.txt",
            subfolder=HF_SUBFOLDER,
            repo_type="dataset",  # Specify that this is a dataset repository
            cache_dir=None  # Use default cache directory
        )
        with open(prompt_path, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception:
        # Fallback to package data if available
        try:
            prompt_file = resources.files("opengenes_mcp.data") / "prompt.txt"
            return prompt_file.read_text(encoding='utf-8')
        except (FileNotFoundError, ModuleNotFoundError):
            # Final fallback to development path structure
            try:
                project_root = Path(__file__).resolve().parent.parent.parent
                prompt_path = project_root / "data" / "prompt.txt"
                return prompt_path.read_text(encoding='utf-8')
            except FileNotFoundError:
                print(f"Warning: Could not load prompt file from Hugging Face or local sources.")
                return "OpenGenes Database: A comprehensive database of genes associated with aging and longevity.\n\nTables:\n- lifespan_change: Experimental lifespan data\n- gene_criteria: Aging-related gene classifications\n- gene_hallmarks: Links genes to hallmarks of aging\n- longevity_associations: Population genetics longevity data"

DB_PATH = get_database_path()

# Configuration
DEFAULT_HOST = os.getenv("MCP_HOST", "0.0.0.0")
DEFAULT_PORT = int(os.getenv("MCP_PORT", "3001"))
DEFAULT_TRANSPORT = os.getenv("MCP_TRANSPORT", "streamable-http")

class QueryResult(BaseModel):
    """Result from a database query."""
    rows: List[Dict[str, Any]] = Field(description="Query result rows")
    count: int = Field(description="Number of rows returned")
    query: str = Field(description="The SQL query that was executed")

class DatabaseManager:
    """Manages SQLite database connections and queries."""
    
    def __init__(self, db_path: Path):
        self.db_path = db_path
        if not self.db_path.exists():
            raise FileNotFoundError(f"Database not found at {self.db_path}")
    
    def execute_query(self, sql: str, params: Optional[tuple] = None) -> QueryResult:
        """Execute a read-only SQL query and return results."""
        with start_action(action_type="execute_query", sql=sql, params=params) as action:
            # Execute query using read-only connection - SQLite will enforce read-only at database level
            # Using URI format with mode=ro for true read-only access
            readonly_uri = f"file:{self.db_path}?mode=ro"
            
            try:
                with sqlite3.connect(readonly_uri, uri=True) as conn:
                    conn.row_factory = sqlite3.Row  # This allows dict-like access to rows
                    cursor = conn.cursor()
                    
                    if params:
                        cursor.execute(sql, params)
                    else:
                        cursor.execute(sql)
                    
                    rows = cursor.fetchall()
                    # Convert sqlite3.Row objects to dictionaries
                    rows_dicts = [dict(row) for row in rows]
                    
                    result = QueryResult(
                        rows=rows_dicts,
                        count=len(rows_dicts),
                        query=sql
                    )
                    
                    action.add_success_fields(rows_count=len(rows_dicts))
                    return result
            except sqlite3.OperationalError as e:
                if "readonly database" in str(e).lower():
                    error_msg = f"Write operation attempted on read-only database. Rejected query: {sql}"
                    action.log(message_type="query_rejected", error=error_msg, rejected_query=sql)
                    raise ValueError(error_msg) from e
                else:
                    # Re-raise other operational errors
                    raise

class OpenGenesMCP(FastMCP):
    """OpenGenes MCP Server with database tools that can be inherited and extended."""
    
    def __init__(
        self, 
        name: str = "OpenGenes MCP Server",
        db_path: Path = DB_PATH,
        prefix: str = "opengenes_",
        huge_query_tool: bool = False,
        **kwargs
    ):
        """Initialize the OpenGenes tools with a database manager and FastMCP functionality."""
        # Initialize FastMCP with the provided name and any additional kwargs
        super().__init__(name=name, **kwargs)
        
        # Initialize our database manager
        self.db_manager = DatabaseManager(db_path)
        
        self.prefix = prefix
        self.huge_query_tool = huge_query_tool
        # Register our tools and resources
        self._register_opengenes_tools()
        self._register_opengenes_resources()
    
    def _register_opengenes_tools(self):
        """Register OpenGenes-specific tools."""
        self.tool(name=f"{self.prefix}get_schema_info", description="Get information about the database schema")(self.get_schema_info)
        self.tool(name=f"{self.prefix}example_queries", description="Get a list of example SQL queries")(self.get_example_queries)
        description = "Query the Opengenes database that contains data about genes involved in longevity, lifespan extension experiments on model organisms, and changes in human and other organisms with aging."
        if self.huge_query_tool:
            # Load and concatenate the prompt from package data
            prompt_content = get_prompt_content().strip()
            if prompt_content:
                description = description + "\n\n" + prompt_content
            self.tool(name=f"{self.prefix}db_query", description=description)(self.db_query)
        else:
            description = description + " Before caling this tool the first time, always check tools that provide schema information and example queries."
            self.tool(name=f"{self.prefix}db_query", description=description)(self.db_query)

    
    def _register_opengenes_resources(self):
        """Register OpenGenes-specific resources."""
        
        @self.resource(f"resource://{self.prefix}db-prompt")
        def get_db_prompt() -> str:
            """
            Get the database prompt that describes the OpenGenes database schema and usage guidelines.
            
            This resource contains detailed information about:
            - Database tables and their schemas
            - Column enumerations and valid values
            - Usage guidelines for querying the database
            - Examples of common queries
            
            Returns:
                The complete database prompt text
            """
            with start_action(action_type="get_db_prompt") as action:
                try:
                    content = get_prompt_content()
                    if content:
                        action.add_success_fields(file_exists=True, content_length=len(content))
                        return content
                    else:
                        action.add_error_fields(file_exists=False, error="Prompt file not found")
                        return "Database prompt file not found."
                except Exception as e:
                    action.add_error_fields(error=str(e), error_type="file_read_error")
                    return f"Error reading prompt file: {e}"
        
        @self.resource(f"resource://{self.prefix}schema-summary")
        def get_schema_summary() -> str:
            """
            Get a summary of the OpenGenes database schema.
            
            Returns:
                A formatted summary of tables and their purposes
            """
            summary = """OpenGenes Database Schema Summary

1. lifespan_change
   - Contains experimental data about genetic interventions and their effects on lifespan
   - Key columns: HGNC (gene symbol), model_organism, sex, effect_on_lifespan
   - Includes intervention details, lifespan measurements, significance data
   - Contains data from various model organisms (mouse, C. elegans, fly, etc.)

2. gene_criteria  
   - Contains criteria classifications for aging-related genes
   - Key columns: HGNC (gene symbol), criteria
   - 12 different aging-related criteria categories
   - Links genes to specific aging research criteria

3. gene_hallmarks
   - Contains hallmarks of aging associated with specific genes  
   - Key columns: HGNC (gene symbol), hallmarks of aging
   - Maps genes to biological hallmarks of aging process
   - Includes various aging-related cellular and molecular processes

4. longevity_associations
   - Contains genetic variants associated with longevity
   - Key columns: HGNC (gene symbol), polymorphism details, ethnicity, study type
   - Population genetics data from longevity studies
   - Includes SNPs, indels, and other genetic variations

All tables are linked by HGNC gene symbols, allowing for comprehensive cross-table queries about aging-related genes."""
            
            return summary
    
    def db_query(self, sql: str) -> QueryResult:
        """
        Execute a read-only SQL query against the OpenGenes database.
        
        SECURITY: This tool uses SQLite's built-in read-only mode to enforce data protection.
        The database connection is opened in read-only mode, preventing any write operations
        at the database level. Any attempt to modify data will be automatically rejected by SQLite.
        
        The OpenGenes database contains aging and lifespan research data across 4 tables:
        - lifespan_change: Experimental data on gene modifications and lifespan effects
        - gene_criteria: Aging-related criteria classifications for genes  
        - gene_hallmarks: Links genes to hallmarks of aging (multi-value field)
        - longevity_associations: Population genetics data on gene variants and longevity
        
        All tables are linked by HGNC gene symbols for cross-table analysis.
        
        CRITICAL REMINDERS:
        - Use LIKE queries with wildcards for multi-value fields (gene_hallmarks."hallmarks of aging", 
          lifespan_change.intervention_improves, lifespan_change.intervention_deteriorates)
        - Order lifespan results by magnitude: DESC for increases, ASC for decreases
        - IMPORTANT: When user asks about "lifespan effects" without specifying mean vs max, 
          show both lifespan_percent_change_mean AND lifespan_percent_change_max
        - Use COALESCE(lifespan_percent_change_mean, lifespan_percent_change_max) for ordering both metrics
        - COMPREHENSIVE AGING EVIDENCE: When users ask about "evidence of aging", "link to aging/longevity", 
          or "aging associations" for a gene, query ALL 4 tables (gene_criteria, gene_hallmarks, 
          lifespan_change, longevity_associations) for complete scientific evidence
        
        For detailed schema information, use get_schema_info().
        For query examples and patterns, use get_example_queries().
        
        Args:
            sql: The SQL query to execute (database enforces read-only access)
            
        Returns:
            QueryResult: Contains the query results, row count, and executed query
        """
        with start_action(action_type="db_query_tool", sql=sql) as action:
            result = self.db_manager.execute_query(sql)
            return result

    def get_schema_info(self) -> Dict[str, Any]:
        """
        Get comprehensive information about the OpenGenes database schema including table structures, 
        column descriptions, enumerations, and critical query guidelines.
        
        Returns:
            Dict containing detailed table schemas, column information, query guidelines, and available enumerations
        """
        with start_action(action_type="get_schema_info") as action:
            # Get table information
            tables_query = "SELECT name FROM sqlite_master WHERE type='table'"
            tables_result = self.db_manager.execute_query(tables_query)
            table_names = [row['name'] for row in tables_result.rows]
            
            action.add_success_fields(tables_found=len(table_names), table_names=table_names)
            
            schema_info = {
                "database_overview": {
                    "description": "OpenGenes database contains aging and lifespan research data with 4 main tables linked by HGNC gene symbols",
                    "total_tables": len(table_names),
                    "primary_key": "HGNC (gene symbol) - links all tables together"
                },
                "critical_query_guidelines": {
                    "multi_value_fields": {
                        "description": "Some columns contain comma-separated values. ALWAYS use LIKE queries with wildcards for these fields.",
                        "fields": [
                            "gene_hallmarks.'hallmarks of aging' - contains multiple aging hallmarks per gene",
                            "lifespan_change.intervention_deteriorates - multiple biological processes that deteriorate",
                            "lifespan_change.intervention_improves - multiple biological processes that improve"
                        ],
                        "example_syntax": "WHERE \"hallmarks of aging\" LIKE '%stem cell exhauston%'"
                    },
                    "lifespan_metrics": {
                        "description": "Database contains both mean and maximum lifespan change metrics. When user asks about lifespan effects without specifying, show both.",
                        "mean_vs_max": "lifespan_percent_change_mean shows average effect, lifespan_percent_change_max shows maximum observed effect",
                        "when_to_show_both": "If user asks about 'lifespan effects' or 'lifespan changes' without specifying mean vs max, include both metrics",
                        "ordering_both": "Use COALESCE(lifespan_percent_change_mean, lifespan_percent_change_max) for ordering when showing both",
                        "significance": "Both mean and max have corresponding significance columns (significance_mean, significance_max)"
                    },
                    "result_ordering": {
                        "lifespan_extension": "ORDER BY lifespan_percent_change_mean DESC (highest increase first)",
                        "lifespan_reduction": "ORDER BY lifespan_percent_change_mean ASC (largest decrease first)",
                        "importance": "Always order lifespan results by magnitude of effect for relevance",
                        "both_metrics": "When showing both mean and max, use COALESCE for ordering or show comparison"
                    },
                    "comprehensive_aging_evidence": {
                        "description": "For questions about aging evidence, link to aging, or longevity associations for a gene, query ALL 4 tables for complete evidence",
                        "required_tables": "1) gene_criteria (aging-related criteria), 2) gene_hallmarks (aging pathways), 3) lifespan_change (experimental effects), 4) longevity_associations (human population studies)",
                        "example_patterns": "Evidence of X and aging, Link between X and aging, X gene aging associations, What evidence links X to aging",
                        "critical_note": "Do NOT omit longevity_associations table - it contains crucial human population genetics data"
                    },
                    "gene_queries": "Use HGNC column for gene symbols (TP53, FOXO3, etc.)",
                    "safety": "Only SELECT queries allowed - no INSERT, UPDATE, DELETE, or DDL operations"
                },
                "tables": {},
                "enumerations": {},
                "biological_processes_tags": [
                    "cardiovascular system", "nervous system", "immune function", "muscle, bone, skin, liver",
                    "renal function, reproductive function", "cognitive function, eyesight, hair/coat",
                    "body composition", "glucose metabolism, lipid metabolism, cholesterol metabolism",
                    "insulin sensitivity", "oxidation/antioxidant function, mitochondrial function",
                    "DNA metabolism, carcinogenesis, apoptosis", "senescence, inflammation, stress responce",
                    "autophagy, proliferation, locomotor function", "tissue regeneration, stem and progenitor cells",
                    "blood, proteostasis, angiogenesis, metabolism", "endocrine system, intercellular matrix",
                    "building and protection of telomeres", "cytoskeleton organization, nucleus structure",
                    "skin and the intestine epithelial barriers function", "calcium homeostasis, proteolysis"
                ],
                "aging_hallmarks_tags": [
                    "nuclear DNA instability", "telomere attrition", "alterations in histone modifications",
                    "chromatin remodeling", "transcriptional alterations", "alterations in DNA methylation",
                    "degradation of proteolytic systems", "TOR pathway dysregulation", "INS/IGF-1 pathway dysregulation",
                    "AMPK pathway dysregulation", "SIRT pathway dysregulation", "impairment of the mitochondrial integrity and biogenesis",
                    "mitochondrial DNA instability", "accumulation of reactive oxygen species", "senescent cells accumulation",
                    "stem cell exhaustion", "sterile inflammation", "intercellular communication impairment",
                    "changes in the extracellular matrix structure", "impairment of proteins folding and stability",
                    "nuclear architecture impairment", "disabled macroautophagy"
                ]
            }
            
            # Get detailed column information for each table with descriptions
            table_descriptions = {
                "lifespan_change": {
                    "purpose": "Experimental data on how gene modifications affect lifespan in various model organisms",
                    "key_columns": "HGNC, model_organism, effect_on_lifespan, intervention methods, lifespan measurements",
                    "use_cases": "Questions about gene effects on lifespan, experimental conditions, organism studies",
                    "special_notes": "Contains multi-value fields for intervention effects. Use LIKE queries for intervention_deteriorates and intervention_improves columns."
                },
                "gene_criteria": {
                    "purpose": "Aging-related criteria that genes meet (12 different categories)",
                    "key_columns": "HGNC, criteria",
                    "use_cases": "Questions about why genes are considered aging-related",
                    "special_notes": "Links genes to specific aging research criteria classifications"
                },
                "gene_hallmarks": {
                    "purpose": "Links genes to hallmarks of aging",
                    "key_columns": "HGNC, hallmarks of aging (multi-value field)",
                    "use_cases": "Questions about which aging hallmarks genes are involved in",
                    "special_notes": "CRITICAL: 'hallmarks of aging' column contains comma-separated values. Always use LIKE queries with wildcards."
                },
                "longevity_associations": {
                    "purpose": "Population genetics data on gene variants associated with longevity",
                    "key_columns": "HGNC, polymorphism data, ethnicity, study type",
                    "use_cases": "Questions about genetic variants associated with longevity in human populations",
                    "special_notes": "Contains SNPs, indels, and other genetic variations from population studies"
                },
                "comprehensive_aging_evidence": {
                    "purpose": "IMPORTANT: When users ask about 'evidence of aging', 'link to aging/longevity', or 'aging associations' for a gene, query ALL 4 tables for complete evidence",
                    "recommended_approach": "For comprehensive aging evidence, combine data from: 1) gene_criteria (why gene is aging-related), 2) gene_hallmarks (aging pathways involved), 3) lifespan_change (experimental effects), 4) longevity_associations (human population studies)",
                    "example_question_patterns": "What evidence links X to aging?, Evidence of X and aging, X gene and longevity associations, Link between X and aging",
                    "critical_note": "Do not just query experimental tables (lifespan_change) - include population genetics data (longevity_associations) for complete evidence"
                }
            }
            
            for table_name in table_names:
                pragma_query = f"PRAGMA table_info({table_name})"
                columns_result = self.db_manager.execute_query(pragma_query)
                
                # Add detailed column descriptions for lifespan_change table
                column_descriptions = {}
                if table_name == "lifespan_change":
                    column_descriptions = {
                        "HGNC": "Gene symbol (standard gene names like TP53, FOXO3)",
                        "model_organism": "Organism used for experiment (mouse, C. elegans, fly, etc.)",
                        "sex": "Sex of organism used (male, female, all, hermaphrodites, etc.)",
                        "effect_on_lifespan": "Direction of lifespan change (increases/decreases/no change)",
                        "lifespan_percent_change_mean": "Mean percent change in lifespan (average effect across cohort - use for ordering results)",
                        "lifespan_percent_change_max": "Maximum percent change in lifespan (best individual response - show both mean and max when user asks about lifespan effects)",
                        "lifespan_percent_change_median": "Median percent change in lifespan",
                        "intervention_deteriorates": "MULTI-VALUE: Biological processes that deteriorated (use LIKE queries)",
                        "intervention_improves": "MULTI-VALUE: Biological processes that improved (use LIKE queries)",
                        "intervention_method": "Method used to modify gene (knockout, overexpression, etc.)",
                        "main_effect_on_lifespan": "Type of gene activity change (gain/loss/switch of function)",
                        "significance_mean": "Statistical significance of mean lifespan change (1=significant, 0=not significant)",
                        "significance_max": "Statistical significance of maximum lifespan change (1=significant, 0=not significant)",
                        "control_lifespan_mean": "Mean lifespan of control group",
                        "experiment_lifespan_mean": "Mean lifespan of experimental group"
                    }
                elif table_name == "gene_hallmarks":
                    column_descriptions = {
                        "HGNC": "Gene symbol (standard gene names like TP53, FOXO3)",
                        "hallmarks of aging": "MULTI-VALUE: Comma-separated aging hallmarks (ALWAYS use LIKE queries with wildcards)"
                    }
                elif table_name == "gene_criteria":
                    column_descriptions = {
                        "HGNC": "Gene symbol (standard gene names like TP53, FOXO3)",
                        "criteria": "Aging-related criteria the gene meets (12 different categories)"
                    }
                elif table_name == "longevity_associations":
                    column_descriptions = {
                        "HGNC": "Gene symbol (standard gene names like TP53, FOXO3)",
                        "polymorphism type": "Type of genetic variant (SNP, In/Del, VNTR, etc.)",
                        "polymorphism id": "Identifier for the genetic variant (e.g., rs numbers for SNPs)",
                        "nucleotide substitution": "DNA sequence change for the variant",
                        "amino acid substitution": "Protein sequence change caused by the variant",
                        "polymorphism — other": "Additional polymorphism details",
                        "ethnicity": "Ethnicity of study participants",
                        "study type": "Type of population study (GWAS, candidate genes, meta-analysis, etc.)",
                        "sex": "Sex of study participants",
                        "doi": "DOI of the research publication",
                        "pmid": "PubMed ID of the research publication"
                    }
                
                schema_info["tables"][table_name] = {
                    "description": table_descriptions.get(table_name, {}),
                    "columns": [
                        {
                            "name": col["name"],
                            "type": col["type"],
                            "nullable": not col["notnull"],
                            "primary_key": bool(col["pk"]),
                            "description": column_descriptions.get(col["name"], "")
                        }
                        for col in columns_result.rows
                    ]
                }
            
            # Add comprehensive enumerations
            schema_info["enumerations"] = self._get_known_enumerations()
            
            action.add_success_fields(schema_retrieved=True, total_tables=len(table_names))
            return schema_info

    def get_example_queries(self) -> List[Dict[str, str]]:
        """
        Get comprehensive example SQL queries with patterns and best practices for the OpenGenes database.
        
        Includes examples for:
        - Multi-value field queries (LIKE with wildcards)
        - Proper result ordering by effect magnitude
        - Cross-table joins and analysis
        - Common research questions and patterns
        
        Returns:
            List of dictionaries containing example queries with descriptions and categories
        """
        examples = [
            # Basic gene and lifespan queries with proper ordering
            {
                "category": "Lifespan Effects - Ordered by Magnitude",
                "description": "Genes that increase lifespan, ordered by greatest extension first",
                "query": "SELECT HGNC, model_organism, effect_on_lifespan, lifespan_percent_change_mean FROM lifespan_change WHERE effect_on_lifespan = 'increases lifespan' AND lifespan_percent_change_mean IS NOT NULL ORDER BY lifespan_percent_change_mean DESC",
                "key_concept": "Always order lifespan results by magnitude for relevance. Use LIMIT only when user specifically asks for 'top N' or similar"
            },
            {
                "category": "Lifespan Effects - Ordered by Magnitude", 
                "description": "Genes that decrease lifespan, ordered by greatest reduction first",
                "query": "SELECT HGNC, model_organism, effect_on_lifespan, lifespan_percent_change_mean FROM lifespan_change WHERE effect_on_lifespan = 'decreases lifespan' AND lifespan_percent_change_mean IS NOT NULL ORDER BY lifespan_percent_change_mean ASC",
                "key_concept": "Use ASC ordering for lifespan reductions to show largest decreases first. Use LIMIT only when user specifically asks for 'top N' or similar"
            },
            {
                "category": "Lifespan Effects - Mean vs Maximum",
                "description": "Show both mean and maximum lifespan changes when user asks about lifespan effects",
                "query": "SELECT HGNC, model_organism, effect_on_lifespan, lifespan_percent_change_mean, lifespan_percent_change_max, significance_mean, significance_max FROM lifespan_change WHERE effect_on_lifespan = 'increases lifespan' AND (lifespan_percent_change_mean IS NOT NULL OR lifespan_percent_change_max IS NOT NULL) ORDER BY COALESCE(lifespan_percent_change_mean, lifespan_percent_change_max) DESC",
                "key_concept": "When user asks about 'lifespan effects' without specifying mean vs max, show both metrics using COALESCE for ordering"
            },
            # Multi-value field queries with LIKE
            {
                "category": "Multi-Value Field Queries",
                "description": "Query genes by specific aging hallmark using LIKE with wildcards",
                "query": "SELECT HGNC, \"hallmarks of aging\" FROM gene_hallmarks WHERE \"hallmarks of aging\" LIKE '%mitochondrial%'",
                "key_concept": "Always use LIKE with wildcards for multi-value columns like gene_hallmarks.'hallmarks of aging'"
            },
            {
                "category": "Multi-Value Field Queries",
                "description": "Find interventions that improve specific biological processes",
                "query": "SELECT HGNC, intervention_improves FROM lifespan_change WHERE intervention_improves LIKE '%oxidation%'",
                "key_concept": "Use LIKE with wildcards for intervention_improves column which contains comma-separated processes"
            },
            # Gene-specific queries
            {
                "category": "Gene-Specific Analysis",
                "description": "Get comprehensive aging evidence for a specific gene across all tables",
                "query": "SELECT 'lifespan_change' as table_name, HGNC, model_organism, effect_on_lifespan FROM lifespan_change WHERE HGNC = 'FOXO3' UNION ALL SELECT 'gene_criteria', HGNC, criteria as model_organism, '' as effect_on_lifespan FROM gene_criteria WHERE HGNC = 'FOXO3' UNION ALL SELECT 'gene_hallmarks', HGNC, \"hallmarks of aging\" as model_organism, '' as effect_on_lifespan FROM gene_hallmarks WHERE HGNC = 'FOXO3' UNION ALL SELECT 'longevity_associations', HGNC, ethnicity as model_organism, polymorphism_type as effect_on_lifespan FROM longevity_associations WHERE HGNC = 'FOXO3'",
                "key_concept": "Use UNION ALL to combine results from all 4 tables for comprehensive aging evidence"
            },
            {
                "category": "Gene-Specific Analysis",
                "description": "Find genes with lifespan extensions in specific organisms",
                "query": "SELECT HGNC, model_organism, lifespan_percent_change_mean FROM lifespan_change WHERE effect_on_lifespan = 'increases lifespan' AND model_organism = 'mouse' ORDER BY lifespan_percent_change_mean DESC",
                "key_concept": "Filter by model_organism to get species-specific results"
            },
            # Intervention method queries
            {
                "category": "Intervention Analysis",
                "description": "Find genes with lifespan extension via knockout",
                "query": "SELECT HGNC, model_organism, lifespan_percent_change_mean FROM lifespan_change WHERE effect_on_lifespan = 'increases lifespan' AND intervention_method = 'knockout' ORDER BY lifespan_percent_change_mean DESC",
                "key_concept": "Filter by intervention_method to analyze specific genetic intervention types"
            },
            {
                "category": "Intervention Analysis",
                "description": "Compare lifespan effects of knockout vs overexpression",
                "query": "SELECT HGNC, intervention_method, COUNT(*) as experiment_count, AVG(lifespan_percent_change_mean) as avg_effect FROM lifespan_change WHERE effect_on_lifespan = 'increases lifespan' AND intervention_method IN ('knockout', 'overexpression') GROUP BY HGNC, intervention_method ORDER BY AVG(lifespan_percent_change_mean) DESC",
                "key_concept": "Use aggregate functions to compare effects across different intervention methods"
            },
            # Population genetics queries
            {
                "category": "Population Genetics",
                "description": "Find longevity associations by ethnicity",
                "query": "SELECT HGNC, ethnicity, polymorphism_type, study_type FROM longevity_associations WHERE ethnicity LIKE '%Japanese%'",
                "key_concept": "Filter longevity_associations by ethnicity for population-specific insights"
            },
            {
                "category": "Population Genetics",
                "description": "Count longevity associations per gene",
                "query": "SELECT HGNC, COUNT(*) as association_count FROM longevity_associations GROUP BY HGNC ORDER BY association_count DESC",
                "key_concept": "Use aggregate functions to identify genes with most population evidence"
            },
            # Complex cross-table queries
            {
                "category": "Complex Cross-Table Analysis",
                "description": "Find genes with both experimental lifespan effects and population longevity associations",
                "query": "SELECT DISTINCT lc.HGNC FROM lifespan_change lc INNER JOIN longevity_associations la ON lc.HGNC = la.HGNC WHERE lc.effect_on_lifespan = 'increases lifespan' AND lc.HGNC IS NOT NULL",
                "key_concept": "Use INNER JOIN to find genes with evidence from both experimental and population studies"
            },
            {
                "category": "Complex Cross-Table Analysis",
                "description": "Find genes with specific hallmarks that also extend lifespan",
                "query": "SELECT DISTINCT gh.HGNC, gh.\"hallmarks of aging\" FROM gene_hallmarks gh INNER JOIN lifespan_change lc ON gh.HGNC = lc.HGNC WHERE gh.\"hallmarks of aging\" LIKE '%mitochondrial%' AND lc.effect_on_lifespan = 'increases lifespan'",
                "key_concept": "Combine hallmark filtering with lifespan effects for targeted analysis"
            }
        ]
        
        action = start_action(action_type="get_example_queries", query_count=len(examples))
        action.add_success_fields(example_count=len(examples))
        
        return examples

    def _get_known_enumerations(self) -> Dict[str, List[str]]:
        """Get known enumerations for database columns."""
        # Query actual unique values from the database
        enums = {}
        
        try:
            # Get unique effect_on_lifespan values
            effect_result = self.db_manager.execute_query("SELECT DISTINCT effect_on_lifespan FROM lifespan_change WHERE effect_on_lifespan IS NOT NULL")
            enums["effect_on_lifespan"] = [row["effect_on_lifespan"] for row in effect_result.rows]
            
            # Get unique model_organism values
            organism_result = self.db_manager.execute_query("SELECT DISTINCT model_organism FROM lifespan_change WHERE model_organism IS NOT NULL")
            enums["model_organism"] = [row["model_organism"] for row in organism_result.rows]
            
            # Get unique intervention_method values
            method_result = self.db_manager.execute_query("SELECT DISTINCT intervention_method FROM lifespan_change WHERE intervention_method IS NOT NULL")
            enums["intervention_method"] = [row["intervention_method"] for row in method_result.rows]
            
            # Get unique criteria values
            criteria_result = self.db_manager.execute_query("SELECT DISTINCT criteria FROM gene_criteria WHERE criteria IS NOT NULL")
            enums["criteria"] = [row["criteria"] for row in criteria_result.rows]
            
        except Exception as e:
            # If queries fail, provide default enumerations
            enums = {
                "effect_on_lifespan": ["increases lifespan", "decreases lifespan", "no change"],
                "model_organism": ["mouse", "C. elegans", "fly", "yeast", "rat"],
                "intervention_method": ["knockout", "overexpression", "RNAi", "CRISPR"],
                "criteria": ["longevity", "senescence", "stress resistance", "metabolism"]
            }
        
        return enums

# Create the main MCP server instance
mcp = OpenGenesMCP(
    name="OpenGenes MCP Server",
    huge_query_tool=False
)

# Typer CLI app
app = typer.Typer(
    name="opengenes-mcp",
    help="MCP server for OpenGenes aging and longevity research database"
)

@app.command()
def cli_app(
    transport: str = typer.Option(DEFAULT_TRANSPORT, "--transport", help="Transport type: stdio, sse, or streamable-http"),
    host: str = typer.Option(DEFAULT_HOST, "--host", help="Host to bind to"),
    port: int = typer.Option(DEFAULT_PORT, "--port", help="Port to bind to")
) -> None:
    """Run the MCP server with specified transport."""
    mcp.run(transport=transport, host=host, port=port)

@app.command("stdio")
def cli_app_stdio(
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Verbose output")
) -> None:
    """Run the MCP server with stdio transport."""
    mcp.run(transport="stdio")

@app.command("sse")
def cli_app_sse(
    host: str = typer.Option(DEFAULT_HOST, "--host", help="Host to bind to"),
    port: int = typer.Option(DEFAULT_PORT, "--port", help="Port to bind to")
) -> None:
    """Run the MCP server with SSE transport."""
    mcp.run(transport="sse", host=host, port=port)

# Standalone CLI functions for direct script access
def cli_app_run() -> None:
    """Standalone function for opengenes-mcp-run script."""
    mcp.run(transport="streamable-http", host=DEFAULT_HOST, port=DEFAULT_PORT)

def cli_app_stdio() -> None:
    """Standalone function for opengenes-mcp-stdio script."""
    mcp.run(transport="stdio")

def cli_app_sse() -> None:
    """Standalone function for opengenes-mcp-sse script."""
    mcp.run(transport="sse", host=DEFAULT_HOST, port=DEFAULT_PORT)

if __name__ == "__main__":
    app()