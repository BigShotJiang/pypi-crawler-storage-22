from __future__ import annotations
#!/usr/bin/env python3
"""
MCP-IRT Server - MCP协议支持的应急响应服务器
"""

import sys
import json
import logging
from typing import Dict, Any, Optional
from datetime import datetime

# MCP SDK support
try:
    from mcp.server.models import InitializationOptions
    from mcp.server import NotificationOptions, Server
    from mcp.server.stdio import stdio_server
    from mcp.types import (
        Resource,
        Tool,
        TextContent,
        ImageContent,
        EmbeddedResource,
    )
    MCP_AVAILABLE = True
except ImportError:
    MCP_AVAILABLE = False
    Server = None
    stdio_server = None
    InitializationOptions = None
    NotificationOptions = None
    Resource = None
    Tool = None
    TextContent = None
    ImageContent = None
    EmbeddedResource = None

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/mcp_server.log'),
        logging.StreamHandler(sys.stderr)
    ]
)
logger = logging.getLogger('MCPIRTServer')


class MCPIRTServer:
    """MCP IRT服务器"""

    def __init__(self):
        """初始化MCP IRT服务器"""
        if not MCP_AVAILABLE:
            logger.error("MCP SDK not available. Please install: pip install mcp")
            sys.exit(1)

        self.server = Server("mcp-irt")
        self.tools = {
            "analyze_security_output": {
                "name": "analyze_security_output",
                "description": "分析安全脚本输出，识别威胁",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "script_name": {
                            "type": "string",
                            "description": "脚本名称"
                        },
                        "output": {
                            "type": "string",
                            "description": "脚本输出内容"
                        },
                        "os_type": {
                            "type": "string",
                            "description": "操作系统类型 (linux/windows)",
                            "enum": ["linux", "windows"]
                        }
                    },
                    "required": ["script_name", "output", "os_type"]
                }
            },
            "analyze_threat": {
                "name": "analyze_threat",
                "description": "深度分析特定威胁",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "threat_type": {
                            "type": "string",
                            "description": "威胁类型"
                        },
                        "indicators": {
                            "type": "array",
                            "description": "威胁指标列表",
                            "items": {"type": "string"}
                        },
                        "context": {
                            "type": "object",
                            "description": "上下文信息"
                        }
                    },
                    "required": ["threat_type", "indicators"]
                }
            },
            "generate_response_plan": {
                "name": "generate_response_plan",
                "description": "生成应急响应计划",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "threats": {
                            "type": "array",
                            "description": "威胁列表",
                            "items": {"type": "object"}
                        },
                        "system_info": {
                            "type": "object",
                            "description": "系统信息"
                        }
                    },
                    "required": ["threats"]
                }
            }
        }

        self._register_handlers()

    def _register_handlers(self):
        """注册MCP处理器"""

        @self.server.list_tools()
        async def list_tools():
            """列出可用工具"""
            return [
                Tool(**tool)
                for tool in self.tools.values()
            ]

        @self.server.call_tool()
        async def call_tool(name: str, arguments: Any):
            """调用工具"""
            if name == "analyze_security_output":
                return await self._analyze_security_output(arguments)
            elif name == "analyze_threat":
                return await self._analyze_threat(arguments)
            elif name == "generate_response_plan":
                return await self._generate_response_plan(arguments)
            else:
                return [TextContent(
                    type="text",
                    text=f"Unknown tool: {name}"
                )]

    async def _analyze_security_output(self, arguments):
        """分析安全脚本输出"""
        script_name = arguments.get('script_name', 'unknown')
        output = arguments.get('output', '')
        os_type = arguments.get('os_type', 'linux')

        analysis_prompt = f"""请分析以下{os_type}系统安全检查脚本的输出，识别安全威胁。

脚本名称: {script_name}

输出内容:
{output[:6000]}

请以JSON格式返回分析结果，包括:
1. 识别的威胁列表（包括描述、严重程度、指标）
2. 整体风险评分（0-100）
3. 处置建议
"""

        return [TextContent(
            type="text",
            text=analysis_prompt
        )]

    async def _analyze_threat(self, arguments):
        """深度分析威胁"""
        threat_type = arguments.get('threat_type', '')
        indicators = arguments.get('indicators', [])
        context = arguments.get('context', {})

        analysis_prompt = f"""请深度分析以下安全威胁:

威胁类型: {threat_type}
威胁指标: {json.dumps(indicators, indent=2, ensure_ascii=False)}
上下文信息: {json.dumps(context, indent=2, ensure_ascii=False)}

请提供:
1. 威胁的工作原理
2. 攻击者可能的目的
3. 影响范围评估
4. 详细的清除步骤
5. 加固建议
"""

        return [TextContent(
            type="text",
            text=analysis_prompt
        )]

    async def _generate_response_plan(self, arguments):
        """生成应急响应计划"""
        threats = arguments.get('threats', [])
        system_info = arguments.get('system_info', {})

        plan_prompt = f"""基于以下威胁信息，生成详细的应急响应计划:

检测到的威胁:
{json.dumps(threats, indent=2, ensure_ascii=False)}

系统信息:
{json.dumps(system_info, indent=2, ensure_ascii=False)}

请生成:
1. 应急响应时间线
2. 每个威胁的具体处置步骤
3. 优先级排序
4. 所需工具和命令
5. 回滚方案
6. 后续加固建议
"""

        return [TextContent(
            type="text",
            text=plan_prompt
        )]

    async def run(self):
        """运行MCP服务器"""
        async with stdio_server() as (read_stream, write_stream):
            await self.server.run(
                read_stream,
                write_stream,
                InitializationOptions(
                    server_name="mcp-irt",
                    server_version="1.0.0",
                    capabilities=self.server.get_capabilities(
                        notification_options=NotificationOptions(),
                        experimental_capabilities={},
                    )
                )
            )


def main():
    """主函数"""
    import asyncio

    server = MCPIRTServer()

    logger.info("MCP-IRT Server started")
    logger.info("Waiting for JSON-RPC requests from Claude Desktop...")

    try:
        asyncio.run(server.run())
    except KeyboardInterrupt:
        logger.info("MCP server stopped by user")
    except Exception as e:
        logger.error(f"Fatal error in MCP server: {e}")
        raise


if __name__ == '__main__':
    main()