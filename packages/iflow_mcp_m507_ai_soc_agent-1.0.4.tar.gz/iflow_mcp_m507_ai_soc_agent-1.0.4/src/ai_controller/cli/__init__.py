"""CLI for AI Controller."""

