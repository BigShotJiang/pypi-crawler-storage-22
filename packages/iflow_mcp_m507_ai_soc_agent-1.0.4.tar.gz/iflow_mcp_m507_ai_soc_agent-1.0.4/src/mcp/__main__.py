"""Entry point for the MCP server."""

import asyncio
import sys

from .mcp_server import main


def cli():
    """Synchronous entry point for the MCP server."""
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        sys.exit(0)


if __name__ == "__main__":
    cli()