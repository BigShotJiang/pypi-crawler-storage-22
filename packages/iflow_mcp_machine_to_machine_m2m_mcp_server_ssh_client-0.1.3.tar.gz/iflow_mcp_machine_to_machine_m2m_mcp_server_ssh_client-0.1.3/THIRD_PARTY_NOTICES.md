# Third-Party Notices

This project includes code from the following third-party source:

## mcp-proxy

- **Source**: https://github.com/sparfenyuk/mcp-proxy
- **Author**: Sergey Parfenyuk
- **Files**: 
  - src/m2m_mcp_server_ssh_client/proxy_server.py
- **License**: MIT License

The code from mcp-proxy is used to create a proxy server that forwards MCP
protocol requests to remote servers. The original code has been modified to
work with our SSH client implementation.

### MIT License Text

MIT License

Copyright (c) 2024 Sergey Parfenyuk

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
