#!/usr/bin/env python3
import asyncio
import json
import sys

async def test_mcp():
    print("Starting MCP test...", file=sys.stderr)

    proc = await asyncio.create_subprocess_exec(
        sys.executable, '-m', 'mcp_server_azure',
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )

    print(f"Process started with PID: {proc.pid}", file=sys.stderr)

    # Wait for startup
    await asyncio.sleep(2)

    if proc.returncode is not None:
        stderr = await proc.stderr.read()
        print(f"Process exited with code {proc.returncode}", file=sys.stderr)
        print(f"Stderr: {stderr.decode()}", file=sys.stderr)
        return False

    print("Process is running", file=sys.stderr)

    # Send initialize request
    init_msg = '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test","version":"1.0"}}}\n'
    print(f"Sending: {init_msg.strip()}", file=sys.stderr)
    proc.stdin.write(init_msg.encode())
    await proc.stdin.drain()

    # Read response
    try:
        response_line = await asyncio.wait_for(proc.stdout.readline(), timeout=5)
        if not response_line:
            print("No response received", file=sys.stderr)
            return False

        response = response_line.decode().strip()
        print(f"Received: {response[:200]}...", file=sys.stderr)

        # Send initialized notification
        init_msg = '{"jsonrpc":"2.0","method":"notifications/initialized"}\n'
        proc.stdin.write(init_msg.encode())
        await proc.stdin.drain()

        # Request tools list
        tools_msg = '{"jsonrpc":"2.0","id":2,"method":"tools/list"}\n'
        print(f"Sending: {tools_msg.strip()}", file=sys.stderr)
        proc.stdin.write(tools_msg.encode())
        await proc.stdin.drain()

        # Read tools response
        tools_response = await asyncio.wait_for(proc.stdout.readline(), timeout=5)
        if not tools_response:
            print("No tools response received", file=sys.stderr)
            return False

        tools_data = tools_response.decode().strip()
        print(f"Tools response: {tools_data[:500]}...", file=sys.stderr)

        # Parse and count tools
        result = json.loads(tools_data)
        if 'result' in result and 'tools' in result['result']:
            tool_count = len(result['result']['tools'])
            print(f"✅ SUCCESS - Found {tool_count} tools", file=sys.stderr)
            print(json.dumps({"success": True, "tool_count": tool_count}))
            return True
        else:
            print(f"❌ FAILED - No tools found", file=sys.stderr)
            print(json.dumps({"success": False, "error": "No tools found"}))
            return False

    except asyncio.TimeoutError:
        print("❌ Timeout waiting for response", file=sys.stderr)
        print(json.dumps({"success": False, "error": "Timeout"}))
        return False
    except Exception as e:
        print(f"❌ Error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        print(json.dumps({"success": False, "error": str(e)}))
        return False
    finally:
        try:
            proc.terminate()
            await asyncio.wait_for(proc.wait(), timeout=2)
        except:
            try:
                proc.kill()
                await proc.wait()
            except:
                pass

if __name__ == "__main__":
    result = asyncio.run(test_mcp())
    sys.exit(0 if result else 1)