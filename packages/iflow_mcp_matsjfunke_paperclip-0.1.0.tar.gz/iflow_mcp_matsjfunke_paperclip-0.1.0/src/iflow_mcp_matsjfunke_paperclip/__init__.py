"""
Paperclip MCP Server - Search and retrieve research papers from Arxiv, OSF, and OpenAlex
"""

__version__ = "0.1.0"