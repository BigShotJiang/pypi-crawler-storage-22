"""
Global application configuration settings for NiFi MCP.

This module loads configuration from config.yaml and provides global access
to configuration values throughout the application.
"""

import os
from pathlib import Path
from typing import Dict, List, Optional, Any, Literal
from pydantic_settings import BaseSettings, SettingsConfigDict
import logging

# Try to import settings relative to this file, fall back to absolute import
try:
    from logging_setup import LOGGING_CONFIG, PROJECT_ROOT
except ImportError:
    print("Could not import settings relative to logging_setup. Trying absolute.")
    try:
        from config.logging_setup import LOGGING_CONFIG, PROJECT_ROOT
    except ImportError:
        print("FATAL: Could not import LOGGING_CONFIG or PROJECT_ROOT from config.settings")
        PROJECT_ROOT = Path(__file__).parent.parent
        LOGGING_CONFIG = {}

# Configuration file paths
CONFIG_DIR = PROJECT_ROOT / "config"
CONFIG_FILE = CONFIG_DIR / "config.yaml"
DEFAULT_LOGGING_CONFIG = {}

def load_yaml_config(config_path: Path) -> Optional[Dict[str, Any]]:
    """Load YAML configuration file safely."""
    import yaml
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)
    except FileNotFoundError:
        return None
    except yaml.YAMLError as e:
        return None
    except Exception as e:
        return None

# Load NiFi configuration
_NIFI_CONFIG = load_yaml_config(CONFIG_FILE)

# Extract NiFi server configurations
NIFI_SERVERS = []
if _NIFI_CONFIG and 'nifi' in _NIFI_CONFIG:
    NIFI_SERVERS = _NIFI_CONFIG['nifi'].get('servers', [])

# Extract LLM configuration
_LLM_CONFIG = {}
if _NIFI_CONFIG and 'llm' in _NIFI_CONFIG:
    _LLM_CONFIG = _NIFI_CONFIG['llm']

# Extract MCP features configuration
_MCP_FEATURES_CONFIG = {}
if _NIFI_CONFIG and 'mcp_features' in _NIFI_CONFIG:
    _MCP_FEATURES_CONFIG = _NIFI_CONFIG['mcp_features']

# Extract logging configuration
_LOGGING_CONFIG_OVERRIDE = {}
if _NIFI_CONFIG and 'logging' in _NIFI_CONFIG:
    _LOGGING_CONFIG_OVERRIDE = _NIFI_CONFIG['logging']

# Extract workflow configuration
_WORKFLOW_CONFIG = {}
if _NIFI_CONFIG and 'workflows' in _NIFI_CONFIG:
    _WORKFLOW_CONFIG = _NIFI_CONFIG['workflows']

# LLM Provider Models
OPENAI_MODELS = _LLM_CONFIG.get('openai', {}).get('models', [])
GEMINI_MODELS = _LLM_CONFIG.get('google', {}).get('models', [])
PERPLEXITY_MODELS = _LLM_CONFIG.get('perplexity', {}).get('models', [])
ANTHROPIC_MODELS = _LLM_CONFIG.get('anthropic', {}).get('models', [])

# LLM API Keys (should be loaded from environment in production)
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY', '')
GEMINI_API_KEY = os.getenv('GEMINI_API_KEY', '')
PERPLEXITY_API_KEY = os.getenv('PERPLEXITY_API_KEY', '')
ANTHROPIC_API_KEY = os.getenv('ANTHROPIC_API_KEY', '')

# Expert Help Configuration
EXPERT_HELP_CONFIG = _LLM_CONFIG.get('expert_help_model', {})
EXPERT_HELP_PROVIDER = EXPERT_HELP_CONFIG.get('provider', 'openai')
EXPERT_HELP_MODEL = EXPERT_HELP_CONFIG.get('model', 'gpt-4o')

# Logging Configuration
LLM_ENQUEUE_ENABLED = _LOGGING_CONFIG_OVERRIDE.get('llm_enqueue_enabled', True)
INTERFACE_DEBUG_ENABLED = _LOGGING_CONFIG_OVERRIDE.get('interface_debug_enabled', False)

# MCP Feature Flags
AUTO_STOP_ENABLED = _MCP_FEATURES_CONFIG.get('auto_stop_enabled', True)
AUTO_DELETE_ENABLED = _MCP_FEATURES_CONFIG.get('auto_delete_enabled', True)
AUTO_PURGE_ENABLED = _MCP_FEATURES_CONFIG.get('auto_purge_enabled', True)

# Workflow Configuration
WORKFLOW_EXECUTION_MODE = _WORKFLOW_CONFIG.get('execution_mode', 'unguided')
WORKFLOW_ACTION_LIMIT = _WORKFLOW_CONFIG.get('default_action_limit', 10)
WORKFLOW_RETRY_ATTEMPTS = _WORKFLOW_CONFIG.get('retry_attempts', 3)
ENABLED_WORKFLOWS = _WORKFLOW_CONFIG.get('enabled_workflows', [])

# Auto-Feature Timing
AUTO_STOP_DELAY_SECONDS = 2
AUTO_FEATURE_RETRY_DELAY_SECONDS = 1

def get_nifi_servers() -> List[Dict[str, Any]]:
    """Get list of configured NiFi servers."""
    return NIFI_SERVERS

def get_nifi_server_config(server_id: str) -> Optional[Dict[str, Any]]:
    """
    Get configuration for a specific NiFi server by ID.
    
    Args:
        server_id: The unique ID of the NiFi server
        
    Returns:
        Dictionary with server configuration or None if not found
    """
    for server in NIFI_SERVERS:
        if server.get('id') == server_id:
            return server
    return None

def is_expert_help_available() -> bool:
    """Check if expert help is available."""
    provider_models_map = {
        'openai': OPENAI_MODELS,
        'google': GEMINI_MODELS,
        'perplexity': PERPLEXITY_MODELS,
        'anthropic': ANTHROPIC_MODELS
    }
    
    available_models = provider_models_map.get(EXPERT_HELP_PROVIDER, [])
    return bool(EXPERT_HELP_MODEL and EXPERT_HELP_MODEL in available_models)

def get_feature_auto_stop_enabled() -> bool:
    """Get Auto-Stop feature enabled status."""
    return AUTO_STOP_ENABLED

def get_feature_auto_delete_enabled() -> bool:
    """Get Auto-Delete feature enabled status."""
    return AUTO_DELETE_ENABLED

def get_feature_auto_purge_enabled() -> bool:
    """Get Auto-Purge feature enabled status."""
    return AUTO_PURGE_ENABLED

def get_llm_enqueue_enabled() -> bool:
    """Get LLM enqueue enabled status."""
    return LLM_ENQUEUE_ENABLED

def get_interface_debug_enabled() -> bool:
    """Get interface debug enabled status."""
    return INTERFACE_DEBUG_ENABLED

def get_workflow_execution_mode() -> str:
    """Get workflow execution mode."""
    return WORKFLOW_EXECUTION_MODE

def get_workflow_action_limit() -> int:
    """Get workflow default action limit."""
    return WORKFLOW_ACTION_LIMIT

def get_workflow_retry_attempts() -> int:
    """Get workflow retry attempts."""
    return WORKFLOW_RETRY_ATTEMPTS

def get_enabled_workflows() -> List[str]:
    """Get list of enabled workflows."""
    return ENABLED_WORKFLOWS

def get_auto_stop_delay_seconds() -> int:
    """Get auto-stop delay in seconds."""
    return AUTO_STOP_DELAY_SECONDS

def get_auto_feature_retry_delay_seconds() -> int:
    """Get auto-feature retry delay in seconds."""
    return AUTO_FEATURE_RETRY_DELAY_SECONDS

def get_feature_auto_stop_enabled(headers: Optional[Dict[str, str]] = None) -> bool:
    """
    Get Auto-Stop feature enabled status, with optional header override.
    
    Args:
        headers: Optional request headers to check for override
        
    Returns:
        Boolean indicating if Auto-Stop is enabled
    """
    if headers:
        override = headers.get('X-Auto-Stop-Enabled')
        if override is not None:
            return override.lower() == 'true'
    return AUTO_STOP_ENABLED