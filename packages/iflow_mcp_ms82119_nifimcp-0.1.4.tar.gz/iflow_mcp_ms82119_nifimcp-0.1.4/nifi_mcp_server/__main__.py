#!/usr/bin/env python3
"""
NiFi MCP Server - stdio entry point
"""
import asyncio
import sys

try:
    from nifi_mcp_server.core import mcp
    
    # Import tool modules to register their tools with the mcp instance
    from nifi_mcp_server.api_tools import review
    from nifi_mcp_server.api_tools import creation
    from nifi_mcp_server.api_tools import modification
    from nifi_mcp_server.api_tools import operation
    from nifi_mcp_server.api_tools import helpers
    
except Exception as e:
    import traceback
    sys.stderr.write(f"Error importing: {e}\n")
    traceback.print_exc(file=sys.stderr)
    sys.exit(1)

async def main():
    try:
        await mcp.run_stdio_async()
    except Exception as e:
        import traceback
        sys.stderr.write(f"Error running server: {e}\n")
        traceback.print_exc(file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    asyncio.run(main())