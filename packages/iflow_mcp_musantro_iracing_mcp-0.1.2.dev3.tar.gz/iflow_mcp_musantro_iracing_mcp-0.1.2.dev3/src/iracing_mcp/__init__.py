"""iRacing MCP package providing integration between iRacing and Model Context Protocol."""
