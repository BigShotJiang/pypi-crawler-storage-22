"""Entry points for the iRacing MCP server."""
