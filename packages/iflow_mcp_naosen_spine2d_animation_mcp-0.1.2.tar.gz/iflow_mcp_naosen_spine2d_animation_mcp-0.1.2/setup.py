import os
from setuptools import setup, find_packages

# Get the directory where this script is located
here = os.path.abspath(os.path.dirname(__file__))

# Read README
readme_path = os.path.join(here, "README.md")
with open(readme_path, "r", encoding="utf-8") as fh:
    long_description = fh.read()

# Read requirements
requirements_path = os.path.join(here, "requirements.txt")
if os.path.exists(requirements_path):
    with open(requirements_path, "r", encoding="utf-8") as fh:
        requirements = fh.read().splitlines()
else:
    requirements = []

setup(
    name="iflow-mcp_naosen-spine2d-animation-mcp",
    version="0.1.2",
    author="",
    author_email="",
    description="MCP server for generating SPINE2D animations from PSD files using natural language",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/spine2d-animation-mcp",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 3 - Alpha",
        "Topic :: Multimedia :: Graphics :: 3D Modeling",
        "Topic :: Multimedia :: Graphics :: Editors :: Vector-Based",
    ],
    python_requires=">=3.6",
    install_requires=requirements,
    entry_points={
        "console_scripts": [
            "spine2d-mcp=iflow_mcp_naosen_spine2d_animation_mcp.main:main",
        ],
    },
)