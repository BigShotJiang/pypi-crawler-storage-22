"""
Main entry point for Payload MCP Server.
This module provides a synchronous wrapper for the async main function.
"""

import asyncio
import sys
from .server import main as _main_async


def main():
    """Synchronous entry point that wraps the async main function."""
    asyncio.run(_main_async())


if __name__ == "__main__":
    main()