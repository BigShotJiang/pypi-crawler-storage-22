#!/usr/bin/env python3
import sys
sys.path.insert(0, "/app/auto-mcp-upload/data/7751/src")
from okta_mcp_server import main
main()