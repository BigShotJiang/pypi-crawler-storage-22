"""
iflow-mcp_orion4d-comfyui_mcp - MCP server for ComfyUI
"""

__version__ = "1.0.4"

from .server import main

__all__ = ["main"]