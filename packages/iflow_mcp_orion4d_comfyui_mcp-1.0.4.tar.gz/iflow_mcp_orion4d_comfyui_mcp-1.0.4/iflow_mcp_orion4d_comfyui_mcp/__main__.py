"""
Main entry point for iflow-mcp_orion4d_comfyui_mcp package
"""

from .server import main

if __name__ == "__main__":
    main()