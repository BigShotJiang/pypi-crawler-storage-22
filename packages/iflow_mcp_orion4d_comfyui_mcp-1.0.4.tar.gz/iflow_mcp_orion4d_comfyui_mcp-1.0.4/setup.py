from setuptools import setup, find_packages
from pathlib import Path

# Read README for long description
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text(encoding="utf-8") if readme_file.exists() else ""

setup(
    name="iflow-mcp_orion4d-comfyui_mcp",
    version="1.0.4",
    description="MCP server for ComfyUI - enables ChatGPT to control ComfyUI workflows",
    long_description=long_description,
    long_description_content_type="text/markdown",
    python_requires=">=3.8",
    packages=find_packages(),
    install_requires=[
        "fastmcp>=0.1.0",
        "httpx>=0.24.0",
        "python-dotenv>=1.0.0",
        "uvicorn[standard]>=0.24.0",
        "fastapi>=0.104.0",
        "websocket-client>=1.0.0",
        "requests>=2.31.0",
        "gradio>=4.0.0",
        "openai>=1.0.0",
        "google-genai>=0.3.0",
    ],
    entry_points={
        "console_scripts": [
            "iflow-mcp-orion4d-comfyui-mcp=iflow_mcp_orion4d_comfyui_mcp.server:main",
        ],
    },
)