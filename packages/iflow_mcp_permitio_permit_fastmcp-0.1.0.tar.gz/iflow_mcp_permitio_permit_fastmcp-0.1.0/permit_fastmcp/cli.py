"""
CLI entry point for permit-fastmcp.
Run a simple MCP server for demonstration.
"""

from permit_fastmcp.simple_server import mcp

def main():
    """Main entry point for the CLI."""
    mcp.run(transport="stdio")

if __name__ == "__main__":
    main()