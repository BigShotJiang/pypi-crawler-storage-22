"""
Simple MCP server example for testing.
"""

from fastmcp import FastMCP

# Create a simple MCP server without authorization
mcp = FastMCP("Permit FastMCP Test Server")

@mcp.tool
def greet(name: str) -> str:
    """Greet a user by name."""
    return f"Hello, {name}!"

@mcp.tool
def echo(message: str) -> str:
    """Echo back the message."""
    return message

@mcp.tool
def calculate(a: float, b: float, operation: str = "add") -> str:
    """Perform a calculation on two numbers."""
    if operation == "add":
        return f"{a} + {b} = {a + b}"
    elif operation == "subtract":
        return f"{a} - {b} = {a - b}"
    elif operation == "multiply":
        return f"{a} * {b} = {a * b}"
    elif operation == "divide":
        if b == 0:
            return "Cannot divide by zero"
        return f"{a} / {b} = {a / b}"
    else:
        return f"Unknown operation: {operation}"

if __name__ == "__main__":
    # Run the MCP server with stdio transport
    mcp.run(transport="stdio")