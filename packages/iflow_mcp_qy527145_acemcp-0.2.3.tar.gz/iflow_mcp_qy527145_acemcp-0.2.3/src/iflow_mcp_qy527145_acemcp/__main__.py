"""Entry point for running iflow_mcp_qy527145_acemcp as a module."""

from iflow_mcp_qy527145_acemcp import run

if __name__ == "__main__":
    run()