"""Index management module."""

from iflow_mcp_qy527145_acemcp.index.manager import IndexManager

__all__ = ["IndexManager"]
