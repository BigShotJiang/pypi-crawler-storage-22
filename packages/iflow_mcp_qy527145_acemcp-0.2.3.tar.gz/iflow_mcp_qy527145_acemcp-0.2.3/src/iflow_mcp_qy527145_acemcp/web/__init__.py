"""Web management interface for acemcp MCP server."""

from iflow_mcp_qy527145_acemcp.web.app import create_app

__all__ = ["create_app"]
