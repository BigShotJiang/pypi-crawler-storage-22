#!/usr/bin/env python3
import sys
sys.path.insert(0, '/app/auto-mcp-upload/data/3375/src')
from arxiv_mcp.server import main
main()