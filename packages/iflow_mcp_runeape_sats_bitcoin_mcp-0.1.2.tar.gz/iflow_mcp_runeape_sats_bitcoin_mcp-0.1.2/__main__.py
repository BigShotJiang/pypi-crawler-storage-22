# Entry point for the Bitcoin MCP server
from bitcoin_mcp_server import mcp

if __name__ == "__main__":
    mcp.run()