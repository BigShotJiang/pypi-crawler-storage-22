# Entry point for the Bitcoin MCP server
from iflow_mcp_runeape_sats_bitcoin_mcp.bitcoin_mcp_server import mcp

if __name__ == "__main__":
    mcp.run()