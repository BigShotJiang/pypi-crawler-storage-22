from streaming_server.main import run_streaming_server

def main():
    run_streaming_server()

if __name__ == "__main__":
    main()
