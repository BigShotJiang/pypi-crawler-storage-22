import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from streaming_server.main import run_streaming_server
import argparse

if __name__ == "__main__":
    args = argparse.Namespace(transport='stdio', host='127.0.0.1', port=8001)
    run_streaming_server(args)
