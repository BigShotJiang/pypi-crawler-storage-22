import asyncio
import json
import sys

async def test_stdio():
    process = await asyncio.create_subprocess_exec(
        sys.executable, "run_stdio.py",
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    
    await asyncio.sleep(2)
    
    # Send initialize request
    request = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "initialize",
        "params": {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {"name": "test", "version": "1.0"}
        }
    }
    
    process.stdin.write((json.dumps(request) + "\n").encode())
    await process.stdin.drain()
    
    # Read response
    response_line = await asyncio.wait_for(process.stdout.readline(), timeout=10)
    print(f"Response: {response_line.decode()}")
    
    process.terminate()
    await process.wait()

asyncio.run(test_stdio())
