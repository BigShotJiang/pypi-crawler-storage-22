#!/usr/bin/env python3
"""
Simple MCP server using FastMCP to add two numbers - Containerized version.
"""

import sys
from fastmcp import FastMCP

# Create the MCP server
mcp = FastMCP("Simple Calculator Container")

@mcp.tool()
def add_numbers(a: float, b: float) -> float:
    """Add two numbers together.
    
    Args:
        a: First number to addition
        b: Second number to addition
        
    Returns:
        The sum of a and b
    """
    result = a + b
    return result

def main():
    """Main entry point for the MCP server.
    
    Supports both stdio and streamable-http transports based on environment.
    For local testing and MCP client connections, use stdio transport.
    For containerized deployment (Kubernetes/Docker), use streamable-http transport.
    """
    # Check if running in containerized environment (has PORT env var or --transport flag)
    transport = sys.argv[1] if len(sys.argv) > 1 else "stdio"
    
    if transport == "streamable-http":
        # Run with streamable-http transport for HTTP-based communication in containers
        # Note: FastMCP doesn't support transport_options parameter
        # Session timeout is handled by the underlying transport layer
        mcp.run(
            transport="streamable-http", 
            host="0.0.0.0", 
            port=8000
        )
    else:
        # Default to stdio transport for MCP client connections
        mcp.run(transport="stdio")

if __name__ == "__main__":
    main()