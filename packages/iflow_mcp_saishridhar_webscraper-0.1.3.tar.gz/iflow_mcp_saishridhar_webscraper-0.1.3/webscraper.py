import sys # Import sys
from typing import Any
import mcp.types as types
import asyncio
import httpx
import os
from youtube_transcript_api import YouTubeTranscriptApi
import re
from crawl4ai import *
from mcp.server.fastmcp import FastMCP

def download_pdf_from_url(url, output_path=None):
    """
    Download a PDF file from a URL.

    Args:
        url (str): URL of the PDF to download
        output_path (str): Optional path to save the PDF. If None, saves to a temporary file.

    Returns:
        str: Path to the downloaded PDF file
    """
    import requests
    import tempfile
    from urllib.parse import urlparse

    # Parse the URL to get the filename
    parsed_url = urlparse(url)
    filename = os.path.basename(parsed_url.path)

    # If no filename was found or it doesn't end with .pdf, use a default name
    if not filename or not filename.endswith('.pdf'):
        filename = 'downloaded_document.pdf'

    # Determine where to save the file
    if output_path is None:
        # Create a temporary file
        temp_dir = tempfile.gettempdir()
        output_path = os.path.join(temp_dir, filename)

    print("Downloading PDF...")
    # Download the PDF
    response = requests.get(url, stream=True)
    response.raise_for_status()

    print("Saving PDF...")
    with open(output_path, 'wb') as f:
        for chunk in response.iter_content(chunk_size=8192):
            if chunk:
                f.write(chunk)

    print(f"Downloaded PDF to: {output_path}")
    return output_path

mcp = FastMCP("websrcaper")

@mcp.tool()
async def get_webpage_content(url_input: str) -> str:
    '''
    Returns the text content on a webpage based on the link provided. Using this tool you can access links provided by the user so you don't have deny those requests.
    When the user provides a webpage link which is NOT a youtube or github link and asks questions based on that, this function should be called.
    Args:
        url: The url from which you want to text to be extracted.

    '''
    async with AsyncWebCrawler() as crawler:
        try:
            result = await crawler.arun(
                url=url_input,
            )
        except Exception as e:
            print(f"Error in get_webpage_content tool: {e}", file=sys.stderr) # PRINT TO STDERR!
            raise e
    #print(result.markdown)
    output = result.markdown
    return [types.TextContent(type="text", text=output)]


@mcp.tool()
async def get_youtube_transcript(url_input: str) -> str:
    '''
    Use this tool when you receive youtube links from the user. This tool will extract the transcript from the youtube video and return it to you. Therefore if a user asks questions on a youtube video after providing a link, you can answer their question with this tool.
    Args:
        url: The url from which you want to text to be extracted.

    '''
    youtube_re = r"(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})"

    match = re.search(youtube_re, url_input)
    if match:
        video_id = match.group(1)
    else:
        print("Invalid youtube url")
        exit()
    dic = YouTubeTranscriptApi.get_transcript(video_id)
    output = ""
    for i in dic:
        output += i['text'] + " "
    return [types.TextContent(type="text", text=output)]

@mcp.tool()
async def get_pdf(url_input: str) -> str:
    """
    Download a PDF file from a URL and return basic info.

    Args:
        url_input (str): Path to the PDF file to download

    Returns:
        str: Information about the downloaded PDF
    """
    try:
        filename = download_pdf_from_url(url_input)
        file_size = os.path.getsize(filename)
        output = f"PDF downloaded successfully: {filename}\nFile size: {file_size} bytes\nNote: Full PDF text extraction requires additional dependencies. This is a placeholder for the PDF download functionality."
        os.remove(filename)
        return [types.TextContent(type="text", text=output)]
    except Exception as e:
        error_msg = f"Error processing PDF: {str(e)}"
        print(error_msg, file=sys.stderr)
        return [types.TextContent(type="text", text=error_msg)]

def main():
    """Main entry point for the MCP server"""
    try:
        mcp.run(transport='stdio')
    except Exception as e:
        print(f"Error initializing or running MCP server: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()