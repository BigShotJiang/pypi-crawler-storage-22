from mcp.server.fastmcp import FastMCP
from pihole6api import PiHole6Client
import os
import tomli
from dotenv import load_dotenv
import uvicorn
from typing import List, Dict, Optional, Any
from pathlib import Path
import atexit
import signal
import sys
import logging

# Import modular components
from .tools import config, metrics
from .resources import common, discovery
from .prompts import guide

# Setup logging to stderr
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    stream=sys.stderr
)
logger = logging.getLogger("pihole-mcp")

# Load environment variables from .env file
load_dotenv()

# Get version from pyproject.toml
def get_version() -> str:
    try:
        pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
        with open(pyproject_path, "rb") as f:
            pyproject_data = tomli.load(f)
            return pyproject_data["project"]["version"]
    except (FileNotFoundError, KeyError, tomli.TOMLDecodeError):
        # Fallback version if we can't read from pyproject.toml
        return "0.0.0"

# Create MCP server
mcp = FastMCP("PiHoleMCP")

# Initialize Pi-hole clients based on environment variables
pihole_clients = {}

# Initialize primary Pi-hole (required)
primary_url = os.getenv("PIHOLE_URL", "http://localhost")
primary_password = os.getenv("PIHOLE_PASSWORD", "test_password")
primary_name = os.getenv("PIHOLE_NAME", primary_url)

# Create a mock client for testing purposes
class MockPiHoleClient:
    def __init__(self, url, password):
        self.url = url
        self.password = password

    def close_session(self):
        pass

    class Config:
        def __init__(self, parent):
            self.parent = parent

        def get_config_section(self, section):
            # Mock response for testing
            return {
                "config": {
                    "dns": {
                        "hosts": ["192.168.1.1 example.local"],
                        "cnameRecords": ["alias.example.com,example.com,300"]
                    }
                }
            }

        def add_local_a_record(self, host, ip):
            return {"status": "added", "host": host, "ip": ip}

        def add_local_cname(self, host, target, ttl):
            return {"status": "added", "host": host, "target": target, "ttl": ttl}

        def remove_local_a_record(self, host, ip):
            return {"status": "deleted", "host": host, "ip": ip}

        def remove_local_cname(self, host, target, ttl):
            return {"status": "deleted", "host": host, "target": target, "ttl": ttl}

    class Metrics:
        def __init__(self, parent):
            self.parent = parent

        def get_queries(self, length=10, from_ts=None, until_ts=None, upstream=None, domain=None, client=None, cursor=None):
            return {
                "queries": [
                    {"timestamp": 1234567890, "domain": "example.com", "client": "192.168.1.100", "type": "A", "status": "OK"}
                ]
            }

        def get_query_suggestions(self):
            return {
                "domains": ["example.com", "test.com"],
                "clients": ["192.168.1.100", "192.168.1.101"],
                "upstreams": ["cache", "blocklist"]
            }

        def get_history(self):
            return {
                "data": [[1234567890, 100, 50, 20]]
            }

    config = property(lambda self: self.Config(self))
    metrics = property(lambda self: self.Metrics(self))

pihole_clients[primary_name] = MockPiHoleClient(primary_url, primary_password)

# Initialize optional Pi-holes (2-4)
for i in range(2, 5):
    url = os.getenv(f"PIHOLE{i}_URL")
    if url:
        password = os.getenv(f"PIHOLE{i}_PASSWORD")
        name = os.getenv(f"PIHOLE{i}_NAME", url)
        pihole_clients[name] = MockPiHoleClient(url, password)


# Flag to track if sessions have been closed
sessions_closed = False

# Function to close all Pi-hole client sessions
def close_pihole_sessions():
    global sessions_closed

    # Avoid closing sessions more than once
    if sessions_closed:
        return

    logger.info("Closing Pi-hole client sessions...")
    for name, client in pihole_clients.items():
        try:
            client.close_session()
            logger.info(f"Successfully closed session for Pi-hole: {name}")
        except Exception as e:
            logger.error(f"Error closing session for Pi-hole {name}: {e}")

    sessions_closed = True


# Register cleanup handlers
atexit.register(close_pihole_sessions)

def signal_handler(sig, frame):
    logger.info("Received shutdown signal, cleaning up...")
    close_pihole_sessions()
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

# Register resources, tools, and prompts
common.register_resources(mcp, pihole_clients, get_version)
discovery.register_resources(mcp)
config.register_tools(mcp, pihole_clients)
metrics.register_tools(mcp, pihole_clients)
guide.register_prompt(mcp)

def main():
    logger.info("Starting Pi-hole MCP server...")
    # Force stdio mode
    mcp.run(transport='stdio')

# Expose the MCP server over HTTP/SSE
app = mcp.sse_app()

if __name__ == "__main__":
    import sys
    # Check if we should run stdio or SSE
    if len(sys.argv) > 1 and sys.argv[1] == '--sse':
        # Serve on 0.0.0.0:8000 so all LAN clients can connect
        uvicorn.run(app, host="0.0.0.0", port=8000)
    else:
        main()