"""Run all tests for the eClass MCP Server."""

import asyncio
import logging
import os
import sys

from dotenv import load_dotenv

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))
from eclass_mcp_server.server import (
    handle_authstatus,
    handle_get_courses,
    handle_login,
    handle_logout,
    session_state,
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('run_all_tests')

test_results = {
    'login': False,
    'authstatus_after_login': False,
    'get_courses': False,
    'logout': False,
    'authstatus_after_logout': False
}


async def test_login() -> bool:
    """Test the login functionality."""
    print("\n=== Testing Login ===")
    
    load_dotenv()
    
    username = os.getenv('ECLASS_USERNAME')
    password = os.getenv('ECLASS_PASSWORD')
    
    if not username or not password:
        print("ERROR: ECLASS_USERNAME and ECLASS_PASSWORD must be set in the .env file.")
        return False
    
    print("Attempting login...")
    response = await handle_login()
    
    if not response:
        print("ERROR: Empty response from login handler.")
        return False
    
    text_content = response[0]
    print(f"Login response: {text_content.text}")
    
    if "Login successful" in text_content.text:
        print("Login test SUCCESS!")
        return True
    
    print("Login test FAILED!")
    return False


async def test_authstatus() -> bool:
    """Test the authentication status functionality."""
    print("\n=== Testing Auth Status ===")
    
    print("Checking authentication status...")
    response = await handle_authstatus()
    
    if not response:
        print("ERROR: Empty response from authstatus handler.")
        return False
    
    text_content = response[0]
    print(f"Auth status response: {text_content.text}")
    
    if "Status: Logged in as" in text_content.text:
        print("Auth status (logged in) test SUCCESS!")
        return True
    if "Status: Not logged in" in text_content.text and not session_state.logged_in:
        print("Auth status (not logged in) test SUCCESS!")
        return True
    if "Status: Session expired" in text_content.text and not session_state.is_session_valid():
        print("Auth status (session expired) test SUCCESS!")
        return True
    
    print("Auth status test FAILED!")
    return False


async def test_get_courses() -> bool:
    """Test the course retrieval functionality."""
    print("\n=== Testing Course Retrieval ===")
    
    if not session_state.logged_in:
        print("Not logged in, skipping course retrieval test.")
        return False
    
    print("Retrieving courses...")
    response = await handle_get_courses()
    
    if not response:
        print("ERROR: Empty response from get_courses handler.")
        return False
    
    text_content = response[0]
    print(f"Course retrieval response: {text_content.text}")
    
    if "Error" in text_content.text:
        print("Course retrieval test FAILED!")
        return False
    
    if "No courses found" in text_content.text:
        print("No courses found, but API worked correctly.")
        print("Course retrieval test SUCCESS!")
        return True
    
    if "Found" in text_content.text and "courses" in text_content.text:
        if "URL:" in text_content.text:
            print("Course retrieval test SUCCESS!")
            return True
        print("Course retrieval test FAILED! Output format is incorrect (missing URLs).")
        return False
    
    print("Unexpected response from course retrieval.")
    print("Course retrieval test FAILED!")
    return False


async def test_logout() -> bool:
    """Test the logout functionality."""
    print("\n=== Testing Logout ===")
    
    if not session_state.logged_in:
        print("Not logged in, skipping logout test.")
        return False
    
    print("Attempting logout...")
    response = await handle_logout()
    
    if not response:
        print("ERROR: Empty response from logout handler.")
        return False
    
    text_content = response[0]
    print(f"Logout response: {text_content.text}")
    
    if "Successfully logged out" in text_content.text:
        print("Logout test SUCCESS!")
        return True
    
    print("Logout test FAILED!")
    return False


async def run_all_tests() -> None:
    """Run all tests in sequence."""
    print("\n====== Starting All eClass MCP Server Tests ======\n")
    
    test_results['login'] = await test_login()
    
    if test_results['login']:
        test_results['authstatus_after_login'] = await test_authstatus()
        test_results['get_courses'] = await test_get_courses()
        test_results['logout'] = await test_logout()
    
    test_results['authstatus_after_logout'] = await test_authstatus()
    
    print("\n====== Test Results Summary ======")
    for test_name, result in test_results.items():
        status = "PASSED" if result else "FAILED"
        print(f"{test_name}: {status}")
    
    if all(test_results.values()):
        print("\nAll tests PASSED!")
    else:
        print("\nSome tests FAILED!")
    
    print("\n====== Completed All eClass MCP Server Tests ======\n")


if __name__ == "__main__":
    asyncio.run(run_all_tests())
