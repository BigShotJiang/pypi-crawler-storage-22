from .server import mcp

def main():
    """Main entry point for running the MCP server."""
    mcp.run()

if __name__ == "__main__":
    main()