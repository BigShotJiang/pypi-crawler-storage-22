#!/usr/bin/env python3
"""
Demo MCP Server using standard MCP SDK
Supports stdio transport for local testing
"""

import logging
import random
from typing import Any

import requests
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger("demo-mcp-server")

# Create server instance
server = Server("demo-mcp-server", "1.0.0")


@server.list_tools()
async def list_tools() -> list[Tool]:
    """List available tools"""
    return [
        Tool(
            name="add",
            description="Add two numbers together",
            inputSchema={
                "type": "object",
                "properties": {
                    "a": {"type": "integer", "description": "First number"},
                    "b": {"type": "integer", "description": "Second number"}
                },
                "required": ["a", "b"]
            }
        ),
        Tool(
            name="get_secret_word",
            description="Get a random secret word",
            inputSchema={
                "type": "object",
                "properties": {},
                "required": []
            }
        ),
        Tool(
            name="get_current_weather",
            description="Get current weather for a city",
            inputSchema={
                "type": "object",
                "properties": {
                    "city": {"type": "string", "description": "City name"}
                },
                "required": ["city"]
            }
        )
    ]


@server.call_tool()
async def call_tool(name: str, arguments: Any) -> list[TextContent]:
    """Handle tool calls"""
    logger.info(f"Tool called: {name} with arguments: {arguments}")

    if name == "add":
        result = arguments["a"] + arguments["b"]
        return [TextContent(type="text", text=str(result))]

    elif name == "get_secret_word":
        word = random.choice(["apple", "banana", "cherry"])
        return [TextContent(type="text", text=word)]

    elif name == "get_current_weather":
        city = arguments["city"]
        try:
            endpoint = "https://wttr.in"
            response = requests.get(f"{endpoint}/{city}", timeout=10)
            response.raise_for_status()
            return [TextContent(type="text", text=response.text)]
        except requests.RequestException as e:
            error_msg = f"Error fetching weather data: {str(e)}"
            logger.error(error_msg)
            return [TextContent(type="text", text=error_msg)]

    else:
        return [TextContent(type="text", text=f"Unknown tool: {name}")]


async def main():
    """Main entry point"""
    logger.info("Starting MCP Server with stdio transport...")
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options()
        )


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())