"""MCP tools for ArgoCD"""
