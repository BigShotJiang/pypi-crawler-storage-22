# archive_agent/mcp_server/__init__.py
#  Copyright © 2025 Dr.-Ing. Paul Wilhelm <paul@wilhelm.dev>
#  This file is part of Archive Agent. See LICENSE for details.

from archive_agent.mcp_server.McpServer import McpServer

__all__ = ["McpServer"]