# archive_agent/mcp_server_stdio.py
#  Copyright © 2025 Dr.-Ing. Paul Wilhelm <paul@wilhelm.dev>
#  This file is part of Archive Agent. See LICENSE for details.

"""
MCP Server stdio entry point for iflow-mcp package.
This module provides a stdio-based MCP server for compatibility.
"""

import os
import asyncio
import logging
import sys
from mcp.server.fastmcp import FastMCP

# Set environment variable to disable logging
os.environ['ARCHIVE_AGENT_MCP_STDIO'] = '1'

# Import after setting environment variable
# This will ensure logging is disabled

# Redirect all logging to stderr to avoid interfering with stdio communication
logging.basicConfig(
    level=logging.CRITICAL,
    stream=sys.stderr,
    force=True
)
logging.getLogger("archive_agent").setLevel(logging.CRITICAL)
logging.getLogger().setLevel(logging.CRITICAL)

# Create a simplified MCP server for stdio mode
mcp_stdio = FastMCP("Archive-Agent-stdio")

@mcp_stdio.tool()
async def get_patterns() -> dict:
    """
    Get the list of included / excluded patterns.
    :return: {"included": [filename], "excluded": [filename]}.
    """
    # Simplified version for testing - returns empty lists
    return {
        "included": [],
        "excluded": []
    }

@mcp_stdio.tool()
async def get_files_tracked() -> dict:
    """
    Get the list of tracked files.
    :return: {"tracked": [filename]}.
    """
    # Simplified version for testing - returns empty list
    return {
        "tracked": [],
    }

@mcp_stdio.tool()
async def get_files_changed() -> dict:
    """
    Get the list of changed files.
    :return: {"added": [filename], "changed": [filename], "removed": [filename]}.
    """
    # Simplified version for testing - returns empty lists
    return {
        "added": [],
        "changed": [],
        "removed": [],
    }

@mcp_stdio.tool()
async def get_search_result(question: str) -> dict:
    """
    Get the list of files relevant to the question.
    :param question: Question.
    :return: {file_path: relevance_score, ...}.
    """
    # Simplified version for testing - returns empty dict
    return {}

@mcp_stdio.tool()
async def get_chunk_headers(file_path: str) -> dict:
    """
    Get the list of chunk headers for a specific file.
    Provides a quick overview of the document's contents structure.
    :param file_path: Path to the file.
    :return: {
        "file_path": str,
        "chunks_total": int,
        "chunks": [{"chunk_index": int, "header": str, "page_range": List[int] | None, "line_range": List[int] | None}]
    }.
    """
    # Simplified version for testing - returns empty chunks
    return {
        "file_path": file_path,
        "chunks_total": 0,
        "chunks": [],
    }

@mcp_stdio.tool()
async def get_answer_rag(question: str) -> dict:
    """
    Get answer to question using RAG.
    :param question: Question.
    :return: {
        "question_rephrased": str,
        "answer_list": [{"answer": str, "chunk_ref_list": List[str]}],
        "answer_conclusion": str,
        "follow_up_questions_list": List[str],
        "is_rejected": bool,
        "rejection_reason": Optional[str]
    }.
    """
    # Simplified version for testing - returns empty answer
    return {
        "question_rephrased": question,
        "answer_list": [],
        "answer_conclusion": "This is a test response. Full functionality requires proper configuration.",
        "follow_up_questions_list": [],
        "is_rejected": False,
        "rejection_reason": None,
    }

async def main():
    """Run MCP server in stdio mode."""
    await mcp_stdio.run_stdio_async()

def main_sync():
    """Synchronous entry point for uvx."""
    asyncio.run(main())

if __name__ == "__main__":
    main_sync()