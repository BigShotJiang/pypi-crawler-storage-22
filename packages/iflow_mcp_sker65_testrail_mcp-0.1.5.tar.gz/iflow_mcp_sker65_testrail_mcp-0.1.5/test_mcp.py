#!/usr/bin/env python3
import asyncio
import subprocess
import json
import os

async def test_mcp_server():
    env = {
        'TESTRAIL_URL': 'https://test.example.com',
        'TESTRAIL_USERNAME': 'test@example.com',
        'TESTRAIL_API_KEY': 'test-key-12345'
    }
    
    proc = await asyncio.create_subprocess_exec(
        'uvx', '--from', 'dist/iflow_mcp_sker65_testrail_mcp-0.1.5-py3-none-any.whl',
        'testrail-mcp',
        stdout=asyncio.subprocess.PIPE,
        stdin=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        env={**os.environ, **env},
        cwd='/app/auto-mcp-upload/data/3089'
    )
    
    # Initialize
    init_request = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "initialize",
        "params": {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {
                "name": "test-client",
                "version": "1.0.0"
            }
        }
    }
    
    proc.stdin.write((json.dumps(init_request) + "\n").encode())
    await proc.stdin.drain()
    
    response = await proc.stdout.readline()
    print(f"Initialize response: {response.decode()}")
    
    # Send initialized notification
    initialized = {
        "jsonrpc": "2.0",
        "method": "notifications/initialized"
    }
    proc.stdin.write((json.dumps(initialized) + "\n").encode())
    await proc.stdin.drain()
    
    # List tools
    tools_request = {
        "jsonrpc": "2.0",
        "id": 2,
        "method": "tools/list"
    }
    proc.stdin.write((json.dumps(tools_request) + "\n").encode())
    await proc.stdin.drain()
    
    response = await proc.stdout.readline()
    tools_response = json.loads(response.decode())
    print(f"\n=== Tools List ===")
    if 'result' in tools_response and 'tools' in tools_response['result']:
        tools = tools_response['result']['tools']
        print(f"Total tools: {len(tools)}")
        for tool in tools:
            print(f"  - {tool['name']}: {tool.get('description', 'No description')[:60]}")
    else:
        print(f"Response: {response.decode()}")
    
    proc.terminate()
    await proc.wait()

if __name__ == "__main__":
    asyncio.run(test_mcp_server())