#!/usr/bin/env python3
"""
CLI entry point for iflow-mcp_sshh12-mcp-demo
"""
import sys
import argparse

from server import app


def main():
    """Main entry point for the CLI"""
    parser = argparse.ArgumentParser(description="URL-Based MCP Server")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind to")
    parser.add_argument("--port", type=int, default=5000, help="Port to bind to")
    parser.add_argument("--transport", default="sse", choices=["sse", "stdio"], help="Transport protocol")
    
    args = parser.parse_args()
    
    if args.transport == "stdio":
        print("Error: This MCP server only supports SSE transport", file=sys.stderr)
        sys.exit(1)
    
    app.run(host=args.host, port=args.port)


if __name__ == "__main__":
    main()