import sys
import os

# Add parent directory to path to import server
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from server import app

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

# For pip install -e . to work
app_cli = app