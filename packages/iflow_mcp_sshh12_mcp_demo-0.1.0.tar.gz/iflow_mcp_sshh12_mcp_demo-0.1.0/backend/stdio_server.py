#!/usr/bin/env python3
"""
STDIO MCP Server for iflow-mcp_sshh12-mcp-demo
Provides stdio transport support for the MCP server
"""
import sys
import json
import uuid
import logging
from typing import Dict, Any

_logger = logging.getLogger(__name__)


class StdioMCPSession:
    """MCP Session for stdio transport"""
    
    def __init__(self):
        self.session_id = uuid.uuid4()
        self.server_name = "URL-MCP-Demo"
        self.server_version = "1.0.0"
        self.configured_tools = []
        self.client_info = {}
        self.capabilities = {
            "logging": {},
            "prompts": {},
            "resources": {"listChanged": True},
            "tools": {"listChanged": True},
        }
    
    def initialize(self, params: Dict) -> Dict:
        """Initialize the MCP session"""
        protocol_version = params.get("protocolVersion", "2024-11-05")
        if protocol_version != "2024-11-05":
            _logger.warning(f"Using unknown version: {protocol_version}")
        
        if "clientInfo" in params:
            self.client_info = params["clientInfo"]
            _logger.info(f"Received client info: {self.client_info}")
        
        return {
            "protocolVersion": protocol_version,
            "capabilities": self.capabilities,
            "serverInfo": {
                "name": self.server_name,
                "version": self.server_version
            },
        }
    
    def tools_list(self, params: Dict) -> Dict:
        """Return list of available tools"""
        return {
            "tools": [
                {
                    "name": tool["name"],
                    "description": tool["description"],
                    "inputSchema": tool["inputSchema"],
                }
                for tool in self.configured_tools
            ]
        }
    
    def tools_call(self, params: Dict) -> Dict:
        """Handle tool execution requests"""
        tool_name = params["name"]
        tool_arguments = params.get("arguments", {})
        
        for tool in self.configured_tools:
            if tool["name"] == tool_name:
                # Handle static text response
                if tool.get("responseType") == "static" and "staticResponse" in tool:
                    return {
                        "content": [
                            {
                                "type": "text", 
                                "text": tool["staticResponse"]
                            }
                        ],
                        "isError": False,
                    }
                # Handle HTTP endpoint
                elif tool.get("responseType") == "endpoint" and "endpoint" in tool:
                    import requests
                    try:
                        payload = {
                            "tool": tool_name,
                            "arguments": tool_arguments,
                            "clientInfo": self.client_info
                        }
                        
                        response = requests.post(
                            tool["endpoint"],
                            json=payload,
                            headers={"Content-Type": "application/json"},
                            timeout=30
                        )
                        
                        response.raise_for_status()
                        
                        return {
                            "content": [
                                {
                                    "type": "text", 
                                    "text": response.text
                                }
                            ],
                            "isError": False,
                        }
                    except requests.RequestException as e:
                        return {
                            "content": [{"type": "text", "text": f"Error calling tool endpoint: {str(e)}"}],
                            "isError": True,
                        }
        
        return {
            "content": [
                {
                    "type": "text",
                    "text": f"No tool found with name: {tool_name}",
                }
            ],
            "isError": True,
        }
    
    def resources_list(self, params: Dict) -> Dict:
        """Return list of resources"""
        return {"resources": []}
    
    def handle_request(self, request: Dict) -> Dict:
        """Handle an MCP request"""
        method = request.get("method")
        params = request.get("params", {})
        
        if not method:
            return {"error": "No method provided"}
        
        try:
            if method == "initialize":
                return {"result": self.initialize(params)}
            elif method == "notifications/initialized":
                return {"result": {}}
            elif method == "tools/list":
                return {"result": self.tools_list(params)}
            elif method == "tools/call":
                return {"result": self.tools_call(params)}
            elif method == "resources/list":
                return {"result": self.resources_list(params)}
            else:
                return {"error": f"Method {method} not found"}
        except Exception as e:
            _logger.error(f"Error handling request: {e}")
            return {"error": str(e)}


def main():
    """Main entry point for stdio MCP server"""
    session = StdioMCPSession()
    
    # Read from stdin and write to stdout
    for line in sys.stdin:
        try:
            request = json.loads(line.strip())
            request_id = request.get("id")
            
            response = session.handle_request(request)
            
            if request_id is not None:
                response["jsonrpc"] = "2.0"
                response["id"] = request_id
            
            print(json.dumps(response))
            sys.stdout.flush()
        except json.JSONDecodeError as e:
            _logger.error(f"JSON decode error: {e}")
        except Exception as e:
            _logger.error(f"Unexpected error: {e}")


if __name__ == "__main__":
    main()