#!/bin/bash
cd /app/auto-mcp-upload/data/2741
export PYTHONPATH=src
export JAMA_MOCK_MODE=true
.venv/bin/python -m jama_mcp_server.server