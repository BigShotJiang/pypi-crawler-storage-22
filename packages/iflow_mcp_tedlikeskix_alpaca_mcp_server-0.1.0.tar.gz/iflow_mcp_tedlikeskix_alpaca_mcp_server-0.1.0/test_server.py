#!/usr/bin/env python3
import asyncio
import sys
sys.path.insert(0, '/app/auto-mcp-upload/data/2283')

# Monkey patch to disable API requirement
import os
os.environ['API_KEY_ID'] = 'test'
os.environ['API_SECRET_KEY'] = 'test'

from alpaca_mcp_server import mcp

async def test_server():
    """Test if MCP server can start and list tools"""
    try:
        # Get all tools
        tools = mcp._tool_manager._tools
        print(f"✓ MCP Server started successfully")
        print(f"✓ Found {len(tools)} tools:")
        for tool_name in tools:
            print(f"  - {tool_name}")
        return True
    except Exception as e:
        print(f"✗ Failed to start server: {e}")
        return False

if __name__ == "__main__":
    success = asyncio.run(test_server())
    sys.exit(0 if success else 1)