"""Tests for hue-mcp server."""
