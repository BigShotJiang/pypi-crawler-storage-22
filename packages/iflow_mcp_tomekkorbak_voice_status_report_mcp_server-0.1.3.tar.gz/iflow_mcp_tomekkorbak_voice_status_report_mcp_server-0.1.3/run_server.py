#!/usr/bin/env python3
import sys
import os

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from voice_status_report_mcp_server import main

if __name__ == "__main__":
    main()