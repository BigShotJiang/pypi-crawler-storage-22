# Add this for compatibility with uvx

from uns_mcp.server import main

if __name__ == "__main__":
    main()
