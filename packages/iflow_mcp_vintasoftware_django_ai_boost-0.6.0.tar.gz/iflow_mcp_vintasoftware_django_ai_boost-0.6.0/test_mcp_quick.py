#!/usr/bin/env python
"""Quick MCP server test script"""

import asyncio
import json
import os
import sys

# Add project to path
sys.path.insert(0, "/app/auto-mcp-upload/data/5422/src")
sys.path.insert(0, "/app/auto-mcp-upload/data/5422/fixtures/testproject")

# Set Django settings
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "testproject.settings")

import django
django.setup()

# Import after Django setup
from django_ai_boost.server_fastmcp import (
    application_info,
    get_setting,
    list_models,
    list_urls,
    database_schema,
    list_migrations,
    list_management_commands,
    get_absolute_url,
    reverse_url,
    query_model,
    run_check,
    search_django_docs,
)


async def test_tool(tool_func, tool_name):
    """Test a single tool"""
    try:
        print(f"\n[TEST] {tool_name}")
        result = await tool_func()
        print(f"✓ {tool_name} works")
        return True
    except Exception as e:
        print(f"✗ {tool_name} failed: {str(e)}")
        return False


async def main():
    print("=" * 60)
    print("Testing Django AI Boost MCP Tools")
    print("=" * 60)

    # Test all tools
    tools_to_test = [
        (lambda: application_info(), "application_info"),
        (lambda: get_setting("DEBUG"), "get_setting"),
        (lambda: list_models(), "list_models"),
        (lambda: list_urls(), "list_urls"),
        (lambda: database_schema(), "database_schema"),
        (lambda: list_migrations(), "list_migrations"),
        (lambda: list_management_commands(), "list_management_commands"),
        (lambda: run_check(), "run_check"),
        (lambda: search_django_docs("models"), "search_django_docs"),
    ]

    passed = 0
    failed = 0

    for tool_func, tool_name in tools_to_test:
        success = await test_tool(tool_func, tool_name)
        if success:
            passed += 1
        else:
            failed += 1

    print("\n" + "=" * 60)
    print(f"Results: {passed} passed, {failed} failed")
    print(f"Total tools: {len(tools_to_test)}")
    print("=" * 60)

    # Print tool count for validation
    print(f"\n[INFO] Total MCP tools available: {len(tools_to_test)}")


if __name__ == "__main__":
    asyncio.run(main())
