"""Точка входа для запуска модуля как пакета (mock для тестирования)."""

import asyncio
from .main_mock import main

if __name__ == "__main__":
    asyncio.run(main())