"""Mock клиент для тестирования без 1С."""

import json
import logging
from typing import Any, Dict, List, Optional
from mcp import types
from mcp.server.lowlevel.helper_types import ReadResourceContents


logger = logging.getLogger(__name__)


class OneCClient:
    """Mock клиент для тестирования без 1С."""

    def __init__(self, base_url: str, username: str, password: str, service_root: str = "mcp"):
        """Инициализация клиента.

        Args:
            base_url: Базовый URL 1С (например, http://localhost/base)
            username: Имя пользователя
            password: Пароль
            service_root: Корневой URL HTTP-сервиса (по умолчанию "mcp")
        """
        self.base_url = base_url.rstrip('/')
        self.service_root = service_root.strip('/')
        self.service_base_url = f"{self.base_url}/hs/{self.service_root}"
        logger.debug(f"Mock клиент инициализирован для: {self.service_base_url}")

    async def check_health(self) -> bool:
        """Проверить состояние HTTP-сервиса 1С.

        Returns:
            True, если сервис доступен и здоров.
        """
        logger.debug("Mock health check: OK")
        return True

    async def list_tools(self) -> List[types.Tool]:
        """Получить список доступных инструментов.

        Returns:
            Список инструментов MCP
        """
        # Возвращаем демонстрационный список инструментов
        tools = [
            types.Tool(
                name="get_metadata",
                description="Получить метаданные объекта 1С",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "object_name": {
                            "type": "string",
                            "description": "Имя объекта метаданных"
                        }
                    },
                    "required": ["object_name"]
                }
            ),
            types.Tool(
                name="execute_query",
                description="Выполнить запрос к базе данных 1С",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "query_text": {
                            "type": "string",
                            "description": "Текст запроса"
                        }
                    },
                    "required": ["query_text"]
                }
            ),
            types.Tool(
                name="create_document",
                description="Создать документ в 1С",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "document_type": {
                            "type": "string",
                            "description": "Тип документа"
                        },
                        "attributes": {
                            "type": "object",
                            "description": "Атрибуты документа"
                        }
                    },
                    "required": ["document_type"]
                }
            )
        ]
        logger.debug(f"Mock tools list: {len(tools)} tools")
        return tools

    async def call_tool(self, name: str, arguments: Dict[str, Any]) -> types.CallToolResult:
        """Вызвать инструмент.

        Args:
            name: Имя инструмента
            arguments: Аргументы инструмента

        Returns:
            Результат выполнения инструмента
        """
        logger.debug(f"Mock call tool: {name} with args: {arguments}")
        return types.CallToolResult(
            content=[
                types.TextContent(
                    type="text",
                    text=f"Mock response for tool '{name}'. This is a demo mode - connect to real 1C server for actual functionality."
                )
            ],
            isError=False
        )

    async def list_resources(self) -> List[types.Resource]:
        """Получить список доступных ресурсов.

        Returns:
            Список ресурсов MCP
        """
        resources = [
            types.Resource(
                uri="1c://metadata/catalogs",
                name="Справочники",
                description="Список всех справочников конфигурации",
                mimeType="application/json"
            ),
            types.Resource(
                uri="1c://metadata/documents",
                name="Документы",
                description="Список всех документов конфигурации",
                mimeType="application/json"
            )
        ]
        logger.debug(f"Mock resources list: {len(resources)} resources")
        return resources

    async def read_resource(self, uri: str) -> List[ReadResourceContents]:
        """Прочитать ресурс.

        Args:
            uri: URI ресурса

        Returns:
            Список частей содержимого ресурса
        """
        logger.debug(f"Mock read resource: {uri}")
        return [
            ReadResourceContents(
                content=json.dumps({
                    "uri": str(uri),
                    "description": "Mock resource content. Connect to real 1C server for actual data."
                }, ensure_ascii=False),
                mime_type="application/json"
            )
        ]

    async def list_prompts(self) -> List[types.Prompt]:
        """Получить список доступных промптов.

        Returns:
            Список промптов MCP
        """
        prompts = [
            types.Prompt(
                name="generate_query",
                description="Генерация запроса 1С по описанию",
                arguments=[
                    types.PromptArgument(
                        name="description",
                        description="Описание требуемого запроса",
                        required=True
                    )
                ]
            )
        ]
        logger.debug(f"Mock prompts list: {len(prompts)} prompts")
        return prompts

    async def get_prompt(self, name: str, arguments: Optional[Dict[str, str]] = None) -> types.GetPromptResult:
        """Получить промпт.

        Args:
            name: Имя промпта
            arguments: Аргументы промпта

        Returns:
            Результат промпта
        """
        logger.debug(f"Mock get prompt: {name} with args: {arguments}")
        return types.GetPromptResult(
            description=f"Mock prompt '{name}'",
            messages=[
                types.PromptMessage(
                    role="user",
                    content=types.TextContent(
                        type="text",
                        text=f"Mock prompt content for '{name}'. Connect to real 1C server for actual functionality."
                    )
                )
            ]
        )

    async def close(self):
        """Закрыть клиент."""
        logger.debug("Mock client closed")