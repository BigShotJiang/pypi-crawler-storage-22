# Mock version of MCP proxy for testing without 1C server

import asyncio
import sys

from .main import main as _main

def main():
    asyncio.run(_main())

if __name__ == "__main__":
    main()