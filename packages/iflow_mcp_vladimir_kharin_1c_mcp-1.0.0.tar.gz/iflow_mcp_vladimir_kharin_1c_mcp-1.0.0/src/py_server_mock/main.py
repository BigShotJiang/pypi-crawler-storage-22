"""Точка входа для тестирования без 1С."""

import sys
import os

# Добавляем путь к родительскому модулю
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from py_server.main_mock import main

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())