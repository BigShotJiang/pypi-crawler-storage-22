#!/usr/bin/env python3
"""
x64dbg MCP Server - Main entry point
"""
from . import mcp

if __name__ == "__main__":
    mcp.run()