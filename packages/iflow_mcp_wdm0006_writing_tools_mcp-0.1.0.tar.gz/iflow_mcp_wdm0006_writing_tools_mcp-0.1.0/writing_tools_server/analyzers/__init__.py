"""Analysis modules for different text analysis domains."""

from writing_tools_server.analyzers.ai_detection import AIDetectionAnalyzer
from writing_tools_server.analyzers.basic_stats import BasicStatsAnalyzer
from writing_tools_server.analyzers.keyword_analysis import KeywordAnalyzer
from writing_tools_server.analyzers.readability import ReadabilityAnalyzer
from writing_tools_server.analyzers.style_analysis import StyleAnalyzer

__all__ = [
    # Classes
    "BasicStatsAnalyzer",
    "ReadabilityAnalyzer",
    "KeywordAnalyzer",
    "StyleAnalyzer",
    "AIDetectionAnalyzer",
]


def initialize_analyzers(nlp_model, gpt2_manager, config):
    """Initialize all analyzers with required dependencies."""
    return {
        "basic_stats": BasicStatsAnalyzer(),
        "readability": ReadabilityAnalyzer(),
        "keyword": KeywordAnalyzer(nlp_model),
        "style": StyleAnalyzer(nlp_model),
        "ai_detection": AIDetectionAnalyzer(nlp_model, gpt2_manager, config),
    }
