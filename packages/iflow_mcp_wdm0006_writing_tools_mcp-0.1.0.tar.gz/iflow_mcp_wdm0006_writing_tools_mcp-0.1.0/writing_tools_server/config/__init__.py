"""Configuration management for the writing tools server."""

from writing_tools_server.config.loader import load_config

__all__ = [
    "load_config",
]
