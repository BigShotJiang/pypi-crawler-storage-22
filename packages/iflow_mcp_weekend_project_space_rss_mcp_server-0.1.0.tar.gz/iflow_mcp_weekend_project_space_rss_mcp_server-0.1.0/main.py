from rss_mcp_server import mcp

def main():
    """Main entry point for the RSS MCP Server."""
    mcp.run()

if __name__ == "__main__":
    main()