#!/usr/bin/env python3
"""MCP entry point for ChiKen"""
import sys
import os

# Add src directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

from backends.mcp.kb_mcp_server import mcp

def main():
    """Main entry point for MCP server"""
    mcp.run()

if __name__ == "__main__":
    main()