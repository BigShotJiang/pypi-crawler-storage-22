from setuptools import setup, find_packages

setup(
    name="iflow-mcp_yutarop_ros_mcp",
    version="0.1.0",
    description="MCP server for controlling ROS2 robots with natural language",
    packages=find_packages(),
    py_modules=["ros_general"],
    install_requires=[
        "httpx>=0.28.1",
        "mcp[cli]>=1.9.4",
        "websockets>=15.0.1",
    ],
    entry_points={
        "console_scripts": [
            "ros_general=ros_general:main",
        ],
    },
)