import asyncio
import os
import shutil
import subprocess
import json
from mcp.client.session import ClientSession
from mcp.client.stdio import StdioServerParameters, stdio_client
from dotenv import load_dotenv

load_dotenv()

async def test_mcp():
    server_config = {
        "command": "uvx",
        "args": ["--from", "iflow-mcp_zacarx-javasinktracer_mcp", "javasinktracer"],
        "values": {}
    }
    
    server_params = StdioServerParameters(
        command=server_config['command'],
        args=server_config['args'],
        env=os.environ.copy()
    )
    
    try:
        async with stdio_client(server_params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                tools = await session.list_tools()
                print(f"✅ 测试成功！获取到 {len(tools.tools)} 个工具")
                for tool in tools.tools:
                    print(f"  - {tool.name}: {tool.description}")
                return True
    except Exception as e:
        print(f"❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    result = asyncio.run(test_mcp())
    exit(0 if result else 1)