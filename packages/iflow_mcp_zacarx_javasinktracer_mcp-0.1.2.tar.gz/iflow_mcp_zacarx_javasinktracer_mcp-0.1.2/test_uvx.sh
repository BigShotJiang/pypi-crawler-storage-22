#!/bin/bash
python3 /app/auto-mcp-upload/scripts/mcp_local_tester.py --command uvx --args "--from iflow-mcp_zacarx-javasinktracer_mcp javasinktracer"