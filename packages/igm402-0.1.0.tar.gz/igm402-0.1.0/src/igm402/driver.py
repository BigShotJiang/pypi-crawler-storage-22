from __future__ import annotations

import re
import socket
import time
from dataclasses import dataclass
from enum import Enum
from typing import Literal, cast

import serial


# =============================================================================
# Exceptions
# =============================================================================
class IGM402Error(Exception):
    """Base class for IGM402 driver errors."""


class IGM402ProtocolError(IGM402Error):
    """Raised when response framing/format is invalid."""


class IGM402DeviceError(IGM402Error):
    """Raised when the device returns an explicit error response ('?...')."""

    def __init__(self, code: str, message: str, raw: str):
        super().__init__(f"IGM402 device error {code}: {message} (raw={raw!r})")
        self.code = code
        self.message = message
        self.raw = raw


class IGM402TimeoutError(IGM402Error):
    """Raised when no response arrives before timeout."""


class IGM402ReconfigureError(IGM402Error):
    """Raised when comm reconfiguration was attempted but relink failed."""


class IGM402UnsupportedCommandError(IGM402Error):
    """Raised when optional command families are unsupported."""


class IGM402UnsupportedTransportOperationError(IGM402Error):
    """Raised when a command is invalid for the current transport mode."""


# =============================================================================
# Enums / models
# =============================================================================
class PressureUnit(str, Enum):
    TORR = "T"
    MBAR = "M"
    PASCAL = "P"


class EmissionSetting(int, Enum):
    U100 = 0  # 100 uA
    MA4 = 1  # 4 mA


class RelayName(str, Enum):
    I = "I"
    A = "A"
    B = "B"


@dataclass(frozen=True)
class TripPoint:
    mode: Literal["on_below", "off_above"]
    value_torr: float


# =============================================================================
# Transport base
# =============================================================================
class BaseTransport:
    """Minimal transport interface used by HornetIGM402."""

    supports_serial_reconfigure: bool = False

    def open(self) -> None:
        raise NotImplementedError

    def close(self) -> None:
        raise NotImplementedError

    @property
    def is_open(self) -> bool:
        raise NotImplementedError

    def write(self, data: bytes) -> None:
        raise NotImplementedError

    def read_until(self, terminator: bytes, timeout_s: float | None = None) -> bytes:
        raise NotImplementedError

    def flush_input(self) -> None:
        raise NotImplementedError

    def flush_output(self) -> None:
        raise NotImplementedError

    def set_baudrate(self, baudrate: int) -> None:
        raise IGM402UnsupportedTransportOperationError(
            "Transport does not support runtime baudrate changes."
        )

    def set_parity(self, parity: Literal["N", "O", "E"]) -> None:
        raise IGM402UnsupportedTransportOperationError(
            "Transport does not support runtime parity changes."
        )


class SerialTransport(BaseTransport):
    """
    Local serial transport (pyserial).
    """

    supports_serial_reconfigure = True

    def __init__(
        self,
        port: str,
        *,
        baudrate: int = 19200,
        timeout_s: float = 0.25,
        bytesize: int = serial.EIGHTBITS,
        parity: str = serial.PARITY_NONE,
        stopbits: int = serial.STOPBITS_ONE,
    ) -> None:
        self.port = port
        self.baudrate = baudrate
        self.timeout_s = timeout_s
        self.bytesize = bytesize
        self.parity = parity
        self.stopbits = stopbits
        self._ser: serial.Serial | None = None

    def open(self) -> None:
        if self._ser is not None and self._ser.is_open:
            return
        self._ser = serial.Serial(
            port=self.port,
            baudrate=self.baudrate,
            timeout=self.timeout_s,
            write_timeout=self.timeout_s,
            bytesize=self.bytesize,
            parity=self.parity,
            stopbits=self.stopbits,
        )
        self.flush_input()
        self.flush_output()

    def close(self) -> None:
        if self._ser is not None and self._ser.is_open:
            self._ser.close()

    @property
    def is_open(self) -> bool:
        return bool(self._ser is not None and self._ser.is_open)

    def _require_open(self) -> serial.Serial:
        if self._ser is None or not self._ser.is_open:
            raise IGM402Error("SerialTransport is not open.")
        return self._ser

    def write(self, data: bytes) -> None:
        ser = self._require_open()
        ser.write(data)
        ser.flush()

    def read_until(self, terminator: bytes, timeout_s: float | None = None) -> bytes:
        ser = self._require_open()
        old_timeout = ser.timeout
        try:
            if timeout_s is not None:
                ser.timeout = timeout_s
            return ser.read_until(terminator)
        finally:
            ser.timeout = old_timeout

    def flush_input(self) -> None:
        self._require_open().reset_input_buffer()

    def flush_output(self) -> None:
        self._require_open().reset_output_buffer()

    def set_baudrate(self, baudrate: int) -> None:
        ser = self._require_open()
        ser.baudrate = baudrate
        self.baudrate = baudrate

    def set_parity(self, parity: Literal["N", "O", "E"]) -> None:
        ser = self._require_open()
        if parity == "N":
            ser.parity = serial.PARITY_NONE
            self.parity = serial.PARITY_NONE
        elif parity == "O":
            ser.parity = serial.PARITY_ODD
            self.parity = serial.PARITY_ODD
        elif parity == "E":
            ser.parity = serial.PARITY_EVEN
            self.parity = serial.PARITY_EVEN
        else:
            raise ValueError("parity must be one of 'N', 'O', 'E'")


class SocketTransport(BaseTransport):
    """
    TCP socket transport for RS485-to-Ethernet gateways.
    """

    supports_serial_reconfigure = False

    def __init__(self, host: str, port: int, *, timeout_s: float = 0.25) -> None:
        self.host = host
        self.port = port
        self.timeout_s = timeout_s
        self._sock: socket.socket | None = None
        self._rx_buf = bytearray()

    def open(self) -> None:
        if self._sock is not None:
            return
        sock = socket.create_connection((self.host, self.port), timeout=self.timeout_s)
        sock.settimeout(self.timeout_s)
        self._sock = sock
        self._rx_buf.clear()

    def close(self) -> None:
        if self._sock is not None:
            try:
                self._sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            self._sock.close()
            self._sock = None
            self._rx_buf.clear()

    @property
    def is_open(self) -> bool:
        return self._sock is not None

    def _require_open(self) -> socket.socket:
        if self._sock is None:
            raise IGM402Error("SocketTransport is not open.")
        return self._sock

    def write(self, data: bytes) -> None:
        self._require_open().sendall(data)

    def read_until(self, terminator: bytes, timeout_s: float | None = None) -> bytes:
        sock = self._require_open()
        if len(terminator) != 1:
            raise ValueError("SocketTransport.read_until expects a 1-byte terminator.")
        term = terminator[0]

        old_timeout = sock.gettimeout()
        try:
            if timeout_s is not None:
                sock.settimeout(timeout_s)

            idx = self._rx_buf.find(term)
            if idx != -1:
                out = bytes(self._rx_buf[: idx + 1])
                del self._rx_buf[: idx + 1]
                return out

            while True:
                chunk = sock.recv(4096)
                if not chunk:
                    out = bytes(self._rx_buf)
                    self._rx_buf.clear()
                    return out
                self._rx_buf.extend(chunk)
                idx = self._rx_buf.find(term)
                if idx != -1:
                    out = bytes(self._rx_buf[: idx + 1])
                    del self._rx_buf[: idx + 1]
                    return out
        finally:
            sock.settimeout(old_timeout)

    def flush_input(self) -> None:
        self._rx_buf.clear()

    def flush_output(self) -> None:
        # no-op at this layer
        pass


# =============================================================================
# Hornet IGM402 protocol driver
# =============================================================================
class HornetIGM402:
    _ERR_RE = re.compile(r"^\?(?P<address>[0-9A-Fa-f]{2})_(?P<msg>.+)\r?$")
    _OK_RE = re.compile(r"^\*(?P<address>[0-9A-Fa-f]{2})_(?P<payload>.+)\r?$")
    _SCI_RE = re.compile(r"([+\-]?\d+(?:\.\d+)?[Ee][+\-]?\d+)")

    def __init__(
        self,
        transport: BaseTransport,
        *,
        address: int = 1,
        node: int | None = None,  # backwards-compatible alias
        min_cmd_interval_s: float = 0.05,
    ) -> None:
        """
        Args:
            transport: SerialTransport or SocketTransport
            address: RS485 address [0..255], manual terminology
            node: Deprecated alias for address
            min_cmd_interval_s: minimum time between commands
        """
        if node is not None:
            address = node
        if not (0 <= address <= 0xFF):
            raise ValueError("address must be in [0, 255]")

        self.transport = transport
        self.address = address
        self.min_cmd_interval_s = min_cmd_interval_s
        self._last_tx = 0.0

        self.supports_ru: bool = False
        self.supports_rdig: bool = False

    @property
    def address_hex(self) -> str:
        return f"{self.address:02X}"

    @property
    def is_open(self) -> bool:
        return self.transport.is_open

    def open(self, *, probe: bool = True) -> None:
        self.transport.open()
        self.transport.flush_input()
        self.transport.flush_output()
        if probe:
            self._probe_ascii_protocol()
            self._probe_capabilities()

    def close(self) -> None:
        self.transport.close()

    def __enter__(self) -> "HornetIGM402":
        self.open(probe=True)
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    # --------------------- helpers ---------------------
    def _throttle(self) -> None:
        dt = time.monotonic() - self._last_tx
        if dt < self.min_cmd_interval_s:
            time.sleep(self.min_cmd_interval_s - dt)

    def _build_command(self, body: str) -> bytes:
        # Manual ASCII framing: # + address(2 hex) + cmd + CR
        return f"#{self.address_hex}{body}\r".encode("ascii")

    def _readline_cr(self, timeout_s: float | None = None) -> str:
        raw = self.transport.read_until(b"\r", timeout_s=timeout_s)
        if not raw:
            raise IGM402TimeoutError("Timed out waiting for response.")
        try:
            return raw.decode("ascii", errors="strict")
        except UnicodeDecodeError as exc:
            raise IGM402ProtocolError(f"Non-ASCII response: {raw!r}") from exc

    def _parse_response(self, resp: str) -> str:
        m_err = self._ERR_RE.match(resp)
        if m_err:
            addr = m_err.group("address").upper()
            msg = m_err.group("msg").strip()
            if addr != self.address_hex:
                raise IGM402ProtocolError(
                    f"Error response address mismatch: expected {self.address_hex}, got {addr}"
                )
            code = msg.split("_", 1)[0]
            raise IGM402DeviceError(code=code, message=msg, raw=resp)

        m_ok = self._OK_RE.match(resp)
        if not m_ok:
            raise IGM402ProtocolError(f"Malformed response: {resp!r}")

        addr = m_ok.group("address").upper()
        if addr != self.address_hex:
            raise IGM402ProtocolError(
                f"Response address mismatch: expected {self.address_hex}, got {addr}"
            )

        return m_ok.group("payload").strip()

    @staticmethod
    def _extract_float(payload: str) -> float:
        compact = payload.replace(" ", "")
        m = HornetIGM402._SCI_RE.search(compact)
        if m:
            return float(m.group(1))
        try:
            return float(payload.strip())
        except ValueError as exc:
            raise IGM402ProtocolError(
                f"No numeric value in payload: {payload!r}"
            ) from exc

    @staticmethod
    def _assert_prog_ok(payload: str) -> None:
        if "PROGM_OK" not in payload:
            raise IGM402ProtocolError(f"Expected PROGM_OK, got {payload!r}")

    @staticmethod
    def _payload_token(payload: str) -> str:
        return payload.strip().split("_", 1)[0].strip()

    def _send(
        self,
        body: str,
        *,
        expect_response: bool = True,
        disrupts_link: bool = False,
        opportunistic_ack_window_s: float = 0.08,
    ) -> str | None:
        self._throttle()
        self.transport.write(self._build_command(body))
        self._last_tx = time.monotonic()

        if disrupts_link:
            # Optional best-effort old-link ACK capture, never required for success
            try:
                maybe = self._readline_cr(timeout_s=opportunistic_ack_window_s).strip(
                    "\n"
                )
                try:
                    _ = self._parse_response(maybe)
                except Exception:
                    pass
            except Exception:
                pass
            return None

        if not expect_response:
            return None

        resp = self._readline_cr().strip("\n")
        return self._parse_response(resp)

    def _probe_ascii_protocol(self) -> None:
        try:
            _ = self.read_sw_version()
        except (IGM402TimeoutError, IGM402ProtocolError) as exc:
            raise IGM402ProtocolError(
                "ASCII probe failed. Device may be in binary mode, wrong address, "
                "or transport settings are incorrect."
            ) from exc

    def _probe_capabilities(self) -> None:
        try:
            _ = self.read_pressure_unit()
            self.supports_ru = True
        except Exception:
            self.supports_ru = False

        try:
            _ = self.read_ig_ion_current_a()
            self.supports_rdig = True
        except Exception:
            self.supports_rdig = False

    def _relink_probe(self, *, retries: int = 3, delay_s: float = 0.2) -> None:
        last_exc: Exception | None = None
        for _ in range(retries):
            try:
                _ = self.read_sw_version()
                return
            except Exception as exc:
                last_exc = exc
                time.sleep(delay_s)
        raise IGM402ReconfigureError(
            "Failed to re-establish communication after serial reconfiguration."
        ) from last_exc

    def _require_reconfigurable_transport(self) -> None:
        if not self.transport.supports_serial_reconfigure:
            raise IGM402UnsupportedTransportOperationError(
                "Changing gauge serial comm settings is disabled for TCP/socket transport."
            )

    # --------------------- basic ---------------------
    def read_sw_version(self) -> str:
        payload = self._send("VER")
        assert payload is not None
        return payload

    def read_ig_pressure_torr(self) -> float:
        payload = self._send("RD")
        assert payload is not None
        return self._extract_float(payload)

    def read_system_pressure_torr(self) -> float:
        payload = self._send("RDS")
        assert payload is not None
        return self._extract_float(payload)

    def read_cg_pressure_torr(self, cg: Literal[1, 2]) -> float:
        payload = self._send(f"RDCG{cg}")
        assert payload is not None
        return self._extract_float(payload)

    # --------------------- ig / degas ---------------------
    def ig_on(self) -> None:
        payload = self._send("IG1")
        assert payload is not None
        self._assert_prog_ok(payload)

    def ig_off(self) -> None:
        payload = self._send("IG0")
        assert payload is not None
        self._assert_prog_ok(payload)

    def read_ig_on(self) -> bool:
        payload = self._send("IGS")
        assert payload is not None
        return payload.startswith("1_")

    def degas_on(self) -> None:
        payload = self._send("DG1")
        assert payload is not None
        self._assert_prog_ok(payload)

    def degas_off(self) -> None:
        payload = self._send("DG0")
        assert payload is not None
        self._assert_prog_ok(payload)

    def read_degas_on(self) -> bool:
        payload = self._send("DGS")
        assert payload is not None
        return payload.startswith("1_")

    def read_ig_status_code(self) -> str:
        payload = self._send("RS")
        assert payload is not None
        return payload

    # --------------------- emission ---------------------
    def read_emission_setting(self) -> EmissionSetting:
        payload = self._send("SES")
        assert payload is not None
        token = self._payload_token(payload)
        try:
            return EmissionSetting(int(token))
        except ValueError as exc:
            raise IGM402ProtocolError(
                f"Invalid emission setting payload: {payload!r}"
            ) from exc

    def set_emission(self, setting: EmissionSetting) -> None:
        payload = self._send(f"SE{int(setting)}")
        assert payload is not None
        self._assert_prog_ok(payload)

    def set_filament(self, filament: Literal[1, 2]) -> None:
        payload = self._send(f"SF{filament}")
        assert payload is not None
        self._assert_prog_ok(payload)

    # --------------------- relays ---------------------
    def set_trip_point(
        self,
        relay: RelayName,
        mode: Literal["on_below", "off_above"],
        value_torr: float,
    ) -> None:
        sign = "+" if mode == "on_below" else "-"
        val = f"{abs(value_torr):.2E}"

        if relay == RelayName.I:
            body = f"SL{sign}{val}"
        elif relay == RelayName.A:
            body = f"SLA{sign}{val}"
        elif relay == RelayName.B:
            body = f"SLB{sign}{val}"
        else:
            raise ValueError(f"Unknown relay {relay}")

        payload = self._send(body)
        assert payload is not None
        self._assert_prog_ok(payload)

    def read_trip_point(
        self,
        relay: RelayName,
        mode: Literal["on_below", "off_above"],
    ) -> TripPoint:
        sign = "+" if mode == "on_below" else "-"
        if relay == RelayName.I:
            body = f"RL{sign}"
        elif relay == RelayName.A:
            body = f"RLA{sign}"
        elif relay == RelayName.B:
            body = f"RLB{sign}"
        else:
            raise ValueError(f"Unknown relay {relay}")

        payload = self._send(body)
        assert payload is not None
        return TripPoint(mode=mode, value_torr=self._extract_float(payload))

    # --------------------- units ---------------------
    def require_ru(self) -> None:
        if not self.supports_ru:
            raise IGM402UnsupportedCommandError(
                "RU/SU commands not supported by this firmware."
            )

    def read_pressure_unit(self) -> PressureUnit:
        payload = self._send("RU")
        assert payload is not None
        token = self._payload_token(payload)
        try:
            return PressureUnit(token)
        except ValueError as exc:
            raise IGM402ProtocolError(
                f"Invalid pressure unit payload: {payload!r}"
            ) from exc

    def set_pressure_unit(self, unit: PressureUnit) -> None:
        payload = self._send(f"SU{unit.value}")
        assert payload is not None
        self._assert_prog_ok(payload)

    # --------------------- CG calibration ---------------------
    def set_cg_zero(self, cg: Literal[1, 2], value_torr: float = 0.0) -> None:
        suffix = "A" if cg == 1 else "B"
        payload = self._send(f"TZ{suffix} {value_torr:.2E}")
        assert payload is not None
        self._assert_prog_ok(payload)

    def set_cg_span(self, cg: Literal[1, 2], value_torr: float = 760.0) -> None:
        suffix = "A" if cg == 1 else "B"
        payload = self._send(f"TS{suffix}{value_torr:.2E}")
        assert payload is not None
        self._assert_prog_ok(payload)

    # --------------------- optional RDIG* ---------------------
    def require_rdig(self) -> None:
        if not self.supports_rdig:
            raise IGM402UnsupportedCommandError(
                "RDIG* commands not supported by this firmware."
            )

    def read_ig_ion_current_a(self) -> float:
        payload = self._send("RDIGC")
        assert payload is not None
        return self._extract_float(payload)

    def read_ig_emission_current_a(self) -> float:
        payload = self._send("RDIGE")
        assert payload is not None
        return self._extract_float(payload)

    def read_ig_filament_voltage_v(self) -> float:
        payload = self._send("RDIGV")
        assert payload is not None
        return self._extract_float(payload)

    def read_ig_filament_current_a(self) -> float:
        payload = self._send("RDIGA")
        assert payload is not None
        return self._extract_float(payload)

    # --------------------- comm changes (serial only) ---------------------
    def unlock_comm_programming(self) -> None:
        payload = self._send("UNL")
        assert payload is not None
        self._assert_prog_ok(payload)

    def toggle_unl_function(self) -> bool:
        payload = self._send("TLU")
        assert payload is not None
        return payload.startswith("1_")

    def set_baud(
        self,
        baud: int,
        *,
        verify: bool = True,
        relink_retries: int = 3,
        relink_delay_s: float = 0.2,
    ) -> None:
        self._require_reconfigurable_transport()

        # optional: unlock before comm programming
        self.unlock_comm_programming()

        # send disruptive command (ACK may be racey/unreadable)
        self._send(f"SB{baud}", disrupts_link=True)

        # switch host serial side
        self.transport.set_baudrate(baud)

        time.sleep(relink_delay_s)
        self.transport.flush_input()
        self.transport.flush_output()

        if verify:
            self._relink_probe(retries=relink_retries, delay_s=relink_delay_s)

    def set_parity(
        self,
        parity: Literal["N", "O", "E"],
        *,
        verify: bool = True,
        relink_retries: int = 3,
        relink_delay_s: float = 0.2,
    ) -> None:
        self._require_reconfigurable_transport()

        p = parity.upper()
        if p not in {"N", "O", "E"}:
            raise ValueError("parity must be one of 'N', 'O', 'E'")
        p_lit = cast(Literal["N", "O", "E"], p)

        self.unlock_comm_programming()
        self._send(f"SP{p_lit}", disrupts_link=True)

        self.transport.set_parity(p_lit)

        time.sleep(relink_delay_s)
        self.transport.flush_input()
        self.transport.flush_output()

        if verify:
            self._relink_probe(retries=relink_retries, delay_s=relink_delay_s)

    def set_serial_comm(
        self,
        *,
        baud: int | None = None,
        parity: Literal["N", "O", "E"] | None = None,
        verify_each_step: bool = True,
        relink_retries: int = 3,
        relink_delay_s: float = 0.2,
    ) -> None:
        self._require_reconfigurable_transport()

        if parity is not None:
            self.set_parity(
                parity,
                verify=verify_each_step,
                relink_retries=relink_retries,
                relink_delay_s=relink_delay_s,
            )
        if baud is not None:
            self.set_baud(
                baud,
                verify=verify_each_step,
                relink_retries=relink_retries,
                relink_delay_s=relink_delay_s,
            )

    # --------------------- reset/defaults ---------------------
    def reset(self) -> None:
        self._send("RST", expect_response=False)

    def factory_defaults(self) -> None:
        payload = self._send("FAC")
        assert payload is not None
        self._assert_prog_ok(payload)
