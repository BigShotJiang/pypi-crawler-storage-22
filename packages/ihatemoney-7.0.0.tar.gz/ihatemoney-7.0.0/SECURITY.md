# Security Policy

## Supported Versions

| Version | Supported          |
|---------| ------------------ |
| 7.0.x   | :heavy_check_mark: |
| < 7.x   | :x:                |

## Reporting a Vulnerability

In order to report a vulnerability, you can either join the IRC channel `#ihatemoney` on libera.chat and ping active users available for a private message,
or write an email to bugs-ihatemoney “@” antipoul.fr This email address is an alias, so you can expect an answer from another address.
