#!/usr/bin/env python3
"""CLI for ihavecool - A curated collection of fascinating research concepts."""

import sys
import argparse
from datetime import datetime


# ASCII art banner
BANNER = """
╔════════════════════════════════════════════════════════════════╗
║                    🎯 IHaveCool ✨                             ║
║         Fascinating Research Concepts & Ideas Showcase          ║
╚════════════════════════════════════════════════════════════════╝
"""

# Cool research concepts
CONCEPTS = {
    "backdoor-safety": {
        "title": "Backdoor Safety Tuning",
        "description": "Defending neural networks against backdoor attacks",
        "keywords": ["security", "ML safety", "neural networks"],
    },
    "unlearning": {
        "title": "Generative Unlearning",
        "description": "Removing learned information from generative models",
        "keywords": ["privacy", "machine unlearning", "diffusion models"],
    },
    "gradient-attack": {
        "title": "Gradient Alignment Based Backdoor Attack",
        "description": "Advanced attack method using gradient-based optimization",
        "keywords": ["adversarial ML", "gradient alignment", "backdoor"],
    },
}


def list_concepts():
    """Display all available research concepts."""
    print(BANNER)
    print(f"  📚 Available Concepts ({len(CONCEPTS)} total):\n")
    for key, val in CONCEPTS.items():
        kw = ", ".join(val["keywords"])
        print(f"    • {val['title']}")
        print(f"      ID: {key}")
        print(f"      {val['description']}")
        print(f"      Tags: {kw}\n")


def show_concept(concept_id):
    """Show details for a specific concept."""
    if concept_id not in CONCEPTS:
        print(f"  ❌ Unknown concept: {concept_id}")
        print(f"  Available: {', '.join(CONCEPTS.keys())}")
        sys.exit(1)
    c = CONCEPTS[concept_id]
    print(BANNER)
    print(f"  📖 {c['title']}")
    print(f"  {c['description']}")
    print(f"  Keywords: {', '.join(c['keywords'])}")
    print(f"  Retrieved: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")


def main():
    parser = argparse.ArgumentParser(
        description="A curated collection of fascinating research concepts.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("list", help="List all research concepts")
    show_p = sub.add_parser("show", help="Show a specific concept")
    show_p.add_argument("concept_id", help="Concept identifier")
    sub.add_parser("version", help="Show version info")

    args = parser.parse_args()

    if args.command == "list":
        list_concepts()
    elif args.command == "show":
        show_concept(args.concept_id)
    elif args.command == "version":
        print("ihavecool CLI v0.1")
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
