"""
Demo docu
"""
from typing import Any


def add(a: Any, b: Any) -> Any:
    return a + b