"""Test detection and correction of Quranic verses in khutbah text."""

from ijaza import LLMProcessor, QuranValidator


KHUTBAH_TEXT = (
    "خليله أشهد أنّه بلغ الرسالة وأدى الأمانة ونصح للأمة\n"
    "ونصح للأمّة وكشف الله به الغمّة، وجاهد في سبيل الله حق جهاده حتّى آتاه اليقين.\n"
    "أما بعد يقول الله عز وجل: يا أيها الذين آمنوا\n"
    "اتقوا الله حق تقاته ولا تموتن إلا وأنتم مسلمون."
)


class TestLLMProcessorKhutbah:
    """Test LLMProcessor with real khutbah text."""

    def setup_method(self):
        self.processor = LLMProcessor()
        self.validator = QuranValidator()

    def test_detects_quran_quote(self):
        result = self.processor.process(KHUTBAH_TEXT)
        assert len(result.quotes) == 1

    def test_identifies_correct_reference(self):
        result = self.processor.process(KHUTBAH_TEXT)
        assert result.quotes[0].reference == "3:102"

    def test_corrects_to_uthmani_script(self):
        result = self.processor.process(KHUTBAH_TEXT)
        quote = result.quotes[0]
        expected_verse = self.validator.get_verse(surah=3, ayah=102)
        assert quote.was_corrected is True
        assert quote.corrected == expected_verse.text

    def test_high_confidence(self):
        result = self.processor.process(KHUTBAH_TEXT)
        assert result.quotes[0].confidence >= 0.90

    def test_corrected_text_replaces_ayah(self):
        result = self.processor.process(KHUTBAH_TEXT)
        expected_verse = self.validator.get_verse(surah=3, ayah=102)
        # The corrected text should be the full khutbah with the ayah
        # replaced by the authentic Uthmani script
        expected_text = (
            "خليله أشهد أنّه بلغ الرسالة وأدى الأمانة ونصح للأمة\n"
            "ونصح للأمّة وكشف الله به الغمّة، وجاهد في سبيل الله حق جهاده حتّى آتاه اليقين.\n"
            f"أما بعد يقول الله عز وجل: {expected_verse.text}."
        )
        assert result.corrected_text == expected_text


class TestDetectAndValidateKhutbah:
    """Test QuranValidator.detect_and_validate with khutbah text."""

    def setup_method(self):
        self.validator = QuranValidator()

    def test_detects_quran_content(self):
        detection = self.validator.detect_and_validate(KHUTBAH_TEXT)
        assert detection.detected is True

    def test_non_quran_segments_not_valid(self):
        detection = self.validator.detect_and_validate(KHUTBAH_TEXT)
        # The khutbah intro should not be flagged as Quran
        intro_segment = detection.segments[0]
        assert intro_segment.validation is not None
        assert intro_segment.validation.is_valid is False

    def test_ayah_segment_is_valid(self):
        detection = self.validator.detect_and_validate(KHUTBAH_TEXT)
        valid_segments = [
            s for s in detection.segments
            if s.validation and s.validation.is_valid
        ]
        assert len(valid_segments) == 1
        assert valid_segments[0].validation.reference == "3:102"
        assert valid_segments[0].validation.match_type == "fuzzy"
