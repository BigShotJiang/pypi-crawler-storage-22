"""
ildev-mongodb: SOLID, extensible MongoDB client for Python using Motor.

Install: pip install ildev-mongodb

Layers:
  1. AsyncCollectionProtocol – dict-based (document: dict[str, Any]), full CRUD.
  2. RepositoryProtocol[TCreate, TUpdate, TOut] – typed CRUD + to_doc_create, to_doc_update, from_doc_out.
  3. BaseAsyncCollection implements AsyncCollectionProtocol; BaseTypedRepository implements RepositoryProtocol.

Usage (dict-based):
    from ildev_mongodb import create_async_client, BaseAsyncClient

    async with create_async_client("mongodb://localhost:27017/") as client:
        db = client.get_database("mydb")
        coll = db.get_collection("items")
        await coll.insert_one({"name": "test"})

Usage (typed repository):
    from ildev_mongodb import create_async_client, BaseTypedRepository

    async with create_async_client() as client:
        raw = client.get_database("mydb").get_collection("items")
        repo = BaseTypedRepository(raw, to_doc_create=..., to_doc_update=..., from_doc_out=...)
        await repo.insert_one(my_doc)
"""

from ildev_mongodb.abstractions import (
    AsyncCollectionProtocol,
    AsyncDatabaseProtocol,
    AsyncMongoClientProtocol,
    FindOptions,
    RepositoryProtocol,
    TransactionalRepositoryProtocol,
)
from ildev_mongodb.di import create_async_client
from ildev_mongodb.exceptions import (
    IldevMongoDBConnectionError,
    IldevMongoDBError,
    UnsupportedOperationError,
)
from ildev_mongodb.implementations import (
    BaseAsyncClient,
    BaseAsyncCollection,
    BaseAsyncDatabase,
    BaseTypedRepository,
    TransactionalTypedRepository,
)
from ildev_mongodb.localization import configure_localization
from ildev_mongodb.logging_config import configure_logging
from ildev_mongodb.models import (
    TransactionalCreateBase,
    TransactionalOutBase,
    TypedCreateBase,
    TypedOutBase,
    TypedUpdateBase,
    ensure_create_id,
)

__all__ = [
    "AsyncMongoClientProtocol",
    "AsyncDatabaseProtocol",
    "AsyncCollectionProtocol",
    "FindOptions",
    "RepositoryProtocol",
    "TransactionalRepositoryProtocol",
    "IldevMongoDBConnectionError",
    "IldevMongoDBError",
    "UnsupportedOperationError",
    "BaseAsyncClient",
    "BaseAsyncCollection",
    "BaseAsyncDatabase",
    "BaseTypedRepository",
    "TransactionalTypedRepository",
    "TransactionalCreateBase",
    "TransactionalOutBase",
    "TypedCreateBase",
    "TypedOutBase",
    "TypedUpdateBase",
    "ensure_create_id",
    "configure_localization",
    "configure_logging",
    "create_async_client",
]
__version__ = "0.1.0"
