"""Abstractions (Protocols) for Dependency Inversion."""

from ildev_mongodb.abstractions.client import AsyncMongoClientProtocol
from ildev_mongodb.abstractions.collection import AsyncCollectionProtocol, FindOptions
from ildev_mongodb.abstractions.database import AsyncDatabaseProtocol
from ildev_mongodb.abstractions.repository import (
    TCreate,
    TOut,
    TUpdate,
    RepositoryProtocol,
)
from ildev_mongodb.abstractions.transactional_repository import (
    TransactionalRepositoryProtocol,
)

__all__ = [
    "AsyncMongoClientProtocol",
    "AsyncDatabaseProtocol",
    "AsyncCollectionProtocol",
    "FindOptions",
    "RepositoryProtocol",
    "TransactionalRepositoryProtocol",
    "TCreate",
    "TUpdate",
    "TOut",
]
