"""Protocol for async MongoDB client (Dependency Inversion)."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

if TYPE_CHECKING:
    from ildev_mongodb.abstractions.database import AsyncDatabaseProtocol


@runtime_checkable
class AsyncMongoClientProtocol(Protocol):
    """Interface for an async MongoDB client. Depend on this, not concrete implementations."""

    def get_database(self, name: str, **kwargs: Any) -> AsyncDatabaseProtocol:
        """Return a database by name."""
        ...

    def __getitem__(self, name: str) -> AsyncDatabaseProtocol:
        """Allow client['dbname'] style access."""
        ...

    async def close(self) -> None:
        """Close the client and release resources."""
        ...

    async def __aenter__(self) -> AsyncMongoClientProtocol:
        ...

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        ...
