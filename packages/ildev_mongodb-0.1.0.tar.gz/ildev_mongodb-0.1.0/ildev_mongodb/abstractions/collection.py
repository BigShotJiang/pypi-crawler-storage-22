"""Protocol for async MongoDB collection (Dependency Inversion)."""

from collections.abc import AsyncIterator
from typing import Any, Protocol, TypedDict, runtime_checkable


class FindOptions(TypedDict, total=False):
    """Options for find/find_one: sort, limit, skip."""

    sort: Any  # BSON sort spec: [(k, 1|-1)] or {k: 1|-1}
    limit: int
    skip: int


@runtime_checkable
class AsyncCollectionProtocol(Protocol):
    """Interface for an async MongoDB collection. Depend on this, not concrete implementations."""

    @property
    def name(self) -> str:
        """Collection name."""
        ...

    async def insert_one(self, document: dict[str, Any], **kwargs: Any) -> Any:
        """Insert a single document. Returns result with inserted_id."""
        ...

    async def insert_many(
        self, documents: list[dict[str, Any]], **kwargs: Any
    ) -> Any:
        """Insert multiple documents. Returns result with inserted_ids."""
        ...

    async def find_one(
        self,
        filter: dict[str, Any] | None = None,
        *,
        options: FindOptions | None = None,
        **kwargs: Any,
    ) -> dict[str, Any] | None:
        """Return one document matching the filter, or None. options: sort, limit, skip."""
        ...

    def find(
        self,
        filter: dict[str, Any] | None = None,
        *,
        options: FindOptions | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[dict[str, Any]]:
        """Return an async iterator over documents matching the filter. options: sort, limit, skip."""
        ...

    async def update_one(
        self,
        filter: dict[str, Any],
        update: dict[str, Any],
        **kwargs: Any,
    ) -> Any:
        """Update at most one document matching the filter."""
        ...

    async def update_many(
        self,
        filter: dict[str, Any],
        update: dict[str, Any],
        **kwargs: Any,
    ) -> Any:
        """Update all documents matching the filter."""
        ...

    async def delete_one(self, filter: dict[str, Any], **kwargs: Any) -> Any:
        """Delete at most one document matching the filter."""
        ...

    async def delete_many(self, filter: dict[str, Any], **kwargs: Any) -> Any:
        """Delete all documents matching the filter."""
        ...

    async def count_documents(
        self, filter: dict[str, Any], **kwargs: Any
    ) -> int:
        """Return the number of documents matching the filter."""
        ...

    async def aggregate(
        self, pipeline: list[dict[str, Any]], **kwargs: Any
    ) -> list[dict[str, Any]]:
        """Run an aggregation pipeline and return results as a list of dicts."""
        ...
