"""Protocol for async MongoDB database (Dependency Inversion)."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

if TYPE_CHECKING:
    from ildev_mongodb.abstractions.collection import AsyncCollectionProtocol


@runtime_checkable
class AsyncDatabaseProtocol(Protocol):
    """Interface for an async MongoDB database. Depend on this, not concrete implementations."""

    def get_collection(self, name: str, **kwargs: Any) -> AsyncCollectionProtocol:
        """Return a collection by name."""
        ...

    def __getitem__(self, name: str) -> AsyncCollectionProtocol:
        """Allow db['collname'] style access."""
        ...

    @property
    def name(self) -> str:
        """Database name."""
        ...
