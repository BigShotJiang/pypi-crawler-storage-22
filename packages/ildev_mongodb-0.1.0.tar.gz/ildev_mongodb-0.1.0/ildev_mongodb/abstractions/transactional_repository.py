"""Transactional (append-only) repository protocol: read + insert only, no update/delete."""

from __future__ import annotations

from collections.abc import AsyncIterator, Callable
from typing import TYPE_CHECKING, Any, Protocol, TypeVar, runtime_checkable

from ildev_mongodb.abstractions.collection import FindOptions
from ildev_mongodb.models import TransactionalCreateBase, TransactionalOutBase

if TYPE_CHECKING:
    from ildev_mongodb.abstractions.collection import AsyncCollectionProtocol

TCreate = TypeVar("TCreate", bound=TransactionalCreateBase)
TOut = TypeVar("TOut", bound=TransactionalOutBase)


@runtime_checkable
class TransactionalRepositoryProtocol(Protocol[TCreate, TOut]):
    """
    Append-only repository: insert and read only.

    Supports: insert_one, insert_many, find_one, find, count_documents.
    No to_doc_update and no update/delete operations.
    """

    @property
    def name(self) -> str:
        """Collection/repository name."""
        ...

    @property
    def collection(self) -> AsyncCollectionProtocol:
        """Underlying dict-based collection."""
        ...

    @property
    def to_doc_create(self) -> Callable[[TCreate], dict[str, Any]]:
        """Encode TCreate to a BSON-ready dict for insert."""
        ...

    @property
    def from_doc_out(self) -> Callable[[dict[str, Any]], TOut]:
        """Decode a stored dict to TOut for find_one/find."""
        ...

    async def insert_one(self, document: TCreate, **kwargs: Any) -> Any:
        """Insert one document of type TCreate."""
        ...

    async def insert_many(self, documents: list[TCreate], **kwargs: Any) -> Any:
        """Insert many documents of type TCreate."""
        ...

    async def find_one(
        self,
        filter: dict[str, Any] | None = None,
        *,
        options: FindOptions | None = None,
        **kwargs: Any,
    ) -> TOut | None:
        """Return one document as TOut, or None. options: sort, limit, skip."""
        ...

    def find(
        self,
        filter: dict[str, Any] | None = None,
        *,
        options: FindOptions | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[TOut]:
        """Async iterate over documents as TOut. options: sort, limit, skip."""
        ...

    async def count_documents(
        self, filter: dict[str, Any], **kwargs: Any
    ) -> int:
        """Return the number of documents matching the filter."""
        ...

    async def aggregate(
        self, pipeline: list[dict[str, Any]], **kwargs: Any
    ) -> list[TOut]:
        """Run an aggregation pipeline and return results mapped to TOut."""
        ...
