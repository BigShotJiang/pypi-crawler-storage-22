"""Dependency injection: factory to create clients from configuration."""

from ildev_mongodb.di.container import create_async_client

__all__ = ["create_async_client"]
