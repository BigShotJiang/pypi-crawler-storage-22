"""DI factory: create async MongoDB client (Motor)."""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import Any, AsyncIterator

from ildev_mongodb.abstractions import AsyncMongoClientProtocol
from ildev_mongodb.implementations import BaseAsyncClient


@asynccontextmanager
async def create_async_client(
    uri: str = "mongodb://localhost:27017/",
    **kwargs: Any,
) -> AsyncIterator[AsyncMongoClientProtocol]:
    """
    Async context manager that yields an async MongoDB client (Motor, DI entry point).

    Args:
        uri: MongoDB connection URI (default: mongodb://localhost:27017/).
        **kwargs: Passed through to Motor AsyncIOMotorClient.

    Yields:
        A client satisfying AsyncMongoClientProtocol (BaseAsyncClient).
    """
    client = BaseAsyncClient(uri=uri, **kwargs)
    async with client:
        yield client
