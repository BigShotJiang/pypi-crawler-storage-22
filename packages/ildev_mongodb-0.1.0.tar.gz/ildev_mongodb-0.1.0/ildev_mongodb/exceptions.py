"""Library-specific exceptions for ildev-mongodb.

Public messages are generic and safe for logging or display. The original
driver/backend exception is available as __cause__ for server-side debugging only.
"""

from __future__ import annotations

# Fixed messages: no formatting, no user/connection/data in str()
_MSG_OPERATION = "Database operation failed."
_MSG_CONNECTION = "Database connection failed."
_MSG_UNSUPPORTED = "Append-only repository does not support update or delete."

from ildev_mongodb.localization import get_message


class IldevMongoDBError(Exception):
    """
    Raised when a database operation fails.

    The public message is generic and must not expose call stacks, URIs,
    or other sensitive data. The original exception is in __cause__ and
    should be used only in server-side logs, never sent to clients.
    """

    def __init__(self, message: str | None = None) -> None:
        # When no explicit message is given, use the (possibly localized) default.
        final = message if message is not None else get_message("operation_failed", _MSG_OPERATION)
        super().__init__(final)


class IldevMongoDBConnectionError(IldevMongoDBError):
    """Raised when connecting to the database fails."""

    def __init__(self) -> None:
        super().__init__(get_message("connection_failed", _MSG_CONNECTION))


class UnsupportedOperationError(IldevMongoDBError):
    """Raised when an append-only (transactional) repository is used for update or delete."""

    def __init__(self, message: str | None = None) -> None:
        final = message if message is not None else get_message(
            "unsupported_operation", _MSG_UNSUPPORTED
        )
        super().__init__(final)
