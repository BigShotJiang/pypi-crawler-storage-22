"""Base repository: client/database/collection implementing Async*Protocol (dict-based)."""

from __future__ import annotations

import asyncio
import functools
import logging
from collections.abc import AsyncIterator
from typing import Any

from motor.motor_asyncio import AsyncIOMotorClient as _MotorClient
from motor.motor_asyncio import AsyncIOMotorDatabase as _MotorDatabase

from ildev_mongodb.abstractions import (
    AsyncCollectionProtocol,
    AsyncDatabaseProtocol,
    AsyncMongoClientProtocol,
)
from ildev_mongodb.abstractions.collection import FindOptions
from ildev_mongodb.exceptions import IldevMongoDBConnectionError, IldevMongoDBError
from ildev_mongodb.logging_config import LOGGER_NAME


def _wrap_db_error(
    exc_class: type[IldevMongoDBError] = IldevMongoDBError,
):
    """Decorator: catch Exception and re-raise exc_class() from e. Supports async and sync."""

    logger = logging.getLogger(LOGGER_NAME)

    def decorator(func: Any) -> Any:
        if asyncio.iscoroutinefunction(func):

            @functools.wraps(func)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                try:
                    return await func(*args, **kwargs)
                except Exception as e:
                    # Log a structured, but safe, error event. Do not log arguments or raw errors.
                    logger.error(
                        "database_operation_failed",
                        extra={
                            "event": "db_error",
                            "operation": getattr(func, "__name__", "<unknown>"),
                            "exc_type": type(e).__name__,
                            "error_class": exc_class.__name__,
                        },
                    )
                    raise exc_class() from e

            return async_wrapper
        else:

            @functools.wraps(func)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    logger.error(
                        "database_operation_failed",
                        extra={
                            "event": "db_error",
                            "operation": getattr(func, "__name__", "<unknown>"),
                            "exc_type": type(e).__name__,
                            "error_class": exc_class.__name__,
                        },
                    )
                    raise exc_class() from e

            return sync_wrapper

    return decorator


def _merge_find_options(
    kwargs: dict[str, Any], options: FindOptions | None
) -> dict[str, Any]:
    if not options:
        return kwargs
    out = dict(kwargs)
    for k in ("sort", "limit", "skip"):
        if k in options:
            out[k] = options[k]
    return out


def _kwargs_project_exclude_id(kwargs: dict[str, Any]) -> dict[str, Any]:
    """Merge projection so _id is excluded (Motor-style projection={"_id": 0})."""
    out = dict(kwargs)
    proj = dict(out.get("projection", {}))
    proj["_id"] = 0
    out["projection"] = proj
    return out


class BaseAsyncCollection(AsyncCollectionProtocol):
    """Async collection implementing AsyncCollectionProtocol using Motor (dict[str, Any]).
    find_one and find use projection={"_id": 0} so _id is excluded from returned documents.
    """

    def __init__(self, collection: Any) -> None:
        self._coll = collection

    @property
    def name(self) -> str:
        return self._coll.name

    @_wrap_db_error()
    async def insert_one(self, document: dict[str, Any], **kwargs: Any) -> Any:
        return await self._coll.insert_one(document, **kwargs)

    @_wrap_db_error()
    async def insert_many(
        self, documents: list[dict[str, Any]], **kwargs: Any
    ) -> Any:
        return await self._coll.insert_many(documents, **kwargs)

    @_wrap_db_error()
    async def find_one(
        self,
        filter: dict[str, Any] | None = None,
        *,
        options: FindOptions | None = None,
        **kwargs: Any,
    ) -> dict[str, Any] | None:
        kwargs = _kwargs_project_exclude_id(_merge_find_options(kwargs, options))
        return await self._coll.find_one(filter or {}, **kwargs)

    @_wrap_db_error()
    def find(
        self,
        filter: dict[str, Any] | None = None,
        *,
        options: FindOptions | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[dict[str, Any]]:
        kwargs = _kwargs_project_exclude_id(_merge_find_options(kwargs, options))
        cursor = self._coll.find(filter or {}, **kwargs)

        async def _iter() -> AsyncIterator[dict[str, Any]]:
            try:
                async for doc in cursor:
                    yield doc
            except Exception as e:
                raise IldevMongoDBError() from e

        return _iter()

    @_wrap_db_error()
    async def update_one(
        self,
        filter: dict[str, Any],
        update: dict[str, Any],
        **kwargs: Any,
    ) -> Any:
        return await self._coll.update_one(filter, update, **kwargs)

    @_wrap_db_error()
    async def update_many(
        self,
        filter: dict[str, Any],
        update: dict[str, Any],
        **kwargs: Any,
    ) -> Any:
        return await self._coll.update_many(filter, update, **kwargs)

    @_wrap_db_error()
    async def delete_one(self, filter: dict[str, Any], **kwargs: Any) -> Any:
        return await self._coll.delete_one(filter, **kwargs)

    @_wrap_db_error()
    async def delete_many(self, filter: dict[str, Any], **kwargs: Any) -> Any:
        return await self._coll.delete_many(filter, **kwargs)

    @_wrap_db_error()
    async def count_documents(
        self, filter: dict[str, Any], **kwargs: Any
    ) -> int:
        return await self._coll.count_documents(filter, **kwargs)

    @_wrap_db_error()
    async def aggregate(
        self, pipeline: list[dict[str, Any]], **kwargs: Any
    ) -> list[dict[str, Any]]:
        """
        Run an aggregation pipeline and return results as a list of dicts.

        Like find/find_one, this excludes _id from the returned documents so
        repository mappers (from_doc_out) always see dicts without _id.
        """
        cursor = self._coll.aggregate(pipeline, **kwargs)
        out: list[dict[str, Any]] = []
        async for doc in cursor:
            d = dict(doc)
            d.pop("_id", None)
            out.append(d)
        return out


class BaseAsyncDatabase(AsyncDatabaseProtocol):
    """Async database implementing AsyncDatabaseProtocol using Motor."""

    def __init__(self, database: _MotorDatabase) -> None:
        self._db = database

    @property
    def name(self) -> str:
        return self._db.name

    @property
    def motor_db(self) -> _MotorDatabase:
        """Underlying Motor database (e.g. for Beanie init_beanie)."""
        return self._db

    @_wrap_db_error()
    def get_collection(self, name: str, **kwargs: Any) -> AsyncCollectionProtocol:
        return BaseAsyncCollection(self._db.get_collection(name, **kwargs))

    @_wrap_db_error()
    def __getitem__(self, name: str) -> AsyncCollectionProtocol:
        return BaseAsyncCollection(self._db[name])


class BaseAsyncClient(AsyncMongoClientProtocol):
    """Async MongoDB client implementing AsyncMongoClientProtocol using Motor."""

    @_wrap_db_error(IldevMongoDBConnectionError)
    def __init__(
        self,
        host: str | None = None,
        port: int | None = None,
        uri: str | None = None,
        **kwargs: Any,
    ) -> None:
        if uri is not None:
            self._client: _MotorClient = _MotorClient(uri, **kwargs)
        elif host is not None or port is not None:
            self._client = _MotorClient(
                host=host or "localhost", port=port or 27017, **kwargs
            )
        else:
            self._client = _MotorClient(**kwargs)

    @property
    def motor_client(self) -> _MotorClient:
        """Underlying Motor client (e.g. for Beanie init_beanie)."""
        return self._client

    @_wrap_db_error()
    def get_database(self, name: str, **kwargs: Any) -> AsyncDatabaseProtocol:
        return BaseAsyncDatabase(self._client.get_database(name, **kwargs))

    @_wrap_db_error()
    def __getitem__(self, name: str) -> AsyncDatabaseProtocol:
        return BaseAsyncDatabase(self._client[name])

    @_wrap_db_error()
    async def close(self) -> None:
        self._client.close()

    async def __aenter__(self) -> BaseAsyncClient:
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        await self.close()
