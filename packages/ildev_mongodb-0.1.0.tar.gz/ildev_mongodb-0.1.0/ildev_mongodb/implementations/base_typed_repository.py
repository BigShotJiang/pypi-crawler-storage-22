"""
Base typed repository: RepositoryProtocol implemented by extending BaseAsyncCollection.

Subclasses BaseAsyncCollection; adds to_doc_create, to_doc_update, from_doc_out
and overrides only the methods that change types (insert_one, insert_many,
find_one, find, update_one, update_many). delete_one, delete_many, count_documents,
and name are inherited. The underlying dict-based collection is self.
"""

from __future__ import annotations

from collections.abc import AsyncIterator, Callable
from typing import Any, Generic

from ildev_mongodb.abstractions import AsyncCollectionProtocol, RepositoryProtocol
from ildev_mongodb.abstractions.collection import FindOptions
from ildev_mongodb.abstractions.repository import TCreate, TOut, TUpdate
from ildev_mongodb.implementations.base_repository import BaseAsyncCollection


class BaseTypedRepository(
    BaseAsyncCollection,
    Generic[TCreate, TUpdate, TOut],
    RepositoryProtocol[TCreate, TUpdate, TOut],
):
    """
    Base implementation of RepositoryProtocol by extending BaseAsyncCollection.

    Takes the same raw collection as BaseAsyncCollection (e.g. Motor or fake).
    Overrides only insert/update/find to apply to_doc_create, to_doc_update,
    from_doc_out; inherits delete_one, delete_many, count_documents, name.
    """

    def __init__(
        self,
        collection: Any,
        *,
        to_doc_create: Callable[[TCreate], dict[str, Any]],
        to_doc_update: Callable[[TUpdate], dict[str, Any]],
        from_doc_out: Callable[[dict[str, Any]], TOut],
    ) -> None:
        super().__init__(collection)
        self._to_doc_create = to_doc_create
        self._to_doc_update = to_doc_update
        self._from_doc_out = from_doc_out

    @property
    def collection(self) -> AsyncCollectionProtocol:
        """Underlying dict-based collection (this instance, as AsyncCollectionProtocol)."""
        return self

    @property
    def to_doc_create(self) -> Callable[[TCreate], dict[str, Any]]:
        """Encode TCreate to a BSON-ready dict for insert."""
        return self._to_doc_create

    @property
    def to_doc_update(self) -> Callable[[TUpdate], dict[str, Any]]:
        """Encode TUpdate to a BSON-ready dict for update."""
        return self._to_doc_update

    @property
    def from_doc_out(self) -> Callable[[dict[str, Any]], TOut]:
        """Decode a stored dict to TOut for find_one/find."""
        return self._from_doc_out

    async def insert_one(self, document: TCreate, **kwargs: Any) -> Any:
        return await super().insert_one(self._to_doc_create(document), **kwargs)

    async def insert_many(self, documents: list[TCreate], **kwargs: Any) -> Any:
        return await super().insert_many(
            [self._to_doc_create(d) for d in documents], **kwargs
        )

    async def find_one(
        self,
        filter: dict[str, Any] | None = None,
        *,
        options: FindOptions | None = None,
        **kwargs: Any,
    ) -> TOut | None:
        raw = await super().find_one(filter or {}, options=options, **kwargs)
        return self._from_doc_out(raw) if raw is not None else None

    def find(
        self,
        filter: dict[str, Any] | None = None,
        *,
        options: FindOptions | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[TOut]:
        parent_cursor = super().find(filter or {}, options=options, **kwargs)

        async def _iter() -> AsyncIterator[TOut]:
            async for doc in parent_cursor:
                yield self._from_doc_out(doc)

        return _iter()

    async def update_one(
        self, filter: dict[str, Any], update: TUpdate, **kwargs: Any
    ) -> Any:
        return await super().update_one(
            filter, self._to_doc_update(update), **kwargs
        )

    async def update_many(
        self, filter: dict[str, Any], update: TUpdate, **kwargs: Any
    ) -> Any:
        return await super().update_many(
            filter, self._to_doc_update(update), **kwargs
        )

    async def aggregate(
        self, pipeline: list[dict[str, Any]], **kwargs: Any
    ) -> list[TOut]:
        raw = await super().aggregate(pipeline, **kwargs)
        return [self._from_doc_out(d) for d in raw]
