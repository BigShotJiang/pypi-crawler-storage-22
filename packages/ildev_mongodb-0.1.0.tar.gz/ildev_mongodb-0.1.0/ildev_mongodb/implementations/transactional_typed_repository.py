"""
Transactional (append-only) typed repository: read + insert only.

Implements TransactionalRepositoryProtocol by extending BaseAsyncCollection.
update_one, update_many, delete_one, delete_many raise UnsupportedOperationError.
TOut is bound to TransactionalOutBase (id, created_at only; no updated_at).
"""

from __future__ import annotations

from collections.abc import AsyncIterator, Callable
from typing import Any, Generic

from ildev_mongodb.abstractions import AsyncCollectionProtocol, TransactionalRepositoryProtocol
from ildev_mongodb.abstractions.collection import FindOptions
from ildev_mongodb.abstractions.transactional_repository import TCreate, TOut
from ildev_mongodb.exceptions import UnsupportedOperationError
from ildev_mongodb.implementations.base_repository import BaseAsyncCollection


class TransactionalTypedRepository(
    BaseAsyncCollection,
    Generic[TCreate, TOut],
    TransactionalRepositoryProtocol[TCreate, TOut],
):
    """
    Append-only repository: insert and read only.

    TOut is bound to TransactionalOutBase (id, created_at; no updated_at).
    update_one, update_many, delete_one, delete_many raise UnsupportedOperationError.
    """

    def __init__(
        self,
        collection: Any,
        *,
        to_doc_create: Callable[[TCreate], dict[str, Any]],
        from_doc_out: Callable[[dict[str, Any]], TOut],
    ) -> None:
        super().__init__(collection)
        self._to_doc_create = to_doc_create
        self._from_doc_out = from_doc_out

    @property
    def collection(self) -> AsyncCollectionProtocol:
        return self

    @property
    def to_doc_create(self) -> Callable[[TCreate], dict[str, Any]]:
        return self._to_doc_create

    @property
    def from_doc_out(self) -> Callable[[dict[str, Any]], TOut]:
        return self._from_doc_out

    async def insert_one(self, document: TCreate, **kwargs: Any) -> Any:
        return await super().insert_one(self._to_doc_create(document), **kwargs)

    async def insert_many(self, documents: list[TCreate], **kwargs: Any) -> Any:
        return await super().insert_many(
            [self._to_doc_create(d) for d in documents], **kwargs
        )

    async def find_one(
        self,
        filter: dict[str, Any] | None = None,
        *,
        options: FindOptions | None = None,
        **kwargs: Any,
    ) -> TOut | None:
        raw = await super().find_one(filter or {}, options=options, **kwargs)
        return self._from_doc_out(raw) if raw is not None else None

    def find(
        self,
        filter: dict[str, Any] | None = None,
        *,
        options: FindOptions | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[TOut]:
        parent_cursor = super().find(filter or {}, options=options, **kwargs)

        async def _iter() -> AsyncIterator[TOut]:
            async for doc in parent_cursor:
                yield self._from_doc_out(doc)

        return _iter()

    async def aggregate(
        self, pipeline: list[dict[str, Any]], **kwargs: Any
    ) -> list[TOut]:
        raw = await super().aggregate(pipeline, **kwargs)
        return [self._from_doc_out(d) for d in raw]

    async def update_one(
        self, filter: dict[str, Any], update: Any, **kwargs: Any
    ) -> Any:
        raise UnsupportedOperationError()

    async def update_many(
        self, filter: dict[str, Any], update: Any, **kwargs: Any
    ) -> Any:
        raise UnsupportedOperationError()

    async def delete_one(self, filter: dict[str, Any], **kwargs: Any) -> Any:
        raise UnsupportedOperationError()

    async def delete_many(self, filter: dict[str, Any], **kwargs: Any) -> Any:
        raise UnsupportedOperationError()
