"""Simple, extensible localization for ildev-mongodb.

Users can provide a JSON file with message overrides:

    {
      "operation_failed": "Operace selhala.",
      "connection_failed": "Připojení k databázi selhalo.",
      "unsupported_operation": "Operace není podporována."
    }

Call configure_localization(path) once at startup to load/override messages.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping


_DEFAULT_MESSAGES: dict[str, str] = {
    "operation_failed": "Database operation failed.",
    "connection_failed": "Database connection failed.",
    "unsupported_operation": "Append-only repository does not support update or delete.",
}


@dataclass
class _Localizer:
    messages: dict[str, str] = field(default_factory=lambda: dict(_DEFAULT_MESSAGES))

    def load_mapping(self, mapping: Mapping[str, Any]) -> None:
        """Merge a mapping of key -> message (strings only) into the current messages."""
        for key, value in mapping.items():
            if isinstance(key, str) and isinstance(value, str):
                self.messages[key] = value

    def load_file(self, path: str | Path, *, encoding: str = "utf-8") -> None:
        """Load a JSON file with key -> message and merge it into the current messages."""
        data = json.loads(Path(path).read_text(encoding=encoding))
        if isinstance(data, dict):
            self.load_mapping(data)

    def get(self, key: str, fallback: str) -> str:
        """Return localized message for key, or fallback if not found."""
        return self.messages.get(key, fallback)


_LOCALIZER = _Localizer()


def configure_localization(path: str | Path, *, encoding: str = "utf-8") -> None:
    """Load/merge messages from a JSON file at runtime."""
    _LOCALIZER.load_file(path, encoding=encoding)


def get_message(key: str, fallback: str) -> str:
    """Get a localized message for key, falling back to the provided default."""
    return _LOCALIZER.get(key, fallback)

