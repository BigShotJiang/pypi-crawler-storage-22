"""JSON logging configuration for ildev-mongodb.

Usage:

    from ildev_mongodb import configure_logging

    # Log JSON lines to a specific file
    configure_logging("logs/ildev_mongodb.log")

    # Or to stderr by default
    configure_logging()
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any


LOGGER_NAME = "ildev_mongodb"


class _JsonFormatter(logging.Formatter):
    """Format log records as one JSON object per line."""

    def format(self, record: logging.LogRecord) -> str:  # type: ignore[override]
        payload: dict[str, Any] = {
            "timestamp": self.formatTime(record, datefmt="%Y-%m-%dT%H:%M:%S%z"),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        # Attach a few safe, structured fields
        for key in ("event", "operation", "exc_type", "error_class"):
            if hasattr(record, key):
                payload[key] = getattr(record, key)
        return json.dumps(payload, ensure_ascii=False)


def configure_logging(
    path: str | Path | None = None,
    *,
    level: int | str = logging.INFO,
) -> logging.Logger:
    """Configure JSON logging for the ildev_mongodb logger.

    - If path is provided, logs are written to that file (UTF-8, append).
    - If path is None, logs go to stderr.
    - Does NOT touch the root logger or any other loggers.
    """
    logger = logging.getLogger(LOGGER_NAME)

    # Normalize level
    if isinstance(level, str):
        level = logging.getLevelName(level.upper())
    logger.setLevel(level)  # type: ignore[arg-type]

    # Remove existing handlers we previously attached
    logger.handlers = []

    if path is None:
        handler: logging.Handler = logging.StreamHandler()
    else:
        handler = logging.FileHandler(Path(path), encoding="utf-8")

    handler.setFormatter(_JsonFormatter())
    logger.addHandler(handler)
    logger.propagate = False
    return logger

