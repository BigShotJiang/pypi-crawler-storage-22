"""
Base dataclass models for typed repositories.

Transactional (append-only): TransactionalCreateBase, TransactionalOutBase.
Full CRUD: TypedCreateBase (id auto-generated), TypedOutBase, TypedUpdateBase.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from uuid import UUID, uuid4


# ---- Full CRUD typed bases (used as bounds for RepositoryProtocol) ----


@dataclass(frozen=False)
class TypedCreateBase:
    """
    Base for full-CRUD create models with auto-generated id.

    id defaults to a new UUID per instance. created_at defaults to now (UTC).
    Override or pass id= / created_at= when needed. Subclass and add domain fields.
    """

    id: UUID = field(default_factory=uuid4)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass(frozen=False)
class TypedOutBase:
    """
    Standard required fields for full-CRUD read output.

    id, created_at, updated_at are the usual audit shape. id defaults to None;
    created_at/updated_at default to now(UTC) so subclasses can build from
    partial docs. Subclass and add domain fields.
    """

    id: UUID | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


# ---- Transactional (append-only / event-sourcing) bases ----


@dataclass(frozen=False)
class TransactionalCreateBase(TypedCreateBase):
    """
    Minimum required fields for transactional (append-only) create models.

    Subtype of TypedCreateBase so TransactionalTypedRepository can reuse
    BaseTypedRepository. Subclass and add domain fields.
    """

    pass


@dataclass(frozen=False)
class TransactionalOutBase:
    """
    Standard required fields for transactional / event-sourcing read output.

    Append-only means no updates: only id and created_at. No updated_at.
    id from stored document; created_at when the record was written.
    Subclass and add domain fields.
    """

    id: UUID | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass(frozen=False)
class TypedUpdateBase:
    """
    Minimum required field for update models: when the update was applied.

    updated_at defaults to now(UTC) so subclasses can use UpdateModel(value=...).
    Subclass and add domain fields (e.g. value, status).
    """

    updated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


# ---- Helpers ----


def ensure_create_id(obj: TypedCreateBase) -> None:
    """
    Set obj.id to a new UUID if it is None.

    No-op if obj has no id or it is already set. Useful when mixing
    TypedCreateBase with id: UUID | None in subclasses.
    """
    if getattr(obj, "id", None) is None:
        object.__setattr__(obj, "id", uuid4())
