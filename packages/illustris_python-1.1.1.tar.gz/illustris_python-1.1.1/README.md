# README #

The Illustris[TNG] Simulation: Public Data Release

Example code (Python).

See the [IllustrisTNG Website Data Access Page](http://www.tng-project.org/data/) for details.

# Install

Updates are rare, so a `pip` install should work well:

```
pip install illustris_python
```

or the latest development version:

```
git clone git@github.com:illustristng/illustris_python.git
cd illustris_python
pip install .
```
