# ilovejpngs
Why should pngs use the alpha channel? 
<h2>Before<img src="./images/before.png" alt="Screenshot" width="200"/><img src="./images/after.png" alt="Screenshot" width="200"/> After

# Install
```console
pip install ilovejpngs
```
# Use
```console
python -m ilovejpngs path/to/image.png
```
 ~ A passion project from a alpha layer grid enjoyer
