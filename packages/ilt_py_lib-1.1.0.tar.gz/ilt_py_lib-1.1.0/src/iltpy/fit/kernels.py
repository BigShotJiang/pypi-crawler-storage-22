#!/usr/bin/env python

# ILTpy : A python library for inverse Laplace transform of one dimensional and multidimensional data
# Copyright (c) 2025 Davis Thomas Daniel, Josef Granwehr and other contributors
# Licensed under the GNU Lesser General Public License v3.0 (LGPL-3.0)
#
# This file is part of ILTpy.
#
# ILTpy is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# ILTpy is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with ILTpy. If not, see <https://www.gnu.org/licenses/>.

# imports
import logging
import warnings
import numpy as np
from scipy.sparse import csr_array
from scipy.sparse import identity as spidentity
from scipy.sparse import kron as spkron
from scipy.sparse import eye as speye
from scipy.sparse import diags as spdiags
from scipy.sparse.linalg import svds
from scipy.linalg import svd
# from scipy.special import seterr

# iltpy
from iltpy.utils.scripts import _multidim_matmul, _estimate_sparsity

# warnings settings
# oldnperr = np.seterr(all="raise", under="ignore")
# oldscipyerr = seterr(all="raise", underflow="ignore", slow="ignore", loss="warn")

# logging
logger = logging.getLogger(__name__)


def iltkernel(kernel_name, kernel_func, kernel_str):
    """
    This function is helper function for creating user-defined kernels.

    Parameters
    ----------
    kernel_name : str
        The name of the kernel
    kernel_func : callable
        A function with signature ``kernel_func(input_sampling, output_sampling)`` returning the kernel value.
        This callable is used for kernel construction.
    kernel_str : str, optional
        A string representation of the kernel function, used for report generation when using iltreport.

    Returns
    -------
    type
        A generated subclass of ``IltKernel`` with the specified
        kernel properties.

    Usage
    -----
    >>> MyKernel = ilt.iltkernel(
    ...     'my_kernel',
    ...     lambda t, tau: np.exp(-t/tau)**0.5,
    ...     "lambda t,tau: np.exp(-t/tau)**0.5"
    ... )
    >>> kernel_instance = MyKernel()
    """

    class UserDefinedIltKernel(IltKernel):
        def __init__(self):
            super().__init__()
            self._name = kernel_name
            self._kernel = kernel_func
            self._kernel_str = kernel_str

    return UserDefinedIltKernel


class IltKernel:
    """
    Parent class for kernels. For defining kernels:

    class MyKernel(IltKernel):
        def __init__(self):
            self._name = 'my_kernel'
            self._kernel = lambda t,tau : kernel_func(t,tau)
            self._kernel_str = "lambda t,tau : kernel_func(t,tau)"
    """

    def __init__(self):
        self._name = "_IltKernel_"
        self._kernel = lambda t, tau: np.eye(t.size)
        self._kernel_str = "lambda t, tau: np.eye(t.size)"

    @property
    def name(self):
        return self._name

    @property
    def kernel(self):
        return self._kernel

    @property
    def kernel_str(self):
        return self._kernel_str


class Identity(IltKernel):
    def __init__(self):
        super().__init__()
        self._name = "_identity_"
        self._kernel = lambda t, tau: np.eye(t.size)
        self._kernel_str = "lambda t, tau: np.eye(t.size)"


class Exponential(IltKernel):
    def __init__(self):
        super().__init__()
        self._name = "_exponential_"
        self._kernel = lambda t, tau: np.exp(-t / tau)
        self._kernel_str = "lambda t, tau: np.exp(-t / tau)"


class Diffusion(IltKernel):
    def __init__(self):
        super().__init__()
        self._name = "_diffusion_"
        self._kernel = lambda B, D: np.exp(-B * D)
        self._kernel_str = "lambda B, D: np.exp(-B * D)"


class Gaussian(IltKernel):
    def __init__(self):
        super().__init__()
        self._name = "_gaussian_"
        self._kernel = lambda t, tau: np.exp(-(t**2) * (1 / tau) ** 2 / 2)
        self._kernel_str = "lambda t, tau: np.exp(-(t**2) * (1 / tau) ** 2 / 2)"


class RealRcKernel(IltKernel):
    def __init__(self):
        super().__init__()
        self._name = "_real_rc_kernel_"
        self._kernel = lambda f, tau: np.real((1.0 / (1 + 1j * 2 * np.pi * tau * f)))
        self._kernel_str = (
            "lambda f, tau: np.real((1.0 / (1 + 1j * 2 * np.pi * tau * f)))"
        )


class ImagRcKernel(IltKernel):
    def __init__(self):
        super().__init__()
        self._name = "_imag_rc_kernel_"
        self._kernel = lambda f, tau: np.imag((1.0 / (1 + 1j * 2 * np.pi * tau * f)))
        self._kernel_str = (
            "lambda f, tau: np.imag((1.0 / (1 + 1j * 2 * np.pi * tau * f)))"
        )


def _kernel_mat_identity(n, sparse=False):
    return spidentity(n, format="csr") if sparse else np.eye(n)


def _kernel_mat_diag(diag_vals, sparse=False):
    return spdiags(diag_vals.flatten()) if sparse else np.diag(diag_vals)


def _kernel_mat_kron(a, b, sparse=False):
    return spkron(csr_array(a), b, format="csr") if sparse else np.kron(a, b)


def _kernel_mat_eye(shape, sparse=False):
    return speye(shape) if sparse else np.eye(shape)


def _select_kernel_mode(iltdata):
    # estimate sparsity
    iltdata._K_sparsity = _estimate_sparsity(iltdata.K)
    logger.debug("Estimated sparsity of K0comp : %s", iltdata._K_sparsity)

    if iltdata._K_sparsity > 0.7 and iltdata.alt_g != 0:
        alt_g_warn = (
            "Setting alt_g equal to 0 may show better performance for this inversion."
        )
        warnings.warn(alt_g_warn)
    if iltdata._K_sparsity < 0.6 and iltdata.alt_g == 0 and iltdata._ndim > 1:
        alt_g_warn = (
            "Setting alt_g equal to 6 may show better performance for this inversion."
        )
        warnings.warn(alt_g_warn)

    # set kernel intialization mode
    if iltdata._K_sparsity < iltdata.sparse_threshold and not iltdata.force_sparse:
        logger.debug("Using dense kernel initialization.")
        iltdata._is_kernel_sparse = False
        iltdata._solver_type = "default-dense"
    else:
        logger.debug("Using sparse kernel initialization.")
        iltdata._is_kernel_sparse = True
        iltdata._solver_type = "default-sparse"


def _compress_kernel(iltdata, i):
    if iltdata.use_svds:
        # vprint1(f"    SVDS compression in dimension {i}...")
        logger.debug("SVDS compression in dimension %s...", i)
        u1, d1, v1 = svds(iltdata.K[i].T, iltdata.s[i], solver="propack")
    else:
        # vprint1(f"    SVD compression in dimension {i}...")
        logger.debug("SVD compression in dimension %s...", i)
        u1, d1, v1 = svd(iltdata.K[i].T, full_matrices=False)

    return u1, d1, v1


def _generate_W_Y(iltdata):
    # unweighted
    if iltdata.sigma is None or iltdata.alt_g not in [0, 4]:
        if iltdata.alt_g == 0:
            logger.debug("Calculating W and Y matrices...")
            iltdata.W = iltdata.K0comp.T @ iltdata.K0comp
            iltdata.Y = iltdata.K0comp.T @ iltdata._mcomp
        return

    # weighted
    logger.debug("Initializing weighting matrix for weighted inversion...")
    sigmacomp = np.reshape(iltdata._Sigma, (iltdata._ncomp, 1), order="F")
    iltdata._isigma = _kernel_mat_diag(
        (1.0 / sigmacomp).flatten(order="F"), sparse=iltdata._is_kernel_sparse
    )

    if iltdata.alt_g == 0:
        logger.debug("Calculating W and Y matrices...")
        iltdata.W = (
            iltdata.K0comp.T @ (iltdata._isigma @ iltdata._isigma) @ iltdata.K0comp
        )
        iltdata.Y = (
            iltdata.K0comp.T @ (iltdata._isigma @ iltdata._isigma) @ iltdata._mcomp
        )

    if iltdata.alt_g == 4:
        logger.debug("Found alt_g = 4, calculating mcompbar...")
        iltdata._mcompbar = iltdata._isigma @ iltdata._mcomp


def init_kernelmatrix(iltdata, verbose=0):
    """
    Initlializes kernel matrices required for inversion, requires that iltdata is intialized.

    Parameters
    ----------
    iltdata : IltData
        An instance of IltData class.
    verbose : int
        Controls verbosity
    """
    vprint1 = print if verbose > 1 else lambda *args, **kwargs: None

    # calculate K
    iltdata.K = [
        iltdata.kernel[i].kernel(iltdata.t[i], iltdata.tau[i])
        for i in range(iltdata._ndim)
    ]

    # select sparse or dense kernel initialization
    _select_kernel_mode(iltdata)

    # start initialization
    iltdata.K0comp = _kernel_mat_identity(n=1, sparse=iltdata._is_kernel_sparse)
    iltdata.U = []
    iltdata.Ut = []

    for i in range(iltdata._ndim):
        vprint1(f"    Initializing kernel matrix in dimension {i}...")
        logger.debug("Initializing kernel matrix in dimension %s...", i)
        # Adjust size if static baseline feature is used
        if iltdata.sb[i]:
            logger.debug("Adjusting the size of K since sb is True for dimension %s", i)
            iltdata.K[i] = np.vstack(
                (iltdata.K[i], np.ones((1, iltdata.K[i].T.shape[0])))
            )

        # SVD compression
        if bool(iltdata.compress[i]):
            u1, d1, v1 = _compress_kernel(iltdata, i)
            v1 = v1.T
            d1_diag = _kernel_mat_diag(
                d1[: iltdata.s[i]], sparse=iltdata._is_kernel_sparse
            )
            v1_red = v1[: iltdata.Nx[i], : iltdata.s[i]]

            iltdata.U.append(u1[: iltdata.Nt[i], : iltdata.s[i]])
            iltdata.K0comp = _kernel_mat_kron(
                d1_diag @ v1_red.T, iltdata.K0comp, sparse=iltdata._is_kernel_sparse
            )
        else:
            # In case of sparse=True,converting K to csr_array is optional, but gets minor performance improvement
            iltdata.K0comp = _kernel_mat_kron(
                iltdata.K[i].T, iltdata.K0comp, sparse=iltdata._is_kernel_sparse
            )
            iltdata.U.append(np.eye(iltdata.Nt[i]))

        iltdata.Ut.append(iltdata.U[i].T)

    Mcomp = _multidim_matmul(iltdata.data, iltdata.Ut)
    iltdata._ncomp = int(np.prod(iltdata.s))
    iltdata._mcomp = Mcomp.reshape((iltdata._ncomp, 1))
    iltdata._Is = _kernel_mat_eye(
        iltdata.K0comp.shape[0], sparse=iltdata._is_kernel_sparse
    )

    _generate_W_Y(iltdata)

    vprint1("    Kernel initialization done.")
    logger.debug("Kernel initialization done.")
