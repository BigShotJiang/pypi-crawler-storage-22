import pytest
import numpy as np
import iltpy as ilt

@pytest.mark.slow
@pytest.mark.benchmark(group="ilt_1d_altg0")
@pytest.mark.parametrize(
    "alt_g_in,maxloop_in,tau_size", [(0, 100,32),(0, 100,64),(0, 100,128),(0, 100,512)]
)
def test_workflow_1d_alt_g0_benchmark(
    alt_g_in, maxloop_in,tau_size, syn_ilt_data_1d,benchmark
):
    """Benchmarks 1D ILT inversion performance with varying tau sizes for alt_g=0."""
    syn_data_1D, t_syn, g_true = syn_ilt_data_1d
    ilt_1d = ilt.iltload(data=syn_data_1D, t=t_syn)
    tau = np.logspace(-10, 10, tau_size)
    ilt_1d.init(
        tau=tau,
        kernel=ilt.Exponential(),
        parameters={"alt_g": alt_g_in, "maxloop": maxloop_in},
    )
    bench_info = f"Data shape: {syn_data_1D.shape}, tau size: {tau_size}, K0comp shape: {ilt_1d.K0comp.shape}, n_K0comp: {np.prod(ilt_1d.K0comp.shape)}"
    print(bench_info)
    benchmark(ilt_1d.invert,verbose=0)

@pytest.mark.slow
@pytest.mark.benchmark(group="ilt_pseudo2d_altg0")
@pytest.mark.parametrize(
    "alt_g_in,maxloop_in,tau_size", [(0, 100,10),(0, 100,20),(0, 100,30),(0, 100,40),(0, 100,50)]
)
def test_workflow_pseudo2d_alt_g0_benchmark(
    alt_g_in, maxloop_in,tau_size, syn_ilt_data_pseudo_2d,benchmark
):
    """Benchmarks pseudo-2D ILT inversion performance with varying tau sizes for alt_g=0."""
    syn_data_pseudo_2D, t_syn, g_true = syn_ilt_data_pseudo_2d
    ilt_2d = ilt.iltload(data=syn_data_pseudo_2D, t=t_syn)
    ilt_2d.init(
        tau=np.logspace(-3, 6, tau_size),
        kernel=ilt.Exponential(),
        parameters={"alt_g": alt_g_in, "maxloop": maxloop_in},
    )

    bench_info = f"Data shape: {syn_data_pseudo_2D.shape}, tau size: {tau_size}, K0comp shape: {ilt_2d.K0comp.shape}, n_K0comp: {np.prod(ilt_2d.K0comp.shape)}"
    print(bench_info)

    benchmark(ilt_2d.invert,verbose=0)


@pytest.mark.slow
@pytest.mark.benchmark(group="ilt_2d_altg6")
@pytest.mark.parametrize(
    "alt_g_in,maxloop_in,tau_size", [(6, 100,10),(6, 100,20),(6, 100,30),(6, 100,40),(6, 100,50)]
)
def test_workflow_2d_alt_g6_benchmark(
    alt_g_in, maxloop_in,tau_size, syn_ilt_data_2d,benchmark
):
    """Benchmarks 2D ILT inversion performance with varying tau sizes for alt_g=6."""
    syn_data_2D, t_list, g_true = syn_ilt_data_2d
    ilt_2d = ilt.iltload(data=syn_data_2D, t=t_list)
    tau = [
        np.logspace(-4, 5, tau_size),
        np.logspace(-4, 5, tau_size),
    ]
    ilt_2d.init(
        tau,
        kernel=[ilt.Exponential(), ilt.Exponential()],
        parameters={"alt_g": alt_g_in, "maxloop": maxloop_in},
    )

    bench_info = f"Data shape: {syn_data_2D.shape}, tau size: {tau_size}, K0comp shape: {ilt_2d.K0comp.shape}, n_K0comp: {np.prod(ilt_2d.K0comp.shape)}"
    print(bench_info)

    benchmark(ilt_2d.invert,verbose=0)