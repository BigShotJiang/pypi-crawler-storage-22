
import pytest
import numpy as np
from unittest.mock import patch, Mock, MagicMock
from scipy.sparse import csc_array
from iltpy.fit.inversion import IltData


class TestIltPyFitInversion:
    @patch("iltpy.fit.inversion._validate_data_t")
    def test_iltdata_init_class(
        self,
        mock_validate_data_t,
        dummy_data_dict,
    ):
        """Tests IltData initialization sets correct attributes and calls _validate_data_t."""
        test_iltdata = IltData(dummy_data_dict)

        assert hasattr(test_iltdata, "_inception")
        assert hasattr(test_iltdata, "_dataset_type")
        assert hasattr(test_iltdata, "filepath")
        assert hasattr(test_iltdata, "data")
        assert hasattr(test_iltdata, "t")
        assert hasattr(test_iltdata, "_initialized")
        assert hasattr(test_iltdata, "_inverted")

        assert test_iltdata._dataset_type == "TXT"
        np.testing.assert_array_equal(dummy_data_dict["data"], test_iltdata.data)
        np.testing.assert_array_equal(dummy_data_dict["dims"], test_iltdata.t)

        mock_validate_data_t.return_value = None
        mock_validate_data_t.assert_called_once_with(test_iltdata)

        assert test_iltdata._initialized is False
        assert test_iltdata._inverted is False

    @patch("iltpy.fit.inversion._validate_data_t")
    @patch("iltpy.fit.inversion._init_dim_attr")
    @patch("iltpy.fit.inversion.init_fit_dict")
    @patch("iltpy.fit.inversion.set_parameters")
    @patch("iltpy.fit.inversion.init_parameters")
    @patch("iltpy.fit.inversion.init_kernelmatrix")
    @patch("iltpy.fit.inversion.init_regmatrix")
    def test_iltdata_init(
        self,
        mock_init_regmatrix,
        mock_init_kernelmatrix,
        mock_init_parameters,
        mock_set_parameters,
        mock_init_fit_dict,
        mock_init_dim_attr,
        mock_validate_data_t,
        dummy_data_dict,
        dummy_fit_dict,
    ):
        """Tests IltData.init() calls all initialization helper functions."""
        test_iltdata = IltData(dummy_data_dict)
        mock_init_fit_dict.return_value = dummy_fit_dict
        for i in dummy_fit_dict:
            setattr(test_iltdata, i, dummy_fit_dict.get(i))

        test_iltdata.tau = [np.logspace(-1, 1, 10).reshape((-1, 1))]
        test_iltdata.init()

        mock_validate_data_t.assert_called_with(
            test_iltdata
        )  # called once during __init__ and then during init
        mock_init_dim_attr.assert_called_once_with(test_iltdata)
        mock_init_fit_dict.assert_called_once_with(
            test_iltdata, None, None, None, None, None, None, False
        )
        mock_set_parameters.assert_called_once_with(test_iltdata, dummy_fit_dict)
        mock_init_parameters.assert_called_once_with(test_iltdata)
        mock_init_kernelmatrix.assert_called_once_with(test_iltdata, verbose=0)
        mock_init_regmatrix.assert_called_once_with(test_iltdata, verbose=0)

        assert hasattr(test_iltdata, "fit_dict")
        assert (
            test_iltdata.fit_dict == dummy_fit_dict
        )  # fit_dict as provided by the user, needed for reporting.
        assert hasattr(test_iltdata, "_initialization_time")
        assert test_iltdata._initialized is True
        assert test_iltdata._inverted is False

    def test_setup_inversion_default(self, dummy_data_dict):
        """Tests _setup_inversion with alt_g=0, no g_guess, and default solver."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.alt_g = 0
        test_iltdata._ndim = 1
        test_iltdata.maxloop = 100
        test_iltdata.alpha_00 = 1
        test_iltdata.Nxtot = 3
        test_iltdata.alpha_0 = np.array([0.0001])
        test_iltdata.W = csc_array([[3, 2, 0], [1, -1, 0], [0, 5, 1]], dtype=float)
        test_iltdata.Y = np.array([[2, 0], [-1, 0], [2, 0]])
        test_iltdata.g_guess = None
        test_iltdata.K0comp = csc_array([[3, 2, 0], [1, -1, 0], [0, 5, 1]], dtype=float)
        test_iltdata._K_sparsity = 0.95
        test_iltdata.force_sparse = True
        test_iltdata.sparse_threshold = 0.9

        solver = test_iltdata._setup_inversion(solver=None)

        assert hasattr(test_iltdata, "Cz")
        assert hasattr(test_iltdata, "convergence")
        assert hasattr(test_iltdata, "Gamma2")
        assert hasattr(test_iltdata, "_solver_type")
        assert hasattr(test_iltdata, "g")
        assert callable(solver) is True
        assert len(test_iltdata.Cz) == 1
        np.testing.assert_array_equal(test_iltdata.Cz, np.array([np.array([0])]))
        np.testing.assert_allclose(
            test_iltdata.Gamma2.toarray(), np.eye(test_iltdata.Nxtot) * 1 / 0.0001
        )
        assert test_iltdata._solver_type == "iltpy-default"
        assert test_iltdata.g.shape[0] == 3

    def test_setup_inversion_g_guess(self, dummy_data_dict):
        """Tests _setup_inversion with alt_g=0 when g_guess is provided."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.alt_g = 0
        test_iltdata._ndim = 1
        test_iltdata.maxloop = 100
        test_iltdata.alpha_00 = 1
        test_iltdata.Nxtot = 3
        test_iltdata.alpha_0 = np.array([0.0001])
        test_iltdata.W = csc_array([[3, 2, 0], [1, -1, 0], [0, 5, 1]], dtype=float)
        test_iltdata.Y = np.array([[2, 0], [-1, 0], [2, 0]])
        test_iltdata.g_guess = np.array([[2, 0], [-1, 0], [2, 0]])
        test_iltdata.K0comp = csc_array([[3, 2, 0], [1, -1, 0], [0, 5, 1]], dtype=float)
        test_iltdata._K_sparsity = 0.95
        test_iltdata.force_sparse = True
        test_iltdata.sparse_threshold = 0.9

        solver = test_iltdata._setup_inversion(solver=None)

        assert hasattr(test_iltdata, "Cz")
        assert hasattr(test_iltdata, "convergence")
        assert hasattr(test_iltdata, "Gamma2")
        assert hasattr(test_iltdata, "_solver_type")
        assert hasattr(test_iltdata, "g")
        assert callable(solver) is True
        assert len(test_iltdata.Cz) == 1
        np.testing.assert_array_equal(test_iltdata.Cz, np.array([np.array([0])]))
        np.testing.assert_allclose(
            test_iltdata.Gamma2.toarray(), np.eye(test_iltdata.Nxtot) * 1 / 0.0001
        )
        assert test_iltdata._solver_type == "iltpy-default"
        assert test_iltdata.g.shape[0] == 3
        np.testing.assert_array_equal(
            test_iltdata.g, np.array([[2, 0], [-1, 0], [2, 0]])
        )

    def test_setup_inversion_custom_solver(self, dummy_data_dict):
        """Tests _setup_inversion with user-defined solver and alt_g=0."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.alt_g = 0
        test_iltdata._ndim = 1
        test_iltdata.maxloop = 100
        test_iltdata.alpha_00 = 1
        test_iltdata.Nxtot = 3
        test_iltdata.alpha_0 = np.array([0.0001])
        test_iltdata.W = csc_array([[3, 2, 0], [1, -1, 0], [0, 5, 1]], dtype=float)
        test_iltdata.Y = np.array([[2, 0], [-1, 0], [2, 0]])
        test_iltdata.g_guess = None
        test_iltdata.K0comp = csc_array([[3, 2, 0], [1, -1, 0], [0, 5, 1]], dtype=float)
        test_iltdata._K_sparsity = 0.95
        test_iltdata.force_sparse = True
        test_iltdata.sparse_threshold = 0.9
        test_solver = Mock()
        test_solver.return_value = np.zeros(3)

        solver = test_iltdata._setup_inversion(solver=test_solver)

        assert hasattr(test_iltdata, "Cz")
        assert hasattr(test_iltdata, "convergence")
        assert hasattr(test_iltdata, "Gamma2")
        assert hasattr(test_iltdata, "_solver_type")
        assert hasattr(test_iltdata, "g")
        assert callable(solver) is True
        assert len(test_iltdata.Cz) == 1
        np.testing.assert_array_equal(test_iltdata.Cz, np.array([np.array([0])]))
        np.testing.assert_allclose(
            test_iltdata.Gamma2.toarray(), np.eye(test_iltdata.Nxtot) * 1 / 0.0001
        )
        assert test_iltdata._solver_type == "user-defined"
        assert test_iltdata.g.shape[0] == 3
        assert test_solver == solver
        test_solver.assert_called_once()
        args, _ = test_solver.call_args
        np.testing.assert_allclose(
            args[0].toarray(), (test_iltdata.W + test_iltdata.Gamma2).toarray()
        )
        np.testing.assert_allclose(args[1], test_iltdata.Y)
        np.testing.assert_array_equal(test_iltdata.g, np.zeros(3))

    def test_setup_inversion_custom_solver_err(self, dummy_data_dict):
        """Tests _setup_inversion raises ValueError when solver is not callable."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.alt_g = 0
        test_iltdata._ndim = 1
        test_iltdata.maxloop = 100
        test_iltdata.alpha_00 = 1
        test_iltdata.Nxtot = 3
        test_iltdata.alpha_0 = np.array([0.0001])
        test_iltdata.W = csc_array([[3, 2, 0], [1, -1, 0], [0, 5, 1]], dtype=float)
        test_iltdata.Y = np.array([[2, 0], [-1, 0], [2, 0]])
        test_iltdata.g_guess = None
        test_iltdata.K0comp = csc_array([[3, 2, 0], [1, -1, 0], [0, 5, 1]], dtype=float)
        test_iltdata._K_sparsity = 0.95
        test_iltdata.force_sparse = True
        test_iltdata.sparse_threshold = 0.9
        test_solver = "not callable"

        with pytest.raises(ValueError):
            _ = test_iltdata._setup_inversion(solver=test_solver)

    @pytest.mark.parametrize("test_alt_g", [2, 4, 6])
    @patch("iltpy.fit.inversion.IltSolver")
    def test_setup_inversion_alt_g_solver(
        self, mock_IltSolver, test_alt_g, dummy_data_dict
    ):
        """Tests _setup_inversion uses alt_g_solve when alt_g is 2, 4, or 6."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.alt_g = test_alt_g
        test_iltdata._ndim = 1
        test_iltdata.maxloop = 100
        test_iltdata.alpha_00 = 1
        test_iltdata.Nxtot = 3
        test_iltdata.alpha_0 = np.array([0.0001])
        test_iltdata.W = csc_array([[3, 2, 0], [1, -1, 0], [0, 5, 1]], dtype=float)
        test_iltdata.Y = np.array([[2, 0], [-1, 0], [2, 0]])
        test_iltdata.g_guess = None
        test_iltdata.K0comp = csc_array([[3, 2, 0], [1, -1, 0], [0, 5, 1]], dtype=float)
        test_iltdata._K_sparsity = 0.95
        test_iltdata.force_sparse = True
        test_iltdata.sparse_threshold = 0.9

        test_solver = Mock()
        test_solver.return_value = np.zeros(3)

        mock_IltSolver_instance = mock_IltSolver.return_value
        mock_IltSolver_instance.alt_g_solve.return_value = np.ones(3)

        solver = test_iltdata._setup_inversion(solver=test_solver)

        assert hasattr(test_iltdata, "Cz")
        assert hasattr(test_iltdata, "convergence")
        assert hasattr(test_iltdata, "Gamma2")
        assert hasattr(test_iltdata, "_solver_type")
        assert hasattr(test_iltdata, "g")
        assert callable(solver) is True
        assert len(test_iltdata.Cz) == 1
        np.testing.assert_array_equal(test_iltdata.Cz, np.array([np.array([0])]))
        np.testing.assert_allclose(
            test_iltdata.Gamma2.toarray(), np.eye(test_iltdata.Nxtot) * 1 / 0.0001
        )
        assert test_iltdata._solver_type == f"alt_g_{test_alt_g}"
        mock_IltSolver_instance.alt_g_solve.assert_called_once()
        test_solver.assert_not_called()  # should not be called if alt_g!=0
        assert test_iltdata.g.shape[0] == 3
        np.testing.assert_array_equal(test_iltdata.g, np.ones(3))

    @pytest.mark.parametrize("test_alt_g", [2, 4, 6])
    @patch("iltpy.fit.inversion.IltSolver")
    def test_setup_inversion_alt_g_solver_g_guess(
        self, mock_IltSolver, test_alt_g, dummy_data_dict
    ):
        """Tests _setup_inversion uses g_guess and skips alt_g_solve when g_guess is provided."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.alt_g = test_alt_g
        test_iltdata._ndim = 1
        test_iltdata.maxloop = 100
        test_iltdata.alpha_00 = 1
        test_iltdata.Nxtot = 3
        test_iltdata.alpha_0 = np.array([0.0001])
        test_iltdata.W = csc_array([[3, 2, 0], [1, -1, 0], [0, 5, 1]], dtype=float)
        test_iltdata.Y = np.array([[2, 0], [-1, 0], [2, 0]])
        test_iltdata.g_guess = np.zeros(3)
        test_iltdata.K0comp = csc_array([[3, 2, 0], [1, -1, 0], [0, 5, 1]], dtype=float)
        test_iltdata._K_sparsity = 0.95
        test_iltdata.force_sparse = True
        test_iltdata.sparse_threshold = 0.9

        test_solver = Mock()
        test_solver.return_value = np.zeros(3)

        mock_IltSolver_instance = mock_IltSolver.return_value
        mock_IltSolver_instance.alt_g_solve.return_value = np.ones(3)

        solver = test_iltdata._setup_inversion(solver=test_solver)

        assert hasattr(test_iltdata, "Cz")
        assert hasattr(test_iltdata, "convergence")
        assert hasattr(test_iltdata, "Gamma2")
        assert hasattr(test_iltdata, "_solver_type")
        assert hasattr(test_iltdata, "g")
        assert callable(solver) is True
        assert len(test_iltdata.Cz) == 1
        np.testing.assert_array_equal(test_iltdata.Cz, np.array([np.array([0])]))
        np.testing.assert_allclose(
            test_iltdata.Gamma2.toarray(), np.eye(test_iltdata.Nxtot) * 1 / 0.0001
        )
        assert test_iltdata._solver_type == f"alt_g_{test_alt_g}"
        mock_IltSolver_instance.alt_g_solve.assert_not_called()
        test_solver.assert_not_called()  # should not be called if alt_g!=0
        assert test_iltdata.g.shape[0] == 3
        np.testing.assert_array_equal(test_iltdata.g, np.zeros(3))

    def test_setup_inversion_custom_solver_g_guess(self, dummy_data_dict):
        """Tests _setup_inversion uses g_guess and skips solver call when g_guess is provided."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.alt_g = 0
        test_iltdata._ndim = 1
        test_iltdata.maxloop = 100
        test_iltdata.alpha_00 = 1
        test_iltdata.Nxtot = 3
        test_iltdata.alpha_0 = np.array([0.0001])
        test_iltdata.W = csc_array([[3, 2, 0], [1, -1, 0], [0, 5, 1]], dtype=float)
        test_iltdata.Y = np.array([[2, 0], [-1, 0], [2, 0]])
        test_iltdata.g_guess = np.ones(3)
        test_iltdata.K0comp = csc_array([[3, 2, 0], [1, -1, 0], [0, 5, 1]], dtype=float)
        test_iltdata._K_sparsity = 0.95
        test_iltdata.force_sparse = True
        test_iltdata.sparse_threshold = 0.9
        test_solver = Mock()
        test_solver.return_value = np.zeros(3)

        solver = test_iltdata._setup_inversion(solver=test_solver)

        assert hasattr(test_iltdata, "Cz")
        assert hasattr(test_iltdata, "convergence")
        assert hasattr(test_iltdata, "Gamma2")
        assert hasattr(test_iltdata, "_solver_type")
        assert hasattr(test_iltdata, "g")
        assert callable(solver) is True
        assert len(test_iltdata.Cz) == 1
        np.testing.assert_array_equal(test_iltdata.Cz, np.array([np.array([0])]))
        np.testing.assert_allclose(
            test_iltdata.Gamma2.toarray(), np.eye(test_iltdata.Nxtot) * 1 / 0.0001
        )
        assert test_iltdata._solver_type == "user-defined"
        assert test_iltdata.g.shape[0] == 3
        assert test_solver == solver
        test_solver.assert_not_called()
        np.testing.assert_array_equal(test_iltdata.g, np.ones(3))

    def test_invert_verbose_type_error(self, dummy_data_dict):
        """Test that invert raises ValueError when verbose is not int."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = True

        with pytest.raises(ValueError, match="`verbose` must be of type int"):
            test_iltdata.invert(verbose="not_an_int")

    def test_invert_not_initialized_error(self, dummy_data_dict):
        """Test that invert raises RuntimeError when not initialized."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False

        with pytest.raises(
            RuntimeError, match="invert\\(\\) called on an uninitialized IltData object"
        ):
            test_iltdata.invert()

    @patch("iltpy.fit.inversion.tqdm")
    @patch("iltpy.fit.inversion.up_reg")
    @patch("iltpy.fit.inversion.zc_reg")
    @patch("iltpy.fit.inversion.nn_reg")
    def test_invert_basic_iteration(
        self, mock_nn_reg, mock_zc_reg, mock_up_reg,mock_tqdm, dummy_data_dict
    ):
        """Test basic inversion iteration with mocked solver."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = True
        test_iltdata.alt_g = 0
        test_iltdata._ndim = 1
        test_iltdata.maxloop = 3
        test_iltdata.alpha_00 = 1
        test_iltdata.Nxtot = 3
        test_iltdata.alpha_0 = np.array([0.0001])
        test_iltdata.W = csc_array(np.eye(3), dtype=float)
        test_iltdata.Y = np.ones(3)
        test_iltdata.g_guess = None
        test_iltdata.K0comp = csc_array(np.eye(3), dtype=float)
        test_iltdata._K_sparsity = 0.95
        test_iltdata.force_sparse = True
        test_iltdata.sparse_threshold = 0.9
        test_iltdata.nn = False
        test_iltdata.store_g = False
        test_iltdata.store_gamma = False
        test_iltdata.conv_limit = 1e-10
        test_iltdata.reg_down = 100
        test_iltdata.Vbc = csc_array(np.zeros((3, 3)), dtype=float)
        test_iltdata.K = [np.eye(3)]
        test_iltdata.data = np.ones(3)
        test_iltdata.tau = np.logspace(-1,1,3)
        test_iltdata.t = np.linspace(1,4)

        # mock regularization to return sparse matrices
        mock_up_reg.return_value = csc_array(np.zeros((3, 3)), dtype=float)
        mock_zc_reg.return_value = csc_array(np.zeros((3, 3)), dtype=float)

        pbar_mock = MagicMock()
        pbar_mock.__iter__.return_value = iter(range(test_iltdata.maxloop))
        mock_tqdm.return_value = pbar_mock

        # mock solver, with slightly changing value of g
        test_solver = Mock()
        test_solver.side_effect = [
                    np.ones(3), 
                    np.ones(3) * 0.9, 
                    np.ones(3) * 0.8, 
                    np.ones(3) * 0.7
                ]
        
        test_iltdata.invert(solver=test_solver, verbose=0)

        # verify solver was called maxloop times +1
        assert test_solver.call_count == test_iltdata.maxloop + 1  # +1 for _setup_inversion
        assert hasattr(test_iltdata, "convergence")
        assert len([c for c in test_iltdata.convergence if c is not None]) == test_iltdata.maxloop

    @patch("iltpy.fit.inversion.tqdm")
    @patch("iltpy.fit.inversion.up_reg")
    @patch("iltpy.fit.inversion.zc_reg")
    def test_invert_convergence_limit_reached(
        self, mock_zc_reg, mock_up_reg, mock_tqdm, dummy_data_dict
    ):
        """Test that iteration stops early when convergence limit is reached."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = True
        test_iltdata.alt_g = 0
        test_iltdata._ndim = 1
        test_iltdata.maxloop = 10
        test_iltdata.alpha_00 = 1
        test_iltdata.Nxtot = 3
        test_iltdata.alpha_0 = np.array([0.0001])
        test_iltdata.W = csc_array(np.eye(3), dtype=float)
        test_iltdata.Y = np.ones(3)
        test_iltdata.g_guess = None
        test_iltdata.K0comp = csc_array(np.eye(3), dtype=float)
        test_iltdata._K_sparsity = 0.95
        test_iltdata.force_sparse = True
        test_iltdata.sparse_threshold = 0.9
        test_iltdata.nn = False
        test_iltdata.store_g = False
        test_iltdata.store_gamma = False
        test_iltdata.conv_limit = 0.1
        test_iltdata.reg_down = 100
        test_iltdata.Vbc = csc_array(np.zeros((3, 3)), dtype=float)
        test_iltdata.K = [np.eye(3)]
        test_iltdata.data = np.ones(3)
        test_iltdata.tau = np.logspace(-1,1,3)
        test_iltdata.t = np.linspace(1,4)

        mock_up_reg.return_value = csc_array(np.zeros((3, 3)), dtype=float)
        mock_zc_reg.return_value = csc_array(np.zeros((3, 3)), dtype=float)

        pbar_mock = MagicMock()
        pbar_mock.__iter__.return_value = iter(range(test_iltdata.maxloop))
        mock_tqdm.return_value = pbar_mock

        # Mock solver
        test_solver = Mock()
        test_solver.side_effect = [
                    np.ones(3), 
                    np.ones(3) * 1.1, 
                    np.ones(3) * 1.2, 
                    np.ones(3) * 1.3
                ]
        
        test_iltdata.invert(solver=test_solver, verbose=0)

        # Should stop before maxloop due to convergence
        assert test_solver.call_count < test_iltdata.maxloop + 1

    @patch("iltpy.fit.inversion.tqdm")
    @patch("iltpy.fit.inversion.up_reg")
    @patch("iltpy.fit.inversion.zc_reg")
    def test_invert_store_g_true(
        self, mock_zc_reg, mock_up_reg, mock_tqdm, dummy_data_dict
    ):
        """Test that g_list is populated when store_g=True."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = True
        test_iltdata.alt_g = 0
        test_iltdata._ndim = 1
        test_iltdata.maxloop = 2
        test_iltdata.alpha_00 = 1
        test_iltdata.Nxtot = 3
        test_iltdata.alpha_0 = np.array([0.0001])
        test_iltdata.W = csc_array(np.eye(3), dtype=float)
        test_iltdata.Y = np.ones(3)
        test_iltdata.g_guess = None
        test_iltdata.K0comp = csc_array(np.eye(3), dtype=float)
        test_iltdata._K_sparsity = 0.95
        test_iltdata.force_sparse = True
        test_iltdata.sparse_threshold = 0.9
        test_iltdata.nn = False
        test_iltdata.store_g = True
        test_iltdata.store_gamma = False
        test_iltdata.conv_limit = 1e-6
        test_iltdata.reg_down = 100
        test_iltdata.Vbc = csc_array(np.zeros((3, 3)), dtype=float)
        test_iltdata.Nx = [3]
        test_iltdata.K = [np.eye(3)]
        test_iltdata.data = np.ones(3)
        test_iltdata.tau = np.logspace(-1,1,3)
        test_iltdata.t = np.linspace(1,4)

        mock_up_reg.return_value = csc_array(np.zeros((3, 3)), dtype=float)
        mock_zc_reg.return_value = csc_array(np.zeros((3, 3)), dtype=float)

        pbar_mock = MagicMock()
        pbar_mock.__iter__.return_value = iter(range(test_iltdata.maxloop))
        mock_tqdm.return_value = pbar_mock

        # Mock solver
        test_solver = Mock()
        test_solver.side_effect = [
                    np.ones(3), 
                    np.ones(3) * 0.9, 
                    np.ones(3) * 0.8, 
                    np.ones(3) * 0.7
                ]

        test_iltdata.invert(solver=test_solver, verbose=0)

        assert hasattr(test_iltdata, "g_list")
        assert len(test_iltdata.g_list) == test_iltdata.maxloop +1

    @patch("iltpy.fit.inversion.tqdm")
    @patch("iltpy.fit.inversion.up_reg")
    @patch("iltpy.fit.inversion.zc_reg")
    def test_invert_store_gamma_true(
        self, mock_zc_reg, mock_up_reg, mock_tqdm, dummy_data_dict
    ):
        """Test that gamma_list is populated when store_gamma=True."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = True
        test_iltdata.alt_g = 0
        test_iltdata._ndim = 1
        test_iltdata.maxloop = 2
        test_iltdata.alpha_00 = 1
        test_iltdata.Nxtot = 3
        test_iltdata.alpha_0 = np.array([0.0001])
        test_iltdata.W = csc_array(np.eye(3), dtype=float)
        test_iltdata.Y = np.ones(3)
        test_iltdata.g_guess = None
        test_iltdata.K0comp = csc_array(np.eye(3), dtype=float)
        test_iltdata._K_sparsity = 0.95
        test_iltdata.force_sparse = True
        test_iltdata.sparse_threshold = 0.9
        test_iltdata.nn = False
        test_iltdata.store_g = False
        test_iltdata.store_gamma = True
        test_iltdata.conv_limit = 1e-10
        test_iltdata.reg_down = 100
        test_iltdata.Vbc = csc_array(np.zeros((3, 3)), dtype=float)
        test_iltdata.K = [np.eye(3)]
        test_iltdata.data = np.ones(3)
        test_iltdata.tau = np.logspace(-1,1,3)
        test_iltdata.t = np.linspace(1,4)

        mock_up_reg.return_value = csc_array(np.zeros((3, 3)), dtype=float)
        mock_zc_reg.return_value = csc_array(np.zeros((3, 3)), dtype=float)

        pbar_mock = MagicMock()
        pbar_mock.__iter__.return_value = iter(range(test_iltdata.maxloop))
        mock_tqdm.return_value = pbar_mock

        # Mock solver
        test_solver = Mock()
        test_solver.side_effect = [
                    np.ones(3), 
                    np.ones(3) * 0.9, 
                    np.ones(3) * 0.8, 
                    np.ones(3) * 0.7
                ]

        test_iltdata._setup_inversion(solver=test_solver)
        test_iltdata.invert(solver=test_solver, verbose=0)

        assert hasattr(test_iltdata, "gamma_list")
        assert len(test_iltdata.gamma_list) == test_iltdata.maxloop + 1

    @patch("iltpy.fit.inversion.tqdm")
    @patch("iltpy.fit.inversion.up_reg")
    @patch("iltpy.fit.inversion.zc_reg")
    @patch("iltpy.fit.inversion.nn_reg")
    def test_invert_nn_true(
        self, mock_nn_reg, mock_zc_reg, mock_up_reg, mock_tqdm, dummy_data_dict
    ):
        """Test that nn_reg is called when nn=True."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = True
        test_iltdata.alt_g = 0
        test_iltdata._ndim = 1
        test_iltdata.maxloop = 1
        test_iltdata.alpha_00 = 1
        test_iltdata.Nxtot = 3
        test_iltdata.alpha_0 = np.array([0.0001])
        test_iltdata.W = csc_array(np.eye(3), dtype=float)
        test_iltdata.Y = np.ones(3)
        test_iltdata.g_guess = None
        test_iltdata.K0comp = csc_array(np.eye(3), dtype=float)
        test_iltdata._K_sparsity = 0.95
        test_iltdata.force_sparse = True
        test_iltdata.sparse_threshold = 0.9
        test_iltdata.nn = True
        test_iltdata.store_g = False
        test_iltdata.store_gamma = False
        test_iltdata.conv_limit = 1e-10
        test_iltdata.reg_down = 100
        test_iltdata.Vbc = csc_array(np.zeros((3, 3)), dtype=float)
        test_iltdata.K = [np.eye(3)]
        test_iltdata.data = np.ones(3)
        test_iltdata.tau = np.logspace(-1,1,3)
        test_iltdata.t = np.linspace(1,4)

        mock_up_reg.return_value = csc_array(np.zeros((3, 3)), dtype=float)
        mock_zc_reg.return_value = csc_array(np.zeros((3, 3)), dtype=float)
        mock_nn_reg.return_value = csc_array(np.zeros((3, 3)), dtype=float)

        pbar_mock = MagicMock()
        pbar_mock.__iter__.return_value = iter(range(test_iltdata.maxloop))
        mock_tqdm.return_value = pbar_mock

        # Mock solver
        test_solver = Mock()
        test_solver.side_effect = [
                    np.ones(3), 
                    np.ones(3) * 0.9, 
                    np.ones(3) * 0.8, 
                    np.ones(3) * 0.7
                ]

        test_iltdata._setup_inversion(solver=test_solver)
        test_iltdata.invert(solver=test_solver, verbose=0)

        mock_nn_reg.assert_called()
        mock_nn_reg.call_count == test_iltdata.maxloop

    @patch("iltpy.fit.inversion.tqdm")
    @patch("iltpy.fit.inversion.up_reg")
    @patch("iltpy.fit.inversion.zc_reg")
    @patch("iltpy.fit.inversion.nn_reg")
    def test_invert_nn_false(
        self, mock_nn_reg, mock_zc_reg, mock_up_reg, mock_tqdm, dummy_data_dict
    ):
        """Test that nn_reg is NOT called when nn=False."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = True
        test_iltdata.alt_g = 0
        test_iltdata._ndim = 1
        test_iltdata.maxloop = 1
        test_iltdata.alpha_00 = 1
        test_iltdata.Nxtot = 3
        test_iltdata.alpha_0 = np.array([0.0001])
        test_iltdata.W = csc_array(np.eye(3), dtype=float)
        test_iltdata.Y = np.ones(3)
        test_iltdata.g_guess = None
        test_iltdata.K0comp = csc_array(np.eye(3), dtype=float)
        test_iltdata._K_sparsity = 0.95
        test_iltdata.force_sparse = True
        test_iltdata.sparse_threshold = 0.9
        test_iltdata.nn = False
        test_iltdata.store_g = False
        test_iltdata.store_gamma = False
        test_iltdata.conv_limit = 1e-10
        test_iltdata.reg_down = 100
        test_iltdata.Vbc = csc_array(np.zeros((3, 3)), dtype=float)
        test_iltdata.K = [np.eye(3)]
        test_iltdata.data = np.ones(3)
        test_iltdata.tau = np.logspace(-1,1,3)
        test_iltdata.t = np.linspace(1,4)

        mock_up_reg.return_value = csc_array(np.zeros((3, 3)), dtype=float)
        mock_zc_reg.return_value = csc_array(np.zeros((3, 3)), dtype=float)

        pbar_mock = MagicMock()
        pbar_mock.__iter__.return_value = iter(range(test_iltdata.maxloop))
        mock_tqdm.return_value = pbar_mock

        # Mock solver
        test_solver = Mock()
        test_solver.side_effect = [
                    np.ones(3), 
                    np.ones(3) * 0.9, 
                    np.ones(3) * 0.8, 
                    np.ones(3) * 0.7
                ]

        test_iltdata._setup_inversion(solver=test_solver)
        test_iltdata.invert(solver=test_solver, verbose=0)

        mock_nn_reg.assert_not_called()

    @patch("iltpy.fit.inversion.tqdm")
    @patch("iltpy.fit.inversion.up_reg")
    @patch("iltpy.fit.inversion.zc_reg")
    def test_invert_reg_down_logic(
        self, mock_zc_reg, mock_up_reg, mock_tqdm, dummy_data_dict
    ):
        """Test that reg_down update ratio is applied when iteration > reg_down."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = True
        test_iltdata.alt_g = 0
        test_iltdata._ndim = 1
        test_iltdata.maxloop = 3
        test_iltdata.alpha_00 = 1
        test_iltdata.Nxtot = 3
        test_iltdata.alpha_0 = np.array([0.0001])
        test_iltdata.W = csc_array(np.eye(3), dtype=float)
        test_iltdata.Y = np.ones(3)
        test_iltdata.g_guess = None
        test_iltdata.K0comp = csc_array(np.eye(3), dtype=float)
        test_iltdata._K_sparsity = 0.95
        test_iltdata.force_sparse = True
        test_iltdata.sparse_threshold = 0.9
        test_iltdata.nn = False
        test_iltdata.store_g = False
        test_iltdata.store_gamma = False
        test_iltdata.conv_limit = 1e-10
        test_iltdata.reg_down = 1  # Set low to trigger update
        test_iltdata.reg_upd = 0.5
        test_iltdata.reg_downrate = 0.1
        test_iltdata.reg_updmin = 0.1
        test_iltdata.Vbc = csc_array(np.zeros((3, 3)), dtype=float)
        test_iltdata.K = [np.eye(3)]
        test_iltdata.data = np.ones(3)
        test_iltdata.tau = np.logspace(-1,1,3)
        test_iltdata.t = np.linspace(1,4)

        mock_up_reg.return_value = csc_array(np.zeros((3, 3)), dtype=float)
        mock_zc_reg.return_value = csc_array(np.zeros((3, 3)), dtype=float)

        pbar_mock = MagicMock()
        pbar_mock.__iter__.return_value = iter(range(test_iltdata.maxloop))
        mock_tqdm.return_value = pbar_mock

        # Mock solver
        test_solver = Mock()
        test_solver.side_effect = [
                    np.ones(3), 
                    np.ones(3) * 0.9, 
                    np.ones(3) * 0.8, 
                    np.ones(3) * 0.7
                ]

        test_iltdata.invert(solver=test_solver, verbose=0)

        # Test passes if no exception is raised during reg_down logic

    @pytest.mark.parametrize("test_alt_g", [2, 4, 6])
    @patch("iltpy.fit.inversion.IltSolver")
    @patch("iltpy.fit.inversion.tqdm")
    @patch("iltpy.fit.inversion.up_reg")
    @patch("iltpy.fit.inversion.zc_reg")
    def test_invert_alt_g_not_zero(
        self, mock_zc_reg, mock_up_reg, mock_tqdm, mock_IltSolver, test_alt_g, dummy_data_dict
    ):
        """Test that alt_g_solver.alt_g_solve() is used when alt_g != 0."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = True
        test_iltdata.alt_g = test_alt_g
        test_iltdata._ndim = 1
        test_iltdata.maxloop = 1
        test_iltdata.alpha_00 = 1
        test_iltdata.Nxtot = 3
        test_iltdata.alpha_0 = np.array([0.0001])
        test_iltdata.W = csc_array(np.eye(3), dtype=float)
        test_iltdata.Y = np.ones(3)
        test_iltdata.g_guess = None
        test_iltdata.K0comp = csc_array(np.eye(3), dtype=float)
        test_iltdata._K_sparsity = 0.95
        test_iltdata.force_sparse = True
        test_iltdata.sparse_threshold = 0.9
        test_iltdata.nn = False
        test_iltdata.store_g = False
        test_iltdata.store_gamma = False
        test_iltdata.conv_limit = 1e-10
        test_iltdata.reg_down = 100
        test_iltdata.Vbc = csc_array(np.zeros((3, 3)), dtype=float)
        test_iltdata.K = [np.eye(3)]
        test_iltdata.data = np.ones(3)
        test_iltdata.tau = np.logspace(-1,1,3)
        test_iltdata.t = np.linspace(1,4)

        mock_up_reg.return_value = csc_array(np.zeros((3, 3)), dtype=float)
        mock_zc_reg.return_value = csc_array(np.zeros((3, 3)), dtype=float)

        pbar_mock = MagicMock()
        pbar_mock.__iter__.return_value = iter(range(test_iltdata.maxloop))
        mock_tqdm.return_value = pbar_mock

        mock_solver_instance = mock_IltSolver.return_value
        mock_solver_instance.alt_g_solve.return_value = np.ones(3)

        test_iltdata.invert(verbose=0)

        # alt_g_solve should be called for each iteration + initial setup
        assert mock_solver_instance.alt_g_solve.call_count >= 1

    def test_post_inversion_1d(self, dummy_data_dict):
        """Test _post_inversion for 1D data."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 1
        test_iltdata.g = np.array([1.0, 2.0, 3.0])
        test_iltdata.Nx = [3]
        test_iltdata.K = [np.array([[0.5, 0.5, 0.5], [0.3, 0.3, 0.3], [0.2, 0.2, 0.2]])]
        test_iltdata.data = np.array([3.0, 1.8, 1.2])

        start_time = 0.0
        iteration_number = 5

        test_iltdata._post_inversion(start_time, iteration_number)

        assert hasattr(test_iltdata, "inversion_time")
        assert hasattr(test_iltdata, "g_old")
        assert hasattr(test_iltdata, "fit")
        assert hasattr(test_iltdata, "residuals")
        assert test_iltdata._inverted is True
        assert test_iltdata.g.shape == (3,)

    def test_post_inversion_2d(self, dummy_data_dict):
        """Test _post_inversion for 2D data - g should be reshaped."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 2
        test_iltdata.g = np.arange(9, dtype=np.float64)
        test_iltdata.Nx = [3, 3]
        test_iltdata.K = [
            np.array([[0.5, 0.5, 0.5], [0.3, 0.3, 0.3], [0.2, 0.2, 0.2]]),
            np.array([[0.5, 0.5, 0.5], [0.3, 0.3, 0.3], [0.2, 0.2, 0.2]]),
        ]
        test_iltdata.data = np.ones((3, 3))

        start_time = 0.0
        iteration_number = 5

        test_iltdata._post_inversion(start_time, iteration_number)

        assert test_iltdata.g.shape == (3, 3)

    def test_post_inversion_residuals(self, dummy_data_dict):
        """Test that residuals = fit - data."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 1
        test_iltdata.g = np.array([1.0, 2.0, 3.0])
        test_iltdata.Nx = [3]
        test_iltdata.K = [np.eye(3)]
        test_iltdata.data = np.array([0.9, 2.1, 2.9])

        start_time = 0.0
        iteration_number = 5

        test_iltdata._post_inversion(start_time, iteration_number)

        expected_residuals = test_iltdata.fit - test_iltdata.data
        np.testing.assert_allclose(test_iltdata.residuals, expected_residuals)

    def test_post_inversion_attributes(self, dummy_data_dict):
        """Test that inversion_time, g_old, _inverted are set correctly."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 1
        test_iltdata.g = np.array([1.0, 2.0, 3.0])
        test_iltdata.Nx = [3]
        test_iltdata.K = [np.eye(3)]
        test_iltdata.data = np.ones(3)

        start_time = 0.0
        iteration_number = 5

        test_iltdata._post_inversion(start_time, iteration_number)

        assert isinstance(test_iltdata.inversion_time, float)
        np.testing.assert_array_equal(test_iltdata.g_old, np.array([1.0, 2.0, 3.0]))
        assert test_iltdata._inverted is True

    def test_iltstats_not_inverted_error(self, dummy_data_dict):
        """Test that iltstats raises RuntimeError when not inverted."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._inverted = False

        with pytest.raises(
            RuntimeError, match="IltData must be inverted at least once"
        ):
            test_iltdata.iltstats()

    def test_iltstats_n_less_than_2(self, dummy_data_dict):
        """Test that iltstats raises ValueError when n < 2."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._inverted = True

        with pytest.raises(ValueError, match="Number of samples,n, must be >=2"):
            test_iltdata.iltstats(n=1)

    @patch("iltpy.fit.inversion.compute_stats")
    @patch("iltpy.fit.inversion.delayed")
    @patch("iltpy.fit.inversion.Parallel")
    def test_iltstats_random_seed(
        self, mock_Parallel, mock_delayed, mock_compute_stats, dummy_data_dict
    ):
        """Tests iltstats produces reproducible noise samples with same random_seed."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._inverted = True
        test_iltdata.fit = np.ones(3)
        test_iltdata.tau = [np.logspace(-1, 1, 3)]
        test_iltdata.kernel = [Mock()]
        test_iltdata._user_parameters = {}

        mock_executor = MagicMock()
        mock_executor.return_value = [
            {"g": np.ones(3), "fit": np.ones(3), "residuals": np.zeros(3)}
            for _ in range(2)
        ]
        mock_Parallel.return_value = mock_executor
        mock_delayed.side_effect = lambda x: x

        # run 1
        test_iltdata.iltstats(n=2, random_seed=42, verbose=0)
        noise1 = test_iltdata.statistics["noise_samples"]

        # run 2
        test_iltdata.iltstats(n=2, random_seed=42, verbose=0)
        noise2 = test_iltdata.statistics["noise_samples"]

        for n1, n2 in zip(noise1, noise2):
            np.testing.assert_array_equal(n1, n2)
        
        mock_compute_stats.assert_called()

    @patch("iltpy.fit.inversion.compute_stats")
    @patch("iltpy.fit.inversion.delayed")
    @patch("iltpy.fit.inversion.Parallel")
    def test_iltstats_output_structure(
        self, mock_Parallel, mock_delayed, mock_compute_stats, dummy_data_dict
    ):
        """Test that statistics dict has correct keys."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._inverted = True
        test_iltdata.fit = np.ones(3)
        test_iltdata.tau = [np.logspace(-1, 1, 3)]
        test_iltdata.kernel = [Mock()]
        test_iltdata._user_parameters = {}

        mock_executor = MagicMock()
        mock_executor.return_value = [
            {"g": np.ones(3), "fit": np.ones(3), "residuals": np.zeros(3)}
            for _ in range(2)
        ]
        mock_Parallel.return_value = mock_executor
        mock_delayed.side_effect = lambda x: x

        test_iltdata.iltstats(n=2, verbose=0)

        assert hasattr(test_iltdata,"statistics")
        expected_keys = ["g_list", "fit_list", "residuals_list", "noise_samples", "data_samples"]
        for key in expected_keys:
            assert key in test_iltdata.statistics

    @patch("iltpy.fit.inversion.compute_stats")
    @patch("iltpy.fit.inversion.delayed")
    @patch("iltpy.fit.inversion.Parallel")
    def test_iltstats_compute_stats_called(
        self,mock_Parallel, mock_delayed, mock_compute_stats, dummy_data_dict
    ):
        """Test that compute_stats is called after iltstats."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._inverted = True
        test_iltdata.fit = np.ones(3)
        test_iltdata.tau = [np.logspace(-1, 1, 3)]
        test_iltdata.kernel = [Mock()]
        test_iltdata._user_parameters = {}

        mock_executor = MagicMock()
        mock_executor.return_value = [
            {"g": np.ones(3), "fit": np.ones(3), "residuals": np.zeros(3)}
            for _ in range(2)
        ]
        mock_Parallel.return_value = mock_executor
        mock_delayed.side_effect = lambda x: x

        test_iltdata.iltstats(n=2, verbose=0)

        mock_compute_stats.assert_called_once_with(test_iltdata)

    @patch("iltpy.fit.inversion.iltreport")
    def test_report_calls_iltreport(self, mock_iltreport, dummy_data_dict):
        """Test that report calls iltreport with correct args."""
        test_iltdata = IltData(dummy_data_dict)

        test_iltdata.report()

        mock_iltreport.assert_called_once()

    @patch("iltpy.fit.inversion.iltreport")
    def test_report_with_filepath(self, mock_iltreport, dummy_data_dict,tmp_path):
        """Test that filepath is passed to iltreport."""
        test_iltdata = IltData(dummy_data_dict)

        test_iltdata.report(filepath=str(tmp_path))

        mock_iltreport.assert_called_once()
        call_kwargs = mock_iltreport.call_args[1]
        assert call_kwargs["filepath"] == str(tmp_path)

    @patch("iltpy.fit.inversion.iltreport")
    def test_report_with_save_arrays(self, mock_iltreport, dummy_data_dict):
        """Test that save_arrays is passed to iltreport."""
        test_iltdata = IltData(dummy_data_dict)

        test_iltdata.report(save_arrays=True)

        mock_iltreport.assert_called_once()
        call_kwargs = mock_iltreport.call_args[1]
        assert call_kwargs["save_arrays"] is True

    @patch("iltpy.fit.inversion.iltreport")
    def test_report_with_level(self, mock_iltreport, dummy_data_dict):
        """Test that level is passed to iltreport."""
        test_iltdata = IltData(dummy_data_dict)

        test_iltdata.report(level=2)

        mock_iltreport.assert_called_once()
        call_kwargs = mock_iltreport.call_args[1]
        assert call_kwargs["level"] == 2

    @patch("iltpy.fit.inversion.iltreport")
    def test_report_with_parameters_to_file(self, mock_iltreport, dummy_data_dict):
        """Test that parameters_to_file is passed to iltreport."""
        test_iltdata = IltData(dummy_data_dict)

        test_iltdata.report(parameters_to_file=True)

        mock_iltreport.assert_called_once()
        call_kwargs = mock_iltreport.call_args[1]
        assert call_kwargs["parameters_to_file"] is True

    def test_iltsolver_init_basic(self, dummy_data_dict):
        """Test basic IltSolver initialization."""
        from iltpy.fit.inversion import IltSolver

        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.alt_g = 2
        test_iltdata.K0comp = np.eye(3)
        test_iltdata._K_sparsity = 0.5
        test_iltdata.force_sparse = False
        test_iltdata.sparse_threshold = 0.9

        solver = IltSolver(test_iltdata)

        assert solver.alt_g == 2
        assert solver._K_sparsity == 0.5
        assert solver.force_sparse is False
        assert solver.sparse_threshold == 0.9

    def test_iltsolver_init_k0comp_conversion(self, dummy_data_dict):
        """Test that K0comp is converted to dense when alt_g in [2,4,6]."""
        from iltpy.fit.inversion import IltSolver

        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.alt_g = 2
        test_iltdata.K0comp = csc_array(np.eye(3), dtype=float)
        test_iltdata._K_sparsity = 0.5
        test_iltdata.force_sparse = False
        test_iltdata.sparse_threshold = 0.9

        IltSolver(test_iltdata)

        # K0comp should be converted to dense array
        assert isinstance(test_iltdata.K0comp, np.ndarray)

    def test_get_default_solver_dense(self, dummy_data_dict):
        """Test that dense solver is returned for low sparsity."""
        from iltpy.fit.inversion import IltSolver

        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.alt_g = 0
        test_iltdata.K0comp = np.eye(3)
        test_iltdata._K_sparsity = 0.3  # Low sparsity
        test_iltdata.force_sparse = False
        test_iltdata.sparse_threshold = 0.9

        solver = IltSolver(test_iltdata)
        result = solver.get_default_solver()

        assert callable(result)
        A = csc_array(np.eye(3))
        b = np.ones(3)
        x = result(A, b)
        np.testing.assert_allclose(x, np.ones(3))

    def test_get_default_solver_sparse(self, dummy_data_dict):
        """Test that sparse solver is returned for high sparsity."""
        from iltpy.fit.inversion import IltSolver

        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.alt_g = 0
        test_iltdata.K0comp = np.eye(3)
        test_iltdata._K_sparsity = 0.95  # High sparsity
        test_iltdata.force_sparse = False
        test_iltdata.sparse_threshold = 0.9

        solver = IltSolver(test_iltdata)
        result = solver.get_default_solver()

        assert callable(result)

    def test_get_default_solver_force_sparse(self, dummy_data_dict):
        """Test that sparse solver is returned when force_sparse=True."""
        from iltpy.fit.inversion import IltSolver

        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.alt_g = 0
        test_iltdata.K0comp = np.eye(3)
        test_iltdata._K_sparsity = 0.3  # low sparsity
        test_iltdata.force_sparse = True  # force sparse
        test_iltdata.sparse_threshold = 0.9

        solver = IltSolver(test_iltdata)
        result = solver.get_default_solver()

        assert callable(result)

    def test_alt_g_solve_2(self, dummy_data_dict):
        """Test alt_g_solve with alt_g=2."""
        from iltpy.fit.inversion import IltSolver

        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.alt_g = 2
        test_iltdata.K0comp = np.eye(3, dtype=float)
        test_iltdata._K_sparsity = 0.5
        test_iltdata.force_sparse = False
        test_iltdata.sparse_threshold = 0.9
        test_iltdata._Is = np.eye(3, dtype=float)
        test_iltdata._mcomp = np.ones((3, 1), dtype=float)
        test_iltdata.Gamma2 = csc_array(np.eye(3, dtype=float))

        solver = IltSolver(test_iltdata)
        result = solver.alt_g_solve(test_iltdata)

        assert isinstance(result, np.ndarray)
        assert result.shape == (3,)

    def test_alt_g_solve_4_with_sigma(self, dummy_data_dict):
        """Test alt_g_solve with alt_g=4 and sigma not None."""
        from iltpy.fit.inversion import IltSolver

        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.alt_g = 4
        test_iltdata.K0comp = np.eye(3, dtype=float)
        test_iltdata._K_sparsity = 0.5
        test_iltdata.force_sparse = False
        test_iltdata.sparse_threshold = 0.9
        test_iltdata._Is = np.eye(3, dtype=float)
        test_iltdata._mcomp = np.ones((3, 1), dtype=float)
        test_iltdata._mcompbar = np.ones((3, 1), dtype=float)
        test_iltdata._isigma = np.eye(3, dtype=float)
        test_iltdata.sigma = np.ones(3)  # sigma is not None
        test_iltdata.Gamma2 = csc_array(np.eye(3, dtype=float))

        solver = IltSolver(test_iltdata)
        result = solver.alt_g_solve(test_iltdata)

        assert isinstance(result, np.ndarray)
        assert result.shape == (3,)

    def test_alt_g_solve_4_without_sigma(self, dummy_data_dict):
        """Test alt_g_solve with alt_g=4 and sigma is None."""
        from iltpy.fit.inversion import IltSolver

        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.alt_g = 4
        test_iltdata.K0comp = np.eye(3, dtype=float)
        test_iltdata._K_sparsity = 0.5
        test_iltdata.force_sparse = False
        test_iltdata.sparse_threshold = 0.9
        test_iltdata._Is = np.eye(3, dtype=float)
        test_iltdata._mcomp = np.ones((3, 1), dtype=float)
        test_iltdata.sigma = None  # sigma is None
        test_iltdata.Gamma2 = csc_array(np.eye(3, dtype=float))

        solver = IltSolver(test_iltdata)
        result = solver.alt_g_solve(test_iltdata)

        assert isinstance(result, np.ndarray)
        assert result.shape == (3,)

    def test_alt_g_solve_6(self, dummy_data_dict):
        """Test alt_g_solve with alt_g=6."""
        from iltpy.fit.inversion import IltSolver

        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.alt_g = 6
        test_iltdata.K0comp = np.eye(3, dtype=float)
        test_iltdata._K_sparsity = 0.5
        test_iltdata.force_sparse = False
        test_iltdata.sparse_threshold = 0.9
        test_iltdata._Is = np.eye(3, dtype=float)
        test_iltdata._mcomp = np.ones((3, 1), dtype=float)
        test_iltdata.Gamma2 = csc_array(np.eye(3, dtype=float))

        solver = IltSolver(test_iltdata)
        result = solver.alt_g_solve(test_iltdata)

        assert isinstance(result, np.ndarray)
        assert result.shape == (3,)

    def test_alt_g_solve_8(self, dummy_data_dict):
        """Test alt_g_solve with alt_g=8 (LU decomposition path)."""
        from iltpy.fit.inversion import IltSolver

        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.alt_g = 8
        test_iltdata.K0comp = np.eye(3, dtype=float)
        test_iltdata._K_sparsity = 0.5
        test_iltdata.force_sparse = False
        test_iltdata.sparse_threshold = 0.9
        test_iltdata._Is = np.eye(3, dtype=float)
        test_iltdata._mcomp = np.ones((3, 1), dtype=float)
        test_iltdata.Gamma2 = csc_array(np.eye(3, dtype=float))

        solver = IltSolver(test_iltdata)
        result = solver.alt_g_solve(test_iltdata)

        assert isinstance(result, np.ndarray)
        assert result.shape == (3,)

    def test_alt_g_solve_invalid(self, dummy_data_dict):
        """Test alt_g_solve raises ValueError for invalid alt_g."""
        from iltpy.fit.inversion import IltSolver

        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.alt_g = 99  # Invalid value
        test_iltdata.K0comp = np.eye(3, dtype=float)
        test_iltdata._K_sparsity = 0.5
        test_iltdata.force_sparse = False
        test_iltdata.sparse_threshold = 0.9

        solver = IltSolver(test_iltdata)

        with pytest.raises(ValueError, match="Invalid alt_g value"):
            solver.alt_g_solve(test_iltdata)

    def test_compute_AbarT(self, dummy_data_dict):
        """Test _compute_AbarT returns correct matrices."""
        from iltpy.fit.inversion import IltSolver

        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.alt_g = 2
        test_iltdata.K0comp = np.eye(3, dtype=float)
        test_iltdata._K_sparsity = 0.5
        test_iltdata.force_sparse = False
        test_iltdata.sparse_threshold = 0.9
        test_iltdata.Gamma2 = csc_array(np.eye(3, dtype=float))

        solver = IltSolver(test_iltdata)
        AbarT, upper_tri = solver._compute_AbarT(test_iltdata)

        assert isinstance(AbarT, np.ndarray)
        assert isinstance(upper_tri, np.ndarray)
        assert AbarT.shape == (3, 3)
        assert upper_tri.shape == (3, 3)