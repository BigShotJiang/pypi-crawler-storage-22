import pytest
import numpy as np
from unittest.mock import patch
from iltpy.fit.kernels import (
    IltKernel,
    iltkernel,
    Exponential,
    Gaussian,
    Diffusion,
    RealRcKernel,
    ImagRcKernel,
    Identity,
)
from iltpy.fit.kernels import (
    _kernel_mat_diag,
    _kernel_mat_eye,
    _kernel_mat_identity,
    _kernel_mat_kron,
    _select_kernel_mode,
    _compress_kernel,
    _generate_W_Y,
    init_kernelmatrix,
)
from scipy.sparse import issparse
from iltpy.fit.inversion import IltData

class TestIltPyFitKernels:
    def test_iltkernel(self):
        """Tests the iltkernel function creates a valid IltKernel subclass with correct attributes."""
        name_in = "my_kernel"
        func_in = lambda t, tau: np.exp(-t / tau)  # noqa: E731
        str_in = "lambda t,tau: np.exp(-t/tau)"

        MyKernelClass = iltkernel(name_in, func_in, str_in)
        instance = MyKernelClass()

        assert isinstance(instance, IltKernel)

        assert instance.name == name_in
        assert instance.kernel == func_in
        assert instance.kernel_str == str_in

        res = instance.kernel(1.0, 1.0)
        assert np.isclose(res, np.exp(-1))

    @pytest.mark.parametrize(
        "kernel_class, expected_shape, calc_func",
        [
            (Exponential, (2, 3), lambda t, tau: np.exp(-t / tau)),
            (Gaussian, (2, 3), lambda t, tau: np.exp(-(t**2) * (1 / tau) ** 2 / 2)),
            (Diffusion, (2, 3), lambda t, tau: np.exp(-t * tau)),
            (
                RealRcKernel,
                (2, 3),
                lambda t, tau: np.real(1.0 / (1 + 1j * 2 * np.pi * tau * t)),
            ),
            (
                ImagRcKernel,
                (2, 3),
                lambda t, tau: np.imag(1.0 / (1 + 1j * 2 * np.pi * tau * t)),
            ),
            (Identity, (3, 3), lambda t, tau: np.eye(t.size)),
        ],
    )
    def test_kernels_with_arrays(self, kernel_class, expected_shape, calc_func):
        """Tests kernel classes compute correct matrix shapes and values for array inputs."""
        t_vec = np.array([1.0, 2.0, 3.0]).reshape(1, 3)
        tau_vec = np.array([0.5, 1.5]).reshape(2, 1)
        k = kernel_class()

        test_kernel_matrix = k.kernel(t_vec, tau_vec)
        expected_kernel_matrix = calc_func(t_vec, tau_vec)
        assert test_kernel_matrix.shape == expected_shape

        np.testing.assert_allclose(
            test_kernel_matrix,
            expected_kernel_matrix,
        )

    @pytest.mark.parametrize("sparse", [True, False])
    def test_kernel_mat_identity(self, sparse):
        """Tests _kernel_mat_identity creates correct identity matrix in dense or sparse format."""
        n = 4
        res = _kernel_mat_identity(n, sparse=sparse)

        assert res.shape == (n, n)
        if sparse:
            assert issparse(res)
            np.testing.assert_array_equal(res.diagonal(), np.ones(n))
        else:
            assert isinstance(res, np.ndarray)
            np.testing.assert_array_equal(res, np.eye(n))

    @pytest.mark.parametrize("sparse", [True, False])
    def test_kernel_mat_eye(self, sparse):
        """Tests _kernel_mat_eye creates correct identity matrix in dense or sparse format."""
        n = 4
        res = _kernel_mat_eye(n, sparse=sparse)

        assert res.shape == (n, n)
        if sparse:
            assert issparse(res)
            np.testing.assert_array_equal(res.diagonal(), np.ones(n))
        else:
            assert isinstance(res, np.ndarray)
            np.testing.assert_array_equal(res, np.eye(n))

    @pytest.mark.parametrize("sparse", [True, False])
    def test_kernel_mat_diag(self, sparse):
        """Tests _kernel_mat_diag creates correct diagonal matrix in dense or sparse format."""
        diag_vals = np.array([1.0, 2.0, 3.0])
        res = _kernel_mat_diag(diag_vals, sparse=sparse)

        assert res.shape == (3, 3)
        if sparse:
            assert issparse(res)
            np.testing.assert_array_equal(res.diagonal(), diag_vals)
        else:
            np.testing.assert_array_equal(np.diagonal(res), diag_vals)

    @pytest.mark.parametrize("sparse", [True, False])
    def test_kernel_mat_kron(self, sparse):
        """Tests _kernel_mat_kron computes Kronecker product in dense or sparse format."""
        a = np.array([[1, 2], [3, 4]])
        b = np.eye(2)

        res = _kernel_mat_kron(a, b, sparse=sparse)

        assert res.shape == (4, 4)

        expected = np.kron(a, b)

        if sparse:
            assert issparse(res)
            np.testing.assert_allclose(res.toarray(), expected)
        else:
            np.testing.assert_allclose(res, expected)

    def test_select_kernel_mode_dense(self, dummy_data_dict):
        """Tests _select_kernel_mode selects dense solver when sparsity is below threshold."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.K = [np.eye(5)]
        test_iltdata.alt_g = 0
        test_iltdata.sparse_threshold = 0.5
        test_iltdata.force_sparse = False
        test_iltdata._ndim = 1

        with patch("iltpy.fit.kernels._estimate_sparsity", return_value=0.3):
            _select_kernel_mode(test_iltdata)

        assert test_iltdata._is_kernel_sparse is False
        assert test_iltdata._solver_type == "default-dense"

    def test_select_kernel_mode_override_dense(self, dummy_data_dict):
        """Tests _select_kernel_mode respects force_sparse flag overriding sparsity threshold."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.K = [np.eye(5)]
        test_iltdata.alt_g = 0
        test_iltdata.sparse_threshold = 0.8
        test_iltdata.force_sparse = True
        test_iltdata._ndim = 1

        with patch("iltpy.fit.kernels._estimate_sparsity", return_value=0.1):
            _select_kernel_mode(test_iltdata)

        assert test_iltdata._is_kernel_sparse is True
        assert test_iltdata._solver_type == "default-sparse"

    def test_select_kernel_mode_alt_g_warn(self, dummy_data_dict):
        """Tests _select_kernel_mode warns when alt_g setting is suboptimal for kernel sparsity."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.K = [np.eye(5)]
        test_iltdata.alt_g = 6
        test_iltdata.sparse_threshold = 0.5
        test_iltdata.force_sparse = False
        test_iltdata._ndim = 1

        with patch("iltpy.fit.kernels._estimate_sparsity", return_value=0.9):
            with pytest.warns(
                UserWarning,
                match="Setting alt_g equal to 0 may show better performance",
            ):
                _select_kernel_mode(test_iltdata)

        test_iltdata.alt_g = 0
        test_iltdata.sparse_threshold = 0.5
        test_iltdata.force_sparse = False
        test_iltdata._ndim = 2

        with patch("iltpy.fit.kernels._estimate_sparsity", return_value=0.1):
            with pytest.warns(
                UserWarning,
                match="Setting alt_g equal to 6 may show better performance",
            ):
                _select_kernel_mode(test_iltdata)

    @patch("iltpy.fit.kernels.svd")
    def test_compress_kernel_full_svd(self, mock_svd, dummy_data_dict):
        """Tests _compress_kernel uses full SVD when use_svds is False."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.use_svds = False
        test_iltdata.K = [np.random.randn(5, 10)]
        test_iltdata.s = [2]
        mock_svd.return_value = ["u_mat", "s_vec", "v_mat"]
        u, d, v = _compress_kernel(test_iltdata, 0)

        mock_svd.assert_called_once()
        assert mock_svd.call_args[0][0].shape == (10, 5)
        assert mock_svd.call_args[1]["full_matrices"] is False

    @patch("iltpy.fit.kernels.svds")
    def test_compress_kernel_svds(self, mock_svds, dummy_data_dict):
        """Tests _compress_kernel uses sparse SVD (svds) when use_svds is True."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.use_svds = True
        test_iltdata.K = [np.random.randn(5, 10)]
        test_iltdata.s = [2]
        mock_svds.return_value = ["u_mat", "s_vec", "v_mat"]
        u, d, v = _compress_kernel(test_iltdata, 0)

        mock_svds.assert_called_once()
        assert mock_svds.call_args[0][0].shape == (10, 5)
        assert mock_svds.call_args[0][1] == 2
        assert mock_svds.call_args[1]["solver"] == "propack"

    def test_generate_wy_unweighted(self, dummy_data_dict):
        """Tests unweighted W and Y calculation"""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.sigma = None
        test_iltdata.alt_g = 0

        test_iltdata.K0comp = np.array([[1, 2], [3, 4]])
        test_iltdata._mcomp = np.array([[10], [20]])

        _generate_W_Y(test_iltdata)

        expected_w = test_iltdata.K0comp.T @ test_iltdata.K0comp
        expected_y = test_iltdata.K0comp.T @ test_iltdata._mcomp

        np.testing.assert_allclose(test_iltdata.W, expected_w)
        np.testing.assert_allclose(test_iltdata.Y, expected_y)

    def test_generate_wy_weighted_alt_g_0(self, dummy_data_dict):
        """Tests _generate_W_Y computes weighted W with sigma and alt_g=0."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.sigma = np.array([1.0, 2.0])
        test_iltdata._Sigma = np.array(
            [2.0, 4.0]
        )  # _Sigma will be calculate if sigma is not None
        test_iltdata.alt_g = 0
        test_iltdata._ncomp = 2
        test_iltdata._is_kernel_sparse = False

        test_iltdata.K0comp = np.eye(2)
        test_iltdata._mcomp = np.array([[10], [10]])

        _generate_W_Y(test_iltdata)

        # _isigma should be diag(1/2, 1/4)
        expected_isigma = np.diag([0.5, 0.25])
        np.testing.assert_allclose(test_iltdata._isigma, expected_isigma)

        # W = I.T @ (diag(0.25, 0.0625)) @ I
        expected_w = expected_isigma @ expected_isigma
        np.testing.assert_allclose(test_iltdata.W, expected_w)

    def test_generate_wy_alt_g_4(self, dummy_data_dict):
        """Tests _generate_W_Y computes _mcompbar and skips W when alt_g=4."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.sigma = np.ones(2)
        test_iltdata._Sigma = np.array([2.0, 2.0])
        test_iltdata.alt_g = 4
        test_iltdata._ncomp = 2
        test_iltdata._mcomp = np.array([[10], [20]])
        test_iltdata._is_kernel_sparse = False

        _generate_W_Y(test_iltdata)

        # _isigma should be diag(0.5, 0.5)
        # _mcompbar = isigma @ mcomp = [5, 10]
        expected_mbar = np.array([[5.0], [10.0]])
        np.testing.assert_allclose(test_iltdata._mcompbar, expected_mbar)

        # W will not be difned for alt_g=4
        assert not hasattr(test_iltdata, "W")

    @patch("iltpy.fit.kernels._select_kernel_mode")
    @patch("iltpy.fit.kernels._generate_W_Y")
    @patch("iltpy.fit.kernels._multidim_matmul")
    def test_init_kernel_matrix_1d_case(
        self,
        mock_multidim_matmul,
        mock_generate_W_Y,
        mock_select_kernel_mode,
        dummy_data_dict,
    ):
        """Tests init_kernelmatrix correctly initializes kernel matrix for 1D data without compression."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.data = np.arange(6)
        test_iltdata.kernel = [Exponential()]
        test_iltdata.t = [np.ones((1, 6))]
        test_iltdata.tau = [np.ones((4, 1))]
        test_iltdata._is_kernel_sparse = False
        test_iltdata._ndim = 1
        test_iltdata.sb = [False]
        test_iltdata.compress = [0]
        test_iltdata.Nt = [6]
        test_iltdata.s = [6]  # would equal Nt when compress is False

        mock_multidim_matmul.return_value = np.array([0.0, 1.0, 2.0, 3.0, 4.0, 5.0])

        expected_K = [np.exp(-np.ones((1, 6)) / np.ones((4, 1)))]
        expected_K0comp = np.kron(expected_K[0].T, np.eye(1))
        expected_U = [np.eye(6)]
        expected_Ut = [expected_U[0].T]
        expected_Is = np.eye(expected_K0comp.shape[0])
        expected_ncomp = 6
        expected_mcomp = np.array([0.0, 1.0, 2.0, 3.0, 4.0, 5.0]).reshape(
            (expected_ncomp, 1)
        )

        init_kernelmatrix(test_iltdata)

        mock_select_kernel_mode.assert_called_once()
        mock_multidim_matmul.assert_called_once()
        mock_generate_W_Y.assert_called_once()

        np.testing.assert_allclose(test_iltdata.K, expected_K)
        np.testing.assert_allclose(test_iltdata.K0comp, expected_K0comp)
        np.testing.assert_allclose(test_iltdata.U, expected_U)
        np.testing.assert_allclose(test_iltdata.Ut, expected_Ut)
        np.testing.assert_allclose(test_iltdata._Is, expected_Is)
        np.testing.assert_allclose(test_iltdata._ncomp, expected_ncomp)
        np.testing.assert_allclose(test_iltdata._mcomp, expected_mcomp)

    @patch("iltpy.fit.kernels._select_kernel_mode")
    @patch("iltpy.fit.kernels._generate_W_Y")
    @patch("iltpy.fit.kernels._multidim_matmul")
    def test_init_kernel_matrix_1d_case_sb_true(
        self,
        mock_multidim_matmul,
        mock_generate_W_Y,
        mock_select_kernel_mode,
        dummy_data_dict,
    ):
        """Tests init_kernelmatrix handles 1D data with baseline correction (sb=True)."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.data = np.arange(6)
        test_iltdata.kernel = [Exponential()]
        test_iltdata.t = [np.ones((1, 6))]
        test_iltdata.tau = [np.ones((4, 1))]
        test_iltdata._is_kernel_sparse = False
        test_iltdata._ndim = 1
        test_iltdata.sb = [True]
        test_iltdata.compress = [0]
        test_iltdata.Nt = [6]
        test_iltdata.s = [6]  # would equal Nt when compress is False

        mock_multidim_matmul.return_value = np.array([0.0, 1.0, 2.0, 3.0, 4.0, 5.0])

        K = [np.exp(-np.ones((1, 6)) / np.ones((4, 1)))]
        expected_K = [np.vstack((K[0], np.ones((1, K[0].T.shape[0]))))]
        expected_K0comp = np.kron(expected_K[0].T, np.eye(1))
        expected_U = [np.eye(6)]
        expected_Ut = [expected_U[0].T]
        expected_Is = np.eye(expected_K0comp.shape[0])
        expected_ncomp = 6
        expected_mcomp = np.array([0.0, 1.0, 2.0, 3.0, 4.0, 5.0]).reshape(
            (expected_ncomp, 1)
        )

        init_kernelmatrix(test_iltdata)

        mock_select_kernel_mode.assert_called_once()
        mock_multidim_matmul.assert_called_once()
        mock_generate_W_Y.assert_called_once()

        np.testing.assert_allclose(test_iltdata.K, expected_K)
        np.testing.assert_allclose(test_iltdata.K0comp, expected_K0comp)
        np.testing.assert_allclose(test_iltdata.U, expected_U)
        np.testing.assert_allclose(test_iltdata.Ut, expected_Ut)
        np.testing.assert_allclose(test_iltdata._Is, expected_Is)
        np.testing.assert_allclose(test_iltdata._ncomp, expected_ncomp)
        np.testing.assert_allclose(test_iltdata._mcomp, expected_mcomp)

    @patch("iltpy.fit.kernels._select_kernel_mode")
    @patch("iltpy.fit.kernels._generate_W_Y")
    @patch("iltpy.fit.kernels._multidim_matmul")
    @patch("iltpy.fit.kernels._compress_kernel")
    def test_init_kernel_matrix_1d_case_compress_true(
        self,
        mock_compress_kernel,
        mock_multidim_matmul,
        mock_generate_W_Y,
        mock_select_kernel_mode,
        dummy_data_dict,
    ):
        """Tests init_kernelmatrix correctly applies SVD compression for 1D data."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.data = np.arange(6)
        test_iltdata.kernel = [Exponential()]
        test_iltdata.t = [np.ones((1, 6))]
        test_iltdata.tau = [np.ones((4, 1))]
        test_iltdata._is_kernel_sparse = False
        test_iltdata._ndim = 1
        test_iltdata.sb = [False]
        test_iltdata.compress = [1]
        test_iltdata.Nt = [6]
        test_iltdata.s = [2]
        test_iltdata.Nx = np.array([4])

        mock_multidim_matmul.return_value = np.array([0.0, 1.0])
        mock_compress_kernel.return_value = (
            np.eye(6),
            np.array([10.0, 5.0, 1.0, 0.1]),
            np.eye(4),
        )

        expected_K = [np.exp(-np.ones((1, 6)) / np.ones((4, 1)))]

        u1, d1, v1 = (np.eye(6), np.array([10.0, 5.0, 1.0, 0.1]), np.eye(4))
        v1 = v1.T
        d1_diag = np.diag(d1[:2])
        v1_red = v1[:4, :2]  # see nx and s assigments

        expected_K0comp = np.kron(d1_diag @ v1_red.T, np.eye(1))
        expected_U = [u1[:6, :2]]  # see nt and s assigments
        expected_Ut = [expected_U[0].T]
        expected_Is = np.eye(expected_K0comp.shape[0])
        expected_ncomp = 2
        expected_mcomp = np.array([0.0, 1.0]).reshape((expected_ncomp, 1))

        init_kernelmatrix(test_iltdata)

        mock_compress_kernel.assert_called_once()
        mock_select_kernel_mode.assert_called_once()
        mock_multidim_matmul.assert_called_once()
        mock_generate_W_Y.assert_called_once()

        np.testing.assert_allclose(test_iltdata.K, expected_K)
        np.testing.assert_allclose(test_iltdata.K0comp, expected_K0comp)
        np.testing.assert_allclose(test_iltdata.U, expected_U)
        np.testing.assert_allclose(test_iltdata.Ut, expected_Ut)
        np.testing.assert_allclose(test_iltdata._Is, expected_Is)
        np.testing.assert_allclose(test_iltdata._ncomp, expected_ncomp)
        np.testing.assert_allclose(test_iltdata._mcomp, expected_mcomp)

    @patch("iltpy.fit.kernels._select_kernel_mode")
    @patch("iltpy.fit.kernels._generate_W_Y")
    @patch("iltpy.fit.kernels._multidim_matmul")
    def test_init_kernel_matrix_2d_case(
        self,
        mock_multidim_matmul,
        mock_generate_W_Y,
        mock_select_kernel_mode,
        dummy_data_dict,
    ):
        """Tests init_kernelmatrix correctly builds Kronecker product kernel for 2D data."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.data = np.ones((6, 6)) * 5
        test_iltdata.kernel = [Exponential(), Exponential()]
        test_iltdata.t = [np.ones((1, 6)), np.ones((1, 6))]
        test_iltdata.tau = [np.ones((4, 1)), np.ones((4, 1))]
        test_iltdata._is_kernel_sparse = False
        test_iltdata._ndim = 2
        test_iltdata.sb = [False, False]
        test_iltdata.compress = [0, 0]
        test_iltdata.Nt = [6, 6]
        test_iltdata.s = [6, 6]

        mock_multidim_matmul.return_value = np.ones((6, 6)) * 5

        expected_K = [
            np.exp(-np.ones((1, 6)) / np.ones((4, 1))),
            np.exp(-np.ones((1, 6)) / np.ones((4, 1))),
        ]

        # Loop 0: kron(K[0].T, I(1)) -> (4, 6)
        # Loop 1: kron(K[1].T, (4, 6)) -> (16, 36)
        k0 = expected_K[0].T
        expected_K0comp = np.kron(k0, np.kron(k0, np.eye(1)))

        expected_U = [np.eye(6), np.eye(6)]
        expected_Ut = [expected_U[0].T, expected_U[1].T]
        expected_Is = np.eye(expected_K0comp.shape[0])
        expected_ncomp = 36  # prod of s
        expected_mcomp = mock_multidim_matmul.return_value.reshape((expected_ncomp, 1))

        init_kernelmatrix(test_iltdata)

        mock_select_kernel_mode.assert_called_once()
        mock_multidim_matmul.assert_called_once()
        mock_generate_W_Y.assert_called_once()

        np.testing.assert_allclose(test_iltdata.K, expected_K)
        np.testing.assert_allclose(test_iltdata.K0comp, expected_K0comp)
        np.testing.assert_allclose(test_iltdata.U, expected_U)
        np.testing.assert_allclose(test_iltdata.Ut, expected_Ut)
        np.testing.assert_allclose(test_iltdata._Is, expected_Is)
        np.testing.assert_allclose(test_iltdata._ncomp, expected_ncomp)
        np.testing.assert_allclose(test_iltdata._mcomp, expected_mcomp)


