import numpy as np
from scipy.sparse import issparse, diags as spdiags
from iltpy.fit.inversion import IltData
from iltpy.fit.regularization import (
    nn_reg,
    init_g_red,
    amp_reg,
    init_regmatrix,
    up_reg,
    zc_reg,
)


class TestIltPyFitRegularization:
    def test_nn_reg(self, dummy_data_dict):
        """Tests nn_reg computes non-negativity penalty diagonal matrix for negative g values."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.g = np.array([10.0, -5.0, 0.0, -2.0])  # dummy g
        test_iltdata.Nxtot = 4
        test_iltdata.alpha_nn = np.array([1000])

        gamma_nn = nn_reg(test_iltdata)

        assert issparse(gamma_nn)
        assert gamma_nn.shape == (4, 4)

        diag_values = gamma_nn.diagonal()

        # Index 0: g=10 -> (1 - 1) = 0  -> Penalty = 0
        # Index 1: g=-5 -> (1 - -1) = 2 -> Penalty = 0.5 * 1.0 * 2 = 1.0
        # Index 2: g=0  -> np.sign(0)=0 -> (1 - 0) = 1 -> Penalty = 0.5 * 1.0 * 1 = 0.5
        # Index 3: g=-2 -> (1 - -1) = 2 -> Penalty = 1.0

        expected_diags = np.array([0.0, 1000.0, 500.0, 1000.0])

        np.testing.assert_allclose(diag_values, expected_diags)

    def test_nn_reg_all_positive(self, dummy_data_dict):
        """If all values are positive, the diagonal should be all zeros."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.g = np.array([1.0, 100.0, 0.5])
        test_iltdata.Nxtot = 3
        test_iltdata.alpha_nn = [1.0]

        gamma_nn = nn_reg(test_iltdata)
        np.testing.assert_array_equal(gamma_nn.diagonal(), np.zeros(3))

    def test_init_g_red_1d_no_sb(self, dummy_data_dict):
        """Tests init_g_red initializes g_red and idx_red for 1D case without baseline."""
        test_iltdata = IltData(dummy_data_dict)

        test_iltdata._ndim = 1
        test_iltdata.Nx0 = [3]
        test_iltdata.sb = [False]
        test_iltdata.Nx = [3]  # wil be as same as Nx0 since sb is False.
        test_iltdata.idx = [[0, 0]]

        init_g_red(test_iltdata)

        assert len(test_iltdata.g_red) == 1
        np.testing.assert_array_equal([np.array([1.0, 1.0, 1.0])], test_iltdata.g_red)
        np.testing.assert_array_equal(
            [np.array([0, 1, 2], dtype=np.int32)], test_iltdata.idx_red
        )

    def test_init_g_red_1d_with_sb(self, dummy_data_dict):
        """Test 1D case with static baseline."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 1
        test_iltdata.Nx0 = [3]
        test_iltdata.Nx = [4]  # Nx is Nx0 + 1 when sb is True
        test_iltdata.sb = [True]
        test_iltdata.idx = [[0, 0]]

        init_g_red(test_iltdata)

        expected = np.array([1, 1, 1, 0])
        np.testing.assert_array_equal(test_iltdata.g_red[0], expected)
        np.testing.assert_array_equal(test_iltdata.idx_red[0], [0, 1, 2])

    def test_init_g_red_2d_structure(self, dummy_data_dict):
        """Test 2D case to verify Kronecker expansion and cross-terms."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 2
        test_iltdata.Nx0 = [2, 2]
        test_iltdata.Nx = [2, 2]
        test_iltdata.sb = [False, False]
        test_iltdata.idx = [[0, 0], [1, 1], [0, 1], [1, 0]]

        init_g_red(test_iltdata)

        # there should be n_dim**2 number of  arrays
        assert len(test_iltdata.g_red) == 4
        for arr in test_iltdata.g_red:
            assert arr.shape == (4,)
            np.testing.assert_array_equal(np.array([1.0, 1.0, 1.0, 1.0]), arr)

        for arr in test_iltdata.idx_red:
            assert arr.shape == (4,)
            np.testing.assert_array_equal(np.array([0, 1, 2, 3], dtype=np.int32), arr)

    def test_amp_reg_no_boundary_conditions(self, dummy_data_dict):
        """Test amp_reg when reg_bc sum is 0 (no boundary conditions)."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 1
        test_iltdata.Nx = np.array([4])
        test_iltdata.Nx0 = np.array([4])
        test_iltdata.reg_bc = [0]
        test_iltdata.alpha_bc = [50]
        test_iltdata.Nxtot = 4

        amp_reg(test_iltdata)

        assert issparse(test_iltdata.Vbc)
        assert test_iltdata.Vbc.shape == (4, 4)
        # all elements should be zero when reg_bc sum is 0
        np.testing.assert_array_equal(test_iltdata.Vbc.toarray(), np.zeros((4, 4)))

    def test_amp_reg_1d_with_boundary(self, dummy_data_dict):
        """Test amp_reg for 1D case with boundary conditions."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 1
        test_iltdata.Nx = np.array([4])
        test_iltdata.Nx0 = np.array([4])
        test_iltdata.reg_bc = [1]
        test_iltdata.alpha_bc = [50]
        test_iltdata.Nxtot = 4

        amp_reg(test_iltdata)

        assert issparse(test_iltdata.Vbc)
        assert test_iltdata.Vbc.shape == (4, 4)
        diag = test_iltdata.Vbc.diagonal()
        # first and last (Nx0[0]-1 = 3) indices should have alpha_bc value
        assert diag[0] == 50
        assert diag[3] == 50
        np.testing.assert_array_equal(diag[1:3], np.zeros(2))

    def test_amp_reg_2d_with_boundary(self, dummy_data_dict):
        """Test amp_reg for 2D case with boundary conditions."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 2
        test_iltdata.Nx = np.array([3, 3])
        test_iltdata.Nx0 = np.array([3, 3])
        test_iltdata.reg_bc = [1, 1]
        test_iltdata.alpha_bc = [50, 100]
        test_iltdata.Nxtot = 9

        amp_reg(test_iltdata)

        assert issparse(test_iltdata.Vbc)
        assert test_iltdata.Vbc.shape == (9, 9)

    def test_init_regmatrix_1d_no_sb(self, dummy_data_dict):
        """Test init_regmatrix for 1D case without static baseline."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 1
        test_iltdata.Nx0 = [4]
        test_iltdata.Nx = [4]
        test_iltdata.Nxtot = np.prod(test_iltdata.Nx)
        test_iltdata.sb = [False]
        test_iltdata.idx = [[0, 0]]
        test_iltdata.reg_bc = [0]
        test_iltdata.alpha_bc = [50]

        init_regmatrix(test_iltdata)

        assert hasattr(test_iltdata, "g_red")
        assert hasattr(test_iltdata, "idx_red")
        assert hasattr(test_iltdata, "Pms")
        assert hasattr(test_iltdata, "Sms")
        assert hasattr(test_iltdata, "Gm")
        assert hasattr(test_iltdata, "GmI")
        assert hasattr(test_iltdata, "Vbc")

        assert len(test_iltdata.Pms) == 1  # ndim**2 = 1
        assert len(test_iltdata.Sms) == 1
        assert len(test_iltdata.Gm) == 1

        assert test_iltdata.GmI.shape == (4, 4)
        assert test_iltdata.Vbc.shape == (4, 4)

    def test_init_regmatrix_1d_with_sb(self, dummy_data_dict):
        """Test init_regmatrix for 1D case with static baseline."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 1
        test_iltdata.Nx0 = [4]
        test_iltdata.Nx = [5]  # Nx0 + 1 when sb is True
        test_iltdata.Nxtot = np.prod(test_iltdata.Nx)
        test_iltdata.sb = [True]
        test_iltdata.idx = [[0, 0]]
        test_iltdata.reg_bc = [0]
        test_iltdata.alpha_bc = [50]

        init_regmatrix(test_iltdata)

        assert test_iltdata.GmI.shape == (5, 5)
        assert test_iltdata.Vbc.shape == (5, 5)
        assert test_iltdata.Gm[0].shape == (5, 5)

    def test_init_regmatrix_2d(self, dummy_data_dict):
        """Test init_regmatrix for 2D case."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 2
        test_iltdata.Nx0 = [3, 3]
        test_iltdata.Nx = [3, 3]
        test_iltdata.Nxtot = np.prod(test_iltdata.Nx)
        test_iltdata.sb = [False, False]
        test_iltdata.idx = [[0, 0], [1, 1], [0, 1], [1, 0]]
        test_iltdata.reg_bc = [0, 0]
        test_iltdata.alpha_bc = [50, 100]

        init_regmatrix(test_iltdata)

        assert len(test_iltdata.Pms) == 4
        assert len(test_iltdata.Sms) == 4
        assert len(test_iltdata.Gm) == 4

        assert test_iltdata.GmI.shape == (9, 9)
        assert test_iltdata.Vbc.shape == (9, 9)
        for i in range(4):
            assert test_iltdata.Gm[i].shape == (9, 9)

    def test_init_regmatrix_2d_with_sb(self, dummy_data_dict):
        """Test init_regmatrix for 2D case with static baseline in first dimension."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 2
        test_iltdata.Nx0 = [3, 3]
        # Nx[0] = Nx0[0] + 1 when sb[0] is True, Nx[1] = Nx0[1] when sb[1] is False
        test_iltdata.Nx = [4, 3]
        test_iltdata.Nxtot = np.prod(test_iltdata.Nx)
        test_iltdata.sb = [True, False]  # sb True for first dimension
        test_iltdata.idx = [[0, 0], [1, 1], [0, 1], [1, 0]]
        test_iltdata.reg_bc = [0, 0]
        test_iltdata.alpha_bc = [50, 100]

        init_regmatrix(test_iltdata)

        assert len(test_iltdata.Pms) == 4
        assert len(test_iltdata.Sms) == 4
        assert len(test_iltdata.Gm) == 4

        assert test_iltdata.GmI.shape == (12, 12)
        assert test_iltdata.Vbc.shape == (12, 12)
        for i in range(4):
            assert test_iltdata.Gm[i].shape == (12, 12)

    def test_up_reg_basic(self, dummy_data_dict):
        """Test up_reg returns sparse matrix with correct shape."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 1
        test_iltdata.Nxtot = 4
        test_iltdata.g = np.array([1.0, 2.0, 3.0, 4.0])
        test_iltdata.Nx = np.array([4])
        test_iltdata.Nx0 = np.array([4])
        test_iltdata.idx = [[0, 0]]
        test_iltdata.idx_red = [np.array([0, 1, 2, 3])]
        test_iltdata.c_nmax = [3]
        test_iltdata.p_nmax = [3]
        test_iltdata.alpha_0 = np.array([0.0001])
        test_iltdata.alpha_p = np.array([1.0])
        test_iltdata.alpha_c = np.array([1.0])
        test_iltdata.Delta_Q = [1.0]

        test_iltdata.Gm = [spdiags([1.0, -2.0, 1.0, 0.0], 0, (4, 4))]
        test_iltdata.Pms = [spdiags([0.5, 0.5, 0.5, 0.5], 0, (4, 4))]

        u_pen = up_reg(test_iltdata)

        assert issparse(u_pen)
        assert u_pen.shape == (4, 4)

    def test_up_reg_sets_csq_inv(self, dummy_data_dict):
        """Test that up_reg sets CSq_inv attribute."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 1
        test_iltdata.Nxtot = 4
        test_iltdata.g = np.array([1.0, 2.0, 3.0, 4.0])
        test_iltdata.Nx = np.array([4])
        test_iltdata.Nx0 = np.array([4])
        test_iltdata.idx = [[0, 0]]
        test_iltdata.idx_red = [np.array([0, 1, 2, 3])]
        test_iltdata.c_nmax = [3]
        test_iltdata.p_nmax = [3]
        test_iltdata.alpha_0 = np.array([0.0001])
        test_iltdata.alpha_p = np.array([1.0])
        test_iltdata.alpha_c = np.array([1.0])
        test_iltdata.Delta_Q = [1.0]

        test_iltdata.Gm = [spdiags([1.0, -2.0, 1.0, 0.0], 0, (4, 4))]
        test_iltdata.Pms = [spdiags([0.5, 0.5, 0.5, 0.5], 0, (4, 4))]

        up_reg(test_iltdata)

        assert hasattr(test_iltdata, "CSq_inv")
        expected_csq_inv = np.array([np.array([17.0001, 18.2501, 20.0001, 13.0001])])
        np.testing.assert_allclose(test_iltdata.CSq_inv, expected_csq_inv)
        assert len(test_iltdata.CSq_inv) == 1

    def test_up_reg_2d(self, dummy_data_dict):
        """Test up_reg for 2D case with 4 iterations (ndim²)."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 2
        test_iltdata.Nxtot = 9  # 3*3
        test_iltdata.g = np.arange(1, 10, dtype=float)
        test_iltdata.Nx = np.array([3, 3])
        test_iltdata.Nx0 = np.array([3, 3])
        test_iltdata.idx = [[0, 0], [1, 1], [0, 1], [1, 0]] 

        test_iltdata.idx_red = [
            np.array([0, 1, 2, 3, 4, 5, 6, 7, 8]),
            np.array([0, 1, 2, 3, 4, 5, 6, 7, 8]),
            np.array([0, 1, 2, 3, 4, 5, 6, 7, 8]),
            np.array([0, 1, 2, 3, 4, 5, 6, 7, 8]),
        ]

        test_iltdata.c_nmax = [3, 3, 3, 3]
        test_iltdata.p_nmax = [3, 3, 3, 3]
        test_iltdata.alpha_0 = np.array([0.0001, 0.0001, 0.0001, 0.0001])
        test_iltdata.alpha_p = np.array([1.0, 1.0, 1.0, 1.0])
        test_iltdata.alpha_c = np.array([1.0, 1.0, 1.0, 1.0])
        test_iltdata.Delta_Q = [1.0, 1.0, 1.0, 1.0]

        # Gm and Pms need 4 matrices (9x9 each)
        test_iltdata.Gm = [spdiags(np.ones(9), 0, (9, 9)) for _ in range(4)]
        test_iltdata.Pms = [spdiags(np.ones(9) * 0.5, 0, (9, 9)) for _ in range(4)]

        u_pen = up_reg(test_iltdata)

        assert issparse(u_pen)
        assert u_pen.shape == (9, 9)
        # CSq_inv should have 4 elements for 2D
        assert len(test_iltdata.CSq_inv) == 4

    def test_zc_reg_disabled(self, dummy_data_dict):
        """Test zc_reg when reg_zc is False."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 1
        test_iltdata.Nxtot = 4
        test_iltdata.g = np.array([1.0, -2.0, 3.0, -4.0])
        test_iltdata.reg_zc = False
        test_iltdata.zc_on = 4
        test_iltdata.zc_upd = 1
        test_iltdata.zc_updmin = 0.2
        test_iltdata.zc_downrate = 0.05
        test_iltdata._ndim = 1

        zc_pen = zc_reg(test_iltdata, 5)

        assert issparse(zc_pen)
        assert zc_pen.shape == (4, 4)
        # Should be all zeros when reg_zc is False
        np.testing.assert_array_equal(zc_pen.toarray(), np.zeros((4, 4)))

    def test_zc_reg_before_zc_on(self, dummy_data_dict):
        """Test zc_reg when iteration is less than zc_on."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 1
        test_iltdata.Nxtot = 4
        test_iltdata.g = np.array([1.0, -2.0, 3.0, -4.0])
        test_iltdata.reg_zc = True
        test_iltdata.zc_on = 4
        test_iltdata.zc_upd = 1
        test_iltdata.zc_updmin = 0.2
        test_iltdata.zc_downrate = 0.05
        test_iltdata._ndim = 1

        zc_pen = zc_reg(test_iltdata, 3)  # iteration < zc_on

        assert issparse(zc_pen)
        # Should be all zeros when iteration < zc_on
        np.testing.assert_array_equal(zc_pen.toarray(), np.zeros((4, 4)))

    def test_zc_reg_after_zc_on(self, dummy_data_dict):
        """Test zc_reg when iteration is greater than zc_on."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 1
        test_iltdata.Nxtot = 4
        test_iltdata.g = np.array([1.0, -2.0, 3.0, -4.0])
        test_iltdata.Nx = np.array([4])
        test_iltdata.reg_zc = True
        test_iltdata.zc_on = 2
        test_iltdata.zc_down = 10  # greater than iteration, so no ratio update
        test_iltdata.zc_upd = 1.0
        test_iltdata.zc_updmin = 0.2
        test_iltdata.zc_downrate = 0.05
        test_iltdata.zc_max = 1.0
        test_iltdata.zc_nmax = 3 * np.ones((test_iltdata._ndim), dtype=np.int32)
        test_iltdata.idx = [[0, 0]]
        test_iltdata.Delta_Q = [1.0]
        test_iltdata.alpha_d = np.array([1.0])
        test_iltdata.g_red = [np.array([1.0, 1.0, 1.0, 1.0])]
        test_iltdata.Cz = [np.zeros(4)]
        test_iltdata.CSq_inv = [np.ones(4)]

        # set up Sms and Pms
        test_iltdata.Sms = [spdiags([0.5, 0.5, 0.5, 0.5], 0, (4, 4))]
        test_iltdata.Pms = [spdiags([0.5, 0.5, 0.5, 0.5], 0, (4, 4))]

        zc_pen = zc_reg(test_iltdata, 5)  # iteration > zc_on

        assert issparse(zc_pen)
        assert zc_pen.shape == (4, 4)

    def test_zc_reg_with_ratio_update(self, dummy_data_dict):
        """Test zc_reg when iteration > zc_down (ratio update occurs)."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 1
        test_iltdata.Nxtot = 4
        test_iltdata.g = np.array([1.0, -2.0, 3.0, -4.0])
        test_iltdata.Nx = np.array([4])
        test_iltdata.reg_zc = True
        test_iltdata.zc_on = 2
        test_iltdata.zc_down = 3  # less than iteration, so ratio update occurs
        test_iltdata.zc_upd = 1.0
        test_iltdata.zc_updmin = 0.2
        test_iltdata.zc_downrate = 0.05
        test_iltdata.zc_max = 1.0
        test_iltdata.zc_nmax = 3 * np.ones((test_iltdata._ndim), dtype=np.int32)
        test_iltdata.idx = [[0, 0]]
        test_iltdata.Delta_Q = [1.0]
        test_iltdata.alpha_d = np.array([1.0])
        test_iltdata.g_red = [np.array([1.0, 1.0, 1.0, 1.0])]
        test_iltdata.Cz = [np.zeros(4)]
        test_iltdata.CSq_inv = [np.ones(4)]

        # set up Sms and Pms
        test_iltdata.Sms = [spdiags([0.5, 0.5, 0.5, 0.5], 0, (4, 4))]
        test_iltdata.Pms = [spdiags([0.5, 0.5, 0.5, 0.5], 0, (4, 4))]

        zc_pen = zc_reg(test_iltdata, 5)  # iteration > zc_down

        assert issparse(zc_pen)
        assert zc_pen.shape == (4, 4)

    def test_zc_reg_2d_after_zc_on(self, dummy_data_dict):
        """Test zc_reg for 2D case - only i=0,1 are processed due to i <= _ndim - 1 condition."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 2
        test_iltdata.Nxtot = 9  # 3*3
        test_iltdata.g = np.arange(1, 10, dtype=float)
        test_iltdata.Nx = np.array([3, 3])
        test_iltdata.reg_zc = True
        test_iltdata.zc_on = 2
        test_iltdata.zc_down = 10  # greater than iteration, so no ratio update
        test_iltdata.zc_upd = 1.0
        test_iltdata.zc_updmin = 0.2
        test_iltdata.zc_downrate = 0.05
        test_iltdata.zc_max = 1.0

        test_iltdata.zc_nmax = 3 * np.ones((test_iltdata._ndim**2), dtype=np.int32)
        test_iltdata.idx = [[0, 0], [1, 1], [0, 1], [1, 0]]
        test_iltdata.Delta_Q = [1.0, 1.0, 1.0, 1.0]
        test_iltdata.alpha_d = np.array([1.0, 1.0, 1.0, 1.0])
        test_iltdata.g_red = [np.ones(9) for _ in range(4)]
        test_iltdata.Cz = [np.zeros(9) for _ in range(4)]
        test_iltdata.CSq_inv = [np.ones(9) for _ in range(4)]

        # Sms and Pms need 4 matrices (9x9 each)
        test_iltdata.Sms = [spdiags(np.ones(9) * 0.5, 0, (9, 9)) for _ in range(4)]
        test_iltdata.Pms = [spdiags(np.ones(9) * 0.5, 0, (9, 9)) for _ in range(4)]

        zc_pen = zc_reg(test_iltdata, 5)  # iteration > zc_on

        assert issparse(zc_pen)
        assert zc_pen.shape == (9, 9)



