import pytest
import numpy as np
from unittest.mock import patch
from iltpy.input.loader import _load_txt, iltload
from iltpy.fit.inversion import IltData


class TestIltPyInputLoader:
    def test_load_txt_success_1dcase(self, tmp_path):
        """Tests if loading from text files was successful for 1d case."""
        data = np.array([1, 2, 3, 4, 5])
        dim1 = np.array([0.1, 0.2, 0.3, 0.4, 0.5])
        np.savetxt(tmp_path / "data.txt", data)
        np.savetxt(tmp_path / "dim1.txt", dim1)

        iltdata = _load_txt(str(tmp_path))

        assert type(iltdata) is IltData
        assert iltdata.data is not None
        assert iltdata.t is not None

        assert isinstance(iltdata.t, list)
        assert len(iltdata.t) > 0

        np.testing.assert_almost_equal(data, iltdata.data)
        np.testing.assert_almost_equal(dim1, iltdata.t[0].flatten())

    def test_load_txt_error_1dcase(self, tmp_path):
        """Tests if ValueError is raised when data and dim1 have mismatched lengths in 1d case."""
        data = np.array([1, 2, 3, 4, 5])
        dim1 = np.array([0.1, 0.2, 0.3, 0.4])
        np.savetxt(tmp_path / "data.txt", data)
        np.savetxt(tmp_path / "dim1.txt", dim1)

        with pytest.raises(ValueError):
            _load_txt(str(tmp_path))

    def test_load_txt_success_2dcase(self, tmp_path):
        """Tests if loading from text files was successful for 2d case."""
        data = np.array([[1.0, 2.0, 3.0], [3.0, 4.0, 5.0]])
        dim1 = np.array([10, 20])
        dim2 = np.array([0.1, 0.2, 0.3])

        np.savetxt(tmp_path / "data.txt", data)
        np.savetxt(tmp_path / "dim1.txt", dim1)
        np.savetxt(tmp_path / "dim2.txt", dim2)

        iltdata = _load_txt(str(tmp_path))

        assert type(iltdata) is IltData
        assert iltdata.data is not None
        assert iltdata.t is not None

        assert isinstance(iltdata.t, list)
        assert len(iltdata.t) > 1

        np.testing.assert_almost_equal(data, iltdata.data)
        np.testing.assert_almost_equal(dim1, iltdata.t[0].flatten())
        np.testing.assert_almost_equal(dim2, iltdata.t[1].flatten())

    def test_load_txt_error_2dcase(self, tmp_path):
        """Tests if ValueError is raised when data and dim2 have mismatched lengths in 2d case."""
        data = np.array([[1.0, 2.0, 3.0], [3.0, 4.0, 5.0]])
        dim1 = np.array([10, 20])
        dim2 = np.array([0.1, 0.2])

        np.savetxt(tmp_path / "data.txt", data)
        np.savetxt(tmp_path / "dim1.txt", dim1)
        np.savetxt(tmp_path / "dim2.txt", dim2)

        with pytest.raises(ValueError):
            _load_txt(str(tmp_path))

    def test_load_txt_dim2absent_2dcase(self, tmp_path):
        """Tests if ValueError is raised when dim2 is missing for 2d data."""
        data = np.array([[1.0, 2.0, 3.0], [3.0, 4.0, 5.0]])
        dim1 = np.array([10, 20])

        np.savetxt(tmp_path / "data.txt", data)
        np.savetxt(tmp_path / "dim1.txt", dim1)

        with pytest.raises(ValueError):
            _load_txt(str(tmp_path))

    def test_iltload_no_args_error(self):
        """Tests if ValueError is raised when neither data_path nor data and t are provided."""
        with pytest.raises(
            ValueError,
            match="Either the `data_path` or both `data` and `t` must be provided.",
        ):
            iltload()

    def test_iltload_invalid_t_type_error(self):
        """Tests if TypeError is raised when t parameter has invalid type."""
        with pytest.raises(TypeError):
            iltload(data=np.array([1, 2, 3]), t="NOT_AN_ARRAY")

        with pytest.raises(TypeError):
            iltload(
                data=np.array([[1.0, 2.0, 3.0], [3.0, 4.0, 5.0]]),
                t=[np.array([10, 20]), "NOT_AN_ARRAY"],
            )

    def test_iltload_invalid_datapath_error(self, tmp_path):
        """Tests if FileNotFoundError is raised when data_path is invalid or files are missing."""
        with pytest.raises(FileNotFoundError):
            iltload(data_path="INVALID_DATAPATH")
        with pytest.raises(FileNotFoundError):
            iltload(data_path=tmp_path)  # path exists, but files do not

    def test_iltload_data_t_given(self):
        """Tests if iltload correctly loads data when data and t arrays are provided."""
        data_test = np.array([1, 2, 3, 4, 5])
        t_test = np.array([0.1, 0.2, 0.3, 0.4, 0.5])

        iltdata = iltload(data=data_test, f=t_test)

        assert type(iltdata) is IltData
        assert iltdata.data is not None
        assert iltdata.t is not None

        assert isinstance(iltdata.t, list)
        assert len(iltdata.t) > 0

        np.testing.assert_almost_equal(data_test, iltdata.data)
        np.testing.assert_almost_equal(t_test, iltdata.t[0])

    def test_iltload_f_given(self):
        """Tests if iltload correctly loads data when data and f arrays are provided."""
        data_test = np.array([1, 2, 3, 4, 5])
        f_test = np.array([0.1, 0.2, 0.3, 0.4, 0.5])

        iltdata = iltload(data=data_test, f=f_test)

        assert type(iltdata) is IltData
        assert iltdata.data is not None
        assert iltdata.t is not None

        assert isinstance(iltdata.t, list)
        assert len(iltdata.t) > 0

        np.testing.assert_almost_equal(data_test, iltdata.data)
        np.testing.assert_almost_equal(f_test, iltdata.t[0])

    def test_iltload_t_f_both_given(self):
        """Tests if t parameter takes priority over f when both are provided."""
        data_test = np.array([1, 2, 3, 4, 5])
        f_test = np.array([0.1, 0.2, 0.3, 0.4, 0.5])
        t_test = f_test * 2

        iltdata = iltload(data=data_test, f=f_test, t=t_test)  # t should be prioritized

        assert type(iltdata) is IltData
        assert iltdata.data is not None
        assert iltdata.t is not None

        assert isinstance(iltdata.t, list)
        assert len(iltdata.t) > 0

        np.testing.assert_almost_equal(data_test, iltdata.data)
        np.testing.assert_almost_equal(t_test, iltdata.t[0])

    @patch("iltpy.input.loader._load_txt")
    def test_iltload_datapath_given(self, mock_load_txt, tmp_path):
        """Tests if _load_txt is called when data_path is given"""
        data = np.array([1, 2, 3, 4, 5])
        dim1 = np.array([0.1, 0.2, 0.3, 0.4, 0.5])
        np.savetxt(tmp_path / "data.txt", data)
        np.savetxt(tmp_path / "dim1.txt", dim1)

        iltload(data_path=str(tmp_path))

        mock_load_txt.assert_called_once_with(str(tmp_path))

    @patch("iltpy.input.loader._load_txt")
    def test_iltload_datapath_data_t_given(self, mock_load_txt, tmp_path):
        """Tests if data_path is prioritized and _load_txt is called when all args are given"""
        data = np.array([1, 2, 3, 4, 5])
        dim1 = np.array([0.1, 0.2, 0.3, 0.4, 0.5])
        np.savetxt(tmp_path / "data.txt", data)
        np.savetxt(tmp_path / "dim1.txt", dim1)

        iltload(data_path=str(tmp_path), data=data, t=dim1)

        mock_load_txt.assert_called_once_with(str(tmp_path))