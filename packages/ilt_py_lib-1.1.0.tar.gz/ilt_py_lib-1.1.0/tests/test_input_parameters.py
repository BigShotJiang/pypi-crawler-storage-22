import pytest
import re
import numpy as np
from unittest.mock import patch
from iltpy.fit.kernels import IltKernel, Exponential, Identity, Gaussian
from iltpy.fit.inversion import IltData
from iltpy.input.parameters import (
    _validate_data_t,
    _init_dim_attr,
    _get_default_fit_parameters,
    set_parameters,
    _reinitialize_iltdata,
    init_fit_dict,
    _update_fit_dict,
    init_parameters,
    _init_kernel,
    _init_compress,
    _init_base_tau,
    _init_s,
    _init_tau,
    _init_t,
    _validate_t_tau,
    _extend_dims,
    _init_alpha_terms,
    _init_static_baseline,
    _init_g_guess,
    _init_sigma,
)
from copy import deepcopy



class TestIltPyInputParameters:
    def test_validate_data_t_squeeze(self, dummy_data_dict):
        """Tests _validate_data_t squeezes 2D with singleton dimensions data back to 1D."""
        test_iltdata = IltData(
            dummy_data_dict
        )  # IltData already calls _validate_data_t during init
        test_iltdata.data = np.atleast_2d(
            test_iltdata.data
        )  # reshape iltdata.data for testing
        _validate_data_t(iltdata=test_iltdata)  # should squeeze it back
        assert test_iltdata.data.shape == (5,)

    def test_validate_data_t_userspect_1dcase(self, dummy_data_dict):
        """Tests _user_t_spec is True for all dimensions in 1D case."""
        test_iltdata = IltData(
            dummy_data_dict
        )  # 1d data, all t should be user specified.
        assert all(test_iltdata._user_t_spec) is True

    def test_validate_data_t_userspect_2dcase(self, dummy_data_dict):
        """Tests _user_t_spec is False for unspecified dimensions in 2D case."""
        dummy_data_dict["data"] = np.array([[1, 2, 3], [4, 5, 6]])
        dummy_data_dict["dims"] = [np.array([0.1, 0.2])]

        test_iltdata = IltData(dummy_data_dict)  # 2d data with t not specified
        assert all(test_iltdata._user_t_spec) is False

    def test_validate_data_t_unspecified_2dcase(self, dummy_data_dict):
        """Tests auto-generated t for unspecified dimension is linearly spaced."""
        dummy_data_dict["data"] = np.array([[1, 2, 3], [4, 5, 6]])
        dummy_data_dict["dims"] = [np.array([0.1, 0.2])]

        test_iltdata = IltData(dummy_data_dict)  # 2d data with t not specified
        # iltpy generated t in second dimension should be linearly spaced array
        np.testing.assert_array_almost_equal(
            test_iltdata.t[1], np.arange(1, dummy_data_dict["data"].shape[1] + 1)
        )

    def test_validate_data_t_err(self, dummy_data_dict):
        """Tests _validate_data_t raises ValueError when t size shows a mismatch with data shape."""
        dummy_data_dict["data"] = np.array([[1, 2, 3], [4, 5, 6]])
        dummy_data_dict["dims"] = [np.array([0.1, 0.2])]

        test_iltdata = IltData(dummy_data_dict)  # 2d data with t not specified
        test_iltdata.t[1] = np.arange(1, 10)  # change size of input sampling
        with pytest.raises(ValueError):
            _validate_data_t(test_iltdata)

    def _test_get_default_parameters(self):
        """Tests _get_default_fit_parameters returns a dictionary."""
        test_dict = _get_default_fit_parameters()

        assert isinstance(test_dict, dict)

    def test_init_dim_attr(self, dummy_data_dict):
        """Tests _init_dim_attr sets Nt, _ndim, and idx attributes correctly."""
        test_iltdata = IltData(dummy_data_dict)
        _init_dim_attr(test_iltdata)

        assert hasattr(test_iltdata, "Nt")
        assert hasattr(test_iltdata, "_ndim")
        assert hasattr(test_iltdata, "idx")
        assert isinstance(test_iltdata.Nt, tuple)
        assert test_iltdata.Nt == dummy_data_dict["data"].shape
        assert isinstance(test_iltdata._ndim, int)
        assert test_iltdata._ndim == len(np.squeeze(dummy_data_dict["data"]).shape)

    @patch("iltpy.input.parameters._reinitialize_iltdata")
    def test_init_fit_dict_initialized_true(
        self, mock_reinitialize_iltdata, dummy_data_dict, dummy_fit_dict
    ):
        """
        Test if _reinitialize_iltdata is called when iltdata is already initialized and init_fit_dict is used.
        """

        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = True

        mock_reinitialize_iltdata.return_value = dummy_fit_dict

        test_fit_dict = init_fit_dict(
            test_iltdata,
            parameters=None,
            kernel=None,
            tau=None,
            dim_ndim=None,
            sigma=None,
            g_guess=None,
            reinitialize=False,  # this arg is used for _reinitialize_iltdata
        )

        mock_reinitialize_iltdata.assert_called_once()
        assert dummy_fit_dict == test_fit_dict

    @patch("iltpy.input.parameters._get_default_fit_parameters")
    def test_init_fit_dict_initialized_false(
        self, mock_get_default_fit_parameters, dummy_data_dict, dummy_fit_dict
    ):
        """
        Test if _get_default_fit_parameters is called iltdata._initialized is False
        """
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False

        mock_get_default_fit_parameters.return_value = dummy_fit_dict

        test_fit_dict = init_fit_dict(
            test_iltdata,
            parameters=None,
            kernel=None,
            tau=None,
            dim_ndim=None,
            sigma=None,
            g_guess=None,
            reinitialize=False,
        )

        mock_get_default_fit_parameters.assert_called_once()
        assert dummy_fit_dict == test_fit_dict

    @patch("iltpy.input.parameters._update_fit_dict")
    @patch("iltpy.input.parameters._get_default_fit_parameters")
    def test_init_fit_dict_user_parameters(
        self,
        mock_get_default_fit_parameters,
        mock_update_fit_dict,
        dummy_data_dict,
        dummy_fit_dict,
    ):
        """
        Test if _update_parameters is called when parameters is not None
        _get_default_fit_parameters should also be called since iltdata._initialized is set to False
        """
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False

        mock_get_default_fit_parameters.return_value = dummy_fit_dict

        user_parameters = {"alpha_00": 1000}

        mock_update_fit_dict.return_value = user_parameters

        _ = init_fit_dict(
            test_iltdata,
            parameters=user_parameters,
            kernel=None,
            tau=None,
            dim_ndim=None,
            sigma=None,
            g_guess=None,
            reinitialize=False,
        )

        mock_get_default_fit_parameters.assert_called_once()
        mock_update_fit_dict.assert_called_once()

    @patch("iltpy.input.parameters._get_default_fit_parameters")
    def test_init_fit_dict_keyword_parameters(
        self, mock_get_default_fit_parameters, dummy_data_dict, dummy_fit_dict
    ):
        """
        Test if keyword parameters are updated even if parameters keyword is None
        _get_default_fit_parameters should also be called since iltdata._initialized is set to False
        """

        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False

        mock_get_default_fit_parameters.return_value = dummy_fit_dict

        test_tau = np.logspace(1, 100, 10)
        test_dim_ndim = np.arange(1, 5)
        test_sigma = np.arange(1, 10)
        test_g_guess = np.arange(1, 15)

        test_fit_dict = init_fit_dict(
            test_iltdata,
            parameters=None,
            kernel=IltKernel(),
            tau=test_tau,
            dim_ndim=test_dim_ndim,
            sigma=test_sigma,
            g_guess=test_g_guess,
            reinitialize=False,
        )

        mock_get_default_fit_parameters.assert_called_once()

        assert isinstance(test_fit_dict["kernel"], IltKernel)
        np.testing.assert_almost_equal(test_fit_dict["tau"], test_tau)
        np.testing.assert_almost_equal(test_fit_dict["dim_ndim"], test_dim_ndim)
        np.testing.assert_almost_equal(test_fit_dict["sigma"], test_sigma)
        np.testing.assert_almost_equal(test_fit_dict["g_guess"], test_g_guess)

    @patch("iltpy.input.parameters._get_default_fit_parameters")
    @patch("iltpy.input.parameters.set_parameters")
    def test_reinitialize_iltdata_calls_helpers(
        self,
        mock_set_parameters,
        mock_get_default_fit_parameters,
        dummy_data_dict,
        dummy_fit_dict,
    ):
        """
        Tests if _reinitialize_iltdata calls internal functions
        : set_parameters and  _get_default_fit_parameters when reintialize is set to True"""

        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        mock_get_default_fit_parameters.return_value = dummy_fit_dict
        test_iltdata.fit_dict = dummy_fit_dict

        # reinitialize with true should call _get_default_fit_parameters and set_parameters
        _reinitialize_iltdata(test_iltdata, reinitialize=True)
        mock_get_default_fit_parameters.assert_called_once()
        mock_set_parameters.assert_called_once()

    @patch("iltpy.input.parameters._get_default_fit_parameters")
    def test_reinitialize_iltdata_false(
        self, mock_get_default_fit_parameters, dummy_data_dict, dummy_fit_dict
    ):
        """
        Tests if a changed fit dict is maintained when reintialize is False
        """

        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        mock_get_default_fit_parameters.return_value = dummy_fit_dict

        changed_fit_dict = deepcopy(dummy_fit_dict)
        changed_fit_dict["alpha_00"] = 100000000000
        changed_fit_dict["alpha_nn"] = 100000000000

        test_iltdata.fit_dict = changed_fit_dict

        # reinitialize with false should give iltdata's fit dict back and not the default fit dict
        assert dummy_fit_dict != changed_fit_dict  ## sanity check
        assert changed_fit_dict == _reinitialize_iltdata(
            test_iltdata, reinitialize=False
        )
        assert (
            _reinitialize_iltdata(test_iltdata, reinitialize=False)["alpha_00"]
            == 100000000000
        )
        assert (
            _reinitialize_iltdata(test_iltdata, reinitialize=False)["alpha_nn"]
            == 100000000000
        )

    @patch("iltpy.input.parameters._get_default_fit_parameters")
    def test_reinitialize_iltdata_true(
        self, mock_get_default_fit_parameters, dummy_data_dict, dummy_fit_dict
    ):
        """
        Tests if a changed fit dict is maintained when reintialize is False
        """

        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        mock_get_default_fit_parameters.return_value = dummy_fit_dict

        changed_fit_dict = deepcopy(dummy_fit_dict)
        changed_fit_dict["alpha_00"] = 100000000000
        changed_fit_dict["alpha_nn"] = 100000000000

        test_iltdata.fit_dict = changed_fit_dict

        # reinitialize with true should give default fit dict back
        assert dummy_fit_dict != changed_fit_dict
        assert dummy_fit_dict == _reinitialize_iltdata(test_iltdata, reinitialize=True)

    @patch("iltpy.input.parameters._read_parameter_file")
    def test_update_fit_dict_calls_helpers(
        self, mock_read_parameter_file, dummy_fit_dict, tmp_path
    ):
        """
        Tests if update_fit_dict calls _read_parameter_file if parameters argument is of type str (parameter file)
        """
        mock_read_parameter_file.return_value = dummy_fit_dict
        _update_fit_dict(parameters=str(tmp_path), fit_dict=dummy_fit_dict)

        mock_read_parameter_file.assert_called_once()

    def test_update_fit_dict_err(self, dummy_fit_dict):
        """Tests _update_fit_dict raises KeyError for invalid parameter names."""
        with pytest.raises(KeyError):
            _update_fit_dict(
                parameters={"alpha_00": 100, "INVALID_PARAMETER": "INVALID_VALUE"},
                fit_dict=dummy_fit_dict,
            )

    def test_update_fit_dict_parameter_update(self, dummy_fit_dict):
        """Tests _update_fit_dict correctly updates fit_dict with user parameters."""
        test_parameters = {"alpha_00": 1000000000, "alpha_nn": 1000000000}
        test_default_dict = deepcopy(dummy_fit_dict)
        test_dict = _update_fit_dict(
            parameters=test_parameters, fit_dict=test_default_dict
        )

        assert test_dict["alpha_00"] != dummy_fit_dict["alpha_00"]
        assert test_dict["alpha_00"] == test_parameters["alpha_00"]
        assert test_dict["alpha_nn"] == test_parameters["alpha_nn"]

    def test_set_parameters(self, dummy_data_dict):
        """Tests set_parameters sets all fit_dict keys as IltData attributes."""
        test_iltdata = IltData(dummy_data_dict)
        fit_dict = _get_default_fit_parameters()

        set_parameters(test_iltdata, fit_dict)

        for parameter in fit_dict:
            assert hasattr(test_iltdata, parameter)

    @pytest.mark.parametrize(
        "ndim, g_guess_in, sigma_in, reg_bc_in, sb_in, base_tau_in, expected_Nx, expected_Nxtot, expected_reg_bc",
        [
            (
                1,
                np.arange(9),
                np.arange(9),
                1,
                [True],
                [0],
                np.array([11]),
                np.array([11]),
                np.array([1]),
            ),
            (
                1,
                None,
                None,
                None,
                [False],
                [1],
                np.array([10]),
                np.array([10]),
                np.array([2]),
            ),  # 1d case with g_guess,sigma None
            (
                2,
                np.ones((5, 5)),
                np.ones((5, 5)),
                1,
                [True, False],
                [1, 1],
                np.array([11, 10]),
                np.array([11 * 10]),
                np.array([1, 1]),
            ),  # 2d case
            (
                2,
                np.ones((5, 5)),
                np.ones((5, 5)),
                1,
                [True, True],
                [1, 1],
                np.array([11, 11]),
                np.array([11 * 11]),
                np.array([1, 1]),
            ),  # sb is True in both dims
            (
                2,
                np.ones((5, 5)),
                np.ones((5, 5)),
                None,
                [True, True],
                [0, 1],
                np.array([11, 11]),
                np.array([11 * 11]),
                np.array([0, 2]),
            ),  # reg_bc is None, base_tau 0,1
        ],
    )
    @patch("iltpy.input.parameters._init_kernel")
    @patch("iltpy.input.parameters._init_compress")
    @patch("iltpy.input.parameters._init_base_tau")
    @patch("iltpy.input.parameters._init_s")
    @patch("iltpy.input.parameters._init_t")
    @patch("iltpy.input.parameters._init_tau")
    @patch("iltpy.input.parameters._validate_t_tau")
    @patch("iltpy.input.parameters._init_static_baseline")
    @patch("iltpy.input.parameters._init_g_guess")
    @patch("iltpy.input.parameters._init_sigma")
    @patch("iltpy.input.parameters._init_alpha_terms")
    @patch("iltpy.input.parameters._extend_dims")
    def test_init_parameters(
        self,
        mock_extend_dims,
        mock_init_alpha_terms,
        mock_init_sigma,
        mock_init_g_guess,
        mock_init_static_baseline,
        mock_validate_t_tau,
        mock_init_tau,
        mock_init_t,
        mock_init_s,
        mock_init_base_tau,
        mock_init_compress,
        mock_init_kernel,
        dummy_data_dict,
        ndim,
        g_guess_in,
        sigma_in,
        reg_bc_in,
        sb_in,
        base_tau_in,
        expected_Nx,
        expected_Nxtot,
        expected_reg_bc,
    ):
        """
        Test init parameters when parameters such as g_guess, sb, reg_bc, sigma are given.
        This test also checks if the helper functions are called.
        """

        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata.reg_bc = reg_bc_in
        tau = np.logspace(1, 10, 10)
        test_iltdata.tau = [tau] * ndim
        test_iltdata.t = [np.arange(5)] * ndim
        test_iltdata.g_guess = g_guess_in
        test_iltdata.sigma = sigma_in
        test_iltdata.sb = sb_in
        test_iltdata.base_tau = base_tau_in
        test_iltdata._ndim = ndim
        test_iltdata.c_nmax = 5
        test_iltdata.p_nmax = 5
        test_iltdata.zc_nmax = 5
        test_iltdata.Cz = [np.array([0])]
        expected_Delta_Q = [
            (np.log(arr.flatten()[-1]) - np.log(arr.flatten()[-2]))
            if base_tau_in[idx] != 0
            else (arr.flatten()[-1] - arr.flatten()[-2]) * np.log(10)
            for idx, arr in enumerate(test_iltdata.tau)
        ]

        init_parameters(test_iltdata)

        if g_guess_in is None:
            mock_init_g_guess.assert_not_called()
        else:
            mock_init_g_guess.assert_called_once()

        if sigma_in is None:
            mock_init_sigma.assert_not_called()
        else:
            mock_init_sigma.assert_called_once()

        for func in [
            mock_extend_dims,
            mock_init_alpha_terms,
            mock_init_static_baseline,
            mock_validate_t_tau,
            mock_init_tau,
            mock_init_t,
            mock_init_s,
            mock_init_base_tau,
            mock_init_compress,
            mock_init_kernel,
        ]:
            func.assert_called_once()

        assert test_iltdata.c_nmax.dtype == np.int32
        assert test_iltdata.p_nmax.dtype == np.int32
        assert test_iltdata.zc_nmax.dtype == np.int32
        assert test_iltdata.t[0].shape == (1, 5)  # should be reshaped during init
        assert test_iltdata.tau[0].shape == (10, 1)  # should be reshaped during init
        if ndim > 1:
            assert test_iltdata.t[1].shape == (1, 5)  # should be reshaped during init
            assert test_iltdata.tau[1].shape == (
                10,
                1,
            )  # should be reshaped during init

        assert hasattr(test_iltdata, "Nx0")
        assert hasattr(test_iltdata, "Nx0tot")
        assert hasattr(test_iltdata, "Ntau")
        assert hasattr(test_iltdata, "Nx")
        assert hasattr(test_iltdata, "Nxtot")

        np.testing.assert_almost_equal(test_iltdata.Nx0, np.array([10] * ndim))
        np.testing.assert_almost_equal(test_iltdata.Nx0tot, np.array([10**ndim]))
        np.testing.assert_almost_equal(test_iltdata.Ntau, np.array([10**ndim]))
        np.testing.assert_almost_equal(test_iltdata.Nx, expected_Nx)
        np.testing.assert_almost_equal(test_iltdata.Nxtot, expected_Nxtot)
        np.testing.assert_almost_equal(test_iltdata.reg_bc, expected_reg_bc)
        assert test_iltdata.Delta_Q == expected_Delta_Q

        np.testing.assert_almost_equal(test_iltdata.Cz, [np.array([0])] * ndim**2)
        np.testing.assert_almost_equal(test_iltdata.c_nmax, np.array([5] * ndim))
        np.testing.assert_almost_equal(test_iltdata.p_nmax, np.array([5] * ndim))
        np.testing.assert_almost_equal(test_iltdata.zc_nmax, np.array([5] * ndim))

    @pytest.mark.parametrize("kernel_in", [(IltKernel()), (Identity())])
    def test_init_kernel_err(self, kernel_in, dummy_data_dict, dummy_kernel_dict):
        """Tests _init_kernel raises ValueError when kernel is not a list for multi-dimensional data."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata.kernel = kernel_in
        test_iltdata._ndim = 1

        with pytest.raises(ValueError):
            _init_kernel(test_iltdata, dummy_kernel_dict)

    def test_init_kernel_user_defined_err(self, dummy_data_dict, dummy_kernel_dict):
        """Tests _init_kernel raises TypeError when kernel is not an IltKernel instance."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 1

        class UserDefinedIltKernel:  # not derived from IltKernel
            def __init__(self):
                super().__init__()
                self._name = "kernel_name"
                self._kernel = lambda t, tau: np.eye(t.size)
                self._kernel_str = "lambda t, tau: np.eye(t.size)"

        test_iltdata.kernel = UserDefinedIltKernel()
        with pytest.raises(TypeError, match="kernel must be an instance of IltKernel"):
            _init_kernel(test_iltdata, dummy_kernel_dict)

    def test_init_kernel_as_list(self, dummy_data_dict, dummy_kernel_dict):
        """
        Tests if kernel parameter is converted to a list
        """

        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 1
        test_iltdata.kernel = Exponential()

        _init_kernel(test_iltdata, dummy_kernel_dict)

        assert isinstance(test_iltdata.kernel, list)
        assert test_iltdata.kernel[0].name == "_exponential_"

    def test_init_kernel_2d_case_unspecified(self, dummy_data_dict, dummy_kernel_dict):
        """
        Tests if identity kernel is chosen if unspecified
        """

        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 2
        test_iltdata.kernel = Exponential()

        _init_kernel(test_iltdata, dummy_kernel_dict)

        assert isinstance(test_iltdata.kernel, list)
        assert test_iltdata.kernel[0].name == "_exponential_"
        assert len(test_iltdata.kernel) > 1
        assert (
            test_iltdata.kernel[1].name == "_identity_"
        )  # identity should be filled in unspecified dimensions

    def test_init_kernel_2d_case_specified(self, dummy_data_dict, dummy_kernel_dict):
        """
        Tests if kernel is respected if specified.
        """

        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 2
        test_iltdata.kernel = [Exponential(), Exponential()]

        _init_kernel(test_iltdata, dummy_kernel_dict)

        assert isinstance(test_iltdata.kernel, list)
        assert test_iltdata.kernel[0].name == "_exponential_"
        assert len(test_iltdata.kernel) > 1
        assert test_iltdata.kernel[1].name == "_exponential_"

    def test_init_kernel_from_str(self, dummy_data_dict, dummy_kernel_dict):
        """Tests _init_kernel correctly initializes kernel from string name."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 1
        test_iltdata.kernel = "_exponential_"

        _init_kernel(test_iltdata, dummy_kernel_dict)

        assert isinstance(test_iltdata.kernel, list)
        assert isinstance(test_iltdata.kernel[0], IltKernel)
        assert test_iltdata.kernel[0].name == "_exponential_"

    def test_init_kernel_from_str_err(self, dummy_data_dict, dummy_kernel_dict):
        """Tests _init_kernel raises ValueError for unknown kernel string name."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 1
        test_iltdata.kernel = "_NOT_A_DEFINED_KERNEL"

        with pytest.raises(ValueError):
            _init_kernel(test_iltdata, dummy_kernel_dict)

    def test_init_compress_as_list(self, dummy_data_dict):
        """Tests _init_compress is a list with default value as False."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 1
        test_iltdata.compress = False

        _init_compress(test_iltdata)

        assert isinstance(test_iltdata.compress, list)
        assert test_iltdata.compress[0] is False

    def test_init_compress_err(self, dummy_data_dict):
        """Tests _init_compress raises TypeError for invalid type."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 1
        test_iltdata.compress = 1

        with pytest.raises(TypeError):
            _init_compress(test_iltdata)

    def test_init_compress_2d_case_unspecified(self, dummy_data_dict):
        """Tests _init_compress extends list for 2D with False for unspecified dimensions."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 2
        test_iltdata.compress = True

        _init_compress(test_iltdata)

        assert isinstance(test_iltdata.compress, list)
        assert test_iltdata.compress[0] is True
        assert len(test_iltdata.compress) > 1
        assert test_iltdata.compress[1] is False

    def test_init_base_tau_err(self, dummy_data_dict, dummy_kernel_dict):
        """Tests _init_base_tau raises TypeError for invalid base_tau type."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 1
        test_iltdata.kernel = Exponential()
        test_iltdata.base_tau = True

        with pytest.raises(TypeError):
            _init_base_tau(test_iltdata, dummy_kernel_dict)

    def test_init_base_tau_as_list(self, dummy_data_dict, dummy_kernel_dict):
        """Tests _init_base_tau converts scalar base_tau to list."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 1
        test_iltdata.base_tau = 1
        test_iltdata.kernel = [Exponential()]
        test_iltdata.compress = [False]

        _init_base_tau(test_iltdata, dummy_kernel_dict)

        assert isinstance(test_iltdata.base_tau, list)
        assert test_iltdata.base_tau[0] == 1

    def test_init_base_tau_linear_kernel(self, dummy_data_dict, dummy_kernel_dict):
        """Tests if base_tau and compress are corrected if a linear kernel is given."""

        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 1
        test_iltdata.base_tau = 1
        test_iltdata.kernel = [Identity()]
        test_iltdata.compress = [True]

        _init_base_tau(test_iltdata, dummy_kernel_dict)

        assert isinstance(test_iltdata.base_tau, list)
        assert test_iltdata.base_tau[0] == 0
        assert test_iltdata.compress[0] is False

    def test_init_base_tau_log_kernel(self, dummy_data_dict, dummy_kernel_dict):
        """Tests if base_tau are set correctly if a log kernel is given."""

        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 1
        test_iltdata.base_tau = 0
        test_iltdata.kernel = [Exponential()]
        test_iltdata.compress = [True]

        _init_base_tau(test_iltdata, dummy_kernel_dict)

        assert isinstance(test_iltdata.base_tau, list)
        assert test_iltdata.base_tau[0] == 1

    def test_init_base_tau_2d_case_unspecified(
        self, dummy_data_dict, dummy_kernel_dict
    ):
        """Tests _init_base_tau sets correct values for 2D with mixed kernel types."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 2
        test_iltdata.base_tau = 0
        test_iltdata.kernel = [Exponential(), Identity()]
        test_iltdata.compress = [True, True]

        _init_base_tau(test_iltdata, dummy_kernel_dict)

        assert isinstance(test_iltdata.base_tau, list)
        assert test_iltdata.base_tau[0] == 1  # log based kernel
        assert len(test_iltdata.base_tau) > 1
        assert (
            test_iltdata.base_tau[1] == 0
        )  # linear kernel, automatically extended to match dimension.

    def test_init_s_as_list(self, dummy_data_dict):
        """Tests _init_s converts scalar s to list."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 1
        test_iltdata.base_tau = 0
        test_iltdata.kernel = [Exponential()]
        test_iltdata.compress = [True]
        test_iltdata.s = 10
        test_iltdata.Nt = test_iltdata.data.shape

        _init_s(test_iltdata)

        assert isinstance(test_iltdata.s, list)

    def test_init_s_2d_case(self, dummy_data_dict):
        """Tests _init_s extends s list for 2D case."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 2
        test_iltdata.compress = [True, True]
        test_iltdata.s = 5
        test_iltdata.data = np.ones((30, 30))
        test_iltdata.Nt = test_iltdata.data.shape

        _init_s(test_iltdata)

        assert isinstance(test_iltdata.s, list)
        assert len(test_iltdata.s) > 1
        assert test_iltdata.s == [5, 5]

    def test_init_s_as_err(self, dummy_data_dict):
        """Tests _init_s raises TypeError for invalid s type."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 1
        test_iltdata.compress = [True]
        test_iltdata.s = "1"
        test_iltdata.Nt = test_iltdata.data.shape

        with pytest.raises(TypeError):
            _init_s(test_iltdata)

    @pytest.mark.parametrize(
        "ndim,compress_in,s_in,nt_in,expected_s",
        [
            (1, [True], 5, (10,), [5]),  # compress true, s<Nt, s would remain same.
            (1, [False], 5, (10,), [10]),  # compress false, s would be Nt
            (1, [True], 15, (10,), [10]),  # s>Nt, s would be Nt
            (2, [True, True], 15, (10, 10), [10, 10]),  # s>Nt for 2d case
            (
                2,
                [True, False],
                5,
                (10, 10),
                [5, 10],
            ),  # compress true,false, s would s,Nt
            (2, [True, True], 5, (10, 10), [5, 5]),
        ],
    )  #  compress true,true and s<Nt.
    def test_init_s_different_inputs(
        self, ndim, compress_in, s_in, nt_in, expected_s, dummy_data_dict
    ):
        """Tests _init_s handles various combinations of compress, s, and Nt values correctly."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = ndim
        test_iltdata.compress = compress_in
        test_iltdata.s = s_in
        test_iltdata.Nt = nt_in

        _init_s(test_iltdata)

        assert test_iltdata.s == expected_s

    def test_init_t_not_given(self, dummy_data_dict):
        """
        Test if value error is raised if t is not specified for a dim
        which has base_tau!=0
        """
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 2
        test_iltdata.data = np.ones((5, 5))
        test_iltdata.base_tau = [1, 1]
        test_iltdata._user_t_spec = [True, False]

        with pytest.raises(ValueError):
            _init_t(test_iltdata)

    def test_init_t_size_mismatch(self, dummy_data_dict):
        """
        Test if value error is raised if t is not specified for a dim
        which has base_tau!=0
        """
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 2
        test_iltdata.data = np.ones((5, 5))
        test_iltdata.t = [np.arange(5), np.arange(6)]
        test_iltdata.base_tau = [1, 1]
        test_iltdata._user_t_spec = [True, True]

        error_match = f"Length of t[1]: {test_iltdata.t[1].size} does not match data.shape[1]: {test_iltdata.data.shape[1]}."

        with pytest.raises(ValueError, match=re.escape(error_match)):
            _init_t(test_iltdata)

    def test_init_t_dim_ndim_err(self, dummy_data_dict):
        """Tests _init_t raises ValueError when dim_ndim size doesn't match data shape."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 2
        test_iltdata.data = np.ones((5, 5))
        test_iltdata.base_tau = [1, 0]
        test_iltdata._user_t_spec = [True, False]
        test_iltdata.dim_ndim = np.arange(
            7
        )  # will fail since doesnt match size of data in second dim.

        error_match = f"""Length of array in dimension {test_iltdata._ndim - 1} : {max(test_iltdata.dim_ndim.shape)} 
                    does not match size of data in dimension {test_iltdata._ndim - 1} : {test_iltdata.data.shape[-1]}"""

        with pytest.raises(ValueError, match=re.escape(error_match)):
            _init_t(test_iltdata)

    def test_init_t_dim_ndim_given(self, dummy_data_dict):
        """
        Test if t[-1] is replaced by dim_ndim
        """

        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 2
        test_iltdata.data = np.ones((5, 5))
        test_iltdata.base_tau = [1, 0]
        test_iltdata._user_t_spec = [True, False]
        test_iltdata.dim_ndim = np.arange(5, 10)
        test_iltdata.t = [
            np.arange(5),
            np.arange(5),
        ]  # t[-1] should be replaced by dim_ndim

        _init_t(test_iltdata)

        np.testing.assert_almost_equal(test_iltdata.t[-1], np.arange(5, 10))

    def test_init_t_dim_ndim_None(self, dummy_data_dict):
        """
        Test if t[-1] is replaced by dim_ndim
        """

        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 2
        test_iltdata.data = np.ones((5, 5))
        test_iltdata.base_tau = [1, 0]
        test_iltdata._user_t_spec = [True, False]
        test_iltdata.dim_ndim = None
        test_iltdata.t = [
            np.arange(5),
            None,
        ]  # t[-1] should be replaced linerly spaced array with size of data in that dim

        _init_t(test_iltdata)

        np.testing.assert_almost_equal(test_iltdata.t[-1], np.arange(1, 6))

    @pytest.mark.parametrize(
        "tau_in,t_in,kernel_in,ndim,expected_tau",
        [
            (None, [np.arange(5)], [Identity()], 1, [np.arange(5)]),
            (
                None,
                [np.arange(5), np.arange(5)],
                [Identity(), Identity()],
                2,
                [np.arange(5), np.arange(5)],
            ),
        ],
    )
    def test_init_tau_None_identity(
        self, tau_in, t_in, kernel_in, ndim, expected_tau, dummy_data_dict
    ):
        """Tests _init_tau sets tau equal to t when tau is None and kernel is Identity."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = ndim
        test_iltdata.kernel = kernel_in
        test_iltdata.t = t_in
        test_iltdata.tau = tau_in

        _init_tau(test_iltdata)

        np.testing.assert_array_almost_equal(test_iltdata.tau, expected_tau)

    @pytest.mark.filterwarnings(r"ignore:tau\[.*\] was not specified")
    @pytest.mark.parametrize(
        "tau_in,t_in,kernel_in,ndim",
        [
            (None, [np.arange(5)], [Exponential()], 1),
            (None, [np.arange(5), np.arange(5)], [Exponential(), Gaussian()], 2),
        ],
    )
    @patch("iltpy.input.parameters._generate_tau")
    def test_init_tau_None_exp(
        self, mock_generate_tau, tau_in, t_in, kernel_in, ndim, dummy_data_dict
    ):
        """Tests _init_tau calls _generate_tau when tau is None and kernel requires log-spaced tau."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = ndim
        test_iltdata.kernel = kernel_in
        test_iltdata.t = t_in
        test_iltdata.tau = tau_in
        mock_generate_tau.return_value = np.arange(5)

        _init_tau(test_iltdata)

        mock_generate_tau.assert_called()

    @patch("iltpy.input.parameters._generate_tau")
    def test_init_tau_warning_1d(self, mock_generate_tau, dummy_data_dict):
        """Tests _init_tau raises UserWarning when tau is not specified for 1D data with log-based kernel."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 1
        test_iltdata.tau = None
        test_iltdata.kernel = [Exponential()]  # triggers warning
        test_iltdata.t = [np.arange(5)]
        mock_generate_tau.return_value = np.arange(5)

        with pytest.warns(UserWarning, match=r"tau\[0\] was not specified"):
            _init_tau(test_iltdata)

    @patch("iltpy.input.parameters._generate_tau")
    def test_init_tau_warning_2d(self, mock_generate_tau, dummy_data_dict):
        """Tests _init_tau raises UserWarnings for each dimension when tau is not specified for 2D data."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 2
        test_iltdata.tau = None
        test_iltdata.kernel = [Exponential(), Gaussian()]
        test_iltdata.t = [np.arange(5), np.arange(5)]

        mock_generate_tau.return_value = np.arange(5)

        with pytest.warns(UserWarning) as record:
            _init_tau(test_iltdata)

        assert len(record) == 2
        assert "tau[0]" in record[0].message.args[0]
        assert "tau[1]" in record[1].message.args[0]

    def test_init_tau_error_1d(self, dummy_data_dict):
        """Tests _init_tau raises ValueError when tau is None and kernel is base IltKernel without specific type."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 1
        test_iltdata.tau = None
        test_iltdata.kernel = [IltKernel()]
        test_iltdata.t = [np.arange(5)]

        with pytest.raises(ValueError):
            _init_tau(test_iltdata)

    def test_init_tau_given_1d(self, dummy_data_dict):
        """Tests _init_tau correctly converts user-provided tau to a list for 1D data."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 1
        test_iltdata.tau = np.logspace(-5, 5, 10)
        test_iltdata.kernel = [IltKernel()]
        test_iltdata.t = [np.arange(5)]

        _init_tau(test_iltdata)
        assert isinstance(test_iltdata.tau, list)

    def test_init_tau_given_err(self, dummy_data_dict):
        """Tests _init_tau raises TypeError when tau is not a numpy array or list of numpy arrays."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 1
        test_iltdata.tau = [[1, 2, 3, 4, 5]]
        test_iltdata.kernel = [IltKernel()]
        test_iltdata.t = [np.arange(5)]

        with pytest.raises(
            TypeError,
            match="tau must be a list of numpy arrays or a single 1D numpy array.",
        ):
            _init_tau(test_iltdata)

        test_iltdata.tau = [1, 2, 3, 4, 5]

        with pytest.raises(TypeError):
            _init_tau(test_iltdata)

    def test_validate_t_tau_t_err(self, dummy_data_dict):
        """Tests _validate_t_tau raises ValueError when t length doesn't match data shape."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 2
        test_iltdata.data = np.ones((5, 5))
        test_iltdata.t = [np.arange(5), np.arange(6)]
        test_iltdata.kernel = [Exponential(), Exponential()]

        error_match = "Length of t: 6 in dimension 1 does not match the length of data: 5 in dimension 1"

        with pytest.raises(ValueError, match=error_match):
            _validate_t_tau(test_iltdata)

    def test_validate_t_tau_tau_err(self, dummy_data_dict):
        """Tests _validate_t_tau raises ValueError when tau length doesn't match data shape for identity kernel."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 2
        test_iltdata.data = np.ones((5, 5))
        test_iltdata.t = [np.arange(5), np.arange(5)]
        test_iltdata.kernel = [Exponential(), Identity()]
        test_iltdata.tau = [np.arange(10), np.arange(7)]

        error_match = "Length of tau: 7 in dimension 1 with identity kernel does not match the length of data: 5 in dimension 1"

        with pytest.raises(ValueError, match=error_match):
            _validate_t_tau(test_iltdata)

    def test_init_static_baseline_err(self, dummy_data_dict):
        """Tests _init_static_baseline raises TypeError for invalid sb type."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 2
        test_iltdata.sb = [1, 0]

        with pytest.raises(TypeError):
            _init_static_baseline(test_iltdata)

    def test_init_static_baseline_1dcase(self, dummy_data_dict):
        """Tests _init_static_baseline converts scalar sb to list for 1D data."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 1
        test_iltdata.sb = True

        _init_static_baseline(test_iltdata)

        assert isinstance(test_iltdata.sb, list)
        assert test_iltdata.sb[0] is True

    def test_init_static_baseline_2dcase(self, dummy_data_dict):
        """Tests _init_static_baseline extends sb list with False for unspecified dimensions in 2D case."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 2
        test_iltdata.sb = True

        _init_static_baseline(test_iltdata)

        assert isinstance(test_iltdata.sb, list)
        assert len(test_iltdata.sb) > 1
        assert test_iltdata.sb[1] is False

    def test_init_g_guess(self, dummy_data_dict):
        """Tests _init_g_guess correctly flattens user-provided g_guess array."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 2
        np.random.default_rng(2505)
        random_g_guess = np.random.randn(10, 8)
        test_iltdata.g_guess = deepcopy(random_g_guess)
        test_iltdata.tau = [np.logspace(-10, 10, 10), np.logspace(-10, 10, 8)]
        test_iltdata.Nx = np.array([len(i) for i in test_iltdata.tau])
        test_iltdata.Nxtot = np.prod(test_iltdata.Nx)

        _init_g_guess(test_iltdata)

        np.testing.assert_array_almost_equal(
            test_iltdata.g_guess, random_g_guess.flatten(order="F")
        )

    def test_init_g_guess_err(self, dummy_data_dict):
        """Tests _init_g_guess raises ValueError when g_guess shape doesn't match tau dimensions."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._initialized = False
        test_iltdata._ndim = 2
        np.random.default_rng(2505)
        random_g_guess = np.random.randn(10, 7)
        test_iltdata.g_guess = deepcopy(random_g_guess)
        test_iltdata.tau = [np.logspace(-10, 10, 10), np.logspace(-10, 10, 8)]
        test_iltdata.Nx = np.array([len(i) for i in test_iltdata.tau])
        test_iltdata.Nxtot = np.prod(test_iltdata.Nx)

        with pytest.raises(ValueError):
            _init_g_guess(test_iltdata)

    def test_sigma_shape_mismatch_raises_error(self, dummy_data_dict):
        """Test that ValueError is raised if sigma shape != Nt."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.data = np.ones((10, 10))
        test_iltdata.Nt = test_iltdata.data.shape
        test_iltdata._ndim = 2
        test_iltdata.sigma = np.ones((5, 5))

        with pytest.raises(
            ValueError, match="Shape of Sigma .* is not equal to data shape"
        ):
            _init_sigma(test_iltdata)

    def test_sigma_no_compression(self, dummy_data_dict):
        """Tests if sigma is unchanged if compress is False."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.Nt = (10, 5)
        test_iltdata._ndim = 2
        np.random.default_rng(2505)
        test_iltdata.sigma = np.random.rand(*test_iltdata.Nt)
        test_iltdata.compress = [False, False]

        _init_sigma(test_iltdata)

        np.testing.assert_array_equal(test_iltdata._Sigma, test_iltdata.sigma)

    def test_sigma_with_compression_1dcase(self, dummy_data_dict):
        """Tests if sigma is calculated correctly when compress is True"""
        test_iltdata = IltData(dummy_data_dict)

        test_iltdata._ndim = 1
        test_iltdata.Nt = (4,)
        test_iltdata.sigma = np.arange(4)
        test_iltdata.compress = [True]
        test_iltdata.s = [2]

        _init_sigma(test_iltdata)

        expected_val = np.sqrt(np.mean(test_iltdata.sigma**2))
        expected_array = np.full((2,), expected_val)

        assert test_iltdata._Sigma.shape == (2,)
        np.testing.assert_allclose(test_iltdata._Sigma, expected_array)

    def test_sigma_with_compression_2dcase(self, dummy_data_dict):
        """Tests if sigma is calculated correctly when compress is True for 2D data"""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 2
        test_iltdata.Nt = (3, 4)

        test_iltdata.sigma = np.ones((3, 4)) * 2.0
        test_iltdata.compress = [False, True]
        test_iltdata.s = [3, 2]

        _init_sigma(test_iltdata)

        assert test_iltdata._Sigma.shape == (3, 2)
        np.testing.assert_allclose(test_iltdata._Sigma, 2.0)

    def test_init_alpha_terms_alphas_given(self, dummy_data_dict):
        """Tests _init_alpha_terms correctly converts scalar alpha values to arrays for each dimension."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 2
        test_iltdata.alpha_0 = 1.0
        test_iltdata.alpha_a = 0.5
        test_iltdata.alpha_bc = 0.1
        test_iltdata.alpha_nn = 0.01
        test_iltdata.alpha_c = 2.0
        test_iltdata.alpha_p = 10.0
        test_iltdata.alpha_d = 0.2
        test_iltdata.compress = [False, False]

        _init_alpha_terms(test_iltdata)

        for attr in [
            "alpha_0",
            "alpha_a",
            "alpha_bc",
            "alpha_nn",
            "alpha_c",
            "alpha_p",
            "alpha_d",
        ]:
            val = getattr(test_iltdata, attr)
            assert isinstance(val, np.ndarray)
            assert len(val) == 2
            assert val[0] == val[1]  # all values are multiplied by np.ones

    def test_init_alpha_terms_alpha_d_p_None(self, dummy_data_dict):
        """Verify alpha_d = 1 / alpha_a when alpha_d is None."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 1
        test_iltdata.alpha_0 = 1.0
        test_iltdata.alpha_a = 0.5
        test_iltdata.alpha_bc = 0.1
        test_iltdata.alpha_nn = 0.01
        test_iltdata.alpha_c = 2.0
        test_iltdata.alpha_p = None
        test_iltdata.alpha_d = None
        test_iltdata.compress = [False]

        _init_alpha_terms(test_iltdata)

        assert test_iltdata.alpha_d[0] == 1 / 0.5  # alpha_d = 1/alphs_a
        assert test_iltdata.alpha_p[0] == 2.0 * 5  # alpha_p = alpha_c * 5

    @pytest.mark.parametrize(
        "ndim, base_tau_in, compress_in, s_in, expected_alpha_c",
        [
            # 1D, base_tau Log, Compress False: 2 * ln(9/8) / 10 * 10 = 0.235...
            (1, [1], [False], [10], np.array([0.235566])),
            # 1D, base_tau Linear, Compress True: 2 * (9-8) / 5 * 10 = 4.0
            (1, [0], [True], [5], np.array([4.0])),
            # 2D, Mixed:
            # pn = (10*(1-0) + 0*5) * (10*(1-1) + 1*5) = 10 * 5 = 50
            # dim0 (Log): 2 * ln(9/8) / 50 * (10*10) = 0.471132
            # dim1 (Lin): 2 * (9-8) / 50 * (10*10) = 4.0
            (2, [1, 0], [False, True], [5, 5], np.array([0.471132, 4.0])),
        ],
    )
    def test_init_alpha_terms_alpha_c(
        self, ndim, base_tau_in, compress_in, s_in, expected_alpha_c, dummy_data_dict
    ):
        """Tests _init_alpha_terms computes alpha_c correctly."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = ndim
        test_iltdata.data = np.zeros([10] * ndim)
        test_iltdata.Ntau = [10] * ndim
        test_iltdata.tau = [np.arange(10)] * ndim

        test_iltdata.base_tau = base_tau_in
        test_iltdata.compress = compress_in
        test_iltdata.s = s_in

        test_iltdata.alpha_c = None
        test_iltdata.alpha_0 = 1.0
        test_iltdata.alpha_a = 1.0
        test_iltdata.alpha_bc = 1.0
        test_iltdata.alpha_nn = 1.0
        test_iltdata.alpha_p = None
        test_iltdata.alpha_d = None

        _init_alpha_terms(test_iltdata)

        np.testing.assert_almost_equal(
            test_iltdata.alpha_c, expected_alpha_c, decimal=5
        )
        np.testing.assert_almost_equal(
            test_iltdata.alpha_p, 5 * expected_alpha_c, decimal=5
        )

    def test_extend_dims_1dcase(self, dummy_data_dict):
        """Tests if dims are not extended for ndim=1"""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 1

        test_iltdata.alpha_0 = np.array([1.0])
        test_iltdata.Delta_Q = [0.5]

        _extend_dims(test_iltdata)

        assert len(test_iltdata.alpha_0) == 1
        assert len(test_iltdata.Delta_Q) == 1

    def test_extend_dims_2dcase(self, dummy_data_dict):
        """Tests _extend_dims correctly extends parameters to ndim^2 for cross-terms in 2D case."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._ndim = 2

        # idx from _generate_idx
        test_iltdata.idx = [[0, 0], [1, 1], [0, 1], [1, 0]]

        # dummy values
        test_iltdata.alpha_0 = np.array([3.0, 4.0])
        test_iltdata.Delta_Q = [3.0, 4.0]
        test_iltdata.reg_bc = np.array([1, 1])
        test_iltdata.c_nmax = np.array([10, 11])
        test_iltdata.p_nmax = np.array([10, 11])
        test_iltdata.zc_nmax = np.array([10, 20])

        test_iltdata.alpha_p = np.array([3.0, 4.0])
        test_iltdata.alpha_c = np.array([3.0, 4.0])
        test_iltdata.alpha_a = np.array([3.0, 4.0])
        test_iltdata.alpha_d = np.array([3.0, 4.0])

        _extend_dims(test_iltdata)

        # ndim**2 = 4
        assert len(test_iltdata.Delta_Q) == 4
        assert len(test_iltdata.reg_bc) == 4
        assert len(test_iltdata.c_nmax) == 4
        assert len(test_iltdata.p_nmax) == 4
        assert len(test_iltdata.zc_nmax) == 4

        assert test_iltdata.reg_bc[2] == 0
        assert test_iltdata.reg_bc[3] == 0

        expected_dq = np.sqrt(3.0**2 + 4.0**2)
        np.testing.assert_allclose(test_iltdata.Delta_Q[2], expected_dq)

        alpha_terms = ["alpha_0", "alpha_c", "alpha_p", "alpha_a", "alpha_d"]
        expecpted_alpha_value = np.sqrt((3.0**2 + 4.0**2) / 2.0)

        for attr in alpha_terms:
            test_alpha_value = getattr(test_iltdata, attr)

            np.testing.assert_allclose(
                test_alpha_value[2],
                expecpted_alpha_value,
            )

            assert len(test_alpha_value) == 4

        # mean(10, 11) = 10.5, so ceil = 11
        assert test_iltdata.c_nmax[2] == 11
        assert test_iltdata.p_nmax[2] == 11
        assert test_iltdata.zc_nmax[3] == 15
