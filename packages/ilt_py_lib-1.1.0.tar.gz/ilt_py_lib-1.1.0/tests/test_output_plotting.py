# Tests for iltpy/output/plotting.py

import pytest
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from matplotlib.axes import Axes
import matplotlib
matplotlib.use("Agg")

from iltpy.output.plotting import set_plot_param, iltplot
from iltpy.fit.inversion import IltData

# fixtures for plotting tests
@pytest.fixture
def mock_inverted_iltdata_1d(dummy_data_dict):
    """Create a mock inverted IltData object for 1D plotting tests."""
    test_iltdata = IltData(dummy_data_dict)
    test_iltdata._inverted = True
    test_iltdata._ndim = 1
    test_iltdata.data = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
    test_iltdata.fit = np.array([1.1, 2.1, 3.1, 4.1, 5.1])
    test_iltdata.g = np.array([0.5, 1.0, 1.5, 1.0, 0.5])
    test_iltdata.t = [np.array([0.1, 0.2, 0.3, 0.4, 0.5]).reshape(-1, 1)]
    test_iltdata.tau = [np.array([1.0, 2.0, 3.0, 4.0, 5.0]).reshape(-1, 1)]
    test_iltdata.residuals = np.array([0.1, 0.1, 0.1, 0.1, 0.1])
    test_iltdata.sigma = None
    test_iltdata.sb = [False]
    test_iltdata.base_tau = [1]
    yield test_iltdata
    plt.close("all")


@pytest.fixture
def mock_inverted_iltdata_1d_with_sigma(dummy_data_dict):
    """Create a mock inverted IltData object with sigma for residual scaling tests."""
    test_iltdata = IltData(dummy_data_dict)
    test_iltdata._inverted = True
    test_iltdata._ndim = 1
    test_iltdata.data = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
    test_iltdata.fit = np.array([1.1, 2.1, 3.1, 4.1, 5.1])
    test_iltdata.g = np.array([0.5, 1.0, 1.5, 1.0, 0.5])
    test_iltdata.t = [np.array([0.1, 0.2, 0.3, 0.4, 0.5]).reshape(-1, 1)]
    test_iltdata.tau = [np.array([1.0, 2.0, 3.0, 4.0, 5.0]).reshape(-1, 1)]
    test_iltdata.residuals = np.array([0.1, 0.1, 0.1, 0.1, 0.1])
    test_iltdata.sigma = np.array([0.05, 0.05, 0.05, 0.05, 0.05])
    test_iltdata.sb = [False]
    test_iltdata.base_tau = [1]
    yield test_iltdata
    plt.close("all")


@pytest.fixture
def mock_inverted_iltdata_1d_with_sb(dummy_data_dict):
    """Create a mock inverted IltData object with static baseline for 1D plotting tests."""
    test_iltdata = IltData(dummy_data_dict)
    test_iltdata._inverted = True
    test_iltdata._ndim = 1
    test_iltdata.data = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
    test_iltdata.fit = np.array([1.1, 2.1, 3.1, 4.1, 5.1])
    test_iltdata.g = np.array([0.5, 1.0, 1.5, 1.0, 0.5, 0.1])  # Extra point for sb
    test_iltdata.t = [np.array([0.1, 0.2, 0.3, 0.4, 0.5]).reshape(-1, 1)]
    test_iltdata.tau = [np.array([1.0, 2.0, 3.0, 4.0, 5.0]).reshape(-1, 1)]
    test_iltdata.residuals = np.array([0.1, 0.1, 0.1, 0.1, 0.1])
    test_iltdata.sigma = None
    test_iltdata.sb = [True]
    test_iltdata.base_tau = [1]
    yield test_iltdata
    plt.close("all")


@pytest.fixture
def mock_inverted_iltdata_2d(dummy_data_dict):
    """Create a mock inverted IltData object for 2D plotting tests."""
    test_iltdata = IltData(dummy_data_dict)
    test_iltdata._inverted = True
    test_iltdata._ndim = 2
    test_iltdata.data = np.ones((10, 5))
    test_iltdata.fit = np.ones((10, 5)) * 1.1
    test_iltdata.g = np.random.rand(10, 5)
    test_iltdata.t = [
        np.linspace(0.1, 1.0, 10).reshape(-1, 1),
        np.linspace(0.1, 0.5, 5).reshape(-1, 1),
    ]
    test_iltdata.tau = [
        np.logspace(-1, 1, 10).reshape(-1, 1),
        np.logspace(-1, 0, 5).reshape(-1, 1),
    ]
    test_iltdata.residuals = np.random.randn(10, 5) * 0.1
    test_iltdata.sigma = None
    test_iltdata.sb = [False, False]
    test_iltdata.base_tau = [1, 1]
    yield test_iltdata
    plt.close("all")


@pytest.fixture
def mock_inverted_iltdata_2d_base_tau_zero(dummy_data_dict):
    """Create a mock inverted IltData object for 2D plotting tests with base_tau[1]=0."""
    test_iltdata = IltData(dummy_data_dict)
    test_iltdata._inverted = True
    test_iltdata._ndim = 2
    test_iltdata.data = np.ones((10, 5))
    test_iltdata.fit = np.ones((10, 5)) * 1.1
    test_iltdata.g = np.random.rand(10, 5)
    test_iltdata.t = [
        np.linspace(0.1, 1.0, 10).reshape(-1, 1),
        np.linspace(0.1, 0.5, 5).reshape(-1, 1),
    ]
    test_iltdata.tau = [
        np.logspace(-1, 1, 10).reshape(-1, 1),
        np.logspace(-1, 0, 5).reshape(-1, 1),
    ]
    test_iltdata.residuals = np.random.randn(10, 5) * 0.1
    test_iltdata.sigma = None
    test_iltdata.sb = [False, False]
    test_iltdata.base_tau = [1, 0]  # base_tau[1] = 0
    yield test_iltdata
    plt.close("all")

# other tests are marked as slow.

def test_set_plot_param_specific_values():
    """Verify specific parameter values are set correctly."""
    set_plot_param()
    assert plt.rcParams["axes.labelsize"] == 12
    assert plt.rcParams["axes.titlesize"] == 14
    assert plt.rcParams["legend.fontsize"] == 10
    assert plt.rcParams["xtick.labelsize"] == 10
    assert plt.rcParams["ytick.labelsize"] == 10
    assert plt.rcParams["lines.linewidth"] == 1
    assert plt.rcParams["lines.markersize"] == 4
    assert plt.rcParams["grid.linestyle"] == "--"
    assert plt.rcParams["grid.linewidth"] == 0.5
    assert plt.rcParams["grid.color"] == "gray"
    assert plt.rcParams["savefig.dpi"] == 300
    assert plt.rcParams["figure.figsize"] == [6, 4]
    assert plt.rcParams["figure.dpi"] == 120
    plt.close("all")

def test_iltplot_not_inverted_error(dummy_data_dict):
    """Verify RuntimeError when iltplot is called on non-inverted data."""
    test_iltdata = IltData(dummy_data_dict)
    test_iltdata._inverted = False

    with pytest.raises(
        RuntimeError, match="iltplot can only be used after the dataset has been inverted."
    ):
        iltplot(test_iltdata)
    plt.close("all")

def test_iltplot_ndim_error(dummy_data_dict):
    """Verify ValueError when data.ndim > 2."""
    test_iltdata = IltData(dummy_data_dict)
    test_iltdata._inverted = True
    test_iltdata._ndim = 3

    with pytest.raises(ValueError, match="iltplot can only be used with up to 2D datasets."):
        iltplot(test_iltdata)
    plt.close("all")

def test_iltplot_1d_return_types(mock_inverted_iltdata_1d):
    """Verify return types for 1D plotting."""
    fig, axes = iltplot(mock_inverted_iltdata_1d)

    assert isinstance(fig, Figure)
    assert isinstance(axes, list)
    assert all(isinstance(ax, Axes) for ax in axes)
    plt.close("all")

def test_iltplot_2d_basic(mock_inverted_iltdata_2d):
    """Verify basic 2D plotting returns correct types."""
    result = iltplot(mock_inverted_iltdata_2d)

    assert isinstance(result[0], Figure)
    assert len(result[1]) == 3
    plt.close("all")


@pytest.mark.slow
class TestIltPyOutputPlotting:
    """Tests for iltpy/output/plotting.py module"""

    def test_iltplot_1d_basic(self, mock_inverted_iltdata_1d):
        """Verify basic 1D plotting returns correct types."""
        result = iltplot(mock_inverted_iltdata_1d)

        assert isinstance(result, tuple)
        assert len(result) == 2
        assert isinstance(result[0], Figure)
        assert isinstance(result[1], list)
        assert len(result[1]) == 3
        for ax in result[1]:
            assert isinstance(ax, Axes)
        plt.close("all")

    def test_iltplot_1d_with_sb_true(self, mock_inverted_iltdata_1d_with_sb):
        """Test with static baseline (sb[0]=True) for 1D data."""
        fig, _ = iltplot(mock_inverted_iltdata_1d_with_sb)

        assert isinstance(fig, Figure)
        plt.close("all")

    def test_iltplot_1d_with_sb_false(self, mock_inverted_iltdata_1d):
        """Test without static baseline for 1D data."""
        fig, _ = iltplot(mock_inverted_iltdata_1d)

        assert isinstance(fig, Figure)
        plt.close("all")

    def test_iltplot_1d_axis_labels(self, mock_inverted_iltdata_1d):
        """Verify axis labels for 1D plotting."""
        _, axes = iltplot(mock_inverted_iltdata_1d)
        ax0, ax1, _ = axes

        assert ax0.get_xlabel() == "t"
        assert ax1.get_xlabel() == r"log($\tau$)"
        plt.close("all")

    def test_iltplot_1d_residuals_plot(self, mock_inverted_iltdata_1d):
        """Verify residuals are plotted in ax2 for 1D data."""
        fig, axes = iltplot(mock_inverted_iltdata_1d)
        ax2 = axes[2]

        # ax2 should have 3 lines: residuals, r_mean, r_std
        lines = ax2.get_lines()
        assert len(lines) == 3
        plt.close("all")

    def test_iltplot_1d_data_fit_plot(self, mock_inverted_iltdata_1d):
        """Verify data and fit are plotted in ax0 for 1D data."""
        _, axes = iltplot(mock_inverted_iltdata_1d)
        ax0 = axes[0]

        # ax0 should have 2 lines: data (black) and fit (red dashed)
        lines = ax0.get_lines()
        assert len(lines) == 2
        plt.close("all")


    def test_iltplot_2d_transpose_residuals(self, mock_inverted_iltdata_2d):
        """Test with transpose_residuals=True for 2D data."""

        fig, _ = iltplot(mock_inverted_iltdata_2d, transpose_residuals=True)
        assert isinstance(fig, Figure)
        plt.close("all")

    def test_iltplot_2d_custom_dim_ndim(self, mock_inverted_iltdata_2d):
        """Test with user-provided dim_ndim for 2D data."""
        custom_dim = np.linspace(0, 10, 5)

        fig, _ = iltplot(mock_inverted_iltdata_2d, dim_ndim=custom_dim)

        assert isinstance(fig, Figure)
        plt.close("all")

    def test_iltplot_2d_dim_ndim_none_base_tau_nonzero(self, mock_inverted_iltdata_2d):
        """Test dim_ndim=None with base_tau[1] != 0 for 2D data."""
        fig, axes = iltplot(mock_inverted_iltdata_2d)

        # should use np.log10(tau[1].flatten()) for dim_ndim
        assert isinstance(fig, Figure)
        plt.close("all")

    def test_iltplot_2d_dim_ndim_none_base_tau_zero(self, mock_inverted_iltdata_2d_base_tau_zero):
        """Test dim_ndim=None with base_tau[1] == 0 for 2D data."""
        fig, axes = iltplot(mock_inverted_iltdata_2d_base_tau_zero)

        # should use tau[1].flatten() for dim_ndim without log
        assert isinstance(fig, Figure)
        plt.close("all")

    def test_iltplot_2d_axis_labels(self, mock_inverted_iltdata_2d):
        """Verify axis labels for 2D plotting."""
        fig, axes = iltplot(mock_inverted_iltdata_2d)
        ax0, ax1, ax2 = axes

        assert ax0.get_xlabel() == "t"
        assert ax1.get_ylabel() == r"log($\tau$)"
        # xlabel for ax1 depends on base_tau[1]
        plt.close("all")

    def test_iltplot_2d_data_summed(self, mock_inverted_iltdata_2d):
        """Verify data is summed along axis for 2D plotting."""
        fig, axes = iltplot(mock_inverted_iltdata_2d)
        fig_axes = fig.get_axes()
        ax0 = axes[0]
        # ax0 should have 2 lines: summed data and summed fit
        lines = ax0.get_lines()
        # should have more than 3 axes due to colorbar
        assert len(fig_axes) > 3
        assert len(lines) == 2
        plt.close("all")

    @pytest.mark.parametrize("scale_residuals", [True, False])
    def test_iltplot_scale_residuals_with_sigma(self, mock_inverted_iltdata_1d_with_sigma, scale_residuals):
        """Test with sigma and various scale_residuals options."""
        fig, axes = iltplot(mock_inverted_iltdata_1d_with_sigma, scale_residuals=scale_residuals)

        assert isinstance(fig, Figure)
        plt.close("all")

    def test_iltplot_integration_1d_synthetic(self, syn_ilt_data_1d):
        """Full workflow test with synthetic 1D data."""
        import iltpy as ilt

        syn_data_1D, t_syn, g_true = syn_ilt_data_1d
        ilt_1d = ilt.iltload(data=syn_data_1D, t=t_syn)
        ilt_1d.init(tau=np.logspace(-10, 10, 50), kernel=ilt.Exponential(),parameters={"maxloop":5})
        ilt_1d.invert()

        fig, axes = iltplot(ilt_1d)

        assert isinstance(fig, Figure)
        assert len(axes) == 3
        plt.close("all")

    def test_iltplot_integration_pseudo_2d_synthetic(self, syn_ilt_data_pseudo_2d):
        """Full workflow test with synthetic pseudo-2D data."""
        import iltpy as ilt

        syn_data_2D, t_syn, g_true = syn_ilt_data_pseudo_2d
        ilt_2d = ilt.iltload(data=syn_data_2D, t=t_syn)
        ilt_2d.init(tau=np.logspace(-3, 6, 40), kernel=ilt.Exponential(),parameters={"maxloop":5})
        ilt_2d.invert()

        fig, axes = iltplot(ilt_2d)

        assert isinstance(fig, Figure)
        assert len(axes) == 3
        plt.close("all")

    def test_iltplot_integration_2d_synthetic(self, syn_ilt_data_2d):
        """Full workflow test with synthetic 2D data."""
        import iltpy as ilt

        syn_data_2D, t_list, g_true = syn_ilt_data_2d
        ilt_2d = ilt.iltload(data=syn_data_2D, t=t_list)
        ilt_2d.init(
            tau=[np.logspace(-4, 5, 50), np.logspace(-4, 5, 50)],
            kernel=[ilt.Exponential(), ilt.Exponential()],parameters={"maxloop":5,"alt_g":6}
        )
        ilt_2d.invert()

        fig, axes = iltplot(ilt_2d)

        assert isinstance(fig, Figure)
        assert len(axes) == 3
        plt.close("all")
