# Tests for iltpy/output/reporting.py

import pytest
import numpy as np
import iltpy as ilt
import json
from pathlib import Path
from unittest.mock import patch
from scipy.sparse import csc_array

from iltpy.output.reporting import (
    iltreport,
    _generate_report_dict,
    _write_report_to_file,
    _write_array_to_file,
)
from iltpy.fit.inversion import IltData
from iltpy import __version__


class TestIltPyOutputReporting:
    """Tests for iltpy/output/reporting.py module"""

    def test_iltreport_not_inverted_error(self, dummy_data_dict):
        """Verify that iltreport() raises ValueError when called on non-inverted data."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._inverted = False

        with pytest.raises(ValueError, match="This dataset is not inverted. Use IltData.invert()."):
            iltreport(test_iltdata)

    @patch("iltpy.output.reporting._write_array_to_file")
    @patch("iltpy.output.reporting._write_report_to_file")
    @patch("iltpy.output.reporting._generate_report_dict")
    def test_iltreport_calls_internal_functions(
        self,
        mock_generate_report_dict,
        mock_write_report_to_file,
        mock_write_array_to_file,
        dummy_data_dict,
        tmp_path,
    ):
        """Verify that iltreport() calls internal functions correctly when data is inverted."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._inverted = True

        mock_report_dict = {"filepath": tmp_path / "test.txt"}
        mock_generate_report_dict.return_value = (
            mock_report_dict,
            tmp_path / "test.txt",
            str(tmp_path),
        )

        iltreport(test_iltdata, filepath=str(tmp_path / "test.txt"))

        mock_generate_report_dict.assert_called_once_with(test_iltdata, str(tmp_path / "test.txt"))
        mock_write_report_to_file.assert_called_once_with(mock_report_dict, False)
        mock_write_array_to_file.assert_not_called()

    @patch("iltpy.output.reporting._write_array_to_file")
    @patch("iltpy.output.reporting._write_report_to_file")
    @patch("iltpy.output.reporting._generate_report_dict")
    def test_iltreport_save_arrays_true(
        self,
        mock_generate_report_dict,
        mock_write_report_to_file,
        mock_write_array_to_file,
        dummy_data_dict,
        tmp_path,
    ):
        """Verify that save_arrays=True triggers array file writing."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._inverted = True

        mock_report_dict = {"filepath": tmp_path / "test.txt"}
        mock_generate_report_dict.return_value = (
            mock_report_dict,
            tmp_path / "test.txt",
            str(tmp_path),
        )

        iltreport(test_iltdata, filepath=str(tmp_path / "test.txt"), save_arrays=True, level=1)

        mock_write_array_to_file.assert_called_once_with(test_iltdata, tmp_path / "test.txt", 1)

    @patch("iltpy.output.reporting._write_array_to_file")
    @patch("iltpy.output.reporting._write_report_to_file")
    @patch("iltpy.output.reporting._generate_report_dict")
    def test_iltreport_parameters_to_file(
        self,
        mock_generate_report_dict,
        mock_write_report_to_file,
        mock_write_array_to_file,
        dummy_data_dict,
        tmp_path,
    ):
        """Verify that parameters_to_file=True is passed to _write_report_to_file."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata._inverted = True

        mock_report_dict = {"filepath": tmp_path / "test.txt"}
        mock_generate_report_dict.return_value = (
            mock_report_dict,
            tmp_path / "test.txt",
            str(tmp_path),
        )

        iltreport(test_iltdata, filepath=str(tmp_path / "test.txt"), parameters_to_file=True)

        mock_write_report_to_file.assert_called_once_with(mock_report_dict, True)

    def test_generate_report_dict_basic(self, dummy_data_dict):
        """Verify basic report dictionary structure is created correctly."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.g = np.array([1.0, 2.0, 3.0])
        test_iltdata.fit = np.array([1.1, 2.1, 3.1])
        test_iltdata.residuals = np.array([0.1, 0.1, 0.1])
        test_iltdata.t = [np.array([0.1, 0.2, 0.3]).reshape(-1, 1)]
        test_iltdata.tau = [np.array([1.0, 2.0, 3.0]).reshape(-1, 1)]
        test_iltdata.sigma = None
        test_iltdata.dim_ndim = None
        test_iltdata.g_guess = None
        test_iltdata._ndim = 1
        test_iltdata.fit_dict = {"test_param": 123}
        test_iltdata.inversion_time = 1.5
        test_iltdata._initialization_time = 0.5

        report_dict, out_file_path, folder = _generate_report_dict(test_iltdata, filepath=None)

        assert "g" in report_dict
        assert "fit" in report_dict
        assert "residuals" in report_dict
        assert "data" in report_dict
        assert "sigma" in report_dict
        assert "g_guess" in report_dict
        assert "dim_ndim" in report_dict
        assert "parameters" in report_dict
        assert "t" in report_dict
        assert "tau" in report_dict
        assert "filepath" in report_dict
        assert "inversion_time" in report_dict
        assert "initialization_time" in report_dict

        np.testing.assert_array_equal(report_dict["g"], test_iltdata.g)
        np.testing.assert_array_equal(report_dict["fit"], test_iltdata.fit)
        np.testing.assert_array_equal(report_dict["residuals"], test_iltdata.residuals)

    def test_generate_report_dict_filepath_none(self, dummy_data_dict):
        """Verify default filepath generation when filepath=None."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.g = np.array([1.0, 2.0, 3.0])
        test_iltdata.fit = np.array([1.1, 2.1, 3.1])
        test_iltdata.residuals = np.array([0.1, 0.1, 0.1])
        test_iltdata.t = [np.array([0.1, 0.2, 0.3]).reshape(-1, 1)]
        test_iltdata.tau = [np.array([1.0, 2.0, 3.0]).reshape(-1, 1)]
        test_iltdata.sigma = None
        test_iltdata.dim_ndim = None
        test_iltdata.g_guess = None
        test_iltdata._ndim = 1
        test_iltdata.fit_dict = {}
        test_iltdata.inversion_time = 1.5
        test_iltdata._initialization_time = 0.5

        report_dict, out_file_path, folder = _generate_report_dict(test_iltdata, filepath=None)

        assert out_file_path.name.startswith("iltpy_")
        assert out_file_path.suffix == ".txt"
        assert out_file_path.parent == Path.cwd()

    def test_generate_report_dict_filepath_with_directory(self, dummy_data_dict, tmp_path):
        """Verify filepath handling when a directory path is provided."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.g = np.array([1.0, 2.0, 3.0])
        test_iltdata.fit = np.array([1.1, 2.1, 3.1])
        test_iltdata.residuals = np.array([0.1, 0.1, 0.1])
        test_iltdata.t = [np.array([0.1, 0.2, 0.3]).reshape(-1, 1)]
        test_iltdata.tau = [np.array([1.0, 2.0, 3.0]).reshape(-1, 1)]
        test_iltdata.sigma = None
        test_iltdata.dim_ndim = None
        test_iltdata.g_guess = None
        test_iltdata._ndim = 1
        test_iltdata.fit_dict = {}
        test_iltdata.inversion_time = 1.5
        test_iltdata._initialization_time = 0.5

        report_dict, out_file_path, folder = _generate_report_dict(
            test_iltdata, filepath=str(tmp_path)
        )

        assert out_file_path.parent == tmp_path
        assert out_file_path.name.startswith("iltpy_")
        assert out_file_path.suffix == ".txt"

    def test_generate_report_dict_filepath_with_file(self, dummy_data_dict, tmp_path):
        """Verify filepath handling when a full file path is provided."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.g = np.array([1.0, 2.0, 3.0])
        test_iltdata.fit = np.array([1.1, 2.1, 3.1])
        test_iltdata.residuals = np.array([0.1, 0.1, 0.1])
        test_iltdata.t = [np.array([0.1, 0.2, 0.3]).reshape(-1, 1)]
        test_iltdata.tau = [np.array([1.0, 2.0, 3.0]).reshape(-1, 1)]
        test_iltdata.sigma = None
        test_iltdata.dim_ndim = None
        test_iltdata.g_guess = None
        test_iltdata._ndim = 1
        test_iltdata.fit_dict = {}
        test_iltdata.inversion_time = 1.5
        test_iltdata._initialization_time = 0.5

        custom_path = tmp_path / "custom_report.txt"
        report_dict, out_file_path, folder = _generate_report_dict(
            test_iltdata, filepath=str(custom_path)
        )

        assert out_file_path == custom_path

    def test_generate_report_dict_filepath_no_extension(self, dummy_data_dict, tmp_path):
        """Verify .txt extension is added when filepath has no extension."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.g = np.array([1.0, 2.0, 3.0])
        test_iltdata.fit = np.array([1.1, 2.1, 3.1])
        test_iltdata.residuals = np.array([0.1, 0.1, 0.1])
        test_iltdata.t = [np.array([0.1, 0.2, 0.3]).reshape(-1, 1)]
        test_iltdata.tau = [np.array([1.0, 2.0, 3.0]).reshape(-1, 1)]
        test_iltdata.sigma = None
        test_iltdata.dim_ndim = None
        test_iltdata.g_guess = None
        test_iltdata._ndim = 1
        test_iltdata.fit_dict = {}
        test_iltdata.inversion_time = 1.5
        test_iltdata._initialization_time = 0.5

        custom_path = tmp_path / "custom_report"
        report_dict, out_file_path, folder = _generate_report_dict(
            test_iltdata, filepath=str(custom_path)
        )

        assert out_file_path.suffix == ".txt"
        assert out_file_path.stem == "custom_report"

    def test_generate_report_dict_nonexistent_folder_error(self, dummy_data_dict):
        """Verify OSError is raised when parent folder doesn't exist."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.g = np.array([1.0, 2.0, 3.0])
        test_iltdata.fit = np.array([1.1, 2.1, 3.1])
        test_iltdata.residuals = np.array([0.1, 0.1, 0.1])
        test_iltdata.t = [np.array([0.1, 0.2, 0.3]).reshape(-1, 1)]
        test_iltdata.tau = [np.array([1.0, 2.0, 3.0]).reshape(-1, 1)]
        test_iltdata.sigma = None
        test_iltdata.dim_ndim = None
        test_iltdata.g_guess = None
        test_iltdata._ndim = 1
        test_iltdata.fit_dict = {}
        test_iltdata.inversion_time = 1.5
        test_iltdata._initialization_time = 0.5

        nonexistent_path = "/nonexistent/folder/report.txt"

        with pytest.raises(OSError, match="Folder does not exist"):
            _generate_report_dict(test_iltdata, filepath=nonexistent_path)

    def test_generate_report_dict_with_sigma(self, dummy_data_dict, tmp_path):
        """Verify sigma is included in report dict when present."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.g = np.array([1.0, 2.0, 3.0])
        test_iltdata.fit = np.array([1.1, 2.1, 3.1])
        test_iltdata.residuals = np.array([0.1, 0.1, 0.1])
        test_iltdata.t = [np.array([0.1, 0.2, 0.3]).reshape(-1, 1)]
        test_iltdata.tau = [np.array([1.0, 2.0, 3.0]).reshape(-1, 1)]
        test_iltdata.sigma = np.array([0.1, 0.2, 0.3])
        test_iltdata.dim_ndim = None
        test_iltdata.g_guess = None
        test_iltdata._ndim = 1
        test_iltdata.fit_dict = {}
        test_iltdata.inversion_time = 1.5
        test_iltdata._initialization_time = 0.5

        report_dict, _, _ = _generate_report_dict(test_iltdata, filepath=str(tmp_path))

        np.testing.assert_array_equal(report_dict["sigma"], test_iltdata.sigma)

    def test_generate_report_dict_with_g_guess(self, dummy_data_dict, tmp_path):
        """Verify g_guess is included and flattened in report dict."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.g = np.array([1.0, 2.0, 3.0])
        test_iltdata.fit = np.array([1.1, 2.1, 3.1])
        test_iltdata.residuals = np.array([0.1, 0.1, 0.1])
        test_iltdata.t = [np.array([0.1, 0.2, 0.3]).reshape(-1, 1)]
        test_iltdata.tau = [np.array([1.0, 2.0, 3.0]).reshape(-1, 1)]
        test_iltdata.sigma = None
        test_iltdata.dim_ndim = None
        test_iltdata.g_guess = np.array([[1.0], [2.0], [3.0]])
        test_iltdata._ndim = 1
        test_iltdata.fit_dict = {}
        test_iltdata.inversion_time = 1.5
        test_iltdata._initialization_time = 0.5

        report_dict, _, _ = _generate_report_dict(test_iltdata, filepath=str(tmp_path))

        assert report_dict["g_guess"].shape == (3,)
        np.testing.assert_array_equal(report_dict["g_guess"], test_iltdata.g_guess.flatten())

    def test_generate_report_dict_with_dim_ndim(self, dummy_data_dict, tmp_path):
        """Verify dim_ndim is included and flattened in report dict."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.g = np.array([1.0, 2.0, 3.0])
        test_iltdata.fit = np.array([1.1, 2.1, 3.1])
        test_iltdata.residuals = np.array([0.1, 0.1, 0.1])
        test_iltdata.t = [np.array([0.1, 0.2, 0.3]).reshape(-1, 1)]
        test_iltdata.tau = [np.array([1.0, 2.0, 3.0]).reshape(-1, 1)]
        test_iltdata.sigma = None
        test_iltdata.dim_ndim = np.array([[1, 2], [3, 4]])
        test_iltdata.g_guess = None
        test_iltdata._ndim = 1
        test_iltdata.fit_dict = {}
        test_iltdata.inversion_time = 1.5
        test_iltdata._initialization_time = 0.5

        report_dict, _, _ = _generate_report_dict(test_iltdata, filepath=str(tmp_path))

        assert report_dict["dim_ndim"].shape == (4,)
        np.testing.assert_array_equal(report_dict["dim_ndim"], test_iltdata.dim_ndim.flatten())

    def test_generate_report_dict_ndim_greater_than_2(self, dummy_data_dict, tmp_path):
        """Verify array reshaping for multidimensional data (ndim > 2)."""
        test_iltdata = IltData(dummy_data_dict)
        # Simulate 3D data
        test_iltdata.g = np.ones((10, 5, 3))
        test_iltdata.fit = np.ones((10, 5, 3))
        test_iltdata.residuals = np.ones((10, 5, 3))
        test_iltdata.data = np.ones((10, 5, 3))
        test_iltdata.t = [np.array([0.1, 0.2, 0.3]).reshape(-1, 1)]
        test_iltdata.tau = [np.array([1.0, 2.0, 3.0]).reshape(-1, 1)]
        test_iltdata.sigma = np.ones((10, 5, 3))
        test_iltdata.dim_ndim = None
        test_iltdata.g_guess = None
        test_iltdata._ndim = 3
        test_iltdata.fit_dict = {}
        test_iltdata.inversion_time = 1.5
        test_iltdata._initialization_time = 0.5

        report_dict, _, _ = _generate_report_dict(test_iltdata, filepath=str(tmp_path))

        # should be reshaped to (10, 15)
        assert report_dict["g"].shape == (10, 15)
        assert report_dict["fit"].shape == (10, 15)
        assert report_dict["residuals"].shape == (10, 15)
        assert report_dict["data"].shape == (10, 15)
        assert report_dict["sigma"].shape == (10, 15)

    def test_generate_report_dict_t_tau_flattened(self, dummy_data_dict, tmp_path):
        """Verify t and tau arrays are flattened in report dict."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.g = np.array([1.0, 2.0, 3.0])
        test_iltdata.fit = np.array([1.1, 2.1, 3.1])
        test_iltdata.residuals = np.array([0.1, 0.1, 0.1])
        test_iltdata.t = [np.array([[0.1], [0.2], [0.3]])]  # 2D array
        test_iltdata.tau = [np.array([[1.0], [2.0], [3.0]])]  # 2D array
        test_iltdata.sigma = None
        test_iltdata.dim_ndim = None
        test_iltdata.g_guess = None
        test_iltdata._ndim = 1
        test_iltdata.fit_dict = {}
        test_iltdata.inversion_time = 1.5
        test_iltdata._initialization_time = 0.5

        report_dict, _, _ = _generate_report_dict(test_iltdata, filepath=str(tmp_path))

        assert report_dict["t"][0].shape == (3,)
        assert report_dict["tau"][0].shape == (3,)

    def test_write_report_to_file_creates_file(self, tmp_path):
        """Verify report file is created."""
        report_dict = {
            "filepath": tmp_path / "test_report.txt",
            "data": np.array([[1.0, 2.0], [3.0, 4.0]]),
            "t": [np.array([0.1, 0.2])],
            "tau": [np.array([1.0, 2.0])],
            "g": np.array([[1.0, 2.0], [3.0, 4.0]]),
            "fit": np.array([[1.1, 2.1], [3.1, 4.1]]),
            "residuals": np.array([[0.1, 0.1], [0.1, 0.1]]),
            "sigma": None,
            "g_guess": None,
            "dim_ndim": None,
            "parameters": {"alpha_00": 1, "kernel": ilt.Exponential()},
            "inversion_time": 1.5,
            "initialization_time": 0.5,
        }

        _write_report_to_file(report_dict, parameters_to_file=False)

        assert (tmp_path / "test_report.txt").exists()

    def test_write_report_to_file_header(self, tmp_path):
        """Verify file header contains expected information."""
        report_dict = {
            "filepath": tmp_path / "test_report.txt",
            "data": np.array([[1.0, 2.0], [3.0, 4.0]]),
            "t": [np.array([0.1, 0.2])],
            "tau": [np.array([1.0, 2.0])],
            "g": np.array([[1.0, 2.0], [3.0, 4.0]]),
            "fit": np.array([[1.1, 2.1], [3.1, 4.1]]),
            "residuals": np.array([[0.1, 0.1], [0.1, 0.1]]),
            "sigma": None,
            "g_guess": None,
            "dim_ndim": None,
            "parameters": {"alpha_00": 1, "kernel": ilt.Exponential()},
            "inversion_time": 1.5,
            "initialization_time": 0.5,
        }

        _write_report_to_file(report_dict, parameters_to_file=False)

        content = (tmp_path / "test_report.txt").read_text()

        assert "# --- ILTPY ---" in content
        assert f"# ILTpy version : {__version__}" in content
        assert "# Time taken for initialization : 0.5 seconds" in content
        assert "# Time taken for inversion : 1.5 seconds" in content

    def test_write_report_to_file_arrays_section(self, tmp_path):
        """Verify arrays section is written correctly."""
        report_dict = {
            "filepath": tmp_path / "test_report.txt",
            "data": np.array([[1.0, 2.0], [3.0, 4.0]]),
            "t": [np.array([0.1, 0.2])],
            "tau": [np.array([1.0, 2.0])],
            "g": np.array([[1.0, 2.0], [3.0, 4.0]]),
            "fit": np.array([[1.1, 2.1], [3.1, 4.1]]),
            "residuals": np.array([[0.1, 0.1], [0.1, 0.1]]),
            "sigma": None,
            "g_guess": None,
            "dim_ndim": None,
            "parameters": {"alpha_00": 1, "kernel": ilt.Exponential()},
            "inversion_time": 1.5,
            "initialization_time": 0.5,
        }

        _write_report_to_file(report_dict, parameters_to_file=False)

        content = (tmp_path / "test_report.txt").read_text()

        assert "# --- ARRAYS ---" in content
        assert "Data" in content
        assert "Shape : (2, 2)" in content
        assert "TAU" in content
        assert "G" in content
        assert "FIT" in content
        assert "RESIDUALS" in content

    def test_write_report_to_file_optional_arrays(self, tmp_path):
        """Verify optional arrays (sigma, g_guess, dim_ndim) are written when present."""
        report_dict = {
            "filepath": tmp_path / "test_report.txt",
            "data": np.array([[1.0, 2.0], [3.0, 4.0]]),
            "t": [np.array([0.1, 0.2])],
            "tau": [np.array([1.0, 2.0])],
            "g": np.array([[1.0, 2.0], [3.0, 4.0]]),
            "fit": np.array([[1.1, 2.1], [3.1, 4.1]]),
            "residuals": np.array([[0.1, 0.1], [0.1, 0.1]]),
            "sigma": np.array([[0.1, 0.2], [0.3, 0.4]]),
            "g_guess": np.array([1.0, 2.0, 3.0, 4.0]),
            "dim_ndim": np.array([1, 2]),
            "parameters": {"alpha_00": 1, "kernel": ilt.Exponential()},
            "inversion_time": 1.5,
            "initialization_time": 0.5,
        }

        _write_report_to_file(report_dict, parameters_to_file=False)

        content = (tmp_path / "test_report.txt").read_text()

        assert "SIGMA" in content
        assert "G_GUESS" in content
        assert "DIM_NDIM" in content

    def test_write_report_to_file_kernel_section(self, tmp_path, dummy_kernel_dict):
        """Verify kernel section is written correctly."""
        kernel = dummy_kernel_dict["_exponential_"]
        report_dict = {
            "filepath": tmp_path / "test_report.txt",
            "data": np.array([[1.0, 2.0], [3.0, 4.0]]),
            "t": [np.array([0.1, 0.2])],
            "tau": [np.array([1.0, 2.0])],
            "g": np.array([[1.0, 2.0], [3.0, 4.0]]),
            "fit": np.array([[1.1, 2.1], [3.1, 4.1]]),
            "residuals": np.array([[0.1, 0.1], [0.1, 0.1]]),
            "sigma": None,
            "g_guess": None,
            "dim_ndim": None,
            "parameters": {"alpha_00": 1, "kernel": kernel},
            "inversion_time": 1.5,
            "initialization_time": 0.5,
        }

        _write_report_to_file(report_dict, parameters_to_file=False)

        content = (tmp_path / "test_report.txt").read_text()

        assert "# --- KERNEL ---" in content
        assert f"# Kernel name Dim 0 : {kernel.name}" in content
        assert f"# Kernel function Dim 0 : {kernel.kernel_str}" in content

    def test_write_report_to_file_kernel_string_warning(self, tmp_path):
        """Verify warning is raised when kernel is a string."""
        report_dict = {
            "filepath": tmp_path / "test_report.txt",
            "data": np.array([[1.0, 2.0], [3.0, 4.0]]),
            "t": [np.array([0.1, 0.2])],
            "tau": [np.array([1.0, 2.0])],
            "g": np.array([[1.0, 2.0], [3.0, 4.0]]),
            "fit": np.array([[1.1, 2.1], [3.1, 4.1]]),
            "residuals": np.array([[0.1, 0.1], [0.1, 0.1]]),
            "sigma": None,
            "g_guess": None,
            "dim_ndim": None,
            "parameters": {"alpha_00": 1, "kernel": "exponential"},
            "inversion_time": 1.5,
            "initialization_time": 0.5,
        }

        with pytest.warns(UserWarning, match="Unable to report kernel function in Dim 0"):
            _write_report_to_file(report_dict, parameters_to_file=False)

    def test_write_report_to_file_kernel_list(self, tmp_path, dummy_kernel_dict):
        """Verify handling of kernel as list (multi-dimensional case)."""
        kernel1 = dummy_kernel_dict["_exponential_"]
        kernel2 = dummy_kernel_dict["_identity_"]
        report_dict = {
            "filepath": tmp_path / "test_report.txt",
            "data": np.array([[1.0, 2.0], [3.0, 4.0]]),
            "t": [np.array([0.1, 0.2])],
            "tau": [np.array([1.0, 2.0])],
            "g": np.array([[1.0, 2.0], [3.0, 4.0]]),
            "fit": np.array([[1.1, 2.1], [3.1, 4.1]]),
            "residuals": np.array([[0.1, 0.1], [0.1, 0.1]]),
            "sigma": None,
            "g_guess": None,
            "dim_ndim": None,
            "parameters": {"alpha_00": 1, "kernel": [kernel1, kernel2]},
            "inversion_time": 1.5,
            "initialization_time": 0.5,
        }

        _write_report_to_file(report_dict, parameters_to_file=False)

        content = (tmp_path / "test_report.txt").read_text()

        assert f"# Kernel name Dim 0 : {kernel1.name}" in content
        assert f"# Kernel name Dim 1 : {kernel2.name}" in content

    def test_write_report_to_file_parameters_section(self, tmp_path):
        """Verify parameters section is written correctly."""
        report_dict = {
            "filepath": tmp_path / "test_report.txt",
            "data": np.array([[1.0, 2.0], [3.0, 4.0]]),
            "t": [np.array([0.1, 0.2])],
            "tau": [np.array([1.0, 2.0])],
            "g": np.array([[1.0, 2.0], [3.0, 4.0]]),
            "fit": np.array([[1.1, 2.1], [3.1, 4.1]]),
            "residuals": np.array([[0.1, 0.1], [0.1, 0.1]]),
            "sigma": None,
            "g_guess": None,
            "dim_ndim": None,
            "parameters": {"alpha_00": 1, "maxloop": 100, "kernel": ilt.Exponential()},
            "inversion_time": 1.5,
            "initialization_time": 0.5,
        }

        _write_report_to_file(report_dict, parameters_to_file=False)

        content = (tmp_path / "test_report.txt").read_text()

        assert "# --- PARAMETERS ---" in content
        assert "'alpha_00': 1" in content
        assert "'maxloop': 100" in content

    def test_write_report_to_file_parameters_to_file_true(self, tmp_path):
        """Verify .param file is created when parameters_to_file=True."""
        report_dict = {
            "filepath": tmp_path / "test_report.txt",
            "data": np.array([[1.0, 2.0], [3.0, 4.0]]),
            "t": [np.array([0.1, 0.2])],
            "tau": [np.array([1.0, 2.0])],
            "g": np.array([[1.0, 2.0], [3.0, 4.0]]),
            "fit": np.array([[1.1, 2.1], [3.1, 4.1]]),
            "residuals": np.array([[0.1, 0.1], [0.1, 0.1]]),
            "sigma": None,
            "g_guess": None,
            "dim_ndim": None,
            "parameters": {"alpha_00": 1, "maxloop": 100, "kernel": ilt.Exponential()},
            "inversion_time": 1.5,
            "initialization_time": 0.5,
        }

        _write_report_to_file(report_dict, parameters_to_file=True)

        param_file = tmp_path / "test_report.param"
        assert param_file.exists()

        with open(param_file, "r") as f:
            loaded_params = json.load(f)

        assert loaded_params["alpha_00"] == 1
        assert loaded_params["maxloop"] == 100

    def test_write_report_to_file_removed_keys(self, tmp_path):
        """Verify certain keys are removed from parameters before writing."""
        report_dict = {
            "filepath": tmp_path / "test_report.txt",
            "data": np.array([[1.0, 2.0], [3.0, 4.0]]),
            "t": [np.array([0.1, 0.2])],
            "tau": [np.array([1.0, 2.0])],
            "g": np.array([[1.0, 2.0], [3.0, 4.0]]),
            "fit": np.array([[1.1, 2.1], [3.1, 4.1]]),
            "residuals": np.array([[0.1, 0.1], [0.1, 0.1]]),
            "sigma": None,
            "g_guess": None,
            "dim_ndim": None,
            "parameters": {
                "alpha_00": 1,
                "tau": [1, 2, 3],
                "kernel": ilt.Exponential(),
                "Cz": [0],
                "sigma": None,
                "dim_ndim": None,
                "g_guess": None,
            },
            "inversion_time": 1.5,
            "initialization_time": 0.5,
        }

        _write_report_to_file(report_dict, parameters_to_file=True)

        param_file = tmp_path / "test_report.param"
        with open(param_file, "r") as f:
            loaded_params = json.load(f)

        assert "tau" not in loaded_params
        assert "kernel" not in loaded_params
        assert "Cz" not in loaded_params
        assert "sigma" not in loaded_params
        assert "dim_ndim" not in loaded_params
        assert "g_guess" not in loaded_params

    def test_write_array_to_file_invalid_level(self, dummy_data_dict, tmp_path):
        """Verify ValueError for invalid level parameter."""
        test_iltdata = IltData(dummy_data_dict)

        with pytest.raises(ValueError, match="level must be one of 0, 1, or 2"):
            _write_array_to_file(test_iltdata, tmp_path / "test", level=3)

        with pytest.raises(ValueError, match="level must be one of 0, 1, or 2"):
            _write_array_to_file(test_iltdata, tmp_path / "test", level=-1)

    def test_write_array_to_file_level_0(self, dummy_data_dict, tmp_path):
        """Verify level 0 saves only np.ndarray attributes."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.g = np.array([1.0, 2.0, 3.0])
        test_iltdata.t = [np.array([0.1, 0.2, 0.3])]  # list of arrays - should NOT be saved at level 0

        _write_array_to_file(test_iltdata, tmp_path / "test", level=0)

        loaded = np.load(tmp_path / "test.npz")

        assert "g" in loaded
        assert "t_dim0" not in loaded  # lists should not be saved at level 0

    def test_write_array_to_file_level_1(self, dummy_data_dict, tmp_path):
        """Verify level 1 saves ndarray attributes AND lists of ndarrays."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.g = np.array([1.0, 2.0, 3.0])
        test_iltdata.t = [np.array([0.1, 0.2, 0.3]), np.array([1.0, 2.0, 3.0])]

        _write_array_to_file(test_iltdata, tmp_path / "test", level=1)

        loaded = np.load(tmp_path / "test.npz")

        assert "g" in loaded
        assert "t_dim0" in loaded
        assert "t_dim1" in loaded

    def test_write_array_to_file_level_2(self, dummy_data_dict, tmp_path):
        """Verify level 2 saves ndarrays, lists, AND sparse matrices."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.g = np.array([1.0, 2.0, 3.0])
        test_iltdata.t = [np.array([0.1, 0.2, 0.3])]
        test_iltdata.K0comp = csc_array([[1, 0], [0, 1]])

        _write_array_to_file(test_iltdata, tmp_path / "test", level=2)

        loaded = np.load(tmp_path / "test.npz")

        assert "g" in loaded
        assert "t_dim0" in loaded
        assert "K0comp" in loaded
        # Sparse matrix should be converted to dense
        assert loaded["K0comp"].shape == (2, 2)

    def test_write_array_to_file_creates_npz(self, dummy_data_dict, tmp_path):
        """Verify .npz file is created at correct location."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.g = np.array([1.0, 2.0, 3.0])

        _write_array_to_file(test_iltdata, tmp_path / "custom_name", level=0)

        assert (tmp_path / "custom_name.npz").exists()

    def test_write_array_to_file_list_naming_convention(self, dummy_data_dict, tmp_path):
        """Verify list elements are named correctly with _dim<index> suffix."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.t = [np.array([0.1, 0.2]), np.array([1.0, 2.0])]

        _write_array_to_file(test_iltdata, tmp_path / "test", level=1)

        loaded = np.load(tmp_path / "test.npz")

        assert "t_dim0" in loaded
        assert "t_dim1" in loaded

    def test_write_array_to_file_mixed_list_not_saved(self, dummy_data_dict, tmp_path):
        """Verify lists with non-ndarray elements are not saved."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.mixed_list = [np.array([1, 2]), "string"]  # Mixed list

        _write_array_to_file(test_iltdata, tmp_path / "test", level=1)

        loaded = np.load(tmp_path / "test.npz")

        assert "mixed_list_dim0" not in loaded
        assert "mixed_list_dim1" not in loaded

    ## These are already tested in test_workflows.py, but added here for completeness - Davis
    def test_full_report_workflow_1d(self, syn_ilt_data_1d, tmp_path):
        """Verify complete reporting workflow for 1D data."""
        syn_data_1D, t_syn, g_true = syn_ilt_data_1d

        ilt_1d = ilt.iltload(data=syn_data_1D, t=t_syn)
        tau = np.logspace(-10, 10, 50)
        ilt_1d.init(tau=tau, kernel=ilt.Exponential(), parameters={"maxloop": 4})
        ilt_1d.invert()

        report_path = tmp_path / "1d_report.txt"
        ilt_1d.report(filepath=str(report_path), save_arrays=True, parameters_to_file=True)

        assert (tmp_path / "1d_report.txt").exists()
        assert (tmp_path / "1d_report.npz").exists()
        assert (tmp_path / "1d_report.param").exists()

        # verify NPZ content
        loaded = np.load(tmp_path / "1d_report.npz")
        assert "g" in loaded
        assert "fit" in loaded

        # verify param file is valid JSON
        with open(tmp_path / "1d_report.param", "r") as f:
            params = json.load(f)
        assert "alpha_00" in params

    def test_full_report_workflow_2d(self, syn_ilt_data_pseudo_2d, tmp_path):
        """Verify complete reporting workflow for 2D data."""
        syn_data_2D, t_syn, g_true = syn_ilt_data_pseudo_2d

        ilt_2d = ilt.iltload(data=syn_data_2D, t=t_syn)
        ilt_2d.init(
            tau=np.logspace(-3, 6, 40),
            kernel=ilt.Exponential(),
            parameters={"maxloop": 4},
        )
        ilt_2d.invert()

        report_path = tmp_path / "2d_report.txt"
        ilt_2d.report(filepath=str(report_path), save_arrays=True, level=1)

        assert (tmp_path / "2d_report.txt").exists()
        assert (tmp_path / "2d_report.npz").exists()

        loaded = np.load(tmp_path / "2d_report.npz")
        assert "g" in loaded
        assert "t_dim0" in loaded
        assert "tau_dim0" in loaded
