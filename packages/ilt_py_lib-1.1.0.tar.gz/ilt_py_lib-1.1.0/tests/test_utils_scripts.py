import pytest
import json
import numpy as np
from iltpy.utils.scripts import _multidim_matmul, _generate_idx, _read_parameter_file
from iltpy.utils.scripts import (
    _ilt_movmax_diag,
    _generate_tau,
    _estimate_sparsity,
    compute_stats,
)
from iltpy.fit.inversion import IltData


class TestIltPyUtilsScripts:
    def test_generate_idx(self):
        """
        Test if indices are calculated correctly
        """

        ndim = 1
        assert _generate_idx(ndim) == [[0, 0]]

        ndim = 2
        assert _generate_idx(ndim) == [[0, 0], [1, 1], [0, 1], [1, 0]]

        ndim = 3
        assert _generate_idx(ndim) == [
            [0, 0],
            [1, 1],
            [2, 2],
            [0, 1],
            [1, 0],
            [0, 2],
            [2, 0],
            [1, 2],
            [2, 1],
        ]

    def test_generate_idx_ndim4(self):
        """Test ndim=4 generates correct index pairs."""
        result = _generate_idx(4)
        # should have diagonal pairs (0,0), (1,1), (2,2), (3,3)
        # and off-diagonal pairs for all combinations
        assert [0, 0] in result
        assert [1, 1] in result
        assert [2, 2] in result
        assert [3, 3] in result
        assert [0, 1] in result
        assert [1, 0] in result
        assert [0, 2] in result
        assert [2, 0] in result
        assert [0, 3] in result
        assert [3, 0] in result
        assert [1, 2] in result
        assert [2, 1] in result
        assert [1, 3] in result
        assert [3, 1] in result
        assert [2, 3] in result
        assert [3, 2] in result
        assert len(result) == 16  # 4 diagonal + 12 off-diagonal

    def test_ilt_movmax_diags(self):
        """Tests _ilt_movmax_diag computes moving maximum along diagonal for 2D array."""
        test_array = np.arange(1, 5)
        matdim = np.array([2, 2])
        nmx = 2
        dim = [0]

        diag_expected_out = np.array([2.0, 2.0, 4.0, 4.0])
        np.testing.assert_array_equal(
            _ilt_movmax_diag(test_array, matdim, nmx, dim), diag_expected_out
        )

    def test_ilt_movmax_diags_multi_xy(self):
        """Tests _ilt_movmax_diag with multiple dimensions specified."""
        test_array = np.arange(1, 5)
        matdim = np.array([2, 2])
        nmx = 2
        dim = [0, 1]

        diag_expected_out = np.array([4.0, 2.0, 3.0, 4.0])
        np.testing.assert_array_equal(
            _ilt_movmax_diag(test_array, matdim, nmx, dim), diag_expected_out
        )

    def test_movmax_nmx1(self):
        """Tests _ilt_movmax_diag returns original array when nmx=1."""
        test_array = np.arange(1, 5)
        matdim = np.array([2, 2])
        nmx = 1
        dim = [0]
        np.testing.assert_array_equal(
            _ilt_movmax_diag(test_array, matdim, nmx, dim), test_array
        )

    def test_movmax_nmx0(self):
        """Test nmx=0 returns original data (abs(nmx) <= 1)."""
        test_array = np.arange(1, 5)
        matdim = np.array([2, 2])
        nmx = 0
        dim = [0]
        np.testing.assert_array_equal(
            _ilt_movmax_diag(test_array, matdim, nmx, dim), test_array
        )

    def test_movmax_nmx_neg1(self):
        """Test nmx=-1 returns original data (abs(nmx) <= 1)."""
        test_array = np.arange(1, 5)
        matdim = np.array([2, 2])
        nmx = -1
        dim = [0]
        np.testing.assert_array_equal(
            _ilt_movmax_diag(test_array, matdim, nmx, dim), test_array
        )


    def test_movmax_length_mismatch(self):
        """Tests _ilt_movmax_diag raises ValueError when array length doesn't match matdim product."""
        test_array = np.arange(1, 5)
        matdim = np.array([2, 3])
        nmx = 2
        dim = [0]

        with pytest.raises(ValueError):
            _ilt_movmax_diag(test_array, matdim, nmx, dim)

    def test_movmax_diags_nmx(self):
        """Tests _ilt_movmax_diag with various nmx values (odd, even, negative)."""
        test_array = np.arange(1, 5)
        matdim = np.array([2, 2])
        nmx = 3
        dim = [0]
        diag_expected_out = np.array([2.0, 2.0, 4.0, 4.0])

        np.testing.assert_array_equal(
            _ilt_movmax_diag(test_array, matdim, nmx, dim), diag_expected_out
        )

        ## even, positive window size, nmx

        test_array = np.arange(1, 5)
        matdim = np.array([2, 2])
        nmx = 2
        dim = [0]

        diag_expected_out = np.array([2.0, 2.0, 4.0, 4.0])
        np.testing.assert_array_equal(
            _ilt_movmax_diag(test_array, matdim, nmx, dim), diag_expected_out
        )

        ## nmx negative
        test_array = np.arange(1, 5)
        matdim = np.array([2, 2])
        nmx = -2
        dim = [0]

        with pytest.raises(ValueError):
            _ilt_movmax_diag(test_array, matdim, nmx, dim)

    def test_movmax_diags_3D(self):
        """Tests _ilt_movmax_diag correctly handles 3D arrays."""
        test_array = (np.zeros((2, 2, 2)) + np.identity((2)) * 2.5).flatten()
        matdim = np.array([2, 2, 2])
        nmx = 2
        dim = [1, 1]
        diag_expected_out = np.array([2.5, 2.5, 0.0, 2.5, 2.5, 2.5, 0.0, 2.5])
        np.testing.assert_array_equal(
            _ilt_movmax_diag(test_array, matdim, nmx, dim), diag_expected_out
        )

    def test_multidim_M_1D(self):
        """Tests _multidim_matmul for 1D input array."""
        X = np.ones((5))
        xy = [np.ones((2, 5))]
        expected_out = np.array([5.0, 5.0])
        out = _multidim_matmul(X, xy)

        np.testing.assert_array_equal(out, expected_out)

    def test_multidim_M_2D(self):
        """Tests _multidim_matmul for 2D input array."""

        X = np.ones((5, 2))
        xy = [np.ones((5, 4)), np.ones((5, 2))]
        expected_out = np.array(
            [
                [10.0, 10.0, 10.0, 10.0],
                [10.0, 10.0, 10.0, 10.0],
                [10.0, 10.0, 10.0, 10.0],
                [10.0, 10.0, 10.0, 10.0],
                [10.0, 10.0, 10.0, 10.0],
            ]
        )
        out = _multidim_matmul(X, xy)

        np.testing.assert_array_equal(out, expected_out)

    def test_multidim_M_xy_scalar(self):
        """Tests _multidim_matmul when xy matrix is scalar (1x1)."""
        X = np.ones((3, 1))
        xy = [np.ones((1, 1))]
        expected_out = np.array([[1.0], [1.0], [1.0]])

        out = _multidim_matmul(X, xy)

        np.testing.assert_array_equal(out, expected_out)

    def test_multidim_M_nd(self):
        """Tests _multidim_matmul with n-dimensional arrays."""
        X = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
        xy = [np.array([[2]]), np.array([[2, 1, 1]])]
        expected_out = np.array([[14.0, 38.0, 62.0]])
        out = _multidim_matmul(X, xy)
        np.testing.assert_array_equal(out, expected_out)

    def test_multidim_M_2d_as_1d(self):
        """Test 2D array with one dimension being 1 is treated as 1D."""

        X = np.array([[1, 2, 3]])  # shape (1, 3), treated as 1D with x.shape[0]=1
        xy = [np.ones((2, 1))]  # shape (2, 1) matches x.shape[0]=1
        out = _multidim_matmul(X, xy)
        # Result should be (2, 3) from (2,1) @ (1,3)
        assert out.shape == (2, 3)

        X = np.array([[1], [2], [3]])  # shape (3, 1), treated as 1D with x.shape[0]=3
        xy = [np.ones((2, 3))]  # shape (2, 3) matches x.shape[0]=3
        # Result: (2, 3) @ (3, 1) = (2, 1)
        expected_out = np.array([[6.0], [6.0]])
        out = _multidim_matmul(X, xy)
        np.testing.assert_array_equal(out, expected_out)


    def test_multidim_M_dim_mismatch(self):
        """Tests _multidim_matmul raises ValueError for dimension mismatch."""
        X = np.ones((3, 1))
        xy = [np.ones((1, 4))]

        with pytest.raises(ValueError):
            _ = _multidim_matmul(X, xy)

    def test_generate_tau_tmin0(self):
        """Tests _generate_tau when t starts from 0."""
        t = np.arange(5)
        test_tau = _generate_tau(t)
        np.testing.assert_equal(
            test_tau, np.logspace(np.log10(1 / 1000), np.log10(4 * 100), 100)
        )

    def test_generate_tau(self):
        """Tests _generate_tau when t starts from non-zero value."""
        t = np.arange(2, 5)
        test_tau = _generate_tau(t)
        np.testing.assert_equal(
            test_tau, np.logspace(np.log10(2 / 1000), np.log10(4 * 100), 100)
        )

    def test_read_parameter_file(self, tmp_path):
        """Tests _read_parameter_file correctly reads JSON parameter file."""
        parameter_dict = {"alpha_00": 1000, "nn": True}

        with open(tmp_path / "parameter_file.json", "w") as f:
            json.dump(parameter_dict, f)

        test_dict = _read_parameter_file(str(tmp_path / "parameter_file.json"))

        assert test_dict == parameter_dict

    def test_estimate_sparsity(self):
        """Tests _estimate_sparsity correctly computes sparsity for various kernel matrices."""
        k_list = [np.ones((3, 3))]
        sparsity = _estimate_sparsity(k_list)
        pytest.approx(sparsity, 0.875)

        k_list = [np.zeros((3, 3))]
        sparsity = _estimate_sparsity(k_list)
        pytest.approx(sparsity, 1.0)

        A = np.array([[1, 0], [0, 0]])
        B = np.array([[1, 1], [0, 0]])
        k_list = [A, B]
        sparsity = _estimate_sparsity(k_list)
        pytest.approx(sparsity, 0.875)

        k_list = [np.array([[1, 0], [0, 1]])]  
        sparsity = _estimate_sparsity(k_list)
        assert sparsity == 0.5

    def test_compute_stats(self, dummy_data_dict):
        """Tests compute_stats correctly calculates mean, std, and confidence intervals."""
        g_results = np.array([[1.0, 2.0], [2.0, 3.0], [3.0, 4.0]])

        fit_results = np.array([[10.0, 10.0], [11.0, 11.0], [12.0, 12.0]])

        res_results = np.array([[-0.1, 0.1], [0.0, 0.0], [0.1, -0.1]])

        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.statistics = {
            "g_list": g_results,
            "fit_list": fit_results,
            "residuals_list": res_results,
        }

        compute_stats(test_iltdata)

        expected_g_mean = np.array([2.0, 3.0])
        np.testing.assert_allclose(test_iltdata.statistics["g_mean"], expected_g_mean)

        expected_fit_mean = np.array([11.0, 11.0])
        np.testing.assert_allclose(
            test_iltdata.statistics["fit_mean"], expected_fit_mean
        )

        expected_g_std = np.std(g_results, axis=0)
        np.testing.assert_allclose(test_iltdata.statistics["g_std"], expected_g_std)

        lower_bound = 2.0 - expected_g_std[0]
        upper_bound = 2.0 + expected_g_std[0]

        np.testing.assert_allclose(
            test_iltdata.statistics["g_conf_interval"][0][0], lower_bound
        )
        np.testing.assert_allclose(
            test_iltdata.statistics["g_conf_interval"][1][0], upper_bound
        )

        expected_residuals_mean = np.mean(res_results, axis=0)
        np.testing.assert_allclose(
            test_iltdata.statistics["residuals_mean"], expected_residuals_mean
        )

        expected_residuals_std = np.std(res_results, axis=0)
        np.testing.assert_allclose(
            test_iltdata.statistics["residuals_std"], expected_residuals_std
        )

        expected_fit_mean = np.mean(fit_results, axis=0)
        expected_fit_std = np.std(fit_results, axis=0)
        np.testing.assert_allclose(
            test_iltdata.statistics["fit_conf_interval"][0],
            expected_fit_mean - expected_fit_std,
        )
        np.testing.assert_allclose(
            test_iltdata.statistics["fit_conf_interval"][1],
            expected_fit_mean + expected_fit_std,
        )

    def test_compute_stats_missing_keys(self, dummy_data_dict):
        """Test compute_stats raises KeyError when required keys are missing."""
        test_iltdata = IltData(dummy_data_dict)
        test_iltdata.statistics = {
            "g_list": np.array([[1.0, 2.0]]),
        } # missing 'fit_list' and 'residuals_list'

        with pytest.raises(KeyError):
            compute_stats(test_iltdata)

    def test_read_parameter_file_not_found(self):
        """Test FileNotFoundError when parameter file does not exist."""
        with pytest.raises(FileNotFoundError):
            _read_parameter_file("non_existent_file.json")

    def test_read_parameter_file_invalid_json(self, tmp_path):
        """Test exception handling for invalid JSON content."""
        invalid_json_path = tmp_path / "invalid.json"
        with open(invalid_json_path, "w") as f:
            f.write("not valid json {")

        with pytest.raises(Exception):
            _read_parameter_file(str(invalid_json_path))


