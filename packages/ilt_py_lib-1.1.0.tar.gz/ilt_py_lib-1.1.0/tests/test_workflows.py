"""
These tests verify ILTpy workflows, including data loading,
parameter initialization, kernel construction, iterative inversion, and reporting.

To handle cross-platform numerical variance the following validation
strategies are employed:

1. True distribution retrieval Accuracy:
    * Measures the Normalized Root Mean Square Error (NRMSE) between the
      obtained distribution 'g' from noisy data and the ground truth generated in conftest.py
    * Differences of up to 5% are tolerated for uncompressed kernels.
    * Differences of up to 10% are tolerated for compressed kernels.

2. Standard deviation of Residual:
    * For a successful inversion this should match the SD of the added noise and should be close to 1.
    * This check is applied to 1D and pseudo-2D general workflow tests.
    * For sigma-weighted inversions, the weighted residual SD should be between 0.95 and 1.1.

3. Element wise comparison:
    * Uses element-wise comparison with a generous absolute tolerance (atol).
    * atol is scaled to 5% of the peak amplitude for standard tests.
    * atol is scaled to 10% of the peak amplitude for compressed kernel tests.

4. Specialized test criteria:
    * Non-negativity (nn) tests: verify negative features are suppressed.
    * Static baseline (sb) tests: verify baseline correction removes long-time constant artifacts.
    * Custom solver tests: verify user-defined solvers are correctly applied.
    * Sigma-weighted tests: verify artifact suppression and residual stabilization.

5. Failure Artifacts:
    * Pytest hooks are configured to capture the test state upon failure.
    * Artifacts (reports, .npz arrays, and comparison plots) are automatically
      copied from temporary directories and saved to a persistent 'data/' directory.
"""
# Tests for iltpy workflows

import pytest
import numpy as np
import iltpy as ilt
from scipy.sparse.linalg import spsolve
from copy import deepcopy
from scipy.ndimage import uniform_filter

class TestIltPyWorkflow1D:
    @pytest.mark.parametrize(
        "alt_g_in,maxloop_in", [(0, 100), (2, 10), (4, 10), (6, 10)]
    )
    def test_workflow_alt_g_general(
        self, alt_g_in, maxloop_in, syn_ilt_data_1d, tmp_path, request
    ):
        filename = f"1d_syn_data_workflow_alt_g{alt_g_in}"
        syn_data_1D, t_syn, g_true = syn_ilt_data_1d
        ilt_1d = ilt.iltload(data=syn_data_1D, t=t_syn)
        tau = np.logspace(-10, 10, 50)  # output sampling points
        ilt_1d.init(
            tau=tau,
            kernel=ilt.Exponential(),
            parameters={"alt_g": alt_g_in, "maxloop": maxloop_in},
        )
        ilt_1d.invert()
        ilt_1d.report(filepath=str(tmp_path / (filename + ".txt")), save_arrays=True)

        test_g = ilt_1d.g
        test_res = ilt_1d.residuals

        # for hooks
        request.node.test_g = ilt_1d.g
        request.node.g_true = g_true
        request.node.filename = filename

        assert np.linalg.norm(test_g - g_true) / np.linalg.norm(g_true) < 0.05
        assert 0.95 < np.std(test_res) < 1.05

        np.testing.assert_allclose(
            test_g, g_true, rtol=0.05, atol=np.max(g_true) * 0.05
        )

        assert (tmp_path / (filename + ".txt")).exists()
        assert (tmp_path / (filename + ".npz")).exists()


    def test_workflow_alt_g_iltstats(
        self, syn_ilt_data_1d, tmp_path, request
    ):
        filename = "1d_syn_data_workflow_iltstats_alt_g0"
        syn_data_1D, t_syn, g_true = syn_ilt_data_1d
        ilt_1d = ilt.iltload(data=syn_data_1D, t=t_syn)
        tau = np.logspace(-10, 10, 50)  # output sampling points
        ilt_1d.init(
            tau=tau,
            kernel=ilt.Exponential(),
            parameters={"alt_g": 0, "maxloop": 15},
        )
        ilt_1d.invert()
        ilt_1d.iltstats(n=5,random_seed=2505)
        ilt_1d.report(filepath=str(tmp_path / (filename + ".txt")), save_arrays=True)

        test_g = ilt_1d.statistics["g_mean"]

        # for hooks
        request.node.test_g = test_g
        request.node.g_true = g_true
        request.node.filename = filename

        np.testing.assert_allclose(
            test_g, g_true, rtol=0.05, atol=np.max(g_true) * 0.05
        )

        assert (tmp_path / (filename + ".txt")).exists()
        assert (tmp_path / (filename + ".npz")).exists()

    def test_workflow_with_nn_alt_g0(self, syn_ilt_data_1d, tmp_path, request):
        alt_g_in = 0
        maxloop_in = 100
        filename = f"1d_syn_data_workflow_with_nn_alt_g{alt_g_in}"
        syn_data_1D, t_syn, g_true = syn_ilt_data_1d
        ilt_1d = ilt.iltload(data=syn_data_1D, t=t_syn)
        tau = np.logspace(-10, 10, 50)  # output sampling points
        ilt_1d.init(
            tau=tau,
            kernel=ilt.Exponential(),
            parameters={
                "alt_g": alt_g_in,
                "maxloop": maxloop_in,
                "nn": True,
                "alpha_nn": 5000,
            },
        )
        ilt_1d.invert()
        ilt_1d.report(filepath=str(tmp_path / (filename + ".txt")), save_arrays=True)

        test_g = ilt_1d.g

        # for hooks
        request.node.test_g = ilt_1d.g
        request.node.g_true = g_true
        request.node.filename = filename

        assert (
            np.max(np.abs(test_g[30:40])) < 10
        )  # negative feature should be suppressed.
        assert (tmp_path / (filename + ".txt")).exists()
        assert (tmp_path / (filename + ".npz")).exists()

    def test_workflow_with_sb_alt_g0(self,syn_ilt_data_1d_with_sb,request):

        filename = "1d_syn_data_workflow_with_sb_alt_g0"
        
        syn_ilt_data_1d,t_syn = syn_ilt_data_1d_with_sb # inversion recovery like curve
        
        # with sb false
        ilt_1d_without_sb = ilt.iltload(data=syn_ilt_data_1d, t=t_syn)
        tau = np.logspace(-1, 5, 50) # output sampling points
        ilt_1d_without_sb.init(tau=tau, kernel=ilt.Exponential(),parameters={"maxloop":100,"sb":False})
        ilt_1d_without_sb.invert()
        g_true = ilt_1d_without_sb.g

        # now with sb true
        ilt_1d_with_sb = ilt.iltload(data=syn_ilt_data_1d, t=t_syn)
        tau = np.logspace(-1, 5, 50) # output sampling points
        ilt_1d_with_sb.init(tau=tau, kernel=ilt.Exponential(),parameters={"maxloop":100,"sb":True})
        ilt_1d_with_sb.invert()
        test_g = ilt_1d_with_sb.g

        # for hooks
        request.node.test_g = test_g
        request.node.g_true = g_true
        request.node.filename = filename
        
        # with sb = False, we should get a feature at long times contants
        # actual g is negative of the obtained g because this is inversion recovery
        region = -ilt_1d_without_sb.g[38:]
        assert np.min(region) < -40 # there should be a negative feature
        assert np.argmax(-ilt_1d_without_sb.g) == 28 # position of main feature

        # should be devoid of the negative feature
        region = -ilt_1d_with_sb.g[38:50]
        assert np.min(region) > -1
        assert ilt_1d_with_sb.g.size == 51 # one point should be added for the static baseline
        assert np.argmax(-ilt_1d_without_sb.g) == 28 # position of main feature should remain the same
        np.testing.assert_allclose(np.max(np.abs(region)),0,atol=1e-5)


class TestIltPyWorkflowPseudo2D:
    @pytest.mark.filterwarnings("ignore:Setting alt_g equal to 0")
    @pytest.mark.parametrize(
        "alt_g_in, maxloop_in",
        [
            (0, 15),
            pytest.param(0, 100, marks=pytest.mark.slow),
            pytest.param(2, 15, marks=pytest.mark.slow),
            pytest.param(4, 15, marks=pytest.mark.slow),
            pytest.param(6, 15, marks=pytest.mark.slow),
        ],
    )
    def test_workflow_alt_g_general(
        self, alt_g_in, maxloop_in, syn_ilt_data_pseudo_2d, tmp_path, request
    ):
        filename = f"pseudo2d_syn_data_workflow_alt_g{alt_g_in}"
        syn_data_pseudo_2D, t_syn, g_true = syn_ilt_data_pseudo_2d
        ilt_2d = ilt.iltload(data=syn_data_pseudo_2D, t=t_syn)
        ilt_2d.init(
            tau=np.logspace(-3, 6, 40),
            kernel=ilt.Exponential(),
            parameters={"alt_g": alt_g_in, "maxloop": maxloop_in},
        )

        ilt_2d.invert()
        ilt_2d.report(filepath=str(tmp_path / (filename + ".txt")), save_arrays=True)

        # for hooks
        request.node.test_g = ilt_2d.g
        request.node.g_true = g_true
        request.node.filename = filename

        assert np.linalg.norm(ilt_2d.g - g_true) / np.linalg.norm(g_true) < 0.05
        assert 0.95 < np.std(ilt_2d.residuals) < 1.05

        np.testing.assert_allclose(
            ilt_2d.g, g_true, rtol=0.05, atol=np.max(g_true) * 0.05
        )

        assert (tmp_path / (filename + ".txt")).exists()
        assert (tmp_path / (filename + ".npz")).exists()


    @pytest.mark.parametrize(
        "alt_g_in, maxloop_in",
        [
            (0, 15),
            pytest.param(0, 100, marks=pytest.mark.slow),
        ],
    )
    def test_workflow_alt_g_0_custom_solver(
        self, alt_g_in, maxloop_in, syn_ilt_data_pseudo_2d, tmp_path, request
    ):
        filename = f"pseudo2d_syn_data_workflow_alt_g_custom_solver{alt_g_in}"
        syn_data_pseudo_2D, t_syn, g_true = syn_ilt_data_pseudo_2d
        ilt_2d = ilt.iltload(data=syn_data_pseudo_2D, t=t_syn)
        ilt_2d.init(
            tau=np.logspace(-3, 6, 40),
            kernel=ilt.Exponential(),
            parameters={"alt_g": alt_g_in, "maxloop": maxloop_in},
        )

        def scipy_COLAMD_solver(A,b):
            return spsolve(A,b,permc_spec='COLAMD',use_umfpack=False)

        ilt_2d.invert(solver=scipy_COLAMD_solver)
        ilt_2d.report(filepath=str(tmp_path / (filename + ".txt")), save_arrays=True)

        # for hooks
        request.node.test_g = ilt_2d.g
        request.node.g_true = g_true
        request.node.filename = filename

        assert ilt_2d._solver_type == "user-defined"
        assert np.linalg.norm(ilt_2d.g - g_true) / np.linalg.norm(g_true) < 0.05
        assert 0.95 < np.std(ilt_2d.residuals) < 1.05

        np.testing.assert_allclose(
            ilt_2d.g, g_true, rtol=0.05, atol=np.max(g_true) * 0.05
        )

        assert (tmp_path / (filename + ".txt")).exists()
        assert (tmp_path / (filename + ".npz")).exists()

    @pytest.mark.filterwarnings("ignore:Setting alt_g equal to 0")
    @pytest.mark.parametrize(
        "alt_g_in, maxloop_in",
        [
            (0, 15),
            pytest.param(0, 100, marks=pytest.mark.slow),
            pytest.param(4, 15, marks=pytest.mark.slow),
        ],
    )
    def test_workflow_alt_g_sigma(
        self, alt_g_in, maxloop_in, syn_ilt_data_pseudo_2d_mnoise, tmp_path, request
    ):
        filename = f"pseudo2d_syn_data_workflow_sigma_alt_g{alt_g_in}"
        syn_data_pseudo_2D, t_syn, g_true = syn_ilt_data_pseudo_2d_mnoise
        ilt_2d = ilt.iltload(data=syn_data_pseudo_2D, t=t_syn)
        ilt_2d.init(
            tau=np.logspace(-1, 2, 40),
            kernel=ilt.Exponential(),
            parameters={"alt_g": alt_g_in, "maxloop": maxloop_in},
        )

        ilt_2d.invert()
        ilt_2d.report(filepath=str(tmp_path / (filename + ".txt")), save_arrays=True)

        # the first inversion should show, residuals with systematic features
        std_dim0,std_dim1 = (ilt_2d.residuals).std(axis=0).mean(),(ilt_2d.residuals).std(axis=1).mean()
        assert std_dim0 > 1.5
        assert std_dim1 > 1.5
        assert np.max(ilt_2d.g[5:15,:]) > 5 # there should be sharp artefact in the distribution in this region

        # weighted inversion
        ilt_2d_w = deepcopy(ilt_2d) # make a copy of the first IltData object
        sigma = np.sqrt(uniform_filter(ilt_2d.residuals**2,size=3,mode='constant')) # Estimate the weighting matrix from the residuals, size refers to window size.
        ilt_2d_w.init(sigma=sigma) # Intialize, rest of the parameters like tau, kernel is retained from the previous IltData object.
        ilt_2d_w.invert() # invert
        ilt_2d_w.report(filepath=str(tmp_path / (filename + "_weighted_1" + ".txt")), save_arrays=True)

        # the residuals should stabilise now
        std_dim0,std_dim1 = (ilt_2d_w.residuals/sigma).std(axis=0).mean(),(ilt_2d_w.residuals/sigma).std(axis=1).mean()
        assert 0.95 < std_dim0 < 1.1
        assert 0.95 < std_dim1 < 1.1
        assert np.max(ilt_2d_w.g[5:15,:]) < 2.5 # the sharp artefact should be gone


        assert (tmp_path / (filename + ".txt")).exists()
        assert (tmp_path / (filename + ".npz")).exists()
        assert (tmp_path / (filename + "_weighted_1" + ".txt")).exists()
        assert (tmp_path / (filename + "_weighted_1" + ".npz")).exists()

class TestIltPyWorkflow2D:
    @pytest.mark.filterwarnings("ignore:Setting alt_g equal to 6")
    @pytest.mark.parametrize(
        "alt_g_in, maxloop_in",
        [
            (6, 15),
            pytest.param(6, 100, marks=pytest.mark.slow),
            pytest.param(8, 15, marks=pytest.mark.slow),
            pytest.param(2, 15, marks=pytest.mark.slow),
            pytest.param(4, 15, marks=pytest.mark.slow),
            pytest.param(0, 15, marks=pytest.mark.slow),
        ],
    )
    def test_workflow_alt_g_general(
        self, alt_g_in, maxloop_in, syn_ilt_data_2d, request, tmp_path
    ):
        filename = f"2d_syn_data_workflow_alt_g{alt_g_in}"
        syn_data_2D, t_list, g_true = syn_ilt_data_2d
        ilt_2d = ilt.iltload(data=syn_data_2D, t=t_list)
        tau = [
            np.logspace(-4, 5, 50),
            np.logspace(-4, 5, 50),
        ]  # define output sampling for ILT

        ilt_2d.init(
            tau,
            kernel=[ilt.Exponential(), ilt.Exponential()],
            verbose=1,
            parameters={"alt_g": alt_g_in, "maxloop": maxloop_in},
        )
        ilt_2d.invert()

        if alt_g_in == 6:
            ilt_2d.report(
                filepath=str(tmp_path / (filename + ".txt")), save_arrays=True
            )
            assert (tmp_path / (filename + ".txt")).exists()
            assert (tmp_path / (filename + ".npz")).exists()

        # for hooks
        request.node.test_g = ilt_2d.g
        request.node.g_true = g_true
        request.node.filename = filename

        assert np.linalg.norm(ilt_2d.g - g_true) / np.linalg.norm(g_true) < 0.05

        np.testing.assert_allclose(
            ilt_2d.g, g_true, rtol=0.05, atol=np.max(g_true) * 0.05
        )

    @pytest.mark.filterwarnings("ignore:Setting alt_g equal to 6")
    @pytest.mark.parametrize(
        "alt_g_in, maxloop_in",
        [
            (6, 15),
            pytest.param(6, 100, marks=pytest.mark.slow),
            pytest.param(8, 15, marks=pytest.mark.slow),
            pytest.param(2, 15, marks=pytest.mark.slow),
            pytest.param(4, 15, marks=pytest.mark.slow),
            pytest.param(0, 15, marks=pytest.mark.slow),
        ],
    )
    def test_workflow_alt_g_compression(
        self, alt_g_in, maxloop_in, syn_ilt_data_2d, request, tmp_path
    ):
        filename = f"2d_syn_data_workflow_alt_g{alt_g_in}"
        syn_data_2D, t_list, g_true = syn_ilt_data_2d
        ilt_2d = ilt.iltload(data=syn_data_2D, t=t_list)
        tau = [
            np.logspace(-4, 5, 50),
            np.logspace(-4, 5, 50),
        ]  # define output sampling for ILT

        ilt_2d.init(
            tau,
            kernel=[ilt.Exponential(), ilt.Exponential()],
            verbose=1,
            parameters={"alt_g": alt_g_in, "maxloop": maxloop_in,"compress":[True,True],"s":[25,25]},
        )
        ilt_2d.invert()

        if alt_g_in == 6:
            ilt_2d.report(
                filepath=str(tmp_path / (filename + ".txt")), save_arrays=True
            )
            assert (tmp_path / (filename + ".txt")).exists()
            assert (tmp_path / (filename + ".npz")).exists()

        # for hooks
        request.node.test_g = ilt_2d.g
        request.node.g_true = g_true
        request.node.filename = filename

        assert (
            np.linalg.norm(np.sum(ilt_2d.g, axis=0) - np.sum(g_true, axis=0))
            / np.linalg.norm(np.sum(g_true, axis=0))
            < 0.05
        )
        assert (
            np.linalg.norm(np.sum(ilt_2d.g, axis=1) - np.sum(g_true, axis=1))
            / np.linalg.norm(np.sum(g_true, axis=1))
            < 0.05
        )
        assert np.linalg.norm(ilt_2d.g - g_true) / np.linalg.norm(g_true) < 0.1

        np.testing.assert_allclose(
            ilt_2d.g, g_true, rtol=0.1, atol=np.max(g_true) * 0.1
        )
