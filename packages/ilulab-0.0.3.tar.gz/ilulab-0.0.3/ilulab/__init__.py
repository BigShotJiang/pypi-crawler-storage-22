"""ilulab - Lightweight ML experiment tracking client."""

from ilulab.client import IlulabClient, Run

__version__ = "0.0.2"
__all__ = ["IlulabClient", "Run"]
