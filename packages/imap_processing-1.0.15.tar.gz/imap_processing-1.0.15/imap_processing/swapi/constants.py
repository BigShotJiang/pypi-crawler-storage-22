"""Constants for SWAPI processing."""

NUM_PACKETS_PER_SWEEP = 12
NUM_ENERGY_STEPS = 72
