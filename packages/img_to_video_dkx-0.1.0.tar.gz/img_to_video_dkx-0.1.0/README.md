# img-to-video-dkx

图片转视频 MCP Server - 基于百度千帆 viduq2-turbo 模型

## 功能特性

- **MCP Protocol**: 完全兼容 Model Context Protocol
- **图片转视频**: 使用百度千帆 viduq2-turbo 模型
- **OSS 集成**: 自动上传图片到阿里云 OSS
- **异步处理**: 后台生成视频，任务状态追踪

## 安装

```bash
# 从 PyPI 安装
pip install img-to-video-dkx

# 从源码安装
pip install .
```

## 快速开始

### 配置环境变量

```bash
# 百度千帆 API
export QIANFAN_API_KEY=your_api_key
export QIANFAN_APPID=your_appid

# 阿里云 OSS
export ALIYUN_ACCESS_KEY_ID=your_access_key
export ALIYUN_ACCESS_KEY_SECRET=your_access_secret
export ALIYUN_OSS_ENDPOINT=oss-cn-hangzhou.aliyuncs.com
export ALIYUN_OSS_BUCKET=your_bucket_name
```

### 启动服务

```bash
# 使用命令行入口
img-to-video-mcp

# 或直接运行
python -m img_to_video_dkx.server
```

## MCP Tools

### generate_video_from_image

将静态图片转换为动态视频。

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| image_base64 | str | 必需 | 图片的 Base64 编码 |
| prompt | str | "嘴巴动起来" | 视频动作描述 |
| duration | int | 4 | 视频时长（秒） |
| resolution | str | "1080p" | 分辨率 |
| movement_amplitude | str | "auto" | 运动幅度 |

### check_video_status

查询视频生成任务状态。

| 参数 | 类型 | 说明 |
|------|------|------|
| task_id | str | 任务 ID |

## 数据流

```
MCP 请求 → 图片上传 OSS → viduq2-turbo API → 返回视频 URL
```

## License

MIT
