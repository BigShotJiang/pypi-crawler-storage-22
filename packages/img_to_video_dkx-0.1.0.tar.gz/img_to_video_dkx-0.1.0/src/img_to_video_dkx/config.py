import os

# 千帆 API 配置（需申请 API Key）
QIANFAN_API_KEY = os.getenv("QIANFAN_API_KEY")
QIANFAN_APPID = os.getenv("QIANFAN_APPID")

# Aliyun OSS 配置
ALIYUN_ACCESS_KEY_ID = os.getenv("ALIYUN_ACCESS_KEY_ID")
ALIYUN_ACCESS_KEY_SECRET = os.getenv("ALIYUN_ACCESS_KEY_SECRET")
ALIYUN_OSS_ENDPOINT = os.getenv("ALIYUN_OSS_ENDPOINT", "oss-cn-hangzhou.aliyuncs.com")
ALIYUN_OSS_BUCKET = os.getenv("ALIYUN_OSS_BUCKET")

# 本地存储
OUTPUT_DIR = "./output"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# 模型默认参数
DEFAULT_PROMPT = os.getenv("DEFAULT_PROMPT", "嘴巴动起来")
DEFAULT_DURATION = int(os.getenv("DEFAULT_DURATION", "4"))
DEFAULT_RESOLUTION = os.getenv("DEFAULT_RESOLUTION", "1080p")
DEFAULT_MOVEMENT_AMPLITUDE = os.getenv("DEFAULT_MOVEMENT_AMPLITUDE", "auto")
DEFAULT_MODEL = os.getenv("DEFAULT_MODEL", "viduq2-turbo")