#!/usr/bin/env python3
import asyncio
import tempfile
import os
import sys
from pathlib import Path

# 添加项目根目录到路径，确保模块导入正确
PROJECT_ROOT = Path(__file__).parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from mcp.server.fastmcp import FastMCP

from img_to_video_dkx.config import (
    DEFAULT_PROMPT, DEFAULT_DURATION, DEFAULT_RESOLUTION,
    DEFAULT_MOVEMENT_AMPLITUDE, DEFAULT_MODEL
)
from img_to_video_dkx.task_manager import task_manager
from img_to_video_dkx.video_generator import video_generator
from img_to_video_dkx.utils.aliyun_oss import upload_local_file_with_auto_path
from img_to_video_dkx.utils.logger import logger

# MCP Server 实例
app = FastMCP("image-to-video")


@app.tool()
async def generate_video_from_image(
    image_path: str,
    prompt: str = DEFAULT_PROMPT,
    duration: int = DEFAULT_DURATION,
    resolution: str = DEFAULT_RESOLUTION,
    movement_amplitude: str = DEFAULT_MOVEMENT_AMPLITUDE,
) -> str:
    """
    将静态图片转换为动态视频。

    注意：视频生成需要 30-120 秒，此工具会立即返回任务ID，需配合 check_video_status 查询结果。

    Args:
        image_path: 图片文件路径（支持绝对路径或相对路径）
        prompt: 描述视频动作，如'人物微笑挥手'、'树叶随风飘动'
        duration: 视频时长（秒）
        resolution: 视频分辨率，如 "1080p"
        movement_amplitude: 运动幅度，如 "auto"
    """
    # 验证文件是否存在
    if not os.path.isfile(image_path):
        return f"❌ 文件不存在: {image_path}"

    # 检查文件大小
    file_size = os.path.getsize(image_path)
    if file_size > 10 * 1024 * 1024:  # 10MB 限制
        return "❌ 图片大小超过 10MB 限制"

    # 验证文件扩展名
    valid_extensions = {'.jpg', '.jpeg', '.png', '.webp'}
    file_ext = Path(image_path).suffix.lower()
    if file_ext not in valid_extensions:
        return f"❌ 不支持的文件格式: {file_ext}，支持的格式: {', '.join(valid_extensions)}"

    # 创建任务
    task_id = task_manager.create_task(
        image_path=image_path,
        prompt=prompt,
        duration=duration,
        resolution=resolution,
        movement_amplitude=movement_amplitude,
        model_name=DEFAULT_MODEL
    )

    logger.info(f"Task created: {task_id}")

    # 启动后台处理任务
    asyncio.create_task(_process_video_task(task_id))

    # 立即返回任务ID（防止 MCP 超时）
    return f"""✅ 视频生成任务已提交！

📋 任务ID: `{task_id}`
⏱️  预计耗时: 30-120 秒
📝 动作描述: {prompt}
📐 分辨率: {resolution}
⏱️  时长: {duration}秒
🎚️  运动幅度: {movement_amplitude}

请使用 `check_video_status` 工具查询进度，建议 30 秒后查询。"""


@app.tool()
async def check_video_status(task_id: str) -> str:
    """
    查询视频生成任务的状态和结果。

    Args:
        task_id: generate_video_from_image 返回的任务ID
    """
    try:
        task = task_manager.get_task(task_id)

        if not task:
            return f"❌ 未找到任务: {task_id}"

        status = task.get("status")

        if status == "queued":
            return f"⏳ 任务 `{task_id}` 正在排队等待处理..."

        elif status == "processing":
            return f"🎬 任务 `{task_id}` 正在生成视频中，请稍后再查..."

        elif status == "completed":
            video_url = task.get("video_url")
            return f"""✅ 任务完成！

🎥 视频链接: {video_url}
📥 可直接下载或预览

任务ID: `{task_id}`"""

        elif status == "failed":
            error = task.get("error", "未知错误")
            return f"❌ 任务失败: {error}\n任务ID: `{task_id}`"

        else:
            return f"❓ 未知状态: {status}"

    except Exception as e:
        logger.error(f"Error checking task status: {e}")
        return f"❌ 查询失败: {str(e)}"


async def _process_video_task(task_id: str):
    """后台处理视频生成任务"""
    try:
        logger.info(f"Starting video processing for task: {task_id}")

        # 获取任务信息
        task = task_manager.get_task(task_id)
        if not task:
            logger.error(f"Task not found: {task_id}")
            return

        # 更新状态为处理中
        task_manager.update_task(task_id, "processing")

        # 读取图片文件
        image_path = task["image_path"]
        with open(image_path, "rb") as f:
            image_bytes = f.read()

        # 保存临时文件用于上传
        with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as tmp_file:
            tmp_file.write(image_bytes)
            tmp_file_path = tmp_file.name

        try:
            # 上传到 OSS
            logger.info(f"Uploading image to OSS for task: {task_id}")
            image_url = upload_local_file_with_auto_path(tmp_file_path)
            logger.info(f"Image uploaded to: {image_url}")

            # 生成视频
            logger.info(f"Generating video for task: {task_id}")
            video_url, api_response = await video_generator.generate_video(
                image_url=image_url,
                prompt=task["prompt"],
                duration=task["duration"],
                resolution=task["resolution"],
                movement_amplitude=task["movement_amplitude"]
            )

            # 更新任务状态为完成
            task_manager.update_task(task_id, "completed", video_url=video_url, api_response=api_response)

            # 保存 API 响应到文件
            task_manager.save_api_response(task_id, api_response)

            logger.info(f"Task completed: {task_id} -> {video_url}")

        finally:
            # 清理临时文件
            if os.path.exists(tmp_file_path):
                os.unlink(tmp_file_path)

    except Exception as e:
        logger.error(f"Error processing video task {task_id}: {e}")
        task_manager.update_task(task_id, "failed", error=str(e))


async def main():
    """MCP Server 入口"""
    # 启动任务管理器的清理任务
    await task_manager.start()

    try:
        await app.run_stdio_async()
    finally:
        # 停止任务管理器的清理任务
        await task_manager.stop()


if __name__ == "__main__":
    asyncio.run(main())
