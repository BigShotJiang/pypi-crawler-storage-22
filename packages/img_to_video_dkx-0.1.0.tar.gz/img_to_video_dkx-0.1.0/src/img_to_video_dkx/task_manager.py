import asyncio
import json
import time
from pathlib import Path
from typing import Dict, Optional, Any


class TaskManager:
    """In-memory task storage manager"""

    def __init__(self):
        self.tasks: Dict[str, Dict[str, Any]] = {}
        self._cleanup_task = None

    async def start(self):
        """Start the cleanup background task"""
        self._cleanup_task = asyncio.create_task(self._cleanup_old_tasks())

    async def stop(self):
        """Stop the cleanup background task"""
        if self._cleanup_task:
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass

    def create_task(self, image_path: str, prompt: str, duration: int, resolution: str,
                    movement_amplitude: str, model_name: str) -> str:
        """Create a new task and return task_id"""
        import uuid
        task_id = f"vid_{uuid.uuid4().hex[:12]}"

        self.tasks[task_id] = {
            "task_id": task_id,
            "status": "queued",
            "image_path": image_path,
            "prompt": prompt,
            "duration": duration,
            "resolution": resolution,
            "movement_amplitude": movement_amplitude,
            "model_name": model_name,
            "created_at": time.time(),
            "video_url": None,
            "error": None
        }

        return task_id

    def update_task(self, task_id: str, status: str, video_url: Optional[str] = None,
                    error: Optional[str] = None, api_response: Optional[dict] = None):
        """Update task status"""
        if task_id not in self.tasks:
            raise ValueError(f"Task not found: {task_id}")

        task = self.tasks[task_id]
        task["status"] = status

        if video_url:
            task["video_url"] = video_url

        if error:
            task["error"] = error

        if api_response:
            task["api_response"] = api_response

        if status in ["completed", "failed"]:
            task["completed_at"] = time.time()

    def save_api_response(self, task_id: str, api_response: dict):
        """Save API response to JSON file"""
        output_dir = Path("./media/output")
        output_dir.mkdir(parents=True, exist_ok=True)

        filepath = output_dir / f"{task_id}.json"
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(api_response, f, ensure_ascii=False, indent=2)

    def get_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        """Get task by task_id"""
        return self.tasks.get(task_id)

    def get_all_tasks(self) -> Dict[str, Dict[str, Any]]:
        """Get all tasks"""
        return self.tasks.copy()

    async def _cleanup_old_tasks(self):
        """Background task to clean up old completed/failed tasks"""
        while True:
            try:
                await asyncio.sleep(3600)  # Run every hour

                current_time = time.time()
                tasks_to_remove = []

                for task_id, task in self.tasks.items():
                    # Remove tasks older than 24 hours
                    if current_time - task["created_at"] > 86400:
                        tasks_to_remove.append(task_id)

                for task_id in tasks_to_remove:
                    del self.tasks[task_id]

                if tasks_to_remove:
                    print(f"Cleaned up {len(tasks_to_remove)} old tasks")

            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"Error in cleanup task: {e}")


# Global task manager instance
task_manager = TaskManager()
