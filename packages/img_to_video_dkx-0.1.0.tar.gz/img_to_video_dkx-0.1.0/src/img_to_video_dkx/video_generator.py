import asyncio
from typing import Tuple, Optional
from .utils.QianfanVideoProModel import QianfanVideoProModel
from .utils.logger import logger


class VideoGenerator:
    """Video generation service using viduq2-turbo"""

    def __init__(self):
        self.model = QianfanVideoProModel(model="viduq2-turbo", type="img2video")

    async def generate_video(
            self,
            image_url: str,
            prompt: str,
            duration: int,
            resolution: str,
            movement_amplitude: str
    ) -> Tuple[str, dict]:
        """
        Generate video using viduq2-turbo model

        Args:
            image_url: Public URL of the input image
            prompt: Video generation prompt
            duration: Video duration in seconds
            resolution: Video resolution (e.g., "1080p")
            movement_amplitude: Movement amplitude (e.g., "auto")

        Returns:
            Tuple of (video_url, api_response)

        Raises:
            Exception: If video generation fails
        """
        try:
            logger.info(f"Starting video generation with viduq2-turbo")
            logger.info(f"Parameters: prompt='{prompt}', duration={duration}, "
                       f"resolution='{resolution}', movement_amplitude='{movement_amplitude}'")

            # Prepare model parameters
            images = [image_url]

            # Call the synchronous method in a thread pool to avoid blocking
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(
                None,
                self.model.gen_img2video_vidu,
                prompt,
                images,
                duration,
                resolution,
                movement_amplitude
            )

            video_url, response = result

            if not video_url:
                error_msg = f"Video generation failed: {response}"
                logger.error(error_msg)
                raise Exception(error_msg)

            logger.info(f"Video generated successfully: {video_url}")
            return video_url, response

        except Exception as e:
            logger.error(f"Video generation error: {str(e)}")
            raise


# Global video generator instance
video_generator = VideoGenerator()
