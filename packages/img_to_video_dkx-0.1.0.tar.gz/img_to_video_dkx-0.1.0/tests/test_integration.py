#!/usr/bin/env python3
"""
集成测试 - 测试 MCP Server 的完整功能
通过直接测试 server.py 中的处理函数来验证功能
"""
import asyncio
import sys
from pathlib import Path

# 添加项目根目录到 Python 路径
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from img_to_video_dkx.task_manager import task_manager
from img_to_video_dkx.video_generator import video_generator
from img_to_video_dkx.utils.aliyun_oss import upload_local_file_with_auto_path
from mcp.types import TextContent

# 测试图片路径
TEST_IMAGE_PATH = Path(__file__).parent.parent / "media" / "input" / "test.jpg"


async def test_task_manager():
    """测试任务管理器 - 核心功能"""
    print("=" * 60)
    print("🧪 测试任务管理器 (集成测试)")
    print("=" * 60)

    # 创建任务
    task_id = task_manager.create_task(
        image_path=str(TEST_IMAGE_PATH),
        prompt="让嘴巴动起来",
        duration=4,
        resolution="1080p",
        movement_amplitude="auto",
        model_name="viduq2-turbo"
    )

    print(f"✅ 创建任务: {task_id}")

    # 获取任务
    task = task_manager.get_task(task_id)
    assert task is not None, "任务应该存在"
    print(f"✅ 获取任务成功: {task['task_id']}")

    # 更新状态
    task_manager.update_task(task_id, "processing")
    task = task_manager.get_task(task_id)
    assert task["status"] == "processing", "状态应该是 processing"
    print(f"✅ 更新状态为 processing")

    # 完成任务
    task_manager.update_task(task_id, "completed", video_url="https://example.com/video.mp4")
    task = task_manager.get_task(task_id)
    assert task["status"] == "completed", "状态应该是 completed"
    assert task["video_url"] == "https://example.com/video.mp4", "应该有视频URL"
    print(f"✅ 任务完成，视频URL: {task['video_url']}")

    print("\n✅ 任务管理器集成测试通过！")
    return task_id


async def test_video_generator_init():
    """测试视频生成器初始化"""
    print("\n" + "=" * 60)
    print("🧪 测试视频生成器初始化")
    print("=" * 60)

    # 验证视频生成器已正确初始化
    assert video_generator is not None, "video_generator 应该已初始化"
    assert video_generator.model is not None, "model 应该已初始化"

    print(f"✅ 视频生成器初始化成功")
    print(f"   模型: {video_generator.model.model}")
    print(f"   类型: {video_generator.model.type}")

    print("\n✅ 视频生成器初始化测试通过！")


async def test_full_flow():
    """测试完整流程"""
    print("\n" + "=" * 60)
    print("🧪 测试完整流程 (Full Flow)")
    print("=" * 60)

    # 1. 检查测试图片是否存在
    if not TEST_IMAGE_PATH.exists():
        print(f"\n❌ 测试图片不存在: {TEST_IMAGE_PATH}")
        print("   请将测试图片放置到该路径后重新运行")
        return None

    print(f"\n📁 使用测试图片: {TEST_IMAGE_PATH}")

    # 读取图片
    with open(TEST_IMAGE_PATH, "rb") as f:
        image_bytes = f.read()

    print(f"   图片大小: {len(image_bytes) / 1024:.1f} KB")

    # 2. 创建任务
    print("\n1️⃣ 创建任务...")
    task_id = task_manager.create_task(
        image_path=str(TEST_IMAGE_PATH),
        prompt="让嘴巴动起来",
        duration=5,
        resolution="1080p",
        movement_amplitude="auto",
        model_name="viduq2-turbo"
    )
    print(f"   ✅ 任务创建: {task_id}")

    # 3. 模拟后台处理 - 上传到 OSS
    print("\n2️⃣ 上传图片到 OSS...")
    from img_to_video_dkx.server import _process_video_task
    task_manager.update_task(task_id, "processing")
    print(f"   ✅ 状态更新为 processing")

    # 这里会真正调用上传和视频生成
    print("\n3️⃣ 启动真实视频生成 (这可能需要 30-120 秒)...")
    print("   请耐心等待...")

    # 直接调用处理函数进行真实测试
    await _process_video_task(task_id)

    # 4. 查询结果
    print("\n4️⃣ 查询结果...")
    task = task_manager.get_task(task_id)
    print(f"   ✅ 任务状态: {task['status']}")

    if task['status'] == 'completed':
        print(f"   ✅ 视频URL: {task['video_url']}")
    elif task['status'] == 'failed':
        print(f"   ❌ 错误信息: {task.get('error', '未知错误')}")
    else:
        print(f"   ❓ 未知状态: {task['status']}")

    print("\n" + "=" * 60)
    if task['status'] == 'completed':
        print(f"🎉 真实视频生成测试完成！")
        print(f"📥 视频下载: {task['video_url']}")
    else:
        print(f"❌ 视频生成失败: {task.get('error', '未知错误')}")
    print("=" * 60)

    return task_id


async def main():
    """主测试函数"""
    print("🚀 开始集成测试")
    print("=" * 60)

    try:
        # 启动任务管理器
        await task_manager.start()

        # 测试 1: 任务管理器 (虚拟测试)
        await test_task_manager()

        # 测试 2: 视频生成器初始化
        await test_video_generator_init()

        # 测试 3: 完整流程 (真实测试)
        print("\n" + "=" * 60)
        print("⚠️  注意: 以下将进行真实 API 调用")
        print("=" * 60)
        await test_full_flow()

        # 停止任务管理器
        await task_manager.stop()

        print("\n" + "=" * 60)
        print("🎉 所有集成测试完成！")
        print("=" * 60)

    except Exception as e:
        print(f"\n❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
