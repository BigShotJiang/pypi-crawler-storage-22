#!/usr/bin/env python3
"""
测试新的 MCP Server 实现 - 测试内存任务管理和视频生成流程
"""
import asyncio
import sys
from pathlib import Path


from img_to_video_dkx.task_manager import task_manager
from img_to_video_dkx.video_generator import video_generator
from img_to_video_dkx.utils.aliyun_oss import upload_local_file_with_auto_path


async def test_task_manager():
    """测试任务管理器"""
    print("=" * 60)
    print("🧪 测试任务管理器 (Task Manager)")
    print("=" * 60)

    # 创建任务
    task_id = task_manager.create_task(
        image_path="/tmp/test_image.jpg",
        prompt="测试提示词",
        duration=4,
        resolution="1080p",
        movement_amplitude="auto",
        model_name="viduq2-turbo"
    )

    print(f"✅ 创建任务: {task_id}")

    # 获取任务
    task = task_manager.get_task(task_id)
    print(f"✅ 获取任务: {task['task_id']}")
    print(f"   状态: {task['status']}")
    print(f"   提示词: {task['prompt']}")

    # 更新任务状态
    task_manager.update_task(task_id, "processing")
    task = task_manager.get_task(task_id)
    print(f"✅ 更新状态为 processing: {task['status']}")

    # 完成任务
    task_manager.update_task(task_id, "completed", video_url="https://example.com/video.mp4")
    task = task_manager.get_task(task_id)
    print(f"✅ 更新状态为 completed: {task['status']}")
    print(f"   视频URL: {task['video_url']}")

    # 获取所有任务
    all_tasks = task_manager.get_all_tasks()
    print(f"✅ 获取所有任务: {len(all_tasks)} 个任务")

    print("\n" + "=" * 60)
    print("✅ 任务管理器测试完成！")
    print("=" * 60)


async def test_oss_upload():
    """测试 OSS 上传"""
    print("\n" + "=" * 60)
    print("🧪 测试 OSS 上传")
    print("=" * 60)

    # 创建测试图片
    test_image_path = "/tmp/test_image.jpg"

    # 创建一个简单的测试图片（1x1 像素的红色图片）
    from PIL import Image
    import io

    img = Image.new('RGB', (100, 100), color='red')
    img.save(test_image_path)

    try:
        # 上传到 OSS
        print(f"📤 上传测试图片: {test_image_path}")
        image_url = upload_local_file_with_auto_path(test_image_path)
        print(f"✅ 上传成功: {image_url}")

        return image_url

    except Exception as e:
        print(f"❌ 上传失败: {e}")
        return None

    finally:
        # 清理临时文件
        import os
        if os.path.exists(test_image_path):
            os.remove(test_image_path)


async def test_video_generator():
    """测试视频生成器"""
    print("\n" + "=" * 60)
    print("🧪 测试视频生成器 (Video Generator)")
    print("=" * 60)

    # 注意：这个测试需要真实的图片 URL 和 API 密钥
    # 这里只是演示如何调用

    print("⚠️  注意: 这个测试需要真实的图片 URL 和 API 密钥")
    print("   跳过实际 API 调用，只测试初始化")

    # 测试初始化
    print(f"✅ 视频生成器初始化成功")
    print(f"   模型: {video_generator.model.model}")
    print(f"   类型: {video_generator.model.type}")

    print("\n" + "=" * 60)
    print("✅ 视频生成器测试完成！")
    print("=" * 60)


async def test_full_flow():
    """测试完整流程"""
    print("\n" + "=" * 60)
    print("🧪 测试完整流程 (Full Flow)")
    print("=" * 60)

    # 1. 创建任务
    print("\n1️⃣ 创建任务...")
    task_id = task_manager.create_task(
        image_path="/tmp/test_image.jpg",
        prompt="测试完整流程",
        duration=4,
        resolution="1080p",
        movement_amplitude="auto",
        model_name="viduq2-turbo"
    )
    print(f"   ✅ 任务创建: {task_id}")

    # 2. 模拟后台处理
    print("\n2️⃣ 模拟后台处理...")
    task_manager.update_task(task_id, "processing")
    print(f"   ✅ 状态更新为 processing")

    # 模拟处理时间
    await asyncio.sleep(1)

    # 3. 完成任务
    print("\n3️⃣ 完成任务...")
    task_manager.update_task(task_id, "completed", video_url="https://example.com/test_video.mp4")
    print(f"   ✅ 状态更新为 completed")

    # 4. 查询结果
    print("\n4️⃣ 查询结果...")
    task = task_manager.get_task(task_id)
    print(f"   ✅ 任务状态: {task['status']}")
    print(f"   ✅ 视频URL: {task['video_url']}")

    print("\n" + "=" * 60)
    print("✅ 完整流程测试完成！")
    print("=" * 60)


async def main():
    """主测试函数"""
    print("🚀 开始测试 MCP Server 新实现")
    print("=" * 60)

    try:
        # 测试 1: 任务管理器
        await test_task_manager()

        # 测试 2: OSS 上传（可选）
        # await test_oss_upload()

        # 测试 3: 视频生成器（需要 API 密钥）
        await test_video_generator()

        # 测试 4: 完整流程
        await test_full_flow()

        print("\n" + "=" * 60)
        print("🎉 所有测试完成！")
        print("=" * 60)

    except Exception as e:
        print(f"\n❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())
