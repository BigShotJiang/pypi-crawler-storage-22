"""
Imhotep CLI entry point.

Usage: imhotep <command> [options]
"""

import argparse
import sys

from .commands import (
    cmd_init,
    cmd_whoami,
    cmd_create_agent,
    cmd_identities,
    cmd_search,
    cmd_send,
    cmd_inbox,
    cmd_ack,
    cmd_threads,
    cmd_thread,
    cmd_upload,
    cmd_profile,
)


def build_parser():
    parser = argparse.ArgumentParser(
        prog="imhotep",
        description="Imhotep CLI — messaging for personal software",
    )
    parser.add_argument(
        "--identity", "-i",
        help="Override the configured identity for this command",
    )

    sub = parser.add_subparsers(dest="command")

    # init
    p = sub.add_parser("init", help="Set up Imhotep — connect and generate local keys")
    p.add_argument("--api-key", help="Your API key (or set IMHOTEP_API_KEY env var)")
    p.add_argument("--base-url", help="Server URL (default: http://localhost:8000)")

    # whoami
    sub.add_parser("whoami", help="Show current configuration and identity")

    # create-agent
    p = sub.add_parser("create-agent", help="Create an agent identity")
    p.add_argument("suffix", help="Agent suffix (e.g. 'research-agent')")

    # identities
    sub.add_parser("identities", help="List your identities")

    # search
    p = sub.add_parser("search", help="Search the identity directory")
    p.add_argument("query", help="Search query")

    # send
    p = sub.add_parser("send", help="Send a text message")
    p.add_argument("to", help="Recipient alias (e.g. 'bob@imhotep')")
    p.add_argument("message", help="Message text")

    # inbox
    sub.add_parser("inbox", help="Check pending messages")

    # ack
    p = sub.add_parser("ack", help="Acknowledge an envelope")
    p.add_argument("id", help="Envelope ID")

    # threads
    sub.add_parser("threads", help="List your threads")

    # thread
    p = sub.add_parser("thread", help="Show a thread with messages")
    p.add_argument("id", help="Thread ID")

    # upload
    p = sub.add_parser("upload", help="Upload a file")
    p.add_argument("file", help="Path to file")

    # profile
    p = sub.add_parser("profile", help="Look up a public identity")
    p.add_argument("alias", help="Identity alias (e.g. 'bob@imhotep')")

    return parser


DISPATCH = {
    "init": cmd_init,
    "whoami": cmd_whoami,
    "create-agent": cmd_create_agent,
    "identities": cmd_identities,
    "search": cmd_search,
    "send": cmd_send,
    "inbox": cmd_inbox,
    "ack": cmd_ack,
    "threads": cmd_threads,
    "thread": cmd_thread,
    "upload": cmd_upload,
    "profile": cmd_profile,
}


def main():
    parser = build_parser()
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    handler = DISPATCH.get(args.command)
    if handler:
        handler(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
