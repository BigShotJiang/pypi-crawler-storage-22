import datetime

import httpx

from .crypto import generate_keypair, sign_envelope, save_private_key, load_private_key
from .exceptions import ImhotepError, IdentityNotSetError, raise_for_status
from .models import (
    Identity,
    PublicIdentity,
    PublicKey,
    Thread,
    ThreadSummary,
    Participant,
    Envelope,
    Content,
)
from .transport import PollingTransport


class ImhotepClient:
    """Python client for the Imhotep messaging platform.

    Usage:
        client = ImhotepClient(api_key="imhotep_sk_...")

        # Log in as an identity (created via dashboard)
        client.login("casey@imhotep")
        client.send(to="bob@imhotep", type="message", content={"text": "hello"})

        for envelope in client.listen():
            print(envelope.content)
    """

    def __init__(self, api_key, base_url="http://localhost:8000", timeout=30):
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._identity = None
        self._private_key = None
        self._transport = None
        self._http = httpx.Client(
            base_url=self._base_url,
            timeout=timeout,
        )

    def close(self):
        """Close the underlying HTTP connection."""
        self._http.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    # -- Headers --

    def _api_headers(self):
        """Headers for management endpoints (API key only)."""
        return {"X-API-Key": self._api_key}

    def _identity_headers(self):
        """Headers for identity-scoped endpoints (API key + X-Identity)."""
        if not self._identity:
            raise IdentityNotSetError()
        return {
            "X-API-Key": self._api_key,
            "X-Identity": self._identity,
        }

    # -- Identity selection --

    def login(self, alias):
        """Log in as an identity. Loads private key from disk.

        Raises ImhotepError immediately if the private key is not found.
        Identities are created via the dashboard — this method connects to one.
        """
        self._identity = alias
        self._private_key = load_private_key(alias)
        if not self._private_key:
            self._identity = None
            raise ImhotepError(
                "No private key found for '%s'. "
                "Run 'imhotep init --api-key <your-key>' to set up your keys." % alias
            )
        self._transport = None  # reset transport for new identity

    def set_private_key(self, private_key_b64):
        """Set the private key programmatically (e.g. for testing)."""
        self._private_key = private_key_b64

    @property
    def identity(self):
        """The currently active identity alias, or None."""
        return self._identity

    # -- Transport --

    def _get_transport(self):
        if self._transport is None:
            self._transport = PollingTransport(
                self._http, self._identity_headers, _parse_envelope
            )
        return self._transport

    def set_transport(self, transport):
        """Plug in a custom transport (e.g. WebSocket)."""
        self._transport = transport

    # -- Identity management (API key only) --

    def create_agent(
        self,
        parent_alias,
        suffix,
        manifest=None,
        delivery_rules=None,
    ):
        """Create an agent (app/endpoint) under your person identity.

        Generates keypair locally, sends only public key to server.
        Person identities are created via the dashboard — agents are created here.
        """
        pub_key, priv_key = generate_keypair()
        body = {"alias_suffix": suffix, "public_key": pub_key}
        if manifest is not None:
            body["manifest"] = manifest
        if delivery_rules is not None:
            body["delivery_rules"] = delivery_rules
        resp = self._http.post(
            "/api/identities/{}/agents".format(parent_alias),
            json=body,
            headers=self._api_headers(),
        )
        raise_for_status(resp)
        identity = _parse_identity(resp.json())
        save_private_key(identity.alias, priv_key)
        return identity

    def list_identities(self):
        """List all identities owned by the authenticated user."""
        resp = self._http.get(
            "/api/identities",
            headers=self._api_headers(),
        )
        raise_for_status(resp)
        return [_parse_identity(i) for i in resp.json()]

    def get_identity(self, alias):
        """Get details of an identity you own."""
        resp = self._http.get(
            "/api/identities/{}".format(alias),
            headers=self._api_headers(),
        )
        raise_for_status(resp)
        return _parse_identity(resp.json())

    def update_identity(
        self,
        alias,
        manifest=None,
        delivery_rules=None,
    ):
        """Update manifest or delivery rules for an identity."""
        body = {}
        if manifest is not None:
            body["manifest"] = manifest
        if delivery_rules is not None:
            body["delivery_rules"] = delivery_rules
        resp = self._http.patch(
            "/api/identities/{}".format(alias),
            json=body,
            headers=self._api_headers(),
        )
        raise_for_status(resp)
        return _parse_identity(resp.json())

    def list_agents(self, parent_alias, include_deactivated=False):
        """List all agent identities under a person identity."""
        params = {}
        if include_deactivated:
            params["include_deactivated"] = "true"
        resp = self._http.get(
            "/api/identities/{}/agents".format(parent_alias),
            params=params,
            headers=self._api_headers(),
        )
        raise_for_status(resp)
        return [_parse_identity(i) for i in resp.json()]

    def delete_agent(self, alias):
        """Deactivate (soft-delete) an agent identity."""
        resp = self._http.delete(
            "/api/identities/{}".format(alias),
            headers=self._api_headers(),
        )
        raise_for_status(resp)
        return _parse_identity(resp.json())

    def reactivate_agent(self, alias):
        """Reactivate a previously deactivated agent identity."""
        resp = self._http.post(
            "/api/identities/{}/reactivate".format(alias),
            headers=self._api_headers(),
        )
        raise_for_status(resp)
        return _parse_identity(resp.json())

    def rotate_key(self, alias):
        """Rotate the keypair for an identity.

        Generates a new keypair, sends the public key to the server,
        and saves the new private key to disk. The old key is invalidated.
        """
        pub_key, priv_key = generate_keypair()
        resp = self._http.post(
            "/api/identities/{}/rotate-key".format(alias),
            json={"public_key": pub_key},
            headers=self._api_headers(),
        )
        raise_for_status(resp)
        identity = _parse_identity(resp.json())
        save_private_key(identity.alias, priv_key)
        # If this is the currently logged-in identity, update in memory too
        if self._identity == alias:
            self._private_key = priv_key
        return identity

    # -- Discovery (no auth) --

    def search_identities(self, query):
        """Search identities by alias or manifest keywords. Public."""
        resp = self._http.get(
            "/api/identities/search",
            params={"q": query},
        )
        raise_for_status(resp)
        return [_parse_public_identity(i) for i in resp.json()]

    def get_public_key(self, alias):
        """Get the public key for any identity. Public."""
        resp = self._http.get(
            "/api/identities/{}/public-key".format(alias),
        )
        raise_for_status(resp)
        d = resp.json()
        return PublicKey(alias=d["alias"], public_key=d["public_key"])

    # -- Threads (requires identity) --

    def create_thread(self, subject=None, participants=None):
        """Create a thread. The current identity is auto-added as creator."""
        body = {}
        if subject is not None:
            body["subject"] = subject
        if participants is not None:
            body["participant_aliases"] = participants
        resp = self._http.post(
            "/api/threads",
            json=body,
            headers=self._identity_headers(),
        )
        raise_for_status(resp)
        return _parse_thread(resp.json())

    def list_threads(self):
        """List threads the current identity participates in."""
        resp = self._http.get(
            "/api/threads",
            headers=self._identity_headers(),
        )
        raise_for_status(resp)
        return [_parse_thread_summary(t) for t in resp.json()]

    def get_thread(self, thread_id):
        """Get a thread with all its envelopes."""
        resp = self._http.get(
            "/api/threads/{}".format(thread_id),
            headers=self._identity_headers(),
        )
        raise_for_status(resp)
        data = resp.json()
        thread = _parse_thread(data["thread"])
        envelopes = [_parse_envelope(e) for e in data.get("envelopes", [])]
        return thread, envelopes

    def update_thread(self, thread_id, subject=None, status=None):
        """Update a thread's subject or status. Creator only."""
        body = {}
        if subject is not None:
            body["subject"] = subject
        if status is not None:
            body["status"] = status
        resp = self._http.patch(
            "/api/threads/{}".format(thread_id),
            json=body,
            headers=self._identity_headers(),
        )
        raise_for_status(resp)
        return _parse_thread(resp.json())

    def add_participant(self, thread_id, alias):
        """Add a participant to a thread. Creator only."""
        resp = self._http.post(
            "/api/threads/{}/participants".format(thread_id),
            json={"alias": alias},
            headers=self._identity_headers(),
        )
        raise_for_status(resp)
        return _parse_thread(resp.json())

    # -- Envelopes (requires identity) --

    def send(
        self,
        to=None,
        thread_id=None,
        type="message",
        content=None,
        metadata=None,
        attachment_ids=None,
        parent_id=None,
    ):
        """Send an envelope. Signs locally before sending.

        Provide `to` for DM or `thread_id` for broadcast.
        """
        if not self._identity:
            raise IdentityNotSetError()
        if not self._private_key:
            raise ImhotepError("No private key set. Call login() or set_private_key() first.")

        now = datetime.datetime.now(datetime.timezone.utc)
        timestamp = now.isoformat()

        # Build canonical data for signing
        canonical_data = {
            "from": self._identity,
            "to": to,
            "thread_id": str(thread_id) if thread_id else None,
            "parent_id": str(parent_id) if parent_id else None,
            "type": type,
            "content": content or {},
            "attachments": sorted([str(a) for a in attachment_ids]) if attachment_ids else None,
            "metadata": metadata,
            "timestamp": timestamp,
        }

        signature = sign_envelope(self._private_key, canonical_data)

        body = {
            "type": type,
            "content": content or {},
            "signature": signature,
            "timestamp": timestamp,
        }
        if to is not None:
            body["to"] = to
        if thread_id is not None:
            body["thread_id"] = str(thread_id)
        if metadata is not None:
            body["metadata"] = metadata
        if attachment_ids is not None:
            body["attachment_ids"] = [str(a) for a in attachment_ids]
        if parent_id is not None:
            body["parent_id"] = str(parent_id)
        resp = self._http.post(
            "/api/envelopes",
            json=body,
            headers=self._identity_headers(),
        )
        raise_for_status(resp)
        return _parse_envelope(resp.json())

    def inbox(self):
        """Get all pending (undelivered) envelopes for the current identity."""
        return self._get_transport().receive()

    def get_envelope(self, envelope_id):
        """Get a specific envelope by ID."""
        resp = self._http.get(
            "/api/envelopes/{}".format(envelope_id),
            headers=self._identity_headers(),
        )
        raise_for_status(resp)
        return _parse_envelope(resp.json())

    def ack(self, envelope_id):
        """Acknowledge an envelope (mark as delivered)."""
        return self._get_transport().ack(envelope_id)

    def listen(self, interval=2, auto_ack=True):
        """Poll inbox continuously, yielding envelopes as they arrive.

        Args:
            interval: Seconds between polls (default 2).
            auto_ack: If True, automatically ack each envelope after yielding.

        Yields:
            Envelope objects as they arrive.
        """
        return self._get_transport().listen(interval=interval, auto_ack=auto_ack)

    # -- Content (requires identity) --

    def upload(self, file_path):
        """Upload a file. Access is initially restricted to the uploader."""
        with open(file_path, "rb") as f:
            filename = file_path.rsplit("/", 1)[-1] if "/" in file_path else file_path
            resp = self._http.post(
                "/api/contents",
                files={"file": (filename, f)},
                headers=self._identity_headers(),
            )
        raise_for_status(resp)
        return _parse_content(resp.json())

    def get_content(self, content_id):
        """Get metadata for a content object."""
        resp = self._http.get(
            "/api/contents/{}".format(content_id),
            headers=self._identity_headers(),
        )
        raise_for_status(resp)
        return _parse_content(resp.json())

    def download(self, content_id, dest_path):
        """Download a file to a local path. Returns the path."""
        resp = self._http.get(
            "/api/contents/{}/download".format(content_id),
            headers=self._identity_headers(),
        )
        raise_for_status(resp)
        with open(dest_path, "wb") as f:
            f.write(resp.content)
        return dest_path

    def delete_content(self, content_id):
        """Delete a content object. Uploader only."""
        resp = self._http.delete(
            "/api/contents/{}".format(content_id),
            headers=self._identity_headers(),
        )
        raise_for_status(resp)
        return resp.json()


# -- Response parsers --


def _parse_identity(d):
    return Identity(
        public_id=str(d["public_id"]),
        alias=d["alias"],
        identity_type=d["identity_type"],
        manifest=d.get("manifest"),
        delivery_rules=d.get("delivery_rules"),
        is_active=d.get("is_active", True),
        deactivated_at=d.get("deactivated_at"),
        created_at=d.get("created_at"),
        updated_at=d.get("updated_at"),
    )


def _parse_public_identity(d):
    return PublicIdentity(
        alias=d["alias"],
        identity_type=d["identity_type"],
        public_key=d["public_key"],
        manifest=d.get("manifest"),
    )


def _parse_thread(d):
    participants = []
    for p in d.get("participants", []):
        participants.append(
            Participant(
                alias=p["alias"],
                identity_type=p["identity_type"],
                joined_at=p.get("joined_at"),
            )
        )
    return Thread(
        public_id=str(d["public_id"]),
        subject=d.get("subject"),
        status=d.get("status", "active"),
        created_by=d.get("created_by", ""),
        participants=participants,
        created_at=d.get("created_at"),
        updated_at=d.get("updated_at"),
    )


def _parse_thread_summary(d):
    return ThreadSummary(
        public_id=str(d["public_id"]),
        subject=d.get("subject"),
        status=d.get("status", "active"),
        created_by=d.get("created_by", ""),
        participant_count=d.get("participant_count", 0),
        created_at=d.get("created_at"),
    )


def _parse_envelope(d):
    return Envelope(
        public_id=str(d["public_id"]),
        from_alias=d["from_alias"],
        to_alias=d.get("to_alias"),
        thread_id=str(d["thread_id"]) if d.get("thread_id") else None,
        parent_id=str(d["parent_id"]) if d.get("parent_id") else None,
        type=d.get("type", "message"),
        content=d.get("content", {}),
        metadata=d.get("metadata"),
        signature=d.get("signature", ""),
        attachments=[str(a) for a in d.get("attachments", [])],
        created_at=d.get("created_at"),
    )


def _parse_content(d):
    return Content(
        public_id=str(d["public_id"]),
        filename=d["filename"],
        mime_type=d["mime_type"],
        size_bytes=d.get("size_bytes", 0),
        access_list=d.get("access_list", []),
        created_at=d.get("created_at"),
    )
