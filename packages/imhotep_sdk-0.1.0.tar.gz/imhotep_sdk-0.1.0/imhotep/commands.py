"""
CLI command implementations for Imhotep.

Each function corresponds to one CLI subcommand. All follow the same pattern:
build client via make_client(), call SDK, print formatted output, close client.
"""

import functools
import sys

from .config import load_config, save_config, make_client
from .exceptions import ImhotepError, IdentityNotSetError
from .formatters import (
    fmt_identity,
    fmt_identity_short,
    fmt_public_identity,
    fmt_envelope,
    fmt_thread_summary,
    fmt_thread_detail,
    fmt_content,
)


def handle_errors(fn):
    """Decorator that catches ImhotepError and prints clean messages."""
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except IdentityNotSetError:
            print("Error: No identity set. Use --identity or run 'imhotep init'.")
            sys.exit(1)
        except ImhotepError as e:
            msg = str(e)
            if e.detail:
                msg = "%s: %s" % (msg, e.detail)
            print("Error: %s" % msg)
            sys.exit(1)
    return wrapper


# ── init ──────────────────────────────────────────────────────────────

def cmd_init(args):
    """Set up Imhotep — connect to your account and generate local keys.

    Non-interactive: pass --api-key (or set IMHOTEP_API_KEY env var).
    Fetches your identities from the server and generates keypairs locally
    for any that don't have keys on this machine yet.
    """
    import os
    from .client import ImhotepClient
    from .crypto import generate_keypair, save_private_key, load_private_key

    cfg = load_config()

    # Resolve API key: flag > env > config
    api_key = getattr(args, "api_key", None) or cfg.get("api_key")
    if not api_key:
        print("Error: API key is required. Use --api-key or set IMHOTEP_API_KEY.")
        sys.exit(1)

    # Resolve base URL: flag > env > config > default
    base_url = getattr(args, "base_url", None) or cfg.get("base_url") or "http://localhost:8000"

    # Connect and fetch identities
    client = ImhotepClient(api_key=api_key, base_url=base_url)
    try:
        identities = client.list_identities()
    except ImhotepError as e:
        print("Error connecting: %s" % e)
        client.close()
        sys.exit(1)

    if not identities:
        print("No identities found. Create one on the dashboard first.")
        client.close()
        sys.exit(1)

    # Generate keypairs for identities that don't have local keys yet
    person_alias = None
    for ident in identities:
        existing_key = load_private_key(ident.alias)
        if existing_key:
            print("  Key exists: %s" % ident.alias)
        else:
            pub_key, priv_key = generate_keypair()
            save_private_key(ident.alias, priv_key)
            # Push public key to server
            client.update_identity(ident.alias, manifest=ident.manifest)
            print("  Key created: %s" % ident.alias)

        if ident.identity_type == "person":
            person_alias = ident.alias

    # Save config
    save_config(api_key=api_key, base_url=base_url, identity=person_alias)

    client.close()
    print("\nReady. Config saved to ~/.imhotep/config")
    if person_alias:
        print("Default identity: %s" % person_alias)


# ── whoami ────────────────────────────────────────────────────────────

@handle_errors
def cmd_whoami(args):
    """Show current config and identity details."""
    cfg = load_config()
    print("API Key:  %s" % ("configured" if cfg["api_key"] else "not set"))
    print("Base URL: %s" % cfg["base_url"])
    print("Identity: %s" % (cfg["identity"] or "not set"))

    if cfg["api_key"] and cfg["identity"]:
        identity_alias = getattr(args, "identity", None) or cfg["identity"]
        client = make_client(identity_override=getattr(args, "identity", None))
        try:
            ident = client.get_identity(identity_alias)
            print("\nIdentity details:")
            print(fmt_identity(ident))
        finally:
            client.close()


# ── create-agent ──────────────────────────────────────────────────────

@handle_errors
def cmd_create_agent(args):
    """Create an agent identity under the configured person identity."""
    cfg = load_config()
    parent = getattr(args, "identity", None) or cfg.get("identity")
    if not parent:
        print("Error: No parent identity. Set one with 'imhotep init' or use --identity.")
        sys.exit(1)

    client = make_client()
    try:
        agent = client.create_agent(parent, args.suffix)
        print("Created agent:")
        print(fmt_identity(agent))
    finally:
        client.close()


# ── identities ────────────────────────────────────────────────────────

@handle_errors
def cmd_identities(args):
    """List all identities owned by the authenticated user."""
    client = make_client(identity_override=getattr(args, "identity", None))
    try:
        identities = client.list_identities()
        if not identities:
            print("No identities found.")
            return
        print("Your identities:")
        for ident in identities:
            print(fmt_identity_short(ident))
    finally:
        client.close()


# ── search ────────────────────────────────────────────────────────────

@handle_errors
def cmd_search(args):
    """Search the identity directory."""
    client = make_client(identity_override=getattr(args, "identity", None))
    try:
        results = client.search_identities(args.query)
        if not results:
            print("No results for '%s'." % args.query)
            return
        print("Found %d identities:" % len(results))
        for pub in results:
            print()
            print(fmt_public_identity(pub))
    finally:
        client.close()


# ── send ──────────────────────────────────────────────────────────────

@handle_errors
def cmd_send(args):
    """Send a text message to an identity."""
    client = make_client(identity_override=getattr(args, "identity", None))
    try:
        env = client.send(to=args.to, content={"text": args.message})
        print("Sent:")
        print(fmt_envelope(env))
    finally:
        client.close()


# ── inbox ─────────────────────────────────────────────────────────────

@handle_errors
def cmd_inbox(args):
    """Check pending messages."""
    client = make_client(identity_override=getattr(args, "identity", None))
    try:
        envelopes = client.inbox()
        if not envelopes:
            print("Inbox empty.")
            return
        print("%d pending messages:" % len(envelopes))
        for env in envelopes:
            print()
            print(fmt_envelope(env))
    finally:
        client.close()


# ── ack ───────────────────────────────────────────────────────────────

@handle_errors
def cmd_ack(args):
    """Acknowledge (mark as delivered) an envelope."""
    client = make_client(identity_override=getattr(args, "identity", None))
    try:
        client.ack(args.id)
        print("Acknowledged: %s" % args.id)
    finally:
        client.close()


# ── threads ───────────────────────────────────────────────────────────

@handle_errors
def cmd_threads(args):
    """List threads the current identity participates in."""
    client = make_client(identity_override=getattr(args, "identity", None))
    try:
        threads = client.list_threads()
        if not threads:
            print("No threads.")
            return
        print("Threads:")
        for ts in threads:
            print(fmt_thread_summary(ts))
    finally:
        client.close()


# ── thread ────────────────────────────────────────────────────────────

@handle_errors
def cmd_thread(args):
    """Show a thread with its messages."""
    client = make_client(identity_override=getattr(args, "identity", None))
    try:
        thread, envelopes = client.get_thread(args.id)
        print(fmt_thread_detail(thread, envelopes))
    finally:
        client.close()


# ── upload ────────────────────────────────────────────────────────────

@handle_errors
def cmd_upload(args):
    """Upload a file."""
    client = make_client(identity_override=getattr(args, "identity", None))
    try:
        content = client.upload(args.file)
        print("Uploaded:")
        print(fmt_content(content))
    finally:
        client.close()


# ── profile ───────────────────────────────────────────────────────────

@handle_errors
def cmd_profile(args):
    """Look up a public identity by alias."""
    client = make_client(identity_override=getattr(args, "identity", None))
    try:
        # Try search first for full profile info
        results = client.search_identities(args.alias)
        match = None
        for r in results:
            if r.alias == args.alias:
                match = r
                break

        if match:
            print("Profile:")
            print(fmt_public_identity(match))
        else:
            # Fall back to public key endpoint to prove existence
            pk = client.get_public_key(args.alias)
            print("Profile:")
            print("  Alias:      %s" % pk.alias)
            print("  Public Key: %s" % pk.public_key)
    finally:
        client.close()
