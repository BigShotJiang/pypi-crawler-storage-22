"""
Configuration management for the Imhotep CLI.

Config file: ~/.imhotep/config (INI format)
Resolution order: env var > config file > default
"""

import configparser
import os
import stat
from pathlib import Path

from .client import ImhotepClient


CONFIG_DIR = Path.home() / ".imhotep"
CONFIG_FILE = CONFIG_DIR / "config"
SECTION = "default"


def load_config():
    """Load config from ~/.imhotep/config. Returns dict with resolved values."""
    cp = configparser.ConfigParser()
    if CONFIG_FILE.exists():
        cp.read(str(CONFIG_FILE))

    file_vals = dict(cp[SECTION]) if cp.has_section(SECTION) else {}

    api_key = os.environ.get("IMHOTEP_API_KEY") or file_vals.get("api_key")
    base_url = os.environ.get("IMHOTEP_BASE_URL") or file_vals.get("base_url") or "http://localhost:8000"
    identity = os.environ.get("IMHOTEP_IDENTITY") or file_vals.get("identity")

    return {
        "api_key": api_key,
        "base_url": base_url,
        "identity": identity,
    }


def save_config(api_key=None, base_url=None, identity=None):
    """Save config to ~/.imhotep/config. Only writes provided values."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    cp = configparser.ConfigParser()
    if CONFIG_FILE.exists():
        cp.read(str(CONFIG_FILE))

    if not cp.has_section(SECTION):
        cp.add_section(SECTION)

    if api_key is not None:
        cp.set(SECTION, "api_key", api_key)
    if base_url is not None:
        cp.set(SECTION, "base_url", base_url)
    if identity is not None:
        cp.set(SECTION, "identity", identity)

    with open(str(CONFIG_FILE), "w") as f:
        cp.write(f)

    os.chmod(str(CONFIG_FILE), stat.S_IRUSR | stat.S_IWUSR)


def make_client(identity_override=None):
    """Build an ImhotepClient from resolved config.

    Args:
        identity_override: If set, use this identity instead of config value.

    Returns:
        Configured ImhotepClient instance.

    Raises:
        SystemExit: If api_key is not configured.
    """
    cfg = load_config()

    if not cfg["api_key"]:
        print("Error: No API key configured. Run 'imhotep init' or set IMHOTEP_API_KEY.")
        raise SystemExit(1)

    client = ImhotepClient(api_key=cfg["api_key"], base_url=cfg["base_url"])

    identity = identity_override or cfg["identity"]
    if identity:
        client.login(identity)

    return client
