import base64
import json
import os
import re
import stat

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import (
    Encoding,
    NoEncryption,
    PrivateFormat,
    PublicFormat,
)

KEYS_DIR = os.path.expanduser("~/.imhotep/keys")


def generate_keypair():
    """Generate an Ed25519 keypair. Returns (public_key_b64, private_key_b64)."""
    private_key = Ed25519PrivateKey.generate()
    private_bytes = private_key.private_bytes(
        Encoding.Raw, PrivateFormat.Raw, NoEncryption()
    )
    public_bytes = private_key.public_key().public_bytes(
        Encoding.Raw, PublicFormat.Raw
    )
    return (
        base64.b64encode(public_bytes).decode(),
        base64.b64encode(private_bytes).decode(),
    )


def _canonical_payload(envelope_data):
    """Build canonical JSON bytes for signing.

    Must match backend/crypto.py exactly.
    """
    canonical = {}
    for key in ("from", "to", "thread_id", "parent_id", "type", "content",
                "attachments", "metadata", "timestamp"):
        if key in envelope_data and envelope_data[key] is not None:
            val = envelope_data[key]
            if key == "attachments" and isinstance(val, list):
                val = sorted(val)
            canonical[key] = val
    return json.dumps(canonical, sort_keys=True, separators=(",", ":")).encode()


def sign_envelope(private_key_b64, envelope_data):
    """Sign canonical envelope data with an Ed25519 private key. Returns base64 signature."""
    private_bytes = base64.b64decode(private_key_b64)
    private_key = Ed25519PrivateKey.from_private_bytes(private_bytes)
    payload = _canonical_payload(envelope_data)
    signature = private_key.sign(payload)
    return base64.b64encode(signature).decode()


def _safe_alias(alias):
    """Convert alias to a safe filename."""
    return re.sub(r'[/@]', '_', alias)


def save_private_key(alias, private_key_b64):
    """Save a private key to ~/.imhotep/keys/{safe_alias}.key with 0600 permissions."""
    os.makedirs(KEYS_DIR, mode=0o700, exist_ok=True)
    path = os.path.join(KEYS_DIR, _safe_alias(alias) + ".key")
    with open(path, "w") as f:
        f.write(private_key_b64)
    os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)  # 0600
    return path


def load_private_key(alias):
    """Load a private key from ~/.imhotep/keys/{safe_alias}.key. Returns b64 string or None."""
    path = os.path.join(KEYS_DIR, _safe_alias(alias) + ".key")
    if not os.path.exists(path):
        return None
    with open(path, "r") as f:
        return f.read().strip()
