class ImhotepError(Exception):
    """Base exception for all Imhotep SDK errors."""

    def __init__(self, message, status_code=None, detail=None):
        self.message = message
        self.status_code = status_code
        self.detail = detail
        super().__init__(message)


class AuthError(ImhotepError):
    """401 — invalid or missing API key."""
    pass


class ForbiddenError(ImhotepError):
    """403 — not allowed to perform this action."""
    pass


class NotFoundError(ImhotepError):
    """404 — resource not found."""
    pass


class ConflictError(ImhotepError):
    """409 — resource already exists (e.g. alias taken)."""
    pass


class RateLimitError(ImhotepError):
    """429 — rate limit exceeded for this recipient."""
    pass


class IdentityNotSetError(ImhotepError):
    """Client-side — called a method that requires login() first."""

    def __init__(self):
        super().__init__(
            "No identity set. Call client.login('alias@imhotep') first.",
            status_code=None,
            detail=None,
        )


_STATUS_MAP = {
    401: AuthError,
    403: ForbiddenError,
    404: NotFoundError,
    409: ConflictError,
    429: RateLimitError,
}


def raise_for_status(response):
    """Raise an appropriate ImhotepError for non-2xx responses."""
    if response.status_code < 300:
        return
    exc_class = _STATUS_MAP.get(response.status_code, ImhotepError)
    try:
        body = response.json()
        detail = body.get("detail", str(body))
    except Exception:
        detail = response.text
    raise exc_class(
        message=detail,
        status_code=response.status_code,
        detail=detail,
    )
