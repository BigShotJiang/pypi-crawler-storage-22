"""
Plain-text output formatters for the Imhotep CLI.

All functions are pure — they take SDK model objects and return strings.
"""

import json


def fmt_identity(identity):
    """Format an owned Identity for display."""
    lines = [
        "  Alias:    %s" % identity.alias,
        "  Type:     %s" % identity.identity_type,
        "  ID:       %s" % identity.public_id,
    ]
    if identity.manifest:
        lines.append("  Manifest: %s" % json.dumps(identity.manifest))
    if identity.created_at:
        lines.append("  Created:  %s" % identity.created_at)
    return "\n".join(lines)


def fmt_identity_short(identity):
    """One-line identity summary."""
    return "  %-30s  %s" % (identity.alias, identity.identity_type)


def fmt_public_identity(pub):
    """Format a PublicIdentity (search result / profile)."""
    lines = [
        "  Alias:      %s" % pub.alias,
        "  Type:       %s" % pub.identity_type,
        "  Public Key: %s" % pub.public_key,
    ]
    if pub.manifest:
        lines.append("  Manifest:   %s" % json.dumps(pub.manifest))
    return "\n".join(lines)


def fmt_envelope(env):
    """Format an Envelope for display."""
    direction = ""
    if env.to_alias:
        direction = "To: %s" % env.to_alias
    elif env.thread_id:
        direction = "Thread: %s" % env.thread_id

    lines = [
        "  ID:      %s" % env.public_id,
        "  From:    %s" % env.from_alias,
    ]
    if direction:
        lines.append("  %s" % direction)
    if env.parent_id:
        lines.append("  Reply:   %s" % env.parent_id)
    lines.append("  Type:    %s" % env.type)

    text = env.content.get("text") if env.content else None
    if text:
        lines.append("  Content: %s" % text)
    elif env.content:
        lines.append("  Content: %s" % json.dumps(env.content))

    if env.attachments:
        lines.append("  Attach:  %s" % ", ".join(env.attachments))
    if env.created_at:
        lines.append("  Sent:    %s" % env.created_at)
    return "\n".join(lines)


def fmt_thread_summary(ts):
    """Format a ThreadSummary for list display."""
    subject = ts.subject or "(no subject)"
    return "  %-12s  %-8s  %d members  %s" % (
        ts.public_id[:12],
        ts.status,
        ts.participant_count,
        subject,
    )


def fmt_thread_detail(thread, envelopes):
    """Format a Thread with its envelopes."""
    subject = thread.subject or "(no subject)"
    lines = [
        "Thread: %s" % subject,
        "  ID:       %s" % thread.public_id,
        "  Status:   %s" % thread.status,
        "  Creator:  %s" % thread.created_by,
    ]
    if thread.participants:
        aliases = [p.alias for p in thread.participants]
        lines.append("  Members:  %s" % ", ".join(aliases))
    if thread.created_at:
        lines.append("  Created:  %s" % thread.created_at)

    if envelopes:
        lines.append("")
        lines.append("Messages (%d):" % len(envelopes))
        for env in envelopes:
            lines.append("")
            lines.append(fmt_envelope(env))

    return "\n".join(lines)


def fmt_content(content):
    """Format a Content object for display."""
    lines = [
        "  ID:       %s" % content.public_id,
        "  File:     %s" % content.filename,
        "  Type:     %s" % content.mime_type,
        "  Size:     %s" % _human_size(content.size_bytes),
    ]
    if content.access_list:
        lines.append("  Access:   %s" % ", ".join(content.access_list))
    if content.created_at:
        lines.append("  Uploaded: %s" % content.created_at)
    return "\n".join(lines)


def _human_size(n):
    """Format byte count as human-readable."""
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            if unit == "B":
                return "%d %s" % (n, unit)
            return "%.1f %s" % (n, unit)
        n = n / 1024.0
    return "%.1f TB" % n
