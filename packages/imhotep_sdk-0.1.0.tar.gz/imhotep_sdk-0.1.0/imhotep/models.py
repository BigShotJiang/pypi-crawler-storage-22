from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any


@dataclass
class Identity:
    public_id: str
    alias: str
    identity_type: str
    manifest: Optional[Dict[str, Any]] = None
    delivery_rules: Optional[Dict[str, Any]] = None
    is_active: bool = True
    deactivated_at: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


@dataclass
class PublicIdentity:
    alias: str
    identity_type: str
    public_key: str
    manifest: Optional[Dict[str, Any]] = None


@dataclass
class PublicKey:
    alias: str
    public_key: str


@dataclass
class Participant:
    alias: str
    identity_type: str
    joined_at: Optional[str] = None


@dataclass
class Thread:
    public_id: str
    subject: Optional[str] = None
    status: str = "active"
    created_by: str = ""
    participants: List[Participant] = field(default_factory=list)
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


@dataclass
class ThreadSummary:
    public_id: str
    subject: Optional[str] = None
    status: str = "active"
    created_by: str = ""
    participant_count: int = 0
    created_at: Optional[str] = None


@dataclass
class Envelope:
    public_id: str
    from_alias: str
    to_alias: Optional[str] = None
    thread_id: Optional[str] = None
    parent_id: Optional[str] = None
    type: str = "message"
    content: Dict[str, Any] = field(default_factory=dict)
    metadata: Optional[Dict[str, Any]] = None
    signature: str = ""
    attachments: List[str] = field(default_factory=list)
    created_at: Optional[str] = None


@dataclass
class Content:
    public_id: str
    filename: str
    mime_type: str
    size_bytes: int = 0
    access_list: List[str] = field(default_factory=list)
    created_at: Optional[str] = None
