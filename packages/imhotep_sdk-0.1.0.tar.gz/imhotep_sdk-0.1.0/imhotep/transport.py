import time


class Transport:
    """Base class for envelope transport mechanisms."""

    def receive(self):
        """Fetch pending envelopes. Returns list of Envelope objects."""
        raise NotImplementedError

    def ack(self, envelope_id):
        """Acknowledge an envelope as delivered."""
        raise NotImplementedError

    def listen(self, interval=2, auto_ack=True):
        """Yield envelopes as they arrive, polling at the given interval.

        Args:
            interval: Seconds between polls (default 2).
            auto_ack: If True, automatically ack each envelope after yielding.

        Yields:
            Envelope objects as they arrive.
        """
        while True:
            envelopes = self.receive()
            for envelope in envelopes:
                yield envelope
                if auto_ack:
                    self.ack(envelope.public_id)
            if not envelopes:
                time.sleep(interval)


class PollingTransport(Transport):
    """Transport that polls the inbox endpoint via HTTP."""

    def __init__(self, http_client, headers_fn, parse_fn):
        """
        Args:
            http_client: httpx.Client instance.
            headers_fn: Callable returning identity-scoped headers dict.
            parse_fn: Callable to parse an envelope dict into an Envelope object.
        """
        self._http = http_client
        self._headers_fn = headers_fn
        self._parse_fn = parse_fn

    def receive(self):
        from .exceptions import raise_for_status
        resp = self._http.get(
            "/api/envelopes/inbox",
            headers=self._headers_fn(),
        )
        raise_for_status(resp)
        return [self._parse_fn(e) for e in resp.json()["envelopes"]]

    def ack(self, envelope_id):
        from .exceptions import raise_for_status
        resp = self._http.post(
            "/api/envelopes/{}/ack".format(envelope_id),
            headers=self._headers_fn(),
        )
        raise_for_status(resp)
        return resp.json()
