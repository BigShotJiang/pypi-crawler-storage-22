# Kept for editable installs (pip install -e .) on older pip versions.
# All config is in pyproject.toml.
from setuptools import setup

setup()
