import base64
import datetime
import json
import os
from unittest.mock import MagicMock, patch, PropertyMock

import pytest

from imhotep.client import ImhotepClient
from imhotep.crypto import generate_keypair, save_private_key
from imhotep.exceptions import IdentityNotSetError, ImhotepError
from imhotep.models import Envelope
from imhotep.transport import Transport


# -- Init --

def test_init_defaults():
    client = ImhotepClient(api_key="test-key")
    assert client._identity is None
    assert client._private_key is None
    assert client._transport is None
    client.close()


# -- Identity --

def test_login_loads_key_from_disk(tmp_path, monkeypatch):
    monkeypatch.setattr("imhotep.crypto.KEYS_DIR", str(tmp_path))
    _, priv = generate_keypair()
    alias = "casey@imhotep"
    save_private_key(alias, priv)

    client = ImhotepClient(api_key="test-key")
    client.login(alias)

    assert client._identity == alias
    assert client._private_key == priv
    client.close()


def test_login_raises_when_no_key_on_disk(tmp_path, monkeypatch):
    monkeypatch.setattr("imhotep.crypto.KEYS_DIR", str(tmp_path))

    client = ImhotepClient(api_key="test-key")
    with pytest.raises(ImhotepError, match="No private key found"):
        client.login("nobody@imhotep")

    assert client._identity is None
    assert client._private_key is None
    client.close()


def test_set_private_key_programmatic():
    client = ImhotepClient(api_key="test-key")
    _, priv = generate_keypair()
    client.set_private_key(priv)
    assert client._private_key == priv
    client.close()


# -- Send guards --

def test_send_raises_without_identity():
    client = ImhotepClient(api_key="test-key")
    with pytest.raises(IdentityNotSetError):
        client.send(to="bob@imhotep", content={"text": "hi"})
    client.close()


def test_send_raises_without_private_key():
    client = ImhotepClient(api_key="test-key")
    client._identity = "alice@imhotep"  # set identity without key
    with pytest.raises(ImhotepError, match="No private key"):
        client.send(to="bob@imhotep", content={"text": "hi"})
    client.close()


# -- Send with signature --

def test_send_includes_signature_and_timestamp():
    pub, priv = generate_keypair()
    client = ImhotepClient(api_key="test-key")
    client._identity = "alice@imhotep"
    client._private_key = priv

    # Mock the HTTP client's post method
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = {
        "public_id": "env-1",
        "from_alias": "alice@imhotep",
        "to_alias": "bob@imhotep",
        "type": "message",
        "content": {"text": "hi"},
        "signature": "fakesig",
    }
    client._http.post = MagicMock(return_value=mock_resp)

    client.send(to="bob@imhotep", content={"text": "hi"})

    # Inspect the JSON body sent
    call_kwargs = client._http.post.call_args
    body = call_kwargs[1]["json"] if "json" in call_kwargs[1] else call_kwargs.kwargs["json"]

    # Signature should be non-empty base64
    assert "signature" in body
    sig_bytes = base64.b64decode(body["signature"])
    assert len(sig_bytes) == 64  # Ed25519 signatures are 64 bytes

    # Timestamp should be ISO format
    assert "timestamp" in body
    # Should parse without error
    datetime.datetime.fromisoformat(body["timestamp"])

    client.close()


# -- Transport --

def test_set_transport_overrides_default():
    client = ImhotepClient(api_key="test-key")
    client._identity = "alice@imhotep"

    mock_transport = MagicMock(spec=Transport)
    mock_transport.receive.return_value = []
    client.set_transport(mock_transport)

    result = client.inbox()
    mock_transport.receive.assert_called_once()
    assert result == []
    client.close()


# -- Context manager --

def test_context_manager_closes():
    with ImhotepClient(api_key="test-key") as client:
        client._http.close = MagicMock()
        close_mock = client._http.close

    close_mock.assert_called_once()
