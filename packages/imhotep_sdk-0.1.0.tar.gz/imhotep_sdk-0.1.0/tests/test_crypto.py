import base64
import os
import stat
import sys

import pytest

# Add backend to path so we can import its crypto module for cross-boundary tests
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "backend"))

from imhotep.crypto import (
    generate_keypair,
    sign_envelope,
    _canonical_payload,
    _safe_alias,
    save_private_key,
    load_private_key,
    KEYS_DIR,
)
import crypto as backend_crypto


# -- Keypair generation --

def test_generate_keypair_format():
    pub, priv = generate_keypair()
    # Both should be valid base64
    pub_bytes = base64.b64decode(pub)
    priv_bytes = base64.b64decode(priv)
    assert len(pub_bytes) == 32
    assert len(priv_bytes) == 32


def test_keypair_uniqueness():
    pair_a = generate_keypair()
    pair_b = generate_keypair()
    assert pair_a[0] != pair_b[0]
    assert pair_a[1] != pair_b[1]


# -- Signing & verification --

def test_sign_and_verify_roundtrip():
    pub, priv = generate_keypair()
    data = {"from": "alice@imhotep", "to": "bob@imhotep", "type": "message",
            "content": {"text": "hello"}, "timestamp": "2025-01-01T00:00:00+00:00"}
    sig = sign_envelope(priv, data)
    assert backend_crypto.verify_signature(pub, sig, data)


def test_sign_wrong_key_rejects():
    pub_a, priv_a = generate_keypair()
    pub_b, priv_b = generate_keypair()
    data = {"from": "alice@imhotep", "type": "message", "content": {}}
    sig = sign_envelope(priv_a, data)
    # Verify with wrong key should fail
    assert not backend_crypto.verify_signature(pub_b, sig, data)


# -- Canonical payload --

def test_canonical_payload_strips_none():
    data = {"from": "a@imhotep", "to": None, "type": "message", "content": {}, "metadata": None}
    payload = _canonical_payload(data)
    import json
    parsed = json.loads(payload)
    assert "to" not in parsed
    assert "metadata" not in parsed
    assert "from" in parsed


def test_canonical_payload_sorts_attachments():
    data = {"attachments": ["c.txt", "a.txt", "b.txt"], "type": "message"}
    payload = _canonical_payload(data)
    import json
    parsed = json.loads(payload)
    assert parsed["attachments"] == ["a.txt", "b.txt", "c.txt"]


def test_canonical_payload_matches_backend():
    data = {
        "from": "alice@imhotep",
        "to": "bob@imhotep",
        "thread_id": None,
        "parent_id": None,
        "type": "message",
        "content": {"text": "hello"},
        "attachments": ["z.txt", "a.txt"],
        "metadata": {"key": "value"},
        "timestamp": "2025-06-15T12:00:00+00:00",
    }
    sdk_bytes = _canonical_payload(data)
    backend_bytes = backend_crypto._canonical_payload(data)
    assert sdk_bytes == backend_bytes


# -- Key persistence --

def test_save_and_load_private_key(tmp_path, monkeypatch):
    monkeypatch.setattr("imhotep.crypto.KEYS_DIR", str(tmp_path))
    _, priv = generate_keypair()
    alias = "casey/research-agent@imhotep"

    save_private_key(alias, priv)

    # Verify file permissions
    key_path = os.path.join(str(tmp_path), "casey_research-agent_imhotep.key")
    file_stat = os.stat(key_path)
    assert stat.S_IMODE(file_stat.st_mode) == 0o600

    # Round-trip
    loaded = load_private_key(alias)
    assert loaded == priv


def test_load_missing_key_returns_none(tmp_path, monkeypatch):
    monkeypatch.setattr("imhotep.crypto.KEYS_DIR", str(tmp_path))
    assert load_private_key("nonexistent@imhotep") is None


# -- Safe alias --

def test_safe_alias():
    assert _safe_alias("casey/agent@imhotep") == "casey_agent_imhotep"
    assert _safe_alias("simple@imhotep") == "simple_imhotep"
