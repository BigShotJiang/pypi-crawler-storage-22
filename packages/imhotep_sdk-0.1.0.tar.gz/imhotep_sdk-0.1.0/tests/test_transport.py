import itertools
from unittest.mock import MagicMock, patch, call

import pytest

from imhotep.transport import Transport, PollingTransport
from imhotep.models import Envelope


def _make_envelope(public_id="env-1"):
    return Envelope(
        public_id=public_id,
        from_alias="alice@imhotep",
        to_alias="bob@imhotep",
        type="message",
        content={"text": "hi"},
        signature="sig",
    )


# -- Base Transport --

def test_base_transport_not_implemented():
    t = Transport()
    with pytest.raises(NotImplementedError):
        t.receive()
    with pytest.raises(NotImplementedError):
        t.ack("env-1")


# -- PollingTransport --

def test_polling_receive():
    mock_http = MagicMock()
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = {
        "envelopes": [
            {
                "public_id": "env-1",
                "from_alias": "alice@imhotep",
                "to_alias": "bob@imhotep",
                "type": "message",
                "content": {"text": "hello"},
                "signature": "sig1",
            }
        ]
    }
    mock_http.get.return_value = mock_resp

    headers_fn = lambda: {"X-API-Key": "key", "X-Identity": "bob@imhotep"}
    parse_fn = lambda d: Envelope(
        public_id=d["public_id"],
        from_alias=d["from_alias"],
        to_alias=d.get("to_alias"),
        type=d.get("type", "message"),
        content=d.get("content", {}),
        signature=d.get("signature", ""),
    )

    transport = PollingTransport(mock_http, headers_fn, parse_fn)
    envelopes = transport.receive()

    assert len(envelopes) == 1
    assert envelopes[0].public_id == "env-1"
    assert envelopes[0].from_alias == "alice@imhotep"
    mock_http.get.assert_called_once_with(
        "/api/envelopes/inbox",
        headers={"X-API-Key": "key", "X-Identity": "bob@imhotep"},
    )


def test_polling_ack():
    mock_http = MagicMock()
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = {"status": "delivered"}
    mock_http.post.return_value = mock_resp

    headers_fn = lambda: {"X-API-Key": "key", "X-Identity": "bob@imhotep"}

    transport = PollingTransport(mock_http, headers_fn, lambda d: d)
    result = transport.ack("env-42")

    mock_http.post.assert_called_once_with(
        "/api/envelopes/env-42/ack",
        headers={"X-API-Key": "key", "X-Identity": "bob@imhotep"},
    )
    assert result == {"status": "delivered"}


# -- listen() --

def test_listen_yields_and_acks():
    env1 = _make_envelope("env-1")
    env2 = _make_envelope("env-2")

    t = Transport()
    # Two single-envelope batches so the ack after each yield runs before
    # the generator reaches the next receive() call.
    t.receive = MagicMock(side_effect=[[env1], [env2], []])
    t.ack = MagicMock()

    results = list(itertools.islice(t.listen(interval=0), 2))

    assert len(results) == 2
    assert results[0].public_id == "env-1"
    assert results[1].public_id == "env-2"
    # After yielding env-1 the generator resumes and acks it before yielding env-2.
    # After yielding env-2 islice stops, so env-2's ack doesn't run.
    assert t.ack.call_count == 1
    t.ack.assert_called_with("env-1")


def test_listen_no_auto_ack():
    env1 = _make_envelope("env-1")

    t = Transport()
    t.receive = MagicMock(side_effect=[[env1], []])
    t.ack = MagicMock()

    results = list(itertools.islice(t.listen(interval=0, auto_ack=False), 1))

    assert len(results) == 1
    t.ack.assert_not_called()


def test_custom_transport_pluggable():
    class MyTransport(Transport):
        def __init__(self):
            self.call_count = 0
            self.acked = []

        def receive(self):
            self.call_count += 1
            if self.call_count == 1:
                return [_make_envelope("custom-1")]
            if self.call_count == 2:
                return [_make_envelope("custom-2")]
            return []

        def ack(self, envelope_id):
            self.acked.append(envelope_id)

    t = MyTransport()
    # Consume 2: after yielding custom-1 the generator resumes and acks it
    # before fetching the next batch. custom-2's ack won't fire (islice stops).
    results = list(itertools.islice(t.listen(interval=0), 2))

    assert len(results) == 2
    assert results[0].public_id == "custom-1"
    assert results[1].public_id == "custom-2"
    assert t.acked == ["custom-1"]
