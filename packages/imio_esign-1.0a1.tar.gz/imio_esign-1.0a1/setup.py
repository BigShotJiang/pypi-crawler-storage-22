# -*- coding: utf-8 -*-
"""Installer for the imio.esign package."""

from setuptools import find_packages
from setuptools import setup


long_description = "\n\n".join(
    [
        open("README.rst").read(),
        open("CONTRIBUTORS.rst").read(),
        open("CHANGES.rst").read(),
    ]
)


setup(
    name="imio.esign",
    version="1.0a1",
    description="Integration of IMIO esign webservice",
    long_description=long_description,
    # Get more from https://pypi.org/classifiers/
    classifiers=[
        "Environment :: Web Environment",
        "Framework :: Plone",
        "Framework :: Plone :: Addon",
        "Framework :: Plone :: 5.2",
        "Framework :: Plone :: 6.0",
        "Programming Language :: Python",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Operating System :: OS Independent",
        "License :: OSI Approved :: GNU General Public License v2 (GPLv2)",
    ],
    keywords="Python Plone CMS",
    author="Stephan Geulette",
    author_email="s.geulette@imio.be",
    url="https://github.com/collective/imio.esign",
    project_urls={
        "PyPI": "https://pypi.org/project/imio.esign/",
        "Source": "https://github.com/collective/imio.esign",
        "Tracker": "https://github.com/collective/imio.esign/issues",
        # 'Documentation': 'https://imio.esign.readthedocs.io/en/latest/',
    },
    license="GPL version 2",
    packages=find_packages("src", exclude=["ez_setup"]),
    namespace_packages=["imio"],
    package_dir={"": "src"},
    include_package_data=True,
    zip_safe=False,
    python_requires=">=3.7",
    install_requires=[
        "setuptools",
        # -*- Extra requirements: -*-
        "collective.compoundcriterion",
        "collective.eeafaceted.z3ctable",
        "eea.facetednavigation",
        "imio.helpers",
        "imio.prettylink",
        "imio.pyutils",
        # 'z3c.jbot',
        "plone.api>=1.8.4",
        "plone.app.dexterity",
        "plone.restapi",
        "requests",
        "z3c.table",
    ],
    extras_require={
        "test": [
            "plone.app.testing",
            # Plone KGS does not use this version, because it would break
            # Remove if your package shall be part of coredev.
            # plone_coredev tests as of 2016-04-01.
            "plone.testing>=5.0.0",
            "plone.app.contenttypes",
            "plone.app.robotframework[debug]",
            "imio.annex",
        ],
    },
    entry_points="""
    [z3c.autoinclude.plugin]
    target = plone
    [console_scripts]
    update_locale = imio.esign.locales.update:update_locale
    cosi_esign_push_acroform = imio.esign.scripts.cosi_esign_push_acroform:main
    """,
)
