DEVICE_ID = "immich-py"
