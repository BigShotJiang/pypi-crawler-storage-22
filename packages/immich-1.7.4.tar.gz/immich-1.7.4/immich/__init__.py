raise ImportError(
    "The 'immich' package has been renamed to 'immichpy'. "
    "Install with: pip install immichpy"
)
