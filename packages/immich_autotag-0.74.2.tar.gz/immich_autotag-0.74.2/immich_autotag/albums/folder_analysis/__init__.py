# Folder analysis subpackage for album folder analyzers and related logic.

# Place all analyzers, utilities, and helpers for folder-based album detection here.
