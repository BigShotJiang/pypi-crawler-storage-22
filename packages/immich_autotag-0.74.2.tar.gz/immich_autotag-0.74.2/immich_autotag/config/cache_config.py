# Global cache timeout (in seconds) for all cache entries (assets, albums, tags, etc.)
DEFAULT_CACHE_MAX_AGE_SECONDS = 3600
