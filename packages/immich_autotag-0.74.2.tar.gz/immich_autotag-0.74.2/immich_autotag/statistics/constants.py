"""
constants.py

Project-wide constants for filenames, keys, etc.
"""

RUN_STATISTICS_FILENAME = "run_statistics.yaml"
