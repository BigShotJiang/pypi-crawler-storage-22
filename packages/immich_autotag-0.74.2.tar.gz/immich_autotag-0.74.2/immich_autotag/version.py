# This file is automatically updated in the build/distribution process
__version__ = "0.74.2"
__git_commit__ = "4a65c3c"
__git_describe__ = "v0.74.1-qualitygate-45-g4a65c3c-dirty"
