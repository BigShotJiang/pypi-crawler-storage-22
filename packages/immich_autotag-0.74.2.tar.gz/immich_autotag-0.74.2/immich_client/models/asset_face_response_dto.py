from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.source_type import SourceType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.person_response_dto import PersonResponseDto


T = TypeVar("T", bound="AssetFaceResponseDto")


@_attrs_define
class AssetFaceResponseDto:
    """
    Attributes:
        bounding_box_x1 (int):
        bounding_box_x2 (int):
        bounding_box_y1 (int):
        bounding_box_y2 (int):
        id (UUID):
        image_height (int):
        image_width (int):
        person (None | PersonResponseDto):
        source_type (SourceType | Unset):
    """

    bounding_box_x1: int
    bounding_box_x2: int
    bounding_box_y1: int
    bounding_box_y2: int
    id: UUID
    image_height: int
    image_width: int
    person: None | PersonResponseDto
    source_type: SourceType | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.person_response_dto import PersonResponseDto

        bounding_box_x1 = self.bounding_box_x1

        bounding_box_x2 = self.bounding_box_x2

        bounding_box_y1 = self.bounding_box_y1

        bounding_box_y2 = self.bounding_box_y2

        id = str(self.id)

        image_height = self.image_height

        image_width = self.image_width

        person: dict[str, Any] | None
        if isinstance(self.person, PersonResponseDto):
            person = self.person.to_dict()
        else:
            person = self.person

        source_type: str | Unset = UNSET
        if not isinstance(self.source_type, Unset):
            source_type = self.source_type.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "boundingBoxX1": bounding_box_x1,
                "boundingBoxX2": bounding_box_x2,
                "boundingBoxY1": bounding_box_y1,
                "boundingBoxY2": bounding_box_y2,
                "id": id,
                "imageHeight": image_height,
                "imageWidth": image_width,
                "person": person,
            }
        )
        if source_type is not UNSET:
            field_dict["sourceType"] = source_type

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.person_response_dto import PersonResponseDto

        d = dict(src_dict)
        bounding_box_x1 = d.pop("boundingBoxX1")

        bounding_box_x2 = d.pop("boundingBoxX2")

        bounding_box_y1 = d.pop("boundingBoxY1")

        bounding_box_y2 = d.pop("boundingBoxY2")

        id = UUID(d.pop("id"))

        image_height = d.pop("imageHeight")

        image_width = d.pop("imageWidth")

        def _parse_person(data: object) -> None | PersonResponseDto:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                person_type_1 = PersonResponseDto.from_dict(data)

                return person_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | PersonResponseDto, data)

        person = _parse_person(d.pop("person"))

        _source_type = d.pop("sourceType", UNSET)
        source_type: SourceType | Unset
        if isinstance(_source_type, Unset):
            source_type = UNSET
        else:
            source_type = SourceType(_source_type)

        asset_face_response_dto = cls(
            bounding_box_x1=bounding_box_x1,
            bounding_box_x2=bounding_box_x2,
            bounding_box_y1=bounding_box_y1,
            bounding_box_y2=bounding_box_y2,
            id=id,
            image_height=image_height,
            image_width=image_width,
            person=person,
            source_type=source_type,
        )

        asset_face_response_dto.additional_properties = d
        return asset_face_response_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
