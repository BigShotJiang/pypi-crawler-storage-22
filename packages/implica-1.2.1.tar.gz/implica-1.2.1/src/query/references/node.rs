use error_stack::ResultExt;
use pyo3::prelude::*;
use std::sync::Arc;

use crate::ctx;
use crate::errors::IntoPyResult;
use crate::graph::{Graph, Uid};
use crate::query::references::r#type::TypeRef;
use crate::query::references::term::TermRef;

#[pyclass(name = "Node")]
#[derive(Debug, Clone)]
pub struct NodeRef {
    graph: Arc<Graph>,

    uid: Uid,
}

impl PartialEq for NodeRef {
    fn eq(&self, other: &Self) -> bool {
        self.uid == other.uid
    }
}

impl Eq for NodeRef {}

impl NodeRef {
    pub fn new(graph: Arc<Graph>, uid: Uid) -> Self {
        NodeRef { graph, uid }
    }
}

#[pymethods]
impl NodeRef {
    pub fn uid(&self) -> String {
        hex::encode(self.uid)
    }

    pub fn properties<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyAny>> {
        let map = self
            .graph
            .node_properties(&self.uid)
            .attach(ctx!("node reference - get properties"))
            .into_py_result()?;

        map.into_pyobject(py) // TODO: add some kind of attachment
    }

    pub fn r#type(&self) -> TypeRef {
        TypeRef::new(self.graph.clone(), self.uid)
    }

    pub fn term(&self) -> Option<TermRef> {
        if self.graph.contains_term_of_type(&self.uid) {
            Some(TermRef::new(self.graph.clone(), self.uid))
        } else {
            None
        }
    }

    pub fn __str__(&self) -> PyResult<String> {
        self.graph
            .node_to_string(&self.uid)
            .attach("node reference - to string")
            .into_py_result()
    }

    pub fn __repr__(&self) -> PyResult<String> {
        self.__str__()
    }

    pub fn __eq__(&self, other: &Self) -> bool {
        self == other
    }
}
