this file exists but the app should not serve it.
