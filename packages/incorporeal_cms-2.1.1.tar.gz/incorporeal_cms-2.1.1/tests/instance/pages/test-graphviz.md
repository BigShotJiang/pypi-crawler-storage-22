# test

test
~~~{ pydot:attack-plan }
digraph G {
    rankdir=LR
    Earth
    Mars
    Earth -> Mars
}
~~~
more test
