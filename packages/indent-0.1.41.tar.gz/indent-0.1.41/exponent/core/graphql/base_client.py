import json
from typing import Any

from httpx import AsyncClient, Response, Timeout
from pydantic import BaseModel


class _PydanticEncoder(json.JSONEncoder):
    def default(self, o: Any) -> Any:
        if isinstance(o, BaseModel):
            return o.model_dump(by_alias=True, exclude_none=True)
        return super().default(o)


class AsyncBaseClient:
    """Base client for Ariadne-generated GraphQL clients."""

    def __init__(self, url: str, headers: dict[str, str] | None = None):
        self.url = url
        self.headers = headers or {}
        self._client: AsyncClient | None = None

    async def _get_client(self) -> AsyncClient:
        """Get or create the HTTP client."""
        if self._client is None:
            self._client = AsyncClient(headers=self.headers, timeout=Timeout(30.0))
        return self._client

    async def execute(
        self,
        query: str,
        operation_name: str | None = None,
        variables: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Execute a GraphQL query."""
        client = await self._get_client()
        payload = {
            "query": query,
            "operationName": operation_name,
            "variables": variables or {},
        }
        content = json.dumps(payload, cls=_PydanticEncoder)
        response: Response = await client.post(
            self.url,
            content=content,
            headers={"Content-Type": "application/json"},
            **kwargs,
        )
        response.raise_for_status()
        json_response: dict[str, Any] = response.json()
        return json_response

    async def aclose(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    @staticmethod
    def get_data(response: dict[str, Any]) -> dict[str, Any]:
        """Extract data from GraphQL response."""
        if "errors" in response:
            errors = response["errors"]
            raise ValueError(f"GraphQL errors: {errors}")
        if "data" not in response:
            raise ValueError("GraphQL response missing 'data' field")
        data: dict[str, Any] = response["data"]
        if data is None:
            raise ValueError("GraphQL response data is null")
        return data
