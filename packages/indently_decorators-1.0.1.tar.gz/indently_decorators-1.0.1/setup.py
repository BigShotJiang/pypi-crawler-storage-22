from setuptools import setup, find_packages

setup(
    name = "indently-decorators",
    url="https://github.com/xystudio889/five_decorators",
    version = "1.0.1",
    packages = find_packages(),
    install_requires = ["deprecated"],
    python_requires = ">=3.6",
    author = "indently",
    author_email = "173288240@qq.com",
    description = "These code by indently.",
    long_description = open("README.md",encoding="utf-8").read(),
    license = "MIT",
)
