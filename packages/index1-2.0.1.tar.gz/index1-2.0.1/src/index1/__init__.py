"""index1 - AI-native project knowledge base."""

__version__ = "0.2.0"

from .config import Config, load_config
from .db import Database
from .embed import Embedder, OllamaEmbedder, create_embedder
from .indexer import backfill_embeddings, index_files
from .search import SearchResponse, SearchResult, search

__all__ = [
    "Config",
    "Database",
    "Embedder",
    "OllamaEmbedder",
    "create_embedder",
    "SearchResponse",
    "SearchResult",
    "backfill_embeddings",
    "index_files",
    "load_config",
    "search",
]
