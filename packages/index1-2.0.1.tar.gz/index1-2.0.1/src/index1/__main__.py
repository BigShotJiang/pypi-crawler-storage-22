"""Allow running as: python -m index1"""

from index1.cli import main

main()
