"""智能分块器 — 按文件类型自动选择分块策略"""

from __future__ import annotations

from pathlib import Path

from .base import BaseChunker, Chunk, estimate_tokens
from .markdown import MarkdownChunker
from .python_code import PythonChunker
from .rust_code import RustChunker, JavaScriptChunker
from .text import TextChunker

_REGISTRY: dict[str, type[BaseChunker]] = {
    ".md": MarkdownChunker,
    ".markdown": MarkdownChunker,
    ".py": PythonChunker,
    ".rs": RustChunker,
    ".js": JavaScriptChunker,
    ".ts": JavaScriptChunker,
    ".jsx": JavaScriptChunker,
    ".tsx": JavaScriptChunker,
}

_DEFAULT_CHUNKER = TextChunker


def get_chunker(file_path: str) -> BaseChunker:
    """根据文件扩展名自动选择分块器"""
    ext = Path(file_path).suffix.lower()
    chunker_cls = _REGISTRY.get(ext, _DEFAULT_CHUNKER)
    return chunker_cls()


__all__ = [
    "Chunk",
    "BaseChunker",
    "get_chunker",
    "estimate_tokens",
    "MarkdownChunker",
    "PythonChunker",
    "RustChunker",
    "JavaScriptChunker",
    "TextChunker",
]
