"""JavaScript/TypeScript 分块 — 已合并到 rust_code.py"""

from .rust_code import JavaScriptChunker  # noqa: F401
