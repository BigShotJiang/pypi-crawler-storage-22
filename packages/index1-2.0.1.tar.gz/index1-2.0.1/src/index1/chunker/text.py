"""通用文本段落分块（兜底）"""

from __future__ import annotations

import re

from .base import BaseChunker, Chunk, estimate_tokens

OVERLAP_TOKENS = 50
OVERLAP_CHARS = int(OVERLAP_TOKENS * 3.5)


class TextChunker(BaseChunker):
    """按段落分割，带重叠窗口"""

    def chunk(self, content: str, file_path: str) -> list[Chunk]:
        content = content.strip()
        if not content:
            return []

        # 按双换行分段
        paragraphs = re.split(r"\n\n+", content)
        paragraphs = [p.strip() for p in paragraphs if p.strip()]

        if not paragraphs:
            return []

        # 合并小段落，分割大段落
        chunks: list[Chunk] = []
        current = ""

        for para in paragraphs:
            candidate = (current + "\n\n" + para) if current else para

            if estimate_tokens(candidate) > self.MAX_CHUNK_TOKENS and current:
                chunks.append(self._make_chunk(current, len(chunks)))
                # 重叠：取上一段末尾
                overlap = current[-OVERLAP_CHARS:] if len(current) > OVERLAP_CHARS else ""
                current = (overlap + "\n\n" + para).strip() if overlap else para
            else:
                current = candidate

        if current.strip():
            chunks.append(self._make_chunk(current, len(chunks)))

        return chunks

    def _make_chunk(self, text: str, index: int) -> Chunk:
        return Chunk(content=text.strip(), chunk_index=index)
