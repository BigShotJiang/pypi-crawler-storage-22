"""cognition — 工作情节记忆模块

认知事实的存储、检索、维护。
独立 cognitive.db，与 corpus (knowledge.db) 隔离。
"""
