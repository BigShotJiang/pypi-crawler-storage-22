"""Gemini Observer Provider — Google Gemini OpenAI 兼容接口

https://ai.google.dev/gemini-api/docs/openai
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

from ...config import OBSERVER_MODELS
from .openai_compat import OpenAICompatProvider

if TYPE_CHECKING:
    from ...config import Config


class GeminiObserverProvider(OpenAICompatProvider):
    """Gemini Flash — 通过 OpenAI 兼容接口调用"""

    def __init__(self, config: Config):
        api_key = getattr(config, "gemini_api_key", "") or os.environ.get("GEMINI_API_KEY", "")
        super().__init__(
            name="gemini",
            base_url="https://generativelanguage.googleapis.com/v1beta/openai",
            api_key=api_key,
            model=OBSERVER_MODELS["gemini"],
            cooldown_name="observer_gemini",
        )
