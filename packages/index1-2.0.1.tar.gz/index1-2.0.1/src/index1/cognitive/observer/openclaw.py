"""OpenClaw Observer Provider — vLLM Gateway (AMD Developer Cloud)

本地或远程 vLLM 兼容服务，默认 localhost:18789。
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

from ...config import OBSERVER_MODELS
from .openai_compat import OpenAICompatProvider

if TYPE_CHECKING:
    from ...config import Config


class OpenClawObserverProvider(OpenAICompatProvider):
    """OpenClaw vLLM Gateway — 通过 OpenAI 兼容接口调用"""

    def __init__(self, config: Config):
        api_key = getattr(config, "openclaw_api_key", "") or os.environ.get("OPENCLAW_API_KEY", "")
        base_url = getattr(config, "openclaw_url", "") or "http://localhost:18789"
        super().__init__(
            name="openclaw",
            base_url=f"{base_url}/v1",
            api_key=api_key,
            model=OBSERVER_MODELS["openclaw"],
            cooldown_name="observer_openclaw",
        )
