"""OpenRouter Observer Provider — 多模型聚合 API

https://openrouter.ai/docs
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

from ...config import OBSERVER_MODELS
from .openai_compat import OpenAICompatProvider

if TYPE_CHECKING:
    from ...config import Config


class OpenRouterObserverProvider(OpenAICompatProvider):
    """OpenRouter — 通过 OpenAI 兼容接口调用"""

    def __init__(self, config: Config):
        api_key = getattr(config, "openrouter_api_key", "") or os.environ.get("OPENROUTER_API_KEY", "")
        super().__init__(
            name="openrouter",
            base_url="https://openrouter.ai/api/v1",
            api_key=api_key,
            model=OBSERVER_MODELS["openrouter"],
            cooldown_name="observer_openrouter",
        )
