# Tree-sitter Tag Queries

These `.scm` files are copied from [Aider](https://github.com/Aider-AI/aider/tree/main/aider/queries/tree-sitter-language-pack) (Apache 2.0 License).

They define tree-sitter queries for extracting symbol definitions and references across 30 programming languages.

## Source

- Repository: https://github.com/Aider-AI/aider
- License: Apache-2.0
- Path: `aider/queries/tree-sitter-language-pack/`
