"""pytest 公共 fixtures"""

import tempfile
from pathlib import Path

import pytest


@pytest.fixture
def tmp_db(tmp_path):
    """临时数据库路径"""
    return tmp_path / "test.db"


@pytest.fixture
def sample_markdown():
    """示例 Markdown 内容"""
    return """# Risk Module

Overview of risk management.

## Liquidation

Progressive liquidation triggers when health factor < 1.2.
The system calculates required collateral and initiates partial liquidation.

## Margin Call

Margin call is triggered when account equity falls below maintenance margin.
"""


@pytest.fixture
def sample_python():
    """示例 Python 代码"""
    return '''import os

CONSTANT = 42


class RiskEngine:
    """风控引擎"""

    def liquidate(self, position):
        """清算仓位"""
        return position.close()

    def margin_call(self, account):
        """追加保证金"""
        return account.notify()


def helper():
    """辅助函数"""
    return True
'''
