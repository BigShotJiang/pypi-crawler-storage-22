"""index1 - AI-native project knowledge base."""

__version__ = "0.1.0"

from .config import Config, load_config
from .db import Database
from .embed import OllamaEmbedder
from .indexer import index_files
from .search import SearchResponse, SearchResult, search

__all__ = [
    "Config",
    "Database",
    "OllamaEmbedder",
    "SearchResponse",
    "SearchResult",
    "index_files",
    "load_config",
    "search",
]
