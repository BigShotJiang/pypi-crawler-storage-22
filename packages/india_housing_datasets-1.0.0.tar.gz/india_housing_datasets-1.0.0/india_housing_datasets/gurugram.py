import warnings

def fetch_gurugram_housing():
    warnings.warn(
        "Gurugram housing data is not included in v1.0. "
        "Use load_housing(city) with available cities instead.",
        DeprecationWarning,
        stacklevel=2
    )
    raise NotImplementedError(
        "Gurugram dataset is not available in this version."
    )
