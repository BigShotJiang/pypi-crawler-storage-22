import pandas as pd
from pathlib import Path

DATA_DIR = Path(__file__).parent / "data"

CITY_FILES = {
    "mumbai": "mumbai.csv",
    "delhi": "delhi.csv",
    "bangalore": "bangalore.csv",
    "hyderabad": "hyderabad.csv",
    "chennai": "chennai.csv",
    "pune": "pune.csv",
    "ahmedabad": "ahmedabad.csv",
    "kolkata": "kolkata.csv",
    "jaipur": "jaipur.csv",
    "chandigarh": "chandigarh.csv",
}

def load_housing(city: str) -> pd.DataFrame:
    city = city.lower()

    if city not in CITY_FILES:
        raise ValueError(
            f"City '{city}' not supported. Available cities: {list(CITY_FILES.keys())}"
        )

    df = pd.read_csv(DATA_DIR / CITY_FILES[city])
    return df
