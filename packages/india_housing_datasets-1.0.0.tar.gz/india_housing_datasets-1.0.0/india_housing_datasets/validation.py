import pandas as pd
from pathlib import Path

# Path to your data folder
DATA_DIR = Path("india_housing_datasets/data")

# Final v1.0 schema (MUST match exactly)
REQUIRED_COLUMNS = [
    "city",
    "locality",
    "area_sqft",
    "bhk",
    "bath",
    "floor",
    "age_years",
    "price_lakhs"
]

def validate_city_file(file_path):
    print(f"Checking {file_path.name}...")

    df = pd.read_csv(file_path)

    # 1. Column check
    if list(df.columns) != REQUIRED_COLUMNS:
        raise ValueError(f"❌ Column mismatch in {file_path.name}")

    # 2. Minimum rows
    if len(df) < 500:
        raise ValueError(f"❌ Less than 500 rows in {file_path.name}")

    # 3. Validation rules
    if not df["area_sqft"].between(300, 4000).all():
        raise ValueError(f"❌ area_sqft out of range in {file_path.name}")

    if not df["bhk"].between(1, 6).all():
        raise ValueError(f"❌ bhk out of range in {file_path.name}")

    if not (df["bath"] <= df["bhk"] + 1).all():
        raise ValueError(f"❌ bath invalid in {file_path.name}")

    if not df["floor"].between(0, 40).all():
        raise ValueError(f"❌ floor out of range in {file_path.name}")

    if not df["age_years"].between(0, 30).all():
        raise ValueError(f"❌ age_years out of range in {file_path.name}")

    if not (df["price_lakhs"] > 0).all():
        raise ValueError(f"❌ price_lakhs invalid in {file_path.name}")

    print(f"✅ {file_path.name} passed")

def run_validation():
    for csv_file in DATA_DIR.glob("*.csv"):
        validate_city_file(csv_file)

    print("\n🎉 ALL FILES PASSED VALIDATION")

if __name__ == "__main__":
    run_validation()
