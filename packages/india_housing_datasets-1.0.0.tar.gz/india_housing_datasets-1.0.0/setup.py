from setuptools import setup, find_packages

setup(
    name="india-housing-datasets",
    version="1.0.0",
    author="Vishal Baghel",
    author_email="baghelvishal264@gmail.com",
    description="Standardized Indian housing datasets for data analysis, visualization, and machine learning practice.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/Rvbaghel/india_housing_datasets",
    packages=find_packages(),
    include_package_data=True,
    package_data={"india_housing_datasets": ["data/*.csv"]},
    install_requires=[
        "pandas>=1.3.0",
    ],
    keywords="india indian housing dataset real estate housing price pandas python machine learning data science",

    project_urls={
        "Documentation": "https://github.com/Rvbaghel/india_housing_datasets#readme",
        "Source": "https://github.com/Rvbaghel/india_housing_datasets",
        "Bug Tracker": "https://github.com/Rvbaghel/india_housing_datasets/issues",
    },
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
)
