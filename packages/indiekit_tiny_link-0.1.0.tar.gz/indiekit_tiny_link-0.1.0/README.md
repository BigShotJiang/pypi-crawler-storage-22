# 🔗 Tiny Link

[![Python](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)

Self-hosted URL shortener with click tracking.

自托管短链接服务，支持点击统计。

## Features

- 🎯 自定义短码或自动生成
- 📊 点击统计和访客信息
- ⏰ 可选链接过期时间
- 💾 JSON 文件存储，零依赖

## Quick Start

```bash
cd /root/source/side-projects/tiny-link

# Install
pip install fastapi uvicorn python-dotenv

# Configure
cp .env.example .env
# Edit: set TINYLINK_BASE_URL to your domain

# Run
uvicorn src.main:app --port 8083
```

## Usage

### Create Short Link

```bash
# Auto-generate code
curl -X POST http://localhost:8083/api/links \
  -H "Content-Type: application/json" \
  -d '{"url": "https://example.com/very/long/url"}'

# Custom code
curl -X POST http://localhost:8083/api/links \
  -H "Content-Type: application/json" \
  -d '{"url": "https://example.com", "code": "mylink"}'
```

### Redirect

```
http://localhost:8083/abc123 → https://example.com/very/long/url
```

### View Stats

```bash
curl http://localhost:8083/api/links/abc123/stats
```

## API

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/{code}` | GET | Redirect to original URL |
| `/api/links` | GET | List all links |
| `/api/links` | POST | Create new link |
| `/api/links/{code}` | GET | Get link details |
| `/api/links/{code}/stats` | GET | Click statistics |
| `/api/links/{code}` | DELETE | Delete link |

### 在线体验

```bash
# 创建短链接
curl -X POST https://s.indiekit.ai/api/links \
  -H "Content-Type: application/json" \
  -d '{"url": "https://github.com/indiekitai"}'

# 查看统计
curl https://s.indiekit.ai/api/links/{code}/stats
```

## Data Storage

```
data/
├── links.json         # All short links
└── clicks/
    └── 2026-02-13.jsonl  # Daily click logs
```

## License

MIT
