# FK Detective - Complete Implementation

This directory contains the complete implementation of **FK Detective**, an intelligent tool for inferring foreign key relationships in database schemas.

## 🎯 What This Is

FK Detective analyzes database schemas and uses multiple heuristic strategies to detect missing foreign key relationships. It provides confidence scores and can output results in multiple formats (JSON, SQL, Markdown).


## 📄 License

MIT License - see the project files for details.

---

**Built with ❤️ as a practical tool for database analysis**

Questions? Check the documentation files or run the examples to see it in action!
