from infer_db.connectors.factory import ConnectorFactory
from infer_db.pipeline import InferenceEngine
from infer_db.strategies.pk_strategies import (
    ExistingConstraintStrategy, 
    SurrogateKeyStrategy, 
    UniquenessStrategy,
    DataValidationStrategy
)
from infer_db.strategies.fk_strategies import (
    ExistingConstraintFKStrategy, 
    NamingConventionFKStrategy, 
    ContainmentFKStrategy
)
from infer_db.utils.logger_util import logger

def infer_relationships(db_config: dict) -> dict:
    """
    Main entry point for the library.
    Connects to the DB, runs inference, and returns the schema report.
    """
    try:
        # 1. Initialize Connector
        logger.info("Initializing Database Connector...")
        connector = ConnectorFactory.create_connector("postgres", db_config)
        
        # 2. Initialize Engine
        engine = InferenceEngine(connector)

        # 3. Add Default Strategies (Batteries Included)
        # PKs
        engine.add_pk_strategy(ExistingConstraintStrategy()) 
        engine.add_pk_strategy(SurrogateKeyStrategy())       
        engine.add_pk_strategy(UniquenessStrategy()) 
        engine.add_pk_strategy(DataValidationStrategy())

        # FKs
        engine.add_fk_strategy(ExistingConstraintFKStrategy())
        engine.add_fk_strategy(NamingConventionFKStrategy())   
        engine.add_fk_strategy(ContainmentFKStrategy())

        # 4. Run Pipeline
        logger.info("Starting Relation Inference Pipeline...")
        report = engine.run()
        
        return report

    except Exception as e:
        logger.error(f"Inference failed: {e}")
        raise e