from abc import ABC, abstractmethod

class BaseConnector(ABC):
    @abstractmethod
    def connect(self):
        pass

    @abstractmethod
    def get_tables(self) -> list[str]:
        """Returns a list of table names."""
        pass

    @abstractmethod
    def get_columns_metadata(self, table_name: str) -> list[dict]:
        """Returns list of dicts: [{'column': name, 'dtype': type, 'is_nullable': bool}]"""
        pass

    @abstractmethod
    def get_existing_constraints(self) -> list[dict]:
        """Returns existing PKs and FKs from the system catalog."""
        pass

    @abstractmethod
    def get_column_stats(self, table: str, column: str) -> tuple | None:
        """Returns min, max, and distinct count for a column."""
        pass
    
    @abstractmethod
    def get_row_count(self, table_name: str) -> int:
        """Returns the total number of rows in a table."""
        pass

    @abstractmethod
    def get_existing_fks(self, table_name: str) -> list[dict]:
        """Returns existing foreign keys for a given table."""
        pass

    @abstractmethod
    def check_containment(self, source_table: str, source_col: str, target_table: str, target_col: str) -> bool:
        """Checks if all non-null values in source_col of source_table exist in target_col of target_table."""
        pass