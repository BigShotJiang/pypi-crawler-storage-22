
from .postgres import PostgresConnector
from infer_db.utils.logger_util import logger
import infer_db.config as config

class ConnectorFactory:
    @staticmethod
    def create_connector(db_type: str, config: dict):
        if db_type.lower() == 'postgres':
            conn = PostgresConnector(config)
            conn.connect()
            logger.info("Connected to PostgreSQL database.")
            return conn
        # elif db_type.lower() == 'mysql':
        #    return MySQLConnector(config)
        else:
            raise ValueError(f"Database type '{db_type}' is not supported yet.")
        
if __name__ == "__main__":
    # Example usage
    config = {
        'host': config.DB_HOST,
        'dbname': config.DB_NAME,
        'user': config.DB_USER,
        'password': config.DB_PASSWORD,
        'port': config.DB_PORT
    }
    connector = ConnectorFactory.create_connector('postgres', config)
    tables = connector.get_tables()
    logger.info(f"Tables: {tables}")
    metadata = connector.get_columns_metadata(tables[0] if tables else '')
    logger.info(f"Metadata for first table: {metadata}")
    existing_constraints = connector.get_existing_constraints()
    logger.info(f"Existing Constraints: {existing_constraints}")
    col_stats = connector.get_column_stats(tables[0], metadata[0]['column']) if tables and metadata else None
    logger.info(f"Column Stats: {col_stats}")
