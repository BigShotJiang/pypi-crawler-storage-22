import logging
import sys
from pathlib import Path

def setup_logger(name="FK_Inference", log_file="pipeline.log"):
    """Sets up a logger that outputs to both console and a file."""
    
    # Create logs directory if it doesn't exist
    log_path = Path("logs")
    log_path.mkdir(exist_ok=True)
    
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)

    # Prevent duplicate logs if setup is called multiple times
    if logger.hasHandlers():
        return logger

    # Format: Time - Name - Level - Message
    formatter = logging.Formatter(
        '%(asctime)s | %(levelname)-8s | %(name)s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    # 1. File Handler (Stores logs in logs/pipeline.log)
    file_handler = logging.FileHandler(log_path / log_file)
    file_handler.setFormatter(formatter)

    # 2. Console Handler (Prints to your screen)
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger

logger = setup_logger()