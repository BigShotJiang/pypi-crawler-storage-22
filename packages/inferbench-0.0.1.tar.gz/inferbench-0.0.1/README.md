# inferbench

A Python package for inference benchmarking.

## Installation

```bash
pip install inferbench
```

## Usage

```python
import inferbench
```

## License

MIT License - see LICENSE file for details.