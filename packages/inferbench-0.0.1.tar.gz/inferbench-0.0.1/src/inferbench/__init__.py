"""inferbench - A Python package for inference benchmarking."""
