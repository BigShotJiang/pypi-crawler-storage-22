from typing import Optional
from fastapi import HTTPException, status
from pydantic import ValidationError


class InferenceKitError(Exception):
    """Base exception for InferenceKit"""
    pass


class ModelNotFoundError(InferenceKitError):
    """Raised when a specified model is not found"""
    pass


class ProviderError(InferenceKitError):
    """Raised when there's an error with the provider"""
    pass


class AuthenticationError(ProviderError):
    """Raised when authentication with the provider fails"""
    pass


class RateLimitError(ProviderError):
    """Raised when rate limits are exceeded"""
    pass


class InvalidRequestError(InferenceKitError):
    """Raised when the request is invalid"""
    pass


class CacheError(InferenceKitError):
    """Raised when there's an error with the cache"""
    pass


class CacheFullError(CacheError):
    """Raised when the cache is full"""
    pass


class SerializationError(InferenceKitError):
    """Raised when serialization/deserialization fails"""
    pass


class ValidationError(InferenceKitError):
    """Raised when validation fails"""
    pass


class ConfigurationError(InferenceKitError):
    """Raised when configuration is invalid"""
    pass


class ConnectionError(InferenceKitError):
    """Raised when there's a connection error"""
    pass


class OperationTimeoutError(InferenceKitError):
    """Raised when an operation times out"""
    pass


class QuotaExceededError(ProviderError):
    """Raised when API quotas are exceeded"""
    pass


def handle_validation_error(error: ValidationError) -> dict:
    """Convert Pydantic validation errors to a standard format"""
    return {
        "error": "validation_error",
        "message": "Invalid request data",
        "details": error.errors()
    }


class BackendError(InferenceKitError):
    """Raised when there's an error with the backend"""
    pass

class StreamingError(InferenceKitError):
    """Raised when there's an error with streaming"""
    pass