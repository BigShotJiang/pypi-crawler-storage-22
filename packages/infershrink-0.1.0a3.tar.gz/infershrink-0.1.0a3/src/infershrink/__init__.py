"""InferShrink — Cut LLM costs 80%+ with one line of code.

Usage::

    import openai
    from infershrink import optimize

    client = optimize(openai.Client())
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": "Hello!"}],
    )
    # InferShrink automatically compressed the prompt and routed
    # to the cheapest model that can handle this simple request.

    # Check savings:
    print(client.infershrink_tracker.summary())
"""

from .wrapper import optimize, InferShrinkClient
from .classifier import classify
from .compressor import compress
from .router import route
from .tracker import Tracker
from .config import build_config, DEFAULT_CONFIG
from .types import (
    Complexity,
    ClassificationResult,
    CompressionResult,
    RoutingDecision,
    RequestRecord,
    SessionStats,
)

__version__ = "0.1.0"

__all__ = [
    "optimize",
    "InferShrinkClient",
    "classify",
    "compress",
    "route",
    "Tracker",
    "build_config",
    "DEFAULT_CONFIG",
    "Complexity",
    "ClassificationResult",
    "CompressionResult",
    "RoutingDecision",
    "RequestRecord",
    "SessionStats",
    "__version__",
]
