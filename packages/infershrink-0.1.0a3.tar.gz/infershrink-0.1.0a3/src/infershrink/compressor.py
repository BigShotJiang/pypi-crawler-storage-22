"""Prompt compressor — optionally uses TokenShrink to reduce token count."""

from __future__ import annotations

import copy
from typing import Any, Dict, List

from .types import Complexity, CompressionResult

# Try to import tokenshrink; gracefully degrade if not installed
_tokenshrink_available = False
_compress_fn = None

try:
    import tokenshrink  # type: ignore[import-untyped]

    _tokenshrink_available = True

    def _ts_compress(text: str) -> str:
        """Compress text using TokenShrink."""
        result = tokenshrink.compress(text)
        if isinstance(result, str):
            return result
        # Some versions return a dict/object
        if hasattr(result, "compressed"):
            return result.compressed
        if isinstance(result, dict):
            return result.get("compressed", result.get("text", text))
        return str(result)

    _compress_fn = _ts_compress

except ImportError:
    pass


def _estimate_tokens(text: str) -> int:
    """Rough token estimate (~4 chars per token)."""
    return max(1, len(text) // 4)


def _compress_message_content(content: Any) -> Any:
    """Compress a single message's content field."""
    if _compress_fn is None:
        return content

    if isinstance(content, str):
        return _compress_fn(content)

    if isinstance(content, list):
        compressed_parts = []
        for part in content:
            if isinstance(part, dict) and part.get("type") == "text":
                compressed_part = copy.deepcopy(part)
                compressed_part["text"] = _compress_fn(part.get("text", ""))
                compressed_parts.append(compressed_part)
            else:
                compressed_parts.append(part)
        return compressed_parts

    return content


def compress(
    messages: List[Dict[str, Any]],
    complexity: Complexity,
    config: Dict[str, Any],
) -> CompressionResult:
    """Compress messages if conditions are met.

    Parameters
    ----------
    messages:
        The messages array (OpenAI chat format).
    complexity:
        The classified complexity of the task.
    config:
        Full InferShrink config dict.

    Returns
    -------
    CompressionResult
    """
    compression_cfg = config.get("compression", {})
    enabled = compression_cfg.get("enabled", True)
    min_tokens = compression_cfg.get("min_tokens", 500)
    skip_for = compression_cfg.get("skip_for", ["SECURITY_CRITICAL"])

    # Calculate original token count
    original_tokens = 0
    for msg in messages:
        content = msg.get("content", "")
        if isinstance(content, str):
            original_tokens += _estimate_tokens(content)
        elif isinstance(content, list):
            for part in content:
                if isinstance(part, dict) and part.get("type") == "text":
                    original_tokens += _estimate_tokens(part.get("text", ""))
                elif isinstance(part, str):
                    original_tokens += _estimate_tokens(part)

    # Determine if we should skip compression
    should_skip = (
        not enabled
        or complexity.value in skip_for
        or original_tokens < min_tokens
        or not _tokenshrink_available
    )

    if should_skip:
        return CompressionResult(
            messages=messages,
            original_tokens=original_tokens,
            compressed_tokens=original_tokens,
            compression_ratio=1.0,
            was_compressed=False,
        )

    # Compress messages (skip system messages to preserve instructions)
    compressed_messages = []
    compressed_tokens = 0

    for msg in messages:
        new_msg = copy.deepcopy(msg)
        role = msg.get("role", "")

        # Don't compress system prompts (they're instructions, not data)
        if role == "system":
            content = msg.get("content", "")
            if isinstance(content, str):
                compressed_tokens += _estimate_tokens(content)
            compressed_messages.append(new_msg)
            continue

        # Compress user and assistant messages
        new_msg["content"] = _compress_message_content(msg.get("content", ""))

        content = new_msg.get("content", "")
        if isinstance(content, str):
            compressed_tokens += _estimate_tokens(content)
        elif isinstance(content, list):
            for part in content:
                if isinstance(part, dict) and part.get("type") == "text":
                    compressed_tokens += _estimate_tokens(part.get("text", ""))
                elif isinstance(part, str):
                    compressed_tokens += _estimate_tokens(part)

        compressed_messages.append(new_msg)

    ratio = compressed_tokens / original_tokens if original_tokens > 0 else 1.0

    return CompressionResult(
        messages=compressed_messages,
        original_tokens=original_tokens,
        compressed_tokens=compressed_tokens,
        compression_ratio=ratio,
        was_compressed=True,
    )


def is_tokenshrink_available() -> bool:
    """Check if TokenShrink is installed and usable."""
    return _tokenshrink_available
