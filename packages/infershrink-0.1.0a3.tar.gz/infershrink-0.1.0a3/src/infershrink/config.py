"""Configuration for InferShrink — model tiers, thresholds, defaults."""

from __future__ import annotations

import copy
from typing import Any, Dict

DEFAULT_CONFIG: Dict[str, Any] = {
    "tiers": {
        "tier1": {
            "models": ["gpt-4o-mini"],
            "max_complexity": "SIMPLE",
            "cost_per_1k_input": 0.00015,
            "cost_per_1k_output": 0.0006,
        },
        "tier2": {
            "models": ["gpt-4o"],
            "max_complexity": "MODERATE",
            "cost_per_1k_input": 0.0025,
            "cost_per_1k_output": 0.01,
        },
        "tier3": {
            "models": ["gpt-5.2", "claude-opus-4-6"],
            "max_complexity": "COMPLEX",
            "cost_per_1k_input": 0.015,
            "cost_per_1k_output": 0.075,
        },
    },
    "compression": {
        "enabled": True,
        "min_tokens": 500,
        "skip_for": ["SECURITY_CRITICAL"],
    },
    "quality_floor": 0.95,
    "cost_tracking": True,
}

# Map complexity → tier name
COMPLEXITY_TO_TIER: Dict[str, str] = {
    "SIMPLE": "tier1",
    "MODERATE": "tier2",
    "COMPLEX": "tier3",
    "SECURITY_CRITICAL": "tier3",
}


def _deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    """Recursively merge *override* into *base*, returning a new dict."""
    merged = copy.deepcopy(base)
    for key, value in override.items():
        if (
            key in merged
            and isinstance(merged[key], dict)
            and isinstance(value, dict)
        ):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = copy.deepcopy(value)
    return merged


def build_config(user_config: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """Return the effective config by merging user overrides into defaults."""
    if user_config is None:
        return copy.deepcopy(DEFAULT_CONFIG)
    return _deep_merge(DEFAULT_CONFIG, user_config)
