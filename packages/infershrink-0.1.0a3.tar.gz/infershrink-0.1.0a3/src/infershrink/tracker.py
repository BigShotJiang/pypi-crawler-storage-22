"""Cost tracking and savings calculator."""

from __future__ import annotations

import threading
from typing import Any, Dict

from .types import Complexity, RequestRecord, SessionStats


# Default cost per 1K tokens (input) by model — rough estimates in USD
_MODEL_COST_INPUT: Dict[str, float] = {
    "gpt-4o-mini": 0.00015,
    "gpt-4o": 0.0025,
    "gpt-4-turbo": 0.01,
    "gpt-5.2": 0.015,
    "claude-opus-4-6": 0.015,
    "claude-sonnet-4-20250514": 0.003,
    "claude-3-haiku-20240307": 0.00025,
}


class Tracker:
    """Tracks request costs and calculates cumulative savings."""

    def __init__(self, config: Dict[str, Any] | None = None) -> None:
        self._config = config or {}
        self._lock = threading.Lock()
        self._stats = SessionStats()

    def _get_cost_per_1k(self, model: str) -> float:
        """Look up input cost per 1K tokens for a model."""
        # First check tier config for explicit costs
        tiers = self._config.get("tiers", {})
        for _tier_name, tier_cfg in tiers.items():
            if model in tier_cfg.get("models", []):
                return tier_cfg.get("cost_per_1k_input", 0.0)

        # Fall back to built-in table
        return _MODEL_COST_INPUT.get(model, 0.005)  # conservative default

    def record(
        self,
        original_model: str,
        routed_model: str,
        original_tokens: int,
        compressed_tokens: int,
        complexity: Complexity,
    ) -> RequestRecord:
        """Record a single request and calculate savings.

        Returns the RequestRecord with computed costs.
        """
        cost_original = (original_tokens / 1000) * self._get_cost_per_1k(original_model)
        cost_routed = (compressed_tokens / 1000) * self._get_cost_per_1k(routed_model)
        savings = max(0.0, cost_original - cost_routed)

        record = RequestRecord(
            original_model=original_model,
            routed_model=routed_model,
            original_tokens=original_tokens,
            compressed_tokens=compressed_tokens,
            complexity=complexity,
            estimated_cost_original=cost_original,
            estimated_cost_routed=cost_routed,
            savings=savings,
        )

        with self._lock:
            self._stats.total_requests += 1
            self._stats.total_original_tokens += original_tokens
            self._stats.total_compressed_tokens += compressed_tokens
            self._stats.total_tokens_saved += max(0, original_tokens - compressed_tokens)
            self._stats.total_estimated_savings_usd += savings
            self._stats.records.append(record)

            if original_model != routed_model:
                self._stats.requests_downgraded += 1
            if compressed_tokens < original_tokens:
                self._stats.requests_compressed += 1

            if self._stats.total_original_tokens > 0:
                self._stats.compression_ratio = (
                    self._stats.total_compressed_tokens
                    / self._stats.total_original_tokens
                )

        return record

    def stats(self) -> SessionStats:
        """Return current session statistics (snapshot)."""
        with self._lock:
            # Return a copy so callers can't mutate internal state
            return SessionStats(
                total_requests=self._stats.total_requests,
                total_original_tokens=self._stats.total_original_tokens,
                total_compressed_tokens=self._stats.total_compressed_tokens,
                total_tokens_saved=self._stats.total_tokens_saved,
                total_estimated_savings_usd=self._stats.total_estimated_savings_usd,
                requests_downgraded=self._stats.requests_downgraded,
                requests_compressed=self._stats.requests_compressed,
                compression_ratio=self._stats.compression_ratio,
                records=list(self._stats.records),
            )

    def reset(self) -> None:
        """Reset all tracked statistics."""
        with self._lock:
            self._stats = SessionStats()

    def summary(self) -> str:
        """Return a human-readable summary of savings."""
        s = self.stats()
        pct_tokens = (
            (1 - s.compression_ratio) * 100 if s.compression_ratio < 1 else 0
        )
        return (
            f"InferShrink Session Stats\n"
            f"{'=' * 40}\n"
            f"Total requests:       {s.total_requests}\n"
            f"Requests downgraded:  {s.requests_downgraded}\n"
            f"Requests compressed:  {s.requests_compressed}\n"
            f"Original tokens:      {s.total_original_tokens:,}\n"
            f"Compressed tokens:    {s.total_compressed_tokens:,}\n"
            f"Tokens saved:         {s.total_tokens_saved:,} ({pct_tokens:.1f}%)\n"
            f"Estimated savings:    ${s.total_estimated_savings_usd:.4f}\n"
            f"{'=' * 40}"
        )
