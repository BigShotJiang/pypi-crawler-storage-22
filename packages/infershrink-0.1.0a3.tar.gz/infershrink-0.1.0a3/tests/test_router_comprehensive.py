"""Comprehensive router tests — edge cases, fallback behavior, all complexity paths."""

import pytest

from infershrink.config import build_config
from infershrink.router import route, _tier_index, _find_tier_for_model, _TIER_ORDER
from infershrink.types import Complexity, RoutingDecision


class TestTierHelpers:
    """Test internal helper functions."""

    def test_tier_index_known(self):
        assert _tier_index("tier1") == 0
        assert _tier_index("tier2") == 1
        assert _tier_index("tier3") == 2

    def test_tier_index_unknown(self):
        assert _tier_index("tier99") == len(_TIER_ORDER)

    def test_tier_order(self):
        assert _TIER_ORDER == ["tier1", "tier2", "tier3"]

    def test_find_tier_for_known_model(self):
        config = build_config()
        tiers = config["tiers"]
        assert _find_tier_for_model("gpt-4o-mini", tiers) == "tier1"
        assert _find_tier_for_model("gpt-4o", tiers) == "tier2"
        assert _find_tier_for_model("gpt-5.2", tiers) == "tier3"
        assert _find_tier_for_model("claude-opus-4-6", tiers) == "tier3"

    def test_find_tier_for_unknown_model(self):
        config = build_config()
        tiers = config["tiers"]
        assert _find_tier_for_model("unknown-model", tiers) is None

    def test_find_tier_empty_tiers(self):
        assert _find_tier_for_model("gpt-4o", {}) is None


class TestRoutingDecisionStructure:
    """Verify RoutingDecision fields are always correct."""

    def test_original_model_preserved(self):
        config = build_config()
        for model in ["gpt-4o-mini", "gpt-4o", "gpt-5.2", "unknown"]:
            for complexity in Complexity:
                decision = route(model, complexity, config)
                assert decision.original_model == model

    def test_complexity_preserved(self):
        config = build_config()
        for complexity in Complexity:
            decision = route("gpt-4o", complexity, config)
            assert decision.complexity == complexity

    def test_routed_model_always_string(self):
        config = build_config()
        for model in ["gpt-4o-mini", "gpt-4o", "gpt-5.2", "unknown"]:
            for complexity in Complexity:
                decision = route(model, complexity, config)
                assert isinstance(decision.routed_model, str)
                assert len(decision.routed_model) > 0


class TestAllRoutingCombinations:
    """Test every model × complexity combination systematically."""

    @pytest.fixture
    def config(self):
        return build_config()

    # gpt-4o-mini (tier1) × all complexities
    def test_tier1_simple(self, config):
        d = route("gpt-4o-mini", Complexity.SIMPLE, config)
        assert d.routed_model == "gpt-4o-mini"
        assert d.was_downgraded is False

    def test_tier1_moderate(self, config):
        d = route("gpt-4o-mini", Complexity.MODERATE, config)
        assert d.routed_model == "gpt-4o-mini"
        # Task is MORE complex than model → keep original (no upgrade)
        assert d.was_upgraded is False

    def test_tier1_complex(self, config):
        d = route("gpt-4o-mini", Complexity.COMPLEX, config)
        assert d.routed_model == "gpt-4o-mini"

    def test_tier1_security(self, config):
        d = route("gpt-4o-mini", Complexity.SECURITY_CRITICAL, config)
        assert d.routed_model == "gpt-4o-mini"

    # gpt-4o (tier2) × all complexities
    def test_tier2_simple(self, config):
        d = route("gpt-4o", Complexity.SIMPLE, config)
        assert d.routed_model == "gpt-4o-mini"
        assert d.was_downgraded is True

    def test_tier2_moderate(self, config):
        d = route("gpt-4o", Complexity.MODERATE, config)
        assert d.routed_model == "gpt-4o"

    def test_tier2_complex(self, config):
        d = route("gpt-4o", Complexity.COMPLEX, config)
        assert d.routed_model == "gpt-4o"

    def test_tier2_security(self, config):
        d = route("gpt-4o", Complexity.SECURITY_CRITICAL, config)
        assert d.routed_model == "gpt-4o"

    # gpt-5.2 (tier3) × all complexities
    def test_tier3_simple(self, config):
        d = route("gpt-5.2", Complexity.SIMPLE, config)
        assert d.routed_model == "gpt-4o-mini"
        assert d.was_downgraded is True

    def test_tier3_moderate(self, config):
        d = route("gpt-5.2", Complexity.MODERATE, config)
        assert d.routed_model == "gpt-4o"
        assert d.was_downgraded is True

    def test_tier3_complex(self, config):
        d = route("gpt-5.2", Complexity.COMPLEX, config)
        assert d.routed_model == "gpt-5.2"

    def test_tier3_security(self, config):
        d = route("gpt-5.2", Complexity.SECURITY_CRITICAL, config)
        assert d.routed_model == "gpt-5.2"

    # claude-opus-4-6 (tier3) × all complexities
    def test_claude_opus_simple(self, config):
        d = route("claude-opus-4-6", Complexity.SIMPLE, config)
        assert d.routed_model == "gpt-4o-mini"
        assert d.was_downgraded is True

    def test_claude_opus_moderate(self, config):
        d = route("claude-opus-4-6", Complexity.MODERATE, config)
        assert d.routed_model == "gpt-4o"
        assert d.was_downgraded is True

    def test_claude_opus_complex(self, config):
        d = route("claude-opus-4-6", Complexity.COMPLEX, config)
        assert d.routed_model == "claude-opus-4-6"

    def test_claude_opus_security(self, config):
        d = route("claude-opus-4-6", Complexity.SECURITY_CRITICAL, config)
        assert d.routed_model == "claude-opus-4-6"


class TestUnknownModelRouting:
    """Test routing for models not in any tier."""

    @pytest.fixture
    def config(self):
        return build_config()

    def test_unknown_model_simple_routes_to_tier1(self, config):
        d = route("llama-3-70b", Complexity.SIMPLE, config)
        assert d.routed_model == "gpt-4o-mini"
        assert d.was_downgraded is True

    def test_unknown_model_moderate_routes_to_tier2(self, config):
        d = route("llama-3-70b", Complexity.MODERATE, config)
        assert d.routed_model == "gpt-4o"
        assert d.was_downgraded is True

    def test_unknown_model_complex_kept(self, config):
        d = route("llama-3-70b", Complexity.COMPLEX, config)
        assert d.routed_model == "llama-3-70b"

    def test_unknown_model_security_kept(self, config):
        d = route("llama-3-70b", Complexity.SECURITY_CRITICAL, config)
        assert d.routed_model == "llama-3-70b"

    def test_empty_string_model(self, config):
        d = route("", Complexity.SIMPLE, config)
        assert d.routed_model == "gpt-4o-mini"

    def test_very_long_model_name(self, config):
        long_name = "a" * 1000
        d = route(long_name, Complexity.COMPLEX, config)
        assert d.routed_model == long_name


class TestCustomConfigRouting:
    """Test routing with custom configurations."""

    def test_single_tier_config(self):
        config = build_config({
            "tiers": {
                "tier1": {"models": ["cheap-model"]},
                "tier2": {"models": ["mid-model"]},
                "tier3": {"models": ["expensive-model"]},
            }
        })
        d = route("expensive-model", Complexity.SIMPLE, config)
        assert d.routed_model == "cheap-model"

    def test_empty_models_list(self):
        """Tier with no models should fallback gracefully (BUG FIX: was IndexError)."""
        config = build_config({
            "tiers": {
                "tier1": {"models": []},
            }
        })
        # Previously caused IndexError: list index out of range
        # After fix, should fallback to original model
        d = route("gpt-4o", Complexity.SIMPLE, config)
        assert d.routed_model == "gpt-4o"  # Falls back to original
        assert d.was_downgraded is False  # Empty tier = no downgrade
        # The default config still has tier1 models since deep merge keeps them
        # Only if we explicitly set to empty will it be empty
        # With deep merge, tier1.models gets replaced by empty list
        # This will cause an IndexError in the router

    def test_missing_target_tier(self):
        """Config missing the target tier entirely."""
        config = build_config()
        # Remove tier1 entirely
        del config["tiers"]["tier1"]
        d = route("gpt-4o", Complexity.SIMPLE, config)
        # target_tier = tiers.get("tier1", {}) → empty dict
        # routed = {}.get("models", [original_model])[0] → original_model
        assert d.routed_model == "gpt-4o"

    def test_model_in_multiple_tiers(self):
        """If a model appears in multiple tiers, first match wins."""
        config = build_config({
            "tiers": {
                "tier1": {"models": ["shared-model"]},
                "tier2": {"models": ["shared-model"]},
            }
        })
        d = route("shared-model", Complexity.SIMPLE, config)
        # _find_tier_for_model iterates dict, returns first match
        assert d.routed_model == "shared-model"

    def test_no_tiers_at_all(self):
        """Config with empty tiers dict."""
        config = build_config()
        config["tiers"] = {}
        d = route("gpt-4o", Complexity.SIMPLE, config)
        # No tiers → unknown model → for SIMPLE, target_tier.get("models", [original_model])[0]
        # target_tier = {}.get("tier1", {}) = {}
        # routed = {}.get("models", ["gpt-4o"])[0] = "gpt-4o"
        assert d.routed_model == "gpt-4o"


class TestRoutingNeverUpgrades:
    """Verify the invariant: routing never upgrades to a more expensive model."""

    @pytest.fixture
    def config(self):
        return build_config()

    @pytest.mark.parametrize("model,complexity", [
        ("gpt-4o-mini", Complexity.MODERATE),
        ("gpt-4o-mini", Complexity.COMPLEX),
        ("gpt-4o-mini", Complexity.SECURITY_CRITICAL),
        ("gpt-4o", Complexity.COMPLEX),
        ("gpt-4o", Complexity.SECURITY_CRITICAL),
    ])
    def test_no_upgrade(self, config, model, complexity):
        """Model should never be upgraded to a more expensive tier."""
        d = route(model, complexity, config)
        original_tier = _find_tier_for_model(model, config["tiers"])
        routed_tier = _find_tier_for_model(d.routed_model, config["tiers"])

        if original_tier and routed_tier:
            assert _tier_index(routed_tier) <= _tier_index(original_tier)
        else:
            # Unknown model should be kept as-is or downgraded
            assert d.routed_model == model or d.was_downgraded
