def main():
    print("Hello from infogroove!")


if __name__ == "__main__":
    main()
