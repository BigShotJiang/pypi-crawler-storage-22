# infosign

A simple Python logging utility.

## Install
```bash
pip install infosign

```

## Usage
from infosign import log

log("Hello world")
log("Something failed", level="ERROR")
