"""ACI sync adapter module."""
