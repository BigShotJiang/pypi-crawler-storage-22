# Tests for adapters
