# infuseai

The official Python client for **InfuseAI**. This SDK empowers you to seamlessly integrate your custom RAG apps and Knowledge Bases into any Python application, including Django, Flask, and FastAPI.

## Installation

```bash
pip install infuseai
```

## Usage

### 1. Import and Initialize

Initialize the `InfuseClient` with your application credentials. You can retrieve these from your App's dashboard in InfuseAI.

```python
from infuseai import InfuseClient

client = InfuseClient(
    client_id="YOUR_CLIENT_ID",  # Your User ID
    app_id="YOUR_APP_ID",        # The specific AI App ID
    api_key="YOUR_API_KEY",      # The API Key for this App
)
```

### 2. Query Your App

Send prompts to your AI using the `query` method. The SDK manages context retrieval (RAG) and LLM inference behind the scenes.

```python
def ask_my_assistant():
    try:
        response = client.query("What does the documentation say about deployment?")
        
        print("Answer:", response.response)
        
        # If your app uses a Knowledge Base, you can inspect the sources used:
        if response.sources:
            print("Sources Used:", [s.name for s in response.sources])
            
    except Exception as e:
        print(f"Failed to query InfuseAI: {e}")

ask_my_assistant()
```

### 3. Using with Django

```python
# views.py
from django.http import JsonResponse
from infuseai import InfuseClient

client = InfuseClient(
    client_id="YOUR_CLIENT_ID",
    app_id="YOUR_APP_ID",
    api_key="YOUR_API_KEY",
)

def chat_view(request):
    query = request.POST.get("query", "")
    response = client.query(query)
    return JsonResponse({
        "response": response.response,
        "sources": [{"name": s.name, "content": s.content} for s in response.sources]
    })
```

### 4. Using with FastAPI

```python
from fastapi import FastAPI
from infuseai import InfuseClient

app = FastAPI()
client = InfuseClient(
    client_id="YOUR_CLIENT_ID",
    app_id="YOUR_APP_ID",
    api_key="YOUR_API_KEY",
)

@app.post("/chat")
async def chat(query: str):
    response = client.query(query)
    return {"response": response.response, "sources_count": len(response.sources)}
```

### 5. Context Manager Support

```python
from infuseai import InfuseClient

with InfuseClient(
    client_id="YOUR_CLIENT_ID",
    app_id="YOUR_APP_ID",
    api_key="YOUR_API_KEY",
) as client:
    response = client.query("Tell me about your product")
    print(response.response)
```

## API Reference

### `InfuseClient`

#### Constructor

```python
InfuseClient(client_id, app_id, api_key, base_url=None)
```

**Parameters:**

| Parameter   | Type   | Required | Description |
| :---------- | :----- | :------- | :---------- |
| `client_id` | `str`  | Yes      | Your unique user identifier from the dashboard. |
| `app_id`    | `str`  | Yes      | The ID of the specific app you want to interact with. |
| `api_key`   | `str`  | Yes      | The secret API key for authentication. |
| `base_url`  | `str`  | No       | Optional override for the API endpoint (default: Production). |

### `client.query(text)`

Sends a prompt to the InfuseAI backend.

#### Signature

```python
query(text: str) -> QueryResponse
```

#### Returns

A `QueryResponse` dataclass:

```python
@dataclass
class QueryResponse:
    response: str           # The AI's generated answer
    sources: List[Source]   # List of sources used for RAG
    credits_left: float     # Remaining credits
    credits_used: float     # Credits consumed by this query
    raw: Dict[str, Any]     # Raw API response
```

## Error Handling

The SDK provides specific exceptions for different error scenarios:

```python
from infuseai import (
    InfuseClient,
    InfuseAuthError,
    InfuseCreditsError,
    InfuseAPIError,
    InfuseConfigError,
)

try:
    response = client.query("Hello")
except InfuseAuthError as e:
    print(f"Authentication failed: {e.message}")
except InfuseCreditsError as e:
    print(f"Insufficient credits: {e.message}")
except InfuseAPIError as e:
    print(f"API error ({e.status_code}): {e.message}")
except InfuseConfigError as e:
    print(f"Configuration error: {e.message}")
```

## License

ISC
