# InfuseAI Python SDK
"""
InfuseAI - Python SDK for building AI applications with your own knowledge bases.

This SDK enables seamless integration with InfuseAI's RAG-powered API from
Django, Flask, FastAPI, and other Python frameworks.

Example:
    >>> from infuseai import InfuseClient
    >>> client = InfuseClient(
    ...     client_id="your-client-id",
    ...     app_id="your-app-id", 
    ...     api_key="your-api-key"
    ... )
    >>> response = client.query("What is your refund policy?")
    >>> print(response.response)
"""

from .client import InfuseClient
from .types import InfuseConfig, QueryResponse, Source
from .exceptions import (
    InfuseError,
    InfuseAuthError,
    InfuseCreditsError,
    InfuseAPIError,
    InfuseConfigError,
)

__version__ = "1.0.0"
__all__ = [
    "InfuseClient",
    "InfuseConfig",
    "QueryResponse",
    "Source",
    "InfuseError",
    "InfuseAuthError",
    "InfuseCreditsError",
    "InfuseAPIError",
    "InfuseConfigError",
]
