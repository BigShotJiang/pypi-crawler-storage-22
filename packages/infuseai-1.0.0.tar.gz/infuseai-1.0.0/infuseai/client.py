# InfuseAI Python SDK Client

import requests
from typing import Optional

from .types import InfuseConfig, QueryResponse
from .exceptions import (
    InfuseError,
    InfuseAuthError,
    InfuseCreditsError,
    InfuseAPIError,
    InfuseConfigError,
)


class InfuseClient:
    """Client for interacting with the InfuseAI API.
    
    This client enables you to query your InfuseAI apps from Python applications,
    including Django, Flask, FastAPI, and other frameworks.
    
    Example:
        >>> from infuseai import InfuseClient
        >>> client = InfuseClient(
        ...     client_id="your-client-id",
        ...     app_id="your-app-id",
        ...     api_key="your-api-key"
        ... )
        >>> response = client.query("What is your refund policy?")
        >>> print(response.response)
    """
    
    def __init__(
        self,
        client_id: str,
        app_id: str,
        api_key: str,
        base_url: str = "https://infuseai.in/",
    ):
        """Initialize the InfuseClient.
        
        Args:
            client_id: Your unique user identifier from the dashboard.
            app_id: The ID of the specific app you want to interact with.
            api_key: The secret API key for authentication.
            base_url: Optional override for the API endpoint (default: Production).
            
        Raises:
            InfuseConfigError: If required parameters are missing.
        """
        if not client_id or not app_id or not api_key:
            raise InfuseConfigError(
                "InfuseClient requires client_id, app_id, and api_key"
            )
        
        self.config = InfuseConfig(
            client_id=client_id,
            app_id=app_id,
            api_key=api_key,
            base_url=base_url.rstrip("/") + "/"  # Ensure trailing slash
        )
        
        self._session = requests.Session()
        self._session.headers.update({
            "Content-Type": "application/json",
            "x-client-id": self.config.client_id,
            "x-app-id": self.config.app_id,
            "x-api-key": self.config.api_key,
        })
    
    def query(self, text: str) -> QueryResponse:
        """Send a query to your InfuseAI app.
        
        The SDK manages context retrieval (RAG) and LLM inference behind the scenes.
        
        Args:
            text: The question or prompt to send to your AI app.
            
        Returns:
            QueryResponse: The AI's response with sources and credit information.
            
        Raises:
            InfuseAuthError: If authentication fails (invalid credentials).
            InfuseCreditsError: If credits are insufficient.
            InfuseAPIError: If the API returns an error.
            InfuseError: For network or other errors.
            
        Example:
            >>> response = client.query("What does the documentation say about deployment?")
            >>> print(response.response)
            >>> if response.sources:
            ...     for source in response.sources:
            ...         print(f"Source: {source.name}")
        """
        if not text or not text.strip():
            raise InfuseConfigError("Query text cannot be empty")
        
        url = f"{self.config.base_url}api/v1/query"
        
        try:
            response = self._session.post(
                url,
                json={"query": text},
                timeout=60,  # 60 second timeout for LLM inference
            )
            
            # Handle error responses
            if not response.ok:
                self._handle_error_response(response)
            
            data = response.json()
            return QueryResponse.from_dict(data)
            
        except requests.exceptions.Timeout:
            raise InfuseAPIError("Request timed out", status_code=408)
        except requests.exceptions.ConnectionError:
            raise InfuseAPIError("Failed to connect to InfuseAI API")
        except requests.exceptions.RequestException as e:
            raise InfuseError(f"Request failed: {str(e)}")
    
    def _handle_error_response(self, response: requests.Response) -> None:
        """Handle error responses from the API."""
        try:
            error_data = response.json()
            error_message = error_data.get("error", f"Request failed with status {response.status_code}")
        except Exception:
            error_message = f"Request failed with status {response.status_code}"
        
        if response.status_code == 401:
            raise InfuseAuthError(error_message, status_code=401)
        elif response.status_code == 402:
            raise InfuseCreditsError(error_message, status_code=402)
        elif response.status_code == 403:
            raise InfuseAuthError(error_message, status_code=403)
        elif response.status_code >= 400:
            raise InfuseAPIError(error_message, status_code=response.status_code)
    
    def close(self) -> None:
        """Close the client session."""
        self._session.close()
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
        return False
