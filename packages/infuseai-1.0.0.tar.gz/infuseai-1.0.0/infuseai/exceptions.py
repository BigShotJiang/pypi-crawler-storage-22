# InfuseAI Python SDK exceptions

class InfuseError(Exception):
    """Base exception for InfuseAI SDK errors."""
    def __init__(self, message: str, status_code: int = None):
        self.message = message
        self.status_code = status_code
        super().__init__(self.message)


class InfuseAuthError(InfuseError):
    """Raised for authentication errors (401, 403)."""
    pass


class InfuseCreditsError(InfuseError):
    """Raised when credits are insufficient (402)."""
    pass


class InfuseAPIError(InfuseError):
    """Raised for general API errors (4xx, 5xx)."""
    pass


class InfuseConfigError(InfuseError):
    """Raised for configuration errors (missing required parameters)."""
    pass
