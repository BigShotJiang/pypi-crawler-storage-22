# InfuseAI Python SDK type definitions

from dataclasses import dataclass, field
from typing import List, Optional, Any, Dict


@dataclass
class InfuseConfig:
    """Configuration for InfuseClient.
    
    Attributes:
        client_id: Your unique user identifier from the dashboard.
        app_id: The ID of the specific app you want to interact with.
        api_key: The secret API key for authentication.
        base_url: Optional override for the API endpoint (default: Production).
    """
    client_id: str
    app_id: str
    api_key: str
    base_url: str = "https://infuseai.in/"


@dataclass
class Source:
    """A source document used for RAG context.
    
    Attributes:
        name: Name of the source file/document.
        content: Snippet of the content used.
    """
    name: str
    content: str


@dataclass
class QueryResponse:
    """Response from the InfuseAI query API.
    
    Attributes:
        response: The AI's generated answer.
        sources: Optional list of sources used for RAG.
        credits_left: Remaining credits after the query.
        credits_used: Credits consumed by this query.
        raw: Raw response dictionary for accessing additional fields.
    """
    response: str
    sources: List[Source] = field(default_factory=list)
    credits_left: float = 0.0
    credits_used: float = 0.0
    raw: Dict[str, Any] = field(default_factory=dict)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "QueryResponse":
        """Create a QueryResponse from API response dictionary."""
        sources = []
        if data.get("sources"):
            for src in data["sources"]:
                sources.append(Source(
                    name=src.get("filename", src.get("name", "")),
                    content=src.get("text", src.get("content", ""))
                ))
        
        return cls(
            response=data.get("response", ""),
            sources=sources,
            credits_left=data.get("creditsLeft", 0.0),
            credits_used=data.get("creditsUsed", 0.0),
            raw=data
        )
