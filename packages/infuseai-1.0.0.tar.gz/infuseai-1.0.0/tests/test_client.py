# Tests for InfuseAI Python SDK

import pytest
from unittest.mock import Mock, patch, MagicMock

from infuseai import (
    InfuseClient,
    QueryResponse,
    Source,
    InfuseAuthError,
    InfuseCreditsError,
    InfuseAPIError,
    InfuseConfigError,
)


class TestInfuseClient:
    """Tests for InfuseClient class."""
    
    def test_init_success(self):
        """Test successful client initialization."""
        client = InfuseClient(
            client_id="test-client",
            app_id="test-app",
            api_key="test-key"
        )
        assert client.config.client_id == "test-client"
        assert client.config.app_id == "test-app"
        assert client.config.api_key == "test-key"
        assert client.config.base_url == "https://infuseai.in/"
    
    def test_init_custom_base_url(self):
        """Test client initialization with custom base URL."""
        client = InfuseClient(
            client_id="test-client",
            app_id="test-app",
            api_key="test-key",
            base_url="https://custom.api.com"
        )
        assert client.config.base_url == "https://custom.api.com/"
    
    def test_init_missing_client_id(self):
        """Test that missing client_id raises InfuseConfigError."""
        with pytest.raises(InfuseConfigError):
            InfuseClient(
                client_id="",
                app_id="test-app",
                api_key="test-key"
            )
    
    def test_init_missing_app_id(self):
        """Test that missing app_id raises InfuseConfigError."""
        with pytest.raises(InfuseConfigError):
            InfuseClient(
                client_id="test-client",
                app_id="",
                api_key="test-key"
            )
    
    def test_init_missing_api_key(self):
        """Test that missing api_key raises InfuseConfigError."""
        with pytest.raises(InfuseConfigError):
            InfuseClient(
                client_id="test-client",
                app_id="test-app",
                api_key=""
            )
    
    def test_query_empty_text(self):
        """Test that empty query text raises InfuseConfigError."""
        client = InfuseClient(
            client_id="test-client",
            app_id="test-app",
            api_key="test-key"
        )
        with pytest.raises(InfuseConfigError):
            client.query("")
    
    @patch('infuseai.client.requests.Session')
    def test_query_success(self, mock_session_class):
        """Test successful query."""
        # Setup mock
        mock_session = MagicMock()
        mock_session_class.return_value = mock_session
        
        mock_response = MagicMock()
        mock_response.ok = True
        mock_response.json.return_value = {
            "response": "This is the AI response",
            "sources": [
                {"filename": "doc1.pdf", "text": "Source content 1"},
                {"filename": "doc2.pdf", "text": "Source content 2"},
            ],
            "creditsLeft": 4.5,
            "creditsUsed": 0.5,
        }
        mock_session.post.return_value = mock_response
        
        client = InfuseClient(
            client_id="test-client",
            app_id="test-app",
            api_key="test-key"
        )
        
        result = client.query("What is your refund policy?")
        
        assert result.response == "This is the AI response"
        assert len(result.sources) == 2
        assert result.sources[0].name == "doc1.pdf"
        assert result.credits_left == 4.5
        assert result.credits_used == 0.5
    
    @patch('infuseai.client.requests.Session')
    def test_query_auth_error(self, mock_session_class):
        """Test query with authentication error."""
        mock_session = MagicMock()
        mock_session_class.return_value = mock_session
        
        mock_response = MagicMock()
        mock_response.ok = False
        mock_response.status_code = 401
        mock_response.json.return_value = {"error": "Invalid API Key"}
        mock_session.post.return_value = mock_response
        
        client = InfuseClient(
            client_id="test-client",
            app_id="test-app",
            api_key="invalid-key"
        )
        
        with pytest.raises(InfuseAuthError) as exc_info:
            client.query("test query")
        
        assert exc_info.value.status_code == 401
    
    @patch('infuseai.client.requests.Session')
    def test_query_credits_error(self, mock_session_class):
        """Test query with insufficient credits error."""
        mock_session = MagicMock()
        mock_session_class.return_value = mock_session
        
        mock_response = MagicMock()
        mock_response.ok = False
        mock_response.status_code = 402
        mock_response.json.return_value = {"error": "Insufficient credits"}
        mock_session.post.return_value = mock_response
        
        client = InfuseClient(
            client_id="test-client",
            app_id="test-app",
            api_key="test-key"
        )
        
        with pytest.raises(InfuseCreditsError) as exc_info:
            client.query("test query")
        
        assert exc_info.value.status_code == 402
    
    def test_context_manager(self):
        """Test client as context manager."""
        with InfuseClient(
            client_id="test-client",
            app_id="test-app",
            api_key="test-key"
        ) as client:
            assert client.config.client_id == "test-client"


class TestQueryResponse:
    """Tests for QueryResponse class."""
    
    def test_from_dict_basic(self):
        """Test creating QueryResponse from dictionary."""
        data = {
            "response": "Test response",
            "creditsLeft": 10.0,
            "creditsUsed": 1.0,
        }
        response = QueryResponse.from_dict(data)
        
        assert response.response == "Test response"
        assert response.credits_left == 10.0
        assert response.credits_used == 1.0
        assert response.sources == []
    
    def test_from_dict_with_sources(self):
        """Test creating QueryResponse with sources."""
        data = {
            "response": "Test response",
            "sources": [
                {"filename": "doc.pdf", "text": "Content"},
            ],
        }
        response = QueryResponse.from_dict(data)
        
        assert len(response.sources) == 1
        assert response.sources[0].name == "doc.pdf"
        assert response.sources[0].content == "Content"


class TestSource:
    """Tests for Source class."""
    
    def test_source_creation(self):
        """Test creating Source dataclass."""
        source = Source(name="test.pdf", content="Test content")
        assert source.name == "test.pdf"
        assert source.content == "Test content"
