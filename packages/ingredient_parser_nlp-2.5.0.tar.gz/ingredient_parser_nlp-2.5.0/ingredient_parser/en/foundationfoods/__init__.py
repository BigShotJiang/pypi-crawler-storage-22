#!/usr/bin/env python3

from ._foundationfoods import match_foundation_foods

__all__ = [
    "match_foundation_foods",
]
