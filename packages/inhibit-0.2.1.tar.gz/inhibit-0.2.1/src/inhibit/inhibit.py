#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Juha Heljoranta <juha.heljoranta@iki.fi>
# SPDX-License-Identifier: Apache-2.0
import argparse
import logging
import os
import signal
import sys
from importlib.metadata import PackageNotFoundError, version
from typing import TYPE_CHECKING, Any, NoReturn, TextIO, cast

if TYPE_CHECKING:
    from types import FrameType

# Try importing dbus, fail gracefully if missing
try:
    import dbus  # type: ignore [import-not-found]
except ImportError:
    sys.stderr.write("Error: 'dbus-python' module is required.\n")
    sys.exit(1)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    stream=sys.stderr,
)
logger = logging.getLogger("inhibit")

try:
    __version__ = version("inhibit")
except PackageNotFoundError:
    __version__ = "unknown"


class Inhibit:
    """Abstracts org.freedesktop.login1.Manager Inhibit."""

    def __init__(self) -> None:
        self.manager: Any = None

        try:
            bus = dbus.SystemBus()
            obj = bus.get_object(
                "org.freedesktop.login1",
                "/org/freedesktop/login1",
            )
            self.manager = dbus.Interface(obj, "org.freedesktop.login1.Manager")
            if self.manager is None:
                logger.critical("Cannot acquire inhibitor: manager is not initialized")
                sys.exit(1)
        except dbus.exceptions.DBusException as e:
            logger.critical(f"Failed to connect to logind: {e}")
            sys.exit(1)

    def take(self, what: str, who: str, why: str, mode: str) -> int:
        try:
            fd_wrapper = self.manager.Inhibit(what, who, why, mode)
            return cast("int", fd_wrapper.take())
        except dbus.exceptions.DBusException:
            logger.exception("Failed to acquire inhibitor via D-Bus")
            raise

    def close(self, fd: int) -> None:
        os.close(fd)


class SleepInhibitor:
    def __init__(  # noqa: PLR0913
        self,
        inhibit: Inhibit,
        what: str,
        who: str,
        why: str,
        mode: str,
        stdin: TextIO,
    ) -> None:
        self.what = what
        self.who = who
        self.why = why
        self.mode = mode
        self.inhibit = inhibit
        self.fd: int | None = None
        self.stdin = stdin

    def acquire(self) -> None:
        if self.fd is not None:
            return

        try:
            self.fd = self.inhibit.take(self.what, self.who, self.why, self.mode)
            logger.debug(f"Inhibitor ACQUIRED for '{self.what}' (fd={self.fd})")
        except Exception:
            logger.exception("Failed to acquire inhibitor")

    def release(self) -> None:
        if self.fd is None:
            return

        fd_to_close = self.fd
        self.fd = None

        try:
            self.inhibit.close(fd_to_close)
            logger.debug("Inhibitor RELEASED")
        except OSError:
            logger.exception(f"Error closing FD {fd_to_close}")


def parse_args(argv: list[str]) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Systemd Inhibitor: Reads ON/OFF from stdin "
        "to inhibit system shutdowns and sleep states.",
    )
    p.add_argument("--strict", action="store_true", help="Exit on malformed input")
    p.add_argument(
        "--what",
        default="sleep",
        choices=[
            "shutdown",
            "sleep",
            "idle",
            "handle-power-key",
            "handle-suspend-key",
            "handle-hibernate-key",
            "handle-lid-switch",
        ],
        help="Target: what operation to inhibit (default: sleep)",
    )
    p.add_argument(
        "--mode",
        default="block",
        choices=[
            "block",
            "delay",
            "block-weak",
        ],
        help="Mode: block or delay operation (default: block)",
    )
    p.add_argument("--who", default="stdin-inhibitor", help="Identifier string")
    p.add_argument("--why", default="External pipeline request", help="Reason string")
    p.add_argument("--verbose", action="store_true", help="Enable debug logging")
    p.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
        help="Print version and exit",
    )
    return p.parse_args(argv)


class Main:
    def __init__(self, argv: list[str], stdin: TextIO) -> None:
        self.stdin = stdin
        self.args: argparse.Namespace = parse_args(argv)

        if self.args.verbose:
            logger.setLevel(logging.DEBUG)

    def setup_input_buffering(self) -> None:
        """Force stdin to be line-buffered to handle pipe inputs immediately."""
        if hasattr(self.stdin, "reconfigure"):
            self.stdin.reconfigure(line_buffering=True)
        else:
            msg = "Cannot configure line-buffering"
            raise OSError(msg)

    def set_exit_handler(self) -> None:
        def exit_handler(signum: int, _frame: FrameType | None) -> NoReturn:
            sig_name = signal.Signals(signum).name
            logger.debug(f"Received signal {sig_name}, exiting...")
            sys.exit(0)

        signal.signal(signal.SIGINT, exit_handler)
        signal.signal(signal.SIGTERM, exit_handler)

    def init(self, inhibit: Inhibit | None) -> None:
        if inhibit is None:
            inhibit = Inhibit()
        self.inhibitor = SleepInhibitor(
            inhibit=inhibit,
            what=self.args.what,
            who=self.args.who,
            why=self.args.why,
            mode=self.args.mode,
            stdin=self.stdin,
        )

    def run(self) -> None:
        logger.debug("Ready. Waiting for input (ON/OFF)...")

        try:
            self._read_stdin()
        except BrokenPipeError:
            logger.debug("Input pipe closed (BrokenPipe).")
        except KeyboardInterrupt:
            logger.debug("Interrupted by user.")
        except Exception:
            logger.exception("Unexpected error in main loop")
        finally:
            self.inhibitor.release()

    def _read_stdin(self) -> None:
        for line in self.stdin:
            command = line.strip().upper()

            if not command:
                continue

            if command == "ON":
                self.inhibitor.acquire()
            elif command == "OFF":
                self.inhibitor.release()
            else:
                msg = f"Unknown command: {command!r}"
                if self.args.strict:
                    logger.error(msg)
                    sys.exit(1)
                else:
                    logger.warning(msg)


def main(argv: list[str] = sys.argv[1:], stdin: TextIO = sys.stdin) -> None:
    main = Main(argv, stdin)
    main.setup_input_buffering()
    main.init(None)
    main.set_exit_handler()
    main.run()


if __name__ == "__main__":
    main()
