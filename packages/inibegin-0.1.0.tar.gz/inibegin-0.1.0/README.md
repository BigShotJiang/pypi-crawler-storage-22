# inibegin

INI file parser for beginners written in Python.

## Why it's for beginners?

Because it's **very** simple. For example, here is an example of getting a parameter from an INI file:

```python
import inibegin

# Setting an INI file for reading
inibegin.SetINIFile("example.ini") 

# 'Section' is the section name, 'example' is the parameter name.
example = inibegin.GetParameter("Section", "example") 

print(example) # Prints: true
```

**Note:** You need a INI file with name "example.ini" with such entries:
[Section]

example = true

And that's not all the library can do! Link to documentation: https://mistertay0dimon.github.io/inibegin-documentation/