# Initalization file for inibegin
from .inibegin import SetINIFile, GetParameter, ChangeParameterValue, AddParameter, DeleteParameter, INIParseError