"""
inibegin - INI file parser for beginners written in Python.
This module contains all function of inibegin (SetINIFile, GetParameter, ChangeParameterValue)...
"""

import os

class INIParseError(Exception):
    """
    INIParseError custom error.
    Needed for errors “Section or parameter doesn't exist.”
    """
    pass

CurrentINIFile = None # A variable that stores the name of the current INI file.

def SetINIFile(filename: str) -> None:
    """
    Function for setting a current INI file.
    
    :param filename: INI file name.
    """
    global CurrentINIFile
    # We use abspath to fix the path relative to the launch location.
    CurrentINIFile = os.path.abspath(os.path.expanduser(filename))

def GetParameter(section: str, parameter: str) -> str:
    """
    Function for getting a parameter from the section in current INI file.\n
    Throws INIParseError if:\n
    Section doesnt exist.\n
    Or:\n
    Parameter in section doesnt exist.\n
    Returns a value of the parameter.

    :param section: Section where the parameter.
    :param parameter: Parameter needed to get
    """
    global CurrentINIFile
    
    # Check if the file path was initialized
    if CurrentINIFile is None:
        raise INIParseError("CurrentINIFile is None. Call SetINIFile first.")

    # Check if the file actually exists on the disk
    if not os.path.exists(CurrentINIFile):
        raise INIParseError(f"INI file '{CurrentINIFile}' does not exist.")

    target_section = f"[{section}]".lower()
    in_correct_section = False
    section_found = False # Track if the section exists anywhere in the file

    # Open the file for reading
    with open(CurrentINIFile, 'r', encoding='utf-8') as f:
        for line in f:
            # Remove leading/trailing whitespace
            line = line.strip()
            
            # Skip empty lines and comments
            if not line or line.startswith(';') or line.startswith('#'):
                continue
            
            # Check if the line is a section header
            if line.startswith('[') and line.endswith(']'):
                if line.lower() == target_section:
                    in_correct_section = True
                    section_found = True
                else:
                    # If we hit a different section, stop looking for parameters
                    in_correct_section = False
                continue
            
            # If we are inside the requested section, look for the key
            if in_correct_section:
                if '=' in line:
                    # Split by the first '=' found
                    key, value = line.split('=', 1)
                    if key.strip().lower() == parameter.lower():
                        return value.strip()

    if not section_found:
        raise INIParseError(f"Section [{section}] doesn't exist.")
    else:
        raise INIParseError(f"Parameter '{parameter}' doesn't exist in section [{section}].")

def ChangeParameterValue(section: str, parameter: str, new_value: str) -> None:
    """
    Changes the value of an existing parameter.
    Throws INIParseError if section or parameter doesn't exist.

    :param section: Section where the parameter.
    :param parameter: Parameter to change value.
    :param new_value: New value of the parameter.
    """
    global CurrentINIFile
    
    if CurrentINIFile is None:
        raise INIParseError("CurrentINIFile is None. Call SetINIFile first.")

    if not os.path.exists(CurrentINIFile):
        raise INIParseError(f"INI file '{CurrentINIFile}' does not exist.")

    target_section = f"[{section}]".lower()
    target_parameter = parameter.lower()
    
    # Read all lines into memory to modify them
    with open(CurrentINIFile, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    updated = False
    in_correct_section = False
    section_found = False

    for i, line in enumerate(lines):
        clean_line = line.strip()
        
        # Section detection
        if clean_line.startswith('[') and clean_line.endswith(']'):
            if clean_line.lower() == target_section:
                in_correct_section = True
                section_found = True
            else:
                in_correct_section = False
            continue

        # Parameter detection and modification within the correct section
        if in_correct_section and '=' in clean_line:
            key = clean_line.split('=', 1)[0].strip().lower()
            if key == target_parameter:
                # Replace the line while maintaining simple formatting
                lines[i] = f"{parameter} = {new_value}\n"
                updated = True
                break 

    # Error handling as requested
    if not section_found:
        raise INIParseError(f"Section [{section}] doesn't exist.")
    if not updated:
        raise INIParseError(f"Parameter '{parameter}' doesn't exist in section [{section}].")

    # Write the modified lines back to the file
    with open(CurrentINIFile, 'w', encoding='utf-8') as f:
        f.writelines(lines)

def AddParameter(section: str, parameter: str, value: str) -> None:
    """
    Adds a new parameter to the specified section.\n
    If the section doesn't exist, it will be created at the end of the file.\n
    If the parameter already exists, it will not be duplicated.

    :param section: Section where to add the parameter.
    :param parameter: New parameter name.
    :param value: Value of the new parameter.
    """
    global CurrentINIFile
    if CurrentINIFile is None:
        raise INIParseError("CurrentINIFile is None. Call SetINIFile first.")

    # We can use our GetParameter to check if it exists (but that might raise Error)
    # Better to read lines and find the spot
    if not os.path.exists(CurrentINIFile):
        # If file doesn't exist, we create it
        with open(CurrentINIFile, 'w', encoding='utf-8') as f:
            f.write(f"[{section}]\n{parameter} = {value}\n")
        return

    with open(CurrentINIFile, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    target_section = f"[{section}]".lower()
    section_index = -1
    next_section_index = -1
    parameter_exists = False

    for i, line in enumerate(lines):
        clean_line = line.strip()
        if clean_line.lower() == target_section:
            section_index = i
            continue
        
        if section_index != -1:
            if clean_line.startswith('[') and clean_line.endswith(']'):
                next_section_index = i
                break
            if '=' in clean_line:
                key = clean_line.split('=', 1)[0].strip().lower()
                if key == parameter.lower():
                    parameter_exists = True
                    break

    if parameter_exists:
        return # Or you can call ChangeParameterValue here if you want to update it

    new_line = f"{parameter} = {value}\n"
    if section_index != -1:
        # Section exists, insert before next section or at the end
        if next_section_index != -1:
            lines.insert(next_section_index, new_line)
        else:
            if not lines[-1].endswith('\n'):
                lines[-1] += '\n'
            lines.append(new_line)
    else:
        # Create new section at the end
        if lines and not lines[-1].endswith('\n'):
            lines.append('\n')
        lines.append(f"\n[{section}]\n")
        lines.append(new_line)

    with open(CurrentINIFile, 'w', encoding='utf-8') as f:
        f.writelines(lines)

def DeleteParameter(section: str, parameter: str) -> None:
    """
    Deletes a parameter from the specified section.\n
    Throws INIParseError if section or parameter doesn't exist.

    :param section: Section where the parameter is located.
    :param parameter: Parameter name to delete.
    """
    global CurrentINIFile
    if CurrentINIFile is None:
        raise INIParseError("CurrentINIFile is None. Call SetINIFile first.")

    if not os.path.exists(CurrentINIFile):
        raise INIParseError(f"INI file '{CurrentINIFile}' does not exist.")

    with open(CurrentINIFile, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    target_section = f"[{section}]".lower()
    target_param = parameter.lower()
    
    new_lines = []
    in_correct_section = False
    found = False
    section_found = False

    for line in lines:
        clean_line = line.strip()
        if clean_line.startswith('[') and clean_line.endswith(']'):
            if clean_line.lower() == target_section:
                in_correct_section = True
                section_found = True
            else:
                in_correct_section = False
        
        delete_this_line = False
        if in_correct_section and '=' in clean_line:
            key = clean_line.split('=', 1)[0].strip().lower()
            if key == target_param:
                found = True
                delete_this_line = True
        
        if not delete_this_line:
            new_lines.append(line)

    if not section_found:
        raise INIParseError(f"Section [{section}] doesn't exist.")
    if not found:
        raise INIParseError(f"Parameter '{parameter}' doesn't exist in section [{section}].")

    with open(CurrentINIFile, 'w', encoding='utf-8') as f:
        f.writelines(new_lines)
