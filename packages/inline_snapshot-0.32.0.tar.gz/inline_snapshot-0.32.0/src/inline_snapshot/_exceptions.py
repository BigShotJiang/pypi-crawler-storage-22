class UsageError(Exception):
    pass
