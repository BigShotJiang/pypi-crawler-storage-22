"""Tests for the pricing module."""
