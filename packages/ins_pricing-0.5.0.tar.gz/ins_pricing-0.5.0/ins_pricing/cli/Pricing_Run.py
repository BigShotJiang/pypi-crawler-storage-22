from __future__ import annotations

from pathlib import Path
from typing import Optional
import importlib.util
import sys

if __package__ in {None, ""}:
    if importlib.util.find_spec("ins_pricing") is None:
        repo_root = Path(__file__).resolve().parents[2]
        if str(repo_root) not in sys.path:
            sys.path.insert(0, str(repo_root))

try:
    from ins_pricing.cli.utils.notebook_utils import run_from_config, run_from_config_cli  # type: ignore
except Exception:  # pragma: no cover
    from utils.notebook_utils import run_from_config, run_from_config_cli  # type: ignore


def run(config_json: str | Path) -> None:
    """Unified entry point: run entry/incremental/watchdog/DDP based on config.json runner."""
    run_from_config(config_json)


def main(argv: Optional[list[str]] = None) -> None:
    run_from_config_cli(
        "Pricing_Run: run BayesOpt by config.json (entry/incremental/watchdog/DDP).",
        argv,
    )


if __name__ == "__main__":
    main()
