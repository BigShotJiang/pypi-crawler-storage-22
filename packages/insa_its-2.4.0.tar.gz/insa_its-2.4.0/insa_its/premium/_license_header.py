# Copyright (c) 2024-2026 YuyAI / InsAIts Team. All rights reserved.
# Proprietary and confidential. See LICENSE.premium for terms.
"""
InsAIts Premium Features License
=================================
Copyright (c) 2024-2026 YuyAI / InsAIts Team
All rights reserved.

This code is proprietary and confidential.
Unauthorized copying, modification, distribution, or use is strictly prohibited.
This module is included only in the official pip package: pip install insa-its

For licensing inquiries: info@yuyai.pro
"""

LICENSE_TYPE = "proprietary"
LICENSE_HOLDER = "YuyAI / InsAIts Team"
