# __init__.py
__version__ = '1.0.0'
__author__ = 'Meng Li'

import insitu_alignment as AL
import insitu_DP as DP
import insitu_IO as IO
import insitu_Preprocess as PP
import insitu_Diff as Diff
import insitu_EMraw as EM
import insitu_DENS as DENS


__all__ = ['function1', 'Class2']
