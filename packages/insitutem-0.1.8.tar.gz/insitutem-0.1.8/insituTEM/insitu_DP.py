# -*- coding: utf-8 -*-
"""
in-situ TEM Toolbox - Data process 

Assembles of functions related to movie input output

Example:
    
    import insitu_DP as DP
    IO.f2tif(path,1)

Created on Tue Jun 11 10:25:25 2019
@author: Meng Li
"""
import numpy as np

def readcsvCol(path,col):
    """
    Function to read csv rol into array 
    Inputs: file path; col number
    Output: 1D np array
        
    Example: 
        x = readcsvCol(path,1)
    """
    import csv
    x=[]
    with open(path,'r') as csvfile:
        plots = csv.reader(csvfile, delimiter=',')
        for row in plots:
            if row[col]=='':
                x.append(np.nan)
            else:
                x.append(float(row[col]))
#        plt.plot(x,y) #to check if  the read  result is correct
    return x
def readcsv(path,col_list):
    """
    Function to read csv rol into array 
    Inputs: file path; col number list
    Output: 1D np array
        
    Example: 
        x = readcsv(path,[0:3])
    """
#    w= len(col_list)
    x=readcsvCol(path,col_list[0])
#    l = len(x)
    D=np.zeros((len(x),len(col_list)))
    i=0
    for col in col_list:
        
        x=readcsvCol(path,col)
        D[:,i]=x
        i=i+1
#        D = [D, x]
    return D

    
# def writeCSV(pathout,data):
# #    import csv
#     import numpy as np
# #    (length,width)=np.shape(data)
# #    np.savetxt(pathout, data, fmt='%1.4d', delimiter=",") 
#     np.savetxt(pathout, data, fmt='%.4f', delimiter=",")   
    
def plot2ani(x,y,outpath,label,w=800,h=600,fps=10,dpi=72,tl_size=20,c='r'):
    """
    Function to make plot into animation 
    Inputs: 
        data: x y; 
        Movie setting: size: w,h ;
                       fps; savepath
                       label: ['xlabel','ylabel'] str array
                       tl_size: title font size
                       c: color of the plot line
                       dpi: dpi for screen : 72 for 4k screen, 96 for 1080p screen
    Output: mp4 movie
        
    Example: 
        plot2ani(x,y,w,h,fps,outpath,dpi,tl_size,'r')

    """
    
    import matplotlib.pyplot as plt
    import matplotlib.animation as animation
    interV=1000/fps #time interval for each frame: ms
#    w_in=w/dpi
#    h_in=h/dpi
    fig, ax = plt.subplots(figsize=(w/dpi, h/dpi))#figsize unit: inch
    plt.rcParams.update({'font.size': tl_size})
    plt.xlabel(label[0])#Change xy label if needed
    plt.ylabel(label[1])
    l=plt.plot(x,y,'grey') #For inital plot
    redLine, = plt.plot(x[:0],y[:0],color=c, lw=3)
    time_text = ax.text(5,7,str(y[0])+'°',fontsize=20)
#    plt.text(5, 7, str(y[0],fontsize=20))
    def animate(i):
        redLine.set_data(x[:i], y[:i])
#        plt.text(5, 7, str(y[i])+'°',fontsize=20) # Text is overlapping with previous frames
        time_text.set_text(str(round(y[i],1))+'°') 
#        print(str(i)/len(x))
        return tuple([redLine,]) + tuple([time_text])
    
    plt.tight_layout() #To avoid boarder
    # create animation using the animate() function
    ani = animation.FuncAnimation(fig, animate, frames=len(x), \
                                      interval=interV, blit=True, repeat=True)
    ani.save(outpath)
    plt.show()
    
def getintensity(x,y,disk,img):
    """
    Function to get intensity of a disk region at point (x,y) 
    Inputs:
        x,y: coordinates of the detection point
        disk: size of pixels for detection region
        img: 2D grayscale image
    """
    x_l=int(x-disk)
    x_r=int(x+disk)
    y_l=int(y-disk)
    y_r=int(y+disk)
    intensity=int(np.mean(img[y_l:y_r,x_l:x_r]))
    return intensity
    

def findconnectingpoints(points,startpoint,r,level):
    """
    FUnction for find all surrounding points within distance r betwwen each other from startpoint
    return: index of all connected points
    """
    from scipy import spatial
    tree = spatial.cKDTree(points, leafsize=30)
    idx =tree.query_ball_point(startpoint,r)
    i=0
    while i<level:
        for results in idx:
            nearby_point = points[results]
            idx2=tree.query_ball_point(nearby_point ,r)
            idx=list(set(idx)|set(idx2))                
        idx=list(set(idx)|set(idx2))
        i=i+1
    print(idx)
    return idx    



#Automatic find ROI bg color from 
def AutoROIbg(img):
    """
    Function to find ROI color from BW image:
        if ROI is 255, then the bg is 0
    """
    bg=int(np.mean(img))
    if bg<128:
        ROI =255
    else:
        ROI = 0
    return ROI
            
def readscale(path):
    """
    Function to measure scalebar from movie first frame
    Input: path - movie path
    scalebarcolr- 0 for black, 255 for white
    """
    import os
    os.environ["IMAGEIO_FFMPEG_EXE"] = "/opt/homebrew/bin/ffmpeg"
    import moviepy.editor as mp
    import cv2
    
    video = mp.VideoFileClip(path)
    fr = video.get_frame(mp.cvsecs(0))
    fr = cv2.cvtColor(fr, cv2.COLOR_BGR2GRAY)

    # Select ROI using cv2.selectROI()
    roi = cv2.selectROI('Select scalebar ROI, quit with SPACE', fr)
    cv2.waitKey(10)
    # cv2.destroyAllWindows()
    cv2.destroyWindow('Select scalebar ROI, quit with SPACE')

    # print(roi)
    # Crop the image based on the selected ROI
    cropped_image = fr[int(roi[1]):int(roi[1] + roi[3]), int(roi[0]):int(roi[0] + roi[2])]

    # # # Display the cropped image
    # from PIL import Image
    # from IPython.display import display
    # pil_image= Image.fromarray(cropped_image)
    # display(pil_image)

    # plt.imshow(cropped_image)

    IO.showFr(cropped_image)
    #calculate the number of pixels in scalebar
    # print(cropped_image[-5,:])
    import numpy as np

    scalebar_color = int(input("Input the scalebar color,  0-black, 255-white: "))


    scalebar_px =  np.count_nonzero(cropped_image[-10,:]==scalebar_color)

    print("scalebar_px=", scalebar_px)

    scale_nm = int(input("Input the scalebar in nm: "))
    scale =scalebar_px/scale_nm
    print("scale=",scale,"px/nm")
    return scale

def next_power_of_2(x):
    return 1 if x == 0 else 2**(x - 1).bit_length()

def pad_to_nearest_power_of_2(image):
    import cv2
    # Get original dimensions
    h, w = image.shape
    size=max(h,w)

    # Calculate the nearest power of 2 dimensions
    new_size = next_power_of_2(size)

    # Calculate padding amounts
    top_pad = (new_size - h) // 2
    bottom_pad = new_size - h - top_pad
    left_pad = (new_size - w) // 2
    right_pad = new_size - w - left_pad

    # Apply padding
    padded_image = cv2.copyMakeBorder(
        image,
        top=top_pad, bottom=bottom_pad,
        left=left_pad, right=right_pad,
        borderType=cv2.BORDER_CONSTANT,
        value=0  # Black color
    )

    return padded_image

def getFFT(im):
    """
    Function to get FFT from grayscale image, auto pad the image to keep the image size  2^n
    Input: grayscale image (np array)
    Output: grayscale FFT with 2^n size, 32 bit
    """

    pad_im=pad_to_nearest_power_of_2(im)


    fft_image = np.fft.fft2(pad_im)
    fft_shifted = np.fft.fftshift(fft_image)
    fft = 20 * np.log(np.abs(fft_shifted))
    return fft

def FFTstack(path):
    """
    Function to get FFT of the stack
    input: path of the image stack
    output: FFT stack with 2^n size 8 bit images
    """
    import tifffile
    import tqdm
    import cv2

    stack = tifffile.imread(path)
    nFrames,h,w = stack.shape #make sure the order of h and w!
    pathout=path[:-4]+'_FFT.tif'

    print("------------------------------------------")
    print('Calculating FFT of each frame')
    with tifffile.TiffWriter(pathout,bigtiff=True) as tif:
        for i in tqdm.tqdm(range(nFrames)):
            fr=stack[i]
            fft=getFFT(fr)
            #convert the 32 bit image to 8 bit
            normalized_image = cv2.normalize(fft, None, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX)
            # Convert the normalized image to 8-bit
            fft_8bit = np.uint8(normalized_image)
            tif.write(fft_8bit, contiguous=True)

def FFT2Polar(fft):
    """
    Function to convert FFT to polar image, y= 180˚, x= Rho
    Input: grayscale fft image (np array)
    """
    import cv2
    #function to convert fft image to polar coordinates from the center from 0-180 deg
    center = (fft.shape[1] // 2, fft.shape[0] // 2)
    polar_fft = cv2.linearPolar(fft, center, center[0], cv2.WARP_FILL_OUTLIERS)
    # polar_fft= polar_fft[:,:center[1]]
    #resize the image to realistic size
    resized_polar_fft = cv2.resize(polar_fft, (center[0], 360))
        # plt.imshow(resized_polar_fft)
    
    p_fft1=resized_polar_fft[:180,:]
    p_fft2=resized_polar_fft[180:,:]
    p_fft=p_fft1+p_fft2
    return p_fft

def FFTidentify(fft,pathout,scale=1,sigmaMax=2.5,sigmaMin=2.4,thrs=0.96,sigma_ratio=10):
    """
    Function to identify DPs from FFT 
    input: 
        fft: image
        scale: scale of the original image : 1 px  = XXX nm
        parameters for blobs detection: sigmaMax, sigmaMin, thrs, sigma_ratio
        pathout: path for output image (.tif) and csv

    output:
        idnetified image
        indexed csv



    """
    import math
    import matplotlib.pyplot as plt
    from scipy import ndimage
    from skimage.feature import blob_dog, blob_log, blob_doh
    from math import sqrt
    from insituTEM import insitu_IO as IO
    
    h,w = fft.shape
    x_c=int(w/2)
    y_c=int(h/2)
    r=int(x_c/2)   
    if w>320:
        fft_crop=fft[x_c-r:x_c+r,y_c-r:y_c+r]
        image= ndimage.maximum_filter(fft_crop, size=2, mode='wrap')
    else:
        fft_crop = fft
        image= ndimage.maximum_filter(fft_crop, size=3, mode='wrap')




    blobs_dog = blob_dog(image, max_sigma=sigmaMax,min_sigma=sigmaMin, threshold=thrs,sigma_ratio=sigma_ratio,exclude_border=True)
    blobs_dog[:, 2] = blobs_dog[:, 2] * sqrt(2)

    title = 'DP detection'

    fig, axes = plt.subplots(1, 2, figsize=(10, 5), sharex=True, sharey=True)
    ax = axes.ravel()

    ax[0].set_title('FFT_')
    ax[0].imshow(fft_crop)
    # ax[0].set_axis_off()
    ax[1].set_title(title)
    ax[1].imshow(image)


    plt.tight_layout()
    
   
    data=np.zeros((len(blobs_dog),6))
    data[:,0]=blobs_dog[:,1]
    data[:,1]=blobs_dog[:,0]

    for j in range(len(blobs_dog)):
        y=data[j,1]-r
        x=data[j,0]-r

        data[j,2]=math.sqrt(x**2+y**2)
        # if data[j,2] < 10:
        #     data[j,2]=0
        #     theta = 0
        # else:
        #     theta=math.atan(y/x)
        theta=math.atan(y/x)
        data[j,3]=math.degrees(theta)

    data[:,4]=data[:,2]*scale
    data[:,5]=1/data[:,4]

    plt.scatter(data[:,0],data[:,1],marker='+',color='red')
    for i, (x_i, y_i) in enumerate(zip(data[:,0],data[:,1])):
        plt.annotate(str(i+1), (x_i, y_i), textcoords="offset points", xytext=(0,10), ha='center',color='white')
    pathoutcsv=pathout[:-4]+'.csv'
    IO.writeCSV(pathoutcsv,data,fmt='%1.3f')
    plt.savefig(pathout)