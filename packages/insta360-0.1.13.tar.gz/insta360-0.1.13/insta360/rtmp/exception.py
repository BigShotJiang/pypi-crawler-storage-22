class CommandFailedException(Exception):
    pass


class CameraNotConnectedException(Exception):
    def __init__(self, message=None):  # pragma: no cover
        message = message or "This device is not connected to the camera Wi-Fi"
        super().__init__(message)
