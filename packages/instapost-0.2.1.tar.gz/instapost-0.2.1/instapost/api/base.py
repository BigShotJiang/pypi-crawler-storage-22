import logging
import requests
import time
from abc import ABC, abstractmethod

from ..exceptions import ContainerProcessingError, ContainerTimeoutError

logger = logging.getLogger(__name__)


class BaseInstagramClient(ABC):
    """Base class for Instagram API clients."""

    BASE_URL = "https://graph.instagram.com"

    def __init__(self, access_token: str, ig_user_id: str):
        self.access_token = access_token
        self.ig_user_id = ig_user_id

    def _request(self, method: str, endpoint: str, **kwargs) -> dict:
        """Make a request to the Graph API."""
        url = f"{self.BASE_URL}/{endpoint}"
        kwargs.setdefault("params", {})["access_token"] = self.access_token
        logger.debug(f"Making {method} request to {endpoint}")
        response = requests.request(method, url, **kwargs)
        response.raise_for_status()
        logger.debug(f"{method} request to {endpoint} successful")
        return response.json()

    def _create_container(self, params: dict) -> str:
        """Create a media container and return its ID."""
        logger.info(f"Creating media container with params: {params}")
        result = self._request("POST", "me/media", params=params)
        container_id = result["id"]
        logger.info(f"Media container created with ID: {container_id}")
        return container_id

    def _publish_container(self, container_id: str) -> dict:
        """Publish a media container."""
        logger.info(f"Publishing media container {container_id}")
        result = self._request(
            "POST",
            "me/media_publish",
            params={"creation_id": container_id},
        )
        logger.info(f"Media container {container_id} published successfully")
        return result

    def _wait_for_container(self, container_id: str, timeout: int = 60, interval: int = 5) -> None:
        """Wait for a media container to finish processing."""
        logger.info(f"Waiting for container {container_id} to finish processing (timeout: {timeout}s)")
        elapsed = 0
        while elapsed < timeout:
            result = self._request("GET", container_id, params={"fields": "status_code,status"})
            status = result.get("status_code")
            logger.debug(f"Container {container_id} status: {status}")

            if status == "FINISHED":
                logger.info(f"Container {container_id} finished processing")
                return
            if status == "ERROR":
                error_msg = f"Container processing failed: {result.get('status')}"
                logger.error(error_msg)
                raise ContainerProcessingError(error_msg)

            time.sleep(interval)
            elapsed += interval

        error_msg = f"Container {container_id} did not finish processing in {timeout}s"
        logger.error(error_msg)
        raise ContainerTimeoutError(error_msg)

    def verify(self) -> dict:
        """Verify credentials and return account info."""
        logger.info("Verifying Instagram credentials")
        result = self._request(
            "GET",
            "me",
            params={"fields": "id,username,name"},
        )
        logger.info(f"Credentials verified for user: {result.get('username')}")
        return result

    def publish(self, container_id: str) -> dict:
        """
        Publish a previously uploaded media container.

        Args:
            container_id: The container ID returned by upload().

        Returns:
            API response with the published media ID.
        """
        logger.info(f"Publishing container {container_id}")
        return self._publish_container(container_id)

    @abstractmethod
    def upload(self, *args, **kwargs) -> str:
        """Upload content and return the container ID."""
        pass

    def post(self, *args, **kwargs) -> dict:
        """Upload and publish content in one step."""
        container_id = self.upload(*args, **kwargs)
        return self.publish(container_id)
