import requests
import time
import json
import base64
from typing import Optional, Dict, Any, Generator, Callable, List
from .exceptions import (
    InstaVMError, AuthenticationError, SessionError, ExecutionError,
    NetworkError, RateLimitError, BrowserError, BrowserSessionError,
    BrowserInteractionError, BrowserTimeoutError, BrowserNavigationError,
    ElementNotFoundError, QuotaExceededError, UnsupportedOperationError
)
class BrowserSession:
    """Represents a browser session for automation"""

    def __init__(self, session_id: str, client: 'InstaVM'):
        self.session_id = session_id
        self.client = client
        self._active = True

    def navigate(self, url: str, wait_timeout: int = 30000) -> Dict[str, Any]:
        """Navigate to a URL"""
        return self.client.browser_navigate(url, self.session_id, wait_timeout)

    def click(self, selector: str, force: bool = False, timeout: int = 30000) -> Dict[str, Any]:
        """Click an element"""
        return self.client.browser_click(selector, self.session_id, force, timeout)

    def type(self, selector: str, text: str, delay: int = 100, timeout: int = 30000) -> Dict[str, Any]:
        """Type text into an element"""
        return self.client.browser_type(selector, text, self.session_id, delay, timeout)

    def fill(self, selector: str, value: str, timeout: int = 30000) -> Dict[str, Any]:
        """Fill a form field"""
        return self.client.browser_fill(selector, value, self.session_id, timeout)

    def scroll(self, selector: str = None, x: int = None, y: int = None) -> Dict[str, Any]:
        """Scroll the page or an element. If a selector is provided, scrolls the element into view. If x and y coordinates are provided, scrolls the page to those absolute coordinates."""
        return self.client.browser_scroll(self.session_id, selector, x, y)

    def wait_for(self, condition: str, selector: str = None, timeout: int = 30000) -> Dict[str, Any]:
        """Wait for a condition"""
        return self.client.browser_wait(condition, self.session_id, selector, timeout)

    def screenshot(self, full_page: bool = True, clip: Dict = None, format: str = "png", quality: int = None) -> str:
        """Take a screenshot (returns base64 string)"""
        return self.client.browser_screenshot(self.session_id, full_page, clip, format, quality)

    def extract_elements(self, selector: str = None, attributes: List[str] = None) -> List[Dict[str, Any]]:
        """Extract DOM elements"""
        return self.client.browser_extract_elements(self.session_id, selector, attributes)

    def extract_content(self, url: str = None, include_interactive: bool = True,
                       include_anchors: bool = True, max_anchors: int = 50) -> Dict[str, Any]:
        """Extract LLM-friendly content with clean text, interactive elements, and anchors"""
        return self.client.browser_extract_content(self.session_id, url, include_interactive,
                                                   include_anchors, max_anchors)

    def close(self) -> bool:
        """Close this browser session"""
        if self._active:
            result = self.client.close_browser_session(self.session_id)
            self._active = False
            return result
        return True

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


class BrowserManager:
    """Manager for browser automation functionality"""

    def __init__(self, client: 'InstaVM'):
        self.client = client
        self._default_session_id = None

    def create_session(self, viewport_width: int = 1920, viewport_height: int = 1080,
                      user_agent: str = None) -> BrowserSession:
        """Create a new browser session"""
        session_id = self.client.create_browser_session(viewport_width, viewport_height, user_agent)
        return BrowserSession(session_id, self.client)

    def _ensure_default_session(self) -> str:
        """Ensure a default browser session exists"""
        if not self._default_session_id:
            session = self.create_session()
            self._default_session_id = session.session_id
        return self._default_session_id

    def navigate(self, url: str, session_id: str = None, wait_timeout: int = 30000) -> Dict[str, Any]:
        """Navigate to URL (auto-creates session if none provided)"""
        if not session_id:
            session_id = self._ensure_default_session()
        return self.client.browser_navigate(url, session_id, wait_timeout)

    def click(self, selector: str, session_id: str = None, force: bool = False, timeout: int = 30000) -> Dict[str, Any]:
        """Click element by CSS selector"""
        if not session_id:
            session_id = self._ensure_default_session()
        return self.client.browser_click(selector, session_id, force, timeout)

    def type(self, selector: str, text: str, session_id: str = None, delay: int = 100, timeout: int = 30000) -> Dict[str, Any]:
        """Type text into element"""
        if not session_id:
            session_id = self._ensure_default_session()
        return self.client.browser_type(selector, text, session_id, delay, timeout)

    def fill(self, selector: str, value: str, session_id: str = None, timeout: int = 30000) -> Dict[str, Any]:
        """Fill form field"""
        if not session_id:
            session_id = self._ensure_default_session()
        return self.client.browser_fill(selector, value, session_id, timeout)

    def wait_for(self, condition: str, selector: str = None, session_id: str = None, timeout: int = 30000) -> Dict[str, Any]:
        """Wait for condition"""
        if not session_id:
            session_id = self._ensure_default_session()
        return self.client.browser_wait(condition, session_id, selector, timeout)

    def screenshot(self, session_id: str = None, full_page: bool = True, clip: Dict = None,
                  format: str = "png", quality: int = None) -> str:
        """Take screenshot (returns base64)"""
        if not session_id:
            session_id = self._ensure_default_session()
        return self.client.browser_screenshot(session_id, full_page, clip, format, quality)

    def extract_elements(self, selector: str = None, session_id: str = None, attributes: List[str] = None) -> List[Dict]:
        """Extract DOM elements"""
        if not session_id:
            session_id = self._ensure_default_session()
        return self.client.browser_extract_elements(session_id, selector, attributes)

    def extract_content(self, session_id: str = None, url: str = None,
                       include_interactive: bool = True, include_anchors: bool = True,
                       max_anchors: int = 50) -> Dict[str, Any]:
        """Extract LLM-friendly content (auto-creates session if none provided in cloud mode)"""
        if not self.client.local and not session_id:
            session_id = self._ensure_default_session()
        return self.client.browser_extract_content(session_id, url, include_interactive,
                                                   include_anchors, max_anchors)

    def close(self):
        """Closes the default browser session, if one was created."""
        if self._default_session_id:
            self.client.close_browser_session(self._default_session_id)
            self._default_session_id = None


class VMManager:
    """Manager for VM lifecycle APIs."""

    def __init__(self, client: 'InstaVM'):
        self.client = client

    def list(self) -> List[Dict[str, Any]]:
        return self.client.list_vms()

    def create(
        self,
        *,
        wait: bool = True,
        session_id: Optional[str] = None,
        vm_lifetime_seconds: Optional[int] = None,
        memory_mb: Optional[int] = None,
        vcpu_count: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None,
        egress_policy: Optional[Dict[str, Any]] = None,
        snapshot_id: Optional[str] = None,
        snapshot_on_terminate: Optional[bool] = None,
        snapshot_name: Optional[str] = None,
        share: Optional[Dict[str, Any]] = None,
        custom_domain: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        return self.client.create_vm(
            wait=wait,
            session_id=session_id,
            vm_lifetime_seconds=vm_lifetime_seconds,
            memory_mb=memory_mb,
            vcpu_count=vcpu_count,
            metadata=metadata,
            egress_policy=egress_policy,
            snapshot_id=snapshot_id,
            snapshot_on_terminate=snapshot_on_terminate,
            snapshot_name=snapshot_name,
            share=share,
            custom_domain=custom_domain,
        )

    def update(
        self,
        vm_id: str,
        *,
        memory_mb: Optional[int] = None,
        egress_policy: Optional[Dict[str, Any]] = None,
        snapshot_on_terminate: Optional[bool] = None,
        snapshot_name: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        return self.client.update_vm(
            vm_id,
            memory_mb=memory_mb,
            egress_policy=egress_policy,
            snapshot_on_terminate=snapshot_on_terminate,
            snapshot_name=snapshot_name,
        )

    def delete(self, vm_id: str) -> bool:
        return self.client.delete_vm(vm_id)

    def clone(
        self,
        vm_id: str,
        *,
        wait: bool = True,
        snapshot_name: Optional[str] = None,
    ) -> Dict[str, Any]:
        return self.client.clone_vm(
            vm_id,
            wait=wait,
            snapshot_name=snapshot_name,
        )

    def snapshot(
        self,
        vm_id: str,
        *,
        wait: bool = True,
        name: Optional[str] = None,
    ) -> Dict[str, Any]:
        return self.client.snapshot_vm(vm_id, wait=wait, name=name)


class SnapshotManager:
    """Manager for snapshot APIs."""

    def __init__(self, client: 'InstaVM'):
        self.client = client

    def list(self, snapshot_type: Optional[str] = None) -> List[Dict[str, Any]]:
        return self.client.list_snapshots(snapshot_type=snapshot_type)

    def create(
        self,
        *,
        oci_image: str,
        name: Optional[str] = None,
        vcpu_count: int = 2,
        memory_mb: int = 512,
        build_args: Optional[Dict[str, Any]] = None,
        snapshot_type: str = "user",
    ) -> Dict[str, Any]:
        return self.client.create_snapshot(
            oci_image=oci_image,
            name=name,
            vcpu_count=vcpu_count,
            memory_mb=memory_mb,
            build_args=build_args,
            snapshot_type=snapshot_type,
        )

    def get(self, snapshot_id: str) -> Dict[str, Any]:
        return self.client.get_snapshot(snapshot_id)

    def delete(self, snapshot_id: str) -> bool:
        return self.client.delete_snapshot(snapshot_id)


class ShareManager:
    """Manager for share APIs."""

    def __init__(self, client: 'InstaVM'):
        self.client = client

    def create(
        self,
        *,
        port: int,
        session_id: Optional[str] = None,
        vm_id: Optional[str] = None,
        is_public: bool = False,
    ) -> Optional[Dict[str, Any]]:
        return self.client.create_share(
            port=port,
            session_id=session_id,
            vm_id=vm_id,
            is_public=is_public,
        )

    def update(
        self,
        share_id: str,
        *,
        is_public: Optional[bool] = None,
        revoke: Optional[bool] = None,
    ) -> Optional[Dict[str, Any]]:
        return self.client.update_share(
            share_id,
            is_public=is_public,
            revoke=revoke,
        )


class SSHKeyManager:
    """Manager for SSH key APIs."""

    def __init__(self, client: 'InstaVM'):
        self.client = client

    def add_key(self, public_key: str) -> dict:
        """Add an SSH public key. Returns the key record with fingerprint."""
        return self.client.add_ssh_key(public_key)

    def list_keys(self) -> List[dict]:
        """List all active SSH keys. Returns list of key records."""
        return self.client.list_ssh_keys()

    def delete_key(self, key_id: int) -> dict:
        """Delete an SSH key by ID."""
        return self.client.delete_ssh_key(key_id)


class EgressManager:
    """Manager for egress policy APIs."""

    def __init__(self, client: 'InstaVM'):
        self.client = client

    def set_session(self, session_id: str = None, *,
                 allow_package_managers: bool = True,
                 allow_http: bool = True,
                 allow_https: bool = True,
                 allowed_domains: List[str] = None,
                 allowed_cidrs: List[str] = None) -> dict:
        """Set egress policy for a session. Uses current session if session_id omitted."""
        return self.client.set_session_egress(
            session_id=session_id,
            allow_package_managers=allow_package_managers,
            allow_http=allow_http,
            allow_https=allow_https,
            allowed_domains=allowed_domains,
            allowed_cidrs=allowed_cidrs,
        )

    def get_session(self, session_id: str = None) -> dict:
        """Get egress policy for a session. Uses current session if session_id omitted."""
        return self.client.get_session_egress(session_id=session_id)

    def set_vm(self, vm_id: str, *,
               allow_package_managers: bool = True,
               allow_http: bool = True,
               allow_https: bool = True,
               allowed_domains: List[str] = None,
               allowed_cidrs: List[str] = None) -> dict:
        """Set egress policy for a specific VM."""
        return self.client.set_vm_egress(
            vm_id=vm_id,
            allow_package_managers=allow_package_managers,
            allow_http=allow_http,
            allow_https=allow_https,
            allowed_domains=allowed_domains,
            allowed_cidrs=allowed_cidrs,
        )

    def get_vm(self, vm_id: str) -> dict:
        """Get egress policy for a specific VM."""
        return self.client.get_vm_egress(vm_id=vm_id)


class InstaVM:
    def __init__(
        self,
        api_key=None,
        base_url="https://api.instavm.io",
        timeout=300,
        max_retries=0,
        local=False,
        local_url="http://coderunner.local:8222",
        env: Optional[Dict[str, str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        memory_mb: Optional[int] = None,
        vcpu_count: Optional[int] = None,
        cpu_count: Optional[int] = None,
    ):
        """
        Initialize InstaVM client

        Args:
            api_key: API key for cloud mode (not required for local mode)
            base_url: Base URL for cloud API (ignored if local=True)
            timeout: VM lifetime in seconds (used when creating session). Also used as default HTTP request timeout. Range: 20-86400 seconds. Default: 300
            max_retries: Maximum number of retries for failed requests
            local: Use local container instead of cloud API
            local_url: Local container URL (default: http://coderunner.local:8222)
        """
        if vcpu_count is not None and cpu_count is not None:
            raise ValueError("Provide only one of vcpu_count or cpu_count")
        if vcpu_count is None and cpu_count is not None:
            vcpu_count = cpu_count

        self.local = local
        self.base_url = local_url if local else base_url
        self.api_key = api_key
        self.session_id = None  # Code execution session
        self.timeout = timeout
        self.max_retries = max_retries
        self.session = requests.Session()

        # Session defaults (sent in start_session, if provided)
        self.env = env
        self.metadata = metadata
        self.memory_mb = memory_mb
        self.vcpu_count = vcpu_count
        # Back-compat alias
        self.cpu_count = vcpu_count

        # Browser automation manager
        self.browser = BrowserManager(self)
        # Management APIs
        self.vms = VMManager(self)
        self.snapshots = SnapshotManager(self)
        self.shares = ShareManager(self)
        self.ssh = SSHKeyManager(self)
        self.egress = EgressManager(self)

        # Only start cloud session if not in local mode
        if not self.local and self.api_key:
            self.start_session()

    def _ensure_not_local(self, operation_name: str):
        """Raise UnsupportedOperationError if in local mode"""
        if self.local:
            raise UnsupportedOperationError(
                f"{operation_name} is not supported in local mode. "
                f"This operation is only available when using the cloud API."
            )

    def _make_request(self, method: str, url: str, timeout: Optional[int] = None, **kwargs) -> requests.Response:
        """Make HTTP request with retry logic and proper error handling"""
        last_exception = None
        request_timeout = timeout if timeout is not None else self.timeout

        for attempt in range(self.max_retries + 1):
            try:
                response = self.session.request(
                    method, url, timeout=request_timeout, **kwargs
                )

                # Handle specific HTTP status codes
                if response.status_code == 401:
                    raise AuthenticationError("Invalid API key or session expired")
                elif response.status_code == 429:
                    detail = response.json().get('detail', 'Rate limit exceeded')
                    raise RateLimitError(detail)
                elif response.status_code >= 500:
                    # More details for debugging
                    status_reason = response.reason or ""
                    try:
                        error_text = response.text.strip()
                    except Exception:
                        error_text = "<No response body>"

                    if response.status_code == 504:
                        raise NetworkError(
                            f"504 Gateway Timeout: The server (or a proxy) didn't get a timely response from the upstream service.\n"
                            f"Reason: {status_reason}\n"
                            f"Details: {error_text}"
                        )
                    else:
                        raise NetworkError(
                            f"Server error: {response.status_code} {status_reason}\n"
                            f"Details: {error_text}"
                        )


                response.raise_for_status()
                return response

            except requests.exceptions.Timeout as e:
                last_exception = NetworkError(f"Request timeout after {request_timeout}s")
            except requests.exceptions.ConnectionError as e:
                last_exception = NetworkError(f"Connection failed: {str(e)}")
            except (AuthenticationError, RateLimitError) as e:
                # Don't retry these
                raise e
            except requests.exceptions.HTTPError as e:
                if e.response.status_code < 500:
                    # Re-raise the original exception to allow for specific handling by the caller
                    raise
                last_exception = NetworkError(f"HTTP error: {str(e)}")

            if attempt < self.max_retries:
                # Exponential backoff
                time.sleep(2 ** attempt)

        raise last_exception or NetworkError("Max retries exceeded")

    def _ensure_api_key(self):
        """Raise AuthenticationError if API key is not set."""
        if not self.api_key:
            raise AuthenticationError("API key not set")

    @staticmethod
    def _normalize_egress_policy(
        egress_policy: Optional[Dict[str, Any]]
    ) -> Optional[Dict[str, Any]]:
        if not egress_policy:
            return egress_policy

        normalized = dict(egress_policy)
        if "allow_package_managers" in normalized:
            if "allow_public_repos" not in normalized:
                normalized["allow_public_repos"] = normalized["allow_package_managers"]
            normalized.pop("allow_package_managers", None)
        return normalized

    @staticmethod
    def _response_json_or_none(response: requests.Response) -> Optional[Any]:
        try:
            body = response.text
        except Exception:
            body = ""

        if not body or not body.strip():
            return None

        try:
            return response.json()
        except ValueError as e:
            snippet = body.strip()
            if len(snippet) > 200:
                snippet = snippet[:200] + "..."
            raise InstaVMError(
                f"Failed to parse JSON response (status {response.status_code}): "
                f"{snippet}"
            ) from e

    def start_session(self):
        self._ensure_not_local("Session management")

        if not self.api_key:
            raise AuthenticationError("API key not set. Please provide an API key or create one first.")

        url = f"{self.base_url}/v1/sessions/session"
        data = {
            "api_key": self.api_key,
            "vm_lifetime_seconds": self.timeout
        }
        if self.env is not None:
            data["env"] = self.env
        if self.metadata is not None:
            data["metadata"] = self.metadata
        if self.memory_mb is not None:
            data["memory_mb"] = self.memory_mb
        if self.vcpu_count is not None:
            data["vcpu_count"] = self.vcpu_count

        try:
            response = self._make_request("POST", url, json=data)
            result = response.json()
            self.session_id = result.get("session_id")
            if not self.session_id:
                raise SessionError("Failed to get session ID from server response")
            return self.session_id
        except Exception as e:
            if isinstance(e, (InstaVMError)):
                raise e
            raise SessionError(f"Failed to start session: {str(e)}")

    def execute(self, command: str, language: Optional[str] = None, timeout: Optional[int] = None) -> Dict[str, Any]:
        """
        Execute a command in the VM

        Args:
            command: Command to execute
            language: Programming language (optional)
            timeout: Request timeout in seconds (used both for HTTP request timeout and sent to API)

        Returns:
            Dict containing execution results
        """
        # In local mode, session_id is not required
        if not self.local and not self.session_id:
            raise SessionError("Session ID not set. Please start a session first.")

        url = f"{self.base_url}/execute"
        headers = {"X-API-Key": self.api_key} if self.api_key else {}
        data = {"command": command}

        # Only include session_id in cloud mode
        if not self.local:
            data["session_id"] = self.session_id
        if language:
            data["language"] = language
        if timeout is not None:
            data["timeout"] = timeout

        # Use custom timeout for this request, or fall back to instance default
        request_timeout = timeout if timeout is not None else self.timeout

        try:
            response = self._make_request("POST", url, headers=headers, json=data, timeout=request_timeout)
            return response.json()
        except Exception as e:
            if isinstance(e, InstaVMError):
                raise e
            raise ExecutionError(f"Failed to execute command: {str(e)}")

    def get_usage(self) -> Dict[str, Any]:
        self._ensure_not_local("Usage tracking")

        if not self.session_id:
            raise SessionError("Session ID not set. Please start a session first.")

        url = f"{self.base_url}/v1/sessions/usage/{self.session_id}"

        try:
            response = self._make_request("GET", url)
            return response.json()
        except Exception as e:
            if isinstance(e, InstaVMError):
                raise e
            raise InstaVMError(f"Failed to get usage: {str(e)}")

    def upload_file(self, file_path: str, remote_path: str,
                    recursive: bool = False) -> Dict[str, Any]:
        self._ensure_not_local("File upload")

        if not self.session_id:
            raise SessionError("Session ID not set. Please start a session first.")

        url = f"{self.base_url}/upload"
        headers = {"X-API-Key": self.api_key}
        try:
            with open(file_path, 'rb') as f:
                files = {'file': (file_path, f)}
                data = {
                    "remote_path": remote_path,
                    "session_id": self.session_id,
                    "recursive": str(recursive).lower()  # ensures 'true'/'false'
                }
                response = self._make_request("POST", url, headers=headers, data=data, files=files)
            return response.json()
        except FileNotFoundError:
            raise InstaVMError(f"File not found: {file_path}")
        except Exception as e:
            if isinstance(e, InstaVMError):
                raise
            raise InstaVMError(f"Failed to upload file: {str(e)}")

    def download_file(self, filename: str, local_path: Optional[str] = None) -> Dict[str, Any]:
        """Download a file from the remote VM

        Args:
            filename: Name of the file to download from the remote VM
            local_path: Optional local path to save the file. If not provided, returns file content in response

        Returns:
            Dict containing download status and file information
        """
        self._ensure_not_local("File download")

        if not self.session_id:
            raise SessionError("Session ID not set. Please start a session first.")

        url = f"{self.base_url}/download"
        headers = {"X-API-Key": self.api_key}
        data = {
            "filename": filename,
            "session_id": self.session_id
        }

        try:
            response = self._make_request("POST", url, headers=headers, data=data)

            # Parse JSON response
            response_data = response.json()

            # Extract and decode file content (assuming base64-encoded)
            encoded_content = response_data.get("content", "")
            if encoded_content:
                file_content = base64.b64decode(encoded_content)
            else:
                # Fallback: if no 'content' field, try raw response
                file_content = response.content

            if local_path:
                # Save to local file
                with open(local_path, 'wb') as f:
                    f.write(file_content)
                return {
                    "status": "success",
                    "filename": filename,
                    "local_path": local_path,
                    "size": len(file_content)
                }
            else:
                # Return content in response
                return {
                    "status": "success",
                    "filename": filename,
                    "content": file_content,
                    "size": len(file_content)
                }
        except Exception as e:
            if isinstance(e, InstaVMError):
                raise
            raise InstaVMError(f"Failed to download file: {str(e)}")

    def execute_async(self, command: str, language: Optional[str] = None, timeout: Optional[int] = None) -> Dict[str, Any]:
        """Execute command asynchronously"""
        self._ensure_not_local("Async execution")

        if not self.session_id:
            raise SessionError("Session ID not set. Please start a session first.")

        url = f"{self.base_url}/execute_async"
        headers = {"X-API-Key": self.api_key}
        data = {
            "command": command,
            "session_id": self.session_id,
        }

        if language:
            data["language"] = language
        if timeout is not None:
            data["timeout"] = timeout

        try:
            response = self._make_request("POST", url, headers=headers, json=data)
            return response.json()
        except Exception as e:
            if isinstance(e, InstaVMError):
                raise e
            raise ExecutionError(f"Failed to execute command asynchronously: {str(e)}")

    def get_task_result(self, task_id: str, poll_interval: int = 1, timeout: int = 60) -> Dict[str, Any]:
        """Poll for async task result.

        Args:
            task_id: The task ID from execute_async
            poll_interval: Seconds between polls (default: 1)
            timeout: Maximum seconds to wait (default: 60)

        Returns:
            Dict containing:
                - stdout: Task stdout output
                - stderr: Task stderr output
                - execution_time: Task execution time (if available)
                - cpu_time: Task CPU time (if available)

        Raises:
            TimeoutError: If task doesn't complete within timeout
            ExecutionError: If task retrieval fails
        """
        self._ensure_not_local("Async task result retrieval")

        start_time = time.time()

        while time.time() - start_time < timeout:
            try:
                url = f"{self.base_url}/v1/executions/{task_id}"
                headers = {"X-API-Key": self.api_key}

                response = self._make_request("GET", url, headers=headers)
                task = response.json()

                if task.get("is_complete"):
                    # Output is already decoded as string (not base64 despite field name)
                    stdout = task.get("serialized_stdout", "")
                    stderr = task.get("serialized_stderr", "")

                    return {
                        "stdout": stdout,
                        "stderr": stderr,
                        "cpu_time": task.get("cpu_time"),
                        "created_at": task.get("created_at"),
                        "execution_time": task.get("execution_time")
                    }

                time.sleep(poll_interval)

            except (AuthenticationError, RateLimitError, NetworkError) as e:
                # Don't retry these specific errors
                raise e
            except Exception as e:
                # Continue polling on transient errors
                if time.time() - start_time >= timeout:
                    raise ExecutionError(f"Failed to get task result: {str(e)}")
                time.sleep(poll_interval)

        raise TimeoutError(f"Task {task_id} timed out after {timeout}s")

    def execute_streaming(self, command: str, on_output: Optional[Callable[[str], None]] = None) -> Generator[str, None, None]:
        """Execute command with real-time streaming output (deprecated - streaming not supported by current API)"""
        import warnings
        warnings.warn("execute_streaming is deprecated. The API does not support streaming execution. Use execute() or execute_async() instead.", DeprecationWarning, stacklevel=2)

        # Fallback to regular execution
        result = self.execute(command)
        output = result.get('output', str(result))
        if on_output:
            on_output(output)
        yield output

    # --- Egress Policy Methods ---

    def set_session_egress(self, session_id: str = None, *,
                           allow_package_managers: bool = True,
                           allow_http: bool = True,
                           allow_https: bool = True,
                           allowed_domains: List[str] = None,
                           allowed_cidrs: List[str] = None) -> dict:
        """Set egress policy for a session. Uses current session if session_id omitted."""
        self._ensure_not_local("Egress policy management")
        self._ensure_api_key()

        sid = session_id or self.session_id
        if not sid:
            raise SessionError("Session ID not set. Please start a session first.")

        url = f"{self.base_url}/v1/egress/session/{sid}"
        headers = {"X-API-Key": self.api_key}
        data = {
            "allow_public_repos": allow_package_managers,
            "allow_http": allow_http,
            "allow_https": allow_https,
            "allowed_domains": allowed_domains or [],
            "allowed_cidrs": allowed_cidrs or [],
        }

        try:
            response = self._make_request("POST", url, headers=headers, json=data)
            return response.json()
        except Exception as e:
            if isinstance(e, InstaVMError):
                raise
            raise InstaVMError(f"Failed to set session egress policy: {str(e)}")

    def get_session_egress(self, session_id: str = None) -> dict:
        """Get egress policy for a session. Uses current session if session_id omitted."""
        self._ensure_not_local("Egress policy management")
        self._ensure_api_key()

        sid = session_id or self.session_id
        if not sid:
            raise SessionError("Session ID not set. Please start a session first.")

        url = f"{self.base_url}/v1/egress/session/{sid}"
        headers = {"X-API-Key": self.api_key}

        try:
            response = self._make_request("GET", url, headers=headers)
            return response.json()
        except Exception as e:
            if isinstance(e, InstaVMError):
                raise
            raise InstaVMError(f"Failed to get session egress policy: {str(e)}")

    def set_vm_egress(self, vm_id: str, *,
                      allow_package_managers: bool = True,
                      allow_http: bool = True,
                      allow_https: bool = True,
                      allowed_domains: List[str] = None,
                      allowed_cidrs: List[str] = None) -> dict:
        """Set egress policy for a specific VM."""
        self._ensure_not_local("Egress policy management")
        self._ensure_api_key()

        url = f"{self.base_url}/v1/egress/vm/{vm_id}"
        headers = {"X-API-Key": self.api_key}
        data = {
            "allow_public_repos": allow_package_managers,
            "allow_http": allow_http,
            "allow_https": allow_https,
            "allowed_domains": allowed_domains or [],
            "allowed_cidrs": allowed_cidrs or [],
        }

        try:
            response = self._make_request("POST", url, headers=headers, json=data)
            return response.json()
        except Exception as e:
            if isinstance(e, InstaVMError):
                raise
            raise InstaVMError(f"Failed to set VM egress policy: {str(e)}")

    def get_vm_egress(self, vm_id: str) -> dict:
        """Get egress policy for a specific VM."""
        self._ensure_not_local("Egress policy management")
        self._ensure_api_key()

        url = f"{self.base_url}/v1/egress/vm/{vm_id}"
        headers = {"X-API-Key": self.api_key}

        try:
            response = self._make_request("GET", url, headers=headers)
            return response.json()
        except Exception as e:
            if isinstance(e, InstaVMError):
                raise
            raise InstaVMError(f"Failed to get VM egress policy: {str(e)}")

    # --- SSH Key Methods ---

    def add_ssh_key(self, public_key: str) -> dict:
        """Add an SSH public key. Returns the key record with fingerprint."""
        self._ensure_not_local("SSH key management")
        self._ensure_api_key()

        url = f"{self.base_url}/v1/ssh-keys"
        headers = {"X-API-Key": self.api_key}
        data = {"public_key": public_key}

        try:
            response = self._make_request("POST", url, headers=headers, json=data)
            return response.json()
        except Exception as e:
            if isinstance(e, InstaVMError):
                raise
            raise InstaVMError(f"Failed to add SSH key: {str(e)}")

    def list_ssh_keys(self) -> List[dict]:
        """List all active SSH keys. Returns list of key records."""
        self._ensure_not_local("SSH key management")
        self._ensure_api_key()

        url = f"{self.base_url}/v1/ssh-keys"
        headers = {"X-API-Key": self.api_key}

        try:
            response = self._make_request("GET", url, headers=headers)
            result = response.json()
            return result.get("keys", [])
        except Exception as e:
            if isinstance(e, InstaVMError):
                raise
            raise InstaVMError(f"Failed to list SSH keys: {str(e)}")

    def delete_ssh_key(self, key_id: int) -> dict:
        """Delete an SSH key by ID."""
        self._ensure_not_local("SSH key management")
        self._ensure_api_key()

        url = f"{self.base_url}/v1/ssh-keys/{key_id}"
        headers = {"X-API-Key": self.api_key}

        try:
            response = self._make_request("DELETE", url, headers=headers)
            return response.json()
        except Exception as e:
            if isinstance(e, InstaVMError):
                raise
            raise InstaVMError(f"Failed to delete SSH key: {str(e)}")

    # --- VM / Snapshot / Share Methods ---

    def list_vms(self) -> List[Dict[str, Any]]:
        """List VMs for the current API key."""
        self._ensure_not_local("VM management")
        self._ensure_api_key()

        url = f"{self.base_url}/v1/vms"
        headers = {"X-API-Key": self.api_key}

        try:
            response = self._make_request("GET", url, headers=headers)
            return response.json()
        except Exception as e:
            if isinstance(e, InstaVMError):
                raise
            raise InstaVMError(f"Failed to list VMs: {str(e)}")

    def create_vm(
        self,
        *,
        wait: bool = True,
        session_id: Optional[str] = None,
        vm_lifetime_seconds: Optional[int] = None,
        memory_mb: Optional[int] = None,
        vcpu_count: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None,
        egress_policy: Optional[Dict[str, Any]] = None,
        snapshot_id: Optional[str] = None,
        snapshot_on_terminate: Optional[bool] = None,
        snapshot_name: Optional[str] = None,
        share: Optional[Dict[str, Any]] = None,
        custom_domain: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Create a VM.

        Note: This is a cloud-only API (not available in local mode).
        """
        self._ensure_not_local("VM management")
        self._ensure_api_key()

        url = f"{self.base_url}/v1/vms"
        headers = {"X-API-Key": self.api_key}
        params = {"wait": str(wait).lower()}

        body: Dict[str, Any] = {}

        sid = session_id if session_id is not None else self.session_id
        if sid is not None:
            body["session_id"] = sid

        lifetime = (
            vm_lifetime_seconds
            if vm_lifetime_seconds is not None
            else self.timeout
        )
        body["vm_lifetime_seconds"] = lifetime

        if memory_mb is not None:
            body["memory_mb"] = memory_mb
        if vcpu_count is not None:
            body["vcpu_count"] = vcpu_count
        if metadata is not None:
            body["metadata"] = metadata

        normalized_egress_policy = self._normalize_egress_policy(egress_policy)
        if normalized_egress_policy is not None:
            body["egress_policy"] = normalized_egress_policy

        if snapshot_id is not None:
            body["snapshot_id"] = snapshot_id
        if snapshot_on_terminate is not None:
            body["snapshot_on_terminate"] = snapshot_on_terminate
        if snapshot_name is not None:
            body["snapshot_name"] = snapshot_name
        if share is not None:
            body["share"] = share
        if custom_domain is not None:
            body["custom_domain"] = custom_domain

        try:
            response = self._make_request(
                "POST", url, headers=headers, params=params, json=body
            )
            return response.json()
        except Exception as e:
            if isinstance(e, InstaVMError):
                raise
            raise InstaVMError(f"Failed to create VM: {str(e)}")

    def update_vm(
        self,
        vm_id: str,
        *,
        memory_mb: Optional[int] = None,
        egress_policy: Optional[Dict[str, Any]] = None,
        snapshot_on_terminate: Optional[bool] = None,
        snapshot_name: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """Update a VM. Returns parsed JSON, or None if response is empty."""
        self._ensure_not_local("VM management")
        self._ensure_api_key()

        url = f"{self.base_url}/v1/vms/{vm_id}"
        headers = {"X-API-Key": self.api_key}

        body: Dict[str, Any] = {}
        if memory_mb is not None:
            body["memory_mb"] = memory_mb

        normalized_egress_policy = self._normalize_egress_policy(egress_policy)
        if normalized_egress_policy is not None:
            body["egress_policy"] = normalized_egress_policy

        if snapshot_on_terminate is not None:
            body["snapshot_on_terminate"] = snapshot_on_terminate
        if snapshot_name is not None:
            body["snapshot_name"] = snapshot_name

        if not body:
            raise ValueError("At least one VM field must be provided to update")

        try:
            response = self._make_request("PATCH", url, headers=headers, json=body)
            return self._response_json_or_none(response)
        except Exception as e:
            if isinstance(e, InstaVMError):
                raise
            raise InstaVMError(f"Failed to update VM: {str(e)}")

    def delete_vm(self, vm_id: str) -> bool:
        """Delete (terminate) a VM."""
        self._ensure_not_local("VM management")
        self._ensure_api_key()

        url = f"{self.base_url}/v1/vms/{vm_id}"
        headers = {"X-API-Key": self.api_key}

        try:
            self._make_request("DELETE", url, headers=headers)
            return True
        except Exception as e:
            if isinstance(e, InstaVMError):
                raise
            raise InstaVMError(f"Failed to delete VM: {str(e)}")

    def clone_vm(
        self,
        vm_id: str,
        *,
        wait: bool = True,
        snapshot_name: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Clone a VM. Optionally names the clone's snapshot."""
        self._ensure_not_local("VM management")
        self._ensure_api_key()

        url = f"{self.base_url}/v1/vms/{vm_id}/clone"
        headers = {"X-API-Key": self.api_key}
        params = {"wait": str(wait).lower()}

        body: Dict[str, Any] = {}
        if snapshot_name is not None:
            body["snapshot_name"] = snapshot_name

        try:
            response = self._make_request(
                "POST", url, headers=headers, params=params, json=body
            )
            return response.json()
        except Exception as e:
            if isinstance(e, InstaVMError):
                raise
            raise InstaVMError(f"Failed to clone VM: {str(e)}")

    def snapshot_vm(
        self,
        vm_id: str,
        *,
        wait: bool = True,
        name: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a snapshot from an existing VM."""
        self._ensure_not_local("VM management")
        self._ensure_api_key()

        url = f"{self.base_url}/v1/vms/{vm_id}/snapshot"
        headers = {"X-API-Key": self.api_key}
        params = {"wait": str(wait).lower()}

        body: Dict[str, Any] = {}
        if name is not None:
            body["name"] = name

        try:
            response = self._make_request(
                "POST", url, headers=headers, params=params, json=body
            )
            return response.json()
        except Exception as e:
            if isinstance(e, InstaVMError):
                raise
            raise InstaVMError(f"Failed to snapshot VM: {str(e)}")

    def list_snapshots(self, snapshot_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """List snapshots. Optionally filter by snapshot type ('user' or 'system')."""
        self._ensure_not_local("Snapshot management")
        self._ensure_api_key()

        url = f"{self.base_url}/v1/snapshots"
        headers = {"X-API-Key": self.api_key}
        params = {"type": snapshot_type} if snapshot_type is not None else None

        try:
            response = self._make_request("GET", url, headers=headers, params=params)
            return response.json()
        except Exception as e:
            if isinstance(e, InstaVMError):
                raise
            raise InstaVMError(f"Failed to list snapshots: {str(e)}")

    def create_snapshot(
        self,
        *,
        oci_image: str,
        name: Optional[str] = None,
        vcpu_count: int = 2,
        memory_mb: int = 512,
        build_args: Optional[Dict[str, Any]] = None,
        snapshot_type: str = "user",
    ) -> Dict[str, Any]:
        """Create a snapshot from an OCI image."""
        self._ensure_not_local("Snapshot management")
        self._ensure_api_key()

        url = f"{self.base_url}/v1/snapshots"
        headers = {"X-API-Key": self.api_key}

        body: Dict[str, Any] = {
            "oci_image": oci_image,
            "vcpu_count": vcpu_count,
            "memory_mb": memory_mb,
            "type": snapshot_type,
        }
        if name is not None:
            body["name"] = name
        if build_args is not None:
            body["build_args"] = build_args

        try:
            response = self._make_request("POST", url, headers=headers, json=body)
            return response.json()
        except Exception as e:
            if isinstance(e, InstaVMError):
                raise
            raise InstaVMError(f"Failed to create snapshot: {str(e)}")

    def get_snapshot(self, snapshot_id: str) -> Dict[str, Any]:
        """Get a snapshot by ID."""
        self._ensure_not_local("Snapshot management")
        self._ensure_api_key()

        url = f"{self.base_url}/v1/snapshots/{snapshot_id}"
        headers = {"X-API-Key": self.api_key}

        try:
            response = self._make_request("GET", url, headers=headers)
            return response.json()
        except Exception as e:
            if isinstance(e, InstaVMError):
                raise
            raise InstaVMError(f"Failed to get snapshot: {str(e)}")

    def delete_snapshot(self, snapshot_id: str) -> bool:
        """Delete a snapshot."""
        self._ensure_not_local("Snapshot management")
        self._ensure_api_key()

        url = f"{self.base_url}/v1/snapshots/{snapshot_id}"
        headers = {"X-API-Key": self.api_key}

        try:
            self._make_request("DELETE", url, headers=headers)
            return True
        except Exception as e:
            if isinstance(e, InstaVMError):
                raise
            raise InstaVMError(f"Failed to delete snapshot: {str(e)}")

    def create_share(
        self,
        *,
        port: int,
        session_id: Optional[str] = None,
        vm_id: Optional[str] = None,
        is_public: bool = False,
    ) -> Optional[Dict[str, Any]]:
        """Create a share for a port. Returns parsed JSON, or None if empty."""
        self._ensure_not_local("Share management")
        self._ensure_api_key()

        sid = session_id
        if sid is None and vm_id is None:
            if not self.session_id:
                raise SessionError("Session ID not set. Please start a session first.")
            sid = self.session_id

        url = f"{self.base_url}/v1/shares"
        headers = {"X-API-Key": self.api_key}

        body: Dict[str, Any] = {"port": port, "is_public": is_public}
        if sid is not None:
            body["session_id"] = sid
        if vm_id is not None:
            body["vm_id"] = vm_id

        try:
            response = self._make_request("POST", url, headers=headers, json=body)
            return self._response_json_or_none(response)
        except Exception as e:
            if isinstance(e, InstaVMError):
                raise
            raise InstaVMError(f"Failed to create share: {str(e)}")

    def update_share(
        self,
        share_id: str,
        *,
        is_public: Optional[bool] = None,
        revoke: Optional[bool] = None,
    ) -> Optional[Dict[str, Any]]:
        """Update a share. Returns parsed JSON, or None if response is empty."""
        self._ensure_not_local("Share management")
        self._ensure_api_key()

        body: Dict[str, Any] = {}
        if is_public is not None:
            body["is_public"] = is_public
        if revoke is not None:
            body["revoke"] = revoke

        if not body:
            raise ValueError("At least one share field must be provided to update")

        url = f"{self.base_url}/v1/shares/{share_id}"
        headers = {"X-API-Key": self.api_key}

        try:
            response = self._make_request("PATCH", url, headers=headers, json=body)
            return self._response_json_or_none(response)
        except Exception as e:
            if isinstance(e, InstaVMError):
                raise
            raise InstaVMError(f"Failed to update share: {str(e)}")

    def close_session(self) -> bool:
        """Close the current session (sessions auto-expire on server side)"""
        if not self.session_id:
            return True

        # Note: API doesn't provide explicit session deletion endpoint
        # Sessions will auto-expire on the server side
        print(f"Info: Session {self.session_id} will auto-expire on server side.")
        self.session_id = None
        return True

    def is_session_active(self) -> bool:
        """Check if current session is still active by checking VM status"""
        if not self.session_id:
            return False

        try:
            url = f"{self.base_url}/v1/sessions/status/{self.session_id}"
            headers = {"X-API-Key": self.api_key} if self.api_key else {}
            response = self._make_request("GET", url, headers=headers)
            result = response.json()
            return result.get("vm_status") == "active"
        except (SessionError, AuthenticationError, NetworkError):
            return False
        except Exception:
            return False

    def __enter__(self):
        """Context manager entry"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - automatically close session"""
        self.close_session()
        # Parameters are standard context manager signature

    # Browser Automation Methods
    def create_browser_session(self, viewport_width: int = 1920, viewport_height: int = 1080,
                              user_agent: str = None) -> str:
        """Create a new browser session"""
        self._ensure_not_local("Browser session management")
        self._ensure_api_key()

        url = f"{self.base_url}/v1/browser/sessions/"
        headers = {"X-API-Key": self.api_key}
        data = {
            "viewport_width": viewport_width,
            "viewport_height": viewport_height
        }
        if user_agent:
            data["user_agent"] = user_agent

        try:
            response = self._make_request("POST", url, headers=headers, json=data)
            result = response.json()
            return result.get("session_id")
        except RateLimitError as e:
            raise QuotaExceededError(str(e))
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 429:
                raise QuotaExceededError("Browser API quota exceeded")
            raise BrowserSessionError(f"Failed to create browser session: {str(e)}")
        except Exception as e:
            raise BrowserSessionError(f"Failed to create browser session: {str(e)}")

    def get_browser_session(self, session_id: str) -> Dict[str, Any]:
        """Get browser session information"""
        self._ensure_not_local("Browser session management")
        self._ensure_api_key()

        url = f"{self.base_url}/v1/browser/sessions/{session_id}"
        headers = {"X-API-Key": self.api_key}

        try:
            response = self._make_request("GET", url, headers=headers)
            return response.json()
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 404:
                raise BrowserSessionError("Browser session not found or expired")
            raise BrowserSessionError(f"Failed to get browser session: {str(e)}")
        except Exception as e:
            raise BrowserSessionError(f"Failed to get browser session: {str(e)}")

    def close_browser_session(self, session_id: str) -> bool:
        """Close a browser session"""
        self._ensure_not_local("Browser session management")
        self._ensure_api_key()

        url = f"{self.base_url}/v1/browser/sessions/{session_id}"
        headers = {"X-API-Key": self.api_key}

        try:
            response = self._make_request("DELETE", url, headers=headers)
            return response.status_code == 200
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 404:
                return True  # Already closed
            raise BrowserSessionError(f"Failed to close browser session: {str(e)}")
        except Exception as e:
            raise BrowserSessionError(f"Failed to close browser session: {str(e)}")

    def list_browser_sessions(self) -> List[Dict[str, Any]]:
        """List active browser sessions"""
        self._ensure_not_local("Browser session management")
        self._ensure_api_key()

        url = f"{self.base_url}/v1/browser/sessions/"
        headers = {"X-API-Key": self.api_key}

        try:
            response = self._make_request("GET", url, headers=headers)
            result = response.json()
            return result.get("sessions", [])
        except Exception as e:
            raise BrowserSessionError(f"Failed to list browser sessions: {str(e)}")

    def browser_navigate(self, url: str, session_id: str = None, wait_timeout: int = 30000) -> Dict[str, Any]:
        """Navigate to a URL in browser session

        Args:
            url: URL to navigate to
            session_id: Browser session ID (not required in local mode)
            wait_timeout: Timeout in milliseconds
        """
        # In cloud mode, require API key and session_id
        if not self.local:
            self._ensure_api_key()
            if not session_id:
                raise ValueError("session_id is required in cloud mode")

        api_url = f"{self.base_url}/v1/browser/interactions/navigate"
        headers = {"X-API-Key": self.api_key} if self.api_key else {}
        data = {"url": url, "wait_timeout": wait_timeout}

        # Only include session_id in cloud mode
        if not self.local and session_id:
            data["session_id"] = session_id

        try:
            response = self._make_request("POST", api_url, headers=headers, json=data)
            return response.json()
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 404:
                raise BrowserSessionError("Browser session not found or expired")
            if e.response.status_code == 408:
                raise BrowserTimeoutError("Navigation timeout")
            raise BrowserNavigationError(f"Failed to navigate: {str(e)}")
        except Exception as e:
            raise BrowserNavigationError(f"Failed to navigate: {str(e)}")

    def browser_click(self, selector: str, session_id: str, force: bool = False, timeout: int = 30000) -> Dict[str, Any]:
        """Click an element in browser session"""
        self._ensure_not_local("Browser click interaction")
        self._ensure_api_key()

        url = f"{self.base_url}/v1/browser/interactions/click"
        headers = {"X-API-Key": self.api_key}
        data = {
            "selector": selector,
            "session_id": session_id,
            "force": force,
            "timeout": timeout
        }

        try:
            response = self._make_request("POST", url, headers=headers, json=data)
            return response.json()
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 404:
                raise ElementNotFoundError(f"Element not found: {selector}")
            if e.response.status_code == 408:
                raise BrowserTimeoutError("Click timeout")
            raise BrowserInteractionError(f"Failed to click element: {str(e)}")
        except Exception as e:
            raise BrowserInteractionError(f"Failed to click element: {str(e)}")

    def browser_type(self, selector: str, text: str, session_id: str, delay: int = 100, timeout: int = 30000) -> Dict[str, Any]:
        """Type text into an element"""
        self._ensure_not_local("Browser type interaction")
        self._ensure_api_key()

        url = f"{self.base_url}/v1/browser/interactions/type"
        headers = {"X-API-Key": self.api_key}
        data = {
            "selector": selector,
            "text": text,
            "session_id": session_id,
            "delay": delay,
            "timeout": timeout
        }

        try:
            response = self._make_request("POST", url, headers=headers, json=data)
            return response.json()
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 404:
                raise ElementNotFoundError(f"Element not found: {selector}")
            if e.response.status_code == 408:
                raise BrowserTimeoutError("Type timeout")
            raise BrowserInteractionError(f"Failed to type text: {str(e)}")
        except Exception as e:
            raise BrowserInteractionError(f"Failed to type text: {str(e)}")

    def browser_fill(self, selector: str, value: str, session_id: str, timeout: int = 30000) -> Dict[str, Any]:
        """Fill a form field"""
        self._ensure_not_local("Browser fill interaction")
        self._ensure_api_key()

        url = f"{self.base_url}/v1/browser/interactions/fill"
        headers = {"X-API-Key": self.api_key}
        data = {
            "selector": selector,
            "value": value,
            "session_id": session_id,
            "timeout": timeout
        }

        try:
            response = self._make_request("POST", url, headers=headers, json=data)
            return response.json()
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 404:
                raise ElementNotFoundError(f"Element not found: {selector}")
            if e.response.status_code == 408:
                raise BrowserTimeoutError("Fill timeout")
            raise BrowserInteractionError(f"Failed to fill form: {str(e)}")
        except Exception as e:
            raise BrowserInteractionError(f"Failed to fill form: {str(e)}")

    def browser_scroll(self, session_id: str, selector: str = None, x: int = None, y: int = None) -> Dict[str, Any]:
        """Scroll the page or an element"""
        self._ensure_not_local("Browser scroll interaction")
        self._ensure_api_key()

        if selector is None and x is None and y is None:
            raise ValueError("At least one of 'selector', 'x', or 'y' must be provided for scrolling.")

        url = f"{self.base_url}/v1/browser/interactions/scroll"
        headers = {"X-API-Key": self.api_key}
        data = {"session_id": session_id}
        if selector:
            data["selector"] = selector
        if x is not None:
            data["x"] = x
        if y is not None:
            data["y"] = y

        try:
            response = self._make_request("POST", url, headers=headers, json=data)
            return response.json()
        except Exception as e:
            raise BrowserInteractionError(f"Failed to scroll: {str(e)}")

    def browser_wait(self, condition: str, session_id: str, selector: str = None, timeout: int = 30000) -> Dict[str, Any]:
        """Wait for a condition to be met"""
        self._ensure_not_local("Browser wait interaction")
        self._ensure_api_key()

        url = f"{self.base_url}/v1/browser/interactions/wait"
        headers = {"X-API-Key": self.api_key}
        data = {
            "condition": condition,
            "session_id": session_id,
            "timeout": timeout
        }
        if selector:
            data["selector"] = selector

        try:
            response = self._make_request("POST", url, headers=headers, json=data)
            return response.json()
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 408:
                raise BrowserTimeoutError(f"Wait timeout for condition: {condition}")
            raise BrowserInteractionError(f"Failed to wait for condition: {str(e)}")
        except Exception as e:
            raise BrowserInteractionError(f"Failed to wait for condition: {str(e)}")

    def browser_screenshot(self, session_id: str, full_page: bool = True, clip: Dict = None,
                          format: str = "png", quality: int = None) -> str:
        """Take a screenshot (returns base64 string)"""
        self._ensure_not_local("Browser screenshot")
        self._ensure_api_key()

        url = f"{self.base_url}/v1/browser/interactions/screenshot"
        headers = {"X-API-Key": self.api_key}
        data = {
            "session_id": session_id,
            "full_page": full_page,
            "format": format
        }
        if clip:
            data["clip"] = clip
        if quality:
            data["quality"] = quality

        try:
            response = self._make_request("POST", url, headers=headers, json=data)
            result = response.json()
            return result.get("screenshot", "")
        except Exception as e:
            raise BrowserInteractionError(f"Failed to take screenshot: {str(e)}")

    def browser_extract_elements(self, session_id: str, selector: str = None, attributes: List[str] = None) -> List[Dict[str, Any]]:
        """Extract DOM elements"""
        self._ensure_not_local("Browser element extraction")
        self._ensure_api_key()

        url = f"{self.base_url}/v1/browser/interactions/extract"
        headers = {"X-API-Key": self.api_key}
        data = {"session_id": session_id}
        if selector:
            data["selector"] = selector
        if attributes:
            data["attributes"] = attributes

        try:
            response = self._make_request("POST", url, headers=headers, json=data)
            result = response.json()
            return result.get("elements", [])
        except Exception as e:
            raise BrowserInteractionError(f"Failed to extract elements: {str(e)}")

    def browser_extract_content(self, session_id: str = None, url: str = None,
                                include_interactive: bool = True,
                                include_anchors: bool = True, max_anchors: int = 50) -> Dict[str, Any]:
        """
        Extract LLM-friendly content from current page.

        Returns clean article content, interactive elements, and content anchors
        for intelligent browser automation.

        Args:
            session_id: Browser session ID (not required in local mode, required in cloud mode)
            url: URL to extract content from (required in local mode, optional in cloud mode)
            include_interactive: Include interactive elements mapping (default: True)
            include_anchors: Include content-to-selector anchors (default: True)
            max_anchors: Maximum number of content anchors (default: 50)

        Returns:
            Dict with:
            - readable_content: Clean article text (no JS/CSS/ads)
            - interactive_elements: Clickable/typeable elements with selectors
            - content_anchors: Text snippets mapped to DOM selectors

        Example:
            ```python
            # Cloud mode
            content = client.browser_extract_content(session_id="session123")

            # Local mode
            content = client.browser_extract_content(url="https://example.com")

            # LLM reads clean content
            article = content['readable_content']['content']

            # LLM finds "Sign Up" in content
            # LLM searches content_anchors for selector
            for anchor in content['content_anchors']:
                if 'sign up' in anchor['text'].lower():
                    selector = anchor['selector']
                    client.browser_click(selector, session_id)
                    break
            ```
        """
        # In cloud mode, require API key and session_id
        if not self.local:
            self._ensure_api_key()
            if not session_id:
                raise ValueError("session_id is required in cloud mode")
        else:
            # In local mode, require url
            if not url:
                raise ValueError("url is required in local mode")

        api_url = f"{self.base_url}/v1/browser/interactions/content"
        headers = {"X-API-Key": self.api_key} if self.api_key else {}
        data = {
            "include_interactive": include_interactive,
            "include_anchors": include_anchors,
            "max_anchors": max_anchors
        }

        # Include session_id in cloud mode
        if not self.local and session_id:
            data["session_id"] = session_id

        # Include url in local mode
        if self.local and url:
            data["url"] = url

        try:
            response = self._make_request("POST", api_url, headers=headers, json=data)
            return response.json()
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 404:
                raise BrowserSessionError("Browser session not found or expired")
            raise BrowserInteractionError(f"Failed to extract content: {str(e)}")
        except json.JSONDecodeError as e:
            raise BrowserInteractionError(f"Failed to parse server response: {str(e)}")
