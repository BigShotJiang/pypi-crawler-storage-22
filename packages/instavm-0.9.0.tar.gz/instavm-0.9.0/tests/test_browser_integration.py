import requests
import pytest
from unittest.mock import MagicMock, call, patch

from instavm import (
    InstaVM,
    ElementNotFoundError,
    QuotaExceededError,
    RateLimitError,
)
from instavm.sandbox_client import BrowserSession


class TestInstaVMBrowserIntegration:
    """Unit tests for browser APIs without real HTTP requests."""

    @pytest.fixture
    def client(self):
        with patch.object(InstaVM, "start_session"):
            client = InstaVM(api_key="test_api_key", base_url="https://api.test.com")
            client.session_id = "test_session_id"
        return client

    def test_create_browser_session(self, client):
        with patch.object(client, "_make_request") as mock_make_request:
            response = MagicMock()
            response.json.return_value = {"session_id": "browser_session_123"}
            mock_make_request.return_value = response

            session_id = client.create_browser_session(
                viewport_width=1280,
                viewport_height=720,
                user_agent="test-agent",
            )

            assert session_id == "browser_session_123"
            mock_make_request.assert_called_once_with(
                "POST",
                "https://api.test.com/v1/browser/sessions/",
                headers={"X-API-Key": "test_api_key"},
                json={
                    "viewport_width": 1280,
                    "viewport_height": 720,
                    "user_agent": "test-agent",
                },
            )

    def test_create_browser_session_quota_exceeded(self, client):
        with patch.object(client, "_make_request") as mock_make_request:
            mock_make_request.side_effect = RateLimitError("Quota exceeded")

            with pytest.raises(QuotaExceededError):
                client.create_browser_session()

    def test_browser_navigate(self, client):
        with patch.object(client, "_make_request") as mock_make_request:
            response = MagicMock()
            response.json.return_value = {"success": True, "data": {"url": "x"}}
            mock_make_request.return_value = response

            result = client.browser_navigate(
                url="https://example.com",
                session_id="browser_session_123",
            )

            assert result["success"] is True
            mock_make_request.assert_called_once_with(
                "POST",
                "https://api.test.com/v1/browser/interactions/navigate",
                headers={"X-API-Key": "test_api_key"},
                json={
                    "url": "https://example.com",
                    "wait_timeout": 30000,
                    "session_id": "browser_session_123",
                },
            )

    def test_browser_click_element_not_found(self, client):
        with patch.object(client, "_make_request") as mock_make_request:
            response = MagicMock()
            response.status_code = 404
            mock_make_request.side_effect = requests.exceptions.HTTPError(
                "Not Found", response=response
            )

            with pytest.raises(ElementNotFoundError):
                client.browser_click(
                    selector="#nonexistent",
                    session_id="browser_session_123",
                )

    def test_close_browser_session(self, client):
        with patch.object(client, "_make_request") as mock_make_request:
            response = MagicMock()
            response.status_code = 200
            mock_make_request.return_value = response

            assert client.close_browser_session("browser_session_123") is True

            mock_make_request.assert_called_once_with(
                "DELETE",
                "https://api.test.com/v1/browser/sessions/browser_session_123",
                headers={"X-API-Key": "test_api_key"},
            )


class TestBrowserManager:
    @pytest.fixture
    def client(self):
        with patch.object(InstaVM, "start_session"):
            client = InstaVM(api_key="test_api_key", base_url="https://api.test.com")
            client.session_id = "test_session_id"
        return client

    def test_browser_manager_navigate_auto_session(self, client):
        with patch.object(client, "_make_request") as mock_make_request:
            response_session = MagicMock()
            response_session.json.return_value = {"session_id": "auto_session_123"}

            response_navigate = MagicMock()
            response_navigate.json.return_value = {
                "success": True,
                "url": "https://example.com",
            }

            mock_make_request.side_effect = [response_session, response_navigate]

            result = client.browser.navigate("https://example.com")
            assert result["success"] is True

            mock_make_request.assert_has_calls(
                [
                    call(
                        "POST",
                        "https://api.test.com/v1/browser/sessions/",
                        headers={"X-API-Key": "test_api_key"},
                        json={"viewport_width": 1920, "viewport_height": 1080},
                    ),
                    call(
                        "POST",
                        "https://api.test.com/v1/browser/interactions/navigate",
                        headers={"X-API-Key": "test_api_key"},
                        json={
                            "url": "https://example.com",
                            "wait_timeout": 30000,
                            "session_id": "auto_session_123",
                        },
                    ),
                ],
                any_order=False,
            )


class TestBrowserSession:
    @pytest.fixture
    def client(self):
        with patch.object(InstaVM, "start_session"):
            client = InstaVM(api_key="test_api_key", base_url="https://api.test.com")
            client.session_id = "test_session_id"
        return client

    def test_browser_session_context_manager_closes(self, client):
        with patch.object(client, "_make_request") as mock_make_request:
            response_session = MagicMock()
            response_session.json.return_value = {"session_id": "ctx_session_123"}

            response_navigate = MagicMock()
            response_navigate.json.return_value = {"success": True}

            response_close = MagicMock()
            response_close.status_code = 200

            mock_make_request.side_effect = [
                response_session,
                response_navigate,
                response_close,
            ]

            browser_session = client.browser.create_session(viewport_width=1280)

            with browser_session:
                result = browser_session.navigate("https://example.com")
                assert result["success"] is True

            mock_make_request.assert_has_calls(
                [
                    call(
                        "POST",
                        "https://api.test.com/v1/browser/sessions/",
                        headers={"X-API-Key": "test_api_key"},
                        json={"viewport_width": 1280, "viewport_height": 1080},
                    ),
                    call(
                        "POST",
                        "https://api.test.com/v1/browser/interactions/navigate",
                        headers={"X-API-Key": "test_api_key"},
                        json={
                            "url": "https://example.com",
                            "wait_timeout": 30000,
                            "session_id": "ctx_session_123",
                        },
                    ),
                    call(
                        "DELETE",
                        "https://api.test.com/v1/browser/sessions/ctx_session_123",
                        headers={"X-API-Key": "test_api_key"},
                    ),
                ],
                any_order=False,
            )

    def test_browser_session_delegates(self, client):
        session = BrowserSession("test_session", client)

        with patch.object(client, "browser_navigate") as mock_nav:
            mock_nav.return_value = {"success": True}
            result = session.navigate("https://example.com", wait_timeout=5000)

            mock_nav.assert_called_once_with(
                "https://example.com", "test_session", 5000
            )
            assert result["success"] is True

