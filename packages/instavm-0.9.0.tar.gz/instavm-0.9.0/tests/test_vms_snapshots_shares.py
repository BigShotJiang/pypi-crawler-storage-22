import pytest
from unittest.mock import MagicMock, patch

from instavm import (
    InstaVM,
    AuthenticationError,
    SessionError,
    UnsupportedOperationError,
)


class TestVmsSnapshotsShares:
    @pytest.fixture
    def client(self):
        with patch.object(InstaVM, "start_session"):
            client = InstaVM(api_key="test_api_key", base_url="https://api.test.com")
            client.session_id = "sess_123"
        return client

    def test_list_vms(self, client):
        with patch.object(client, "_make_request") as mock_make_request:
            response = MagicMock()
            response.json.return_value = [{"vm_id": "vm_1"}]
            mock_make_request.return_value = response

            vms = client.list_vms()
            assert vms == [{"vm_id": "vm_1"}]

            mock_make_request.assert_called_once_with(
                "GET",
                "https://api.test.com/v1/vms",
                headers={"X-API-Key": "test_api_key"},
            )

    def test_create_vm_defaults(self, client):
        with patch.object(client, "_make_request") as mock_make_request:
            response = MagicMock()
            response.json.return_value = {
                "vm_id": "vm_1",
                "session_id": "sess_123",
                "status": "active",
            }
            mock_make_request.return_value = response

            result = client.create_vm()
            assert result["vm_id"] == "vm_1"

            mock_make_request.assert_called_once()
            args, kwargs = mock_make_request.call_args
            assert args == ("POST", "https://api.test.com/v1/vms")
            assert kwargs["headers"] == {"X-API-Key": "test_api_key"}
            assert kwargs["params"] == {"wait": "true"}
            assert kwargs["json"]["session_id"] == "sess_123"
            assert kwargs["json"]["vm_lifetime_seconds"] == client.timeout

    def test_create_vm_wait_false(self, client):
        with patch.object(client, "_make_request") as mock_make_request:
            response = MagicMock()
            response.json.return_value = {"vm_id": "vm_1", "status": "active"}
            mock_make_request.return_value = response

            client.create_vm(wait=False)

            _, kwargs = mock_make_request.call_args
            assert kwargs["params"] == {"wait": "false"}

    def test_create_vm_normalizes_egress_policy(self, client):
        with patch.object(client, "_make_request") as mock_make_request:
            response = MagicMock()
            response.json.return_value = {"vm_id": "vm_1", "status": "active"}
            mock_make_request.return_value = response

            client.create_vm(
                egress_policy={
                    "allow_package_managers": False,
                    "allow_https": True,
                }
            )

            _, kwargs = mock_make_request.call_args
            egress_policy = kwargs["json"]["egress_policy"]
            assert "allow_package_managers" not in egress_policy
            assert egress_policy["allow_public_repos"] is False
            assert egress_policy["allow_https"] is True

    def test_update_vm_requires_fields(self, client):
        with pytest.raises(ValueError):
            client.update_vm("vm_1")

    def test_update_vm_empty_body_returns_none(self, client):
        with patch.object(client, "_make_request") as mock_make_request:
            response = MagicMock()
            response.text = ""
            mock_make_request.return_value = response

            result = client.update_vm("vm_1", memory_mb=1024)
            assert result is None

    def test_delete_vm_returns_true(self, client):
        with patch.object(client, "_make_request") as mock_make_request:
            mock_make_request.return_value = MagicMock()

            assert client.delete_vm("vm_1") is True

    def test_clone_vm_wait_default_true(self, client):
        with patch.object(client, "_make_request") as mock_make_request:
            response = MagicMock()
            response.json.return_value = {"vm_id": "vm_2", "status": "active"}
            mock_make_request.return_value = response

            client.clone_vm("vm_1")

            _, kwargs = mock_make_request.call_args
            assert kwargs["params"] == {"wait": "true"}

    def test_snapshot_vm_wait_default_true(self, client):
        with patch.object(client, "_make_request") as mock_make_request:
            response = MagicMock()
            response.json.return_value = {
                "snapshot_id": "snap_1",
                "status": "created",
            }
            mock_make_request.return_value = response

            client.snapshot_vm("vm_1")

            _, kwargs = mock_make_request.call_args
            assert kwargs["params"] == {"wait": "true"}

    def test_list_snapshots_filter(self, client):
        with patch.object(client, "_make_request") as mock_make_request:
            response = MagicMock()
            response.json.return_value = [{"id": "snap_1"}]
            mock_make_request.return_value = response

            snapshots = client.list_snapshots(snapshot_type="system")
            assert snapshots == [{"id": "snap_1"}]

            mock_make_request.assert_called_once_with(
                "GET",
                "https://api.test.com/v1/snapshots",
                headers={"X-API-Key": "test_api_key"},
                params={"type": "system"},
            )

    def test_create_snapshot_defaults(self, client):
        with patch.object(client, "_make_request") as mock_make_request:
            response = MagicMock()
            response.json.return_value = {"id": "snap_1", "status": "building"}
            mock_make_request.return_value = response

            client.create_snapshot(oci_image="python:3.12-slim")

            _, kwargs = mock_make_request.call_args
            body = kwargs["json"]
            assert body["oci_image"] == "python:3.12-slim"
            assert body["vcpu_count"] == 2
            assert body["memory_mb"] == 512
            assert body["type"] == "user"

    def test_create_share_defaults_to_current_session(self, client):
        with patch.object(client, "_make_request") as mock_make_request:
            response = MagicMock()
            response.text = ""
            mock_make_request.return_value = response

            result = client.create_share(port=8000)
            assert result is None

            _, kwargs = mock_make_request.call_args
            assert kwargs["json"]["session_id"] == "sess_123"
            assert kwargs["json"]["port"] == 8000
            assert kwargs["json"]["is_public"] is False

    def test_create_share_requires_session_or_vm_id(self):
        with patch.object(InstaVM, "start_session"):
            client = InstaVM(api_key="test_api_key", base_url="https://api.test.com")

        with pytest.raises(SessionError):
            client.create_share(port=8000)

    def test_update_share_empty_body_returns_none(self, client):
        with patch.object(client, "_make_request") as mock_make_request:
            response = MagicMock()
            response.text = ""
            mock_make_request.return_value = response

            assert client.update_share("share_1", revoke=True) is None

    def test_local_mode_raises_unsupported_operation(self):
        client = InstaVM(local=True)
        with pytest.raises(UnsupportedOperationError):
            client.list_vms()

    def test_cloud_missing_api_key_raises_authentication_error(self):
        with patch.object(InstaVM, "start_session"):
            client = InstaVM(api_key=None, base_url="https://api.test.com")

        with pytest.raises(AuthenticationError):
            client.list_vms()

