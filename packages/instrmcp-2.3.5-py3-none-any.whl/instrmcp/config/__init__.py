"""InstrMCP configuration package.

Contains:
- metadata_baseline.yaml: Default tool/resource metadata descriptions
"""
