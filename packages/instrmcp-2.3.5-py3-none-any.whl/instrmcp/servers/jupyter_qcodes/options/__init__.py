"""
Optional features for the Jupyter MCP server.

These features are enabled via %mcp_option add <feature_name>.
Available options: measureit, database, dynamictool
"""
