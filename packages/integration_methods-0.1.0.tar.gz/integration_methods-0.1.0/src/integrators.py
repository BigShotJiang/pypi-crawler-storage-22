"""Numerical integration methods."""
import math
import random

def trapezoidal(f, a: float, b: float, n: int) -> float:
    """Composite trapezoidal rule."""
    if n <= 0:
        raise ValueError("n must be positive")
    h = (b - a) / n
    total = (f(a) + f(b)) / 2
    for i in range(1, n):
        total += f(a + i * h)
    return total * h

def simpson(f, a: float, b: float, n: int) -> float:
    """Composite Simpson's 1/3 rule. n must be even."""
    if n <= 0 or n % 2 != 0:
        raise ValueError("n must be a positive even integer")
    h = (b - a) / n
    total = f(a) + f(b)
    for i in range(1, n, 2):
        total += 4 * f(a + i * h)
    for i in range(2, n, 2):
        total += 2 * f(a + i * h)
    return total * h / 3

def monte_carlo(f, a: float, b: float, n: int, seed: int = 42) -> float:
    """Monte Carlo integration with fixed seed for reproducibility."""
    if n <= 0:
        raise ValueError("n must be positive")
    rng = random.Random(seed)
    total = sum(f(rng.uniform(a, b)) for _ in range(n))
    return (b - a) * total / n
