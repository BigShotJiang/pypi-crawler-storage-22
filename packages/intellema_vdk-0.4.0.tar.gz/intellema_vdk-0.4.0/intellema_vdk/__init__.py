from typing import Optional, List, Any

from .providers import (
    VoiceProvider,
    LiveKitManager,
    RetellManager,
    # LiveKit Exceptions
    LiveKitError,
    LiveKitConfigurationError,
    LiveKitRoomError,
    LiveKitSIPError,
    LiveKitDispatchError,
    LiveKitEgressError,
    # Retell Exceptions
    RetellError,
    RetellConfigurationError,
    RetellAPIError,
    RetellPhoneNumberError,
    RetellCallError,
)
from .stt import (
    STTManager,
    STTAgentError,
    STTConfigurationError,
    STTError,
    STTFileError,
    STTTranscriptionError
)
from .tts import (
    TTSStreamer,
    TTSError,
    TTSConfigurationError,
    TTSStreamError,
    TTSAPIError,
)
from .utils.logger_config import setup_logging

__all__ = [
    "VoiceClient",
    "start_outbound_call",
    "VoiceProvider",
    "LiveKitManager",
    "RetellManager",
    "STTManager",
    "TTSStreamer",
    "setup_logging",
    "LiveKitError",
    "LiveKitConfigurationError",
    "LiveKitRoomError",
    "LiveKitSIPError",
    "LiveKitDispatchError",
    "LiveKitEgressError",
    "RetellError",
    "RetellConfigurationError",
    "RetellAPIError",
    "RetellPhoneNumberError",
    "RetellCallError",
    "STTAgentError",
    "STTConfigurationError",
    "STTError",
    "STTFileError",
    "STTTranscriptionError",
    "TTSError",
    "TTSConfigurationError",
    "TTSStreamError",
    "TTSAPIError",
]

def VoiceClient(provider: str, **kwargs) -> VoiceProvider:
    """
    Factory function that returns a specific provider client.
    
    Args:
        provider: "livekit" or "retell"
        **kwargs: Arguments passed to the manager's constructor
    
    Returns:
        An instance of LiveKitManager or RetellManager
    """
    if provider == "livekit":
        return LiveKitManager(**kwargs)
    elif provider == "retell":
        return RetellManager(**kwargs)
    else:
        raise ValueError(f"Unknown provider: {provider}. Supported providers: 'livekit', 'retell'")

async def start_outbound_call(provider: str, *args, **kwargs):
    """
    Convenience wrapper to start an outbound call.
    """
    client = VoiceClient(provider)
    return await client.start_outbound_call(*args, **kwargs)
