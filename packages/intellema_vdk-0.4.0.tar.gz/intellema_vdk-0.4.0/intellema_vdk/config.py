import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv(dotenv_path=".env.local")
load_dotenv()

def get_env(key: str, default: str = None) -> str:
    """Get an environment variable."""
    return os.getenv(key, default)

# TTS Configuration
TTS_AUDIO_SAMPLE_RATE = 24000
WAV_HEADER_SIZE = 44
