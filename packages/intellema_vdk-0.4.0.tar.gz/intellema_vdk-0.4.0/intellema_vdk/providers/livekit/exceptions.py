class LiveKitError(Exception):
    """Base exception for all LiveKit-related errors."""
    pass

class LiveKitConfigurationError(LiveKitError):
    """Raised when configuration (URL, API Key, Secret) is missing or invalid."""
    pass

class LiveKitRoomError(LiveKitError):
    """Raised when creating, deleting, or managing a room fails."""
    pass

class LiveKitSIPError(LiveKitError):
    """Raised when SIP trunking or participant operations fail."""
    pass

class LiveKitDispatchError(LiveKitError):
    """Raised when agent dispatch operations fail."""
    pass

class LiveKitEgressError(LiveKitError):
    """Raised when starting or managing egress (recording/streaming) fails."""
    pass
