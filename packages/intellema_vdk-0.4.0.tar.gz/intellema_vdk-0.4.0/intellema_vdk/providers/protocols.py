from typing import List, Optional, Protocol, runtime_checkable

@runtime_checkable
class VoiceProvider(Protocol):
    """Protocol defining the interface for voice providers."""

    async def start_outbound_call(self, phone_number: str, prompt_content: str, call_id: Optional[str] = None) -> str:
        """Initiates an outbound call and returns the call/room ID."""
        ...

    async def delete_room(self, call_id: str) -> None:
        """Ends the call/room."""
        ...

    async def start_stream(self, call_id: str, rtmp_urls: List[str]) -> None:
        """Starts streaming the call to RTMP URLs."""
        ...

    async def start_recording(self, call_id: str, output_filepath: Optional[str] = None, upload_to_s3: bool = True, wait_for_completion: bool = True) -> str:
        """Starts recording the call and returns the recording ID."""
        ...

    async def kick_participant(self, call_id: str, identity: str) -> None:
        """Removes a participant from the call."""
        ...

    async def mute_participant(self, call_id: str, identity: str, track_sid: str, muted: bool) -> None:
        """Mutes or unmutes a participant's track."""
        ...

    async def send_alert(self, call_id: str, message: str, participant_identity: Optional[str] = None) -> None:
        """Sends a data message/alert to the call."""
        ...
