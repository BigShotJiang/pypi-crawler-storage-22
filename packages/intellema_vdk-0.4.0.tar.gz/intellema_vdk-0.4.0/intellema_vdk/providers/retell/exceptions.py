class RetellError(Exception):
    """Base exception for all Retell-related errors."""
    pass

class RetellConfigurationError(RetellError):
    """Raised when configuration (API keys, secrets) is missing or invalid."""
    pass

class RetellAPIError(RetellError):
    """Raised when the Retell API returns an error response."""
    pass

class RetellPhoneNumberError(RetellError):
    """Raised when there are issues importing or managing phone numbers."""
    pass

class RetellCallError(RetellError):
    """Raised when starting, updating, or ending a call fails."""
    pass
