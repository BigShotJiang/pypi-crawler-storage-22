import os  # Used for operating system dependent functionality, like checking file existence.
import json  # Used for JSON serialization.
import logging  # Used for logging events.
from pathlib import Path  # Used for path operations.
from typing import Optional, Tuple, Any, List, Dict, Union, Literal, overload  # Used for type hinting.

# httpx is a core dependency and should be available
import httpx  # Modern asynchronous HTTP client.

from .providers import (
    STTProvider,
    OpenAISTTProvider,
    ElevenLabsSTTProvider,
    LocalWhisperSTTProvider,
    LocalMoonshineSTTProvider,
    OpenAISTTConfig,
    ElevenLabsSTTConfig,
    LocalWhisperSTTConfig,
    LocalMoonshineSTTConfig,
    OpenAISTTModel,
    ElevenLabsSTTModel,
    LocalWhisperDevice,
    LocalWhisperComputeType,
    LocalWhisperSTTModel,
    LocalMoonshineSTTModel,
    LocalMoonshineLanguage,
    ALLOWED_WHISPER_MODELS,
    ALLOWED_MOONSHINE_MODELS,
)
from ..config import get_env  # Used to get environment variables.
from .exceptions import (
    STTConfigurationError,
    STTFileError,
    STTTranscriptionError,
    STTAgentError,
    STTError
)

# Setup logger for this module.
logger = logging.getLogger(__name__)


class STTManager:
    """Manages Speech-to-Text (STT) operations using various providers.

    This class provides functionality to transcribe audio files and optionally
    post the transcribed text to an external agent API. Supports multiple
    STT providers including OpenAI, ElevenLabs, local Whisper, and local Moonshine models.
    
    Create instances using factory methods:
        - STTManager.from_openai() - For OpenAI Whisper/GPT-4o models
        - STTManager.from_elevenlabs() - For ElevenLabs Scribe models
        - STTManager.from_local_whisper() - For offline local Whisper models
        - STTManager.from_local_moonshine() - For offline Moonshine models (low-latency)

    Attributes:
        provider (STTProvider): The STT provider instance for transcription.
        _agent_api_url (Optional[str]): The URL of the agent API to post
            transcriptions to.
        _http_client (httpx.AsyncClient): The asynchronous HTTP client for
            making requests to the agent API.

    Supported Providers:
        - OpenAI: Uses Whisper and GPT-4o models for high-quality transcription
        - ElevenLabs: Uses Scribe models for fast transcription
        - Local Whisper: Uses faster-whisper for offline, cost-free transcription
        - Local Moonshine: Uses moonshine-voice for offline, low-latency transcription

    Example:
        >>> async def main():
        ...     # Using OpenAI Whisper
        ...     stt_manager = STTManager.from_openai(model="whisper-1")
        ...     try:
        ...         result = await stt_manager.transcribe_audio(
        ...             "audio.wav",
        ...             language="en"
        ...         )
        ...         print(f"Transcript: {result['text']}")
        ...         
        ...         # Post to agent API
        ...         result, response = await stt_manager.transcribe_and_post(
        ...             "audio.wav",
        ...             agent_post_key="transcript"
        ...         )
        ...     finally:
        ...         await stt_manager.close()
        ...
        ...     # Using ElevenLabs
        ...     stt_manager = STTManager.from_elevenlabs(model="scribe_v2")
        ...     try:
        ...         result = await stt_manager.transcribe_audio(
        ...             "audio.wav",
        ...             language="en",
        ...             temperature=0.5
        ...         )
        ...         print(f"Transcript: {result['text']}")
        ...     finally:
        ...         await stt_manager.close()
        ...
        ...     # Using Local Whisper (offline, no API costs)
        ...     stt_manager = STTManager.from_local_whisper(
        ...         model="base",
        ...         device="cuda",
        ...         vad_filter=True,
        ...         beam_size=7
        ...     )
        ...     try:
        ...         result = await stt_manager.transcribe_audio(
        ...             "audio.wav",
        ...             language="en"
        ...         )
        ...         print(f"Transcript: {result['text']}")
        ...     finally:
        ...         await stt_manager.close()
        ...
        ...     # Using Local Moonshine (offline, low-latency)
        ...     stt_manager = STTManager.from_local_moonshine(
        ...         model="base",
        ...         language="en",
        ...         vad_threshold=0.5
        ...     )
        ...     try:
        ...         result = await stt_manager.transcribe_audio("audio.wav")
        ...         print(f"Transcript: {result['text']}")
        ...     finally:
        ...         await stt_manager.close()
        ...
        >>> if __name__ == "__main__":
        ...     import asyncio
        ...     asyncio.run(main())
    """

    # Default supported audio extensions
    DEFAULT_BATCH_EXTENSIONS = [".mp3", ".mp4", ".mpeg", ".mpga", ".m4a", ".wav", ".webm"]

    def __init__(self, provider: STTProvider) -> None:
        """Internal constructor for STTManager.
        
        Use factory methods to create instances instead:
            - STTManager.from_openai() for OpenAI Whisper
            - STTManager.from_elevenlabs() for ElevenLabs Scribe  
            - STTManager.from_local_whisper() for local Whisper models
        """
        self.provider = provider
        self._agent_api_url = get_env("AGENT_API_URL")
        if not self._agent_api_url:
            logger.warning(
                "AGENT_API_URL is not set in .env. Posting to agent will be disabled.")
        self._http_client = httpx.AsyncClient()

    @classmethod
    def from_openai(
        cls,
        model: OpenAISTTModel = "whisper-1",
        api_key: Optional[str] = None
    ) -> "STTManager":
        """
        Create STTManager with OpenAI provider.
        
        Args:
            model (OpenAISTTModel): OpenAI model to use for transcription.
                Allowed values:
                - "whisper-1": Standard Whisper model (reliable)
                - "gpt-4o-transcribe": GPT-4o transcription
                - "gpt-4o-transcribe-diarize": GPT-4o with speaker diarization
                - "gpt-4o-mini-transcribe": Faster, cheaper GPT-4o variant
                Default: "whisper-1"
            api_key (Optional[str]): OpenAI API key. If None, reads from OPENAI_API_KEY env var.
                Default: None
        
        Returns:
            STTManager instance configured for OpenAI.
            
        Raises:
            STTConfigurationError: If API key is missing.
            
        Example:
            >>> stt = STTManager.from_openai(model="whisper-1")
            >>> result = await stt.transcribe_audio("audio.wav", language="en")
        """
        api_key = api_key or get_env("OPENAI_API_KEY")
        if not api_key:
            raise STTConfigurationError(
                "OpenAI API Key is missing. Set OPENAI_API_KEY env var or pass api_key."
            )
        provider = OpenAISTTProvider(api_key=api_key, model=model)
        return cls(provider)

    @classmethod
    def from_elevenlabs(
        cls,
        model: ElevenLabsSTTModel = "scribe_v1",
        api_key: Optional[str] = None
    ) -> "STTManager":
        """
        Create STTManager with ElevenLabs provider.
        
        Args:
            model (ElevenLabsSTTModel): ElevenLabs model to use for transcription.
                Allowed values:
                - "scribe_v1": Production-ready multilingual model
                - "scribe_v1_experimental": Experimental features (may change)
                - "scribe_v2": Latest version with improvements
                Default: "scribe_v1"
            api_key (Optional[str]): ElevenLabs API key. If None, reads from ELEVENLABS_API_KEY env var.
                Default: None
        
        Returns:
            STTManager instance configured for ElevenLabs.
            
        Raises:
            STTConfigurationError: If API key is missing.
            
        Example:
            >>> stt = STTManager.from_elevenlabs(model="scribe_v2")
            >>> result = await stt.transcribe_audio("audio.wav", language="en")
        """
        api_key = api_key or get_env("ELEVENLABS_API_KEY")
        if not api_key:
            raise STTConfigurationError(
                "ElevenLabs API Key is missing. Set ELEVENLABS_API_KEY env var or pass api_key."
            )
        provider = ElevenLabsSTTProvider(api_key=api_key, model=model)
        return cls(provider)

    @classmethod
    def from_local_whisper(
        cls,
        model: LocalWhisperSTTModel = "base",
        device: LocalWhisperDevice = "auto",
        compute_type: Optional[LocalWhisperComputeType] = None,
        download_root: Optional[str] = None,
        beam_size: int = 5,
        vad_filter: bool = False,
        vad_parameters: Optional[Dict[str, Any]] = None
    ) -> "STTManager":
        """
        Create STTManager with local Whisper provider (offline, no API costs).
        
        Args:
            model (LocalWhisperSTTModel): Whisper model to use (will be downloaded if not cached).
                Allowed values:
                Multilingual: "tiny" | "base" | "small" | "medium" | "large-v1" | "large-v2" | "large-v3" | "large"
                English-only: "tiny.en" | "base.en" | "small.en" | "medium.en"
                Distilled: "distil-small.en" | "distil-medium.en" | "distil-large-v2" | "distil-large-v3"
                Turbo: "large-v3-turbo" | "turbo"
                Default: "base" (~140MB)
            device (LocalWhisperDevice): Device to run on.
                Allowed values: "cpu", "cuda", "auto"
                Default: "auto"
            compute_type (Optional[LocalWhisperComputeType]): Quantization type.
                Allowed values: "float32", "float16", "int8", "int8_float16"
                Default: None ("float16" for CUDA, "int8" for CPU)
            download_root (Optional[str]): Directory to cache models.
                Default: None (~/.cache/huggingface)
            beam_size (int): Beam search width (1-10).
                Higher = better quality but slower. 1 = fastest greedy decoding.
                Default: 5
            vad_filter (bool): Enable Voice Activity Detection to skip silence.
                Default: False
            vad_parameters (Optional[Dict[str, Any]]): VAD configuration dict.
                Keys:
                - threshold (float): Speech probability threshold between 0-1
                - min_speech_duration_ms (int): Minimum speech duration
                - max_speech_duration_s (float): Maximum speech duration
                - min_silence_duration_ms (int): Minimum silence duration
                - speech_pad_ms (int): Speech padding
                Default: None
        
        Returns:
            STTManager instance configured for local Whisper.
            
        Raises:
            ImportError: If faster-whisper is not installed.
            UnsupportedLocalModelError: If model not in allowed list.
            
        Example:
            >>> stt = STTManager.from_local_whisper(
            ...     model="medium",
            ...     device="cuda",
            ...     vad_filter=True,
            ...     beam_size=7
            ... )
            >>> result = await stt.transcribe_audio("audio.wav", language="en")
        """
        provider = LocalWhisperSTTProvider(
            model=model,
            device=device,
            compute_type=compute_type,
            download_root=download_root,
            beam_size=beam_size,
            vad_filter=vad_filter,
            vad_parameters=vad_parameters
        )
        return cls(provider)

    @classmethod
    def from_local_moonshine(
        cls,
        model: LocalMoonshineSTTModel = "base",
        language: LocalMoonshineLanguage = "en",
        download_root: Optional[str] = None,
        vad_threshold: Optional[float] = None,
        vad_max_segment_duration: Optional[float] = None,
        identify_speakers: bool = False
    ) -> "STTManager":
        """
        Create STTManager with local Moonshine provider (offline, no API costs).
        
        Moonshine is optimized for live streaming and low-latency applications,
        offering excellent accuracy with lower latency than Whisper.
        
        Args:
            model (LocalMoonshineSTTModel): Moonshine model to use.
                Allowed values:
                - "tiny": Smallest model (~26MB), fastest
                - "tiny-streaming": Tiny with streaming support (~34MB)
                - "base": Good balance (~58MB) - Default
                - "small-streaming": Better accuracy with streaming (~123MB)
                - "medium-streaming": Best accuracy, beats Whisper Large v3 (~245MB)
            language (LocalMoonshineLanguage): Language code for transcription.
                Allowed values: "en", "ar", "ja", "ko", "zh", "es", "uk", "vi"
                Default: "en"
            download_root (Optional[str]): Directory to cache models.
                Default: None (uses platform-specific cache)
            vad_threshold (Optional[float]): Voice Activity Detection threshold (0.0-1.0).
                Lower = more sensitive, longer segments.
                Default: None (uses 0.5)
            vad_max_segment_duration (Optional[float]): Maximum segment duration in seconds.
                Default: None (uses 15.0)
            identify_speakers (bool): Enable speaker identification (diarization).
                Disabling speeds up processing.
                Default: False
        
        Returns:
            STTManager instance configured for local Moonshine.
            
        Raises:
            ImportError: If moonshine-voice is not installed.
            UnsupportedLocalModelError: If model/language not in allowed list.
            
        Example:
            >>> stt = STTManager.from_local_moonshine(
            ...     model="base",
            ...     language="en",
            ...     vad_threshold=0.4
            ... )
            >>> result = await stt.transcribe_audio("audio.wav")
        """
        provider = LocalMoonshineSTTProvider(
            model=model,
            language=language,
            download_root=download_root,
            vad_threshold=vad_threshold,
            vad_max_segment_duration=vad_max_segment_duration,
            identify_speakers=identify_speakers
        )
        return cls(provider)

    async def close(self) -> None:
        """Cleans up resources used by the STTManager.

        This method should be called when the STTManager is no longer needed
        to close the underlying HTTP client and provider resources.
        """
        await self._http_client.aclose()
        if hasattr(self.provider, 'close'):
            await self.provider.close()

    def _get_audio_files(self, folder_path: str, extensions: List[str], recursive: bool = False) -> List[str]:
        """Gets all audio files from a folder.

        Args:
            folder_path (str): The path to the folder.
            extensions (List[str]): List of file extensions to include (e.g., [".wav", ".mp3"]).
            recursive (bool): Whether to scan subfolders recursively.
                Default: False
        Returns:
            List[str]: List of file paths.
        """
        folder = Path(folder_path)
        audio_files = []
        
        if recursive:
            for ext in extensions:
                audio_files.extend([str(f) for f in folder.rglob(f"*{ext}")])
        else:
            for ext in extensions:
                audio_files.extend([str(f) for f in folder.glob(f"*{ext}")])
        
        return sorted(audio_files)

    async def _validate_audio(self, file_path: str, allowed_extensions: Optional[List[str]] = None) -> Tuple[bool, Optional[str]]:
        """Validates an audio file.

        Args:
            file_path (str): The path to the audio file.
            allowed_extensions (Optional[List[str]]): List of allowed extensions. If None,
                uses DEFAULT_BATCH_EXTENSIONS.
                Default: None

        Returns:
            Tuple[bool, Optional[str]]: A tuple of (is_valid, error_message).
                If valid, returns (True, None). If invalid, returns (False, error_message).
        """
        # Check if file exists
        if not os.path.exists(file_path):
            return False, f"File not found: {file_path}"
        
        # Check if it's a file (not a directory)
        if not os.path.isfile(file_path):
            return False, f"Path is not a file: {file_path}"
        
        # Check if file is readable
        if not os.access(file_path, os.R_OK):
            return False, f"File is not readable: {file_path}"
        
        # Check file extension
        file_ext = Path(file_path).suffix.lower()
        valid_extensions = allowed_extensions if allowed_extensions else self.DEFAULT_BATCH_EXTENSIONS
        if file_ext not in valid_extensions:
            return False, f"Unsupported file format: {file_ext}. Allowed: {', '.join(valid_extensions)}"
        
        # Check file size (must be > 0)
        file_size = os.path.getsize(file_path)
        if file_size == 0:
            return False, f"File is empty: {file_path}"
        
        return True, None

    def _write_output_to_file(self, output_path: str, data: Union[Dict, List[Dict]]) -> None:
        """Writes transcription results to a file.

        Args:
            output_path (str): The path to the output file.
            data (Union[Dict, List[Dict]]): The data to write.
        """
        try:
            output_file = Path(output_path)
            output_file.parent.mkdir(parents=True, exist_ok=True)
            
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            
            logger.info(f"Successfully wrote output to: {output_path}")
        except Exception as e:
            logger.error(f"Failed to write output to {output_path}: {e}")
            raise STTFileError(f"Failed to write output to {output_path}: {e}") from e

    async def transcribe_audio(
        self,
        path: str,
        language: Optional[str] = None,
        temperature: Optional[float] = None,
        batch_process: bool = False,
        batch_extensions: Optional[List[str]] = None,
        recursive: bool = False,
        validate_audio: bool = True,
        output_file: Optional[str] = None
    ) -> Union[Dict[str, Any], List[Dict[str, Any]]]:
        """Transcribes an audio file or batch of audio files using the configured STT provider.

        Args:
            path (str): Either a single file path or a folder path when batch_process=True.
            language (Optional[str]): The language of the audio in ISO-639-1 format
                (e.g., "en" for English, "es" for Spanish). If None, the provider will
                auto-detect the language.
                Default: None
            temperature (Optional[float]): The sampling temperature, between 0 and 1.
                Higher values like 0.8 will make the output more random, while lower
                values like 0.2 will make it more focused and deterministic.
                Default: None
            batch_process (bool): If False, path must be a single audio file.
                If True, path is a folder and all supported files inside will be transcribed.
                Default: False
            batch_extensions (Optional[List[str]]): When batch_process=True, which extensions
                to include (e.g., ['.wav', '.mp3']). If None, uses all supported formats.
                Default: None
            recursive (bool): When batch_process=True, whether to scan subfolders.
                Default: False
            validate_audio (bool): Whether to validate audio files before transcription.
                Default: True
            output_file (Optional[str]): Path to save the transcription results as JSON.
                Default: None

        Returns:
            Union[Dict[str, Any], List[Dict[str, Any]]]: 
                - Single file: {"text": "...", "language": "...", "path": "..."}
                - Batch: [{"path": "...", "text": "...", "language": "...", "error": None}, ...]

        Raises:
            STTFileError: If the audio file/folder is not found or invalid.
            STTTranscriptionError: If there is an error with the STT provider API.
        """
        if batch_process:
            # Batch processing
            if not os.path.isdir(path):
                raise STTFileError(f"Batch processing requires a valid folder path, got: {path}")
            
            extensions = batch_extensions or self.DEFAULT_BATCH_EXTENSIONS
            audio_files = self._get_audio_files(path, extensions, recursive)
            
            if not audio_files:
                logger.warning(f"No audio files found in {path} with extensions {extensions}")
                result = []
            else:
                logger.info(f"Found {len(audio_files)} audio files to process")
                results = []
                
                for file_path in audio_files:
                    file_result = {
                        "path": file_path,
                        "text": None,
                        "language": None,
                        "error": None
                    }
                    
                    try:
                        # Validate if needed
                        if validate_audio:
                            is_valid, error_msg = await self._validate_audio(file_path, extensions)
                            if not is_valid:
                                file_result["error"] = error_msg
                                logger.warning(f"Validation failed for {file_path}: {error_msg}")
                                results.append(file_result)
                                continue
                        
                        # Transcribe
                        single_result = await self._transcribe_single_file(file_path, language, temperature, validate_audio=False)
                        file_result["text"] = single_result["text"]
                        file_result["language"] = single_result.get("language")
                        
                    except Exception as e:
                        file_result["error"] = str(e)
                        logger.error(f"Failed to transcribe {file_path}: {e}")
                    
                    results.append(file_result)
                
                result = results
            
            # Write to file if specified
            if output_file:
                self._write_output_to_file(output_file, result)
            
            return result
        else:
            # Single file processing
            # Warn if batch_extensions is specified without batch_process
            if batch_extensions:
                logger.warning(
                    f"batch_extensions={batch_extensions} specified but batch_process=False. "
                    f"The extension filter will be used for validation."
                )
            
            # Warn if recursive is specified without batch_process
            if recursive:
                logger.warning(
                    "recursive=True specified but batch_process=False. "
                    "This parameter is ignored for single file processing."
                )
            
            result = await self._transcribe_single_file(
                path, language, temperature, validate_audio, 
                allowed_extensions=batch_extensions
            )
            
            # Write to file if specified
            if output_file:
                self._write_output_to_file(output_file, result)
            
            return result

    async def _transcribe_single_file(
        self,
        file_path: str,
        language: Optional[str],
        temperature: Optional[float],
        validate_audio: bool = True,
        allowed_extensions: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """Transcribes a single audio file using the configured provider.

        Args:
            file_path (str): The path to the audio file.
            language (Optional[str]): The language code for transcription.
            temperature (Optional[float]): The sampling temperature.
            validate_audio (bool): Whether to validate the audio file.
                Default: True
            allowed_extensions (Optional[List[str]]): Allowed file extensions for validation.
                Default: None

        Returns:
            Dict[str, Any]: {"text": "...", "language": "...", "path": "..."}

        Raises:
            STTFileError: If validation fails.
            STTTranscriptionError: If transcription fails.
        """
        logger.info(f"Starting transcription for file: {file_path}")
        
        # Validate if needed
        if validate_audio:
            is_valid, error_msg = await self._validate_audio(file_path, allowed_extensions)
            if not is_valid:
                raise STTFileError(error_msg)

        try:
            # Use the provider to transcribe with language, temperature
            result = await self.provider.transcribe(
                file_path=file_path,
                language=language,
                temperature=temperature
            )
            return result
        except Exception as e:
            logger.error(f"Transcription error for {file_path}: {e}", exc_info=True)
            raise STTTranscriptionError(f"Transcription failed: {e}") from e

    async def transcribe_and_post(
        self,
        path: str,
        agent_post_key: str = "message",
        language: Optional[str] = None,
        temperature: Optional[float] = None,
        batch_process: bool = False,
        batch_extensions: Optional[List[str]] = None,
        recursive: bool = False,
        validate_audio: bool = True,
        output_file: Optional[str] = None
    ) -> Tuple[Union[Dict[str, Any], List[Dict[str, Any]]], Optional[Any]]:
        """Transcribes an audio file or batch using the configured provider and posts to agent API.

        Args:
            path (str): Either a single file path or a folder path when batch_process=True.
            agent_post_key (str): The key to use when posting transcriptions to agent API.
                Transcript will be sent under this key in the JSON payload.
                Default: "message"
            language (Optional[str]): The language of the audio in ISO-639-1 format.
                Default: None
            temperature (Optional[float]): The sampling temperature, between 0 and 1.
                Default: None
            batch_process (bool): If False, path is a single file. If True, path is a folder.
                Default: False
            batch_extensions (Optional[List[str]]): File extensions to include in batch mode.
                Default: None
            recursive (bool): Whether to scan subfolders in batch mode.
                Default: False
            validate_audio (bool): Whether to validate audio files before transcription.
                Default: True
            output_file (Optional[str]): Path to save the transcription results as JSON.
                Default: None

        Returns:
            A tuple containing:
            - Union[Dict[str, Any], List[Dict[str, Any]]]: Transcription result(s).
            - Optional[Any]: The JSON response from the agent API, or None if disabled.

        Raises:
            STTError: If any step in the process fails.
        """
        try:
            # Transcribe the audio file(s)
            transcript_result = await self.transcribe_audio(
                path=path,
                language=language,
                temperature=temperature,
                batch_process=batch_process,
                batch_extensions=batch_extensions,
                recursive=recursive,
                validate_audio=validate_audio,
                output_file=output_file
            )

            response = None
            # Post the transcribed text to the agent API if the URL is configured
            if self._agent_api_url:
                if batch_process:
                    # For batch, post all successful transcriptions
                    texts = [r["text"] for r in transcript_result if r["text"] is not None]
                    if texts:
                        response = await self._post_to_agent(texts, agent_post_key)
                else:
                    # For single file, post the text
                    response = await self._post_to_agent(transcript_result["text"], agent_post_key)
            else:
                logger.info("AGENT_API_URL not set, skipping post to agent.")

            return transcript_result, response

        except STTError as e:
            logger.error(
                f"STT Error during processing of {path}: {e}", exc_info=True)
            raise
        except Exception as e:
            logger.error(
                f"An unexpected error occurred during processing of {path}: {e}", exc_info=True)
            raise

    async def _post_to_agent(self, data: Union[str, List[str]], agent_post_key: str) -> Any:
        """Posts the transcribed text to the agent API.

        The text is sent in a JSON payload under the specified key.

        Args:
            data (Union[str, List[str]]): The transcribed text or list of texts to post.
            agent_post_key (str): The key to use in the JSON payload.

        Returns:
            Any: The JSON response from the agent API.

        Raises:
            STTAgentError: If the HTTP request to the agent API fails.
        """
        payload = {agent_post_key: data}
        try:
            logger.info(f"Posting to agent with payload: {payload}")
            response = await self._http_client.post(self._agent_api_url, json=payload)
            response.raise_for_status()  # Raises HTTPError for bad responses (4xx or 5xx)
            logger.info(
                f"Successfully posted to agent. Status: {response.status_code}")
            return response.json()
        except httpx.HTTPError as e:
            logger.error(f"Failed to post to agent API: {e}", exc_info=True)
            raise STTAgentError(f"Failed to post to agent API: {e}") from e