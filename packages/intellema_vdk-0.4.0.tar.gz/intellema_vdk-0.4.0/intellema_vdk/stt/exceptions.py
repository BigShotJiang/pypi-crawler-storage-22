class STTError(Exception):
    """Base exception for all STT-related errors."""
    pass

class STTConfigurationError(STTError):
    """Raised when configuration (API keys, URLs) is missing or invalid."""
    pass

class STTFileError(STTError):
    """Raised when the audio file is not found or inaccessible."""
    pass

class STTTranscriptionError(STTError):
    """Raised when the transcription service (OpenAI) fails."""
    pass

class STTAgentError(STTError):
    """Raised when posting to the agent API fails."""
    pass


class UnsupportedLocalModelError(STTError):
    """Raised when user tries to use an unsupported local model."""
    pass


class ModelNotDownloadedError(STTError):
    """Raised when a local model is not downloaded and user declines download."""
    pass