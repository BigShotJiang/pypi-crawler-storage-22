"""STT Provider implementations."""

from .base import STTProvider
from .openai import (
    OpenAISTTProvider,
    OpenAISTTConfig,
    OpenAISTTModel,
    OpenAISTTLanguage,
)
from .elevenlabs import (
    ElevenLabsSTTProvider,
    ElevenLabsSTTConfig,
    ElevenLabsSTTModel,
)
from .local_whisper import (
    LocalWhisperSTTProvider,
    LocalWhisperSTTConfig,
    LocalWhisperDevice,
    LocalWhisperComputeType,
    LocalWhisperSTTModel,
    VADParameters,
    ALLOWED_WHISPER_MODELS,
    MODEL_SIZES,
)
from .local_moonshine import (
    LocalMoonshineSTTProvider,
    LocalMoonshineSTTConfig,
    LocalMoonshineSTTModel,
    LocalMoonshineLanguage,
    ALLOWED_MOONSHINE_MODELS,
    MOONSHINE_MODEL_SIZES,
)

__all__ = [
    # Base Protocol
    "STTProvider",
    # OpenAI Provider
    "OpenAISTTProvider",
    "OpenAISTTConfig",
    "OpenAISTTModel",
    "OpenAISTTLanguage",
    # ElevenLabs Provider
    "ElevenLabsSTTProvider",
    "ElevenLabsSTTConfig",
    "ElevenLabsSTTModel",
    # Local Whisper Provider
    "LocalWhisperSTTProvider",
    "LocalWhisperSTTConfig",
    "LocalWhisperSTTModel",
    "LocalWhisperDevice",
    "LocalWhisperComputeType",
    "VADParameters",
    "ALLOWED_WHISPER_MODELS",
    "MODEL_SIZES",
    # Local Moonshine Provider
    "LocalMoonshineSTTProvider",
    "LocalMoonshineSTTConfig",
    "LocalMoonshineSTTModel",
    "LocalMoonshineLanguage",
    "ALLOWED_MOONSHINE_MODELS",
    "MOONSHINE_MODEL_SIZES",
]
