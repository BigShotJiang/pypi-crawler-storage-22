"""Base protocol and type definitions for STT providers."""

from typing import Protocol, runtime_checkable, Optional, Dict, Any


@runtime_checkable
class STTProvider(Protocol):
    """
    Protocol defining the interface for Speech-to-Text providers.
    
    All STT providers must implement the transcribe method to convert
    audio files to text.
    """

    async def transcribe(
        self,
        file_path: str,
        language: Optional[str] = None,
        temperature: Optional[float] = None
    ) -> Dict[str, Any]:
        """
        Transcribe an audio file to text.
        
        Args:
            file_path: Path to the audio file to transcribe.
            language: The language code for transcription (optional).
            temperature: Sampling temperature between 0 and 1 (optional).
            
        Returns:
            A dictionary containing:
                - text: The transcribed text
                - language: The detected/specified language (optional)
                - path: The original file path
            
        Raises:
            Exception: If the STT API call fails.
        """
        ...
