"""ElevenLabs STT provider implementation."""

import os
import logging
from typing import Optional, Dict, Any, Literal, TypedDict

from .base import STTProvider

logger = logging.getLogger(__name__)


# ElevenLabs-specific type definitions

ElevenLabsSTTModel = Literal["scribe_v1", "scribe_v1_experimental", "scribe_v2"]


class ElevenLabsSTTConfig(TypedDict, total=False):
    """Configuration options for ElevenLabs STT provider."""
    model: ElevenLabsSTTModel
    language: Optional[str]


class ElevenLabsSTTProvider(STTProvider):
    """
    ElevenLabs STT provider implementation.
    
    Uses the ElevenLabs API to transcribe audio files with high accuracy.
    Supports multiple models including multilingual and English-only variants.
    
    Attributes:
        client: The ElevenLabs AsyncElevenLabs client instance.
    
    Example:
        >>> import asyncio
        >>> provider = ElevenLabsSTTProvider(
        ...     api_key="your-api-key",
        ...     model="scribe_v1"
        ... )
        >>> result = asyncio.run(provider.transcribe(
        ...     "audio.wav",
        ...     language="en",
        ...     temperature=0.5
        ... ))
        >>> print(result["text"])
    """

    def __init__(
        self,
        api_key: str,
        model: ElevenLabsSTTModel = "scribe_v1"
    ) -> None:
        """
        Initialize the ElevenLabs STT provider.
        
        Args:
            api_key: ElevenLabs API key for authentication.
            model: Model to use for transcription. Default: "scribe_v1"
                Options:
                    - "scribe_v1": Production-ready multilingual model
                    - "scribe_v1_experimental": Experimental features (may change)
                    - "scribe_v2": Latest version with improvements
        
        Raises:
            ImportError: If the elevenlabs package is not installed.
        """
        try:
            from elevenlabs.client import AsyncElevenLabs
        except ImportError:
            import subprocess
            import sys
            print("ElevenLabs SDK is not installed. Installing now...")
            print("Run: pip install intellema-vdk[stt]")
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", "elevenlabs>=1.0.0"])
                from elevenlabs.client import AsyncElevenLabs
                print("✓ ElevenLabs SDK installed successfully!")
            except Exception as e:
                raise ImportError(
                    "Failed to install elevenlabs. Please install manually:\n"
                    "  pip install intellema-vdk[stt]\n"
                    "or:\n"
                    "  pip install elevenlabs>=1.0.0"
                ) from e
        
        self.api_key = api_key
        self.model = model
        self.client = AsyncElevenLabs(api_key=api_key)

    async def transcribe(
        self,
        file_path: str,
        language: Optional[str] = None,
        temperature: Optional[float] = None
    ) -> Dict[str, Any]:
        """
        Transcribe an audio file using ElevenLabs Scribe models.
        
        Args:
            file_path: Path to the audio file to transcribe.
            language: The language code (ISO-639-1 or ISO-639-3).
                If None, language will be auto-detected.
            temperature: Sampling temperature between 0 and 1.
                Higher values make output more random. Will be scaled to 0-2 for ElevenLabs API.
            
        Returns:
            Dictionary containing transcription result:
                - text: The transcribed text
                - language: The detected/specified language
                - path: The original file path
                
        Raises:
            Exception: If the ElevenLabs API call fails.
            FileNotFoundError: If the audio file doesn't exist.
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Audio file not found: {file_path}")
        
        try:
            # ElevenLabs API call for speech-to-text
            with open(file_path, "rb") as audio_file:
                transcription_params = {
                    "model_id": self.model,
                    "file": audio_file
                }
                if language:
                    transcription_params["language_code"] = language
                if temperature is not None:
                    # Scale temperature from 0-1 to 0-2 for ElevenLabs API
                    transcription_params["temperature"] = temperature * 2.0
                
                # Call the ElevenLabs transcription endpoint
                response = await self.client.speech_to_text.convert(**transcription_params)
            
            # Extract text from response
            if hasattr(response, "text"):
                text = response.text
            elif isinstance(response, dict):
                text = response.get("text", "")
            else:
                text = str(response)
            
            logger.info(f"Successfully transcribed file: {file_path}")
            
            return {
                "text": text,
                "language": language,
                "path": file_path
            }
        except Exception as e:
            logger.error(f"ElevenLabs transcription error: {e}", exc_info=True)
            raise

    async def close(self) -> None:
        """Clean up resources used by the provider."""
        # ElevenLabs client doesn't require explicit cleanup
        pass
