"""Local Moonshine STT provider using moonshine-voice."""

import os
import sys
import logging
from typing import Optional, Dict, Any, Literal, TypedDict, get_args
from pathlib import Path
import asyncio

from .base import STTProvider

logger = logging.getLogger(__name__)


LocalMoonshineSTTModel = Literal[
    # English models
    "tiny", "tiny-streaming", "base", "small-streaming", "medium-streaming",
]

LocalMoonshineLanguage = Literal[
    "en", "ar", "ja", "ko", "zh", "es", "uk", "vi"
]


ALLOWED_MOONSHINE_MODELS = list(get_args(LocalMoonshineSTTModel))
MOONSHINE_MODEL_SIZES = {
    "tiny": "~26MB",
    "tiny-streaming": "~34MB",
    "base": "~58MB",
    "small-streaming": "~123MB",
    "medium-streaming": "~245MB",
}

# Languages supported by Moonshine with base models
ALLOWED_MOONSHINE_LANGUAGES = list(get_args(LocalMoonshineLanguage))
LANGUAGE_NAMES = {
    "en": "English",
    "ar": "Arabic", 
    "ja": "Japanese",
    "ko": "Korean",
    "zh": "Mandarin",
    "es": "Spanish",
    "uk": "Ukrainian",
    "vi": "Vietnamese",
}


class LocalMoonshineSTTConfig(TypedDict, total=False):
    """Configuration options for Local Moonshine STT provider."""
    model: LocalMoonshineSTTModel
    language: LocalMoonshineLanguage
    download_root: Optional[str]


class LocalMoonshineSTTProvider(STTProvider):
    """
    Local Moonshine STT provider using moonshine-voice.
    
    Runs Moonshine models locally without API calls. Optimized for live streaming
    and low-latency applications with excellent accuracy.
    
    Features:
        - No API costs
        - Offline capable
        - Optimized for live/streaming speech
        - Lower latency than Whisper
        - Flexible input windows (no 30s requirement)
        - Speaker identification (diarization)
        - Multiple language models
    
    Attributes:
        transcriber: The Moonshine Transcriber instance.
        model_name: Name of the loaded model.
        language: Language being used.
    
    Example:
        >>> import asyncio
        >>> provider = LocalMoonshineSTTProvider(
        ...     model="base",
        ...     language="en",
        ...     vad_threshold=0.5,
        ...     identify_speakers=False
        ... )
        >>> result = asyncio.run(provider.transcribe(
        ...     "audio.wav"
        ... ))
        >>> print(result["text"])
    """

    def __init__(
        self,
        model: LocalMoonshineSTTModel = "base",
        language: LocalMoonshineLanguage = "en",
        download_root: Optional[str] = None,
        vad_threshold: Optional[float] = None,
        vad_max_segment_duration: Optional[float] = None,
        identify_speakers: bool = False,
    ) -> None:
        """
        Initialize the Moonshine STT provider.
        
        Args:
            model: Model size to use. Options:
                - "tiny": Smallest model (~26MB), fastest, basic accuracy
                - "tiny-streaming": Tiny with streaming support (~34MB)
                - "base": Good balance of speed/accuracy (~58MB) - Default
                - "small-streaming": Better accuracy with streaming (~123MB)
                - "medium-streaming": Best accuracy, beats Whisper Large v3 (~245MB)
            language: Language code for transcription. Options:
                - "en": English (default)
                - "ar": Arabic
                - "ja": Japanese
                - "ko": Korean
                - "zh": Mandarin Chinese
                - "es": Spanish
                - "uk": Ukrainian
                - "vi": Vietnamese
            download_root: Directory to cache models. If None, uses default
                Moonshine cache (platform-specific cache directory).
            vad_threshold: Voice Activity Detection threshold (0.0-1.0).
                Lower = more sensitive, longer segments. Default: 0.5
            vad_max_segment_duration: Maximum segment duration in seconds
                before forced completion. Default: 15.0
            identify_speakers: Enable speaker identification (diarization).
                Default: False (speeds up processing when disabled)
        
        Raises:
            ImportError: If moonshine-voice is not installed.
            UnsupportedLocalModelError: If model is not in allowed list.
            ModelNotDownloadedError: If model needs download and user declines.
        """
        from ..exceptions import UnsupportedLocalModelError, ModelNotDownloadedError
        
        # Validate model
        if model not in ALLOWED_MOONSHINE_MODELS:
            raise UnsupportedLocalModelError(
                f"Model '{model}' is not supported. "
                f"Allowed models: {', '.join(ALLOWED_MOONSHINE_MODELS)}"
            )
        
        # Validate language
        if language not in ALLOWED_MOONSHINE_LANGUAGES:
            raise UnsupportedLocalModelError(
                f"Language '{language}' is not supported. "
                f"Allowed languages: {', '.join(ALLOWED_MOONSHINE_LANGUAGES)}"
            )
        
        # Import and check for moonshine-voice
        try:
            from moonshine_voice import (
                get_model_for_language,
                string_to_model_arch,
                ModelArch,
                load_wav_file
            )
            from moonshine_voice.transcriber import Transcriber
        except ImportError:
            import subprocess
            import sys
            
            print("moonshine-voice is not installed. Installing now...")
            print("Run: pip install intellema-vdk[stt]")

            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", "moonshine-voice"])
                from moonshine_voice import (
                    get_model_for_language,
                    string_to_model_arch,
                    ModelArch,
                    load_wav_file
                )
                from moonshine_voice.transcriber import Transcriber
                print("✓ moonshine-voice installed successfully!\n")
            except Exception as e:
                raise ImportError(
                    "Failed to install moonshine-voice. "
                    "Please install manually: pip install moonshine-voice"
                ) from e
        
        # Store the load_wav_file function for later use
        self._load_wav_file = load_wav_file
        
        # Determine model size
        model_size = MOONSHINE_MODEL_SIZES.get(model, "unknown size")
        
        # Determine cache directory
        # Priority: 1) download_root param, 2) existing env var, 3) platform default
        if download_root:
            cache_dir = os.path.abspath(download_root)
            os.environ["MOONSHINE_VOICE_CACHE"] = cache_dir
        elif os.environ.get("MOONSHINE_VOICE_CACHE"):
            cache_dir = os.environ["MOONSHINE_VOICE_CACHE"]
        else:
            # Default moonshine cache location (moonshine-voice uses platformdirs)
            try:
                from platformdirs import user_cache_dir
                cache_dir = user_cache_dir("moonshine_voice")
            except ImportError:
                # Fallback to known platform-specific paths
                if os.name == 'nt':  # Windows
                    cache_dir = os.path.join(
                        os.environ.get('LOCALAPPDATA', ''),
                        'moonshine_voice', 'moonshine_voice', 'Cache'
                    )
                else:  # Linux/Mac
                    cache_dir = os.path.join(str(Path.home()), '.cache', 'moonshine_voice')
        
        # Check if model already exists in the cache directory that will actually be used
        # Moonshine stores models as: {cache_dir}/download.moonshine.ai/model/{model}-{language}/
        model_dir = os.path.join(cache_dir, 'download.moonshine.ai', 'model', f'{model}-{language}')
        model_exists = os.path.isdir(model_dir) and len(os.listdir(model_dir)) > 0
        
        if not model_exists:
            print(f"\nModel '{model}' ({model_size}) not found locally.")
            print(f"It will be downloaded from the Moonshine repository.")
            print(f"Cache location: {cache_dir}")
            
            response = input(f"\nDownload model '{model}' now? [y/n]: ").strip().lower()
            
            if response == 'n':
                raise ModelNotDownloadedError(
                    f"Model '{model}' download declined. "
                    f"The model will be downloaded automatically on first transcription."
                )
        
        # Load the model
        logger.info(f"Loading Moonshine model '{model}' for language '{language}'")
        
        try:
            # Convert model string to ModelArch enum
            model_arch_int = string_to_model_arch(model)
            wanted_arch = ModelArch(model_arch_int)
            
            # Download model and get path
            if not model_exists:
                print(f"Downloading model '{model}' ({model_size}) for {LANGUAGE_NAMES.get(language, language)}...")
            model_path, result_arch = get_model_for_language(
                wanted_language=language,
                wanted_model_arch=wanted_arch
            )
            if not model_exists:
                print(f"\n✓ Model '{model}' downloaded successfully!\n")
            
            # Build options dict
            options: Dict[str, Any] = {}
            if vad_threshold is not None:
                options["vad_threshold"] = str(vad_threshold)
            if vad_max_segment_duration is not None:
                options["vad_max_segment_duration"] = str(vad_max_segment_duration)
            if not identify_speakers:
                options["identify_speakers"] = "false"
            
            # Create transcriber - use the returned arch which is an int
            self.transcriber = Transcriber(
                model_path=model_path,
                model_arch=ModelArch(result_arch),
                options=options if options else None
            )
            
            self.model_name = model
            self.language = language
            logger.info(f"Successfully loaded Moonshine model '{model}'")
            
        except Exception as e:
            logger.error(f"Failed to load Moonshine model '{model}': {e}", exc_info=True)
            raise

    async def transcribe(
        self,
        file_path: str,
        language: Optional[str] = None,
        temperature: Optional[float] = None
    ) -> Dict[str, Any]:
        """
        Transcribe an audio file using local Moonshine model.
        
        This provider runs Moonshine models locally without API calls, offering
        offline capability, no costs, and optimized streaming/low-latency performance.
        
        Supported Audio Formats:
            Any format supported by the system: .wav, .mp3, .m4a, .flac, .ogg, etc.
        
        Args:
            file_path: Path to the audio file to transcribe.
            language: Language code (ignored - uses language set during init).
                Moonshine uses language-specific models, so language is set
                at initialization time.
            temperature: Temperature parameter (not used by Moonshine).
                Included for API compatibility.
            
        Returns:
            Dictionary containing:
                - text (str): The complete transcribed text
                - language (str): The language code used
                - path (str): The original audio file path
                
        Raises:
            FileNotFoundError: If the audio file doesn't exist.
            Exception: If transcription fails (corrupted audio, etc.).
            
        Example:
            >>> provider = LocalMoonshineSTTProvider(
            ...     model="base",
            ...     language="en"
            ... )
            >>> result = await provider.transcribe("interview.wav")
            >>> print(result["text"])
        
        Performance Tips:
            - Use language-specific models for best accuracy
            - Smaller models (tiny/base) for speed, larger for accuracy
            - Medium-streaming achieves better accuracy than Whisper Large v3
            - Disable speaker identification for faster processing
            - Moonshine is optimized for live speech with lower latency
        
        Note:
            - This method runs asynchronously using asyncio.to_thread()
            - First transcription downloads the model if not cached
            - Models cached in platform-specific cache directory
            - No internet required after model download
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Audio file not found: {file_path}")
        
        try:
            logger.info(f"Transcribing file: {file_path}")
            
            # Run transcription in a separate thread to avoid blocking
            result = await asyncio.to_thread(
                self._transcribe_sync, file_path
            )
            
            logger.info(f"Successfully transcribed file: {file_path}")
            return result
            
        except Exception as e:
            logger.error(f"Moonshine transcription error: {e}", exc_info=True)
            raise

    def _transcribe_sync(self, file_path: str) -> Dict[str, Any]:
        """Synchronous transcription helper."""
        # Check if the file is a WAV file - use moonshine's native loader
        file_ext = os.path.splitext(file_path)[1].lower()
        
        if file_ext == '.wav':
            # Load the WAV file directly using moonshine's native loader
            audio_data, sample_rate = self._load_wav_file(file_path)
        else:
            # For non-WAV formats, try soundfile (supports MP3, FLAC, OGG, etc.)
            audio_data, sample_rate = self._load_audio_with_soundfile(file_path)
        
        # Resample to 16kHz if needed (moonshine expects 16kHz)
        if sample_rate != 16000:
            audio_data = self._resample_audio(audio_data, sample_rate, 16000)
            sample_rate = 16000
        
        # Use the simpler non-streaming transcription method
        transcript = self.transcriber.transcribe_without_streaming(
            audio_data=audio_data,
            sample_rate=sample_rate
        )
        
        # Extract text from all lines in the transcript
        full_text = []
        for line in transcript.lines:
            if line.text:
                full_text.append(line.text.strip())
        
        return {
            "text": " ".join(full_text).strip(),
            "language": self.language,
            "path": file_path,
        }

    def _load_audio_with_soundfile(self, file_path: str) -> tuple:
        """Load audio file using soundfile library (supports MP3, FLAC, OGG, etc.)."""
        import subprocess
        import sys
        
        # Try to import soundfile, auto-install if missing
        try:
            import soundfile as sf
        except ImportError:
            print("soundfile is not installed. Installing now...")
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", "soundfile"])
                import soundfile as sf
                print("✓ soundfile installed successfully!\n")
            except Exception as e:
                raise ImportError(
                    "Failed to install soundfile. "
                    "Please install manually: pip install soundfile"
                ) from e
        
        # Read audio file
        audio_data, sample_rate = sf.read(file_path, dtype='float32')
        
        # Convert to mono if stereo
        if len(audio_data.shape) > 1:
            audio_data = audio_data.mean(axis=1)
        
        # Convert to list of floats as expected by moonshine
        return audio_data.tolist(), sample_rate

    def _resample_audio(self, audio_data: list, orig_sr: int, target_sr: int) -> list:
        """Resample audio data to target sample rate."""
        import numpy as np
        
        if orig_sr == target_sr:
            return audio_data
        
        # Simple linear interpolation resampling
        audio_array = np.array(audio_data, dtype=np.float32)
        duration = len(audio_array) / orig_sr
        target_length = int(duration * target_sr)
        
        # Use numpy interpolation
        x_old = np.linspace(0, duration, len(audio_array))
        x_new = np.linspace(0, duration, target_length)
        resampled = np.interp(x_new, x_old, audio_array)
        
        return resampled.tolist()

    async def close(self) -> None:
        """Clean up resources used by the provider."""
        self._cleanup()

    def _cleanup(self) -> None:
        """Synchronous cleanup helper.
        
        Note: moonshine-voice's native transcriber.close() can trigger
        Windows access violations (structured exceptions) that crash the
        process. On Windows we skip calling close() and just dereference
        the transcriber, letting Python's GC handle resource release.
        """
        if hasattr(self, 'transcriber') and self.transcriber is not None:
            if sys.platform != "win32":
                try:
                    self.transcriber.close()
                except Exception:
                    pass
            try:
                self.transcriber._handle = None
            except Exception:
                pass
            self.transcriber = None

    def __del__(self) -> None:
        """Ensure resources are freed even if close() was not called."""
        self._cleanup()
