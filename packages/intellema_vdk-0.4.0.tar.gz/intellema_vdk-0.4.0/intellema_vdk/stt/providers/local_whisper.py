"""Local Whisper STT provider using faster-whisper."""

import os
import logging
from typing import Optional, Dict, Any, Literal, TypedDict, get_args
from pathlib import Path
import asyncio

from .base import STTProvider

logger = logging.getLogger(__name__)


LocalWhisperSTTModel = Literal[
    # Multilingual models
    "tiny", "base", "small", "medium", "large-v1", "large-v2", "large-v3", "large",
    # English-only models
    "tiny.en", "base.en", "small.en", "medium.en",
    # Distilled models
    "distil-small.en", "distil-medium.en", "distil-large-v2", "distil-large-v3",
    # Turbo models
    "large-v3-turbo", "turbo"
]
LocalWhisperDevice = Literal["cpu", "cuda", "auto"]
LocalWhisperComputeType = Literal["float32", "float16", "int8", "int8_float16"]


ALLOWED_WHISPER_MODELS = list(get_args(LocalWhisperSTTModel))
MODEL_SIZES = {
    "tiny": "~75MB",
    "tiny.en": "~75MB",
    "base": "~140MB",
    "base.en": "~140MB",
    "small": "~480MB",
    "small.en": "~480MB",
    "distil-small.en": "~250MB",
    "medium": "~1.5GB",
    "medium.en": "~1.5GB",
    "distil-medium.en": "~600MB",
    "large-v1": "~3GB",
    "large-v2": "~3GB",
    "large-v3": "~3GB",
    "large": "~3GB",
    "distil-large-v2": "~800MB",
    "distil-large-v3": "~800MB",
    "large-v3-turbo": "~1.6GB",
    "turbo": "~1.6GB",
}


class LocalWhisperSTTConfig(TypedDict, total=False):
    """Configuration options for Local Whisper STT provider."""
    model: LocalWhisperSTTModel
    device: LocalWhisperDevice
    compute_type: Optional[LocalWhisperComputeType]
    download_root: Optional[str]


class VADParameters(TypedDict, total=False):
    """Voice Activity Detection parameters."""
    threshold: float  # Speech probability threshold (0.0-1.0)
    min_speech_duration_ms: int
    max_speech_duration_s: float
    min_silence_duration_ms: int
    speech_pad_ms: int


class LocalWhisperSTTProvider(STTProvider):
    """
    Local Whisper STT provider using faster-whisper.
    
    Runs Whisper models locally without API calls. Uses CTranslate2 backend
    for fast inference with quantization support.
    
    Features:
        - No API costs
        - Offline capable
        - GPU acceleration support
        - Voice Activity Detection (VAD)
        - Word-level timestamps
        - Multiple model sizes
    
    Attributes:
        model: The faster-whisper WhisperModel instance.
        model_name: Name of the loaded model.
        device: Device being used (cpu/cuda).
    
    Example:
        >>> import asyncio
        >>> provider = LocalWhisperSTTProvider(
        ...     model="base",
        ...     device="auto",
        ...     compute_type="float16",
        ...     beam_size=5,
        ...     vad_filter=True
        ... )
        >>> result = asyncio.run(provider.transcribe(
        ...     "audio.wav",
        ...     language="en"
        ... ))
        >>> print(result["text"])
    """

    def __init__(
        self,
        model: LocalWhisperSTTModel = "base",
        device: LocalWhisperDevice = "auto",
        compute_type: Optional[LocalWhisperComputeType] = None,
        download_root: Optional[str] = None,
        beam_size: int = 5,
        vad_filter: bool = False,
        vad_parameters: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Initialize the Local Whisper STT provider.
        
        Args:
            model: Model size to use. Options:
                - Multilingual: "tiny", "base", "small", "medium", "large-v1", "large-v2", "large-v3", "large"
                - English-only: "tiny.en", "base.en", "small.en", "medium.en"
                - Distilled: "distil-small.en", "distil-medium.en", "distil-large-v2", "distil-large-v3"
                - Turbo: "large-v3-turbo", "turbo"
                - Default: "base"
            device: Device to run on - "cpu", "cuda", or "auto".
            compute_type: Quantization type. If None, uses defaults:
                - CPU: "int8"
                - CUDA: "float16"
            download_root: Directory to cache models. If None, uses default
                Hugging Face cache (~/.cache/huggingface).
            beam_size: Beam search width for decoding. Default: 5
                Range: 1-10 (higher = better quality but slower)
                - 1 = Greedy decoding (fastest, lower quality)
                - 5 = Good balance (recommended)
                - 10 = Best quality (slowest)
            vad_filter: Enable Voice Activity Detection. Default: False
                When True, automatically skips silent portions of audio.
                Significantly speeds up transcription for audio with pauses.
            vad_parameters: VAD configuration dictionary. Default: None
                Only used when vad_filter=True. Options:
                    - threshold (float): Speech probability threshold (0.0-1.0)
                    - min_speech_duration_ms (int): Min speech segment duration
                    - max_speech_duration_s (float): Max speech segment duration
                    - min_silence_duration_ms (int): Min silence to split on
                    - speech_pad_ms (int): Padding around speech segments
        
        Raises:
            ImportError: If faster-whisper is not installed.
            UnsupportedLocalModelError: If model is not in allowed list.
            ModelNotDownloadedError: If model needs download and user declines.
        """
        from ..exceptions import UnsupportedLocalModelError, ModelNotDownloadedError
        
        # Validate model
        if model not in ALLOWED_WHISPER_MODELS:
            raise UnsupportedLocalModelError(
                f"Model '{model}' is not supported. "
                f"Allowed models: {', '.join(ALLOWED_WHISPER_MODELS)}"
            )
        
        # Import and check for faster-whisper
        try:
            from faster_whisper import WhisperModel
        except ImportError:
            import subprocess
            import sys
            
            print("faster-whisper is not installed. Installing now...")
            print("Run: pip install intellema-vdk[stt]")

            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", "faster-whisper"])
                from faster_whisper import WhisperModel
                print("✓ faster-whisper installed successfully!\n")
            except Exception as e:
                raise ImportError(
                    "Failed to install faster-whisper. "
                    "Please install manually: pip install faster-whisper"
                ) from e
        
        # Determine device
        if device == "auto":
            try:
                import torch
                device = "cuda" if torch.cuda.is_available() else "cpu"
            except ImportError:
                device = "cpu"
        
        # Set default compute_type based on device
        if compute_type is None:
            compute_type = "float16" if device == "cuda" else "int8"
        
        # Check if model is already downloaded
        model_size = MODEL_SIZES.get(model, "unknown size")
        cache_dir = download_root or os.path.join(Path.home(), ".cache", "huggingface", "hub")
        
        # Check if model exists in cache (simple check)
        model_path = os.path.join(cache_dir, f"models--Systran--faster-whisper-{model}")
        model_exists = os.path.exists(model_path)
        
        if not model_exists:
            print(f"\nModel '{model}' ({model_size}) not found locally.")
            print(f"It will be downloaded from Hugging Face on first use.")
            print(f"Cache location: {cache_dir}")
            
            response = input(f"\nDownload model '{model}' now? [y/n]: ").strip().lower()
            
            if response == 'n':
                raise ModelNotDownloadedError(
                    f"Model '{model}' download declined. "
                    f"The model will be downloaded automatically on first transcription."
                )
        
        logger.info(f"Loading Whisper model '{model}' on device '{device}' with compute_type '{compute_type}'")
        
        try:
            # Enable progress bar for model downloads
            if not model_exists:
                print(f"Downloading model '{model}' ({model_size})...")
            self.model = WhisperModel(
                model,
                device=device,
                compute_type=compute_type,
                download_root=download_root
            )
            
            if not model_exists:
                print(f"\n✓ Model '{model}' downloaded successfully!\n")
            
            self.model_name = model
            self.device = device
            self.beam_size = beam_size
            self.vad_filter = vad_filter
            self.vad_parameters = vad_parameters
            logger.info(f"Successfully loaded model '{model}'")
        except Exception as e:
            logger.error(f"Failed to load model '{model}': {e}", exc_info=True)
            raise

    async def transcribe(
        self,
        file_path: str,
        language: Optional[str] = None,
        temperature: float = 0.0
    ) -> Dict[str, Any]:
        """
        Transcribe an audio file using local Whisper model via faster-whisper.
        
        This provider runs Whisper models locally without API calls, offering
        offline capability, no costs, and advanced features like VAD.
        Uses CTranslate2 for optimized inference.
        
        Supported Audio Formats:
            Any format supported by ffmpeg: .wav, .mp3, .m4a, .flac, .ogg, etc.
        
        Args:
            file_path: Path to the audio file to transcribe.
            language: ISO-639-1 language code (e.g., "en", "es", "fr").
                Specifying language improves accuracy and speed.
                If None, language will be auto-detected (slower).
            temperature: Sampling temperature for generation. Default: 0.0
                Range: 0.0-1.0
                - 0.0 = Deterministic (most consistent, recommended)
                - Higher = More random/creative outputs
            
        Returns:
            Dictionary containing:
                - text (str): The complete transcribed text
                - language (str): The detected or specified language code
                - path (str): The original audio file path
                
        Raises:
            FileNotFoundError: If the audio file doesn't exist.
            UnsupportedLocalModelError: If model name not in ALLOWED_WHISPER_MODELS.
            ModelNotDownloadedError: If model not downloaded and download declined.
            Exception: If transcription fails (corrupted audio, out of memory, etc.).
            
        Example:
            >>> provider = LocalWhisperSTTProvider(
            ...     model="base",
            ...     device="cuda",
            ...     beam_size=7,
            ...     vad_filter=True
            ... )
            >>> result = await provider.transcribe(
            ...     "interview.wav",
            ...     language="en"
            ... )
            >>> print(result["text"])
        
        Performance Tips:
            - Use English-only models (.en) for English audio (faster)
            - Enable VAD in constructor for audio with long pauses
            - Use smaller models (tiny/base) for speed, larger for accuracy
            - GPU acceleration (CUDA) provides 5-10x speedup
            - Set beam_size=1 in constructor for fastest (greedy) decoding
            - Specify language to avoid auto-detection overhead
        
        Note:
            - This method runs asynchronously using asyncio.to_thread()
            - First transcription downloads the model if not cached
            - Models cached in ~/.cache/huggingface/hub/
            - No internet required after model download
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Audio file not found: {file_path}")
        
        try:
            logger.info(f"Transcribing file: {file_path}")
            
            # Prepare transcription parameters
            transcribe_params = {
                "beam_size": self.beam_size,
                "vad_filter": self.vad_filter,
            }
            
            # Only add temperature if it's not None (faster-whisper doesn't accept None)
            if temperature is not None:
                transcribe_params["temperature"] = temperature
            
            if language:
                transcribe_params["language"] = language
            
            if self.vad_filter and self.vad_parameters:
                transcribe_params["vad_parameters"] = self.vad_parameters
            
            # Run transcription in a separate thread to avoid blocking
            segments, info = await asyncio.to_thread(
                self.model.transcribe, file_path, **transcribe_params
            )
            
            # Collect all text from segments
            full_text = []
            for segment in segments:
                full_text.append(segment.text)
            
            result = {
                "text": " ".join(full_text).strip(),
                "language": info.language if hasattr(info, 'language') else language,
                "path": file_path,
            }
            
            logger.info(f"Successfully transcribed file: {file_path}")
            return result
            
        except Exception as e:
            logger.error(f"Local Whisper transcription error: {e}", exc_info=True)
            raise

    async def close(self) -> None:
        """Clean up resources used by the provider."""
        # faster-whisper doesn't require explicit cleanup
        pass
