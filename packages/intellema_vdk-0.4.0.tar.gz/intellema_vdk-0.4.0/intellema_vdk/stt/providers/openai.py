"""OpenAI Whisper STT provider implementation."""

import os
import logging
from typing import Optional, Dict, Any, Literal, TypedDict

from .base import STTProvider

logger = logging.getLogger(__name__)


# OpenAI-specific type definitions

OpenAISTTModel = Literal[
    "whisper-1",
    "gpt-4o-transcribe-diarize",
    "gpt-4o-transcribe",
    "gpt-4o-mini-transcribe"
]
OpenAISTTLanguage = Literal[
    "en", "es", "fr", "de", "it", "pt", "nl", "pl", "ru", "ja", "ko", "zh", "ar", "hi"
]


class OpenAISTTConfig(TypedDict, total=False):
    """Configuration options for OpenAI Whisper STT provider."""
    model: OpenAISTTModel
    language: Optional[OpenAISTTLanguage]
    temperature: Optional[float]


class OpenAISTTProvider(STTProvider):
    """
    OpenAI Whisper STT provider implementation.
    
    Uses the OpenAI API to transcribe audio files with the Whisper model.
    Supports multiple languages and high-quality transcription.
    
    Attributes:
        client: The OpenAI AsyncOpenAI client instance.
    
    Example:
        >>> import asyncio
        >>> provider = OpenAISTTProvider(
        ...     api_key="your-api-key",
        ...     model="whisper-1"
        ... )
        >>> result = asyncio.run(provider.transcribe(
        ...     "audio.wav",
        ...     language="en"
        ... ))
        >>> print(result["text"])
    """

    def __init__(
        self,
        api_key: str,
        model: OpenAISTTModel = "whisper-1"
    ) -> None:
        """
        Initialize the OpenAI STT provider.
        
        Args:
            api_key: OpenAI API key for authentication.
            model: Model to use for transcription. Default: "whisper-1"
                Options:
                    - "whisper-1": Standard Whisper model (reliable)
                    - "gpt-4o-transcribe": GPT-4o transcription
                    - "gpt-4o-transcribe-diarize": GPT-4o with speaker diarization
                    - "gpt-4o-mini-transcribe": Faster, cheaper GPT-4o variant
        
        Raises:
            ImportError: If the openai package is not installed.
        """
        try:
            from openai import AsyncOpenAI, APIError as _APIError
            self.APIError = _APIError
        except ImportError:
            import subprocess
            import sys
            print("OpenAI SDK is not installed. Installing now...")
            print("Run: pip install intellema-vdk[stt]")
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", "openai>=1.0.0"])
                from openai import AsyncOpenAI, APIError as _APIError
                self.APIError = _APIError
                print("✓ OpenAI SDK installed successfully!")
            except Exception as e:
                raise ImportError(
                    "Failed to install openai. Please install manually:\n"
                    "  pip install intellema-vdk[stt]\n"
                    "or:\n"
                    "  pip install openai>=1.0.0"
                ) from e
        
        self.api_key = api_key
        self.model = model
        self.client = AsyncOpenAI(api_key=api_key)

    async def transcribe(
        self,
        file_path: str,
        language: Optional[str] = None,
        temperature: Optional[float] = None
    ) -> Dict[str, Any]:
        """
        Transcribe an audio file using OpenAI Whisper or GPT-4o models.
        
        Args:
            file_path: Path to the audio file to transcribe.
            language: The language of the audio in ISO-639-1 format.
                If None, language will be auto-detected.
            temperature: The sampling temperature, between 0 and 1.
                Higher values make output more random, lower values more focused.
            
        Returns:
            Dictionary containing transcription result:
                - text: The transcribed text
                - language: The detected/specified language
                - path: The original file path
                
        Raises:
            APIError: If the OpenAI API call fails.
            FileNotFoundError: If the audio file doesn't exist.
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Audio file not found: {file_path}")
        
        try:
            with open(file_path, "rb") as audio_file:
                transcription_params = {
                    "model": self.model,
                    "file": audio_file
                }
                if language:
                    transcription_params["language"] = language
                if temperature is not None:
                    transcription_params["temperature"] = temperature
                
                transcript = await self.client.audio.transcriptions.create(**transcription_params)
            
            logger.info(f"Successfully transcribed file: {file_path}")
            
            return {
                "text": transcript.text,
                "language": language,
                "path": file_path
            }
        except self.APIError as e:
            logger.error(f"OpenAI Whisper transcription error: {e}", exc_info=True)
            raise
        except Exception as e:
            logger.error(f"Unexpected error during transcription: {e}", exc_info=True)
            raise

    async def close(self) -> None:
        """Clean up resources used by the provider."""
        await self.client.close()
