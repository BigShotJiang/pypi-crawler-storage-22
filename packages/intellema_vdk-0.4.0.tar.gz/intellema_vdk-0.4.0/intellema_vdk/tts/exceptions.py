class TTSError(Exception):
    """Base exception for all TTS-related errors."""
    pass

class TTSConfigurationError(TTSError):
    """Raised when configuration (API keys) is missing or invalid."""
    pass

class TTSStreamError(TTSError):
    """Raised when there are issues with the audio stream."""
    pass

class TTSAPIError(TTSError):
    """Raised when the TTS API (Together) returns an error."""
    pass