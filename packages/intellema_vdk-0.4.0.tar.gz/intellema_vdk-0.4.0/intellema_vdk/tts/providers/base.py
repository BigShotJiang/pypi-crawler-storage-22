from typing import Iterator, Protocol, runtime_checkable

@runtime_checkable
class TTSProvider(Protocol):
    """
    Protocol defining the interface for Text-to-Speech providers.
    
    All TTS providers must implement the stream method to generate
    audio from text input.
    """

    def stream(self, text: str) -> Iterator[bytes]:
        """Generate audio data from text input as a stream of bytes."""
        ...