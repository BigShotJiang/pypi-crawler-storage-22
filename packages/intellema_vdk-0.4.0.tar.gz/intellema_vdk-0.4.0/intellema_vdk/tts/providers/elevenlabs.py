"""TTS provider implementations for ElevenLabs."""

from typing import Iterator, Literal, TypedDict
import logging

logger = logging.getLogger(__name__)

ElevenLabsTTSModel = Literal["eleven_monolingual_v1", "eleven_multilingual_v2", "eleven_turbo_v2", "eleven_turbo_v2_5"]
ElevenLabsTTSVoice = Literal["rachel", "domi", "antoni", "bill", "josh", "jessie", "nicole", "bella"]

# Voice IDs required by ElevenLabs API for voice selection
ELEVENLABS_VOICEIDS = {
    "rachel": "21m00Tcm4TlvDq8ikWAM",
    "domi": "AZnzlk1XvdvUeBnXmlld",
    "antoni": "ErXwobaYiN019PkySvjV",
    "bill": "2EiwWnXFnvU5JabPnv8n",
    "josh": "TxGEqnHWrfWFTfGW9XjX",
    "jessie": "t0jbNlBVZ17f02VDIeMI",
    "nicole": "piTKgcLEGmPE4e6mEKli",
    "bella": "EXAVITQu4vr4xnSDxMaL",
}

class ElevenLabsTTSProvider:
    """
    ElevenLabs TTS provider implementation.
    
    Uses the ElevenLabs API to generate high-quality speech from text.
    Supports streaming audio generation.
    
    Attributes
    ----------
    model : ElevenLabsTTSModel
        The TTS model identifier.
    voice : ElevenLabsTTSVoice
        The voice identifier for speech generation.
    client : elevenlabs.client.ElevenLabs
        The ElevenLabs API client instance.
    
    Examples
    --------
    >>> provider = ElevenLabsTTSProvider(
    ...     api_key="your-api-key",
    ...     model="eleven_turbo_v2_5",
    ...     voice="rachel"
    ... )
    >>> for audio_chunk in provider.stream("Hello world"):
    ...     # Process audio chunk
    ...     pass
    """

    def __init__(
        self,
        api_key: str,
        model: ElevenLabsTTSModel = "eleven_turbo_v2_5",
        voice: ElevenLabsTTSVoice = "rachel"
    ) -> None:
        """
        Initialize the ElevenLabs TTS provider.
        
        Parameters
        ----------
        api_key : str
            ElevenLabs API key for authentication.
        model : ElevenLabsTTSModel, optional
            The TTS model to use. Default is "eleven_turbo_v2_5".
            Allowed values: "eleven_monolingual_v1", "eleven_multilingual_v2", "eleven_turbo_v2", "eleven_turbo_v2_5".
        voice : ElevenLabsTTSVoice, optional
            The voice to use for speech generation. Default is "rachel".
            Allowed values: "rachel", "domi", "antoni", "bill", "josh", "jessie", "nicole", "bella".
        
        Raises
        ------
        ImportError
            If the elevenlabs package is not installed.
        """
        try:
            from elevenlabs.client import ElevenLabs
        except ImportError:
            import subprocess
            import sys
            print("ElevenLabs SDK is not installed. Installing now...")
            print("Run: pip install intellema-vdk[tts]")
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", "elevenlabs>=1.0.0"])
                from elevenlabs.client import ElevenLabs
                print("✓ ElevenLabs SDK installed successfully!")
            except Exception as e:
                raise ImportError(
                    "Failed to install elevenlabs. Please install manually:\n"
                    "  pip install intellema-vdk[tts]\n"
                    "or:\n"
                    "  pip install elevenlabs>=1.0.0"
                ) from e
        
        self.api_key = api_key
        self.model = model
        self.voice = voice
        self.client = ElevenLabs(api_key=api_key)

    def stream(self, text: str) -> Iterator[bytes]:
        """
        Stream audio from ElevenLabs API.
        
        Parameters
        ----------
        text : str
            The text to convert to speech.
            
        Yields
        ------
        bytes
            Raw audio bytes in PCM format (via MP3 stream).
            
        Raises
        ------
        Exception
            If the ElevenLabs API call fails.
        """
        try:
            # We use 24kHz PCM to match typical defaults which is usually 24000
            response = self.client.text_to_speech.convert(
                voice_id=ELEVENLABS_VOICEIDS.get(self.voice, self.voice),
                model_id=self.model,
                text=text,
                output_format="pcm_24000"
            )

            for chunk in response:
                if isinstance(chunk, bytes):
                    yield chunk

        except Exception as e:
            logger.error(f"ElevenLabs TTS stream error: {e}", exc_info=True)
            raise