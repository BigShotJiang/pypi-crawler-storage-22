"""TTS provider implementations for Hugging Face."""

from typing import Iterator, Literal, TypedDict, get_args
import logging
import warnings
import subprocess
import sys

logger = logging.getLogger(__name__)

# Hugging Face Configuration    
HuggingFaceTTSModel = Literal["hexgrad/Kokoro-82M", "kyutai/pocket-tts", "FunAudioLLM/CosyVoice2-0.5B"]
HuggingFaceDevice = Literal["cpu", "cuda", "auto"]

VALID_HF_MODELS = list(get_args(HuggingFaceTTSModel))

class HuggingFaceTTSProvider:
    """
    Hugging Face TTS provider implementation.
    
    Uses the transformers library to generate speech.
    Supports local execution of models.
    
    Attributes
    ----------
    model : HuggingFaceTTSModel
        The TTS model identifier.
    device : HuggingFaceDevice
        The device to run the model on.
    pipe : Any
        The underlying pipeline object (Kokoro KPipeline or Transformers pipeline).
    sample_rate : int
        The audio sample rate of the model.

    Examples
    --------
    >>> provider = HuggingFaceTTSProvider(
    ...     model="hexgrad/Kokoro-82M",
    ...     device="cpu"
    ... )
    >>> for audio_chunk in provider.stream("Hello world"):
    ...     # Process audio chunk
    ...     pass
    """


    def __init__(
        self,
        model: HuggingFaceTTSModel = "hexgrad/Kokoro-82M",
        device: HuggingFaceDevice = "cpu"
    ) -> None:
        """
        Initialize the Hugging Face TTS provider.
        
        Parameters
        ----------
        model : HuggingFaceTTSModel, optional
            The TTS model to use. Default is "hexgrad/Kokoro-82M".
            Allowed values: 
            - "hexgrad/Kokoro-82M" (Requires Python >= 3.10 and < 3.13)
            - "kyutai/pocket-tts"
            - "FunAudioLLM/CosyVoice2-0.5B"
        device : HuggingFaceDevice, optional
            Device to run on. Default is "cpu".
            Allowed values: "cpu", "cuda", "auto".
            
        Raises
        ------
        ValueError
            If the model is not supported.
        ImportError
            If required packages (transformers, kokoro, torch, etc.) are not installed.
        Exception
            If the model is not found locally and the user declines the download.
        """
        if model not in VALID_HF_MODELS:
            raise ValueError(f"Invalid model: {model}. Must be one of {VALID_HF_MODELS}")
        
        self.model = model
        self.device = device
            
        self.pipe = None
        self.is_kokoro = "Kokoro" in model

        if self.is_kokoro:
            self._init_kokoro()
        else:
            self._init_transformers()

    def _init_kokoro(self):
        # 0. Check Python version compatibility for Kokoro
        # Kokoro only supports Python >= 3.10 and < 3.13
        # Reference: https://pypi.org/project/kokoro/
        if not (sys.version_info >= (3, 10) and sys.version_info < (3, 13)):
            current_version = f"{sys.version_info.major}.{sys.version_info.minor}"
            warning_msg = (
                f"\n[WARNING] Kokoro TTS model requires Python 3.10 <= version < 3.13.\n"
                f"You are running Python {current_version}.\n"
                f"Use a compatible Python version to ensure stability.\n"
            )
            logger.warning(warning_msg)
            
        # Suppress specific PyTorch warnings that are harmless but noisy in Kokoro
        warnings.filterwarnings("ignore", message=".*dropout option adds dropout.*")
        warnings.filterwarnings("ignore", message=".*weight_norm` is deprecated.*")

        try:
            from kokoro import KPipeline
            import huggingface_hub
        except ImportError:
            print("Kokoro library is not installed. Installing now...")
            print("Run: pip install kokoro")
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", "kokoro>=0.3.0", "soundfile", "huggingface_hub"])
                from kokoro import KPipeline
                import huggingface_hub
                print("✓ Kokoro SDK installed successfully!")
                print("Note: You may need 'espeak-ng' installed on your system for best results.")
            except Exception as e:
                raise ImportError(
                    "Failed to install kokoro. Please install manually:\n"
                    "  pip install kokoro soundfile huggingface_hub"
                ) from e
        
        # Check local availability (Kokoro uses 'hexgrad/Kokoro-82M' by default)
        model_id = "hexgrad/Kokoro-82M"
        try:
            # Check if main model file exists in cache
            # This is a heuristic; robust check would be more complex but this catches "totally missing"
            cached_path = huggingface_hub.try_to_load_from_cache(repo_id=model_id, filename="kokoro-v1_0.pth")
            if not cached_path:
                raise FileNotFoundError("Not cached")
        except Exception:
            print(f"\nModel '{model_id}' not found locally.")
            try:
                choice = input(f"Would you like to download it from Hugging Face? [y/N]: ").strip().lower()
            except EOFError:
                choice = 'n'
                
            if choice != 'y':
                raise Exception(f"Model '{model_id}' is required but not available locally.")
            print(f"Downloading {model_id} and dependencies (this may take a while)...")

        logger.info(f"Initializing Kokoro pipeline ({self.model})...")

        k_device = self.device
        if k_device == "auto":
            k_device = None # Kokoro will auto-detect device
            
        self.pipe = KPipeline(lang_code='a', device=k_device, repo_id=model_id)
        self.sample_rate = 24000 # Kokoro default

    def _init_transformers(self):
        try:
            from transformers import pipeline
        except ImportError:
            print("Transformers is not installed. Installing now...")
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", "transformers>=4.0.0", "torch", "datasets", "soundfile", "accelerate"])
                from transformers import pipeline
                print("✓ Transformers installed successfully!")
            except Exception as e:
                raise ImportError("Failed to install transformers.") from e

        # Check local availability
        is_local = True
        
        tf_device = self.device
        if tf_device == "auto":
            import torch
            tf_device = "cuda" if torch.cuda.is_available() else "cpu"
            
        try:
            # Try to load pipeline with local_files_only=True
            pipeline("text-to-speech", model=self.model, device=tf_device, local_files_only=True, trust_remote_code=True)
        except Exception:
            is_local = False
            
        if not is_local:
            print(f"\nModel '{self.model}' not found locally.")
            try:
                choice = input(f"Would you like to download it from Hugging Face? [y/N]: ").strip().lower()
            except EOFError:
                choice = 'n'
                
            if choice != 'y':
                raise Exception(f"Model '{self.model}' is required but not available locally.")
            print(f"Downloading {self.model} and dependencies (this may take a while)...")
            
        self.pipe = pipeline("text-to-speech", model=self.model, device=tf_device, trust_remote_code=True)
        self.sample_rate = self.pipe.model.config.sampling_rate

    def stream(self, text: str) -> Iterator[bytes]:
        """
        Generate audio from text.
        
        Parameters
        ----------
        text : str
            The text to convert to speech.
            
        Yields
        ------
        bytes
            Raw audio bytes in PCM format (int16).
            
        Raises
        ------
        Exception
            If audio generation fails.
        """
        try:
            if self.is_kokoro:
                # Kokoro KPipeline generator: pipe(text, voice, speed, split_pattern)
                voice = "af_heart" 
                
                generator = self.pipe(
                    text, 
                    voice=voice, 
                    speed=1.0, 
                    split_pattern=r'\n+'
                )
                
                import numpy as np
                import torch
                for _, _, audio_data in generator:
                    # audio_data can be a PyTorch Tensor
                    if isinstance(audio_data, torch.Tensor):
                        audio_data = audio_data.cpu().numpy()
                        
                    # audio_data is float32 numpy array
                    # Clip and convert to int16
                    audio_data = np.clip(audio_data, -1.0, 1.0)
                    audio_int16 = (audio_data * 32767).astype(np.int16)
                    yield audio_int16.tobytes()
            
            else:
                # Standard Transformers Pipeline
                output = self.pipe(text)
                audio_data = output["audio"]
                import numpy as np
                audio_data = np.clip(audio_data, -1.0, 1.0)
                audio_int16 = (audio_data * 32767).astype(np.int16)
                yield audio_int16.tobytes()
            
        except Exception as e:
            logger.error(f"HuggingFace TTS error: {e}", exc_info=True)
            raise