"""TTS provider implementations for OpenAI."""

from typing import Iterator, Literal, TypedDict
import logging

logger = logging.getLogger(__name__)

OpenAITTSModel = Literal["tts-1", "tts-1-hd","gpt-4o-mini-tts", "gpt-4o-mini-tts-2025-12-15"]
OpenAITTSVoice = Literal['alloy', 'ash', 'ballad', 'coral', 'echo', 'sage', 'shimmer', 'verse', 'marin', 'cedar']

class OpenAITTSProvider:
    """
    OpenAI TTS provider implementation.
    
    Uses the OpenAI API to generate high-quality speech from text.
    Supports multiple voices and quality levels.
    
    Attributes
    ----------
    model : OpenAITTSModel
        The TTS model identifier.
    voice : OpenAITTSVoice
        The voice identifier for speech generation.
    client : openai.OpenAI
        The OpenAI API client instance.
    
    Examples
    --------
    >>> provider = OpenAITTSProvider(
    ...     api_key="your-api-key",
    ...     model="tts-1-hd",
    ...     voice="shimmer"
    ... )
    >>> for audio_chunk in provider.stream("Hello world"):
    ...     # Process audio chunk
    ...     pass
    """

    def __init__(
        self,
        api_key: str,
        model: OpenAITTSModel = "tts-1",
        voice: OpenAITTSVoice = "alloy"
    ) -> None:
        """
        Initialize the OpenAI TTS provider.
        
        Parameters
        ----------
        api_key : str
            OpenAI API key for authentication.
        model : OpenAITTSModel, optional
            The TTS model to use. Default is "tts-1".
            Allowed values:
            - "tts-1": Standard quality, lower latency.
            - "tts-1-hd": High definition quality, higher latency.
            - "gpt-4o-mini-tts": GPT-4o mini TTS model (experimental).
            - "gpt-4o-mini-tts-2025-12-15": GPT-4o mini TTS model with 2025-12-15 version (experimental).
        voice : OpenAITTSVoice, optional
            The voice to use for speech generation. Default is "alloy".
            Allowed values: 'alloy', 'ash', 'ballad', 'coral', 'echo', 'sage',
            'shimmer', 'verse', 'marin', 'cedar'.
        
        Raises
        ------
        ImportError
            If the openai package is not installed.
        """
        try:
            from openai import OpenAI
        except ImportError:
            import subprocess
            import sys
            print("OpenAI SDK is not installed. Installing now...")
            print("Run: pip install intellema-vdk[tts]")
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", "openai>=1.0.0"])
                from openai import OpenAI
                print("✓ OpenAI SDK installed successfully!")
            except Exception as e:
                raise ImportError(
                    "Failed to install openai. Please install manually:\n"
                    "  pip install intellema-vdk[tts]\n"
                    "or:\n"
                    "  pip install openai>=1.0.0"
                ) from e
        
        self.api_key = api_key
        self.model = model
        self.voice = voice
        self.client = OpenAI(api_key=api_key)

    def stream(self, text: str) -> Iterator[bytes]:
        """
        Stream audio from OpenAI API.
        
        Parameters
        ----------
        text : str
            The text to convert to speech.
            
        Yields
        ------
        bytes
            Raw audio bytes in PCM format (converted from MP3/Opus).
            
        Raises
        ------
        Exception
            If the OpenAI API call fails.
        """
        try:
            response = self.client.audio.speech.create(
                model=self.model,
                voice=self.voice,
                input=text,
                response_format="pcm"  # Request PCM format directly
            )

            # OpenAI streaming response
            for chunk in response.iter_bytes(chunk_size=4096):
                if chunk:
                    yield chunk

        except Exception as e:
            logger.error(f"OpenAI TTS stream error: {e}", exc_info=True)
            raise