"""TTS provider implementations for Together AI."""

from typing import Iterator, Literal, TypedDict
import logging
from ...config import (
    WAV_HEADER_SIZE
)

logger = logging.getLogger(__name__)

TogetherTTSModel = Literal["canopylabs/orpheus-3b-0.1-ft"]
TogetherTTSVoice = Literal["tara"]

class TogetherTTSProvider:
    """
    Together AI TTS provider implementation.
    
    Uses the Together API to generate speech from text with the Orpheus model.
    Supports streaming audio generation with low latency.
    
    Attributes
    ----------
    model : TogetherTTSModel
        The TTS model identifier.
    voice : TogetherTTSVoice
        The voice identifier for speech generation.
    client : together.Together
        The Together API client instance.
    
    Examples
    --------
    >>> provider = TogetherTTSProvider(
    ...     api_key="your-api-key",
    ...     model="canopylabs/orpheus-3b-0.1-ft",
    ...     voice="tara"
    ... )
    >>> for audio_chunk in provider.stream("Hello world"):
    ...     # Process audio chunk
    ...     pass
    """

    def __init__(
        self, 
        api_key: str, 
        model: TogetherTTSModel = "canopylabs/orpheus-3b-0.1-ft",
        voice: TogetherTTSVoice = "tara"
    ) -> None:
        """
        Initialize the Together TTS provider.
        
        Parameters
        ----------
        api_key : str
            Together API key for authentication.
        model : TogetherTTSModel, optional
            The TTS model to use. Default is "canopylabs/orpheus-3b-0.1-ft".
            Allowed values: "canopylabs/orpheus-3b-0.1-ft".
        voice : TogetherTTSVoice, optional
            The voice to use for speech generation. Default is "tara".
            Allowed values: "tara".
        
        Raises
        ------
        ImportError
            If the together package is not installed.
        """
        try:
            from together import Together
        except ImportError:
            import subprocess
            import sys
            print("Together AI SDK is not installed. Installing now...")
            print("Run: pip install intellema-vdk[tts]")
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", "together>=1.0.0"])
                from together import Together
                print("✓ Together AI SDK installed successfully!")
            except Exception as e:
                raise ImportError(
                    "Failed to install together. Please install manually:\n"
                    "  pip install intellema-vdk[tts]\n"
                    "or:\n"
                    "  pip install together>=1.0.0"
                ) from e
        
        self.api_key = api_key
        self.model = model
        self.voice = voice
        self.client = Together(api_key=api_key)

    def stream(self, text: str) -> Iterator[bytes]:
        """
        Stream audio from Together API.
        
        Parameters
        ----------
        text : str
            The text to convert to speech.
            
        Yields
        ------
        bytes
            Raw audio bytes in PCM format.
            
        Raises
        ------
        Exception
            If the Together API call fails.
        """
        try:
            response = self.client.audio.speech.create(
                model=self.model,
                input=text,
                voice=self.voice,
                stream=True,
                response_format="raw",
                response_encoding="pcm_s16le",
            )

            # The Together SDK's Stream object tries to decode as SSE (text) by default
            # when iterating directly. For binary audio data, we must access the 
            # underlying httpx response bytes directly to avoid UnicodeDecodeError.
            if hasattr(response, "response"):
                # response.response is the httpx.Response object
                for chunk in response.response.iter_bytes():
                    processed = self._strip_wav_header(chunk)
                    if len(processed) > 0:
                        yield processed
            else:
                # Fallback for older SDK versions or different return types
                for chunk in response:
                    # Handle tuple format first (most common for Together API)
                    if isinstance(chunk, tuple):
                        if len(chunk) > 1:
                            # Tuple format (metadata, data)
                            sub_iterator = chunk[1]
                            if isinstance(sub_iterator, (bytes, bytearray)):
                                processed = self._strip_wav_header(sub_iterator)
                                if len(processed) > 0:
                                    yield processed
                            else:
                                try:
                                    for sub_chunk in sub_iterator:
                                        if isinstance(sub_chunk, (bytes, bytearray)):
                                            processed = self._strip_wav_header(sub_chunk)
                                            if len(processed) > 0:
                                                yield processed
                                        elif hasattr(sub_chunk, "data") and sub_chunk.data:
                                            # TogetherResponse objects have data attribute
                                            processed = self._strip_wav_header(sub_chunk.data)
                                            if len(processed) > 0:
                                                yield processed
                                        elif hasattr(sub_chunk, "content") and sub_chunk.content:
                                            processed = self._strip_wav_header(sub_chunk.content)
                                            if len(processed) > 0:
                                                yield processed
                                except TypeError as te:
                                    logger.warning(f"Non-iterable sub-iterator: {type(sub_iterator)}, error: {te}")
                    # Handle different response structures
                    elif isinstance(chunk, (bytes, bytearray)):
                        # Direct bytes - this is what we expect
                        processed = self._strip_wav_header(chunk)
                        if len(processed) > 0:
                            yield processed
                    elif hasattr(chunk, "content"):
                        # Object with content attribute
                        processed = self._strip_wav_header(chunk.content)
                        if len(processed) > 0:
                            yield processed

        except Exception as e:
            logger.error(f"Together TTS stream error: {e}", exc_info=True)
            raise

    def _strip_wav_header(self, audio_data: bytes) -> bytes:
        """Remove WAV header if present, returning raw PCM data."""
        if len(audio_data) >= WAV_HEADER_SIZE and audio_data[:4] == b"RIFF":
            return audio_data[WAV_HEADER_SIZE:]
        return audio_data
    
    
