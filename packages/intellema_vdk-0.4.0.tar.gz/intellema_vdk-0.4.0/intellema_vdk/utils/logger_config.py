import logging  # Standard library for logging events.
import sys  # Provides access to system-specific parameters and functions.


def setup_logging(
    log_level: int = logging.INFO,
    log_format: str = "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    date_format: str = "%Y-%m-%d %H:%M:%S",
) -> None:
    """Configures basic console logging for the application.

    This function should be called once at the beginning of the application's
    execution to set up a consistent logging format and level. It configures
    the root logger to output messages to the standard output.

    Args:
        log_level (int): The logging level for the root logger.
            Defaults to `logging.INFO`.
            Example accepted values: `logging.DEBUG`, `logging.INFO`,
            `logging.WARNING`, `logging.ERROR`.
        log_format (str): The format string for log messages.
            Defaults to a standard format including timestamp, level, and name.
        date_format (str): The format string for the date/time in log messages.
            Defaults to "%Y-%m-%d %H:%M:%S".

    Example:
        >>> import logging
        >>> # Set up logging with a DEBUG level
        >>> setup_logging(log_level=logging.DEBUG)
        >>>
        >>> # Now, any logger will inherit this configuration
        >>> logger = logging.getLogger("my_app")
        >>> logger.debug("This is a debug message.")
        >>> logger.info("This is an info message.")
    """
    logging.basicConfig(
        level=log_level,
        format=log_format,
        datefmt=date_format,
        stream=sys.stdout,  # Direct logs to standard output.
    )
