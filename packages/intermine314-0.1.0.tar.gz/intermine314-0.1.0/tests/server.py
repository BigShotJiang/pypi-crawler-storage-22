import threading
import time
import os
import posixpath
from socket import socket

from http.server import HTTPServer
from http.server import SimpleHTTPRequestHandler
from urllib.parse import unquote


class SilentRequestHandler(SimpleHTTPRequestHandler):  # pragma: no cover
    silent = True

    def translate_path(self, path):
        """Use the file's location instead of cwd"""
        # abandon query parameters
        self.silent = SilentRequestHandler.silent
        path = path.split("?", 1)[0]
        path = path.split("#", 1)[0]
        path = posixpath.normpath(unquote(path))
        words = path.split("/")
        words = filter(None, words)
        path = os.path.dirname(__file__)
        for word in words:
            drive, word = os.path.splitdrive(word)
            head, word = os.path.split(word)
            if word in (os.curdir, os.pardir):
                continue
            path = os.path.join(path, word)
        return path

    def log_message(self, *args):
        """Don't log anything, unless you say so"""
        if not self.silent:
            SimpleHTTPRequestHandler.log_message(self, *args)

    def do_POST(self):
        self.do_GET()


class TestServer(threading.Thread):  # pragma: no cover
    def __init__(self, daemonise=True, silent=True):
        super().__init__()
        self.daemon = daemonise
        self.silent = silent
        self.http = None
        # Try and get a free port number
        sock = socket()
        sock.bind(("", 0))
        self.port = sock.getsockname()[1]
        sock.close()

    def run(self):
        protocol = "HTTP/1.0"
        server_address = ("", self.port)

        SilentRequestHandler.protocol_version = protocol
        SilentRequestHandler.silent = self.silent
        self.http = HTTPServer(server_address, SilentRequestHandler)
        self.http.serve_forever()

    def shutdown(self):
        if self.http is not None:
            self.http.shutdown()
            self.http.server_close()
        self.join(timeout=5)


if __name__ == "__main__":  # pragma: no cover
    server = TestServer(silent=False)
    server.start()
    for number in range(1, 20):
        time.sleep(2)
