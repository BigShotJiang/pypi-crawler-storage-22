import time
import unittest
import logging
import xml.etree.ElementTree as ET
from pathlib import Path
from tempfile import TemporaryDirectory

import intermine314.query as query_module

from intermine314.model import Attribute, Collection, Field, Model, ModelError, ModelParseError, Reference
from intermine314.webservice import Service
from intermine314.query import ConstraintError, Query, QueryError, Template
from intermine314.constraints import LogicGroup, LogicParseError
from intermine314.lists.list import List

from tests.server import TestServer

logging.basicConfig()


class WebserviceTest(unittest.TestCase):  # pragma: no cover
    TEST_PORT = 8000
    MAX_ATTEMPTS = 50
    maxDiff = None
    LOG = logging.getLogger("WebserviceTest")

    def get_test_root(self):
        return "http://localhost:" + str(WebserviceTest.TEST_PORT) + "/testservice/service"

    def do_unpredictable_test(self, test, attempts=0, error=None):
        if attempts < WebserviceTest.MAX_ATTEMPTS:
            try:
                test()
                return
            except OSError as e:
                self.do_unpredictable_test(test, attempts + 1, e)
        else:
            raise RuntimeError("Max error count reached - last error: " + str(error))

    def checkQueryHasConstraint(self, query, **kwargs):
        xpath_attrs = []

        for k, v in kwargs.items():
            xpath_attrs.append(f"[@{k}='{v}']")

        xpath_attrs_str = "".join(xpath_attrs)
        xpath = f"./constraint{xpath_attrs_str}"

        constraint = query.find(xpath)

        ET.indent(query, space="    ", level=0)
        xml = ET.tostring(query, method="xml")
        self.assertIsNotNone(constraint, f"Failed to find constraint matching:\n{xpath} in:\n{xml}")

        return constraint


class TestInstantiation(WebserviceTest):  # pragma: no cover
    def testMakeModel(self):
        """Should be about to make a model, or fail with an appropriate message"""
        m = Model(self.get_test_root() + "/model")
        self.assertTrue(isinstance(m, Model), "Can make a model")
        try:
            bad_m = Model("foo")
            self.fail("No ModelParseError thrown at bad model xml")
        except ModelParseError as ex:
            self.assertEqual(ex.message, "Error parsing model")

    def testMakeService(self):
        """Should be able to make a Service"""
        s = Service(self.get_test_root())
        self.assertTrue(isinstance(s, Service), "Can make a service")


class TestModel(WebserviceTest):  # pragma: no cover
    model = None

    def setUp(self):
        if self.model is None:
            self.__class__.model = Model(self.get_test_root() + "/model")

    def testModelClasses(self):
        """The model should have the correct number of classes, which behave correctly"""
        self.assertEqual(len(self.model.classes.items()), 19)
        for good_class in ["Employee", "Company", "Department"]:
            cd = self.model.get_class(good_class)
            self.assertEqual(cd.name, good_class)
        ceo = self.model.get_class("Employee.department.company.CEO")
        self.assertEqual(ceo.name, "CEO")
        self.assertTrue(ceo.isa("Employee"))
        emp = self.model.get_class("Employee")
        self.assertTrue(ceo.isa(emp))

        try:
            self.model.get_class("Foo")
            self.fail("No ModelError thrown at non existent class")
        except ModelError as ex:
            self.assertEqual(ex.message, "'Foo' is not a class in this model")
        try:
            self.model.get_class("Employee.name")
            self.fail("No ModelError thrown at bad class retrieval")
        except ModelError as ex:
            self.assertEqual(ex.message, "'Employee.name' is not a class")

    def testClassFields(self):
        """The classes should have the correct fields"""
        cls = self.model.get_class("Bank")
        for f in ["name", "debtors"]:
            fd = cls.get_field(f)
            self.assertEqual(fd.name, f)
            self.assertTrue(isinstance(fd, Field))

    def testInheritedClassFields(self):
        """The classes should have the correct fields"""
        ceo = self.model.get_class("CEO")
        for f in ["name", "age", "seniority", "address", "department"]:
            fd = ceo.get_field(f)
            self.assertEqual(fd.name, f)
            self.assertTrue(isinstance(fd, Field))

        try:
            ceo.get_field("foo")
            self.fail("No ModelError thrown at non existent field")
        except ModelError as ex:
            self.assertEqual(ex.message, "There is no field called foo in CEO")

    def testFieldTypes(self):
        """The fields should be of the appropriate type"""
        dep = self.model.get_class("Department")
        self.assertTrue(isinstance(dep.get_field("name"), Attribute))
        self.assertTrue(isinstance(dep.get_field("employees"), Collection))
        self.assertTrue(isinstance(dep.get_field("company"), Reference))


class TestService(WebserviceTest):  # pragma: no cover
    def setUp(self):
        self.s = Service(self.get_test_root())

    def testRoot(self):
        """The service should have the right root"""
        self.assertEqual(self.get_test_root(), self.s.root, "it has the right root")

    def testVersion(self):
        """The service should have a version"""
        from numbers import Number

        v = self.s.version
        self.assertTrue(isinstance(v, Number))

    def testRelease(self):
        """The service should have a release"""
        self.assertEqual(self.s.release, "FOO")

    def testQueryMaking(self):
        """The service should be able to make a query"""
        q = self.s.new_query()
        self.assertTrue(isinstance(q, Query), "Can make a query")
        self.assertEqual(q.model.name, "testmodel", "and it has the right model")


class TestQuery(WebserviceTest):  # pragma: no cover
    model = None
    service = None
    expected_unary = "[<UnaryConstraint: Employee.age IS NULL>, <UnaryConstraint: Employee.name IS NOT NULL>, <UnaryConstraint: Employee.address IS NULL>]"
    expected_binary = "[<BinaryConstraint: Employee.age > 50000>, <BinaryConstraint: Employee.name = John>, <BinaryConstraint: Employee.end != 0>]"
    expected_multi = "[<MultiConstraint: Employee.name ONE OF ['Tom', 'Dick', 'Harry']>, <MultiConstraint: Employee.name NONE OF ['Sue', 'Jane', 'Helen']>]"
    expected_range = "[<RangeConstraint: Employee.age OVERLAPS ['1..10', '30..35']>]"
    expected_list = (
        "[<ListConstraint: Employee IN my-list>, <ListConstraint: Employee.department.manager NOT IN my-list>]"
    )
    expected_loop = "[<LoopConstraint: Employee IS Employee.department.manager>, <LoopConstraint: Employee.department.manager IS NOT Employee.department.company.CEO>]"
    expected_ternary = "[<TernaryConstraint: Employee LOOKUP Susan>, <TernaryConstraint: Employee.department.manager LOOKUP John IN Wernham-Hogg>]"
    expected_subclass = "[<SubClassConstraint: Department.employees ISA Manager>]"

    XML_1 = """
        <query model="testmodel" view="Employee.name Employee.age">
        </query>
        """
    EXPECTED_VIEWS_1 = ["Employee.name", "Employee.age"]

    XML_2 = """
        <query model="testmodel"
            view="Department.employees.name Department.employees.age Department.employees.seniority"
            >
            <constraint path="Department.employees" type="Manager"/>
        </query>
        """

    EXPECTED_VIEWS_2 = ["Department.employees.name", "Department.employees.age", "Department.employees.seniority"]

    XML_3 = """
        <query model="testmodel"
            view="Department.employees.name Department.employees.age Department.employees.seniority"
            >
            <constraint path="Department.employees" type="Manager"/>
            <constraint path="Department.name" op="=" value="foo"/>
        </query>
        """

    XML_4 = """
        <query model="testmodel"
            view="Department.employees.name Department.employees.age Department.employees.seniority"
            sortOrder="Department.employees.age asc"
            >
            <constraint path="Department.employees" type="Manager"/>
            <constraint path="Department.name" op="=" value="foo"/>
        </query>
        """

    XML_5 = """
        <query model="testmodel"
            view="Department.employees.name Department.employees.age Department.employees.seniority"
            sortOrder="Department.employees.age asc"
            >
            <pathDescription description="Should be a manager" pathString="Department.employees"/>
            <constraint path="Department.employees" type="Manager"/>
            <constraint path="Department.name" op="=" value="foo"/>
        </query>
        """

    XML_6 = """
        <query model="testmodel"
            view="Department.employees.name Department.employees.age Department.employees.salary"
            sortOrder="Department.employees.salary asc"
            >
            <pathDescription description="The Company" pathString="Department.employees.company"/>
            <pathDescription description="Should be a CEO" pathString="Department.employees"/>
            <constraint path="Department.employees" type="CEO"/>
            <constraint path="Department.employees.company" op="LOOKUP" value="foo"/>
        </query>
        """

    EXPECTED_VIEWS_6 = ["Department.employees.name", "Department.employees.age", "Department.employees.salary"]

    XML_7 = """
        <query model="testmodel"
            view="Department.employees.seniority Department.employees.age Department.employees.salary"
            sortOrder="Department.employees.salary asc"
            >
            <pathDescription description="The Company" pathString="Department.employees.company"/>
            <pathDescription description="Should be a CEO" pathString="Department.employees"/>
            <constraint path="Department.employees" type="CEO"/>
            <constraint path="Department.employees.company" op="LOOKUP" value="foo"/>
        </query>
        """

    EXPECTED_VIEWS_7 = ["Department.employees.seniority", "Department.employees.age", "Department.employees.salary"]

    CONSTRAINTS_COUNT_3 = 2

    XML_8 = """
        <query name="codesNotInOrder" model="testmodel" view="Employee.name Employee.age">
            <constraint path="Employee.name" op="=" value="foo" code="X"/>
            <constraint path="Employee.name" op="=" value="bar" code="Y"/>
            <constraint path="Employee.name" op="=" value="baz" code="Z"/>
        </query>
          """

    XML_9 = """
        <query name="ranges" model="testmodel" view="Employee.name Employee.age">
          <constraint path="Employee.age" op="OVERLAPS" code="A">
            <value>1..10</value>
            <value>30..35</value>
          </constraint>
        </query>
        """

    XML_10 = """
        <query name="ranges" model="testmodel" view="Employee.name Employee.age">
          <constraint path="Employee.name" op="ONE OF" code="A">
            <value>foo</value>
            <value>bar</value>
          </constraint>
        </query>
        """

    def setUp(self):
        if self.service is None:
            self.__class__.service = Service(self.get_test_root())

        if self.model is None:
            self.__class__.model = Model(self.get_test_root() + "/model", self.service)

        self.q = Query(self.model, self.service)

        class DummyManager:
            pass

        list_dict = {
            "service": None,
            "manager": DummyManager(),
            "name": "my-list",
            "title": None,
            "type": "Employee",
            "size": 10,
        }
        self.l = List(**list_dict)

    def testFromXML(self):
        q1 = self.service.new_query(xml=TestQuery.XML_1)
        self.assertEqual(q1.views, TestQuery.EXPECTED_VIEWS_1)

        q2 = self.service.new_query(xml=TestQuery.XML_2)
        self.assertEqual(q2.views, TestQuery.EXPECTED_VIEWS_2)

        q3 = self.service.new_query(xml=TestQuery.XML_3)
        self.assertEqual(q3.views, TestQuery.EXPECTED_VIEWS_2)
        self.assertEqual(len(q3.constraints), TestQuery.CONSTRAINTS_COUNT_3)

        q4 = self.service.new_query(xml=TestQuery.XML_4)
        self.assertEqual(q4.views, TestQuery.EXPECTED_VIEWS_2)
        self.assertEqual(len(q4.constraints), TestQuery.CONSTRAINTS_COUNT_3)
        self.assertEqual(str(q4.get_sort_order()), "Department.employees.age asc")

        q5 = self.service.new_query(xml=TestQuery.XML_5)
        self.assertEqual(q5.views, TestQuery.EXPECTED_VIEWS_2)
        self.assertEqual(len(q5.constraints), TestQuery.CONSTRAINTS_COUNT_3)
        self.assertEqual(str(q5.get_sort_order()), "Department.employees.age asc")
        self.assertEqual(len(q5.path_descriptions), 1)

        q6 = self.service.new_query(xml=TestQuery.XML_6)
        self.assertEqual(q6.views, TestQuery.EXPECTED_VIEWS_6)
        self.assertEqual(len(q6.constraints), TestQuery.CONSTRAINTS_COUNT_3)
        self.assertEqual(str(q6.get_sort_order()), "Department.employees.salary asc")
        self.assertEqual(len(q6.path_descriptions), 2)

        q7 = self.service.new_query(xml=TestQuery.XML_7)
        self.assertEqual(q7.views, TestQuery.EXPECTED_VIEWS_7)
        self.assertEqual(len(q7.constraints), TestQuery.CONSTRAINTS_COUNT_3)
        self.assertEqual(str(q7.get_sort_order()), "Department.employees.salary asc")
        self.assertEqual(len(q7.path_descriptions), 2)

        q8 = self.service.new_query(xml=TestQuery.XML_8)
        v = None
        try:
            v = q8.get_constraint("X").value
        except Exception:
            pass

        self.assertIsNotNone(
            v,
            "query should have a constraint with the code 'X', but it only has the codes: %s"
            % map(lambda x: x.code, q8.constraints),
        )
        self.assertEqual("foo", v, "And it has the right value")

        q9 = self.service.new_query(xml=TestQuery.XML_9)
        self.assertEqual(len(q9.constraints), 1)
        self.assertEqual(q9.get_constraint("A").op, "OVERLAPS")
        self.assertEqual(q9.get_constraint("A").values, ["1..10", "30..35"])

        q10 = self.service.new_query(xml=TestQuery.XML_10)
        self.assertEqual(len(q10.constraints), 1)
        self.assertEqual(q10.get_constraint("A").op, "ONE OF")
        self.assertEqual(q10.get_constraint("A").values, ["foo", "bar"])

    def testAddViews(self):
        """Queries should be able to add legal views, and complain about illegal ones"""
        self.q.add_view("Employee.age")
        self.q.add_view("Employee.name", "Employee.department.company.name")
        self.q.add_view("Employee.department.name Employee.department.company.vatNumber")
        self.q.add_view("Employee.department.manager.name,Employee.department.company.CEO.name")
        self.q.add_view("Employee.department.manager.name, Employee.department.company.CEO.name")
        self.q.add_view("department.*")
        expected = [
            "Employee.age",
            "Employee.name",
            "Employee.department.company.name",
            "Employee.department.name",
            "Employee.department.company.vatNumber",
            "Employee.department.manager.name",
            "Employee.department.company.CEO.name",
            "Employee.department.manager.name",
            "Employee.department.company.CEO.name",
            "Employee.department.id",
            "Employee.department.name",
        ]
        self.assertEqual(self.q.views, expected)
        try:
            self.q.add_view("Employee.name", "Employee.age", "Employee.department")
            self.fail("No ConstraintError thrown at non attribute view")
        except ConstraintError as ex:
            self.assertEqual(ex.message, "'Employee.department' does not represent an attribute")

    def testIDOnlyExpansion(self):
        """Should be able to expand to a given depth, selecting only the id attribute for IM Object classes"""
        self.q.prefetch_depth = 3
        self.q.prefetch_id_only = True

        self.q.add_view("Employee.*")
        expected = [
            "Employee.age",
            "Employee.end",
            "Employee.fullTime",
            "Employee.id",
            "Employee.name",
            "Employee.address.id",
            "Employee.department.id",
            "Employee.department.company.id",
            "Employee.department.manager.id",
            "Employee.department.employees.id",
            "Employee.department.rejectedEmployees.id",
            "Employee.departmentThatRejectedMe.id",
            "Employee.departmentThatRejectedMe.company.id",
            "Employee.departmentThatRejectedMe.manager.id",
            "Employee.departmentThatRejectedMe.employees.id",
            "Employee.departmentThatRejectedMe.rejectedEmployees.id",
            "Employee.simpleObjects.name",
            "Employee.simpleObjects.employee.id",
        ]
        self.assertEqual(self.q.views, expected)
        exp_joins = [
            "Employee.address",
            "Employee.department",
            "Employee.department.company",
            "Employee.department.manager",
            "Employee.department.employees",
            "Employee.department.rejectedEmployees",
            "Employee.departmentThatRejectedMe",
            "Employee.departmentThatRejectedMe.company",
            "Employee.departmentThatRejectedMe.manager",
            "Employee.departmentThatRejectedMe.employees",
            "Employee.departmentThatRejectedMe.rejectedEmployees",
            "Employee.simpleObjects",
            "Employee.simpleObjects.employee",
        ]
        self.assertEqual([j.path for j in self.q.joins], exp_joins)

    def testDeepViews(self):
        """Should be able to expand to a given prefetch depth"""
        self.q.prefetch_depth = 3
        self.q.add_view("Employee.*")
        expected = [
            "Employee.age",
            "Employee.end",
            "Employee.fullTime",
            "Employee.id",
            "Employee.name",
            "Employee.address.address",
            "Employee.address.id",
            "Employee.department.id",
            "Employee.department.name",
            "Employee.department.company.id",
            "Employee.department.company.name",
            "Employee.department.company.vatNumber",
            "Employee.department.manager.age",
            "Employee.department.manager.end",
            "Employee.department.manager.fullTime",
            "Employee.department.manager.id",
            "Employee.department.manager.name",
            "Employee.department.manager.seniority",
            "Employee.department.manager.title",
            "Employee.department.employees.age",
            "Employee.department.employees.end",
            "Employee.department.employees.fullTime",
            "Employee.department.employees.id",
            "Employee.department.employees.name",
            "Employee.department.rejectedEmployees.age",
            "Employee.department.rejectedEmployees.end",
            "Employee.department.rejectedEmployees.fullTime",
            "Employee.department.rejectedEmployees.id",
            "Employee.department.rejectedEmployees.name",
            "Employee.departmentThatRejectedMe.id",
            "Employee.departmentThatRejectedMe.name",
            "Employee.departmentThatRejectedMe.company.id",
            "Employee.departmentThatRejectedMe.company.name",
            "Employee.departmentThatRejectedMe.company.vatNumber",
            "Employee.departmentThatRejectedMe.manager.age",
            "Employee.departmentThatRejectedMe.manager.end",
            "Employee.departmentThatRejectedMe.manager.fullTime",
            "Employee.departmentThatRejectedMe.manager.id",
            "Employee.departmentThatRejectedMe.manager.name",
            "Employee.departmentThatRejectedMe.manager.seniority",
            "Employee.departmentThatRejectedMe.manager.title",
            "Employee.departmentThatRejectedMe.employees.age",
            "Employee.departmentThatRejectedMe.employees.end",
            "Employee.departmentThatRejectedMe.employees.fullTime",
            "Employee.departmentThatRejectedMe.employees.id",
            "Employee.departmentThatRejectedMe.employees.name",
            "Employee.departmentThatRejectedMe.rejectedEmployees.age",
            "Employee.departmentThatRejectedMe.rejectedEmployees.end",
            "Employee.departmentThatRejectedMe.rejectedEmployees.fullTime",
            "Employee.departmentThatRejectedMe.rejectedEmployees.id",
            "Employee.departmentThatRejectedMe.rejectedEmployees.name",
            "Employee.simpleObjects.name",
            "Employee.simpleObjects.employee.age",
            "Employee.simpleObjects.employee.end",
            "Employee.simpleObjects.employee.fullTime",
            "Employee.simpleObjects.employee.id",
            "Employee.simpleObjects.employee.name",
        ]
        self.assertEqual(self.q.views, expected)
        exp_joins = [
            "Employee.address",
            "Employee.department",
            "Employee.department.company",
            "Employee.department.manager",
            "Employee.department.employees",
            "Employee.department.rejectedEmployees",
            "Employee.departmentThatRejectedMe",
            "Employee.departmentThatRejectedMe.company",
            "Employee.departmentThatRejectedMe.manager",
            "Employee.departmentThatRejectedMe.employees",
            "Employee.departmentThatRejectedMe.rejectedEmployees",
            "Employee.simpleObjects",
            "Employee.simpleObjects.employee",
        ]
        self.assertEqual([j.path for j in self.q.joins], exp_joins)

    def testViewAlias(self):
        """The aliases for add_view should work as well"""
        self.q.select("Employee.age")
        self.q.add_to_select("name")
        self.q.add_column("department.name")
        self.q.add_columns("department.manager.name")
        self.q.add_views("department.company.CEO.name")
        expected = [
            "Employee.age",
            "Employee.name",
            "Employee.department.name",
            "Employee.department.manager.name",
            "Employee.department.company.CEO.name",
        ]
        self.assertEqual(self.q.views, expected)
        self.q.add_sort_order("name")
        self.q.add_sort_order("department.name")
        self.q.select("department.*")
        expected = ["Employee.department.id", "Employee.department.name"]
        self.assertEqual(self.q.views, expected)
        self.assertEqual(len(self.q._sort_order_list), 1)

    def testSortOrder(self):
        """Queries should be able to add sort orders, and complain appropriately"""
        self.q.add_view("Employee.name", "Employee.age", "Employee.fullTime")
        self.assertEqual(str(self.q.get_sort_order()), "Employee.name asc")
        self.q.add_sort_order("Employee.fullTime", "desc")
        self.assertEqual(str(self.q.get_sort_order()), "Employee.fullTime desc")
        self.q.add_sort_order("Employee.age", "asc")
        self.assertEqual(str(self.q.get_sort_order()), "Employee.fullTime desc Employee.age asc")
        self.q.add_sort_order("Employee.end", "desc")
        self.assertEqual(str(self.q.get_sort_order()), "Employee.fullTime desc Employee.age asc Employee.end desc")
        self.assertRaises(ModelError, self.q.add_sort_order, "Foo", "asc")
        self.assertRaises(TypeError, self.q.add_sort_order, "Employee.name", "up")
        self.assertRaises(QueryError, self.q.add_sort_order, "Employee.department.name", "desc")

    def testUCSortOrder(self):
        """Sort-Order directions should be accepted in upper case"""
        self.q.add_view("Employee.name", "Employee.age", "Employee.fullTime")
        self.q.add_sort_order("Employee.age", "ASC")
        self.assertEqual(str(self.q.get_sort_order()), "Employee.age asc")
        self.q.add_sort_order("Employee.fullTime", "DESC")
        self.assertEqual(str(self.q.get_sort_order()), "Employee.age asc Employee.fullTime desc")

    def testConstraintPathProblems(self):
        """Queries should not add constraints with bad paths to themselves"""
        try:
            self.q.add_constraint("Foo", "IS NULL")
            self.fail("No ModelError thrown at bad path name")
        except ModelError as ex:
            self.assertEqual(ex.message, "'Foo' is not a class in this model")

    def testUnaryConstraints(self):
        """Queries should be fine with NULL/NOT NULL constraints"""
        self.q.add_constraint("Employee.age", "IS NULL")
        self.q.add_constraint("Employee.name", "IS NOT NULL")
        self.q.add_constraint("Employee.address", "IS NULL")
        self.assertEqual(self.q.constraints.__repr__(), self.expected_unary)

    def testUnaryConstraintsSugar(self):
        """Queries should be fine with NULL/NOT NULL constraints"""
        Employee = self.q.model.table("Employee")

        self.q.add_constraint(Employee.age == None)
        self.q.add_constraint(Employee.name != None)
        self.q.add_constraint(Employee.address == None)
        self.assertEqual(self.q.constraints.__repr__(), self.expected_unary)

    def testAddBinaryConstraints(self):
        """Queries should be able to handle constraints on attribute values"""
        self.q.add_constraint("Employee.age", ">", 50000)
        self.q.add_constraint("Employee.name", "=", "John")
        self.q.add_constraint("Employee.end", "!=", 0)
        self.assertEqual(self.q.constraints.__repr__(), self.expected_binary)
        try:
            self.q.add_constraint("Employee.department", "=", "foo")
            self.fail("No ConstraintError thrown for non attribute BinaryConstraint")
        except ConstraintError as ex:
            self.assertEqual(ex.message, "'Employee.department' does not represent an attribute")

    def testAddBinaryConstraintsSugar(self):
        """Queries should be able to handle constraints on attribute values"""
        Employee = self.q.model.table("Employee")

        self.q.add_constraint(Employee.age > 50000)
        self.q.add_constraint(Employee.name == "John")
        self.q.add_constraint(Employee.end != 0)
        self.assertEqual(self.q.constraints.__repr__(), self.expected_binary)
        try:
            self.q.add_constraint(Employee.department == "foo")
            self.fail("No ConstraintError thrown for non attribute BinaryConstraint")
        except ConstraintError as ex:
            self.assertEqual(ex.message, "'Employee.department' does not represent an attribute")

    def testTernaryConstraint(self):
        """Queries should be able to add constraints for LOOKUPs"""
        self.q.add_constraint("Employee", "LOOKUP", "Susan")
        self.q.add_constraint("Employee.department.manager", "LOOKUP", "John", "Wernham-Hogg")
        self.assertEqual(self.q.constraints.__repr__(), self.expected_ternary)
        try:
            self.q.add_constraint("Employee.department.name", "LOOKUP", "foo")
            self.fail("No ConstraintError thrown for non object TernaryConstraint")
        except ConstraintError as ex:
            self.assertEqual(
                ex.message, "'Employee.department.name' does not represent a class, or a reference to a class"
            )

    def testTernaryConstraintImpliedRoot(self):
        """Queries should be able to add constraints for LOOKUPs on the implied root"""
        self.q.add_view("Employee.age")  # Sets root implicitly
        self.q.add_constraint("LOOKUP", "Susan")
        self.assertEqual(1, len(self.q.constraints))
        self.assertEqual("Employee", self.q.constraints[0].path)
        self.assertEqual("LOOKUP", self.q.constraints[0].op)
        self.assertEqual("Susan", self.q.constraints[0].value)

    def testMultiConstraint(self):
        """Queries should be ok with multi-value constraints"""
        self.q.add_constraint("Employee.name", "ONE OF", ["Tom", "Dick", "Harry"])
        self.q.add_constraint("Employee.name", "NONE OF", ["Sue", "Jane", "Helen"])
        self.assertEqual(self.q.constraints.__repr__(), self.expected_multi)
        self.assertRaises(TypeError, self.q.add_constraint, "Employee.name", "ONE OF", "Tom, Dick, Harry")
        self.assertRaises(ConstraintError, self.q.add_constraint, "Employee", "ONE OF", ["Tom", "Dick", "Harry"])

    def testMultiConstraintSugar(self):
        """Queries should be ok with multi-value constraints"""
        Employee = self.q.model.table("Employee")

        self.q.add_constraint(Employee.name == ["Tom", "Dick", "Harry"])
        self.q.add_constraint(Employee.name != ["Sue", "Jane", "Helen"])
        self.assertEqual(self.q.constraints.__repr__(), self.expected_multi)
        # This method does not throw an error in this form!!
        self.q.add_constraint(Employee.name == "Tom, Dick, Harry")
        self.assertRaises(ConstraintError, self.q.add_constraint, Employee == ["Tom", "Dick", "Harry"])

    def testRangeConstraint(self):
        """Queries should be OK with range constraints"""
        self.q.add_constraint("Employee.age", "OVERLAPS", ["1..10", "30..35"])
        self.assertEqual(self.q.constraints.__repr__(), self.expected_range)
        self.assertRaises(TypeError, self.q.add_constraint, "Employee.age", "OVERLAPS", "Tom, Dick, Harry")
        self.q.add_constraint("Employee", "OVERLAPS", ["1..10", "30..35"])

    def testListConstraint(self):
        """Queries should be ok with list constraints"""
        self.q.add_constraint("Employee", "IN", "my-list")
        self.q.add_constraint("Employee.department.manager", "NOT IN", "my-list")
        self.assertEqual(self.q.constraints.__repr__(), self.expected_list)
        self.assertRaises(ConstraintError, self.q.add_constraint, "Employee.name", "IN", "some list")

    def testListConstraintSugar(self):
        """Queries should be ok with list constraints"""
        Employee = self.q.model.table("Employee")

        self.q.add_constraint(Employee == self.l)
        self.q.add_constraint(Employee.department.manager != self.l)
        self.assertEqual(self.q.constraints.__repr__(), self.expected_list)
        self.assertRaises(ConstraintError, self.q.add_constraint, Employee.name == self.l)

    def testLoopConstraint(self):
        """Queries should be ok with loop constraints"""
        self.q.add_constraint("Employee", "IS", "Employee.department.manager")
        self.q.add_constraint("Employee.department.manager", "IS NOT", "Employee.department.company.CEO")
        self.assertEqual(self.q.constraints.__repr__(), self.expected_loop)
        self.assertRaises(ConstraintError, self.q.add_constraint, "Employee", "IS", "Employee.department")

    def testLoopConstraintSugar(self):
        """Queries should be ok with loop constraints made with alchemical sugar"""
        Employee = self.q.model.table("Employee")

        self.q.add_constraint(Employee == Employee.department.manager)
        self.q.add_constraint(Employee.department.manager != Employee.department.company.CEO)
        self.assertEqual(self.q.constraints.__repr__(), self.expected_loop)
        self.assertRaises(ConstraintError, self.q.add_constraint, Employee == Employee.department)

    def testSubclassConstraints(self):
        """Queries should be ok with sub class constraints"""
        self.q.add_constraint("Department.employees", "Manager")
        self.assertEqual(self.q.constraints.__repr__(), self.expected_subclass)
        try:
            self.q.add_constraint("Department.company.CEO", "Foo")
            self.fail("No ModelError raised by bad sub class")
        except ModelError as ex:
            self.assertEqual(ex.message, "'Foo' is not a class in this model")
        try:
            self.q.add_constraint("Department.company.CEO", "Manager")
            self.fail("No ConstraintError raised by bad subclass relationship")
        except ConstraintError as ex:
            self.assertEqual(ex.message, "'Manager' is not a subclass of 'Department.company.CEO'")

    def testStringLogic(self):
        """Queries should be able to parse good logic strings"""

        a = self.q.add_constraint("Employee.name", "IS NOT NULL")
        b = self.q.add_constraint("Employee.age", ">", 10)
        c = self.q.add_constraint("Employee.department", "LOOKUP", "Sales", "Wernham-Hogg")
        d = self.q.add_constraint("Employee.department.employees.name", "ONE OF", ["John", "Paul", "Mary"])
        self.q.add_constraint("Employee.department.employees", "Manager")

        self.assertEqual(str(self.q.get_logic()), "A and B and C and D")
        self.q.set_logic("(B or C) and (A or D)")
        self.assertEqual(str(self.q.get_logic()), "(B or C) and (A or D)")
        self.q.set_logic("B and C or A and D")
        self.assertEqual(str(self.q.get_logic()), "B and (C or A) and D")
        self.q.set_logic("(A and B) or (A and C and D)")
        self.assertEqual(str(self.q.get_logic()), "(A and B) or (A and C and D)")

    def testIrrelevantCodeStripping(self):
        """Should be able to recover from queries that have irrelevant codes in their logic"""

        a = self.q.add_constraint("Employee.name", "IS NOT NULL")
        b = self.q.add_constraint("Employee.age", ">", 10)
        c = self.q.add_constraint("Employee.department", "LOOKUP", "Sales", "Wernham-Hogg")
        d = self.q.add_constraint("Employee.department.employees.name", "ONE OF", ["John", "Paul", "Mary"])
        self.q.add_constraint("Employee.department.employees", "Manager")

        self.q._set_questionable_logic("A and B or C or D and E")
        self.assertEqual(str(self.q.get_logic()), "A and (B or C or D)")
        self.q._set_questionable_logic("E and A and B or C or D")
        self.assertEqual(str(self.q.get_logic()), "A and (B or C or D)")
        self.q._set_questionable_logic("A and B and E or C or D")
        self.assertEqual(str(self.q.get_logic()), "A and B and (C or D)")
        self.q._set_questionable_logic("A and B or X and J or Z and E or C or D")
        self.assertEqual(str(self.q.get_logic()), "A and B and (C or D)")
        self.q._set_questionable_logic("A and B or X and (J or Z and E or C) or D")
        self.assertEqual(str(self.q.get_logic()), "(A and B and C) or D")
        self.q._set_questionable_logic("A or (B or X and J or Z and E or C) or D")
        self.assertEqual(str(self.q.get_logic()), "A or (B and C) or D")

    def testObjectLogic(self):
        """Queries should be able to set logic from object methods"""

        a = self.q.add_constraint("Employee.name", "IS NOT NULL")
        b = self.q.add_constraint("Employee.age", ">", 10)
        c = self.q.add_constraint("Employee.department", "LOOKUP", "Sales", "Wernham-Hogg")
        d = self.q.add_constraint("Employee.department.employees.name", "ONE OF", ["John", "Paul", "Mary"])
        self.q.add_constraint("Employee.department.employees", "Manager")

        self.q.set_logic(a + b + c + d)
        self.assertEqual(str(self.q.get_logic()), "A and B and C and D")
        self.q.set_logic(a & b & c & d)
        self.assertEqual(str(self.q.get_logic()), "A and B and C and D")
        self.q.set_logic(a | b | c | d)
        self.assertEqual(str(self.q.get_logic()), "A or B or C or D")
        self.q.set_logic(a + b & c | d)
        self.assertEqual(str(self.q.get_logic()), "(A and B and C) or D")

        self.assertEqual(repr(self.q.get_logic()), "<LogicGroup: (A and B and C) or D>")

        self.assertRaises(ConstraintError, self.q.set_logic, "E and C or A and D")
        self.assertRaises(QueryError, self.q.set_logic, "A and B and C")
        self.assertRaises(LogicParseError, self.q.set_logic, "A and B and C not D")
        self.assertRaises(LogicParseError, self.q.set_logic, "A and ((B and C and D)")
        self.assertRaises(LogicParseError, self.q.set_logic, "A and ((B and C) and D))")
        self.assertRaises(LogicParseError, self.q.set_logic, "A and B( and C and D)")
        self.assertRaises(LogicParseError, self.q.set_logic, "A and (B and C and )D")
        self.assertRaises(LogicParseError, self.q.set_logic, "A and (B and C) D")
        self.assertRaises(LogicParseError, self.q.set_logic, "A and (B and C) (D and E)")
        self.assertRaises(TypeError, lambda: self.q.get_logic() + 1)
        self.assertRaises(TypeError, lambda: self.q.get_logic() & 1)
        self.assertRaises(TypeError, lambda: self.q.get_logic() | 1)
        self.assertRaises(TypeError, lambda: LogicGroup(a, "bar", b))

    def testJoins(self):
        """Queries should be able to add joins"""
        self.assertRaises(TypeError, self.q.add_join, "Employee.department", "foo")
        self.assertRaises(QueryError, self.q.add_join, "Employee.age", "inner")
        self.assertRaises(ModelError, self.q.add_join, "Employee.foo", "inner")
        self.q.add_join("Employee.department", "inner")
        self.q.add_join("Employee.department.company", "outer")
        expected = "[<Join: Employee.department INNER>, <Join: Employee.department.company OUTER>]"
        self.assertEqual(expected, self.q.joins.__repr__())

    def testXML(self):
        """Queries should be able to serialise themselves to XML"""
        self.q.add_view("Employee.name", "Employee.age", "Employee.department.name")
        self.q.add_constraint("Employee.name", "IS NOT NULL")
        self.q.add_constraint("Employee.age", ">", 10)
        self.q.add_constraint("Employee.department", "LOOKUP", "Sales", "Wernham-Hogg")
        self.q.add_constraint("Employee.department.employees.name", "ONE OF", ["John", "Paul", "Mary"])
        self.q.add_constraint("Employee.department.manager", "IS", "Employee")
        self.q.add_constraint("Employee", "IN", "some list of employees")
        self.q.add_constraint("Employee.age", "OVERLAPS", ["1..10", "30..35"])
        self.q.add_constraint("Employee.department.employees", "Manager")
        self.q.add_join("Employee.department", "outer")
        self.q.add_sort_order("Employee.age")
        self.q.set_logic("(A and B) or (A and C and D) and (E or F or G)")

        xml = self.q.to_xml()
        query = ET.fromstring(xml)

        self.assertEqual(query.attrib["constraintLogic"], "((A and B) or (A and C and D)) and (E or F or G)")
        self.assertEqual(query.attrib["model"], "testmodel")
        self.assertEqual(query.attrib["sortOrder"], "Employee.age asc")
        self.assertEqual(query.attrib["view"], "Employee.name Employee.age Employee.department.name")

        join = query.find("join")
        self.assertEqual(join.attrib["path"], "Employee.department")
        self.assertEqual(join.attrib["style"], "OUTER")

        self.checkQueryHasConstraint(query, path="Employee.name", op="IS NOT NULL")
        self.checkQueryHasConstraint(query, path="Employee.age", op=">", value=10)
        self.checkQueryHasConstraint(
            query, path="Employee.department", op="LOOKUP", value="Sales", extraValue="Wernham-Hogg"
        )
        constraint = self.checkQueryHasConstraint(query, path="Employee.department.employees.name", op="ONE OF")

        names = [e.text for e in constraint.findall("value")]
        self.assertIn("John", names)
        self.assertIn("Paul", names)
        self.assertIn("Mary", names)

        self.checkQueryHasConstraint(query, path="Employee.department.manager", op="=", loopPath="Employee")
        self.checkQueryHasConstraint(query, path="Employee", op="IN", value="some list of employees")

        constraint = self.checkQueryHasConstraint(query, path="Employee.age", op="OVERLAPS")
        values = [e.text for e in constraint.findall("value")]
        self.assertIn("1..10", values)
        self.assertIn("30..35", values)

        constraint = self.checkQueryHasConstraint(query, path="Employee.department.employees", type="Manager")

        # Clones must produce identical XML
        self.assertEqual(xml, self.q.clone().to_xml())

    def testSugaryQueryConstruction(self):
        """Test use of operation coercion which is similar to SQLAlchemy"""
        model = self.q.model

        Employee = model.table("Employee")
        Manager = model.table("Manager")

        # SQL style
        q = (
            Employee.select("name", "age", "department.name")
            .where(Employee.name != None)
            .where(Employee.age > 10)
            .where(Employee.department % ("Sales", "Wernham-Hogg"))
            .where(Employee.department.employees.name == ["John", "Paul", "Mary"])
            .where(Employee.department.manager == Employee)
            .where(Employee == self.l)
            .where(Employee.department.employees >> Manager)
            .outerjoin(Employee.department)
            .order_by(Employee.age)
            .set_logic("(A and B) or (A and C and D) and (E or F)")
        )

        xml = q.to_xml()
        query = ET.fromstring(xml)

        self.assertEqual(query.attrib["constraintLogic"], "((A and B) or (A and C and D)) and (E or F)")
        self.assertEqual(query.attrib["model"], "testmodel")
        self.assertEqual(query.attrib["sortOrder"], "Employee.age asc")
        self.assertEqual(query.attrib["view"], "Employee.name Employee.age Employee.department.name")

        join = query.find("join")
        self.assertEqual(join.attrib["path"], "Employee.department")
        self.assertEqual(join.attrib["style"], "OUTER")

        self.checkQueryHasConstraint(query, path="Employee.name", op="IS NOT NULL")
        self.checkQueryHasConstraint(query, path="Employee.age", op=">", value="10")
        self.checkQueryHasConstraint(
            query, path="Employee.department", op="LOOKUP", value="Sales", extraValue="Wernham-Hogg"
        )

        constraint = self.checkQueryHasConstraint(query, path="Employee.department.employees.name", op="ONE OF")
        names = [e.text for e in constraint.findall("value")]
        self.assertIn("John", names)
        self.assertIn("Paul", names)
        self.assertIn("Mary", names)

        self.checkQueryHasConstraint(query, path="Employee.department.manager", op="=", loopPath="Employee")
        self.checkQueryHasConstraint(query, path="Employee", op="IN", value="my-list")
        self.checkQueryHasConstraint(query, path="Employee.department.employees", type="Manager")

        # SQLAlchemy style
        q = (
            self.service.query(Employee)
            .select("name", "age", "department.name")
            .filter(Employee.name != None)
            .filter(Employee.age > 10)
            .filter(Employee.department % ("Sales", "Wernham-Hogg"))
            .filter(Employee.department.employees.name == ["John", "Paul", "Mary"])
            .filter(Employee.department.manager == Employee)
            .filter(Employee == self.l)
            .filter(Employee.department.employees >> Manager)
            .outerjoin(Employee.department)
            .order_by(Employee.age)
            .set_logic("(A and B) or (A and C and D) and (E or F)")
        )
        xml = q.to_xml()
        query = ET.fromstring(xml)

        self.assertEqual(query.attrib["constraintLogic"], "((A and B) or (A and C and D)) and (E or F)")
        self.assertEqual(query.attrib["model"], "testmodel")
        self.assertEqual(query.attrib["sortOrder"], "Employee.age asc")
        self.assertEqual(query.attrib["view"], "Employee.name Employee.age Employee.department.name")

        join = query.find("join")
        self.assertEqual(join.attrib["path"], "Employee.department")
        self.assertEqual(join.attrib["style"], "OUTER")

        self.checkQueryHasConstraint(query, path="Employee.name", op="IS NOT NULL")
        self.checkQueryHasConstraint(query, path="Employee.age", op=">", value="10")
        self.checkQueryHasConstraint(
            query, path="Employee.department", op="LOOKUP", value="Sales", extraValue="Wernham-Hogg"
        )

        constraint = self.checkQueryHasConstraint(query, path="Employee.department.employees.name", op="ONE OF")
        names = [e.text for e in constraint.findall("value")]
        self.assertIn("John", names)
        self.assertIn("Paul", names)
        self.assertIn("Mary", names)

        self.checkQueryHasConstraint(query, path="Employee.department.manager", op="=", loopPath="Employee")
        self.checkQueryHasConstraint(query, path="Employee", op="IN", value="my-list")
        self.checkQueryHasConstraint(query, path="Employee.department.employees", type="Manager")

    def testKWCons(self):
        """Test use of constraints provided in kwargs"""

        model = self.q.model

        q = model.Employee.select("name").where(age=10)
        xml = q.to_xml()
        query = ET.fromstring(xml)
        self.assertEqual(query.attrib["model"], "testmodel")
        self.assertEqual(query.attrib["sortOrder"], "Employee.name asc")
        self.assertEqual(query.attrib["view"], "Employee.name")

        self.checkQueryHasConstraint(query, path="Employee.age", op="=", value=10)

    def testLogicConstraintTrees(self):
        # Actually SQL-Alchemy-esque
        e = self.service.model.Employee
        CEO = self.service.model.CEO
        q = (
            self.service.query(e, e.department.name)
            .filter(
                e.department.manager < CEO,
                (((e.name != None) & (e.age > 10)) | (e.in_(self.l) & (e.department.manager % "David"))),
            )
            .outerjoin(e.department)
            .order_by(e.age)
        )

        xml = q.to_xml()
        query = ET.fromstring(xml)

        self.assertEqual(query.attrib["constraintLogic"], "(A and B) or (C and D)")
        self.assertEqual(query.attrib["model"], "testmodel")
        self.assertEqual(query.attrib["sortOrder"], "Employee.age asc")
        self.assertEqual(
            query.attrib["view"],
            "Employee.age Employee.end Employee.fullTime Employee.id Employee.name Employee.department.name",
        )

        join = query.find("join")
        self.assertEqual(join.attrib["path"], "Employee.department")
        self.assertEqual(join.attrib["style"], "OUTER")

        self.checkQueryHasConstraint(query, path="Employee.name", op="IS NOT NULL")
        self.checkQueryHasConstraint(query, path="Employee.age", op=">", value="10")
        self.checkQueryHasConstraint(query, path="Employee", op="IN", value="my-list")
        self.checkQueryHasConstraint(query, value="David", op="LOOKUP", path="Employee.department.manager")
        self.checkQueryHasConstraint(query, path="Employee.department.manager", type="CEO")


class TestTemplate(TestQuery):  # pragma: no cover
    expected_unary = "[<TemplateUnaryConstraint: Employee.age IS NULL (editable, locked)>, <TemplateUnaryConstraint: Employee.name IS NOT NULL (editable, locked)>, <TemplateUnaryConstraint: Employee.address IS NULL (editable, locked)>]"
    expected_binary = "[<TemplateBinaryConstraint: Employee.age > 50000 (editable, locked)>, <TemplateBinaryConstraint: Employee.name = John (editable, locked)>, <TemplateBinaryConstraint: Employee.end != 0 (editable, locked)>]"
    expected_multi = "[<TemplateMultiConstraint: Employee.name ONE OF ['Tom', 'Dick', 'Harry'] (editable, locked)>, <TemplateMultiConstraint: Employee.name NONE OF ['Sue', 'Jane', 'Helen'] (editable, locked)>]"
    expected_range = "[<TemplateRangeConstraint: Employee.age OVERLAPS ['1..10', '30..35'] (editable, locked)>]"
    expected_ternary = "[<TemplateTernaryConstraint: Employee LOOKUP Susan (editable, locked)>, <TemplateTernaryConstraint: Employee.department.manager LOOKUP John IN Wernham-Hogg (editable, locked)>]"
    expected_subclass = "[<TemplateSubClassConstraint: Department.employees ISA Manager (editable, locked)>]"
    expected_list = "[<TemplateListConstraint: Employee IN my-list (editable, locked)>, <TemplateListConstraint: Employee.department.manager NOT IN my-list (editable, locked)>]"
    expected_loop = "[<TemplateLoopConstraint: Employee IS Employee.department.manager (editable, locked)>, <TemplateLoopConstraint: Employee.department.manager IS NOT Employee.department.company.CEO (editable, locked)>]"

    def setUp(self):
        super(TestTemplate, self).setUp()
        self.q = Template(self.model)


class TestQueryResults(WebserviceTest):  # pragma: no cover
    model = None
    service = None

    class MockService(object):
        QUERY_PATH = "/QUERY-PATH"
        TEMPLATEQUERY_PATH = "/TEMPLATE-PATH"
        root = "ROOT"
        prefetch_depth = 1
        prefetch_id_only = False

        def get_results(self, *args):
            return args

    def setUp(self):
        if self.service is None:
            self.__class__.service = Service(self.get_test_root())
        if self.model is None:
            self.__class__.model = Model(self.get_test_root() + "/model")

        q = Query(self.model, self.service)
        q.add_view("Employee.name", "Employee.age", "Employee.id")
        self.query = q
        t = Template(self.model, self.service)
        t.add_view("Employee.name", "Employee.age", "Employee.id")
        t.add_constraint("Employee.name", "=", "Fred")
        t.add_constraint("Employee.age", ">", 25)
        self.template = t

    def testURLs(self):
        """Should be able to produce the right information for opening urls"""
        q = Query(self.model, self.MockService())
        q.add_view("Employee.name", "Employee.age", "Employee.id")
        q.add_constraint("Employee.name", "=", "Fred")
        q.add_constraint("Employee.age", ">", 25)

        t = Template(self.model, self.MockService())
        t.name = "TEST-TEMPLATE"
        t.add_view("Employee.name", "Employee.age", "Employee.id")
        t.add_constraint("Employee.name", "=", "Fred")
        t.add_constraint("Employee.age", ">", 25)

        results = q.results()

        self.assertEqual(results[0], "/QUERY-PATH")
        query_xml = results[1]["query"]

        query = ET.fromstring(query_xml)

        self.assertEqual(query.attrib["constraintLogic"], "A and B")
        self.assertEqual(query.attrib["model"], "testmodel")
        self.assertEqual(query.attrib["sortOrder"], "Employee.name asc")
        self.assertEqual(query.attrib["view"], "Employee.name Employee.age Employee.id")

        self.checkQueryHasConstraint(query, path="Employee.name", op="=", value="Fred")
        self.checkQueryHasConstraint(query, path="Employee.age", op=">", value="25")

        self.assertEqual(results[1]["start"], 0)
        self.assertEqual(results[2], "object")
        self.assertIn("Employee.name", results[3])
        self.assertIn("Employee.age", results[3])
        self.assertIn("Employee.id", results[3])
        self.assertEqual(results[4], self.model.get_class("Employee"))

        self.assertEqual(list(results), q.get_results_list())

        rows = q.rows()
        self.assertEqual(rows[0], "/QUERY-PATH")
        query_xml = rows[1]["query"]

        query = ET.fromstring(query_xml)

        self.assertEqual(query.attrib["constraintLogic"], "A and B")
        self.assertEqual(query.attrib["model"], "testmodel")
        self.assertEqual(query.attrib["sortOrder"], "Employee.name asc")
        self.assertEqual(query.attrib["view"], "Employee.name Employee.age Employee.id")

        self.checkQueryHasConstraint(query, path="Employee.name", op="=", value="Fred")
        self.checkQueryHasConstraint(query, path="Employee.age", op=">", value="25")
        self.assertEqual(rows[1]["start"], 0)
        self.assertEqual(rows[2], "rr")
        self.assertIn("Employee.name", rows[3])
        self.assertIn("Employee.age", rows[3])
        self.assertIn("Employee.id", rows[3])
        self.assertEqual(rows[4], self.model.get_class("Employee"))

        self.assertEqual(list(rows), q.get_row_list())

        results = q.results(start=10, size=200)
        self.assertEqual(results[0], "/QUERY-PATH")

        query_xml = results[1]["query"]
        query = ET.fromstring(query_xml)

        self.assertEqual(query.attrib["constraintLogic"], "A and B")
        self.assertEqual(query.attrib["model"], "testmodel")
        self.assertEqual(query.attrib["sortOrder"], "Employee.name asc")
        self.assertEqual(query.attrib["view"], "Employee.name Employee.age Employee.id")

        self.checkQueryHasConstraint(query, path="Employee.name", op="=", value="Fred")
        self.checkQueryHasConstraint(query, path="Employee.age", op=">", value="25")

        self.assertEqual(results[1]["start"], 10)
        self.assertEqual(results[1]["size"], 200)
        self.assertEqual(results[2], "object")
        self.assertIn("Employee.name", results[3])
        self.assertIn("Employee.age", results[3])
        self.assertIn("Employee.id", results[3])
        self.assertEqual(results[4], self.model.get_class("Employee"))

        self.assertEqual(list(results), q.get_results_list(start=10, size=200))

        expected1 = (
            "/TEMPLATE-PATH",
            {
                "name": "TEST-TEMPLATE",
                "userName": "",
                "code1": "A",
                "code2": "B",
                "constraint1": "Employee.name",
                "constraint2": "Employee.age",
                "op1": "=",
                "op2": ">",
                "value1": "Fred",
                "value2": "25",
                "start": 0,
            },
            "object",
            ["Employee.name", "Employee.age", "Employee.id"],
            self.model.get_class("Employee"),
        )
        self.assertEqual(expected1, t.results())
        self.assertEqual(list(expected1), t.get_results_list())

        expected1 = (
            "/TEMPLATE-PATH",
            {
                "name": "TEST-TEMPLATE",
                "userName": "",
                "code1": "A",
                "code2": "B",
                "constraint1": "Employee.name",
                "constraint2": "Employee.age",
                "op1": "=",
                "op2": ">",
                "value1": "Fred",
                "value2": "25",
                "start": 0,
            },
            "rr",
            ["Employee.name", "Employee.age", "Employee.id"],
            self.model.get_class("Employee"),
        )
        self.assertEqual(expected1, t.rows())
        self.assertEqual(list(expected1), t.get_row_list())

        expected2 = (
            "/TEMPLATE-PATH",
            {
                "name": "TEST-TEMPLATE",
                "userName": "",
                "code1": "A",
                "code2": "B",
                "constraint1": "Employee.name",
                "constraint2": "Employee.age",
                "op1": "<",
                "op2": ">",
                "value1": "Tom",
                "value2": "55",
                "start": 0,
            },
            "object",
            ["Employee.name", "Employee.age", "Employee.id"],
            self.model.get_class("Employee"),
        )
        self.assertEqual(expected2, t.results(A={"op": "<", "value": "Tom"}, B={"value": 55}))

        expected2 = (
            "/TEMPLATE-PATH",
            {
                "name": "TEST-TEMPLATE",
                "userName": "",
                "code1": "A",
                "code2": "B",
                "constraint1": "Employee.name",
                "constraint2": "Employee.age",
                "op1": "<",
                "op2": ">",
                "value1": "Tom",
                "value2": "55",
                "start": 10,
                "size": 200,
            },
            "object",
            ["Employee.name", "Employee.age", "Employee.id"],
            self.model.get_class("Employee"),
        )
        self.assertEqual(expected2, t.results(start=10, size=200, A={"op": "<", "value": "Tom"}, B={"value": 55}))
        self.assertEqual(
            list(expected2), t.get_results_list(start=10, size=200, A={"op": "<", "value": "Tom"}, B={"value": 55})
        )

        # Check that we can just use strings for simple value replacement.
        expected3 = (
            "/TEMPLATE-PATH",
            {
                "name": "TEST-TEMPLATE",
                "userName": "",
                "code1": "A",
                "code2": "B",
                "constraint1": "Employee.name",
                "constraint2": "Employee.age",
                "op1": "=",
                "op2": ">",
                "value1": "Foo",
                "value2": "Bar",
                "start": 10,
                "size": 200,
            },
            "object",
            ["Employee.name", "Employee.age", "Employee.id"],
            self.model.get_class("Employee"),
        )
        self.assertEqual(list(expected3), t.get_results_list(start=10, size=200, A="Foo", B="Bar"))
        # Check that these contraint values have not been applied to the actual template
        self.assertEqual(expected1, t.rows())
        expected1 = (
            "/TEMPLATE-PATH",
            {
                "name": "TEST-TEMPLATE",
                "userName": "",
                "code1": "A",
                "code2": "B",
                "constraint1": "Employee.name",
                "constraint2": "Employee.age",
                "op1": "=",
                "op2": ">",
                "value1": "Fred",
                "value2": "25",
                "start": 0,
            },
            "object",
            ["Employee.name", "Employee.age", "Employee.id"],
            self.model.get_class("Employee"),
        )

        self.assertEqual(expected1, t.results())

    def testResultsList(self):
        """Should be able to get results as one list per row"""

        def logic():
            expected = [["foo", "bar", "baz"], [123, 1.23, -1.23], [True, False, None]]
            self.assertEqual(self.query.get_results_list("list"), expected)
            self.assertEqual(self.template.get_results_list("list"), expected)

        self.do_unpredictable_test(logic)

    def testResultRows(self):
        """Should be able to get results as result rows"""

        def logic():
            assertEqual = self.assertEqual
            q_res = self.query.all("rr")
            t_res = self.template.all("rr")
            for results in [q_res, t_res]:
                # Can index by short path
                assertEqual(results[0]["age"], "bar")
                assertEqual(results[1]["Employee.age"], 1.23)  # or by full path
                assertEqual(results[2][0], True)  # or by numerical index
                assertEqual(len(results), 3)
                for row in results:
                    assertEqual(len(row), 3)

        self.do_unpredictable_test(logic)

    def testResultRowIterability(self):
        """Result rows should iterate as lists"""

        def logic():
            q_res = self.query.all("rr")
            t_res = self.template.all("rr")
            for results in [q_res, t_res]:
                # 'in' as test of iterability
                self.assertTrue("bar" in results[0])
                self.assertTrue(1.23 in results[1])
                self.assertTrue(True in results[2])
                # Should be able to actually iterate
                count = 0
                for val in results[0]:
                    count += 1
                    self.assertTrue(0 < count < 4)

        self.do_unpredictable_test(logic)

    def testResultRowDictBehaviour(self):
        """Result rows should allow dictionary-like access and iteration"""

        def logic():
            q_res = self.query.all("rr")
            t_res = self.template.all("rr")
            for results in [q_res, t_res]:
                r = results[0]
                count = 0
                for k, v in r.items():
                    count += 1
                    self.assertTrue(0 < count < 4)
                count = 0
                self.assertEqual({"Employee.name": "foo", "Employee.age": "bar", "Employee.id": "baz"}, r.to_d())
                self.assertEqual([("Employee.name", "foo"), ("Employee.age", "bar"), ("Employee.id", "baz")], r.items())
                for k, v in r.items():
                    count += 1
                    self.assertTrue(0 < count < 4)
                self.assertEqual([pair for pair in r.items()], r.items())
                self.assertEqual(r.keys(), self.query.views)
                self.assertEqual(r.values(), r.to_l())
                self.assertEqual(r["age"], "bar")
                self.assertEqual(r["Employee.age"], "bar")
                with self.assertRaises(KeyError):
                    _ = r["Employee.foo"]

        self.do_unpredictable_test(logic)

    def testResultsDict(self):
        """Should be able to get results as one dictionary per row"""
        expected = [
            {"Employee.age": "bar", "Employee.id": "baz", "Employee.name": "foo"},
            {"Employee.age": 1.23, "Employee.id": -1.23, "Employee.name": 123},
            {"Employee.age": False, "Employee.id": None, "Employee.name": True},
        ]

        def logic():
            self.assertEqual(expected, self.query.get_results_list("dict"))
            self.assertEqual(expected, self.template.get_results_list("dict"))

        self.do_unpredictable_test(logic)


class TestMinimalResults(TestQueryResults):
    PATH = "/testservice/legacyjsonrows"


class TestTSVResults(WebserviceTest):  # pragma: no cover
    model = None
    service = None
    PATH = "/testservice/tsvservice"
    FORMAT = "tsv"
    EXPECTED_RESULTS = ["foo\tbar\tbaz", "123\t1.23\t-1.23"]

    def get_test_root(self):
        return "http://localhost:" + str(self.TEST_PORT) + self.PATH

    def setUp(self):
        if self.service is None:
            self.__class__.service = Service(self.get_test_root())
        if self.model is None:
            self.__class__.model = Model(self.get_test_root() + "/service/model")

        q = Query(self.model, self.service)
        q.add_view("Employee.name", "Employee.age", "Employee.id")
        self.query = q
        t = Template(self.model, self.service)
        t.add_view("Employee.name", "Employee.age", "Employee.id")
        t.add_constraint("Employee.name", "=", "Fred")
        t.add_constraint("Employee.age", ">", 25)
        self.template = t

    def testResults(self):
        """Should be able to get results as one string per row"""

        def logic():
            self.assertEqual(self.query.get_results_list(self.FORMAT), self.EXPECTED_RESULTS)
            self.assertEqual(self.template.get_results_list(self.FORMAT), self.EXPECTED_RESULTS)

        self.do_unpredictable_test(logic)


class TestCSVResults(TestTSVResults):  # pragma: no cover
    PATH = "/testservice/csvservice"
    FORMAT = "csv"
    EXPECTED_RESULTS = ['"foo","bar","baz"', '"123","1.23","-1.23"']


class TestResultObjects(WebserviceTest):  # pragma: no cover
    model = None
    service = None

    def get_test_root(self):
        return "http://localhost:" + str(self.TEST_PORT) + "/testservice/testresultobjs"

    def setUp(self):
        if self.service is None:
            self.__class__.service = Service(self.get_test_root())
        if self.model is None:
            self.__class__.model = self.service.model

        q = Query(self.model, self.service)
        q.add_view(
            "Department.name", "Department.employees.name", "Department.employees.age", "Department.company.vatNumber"
        )
        self.query = q
        t = Template(self.model, self.service)
        q.add_view(
            "Department.name", "Department.employees.name", "Department.employees.age", "Department.company.vatNumber"
        )
        t.add_constraint("Department.manager.name", "=", "Fred")
        self.template = t

    def testResultObjs(self):
        """Should be able to get results as result objects"""

        def logic():
            assertEqual = self.assertEqual
            q_res = self.query.all("jsonobjects")
            t_res = self.template.all("jsonobjects")
            for departments in [q_res, t_res]:
                assertEqual(departments[0].name, "Sales")
                assertEqual(departments[0].company.vatNumber, 665261)
                assertEqual(departments[0].employees[2].name, "Tim Canterbury")
                assertEqual(departments[0].employees[3].age, 58)
                assertEqual(len(departments[0].employees), 6)

                assertEqual(departments[-1].name, "Slashes")
                assertEqual(departments[-1].company.vatNumber, 764575)
                assertEqual(departments[-1].employees[2].name, "Double forward Slash //")
                assertEqual(departments[-1].employees[2].age, 62)
                assertEqual(len(departments[-1].employees), 5)

                for idx in [0, -1]:
                    # Model errors are thrown for illegal field access
                    self.assertRaises(ModelError, lambda: departments[idx].foo)
                    self.assertRaises(ModelError, lambda: departments[idx].company.foo)

                assertEqual(len(departments), 8)

        self.do_unpredictable_test(logic)


class TestCountResults(TestTSVResults):  # pragma: no cover
    PATH = "/testservice/countservice"
    FORMAT = "count"
    EXPECTED_RESULTS = ["25"]
    EXPECTED_COUNT = 25

    def testCount(self):
        """Should be able to get count as an integer"""

        def logic():
            self.assertEqual(self.query.count(), self.EXPECTED_COUNT)
            self.assertEqual(self.template.count(), self.EXPECTED_COUNT)

        self.do_unpredictable_test(logic)


class TestAnalyticsWorkflow(WebserviceTest):  # pragma: no cover
    model = None
    service = None

    def setUp(self):
        if self.service is None:
            self.__class__.service = Service(self.get_test_root())
        if self.model is None:
            self.__class__.model = Model(self.get_test_root() + "/model", self.service)

        self.query = Query(self.model, self.service)
        self.query.add_view("Employee.name", "Employee.age", "Employee.id")

    def _expected_rows(self):
        return self.query.get_results_list("dict")

    def test_run_parallel_matches_sequential(self):
        expected = self._expected_rows()
        got = list(
            self.query.run_parallel(
                row="dict",
                size=len(expected),
                page_size=1,
                max_workers=2,
                ordered=True,
                prefetch=2,
            )
        )
        self.assertEqual(len(expected), len(got))
        self.assertEqual(sorted(expected[0].keys()), sorted(got[0].keys()))

    def test_run_parallel_unordered_has_same_rows(self):
        expected = self._expected_rows()
        got = list(
            self.query.run_parallel(
                row="dict",
                size=len(expected),
                page_size=1,
                max_workers=2,
                ordered=False,
                prefetch=2,
            )
        )
        self.assertEqual(len(expected), len(got))
        self.assertEqual(sorted(expected[0].keys()), sorted(got[0].keys()))

    def test_run_parallel_type_validation(self):
        with self.assertRaises(TypeError):
            list(self.query.run_parallel(row="dict", size=1, page_size="1000"))

    @unittest.skipIf(query_module.pl is None, "polars optional dependency is not installed")
    def test_dataframe_parallel(self):
        expected = self._expected_rows()
        df = self.query.dataframe(
            size=len(expected),
            batch_size=1,
            parallel=True,
            page_size=1,
            max_workers=2,
            prefetch=2,
        )
        self.assertEqual(df.height, len(expected))
        self.assertEqual(sorted(df.columns), sorted(expected[0].keys()))

    @unittest.skipIf(query_module.pl is None, "polars optional dependency is not installed")
    def test_to_parquet_cleans_stale_parts(self):
        expected = self._expected_rows()
        with TemporaryDirectory() as tmp:
            target = Path(tmp)
            (target / "part-99999.parquet").write_text("stale", encoding="utf-8")
            self.query.to_parquet(
                target,
                size=len(expected),
                batch_size=2,
                parallel=True,
                page_size=1,
                max_workers=2,
            )
            parts = sorted(path.name for path in target.glob("part-*.parquet"))
            self.assertEqual(parts, ["part-00000.parquet", "part-00001.parquet"])

    @unittest.skipIf(query_module.pl is None, "polars optional dependency is not installed")
    def test_to_parquet_single_file_parallel(self):
        expected = self._expected_rows()
        with TemporaryDirectory() as tmp:
            target = Path(tmp) / "results.parquet"
            self.query.to_parquet(
                target,
                size=len(expected),
                batch_size=2,
                single_file=True,
                parallel=True,
                page_size=1,
                max_workers=2,
            )
            self.assertTrue(target.exists())
            self.assertGreater(target.stat().st_size, 0)

    @unittest.skipIf(
        query_module.pl is None or query_module.duckdb is None,
        "polars/duckdb optional dependencies are not installed",
    )
    def test_to_duckdb_parallel(self):
        expected = self._expected_rows()
        with TemporaryDirectory() as tmp:
            target = Path(tmp) / "parts"
            con = self.query.to_duckdb(
                target,
                size=len(expected),
                batch_size=2,
                table="results314",
                parallel=True,
                page_size=1,
                max_workers=2,
            )
            try:
                count = con.execute("select count(*) from results314").fetchone()[0]
            finally:
                con.close()
        self.assertEqual(count, len(expected))

    @unittest.skipIf(query_module.duckdb is None, "duckdb optional dependency is not installed")
    def test_to_duckdb_rejects_invalid_table_name(self):
        with self.assertRaises(ValueError):
            self.query.to_duckdb("ignored", size=1, table="results;drop")


if __name__ == "__main__":  # pragma: no cover
    server = TestServer()
    server.start()
    time.sleep(0.1)  # Avoid race conditions with the server
    unittest.main()
    server.shutdown()
