import os


def get_workspace_id():
    return os.environ.get("INTUNED_WORKSPACE_ID")


def get_project_id():
    return os.environ.get("INTUNED_INTEGRATION_ID", os.environ.get("INTUNED_PROJECT_ID"))


def get_functions_domain():
    return os.environ.get("FUNCTIONS_DOMAIN")


def get_browser_type():
    return os.environ.get("BROWSER_TYPE")


def get_api_key():
    return os.environ.get(api_key_env_var_key)


def get_is_running_in_cli():
    return os.environ.get(cli_env_var_key) == "true"


def get_is_auth_session_recorder_enabled():
    return os.environ.get("INTUNED_AUTH_SESSION_RECORDER_ENABLED") == "true"


def get_user_agent_override():
    return os.environ.get("__PLAYWRIGHT_USER_AGENT_OVERRIDE")


def get_ignore_http_errors():
    """Get ignore_http_errors setting from environment variable."""
    env_value = os.environ.get("IGNORE_HTTP_ERRORS")
    if env_value is None:
        return None
    return env_value.lower() in ("true", "1", "yes")


def get_auth_token():
    return os.environ.get(auth_token_env_var_key)


cli_env_var_key = "INTUNED_CLI"
workspace_env_var_key = "INTUNED_WORKSPACE_ID"
project_env_var_key = "INTUNED_PROJECT_ID"
api_key_env_var_key = "INTUNED_API_KEY"
auth_token_env_var_key = "INTUNED_AUTH_TOKEN"
