from typing import Any
from typing import AsyncContextManager
from typing import TYPE_CHECKING

from _intuned_runtime_internal.types.run_types import CDPRunOptions
from _intuned_runtime_internal.types.run_types import ProxyConfig
from _intuned_runtime_internal.types.run_types import StandaloneRunOptions
from intuned_cli.utils.browser_state import resolve_cdp_target_id

if TYPE_CHECKING:
    from playwright.async_api import BrowserContext

_current_browser_context_manager: AsyncContextManager[Any] | None = None
_current_browser_context: "BrowserContext | None" = None


async def get_cli_run_options(
    headless: bool = False,
    proxy: ProxyConfig | None = None,
    keep_browser_open: bool = False,
    cdp_url: str | None = None,
    cdp_tab_id: str | None = None,
    ignore_http_errors: bool = False,
):
    global _current_browser_context_manager, _current_browser_context

    # If ignore_http_errors is not explicitly set, check config
    if not ignore_http_errors:
        from _intuned_runtime_internal.browser.helpers import get_ignore_http_errors_from_config

        ignore_http_errors = await get_ignore_http_errors_from_config()

    if cdp_url is not None:
        await close_cli_browser()
        return CDPRunOptions(
            cdp_address=cdp_url,
            cdp_target_id=await resolve_cdp_target_id(cdp_url, cdp_tab_id),
            ignore_http_errors=ignore_http_errors,
        )
    if not keep_browser_open:
        return StandaloneRunOptions(
            headless=headless,
            proxy=proxy,
            ignore_http_errors=ignore_http_errors,
        )
    from playwright.async_api import ProxySettings

    from _intuned_runtime_internal.browser.launch_chromium import launch_chromium
    from _intuned_runtime_internal.run.playwright_context import get_random_free_port

    await close_cli_browser()
    port = await get_random_free_port()
    acm = launch_chromium(
        headless=headless,
        cdp_port=port,
        proxy=ProxySettings(
            **proxy.model_dump(by_alias=True),
        )
        if proxy
        else None,
        ignore_http_errors=ignore_http_errors,
    )

    _current_browser_context_manager = acm
    _current_browser_context, _ = await _current_browser_context_manager.__aenter__()

    return CDPRunOptions(
        cdp_address=f"http://localhost:{port}",
        ignore_http_errors=ignore_http_errors,
    )


def is_cli_browser_launched():
    global _current_browser_context_manager
    return _current_browser_context_manager is not None and _current_browser_context is not None


async def close_cli_browser():
    global _current_browser_context_manager, _current_browser_context
    if _current_browser_context_manager is not None:
        await _current_browser_context_manager.__aexit__(None, None, None)
        _current_browser_context_manager = None
    if _current_browser_context is not None:
        _current_browser_context = None
