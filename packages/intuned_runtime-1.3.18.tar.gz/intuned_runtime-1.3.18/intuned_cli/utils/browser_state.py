"""
Browser utilities for CLI commands.
"""

from _intuned_runtime_internal.browser.tabs import get_cdp_tabs
from intuned_cli.utils.error import CLIError


async def resolve_cdp_target_id(
    cdp_url: str,
    cdp_tab_id: str | None,
) -> str | None:
    """
    Resolve the CDP target ID based on the provided CDP URL and tab ID.

    Args:
        cdp_url: CDP URL of the browser instance
        cdp_tab_id: 4-character tab ID to look up
    Returns:
        Full CDP target ID, or None if not applicable
    """
    if cdp_tab_id is not None:
        return await get_cdp_target_id_from_tab_id(cdp_url, cdp_tab_id)
    else:
        return await get_first_tab_cdp_target_id(cdp_url)


async def get_cdp_target_id_from_tab_id(cdp_address: str, tab_id: str) -> str:
    """
    Look up full CDP target ID from a 4-character tab ID using live CDP data.

    Args:
        cdp_address: CDP address of the browser
        tab_id: 4-character tab ID to look up

    Returns:
        Full CDP target ID

    Raises:
        CLIError: If the tab is not found
    """
    try:
        cdp_tabs = await get_cdp_tabs(cdp_address)
    except Exception as e:
        raise CLIError(f"Failed to fetch tabs from browser: {e}") from e

    for tab in cdp_tabs:
        if tab["id"].startswith(tab_id):
            return tab["id"]

    raise CLIError(f"Tab '{tab_id}' not found")


async def get_first_tab_cdp_target_id(cdp_address: str) -> str | None:
    """
    Get the CDP target ID of the first tab.

    Args:
        cdp_address: CDP address of the browser

    Returns:
        Full CDP target ID of the first tab, or None if no tabs
    """
    try:
        cdp_tabs = await get_cdp_tabs(cdp_address)
        if cdp_tabs:
            return cdp_tabs[0]["id"]
        return None
    except Exception:
        return None
