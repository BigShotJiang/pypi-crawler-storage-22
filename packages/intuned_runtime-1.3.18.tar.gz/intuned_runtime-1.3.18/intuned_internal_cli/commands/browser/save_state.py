import json
import os

from _intuned_runtime_internal.browser import launch_browser
from _intuned_runtime_internal.browser.helpers import get_ignore_http_errors_from_config
from _intuned_runtime_internal.browser.storage_state import get_storage_state
from intuned_internal_cli.utils.wrapper import internal_cli_command


@internal_cli_command
async def browser__save_state(
    *,
    cdp_address: str,
    output_path: str,
):
    """
    Load an AuthSession to a browser.

    Args:
        cdp_address (str): The CDP address of the browser to save the state from.
        output_path (str): Path to save browser state to.
    """
    ignore_http_errors = await get_ignore_http_errors_from_config()

    async with launch_browser(
        cdp_address=cdp_address,
        ignore_http_errors=ignore_http_errors,
    ) as (context, _):
        storage_state = await get_storage_state(context)

        path = os.path.join(os.getcwd(), output_path)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w") as f:
            json.dump(storage_state.model_dump(by_alias=True), f, indent=2)
