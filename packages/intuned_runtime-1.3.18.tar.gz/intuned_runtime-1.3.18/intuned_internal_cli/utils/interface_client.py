import asyncio
import json
import os
import socket
import struct
from abc import abstractmethod
from collections.abc import AsyncGenerator
from typing import Any
from typing import override


class InterfaceClient:
    @abstractmethod
    async def connect(self) -> None: ...

    @abstractmethod
    async def send_message(self, data: Any): ...

    @abstractmethod
    def receive_messages(self) -> AsyncGenerator[Any, None]: ...

    @abstractmethod
    def close(self): ...


class SocketClient(InterfaceClient):
    LENGTH_HEADER_LENGTH = 4

    def __init__(self, sock: socket.socket):
        self.socket = sock

    @override
    async def send_message(self, data: Any):
        # Convert data to JSON string and encode to bytes
        data_to_send = json.dumps(data).encode()
        # Calculate length
        length = len(data_to_send)
        # Pack length as 4-byte big-endian unsigned int
        length_header = struct.pack(">I", length)
        # Send length header followed by data
        return await asyncio.to_thread(self.socket.sendall, length_header + data_to_send)

    @override
    async def receive_messages(self):
        buffer = bytearray()

        while True:
            try:
                # First, ensure we have the length header
                while len(buffer) < self.LENGTH_HEADER_LENGTH:
                    chunk = await asyncio.to_thread(self.socket.recv, 4096)
                    if not chunk:
                        return
                    buffer.extend(chunk)

                # Read the message length
                length = struct.unpack(">I", buffer[: self.LENGTH_HEADER_LENGTH])[0]
                total_length = length + self.LENGTH_HEADER_LENGTH

                # Read the full message
                while len(buffer) < total_length:
                    chunk = await asyncio.to_thread(self.socket.recv, 4096)
                    if not chunk:
                        return
                    buffer.extend(chunk)

                # Extract the JSON data
                data = buffer[self.LENGTH_HEADER_LENGTH : total_length]
                # Remove processed data from buffer
                buffer = buffer[total_length:]
                # Parse and yield the JSON data
                yield json.loads(data.decode())

            except OSError:
                break

    @override
    def close(self):
        if not self.socket:
            return
        self.socket.shutdown(socket.SHUT_RDWR)
        self.socket.close()


class UnixSocketClient(SocketClient):
    def __init__(self, socket_path: str):
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        super().__init__(sock)
        self.socket_path = socket_path

    @override
    async def connect(self):
        await asyncio.to_thread(self.socket.connect, self.socket_path)


class TCPSocketClient(SocketClient):
    def __init__(self, host: str, port: int):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        super().__init__(sock)
        self.host = host
        self.port = port

    @override
    async def connect(self):
        await asyncio.to_thread(self.socket.connect, (self.host, self.port))


class JSONLFileClient(InterfaceClient):
    def __init__(self, socket_path: str):
        self.socket_path = socket_path
        self.fp = None

    @override
    async def connect(self):
        if not os.path.exists(self.socket_path):
            raise Exception(f"JSONL file does not exist: {self.socket_path}")
        self.fp = open(self.socket_path, "r+b", buffering=0)

    @override
    def receive_messages(self):
        import json

        async def generator():
            if self.fp is None:
                raise Exception("Socket not connected")
            while True:
                line = self.fp.readline()
                if not line:
                    break
                yield json.loads(line.decode("utf-8"))

        return generator()

    @override
    async def send_message(self, data: Any):
        print("[JSONLFileClient] Sending message", data)

    def close(self):
        if not self.fp:
            return
        self.fp.close()
