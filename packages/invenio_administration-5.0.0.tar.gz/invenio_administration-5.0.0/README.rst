..
    Copyright (C) 2022 CERN.

    invenio-administration is free software; you can redistribute it and/or
    modify it under the terms of the MIT License; see LICENSE file for more
    details.

========================
 invenio-administration
========================

.. image:: https://github.com/inveniosoftware/invenio-administration/workflows/CI/badge.svg
        :target: https://github.com/inveniosoftware/invenio-administration/actions?query=workflow%3ACI

.. image:: https://img.shields.io/github/tag/inveniosoftware/invenio-administration.svg
        :target: https://github.com/inveniosoftware/invenio-administration/releases

.. image:: https://img.shields.io/pypi/dm/invenio-administration.svg
        :target: https://pypi.python.org/pypi/invenio-administration

.. image:: https://img.shields.io/github/license/inveniosoftware/invenio-administration.svg
        :target: https://github.com/inveniosoftware/invenio-administration/blob/master/LICENSE

Invenio module providing extensible administration panel.

TODO: Please provide feature overview of module

Further documentation is available on
https://invenio-administration.readthedocs.io/
