..
    Copyright (C) 2025 CERN.

    Invenio-Audit-Logs is free software; you can redistribute it and/or
    modify it under the terms of the MIT License; see LICENSE file for more
    details.

====================
 Invenio-Audit-Logs
====================

.. image:: https://github.com/inveniosoftware/invenio-audit-logs/workflows/CI/badge.svg
        :target: https://github.com/inveniosoftware/invenio-audit-logs/actions?query=workflow%3ACI

.. image:: https://img.shields.io/github/tag/inveniosoftware/invenio-audit-logs.svg
        :target: https://github.com/inveniosoftware/invenio-audit-logs/releases

.. image:: https://img.shields.io/pypi/dm/invenio-audit-logs.svg
        :target: https://pypi.python.org/pypi/invenio-audit-logs

.. image:: https://img.shields.io/github/license/inveniosoftware/invenio-audit-logs.svg
        :target: https://github.com/inveniosoftware/invenio-audit-logs/blob/master/LICENSE

Module providing audit logging features for Invenio.

TODO: Please provide feature overview of module

Further documentation is available on
https://invenio-audit-logs.readthedocs.io/
