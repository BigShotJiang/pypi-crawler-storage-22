..
    Copyright (C) 2020 CERN.

    Invenio-Banners is free software; you can redistribute it and/or modify
    it under the terms of the MIT License; see LICENSE file for more details.

=================
 Invenio-Banners
=================

.. image:: https://img.shields.io/travis/inveniosoftware/invenio-banners.svg
        :target: https://travis-ci.org/inveniosoftware/invenio-banners

.. image:: https://img.shields.io/coveralls/inveniosoftware/invenio-banners.svg
        :target: https://coveralls.io/r/inveniosoftware/invenio-banners

.. image:: https://img.shields.io/github/tag/inveniosoftware/invenio-banners.svg
        :target: https://github.com/inveniosoftware/invenio-banners/releases

.. image:: https://img.shields.io/pypi/dm/invenio-banners.svg
        :target: https://pypi.python.org/pypi/invenio-banners

.. image:: https://img.shields.io/github/license/inveniosoftware/invenio-banners.svg
        :target: https://github.com/inveniosoftware/invenio-banners/blob/master/LICENSE

Create and show banners with useful messages to users.

Further documentation is available on
https://invenio-banners.readthedocs.io/
