..
    This file is part of Invenio.
    Copyright (C) 2015-2022 CERN.

    Invenio is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.


Authors
=======

Static pages module for Invenio.

- Adrian Baran <bouzlibop@gmail.com>
- Alizee Pace <alizee.pace@gmail.com>
- Eirini Psallida <eirini.psallida@cern.ch>
- Javier Martin Montull <javier.martin.montull@cern.ch>
- Jiri Kuncar <jiri.kuncar@cern.ch>
- Lars Holm Nielsen <lars.holm.nielsen@cern.ch>
- Leonardo Rossi <leonardo.r@cern.ch>
- Sami Hiltunen <sami.mikael.hiltunen@cern.ch>
- Tibor Simko <tibor.simko@cern.ch>
- Yoan Blanc <yoan.blanc@cern.ch>
