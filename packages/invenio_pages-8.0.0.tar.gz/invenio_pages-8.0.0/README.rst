..
    This file is part of Invenio.
    Copyright (C) 2015-2022 CERN.
    Invenio is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.

===============
 Invenio-Pages
===============

.. image:: https://github.com/inveniosoftware/invenio-pages/workflows/CI/badge.svg
        :target: https://github.com/inveniosoftware/invenio-pages/actions?query=workflow%3ACI

.. image:: https://img.shields.io/coveralls/inveniosoftware/invenio-pages.svg
        :target: https://coveralls.io/r/inveniosoftware/invenio-pages

.. image:: https://img.shields.io/pypi/v/invenio-pages.svg
        :target: https://pypi.org/pypi/invenio-pages

Static pages module for Invenio.

*This is an experimental developer preview release.*

* Free software: MIT license
* Documentation: https://invenio-pages.readthedocs.io/
