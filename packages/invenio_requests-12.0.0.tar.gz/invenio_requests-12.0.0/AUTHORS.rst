..
    Copyright (C) 2021 CERN.

    Invenio-Requests is free software; you can redistribute it and/or
    modify it under the terms of the MIT License; see LICENSE file for more
    details.

Authors
=======

Invenio module for generic and customizable requests.

- CERN <info@inveniosoftware.org>
- TU Wien <tudata@tuwien.ac.at>
- KTH Royal Institute of Technology <info@kth.se>
