# -*- coding: utf-8 -*-
#
# Copyright (C) 2021 - 2022 TU Wien.
#
# Invenio-Requests is free software; you can redistribute it and/or modify
# it under the terms of the MIT License; see LICENSE file for more details.

"""Systemfields for request records."""

from .computed import LastActivity, LastReply
from .entity_reference import EntityReferenceField
from .event_type import EventTypeField
from .expired_state import ExpiredStateCalculatedField
from .identity import IdentityField
from .request_state import RequestStateCalculatedField
from .request_type import RequestTypeField
from .status import RequestStatusField

__all__ = (
    "EntityReferenceField",
    "EventTypeField",
    "ExpiredStateCalculatedField",
    "IdentityField",
    "LastReply",
    "LastActivity",
    "RequestStateCalculatedField",
    "RequestStatusField",
    "RequestTypeField",
)
