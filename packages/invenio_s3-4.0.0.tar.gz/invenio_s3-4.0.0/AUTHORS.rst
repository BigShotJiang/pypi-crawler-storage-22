..
    Copyright (C) 2018 Esteban J. G. Gabancho.
    Invenio-S3 is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.

Authors
=======

S3 file storage support for Invenio. 

- Esteban J. G. Gabancho <egabancho@gmail.com>
