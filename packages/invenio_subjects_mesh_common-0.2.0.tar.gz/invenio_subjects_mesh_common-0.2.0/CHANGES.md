# Changes

Version 0.2.0 (released 2026-01-28)

- account for NLM quirks
- clean up cli.py implementation

Version 0.1.0 (released 2026-01-27)

- Initial public release
