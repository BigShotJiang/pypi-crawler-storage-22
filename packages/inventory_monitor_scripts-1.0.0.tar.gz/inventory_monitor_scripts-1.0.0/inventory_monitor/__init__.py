"""Inventory Monitor Scripts - SNMP inventory collection for NetBox."""

__version__ = "1.0.0"
__author__ = "Jan Krupa"
