from typing import Any

def stripper(value: Any) -> Any:
    """
    Strips whitespace from string values, returns non-string values unchanged.

    This function checks if the passed value is a string. If it is, it strips
    leading and trailing whitespace and returns the result. If the value is not
    a string, it returns the original value unchanged.

    Args:
        value: Any type of value that might be a string

    Returns:
        The stripped string if input was a string, otherwise the unchanged input value

    Examples:
        >>> stripper("  hello  ")
        'hello'
        >>> stripper(123)
        123
        >>> stripper(None)
        None
    """
    if isinstance(value, str):
        return value.strip()
    return value
