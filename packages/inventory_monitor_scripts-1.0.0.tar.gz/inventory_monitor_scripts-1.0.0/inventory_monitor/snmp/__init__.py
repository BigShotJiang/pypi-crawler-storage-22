"""SNMP handlers for network device inventory collection.

Re-exports all public names so existing imports from ``inventory_monitor.snmp``
continue to work unchanged.
"""

from typing import Dict, Optional

from inventory_monitor.models import SnmpConfig

from .base import ISnmp
from .cisco import SnmpCisco, SnmpCiscoLegacy
from .constants import (
    CISCO_ENTITY_FIELD,
    JUNOS_CHASSIS_FIELD,
    JUNOS_COMPONENT_FIELD,
    OID,
    SROS_CHASSIS_FIELD,
    SROS_HW_CLASS,
    SROS_HW_CLASS_CHASSIS,
    SROS_HW_CLASS_MODULE,
)
from .errors import SENSITIVE_FIELDS, sanitize_snmp_error
from .junos import SnmpJunos
from .sros import SnmpSros

# Platform handler registry: platform name -> SNMP handler class
PLATFORM_HANDLERS: Dict[str, type] = {
    "sros": SnmpSros,
    "junos": SnmpJunos,
}


def get_snmp_handler(platform, snmp_config: Optional[SnmpConfig] = None) -> ISnmp:
    """Factory function to return the appropriate SNMP handler instance based on device platform.

    Args:
        platform: Platform object with a name attribute
        snmp_config: Optional SnmpConfig; falls back to env-loaded config if None

    Returns:
        An SNMP handler class instance appropriate for the platform
    """
    platform_name = platform.name.lower() if platform and platform.name else None
    handler_cls = PLATFORM_HANDLERS.get(platform_name, SnmpCisco)
    return handler_cls(snmp_config=snmp_config)


__all__ = [
    "CISCO_ENTITY_FIELD",
    "ISnmp",
    "JUNOS_CHASSIS_FIELD",
    "JUNOS_COMPONENT_FIELD",
    "OID",
    "PLATFORM_HANDLERS",
    "SROS_CHASSIS_FIELD",
    "SROS_HW_CLASS",
    "SROS_HW_CLASS_CHASSIS",
    "SROS_HW_CLASS_MODULE",
    "SnmpCisco",
    "SnmpCiscoLegacy",
    "SnmpJunos",
    "SnmpSros",
    "SENSITIVE_FIELDS",
    "sanitize_snmp_error",
    "get_snmp_handler",
]
