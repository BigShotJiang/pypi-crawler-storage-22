"""OID constants and named field mappings for SNMP handlers."""

from typing import Dict

# Define OID constants for better readability and maintenance
OID = {
    "CISCO_LEGACY_BASE": ".1.3.6.1.4.1.9.3.6",
    "CISCO_LEGACY_CHASSIS": ".1.3.6.1.4.1.9.3.6.3",
    "CISCO_LEGACY_COMPONENT": ".1.3.6.1.4.1.9.3.6.11.1",
    "CISCO_ENTITY_MIB": ".1.3.6.1.2.1.47.1.1.1.1",
    "JUNOS_CHASSIS": ".1.3.6.1.4.1.2636.3.1",
    "JUNOS_COMPONENT": ".1.3.6.1.4.1.2636.3.1.8.1",
    "SROS_BASE": ".1.3.6.1.4.1.6527.3.1.2.2",
    "SROS_CHASSIS": ".1.3.6.1.4.1.6527.3.1.2.2.1.8.1",
    "SROS_PORT": ".1.3.6.1.4.1.6527.3.1.2.2.4.2.1",
    "SYS_DESCR": ".1.3.6.1.2.1.1.1.0",
}

# Named field constants for Cisco Entity MIB OID sub-indexes
CISCO_ENTITY_FIELD: Dict[str, str] = {
    "DESCR": "2",
    "VENDOR_TYPE": "3",
    "CONTAINED_IN": "4",
    "CLASS": "5",
    "PARENT_REL_POS": "6",
    "NAME": "7",
    "HW_REV": "8",
    "FW_REV": "9",
    "SW_REV": "10",
    "SERIAL_NUM": "11",
    "MFG_NAME": "12",
    "MODEL_NAME": "13",
    "ALIAS": "14",
    "ASSET_ID": "15",
    "IS_FRU": "16",
}

# Named field constants for SROS OID sub-indexes
SROS_CHASSIS_FIELD: Dict[str, str] = {
    "MODEL": "4.1",
    "SERIAL": "5.1",
    "PORT_NAME": "6.1",
    "HW_CLASS": "7.1",
    "COMPONENT_NAME": "8.1",
    "PORT_TYPE": "25.1",
    "PORT_SERIAL": "45.1",
    "PORT_MODEL": "46.1",
}

# SROS hardware class values
SROS_HW_CLASS: Dict[int, str] = {
    3: "chassis",
    8: "controlProcessor",
    9: "switchFabric",
    10: "containerModule",
    11: "ioModule",
}

# Hardware classes that map to "chassis" in output
SROS_HW_CLASS_CHASSIS = {3}
# Hardware classes that map to modules ("-") in output
SROS_HW_CLASS_MODULE = {8, 9, 10, 11}

# Named field constants for JunOS OID sub-indexes
JUNOS_CHASSIS_FIELD: Dict[str, str] = {
    "NAME": "2",
    "SERIAL": "3",
}

JUNOS_COMPONENT_FIELD: Dict[str, str] = {
    "DESCR": "6",
    "SERIAL": "7",
    "PART_NUM": "10",
}
