"""SNMP error sanitization utilities."""

# Substrings that may indicate credentials leaked in SNMP error messages
SENSITIVE_FIELDS = ("password", "community", "auth_password", "privacy_password")


def sanitize_snmp_error(error: Exception) -> str:
    """Return error message with potential credential values redacted."""
    msg = str(error)
    # easysnmp errors typically don't embed credentials, but be defensive
    for field in SENSITIVE_FIELDS:
        if field in msg.lower():
            msg = "SNMP error (details redacted for security)"
            break
    return msg
