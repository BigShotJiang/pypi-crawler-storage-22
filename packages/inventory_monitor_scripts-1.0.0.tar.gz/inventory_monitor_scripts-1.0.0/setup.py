from setuptools import find_packages, setup
import os

# Read version from package __init__.py
def get_version():
    init_path = os.path.join(os.path.dirname(__file__), "inventory_monitor", "__init__.py")
    with open(init_path) as f:
        for line in f:
            if line.startswith("__version__"):
                return line.split("=")[1].strip().strip('"').strip("'")
    raise RuntimeError("Unable to find version string in inventory_monitor/__init__.py")

# Read long description from README
def get_long_description():
    readme_path = os.path.join(os.path.dirname(__file__), "README.md")
    if os.path.exists(readme_path):
        with open(readme_path, encoding="utf-8") as f:
            return f.read()
    return ""

setup(
    name="inventory_monitor_scripts",
    version=get_version(),
    author="Jan Krupa",
    description="Scan devices via SNMP and store its inventory to NetBox",
    long_description=get_long_description(),
    long_description_content_type="text/markdown",
    url="https://github.com/Kani999/inventory_monitor_scripts.git",
    project_urls={
        "Bug Tracker": "https://github.com/Kani999/inventory_monitor_scripts.git/issues",
        "Source Code": "https://github.com/Kani999/inventory_monitor_scripts.git",
    },
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: System Administrators",
        "Intended Audience :: Telecommunications Industry",
        "Topic :: System :: Monitoring",
        "Topic :: System :: Networking :: Monitoring",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
    keywords="netbox snmp inventory network monitoring cisco juniper nokia",
    python_requires=">=3.7",
    install_requires=[
        "easysnmp>=0.2.6,<1.0",
        "pynetbox>=7.0,<8.0",
        "python-dotenv>=1.0,<2.0",
        "joblib>=1.3,<2.0",
        "loguru>=0.7,<1.0",
        "click>=8.0,<9.0",
    ],
    extras_require={
        "test": ["pytest>=7.0,<9.0"],
    },
    packages=find_packages(),
    include_package_data=True,
    zip_safe=False,
)
