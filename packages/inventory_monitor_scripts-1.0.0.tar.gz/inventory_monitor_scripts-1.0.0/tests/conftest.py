"""Pytest configuration and shared fixtures.

Mocks the easysnmp C-extension module so tests can run without
net-snmp system libraries installed.
"""
import sys
from types import ModuleType
from unittest.mock import MagicMock

# Create mock easysnmp modules before any inventory_monitor imports
_easysnmp = ModuleType("easysnmp")
_easysnmp.Session = MagicMock
_easysnmp_exceptions = ModuleType("easysnmp.exceptions")


class _EasySNMPError(Exception):
    pass


_easysnmp_exceptions.EasySNMPError = _EasySNMPError
_easysnmp.exceptions = _easysnmp_exceptions

# Only inject mocks if easysnmp is not actually available
try:
    import easysnmp  # noqa: F401
except ImportError:
    sys.modules["easysnmp"] = _easysnmp
    sys.modules["easysnmp.exceptions"] = _easysnmp_exceptions
