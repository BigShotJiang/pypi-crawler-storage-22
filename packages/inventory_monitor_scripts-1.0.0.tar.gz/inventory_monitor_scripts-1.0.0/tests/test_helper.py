from inventory_monitor.helper import stripper


def test_stripper_strips_whitespace():
    assert stripper("  hello  ") == "hello"


def test_stripper_returns_non_string_unchanged():
    assert stripper(123) == 123
    assert stripper(None) is None
    assert stripper([1, 2]) == [1, 2]


def test_stripper_empty_string():
    assert stripper("") == ""
    assert stripper("   ") == ""
