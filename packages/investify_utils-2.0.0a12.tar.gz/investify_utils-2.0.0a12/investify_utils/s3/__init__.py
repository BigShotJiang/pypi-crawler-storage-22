"""
S3-compatible object storage client.

Sync client (boto3):
    from investify_utils.s3 import S3Client

Async client (aioboto3):
    from investify_utils.s3 import AsyncS3Client
"""


def __getattr__(name: str):
    """Lazy import to avoid loading boto3/aioboto3 if not needed."""
    if name == "S3Client":
        from investify_utils.s3.sync_client import S3Client

        return S3Client
    if name == "AsyncS3Client":
        from investify_utils.s3.async_client import AsyncS3Client

        return AsyncS3Client
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = ["S3Client", "AsyncS3Client"]
