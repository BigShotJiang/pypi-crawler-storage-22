"""Technical analysis, ratios, and scoring utilities for InvestorMate."""
