"""Core classes for InvestorMate."""
