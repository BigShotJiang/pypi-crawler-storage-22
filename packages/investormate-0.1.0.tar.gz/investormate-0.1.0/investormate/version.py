"""Version information for InvestorMate."""

__version__ = "0.1.0"
