"""Data fetching and parsing utilities for InvestorMate."""
