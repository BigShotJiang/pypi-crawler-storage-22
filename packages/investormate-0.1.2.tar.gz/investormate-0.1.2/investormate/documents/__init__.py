"""Document extraction and processing utilities for InvestorMate."""
