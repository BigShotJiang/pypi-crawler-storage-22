"""Utility functions and helpers for InvestorMate."""
