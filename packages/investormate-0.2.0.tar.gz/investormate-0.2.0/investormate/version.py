"""Version information for InvestorMate."""

__version__ = "0.2.0"
