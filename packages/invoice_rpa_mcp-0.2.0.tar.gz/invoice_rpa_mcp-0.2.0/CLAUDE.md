# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 프로젝트 개요

입력 Excel 파일에서 데이터를 추출하여 표준화된 출력 템플릿으로 매핑하는 인보이스 자동화 RPA 시스템. DRB Industrial의 미국, 일본, 인도, 유럽 고객 인보이스를 처리한다.

## 명령어

```bash
# 의존성 설치
uv sync

# standalone 실행 (기존 방식)
uv run python invoice_rpa_mcp/main.py

# MCP 서버 실행
uv run invoice-rpa-mcp
```

두 가지 진입점이 있다:
- **`invoice_rpa_mcp/main.py`** - standalone 배치 실행. `variation_data/process_config.json`에서 경로 설정
- **`invoice_rpa_mcp/mcp_server.py`** - MCP 서버. 환경변수(`INVOICE_INPUT_FOLDER`, `INVOICE_OUTPUT_FOLDER`, `INVOICE_CUSTOMER_MASTER_PATH`, `INVOICE_ITEM_LIST_PATH`)로 경로 설정, 미설정 시 프로젝트 기본값 사용

테스트 스위트는 없다.

## 아키텍처

### 처리 파이프라인 (`InvoiceProcessor`가 오케스트레이션)

1. **파일 탐색** - 입력 디렉토리에서 `.xlsx` 파일 스캔 (`~$` 임시 파일 제외)
2. **고객 식별** (`CustomerIdentifier`) - 파일명 패턴 `Contract No.DRBVN XXXXX (DD-MM-YYYY) 고객명-위치.xlsx`에서 고객명 추출, `config/customer_patterns.json` 별칭과 매칭
3. **고객 마스터 조회** (`VariationDataLoader`) - `customer_master.csv`에서 고객 정보 로드
4. **인보이스 번호 생성** (`SequenceManager`) - 시퀀스 패턴 고객(예: `Caterpillar_2026_1`)은 자동 증가, 비시퀀스 고객은 빈값 처리. 상태는 `.invoice_sequences.json`에 저장
5. **템플릿 선택** (`TemplateSelector`) - US 고객은 `OUTPUT_BLANKFILE_US_V2.2.xlsx`, 나머지는 `OUTPUT_BLANKFILE_V2.xlsx`
6. **데이터 추출** (`DataExtractor`) - 입력 시트(`I.V & P.L`, `Contract`)에서 인보이스 메타데이터, 운송 정보, 라인 아이템 추출
7. **데이터 매핑** (`Mapper`) - 추출 데이터 + 고객 마스터 데이터를 출력 템플릿의 `I.V`, `P.L` 시트에 기입
8. **Detail P.L 복사** (`DetailPLHandler`) - 입력의 `Detail P.L` 시트를 출력으로 복사, 빈 행 숨기기 및 무게 데이터 추출
9. **출력** - 정규화된 파일명으로 저장, `.invoice_history.json`에 처리 완료 기록

### 설정 기반 설계

모든 셀 위치, 시트 이름, 검색 파라미터는 하드코딩 없이 JSON 설정 파일로 관리한다. 이것이 핵심 설계 원칙이다.

- **`config/cell_references.json`** - 입출력 셀 위치를 primary/fallback으로 매핑 (예: 인보이스 번호를 `D5` → `D4` 순으로 시도)
- **`config/sheet_config.json`** - 시트 이름 별칭으로 유연하게 매칭 (후행 공백, 대소문자 변형 처리). 검색 우선순위: 정확 > 대소문자 무시 > 부분 매칭
- **`config/search_config.json`** - 헤더 감지 키워드, 검색 범위, 컬럼 오프셋, 안전 한계값
- **`config/mapping_config.json`** - dot-notation 경로로 `cell_references.json`을 참조하는 필드 매핑 규칙 (예: `output_sheets.invoice_metadata.cells.invoice_number`)
- **`config/customer_patterns.json`** - exact/partial 매치 타입과 exclude 목록이 있는 고객 식별 패턴
- **`config/customer_types.json`** - 지역 분류(US/Japan/India/Europe)와 지역별 행 위치 설정

### 변수 데이터 (`variation_data/`)

CSV 파일에서 로드하는 런타임 데이터. 경로는 `process_config.json`의 `customer_master_path`, `item_list_path`로 커스터마이징 가능하며, 미설정 시 기본 `variation_data/` 디렉토리를 사용한다.

- **`customer_master.csv`** - 고객 상세 정보 (consignee, notify party, incoterms, 인보이스 번호 포맷)
- **`itemList.csv`** - Customer + CODE로 키잉된 제품 카탈로그. 입력 파일의 아이템을 CODE로 매칭하여 SO, PN, TYPE & SIZE, PRICE, CURRENCY를 가져옴

### 주요 유틸리티 클래스

- **`ExcelOperations`** - 별칭 기반 시트 찾기, fallback 체인으로 셀 값 추출, 수식 적용
- **`HeaderDetector`** - 추정 행 위치 근처에서 키워드(CODE, QTY 등) 매칭으로 테이블 헤더 동적 감지
- **`TableMapper`** - 아이템 수에 맞게 행 삽입/삭제, 수식 적용 (AMOUNT = ROUND(QTY * PRICE, 2), SUM 합계), 병합 셀 처리
- **`DuplicateChecker`** - `.invoice_history.json`에 처리 파일 추적하여 중복 처리 방지

### 출력 템플릿 구조

출력 Excel은 3개 시트로 구성: `I.V` (인보이스 + 아이템 테이블), `P.L` (패킹리스트, I.V 셀 참조), `Detail P.L` (입력에서 복사). P.L 수식은 I.V 셀을 참조(예: `=I.V!A36`)하며, 아이템 행 변경 시 동적으로 갱신된다. US 템플릿은 TOTAL 행을 참조하는 FOB Value/PREMIUM 수식이 추가로 있다.

## 신규 고객 추가 절차

1. `config/customer_patterns.json`에 별칭 추가
2. `config/customer_types.json`의 해당 지역에 추가
3. `variation_data/customer_master.csv`에 행 추가
4. `variation_data/itemList.csv`에 제품 항목 추가

## 언어 규칙

코드 주석과 로그 메시지는 한국어/영어를 혼용한다. 커밋 메시지는 conventional commit prefix(fix, chore 등)와 한국어 설명을 사용한다.
