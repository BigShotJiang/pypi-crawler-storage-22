"""Configuration loader for JSON config files"""

import json
from pathlib import Path
from typing import Dict, Any


class ConfigLoader:
    """Load and manage JSON configuration files"""

    def __init__(self, config_dir: Path | None = None):
        """
        Initialize config loader

        Args:
            config_dir: Path to config directory (default: project_root/config)
        """
        if config_dir is None:
            project_root = Path(__file__).parent.parent
            config_dir = project_root / "config"

        self.config_dir = Path(config_dir)

    def load_json(self, filename: str) -> Dict[str, Any]:
        """
        Load JSON configuration file

        Args:
            filename: Name of JSON file (e.g., 'customer_patterns.json')

        Returns:
            Dictionary with configuration data

        Raises:
            FileNotFoundError: If config file doesn't exist
            json.JSONDecodeError: If JSON is invalid
        """
        config_path = self.config_dir / filename

        if not config_path.exists():
            raise FileNotFoundError(f"Config file not found: {config_path}")

        with open(config_path, "r", encoding="utf-8") as f:
            return json.load(f)

    def load_customer_patterns(self) -> Dict[str, Any]:
        """Load customer identification patterns"""
        return self.load_json("customer_patterns.json")

    def load_customer_types(self) -> Dict[str, Any]:
        """Load customer type classification"""
        return self.load_json("customer_types.json")

    def load_mapping_config(self) -> Dict[str, Any]:
        """Load field mapping configuration"""
        return self.load_json("mapping_config.json")

    def load_cell_references(self) -> Dict[str, Any]:
        """Load dynamic cell reference configuration"""
        return self.load_json("cell_references.json")

    def load_search_config(self) -> Dict[str, Any]:
        """Load search ranges and parameters configuration"""
        return self.load_json("search_config.json")

    def load_sheet_config(self) -> Dict[str, Any]:
        """Load sheet name mappings configuration"""
        return self.load_json("sheet_config.json")
