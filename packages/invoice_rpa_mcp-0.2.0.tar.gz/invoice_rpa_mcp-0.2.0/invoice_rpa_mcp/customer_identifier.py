"""Customer identification from filename"""

import re
from typing import Dict, Optional, List
from pathlib import Path


class CustomerNotFoundError(Exception):
    """Raised when customer cannot be identified from filename"""
    pass


class CustomerIdentifier:
    """Extract and match customer from filename"""

    def __init__(self, customer_patterns: Dict, customer_master: List[Dict]):
        """
        Initialize customer identifier

        Args:
            customer_patterns: Customer pattern configuration
            customer_master: Customer master data from CSV
        """
        self.customer_patterns = customer_patterns
        self.customer_master = customer_master

    def extract_customer_from_filename(self, filename: str) -> str:
        """
        Extract customer portion from filename

        Pattern: "Contract No.DRBVN XXXXX (DD-MM-YYYY) CUSTOMER-LOCATION..."
        Returns: "CUSTOMER-LOCATION" part (e.g., "KUBOTA-OSK, JAPAN")

        Args:
            filename: Input filename

        Returns:
            Extracted customer text

        Raises:
            CustomerNotFoundError: If pattern doesn't match
        """
        # Remove path and extension
        filename = Path(filename).stem

        # Pattern: Contract No.DRBVN XXXXX (DD-MM-YYYY) CUSTOMER...
        # Extract everything after date until first (, or ETD
        pattern = r'Contract No\.DRBVN [^(]+\(\d{2}-\d{2}-\d{4}\)\s*(.+?)(?:\(|ETD|$)'
        match = re.search(pattern, filename, re.IGNORECASE)

        if not match:
            raise CustomerNotFoundError(
                f"Cannot extract customer from filename: {filename}"
            )

        extracted = match.group(1).strip()

        # Remove trailing punctuation and spaces
        extracted = re.sub(r'[,\s-]+$', '', extracted)

        return extracted

    def match_customer(self, extracted_text: str) -> str:
        """
        Match extracted text to customer name using patterns

        Args:
            extracted_text: Extracted customer text from filename

        Returns:
            Matched customer name

        Raises:
            CustomerNotFoundError: If no match found
        """
        patterns = self.customer_patterns.get('patterns', [])

        # Try pattern matching with priority
        for pattern in patterns:
            customer_name = pattern['customer']
            aliases = pattern['aliases']
            match_type = pattern['match_type']
            excludes = pattern.get('exclude', [])

            # Check excludes first
            if any(excl.upper() in extracted_text.upper() for excl in excludes):
                continue

            # Try match based on type
            if match_type == "exact":
                # Exact match (case-insensitive)
                if any(alias.upper() == extracted_text.upper() for alias in aliases):
                    return customer_name

            elif match_type == "partial":
                # Partial match (case-insensitive)
                if any(alias.upper() in extracted_text.upper() for alias in aliases):
                    return customer_name

        # Fallback: try direct lookup in customer_master
        for row in self.customer_master:
            customer = row.get('Customer', '').strip()
            if customer and customer.upper() in extracted_text.upper():
                return customer

        raise CustomerNotFoundError(
            f"No customer match found for: {extracted_text}"
        )

    def identify_customer(self, filename: str) -> str:
        """
        Main function: extract and match customer from filename

        Args:
            filename: Input filename

        Returns:
            Matched customer name

        Raises:
            CustomerNotFoundError: If identification fails
        """
        extracted_text = self.extract_customer_from_filename(filename)
        customer_name = self.match_customer(extracted_text)
        return customer_name

    def get_customer_info(self, customer_name: str) -> Optional[Dict[str, str]]:
        """
        Get customer information from customer_master

        Args:
            customer_name: Customer name

        Returns:
            Customer data dictionary or None if not found
        """
        for row in self.customer_master:
            if row.get('Customer', '').strip() == customer_name.strip():
                return row
        return None
