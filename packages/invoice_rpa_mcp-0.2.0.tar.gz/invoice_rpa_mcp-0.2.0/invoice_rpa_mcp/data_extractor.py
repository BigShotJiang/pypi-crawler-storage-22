"""Extract data from input Excel files"""

import openpyxl
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
from openpyxl.utils import get_column_letter
from invoice_rpa_mcp.utils.excel_helper import get_cell_value_safe, get_merged_cell_value
from invoice_rpa_mcp.utils.excel_operations import ExcelOperations
from invoice_rpa_mcp.utils.header_detector import HeaderDetector


class DataExtractor:
    """Extract data from input Excel files with variable row positions"""

    def __init__(
        self,
        row_positions: Dict[str, int],
        cell_references: Dict[str, Any] | None = None,
        search_config: Dict[str, Any] | None = None,
        sheet_config: Dict[str, Any] | None = None,
    ):
        """
        Initialize data extractor

        Args:
            row_positions: Row position configuration for customer type
            cell_references: Dynamic cell reference configuration
            search_config: Search ranges and parameters configuration
            sheet_config: Sheet name mappings configuration
        """
        self.row_positions = row_positions
        self.cell_references = cell_references or {}
        self.search_config = search_config or {}
        self.sheet_config = sheet_config or {}
        self.excel_ops = ExcelOperations(sheet_config)
        self.header_detector = HeaderDetector(search_config)

    def extract_all_data(self, input_file_path: Path) -> Dict[str, Any]:
        """
        Extract all data from input file

        Args:
            input_file_path: Path to input Excel file

        Returns:
            Dictionary with all extracted data
        """
        # Load workbook with data_only=True to get calculated formula values
        wb = openpyxl.load_workbook(input_file_path, data_only=True)

        data = {
            "invoice_metadata": self.extract_invoice_metadata(wb),
            "shipping_info": self.extract_shipping_info(wb),
            "items": self.extract_items(wb),
            "marks_and_numbers": self.extract_marks_and_numbers(wb),
        }

        wb.close()
        return data

    def extract_invoice_metadata(self, wb) -> Dict[str, Any]:
        """
        Extract invoice number, date, and other metadata using dynamic configuration

        Args:
            wb: Workbook object

        Returns:
            Dictionary with invoice metadata
        """
        # Get sheet name from config or fallback to default
        sheet_name = self.excel_ops.get_sheet_name_config("shipping_info")

        try:
            ws = self.excel_ops.find_sheet(wb, sheet_name)
        except ValueError as e:
            raise e

        metadata = {}

        # Use dynamic cell references if available
        if self.cell_references and "input_sheets" in self.cell_references:
            cells_config = self.cell_references["input_sheets"]["invoice_metadata"][
                "cells"
            ]

            metadata["invoice_number"] = self.excel_ops.get_cell_with_fallback(
                ws, cells_config["invoice_number"]
            )
            metadata["invoice_date"] = self.excel_ops.get_cell_with_fallback(
                ws, cells_config["invoice_date"]
            )
            metadata["exporter"] = self.excel_ops.get_cell_with_fallback(
                ws, cells_config["exporter"]
            )
            metadata["importer"] = self.excel_ops.get_cell_with_fallback(
                ws, cells_config["importer"]
            )

            # Consignee needs merged cell handling
            metadata["consignee"] = self.excel_ops.get_merged_cell_with_fallback(
                ws, cells_config["consignee"]
            )
        else:
            # Fallback to hardcoded values
            metadata["invoice_number"] = get_cell_value_safe(
                ws, "D5"
            ) or get_cell_value_safe(ws, "D4")
            metadata["invoice_date"] = get_cell_value_safe(
                ws, "H5"
            ) or get_cell_value_safe(ws, "H4")
            metadata["exporter"] = get_cell_value_safe(ws, "A5")
            metadata["importer"] = get_cell_value_safe(ws, "A11")
            metadata["consignee"] = get_merged_cell_value(
                ws, "A17"
            ) or get_merged_cell_value(ws, "A16")

        return metadata

    def extract_shipping_info(self, wb) -> Dict[str, Any]:
        """
        Extract shipping information using dynamic configuration

        Args:
            wb: Workbook object

        Returns:
            Dictionary with shipping info
        """
        # Get sheet name from config or fallback to default
        sheet_name = self.excel_ops.get_sheet_name_config("invoice_metadata")

        try:
            ws = self.excel_ops.find_sheet(wb, sheet_name)
        except ValueError as e:
            raise e

        shipping_info = {}

        # Use dynamic cell references if available
        if self.cell_references and "input_sheets" in self.cell_references:
            cells_config = self.cell_references["input_sheets"]["shipping_info"][
                "cells"
            ]

            shipping_info["port_of_loading"] = self.excel_ops.get_cell_with_fallback(
                ws, cells_config["port_of_loading"]
            )
            shipping_info["final_destination"] = self.excel_ops.get_cell_with_fallback(
                ws, cells_config["final_destination"]
            )
            shipping_info["carrier"] = self.excel_ops.get_cell_with_fallback(
                ws, cells_config["carrier"]
            )
            shipping_info["sailing_date"] = self.excel_ops.get_cell_with_fallback(
                ws, cells_config["sailing_date"]
            )
        else:
            # Fallback to hardcoded values
            shipping_info["port_of_loading"] = get_cell_value_safe(
                ws, "A21"
            ) or get_cell_value_safe(ws, "A20")
            shipping_info["final_destination"] = get_cell_value_safe(
                ws, "C21"
            ) or get_cell_value_safe(ws, "C20")
            shipping_info["carrier"] = get_cell_value_safe(
                ws, "A24"
            ) or get_cell_value_safe(ws, "A23")
            shipping_info["sailing_date"] = get_cell_value_safe(
                ws, "C24"
            ) or get_cell_value_safe(ws, "C23")

        return shipping_info

    def _analyze_table_structure(
        self, ws, estimated_row: int
    ) -> Tuple[int, Dict[str, int]]:
        """
        Analyze contract table structure using HeaderDetector

        Args:
            ws: Worksheet
            estimated_row: Estimated start row

        Returns:
            Tuple of (header_row, col_map)
        """
        import logging
        logger = logging.getLogger(__name__)

        # Use HeaderDetector for table analysis
        header_row, col_map = self.header_detector.detect_table_headers(
            ws, estimated_row, required_headers=["code", "quantity"]
        )

        # Fallback if no header found - try broader search
        if header_row == -1:
            logger.warning(
                f"⚠️  Header detection failed at estimated row {estimated_row}. "
                f"Attempting broader search..."
            )
            # Try again with much wider range
            header_row, col_map = self.header_detector.detect_table_headers(
                ws, estimated_row,
                max_columns=20,
                rows_before=10,
                rows_after=15,
                required_headers=["code", "quantity"]
            )

            # If still fails, use estimated but warn
            if header_row == -1:
                logger.error(
                    f"⚠️  Could not detect table headers near row {estimated_row}! "
                    f"Using estimated row as fallback. Results may be incorrect."
                )
                header_row = estimated_row

        # Apply defaults for missing columns
        default_code_col = 3
        if self.search_config and "column_mapping" in self.search_config:
            default_code_col = self.search_config["column_mapping"][
                "default_structure"
            ]["code_column"]

        # If col_map is still empty after detection, try to infer columns
        if not col_map or "code" not in col_map:
            logger.warning("Column mapping is empty or missing CODE. Attempting to infer columns...")

            # Read header row values and try to match manually
            if header_row > 0:
                from openpyxl.utils import get_column_letter
                for col in range(1, 15):
                    cell_val = get_cell_value_safe(
                        ws, f"{get_column_letter(col)}{header_row}"
                    )
                    if cell_val:
                        normalized = str(cell_val).replace('\n', ' ').replace('\r', ' ').replace('\t', ' ')
                        normalized = ' '.join(normalized.split()).strip().upper()
                        logger.info(f"  Column {col}: {normalized}")

                        # Check for CODE patterns
                        if any(kw in normalized for kw in ["CODE", "MATERIAL", "P/N", "ITEM"]):
                            if "code" not in col_map:
                                col_map["code"] = col
                                logger.info(f"  ✓ Inferred CODE column: {col}")

                        # Check for QUANTITY patterns
                        if any(kw in normalized for kw in ["QTY", "QUANTITY", "Q'TY"]):
                            if "quantity" not in col_map:
                                col_map["quantity"] = col
                                logger.info(f"  ✓ Inferred QUANTITY column: {col}")

        # Apply defaults only after inference attempt
        col_map = self.header_detector.apply_column_mapping_defaults(
            col_map, default_code_col
        )

        return header_row, col_map

    def extract_items(self, wb) -> List[Dict[str, Any]]:
        """
        Extract product items from Contract sheet

        Args:
            wb: Workbook object

        Returns:
            List of item dictionaries
        """
        # Get sheet name from config or fallback to default
        # Get sheet name from config or fallback to default
        sheet_name = self.excel_ops.get_sheet_name_config("items")

        # Try to find Contract sheet using flexible search
        try:
            ws = self.excel_ops.find_sheet(wb, sheet_name)
        except ValueError:
            raise ValueError(f"Sheet '{sheet_name}' not found in workbook")

        estimated_start_row = self.row_positions["contract_item_start"]

        # Dynamic analysis
        header_row, col_map = self._analyze_table_structure(ws, estimated_start_row)
        start_row = header_row + 1

        # LOG: What we detected
        import logging
        logger = logging.getLogger(__name__)
        logger.info(f"Table structure detected:")
        logger.info(f"  Estimated row: {estimated_start_row}")
        logger.info(f"  Header row: {header_row}")
        logger.info(f"  Start row: {start_row}")
        logger.info(f"  Column mapping: {col_map}")

        items = []
        current_row = start_row

        # Read until CODE column is empty
        while True:
            code_col_idx = col_map["code"]
            code_col_letter = get_column_letter(code_col_idx)
            raw_code = get_cell_value_safe(ws, f"{code_col_letter}{current_row}")

            # Stop if CODE is empty
            if not raw_code:
                # Double check next row just in case of empty line
                next_code = get_cell_value_safe(
                    ws, f"{code_col_letter}{current_row + 1}"
                )
                if not next_code:
                    break
                else:
                    current_row += 1
                    continue

            # Extract code: if format is "6013448_0325", extract "6013448"
            code = (
                str(raw_code).split("_")[0]
                if raw_code and "_" in str(raw_code)
                else raw_code
            )

            # Helper to retrieve value based on map
            def get_val(field):
                col = col_map.get(field)
                if col:
                    return get_cell_value_safe(
                        ws, f"{get_column_letter(col)}{current_row}"
                    )
                return None

            item = {
                "no": current_row - start_row + 1,
                "code": code,
                "raw_code": raw_code,
                "description": get_val("description"),
                "quantity": get_val("quantity"),
                "unit": get_val("unit"),
                "price": get_val("price"),
                "amount": get_val("amount"),
            }

            items.append(item)
            current_row += 1

            # Safety limit to prevent infinite loop
            max_rows = 100  # default
            if self.search_config and "item_extraction" in self.search_config:
                max_rows = self.search_config["item_extraction"]["safety_limit"][
                    "max_rows"
                ]

            if current_row > start_row + max_rows:
                break

        return items

    def extract_marks_and_numbers(self, wb) -> List[str]:
        """
        I.V & P.L 시트에서 'Marks and numbers of PKGS' 하단 데이터 추출

        Args:
            wb: Workbook object

        Returns:
            List[str]: 추출된 데이터 라인들 (구분선 제외)
        """
        import logging
        logger = logging.getLogger(__name__)

        # Get sheet name from config or fallback to default
        sheet_name = self.excel_ops.get_sheet_name_config("invoice_metadata")

        try:
            ws = self.excel_ops.find_sheet(wb, sheet_name)
        except ValueError as e:
            logger.warning(f"Could not find sheet for marks extraction: {e}")
            return []

        # Find the header cell
        header_cell = self._find_marks_header(ws)
        if not header_cell:
            logger.warning("'Marks and numbers' header not found in input sheet")
            return []

        header_row, header_col = header_cell

        # Get config values
        marks_config = self.search_config.get("marks_and_numbers", {})
        separator_pattern = marks_config.get("separator_pattern", "//")
        max_data_rows = marks_config.get("max_data_rows", 20)

        # "//" 를 종료 마커로 사용하는 간결한 로직
        data_lines = []
        found_separator = False

        for row in range(header_row + 1, header_row + 1 + max_data_rows):
            cell_value = ws.cell(row=row, column=header_col).value
            if cell_value:
                cell_str = str(cell_value).strip()
                data_lines.append(cell_str)

                # "//" 포함된 줄에서 종료 (해당 줄 포함)
                if separator_pattern in cell_str:
                    found_separator = True
                    break

        # "//" 를 찾지 못했으면 marks 데이터 없음
        if not found_separator:
            return []

        if data_lines:
            logger.info(f"Extracted {len(data_lines)} lines from 'Marks and numbers'")

        return data_lines

    def _find_marks_header(self, ws) -> Optional[Tuple[int, int]]:
        """
        시트에서 'Marks and numbers' 헤더 셀 찾기

        Args:
            ws: Worksheet object

        Returns:
            Tuple of (row, column) or None if not found
        """
        marks_config = self.search_config.get("marks_and_numbers", {})
        keywords = marks_config.get("keywords", ["Marks and numbers", "MARKS AND NUMBERS"])
        search_range = marks_config.get("search_range", 50)

        for row in range(1, search_range + 1):
            for col in range(1, 20):
                cell = ws.cell(row=row, column=col)
                if cell.value:
                    cell_str = str(cell.value).strip()
                    if any(kw.lower() in cell_str.lower() for kw in keywords):
                        return (row, col)

        return None
