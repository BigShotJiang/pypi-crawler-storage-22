"""Load variation data from CSV files"""

import csv
from pathlib import Path
from typing import Dict, List, Any, Optional


class VariationDataLoader:
    """Load and manage variation data from CSV files"""

    def __init__(self, variation_data_dir: Path = None,
                 customer_master_path: Path = None,
                 item_list_path: Path = None):
        """
        Initialize variation data loader

        Args:
            variation_data_dir: Path to variation_data directory
            customer_master_path: 커스텀 customer_master.csv 경로 (None이면 기본 위치 사용)
            item_list_path: 커스텀 itemList.csv 경로 (None이면 기본 위치 사용)
        """
        if variation_data_dir is None:
            project_root = Path(__file__).parent.parent
            variation_data_dir = project_root / 'variation_data'

        self.variation_data_dir = Path(variation_data_dir).resolve()
        self.customer_master_path = Path(customer_master_path).resolve() if customer_master_path else None
        self.item_list_path = Path(item_list_path).resolve() if item_list_path else None
        self.customer_master: List[Dict[str, str]] = []
        self.item_list: List[Dict[str, str]] = []

    def _resolve_csv_path(self, filename: str, override_path: Path = None) -> Path:
        """
        CSV 파일 경로를 결정 (커스텀 경로 우선, 없으면 기본 디렉토리)

        Args:
            filename: 기본 CSV 파일명
            override_path: 커스텀 경로 (절대/상대 모두 지원)

        Returns:
            확정된 CSV 파일 경로
        """
        if override_path:
            return override_path
        return self.variation_data_dir / filename

    def load_csv(self, filename: str, override_path: Path = None) -> List[Dict[str, str]]:
        """
        Load CSV file and return list of dictionaries with BOM handling

        Args:
            filename: Name of CSV file
            override_path: 커스텀 경로 (None이면 기본 디렉토리 사용)

        Returns:
            List of dictionaries (one per row)
        """
        csv_path = self._resolve_csv_path(filename, override_path)

        if not csv_path.exists():
            raise FileNotFoundError(f"CSV file not found: {csv_path}")

        data = []
        with open(csv_path, 'r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)

            # Normalize fieldnames to remove BOM and whitespace
            # This handles cases where BOM isn't removed by utf-8-sig
            reader.fieldnames = [col.lstrip('\ufeff').strip() for col in reader.fieldnames]

            for row in reader:
                # Skip empty rows
                if any(value.strip() for value in row.values()):
                    # Normalize row keys to match normalized fieldnames
                    normalized_row = {}
                    for old_key, value in row.items():
                        new_key = old_key.lstrip('\ufeff').strip()
                        normalized_row[new_key] = value
                    data.append(normalized_row)

        return data

    def load_customer_master(self) -> List[Dict[str, str]]:
        """Load customer_master.csv"""
        self.customer_master = self.load_csv('customer_master.csv', self.customer_master_path)
        return self.customer_master

    def load_item_list(self) -> List[Dict[str, str]]:
        """Load itemList.csv"""
        self.item_list = self.load_csv('itemList.csv', self.item_list_path)
        return self.item_list

    def load_all(self):
        """Load all variation data"""
        self.load_customer_master()
        self.load_item_list()

    def find_customer(self, customer_name: str) -> Optional[Dict[str, str]]:
        """
        Find customer in customer_master by name

        Args:
            customer_name: Customer name to search

        Returns:
            Customer data dictionary or None if not found
        """
        for row in self.customer_master:
            if row.get('Customer', '').strip() == customer_name.strip():
                return row
        return None

    def find_items_by_customer(self, customer_name: str) -> List[Dict[str, str]]:
        """
        Find all items for a customer in itemList

        Args:
            customer_name: Customer name

        Returns:
            List of item dictionaries
        """
        items = []
        for row in self.item_list:
            if row.get('Customer', '').strip() == customer_name.strip():
                items.append(row)
        return items

    def find_item_by_code(
        self,
        customer_name: str,
        code: str
    ) -> Optional[Dict[str, str]]:
        """
        Find item by customer and code

        Args:
            customer_name: Customer name
            code: Product CODE

        Returns:
            Item dictionary or None if not found
        """
        for row in self.item_list:
            if (row.get('Customer', '').strip() == customer_name.strip() and
                row.get('CODE', '').strip() == code.strip()):
                return row
        return None
