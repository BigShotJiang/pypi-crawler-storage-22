"""Handle Detail PL sheet copy, empty row hiding, and weight data extraction"""

import openpyxl
from openpyxl.worksheet.worksheet import Worksheet
from copy import copy
from invoice_rpa_mcp.utils.excel_helper import find_sheet
from invoice_rpa_mcp.utils.detail_pl_analyzer import DetailPLAnalyzer
from typing import Optional, Dict, Any
import logging


logger = logging.getLogger(__name__)


class DetailPLHandler:
    """Copy Detail PL sheet from input to output and extract weight data"""

    def __init__(self, logger=None):
        self.logger = logger

    @staticmethod
    def is_row_empty(worksheet: Worksheet, row_idx: int) -> bool:
        """
        Check if all cells in row are empty or whitespace

        Args:
            worksheet: Worksheet to check
            row_idx: Row index (1-based)

        Returns:
            True if row is empty or contains only whitespace
        """
        for cell in worksheet[row_idx]:
            value = cell.value

            if value is not None:
                # Check if string with only whitespace
                if isinstance(value, str):
                    if value.strip():
                        return False  # Has non-whitespace content
                else:
                    return False  # Has non-string value

        return True  # All cells are None or whitespace strings

    @staticmethod
    def _find_weight_columns(worksheet: Worksheet) -> dict:
        """
        Find column indices for N.W, G.W, and CBM headers dynamically.

        Args:
            worksheet: Worksheet to search

        Returns:
            Dictionary with column indices: {'nw': col_idx, 'gw': col_idx, 'cbm': col_idx}
        """
        weight_cols = {'nw': None, 'gw': None, 'cbm': None}

        # Search first 10 rows for headers
        for row_idx in range(1, 11):
            for col_idx in range(1, worksheet.max_column + 1):
                cell_value = worksheet.cell(row=row_idx, column=col_idx).value
                if not cell_value:
                    continue

                cell_str = str(cell_value).strip().upper()

                # Match N.W (Kg)
                if 'N.W' in cell_str and 'KG' in cell_str:
                    weight_cols['nw'] = col_idx

                # Match G.W (Kg)
                elif 'G.W' in cell_str and 'KG' in cell_str:
                    weight_cols['gw'] = col_idx

                # Match CBM
                elif cell_str == 'CBM':
                    weight_cols['cbm'] = col_idx

            # Stop if all three columns are found
            if all(weight_cols.values()):
                break

        return weight_cols

    @staticmethod
    def is_empty_total_row(worksheet: Worksheet, row_idx: int, source_worksheet: Worksheet = None) -> bool:
        """
        Check if row is a TOTAL row that should be hidden.

        A TOTAL row should be hidden if ALL of the following columns are empty/zero/dash:
        - N.W (Kg)
        - G.W (Kg)
        - CBM

        When source_worksheet is provided, formula cells are checked against their
        calculated values in the source worksheet.

        Args:
            worksheet: Target worksheet to check (output workbook)
            row_idx: Row index (1-based)
            source_worksheet: Source worksheet with calculated values (input workbook, optional)

        Returns:
            True if row is TOTAL with no weight data (should be hidden)
        """
        # Search for TOTAL in first 5 columns (some files have TOTAL in column D)
        total_found = False
        for col_idx in range(1, 6):  # Columns A-E
            cell_value = worksheet.cell(row=row_idx, column=col_idx).value
            if cell_value:
                cell_str = str(cell_value).strip().upper()
                if cell_str == "TOTAL":
                    total_found = True
                    break
                elif "GRAND" in cell_str and "TOTAL" in cell_str:
                    # Never hide GRAND TOTAL rows
                    return False

        if not total_found:
            return False

        # Find weight columns dynamically
        weight_cols = DetailPLHandler._find_weight_columns(worksheet)

        # If we can't find the weight columns, don't hide the row
        if not all(weight_cols.values()):
            return False

        # Check the three weight columns
        for col_key, col_idx in weight_cols.items():
            cell = worksheet.cell(row=row_idx, column=col_idx)
            value = cell.value

            # If cell has a formula, check calculated value from source worksheet
            if isinstance(value, str) and value.startswith('='):
                if source_worksheet is not None:
                    # Get calculated value from source worksheet
                    source_value = source_worksheet.cell(row=row_idx, column=col_idx).value
                    value = source_value
                else:
                    # No source worksheet - treat formula as potentially empty
                    continue

            # If cell has a non-zero number
            if isinstance(value, (int, float)) and value != 0:
                return False

            # If cell has non-empty text (excluding whitespace and dashes)
            if isinstance(value, str):
                stripped = value.strip()
                if stripped and stripped != '-':
                    return False

        # All three weight columns are empty/zero/dash - should hide this TOTAL row
        return True

    def copy_detail_pl_sheet(self, input_wb, output_wb, input_file_path=None, logger=None):
        """
        Copy entire Detail PL sheet from input to output and extract weight data

        Args:
            input_wb: Input workbook
            output_wb: Output workbook
            input_file_path: Path to input file (optional, for loading with data_only=True)
            logger: Logger instance for detailed logging

        Returns:
            Dict with 'success', 'reason', 'structure', 'weights'
        """
        from invoice_rpa_mcp.utils.detail_pl_analyzer import DetailPLAnalyzer
        import openpyxl

        # List all sheets in input workbook
        all_sheets = input_wb.sheetnames
        if logger:
            logger.info(f"  - Input workbook sheets: {all_sheets}")

        # Find source sheet with flexible matching
        source_sheet = None
        source_sheet_name = None
        analyzer = DetailPLAnalyzer(logger=logger)

        # Try multiple variations for Detail P.L
        detail_variations = [
            "Detail P.L",
            "Detail PL",
            "Detail P.L ",
            "DETAIL PL",
            "DETAIL P.L ",
            "DETAILPL",
        ]

        for variation in detail_variations:
            try:
                source_sheet = find_sheet(input_wb, variation)
                source_sheet_name = variation
                if logger:
                    logger.info(
                        f"  - Found Detail PL sheet with variation: '{variation}'"
                    )
                break
            except ValueError:
                continue

        if not source_sheet:
            # Detail PL sheet doesn't exist in input
            if logger:
                logger.warning(
                    "  - Detail PL sheet not found in input (checked multiple variations)"
                )
                if logger:
                    logger.info(f"  - Available sheets: {input_wb.sheetnames}")
            return {"success": False, "reason": "sheet_not_found"}

        # Analyze sheet structure
        structure = analyzer.analyze_sheet_structure(source_sheet)

        if not structure["has_data"]:
            if logger:
                logger.warning("  - Detail PL sheet is empty (no meaningful data)")
            return {"success": False, "reason": "empty_sheet"}

        # Load workbook with data_only=True to extract weight values from formulas
        # This workbook will be reused for hiding empty rows later
        input_wb_calc = None
        source_with_calc = None
        if input_file_path:
            input_wb_calc = openpyxl.load_workbook(input_file_path, data_only=True)
            for name in input_wb_calc.sheetnames:
                if name.lower().replace(" ", "") == source_sheet.title.lower().replace(" ", ""):
                    source_with_calc = input_wb_calc[name]
                    break

        # Extract weight data from data_only workbook (has calculated values)
        weight_source = source_with_calc if source_with_calc else source_sheet
        weights = analyzer.find_weights_data(weight_source, structure)

        if not weights["found_grand_total"]:
            if logger:
                logger.warning("  - GRAND TOTAL row not found in Detail PL sheet")

        # Get actual sheet name from input
        actual_sheet_name = source_sheet.title

        # Remove existing Detail P.L sheet if it exists in output
        try:
            existing_sheet = find_sheet(output_wb, "Detail P.L")
            if logger:
                logger.info(
                    f"  - Removing existing Detail P.L sheet from output: {existing_sheet.title}"
                )
            del output_wb[existing_sheet.title]
        except ValueError:
            if logger:
                logger.info(
                    "  - No existing Detail P.L sheet in output (this is first time)"
                )

        # Create new sheet with same name as source
        target_sheet = output_wb.create_sheet(actual_sheet_name)

        # Copy cell values and formatting
        for row in source_sheet.iter_rows():
            for cell in row:
                target_cell = target_sheet[cell.coordinate]

                # Copy value
                if cell.value is not None:
                    target_cell.value = cell.value

                # Copy formatting (optional, can be slow)
                if cell.has_style:
                    target_cell.font = copy(cell.font)
                    target_cell.border = copy(cell.border)
                    target_cell.fill = copy(cell.fill)
                    target_cell.number_format = copy(cell.number_format)
                    target_cell.protection = copy(cell.protection)
                    target_cell.alignment = copy(cell.alignment)

        # Copy column dimensions from source (template widths preserved)
        for col_letter in source_sheet.column_dimensions:
            if col_letter in source_sheet.column_dimensions:
                target_sheet.column_dimensions[
                    col_letter
                ].width = source_sheet.column_dimensions[col_letter].width

        # Copy row dimensions
        for row_idx in source_sheet.row_dimensions:
            if row_idx in source_sheet.row_dimensions:
                target_sheet.row_dimensions[
                    row_idx
                ].height = source_sheet.row_dimensions[row_idx].height

        # Copy merged cells
        for merged_range in source_sheet.merged_cells.ranges:
            target_sheet.merge_cells(str(merged_range))

        # Configure print settings for Detail P.L sheet
        if logger:
            logger.info("  - Detail P.L: Configuring print settings...")

        # Page setup
        target_sheet.page_setup.paperSize = target_sheet.PAPERSIZE_A4
        target_sheet.page_setup.orientation = 'landscape'  # 가로 방향

        # Fit to page (1 page wide, auto height)
        target_sheet.page_setup.fitToPage = True
        target_sheet.page_setup.fitToWidth = 1
        target_sheet.page_setup.fitToHeight = 0  # 0 = auto

        # Margins - 좁은 여백 (단위: inches)
        target_sheet.page_margins.left = 0.25
        target_sheet.page_margins.right = 0.25
        target_sheet.page_margins.top = 0.75
        target_sheet.page_margins.bottom = 0.75
        target_sheet.page_margins.header = 0.3
        target_sheet.page_margins.footer = 0.3

        # Print options
        target_sheet.print_options.horizontalCentered = False
        target_sheet.print_options.verticalCentered = False

        if logger:
            logger.info("  - Detail P.L: Print settings applied (A4, Landscape, Fit to 1 page)")

        # Hide empty rows - use the already-loaded data_only workbook
        empty_row_count = structure["hidden_rows"]
        if source_with_calc:
            DetailPLHandler.hide_empty_rows(target_sheet, source_with_calc, logger)
        else:
            DetailPLHandler.hide_empty_rows(target_sheet, source_sheet, logger)

        # Close the data_only workbook if it was loaded
        if input_wb_calc:
            input_wb_calc.close()

        if logger:
            logger.info(f"  - Detail PL: hidden {empty_row_count} empty rows")

        return {"success": True, "structure": structure, "weights": weights}

    @staticmethod
    def hide_empty_rows(worksheet: Worksheet, source_worksheet: Worksheet = None, logger=None):
        """
        Hide rows where all cells are empty or whitespace, or TOTAL rows with zero/empty values

        Args:
            worksheet: Target worksheet to process (output workbook)
            source_worksheet: Source worksheet with calculated formula values (input workbook)
            logger: Logger instance
        """
        total_rows = worksheet.max_row
        hidden_rows = 0

        for row_idx in range(1, total_rows + 1):
            if DetailPLHandler.is_row_empty(worksheet, row_idx) or DetailPLHandler.is_empty_total_row(worksheet, row_idx, source_worksheet):
                worksheet.row_dimensions[row_idx].hidden = True
                hidden_rows += 1

        if logger:
            logger.info(f"  - Detail PL: hidden {hidden_rows} empty rows")

        return hidden_rows

    @staticmethod
    def process_detail_pl(input_wb, output_wb, logger=None):
        """
        Complete Detail PL processing with comprehensive logging

        Args:
            input_wb: Input workbook
            output_wb: Output workbook
            logger: Logger instance
        """
        # Copy sheet from input to output with weight extraction
        result = DetailPLHandler().copy_detail_pl_sheet(input_wb, output_wb, logger)

        if result["success"]:
            if logger:
                # Log weight data
                weights = result.get("weights", {})
                if weights.get("found_grand_total"):
                    if logger:
                        logger.info(
                            f"  → Weights found: N.WGT={weights.get('n_wgt')}, G.WGT={weights.get('g_wgt')}, CBM={weights.get('cbm')}"
                        )
                else:
                    if logger:
                        logger.warning("  → No weight data extracted")
            else:
                if result.get("reason") == "not_found":
                    if logger:
                        logger.info("  → Detail PL: SKIPPED (sheet not found)")
                elif result.get("reason") == "empty_sheet":
                    if logger:
                        logger.info("  → Detail PL: SKIPPED (empty sheet)")
                else:
                    if logger:
                        logger.warning("  - Detail PL: SKIPPED")
        else:
            if logger:
                logger.error(f"  - Detail PL: SKIPPED (reason: {result.get('reason')})")

        return result["success"]
