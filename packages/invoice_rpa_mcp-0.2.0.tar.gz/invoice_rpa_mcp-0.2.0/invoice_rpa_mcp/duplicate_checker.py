"""Track processed files to prevent duplicate processing"""

import json
from pathlib import Path
from datetime import datetime
from typing import Dict, Optional


class DuplicateChecker:
    """Manage processed files history"""

    def __init__(self, history_file: Path = None):
        """
        Initialize duplicate checker

        Args:
            history_file: Path to history JSON file
        """
        if history_file is None:
            project_root = Path(__file__).parent.parent
            history_file = project_root / '.invoice_history.json'

        self.history_file = Path(history_file)
        self.history = self._load_history()

    def _load_history(self) -> Dict:
        """
        Load history from JSON file

        Returns:
            Dictionary with processed files
        """
        if not self.history_file.exists():
            return {}

        try:
            with open(self.history_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return {}

    def _save_history(self):
        """Save history to JSON file"""
        self.history_file.parent.mkdir(parents=True, exist_ok=True)

        with open(self.history_file, 'w', encoding='utf-8') as f:
            json.dump(self.history, f, indent=2, ensure_ascii=False)

    def is_processed(self, filename: str) -> bool:
        """
        Check if file already processed

        Args:
            filename: Input filename to check

        Returns:
            True if already processed
        """
        # Use just the filename without path
        filename = Path(filename).name
        return filename in self.history

    def mark_processed(
        self,
        filename: str,
        output_filename: str,
        status: str = 'success'
    ):
        """
        Mark file as processed

        Args:
            filename: Input filename
            output_filename: Output filename
            status: Processing status
        """
        filename = Path(filename).name

        self.history[filename] = {
            'processed_at': datetime.now().isoformat(),
            'output_file': output_filename,
            'status': status
        }

        self._save_history()

    def get_processed_info(self, filename: str) -> Optional[Dict]:
        """
        Get processing info for a file

        Args:
            filename: Input filename

        Returns:
            Processing info dictionary or None
        """
        filename = Path(filename).name
        return self.history.get(filename)
