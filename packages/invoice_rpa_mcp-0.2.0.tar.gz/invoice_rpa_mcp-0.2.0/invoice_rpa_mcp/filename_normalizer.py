"""Filename normalization based on naming_test.py logic"""

import re
from pathlib import Path


class FilenameNormalizer:
    """Normalize output filename from input filename"""

    def __init__(self):
        """Initialize filename normalizer"""
        self.cipl_keywords = ['INDIA', 'CZECH', 'UK', 'EUROPE', 'NETHERLANDS']

    def normalize_filename(self, source_filename: str, sequence: int = None) -> str:
        """
        Apply naming_test.py logic to normalize filename

        Steps:
        1. Remove header: "Contract No.DRBVN XXXXX (DD-MM-YYYY) "
        2. Remove noise: "(F2)", "- CONT 1~3", etc.
        3. Apply classification:
           - CODE pattern (UNIV026, DHLVN022, DZI...) → "{CODE}_{content}.xlsx"
           - CIPL pattern (INDIA, CZECH, UK, EUROPE, NETHERLANDS) → "CIPL_{content}.xlsx"
           - Standard with sequence → "{N}차_{content}.xlsx" (N = sequence number)
           - Standard without sequence → "{content}.xlsx" (비시퀀스 고객)

        Args:
            source_filename: Original input filename
            sequence: Sequence number for standard pattern (None = 비시퀀스 고객)

        Returns:
            Normalized output filename with .xlsx extension
        """
        # Remove .xlsx extension if present
        filename = Path(source_filename).stem

        # Step 1: Remove header
        body = re.sub(
            r'^Contract No\.[^(]+\(\d{2}-\d{2}-\d{4}\)\s*',
            '',
            filename
        ).strip()

        # Step 2: Remove noise
        body = re.sub(r'\s*\(F2\)', '', body)
        body = re.sub(r'- CONT \d+~\d+', '', body)

        # Step 3: Classify and apply prefix

        # CASE 1: Code pattern (e.g., UNIV026, DHLVN022, DZI...)
        # Pattern: comma followed by CODE (3+ uppercase letters + 3+ digits)
        code_match = re.search(r',\s*([A-Z]{3,}\d{3,}.*)$', body)
        if code_match:
            code_part = code_match.group(1).strip()
            main_content = body.replace(code_match.group(0), "").strip()
            return f"{code_part}_{main_content}.xlsx"

        # CASE 2: CIPL pattern (INDIA, CZECH, UK, EUROPE, NETHERLANDS)
        if any(keyword in body.upper() for keyword in self.cipl_keywords):
            clean_body = body.rstrip('_').strip()
            return f"CIPL_{clean_body}.xlsx"

        # CASE 3: Standard pattern
        clean_body = body.strip().rstrip(',')

        # 시퀀스가 있으면 차수 prefix 추가, 없으면 파일명만
        if sequence is not None and sequence > 0:
            return f"차_{clean_body}.xlsx"
        else:
            # 비시퀀스 고객: prefix 없이 파일명만
            return f"{clean_body}.xlsx"
