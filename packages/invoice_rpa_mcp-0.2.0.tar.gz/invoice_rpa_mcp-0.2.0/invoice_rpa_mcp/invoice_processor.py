"""Main invoice processing orchestrator"""

import openpyxl
from pathlib import Path
from typing import Dict, Any
import logging

from invoice_rpa_mcp.customer_identifier import CustomerIdentifier, CustomerNotFoundError
from invoice_rpa_mcp.template_selector import TemplateSelector
from invoice_rpa_mcp.data_extractor import DataExtractor
from invoice_rpa_mcp.mapper import Mapper
from invoice_rpa_mcp.filename_normalizer import FilenameNormalizer
from invoice_rpa_mcp.duplicate_checker import DuplicateChecker
from invoice_rpa_mcp.detail_pl_handler import DetailPLHandler
from invoice_rpa_mcp.detail_pl_handler import DetailPLHandler
from invoice_rpa_mcp.data_loader import VariationDataLoader
from invoice_rpa_mcp.sequence_manager import SequenceManager
import re
from datetime import datetime


class InvoiceProcessor:
    """Orchestrate invoice processing workflow"""

    def __init__(
        self,
        config_loader,
        variation_data_loader: VariationDataLoader,
        duplicate_checker: DuplicateChecker,
        sequence_manager: SequenceManager,
        logger: logging.Logger,
    ):
        """
        Initialize invoice processor

        Args:
            config_loader: Configuration loader instance
            variation_data_loader: Variation data loader instance
            duplicate_checker: Duplicate checker instance
            logger: Logger instance
        """
        self.config_loader = config_loader
        self.variation_data = variation_data_loader
        self.duplicate_checker = duplicate_checker
        self.sequence_manager = sequence_manager
        self.logger = logger

        # Load configurations
        self.customer_patterns = config_loader.load_customer_patterns()
        self.customer_types = config_loader.load_customer_types()
        self.mapping_config = config_loader.load_mapping_config()
        self.cell_references = config_loader.load_cell_references()
        self.search_config = config_loader.load_search_config()
        self.sheet_config = config_loader.load_sheet_config()

        # Initialize components
        self.customer_identifier = CustomerIdentifier(
            self.customer_patterns, self.variation_data.customer_master
        )
        self.template_selector = TemplateSelector(self.customer_types)
        self.filename_normalizer = FilenameNormalizer()

    def process_file(self, input_file_path: Path, output_dir: Path) -> Dict[str, Any]:
        """
        Process a single input file

        Args:
            input_file_path: Path to input Excel file
            output_dir: Directory for output files

        Returns:
            Processing result dictionary
        """
        filename = input_file_path.name
        self.logger.info(f"Processing: {filename}")

        try:
            # Step 1: Check if already processed
            if self.duplicate_checker.is_processed(filename):
                self.logger.info(f"Skipped (already processed): {filename}")
                return {
                    "status": "skipped",
                    "reason": "already_processed",
                    "input_file": filename,
                }

            # Step 2: Identify customer
            try:
                customer_name = self.customer_identifier.identify_customer(filename)
                self.logger.info(f"Customer identified: {customer_name}")
            except CustomerNotFoundError as e:
                self.logger.warning(f"Customer not found for {filename}: {e}")
                return {
                    "status": "error",
                    "reason": "customer_not_found",
                    "message": str(e),
                    "input_file": filename,
                }

            # Step 3: Get customer info from customer_master
            customer_info = self.customer_identifier.get_customer_info(customer_name)
            if not customer_info:
                self.logger.error(f"Customer {customer_name} not in customer_master")
                return {
                    "status": "error",
                    "reason": "customer_not_in_master",
                    "input_file": filename,
                }

            # Step 3.5: Generate Invoice Number based on Customer Master
            invoice_numbering_format = customer_info.get("invoice_numbering", "")
            sequence_key = None

            if invoice_numbering_format:
                # Check for pattern like "Caterpillar_2026_1" (Prefix_Year_Sequence)
                # We assume the user wants to keep the Prefix and Year, and auto-increment the Sequence
                # Current Logic: If it ends with _1, treated as auto-increment start.
                match = re.search(r"^(.+)_(\d{4})_1$", invoice_numbering_format.strip())
                if match:
                    prefix = match.group(1)
                    year = match.group(2)
                    sequence_key = f"{prefix}_{year}"

                    # Get next sequence (without commit yet)
                    next_seq = self.sequence_manager.get_next_sequence(sequence_key)
                    new_invoice_number = f"{prefix}_"

                    self.logger.info(
                        f"Generated Invoice Number: {new_invoice_number} (Key: {sequence_key}, Seq: {next_seq})"
                    )
                else:
                    # Fixed code pattern - 비시퀀스 고객은 빈값 처리
                    new_invoice_number = None
                    self.logger.info(
                        f"Non-sequence customer: Invoice number left empty (static code: {invoice_numbering_format})"
                    )
            else:
                new_invoice_number = None

            # Step 4: Select template
            template_path = self.template_selector.select_template(customer_name)
            row_positions = self.template_selector.get_row_positions(customer_name)
            self.logger.info(f"Template: {template_path.name}")

            # Step 5: Extract data from input file
            try:
                extractor = DataExtractor(
                    row_positions,
                    self.cell_references,
                    self.search_config,
                    self.sheet_config,
                )
                extracted_data = extractor.extract_all_data(input_file_path)

                # Override Invoice Number (시퀀스: prefix_, 비시퀀스: 빈값)
                if "invoice_metadata" not in extracted_data:
                    extracted_data["invoice_metadata"] = {}
                extracted_data["invoice_metadata"]["invoice_number"] = (
                    new_invoice_number if new_invoice_number else ""
                )

                self.logger.info(
                    f"Extracted {len(extracted_data.get('items', []))} items"
                )
            except ValueError as e:
                self.logger.error(f"Data extraction failed for {filename}: {e}")
                return {
                    "status": "error",
                    "reason": "missing_required_sheet",
                    "message": str(e),
                    "input_file": filename,
                }

            # Step 6: Load template
            output_wb = openpyxl.load_workbook(template_path)

            # Step 7: Get item list for this customer
            customer_items = self.variation_data.find_items_by_customer(customer_name)

            # Step 8: Map data to template
            mapper = Mapper(
                self.mapping_config,
                customer_info,
                customer_items,
                row_positions,
                self.cell_references,
                self.search_config,
                self.sheet_config,
                self.logger,
            )
            mapper.apply_mappings(extracted_data, output_wb)

            # Step 8.5: Map Marks and numbers to P.L
            marks_data = extracted_data.get("marks_and_numbers", [])
            if marks_data:
                mapper.map_marks_and_numbers(output_wb, marks_data)

            self.logger.info("Mapping complete")

            # Step 9: Handle Detail PL sheet with enhanced logging
            detail_pl_handler = DetailPLHandler(logger=self.logger)
            input_wb = openpyxl.load_workbook(input_file_path)
            detail_result = detail_pl_handler.copy_detail_pl_sheet(input_wb, output_wb, input_file_path)

            # Handle dict response (new format with weights data)
            if isinstance(detail_result, dict) and detail_result.get("success"):
                self.logger.info("  → Detail P.L: COPIED")

                # Update P.L sheet with weights from Detail P.L GRAND TOTAL
                weights = detail_result.get("weights", {})
                mapper.update_pl_sheet_weights(output_wb, weights)

            # Handle string response (backward compatibility)
            elif detail_result == "success":
                self.logger.info("  → Detail P.L: COPIED")
            elif detail_result == "not_found":
                self.logger.warning("  → Detail P.L: SKIPPED (sheet not found)")
            elif detail_result == "empty_sheet":
                self.logger.warning("  → Detail P.L: SKIPPED (empty sheet)")

            input_wb.close()

            # Step 10: Generate output filename
            # 시퀀스 패턴인 경우 차수(next_seq) 전달
            if sequence_key:
                output_filename = self.filename_normalizer.normalize_filename(filename, next_seq)
            else:
                # 비시퀀스 고객: prefix 없음 (sequence=None 전달)
                output_filename = self.filename_normalizer.normalize_filename(filename, sequence=None)
            output_path = output_dir / output_filename
            self.logger.info(f"Output filename: {output_filename}")

            # Step 11: Save output
            output_dir.mkdir(parents=True, exist_ok=True)
            output_wb.save(output_path)

            # Step 12: Commit Sequence (if used)
            if sequence_key:
                self.sequence_manager.commit_sequence(sequence_key)
                self.logger.info(f"Sequence committed for key: {sequence_key}")
            output_wb.close()

            # Step 12: Mark as processed
            self.duplicate_checker.mark_processed(filename, output_filename, "success")

            self.logger.info(f"Success: {filename} → {output_filename}")
            return {
                "status": "success",
                "input_file": filename,
                "output_file": output_filename,
                "customer": customer_name,
            }

        except Exception as e:
            self.logger.exception(f"Error processing {filename}: {e}")
            return {
                "status": "error",
                "reason": "unexpected_error",
                "message": str(e),
                "input_file": filename,
            }
