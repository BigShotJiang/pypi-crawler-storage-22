#!/usr/bin/env python3
"""
Invoice Automation Main Script

Usage:
    uv run python invoice_rpa_mcp/main.py
"""

import sys
from pathlib import Path

from invoice_rpa_mcp.utils.logger import setup_logger
from invoice_rpa_mcp.config_loader import ConfigLoader
from invoice_rpa_mcp.data_loader import VariationDataLoader
from invoice_rpa_mcp.duplicate_checker import DuplicateChecker
from invoice_rpa_mcp.invoice_processor import InvoiceProcessor
from invoice_rpa_mcp.sequence_manager import SequenceManager


def main():
    """Main entry point"""
    # Setup logging
    project_root = Path(__file__).parent.parent
    log_file = project_root / 'logs' / 'invoice_automation.log'
    logger = setup_logger('invoice_rpa', log_file=log_file)

    logger.info("=" * 60)
    logger.info("Invoice Automation System")
    logger.info("=" * 60)

    # Load Process Configuration
    config_path = project_root / 'variation_data' / 'process_config.json'
    input_dir = project_root / 'input'
    output_dir = project_root / 'output'
    process_config = {}

    if config_path.exists():
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                import json
                process_config = json.load(f)

                # Update input/output dirs if present in config
                if 'input_folder' in process_config:
                    input_folder_name = process_config['input_folder']
                    # Handle absolute paths vs relative paths
                    input_path = Path(input_folder_name)
                    if input_path.is_absolute():
                        input_dir = input_path
                    else:
                        input_dir = project_root / input_folder_name

                if 'output_folder' in process_config:
                    output_folder_name = process_config['output_folder']
                    output_path = Path(output_folder_name)
                    if output_path.is_absolute():
                        output_dir = output_path
                    else:
                        output_dir = project_root / output_folder_name

                logger.info(f"Configuration loaded from {config_path}")
                logger.info(f"Input Directory: {input_dir}")
                logger.info(f"Output Directory: {output_dir}")
        except Exception as e:
            logger.error(f"Failed to load process config: {e}. Using defaults.")
    else:
        logger.warning(f"Config file not found at {config_path}. Using default 'input' and 'output' directories.")

    try:
        # Initialize components
        logger.info("Initializing components...")

        config_loader = ConfigLoader()

        # process_config에서 CSV 경로 읽기 (Windows 백슬래시/슬래시 모두 지원)
        raw_cm = process_config.get('customer_master_path')
        raw_il = process_config.get('item_list_path')
        customer_master_path = str(Path(raw_cm).resolve()) if raw_cm else None
        item_list_path = str(Path(raw_il).resolve()) if raw_il else None

        variation_data_loader = VariationDataLoader(
            customer_master_path=customer_master_path,
            item_list_path=item_list_path,
        )
        variation_data_loader.load_all()

        logger.info(f"Loaded {len(variation_data_loader.customer_master)} customer records")
        logger.info(f"Loaded {len(variation_data_loader.item_list)} item records")

        duplicate_checker = DuplicateChecker()
        sequence_manager = SequenceManager(project_root / '.invoice_sequences.json')

        processor = InvoiceProcessor(
            config_loader,
            variation_data_loader,
            duplicate_checker,
            sequence_manager,
            logger
        )

        # Scan input directory
        if not input_dir.exists():
            logger.error(f"Input directory not found: {input_dir}")
            sys.exit(1)

        all_files = list(input_dir.glob('*.xlsx'))

        # Filter out temp files (starting with ~$) and invalid files
        input_files = [f for f in all_files if not f.name.startswith('~$')]

        temp_files_count = len(all_files) - len(input_files)
        if temp_files_count > 0:
            logger.info(f"\nFiltered out {temp_files_count} temp file(s)")

        logger.info(f"Found {len(input_files)} Excel file(s) to process")

        if not input_files:
            logger.info("No files to process. Exiting.")
            return

        # Process each file
        results = []
        for input_file in input_files:
            result = processor.process_file(input_file, output_dir)
            results.append(result)
            print()  # Blank line between files

        # Report results
        logger.info("\n" + "=" * 60)
        logger.info("Processing Summary")
        logger.info("=" * 60)

        successful = [r for r in results if r.get('status') == 'success']
        skipped = [r for r in results if r.get('status') == 'skipped']
        failed = [r for r in results if r.get('status') == 'error']

        if successful:
            logger.info(f"\n✓ Successfully processed {len(successful)} file(s):")
            for result in successful:
                logger.info(f"  - {result['input_file']} → {result['output_file']}")

        if skipped:
            logger.info(f"\n○ Skipped {len(skipped)} file(s) (already processed):")
            for result in skipped:
                logger.info(f"  - {result['input_file']}")

        if failed:
            logger.error(f"\n✗ Failed to process {len(failed)} file(s):")
            for result in failed:
                reason = result.get('reason', 'unknown')
                logger.error(f"  - {result['input_file']}: {reason}")

        logger.info(f"\nTotal: {len(results)} file(s)")
        logger.info(f"Success: {len(successful)}, Skipped: {len(skipped)}, Failed: {len(failed)}")

        # Exit with appropriate code
        sys.exit(0 if not failed else 1)

    except KeyboardInterrupt:
        logger.info("\nProcess interrupted by user")
        sys.exit(130)

    except Exception as e:
        logger.exception(f"\nFatal error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
