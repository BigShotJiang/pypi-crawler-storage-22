"""Map extracted data to output template"""

import re
import openpyxl
from openpyxl.styles import Alignment
from pathlib import Path
from typing import Dict, List, Any
from invoice_rpa_mcp.utils.excel_operations import ExcelOperations
from invoice_rpa_mcp.utils.header_detector import HeaderDetector
from invoice_rpa_mcp.utils.table_mapper import TableMapper


class Mapper:
    """Map extracted data to output template based on configuration"""

    def __init__(
        self,
        mapping_config: Dict,
        customer_master_data: Dict,
        item_list_data: List[Dict],
        row_positions: Dict,
        cell_references: Dict[str, Any] | None = None,
        search_config: Dict[str, Any] | None = None,
        sheet_config: Dict[str, Any] | None = None,
        logger = None,
    ):
        """
        Initialize mapper

        Args:
            mapping_config: Mapping configuration
            customer_master_data: Customer master data for current customer
            item_list_data: Item list data
            row_positions: Row position configuration
            cell_references: Dynamic cell reference configuration
            search_config: Search ranges and parameters configuration
            sheet_config: Sheet name mappings configuration
            logger: Logger instance
        """
        self.mapping_config = mapping_config
        self.customer_master_data = customer_master_data
        self.item_list_data = item_list_data
        self.row_positions = row_positions
        self.cell_references = cell_references or {}
        self.search_config = search_config or {}
        self.sheet_config = sheet_config or {}
        self.logger = logger

        # Initialize utilities
        self.excel_ops = ExcelOperations(sheet_config)
        self.header_detector = HeaderDetector(search_config)
        self.table_mapper = TableMapper(self.excel_ops, self.header_detector)

    def _get_output_sheet_name(self, sheet_type: str) -> str:
        """Get output sheet name from config or fallback to default"""
        if self.sheet_config and "output_sheets" in self.sheet_config:
            return self.sheet_config["output_sheets"].get(sheet_type, "I.V")
        return "I.V"

    def apply_mappings(self, extracted_data: Dict, output_wb):
        """
        Apply all mappings to populate template

        Args:
            extracted_data: Extracted data from input file
            output_wb: Output workbook (template)
        """
        mappings = self.mapping_config.get("mappings", {})

        # Map invoice metadata
        if "invoice_metadata" in mappings:
            self._map_invoice_metadata(
                extracted_data.get("invoice_metadata", {}),
                mappings["invoice_metadata"],
                output_wb,
            )

        # Map customer info from customer_master
        if "customer_info" in mappings:
            self._map_customer_info(mappings["customer_info"], output_wb)

        # Map shipping info
        if "shipping_info" in mappings:
            self._map_shipping_info(
                extracted_data.get("shipping_info", {}),
                mappings["shipping_info"],
                output_wb,
            )

        # Map items table
        self._map_items_table(extracted_data.get("items", []), output_wb)

    def _map_invoice_metadata(self, metadata: Dict, mapping_rules: Dict, output_wb):
        """Map invoice metadata fields using dynamic cell references"""
        for field_name, rule in mapping_rules.items():
            source_value = metadata.get(rule.get("source_field"))
            if source_value:
                # Get target from dynamic config or fallback
                target_config = rule.get("target_config")
                if target_config and self.cell_references:
                    # Navigate through nested keys like "output_sheets.invoice_metadata.cells.invoice_number"
                    keys = target_config.split(".")
                    target_info = self.cell_references
                    for key in keys:
                        if isinstance(target_info, dict) and key in target_info:
                            target_info = target_info[key]
                        else:
                            target_info = None
                            break

                    if target_info and "cell" in target_info:
                        target_sheet_name = self._get_output_sheet_name(
                            "invoice_metadata"
                        )
                        target_cell = target_info["cell"]
                    else:
                        continue  # Skip if config not found
                else:
                    # Fallback to hardcoded values
                    target_sheet_name = rule.get("target_sheet", "I.V")
                    target_cell = rule.get("target_cell")
                    if not target_cell:
                        continue

                ws = output_wb[target_sheet_name]
                ws[target_cell] = source_value

    def _map_customer_info(self, mapping_rules: Dict, output_wb):
        """Map customer info from customer_master using dynamic cell references"""
        for field_name, rule in mapping_rules.items():
            if rule.get("source") == "customer_master":
                field = rule.get("field")
                value = self.customer_master_data.get(field, "")

                # Get target from dynamic config or fallback
                target_config = rule.get("target_config")
                if target_config and self.cell_references:
                    # Navigate through nested keys
                    keys = target_config.split(".")
                    target_info = self.cell_references
                    for key in keys:
                        if isinstance(target_info, dict) and key in target_info:
                            target_info = target_info[key]
                        else:
                            target_info = None
                            break

                    if target_info and "cell" in target_info:
                        target_sheet_name = self._get_output_sheet_name(
                            "invoice_metadata"
                        )
                        target_cell = target_info["cell"]
                    else:
                        continue
                else:
                    # Fallback to hardcoded values
                    target_sheet_name = rule.get("target_sheet", "I.V")
                    target_cell = rule.get("target_cell")
                    if not target_cell:
                        continue

                ws = output_wb[target_sheet_name]
                ws[target_cell] = value

    def _map_shipping_info(self, shipping_info: Dict, mapping_rules: Dict, output_wb):
        """Map shipping information fields using dynamic cell references"""
        for field_name, rule in mapping_rules.items():
            source_value = shipping_info.get(rule.get("source_field"))
            if source_value:
                # Get target from dynamic config or fallback
                target_config = rule.get("target_config")
                if target_config and self.cell_references:
                    # Navigate through nested keys
                    keys = target_config.split(".")
                    target_info = self.cell_references
                    for key in keys:
                        if isinstance(target_info, dict) and key in target_info:
                            target_info = target_info[key]
                        else:
                            target_info = None
                            break

                    if target_info and "cell" in target_info:
                        target_sheet_name = self._get_output_sheet_name("shipping_info")
                        target_cell = target_info["cell"]
                    else:
                        continue
                else:
                    # Fallback to hardcoded values
                    target_sheet_name = rule.get("target_sheet", "I.V")
                    target_cell = rule.get("target_cell")
                    if not target_cell:
                        continue

                ws = output_wb[target_sheet_name]
                ws[target_cell] = source_value

    def _map_items_table(self, items: List[Dict], output_wb):
        """
        Map items from Input file (QUANTITY) + itemList.csv (other fields)
        Uses TableMapper for organized table operations.

        Args:
            items: List from Input file (with QUANTITY)
            output_wb: Output workbook
        """
        ws = output_wb["I.V"]

        # Find table structure using TableMapper
        header_row, columns, total_row = self.table_mapper.find_output_table_structure(
            ws
        )
        start_row = header_row + 1
        available_rows = total_row - header_row - 1

        # Prepare matched items
        matched_items = self._prepare_matched_items(items)
        if not matched_items:
            return

        needed_rows = len(matched_items)

        # Update PRICE header with currency
        currency = matched_items[0]["CURRENCY"]
        self.table_mapper.update_price_header(ws, header_row, columns, currency)

        # Prepare table area
        self.table_mapper.prepare_merged_cells(ws, start_row, total_row)

        # Adjust table rows
        total_row = self.table_mapper.adjust_table_rows(
            ws, needed_rows, available_rows, start_row, total_row
        )

        # Map item data
        self.table_mapper.map_item_data(ws, matched_items, columns, start_row)

        # Apply formulas
        last_data_row = start_row + needed_rows - 1
        self.table_mapper.apply_formulas(
            ws, columns, start_row, last_data_row, total_row
        )

        # Format total row
        self.table_mapper.format_total_row(ws, columns, total_row)

        # Update P.L sheet references to match new I.V table structure
        self._update_pl_sheet_references(output_wb, start_row, total_row)

        # Set P.L header row height (row 34)
        pl_ws = output_wb['P.L']
        pl_ws.row_dimensions[34].height = 42

        # Update US template formulas to reference actual TOTAL row
        self._update_us_template_formulas(output_wb, total_row)

    def _prepare_matched_items(self, items: List[Dict]) -> List[Dict]:
        """
        Prepare matched items from input and itemList data with detailed logging

        Args:
            items: Input items with QUANTITY

        Returns:
            List of matched item dictionaries
        """
        customer_items = self.item_list_data

        # Log if no itemList entries found
        if not customer_items:
            if self.logger:
                self.logger.warning("  ⚠ No itemList entries found for customer")
            return []

        matched_items = []
        unmatched_codes = []  # Track failures

        for input_item in items:
            input_code = input_item.get("code")
            itemlist_entry = next(
                (
                    item
                    for item in customer_items
                    if item.get("CODE", "").strip() == str(input_code)
                ),
                None,
            )

            if itemlist_entry:
                matched_item = {
                    "SO": itemlist_entry.get("SO", "").strip(),
                    "PN": itemlist_entry.get("PN", "").strip(),
                    "CODE": itemlist_entry.get("CODE", "").strip(),
                    "TYPE_SIZE": itemlist_entry.get("TYPE & SIZE", "").strip(),
                    "QUANTITY": input_item.get("quantity"),
                    "UNIT": input_item.get("unit", "PCS"),
                    "PRICE": itemlist_entry.get(
                        " PRICE ", itemlist_entry.get("PRICE", "")
                    ).strip(),
                    "CURRENCY": itemlist_entry.get("CURRENCY", "USD").strip(),
                }
                matched_items.append(matched_item)
            else:
                # LOG UNMATCHED CODE
                unmatched_codes.append(input_code)
                if self.logger:
                    self.logger.warning(
                        f"  ✗ CODE '{input_code}' not found in itemList.csv - item skipped"
                    )

        # Summary logging
        if self.logger:
            self.logger.info(
                f"  Item matching: {len(matched_items)} matched, {len(unmatched_codes)} unmatched"
            )
            if unmatched_codes:
                self.logger.warning(f"  Unmatched CODEs: {unmatched_codes}")

        return matched_items

    def _update_pl_sheet_references(self, output_wb, iv_start_row: int, iv_total_row: int):
        """
        Update P.L sheet I.V references to match actual I.V data rows

        Strategy:
        1. Find P.L table structure (header + data rows)
        2. Map P.L data rows directly to I.V data rows (1:1)
        3. Clear extra P.L rows if I.V has fewer items
        4. Update TOTAL row reference

        Args:
            output_wb: Output workbook
            iv_start_row: First data row in I.V table
            iv_total_row: TOTAL row in I.V table
        """
        # Check if P.L sheet exists
        try:
            pl_ws = output_wb["P.L"]
        except KeyError:
            if self.logger:
                self.logger.info("  P.L sheet not found, skipping reference updates")
            return  # P.L sheet doesn't exist, skip

        # Find P.L table structure
        try:
            pl_header_row, pl_columns, pl_total_row = self.table_mapper.find_output_table_structure(pl_ws)
        except Exception as e:
            if self.logger:
                self.logger.warning(f"  Could not find P.L table structure: {e}")
            return

        pl_start_row = pl_header_row + 1

        # Calculate how many data rows we have
        iv_data_rows = iv_total_row - iv_start_row  # e.g., 39 - 36 = 3 items
        pl_data_rows = pl_total_row - pl_start_row  # e.g., 42 - 36 = 6 rows

        # Pattern to match I.V cell references like I.V!A36, I.V!F42, etc.
        pattern = re.compile(r'(=I\.V!)([A-Z]+)(\d+)')

        # Update each P.L data row to reference corresponding I.V row
        for i in range(pl_data_rows):
            pl_row_idx = pl_start_row + i
            pl_row = pl_ws[pl_row_idx]

            if i < iv_data_rows:
                # Map to corresponding I.V data row (1:1 mapping)
                iv_row_idx = iv_start_row + i

                for cell in pl_row:
                    if cell.value and isinstance(cell.value, str) and 'I.V!' in cell.value:
                        def update_to_iv_row(match):
                            prefix = match.group(1)  # "=I.V!"
                            col = match.group(2)     # Column letter
                            # Replace with correct I.V row
                            return f"{prefix}{col}{iv_row_idx}"

                        cell.value = pattern.sub(update_to_iv_row, cell.value)
            else:
                # Extra P.L rows: Clear formulas and HIDE row
                for cell in pl_row:
                    if cell.value and isinstance(cell.value, str) and 'I.V!' in cell.value:
                        cell.value = None  # Clear formula

                # Hide the empty row
                pl_ws.row_dimensions[pl_row_idx].hidden = True

        # Update TOTAL row reference
        pl_total_row_cells = pl_ws[pl_total_row]
        for cell in pl_total_row_cells:
            if cell.value and isinstance(cell.value, str) and 'I.V!' in cell.value:
                # Update to reference I.V TOTAL row
                def update_to_total(match):
                    prefix = match.group(1)
                    col = match.group(2)
                    return f"{prefix}{col}{iv_total_row}"

                cell.value = pattern.sub(update_to_total, cell.value)

        if self.logger:
            self.logger.info(
                f"  P.L references updated: {iv_data_rows} data rows, {pl_data_rows - iv_data_rows} rows cleared"
            )

    def _get_item_price(self, code: str) -> float | None:
        """
        Get item price from itemList

        Args:
            code: Product CODE

        Returns:
            Price or None if not found
        """
        for item in self.item_list_data:
            if item.get("CODE") == code:
                price_str = item.get("PRICE", "")
                if price_str:
                    try:
                        # Remove commas and convert to float
                        return float(str(price_str).replace(",", ""))
                    except:
                        pass
        return None

    def _update_us_template_formulas(self, output_wb, total_row: int):
        """
        Update US template formulas (FOB Value, PREMIUM) to reference actual TOTAL row

        US 템플릿의 FOB Value와 PREMIUM 수식은 $H$42 절대 참조를 사용합니다.
        아이템 행이 추가/삭제되면 TOTAL 행이 이동하지만 $H$42는 고정되어
        잘못된 셀을 참조하게 됩니다. 이 메서드는 $H$42를 실제 TOTAL 행으로
        동적으로 업데이트합니다.

        Args:
            output_wb: Output workbook
            total_row: Actual TOTAL row number in I.V sheet
        """
        ws = output_wb["I.V"]

        # Pattern to match $H$42 absolute references
        pattern = re.compile(r'\$H\$42')

        # Find FOB Value row (search for "FOB Value" in column D)
        fob_row = None
        for row in range(1, 35):  # Search before item table (starts at row 35)
            cell_value = ws[f'D{row}'].value
            if cell_value and 'FOB' in str(cell_value).upper():
                fob_row = row
                break

        # Find PREMIUM row (search for "PREMIUM" in column D)
        premium_row = None
        for row in range(1, 35):
            cell_value = ws[f'D{row}'].value
            if cell_value and 'PREMIUM' in str(cell_value).upper():
                premium_row = row
                break

        # Update FOB Value formula in H column
        if fob_row:
            fob_cell = ws[f'H{fob_row}']
            if fob_cell.value and isinstance(fob_cell.value, str) and '$H$42' in fob_cell.value:
                updated = pattern.sub(f'$H${total_row}', fob_cell.value)
                fob_cell.value = updated
                if self.logger:
                    self.logger.info(f"  FOB Value formula updated: $H$42 → $H${total_row}")

        # Update PREMIUM formula in H column
        if premium_row:
            premium_cell = ws[f'H{premium_row}']
            if premium_cell.value and isinstance(premium_cell.value, str) and '$H$42' in premium_cell.value:
                updated = pattern.sub(f'$H${total_row}', premium_cell.value)
                premium_cell.value = updated
                if self.logger:
                    self.logger.info(f"  PREMIUM formula updated: $H$42 → $H${total_row}")

    def _set_cell_value_preserve_style(self, cell, value):
        """
        Set cell value while preserving all styling

        Args:
            cell: Cell object to update
            value: New value to set
        """
        from copy import copy

        # 원본 스타일 저장
        original_border = copy(cell.border)
        original_font = copy(cell.font)
        original_fill = copy(cell.fill)
        original_alignment = copy(cell.alignment)
        original_format = cell.number_format
        original_protection = copy(cell.protection)

        # 값 할당
        cell.value = value

        # 스타일 복구
        cell.border = original_border
        cell.font = original_font
        cell.fill = original_fill
        cell.alignment = original_alignment
        cell.number_format = original_format
        cell.protection = original_protection

    def update_pl_sheet_weights(self, output_wb, weights: Dict[str, Any]):
        """
        Update P.L sheet with weight values from Detail P.L GRAND TOTAL

        P.L 시트의 무게 관련 셀에 Detail P.L의 GRAND TOTAL 행에서
        추출한 무게 데이터를 입력합니다.

        Mapping:
        - G35: N.W (Net Weight)
        - H35: G.W (Gross Weight)
        - G43: CBM (Cubic Meter)

        Args:
            output_wb: Output workbook
            weights: Weight data from Detail P.L GRAND TOTAL
                {
                    "n_wgt": float or None,
                    "g_wgt": float or None,
                    "cbm": float or None,
                    "found_grand_total": bool
                }
        """
        # Check if P.L sheet exists
        try:
            pl_ws = output_wb["P.L"]
        except KeyError:
            if self.logger:
                self.logger.info("  P.L sheet not found, skipping weight updates")
            return

        # Check if GRAND TOTAL was found
        if not weights.get("found_grand_total", False):
            if self.logger:
                self.logger.warning("  GRAND TOTAL not found in Detail P.L, skipping weight updates")
            return

        # Update NET WGT (G35) - 스타일 보존하면서 값 입력
        n_wgt = weights.get("n_wgt")
        if n_wgt is not None:
            self._set_cell_value_preserve_style(pl_ws["G35"], n_wgt)
            if self.logger:
                self.logger.info(f"  P.L G35 (NET WGT): {n_wgt}")

        # Update GROSS WGT (H35) - 스타일 보존하면서 값 입력
        g_wgt = weights.get("g_wgt")
        if g_wgt is not None:
            self._set_cell_value_preserve_style(pl_ws["H35"], g_wgt)
            if self.logger:
                self.logger.info(f"  P.L H35 (GROSS WGT): {g_wgt}")

        # Update CBM (G43) - 스타일 보존하면서 값 입력
        cbm = weights.get("cbm")
        if cbm is not None:
            self._set_cell_value_preserve_style(pl_ws["G43"], cbm)
            if self.logger:
                self.logger.info(f"  P.L G43 (CBM): {cbm}")

    def map_marks_and_numbers(self, output_wb, marks_data: List[str]):
        """
        추출한 'Marks and numbers' 데이터를 P.L 시트에 기입

        Args:
            output_wb: Output workbook
            marks_data: List of data lines to write
        """
        if not marks_data:
            return

        # Check if P.L sheet exists
        try:
            pl_ws = output_wb["P.L"]
        except KeyError:
            if self.logger:
                self.logger.warning("P.L sheet not found, skipping marks and numbers mapping")
            return

        # Find the header in P.L sheet
        header_cell = self._find_marks_header_in_pl(pl_ws)
        if not header_cell:
            if self.logger:
                self.logger.warning("'Marks and numbers' header not found in P.L sheet")
            return

        header_row, header_col = header_cell

        # Write data starting from header+1
        for i, line in enumerate(marks_data):
            target_cell = pl_ws.cell(row=header_row + 1 + i, column=header_col)
            self._set_cell_value_preserve_style(target_cell, line)

        if self.logger:
            self.logger.info(f"  - Marks and numbers: {len(marks_data)} lines copied to P.L")

    def _find_marks_header_in_pl(self, ws) -> tuple | None:
        """
        P.L 시트에서 'Marks and numbers' 헤더 셀 찾기

        Args:
            ws: P.L worksheet object

        Returns:
            Tuple of (row, column) or None if not found
        """
        marks_config = self.search_config.get("marks_and_numbers", {})
        keywords = marks_config.get("keywords", ["Marks and numbers", "MARKS AND NUMBERS"])
        search_range = marks_config.get("search_range", 50)

        for row in range(1, search_range + 1):
            for col in range(1, 20):
                cell = ws.cell(row=row, column=col)
                if cell.value:
                    cell_str = str(cell.value).strip()
                    if any(kw.lower() in cell_str.lower() for kw in keywords):
                        return (row, col)

        return None
