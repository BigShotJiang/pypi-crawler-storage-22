"""
MCP Server — Invoice RPA

Publishable MCP server wrapping invoice processing logic.
Install & run: uvx invoice-rpa-mcp
"""

import asyncio
import json
import logging
import os
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass
from functools import partial
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP, Context

from invoice_rpa_mcp.config_loader import ConfigLoader
from invoice_rpa_mcp.data_loader import VariationDataLoader
from invoice_rpa_mcp.duplicate_checker import DuplicateChecker
from invoice_rpa_mcp.invoice_processor import InvoiceProcessor
from invoice_rpa_mcp.sequence_manager import SequenceManager
from invoice_rpa_mcp.utils.logger import setup_logger


# ═══════════════════════════════════════════════════════════════
# 1. CONFIGURATION
# ═══════════════════════════════════════════════════════════════

_PREFIX = "INVOICE"


def _env(name: str, default: str | None = None) -> str | None:
    """Read environment variable with project prefix."""
    return os.environ.get(f"{_PREFIX}_{name}", default)


def resolve_config() -> dict[str, Any]:
    """
    Resolve all configuration from environment variables.
    Falls back to project-relative defaults when unset.

    Environment Variables (all optional):
        INVOICE_INPUT_FOLDER          — Input directory (default: ./input)
        INVOICE_OUTPUT_FOLDER         — Output directory (default: ./output)
        INVOICE_CUSTOMER_MASTER_PATH  — Customer master CSV
        INVOICE_ITEM_LIST_PATH        — Item list CSV
        INVOICE_MCP_TRANSPORT         — Transport: stdio | streamable-http (default: stdio)
    """
    project_root = Path(__file__).parent.parent

    return {
        "project_root": project_root,
        "input_dir": Path(_env(
            "INPUT_FOLDER", str(project_root / "input"),
        )).resolve(),
        "output_dir": Path(_env(
            "OUTPUT_FOLDER", str(project_root / "output"),
        )).resolve(),
        "customer_master_path": Path(_env(
            "CUSTOMER_MASTER_PATH",
            str(project_root / "variation_data" / "customer_master.csv"),
        )).resolve(),
        "item_list_path": Path(_env(
            "ITEM_LIST_PATH",
            str(project_root / "variation_data" / "itemList.csv"),
        )).resolve(),
    }


# ═══════════════════════════════════════════════════════════════
# 2. APPLICATION CONTEXT
# ═══════════════════════════════════════════════════════════════

@dataclass
class AppContext:
    """Resources shared across all tool calls, initialized once at startup."""
    processor: InvoiceProcessor
    input_dir: Path
    output_dir: Path
    config: dict[str, Any]
    logger: logging.Logger


# ═══════════════════════════════════════════════════════════════
# 3. LIFESPAN
# ═══════════════════════════════════════════════════════════════

@asynccontextmanager
async def app_lifespan(server: FastMCP) -> AsyncIterator[AppContext]:
    """Initialize on startup, cleanup on shutdown."""
    config = resolve_config()
    project_root = config["project_root"]

    is_stdio = _env("MCP_TRANSPORT", "stdio") == "stdio"
    logger = setup_logger(
        "invoice_rpa_mcp",
        log_file=project_root / "logs" / "mcp_server.log",
        console=not is_stdio,  # stdio에서는 콘솔 출력 금지
    )

    config_loader = ConfigLoader()
    variation_data_loader = VariationDataLoader(
        customer_master_path=config["customer_master_path"],
        item_list_path=config["item_list_path"],
    )
    variation_data_loader.load_all()

    duplicate_checker = DuplicateChecker()
    sequence_manager = SequenceManager(project_root / ".invoice_sequences.json")

    processor = InvoiceProcessor(
        config_loader, variation_data_loader,
        duplicate_checker, sequence_manager, logger,
    )

    logger.info("MCP Server initialized")
    logger.info(f"  Input:  {config['input_dir']}")
    logger.info(f"  Output: {config['output_dir']}")
    logger.info(f"  Customer Master: {config['customer_master_path']}")
    logger.info(f"  Item List: {config['item_list_path']}")
    logger.info(f"  Loaded {len(variation_data_loader.customer_master)} customer records")
    logger.info(f"  Loaded {len(variation_data_loader.item_list)} item records")

    try:
        yield AppContext(
            processor=processor,
            input_dir=config["input_dir"],
            output_dir=config["output_dir"],
            config=config,
            logger=logger,
        )
    finally:
        logger.info("MCP Server shutting down")


# ═══════════════════════════════════════════════════════════════
# 4. SERVER INSTANCE
# ═══════════════════════════════════════════════════════════════

mcp = FastMCP(
    "invoice-rpa",
    host=_env("MCP_HOST", "0.0.0.0"),
    port=int(_env("MCP_PORT", "8000")),
    lifespan=app_lifespan,
)


# ═══════════════════════════════════════════════════════════════
# 5. HELPERS
# ═══════════════════════════════════════════════════════════════

def _app(ctx: Context) -> AppContext:
    """Extract AppContext from request context."""
    return ctx.request_context.lifespan_context


async def _run_sync(func, *args, **kwargs):
    """Run sync function in thread pool without blocking the event loop."""
    loop = asyncio.get_event_loop()
    if kwargs:
        return await loop.run_in_executor(None, partial(func, *args, **kwargs))
    return await loop.run_in_executor(None, partial(func, *args))


def _json(data: Any) -> str:
    """Serialize to JSON with Korean/CJK support and Path safety."""
    return json.dumps(data, ensure_ascii=False, indent=2, default=str)


def _scan_input_files(input_dir: Path) -> list[Path]:
    """Scan input directory for processable .xlsx files (exclude temp files)."""
    if not input_dir.exists():
        return []
    return [f for f in sorted(input_dir.glob("*.xlsx")) if not f.name.startswith("~$")]


# ═══════════════════════════════════════════════════════════════
# 6. TOOLS
# ═══════════════════════════════════════════════════════════════

@mcp.tool()
async def process_all_invoices(ctx: Context) -> str:
    """
    input 폴더의 모든 .xlsx 인보이스 파일을 일괄 처리합니다.
    처리 결과(성공/스킵/실패)를 요약하여 반환합니다.
    """
    app = _app(ctx)

    if not app.input_dir.exists():
        return _json({"status": "error", "error": f"Input directory not found: {app.input_dir}"})

    input_files = _scan_input_files(app.input_dir)
    if not input_files:
        return _json({"status": "success", "total": 0, "message": "처리할 파일이 없습니다."})

    results = []
    for f in input_files:
        try:
            result = await _run_sync(app.processor.process_file, f, app.output_dir)
            results.append(result)
        except Exception as e:
            results.append({"status": "error", "input_file": f.name, "error": str(e)})

    successful = [r for r in results if r.get("status") == "success"]
    skipped = [r for r in results if r.get("status") == "skipped"]
    failed = [r for r in results if r.get("status") == "error"]

    details = []
    for r in results:
        detail = {"file": r.get("input_file", ""), "status": r.get("status", "")}
        if r.get("output_file"):
            detail["output"] = r["output_file"]
        if r.get("reason"):
            detail["reason"] = r["reason"]
        if r.get("message"):
            detail["message"] = r["message"]
        details.append(detail)

    return _json({
        "status": "success",
        "total": len(results),
        "success": len(successful),
        "skipped": len(skipped),
        "failed": len(failed),
        "details": details,
    })


@mcp.tool()
async def process_single_invoice(filename: str, ctx: Context) -> str:
    """
    input 폴더 내 특정 .xlsx 파일 1개를 처리합니다.

    Args:
        filename: 처리할 파일명 (예: "Contract No.DRBVN 12345 (15-01-2024) KUBOTA-OSK, JAPAN.xlsx")
    """
    app = _app(ctx)
    filepath = app.input_dir / filename

    if not filepath.exists():
        return _json({
            "status": "error",
            "error": f"파일을 찾을 수 없습니다: {filename}",
            "suggestion": "list_input_files 도구로 처리 가능한 파일 목록을 확인하세요.",
        })

    try:
        result = await _run_sync(app.processor.process_file, filepath, app.output_dir)
        return _json(result)
    except Exception as e:
        return _json({"status": "error", "file": filename, "error": str(e)})


@mcp.tool()
async def list_input_files(ctx: Context) -> str:
    """
    input 폴더에 있는 처리 대상 .xlsx 파일 목록을 반환합니다.
    임시 파일(~$로 시작)은 제외됩니다.
    """
    app = _app(ctx)

    if not app.input_dir.exists():
        return _json({"status": "error", "error": f"Input directory not found: {app.input_dir}"})

    input_files = _scan_input_files(app.input_dir)

    return _json({
        "status": "success",
        "input_dir": str(app.input_dir),
        "count": len(input_files),
        "files": [
            {"name": f.name, "size_bytes": f.stat().st_size}
            for f in input_files
        ],
    })


@mcp.tool()
async def get_server_config(ctx: Context) -> str:
    """현재 서버 설정 정보(input/output 경로, CSV 경로, 로드된 데이터 건수)를 반환합니다."""
    app = _app(ctx)

    return _json({
        "status": "success",
        "config": {
            "input_dir": str(app.config["input_dir"]),
            "output_dir": str(app.config["output_dir"]),
            "customer_master_path": str(app.config["customer_master_path"]),
            "item_list_path": str(app.config["item_list_path"]),
            "input_dir_exists": app.input_dir.exists(),
            "output_dir_exists": app.output_dir.exists(),
        },
        "loaded_data": {
            "customer_records": len(app.processor.variation_data.customer_master),
            "item_records": len(app.processor.variation_data.item_list),
        },
    })


# ═══════════════════════════════════════════════════════════════
# 6b. STATE MANAGEMENT TOOLS
# ═══════════════════════════════════════════════════════════════

@mcp.tool()
async def get_history(ctx: Context) -> str:
    """
    처리 이력을 조회합니다.
    어떤 파일이 언제 처리되었는지, 출력 파일명은 무엇인지 확인할 수 있습니다.
    """
    app = _app(ctx)
    checker = app.processor.duplicate_checker

    return _json({
        "status": "success",
        "history_file": str(checker.history_file),
        "count": len(checker.history),
        "entries": checker.history,
    })


@mcp.tool()
async def reset_history(filename: str = "", ctx: Context = None) -> str:
    """
    처리 이력을 초기화합니다. 초기화된 파일은 다시 처리할 수 있게 됩니다.

    Args:
        filename: 특정 파일만 초기화할 경우 파일명 입력. 빈 문자열이면 전체 초기화.
    """
    app = _app(ctx)
    checker = app.processor.duplicate_checker

    if filename:
        if filename not in checker.history:
            return _json({
                "status": "error",
                "error": f"이력에 없는 파일입니다: {filename}",
                "suggestion": "get_history 도구로 현재 이력을 확인하세요.",
            })
        del checker.history[filename]
        checker._save_history()
        return _json({
            "status": "success",
            "message": f"이력에서 제거됨: {filename}",
            "remaining": len(checker.history),
        })

    count = len(checker.history)
    checker.history.clear()
    checker._save_history()
    return _json({
        "status": "success",
        "message": f"전체 이력 초기화 완료 ({count}건 삭제)",
        "remaining": 0,
    })


@mcp.tool()
async def get_sequences(ctx: Context) -> str:
    """
    인보이스 번호 시퀀스 상태를 조회합니다.
    각 고객 키별 현재 시퀀스 번호를 확인할 수 있습니다.
    """
    app = _app(ctx)
    seq = app.processor.sequence_manager

    return _json({
        "status": "success",
        "sequence_file": str(seq.storage_path),
        "count": len(seq.sequences),
        "sequences": seq.sequences,
    })


@mcp.tool()
async def reset_sequence(key: str = "", ctx: Context = None) -> str:
    """
    인보이스 번호 시퀀스를 초기화합니다. 초기화하면 다음 번호가 1부터 다시 시작됩니다.

    Args:
        key: 특정 시퀀스 키만 초기화할 경우 입력 (예: "Caterpillar_2026"). 빈 문자열이면 전체 초기화.
    """
    app = _app(ctx)
    seq = app.processor.sequence_manager

    if key:
        if key not in seq.sequences:
            return _json({
                "status": "error",
                "error": f"존재하지 않는 시퀀스 키: {key}",
                "suggestion": "get_sequences 도구로 현재 시퀀스를 확인하세요.",
            })
        old_value = seq.sequences.pop(key)
        seq._save()
        return _json({
            "status": "success",
            "message": f"시퀀스 초기화: {key} (이전 값: {old_value})",
            "remaining": len(seq.sequences),
        })

    count = len(seq.sequences)
    seq.sequences.clear()
    seq._save()
    return _json({
        "status": "success",
        "message": f"전체 시퀀스 초기화 완료 ({count}건 삭제)",
        "remaining": 0,
    })


# ═══════════════════════════════════════════════════════════════
# 7. ENTRY POINT
# ═══════════════════════════════════════════════════════════════

def main():
    """Entry point — called by `uvx invoice-rpa-mcp` or `[project.scripts]`."""
    transport = _env("MCP_TRANSPORT", "stdio")
    mcp.run(transport=transport)


if __name__ == "__main__":
    main()
