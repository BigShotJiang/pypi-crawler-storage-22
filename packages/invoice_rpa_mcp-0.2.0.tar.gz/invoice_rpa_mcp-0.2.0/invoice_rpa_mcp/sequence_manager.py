
import json
from pathlib import Path
from typing import Dict, Optional

class SequenceManager:
    """Manage auto-incrementing sequences for invoice numbers"""

    def __init__(self, storage_path: Path):
        """
        Initialize SequenceManager

        Args:
            storage_path: Path to the JSON file storing sequences
        """
        self.storage_path = storage_path
        self.sequences: Dict[str, int] = {}
        self._load()

    def _load(self):
        """Load sequences from file"""
        if self.storage_path.exists():
            try:
                with open(self.storage_path, 'r', encoding='utf-8') as f:
                    self.sequences = json.load(f)
            except (json.JSONDecodeError, OSError):
                self.sequences = {}
        else:
            self.sequences = {}

    def _save(self):
        """Save sequences to file"""
        with open(self.storage_path, 'w', encoding='utf-8') as f:
            json.dump(self.sequences, f, indent=2, ensure_ascii=False)

    def get_next_sequence(self, key: str) -> int:
        """
        Get the next sequence number for a key without incrementing
        
        Args:
            key: Sequence key (e.g., 'Caterpillar_2026')
            
        Returns:
            Next sequence number (starts at 1)
        """
        return self.sequences.get(key, 0) + 1

    def commit_sequence(self, key: str):
        """
        Increment and save the sequence for a key
        
        Args:
            key: Sequence key
        """
        self.sequences[key] = self.sequences.get(key, 0) + 1
        self._save()
