"""Template selection based on customer type"""

from pathlib import Path
from typing import Dict


class TemplateSelector:
    """Select appropriate template based on customer type"""

    def __init__(self, customer_types: Dict, templates_dir: Path = None):
        """
        Initialize template selector

        Args:
            customer_types: Customer type configuration
            templates_dir: Path to templates directory
        """
        self.customer_types = customer_types

        if templates_dir is None:
            project_root = Path(__file__).parent.parent
            templates_dir = project_root / 'templates'

        self.templates_dir = Path(templates_dir)

    def get_customer_type(self, customer_name: str) -> str:
        """
        Determine customer type (US, Japan, India, Europe)

        Args:
            customer_name: Customer name

        Returns:
            Customer type string

        Raises:
            ValueError: If customer type not found
        """
        types_mapping = self.customer_types.get('customer_types', {})

        for customer_type, customers in types_mapping.items():
            if customer_name in customers:
                return customer_type

        raise ValueError(f"Customer type not found for: {customer_name}")

    def select_template(self, customer_name: str) -> Path:
        """
        Select template path based on customer

        Args:
            customer_name: Customer name

        Returns:
            Path to template file

        Raises:
            FileNotFoundError: If template file doesn't exist
        """
        customer_type = self.get_customer_type(customer_name)

        # US customers use US template, others use standard template
        if customer_type == "US":
            template_name = "OUTPUT_BLANKFILE_US_V2.2.xlsx"
        else:
            template_name = "OUTPUT_BLANKFILE_V2.xlsx"

        template_path = self.templates_dir / template_name

        if not template_path.exists():
            raise FileNotFoundError(f"Template not found: {template_path}")

        return template_path

    def get_row_positions(self, customer_name: str) -> Dict[str, int]:
        """
        Get row position configuration for customer type

        Args:
            customer_name: Customer name

        Returns:
            Dictionary with row position configuration
        """
        customer_type = self.get_customer_type(customer_name)
        row_positions = self.customer_types.get('row_positions', {})

        if customer_type not in row_positions:
            raise ValueError(f"Row positions not found for type: {customer_type}")

        return row_positions[customer_type]
