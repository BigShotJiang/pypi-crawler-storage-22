"""Detail PL sheet structure analyzer for extracting weight data"""

import openpyxl
from openpyxl.worksheet.worksheet import Worksheet
from typing import Dict, List, Any, Optional
import logging


logger = logging.getLogger(__name__)


class DetailPLAnalyzer:
    """Analyze Detail PL sheet structure and extract weight data"""

    def __init__(self, logger=None):
        self.logger = logger or logging.getLogger(__name__)

    def analyze_sheet_structure(self, worksheet: Worksheet) -> Dict[str, Any]:
        """
        Analyze Detail PL sheet structure comprehensively

        Args:
            worksheet: Worksheet to analyze

        Returns:
            Dictionary with structure information
        """
        structure = {
            "has_data": False,
            "data_rows": 0,
            "hidden_rows": 0,
            "grand_total_row": -1,
            "column_mapping": {},
            "n_wgt_col": None,
            "g_wgt_col": None,
            "cbm_col": None,
            "row_with_grand_total": -1,
        }

        # First, find weight columns by searching headers in first 10 rows
        for row_idx in range(1, min(11, worksheet.max_row + 1)):
            for col_idx in range(1, worksheet.max_column + 1):
                cell_value = worksheet.cell(row=row_idx, column=col_idx).value
                if not cell_value:
                    continue

                cell_str = str(cell_value).strip().upper()

                # Match N.W (Kg) - look for "N.W" and "KG"
                if 'N.W' in cell_str and 'KG' in cell_str and not structure["n_wgt_col"]:
                    structure["n_wgt_col"] = col_idx

                # Match G.W (Kg) - look for "G.W" and "KG"
                elif 'G.W' in cell_str and 'KG' in cell_str and not structure["g_wgt_col"]:
                    structure["g_wgt_col"] = col_idx

                # Match CBM - exact match
                elif cell_str == 'CBM' and not structure["cbm_col"]:
                    structure["cbm_col"] = col_idx

            # Stop if all three columns are found
            if all([structure["n_wgt_col"], structure["g_wgt_col"], structure["cbm_col"]]):
                break

        # Analyze structure row by row
        for row_idx, row in enumerate(worksheet.iter_rows(), 1):
            has_data = any(cell.value for cell in row if cell.value is not None)

            if has_data:
                structure["has_data"] = True
                structure["data_rows"] += 1

                # Look for GRAND TOTAL in first column
                first_cell_value = row[0].value
                if first_cell_value and "GRAND TOTAL" in str(first_cell_value).upper():
                    structure["row_with_grand_total"] = row_idx

            # Check if row is empty
            is_empty = not any(cell.value for cell in row if cell.value is not None)
            if is_empty:
                structure["hidden_rows"] += 1

        structure["total_rows"] = worksheet.max_row
        return structure

    def find_weights_data(
        self, worksheet: Worksheet, structure: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Extract N.WGT, G.WGT, CBM values from GRAND TOTAL row

        Args:
            worksheet: Worksheet
            structure: Analyzed structure

        Returns:
            Dictionary with extracted weight data
        """
        weights = {
            "n_wgt": None,
            "g_wgt": None,
            "cbm": None,
            "found_grand_total": False,
        }

        # Use "row_with_grand_total" key to match analyze_sheet_structure()
        grand_total_row = structure.get("row_with_grand_total", -1)
        if grand_total_row == -1:
            return weights

        weights["found_grand_total"] = True

        # Extract values from appropriate columns using 1-based indexing
        if structure["n_wgt_col"]:
            n_wgt_cell = worksheet.cell(row=grand_total_row, column=structure["n_wgt_col"])
            weights["n_wgt"] = self._extract_numeric_value(n_wgt_cell)
            if self.logger and weights["n_wgt"]:
                self.logger.debug(
                    f"    - N.WGT value: {weights['n_wgt']} (col {structure['n_wgt_col']})"
                )

        if structure["g_wgt_col"]:
            g_wgt_cell = worksheet.cell(row=grand_total_row, column=structure["g_wgt_col"])
            weights["g_wgt"] = self._extract_numeric_value(g_wgt_cell)
            if self.logger and weights["g_wgt"]:
                self.logger.debug(
                    f"    - G.WGT value: {weights['g_wgt']} (col {structure['g_wgt_col']})"
                )

        if structure["cbm_col"]:
            cbm_cell = worksheet.cell(row=grand_total_row, column=structure["cbm_col"])
            weights["cbm"] = self._extract_numeric_value(cbm_cell)
            if self.logger and weights["cbm"]:
                self.logger.debug(
                    f"    - CBM value: {weights['cbm']} (col {structure['cbm_col']})"
                )

        return weights

    def _extract_numeric_value(self, cell) -> Optional[float]:
        """
        Extract numeric value from cell

        Args:
            cell: Cell object

        Returns:
            Float value or None
        """
        if cell.value is None:
            return None

        try:
            # Try to parse as float
            value = str(cell.value).strip().replace(",", "")
            if value:
                return float(value)
        except (ValueError, TypeError):
            return None

    def log_analysis_summary(self, structure: Dict[str, Any], weights: Dict[str, Any]):
        """
        Log comprehensive analysis summary

        Args:
            structure: Sheet structure analysis
            weights: Extracted weight data
        """
        if not self.logger:
            return

        self.logger.info(" === Detail PL Sheet Analysis Summary ===")
        self.logger.info(f"  - Total rows: {structure['total_rows']}")
        self.logger.info(f"  - Data rows: {structure['data_rows']}")
        self.logger.info(f"  - Has data: {structure['has_data']}")

        if structure["row_with_grand_total"] != -1:
            self.logger.info(
                f"  - GRAND TOTAL row: {structure['row_with_grand_total']}"
            )

        self.logger.info(" === Weight Data ===")

        if weights["found_grand_total"]:
            self.logger.info(f"  - N.WGT: {weights['n_wgt']}")
            self.logger.info(f"  - G.WGT: {weights['g_wgt']}")
            self.logger.info(f"  - CBM: {weights['cbm']}")
        else:
            self.logger.warning("  - No weight data extracted")
