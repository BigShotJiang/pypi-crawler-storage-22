"""Excel utility functions"""

from openpyxl.worksheet.worksheet import Worksheet
from openpyxl.utils import get_column_letter
from typing import Tuple, Optional, Any
import openpyxl
from pathlib import Path


def find_cell_by_text(
    worksheet: Worksheet, search_text: str
) -> Optional[Tuple[int, int]]:
    """
    Find cell containing specific text

    Args:
        worksheet: Worksheet to search
        search_text: Text to find

    Returns:
        Tuple of (row, column) or None if not found
    """
    for row in worksheet.iter_rows():
        for cell in row:
            if cell.value and search_text in str(cell.value):
                return (cell.row, cell.column)
    return None


def get_merged_cell_value(worksheet: Worksheet, cell_ref: str) -> Optional[str]:
    """
    Get value from merged cell range

    Args:
        worksheet: Worksheet containing the cell
        cell_ref: Cell reference (e.g., 'A1')

    Returns:
        Cell value or None
    """
    cell = worksheet[cell_ref]

    # Check if cell is part of a merged range
    for merged_range in worksheet.merged_cells.ranges:
        if cell.coordinate in merged_range:
            # Get the top-left cell of the merged range
            min_col, min_row, max_col, max_row = merged_range.bounds
            top_left_cell = worksheet.cell(min_row, min_col)
            return top_left_cell.value

    return cell.value


def copy_template(template_path: Path, output_path: Path = None):
    """
    Copy template workbook

    Args:
        template_path: Path to template file
        output_path: Optional output path (if None, returns workbook)

    Returns:
        Workbook object if output_path is None
    """
    wb = openpyxl.load_workbook(template_path)

    if output_path:
        wb.save(output_path)
        wb.close()
    else:
        return wb


def is_cell_empty(value: Any) -> bool:
    """
    Check if cell value is empty or whitespace

    Args:
        value: Cell value

    Returns:
        True if empty or whitespace only
    """
    if value is None:
        return True

    if isinstance(value, str):
        return not value.strip()

    return False


def get_cell_value_safe(worksheet: Worksheet, cell_ref: str) -> Any:
    """
    Get cell value safely (handles None and errors)

    Args:
        worksheet: Worksheet
        cell_ref: Cell reference

    Returns:
        Cell value or None
    """
    try:
        value = worksheet[cell_ref].value
        if value is None:
            return None
        if isinstance(value, str):
            return value.strip()
        return value
    except:
        return None


def find_sheet(wb, target_name: str, logger=None, sheet_config=None):
    """
    Find sheet by name with comprehensive matching (case-insensitive, ignoring whitespace,
    multiple spacing variations, partial match, and configuration-based aliases)

    Args:
        wb: Workbook object
        target_name: Target sheet name to search for
        logger: Logger instance for detailed logging
        sheet_config: Sheet configuration dictionary with aliases

    Returns:
        Worksheet object

    Raises:
        ValueError: If sheet not found
    """
    # Load sheet aliases from config if provided
    aliases = []
    if sheet_config and "sheet_aliases" in sheet_config:
        aliases = sheet_config["sheet_aliases"].get(target_name, [])

    # Combine direct target with aliases
    search_targets = [target_name] + aliases if aliases else [target_name]

    # Normalize target name: remove extra spaces and standardize punctuation
    def normalize_sheet_name(name: str) -> str:
        """Normalize sheet name by removing extra spaces and standardizing punctuation"""
        normalized = name.strip().replace("  ", " ").replace("  ", " ")
        # Standardize common variations
        normalized = normalized.replace("P.L", "PL").replace("P.L ", "PL ")
        return normalized

    # Normalize all targets
    normalized_targets = [normalize_sheet_name(t) for t in search_targets]

    # Log search details
    if logger:
        logger.debug(f"  - Finding sheet: {target_name}")
        logger.debug(f"  - Search targets (normalized): {normalized_targets}")
        logger.debug(f"  - Available sheets: {wb.sheetnames}")

    # 1. Exact match (ignoring whitespace)
    for sheet_name in wb.sheetnames:
        if normalize_sheet_name(sheet_name) in normalized_targets:
            if logger:
                logger.debug(f"  - Found exact match: '{sheet_name}'")
            return wb[sheet_name]

    # 2. Case-insensitive match (ignoring whitespace)
    for sheet_name in wb.sheetnames:
        normalized_sheet = normalize_sheet_name(sheet_name).lower()
        for target in normalized_targets:
            if target.lower() == normalized_sheet:
                if logger:
                    logger.debug(f"  - Found case-insensitive match: '{sheet_name}'")
                return wb[sheet_name]

    # 3. Partial match (target in sheet name)
    for sheet_name in wb.sheetnames:
        for target in normalized_targets:
            if target.lower() in sheet_name.lower():
                if logger:
                    logger.debug(
                        f"  - Found partial match: '{sheet_name}' (target: '{target}')"
                    )
                return wb[sheet_name]

    raise ValueError(
        f"Sheet '{target_name}' not found in workbook (Available: {wb.sheetnames})"
    )
