"""Unified Excel operations utility class"""

import openpyxl
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
from openpyxl.utils import get_column_letter
from invoice_rpa_mcp.utils.excel_helper import get_cell_value_safe, get_merged_cell_value


class ExcelOperations:
    """Unified Excel operations with common patterns and fallbacks"""

    def __init__(self, sheet_config: Dict[str, Any] | None = None):
        """
        Initialize Excel operations

        Args:
            sheet_config: Sheet name mappings configuration
        """
        self.sheet_config = sheet_config or {}

    def find_sheet(self, wb, target_name: str):
        """
        Find sheet by name using dynamic configuration with flexible matching

        Args:
            wb: Workbook object
            target_name: Target sheet name

        Returns:
            Worksheet object

        Raises:
            ValueError: If sheet not found
        """
        # Check if we have sheet config
        if self.sheet_config and "sheet_aliases" in self.sheet_config:
            sheet_aliases = self.sheet_config["sheet_aliases"]

            # Get all possible names for target
            possible_names = sheet_aliases.get(target_name, [target_name])

            # Try each possible name
            for name in possible_names:
                for sheet_name in wb.sheetnames:
                    if sheet_name.strip() == name.strip():
                        return wb[sheet_name]
                    if sheet_name.strip().lower() == name.strip().lower():
                        return wb[sheet_name]
                    if name in sheet_name:
                        return wb[sheet_name]

        # Fallback to original logic
        for sheet_name in wb.sheetnames:
            if sheet_name.strip() == target_name.strip():
                return wb[sheet_name]

        for sheet_name in wb.sheetnames:
            if sheet_name.strip().lower() == target_name.strip().lower():
                return wb[sheet_name]

        for sheet_name in wb.sheetnames:
            if target_name in sheet_name:
                return wb[sheet_name]

        raise ValueError(
            f"Sheet '{target_name}' not found in workbook (Available: {wb.sheetnames})"
        )

    def get_cell_with_fallback(self, ws, cell_config: Dict[str, Any]) -> Any:
        """
        Get cell value with fallback support using dynamic configuration

        Args:
            ws: Worksheet object
            cell_config: Cell configuration with primary/fallback cells

        Returns:
            Cell value or None
        """
        if "cell" in cell_config:
            # Single cell
            return get_cell_value_safe(ws, cell_config["cell"])
        elif "primary" in cell_config:
            # Primary with fallback
            value = get_cell_value_safe(ws, cell_config["primary"])
            if not value:
                value = get_cell_value_safe(ws, cell_config["fallback"])
            return value
        return None

    def get_merged_cell_with_fallback(self, ws, cell_config: Dict[str, Any]) -> Any:
        """
        Get merged cell value with fallback support

        Args:
            ws: Worksheet object
            cell_config: Cell configuration with primary/fallback cells

        Returns:
            Merged cell value or None
        """
        if "cell" in cell_config:
            # Single cell
            return get_merged_cell_value(ws, cell_config["cell"])
        elif "primary" in cell_config:
            # Primary with fallback
            value = get_merged_cell_value(ws, cell_config["primary"])
            if not value or (isinstance(value, str) and not value.strip()):
                value = get_merged_cell_value(ws, cell_config["fallback"])
            return value
        return None

    def get_sheet_name_config(self, sheet_type: str) -> str:
        """
        Get sheet name from config or fallback to default

        Args:
            sheet_type: Type of sheet (e.g., 'invoice_metadata', 'items')

        Returns:
            Sheet name
        """
        if self.sheet_config and "input_sheets" in self.sheet_config:
            return self.sheet_config["input_sheets"].get(sheet_type, sheet_type)
        return sheet_type

    def search_headers(
        self,
        ws,
        header_keywords: Dict[str, List[str]],
        search_range: Tuple[
            int, int, int, int
        ],  # (start_row, end_row, start_col, end_col)
        required_headers: List[str] | None = None,
    ) -> Tuple[int, Dict[str, int]]:
        """
        Search for headers in worksheet

        Args:
            ws: Worksheet object
            header_keywords: Dictionary mapping field names to keyword lists
            search_range: (start_row, end_row, start_col, end_col) for search area
            required_headers: List of headers that must be present

        Returns:
            Tuple of (header_row, column_mapping)
        """
        start_row, end_row, start_col, end_col = search_range
        found_header_row = -1
        col_map = {}

        # Search for header row
        for row in range(start_row, end_row + 1):
            row_values = []
            for col in range(start_col, end_col + 1):
                val = get_cell_value_safe(ws, f"{get_column_letter(col)}{row}")
                row_values.append(str(val).upper().strip() if val else "")

            # Check if required headers are present
            if required_headers:
                has_required = all(
                    any(k in val for val in row_values for k in header_keywords[field])
                    for field in required_headers
                )
                if not has_required:
                    continue

            # Build column mapping
            for col_idx, val in enumerate(row_values, start_col):
                if not val:
                    continue

                for field, keywords in header_keywords.items():
                    if any(k in val for k in keywords):
                        # Handle conflicts (e.g., "Unit Price" should match Price, not Unit)
                        if field == "unit" and "PRICE" in val:
                            continue
                        if field == "price" and "AMOUNT" in val:
                            continue
                        col_map[field] = col_idx

            if col_map:
                found_header_row = row
                break

        return found_header_row, col_map

    def apply_formula_to_cell(self, ws, cell_ref: str, formula: str) -> None:
        """
        Apply formula to cell with error handling

        Args:
            ws: Worksheet object
            cell_ref: Cell reference (e.g., "A1")
            formula: Formula string (e.g., "=A1*B1")
        """
        try:
            ws[cell_ref] = formula
        except Exception as e:
            # Log error or handle gracefully
            ws[cell_ref] = f"#ERROR: {str(e)}"

    def sum_range(
        self,
        ws,
        start_cell: str,
        end_cell: str,
        target_cell: str,
    ) -> None:
        """
        Apply SUM formula to range

        Args:
            ws: Worksheet object
            start_cell: Start cell reference (e.g., "A1")
            end_cell: End cell reference (e.g., "A10")
            target_cell: Target cell for SUM formula
        """
        formula = f"=SUM({start_cell}:{end_cell})"
        self.apply_formula_to_cell(ws, target_cell, formula)

    def round_multiply(
        self, ws, qty_cell: str, price_cell: str, target_cell: str, decimals: int = 2
    ) -> None:
        """
        Apply ROUND formula for quantity * price

        Args:
            ws: Worksheet object
            qty_cell: Quantity cell reference
            price_cell: Price cell reference
            target_cell: Target cell for formula
            decimals: Number of decimal places
        """
        formula = f"=ROUND({qty_cell}*{price_cell}, {decimals})"
        self.apply_formula_to_cell(ws, target_cell, formula)
