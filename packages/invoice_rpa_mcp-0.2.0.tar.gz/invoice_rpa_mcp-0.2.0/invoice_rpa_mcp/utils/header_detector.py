"""Header detection utility for Excel table analysis"""

from typing import Dict, List, Tuple, Any
from openpyxl.utils import get_column_letter
from invoice_rpa_mcp.utils.excel_helper import get_cell_value_safe


class HeaderDetector:
    """Utility class for detecting and mapping Excel table headers"""

    def __init__(self, search_config: Dict[str, Any] | None = None):
        """
        Initialize header detector

        Args:
            search_config: Search configuration from search_config.json
        """
        self.search_config = search_config or {}

    def get_default_keywords(self) -> Dict[str, List[str]]:
        """Get default header keywords"""
        return {
            # Removed "ARTICLE" and "ITEM" - too generic, match section headers like "ARTICLE 1"
            # Added more variants for better matching across different file formats
            "code": [
                "CODE", "MATERIAL CODE", "MATERIAL",
                "ITEM CODE", "ITEM NO", "ITEM NUMBER",
                "P/N", "PN", "PART NO", "PART NUMBER", "PART#",
                "PRODUCT CODE", "PRODUCT NO"
            ],
            "description": ["DESCRIPTION", "COMMODITY", "NAME", "DESC", "ITEM NAME"],
            "image": ["IMAGE", "PICTURE", "PHOTO"],
            "quantity": ["QTY", "QUANTITY", "Q'TY", "Q.TY", "QTY.", "Q'T.Y"],
            "unit": ["UNIT", "UOM", "U/M"],
            "price": ["PRICE", "UNIT PRICE", "U/PRICE", "PRICE/UNIT"],
            "amount": ["AMOUNT", "AMT", "TOTAL", "SUM"],
            # Output sheet specific headers
            "NO": ["NO", "NO.", "N.O", "N.O.", "SO", "S.O", "S.O."],
            "PN": ["PN", "P/N", "PART NUMBER"],
            "TYPE_SIZE": ["TYPE & SIZE", "TYPE", "SIZE"],
            "SO": ["SO", "S.O", "S.O.", "SALES ORDER"],
        }

    def detect_table_headers(
        self,
        worksheet,
        estimated_row: int,
        max_columns: int = 15,
        rows_before: int = 2,
        rows_after: int = 5,
        required_headers: List[str] | None = None,
    ) -> Tuple[int, Dict[str, int]]:
        """
        Detect table headers in worksheet

        Args:
            worksheet: Excel worksheet object
            estimated_row: Estimated starting row for headers
            max_columns: Maximum number of columns to search
            rows_before: Number of rows before estimated to search
            rows_after: Number of rows after estimated to search
            required_headers: Headers that must be present

        Returns:
            Tuple of (header_row, column_mapping)
        """
        # Get configuration or use defaults
        if self.search_config and "table_analysis" in self.search_config:
            header_search = self.search_config["table_analysis"]["header_search"]
            rows_before = header_search.get("rows_before_estimated", rows_before)
            rows_after = header_search.get("rows_after_estimated", rows_after)
            max_columns = self.search_config["table_analysis"]["column_search"].get(
                "max_columns", max_columns
            )
        else:
            # Increase defaults for better detection when no config is provided
            rows_before = 5  # Expanded from default 2 to cover more header variations
            rows_after = 10  # Expanded from default 5 to cover more header variations

        # Define search range
        search_start = max(1, estimated_row - rows_before)
        search_end = estimated_row + rows_after

        # Get header keywords
        header_keywords = self.get_default_keywords()
        if self.search_config and "table_analysis" in self.search_config:
            header_keywords.update(
                self.search_config["table_analysis"]["header_keywords"]
            )

        required_headers = required_headers or ["code", "quantity"]

        found_header_row = -1
        col_map = {}

        # Search for header row
        for row in range(search_start, search_end + 1):
            row_values = []
            for col in range(1, max_columns + 1):
                val = get_cell_value_safe(worksheet, f"{get_column_letter(col)}{row}")
                # Normalize: replace newlines/tabs with spaces, then clean up
                if val:
                    normalized = str(val).replace('\n', ' ').replace('\r', ' ').replace('\t', ' ')
                    normalized = ' '.join(normalized.split())  # Remove multiple spaces
                    row_values.append(normalized.upper().strip())
                else:
                    row_values.append("")

            # Check if required headers are present
            has_required = all(
                any(k in val for val in row_values for k in header_keywords[field])
                for field in required_headers
            )

            if not has_required:
                continue

            # Reject rows that look like section headers, not table headers
            # Section headers often have multiple keywords in one cell
            is_section_header = False
            for val in row_values:
                if not val:
                    continue

                # Count how many different header field keywords appear in this cell
                field_matches = 0
                for field in header_keywords:
                    if any(k in val for k in header_keywords[field]):
                        field_matches += 1

                # If one cell has 3+ different field keywords, it's likely a section header
                # Example: ": COMMODITY - QUANTITY - PRICE" matches 3 fields
                if field_matches >= 3:
                    is_section_header = True
                    break

                # Check for "ARTICLE N" pattern (section header, not table header)
                # Example: "ARTICLE 1" should not be treated as a CODE header
                import re
                if re.match(r'^ARTICLE\s+\d+', val, re.IGNORECASE):
                    is_section_header = True
                    break

            if is_section_header:
                continue

            # Build column mapping
            for col_idx, val in enumerate(row_values, 1):
                if not val:
                    continue

                for field, keywords in header_keywords.items():
                    if any(k in val for k in keywords):
                        # Handle conflicts
                        if field == "unit" and "PRICE" in val:
                            continue
                        if field == "price" and "AMOUNT" in val:
                            continue
                        if field == "SO" and "S.O." in val and "N.O." in val:
                            # Prefer NO over SO for ambiguous headers
                            if "NO" in header_keywords and any(
                                k in val for k in header_keywords["NO"]
                            ):
                                col_map["NO"] = col_idx
                                continue

                        # Prevent "NO" from being mapped as "code"
                        # Let "MATERIAL"/"CODE" keywords take priority
                        if field == "NO" and "code" not in col_map:
                            # Skip NO field if we haven't found code yet
                            continue

                        col_map[field] = col_idx

            if col_map:
                found_header_row = row
                break

        return found_header_row, col_map

    def detect_output_headers(
        self,
        worksheet,
        search_start: int = 1,
        search_end: int = 50,
        max_columns: int = 20,
    ) -> Tuple[int, Dict[str, int]]:
        """
        Detect headers in output template (I.V sheet)

        Args:
            worksheet: Excel worksheet object
            search_start: Starting row for search
            search_end: Ending row for search
            max_columns: Maximum number of columns to search

        Returns:
            Tuple of (header_row, column_mapping)
        """
        # Get configuration or use defaults
        if self.search_config and "output_mapping" in self.search_config:
            header_search = self.search_config["output_mapping"]["header_search"]
            search_end = header_search.get("max_rows", search_end)
            max_columns = self.search_config["output_mapping"]["column_search"].get(
                "max_columns", max_columns
            )

        # Output-specific keywords
        output_keywords = {
            "NO": ["NO", "NO.", "N.O", "N.O."],
            "SO": ["SO", "S.O", "S.O."],
            "PN": ["PN", "P/N", "PART NUMBER"],
            "CODE": ["CODE", "MATERIAL", "ITEM"],
            "TYPE_SIZE": ["TYPE & SIZE", "TYPE"],
            "QUANTITY": ["QUANTITY", "QTY", "Q'TY"],
            "UNIT": ["UNIT", "U/M", "UOM"],
            "PRICE": ["PRICE", "UNIT PRICE"],
            "AMOUNT": ["AMOUNT", "AMT"],
        }

        # Search for header indicators
        for row in range(search_start, search_end + 1):
            cell_value = get_cell_value_safe(worksheet, f"A{row}")
            if cell_value:
                cell_text = str(cell_value).strip().upper()
                if cell_text in ["NO", "NO.", "N.O", "N.O.", "SO", "S.O", "S.O."]:
                    # Found header row, now analyze all columns
                    row_values = []
                    for col in range(1, max_columns + 1):
                        val = get_cell_value_safe(
                            worksheet, f"{get_column_letter(col)}{row}"
                        )
                        row_values.append(str(val).strip().upper() if val else "")

                    col_map = {}
                    for col_idx, val in enumerate(row_values, 1):
                        if not val:
                            continue

                        for field, keywords in output_keywords.items():
                            if any(k in val for k in keywords):
                                col_map[field] = col_idx

                    if col_map:
                        return row, col_map

        # Fallback if not found
        return -1, {}

    def find_total_row(
        self, worksheet, header_row: int, max_rows_after: int = 50
    ) -> int:
        """
        Find TOTAL row in worksheet

        Args:
            worksheet: Excel worksheet object
            header_row: Row where headers were found
            max_rows_after: Maximum rows to search after header

        Returns:
            Row number of TOTAL row, or -1 if not found
        """
        # Get configuration or use defaults
        if self.search_config and "output_mapping" in self.search_config:
            max_rows_after = self.search_config["output_mapping"][
                "total_row_search"
            ].get("max_rows_after_header", max_rows_after)

        for row in range(header_row + 1, header_row + max_rows_after + 1):
            val = get_cell_value_safe(worksheet, f"A{row}")
            if val and str(val).strip().upper() == "TOTAL":
                return row

        return -1

    def apply_column_mapping_defaults(
        self, col_map: Dict[str, int], code_col: int = 3
    ) -> Dict[str, int]:
        """
        Apply default column mappings based on code column position

        Args:
            col_map: Existing column mapping
            code_col: Column position of CODE field

        Returns:
            Updated column mapping
        """
        # Get configuration or use defaults
        offsets = {"description": 2, "quantity": 3, "unit": 4, "price": 5, "amount": 6}

        if self.search_config and "column_mapping" in self.search_config:
            offsets = self.search_config["column_mapping"]["offsets"]

        # Ensure minimal required columns exist
        if "code" not in col_map:
            col_map["code"] = code_col
        if "description" not in col_map:
            col_map["description"] = col_map["code"] + offsets.get(
                "description_offset", 2
            )
        if "quantity" not in col_map:
            col_map["quantity"] = col_map["code"] + offsets.get("quantity_offset", 3)
        if "unit" not in col_map:
            col_map["unit"] = col_map["code"] + offsets.get("unit_offset", 4)
        if "price" not in col_map:
            col_map["price"] = col_map["code"] + offsets.get("price_offset", 5)
        if "amount" not in col_map:
            col_map["amount"] = col_map["code"] + offsets.get("amount_offset", 6)

        return col_map
