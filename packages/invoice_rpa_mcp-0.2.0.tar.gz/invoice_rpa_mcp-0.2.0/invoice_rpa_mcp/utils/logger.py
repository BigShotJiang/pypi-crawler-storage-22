"""Logging utility for invoice automation system"""

import logging
import sys
from pathlib import Path
from typing import Optional


def setup_logger(
    name: str = "invoice_rpa",
    log_file: Optional[Path] = None,
    level: int = logging.INFO,
    console: bool = True,
) -> logging.Logger:
    """
    Configure logging with both file and console handlers

    Args:
        name: Logger name
        log_file: Optional path to log file
        level: Logging level (default: INFO)
        console: stdout 콘솔 핸들러 활성화 여부 (MCP stdio 모드에서는 False로 설정)

    Returns:
        Configured logger instance
    """
    logger = logging.getLogger(name)
    logger.setLevel(level)

    # Remove existing handlers to avoid duplicates
    logger.handlers.clear()

    # Create formatter
    formatter = logging.Formatter(
        fmt='[%(asctime)s] [%(levelname)s] [%(name)s] - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    # Console handler → stderr (stdout은 MCP JSON-RPC용으로 예약)
    if console:
        console_handler = logging.StreamHandler(sys.stderr)
        console_handler.setLevel(level)
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)

    # File handler (if log_file specified)
    if log_file:
        # Create logs directory if it doesn't exist
        log_file = Path(log_file)
        log_file.parent.mkdir(parents=True, exist_ok=True)

        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    return logger
