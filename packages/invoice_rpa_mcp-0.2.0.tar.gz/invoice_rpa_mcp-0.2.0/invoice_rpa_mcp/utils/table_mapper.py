"""Table mapping utilities for Excel operations"""

from typing import Dict, List, Any
from copy import copy
from openpyxl.styles import Alignment
from invoice_rpa_mcp.utils.excel_operations import ExcelOperations
from invoice_rpa_mcp.utils.header_detector import HeaderDetector


class TableMapper:
    """Specialized class for mapping tables between input and output Excel files"""

    def __init__(self, excel_ops: ExcelOperations, header_detector: HeaderDetector):
        """
        Initialize table mapper

        Args:
            excel_ops: Excel operations utility
            header_detector: Header detection utility
        """
        self.excel_ops = excel_ops
        self.header_detector = header_detector

    def find_output_table_structure(self, ws) -> tuple[int, Dict[str, int], int]:
        """
        Find table structure in output worksheet

        Args:
            ws: Output worksheet

        Returns:
            Tuple of (header_row, column_mapping, total_row)
        """
        # Find header row and columns using HeaderDetector
        header_row, columns = self.header_detector.detect_output_headers(ws)

        # Find TOTAL row
        total_row = self.header_detector.find_total_row(ws, header_row)

        # Fallback if TOTAL not found
        if total_row == -1:
            default_gap = 7
            if (
                self.header_detector.search_config
                and "output_mapping" in self.header_detector.search_config
            ):
                default_gap = self.header_detector.search_config["output_mapping"][
                    "default_template_gap"
                ]["rows"]
            total_row = header_row + default_gap

        return header_row, columns, total_row

    def adjust_table_rows(
        self, ws, needed_rows: int, available_rows: int, start_row: int, total_row: int
    ) -> int:
        """
        Adjust table rows by inserting or deleting as needed

        Args:
            ws: Worksheet
            needed_rows: Number of rows needed
            available_rows: Number of rows currently available
            start_row: Starting row of data
            total_row: Row containing TOTAL

        Returns:
            Updated total row position
        """
        if needed_rows > available_rows:
            # Insert rows before total row
            rows_to_insert = needed_rows - available_rows
            ws.insert_rows(total_row, amount=rows_to_insert)

            # Copy formatting from last existing data row to new rows
            template_row = total_row - 1  # Row just before insertion point
            for i in range(rows_to_insert):
                new_row = total_row + i
                self.copy_row_formatting(ws, template_row, new_row)

            total_row += rows_to_insert
        elif needed_rows < available_rows:
            # Delete excess rows
            rows_to_delete = available_rows - needed_rows
            delete_start = start_row + needed_rows
            ws.delete_rows(delete_start, amount=rows_to_delete)
            total_row -= rows_to_delete

        return total_row

    def copy_row_formatting(self, ws, source_row: int, target_row: int, start_col: int = 1, end_col: int = None):
        """
        Copy formatting from source row to target row

        Args:
            ws: Worksheet
            source_row: Source row to copy formatting from
            target_row: Target row to apply formatting to
            start_col: Starting column (default: 1)
            end_col: Ending column (default: max_column)
        """
        if end_col is None:
            end_col = ws.max_column

        for col in range(start_col, end_col + 1):
            source_cell = ws.cell(row=source_row, column=col)
            target_cell = ws.cell(row=target_row, column=col)

            if source_cell.has_style:
                target_cell.font = copy(source_cell.font)
                target_cell.border = copy(source_cell.border)
                target_cell.fill = copy(source_cell.fill)
                target_cell.number_format = source_cell.number_format
                target_cell.alignment = copy(source_cell.alignment)

    def prepare_merged_cells(self, ws, start_row: int, total_row: int):
        """
        Remove merged cells in table area to avoid issues during row operations

        Extended to remove merged cells in a wider range (total_row + 10) to prevent
        formatting issues when additional rows are inserted beyond the template's default size.

        Args:
            ws: Worksheet
            start_row: Starting row of table data
            total_row: Row containing TOTAL
        """
        # Extend removal range to cover additional rows that may be inserted
        extended_end_row = total_row + 10

        merged_cells_to_remove = []
        for merged_range in list(ws.merged_cells.ranges):
            min_col, min_row, max_col, max_row = merged_range.bounds
            # Remove merged cells from start_row to extended_end_row
            if min_row >= start_row and min_row <= extended_end_row:
                merged_cells_to_remove.append(merged_range)

        for merged_range in merged_cells_to_remove:
            ws.unmerge_cells(str(merged_range))

    def map_item_data(
        self, ws, items: List[Dict], columns: Dict[str, int], start_row: int
    ):
        """
        Map item data to worksheet rows

        Args:
            ws: Worksheet
            items: List of item dictionaries
            columns: Column mapping
            start_row: Starting row for data
        """
        for idx, item in enumerate(items):
            row = start_row + idx

            # Map each field to its column
            if "NO" in columns:
                ws.cell(row=row, column=columns["NO"], value=idx + 1)
            if "SO" in columns:
                ws.cell(row=row, column=columns["SO"], value=item.get("SO", ""))
            if "PN" in columns:
                ws.cell(row=row, column=columns["PN"], value=item.get("PN", ""))
            if "CODE" in columns:
                ws.cell(row=row, column=columns["CODE"], value=item.get("CODE", ""))
            if "TYPE_SIZE" in columns:
                ws.cell(
                    row=row,
                    column=columns["TYPE_SIZE"],
                    value=item.get("TYPE_SIZE", ""),
                )
            if "QUANTITY" in columns:
                ws.cell(row=row, column=columns["QUANTITY"], value=item.get("QUANTITY"))
            if "UNIT" in columns:
                unit = item.get("UNIT", "PCS")
                ws.cell(row=row, column=columns["UNIT"], value=unit)
            if "PRICE" in columns:
                price_str = item.get("PRICE", "0")
                try:
                    price = float(str(price_str).replace(",", "")) if price_str else 0
                except ValueError:
                    price = 0
                ws.cell(row=row, column=columns["PRICE"], value=price)

    def apply_formulas(
        self,
        ws,
        columns: Dict[str, int],
        start_row: int,
        last_data_row: int,
        total_row: int,
    ):
        """
        Apply formulas to worksheet (amount calculations and totals)

        Args:
            ws: Worksheet
            columns: Column mapping
            start_row: Starting row of data
            last_data_row: Last row of data
            total_row: Row containing TOTAL
        """
        # Apply AMOUNT formulas for each row
        if "AMOUNT" in columns and "QUANTITY" in columns and "PRICE" in columns:
            for row in range(start_row, last_data_row + 1):
                qty_cell = ws.cell(row=row, column=columns["QUANTITY"]).coordinate
                price_cell = ws.cell(row=row, column=columns["PRICE"]).coordinate
                target_cell = ws.cell(row=row, column=columns["AMOUNT"]).coordinate
                self.excel_ops.round_multiply(
                    ws,
                    qty_cell,
                    price_cell,
                    target_cell,
                )

        # Update TOTAL row formulas
        if "QUANTITY" in columns:
            qty_start = ws.cell(row=start_row, column=columns["QUANTITY"]).coordinate
            qty_end = ws.cell(row=last_data_row, column=columns["QUANTITY"]).coordinate
            qty_target = ws.cell(row=total_row, column=columns["QUANTITY"]).coordinate
            self.excel_ops.sum_range(
                ws,
                qty_start,
                qty_end,
                qty_target,
            )

        if "AMOUNT" in columns:
            amt_start = ws.cell(row=start_row, column=columns["AMOUNT"]).coordinate
            amt_end = ws.cell(row=last_data_row, column=columns["AMOUNT"]).coordinate
            amt_target = ws.cell(row=total_row, column=columns["AMOUNT"]).coordinate
            self.excel_ops.sum_range(
                ws,
                amt_start,
                amt_end,
                amt_target,
            )

    def format_total_row(self, ws, columns: Dict[str, int], total_row: int):
        """
        Format TOTAL row with merged cells and alignment

        Args:
            ws: Worksheet
            columns: Column mapping
            total_row: Row containing TOTAL
        """
        # Merge TOTAL row cells (SO to TYPE_SIZE) and Center Align
        if "SO" in columns and "TYPE_SIZE" in columns:
            start_col = columns["SO"]
            end_col = columns["TYPE_SIZE"]

            # Check if already merged and unmerge if necessary
            from openpyxl.styles import Border, Side
            merged_range_to_remove = None
            for merged_range in ws.merged_cells.ranges:
                min_col, min_row, max_col, max_row = merged_range.bounds
                if min_row == total_row and min_col <= start_col and max_col >= end_col:
                    merged_range_to_remove = merged_range
                    break

            if merged_range_to_remove:
                ws.unmerge_cells(str(merged_range_to_remove))

            # Save borders from all cells in merge range before merging
            saved_borders = {}
            for col in range(start_col, end_col + 1):
                cell = ws.cell(row=total_row, column=col)
                saved_borders[col] = copy(cell.border)

            # Merge
            ws.merge_cells(
                start_row=total_row,
                start_column=start_col,
                end_row=total_row,
                end_column=end_col,
            )

            # Restore borders to merged cell (first cell represents the merged range)
            first_cell = ws.cell(row=total_row, column=start_col)
            first_cell.alignment = Alignment(horizontal="center")

            # For merged cells, only the first cell's border is visible
            # We need to set the border that represents the outer edges
            if start_col in saved_borders:
                first_border = saved_borders[start_col]
                last_border = saved_borders[end_col] if end_col in saved_borders else first_border

                # Create border for merged range
                first_cell.border = Border(
                    left=first_border.left if first_border.left else None,
                    right=last_border.right if last_border.right else None,
                    top=first_border.top if first_border.top else None,
                    bottom=first_border.bottom if first_border.bottom else None
                )

            # Also restore borders for non-merged cells in the same row (QUANTITY, AMOUNT, etc.)
            # These cells are not part of the merged range but still need their borders preserved
            for col in range(end_col + 1, ws.max_column + 1):
                cell = ws.cell(row=total_row, column=col)
                if col in saved_borders:
                    cell.border = saved_borders[col]

    def update_price_header(
        self, ws, header_row: int, columns: Dict[str, int], currency: str
    ):
        """
        Update PRICE header with currency

        Args:
            ws: Worksheet
            header_row: Header row number
            columns: Column mapping
            currency: Currency code (e.g., USD, KRW)
        """
        if "PRICE" in columns:
            ws.cell(
                row=header_row, column=columns["PRICE"], value=f"PRICE ({currency})"
            )

    def adjust_column_widths_simple(self, ws, columns: Dict[str, int]) -> None:
        """
        Set fixed minimum widths for all columns to prevent ### display

        Uses predefined widths that work for most data ranges.
        This ensures all numeric values are fully visible without showing ###.

        Args:
            ws: Worksheet to adjust
            columns: Column mapping dict (field_name -> column_number)
        """
        from openpyxl.utils import get_column_letter

        # Fixed widths optimized for typical data ranges
        fixed_widths = {
            "SO": 12,
            "PN": 14,
            "CODE": 10,
            "TYPE_SIZE": 28,
            "QUANTITY": 15,  # Increased from 12.83 to fit large numbers
            "UNIT": 8,
            "PRICE": 16,     # Increased from 13.16 to fit KRW values
            "AMOUNT": 16,    # Increased from 11.66 to fit large totals
        }

        for field, col_idx in columns.items():
            if field in fixed_widths:
                col_letter = get_column_letter(col_idx)
                ws.column_dimensions[col_letter].width = fixed_widths[field]

    def auto_fit_columns(self, ws, columns: Dict[str, int] = None, min_width: int = 5, max_width: int = 30):
        """
        Auto-fit column widths based on cell content

        Similar to Excel's double-click column resize feature.
        Calculates the maximum content width for each column and adjusts accordingly.

        Args:
            ws: Worksheet to adjust
            columns: Optional dict of column names to column numbers (if provided, only fit these)
            min_width: Minimum column width (default: 5)
            max_width: Maximum column width (default: 30)
        """
        from openpyxl.utils import get_column_letter

        # Determine which columns to fit
        if columns:
            # Fit only specified columns (by column number)
            cols_to_fit = set(columns.values())
        else:
            # Fit all columns
            cols_to_fit = None

        for col_num in range(1, ws.max_column + 1):
            # Skip if we're only fitting specific columns
            if cols_to_fit and col_num not in cols_to_fit:
                continue

            max_length = 0
            col_letter = get_column_letter(col_num)

            # Iterate through all cells in this column
            for row_num in range(1, ws.max_row + 1):
                cell = ws.cell(row=row_num, column=col_num)

                if cell.value is not None:
                    # Convert to string and measure length (원본 길이 사용)
                    cell_str = str(cell.value)

                    # 다중라인 셀 처리 - 줄당 최대 길이 사용
                    if '\n' in cell_str:
                        lines = cell_str.split('\n')
                        length = max(len(line) for line in lines)
                    else:
                        length = len(cell_str)

                    if length > max_length:
                        max_length = length

            # Calculate adjusted width (Excel 표준 공식)
            # Formula: max_length * 1.1 + 1 (더 보수적)
            if max_length > 0:
                adjusted_width = max_length * 1.1 + 1

                # Apply bounds
                adjusted_width = max(min_width, min(adjusted_width, max_width))

                # Set the width
                ws.column_dimensions[col_letter].width = adjusted_width
