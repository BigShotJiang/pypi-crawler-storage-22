# Invoice RPA → MCP Server 리팩토링 계획

## 1. 현재 구조 분석 (AS-IS)

### 실행 방식
```bash
uv run python src/main.py
```

### 핵심 흐름
```
main.py
  ├─ 설정 로드 (process_config.json → input/output 경로, CSV 경로)
  ├─ 컴포넌트 초기화
  │   ├─ ConfigLoader
  │   ├─ VariationDataLoader (customer_master.csv, itemList.csv)
  │   ├─ DuplicateChecker
  │   └─ SequenceManager
  ├─ input 폴더에서 .xlsx 파일 스캔
  ├─ 각 파일을 InvoiceProcessor.process_file() 실행
  └─ 결과 리포트 출력 (success / skipped / failed)
```

### 설정 의존성
| 설정 항목 | 현재 소스 | 용도 |
|-----------|----------|------|
| `input_folder` | process_config.json | 처리 대상 .xlsx 파일 디렉토리 |
| `output_folder` | process_config.json | 결과 파일 출력 디렉토리 |
| `customer_master_path` | process_config.json | 거래처 마스터 CSV |
| `item_list_path` | process_config.json | 품목 리스트 CSV |

### 현재 의존성
```
openpyxl>=3.1.2, python-dotenv>=1.0.0, pillow>=10.0.0
```

---

## 2. 목표 구조 (TO-BE)

### 설계 방향
- **MCPServer (High-Level API)** 사용 — `@mcp.tool()` 데코레이터 기반
- **Lifespan**으로 초기화 리소스(CSV 로드 등)를 서버 시작 시 1회 로드
- **환경변수**로 4개 경로를 선택적으로 전달 (미설정 시 프로젝트 기본값 사용)
- **기존 비즈니스 로직 모듈은 변경 없이 재사용**
- `main.py`는 standalone 실행용으로 유지 (하위 호환)

### 환경변수 정의

| 환경변수 | 필수 | 기본값 | 설명 |
|---------|------|--------|------|
| `INVOICE_INPUT_FOLDER` | X | `{project_root}/input` | 입력 폴더 경로 |
| `INVOICE_OUTPUT_FOLDER` | X | `{project_root}/output` | 출력 폴더 경로 |
| `INVOICE_CUSTOMER_MASTER_PATH` | X | `{project_root}/variation_data/customer_master.csv` | 거래처 마스터 CSV |
| `INVOICE_ITEM_LIST_PATH` | X | `{project_root}/variation_data/itemList.csv` | 품목 리스트 CSV |

### mcp.json 등록 예시

```json
{
  "mcpServers": {
    "invoice-rpa": {
      "transport": "stdio",
      "command": "uv",
      "args": ["run", "--directory", "/path/to/invoice_rpa", "invoice-rpa-mcp"],
      "env": {
        "INVOICE_INPUT_FOLDER": "/Users/drb/workspace/02_rule_based/RPA/invoice_rpa/input",
        "INVOICE_OUTPUT_FOLDER": "/Users/drb/workspace/02_rule_based/RPA/invoice_rpa/output",
        "INVOICE_CUSTOMER_MASTER_PATH": "/Users/drb/workspace/tools/invoice_rpa/variation_data/customer_master.csv",
        "INVOICE_ITEM_LIST_PATH": "/Users/drb/workspace/tools/invoice_rpa/variation_data/itemList.csv"
      },
      "enabled": true
    }
  }
}
```

env를 생략하면 프로젝트 기본 경로를 사용:

```json
{
  "mcpServers": {
    "invoice-rpa": {
      "transport": "stdio",
      "command": "uv",
      "args": ["run", "--directory", "/path/to/invoice_rpa", "invoice-rpa-mcp"],
      "enabled": true
    }
  }
}
```

---

## 3. 프로젝트 구조 변경

### 변경 전
```
invoice_rpa/
├── src/
│   ├── __init__.py
│   ├── main.py                  ← 유일한 진입점
│   ├── config_loader.py
│   ├── data_loader.py
│   ├── duplicate_checker.py
│   ├── invoice_processor.py
│   ├── sequence_manager.py
│   └── utils/
│       └── logger.py
├── variation_data/
│   ├── process_config.json
│   ├── customer_master.csv
│   └── itemList.csv
├── input/
├── output/
├── logs/
└── pyproject.toml
```

### 변경 후
```
invoice_rpa/
├── src/
│   ├── __init__.py
│   ├── main.py                  ← 기존 유지 (standalone 실행)
│   ├── mcp_server.py            ← ★ 신규: MCP Server 진입점
│   ├── config_loader.py         ← 변경 없음
│   ├── data_loader.py           ← 변경 없음
│   ├── duplicate_checker.py     ← 변경 없음
│   ├── invoice_processor.py     ← 변경 없음
│   ├── sequence_manager.py      ← 변경 없음
│   └── utils/
│       └── logger.py            ← 변경 없음
├── variation_data/
├── input/
├── output/
├── logs/
└── pyproject.toml               ← ★ 수정: mcp 의존성 + entry point 추가
```

**변경 파일 요약: 신규 1개, 수정 1개, 기존 모듈 전부 변경 없음**

---

## 4. 신규 파일: `src/mcp_server.py`

### 4.1 전체 구조

```python
"""Invoice RPA MCP Server"""

import os
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass
from pathlib import Path

from mcp.server.mcpserver import Context, MCPServer

from src.config_loader import ConfigLoader
from src.data_loader import VariationDataLoader
from src.duplicate_checker import DuplicateChecker
from src.invoice_processor import InvoiceProcessor
from src.sequence_manager import SequenceManager
from src.utils.logger import setup_logger


# ──────────────────────────────────────────────
# 1) Lifespan Context (서버 시작 시 1회 초기화)
# ──────────────────────────────────────────────

@dataclass
class AppContext:
    """서버 수명 동안 유지되는 공유 리소스"""
    processor: InvoiceProcessor
    input_dir: Path
    output_dir: Path
    logger: ...


def resolve_paths() -> dict:
    """환경변수에서 경로를 읽고, 없으면 프로젝트 기본값 사용"""
    project_root = Path(__file__).parent.parent

    return {
        "input_dir": Path(os.environ.get(
            "INVOICE_INPUT_FOLDER",
            str(project_root / "input")
        )),
        "output_dir": Path(os.environ.get(
            "INVOICE_OUTPUT_FOLDER",
            str(project_root / "output")
        )),
        "customer_master_path": os.environ.get(
            "INVOICE_CUSTOMER_MASTER_PATH",
            str(project_root / "variation_data" / "customer_master.csv")
        ),
        "item_list_path": os.environ.get(
            "INVOICE_ITEM_LIST_PATH",
            str(project_root / "variation_data" / "itemList.csv")
        ),
    }


@asynccontextmanager
async def app_lifespan(server: MCPServer) -> AsyncIterator[AppContext]:
    """서버 시작 시 컴포넌트 초기화, 종료 시 정리"""
    paths = resolve_paths()
    project_root = Path(__file__).parent.parent

    logger = setup_logger("invoice_rpa_mcp",
                          log_file=project_root / "logs" / "mcp_server.log")

    config_loader = ConfigLoader()
    variation_data_loader = VariationDataLoader(
        customer_master_path=paths["customer_master_path"],
        item_list_path=paths["item_list_path"],
    )
    variation_data_loader.load_all()

    duplicate_checker = DuplicateChecker()
    sequence_manager = SequenceManager(project_root / ".invoice_sequences.json")

    processor = InvoiceProcessor(
        config_loader, variation_data_loader,
        duplicate_checker, sequence_manager, logger
    )

    logger.info("MCP Server initialized")
    logger.info(f"  Input:  {paths['input_dir']}")
    logger.info(f"  Output: {paths['output_dir']}")

    try:
        yield AppContext(
            processor=processor,
            input_dir=paths["input_dir"],
            output_dir=paths["output_dir"],
            logger=logger,
        )
    finally:
        logger.info("MCP Server shutting down")


# ──────────────────────────────────────────────
# 2) MCP Server 인스턴스
# ──────────────────────────────────────────────

mcp = MCPServer("invoice-rpa", lifespan=app_lifespan)


# ──────────────────────────────────────────────
# 3) Tool 정의
# ──────────────────────────────────────────────

@mcp.tool()
async def process_all_invoices(ctx: Context) -> str:
    """
    input 폴더의 모든 .xlsx 인보이스 파일을 일괄 처리합니다.
    처리 결과(성공/스킵/실패)를 요약하여 반환합니다.
    """
    app: AppContext = ctx.request_context.lifespan_context
    # ... input_dir 스캔 → processor.process_file() 루프 → 결과 요약


@mcp.tool()
async def process_single_invoice(filename: str, ctx: Context) -> str:
    """
    input 폴더 내 특정 .xlsx 파일 1개를 처리합니다.

    Args:
        filename: 처리할 파일명 (예: "invoice_001.xlsx")
    """
    app: AppContext = ctx.request_context.lifespan_context
    # ... 단일 파일 처리 → 결과 반환


@mcp.tool()
async def list_input_files(ctx: Context) -> str:
    """
    input 폴더에 있는 처리 대상 .xlsx 파일 목록을 반환합니다.
    임시 파일(~$로 시작)은 제외됩니다.
    """
    app: AppContext = ctx.request_context.lifespan_context
    # ... input_dir.glob("*.xlsx") → 파일 목록 반환


@mcp.tool()
async def get_server_config(ctx: Context) -> str:
    """
    현재 서버 설정 정보(input/output 경로, CSV 경로 등)를 반환합니다.
    """
    app: AppContext = ctx.request_context.lifespan_context
    # ... resolve_paths() 결과 + 로드된 데이터 건수 반환


# ──────────────────────────────────────────────
# 4) Entry Point
# ──────────────────────────────────────────────

def main():
    mcp.run()  # 기본값: stdio transport

if __name__ == "__main__":
    main()
```

### 4.2 Tool 상세 설계

| Tool | 입력 | 출력 | 대응하는 기존 로직 |
|------|------|------|-------------------|
| `process_all_invoices` | 없음 | 처리 요약 (JSON 문자열) | `main()` 전체 루프 |
| `process_single_invoice` | `filename: str` | 단일 파일 처리 결과 | `processor.process_file()` |
| `list_input_files` | 없음 | 파일명 리스트 | `input_dir.glob('*.xlsx')` |
| `get_server_config` | 없음 | 설정 정보 (JSON) | `resolve_paths()` |

### 4.3 Tool 반환 포맷

모든 tool은 **JSON 문자열**을 반환하여 LLM이 구조적으로 파싱할 수 있게 합니다:

```json
// process_all_invoices 반환 예시
{
  "total": 5,
  "success": 3,
  "skipped": 1,
  "failed": 1,
  "details": [
    {"file": "inv_001.xlsx", "status": "success", "output": "inv_001_processed.xlsx"},
    {"file": "inv_002.xlsx", "status": "skipped", "reason": "already processed"},
    {"file": "inv_003.xlsx", "status": "error", "reason": "invalid format"}
  ]
}
```

---

## 5. 수정 파일: `pyproject.toml`

### 변경 내용

```toml
[project]
name = "invoice-rpa"
version = "0.2.0"                          # ← 버전 업
requires-python = ">=3.13"
dependencies = [
    "openpyxl>=3.1.2",
    "python-dotenv>=1.0.0",
    "pillow>=10.0.0",
    "mcp>=1.0.0",                          # ← 추가: MCP Python SDK
]

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src"]

[project.scripts]                           # ← 추가: CLI entry point
invoice-rpa-mcp = "src.mcp_server:main"     # uv run invoice-rpa-mcp 으로 실행 가능
```

`[project.scripts]`를 추가하면 mcp.json에서 이렇게 등록할 수 있습니다:

```json
{
  "command": "uv",
  "args": ["run", "--directory", "/path/to/invoice_rpa", "invoice-rpa-mcp"]
}
```

---

## 6. 기존 모듈 영향 분석

| 모듈 | 변경 여부 | 사유 |
|------|----------|------|
| `src/config_loader.py` | **변경 없음** | mcp_server.py에서 그대로 import |
| `src/data_loader.py` | **변경 없음** | 생성자에서 이미 path를 받는 구조 |
| `src/duplicate_checker.py` | **변경 없음** | 독립적 모듈 |
| `src/invoice_processor.py` | **변경 없음** | `process_file(input, output_dir)` 인터페이스 유지 |
| `src/sequence_manager.py` | **변경 없음** | 독립적 모듈 |
| `src/utils/logger.py` | **변경 없음** | `setup_logger()` 인터페이스 유지 |
| `src/main.py` | **변경 없음** | standalone 실행 경로 유지 |

---

## 7. 구현 단계

### Step 1: 의존성 추가
```bash
cd invoice_rpa
uv add mcp
```
`pyproject.toml`에 `mcp>=1.0.0` 추가 + `[project.scripts]` entry point 추가

### Step 2: `src/mcp_server.py` 작성
1. `resolve_paths()` — 환경변수 → Path 변환 (fallback 포함)
2. `app_lifespan()` — 컴포넌트 초기화 (기존 main.py 초기화 로직 추출)
3. `MCPServer` 인스턴스 생성
4. 4개 tool 함수 구현 (기존 main.py 로직 재사용)
5. `main()` entry point

### Step 3: 테스트
```bash
# standalone 실행 확인 (기존 방식)
uv run python src/main.py

# MCP 서버 실행 확인
uv run invoice-rpa-mcp

# MCP Inspector로 tool 테스트
npx @modelcontextprotocol/inspector uv run invoice-rpa-mcp
```

### Step 4: Nexus Agent에 등록
`backend/mcp.json`에 서버 설정 추가 후 연결 테스트

---

## 8. 주의사항

### 8.1 동기/비동기 호환
현재 `InvoiceProcessor.process_file()`은 동기 함수입니다. MCP tool은 async로 정의하되, 내부에서 동기 코드를 호출할 때는 이벤트 루프 블로킹에 주의해야 합니다:

```python
import asyncio

@mcp.tool()
async def process_all_invoices(ctx: Context) -> str:
    app: AppContext = ctx.request_context.lifespan_context
    # 동기 함수를 thread executor에서 실행
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(
        None, app.processor.process_file, input_file, app.output_dir
    )
    return json.dumps(result)
```

### 8.2 stdout 오염 방지
MCP stdio transport는 stdout을 JSON-RPC 통신에 사용합니다. 기존 코드에 `print()` 문이 있으면 프로토콜이 깨질 수 있습니다:

- `main.py`의 `print()` → MCP 서버에서는 사용하지 않으므로 문제 없음
- `InvoiceProcessor` 내부에 `print()`가 있다면 → logger로 교체 필요
- 서버 진입점에서는 **절대 stdout에 직접 출력하지 않도록** 주의

### 8.3 경로 해석
환경변수의 경로는 **항상 절대 경로**를 사용하는 것을 권장합니다. mcp.json의 `env`에서 전달되는 경로가 상대 경로일 경우, MCP 서버 프로세스의 working directory에 따라 달라질 수 있습니다.

### 8.4 프로세스 수명
MCP stdio 서버는 클라이언트(Nexus Agent)가 연결을 유지하는 동안 살아있습니다. 따라서:
- Lifespan에서 로드한 CSV 데이터는 서버가 살아있는 동안 메모리에 유지
- CSV 파일이 변경되면 서버 재시작 필요 (또는 reload tool 추가 가능)