from iolanta.facets.mkdocs_material_insiders_markdown.facet import (
    MkDocsMaterialInsidersMarkdownFacet,
)

__all__ = ['MkDocsMaterialInsidersMarkdownFacet']

