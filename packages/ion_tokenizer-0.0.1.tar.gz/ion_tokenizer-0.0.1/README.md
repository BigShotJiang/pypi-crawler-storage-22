# Ion Tokenizer

Phrase-first tokenizer for LLMs. 54-0 vs BPE in head-to-head benchmarks.

**Coming soon.** Visit [iontokenizer.com](https://iontokenizer.com) for updates.

## Installation
```bash
pip install ion-tokenizer
```

## Links

- Website: https://iontokenizer.com
- GitHub: https://github.com/creayo-dev/ion
- Company: https://creayodev.com
