#!/usr/bin/env python3
"""
Benchmark Ion vs BPE on code and multilingual text.

Tests:
1. Python source code
2. JavaScript source code
3. Mixed code + comments
4. German text
5. French text
6. Spanish text
7. Mixed multilingual
"""

import os
import sys
import json
import time
import tempfile
import random
import statistics
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any
from collections import Counter

sys.path.insert(0, str(Path(__file__).parent.parent))

from tqdm import tqdm
from tokenizers import Tokenizer
from tokenizers.models import BPE
from tokenizers.trainers import BpeTrainer
from tokenizers.pre_tokenizers import Whitespace

from ion.builder import TokenizerBuilder
from ion.tokenizer import IonTokenizer


def train_bpe_tokenizer(sentences: List[str], vocab_size: int) -> Tokenizer:
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
        for sent in sentences:
            f.write(sent + '\n')
        temp_path = f.name
    try:
        tokenizer = Tokenizer(BPE(unk_token="[UNK]"))
        tokenizer.pre_tokenizer = Whitespace()
        trainer = BpeTrainer(
            vocab_size=vocab_size,
            special_tokens=["[UNK]", "[PAD]", "[CLS]", "[SEP]", "[MASK]"],
            min_frequency=2,
        )
        tokenizer.train([temp_path], trainer)
        return tokenizer
    finally:
        os.unlink(temp_path)


def train_ion_tokenizer(sentences: List[str], vocab_size: int, language: str = "en", preserve_case: bool = False) -> IonTokenizer:
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
        for sent in sentences:
            f.write(sent + '\n')
        temp_path = f.name
    try:
        builder = TokenizerBuilder(
            max_vocab_size=vocab_size,
            min_word_freq=1,
            min_phrase_freq=2,
            phrase_threshold=0.00001,
            max_phrase_layers=6,
            enable_bpe_fallback=True,
            bpe_vocab_size=vocab_size,
            take_needed=True,
            language=language,
            preserve_case=preserve_case,
        )
        builder.load_corpus(temp_path)
        builder.discover_phrases()
        return builder.build_tokenizer()
    finally:
        os.unlink(temp_path)


def analyze_token_distribution(tok: IonTokenizer, sentences: List[str], sample_size: int = 1000):
    phrases = set(tok.token_classes.get("phrase", []))
    words = set(tok.token_classes.get("word", []))
    bpe_subwords = set(tok.token_classes.get("bpe_subword", []))
    counts = {"phrase": 0, "word": 0, "bpe_subword": 0, "character": 0}
    for sent in sentences[:sample_size]:
        ids = tok.encode(sent)
        for tid in ids:
            t = tok.id_to_token.get(tid, "")
            if t in phrases:
                counts["phrase"] += 1
            elif t in words:
                counts["word"] += 1
            elif t in bpe_subwords:
                counts["bpe_subword"] += 1
            else:
                counts["character"] += 1
    total = sum(counts.values()) or 1
    return {k: round(v / total * 100, 1) for k, v in counts.items()}


def benchmark_dataset(name, train, test, vocab_sizes, language="en", preserve_case=False):
    print(f"\n{'='*70}")
    print(f"BENCHMARK: {name}")
    print(f"{'='*70}")
    print(f"  Train: {len(train):,} sentences, Test: {len(test):,} sentences")
    print(f"  Language: {language}, Preserve case: {preserve_case}")

    total_test_words = sum(len(s.split()) for s in test)
    total_test_chars = sum(len(s) for s in test)

    results = []
    for vocab_size in vocab_sizes:
        print(f"\n  Training vocab_size={vocab_size:,}...")
        sys.stdout.flush()

        t0 = time.time()
        ion_tok = train_ion_tokenizer(train, vocab_size, language, preserve_case)
        ion_train_time = time.time() - t0

        t0 = time.time()
        bpe_tok = train_bpe_tokenizer(train, vocab_size)
        bpe_train_time = time.time() - t0

        t0 = time.time()
        ion_tokens = [len(ion_tok.encode(s)) for s in test]
        ion_encode_time = time.time() - t0

        t0 = time.time()
        bpe_tokens = [len(bpe_tok.encode(s).ids) for s in test]
        bpe_encode_time = time.time() - t0

        ion_total = sum(ion_tokens)
        bpe_total = sum(bpe_tokens)
        dist = analyze_token_distribution(ion_tok, test)

        result = {
            "vocab_size": vocab_size,
            "ion_tokens": ion_total,
            "bpe_tokens": bpe_total,
            "ion_advantage_pct": round(((bpe_total - ion_total) / max(bpe_total, 1)) * 100, 2),
            "ion_chars_per_token": round(total_test_chars / max(ion_total, 1), 2),
            "bpe_chars_per_token": round(total_test_chars / max(bpe_total, 1), 2),
            "ion_phrases_count": len(ion_tok.token_classes.get("phrase", [])),
            "token_distribution": dist,
            "ion_train_time_s": round(ion_train_time, 2),
            "bpe_train_time_s": round(bpe_train_time, 2),
        }
        results.append(result)

        print(f"    Ion: {ion_total:,} tokens ({result['ion_chars_per_token']:.1f} c/t)")
        print(f"    BPE: {bpe_total:,} tokens ({result['bpe_chars_per_token']:.1f} c/t)")
        print(f"    Ion advantage: {result['ion_advantage_pct']:+.1f}%")
        print(f"    Phrases: {result['ion_phrases_count']:,} | Mix: "
              f"{dist['phrase']:.1f}% phrase, {dist['word']:.1f}% word, "
              f"{dist['bpe_subword']:.1f}% bpe, {dist['character']:.1f}% char")

    return {"dataset": name, "language": language, "preserve_case": preserve_case,
            "train_size": len(train), "test_size": len(test), "results": results}


# ============================================================================
# CODE CORPUS GENERATORS
# ============================================================================

def generate_python_corpus(n: int = 10000) -> List[str]:
    random.seed(50)
    patterns = [
        "def {func}({args}):",
        "    return {var}.{method}({args})",
        "    if {var} is not None:",
        "        raise ValueError(\"Invalid {var}\")",
        "    for {var} in range(len({collection})):",
        "    with open({var}, 'r') as f:",
        "        {var} = json.loads(f.read())",
        "class {cls}({base}):",
        "    def __init__(self, {args}):",
        "        self.{var} = {var}",
        "        super().__init__({args})",
        "    @staticmethod",
        "    def {func}({args}) -> {type}:",
        "        \"\"\"Docstring for {func}.\"\"\"",
        "    try:",
        "        {var} = {func}({args})",
        "    except Exception as e:",
        "        logging.error(f\"Error in {func}: {{e}}\")",
        "import os",
        "from typing import List, Dict, Optional",
        "from pathlib import Path",
        "# {comment}",
        "assert {var} is not None, \"Expected {var} to be set\"",
        "    if not isinstance({var}, {type}):",
        "        {var} = list(filter(lambda x: x is not None, {collection}))",
        "    result = {{k: v for k, v in {var}.items() if v > 0}}",
    ]
    funcs = ["process_data", "load_config", "save_results", "validate_input",
             "compute_stats", "train_model", "parse_args", "run_pipeline",
             "get_value", "set_value", "update_state", "handle_error"]
    vars_ = ["data", "config", "result", "value", "item", "output", "input_path",
             "model", "params", "batch", "tokens", "text"]
    methods = ["append", "extend", "update", "get", "items", "values", "keys",
               "strip", "split", "lower", "encode", "decode"]
    classes = ["DataProcessor", "ModelTrainer", "ConfigLoader", "Pipeline",
               "TokenizerBuilder", "TextCleaner", "BatchEncoder"]
    bases = ["object", "BaseModel", "nn.Module", "ABC", "Protocol"]
    types = ["str", "int", "float", "bool", "List[str]", "Dict[str, Any]", "Optional[int]"]
    args = ["x", "y", "name", "path", "config", "data, labels", "model, tokenizer",
            "batch_size=32", "max_length=512", "verbose=False"]
    collections = ["items", "results", "data_list", "batch", "tokens"]
    comments = [
        "TODO: refactor this function",
        "Process input data and return results",
        "This handles the edge case for empty input",
        "Validate configuration before processing",
    ]

    sentences = []
    for _ in range(n):
        p = random.choice(patterns)
        sentences.append(p.format(
            func=random.choice(funcs), var=random.choice(vars_),
            method=random.choice(methods), cls=random.choice(classes),
            base=random.choice(bases), type=random.choice(types),
            args=random.choice(args), collection=random.choice(collections),
            comment=random.choice(comments),
        ))
    return sentences


def generate_javascript_corpus(n: int = 10000) -> List[str]:
    random.seed(51)
    patterns = [
        "function {func}({args}) {{",
        "  const {var} = await fetch({url});",
        "  return {var}.{method}({args});",
        "  if ({var} === null || {var} === undefined) {{",
        "    throw new Error(`Invalid {var}`);",
        "  for (let i = 0; i < {var}.length; i++) {{",
        "  const {{ {var}, ...rest }} = {obj};",
        "class {cls} extends {base} {{",
        "  constructor({args}) {{",
        "    super({args});",
        "    this.{var} = {var};",
        "  async {func}({args}) {{",
        "    try {{",
        "      const {var} = await this.{func}({args});",
        "    }} catch (error) {{",
        "      console.error(`Error in {func}:`, error);",
        "import {{ {var} }} from '{module}';",
        "export default {cls};",
        "export const {var} = ({args}) => {{",
        "  const [{var}, set{Var}] = useState({init});",
        "  useEffect(() => {{",
        "    {func}({args}).then(({var}) => set{Var}({var}));",
        "  }}, [{var}]);",
        "// {comment}",
        "  const {var} = {obj}.map(item => item.{method}());",
        "  const {var} = {obj}.filter(item => item !== null);",
        "  const {var} = Object.keys({obj}).reduce((acc, key) => {{",
    ]
    funcs = ["fetchData", "handleSubmit", "processInput", "validateForm",
             "renderComponent", "updateState", "loadConfig", "parseResponse"]
    vars_ = ["data", "result", "response", "config", "value", "items", "error"]
    methods = ["json", "text", "push", "filter", "map", "reduce", "forEach", "find"]
    classes = ["DataService", "ApiClient", "FormHandler", "StateManager"]
    bases = ["Component", "EventEmitter", "BaseService"]
    args = ["url", "options", "config", "data, callback", "event", "props"]
    objs = ["state", "props", "config", "data", "response"]
    modules = ["react", "./utils", "../services/api", "@/components", "lodash"]
    Vars = ["Data", "Result", "Config", "Value", "Items"]
    inits = ["null", "[]", "{}", "''", "0", "false"]
    comments = [
        "TODO: add error handling",
        "Handle form submission",
        "Fetch data from API endpoint",
        "Update component state",
    ]

    sentences = []
    for _ in range(n):
        p = random.choice(patterns)
        sentences.append(p.format(
            func=random.choice(funcs), var=random.choice(vars_),
            method=random.choice(methods), cls=random.choice(classes),
            base=random.choice(bases), args=random.choice(args),
            obj=random.choice(objs), module=random.choice(modules),
            Var=random.choice(Vars), init=random.choice(inits),
            url="'/api/data'", comment=random.choice(comments),
        ))
    return sentences


def generate_mixed_code_corpus(n: int = 10000) -> List[str]:
    """Mix of code and English comments/docstrings."""
    random.seed(52)
    py = generate_python_corpus(n // 2)
    js = generate_javascript_corpus(n // 2)
    mixed = py + js
    random.shuffle(mixed)
    return mixed[:n]


# ============================================================================
# MULTILINGUAL CORPUS GENERATORS
# ============================================================================

def generate_german_corpus(n: int = 10000) -> List[str]:
    random.seed(60)
    phrases = [
        "auf der anderen Seite", "in Bezug auf", "im Vergleich zu",
        "zum Beispiel", "in der Regel", "auf jeden Fall",
        "unter anderem", "in der Lage", "zur gleichen Zeit",
        "im Laufe der", "in der Tat", "auf diese Weise",
        "Vereinigte Staaten", "Europaeische Union", "Bundesrepublik Deutschland",
    ]
    templates = [
        "Die {noun} der {noun2} war {adj} und von grosser Bedeutung.",
        "In Bezug auf die {noun} hat die Regierung {verb} Massnahmen ergriffen.",
        "Auf der anderen Seite hat die {noun} im Vergleich zu frueheren Jahren {verb}.",
        "Zum Beispiel hat die {noun} in der Regel eine {adj} Wirkung.",
        "Die {adj} {noun} zeigt, dass unter anderem die {noun2} eine wichtige Rolle spielt.",
        "Im Laufe der Zeit hat sich die {noun} in der Tat {adj} entwickelt.",
        "Die Bundesrepublik Deutschland hat auf diese Weise die {noun} {verb}.",
        "Auf jeden Fall ist die {noun} der Europaeische Union fuer die {noun2} wichtig.",
        "In der Lage, die {noun} zu verbessern, haben die Forscher {adj} Ergebnisse erzielt.",
        "Zur gleichen Zeit hat die Vereinigte Staaten die {noun2} {verb}.",
    ]
    nouns = ["Wirtschaft", "Entwicklung", "Forschung", "Gesellschaft", "Politik",
             "Bildung", "Technologie", "Umwelt", "Gesundheit", "Sicherheit"]
    adjs = ["bedeutend", "wichtig", "gross", "stark", "positiv", "negativ",
            "erheblich", "zunehmend", "steigend", "wachsend"]
    verbs = ["verbessert", "entwickelt", "gestaerkt", "unterstuetzt",
             "analysiert", "bewertet", "umgesetzt", "gefoerdert"]

    sentences = []
    for _ in range(n):
        t = random.choice(templates)
        sentences.append(t.format(
            noun=random.choice(nouns), noun2=random.choice(nouns),
            adj=random.choice(adjs), verb=random.choice(verbs),
        ))
    return sentences


def generate_french_corpus(n: int = 10000) -> List[str]:
    random.seed(61)
    phrases = [
        "d'autre part", "en ce qui concerne", "par rapport a",
        "par exemple", "en general", "en tout cas",
        "entre autres", "en mesure de", "en meme temps",
        "au cours de", "en effet", "de cette maniere",
        "Etats-Unis", "Union europeenne", "Nations Unies",
    ]
    templates = [
        "Le {noun} de la {noun2} etait {adj} et d'une grande importance.",
        "En ce qui concerne le {noun}, le gouvernement a pris des mesures {adj}.",
        "D'autre part, le {noun} a {verb} par rapport aux annees precedentes.",
        "Par exemple, le {noun} a en general un effet {adj} sur la societe.",
        "Le {adj} {noun} montre que, entre autres, la {noun2} joue un role important.",
        "Au cours de la periode, le {noun} a en effet {verb} de maniere significative.",
        "Les Etats-Unis ont de cette maniere {verb} la {noun} internationale.",
        "En tout cas, le {noun} de l'Union europeenne est important pour la {noun2}.",
        "En mesure de ameliorer le {noun}, les chercheurs ont obtenu des resultats {adj}.",
        "En meme temps, les Nations Unies ont {verb} la {noun2} mondiale.",
    ]
    nouns = ["economie", "developpement", "recherche", "societe", "politique",
             "education", "technologie", "environnement", "sante", "securite"]
    adjs = ["important", "significatif", "majeur", "fort", "positif", "negatif",
            "considerable", "croissant", "notable", "remarquable"]
    verbs = ["ameliore", "developpe", "renforce", "soutenu",
             "analyse", "evalue", "mis en oeuvre", "encourage"]

    sentences = []
    for _ in range(n):
        t = random.choice(templates)
        sentences.append(t.format(
            noun=random.choice(nouns), noun2=random.choice(nouns),
            adj=random.choice(adjs), verb=random.choice(verbs),
        ))
    return sentences


def generate_spanish_corpus(n: int = 10000) -> List[str]:
    random.seed(62)
    phrases = [
        "por otra parte", "con respecto a", "en comparacion con",
        "por ejemplo", "en general", "en todo caso",
        "entre otros", "en condiciones de", "al mismo tiempo",
        "a lo largo de", "de hecho", "de esta manera",
        "Estados Unidos", "Union Europea", "Naciones Unidas",
    ]
    templates = [
        "El {noun} de la {noun2} fue {adj} y de gran importancia.",
        "Con respecto al {noun}, el gobierno ha tomado medidas {adj}.",
        "Por otra parte, el {noun} ha {verb} en comparacion con anos anteriores.",
        "Por ejemplo, el {noun} tiene en general un efecto {adj} en la sociedad.",
        "El {adj} {noun} muestra que, entre otros, la {noun2} juega un papel importante.",
        "A lo largo del periodo, el {noun} ha de hecho {verb} de manera significativa.",
        "Los Estados Unidos han de esta manera {verb} la {noun} internacional.",
        "En todo caso, el {noun} de la Union Europea es importante para la {noun2}.",
        "En condiciones de mejorar el {noun}, los investigadores han obtenido resultados {adj}.",
        "Al mismo tiempo, las Naciones Unidas han {verb} la {noun2} mundial.",
    ]
    nouns = ["economia", "desarrollo", "investigacion", "sociedad", "politica",
             "educacion", "tecnologia", "medio ambiente", "salud", "seguridad"]
    adjs = ["importante", "significativo", "mayor", "fuerte", "positivo", "negativo",
            "considerable", "creciente", "notable", "destacado"]
    verbs = ["mejorado", "desarrollado", "fortalecido", "apoyado",
             "analizado", "evaluado", "implementado", "promovido"]

    sentences = []
    for _ in range(n):
        t = random.choice(templates)
        sentences.append(t.format(
            noun=random.choice(nouns), noun2=random.choice(nouns),
            adj=random.choice(adjs), verb=random.choice(verbs),
        ))
    return sentences


# ============================================================================
# MAIN
# ============================================================================

def run_code_multilingual_benchmarks():
    print("=" * 70)
    print("ION vs BPE: CODE & MULTILINGUAL BENCHMARKS")
    print("=" * 70)
    print(f"Started: {datetime.now().isoformat()}")
    print()

    vocab_sizes = [10000, 20000]
    all_results = {}

    # CODE BENCHMARKS
    print("\n*** CODE BENCHMARKS ***\n")

    # 1. Python
    py = generate_python_corpus(12000)
    random.seed(42); random.shuffle(py)
    split = int(len(py) * 0.8)
    all_results["python"] = benchmark_dataset(
        "Python Source Code", py[:split], py[split:],
        vocab_sizes, language="en", preserve_case=True,
    )

    # 2. JavaScript
    js = generate_javascript_corpus(12000)
    random.seed(42); random.shuffle(js)
    split = int(len(js) * 0.8)
    all_results["javascript"] = benchmark_dataset(
        "JavaScript Source Code", js[:split], js[split:],
        vocab_sizes, language="en", preserve_case=True,
    )

    # 3. Mixed code
    mixed = generate_mixed_code_corpus(12000)
    random.seed(42); random.shuffle(mixed)
    split = int(len(mixed) * 0.8)
    all_results["mixed_code"] = benchmark_dataset(
        "Mixed Code (Python + JavaScript)", mixed[:split], mixed[split:],
        vocab_sizes, language="en", preserve_case=True,
    )

    # MULTILINGUAL BENCHMARKS
    print("\n*** MULTILINGUAL BENCHMARKS ***\n")

    # 4. German
    de = generate_german_corpus(12000)
    random.seed(42); random.shuffle(de)
    split = int(len(de) * 0.8)
    all_results["german"] = benchmark_dataset(
        "German Text", de[:split], de[split:],
        vocab_sizes, language="de",
    )

    # 5. French
    fr = generate_french_corpus(12000)
    random.seed(42); random.shuffle(fr)
    split = int(len(fr) * 0.8)
    all_results["french"] = benchmark_dataset(
        "French Text", fr[:split], fr[split:],
        vocab_sizes, language="fr",
    )

    # 6. Spanish
    es = generate_spanish_corpus(12000)
    random.seed(42); random.shuffle(es)
    split = int(len(es) * 0.8)
    all_results["spanish"] = benchmark_dataset(
        "Spanish Text", es[:split], es[split:],
        vocab_sizes, language="es",
    )

    # GRAND SUMMARY
    print("\n" + "=" * 70)
    print("GRAND SUMMARY: CODE & MULTILINGUAL")
    print("=" * 70)

    print(f"\n{'Dataset':<35} {'Vocab':>8} {'Ion':>10} {'BPE':>10} {'Advantage':>10} {'Phrase%':>8}")
    print("-" * 85)

    advantages = []
    for ds_name, ds_data in all_results.items():
        for r in ds_data["results"]:
            adv = r["ion_advantage_pct"]
            advantages.append(adv)
            dist = r["token_distribution"]
            print(f"{ds_data['dataset'][:34]:<35} {r['vocab_size']:>8,} "
                  f"{r['ion_tokens']:>10,} {r['bpe_tokens']:>10,} "
                  f"{adv:>+9.1f}% {dist['phrase']:>7.1f}%")

    if advantages:
        avg = statistics.mean(advantages)
        print("-" * 85)
        print(f"{'AVERAGE':>35} {'':>8} {'':>10} {'':>10} {avg:>+9.1f}%")
        print(f"{'RANGE':>35} {'':>8} {'':>10} {'':>10} {min(advantages):>+.1f}% to {max(advantages):>+.1f}%")

    # Save
    output = {
        "metadata": {
            "timestamp": datetime.now().isoformat(),
            "methodology": "Ion with BPE hybrid vs pure BPE. Code uses preserve_case=True.",
            "vocab_sizes": vocab_sizes,
        },
        "datasets": all_results,
        "summary": {
            "average_advantage_pct": round(statistics.mean(advantages), 2) if advantages else 0,
            "min_advantage_pct": round(min(advantages), 2) if advantages else 0,
            "max_advantage_pct": round(max(advantages), 2) if advantages else 0,
        }
    }

    results_path = Path(__file__).parent / "benchmark_code_multilingual_results.json"
    with open(results_path, "w") as f:
        json.dump(output, f, indent=2)

    print(f"\nResults saved to: {results_path}")
    print(f"Completed: {datetime.now().isoformat()}")
    return output


if __name__ == "__main__":
    run_code_multilingual_benchmarks()
