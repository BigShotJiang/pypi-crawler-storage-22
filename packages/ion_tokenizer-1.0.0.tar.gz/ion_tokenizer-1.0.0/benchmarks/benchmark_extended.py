#!/usr/bin/env python3
"""
Extended benchmarks: Ion vs BPE on additional HuggingFace datasets and synthetic corpora.

Tests Ion on:
1. IMDB movie reviews (sentiment, long text)
2. OpenWebText sample (diverse web text)
3. BookCorpus-style text (literary/narrative)
4. Medical abstracts (synthetic PubMed-style)
5. Technical documentation (synthetic API docs)
6. Italian text (new multilingual)
7. Portuguese text (new multilingual)
8. Rust source code (new code language)
9. Go source code (new code language)
10. Newword fallback mode comparison

Also benchmarks configurable phrase_target_pct at 30%, 50%, 70%, 90%.
"""

import os
import sys
import json
import time
import tempfile
import random
import statistics
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any
from collections import Counter

sys.path.insert(0, str(Path(__file__).parent.parent))

from tqdm import tqdm
from tokenizers import Tokenizer
from tokenizers.models import BPE
from tokenizers.trainers import BpeTrainer
from tokenizers.pre_tokenizers import Whitespace

from ion.builder import TokenizerBuilder
from ion.tokenizer import IonTokenizer


def train_bpe_tokenizer(sentences: List[str], vocab_size: int) -> Tokenizer:
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
        for sent in sentences:
            f.write(sent + '\n')
        temp_path = f.name
    try:
        tokenizer = Tokenizer(BPE(unk_token="[UNK]"))
        tokenizer.pre_tokenizer = Whitespace()
        trainer = BpeTrainer(
            vocab_size=vocab_size,
            special_tokens=["[UNK]", "[PAD]", "[CLS]", "[SEP]", "[MASK]"],
            min_frequency=2,
        )
        tokenizer.train([temp_path], trainer)
        return tokenizer
    finally:
        os.unlink(temp_path)


def train_ion_tokenizer(
    sentences: List[str],
    vocab_size: int,
    language: str = "en",
    preserve_case: bool = False,
    phrase_target_pct: float = 60.0,
    fallback_mode: str = "bpe",
) -> IonTokenizer:
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
        for sent in sentences:
            f.write(sent + '\n')
        temp_path = f.name
    try:
        builder = TokenizerBuilder(
            max_vocab_size=vocab_size,
            min_word_freq=1,
            min_phrase_freq=2,
            phrase_threshold=0.00001,
            max_phrase_layers=6,
            enable_bpe_fallback=(fallback_mode == "bpe"),
            bpe_vocab_size=vocab_size,
            take_needed=False,
            language=language,
            preserve_case=preserve_case,
            phrase_target_pct=phrase_target_pct,
            fallback_mode=fallback_mode,
        )
        builder.load_corpus(temp_path)
        builder.discover_phrases()
        return builder.build_tokenizer()
    finally:
        os.unlink(temp_path)


def analyze_token_distribution(tok: IonTokenizer, sentences: List[str], sample_size: int = 1000):
    phrases = set(tok.token_classes.get("phrase", []))
    words = set(tok.token_classes.get("word", []))
    bpe_subwords = set(tok.token_classes.get("bpe_subword", []))
    counts = {"phrase": 0, "word": 0, "bpe_subword": 0, "character": 0}
    for sent in sentences[:sample_size]:
        ids = tok.encode(sent)
        for tid in ids:
            t = tok.id_to_token.get(tid, "")
            if t in phrases:
                counts["phrase"] += 1
            elif t in words:
                counts["word"] += 1
            elif t in bpe_subwords:
                counts["bpe_subword"] += 1
            else:
                counts["character"] += 1
    total = sum(counts.values()) or 1
    return {k: round(v / total * 100, 1) for k, v in counts.items()}


def benchmark_dataset(
    name, train, test, vocab_sizes, language="en", preserve_case=False,
    phrase_target_pct=60.0, fallback_mode="bpe",
):
    print(f"\n{'='*70}")
    print(f"BENCHMARK: {name}")
    print(f"{'='*70}")
    print(f"  Train: {len(train):,}, Test: {len(test):,}")
    print(f"  Language: {language}, Case: {preserve_case}, Phrase%: {phrase_target_pct}, Fallback: {fallback_mode}")

    total_test_words = sum(len(s.split()) for s in test)
    total_test_chars = sum(len(s) for s in test)

    results = []
    for vocab_size in vocab_sizes:
        print(f"\n  vocab_size={vocab_size:,}...")
        sys.stdout.flush()

        t0 = time.time()
        ion_tok = train_ion_tokenizer(
            train, vocab_size, language, preserve_case,
            phrase_target_pct, fallback_mode,
        )
        ion_train_time = time.time() - t0

        t0 = time.time()
        bpe_tok = train_bpe_tokenizer(train, vocab_size)
        bpe_train_time = time.time() - t0

        t0 = time.time()
        ion_tokens = [len(ion_tok.encode(s)) for s in test]
        ion_encode_time = time.time() - t0

        t0 = time.time()
        bpe_tokens = [len(bpe_tok.encode(s).ids) for s in test]
        bpe_encode_time = time.time() - t0

        ion_total = sum(ion_tokens)
        bpe_total = sum(bpe_tokens)
        dist = analyze_token_distribution(ion_tok, test)

        result = {
            "vocab_size": vocab_size,
            "ion_tokens": ion_total,
            "bpe_tokens": bpe_total,
            "ion_advantage_pct": round(((bpe_total - ion_total) / max(bpe_total, 1)) * 100, 2),
            "ion_chars_per_token": round(total_test_chars / max(ion_total, 1), 2),
            "bpe_chars_per_token": round(total_test_chars / max(bpe_total, 1), 2),
            "ion_phrases_count": len(ion_tok.token_classes.get("phrase", [])),
            "ion_words_count": len(ion_tok.token_classes.get("word", [])),
            "ion_actual_vocab": ion_tok.vocab_size(),
            "token_distribution": dist,
            "ion_train_time_s": round(ion_train_time, 2),
            "bpe_train_time_s": round(bpe_train_time, 2),
            "phrase_target_pct": phrase_target_pct,
            "fallback_mode": fallback_mode,
        }
        results.append(result)

        print(f"    Ion: {ion_total:,} tokens ({result['ion_chars_per_token']:.1f} c/t)")
        print(f"    BPE: {bpe_total:,} tokens ({result['bpe_chars_per_token']:.1f} c/t)")
        print(f"    Ion advantage: {result['ion_advantage_pct']:+.1f}%")
        print(f"    Phrases: {result['ion_phrases_count']:,} | Mix: "
              f"{dist['phrase']:.1f}% phrase, {dist['word']:.1f}% word, "
              f"{dist['bpe_subword']:.1f}% bpe, {dist['character']:.1f}% char")

    return {"dataset": name, "language": language, "preserve_case": preserve_case,
            "train_size": len(train), "test_size": len(test), "results": results}


# ============================================================================
# HF DATASET LOADERS
# ============================================================================

def load_imdb(max_samples: int = 15000) -> List[str]:
    """Load IMDB movie reviews from HuggingFace."""
    print("Loading IMDB reviews...")
    from datasets import load_dataset
    dataset = load_dataset("stanfordnlp/imdb", split="train")
    sentences = []
    for item in tqdm(dataset, desc="IMDB"):
        text = item.get("text", "")
        if text and len(text) > 80:
            for sent in text.replace("<br />", " ").replace("\n", " ").split(". "):
                sent = sent.strip()
                if 40 < len(sent) < 500 and sent[0].isalpha() and " " in sent:
                    sentences.append(sent + ".")
                if len(sentences) >= max_samples * 2:
                    break
        if len(sentences) >= max_samples * 2:
            break
    print(f"  Loaded {len(sentences):,} sentences")
    return sentences


def load_openwebtext_sample(max_samples: int = 15000) -> List[str]:
    """Load a sample from OpenWebText (or fallback to synthetic web text)."""
    print("Loading web text...")
    try:
        from datasets import load_dataset
        dataset = load_dataset("Skylion007/openwebtext", split="train", streaming=True)
        sentences = []
        for item in tqdm(dataset, desc="OpenWebText"):
            text = item.get("text", "")
            if text and len(text) > 80:
                for sent in text.replace("\n", " ").split(". "):
                    sent = sent.strip()
                    if 40 < len(sent) < 500 and sent[0].isalpha() and " " in sent:
                        sentences.append(sent + ".")
                    if len(sentences) >= max_samples * 2:
                        break
            if len(sentences) >= max_samples * 2:
                break
        if len(sentences) >= 1000:
            print(f"  Loaded {len(sentences):,} sentences")
            return sentences
    except Exception as e:
        print(f"  OpenWebText failed: {e}, using synthetic web text")

    return generate_web_text_corpus(max_samples)


# ============================================================================
# SYNTHETIC CORPUS GENERATORS
# ============================================================================

def generate_web_text_corpus(n: int = 15000) -> List[str]:
    """Generate synthetic diverse web text."""
    random.seed(70)
    phrases = [
        "according to", "in order to", "as well as", "such as",
        "in addition to", "on the other hand", "for example",
        "at the same time", "in terms of", "as a result",
        "a number of", "the fact that", "more than",
        "one of the most", "it is important to", "there are many",
        "when it comes to", "in the past", "in recent years",
        "this is because", "not only but also", "in other words",
    ]
    templates = [
        "According to recent reports, {topic} has become one of the most {adj} issues in {field}.",
        "In order to address the growing concern about {topic}, experts suggest {action}.",
        "The {topic} as well as {topic2} have been a number of key factors in {field}.",
        "For example, in recent years the impact of {topic} on {field} has grown significantly.",
        "On the other hand, some researchers argue that {topic} is not as {adj} as previously thought.",
        "In terms of {field}, there are many approaches to {action}, such as {method} and {method2}.",
        "At the same time, the fact that {topic} continues to {action} raises important questions.",
        "It is important to note that {topic} in the past has been more {adj} than it is today.",
        "As a result of {topic}, more than {num} organizations have adopted {method}.",
        "When it comes to {field}, one of the most {adj} developments is {topic2}.",
        "This is because {topic} not only affects {field} but also influences {field2}.",
        "In other words, the relationship between {topic} and {topic2} is more {adj} than expected.",
        "In addition to {topic}, there are many factors that contribute to the {adj} state of {field}.",
    ]
    topics = ["climate change", "artificial intelligence", "economic growth", "public health",
              "digital transformation", "renewable energy", "global trade", "urban development",
              "data privacy", "education reform", "workforce automation", "social media"]
    fields = ["technology", "healthcare", "finance", "education", "government",
              "manufacturing", "agriculture", "transportation", "energy", "media"]
    adjs = ["significant", "important", "critical", "complex", "challenging",
            "promising", "controversial", "transformative", "unprecedented", "essential"]
    actions = ["investing in new solutions", "developing better policies", "improving existing systems",
               "adopting modern practices", "strengthening international cooperation"]
    methods = ["machine learning", "data analysis", "policy reform", "community engagement",
               "technological innovation", "strategic planning"]
    nums = ["50", "100", "200", "500", "1000", "5000"]

    sentences = []
    for _ in range(n):
        t = random.choice(templates)
        sentences.append(t.format(
            topic=random.choice(topics), topic2=random.choice(topics),
            field=random.choice(fields), field2=random.choice(fields),
            adj=random.choice(adjs), action=random.choice(actions),
            method=random.choice(methods), method2=random.choice(methods),
            num=random.choice(nums),
        ))
    return sentences


def generate_book_corpus(n: int = 15000) -> List[str]:
    """Generate synthetic literary/narrative text."""
    random.seed(71)
    phrases = [
        "a long time", "for a moment", "at the same time", "in the end",
        "once upon a time", "all of a sudden", "on the other side",
        "little by little", "from time to time", "side by side",
        "face to face", "hand in hand", "step by step",
        "more and more", "again and again", "over and over",
    ]
    templates = [
        "She looked at {him} for a moment, then turned and walked toward the {place}.",
        "For a long time, {he} had known that the {thing} would change everything.",
        "All of a sudden, the {adj} {thing} appeared on the other side of the {place}.",
        "Little by little, {he} began to understand what the {adj} {person} had meant.",
        "They stood side by side, watching the {adj} {thing} {verb} in the {place}.",
        "In the end, it was the {adj} {thing} that {he} remembered most clearly.",
        "From time to time, {he} would think about the {person} and the {place}.",
        "Step by step, the {adj} journey through the {place} revealed more and more.",
        "Again and again, {he} tried to {verb} the {adj} {thing}, but it was no use.",
        "Face to face with the {person}, {he} felt a {adj} sense of recognition.",
        "Hand in hand, they crossed the {place} as the {adj} sun began to set.",
        "Over and over, the {adj} memory of that day in the {place} came back to {him}.",
    ]
    hes = ["he", "she", "the old man", "the young woman", "the traveler", "the stranger"]
    hims = ["him", "her", "the old man", "the young woman", "the traveler"]
    persons = ["stranger", "old woman", "child", "merchant", "healer", "guardian"]
    things = ["light", "shadow", "silence", "truth", "letter", "door", "path", "voice"]
    places = ["forest", "village", "river", "mountain", "garden", "castle", "market", "shore"]
    adjs = ["strange", "quiet", "ancient", "distant", "golden", "dark", "fading", "gentle"]
    verbs = ["reach", "understand", "find", "open", "cross", "remember"]

    sentences = []
    for _ in range(n):
        t = random.choice(templates)
        sentences.append(t.format(
            he=random.choice(hes), him=random.choice(hims),
            person=random.choice(persons), thing=random.choice(things),
            place=random.choice(places), adj=random.choice(adjs),
            verb=random.choice(verbs),
        ))
    return sentences


def generate_medical_corpus(n: int = 15000) -> List[str]:
    """Generate synthetic medical/clinical abstracts."""
    random.seed(72)
    phrases = [
        "blood pressure", "heart rate", "side effects", "clinical trial",
        "patient history", "differential diagnosis", "risk factors",
        "treatment outcome", "adverse events", "standard of care",
        "randomized controlled", "double blind", "placebo controlled",
        "statistically significant", "confidence interval", "hazard ratio",
        "overall survival", "progression free", "complete response",
        "body mass index", "white blood cell", "red blood cell",
    ]
    templates = [
        "In this clinical trial, we evaluated the effect of {drug} on blood pressure and heart rate.",
        "The randomized controlled double blind study enrolled {num} patients with {condition}.",
        "Side effects were minimal, with adverse events occurring in fewer than {pct} of patients.",
        "The treatment outcome showed statistically significant improvement in overall survival.",
        "Patient history revealed multiple risk factors including {risk} and {risk2}.",
        "Differential diagnosis included {condition} and {condition2} based on clinical presentation.",
        "The hazard ratio was {hr} with a confidence interval of {ci} for progression free survival.",
        "Standard of care for {condition} includes {drug} administration and monitoring of side effects.",
        "Body mass index and white blood cell count were measured at baseline and follow-up.",
        "Complete response was achieved in {pct} of the placebo controlled group.",
        "The red blood cell count showed a {adj} change following {drug} treatment.",
        "Risk factors for {condition} include elevated blood pressure and abnormal heart rate.",
    ]
    drugs = ["metformin", "atorvastatin", "lisinopril", "amlodipine", "omeprazole",
             "the experimental compound", "the novel therapeutic agent"]
    conditions = ["hypertension", "type 2 diabetes", "chronic heart failure",
                  "acute respiratory syndrome", "renal insufficiency", "hepatic dysfunction"]
    risks = ["smoking", "obesity", "sedentary lifestyle", "family history", "advanced age"]
    nums = ["120", "250", "500", "1000", "2500"]
    pcts = ["5%", "8%", "12%", "15%", "3%"]
    hrs = ["0.72", "0.85", "0.63", "0.91", "0.78"]
    cis = ["0.58-0.89", "0.71-0.99", "0.45-0.82", "0.80-1.03", "0.62-0.95"]
    adjs = ["significant", "moderate", "minimal", "marked", "gradual"]

    sentences = []
    for _ in range(n):
        t = random.choice(templates)
        sentences.append(t.format(
            drug=random.choice(drugs), condition=random.choice(conditions),
            condition2=random.choice(conditions), risk=random.choice(risks),
            risk2=random.choice(risks), num=random.choice(nums),
            pct=random.choice(pcts), hr=random.choice(hrs),
            ci=random.choice(cis), adj=random.choice(adjs),
        ))
    return sentences


def generate_tech_docs_corpus(n: int = 15000) -> List[str]:
    """Generate synthetic technical documentation."""
    random.seed(73)
    phrases = [
        "in order to", "make sure", "for more information", "keep in mind",
        "by default", "at this point", "on the other hand", "as follows",
        "in this case", "for example", "such as", "as well as",
        "set up", "log in", "sign up", "check out",
        "command line", "open source", "real time", "end to end",
    ]
    templates = [
        "In order to {action}, make sure you have installed the {tool} command line tool.",
        "By default, the {component} will {behavior} when the {event} is triggered.",
        "For more information on how to {action}, check out the {tool} documentation.",
        "Keep in mind that the {component} requires a {adj} configuration as follows.",
        "In this case, you can use the open source {tool} to {action} in real time.",
        "At this point, the {component} should be set up and ready for end to end testing.",
        "For example, to {action}, run the following command line instruction.",
        "On the other hand, the {adj} {component} as well as the {component2} need to be configured.",
        "Such as {tool}, there are several {adj} options available for {action}.",
        "To log in and sign up for the {tool} service, follow the steps as follows.",
        "The {component} provides a {adj} interface for {action} with real time feedback.",
        "Keep in mind that {tool} is an open source project and supports end to end workflows.",
    ]
    actions = ["deploy your application", "configure the service", "authenticate users",
               "process the data", "monitor performance", "set up the environment",
               "manage dependencies", "run the test suite"]
    tools = ["Docker", "Kubernetes", "Terraform", "GitHub Actions", "Jenkins",
             "the CLI", "the SDK", "the REST API"]
    components = ["server", "client", "database", "cache", "load balancer",
                  "message queue", "API gateway", "authentication module"]
    behaviors = ["automatically restart", "retry the operation", "log the error",
                 "send a notification", "fall back to defaults"]
    events = ["request timeout", "connection failure", "configuration change",
              "deployment trigger", "health check failure"]
    adjs = ["minimal", "standard", "advanced", "custom", "secure", "optimized"]

    sentences = []
    for _ in range(n):
        t = random.choice(templates)
        sentences.append(t.format(
            action=random.choice(actions), tool=random.choice(tools),
            component=random.choice(components), component2=random.choice(components),
            behavior=random.choice(behaviors), event=random.choice(events),
            adj=random.choice(adjs),
        ))
    return sentences


def generate_italian_corpus(n: int = 10000) -> List[str]:
    """Generate synthetic Italian text."""
    random.seed(74)
    phrases = [
        "d'altra parte", "per quanto riguarda", "rispetto a",
        "ad esempio", "in generale", "in ogni caso",
        "tra l'altro", "in grado di", "allo stesso tempo",
        "nel corso di", "in effetti", "in questo modo",
        "Stati Uniti", "Unione Europea", "Nazioni Unite",
    ]
    templates = [
        "Il {noun} della {noun2} era {adj} e di grande importanza per la societa.",
        "Per quanto riguarda il {noun}, il governo ha adottato misure {adj}.",
        "D'altra parte, il {noun} ha {verb} rispetto agli anni precedenti.",
        "Ad esempio, il {noun} ha in generale un effetto {adj} sulla popolazione.",
        "Il {adj} {noun} mostra che, tra l'altro, la {noun2} ha un ruolo importante.",
        "Nel corso del periodo, il {noun} ha in effetti {verb} in modo significativo.",
        "Gli Stati Uniti hanno in questo modo {verb} la {noun} internazionale.",
        "In ogni caso, il {noun} dell'Unione Europea e importante per la {noun2}.",
        "In grado di migliorare il {noun}, i ricercatori hanno ottenuto risultati {adj}.",
        "Allo stesso tempo, le Nazioni Unite hanno {verb} la {noun2} mondiale.",
    ]
    nouns = ["economia", "sviluppo", "ricerca", "societa", "politica",
             "istruzione", "tecnologia", "ambiente", "salute", "sicurezza"]
    adjs = ["importante", "significativo", "grande", "forte", "positivo", "negativo",
            "considerevole", "crescente", "notevole", "rilevante"]
    verbs = ["migliorato", "sviluppato", "rafforzato", "sostenuto",
             "analizzato", "valutato", "attuato", "promosso"]

    sentences = []
    for _ in range(n):
        t = random.choice(templates)
        sentences.append(t.format(
            noun=random.choice(nouns), noun2=random.choice(nouns),
            adj=random.choice(adjs), verb=random.choice(verbs),
        ))
    return sentences


def generate_portuguese_corpus(n: int = 10000) -> List[str]:
    """Generate synthetic Portuguese text."""
    random.seed(75)
    phrases = [
        "por outro lado", "no que diz respeito", "em relacao a",
        "por exemplo", "em geral", "de qualquer forma",
        "entre outros", "em condicoes de", "ao mesmo tempo",
        "ao longo de", "de fato", "desta forma",
        "Estados Unidos", "Uniao Europeia", "Nacoes Unidas",
    ]
    templates = [
        "O {noun} da {noun2} foi {adj} e de grande importancia para a sociedade.",
        "No que diz respeito ao {noun}, o governo adotou medidas {adj}.",
        "Por outro lado, o {noun} tem {verb} em relacao aos anos anteriores.",
        "Por exemplo, o {noun} tem em geral um efeito {adj} sobre a populacao.",
        "O {adj} {noun} mostra que, entre outros, a {noun2} desempenha um papel importante.",
        "Ao longo do periodo, o {noun} de fato {verb} de forma significativa.",
        "Os Estados Unidos desta forma {verb} a {noun} internacional.",
        "De qualquer forma, o {noun} da Uniao Europeia e importante para a {noun2}.",
        "Em condicoes de melhorar o {noun}, os pesquisadores obtiveram resultados {adj}.",
        "Ao mesmo tempo, as Nacoes Unidas {verb} a {noun2} mundial.",
    ]
    nouns = ["economia", "desenvolvimento", "pesquisa", "sociedade", "politica",
             "educacao", "tecnologia", "ambiente", "saude", "seguranca"]
    adjs = ["importante", "significativo", "grande", "forte", "positivo", "negativo",
            "consideravel", "crescente", "notavel", "relevante"]
    verbs = ["melhorado", "desenvolvido", "fortalecido", "apoiado",
             "analisado", "avaliado", "implementado", "promovido"]

    sentences = []
    for _ in range(n):
        t = random.choice(templates)
        sentences.append(t.format(
            noun=random.choice(nouns), noun2=random.choice(nouns),
            adj=random.choice(adjs), verb=random.choice(verbs),
        ))
    return sentences


def generate_rust_corpus(n: int = 10000) -> List[str]:
    """Generate synthetic Rust source code."""
    random.seed(76)
    patterns = [
        "fn {func}({args}) -> {type} {{",
        "    let mut {var} = {init};",
        "    let {var}: {type} = {expr};",
        "    if let Some({var}) = {opt}.as_ref() {{",
        "    match {var} {{",
        "        {variant} => {expr},",
        "        _ => {default},",
        "    }}",
        "    for {var} in {iter}.iter() {{",
        "        {var}.{method}({args});",
        "    }}",
        "impl {trait} for {struct} {{",
        "    fn {func}(&self, {args}) -> {type} {{",
        "        self.{field}.{method}()",
        "    }}",
        "pub struct {struct} {{",
        "    pub {field}: {type},",
        "}}",
        "use std::collections::HashMap;",
        "use std::io::{{self, Read}};",
        "#[derive(Debug, Clone)]",
        "/// {comment}",
        "    Ok({var})",
        "    Err(Error::new(\"{error}\"))",
        "    {var}.unwrap_or_default()",
        "    {var}?.{method}()",
    ]
    funcs = ["process", "parse", "build", "run", "create", "handle", "validate", "transform"]
    vars_ = ["data", "result", "value", "input", "output", "config", "state", "buf"]
    types = ["String", "Vec<u8>", "Result<(), Error>", "Option<String>", "bool", "usize", "i64", "&str"]
    inits = ["Vec::new()", "String::new()", "HashMap::new()", "0", "false", "None"]
    exprs = ["data.clone()", "value.to_string()", "input.len()", "result.unwrap()"]
    structs = ["Config", "State", "Builder", "Handler", "Parser", "Processor"]
    traits = ["Display", "FromStr", "Default", "Iterator", "Clone"]
    methods = ["push", "insert", "get", "contains", "len", "is_empty", "iter", "map"]
    fields = ["inner", "data", "config", "state", "buffer", "name"]
    variants = ["Some(v)", "Ok(v)", "Err(e)", "None"]
    defaults = ["Default::default()", "Vec::new()", "String::new()", "0"]
    iters = ["items", "entries", "results", "values", "keys"]
    args = ["key: &str", "value: T", "config: &Config", "input: &[u8]", "n: usize"]
    comments = ["Process the input data", "Create a new instance", "Validate and return result"]
    errors = ["invalid input", "parse failed", "not found", "connection error"]
    opts = ["config", "result", "value", "data"]

    sentences = []
    for _ in range(n):
        p = random.choice(patterns)
        sentences.append(p.format(
            func=random.choice(funcs), var=random.choice(vars_),
            type=random.choice(types), init=random.choice(inits),
            expr=random.choice(exprs), struct=random.choice(structs),
            trait=random.choice(traits), method=random.choice(methods),
            field=random.choice(fields), variant=random.choice(variants),
            default=random.choice(defaults), iter=random.choice(iters),
            args=random.choice(args), comment=random.choice(comments),
            error=random.choice(errors), opt=random.choice(opts),
        ))
    return sentences


def generate_go_corpus(n: int = 10000) -> List[str]:
    """Generate synthetic Go source code."""
    random.seed(77)
    patterns = [
        "func {func}({args}) ({type}, error) {{",
        "    {var}, err := {call}({args})",
        "    if err != nil {{",
        "        return {zero}, fmt.Errorf(\"{msg}: %w\", err)",
        "    }}",
        "    for _, {var} := range {slice} {{",
        "        {var}.{method}()",
        "    }}",
        "type {struct} struct {{",
        "    {field} {type}",
        "}}",
        "func ({recv} *{struct}) {func}({args}) {type} {{",
        "    return {recv}.{field}",
        "}}",
        "    ctx, cancel := context.WithTimeout(ctx, {dur})",
        "    defer cancel()",
        "package {pkg}",
        "import (",
        "    \"fmt\"",
        "    \"context\"",
        "    \"net/http\"",
        ")",
        "// {comment}",
        "    switch {var} {{",
        "    case {val}:",
        "        {stmt}",
        "    default:",
        "        return nil, errors.New(\"{msg}\")",
        "    }}",
        "    resp, err := http.Get({url})",
    ]
    funcs = ["Process", "Handle", "Create", "Get", "Set", "Delete", "Update", "List"]
    vars_ = ["data", "result", "value", "input", "output", "config", "item", "resp"]
    types = ["string", "int", "[]byte", "error", "bool", "*Config", "interface{}", "context.Context"]
    zeros = ["\"\"", "0", "nil", "false"]
    calls = ["json.Marshal", "json.Unmarshal", "http.Get", "os.Open", "ioutil.ReadAll"]
    structs = ["Server", "Client", "Handler", "Config", "Service", "Repository"]
    methods = ["Close", "Write", "Read", "Flush", "Reset", "String"]
    fields = ["Name", "Data", "Config", "State", "ID", "URL"]
    recvs = ["s", "c", "h", "r"]
    slices = ["items", "results", "records", "entries"]
    pkgs = ["main", "handler", "service", "config", "middleware"]
    args = ["ctx context.Context", "key string", "data []byte", "id int"]
    comments = ["Process handles the request", "Create initializes a new instance"]
    msgs = ["failed to process", "invalid input", "not found", "connection failed"]
    vals = ["\"active\"", "\"pending\"", "\"error\"", "\"done\""]
    stmts = ["return nil", "continue", "break", "log.Println(err)"]
    durs = ["5*time.Second", "30*time.Second", "time.Minute"]
    urls = ["\"http://api.example.com/data\""]

    sentences = []
    for _ in range(n):
        p = random.choice(patterns)
        sentences.append(p.format(
            func=random.choice(funcs), var=random.choice(vars_),
            type=random.choice(types), zero=random.choice(zeros),
            call=random.choice(calls), struct=random.choice(structs),
            method=random.choice(methods), field=random.choice(fields),
            recv=random.choice(recvs), slice=random.choice(slices),
            pkg=random.choice(pkgs), args=random.choice(args),
            comment=random.choice(comments), msg=random.choice(msgs),
            val=random.choice(vals), stmt=random.choice(stmts),
            dur=random.choice(durs), url=random.choice(urls),
        ))
    return sentences


# ============================================================================
# MAIN
# ============================================================================

def run_extended_benchmarks():
    print("=" * 70)
    print("ION vs BPE: EXTENDED BENCHMARKS")
    print("=" * 70)
    print(f"Started: {datetime.now().isoformat()}")
    print()

    vocab_sizes = [10000, 20000]
    all_results = {}

    # ===== NEW HF DATASETS =====
    print("\n*** HUGGINGFACE DATASET BENCHMARKS ***\n")

    # 1. IMDB
    try:
        imdb = load_imdb(15000)
        if len(imdb) >= 2000:
            random.seed(42); random.shuffle(imdb)
            split = int(len(imdb) * 0.8)
            all_results["imdb"] = benchmark_dataset(
                "IMDB Movie Reviews", imdb[:split], imdb[split:], vocab_sizes,
            )
    except Exception as e:
        print(f"IMDB failed: {e}")

    # 2. Web text
    try:
        web = load_openwebtext_sample(15000)
        if len(web) >= 2000:
            random.seed(42); random.shuffle(web)
            split = int(len(web) * 0.8)
            all_results["webtext"] = benchmark_dataset(
                "Web Text (OpenWebText/Synthetic)", web[:split], web[split:], vocab_sizes,
            )
    except Exception as e:
        print(f"Web text failed: {e}")

    # ===== SYNTHETIC DOMAIN BENCHMARKS =====
    print("\n*** NEW DOMAIN BENCHMARKS ***\n")

    # 3. Book corpus
    book = generate_book_corpus(15000)
    random.seed(42); random.shuffle(book)
    split = int(len(book) * 0.8)
    all_results["book"] = benchmark_dataset(
        "Literary/Narrative Text", book[:split], book[split:], vocab_sizes,
    )

    # 4. Medical
    med = generate_medical_corpus(15000)
    random.seed(42); random.shuffle(med)
    split = int(len(med) * 0.8)
    all_results["medical"] = benchmark_dataset(
        "Medical Abstracts (Clinical)", med[:split], med[split:], vocab_sizes, "en",
    )

    # 5. Tech docs
    tech = generate_tech_docs_corpus(15000)
    random.seed(42); random.shuffle(tech)
    split = int(len(tech) * 0.8)
    all_results["techdocs"] = benchmark_dataset(
        "Technical Documentation", tech[:split], tech[split:], vocab_sizes,
    )

    # ===== NEW MULTILINGUAL =====
    print("\n*** NEW MULTILINGUAL BENCHMARKS ***\n")

    # 6. Italian
    it = generate_italian_corpus(12000)
    random.seed(42); random.shuffle(it)
    split = int(len(it) * 0.8)
    all_results["italian"] = benchmark_dataset(
        "Italian Text", it[:split], it[split:], vocab_sizes, language="it",
    )

    # 7. Portuguese
    pt = generate_portuguese_corpus(12000)
    random.seed(42); random.shuffle(pt)
    split = int(len(pt) * 0.8)
    all_results["portuguese"] = benchmark_dataset(
        "Portuguese Text", pt[:split], pt[split:], vocab_sizes, language="pt",
    )

    # ===== NEW CODE LANGUAGES =====
    print("\n*** NEW CODE LANGUAGE BENCHMARKS ***\n")

    # 8. Rust
    rs = generate_rust_corpus(12000)
    random.seed(42); random.shuffle(rs)
    split = int(len(rs) * 0.8)
    all_results["rust"] = benchmark_dataset(
        "Rust Source Code", rs[:split], rs[split:], vocab_sizes,
        language="en", preserve_case=True,
    )

    # 9. Go
    go = generate_go_corpus(12000)
    random.seed(42); random.shuffle(go)
    split = int(len(go) * 0.8)
    all_results["go"] = benchmark_dataset(
        "Go Source Code", go[:split], go[split:], vocab_sizes,
        language="en", preserve_case=True,
    )

    # ===== NEWWORD FALLBACK MODE COMPARISON =====
    print("\n*** NEWWORD FALLBACK MODE COMPARISON ***\n")

    # Use web text for newword comparison
    web_corpus = generate_web_text_corpus(12000)
    random.seed(42); random.shuffle(web_corpus)
    split = int(len(web_corpus) * 0.8)

    all_results["newword_bpe"] = benchmark_dataset(
        "Web Text (BPE fallback)", web_corpus[:split], web_corpus[split:],
        [10000], fallback_mode="bpe",
    )
    all_results["newword_newword"] = benchmark_dataset(
        "Web Text (Newword fallback)", web_corpus[:split], web_corpus[split:],
        [10000], fallback_mode="newword",
    )

    # ===== PHRASE TARGET PCT SWEEP =====
    print("\n*** PHRASE TARGET % SWEEP ***\n")

    for pct in [30, 50, 70, 90]:
        all_results[f"phrase_pct_{pct}"] = benchmark_dataset(
            f"Web Text (phrase_target={pct}%)", web_corpus[:split], web_corpus[split:],
            [10000], phrase_target_pct=float(pct),
        )

    # ===== GRAND SUMMARY =====
    print("\n" + "=" * 70)
    print("GRAND SUMMARY: EXTENDED BENCHMARKS")
    print("=" * 70)

    print(f"\n{'Dataset':<40} {'Vocab':>8} {'Advantage':>10} {'Phrase%':>8}")
    print("-" * 70)

    advantages = []
    for ds_name, ds_data in all_results.items():
        for r in ds_data["results"]:
            adv = r["ion_advantage_pct"]
            advantages.append(adv)
            dist = r["token_distribution"]
            label = ds_data["dataset"][:39]
            print(f"{label:<40} {r['vocab_size']:>8,} {adv:>+9.1f}% {dist['phrase']:>7.1f}%")

    if advantages:
        avg = statistics.mean(advantages)
        print("-" * 70)
        print(f"{'AVERAGE':>40} {'':>8} {avg:>+9.1f}%")
        print(f"{'RANGE':>40} {'':>8} {min(advantages):>+.1f}% to {max(advantages):>+.1f}%")
        print(f"{'DATASETS':>40} {'':>8} {len(advantages):>9}")

    # Save
    output = {
        "metadata": {
            "timestamp": datetime.now().isoformat(),
            "methodology": "Ion with BPE hybrid vs pure BPE. Extended evaluation with new domains, languages, code, and configuration sweeps.",
            "vocab_sizes": vocab_sizes,
        },
        "datasets": {},
        "summary": {
            "average_advantage_pct": round(statistics.mean(advantages), 2) if advantages else 0,
            "min_advantage_pct": round(min(advantages), 2) if advantages else 0,
            "max_advantage_pct": round(max(advantages), 2) if advantages else 0,
            "total_benchmarks": len(advantages),
        },
    }

    # Serialize results (strip non-serializable data)
    for k, v in all_results.items():
        output["datasets"][k] = v

    results_path = Path(__file__).parent / "benchmark_extended_results.json"
    with open(results_path, "w") as f:
        json.dump(output, f, indent=2, default=str)

    print(f"\nResults saved to: {results_path}")
    print(f"Completed: {datetime.now().isoformat()}")

    return output


if __name__ == "__main__":
    run_extended_benchmarks()
