"""Benchmark Ion tokenizer on popular GitHub repositories.

Clones real repos with >1000 stars, auto-detects language,
builds Ion + BPE tokenizers, and compares compression.
"""

import json
import os
import shutil
import subprocess
import tempfile
import time
from datetime import datetime
from pathlib import Path

import requests


# Curated list of popular repos spanning different languages and domains
# Each entry: (owner/repo, primary_language, description)
REPOS = [
    # Python
    ("pallets/flask", "Python", "Web microframework"),
    ("psf/requests", "Python", "HTTP library"),
    ("fastapi/fastapi", "Python", "Modern web framework"),
    ("django/django", "Python", "Full-stack web framework"),
    ("scikit-learn/scikit-learn", "Python", "Machine learning library"),
    # JavaScript/TypeScript
    ("expressjs/express", "JavaScript", "Node.js web framework"),
    ("lodash/lodash", "JavaScript", "Utility library"),
    ("vuejs/core", "TypeScript", "Vue.js framework"),
    ("facebook/react", "JavaScript", "UI component library"),
    ("vercel/next.js", "JavaScript", "React framework"),
    # Go
    ("gin-gonic/gin", "Go", "HTTP web framework"),
    ("gofiber/fiber", "Go", "Express-inspired web framework"),
    ("kubernetes/kubernetes", "Go", "Container orchestration"),
    # Rust
    ("BurntSushi/ripgrep", "Rust", "Line-oriented search tool"),
    ("starship/starship", "Rust", "Cross-shell prompt"),
    ("denoland/deno", "Rust", "JavaScript runtime"),
    # Java
    ("iluwatar/java-design-patterns", "Java", "Design patterns"),
    ("spring-projects/spring-boot", "Java", "Java application framework"),
    # C/C++
    ("redis/redis", "C", "In-memory data store"),
    ("curl/curl", "C", "Transfer data with URLs"),
    ("nlohmann/json", "C++", "JSON library for C++"),
    # Ruby
    ("jekyll/jekyll", "Ruby", "Static site generator"),
    ("rails/rails", "Ruby", "Full-stack web framework"),
    # Mixed / Docs
    ("sindresorhus/awesome", "Markdown", "Awesome lists"),
]

# File extensions per language
LANG_EXTENSIONS = {
    "Python": [".py"],
    "JavaScript": [".js", ".mjs"],
    "TypeScript": [".ts", ".tsx"],
    "Go": [".go"],
    "Rust": [".rs"],
    "Java": [".java"],
    "C": [".c", ".h"],
    "C++": [".cpp", ".hpp", ".cc", ".hh"],
    "Ruby": [".rb"],
    "Markdown": [".md"],
}

# Map programming languages to spaCy language codes
PROG_TO_SPACY = {
    "Python": "en",
    "JavaScript": "en",
    "TypeScript": "en",
    "Go": "en",
    "Rust": "en",
    "Java": "en",
    "C": "en",
    "C++": "en",
    "Ruby": "en",
    "Markdown": "en",
}


def clone_repo(owner_repo: str, dest: str, depth: int = 1) -> bool:
    """Shallow clone a GitHub repo."""
    url = f"https://github.com/{owner_repo}.git"
    try:
        result = subprocess.run(
            ["git", "clone", "--depth", str(depth), url, dest],
            capture_output=True, text=True, timeout=120,
        )
        return result.returncode == 0
    except Exception as e:
        print(f"  Failed to clone {owner_repo}: {e}")
        return False


def collect_source_files(repo_dir: str, language: str, max_files: int = 500, max_chars: int = 5_000_000) -> str:
    """Collect source files from a repo into a single text blob."""
    extensions = LANG_EXTENSIONS.get(language, [".txt"])
    repo_path = Path(repo_dir)

    texts = []
    total_chars = 0
    file_count = 0

    for ext in extensions:
        for fpath in sorted(repo_path.rglob(f"*{ext}")):
            # Skip test/vendor/node_modules
            parts = fpath.parts
            skip_dirs = {"node_modules", "vendor", ".git", "__pycache__", "dist", "build", ".tox", "venv"}
            if any(d in parts for d in skip_dirs):
                continue

            try:
                content = fpath.read_text(encoding="utf-8", errors="ignore")
                if len(content) > 100_000:
                    content = content[:100_000]  # Cap per-file
                texts.append(content)
                total_chars += len(content)
                file_count += 1
            except Exception:
                continue

            if file_count >= max_files or total_chars >= max_chars:
                break
        if file_count >= max_files or total_chars >= max_chars:
            break

    return "\n\n".join(texts), file_count, total_chars


def benchmark_repo(owner_repo: str, language: str, description: str) -> dict:
    """Benchmark Ion vs BPE on a single repo."""
    print(f"\n{'='*70}")
    print(f"Benchmarking: {owner_repo} ({language}) - {description}")
    print(f"{'='*70}")

    result = {
        "repo": owner_repo,
        "language": language,
        "description": description,
    }

    with tempfile.TemporaryDirectory() as tmpdir:
        repo_dir = os.path.join(tmpdir, "repo")

        # Clone
        print(f"  Cloning {owner_repo}...")
        if not clone_repo(owner_repo, repo_dir):
            print(f"  SKIP: Failed to clone")
            result["status"] = "clone_failed"
            return result

        # Collect source files
        print(f"  Collecting {language} source files...")
        corpus_text, file_count, total_chars = collect_source_files(repo_dir, language)

        if total_chars < 1000:
            print(f"  SKIP: Too little source code ({total_chars} chars)")
            result["status"] = "insufficient_data"
            return result

        print(f"  Found {file_count} files, {total_chars:,} chars")
        result["file_count"] = file_count
        result["total_chars"] = total_chars

        # Write corpus to temp file
        corpus_path = os.path.join(tmpdir, "corpus.txt")
        with open(corpus_path, "w", encoding="utf-8") as f:
            f.write(corpus_text)

        # Auto-detect language
        from ion.corpus import detect_language, detect_if_code
        samples = corpus_text.split("\n\n")[:200]
        detected_lang = detect_language(samples[:100])
        is_code = detect_if_code(samples[:200])
        result["detected_language"] = detected_lang
        result["detected_code"] = is_code
        print(f"  Auto-detect: lang={detected_lang}, code={is_code}")

        # Determine settings
        preserve_case = is_code
        spacy_lang = detected_lang

        # Build Ion tokenizer
        print(f"  Training Ion tokenizer...")
        try:
            from ion.builder import build_tokenizer
            t0 = time.time()
            ion_stats = build_tokenizer(
                source=corpus_path,
                output=os.path.join(tmpdir, "ion.json"),
                max_vocab_size=10000,
                min_word_freq=1,
                min_phrase_freq=2,
                max_sentences=100_000,
                language=spacy_lang,
                preserve_case=preserve_case,
            )
            ion_train_time = time.time() - t0
        except Exception as e:
            print(f"  SKIP: Ion training failed: {e}")
            result["status"] = "ion_failed"
            return result

        # Load Ion tokenizer
        import orjson
        from ion.tokenizer import IonTokenizer
        ion_data = orjson.loads(Path(os.path.join(tmpdir, "ion.json")).read_bytes())
        ion_tok = IonTokenizer.from_dict(ion_data)

        # Build BPE tokenizer
        print(f"  Training BPE tokenizer...")
        try:
            from tokenizers import Tokenizer
            from tokenizers.models import BPE
            from tokenizers.trainers import BpeTrainer
            from tokenizers.pre_tokenizers import Whitespace

            t0 = time.time()
            bpe_tokenizer = Tokenizer(BPE(unk_token="<unk>"))
            bpe_tokenizer.pre_tokenizer = Whitespace()
            trainer = BpeTrainer(
                special_tokens=["<pad>", "<unk>", "<bos>", "<eos>"],
                vocab_size=10000,
                min_frequency=2,
            )
            bpe_tokenizer.train([corpus_path], trainer)
            bpe_train_time = time.time() - t0
        except Exception as e:
            print(f"  SKIP: BPE training failed: {e}")
            result["status"] = "bpe_failed"
            return result

        # Benchmark on test portion
        print(f"  Benchmarking...")
        # Use last 20% as test
        lines = corpus_text.split("\n")
        test_start = int(len(lines) * 0.8)
        test_lines = lines[test_start:]
        test_text_chunks = []
        chunk = ""
        for line in test_lines:
            chunk += line + "\n"
            if len(chunk) > 500:
                test_text_chunks.append(chunk.strip())
                chunk = ""
        if chunk.strip():
            test_text_chunks.append(chunk.strip())

        ion_tokens = 0
        bpe_tokens = 0
        total_test_chars = 0

        for chunk in test_text_chunks[:2000]:
            if not chunk.strip():
                continue
            total_test_chars += len(chunk)
            ion_encoded = ion_tok.encode(chunk)
            bpe_encoded = bpe_tokenizer.encode(chunk)
            ion_tokens += len(ion_encoded)
            bpe_tokens += len(bpe_encoded.ids)

        if bpe_tokens == 0:
            print(f"  SKIP: No test data encoded")
            result["status"] = "no_test_data"
            return result

        ion_advantage = (bpe_tokens - ion_tokens) / bpe_tokens * 100
        ion_cpt = total_test_chars / max(ion_tokens, 1)
        bpe_cpt = total_test_chars / max(bpe_tokens, 1)

        result.update({
            "status": "success",
            "vocab_size": 10000,
            "ion_vocab_actual": ion_tok.vocab_size(),
            "ion_tokens": ion_tokens,
            "bpe_tokens": bpe_tokens,
            "ion_advantage_pct": round(ion_advantage, 2),
            "ion_chars_per_token": round(ion_cpt, 2),
            "bpe_chars_per_token": round(bpe_cpt, 2),
            "ion_phrases": len(ion_tok.token_classes["phrase"]),
            "ion_words": len(ion_tok.token_classes["word"]),
            "ion_train_time_s": round(ion_train_time, 2),
            "bpe_train_time_s": round(bpe_train_time, 2),
            "test_chars": total_test_chars,
            "preserve_case": preserve_case,
        })

        # Print result
        winner = "ION" if ion_advantage > 0 else "BPE"
        print(f"\n  Results for {owner_repo}:")
        print(f"    Ion tokens:  {ion_tokens:>10,}")
        print(f"    BPE tokens:  {bpe_tokens:>10,}")
        print(f"    Advantage:   {ion_advantage:>+9.1f}% ({winner} wins)")
        print(f"    Ion c/t:     {ion_cpt:>10.2f}")
        print(f"    BPE c/t:     {bpe_cpt:>10.2f}")
        print(f"    Ion phrases: {len(ion_tok.token_classes['phrase']):>10,}")

    return result


def main():
    print("=" * 70)
    print("ION vs BPE: GITHUB REPOS BENCHMARK")
    print("=" * 70)
    print(f"Testing on {len(REPOS)} popular GitHub repositories (>1000 stars)")
    print(f"Timestamp: {datetime.now().isoformat()}")
    print()

    results = []
    for owner_repo, language, description in REPOS:
        try:
            result = benchmark_repo(owner_repo, language, description)
            results.append(result)
        except Exception as e:
            print(f"  ERROR: {e}")
            results.append({
                "repo": owner_repo,
                "language": language,
                "description": description,
                "status": "error",
                "error": str(e),
            })

    # Summary
    successful = [r for r in results if r.get("status") == "success"]

    print("\n" + "=" * 70)
    print("SUMMARY: ION vs BPE ON REAL GITHUB REPOS")
    print("=" * 70)

    if successful:
        print(f"\n{'Repo':<35} {'Language':<12} {'Ion Adv':>10} {'Ion c/t':>8} {'BPE c/t':>8} {'Phrases':>8}")
        print("-" * 85)

        total_advantage = 0
        wins = 0
        losses = 0

        for r in successful:
            adv = r["ion_advantage_pct"]
            total_advantage += adv
            if adv > 0:
                wins += 1
            else:
                losses += 1

            repo_short = r["repo"]
            if len(repo_short) > 33:
                repo_short = "..." + repo_short[-30:]
            print(f"{repo_short:<35} {r['language']:<12} {adv:>+9.1f}% {r['ion_chars_per_token']:>8.2f} {r['bpe_chars_per_token']:>8.2f} {r['ion_phrases']:>8,}")

        avg_advantage = total_advantage / len(successful)
        max_adv = max(r["ion_advantage_pct"] for r in successful)
        min_adv = min(r["ion_advantage_pct"] for r in successful)

        print("-" * 85)
        print(f"\n  Repos tested:    {len(successful)}")
        print(f"  Ion wins:        {wins}")
        print(f"  BPE wins:        {losses}")
        print(f"  Avg advantage:   {avg_advantage:+.1f}%")
        print(f"  Best:            {max_adv:+.1f}%")
        print(f"  Worst:           {min_adv:+.1f}%")

    failed = [r for r in results if r.get("status") != "success"]
    if failed:
        print(f"\n  Skipped/failed:  {len(failed)}")
        for r in failed:
            print(f"    - {r['repo']}: {r.get('status', 'unknown')}")

    # Save results
    output_path = Path(__file__).parent / "benchmark_github_repos_results.json"
    output = {
        "metadata": {
            "timestamp": datetime.now().isoformat(),
            "repos_tested": len(REPOS),
            "repos_successful": len(successful),
            "methodology": "Shallow clone, collect source files, train Ion+BPE at 10K vocab, compare on held-out 20%",
        },
        "results": results,
    }
    if successful:
        output["summary"] = {
            "average_advantage_pct": round(avg_advantage, 2),
            "min_advantage_pct": round(min_adv, 2),
            "max_advantage_pct": round(max_adv, 2),
            "ion_wins": wins,
            "bpe_wins": losses,
        }

    output_path.write_text(json.dumps(output, indent=2))
    print(f"\nResults saved to: {output_path}")


if __name__ == "__main__":
    main()
