#!/usr/bin/env python3
"""
Compare Ion (BPE fallback) vs Ion (newword fallback) vs pure BPE across ALL domains.

Runs every corpus generator from the existing benchmarks with both fallback modes
and reports the difference.
"""

import os
import sys
import json
import time
import tempfile
import random
import statistics
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any

sys.path.insert(0, str(Path(__file__).parent.parent))

from tqdm import tqdm
from tokenizers import Tokenizer
from tokenizers.models import BPE
from tokenizers.trainers import BpeTrainer
from tokenizers.pre_tokenizers import Whitespace

from ion.builder import TokenizerBuilder
from ion.tokenizer import IonTokenizer

# Import corpus generators from sibling benchmarks
from benchmark_realworld import (
    generate_legal_corpus, generate_scientific_corpus, generate_conversational_corpus,
)
from benchmark_code_multilingual import (
    generate_python_corpus, generate_javascript_corpus, generate_mixed_code_corpus,
    generate_german_corpus, generate_french_corpus, generate_spanish_corpus,
)


def train_bpe(sentences: List[str], vocab_size: int) -> Tokenizer:
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
        for s in sentences:
            f.write(s + '\n')
        p = f.name
    try:
        tok = Tokenizer(BPE(unk_token="[UNK]"))
        tok.pre_tokenizer = Whitespace()
        trainer = BpeTrainer(vocab_size=vocab_size, special_tokens=["[UNK]","[PAD]","[CLS]","[SEP]","[MASK]"], min_frequency=2)
        tok.train([p], trainer)
        return tok
    finally:
        os.unlink(p)


def train_ion(sentences: List[str], vocab_size: int, fallback_mode: str = "bpe",
              language: str = "en", preserve_case: bool = False) -> IonTokenizer:
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
        for s in sentences:
            f.write(s + '\n')
        p = f.name
    try:
        enable_bpe = fallback_mode == "bpe"
        builder = TokenizerBuilder(
            max_vocab_size=vocab_size,
            min_word_freq=1,
            min_phrase_freq=2,
            phrase_threshold=0.00001,
            max_phrase_layers=6,
            enable_bpe_fallback=enable_bpe,
            bpe_vocab_size=vocab_size,
            take_needed=False,
            language=language,
            preserve_case=preserve_case,
            fallback_mode=fallback_mode,
        )
        builder.load_corpus(p)
        builder.discover_phrases()
        return builder.build_tokenizer()
    finally:
        os.unlink(p)


def count_tokens(tok, sentences):
    return sum(len(tok.encode(s)) for s in sentences)


def count_bpe_tokens(tok, sentences):
    return sum(len(tok.encode(s).ids) for s in sentences)


def run_comparison(name, train_sents, test_sents, vocab_size=20000,
                   language="en", preserve_case=False):
    """Run BPE vs Ion(bpe) vs Ion(newword) on a single dataset."""
    print(f"\n{'='*60}")
    print(f"  {name}  (vocab={vocab_size:,}, train={len(train_sents):,}, test={len(test_sents):,})")
    print(f"{'='*60}")

    # Pure BPE baseline
    t0 = time.time()
    bpe_tok = train_bpe(train_sents, vocab_size)
    bpe_train = time.time() - t0
    bpe_total = count_bpe_tokens(bpe_tok, test_sents)

    # Ion with BPE fallback
    t0 = time.time()
    ion_bpe = train_ion(train_sents, vocab_size, "bpe", language, preserve_case)
    ion_bpe_train = time.time() - t0
    ion_bpe_total = count_tokens(ion_bpe, test_sents)

    # Ion with newword fallback
    t0 = time.time()
    ion_nw = train_ion(train_sents, vocab_size, "newword", language, preserve_case)
    ion_nw_train = time.time() - t0
    ion_nw_total = count_tokens(ion_nw, test_sents)

    bpe_adv = round(((bpe_total - ion_bpe_total) / max(bpe_total, 1)) * 100, 2)
    nw_adv = round(((bpe_total - ion_nw_total) / max(bpe_total, 1)) * 100, 2)
    nw_vs_bpe = round(((ion_bpe_total - ion_nw_total) / max(ion_bpe_total, 1)) * 100, 2)

    print(f"  Pure BPE:      {bpe_total:>10,} tokens  (baseline)")
    print(f"  Ion+BPE:       {ion_bpe_total:>10,} tokens  ({bpe_adv:+.1f}% vs BPE)")
    print(f"  Ion+newword:   {ion_nw_total:>10,} tokens  ({nw_adv:+.1f}% vs BPE)")
    print(f"  Newword wins:  {nw_vs_bpe:+.1f}% fewer tokens than Ion+BPE")

    return {
        "dataset": name,
        "vocab_size": vocab_size,
        "bpe_tokens": bpe_total,
        "ion_bpe_tokens": ion_bpe_total,
        "ion_newword_tokens": ion_nw_total,
        "ion_bpe_vs_bpe_pct": bpe_adv,
        "ion_newword_vs_bpe_pct": nw_adv,
        "newword_vs_ion_bpe_pct": nw_vs_bpe,
        "bpe_train_s": round(bpe_train, 2),
        "ion_bpe_train_s": round(ion_bpe_train, 2),
        "ion_nw_train_s": round(ion_nw_train, 2),
    }


def load_hf_dataset(name, split="train", text_field="text", max_samples=15000):
    """Load a HuggingFace dataset."""
    from datasets import load_dataset
    ds = load_dataset(name, split=split, trust_remote_code=True)
    sents = []
    for item in ds:
        text = item.get(text_field, "")
        if text and len(text) > 40:
            for s in text.replace("\n", " ").split(". "):
                s = s.strip()
                if 30 < len(s) < 400 and s[0:1].isalpha() and " " in s:
                    sents.append(s + ".")
                if len(sents) >= max_samples:
                    return sents
    return sents


def main():
    print("=" * 60)
    print("ION NEWWORD vs BPE FALLBACK: ALL-DOMAIN COMPARISON")
    print("=" * 60)
    print(f"Started: {datetime.now().isoformat()}\n")

    results = []
    vocab_size = 20000

    # --- HuggingFace datasets ---
    print("\n*** HUGGINGFACE DATASETS ***")

    # IMDB
    try:
        from datasets import load_dataset
        print("Loading IMDB...")
        ds = load_dataset("imdb", split="train")
        sents = []
        for item in ds:
            text = item.get("text", "")
            if text and len(text) > 40:
                for s in text.replace("\n", " ").split(". "):
                    s = s.strip()
                    if 30 < len(s) < 400 and s[0:1].isalpha() and " " in s:
                        sents.append(s + ".")
                    if len(sents) >= 20000:
                        break
            if len(sents) >= 20000:
                break
        if len(sents) >= 2000:
            random.seed(42); random.shuffle(sents)
            split = int(len(sents) * 0.8)
            results.append(run_comparison("IMDB Reviews", sents[:split], sents[split:], vocab_size))
    except Exception as e:
        print(f"  IMDB failed: {e}")

    # WikiText
    try:
        print("Loading WikiText-103...")
        ds = load_dataset("wikitext", "wikitext-103-v1", split="train")
        sents = []
        for item in ds:
            text = item.get("text", "")
            if text and len(text) > 50:
                for s in text.replace("\n", " ").split(". "):
                    s = s.strip()
                    if 40 < len(s) < 400 and s[0:1].isalpha() and " " in s:
                        sents.append(s + ".")
                    if len(sents) >= 20000:
                        break
            if len(sents) >= 20000:
                break
        if len(sents) >= 2000:
            random.seed(42); random.shuffle(sents)
            split = int(len(sents) * 0.8)
            results.append(run_comparison("WikiText-103", sents[:split], sents[split:], vocab_size))
    except Exception as e:
        print(f"  WikiText failed: {e}")

    # AG News
    try:
        print("Loading AG News...")
        ds = load_dataset("fancyzhx/ag_news", split="train")
        sents = []
        for item in ds:
            text = item.get("text", "")
            if text and len(text) > 40:
                for s in text.replace("\n", " ").split(". "):
                    s = s.strip()
                    if 30 < len(s) < 400 and s[0:1].isalpha() and " " in s:
                        sents.append(s + ".")
                    if len(sents) >= 20000:
                        break
            if len(sents) >= 20000:
                break
        if len(sents) >= 2000:
            random.seed(42); random.shuffle(sents)
            split = int(len(sents) * 0.8)
            results.append(run_comparison("AG News", sents[:split], sents[split:], vocab_size))
    except Exception as e:
        print(f"  AG News failed: {e}")

    # --- Synthetic text domains ---
    print("\n*** SYNTHETIC TEXT DOMAINS ***")

    for name, gen_fn, lang, pc in [
        ("Legal", generate_legal_corpus, "en", False),
        ("Scientific", generate_scientific_corpus, "en", False),
        ("Conversational", generate_conversational_corpus, "en", False),
        ("German", generate_german_corpus, "de", False),
        ("French", generate_french_corpus, "fr", False),
        ("Spanish", generate_spanish_corpus, "es", False),
    ]:
        sents = gen_fn(15000)
        random.seed(42); random.shuffle(sents)
        split = int(len(sents) * 0.8)
        results.append(run_comparison(name, sents[:split], sents[split:], vocab_size, lang, pc))

    # --- Code domains ---
    print("\n*** CODE DOMAINS ***")

    for name, gen_fn in [
        ("Python Code", generate_python_corpus),
        ("JavaScript Code", generate_javascript_corpus),
        ("Mixed Code", generate_mixed_code_corpus),
    ]:
        sents = gen_fn(12000)
        random.seed(42); random.shuffle(sents)
        split = int(len(sents) * 0.8)
        results.append(run_comparison(name, sents[:split], sents[split:], vocab_size, "en", True))

    # --- GRAND SUMMARY ---
    print("\n" + "=" * 80)
    print("GRAND SUMMARY: NEWWORD vs BPE FALLBACK ACROSS ALL DOMAINS")
    print("=" * 80)
    print(f"\n{'Dataset':<25} {'BPE tok':>10} {'Ion+BPE':>10} {'Ion+NW':>10} {'BPE adv':>8} {'NW adv':>8} {'NW wins':>8}")
    print("-" * 80)

    bpe_advs = []
    nw_advs = []
    nw_wins = []

    for r in results:
        print(f"{r['dataset']:<25} {r['bpe_tokens']:>10,} {r['ion_bpe_tokens']:>10,} "
              f"{r['ion_newword_tokens']:>10,} {r['ion_bpe_vs_bpe_pct']:>+7.1f}% "
              f"{r['ion_newword_vs_bpe_pct']:>+7.1f}% {r['newword_vs_ion_bpe_pct']:>+7.1f}%")
        bpe_advs.append(r['ion_bpe_vs_bpe_pct'])
        nw_advs.append(r['ion_newword_vs_bpe_pct'])
        nw_wins.append(r['newword_vs_ion_bpe_pct'])

    print("-" * 80)
    if results:
        print(f"{'AVERAGE':<25} {'':>10} {'':>10} {'':>10} "
              f"{statistics.mean(bpe_advs):>+7.1f}% {statistics.mean(nw_advs):>+7.1f}% "
              f"{statistics.mean(nw_wins):>+7.1f}%")
        print(f"{'MEDIAN':<25} {'':>10} {'':>10} {'':>10} "
              f"{statistics.median(bpe_advs):>+7.1f}% {statistics.median(nw_advs):>+7.1f}% "
              f"{statistics.median(nw_wins):>+7.1f}%")

    # Save
    output = {
        "metadata": {
            "timestamp": datetime.now().isoformat(),
            "vocab_size": vocab_size,
            "methodology": "Ion+BPE = phrase-first with BPE subword fallback. Ion+newword = phrase-first with dynamic word creation fallback. Both use take_needed=False, phrase_target_pct=60.",
        },
        "results": results,
        "summary": {
            "num_datasets": len(results),
            "avg_ion_bpe_vs_bpe": round(statistics.mean(bpe_advs), 2) if bpe_advs else 0,
            "avg_ion_newword_vs_bpe": round(statistics.mean(nw_advs), 2) if nw_advs else 0,
            "avg_newword_vs_ion_bpe": round(statistics.mean(nw_wins), 2) if nw_wins else 0,
            "median_newword_vs_ion_bpe": round(statistics.median(nw_wins), 2) if nw_wins else 0,
        },
    }

    out_path = Path(__file__).parent / "benchmark_newword_comparison_results.json"
    with open(out_path, "w") as f:
        json.dump(output, f, indent=2)
    print(f"\nResults saved to: {out_path}")
    print(f"Completed: {datetime.now().isoformat()}")
    return output


if __name__ == "__main__":
    main()
