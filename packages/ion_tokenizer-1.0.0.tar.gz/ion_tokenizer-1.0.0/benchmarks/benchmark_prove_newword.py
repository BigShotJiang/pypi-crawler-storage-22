#!/usr/bin/env python3
"""
Comprehensive proof: newword fallback is superior across many real-world datasets,
multiple vocab sizes, and diverse domains.

Tests:
- 8+ real HuggingFace datasets (no synthetic)
- 3 vocab sizes each (5K, 10K, 20K)
- Measures: Ion+BPE vs Ion+newword vs pure BPE
"""

import os
import sys
import json
import time
import tempfile
import random
import statistics
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any

sys.path.insert(0, str(Path(__file__).parent.parent))

from tokenizers import Tokenizer
from tokenizers.models import BPE
from tokenizers.trainers import BpeTrainer
from tokenizers.pre_tokenizers import Whitespace

from ion.builder import TokenizerBuilder
from ion.tokenizer import IonTokenizer


def train_bpe(sentences, vocab_size):
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
        for s in sentences:
            f.write(s + '\n')
        p = f.name
    try:
        tok = Tokenizer(BPE(unk_token="[UNK]"))
        tok.pre_tokenizer = Whitespace()
        trainer = BpeTrainer(vocab_size=vocab_size,
                             special_tokens=["[UNK]","[PAD]","[CLS]","[SEP]","[MASK]"],
                             min_frequency=2)
        tok.train([p], trainer)
        return tok
    finally:
        os.unlink(p)


def train_ion(sentences, vocab_size, fallback_mode="bpe", language="en", preserve_case=False):
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
        for s in sentences:
            f.write(s + '\n')
        p = f.name
    try:
        builder = TokenizerBuilder(
            max_vocab_size=vocab_size,
            min_word_freq=1,
            min_phrase_freq=2,
            phrase_threshold=0.00001,
            max_phrase_layers=6,
            enable_bpe_fallback=(fallback_mode == "bpe"),
            bpe_vocab_size=vocab_size,
            take_needed=False,
            language=language,
            preserve_case=preserve_case,
            fallback_mode=fallback_mode,
        )
        builder.load_corpus(p)
        builder.discover_phrases()
        return builder.build_tokenizer()
    finally:
        os.unlink(p)


def extract_sentences(texts, max_sents=20000, min_len=30, max_len=400):
    """Extract clean sentences from raw texts."""
    sents = []
    for text in texts:
        if not text or len(text) < 40:
            continue
        for s in text.replace("\n", " ").split(". "):
            s = s.strip()
            if min_len < len(s) < max_len and s[0:1].isalpha() and " " in s:
                sents.append(s + ".")
            if len(sents) >= max_sents:
                return sents
    return sents


def run_one(name, train_sents, test_sents, vocab_size, language="en", preserve_case=False):
    """Single comparison: BPE vs Ion+BPE vs Ion+newword."""
    # Pure BPE
    bpe_tok = train_bpe(train_sents, vocab_size)
    bpe_total = sum(len(bpe_tok.encode(s).ids) for s in test_sents)

    # Ion+BPE
    ion_bpe = train_ion(train_sents, vocab_size, "bpe", language, preserve_case)
    ion_bpe_total = sum(len(ion_bpe.encode(s)) for s in test_sents)

    # Ion+newword
    ion_nw = train_ion(train_sents, vocab_size, "newword", language, preserve_case)
    ion_nw_total = sum(len(ion_nw.encode(s)) for s in test_sents)

    bpe_adv = round(((bpe_total - ion_bpe_total) / max(bpe_total, 1)) * 100, 2)
    nw_adv = round(((bpe_total - ion_nw_total) / max(bpe_total, 1)) * 100, 2)
    nw_vs_bpe = round(((ion_bpe_total - ion_nw_total) / max(ion_bpe_total, 1)) * 100, 2)

    return {
        "dataset": name, "vocab_size": vocab_size,
        "bpe_tokens": bpe_total, "ion_bpe_tokens": ion_bpe_total,
        "ion_nw_tokens": ion_nw_total,
        "ion_bpe_vs_bpe_pct": bpe_adv, "ion_nw_vs_bpe_pct": nw_adv,
        "nw_vs_ion_bpe_pct": nw_vs_bpe,
    }


def load_hf(name, config=None, split="train", field="text", max_items=30000):
    from datasets import load_dataset
    if config:
        ds = load_dataset(name, config, split=split, trust_remote_code=True)
    else:
        ds = load_dataset(name, split=split, trust_remote_code=True)
    texts = []
    for item in ds:
        t = item.get(field, "")
        if t:
            texts.append(t)
        if len(texts) >= max_items:
            break
    return texts


def main():
    from datasets import load_dataset

    print("=" * 80)
    print("COMPREHENSIVE PROOF: NEWWORD vs BPE ACROSS REAL-WORLD DATASETS")
    print("=" * 80)
    print(f"Started: {datetime.now().isoformat()}\n")

    vocab_sizes = [5000, 10000, 20000]
    all_results = []

    # Define datasets to test
    datasets_to_test = [
        ("IMDB Reviews", "imdb", None, "train", "text"),
        ("WikiText-103", "wikitext", "wikitext-103-v1", "train", "text"),
        ("AG News", "fancyzhx/ag_news", None, "train", "text"),
        ("Rotten Tomatoes", "cornell-movie-review-data/rotten_tomatoes", None, "train", "text"),
        ("Tweet Eval (Sentiment)", "cardiffnlp/tweet_eval", "sentiment", "train", "text"),
        ("Amazon Polarity", "amazon_polarity", None, "train", "content"),
        ("Yelp Reviews", "yelp_review_full", None, "train", "text"),
        ("DBpedia14", "fancyzhx/dbpedia_14", None, "train", "content"),
    ]

    for ds_name, hf_name, config, split, field in datasets_to_test:
        print(f"\n{'='*70}")
        print(f"Loading {ds_name} ({hf_name})...")
        try:
            texts = load_hf(hf_name, config, split, field)
            sents = extract_sentences(texts)
            if len(sents) < 2000:
                print(f"  Only {len(sents)} sentences, skipping")
                continue

            random.seed(42)
            random.shuffle(sents)
            # Cap at 20K for speed
            sents = sents[:20000]
            sp = int(len(sents) * 0.8)
            train_s, test_s = sents[:sp], sents[sp:]

            print(f"  {len(train_s):,} train, {len(test_s):,} test sentences")

            for vs in vocab_sizes:
                print(f"\n  vocab={vs:,}...")
                r = run_one(ds_name, train_s, test_s, vs)
                all_results.append(r)
                nw_win = "WIN" if r["nw_vs_ion_bpe_pct"] > 0 else ("TIE" if r["nw_vs_ion_bpe_pct"] == 0 else "LOSS")
                print(f"    BPE:{r['bpe_tokens']:>9,}  Ion+BPE:{r['ion_bpe_tokens']:>9,}  "
                      f"Ion+NW:{r['ion_nw_tokens']:>9,}  NW vs BPE: {r['nw_vs_ion_bpe_pct']:+.1f}% [{nw_win}]")

        except Exception as e:
            print(f"  FAILED: {e}")
            import traceback; traceback.print_exc()

    # GRAND SUMMARY
    print("\n" + "=" * 90)
    print("GRAND SUMMARY")
    print("=" * 90)

    print(f"\n{'Dataset':<25} {'Vocab':>6} {'Pure BPE':>10} {'Ion+BPE':>10} {'Ion+NW':>10} "
          f"{'BPE adv':>8} {'NW adv':>8} {'NW wins':>8}")
    print("-" * 90)

    wins = 0
    ties = 0
    losses = 0
    nw_margins = []

    for r in all_results:
        nw_win = r["nw_vs_ion_bpe_pct"]
        tag = "WIN" if nw_win > 0 else ("TIE" if nw_win == 0 else "LOSS")
        if nw_win > 0: wins += 1
        elif nw_win == 0: ties += 1
        else: losses += 1
        nw_margins.append(nw_win)

        print(f"{r['dataset']:<25} {r['vocab_size']:>6,} {r['bpe_tokens']:>10,} "
              f"{r['ion_bpe_tokens']:>10,} {r['ion_nw_tokens']:>10,} "
              f"{r['ion_bpe_vs_bpe_pct']:>+7.1f}% {r['ion_nw_vs_bpe_pct']:>+7.1f}% "
              f"{r['nw_vs_ion_bpe_pct']:>+7.1f}% {tag}")

    print("-" * 90)
    if nw_margins:
        print(f"\nNewword vs Ion+BPE:")
        print(f"  Wins:   {wins}/{len(all_results)} ({wins/len(all_results)*100:.0f}%)")
        print(f"  Ties:   {ties}/{len(all_results)} ({ties/len(all_results)*100:.0f}%)")
        print(f"  Losses: {losses}/{len(all_results)} ({losses/len(all_results)*100:.0f}%)")
        print(f"  Average margin: {statistics.mean(nw_margins):+.2f}%")
        print(f"  Median margin:  {statistics.median(nw_margins):+.2f}%")
        print(f"  Min margin:     {min(nw_margins):+.2f}%")
        print(f"  Max margin:     {max(nw_margins):+.2f}%")

    # Per-dataset summary (avg across vocab sizes)
    print(f"\nPer-dataset average (across vocab sizes):")
    print(f"{'Dataset':<25} {'Avg NW vs BPE':>15} {'Avg NW vs pure BPE':>20}")
    print("-" * 65)
    ds_names = []
    for r in all_results:
        if r["dataset"] not in ds_names:
            ds_names.append(r["dataset"])
    for dn in ds_names:
        ds_results = [r for r in all_results if r["dataset"] == dn]
        avg_nw = statistics.mean([r["nw_vs_ion_bpe_pct"] for r in ds_results])
        avg_nw_bpe = statistics.mean([r["ion_nw_vs_bpe_pct"] for r in ds_results])
        print(f"{dn:<25} {avg_nw:>+14.1f}% {avg_nw_bpe:>+19.1f}%")

    # Save
    output = {
        "metadata": {
            "timestamp": datetime.now().isoformat(),
            "vocab_sizes": vocab_sizes,
            "methodology": "All real HuggingFace datasets. take_needed=False, phrase_target_pct=60. 80/20 train/test split.",
            "num_comparisons": len(all_results),
        },
        "results": all_results,
        "summary": {
            "wins": wins, "ties": ties, "losses": losses,
            "total": len(all_results),
            "avg_nw_margin": round(statistics.mean(nw_margins), 2) if nw_margins else 0,
            "median_nw_margin": round(statistics.median(nw_margins), 2) if nw_margins else 0,
        },
    }

    out_path = Path(__file__).parent / "benchmark_prove_newword_results.json"
    with open(out_path, "w") as f:
        json.dump(output, f, indent=2)
    print(f"\nResults saved to: {out_path}")
    print(f"Completed: {datetime.now().isoformat()}")
    return output


if __name__ == "__main__":
    main()
