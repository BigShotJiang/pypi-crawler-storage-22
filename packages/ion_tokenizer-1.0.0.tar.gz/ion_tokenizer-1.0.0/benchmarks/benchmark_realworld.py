#!/usr/bin/env python3
"""
Real-world benchmark: Ion vs BPE across multiple diverse datasets.

Tests Ion on:
1. WikiText-103 (encyclopedic)
2. AG News (news articles)
3. Legal text (synthetic formal/legal)
4. Scientific abstracts (synthetic research)
5. Conversational text (synthetic chat)

Generates comprehensive results for the research paper.
"""

import os
import sys
import json
import time
import tempfile
import random
import statistics
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional
from collections import Counter

sys.path.insert(0, str(Path(__file__).parent.parent))

from tqdm import tqdm
from tokenizers import Tokenizer
from tokenizers.models import BPE
from tokenizers.trainers import BpeTrainer
from tokenizers.pre_tokenizers import Whitespace

from ion.builder import TokenizerBuilder
from ion.tokenizer import IonTokenizer


def train_bpe_tokenizer(sentences: List[str], vocab_size: int) -> Tokenizer:
    """Train a BPE tokenizer on the given sentences."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
        for sent in sentences:
            f.write(sent + '\n')
        temp_path = f.name
    try:
        tokenizer = Tokenizer(BPE(unk_token="[UNK]"))
        tokenizer.pre_tokenizer = Whitespace()
        trainer = BpeTrainer(
            vocab_size=vocab_size,
            special_tokens=["[UNK]", "[PAD]", "[CLS]", "[SEP]", "[MASK]"],
            min_frequency=2,
        )
        tokenizer.train([temp_path], trainer)
        return tokenizer
    finally:
        os.unlink(temp_path)


def train_ion_tokenizer(sentences: List[str], vocab_size: int, domain: str = "general") -> IonTokenizer:
    """Train an Ion tokenizer with BPE hybrid fallback."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
        for sent in sentences:
            f.write(sent + '\n')
        temp_path = f.name
    try:
        builder = TokenizerBuilder(
            max_vocab_size=vocab_size,
            min_word_freq=1,
            min_phrase_freq=2,
            phrase_threshold=0.00001,
            max_phrase_layers=6,
            enable_bpe_fallback=True,
            bpe_vocab_size=vocab_size,
            take_needed=True,
        )
        builder.load_corpus(temp_path)
        builder.discover_phrases()
        return builder.build_tokenizer()
    finally:
        os.unlink(temp_path)


def analyze_token_distribution(tok: IonTokenizer, sentences: List[str], sample_size: int = 1000):
    """Analyze distribution of token types."""
    phrases = set(tok.token_classes.get("phrase", []))
    words = set(tok.token_classes.get("word", []))
    bpe_subwords = set(tok.token_classes.get("bpe_subword", []))

    counts = {"phrase": 0, "word": 0, "bpe_subword": 0, "character": 0}
    for sent in sentences[:sample_size]:
        ids = tok.encode(sent)
        for tid in ids:
            t = tok.id_to_token.get(tid, "")
            if t in phrases:
                counts["phrase"] += 1
            elif t in words:
                counts["word"] += 1
            elif t in bpe_subwords:
                counts["bpe_subword"] += 1
            else:
                counts["character"] += 1

    total = sum(counts.values()) or 1
    return {k: round(v / total * 100, 1) for k, v in counts.items()}


def benchmark_dataset(
    name: str,
    train_sentences: List[str],
    test_sentences: List[str],
    vocab_sizes: List[int],
    domain: str = "general",
) -> Dict[str, Any]:
    """Run full benchmark on a dataset."""
    print(f"\n{'='*70}")
    print(f"BENCHMARK: {name}")
    print(f"{'='*70}")
    print(f"  Train: {len(train_sentences):,} sentences")
    print(f"  Test:  {len(test_sentences):,} sentences")

    total_test_words = sum(len(s.split()) for s in test_sentences)
    total_test_chars = sum(len(s) for s in test_sentences)

    results = []
    for vocab_size in vocab_sizes:
        print(f"\n  Training vocab_size={vocab_size:,}...")
        sys.stdout.flush()

        # Train Ion
        t0 = time.time()
        ion_tok = train_ion_tokenizer(train_sentences, vocab_size, domain)
        ion_train_time = time.time() - t0

        # Train BPE
        t0 = time.time()
        bpe_tok = train_bpe_tokenizer(train_sentences, vocab_size)
        bpe_train_time = time.time() - t0

        # Encode test data
        t0 = time.time()
        ion_tokens = [len(ion_tok.encode(s)) for s in test_sentences]
        ion_encode_time = time.time() - t0

        t0 = time.time()
        bpe_tokens = [len(bpe_tok.encode(s).ids) for s in test_sentences]
        bpe_encode_time = time.time() - t0

        ion_total = sum(ion_tokens)
        bpe_total = sum(bpe_tokens)

        # Token distribution analysis
        dist = analyze_token_distribution(ion_tok, test_sentences)

        # Compute per-sentence statistics
        ratios = [b / max(i, 1) for i, b in zip(ion_tokens, bpe_tokens) if i > 0]
        median_ratio = statistics.median(ratios) if ratios else 1.0

        result = {
            "vocab_size": vocab_size,
            "ion_tokens": ion_total,
            "bpe_tokens": bpe_total,
            "ion_advantage_pct": round(((bpe_total - ion_total) / max(bpe_total, 1)) * 100, 2),
            "ion_chars_per_token": round(total_test_chars / max(ion_total, 1), 2),
            "bpe_chars_per_token": round(total_test_chars / max(bpe_total, 1), 2),
            "ion_words_per_token": round(total_test_words / max(ion_total, 1), 3),
            "bpe_words_per_token": round(total_test_words / max(bpe_total, 1), 3),
            "median_compression_ratio": round(median_ratio, 3),
            "ion_train_time_s": round(ion_train_time, 2),
            "bpe_train_time_s": round(bpe_train_time, 2),
            "ion_encode_time_s": round(ion_encode_time, 2),
            "bpe_encode_time_s": round(bpe_encode_time, 2),
            "ion_encode_toks_per_sec": round(ion_total / max(ion_encode_time, 0.001)),
            "bpe_encode_toks_per_sec": round(bpe_total / max(bpe_encode_time, 0.001)),
            "ion_phrases_count": len(ion_tok.token_classes.get("phrase", [])),
            "ion_words_count": len(ion_tok.token_classes.get("word", [])),
            "ion_actual_vocab": ion_tok.vocab_size(),
            "token_distribution": dist,
        }
        results.append(result)

        print(f"    Ion: {ion_total:,} tokens ({result['ion_chars_per_token']:.1f} c/t, {result['ion_words_per_token']:.3f} w/t)")
        print(f"    BPE: {bpe_total:,} tokens ({result['bpe_chars_per_token']:.1f} c/t, {result['bpe_words_per_token']:.3f} w/t)")
        print(f"    Ion advantage: {result['ion_advantage_pct']:+.1f}%")
        print(f"    Phrases: {result['ion_phrases_count']:,} | Token mix: "
              f"{dist['phrase']:.1f}% phrase, {dist['word']:.1f}% word, "
              f"{dist['bpe_subword']:.1f}% bpe, {dist['character']:.1f}% char")
        print(f"    Encode speed: Ion {result['ion_encode_toks_per_sec']:,}/s, BPE {result['bpe_encode_toks_per_sec']:,}/s")

    return {
        "dataset": name,
        "domain": domain,
        "train_size": len(train_sentences),
        "test_size": len(test_sentences),
        "total_test_words": total_test_words,
        "total_test_chars": total_test_chars,
        "results": results,
    }


# ============================================================================
# DATASET LOADERS
# ============================================================================

def load_wikitext(max_samples: int = 20000) -> List[str]:
    """Load WikiText-103 from HuggingFace."""
    print("Loading WikiText-103...")
    from datasets import load_dataset
    dataset = load_dataset("wikitext", "wikitext-103-v1", split="train")
    sentences = []
    for item in tqdm(dataset, desc="WikiText-103"):
        text = item.get("text", "")
        if text and len(text) > 50:
            for sent in text.replace("\n", " ").split(". "):
                sent = sent.strip()
                if 40 < len(sent) < 400 and sent[0].isalpha() and " " in sent:
                    sentences.append(sent + ".")
                if len(sentences) >= max_samples * 3:
                    break
        if len(sentences) >= max_samples * 3:
            break
    print(f"  Loaded {len(sentences):,} sentences")
    return sentences


def load_ag_news(max_samples: int = 20000) -> List[str]:
    """Load AG News from HuggingFace."""
    print("Loading AG News...")
    from datasets import load_dataset
    dataset = load_dataset("fancyzhx/ag_news", split="train")
    sentences = []
    for item in tqdm(dataset, desc="AG News"):
        text = item.get("text", "")
        if text and len(text) > 40:
            for sent in text.replace("\n", " ").split(". "):
                sent = sent.strip()
                if 30 < len(sent) < 400 and sent[0].isalpha() and " " in sent:
                    sentences.append(sent + ".")
                if len(sentences) >= max_samples * 3:
                    break
        if len(sentences) >= max_samples * 3:
            break
    print(f"  Loaded {len(sentences):,} sentences")
    return sentences


def generate_legal_corpus(n: int = 15000) -> List[str]:
    """Generate realistic legal text corpus."""
    random.seed(42)
    phrases = [
        "pursuant to", "in accordance with", "shall be deemed",
        "subject to the", "notwithstanding the", "with respect to",
        "in the event that", "for the purpose of", "in connection with",
        "at the time of", "on behalf of", "in lieu of",
        "terms and conditions", "rights and obligations", "representations and warranties",
        "indemnification and liability", "governing law and jurisdiction",
        "confidential information", "intellectual property", "force majeure",
        "due diligence", "breach of contract", "good faith",
        "reasonable efforts", "material adverse effect", "third party",
        "prior written consent", "effective date", "binding agreement",
    ]
    templates = [
        "The {party} shall, pursuant to Section {num}, provide {obj} in accordance with the {doc}.",
        "Notwithstanding the provisions of this {doc}, the {party} may exercise its rights and obligations.",
        "In the event that the {party} fails to comply with the terms and conditions herein, the {doc} shall be deemed void.",
        "Subject to the approval of the {party}, all confidential information shall remain protected.",
        "With respect to the intellectual property rights, the {party} grants a non-exclusive license.",
        "For the purpose of this {doc}, {phrase} shall be interpreted in accordance with governing law and jurisdiction.",
        "The {party} represents and warrants that it has the authority to enter into this binding agreement.",
        "In connection with the due diligence process, the {party} shall disclose all material adverse effects.",
        "At the time of execution, the {party} shall have obtained prior written consent from all third parties.",
        "The indemnification and liability provisions shall survive the termination of this {doc}.",
        "In lieu of monetary damages, the {party} may seek specific performance pursuant to applicable law.",
        "On behalf of the {party}, the authorized representative shall execute this {doc} on the effective date.",
        "The {party} acknowledges that breach of contract may result in irreparable harm requiring equitable relief.",
        "Reasonable efforts shall be made by the {party} to mitigate any force majeure event.",
        "The {party} agrees to act in good faith with respect to all {phrase} matters under this {doc}.",
    ]
    parties = ["Licensor", "Licensee", "Seller", "Buyer", "Employer", "Employee",
               "Landlord", "Tenant", "Company", "Contractor", "Client", "Vendor"]
    docs = ["Agreement", "Contract", "Covenant", "License", "Lease", "Memorandum"]
    objs = ["services", "products", "documentation", "deliverables", "consideration", "performance"]
    nums = ["3.1", "4.2", "5.7", "8.1", "12.4", "15.3", "2.6"]

    sentences = []
    for _ in range(n):
        t = random.choice(templates)
        sentences.append(t.format(
            party=random.choice(parties),
            doc=random.choice(docs),
            obj=random.choice(objs),
            num=random.choice(nums),
            phrase=random.choice(phrases),
        ))
    return sentences


def generate_scientific_corpus(n: int = 15000) -> List[str]:
    """Generate realistic scientific abstract corpus."""
    random.seed(43)
    phrases = [
        "et al", "results show", "compared to", "statistically significant",
        "in conclusion", "we propose", "state of the art", "we demonstrate",
        "as shown in", "in this paper", "previous work", "our approach",
        "experimental results", "we observe", "in contrast to", "on the other hand",
        "we evaluate", "baseline model", "training data", "test set",
        "cross validation", "mean squared error", "standard deviation",
        "confidence interval", "null hypothesis", "p value",
        "deep learning", "neural network", "gradient descent",
        "convolutional neural", "recurrent neural", "attention mechanism",
    ]
    templates = [
        "In this paper, we propose a novel approach to {topic} that achieves state of the art results.",
        "Our experimental results demonstrate that {method} outperforms the baseline model on {metric}.",
        "Compared to previous work (Smith et al, 2023), our approach achieves statistically significant improvements.",
        "We evaluate our method on the {dataset} training data and test set using cross validation.",
        "As shown in Table 1, the mean squared error with standard deviation of {num} indicates strong performance.",
        "The confidence interval for the {metric} suggests that we can reject the null hypothesis with p value {pval}.",
        "In contrast to existing deep learning methods, our neural network uses a novel attention mechanism.",
        "We observe that the convolutional neural architecture with gradient descent converges faster.",
        "The results show that {method} with recurrent neural layers improves {metric} by {num} percent.",
        "In conclusion, we demonstrate that our approach to {topic} advances the state of the art.",
        "Previous work on {topic} has focused on {method}, but we propose an alternative framework.",
        "On the other hand, the baseline model achieves comparable experimental results on smaller datasets.",
    ]
    topics = ["natural language processing", "computer vision", "speech recognition",
              "reinforcement learning", "transfer learning", "few shot learning",
              "semantic segmentation", "object detection", "text classification"]
    methods = ["transformer based model", "attention mechanism", "graph neural network",
               "variational autoencoder", "generative adversarial network", "contrastive learning"]
    metrics = ["accuracy", "F1 score", "BLEU score", "perplexity", "precision", "recall"]
    datasets = ["benchmark", "standard", "large scale", "curated", "annotated"]
    nums = ["2.3", "5.7", "0.8", "12.4", "3.1", "7.9"]
    pvals = ["0.001", "0.01", "0.05", "0.005"]

    sentences = []
    for _ in range(n):
        t = random.choice(templates)
        sentences.append(t.format(
            topic=random.choice(topics),
            method=random.choice(methods),
            metric=random.choice(metrics),
            dataset=random.choice(datasets),
            num=random.choice(nums),
            pval=random.choice(pvals),
        ))
    return sentences


def generate_conversational_corpus(n: int = 15000) -> List[str]:
    """Generate realistic conversational text."""
    random.seed(44)
    phrases = [
        "i think", "you know", "i mean", "going to", "want to",
        "do you", "have to", "kind of", "a lot of", "used to",
        "looking for", "trying to", "supposed to", "ended up",
        "turns out", "figured out", "came up with", "ran into",
        "got to", "how about", "what about", "by the way",
        "as far as", "long time", "right now", "real quick",
    ]
    templates = [
        "I think we should {verb} the {noun}, you know, because it would be a lot of work otherwise.",
        "Do you want to {verb} {obj}? I mean, I'm going to be there anyway.",
        "You know what, I kind of figured out how to {verb} the {noun} by the way.",
        "I'm looking for something that's supposed to {verb}, turns out it's hard to find.",
        "So I ended up trying to {verb} the {noun}, and I ran into some issues right now.",
        "How about we {verb} first? I used to do that a long time ago and it worked.",
        "As far as I know, they're going to {verb} the {noun} real quick before the deadline.",
        "I'm trying to {verb} but I have to {verb2} first, what about you?",
        "It turns out the {noun} is kind of {adj}, I think we should reconsider.",
        "Do you have to {verb} right now? I want to talk about the {noun} real quick.",
        "I came up with a way to {verb} the {noun}, you know, using a lot of {obj}.",
        "By the way, I got to {verb} yesterday, it was kind of {adj} if you know what I mean.",
    ]
    verbs = ["fix", "update", "check", "handle", "finish", "start", "review", "change"]
    verb2s = ["prepare", "organize", "clean up", "set up", "figure out", "work on"]
    nouns = ["project", "report", "system", "schedule", "budget", "presentation"]
    objs = ["resources", "time", "effort", "help", "materials", "ideas"]
    adjs = ["tricky", "interesting", "complicated", "straightforward", "unexpected", "helpful"]

    sentences = []
    for _ in range(n):
        t = random.choice(templates)
        sentences.append(t.format(
            verb=random.choice(verbs),
            verb2=random.choice(verb2s),
            noun=random.choice(nouns),
            obj=random.choice(objs),
            adj=random.choice(adjs),
        ))
    return sentences


# ============================================================================
# MAIN BENCHMARK
# ============================================================================

def run_realworld_benchmarks():
    """Run benchmarks across all datasets."""
    print("=" * 70)
    print("ION vs BPE: COMPREHENSIVE REAL-WORLD BENCHMARKS")
    print("=" * 70)
    print(f"Started: {datetime.now().isoformat()}")
    print()

    vocab_sizes = [10000, 20000, 32000]
    all_results = {}

    # 1. WikiText-103
    try:
        wiki_sents = load_wikitext(20000)
        if len(wiki_sents) >= 2000:
            random.seed(42)
            random.shuffle(wiki_sents)
            split = int(len(wiki_sents) * 0.8)
            all_results["wikitext103"] = benchmark_dataset(
                "WikiText-103 (Encyclopedic)",
                wiki_sents[:split], wiki_sents[split:],
                vocab_sizes, "wikipedia",
            )
    except Exception as e:
        print(f"WikiText-103 failed: {e}")

    # 2. AG News
    try:
        news_sents = load_ag_news(20000)
        if len(news_sents) >= 2000:
            random.seed(42)
            random.shuffle(news_sents)
            split = int(len(news_sents) * 0.8)
            all_results["ag_news"] = benchmark_dataset(
                "AG News (News Articles)",
                news_sents[:split], news_sents[split:],
                vocab_sizes, "general",
            )
    except Exception as e:
        print(f"AG News failed: {e}")

    # 3. Legal
    legal_sents = generate_legal_corpus(15000)
    random.seed(42)
    random.shuffle(legal_sents)
    split = int(len(legal_sents) * 0.8)
    all_results["legal"] = benchmark_dataset(
        "Legal Text (Contracts & Agreements)",
        legal_sents[:split], legal_sents[split:],
        vocab_sizes, "legal",
    )

    # 4. Scientific
    sci_sents = generate_scientific_corpus(15000)
    random.seed(42)
    random.shuffle(sci_sents)
    split = int(len(sci_sents) * 0.8)
    all_results["scientific"] = benchmark_dataset(
        "Scientific Abstracts (Research Papers)",
        sci_sents[:split], sci_sents[split:],
        vocab_sizes, "scientific",
    )

    # 5. Conversational
    chat_sents = generate_conversational_corpus(15000)
    random.seed(42)
    random.shuffle(chat_sents)
    split = int(len(chat_sents) * 0.8)
    all_results["conversational"] = benchmark_dataset(
        "Conversational Text (Chat/Dialogue)",
        chat_sents[:split], chat_sents[split:],
        vocab_sizes, "chat",
    )

    # ===== GRAND SUMMARY =====
    print("\n" + "=" * 70)
    print("GRAND SUMMARY: ION vs BPE ACROSS ALL DOMAINS")
    print("=" * 70)

    print(f"\n{'Dataset':<30} {'Vocab':>8} {'Ion':>10} {'BPE':>10} {'Advantage':>10} {'Phrase%':>8} {'BPE%':>6}")
    print("-" * 85)

    summary_advantages = []

    for ds_name, ds_data in all_results.items():
        for r in ds_data["results"]:
            advantage = r["ion_advantage_pct"]
            summary_advantages.append(advantage)
            dist = r["token_distribution"]
            print(f"{ds_data['dataset'][:29]:<30} {r['vocab_size']:>8,} "
                  f"{r['ion_tokens']:>10,} {r['bpe_tokens']:>10,} "
                  f"{advantage:>+9.1f}% {dist['phrase']:>7.1f}% {dist['bpe_subword']:>5.1f}%")

    if summary_advantages:
        avg_adv = statistics.mean(summary_advantages)
        min_adv = min(summary_advantages)
        max_adv = max(summary_advantages)
        print("-" * 85)
        print(f"{'OVERALL':>30} {'Avg':>8} {'':>10} {'':>10} {avg_adv:>+9.1f}% {'Min':>7} {min_adv:>+5.1f}%")
        print(f"{'':>30} {'':>8} {'':>10} {'':>10} {'':>10} {'Max':>7} {max_adv:>+5.1f}%")

    # Save results
    output = {
        "metadata": {
            "timestamp": datetime.now().isoformat(),
            "methodology": "Both tokenizers trained on same corpus, tested on held-out data. Ion uses BPE hybrid fallback.",
            "vocab_sizes_tested": vocab_sizes,
            "datasets": list(all_results.keys()),
        },
        "datasets": all_results,
        "summary": {
            "average_advantage_pct": round(statistics.mean(summary_advantages), 2) if summary_advantages else 0,
            "min_advantage_pct": round(min(summary_advantages), 2) if summary_advantages else 0,
            "max_advantage_pct": round(max(summary_advantages), 2) if summary_advantages else 0,
            "total_benchmarks": len(summary_advantages),
        }
    }

    results_path = Path(__file__).parent / "benchmark_realworld_results.json"
    with open(results_path, "w") as f:
        json.dump(output, f, indent=2)

    print(f"\nResults saved to: {results_path}")
    print(f"Completed: {datetime.now().isoformat()}")

    return output


if __name__ == "__main__":
    results = run_realworld_benchmarks()
