#!/usr/bin/env python3
"""
Comprehensive benchmark study: Ion vs BPE tokenization.

FAIR COMPARISON METHODOLOGY:
1. Generate/load a corpus with realistic phrase patterns
2. Train BOTH Ion and BPE on the SAME training data
3. Test BOTH on the SAME test data
4. Compare token counts, compression ratios, and efficiency

This ensures vocabulary coverage is comparable between approaches.
"""

import os
import sys
import json
import time
import tempfile
import statistics
import random
from pathlib import Path
from collections import Counter
from typing import List, Dict, Any, Tuple
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent.parent))

from tqdm import tqdm
from tokenizers import Tokenizer
from tokenizers.models import BPE
from tokenizers.trainers import BpeTrainer
from tokenizers.pre_tokenizers import Whitespace

from ion.builder import TokenizerBuilder
from ion.tokenizer import IonTokenizer


VOCAB_SIZES = [5000, 10000, 20000, 32000]


def generate_realistic_corpus(n_sentences: int = 50000) -> List[str]:
    """Generate a corpus with realistic phrase patterns for benchmarking."""

    # Common multi-word expressions (phrases Ion should capture)
    phrases = [
        "united states", "united kingdom", "european union", "new york",
        "according to", "in order to", "as well as", "such as",
        "one of the", "some of the", "most of the", "all of the",
        "in addition to", "in accordance with", "with respect to",
        "on the other hand", "at the same time", "for the first time",
        "the fact that", "in terms of", "as a result",
        "machine learning", "artificial intelligence", "data science",
        "climate change", "human rights", "public health",
        "world war", "cold war", "civil war",
        "high school", "middle school", "elementary school",
        "last year", "next year", "this year",
        "first time", "second time", "every time",
        "long time", "short time", "same time",
        "good morning", "good evening", "good night",
        "thank you", "excuse me", "i think",
        "you know", "i mean", "of course",
    ]

    templates = [
        "The {noun} of the {noun2} was {adj} according to the report.",
        "In the {place}, many people believe that {phrase} is important.",
        "According to {source}, the {noun} has {verb} significantly.",
        "One of the most {adj} aspects of {topic} is the {noun}.",
        "The {org} announced that {phrase} would be implemented.",
        "As a result of the {noun}, the {noun2} has {verb}.",
        "In terms of {topic}, the {noun} is considered {adj}.",
        "The study found that {phrase} leads to better outcomes.",
        "For the first time, researchers have {verb} the {noun}.",
        "At the same time, the {noun} continued to {verb}.",
        "With respect to {topic}, experts suggest that {phrase}.",
        "The {adj} {noun} demonstrates the importance of {topic}.",
        "In order to {verb} the {noun}, one must understand {topic}.",
        "Some of the {noun} were {adj}, while others were not.",
        "The fact that {phrase} is significant cannot be ignored.",
        "On the other hand, the {noun} also shows {adj} results.",
        "As well as the {noun}, the {noun2} played a crucial role.",
        "The {place} is known for its {adj} {noun} and {noun2}.",
        "In addition to {topic}, the research examined {noun}.",
        "Most of the {noun} in the {place} are {adj}.",
    ]

    nouns = ["system", "process", "study", "research", "development", "analysis",
             "method", "approach", "model", "framework", "structure", "policy",
             "result", "outcome", "finding", "conclusion", "evidence", "data",
             "change", "growth", "decline", "increase", "improvement", "progress",
             "problem", "issue", "challenge", "solution", "strategy", "plan"]

    adjs = ["significant", "important", "major", "key", "critical", "essential",
            "new", "recent", "current", "future", "past", "traditional",
            "large", "small", "high", "low", "strong", "weak",
            "positive", "negative", "different", "similar", "various", "specific"]

    verbs = ["increased", "decreased", "improved", "developed", "changed",
             "demonstrated", "showed", "indicated", "revealed", "suggested",
             "examined", "analyzed", "studied", "investigated", "explored"]

    places = ["United States", "European Union", "United Kingdom", "New York",
              "the region", "the country", "the city", "the world"]

    sources = ["the study", "recent research", "the report", "experts",
               "the data", "the analysis", "the findings", "scientists"]

    orgs = ["the government", "the organization", "the company", "the university",
            "the institute", "the committee", "the agency", "the council"]

    topics = ["climate change", "public health", "machine learning",
              "economic growth", "social development", "education reform",
              "data science", "artificial intelligence", "human rights"]

    sentences = []
    for _ in range(n_sentences):
        template = random.choice(templates)
        phrase = random.choice(phrases)

        sent = template.format(
            noun=random.choice(nouns),
            noun2=random.choice(nouns),
            adj=random.choice(adjs),
            verb=random.choice(verbs),
            place=random.choice(places),
            source=random.choice(sources),
            org=random.choice(orgs),
            topic=random.choice(topics),
            phrase=phrase,
        )
        sentences.append(sent)

    return sentences


def train_bpe_tokenizer(sentences: List[str], vocab_size: int) -> Tokenizer:
    """Train a BPE tokenizer on the given sentences."""
    # Write sentences to temp file (tokenizers library needs files)
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
        for sent in sentences:
            f.write(sent + '\n')
        temp_path = f.name

    try:
        tokenizer = Tokenizer(BPE(unk_token="[UNK]"))
        tokenizer.pre_tokenizer = Whitespace()

        trainer = BpeTrainer(
            vocab_size=vocab_size,
            special_tokens=["[UNK]", "[PAD]", "[CLS]", "[SEP]", "[MASK]"],
            min_frequency=2,
        )

        tokenizer.train([temp_path], trainer)
        return tokenizer
    finally:
        os.unlink(temp_path)


def train_ion_tokenizer(sentences: List[str], vocab_size: int) -> IonTokenizer:
    """Train an Ion tokenizer on the given sentences."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
        for sent in sentences:
            f.write(sent + '\n')
        temp_path = f.name

    try:
        builder = TokenizerBuilder(
            max_vocab_size=vocab_size,
            min_word_freq=1,  # Include all words seen in training
            min_phrase_freq=2,
        )
        builder.load_corpus(temp_path)
        builder.discover_phrases()
        return builder.build_tokenizer()
    finally:
        os.unlink(temp_path)


def benchmark_tokenizers(
    train_sentences: List[str],
    test_sentences: List[str],
    vocab_size: int,
) -> Dict[str, Any]:
    """Run benchmark comparing Ion vs BPE at a given vocab size."""

    print(f"\n  Training tokenizers (vocab_size={vocab_size:,})...")

    # Train both tokenizers
    t0 = time.time()
    ion_tok = train_ion_tokenizer(train_sentences, vocab_size)
    ion_train_time = time.time() - t0

    t0 = time.time()
    bpe_tok = train_bpe_tokenizer(train_sentences, vocab_size)
    bpe_train_time = time.time() - t0

    # Count original words
    total_words = sum(len(s.split()) for s in test_sentences)
    total_chars = sum(len(s) for s in test_sentences)

    # Tokenize test data with both
    ion_tokens = []
    bpe_tokens = []

    print(f"  Tokenizing {len(test_sentences):,} test sentences...")

    t0 = time.time()
    for sent in test_sentences:
        ids = ion_tok.encode(sent)
        ion_tokens.append(len(ids))
    ion_encode_time = time.time() - t0

    t0 = time.time()
    for sent in test_sentences:
        output = bpe_tok.encode(sent)
        bpe_tokens.append(len(output.ids))
    bpe_encode_time = time.time() - t0

    ion_total = sum(ion_tokens)
    bpe_total = sum(bpe_tokens)

    # Analyze Ion token distribution
    phrase_tokens = 0
    word_tokens = 0
    fallback_tokens = 0

    phrases = set(ion_tok.token_classes.get("phrase", []))
    words = set(ion_tok.token_classes.get("word", []))

    for sent in test_sentences[:1000]:  # Sample for speed
        ids = ion_tok.encode(sent)
        for tid in ids:
            tok = ion_tok.id_to_token.get(tid, "")
            if tok in phrases:
                phrase_tokens += 1
            elif tok in words:
                word_tokens += 1
            else:
                fallback_tokens += 1

    token_sample_total = phrase_tokens + word_tokens + fallback_tokens

    return {
        "vocab_size": vocab_size,
        "train_sentences": len(train_sentences),
        "test_sentences": len(test_sentences),
        "total_words": total_words,
        "total_chars": total_chars,

        # Token counts
        "ion_tokens": ion_total,
        "bpe_tokens": bpe_total,

        # Compression ratios (chars per token - higher is better)
        "ion_chars_per_token": round(total_chars / max(ion_total, 1), 2),
        "bpe_chars_per_token": round(total_chars / max(bpe_total, 1), 2),

        # Words per token (higher is better - more compression)
        "ion_words_per_token": round(total_words / max(ion_total, 1), 3),
        "bpe_words_per_token": round(total_words / max(bpe_total, 1), 3),

        # Advantage calculation (positive = Ion wins)
        "ion_advantage_pct": round(((bpe_total - ion_total) / bpe_total) * 100, 2),

        # Timing
        "ion_train_time": round(ion_train_time, 2),
        "bpe_train_time": round(bpe_train_time, 2),
        "ion_encode_time": round(ion_encode_time, 2),
        "bpe_encode_time": round(bpe_encode_time, 2),

        # Ion vocab composition
        "ion_actual_vocab": ion_tok.vocab_size(),
        "ion_phrases": len(ion_tok.token_classes.get("phrase", [])),
        "ion_words": len(ion_tok.token_classes.get("word", [])),

        # Token type distribution (from sample)
        "ion_phrase_usage_pct": round((phrase_tokens / max(token_sample_total, 1)) * 100, 1),
        "ion_word_usage_pct": round((word_tokens / max(token_sample_total, 1)) * 100, 1),
        "ion_fallback_usage_pct": round((fallback_tokens / max(token_sample_total, 1)) * 100, 1),
    }


def run_full_benchmark():
    """Run complete benchmark suite."""
    print("=" * 70)
    print("ION vs BPE COMPREHENSIVE BENCHMARK")
    print("=" * 70)
    print(f"Started: {datetime.now().isoformat()}")
    print()

    # Generate corpus
    print("Generating realistic test corpus...")
    all_sentences = generate_realistic_corpus(60000)

    # Split into train/test
    random.shuffle(all_sentences)
    train_sentences = all_sentences[:50000]
    test_sentences = all_sentences[50000:]

    print(f"  Training set: {len(train_sentences):,} sentences")
    print(f"  Test set: {len(test_sentences):,} sentences")

    results = []

    for vocab_size in VOCAB_SIZES:
        result = benchmark_tokenizers(train_sentences, test_sentences, vocab_size)
        results.append(result)

        print(f"\n  Results for vocab_size={vocab_size:,}:")
        print(f"    Ion: {result['ion_tokens']:,} tokens ({result['ion_chars_per_token']:.1f} chars/tok)")
        print(f"    BPE: {result['bpe_tokens']:,} tokens ({result['bpe_chars_per_token']:.1f} chars/tok)")
        print(f"    Ion advantage: {result['ion_advantage_pct']:+.1f}%")
        print(f"    Ion phrase usage: {result['ion_phrase_usage_pct']:.1f}%")
        print(f"    Ion fallback: {result['ion_fallback_usage_pct']:.1f}%")

    # Save results
    output = {
        "metadata": {
            "timestamp": datetime.now().isoformat(),
            "methodology": "Both tokenizers trained on same corpus, tested on held-out data",
            "train_size": len(train_sentences),
            "test_size": len(test_sentences),
        },
        "results": results,
    }

    results_path = Path(__file__).parent / "benchmark_results.json"
    with open(results_path, "w") as f:
        json.dump(output, f, indent=2)

    # Print summary
    print("\n" + "=" * 70)
    print("SUMMARY")
    print("=" * 70)

    print("\nVocab Size | Ion Tokens | BPE Tokens | Ion Advantage | Phrase Usage")
    print("-" * 70)
    for r in results:
        print(f"{r['vocab_size']:>10,} | {r['ion_tokens']:>10,} | {r['bpe_tokens']:>10,} | "
              f"{r['ion_advantage_pct']:>+12.1f}% | {r['ion_phrase_usage_pct']:>11.1f}%")

    avg_advantage = statistics.mean(r['ion_advantage_pct'] for r in results)
    print("-" * 70)
    print(f"{'Average':>10} | {'-':>10} | {'-':>10} | {avg_advantage:>+12.1f}% |")

    print(f"\nResults saved to: {results_path}")

    return results


if __name__ == "__main__":
    results = run_full_benchmark()
