#!/usr/bin/env python3
"""
Wikipedia benchmark: Ion vs BPE on real-world text.
Uses HuggingFace wikipedia dataset for proper large-scale testing.
"""

import os
import sys
import json
import time
import tempfile
import random
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any

sys.path.insert(0, str(Path(__file__).parent.parent))

from tqdm import tqdm
from tokenizers import Tokenizer
from tokenizers.models import BPE
from tokenizers.trainers import BpeTrainer
from tokenizers.pre_tokenizers import Whitespace

from ion.builder import TokenizerBuilder
from ion.tokenizer import IonTokenizer


def train_bpe_tokenizer(sentences: List[str], vocab_size: int) -> Tokenizer:
    """Train a BPE tokenizer on the given sentences."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
        for sent in sentences:
            f.write(sent + '\n')
        temp_path = f.name

    try:
        tokenizer = Tokenizer(BPE(unk_token="[UNK]"))
        tokenizer.pre_tokenizer = Whitespace()

        trainer = BpeTrainer(
            vocab_size=vocab_size,
            special_tokens=["[UNK]", "[PAD]", "[CLS]", "[SEP]", "[MASK]"],
            min_frequency=2,
        )

        tokenizer.train([temp_path], trainer)
        return tokenizer
    finally:
        os.unlink(temp_path)


def train_ion_tokenizer(sentences: List[str], vocab_size: int, enable_bpe: bool = True) -> IonTokenizer:
    """Train an Ion tokenizer with aggressive phrase discovery."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
        for sent in sentences:
            f.write(sent + '\n')
        temp_path = f.name

    try:
        builder = TokenizerBuilder(
            max_vocab_size=vocab_size,
            min_word_freq=1,
            min_phrase_freq=2,  # Low threshold - find more phrases
            phrase_threshold=0.00001,  # Even lower PMI threshold for more phrases
            max_phrase_layers=6,  # Allow longer n-grams
            enable_bpe_fallback=enable_bpe,
            bpe_vocab_size=vocab_size,
            take_needed=True,  # Include ALL discovered phrases and ALL words
        )
        builder.load_corpus(temp_path)
        builder.discover_phrases()
        tok = builder.build_tokenizer()

        # Print phrase stats
        phrases = builder.phrases
        print(f"    Discovered {len(phrases)} phrases")
        if phrases:
            print(f"    Top 20 phrases: {phrases[:20]}")
            # Print some longer phrases (3+ words)
            long_phrases = [p for p in phrases if len(p.split()) >= 3][:10]
            if long_phrases:
                print(f"    Long phrases (3+ words): {long_phrases}")

        return tok
    finally:
        os.unlink(temp_path)


def load_wikipedia_from_hf(max_samples: int = 50000) -> List[str]:
    """Load Wikipedia-derived text from HuggingFace datasets."""
    print(f"Loading text from HuggingFace (max {max_samples:,} articles)...")

    from datasets import load_dataset

    # Try multiple Wikipedia-derived datasets
    datasets_to_try = [
        ("wikitext", "wikitext-103-v1", "train", "text"),
        ("bookcorpus", None, "train", "text"),
        ("ag_news", None, "train", "text"),
    ]

    sentences = []

    for ds_name, ds_config, ds_split, text_field in datasets_to_try:
        if len(sentences) >= max_samples * 3:
            break

        try:
            print(f"  Trying {ds_name}...")
            if ds_config:
                dataset = load_dataset(ds_name, ds_config, split=ds_split)
            else:
                dataset = load_dataset(ds_name, split=ds_split)

            for item in tqdm(dataset, desc=f"Loading {ds_name}"):
                text = item.get(text_field, "")
                if text and len(text) > 50:
                    # Split into sentences
                    for sent in text.replace("\n", " ").split(". "):
                        sent = sent.strip()
                        # Filter: reasonable length, starts with letter, has spaces
                        if (len(sent) > 40 and len(sent) < 400
                            and sent[0].isalpha() and " " in sent):
                            sentences.append(sent + ".")

                        if len(sentences) >= max_samples * 5:
                            break

                if len(sentences) >= max_samples * 5:
                    break

            print(f"  Got {len(sentences):,} sentences from {ds_name}")

        except Exception as e:
            print(f"  Failed to load {ds_name}: {e}")
            continue

    print(f"Total: {len(sentences):,} sentences")
    return sentences


def benchmark_on_wikipedia(
    train_sentences: List[str],
    test_sentences: List[str],
    vocab_size: int,
    enable_bpe_fallback: bool = True,
) -> Dict[str, Any]:
    """Run benchmark comparing Ion vs BPE."""

    mode = "hybrid" if enable_bpe_fallback else "character"
    print(f"\n  Training tokenizers (vocab_size={vocab_size:,}, mode={mode})...")
    sys.stdout.flush()

    # Train both tokenizers
    t0 = time.time()
    ion_tok = train_ion_tokenizer(train_sentences, vocab_size, enable_bpe=enable_bpe_fallback)
    ion_train_time = time.time() - t0

    t0 = time.time()
    bpe_tok = train_bpe_tokenizer(train_sentences, vocab_size)
    bpe_train_time = time.time() - t0

    # Stats
    total_words = sum(len(s.split()) for s in test_sentences)
    total_chars = sum(len(s) for s in test_sentences)

    print(f"  Tokenizing {len(test_sentences):,} test sentences...")
    sys.stdout.flush()

    # Tokenize
    t0 = time.time()
    ion_tokens = [len(ion_tok.encode(sent)) for sent in test_sentences]
    ion_encode_time = time.time() - t0

    t0 = time.time()
    bpe_tokens = [len(bpe_tok.encode(sent).ids) for sent in test_sentences]
    bpe_encode_time = time.time() - t0

    ion_total = sum(ion_tokens)
    bpe_total = sum(bpe_tokens)

    # Analyze token distribution
    phrase_tokens = 0
    word_tokens = 0
    bpe_subword_tokens = 0
    char_tokens = 0

    phrases = set(ion_tok.token_classes.get("phrase", []))
    words = set(ion_tok.token_classes.get("word", []))
    bpe_subwords = set(ion_tok.token_classes.get("bpe_subword", []))

    for sent in test_sentences[:1000]:  # Sample for speed
        ids = ion_tok.encode(sent)
        for tid in ids:
            tok = ion_tok.id_to_token.get(tid, "")
            if tok in phrases:
                phrase_tokens += 1
            elif tok in words:
                word_tokens += 1
            elif tok in bpe_subwords or tok.startswith("<bpe:"):
                bpe_subword_tokens += 1
            else:
                char_tokens += 1

    token_total = phrase_tokens + word_tokens + bpe_subword_tokens + char_tokens

    return {
        "vocab_size": vocab_size,
        "train_sentences": len(train_sentences),
        "test_sentences": len(test_sentences),
        "total_words": total_words,
        "total_chars": total_chars,
        "ion_tokens": ion_total,
        "bpe_tokens": bpe_total,
        "ion_chars_per_token": round(total_chars / max(ion_total, 1), 2),
        "bpe_chars_per_token": round(total_chars / max(bpe_total, 1), 2),
        "ion_advantage_pct": round(((bpe_total - ion_total) / bpe_total) * 100, 2),
        "ion_train_time": round(ion_train_time, 2),
        "bpe_train_time": round(bpe_train_time, 2),
        "ion_phrases_discovered": len(ion_tok.token_classes.get("phrase", [])),
        "ion_phrase_usage_pct": round((phrase_tokens / max(token_total, 1)) * 100, 1),
        "ion_word_usage_pct": round((word_tokens / max(token_total, 1)) * 100, 1),
        "ion_bpe_subword_pct": round((bpe_subword_tokens / max(token_total, 1)) * 100, 1),
        "ion_char_fallback_pct": round((char_tokens / max(token_total, 1)) * 100, 1),
    }


def run_wikipedia_benchmark():
    """Run the full Wikipedia benchmark."""
    print("=" * 70)
    print("ION vs BPE: WIKIPEDIA BENCHMARK (HuggingFace Dataset)")
    print("=" * 70)
    print(f"Started: {datetime.now().isoformat()}")
    print()

    # Load Wikipedia
    all_sentences = load_wikipedia_from_hf(max_samples=10000)

    if len(all_sentences) < 1000:
        print("ERROR: Not enough sentences loaded.")
        return None

    # Shuffle and split 80/20
    random.seed(42)
    random.shuffle(all_sentences)
    split = int(len(all_sentences) * 0.8)
    train_sentences = all_sentences[:split]
    test_sentences = all_sentences[split:]

    print(f"\nTrain: {len(train_sentences):,} sentences")
    print(f"Test: {len(test_sentences):,} sentences")

    # Benchmark
    results = []
    for vocab_size in [10000, 32000]:
        result = benchmark_on_wikipedia(train_sentences, test_sentences, vocab_size)
        results.append(result)

        print(f"\n  Results (vocab={vocab_size:,}):")
        print(f"    Ion: {result['ion_tokens']:,} tokens ({result['ion_chars_per_token']:.1f} c/t)")
        print(f"    BPE: {result['bpe_tokens']:,} tokens ({result['bpe_chars_per_token']:.1f} c/t)")
        print(f"    Ion advantage: {result['ion_advantage_pct']:+.1f}%")
        print(f"    Phrases discovered: {result['ion_phrases_discovered']:,}")
        print(f"    Token mix: {result['ion_phrase_usage_pct']:.1f}% phrase, "
              f"{result['ion_word_usage_pct']:.1f}% word, "
              f"{result['ion_bpe_subword_pct']:.1f}% BPE, "
              f"{result['ion_char_fallback_pct']:.1f}% char")

    # Save
    output = {
        "metadata": {
            "timestamp": datetime.now().isoformat(),
            "source": "HuggingFace wikipedia/20220301.en",
            "train_size": len(train_sentences),
            "test_size": len(test_sentences),
        },
        "results": results,
    }
    results_path = Path(__file__).parent / "benchmark_wikipedia_results.json"
    with open(results_path, "w") as f:
        json.dump(output, f, indent=2)

    # Summary
    print("\n" + "=" * 70)
    print("SUMMARY")
    print("=" * 70)
    print("\nVocab    | Ion Tokens | BPE Tokens | Advantage | Phrases | Phrase% | BPE%")
    print("-" * 80)
    for r in results:
        print(f"{r['vocab_size']:>8,} | {r['ion_tokens']:>10,} | {r['bpe_tokens']:>10,} | "
              f"{r['ion_advantage_pct']:>+8.1f}% | {r['ion_phrases_discovered']:>7,} | "
              f"{r['ion_phrase_usage_pct']:>6.1f}% | {r['ion_bpe_subword_pct']:>4.1f}%")

    print(f"\nResults saved to: {results_path}")
    return results


if __name__ == "__main__":
    results = run_wikipedia_benchmark()
