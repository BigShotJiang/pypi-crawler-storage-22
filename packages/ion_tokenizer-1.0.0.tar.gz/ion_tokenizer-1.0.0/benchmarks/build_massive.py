#!/usr/bin/env python3
"""Build the largest possible Ion tokenizer from major HuggingFace datasets.

Tests: Wikipedia, FineWeb-Edu, BookCorpus, C4, OpenWebText
Measures maximum sequence length reduction achievable with Ion's phrase-first architecture.
"""

import json
import os
import sys
import time
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from tqdm import tqdm
from ion.builder import TokenizerBuilder
from ion.corpus import load_corpus, load_spacy_tokenizer
from ion.tokenizer import IonTokenizer, EXTENDED_ALPHABET


# Datasets to test - ordered by expected diversity/size
DATASETS = [
    {
        "name": "Wikipedia (wikimedia/wikipedia, 20231101.en)",
        "source": "wikimedia/wikipedia",
        "hf_config": "20231101.en",
        "hf_split": "train",
        "hf_text_field": "text",
        "max_samples": 500_000,
        "domain": "wikipedia",
    },
    {
        "name": "FineWeb-Edu (sample-10BT)",
        "source": "HuggingFaceFW/fineweb-edu-score-2",
        "hf_config": "default",
        "hf_split": "train",
        "hf_text_field": "text",
        "max_samples": 500_000,
        "domain": "general",
    },
    {
        "name": "OpenWebText",
        "source": "Skylion007/openwebtext",
        "hf_config": None,
        "hf_split": "train",
        "hf_text_field": "text",
        "max_samples": 500_000,
        "domain": "general",
    },
]

# Configurations to test
CONFIGS = [
    {
        "name": "Massive TN (Take-Needed, All Phrases+Words)",
        "max_vocab_size": 500_000,
        "take_needed": True,
        "min_phrase_freq": 2,
        "phrase_threshold": 0.0005,
        "max_phrase_layers": 6,
        "fallback_mode": "newword",
        "max_sentences": 5_000_000,
    },
    {
        "name": "Large Vocab 200K (Standard, BPE fallback)",
        "max_vocab_size": 200_000,
        "take_needed": False,
        "min_phrase_freq": 3,
        "phrase_threshold": 0.001,
        "max_phrase_layers": 5,
        "fallback_mode": "bpe",
        "max_sentences": 5_000_000,
    },
    {
        "name": "Ultra-Deep Phrases (6 layers, low threshold)",
        "max_vocab_size": 100_000,
        "take_needed": False,
        "min_phrase_freq": 2,
        "phrase_threshold": 0.0001,
        "max_phrase_layers": 6,
        "fallback_mode": "newword",
        "max_sentences": 5_000_000,
    },
]


def load_dataset_sentences(ds_config, max_sentences=5_000_000):
    """Load sentences from a dataset config."""
    print(f"\n{'='*70}")
    print(f"Loading: {ds_config['name']}")
    print(f"{'='*70}")

    sentences = []
    word_freq = Counter()
    count = 0
    start = time.time()

    try:
        for sent in tqdm(
            load_corpus(
                ds_config["source"],
                hf_split=ds_config["hf_split"],
                hf_text_field=ds_config["hf_text_field"],
                hf_config=ds_config.get("hf_config"),
                max_samples=ds_config.get("max_samples"),
            ),
            desc=f"Loading {ds_config['name']}",
        ):
            sentences.append(sent)
            for tok in sent:
                word_freq[tok] += 1
            count += 1
            if count >= max_sentences:
                break
            if count % 500_000 == 0:
                elapsed = time.time() - start
                print(f"  ... {count:,} sentences loaded ({elapsed:.0f}s)")
    except Exception as e:
        print(f"  ERROR loading {ds_config['name']}: {e}")
        print(f"  Continuing with {len(sentences):,} sentences loaded so far...")

    elapsed = time.time() - start
    total_tokens = sum(len(s) for s in sentences)
    unique_words = len(word_freq)

    print(f"\n  Loaded: {len(sentences):,} sentences")
    print(f"  Total tokens: {total_tokens:,}")
    print(f"  Unique words: {unique_words:,}")
    print(f"  Time: {elapsed:.1f}s")

    return sentences, word_freq


def build_and_measure(sentences, word_freq, config, dataset_name):
    """Build tokenizer with given config and measure compression."""
    print(f"\n  Config: {config['name']}")
    print(f"  Vocab target: {config['max_vocab_size']:,}")
    print(f"  Take-needed: {config['take_needed']}")
    print(f"  Fallback: {config['fallback_mode']}")
    print(f"  Phrase layers: {config['max_phrase_layers']}")
    print(f"  Phrase threshold: {config['phrase_threshold']}")

    start = time.time()

    builder = TokenizerBuilder(
        max_vocab_size=config["max_vocab_size"],
        min_word_freq=1,
        min_phrase_freq=config["min_phrase_freq"],
        phrase_threshold=config["phrase_threshold"],
        max_phrase_layers=config["max_phrase_layers"],
        max_sentences=config["max_sentences"],
        take_needed=config["take_needed"],
        enable_bpe_fallback=(config["fallback_mode"] == "bpe"),
        fallback_mode=config["fallback_mode"],
    )

    # Inject pre-loaded data
    builder.sentences = sentences
    builder.word_freq = word_freq
    builder.stats["total_sentences"] = len(sentences)
    builder.stats["total_tokens_original"] = sum(len(s) for s in sentences)

    print("  Discovering phrases...")
    builder.discover_phrases()

    print(f"  Phrases discovered: {len(builder.phrases):,}")
    print(f"  Words included: {len(builder.words):,}")

    print("  Building tokenizer...")
    tok = builder.build_tokenizer()
    build_time = time.time() - start

    print(f"  Final vocab size: {tok.vocab_size():,}")
    print(f"  Build time: {build_time:.1f}s")

    # Measure compression on test samples
    print("  Measuring compression...")
    test_sentences = sentences[:50_000]
    original_tokens = 0
    compressed_tokens = 0

    for sent in tqdm(test_sentences, desc="  Encoding"):
        text = " ".join(sent)
        original_tokens += len(sent)
        encoded = tok.encode(text)
        compressed_tokens += len(encoded)

    if original_tokens > 0:
        reduction_pct = (original_tokens - compressed_tokens) / original_tokens * 100
        ratio = original_tokens / max(compressed_tokens, 1)
    else:
        reduction_pct = 0
        ratio = 1.0

    result = {
        "dataset": dataset_name,
        "config": config["name"],
        "vocab_size": tok.vocab_size(),
        "phrases": len(tok.token_classes["phrase"]),
        "words": len(tok.token_classes["word"]),
        "bpe_subwords": len(tok.token_classes.get("bpe_subword", [])),
        "sentences_loaded": len(sentences),
        "test_sentences": len(test_sentences),
        "original_tokens": original_tokens,
        "compressed_tokens": compressed_tokens,
        "reduction_pct": round(reduction_pct, 2),
        "compression_ratio": round(ratio, 3),
        "build_time_s": round(build_time, 1),
        "fallback_mode": config["fallback_mode"],
        "take_needed": config["take_needed"],
        "phrase_layers": config["max_phrase_layers"],
        "phrase_threshold": config["phrase_threshold"],
    }

    print(f"\n  {'='*50}")
    print(f"  RESULT: {reduction_pct:.2f}% sequence length reduction")
    print(f"  RESULT: {ratio:.3f}x compression ratio")
    print(f"  RESULT: {compressed_tokens:,} tokens from {original_tokens:,} words")
    print(f"  {'='*50}")

    # Save the tokenizer if it's the best so far
    safe_name = dataset_name.replace(" ", "_").replace("(", "").replace(")", "").lower()
    config_name = config["name"].replace(" ", "_").replace("(", "").replace(")", "").replace(",", "").lower()
    output_path = f"/home/user/ion/benchmarks/massive_{safe_name}_{config_name}.json"
    try:
        import orjson
        Path(output_path).write_bytes(orjson.dumps(tok.to_dict(), option=orjson.OPT_INDENT_2))
        result["tokenizer_path"] = output_path
        print(f"  Saved tokenizer to: {output_path}")
    except Exception as e:
        print(f"  Warning: Could not save tokenizer: {e}")

    return result


def main():
    print("="*70)
    print("ION MASSIVE TOKENIZER BUILD")
    print("Finding maximum sequence length reduction across human domains")
    print("="*70)
    print(f"Datasets: {len(DATASETS)}")
    print(f"Configs: {len(CONFIGS)}")
    print(f"Total builds: {len(DATASETS) * len(CONFIGS)}")
    print()

    all_results = []
    best_result = None

    for ds_config in DATASETS:
        try:
            sentences, word_freq = load_dataset_sentences(
                ds_config, max_sentences=5_000_000
            )

            if not sentences:
                print(f"  Skipping {ds_config['name']} - no data loaded")
                continue

            for config in CONFIGS:
                try:
                    result = build_and_measure(
                        sentences, word_freq, config, ds_config["name"]
                    )
                    all_results.append(result)

                    if best_result is None or result["reduction_pct"] > best_result["reduction_pct"]:
                        best_result = result

                except Exception as e:
                    print(f"  ERROR building with config '{config['name']}': {e}")
                    import traceback
                    traceback.print_exc()

        except Exception as e:
            print(f"ERROR loading dataset '{ds_config['name']}': {e}")
            import traceback
            traceback.print_exc()

    # Final summary
    print("\n" + "="*70)
    print("FINAL RESULTS SUMMARY")
    print("="*70)
    print(f"\n{'Dataset':<35} {'Config':<40} {'Vocab':>8} {'Phrases':>8} {'Reduction':>10} {'Ratio':>8}")
    print("-" * 115)

    for r in sorted(all_results, key=lambda x: -x["reduction_pct"]):
        print(
            f"{r['dataset']:<35} {r['config']:<40} "
            f"{r['vocab_size']:>8,} {r['phrases']:>8,} "
            f"{r['reduction_pct']:>9.2f}% {r['compression_ratio']:>7.3f}x"
        )

    if best_result:
        print(f"\n{'='*70}")
        print(f"BEST RESULT:")
        print(f"  Dataset:    {best_result['dataset']}")
        print(f"  Config:     {best_result['config']}")
        print(f"  Vocab:      {best_result['vocab_size']:,}")
        print(f"  Phrases:    {best_result['phrases']:,}")
        print(f"  Reduction:  {best_result['reduction_pct']:.2f}%")
        print(f"  Ratio:      {best_result['compression_ratio']:.3f}x")
        print(f"  Original:   {best_result['original_tokens']:,} tokens")
        print(f"  Compressed: {best_result['compressed_tokens']:,} tokens")
        if best_result.get("tokenizer_path"):
            print(f"  Tokenizer:  {best_result['tokenizer_path']}")
        print(f"{'='*70}")

    # Save full results
    results_path = "/home/user/ion/benchmarks/massive_build_results.json"
    with open(results_path, "w") as f:
        json.dump(all_results, f, indent=2)
    print(f"\nFull results saved to: {results_path}")


if __name__ == "__main__":
    main()
