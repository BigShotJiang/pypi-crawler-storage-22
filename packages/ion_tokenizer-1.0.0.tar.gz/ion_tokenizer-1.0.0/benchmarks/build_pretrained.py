#!/usr/bin/env python3
"""
Build pretrained Ion tokenizers at multiple scales + BPE comparisons.

Produces 8 tokenizers:
  - ion-250k, ion-500k, ion-1m, ion-2m  (Ion phrase-first)
  - bpe-250k, bpe-500k, bpe-1m, bpe-2m  (BPE baseline)

Each is trained on Wikipedia + FineWeb with the specified sentence count.
Results are saved to pretrained/ with compression ratio reports.
"""

import sys
import os
import time
import json
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from ion.builder import TokenizerBuilder
from ion.corpus import load_corpus
from tqdm import tqdm
from collections import Counter

PRETRAINED_DIR = Path(__file__).parent.parent / "pretrained"
PRETRAINED_DIR.mkdir(exist_ok=True)

SCALES = {
    "250k": 250_000,
    "500k": 500_000,
    "1m": 1_000_000,
    "2m": 2_000_000,
}

# Benchmark text for compression measurement
BENCHMARK_TEXTS = [
    "The United States of America declared independence in 1776 and has since become one of the world's largest economies.",
    "Machine learning algorithms can process vast amounts of data to discover patterns that humans might miss entirely.",
    "Climate change is accelerating due to greenhouse gas emissions from fossil fuels and deforestation worldwide.",
    "The stock market experienced significant volatility during the pandemic as investors reacted to economic uncertainty.",
    "Natural language processing enables computers to understand, interpret, and generate human language effectively.",
    "New York City is home to Wall Street, the United Nations headquarters, and numerous world-famous cultural institutions.",
    "Artificial intelligence researchers are developing systems that can reason, learn, and solve complex problems autonomously.",
    "Solar energy production has increased dramatically as photovoltaic technology becomes more efficient and affordable.",
    "The European Union represents a unique political and economic partnership between twenty-seven European countries.",
    "Quantum computing promises to revolutionize fields from cryptography to drug discovery by leveraging quantum mechanical phenomena.",
]


def load_sentences(max_sentences: int, builder: TokenizerBuilder):
    """Load sentences from Wikipedia and FineWeb up to max_sentences."""
    total = 0
    half = max_sentences // 2

    # Wikipedia
    print(f"  Loading Wikipedia (up to {half:,} sentences)...")
    try:
        sentence_iter = load_corpus(
            "wikimedia/wikipedia",
            hf_split="train",
            hf_text_field="text",
            hf_config="20231101.en",
            max_samples=half,
            language=builder.language,
            preserve_case=builder.preserve_case,
        )
        for sent in tqdm(sentence_iter, desc="Wikipedia", total=half):
            builder.sentences.append(sent)
            for tok in sent:
                builder.word_freq[tok] += 1
            total += 1
            if total >= half:
                break
    except Exception as e:
        print(f"  [WARN] Wikipedia: {e}")

    # FineWeb
    remaining = max_sentences - total
    print(f"  Loading FineWeb (up to {remaining:,} sentences)...")
    try:
        sentence_iter = load_corpus(
            "HuggingFaceFW/fineweb",
            hf_split="train",
            hf_text_field="text",
            hf_config="sample-10BT",
            max_samples=remaining,
            language=builder.language,
            preserve_case=builder.preserve_case,
        )
        count = 0
        for sent in tqdm(sentence_iter, desc="FineWeb", total=remaining):
            builder.sentences.append(sent)
            for tok in sent:
                builder.word_freq[tok] += 1
            total += 1
            count += 1
            if count >= remaining:
                break
    except Exception as e:
        print(f"  [WARN] FineWeb: {e}")

    return total


def build_bpe_tokenizer(sentences: list, vocab_size: int, output_path: str):
    """Build a pure BPE tokenizer for comparison."""
    try:
        from tokenizers import Tokenizer
        from tokenizers.models import BPE
        from tokenizers.trainers import BpeTrainer
        from tokenizers.pre_tokenizers import Whitespace

        tokenizer = Tokenizer(BPE(unk_token="[UNK]"))
        tokenizer.pre_tokenizer = Whitespace()

        trainer = BpeTrainer(
            vocab_size=vocab_size,
            special_tokens=["[UNK]", "[PAD]", "[CLS]", "[SEP]", "[MASK]"],
            min_frequency=2,
        )

        # Write corpus to temp file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            for sent in sentences:
                f.write(" ".join(sent) + '\n')
            temp_path = f.name

        try:
            tokenizer.train([temp_path], trainer)
            tokenizer.save(output_path)
            return tokenizer
        finally:
            os.unlink(temp_path)

    except ImportError:
        print("  [WARN] 'tokenizers' library not installed. Cannot build BPE.")
        return None


def measure_compression(tokenizer_obj, texts, is_bpe=False):
    """Measure compression ratio on benchmark texts."""
    total_words = 0
    total_tokens = 0

    for text in texts:
        words = text.split()
        total_words += len(words)
        if is_bpe:
            encoded = tokenizer_obj.encode(text)
            total_tokens += len(encoded.ids)
        else:
            encoded = tokenizer_obj.encode(text)
            total_tokens += len(encoded)

    if total_tokens == 0:
        return 1.0
    return total_words / total_tokens


def build_ion_at_scale(scale_name: str, max_sentences: int):
    """Build an Ion tokenizer at the given scale."""
    output_path = str(PRETRAINED_DIR / f"ion-{scale_name}.json")

    if os.path.exists(output_path):
        print(f"  [SKIP] {output_path} already exists")
        return output_path

    print(f"\n{'='*60}")
    print(f"Building ion-{scale_name} ({max_sentences:,} sentences)")
    print(f"{'='*60}")

    builder = TokenizerBuilder(
        max_vocab_size=100_000,
        min_word_freq=2,
        min_phrase_freq=3,
        phrase_threshold=0.001,
        max_phrase_layers=4,
        max_sentences=max_sentences + 100_000,
        take_needed=True,
        enable_bpe_fallback=True,
        bpe_vocab_size=10_000,
        language="en",
        preserve_case=False,
        phrase_target_pct=60.0,
        word_target_pct=40.0,
        fallback_mode="bpe",
    )

    t0 = time.time()
    n = load_sentences(max_sentences, builder)
    print(f"  Loaded {n:,} sentences in {time.time()-t0:.1f}s")

    builder.stats["total_sentences"] = len(builder.sentences)
    builder.stats["total_tokens_original"] = sum(len(s) for s in builder.sentences)

    print("  Discovering phrases...")
    t0 = time.time()
    builder.discover_phrases()
    print(f"  Phrases: {len(builder.phrases):,}, Words: {len(builder.words):,} ({time.time()-t0:.1f}s)")

    print("  Building tokenizer...")
    t0 = time.time()
    builder.build_tokenizer()
    print(f"  Built in {time.time()-t0:.1f}s")

    builder.save(output_path)
    size_mb = os.path.getsize(output_path) / (1024 * 1024)
    print(f"  Saved: {output_path} ({size_mb:.1f} MB)")

    return output_path


def build_bpe_at_scale(scale_name: str, sentences: list):
    """Build a BPE tokenizer at the given scale."""
    output_path = str(PRETRAINED_DIR / f"bpe-{scale_name}.json")

    if os.path.exists(output_path):
        print(f"  [SKIP] {output_path} already exists")
        return output_path

    print(f"\n  Building bpe-{scale_name}...")
    t0 = time.time()
    bpe = build_bpe_tokenizer(sentences, vocab_size=50_000, output_path=output_path)
    if bpe:
        size_mb = os.path.getsize(output_path) / (1024 * 1024)
        print(f"  Saved: {output_path} ({size_mb:.1f} MB, {time.time()-t0:.1f}s)")
    return output_path


def main():
    import orjson

    results = {}

    # We need to collect sentences at each scale for BPE training
    # Build Ion tokenizers first (they save their sentences internally)
    all_sentences = {}

    for scale_name, max_sents in SCALES.items():
        # Build Ion version
        ion_path = build_ion_at_scale(scale_name, max_sents)

        # Load the Ion tokenizer for compression measurement
        from ion.tokenizer import IonTokenizer
        data = orjson.loads(Path(ion_path).read_bytes())
        ion_tok = IonTokenizer.from_dict(data)
        ion_ratio = measure_compression(ion_tok, BENCHMARK_TEXTS, is_bpe=False)

        results[f"ion-{scale_name}"] = {
            "compression_ratio": round(ion_ratio, 3),
            "vocab_size": ion_tok.vocab_size(),
            "path": ion_path,
        }

        # Collect sentences for BPE (reuse from builder - load fresh)
        print(f"\n  Loading sentences for bpe-{scale_name}...")
        bpe_builder = TokenizerBuilder(language="en", preserve_case=False, max_sentences=max_sents + 100_000)
        load_sentences(max_sents, bpe_builder)
        all_sentences[scale_name] = bpe_builder.sentences

        # Build BPE version
        bpe_path = build_bpe_at_scale(scale_name, bpe_builder.sentences)
        if bpe_path and os.path.exists(bpe_path):
            try:
                from tokenizers import Tokenizer as HFTokenizer
                bpe_tok = HFTokenizer.from_file(bpe_path)
                bpe_ratio = measure_compression(bpe_tok, BENCHMARK_TEXTS, is_bpe=True)
                results[f"bpe-{scale_name}"] = {
                    "compression_ratio": round(bpe_ratio, 3),
                    "vocab_size": bpe_tok.get_vocab_size(),
                    "path": bpe_path,
                }
            except Exception as e:
                print(f"  [WARN] BPE measurement failed: {e}")

    # Print summary
    print("\n" + "=" * 70)
    print("COMPRESSION RATIO SUMMARY")
    print("=" * 70)
    print(f"{'Tokenizer':<20} {'Vocab Size':>12} {'Compression':>14} {'Path'}")
    print("-" * 70)
    for name in sorted(results.keys()):
        r = results[name]
        print(f"{name:<20} {r['vocab_size']:>12,} {r['compression_ratio']:>13.3f}x  {r['path']}")

    # Save results
    results_path = str(PRETRAINED_DIR / "compression_results.json")
    Path(results_path).write_bytes(orjson.dumps(results, option=orjson.OPT_INDENT_2))
    print(f"\nResults saved to {results_path}")


if __name__ == "__main__":
    main()
