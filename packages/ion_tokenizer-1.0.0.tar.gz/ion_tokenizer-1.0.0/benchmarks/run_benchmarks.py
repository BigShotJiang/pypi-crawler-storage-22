#!/usr/bin/env python3
"""Run comprehensive Ion benchmarks across HuggingFace datasets with proper domain application."""

import os
import json
import time
import traceback

# Set up registration
os.makedirs(os.path.expanduser("~/.ion"), exist_ok=True)
config = {
    "email": "bench@test.com",
    "plan": "free",
    "user_id": "usr_bench123",
    "registered_at": "2026-01-01T00:00:00",
    "agreed_to_license": True,
    "license_version": "1.0",
}
with open(os.path.expanduser("~/.ion/config.json"), "w") as f:
    json.dump(config, f)

from ion.builder import TokenizerBuilder
from ion.tools import get_domain_config, DOMAIN_CONFIGS

# Dataset configurations - use larger sentence counts for meaningful phrase discovery
DATASETS = [
    {
        "name": "imdb",
        "source": "imdb",
        "hf_text_field": "text",
        "hf_split": "train",
        "hf_config": None,
        "domains": ["general", "chat"],
    },
    {
        "name": "wikitext",
        "source": "wikitext",
        "hf_text_field": "text",
        "hf_split": "train",
        "hf_config": "wikitext-103-raw-v1",
        "domains": ["general", "wikipedia"],
    },
    {
        "name": "ag_news",
        "source": "ag_news",
        "hf_text_field": "text",
        "hf_split": "train",
        "hf_config": None,
        "domains": ["general", "scientific"],
    },
]

VOCAB_SIZES = [10000, 20000, 50000]
FALLBACK_MODES = ["bpe", "newword"]
PHRASE_TARGET_PCTS = [40, 60, 80]
MAX_SENTENCES = 50000  # 10x more data for meaningful phrase discovery

results = []
total_runs = 0
for ds in DATASETS:
    for vs in VOCAB_SIZES:
        for fm in FALLBACK_MODES:
            for ptp in PHRASE_TARGET_PCTS:
                total_runs += len(ds["domains"])

run_num = 0

for ds in DATASETS:
    print(f"\n{'='*60}")
    print(f"DATASET: {ds['name']}")
    print(f"{'='*60}")

    for vocab_size in VOCAB_SIZES:
        for fallback_mode in FALLBACK_MODES:
            for phrase_pct in PHRASE_TARGET_PCTS:
                for domain in ds["domains"]:
                    run_num += 1
                    label = f"[{run_num}/{total_runs}] {ds['name']} | vocab={vocab_size} fb={fallback_mode} phr={phrase_pct}% domain={domain}"
                    print(f"\n>>> {label}")
                    start = time.time()
                    try:
                        # Get domain config and apply its settings
                        domain_cfg = get_domain_config(domain)

                        builder = TokenizerBuilder(
                            max_vocab_size=vocab_size,
                            max_sentences=MAX_SENTENCES,
                            fallback_mode=fallback_mode,
                            phrase_target_pct=phrase_pct,
                            word_target_pct=100 - phrase_pct,
                            # Apply domain-specific settings (this is what was missing!)
                            min_word_freq=domain_cfg["min_word_freq"],
                            min_phrase_freq=domain_cfg["min_phrase_freq"],
                            phrase_threshold=domain_cfg["phrase_threshold"],
                            max_phrase_layers=domain_cfg["max_phrase_layers"],
                            preserve_case=domain_cfg.get("preserve_case", False),
                            enable_bpe_fallback=(fallback_mode == "bpe"),
                            bpe_vocab_size=min(vocab_size // 2, 10000),
                        )

                        builder.load_corpus(
                            source=ds["source"],
                            hf_split=ds["hf_split"],
                            hf_text_field=ds["hf_text_field"],
                            hf_config=ds.get("hf_config"),
                        )

                        builder.discover_phrases()
                        tokenizer = builder.build_tokenizer()

                        elapsed = time.time() - start
                        result = {
                            "dataset": ds["name"],
                            "domain": domain,
                            "vocab_size": builder.stats.get("vocab_size", vocab_size),
                            "target_vocab_size": vocab_size,
                            "fallback_mode": fallback_mode,
                            "phrase_target_pct": phrase_pct,
                            "phrase_count": builder.stats.get("phrase_count", 0),
                            "word_count": builder.stats.get("word_count", 0),
                            "reduction_pct": builder.stats.get("sequence_length_reduction_pct", 0),
                            "compression_ratio": builder.stats.get("compression_ratio", 1.0),
                            "total_sentences": builder.stats.get("total_sentences", 0),
                            "original_tokens_sample": builder.stats.get("original_tokens_sample", 0),
                            "compressed_tokens_sample": builder.stats.get("compressed_tokens_sample", 0),
                            "elapsed_seconds": round(elapsed, 1),
                            # Domain settings applied
                            "domain_phrase_threshold": domain_cfg["phrase_threshold"],
                            "domain_max_phrase_layers": domain_cfg["max_phrase_layers"],
                            "domain_min_phrase_freq": domain_cfg["min_phrase_freq"],
                        }
                        results.append(result)
                        print(f"    reduction={result['reduction_pct']}% ratio={result['compression_ratio']} "
                              f"phrases={result['phrase_count']} words={result['word_count']} "
                              f"vocab={result['vocab_size']} time={result['elapsed_seconds']}s")

                    except Exception as e:
                        print(f"    FAILED: {e}")
                        traceback.print_exc()
                        results.append({
                            "dataset": ds["name"],
                            "domain": domain,
                            "vocab_size": vocab_size,
                            "target_vocab_size": vocab_size,
                            "fallback_mode": fallback_mode,
                            "phrase_target_pct": phrase_pct,
                            "error": str(e),
                        })

# Save results
output_path = "/home/user/ion/benchmark_results.json"
with open(output_path, "w") as f:
    json.dump(results, f, indent=2)
print(f"\n\nResults saved to {output_path}")
print(f"Total runs: {len(results)}")

# Analysis
print("\n" + "=" * 70)
print("ANALYSIS")
print("=" * 70)

from collections import defaultdict

all_valid = [r for r in results if "error" not in r]

# By fallback mode
print("\nBy fallback mode:")
for fm in FALLBACK_MODES:
    subset = [r for r in all_valid if r["fallback_mode"] == fm]
    if subset:
        avg_ratio = sum(r["compression_ratio"] for r in subset) / len(subset)
        avg_reduction = sum(r["reduction_pct"] for r in subset) / len(subset)
        print(f"  {fm}: avg ratio={avg_ratio:.3f}x, avg reduction={avg_reduction:.2f}%")

# By vocab size
print("\nBy vocab size:")
for vs in VOCAB_SIZES:
    subset = [r for r in all_valid if r["target_vocab_size"] == vs]
    if subset:
        avg_ratio = sum(r["compression_ratio"] for r in subset) / len(subset)
        avg_reduction = sum(r["reduction_pct"] for r in subset) / len(subset)
        print(f"  {vs}: avg ratio={avg_ratio:.3f}x, avg reduction={avg_reduction:.2f}%")

# By phrase target %
print("\nBy phrase target %:")
for ptp in PHRASE_TARGET_PCTS:
    subset = [r for r in all_valid if r["phrase_target_pct"] == ptp]
    if subset:
        avg_ratio = sum(r["compression_ratio"] for r in subset) / len(subset)
        avg_reduction = sum(r["reduction_pct"] for r in subset) / len(subset)
        print(f"  {ptp}%: avg ratio={avg_ratio:.3f}x, avg reduction={avg_reduction:.2f}%")

# By domain
print("\nBy domain (across datasets):")
by_domain = defaultdict(list)
for r in all_valid:
    by_domain[r["domain"]].append(r)
for dom, runs in sorted(by_domain.items()):
    avg_ratio = sum(r["compression_ratio"] for r in runs) / len(runs)
    avg_reduction = sum(r["reduction_pct"] for r in runs) / len(runs)
    print(f"  {dom}: avg ratio={avg_ratio:.3f}x, avg reduction={avg_reduction:.2f}% ({len(runs)} runs)")

# Best per dataset
print("\nBest config per dataset:")
by_ds = defaultdict(list)
for r in all_valid:
    by_ds[r["dataset"]].append(r)
for dataset, runs in sorted(by_ds.items()):
    best = max(runs, key=lambda x: x["reduction_pct"])
    print(f"  {dataset}: {best['reduction_pct']:.2f}% reduction, {best['compression_ratio']:.2f}x ratio")
    print(f"    vocab={best['target_vocab_size']} fb={best['fallback_mode']} phr={best['phrase_target_pct']}% "
          f"domain={best['domain']} phrases={best['phrase_count']} words={best['word_count']}")
