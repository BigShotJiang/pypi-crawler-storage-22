#!/usr/bin/env python3
"""
Monster Tokenizer Training Script
==================================
Trains an Ion tokenizer on:
  1. Local text files (training_data/)
  2. Wikipedia (full English)
  3. FineWeb (HuggingFace/fineweb)

Usage:
    python train_monster_tokenizer.py

This builds a comprehensive tokenizer that doesn't miss anything.
"""

import sys
import os
import time
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from ion.builder import TokenizerBuilder
from ion.corpus import load_corpus
from tqdm import tqdm
from collections import Counter


def load_local_texts(builder: TokenizerBuilder, data_dir: str = "training_data"):
    """Load all .txt files from local training_data directory."""
    data_path = Path(data_dir)
    if not data_path.exists():
        print(f"  [SKIP] {data_dir}/ not found")
        return 0

    count = 0
    for txt_file in sorted(data_path.glob("*.txt")):
        print(f"  Loading {txt_file.name}...")
        try:
            sentence_iter = load_corpus(
                str(txt_file),
                language=builder.language,
                preserve_case=builder.preserve_case,
                keep_json=builder.keep_json,
            )
            for sent in sentence_iter:
                builder.sentences.append(sent)
                for tok in sent:
                    builder.word_freq[tok] += 1
                count += 1
        except Exception as e:
            print(f"  [WARN] Failed to load {txt_file.name}: {e}")
    return count


def load_wikipedia(builder: TokenizerBuilder, max_samples: int = 500_000):
    """Load English Wikipedia from HuggingFace."""
    print(f"  Loading Wikipedia (up to {max_samples:,} samples)...")
    try:
        sentence_iter = load_corpus(
            "wikipedia",
            hf_split="train",
            hf_text_field="text",
            hf_config="20220301.en",
            max_samples=max_samples,
            language=builder.language,
            preserve_case=builder.preserve_case,
            keep_json=builder.keep_json,
        )
        count = 0
        for sent in tqdm(sentence_iter, desc="Wikipedia", total=max_samples):
            builder.sentences.append(sent)
            for tok in sent:
                builder.word_freq[tok] += 1
            count += 1
            if count >= max_samples:
                break
        return count
    except Exception as e:
        print(f"  [WARN] Failed to load Wikipedia: {e}")
        print(f"  Trying alternative config...")
        try:
            sentence_iter = load_corpus(
                "wikimedia/wikipedia",
                hf_split="train",
                hf_text_field="text",
                hf_config="20231101.en",
                max_samples=max_samples,
                language=builder.language,
                preserve_case=builder.preserve_case,
                keep_json=builder.keep_json,
            )
            count = 0
            for sent in tqdm(sentence_iter, desc="Wikipedia", total=max_samples):
                builder.sentences.append(sent)
                for tok in sent:
                    builder.word_freq[tok] += 1
                count += 1
                if count >= max_samples:
                    break
            return count
        except Exception as e2:
            print(f"  [WARN] Wikipedia unavailable: {e2}")
            return 0


def load_fineweb(builder: TokenizerBuilder, max_samples: int = 500_000):
    """Load FineWeb from HuggingFace."""
    print(f"  Loading FineWeb (up to {max_samples:,} samples)...")
    try:
        sentence_iter = load_corpus(
            "HuggingFaceFW/fineweb",
            hf_split="train",
            hf_text_field="text",
            hf_config="sample-10BT",
            max_samples=max_samples,
            language=builder.language,
            preserve_case=builder.preserve_case,
            keep_json=builder.keep_json,
        )
        count = 0
        for sent in tqdm(sentence_iter, desc="FineWeb", total=max_samples):
            builder.sentences.append(sent)
            for tok in sent:
                builder.word_freq[tok] += 1
            count += 1
            if count >= max_samples:
                break
        return count
    except Exception as e:
        print(f"  [WARN] Failed to load FineWeb: {e}")
        # Try without config
        try:
            sentence_iter = load_corpus(
                "HuggingFaceFW/fineweb",
                hf_split="train",
                hf_text_field="text",
                max_samples=max_samples,
                language=builder.language,
                preserve_case=builder.preserve_case,
                keep_json=builder.keep_json,
            )
            count = 0
            for sent in tqdm(sentence_iter, desc="FineWeb", total=max_samples):
                builder.sentences.append(sent)
                for tok in sent:
                    builder.word_freq[tok] += 1
                count += 1
                if count >= max_samples:
                    break
            return count
        except Exception as e2:
            print(f"  [WARN] FineWeb unavailable: {e2}")
            return 0


def main():
    print("=" * 60)
    print("MONSTER TOKENIZER TRAINING")
    print("=" * 60)
    print()

    output_path = "monster_tokenizer.json"

    # Build with take-needed mode for maximum coverage
    builder = TokenizerBuilder(
        max_vocab_size=100_000,       # Large vocab for monster tokenizer
        min_word_freq=2,              # Include rare words
        min_phrase_freq=3,            # Catch phrases that appear 3+ times
        phrase_threshold=0.001,       # Low threshold for more phrases
        max_phrase_layers=4,          # Up to 5-grams
        max_sentences=5_000_000,      # High limit
        take_needed=True,             # Include ALL words and ALL phrases
        enable_bpe_fallback=True,     # BPE for unknown words
        bpe_vocab_size=10_000,
        language="en",
        preserve_case=False,
        phrase_target_pct=60.0,
        word_target_pct=40.0,
        fallback_mode="bpe",
    )

    total_sents = 0

    # Phase 1: Local texts
    print("[1/3] Loading local training texts...")
    n = load_local_texts(builder)
    total_sents += n
    print(f"  -> {n:,} sentences from local files")
    print()

    # Phase 2: Wikipedia
    print("[2/3] Loading Wikipedia...")
    n = load_wikipedia(builder)
    total_sents += n
    print(f"  -> {n:,} sentences from Wikipedia")
    print()

    # Phase 3: FineWeb
    print("[3/3] Loading FineWeb...")
    n = load_fineweb(builder)
    total_sents += n
    print(f"  -> {n:,} sentences from FineWeb")
    print()

    builder.stats["total_sentences"] = len(builder.sentences)
    builder.stats["total_tokens_original"] = sum(len(s) for s in builder.sentences)

    print(f"Total: {total_sents:,} sentences loaded")
    print(f"Unique words: {len(builder.word_freq):,}")
    print()

    if total_sents == 0:
        print("ERROR: No data loaded. Ensure training_data/ has .txt files or HF datasets are accessible.")
        sys.exit(1)

    # Phase 4: Discover phrases
    print("Discovering phrases...")
    start = time.time()
    builder.discover_phrases()
    elapsed = time.time() - start
    print(f"  Phrase discovery completed in {elapsed:.1f}s")
    print(f"  Phrases: {len(builder.phrases):,}")
    print(f"  Words: {len(builder.words):,}")
    print()

    # Phase 5: Build tokenizer
    print("Building tokenizer...")
    start = time.time()
    builder.build_tokenizer()
    elapsed = time.time() - start
    print(f"  Tokenizer built in {elapsed:.1f}s")
    print()

    # Phase 6: Save
    print(f"Saving to {output_path}...")
    builder.save(output_path)
    size_mb = os.path.getsize(output_path) / (1024 * 1024)
    print(f"  Saved ({size_mb:.1f} MB)")
    print()

    # Summary
    print("=" * 60)
    print("TRAINING COMPLETE")
    print("=" * 60)
    if builder.tokenizer:
        vocab = builder.tokenizer.vocab_size
        print(f"  Vocab size: {vocab:,}")
    print(f"  Total sentences: {total_sents:,}")
    print(f"  Output: {output_path}")
    if builder.stats.get("compression_ratio"):
        print(f"  Compression ratio: {builder.stats['compression_ratio']:.2f}x")
    print()


if __name__ == "__main__":
    main()
