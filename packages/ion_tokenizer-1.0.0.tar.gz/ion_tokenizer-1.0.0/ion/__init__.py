"""Ion: Phrase-First Semantic Tokenizer Compiler for Neural Language Models.

Ion maximizes sequence-length reduction by discovering and collapsing
multi-word semantic units into single tokens.

Example usage:
    from ion import IonTokenizer
    from ion.integrations import IonTokenizerHF, IonDataset

    # Load tokenizer
    tokenizer = IonTokenizerHF.from_pretrained("tokenizer.json")

    # Encode text (HuggingFace compatible)
    encoded = tokenizer("Hello world", return_tensors="pt")
"""

__version__ = "1.0.0"

from .tokenizer import IonTokenizer, TypoCorrector, StreamingPhraseDiscovery

__all__ = [
    "IonTokenizer", "TypoCorrector", "StreamingPhraseDiscovery",
    "__version__",
]

try:
    from .phrase_discovery import EmbeddingPhraseScorer
    __all__.append("EmbeddingPhraseScorer")
except ImportError:
    pass
