"""Allow running ion as a module: python -m ion"""

from .cli import main

if __name__ == "__main__":
    main()
