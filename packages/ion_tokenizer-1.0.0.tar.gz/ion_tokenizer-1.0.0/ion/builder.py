"""Tokenizer builder: orchestrates corpus loading, phrase discovery, and tokenizer construction."""

import tempfile
from collections import Counter
from pathlib import Path
from typing import Optional, Any

import orjson
from tqdm import tqdm

from .corpus import load_corpus
from .phrase_discovery import PhraseDiscoverer
from .tokenizer import IonTokenizer, FALLBACK_ALPHABET, EXTENDED_ALPHABET, SPECIAL_TOKENS, PLAN_TOKENS


class TokenizerBuilder:
    """Builds an IonTokenizer from corpus with optional BPE hybrid fallback."""

    def __init__(
        self,
        max_vocab_size: int = 20000,
        min_word_freq: int = 1,  # Include all words to minimize character fallback
        min_phrase_freq: int = 3,  # Lower threshold to find more phrases
        phrase_threshold: float = 0.001,
        max_phrase_layers: int = 4,
        max_sentences: int = 1_000_000,
        take_needed: bool = False,  # TN mode: include ALL words and ALL phrases
        enable_bpe_fallback: bool = True,  # Enable BPE hybrid mode (recommended)
        bpe_vocab_size: int = 10000,  # BPE vocabulary size for fallback
        language: str = "en",  # spaCy language code
        preserve_case: bool = False,  # If True, don't lowercase tokens
        phrase_target_pct: float = 60.0,  # Target % of vocab for phrases (default: 60%)
        word_target_pct: float = 40.0,  # Target % of vocab for words (default: 40%)
        fallback_mode: str = "bpe",  # "bpe", "newword", "character", "word"
        max_word_length: int = 0,  # 0 = disabled; >0 = words longer than this use BPE fallback
        keep_json: bool = False,  # If True, keep JSON-structured content in corpus
    ):
        self.max_vocab_size = max_vocab_size
        self.min_word_freq = min_word_freq
        self.min_phrase_freq = min_phrase_freq
        self.phrase_threshold = phrase_threshold
        self.max_phrase_layers = max_phrase_layers
        self.max_sentences = max_sentences
        self.take_needed = take_needed
        self.enable_bpe_fallback = enable_bpe_fallback
        self.bpe_vocab_size = bpe_vocab_size
        self.language = language
        self.preserve_case = preserve_case
        self.phrase_target_pct = phrase_target_pct
        self.word_target_pct = word_target_pct
        self.fallback_mode = fallback_mode
        self.max_word_length = max_word_length
        self.keep_json = keep_json

        self.word_freq = Counter()
        self.sentences = []
        self.phrases = []
        self.words = []
        self.tokenizer = None
        self.bpe_tokenizer = None
        self.stats = {}

    def load_corpus(
        self,
        source: str,
        hf_split: str = "train",
        hf_text_field: str = "text",
        max_samples: Optional[int] = None,
        hf_config: Optional[str] = None,
        remove_emphasis: bool = False,
        collapse_punctuation: bool = False,
        token: Optional[str] = None,
    ):
        """Load corpus from source."""
        sentence_iter = load_corpus(
            source,
            hf_split=hf_split,
            hf_text_field=hf_text_field,
            max_samples=max_samples,
            hf_config=hf_config,
            remove_emphasis=remove_emphasis,
            collapse_punctuation=collapse_punctuation,
            language=self.language,
            preserve_case=self.preserve_case,
            token=token,
            keep_json=self.keep_json,
        )

        count = 0
        for sent in tqdm(sentence_iter, desc="Loading corpus"):
            self.sentences.append(sent)
            for tok in sent:
                self.word_freq[tok] += 1
            count += 1
            if count >= self.max_sentences:
                break

        self.stats["total_sentences"] = len(self.sentences)
        self.stats["total_tokens_original"] = sum(len(s) for s in self.sentences)

    def discover_phrases(self):
        """Run phrase discovery on loaded corpus."""
        # Use language-appropriate connector words
        try:
            from gensim.models.phrases import ENGLISH_CONNECTOR_WORDS
        except ImportError:
            from ion.compat.ion_phrases import ENGLISH_CONNECTOR_WORDS
        connector_words = ENGLISH_CONNECTOR_WORDS if self.language == "en" else frozenset()

        discoverer = PhraseDiscoverer(
            min_count=self.min_phrase_freq,
            threshold=self.phrase_threshold,
            max_vocab_size=self.max_vocab_size,
            max_layers=self.max_phrase_layers,
            connector_words=connector_words,
        )

        discoverer.discover(iter(self.sentences), max_sentences=len(self.sentences))

        # Use extended alphabet for non-English languages
        fallback_alphabet = EXTENDED_ALPHABET if self.language != "en" else FALLBACK_ALPHABET
        reserved_slots = len(SPECIAL_TOKENS) + len(fallback_alphabet)

        # CRITICAL: Get ALL words sorted by frequency
        # Include words with freq >= 1 to maximize coverage and minimize character fallback
        # If max_word_length is set, exclude words longer than the limit (they'll use BPE fallback)
        words_with_freq = [
            (w, f) for w, f in self.word_freq.items()
            if f >= self.min_word_freq and (self.max_word_length <= 0 or len(w) <= self.max_word_length)
        ]
        words_with_freq.sort(key=lambda x: -x[1])

        if self.take_needed:
            # TN MODE: Take ALL discovered phrases and ALL words
            # This ensures zero character fallback and complete phrase coverage
            candidate_phrases = discoverer.select_phrases_for_vocab(
                self.sentences,
                base_vocab_size=reserved_slots,
                max_phrases=999_999_999,  # No limit
            )
            self.phrases = candidate_phrases  # All phrases
            self.words = [w for w, f in words_with_freq]  # All words
            self.stats["mode"] = "take_needed"
        else:
            # STRATEGY: Phrases first, then fill remaining with words
            # Phrases save more tokens per vocab slot, so prioritize them

            # First, get candidate phrases
            candidate_phrases = discoverer.select_phrases_for_vocab(
                self.sentences,
                base_vocab_size=reserved_slots,
                max_phrases=self.max_vocab_size - reserved_slots,
            )

            # Allocate phrases and words according to target percentages
            phrase_pct = self.phrase_target_pct / 100.0
            max_phrase_slots = int((self.max_vocab_size - reserved_slots) * phrase_pct)
            self.phrases = candidate_phrases[:max_phrase_slots]

            # Fill remaining vocab with words (maximize coverage)
            remaining_slots = self.max_vocab_size - reserved_slots - len(self.phrases)
            self.words = [w for w, f in words_with_freq[:remaining_slots]]
            self.stats["mode"] = "standard"

        self.stats["phrase_count"] = len(self.phrases)
        self.stats["word_count"] = len(self.words)

    def _train_bpe_tokenizer(self) -> Any:
        """Train a BPE tokenizer on the corpus for hybrid fallback."""
        try:
            from tokenizers import Tokenizer
            from tokenizers.models import BPE
            from tokenizers.trainers import BpeTrainer
            from tokenizers.pre_tokenizers import Whitespace

            # Write corpus to temp file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
                for sent in self.sentences:
                    f.write(" ".join(sent) + '\n')
                temp_path = f.name

            try:
                tokenizer = Tokenizer(BPE(unk_token="[UNK]"))
                tokenizer.pre_tokenizer = Whitespace()

                trainer = BpeTrainer(
                    vocab_size=self.bpe_vocab_size,
                    special_tokens=["[UNK]", "[PAD]"],
                    min_frequency=2,
                )

                tokenizer.train([temp_path], trainer)
                return tokenizer
            finally:
                import os
                os.unlink(temp_path)

        except ImportError:
            # tokenizers library not installed
            return None

    def build_tokenizer(self) -> IonTokenizer:
        """Build the tokenizer from discovered vocabulary."""
        # Train BPE tokenizer if enabled and fallback mode is bpe
        if self.enable_bpe_fallback and self.fallback_mode == "bpe":
            self.bpe_tokenizer = self._train_bpe_tokenizer()
            self.stats["bpe_fallback"] = self.bpe_tokenizer is not None

        # Use extended alphabet for non-English languages
        fallback_alphabet = EXTENDED_ALPHABET if self.language != "en" else FALLBACK_ALPHABET

        # Build Ion tokenizer with configured fallback mode
        if self.fallback_mode == "newword":
            fallback_mode = "newword"
        elif self.fallback_mode == "bpe" and self.bpe_tokenizer:
            fallback_mode = "bpe"
        elif self.fallback_mode in ("character", "word"):
            fallback_mode = self.fallback_mode
        else:
            fallback_mode = "bpe" if self.bpe_tokenizer else "character"
        self.tokenizer = IonTokenizer(
            phrases=self.phrases,
            words=self.words,
            fallback_chars=fallback_alphabet,
            fallback_mode=fallback_mode,
            bpe_tokenizer=self.bpe_tokenizer,
            preserve_case=self.preserve_case,
            plan_token=getattr(self, 'plan_token', None),
        )

        # Set max_word_length for runtime enforcement (newword mode)
        self.tokenizer.max_word_length = self.max_word_length

        # Set up BPE tokenizer if available
        if self.bpe_tokenizer:
            self.tokenizer.set_bpe_tokenizer(self.bpe_tokenizer, add_vocab=True)

        self.stats["vocab_size"] = self.tokenizer.vocab_size()
        self.stats["fallback_mode"] = fallback_mode
        self.stats["max_word_length"] = self.max_word_length
        self.stats["language"] = self.language
        self.stats["preserve_case"] = self.preserve_case
        self._compute_compression_stats()

        return self.tokenizer

    def _compute_compression_stats(self):
        """Compute sequence length reduction statistics."""
        original_tokens = 0
        compressed_tokens = 0

        for sent in tqdm(self.sentences[:10000], desc="Computing stats"):
            text = " ".join(sent)
            original_tokens += len(sent)
            encoded = self.tokenizer.encode(text)
            compressed_tokens += len(encoded)

        self.stats["original_tokens_sample"] = original_tokens
        self.stats["compressed_tokens_sample"] = compressed_tokens

        if original_tokens > 0:
            reduction = (original_tokens - compressed_tokens) / original_tokens * 100
            self.stats["sequence_length_reduction_pct"] = round(reduction, 2)
            self.stats["compression_ratio"] = round(original_tokens / max(compressed_tokens, 1), 2)
        else:
            self.stats["sequence_length_reduction_pct"] = 0.0
            self.stats["compression_ratio"] = 1.0

    def save(self, output_path: str = "tokenizer.json", license_config: dict = None):
        """Save tokenizer to JSON file, inject license metadata, and write LICENSE.md."""
        if self.tokenizer is None:
            raise ValueError("Tokenizer not built. Call build_tokenizer() first.")

        if license_config:
            from .licensing import (
                _sha256, _generate_tokenizer_id, compute_vocab_hash,
                generate_license_md, log_tokenizer_creation, sign_tokenizer,
                PLAN_TOKENS, ION_LICENSE_VERSION,
            )
            from . import __version__
            from datetime import datetime, timezone

            tokenizer_id = _generate_tokenizer_id()
            now = datetime.now(timezone.utc).isoformat()
            email = license_config.get("email", "")
            plan = license_config.get("plan", "free")

            self.tokenizer._ion_license = {
                "plan": plan,
                "tokenizer_id": tokenizer_id,
                "email_hash": _sha256(email),
                "created_at": now,
                "license_url": "https://iontokenizer.com/license",
                "ion_version": __version__,
            }

            # Write LICENSE.md alongside tokenizer
            path = Path(output_path)
            license_md = generate_license_md(
                email=email,
                plan=plan,
                tokenizer_id=tokenizer_id,
                created_at=now,
                version=__version__,
            )
            license_path = path.parent / "LICENSE.md"
            license_path.write_text(license_md)

            # Log creation to server
            vocab_hash = compute_vocab_hash(self.tokenizer.vocab)
            log_tokenizer_creation(
                config=license_config,
                tokenizer_id=tokenizer_id,
                vocab_size=len(self.tokenizer.vocab),
                vocab_hash=vocab_hash,
            )

        data = self.tokenizer.to_dict()

        # Sign tokenizer with HMAC if license is present
        if license_config and data.get("ion_license"):
            from .licensing import sign_tokenizer
            data["ion_license"]["signature"] = sign_tokenizer(data, license_config)

        path = Path(output_path)
        path.write_bytes(orjson.dumps(data, option=orjson.OPT_INDENT_2))

    def get_stats(self) -> dict:
        """Return build statistics."""
        return self.stats


def build_tokenizer(
    source: str,
    output: str = "tokenizer.json",
    max_vocab_size: int = 20000,
    min_word_freq: int = 1,
    min_phrase_freq: int = 3,
    phrase_threshold: float = 0.001,
    max_phrase_layers: int = 4,
    max_sentences: int = 1_000_000,
    hf_split: str = "train",
    hf_text_field: str = "text",
    max_samples: Optional[int] = None,
    hf_config: Optional[str] = None,
    remove_emphasis: bool = False,
    collapse_punctuation: bool = False,
    take_needed: bool = False,
    enable_bpe_fallback: bool = True,
    bpe_vocab_size: int = 10000,
    language: str = "en",
    preserve_case: bool = False,
    phrase_target_pct: float = 60.0,
    word_target_pct: float = 40.0,
    fallback_mode: str = "bpe",
    max_word_length: int = 0,
    typo_correction: bool = False,
    typo_edit_distance: int = 2,
    streaming_phrases: bool = False,
    embedding_scoring: bool = False,
    hf_token: Optional[str] = None,
    license_config: Optional[dict] = None,
    keep_json: bool = False,
) -> dict:
    """
    Build tokenizer from corpus source.

    Args:
        source: HF dataset identifier, local file, or directory path
        output: Output path for tokenizer.json
        max_vocab_size: Maximum vocabulary size (no hard cap)
        min_word_freq: Minimum frequency for word inclusion
        min_phrase_freq: Minimum frequency for phrase inclusion
        phrase_threshold: PMI threshold for phrase detection
        max_phrase_layers: Maximum phrase discovery layers for longer n-grams
        max_sentences: Maximum sentences to process
        hf_split: HuggingFace dataset split
        hf_text_field: HuggingFace dataset text field name
        max_samples: Maximum samples from HF dataset
        hf_config: HuggingFace dataset config name
        remove_emphasis: Remove emphasis/intensifier words
        collapse_punctuation: Collapse duplicate punctuation
        take_needed: Include ALL words and ALL discovered phrases (ignores max_vocab_size)
        enable_bpe_fallback: Enable BPE subword fallback for unknown words (recommended)
        bpe_vocab_size: Vocabulary size for the BPE fallback tokenizer
        language: spaCy language code (en, de, fr, es, zh, ja, ko, ru, ar, etc.)
        preserve_case: If True, preserve case in tokens (useful for code, proper nouns)
        phrase_target_pct: Target percentage of vocab for phrases (default: 60%)
        word_target_pct: Target percentage of vocab for words (default: 40%)
        fallback_mode: Fallback mode: 'bpe', 'newword', 'character', 'word' (default: 'bpe')
        max_word_length: Max word length for vocab inclusion; longer words use BPE fallback (0=disabled)
        typo_correction: Enable typo correction layer
        typo_edit_distance: Max edit distance for typo correction (1 or 2)
        streaming_phrases: Enable streaming phrase discovery
        embedding_scoring: Use embedding-based phrase scoring

    Returns:
        Build statistics dictionary
    """
    builder = TokenizerBuilder(
        max_vocab_size=max_vocab_size,
        min_word_freq=min_word_freq,
        min_phrase_freq=min_phrase_freq,
        phrase_threshold=phrase_threshold,
        max_phrase_layers=max_phrase_layers,
        max_sentences=max_sentences,
        take_needed=take_needed,
        enable_bpe_fallback=enable_bpe_fallback,
        bpe_vocab_size=bpe_vocab_size,
        language=language,
        preserve_case=preserve_case,
        phrase_target_pct=phrase_target_pct,
        word_target_pct=word_target_pct,
        fallback_mode=fallback_mode,
        max_word_length=max_word_length,
        keep_json=keep_json,
    )

    builder.load_corpus(
        source,
        hf_split=hf_split,
        hf_text_field=hf_text_field,
        max_samples=max_samples,
        hf_config=hf_config,
        remove_emphasis=remove_emphasis,
        collapse_punctuation=collapse_punctuation,
        token=hf_token,
    )

    # Use embedding scoring if requested
    if embedding_scoring:
        try:
            from .phrase_discovery import EmbeddingPhraseScorer
            scorer = EmbeddingPhraseScorer()
            scorer.train(builder.sentences)
            if scorer.is_trained():
                builder.stats["embedding_scoring"] = True
                builder._embedding_scorer = scorer
        except ImportError:
            import warnings
            warnings.warn("Embedding scoring requires gensim and numpy. Skipping.")
            embedding_scoring = False

    # Set plan token from license config
    if license_config:
        from .licensing import PLAN_TOKENS as _PLAN_TOKENS
        plan = license_config.get("plan", "free")
        builder.plan_token = _PLAN_TOKENS.get(plan)
    else:
        builder.plan_token = None

    builder.discover_phrases()

    # If embedding scoring is enabled, re-rank phrases using the scorer
    if embedding_scoring and hasattr(builder, '_embedding_scorer') and builder._embedding_scorer.is_trained():
        scorer = builder._embedding_scorer
        phrases_with_freq = [(p, builder.stats.get("phrase_count", 0)) for p in builder.phrases]
        # Get actual frequencies
        phrase_freq = {}
        for sent in builder.sentences[:10000]:
            text = " ".join(sent)
            for phrase in builder.phrases:
                if phrase in text:
                    phrase_freq[phrase] = phrase_freq.get(phrase, 0) + 1
        phrases_with_freq = [(p, phrase_freq.get(p, 1)) for p in builder.phrases]
        scored = scorer.score_phrases(phrases_with_freq)
        # Re-sort phrases by embedding score
        builder.phrases = [p for p, score, details in scored]
        builder.stats["embedding_scored_phrases"] = len(scored)

    builder.build_tokenizer()

    # Enable typo correction if requested
    if typo_correction:
        builder.tokenizer.enable_typo_correction(
            max_edit_distance=typo_edit_distance,
        )
        builder.stats["typo_correction"] = True
        builder.stats["typo_edit_distance"] = typo_edit_distance

    # Enable streaming phrase discovery if requested
    if streaming_phrases:
        builder.tokenizer.enable_streaming_phrases()
        builder.stats["streaming_phrases"] = True

    builder.save(output, license_config=license_config)

    return builder.get_stats()


def iterate_tokenizer(
    tokenizer_path: str,
    source: str,
    output: str = "tokenizer.json",
    max_sentences: int = 100_000,
    hf_split: str = "train",
    hf_text_field: str = "text",
    max_samples: Optional[int] = None,
    hf_config: Optional[str] = None,
    remove_emphasis: bool = False,
    collapse_punctuation: bool = False,
    add_phrases: bool = True,
    add_words: bool = True,
) -> dict:
    """
    Iterate on existing tokenizer with new corpus data.

    Loads existing tokenizer and adapts it to new data by:
    - Adding new phrases discovered in the corpus
    - Adding new words that meet frequency threshold
    - Preserving existing vocabulary

    Args:
        tokenizer_path: Path to existing tokenizer.json
        source: New corpus source
        output: Output path for updated tokenizer.json
        max_sentences: Maximum sentences to process
        hf_split: HuggingFace dataset split
        hf_text_field: HuggingFace dataset text field name
        max_samples: Maximum samples from HF dataset
        hf_config: HuggingFace dataset config name
        remove_emphasis: Remove emphasis/intensifier words
        collapse_punctuation: Collapse duplicate punctuation
        add_phrases: Whether to add new phrases
        add_words: Whether to add new words

    Returns:
        Iteration statistics dictionary
    """
    from .tokenizer import IonTokenizer

    # Load existing tokenizer
    existing_data = orjson.loads(Path(tokenizer_path).read_bytes())
    existing_tokenizer = IonTokenizer.from_dict(existing_data)

    existing_phrases = set(
        t["token"] for t in existing_data["token_classes"]["phrase"]
    )
    existing_words = set(
        t["token"] for t in existing_data["token_classes"]["word"]
    )

    # Load new corpus, preserving original tokenizer's language/case settings
    preserve_case = existing_data.get("preserve_case", False)
    sentence_iter = load_corpus(
        source,
        hf_split=hf_split,
        hf_text_field=hf_text_field,
        max_samples=max_samples,
        hf_config=hf_config,
        remove_emphasis=remove_emphasis,
        collapse_punctuation=collapse_punctuation,
        preserve_case=preserve_case,
    )

    sentences = []
    word_freq = Counter()
    count = 0
    for sent in tqdm(sentence_iter, desc="Loading new corpus"):
        sentences.append(sent)
        for token in sent:
            word_freq[token] += 1
        count += 1
        if count >= max_sentences:
            break

    stats = {
        "sentences_processed": len(sentences),
        "existing_phrases": len(existing_phrases),
        "existing_words": len(existing_words),
    }

    new_phrases = []
    new_words = []

    # Discover new phrases
    if add_phrases and sentences:
        discoverer = PhraseDiscoverer(
            min_count=5,
            threshold=0.001,
            max_vocab_size=20000,
        )
        discoverer.discover(iter(sentences), max_sentences=len(sentences))

        for phrase, freq in discoverer.get_phrases_by_frequency(min_freq=5):
            if phrase not in existing_phrases:
                new_phrases.append(phrase)

    # Find new words
    if add_words:
        for word, freq in word_freq.items():
            if freq >= 5 and word not in existing_words:
                new_words.append(word)

    # Prioritize phrases over words for sequence reduction
    # Add all discovered new phrases and words (no artificial cap)
    phrases_to_add = new_phrases
    words_to_add = new_words

    # Build updated tokenizer preserving original configuration
    all_phrases = list(existing_phrases) + phrases_to_add
    all_words = list(existing_words) + words_to_add

    fallback_mode = existing_data.get("fallback_mode", "bpe")
    preserve_case = existing_data.get("preserve_case", False)
    fallback_chars = [t["token"][1:-1] for t in existing_data["token_classes"]["fallback"]]

    updated_tokenizer = IonTokenizer(
        phrases=all_phrases,
        words=all_words,
        fallback_chars=fallback_chars,
        fallback_mode=fallback_mode,
        preserve_case=preserve_case,
    )

    # Save
    Path(output).write_bytes(
        orjson.dumps(updated_tokenizer.to_dict(), option=orjson.OPT_INDENT_2)
    )

    stats["new_phrases_added"] = len(phrases_to_add)
    stats["new_words_added"] = len(words_to_add)
    stats["final_vocab_size"] = updated_tokenizer.vocab_size()

    return stats
