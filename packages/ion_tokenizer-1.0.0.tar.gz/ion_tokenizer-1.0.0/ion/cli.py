"""Ion CLI: phrase-first semantic tokenizer compiler."""

import os
import subprocess
import sys
import time
from pathlib import Path

import click
import orjson

from .builder import build_tokenizer, iterate_tokenizer
from .stats import compute_stats, format_stats
from .utils import clean_text, clean_file
from .tools import (
    vocab_sweep, phrase_accountability, bpe_parity_compare,
    export_huggingface, export_sentencepiece, export_vocab_txt,
    export_onnx, export_tiktoken, export_jsonl, export_csv,
    introspect_fallbacks, create_reproducibility_snapshot, verify_reproducibility,
    get_domain_config, list_domains, set_seed, DOMAIN_CONFIGS,
)
from .benchmarks import (
    load_benchmarks, save_benchmarks, format_benchmark_summary,
    format_quick_stats, get_ascii_chart, update_vocab_sweep,
    BASELINE_BENCHMARKS,
)


@click.group(invoke_without_command=True)
@click.version_option()
@click.pass_context
def main(ctx):
    """Ion: phrase-first semantic tokenizer compiler for neural language models.

    Run 'ion' without arguments to launch the interactive GUI.
    """
    if ctx.invoked_subcommand is None:
        # Ensure registration before launching GUI
        from .licensing import ensure_registered
        ensure_registered()
        from .gui import run_gui
        run_gui()


@main.command()
def help():
    """Show detailed help and usage information."""
    help_text = """
Ion - Phrase-First Semantic Tokenizer Compiler
===============================================

WHAT IS ION?
  Ion builds tokenizers that understand phrases, not just words.
  Instead of breaking "United States of America" into 4+ tokens,
  Ion keeps it as ONE token. This means shorter sequences, faster
  training, and better context utilization.

  TL;DR: Ion typically achieves 15-20% better compression than BPE.

START HERE (pick one):
  ion                    Interactive GUI - best for beginners!
  ion benchmarks         See Ion's value with pre-computed benchmarks
  ion tokenize           Build your first tokenizer

=== CORE COMMANDS ===

ion benchmarks
  See Ion's performance WITHOUT building anything.
  Shows vocab sweep results, Ion vs BPE comparisons, domain benchmarks.
  NEXT STEP: Run this first to understand what Ion can do.

ion tokenize <source>
  Build a tokenizer from your text corpus.
  Source can be: local file, directory, or HuggingFace dataset.
  Key options:
    --max-vocab N        Set vocabulary size (default: 20,000)
    -tn, --take-needed   Include ALL words + ALL phrases
    --domain <name>      Use domain-specific settings
  NEXT STEP: After building, run 'ion stats' to see how well it compresses.

ion benchmark <corpus>
  Train both Ion and BPE on the same corpus, compare results.
  Shows side-by-side token counts and compression ratios.
  NEXT STEP: Use this to prove Ion's value on YOUR data.

ion stats -t tokenizer.json
  Show detailed statistics for a tokenizer.
  Displays vocab breakdown, phrase/word counts, compression metrics.
  NEXT STEP: Run 'ion phrases' to see which phrases help most.

=== OPTIMIZATION TOOLS ===

ion sweep <corpus>
  Find the optimal vocab size for your data.
  Tests multiple sizes (5k, 10k, 20k, 50k, 100k) and shows:
    - Sequence reduction at each size
    - Compression ratio curve
    - Sweet spot recommendation
  Outputs CSV file for charts/analysis.
  NEXT STEP: Pick the vocab size with best reduction/size tradeoff.

ion phrases <corpus> -t tokenizer.json
  See which phrases earn their vocab slot.
  Shows per-phrase: usage count, tokens saved, marginal benefit.
  Identifies:
    - Top 100 most valuable phrases
    - Bottom 100 wasteful phrases (candidates for removal)
  NEXT STEP: Use this to prune or trust your tokenizer.

ion introspect "your text here" -t tokenizer.json
  Debug why words get spelled out character-by-character.
  Shows: which words aren't in vocab, why they fell back, fixes.
  NEXT STEP: Adjust --min-word-freq or use -tn mode to fix fallbacks.

=== DOMAIN-SPECIFIC BUILDS ===

ion tokenize <source> --domain <name>

  Available domains:
    wikipedia   - Encyclopedic content (boosts: "united states", "according to")
    code        - Source code and docs (boosts: "return value", "function call")
    legal       - Contracts and law (boosts: "pursuant to", "in accordance with")
    chat        - Conversational text (boosts: "i think", "you know")
    medical     - Clinical text (boosts: "blood pressure", "side effects")
    scientific  - Research papers (boosts: "et al", "results show")

  Each domain has tuned thresholds and phrase boosters.
  NEXT STEP: Pick the domain closest to your data.

=== EXPORT & INTEGRATION ===

ion export -t tokenizer.json -f <format> -o <output>

  Export to other formats for model training:
    huggingface   - HuggingFace Transformers compatible
    sentencepiece - SentencePiece vocab format
    vocab         - Plain vocab.txt for custom loaders

  NEXT STEP: Use the exported tokenizer in your training pipeline.

ion parity "text to compare" -t tokenizer.json
  Side-by-side comparison with BPE/tiktoken.
  Shows exact tokens from each, highlights winner.
  NEXT STEP: Use this to demonstrate Ion's value to stakeholders.

=== REPRODUCIBILITY ===

ion tokenize <source> --seed 42 --snapshot build.json
  Build with deterministic seed, save config snapshot.

ion verify build.json -t tokenizer.json
  Verify tokenizer matches its snapshot (hash comparison).
  NEXT STEP: Use snapshots for reproducible research.

=== QUICK START WORKFLOW ===

  Step 1: See what Ion can do
    $ ion benchmarks

  Step 2: Build your tokenizer
    $ ion tokenize my_corpus.txt -o tokenizer.json --max-vocab 20000

  Step 3: Check the results
    $ ion stats -t tokenizer.json

  Step 4: Compare with BPE
    $ ion benchmark my_corpus.txt --vocab-size 20000

  Step 5: Export for training
    $ ion export -t tokenizer.json -f huggingface -o ./my_tokenizer/

For interactive experience, just run: ion

For more info: https://github.com/creayo-dev/ion
"""
    click.echo(help_text)


@main.command()
def gui():
    """Launch the interactive graphical interface."""
    from .gui import run_gui
    run_gui()


@main.command()
def splash():
    """Show the ion splash screen."""
    from .gui import show_loading
    show_loading()


@main.command()
def uninstall():
    """Uninstall ion from the system."""
    click.echo("Uninstalling ion...")
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "uninstall", "ion", "-y"],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            click.echo("ion has been uninstalled successfully.")
        else:
            click.echo(f"Uninstall completed. Output: {result.stdout}")
            if result.stderr:
                click.echo(f"Warnings: {result.stderr}", err=True)
    except Exception as e:
        click.echo(f"Error during uninstall: {e}", err=True)
        sys.exit(1)


@main.command()
@click.option(
    "-o", "--output",
    default="ion.config.json",
    help="Output path for config file (default: ion.config.json)",
)
@click.option(
    "-y", "--yes",
    is_flag=True,
    default=False,
    help="Accept all defaults without prompting",
)
def init(output: str, yes: bool):
    """Interactive setup wizard to configure and build an Ion tokenizer.

    Walks you through choosing a corpus source, domain, vocab size,
    fallback mode, and optional features (typo correction, streaming
    phrases, embedding scoring). Generates a config file and optionally
    builds the tokenizer immediately.
    """
    # Ensure registration first
    from .licensing import ensure_registered
    license_config = ensure_registered()

    click.echo("=" * 60)
    click.echo("  Ion Tokenizer Setup Wizard")
    click.echo("=" * 60)
    click.echo()

    config = {}

    # Step 1: Corpus source
    click.echo("Step 1/8: Corpus Source")
    click.echo("  Your corpus can be a local file, directory, or HuggingFace dataset.")
    if yes:
        # Generate a fast local sample corpus so init completes quickly
        sample_path = _generate_sample_corpus()
        config["source"] = sample_path
        click.echo(f"  Source: {sample_path} (built-in sample for fast setup)")
    else:
        source = click.prompt(
            "  Enter corpus source (file path, directory, or HF dataset ID)",
            default="wikitext",
        )
        config["source"] = source
        if not Path(source).exists():
            hf_config = click.prompt(
                "  HuggingFace config name (leave blank if none)",
                default="",
            )
            if hf_config:
                config["hf_config"] = hf_config
            hf_split = click.prompt("  HF split", default="train")
            config["hf_split"] = hf_split
            hf_text_field = click.prompt("  HF text field", default="text")
            config["hf_text_field"] = hf_text_field
            hf_token = click.prompt(
                "  HF access token for private datasets (leave blank if public, or set HF_TOKEN env var)",
                default="",
            )
            if hf_token:
                config["hf_token"] = hf_token
    click.echo()

    # Step 2: Domain
    click.echo("Step 2/8: Domain")
    domains = list(DOMAIN_CONFIGS.keys())
    click.echo(f"  Available domains: {', '.join(domains)}")
    click.echo("  Domains set optimized defaults for phrase discovery thresholds.")
    if yes:
        config["domain"] = None
        click.echo("  Domain: none (custom settings)")
    else:
        domain = click.prompt(
            "  Select domain (or 'none' for custom)",
            default="none",
        )
        config["domain"] = domain if domain != "none" else None
    click.echo()

    # Step 3: Vocab size
    click.echo("Step 3/8: Vocabulary Size")
    click.echo("  Larger vocab = more phrases captured, but bigger model.")
    click.echo("  Typical: 10k (small), 20k (medium), 50k (large)")
    if yes:
        config["max_vocab"] = 20000
        click.echo(f"  Vocab size: {config['max_vocab']} (default)")
    else:
        config["max_vocab"] = click.prompt(
            "  Max vocabulary size",
            default=20000,
            type=int,
        )
    click.echo()

    # Step 4: Fallback mode
    click.echo("Step 4/8: Fallback Mode")
    click.echo("  How to handle words not in vocabulary:")
    click.echo("    bpe     - BPE subword decomposition (recommended)")
    click.echo("    newword - Add unknown words to vocab dynamically")
    click.echo("    character - Character-by-character fallback")
    click.echo("    word    - Map to <unk> token")
    if yes:
        config["fallback_mode"] = "bpe"
        click.echo(f"  Fallback: {config['fallback_mode']} (default)")
    else:
        config["fallback_mode"] = click.prompt(
            "  Fallback mode",
            default="bpe",
            type=click.Choice(["bpe", "newword", "character", "word"]),
        )
    click.echo()

    # Step 5: Language
    click.echo("Step 5/8: Language")
    click.echo("  Language code for tokenization (en, de, fr, es, zh, ja, ko, etc.)")
    if yes:
        config["language"] = "en"
        click.echo(f"  Language: {config['language']} (default)")
    else:
        config["language"] = click.prompt("  Language code", default="en")
    click.echo()

    # Step 6: Vocab allocation
    click.echo("Step 6/8: Vocab Allocation")
    click.echo("  How to split vocab between phrases and words.")
    click.echo("  Default: 60% phrases, 40% words")
    if yes:
        config["phrase_target_pct"] = 60.0
        config["word_target_pct"] = 40.0
        click.echo("  Allocation: 60% phrases, 40% words (default)")
    else:
        config["phrase_target_pct"] = click.prompt(
            "  Phrase target %",
            default=60.0,
            type=float,
        )
        config["word_target_pct"] = click.prompt(
            "  Word target %",
            default=40.0,
            type=float,
        )
    click.echo()

    # Step 7: Advanced features
    click.echo("Step 7/8: Advanced Features")
    if yes:
        config["typo_correction"] = False
        config["streaming_phrases"] = False
        config["embedding_scoring"] = False
        config["max_word_length"] = 0
        config["preserve_case"] = False
        click.echo("  All advanced features: disabled (default)")
    else:
        config["typo_correction"] = click.confirm(
            "  Enable typo correction? (maps misspellings to closest vocab word)",
            default=False,
        )
        if config["typo_correction"]:
            config["typo_edit_distance"] = click.prompt(
                "    Max edit distance (1 or 2)",
                default=2,
                type=click.IntRange(1, 2),
            )

        config["streaming_phrases"] = click.confirm(
            "  Enable streaming phrase discovery? (learns new phrases during encoding)",
            default=False,
        )

        config["embedding_scoring"] = click.confirm(
            "  Enable embedding-based phrase scoring? (trains Word2Vec, improves phrase quality)",
            default=False,
        )

        mwl = click.prompt(
            "  Max word length (0 = no limit, or set a char limit for vocab words)",
            default=0,
            type=int,
        )
        config["max_word_length"] = mwl

        config["preserve_case"] = click.confirm(
            "  Preserve case? (useful for code, proper nouns)",
            default=False,
        )
    click.echo()

    # Step 8: Output
    click.echo("Step 8/8: Output")
    if yes:
        config["output"] = "tokenizer.json"
        click.echo(f"  Tokenizer output: {config['output']} (default)")
    else:
        config["output"] = click.prompt(
            "  Output path for tokenizer",
            default="tokenizer.json",
        )
    click.echo()

    # Show summary
    click.echo("=" * 60)
    click.echo("  Configuration Summary")
    click.echo("=" * 60)
    click.echo(f"  Source:          {config['source']}")
    if config.get("domain"):
        click.echo(f"  Domain:          {config['domain']}")
    click.echo(f"  Vocab size:      {config['max_vocab']:,}")
    click.echo(f"  Fallback:        {config['fallback_mode']}")
    click.echo(f"  Language:        {config['language']}")
    click.echo(f"  Phrases/Words:   {config.get('phrase_target_pct', 60)}% / {config.get('word_target_pct', 40)}%")
    if config.get("typo_correction"):
        click.echo(f"  Typo correction: enabled (distance {config.get('typo_edit_distance', 2)})")
    if config.get("streaming_phrases"):
        click.echo("  Streaming:       enabled")
    if config.get("embedding_scoring"):
        click.echo("  Embedding score: enabled")
    if config.get("max_word_length", 0) > 0:
        click.echo(f"  Max word length: {config['max_word_length']}")
    if config.get("preserve_case"):
        click.echo("  Preserve case:   yes")
    click.echo(f"  Output:          {config['output']}")
    click.echo("=" * 60)

    # Save config file
    config_path = Path(output)
    config_path.write_bytes(orjson.dumps(config, option=orjson.OPT_INDENT_2))
    click.echo(f"\nConfig saved to: {config_path}")

    # Ask to build now
    if yes:
        build_now = True
    else:
        build_now = click.confirm("\nBuild tokenizer now?", default=True)

    if build_now:
        click.echo("\nBuilding tokenizer...")
        t0 = time.time()

        build_kwargs = {
            "source": config["source"],
            "output": config["output"],
            "max_vocab_size": config["max_vocab"],
            "fallback_mode": config["fallback_mode"],
            "language": config["language"],
            "phrase_target_pct": config.get("phrase_target_pct", 60.0),
            "word_target_pct": config.get("word_target_pct", 40.0),
            "preserve_case": config.get("preserve_case", False),
            "max_word_length": config.get("max_word_length", 0),
            "typo_correction": config.get("typo_correction", False),
            "typo_edit_distance": config.get("typo_edit_distance", 2),
            "streaming_phrases": config.get("streaming_phrases", False),
            "embedding_scoring": config.get("embedding_scoring", False),
        }

        if config.get("hf_config"):
            build_kwargs["hf_config"] = config["hf_config"]
        if config.get("hf_split"):
            build_kwargs["hf_split"] = config["hf_split"]
        if config.get("hf_text_field"):
            build_kwargs["hf_text_field"] = config["hf_text_field"]
        if config.get("hf_token"):
            build_kwargs["hf_token"] = config["hf_token"]

        # Apply domain config if set
        if config.get("domain"):
            domain_cfg = get_domain_config(config["domain"])
            build_kwargs["min_word_freq"] = domain_cfg.get("min_word_freq", 3)
            build_kwargs["min_phrase_freq"] = domain_cfg.get("min_phrase_freq", 5)

        build_kwargs["license_config"] = license_config

        try:
            stats = build_tokenizer(**build_kwargs)
            elapsed = time.time() - t0

            click.echo(f"\nTokenizer built in {elapsed:.1f}s")
            click.echo(f"  Saved to: {config['output']}")
            click.echo(f"  Vocab size: {stats.get('vocab_size', 'N/A'):,}")
            click.echo(f"  Phrases: {stats.get('phrase_count', 'N/A'):,}")
            click.echo(f"  Words: {stats.get('word_count', 'N/A'):,}")
            if stats.get("typo_correction"):
                click.echo(f"  Typo correction: enabled")
            if stats.get("streaming_phrases"):
                click.echo(f"  Streaming phrases: enabled")
            if stats.get("embedding_scoring"):
                click.echo(f"  Embedding scoring: enabled")

            click.echo(f"\nNext steps:")
            click.echo(f"  ion stats -t {config['output']}")
            click.echo(f"  ion benchmark {config['source']} -v {config['max_vocab']}")
            click.echo(f"  ion export -t {config['output']} -f huggingface -o ./my_tokenizer/")
        except Exception as e:
            click.echo(f"\nBuild failed: {e}", err=True)
            click.echo("You can build later with:")
            _print_build_command(config)
            sys.exit(1)
    else:
        click.echo("\nTo build later, run:")
        _print_build_command(config)
        click.echo(f"\nOr rebuild from config:")
        click.echo(f"  ion build-from-config {config_path}")


def _generate_sample_corpus() -> str:
    """Generate a small built-in sample corpus for fast init demos."""
    import tempfile
    sample_text = """The United States of America is a federal republic composed of 50 states.
Machine learning algorithms process large amounts of data to identify patterns.
Natural language processing enables computers to understand human language.
The quick brown fox jumps over the lazy dog near the old stone bridge.
Artificial intelligence research has made significant progress in recent years.
Deep learning models require substantial computational resources for training.
The stock market experienced volatility due to changing economic conditions.
Climate change poses serious challenges for environmental sustainability efforts.
Open source software development encourages collaboration among developers worldwide.
The Supreme Court issued a landmark ruling on digital privacy rights today.
Neural networks consist of interconnected layers of artificial neurons.
Quantum computing promises to revolutionize cryptography and drug discovery.
The World Health Organization declared a global health emergency last month.
Renewable energy sources include solar power and wind turbines for electricity.
The European Union implemented new data protection regulations this year.
Software engineers use version control systems like git for collaboration.
Public health officials recommend regular exercise and balanced nutrition.
The International Space Station orbits Earth at approximately 400 kilometers altitude.
Blockchain technology enables secure decentralized transaction verification systems.
University researchers published groundbreaking findings in Nature this week.
The central bank raised interest rates to combat rising inflation pressures.
Autonomous vehicles rely on sensor fusion and computer vision algorithms.
The United Nations General Assembly convened to discuss peacekeeping operations.
Social media platforms face increasing scrutiny over content moderation policies.
Cybersecurity threats continue to evolve as attackers develop new techniques.
The pharmaceutical industry invested billions in vaccine development programs.
Cloud computing services provide scalable infrastructure for modern applications.
The housing market showed signs of recovery after months of decline.
Genetic engineering tools like CRISPR enable precise DNA modification techniques.
International trade agreements shape global economic relationships between nations.
The film industry adapted to streaming platforms and changing viewer habits.
Robotics and automation are transforming manufacturing and logistics operations.
The education system is incorporating more technology into classroom learning.
Environmental scientists monitor biodiversity loss in tropical rainforest ecosystems.
The tech industry continues to drive innovation in consumer electronics.
Healthcare providers are adopting electronic medical records for patient care.
Space exploration missions aim to establish a permanent lunar base soon.
The agricultural sector faces challenges from drought and soil degradation.
Cryptocurrency markets experienced significant price fluctuations this quarter.
Government agencies are modernizing their digital infrastructure and services.
"""
    fd, path = tempfile.mkstemp(suffix=".txt", prefix="ion_sample_")
    with os.fdopen(fd, "w") as f:
        # Write the sample text multiple times for enough data
        for _ in range(25):
            f.write(sample_text)
    return path


def _print_build_command(config: dict):
    """Print the equivalent ion tokenize command for a config."""
    parts = [f"  ion tokenize {config['source']}"]
    parts.append(f"-o {config['output']}")
    parts.append(f"-v {config['max_vocab']}")
    if config.get("fallback_mode") == "bpe":
        parts.append("--dangerously-enable-bpe-fallback")
    else:
        parts.append(f"-fm {config['fallback_mode']}")
    if config.get("keep_json"):
        parts.append("--keep-json")
    if config.get("language", "en") != "en":
        parts.append(f"-l {config['language']}")
    if config.get("phrase_target_pct", 60.0) != 60.0:
        parts.append(f"-pp {config['phrase_target_pct']}")
    if config.get("word_target_pct", 40.0) != 40.0:
        parts.append(f"-wp {config['word_target_pct']}")
    if config.get("typo_correction"):
        parts.append("-tc")
        if config.get("typo_edit_distance", 2) != 2:
            parts.append(f"-ted {config['typo_edit_distance']}")
    if config.get("streaming_phrases"):
        parts.append("-sp")
    if config.get("embedding_scoring"):
        parts.append("-es")
    if config.get("max_word_length", 0) > 0:
        parts.append(f"-mwl {config['max_word_length']}")
    if config.get("preserve_case"):
        parts.append("-pc")
    if config.get("hf_config"):
        parts.append(f"--hf-config {config['hf_config']}")
    click.echo(" ".join(parts))


@main.command()
@click.argument("source")
@click.option(
    "-o", "--output",
    default="tokenizer.json",
    help="Output path for tokenizer.json",
)
@click.option(
    "-v", "--max-vocab",
    default=20000,
    type=int,
    help="Maximum vocabulary size (no hard cap, default: 20000)",
)
@click.option(
    "-tn", "--take-needed",
    is_flag=True,
    default=False,
    help="Take-needed mode: include ALL words and ALL discovered phrases (ignores --max-vocab)",
)
@click.option(
    "--min-word-freq",
    default=1,
    type=int,
    help="Minimum frequency for word inclusion (default: 1 for max coverage)",
)
@click.option(
    "--min-phrase-freq",
    default=3,
    type=int,
    help="Minimum frequency for phrase inclusion (default: 3)",
)
@click.option(
    "--phrase-threshold",
    default=0.001,
    type=float,
    help="Score threshold for phrase detection (default: 0.001)",
)
@click.option(
    "--max-phrase-layers",
    default=4,
    type=int,
    help="Maximum phrase discovery layers for longer n-grams (default: 4)",
)
@click.option(
    "-n", "--max-sentences",
    default=1_000_000,
    type=int,
    help="Maximum sentences to process",
)
@click.option(
    "--hf-split",
    default="train",
    help="HuggingFace dataset split",
)
@click.option(
    "--hf-text-field",
    default="text",
    help="HuggingFace dataset text field name",
)
@click.option(
    "--max-samples",
    default=None,
    type=int,
    help="Maximum samples from HuggingFace dataset",
)
@click.option(
    "--hf-config",
    default=None,
    help="HuggingFace dataset config name (e.g., 'sample-10BT' for fineweb)",
)
@click.option(
    "-re", "--remove-emphasis",
    is_flag=True,
    default=False,
    help="Remove emphasis words (very, really, extremely, etc.)",
)
@click.option(
    "-cp", "--collapse-punctuation",
    is_flag=True,
    default=False,
    help="Collapse duplicate punctuation (!!!! -> !, ???? -> ?, etc.)",
)
@click.option(
    "-d", "--domain",
    type=click.Choice(["general", "wikipedia", "code", "legal", "chat", "medical", "scientific"]),
    default=None,
    help="Apply a domain preset that tunes phrase discovery for a specific content type "
         "(e.g. wikipedia, code, legal). Overrides phrase threshold, frequency, layer, "
         "filter, and booster settings. Run 'ion domains' to see all presets and what they do.",
)
@click.option(
    "-s", "--seed",
    default=None,
    type=int,
    help="Random seed for reproducibility",
)
@click.option(
    "--snapshot",
    default=None,
    help="Save reproducibility snapshot to this path",
)
@click.option(
    "--language", "-l",
    default="en",
    help="Language code for tokenization (en, de, fr, es, zh, ja, ko, ru, ar, etc.)",
)
@click.option(
    "-pc", "--preserve-case",
    is_flag=True,
    default=False,
    help="Preserve case in tokens (useful for code, proper nouns, CamelCase)",
)
@click.option(
    "-pp", "--phrase-target-pct",
    default=60.0,
    type=float,
    help="Target percentage of vocab for phrases (default: 60%)",
)
@click.option(
    "-wp", "--word-target-pct",
    default=40.0,
    type=float,
    help="Target percentage of vocab for words (default: 40%)",
)
@click.option(
    "-fm", "--fallback-mode",
    type=click.Choice(["newword", "character", "word"]),
    default="character",
    help="Fallback mode for unknown words: character (default), newword (add to vocab), word (<unk>). Use --dangerously-enable-bpe-fallback for BPE.",
)
@click.option(
    "--dangerously-enable-bpe-fallback",
    is_flag=True,
    default=False,
    help="Enable BPE subword fallback for unknown words. Overrides --fallback-mode to 'bpe'.",
)
@click.option(
    "--keep-json",
    is_flag=True,
    default=False,
    help="Keep JSON-structured content in the corpus instead of filtering it out.",
)
@click.option(
    "-mwl", "--max-word-length", "--length-limit",
    default=0,
    type=int,
    help="Max word length to add as whole token; longer words use BPE fallback (0=disabled, default: 0)",
)
@click.option(
    "-tc", "--typo-correction",
    is_flag=True,
    default=False,
    help="Enable typo correction layer (maps misspellings to closest vocab word)",
)
@click.option(
    "-ted", "--typo-edit-distance",
    default=2,
    type=click.IntRange(1, 2),
    help="Max edit distance for typo correction (1 or 2, default: 2)",
)
@click.option(
    "-sp", "--streaming-phrases",
    is_flag=True,
    default=False,
    help="Enable streaming phrase discovery during encoding",
)
@click.option(
    "-es", "--embedding-scoring",
    is_flag=True,
    default=False,
    help="Use learned embedding-based phrase scoring (trains Word2Vec on corpus)",
)
@click.option(
    "--hf-token",
    default=None,
    help="HuggingFace access token for private datasets (or set HF_TOKEN env var)",
)
def tokenize(
    source: str,
    output: str,
    max_vocab: int,
    take_needed: bool,
    min_word_freq: int,
    min_phrase_freq: int,
    phrase_threshold: float,
    max_phrase_layers: int,
    max_sentences: int,
    hf_split: str,
    hf_text_field: str,
    max_samples: int,
    hf_config: str,
    remove_emphasis: bool,
    collapse_punctuation: bool,
    domain: str,
    seed: int,
    snapshot: str,
    language: str,
    preserve_case: bool,
    phrase_target_pct: float,
    word_target_pct: float,
    fallback_mode: str,
    dangerously_enable_bpe_fallback: bool,
    keep_json: bool,
    max_word_length: int,
    typo_correction: bool,
    typo_edit_distance: int,
    streaming_phrases: bool,
    embedding_scoring: bool,
    hf_token: str,
):
    """
    Build tokenizer from corpus.

    SOURCE can be:
    - HuggingFace dataset identifier (e.g., "wikitext")
    - Local text file path
    - Local directory containing text files

    Use -tn/--take-needed to include ALL words and ALL phrases (ignores vocab limit).
    Use --domain to apply domain-specific optimizations.
    Use --seed for reproducible builds.
    """
    # Override fallback_mode if BPE flag is set
    if dangerously_enable_bpe_fallback:
        fallback_mode = "bpe"
        click.echo("WARNING: BPE fallback enabled via --dangerously-enable-bpe-fallback")

    # Ensure registration
    from .licensing import ensure_registered
    license_config = ensure_registered()

    # Apply domain-specific configuration
    if domain:
        domain_config = get_domain_config(domain)
        click.echo(f"Applying domain preset: {domain}")
        click.echo(f"  {domain_config['description']}")
        min_word_freq = domain_config["min_word_freq"]
        min_phrase_freq = domain_config["min_phrase_freq"]
        phrase_threshold = domain_config["phrase_threshold"]
        max_phrase_layers = domain_config["max_phrase_layers"]
        remove_emphasis = domain_config["remove_emphasis"]
        collapse_punctuation = domain_config["collapse_punctuation"]
        # Domain can override preserve_case (e.g., code domain)
        if domain_config.get("preserve_case"):
            preserve_case = True

    # Set seed for reproducibility
    if seed is not None:
        set_seed(seed)
        click.echo(f"Random seed: {seed}")

    # Auto-detect language and code if requested
    if language == "auto":
        click.echo("Auto-detecting language and content type...")
        from .corpus import detect_language, detect_if_code, load_corpus as _load_corpus

        # Sample some text for detection
        _samples = []
        _count = 0
        try:
            for sent in _load_corpus(
                source, hf_split=hf_split, hf_text_field=hf_text_field,
                max_samples=max_samples, hf_config=hf_config,
            ):
                _samples.append(" ".join(sent))
                _count += 1
                if _count >= 500:
                    break
        except Exception:
            pass

        if _samples:
            detected_lang = detect_language(_samples)
            is_code = detect_if_code(_samples)
            language = detected_lang
            click.echo(f"  Detected language: {language}")
            if is_code:
                click.echo("  Detected content type: source code")
                preserve_case = True
                if not domain:
                    domain = "code"
                    domain_config = get_domain_config(domain)
                    click.echo(f"  Auto-applying domain preset: code")
                    min_word_freq = domain_config["min_word_freq"]
                    min_phrase_freq = domain_config["min_phrase_freq"]
                    phrase_threshold = domain_config["phrase_threshold"]
                    max_phrase_layers = domain_config["max_phrase_layers"]
                    remove_emphasis = domain_config["remove_emphasis"]
                    collapse_punctuation = domain_config["collapse_punctuation"]
        else:
            language = "en"
            click.echo("  Could not detect language, defaulting to: en")

    if language != "en":
        click.echo(f"Language: {language}")
    if preserve_case:
        click.echo("Case preservation: enabled")
    if fallback_mode != "bpe":
        click.echo(f"Fallback mode: {fallback_mode}")
    if max_word_length > 0:
        click.echo(f"Max word length: {max_word_length} (longer words use BPE fallback)")
    if phrase_target_pct != 60.0 or word_target_pct != 40.0:
        click.echo(f"Vocab allocation: {phrase_target_pct:.0f}% phrases, {word_target_pct:.0f}% words")
    if typo_correction:
        click.echo(f"Typo correction: enabled (max edit distance: {typo_edit_distance})")
    if streaming_phrases:
        click.echo("Streaming phrase discovery: enabled")
    if embedding_scoring:
        click.echo("Embedding-based phrase scoring: enabled (training Word2Vec)")
    if keep_json:
        click.echo("JSON content: preserved (--keep-json)")

    t0 = time.time()
    stats = build_tokenizer(
        source=source,
        output=output,
        max_vocab_size=max_vocab,
        min_word_freq=min_word_freq,
        min_phrase_freq=min_phrase_freq,
        phrase_threshold=phrase_threshold,
        max_phrase_layers=max_phrase_layers,
        max_sentences=max_sentences,
        hf_split=hf_split,
        hf_text_field=hf_text_field,
        max_samples=max_samples,
        hf_config=hf_config,
        remove_emphasis=remove_emphasis,
        collapse_punctuation=collapse_punctuation,
        take_needed=take_needed,
        language=language,
        preserve_case=preserve_case,
        phrase_target_pct=phrase_target_pct,
        word_target_pct=word_target_pct,
        fallback_mode=fallback_mode,
        max_word_length=max_word_length,
        typo_correction=typo_correction,
        typo_edit_distance=typo_edit_distance,
        streaming_phrases=streaming_phrases,
        embedding_scoring=embedding_scoring,
        hf_token=hf_token,
        license_config=license_config,
        keep_json=keep_json,
    )
    elapsed = time.time() - t0

    click.echo(f"\nTokenizer saved to: {output}")
    if stats.get('mode') == 'take_needed':
        click.echo(f"Mode: TAKE-NEEDED (all words + all phrases)")
    if domain:
        click.echo(f"Domain: {domain}")
    click.echo(f"Fallback mode: {stats.get('fallback_mode', fallback_mode)}")
    click.echo(f"Vocabulary size: {stats['vocab_size']:,}")
    click.echo(f"Phrase tokens: {stats['phrase_count']:,}")
    click.echo(f"Word tokens: {stats['word_count']:,}")
    click.echo(f"Sequence length reduction: {stats.get('sequence_length_reduction_pct', 0):.2f}%")
    click.echo(f"Compression ratio: {stats.get('compression_ratio', 1):.2f}x")
    click.echo(f"Build time: {elapsed:.1f}s")

    # Save reproducibility snapshot if requested
    if snapshot:
        config = {
            "max_vocab_size": max_vocab,
            "min_word_freq": min_word_freq,
            "min_phrase_freq": min_phrase_freq,
            "phrase_threshold": phrase_threshold,
            "max_phrase_layers": max_phrase_layers,
            "take_needed": take_needed,
            "domain": domain,
        }
        create_reproducibility_snapshot(output, source, seed or 0, config, snapshot)
        click.echo(f"Reproducibility snapshot saved to: {snapshot}")


@main.command()
@click.option(
    "-t", "--tokenizer",
    default="tokenizer.json",
    help="Path to tokenizer.json",
)
@click.option(
    "-c", "--corpus",
    default=None,
    help="Optional corpus to analyze compression",
)
@click.option(
    "--hf-split",
    default="train",
    help="HuggingFace dataset split",
)
@click.option(
    "--hf-text-field",
    default="text",
    help="HuggingFace dataset text field",
)
@click.option(
    "-n", "--max-samples",
    default=10000,
    type=int,
    help="Maximum samples for analysis",
)
@click.option(
    "--hf-config",
    default=None,
    help="HuggingFace dataset config name",
)
def stats(
    tokenizer: str,
    corpus: str,
    hf_split: str,
    hf_text_field: str,
    max_samples: int,
    hf_config: str,
):
    """Report tokenizer statistics and compression metrics."""
    try:
        result = compute_stats(
            tokenizer_path=tokenizer,
            corpus_source=corpus,
            hf_split=hf_split,
            hf_text_field=hf_text_field,
            max_samples=max_samples,
            hf_config=hf_config,
        )
        click.echo(format_stats(result))
    except FileNotFoundError:
        click.echo(f"Error: tokenizer file not found: {tokenizer}", err=True)
        sys.exit(1)


@main.command()
@click.argument("source")
@click.option(
    "-t", "--tokenizer",
    default="tokenizer.json",
    help="Path to existing tokenizer.json to iterate on",
)
@click.option(
    "-o", "--output",
    default="tokenizer.json",
    help="Output path for updated tokenizer.json",
)
@click.option(
    "-n", "--max-sentences",
    default=100_000,
    type=int,
    help="Maximum sentences to process from new corpus",
)
@click.option(
    "--hf-split",
    default="train",
    help="HuggingFace dataset split",
)
@click.option(
    "--hf-text-field",
    default="text",
    help="HuggingFace dataset text field name",
)
@click.option(
    "--max-samples",
    default=None,
    type=int,
    help="Maximum samples from HuggingFace dataset",
)
@click.option(
    "--hf-config",
    default=None,
    help="HuggingFace dataset config name",
)
@click.option(
    "-re", "--remove-emphasis",
    is_flag=True,
    default=False,
    help="Remove emphasis words (very, really, extremely, etc.)",
)
@click.option(
    "-cp", "--collapse-punctuation",
    is_flag=True,
    default=False,
    help="Collapse duplicate punctuation (!!!! -> !, ???? -> ?, etc.)",
)
@click.option(
    "-np", "--no-phrases",
    is_flag=True,
    default=False,
    help="Don't add new phrases, only words",
)
@click.option(
    "-nw", "--no-words",
    is_flag=True,
    default=False,
    help="Don't add new words, only phrases",
)
def iterate(
    source: str,
    tokenizer: str,
    output: str,
    max_sentences: int,
    hf_split: str,
    hf_text_field: str,
    max_samples: int,
    hf_config: str,
    remove_emphasis: bool,
    collapse_punctuation: bool,
    no_phrases: bool,
    no_words: bool,
):
    """
    Iterate on existing tokenizer with new corpus data.

    Adapts an existing tokenizer to a new dataset by discovering
    and adding new phrases and words while preserving the existing vocabulary.

    SOURCE can be:
    - HuggingFace dataset identifier
    - Local text file path
    - Local directory containing text files
    """
    try:
        stats = iterate_tokenizer(
            tokenizer_path=tokenizer,
            source=source,
            output=output,
            max_sentences=max_sentences,
            hf_split=hf_split,
            hf_text_field=hf_text_field,
            max_samples=max_samples,
            hf_config=hf_config,
            remove_emphasis=remove_emphasis,
            collapse_punctuation=collapse_punctuation,
            add_phrases=not no_phrases,
            add_words=not no_words,
        )

        click.echo(f"\nTokenizer updated: {output}")
        click.echo(f"Sentences processed: {stats['sentences_processed']:,}")
        click.echo(f"Existing phrases: {stats['existing_phrases']:,}")
        click.echo(f"Existing words: {stats['existing_words']:,}")
        click.echo(f"New phrases added: {stats['new_phrases_added']:,}")
        click.echo(f"New words added: {stats['new_words_added']:,}")
        click.echo(f"Final vocab size: {stats['final_vocab_size']:,}")
    except FileNotFoundError:
        click.echo(f"Error: tokenizer file not found: {tokenizer}", err=True)
        sys.exit(1)


@main.command()
@click.argument("input_path")
@click.option(
    "-o", "--output",
    default=None,
    help="Output path (default: input_path.cleaned.txt)",
)
@click.option(
    "--no-lowercase",
    is_flag=True,
    default=False,
    help="Don't convert to lowercase",
)
@click.option(
    "-re", "--remove-emphasis",
    is_flag=True,
    default=False,
    help="Remove emphasis words (very, really, extremely, etc.)",
)
@click.option(
    "-cp", "--collapse-punctuation",
    is_flag=True,
    default=False,
    help="Collapse duplicate punctuation",
)
@click.option(
    "--expand-contractions",
    is_flag=True,
    default=False,
    help="Expand contractions (can't -> cannot, etc.)",
)
@click.option(
    "--strip-urls",
    is_flag=True,
    default=False,
    help="Remove URLs from text",
)
@click.option(
    "--strip-emails",
    is_flag=True,
    default=False,
    help="Remove email addresses from text",
)
@click.option(
    "--strip-html",
    is_flag=True,
    default=False,
    help="Remove HTML tags from text",
)
@click.option(
    "--strip-special",
    is_flag=True,
    default=False,
    help="Remove special characters (keep basic punctuation)",
)
@click.option(
    "--strip-numbers",
    is_flag=True,
    default=False,
    help="Remove standalone numbers",
)
@click.option(
    "--remove-fillers",
    is_flag=True,
    default=False,
    help="Remove filler words (um, like, you know, etc.)",
)
@click.option(
    "--remove-discourse",
    is_flag=True,
    default=False,
    help="Remove discourse markers (however, therefore, etc.)",
)
@click.option(
    "--semantic-normalize",
    is_flag=True,
    default=False,
    help="Normalize phrases to canonical forms (gonna->going to, a lot of->many)",
)
@click.option(
    "--normalize-numbers",
    is_flag=True,
    default=False,
    help="Normalize numbers to generic tokens (<num>, <year>, etc.)",
)
@click.option(
    "--remove-parens",
    is_flag=True,
    default=False,
    help="Remove parenthetical expressions",
)
@click.option(
    "--simplify-punct",
    is_flag=True,
    default=False,
    help="Simplify punctuation to canonical forms",
)
@click.option(
    "--deduplicate",
    is_flag=True,
    default=False,
    help="Remove adjacent duplicate words",
)
@click.option(
    "--remove-redundant",
    is_flag=True,
    default=False,
    help="Remove redundant modifiers (very unique -> unique)",
)
@click.option(
    "--remove-stopwords",
    is_flag=True,
    default=False,
    help="Aggressively remove common stopwords (the, a, is, etc.)",
)
@click.option(
    "--remove-starters",
    is_flag=True,
    default=False,
    help="Remove unnecessary sentence starters (well, so, anyway)",
)
@click.option(
    "--simplify-redundant",
    is_flag=True,
    default=False,
    help="Simplify redundant phrases (end result -> result)",
)
@click.option(
    "--strip-quotes",
    is_flag=True,
    default=False,
    help="Remove quotation marks",
)
@click.option(
    "--flatten-case",
    is_flag=True,
    default=False,
    help="Flatten ALL CAPS and MiXeD CaSe to lowercase",
)
@click.option(
    "--aggressive",
    is_flag=True,
    default=False,
    help="Apply standard cleaning (URLs, emails, HTML, emphasis, contractions)",
)
@click.option(
    "--maximum",
    is_flag=True,
    default=False,
    help="Apply ALL cleaning options for maximum sequence length reduction",
)
@click.option(
    "--extreme",
    is_flag=True,
    default=False,
    help="EXTREME compression: includes stopword removal (may lose meaning)",
)
def clean(
    input_path: str,
    output: str,
    no_lowercase: bool,
    remove_emphasis: bool,
    collapse_punctuation: bool,
    expand_contractions: bool,
    strip_urls: bool,
    strip_emails: bool,
    strip_html: bool,
    strip_special: bool,
    strip_numbers: bool,
    remove_fillers: bool,
    remove_discourse: bool,
    semantic_normalize: bool,
    normalize_numbers: bool,
    remove_parens: bool,
    simplify_punct: bool,
    deduplicate: bool,
    remove_redundant: bool,
    remove_stopwords: bool,
    remove_starters: bool,
    simplify_redundant: bool,
    strip_quotes: bool,
    flatten_case: bool,
    aggressive: bool,
    maximum: bool,
    extreme: bool,
):
    """
    Clean and preprocess text files for tokenizer training.

    INPUT_PATH can be a single file or directory of .txt files.

    Presets:
      --aggressive: Standard cleaning (URLs, HTML, emails, emphasis, contractions)
      --maximum: ALL options enabled for maximum sequence length reduction
      --extreme: EXTREME mode with stopword removal (may lose semantic meaning)

    Maximum mode applies: semantic normalization, filler/discourse removal,
    number normalization, parenthetical removal, punctuation simplification,
    and word deduplication - achieving the highest possible compression.
    """
    input_p = Path(input_path)

    if extreme:
        # EXTREME: all maximum options PLUS stopword removal
        remove_emphasis = True
        collapse_punctuation = True
        expand_contractions = True
        strip_urls = True
        strip_emails = True
        strip_html = True
        remove_fillers = True
        remove_discourse = True
        semantic_normalize = True
        normalize_numbers = True
        remove_parens = True
        simplify_punct = True
        deduplicate = True
        remove_redundant = True
        remove_stopwords = True
        remove_starters = True
        simplify_redundant = True
        strip_quotes = True
        flatten_case = True
    elif maximum:
        # Enable ALL cleaning options for maximum sequence reduction
        remove_emphasis = True
        collapse_punctuation = True
        expand_contractions = True
        strip_urls = True
        strip_emails = True
        strip_html = True
        remove_fillers = True
        remove_discourse = True
        semantic_normalize = True
        normalize_numbers = True
        remove_parens = True
        simplify_punct = True
        deduplicate = True
        remove_redundant = True
        remove_starters = True
        simplify_redundant = True
        strip_quotes = True
        flatten_case = True
    elif aggressive:
        # Standard aggressive cleaning
        remove_emphasis = True
        collapse_punctuation = True
        expand_contractions = True
        strip_urls = True
        strip_emails = True
        strip_html = True
        simplify_punct = True

    clean_options = {
        'lowercase': not no_lowercase,
        'normalize_chars': True,
        'remove_emphasis': remove_emphasis,
        'collapse_punct': collapse_punctuation,
        'expand_contract': expand_contractions,
        'strip_urls': strip_urls,
        'strip_emails': strip_emails,
        'strip_html': strip_html,
        'strip_special': strip_special,
        'strip_numbers': strip_numbers,
        'remove_fillers': remove_fillers,
        'remove_discourse': remove_discourse,
        'semantic_normalize': semantic_normalize,
        'normalize_nums': normalize_numbers,
        'remove_parens': remove_parens,
        'simplify_punct': simplify_punct,
        'deduplicate': deduplicate,
        'remove_redundant': remove_redundant,
        'remove_stopwords_flag': remove_stopwords,
        'remove_starters': remove_starters,
        'simplify_redundant': simplify_redundant,
        'strip_quotes': strip_quotes,
        'flatten_case': flatten_case,
    }

    if input_p.is_file():
        # Single file
        if output is None:
            output = str(input_p.with_suffix('.cleaned.txt'))

        stats = clean_file(input_path, output, **clean_options)
        click.echo(f"Cleaned: {stats['input_path']}")
        click.echo(f"Output:  {stats['output_path']}")
        click.echo(f"Original: {stats['original_chars']:,} chars")
        click.echo(f"Cleaned:  {stats['cleaned_chars']:,} chars")
        click.echo(f"Reduction: {stats['reduction_pct']:.2f}%")

    elif input_p.is_dir():
        # Directory of files
        if output is None:
            output_dir = input_p / "cleaned"
        else:
            output_dir = Path(output)

        output_dir.mkdir(parents=True, exist_ok=True)

        total_original = 0
        total_cleaned = 0
        file_count = 0

        for fpath in input_p.rglob("*.txt"):
            if "cleaned" in str(fpath):
                continue  # Skip already cleaned files

            rel_path = fpath.relative_to(input_p)
            out_path = output_dir / rel_path

            out_path.parent.mkdir(parents=True, exist_ok=True)

            stats = clean_file(str(fpath), str(out_path), **clean_options)
            total_original += stats['original_chars']
            total_cleaned += stats['cleaned_chars']
            file_count += 1

            if file_count <= 5:
                click.echo(f"  Cleaned: {fpath.name}")

        if file_count > 5:
            click.echo(f"  ... and {file_count - 5} more files")

        reduction = (total_original - total_cleaned) / max(total_original, 1) * 100
        click.echo(f"\nTotal files: {file_count:,}")
        click.echo(f"Output dir:  {output_dir}")
        click.echo(f"Original: {total_original:,} chars")
        click.echo(f"Cleaned:  {total_cleaned:,} chars")
        click.echo(f"Reduction: {reduction:.2f}%")
    else:
        click.echo(f"Error: path not found: {input_path}", err=True)
        sys.exit(1)


@main.command()
@click.argument("input_path")
@click.option(
    "-t", "--tokenizer",
    default="tokenizer.json",
    help="Path to tokenizer.json to use for encoding",
)
@click.option(
    "-o", "--output",
    default=None,
    help="Output path for encoded file (default: input_path.tokens)",
)
@click.option(
    "-F", "--format",
    "output_format",
    type=click.Choice(["ids", "tokens", "both"]),
    default="ids",
    help="Output format: ids (token IDs), tokens (text), or both",
)
def retokenize(
    input_path: str,
    tokenizer: str,
    output: str,
    output_format: str,
):
    """
    Re-encode text using a tokenizer.

    Reads INPUT_PATH and encodes it using the specified tokenizer,
    outputting token IDs or token text.
    """
    from .tokenizer import IonTokenizer

    try:
        tokenizer_data = orjson.loads(Path(tokenizer).read_bytes())
        tok = IonTokenizer.from_dict(tokenizer_data)
    except FileNotFoundError:
        click.echo(f"Error: tokenizer file not found: {tokenizer}", err=True)
        sys.exit(1)

    input_p = Path(input_path)
    if not input_p.exists():
        click.echo(f"Error: input file not found: {input_path}", err=True)
        sys.exit(1)

    text = input_p.read_text(encoding="utf-8", errors="ignore")
    encoded = tok.encode(text)

    if output is None:
        output = str(input_p.with_suffix(".tokens"))

    output_lines = []
    if output_format == "ids":
        output_lines.append(" ".join(str(id) for id in encoded))
    elif output_format == "tokens":
        output_lines.append(" ".join(tok.id_to_token.get(id, "<unk>") for id in encoded))
    else:  # both
        output_lines.append("IDs: " + " ".join(str(id) for id in encoded))
        output_lines.append("Tokens: " + " ".join(tok.id_to_token.get(id, "<unk>") for id in encoded))

    Path(output).write_text("\n".join(output_lines), encoding="utf-8")

    original_words = len(text.split())
    click.echo(f"Input: {input_path}")
    click.echo(f"Tokenizer: {tokenizer}")
    click.echo(f"Output: {output}")
    click.echo(f"Original words: {original_words:,}")
    click.echo(f"Encoded tokens: {len(encoded):,}")
    if original_words > 0:
        reduction = (original_words - len(encoded)) / original_words * 100
        click.echo(f"Reduction: {reduction:.2f}%")


@main.command()
@click.argument("tokenizer1")
@click.argument("tokenizer2")
@click.option(
    "-c", "--corpus",
    default=None,
    help="Optional corpus to analyze compression differences",
)
@click.option(
    "--hf-split",
    default="train",
    help="HuggingFace dataset split",
)
@click.option(
    "--hf-text-field",
    default="text",
    help="HuggingFace dataset text field",
)
@click.option(
    "-n", "--max-samples",
    default=10000,
    type=int,
    help="Maximum samples for analysis",
)
@click.option(
    "--hf-config",
    default=None,
    help="HuggingFace dataset config name",
)
def compare(
    tokenizer1: str,
    tokenizer2: str,
    corpus: str,
    hf_split: str,
    hf_text_field: str,
    max_samples: int,
    hf_config: str,
):
    """
    Compare two tokenizers.

    Shows vocabulary differences and compression statistics for both tokenizers.
    Optionally analyzes compression on a shared corpus.
    """
    from .tokenizer import IonTokenizer

    # Load both tokenizers
    try:
        data1 = orjson.loads(Path(tokenizer1).read_bytes())
        tok1 = IonTokenizer.from_dict(data1)
    except FileNotFoundError:
        click.echo(f"Error: tokenizer file not found: {tokenizer1}", err=True)
        sys.exit(1)

    try:
        data2 = orjson.loads(Path(tokenizer2).read_bytes())
        tok2 = IonTokenizer.from_dict(data2)
    except FileNotFoundError:
        click.echo(f"Error: tokenizer file not found: {tokenizer2}", err=True)
        sys.exit(1)

    # Basic comparison
    click.echo("=" * 60)
    click.echo("TOKENIZER COMPARISON")
    click.echo("=" * 60)
    click.echo(f"\n{'Metric':<30} {'Tokenizer 1':>12} {'Tokenizer 2':>12}")
    click.echo("-" * 60)

    vocab1 = tok1.vocab_size()
    vocab2 = tok2.vocab_size()
    click.echo(f"{'Vocabulary size':<30} {vocab1:>12,} {vocab2:>12,}")

    phrases1 = len(tok1.token_classes["phrase"])
    phrases2 = len(tok2.token_classes["phrase"])
    click.echo(f"{'Phrase tokens':<30} {phrases1:>12,} {phrases2:>12,}")

    words1 = len(tok1.token_classes["word"])
    words2 = len(tok2.token_classes["word"])
    click.echo(f"{'Word tokens':<30} {words1:>12,} {words2:>12,}")

    # Phrase overlap analysis
    phrases_set1 = set(tok1.token_classes["phrase"])
    phrases_set2 = set(tok2.token_classes["phrase"])
    shared_phrases = phrases_set1 & phrases_set2
    unique_to_1 = phrases_set1 - phrases_set2
    unique_to_2 = phrases_set2 - phrases_set1

    click.echo(f"\n{'Shared phrases':<30} {len(shared_phrases):>12,}")
    click.echo(f"{'Unique to tokenizer 1':<30} {len(unique_to_1):>12,}")
    click.echo(f"{'Unique to tokenizer 2':<30} {len(unique_to_2):>12,}")

    # Show some unique phrases
    if unique_to_1:
        click.echo(f"\nSample phrases unique to tokenizer 1:")
        for phrase in list(unique_to_1)[:5]:
            click.echo(f"  - {phrase}")

    if unique_to_2:
        click.echo(f"\nSample phrases unique to tokenizer 2:")
        for phrase in list(unique_to_2)[:5]:
            click.echo(f"  - {phrase}")

    # Corpus comparison if provided
    if corpus:
        click.echo("\n" + "=" * 60)
        click.echo("CORPUS COMPRESSION COMPARISON")
        click.echo("=" * 60)

        from .corpus import load_corpus

        sentences = []
        count = 0
        for sent in load_corpus(
            corpus,
            hf_split=hf_split,
            hf_text_field=hf_text_field,
            hf_config=hf_config,
        ):
            sentences.append(" ".join(sent))
            count += 1
            if count >= max_samples:
                break

        total_words = 0
        total_tokens1 = 0
        total_tokens2 = 0

        for text in sentences:
            words = text.split()
            total_words += len(words)
            total_tokens1 += len(tok1.encode(text))
            total_tokens2 += len(tok2.encode(text))

        click.echo(f"\nSamples analyzed: {len(sentences):,}")
        click.echo(f"Total words: {total_words:,}")
        click.echo(f"\n{'Metric':<30} {'Tokenizer 1':>12} {'Tokenizer 2':>12}")
        click.echo("-" * 60)
        click.echo(f"{'Total tokens':<30} {total_tokens1:>12,} {total_tokens2:>12,}")

        if total_words > 0:
            reduction1 = (total_words - total_tokens1) / total_words * 100
            reduction2 = (total_words - total_tokens2) / total_words * 100
            ratio1 = total_words / max(total_tokens1, 1)
            ratio2 = total_words / max(total_tokens2, 1)

            click.echo(f"{'Sequence reduction %':<30} {reduction1:>11.2f}% {reduction2:>11.2f}%")
            click.echo(f"{'Compression ratio':<30} {ratio1:>11.2f}x {ratio2:>11.2f}x")

            # Determine winner
            if reduction1 > reduction2:
                diff = reduction1 - reduction2
                click.echo(f"\nTokenizer 1 achieves {diff:.2f}% better compression")
            elif reduction2 > reduction1:
                diff = reduction2 - reduction1
                click.echo(f"\nTokenizer 2 achieves {diff:.2f}% better compression")
            else:
                click.echo(f"\nBoth tokenizers achieve equal compression")


@main.command()
@click.argument("corpus")
@click.option(
    "-o", "--output",
    default="bpe_tokenizer.json",
    help="Output path for BPE tokenizer (default: bpe_tokenizer.json)",
)
@click.option(
    "-v", "--vocab-size",
    default=10000,
    type=int,
    help="Vocabulary size (default: 10000)",
)
@click.option(
    "-n", "--max-samples",
    default=50000,
    type=int,
    help="Maximum samples to process",
)
@click.option(
    "--hf-split",
    default="train",
    help="HuggingFace dataset split",
)
@click.option(
    "--hf-text-field",
    default="text",
    help="HuggingFace dataset text field",
)
@click.option(
    "--hf-config",
    default=None,
    help="HuggingFace dataset config name",
)
def bpe(
    corpus: str,
    output: str,
    vocab_size: int,
    max_samples: int,
    hf_split: str,
    hf_text_field: str,
    hf_config: str,
):
    """
    Build a standalone BPE tokenizer for comparison.

    Creates a BPE tokenizer using the HuggingFace tokenizers library.
    Use this to create a baseline BPE tokenizer to compare against Ion.

    CORPUS can be a HuggingFace dataset or local file/directory.
    """
    import tempfile
    from tqdm import tqdm

    click.echo("=" * 60)
    click.echo("BPE TOKENIZER BUILDER")
    click.echo("=" * 60)
    click.echo(f"\nCorpus: {corpus}")
    click.echo(f"Output: {output}")
    click.echo(f"Vocabulary size: {vocab_size:,}")

    # Check if tokenizers is installed
    try:
        from tokenizers import Tokenizer
        from tokenizers.models import BPE
        from tokenizers.trainers import BpeTrainer
        from tokenizers.pre_tokenizers import Whitespace
    except ImportError:
        click.echo("\nError: 'tokenizers' package not installed.", err=True)
        click.echo("Install with: pip install tokenizers", err=True)
        sys.exit(1)

    # Load corpus
    click.echo("\nLoading corpus...")
    from .corpus import load_corpus

    texts = []
    for sent in tqdm(load_corpus(
        corpus,
        hf_split=hf_split,
        hf_text_field=hf_text_field,
        hf_config=hf_config,
    ), desc="Loading"):
        text = " ".join(sent)
        texts.append(text)
        if len(texts) >= max_samples:
            break

    click.echo(f"Loaded {len(texts):,} samples")

    # Write to temp file for training
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
        f.write('\n'.join(texts))
        temp_corpus = f.name

    # Train BPE tokenizer
    click.echo("\nTraining BPE tokenizer...")
    bpe_tokenizer = Tokenizer(BPE(unk_token="<unk>"))
    bpe_tokenizer.pre_tokenizer = Whitespace()
    trainer = BpeTrainer(
        special_tokens=["<pad>", "<unk>", "<bos>", "<eos>"],
        vocab_size=vocab_size,
        min_frequency=2,
    )
    bpe_tokenizer.train([temp_corpus], trainer)

    # Save
    bpe_tokenizer.save(output)

    click.echo(f"\nBPE tokenizer saved to: {output}")
    click.echo(f"Vocabulary size: {bpe_tokenizer.get_vocab_size():,}")
    click.echo("\nUse in demo: The demo will automatically load bpe_tokenizer.json for comparison")

    # Cleanup
    Path(temp_corpus).unlink(missing_ok=True)


@main.command()
@click.argument("corpus")
@click.option(
    "-v", "--vocab-size",
    default=10000,
    type=int,
    help="Vocabulary size for both tokenizers (default: 10000)",
)
@click.option(
    "-n", "--max-samples",
    default=50000,
    type=int,
    help="Maximum samples to process",
)
@click.option(
    "--hf-split",
    default="train",
    help="HuggingFace dataset split",
)
@click.option(
    "--hf-text-field",
    default="text",
    help="HuggingFace dataset text field",
)
@click.option(
    "--hf-config",
    default=None,
    help="HuggingFace dataset config name",
)
@click.option(
    "--language", "-l",
    default="auto",
    help="Language code (en, de, fr, etc.) or 'auto' for detection (default: auto)",
)
@click.option(
    "-pc", "--preserve-case",
    is_flag=True,
    default=False,
    help="Preserve case in tokens",
)
@click.option(
    "-pp", "--phrase-target-pct",
    default=60.0,
    type=float,
    help="Target percentage of vocab for phrases (default: 60%)",
)
@click.option(
    "-fm", "--fallback-mode",
    type=click.Choice(["bpe", "newword", "character", "word"]),
    default="bpe",
    help="Fallback mode for unknown words (default: bpe)",
)
def benchmark(
    corpus: str,
    vocab_size: int,
    max_samples: int,
    hf_split: str,
    hf_text_field: str,
    hf_config: str,
    language: str,
    preserve_case: bool,
    phrase_target_pct: float,
    fallback_mode: str,
):
    """
    Benchmark ion vs BPE tokenizer on a corpus.

    Trains both an ion tokenizer and a BPE tokenizer on the same corpus,
    then compares their compression performance.

    CORPUS can be a HuggingFace dataset or local file/directory.
    """
    import tempfile
    from tqdm import tqdm

    click.echo("=" * 70)
    click.echo("ION vs BPE BENCHMARK")
    click.echo("=" * 70)
    click.echo(f"\nCorpus: {corpus}")
    click.echo(f"Vocabulary size: {vocab_size:,}")
    click.echo(f"Max samples: {max_samples:,}")

    # Load corpus
    click.echo("\nLoading corpus...")
    from .corpus import load_corpus, detect_language, detect_if_code

    texts = []
    total_chars = 0
    for sent in tqdm(load_corpus(
        corpus,
        hf_split=hf_split,
        hf_text_field=hf_text_field,
        hf_config=hf_config,
    ), desc="Loading"):
        text = " ".join(sent)
        texts.append(text)
        total_chars += len(text)
        if len(texts) >= max_samples:
            break

    click.echo(f"Loaded {len(texts):,} samples ({total_chars:,} chars)")

    # Auto-detect language and code
    if language == "auto":
        detected_lang = detect_language(texts[:500])
        is_code = detect_if_code(texts[:200])
        language = detected_lang
        if is_code:
            preserve_case = True
        click.echo(f"Detected language: {language}" + (" (code)" if is_code else ""))
    if language != "en":
        click.echo(f"Language: {language}")
    if preserve_case:
        click.echo("Case preservation: enabled")

    # Train ion tokenizer
    click.echo("\n" + "-" * 70)
    click.echo("Training ION tokenizer...")
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
        f.write('\n'.join(texts))
        temp_corpus = f.name

    ion_stats = build_tokenizer(
        source=temp_corpus,
        output="/tmp/ion_benchmark.json",
        max_vocab_size=vocab_size,
        min_word_freq=1,
        min_phrase_freq=2,
        max_sentences=max_samples,
        language=language,
        preserve_case=preserve_case,
        phrase_target_pct=phrase_target_pct,
        fallback_mode=fallback_mode,
    )

    # Load ion tokenizer
    from .tokenizer import IonTokenizer
    ion_data = orjson.loads(Path("/tmp/ion_benchmark.json").read_bytes())
    ion_tok = IonTokenizer.from_dict(ion_data)

    # Train BPE tokenizer
    click.echo("\n" + "-" * 70)
    click.echo("Training BPE tokenizer...")
    try:
        from tokenizers import Tokenizer
        from tokenizers.models import BPE
        from tokenizers.trainers import BpeTrainer
        from tokenizers.pre_tokenizers import Whitespace

        bpe_tokenizer = Tokenizer(BPE(unk_token="<unk>"))
        bpe_tokenizer.pre_tokenizer = Whitespace()
        trainer = BpeTrainer(
            special_tokens=["<pad>", "<unk>", "<bos>", "<eos>"],
            vocab_size=vocab_size,
            min_frequency=2,
        )
        bpe_tokenizer.train([temp_corpus], trainer)
        bpe_available = True
        click.echo(f"BPE vocab size: {bpe_tokenizer.get_vocab_size():,}")
    except ImportError:
        click.echo("Warning: 'tokenizers' package not installed. Skipping BPE comparison.")
        click.echo("Install with: pip install tokenizers")
        bpe_available = False

    # Benchmark
    click.echo("\n" + "-" * 70)
    click.echo("Running benchmark...")

    total_words = 0
    ion_tokens = 0
    bpe_tokens = 0 if bpe_available else None

    for text in tqdm(texts[:10000], desc="Encoding"):
        words = text.split()
        total_words += len(words)
        ion_tokens += len(ion_tok.encode(text))
        if bpe_available:
            bpe_tokens += len(bpe_tokenizer.encode(text).ids)

    # Results
    click.echo("\n" + "=" * 70)
    click.echo("RESULTS")
    click.echo("=" * 70)

    click.echo(f"\n{'Metric':<35} {'ION':>15} {'BPE':>15}")
    click.echo("-" * 70)
    click.echo(f"{'Vocabulary size':<35} {ion_tok.vocab_size():>15,} {vocab_size if bpe_available else 'N/A':>15}")
    click.echo(f"{'Phrase tokens':<35} {len(ion_tok.token_classes['phrase']):>15,} {'0':>15}")
    click.echo(f"{'Word tokens':<35} {len(ion_tok.token_classes['word']):>15,} {'N/A':>15}")

    click.echo(f"\n{'Total input words':<35} {total_words:>15,}")
    click.echo(f"{'ION output tokens':<35} {ion_tokens:>15,}")
    if bpe_available:
        click.echo(f"{'BPE output tokens':<35} {bpe_tokens:>15,}")

    ion_reduction = (total_words - ion_tokens) / total_words * 100 if total_words > 0 else 0
    ion_ratio = total_words / max(ion_tokens, 1)

    click.echo(f"\n{'ION sequence reduction':<35} {ion_reduction:>14.2f}%")
    click.echo(f"{'ION compression ratio':<35} {ion_ratio:>14.2f}x")

    if bpe_available and bpe_tokens:
        bpe_reduction = (total_words - bpe_tokens) / total_words * 100 if total_words > 0 else 0
        bpe_ratio = total_words / max(bpe_tokens, 1)
        click.echo(f"{'BPE sequence reduction':<35} {bpe_reduction:>14.2f}%")
        click.echo(f"{'BPE compression ratio':<35} {bpe_ratio:>14.2f}x")

        click.echo("\n" + "=" * 70)
        if ion_reduction > bpe_reduction:
            diff = ion_reduction - bpe_reduction
            click.echo(f"ION achieves {diff:.2f}% BETTER compression than BPE")
        elif bpe_reduction > ion_reduction:
            diff = bpe_reduction - ion_reduction
            click.echo(f"BPE achieves {diff:.2f}% better compression than ION")
        else:
            click.echo("Both tokenizers achieve equal compression")
        click.echo("=" * 70)

    # Cleanup
    Path(temp_corpus).unlink(missing_ok=True)
    Path("/tmp/ion_benchmark.json").unlink(missing_ok=True)


@main.command()
@click.argument("corpus", required=False)
@click.option(
    "-v", "--vocab-sizes",
    default=None,
    help="Comma-separated vocab sizes to sweep (default: 5000,10000,20000,50000,100000)",
)
@click.option(
    "-o", "--output",
    default="vocab_sweep.csv",
    help="Output CSV path (default: vocab_sweep.csv)",
)
@click.option(
    "-C", "--chart",
    default=None,
    help="Optional path for ASCII chart file",
)
@click.option(
    "-n", "--max-sentences",
    default=100_000,
    type=int,
    help="Maximum sentences to process",
)
@click.option(
    "--hf-split",
    default="train",
    help="HuggingFace dataset split",
)
@click.option(
    "--hf-text-field",
    default="text",
    help="HuggingFace dataset text field",
)
@click.option(
    "--hf-config",
    default=None,
    help="HuggingFace dataset config name",
)
def sweep(
    corpus: str,
    vocab_sizes: str,
    output: str,
    chart: str,
    max_sentences: int,
    hf_split: str,
    hf_text_field: str,
    hf_config: str,
):
    """
    Sweep vocab sizes and measure sequence-length reduction.

    Finds the optimal vocab size for your corpus by testing multiple sizes.
    """
    click.echo("=" * 60)
    click.echo("VOCABULARY SIZE SWEEP")
    click.echo("=" * 60)
    click.echo("\nThis tool helps you find the optimal vocabulary size.")
    click.echo("It builds tokenizers at different sizes and measures compression.\n")

    # Interactive prompts if corpus not provided
    if not corpus:
        click.echo("STEP 1: What corpus do you want to analyze?")
        click.echo("  Examples: wikitext, my_corpus.txt, ./data/")
        corpus = click.prompt("  Enter corpus path or HuggingFace dataset")

    if not vocab_sizes:
        click.echo("\nSTEP 2: What vocab sizes do you want to test?")
        click.echo("  Suggested: 5000,10000,20000,50000,100000")
        click.echo("  Smaller = faster training, Larger = better compression")
        vocab_sizes = click.prompt("  Enter sizes (comma-separated)", default="5000,10000,20000,50000,100000")

    sizes = [int(s.strip()) for s in vocab_sizes.split(",")]

    click.echo(f"\n" + "-" * 60)
    click.echo(f"Configuration:")
    click.echo(f"  Corpus: {corpus}")
    click.echo(f"  Vocab sizes: {sizes}")
    click.echo(f"  Output: {output}")
    click.echo("-" * 60)

    if not click.confirm("\nReady to start sweep?", default=True):
        click.echo("Cancelled.")
        return

    results = vocab_sweep(
        source=corpus,
        vocab_sizes=sizes,
        output_csv=output,
        output_chart=chart,
        max_sentences=max_sentences,
        hf_split=hf_split,
        hf_text_field=hf_text_field,
        hf_config=hf_config,
    )

    # Save results to benchmarks
    update_vocab_sweep(results, corpus)

    click.echo("\n" + "=" * 60)
    click.echo("SWEEP COMPLETE!")
    click.echo("=" * 60)
    click.echo(f"\nResults saved to: {output}")
    click.echo("\nNEXT STEPS:")
    click.echo("  1. Review the CSV or chart to find your sweet spot")
    click.echo("  2. Build tokenizer: ion tokenize <corpus> --max-vocab <best_size>")
    click.echo("  3. View benchmarks anytime: ion benchmarks")
    click.echo("=" * 60)


@main.command()
@click.option(
    "-t", "--tokenizer",
    default=None,
    help="Path to tokenizer.json",
)
@click.argument("corpus", required=False)
@click.option(
    "-T", "--top",
    default=100,
    type=int,
    help="Number of top valuable phrases to show",
)
@click.option(
    "-B", "--bottom",
    default=100,
    type=int,
    help="Number of bottom/wasteful phrases to show",
)
@click.option(
    "-o", "--output",
    default=None,
    help="Optional CSV output for full phrase analysis",
)
@click.option(
    "-n", "--max-samples",
    default=50000,
    type=int,
    help="Maximum samples for analysis",
)
@click.option(
    "--hf-split",
    default="train",
    help="HuggingFace dataset split",
)
@click.option(
    "--hf-text-field",
    default="text",
    help="HuggingFace dataset text field",
)
@click.option(
    "--hf-config",
    default=None,
    help="HuggingFace dataset config name",
)
def phrases(
    tokenizer: str,
    corpus: str,
    top: int,
    bottom: int,
    output: str,
    max_samples: int,
    hf_split: str,
    hf_text_field: str,
    hf_config: str,
):
    """
    Analyze phrase value: which phrases earn their vocab slot?

    Make every phrase justify its existence in your vocabulary.
    """
    click.echo("=" * 60)
    click.echo("PHRASE ACCOUNTABILITY ANALYSIS")
    click.echo("=" * 60)
    click.echo("\nThis tool shows which phrases save the most tokens")
    click.echo("and which ones barely contribute.\n")

    # Interactive prompts
    if not tokenizer:
        click.echo("STEP 1: Which tokenizer do you want to analyze?")
        if Path("tokenizer.json").exists():
            tokenizer = click.prompt("  Enter tokenizer path", default="tokenizer.json")
        else:
            tokenizer = click.prompt("  Enter tokenizer path")

    if not Path(tokenizer).exists():
        click.echo(f"\nError: Tokenizer not found: {tokenizer}")
        click.echo("NEXT STEP: Build a tokenizer first with: ion tokenize <corpus>")
        return

    if not corpus:
        click.echo("\nSTEP 2: What corpus do you want to test phrases against?")
        click.echo("  This should be similar to your training data.")
        click.echo("  Examples: wikitext, my_corpus.txt, ./data/")
        corpus = click.prompt("  Enter corpus path or HuggingFace dataset")

    click.echo(f"\n" + "-" * 60)
    click.echo(f"Configuration:")
    click.echo(f"  Tokenizer: {tokenizer}")
    click.echo(f"  Corpus: {corpus}")
    click.echo(f"  Show top: {top}, bottom: {bottom}")
    click.echo("-" * 60)

    if not click.confirm("\nReady to analyze?", default=True):
        click.echo("Cancelled.")
        return

    result = phrase_accountability(
        tokenizer_path=tokenizer,
        corpus_source=corpus,
        top_n=top,
        bottom_n=bottom,
        max_samples=max_samples,
        hf_split=hf_split,
        hf_text_field=hf_text_field,
        hf_config=hf_config,
        output_csv=output,
    )

    click.echo(f"\n" + "=" * 60)
    click.echo("SUMMARY")
    click.echo("=" * 60)
    click.echo(f"  Total phrases: {result['total_phrases']:,}")
    click.echo(f"  Used phrases: {result['used_phrases']:,}")
    click.echo(f"  Unused phrases: {result['unused_phrases']:,}")
    click.echo(f"  Total tokens saved: {result['total_savings']:,}")

    click.echo(f"\n{'='*60}")
    click.echo(f"TOP {min(top, 20)} MOST VALUABLE PHRASES")
    click.echo(f"{'='*60}")
    click.echo(f"{'Phrase':<35} {'Uses':>8} {'Savings':>8} {'Benefit':>10}")
    click.echo("-" * 65)

    for p in result["top_phrases"][:min(top, 20)]:
        phrase_display = p["phrase"][:32] + "..." if len(p["phrase"]) > 35 else p["phrase"]
        click.echo(f"{phrase_display:<35} {p['usage_count']:>8,} {p['total_savings']:>8,} {p['marginal_benefit']:>10.1f}")

    if result["bottom_phrases"]:
        click.echo(f"\n{'='*60}")
        click.echo(f"BOTTOM {min(bottom, 20)} LEAST VALUABLE PHRASES")
        click.echo(f"{'='*60}")
        click.echo(f"{'Phrase':<35} {'Uses':>8} {'Savings':>8} {'Benefit':>10}")
        click.echo("-" * 65)

        for p in result["bottom_phrases"][:min(bottom, 20)]:
            phrase_display = p["phrase"][:32] + "..." if len(p["phrase"]) > 35 else p["phrase"]
            click.echo(f"{phrase_display:<35} {p['usage_count']:>8,} {p['total_savings']:>8,} {p['marginal_benefit']:>10.1f}")

    if result["unused_list"]:
        click.echo(f"\nUnused phrases (sample): {', '.join(result['unused_list'][:5])}")

    click.echo(f"\n" + "=" * 60)
    click.echo("NEXT STEPS:")
    if result['unused_phrases'] > result['total_phrases'] * 0.2:
        click.echo("  - High unused phrase rate! Consider rebuilding with higher --min-phrase-freq")
    click.echo("  - Export full analysis: ion phrases <corpus> -t tokenizer.json -o phrases.csv")
    click.echo("  - See compression stats: ion stats -t tokenizer.json")
    click.echo("=" * 60)


@main.command()
@click.argument("text", required=False)
@click.option(
    "-t", "--tokenizer",
    default=None,
    help="Path to ion tokenizer.json",
)
@click.option(
    "--bpe",
    default=None,
    help="Optional path to BPE tokenizer for comparison",
)
def parity(
    text: str,
    tokenizer: str,
    bpe: str,
):
    """
    Side-by-side comparison of ion vs BPE tokenization.

    Demonstrate Ion's value with real examples. Great for convincing stakeholders!
    """
    click.echo("=" * 60)
    click.echo("ION vs BPE PARITY COMPARISON")
    click.echo("=" * 60)
    click.echo("\nCompare Ion and BPE tokenization side-by-side.")
    click.echo("See exactly where Ion wins and loses.\n")

    # Interactive prompts
    if not tokenizer:
        click.echo("STEP 1: Which Ion tokenizer do you want to compare?")
        if Path("tokenizer.json").exists():
            tokenizer = click.prompt("  Enter tokenizer path", default="tokenizer.json")
        else:
            tokenizer = click.prompt("  Enter tokenizer path")

    if not Path(tokenizer).exists():
        click.echo(f"\nError: Tokenizer not found: {tokenizer}")
        click.echo("NEXT STEP: Build a tokenizer first with: ion tokenize <corpus>")
        return

    if not text:
        click.echo("\nSTEP 2: What text do you want to compare?")
        click.echo("  Try a sentence with common phrases for best results.")
        click.echo("  Example: The United States of America has one of the largest economies.")
        text = click.prompt("  Enter text to tokenize")

    click.echo(f"\n" + "-" * 60)
    click.echo(f"Comparing tokenization...")
    click.echo("-" * 60)

    result = bpe_parity_compare(text, tokenizer, bpe)

    click.echo(f"\nINPUT TEXT:")
    click.echo(f"  \"{result['input_text']}\"")
    click.echo(f"  Word count: {result['input_words']}")

    click.echo(f"\n" + "-" * 60)
    click.echo(f"ION TOKENIZATION ({result['ion_count']} tokens)")
    click.echo("-" * 60)
    # Display tokens with visual separator
    tokens_display = result['ion_tokens'][:30]
    click.echo(f"  {' | '.join(tokens_display)}")
    if len(result['ion_tokens']) > 30:
        click.echo(f"  ... and {len(result['ion_tokens']) - 30} more")

    if result['bpe_tokens']:
        click.echo(f"\n" + "-" * 60)
        click.echo(f"BPE TOKENIZATION ({result['bpe_count']} tokens)")
        click.echo("-" * 60)
        tokens_display = result['bpe_tokens'][:30]
        click.echo(f"  {' | '.join(tokens_display)}")
        if len(result['bpe_tokens']) > 30:
            click.echo(f"  ... and {len(result['bpe_tokens']) - 30} more")

        click.echo(f"\n" + "=" * 60)
        click.echo("RESULT")
        click.echo("=" * 60)
        if result['ion_wins']:
            click.echo(f"  ION WINS!")
            click.echo(f"  {result['difference']} fewer tokens ({result['savings_pct']:.1f}% reduction)")
            click.echo(f"\n  Ion: {result['ion_count']} tokens")
            click.echo(f"  BPE: {result['bpe_count']} tokens")
        elif result['difference'] < 0:
            click.echo(f"  BPE wins by {-result['difference']} tokens")
            click.echo(f"  (This can happen with very short or unusual text)")
        else:
            click.echo("  TIE - both tokenizers produce the same count")

        click.echo(f"\n" + "=" * 60)
        click.echo("NEXT STEPS:")
        click.echo("  - Try more examples: ion parity")
        click.echo("  - Run full benchmark: ion benchmark <corpus>")
        click.echo("  - See built-in benchmarks: ion benchmarks")
        click.echo("=" * 60)
    else:
        click.echo(f"\n" + "-" * 60)
        click.echo("BPE COMPARISON NOT AVAILABLE")
        click.echo("-" * 60)
        click.echo("  To enable BPE comparison:")
        click.echo("    1. Install tiktoken: pip install tiktoken")
        click.echo("    2. Or provide --bpe path to a BPE tokenizer")
        click.echo("-" * 60)


@main.command()
@click.option(
    "-t", "--tokenizer",
    default=None,
    help="Path to tokenizer.json",
)
@click.option(
    "-f", "--format",
    "export_format",
    type=click.Choice(["huggingface", "sentencepiece", "vocab", "onnx", "tiktoken", "jsonl", "csv"]),
    default=None,
    help="Export format",
)
@click.option(
    "-o", "--output",
    default=None,
    help="Output path (directory for huggingface, file for others)",
)
@click.option(
    "--include-ids/--no-ids",
    default=True,
    help="Include token IDs in vocab format (default: yes)",
)
def export(
    tokenizer: str,
    export_format: str,
    output: str,
    include_ids: bool,
):
    """
    Export ion tokenizer to other formats for model training.

    Makes integration with your ML pipeline easy!
    """
    click.echo("=" * 60)
    click.echo("EXPORT TOKENIZER")
    click.echo("=" * 60)
    click.echo("\nExport your Ion tokenizer for use in model training.\n")

    # Interactive prompts
    if not tokenizer:
        click.echo("STEP 1: Which tokenizer do you want to export?")
        if Path("tokenizer.json").exists():
            tokenizer = click.prompt("  Enter tokenizer path", default="tokenizer.json")
        else:
            tokenizer = click.prompt("  Enter tokenizer path")

    if not Path(tokenizer).exists():
        click.echo(f"\nError: Tokenizer not found: {tokenizer}")
        click.echo("NEXT STEP: Build a tokenizer first with: ion tokenize <corpus>")
        return

    if not export_format:
        click.echo("\nSTEP 2: What format do you need?")
        click.echo("  1. huggingface   - For HuggingFace Transformers (recommended)")
        click.echo("  2. sentencepiece - For SentencePiece-based systems")
        click.echo("  3. vocab         - Plain text vocab file")
        click.echo("  4. onnx          - For ONNX Runtime tokenizer operators")
        click.echo("  5. tiktoken      - For tiktoken-compatible loading")
        click.echo("  6. jsonl         - JSON-Lines (data pipelines, BigQuery, Spark)")
        click.echo("  7. csv           - CSV (spreadsheets, pandas)")
        format_choice = click.prompt("  Enter format (1-7 or name)", default="1")

        format_map = {
            "1": "huggingface", "2": "sentencepiece", "3": "vocab",
            "4": "onnx", "5": "tiktoken", "6": "jsonl", "7": "csv",
        }
        export_format = format_map.get(format_choice, format_choice)

    if not output:
        click.echo(f"\nSTEP 3: Where should we save the export?")
        defaults = {
            "huggingface": "./ion_hf_tokenizer/",
            "sentencepiece": "ion_vocab.spm",
            "vocab": "ion_vocab.txt",
            "onnx": "./ion_onnx/",
            "tiktoken": "ion_vocab.tiktoken",
            "jsonl": "ion_vocab.jsonl",
            "csv": "ion_vocab.csv",
        }
        output = click.prompt("  Enter output path", default=defaults.get(export_format, "ion_export"))

    click.echo(f"\n" + "-" * 60)
    click.echo(f"Configuration:")
    click.echo(f"  Tokenizer: {tokenizer}")
    click.echo(f"  Format: {export_format}")
    click.echo(f"  Output: {output}")
    click.echo("-" * 60)

    if not click.confirm("\nReady to export?", default=True):
        click.echo("Cancelled.")
        return

    click.echo(f"\n" + "=" * 60)
    click.echo(f"EXPORTING TO {export_format.upper()}")
    click.echo("=" * 60)

    if export_format == "huggingface":
        result = export_huggingface(tokenizer, output)
        click.echo(f"\nExported to: {result}")
        click.echo("\nFiles created:")
        click.echo("  - tokenizer.json")
        click.echo("  - tokenizer_config.json")
        click.echo("  - special_tokens_map.json")
        click.echo(f"\n" + "=" * 60)
        click.echo("NEXT STEP: Use in your code:")
        click.echo("=" * 60)
        click.echo("  from transformers import PreTrainedTokenizerFast")
        click.echo(f"  tokenizer = PreTrainedTokenizerFast.from_pretrained('{output}')")
        click.echo("  encoded = tokenizer('Hello world', return_tensors='pt')")

    elif export_format == "sentencepiece":
        result = export_sentencepiece(tokenizer, output)
        click.echo(f"\nExported to: {result}")
        click.echo(f"\n" + "=" * 60)
        click.echo("NEXT STEP: Load in SentencePiece-based systems")
        click.echo("=" * 60)

    elif export_format == "vocab":
        result = export_vocab_txt(tokenizer, output, include_ids=include_ids)
        click.echo(f"\nExported to: {result}")
        click.echo(f"\n" + "=" * 60)
        click.echo("NEXT STEP: Use with custom tokenizer loaders")
        click.echo("=" * 60)

    elif export_format == "onnx":
        result = export_onnx(tokenizer, output)
        click.echo(f"\nExported to: {result}")
        click.echo("\nFiles created:")
        click.echo("  - vocab.txt")
        click.echo("  - config.json")
        click.echo(f"\n" + "=" * 60)
        click.echo("NEXT STEP: Use with ONNX Runtime tokenizer operators")
        click.echo("=" * 60)

    elif export_format == "tiktoken":
        result = export_tiktoken(tokenizer, output)
        click.echo(f"\nExported to: {result}")
        click.echo(f"\n" + "=" * 60)
        click.echo("NEXT STEP: Load with tiktoken:")
        click.echo("=" * 60)
        click.echo("  import tiktoken")
        click.echo(f"  enc = tiktoken.Encoding(")
        click.echo(f"      name='ion',")
        click.echo(f"      pat_str=r\"\"\"'s|'t|...\"\"\",")
        click.echo(f"      mergeable_ranks=tiktoken.load_tiktoken_bpe('{output}'),")
        click.echo(f"      special_tokens={{'<pad>': 0, '<unk>': 1, '<bos>': 2, '<eos>': 3}}")
        click.echo(f"  )")

    elif export_format == "jsonl":
        result = export_jsonl(tokenizer, output)
        click.echo(f"\nExported to: {result}")
        click.echo(f"\n" + "=" * 60)
        click.echo("NEXT STEP: Load in data pipelines:")
        click.echo("=" * 60)
        click.echo("  import json")
        click.echo(f"  with open('{output}') as f:")
        click.echo("      vocab = [json.loads(line) for line in f]")
        click.echo("  # Each entry: {id, token, type, bytes}")

    elif export_format == "csv":
        result = export_csv(tokenizer, output)
        click.echo(f"\nExported to: {result}")
        click.echo(f"\n" + "=" * 60)
        click.echo("NEXT STEP: Open in spreadsheet or pandas:")
        click.echo("=" * 60)
        click.echo("  import pandas as pd")
        click.echo(f"  df = pd.read_csv('{output}')")
        click.echo("  print(df[df['type'] == 'phrase'].head(20))")


@main.command()
@click.option(
    "-t", "--tokenizer",
    default=None,
    help="Path to tokenizer.json",
)
@click.argument("text", required=False)
def introspect(
    tokenizer: str,
    text: str,
):
    """
    Analyze fallback tokens and why words fell back.

    Debug "why did it spell out this word?" issues.
    """
    click.echo("=" * 60)
    click.echo("FALLBACK INTROSPECTION")
    click.echo("=" * 60)
    click.echo("\nDebug why words get spelled out character-by-character.")
    click.echo("Find out what's missing from your vocabulary.\n")

    # Interactive prompts
    if not tokenizer:
        click.echo("STEP 1: Which tokenizer do you want to analyze?")
        if Path("tokenizer.json").exists():
            tokenizer = click.prompt("  Enter tokenizer path", default="tokenizer.json")
        else:
            tokenizer = click.prompt("  Enter tokenizer path")

    if not Path(tokenizer).exists():
        click.echo(f"\nError: Tokenizer not found: {tokenizer}")
        click.echo("NEXT STEP: Build a tokenizer first with: ion tokenize <corpus>")
        return

    if not text:
        click.echo("\nSTEP 2: What text do you want to analyze?")
        click.echo("  Enter text that produces unexpected fallback tokens.")
        click.echo("  Example: The turtles went swimming")
        text = click.prompt("  Enter text")

    click.echo(f"\n" + "-" * 60)
    click.echo(f"Analyzing fallbacks...")
    click.echo("-" * 60)

    result = introspect_fallbacks(tokenizer, text)

    click.echo(f"\n" + "=" * 60)
    click.echo("ANALYSIS RESULTS")
    click.echo("=" * 60)
    click.echo(f"\nInput: \"{text}\"")
    click.echo(f"\n  Total words: {result['total_words']}")
    click.echo(f"  Fallback words: {result['fallback_words']}")
    click.echo(f"  Fallback rate: {result['fallback_rate']:.1f}%")
    click.echo(f"  Total fallback tokens: {result['fallback_tokens']}")
    click.echo(f"  Expansion factor: {result['expansion_factor']:.1f}x")

    if result['fallbacks']:
        click.echo(f"\n" + "=" * 60)
        click.echo("FALLBACK DETAILS")
        click.echo("=" * 60)
        click.echo("\nThese words are NOT in your vocabulary and got spelled out:\n")

        for i, fb in enumerate(result['fallbacks'][:10], 1):
            click.echo(f"  {i}. \"{fb['word']}\"")
            click.echo(f"     Became: {' '.join(fb['fallback_tokens'])}")
            click.echo(f"     Reason: {fb['reason']}")
            if fb['suggestions']:
                click.echo(f"     Fix: {fb['suggestions'][0]}")
            if fb.get('similar_in_vocab'):
                click.echo(f"     Similar words in vocab: {', '.join(fb['similar_in_vocab'][:3])}")
            click.echo()

        if len(result['fallbacks']) > 10:
            click.echo(f"  ... and {len(result['fallbacks']) - 10} more words")

    click.echo("=" * 60)
    click.echo("RECOMMENDATIONS")
    click.echo("=" * 60)

    if result['recommendations']:
        for rec in result['recommendations']:
            click.echo(f"  - {rec}")
    else:
        if result['fallback_rate'] == 0:
            click.echo("  Great! No fallbacks detected. Your vocab covers this text well.")
        else:
            click.echo("  - Consider using -tn (take-needed) mode for complete coverage")
            click.echo("  - Or lower --min-word-freq to include more words")

    click.echo(f"\n" + "=" * 60)
    click.echo("NEXT STEPS:")
    click.echo("  - Rebuild with more coverage: ion tokenize <corpus> -tn")
    click.echo("  - Or adjust frequency: ion tokenize <corpus> --min-word-freq 1")
    click.echo("  - Check full stats: ion stats -t tokenizer.json")
    click.echo("=" * 60)


@main.command()
@click.option(
    "-C", "--chart",
    is_flag=True,
    default=False,
    help="Show ASCII chart only",
)
@click.option(
    "-q", "--quick",
    is_flag=True,
    default=False,
    help="Show quick one-line summary",
)
def benchmarks(chart: bool, quick: bool):
    """
    Show built-in benchmarks demonstrating Ion's value.

    See Ion's performance WITHOUT building anything!
    """
    if quick:
        click.echo(format_quick_stats())
    elif chart:
        click.echo(get_ascii_chart())
    else:
        click.echo(format_benchmark_summary())
        click.echo("\n" + "=" * 70)
        click.echo("WHAT WOULD YOU LIKE TO DO NEXT?")
        click.echo("=" * 70)
        click.echo("\n  1. Build your first tokenizer:")
        click.echo("     $ ion tokenize <your_corpus.txt>")
        click.echo("\n  2. Find optimal vocab size for your data:")
        click.echo("     $ ion sweep <your_corpus.txt>")
        click.echo("\n  3. Compare Ion vs BPE on your data:")
        click.echo("     $ ion benchmark <your_corpus.txt>")
        click.echo("\n  4. Try the interactive demo:")
        click.echo("     $ ion")
        click.echo("\n  5. Read the research paper:")
        click.echo("     $ ion proof")
        click.echo("\n" + "=" * 70)


@main.command()
def proof():
    """Show the Ion proof-of-concept research paper (proof.md).

    \b
    Displays the 108-run empirical study demonstrating Ion's phrase-first
    architecture vs BPE tokenization across three HuggingFace datasets.
    """
    import importlib.resources
    # Try to find proof.md relative to the package
    proof_paths = [
        Path(__file__).parent.parent / "proof.md",
        Path.cwd() / "proof.md",
    ]
    for p in proof_paths:
        if p.exists():
            click.echo_via_pager(p.read_text())
            return
    # Inline summary if file not found
    click.echo("=" * 70)
    click.echo("ION PROOF: 108-RUN EMPIRICAL STUDY")
    click.echo("=" * 70)
    click.echo()
    click.echo("  Full paper: proof.md (in the ion repository root)")
    click.echo()
    click.echo("  KEY FINDINGS (3 datasets, 50k sentences each, 108 runs):")
    click.echo()
    click.echo("  1. Newword fallback wins ALL 54 head-to-head comparisons vs BPE fallback")
    click.echo("     Average: +12.55% reduction (newword) vs -35.33% (BPE)")
    click.echo()
    click.echo("  2. More phrases helps newword but HURTS BPE:")
    click.echo("     Newword at 80% phrases: +10.8% to +16.0% reduction")
    click.echo("     BPE at 80% phrases:     -100.6% to +4.0% (catastrophic at small vocab)")
    click.echo()
    click.echo("  3. Best config: --fallback-mode newword --vocab-size 50000 --phrase-target-pct 80")
    click.echo("     Peak: 19.68% reduction on AG News")
    click.echo()
    click.echo("  4. BPE fallback only viable at vocab=50k+ with phrase-target-pct=40")
    click.echo()
    click.echo("  Run 'ion docs -s proof' or read proof.md for the full paper.")
    click.echo("=" * 70)


@main.command()
def domains():
    """
    List available domain presets for tokenizer building.

    Each domain has tuned settings for specific content types.
    """
    click.echo("=" * 70)
    click.echo("DOMAIN PRESETS")
    click.echo("=" * 70)
    click.echo()
    click.echo("WHAT ARE DOMAINS?")
    click.echo("  Domains are presets that tune Ion's phrase discovery for a specific")
    click.echo("  content type. Each preset adjusts settings like PMI threshold,")
    click.echo("  phrase frequency minimums, phrase layer depth, and content-specific")
    click.echo("  phrase boosters/filters -- so you don't have to configure them")
    click.echo("  manually. Picking the right domain can improve compression by 5-15%.")
    click.echo()

    for domain, config in DOMAIN_CONFIGS.items():
        click.echo("-" * 70)
        click.echo(f"  {domain.upper()}: {config['description']}")
        click.echo()
        what = config.get('what_it_does', 'No details available.')
        click.echo(f"  What it does:")
        click.echo(f"    {what}")
        click.echo()
        click.echo(f"  Settings changed:")
        click.echo(f"    phrase_threshold={config['phrase_threshold']}  "
                   f"min_phrase_freq={config['min_phrase_freq']}  "
                   f"min_word_freq={config['min_word_freq']}  "
                   f"max_phrase_layers={config['max_phrase_layers']}")
        extras = []
        if config.get('remove_emphasis'):
            extras.append("remove_emphasis")
        if config.get('collapse_punctuation'):
            extras.append("collapse_punctuation")
        if config.get('preserve_case'):
            extras.append("preserve_case")
        if extras:
            click.echo(f"    Also enables: {', '.join(extras)}")
        boosters = config.get('phrase_boosters', [])
        if boosters:
            shown = ', '.join(f'"{b}"' for b in boosters[:4])
            suffix = f" (+{len(boosters)-4} more)" if len(boosters) > 4 else ""
            click.echo(f"    Boosted phrases: {shown}{suffix}")
        filters = config.get('phrase_filters', [])
        if filters:
            click.echo(f"    Filtered phrases: {', '.join(filters)}")
        click.echo()
        recommended = config.get('recommended_for', [])
        if recommended:
            click.echo(f"  When to use it:")
            for use_case in recommended:
                click.echo(f"    - {use_case}")
            click.echo()

    click.echo("=" * 70)
    click.echo("EXAMPLES")
    click.echo("=" * 70)
    click.echo()
    click.echo("  # Build a tokenizer for Wikipedia data:")
    click.echo("  ion tokenize wiki_dump.txt --domain wikipedia")
    click.echo()
    click.echo("  # Build a tokenizer for a code repository:")
    click.echo("  ion tokenize ./src/ --domain code")
    click.echo()
    click.echo("  # Build a tokenizer for legal contracts with large vocab:")
    click.echo("  ion tokenize contracts/ --domain legal --vocab-size 100000")
    click.echo()
    click.echo("  # Start with general if you're unsure:")
    click.echo("  ion tokenize my_corpus.txt --domain general")
    click.echo()
    click.echo("=" * 70)


@main.command()
@click.argument("snapshot_path")
@click.option(
    "-t", "--tokenizer",
    default="tokenizer.json",
    help="Path to tokenizer.json to verify",
)
def verify(
    snapshot_path: str,
    tokenizer: str,
):
    """
    Verify tokenizer matches its reproducibility snapshot.

    Checks that the tokenizer hash matches what was recorded during build.

    Example:
      ion verify build_snapshot.json -t tokenizer.json
    """
    click.echo("=" * 60)
    click.echo("REPRODUCIBILITY VERIFICATION")
    click.echo("=" * 60)

    result = verify_reproducibility(snapshot_path, tokenizer)

    click.echo(f"\nSnapshot created: {result['snapshot_created']}")
    click.echo(f"Seed: {result['seed']}")
    click.echo(f"Corpus: {result['corpus_source']}")
    click.echo(f"\nExpected hash: {result['expected_hash']}")
    click.echo(f"Current hash:  {result['current_hash']}")

    if result['match']:
        click.echo(f"\n{'='*60}")
        click.echo("MATCH - Tokenizer is reproducible!")
        click.echo("=" * 60)
    else:
        click.echo(f"\n{'='*60}")
        click.echo("MISMATCH - Tokenizer differs from snapshot!")
        click.echo("This may be due to:")
        click.echo("  - Different random seed")
        click.echo("  - Different corpus content")
        click.echo("  - Modified configuration")
        click.echo("=" * 60)


@main.command()
@click.option("-t", "--terminal", is_flag=True, default=False,
              help="Show documentation in the terminal instead of opening the website.")
@click.option("-s", "--search", "search_query", default=None,
              help="Search the documentation for a specific term.")
def docs(terminal, search_query):
    """Open Ion documentation in a browser, or browse it in the terminal.

    \b
    Examples:
      ion docs               Open docs website in browser
      ion docs -t            Browse docs in terminal (navigable, searchable)
      ion docs -s "domain"   Search docs for a term
    """
    import webbrowser

    DOCS_URL = "https://ion-tokenizer.dev/docs"

    # --- build the full terminal docs string ---
    sections = _build_docs_sections()

    if search_query:
        query = search_query.lower()
        matches = []
        for title, body in sections:
            if query in title.lower() or query in body.lower():
                matches.append((title, body))
        if not matches:
            click.echo(f'No documentation sections matched "{search_query}".')
            return
        click.echo(f'Found {len(matches)} section(s) matching "{search_query}":\n')
        text = "\n".join(f"{'=' * 70}\n{t}\n{'=' * 70}\n{b}\n" for t, b in matches)
        click.echo_via_pager(text)
        return

    if terminal:
        text = "\n".join(f"{'=' * 70}\n{t}\n{'=' * 70}\n{b}\n" for t, b in sections)
        click.echo_via_pager(text)
        return

    # Default: open in browser
    click.echo(f"Opening Ion documentation: {DOCS_URL}")
    try:
        webbrowser.open(DOCS_URL)
    except Exception:
        click.echo(f"Could not open browser. Visit: {DOCS_URL}")


def _build_docs_sections():
    """Return a list of (title, body) tuples for terminal docs."""
    sections = []

    sections.append(("ION - PHRASE-FIRST SEMANTIC TOKENIZER COMPILER", """
Ion discovers and collapses multi-word semantic units (phrases) into single
tokens to minimize sequence length, achieving better compression than BPE.

Architecture (fallback hierarchy):
  Phrases > Words > BPE subwords > Characters

Ion's phrase-first approach means common multi-word expressions like
"machine learning", "in accordance with", or "blood pressure" become
single tokens rather than being split into subwords.
"""))

    sections.append(("QUICK START", """
  # 1. Register (free plan available)
  ion register

  # 2. Build a tokenizer from a corpus
  ion tokenize my_corpus.txt

  # 3. Build with a specific domain preset
  ion tokenize my_corpus.txt --domain wikipedia

  # 4. View tokenizer stats
  ion stats -t tokenizer.json

  # 5. Compare Ion vs BPE
  ion benchmark my_corpus.txt

  # 6. Launch interactive GUI
  ion
"""))

    cmd_text = """
  ion                          Launch interactive GUI
  ion help                     Detailed help
  ion gui                      Launch GUI
  ion register                 Register for a license plan
  ion license -t tok.json      View license info
  ion upgrade --plan <name>    Upgrade license plan
  ion sync                     Sync pending registrations

  BUILDING:
  ion tokenize <source>        Build tokenizer from corpus
  ion iterate <source>         Adapt existing tokenizer to new data
  ion init                     Interactive setup wizard
  ion bpe <source>             Train BPE baseline for comparison

  ANALYSIS:
  ion stats -t tokenizer.json  Tokenizer statistics
  ion benchmark <corpus>       Ion vs BPE comparison
  ion sweep <corpus>           Vocab size sweep (5k-100k)
  ion compare <text>           Side-by-side comparison
  ion parity <text>            Token-level comparison
  ion phrases <corpus>         Phrase accountability analysis
  ion introspect <text>        Debug character fallbacks
  ion benchmarks               Show pre-computed benchmark data
  ion domains                  List domain presets

  EXPORT:
  ion export -t tok.json -f hf          HuggingFace format
  ion export -t tok.json -f tiktoken    tiktoken format
  ion export -t tok.json -f onnx        ONNX format
  ion export -t tok.json -f jsonl       JSONL format
  ion export -t tok.json -f csv         CSV format

  UTILITIES:
  ion clean <input>            Clean text with utilities
  ion retokenize <input>       Re-tokenize with different settings
  ion verify <snapshot>        Verify reproducibility snapshot
  ion docs                     Open documentation
  ion docs -t                  Browse docs in terminal
  ion docs -s "query"          Search docs
  ion proof                    Show research paper (108-run study)
"""
    sections.append(("COMMANDS REFERENCE", cmd_text))

    domain_lines = ["""
WHAT ARE DOMAINS?
  Domains are presets that tune Ion's phrase discovery for a specific
  content type. Each preset adjusts the PMI threshold, phrase frequency
  minimums, phrase layer depth, and content-specific phrase boosters and
  filters -- so you don't have to configure these manually.

  Picking the right domain can improve compression by 5-15%.

  Usage:  ion tokenize <source> --domain <name>
  List:   ion domains
"""]
    for name, cfg in DOMAIN_CONFIGS.items():
        domain_lines.append(f"\n  {name.upper()}: {cfg['description']}")
        what = cfg.get('what_it_does', '')
        if what:
            domain_lines.append(f"    {what}")
        recommended = cfg.get('recommended_for', [])
        for r in recommended:
            domain_lines.append(f"    - {r}")
    sections.append(("DOMAINS GUIDE", "\n".join(domain_lines)))

    sections.append(("FALLBACK MODES", """
When Ion encounters a word not in the vocabulary, it uses a fallback mode
to encode it. There are four modes:

  bpe (default, recommended)
    Decomposes unknown words into BPE subword tokens. Good coverage with
    reasonable compression.

  newword (best compression)
    Dynamically adds unknown words to the vocabulary. Best compression
    (avg 31.7% advantage over BPE baseline). 24/24 wins across tested
    HuggingFace datasets.

  character
    Splits unknown words into individual characters. Simple but produces
    long sequences for unknown words.

  word
    Maps all unknown words to <unk>. Only use when vocab covers all
    expected words.

  Usage:  ion tokenize <source> --fallback-mode newword

  PROVEN RESULTS (108-run study, proof.md):
    Newword wins all 54 head-to-head comparisons vs BPE fallback.
    Avg +12.55% reduction (newword) vs -35.33% (BPE).
    More phrases helps newword but hurts BPE at small vocab sizes.
    Best: --fallback-mode newword --vocab-size 50000 --phrase-target-pct 80
"""))

    sections.append(("PHRASE DISCOVERY", """
Ion uses PMI-based (Pointwise Mutual Information) phrase detection via
gensim's Phrases model to discover multi-word semantic units.

Key parameters:
  --phrase-threshold (-pt)   PMI threshold (default: 0.001). Lower = more phrases.
  --min-phrase-freq (-pf)    Minimum phrase frequency (default: 3)
  --max-phrase-layers (-pl)  Phrase composition rounds (default: 4)
  --phrase-target-pct (-pp)  % of vocab for phrases (default: 60)
  --word-target-pct (-wp)    % of vocab for words (default: 40)

Advanced:
  --embedding-scoring        Use Word2Vec to score phrase coherence
  --streaming-phrases        Learn phrases during encoding
  --typo-correction          Enable edit-distance typo correction
"""))

    sections.append(("EXPORT FORMATS", """
  ion export -t tokenizer.json -f <format>

    hf             HuggingFace Transformers (tokenizer.json + config)
    sentencepiece  SentencePiece .model file
    vocab          Plain text vocabulary (one token per line)
    onnx           ONNX runtime model
    tiktoken       tiktoken-compatible .tiktoken file
    jsonl          JSON Lines (one token per line)
    csv            CSV with token ID, text, type, frequency
"""))

    sections.append(("LICENSING PLANS", """
  Free ($0)          <10B params, open-source weights in 7 days, attribution
  Closed ($100)      <10B params, keep weights private, attribution
  Open Large ($1k)   10B+ params, open-source weights in 7 days, attribution
  Enterprise ($2k/B) 10B+ params, keep weights private, no attribution

  Register:  ion register
  View:      ion license
  Upgrade:   ion upgrade --plan <name>
"""))

    sections.append(("CONFIGURATION OPTIONS", """
  Key tokenize flags:
    -v, --vocab-size N        Target vocabulary size (default: 20000)
    -fm, --fallback-mode M    bpe|newword|character|word
    -d, --domain D            Domain preset
    -tn, --take-needed        Include ALL words+phrases (ignore budget)
    -pp, --phrase-target-pct  % of vocab for phrases (default: 60)
    -wp, --word-target-pct    % of vocab for words (default: 40)
    -pt, --phrase-threshold   PMI threshold (default: 0.001)
    -pf, --min-phrase-freq    Min phrase frequency (default: 3)
    -wf, --min-word-freq      Min word frequency (default: 1)
    -pl, --max-phrase-layers  Phrase layers (default: 4)
    -ms, --max-sentences N    Max sentences (default: 1000000)
    --preserve-case           Don't lowercase
    --embedding-scoring       Word2Vec phrase scoring
    --streaming-phrases       Adaptive phrase learning
    --typo-correction         Typo correction layer
    -s, --seed N              Random seed
"""))

    return sections


@main.command()
@click.option("--email", default=None, help="Registration email")
@click.option(
    "--plan", "plan_name", default=None,
    type=click.Choice(["free", "closed", "open-large", "enterprise"]),
    help="Plan: free, closed, open-large, enterprise",
)
@click.option("--force", is_flag=True, default=False, help="Overwrite existing registration")
def register(email, plan_name, force):
    """Register or re-register for Ion Tokenizer licensing."""
    from .licensing import register_interactive
    register_interactive(force=force, preset_email=email, preset_plan=plan_name)


@main.command("license")
@click.option(
    "--tokenizer", "tokenizer_path", default=None,
    help="Show license for specific tokenizer file",
)
def license_cmd(tokenizer_path):
    """View current license information."""
    from .licensing import (
        load_config, is_registered, get_license_info_display,
        get_tokenizer_license_display,
    )

    if tokenizer_path:
        click.echo(get_tokenizer_license_display(tokenizer_path))
        return

    config = load_config()
    if not config or not is_registered():
        click.echo("  ✗ Not registered. Run: ion register")
        return

    click.echo(get_license_info_display(config))


@main.command()
@click.option(
    "--plan", "plan_name", required=True,
    type=click.Choice(["closed", "open-large", "enterprise"]),
    help="Plan to upgrade to: closed, open-large, enterprise",
)
def upgrade(plan_name):
    """Upgrade to a different plan."""
    from .licensing import (
        load_config, is_registered, save_config, PLAN_NAMES, PLAN_PRICES,
        _generate_session_id, _check_internet, _poll_payment, ION_BASE_URL,
    )
    import webbrowser

    config = load_config()
    if not config or not is_registered():
        click.echo("  ✗ Not registered. Run: ion register")
        return

    current_plan = config.get("plan", "free")

    click.echo("━" * 64)
    click.echo(f"  Upgrade to {PLAN_NAMES[plan_name]} Plan")
    click.echo("━" * 64)
    click.echo()
    click.echo(f"  Current plan:  {PLAN_NAMES.get(current_plan, current_plan)}")
    click.echo(f"  New plan:      {PLAN_NAMES[plan_name]} — {PLAN_PRICES[plan_name]}")
    click.echo()

    if not _check_internet():
        click.echo("  ✗ Payment requires internet connection.")
        return

    session_id = _generate_session_id()
    email = config.get("email", "")
    checkout_url = f"{ION_BASE_URL}/checkout?session_id={session_id}&plan={plan_name}&email={email}&upgrade=true"

    click.echo("  Opening browser for payment...")
    click.echo()
    try:
        webbrowser.open(checkout_url)
    except Exception:
        click.echo(f"  Could not open browser. Visit:")
        click.echo(f"  {checkout_url}")
        click.echo()

    result = _poll_payment(session_id)
    if not result:
        return

    config["plan"] = plan_name
    config["payment_confirmed"] = True
    if result.get("user_id"):
        config["user_id"] = result["user_id"]
    save_config(config)

    click.echo()
    click.echo(f"  ✓ Upgrade complete!")
    click.echo()
    click.echo(f"  New plan: {PLAN_NAMES[plan_name]}")
    click.echo()
    click.echo(f"  Your existing tokenizers remain on their original plan.")
    click.echo(f"  New tokenizers will use the {PLAN_NAMES[plan_name]} plan.")


@main.command()
def sync():
    """Sync pending registrations and tokenizer logs with the server."""
    from .licensing import sync_pending
    sync_pending()


@main.command()
@click.argument("source")
@click.option(
    "-p", "--pretrained",
    default="ion-1m",
    type=click.Choice(["ion-250k", "ion-500k", "ion-1m", "ion-2m"]),
    help="Pretrained tokenizer to use as base (default: ion-1m)",
)
@click.option(
    "-o", "--output",
    default="tokenizer.json",
    help="Output path for adapted tokenizer",
)
@click.option(
    "-n", "--max-sentences",
    default=100_000,
    type=int,
    help="Maximum sentences to process from new corpus",
)
@click.option(
    "--hf-split",
    default="train",
    help="HuggingFace dataset split",
)
@click.option(
    "--hf-text-field",
    default="text",
    help="HuggingFace dataset text field name",
)
@click.option(
    "--hf-config",
    default=None,
    help="HuggingFace dataset config name",
)
@click.option(
    "--max-samples",
    default=None,
    type=int,
    help="Maximum samples from HuggingFace dataset",
)
def pretrained(source, pretrained, output, max_sentences, hf_split, hf_text_field, hf_config, max_samples):
    """Train using a pretrained Ion tokenizer as base.

    Adapts a pretrained tokenizer to your corpus by discovering new phrases
    and words from your data while preserving the pretrained vocabulary.

    Available pretrained models:

    \b
      ion-250k   Trained on 250K sentences (Wikipedia + FineWeb)
      ion-500k   Trained on 500K sentences
      ion-1m     Trained on 1M sentences (recommended)
      ion-2m     Trained on 2M sentences (largest)

    Examples:

    \b
      ion pretrained my_corpus.txt
      ion pretrained my_corpus.txt -p ion-2m -o my_tokenizer.json
      ion pretrained wikitext --hf-config wikitext-103-raw-v1
    """
    import importlib.resources

    # Find pretrained tokenizer
    pretrained_dir = Path(__file__).parent.parent / "pretrained"
    pretrained_path = pretrained_dir / f"{pretrained}.json"

    if not pretrained_path.exists():
        click.echo(f"Error: Pretrained tokenizer not found: {pretrained_path}")
        click.echo(f"Available pretrained models in {pretrained_dir}/:")
        if pretrained_dir.exists():
            for f in sorted(pretrained_dir.glob("ion-*.json")):
                size_mb = f.stat().st_size / (1024 * 1024)
                click.echo(f"  {f.stem} ({size_mb:.1f} MB)")
        else:
            click.echo("  (none found - run benchmarks/build_pretrained.py first)")
        sys.exit(1)

    click.echo(f"Base tokenizer: {pretrained} ({pretrained_path})")
    click.echo(f"Adapting to: {source}")
    click.echo()

    from .builder import iterate_tokenizer
    stats = iterate_tokenizer(
        tokenizer_path=str(pretrained_path),
        source=source,
        output=output,
        max_sentences=max_sentences,
        hf_split=hf_split,
        hf_text_field=hf_text_field,
        max_samples=max_samples,
        hf_config=hf_config,
    )

    click.echo()
    click.echo(f"Adapted tokenizer saved to: {output}")
    click.echo(f"  New phrases added: {stats.get('new_phrases_added', 0)}")
    click.echo(f"  New words added: {stats.get('new_words_added', 0)}")
    click.echo(f"  Final vocab size: {stats.get('final_vocab_size', 'unknown')}")


if __name__ == "__main__":
    main()
