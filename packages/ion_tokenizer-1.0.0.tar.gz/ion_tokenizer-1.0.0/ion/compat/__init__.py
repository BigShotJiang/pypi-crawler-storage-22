"""
ion.compat - Pure-Python replacements for gensim and scipy.

These modules provide compatible implementations that work on newer Python
versions where gensim/scipy installation may break. They are used as
automatic fallbacks when the upstream packages are unavailable.

Modules:
    ion_phrases   - PMI-based phrase detection (replaces gensim.models.phrases)
    ion_embeddings - Word2Vec skip-gram embeddings (replaces gensim.models.Word2Vec)
    ion_math      - Numerical computing (replaces scipy: sparse, spatial, optimize,
                    stats, linalg, signal, special, interpolate, integrate)

Usage:
    from ion.compat.ion_phrases import Phrases, ENGLISH_CONNECTOR_WORDS
    from ion.compat.ion_embeddings import Word2Vec
    from ion.compat import ion_math
"""
