"""
Pure-Python replacement for gensim.models.Word2Vec.

Implements Skip-gram with negative sampling using only Python stdlib + basic math.
No numpy/scipy required (but will use numpy if available for speed).
"""

import math
import random
import struct
from collections import Counter
from typing import Optional


def _try_numpy():
    """Try to import numpy, return None if unavailable."""
    try:
        import numpy as np
        return np
    except ImportError:
        return None


class _PureVector:
    """Pure-Python vector operations when numpy is unavailable."""

    @staticmethod
    def zeros(n):
        return [0.0] * n

    @staticmethod
    def randn(n, seed_val=None):
        """Generate pseudo-random normal values using Box-Muller."""
        rng = random.Random(seed_val)
        result = []
        for _ in range(0, n, 2):
            u1 = rng.random() or 1e-10
            u2 = rng.random()
            z0 = math.sqrt(-2.0 * math.log(u1)) * math.cos(2.0 * math.pi * u2)
            z1 = math.sqrt(-2.0 * math.log(u1)) * math.sin(2.0 * math.pi * u2)
            result.append(z0 * 0.01)
            if len(result) < n:
                result.append(z1 * 0.01)
        return result[:n]

    @staticmethod
    def dot(a, b):
        return sum(x * y for x, y in zip(a, b))

    @staticmethod
    def norm(a):
        return math.sqrt(sum(x * x for x in a))

    @staticmethod
    def add_inplace(a, b, scale=1.0):
        for i in range(len(a)):
            a[i] += b[i] * scale

    @staticmethod
    def scale(a, s):
        return [x * s for x in a]


class KeyedVectors:
    """
    Compatible replacement for gensim.models.KeyedVectors.

    Stores word vectors and supports similarity queries.
    """

    def __init__(self, vector_size: int):
        self.vector_size = vector_size
        self.vectors: dict = {}  # word -> list[float] or np.array
        self.index_to_key: list = []
        self._np = _try_numpy()

    def __contains__(self, word: str) -> bool:
        return word in self.vectors

    def __getitem__(self, word: str):
        if word not in self.vectors:
            raise KeyError(f"word '{word}' not in vocabulary")
        return self.vectors[word]

    def __len__(self):
        return len(self.vectors)

    def add_vector(self, word: str, vector):
        self.vectors[word] = vector
        if word not in self.index_to_key:
            self.index_to_key.append(word)

    def most_similar(self, positive=None, negative=None, topn=10):
        """Find most similar words by cosine similarity."""
        positive = positive or []
        negative = negative or []

        if isinstance(positive, str):
            positive = [positive]
        if isinstance(negative, str):
            negative = [negative]

        # Build query vector
        np = self._np
        if np is not None:
            query = np.zeros(self.vector_size)
            for w in positive:
                if w in self.vectors:
                    query = query + self.vectors[w]
            for w in negative:
                if w in self.vectors:
                    query = query - self.vectors[w]
            query_norm = np.linalg.norm(query)
            if query_norm == 0:
                return []
            query = query / query_norm
        else:
            query = _PureVector.zeros(self.vector_size)
            for w in positive:
                if w in self.vectors:
                    _PureVector.add_inplace(query, self.vectors[w])
            for w in negative:
                if w in self.vectors:
                    _PureVector.add_inplace(query, self.vectors[w], scale=-1.0)
            qn = _PureVector.norm(query)
            if qn == 0:
                return []
            query = _PureVector.scale(query, 1.0 / qn)

        # Compute similarities
        exclude = set(positive) | set(negative)
        scores = []
        for word, vec in self.vectors.items():
            if word in exclude:
                continue
            if np is not None:
                sim = float(np.dot(query, vec) / (np.linalg.norm(vec) + 1e-10))
            else:
                vn = _PureVector.norm(vec)
                sim = _PureVector.dot(query, vec) / (vn + 1e-10) if vn > 0 else 0.0
            scores.append((word, sim))

        scores.sort(key=lambda x: -x[1])
        return scores[:topn]

    def similarity(self, w1: str, w2: str) -> float:
        """Cosine similarity between two words."""
        if w1 not in self.vectors or w2 not in self.vectors:
            raise KeyError(f"word not in vocabulary")
        v1 = self.vectors[w1]
        v2 = self.vectors[w2]
        np = self._np
        if np is not None:
            return float(np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2) + 1e-10))
        else:
            n1 = _PureVector.norm(v1)
            n2 = _PureVector.norm(v2)
            if n1 == 0 or n2 == 0:
                return 0.0
            return _PureVector.dot(v1, v2) / (n1 * n2)

    def get_vector(self, word: str):
        return self[word]

    @property
    def key_to_index(self):
        return {w: i for i, w in enumerate(self.index_to_key)}


def _sigmoid(x: float) -> float:
    if x > 6.0:
        return 1.0
    if x < -6.0:
        return 0.0
    return 1.0 / (1.0 + math.exp(-x))


class Word2Vec:
    """
    Pure-Python Word2Vec (Skip-gram with negative sampling).

    Compatible with gensim.models.Word2Vec API.
    """

    def __init__(
        self,
        sentences=None,
        vector_size: int = 100,
        window: int = 5,
        min_count: int = 5,
        workers: int = 1,
        sg: int = 1,
        negative: int = 5,
        alpha: float = 0.025,
        min_alpha: float = 0.0001,
        epochs: int = 5,
        seed: int = 42,
        sample: float = 1e-3,
        ns_exponent: float = 0.75,
    ):
        self.vector_size = vector_size
        self.window = window
        self.min_count = min_count
        self.workers = workers  # ignored in pure-Python, single-threaded
        self.sg = sg
        self.negative = negative
        self.alpha = alpha
        self.min_alpha = min_alpha
        self.epochs = epochs
        self.seed = seed
        self.sample = sample
        self.ns_exponent = ns_exponent

        self._np = _try_numpy()
        self._rng = random.Random(seed)

        # Vocabulary
        self._word_freq: Counter = Counter()
        self._vocab: dict = {}  # word -> index
        self._index2word: list = []

        # Vectors
        self._syn0 = None  # input vectors (word embeddings)
        self._syn1neg = None  # output vectors (for negative sampling)

        # Negative sampling table
        self._neg_table = []
        self._neg_table_size = 100_000

        # Public interface
        self.wv = KeyedVectors(vector_size)

        if sentences is not None:
            # Materialize to list if not re-iterable (e.g. generator)
            if not hasattr(sentences, '__len__') and not hasattr(sentences, '__getitem__'):
                sentences = list(sentences)
            self.build_vocab(sentences)
            self.train(sentences, total_examples=len(self._index2word), epochs=epochs)

    def build_vocab(self, sentences):
        """Build vocabulary from sentences."""
        self._word_freq = Counter()
        for sent in sentences:
            for word in sent:
                self._word_freq[word] += 1

        # Filter by min_count
        self._index2word = []
        self._vocab = {}
        for word, freq in self._word_freq.most_common():
            if freq >= self.min_count:
                idx = len(self._index2word)
                self._vocab[word] = idx
                self._index2word.append(word)

        vocab_size = len(self._index2word)
        if vocab_size == 0:
            return

        # Initialize vectors
        np = self._np
        if np is not None:
            rng = np.random.RandomState(self.seed)
            self._syn0 = (rng.rand(vocab_size, self.vector_size).astype(np.float32) - 0.5) / self.vector_size
            self._syn1neg = np.zeros((vocab_size, self.vector_size), dtype=np.float32)
        else:
            self._syn0 = [
                _PureVector.randn(self.vector_size, seed_val=self.seed + i)
                for i in range(vocab_size)
            ]
            self._syn1neg = [
                _PureVector.zeros(self.vector_size)
                for _ in range(vocab_size)
            ]

        # Build negative sampling table
        self._build_neg_table()

    def _build_neg_table(self):
        """Build unigram distribution table for negative sampling."""
        total = 0.0
        for word in self._index2word:
            total += self._word_freq[word] ** self.ns_exponent

        self._neg_table = []
        cumulative = 0.0
        word_idx = 0
        for i in range(self._neg_table_size):
            target = (i + 0.5) / self._neg_table_size * total
            while cumulative < target and word_idx < len(self._index2word):
                cumulative += self._word_freq[self._index2word[word_idx]] ** self.ns_exponent
                word_idx += 1
            self._neg_table.append(max(0, word_idx - 1))

    def _sample_negatives(self, count: int, exclude: int) -> list:
        """Sample negative examples."""
        negs = []
        while len(negs) < count:
            idx = self._neg_table[self._rng.randint(0, self._neg_table_size - 1)]
            if idx != exclude:
                negs.append(idx)
        return negs

    def _should_subsample(self, word: str) -> bool:
        """Subsampling of frequent words."""
        if self.sample <= 0:
            return False
        freq = self._word_freq[word]
        total = sum(self._word_freq[w] for w in self._index2word)
        if total == 0:
            return False
        f = freq / total
        prob_keep = (math.sqrt(f / self.sample) + 1) * (self.sample / f)
        return self._rng.random() > prob_keep

    def train(self, sentences, total_examples=None, epochs=None):
        """Train the model."""
        epochs = epochs or self.epochs
        vocab_size = len(self._index2word)
        if vocab_size == 0:
            return

        np = self._np
        total_words = sum(self._word_freq[w] for w in self._index2word)

        for epoch in range(epochs):
            lr = self.alpha - (self.alpha - self.min_alpha) * epoch / max(epochs - 1, 1)

            for sent in sentences:
                # Convert sentence to indices, with subsampling
                indices = []
                for word in sent:
                    if word in self._vocab and not self._should_subsample(word):
                        indices.append(self._vocab[word])

                if len(indices) < 2:
                    continue

                for pos, word_idx in enumerate(indices):
                    # Dynamic window
                    reduced_window = self._rng.randint(0, self.window - 1) if self.window > 1 else 0
                    start = max(0, pos - self.window + reduced_window)
                    end = min(len(indices), pos + self.window + 1 - reduced_window)

                    for ctx_pos in range(start, end):
                        if ctx_pos == pos:
                            continue
                        ctx_idx = indices[ctx_pos]

                        # Skip-gram with negative sampling
                        self._train_pair(word_idx, ctx_idx, lr, np)

        # Copy final vectors to KeyedVectors
        self._finalize_vectors()

    def _train_pair(self, word_idx: int, ctx_idx: int, lr: float, np):
        """Train one word-context pair with negative sampling."""
        negatives = self._sample_negatives(self.negative, ctx_idx)

        if np is not None:
            # Numpy fast path
            word_vec = self._syn0[word_idx]
            neu1e = np.zeros(self.vector_size, dtype=np.float32)

            # Positive sample
            ctx_vec = self._syn1neg[ctx_idx]
            dot = float(np.dot(word_vec, ctx_vec))
            g = (1.0 - _sigmoid(dot)) * lr
            neu1e += g * ctx_vec
            self._syn1neg[ctx_idx] += g * word_vec

            # Negative samples
            for neg_idx in negatives:
                neg_vec = self._syn1neg[neg_idx]
                dot = float(np.dot(word_vec, neg_vec))
                g = -_sigmoid(dot) * lr
                neu1e += g * neg_vec
                self._syn1neg[neg_idx] += g * word_vec

            self._syn0[word_idx] += neu1e
        else:
            # Pure Python path
            word_vec = self._syn0[word_idx]
            neu1e = _PureVector.zeros(self.vector_size)

            # Positive
            ctx_vec = self._syn1neg[ctx_idx]
            dot = _PureVector.dot(word_vec, ctx_vec)
            g = (1.0 - _sigmoid(dot)) * lr
            _PureVector.add_inplace(neu1e, ctx_vec, g)
            _PureVector.add_inplace(ctx_vec, word_vec, g)

            # Negatives
            for neg_idx in negatives:
                neg_vec = self._syn1neg[neg_idx]
                dot = _PureVector.dot(word_vec, neg_vec)
                g = -_sigmoid(dot) * lr
                _PureVector.add_inplace(neu1e, neg_vec, g)
                _PureVector.add_inplace(neg_vec, word_vec, g)

            _PureVector.add_inplace(word_vec, neu1e)

    def _finalize_vectors(self):
        """Copy trained vectors into KeyedVectors."""
        np = self._np
        self.wv = KeyedVectors(self.vector_size)
        for i, word in enumerate(self._index2word):
            vec = self._syn0[i]
            if np is not None:
                vec = vec.copy()
            else:
                vec = list(vec)
            self.wv.add_vector(word, vec)

    def save(self, path: str):
        """Save model to file (simple binary format)."""
        import json
        meta = {
            "vector_size": self.vector_size,
            "window": self.window,
            "min_count": self.min_count,
            "epochs": self.epochs,
            "vocab_size": len(self._index2word),
            "index2word": self._index2word,
        }
        with open(path, 'wb') as f:
            meta_bytes = json.dumps(meta).encode('utf-8')
            f.write(struct.pack('I', len(meta_bytes)))
            f.write(meta_bytes)
            # Write vectors
            for i in range(len(self._index2word)):
                vec = self._syn0[i]
                for v in vec:
                    f.write(struct.pack('f', float(v)))

    @classmethod
    def load(cls, path: str) -> 'Word2Vec':
        """Load model from file."""
        import json
        model = cls.__new__(cls)
        model._np = _try_numpy()

        with open(path, 'rb') as f:
            meta_len = struct.unpack('I', f.read(4))[0]
            meta = json.loads(f.read(meta_len).decode('utf-8'))

            model.vector_size = meta["vector_size"]
            model.window = meta["window"]
            model.min_count = meta["min_count"]
            model.epochs = meta["epochs"]
            model._index2word = meta["index2word"]
            model._vocab = {w: i for i, w in enumerate(model._index2word)}

            model.wv = KeyedVectors(model.vector_size)
            np = model._np
            for word in model._index2word:
                raw = f.read(model.vector_size * 4)
                values = struct.unpack(f'{model.vector_size}f', raw)
                if np is not None:
                    vec = np.array(values, dtype=np.float32)
                else:
                    vec = list(values)
                model.wv.add_vector(word, vec)

        return model
