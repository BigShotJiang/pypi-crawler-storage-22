"""
ion.compat.ion_math - Pure-Python numerical computing library for Ion.

Provides compatible implementations of commonly-used scipy submodules:
  - scipy_compat.sparse  (CSR, CSC, COO sparse matrices, basic operations)
  - scipy_compat.spatial (distance metrics, KDTree)
  - scipy_compat.optimize (minimize, root-finding, curve_fit)
  - scipy_compat.stats (distributions, statistical tests)
  - scipy_compat.linalg (decompositions, solvers)
  - scipy_compat.signal (convolution, filtering)
  - scipy_compat.special (gamma, beta, erf, etc.)
  - scipy_compat.interpolate (interp1d)

No external dependencies required. Will use numpy if available for speed.
"""

import math
import random
from collections import defaultdict
from typing import Optional, Callable, Tuple, List, Union


def _try_numpy():
    try:
        import numpy as np
        return np
    except ImportError:
        return None


# ============================================================================
# scipy_compat.sparse
# ============================================================================

class _SparseMatrix:
    """Base class for sparse matrices."""

    def __init__(self, shape):
        self.shape = shape
        self.dtype = float

    @property
    def nnz(self):
        raise NotImplementedError

    def toarray(self):
        raise NotImplementedError

    def todense(self):
        return self.toarray()

    def tocsr(self):
        raise NotImplementedError

    def tocsc(self):
        raise NotImplementedError

    def tocoo(self):
        raise NotImplementedError


class coo_matrix(_SparseMatrix):
    """Coordinate-format sparse matrix."""

    def __init__(self, arg=None, shape=None):
        if arg is None:
            if shape is None:
                shape = (0, 0)
            super().__init__(shape)
            self.row = []
            self.col = []
            self.data = []
        elif isinstance(arg, tuple):
            if len(arg) == 3:
                data, (row, col) = arg[0], (arg[1][0], arg[1][1])
            elif len(arg) == 2:
                # Could be (data, (row, col)) or (nrows, ncols)
                if isinstance(arg[0], (list, tuple)) and isinstance(arg[1], (list, tuple)) and len(arg[1]) == 2:
                    data = arg[0]
                    row, col = arg[1][0], arg[1][1]
                elif isinstance(arg[0], (int, float)) and isinstance(arg[1], (int, float)):
                    # Shape tuple
                    super().__init__((int(arg[0]), int(arg[1])))
                    self.row = []
                    self.col = []
                    self.data = []
                    return
                else:
                    super().__init__((int(arg[0]), int(arg[1])))
                    self.row = []
                    self.col = []
                    self.data = []
                    return
            else:
                raise ValueError(f"Invalid COO tuple length: {len(arg)}")
            self.data = list(data)
            self.row = list(row)
            self.col = list(col)
            if shape is None:
                shape = (max(row) + 1 if row else 0, max(col) + 1 if col else 0)
            super().__init__(shape)
        else:
            # Dense input
            super().__init__((len(arg), len(arg[0]) if arg else 0))
            self.row = []
            self.col = []
            self.data = []
            for i, r in enumerate(arg):
                for j, v in enumerate(r):
                    if v != 0:
                        self.row.append(i)
                        self.col.append(j)
                        self.data.append(float(v))

    @property
    def nnz(self):
        return len(self.data)

    def toarray(self):
        np = _try_numpy()
        rows, cols = self.shape
        if np is not None:
            arr = np.zeros(self.shape)
            for r, c, v in zip(self.row, self.col, self.data):
                arr[r, c] += v
            return arr
        else:
            arr = [[0.0] * cols for _ in range(rows)]
            for r, c, v in zip(self.row, self.col, self.data):
                arr[r][c] += v
            return arr

    def tocsr(self):
        return csr_matrix(self)

    def tocsc(self):
        return csc_matrix(self)

    def tocoo(self):
        return self


class csr_matrix(_SparseMatrix):
    """Compressed Sparse Row matrix."""

    def __init__(self, arg=None, shape=None):
        if isinstance(arg, coo_matrix):
            shape = arg.shape
            super().__init__(shape)
            self._from_coo(arg)
        elif isinstance(arg, csr_matrix):
            super().__init__(arg.shape)
            self.indptr = list(arg.indptr)
            self.indices = list(arg.indices)
            self.data = list(arg.data)
        elif isinstance(arg, tuple) and len(arg) == 2:
            super().__init__(arg)
            rows = arg[0]
            self.indptr = [0] * (rows + 1)
            self.indices = []
            self.data = []
        elif arg is not None:
            # Dense input
            if hasattr(arg, 'shape'):
                shape = tuple(arg.shape)
            else:
                shape = (len(arg), len(arg[0]) if arg else 0)
            super().__init__(shape)
            coo = coo_matrix(arg, shape=shape)
            self._from_coo(coo)
        else:
            if shape is None:
                shape = (0, 0)
            super().__init__(shape)
            self.indptr = [0] * (shape[0] + 1)
            self.indices = []
            self.data = []

    def _from_coo(self, coo):
        rows = self.shape[0]
        entries = sorted(zip(coo.row, coo.col, coo.data))

        self.indptr = [0] * (rows + 1)
        self.indices = []
        self.data = []

        for r, c, v in entries:
            self.indices.append(c)
            self.data.append(v)
            self.indptr[r + 1] = len(self.data)

        # Fill forward
        for i in range(1, rows + 1):
            if self.indptr[i] == 0 and self.indptr[i - 1] > 0:
                self.indptr[i] = self.indptr[i - 1]
            elif self.indptr[i] < self.indptr[i - 1]:
                self.indptr[i] = self.indptr[i - 1]

    @property
    def nnz(self):
        return len(self.data)

    def toarray(self):
        np = _try_numpy()
        rows, cols = self.shape
        if np is not None:
            arr = np.zeros(self.shape)
            for i in range(rows):
                for j in range(self.indptr[i], self.indptr[i + 1]):
                    arr[i, self.indices[j]] = self.data[j]
            return arr
        else:
            arr = [[0.0] * cols for _ in range(rows)]
            for i in range(rows):
                for j in range(self.indptr[i], self.indptr[i + 1]):
                    arr[i][self.indices[j]] = self.data[j]
            return arr

    def tocsr(self):
        return self

    def tocoo(self):
        row, col, data = [], [], []
        for i in range(self.shape[0]):
            for j in range(self.indptr[i], self.indptr[i + 1]):
                row.append(i)
                col.append(self.indices[j])
                data.append(self.data[j])
        return coo_matrix((data, (row, col)), shape=self.shape)

    def dot(self, other):
        """Matrix-vector or matrix-matrix product."""
        if isinstance(other, list):
            # Matrix-vector
            result = [0.0] * self.shape[0]
            for i in range(self.shape[0]):
                for j in range(self.indptr[i], self.indptr[i + 1]):
                    result[i] += self.data[j] * other[self.indices[j]]
            return result
        return NotImplemented

    def getrow(self, i):
        start, end = self.indptr[i], self.indptr[i + 1]
        row_data = self.data[start:end]
        row_indices = self.indices[start:end]
        coo = coo_matrix((row_data, ([0] * len(row_data), row_indices)),
                         shape=(1, self.shape[1]))
        return csr_matrix(coo)


class csc_matrix(_SparseMatrix):
    """Compressed Sparse Column matrix."""

    def __init__(self, arg=None, shape=None):
        if isinstance(arg, coo_matrix):
            shape = arg.shape
            super().__init__(shape)
            self._from_coo(arg)
        elif isinstance(arg, tuple) and len(arg) == 2:
            super().__init__(arg)
            cols = arg[1]
            self.indptr = [0] * (cols + 1)
            self.indices = []
            self.data = []
        else:
            if shape is None:
                shape = (0, 0)
            super().__init__(shape)
            self.indptr = [0] * (shape[1] + 1)
            self.indices = []
            self.data = []

    def _from_coo(self, coo):
        cols = self.shape[1]
        entries = sorted(zip(coo.col, coo.row, coo.data))

        self.indptr = [0] * (cols + 1)
        self.indices = []
        self.data = []

        for c, r, v in entries:
            self.indices.append(r)
            self.data.append(v)
            self.indptr[c + 1] = len(self.data)

        for i in range(1, cols + 1):
            if self.indptr[i] < self.indptr[i - 1]:
                self.indptr[i] = self.indptr[i - 1]

    @property
    def nnz(self):
        return len(self.data)

    def toarray(self):
        np = _try_numpy()
        rows, cols = self.shape
        if np is not None:
            arr = np.zeros(self.shape)
            for j in range(cols):
                for k in range(self.indptr[j], self.indptr[j + 1]):
                    arr[self.indices[k], j] = self.data[k]
            return arr
        else:
            arr = [[0.0] * cols for _ in range(rows)]
            for j in range(cols):
                for k in range(self.indptr[j], self.indptr[j + 1]):
                    arr[self.indices[k]][j] = self.data[k]
            return arr

    def tocsc(self):
        return self

    def tocoo(self):
        row, col, data = [], [], []
        for j in range(self.shape[1]):
            for k in range(self.indptr[j], self.indptr[j + 1]):
                row.append(self.indices[k])
                col.append(j)
                data.append(self.data[k])
        return coo_matrix((data, (row, col)), shape=self.shape)


def eye_sparse(n, format="csr"):
    """Sparse identity matrix."""
    row = list(range(n))
    col = list(range(n))
    data = [1.0] * n
    coo = coo_matrix((data, (row, col)), shape=(n, n))
    if format == "csr":
        return coo.tocsr()
    elif format == "csc":
        return coo.tocsc()
    return coo


def diags(diagonals, offsets=0, shape=None):
    """Construct a sparse diagonal matrix."""
    if isinstance(offsets, int):
        offsets = [offsets]
        diagonals = [diagonals]

    row, col, data = [], [], []
    for diag, offset in zip(diagonals, offsets):
        for i, v in enumerate(diag):
            r = i - min(0, offset)
            c = i + max(0, offset)
            if shape and (r >= shape[0] or c >= shape[1]):
                break
            row.append(r)
            col.append(c)
            data.append(float(v))

    if shape is None:
        n = max(max(row) + 1, max(col) + 1) if row else 0
        shape = (n, n)

    return coo_matrix((data, (row, col)), shape=shape).tocsr()


class sparse:
    """Namespace matching scipy.sparse."""
    coo_matrix = coo_matrix
    csr_matrix = csr_matrix
    csc_matrix = csc_matrix
    eye = staticmethod(eye_sparse)
    diags = staticmethod(diags)

    @staticmethod
    def issparse(x):
        return isinstance(x, _SparseMatrix)

    @staticmethod
    def hstack(matrices, format="csr"):
        """Horizontal stack of sparse matrices."""
        all_coo = [m.tocoo() for m in matrices]
        row, col, data = [], [], []
        col_offset = 0
        total_rows = max(m.shape[0] for m in all_coo)
        for coo in all_coo:
            row.extend(coo.row)
            col.extend([c + col_offset for c in coo.col])
            data.extend(coo.data)
            col_offset += coo.shape[1]
        result = coo_matrix((data, (row, col)), shape=(total_rows, col_offset))
        return result.tocsr() if format == "csr" else result

    @staticmethod
    def vstack(matrices, format="csr"):
        """Vertical stack of sparse matrices."""
        all_coo = [m.tocoo() for m in matrices]
        row, col, data = [], [], []
        row_offset = 0
        total_cols = max(m.shape[1] for m in all_coo)
        for coo in all_coo:
            row.extend([r + row_offset for r in coo.row])
            col.extend(coo.col)
            data.extend(coo.data)
            row_offset += coo.shape[0]
        result = coo_matrix((data, (row, col)), shape=(row_offset, total_cols))
        return result.tocsr() if format == "csr" else result


# ============================================================================
# scipy_compat.spatial
# ============================================================================

class _DistanceMetrics:
    """Common distance metrics."""

    @staticmethod
    def euclidean(u, v):
        return math.sqrt(sum((a - b) ** 2 for a, b in zip(u, v)))

    @staticmethod
    def cosine(u, v):
        dot = sum(a * b for a, b in zip(u, v))
        nu = math.sqrt(sum(a * a for a in u))
        nv = math.sqrt(sum(b * b for b in v))
        if nu == 0 or nv == 0:
            return 1.0
        return 1.0 - dot / (nu * nv)

    @staticmethod
    def manhattan(u, v):
        return sum(abs(a - b) for a, b in zip(u, v))

    @staticmethod
    def chebyshev(u, v):
        return max(abs(a - b) for a, b in zip(u, v))

    @staticmethod
    def minkowski(u, v, p=2):
        return sum(abs(a - b) ** p for a, b in zip(u, v)) ** (1.0 / p)

    @staticmethod
    def hamming(u, v):
        n = len(u)
        if n == 0:
            return 0.0
        return sum(a != b for a, b in zip(u, v)) / n

    @staticmethod
    def jaccard(u, v):
        set_u = set(i for i, x in enumerate(u) if x)
        set_v = set(i for i, x in enumerate(v) if x)
        inter = len(set_u & set_v)
        union = len(set_u | set_v)
        if union == 0:
            return 0.0
        return 1.0 - inter / union

    @staticmethod
    def correlation(u, v):
        n = len(u)
        if n == 0:
            return 0.0
        mean_u = sum(u) / n
        mean_v = sum(v) / n
        u_centered = [a - mean_u for a in u]
        v_centered = [b - mean_v for b in v]
        dot = sum(a * b for a, b in zip(u_centered, v_centered))
        nu = math.sqrt(sum(a * a for a in u_centered))
        nv = math.sqrt(sum(b * b for b in v_centered))
        if nu == 0 or nv == 0:
            return 1.0
        return 1.0 - dot / (nu * nv)


class KDTree:
    """Simple KD-tree for nearest-neighbor queries."""

    def __init__(self, data, leafsize=10):
        self.data = [list(p) for p in data]
        self.n = len(data)
        self.dim = len(data[0]) if data else 0
        self.leafsize = leafsize
        self._tree = self._build(list(range(self.n)), 0)

    def _build(self, indices, depth):
        if not indices:
            return None
        if len(indices) <= self.leafsize:
            return {"leaf": True, "indices": indices}

        axis = depth % self.dim
        indices.sort(key=lambda i: self.data[i][axis])
        mid = len(indices) // 2

        return {
            "leaf": False,
            "axis": axis,
            "point_idx": indices[mid],
            "median": self.data[indices[mid]][axis],
            "left": self._build(indices[:mid], depth + 1),
            "right": self._build(indices[mid + 1:], depth + 1),
        }

    def query(self, x, k=1):
        """Find k nearest neighbors. Returns (distances, indices)."""
        if isinstance(x[0], (list, tuple)):
            # Batch query
            dists, idxs = [], []
            for point in x:
                d, i = self._query_single(point, k)
                dists.append(d)
                idxs.append(i)
            return dists, idxs
        return self._query_single(x, k)

    def _query_single(self, point, k):
        best = []  # list of (dist, idx)
        self._search(self._tree, point, k, best)
        best.sort()
        dists = [b[0] for b in best[:k]]
        idxs = [b[1] for b in best[:k]]
        return dists, idxs

    def _search(self, node, point, k, best):
        if node is None:
            return
        if node.get("leaf"):
            for idx in node["indices"]:
                d = _DistanceMetrics.euclidean(point, self.data[idx])
                if len(best) < k:
                    best.append((d, idx))
                    best.sort()
                elif d < best[-1][0]:
                    best[-1] = (d, idx)
                    best.sort()
            return

        axis = node["axis"]
        idx = node["point_idx"]
        d = _DistanceMetrics.euclidean(point, self.data[idx])

        if len(best) < k:
            best.append((d, idx))
            best.sort()
        elif d < best[-1][0]:
            best[-1] = (d, idx)
            best.sort()

        diff = point[axis] - node["median"]
        close = node["left"] if diff <= 0 else node["right"]
        away = node["right"] if diff <= 0 else node["left"]

        self._search(close, point, k, best)

        if len(best) < k or abs(diff) < best[-1][0]:
            self._search(away, point, k, best)


def cdist(XA, XB, metric="euclidean"):
    """Compute pairwise distances between two sets of points."""
    metric_fn = {
        "euclidean": _DistanceMetrics.euclidean,
        "cosine": _DistanceMetrics.cosine,
        "manhattan": _DistanceMetrics.manhattan,
        "cityblock": _DistanceMetrics.manhattan,
        "chebyshev": _DistanceMetrics.chebyshev,
        "hamming": _DistanceMetrics.hamming,
        "correlation": _DistanceMetrics.correlation,
    }.get(metric, _DistanceMetrics.euclidean)

    np = _try_numpy()
    n, m = len(XA), len(XB)
    if np is not None:
        result = np.zeros((n, m))
        for i in range(n):
            for j in range(m):
                result[i, j] = metric_fn(XA[i], XB[j])
        return result
    else:
        return [[metric_fn(XA[i], XB[j]) for j in range(m)] for i in range(n)]


def pdist(X, metric="euclidean"):
    """Pairwise distances in condensed form."""
    metric_fn = {
        "euclidean": _DistanceMetrics.euclidean,
        "cosine": _DistanceMetrics.cosine,
        "manhattan": _DistanceMetrics.manhattan,
        "cityblock": _DistanceMetrics.manhattan,
        "correlation": _DistanceMetrics.correlation,
    }.get(metric, _DistanceMetrics.euclidean)

    n = len(X)
    result = []
    for i in range(n):
        for j in range(i + 1, n):
            result.append(metric_fn(X[i], X[j]))
    return result


def squareform(X):
    """Convert condensed distance matrix to square form or vice versa."""
    if isinstance(X, list) and isinstance(X[0], (list, tuple)):
        # Square to condensed
        n = len(X)
        result = []
        for i in range(n):
            for j in range(i + 1, n):
                result.append(X[i][j])
        return result
    else:
        # Condensed to square
        m = len(X)
        n = int((1 + math.sqrt(1 + 8 * m)) / 2)
        result = [[0.0] * n for _ in range(n)]
        k = 0
        for i in range(n):
            for j in range(i + 1, n):
                result[i][j] = X[k]
                result[j][i] = X[k]
                k += 1
        return result


class spatial:
    """Namespace matching scipy.spatial."""

    class distance:
        euclidean = staticmethod(_DistanceMetrics.euclidean)
        cosine = staticmethod(_DistanceMetrics.cosine)
        cityblock = staticmethod(_DistanceMetrics.manhattan)
        chebyshev = staticmethod(_DistanceMetrics.chebyshev)
        minkowski = staticmethod(_DistanceMetrics.minkowski)
        hamming = staticmethod(_DistanceMetrics.hamming)
        jaccard = staticmethod(_DistanceMetrics.jaccard)
        correlation = staticmethod(_DistanceMetrics.correlation)
        cdist = staticmethod(cdist)
        pdist = staticmethod(pdist)
        squareform = staticmethod(squareform)

    KDTree = KDTree


# ============================================================================
# scipy_compat.optimize
# ============================================================================

def _golden_section(f, a, b, tol=1e-5, maxiter=500):
    """Golden section search for 1D minimization."""
    gr = (math.sqrt(5) + 1) / 2
    c = b - (b - a) / gr
    d = a + (b - a) / gr
    for _ in range(maxiter):
        if abs(b - a) < tol:
            break
        if f(c) < f(d):
            b = d
        else:
            a = c
        c = b - (b - a) / gr
        d = a + (b - a) / gr
    return (a + b) / 2


class OptimizeResult:
    """Result of an optimization."""

    def __init__(self, x, fun, success=True, message="", nit=0, nfev=0):
        self.x = x
        self.fun = fun
        self.success = success
        self.message = message
        self.nit = nit
        self.nfev = nfev

    def __repr__(self):
        return f"OptimizeResult(x={self.x}, fun={self.fun}, success={self.success})"


def minimize_scalar(fun, bounds=None, method="bounded", options=None):
    """Minimize a scalar function."""
    options = options or {}
    maxiter = options.get("maxiter", 500)
    tol = options.get("xatol", 1e-5)

    if bounds:
        a, b = bounds
    else:
        a, b = -1e6, 1e6

    x_min = _golden_section(fun, a, b, tol=tol, maxiter=maxiter)
    return OptimizeResult(x=x_min, fun=fun(x_min))


def minimize(fun, x0, method="nelder-mead", bounds=None, options=None, args=()):
    """Minimize a multivariate function using Nelder-Mead simplex."""
    options = options or {}
    maxiter = options.get("maxiter", 1000)
    tol = options.get("xatol", 1e-8)
    n = len(x0)
    x0 = [float(v) for v in x0]

    def f(x):
        return fun(x, *args)

    if method.lower() in ("nelder-mead", "nm"):
        return _nelder_mead(f, x0, maxiter=maxiter, tol=tol)
    elif method.lower() in ("l-bfgs-b", "bfgs"):
        return _gradient_descent(f, x0, maxiter=maxiter, tol=tol, bounds=bounds)
    elif method.lower() == "powell":
        return _powell(f, x0, maxiter=maxiter, tol=tol)
    else:
        return _nelder_mead(f, x0, maxiter=maxiter, tol=tol)


def _nelder_mead(f, x0, maxiter=1000, tol=1e-8):
    """Nelder-Mead simplex optimization."""
    n = len(x0)
    # Initialize simplex
    simplex = [list(x0)]
    for i in range(n):
        point = list(x0)
        point[i] += 0.05 if x0[i] == 0 else 0.05 * x0[i]
        simplex.append(point)

    values = [f(p) for p in simplex]
    nfev = n + 1

    alpha, gamma, rho, sigma = 1.0, 2.0, 0.5, 0.5

    for nit in range(maxiter):
        # Sort
        order = sorted(range(n + 1), key=lambda i: values[i])
        simplex = [simplex[i] for i in order]
        values = [values[i] for i in order]

        # Convergence check
        spread = max(values) - min(values)
        if spread < tol:
            return OptimizeResult(x=simplex[0], fun=values[0], success=True, nit=nit, nfev=nfev)

        # Centroid (excluding worst)
        centroid = [sum(simplex[i][j] for i in range(n)) / n for j in range(n)]

        # Reflection
        worst = simplex[-1]
        reflected = [centroid[j] + alpha * (centroid[j] - worst[j]) for j in range(n)]
        fr = f(reflected)
        nfev += 1

        if values[0] <= fr < values[-2]:
            simplex[-1] = reflected
            values[-1] = fr
            continue

        if fr < values[0]:
            # Expansion
            expanded = [centroid[j] + gamma * (reflected[j] - centroid[j]) for j in range(n)]
            fe = f(expanded)
            nfev += 1
            if fe < fr:
                simplex[-1] = expanded
                values[-1] = fe
            else:
                simplex[-1] = reflected
                values[-1] = fr
            continue

        # Contraction
        contracted = [centroid[j] + rho * (worst[j] - centroid[j]) for j in range(n)]
        fc = f(contracted)
        nfev += 1
        if fc < values[-1]:
            simplex[-1] = contracted
            values[-1] = fc
            continue

        # Shrink
        best = simplex[0]
        for i in range(1, n + 1):
            simplex[i] = [best[j] + sigma * (simplex[i][j] - best[j]) for j in range(n)]
            values[i] = f(simplex[i])
            nfev += 1

    return OptimizeResult(x=simplex[0], fun=values[0], success=False, nit=maxiter, nfev=nfev,
                          message="Maximum iterations reached")


def _gradient_descent(f, x0, maxiter=1000, tol=1e-8, bounds=None, lr=0.01):
    """Simple gradient descent with numerical gradients."""
    x = list(x0)
    n = len(x)
    h = 1e-7
    best_f = f(x)
    nfev = 1

    for nit in range(maxiter):
        # Numerical gradient
        grad = []
        for i in range(n):
            x_plus = list(x)
            x_plus[i] += h
            fp = f(x_plus)
            nfev += 1
            grad.append((fp - best_f) / h)

        # Update
        grad_norm = math.sqrt(sum(g * g for g in grad))
        if grad_norm < tol:
            return OptimizeResult(x=x, fun=best_f, success=True, nit=nit, nfev=nfev)

        for i in range(n):
            x[i] -= lr * grad[i]
            if bounds:
                lo, hi = bounds[i]
                if lo is not None:
                    x[i] = max(x[i], lo)
                if hi is not None:
                    x[i] = min(x[i], hi)

        new_f = f(x)
        nfev += 1

        if abs(new_f - best_f) < tol:
            return OptimizeResult(x=x, fun=new_f, success=True, nit=nit, nfev=nfev)
        best_f = new_f

    return OptimizeResult(x=x, fun=best_f, success=False, nit=maxiter, nfev=nfev)


def _powell(f, x0, maxiter=1000, tol=1e-8):
    """Powell's direction set method."""
    n = len(x0)
    x = list(x0)
    # Initialize directions as identity
    directions = [[1.0 if i == j else 0.0 for j in range(n)] for i in range(n)]
    fx = f(x)
    nfev = 1

    for nit in range(maxiter):
        x_old = list(x)
        fx_old = fx

        for i in range(n):
            d = directions[i]

            def line_func(alpha):
                return f([x[j] + alpha * d[j] for j in range(n)])

            alpha = _golden_section(line_func, -1.0, 1.0, tol=tol)
            x = [x[j] + alpha * d[j] for j in range(n)]
            fx = f(x)
            nfev += 2  # approximate

        if abs(fx - fx_old) < tol:
            return OptimizeResult(x=x, fun=fx, success=True, nit=nit, nfev=nfev)

    return OptimizeResult(x=x, fun=fx, success=False, nit=maxiter, nfev=nfev)


def brentq(f, a, b, xtol=1e-12, maxiter=100):
    """Find root using Brent's method."""
    fa, fb = f(a), f(b)
    if fa * fb > 0:
        raise ValueError("f(a) and f(b) must have different signs")

    c, fc = a, fa
    d = e = b - a

    for _ in range(maxiter):
        if fb * fc > 0:
            c, fc = a, fa
            d = e = b - a
        if abs(fc) < abs(fb):
            a, b, c = b, c, b
            fa, fb, fc = fb, fc, fb

        tol1 = 2 * 2.2e-16 * abs(b) + 0.5 * xtol
        m = 0.5 * (c - b)

        if abs(m) <= tol1 or fb == 0:
            return b

        if abs(e) >= tol1 and abs(fa) > abs(fb):
            s = fb / fa
            if a == c:
                p = 2 * m * s
                q = 1 - s
            else:
                q_val = fa / fc
                r = fb / fc
                p = s * (2 * m * q_val * (q_val - r) - (b - a) * (r - 1))
                q = (q_val - 1) * (r - 1) * (s - 1)
            if p > 0:
                q = -q
            else:
                p = -p
            if 2 * p < min(3 * m * q - abs(tol1 * q), abs(e * q)):
                e, d = d, p / q
            else:
                d = e = m
        else:
            d = e = m

        a, fa = b, fb
        if abs(d) > tol1:
            b += d
        else:
            b += tol1 if m > 0 else -tol1
        fb = f(b)

    return b


def bisect(f, a, b, xtol=1e-12, maxiter=100):
    """Find root using bisection method."""
    for _ in range(maxiter):
        c = (a + b) / 2
        if abs(b - a) < xtol:
            return c
        if f(c) * f(a) < 0:
            b = c
        else:
            a = c
    return (a + b) / 2


def curve_fit(f, xdata, ydata, p0=None, maxfev=1000):
    """Fit function f(x, *params) to data using least squares."""
    if p0 is None:
        # Try to determine number of params
        import inspect
        sig = inspect.signature(f)
        n_params = len(sig.parameters) - 1  # exclude x
        p0 = [1.0] * n_params

    def residual(params):
        return sum((f(x, *params) - y) ** 2 for x, y in zip(xdata, ydata))

    result = minimize(residual, p0, options={"maxiter": maxfev})
    return result.x, None  # (popt, pcov) - pcov not computed


class optimize:
    """Namespace matching scipy.optimize."""
    minimize = staticmethod(minimize)
    minimize_scalar = staticmethod(minimize_scalar)
    brentq = staticmethod(brentq)
    bisect = staticmethod(bisect)
    curve_fit = staticmethod(curve_fit)
    OptimizeResult = OptimizeResult


# ============================================================================
# scipy_compat.stats
# ============================================================================

def _norm_pdf(x, loc=0, scale=1):
    z = (x - loc) / scale
    return math.exp(-0.5 * z * z) / (scale * math.sqrt(2 * math.pi))


def _norm_cdf(x, loc=0, scale=1):
    z = (x - loc) / scale
    return 0.5 * (1 + math.erf(z / math.sqrt(2)))


def _norm_ppf(p, loc=0, scale=1):
    """Inverse normal CDF using rational approximation."""
    if p <= 0:
        return float('-inf')
    if p >= 1:
        return float('inf')

    # Rational approximation (Abramowitz and Stegun)
    if p < 0.5:
        t = math.sqrt(-2 * math.log(p))
    else:
        t = math.sqrt(-2 * math.log(1 - p))

    c0, c1, c2 = 2.515517, 0.802853, 0.010328
    d1, d2, d3 = 1.432788, 0.189269, 0.001308

    x = t - (c0 + c1 * t + c2 * t * t) / (1 + d1 * t + d2 * t * t + d3 * t * t * t)
    if p < 0.5:
        x = -x

    return x * scale + loc


class _NormDist:
    """Normal distribution."""

    @staticmethod
    def pdf(x, loc=0, scale=1):
        return _norm_pdf(x, loc, scale)

    @staticmethod
    def cdf(x, loc=0, scale=1):
        return _norm_cdf(x, loc, scale)

    @staticmethod
    def ppf(q, loc=0, scale=1):
        return _norm_ppf(q, loc, scale)

    @staticmethod
    def rvs(loc=0, scale=1, size=1, random_state=None):
        rng = random.Random(random_state)
        if isinstance(size, int):
            return [rng.gauss(loc, scale) for _ in range(size)]
        return [[rng.gauss(loc, scale) for _ in range(size[1])] for _ in range(size[0])]

    @staticmethod
    def fit(data):
        n = len(data)
        mu = sum(data) / n
        var = sum((x - mu) ** 2 for x in data) / n
        return mu, math.sqrt(var)


class _UniformDist:
    """Uniform distribution."""

    @staticmethod
    def pdf(x, loc=0, scale=1):
        if loc <= x <= loc + scale:
            return 1.0 / scale
        return 0.0

    @staticmethod
    def cdf(x, loc=0, scale=1):
        if x < loc:
            return 0.0
        if x > loc + scale:
            return 1.0
        return (x - loc) / scale

    @staticmethod
    def ppf(q, loc=0, scale=1):
        return loc + q * scale

    @staticmethod
    def rvs(loc=0, scale=1, size=1, random_state=None):
        rng = random.Random(random_state)
        return [rng.uniform(loc, loc + scale) for _ in range(size)]


class _ExponDist:
    """Exponential distribution."""

    @staticmethod
    def pdf(x, loc=0, scale=1):
        if x < loc:
            return 0.0
        z = (x - loc) / scale
        return math.exp(-z) / scale

    @staticmethod
    def cdf(x, loc=0, scale=1):
        if x < loc:
            return 0.0
        return 1 - math.exp(-(x - loc) / scale)

    @staticmethod
    def ppf(q, loc=0, scale=1):
        return loc - scale * math.log(1 - q)

    @staticmethod
    def rvs(loc=0, scale=1, size=1, random_state=None):
        rng = random.Random(random_state)
        return [loc - scale * math.log(rng.random() or 1e-10) for _ in range(size)]


def pearsonr(x, y):
    """Pearson correlation coefficient and p-value."""
    n = len(x)
    if n < 3:
        return 0.0, 1.0

    mx = sum(x) / n
    my = sum(y) / n

    xm = [xi - mx for xi in x]
    ym = [yi - my for yi in y]

    num = sum(a * b for a, b in zip(xm, ym))
    den_x = math.sqrt(sum(a * a for a in xm))
    den_y = math.sqrt(sum(b * b for b in ym))

    if den_x == 0 or den_y == 0:
        return 0.0, 1.0

    r = num / (den_x * den_y)
    r = max(-1.0, min(1.0, r))

    # Approximate p-value using t-distribution
    if abs(r) == 1.0:
        return r, 0.0
    t_stat = r * math.sqrt((n - 2) / (1 - r * r))
    # Approximate p using normal for large n
    p = 2 * (1 - _norm_cdf(abs(t_stat)))
    return r, p


def spearmanr(x, y):
    """Spearman rank correlation."""
    n = len(x)
    rank_x = _rank(x)
    rank_y = _rank(y)
    return pearsonr(rank_x, rank_y)


def _rank(data):
    """Compute ranks with tie-breaking."""
    indexed = sorted(enumerate(data), key=lambda t: t[1])
    ranks = [0.0] * len(data)
    i = 0
    while i < len(indexed):
        j = i
        while j < len(indexed) and indexed[j][1] == indexed[i][1]:
            j += 1
        avg_rank = sum(range(i + 1, j + 1)) / (j - i)
        for k in range(i, j):
            ranks[indexed[k][0]] = avg_rank
        i = j
    return ranks


def kendalltau(x, y):
    """Kendall's tau."""
    n = len(x)
    concordant = discordant = 0
    for i in range(n):
        for j in range(i + 1, n):
            dx = x[i] - x[j]
            dy = y[i] - y[j]
            if dx * dy > 0:
                concordant += 1
            elif dx * dy < 0:
                discordant += 1
    denom = n * (n - 1) / 2
    if denom == 0:
        return 0.0, 1.0
    tau = (concordant - discordant) / denom
    return tau, 0.0  # p-value approximation omitted


def ttest_ind(a, b):
    """Independent two-sample t-test."""
    na, nb = len(a), len(b)
    ma = sum(a) / na
    mb = sum(b) / nb
    va = sum((x - ma) ** 2 for x in a) / (na - 1) if na > 1 else 0
    vb = sum((x - mb) ** 2 for x in b) / (nb - 1) if nb > 1 else 0

    se = math.sqrt(va / na + vb / nb) if (va / na + vb / nb) > 0 else 1e-10
    t = (ma - mb) / se

    # Welch's df approximation
    num = (va / na + vb / nb) ** 2
    denom = (va / na) ** 2 / (na - 1) + (vb / nb) ** 2 / (nb - 1) if (na > 1 and nb > 1) else 1
    df = num / denom if denom > 0 else 1

    # Approximate p-value
    p = 2 * (1 - _norm_cdf(abs(t)))
    return t, p


def ttest_1samp(a, popmean):
    """One-sample t-test."""
    n = len(a)
    m = sum(a) / n
    s = math.sqrt(sum((x - m) ** 2 for x in a) / (n - 1)) if n > 1 else 1e-10
    t = (m - popmean) / (s / math.sqrt(n))
    p = 2 * (1 - _norm_cdf(abs(t)))
    return t, p


def chi2_contingency(observed):
    """Chi-square test of independence for contingency table."""
    rows = len(observed)
    cols = len(observed[0])
    row_totals = [sum(row) for row in observed]
    col_totals = [sum(observed[r][c] for r in range(rows)) for c in range(cols)]
    total = sum(row_totals)

    if total == 0:
        return 0.0, 1.0, (rows - 1) * (cols - 1), observed

    chi2 = 0.0
    expected = [[0.0] * cols for _ in range(rows)]
    for r in range(rows):
        for c in range(cols):
            e = row_totals[r] * col_totals[c] / total
            expected[r][c] = e
            if e > 0:
                chi2 += (observed[r][c] - e) ** 2 / e

    df = (rows - 1) * (cols - 1)
    # Approximate p-value
    p = 1.0 - _norm_cdf(math.sqrt(chi2) if chi2 > 0 else 0)
    return chi2, p, df, expected


def ks_2samp(data1, data2):
    """Two-sample Kolmogorov-Smirnov test."""
    n1, n2 = len(data1), len(data2)
    all_data = sorted([(v, 0) for v in data1] + [(v, 1) for v in data2])

    d_max = 0.0
    ecdf1 = ecdf2 = 0.0
    for val, group in all_data:
        if group == 0:
            ecdf1 += 1.0 / n1
        else:
            ecdf2 += 1.0 / n2
        d_max = max(d_max, abs(ecdf1 - ecdf2))

    # Approximate p-value
    en = math.sqrt(n1 * n2 / (n1 + n2))
    p = 2 * math.exp(-2 * (d_max * en) ** 2) if d_max > 0 else 1.0
    p = min(1.0, max(0.0, p))
    return d_max, p


def zscore(data, ddof=0):
    """Compute z-scores."""
    n = len(data)
    mu = sum(data) / n
    var = sum((x - mu) ** 2 for x in data) / (n - ddof) if n > ddof else 1.0
    std = math.sqrt(var)
    if std == 0:
        return [0.0] * n
    return [(x - mu) / std for x in data]


def entropy(pk, qk=None, base=None):
    """Compute entropy / KL divergence."""
    if qk is None:
        # Shannon entropy
        total = sum(pk)
        if total == 0:
            return 0.0
        h = 0.0
        for p in pk:
            if p > 0:
                pp = p / total
                h -= pp * math.log(pp)
        if base:
            h /= math.log(base)
        return h
    else:
        # KL divergence
        kl = 0.0
        for p, q in zip(pk, qk):
            if p > 0 and q > 0:
                kl += p * math.log(p / q)
        if base:
            kl /= math.log(base)
        return kl


def describe(data):
    """Descriptive statistics."""
    n = len(data)
    mn = min(data)
    mx = max(data)
    mu = sum(data) / n
    var = sum((x - mu) ** 2 for x in data) / (n - 1) if n > 1 else 0.0
    skew_val = sum((x - mu) ** 3 for x in data) / (n * var ** 1.5) if var > 0 else 0.0
    kurt_val = sum((x - mu) ** 4 for x in data) / (n * var ** 2) - 3 if var > 0 else 0.0
    return n, (mn, mx), mu, var, skew_val, kurt_val


class stats:
    """Namespace matching scipy.stats."""
    norm = _NormDist
    uniform = _UniformDist
    expon = _ExponDist
    pearsonr = staticmethod(pearsonr)
    spearmanr = staticmethod(spearmanr)
    kendalltau = staticmethod(kendalltau)
    ttest_ind = staticmethod(ttest_ind)
    ttest_1samp = staticmethod(ttest_1samp)
    chi2_contingency = staticmethod(chi2_contingency)
    ks_2samp = staticmethod(ks_2samp)
    zscore = staticmethod(zscore)
    entropy = staticmethod(entropy)
    describe = staticmethod(describe)


# ============================================================================
# scipy_compat.linalg
# ============================================================================

def _mat_mult(A, B):
    """Matrix multiplication."""
    rows_a, cols_a = len(A), len(A[0])
    rows_b, cols_b = len(B), len(B[0])
    assert cols_a == rows_b
    C = [[0.0] * cols_b for _ in range(rows_a)]
    for i in range(rows_a):
        for k in range(cols_a):
            if A[i][k] == 0:
                continue
            for j in range(cols_b):
                C[i][j] += A[i][k] * B[k][j]
    return C


def _mat_transpose(A):
    rows, cols = len(A), len(A[0])
    return [[A[i][j] for i in range(rows)] for j in range(cols)]


def lu_factor(A):
    """LU decomposition with partial pivoting. Returns (LU, piv)."""
    n = len(A)
    LU = [list(row) for row in A]
    piv = list(range(n))

    for k in range(n):
        # Partial pivoting
        max_val = abs(LU[k][k])
        max_row = k
        for i in range(k + 1, n):
            if abs(LU[i][k]) > max_val:
                max_val = abs(LU[i][k])
                max_row = i
        if max_row != k:
            LU[k], LU[max_row] = LU[max_row], LU[k]
            piv[k], piv[max_row] = piv[max_row], piv[k]

        if LU[k][k] == 0:
            continue

        for i in range(k + 1, n):
            LU[i][k] /= LU[k][k]
            for j in range(k + 1, n):
                LU[i][j] -= LU[i][k] * LU[k][j]

    return LU, piv


def lu_solve(lu_piv, b):
    """Solve Ax=b given LU factorization."""
    LU, piv = lu_piv
    n = len(b)

    # Apply permutation
    x = [b[piv[i]] for i in range(n)]

    # Forward substitution
    for i in range(n):
        for j in range(i):
            x[i] -= LU[i][j] * x[j]

    # Back substitution
    for i in range(n - 1, -1, -1):
        for j in range(i + 1, n):
            x[i] -= LU[i][j] * x[j]
        if LU[i][i] != 0:
            x[i] /= LU[i][i]

    return x


def solve(A, b):
    """Solve Ax = b."""
    np = _try_numpy()
    if np is not None:
        return np.linalg.solve(A, b).tolist()
    lu_piv = lu_factor(A)
    return lu_solve(lu_piv, b)


def inv(A):
    """Matrix inverse."""
    np = _try_numpy()
    if np is not None:
        return np.linalg.inv(A).tolist()
    n = len(A)
    result = []
    lu_piv = lu_factor(A)
    for i in range(n):
        e = [1.0 if j == i else 0.0 for j in range(n)]
        col = lu_solve(lu_piv, e)
        result.append(col)
    return _mat_transpose(result)


def det(A):
    """Matrix determinant."""
    np = _try_numpy()
    if np is not None:
        return float(np.linalg.det(A))
    n = len(A)
    if n == 1:
        return A[0][0]
    if n == 2:
        return A[0][0] * A[1][1] - A[0][1] * A[1][0]

    LU, piv = lu_factor(A)
    d = 1.0
    swaps = sum(1 for i, p in enumerate(piv) if i != p)
    sign = (-1) ** swaps
    for i in range(n):
        d *= LU[i][i]
    return d * sign


def norm(x, ord=None):
    """Vector or matrix norm."""
    if isinstance(x[0], (list, tuple)):
        # Matrix norm
        if ord is None or ord == "fro":
            return math.sqrt(sum(v ** 2 for row in x for v in row))
    else:
        # Vector norm
        if ord is None or ord == 2:
            return math.sqrt(sum(v ** 2 for v in x))
        if ord == 1:
            return sum(abs(v) for v in x)
        if ord == float('inf'):
            return max(abs(v) for v in x)
    return math.sqrt(sum(v ** 2 for v in x))


def eigh(A):
    """Eigenvalues and eigenvectors of symmetric matrix (power iteration)."""
    np = _try_numpy()
    if np is not None:
        w, v = np.linalg.eigh(A)
        return w.tolist(), v.tolist()

    n = len(A)
    # Simple power iteration for dominant eigenvalue
    # (full decomposition is complex without numpy)
    eigenvalues = []
    eigenvectors = []
    A_work = [list(row) for row in A]

    for _ in range(n):
        v = [random.gauss(0, 1) for _ in range(n)]
        vn = math.sqrt(sum(x * x for x in v))
        v = [x / vn for x in v]

        for _ in range(100):
            # Matrix-vector product
            Av = [sum(A_work[i][j] * v[j] for j in range(n)) for i in range(n)]
            eigenvalue = sum(a * b for a, b in zip(v, Av))
            vn = math.sqrt(sum(x * x for x in Av))
            if vn == 0:
                break
            v_new = [x / vn for x in Av]
            diff = sum((a - b) ** 2 for a, b in zip(v, v_new))
            v = v_new
            if diff < 1e-10:
                break

        eigenvalues.append(eigenvalue)
        eigenvectors.append(v)

        # Deflate
        for i in range(n):
            for j in range(n):
                A_work[i][j] -= eigenvalue * v[i] * v[j]

    return eigenvalues, _mat_transpose(eigenvectors)


def svd(A, full_matrices=True):
    """SVD via eigendecomposition of A^T A."""
    np = _try_numpy()
    if np is not None:
        U, s, Vt = np.linalg.svd(A, full_matrices=full_matrices)
        return U.tolist(), s.tolist(), Vt.tolist()

    # A^T A
    At = _mat_transpose(A)
    AtA = _mat_mult(At, A)
    eigenvalues, V = eigh(AtA)

    # Singular values
    s = [math.sqrt(max(0, ev)) for ev in eigenvalues]

    return None, s, V  # U computation omitted for pure-Python


def cholesky(A, lower=True):
    """Cholesky decomposition."""
    n = len(A)
    L = [[0.0] * n for _ in range(n)]
    for i in range(n):
        for j in range(i + 1):
            s = sum(L[i][k] * L[j][k] for k in range(j))
            if i == j:
                val = A[i][i] - s
                if val < 0:
                    raise ValueError("Matrix is not positive definite")
                L[i][j] = math.sqrt(val)
            else:
                if L[j][j] == 0:
                    L[i][j] = 0
                else:
                    L[i][j] = (A[i][j] - s) / L[j][j]
    if lower:
        return L
    return _mat_transpose(L)


def qr(A):
    """QR decomposition using Gram-Schmidt."""
    np = _try_numpy()
    if np is not None:
        Q, R = np.linalg.qr(A)
        return Q.tolist(), R.tolist()

    m = len(A)
    n = len(A[0])
    Q = [[0.0] * n for _ in range(m)]
    R = [[0.0] * n for _ in range(n)]

    for j in range(n):
        v = [A[i][j] for i in range(m)]
        for k in range(j):
            R[k][j] = sum(Q[i][k] * v[i] for i in range(m))
            for i in range(m):
                v[i] -= R[k][j] * Q[i][k]
        R[j][j] = math.sqrt(sum(x * x for x in v))
        if R[j][j] == 0:
            for i in range(m):
                Q[i][j] = 0
        else:
            for i in range(m):
                Q[i][j] = v[i] / R[j][j]

    return Q, R


class linalg:
    """Namespace matching scipy.linalg."""
    lu_factor = staticmethod(lu_factor)
    lu_solve = staticmethod(lu_solve)
    solve = staticmethod(solve)
    inv = staticmethod(inv)
    det = staticmethod(det)
    norm = staticmethod(norm)
    eigh = staticmethod(eigh)
    svd = staticmethod(svd)
    cholesky = staticmethod(cholesky)
    qr = staticmethod(qr)


# ============================================================================
# scipy_compat.signal
# ============================================================================

def convolve(a, b, mode="full"):
    """1D convolution."""
    na, nb = len(a), len(b)
    if mode == "full":
        out_len = na + nb - 1
    elif mode == "same":
        out_len = na
    elif mode == "valid":
        out_len = max(na, nb) - min(na, nb) + 1
    else:
        out_len = na + nb - 1

    result_full = [0.0] * (na + nb - 1)
    for i in range(na):
        for j in range(nb):
            result_full[i + j] += a[i] * b[j]

    if mode == "full":
        return result_full
    elif mode == "same":
        start = (nb - 1) // 2
        return result_full[start:start + na]
    elif mode == "valid":
        start = min(na, nb) - 1
        return result_full[start:start + out_len]
    return result_full


def correlate(a, b, mode="full"):
    """1D cross-correlation."""
    b_rev = list(reversed(b))
    return convolve(a, b_rev, mode=mode)


def medfilt(data, kernel_size=3):
    """1D median filter."""
    n = len(data)
    half = kernel_size // 2
    result = []
    for i in range(n):
        start = max(0, i - half)
        end = min(n, i + half + 1)
        window = sorted(data[start:end])
        result.append(window[len(window) // 2])
    return result


def butter(N, Wn, btype="low", fs=None, output="ba"):
    """Design a Butterworth filter (simplified)."""
    # Simplified: just return placeholder coefficients
    # Real Butterworth design requires complex pole placement
    if isinstance(Wn, (list, tuple)):
        Wn = Wn[0]  # Simplified

    # RC low-pass approximation
    alpha = Wn / (1 + Wn)
    b = [alpha ** N]
    a = [1.0]
    for i in range(1, N + 1):
        a.append((-1) ** i * (1 - alpha) ** i)

    return b, a


def lfilter(b, a, x):
    """Apply IIR/FIR filter."""
    n = len(x)
    nb, na = len(b), len(a)
    y = [0.0] * n

    for i in range(n):
        # FIR part
        for j in range(nb):
            if i - j >= 0:
                y[i] += b[j] * x[i - j]
        # IIR part
        for j in range(1, na):
            if i - j >= 0:
                y[i] -= a[j] * y[i - j]
        if a[0] != 0 and a[0] != 1:
            y[i] /= a[0]

    return y


def fftconvolve(a, b, mode="full"):
    """FFT-based convolution (falls back to direct convolution)."""
    # Without numpy/FFT, use direct convolution
    return convolve(a, b, mode=mode)


def find_peaks(x, height=None, distance=None, prominence=None):
    """Find peaks in signal."""
    peaks = []
    for i in range(1, len(x) - 1):
        if x[i] > x[i - 1] and x[i] > x[i + 1]:
            if height is not None and x[i] < height:
                continue
            peaks.append(i)

    if distance is not None and len(peaks) > 1:
        filtered = [peaks[0]]
        for p in peaks[1:]:
            if p - filtered[-1] >= distance:
                filtered.append(p)
        peaks = filtered

    properties = {"peak_heights": [x[i] for i in peaks]}
    return peaks, properties


def welch(x, fs=1.0, nperseg=256, noverlap=None):
    """Welch's PSD estimate (simplified - returns power spectral density)."""
    n = len(x)
    if noverlap is None:
        noverlap = nperseg // 2

    step = nperseg - noverlap
    segments = []
    for start in range(0, n - nperseg + 1, step):
        seg = x[start:start + nperseg]
        segments.append(seg)

    if not segments:
        return [0.0], [0.0]

    # Compute periodogram for each segment using DFT
    nfreq = nperseg // 2 + 1
    psd = [0.0] * nfreq

    for seg in segments:
        for k in range(nfreq):
            real = sum(seg[n_] * math.cos(2 * math.pi * k * n_ / nperseg) for n_ in range(nperseg))
            imag = sum(seg[n_] * math.sin(2 * math.pi * k * n_ / nperseg) for n_ in range(nperseg))
            psd[k] += (real ** 2 + imag ** 2) / nperseg

    psd = [p / len(segments) for p in psd]
    freqs = [k * fs / nperseg for k in range(nfreq)]
    return freqs, psd


class signal:
    """Namespace matching scipy.signal."""
    convolve = staticmethod(convolve)
    correlate = staticmethod(correlate)
    medfilt = staticmethod(medfilt)
    butter = staticmethod(butter)
    lfilter = staticmethod(lfilter)
    fftconvolve = staticmethod(fftconvolve)
    find_peaks = staticmethod(find_peaks)
    welch = staticmethod(welch)


# ============================================================================
# scipy_compat.special
# ============================================================================

def gamma_func(x):
    """Gamma function using Lanczos approximation."""
    if x <= 0 and x == int(x):
        return float('inf')
    if x < 0.5:
        return math.pi / (math.sin(math.pi * x) * gamma_func(1 - x))

    x -= 1
    g = 7
    p = [
        0.99999999999980993,
        676.5203681218851,
        -1259.1392167224028,
        771.32342877765313,
        -176.61502916214059,
        12.507343278686905,
        -0.13857109526572012,
        9.9843695780195716e-6,
        1.5056327351493116e-7,
    ]
    t = x + g + 0.5
    s = p[0]
    for i in range(1, g + 2):
        s += p[i] / (x + i)
    return math.sqrt(2 * math.pi) * t ** (x + 0.5) * math.exp(-t) * s


def gammaln(x):
    """Log of gamma function."""
    return math.lgamma(x)


def beta_func(a, b):
    """Beta function."""
    return math.exp(gammaln(a) + gammaln(b) - gammaln(a + b))


def digamma(x):
    """Digamma function (psi)."""
    result = 0.0
    while x < 6:
        result -= 1.0 / x
        x += 1

    result += math.log(x) - 0.5 / x
    x2 = 1.0 / (x * x)
    result -= x2 * (1.0 / 12 - x2 * (1.0 / 120 - x2 / 252))
    return result


def erf(x):
    """Error function."""
    return math.erf(x)


def erfc(x):
    """Complementary error function."""
    return math.erfc(x)


def expit(x):
    """Logistic sigmoid."""
    if x > 0:
        return 1.0 / (1.0 + math.exp(-x))
    ex = math.exp(x)
    return ex / (1.0 + ex)


def logit(p):
    """Logit function."""
    if p <= 0:
        return float('-inf')
    if p >= 1:
        return float('inf')
    return math.log(p / (1 - p))


def softmax(x):
    """Softmax function."""
    m = max(x)
    exps = [math.exp(v - m) for v in x]
    s = sum(exps)
    return [e / s for e in exps]


def log_softmax(x):
    """Log-softmax function."""
    m = max(x)
    lse = m + math.log(sum(math.exp(v - m) for v in x))
    return [v - lse for v in x]


def comb(n, k, exact=False):
    """Binomial coefficient."""
    return math.comb(n, k)


def factorial(n, exact=False):
    """Factorial."""
    return math.factorial(n)


class special:
    """Namespace matching scipy.special."""
    gamma = staticmethod(gamma_func)
    gammaln = staticmethod(gammaln)
    beta = staticmethod(beta_func)
    digamma = staticmethod(digamma)
    erf = staticmethod(erf)
    erfc = staticmethod(erfc)
    expit = staticmethod(expit)
    logit = staticmethod(logit)
    softmax = staticmethod(softmax)
    log_softmax = staticmethod(log_softmax)
    comb = staticmethod(comb)
    factorial = staticmethod(factorial)


# ============================================================================
# scipy_compat.interpolate
# ============================================================================

class interp1d:
    """1D interpolation."""

    def __init__(self, x, y, kind="linear", fill_value=None, bounds_error=True):
        self.x = list(x)
        self.y = list(y)
        self.kind = kind
        self.fill_value = fill_value
        self.bounds_error = bounds_error

        # Sort by x
        pairs = sorted(zip(self.x, self.y))
        self.x = [p[0] for p in pairs]
        self.y = [p[1] for p in pairs]

    def __call__(self, x_new):
        if isinstance(x_new, (int, float)):
            return self._interp_single(x_new)
        return [self._interp_single(xi) for xi in x_new]

    def _interp_single(self, xi):
        if xi <= self.x[0]:
            if self.bounds_error and xi < self.x[0]:
                raise ValueError(f"x={xi} is below interpolation range")
            if self.fill_value is not None:
                if isinstance(self.fill_value, tuple):
                    return self.fill_value[0]
                return self.fill_value
            return self.y[0]
        if xi >= self.x[-1]:
            if self.bounds_error and xi > self.x[-1]:
                raise ValueError(f"x={xi} is above interpolation range")
            if self.fill_value is not None:
                if isinstance(self.fill_value, tuple):
                    return self.fill_value[1]
                return self.fill_value
            return self.y[-1]

        # Binary search
        lo, hi = 0, len(self.x) - 1
        while lo < hi - 1:
            mid = (lo + hi) // 2
            if self.x[mid] <= xi:
                lo = mid
            else:
                hi = mid

        t = (xi - self.x[lo]) / (self.x[hi] - self.x[lo]) if self.x[hi] != self.x[lo] else 0

        if self.kind == "nearest":
            return self.y[lo] if t < 0.5 else self.y[hi]
        elif self.kind == "zero" or self.kind == "previous":
            return self.y[lo]
        elif self.kind == "next":
            return self.y[hi]
        elif self.kind == "cubic":
            return self._cubic_interp(lo, hi, t)
        else:
            # Linear
            return self.y[lo] + t * (self.y[hi] - self.y[lo])

    def _cubic_interp(self, lo, hi, t):
        """Cubic Hermite interpolation."""
        # Get 4 points
        i0 = max(0, lo - 1)
        i1 = lo
        i2 = hi
        i3 = min(len(self.y) - 1, hi + 1)

        y0, y1, y2, y3 = self.y[i0], self.y[i1], self.y[i2], self.y[i3]

        a = -0.5 * y0 + 1.5 * y1 - 1.5 * y2 + 0.5 * y3
        b = y0 - 2.5 * y1 + 2 * y2 - 0.5 * y3
        c = -0.5 * y0 + 0.5 * y2
        d = y1

        return a * t ** 3 + b * t ** 2 + c * t + d


class interpolate:
    """Namespace matching scipy.interpolate."""
    interp1d = interp1d


# ============================================================================
# scipy_compat.integrate
# ============================================================================

def quad(func, a, b, args=(), limit=50):
    """Numerical integration using adaptive Simpson's rule."""
    def f(x):
        return func(x, *args)

    result = _adaptive_simpson(f, a, b, tol=1.49e-8, max_depth=limit)
    return result, 0.0  # (result, error_estimate)


def _adaptive_simpson(f, a, b, tol=1e-8, max_depth=50):
    """Adaptive Simpson's rule."""
    c = (a + b) / 2
    h = b - a
    fa, fb, fc = f(a), f(b), f(c)
    whole = (h / 6) * (fa + 4 * fc + fb)
    return _adaptive_simpson_rec(f, a, b, fa, fb, fc, whole, tol, max_depth)


def _adaptive_simpson_rec(f, a, b, fa, fb, fc, whole, tol, depth):
    c = (a + b) / 2
    d = (a + c) / 2
    e = (c + b) / 2
    fd, fe = f(d), f(e)
    h = b - a

    left = (h / 12) * (fa + 4 * fd + fc)
    right = (h / 12) * (fc + 4 * fe + fb)
    total = left + right

    if depth <= 0 or abs(total - whole) <= 15 * tol:
        return total + (total - whole) / 15

    return (_adaptive_simpson_rec(f, a, c, fa, fc, fd, left, tol / 2, depth - 1) +
            _adaptive_simpson_rec(f, c, b, fc, fb, fe, right, tol / 2, depth - 1))


def trapezoid(y, x=None, dx=1.0):
    """Trapezoidal integration."""
    n = len(y)
    if x is not None:
        return sum((x[i + 1] - x[i]) * (y[i] + y[i + 1]) / 2 for i in range(n - 1))
    return sum(dx * (y[i] + y[i + 1]) / 2 for i in range(n - 1))


def simpson(y, x=None, dx=1.0):
    """Simpson's rule integration."""
    n = len(y)
    if n < 3:
        return trapezoid(y, x, dx)

    if x is not None:
        # Non-uniform spacing
        result = 0.0
        for i in range(0, n - 2, 2):
            h1 = x[i + 1] - x[i]
            h2 = x[i + 2] - x[i + 1]
            result += (h1 + h2) / 6 * (y[i] * (2 - h2 / h1) + y[i + 1] * (h1 + h2) ** 2 / (h1 * h2) + y[i + 2] * (2 - h1 / h2))
        if n % 2 == 0:
            result += trapezoid(y[-2:], x[-2:] if x else None, dx)
        return result
    else:
        result = y[0] + y[-1]
        for i in range(1, n - 1):
            if i % 2 == 0:
                result += 2 * y[i]
            else:
                result += 4 * y[i]
        return result * dx / 3


class integrate:
    """Namespace matching scipy.integrate."""
    quad = staticmethod(quad)
    trapezoid = staticmethod(trapezoid)
    simpson = staticmethod(simpson)


# ============================================================================
# Top-level convenience: import scipy_compat as scipy
# ============================================================================
# All submodules are accessible as attributes: scipy_compat.sparse, etc.
