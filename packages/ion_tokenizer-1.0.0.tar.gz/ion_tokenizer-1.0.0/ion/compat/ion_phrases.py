"""
Pure-Python replacement for gensim.models.phrases.

Implements PMI-based phrase detection compatible with gensim's Phrases API.
No external dependencies beyond the Python standard library.
"""

import math
from collections import Counter, defaultdict
from typing import Optional, Iterator


# Matches gensim.models.phrases.ENGLISH_CONNECTOR_WORDS exactly
ENGLISH_CONNECTOR_WORDS = frozenset({
    "a", "an", "and", "at", "by", "for", "from", "in",
    "of", "on", "or", "the", "to", "with", "without",
})


class FrozenPhrases:
    """
    Frozen (read-only) phrase model for efficient transformation.
    Equivalent to gensim's FrozenPhrases / Phraser.
    """

    def __init__(self, phrasegrams: dict, threshold: float, connector_words: frozenset,
                 scoring: str, min_count: int, delimiter: str = "_"):
        self.phrasegrams = phrasegrams  # {(w1, w2): (count, score)}
        self.threshold = threshold
        self.connector_words = connector_words
        self.scoring = scoring
        self.min_count = min_count
        self.delimiter = delimiter

    def __getitem__(self, sentence: list[str]) -> list[str]:
        """Transform a sentence by joining detected phrases."""
        return self._apply(sentence)

    def _apply(self, sentence: list[str]) -> list[str]:
        if len(sentence) < 2:
            return list(sentence)

        result = []
        i = 0
        while i < len(sentence):
            if i < len(sentence) - 1:
                # Try to form a phrase starting at position i
                phrase_end = self._find_phrase_end(sentence, i)
                if phrase_end > i + 1:
                    # Found a phrase
                    phrase_tokens = sentence[i:phrase_end]
                    result.append(self.delimiter.join(phrase_tokens))
                    i = phrase_end
                    continue
            result.append(sentence[i])
            i += 1

        return result

    def _find_phrase_end(self, sentence: list[str], start: int) -> int:
        """Find the end of a phrase starting at `start`. Returns start+1 if no phrase."""
        best_end = start + 1

        # Check bigram
        if start + 1 < len(sentence):
            w1, w2 = sentence[start], sentence[start + 1]

            # Handle connector words: look through connectors
            # Connector words can appear between phrase components
            j = start + 1
            connectors_seen = []

            while j < len(sentence) and sentence[j] in self.connector_words:
                connectors_seen.append(sentence[j])
                j += 1

            if connectors_seen and j < len(sentence):
                # w1 + connectors + w_next
                w_next = sentence[j]
                key = (w1, w_next)
                if key in self.phrasegrams:
                    count, score = self.phrasegrams[key]
                    if score >= self.threshold and count >= self.min_count:
                        best_end = j + 1
                        return best_end

            # Direct bigram (no connectors)
            key = (w1, w2)
            if key in self.phrasegrams:
                count, score = self.phrasegrams[key]
                if score >= self.threshold and count >= self.min_count:
                    best_end = start + 2

        return best_end


class Phrases:
    """
    Pure-Python replacement for gensim.models.phrases.Phrases.

    Detects collocations (multi-word phrases) using PMI scoring.
    Compatible with gensim's API: Phrases(sentences, ...).freeze()[sentence].
    """

    def __init__(
        self,
        sentences: Optional[list[list[str]]] = None,
        min_count: int = 5,
        threshold: float = 10.0,
        max_vocab_size: int = 40_000_000,
        delimiter: str = "_",
        scoring: str = "default",
        connector_words: frozenset = frozenset(),
    ):
        self.min_count = min_count
        self.threshold = threshold
        self.max_vocab_size = max_vocab_size
        self.delimiter = delimiter
        self.scoring = scoring
        self.connector_words = connector_words

        # Internal state
        self.vocab: Counter = Counter()  # unigram counts
        self.bigram_counts: Counter = Counter()  # bigram counts
        self.phrasegrams: dict = {}  # {(w1, w2): (count, score)}
        self._total_words = 0

        if sentences is not None:
            self.add_vocab(sentences)

    def add_vocab(self, sentences):
        """Learn vocabulary and bigram statistics from sentences."""
        for sentence in sentences:
            if not sentence:
                continue
            # Count unigrams
            for word in sentence:
                self.vocab[word] += 1
                self._total_words += 1

            # Count bigrams (skipping connector words in between)
            clean = [w for w in sentence if w not in self.connector_words]
            for i in range(len(clean) - 1):
                bigram = (clean[i], clean[i + 1])
                self.bigram_counts[bigram] += 1

        # Prune vocabulary if too large
        if len(self.vocab) > self.max_vocab_size:
            self.vocab = Counter(dict(self.vocab.most_common(self.max_vocab_size)))

        # Score all bigrams
        self._score_bigrams()

    def _score_bigrams(self):
        """Compute PMI or NPMI scores for all bigrams."""
        self.phrasegrams = {}

        for (w1, w2), count in self.bigram_counts.items():
            if count < self.min_count:
                continue

            freq_w1 = self.vocab.get(w1, 0)
            freq_w2 = self.vocab.get(w2, 0)

            if freq_w1 == 0 or freq_w2 == 0:
                continue

            if self.scoring == "npmi":
                score = self._npmi(count, freq_w1, freq_w2)
            else:
                score = self._pmi_score(count, freq_w1, freq_w2)

            if score >= self.threshold:
                self.phrasegrams[(w1, w2)] = (count, score)

    def _pmi_score(self, bigram_count: int, freq_w1: int, freq_w2: int) -> float:
        """
        Default gensim-style scoring:
        score = (bigram_count - min_count) * N / (freq_w1 * freq_w2)

        where N is total word count.
        """
        if freq_w1 == 0 or freq_w2 == 0:
            return 0.0
        return (bigram_count - self.min_count) * self._total_words / (freq_w1 * freq_w2)

    def _npmi(self, bigram_count: int, freq_w1: int, freq_w2: int) -> float:
        """
        Normalized Pointwise Mutual Information.
        NPMI = PMI / (-log(P(bigram)))
        Range: -1 to 1 (1 = perfect association)
        """
        if self._total_words == 0 or bigram_count == 0:
            return -1.0

        p_w1 = freq_w1 / self._total_words
        p_w2 = freq_w2 / self._total_words
        p_bigram = bigram_count / self._total_words

        if p_w1 == 0 or p_w2 == 0 or p_bigram == 0:
            return -1.0

        pmi = math.log(p_bigram / (p_w1 * p_w2))
        neg_log_p = -math.log(p_bigram)

        if neg_log_p == 0:
            return 0.0

        return pmi / neg_log_p

    def freeze(self) -> FrozenPhrases:
        """Return a frozen (read-only) version for efficient transformation."""
        return FrozenPhrases(
            phrasegrams=dict(self.phrasegrams),
            threshold=self.threshold,
            connector_words=self.connector_words,
            scoring=self.scoring,
            min_count=self.min_count,
            delimiter=self.delimiter,
        )

    def __getitem__(self, sentence: list[str]) -> list[str]:
        """Transform a single sentence (for convenience)."""
        frozen = self.freeze()
        return frozen[sentence]

    def export_phrases(self) -> dict:
        """Export all detected phrases with scores."""
        result = {}
        for (w1, w2), (count, score) in self.phrasegrams.items():
            phrase = f"{w1}{self.delimiter}{w2}"
            result[phrase] = {"count": count, "score": score}
        return result
