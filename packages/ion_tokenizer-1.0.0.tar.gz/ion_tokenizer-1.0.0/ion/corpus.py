"""Corpus loading from Hugging Face datasets, local files, and directories."""

import os
import re
from pathlib import Path
from typing import Iterator, Optional, Tuple
from urllib.parse import urlparse

import spacy

from .utils import EMPHASIS_WORDS, collapse_punctuation as collapse_punct_fn


# Regex to detect lines that are primarily JSON content
_JSON_LINE_RE = re.compile(r'^\s*[\[{].*[\]}]\s*$')


# Mapping from lingua language codes to spaCy language codes
LINGUA_TO_SPACY = {
    "ENGLISH": "en", "GERMAN": "de", "FRENCH": "fr", "SPANISH": "es",
    "ITALIAN": "it", "PORTUGUESE": "pt", "DUTCH": "nl", "RUSSIAN": "ru",
    "CHINESE": "zh", "JAPANESE": "ja", "KOREAN": "ko", "ARABIC": "ar",
    "HINDI": "hi", "POLISH": "pl", "TURKISH": "tr", "SWEDISH": "sv",
    "DANISH": "da", "NORWEGIAN": "nb", "FINNISH": "fi", "GREEK": "el",
    "CZECH": "cs", "ROMANIAN": "ro", "HUNGARIAN": "hu", "UKRAINIAN": "uk",
    "CATALAN": "ca", "CROATIAN": "hr", "SERBIAN": "sr", "BULGARIAN": "bg",
    "SLOVAK": "sk", "SLOVENIAN": "sl", "LITHUANIAN": "lt", "LATVIAN": "lv",
    "ESTONIAN": "et", "HEBREW": "he", "THAI": "th", "VIETNAMESE": "vi",
    "INDONESIAN": "id", "MALAY": "ms", "TAGALOG": "tl", "AFRIKAANS": "af",
}


def detect_language(text_samples: list[str], max_chars: int = 50000) -> str:
    """Detect the language of text samples using lingua.

    Args:
        text_samples: List of text strings to analyze.
        max_chars: Maximum characters to analyze for detection.

    Returns:
        spaCy language code (e.g., "en", "de", "fr").
    """
    try:
        from lingua import LanguageDetectorBuilder
    except ImportError:
        return "en"

    # Combine samples up to max_chars
    combined = ""
    for sample in text_samples:
        combined += sample + "\n"
        if len(combined) >= max_chars:
            break

    if not combined.strip():
        return "en"

    detector = LanguageDetectorBuilder.from_all_languages().build()
    result = detector.detect_language_of(combined[:max_chars])

    if result is None:
        return "en"

    lang_name = result.name
    return LINGUA_TO_SPACY.get(lang_name, "en")


def detect_if_code(text_samples: list[str], threshold: float = 0.4) -> bool:
    """Detect if text samples are primarily source code.

    Uses heuristic markers: braces, semicolons, imports, def/function keywords,
    indentation patterns, etc.

    Args:
        text_samples: List of text strings to analyze.
        threshold: Fraction of lines that must look like code.

    Returns:
        True if the text appears to be source code.
    """
    code_markers = re.compile(
        r'(^\s*(def |class |import |from .+ import |function |const |let |var |'
        r'if\s*\(|for\s*\(|while\s*\(|return |#include|package |public |private )'
        r'|[{};]\s*$'
        r'|^\s*//|^\s*#!|^\s*/\*'
        r'|=>|->|\|\||&&'
        r'|\bself\.|\.join\(|\.split\(|\.append\(|\.map\(|\.filter\()',
        re.MULTILINE
    )

    total_lines = 0
    code_lines = 0
    for sample in text_samples[:200]:
        for line in sample.split("\n"):
            line = line.strip()
            if not line:
                continue
            total_lines += 1
            if code_markers.search(line):
                code_lines += 1

    if total_lines == 0:
        return False
    return (code_lines / total_lines) >= threshold


def parse_huggingface_url(source: str) -> Tuple[bool, str, Optional[str]]:
    """
    Parse a HuggingFace dataset reference.

    Supports:
    - Full URLs: https://huggingface.co/datasets/wikitext
    - Full URLs with org: https://huggingface.co/datasets/allenai/c4
    - Simple identifiers: wikitext, allenai/c4
    - Legacy hf:// prefix: hf://wikitext (deprecated)

    Returns:
        (is_hf, dataset_id, config)
        Config is only extracted from URL if there's a 3rd path component.
    """
    # Full HuggingFace URL
    if source.startswith("https://huggingface.co/datasets/"):
        path = source.replace("https://huggingface.co/datasets/", "")
        parts = [p for p in path.strip("/").split("/") if p]

        if len(parts) == 1:
            # Simple dataset: wikitext
            return True, parts[0], None
        elif len(parts) == 2:
            # Org/dataset: allenai/c4, Alibaba-Apsara/Superior-Reasoning-SFT-gpt-oss-120b
            return True, f"{parts[0]}/{parts[1]}", None
        elif len(parts) >= 3:
            # Org/dataset/config or more
            return True, f"{parts[0]}/{parts[1]}", parts[2]
        else:
            return True, path.strip("/"), None

    # Legacy hf:// or hf:/ prefix (deprecated but supported)
    if source.startswith("hf://"):
        return True, source[5:], None
    if source.startswith("hf:/"):
        return True, source[4:], None
    if source.startswith("hf:"):
        return True, source[3:], None

    return False, source, None


def load_spacy_tokenizer(language: str = "en"):
    """Load spaCy tokenizer for sentence/word splitting.

    Supports any language that spaCy has a blank model for.
    Common codes: en, de, fr, es, it, pt, nl, ja, zh, ko, ru, ar, hi, pl, etc.
    """
    try:
        nlp = spacy.blank(language)
    except Exception:
        # Fall back to multi-language if specific language not available
        try:
            nlp = spacy.blank("xx")  # Multi-language blank model
        except Exception:
            nlp = spacy.blank("en")
    nlp.add_pipe("sentencizer")
    nlp.max_length = 50_000_000  # 50MB max for large corpora
    return nlp


def normalize_text(
    text: str,
    collapse_punctuation: bool = False,
    preserve_case: bool = False,
) -> str:
    """Normalize text: optionally lowercase, collapse whitespace, strip."""
    if not preserve_case:
        text = text.lower()
    if collapse_punctuation:
        text = collapse_punct_fn(text)
    text = re.sub(r'\s+', ' ', text)
    text = text.strip()
    return text


def filter_emphasis_words(tokens: list[str]) -> list[str]:
    """Remove emphasis/intensifier words from token list."""
    return [t for t in tokens if t not in EMPHASIS_WORDS]


def _is_json_line(line: str) -> bool:
    """Check if a line looks like JSON content."""
    stripped = line.strip()
    if not stripped:
        return False
    # Quick check: starts with { or [ and ends with } or ]
    if _JSON_LINE_RE.match(stripped):
        return True
    # Also detect lines with high density of JSON-like characters
    json_chars = sum(1 for c in stripped if c in '{}[]:,"')
    if len(stripped) > 10 and json_chars / len(stripped) > 0.3:
        return True
    return False


def iter_sentences_from_text(
    text: str,
    nlp,
    remove_emphasis: bool = False,
    collapse_punctuation: bool = False,
    preserve_case: bool = False,
    keep_json: bool = False,
) -> Iterator[list[str]]:
    """Yield tokenized sentences from text.

    Args:
        keep_json: If True, keep JSON-structured content in the corpus.
                   If False (default), skip lines that look like JSON.
    """
    # Filter out JSON lines unless keep_json is set
    if not keep_json:
        lines = text.split('\n')
        lines = [l for l in lines if not _is_json_line(l)]
        text = '\n'.join(lines)

    text = normalize_text(text, collapse_punctuation=collapse_punctuation, preserve_case=preserve_case)
    if not text:
        return
    doc = nlp(text)
    for sent in doc.sents:
        tokens = [token.text for token in sent if not token.is_space]
        if remove_emphasis:
            tokens = filter_emphasis_words(tokens)
        if tokens:
            yield tokens


def load_local_file(
    path: str,
    nlp,
    remove_emphasis: bool = False,
    collapse_punctuation: bool = False,
    preserve_case: bool = False,
    keep_json: bool = False,
) -> Iterator[list[str]]:
    """Load sentences from a local text file."""
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        text = f.read()
    yield from iter_sentences_from_text(
        text, nlp, remove_emphasis, collapse_punctuation, preserve_case, keep_json=keep_json
    )


def load_local_directory(
    path: str,
    nlp,
    remove_emphasis: bool = False,
    collapse_punctuation: bool = False,
    preserve_case: bool = False,
    keep_json: bool = False,
) -> Iterator[list[str]]:
    """Load sentences from all text files in a directory."""
    p = Path(path)
    for fpath in sorted(p.rglob("*.txt")):
        yield from load_local_file(
            str(fpath), nlp, remove_emphasis, collapse_punctuation, preserve_case,
            keep_json=keep_json,
        )


def _resolve_hf_token(token: Optional[str] = None) -> Optional[str]:
    """Resolve HuggingFace token from argument, env var, or HF CLI login."""
    if token:
        return token
    return os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")


def load_huggingface_dataset(
    identifier: str,
    split: str = "train",
    text_field: str = "text",
    streaming: bool = True,
    max_samples: Optional[int] = None,
    nlp=None,
    config: Optional[str] = None,
    remove_emphasis: bool = False,
    collapse_punctuation: bool = False,
    preserve_case: bool = False,
    token: Optional[str] = None,
    keep_json: bool = False,
) -> Iterator[list[str]]:
    """Load sentences from a Hugging Face dataset."""
    from datasets import load_dataset

    hf_token = _resolve_hf_token(token)

    try:
        if config:
            ds = load_dataset(identifier, config, split=split, streaming=streaming, token=hf_token)
        else:
            ds = load_dataset(identifier, split=split, streaming=streaming, token=hf_token)
    except Exception:
        if config:
            ds = load_dataset(identifier, config, split=split, streaming=False, token=hf_token)
        else:
            ds = load_dataset(identifier, split=split, streaming=False, token=hf_token)

    count = 0
    for example in ds:
        text = example.get(text_field, "")
        if not text:
            continue
        yield from iter_sentences_from_text(
            text, nlp, remove_emphasis, collapse_punctuation, preserve_case,
            keep_json=keep_json,
        )
        count += 1
        if max_samples and count >= max_samples:
            break


def load_corpus(
    source: str,
    hf_split: str = "train",
    hf_text_field: str = "text",
    hf_streaming: bool = True,
    max_samples: Optional[int] = None,
    hf_config: Optional[str] = None,
    remove_emphasis: bool = False,
    collapse_punctuation: bool = False,
    language: str = "en",
    preserve_case: bool = False,
    token: Optional[str] = None,
    keep_json: bool = False,
) -> Iterator[list[str]]:
    """
    Load corpus from various sources.

    Supports:
    - HuggingFace URLs: https://huggingface.co/datasets/wikitext
    - HuggingFace dataset identifiers (e.g., "wikitext", "openwebtext")
    - Local file paths
    - Local directory paths

    Args:
        language: spaCy language code (en, de, fr, es, zh, ja, ko, ru, ar, etc.)
        preserve_case: If True, don't lowercase text during normalization
        keep_json: If True, keep JSON-structured content in the corpus
    """
    nlp = load_spacy_tokenizer(language=language)

    # Check if it's a HuggingFace URL or identifier
    is_hf, dataset_id, url_config = parse_huggingface_url(source)

    if not is_hf and os.path.isfile(source):
        yield from load_local_file(
            source, nlp, remove_emphasis, collapse_punctuation, preserve_case,
            keep_json=keep_json,
        )
    elif not is_hf and os.path.isdir(source):
        yield from load_local_directory(
            source, nlp, remove_emphasis, collapse_punctuation, preserve_case,
            keep_json=keep_json,
        )
    else:
        # Use config from URL if not explicitly provided
        config = hf_config or url_config
        yield from load_huggingface_dataset(
            dataset_id,
            split=hf_split,
            text_field=hf_text_field,
            streaming=hf_streaming,
            max_samples=max_samples,
            nlp=nlp,
            config=config,
            remove_emphasis=remove_emphasis,
            collapse_punctuation=collapse_punctuation,
            preserve_case=preserve_case,
            token=token,
            keep_json=keep_json,
        )
