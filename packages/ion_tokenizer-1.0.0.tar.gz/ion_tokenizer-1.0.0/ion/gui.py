"""Interactive GUI for ion CLI with single-view architecture."""

import shlex
import sys
import time

# Loading animation - show immediately before heavy imports
LOAD_FRAMES = [
    "     *     ",
    "    ***    ",
    "   *****   ",
    "  *******  ",
    "   *****   ",
    "    ***    ",
    "   *.*.    ",
    "  *. .*    ",
    "   . .     ",
]

def show_loading():
    """Show quick loading animation."""
    sys.stdout.write("\033[?25l\033[H\033[J")  # Hide cursor, clear
    sys.stdout.flush()

    for i, frame in enumerate(LOAD_FRAMES):
        sys.stdout.write(f"\033[H\n\n\033[36m{frame:^40}\033[0m\n")
        sys.stdout.write(f"\033[96m{'ION':^40}\033[0m")
        sys.stdout.flush()
        time.sleep(0.03)

    sys.stdout.write("\033[?25h")

show_loading()

# Now do heavy imports
import os
import random
from typing import Optional, List, Tuple, Dict, Any
from pathlib import Path

from .benchmarks import (
    load_benchmarks, format_benchmark_summary, format_quick_stats,
    get_ascii_chart, BASELINE_BENCHMARKS,
)

# ANSI codes
class Colors:
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    HIDE_CURSOR = "\033[?25l"
    SHOW_CURSOR = "\033[?25h"
    CLEAR_LINE = "\033[2K"
    CLEAR_SCREEN = "\033[2J"
    HOME = "\033[H"
    ALT_SCREEN_ON = "\033[?1049h"
    ALT_SCREEN_OFF = "\033[?1049l"

    BLACK = "\033[30m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"
    BRIGHT_BLACK = "\033[90m"
    BRIGHT_CYAN = "\033[96m"
    BRIGHT_GREEN = "\033[92m"
    BRIGHT_WHITE = "\033[97m"


# Spinning cube frames
SPIN_FRAMES = [
    ["  ╔═══╗  ", "  ║ I ║  ", "  ╚═══╝  "],
    [" ╔════╗ ", " ║ IO ║ ", " ╚════╝ "],
    ["╔═════╗", "║ ION ║", "╚═════╝"],
    [" ╔════╗ ", " ║ ON ║ ", " ╚════╝ "],
    ["  ╔═══╗  ", "  ║ N ║  ", "  ╚═══╝  "],
    [" ╔════╗ ", " ║ ON ║ ", " ╚════╝ "],
    ["╔═════╗", "║ ION ║", "╚═════╝"],
    [" ╔════╗ ", " ║ IO ║ ", " ╚════╝ "],
]

GOODBYES = [
    "Happy tokenizing!",
    "May your sequences be short!",
    "Compress wisely!",
    "Fewer tokens, more meaning!",
    "Until next time!",
]

# Commands
COMMANDS = {
    "benchmarks": {"desc": "See Ion's value instantly", "cat": "start", "icon": "📊"},
    "tokenize": {"desc": "Build tokenizer from corpus", "cat": "build", "icon": "🔨"},
    "demo": {"desc": "Interactive tokenization", "cat": "start", "icon": "🎮"},
    "sweep": {"desc": "Find optimal vocab size", "cat": "analyze", "icon": "📈"},
    "phrases": {"desc": "Analyze phrase value", "cat": "analyze", "icon": "💎"},
    "parity": {"desc": "Compare Ion vs BPE", "cat": "analyze", "icon": "⚖️"},
    "export": {"desc": "Export for training", "cat": "export", "icon": "📦"},
    "stats": {"desc": "Show tokenizer stats", "cat": "analyze", "icon": "📋"},
    "domains": {"desc": "View domain presets", "cat": "build", "icon": "🌐"},
    "preview": {"desc": "Live token preview", "cat": "start", "icon": "👁️"},
    "help": {"desc": "Show help", "cat": "config", "icon": "❓"},
    "quit": {"desc": "Exit ion", "cat": "config", "icon": "👋"},
}

CATEGORIES = {
    "start": "Getting Started",
    "build": "Build & Create",
    "analyze": "Analyze & Compare",
    "export": "Export",
    "config": "Config",
}


def clear():
    """Clear screen and go home."""
    # Move to top-left and clear everything below
    sys.stdout.write(f"\033[H\033[J")
    sys.stdout.flush()


def get_key():
    """Get a single keypress."""
    import termios
    import tty
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        ch = sys.stdin.read(1)
        if ch == '\x1b':
            ch2 = sys.stdin.read(1)
            if ch2 == '[':
                ch3 = sys.stdin.read(1)
                return {'A': 'UP', 'B': 'DOWN', 'C': 'RIGHT', 'D': 'LEFT'}.get(ch3, '')
            return 'ESC'
        elif ch == '\r' or ch == '\n':
            return 'ENTER'
        elif ch == '\x7f' or ch == '\x08':
            return 'BACKSPACE'
        elif ch == '\x03':
            return 'QUIT'
        return ch
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


def dropdown(title: str, options: List[str], default: int = 0) -> int:
    """Show dropdown selector. Returns index of selected option."""
    selected = default
    first_draw = True

    while True:
        # Draw options
        print(f"\r{Colors.CLEAR_LINE}", end="")
        print(f"  {Colors.YELLOW}{title}:{Colors.RESET}", end="")

        for i, opt in enumerate(options):
            if i == selected:
                print(f" {Colors.BRIGHT_CYAN}[{opt}]{Colors.RESET}", end="")
            else:
                print(f" {Colors.DIM}{opt}{Colors.RESET}", end="")

        if first_draw:
            print(f"  {Colors.DIM}(← → to switch, Enter to confirm){Colors.RESET}", end="", flush=True)
            first_draw = False
        else:
            print(f"  {Colors.DIM}← →{Colors.RESET}", end="", flush=True)

        key = get_key()
        if key == 'LEFT':
            selected = (selected - 1) % len(options)
        elif key == 'RIGHT':
            selected = (selected + 1) % len(options)
        elif key == 'ENTER':
            print()
            return selected
        elif key == 'ESC' or key == 'QUIT':
            print()
            return -1


def text_input(prompt: str, default: str = "") -> str:
    """Get text input from user."""
    print(f"  {Colors.CYAN}{prompt}:{Colors.RESET} ", end="", flush=True)
    try:
        # Use regular input for text entry
        import termios
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old)

        result = input()
        return result.strip() if result.strip() else default
    except Exception:
        return default


def render_header():
    """Render the spinning cube header."""
    frame_idx = int(time.time() * 3) % len(SPIN_FRAMES)
    frame = SPIN_FRAMES[frame_idx]

    print()
    for line in frame:
        print(f"  {Colors.CYAN}{line}{Colors.RESET}")
    print(f"\n  {Colors.BOLD}{Colors.WHITE}ION{Colors.RESET} {Colors.DIM}Phrase-First Tokenizer{Colors.RESET}")
    print(f"  {Colors.DIM}{format_quick_stats()}{Colors.RESET}")
    print()


def render_search_bar(query: str):
    """Render the search bar at bottom."""
    print(f"  ╭{'─' * 56}╮")
    q = query[:50]
    pad = 53 - len(q)
    print(f"  │ {Colors.CYAN}/{Colors.RESET}{Colors.WHITE}{q}{Colors.RESET}{'_'}{' ' * pad}│")
    print(f"  ╰{'─' * 56}╯")


def show_main_menu() -> Optional[str]:
    """Show main menu - single view, commands appear after typing."""
    query = ""
    selected = 0

    while True:
        clear()
        render_header()

        # Filter commands based on query
        if query:
            filtered = [(k, v) for k, v in COMMANDS.items()
                       if query.lower() in k.lower() or query.lower() in v["desc"].lower()]
        else:
            filtered = []

        # Commands area
        if filtered:
            if selected >= len(filtered):
                selected = len(filtered) - 1

            current_cat = None
            idx = 0
            for name, info in filtered:
                if info["cat"] != current_cat:
                    current_cat = info["cat"]
                    print(f"  {Colors.DIM}── {CATEGORIES.get(current_cat, '')} ──{Colors.RESET}")

                if idx == selected:
                    print(f"  {Colors.BRIGHT_CYAN}▸{Colors.RESET} {Colors.BOLD}{info['icon']} /{name:<12}{Colors.RESET} {Colors.WHITE}{info['desc']}{Colors.RESET}")
                else:
                    print(f"    {Colors.DIM}{info['icon']}{Colors.RESET} {Colors.CYAN}/{name:<12}{Colors.RESET} {Colors.DIM}{info['desc']}{Colors.RESET}")
                idx += 1
            print()
        else:
            # Welcome - no commands yet
            print(f"  {Colors.DIM}Type to search commands...{Colors.RESET}")
            print()
            print(f"  {Colors.BRIGHT_BLACK}Quick launch:{Colors.RESET}")
            print(f"    {Colors.CYAN}1{Colors.RESET} benchmarks   {Colors.CYAN}2{Colors.RESET} tokenize   {Colors.CYAN}3{Colors.RESET} demo")
            print(f"    {Colors.CYAN}4{Colors.RESET} preview      {Colors.CYAN}0{Colors.RESET} quit")
            print()

        render_search_bar(query)
        print(f"  {Colors.DIM}Type to search │ ↑↓ navigate │ Enter select │ Esc quit{Colors.RESET}")

        key = get_key()

        if key == 'UP':
            selected = max(0, selected - 1)
        elif key == 'DOWN':
            if filtered:
                selected = min(len(filtered) - 1, selected + 1)
        elif key == 'ENTER':
            if filtered:
                return list(filtered)[selected][0]
        elif key == 'BACKSPACE':
            query = query[:-1]
            selected = 0
        elif key == 'ESC' or key == 'QUIT':
            return "quit"
        elif key == '1' and not query:
            return "benchmarks"
        elif key == '2' and not query:
            return "tokenize"
        elif key == '3' and not query:
            return "demo"
        elif key == '4' and not query:
            return "preview"
        elif key == '0' and not query:
            return "quit"
        elif isinstance(key, str) and len(key) == 1 and key.isprintable():
            query += key
            selected = 0


def run_benchmarks():
    """Show benchmarks screen."""
    clear()
    print(f"\n  {Colors.BOLD}{Colors.CYAN}BENCHMARKS{Colors.RESET}")
    print(f"  {'─' * 50}")
    print()

    benchmarks = load_benchmarks()

    print(f"  {Colors.BRIGHT_GREEN}{format_quick_stats()}{Colors.RESET}")
    print()

    # Vocab sweep
    print(f"  {Colors.BOLD}Vocab Size vs Compression{Colors.RESET}")
    if "vocab_sweep" in benchmarks:
        results = benchmarks["vocab_sweep"].get("results", [])
        max_red = max(r.get("reduction_pct", 0) for r in results) if results else 1
        for r in results:
            bar_len = int((r.get("reduction_pct", 0) / max(max_red, 1)) * 25)
            bar = f"{Colors.GREEN}{'█' * bar_len}{Colors.RESET}"
            print(f"    {r['vocab_size']:>7,} {bar} {r['reduction_pct']:>5.1f}%")
    print()

    # Ion vs BPE
    print(f"  {Colors.BOLD}Ion vs BPE Advantage{Colors.RESET}")
    if "ion_vs_bpe" in benchmarks:
        for c in benchmarks["ion_vs_bpe"].get("comparisons", [])[:4]:
            adv = c.get("ion_advantage_pct", 0)
            print(f"    {c['vocab_size']:>7,} vocab: {Colors.GREEN}+{adv:.1f}%{Colors.RESET} fewer tokens")

    print()
    print(f"  {Colors.YELLOW}NEXT:{Colors.RESET} Try /tokenize to build your own")
    print()
    print(f"  {Colors.DIM}Press any key to continue...{Colors.RESET}")
    get_key()


def run_tokenize():
    """Interactive tokenizer builder with dropdowns."""
    clear()
    print(f"\n  {Colors.BOLD}{Colors.CYAN}BUILD TOKENIZER{Colors.RESET}")
    print(f"  {'─' * 50}")
    print()

    # Step 1: Source type dropdown
    source_types = ["Text file", "HuggingFace", "Parquet", "JSONL", "Directory"]
    print(f"  {Colors.BOLD}Step 1:{Colors.RESET} Choose corpus source")
    idx = dropdown("Source", source_types)
    if idx < 0:
        return

    source_type = source_types[idx]
    source = ""

    if source_type == "HuggingFace":
        print()
        print(f"  {Colors.DIM}Examples: https://huggingface.co/datasets/wikitext{Colors.RESET}")
        print(f"  {Colors.DIM}Or just: wikitext, allenai/c4{Colors.RESET}")
        dataset = text_input("Dataset URL or name", "https://huggingface.co/datasets/wikitext")
        if not dataset:
            return
        source = dataset  # URL or identifier passed directly
    elif source_type == "Text file":
        print()
        print(f"  {Colors.DIM}Supports .txt files{Colors.RESET}")
        source = text_input("File path", "corpus.txt")
    elif source_type == "Parquet":
        print()
        print(f"  {Colors.DIM}Supports .parquet files (specify text column with :column_name){Colors.RESET}")
        path = text_input("Parquet file", "data.parquet")
        col = text_input("Text column", "text")
        source = f"{path}:{col}" if col != "text" else path
    elif source_type == "JSONL":
        print()
        print(f"  {Colors.DIM}Supports .jsonl files (specify text field with :field_name){Colors.RESET}")
        path = text_input("JSONL file", "data.jsonl")
        field = text_input("Text field", "text")
        source = f"{path}:{field}" if field != "text" else path
    elif source_type == "Directory":
        print()
        print(f"  {Colors.DIM}Reads all .txt files recursively{Colors.RESET}")
        source = text_input("Directory", "./data/")

    if not source:
        print(f"  {Colors.RED}Cancelled{Colors.RESET}")
        time.sleep(1)
        return

    # Step 2: Vocab mode
    print()
    print(f"  {Colors.BOLD}Step 2:{Colors.RESET} Vocabulary mode")
    vocab_modes = ["Standard", "Take-Needed"]
    idx = dropdown("Mode", vocab_modes)
    if idx < 0:
        return

    if vocab_modes[idx] == "Standard":
        print()
        sizes = ["10000", "20000", "32000", "50000", "100000"]
        print(f"  {Colors.BOLD}Step 2b:{Colors.RESET} Max vocabulary size")
        size_idx = dropdown("Size", sizes, default=1)
        if size_idx < 0:
            return
        vocab_size = sizes[size_idx]
        cmd = f'ion tokenize "{source}" --max-vocab {vocab_size}'
    else:
        cmd = f'ion tokenize "{source}" -tn'

    # Step 3: Domain
    print()
    print(f"  {Colors.BOLD}Step 3:{Colors.RESET} Domain optimization (optional)")
    domains = ["general", "wikipedia", "code", "legal", "chat", "medical"]
    idx = dropdown("Domain", domains)
    if idx > 0:  # Not general
        cmd += f" --domain {domains[idx]}"

    # Run
    print()
    print(f"  {Colors.GREEN}Running:{Colors.RESET} {cmd}")
    print()

    import subprocess
    subprocess.run(shlex.split(cmd))

    print()
    print(f"  {Colors.DIM}Press any key to continue...{Colors.RESET}")
    get_key()


def run_preview():
    """Live token preview - type and see tokens in real-time."""
    clear()
    print(f"\n  {Colors.BOLD}{Colors.CYAN}LIVE TOKEN PREVIEW{Colors.RESET}")
    print(f"  {'─' * 50}")
    print()
    print(f"  {Colors.DIM}Type text and see it tokenized in real-time{Colors.RESET}")
    print(f"  {Colors.DIM}Press Esc to exit{Colors.RESET}")
    print()

    # Check for tokenizer
    tok_path = Path("tokenizer.json")
    if not tok_path.exists():
        print(f"  {Colors.YELLOW}No tokenizer.json found.{Colors.RESET}")
        print(f"  {Colors.DIM}Using baseline preview mode.{Colors.RESET}")
        print()
        tok = None
    else:
        import orjson
        from .tokenizer import IonTokenizer
        data = orjson.loads(tok_path.read_bytes())
        tok = IonTokenizer.from_dict(data)
        print(f"  {Colors.GREEN}Loaded tokenizer{Colors.RESET} ({tok.vocab_size():,} tokens)")
        print()

    text = ""

    while True:
        # Clear and redraw
        print(f"\r{Colors.CLEAR_LINE}", end="")
        print(f"\033[A{Colors.CLEAR_LINE}", end="")  # Go up and clear
        print(f"\033[A{Colors.CLEAR_LINE}", end="")
        print(f"\033[A{Colors.CLEAR_LINE}", end="")

        # Show input
        print(f"  {Colors.CYAN}Text:{Colors.RESET} {text}_")
        print()

        # Show tokens
        if tok and text:
            ids = tok.encode(text)
            tokens = [tok.id_to_token.get(i, "?") for i in ids]
            token_str = " │ ".join(tokens[:15])
            if len(tokens) > 15:
                token_str += " ..."
            print(f"  {Colors.GREEN}Tokens ({len(ids)}):{Colors.RESET} {token_str}")
        elif text:
            # Rough word count as fallback
            words = text.lower().split()
            print(f"  {Colors.GREEN}Words:{Colors.RESET} {len(words)} {Colors.DIM}(load tokenizer for real count){Colors.RESET}")
        else:
            print(f"  {Colors.DIM}Start typing...{Colors.RESET}")

        print(f"  {Colors.DIM}Esc to exit{Colors.RESET}", end="", flush=True)

        key = get_key()

        if key == 'ESC' or key == 'QUIT':
            return
        elif key == 'BACKSPACE':
            text = text[:-1]
        elif key == 'ENTER':
            text += " "
        elif isinstance(key, str) and len(key) == 1 and key.isprintable():
            text += key


def run_demo():
    """Interactive demo."""
    clear()
    print(f"\n  {Colors.BOLD}{Colors.CYAN}INTERACTIVE DEMO{Colors.RESET}")
    print(f"  {'─' * 50}")
    print()

    tok_path = Path("tokenizer.json")
    if not tok_path.exists():
        print(f"  {Colors.RED}No tokenizer.json found.{Colors.RESET}")
        print(f"  {Colors.YELLOW}Run /tokenize first to create one.{Colors.RESET}")
        print()
        print(f"  {Colors.DIM}Press any key...{Colors.RESET}")
        get_key()
        return

    import orjson
    from .tokenizer import IonTokenizer
    data = orjson.loads(tok_path.read_bytes())
    tok = IonTokenizer.from_dict(data)

    print(f"  {Colors.GREEN}Loaded:{Colors.RESET} {tok.vocab_size():,} tokens")
    print(f"  {Colors.DIM}Type text to tokenize, 'q' to quit{Colors.RESET}")
    print()

    while True:
        text = text_input(">")
        if text.lower() == 'q':
            break
        if not text:
            continue

        ids = tok.encode(text)
        tokens = [tok.id_to_token.get(i, "?") for i in ids]

        print(f"  {Colors.GREEN}Tokens ({len(ids)}):{Colors.RESET}")
        print(f"  {Colors.WHITE}{' │ '.join(tokens)}{Colors.RESET}")
        print()


def run_sweep():
    """Vocab size sweep."""
    clear()
    print(f"\n  {Colors.BOLD}{Colors.CYAN}VOCAB SIZE SWEEP{Colors.RESET}")
    print(f"  {'─' * 50}")
    print()

    print(f"  {Colors.BOLD}Step 1:{Colors.RESET} Corpus source")
    source = text_input("Corpus", "wikitext")
    if not source:
        return

    print()
    print(f"  {Colors.BOLD}Step 2:{Colors.RESET} Sizes to test")
    sizes = text_input("Sizes", "5000,10000,20000,50000")

    cmd = f'ion sweep "{source}" --vocab-sizes {sizes}'

    print()
    print(f"  {Colors.GREEN}Running:{Colors.RESET} {cmd}")
    print()

    import subprocess
    subprocess.run(shlex.split(cmd))

    print()
    print(f"  {Colors.DIM}Press any key...{Colors.RESET}")
    get_key()


def run_phrases():
    """Phrase analysis."""
    clear()
    print(f"\n  {Colors.BOLD}{Colors.CYAN}PHRASE ACCOUNTABILITY{Colors.RESET}")
    print(f"  {'─' * 50}")
    print()

    tok = text_input("Tokenizer", "tokenizer.json")
    if not Path(tok).exists():
        print(f"  {Colors.RED}Not found{Colors.RESET}")
        time.sleep(1)
        return

    print()
    corpus = text_input("Test corpus")
    if not corpus:
        return

    cmd = f'ion phrases "{corpus}" -t "{tok}"'

    print()
    import subprocess
    subprocess.run(shlex.split(cmd))

    print()
    print(f"  {Colors.DIM}Press any key...{Colors.RESET}")
    get_key()


def run_parity():
    """Ion vs BPE comparison."""
    clear()
    print(f"\n  {Colors.BOLD}{Colors.CYAN}ION vs BPE PARITY{Colors.RESET}")
    print(f"  {'─' * 50}")
    print()

    tok = text_input("Tokenizer", "tokenizer.json")
    if not Path(tok).exists():
        print(f"  {Colors.RED}Not found{Colors.RESET}")
        time.sleep(1)
        return

    print()
    print(f"  {Colors.DIM}Example: The United States of America has one of the largest economies{Colors.RESET}")
    text = text_input("Text to compare")
    if not text:
        return

    cmd = f'ion parity "{text}" -t "{tok}"'

    print()
    import subprocess
    subprocess.run(shlex.split(cmd))

    print()
    print(f"  {Colors.DIM}Press any key...{Colors.RESET}")
    get_key()


def run_export():
    """Export tokenizer."""
    clear()
    print(f"\n  {Colors.BOLD}{Colors.CYAN}EXPORT TOKENIZER{Colors.RESET}")
    print(f"  {'─' * 50}")
    print()

    tok = text_input("Tokenizer", "tokenizer.json")
    if not Path(tok).exists():
        print(f"  {Colors.RED}Not found{Colors.RESET}")
        time.sleep(1)
        return

    print()
    print(f"  {Colors.BOLD}Format:{Colors.RESET}")
    formats = ["HuggingFace", "SentencePiece", "vocab.txt"]
    idx = dropdown("Format", formats)
    if idx < 0:
        return

    fmt_map = {0: "huggingface", 1: "sentencepiece", 2: "vocab"}
    fmt = fmt_map[idx]

    print()
    output = text_input("Output path", f"./ion_export/")

    cmd = f'ion export -t "{tok}" -f {fmt} -o "{output}"'

    print()
    import subprocess
    subprocess.run(shlex.split(cmd))

    print()
    print(f"  {Colors.DIM}Press any key...{Colors.RESET}")
    get_key()


def run_stats():
    """Show tokenizer stats."""
    clear()
    print(f"\n  {Colors.BOLD}{Colors.CYAN}TOKENIZER STATS{Colors.RESET}")
    print(f"  {'─' * 50}")
    print()

    tok = text_input("Tokenizer", "tokenizer.json")

    cmd = f'ion stats -t "{tok}"'

    print()
    import subprocess
    subprocess.run(shlex.split(cmd))

    print()
    print(f"  {Colors.DIM}Press any key...{Colors.RESET}")
    get_key()


def run_domains():
    """Show domain presets."""
    clear()
    print(f"\n  {Colors.BOLD}{Colors.CYAN}DOMAIN PRESETS{Colors.RESET}")
    print(f"  {'─' * 50}")
    print()

    from .tools import DOMAIN_CONFIGS

    for domain, config in DOMAIN_CONFIGS.items():
        boosters = config.get('phrase_boosters', [])[:2]
        booster_str = ', '.join(f'"{b}"' for b in boosters) if boosters else ""

        print(f"  {Colors.CYAN}{domain:<12}{Colors.RESET} {config['description']}")
        if booster_str:
            print(f"  {Colors.DIM}{' ' * 12} Boosts: {booster_str}{Colors.RESET}")

    print()
    print(f"  {Colors.YELLOW}Usage:{Colors.RESET} ion tokenize <corpus> --domain <name>")
    print()
    print(f"  {Colors.DIM}Press any key...{Colors.RESET}")
    get_key()


def run_help():
    """Show help."""
    clear()
    import subprocess
    subprocess.run(["ion", "help"])
    print()
    print(f"  {Colors.DIM}Press any key...{Colors.RESET}")
    get_key()


SCREENS = {
    "benchmarks": run_benchmarks,
    "tokenize": run_tokenize,
    "demo": run_demo,
    "preview": run_preview,
    "sweep": run_sweep,
    "phrases": run_phrases,
    "parity": run_parity,
    "export": run_export,
    "stats": run_stats,
    "domains": run_domains,
    "help": run_help,
}


def run_gui():
    """Main GUI entry point - single view architecture."""
    # Enter alternate screen buffer (like vim/less do)
    sys.stdout.write(Colors.ALT_SCREEN_ON)
    sys.stdout.write(Colors.HIDE_CURSOR)
    sys.stdout.flush()

    try:
        while True:
            cmd = show_main_menu()

            if cmd == "quit" or cmd is None:
                break

            if cmd in SCREENS:
                SCREENS[cmd]()

    finally:
        # Exit alternate screen buffer - returns to original terminal state
        sys.stdout.write(Colors.SHOW_CURSOR)
        sys.stdout.write(Colors.ALT_SCREEN_OFF)
        sys.stdout.flush()
        goodbye = random.choice(GOODBYES)
        print(f"\n  {Colors.CYAN}{goodbye}{Colors.RESET}\n")
