"""ML Framework Integrations for Ion Tokenizer.

This module provides seamless integration with popular ML frameworks:
- HuggingFace Transformers (PreTrainedTokenizer-compatible)
- PyTorch (Dataset, DataLoader, collate functions)
- TensorFlow/Keras (tf.data.Dataset compatible)
- PyTorch Lightning (DataModule)

Example usage:

    # HuggingFace Transformers style
    from ion.integrations import IonTokenizerHF
    tokenizer = IonTokenizerHF.from_pretrained("tokenizer.json")
    encoded = tokenizer("Hello world", return_tensors="pt")

    # PyTorch Dataset
    from ion.integrations import IonDataset, ion_collate_fn
    dataset = IonDataset(texts, tokenizer, max_length=512)
    loader = DataLoader(dataset, collate_fn=ion_collate_fn)

    # With HuggingFace Trainer
    from ion.integrations import IonTokenizerHF
    tokenizer = IonTokenizerHF.from_pretrained("tokenizer.json")
    trainer = Trainer(model=model, tokenizer=tokenizer, ...)
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import orjson

from .tokenizer import IonTokenizer, SPECIAL_TOKENS


# =============================================================================
# Batch Encoding Result (HuggingFace compatible)
# =============================================================================

@dataclass
class BatchEncoding:
    """Container for batch-encoded sequences (HuggingFace compatible)."""

    input_ids: List[List[int]]
    attention_mask: Optional[List[List[int]]] = None
    token_type_ids: Optional[List[List[int]]] = None

    def __getitem__(self, key: str):
        return getattr(self, key)

    def __contains__(self, key: str):
        return hasattr(self, key) and getattr(self, key) is not None

    def keys(self):
        keys = ["input_ids"]
        if self.attention_mask is not None:
            keys.append("attention_mask")
        if self.token_type_ids is not None:
            keys.append("token_type_ids")
        return keys

    def values(self):
        return [self[k] for k in self.keys()]

    def items(self):
        return [(k, self[k]) for k in self.keys()]

    def to(self, device: str):
        """Move tensors to device (requires torch)."""
        import torch
        result = {}
        for key in self.keys():
            val = getattr(self, key)
            if val is not None:
                result[key] = torch.tensor(val).to(device)
        return result

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {k: v for k, v in self.items()}


# =============================================================================
# HuggingFace Transformers Compatible Tokenizer
# =============================================================================

class IonTokenizerHF:
    """
    HuggingFace Transformers compatible wrapper for IonTokenizer.

    Implements the key interfaces expected by HuggingFace Trainer and pipelines:
    - __call__ for encoding
    - encode/decode methods
    - batch_encode_plus for batch processing
    - pad for padding sequences
    - save_pretrained/from_pretrained for serialization

    Example:
        tokenizer = IonTokenizerHF.from_pretrained("tokenizer.json")

        # Single encoding
        encoded = tokenizer("Hello world")

        # Batch encoding with padding
        encoded = tokenizer(
            ["Hello world", "Another sentence"],
            padding=True,
            max_length=128,
            truncation=True,
            return_tensors="pt"
        )

        # Use with HuggingFace Trainer
        trainer = Trainer(
            model=model,
            tokenizer=tokenizer,
            train_dataset=dataset,
        )
    """

    model_input_names = ["input_ids", "attention_mask"]

    def __init__(self, tokenizer: IonTokenizer):
        self._tokenizer = tokenizer

        # Special token IDs
        self.pad_token = "<pad>"
        self.unk_token = "<unk>"
        self.bos_token = "<bos>"
        self.eos_token = "<eos>"

        self.pad_token_id = tokenizer.vocab.get("<pad>", 0)
        self.unk_token_id = tokenizer.vocab.get("<unk>", 1)
        self.bos_token_id = tokenizer.vocab.get("<bos>", 2)
        self.eos_token_id = tokenizer.vocab.get("<eos>", 3)

        # Vocabulary
        self.vocab = tokenizer.vocab
        self.vocab_size = len(tokenizer.vocab)

        # Config
        self.model_max_length = 512
        self.padding_side = "right"
        self.truncation_side = "right"

    @classmethod
    def from_pretrained(
        cls,
        path: Union[str, Path],
        **kwargs
    ) -> "IonTokenizerHF":
        """Load tokenizer from file or directory."""
        path = Path(path)

        if path.is_dir():
            tokenizer_path = path / "tokenizer.json"
        else:
            tokenizer_path = path

        with open(tokenizer_path, "rb") as f:
            data = orjson.loads(f.read())

        tokenizer = IonTokenizer.from_dict(data)
        instance = cls(tokenizer)

        # Load config if exists
        config_path = path / "tokenizer_config.json" if path.is_dir() else path.parent / "tokenizer_config.json"
        if config_path.exists():
            with open(config_path, "r") as f:
                config = json.load(f)
                instance.model_max_length = config.get("model_max_length", 512)

        return instance

    def save_pretrained(self, path: Union[str, Path]):
        """Save tokenizer to directory."""
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)

        # Save tokenizer
        tokenizer_path = path / "tokenizer.json"
        with open(tokenizer_path, "wb") as f:
            f.write(orjson.dumps(self._tokenizer.to_dict(), option=orjson.OPT_INDENT_2))

        # Save config
        config = {
            "tokenizer_class": "IonTokenizerHF",
            "model_max_length": self.model_max_length,
            "pad_token": self.pad_token,
            "unk_token": self.unk_token,
            "bos_token": self.bos_token,
            "eos_token": self.eos_token,
        }
        config_path = path / "tokenizer_config.json"
        with open(config_path, "w") as f:
            json.dump(config, f, indent=2)

        # Save special tokens map
        special_tokens = {
            "pad_token": self.pad_token,
            "unk_token": self.unk_token,
            "bos_token": self.bos_token,
            "eos_token": self.eos_token,
        }
        special_path = path / "special_tokens_map.json"
        with open(special_path, "w") as f:
            json.dump(special_tokens, f, indent=2)

    def __call__(
        self,
        text: Union[str, List[str]],
        padding: Union[bool, str] = False,
        truncation: bool = False,
        max_length: Optional[int] = None,
        return_tensors: Optional[str] = None,
        return_attention_mask: bool = True,
        return_token_type_ids: bool = False,
        add_special_tokens: bool = True,
        **kwargs
    ) -> Union[BatchEncoding, Dict[str, Any]]:
        """
        Encode text(s) to token IDs.

        Args:
            text: Single string or list of strings to encode
            padding: Pad sequences to same length (True, "longest", "max_length")
            truncation: Truncate sequences to max_length
            max_length: Maximum sequence length
            return_tensors: Return as tensors ("pt" for PyTorch, "tf" for TensorFlow, "np" for NumPy)
            return_attention_mask: Include attention mask
            return_token_type_ids: Include token type IDs
            add_special_tokens: Add BOS/EOS tokens

        Returns:
            BatchEncoding with input_ids and optional attention_mask
        """
        if max_length is None:
            max_length = self.model_max_length

        # Handle single string
        if isinstance(text, str):
            text = [text]
            single_input = True
        else:
            single_input = False

        # Encode all texts
        all_input_ids = []
        for t in text:
            ids = self._tokenizer.encode(t)

            if add_special_tokens:
                ids = [self.bos_token_id] + ids + [self.eos_token_id]

            if truncation and len(ids) > max_length:
                if self.truncation_side == "right":
                    ids = ids[:max_length]
                else:
                    ids = ids[-max_length:]

            all_input_ids.append(ids)

        # Padding
        attention_masks = None
        if padding:
            if padding == "max_length":
                pad_to = max_length
            else:  # "longest" or True
                pad_to = max(len(ids) for ids in all_input_ids)

            attention_masks = []
            padded_ids = []

            for ids in all_input_ids:
                pad_len = pad_to - len(ids)
                mask = [1] * len(ids) + [0] * pad_len

                if self.padding_side == "right":
                    ids = ids + [self.pad_token_id] * pad_len
                else:
                    ids = [self.pad_token_id] * pad_len + ids
                    mask = [0] * pad_len + [1] * (pad_to - pad_len)

                padded_ids.append(ids)
                attention_masks.append(mask)

            all_input_ids = padded_ids

        # Create result
        result = BatchEncoding(
            input_ids=all_input_ids,
            attention_mask=attention_masks if return_attention_mask and attention_masks else None,
            token_type_ids=[[0] * len(ids) for ids in all_input_ids] if return_token_type_ids else None,
        )

        # Convert to tensors
        if return_tensors:
            result = self._convert_to_tensors(result, return_tensors)

        return result

    def _convert_to_tensors(self, encoding: BatchEncoding, tensor_type: str) -> Dict[str, Any]:
        """Convert encoding to tensors."""
        if tensor_type == "pt":
            import torch
            result = {}
            for key in encoding.keys():
                val = getattr(encoding, key)
                if val is not None:
                    result[key] = torch.tensor(val)
            return result

        elif tensor_type == "tf":
            import tensorflow as tf
            result = {}
            for key in encoding.keys():
                val = getattr(encoding, key)
                if val is not None:
                    result[key] = tf.constant(val)
            return result

        elif tensor_type == "np":
            import numpy as np
            result = {}
            for key in encoding.keys():
                val = getattr(encoding, key)
                if val is not None:
                    result[key] = np.array(val)
            return result

        return encoding.to_dict()

    def encode(
        self,
        text: str,
        add_special_tokens: bool = True,
        **kwargs
    ) -> List[int]:
        """Encode single text to token IDs."""
        ids = self._tokenizer.encode(text)
        if add_special_tokens:
            ids = [self.bos_token_id] + ids + [self.eos_token_id]
        return ids

    def decode(
        self,
        token_ids: List[int],
        skip_special_tokens: bool = True,
        **kwargs
    ) -> str:
        """Decode token IDs to text."""
        if skip_special_tokens:
            token_ids = [t for t in token_ids if t not in {
                self.pad_token_id, self.bos_token_id, self.eos_token_id
            }]
        return self._tokenizer.decode(token_ids)

    def batch_decode(
        self,
        sequences: List[List[int]],
        skip_special_tokens: bool = True,
        **kwargs
    ) -> List[str]:
        """Decode batch of token IDs to texts."""
        return [self.decode(seq, skip_special_tokens) for seq in sequences]

    def encode_plus(
        self,
        text: str,
        **kwargs
    ) -> BatchEncoding:
        """Encode with additional outputs (alias for __call__)."""
        return self(text, **kwargs)

    def batch_encode_plus(
        self,
        batch_text: List[str],
        **kwargs
    ) -> BatchEncoding:
        """Batch encode with additional outputs."""
        return self(batch_text, **kwargs)

    def pad(
        self,
        encoded_inputs: Union[BatchEncoding, List[Dict], Dict],
        padding: Union[bool, str] = True,
        max_length: Optional[int] = None,
        return_tensors: Optional[str] = None,
        **kwargs
    ) -> Union[BatchEncoding, Dict]:
        """Pad encoded inputs to same length."""
        if isinstance(encoded_inputs, BatchEncoding):
            input_ids = encoded_inputs.input_ids
        elif isinstance(encoded_inputs, dict):
            input_ids = encoded_inputs["input_ids"]
        else:
            input_ids = [e["input_ids"] for e in encoded_inputs]

        if max_length is None:
            max_length = max(len(ids) for ids in input_ids)

        padded_ids = []
        attention_masks = []

        for ids in input_ids:
            pad_len = max_length - len(ids)
            mask = [1] * len(ids) + [0] * pad_len
            ids = ids + [self.pad_token_id] * pad_len
            padded_ids.append(ids)
            attention_masks.append(mask)

        result = BatchEncoding(
            input_ids=padded_ids,
            attention_mask=attention_masks,
        )

        if return_tensors:
            return self._convert_to_tensors(result, return_tensors)

        return result

    def get_vocab(self) -> Dict[str, int]:
        """Get vocabulary as dict."""
        return self.vocab.copy()

    def __len__(self) -> int:
        """Return vocabulary size."""
        return self.vocab_size

    def convert_tokens_to_ids(self, tokens: Union[str, List[str]]) -> Union[int, List[int]]:
        """Convert tokens to IDs."""
        if isinstance(tokens, str):
            return self.vocab.get(tokens, self.unk_token_id)
        return [self.vocab.get(t, self.unk_token_id) for t in tokens]

    def convert_ids_to_tokens(self, ids: Union[int, List[int]]) -> Union[str, List[str]]:
        """Convert IDs to tokens."""
        if isinstance(ids, int):
            return self._tokenizer.id_to_token.get(ids, self.unk_token)
        return [self._tokenizer.id_to_token.get(i, self.unk_token) for i in ids]

    def convert_tokens_to_string(self, tokens: List[str]) -> str:
        """Convert a sequence of tokens to a single string."""
        return " ".join(tokens)

    def clean_up_tokenization(self, text: str) -> str:
        """Clean up tokenization artifacts (extra spaces around punctuation)."""
        for punct in [".", ",", "!", "?", ";", ":", "'", '"', ")", "]", "}"]:
            text = text.replace(f" {punct}", punct)
        for punct in ["(", "[", "{"]:
            text = text.replace(f"{punct} ", punct)
        return text.strip()

    @property
    def all_special_tokens(self) -> List[str]:
        """Return all special tokens."""
        return [self.pad_token, self.unk_token, self.bos_token, self.eos_token]

    @property
    def all_special_ids(self) -> List[int]:
        """Return all special token IDs."""
        return [self.pad_token_id, self.unk_token_id, self.bos_token_id, self.eos_token_id]


# =============================================================================
# PyTorch Dataset
# =============================================================================

class IonDataset:
    """
    PyTorch Dataset for Ion tokenizer.

    Example:
        from torch.utils.data import DataLoader
        from ion.integrations import IonDataset, ion_collate_fn

        dataset = IonDataset(
            texts=["Hello world", "Another text"],
            tokenizer=tokenizer,
            max_length=512
        )

        loader = DataLoader(
            dataset,
            batch_size=32,
            collate_fn=ion_collate_fn(tokenizer.pad_token_id)
        )
    """

    def __init__(
        self,
        texts: List[str],
        tokenizer: Union[IonTokenizer, IonTokenizerHF],
        max_length: int = 512,
        add_special_tokens: bool = True,
        labels: Optional[List[Any]] = None,
    ):
        self.texts = texts
        self.labels = labels
        self.max_length = max_length
        self.add_special_tokens = add_special_tokens

        if isinstance(tokenizer, IonTokenizerHF):
            self.tokenizer = tokenizer
        else:
            self.tokenizer = IonTokenizerHF(tokenizer)

    def __len__(self) -> int:
        return len(self.texts)

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        text = self.texts[idx]

        encoded = self.tokenizer(
            text,
            truncation=True,
            max_length=self.max_length,
            add_special_tokens=self.add_special_tokens,
        )

        result = {
            "input_ids": encoded.input_ids[0],
        }

        if self.labels is not None:
            result["labels"] = self.labels[idx]

        return result


class IonLanguageModelDataset:
    """
    Dataset for language modeling (causal LM / next token prediction).

    Example:
        dataset = IonLanguageModelDataset(
            texts=corpus,
            tokenizer=tokenizer,
            block_size=512
        )
    """

    def __init__(
        self,
        texts: List[str],
        tokenizer: Union[IonTokenizer, IonTokenizerHF],
        block_size: int = 512,
    ):
        if isinstance(tokenizer, IonTokenizerHF):
            self.tokenizer = tokenizer
        else:
            self.tokenizer = IonTokenizerHF(tokenizer)

        self.block_size = block_size

        # Concatenate all texts and tokenize
        all_ids = []
        for text in texts:
            ids = self.tokenizer.encode(text, add_special_tokens=False)
            all_ids.extend(ids)
            all_ids.append(self.tokenizer.eos_token_id)

        # Split into blocks
        self.examples = []
        for i in range(0, len(all_ids) - block_size, block_size):
            self.examples.append(all_ids[i:i + block_size + 1])

    def __len__(self) -> int:
        return len(self.examples)

    def __getitem__(self, idx: int) -> Dict[str, List[int]]:
        chunk = self.examples[idx]
        return {
            "input_ids": chunk[:-1],
            "labels": chunk[1:],
        }


def ion_collate_fn(pad_token_id: int = 0):
    """
    Create a collate function for DataLoader.

    Example:
        loader = DataLoader(
            dataset,
            batch_size=32,
            collate_fn=ion_collate_fn(tokenizer.pad_token_id)
        )
    """
    def collate(batch: List[Dict[str, Any]]) -> Dict[str, Any]:
        import torch

        # Get max length in batch
        max_len = max(len(item["input_ids"]) for item in batch)

        input_ids = []
        attention_masks = []
        labels = []
        has_labels = "labels" in batch[0]

        for item in batch:
            ids = item["input_ids"]
            pad_len = max_len - len(ids)

            # Pad input_ids
            padded_ids = ids + [pad_token_id] * pad_len
            input_ids.append(padded_ids)

            # Create attention mask
            mask = [1] * len(ids) + [0] * pad_len
            attention_masks.append(mask)

            # Handle labels
            if has_labels:
                if isinstance(item["labels"], list):
                    # Sequence labels (LM)
                    padded_labels = item["labels"] + [-100] * pad_len
                    labels.append(padded_labels)
                else:
                    # Classification label
                    labels.append(item["labels"])

        result = {
            "input_ids": torch.tensor(input_ids),
            "attention_mask": torch.tensor(attention_masks),
        }

        if has_labels:
            if isinstance(batch[0]["labels"], list):
                result["labels"] = torch.tensor(labels)
            else:
                result["labels"] = torch.tensor(labels)

        return result

    return collate


# =============================================================================
# PyTorch Lightning DataModule
# =============================================================================

class IonDataModule:
    """
    PyTorch Lightning DataModule for Ion tokenizer.

    Example:
        from pytorch_lightning import Trainer

        datamodule = IonDataModule(
            train_texts=train_data,
            val_texts=val_data,
            tokenizer=tokenizer,
            batch_size=32
        )

        trainer = Trainer(...)
        trainer.fit(model, datamodule)
    """

    def __init__(
        self,
        train_texts: List[str],
        tokenizer: Union[IonTokenizer, IonTokenizerHF],
        val_texts: Optional[List[str]] = None,
        test_texts: Optional[List[str]] = None,
        train_labels: Optional[List[Any]] = None,
        val_labels: Optional[List[Any]] = None,
        test_labels: Optional[List[Any]] = None,
        batch_size: int = 32,
        max_length: int = 512,
        num_workers: int = 0,
    ):
        if isinstance(tokenizer, IonTokenizerHF):
            self.tokenizer = tokenizer
        else:
            self.tokenizer = IonTokenizerHF(tokenizer)

        self.train_texts = train_texts
        self.val_texts = val_texts
        self.test_texts = test_texts
        self.train_labels = train_labels
        self.val_labels = val_labels
        self.test_labels = test_labels
        self.batch_size = batch_size
        self.max_length = max_length
        self.num_workers = num_workers

    def setup(self, stage: Optional[str] = None):
        """Set up datasets."""
        if stage == "fit" or stage is None:
            self.train_dataset = IonDataset(
                self.train_texts,
                self.tokenizer,
                self.max_length,
                labels=self.train_labels,
            )
            if self.val_texts:
                self.val_dataset = IonDataset(
                    self.val_texts,
                    self.tokenizer,
                    self.max_length,
                    labels=self.val_labels,
                )

        if stage == "test" or stage is None:
            if self.test_texts:
                self.test_dataset = IonDataset(
                    self.test_texts,
                    self.tokenizer,
                    self.max_length,
                    labels=self.test_labels,
                )

    def train_dataloader(self):
        from torch.utils.data import DataLoader
        return DataLoader(
            self.train_dataset,
            batch_size=self.batch_size,
            shuffle=True,
            num_workers=self.num_workers,
            collate_fn=ion_collate_fn(self.tokenizer.pad_token_id),
        )

    def val_dataloader(self):
        from torch.utils.data import DataLoader
        if not hasattr(self, 'val_dataset'):
            return None
        return DataLoader(
            self.val_dataset,
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=self.num_workers,
            collate_fn=ion_collate_fn(self.tokenizer.pad_token_id),
        )

    def test_dataloader(self):
        from torch.utils.data import DataLoader
        if not hasattr(self, 'test_dataset'):
            return None
        return DataLoader(
            self.test_dataset,
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=self.num_workers,
            collate_fn=ion_collate_fn(self.tokenizer.pad_token_id),
        )

    def predict_dataloader(self):
        from torch.utils.data import DataLoader
        if not hasattr(self, 'test_dataset'):
            return None
        return DataLoader(
            self.test_dataset,
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=self.num_workers,
            collate_fn=ion_collate_fn(self.tokenizer.pad_token_id),
        )


# =============================================================================
# TensorFlow/Keras Integration
# =============================================================================

def create_tf_dataset(
    texts: List[str],
    tokenizer: Union[IonTokenizer, IonTokenizerHF],
    max_length: int = 512,
    batch_size: int = 32,
    labels: Optional[List[Any]] = None,
    shuffle: bool = True,
    buffer_size: int = 10000,
):
    """
    Create a TensorFlow Dataset from texts.

    Example:
        import tensorflow as tf

        dataset = create_tf_dataset(
            texts=train_texts,
            tokenizer=tokenizer,
            max_length=512,
            batch_size=32
        )

        model.fit(dataset, epochs=10)
    """
    import tensorflow as tf

    if isinstance(tokenizer, IonTokenizer):
        tokenizer = IonTokenizerHF(tokenizer)

    # Encode all texts
    encoded = tokenizer(
        texts,
        padding="max_length",
        truncation=True,
        max_length=max_length,
        return_attention_mask=True,
    )

    # Create dataset
    if labels is not None:
        dataset = tf.data.Dataset.from_tensor_slices((
            {
                "input_ids": encoded.input_ids,
                "attention_mask": encoded.attention_mask,
            },
            labels
        ))
    else:
        dataset = tf.data.Dataset.from_tensor_slices({
            "input_ids": encoded.input_ids,
            "attention_mask": encoded.attention_mask,
        })

    if shuffle:
        dataset = dataset.shuffle(buffer_size)

    dataset = dataset.batch(batch_size)
    dataset = dataset.prefetch(tf.data.AUTOTUNE)

    return dataset


# =============================================================================
# Export Utilities
# =============================================================================

def export_for_onnx(
    tokenizer: Union[IonTokenizer, IonTokenizerHF],
    output_dir: Union[str, Path],
):
    """
    Export tokenizer in ONNX-compatible format.

    Creates vocab files that can be used with ONNX tokenizer operators.
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    if isinstance(tokenizer, IonTokenizer):
        tokenizer = IonTokenizerHF(tokenizer)

    # Export vocabulary
    vocab_path = output_dir / "vocab.txt"
    with open(vocab_path, "w", encoding="utf-8") as f:
        for token, idx in sorted(tokenizer.vocab.items(), key=lambda x: x[1]):
            f.write(f"{token}\n")

    # Export tokenizer config
    config = {
        "vocab_size": tokenizer.vocab_size,
        "pad_token_id": tokenizer.pad_token_id,
        "unk_token_id": tokenizer.unk_token_id,
        "bos_token_id": tokenizer.bos_token_id,
        "eos_token_id": tokenizer.eos_token_id,
    }
    config_path = output_dir / "config.json"
    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)


def export_for_sentencepiece(
    tokenizer: Union[IonTokenizer, IonTokenizerHF],
    output_path: Union[str, Path],
):
    """
    Export vocabulary in SentencePiece-compatible format.

    Note: This exports the vocabulary only, not the segmentation model.
    """
    if isinstance(tokenizer, IonTokenizer):
        tokenizer = IonTokenizerHF(tokenizer)

    output_path = Path(output_path)

    with open(output_path, "w", encoding="utf-8") as f:
        for token, idx in sorted(tokenizer.vocab.items(), key=lambda x: x[1]):
            # SentencePiece format: token\tscore
            f.write(f"{token}\t{-idx}\n")


# =============================================================================
# Training Utilities
# =============================================================================

class IonTrainingArguments:
    """
    Training arguments for Ion tokenizer (HuggingFace Trainer compatible).

    Example:
        args = IonTrainingArguments(
            output_dir="./model",
            num_train_epochs=3,
            per_device_train_batch_size=32,
        )
    """

    def __init__(
        self,
        output_dir: str = "./output",
        num_train_epochs: int = 3,
        per_device_train_batch_size: int = 8,
        per_device_eval_batch_size: int = 8,
        learning_rate: float = 5e-5,
        weight_decay: float = 0.01,
        warmup_steps: int = 500,
        logging_steps: int = 100,
        eval_steps: int = 500,
        save_steps: int = 1000,
        max_length: int = 512,
        **kwargs
    ):
        self.output_dir = output_dir
        self.num_train_epochs = num_train_epochs
        self.per_device_train_batch_size = per_device_train_batch_size
        self.per_device_eval_batch_size = per_device_eval_batch_size
        self.learning_rate = learning_rate
        self.weight_decay = weight_decay
        self.warmup_steps = warmup_steps
        self.logging_steps = logging_steps
        self.eval_steps = eval_steps
        self.save_steps = save_steps
        self.max_length = max_length

        for k, v in kwargs.items():
            setattr(self, k, v)


def prepare_model_inputs(
    texts: List[str],
    tokenizer: Union[IonTokenizer, IonTokenizerHF],
    max_length: int = 512,
    device: str = "cpu",
) -> Dict[str, Any]:
    """
    Prepare model inputs from texts (ready for forward pass).

    Example:
        inputs = prepare_model_inputs(
            texts=["Hello world"],
            tokenizer=tokenizer,
            device="cuda"
        )
        outputs = model(**inputs)
    """
    if isinstance(tokenizer, IonTokenizer):
        tokenizer = IonTokenizerHF(tokenizer)

    encoded = tokenizer(
        texts,
        padding=True,
        truncation=True,
        max_length=max_length,
        return_tensors="pt",
    )

    return {k: v.to(device) for k, v in encoded.items()}
