"""Ion Tokenizer licensing and registration system."""

import hashlib
import hmac
import json
import os
import re
import secrets
import string
import random
import sys
import time
import webbrowser
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

ION_CONFIG_DIR = Path.home() / ".ion"
ION_CONFIG_FILE = ION_CONFIG_DIR / "config.json"
ION_PENDING_SYNC_FILE = ION_CONFIG_DIR / "pending_sync.json"
ION_BASE_URL = "https://iontokenizer.com"
ION_LICENSE_VERSION = "1.0"

PLAN_NAMES = {
    "free": "Free",
    "closed": "Closed",
    "open-large": "Open Large",
    "enterprise": "Enterprise",
}

PLAN_TOKENS = {
    "free": "<ion-tokenizer-free>",
    "closed": "<ion-tokenizer-closed>",
    "open-large": "<ion-tokenizer-open-large>",
    "enterprise": "<ion-tokenizer-enterprise>",
}

PLAN_PRICES = {
    "free": "$0",
    "closed": "$100 one-time",
    "open-large": "$1,000 one-time",
    "enterprise": "$2,000 per billion one-time",
}

STANDARD_ATTRIBUTION = 'Tokenized with [Ion Tokenizer](https://iontokenizer.com)'


def _random_id(prefix: str, length: int = 12) -> str:
    """Generate a cryptographically secure random ID."""
    return prefix + secrets.token_hex(length // 2 + 1)[:length]


def _generate_session_id() -> str:
    """Generate a cryptographically secure session ID."""
    return "sess_" + secrets.token_hex(8)


def _generate_tokenizer_id() -> str:
    """Generate a cryptographically secure tokenizer ID."""
    return _random_id("ion_", 12)


def _sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _validate_email(email: str) -> bool:
    return bool(re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email))


def _ensure_config_dir():
    ION_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(ION_CONFIG_DIR, 0o700)
    except OSError:
        pass


def load_config() -> Optional[dict]:
    """Load registration config from ~/.ion/config.json."""
    if ION_CONFIG_FILE.exists():
        try:
            return json.loads(ION_CONFIG_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            return None
    return None


def save_config(config: dict):
    """Save registration config to ~/.ion/config.json with restricted permissions."""
    _ensure_config_dir()
    ION_CONFIG_FILE.write_text(json.dumps(config, indent=2))
    try:
        os.chmod(ION_CONFIG_FILE, 0o600)
    except OSError:
        pass


def is_registered() -> bool:
    """Check if user has a valid registration."""
    config = load_config()
    if not config:
        return False
    required = ["email", "plan", "agreed_to_license"]
    return all(config.get(k) for k in required)


def _load_pending_sync() -> dict:
    if ION_PENDING_SYNC_FILE.exists():
        try:
            return json.loads(ION_PENDING_SYNC_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            return {"registrations": [], "tokenizers": []}
    return {"registrations": [], "tokenizers": []}


def _save_pending_sync(data: dict):
    _ensure_config_dir()
    ION_PENDING_SYNC_FILE.write_text(json.dumps(data, indent=2))
    try:
        os.chmod(ION_PENDING_SYNC_FILE, 0o600)
    except OSError:
        pass


def _check_internet() -> bool:
    """Quick check if we can reach the server."""
    try:
        import urllib.request
        urllib.request.urlopen(f"{ION_BASE_URL}/api/health", timeout=5)
        return True
    except Exception:
        return False


def _post_json(url: str, data: dict) -> Optional[dict]:
    """POST JSON to server, return response or None on failure."""
    try:
        import urllib.request
        req = urllib.request.Request(
            url,
            data=json.dumps(data).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception:
        return None


def _get_json(url: str) -> Optional[dict]:
    """GET JSON from server, return response or None on failure."""
    try:
        import urllib.request
        with urllib.request.urlopen(url, timeout=10) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception:
        return None


def _poll_payment(session_id: str) -> Optional[dict]:
    """Poll payment status. Returns completed session data or None."""
    import click

    poll_interval = 2
    max_wait = 1800  # 30 minutes
    url = f"{ION_BASE_URL}/api/session/{session_id}/status"

    spinner_frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
    frame_idx = 0

    click.echo("  Waiting for payment confirmation...")
    click.echo("  (Press Ctrl+C to cancel)")
    click.echo()

    start_time = time.time()
    try:
        while time.time() - start_time < max_wait:
            click.echo(f"\r  {spinner_frames[frame_idx % len(spinner_frames)]} Waiting...", nl=False)
            frame_idx += 1

            data = _get_json(url)
            if data:
                status = data.get("status")
                if status == "completed":
                    click.echo(f"\r  ✓ Payment confirmed!          ")
                    return data
                elif status == "cancelled":
                    click.echo(f"\r  ✗ Payment cancelled.          ")
                    return None
                elif status == "expired":
                    click.echo(f"\r  ✗ Session expired. Run: ion register")
                    return None

            time.sleep(poll_interval)
    except KeyboardInterrupt:
        click.echo(f"\r  ✗ Cancelled.                  ")
        return None

    click.echo(f"\r  ✗ Timed out waiting for payment. Run: ion register")
    return None


def register_interactive(force: bool = False, preset_email: str = None, preset_plan: str = None) -> Optional[dict]:
    """Run interactive registration flow. Returns config dict or None."""
    import click

    existing = load_config()
    if existing and is_registered() and not force:
        click.echo(f"  Already registered as {existing['email']} ({PLAN_NAMES.get(existing['plan'], existing['plan'])})")
        click.echo(f"  Use --force to re-register.")
        return existing

    click.echo("━" * 64)
    click.echo("  Ion Tokenizer — First Time Setup")
    click.echo("━" * 64)
    click.echo()

    # Email
    if preset_email and _validate_email(preset_email):
        email = preset_email
        click.echo(f"  Email: {email}")
    else:
        while True:
            email = click.prompt("  Email")
            if _validate_email(email):
                break
            click.echo("  ✗ Invalid email address. Please enter a valid email.")

    click.echo()

    # Plan selection
    click.echo("  Select your plan:")
    click.echo()
    click.echo("    [1] Free")
    click.echo("        Models <10B parameters")
    click.echo("        Must open source weights within 7 days of public deployment")
    click.echo()
    click.echo("    [2] Closed — $100 one-time")
    click.echo("        Models <10B parameters")
    click.echo("        Keep weights private, commercial use allowed")
    click.echo()
    click.echo("    [3] Open Large — $1,000 one-time")
    click.echo("        Models ≥10B parameters")
    click.echo("        Must open source weights within 7 days of public deployment")
    click.echo()
    click.echo("    [4] Enterprise — $2,000 per billion one-time")
    click.echo("        Models ≥10B parameters")
    click.echo("        Keep weights private, commercial use allowed")
    click.echo()

    plan_map = {"1": "free", "2": "closed", "3": "open-large", "4": "enterprise"}

    if preset_plan and preset_plan in plan_map.values():
        plan = preset_plan
        reverse = {v: k for k, v in plan_map.items()}
        click.echo(f"  Plan [{reverse[plan]}]: {PLAN_NAMES[plan]}")
    else:
        while True:
            choice = click.prompt("  Plan [1/2/3/4]", default="1")
            if choice in plan_map:
                plan = plan_map[choice]
                break
            click.echo("  Please enter 1, 2, 3, or 4.")

    click.echo()

    # License agreement
    click.echo("  □ I agree to the Ion Tokenizer License Agreement")
    click.echo(f"    {ION_BASE_URL}/license")
    click.echo()
    agreed = click.confirm("  Agree", default=False)
    if not agreed:
        click.echo()
        click.echo("  ✗ You must agree to the license to use Ion Tokenizer.")
        click.echo()
        click.echo(f"  Review the license at: {ION_BASE_URL}/license")
        click.echo()
        click.echo("  Then run: ion register")
        return None

    click.echo()

    now = datetime.now(timezone.utc).isoformat()

    # Handle paid plans
    if plan in ("closed", "open-large", "enterprise"):
        if plan == "enterprise":
            click.echo("━" * 64)
            click.echo("  Enterprise Plan")
            click.echo("━" * 64)
            click.echo()
            click.echo("  For models ≥10B parameters with closed weights.")
            click.echo()
            click.echo("  Pricing: $2,000 per billion parameters (one-time)")
            click.echo()
            click.echo("  Examples:")
            click.echo("    10B model  → $20,000")
            click.echo("    70B model  → $140,000")
            click.echo("    405B model → $810,000")
            click.echo()
            click.echo("  Alternative: Grant API access to your trained model")
            click.echo("               in lieu of payment.")
            click.echo()
            click.echo("  For API access arrangements, contact: support@creayodev.com")
            click.echo()

        click.echo("━" * 64)
        click.echo("  Payment Required")
        click.echo("━" * 64)
        click.echo()
        click.echo(f"  Plan: {PLAN_NAMES[plan]} — {PLAN_PRICES[plan]}")
        click.echo()

        online = _check_internet()
        if not online:
            click.echo("  ✗ Payment requires internet connection.")
            click.echo()
            click.echo("  Please connect to the internet and run: ion register")
            return None

        session_id = _generate_session_id()
        checkout_url = f"{ION_BASE_URL}/checkout?session_id={session_id}&plan={plan}&email={email}"

        click.echo("  Opening browser for payment...")
        click.echo()
        try:
            webbrowser.open(checkout_url)
        except Exception:
            click.echo(f"  Could not open browser. Visit:")
            click.echo(f"  {checkout_url}")
            click.echo()

        result = _poll_payment(session_id)
        if not result:
            click.echo()
            click.echo(f"  To retry: ion register --plan {plan}")
            click.echo(f"  To use free plan: ion register --plan free")
            return None

        config = {
            "email": email,
            "plan": plan,
            "user_id": result.get("user_id", _random_id("usr_")),
            "registered_at": now,
            "agreed_to_license": True,
            "license_version": ION_LICENSE_VERSION,
            "payment_confirmed": True,
        }
    else:
        # Free plan
        online = _check_internet()
        if online:
            resp = _post_json(f"{ION_BASE_URL}/api/register", {
                "email": email,
                "plan": "free",
                "registered_at": now,
                "license_version": ION_LICENSE_VERSION,
            })
            user_id = resp.get("user_id", _random_id("usr_")) if resp else _random_id("usr_local_")
        else:
            click.echo()
            click.echo("  ⚠ Could not connect to iontokenizer.com")
            click.echo()
            click.echo("  Registering locally. Your registration will sync when connection is available.")
            click.echo()
            cont = click.confirm("  Continue anyway?", default=True)
            if not cont:
                return None
            user_id = _random_id("usr_local_")
            # Queue for sync
            pending = _load_pending_sync()
            pending["registrations"].append({
                "email": email,
                "plan": "free",
                "registered_at": now,
                "license_version": ION_LICENSE_VERSION,
                "local_user_id": user_id,
            })
            _save_pending_sync(pending)

        config = {
            "email": email,
            "plan": "free",
            "user_id": user_id,
            "registered_at": now,
            "agreed_to_license": True,
            "license_version": ION_LICENSE_VERSION,
        }

    save_config(config)

    click.echo()
    click.echo("━" * 64)
    click.echo("  ✓ Registered successfully")
    click.echo()
    click.echo(f"  Email:  {email}")
    click.echo(f"  Plan:   {PLAN_NAMES[plan]}")
    click.echo("━" * 64)
    click.echo()

    return config


def ensure_registered() -> dict:
    """Ensure user is registered. Runs interactive flow if not. Returns config.

    Exits if registration fails or is declined.
    """
    import click

    config = load_config()

    if config and is_registered():
        # Validate paid plans have payment confirmed
        if config.get("plan") in ("closed", "open-large", "enterprise"):
            if not config.get("payment_confirmed"):
                click.echo(f"  ✗ Your plan ({PLAN_NAMES.get(config['plan'], config['plan'])}) requires payment.")
                click.echo()
                click.echo(f"  Complete payment: ion upgrade --plan {config['plan']}")
                click.echo(f"  Or switch to free: ion register --force --plan free")
                sys.exit(1)

        # Check license version
        if config.get("license_version") != ION_LICENSE_VERSION:
            click.echo("  Your license agreement is outdated.")
            agreed = click.confirm(f"  Agree to updated terms? ({ION_BASE_URL}/license)", default=True)
            if not agreed:
                click.echo("  ✗ You must agree to the updated license to continue.")
                sys.exit(1)
            config["license_version"] = ION_LICENSE_VERSION
            save_config(config)

        return config

    # Not registered — run interactive flow
    config = register_interactive()
    if not config:
        sys.exit(1)
    return config


def compute_vocab_hash(vocab: dict) -> str:
    """Compute SHA-256 hash of sorted vocab keys."""
    keys = sorted(vocab.keys())
    return _sha256("\n".join(keys))


# =============================================================================
# Tokenizer HMAC Signing & Verification
# =============================================================================

# Signing key is derived from user_id + email_hash so each user has a unique key
# This prevents license token swapping between users
_SIGNING_ALGORITHM = "sha256"


def _derive_signing_key(config: dict) -> bytes:
    """Derive a per-user signing key from registration config."""
    user_id = config.get("user_id", "")
    email = config.get("email", "")
    key_material = f"ion-signing-v1:{user_id}:{_sha256(email)}"
    return hashlib.sha256(key_material.encode("utf-8")).digest()


def sign_tokenizer(tokenizer_data: dict, config: dict) -> str:
    """Compute HMAC signature of tokenizer data for tamper detection.

    Signs the critical fields: vocab_size, plan token, license metadata.
    Returns hex-encoded HMAC signature.
    """
    key = _derive_signing_key(config)

    # Build canonical signing payload from tamper-critical fields
    license_info = tokenizer_data.get("ion_license", {})
    sign_payload = json.dumps({
        "vocab_size": tokenizer_data.get("vocab_size", 0),
        "plan": license_info.get("plan", ""),
        "tokenizer_id": license_info.get("tokenizer_id", ""),
        "email_hash": license_info.get("email_hash", ""),
    }, sort_keys=True, separators=(",", ":"))

    signature = hmac.new(key, sign_payload.encode("utf-8"), hashlib.sha256).hexdigest()
    return signature


def verify_tokenizer_signature(tokenizer_data: dict, config: dict) -> bool:
    """Verify the HMAC signature of a tokenizer file.

    Returns True if signature is valid, False if tampered or missing.
    """
    stored_sig = tokenizer_data.get("ion_license", {}).get("signature")
    if not stored_sig:
        return False

    expected_sig = sign_tokenizer(tokenizer_data, config)
    return hmac.compare_digest(stored_sig, expected_sig)


def validate_license_token(tokenizer_data: dict) -> dict:
    """Validate that the license token in the tokenizer matches the license metadata.

    Returns dict with 'valid' bool and 'reason' string.
    """
    license_info = tokenizer_data.get("ion_license", {})
    if not license_info:
        return {"valid": False, "reason": "No license metadata found"}

    plan = license_info.get("plan", "")
    if plan not in PLAN_TOKENS:
        return {"valid": False, "reason": f"Unknown plan: {plan}"}

    expected_token = PLAN_TOKENS[plan]

    # Check that the expected plan token exists in special tokens
    special_tokens = tokenizer_data.get("token_classes", {}).get("special", [])
    special_token_names = [t.get("token", "") for t in special_tokens]

    if expected_token not in special_token_names:
        return {"valid": False, "reason": f"Plan token {expected_token} not found in tokenizer"}

    # Check for unauthorized plan tokens (someone inserting a higher-tier token)
    for tok_name in special_token_names:
        if tok_name.startswith("<ion-tokenizer-") and tok_name != expected_token:
            return {
                "valid": False,
                "reason": f"Unauthorized plan token {tok_name} found (expected {expected_token})"
            }

    # Validate required fields
    required = ["tokenizer_id", "email_hash", "created_at"]
    for field in required:
        if not license_info.get(field):
            return {"valid": False, "reason": f"Missing required field: {field}"}

    return {"valid": True, "reason": "License valid"}


def log_tokenizer_creation(config: dict, tokenizer_id: str, vocab_size: int, vocab_hash: str):
    """Log tokenizer creation to server (or queue if offline)."""
    from . import __version__

    now = datetime.now(timezone.utc).isoformat()
    payload = {
        "user_id": config.get("user_id", "unknown"),
        "tokenizer_id": tokenizer_id,
        "plan": config.get("plan", "free"),
        "vocab_size": vocab_size,
        "vocab_hash": vocab_hash,
        "created_at": now,
        "ion_version": __version__,
    }

    resp = _post_json(f"{ION_BASE_URL}/api/tokenizer/create", payload)
    if not resp:
        # Queue for later sync
        pending = _load_pending_sync()
        pending.setdefault("tokenizers", []).append(payload)
        _save_pending_sync(pending)
        import click
        click.echo("  ⚠ Tokenizer logged locally. Will sync when connection is available.")


def generate_license_md(
    email: str,
    plan: str,
    tokenizer_id: str,
    created_at: str,
    version: str,
) -> str:
    """Generate LICENSE.md content for a tokenizer."""
    plan_display = PLAN_NAMES.get(plan, plan)

    # Plan-specific terms
    terms = _get_plan_terms(plan)
    upgrade = _get_upgrade_section(plan)

    # Attribution section — enterprise closed doesn't need it, all others do
    if plan == "enterprise":
        attribution_section = ""
    else:
        attribution_section = f"""
---

## Attribution

When publishing models trained with this tokenizer, include the following exactly as shown in your model card, README, or documentation:

> {STANDARD_ATTRIBUTION}

This exact text is required and will be verified. For API access to Ion services,
contact support@creayodev.com.
"""

    content = f"""# Ion Tokenizer License

| Field | Value |
|-------|-------|
| Licensee | {email} |
| Plan | {plan_display} |
| Tokenizer ID | {tokenizer_id} |
| Created | {created_at} |
| Ion Version | {version} |

---

## Terms

{terms}
{attribution_section}
---

## Upgrade

{upgrade}

---

## Contact

- Documentation: {ION_BASE_URL}/docs
- Support: support@creayodev.com
- License questions: legal@iontokenizer.com

---

Ion Tokenizer by Creayo
{ION_BASE_URL}
"""
    return content


def _get_plan_terms(plan: str) -> str:
    if plan == "free":
        return """This tokenizer is licensed under the Ion Free Plan.

You MAY:
- Train models up to 10 billion parameters
- Use for research, development, and internal applications
- Deploy internally without restriction

You MUST:
- Open source model weights within 7 days of any public deployment
- "Public deployment" includes: APIs, applications, hosted services, or any
  system where users outside your organization can access model outputs
- Include attribution in model card or documentation

You MAY NOT:
- Train models over 10B parameters (requires Open Large or Enterprise plan)
- Deploy publicly without releasing weights (requires Closed or Enterprise plan)"""

    elif plan == "closed":
        return """This tokenizer is licensed under the Ion Closed Plan ($100 one-time).

You MAY:
- Train models up to 10 billion parameters
- Keep model weights private and proprietary
- Deploy commercially without open sourcing
- Use for any lawful commercial purpose

You MUST:
- Include attribution in model card or documentation

You MAY NOT:
- Train models over 10B parameters (requires Enterprise plan)
- Transfer this license to another organization"""

    elif plan == "open-large":
        return """This tokenizer is licensed under the Ion Open Large Plan ($1,000 one-time).

You MAY:
- Train models of any size
- Use for research, development, and internal applications
- Deploy internally without restriction

You MUST:
- Open source model weights within 7 days of any public deployment
- "Public deployment" includes: APIs, applications, hosted services, or any
  system where users outside your organization can access model outputs
- Include attribution in model card or documentation

You MAY NOT:
- Deploy publicly without releasing weights (requires Enterprise plan)"""

    elif plan == "enterprise":
        return """This tokenizer is licensed under the Ion Enterprise Plan.

You MAY:
- Train models of any size
- Keep model weights private and proprietary
- Deploy commercially without open sourcing
- Use for any lawful commercial purpose

Pricing: $2,000 per billion parameters (one-time)

Your specific terms are defined in your enterprise agreement.
Contact enterprise@iontokenizer.com for questions."""

    return "Unknown plan."


def _get_upgrade_section(plan: str) -> str:
    if plan == "free":
        return """To keep your model weights private:
  ion upgrade --plan closed
  ($100 one-time payment)

For models over 10B parameters (open source):
  ion upgrade --plan open-large
  ($1,000 one-time payment)

For models over 10B parameters (closed source):
  ion upgrade --plan enterprise
  ($2,000 per billion parameters)"""

    elif plan == "closed":
        return """For models over 10B parameters:
  ion upgrade --plan enterprise
  ($2,000 per billion parameters)"""

    elif plan == "open-large":
        return """To keep your model weights private:
  ion upgrade --plan enterprise
  ($2,000 per billion parameters)"""

    elif plan == "enterprise":
        return "Contact enterprise@iontokenizer.com for plan modifications."

    return ""


def sync_pending():
    """Sync any pending registrations/tokenizers with server."""
    import click

    pending = _load_pending_sync()
    reg_synced = 0
    tok_synced = 0

    # Sync registrations
    remaining_regs = []
    for reg in pending.get("registrations", []):
        resp = _post_json(f"{ION_BASE_URL}/api/register", reg)
        if resp and resp.get("success"):
            reg_synced += 1
            # Update local config with server user_id if needed
            config = load_config()
            if config and config.get("user_id", "").startswith("usr_local_"):
                config["user_id"] = resp.get("user_id", config["user_id"])
                save_config(config)
        else:
            remaining_regs.append(reg)

    # Sync tokenizers
    remaining_toks = []
    for tok in pending.get("tokenizers", []):
        resp = _post_json(f"{ION_BASE_URL}/api/tokenizer/create", tok)
        if resp and resp.get("success"):
            tok_synced += 1
        else:
            remaining_toks.append(tok)

    pending["registrations"] = remaining_regs
    pending["tokenizers"] = remaining_toks
    _save_pending_sync(pending)

    click.echo("━" * 64)
    click.echo(f"  Syncing with iontokenizer.com...")
    click.echo("━" * 64)
    click.echo()

    if reg_synced:
        click.echo(f"  ✓ {reg_synced} registration(s) synced")
    if tok_synced:
        click.echo(f"  ✓ {tok_synced} tokenizer(s) synced")

    if not reg_synced and not tok_synced:
        if remaining_regs or remaining_toks:
            click.echo(f"  ⚠ Could not reach server. {len(remaining_regs)} registration(s) and {len(remaining_toks)} tokenizer(s) still pending.")
        else:
            click.echo("  All caught up!")
    else:
        if remaining_regs or remaining_toks:
            click.echo(f"  ⚠ {len(remaining_regs) + len(remaining_toks)} item(s) still pending.")
        else:
            click.echo()
            click.echo("  All caught up!")

    click.echo("━" * 64)


def get_license_info_display(config: dict) -> str:
    """Format license info for display."""
    plan = config.get("plan", "unknown")
    plan_display = PLAN_NAMES.get(plan, plan)

    lines = []
    lines.append("━" * 64)
    lines.append("  Ion Tokenizer License")
    lines.append("━" * 64)
    lines.append("")
    lines.append(f"  Email:       {config.get('email', 'N/A')}")
    lines.append(f"  Plan:        {plan_display}")
    lines.append(f"  Registered:  {config.get('registered_at', 'N/A')[:10]}")
    lines.append(f"  User ID:     {config.get('user_id', 'N/A')}")
    lines.append("")

    # Terms summary
    lines.append("  Terms:")
    if plan == "free":
        lines.append("  • Models <10B parameters")
        lines.append("  • Must open source weights within 7 days of public deployment")
    elif plan == "closed":
        lines.append("  • Models <10B parameters")
        lines.append("  • Keep weights private, commercial use allowed")
    elif plan == "open-large":
        lines.append("  • Models of any size")
        lines.append("  • Must open source weights within 7 days of public deployment")
    elif plan == "enterprise":
        lines.append("  • Models of any size")
        lines.append("  • Keep weights private, commercial use allowed")

    lines.append("")
    lines.append("  Upgrade options:")
    if plan == "free":
        lines.append("  • ion upgrade --plan closed      ($100 — keep weights private)")
        lines.append("  • ion upgrade --plan open-large  ($1,000 — models ≥10B, open source)")
        lines.append("  • ion upgrade --plan enterprise  ($2K/B — models ≥10B, closed)")
    elif plan == "closed":
        lines.append("  • ion upgrade --plan enterprise  ($2K/B — models ≥10B)")
    elif plan == "open-large":
        lines.append("  • ion upgrade --plan enterprise  ($2K/B — keep weights private)")
    elif plan == "enterprise":
        lines.append("  • Contact enterprise@iontokenizer.com for plan modifications")

    lines.append("")
    lines.append("━" * 64)
    return "\n".join(lines)


def get_tokenizer_license_display(tokenizer_path: str) -> str:
    """Display license info from a tokenizer.json file."""
    import orjson

    path = Path(tokenizer_path)
    if not path.exists():
        return f"  ✗ File not found: {tokenizer_path}"

    data = orjson.loads(path.read_bytes())
    ion_license = data.get("ion_license", {})

    if not ion_license:
        return "  ⚠ No license metadata found in this tokenizer."

    plan = ion_license.get("plan", "unknown")
    plan_display = PLAN_NAMES.get(plan, plan)

    # Check for LICENSE.md alongside
    license_path = path.parent / "LICENSE.md"

    lines = []
    lines.append("━" * 64)
    lines.append("  Tokenizer License")
    lines.append("━" * 64)
    lines.append("")
    lines.append(f"  Tokenizer ID:  {ion_license.get('tokenizer_id', 'N/A')}")
    lines.append(f"  Plan:          {plan_display}")
    lines.append(f"  Created:       {ion_license.get('created_at', 'N/A')[:10]}")
    lines.append(f"  Vocab Size:    {data.get('vocab_size', 'N/A'):,}")
    lines.append("")
    if license_path.exists():
        lines.append(f"  License file:  {license_path}")
    lines.append("")
    lines.append("━" * 64)
    return "\n".join(lines)
