"""Phrase discovery using gensim Phrases and PMI-based scoring."""

import math
from collections import Counter
from typing import Iterator, Optional

try:
    from gensim.models.phrases import Phrases, ENGLISH_CONNECTOR_WORDS
except ImportError:
    from ion.compat.ion_phrases import Phrases, ENGLISH_CONNECTOR_WORDS
from tqdm import tqdm


class PhraseDiscoverer:
    """
    Discovers multi-word phrases from corpus using gensim Phrases.

    Uses PMI (Pointwise Mutual Information) for phrase scoring.
    Supports n-grams of length 2-5+.
    """

    def __init__(
        self,
        min_count: int = 10,
        threshold: float = 0.001,
        max_vocab_size: int = 20000,
        connector_words: frozenset = ENGLISH_CONNECTOR_WORDS,
        scoring: str = "default",
        max_layers: int = 4,
    ):
        self.min_count = min_count
        self.threshold = threshold
        self.max_vocab_size = max_vocab_size
        self.connector_words = connector_words
        self.scoring = scoring
        self.max_layers = max_layers
        self.phrase_models = []
        self.word_freq = Counter()
        self.phrase_freq = Counter()

    def _build_phrase_layer(
        self, sentences: list[list[str]], layer: int
    ) -> tuple[Phrases, list[list[str]]]:
        """Build one layer of phrase detection."""
        # More aggressive min_count decay for deeper layers
        layer_min_count = max(self.min_count // (2 ** layer), 2)
        # Threshold decays slower to maintain quality
        layer_threshold = self.threshold / (layer + 1)

        kwargs = {
            "min_count": layer_min_count,
            "threshold": layer_threshold,
            "connector_words": self.connector_words,
        }

        # Use NPMI scoring if requested (threshold must be -1 to 1)
        if self.scoring == "npmi":
            kwargs["scoring"] = "npmi"
            # NPMI threshold should be higher for quality (0.3-0.7 typical)
            kwargs["threshold"] = max(0.3 / (layer + 1), 0.1)

        model = Phrases(sentences, **kwargs)
        phraser = model.freeze()
        transformed = [phraser[sent] for sent in sentences]
        return model, transformed

    def discover(
        self, sentence_iter: Iterator[list[str]], max_sentences: int = 1_000_000
    ) -> dict[str, int]:
        """
        Discover phrases from sentence iterator.

        Returns dict mapping phrase -> frequency.
        """
        sentences = []
        for i, sent in enumerate(tqdm(sentence_iter, desc="Loading sentences")):
            sentences.append(sent)
            for token in sent:
                self.word_freq[token] += 1
            if i >= max_sentences - 1:
                break

        current_sentences = sentences
        all_phrases = Counter()
        prev_phrase_count = 0

        for layer in range(self.max_layers):
            model, transformed = self._build_phrase_layer(current_sentences, layer)
            self.phrase_models.append(model)

            for sent in transformed:
                for token in sent:
                    if "_" in token:
                        phrase = token.replace("_", " ")
                        all_phrases[phrase] += 1

            current_phrase_count = len(all_phrases)
            # Stop if no new phrases discovered
            if current_phrase_count == prev_phrase_count:
                break
            prev_phrase_count = current_phrase_count

            current_sentences = transformed

        self.phrase_freq = all_phrases
        return dict(all_phrases)

    def _is_quality_phrase(self, phrase: str) -> bool:
        """
        Filter out garbage phrases. A quality phrase:
        - Has 2-5 words (not too short, not full sentences)
        - Doesn't contain special tokens (<unk>, <pad>, etc.)
        - Doesn't start or end with punctuation
        - Contains at least one word with 3+ characters
        - Doesn't contain numbers only
        - Doesn't contain WikiText artifacts (@,@ etc.)
        """
        words = phrase.split()

        # Length filter: 2-5 words only
        if len(words) < 2 or len(words) > 5:
            return False

        # No special tokens
        if "<" in phrase or ">" in phrase:
            return False

        # No WikiText artifacts (@,@ @-@ @.@ = encoded punctuation in numbers)
        if "@" in phrase:
            return False

        # No phrases starting/ending with punctuation
        punct = '.,!?;:\'"()[]{}-'
        if phrase[0] in punct or phrase[-1] in punct:
            return False

        # At least one meaningful word (2+ chars for CJK/short languages, 3+ for Latin, not all digits)
        has_meaningful_word = False
        for word in words:
            # For CJK characters, even 1 char is meaningful
            if any(ord(c) > 0x2000 for c in word):
                has_meaningful_word = True
                break
            if len(word) >= 3 and not word.isdigit():
                has_meaningful_word = True
                break
        if not has_meaningful_word:
            return False

        # No all-numeric phrases
        if all(w.isdigit() for w in words):
            return False

        return True

    def get_phrases_by_frequency(self, min_freq: int = 5) -> list[tuple[str, int]]:
        """Get phrases sorted by frequency, filtered for quality."""
        return sorted(
            [(p, f) for p, f in self.phrase_freq.items()
             if f >= min_freq and self._is_quality_phrase(p)],
            key=lambda x: -x[1],
        )

    def select_phrases_for_vocab(
        self,
        sentences: list[list[str]],
        base_vocab_size: int,
        max_phrases: int,
    ) -> list[str]:
        """
        Select phrases that maximize sequence length reduction.

        Uses aggressive scoring optimized for maximum compression:
        - Total tokens saved: frequency * (phrase_length - 1)
        - Exponential length bonus: longer phrases compress more per vocab slot
        - Frequency weighting: ensures high-impact phrases are prioritized
        """
        # Use lower min_freq to get more candidate phrases
        phrases = self.get_phrases_by_frequency(min_freq=max(2, self.min_count // 2))

        phrase_scores = []
        for phrase, freq in phrases:
            n_tokens = len(phrase.split())
            # Total tokens saved across all occurrences
            tokens_saved = (n_tokens - 1) * freq
            # Exponential bonus for longer phrases (2^(n-2) for n>2)
            # This heavily favors 4-grams over 3-grams over 2-grams
            length_bonus = 2.0 ** max(0, n_tokens - 2)
            # Frequency density: prefer phrases that appear often
            freq_density = freq ** 0.5
            # Final score: aggressive compression priority
            score = tokens_saved * length_bonus * freq_density
            phrase_scores.append((phrase, score, freq, n_tokens, tokens_saved))

        # Sort by score descending
        phrase_scores.sort(key=lambda x: -x[1])

        available_slots = self.max_vocab_size - base_vocab_size
        selected = []
        selected_set = set()
        total_tokens_saved = 0

        for phrase, score, freq, n_tokens, tokens_saved in phrase_scores:
            if len(selected) >= min(max_phrases, available_slots):
                break
            if score > 0 and phrase not in selected_set:
                # Check for subphrase conflicts - prefer longer phrases
                words = phrase.split()
                skip = False
                # If a longer phrase containing this one is already selected, skip
                for existing in selected:
                    if phrase in existing and phrase != existing:
                        skip = True
                        break
                if skip:
                    continue
                selected.append(phrase)
                selected_set.add(phrase)
                total_tokens_saved += tokens_saved

        return selected


class EmbeddingPhraseScorer:
    """
    Learned phrase scoring using word embeddings.

    Scores phrase candidates by semantic coherence — how much meaning is
    captured by treating the phrase as a single unit vs its component words.

    Uses Word2Vec embeddings trained on the same corpus. Phrases where the
    combined meaning is more than the sum of parts get higher scores.

    Scoring approach:
    1. Train Word2Vec on the corpus (fast, lightweight)
    2. For each phrase candidate, compute:
       - Compositional vector: average of component word vectors
       - Phrase context similarity: how often the phrase appears in similar contexts
       - Coherence score: cosine similarity between compositional vector and
         the phrase's actual context vector
    3. Combine with frequency for final ranking
    """

    def __init__(
        self,
        vector_size: int = 100,
        window: int = 5,
        min_count: int = 5,
        workers: int = 1,
        coherence_weight: float = 0.4,
        frequency_weight: float = 0.3,
        pmi_weight: float = 0.3,
    ):
        """
        Args:
            vector_size: Dimensionality of word vectors.
            window: Context window size for Word2Vec.
            min_count: Minimum word frequency for Word2Vec vocabulary.
            workers: Number of workers for training.
            coherence_weight: Weight for semantic coherence score (0-1).
            frequency_weight: Weight for frequency-based score (0-1).
            pmi_weight: Weight for PMI-based score (0-1).
        """
        self.vector_size = vector_size
        self.window = window
        self.min_count = min_count
        self.workers = workers
        self.coherence_weight = coherence_weight
        self.frequency_weight = frequency_weight
        self.pmi_weight = pmi_weight

        self._model = None
        self._word_freq = Counter()
        self._total_words = 0
        self._trained = False

    def train(self, sentences: list[list[str]]):
        """
        Train Word2Vec embeddings on the corpus.

        Args:
            sentences: List of tokenized sentences (same format as PhraseDiscoverer).
        """
        try:
            from gensim.models import Word2Vec
        except ImportError:
            try:
                from ion.compat.ion_embeddings import Word2Vec
            except ImportError:
                self._trained = False
                return

        # Count word frequencies
        for sent in sentences:
            for word in sent:
                self._word_freq[word] += 1
                self._total_words += 1

        # Train Word2Vec
        self._model = Word2Vec(
            sentences=sentences,
            vector_size=self.vector_size,
            window=self.window,
            min_count=self.min_count,
            workers=self.workers,
            epochs=5,
            seed=42,
        )
        self._trained = True

    def score_phrase(self, phrase: str, phrase_freq: int) -> float:
        """
        Score a phrase candidate using embedding-based coherence.

        Returns a combined score (higher = better phrase candidate).

        Components:
        1. Coherence: cosine similarity between the phrase's component
           word vectors and the phrase's actual usage context.
        2. Frequency: normalized log frequency.
        3. PMI: pointwise mutual information of the component words.
        """
        words = phrase.split()
        if len(words) < 2:
            return 0.0

        coherence = self._compute_coherence(words)
        freq_score = self._compute_frequency_score(phrase_freq)
        pmi_score = self._compute_pmi(words)

        return (
            self.coherence_weight * coherence +
            self.frequency_weight * freq_score +
            self.pmi_weight * pmi_score
        )

    def _compute_coherence(self, words: list[str]) -> float:
        """
        Compute semantic coherence of a multi-word phrase.

        Measures how semantically tight the phrase is — high coherence means
        the words belong together as a unit.

        Uses average pairwise cosine similarity between word vectors.
        """
        if not self._trained or self._model is None:
            return 0.5  # neutral if no model

        vectors = []
        for word in words:
            if word in self._model.wv:
                vectors.append(self._model.wv[word])

        if len(vectors) < 2:
            return 0.3  # low coherence if words not in vocabulary

        # Average pairwise cosine similarity
        total_sim = 0.0
        pairs = 0
        for i in range(len(vectors)):
            for j in range(i + 1, len(vectors)):
                sim = self._cosine_similarity(vectors[i], vectors[j])
                total_sim += sim
                pairs += 1

        if pairs == 0:
            return 0.3

        avg_sim = total_sim / pairs
        # Normalize to 0-1 range (cosine sim is -1 to 1)
        return (avg_sim + 1.0) / 2.0

    def _compute_frequency_score(self, freq: int) -> float:
        """Compute normalized log frequency score (0-1)."""
        if freq <= 0 or self._total_words <= 0:
            return 0.0
        # Log frequency normalized by corpus size
        log_freq = math.log(freq + 1)
        log_max = math.log(self._total_words + 1)
        return min(log_freq / log_max, 1.0)

    def _compute_pmi(self, words: list[str]) -> float:
        """
        Compute normalized PMI for the phrase.

        PMI = log(P(phrase) / product(P(word_i)))
        Normalized to 0-1 range.
        """
        if self._total_words <= 0:
            return 0.0

        # Joint probability estimate (use product of individual probs as baseline)
        log_product = 0.0
        for word in words:
            freq = self._word_freq.get(word, 0)
            if freq == 0:
                return 0.0
            log_product += math.log(freq / self._total_words)

        # If we can't get the joint frequency directly, estimate from co-occurrence
        # Use a simplified approximation based on word frequencies
        min_freq = min(self._word_freq.get(w, 0) for w in words)
        if min_freq == 0:
            return 0.0

        log_joint = math.log(min_freq / self._total_words)

        # PMI = log(P(joint)) - log(product(P(individual)))
        pmi = log_joint - log_product

        # Normalize to 0-1 (typical PMI range is -10 to 10)
        normalized = (pmi + 10.0) / 20.0
        return max(0.0, min(1.0, normalized))

    @staticmethod
    def _cosine_similarity(v1, v2) -> float:
        """Compute cosine similarity between two vectors."""
        import numpy as np
        dot = np.dot(v1, v2)
        norm1 = np.linalg.norm(v1)
        norm2 = np.linalg.norm(v2)
        if norm1 == 0 or norm2 == 0:
            return 0.0
        return float(dot / (norm1 * norm2))

    def score_phrases(
        self,
        phrases_with_freq: list[tuple[str, int]],
        top_k: Optional[int] = None,
    ) -> list[tuple[str, float, dict]]:
        """
        Score and rank a list of phrase candidates.

        Args:
            phrases_with_freq: List of (phrase, frequency) tuples.
            top_k: If set, return only top K phrases.

        Returns:
            List of (phrase, combined_score, detail_dict) sorted by score descending.
        """
        results = []
        for phrase, freq in phrases_with_freq:
            words = phrase.split()
            coherence = self._compute_coherence(words)
            freq_score = self._compute_frequency_score(freq)
            pmi_score = self._compute_pmi(words)

            combined = (
                self.coherence_weight * coherence +
                self.frequency_weight * freq_score +
                self.pmi_weight * pmi_score
            )

            results.append((phrase, combined, {
                "coherence": round(coherence, 4),
                "frequency": round(freq_score, 4),
                "pmi": round(pmi_score, 4),
                "raw_freq": freq,
                "n_words": len(words),
            }))

        results.sort(key=lambda x: -x[1])

        if top_k:
            results = results[:top_k]

        return results

    def is_trained(self) -> bool:
        """Return whether the model has been trained."""
        return self._trained
