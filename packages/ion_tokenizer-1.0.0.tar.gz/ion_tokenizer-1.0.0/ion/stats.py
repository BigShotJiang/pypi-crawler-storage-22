"""Statistics computation for tokenizer analysis."""

from pathlib import Path
from typing import Optional

import orjson
from tqdm import tqdm

from .corpus import load_corpus
from .tokenizer import IonTokenizer


def load_tokenizer(path: str = "tokenizer.json") -> IonTokenizer:
    """Load tokenizer from JSON file."""
    data = orjson.loads(Path(path).read_bytes())
    return IonTokenizer.from_dict(data)


def compute_stats(
    tokenizer_path: str = "tokenizer.json",
    corpus_source: Optional[str] = None,
    hf_split: str = "train",
    hf_text_field: str = "text",
    max_samples: int = 10000,
    hf_config: Optional[str] = None,
) -> dict:
    """
    Compute tokenizer statistics.

    Args:
        tokenizer_path: Path to tokenizer.json
        corpus_source: Optional corpus to test against
        hf_split: HuggingFace dataset split
        hf_text_field: HuggingFace dataset text field
        max_samples: Maximum samples for testing
        hf_config: HuggingFace dataset config name

    Returns:
        Statistics dictionary
    """
    data = orjson.loads(Path(tokenizer_path).read_bytes())
    tokenizer = IonTokenizer.from_dict(data)

    stats = {
        "vocab_size": data["vocab_size"],
        "special_tokens": len(data["token_classes"]["special"]),
        "phrase_tokens": len(data["token_classes"]["phrase"]),
        "word_tokens": len(data["token_classes"]["word"]),
        "fallback_tokens": len(data["token_classes"]["fallback"]),
    }

    if corpus_source:
        original_tokens = 0
        compressed_tokens = 0
        sentence_count = 0

        sentence_iter = load_corpus(
            corpus_source,
            hf_split=hf_split,
            hf_text_field=hf_text_field,
            max_samples=max_samples,
            hf_config=hf_config,
        )

        for sent in tqdm(sentence_iter, desc="Analyzing corpus"):
            text = " ".join(sent)
            original_tokens += len(sent)
            encoded = tokenizer.encode(text)
            compressed_tokens += len(encoded)
            sentence_count += 1
            if sentence_count >= max_samples:
                break

        stats["corpus_source"] = corpus_source
        stats["sentences_analyzed"] = sentence_count
        stats["original_tokens"] = original_tokens
        stats["compressed_tokens"] = compressed_tokens

        if original_tokens > 0:
            reduction = (original_tokens - compressed_tokens) / original_tokens * 100
            stats["sequence_length_reduction_pct"] = round(reduction, 2)
            stats["compression_ratio"] = round(
                original_tokens / max(compressed_tokens, 1), 2
            )
        else:
            stats["sequence_length_reduction_pct"] = 0.0
            stats["compression_ratio"] = 1.0

    return stats


def format_stats(stats: dict) -> str:
    """Format statistics for display."""
    lines = [
        "Ion Tokenizer Statistics",
        "=" * 40,
        "",
        "Vocabulary Composition:",
        f"  Total vocab size:    {stats['vocab_size']:,}",
        f"  Special tokens:      {stats['special_tokens']:,}",
        f"  Phrase tokens:       {stats['phrase_tokens']:,}",
        f"  Word tokens:         {stats['word_tokens']:,}",
        f"  Fallback tokens:     {stats['fallback_tokens']:,}",
    ]

    if "corpus_source" in stats:
        lines.extend([
            "",
            "Compression Analysis:",
            f"  Corpus:              {stats['corpus_source']}",
            f"  Sentences analyzed:  {stats['sentences_analyzed']:,}",
            f"  Original tokens:     {stats['original_tokens']:,}",
            f"  Compressed tokens:   {stats['compressed_tokens']:,}",
            f"  Reduction:           {stats['sequence_length_reduction_pct']:.2f}%",
            f"  Compression ratio:   {stats['compression_ratio']:.2f}x",
        ])

    return "\n".join(lines)
