"""Deterministic greedy longest-match tokenizer with hybrid BPE fallback."""

import re
from collections import Counter, defaultdict
from typing import Optional, Any


FALLBACK_ALPHABET = list(
    "abcdefghijklmnopqrstuvwxyz"
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    "0123456789"
    ".,!?;:'\"-()[]{}@#$%^&*+=<>/\\|`~_ \t\n"
)

# Extended alphabet for multilingual and code support
EXTENDED_ALPHABET = list(
    "abcdefghijklmnopqrstuvwxyz"
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    "0123456789"
    ".,!?;:'\"-()[]{}@#$%^&*+=<>/\\|`~_ \t\n"
    # Accented Latin characters (Western European languages)
    "\u00e0\u00e1\u00e2\u00e3\u00e4\u00e5\u00e6\u00e7\u00e8\u00e9\u00ea\u00eb\u00ec\u00ed\u00ee\u00ef"
    "\u00f0\u00f1\u00f2\u00f3\u00f4\u00f5\u00f6\u00f8\u00f9\u00fa\u00fb\u00fc\u00fd\u00fe\u00ff"
    "\u00c0\u00c1\u00c2\u00c3\u00c4\u00c5\u00c6\u00c7\u00c8\u00c9\u00ca\u00cb\u00cc\u00cd\u00ce\u00cf"
    "\u00d0\u00d1\u00d2\u00d3\u00d4\u00d5\u00d6\u00d8\u00d9\u00da\u00db\u00dc\u00dd\u00de"
    # Common CJK punctuation and symbols
    "\u3001\u3002\uff0c\uff0e\uff01\uff1f\u300c\u300d\u300e\u300f\u3010\u3011"
    # Cyrillic basic (Russian)
    "\u0410\u0411\u0412\u0413\u0414\u0415\u0416\u0417\u0418\u0419\u041a\u041b\u041c\u041d\u041e\u041f"
    "\u0420\u0421\u0422\u0423\u0424\u0425\u0426\u0427\u0428\u0429\u042a\u042b\u042c\u042d\u042e\u042f"
    "\u0430\u0431\u0432\u0433\u0434\u0435\u0436\u0437\u0438\u0439\u043a\u043b\u043c\u043d\u043e\u043f"
    "\u0440\u0441\u0442\u0443\u0444\u0445\u0446\u0447\u0448\u0449\u044a\u044b\u044c\u044d\u044e\u044f"
    # Common Arabic letters
    "\u0627\u0628\u062a\u062b\u062c\u062d\u062e\u062f\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637"
    "\u0638\u0639\u063a\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0648\u064a"
    # Hindi/Devanagari common characters
    "\u0905\u0906\u0907\u0908\u0909\u090a\u090b\u090f\u0910\u0913\u0914"
    "\u0915\u0916\u0917\u0918\u0919\u091a\u091b\u091c\u091d\u091e\u091f\u0920\u0921\u0922\u0923\u0924\u0925\u0926\u0927\u0928"
    "\u092a\u092b\u092c\u092d\u092e\u092f\u0930\u0932\u0935\u0936\u0937\u0938\u0939"
    "\u093e\u093f\u0940\u0941\u0942\u0947\u0948\u094b\u094c\u094d"
    # Thai characters
    "\u0e01\u0e02\u0e03\u0e04\u0e05\u0e06\u0e07\u0e08\u0e09\u0e0a\u0e0b\u0e0c\u0e0d\u0e0e\u0e0f"
    "\u0e10\u0e11\u0e12\u0e13\u0e14\u0e15\u0e16\u0e17\u0e18\u0e19\u0e1a\u0e1b\u0e1c\u0e1d\u0e1e\u0e1f"
    "\u0e20\u0e21\u0e22\u0e23\u0e24\u0e25\u0e26\u0e27\u0e28\u0e29\u0e2a\u0e2b\u0e2c\u0e2d\u0e2e"
    "\u0e30\u0e31\u0e32\u0e33\u0e34\u0e35\u0e36\u0e37\u0e38\u0e39\u0e3a"
    # Vietnamese diacritics (additional to Latin)
    "\u01a0\u01a1\u01af\u01b0\u0110\u0111"
    # Korean Hangul common syllables (Jamo)
    "\u3131\u3132\u3134\u3137\u3138\u3139\u3141\u3142\u3143\u3145\u3146\u3147\u3148\u3149\u314a\u314b\u314c\u314d\u314e"
    "\u314f\u3150\u3151\u3152\u3153\u3154\u3155\u3156\u3157\u3158\u3159\u315a\u315b\u315c\u315d\u315e\u315f\u3160\u3161\u3162\u3163"
)

SPECIAL_TOKENS = ["<pad>", "<unk>", "<bos>", "<eos>"]

# License plan tokens — injected at position 4 during tokenizer creation
PLAN_TOKENS = [
    "<ion-tokenizer-free>",
    "<ion-tokenizer-closed>",
    "<ion-tokenizer-open-large>",
    "<ion-tokenizer-enterprise>",
]


class TypoCorrector:
    """
    Edit-distance based typo correction layer.

    Before tokenization, checks if an unknown word has a close match in the
    vocabulary. If so, maps the misspelling to the canonical token, saving
    tokens and preventing vocabulary bloat in newword mode.

    Uses a BK-tree-inspired approach with precomputed deletion neighborhoods
    for O(1) average lookup of edit-distance-1 candidates.
    """

    def __init__(self, max_edit_distance: int = 2, min_word_length: int = 4):
        """
        Args:
            max_edit_distance: Maximum edit distance for corrections (1 or 2).
            min_word_length: Minimum word length to attempt correction on.
                Short words have too many collisions at distance 1.
        """
        self.max_edit_distance = min(max_edit_distance, 2)  # Cap at 2
        self.min_word_length = min_word_length
        self._delete_index: dict[str, set[str]] = defaultdict(set)
        self._vocab_words: set[str] = set()
        self._correction_cache: dict[str, Optional[str]] = {}
        self._stats = Counter()  # Track corrections made

    def build_index(self, words: list[str]):
        """Build the deletion neighborhood index from vocabulary words."""
        self._vocab_words = set(words)
        self._delete_index.clear()
        self._correction_cache.clear()
        self._stats.clear()

        for word in words:
            if len(word) < 2:
                continue
            # Index the word itself
            self._delete_index[word].add(word)
            # Index all deletions at distance 1
            for deletion in self._deletions(word):
                self._delete_index[deletion].add(word)
            # Index all deletions at distance 2
            if self.max_edit_distance >= 2:
                for d1 in self._deletions(word):
                    for d2 in self._deletions(d1):
                        self._delete_index[d2].add(word)

    def _deletions(self, word: str) -> list[str]:
        """Generate all single-character deletions of a word."""
        return [word[:i] + word[i+1:] for i in range(len(word))]

    def correct(self, word: str) -> Optional[str]:
        """
        Find the best correction for a misspelled word.

        Returns the canonical word if a match is found within max_edit_distance,
        or None if no correction is found.

        Tie-breaking: shortest edit distance first, then longest word, then
        alphabetical order (deterministic).
        """
        # Skip short words (too many false positives)
        if len(word) < self.min_word_length:
            return None

        # Check cache
        if word in self._correction_cache:
            return self._correction_cache[word]

        # Already in vocab — no correction needed
        if word in self._vocab_words:
            self._correction_cache[word] = None
            return None

        # Collect candidates at each edit distance
        best = None
        best_dist = self.max_edit_distance + 1

        # Check distance 1 candidates
        candidates_d1 = set()
        for d in self._deletions(word):
            candidates_d1.update(self._delete_index.get(d, set()))
        # Also check if word itself is a deletion of a vocab word
        candidates_d1.update(self._delete_index.get(word, set()))

        for candidate in candidates_d1:
            if candidate == word:
                continue
            dist = self._edit_distance(word, candidate, self.max_edit_distance)
            if dist <= self.max_edit_distance and dist < best_dist:
                best_dist = dist
                best = candidate
            elif dist == best_dist and best is not None:
                # Tie-break: prefer longer word, then alphabetical
                if len(candidate) > len(best) or (len(candidate) == len(best) and candidate < best):
                    best = candidate

        # Distance 2: check deletions of deletions
        if best_dist > 1 and self.max_edit_distance >= 2:
            candidates_d2 = set()
            for d1 in self._deletions(word):
                for d2 in self._deletions(d1):
                    candidates_d2.update(self._delete_index.get(d2, set()))

            for candidate in candidates_d2:
                if candidate == word:
                    continue
                dist = self._edit_distance(word, candidate, 2)
                if dist <= 2 and dist < best_dist:
                    best_dist = dist
                    best = candidate
                elif dist == best_dist and best is not None:
                    if len(candidate) > len(best) or (len(candidate) == len(best) and candidate < best):
                        best = candidate

        self._correction_cache[word] = best
        if best:
            self._stats[f"{word}->{best}"] += 1
        return best

    @staticmethod
    def _edit_distance(s1: str, s2: str, max_dist: int = 2) -> int:
        """
        Compute Levenshtein edit distance with early termination.

        Returns the edit distance, or max_dist+1 if it exceeds max_dist.
        """
        len1, len2 = len(s1), len(s2)
        # Quick length check
        if abs(len1 - len2) > max_dist:
            return max_dist + 1

        if len1 > len2:
            s1, s2 = s2, s1
            len1, len2 = len2, len1

        # Use single-row DP for space efficiency
        prev_row = list(range(len1 + 1))
        for j in range(1, len2 + 1):
            curr_row = [j] + [0] * len1
            min_val = j
            for i in range(1, len1 + 1):
                cost = 0 if s1[i-1] == s2[j-1] else 1
                curr_row[i] = min(
                    curr_row[i-1] + 1,      # insertion
                    prev_row[i] + 1,         # deletion
                    prev_row[i-1] + cost,    # substitution
                )
                if curr_row[i] < min_val:
                    min_val = curr_row[i]
            # Early termination
            if min_val > max_dist:
                return max_dist + 1
            prev_row = curr_row

        return prev_row[len1]

    def get_stats(self) -> dict:
        """Return correction statistics."""
        return {
            "total_corrections": sum(self._stats.values()),
            "unique_corrections": len(self._stats),
            "top_corrections": self._stats.most_common(20),
            "vocab_size": len(self._vocab_words),
            "index_size": len(self._delete_index),
        }


class StreamingPhraseDiscovery:
    """
    Online phrase discovery that learns new phrases during encoding.

    Tracks bigram co-occurrence counts in a sliding window and promotes
    frequent bigrams to phrases when they exceed a configurable threshold.
    New phrases are inserted into the tokenizer's trie in real-time.

    Uses exponential decay to favor recent patterns over stale ones.
    """

    def __init__(
        self,
        min_count: int = 10,
        promotion_threshold: float = 0.5,
        decay_rate: float = 0.999,
        max_new_phrases: int = 5000,
        min_word_length: int = 2,
    ):
        """
        Args:
            min_count: Minimum co-occurrence count before considering promotion.
            promotion_threshold: PMI-like score threshold for promotion.
                Higher = more conservative (fewer but higher-quality phrases).
            decay_rate: Exponential decay applied to counts each encoding step.
                0.999 = slow decay (long memory), 0.99 = fast decay (recent bias).
            max_new_phrases: Maximum number of new phrases to discover.
            min_word_length: Minimum word length for phrase components.
        """
        self.min_count = min_count
        self.promotion_threshold = promotion_threshold
        self.decay_rate = decay_rate
        self.max_new_phrases = max_new_phrases
        self.min_word_length = min_word_length

        self.bigram_counts: Counter = Counter()
        self.unigram_counts: Counter = Counter()
        self.total_bigrams: float = 0.0
        self.total_unigrams: float = 0.0
        self._discovered_phrases: list[str] = []
        self._discovered_set: set[str] = set()
        self._step_count: int = 0
        self._enabled: bool = True
        self._stats = {
            "phrases_discovered": 0,
            "bigrams_tracked": 0,
            "encoding_steps": 0,
        }

    def observe(self, tokens: list[str]):
        """
        Observe a sequence of tokens and update co-occurrence counts.

        Call this after tokenizing each piece of text to track patterns.
        """
        if not self._enabled:
            return

        self._step_count += 1

        # Apply exponential decay periodically (every 100 steps for perf)
        if self._step_count % 100 == 0:
            decay = self.decay_rate ** 100
            for key in list(self.bigram_counts.keys()):
                self.bigram_counts[key] *= decay
                if self.bigram_counts[key] < 0.5:
                    del self.bigram_counts[key]
            for key in list(self.unigram_counts.keys()):
                self.unigram_counts[key] *= decay
                if self.unigram_counts[key] < 0.5:
                    del self.unigram_counts[key]
            self.total_bigrams *= decay
            self.total_unigrams *= decay

        # Count unigrams
        for tok in tokens:
            if len(tok) >= self.min_word_length and tok.isalpha():
                self.unigram_counts[tok] += 1
                self.total_unigrams += 1

        # Count bigrams
        for i in range(len(tokens) - 1):
            w1, w2 = tokens[i], tokens[i + 1]
            if (len(w1) >= self.min_word_length and w1.isalpha() and
                    len(w2) >= self.min_word_length and w2.isalpha()):
                bigram = f"{w1} {w2}"
                self.bigram_counts[bigram] += 1
                self.total_bigrams += 1

        self._stats["bigrams_tracked"] = len(self.bigram_counts)
        self._stats["encoding_steps"] = self._step_count

    def check_promotions(self) -> list[str]:
        """
        Check for bigrams ready to be promoted to phrases.

        Returns list of newly discovered phrases (if any).
        """
        if not self._enabled or len(self._discovered_phrases) >= self.max_new_phrases:
            self._enabled = False
            return []

        new_phrases = []

        for bigram, count in self.bigram_counts.most_common(100):
            if bigram in self._discovered_set:
                continue
            if count < self.min_count:
                break  # sorted by count, so we can stop early

            # Compute PMI-like score
            w1, w2 = bigram.split(" ", 1)
            c1 = self.unigram_counts.get(w1, 0)
            c2 = self.unigram_counts.get(w2, 0)

            if c1 == 0 or c2 == 0 or self.total_bigrams == 0:
                continue

            # PMI score: log(P(w1,w2) / (P(w1) * P(w2)))
            # Simplified to: count * total / (c1 * c2) — skip log for speed
            pmi_score = (count * self.total_unigrams * self.total_unigrams) / (
                c1 * c2 * self.total_bigrams
            )

            if pmi_score >= self.promotion_threshold:
                self._discovered_phrases.append(bigram)
                self._discovered_set.add(bigram)
                new_phrases.append(bigram)
                self._stats["phrases_discovered"] += 1

                if len(self._discovered_phrases) >= self.max_new_phrases:
                    self._enabled = False
                    break

        return new_phrases

    def get_discovered_phrases(self) -> list[str]:
        """Return all phrases discovered so far."""
        return list(self._discovered_phrases)

    def get_stats(self) -> dict:
        """Return discovery statistics."""
        return dict(self._stats)

    def reset(self):
        """Reset all state."""
        self.bigram_counts.clear()
        self.unigram_counts.clear()
        self.total_bigrams = 0.0
        self.total_unigrams = 0.0
        self._discovered_phrases.clear()
        self._discovered_set.clear()
        self._step_count = 0
        self._enabled = True
        self._stats = {
            "phrases_discovered": 0,
            "bigrams_tracked": 0,
            "encoding_steps": 0,
        }


class IonTokenizer:
    """
    Greedy longest-match tokenizer with hybrid fallback.

    Token priority (phrase-first architecture):
    1. Phrase tokens (multi-word expressions)
    2. Word tokens (single words)
    3. BPE subword tokens (graceful degradation)
    4. Character tokens (last resort)

    This hierarchy ensures Ion is *strictly better* than BPE:
    - On phrase-stable text: captures phrases BPE would fragment
    - On open-domain text: degrades gracefully to BPE-level performance
    """

    def __init__(
        self,
        phrases: list[str],
        words: list[str],
        fallback_chars: list[str] = FALLBACK_ALPHABET,
        fallback_mode: str = "bpe",  # "character", "word", "bpe", or "newword" (default: bpe for production)
        bpe_tokenizer: Any = None,  # Pre-trained BPE tokenizer (HuggingFace tokenizers.Tokenizer)
        preserve_case: bool = False,  # If True, don't lowercase during tokenization
        plan_token: Optional[str] = None,  # License plan token e.g. "<ion-tokenizer-free>"
    ):
        self.vocab = {}
        self.id_to_token = {}
        self.token_classes = {
            "special": [],
            "phrase": [],
            "word": [],
            "bpe_subword": [],  # New class for BPE subwords
            "fallback": [],
        }
        self.fallback_mode = fallback_mode
        self._bpe_tokenizer = bpe_tokenizer
        self._bpe_vocab_added = False
        self.preserve_case = preserve_case
        self.max_word_length = 0  # 0 = disabled; set via builder or directly
        self.plan_token = plan_token

        # Typo correction layer (disabled by default)
        self._typo_corrector: Optional[TypoCorrector] = None
        self._typo_correction_enabled = False

        # Streaming phrase discovery (disabled by default)
        self._streaming_discovery: Optional[StreamingPhraseDiscovery] = None
        self._streaming_enabled = False
        self._manually_added_phrases: list[str] = []
        self._streaming_check_interval = 50  # Check for promotions every N encodes
        self._encode_count = 0

        token_id = 0

        for tok in SPECIAL_TOKENS:
            self.vocab[tok] = token_id
            self.id_to_token[token_id] = tok
            self.token_classes["special"].append(tok)
            token_id += 1

        # Inject plan token at position 4 (right after special tokens)
        if plan_token and plan_token in PLAN_TOKENS:
            self.vocab[plan_token] = token_id
            self.id_to_token[token_id] = plan_token
            self.token_classes["special"].append(plan_token)
            token_id += 1

        for phrase in sorted(phrases, key=lambda x: (-len(x.split()), x)):
            if phrase not in self.vocab:
                self.vocab[phrase] = token_id
                self.id_to_token[token_id] = phrase
                self.token_classes["phrase"].append(phrase)
                token_id += 1

        for word in sorted(words):
            if word not in self.vocab:
                self.vocab[word] = token_id
                self.id_to_token[token_id] = word
                self.token_classes["word"].append(word)
                token_id += 1

        for char in fallback_chars:
            char_tok = f"<{char}>"
            if char_tok not in self.vocab:
                self.vocab[char_tok] = token_id
                self.id_to_token[token_id] = char_tok
                self.token_classes["fallback"].append(char_tok)
                token_id += 1

        self._build_phrase_trie()
        self._next_dynamic_id = token_id  # For dynamic word additions

    def _build_phrase_trie(self):
        """Build trie for efficient phrase matching."""
        self.phrase_trie = {}
        for phrase in self.token_classes["phrase"]:
            words = phrase.split()
            node = self.phrase_trie
            for word in words:
                if word not in node:
                    node[word] = {}
                node = node[word]
            node["_end_"] = phrase

    def _match_phrase(self, tokens: list[str], start: int) -> Optional[tuple[str, int]]:
        """Try to match longest phrase starting at position."""
        node = self.phrase_trie
        matched_phrase = None
        matched_len = 0

        for i in range(start, len(tokens)):
            word = tokens[i]
            if word in node:
                node = node[word]
                if "_end_" in node:
                    matched_phrase = node["_end_"]
                    matched_len = i - start + 1
            else:
                break

        if matched_phrase:
            return (matched_phrase, matched_len)
        return None

    def _tokenize_word(self, word: str) -> list[int]:
        """
        Tokenize a single word using the configured fallback hierarchy.

        Fallback modes:
        - "bpe": word -> BPE subword -> character (recommended for production)
        - "newword": dynamically add unknown words to vocab (never fall back to BPE)
        - "character": word -> character
        - "word": word -> <unk>
        """
        # First, try exact word match
        if word in self.vocab:
            return [self.vocab[word]]

        # Typo correction: check if word is a misspelling of a known word
        if self._typo_correction_enabled and self._typo_corrector:
            corrected = self._typo_corrector.correct(word)
            if corrected and corrected in self.vocab:
                return [self.vocab[corrected]]

        # Handle based on fallback mode
        if self.fallback_mode == "bpe":
            # Use BPE subword tokenization (graceful degradation)
            return self._bpe_fallback(word)

        elif self.fallback_mode == "newword":
            # If word contains special (non-alphanumeric) characters, use BPE/character fallback
            if not word.isalnum() and not word.replace("'", "").replace("-", "").isalnum():
                return self._bpe_fallback(word)
            # If length limit is set and word exceeds it, fall back to BPE
            if self.max_word_length > 0 and len(word) > self.max_word_length:
                return self._bpe_fallback(word)
            # Dynamically add unknown words to vocab
            return self._newword_fallback(word)

        elif self.fallback_mode == "word":
            # Just return <unk> for unknown words
            return [self.vocab.get("<unk>", 1)]

        else:  # "character"
            # Character-level fallback
            return self._character_fallback(word)

    def set_bpe_tokenizer(self, bpe_tokenizer: Any, add_vocab: bool = True):
        """
        Set the BPE tokenizer for hybrid fallback.

        Args:
            bpe_tokenizer: A HuggingFace tokenizers.Tokenizer instance
            add_vocab: If True, add BPE vocabulary to Ion's vocab
        """
        self._bpe_tokenizer = bpe_tokenizer

        if add_vocab and bpe_tokenizer and not self._bpe_vocab_added:
            # Add BPE vocabulary to Ion's vocab for proper round-tripping
            bpe_vocab = bpe_tokenizer.get_vocab()
            for token, _ in sorted(bpe_vocab.items(), key=lambda x: x[1]):
                if token not in self.vocab and not token.startswith("["):
                    subword_tok = f"<bpe:{token}>"
                    self.vocab[subword_tok] = self._next_dynamic_id
                    self.id_to_token[self._next_dynamic_id] = subword_tok
                    self.token_classes["bpe_subword"].append(subword_tok)
                    self._next_dynamic_id += 1
            self._bpe_vocab_added = True

    def _bpe_fallback(self, word: str) -> list[int]:
        """Use BPE tokenization as fallback for unknown words."""
        # If no BPE tokenizer, fall back to character mode
        if self._bpe_tokenizer is None:
            return self._character_fallback(word)

        try:
            bpe_output = self._bpe_tokenizer.encode(word)
            result = []

            for token in bpe_output.tokens:
                # Skip special BPE tokens
                if token.startswith("[") and token.endswith("]"):
                    continue

                # Check if token exists directly in vocab (might be a word we know)
                if token.lower() in self.vocab:
                    result.append(self.vocab[token.lower()])
                else:
                    # Use BPE subword token
                    subword_tok = f"<bpe:{token}>"
                    if subword_tok in self.vocab:
                        result.append(self.vocab[subword_tok])
                    else:
                        # Dynamically add if not present
                        self.vocab[subword_tok] = self._next_dynamic_id
                        self.id_to_token[self._next_dynamic_id] = subword_tok
                        self.token_classes["bpe_subword"].append(subword_tok)
                        result.append(self._next_dynamic_id)
                        self._next_dynamic_id += 1

            return result if result else self._character_fallback(word)

        except Exception:
            # If BPE fails for any reason, fall back to character mode
            return self._character_fallback(word)

    def _newword_fallback(self, word: str) -> list[int]:
        """Dynamically add unknown word to vocab as a new word token."""
        self.vocab[word] = self._next_dynamic_id
        self.id_to_token[self._next_dynamic_id] = word
        self.token_classes["word"].append(word)
        result = [self._next_dynamic_id]
        self._next_dynamic_id += 1
        return result

    def _character_fallback(self, word: str) -> list[int]:
        """Character-level fallback (last resort)."""
        result = []
        for char in word:
            char_tok = f"<{char}>"
            if char_tok in self.vocab:
                result.append(self.vocab[char_tok])
            else:
                result.append(self.vocab.get("<unk>", 1))
        return result

    def set_fallback_mode(self, mode: str):
        """Set the fallback mode: 'character', 'word', 'bpe', or 'newword'."""
        if mode in ("character", "word", "bpe", "newword"):
            self.fallback_mode = mode
        else:
            raise ValueError(f"Invalid fallback mode: {mode}. Use 'character', 'word', 'bpe', or 'newword'.")

    def enable_typo_correction(
        self,
        max_edit_distance: int = 2,
        min_word_length: int = 4,
    ):
        """
        Enable the typo correction layer.

        Builds a deletion-neighborhood index from all words in the vocabulary.
        During encoding, unknown words are checked for close matches and
        corrected before fallback is applied.

        Args:
            max_edit_distance: Max edit distance for corrections (1 or 2).
            min_word_length: Min word length to attempt correction (avoid
                false positives on short words like "to" -> "go").
        """
        self._typo_corrector = TypoCorrector(
            max_edit_distance=max_edit_distance,
            min_word_length=min_word_length,
        )
        # Build index from all word-class tokens
        vocab_words = [w for w in self.token_classes["word"] if len(w) >= 2]
        self._typo_corrector.build_index(vocab_words)
        self._typo_correction_enabled = True

    def disable_typo_correction(self):
        """Disable the typo correction layer."""
        self._typo_correction_enabled = False
        self._typo_corrector = None

    def get_typo_stats(self) -> dict:
        """Return typo correction statistics."""
        if self._typo_corrector:
            return self._typo_corrector.get_stats()
        return {"total_corrections": 0, "unique_corrections": 0, "top_corrections": []}

    def enable_streaming_phrases(
        self,
        min_count: int = 10,
        promotion_threshold: float = 0.5,
        decay_rate: float = 0.999,
        max_new_phrases: int = 5000,
        check_interval: int = 50,
    ):
        """
        Enable streaming/online phrase discovery during encoding.

        As text is encoded, bigram co-occurrences are tracked. When a bigram
        exceeds the promotion threshold, it's automatically added as a phrase
        token and inserted into the trie.

        Args:
            min_count: Minimum bigram count before considering promotion.
            promotion_threshold: PMI-like score threshold (higher = stricter).
            decay_rate: Exponential decay for counts (0.999 = slow decay).
            max_new_phrases: Maximum number of new phrases to discover.
            check_interval: Check for promotions every N encode() calls.
        """
        self._streaming_discovery = StreamingPhraseDiscovery(
            min_count=min_count,
            promotion_threshold=promotion_threshold,
            decay_rate=decay_rate,
            max_new_phrases=max_new_phrases,
        )
        self._streaming_enabled = True
        self._streaming_check_interval = check_interval

    def disable_streaming_phrases(self):
        """Disable streaming phrase discovery."""
        self._streaming_enabled = False
        self._streaming_discovery = None

    def get_streaming_stats(self) -> dict:
        """Return streaming phrase discovery statistics."""
        if self._streaming_discovery:
            return self._streaming_discovery.get_stats()
        return {"phrases_discovered": 0, "bigrams_tracked": 0, "encoding_steps": 0}

    def get_streaming_phrases(self) -> list[str]:
        """Return all phrases discovered via streaming."""
        phrases = list(self._manually_added_phrases)
        if self._streaming_discovery:
            phrases.extend(self._streaming_discovery.get_discovered_phrases())
        return phrases

    def _add_streaming_phrase(self, phrase: str):
        """Add a phrase discovered by streaming to the tokenizer's vocab and trie."""
        if phrase in self.vocab:
            return
        self.vocab[phrase] = self._next_dynamic_id
        self.id_to_token[self._next_dynamic_id] = phrase
        self.token_classes["phrase"].append(phrase)
        self._manually_added_phrases.append(phrase)
        self._next_dynamic_id += 1
        # Update the trie
        words = phrase.split()
        node = self.phrase_trie
        for word in words:
            if word not in node:
                node[word] = {}
            node = node[word]
        node["_end_"] = phrase

    def _tokenize_text(self, text: str) -> list[str]:
        """Tokenize text, separating punctuation from words (matches training tokenization)."""
        if not self.preserve_case:
            text = text.lower()
        text = text.strip()
        text = re.sub(r'\s+', ' ', text)

        # Punctuation chars to separate (apostrophe excluded to keep
        # possessives and contractions intact, matching spaCy training tokenization)
        punct_chars = '.,!?;:\"()[]{}'

        # Split on whitespace first, then separate punctuation
        # This matches how spaCy tokenizes during training
        tokens = []
        for word in text.split():
            # Separate leading punctuation (strip leading apostrophes only
            # when they are not followed by an alphanumeric, i.e. quote marks)
            while word and word[0] in punct_chars:
                tokens.append(word[0])
                word = word[1:]
            while word and word[0:1] == "'" and (len(word) < 2 or not word[1].isalnum()):
                tokens.append(word[0])
                word = word[1:]
            # Separate trailing punctuation (strip trailing apostrophes only
            # when preceded by non-alphanumeric, i.e. closing quotes)
            trailing = []
            while word and word[-1] in punct_chars:
                trailing.insert(0, word[-1])
                word = word[:-1]
            while word and word[-1:] == "'" and (len(word) < 2 or not word[-2].isalnum()):
                trailing.insert(0, word[-1])
                word = word[:-1]
            # Add the word if anything remains
            if word:
                tokens.append(word)
            # Add trailing punctuation
            tokens.extend(trailing)

        return tokens

    def encode(self, text: str) -> list[int]:
        """Encode text to token IDs using greedy longest-match."""
        words = self._tokenize_text(text)
        if not words:
            return []

        result = []
        i = 0

        while i < len(words):
            match = self._match_phrase(words, i)
            if match:
                phrase, length = match
                result.append(self.vocab[phrase])
                i += length
            else:
                result.extend(self._tokenize_word(words[i]))
                i += 1

        # Streaming phrase discovery: observe tokens and check for promotions
        if self._streaming_enabled and self._streaming_discovery:
            self._streaming_discovery.observe(words)
            self._encode_count += 1
            if self._encode_count % self._streaming_check_interval == 0:
                new_phrases = self._streaming_discovery.check_promotions()
                for phrase in new_phrases:
                    self._add_streaming_phrase(phrase)

        return result

    def decode(self, ids: list[int]) -> str:
        """Decode token IDs back to text."""
        tokens = []
        for tid in ids:
            if tid in self.id_to_token:
                tok = self.id_to_token[tid]
                # Single character token: <a> -> a
                if tok.startswith("<") and tok.endswith(">") and len(tok) == 3:
                    tokens.append(tok[1])
                # BPE subword token: <bpe:xyz> -> xyz
                elif tok.startswith("<bpe:") and tok.endswith(">"):
                    tokens.append(tok[5:-1])
                # Skip special tokens and plan tokens
                elif tok in SPECIAL_TOKENS or tok in PLAN_TOKENS:
                    continue
                # Regular phrase or word token
                else:
                    tokens.append(tok)
        return " ".join(tokens)

    def vocab_size(self) -> int:
        """Return total vocabulary size."""
        return len(self.vocab)

    def to_dict(self) -> dict:
        """Export tokenizer to dictionary format (pure tokenizer data only)."""
        result = {
            "version": "3.0",
            "vocab_size": len(self.vocab),
            "fallback_mode": self.fallback_mode,
            "preserve_case": self.preserve_case,
            "max_word_length": self.max_word_length,
            "typo_correction": {
                "enabled": self._typo_correction_enabled,
                "max_edit_distance": self._typo_corrector.max_edit_distance if self._typo_corrector else 2,
                "min_word_length": self._typo_corrector.min_word_length if self._typo_corrector else 4,
            },
            "streaming_phrases": {
                "enabled": self._streaming_enabled,
                "discovered": self.get_streaming_phrases(),
            },
            "vocab": self.vocab,
            "token_classes": {
                "special": [
                    {"token": t, "id": self.vocab[t]}
                    for t in self.token_classes["special"]
                ],
                "phrase": [
                    {"token": t, "id": self.vocab[t]}
                    for t in self.token_classes["phrase"]
                ],
                "word": [
                    {"token": t, "id": self.vocab[t]}
                    for t in self.token_classes["word"]
                ],
                "bpe_subword": [
                    {"token": t, "id": self.vocab[t]}
                    for t in self.token_classes.get("bpe_subword", [])
                ],
                "fallback": [
                    {"token": t, "id": self.vocab[t]}
                    for t in self.token_classes["fallback"]
                ],
            },
        }

        # Serialize BPE tokenizer if available
        if self._bpe_tokenizer is not None:
            try:
                result["bpe_tokenizer_json"] = self._bpe_tokenizer.to_str()
            except Exception:
                pass

        # Include ion_license metadata if set externally
        if hasattr(self, '_ion_license') and self._ion_license:
            result["ion_license"] = self._ion_license

        return result

    @classmethod
    def from_dict(cls, data: dict) -> "IonTokenizer":
        """Load tokenizer from dictionary."""
        phrases = [t["token"] for t in data["token_classes"]["phrase"]]
        words = [t["token"] for t in data["token_classes"]["word"]]
        fallback = [t["token"][1:-1] for t in data["token_classes"]["fallback"]]
        fallback_mode = data.get("fallback_mode", "bpe")
        preserve_case = data.get("preserve_case", False)

        max_word_length = data.get("max_word_length", 0)

        # Detect plan token from special tokens
        plan_token = None
        special_tokens = [t["token"] for t in data["token_classes"]["special"]]
        for tok in special_tokens:
            if tok in PLAN_TOKENS:
                plan_token = tok
                break

        tokenizer = cls(
            phrases=phrases,
            words=words,
            fallback_chars=fallback,
            fallback_mode=fallback_mode,
            preserve_case=preserve_case,
            plan_token=plan_token,
        )
        tokenizer.max_word_length = max_word_length

        # Restore typo correction settings
        typo_config = data.get("typo_correction", {})
        if typo_config.get("enabled", False):
            tokenizer.enable_typo_correction(
                max_edit_distance=typo_config.get("max_edit_distance", 2),
                min_word_length=typo_config.get("min_word_length", 4),
            )

        # Restore streaming phrase discovery results (phrases already in vocab via token_classes)
        streaming_config = data.get("streaming_phrases", {})
        # Streaming discovered phrases are already serialized in the phrase token_classes
        # so they're restored automatically. We don't re-enable streaming by default
        # (it's a runtime feature, not a persisted state).

        # Restore BPE subwords if present
        bpe_subwords = data["token_classes"].get("bpe_subword", [])
        for item in bpe_subwords:
            tok = item["token"]
            if tok not in tokenizer.vocab:
                tokenizer.vocab[tok] = tokenizer._next_dynamic_id
                tokenizer.id_to_token[tokenizer._next_dynamic_id] = tok
                tokenizer.token_classes["bpe_subword"].append(tok)
                tokenizer._next_dynamic_id += 1

        # Restore BPE tokenizer if serialized
        bpe_json = data.get("bpe_tokenizer_json")
        if bpe_json:
            try:
                from tokenizers import Tokenizer as HFTokenizer
                tokenizer._bpe_tokenizer = HFTokenizer.from_str(bpe_json)
                tokenizer._bpe_vocab_added = True
            except Exception:
                pass

        return tokenizer
