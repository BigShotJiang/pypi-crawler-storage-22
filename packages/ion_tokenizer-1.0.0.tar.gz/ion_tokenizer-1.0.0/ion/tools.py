"""Advanced tools for ion tokenizer: sweep, accountability, export, introspection."""

import hashlib
import json
import random
import csv
from collections import Counter
from pathlib import Path
from typing import Optional, List, Dict, Any, Tuple
from datetime import datetime

import orjson
from tqdm import tqdm


# Domain-specific configurations
DOMAIN_CONFIGS = {
    "general": {
        "description": "General-purpose tokenizer for mixed content",
        "what_it_does": "Uses balanced default settings suitable for any text type. "
                        "No special phrase boosters or filters are applied.",
        "recommended_for": [
            "Mixed-domain corpora or when you're unsure which domain to pick",
            "Web scrapes, news articles, or heterogeneous datasets",
        ],
        "min_word_freq": 1,
        "min_phrase_freq": 3,
        "phrase_threshold": 0.001,
        "max_phrase_layers": 4,
        "remove_emphasis": False,
        "collapse_punctuation": False,
        "phrase_filters": [],
        "phrase_boosters": [],
    },
    "wikipedia": {
        "description": "Optimized for encyclopedic content",
        "what_it_does": "Lowers phrase threshold and adds an extra phrase layer to capture "
                        "long entity names (e.g. 'united states'). Removes wiki markup "
                        "emphasis and filters out editing artifacts like 'citation needed'.",
        "recommended_for": [
            "Wikipedia dumps, encyclopedias, knowledge-base articles",
            "Any factual/reference prose with named entities",
        ],
        "min_word_freq": 2,
        "min_phrase_freq": 5,
        "phrase_threshold": 0.0005,
        "max_phrase_layers": 5,
        "remove_emphasis": True,
        "collapse_punctuation": True,
        "phrase_filters": ["citation needed", "edit source", "see also"],
        "phrase_boosters": ["united states", "world war", "according to"],
    },
    "code": {
        "description": "Optimized for source code and technical docs",
        "what_it_does": "Preserves case (critical for identifiers), keeps phrase layers "
                        "shallow since code phrases are short, and boosts common programming "
                        "idioms like 'return value' and 'error handling'.",
        "recommended_for": [
            "Source code repositories, API documentation, READMEs",
            "Stack Overflow, GitHub issues, technical blog posts",
        ],
        "min_word_freq": 1,
        "min_phrase_freq": 3,
        "phrase_threshold": 0.001,
        "max_phrase_layers": 3,
        "remove_emphasis": False,
        "collapse_punctuation": False,
        "phrase_filters": [],
        "phrase_boosters": ["return value", "function call", "error handling"],
        "preserve_case": True,
    },
    "legal": {
        "description": "Optimized for legal documents and contracts",
        "what_it_does": "Uses a very low phrase threshold and deep phrase layers (6) to "
                        "capture long legal formulae like 'notwithstanding the' and "
                        "'in accordance with'. Legal text is highly formulaic, so "
                        "aggressive phrase discovery yields large compression gains.",
        "recommended_for": [
            "Contracts, legislation, court filings, regulatory text",
            "Terms of service, privacy policies, compliance documents",
        ],
        "min_word_freq": 1,
        "min_phrase_freq": 2,
        "phrase_threshold": 0.0001,
        "max_phrase_layers": 6,
        "remove_emphasis": False,
        "collapse_punctuation": False,
        "phrase_filters": [],
        "phrase_boosters": [
            "pursuant to", "notwithstanding the", "in accordance with",
            "shall be deemed", "subject to the", "for the purposes of",
            "with respect to", "in the event", "provided that",
        ],
    },
    "chat": {
        "description": "Optimized for conversational/chat data",
        "what_it_does": "Raises phrase threshold to avoid noisy n-grams common in chat. "
                        "Collapses repeated punctuation (!!!! -> !) and removes emphasis "
                        "markup. Filters internet slang that fragments into poor phrases, "
                        "and boosts discourse markers like 'i think' and 'you know'.",
        "recommended_for": [
            "Chat logs, messaging data, social media posts",
            "Dialogue datasets, conversational AI training data",
        ],
        "min_word_freq": 1,
        "min_phrase_freq": 5,
        "phrase_threshold": 0.002,
        "max_phrase_layers": 3,
        "remove_emphasis": True,
        "collapse_punctuation": True,
        "phrase_filters": ["lol", "omg", "wtf"],
        "phrase_boosters": ["i think", "you know", "i mean", "that's right"],
    },
    "medical": {
        "description": "Optimized for medical/clinical text",
        "what_it_does": "Uses a very low phrase threshold and 5 phrase layers to capture "
                        "multi-word medical terms (e.g. 'differential diagnosis', "
                        "'blood pressure'). Medical text has a dense specialized vocabulary "
                        "where phrase discovery is especially effective.",
        "recommended_for": [
            "Clinical notes, EHR data, medical literature",
            "PubMed abstracts, drug labels, pathology reports",
        ],
        "min_word_freq": 1,
        "min_phrase_freq": 2,
        "phrase_threshold": 0.0001,
        "max_phrase_layers": 5,
        "remove_emphasis": False,
        "collapse_punctuation": False,
        "phrase_filters": [],
        "phrase_boosters": [
            "blood pressure", "heart rate", "side effects",
            "clinical trial", "patient history", "differential diagnosis",
        ],
    },
    "scientific": {
        "description": "Optimized for scientific papers and research",
        "what_it_does": "Removes emphasis markup (common in LaTeX-derived text), collapses "
                        "punctuation, and boosts academic phrases like 'et al' and "
                        "'statistically significant'. Uses 5 phrase layers to capture "
                        "compound technical terms.",
        "recommended_for": [
            "Research papers, journal articles, preprints (arXiv, etc.)",
            "Grant proposals, technical reports, thesis documents",
        ],
        "min_word_freq": 2,
        "min_phrase_freq": 3,
        "phrase_threshold": 0.0005,
        "max_phrase_layers": 5,
        "remove_emphasis": True,
        "collapse_punctuation": True,
        "phrase_filters": [],
        "phrase_boosters": [
            "et al", "figure shows", "results indicate",
            "statistically significant", "compared to", "in conclusion",
        ],
    },
}


def get_domain_config(domain: str) -> Dict[str, Any]:
    """Get configuration for a specific domain."""
    return DOMAIN_CONFIGS.get(domain, DOMAIN_CONFIGS["general"])


def list_domains() -> List[str]:
    """List available domain presets."""
    return list(DOMAIN_CONFIGS.keys())


def vocab_sweep(
    source: str,
    vocab_sizes: List[int] = None,
    output_csv: str = "vocab_sweep.csv",
    output_chart: str = None,
    max_sentences: int = 100_000,
    hf_split: str = "train",
    hf_text_field: str = "text",
    max_samples: Optional[int] = None,
    hf_config: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """
    Sweep through vocab sizes and measure sequence-length reduction.

    Returns a list of dicts with vocab_size, tokens, reduction, ratio for each size.
    """
    from .corpus import load_corpus
    from .builder import TokenizerBuilder

    if vocab_sizes is None:
        vocab_sizes = [5000, 10000, 20000, 50000, 100000]

    # Load corpus once
    print("Loading corpus for sweep...")
    sentences = []
    count = 0
    for sent in tqdm(load_corpus(
        source,
        hf_split=hf_split,
        hf_text_field=hf_text_field,
        max_samples=max_samples,
        hf_config=hf_config,
    ), desc="Loading"):
        sentences.append(sent)
        count += 1
        if count >= max_sentences:
            break

    # Calculate total original tokens
    total_original = sum(len(s) for s in sentences)
    test_texts = [" ".join(s) for s in sentences[:10000]]  # Use subset for encoding test
    original_words_test = sum(len(t.split()) for t in test_texts)

    results = []

    for vocab_size in tqdm(vocab_sizes, desc="Sweeping vocab sizes"):
        print(f"\nBuilding tokenizer with vocab_size={vocab_size:,}...")

        builder = TokenizerBuilder(
            max_vocab_size=vocab_size,
            min_word_freq=1,
            min_phrase_freq=3,
            max_sentences=len(sentences),
        )

        # Set sentences directly instead of reloading
        builder.sentences = sentences
        builder.word_freq = Counter(tok for sent in sentences for tok in sent)
        builder.stats["total_sentences"] = len(sentences)
        builder.stats["total_tokens_original"] = total_original

        builder.discover_phrases()
        tok = builder.build_tokenizer()

        # Encode test set
        total_tokens = sum(len(tok.encode(t)) for t in test_texts)

        reduction = (original_words_test - total_tokens) / original_words_test * 100 if original_words_test > 0 else 0
        ratio = original_words_test / max(total_tokens, 1)

        result = {
            "vocab_size": vocab_size,
            "actual_vocab": tok.vocab_size(),
            "phrases": len(tok.token_classes["phrase"]),
            "words": len(tok.token_classes["word"]),
            "test_words": original_words_test,
            "test_tokens": total_tokens,
            "reduction_pct": round(reduction, 2),
            "compression_ratio": round(ratio, 2),
        }
        results.append(result)

        print(f"  Vocab: {tok.vocab_size():,}, Reduction: {reduction:.2f}%, Ratio: {ratio:.2f}x")

    # Write CSV
    if output_csv:
        with open(output_csv, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=results[0].keys())
            writer.writeheader()
            writer.writerows(results)
        print(f"\nResults saved to: {output_csv}")

    # Generate ASCII chart
    if output_chart:
        _generate_ascii_chart(results, output_chart)
    else:
        _print_ascii_chart(results)

    return results


def _print_ascii_chart(results: List[Dict], width: int = 60):
    """Print ASCII chart of sweep results."""
    print("\n" + "=" * (width + 20))
    print("VOCAB SIZE vs SEQUENCE REDUCTION")
    print("=" * (width + 20))

    max_reduction = max(r["reduction_pct"] for r in results)

    for r in results:
        bar_len = int((r["reduction_pct"] / max(max_reduction, 1)) * width)
        bar = "#" * bar_len
        print(f"{r['vocab_size']:>7,} | {bar:<{width}} | {r['reduction_pct']:>6.2f}%")

    print("-" * (width + 20))
    print(f"{'Vocab':>7} | {'<-- Sequence Reduction -->':^{width}} | {'%':>6}")
    print("=" * (width + 20))


def _generate_ascii_chart(results: List[Dict], output_path: str, width: int = 60):
    """Generate ASCII chart file."""
    lines = []
    lines.append("=" * (width + 20))
    lines.append("VOCAB SIZE vs SEQUENCE REDUCTION")
    lines.append("=" * (width + 20))

    max_reduction = max(r["reduction_pct"] for r in results)

    for r in results:
        bar_len = int((r["reduction_pct"] / max(max_reduction, 1)) * width)
        bar = "#" * bar_len
        lines.append(f"{r['vocab_size']:>7,} | {bar:<{width}} | {r['reduction_pct']:>6.2f}%")

    lines.append("-" * (width + 20))
    lines.append(f"{'Vocab':>7} | {'<-- Sequence Reduction -->':^{width}} | {'%':>6}")
    lines.append("=" * (width + 20))

    Path(output_path).write_text("\n".join(lines))
    print(f"Chart saved to: {output_path}")


def phrase_accountability(
    tokenizer_path: str,
    corpus_source: str,
    top_n: int = 100,
    bottom_n: int = 100,
    max_samples: int = 50000,
    hf_split: str = "train",
    hf_text_field: str = "text",
    hf_config: Optional[str] = None,
    output_csv: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Analyze phrase value: per-phrase token savings, usage frequency, marginal benefit.

    Returns dict with top_phrases, bottom_phrases, and full analysis.
    """
    from .tokenizer import IonTokenizer
    from .corpus import load_corpus

    # Load tokenizer
    tok_data = orjson.loads(Path(tokenizer_path).read_bytes())
    tok = IonTokenizer.from_dict(tok_data)

    # Track phrase usage and savings
    phrase_usage = Counter()
    phrase_savings = Counter()  # Tokens saved by using this phrase

    # Load and analyze corpus
    print("Analyzing phrase value on corpus...")
    count = 0
    for sent in tqdm(load_corpus(
        corpus_source,
        hf_split=hf_split,
        hf_text_field=hf_text_field,
        hf_config=hf_config,
    ), desc="Analyzing"):
        text = " ".join(sent)

        # Count phrase matches and savings
        words = text.lower().split()
        i = 0
        while i < len(words):
            match = tok._match_phrase(words, i)
            if match:
                phrase, length = match
                phrase_usage[phrase] += 1
                # Savings = words in phrase - 1 (the single token)
                phrase_savings[phrase] += length - 1
                i += length
            else:
                i += 1

        count += 1
        if count >= max_samples:
            break

    # Calculate marginal benefit score
    # Score = (total_savings * frequency) / phrase_length
    # This rewards frequently-used phrases that save many tokens
    phrase_scores = {}
    for phrase in tok.token_classes["phrase"]:
        usage = phrase_usage.get(phrase, 0)
        savings = phrase_savings.get(phrase, 0)
        length = len(phrase.split())

        if usage > 0:
            marginal_benefit = (savings * usage) / length
        else:
            marginal_benefit = 0

        phrase_scores[phrase] = {
            "phrase": phrase,
            "word_count": length,
            "usage_count": usage,
            "total_savings": savings,
            "marginal_benefit": round(marginal_benefit, 2),
            "savings_per_use": round(savings / max(usage, 1), 2),
        }

    # Sort by marginal benefit
    sorted_phrases = sorted(
        phrase_scores.values(),
        key=lambda x: x["marginal_benefit"],
        reverse=True
    )

    top_phrases = sorted_phrases[:top_n]
    bottom_phrases = sorted_phrases[-bottom_n:] if len(sorted_phrases) > bottom_n else []
    bottom_phrases.reverse()  # Worst first

    # Unused phrases
    unused = [p for p in sorted_phrases if p["usage_count"] == 0]

    result = {
        "total_phrases": len(tok.token_classes["phrase"]),
        "used_phrases": len([p for p in sorted_phrases if p["usage_count"] > 0]),
        "unused_phrases": len(unused),
        "total_savings": sum(p["total_savings"] for p in sorted_phrases),
        "top_phrases": top_phrases,
        "bottom_phrases": bottom_phrases,
        "unused_list": [p["phrase"] for p in unused[:50]],
    }

    # Output CSV if requested
    if output_csv:
        with open(output_csv, 'w', newline='') as f:
            if sorted_phrases:
                writer = csv.DictWriter(f, fieldnames=sorted_phrases[0].keys())
                writer.writeheader()
                writer.writerows(sorted_phrases)
        print(f"Full analysis saved to: {output_csv}")

    return result


def bpe_parity_compare(
    text: str,
    ion_tokenizer_path: str,
    bpe_tokenizer_path: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Side-by-side comparison of ion vs BPE tokenization.

    Shows token counts and highlights where each wins.
    """
    from .tokenizer import IonTokenizer

    # Load ion tokenizer
    tok_data = orjson.loads(Path(ion_tokenizer_path).read_bytes())
    ion_tok = IonTokenizer.from_dict(tok_data)

    # Encode with ion
    ion_ids = ion_tok.encode(text)
    ion_tokens = [ion_tok.id_to_token.get(id, "<?>") for id in ion_ids]

    # Try to load BPE tokenizer
    bpe_tokens = None
    bpe_ids = None

    if bpe_tokenizer_path and Path(bpe_tokenizer_path).exists():
        try:
            from tokenizers import Tokenizer
            bpe_tok = Tokenizer.from_file(bpe_tokenizer_path)
            bpe_output = bpe_tok.encode(text)
            bpe_ids = bpe_output.ids
            bpe_tokens = bpe_output.tokens
        except Exception:
            pass

    # Try tiktoken as fallback
    if bpe_tokens is None:
        try:
            import tiktoken
            enc = tiktoken.get_encoding("cl100k_base")
            bpe_ids = enc.encode(text)
            bpe_tokens = [enc.decode([id]) for id in bpe_ids]
        except ImportError:
            pass

    result = {
        "input_text": text,
        "input_words": len(text.split()),
        "ion_tokens": ion_tokens,
        "ion_count": len(ion_tokens),
        "bpe_tokens": bpe_tokens,
        "bpe_count": len(bpe_tokens) if bpe_tokens else None,
    }

    if bpe_tokens:
        diff = len(bpe_tokens) - len(ion_tokens)
        result["difference"] = diff
        result["ion_wins"] = diff > 0
        result["savings_pct"] = round(diff / len(bpe_tokens) * 100, 2) if diff > 0 else 0

    return result


def export_huggingface(
    tokenizer_path: str,
    output_dir: str,
) -> str:
    """
    Export ion tokenizer to HuggingFace tokenizers format.

    Creates tokenizer.json compatible with HuggingFace transformers.
    """
    from .tokenizer import IonTokenizer

    tok_data = orjson.loads(Path(tokenizer_path).read_bytes())
    tok = IonTokenizer.from_dict(tok_data)

    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    # Build HuggingFace compatible format
    hf_vocab = {}
    for token, id in tok.vocab.items():
        hf_vocab[token] = id

    hf_config = {
        "version": "1.0",
        "truncation": None,
        "padding": None,
        "added_tokens": [
            {"id": tok.vocab["<pad>"], "content": "<pad>", "single_word": False, "lstrip": False, "rstrip": False, "normalized": False, "special": True},
            {"id": tok.vocab["<unk>"], "content": "<unk>", "single_word": False, "lstrip": False, "rstrip": False, "normalized": False, "special": True},
            {"id": tok.vocab["<bos>"], "content": "<bos>", "single_word": False, "lstrip": False, "rstrip": False, "normalized": False, "special": True},
            {"id": tok.vocab["<eos>"], "content": "<eos>", "single_word": False, "lstrip": False, "rstrip": False, "normalized": False, "special": True},
        ],
        "normalizer": {"type": "Lowercase"},
        "pre_tokenizer": {"type": "Whitespace"},
        "post_processor": None,
        "decoder": {"type": "WordPiece", "prefix": "", "cleanup": True},
        "model": {
            "type": "WordLevel",
            "vocab": hf_vocab,
            "unk_token": "<unk>",
        },
    }

    hf_path = output_path / "tokenizer.json"
    hf_path.write_bytes(orjson.dumps(hf_config, option=orjson.OPT_INDENT_2))

    # Write tokenizer_config.json
    config = {
        "tokenizer_class": "PreTrainedTokenizerFast",
        "unk_token": "<unk>",
        "bos_token": "<bos>",
        "eos_token": "<eos>",
        "pad_token": "<pad>",
        "model_max_length": 2048,
    }
    (output_path / "tokenizer_config.json").write_bytes(
        orjson.dumps(config, option=orjson.OPT_INDENT_2)
    )

    # Write special_tokens_map.json
    special_tokens = {
        "unk_token": "<unk>",
        "bos_token": "<bos>",
        "eos_token": "<eos>",
        "pad_token": "<pad>",
    }
    (output_path / "special_tokens_map.json").write_bytes(
        orjson.dumps(special_tokens, option=orjson.OPT_INDENT_2)
    )

    return str(output_path)


def export_sentencepiece(
    tokenizer_path: str,
    output_path: str,
) -> str:
    """
    Export ion tokenizer to SentencePiece-compatible vocab format.

    Creates vocab.txt file that can be loaded by SentencePiece-based systems.
    """
    from .tokenizer import IonTokenizer

    tok_data = orjson.loads(Path(tokenizer_path).read_bytes())
    tok = IonTokenizer.from_dict(tok_data)

    lines = []

    # SentencePiece format: token\tscore
    # We use negative ID as score (lower ID = higher priority)
    for token, id in sorted(tok.vocab.items(), key=lambda x: x[1]):
        # Escape special characters
        escaped = token.replace("\t", "\\t").replace("\n", "\\n")
        score = -id  # Higher priority for lower IDs
        lines.append(f"{escaped}\t{score}")

    Path(output_path).write_text("\n".join(lines))
    return output_path


def export_vocab_txt(
    tokenizer_path: str,
    output_path: str,
    include_ids: bool = True,
) -> str:
    """
    Export ion tokenizer to plain vocab.txt format.

    Simple format for custom loaders.
    """
    from .tokenizer import IonTokenizer

    tok_data = orjson.loads(Path(tokenizer_path).read_bytes())
    tok = IonTokenizer.from_dict(tok_data)

    lines = []
    for token, id in sorted(tok.vocab.items(), key=lambda x: x[1]):
        if include_ids:
            lines.append(f"{id}\t{token}")
        else:
            lines.append(token)

    Path(output_path).write_text("\n".join(lines))
    return output_path


def export_onnx(
    tokenizer_path: str,
    output_dir: str,
) -> str:
    """
    Export ion tokenizer in ONNX-compatible format.

    Creates vocab.txt and config.json for use with ONNX tokenizer operators.
    """
    from .tokenizer import IonTokenizer

    tok_data = orjson.loads(Path(tokenizer_path).read_bytes())
    tok = IonTokenizer.from_dict(tok_data)

    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    # Export vocabulary (one token per line, sorted by ID)
    vocab_lines = []
    for token, idx in sorted(tok.vocab.items(), key=lambda x: x[1]):
        vocab_lines.append(token)
    (output_path / "vocab.txt").write_text("\n".join(vocab_lines), encoding="utf-8")

    # Export config
    config = {
        "vocab_size": len(tok.vocab),
        "pad_token_id": tok.vocab.get("<pad>", 0),
        "unk_token_id": tok.vocab.get("<unk>", 1),
        "bos_token_id": tok.vocab.get("<bos>", 2),
        "eos_token_id": tok.vocab.get("<eos>", 3),
        "model_type": "ion",
    }
    import json
    (output_path / "config.json").write_text(json.dumps(config, indent=2))

    return str(output_path)


def export_tiktoken(
    tokenizer_path: str,
    output_path: str,
) -> str:
    """
    Export ion tokenizer in tiktoken-compatible format.

    Creates a .tiktoken file with base64-encoded token-to-rank mappings,
    compatible with tiktoken's load_tiktoken_bpe() function.
    """
    import base64
    from .tokenizer import IonTokenizer

    tok_data = orjson.loads(Path(tokenizer_path).read_bytes())
    tok = IonTokenizer.from_dict(tok_data)

    lines = []
    for token, rank in sorted(tok.vocab.items(), key=lambda x: x[1]):
        token_bytes = token.encode("utf-8")
        b64 = base64.b64encode(token_bytes).decode("ascii")
        lines.append(f"{b64} {rank}")

    Path(output_path).write_text("\n".join(lines))
    return output_path


def export_jsonl(
    tokenizer_path: str,
    output_path: str,
) -> str:
    """
    Export ion tokenizer as JSON-Lines format.

    Each line is a JSON object with token metadata:
    {"id": 0, "token": "<pad>", "type": "special", "bytes": [60, 112, ...]}

    Useful for data pipelines, BigQuery, Spark, and custom tooling.
    """
    from .tokenizer import IonTokenizer

    tok_data = orjson.loads(Path(tokenizer_path).read_bytes())
    tok = IonTokenizer.from_dict(tok_data)

    special_tokens = {"<pad>", "<unk>", "<bos>", "<eos>"}

    # Determine token types from token_classes
    phrase_tokens = set()
    word_tokens = set()
    for tc in tok_data.get("token_classes", {}).get("phrase", []):
        phrase_tokens.add(tc["token"])
    for tc in tok_data.get("token_classes", {}).get("word", []):
        word_tokens.add(tc["token"])

    lines = []
    for token, idx in sorted(tok.vocab.items(), key=lambda x: x[1]):
        if token in special_tokens:
            token_type = "special"
        elif token in phrase_tokens:
            token_type = "phrase"
        elif token in word_tokens:
            token_type = "word"
        else:
            token_type = "subword"

        entry = {
            "id": idx,
            "token": token,
            "type": token_type,
            "bytes": list(token.encode("utf-8")),
        }
        lines.append(orjson.dumps(entry).decode("utf-8"))

    Path(output_path).write_text("\n".join(lines))
    return output_path


def export_csv(
    tokenizer_path: str,
    output_path: str,
) -> str:
    """
    Export ion tokenizer as CSV format.

    Columns: id, token, type, length, byte_length
    Useful for spreadsheet analysis, pandas, and quick inspection.
    """
    from .tokenizer import IonTokenizer

    tok_data = orjson.loads(Path(tokenizer_path).read_bytes())
    tok = IonTokenizer.from_dict(tok_data)

    special_tokens = {"<pad>", "<unk>", "<bos>", "<eos>"}
    phrase_tokens = set()
    word_tokens = set()
    for tc in tok_data.get("token_classes", {}).get("phrase", []):
        phrase_tokens.add(tc["token"])
    for tc in tok_data.get("token_classes", {}).get("word", []):
        word_tokens.add(tc["token"])

    lines = ["id,token,type,length,byte_length"]
    for token, idx in sorted(tok.vocab.items(), key=lambda x: x[1]):
        if token in special_tokens:
            token_type = "special"
        elif token in phrase_tokens:
            token_type = "phrase"
        elif token in word_tokens:
            token_type = "word"
        else:
            token_type = "subword"

        # CSV-escape: quote tokens containing commas or quotes
        escaped = token.replace('"', '""')
        if "," in token or '"' in token or "\n" in token:
            escaped = f'"{escaped}"'

        lines.append(f"{idx},{escaped},{token_type},{len(token)},{len(token.encode('utf-8'))}")

    Path(output_path).write_text("\n".join(lines))
    return output_path


def introspect_fallbacks(
    tokenizer_path: str,
    text: str,
) -> Dict[str, Any]:
    """
    Analyze fallback tokens in the encoded output.

    Shows why words fell back and suggests vocab constraints.
    """
    from .tokenizer import IonTokenizer

    tok_data = orjson.loads(Path(tokenizer_path).read_bytes())
    tok = IonTokenizer.from_dict(tok_data)

    # Get words from text
    words = text.lower().strip().split()

    fallbacks = []
    word_tokens = set(tok.token_classes["word"])
    phrase_set = set(tok.token_classes["phrase"])

    for word in words:
        if word not in tok.vocab:
            # This word will fall back to character tokens
            char_tokens = []
            for char in word:
                char_tok = f"<{char}>"
                if char_tok in tok.vocab:
                    char_tokens.append(char_tok)
                else:
                    char_tokens.append("<unk>")

            fallback_info = {
                "word": word,
                "fallback_tokens": char_tokens,
                "token_count": len(char_tokens),
                "reason": "not in vocabulary",
                "suggestions": [],
            }

            # Suggest why it might be missing
            if len(word) < 3:
                fallback_info["suggestions"].append("Word too short - may have been filtered")
            else:
                fallback_info["suggestions"].append(
                    f"Add to corpus or lower --min-word-freq threshold"
                )

            # Check if similar words exist
            similar = [w for w in list(word_tokens)[:1000] if word[:3] in w][:3]
            if similar:
                fallback_info["similar_in_vocab"] = similar

            fallbacks.append(fallback_info)

    # Summary statistics
    total_words = len(words)
    fallback_words = len(fallbacks)
    fallback_tokens = sum(f["token_count"] for f in fallbacks)

    result = {
        "total_words": total_words,
        "fallback_words": fallback_words,
        "fallback_rate": round(fallback_words / max(total_words, 1) * 100, 2),
        "fallback_tokens": fallback_tokens,
        "expansion_factor": round(fallback_tokens / max(fallback_words, 1), 2),
        "fallbacks": fallbacks,
        "recommendations": [],
    }

    # Generate recommendations
    if fallback_words > total_words * 0.1:
        result["recommendations"].append(
            "High fallback rate (>10%). Consider: --min-word-freq 1 to include more words"
        )
    if fallback_tokens > fallback_words * 5:
        result["recommendations"].append(
            "Long fallback sequences. Consider: using --take-needed mode for full coverage"
        )

    return result


def create_reproducibility_snapshot(
    tokenizer_path: str,
    corpus_source: str,
    seed: int,
    config: Dict[str, Any],
    output_path: str,
) -> str:
    """
    Create a reproducibility snapshot for the tokenizer build.

    Includes seed, config, corpus hash, and tokenizer hash.
    """
    from .tokenizer import IonTokenizer

    tok_data = orjson.loads(Path(tokenizer_path).read_bytes())

    # Compute tokenizer hash
    tok_hash = hashlib.sha256(
        orjson.dumps(tok_data, option=orjson.OPT_SORT_KEYS)
    ).hexdigest()[:16]

    # Compute corpus hash (if it's a file)
    corpus_hash = None
    if Path(corpus_source).exists():
        content = Path(corpus_source).read_bytes()
        corpus_hash = hashlib.sha256(content).hexdigest()[:16]

    snapshot = {
        "version": "1.0",
        "created_at": datetime.now().isoformat(),
        "seed": seed,
        "corpus_source": corpus_source,
        "corpus_hash": corpus_hash,
        "tokenizer_hash": tok_hash,
        "config": config,
        "vocab_size": tok_data.get("vocab_size"),
    }

    Path(output_path).write_bytes(
        orjson.dumps(snapshot, option=orjson.OPT_INDENT_2)
    )

    return output_path


def verify_reproducibility(
    snapshot_path: str,
    tokenizer_path: str,
) -> Dict[str, Any]:
    """
    Verify that a tokenizer matches its reproducibility snapshot.
    """
    snapshot = orjson.loads(Path(snapshot_path).read_bytes())
    tok_data = orjson.loads(Path(tokenizer_path).read_bytes())

    # Compute current tokenizer hash
    current_hash = hashlib.sha256(
        orjson.dumps(tok_data, option=orjson.OPT_SORT_KEYS)
    ).hexdigest()[:16]

    expected_hash = snapshot.get("tokenizer_hash")

    return {
        "snapshot_created": snapshot.get("created_at"),
        "seed": snapshot.get("seed"),
        "expected_hash": expected_hash,
        "current_hash": current_hash,
        "match": expected_hash == current_hash,
        "corpus_source": snapshot.get("corpus_source"),
        "config": snapshot.get("config"),
    }


def set_seed(seed: int):
    """Set random seed for reproducibility."""
    random.seed(seed)
    try:
        import numpy as np
        np.random.seed(seed)
    except ImportError:
        pass
