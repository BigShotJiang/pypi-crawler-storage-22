"""Text cleaning and preprocessing utilities for ion."""

import re
import unicodedata
from typing import Iterator, Optional


# Emphasis/intensifier words to filter
EMPHASIS_WORDS = frozenset({
    "very", "really", "extremely", "incredibly", "absolutely", "totally",
    "completely", "utterly", "quite", "rather", "somewhat", "fairly",
    "pretty", "highly", "deeply", "strongly", "seriously", "literally",
    "actually", "basically", "essentially", "definitely", "certainly",
    "surely", "clearly", "obviously", "simply", "just", "even", "ever",
    "super", "ultra", "mega", "so", "too", "much", "way",
})

# Filler words that add no semantic value and break phrase detection
FILLER_WORDS = frozenset({
    "um", "uh", "er", "ah", "like", "you know", "i mean", "sort of",
    "kind of", "well", "anyway", "anyways", "basically", "literally",
    "honestly", "frankly", "obviously", "clearly", "actually", "really",
    "right", "okay", "ok", "so", "now", "then", "also", "just",
})

# Discourse markers that can be removed without semantic loss
DISCOURSE_MARKERS = frozenset({
    "however", "therefore", "moreover", "furthermore", "nevertheless",
    "nonetheless", "meanwhile", "consequently", "accordingly", "hence",
    "thus", "indeed", "certainly", "obviously", "apparently", "presumably",
    "arguably", "admittedly", "undoubtedly", "interestingly", "surprisingly",
    "importantly", "significantly", "notably", "specifically", "particularly",
    "especially", "generally", "typically", "usually", "normally", "often",
    "sometimes", "occasionally", "rarely", "seldom", "always", "never",
})

# Semantic equivalents: normalize to canonical forms for better phrase matching
SEMANTIC_NORMALIZATIONS = {
    # Modal equivalents
    "gonna": "going to",
    "gotta": "got to",
    "wanna": "want to",
    "kinda": "kind of",
    "sorta": "sort of",
    "coulda": "could have",
    "shoulda": "should have",
    "woulda": "would have",
    "musta": "must have",
    "oughta": "ought to",
    "hafta": "have to",
    "hasta": "has to",
    "useta": "used to",
    "lemme": "let me",
    "gimme": "give me",
    "dunno": "do not know",
    "ain't": "is not",
    # Common phrase normalizations
    "a lot of": "many",
    "lots of": "many",
    "plenty of": "many",
    "a bunch of": "many",
    "a number of": "several",
    "a couple of": "two",
    "a few": "some",
    "in order to": "to",
    "so as to": "to",
    "due to the fact that": "because",
    "owing to the fact that": "because",
    "by virtue of": "because",
    "as a result of": "because",
    "on account of": "because",
    "in light of": "because",
    "for the purpose of": "for",
    "with the aim of": "to",
    "with a view to": "to",
    "at this point in time": "now",
    "at the present time": "now",
    "in the event that": "if",
    "in the case that": "if",
    "on the condition that": "if",
    "provided that": "if",
    "assuming that": "if",
    "as long as": "if",
    "in spite of the fact that": "although",
    "despite the fact that": "although",
    "regardless of the fact that": "although",
    "notwithstanding": "although",
    "prior to": "before",
    "subsequent to": "after",
    "in the aftermath of": "after",
    "in the wake of": "after",
    "with regard to": "about",
    "with respect to": "about",
    "in regard to": "about",
    "in relation to": "about",
    "pertaining to": "about",
    "concerning": "about",
    "regarding": "about",
    "as regards": "about",
    "in terms of": "about",
    "on the subject of": "about",
    "in the matter of": "about",
    "as far as": "about",
    "when it comes to": "about",
    "in the area of": "in",
    "in the field of": "in",
    "in the realm of": "in",
    "in the domain of": "in",
    "make use of": "use",
    "utilize": "use",
    "take advantage of": "use",
    "is able to": "can",
    "has the ability to": "can",
    "is capable of": "can",
    "has the capacity to": "can",
    "it is necessary to": "must",
    "it is important to": "should",
    "it is essential to": "must",
    "there is a need to": "must",
    "a large number of": "many",
    "a great deal of": "much",
    "a significant amount of": "much",
    "the majority of": "most",
    "the vast majority of": "most",
    "a small number of": "few",
    "a limited number of": "few",
    # Time expressions
    "at the moment": "now",
    "right now": "now",
    "currently": "now",
    "presently": "now",
    "at present": "now",
    "for the time being": "now",
    "in the near future": "soon",
    "in the not too distant future": "soon",
    "before long": "soon",
    "in due course": "soon",
    "sooner or later": "eventually",
    "at some point": "eventually",
    "in the end": "eventually",
    "in the long run": "eventually",
    "over and over": "repeatedly",
    "again and again": "repeatedly",
    "time and time again": "repeatedly",
    "time after time": "repeatedly",
    "more and more": "increasingly",
    "less and less": "decreasingly",
    # Hedging removal - normalize hedged statements
    "i think that": "",
    "i believe that": "",
    "i feel that": "",
    "in my opinion": "",
    "from my perspective": "",
    "it seems that": "",
    "it appears that": "",
    "it would seem that": "",
    "it seems to me that": "",
    "it is my understanding that": "",
    "as far as i know": "",
    "to the best of my knowledge": "",
    "if i'm not mistaken": "",
    "if memory serves": "",
}

# Redundant adjectives/adverbs that can be removed
REDUNDANT_MODIFIERS = frozenset({
    "very", "really", "quite", "rather", "somewhat", "fairly",
    "pretty", "highly", "extremely", "incredibly", "absolutely",
    "completely", "totally", "utterly", "entirely", "perfectly",
    "simply", "merely", "just", "only", "even",
})

# Common stopwords that can be aggressively removed
AGGRESSIVE_STOPWORDS = frozenset({
    "the", "a", "an", "and", "or", "but", "in", "on", "at", "to",
    "for", "of", "with", "by", "from", "as", "is", "was", "are",
    "were", "been", "be", "have", "has", "had", "do", "does", "did",
    "will", "would", "could", "should", "may", "might", "must",
    "shall", "can", "need", "dare", "ought", "used", "that", "which",
    "who", "whom", "whose", "this", "these", "those", "it", "its",
})

# Sentence starters that add no content
SENTENCE_STARTERS = frozenset({
    "well", "so", "now", "okay", "ok", "right", "anyway", "anyways",
    "actually", "basically", "honestly", "frankly", "clearly",
    "obviously", "essentially", "fundamentally", "interestingly",
    "surprisingly", "importantly", "significantly", "notably",
    "incidentally", "coincidentally", "fortunately", "unfortunately",
})

# Redundant phrases that can be simplified
REDUNDANT_PHRASES = {
    "each and every": "every",
    "first and foremost": "first",
    "one and only": "only",
    "any and all": "all",
    "if and when": "when",
    "unless and until": "until",
    "null and void": "void",
    "peace and quiet": "quiet",
    "various different": "various",
    "completely eliminate": "eliminate",
    "totally destroy": "destroy",
    "absolutely essential": "essential",
    "basic fundamentals": "fundamentals",
    "brief summary": "summary",
    "close proximity": "proximity",
    "collaborate together": "collaborate",
    "combine together": "combine",
    "completely finish": "finish",
    "end result": "result",
    "exact same": "same",
    "final outcome": "outcome",
    "free gift": "gift",
    "future plans": "plans",
    "general public": "public",
    "join together": "join",
    "merge together": "merge",
    "mix together": "mix",
    "mutual cooperation": "cooperation",
    "new innovation": "innovation",
    "past history": "history",
    "plan ahead": "plan",
    "postpone until later": "postpone",
    "reason why": "reason",
    "refer back": "refer",
    "repeat again": "repeat",
    "revert back": "revert",
    "rise up": "rise",
    "still remains": "remains",
    "sum total": "total",
    "surrounded on all sides": "surrounded",
    "unexpected surprise": "surprise",
    "very unique": "unique",
    "advance planning": "planning",
    "added bonus": "bonus",
    "consensus of opinion": "consensus",
    "direct confrontation": "confrontation",
    "empty space": "space",
    "evolve over time": "evolve",
    "fall down": "fall",
    "gather together": "gather",
    "grow in size": "grow",
}

# Common contractions to expand
CONTRACTIONS = {
    "can't": "cannot",
    "won't": "will not",
    "n't": " not",
    "'re": " are",
    "'ve": " have",
    "'ll": " will",
    "'d": " would",
    "'m": " am",
    "let's": "let us",
    "it's": "it is",
    "that's": "that is",
    "what's": "what is",
    "there's": "there is",
    "here's": "here is",
    "who's": "who is",
    "how's": "how is",
    "where's": "where is",
    "when's": "when is",
    "why's": "why is",
}

# Characters to normalize or remove
UNICODE_QUOTES = {
    '\u2018': "'", '\u2019': "'",  # Single quotes
    '\u201c': '"', '\u201d': '"',  # Double quotes
    '\u2013': '-', '\u2014': '-',  # En/em dash
    '\u2026': '...',  # Ellipsis
    '\u00a0': ' ',  # Non-breaking space
}


def normalize_unicode(text: str) -> str:
    """Normalize unicode characters to ASCII equivalents."""
    # Replace special unicode characters
    for char, replacement in UNICODE_QUOTES.items():
        text = text.replace(char, replacement)

    # Normalize remaining unicode
    text = unicodedata.normalize('NFKC', text)
    return text


def collapse_whitespace(text: str) -> str:
    """Collapse multiple whitespace characters to single space."""
    return re.sub(r'\s+', ' ', text).strip()


def collapse_punctuation(text: str) -> str:
    """Collapse duplicate punctuation marks."""
    # Preserve ellipsis, collapse longer
    text = re.sub(r'\.{4,}', '...', text)
    # Collapse repeated punctuation
    text = re.sub(r'!{2,}', '!', text)
    text = re.sub(r'\?{2,}', '?', text)
    text = re.sub(r',{2,}', ',', text)
    text = re.sub(r';{2,}', ';', text)
    text = re.sub(r':{2,}', ':', text)
    # Mixed punctuation
    text = re.sub(r'[!?]{2,}', '?', text)
    # Dashes
    text = re.sub(r'-{3,}', '--', text)
    return text


def remove_urls(text: str) -> str:
    """Remove URLs from text."""
    url_pattern = r'https?://\S+|www\.\S+'
    return re.sub(url_pattern, '', text)


def remove_emails(text: str) -> str:
    """Remove email addresses from text."""
    email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    return re.sub(email_pattern, '', text)


def remove_html_tags(text: str) -> str:
    """Remove HTML tags from text."""
    return re.sub(r'<[^>]+>', '', text)


def remove_special_chars(text: str, keep_basic_punct: bool = True) -> str:
    """Remove special characters, optionally keeping basic punctuation."""
    if keep_basic_punct:
        # Keep letters, numbers, basic punctuation, and whitespace
        return re.sub(r"[^a-zA-Z0-9\s.,!?;:'\"-]", '', text)
    else:
        # Keep only letters, numbers, and whitespace
        return re.sub(r'[^a-zA-Z0-9\s]', '', text)


def expand_contractions(text: str) -> str:
    """Expand common contractions."""
    for contraction, expansion in CONTRACTIONS.items():
        text = re.sub(re.escape(contraction), expansion, text, flags=re.IGNORECASE)
    return text


def remove_numbers(text: str) -> str:
    """Remove standalone numbers (preserves numbers in words)."""
    return re.sub(r'\b\d+\b', '', text)


def filter_emphasis_words(text: str) -> str:
    """Remove emphasis/intensifier words from text."""
    words = text.split()
    filtered = [w for w in words if w.lower() not in EMPHASIS_WORDS]
    return ' '.join(filtered)


def filter_filler_words(text: str) -> str:
    """Remove filler words that break phrase detection."""
    # First remove multi-word fillers
    text_lower = text.lower()
    for filler in sorted(FILLER_WORDS, key=len, reverse=True):
        if ' ' in filler:
            text_lower = re.sub(r'\b' + re.escape(filler) + r'\b', '', text_lower)
    # Then single-word fillers (strip punctuation for matching)
    words = text_lower.split()
    filtered = [w for w in words if re.sub(r'[^\w]', '', w) not in FILLER_WORDS]
    return ' '.join(filtered)


def filter_discourse_markers(text: str) -> str:
    """Remove discourse markers that add no semantic value."""
    words = text.lower().split()
    filtered = [w for w in words if w not in DISCOURSE_MARKERS]
    return ' '.join(filtered)


def apply_semantic_normalizations(text: str) -> str:
    """Normalize phrases to canonical forms for better phrase matching."""
    text_lower = text.lower()
    # Apply longest matches first to avoid partial replacements
    for phrase, replacement in sorted(
        SEMANTIC_NORMALIZATIONS.items(), key=lambda x: len(x[0]), reverse=True
    ):
        pattern = r'\b' + re.escape(phrase) + r'\b'
        text_lower = re.sub(pattern, replacement, text_lower)
    return text_lower


def normalize_numbers(text: str) -> str:
    """Normalize number expressions to reduce vocabulary."""
    # Replace specific numbers with generic tokens
    text = re.sub(r'\b\d{1,2}\b', '<num>', text)  # Small numbers
    text = re.sub(r'\b\d{3,4}\b', '<year>', text)  # Years/medium numbers
    text = re.sub(r'\b\d{5,}\b', '<bignum>', text)  # Large numbers
    text = re.sub(r'\b\d+\.\d+\b', '<decimal>', text)  # Decimals
    text = re.sub(r'\$\d+', '<money>', text)  # Money
    text = re.sub(r'\d+%', '<percent>', text)  # Percentages
    return text


def remove_parentheticals(text: str) -> str:
    """Remove parenthetical expressions that break phrase flow."""
    # Remove content in parentheses
    text = re.sub(r'\([^)]*\)', '', text)
    # Remove content in brackets
    text = re.sub(r'\[[^\]]*\]', '', text)
    # Remove content in braces
    text = re.sub(r'\{[^}]*\}', '', text)
    return text


def simplify_punctuation(text: str) -> str:
    """Simplify punctuation to canonical forms."""
    # Normalize quotes
    text = re.sub(r'[""\u201c\u201d]', '"', text)
    text = re.sub(r"[''`\u2018\u2019]", "'", text)
    # Normalize dashes
    text = re.sub(r'[\u2013\u2014\u2015]', '-', text)
    text = re.sub(r'-{2,}', '-', text)
    # Remove excessive punctuation
    text = re.sub(r'[.]{4,}', '...', text)
    text = re.sub(r'[!]{2,}', '!', text)
    text = re.sub(r'[?]{2,}', '?', text)
    text = re.sub(r'[,]{2,}', ',', text)
    # Remove decorative punctuation
    text = re.sub(r'[~*_#@^]', '', text)
    return text


def deduplicate_adjacent(text: str) -> str:
    """Remove adjacent duplicate words."""
    words = text.split()
    if not words:
        return text
    result = [words[0]]
    for word in words[1:]:
        if word.lower() != result[-1].lower():
            result.append(word)
    return ' '.join(result)


def remove_redundant_modifiers(text: str) -> str:
    """Remove redundant adjectives and adverbs."""
    words = text.lower().split()
    filtered = [w for w in words if w not in REDUNDANT_MODIFIERS]
    return ' '.join(filtered)


def remove_stopwords(text: str) -> str:
    """Aggressively remove common stopwords."""
    words = text.lower().split()
    filtered = [w for w in words if w not in AGGRESSIVE_STOPWORDS]
    return ' '.join(filtered)


def remove_sentence_starters(text: str) -> str:
    """Remove unnecessary sentence starters."""
    # Split into sentences using common sentence boundaries
    sentences = re.split(r'([.!?]+)', text)
    result = []
    for i, part in enumerate(sentences):
        if i % 2 == 0:  # Content part
            words = part.strip().split()
            if words:
                # Strip leading punctuation (comma, etc.) from first word for matching
                first_clean = re.sub(r'[^\w]', '', words[0]).lower()
                if first_clean in SENTENCE_STARTERS:
                    # Remove the starter word; also strip comma if next word starts with one
                    words = words[1:]
                    if words and words[0].startswith(','):
                        words[0] = words[0].lstrip(',').strip()
                        if not words[0]:
                            words = words[1:]
            result.append(' '.join(words))
        else:  # Punctuation
            result.append(part)
    # Also handle text that starts with a starter (no preceding sentence boundary)
    final = ''.join(result).strip()
    if final:
        words = final.split()
        if words:
            first_clean = re.sub(r'[^\w]', '', words[0]).lower()
            if first_clean in SENTENCE_STARTERS:
                words = words[1:]
                if words and words[0].startswith(','):
                    words[0] = words[0].lstrip(',').strip()
                    if not words[0]:
                        words = words[1:]
                final = ' '.join(words)
    return final


def simplify_redundant_phrases(text: str) -> str:
    """Simplify redundant phrases to single words."""
    text_lower = text.lower()
    for phrase, replacement in sorted(
        REDUNDANT_PHRASES.items(), key=lambda x: len(x[0]), reverse=True
    ):
        pattern = r'\b' + re.escape(phrase) + r'\b'
        text_lower = re.sub(pattern, replacement, text_lower)
    return text_lower


def normalize_whitespace_around_punct(text: str) -> str:
    """Remove spaces before punctuation, ensure space after."""
    text = re.sub(r'\s+([.,!?;:])', r'\1', text)
    text = re.sub(r'([.,!?;:])([a-zA-Z])', r'\1 \2', text)
    return text


def remove_quotes(text: str) -> str:
    """Remove quotation marks from text."""
    return re.sub(r'["\']', '', text)


def flatten_case_variations(text: str) -> str:
    """Flatten ALL CAPS and MiXeD CaSe to lowercase."""
    words = text.split()
    result = []
    for word in words:
        # All caps or mixed case -> lowercase
        if word.isupper() or (not word.islower() and not word.istitle()):
            result.append(word.lower())
        else:
            result.append(word)
    return ' '.join(result)


def clean_text(
    text: str,
    lowercase: bool = True,
    normalize_chars: bool = True,
    remove_emphasis: bool = False,
    collapse_punct: bool = False,
    expand_contract: bool = False,
    strip_urls: bool = True,
    strip_emails: bool = True,
    strip_html: bool = True,
    strip_special: bool = False,
    strip_numbers: bool = False,
    remove_fillers: bool = False,
    remove_discourse: bool = False,
    semantic_normalize: bool = False,
    normalize_nums: bool = False,
    remove_parens: bool = False,
    simplify_punct: bool = False,
    deduplicate: bool = False,
    remove_redundant: bool = False,
    remove_stopwords_flag: bool = False,
    remove_starters: bool = False,
    simplify_redundant: bool = False,
    strip_quotes: bool = False,
    flatten_case: bool = False,
) -> str:
    """
    Apply comprehensive text cleaning optimized for sequence length reduction.

    Args:
        text: Input text
        lowercase: Convert to lowercase
        normalize_chars: Normalize unicode characters
        remove_emphasis: Remove emphasis words
        collapse_punct: Collapse duplicate punctuation
        expand_contract: Expand contractions
        strip_urls: Remove URLs
        strip_emails: Remove email addresses
        strip_html: Remove HTML tags
        strip_special: Remove special characters
        strip_numbers: Remove standalone numbers
        remove_fillers: Remove filler words (um, like, you know, etc.)
        remove_discourse: Remove discourse markers (however, therefore, etc.)
        semantic_normalize: Normalize phrases to canonical forms
        normalize_nums: Normalize numbers to generic tokens
        remove_parens: Remove parenthetical expressions
        simplify_punct: Simplify punctuation to canonical forms
        deduplicate: Remove adjacent duplicate words
        remove_redundant: Remove redundant modifiers (very, really, etc.)
        remove_stopwords_flag: Aggressively remove stopwords
        remove_starters: Remove unnecessary sentence starters
        simplify_redundant: Simplify redundant phrases
        strip_quotes: Remove quotation marks
        flatten_case: Flatten ALL CAPS and MiXeD CaSe

    Returns:
        Cleaned text
    """
    if not text:
        return ""

    # Order matters for some operations
    # 1. Remove markup and non-text content first
    if strip_html:
        text = remove_html_tags(text)

    if strip_urls:
        text = remove_urls(text)

    if strip_emails:
        text = remove_emails(text)

    if remove_parens:
        text = remove_parentheticals(text)

    # 2. Normalize characters and case
    if normalize_chars:
        text = normalize_unicode(text)

    if simplify_punct:
        text = simplify_punctuation(text)

    if expand_contract:
        text = expand_contractions(text)

    if lowercase:
        text = text.lower()

    # 3. Semantic normalizations (must come after lowercase)
    if semantic_normalize:
        text = apply_semantic_normalizations(text)

    # 4. Remove noise words
    if remove_fillers:
        text = filter_filler_words(text)

    if remove_discourse:
        text = filter_discourse_markers(text)

    if remove_emphasis:
        text = filter_emphasis_words(text)

    if remove_redundant:
        text = remove_redundant_modifiers(text)

    if remove_starters:
        text = remove_sentence_starters(text)

    if simplify_redundant:
        text = simplify_redundant_phrases(text)

    # 5. Handle punctuation and numbers
    if collapse_punct:
        text = collapse_punctuation(text)

    if strip_special:
        text = remove_special_chars(text)

    if strip_quotes:
        text = remove_quotes(text)

    if normalize_nums:
        text = normalize_numbers(text)
    elif strip_numbers:
        text = remove_numbers(text)

    # 6. Aggressive reduction (optional)
    if remove_stopwords_flag:
        text = remove_stopwords(text)

    if flatten_case:
        text = flatten_case_variations(text)

    # 7. Final cleanup
    if deduplicate:
        text = deduplicate_adjacent(text)

    text = normalize_whitespace_around_punct(text)

    # Always collapse whitespace at the end
    text = collapse_whitespace(text)

    return text


def clean_file(
    input_path: str,
    output_path: str,
    **clean_options,
) -> dict:
    """
    Clean a text file and write to output.

    Returns statistics about the cleaning process.
    """
    with open(input_path, 'r', encoding='utf-8', errors='ignore') as f:
        original_text = f.read()

    cleaned_text = clean_text(original_text, **clean_options)

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(cleaned_text)

    return {
        'input_path': input_path,
        'output_path': output_path,
        'original_chars': len(original_text),
        'cleaned_chars': len(cleaned_text),
        'reduction_pct': round(
            (len(original_text) - len(cleaned_text)) / max(len(original_text), 1) * 100, 2
        ),
    }


def iter_clean_lines(
    input_path: str,
    **clean_options,
) -> Iterator[str]:
    """Iterate over cleaned lines from a file."""
    with open(input_path, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            cleaned = clean_text(line, **clean_options)
            if cleaned:
                yield cleaned
