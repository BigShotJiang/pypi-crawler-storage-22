#!/usr/bin/env python3
"""Comprehensive test suite for all Ion features."""

import json
import os
import sys
import tempfile
import shutil
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from ion.tokenizer import IonTokenizer, SPECIAL_TOKENS, FALLBACK_ALPHABET
from ion.builder import TokenizerBuilder, build_tokenizer, iterate_tokenizer
from ion.corpus import parse_huggingface_url, load_corpus, normalize_text
from ion.phrase_discovery import PhraseDiscoverer
from ion.stats import compute_stats, format_stats
from ion.utils import (
    clean_text, clean_file, collapse_punctuation, remove_urls,
    remove_emails, remove_html_tags, expand_contractions, remove_numbers,
    filter_emphasis_words, filter_filler_words, filter_discourse_markers,
    apply_semantic_normalizations, normalize_numbers, remove_parentheticals,
    simplify_punctuation, deduplicate_adjacent, remove_redundant_modifiers,
    remove_stopwords, remove_sentence_starters, simplify_redundant_phrases,
    flatten_case_variations, normalize_unicode, collapse_whitespace, remove_quotes,
)
from ion.tools import (
    get_domain_config, list_domains, DOMAIN_CONFIGS,
    export_huggingface, export_sentencepiece, export_vocab_txt,
    export_onnx, export_tiktoken, export_jsonl, export_csv,
    introspect_fallbacks, create_reproducibility_snapshot, verify_reproducibility,
    set_seed,
)
from ion.benchmarks import (
    load_benchmarks, format_benchmark_summary, format_quick_stats,
    get_ascii_chart, BASELINE_BENCHMARKS,
)
from ion.integrations import (
    IonTokenizerHF, IonDataset, IonLanguageModelDataset, BatchEncoding,
    ion_collate_fn, IonDataModule, IonTrainingArguments,
    export_for_onnx, export_for_sentencepiece,
)

import orjson

passed = 0
failed = 0
errors = []

def test(name):
    def decorator(fn):
        global passed, failed
        try:
            fn()
            passed += 1
            print(f"  PASS: {name}")
        except Exception as e:
            failed += 1
            errors.append((name, str(e)))
            print(f"  FAIL: {name} - {e}")
    return decorator

# Helper: create a test corpus file
def create_test_corpus(n_sentences=500):
    """Create a realistic test corpus."""
    sentences = []
    phrases = [
        "united states", "new york", "machine learning", "artificial intelligence",
        "according to", "as well as", "in order to", "such as",
        "one of the", "in addition to", "the fact that", "as a result",
        "climate change", "public health", "data science", "world war",
    ]
    nouns = ["system", "process", "study", "model", "framework", "policy", "result"]
    adjs = ["significant", "important", "new", "large", "strong", "positive"]

    import random
    random.seed(42)
    templates = [
        "The {noun} of the {phrase} was {adj} and notable.",
        "According to the report, {phrase} is very important.",
        "In the {phrase}, many researchers study {noun} development.",
        "One of the most {adj} aspects is the {phrase} approach.",
        "As a result of {phrase}, the {noun} has improved significantly.",
        "The {adj} {noun} in {phrase} demonstrates good results.",
    ]

    for i in range(n_sentences):
        template = random.choice(templates)
        sent = template.format(
            noun=random.choice(nouns),
            phrase=random.choice(phrases),
            adj=random.choice(adjs),
        )
        sentences.append(sent)

    tmp = tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False)
    tmp.write('\n'.join(sentences))
    tmp.close()
    return tmp.name

# Create test corpus once
CORPUS_PATH = create_test_corpus(1000)
TOKENIZER_PATH = None

def build_test_tokenizer():
    """Build a tokenizer for testing."""
    global TOKENIZER_PATH
    if TOKENIZER_PATH and Path(TOKENIZER_PATH).exists():
        return TOKENIZER_PATH

    TOKENIZER_PATH = tempfile.mktemp(suffix='.json')
    build_tokenizer(
        source=CORPUS_PATH,
        output=TOKENIZER_PATH,
        max_vocab_size=5000,
        min_word_freq=1,
        min_phrase_freq=2,
        max_sentences=1000,
        enable_bpe_fallback=True,
        bpe_vocab_size=2000,
    )
    return TOKENIZER_PATH


# ============================================================================
# 1. TOKENIZER CORE TESTS
# ============================================================================
print("\n" + "=" * 60)
print("1. TOKENIZER CORE")
print("=" * 60)

@test("IonTokenizer basic construction")
def _():
    tok = IonTokenizer(
        phrases=["united states", "new york", "as well as"],
        words=["hello", "world", "the", "is"],
    )
    assert tok.vocab_size() > 0
    assert "<pad>" in tok.vocab
    assert "<unk>" in tok.vocab
    assert "<bos>" in tok.vocab
    assert "<eos>" in tok.vocab
    assert "united states" in tok.vocab
    assert "hello" in tok.vocab

@test("IonTokenizer encode basic text")
def _():
    tok = IonTokenizer(
        phrases=["united states", "new york"],
        words=["the", "is", "in", "a", "great", "country"],
    )
    ids = tok.encode("the united states is a great country")
    assert len(ids) > 0
    assert all(isinstance(i, int) for i in ids)

@test("IonTokenizer encode captures phrases")
def _():
    tok = IonTokenizer(
        phrases=["united states", "new york city"],
        words=["the", "is", "in", "and", "a", "great", "country"],
    )
    ids = tok.encode("the united states is a great country")
    # "united states" should be a single token
    assert tok.vocab["united states"] in ids

@test("IonTokenizer encode longer phrase takes priority")
def _():
    tok = IonTokenizer(
        phrases=["new york", "new york city"],
        words=["the", "is", "in"],
    )
    ids = tok.encode("in new york city")
    assert tok.vocab["new york city"] in ids

@test("IonTokenizer decode round-trip")
def _():
    tok = IonTokenizer(
        phrases=["united states"],
        words=["the", "is", "a", "great", "country"],
    )
    text = "the united states is a great country"
    ids = tok.encode(text)
    decoded = tok.decode(ids)
    # Should contain the key words
    assert "united states" in decoded
    assert "great" in decoded
    assert "country" in decoded

@test("IonTokenizer character fallback")
def _():
    tok = IonTokenizer(
        phrases=[],
        words=["hello"],
        fallback_mode="character",
    )
    ids = tok.encode("hello xyz")
    assert len(ids) > 0
    # "xyz" should be character tokens
    decoded = tok.decode(ids)
    assert "hello" in decoded

@test("IonTokenizer word fallback mode")
def _():
    tok = IonTokenizer(
        phrases=[],
        words=["hello"],
        fallback_mode="word",
    )
    ids = tok.encode("hello xyz")
    # "xyz" should be <unk>
    assert tok.vocab.get("<unk>", 1) in ids

@test("IonTokenizer to_dict and from_dict")
def _():
    tok = IonTokenizer(
        phrases=["united states", "new york"],
        words=["the", "is", "hello"],
    )
    data = tok.to_dict()
    tok2 = IonTokenizer.from_dict(data)
    assert tok.vocab_size() == tok2.vocab_size()
    assert tok.encode("the united states") == tok2.encode("the united states")

@test("IonTokenizer empty input")
def _():
    tok = IonTokenizer(phrases=[], words=["hello"])
    assert tok.encode("") == []
    assert tok.encode("   ") == []

@test("IonTokenizer punctuation handling")
def _():
    tok = IonTokenizer(
        phrases=[],
        words=["hello", "world"],
    )
    ids = tok.encode("hello, world!")
    assert len(ids) > 0

@test("IonTokenizer special characters")
def _():
    tok = IonTokenizer(
        phrases=[],
        words=["test", "email"],
    )
    ids = tok.encode("test@email.com")
    assert len(ids) > 0

@test("IonTokenizer vocab_size correct")
def _():
    tok = IonTokenizer(
        phrases=["a b"],
        words=["c", "d"],
    )
    expected = len(SPECIAL_TOKENS) + 1 + 2 + len(FALLBACK_ALPHABET)
    assert tok.vocab_size() == expected

@test("IonTokenizer set_fallback_mode")
def _():
    tok = IonTokenizer(phrases=[], words=["hello"])
    tok.set_fallback_mode("character")
    assert tok.fallback_mode == "character"
    tok.set_fallback_mode("word")
    assert tok.fallback_mode == "word"
    tok.set_fallback_mode("bpe")
    assert tok.fallback_mode == "bpe"
    try:
        tok.set_fallback_mode("invalid")
        assert False, "Should have raised ValueError"
    except ValueError:
        pass

@test("IonTokenizer BPE fallback mode without BPE tokenizer falls back to character")
def _():
    tok = IonTokenizer(
        phrases=[],
        words=["hello"],
        fallback_mode="bpe",
        bpe_tokenizer=None,
    )
    ids = tok.encode("hello xyz")
    assert len(ids) > 0  # Should use character fallback

@test("IonTokenizer phrase trie correctness")
def _():
    tok = IonTokenizer(
        phrases=["a b", "a b c", "x y"],
        words=["d"],
    )
    # Should match "a b c" (longest match)
    match = tok._match_phrase(["a", "b", "c", "d"], 0)
    assert match is not None
    assert match[0] == "a b c"
    assert match[1] == 3

@test("IonTokenizer large vocabulary")
def _():
    phrases = [f"phrase {i} word" for i in range(100)]
    words = [f"word{i}" for i in range(500)]
    tok = IonTokenizer(phrases=phrases, words=words)
    assert tok.vocab_size() > 600

@test("IonTokenizer unicode text")
def _():
    tok = IonTokenizer(phrases=[], words=["hello", "world"])
    # Should handle unicode without crashing
    ids = tok.encode("hello world caf\u00e9")
    assert len(ids) > 0


# ============================================================================
# 2. BUILDER TESTS
# ============================================================================
print("\n" + "=" * 60)
print("2. BUILDER")
print("=" * 60)

@test("build_tokenizer from file")
def _():
    path = build_test_tokenizer()
    assert Path(path).exists()
    data = orjson.loads(Path(path).read_bytes())
    assert "vocab" in data
    assert "token_classes" in data
    assert data["vocab_size"] > 0

@test("build_tokenizer stats returned")
def _():
    tmp = tempfile.mktemp(suffix='.json')
    stats = build_tokenizer(
        source=CORPUS_PATH,
        output=tmp,
        max_vocab_size=2000,
        max_sentences=200,
    )
    assert "vocab_size" in stats
    assert "phrase_count" in stats
    assert "word_count" in stats
    assert stats["vocab_size"] > 0
    Path(tmp).unlink(missing_ok=True)

@test("build_tokenizer take-needed mode")
def _():
    tmp = tempfile.mktemp(suffix='.json')
    stats = build_tokenizer(
        source=CORPUS_PATH,
        output=tmp,
        max_vocab_size=1000,
        take_needed=True,
        max_sentences=200,
    )
    assert stats.get("mode") == "take_needed"
    Path(tmp).unlink(missing_ok=True)

@test("TokenizerBuilder step by step")
def _():
    builder = TokenizerBuilder(
        max_vocab_size=2000,
        min_word_freq=1,
        max_sentences=200,
    )
    builder.load_corpus(CORPUS_PATH)
    assert len(builder.sentences) > 0
    builder.discover_phrases()
    tok = builder.build_tokenizer()
    assert tok.vocab_size() > 0
    assert builder.stats["vocab_size"] > 0

@test("iterate_tokenizer")
def _():
    path = build_test_tokenizer()
    tmp2 = tempfile.mktemp(suffix='.json')
    stats = iterate_tokenizer(
        tokenizer_path=path,
        source=CORPUS_PATH,
        output=tmp2,
        max_sentences=100,
    )
    assert "new_phrases_added" in stats
    assert "new_words_added" in stats
    assert "final_vocab_size" in stats
    assert Path(tmp2).exists()
    Path(tmp2).unlink(missing_ok=True)


# ============================================================================
# 3. CORPUS LOADING TESTS
# ============================================================================
print("\n" + "=" * 60)
print("3. CORPUS LOADING")
print("=" * 60)

@test("parse_huggingface_url - simple identifier")
def _():
    is_hf, ds_id, config = parse_huggingface_url("wikitext")
    assert not is_hf  # simple identifiers are not detected as HF by URL parser
    # They get caught by the load_corpus fallback to HF

@test("parse_huggingface_url - org/dataset")
def _():
    is_hf, ds_id, config = parse_huggingface_url("https://huggingface.co/datasets/allenai/c4")
    assert is_hf
    assert ds_id == "allenai/c4"

@test("parse_huggingface_url - full URL simple")
def _():
    is_hf, ds_id, config = parse_huggingface_url("https://huggingface.co/datasets/wikitext")
    assert is_hf
    assert ds_id == "wikitext"

@test("parse_huggingface_url - full URL with config")
def _():
    is_hf, ds_id, config = parse_huggingface_url("https://huggingface.co/datasets/allenai/c4/en")
    assert is_hf
    assert ds_id == "allenai/c4"
    assert config == "en"

@test("parse_huggingface_url - hf:// prefix")
def _():
    is_hf, ds_id, config = parse_huggingface_url("hf://wikitext")
    assert is_hf
    assert ds_id == "wikitext"

@test("parse_huggingface_url - hf: prefix")
def _():
    is_hf, ds_id, config = parse_huggingface_url("hf:wikitext")
    assert is_hf
    assert ds_id == "wikitext"

@test("parse_huggingface_url - hf:/ prefix")
def _():
    is_hf, ds_id, config = parse_huggingface_url("hf:/wikitext")
    assert is_hf
    assert ds_id == "wikitext"

@test("parse_huggingface_url - local file path")
def _():
    is_hf, ds_id, config = parse_huggingface_url("/tmp/corpus.txt")
    assert not is_hf

@test("load_corpus from local file")
def _():
    sentences = list(load_corpus(CORPUS_PATH))
    assert len(sentences) > 0
    assert all(isinstance(s, list) for s in sentences)
    assert all(isinstance(w, str) for s in sentences for w in s)

@test("load_corpus from directory")
def _():
    tmpdir = tempfile.mkdtemp()
    # Write a few test files
    for i in range(3):
        (Path(tmpdir) / f"test{i}.txt").write_text(
            f"This is test file number {i}. It has some text."
        )
    sentences = list(load_corpus(tmpdir))
    assert len(sentences) > 0
    shutil.rmtree(tmpdir)

@test("normalize_text")
def _():
    assert normalize_text("  Hello   WORLD  ") == "hello world"
    assert normalize_text("Hello!!! World???", collapse_punctuation=True) == "hello! world?"


# ============================================================================
# 4. PHRASE DISCOVERY TESTS
# ============================================================================
print("\n" + "=" * 60)
print("4. PHRASE DISCOVERY")
print("=" * 60)

@test("PhraseDiscoverer basic discovery")
def _():
    discoverer = PhraseDiscoverer(min_count=2, threshold=0.001, max_layers=2)
    sentences = [
        ["the", "united", "states", "is", "a", "country"],
        ["the", "united", "states", "has", "many", "people"],
        ["the", "united", "states", "is", "large"],
        ["in", "the", "united", "states", "there", "are", "cities"],
        ["people", "in", "the", "united", "states", "speak", "english"],
    ] * 20
    phrases = discoverer.discover(iter(sentences), max_sentences=100)
    assert isinstance(phrases, dict)

@test("PhraseDiscoverer quality filter")
def _():
    d = PhraseDiscoverer()
    assert d._is_quality_phrase("united states") == True
    assert d._is_quality_phrase("a b") == False  # Too short words
    assert d._is_quality_phrase("<unk> test") == False  # Special tokens
    assert d._is_quality_phrase("@ test") == False  # Wiki artifacts
    assert d._is_quality_phrase(". test") == False  # Starts with punct
    assert d._is_quality_phrase("1 2 3") == False  # All numeric

@test("PhraseDiscoverer select_phrases_for_vocab")
def _():
    discoverer = PhraseDiscoverer(min_count=2, threshold=0.001, max_layers=2)
    sentences = [
        ["machine", "learning", "is", "important"],
        ["machine", "learning", "research", "grows"],
        ["the", "new", "york", "city", "is", "big"],
        ["new", "york", "has", "many", "people"],
    ] * 30
    discoverer.discover(iter(sentences), max_sentences=120)
    selected = discoverer.select_phrases_for_vocab(sentences, base_vocab_size=40, max_phrases=100)
    assert isinstance(selected, list)


# ============================================================================
# 5. TEXT CLEANING TESTS
# ============================================================================
print("\n" + "=" * 60)
print("5. TEXT CLEANING UTILITIES")
print("=" * 60)

@test("clean_text basic")
def _():
    result = clean_text("Hello World")
    assert result == "hello world"

@test("clean_text remove_urls")
def _():
    result = clean_text("Visit https://example.com today", strip_urls=True)
    assert "https" not in result
    assert "example" not in result

@test("clean_text remove_emails")
def _():
    result = clean_text("Contact test@example.com now", strip_emails=True)
    assert "@" not in result

@test("clean_text remove_html")
def _():
    result = clean_text("<p>Hello</p> <b>world</b>", strip_html=True)
    assert "<p>" not in result
    assert "hello" in result

@test("expand_contractions")
def _():
    result = expand_contractions("I can't do this")
    assert "cannot" in result

@test("collapse_punctuation")
def _():
    result = collapse_punctuation("Hello!!!! World????")
    assert "!!!!" not in result
    assert "????" not in result

@test("remove_numbers")
def _():
    result = remove_numbers("There are 42 apples and 100 oranges")
    assert "42" not in result
    assert "100" not in result

@test("filter_emphasis_words")
def _():
    result = filter_emphasis_words("This is very extremely important")
    assert "very" not in result
    assert "extremely" not in result
    assert "important" in result

@test("filter_filler_words")
def _():
    result = filter_filler_words("Um, like, I think this is, you know, interesting")
    assert "um" not in result.lower()

@test("filter_discourse_markers")
def _():
    result = filter_discourse_markers("However the results were significant")
    assert "however" not in result.lower()

@test("apply_semantic_normalizations")
def _():
    result = apply_semantic_normalizations("I'm gonna try to utilize this")
    assert "going to" in result
    assert "use" in result

@test("normalize_numbers")
def _():
    result = normalize_numbers("In 2024, there were 5 items costing $100")
    assert "<year>" in result or "<num>" in result

@test("remove_parentheticals")
def _():
    result = remove_parentheticals("Hello (this is extra) world")
    assert "(this is extra)" not in result
    assert "hello" in result.lower()

@test("simplify_punctuation")
def _():
    result = simplify_punctuation("Hello!!! World????")
    assert "!!!" not in result

@test("deduplicate_adjacent")
def _():
    result = deduplicate_adjacent("the the the cat sat sat")
    assert result == "the cat sat"

@test("remove_redundant_modifiers")
def _():
    result = remove_redundant_modifiers("It was very extremely important")
    assert "very" not in result
    assert "extremely" not in result

@test("remove_stopwords")
def _():
    result = remove_stopwords("The cat is on the mat")
    assert "the" not in result.split()
    assert "is" not in result.split()

@test("remove_sentence_starters")
def _():
    result = remove_sentence_starters("Well, I think this is important")
    assert not result.strip().lower().startswith("well")

@test("simplify_redundant_phrases")
def _():
    result = simplify_redundant_phrases("The end result was an unexpected surprise")
    assert "end result" not in result
    assert "unexpected surprise" not in result

@test("flatten_case_variations")
def _():
    result = flatten_case_variations("ALL CAPS and Normal text")
    assert "all caps" in result

@test("normalize_unicode")
def _():
    result = normalize_unicode("Hello\u2018world\u2019 \u2013 test")
    assert "\u2018" not in result
    assert "'" in result

@test("remove_quotes")
def _():
    result = remove_quotes('He said "hello" and \'goodbye\'')
    assert '"' not in result
    assert "'" not in result

@test("clean_text aggressive preset")
def _():
    text = 'Visit https://example.com and <b>contact</b> test@email.com!!! Very important!!!'
    result = clean_text(text, **{
        'lowercase': True, 'normalize_chars': True, 'remove_emphasis': True,
        'collapse_punct': True, 'expand_contract': True, 'strip_urls': True,
        'strip_emails': True, 'strip_html': True, 'simplify_punct': True,
    })
    assert "https" not in result
    assert "<b>" not in result
    assert "@" not in result

@test("clean_text extreme preset")
def _():
    text = "Well, I think the very important result was due to the fact that we utilized it."
    result = clean_text(text, **{
        'lowercase': True, 'normalize_chars': True, 'remove_emphasis': True,
        'collapse_punct': True, 'expand_contract': True, 'strip_urls': True,
        'strip_emails': True, 'strip_html': True, 'remove_fillers': True,
        'remove_discourse': True, 'semantic_normalize': True,
        'normalize_nums': True, 'remove_parens': True, 'simplify_punct': True,
        'deduplicate': True, 'remove_redundant': True, 'remove_stopwords_flag': True,
        'remove_starters': True, 'simplify_redundant': True,
        'strip_quotes': True, 'flatten_case': True,
    })
    assert len(result) < len(text)

@test("clean_file")
def _():
    tmp_in = tempfile.mktemp(suffix='.txt')
    tmp_out = tempfile.mktemp(suffix='.txt')
    Path(tmp_in).write_text("Hello WORLD!!! Visit https://example.com now!!!")
    stats = clean_file(tmp_in, tmp_out, strip_urls=True, collapse_punct=True)
    assert stats['reduction_pct'] > 0
    assert Path(tmp_out).exists()
    Path(tmp_in).unlink()
    Path(tmp_out).unlink()


# ============================================================================
# 6. STATS TESTS
# ============================================================================
print("\n" + "=" * 60)
print("6. STATS")
print("=" * 60)

@test("compute_stats without corpus")
def _():
    path = build_test_tokenizer()
    stats = compute_stats(tokenizer_path=path)
    assert "vocab_size" in stats
    assert "phrase_tokens" in stats
    assert "word_tokens" in stats
    assert stats["vocab_size"] > 0

@test("compute_stats with corpus")
def _():
    path = build_test_tokenizer()
    stats = compute_stats(tokenizer_path=path, corpus_source=CORPUS_PATH, max_samples=100)
    assert "compressed_tokens" in stats
    assert "sequence_length_reduction_pct" in stats

@test("format_stats")
def _():
    stats = {"vocab_size": 1000, "special_tokens": 4, "phrase_tokens": 50,
             "word_tokens": 900, "fallback_tokens": 46}
    result = format_stats(stats)
    assert "1,000" in result
    assert "Phrase tokens" in result


# ============================================================================
# 7. TOOLS TESTS
# ============================================================================
print("\n" + "=" * 60)
print("7. TOOLS")
print("=" * 60)

@test("get_domain_config returns valid config")
def _():
    for domain in ["general", "wikipedia", "code", "legal", "chat", "medical", "scientific"]:
        config = get_domain_config(domain)
        assert "min_word_freq" in config
        assert "min_phrase_freq" in config
        assert "phrase_threshold" in config
        assert "max_phrase_layers" in config

@test("list_domains returns all domains")
def _():
    domains = list_domains()
    assert "general" in domains
    assert "wikipedia" in domains
    assert "legal" in domains
    assert len(domains) == 7

@test("DOMAIN_CONFIGS structure")
def _():
    for domain, config in DOMAIN_CONFIGS.items():
        assert "description" in config
        assert "phrase_boosters" in config or domain == "general"

@test("introspect_fallbacks")
def _():
    path = build_test_tokenizer()
    result = introspect_fallbacks(path, "hello world xylophone")
    assert "total_words" in result
    assert "fallback_words" in result
    assert "fallback_rate" in result

@test("export_huggingface")
def _():
    path = build_test_tokenizer()
    tmpdir = tempfile.mkdtemp()
    result = export_huggingface(path, tmpdir)
    assert (Path(tmpdir) / "tokenizer.json").exists()
    assert (Path(tmpdir) / "tokenizer_config.json").exists()
    assert (Path(tmpdir) / "special_tokens_map.json").exists()
    shutil.rmtree(tmpdir)

@test("export_sentencepiece")
def _():
    path = build_test_tokenizer()
    tmp = tempfile.mktemp(suffix='.spm')
    result = export_sentencepiece(path, tmp)
    assert Path(tmp).exists()
    content = Path(tmp).read_text()
    assert "<pad>" in content
    Path(tmp).unlink()

@test("export_vocab_txt")
def _():
    path = build_test_tokenizer()
    tmp = tempfile.mktemp(suffix='.txt')
    result = export_vocab_txt(path, tmp)
    assert Path(tmp).exists()
    content = Path(tmp).read_text()
    assert "<pad>" in content
    Path(tmp).unlink()

@test("export_vocab_txt without ids")
def _():
    path = build_test_tokenizer()
    tmp = tempfile.mktemp(suffix='.txt')
    result = export_vocab_txt(path, tmp, include_ids=False)
    content = Path(tmp).read_text()
    lines = content.strip().split('\n')
    assert "\t" not in lines[0]  # No tab means no IDs
    Path(tmp).unlink()

@test("export_onnx creates vocab.txt and config.json")
def _():
    path = build_test_tokenizer()
    tmp_dir = tempfile.mkdtemp()
    result = export_onnx(path, tmp_dir)
    assert Path(tmp_dir, "vocab.txt").exists()
    assert Path(tmp_dir, "config.json").exists()
    import json
    config = json.loads(Path(tmp_dir, "config.json").read_text())
    assert "vocab_size" in config
    assert config["model_type"] == "ion"
    import shutil
    shutil.rmtree(tmp_dir)

@test("export_tiktoken creates base64 encoded file")
def _():
    path = build_test_tokenizer()
    tmp = tempfile.mktemp(suffix='.tiktoken')
    result = export_tiktoken(path, tmp)
    content = Path(tmp).read_text()
    lines = content.strip().split('\n')
    assert len(lines) > 0
    # Each line should be "base64 rank"
    parts = lines[0].split(' ')
    assert len(parts) == 2
    assert parts[1].isdigit()
    import base64
    base64.b64decode(parts[0])  # Should not raise
    Path(tmp).unlink()

@test("export_jsonl creates valid JSON lines with token metadata")
def _():
    path = build_test_tokenizer()
    tmp = tempfile.mktemp(suffix='.jsonl')
    result = export_jsonl(path, tmp)
    content = Path(tmp).read_text()
    lines = content.strip().split('\n')
    assert len(lines) > 0
    import json
    entry = json.loads(lines[0])
    assert "id" in entry
    assert "token" in entry
    assert "type" in entry
    assert "bytes" in entry
    assert entry["type"] in ("special", "phrase", "word", "subword")
    Path(tmp).unlink()

@test("export_csv creates valid CSV with header")
def _():
    path = build_test_tokenizer()
    tmp = tempfile.mktemp(suffix='.csv')
    result = export_csv(path, tmp)
    content = Path(tmp).read_text()
    lines = content.strip().split('\n')
    assert lines[0] == "id,token,type,length,byte_length"
    assert len(lines) > 1
    # Check a data row has 5 columns
    parts = lines[1].split(',')
    assert len(parts) >= 5
    Path(tmp).unlink()

@test("create and verify reproducibility snapshot")
def _():
    path = build_test_tokenizer()
    snap = tempfile.mktemp(suffix='.json')
    config = {"max_vocab_size": 5000, "min_word_freq": 1}
    create_reproducibility_snapshot(path, CORPUS_PATH, 42, config, snap)
    assert Path(snap).exists()

    result = verify_reproducibility(snap, path)
    assert result["match"] == True
    assert result["seed"] == 42
    Path(snap).unlink()

@test("set_seed determinism")
def _():
    import random
    set_seed(42)
    a = random.random()
    set_seed(42)
    b = random.random()
    assert a == b


# ============================================================================
# 8. BENCHMARKS MODULE TESTS
# ============================================================================
print("\n" + "=" * 60)
print("8. BENCHMARKS MODULE")
print("=" * 60)

@test("BASELINE_BENCHMARKS structure")
def _():
    assert "vocab_sweep" in BASELINE_BENCHMARKS
    assert "ion_vs_bpe" in BASELINE_BENCHMARKS
    assert "domain_benchmarks" in BASELINE_BENCHMARKS
    assert "phrase_accountability" in BASELINE_BENCHMARKS

@test("BASELINE_BENCHMARKS has HF dataset matrix with 12 datasets")
def _():
    assert "hf_dataset_matrix" in BASELINE_BENCHMARKS
    matrix = BASELINE_BENCHMARKS["hf_dataset_matrix"]
    assert len(matrix["datasets"]) == 12
    summary = matrix["summary"]
    assert summary["total_comparisons"] == 96
    assert summary["ion_bpe_wins"] == 96
    assert summary["ion_nw_wins"] == 96
    # All advantages should be positive
    for ds_name, ds_data in matrix["datasets"].items():
        for r in ds_data["results"]:
            assert r["ion_bpe_adv"] > 0, f"{ds_name} at {r['vocab']}: ion_bpe_adv should be positive"
            assert r["ion_nw_adv"] > 0, f"{ds_name} at {r['vocab']}: ion_nw_adv should be positive"

@test("BASELINE_BENCHMARKS has phrase_pct_cross_dataset analysis")
def _():
    assert "phrase_pct_cross_dataset" in BASELINE_BENCHMARKS
    data = BASELINE_BENCHMARKS["phrase_pct_cross_dataset"]
    assert len(data["results"]) == 5
    # 60% should be better than 20% for all datasets
    for ds_name, pct_data in data["results"].items():
        assert pct_data["60%"]["advantage"] > pct_data["20%"]["advantage"], f"{ds_name}: 60% should beat 20%"

@test("load_benchmarks returns data")
def _():
    data = load_benchmarks()
    assert "vocab_sweep" in data

@test("format_benchmark_summary")
def _():
    result = format_benchmark_summary()
    assert "ION" in result
    assert "VOCAB" in result.upper() or "Vocab" in result

@test("format_quick_stats")
def _():
    result = format_quick_stats()
    assert "%" in result

@test("get_ascii_chart")
def _():
    result = get_ascii_chart()
    assert "#" in result or "No vocab sweep" in result


# ============================================================================
# 9. INTEGRATIONS TESTS
# ============================================================================
print("\n" + "=" * 60)
print("9. INTEGRATIONS")
print("=" * 60)

@test("BatchEncoding basic")
def _():
    be = BatchEncoding(input_ids=[[1, 2, 3]], attention_mask=[[1, 1, 1]])
    assert be["input_ids"] == [[1, 2, 3]]
    assert "input_ids" in be
    assert "attention_mask" in be
    assert set(be.keys()) == {"input_ids", "attention_mask"}

@test("BatchEncoding to_dict")
def _():
    be = BatchEncoding(input_ids=[[1, 2]], attention_mask=[[1, 1]])
    d = be.to_dict()
    assert "input_ids" in d

@test("IonTokenizerHF from_pretrained")
def _():
    path = build_test_tokenizer()
    hf_tok = IonTokenizerHF.from_pretrained(path)
    assert hf_tok.vocab_size > 0
    assert hf_tok.pad_token_id == 0

@test("IonTokenizerHF encode/decode")
def _():
    path = build_test_tokenizer()
    hf_tok = IonTokenizerHF.from_pretrained(path)
    ids = hf_tok.encode("hello world")
    assert len(ids) > 0
    text = hf_tok.decode(ids)
    assert isinstance(text, str)

@test("IonTokenizerHF __call__ single text")
def _():
    path = build_test_tokenizer()
    hf_tok = IonTokenizerHF.from_pretrained(path)
    result = hf_tok("hello world")
    assert hasattr(result, 'input_ids') or 'input_ids' in result

@test("IonTokenizerHF __call__ batch")
def _():
    path = build_test_tokenizer()
    hf_tok = IonTokenizerHF.from_pretrained(path)
    result = hf_tok(["hello world", "foo bar"], padding=True)
    assert len(result.input_ids) == 2

@test("IonTokenizerHF with padding and truncation")
def _():
    path = build_test_tokenizer()
    hf_tok = IonTokenizerHF.from_pretrained(path)
    result = hf_tok(
        ["hello", "hello world this is a longer sentence"],
        padding=True,
        truncation=True,
        max_length=20,
    )
    assert len(result.input_ids[0]) == len(result.input_ids[1])

@test("IonTokenizerHF save_pretrained and reload")
def _():
    path = build_test_tokenizer()
    hf_tok = IonTokenizerHF.from_pretrained(path)

    tmpdir = tempfile.mkdtemp()
    hf_tok.save_pretrained(tmpdir)
    assert (Path(tmpdir) / "tokenizer.json").exists()
    assert (Path(tmpdir) / "tokenizer_config.json").exists()

    hf_tok2 = IonTokenizerHF.from_pretrained(tmpdir)
    assert hf_tok2.vocab_size == hf_tok.vocab_size
    shutil.rmtree(tmpdir)

@test("IonTokenizerHF batch_decode")
def _():
    path = build_test_tokenizer()
    hf_tok = IonTokenizerHF.from_pretrained(path)
    ids_batch = [hf_tok.encode("hello"), hf_tok.encode("world")]
    texts = hf_tok.batch_decode(ids_batch)
    assert len(texts) == 2

@test("IonTokenizerHF convert_tokens_to_ids")
def _():
    path = build_test_tokenizer()
    hf_tok = IonTokenizerHF.from_pretrained(path)
    # Single token
    tid = hf_tok.convert_tokens_to_ids("<pad>")
    assert tid == 0
    # List
    tids = hf_tok.convert_tokens_to_ids(["<pad>", "<unk>"])
    assert tids == [0, 1]

@test("IonTokenizerHF convert_ids_to_tokens")
def _():
    path = build_test_tokenizer()
    hf_tok = IonTokenizerHF.from_pretrained(path)
    tok = hf_tok.convert_ids_to_tokens(0)
    assert tok == "<pad>"

@test("IonTokenizerHF get_vocab")
def _():
    path = build_test_tokenizer()
    hf_tok = IonTokenizerHF.from_pretrained(path)
    v = hf_tok.get_vocab()
    assert "<pad>" in v

@test("IonTokenizerHF len")
def _():
    path = build_test_tokenizer()
    hf_tok = IonTokenizerHF.from_pretrained(path)
    assert len(hf_tok) > 0

@test("IonTokenizerHF pad")
def _():
    path = build_test_tokenizer()
    hf_tok = IonTokenizerHF.from_pretrained(path)
    result = hf_tok.pad(
        BatchEncoding(input_ids=[[1, 2, 3], [4, 5]]),
        padding=True,
    )
    assert len(result.input_ids[0]) == len(result.input_ids[1])

@test("IonDataset basic")
def _():
    path = build_test_tokenizer()
    hf_tok = IonTokenizerHF.from_pretrained(path)
    ds = IonDataset(
        texts=["hello world", "foo bar"],
        tokenizer=hf_tok,
        max_length=32,
    )
    assert len(ds) == 2
    item = ds[0]
    assert "input_ids" in item

@test("IonLanguageModelDataset")
def _():
    path = build_test_tokenizer()
    hf_tok = IonTokenizerHF.from_pretrained(path)
    ds = IonLanguageModelDataset(
        texts=["hello world this is a test. Another sentence here."] * 10,
        tokenizer=hf_tok,
        block_size=16,
    )
    if len(ds) > 0:
        item = ds[0]
        assert "input_ids" in item
        assert "labels" in item
        assert len(item["input_ids"]) == 16

@test("IonTrainingArguments")
def _():
    args = IonTrainingArguments(
        output_dir="./test",
        num_train_epochs=3,
        per_device_train_batch_size=32,
    )
    assert args.output_dir == "./test"
    assert args.num_train_epochs == 3

@test("IonDataModule")
def _():
    path = build_test_tokenizer()
    hf_tok = IonTokenizerHF.from_pretrained(path)
    dm = IonDataModule(
        train_texts=["hello world", "foo bar"],
        tokenizer=hf_tok,
        batch_size=2,
        max_length=32,
    )
    dm.setup("fit")
    assert hasattr(dm, 'train_dataset')

@test("export_for_onnx")
def _():
    path = build_test_tokenizer()
    data = orjson.loads(Path(path).read_bytes())
    tok = IonTokenizer.from_dict(data)
    tmpdir = tempfile.mkdtemp()
    export_for_onnx(tok, tmpdir)
    assert (Path(tmpdir) / "vocab.txt").exists()
    assert (Path(tmpdir) / "config.json").exists()
    shutil.rmtree(tmpdir)

@test("export_for_sentencepiece integration")
def _():
    path = build_test_tokenizer()
    data = orjson.loads(Path(path).read_bytes())
    tok = IonTokenizer.from_dict(data)
    tmp = tempfile.mktemp(suffix='.vocab')
    export_for_sentencepiece(tok, tmp)
    assert Path(tmp).exists()
    Path(tmp).unlink()


# ============================================================================
# 10. CLI TESTS (via Click testing)
# ============================================================================
print("\n" + "=" * 60)
print("10. CLI COMMANDS")
print("=" * 60)

from click.testing import CliRunner
from ion.cli import main

runner = CliRunner()

@test("CLI help command")
def _():
    result = runner.invoke(main, ['help'])
    assert result.exit_code == 0
    assert "Ion" in result.output

@test("CLI benchmarks command")
def _():
    result = runner.invoke(main, ['benchmarks'])
    assert result.exit_code == 0
    assert "ION" in result.output or "Vocab" in result.output

@test("CLI benchmarks --quick")
def _():
    result = runner.invoke(main, ['benchmarks', '--quick'])
    assert result.exit_code == 0
    assert "%" in result.output

@test("CLI benchmarks --chart")
def _():
    result = runner.invoke(main, ['benchmarks', '--chart'])
    assert result.exit_code == 0

@test("CLI domains command")
def _():
    result = runner.invoke(main, ['domains'])
    assert result.exit_code == 0
    assert "wikipedia" in result.output
    assert "legal" in result.output

@test("CLI tokenize from file")
def _():
    tmp_out = tempfile.mktemp(suffix='.json')
    result = runner.invoke(main, [
        'tokenize', CORPUS_PATH,
        '-o', tmp_out,
        '--max-vocab', '2000',
        '--max-sentences', '200',
    ])
    assert result.exit_code == 0, f"Exit code: {result.exit_code}, Output: {result.output}"
    assert Path(tmp_out).exists()
    Path(tmp_out).unlink(missing_ok=True)

@test("CLI tokenize with domain")
def _():
    tmp_out = tempfile.mktemp(suffix='.json')
    result = runner.invoke(main, [
        'tokenize', CORPUS_PATH,
        '-o', tmp_out,
        '--max-vocab', '2000',
        '--max-sentences', '200',
        '--domain', 'wikipedia',
    ])
    assert result.exit_code == 0, f"Output: {result.output}"
    assert "wikipedia" in result.output.lower()
    Path(tmp_out).unlink(missing_ok=True)

@test("CLI tokenize with take-needed")
def _():
    tmp_out = tempfile.mktemp(suffix='.json')
    result = runner.invoke(main, [
        'tokenize', CORPUS_PATH,
        '-o', tmp_out,
        '-tn',
        '--max-sentences', '200',
    ])
    assert result.exit_code == 0, f"Output: {result.output}"
    assert "TAKE-NEEDED" in result.output
    Path(tmp_out).unlink(missing_ok=True)

@test("CLI tokenize with seed and snapshot")
def _():
    tmp_out = tempfile.mktemp(suffix='.json')
    snap_out = tempfile.mktemp(suffix='.json')
    result = runner.invoke(main, [
        'tokenize', CORPUS_PATH,
        '-o', tmp_out,
        '--max-vocab', '2000',
        '--max-sentences', '200',
        '--seed', '42',
        '--snapshot', snap_out,
    ])
    assert result.exit_code == 0, f"Output: {result.output}"
    assert Path(snap_out).exists()
    Path(tmp_out).unlink(missing_ok=True)
    Path(snap_out).unlink(missing_ok=True)

@test("CLI stats command")
def _():
    path = build_test_tokenizer()
    result = runner.invoke(main, ['stats', '-t', path])
    assert result.exit_code == 0
    assert "vocab" in result.output.lower() or "Vocab" in result.output

@test("CLI stats with corpus")
def _():
    path = build_test_tokenizer()
    result = runner.invoke(main, ['stats', '-t', path, '-c', CORPUS_PATH, '--max-samples', '50'])
    assert result.exit_code == 0

@test("CLI retokenize command")
def _():
    path = build_test_tokenizer()
    tmp_out = tempfile.mktemp(suffix='.tokens')
    result = runner.invoke(main, [
        'retokenize', CORPUS_PATH,
        '-t', path,
        '-o', tmp_out,
    ])
    assert result.exit_code == 0, f"Output: {result.output}"
    assert Path(tmp_out).exists()
    Path(tmp_out).unlink(missing_ok=True)

@test("CLI retokenize tokens format")
def _():
    path = build_test_tokenizer()
    tmp_out = tempfile.mktemp(suffix='.tokens')
    result = runner.invoke(main, [
        'retokenize', CORPUS_PATH,
        '-t', path,
        '-o', tmp_out,
        '--format', 'tokens',
    ])
    assert result.exit_code == 0
    Path(tmp_out).unlink(missing_ok=True)

@test("CLI retokenize both format")
def _():
    path = build_test_tokenizer()
    tmp_out = tempfile.mktemp(suffix='.tokens')
    result = runner.invoke(main, [
        'retokenize', CORPUS_PATH,
        '-t', path,
        '-o', tmp_out,
        '--format', 'both',
    ])
    assert result.exit_code == 0
    Path(tmp_out).unlink(missing_ok=True)

@test("CLI clean command basic")
def _():
    tmp_in = tempfile.mktemp(suffix='.txt')
    tmp_out = tempfile.mktemp(suffix='.txt')
    Path(tmp_in).write_text("Hello WORLD!!! Visit https://example.com")
    result = runner.invoke(main, [
        'clean', tmp_in,
        '-o', tmp_out,
        '--strip-urls',
        '-cp',
    ])
    assert result.exit_code == 0
    assert Path(tmp_out).exists()
    Path(tmp_in).unlink()
    Path(tmp_out).unlink()

@test("CLI clean --aggressive")
def _():
    tmp_in = tempfile.mktemp(suffix='.txt')
    tmp_out = tempfile.mktemp(suffix='.txt')
    Path(tmp_in).write_text("Visit https://example.com <b>now</b>!!! Can't miss it!")
    result = runner.invoke(main, ['clean', tmp_in, '-o', tmp_out, '--aggressive'])
    assert result.exit_code == 0
    Path(tmp_in).unlink()
    Path(tmp_out).unlink()

@test("CLI clean --maximum")
def _():
    tmp_in = tempfile.mktemp(suffix='.txt')
    tmp_out = tempfile.mktemp(suffix='.txt')
    Path(tmp_in).write_text("Well, I think the very important end result was good.")
    result = runner.invoke(main, ['clean', tmp_in, '-o', tmp_out, '--maximum'])
    assert result.exit_code == 0
    Path(tmp_in).unlink()
    Path(tmp_out).unlink()

@test("CLI clean --extreme")
def _():
    tmp_in = tempfile.mktemp(suffix='.txt')
    tmp_out = tempfile.mktemp(suffix='.txt')
    Path(tmp_in).write_text("Well, I think the very important end result was good.")
    result = runner.invoke(main, ['clean', tmp_in, '-o', tmp_out, '--extreme'])
    assert result.exit_code == 0
    Path(tmp_in).unlink()
    Path(tmp_out).unlink()

@test("CLI clean directory")
def _():
    tmpdir = tempfile.mkdtemp()
    (Path(tmpdir) / "test1.txt").write_text("Hello World!!! Very important.")
    (Path(tmpdir) / "test2.txt").write_text("Another test file!!!")
    outdir = tmpdir + "_clean"
    result = runner.invoke(main, ['clean', tmpdir, '-o', outdir, '-cp'])
    assert result.exit_code == 0
    shutil.rmtree(tmpdir)
    shutil.rmtree(outdir, ignore_errors=True)

@test("CLI iterate command")
def _():
    path = build_test_tokenizer()
    tmp_out = tempfile.mktemp(suffix='.json')
    result = runner.invoke(main, [
        'iterate', CORPUS_PATH,
        '-t', path,
        '-o', tmp_out,
        '--max-sentences', '100',
    ])
    assert result.exit_code == 0, f"Output: {result.output}"
    Path(tmp_out).unlink(missing_ok=True)

@test("CLI verify command")
def _():
    path = build_test_tokenizer()
    snap = tempfile.mktemp(suffix='.json')
    config = {"max_vocab_size": 5000}
    create_reproducibility_snapshot(path, CORPUS_PATH, 42, config, snap)

    result = runner.invoke(main, ['verify', snap, '-t', path])
    assert result.exit_code == 0
    assert "MATCH" in result.output
    Path(snap).unlink()

@test("CLI benchmark command")
def _():
    result = runner.invoke(main, [
        'benchmark', CORPUS_PATH,
        '--vocab-size', '2000',
        '--max-samples', '200',
    ])
    assert result.exit_code == 0, f"Output: {result.output}"
    assert "ION" in result.output or "Ion" in result.output

@test("CLI compare command")
def _():
    path1 = build_test_tokenizer()
    # Build a second tokenizer
    tmp2 = tempfile.mktemp(suffix='.json')
    build_tokenizer(
        source=CORPUS_PATH,
        output=tmp2,
        max_vocab_size=3000,
        max_sentences=200,
    )
    result = runner.invoke(main, ['compare', path1, tmp2])
    assert result.exit_code == 0, f"Output: {result.output}"
    assert "COMPARISON" in result.output
    Path(tmp2).unlink(missing_ok=True)

@test("CLI compare with corpus")
def _():
    path1 = build_test_tokenizer()
    tmp2 = tempfile.mktemp(suffix='.json')
    build_tokenizer(
        source=CORPUS_PATH,
        output=tmp2,
        max_vocab_size=3000,
        max_sentences=200,
    )
    result = runner.invoke(main, ['compare', path1, tmp2, '-c', CORPUS_PATH, '--max-samples', '50'])
    assert result.exit_code == 0, f"Output: {result.output}"
    Path(tmp2).unlink(missing_ok=True)

@test("CLI export huggingface format")
def _():
    path = build_test_tokenizer()
    tmpdir = tempfile.mkdtemp()
    result = runner.invoke(main, [
        'export', '-t', path, '-f', 'huggingface', '-o', tmpdir,
    ], input="y\n")
    assert result.exit_code == 0, f"Output: {result.output}"
    shutil.rmtree(tmpdir)

@test("CLI export vocab format")
def _():
    path = build_test_tokenizer()
    tmp = tempfile.mktemp(suffix='.txt')
    result = runner.invoke(main, [
        'export', '-t', path, '-f', 'vocab', '-o', tmp,
    ], input="y\n")
    assert result.exit_code == 0, f"Output: {result.output}"
    Path(tmp).unlink(missing_ok=True)

@test("CLI export sentencepiece format")
def _():
    path = build_test_tokenizer()
    tmp = tempfile.mktemp(suffix='.spm')
    result = runner.invoke(main, [
        'export', '-t', path, '-f', 'sentencepiece', '-o', tmp,
    ], input="y\n")
    assert result.exit_code == 0, f"Output: {result.output}"
    Path(tmp).unlink(missing_ok=True)

@test("CLI stats nonexistent tokenizer")
def _():
    result = runner.invoke(main, ['stats', '-t', '/tmp/nonexistent_tokenizer.json'])
    assert result.exit_code != 0

@test("CLI retokenize nonexistent input")
def _():
    path = build_test_tokenizer()
    result = runner.invoke(main, ['retokenize', '/tmp/nonexistent_input.txt', '-t', path])
    assert result.exit_code != 0

@test("CLI clean nonexistent path")
def _():
    result = runner.invoke(main, ['clean', '/tmp/nonexistent_path_12345'])
    assert result.exit_code != 0


# ============================================================================
# NEW FEATURE TESTS: phrase_target_pct, word_target_pct, fallback_mode
# ============================================================================
print("\n" + "=" * 60)
print("NEW FEATURE TESTS")
print("=" * 60)

@test("Newword fallback mode - dynamic word creation")
def _():
    tok = IonTokenizer(
        phrases=["hello world"],
        words=["hello", "world", "this"],
        fallback_mode="newword",
    )
    # "unknown" is not in vocab, should be dynamically added
    ids = tok.encode("hello world unknown")
    decoded = tok.decode(ids)
    # "unknown" should be a single word token now, not characters
    assert "unknown" in tok.vocab
    assert tok.vocab["unknown"] >= 0

@test("Newword fallback mode - multiple unknowns")
def _():
    tok = IonTokenizer(
        phrases=["hello world"],
        words=["hello", "world"],
        fallback_mode="newword",
    )
    ids = tok.encode("hello world foo bar baz")
    assert "foo" in tok.vocab
    assert "bar" in tok.vocab
    assert "baz" in tok.vocab
    # "hello world" = 1 phrase token, "foo" = 1, "bar" = 1, "baz" = 1 = 4 tokens
    assert len(ids) == 4

@test("Newword fallback mode serialization roundtrip")
def _():
    tok = IonTokenizer(
        phrases=["hello world"],
        words=["hello", "world"],
        fallback_mode="newword",
    )
    # Add some dynamic words
    tok.encode("hello world unknown")
    assert "unknown" in tok.vocab

    # Serialize and deserialize
    data = tok.to_dict()
    assert data["fallback_mode"] == "newword"
    tok2 = IonTokenizer.from_dict(data)
    assert tok2.fallback_mode == "newword"
    assert "unknown" in tok2.vocab or "unknown" in [t for t in tok2.token_classes["word"]]

@test("Set fallback mode to newword")
def _():
    tok = IonTokenizer(
        phrases=["hello world"],
        words=["hello", "world"],
        fallback_mode="bpe",
    )
    tok.set_fallback_mode("newword")
    assert tok.fallback_mode == "newword"

@test("Invalid fallback mode raises ValueError")
def _():
    tok = IonTokenizer(
        phrases=["hello world"],
        words=["hello", "world"],
    )
    try:
        tok.set_fallback_mode("invalid")
        assert False, "Should have raised ValueError"
    except ValueError:
        pass

@test("phrase_target_pct affects vocab allocation")
def _():
    # Build with 80% phrases, 20% words
    stats_80 = build_tokenizer(
        source=CORPUS_PATH,
        output="/tmp/test_pct80.json",
        max_vocab_size=2000,
        max_sentences=200,
        phrase_target_pct=80.0,
        word_target_pct=20.0,
    )
    # Build with 30% phrases, 70% words
    stats_30 = build_tokenizer(
        source=CORPUS_PATH,
        output="/tmp/test_pct30.json",
        max_vocab_size=2000,
        max_sentences=200,
        phrase_target_pct=30.0,
        word_target_pct=70.0,
    )
    # 80% phrases should have more phrases
    assert stats_80["phrase_count"] >= stats_30["phrase_count"]
    Path("/tmp/test_pct80.json").unlink(missing_ok=True)
    Path("/tmp/test_pct30.json").unlink(missing_ok=True)

@test("CLI tokenize with --phrase-target-pct")
def _():
    tmp_out = tempfile.mktemp(suffix='.json')
    result = runner.invoke(main, [
        'tokenize', CORPUS_PATH,
        '-o', tmp_out,
        '--max-vocab', '2000',
        '--max-sentences', '200',
        '--phrase-target-pct', '80',
    ])
    assert result.exit_code == 0, f"Output: {result.output}"
    Path(tmp_out).unlink(missing_ok=True)

@test("CLI tokenize with --fallback-mode newword")
def _():
    tmp_out = tempfile.mktemp(suffix='.json')
    result = runner.invoke(main, [
        'tokenize', CORPUS_PATH,
        '-o', tmp_out,
        '--max-vocab', '2000',
        '--max-sentences', '200',
        '--fallback-mode', 'newword',
    ])
    assert result.exit_code == 0, f"Output: {result.output}"
    assert "newword" in result.output.lower()
    Path(tmp_out).unlink(missing_ok=True)

@test("CLI tokenize with --fallback-mode character")
def _():
    tmp_out = tempfile.mktemp(suffix='.json')
    result = runner.invoke(main, [
        'tokenize', CORPUS_PATH,
        '-o', tmp_out,
        '--max-vocab', '2000',
        '--max-sentences', '200',
        '--fallback-mode', 'character',
    ])
    assert result.exit_code == 0, f"Output: {result.output}"
    Path(tmp_out).unlink(missing_ok=True)

@test("CLI benchmark with --phrase-target-pct and --fallback-mode")
def _():
    result = runner.invoke(main, [
        'benchmark', CORPUS_PATH,
        '--vocab-size', '2000',
        '--max-samples', '200',
        '--phrase-target-pct', '70',
        '--fallback-mode', 'newword',
    ])
    assert result.exit_code == 0, f"Output: {result.output}"

@test("Extended alphabet includes Hindi characters")
def _():
    from ion.tokenizer import EXTENDED_ALPHABET
    # Check that Hindi characters are present
    assert '\u0915' in EXTENDED_ALPHABET  # ka
    assert '\u0905' in EXTENDED_ALPHABET  # a

@test("Extended alphabet includes Thai characters")
def _():
    from ion.tokenizer import EXTENDED_ALPHABET
    assert '\u0e01' in EXTENDED_ALPHABET  # ko kai

@test("Extended alphabet includes Korean Jamo")
def _():
    from ion.tokenizer import EXTENDED_ALPHABET
    assert '\u3131' in EXTENDED_ALPHABET  # kiyeok

@test("Build time is reported in CLI output")
def _():
    tmp_out = tempfile.mktemp(suffix='.json')
    result = runner.invoke(main, [
        'tokenize', CORPUS_PATH,
        '-o', tmp_out,
        '--max-vocab', '2000',
        '--max-sentences', '200',
    ])
    assert result.exit_code == 0
    assert "Build time:" in result.output
    Path(tmp_out).unlink(missing_ok=True)

@test("Fallback mode shown in CLI output")
def _():
    tmp_out = tempfile.mktemp(suffix='.json')
    result = runner.invoke(main, [
        'tokenize', CORPUS_PATH,
        '-o', tmp_out,
        '--max-vocab', '2000',
        '--max-sentences', '200',
    ])
    assert result.exit_code == 0
    assert "Fallback mode:" in result.output
    Path(tmp_out).unlink(missing_ok=True)


# ============================================================================
# EXTENDED TESTS: More corpora, languages, fallback modes
# ============================================================================
print("\n" + "=" * 60)
print("EXTENDED TESTS")
print("=" * 60)

@test("Newword mode produces 1 token per unknown word")
def _():
    tok = IonTokenizer(
        phrases=["machine learning"],
        words=["the", "is", "a"],
        fallback_mode="newword",
    )
    ids = tok.encode("machine learning is a transformative technology")
    # "machine learning" = 1 phrase, "is" = 1 word, "a" = 1 word,
    # "transformative" = 1 newword, "technology" = 1 newword = 5 total
    assert len(ids) == 5
    assert "transformative" in tok.vocab
    assert "technology" in tok.vocab

@test("Newword mode vocab grows with unseen words")
def _():
    tok = IonTokenizer(
        phrases=[],
        words=["hello"],
        fallback_mode="newword",
    )
    initial_size = tok.vocab_size()
    tok.encode("hello world foo bar")
    assert tok.vocab_size() == initial_size + 3  # world, foo, bar added

@test("Newword mode does not duplicate existing words")
def _():
    tok = IonTokenizer(
        phrases=[],
        words=["hello", "world"],
        fallback_mode="newword",
    )
    ids1 = tok.encode("hello world unknown")
    ids2 = tok.encode("hello world unknown")  # second time, "unknown" already in vocab
    assert ids1 == ids2

@test("phrase_target_pct 90% gives more phrases than 10%")
def _():
    stats_90 = build_tokenizer(
        source=CORPUS_PATH,
        output="/tmp/test_pct90.json",
        max_vocab_size=2000,
        max_sentences=200,
        phrase_target_pct=90.0,
    )
    stats_10 = build_tokenizer(
        source=CORPUS_PATH,
        output="/tmp/test_pct10.json",
        max_vocab_size=2000,
        max_sentences=200,
        phrase_target_pct=10.0,
    )
    assert stats_90["phrase_count"] >= stats_10["phrase_count"]
    assert stats_10["word_count"] >= stats_90["word_count"]
    Path("/tmp/test_pct90.json").unlink(missing_ok=True)
    Path("/tmp/test_pct10.json").unlink(missing_ok=True)

@test("Builder fallback_mode='newword' produces newword tokenizer")
def _():
    stats = build_tokenizer(
        source=CORPUS_PATH,
        output="/tmp/test_newword_build.json",
        max_vocab_size=2000,
        max_sentences=200,
        fallback_mode="newword",
    )
    tok_data = orjson.loads(Path("/tmp/test_newword_build.json").read_bytes())
    tok = IonTokenizer.from_dict(tok_data)
    assert tok.fallback_mode == "newword"
    # Encoding unknown words should not produce character tokens
    ids = tok.encode("supercalifragilisticexpialidocious")
    assert len(ids) == 1  # single newword token
    Path("/tmp/test_newword_build.json").unlink(missing_ok=True)

@test("Builder fallback_mode='character' produces character tokenizer")
def _():
    stats = build_tokenizer(
        source=CORPUS_PATH,
        output="/tmp/test_char_build.json",
        max_vocab_size=2000,
        max_sentences=200,
        fallback_mode="character",
    )
    tok_data = orjson.loads(Path("/tmp/test_char_build.json").read_bytes())
    tok = IonTokenizer.from_dict(tok_data)
    assert tok.fallback_mode == "character"
    Path("/tmp/test_char_build.json").unlink(missing_ok=True)

@test("Extended alphabet has at least 200 characters")
def _():
    from ion.tokenizer import EXTENDED_ALPHABET
    assert len(EXTENDED_ALPHABET) >= 200

@test("CLI tokenize with --word-target-pct")
def _():
    tmp_out = tempfile.mktemp(suffix='.json')
    result = runner.invoke(main, [
        'tokenize', CORPUS_PATH,
        '-o', tmp_out,
        '--max-vocab', '2000',
        '--max-sentences', '200',
        '--phrase-target-pct', '30',
        '--word-target-pct', '70',
    ])
    assert result.exit_code == 0, f"Output: {result.output}"
    assert "30% phrases" in result.output
    Path(tmp_out).unlink(missing_ok=True)

@test("Multiple encode calls with newword are consistent")
def _():
    tok = IonTokenizer(
        phrases=["hello world"],
        words=["hello", "world"],
        fallback_mode="newword",
    )
    text = "hello world something new appears here"
    ids1 = tok.encode(text)
    ids2 = tok.encode(text)
    assert ids1 == ids2  # same text, same ids

@test("Synthetic corpus generators produce valid output")
def _():
    bench_path = str(Path(__file__).parent.parent / "benchmarks")
    if bench_path not in sys.path:
        sys.path.insert(0, bench_path)
    import importlib
    mod = importlib.import_module("benchmark_extended")
    for gen_name in ["generate_web_text_corpus", "generate_book_corpus",
                     "generate_medical_corpus", "generate_tech_docs_corpus",
                     "generate_italian_corpus", "generate_portuguese_corpus",
                     "generate_rust_corpus", "generate_go_corpus"]:
        gen = getattr(mod, gen_name)
        sents = gen(100)
        assert len(sents) == 100, f"{gen_name} produced {len(sents)} sentences"
        assert all(len(s) >= 1 for s in sents), f"{gen_name} produced empty sentences"

@test("Ion tokenizer on medical text with newword mode")
def _():
    sys.path.insert(0, str(Path(__file__).parent.parent / "benchmarks"))
    from benchmark_extended import generate_medical_corpus
    sents = generate_medical_corpus(200)
    corpus_text = "\n".join(sents)
    tmp = tempfile.mktemp(suffix='.txt')
    Path(tmp).write_text(corpus_text)
    stats = build_tokenizer(
        source=tmp,
        output="/tmp/test_med_nw.json",
        max_vocab_size=2000,
        max_sentences=200,
        fallback_mode="newword",
    )
    assert stats["vocab_size"] > 0
    assert stats["phrase_count"] >= 0
    Path(tmp).unlink(missing_ok=True)
    Path("/tmp/test_med_nw.json").unlink(missing_ok=True)

@test("Ion tokenizer on Italian text")
def _():
    sys.path.insert(0, str(Path(__file__).parent.parent / "benchmarks"))
    from benchmark_extended import generate_italian_corpus
    sents = generate_italian_corpus(200)
    corpus_text = "\n".join(sents)
    tmp = tempfile.mktemp(suffix='.txt')
    Path(tmp).write_text(corpus_text)
    stats = build_tokenizer(
        source=tmp,
        output="/tmp/test_it.json",
        max_vocab_size=2000,
        max_sentences=200,
        language="it",
    )
    assert stats["vocab_size"] > 0
    Path(tmp).unlink(missing_ok=True)
    Path("/tmp/test_it.json").unlink(missing_ok=True)

@test("Ion tokenizer on Rust code with preserve_case")
def _():
    sys.path.insert(0, str(Path(__file__).parent.parent / "benchmarks"))
    from benchmark_extended import generate_rust_corpus
    sents = generate_rust_corpus(200)
    corpus_text = "\n".join(sents)
    tmp = tempfile.mktemp(suffix='.txt')
    Path(tmp).write_text(corpus_text)
    stats = build_tokenizer(
        source=tmp,
        output="/tmp/test_rs.json",
        max_vocab_size=2000,
        max_sentences=200,
        preserve_case=True,
    )
    assert stats["vocab_size"] > 0
    Path(tmp).unlink(missing_ok=True)
    Path("/tmp/test_rs.json").unlink(missing_ok=True)

@test("Ion tokenizer on Go code")
def _():
    sys.path.insert(0, str(Path(__file__).parent.parent / "benchmarks"))
    from benchmark_extended import generate_go_corpus
    sents = generate_go_corpus(200)
    corpus_text = "\n".join(sents)
    tmp = tempfile.mktemp(suffix='.txt')
    Path(tmp).write_text(corpus_text)
    stats = build_tokenizer(
        source=tmp,
        output="/tmp/test_go.json",
        max_vocab_size=2000,
        max_sentences=200,
        preserve_case=True,
    )
    assert stats["vocab_size"] > 0
    Path(tmp).unlink(missing_ok=True)
    Path("/tmp/test_go.json").unlink(missing_ok=True)


# ============================================================================
# NEW TESTS: CLI shorthands, max_word_length, typo handling, bug hunting
# ============================================================================
print("\n" + "=" * 60)
print("CLI SHORTHANDS, MAX WORD LENGTH, TYPO TESTS")
print("=" * 60)

@test("CLI tokenize shorthand -v for --max-vocab")
def _():
    tmp_out = tempfile.mktemp(suffix='.json')
    result = runner.invoke(main, [
        'tokenize', CORPUS_PATH,
        '-o', tmp_out,
        '-v', '2000',
        '-n', '200',
    ])
    assert result.exit_code == 0, f"Output: {result.output}"
    Path(tmp_out).unlink(missing_ok=True)

@test("CLI tokenize shorthand -d for --domain")
def _():
    tmp_out = tempfile.mktemp(suffix='.json')
    result = runner.invoke(main, [
        'tokenize', CORPUS_PATH,
        '-o', tmp_out,
        '-v', '2000',
        '-n', '200',
        '-d', 'legal',
    ])
    assert result.exit_code == 0, f"Output: {result.output}"
    assert "legal" in result.output.lower()
    Path(tmp_out).unlink(missing_ok=True)

@test("CLI tokenize shorthand -s for --seed")
def _():
    tmp_out = tempfile.mktemp(suffix='.json')
    result = runner.invoke(main, [
        'tokenize', CORPUS_PATH,
        '-o', tmp_out, '-v', '2000', '-n', '200', '-s', '42',
    ])
    assert result.exit_code == 0, f"Output: {result.output}"
    Path(tmp_out).unlink(missing_ok=True)

@test("CLI tokenize shorthand -fm for --fallback-mode")
def _():
    tmp_out = tempfile.mktemp(suffix='.json')
    result = runner.invoke(main, [
        'tokenize', CORPUS_PATH,
        '-o', tmp_out, '-v', '2000', '-n', '200', '-fm', 'newword',
    ])
    assert result.exit_code == 0, f"Output: {result.output}"
    assert "newword" in result.output.lower()
    Path(tmp_out).unlink(missing_ok=True)

@test("CLI tokenize shorthand -pp for --phrase-target-pct")
def _():
    tmp_out = tempfile.mktemp(suffix='.json')
    result = runner.invoke(main, [
        'tokenize', CORPUS_PATH,
        '-o', tmp_out, '-v', '2000', '-n', '200', '-pp', '80',
    ])
    assert result.exit_code == 0, f"Output: {result.output}"
    Path(tmp_out).unlink(missing_ok=True)

@test("CLI tokenize shorthand -pc for --preserve-case")
def _():
    tmp_out = tempfile.mktemp(suffix='.json')
    result = runner.invoke(main, [
        'tokenize', CORPUS_PATH,
        '-o', tmp_out, '-v', '2000', '-n', '200', '-pc',
    ])
    assert result.exit_code == 0, f"Output: {result.output}"
    assert "Case preservation" in result.output
    Path(tmp_out).unlink(missing_ok=True)

@test("CLI benchmark shorthand -v and -n")
def _():
    result = runner.invoke(main, [
        'benchmark', CORPUS_PATH,
        '-v', '2000', '-n', '200',
    ])
    assert result.exit_code == 0, f"Output: {result.output}"

@test("CLI bpe shorthand -v and -n")
def _():
    tmp_out = tempfile.mktemp(suffix='.json')
    result = runner.invoke(main, [
        'bpe', CORPUS_PATH,
        '-o', tmp_out, '-v', '2000', '-n', '200',
    ])
    assert result.exit_code == 0, f"Output: {result.output}"
    Path(tmp_out).unlink(missing_ok=True)

@test("CLI benchmarks shorthand -q")
def _():
    result = runner.invoke(main, ['-q'])  # this is on benchmarks
    # Actually test benchmarks -q
    result = runner.invoke(main, ['benchmarks', '-q'])
    assert result.exit_code == 0

@test("CLI benchmarks shorthand -C")
def _():
    result = runner.invoke(main, ['benchmarks', '-C'])
    assert result.exit_code == 0

@test("CLI retokenize shorthand -F for --format")
def _():
    path = build_test_tokenizer()
    tmp_out = tempfile.mktemp(suffix='.tokens')
    result = runner.invoke(main, [
        'retokenize', CORPUS_PATH,
        '-t', path, '-o', tmp_out, '-F', 'tokens',
    ])
    assert result.exit_code == 0, f"Output: {result.output}"
    Path(tmp_out).unlink(missing_ok=True)

@test("CLI iterate shorthand -n and -np")
def _():
    path = build_test_tokenizer()
    tmp_out = tempfile.mktemp(suffix='.json')
    result = runner.invoke(main, [
        'iterate', CORPUS_PATH,
        '-t', path, '-o', tmp_out, '-n', '100', '-np',
    ])
    assert result.exit_code == 0, f"Output: {result.output}"
    Path(tmp_out).unlink(missing_ok=True)

@test("CLI stats shorthand -n for --max-samples")
def _():
    path = build_test_tokenizer()
    result = runner.invoke(main, ['stats', '-t', path, '-c', CORPUS_PATH, '-n', '50'])
    assert result.exit_code == 0

@test("max_word_length filters long words from vocab")
def _():
    stats = build_tokenizer(
        source=CORPUS_PATH,
        output="/tmp/test_mwl.json",
        max_vocab_size=2000,
        max_sentences=200,
        max_word_length=8,
    )
    tok_data = orjson.loads(Path("/tmp/test_mwl.json").read_bytes())
    tok = IonTokenizer.from_dict(tok_data)
    # All words in vocab should be <= 8 characters (except specials/phrases/fallback)
    word_tokens = [t["token"] for t in tok_data["token_classes"]["word"]]
    for w in word_tokens:
        assert len(w) <= 8, f"Word '{w}' ({len(w)} chars) exceeds max_word_length=8"
    Path("/tmp/test_mwl.json").unlink(missing_ok=True)

@test("max_word_length serialization roundtrip")
def _():
    tok = IonTokenizer(
        phrases=["hello world"],
        words=["hello", "world"],
        fallback_mode="newword",
    )
    tok.max_word_length = 10
    data = tok.to_dict()
    assert data["max_word_length"] == 10
    tok2 = IonTokenizer.from_dict(data)
    assert tok2.max_word_length == 10

@test("max_word_length with newword mode skips long words")
def _():
    tok = IonTokenizer(
        phrases=[],
        words=["hello", "world"],
        fallback_mode="newword",
    )
    tok.max_word_length = 5
    # "supercalifragilistic" (20 chars) should NOT be added as newword
    ids = tok.encode("hello supercalifragilistic")
    # "supercalifragilistic" should be broken by BPE/character fallback, not added as single token
    assert "supercalifragilistic" not in tok.vocab
    assert len(ids) > 2  # more than "hello" + one token

@test("CLI tokenize with --max-word-length / -mwl")
def _():
    tmp_out = tempfile.mktemp(suffix='.json')
    result = runner.invoke(main, [
        'tokenize', CORPUS_PATH,
        '-o', tmp_out, '-v', '2000', '-n', '200', '-mwl', '10',
    ])
    assert result.exit_code == 0, f"Output: {result.output}"
    assert "Max word length" in result.output
    Path(tmp_out).unlink(missing_ok=True)

@test("Typo-heavy text tokenization with newword mode")
def _():
    tok = IonTokenizer(
        phrases=["machine learning", "deep learning", "neural network"],
        words=["the", "is", "a", "good", "bad", "model", "data", "this", "that",
               "machine", "learning", "deep", "neural", "network"],
        fallback_mode="newword",
    )
    typo_text = "the machne lerning modle is goood and deepp lerning nueral netwrok is alsoo goood"
    ids = tok.encode(typo_text)
    # Typos get added as new words (1 token each) in newword mode
    assert "machne" in tok.vocab
    assert "lerning" in tok.vocab
    assert "modle" in tok.vocab
    assert "goood" in tok.vocab
    # Each typo = 1 token, so newword handles typos gracefully

@test("Typo-heavy text tokenization with BPE mode")
def _():
    tok = IonTokenizer(
        phrases=["machine learning"],
        words=["the", "is", "a", "machine", "learning"],
        fallback_mode="bpe",
    )
    typo_text = "the machne lerning"
    ids = tok.encode(typo_text)
    # "machne" and "lerning" should be handled by BPE fallback (character by character)
    # They won't be single tokens but will be decomposed
    assert len(ids) > 3  # "the" + multiple fallback tokens for typos

@test("Typo-heavy text tokenization with character mode")
def _():
    tok = IonTokenizer(
        phrases=["machine learning"],
        words=["the", "is", "a", "machine", "learning"],
        fallback_mode="character",
    )
    typo_text = "the machne"
    ids = tok.encode(typo_text)
    # "machne" = 6 character tokens, "the" = 1 word token
    assert len(ids) == 7  # 1 ("the") + 6 ("m","a","c","h","n","e")

@test("Real typo paragraph tokenization")
def _():
    """Test with a realistic paragraph full of common typos"""
    tok = IonTokenizer(
        phrases=["according to", "in order to", "as well as", "united states",
                 "machine learning", "deep learning"],
        words=["the", "is", "a", "an", "of", "to", "in", "and", "for", "that",
               "this", "was", "are", "with", "on", "it", "they", "have", "not",
               "according", "order", "well", "united", "states", "machine",
               "learning", "deep", "important", "research", "development"],
        fallback_mode="newword",
    )
    typo_paragraph = (
        "Accoring to teh reserch, machne lerning is importnat for developmnet. "
        "Teh untied staets has investd in deap lerning reserch as wel as "
        "artifical intelligense. In ordr to achive beter results, we neeed "
        "moar data and compuational resurces."
    )
    ids = tok.encode(typo_paragraph)
    # In newword mode, every unknown typo is 1 token
    # The correctly spelled words match existing vocab
    assert "teh" in tok.vocab  # common typo for "the"
    assert "reserch" in tok.vocab  # common typo for "research"
    assert "importnat" in tok.vocab  # common typo for "important"

@test("Empty string tokenization")
def _():
    tok = IonTokenizer(
        phrases=["hello world"],
        words=["hello", "world"],
    )
    ids = tok.encode("")
    assert ids == []

@test("Single character tokenization")
def _():
    tok = IonTokenizer(
        phrases=["hello world"],
        words=["hello", "world"],
        fallback_mode="character",
    )
    ids = tok.encode("x")
    assert len(ids) == 1

@test("Repeated words tokenization consistency")
def _():
    tok = IonTokenizer(
        phrases=["hello world"],
        words=["hello", "world"],
    )
    ids1 = tok.encode("hello hello hello")
    # "hello" repeated 3 times = 3 tokens (same ID)
    assert len(ids1) == 3
    assert ids1[0] == ids1[1] == ids1[2]

@test("Phrase at start, middle, and end of text")
def _():
    tok = IonTokenizer(
        phrases=["hello world", "good morning"],
        words=["hello", "world", "say", "good", "morning", "now"],
    )
    ids_start = tok.encode("hello world say now")
    ids_mid = tok.encode("say hello world now")
    ids_end = tok.encode("say now hello world")
    # All should contain exactly 3 tokens (phrase + 2 words)
    assert len(ids_start) == 3
    assert len(ids_mid) == 3
    assert len(ids_end) == 3

@test("Very long word fallback")
def _():
    tok = IonTokenizer(
        phrases=[],
        words=["hello"],
        fallback_mode="character",
    )
    long_word = "a" * 100
    ids = tok.encode(long_word)
    assert len(ids) == 100  # 100 character tokens

@test("Unicode emoji handling")
def _():
    tok = IonTokenizer(
        phrases=["hello world"],
        words=["hello", "world"],
        fallback_mode="newword",
    )
    # Emoji should be handled gracefully
    ids = tok.encode("hello world")
    assert len(ids) >= 1  # At least the phrase

@test("Mixed case with preserve_case=False")
def _():
    tok = IonTokenizer(
        phrases=["hello world"],
        words=["hello", "world"],
        preserve_case=False,
    )
    ids = tok.encode("Hello World")
    decoded = tok.decode(ids)
    assert "hello" in decoded.lower()

@test("Version field in serialized tokenizer")
def _():
    tok = IonTokenizer(
        phrases=["hello world"],
        words=["hello", "world"],
    )
    data = tok.to_dict()
    assert data["version"] == "3.0"

@test("CLI help command works")
def _():
    result = runner.invoke(main, ['help'])
    assert result.exit_code == 0
    assert "ion" in result.output.lower() or "ION" in result.output

@test("CLI splash command works")
def _():
    result = runner.invoke(main, ['splash'])
    assert result.exit_code == 0

@test("CLI --help flag works on main")
def _():
    result = runner.invoke(main, ['--help'])
    assert result.exit_code == 0
    assert "tokenize" in result.output

@test("CLI tokenize --help shows shorthand flags")
def _():
    result = runner.invoke(main, ['tokenize', '--help'])
    assert result.exit_code == 0
    assert "-v" in result.output
    assert "-n" in result.output
    assert "-d" in result.output
    assert "-fm" in result.output
    assert "-mwl" in result.output
    assert "-tc" in result.output
    assert "-sp" in result.output
    assert "-es" in result.output


# ============================================================================
# FEATURE 1: TYPO CORRECTION LAYER
# ============================================================================
print("\n" + "=" * 60)
print("TYPO CORRECTION TESTS")
print("=" * 60)

from ion.tokenizer import TypoCorrector

@test("TypoCorrector basic edit distance 1 correction")
def _():
    tc = TypoCorrector(max_edit_distance=1, min_word_length=3)
    tc.build_index(["hello", "world", "machine", "learning", "network"])
    assert tc.correct("helo") == "hello"  # deletion
    assert tc.correct("worlf") == "world"  # substitution
    assert tc.correct("xyz123") is None  # no close match in vocab

@test("TypoCorrector edit distance 2 correction")
def _():
    tc = TypoCorrector(max_edit_distance=2, min_word_length=3)
    tc.build_index(["hello", "world", "machine", "learning", "network"])
    assert tc.correct("machne") == "machine"  # distance 2
    assert tc.correct("lerning") == "learning"  # distance 2
    assert tc.correct("netwrok") == "network"  # transposition = 2 ops

@test("TypoCorrector skips short words")
def _():
    tc = TypoCorrector(max_edit_distance=2, min_word_length=4)
    tc.build_index(["the", "to", "go", "hello", "world"])
    assert tc.correct("th") is None  # too short
    assert tc.correct("teh") is None  # too short (3 chars < min_word_length=4)

@test("TypoCorrector returns None for correct words")
def _():
    tc = TypoCorrector(max_edit_distance=2, min_word_length=3)
    tc.build_index(["hello", "world"])
    assert tc.correct("hello") is None  # already in vocab
    assert tc.correct("world") is None

@test("TypoCorrector returns None for distant words")
def _():
    tc = TypoCorrector(max_edit_distance=2, min_word_length=3)
    tc.build_index(["hello", "world"])
    assert tc.correct("xyzzy") is None  # too far from anything
    assert tc.correct("abcde") is None

@test("TypoCorrector caches results")
def _():
    tc = TypoCorrector(max_edit_distance=2, min_word_length=3)
    tc.build_index(["hello", "world"])
    result1 = tc.correct("helo")
    result2 = tc.correct("helo")
    assert result1 == result2 == "hello"
    assert "helo" in tc._correction_cache

@test("TypoCorrector stats tracking")
def _():
    tc = TypoCorrector(max_edit_distance=2, min_word_length=3)
    tc.build_index(["hello", "world"])
    tc.correct("helo")
    tc.correct("worlf")
    stats = tc.get_stats()
    assert stats["total_corrections"] == 2
    assert stats["unique_corrections"] == 2
    assert stats["vocab_size"] == 2

@test("TypoCorrector edit_distance static method")
def _():
    assert TypoCorrector._edit_distance("hello", "hello") == 0
    assert TypoCorrector._edit_distance("hello", "helo") == 1
    assert TypoCorrector._edit_distance("hello", "hllo") == 1
    assert TypoCorrector._edit_distance("hello", "heo") == 2
    assert TypoCorrector._edit_distance("cat", "dog") == 3

@test("IonTokenizer with typo correction enabled")
def _():
    tok = IonTokenizer(
        phrases=["machine learning", "deep learning"],
        words=["the", "is", "a", "machine", "learning", "deep", "important", "research"],
        fallback_mode="character",
    )
    tok.enable_typo_correction(max_edit_distance=2)
    # "machne" should be corrected to "machine"
    ids = tok.encode("the machne lerning is important")
    decoded = tok.decode(ids)
    # "machne" -> "machine", "lerning" -> "learning"
    assert "machine" in decoded
    assert "learning" in decoded

@test("IonTokenizer typo correction reduces token count")
def _():
    tok = IonTokenizer(
        phrases=["machine learning"],
        words=["the", "is", "machine", "learning"],
        fallback_mode="character",
    )
    # Without typo correction: "machne" = 6 character tokens
    ids_no_tc = tok.encode("the machne")
    assert len(ids_no_tc) == 7  # "the" + 6 chars

    tok.enable_typo_correction(max_edit_distance=2)
    # With typo correction: "machne" -> "machine" = 1 word token
    ids_tc = tok.encode("the machne")
    assert len(ids_tc) == 2  # "the" + "machine"

@test("IonTokenizer typo correction serialization roundtrip")
def _():
    tok = IonTokenizer(
        phrases=["hello world"],
        words=["hello", "world", "testing"],
        fallback_mode="newword",
    )
    tok.enable_typo_correction(max_edit_distance=1)
    data = tok.to_dict()
    assert data["typo_correction"]["enabled"] is True
    assert data["typo_correction"]["max_edit_distance"] == 1

    tok2 = IonTokenizer.from_dict(data)
    assert tok2._typo_correction_enabled is True
    assert tok2._typo_corrector is not None
    assert tok2._typo_corrector.max_edit_distance == 1

@test("IonTokenizer disable typo correction")
def _():
    tok = IonTokenizer(
        phrases=[],
        words=["hello", "world"],
        fallback_mode="character",
    )
    tok.enable_typo_correction()
    assert tok._typo_correction_enabled is True
    tok.disable_typo_correction()
    assert tok._typo_correction_enabled is False
    assert tok._typo_corrector is None

@test("IonTokenizer get_typo_stats")
def _():
    tok = IonTokenizer(
        phrases=[],
        words=["hello", "world", "testing"],
        fallback_mode="character",
    )
    tok.enable_typo_correction(max_edit_distance=2)
    tok.encode("helo worlf")
    stats = tok.get_typo_stats()
    assert stats["total_corrections"] >= 1

@test("CLI tokenize with --typo-correction")
def _():
    tmp_out = tempfile.mktemp(suffix='.json')
    result = runner.invoke(main, [
        'tokenize', CORPUS_PATH,
        '-o', tmp_out, '-v', '2000', '-n', '200', '-tc',
    ])
    assert result.exit_code == 0, f"Output: {result.output}"
    assert "Typo correction" in result.output
    tok_data = orjson.loads(Path(tmp_out).read_bytes())
    assert tok_data.get("typo_correction", {}).get("enabled") is True
    Path(tmp_out).unlink(missing_ok=True)


# ============================================================================
# FEATURE 2: STREAMING PHRASE DISCOVERY
# ============================================================================
print("\n" + "=" * 60)
print("STREAMING PHRASE DISCOVERY TESTS")
print("=" * 60)

from ion.tokenizer import StreamingPhraseDiscovery

@test("StreamingPhraseDiscovery basic observation")
def _():
    spd = StreamingPhraseDiscovery(min_count=3, promotion_threshold=0.1)
    for _ in range(10):
        spd.observe(["hello", "world", "this", "is", "great"])
    stats = spd.get_stats()
    assert stats["encoding_steps"] == 10
    assert stats["bigrams_tracked"] > 0

@test("StreamingPhraseDiscovery phrase promotion")
def _():
    spd = StreamingPhraseDiscovery(min_count=5, promotion_threshold=0.01)
    # Feed the same bigram many times to trigger promotion
    for _ in range(50):
        spd.observe(["machine", "learning", "is", "great"])
    new = spd.check_promotions()
    # "machine learning" should be promoted
    assert "machine learning" in new or "machine learning" in spd.get_discovered_phrases()

@test("StreamingPhraseDiscovery max phrases limit")
def _():
    spd = StreamingPhraseDiscovery(min_count=2, promotion_threshold=0.01, max_new_phrases=2)
    for _ in range(50):
        spd.observe(["hello", "world", "deep", "learning", "machine", "learning"])
    spd.check_promotions()
    assert len(spd.get_discovered_phrases()) <= 2

@test("StreamingPhraseDiscovery reset")
def _():
    spd = StreamingPhraseDiscovery(min_count=3)
    for _ in range(10):
        spd.observe(["hello", "world"])
    spd.reset()
    assert spd.get_stats()["encoding_steps"] == 0
    assert spd.get_stats()["bigrams_tracked"] == 0

@test("StreamingPhraseDiscovery exponential decay")
def _():
    spd = StreamingPhraseDiscovery(min_count=3, decay_rate=0.99)
    for _ in range(200):
        spd.observe(["test", "word"])
    # After decay, counts should be reduced
    stats = spd.get_stats()
    assert stats["encoding_steps"] == 200

@test("IonTokenizer with streaming phrases enabled")
def _():
    tok = IonTokenizer(
        phrases=[],
        words=["machine", "learning", "deep", "is", "great"],
        fallback_mode="newword",
    )
    tok.enable_streaming_phrases(
        min_count=3, promotion_threshold=0.01, check_interval=5
    )
    # Feed "machine learning" many times
    for _ in range(50):
        tok.encode("machine learning is great")
    # After enough encodes, "machine learning" should be discovered
    phrases = tok.get_streaming_phrases()
    stats = tok.get_streaming_stats()
    assert stats["encoding_steps"] > 0

@test("IonTokenizer streaming phrases added to trie")
def _():
    tok = IonTokenizer(
        phrases=[],
        words=["hello", "world", "good", "morning"],
        fallback_mode="newword",
    )
    # Manually add a streaming phrase
    tok._add_streaming_phrase("hello world")
    assert "hello world" in tok.vocab
    # Should now match as a phrase
    ids = tok.encode("hello world")
    assert len(ids) == 1  # single phrase token

@test("IonTokenizer disable streaming phrases")
def _():
    tok = IonTokenizer(
        phrases=[],
        words=["hello", "world"],
    )
    tok.enable_streaming_phrases()
    assert tok._streaming_enabled is True
    tok.disable_streaming_phrases()
    assert tok._streaming_enabled is False

@test("IonTokenizer streaming phrases serialization")
def _():
    tok = IonTokenizer(
        phrases=[],
        words=["hello", "world"],
        fallback_mode="newword",
    )
    tok._add_streaming_phrase("hello world")
    data = tok.to_dict()
    assert "hello world" in data["streaming_phrases"]["discovered"]
    # Phrase should be in token_classes
    phrase_tokens = [t["token"] for t in data["token_classes"]["phrase"]]
    assert "hello world" in phrase_tokens

@test("CLI tokenize with --streaming-phrases")
def _():
    tmp_out = tempfile.mktemp(suffix='.json')
    result = runner.invoke(main, [
        'tokenize', CORPUS_PATH,
        '-o', tmp_out, '-v', '2000', '-n', '200', '-sp',
    ])
    assert result.exit_code == 0, f"Output: {result.output}"
    assert "Streaming phrase discovery" in result.output
    Path(tmp_out).unlink(missing_ok=True)


# ============================================================================
# FEATURE 3: EMBEDDING-BASED PHRASE SCORING
# ============================================================================
print("\n" + "=" * 60)
print("EMBEDDING PHRASE SCORING TESTS")
print("=" * 60)

from ion.phrase_discovery import EmbeddingPhraseScorer

@test("EmbeddingPhraseScorer training")
def _():
    sentences = [
        ["the", "machine", "learning", "model", "is", "good"],
        ["deep", "learning", "networks", "are", "powerful"],
        ["the", "neural", "network", "works", "well"],
        ["machine", "learning", "algorithms", "learn", "patterns"],
        ["deep", "learning", "is", "a", "subset", "of", "machine", "learning"],
    ] * 20
    scorer = EmbeddingPhraseScorer(vector_size=50, min_count=2)
    scorer.train(sentences)
    assert scorer.is_trained()

@test("EmbeddingPhraseScorer phrase scoring")
def _():
    sentences = [
        ["machine", "learning", "is", "important"],
        ["deep", "learning", "uses", "neural", "networks"],
        ["machine", "learning", "algorithms", "process", "data"],
    ] * 30
    scorer = EmbeddingPhraseScorer(vector_size=50, min_count=2)
    scorer.train(sentences)
    score = scorer.score_phrase("machine learning", 50)
    assert score > 0
    assert isinstance(score, float)

@test("EmbeddingPhraseScorer batch scoring")
def _():
    sentences = [
        ["the", "united", "states", "has", "great", "technology"],
        ["machine", "learning", "is", "advancing", "fast"],
    ] * 30
    scorer = EmbeddingPhraseScorer(vector_size=50, min_count=2)
    scorer.train(sentences)
    results = scorer.score_phrases([
        ("united states", 50),
        ("machine learning", 40),
        ("the has", 10),
    ])
    assert len(results) == 3
    # Each result is (phrase, score, details)
    for phrase, score, details in results:
        assert isinstance(score, float)
        assert "coherence" in details
        assert "frequency" in details
        assert "pmi" in details
        assert "raw_freq" in details

@test("EmbeddingPhraseScorer top_k filtering")
def _():
    sentences = [["the", "cat", "sat", "on", "the", "mat"]] * 30
    scorer = EmbeddingPhraseScorer(vector_size=50, min_count=2)
    scorer.train(sentences)
    results = scorer.score_phrases([
        ("cat sat", 20),
        ("sat on", 15),
        ("the mat", 10),
    ], top_k=2)
    assert len(results) == 2

@test("EmbeddingPhraseScorer untrained returns neutral")
def _():
    scorer = EmbeddingPhraseScorer()
    assert not scorer.is_trained()
    score = scorer.score_phrase("hello world", 10)
    assert score > 0  # Should return a neutral score

@test("EmbeddingPhraseScorer coherence computation")
def _():
    sentences = [
        ["machine", "learning", "model", "training", "data"],
        ["machine", "learning", "algorithms", "classification"],
    ] * 30
    scorer = EmbeddingPhraseScorer(vector_size=50, min_count=2)
    scorer.train(sentences)
    # Words that appear in similar contexts should have higher coherence
    coherence = scorer._compute_coherence(["machine", "learning"])
    assert 0.0 <= coherence <= 1.0

@test("EmbeddingPhraseScorer frequency score")
def _():
    scorer = EmbeddingPhraseScorer()
    scorer._total_words = 10000
    freq_score = scorer._compute_frequency_score(100)
    assert 0.0 <= freq_score <= 1.0
    # Higher frequency should give higher score
    freq_score_high = scorer._compute_frequency_score(1000)
    assert freq_score_high > freq_score

@test("CLI tokenize with --embedding-scoring")
def _():
    tmp_out = tempfile.mktemp(suffix='.json')
    result = runner.invoke(main, [
        'tokenize', CORPUS_PATH,
        '-o', tmp_out, '-v', '2000', '-n', '200', '-es',
    ])
    assert result.exit_code == 0, f"Output: {result.output}"
    assert "Embedding-based phrase scoring" in result.output
    Path(tmp_out).unlink(missing_ok=True)

@test("CLI tokenize with all 3 features combined")
def _():
    tmp_out = tempfile.mktemp(suffix='.json')
    result = runner.invoke(main, [
        'tokenize', CORPUS_PATH,
        '-o', tmp_out, '-v', '2000', '-n', '200',
        '-tc', '-sp', '-es',
    ])
    assert result.exit_code == 0, f"Output: {result.output}"
    assert "Typo correction" in result.output
    assert "Streaming phrase discovery" in result.output
    assert "Embedding-based phrase scoring" in result.output
    Path(tmp_out).unlink(missing_ok=True)

@test("Typo correction + newword mode integration")
def _():
    tok = IonTokenizer(
        phrases=["machine learning"],
        words=["the", "is", "machine", "learning", "important"],
        fallback_mode="newword",
    )
    tok.enable_typo_correction(max_edit_distance=2)
    # "machne" should be corrected to "machine", triggering phrase match with "learning"
    ids = tok.encode("machne learning is important")
    # "machne" corrected to "machine", then "machine learning" matches as phrase
    assert len(ids) <= 4  # phrase + "is" + "important" = 3 tokens max

@test("Typo correction preserves correct words")
def _():
    tok = IonTokenizer(
        phrases=[],
        words=["hello", "help", "world", "word"],
        fallback_mode="character",
    )
    tok.enable_typo_correction(max_edit_distance=1)
    # "hello" is already in vocab, should NOT be corrected to "help"
    ids = tok.encode("hello world")
    decoded = tok.decode(ids)
    assert "hello" in decoded
    assert "world" in decoded

@test("Streaming phrases reduce token count over time")
def _():
    tok = IonTokenizer(
        phrases=[],
        words=["machine", "learning", "is", "great", "deep"],
        fallback_mode="newword",
    )
    # Without streaming, "machine" and "learning" are separate tokens
    ids_before = tok.encode("machine learning is great")
    assert len(ids_before) == 4

    # Manually add phrase to simulate streaming discovery
    tok._add_streaming_phrase("machine learning")
    ids_after = tok.encode("machine learning is great")
    assert len(ids_after) == 3  # "machine learning" as one phrase + "is" + "great"


# ============================================================================
# INIT WIZARD TESTS
# ============================================================================
print("\n" + "=" * 60)
print("INIT WIZARD TESTS")
print("=" * 60)

@test("CLI init interactive creates config (no build)")
def _():
    tmp_config = tempfile.mktemp(suffix='.json')
    # Simulate interactive input: use local corpus, no domain, defaults, no build
    inputs = f"{CORPUS_PATH}\nnone\n20000\nbpe\nen\n60\n40\nn\nn\nn\n0\nn\ntokenizer_test_init.json\nn\n"
    result = runner.invoke(main, ['init', '-o', tmp_config], input=inputs)
    assert result.exit_code == 0, f"Output: {result.output}"
    assert "Ion Tokenizer Setup Wizard" in result.output
    assert "Configuration Summary" in result.output
    assert "Config saved to" in result.output
    assert Path(tmp_config).exists()
    config = orjson.loads(Path(tmp_config).read_bytes())
    assert config["source"] == CORPUS_PATH
    assert config["max_vocab"] == 20000
    assert config["fallback_mode"] == "bpe"
    Path(tmp_config).unlink(missing_ok=True)

@test("CLI init shows all 8 steps")
def _():
    tmp_config = tempfile.mktemp(suffix='.json')
    inputs = f"{CORPUS_PATH}\nnone\n20000\nbpe\nen\n60\n40\nn\nn\nn\n0\nn\ntest.json\nn\n"
    result = runner.invoke(main, ['init', '-o', tmp_config], input=inputs)
    for step in range(1, 9):
        assert f"Step {step}/8" in result.output, f"Missing Step {step}/8"
    Path(tmp_config).unlink(missing_ok=True)

@test("CLI init config file has all required keys")
def _():
    tmp_config = tempfile.mktemp(suffix='.json')
    inputs = f"{CORPUS_PATH}\nnone\n20000\nbpe\nen\n60\n40\nn\nn\nn\n0\nn\ntest.json\nn\n"
    result = runner.invoke(main, ['init', '-o', tmp_config], input=inputs)
    assert result.exit_code == 0
    config = orjson.loads(Path(tmp_config).read_bytes())
    required_keys = ["source", "max_vocab", "fallback_mode", "language",
                     "phrase_target_pct", "word_target_pct", "typo_correction",
                     "streaming_phrases", "embedding_scoring", "max_word_length",
                     "preserve_case", "output"]
    for key in required_keys:
        assert key in config, f"Missing key: {key}"
    Path(tmp_config).unlink(missing_ok=True)

@test("CLI init with features enabled")
def _():
    tmp_config = tempfile.mktemp(suffix='.json')
    # Enable typo correction (y, distance 2), streaming (y), embedding (y), mwl 15, preserve case (y)
    inputs = f"{CORPUS_PATH}\nnone\n10000\nnewword\nen\n70\n30\ny\n2\ny\ny\n15\ny\ntest.json\nn\n"
    result = runner.invoke(main, ['init', '-o', tmp_config], input=inputs)
    assert result.exit_code == 0, f"Output: {result.output}"
    config = orjson.loads(Path(tmp_config).read_bytes())
    assert config["typo_correction"] == True
    assert config["typo_edit_distance"] == 2
    assert config["streaming_phrases"] == True
    assert config["embedding_scoring"] == True
    assert config["max_word_length"] == 15
    assert config["preserve_case"] == True
    assert config["max_vocab"] == 10000
    assert config["fallback_mode"] == "newword"
    Path(tmp_config).unlink(missing_ok=True)

@test("CLI init prints build command when skipping build")
def _():
    tmp_config = tempfile.mktemp(suffix='.json')
    inputs = f"{CORPUS_PATH}\nnone\n20000\nbpe\nen\n60\n40\nn\nn\nn\n0\nn\ntest.json\nn\n"
    result = runner.invoke(main, ['init', '-o', tmp_config], input=inputs)
    assert "ion tokenize" in result.output
    Path(tmp_config).unlink(missing_ok=True)

# ============================================================================
# FEATURE BENCHMARK TESTS
# ============================================================================
print("\n" + "=" * 60)
print("FEATURE BENCHMARK TESTS")
print("=" * 60)

@test("Typo correction reduces token count on typo text")
def _():
    tok = IonTokenizer(
        phrases=["machine learning", "united states"],
        words=["the", "model", "of", "was", "and", "machine", "learning",
               "united", "states", "significant", "notable"],
        fallback_mode="bpe",
    )
    tok.enable_typo_correction(max_edit_distance=2, min_word_length=3)
    clean = tok.encode("the machine learning model")
    typo = tok.encode("the machne lerning modl")
    # Typo correction should produce same or similar token count
    assert len(typo) <= len(clean) + 2  # Allow small overhead from imperfect correction

@test("Streaming discovery finds phrases from repeated text")
def _():
    tok = IonTokenizer(
        phrases=[],
        words=["the", "quick", "brown", "fox", "jumps", "over", "lazy", "dog"],
        fallback_mode="newword",
    )
    tok.enable_streaming_phrases(min_count=3, promotion_threshold=0.1, check_interval=5)
    # Feed the same text many times to trigger bigram promotion
    for _ in range(200):
        tok.encode("the quick brown fox jumps over the lazy dog")
    stats = tok.get_streaming_stats()
    assert stats["bigrams_tracked"] > 0
    assert stats["encoding_steps"] == 200

@test("Embedding scorer ranks semantically coherent phrases higher")
def _():
    sentences = [
        ["machine", "learning", "model", "training"],
        ["deep", "learning", "neural", "network"],
        ["machine", "learning", "algorithms", "data"],
        ["random", "word", "salad", "nonsense"],
    ] * 50
    scorer = EmbeddingPhraseScorer(vector_size=50, min_count=2)
    scorer.train(sentences)
    # "machine learning" should score higher than "random salad"
    ml_score = scorer.score_phrase("machine learning", 100)
    rs_score = scorer.score_phrase("random salad", 5)
    assert ml_score > rs_score, f"Expected ML ({ml_score}) > random ({rs_score})"

@test("All features combined: typo + streaming + serialization roundtrip")
def _():
    tok = IonTokenizer(
        phrases=["data science"],
        words=["the", "is", "great", "data", "science", "field"],
        fallback_mode="newword",
    )
    tok.enable_typo_correction(max_edit_distance=2)
    tok.enable_streaming_phrases(min_count=2, check_interval=5)
    # Use the tokenizer
    for _ in range(20):
        tok.encode("the data science field is great")
    # Serialize and deserialize
    data = tok.to_dict()
    assert data["typo_correction"]["enabled"] == True
    assert data["streaming_phrases"]["enabled"] == True
    tok2 = IonTokenizer.from_dict(data)
    # Typo correction should be restored
    assert tok2._typo_correction_enabled == True

@test("Feature flags produce correct CLI output messages")
def _():
    tmp_out = tempfile.mktemp(suffix='.json')
    result = runner.invoke(main, [
        'tokenize', CORPUS_PATH, '-o', tmp_out, '-v', '2000', '-n', '200',
        '-tc', '-ted', '1', '-sp', '-mwl', '15',
    ])
    assert result.exit_code == 0, f"Output: {result.output}"
    assert "Typo correction: enabled (max edit distance: 1)" in result.output
    assert "Streaming phrase discovery: enabled" in result.output
    assert "Max word length: 15" in result.output
    Path(tmp_out).unlink(missing_ok=True)


# ============================================================================
# CLEANUP AND SUMMARY
# ============================================================================
print("\n" + "=" * 60)
print("TEST SUMMARY")
print("=" * 60)
print(f"  Passed: {passed}")
print(f"  Failed: {failed}")
print(f"  Total:  {passed + failed}")

if errors:
    print(f"\nFailed tests:")
    for name, err in errors:
        print(f"  - {name}: {err}")

# Cleanup
Path(CORPUS_PATH).unlink(missing_ok=True)
if TOKENIZER_PATH:
    Path(TOKENIZER_PATH).unlink(missing_ok=True)

print()
if failed == 0:
    print("ALL TESTS PASSED!")
else:
    print(f"{failed} TESTS FAILED - see above for details")

sys.exit(1 if failed > 0 else 0)
