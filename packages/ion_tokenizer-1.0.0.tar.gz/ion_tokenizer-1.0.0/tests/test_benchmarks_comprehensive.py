#!/usr/bin/env python3
"""
Comprehensive benchmark, export, signup, and edge-case test suite for Ion.

Tests:
- Free plan registration flow
- All export formats with mini-model training
- Cross-domain benchmarks with varying settings
- Large HF dataset benchmarks with optimal-setting search
- JSON filtering (--keep-json / default)
- BPE fallback via --dangerously-enable-bpe-fallback
- Weird/underground edge cases (adversarial inputs, unicode, etc.)
"""

import json
import os
import sys
import tempfile
import shutil
import time
import random
from pathlib import Path
from unittest.mock import patch, MagicMock
from collections import Counter

sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from ion.tokenizer import IonTokenizer, SPECIAL_TOKENS, FALLBACK_ALPHABET, PLAN_TOKENS
from ion.builder import TokenizerBuilder, build_tokenizer
from ion.corpus import (
    load_corpus, normalize_text, iter_sentences_from_text, _is_json_line,
    load_spacy_tokenizer,
)
from ion.phrase_discovery import PhraseDiscoverer
from ion.stats import compute_stats, format_stats
from ion.tools import (
    get_domain_config, list_domains, DOMAIN_CONFIGS,
    export_huggingface, export_sentencepiece, export_vocab_txt,
    export_onnx, export_tiktoken, export_jsonl, export_csv,
    introspect_fallbacks, set_seed,
)
from ion.benchmarks import (
    load_benchmarks, save_benchmarks, format_benchmark_summary,
    format_quick_stats, get_ascii_chart, BASELINE_BENCHMARKS,
)
from ion.integrations import (
    IonTokenizerHF, IonDataset, IonLanguageModelDataset, BatchEncoding,
    ion_collate_fn, IonDataModule,
)
from ion.licensing import (
    _validate_email, load_config, save_config, is_registered,
    register_interactive, ION_CONFIG_DIR, ION_CONFIG_FILE,
    PLAN_NAMES, PLAN_PRICES, ION_LICENSE_VERSION,
    generate_license_md,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_corpus_file(texts, suffix=".txt"):
    fd, path = tempfile.mkstemp(suffix=suffix)
    with os.fdopen(fd, "w") as f:
        f.write("\n".join(texts))
    return path


def _build_small_tokenizer(
    texts=None, fallback_mode="character", max_vocab=500,
    keep_json=False, preserve_case=False, domain=None,
):
    """Build a small tokenizer from sample text."""
    if texts is None:
        texts = [
            "The quick brown fox jumps over the lazy dog.",
            "Machine learning models need good tokenizers.",
            "Ion is a phrase-first semantic tokenizer compiler.",
            "Neural language models benefit from better tokenization.",
            "The cat sat on the mat and looked at the bat.",
            "Deep learning has revolutionized natural language processing.",
            "Tokenization is the first step in any NLP pipeline.",
            "Good compression means fewer tokens for the same text.",
            "Phrases capture multi-word semantic units efficiently.",
        ] * 20
    path = _make_corpus_file(texts)
    fd, out = tempfile.mkstemp(suffix=".json")
    os.close(fd)
    try:
        stats = build_tokenizer(
            source=path,
            output=out,
            max_vocab_size=max_vocab,
            fallback_mode=fallback_mode,
            keep_json=keep_json,
            preserve_case=preserve_case,
            license_config={"plan": "free", "email": "test@test.com",
                            "agreed_to_license": True},
        )
        import orjson
        data = orjson.loads(Path(out).read_bytes())
        tok = IonTokenizer.from_dict(data)
        return tok, stats, out
    finally:
        os.unlink(path)


class TinyLM(nn.Module):
    """Tiny language model for export testing."""
    def __init__(self, vocab_size, d=32):
        super().__init__()
        self.emb = nn.Embedding(vocab_size, d)
        self.fc = nn.Linear(d, vocab_size)

    def forward(self, input_ids, labels=None):
        x = self.emb(input_ids)
        logits = self.fc(x)
        loss = None
        if labels is not None:
            loss = nn.functional.cross_entropy(
                logits.view(-1, logits.size(-1)), labels.view(-1)
            )
        return {"loss": loss, "logits": logits}


# ===========================================================================
# 1. FREE PLAN SIGNUP
# ===========================================================================

class TestFreePlanSignup:
    """Test the free plan registration flow."""

    def test_email_validation(self):
        assert _validate_email("user@example.com")
        assert _validate_email("a.b+c@x.y.z")
        assert not _validate_email("")
        assert not _validate_email("noatsign")
        assert not _validate_email("@no-user.com")
        assert not _validate_email("spaces in@email.com")

    def test_save_and_load_config(self, tmp_path, monkeypatch):
        config_dir = tmp_path / ".ion"
        config_file = config_dir / "config.json"
        monkeypatch.setattr("ion.licensing.ION_CONFIG_DIR", config_dir)
        monkeypatch.setattr("ion.licensing.ION_CONFIG_FILE", config_file)

        config = {
            "email": "test@test.com",
            "plan": "free",
            "agreed_to_license": True,
            "license_version": ION_LICENSE_VERSION,
        }
        save_config(config)
        loaded = load_config()
        assert loaded is not None
        assert loaded["email"] == "test@test.com"
        assert loaded["plan"] == "free"

    def test_is_registered(self, tmp_path, monkeypatch):
        config_dir = tmp_path / ".ion"
        config_file = config_dir / "config.json"
        monkeypatch.setattr("ion.licensing.ION_CONFIG_DIR", config_dir)
        monkeypatch.setattr("ion.licensing.ION_CONFIG_FILE", config_file)

        assert not is_registered()

        config = {
            "email": "test@test.com",
            "plan": "free",
            "agreed_to_license": True,
            "license_version": ION_LICENSE_VERSION,
        }
        save_config(config)
        assert is_registered()

    def test_register_interactive_free_plan(self, tmp_path, monkeypatch):
        config_dir = tmp_path / ".ion"
        config_file = config_dir / "config.json"
        pending_sync = config_dir / "pending_sync.json"
        monkeypatch.setattr("ion.licensing.ION_CONFIG_DIR", config_dir)
        monkeypatch.setattr("ion.licensing.ION_CONFIG_FILE", config_file)
        monkeypatch.setattr("ion.licensing.ION_PENDING_SYNC_FILE", pending_sync)
        # Simulate offline mode
        monkeypatch.setattr("ion.licensing._check_internet", lambda: False)
        # Auto-accept license agreement
        import click
        monkeypatch.setattr(click, "confirm", lambda *a, **kw: True)

        result = register_interactive(
            force=True,
            preset_email="bench@test.com",
            preset_plan="free",
        )
        assert result is not None
        assert result["plan"] == "free"
        assert result["email"] == "bench@test.com"
        assert result["agreed_to_license"] is True

    def test_plan_names_and_prices(self):
        assert "Free" in PLAN_NAMES.values()
        assert "$0" in PLAN_PRICES.values()
        for plan in ("free", "closed", "open-large", "enterprise"):
            assert plan in PLAN_NAMES
            assert plan in PLAN_PRICES

    def test_plan_tokens_injected(self):
        tok = IonTokenizer(
            phrases=["hello world"],
            words=["hello", "world"],
            plan_token="<ion-tokenizer-free>",
        )
        assert "<ion-tokenizer-free>" in tok.vocab

    def test_generate_license_md(self):
        md = generate_license_md(
            email="test@test.com",
            plan="free",
            tokenizer_id="test-123",
            created_at="2025-01-01",
            version="3.0",
        )
        assert "Free" in md or "free" in md.lower()
        assert "test@test.com" in md


# ===========================================================================
# 2. ALL EXPORT FORMATS + MINI-MODEL TRAINING
# ===========================================================================

class TestExportFormatsWithTraining:
    """Build a small tokenizer, export in every format, and train a tiny model."""

    @pytest.fixture(autouse=True)
    def setup(self, tmp_path):
        self.tmp = tmp_path
        self.tok, self.stats, self.tok_path = _build_small_tokenizer()
        self.vocab_size = len(self.tok.vocab)

    def _train_tiny_model(self, tok):
        model = TinyLM(len(tok.vocab))
        optimizer = torch.optim.SGD(model.parameters(), lr=0.01)
        text = "the quick brown fox jumps over the lazy dog"
        ids = tok.encode(text)
        if len(ids) < 2:
            return model
        t = torch.tensor([ids[:16] if len(ids) > 16 else ids])
        for _ in range(3):
            out = model(t[:, :-1], labels=t[:, 1:])
            out["loss"].backward()
            optimizer.step()
            optimizer.zero_grad()
        return model

    def test_export_huggingface(self):
        out_dir = str(self.tmp / "hf_export")
        export_huggingface(self.tok_path, out_dir)
        assert (Path(out_dir) / "tokenizer.json").exists()
        assert (Path(out_dir) / "tokenizer_config.json").exists()
        self._train_tiny_model(self.tok)

    def test_export_sentencepiece(self):
        out = str(self.tmp / "sp_vocab.txt")
        export_sentencepiece(self.tok_path, out)
        assert Path(out).exists()
        lines = Path(out).read_text().strip().split("\n")
        assert len(lines) > 0
        self._train_tiny_model(self.tok)

    def test_export_vocab_txt(self):
        out = str(self.tmp / "vocab.txt")
        export_vocab_txt(self.tok_path, out)
        assert Path(out).exists()
        self._train_tiny_model(self.tok)

    def test_export_onnx(self):
        out_dir = str(self.tmp / "onnx_export")
        export_onnx(self.tok_path, out_dir)
        assert (Path(out_dir) / "vocab.txt").exists()
        assert (Path(out_dir) / "config.json").exists()
        self._train_tiny_model(self.tok)

    def test_export_tiktoken(self):
        out = str(self.tmp / "tiktoken.bpe")
        export_tiktoken(self.tok_path, out)
        assert Path(out).exists()
        content = Path(out).read_text()
        assert len(content) > 0
        self._train_tiny_model(self.tok)

    def test_export_jsonl(self):
        out = str(self.tmp / "vocab.jsonl")
        export_jsonl(self.tok_path, out)
        assert Path(out).exists()
        lines = Path(out).read_text().strip().split("\n")
        for line in lines[:5]:
            obj = json.loads(line)
            assert "id" in obj
            assert "token" in obj
        self._train_tiny_model(self.tok)

    def test_export_csv(self):
        out = str(self.tmp / "vocab.csv")
        export_csv(self.tok_path, out)
        assert Path(out).exists()
        lines = Path(out).read_text().strip().split("\n")
        assert "id" in lines[0].lower() or "token" in lines[0].lower()
        self._train_tiny_model(self.tok)

    def test_all_exports_produce_valid_tokenizer_for_training(self):
        """Train a model after every export to verify none corrupt the tokenizer."""
        model = self._train_tiny_model(self.tok)
        # Verify model can do inference
        ids = self.tok.encode("hello world")
        if ids:
            t = torch.tensor([ids])
            with torch.no_grad():
                out = model(t)
            assert out["logits"].shape[-1] == len(self.tok.vocab)


# ===========================================================================
# 3. CROSS-DOMAIN BENCHMARKS WITH VARYING SETTINGS
# ===========================================================================

class TestCrossDomainBenchmarks:
    """Test all domains with different settings combos."""

    DOMAINS = ["general", "wikipedia", "code", "legal", "chat", "medical", "scientific"]

    def test_all_domain_configs_exist(self):
        for d in self.DOMAINS:
            cfg = get_domain_config(d)
            assert "description" in cfg
            assert "min_word_freq" in cfg
            assert "phrase_threshold" in cfg

    def test_domain_list(self):
        domains = list_domains()
        for d in self.DOMAINS:
            assert d in domains

    @pytest.mark.parametrize("domain", DOMAINS)
    def test_build_tokenizer_per_domain(self, domain):
        """Build a tokenizer for each domain and verify it works."""
        texts = [
            "The quick brown fox jumps over the lazy dog.",
            "Machine learning models need good tokenizers.",
            "In the united states, many people use new york as a hub.",
            "According to the report, climate change is a major concern.",
            "One of the most important aspects is data science.",
            "As a result of machine learning, the system has improved.",
        ] * 30
        path = _make_corpus_file(texts)
        fd, out = tempfile.mkstemp(suffix=".json")
        os.close(fd)
        try:
            stats = build_tokenizer(
                source=path,
                output=out,
                max_vocab_size=300,
                fallback_mode="character",
                license_config={"plan": "free", "email": "test@test.com",
                                "agreed_to_license": True},
            )
            assert stats["vocab_size"] > 0
            assert stats["phrase_count"] >= 0
        finally:
            os.unlink(path)
            os.unlink(out)

    @pytest.mark.parametrize("fallback", ["character", "word", "newword"])
    def test_fallback_modes(self, fallback):
        tok, stats, path = _build_small_tokenizer(fallback_mode=fallback)
        assert stats["vocab_size"] > 0
        result = tok.encode("this is an unknown xyzzy word")
        assert len(result) > 0
        os.unlink(path)

    def test_bpe_fallback_mode(self):
        """BPE fallback (the 'dangerous' one) still works."""
        tok, stats, path = _build_small_tokenizer(fallback_mode="bpe")
        assert stats["vocab_size"] > 0
        result = tok.encode("supercalifragilisticexpialidocious")
        assert len(result) > 0
        os.unlink(path)

    @pytest.mark.parametrize("phrase_pct,word_pct", [
        (80.0, 20.0), (50.0, 50.0), (30.0, 70.0), (60.0, 40.0),
    ])
    def test_phrase_word_allocation(self, phrase_pct, word_pct):
        texts = [
            "The machine learning model of the united states is very good.",
            "According to the report, artificial intelligence has improved.",
        ] * 50
        path = _make_corpus_file(texts)
        fd, out = tempfile.mkstemp(suffix=".json")
        os.close(fd)
        try:
            stats = build_tokenizer(
                source=path,
                output=out,
                max_vocab_size=300,
                phrase_target_pct=phrase_pct,
                word_target_pct=word_pct,
                fallback_mode="character",
                license_config={"plan": "free", "email": "t@t.com",
                                "agreed_to_license": True},
            )
            assert stats["vocab_size"] > 0
        finally:
            os.unlink(path)
            os.unlink(out)


# ===========================================================================
# 4. OPTIMAL SETTINGS SEARCH (SIMULATED LARGE BENCHMARK)
# ===========================================================================

class TestOptimalSettingsSearch:
    """Simulate a settings sweep across vocab sizes and parameters."""

    def test_vocab_size_sweep(self):
        """Test multiple vocab sizes and find the one with best compression."""
        texts = [
            "The quick brown fox jumps over the lazy dog.",
            "Machine learning models need good tokenizers.",
            "Ion is a phrase-first semantic tokenizer compiler.",
            "Neural language models benefit from better tokenization.",
            "Deep learning has revolutionized natural language processing.",
            "The united states has many machine learning researchers.",
            "According to the report, data science is growing rapidly.",
            "One of the most important aspects of artificial intelligence.",
        ] * 40
        path = _make_corpus_file(texts)
        results = []
        for vocab_size in [200, 500, 1000, 2000]:
            fd, out = tempfile.mkstemp(suffix=".json")
            os.close(fd)
            try:
                stats = build_tokenizer(
                    source=path,
                    output=out,
                    max_vocab_size=vocab_size,
                    fallback_mode="character",
                    license_config={"plan": "free", "email": "t@t.com",
                                    "agreed_to_license": True},
                )
                results.append({
                    "vocab_size": vocab_size,
                    "actual_vocab": stats["vocab_size"],
                    "compression": stats.get("compression_ratio", 1.0),
                    "seq_reduction": stats.get("sequence_length_reduction_pct", 0),
                })
            finally:
                os.unlink(out)
        os.unlink(path)

        # Verify we got results for all sizes
        assert len(results) == 4
        # Larger vocab should generally achieve better or equal compression
        assert all(r["actual_vocab"] > 0 for r in results)

    def test_cross_domain_optimal_settings(self):
        """Compare settings across different text domains."""
        domain_texts = {
            "general": [
                "The quick brown fox jumps over the lazy dog.",
                "People enjoy reading books and watching movies.",
            ] * 30,
            "code": [
                "def foo(x): return x + 1",
                "class MyClass: pass",
                "import os; os.path.join('a', 'b')",
                "for i in range(10): print(i)",
            ] * 30,
            "legal": [
                "The party of the first part hereby agrees to the terms.",
                "Notwithstanding any provision to the contrary herein.",
                "The court finds that the defendant is liable for damages.",
            ] * 30,
            "chat": [
                "hey how are you doing today?",
                "lol that's so funny haha",
                "wanna grab lunch tomorrow?",
                "ok sounds good see you then!",
            ] * 30,
        }

        domain_results = {}
        for domain_name, texts in domain_texts.items():
            path = _make_corpus_file(texts)
            fd, out = tempfile.mkstemp(suffix=".json")
            os.close(fd)
            try:
                stats = build_tokenizer(
                    source=path,
                    output=out,
                    max_vocab_size=500,
                    fallback_mode="character",
                    license_config={"plan": "free", "email": "t@t.com",
                                    "agreed_to_license": True},
                )
                domain_results[domain_name] = {
                    "vocab_size": stats["vocab_size"],
                    "compression": stats.get("compression_ratio", 1.0),
                    "phrases": stats["phrase_count"],
                    "words": stats["word_count"],
                }
            finally:
                os.unlink(path)
                os.unlink(out)

        assert len(domain_results) == 4
        # Code domain with preserve_case should differ from general
        for d in domain_results:
            assert domain_results[d]["vocab_size"] > 0


# ===========================================================================
# 5. JSON FILTERING (--keep-json)
# ===========================================================================

class TestKeepJson:
    """Test the --keep-json flag and JSON filtering."""

    def test_is_json_line_detection(self):
        assert _is_json_line('{"key": "value"}')
        assert _is_json_line('[1, 2, 3]')
        assert _is_json_line('  {"nested": {"a": 1}}  ')
        assert not _is_json_line("This is normal text.")
        assert not _is_json_line("")
        assert not _is_json_line("Hello world")
        # High density of JSON chars
        assert _is_json_line('{"a":"b","c":"d","e":"f","g":"h"}')

    def test_json_filtered_by_default(self):
        """Without --keep-json, JSON lines should be skipped."""
        texts = [
            'The quick brown fox.',
            '{"name": "test", "value": 42}',
            'Another normal sentence.',
            '[{"a": 1}, {"b": 2}]',
        ]
        path = _make_corpus_file(texts)
        fd, out = tempfile.mkstemp(suffix=".json")
        os.close(fd)
        try:
            stats = build_tokenizer(
                source=path, output=out, max_vocab_size=200,
                fallback_mode="character", keep_json=False,
                license_config={"plan": "free", "email": "t@t.com",
                                "agreed_to_license": True},
            )
            import orjson
            data = orjson.loads(Path(out).read_bytes())
            tok = IonTokenizer.from_dict(data)
            # JSON structural tokens should not be prominent
            vocab_tokens = list(tok.vocab.keys())
            # "name" and "value" from JSON shouldn't be in word tokens
            word_tokens = tok.token_classes.get("word", [])
            # Normal text words should be present
            assert any("fox" in str(w) for w in word_tokens) or \
                   any("quick" in str(w) for w in word_tokens) or \
                   any("sentence" in str(w) for w in word_tokens)
        finally:
            os.unlink(path)
            os.unlink(out)

    def test_json_kept_with_flag(self):
        """With --keep-json, JSON content should be tokenized."""
        texts = [
            '{"name": "test", "value": 42}',
            '{"config": {"model": "gpt", "layers": 12}}',
        ] * 30
        path = _make_corpus_file(texts)
        fd, out = tempfile.mkstemp(suffix=".json")
        os.close(fd)
        try:
            stats = build_tokenizer(
                source=path, output=out, max_vocab_size=200,
                fallback_mode="character", keep_json=True,
                license_config={"plan": "free", "email": "t@t.com",
                                "agreed_to_license": True},
            )
            # Should have vocab entries
            assert stats["vocab_size"] > len(SPECIAL_TOKENS)
        finally:
            os.unlink(path)
            os.unlink(out)

    def test_iter_sentences_keep_json(self):
        nlp = load_spacy_tokenizer()
        text = 'Hello world.\n{"key": "val"}\nGoodbye.'
        # Without keep_json
        sents_no_json = list(iter_sentences_from_text(text, nlp, keep_json=False))
        # With keep_json
        sents_json = list(iter_sentences_from_text(text, nlp, keep_json=True))
        # The JSON-kept version should have more tokens
        total_no = sum(len(s) for s in sents_no_json)
        total_yes = sum(len(s) for s in sents_json)
        assert total_yes >= total_no


# ===========================================================================
# 6. DANGEROUSLY ENABLE BPE FALLBACK FLAG
# ===========================================================================

class TestDangerouslyEnableBpeFallback:
    """Test the --dangerously-enable-bpe-fallback CLI flag behavior."""

    def test_bpe_fallback_produces_bpe_tokens(self):
        tok, stats, path = _build_small_tokenizer(fallback_mode="bpe")
        # Encode an unknown word - should produce BPE subword tokens
        result = tok.encode("xyzzyplughfoobar")
        assert len(result) > 0
        os.unlink(path)

    def test_character_fallback_default(self):
        tok, stats, path = _build_small_tokenizer(fallback_mode="character")
        result = tok.encode("xyzzyplugh")
        assert len(result) > 0
        # Should produce character-level tokens
        os.unlink(path)

    def test_bpe_vs_character_token_count(self):
        """BPE should typically produce fewer tokens than character for unknown words."""
        tok_bpe, _, p1 = _build_small_tokenizer(fallback_mode="bpe")
        tok_char, _, p2 = _build_small_tokenizer(fallback_mode="character")
        word = "antidisestablishmentarianism"
        bpe_ids = tok_bpe.encode(word)
        char_ids = tok_char.encode(word)
        # Both should produce output
        assert len(bpe_ids) > 0
        assert len(char_ids) > 0
        os.unlink(p1)
        os.unlink(p2)


# ===========================================================================
# 7. BENCHMARK DATA & FORMATTING
# ===========================================================================

class TestBenchmarkData:
    """Test benchmark data loading, formatting, and management."""

    def test_baseline_benchmarks_structure(self):
        b = BASELINE_BENCHMARKS
        assert "vocab_sweep" in b
        assert "ion_vs_bpe" in b
        assert "domain_benchmarks" in b
        assert "hf_dataset_matrix" in b

    def test_load_benchmarks_returns_baseline(self):
        b = load_benchmarks()
        assert isinstance(b, dict)
        assert "vocab_sweep" in b

    def test_format_benchmark_summary(self):
        summary = format_benchmark_summary()
        assert isinstance(summary, str)
        assert len(summary) > 0

    def test_format_quick_stats(self):
        qs = format_quick_stats()
        assert isinstance(qs, str)

    def test_ascii_chart(self):
        chart = get_ascii_chart()
        assert isinstance(chart, str)

    def test_save_and_load_benchmarks(self, tmp_path, monkeypatch):
        b = BASELINE_BENCHMARKS.copy()
        bench_file = tmp_path / ".ion_benchmarks.json"
        monkeypatch.setattr("ion.benchmarks.BENCHMARK_FILE", str(bench_file))
        save_benchmarks(b)
        loaded = load_benchmarks()
        assert "vocab_sweep" in loaded

    def test_hf_dataset_matrix(self):
        matrix = BASELINE_BENCHMARKS.get("hf_dataset_matrix", {})
        assert isinstance(matrix, dict)
        # Should have multiple datasets
        assert len(matrix) > 0

    def test_domain_benchmarks(self):
        db = BASELINE_BENCHMARKS.get("domain_benchmarks", {})
        for domain in ["wikipedia", "code", "legal", "chat"]:
            assert domain in db


# ===========================================================================
# 8. WEIRD / UNDERGROUND / ADVERSARIAL EDGE CASES
# ===========================================================================

class TestWeirdEdgeCases:
    """Adversarial, unicode, empty, and edge-case inputs."""

    def test_empty_string(self):
        tok, _, path = _build_small_tokenizer()
        result = tok.encode("")
        assert result == []
        os.unlink(path)

    def test_whitespace_only(self):
        tok, _, path = _build_small_tokenizer()
        result = tok.encode("   \n\t\n   ")
        # Should produce empty or minimal
        assert isinstance(result, list)
        os.unlink(path)

    def test_single_character(self):
        tok, _, path = _build_small_tokenizer()
        result = tok.encode("a")
        assert len(result) >= 1
        os.unlink(path)

    def test_very_long_word(self):
        tok, _, path = _build_small_tokenizer()
        long_word = "a" * 1000
        result = tok.encode(long_word)
        assert len(result) > 0
        os.unlink(path)

    def test_unicode_emoji(self):
        tok, _, path = _build_small_tokenizer()
        result = tok.encode("Hello 🌍🔥 world")
        assert len(result) > 0
        os.unlink(path)

    def test_unicode_cjk(self):
        tok, _, path = _build_small_tokenizer()
        result = tok.encode("这是一个测试 Hello")
        assert len(result) > 0
        os.unlink(path)

    def test_unicode_rtl(self):
        tok, _, path = _build_small_tokenizer()
        result = tok.encode("مرحبا بالعالم Hello")
        assert len(result) > 0
        os.unlink(path)

    def test_mixed_scripts(self):
        tok, _, path = _build_small_tokenizer()
        result = tok.encode("Hello Мир 世界 مرحبا")
        assert len(result) > 0
        os.unlink(path)

    def test_control_characters(self):
        tok, _, path = _build_small_tokenizer()
        result = tok.encode("Hello\x00World\x01Test")
        assert isinstance(result, list)
        os.unlink(path)

    def test_zalgo_text(self):
        tok, _, path = _build_small_tokenizer()
        zalgo = "H̷̢̧̛̙̣̻̤̦̰͉̘͉̬̰̦̻̮̻̫̙̱̣̲̠̞̤̦̟̝̺̯̪̦̗̙̥̝̗̗̫̞̪̠̮̙̤̞̣̼̮͉̤̟̰̦̮̝̗̻̦̬̣̺̲e̷l̶l̵o̶"
        result = tok.encode(zalgo)
        assert isinstance(result, list)
        os.unlink(path)

    def test_only_punctuation(self):
        tok, _, path = _build_small_tokenizer()
        result = tok.encode("!@#$%^&*()_+-=[]{}|;':\",./<>?")
        assert isinstance(result, list)
        os.unlink(path)

    def test_repeated_spaces(self):
        tok, _, path = _build_small_tokenizer()
        result = tok.encode("hello      world")
        assert len(result) > 0
        os.unlink(path)

    def test_newlines_tabs(self):
        tok, _, path = _build_small_tokenizer()
        result = tok.encode("hello\n\nworld\t\ttab")
        assert len(result) > 0
        os.unlink(path)

    def test_html_content(self):
        tok, _, path = _build_small_tokenizer()
        result = tok.encode("<div class='test'><p>Hello <b>World</b></p></div>")
        assert len(result) > 0
        os.unlink(path)

    def test_url_content(self):
        tok, _, path = _build_small_tokenizer()
        result = tok.encode("Visit https://example.com/path?q=test&v=1#anchor for info")
        assert len(result) > 0
        os.unlink(path)

    def test_code_content(self):
        tok, _, path = _build_small_tokenizer()
        result = tok.encode("def foo(x: int) -> bool:\n    return x > 0")
        assert len(result) > 0
        os.unlink(path)

    def test_json_string_input(self):
        tok, _, path = _build_small_tokenizer()
        result = tok.encode('{"key": "value", "num": 42}')
        assert len(result) > 0
        os.unlink(path)

    def test_base64_content(self):
        tok, _, path = _build_small_tokenizer()
        import base64
        b64 = base64.b64encode(b"Hello World" * 100).decode()
        result = tok.encode(b64)
        assert isinstance(result, list)
        os.unlink(path)

    def test_numbers_only(self):
        tok, _, path = _build_small_tokenizer()
        result = tok.encode("12345678901234567890")
        assert len(result) > 0
        os.unlink(path)

    def test_mixed_case_aggressive(self):
        tok, _, path = _build_small_tokenizer()
        result = tok.encode("hElLo WoRlD tHiS iS mIxEd CaSe")
        assert len(result) > 0
        os.unlink(path)

    def test_preserve_case_mode(self):
        tok, _, path = _build_small_tokenizer(preserve_case=True)
        # With preserve_case, "Hello" and "hello" should differ
        r1 = tok.encode("Hello")
        r2 = tok.encode("hello")
        # At least one should produce output
        assert len(r1) > 0 or len(r2) > 0
        os.unlink(path)

    def test_extremely_repetitive(self):
        tok, _, path = _build_small_tokenizer()
        result = tok.encode("the " * 500)
        assert len(result) > 0
        os.unlink(path)

    def test_single_word_repeated(self):
        tok, _, path = _build_small_tokenizer()
        result = tok.encode("test test test test test")
        assert len(result) > 0
        os.unlink(path)

    def test_encode_decode_roundtrip(self):
        tok, _, path = _build_small_tokenizer()
        text = "the quick brown fox"
        ids = tok.encode(text)
        decoded = tok.decode(ids)
        assert isinstance(decoded, str)
        assert len(decoded) > 0
        os.unlink(path)

    def test_special_tokens_in_input(self):
        tok, _, path = _build_small_tokenizer()
        result = tok.encode("<pad> <unk> <bos> <eos>")
        assert isinstance(result, list)
        os.unlink(path)

    def test_sql_injection_like(self):
        tok, _, path = _build_small_tokenizer()
        result = tok.encode("'; DROP TABLE users; --")
        assert isinstance(result, list)
        os.unlink(path)

    def test_xss_like(self):
        tok, _, path = _build_small_tokenizer()
        result = tok.encode("<script>alert('xss')</script>")
        assert isinstance(result, list)
        os.unlink(path)

    def test_null_bytes(self):
        tok, _, path = _build_small_tokenizer()
        result = tok.encode("hello\x00\x00world")
        assert isinstance(result, list)
        os.unlink(path)

    def test_very_long_sentence(self):
        tok, _, path = _build_small_tokenizer()
        words = ["word"] * 10000
        result = tok.encode(" ".join(words))
        assert len(result) > 0
        os.unlink(path)

    def test_markdown_content(self):
        tok, _, path = _build_small_tokenizer()
        md = "# Header\n\n**bold** _italic_ `code`\n\n- item1\n- item2\n\n[link](url)"
        result = tok.encode(md)
        assert len(result) > 0
        os.unlink(path)

    def test_latex_content(self):
        tok, _, path = _build_small_tokenizer()
        latex = r"\begin{equation} E = mc^2 \end{equation}"
        result = tok.encode(latex)
        assert len(result) > 0
        os.unlink(path)


# ===========================================================================
# 9. STATS AND INTROSPECTION
# ===========================================================================

class TestStatsAndIntrospection:
    """Test stats computation and fallback introspection."""

    def test_compute_stats(self):
        tok, _, path = _build_small_tokenizer()
        stats = compute_stats(path)
        assert "vocab_size" in stats
        assert "phrase_tokens" in stats
        assert "word_tokens" in stats
        os.unlink(path)

    def test_format_stats(self):
        tok, _, path = _build_small_tokenizer()
        stats = compute_stats(path)
        formatted = format_stats(stats)
        assert isinstance(formatted, str)
        assert len(formatted) > 0
        os.unlink(path)

    def test_introspect_fallbacks(self):
        tok, _, path = _build_small_tokenizer()
        report = introspect_fallbacks(path, "xyzzy hello the")
        assert isinstance(report, dict)
        assert "fallback_rate" in report
        os.unlink(path)


# ===========================================================================
# 10. INTEGRATION: HF TOKENIZER WRAPPER + DATASET
# ===========================================================================

class TestIntegrations:
    """Test IonTokenizerHF, IonDataset, and training integration."""

    @pytest.fixture(autouse=True)
    def setup(self, tmp_path):
        self.tmp = tmp_path
        self.tok, self.stats, self.tok_path = _build_small_tokenizer()

    def test_hf_tokenizer_wrapper(self):
        hf_tok = IonTokenizerHF(self.tok)
        result = hf_tok("hello world")
        assert "input_ids" in result
        assert len(result["input_ids"]) > 0

    def test_ion_dataset(self):
        texts = ["the quick brown fox", "hello world"]
        ds = IonDataset(texts, self.tok, max_length=16)
        assert len(ds) == 2
        item = ds[0]
        assert "input_ids" in item

    def test_lm_dataset(self):
        texts = ["the quick brown fox jumps over the lazy dog"] * 5
        ds = IonLanguageModelDataset(texts, self.tok, block_size=16)
        assert len(ds) > 0
        item = ds[0]
        assert "input_ids" in item
        assert "labels" in item

    def test_train_with_ion_dataset(self):
        texts = ["the quick brown fox jumps over the lazy dog"] * 10
        ds = IonLanguageModelDataset(texts, self.tok, block_size=16)
        loader = DataLoader(ds, batch_size=2, collate_fn=ion_collate_fn(0))
        model = TinyLM(len(self.tok.vocab))
        optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

        for batch in loader:
            out = model(batch["input_ids"], labels=batch["labels"])
            if out["loss"] is not None:
                out["loss"].backward()
                optimizer.step()
                optimizer.zero_grad()
            break  # Just one batch

    def teardown_method(self, method):
        if hasattr(self, "tok_path") and os.path.exists(self.tok_path):
            os.unlink(self.tok_path)


# ===========================================================================
# 11. REPRODUCIBILITY
# ===========================================================================

class TestReproducibility:
    """Test seeded builds produce identical results."""

    def test_seeded_build_deterministic(self):
        texts = [
            "The quick brown fox jumps over the lazy dog.",
            "Machine learning models need good tokenizers.",
        ] * 30
        path = _make_corpus_file(texts)

        results = []
        for _ in range(2):
            fd, out = tempfile.mkstemp(suffix=".json")
            os.close(fd)
            set_seed(42)
            stats = build_tokenizer(
                source=path, output=out, max_vocab_size=200,
                fallback_mode="character",
                license_config={"plan": "free", "email": "t@t.com",
                                "agreed_to_license": True},
            )
            results.append(stats)
            os.unlink(out)
        os.unlink(path)

        assert results[0]["vocab_size"] == results[1]["vocab_size"]
        assert results[0]["phrase_count"] == results[1]["phrase_count"]


# ===========================================================================
# 12. SERIALIZATION ROUNDTRIP
# ===========================================================================

class TestSerializationRoundtrip:
    """Test tokenizer save/load roundtrip."""

    def test_to_dict_from_dict(self):
        tok, _, path = _build_small_tokenizer()
        d = tok.to_dict()
        tok2 = IonTokenizer.from_dict(d)
        assert len(tok2.vocab) == len(tok.vocab)
        text = "the quick brown fox"
        assert tok.encode(text) == tok2.encode(text)
        os.unlink(path)

    def test_json_roundtrip(self):
        tok, _, path = _build_small_tokenizer()
        import orjson
        d = tok.to_dict()
        serialized = orjson.dumps(d)
        deserialized = orjson.loads(serialized)
        tok2 = IonTokenizer.from_dict(deserialized)
        assert tok.encode("hello world") == tok2.encode("hello world")
        os.unlink(path)


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short", "-x"])
