#!/usr/bin/env python3
"""Comprehensive tests for ion.compat modules."""

import math
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

passed = 0
failed = 0

def test(name, condition):
    global passed, failed
    if condition:
        passed += 1
        print(f"  PASS: {name}")
    else:
        failed += 1
        print(f"  FAIL: {name}")

def approx(a, b, tol=1e-2):
    if isinstance(a, (list, tuple)):
        return all(approx(x, y, tol) for x, y in zip(a, b))
    return abs(a - b) < tol

# ===========================================================================
print("=" * 60)
print("TESTING ion.compat.ion_phrases")
print("=" * 60)

from ion.compat.ion_phrases import Phrases, FrozenPhrases, ENGLISH_CONNECTOR_WORDS

# Test ENGLISH_CONNECTOR_WORDS
test("ENGLISH_CONNECTOR_WORDS is frozenset", isinstance(ENGLISH_CONNECTOR_WORDS, frozenset))
test("Contains 'the'", "the" in ENGLISH_CONNECTOR_WORDS)
test("Contains 'of'", "of" in ENGLISH_CONNECTOR_WORDS)
test("Contains 'and'", "and" in ENGLISH_CONNECTOR_WORDS)
test("Does not contain 'cat'", "cat" not in ENGLISH_CONNECTOR_WORDS)

# Test basic phrase detection
sents = [
    ["new", "york", "city", "is", "great"],
    ["new", "york", "city", "has", "buildings"],
    ["new", "york", "city", "is", "big"],
    ["new", "york", "city", "weather", "is", "cold"],
    ["new", "york", "city", "subway", "is", "fast"],
    ["i", "love", "new", "york"],
    ["new", "york", "is", "amazing"],
    ["new", "york", "times", "is", "good"],
    ["new", "york", "stock", "exchange"],
    ["new", "york", "knicks", "won"],
]
p = Phrases(sents, min_count=2, threshold=0.001)
test("Phrases creates phrasegrams", len(p.phrasegrams) > 0)
test("new+york detected", ("new", "york") in p.phrasegrams)

# Test freeze
frozen = p.freeze()
test("freeze returns FrozenPhrases", isinstance(frozen, FrozenPhrases))
result = frozen[["new", "york", "city"]]
test("Frozen transforms sentences", "new_york" in result[0] if result else False)

# Test NPMI scoring
p_npmi = Phrases(sents, min_count=2, threshold=-1, scoring="npmi")
test("NPMI scoring works", len(p_npmi.phrasegrams) >= 0)

# Test export
exported = p.export_phrases()
test("export_phrases returns dict", isinstance(exported, dict))

# Test empty input
p_empty = Phrases([], min_count=1, threshold=0.001)
test("Empty sentences OK", len(p_empty.phrasegrams) == 0)

# Test single word sentences
p_single = Phrases([["hello"], ["world"]], min_count=1, threshold=0.001)
test("Single-word sentences OK", len(p_single.phrasegrams) == 0)

# ===========================================================================
print()
print("=" * 60)
print("TESTING ion.compat.ion_embeddings")
print("=" * 60)

from ion.compat.ion_embeddings import Word2Vec, KeyedVectors

# Test KeyedVectors
kv = KeyedVectors(3)
kv.add_vector("cat", [1.0, 0.0, 0.0])
kv.add_vector("dog", [0.9, 0.1, 0.0])
kv.add_vector("car", [0.0, 0.0, 1.0])

test("KeyedVectors contains", "cat" in kv)
test("KeyedVectors getitem", kv["cat"] == [1.0, 0.0, 0.0])
test("KeyedVectors len", len(kv) == 3)

sim = kv.similarity("cat", "dog")
test("cat-dog similarity > car", sim > kv.similarity("cat", "car"))

most_sim = kv.most_similar(positive=["cat"], topn=2)
test("most_similar returns list", len(most_sim) == 2)
test("most_similar top is dog", most_sim[0][0] == "dog")

# Test Word2Vec training
sents_w2v = [
    ["the", "cat", "sat", "on", "the", "mat"],
    ["the", "dog", "sat", "on", "the", "rug"],
    ["the", "cat", "chased", "the", "dog"],
    ["the", "dog", "chased", "the", "cat"],
    ["cats", "and", "dogs", "are", "pets"],
] * 20  # repeat for enough data

model = Word2Vec(sents_w2v, vector_size=20, window=3, min_count=2, epochs=10, seed=42)
test("Word2Vec trains", model.wv is not None)
test("Word2Vec has vocab", len(model.wv) > 0)
test("'cat' in vocab", "cat" in model.wv)
test("'the' in vocab", "the" in model.wv)

# Test save/load
import tempfile
with tempfile.NamedTemporaryFile(suffix=".bin", delete=False) as f:
    tmppath = f.name
model.save(tmppath)
loaded = Word2Vec.load(tmppath)
test("Save/load preserves vocab", len(loaded.wv) == len(model.wv))
test("Save/load preserves words", "cat" in loaded.wv)
os.unlink(tmppath)

# ===========================================================================
print()
print("=" * 60)
print("TESTING ion.compat.ion_math - sparse")
print("=" * 60)

from ion.compat.ion_math import (
    sparse, spatial, optimize, stats, linalg, signal, special, interpolate, integrate,
    coo_matrix, csr_matrix, csc_matrix, KDTree, cdist, pdist,
    pearsonr, spearmanr, ttest_ind, zscore, entropy,
    minimize, minimize_scalar, brentq, bisect, curve_fit,
    solve, inv, det, norm, cholesky, qr, eigh,
    convolve, correlate, find_peaks, medfilt,
    gamma_func, gammaln, erf, expit, logit, softmax,
    interp1d, quad, trapezoid,
)

# Sparse matrices
coo = coo_matrix(([1.0, 2.0, 3.0], ([0, 1, 2], [0, 1, 2])), shape=(3, 3))
test("COO nnz", coo.nnz == 3)
test("COO shape", coo.shape == (3, 3))
arr = coo.toarray()
test("COO toarray diagonal", arr[0][0] == 1.0 and arr[1][1] == 2.0 and arr[2][2] == 3.0)

csr = coo.tocsr()
test("CSR shape", csr.shape == (3, 3))
test("CSR nnz", csr.nnz == 3)
csr_arr = csr.toarray()
test("CSR toarray matches COO", csr_arr[1][1] == 2.0)

csc = coo.tocsc()
test("CSC shape", csc.shape == (3, 3))

# Sparse from dense
dense = [[1, 0, 0], [0, 2, 0], [0, 0, 3]]
coo_d = coo_matrix(dense)
test("COO from dense", coo_d.nnz == 3)

# dot product
result = csr.dot([1.0, 1.0, 1.0])
test("CSR dot product", approx(result, [1.0, 2.0, 3.0]))

# eye
eye = sparse.eye(3)
test("Sparse eye", eye.shape == (3, 3))

# issparse
test("issparse True", sparse.issparse(csr))
test("issparse False", not sparse.issparse([1, 2]))

# ===========================================================================
print()
print("=" * 60)
print("TESTING ion.compat.ion_math - spatial")
print("=" * 60)

from ion.compat.ion_math import _DistanceMetrics

test("euclidean", approx(_DistanceMetrics.euclidean([0, 0], [3, 4]), 5.0))
test("cosine identical", approx(_DistanceMetrics.cosine([1, 0], [1, 0]), 0.0))
test("cosine orthogonal", approx(_DistanceMetrics.cosine([1, 0], [0, 1]), 1.0))
test("manhattan", approx(_DistanceMetrics.manhattan([0, 0], [3, 4]), 7.0))
test("chebyshev", approx(_DistanceMetrics.chebyshev([0, 0], [3, 4]), 4.0))

# KDTree
tree = KDTree([[0, 0], [1, 1], [2, 2], [10, 10]])
d, i = tree.query([0.5, 0.5], k=1)
test("KDTree nearest to (0.5,0.5)", i[0] in [0, 1])

d, i = tree.query([9.9, 9.9], k=1)
test("KDTree nearest to (9.9,9.9)", i[0] == 3)

# cdist
dists = cdist([[0, 0], [1, 1]], [[2, 2], [3, 3]], metric="euclidean")
test("cdist shape", len(dists) == 2 and len(dists[0]) == 2)

# pdist
pd = pdist([[0, 0], [1, 1], [2, 2]])
test("pdist length", len(pd) == 3)

# ===========================================================================
print()
print("=" * 60)
print("TESTING ion.compat.ion_math - optimize")
print("=" * 60)

# minimize
res = minimize(lambda x: (x[0] - 3) ** 2 + (x[1] + 1) ** 2, [0.0, 0.0])
test("minimize finds x~[3,-1]", approx(res.x[0], 3.0, 0.5) and approx(res.x[1], -1.0, 0.5))

# minimize_scalar
res_s = minimize_scalar(lambda x: (x - 5) ** 2, bounds=(0, 10))
test("minimize_scalar finds x~5", approx(res_s.x, 5.0, 0.1))

# brentq
root = brentq(lambda x: x ** 2 - 4, 0, 10)
test("brentq finds sqrt(4)=2", approx(root, 2.0, 0.001))

# bisect
root_b = bisect(lambda x: x ** 3 - 8, 0, 10)
test("bisect finds cbrt(8)=2", approx(root_b, 2.0, 0.001))

# curve_fit
xdata = [0, 1, 2, 3, 4]
ydata = [0.1, 2.1, 4.0, 6.1, 7.9]
popt, _ = curve_fit(lambda x, a, b: a * x + b, xdata, ydata, p0=[1.0, 0.0])
test("curve_fit linear slope~2", approx(popt[0], 2.0, 0.5))

# ===========================================================================
print()
print("=" * 60)
print("TESTING ion.compat.ion_math - stats")
print("=" * 60)

# pearsonr
r, p = pearsonr([1, 2, 3, 4, 5], [2, 4, 6, 8, 10])
test("pearsonr perfect positive", approx(r, 1.0))

r2, p2 = pearsonr([1, 2, 3, 4, 5], [10, 8, 6, 4, 2])
test("pearsonr perfect negative", approx(r2, -1.0))

# spearmanr
rs, ps = spearmanr([1, 2, 3, 4, 5], [2, 4, 6, 8, 10])
test("spearmanr perfect", approx(rs, 1.0))

# ttest_ind
t, pval = ttest_ind([1, 2, 3], [10, 11, 12])
test("ttest_ind significant", pval < 0.05)

# zscore
z = zscore([1, 2, 3, 4, 5])
test("zscore mean~0", approx(sum(z) / len(z), 0.0))

# entropy
h = entropy([0.25, 0.25, 0.25, 0.25])
test("entropy uniform 4", approx(h, math.log(4), 0.01))

# norm distribution
from ion.compat.ion_math import _NormDist
test("norm.pdf(0) ~ 0.3989", approx(_NormDist.pdf(0), 0.3989, 0.001))
test("norm.cdf(0) = 0.5", approx(_NormDist.cdf(0), 0.5))
test("norm.ppf(0.5) ~ 0", approx(_NormDist.ppf(0.5), 0.0, 0.01))

# ===========================================================================
print()
print("=" * 60)
print("TESTING ion.compat.ion_math - linalg")
print("=" * 60)

# solve
A = [[2, 1], [5, 3]]
b = [4, 7]
x = solve(A, b)
test("solve Ax=b", approx(x[0], 5.0, 0.1) and approx(x[1], -6.0, 0.1))

# det
d = det([[1, 2], [3, 4]])
test("det 2x2", approx(d, -2.0, 0.01))

# inv
A_inv = inv([[1, 2], [3, 4]])
test("inv 2x2", approx(A_inv[0][0], -2.0, 0.1) and approx(A_inv[0][1], 1.0, 0.1))

# norm
test("vector norm", approx(norm([3, 4]), 5.0))
test("vector 1-norm", approx(norm([3, -4], ord=1), 7.0))

# cholesky
L = cholesky([[4, 2], [2, 3]])
test("cholesky L[0][0]", approx(L[0][0], 2.0))

# qr
Q, R = qr([[1, 0], [0, 1], [1, 1]])
test("QR returns matrices", len(Q) == 3 and len(R) == 2)

# ===========================================================================
print()
print("=" * 60)
print("TESTING ion.compat.ion_math - signal")
print("=" * 60)

# convolve
c = convolve([1, 2, 3], [0, 1, 0.5])
test("convolve full length", len(c) == 5)
test("convolve values", approx(c[1], 1.0, 0.1))

c_same = convolve([1, 2, 3], [0, 1, 0.5], mode="same")
test("convolve same length", len(c_same) == 3)

# correlate
cr = correlate([1, 2, 3], [1, 2, 3])
test("autocorrelation peak at center", max(cr) == cr[2])

# medfilt
m = medfilt([1, 100, 2, 3, 4], kernel_size=3)
test("medfilt removes spike", m[1] < 50)

# find_peaks
peaks, props = find_peaks([0, 1, 0, 3, 0, 2, 0])
test("find_peaks finds peaks", 1 in peaks and 3 in peaks)

# ===========================================================================
print()
print("=" * 60)
print("TESTING ion.compat.ion_math - special")
print("=" * 60)

test("gamma(5) = 24", approx(gamma_func(5), 24.0))
test("gamma(1) = 1", approx(gamma_func(1), 1.0))
test("gammaln(5) = ln(24)", approx(gammaln(5), math.log(24), 0.001))
test("erf(0) = 0", approx(erf(0), 0.0))
test("erf(inf) ~ 1", approx(erf(10), 1.0))
test("expit(0) = 0.5", approx(expit(0), 0.5))
test("expit(large) ~ 1", approx(expit(100), 1.0))
test("logit(0.5) = 0", approx(logit(0.5), 0.0))
sm = softmax([1, 2, 3])
test("softmax sums to 1", approx(sum(sm), 1.0))
test("softmax ordered", sm[0] < sm[1] < sm[2])

# ===========================================================================
print()
print("=" * 60)
print("TESTING ion.compat.ion_math - interpolate")
print("=" * 60)

f = interp1d([0, 1, 2, 3], [0, 1, 4, 9])
test("interp1d(0.5) linear", approx(f(0.5), 0.5))
test("interp1d(1.5) linear", approx(f(1.5), 2.5))
test("interp1d batch", approx(f([0.5, 1.5]), [0.5, 2.5]))

f_near = interp1d([0, 1, 2], [0, 10, 20], kind="nearest")
test("interp1d nearest(0.3)=0", approx(f_near(0.3), 0.0))
test("interp1d nearest(0.7)=10", approx(f_near(0.7), 10.0))

# ===========================================================================
print()
print("=" * 60)
print("TESTING ion.compat.ion_math - integrate")
print("=" * 60)

result, err = quad(lambda x: x ** 2, 0, 1)
test("quad x^2 from 0 to 1 = 1/3", approx(result, 1.0 / 3, 0.01))

result2, err2 = quad(math.sin, 0, math.pi)
test("quad sin from 0 to pi = 2", approx(result2, 2.0, 0.01))

t_result = trapezoid([0, 1, 4, 9], dx=1.0)
test("trapezoid", approx(t_result, 9.5, 0.5))

# ===========================================================================
print()
print("=" * 60)
print("TESTING integration: compat modules with ion tokenizer")
print("=" * 60)

# Test that phrase_discovery imports work
from ion.phrase_discovery import PhraseDiscoverer, EmbeddingPhraseScorer
test("PhraseDiscoverer imports OK", PhraseDiscoverer is not None)
test("EmbeddingPhraseScorer imports OK", EmbeddingPhraseScorer is not None)

# Test PhraseDiscoverer with compat
pd = PhraseDiscoverer(min_count=2, threshold=0.001, max_layers=2)
sents_test = [
    ["machine", "learning", "is", "great"],
    ["machine", "learning", "model", "works"],
    ["deep", "learning", "is", "powerful"],
    ["machine", "learning", "algorithms", "improve"],
    ["natural", "language", "processing", "uses", "machine", "learning"],
] * 5
phrases = pd.discover(iter(sents_test))
test("PhraseDiscoverer finds phrases", len(phrases) > 0)
test("'machine learning' found", "machine learning" in phrases)

# Test EmbeddingPhraseScorer
scorer = EmbeddingPhraseScorer(vector_size=20, min_count=2, workers=1)
scorer.train(sents_test)
test("EmbeddingPhraseScorer trains", scorer.is_trained())
score = scorer.score_phrase("machine learning", 10)
test("score_phrase returns float", isinstance(score, float) and score > 0)

# ===========================================================================
print()
print("=" * 60)
print(f"RESULTS: {passed} passed, {failed} failed out of {passed + failed}")
print("=" * 60)

sys.exit(1 if failed > 0 else 0)
