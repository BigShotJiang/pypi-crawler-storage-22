#!/usr/bin/env python3
"""
Compare ion_phrases vs gensim Phrases and ion_embeddings vs gensim Word2Vec.

Trains tokenizers with both backends and compares:
- Phrase detection overlap
- Embedding quality (similarity rankings)
- End-to-end tokenizer compression ratios
"""

import sys
import os
import time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# ============================================================================
# Test corpus
# ============================================================================
CORPUS = [
    ["the", "united", "states", "of", "america", "is", "a", "large", "country"],
    ["the", "united", "states", "has", "many", "states"],
    ["the", "united", "states", "president", "lives", "in", "washington"],
    ["the", "united", "states", "economy", "is", "strong"],
    ["the", "united", "states", "military", "is", "powerful"],
    ["new", "york", "city", "is", "in", "the", "united", "states"],
    ["new", "york", "city", "has", "many", "tall", "buildings"],
    ["new", "york", "city", "is", "a", "major", "financial", "center"],
    ["new", "york", "times", "is", "a", "famous", "newspaper"],
    ["new", "york", "stock", "exchange", "is", "on", "wall", "street"],
    ["wall", "street", "is", "in", "new", "york", "city"],
    ["wall", "street", "is", "the", "financial", "center"],
    ["machine", "learning", "is", "a", "branch", "of", "artificial", "intelligence"],
    ["machine", "learning", "algorithms", "can", "learn", "from", "data"],
    ["machine", "learning", "models", "are", "trained", "on", "data"],
    ["deep", "learning", "is", "a", "subset", "of", "machine", "learning"],
    ["deep", "learning", "uses", "neural", "networks"],
    ["artificial", "intelligence", "is", "changing", "the", "world"],
    ["artificial", "intelligence", "can", "solve", "complex", "problems"],
    ["natural", "language", "processing", "is", "part", "of", "artificial", "intelligence"],
    ["natural", "language", "processing", "helps", "computers", "understand", "text"],
    ["climate", "change", "is", "a", "global", "challenge"],
    ["climate", "change", "affects", "weather", "patterns"],
    ["climate", "change", "is", "caused", "by", "greenhouse", "gases"],
    ["the", "stock", "market", "is", "volatile"],
    ["the", "stock", "market", "crashed", "in", "recent", "years"],
    ["real", "estate", "prices", "are", "rising"],
    ["real", "estate", "is", "a", "good", "investment"],
    ["real", "estate", "market", "is", "competitive"],
    ["solar", "energy", "is", "renewable"],
    ["solar", "energy", "is", "becoming", "cheaper"],
    ["solar", "energy", "can", "power", "homes"],
] * 10  # Repeat for statistical significance

passed = 0
failed = 0

def test(name, condition):
    global passed, failed
    if condition:
        passed += 1
        print(f"  PASS: {name}")
    else:
        failed += 1
        print(f"  FAIL: {name}")


# ============================================================================
print("=" * 60)
print("TEST 1: ion_phrases vs gensim Phrases - Phrase Detection")
print("=" * 60)

# ion_phrases
from ion.compat.ion_phrases import Phrases as IonPhrases, ENGLISH_CONNECTOR_WORDS as ION_ECW

t0 = time.time()
ion_model = IonPhrases(CORPUS, min_count=5, threshold=0.001, connector_words=ION_ECW)
ion_time = time.time() - t0
ion_frozen = ion_model.freeze()
ion_phrases = set(ion_model.export_phrases().keys())
print(f"  ion_phrases: {len(ion_phrases)} phrases detected in {ion_time:.3f}s")
print(f"    Phrases: {sorted(ion_phrases)[:10]}")

# Transform a sentence
ion_result = ion_frozen[["new", "york", "city", "is", "great"]]
print(f"    Transform: {ion_result}")

# gensim
try:
    from gensim.models.phrases import Phrases as GensimPhrases, ENGLISH_CONNECTOR_WORDS as GENSIM_ECW

    t0 = time.time()
    gensim_model = GensimPhrases(CORPUS, min_count=5, threshold=0.001, connector_words=GENSIM_ECW)
    gensim_time = time.time() - t0
    gensim_frozen = gensim_model.freeze()

    # Get gensim phrases
    gensim_phrases = set()
    for sent in CORPUS:
        result = gensim_frozen[sent]
        for tok in result:
            if "_" in tok:
                gensim_phrases.add(tok)

    print(f"  gensim:      {len(gensim_phrases)} phrases detected in {gensim_time:.3f}s")
    print(f"    Phrases: {sorted(gensim_phrases)[:10]}")

    gensim_result = gensim_frozen[["new", "york", "city", "is", "great"]]
    print(f"    Transform: {gensim_result}")

    # Compare
    overlap = ion_phrases & gensim_phrases
    ion_only = ion_phrases - gensim_phrases
    gensim_only = gensim_phrases - ion_phrases

    print(f"\n  Overlap: {len(overlap)} phrases")
    print(f"  ion_phrases only: {len(ion_only)} - {sorted(ion_only)[:5]}")
    print(f"  gensim only: {len(gensim_only)} - {sorted(gensim_only)[:5]}")

    # Both should find "new_york" and "united_states"
    ion_found_ny = any("new" in p and "york" in p for p in ion_phrases)
    gensim_found_ny = any("new" in p and "york" in p for p in gensim_phrases)
    test("Both find new_york variant", ion_found_ny and gensim_found_ny)

    # Connector words should match
    test("ENGLISH_CONNECTOR_WORDS match", ION_ECW == GENSIM_ECW)

    # Both should detect some common phrases
    test("Both detect phrases", len(ion_phrases) > 0 and len(gensim_phrases) > 0)
    test("Significant overlap", len(overlap) >= min(len(ion_phrases), len(gensim_phrases)) * 0.3 or len(overlap) > 0)

    HAS_GENSIM = True

except ImportError:
    print("  gensim not available - skipping comparison (ion_phrases standalone test)")
    test("ion_phrases detects phrases without gensim", len(ion_phrases) > 0)
    test("ion_phrases finds new_york", any("new" in p and "york" in p for p in ion_phrases))
    HAS_GENSIM = False


# ============================================================================
print()
print("=" * 60)
print("TEST 2: ion_embeddings vs gensim Word2Vec - Embedding Quality")
print("=" * 60)

from ion.compat.ion_embeddings import Word2Vec as IonWord2Vec

t0 = time.time()
ion_w2v = IonWord2Vec(CORPUS, vector_size=50, window=5, min_count=3, epochs=20, seed=42)
ion_w2v_time = time.time() - t0
print(f"  ion_embeddings: trained in {ion_w2v_time:.3f}s, vocab={len(ion_w2v.wv)}")

# Check similarity rankings
if "new" in ion_w2v.wv and "york" in ion_w2v.wv:
    ion_sim_ny = ion_w2v.wv.similarity("new", "york")
    print(f"    sim(new, york) = {ion_sim_ny:.4f}")
    test("ion_embeddings produces similarities", isinstance(ion_sim_ny, float))

if "machine" in ion_w2v.wv:
    ion_top = ion_w2v.wv.most_similar(positive=["machine"], topn=5)
    print(f"    most_similar(machine) = {[(w, round(s, 3)) for w, s in ion_top]}")
    test("ion_embeddings most_similar works", len(ion_top) > 0)

if HAS_GENSIM:
    try:
        from gensim.models import Word2Vec as GensimWord2Vec

        t0 = time.time()
        gensim_w2v = GensimWord2Vec(CORPUS, vector_size=50, window=5, min_count=3, epochs=20, seed=42, workers=1)
        gensim_w2v_time = time.time() - t0
        print(f"  gensim Word2Vec: trained in {gensim_w2v_time:.3f}s, vocab={len(gensim_w2v.wv)}")

        if "new" in gensim_w2v.wv and "york" in gensim_w2v.wv:
            gensim_sim_ny = gensim_w2v.wv.similarity("new", "york")
            print(f"    sim(new, york) = {gensim_sim_ny:.4f}")

        if "machine" in gensim_w2v.wv:
            gensim_top = gensim_w2v.wv.most_similar(positive=["machine"], topn=5)
            print(f"    most_similar(machine) = {[(w, round(s, 3)) for w, s in gensim_top]}")

        # Both should have similar vocab sizes
        test("Similar vocab sizes", abs(len(ion_w2v.wv) - len(gensim_w2v.wv)) <= 5)

    except Exception as e:
        print(f"  gensim Word2Vec comparison failed: {e}")
        test("ion_embeddings works standalone", len(ion_w2v.wv) > 0)
else:
    test("ion_embeddings works standalone", len(ion_w2v.wv) > 0)
    test("ion_embeddings has vocab", len(ion_w2v.wv) >= 10)


# ============================================================================
print()
print("=" * 60)
print("TEST 3: End-to-end tokenizer build with ion compat modules")
print("=" * 60)

from ion.phrase_discovery import PhraseDiscoverer, EmbeddingPhraseScorer

# Build with ion compat (which is the fallback when gensim is unavailable)
t0 = time.time()
discoverer = PhraseDiscoverer(
    min_count=3,
    threshold=0.001,
    max_vocab_size=5000,
    connector_words=ION_ECW,
    max_layers=2,
)
phrases = discoverer.discover(iter(CORPUS))
build_time = time.time() - t0

print(f"  PhraseDiscoverer: {len(phrases)} phrases in {build_time:.3f}s")
for phrase, freq in sorted(phrases.items(), key=lambda x: -x[1])[:10]:
    print(f"    {phrase}: {freq}")

test("PhraseDiscoverer finds phrases", len(phrases) > 0)
test("Discovers multi-word phrases", any(" " in p for p in phrases))

# Test with embedding scoring
scorer = EmbeddingPhraseScorer(vector_size=30, min_count=3, workers=1)
scorer.train(CORPUS)
test("EmbeddingPhraseScorer trains successfully", scorer.is_trained())

if scorer.is_trained():
    scored = scorer.score_phrases(
        [(p, f) for p, f in phrases.items()],
        top_k=5,
    )
    print(f"\n  Top scored phrases:")
    for phrase, score, detail in scored:
        print(f"    {phrase}: score={score:.4f} (coherence={detail['coherence']}, freq={detail['frequency']}, pmi={detail['pmi']})")
    test("Scoring produces ranked results", len(scored) > 0)
    test("Scores are positive", all(s > 0 for _, s, _ in scored))

# Vocab selection
selected = discoverer.select_phrases_for_vocab(CORPUS, base_vocab_size=100, max_phrases=50)
print(f"\n  Selected {len(selected)} phrases for vocab")
test("select_phrases_for_vocab returns phrases", len(selected) > 0)


# ============================================================================
print()
print("=" * 60)
print(f"RESULTS: {passed} passed, {failed} failed out of {passed + failed}")
print("=" * 60)

sys.exit(1 if failed > 0 else 0)
