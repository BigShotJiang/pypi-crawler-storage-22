#!/usr/bin/env python3
"""
Export-format training verification: build individually-crafted tokenizers,
export to all 9 formats, then train a ~1M-parameter model for a few steps
to confirm each tokenizer output is functional end-to-end.

Formats tested:
  1. Native Ion JSON (tokenizer.json)
  2. HuggingFace (tokenizer.json + config)
  3. SentencePiece (vocab.txt with scores)
  4. Plain vocab.txt (id + token)
  5. ONNX (vocab.txt + config.json)
  6. tiktoken (base64 BPE ranks)
  7. JSONL (JSON Lines with metadata)
  8. CSV (spreadsheet-friendly)
  9. Integration ONNX (via ion.integrations.export_for_onnx)
"""

import json
import math
import os
import sys
import tempfile
from pathlib import Path

import pytest
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

sys.path.insert(0, str(Path(__file__).parent.parent))

from ion.tokenizer import IonTokenizer
from ion.builder import build_tokenizer
from ion.tools import (
    export_huggingface, export_sentencepiece, export_vocab_txt,
    export_onnx, export_tiktoken, export_jsonl, export_csv,
)
from ion.integrations import (
    IonTokenizerHF, IonDataset, IonLanguageModelDataset,
    ion_collate_fn, export_for_onnx, export_for_sentencepiece,
)

# ---------------------------------------------------------------------------
# Corpus variants — each tailored to a different "domain" so that the
# tokenizers built from them have meaningfully different vocabularies.
# ---------------------------------------------------------------------------

CORPORA = {
    "prose": [
        "The old lighthouse keeper watched the storm approach from the west.",
        "Every morning the fishermen set out before dawn to catch herring.",
        "Waves crashed against the rocky shore sending spray into the air.",
        "The small coastal village depended on the sea for its livelihood.",
        "Fog rolled in from the ocean blanketing the harbor in grey mist.",
        "Seagulls circled overhead crying out as the boats returned to port.",
        "The tide charts hung on the wall of every house in the village.",
        "Salt air corroded the metal fixtures on the old wooden pier.",
        "Children collected shells along the beach after the storm passed.",
        "The lighthouse beam swept across the dark waters every eight seconds.",
    ] * 25,
    "technical": [
        "The convolutional neural network achieved 95% accuracy on the test set.",
        "Gradient descent optimizes the loss function by updating model weights.",
        "Batch normalization stabilizes training by normalizing layer inputs.",
        "The transformer architecture uses multi-head self-attention mechanisms.",
        "Dropout regularization prevents overfitting by randomly zeroing activations.",
        "Learning rate scheduling reduces the step size as training progresses.",
        "Residual connections allow gradients to flow through very deep networks.",
        "The embedding layer maps discrete tokens to continuous vector representations.",
        "Cross-entropy loss measures the divergence between predicted and true distributions.",
        "Adam optimizer combines momentum and adaptive learning rate for faster convergence.",
    ] * 25,
    "dialogue": [
        "Hey have you seen the new update to the project repository yet?",
        "Yeah I pushed a fix for the memory leak last night around midnight.",
        "Nice that bug has been driving me crazy for the past two weeks.",
        "I also refactored the database connection pool to use async await.",
        "Oh that explains why the integration tests were failing this morning.",
        "We should probably add more unit tests before the release next week.",
        "Agreed I will write tests for the authentication module tomorrow.",
        "Can you review my pull request when you get a chance today?",
        "Sure I will look at it right after the standup meeting at ten.",
        "Thanks also we need to update the deployment configuration for staging.",
    ] * 25,
    "code_mixed": [
        "The function parse_config reads YAML files and returns a dictionary.",
        "Use try except blocks to handle FileNotFoundError gracefully in Python.",
        "The class DataProcessor inherits from BaseProcessor and overrides transform.",
        "List comprehensions like [x*2 for x in range(10)] are Pythonic patterns.",
        "Decorators such as @staticmethod modify function behavior without subclassing.",
        "The asyncio event loop manages concurrent IO operations efficiently.",
        "Type hints like def foo(x: int) -> str improve code readability.",
        "Context managers with the with statement ensure proper resource cleanup.",
        "Generator expressions use lazy evaluation to handle large datasets in memory.",
        "The dataclass decorator automatically generates init repr and eq methods.",
    ] * 25,
    "scientific": [
        "The mitochondrial membrane potential drives ATP synthesis via chemiosmosis.",
        "Polymerase chain reaction amplifies specific DNA sequences exponentially.",
        "CRISPR Cas9 enables precise genome editing at targeted loci in organisms.",
        "Protein folding is governed by thermodynamic stability and kinetic pathways.",
        "Spectroscopic analysis revealed absorption peaks at 260 and 280 nanometers.",
        "The enzyme catalyzes the hydrolysis of peptide bonds at physiological pH.",
        "Fluorescence microscopy allows visualization of subcellular structures in vivo.",
        "The statistical analysis yielded a p-value below the significance threshold.",
        "Gel electrophoresis separates DNA fragments by size through agarose matrix.",
        "The phylogenetic tree was constructed using maximum likelihood estimation.",
    ] * 25,
    "legal": [
        "The plaintiff alleges breach of contract under Section 2 of the agreement.",
        "Pursuant to the terms herein the parties agree to binding arbitration.",
        "The defendant shall indemnify and hold harmless the injured party.",
        "Force majeure provisions apply when performance is prevented by acts of God.",
        "The intellectual property rights shall remain with the original creator.",
        "Non-disclosure agreements protect confidential information shared between parties.",
        "The statute of limitations for civil claims is three years from discovery.",
        "Liquidated damages clauses specify predetermined compensation for breach.",
        "The court of appeals reversed the lower court decision on procedural grounds.",
        "Warranty disclaimers must be conspicuous to be enforceable under the UCC.",
    ] * 25,
    "multilingual": [
        "The cafe served croissants and espresso alongside traditional English breakfast.",
        "Kindergarten comes from the German word meaning garden for children.",
        "The entrepreneur launched a boutique selling haute couture fashion designs.",
        "Tsunami warning systems detect seismic activity along the Pacific Rim.",
        "The maestro conducted the symphony orchestra through a rendition of Beethoven.",
        "Karate and judo are martial arts that originated in Japan centuries ago.",
        "The pizza margherita was named after Queen Margherita of Savoy in Italy.",
        "Yoga and meditation practices have roots in ancient Sanskrit traditions.",
        "The safari guide led the group through the savanna to see wildlife.",
        "Ballet dancers perform pirouettes and arabesques with precision and grace.",
    ] * 25,
    "json_heavy": [
        'The API returns {"status": "ok", "count": 42} for successful requests.',
        'Config files use {"debug": true, "port": 8080} to set server options.',
        'The response payload contains {"users": [{"id": 1, "name": "Alice"}]}.',
        'Error messages follow {"error": "not_found", "code": 404} format.',
        'Metadata includes {"version": "2.0", "format": "json"} in the header.',
        "REST endpoints accept JSON bodies with content type application json.",
        "The schema validator checks that all required fields are present.",
        "Nested objects represent hierarchical data structures in the response.",
        "Array fields contain lists of related items for batch processing.",
        "The serializer converts Python objects to JSON strings for transmission.",
    ] * 25,
    "adversarial": [
        "Testing edge cases: café résumé naïve über straße Ωmega Δelta.",
        "Numbers like 3.14159 and 2.71828 appear in mathematical formulas.",
        "Special chars: @user #hashtag $100 50% a&b c|d e^f aren't unusual.",
        "Contractions like don't won't can't shouldn't wouldn't mustn't exist.",
        "ALL CAPS TEXT sometimes appears in HEADLINES and WARNING MESSAGES.",
        "CamelCase and snake_case naming conventions coexist in programming.",
        "Repeated words words words sometimes occur in messy text data.",
        "Short. Sentences. Like. These. Test. Boundary. Conditions. Well.",
        "Hyphenated-compounds and semi-structured data test the tokenizer.",
        "Ellipsis... dashes -- and em-dashes are common in written English.",
    ] * 25,
}

# ---------------------------------------------------------------------------
# ~1M parameter model
# ---------------------------------------------------------------------------

class SmallLM(nn.Module):
    """
    ~1M parameter causal language model.
    With d_model=128, n_heads=4, n_layers=4, ff=512 and vocab ~500:
      embed: 500*128 = 64K
      per layer: 4*(128*128)=65K (attn) + 2*(128*512)=131K (ff) ≈ 200K
      4 layers ≈ 800K
      output proj: 64K
      Total ≈ 928K ≈ ~1M params
    """

    def __init__(self, vocab_size: int, d_model=128, n_heads=4, n_layers=4, d_ff=512):
        super().__init__()
        self.d_model = d_model
        self.embed = nn.Embedding(vocab_size, d_model)
        self.pos_embed = nn.Embedding(512, d_model)

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=n_heads, dim_feedforward=d_ff,
            batch_first=True, dropout=0.0,
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=n_layers)
        self.head = nn.Linear(d_model, vocab_size)

        self._param_count = sum(p.numel() for p in self.parameters())

    @property
    def param_count(self):
        return self._param_count

    def forward(self, input_ids, labels=None):
        B, T = input_ids.shape
        pos = torch.arange(T, device=input_ids.device).unsqueeze(0)
        x = self.embed(input_ids) * math.sqrt(self.d_model) + self.pos_embed(pos)

        # Causal mask
        mask = nn.Transformer.generate_square_subsequent_mask(T, device=input_ids.device)
        x = self.transformer(x, mask=mask, is_causal=True)
        logits = self.head(x)

        loss = None
        if labels is not None:
            loss = nn.functional.cross_entropy(
                logits.view(-1, logits.size(-1)), labels.view(-1), ignore_index=0,
            )
        return {"loss": loss, "logits": logits}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_corpus(texts):
    fd, path = tempfile.mkstemp(suffix=".txt")
    with os.fdopen(fd, "w") as f:
        f.write("\n".join(texts))
    return path


def _build_tok(corpus_name: str, **kwargs):
    """Build a tokenizer from one of the named corpora."""
    texts = CORPORA[corpus_name]
    path = _make_corpus(texts)
    fd, out = tempfile.mkstemp(suffix=".json")
    os.close(fd)
    defaults = dict(
        max_vocab_size=500,
        fallback_mode="character",
        license_config={"plan": "free", "email": "test@test.com",
                        "agreed_to_license": True},
    )
    defaults.update(kwargs)
    stats = build_tokenizer(source=path, output=out, **defaults)
    import orjson
    data = orjson.loads(Path(out).read_bytes())
    tok = IonTokenizer.from_dict(data)
    os.unlink(path)
    return tok, stats, out


def _train_model(tok, texts, steps=5, block_size=32, batch_size=4):
    """
    Train a ~1M param model for a few steps using the given tokenizer.
    Returns (model, final_loss).
    """
    vocab_size = len(tok.vocab)
    model = SmallLM(vocab_size)
    assert model.param_count > 500_000, f"Model too small: {model.param_count}"

    ds = IonLanguageModelDataset(texts, tok, block_size=block_size)
    if len(ds) == 0:
        pytest.skip("Dataset empty after tokenization")
    loader = DataLoader(ds, batch_size=batch_size, collate_fn=ion_collate_fn(0))
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3)

    model.train()
    losses = []
    step = 0
    for batch in loader:
        out = model(batch["input_ids"], labels=batch["labels"])
        if out["loss"] is None:
            continue
        out["loss"].backward()
        optimizer.step()
        optimizer.zero_grad()
        losses.append(out["loss"].item())
        step += 1
        if step >= steps:
            break

    assert len(losses) > 0, "No training steps completed"
    return model, losses[-1]


# ===========================================================================
# Test class: one method per export format, each with its own tokenizer
# ===========================================================================

class TestExportFormatTraining:
    """
    For each of the 9 output formats:
      1. Build a tokenizer from a unique corpus
      2. Export to that format
      3. Verify the export files exist and are valid
      4. Train a ~1M-param model for a few steps
      5. Confirm loss is finite and decreasing
    """

    def test_01_native_ion_json(self, tmp_path):
        """Format 1: Native Ion tokenizer.json — the canonical format."""
        tok, stats, tok_path = _build_tok("prose")
        try:
            assert stats["vocab_size"] > 0
            # Verify round-trip
            data = tok.to_dict()
            tok2 = IonTokenizer.from_dict(data)
            assert tok.encode("the lighthouse") == tok2.encode("the lighthouse")

            model, loss = _train_model(tok, CORPORA["prose"])
            assert math.isfinite(loss), f"Loss not finite: {loss}"
        finally:
            os.unlink(tok_path)

    def test_02_huggingface_export(self, tmp_path):
        """Format 2: HuggingFace transformers directory."""
        tok, stats, tok_path = _build_tok("technical")
        out_dir = str(tmp_path / "hf")
        try:
            export_huggingface(tok_path, out_dir)

            assert (Path(out_dir) / "tokenizer.json").exists()
            assert (Path(out_dir) / "tokenizer_config.json").exists()
            assert (Path(out_dir) / "special_tokens_map.json").exists()

            # Verify tokenizer_config has expected fields
            cfg = json.loads((Path(out_dir) / "tokenizer_config.json").read_text())
            assert "model_type" in cfg or "tokenizer_class" in cfg or len(cfg) > 0

            model, loss = _train_model(tok, CORPORA["technical"])
            assert math.isfinite(loss)
        finally:
            os.unlink(tok_path)

    def test_03_sentencepiece_export(self, tmp_path):
        """Format 3: SentencePiece vocab (token + score per line)."""
        tok, stats, tok_path = _build_tok("dialogue")
        out = str(tmp_path / "sp_vocab.txt")
        try:
            export_sentencepiece(tok_path, out)
            assert Path(out).exists()

            lines = Path(out).read_text().strip().split("\n")
            assert len(lines) == len(tok.vocab)
            # Each line should have token\tscore
            for line in lines[:10]:
                parts = line.split("\t")
                assert len(parts) == 2, f"Bad SentencePiece line: {line}"

            model, loss = _train_model(tok, CORPORA["dialogue"])
            assert math.isfinite(loss)
        finally:
            os.unlink(tok_path)

    def test_04_vocab_txt_export(self, tmp_path):
        """Format 4: Plain vocab.txt (id + token)."""
        tok, stats, tok_path = _build_tok("code_mixed")
        out = str(tmp_path / "vocab.txt")
        try:
            export_vocab_txt(tok_path, out)
            assert Path(out).exists()

            lines = Path(out).read_text().strip().split("\n")
            assert len(lines) > 0
            # Verify it can be parsed back
            vocab_from_file = {}
            for line in lines:
                parts = line.split("\t")
                if len(parts) >= 2:
                    vocab_from_file[parts[1]] = int(parts[0])
            assert len(vocab_from_file) > 10

            model, loss = _train_model(tok, CORPORA["code_mixed"])
            assert math.isfinite(loss)
        finally:
            os.unlink(tok_path)

    def test_05_onnx_export(self, tmp_path):
        """Format 5: ONNX directory (vocab.txt + config.json)."""
        tok, stats, tok_path = _build_tok("scientific")
        out_dir = str(tmp_path / "onnx")
        try:
            export_onnx(tok_path, out_dir)

            assert (Path(out_dir) / "vocab.txt").exists()
            assert (Path(out_dir) / "config.json").exists()

            # Verify config
            cfg = json.loads((Path(out_dir) / "config.json").read_text())
            assert "vocab_size" in cfg or "model_type" in cfg or len(cfg) > 0

            model, loss = _train_model(tok, CORPORA["scientific"])
            assert math.isfinite(loss)
        finally:
            os.unlink(tok_path)

    def test_06_tiktoken_export(self, tmp_path):
        """Format 6: tiktoken base64-encoded BPE ranks."""
        tok, stats, tok_path = _build_tok("legal")
        out = str(tmp_path / "tiktoken.bpe")
        try:
            export_tiktoken(tok_path, out)
            assert Path(out).exists()

            content = Path(out).read_text().strip()
            assert len(content) > 0
            # Each line should be: base64_token rank
            lines = content.split("\n")
            for line in lines[:10]:
                parts = line.split(" ")
                assert len(parts) == 2, f"Bad tiktoken line: {line}"
                # Second part should be an integer rank
                int(parts[1])

            model, loss = _train_model(tok, CORPORA["legal"])
            assert math.isfinite(loss)
        finally:
            os.unlink(tok_path)

    def test_07_jsonl_export(self, tmp_path):
        """Format 7: JSON Lines with full metadata."""
        tok, stats, tok_path = _build_tok("multilingual")
        out = str(tmp_path / "vocab.jsonl")
        try:
            export_jsonl(tok_path, out)
            assert Path(out).exists()

            lines = Path(out).read_text().strip().split("\n")
            assert len(lines) == len(tok.vocab)
            # Validate each line is valid JSON with expected fields
            for line in lines[:20]:
                obj = json.loads(line)
                assert "id" in obj
                assert "token" in obj
                assert "type" in obj

            model, loss = _train_model(tok, CORPORA["multilingual"])
            assert math.isfinite(loss)
        finally:
            os.unlink(tok_path)

    def test_08_csv_export(self, tmp_path):
        """Format 8: CSV with headers."""
        tok, stats, tok_path = _build_tok("json_heavy", keep_json=True)
        out = str(tmp_path / "vocab.csv")
        try:
            export_csv(tok_path, out)
            assert Path(out).exists()

            lines = Path(out).read_text().strip().split("\n")
            assert len(lines) >= 2  # header + at least one row
            header = lines[0].lower()
            assert "id" in header or "token" in header

            model, loss = _train_model(tok, CORPORA["json_heavy"])
            assert math.isfinite(loss)
        finally:
            os.unlink(tok_path)

    def test_09_integration_onnx_export(self, tmp_path):
        """Format 9: Integration-level ONNX export (via ion.integrations)."""
        tok, stats, tok_path = _build_tok("adversarial")
        out_dir = str(tmp_path / "int_onnx")
        try:
            export_for_onnx(tok, out_dir)
            assert (Path(out_dir) / "vocab.txt").exists()
            assert (Path(out_dir) / "config.json").exists()

            model, loss = _train_model(tok, CORPORA["adversarial"])
            assert math.isfinite(loss)
        finally:
            os.unlink(tok_path)


# ===========================================================================
# Verify the model is actually ~1M params
# ===========================================================================

class TestModelSize:
    """Sanity-check that SmallLM is in the 1M parameter range."""

    def test_param_count(self):
        model = SmallLM(vocab_size=500)
        count = model.param_count
        assert 500_000 < count < 2_000_000, (
            f"Expected ~1M params, got {count:,}"
        )

    def test_loss_decreases(self):
        """Confirm the model can actually learn (loss goes down)."""
        tok, _, tok_path = _build_tok("prose")
        try:
            vocab_size = len(tok.vocab)
            model = SmallLM(vocab_size)
            ds = IonLanguageModelDataset(CORPORA["prose"], tok, block_size=32)
            loader = DataLoader(ds, batch_size=8, collate_fn=ion_collate_fn(0))
            optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3)

            model.train()
            losses = []
            for i, batch in enumerate(loader):
                out = model(batch["input_ids"], labels=batch["labels"])
                if out["loss"] is None:
                    continue
                out["loss"].backward()
                optimizer.step()
                optimizer.zero_grad()
                losses.append(out["loss"].item())
                if i >= 15:
                    break

            assert len(losses) >= 8
            # Average of last 3 should be less than average of first 3
            first_avg = sum(losses[:3]) / 3
            last_avg = sum(losses[-3:]) / 3
            assert last_avg < first_avg, (
                f"Loss did not decrease: first={first_avg:.4f} last={last_avg:.4f}"
            )
        finally:
            os.unlink(tok_path)


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
