"""
End-to-end integration tests: build a small Ion tokenizer, then train
a tiny model for 3 steps using every integration path to verify they work.
"""

import os
import sys
import json
import tempfile
import shutil
from pathlib import Path

import pytest
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

# Add project root
sys.path.insert(0, str(Path(__file__).parent.parent))

from ion.tokenizer import IonTokenizer
from ion.integrations import (
    IonTokenizerHF,
    IonDataset,
    IonLanguageModelDataset,
    IonDataModule,
    BatchEncoding,
    ion_collate_fn,
    prepare_model_inputs,
    export_for_onnx,
    export_for_sentencepiece,
)
from ion.tools import (
    export_huggingface,
    export_sentencepiece,
    export_onnx,
    export_tiktoken,
    export_jsonl,
    export_csv,
    export_vocab_txt,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

SAMPLE_TEXTS = [
    "The quick brown fox jumps over the lazy dog.",
    "Machine learning models need good tokenizers.",
    "Ion is a phrase-first semantic tokenizer compiler.",
    "Neural language models benefit from better tokenization.",
    "The cat sat on the mat and looked at the bat.",
    "Deep learning has revolutionized natural language processing.",
    "Tokenization is the first step in any NLP pipeline.",
    "Good compression means fewer tokens for the same text.",
    "Phrases capture multi-word semantic units efficiently.",
    "The quick brown fox jumps over the lazy dog again.",
    "Semantic tokenizers discover meaningful chunks of text.",
    "Training a language model requires a well-built vocabulary.",
    "The weather today is sunny and warm with clear skies.",
    "Python is a popular programming language for data science.",
    "Artificial intelligence continues to advance rapidly.",
    "The brown fox and the lazy dog are friends.",
    "Natural language understanding requires good representations.",
    "Transformers changed the landscape of machine learning.",
    "Attention mechanisms allow models to focus on relevant parts.",
    "Vocabulary size affects both compression and model quality.",
] * 5  # repeat for more data


@pytest.fixture(scope="module")
def tmp_dir():
    d = tempfile.mkdtemp(prefix="ion_test_")
    yield d
    shutil.rmtree(d, ignore_errors=True)


@pytest.fixture(scope="module")
def ion_tokenizer(tmp_dir):
    """Build a small Ion tokenizer from sample texts."""
    from ion.builder import TokenizerBuilder
    from collections import Counter

    sentences = [text.lower().split() for text in SAMPLE_TEXTS]

    builder = TokenizerBuilder(
        max_vocab_size=500,
        min_word_freq=1,
        min_phrase_freq=2,
        max_sentences=len(sentences),
    )
    builder.sentences = sentences
    builder.word_freq = Counter(tok for sent in sentences for tok in sent)
    builder.stats["total_sentences"] = len(sentences)
    builder.stats["total_tokens_original"] = sum(len(s) for s in sentences)

    builder.discover_phrases()
    tok = builder.build_tokenizer()

    # Save to disk
    tok_path = Path(tmp_dir) / "tokenizer.json"
    import orjson
    tok_path.write_bytes(orjson.dumps(tok.to_dict(), option=orjson.OPT_INDENT_2))

    return tok, str(tok_path)


@pytest.fixture(scope="module")
def hf_tokenizer(ion_tokenizer):
    tok, _ = ion_tokenizer
    return IonTokenizerHF(tok)


# ---------------------------------------------------------------------------
# Tiny model for testing
# ---------------------------------------------------------------------------

class TinyLM(nn.Module):
    """Minimal language model for testing."""
    def __init__(self, vocab_size, embed_dim=32, hidden_dim=64):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, embed_dim, padding_idx=0)
        self.linear = nn.Linear(embed_dim, hidden_dim)
        self.head = nn.Linear(hidden_dim, vocab_size)
        self.loss_fn = nn.CrossEntropyLoss(ignore_index=-100)

    def forward(self, input_ids, attention_mask=None, labels=None):
        x = self.embed(input_ids)
        x = torch.relu(self.linear(x))
        logits = self.head(x)
        loss = None
        if labels is not None:
            loss = self.loss_fn(logits.view(-1, logits.size(-1)), labels.view(-1))
        return {"loss": loss, "logits": logits}


class TinyClassifier(nn.Module):
    """Minimal classifier for testing."""
    def __init__(self, vocab_size, num_labels=2, embed_dim=32):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, embed_dim, padding_idx=0)
        self.head = nn.Linear(embed_dim, num_labels)
        self.loss_fn = nn.CrossEntropyLoss()

    def forward(self, input_ids, attention_mask=None, labels=None):
        x = self.embed(input_ids)
        # mean pool
        if attention_mask is not None:
            mask = attention_mask.unsqueeze(-1).float()
            x = (x * mask).sum(1) / mask.sum(1).clamp(min=1)
        else:
            x = x.mean(1)
        logits = self.head(x)
        loss = None
        if labels is not None:
            loss = self.loss_fn(logits, labels)
        return {"loss": loss, "logits": logits}


# ---------------------------------------------------------------------------
# Test 1: IonTokenizerHF basic encoding
# ---------------------------------------------------------------------------

def test_hf_tokenizer_encode_decode(hf_tokenizer):
    """Test basic encode/decode round-trip."""
    text = "the quick brown fox"
    ids = hf_tokenizer.encode(text)
    assert len(ids) > 0
    decoded = hf_tokenizer.decode(ids)
    assert isinstance(decoded, str)
    assert len(decoded) > 0


def test_hf_tokenizer_call_single(hf_tokenizer):
    """Test __call__ with single string."""
    result = hf_tokenizer("the quick brown fox", padding=True, return_attention_mask=True)
    assert "input_ids" in result.keys()


def test_hf_tokenizer_call_batch(hf_tokenizer):
    """Test __call__ with batch of strings."""
    result = hf_tokenizer(
        ["the quick brown fox", "the lazy dog"],
        padding=True,
        truncation=True,
        max_length=32,
        return_tensors="pt",
    )
    assert "input_ids" in result
    assert result["input_ids"].shape[0] == 2


def test_hf_tokenizer_save_load(hf_tokenizer, tmp_dir):
    """Test save_pretrained / from_pretrained."""
    save_dir = Path(tmp_dir) / "hf_save"
    hf_tokenizer.save_pretrained(str(save_dir))

    loaded = IonTokenizerHF.from_pretrained(str(save_dir))
    assert loaded.vocab_size == hf_tokenizer.vocab_size

    # Verify encoding matches
    text = "test encoding"
    orig_ids = hf_tokenizer.encode(text)
    loaded_ids = loaded.encode(text)
    assert orig_ids == loaded_ids


# ---------------------------------------------------------------------------
# Test 2: IonDataset + DataLoader + 3 training steps (classification)
# ---------------------------------------------------------------------------

def test_ion_dataset_training(hf_tokenizer):
    """Train a tiny classifier for 3 steps using IonDataset."""
    texts = SAMPLE_TEXTS[:20]
    labels = [i % 2 for i in range(len(texts))]

    dataset = IonDataset(texts, hf_tokenizer, max_length=64, labels=labels)
    assert len(dataset) == 20

    loader = DataLoader(
        dataset,
        batch_size=4,
        collate_fn=ion_collate_fn(hf_tokenizer.pad_token_id),
    )

    model = TinyClassifier(hf_tokenizer.vocab_size)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

    model.train()
    steps = 0
    for batch in loader:
        out = model(**batch)
        assert out["loss"] is not None
        out["loss"].backward()
        optimizer.step()
        optimizer.zero_grad()
        steps += 1
        if steps >= 3:
            break

    assert steps == 3, f"Expected 3 training steps, got {steps}"


# ---------------------------------------------------------------------------
# Test 3: IonLanguageModelDataset + 3 training steps (causal LM)
# ---------------------------------------------------------------------------

def test_language_model_dataset_training(hf_tokenizer):
    """Train a tiny LM for 3 steps using IonLanguageModelDataset."""
    dataset = IonLanguageModelDataset(
        texts=SAMPLE_TEXTS,
        tokenizer=hf_tokenizer,
        block_size=32,
    )
    assert len(dataset) > 0

    loader = DataLoader(
        dataset,
        batch_size=4,
        collate_fn=ion_collate_fn(hf_tokenizer.pad_token_id),
    )

    model = TinyLM(hf_tokenizer.vocab_size)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

    model.train()
    steps = 0
    for batch in loader:
        out = model(**batch)
        assert out["loss"] is not None
        out["loss"].backward()
        optimizer.step()
        optimizer.zero_grad()
        steps += 1
        if steps >= 3:
            break

    assert steps == 3, f"Expected 3 training steps, got {steps}"


# ---------------------------------------------------------------------------
# Test 4: IonDataModule + 3 training steps
# ---------------------------------------------------------------------------

def test_data_module_training(hf_tokenizer):
    """Train using IonDataModule for 3 steps."""
    train_texts = SAMPLE_TEXTS[:16]
    val_texts = SAMPLE_TEXTS[16:20]
    train_labels = [i % 2 for i in range(len(train_texts))]
    val_labels = [i % 2 for i in range(len(val_texts))]

    dm = IonDataModule(
        train_texts=train_texts,
        val_texts=val_texts,
        tokenizer=hf_tokenizer,
        train_labels=train_labels,
        val_labels=val_labels,
        batch_size=4,
        max_length=64,
    )
    dm.setup("fit")

    train_loader = dm.train_dataloader()
    val_loader = dm.val_dataloader()
    assert val_loader is not None

    model = TinyClassifier(hf_tokenizer.vocab_size)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

    model.train()
    steps = 0
    for batch in train_loader:
        out = model(**batch)
        out["loss"].backward()
        optimizer.step()
        optimizer.zero_grad()
        steps += 1
        if steps >= 3:
            break

    assert steps == 3


# ---------------------------------------------------------------------------
# Test 5: prepare_model_inputs
# ---------------------------------------------------------------------------

def test_prepare_model_inputs(hf_tokenizer):
    """Test prepare_model_inputs utility."""
    inputs = prepare_model_inputs(
        ["hello world", "test text"],
        hf_tokenizer,
        max_length=32,
        device="cpu",
    )
    assert "input_ids" in inputs
    assert inputs["input_ids"].shape[0] == 2

    model = TinyClassifier(hf_tokenizer.vocab_size)
    out = model(**inputs)
    assert out["logits"] is not None


# ---------------------------------------------------------------------------
# Test 6: All export formats
# ---------------------------------------------------------------------------

def test_export_huggingface(ion_tokenizer, tmp_dir):
    """Test HuggingFace export."""
    _, tok_path = ion_tokenizer
    out_dir = str(Path(tmp_dir) / "export_hf")
    result = export_huggingface(tok_path, out_dir)
    assert Path(result, "tokenizer.json").exists()
    assert Path(result, "tokenizer_config.json").exists()
    assert Path(result, "special_tokens_map.json").exists()


def test_export_sentencepiece(ion_tokenizer, tmp_dir):
    """Test SentencePiece export."""
    _, tok_path = ion_tokenizer
    out_path = str(Path(tmp_dir) / "export_sp.vocab")
    result = export_sentencepiece(tok_path, out_path)
    assert Path(result).exists()
    content = Path(result).read_text()
    assert "\t" in content  # tab-separated


def test_export_onnx(ion_tokenizer, tmp_dir):
    """Test ONNX export."""
    _, tok_path = ion_tokenizer
    out_dir = str(Path(tmp_dir) / "export_onnx")
    result = export_onnx(tok_path, out_dir)
    assert Path(result, "vocab.txt").exists()
    assert Path(result, "config.json").exists()


def test_export_tiktoken(ion_tokenizer, tmp_dir):
    """Test tiktoken export."""
    _, tok_path = ion_tokenizer
    out_path = str(Path(tmp_dir) / "export.tiktoken")
    result = export_tiktoken(tok_path, out_path)
    assert Path(result).exists()
    # Verify format: base64 space rank
    lines = Path(result).read_text().strip().split("\n")
    assert len(lines) > 0
    parts = lines[0].split(" ")
    assert len(parts) == 2


def test_export_jsonl(ion_tokenizer, tmp_dir):
    """Test JSONL export."""
    _, tok_path = ion_tokenizer
    out_path = str(Path(tmp_dir) / "export.jsonl")
    result = export_jsonl(tok_path, out_path)
    assert Path(result).exists()
    lines = Path(result).read_text().strip().split("\n")
    first = json.loads(lines[0])
    assert "id" in first
    assert "token" in first
    assert "type" in first


def test_export_csv(ion_tokenizer, tmp_dir):
    """Test CSV export."""
    _, tok_path = ion_tokenizer
    out_path = str(Path(tmp_dir) / "export.csv")
    result = export_csv(tok_path, out_path)
    assert Path(result).exists()
    lines = Path(result).read_text().strip().split("\n")
    assert lines[0].startswith("id,token,type")


def test_export_vocab_txt(ion_tokenizer, tmp_dir):
    """Test vocab.txt export."""
    _, tok_path = ion_tokenizer
    out_path = str(Path(tmp_dir) / "vocab.txt")
    result = export_vocab_txt(tok_path, out_path)
    assert Path(result).exists()


def test_export_for_onnx_integration(ion_tokenizer, tmp_dir):
    """Test integrations.export_for_onnx."""
    tok, _ = ion_tokenizer
    out_dir = Path(tmp_dir) / "integration_onnx"
    export_for_onnx(tok, out_dir)
    assert (out_dir / "vocab.txt").exists()
    assert (out_dir / "config.json").exists()


def test_export_for_sentencepiece_integration(ion_tokenizer, tmp_dir):
    """Test integrations.export_for_sentencepiece."""
    tok, _ = ion_tokenizer
    out_path = Path(tmp_dir) / "integration_sp.vocab"
    export_for_sentencepiece(tok, str(out_path))
    assert out_path.exists()


# ---------------------------------------------------------------------------
# Test 7: BatchEncoding .to() and .to_dict()
# ---------------------------------------------------------------------------

def test_batch_encoding_to_device(hf_tokenizer):
    """Test BatchEncoding.to() conversion."""
    result = hf_tokenizer(
        ["hello world"],
        padding=True,
        return_attention_mask=True,
    )
    tensor_dict = result.to("cpu")
    assert "input_ids" in tensor_dict
    assert isinstance(tensor_dict["input_ids"], torch.Tensor)


def test_batch_encoding_to_dict(hf_tokenizer):
    """Test BatchEncoding.to_dict()."""
    result = hf_tokenizer(
        ["hello world"],
        padding=True,
        return_attention_mask=True,
    )
    d = result.to_dict()
    assert "input_ids" in d


# ---------------------------------------------------------------------------
# Test 8: convert_tokens_to_ids / convert_ids_to_tokens
# ---------------------------------------------------------------------------

def test_token_id_conversion(hf_tokenizer):
    """Test token<->id conversion methods."""
    token_id = hf_tokenizer.convert_tokens_to_ids("<pad>")
    assert token_id == hf_tokenizer.pad_token_id

    token = hf_tokenizer.convert_ids_to_tokens(hf_tokenizer.pad_token_id)
    assert token == "<pad>"

    # Batch
    ids = hf_tokenizer.convert_tokens_to_ids(["<pad>", "<unk>"])
    assert len(ids) == 2


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
