"""Cell measurement client for managing time series test data.

This module provides the :class:`CellMeasurementClient` for uploading,
retrieving, and managing measurement data from battery cell testing. It
supports efficient upload of large datasets using signed URLs and parquet
format.
"""

from __future__ import annotations

import io
from typing import Any

import pandas as pd
import polars as pl
from pydantic import ValidationError
import requests

from .errors import IonworksError
from .models import (
    CellInstanceMeasurementsWithSteps,
    CellMeasurement,
    CellMeasurementBundleResponse,
    CellMeasurementDetail,
    ConfirmUploadResponse,
    InitiateUploadResponse,
)
from .validators import DataFrame, df_to_dict_validator, validate_measurement_data


def _to_polars(df: DataFrame | dict) -> pl.DataFrame:
    """Convert pandas DataFrame or dict to polars DataFrame.

    Parameters
    ----------
    df : DataFrame | dict
        Input data as pandas DataFrame, polars DataFrame, or dict.

    Returns
    -------
    pl.DataFrame
        Polars DataFrame.
    """
    if isinstance(df, pl.DataFrame):
        return df
    if isinstance(df, pd.DataFrame):
        return pl.from_pandas(df)
    if isinstance(df, dict):
        return pl.DataFrame(df)
    raise TypeError(f"Expected DataFrame or dict, got {type(df).__name__}")


class CellMeasurementClient:
    """Client for managing cell measurement data."""

    #: Default timeout for signed URL uploads as (connect, read) in seconds.
    UPLOAD_TIMEOUT: tuple[float, float] = (10, 300)

    def __init__(self, client: Any) -> None:
        """Initialize the CellMeasurementClient.

        Parameters
        ----------
        client : Any
            The HTTP client instance for making API calls.
        """
        self.client = client

    def list(self, cell_instance_id: str) -> list[CellMeasurement]:
        """List all cell measurements for a cell instance by instance ID."""
        endpoint = f"/cell_instances/{cell_instance_id}/cell_measurements"
        response_data = self.client.get(endpoint)
        return [CellMeasurement(**item) for item in response_data]

    def get(self, measurement_id: str) -> CellMeasurement:
        """Get a specific cell measurement by its ID only."""
        endpoint = f"/cell_measurements/{measurement_id}"
        response_data = self.client.get(endpoint)
        return CellMeasurement(**response_data)

    def detail(self, measurement_id: str) -> CellMeasurementDetail:
        """Get the full details for a cell measurement by measurement ID only."""
        endpoint = f"/cell_measurements/{measurement_id}/detail"
        response_data = self.client.get(endpoint)
        return CellMeasurementDetail(**response_data)

    def update(self, measurement_id: str, data: dict[str, Any]) -> CellMeasurement:
        """Update an existing cell measurement.

        Parameters
        ----------
        measurement_id : str
            The ID of the cell measurement to update.
        data : dict[str, Any]
            Dictionary containing the fields to update.

        Returns
        -------
        CellMeasurement
            The updated cell measurement.
        """
        endpoint = f"/cell_measurements/{measurement_id}"
        response_data = self.client.put(endpoint, data)
        return CellMeasurement(**response_data)

    def delete(self, measurement_id: str) -> None:
        """Delete a cell measurement by measurement ID only."""
        endpoint = f"/cell_measurements/{measurement_id}"
        self.client.delete(endpoint)

    def list_with_steps(
        self, cell_instance_id: str
    ) -> CellInstanceMeasurementsWithSteps:
        """List all measurements and steps for a specific cell instance.

        Returns normalized data: separate lists for instance, measurements, and
        steps.
        """
        endpoint = f"/cell_instances/{cell_instance_id}/cell_measurements/with-steps"
        try:
            response_data = self.client.get(endpoint)
            return CellInstanceMeasurementsWithSteps(**response_data)
        except ValidationError as e:
            raise ValueError(f"Response validation failed for {endpoint}: {e}") from e
        except Exception as e:
            raise RuntimeError(f"API call to {endpoint} failed: {e}") from e

    def get_by_slugs(
        self, cell_instance_slug: str, measurement_slug: str
    ) -> CellMeasurement:
        """Get a specific cell measurement by instance slug and measurement slug.

        Returns metadata only (no steps or time series).
        """
        endpoint = (
            f"/cell_instances/slug/{cell_instance_slug}"
            f"/cell_measurements/slug/{measurement_slug}"
        )
        response_data = self.client.get(endpoint)
        return CellMeasurement(**response_data)

    def _dataframe_to_parquet(self, df: pl.DataFrame) -> bytes:
        """Convert a polars DataFrame to parquet bytes.

        Parameters
        ----------
        df : pl.DataFrame
            The DataFrame to convert.

        Returns
        -------
        bytes
            Parquet file content (uses zstd compression).
        """
        buffer = io.BytesIO()
        df.write_parquet(buffer, compression="zstd")
        return buffer.getvalue()

    def _initiate_upload(
        self,
        cell_instance_id: str,
        name: str,
        notes: str | None = None,
    ) -> InitiateUploadResponse:
        """Initiate a signed URL upload for a new measurement.

        Parameters
        ----------
        cell_instance_id : str
            The ID of the cell instance.
        name : str
            Name for the new measurement.
        notes : str | None
            Optional notes for the measurement.

        Returns
        -------
        InitiateUploadResponse
            Response containing measurement_id, signed_url, token, path.
        """
        endpoint = (
            f"/cell_instances/{cell_instance_id}/cell_measurements/initiate-upload"
        )
        measurement_data: dict[str, Any] = {"name": name}
        if notes:
            measurement_data["notes"] = notes

        payload = {"measurement": measurement_data}
        response_data = self.client.post(endpoint, payload)
        return InitiateUploadResponse(**response_data)

    def _upload_to_signed_url(self, signed_url: str, parquet_bytes: bytes) -> None:
        """Upload parquet bytes to a signed URL.

        Parameters
        ----------
        signed_url : str
            The signed URL to upload to.
        parquet_bytes : bytes
            The parquet file content to upload.

        Raises
        ------
        IonworksError
            If the upload fails.
        """
        # Handle Docker-internal URLs when running locally
        url = signed_url.replace("host.docker.internal", "localhost")

        try:
            response = requests.put(
                url,
                data=parquet_bytes,
                headers={"Content-Type": "application/octet-stream"},
                timeout=self.UPLOAD_TIMEOUT,
            )
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            raise IonworksError(f"Failed to upload to signed URL: {e}") from None

    def _confirm_upload(
        self,
        measurement_id: str,
        cell_instance_id: str,
        measurement_data: dict[str, Any],
        steps: dict[str, list[Any]] | None = None,
    ) -> ConfirmUploadResponse:
        """Confirm a signed URL upload after successful file upload.

        This creates the measurement record in the database. The measurement
        data must be passed again (same as initiate) to ensure no orphaned
        records are created if the file upload fails.

        Parameters
        ----------
        measurement_id : str
            The pre-generated ID for the measurement (from initiate).
        cell_instance_id : str
            The ID of the parent cell instance.
        measurement_data : dict[str, Any]
            Measurement metadata (name, notes, etc.) — same as passed to
            initiate.
        steps : dict[str, list[Any]] | None
            Pre-calculated steps data. If not provided, will be
            auto-calculated.

        Returns
        -------
        ConfirmUploadResponse
            Response containing instance, measurement, steps_created, and
            file_path.
        """
        endpoint = f"/cell_measurements/{measurement_id}/confirm-upload"
        payload: dict[str, Any] = {
            "cell_instance_id": cell_instance_id,
            "measurement": measurement_data,
        }
        if steps:
            payload["steps"] = steps

        response_data = self.client.post(endpoint, payload)
        return ConfirmUploadResponse(**response_data)

    def create(
        self,
        cell_instance_id: str,
        measurement_detail: dict[str, Any],
    ) -> CellMeasurementBundleResponse:
        """Create a new cell measurement with steps and time series data.

        Uses signed URL upload for better performance with large datasets.
        Data is uploaded directly to storage as parquet, bypassing backend
        JSON parsing. No database record is created until the upload is
        confirmed, preventing orphaned records if upload fails.

        Parameters
        ----------
        cell_instance_id : str
            The ID of the cell instance to create the measurement for.
        measurement_detail : dict[str, Any]
            Dictionary containing 'measurement', 'steps', and 'time_series'.

            - measurement: dict with 'name' (required) and 'notes'
            - time_series: pandas DataFrame or dict with time series data
            - steps: optional dict with pre-calculated steps data

        Returns
        -------
        CellMeasurementBundleResponse
            Response containing the created measurement, steps count, and
            file path.

        Raises
        ------
        MeasurementValidationError
            If data validation fails. Validation checks include:
            - Positive current should correspond to discharge
            - Cumulative values should reset at each step
        """
        measurement_info = measurement_detail["measurement"]
        name = measurement_info["name"]
        notes = measurement_info.get("notes")

        # Step 1: Convert time_series to polars DataFrame
        # Accepts pandas DataFrame, polars DataFrame, or dict
        time_series = _to_polars(measurement_detail["time_series"])

        # Step 2: Validate the data before any upload
        validate_measurement_data(time_series)

        # Step 3: Initiate upload (validates metadata, returns signed URL, no DB record)
        initiate_result = self._initiate_upload(cell_instance_id, name, notes)

        # Step 4: Convert to parquet
        parquet_bytes = self._dataframe_to_parquet(time_series)

        # Step 5: Upload to signed URL
        self._upload_to_signed_url(initiate_result.signed_url, parquet_bytes)

        # Step 6: Confirm upload (creates the measurement record)
        steps = measurement_detail.get("steps")
        if steps is not None:
            # Convert DataFrame to dict if needed
            steps = df_to_dict_validator(steps)
        confirm_result = self._confirm_upload(
            measurement_id=initiate_result.measurement_id,
            cell_instance_id=cell_instance_id,
            measurement_data=measurement_info,
            steps=steps,
        )

        return CellMeasurementBundleResponse(
            measurement=confirm_result.measurement,
            steps_created=confirm_result.steps_created,
            file_path=confirm_result.file_path,
        )

    def create_or_get(
        self,
        cell_instance_id: str,
        measurement_detail: dict[str, Any],
    ) -> CellMeasurementBundleResponse | CellMeasurement:
        """Create a new cell measurement or get existing one.

        Parameters
        ----------
        cell_instance_id : str
            The ID of the cell instance to create the measurement for.
        measurement_detail : dict[str, Any]
            Dictionary containing 'measurement', 'steps', and 'time_series'.

        Returns
        -------
        CellMeasurementBundleResponse | CellMeasurement
            Response containing the created measurement bundle, or the existing
            measurement if it already exists.
        """
        try:
            return self.create(cell_instance_id, measurement_detail)
        except IonworksError as e:
            # Check for duplicate key error (409 conflict or unique constraint)
            if e.status_code == 409 or (
                "duplicate key" in str(e).lower()
                and "cell_measurements_name_cell_instance_id_key" in str(e)
            ):
                # Look up existing measurement by name
                measurement_name = measurement_detail["measurement"]["name"]
                measurements = self.list(cell_instance_id)
                for m in measurements:
                    if m.name == measurement_name:
                        return m
                raise ValueError(
                    f"Measurement '{measurement_name}' reported as duplicate "
                    "but could not be found"
                ) from e
            raise
