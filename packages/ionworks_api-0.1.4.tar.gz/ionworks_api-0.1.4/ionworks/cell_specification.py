"""Cell specification client for managing cell type definitions.

This module provides the :class:`CellSpecificationClient` for creating,
reading, updating, and deleting cell specifications, which define the
properties of battery cell types (manufacturer, chemistry, ratings, etc.).
"""

from typing import Any

from pydantic import ValidationError

from ionworks.errors import IonworksError

from .models import CellSpecification


class CellSpecificationClient:
    """Client for managing cell specifications.

    Provides methods to create, read, update, and delete cell specifications,
    which define the properties of battery cell types (manufacturer, chemistry,
    ratings, etc.).
    """

    def __init__(self, client: Any) -> None:
        """Initialize the CellSpecificationClient.

        Parameters
        ----------
        client : Any
            The HTTP client instance for making API requests.
        """
        self.client = client

    def get(self, cell_spec_id: str) -> CellSpecification:
        """Get a specific cell specification by ID.

        Parameters
        ----------
        cell_spec_id : str
            The ID of the cell specification to retrieve.

        Returns
        -------
        CellSpecification
            The requested cell specification object.

        Raises
        ------
        ValueError
            If the response format is invalid.
        RuntimeError
            If the API call fails.
        """
        endpoint = f"/cell_specifications/{cell_spec_id}"
        try:
            response_data = self.client.get(endpoint)
            # Validate and parse the response
            return CellSpecification(**response_data)
        except ValidationError as e:
            raise ValueError(f"Invalid response format from {endpoint}: {e}") from e
        except Exception as e:  # Catch potential client errors
            raise RuntimeError(f"API call to {endpoint} failed: {e}") from e

    def list(self) -> list[CellSpecification]:
        """List all cell specifications.

        Returns
        -------
        list[CellSpecification]
            A list of all cell specification objects.

        Raises
        ------
        ValueError
            If the response format is not a list or items are invalid.
        RuntimeError
            If the API call fails.
        """
        endpoint = "/cell_specifications"
        try:
            response_data = self.client.get(endpoint)
            if not isinstance(response_data, list):
                raise ValueError(
                    f"Unexpected response format from {endpoint}: expected a list, "
                    f"got {type(response_data).__name__}"
                )
            # Validate each item in the list
            return [CellSpecification(**item) for item in response_data]
        except ValidationError as e:
            raise ValueError(f"Invalid item format in list from {endpoint}: {e}") from e
        except Exception as e:  # Catch potential client errors
            raise RuntimeError(f"API call to {endpoint} failed: {e}") from e

    def create(self, data: dict[str, Any]) -> CellSpecification:
        """Create a new cell specification.

        Parameters
        ----------
        data : dict[str, Any]
            Dictionary containing the cell specification data.

        Returns
        -------
        CellSpecification
            The newly created cell specification object.
        """
        endpoint = "/cell_specifications"
        response_data = self.client.post(endpoint, data)
        return CellSpecification(**response_data)

    def create_or_get(self, data: dict[str, Any]) -> CellSpecification:
        """Create a new cell specification or get an existing one.

        Creates a new cell specification if it doesn't exist, otherwise returns
        the existing one.

        Parameters
        ----------
        data : dict[str, Any]
            Dictionary containing the cell specification data.

        Returns
        -------
        CellSpecification
            The cell specification object (newly created or existing).
        """
        try:
            return self.create(data)
        except IonworksError as e:
            if e.status_code == 409 and e.data is not None:
                existing_id = e.data.get("existing_cell_specification_id")
                if existing_id:
                    return self.get(existing_id)
            raise

    def update(self, cell_spec_id: str, data: dict[str, Any]) -> CellSpecification:
        """Update an existing cell specification.

        Parameters
        ----------
        cell_spec_id : str
            The ID of the cell specification to update.
        data : dict[str, Any]
            Dictionary containing the fields to update. Supports nested
            component/material data for upsert.

        Returns
        -------
        CellSpecification
            The updated cell specification object.
        """
        endpoint = f"/cell_specifications/{cell_spec_id}"
        response_data = self.client.put(endpoint, data)
        return CellSpecification(**response_data)

    def delete(self, cell_spec_id: str) -> None:
        """Delete a cell specification by ID.

        Parameters
        ----------
        cell_spec_id : str
            The ID of the cell specification to delete.
        """
        endpoint = f"/cell_specifications/{cell_spec_id}"
        self.client.delete(endpoint)

    def get_by_slug(self, cell_spec_slug: str) -> CellSpecification:
        """Get a specific cell specification by slug.

        Parameters
        ----------
        cell_spec_slug : str
            The slug of the cell specification to retrieve.

        Returns
        -------
        CellSpecification
            The requested cell specification object.

        Raises
        ------
        ValueError
            If the response format is invalid.
        RuntimeError
            If the API call fails.
        """
        endpoint = f"/cell_specifications/slug/{cell_spec_slug}"
        try:
            response_data = self.client.get(endpoint)
            return CellSpecification(**response_data)
        except ValidationError as e:
            raise ValueError(f"Invalid response format from {endpoint}: {e}") from e
        except Exception as e:
            raise RuntimeError(f"API call to {endpoint} failed: {e}") from e
