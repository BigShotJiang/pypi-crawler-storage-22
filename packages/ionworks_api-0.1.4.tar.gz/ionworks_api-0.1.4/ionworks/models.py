"""Pydantic models for the Ionworks API client.

These models use extra="allow" to accept any fields from the API response,
letting the API handle validation. Required fields are kept minimal.
"""

from typing import Any

from pydantic import BaseModel, ConfigDict, field_validator

from .validators import DataFrame, dict_to_df_validator

# --- Cell Specification Models --- #


class CellSpecification(BaseModel):
    """Cell specification model - accepts any fields from the API.

    The API returns nested component/material data and ratings objects.
    This model is permissive to allow the API to define the schema.
    """

    model_config = ConfigDict(extra="allow")

    id: str
    slug: str
    name: str


# --- Cell Instance Models --- #


class CellInstance(BaseModel):
    """Cell instance model - accepts any fields from the API."""

    model_config = ConfigDict(extra="allow")

    id: str
    slug: str


# --- Cell Measurement Models --- #


class CellMeasurement(BaseModel):
    """Cell measurement model - accepts any fields from the API."""

    model_config = ConfigDict(extra="allow")

    id: str
    slug: str
    name: str


# --- Bundle Models --- #


class CellMeasurementBundleResponse(BaseModel):
    """Response from creating a measurement bundle."""

    measurement: CellMeasurement
    steps_created: int
    file_path: str


class InitiateUploadResponse(BaseModel):
    """Response from the initiate-upload endpoint for signed URL uploads."""

    measurement_id: str
    signed_url: str
    token: str
    path: str


class ConfirmUploadResponse(BaseModel):
    """Response from the confirm-upload endpoint after successful upload."""

    instance: CellInstance
    measurement: CellMeasurement
    steps_created: int
    file_path: str


# --- Detail Models --- #


class CellMeasurementDetailBase(BaseModel):
    """Base model for measurement detail with steps and time series."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    measurement: CellMeasurement
    steps: DataFrame
    time_series: DataFrame

    @field_validator("steps", "time_series", mode="before")
    @classmethod
    def convert_dict_to_df(cls, v: Any) -> Any:
        """Convert dictionary to DataFrame (polars or pandas based on config)."""
        return dict_to_df_validator(v)


class CellInstanceDetail(BaseModel):
    """Detail model for a cell instance with all measurements."""

    specification: CellSpecification
    instance: CellInstance
    measurements: list[CellMeasurementDetailBase]


class CellMeasurementDetail(CellMeasurementDetailBase):
    """Detail model for a single measurement with context."""

    specification: CellSpecification
    instance: CellInstance


# --- Group Response Models --- #


class CellInstanceMeasurementsWithSteps(BaseModel):
    """Response model for measurements + steps for a cell instance.

    Returns normalized data: separate lists for instance, measurements,
    and steps. Includes parent information for consistency with other
    group endpoints.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    specification: CellSpecification
    instance: CellInstance
    measurements: list[CellMeasurement]
    steps: list[DataFrame]

    @field_validator("steps", mode="before")
    @classmethod
    def convert_dict_to_df(cls, v: Any) -> Any:
        """Convert dictionary or list of dictionaries to DataFrames."""
        if isinstance(v, list):
            return [dict_to_df_validator(item) for item in v]
        return dict_to_df_validator(v)


class CellSpecificationInstances(BaseModel):
    """Response model for all instances associated with a cell specification.

    Returns normalized data: separate lists for specification, instances,
    and measurements.
    """

    specification: CellSpecification
    instances: list[CellInstance]
    measurements: list[CellMeasurement]


class CellSpecificationInstancesWithSteps(BaseModel):
    """Response model for instances + measurements + steps for a cell spec.

    Returns normalized data: separate lists for specification, instances,
    measurements, and steps.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    specification: CellSpecification
    instances: list[CellInstance]
    measurements: list[CellMeasurement]
    steps: list[DataFrame]

    @field_validator("steps", mode="before")
    @classmethod
    def convert_dict_to_df(cls, v: Any) -> Any:
        """Convert dictionary or list of dictionaries to DataFrames."""
        if isinstance(v, list):
            return [dict_to_df_validator(item) for item in v]
        return dict_to_df_validator(v)
