"""iOS Backup Inspector — GUI tool for analyzing iOS backups on macOS"""
__version__ = "0.1.0"