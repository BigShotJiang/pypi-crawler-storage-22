"""Работа с бэкапами iOS: парсинг, поиск файлов приложения"""
from pathlib import Path
import sqlite3
import plistlib
from datetime import datetime
from typing import List, Dict, Optional, Tuple


class BackupFile:
    def __init__(self, file_id: str, relative_path: str, backup_path: Path, size: int, mtime: float):
        self.file_id = file_id
        self.relative_path = relative_path
        self.backup_path = backup_path
        self.size = size
        self.mtime = mtime
        self.exists = backup_path.exists()


class iOSBackup:
    def __init__(self, path: Path):
        self.path = path
        self.udid = path.name
        self.manifest_path = path / "Manifest.db"
        self.info_path = path / "Info.plist"
        self.status_path = path / "Status.plist"

    def get_device_info(self) -> Dict[str, str]:
        info = {}
        if self.info_path.exists():
            try:
                with open(self.info_path, 'rb') as f:
                    data = plistlib.load(f)
                    info['device_name'] = data.get('Device Name', 'Unknown')
                    info['product_type'] = data.get('Product Type', 'Unknown')
                    info['product_version'] = data.get('Product Version', 'Unknown')
            except Exception:
                pass
        return info

    def is_encrypted(self) -> bool:
        if self.status_path.exists():
            try:
                with open(self.status_path, 'rb') as f:
                    data = plistlib.load(f)
                    return data.get('IsEncrypted', False)
            except Exception:
                pass
        return False

    def get_backup_date(self) -> Optional[datetime]:
        try:
            return datetime.fromtimestamp(self.path.stat().st_mtime)
        except Exception:
            return None

    def find_app_files(self, bundle_id: str) -> List[BackupFile]:
        if not self.manifest_path.exists():
            raise FileNotFoundError(f"Manifest.db not found in {self.path}")

        domain_pattern = f"AppDomain-{bundle_id}"
        files = []

        conn = sqlite3.connect(str(self.manifest_path))
        cursor = conn.cursor()

        cursor.execute("""
            SELECT fileID, relativePath FROM Files
            WHERE domain LIKE ? AND relativePath != '' AND flags = 1
            ORDER BY relativePath
        """, (domain_pattern + '%',))

        for file_id, rel_path in cursor.fetchall():
            backup_file_path = self.path / file_id[:2] / file_id
            size = backup_file_path.stat().st_size if backup_file_path.exists() else 0
            mtime = backup_file_path.stat().st_mtime if backup_file_path.exists() else 0

            files.append(BackupFile(file_id, rel_path, backup_file_path, size, mtime))

        conn.close()
        return files

    def list_all_apps(self) -> List[Tuple[str, str]]:
        """Возвращает список всех приложений: [(имя_домена, bundle_id), ...]"""
        if not self.manifest_path.exists():
            raise FileNotFoundError(f"Manifest.db not found in {self.path}")

        apps = set()
        conn = sqlite3.connect(str(self.manifest_path))
        cursor = conn.cursor()

        # Ищем все домены вида AppDomain-*
        cursor.execute("""
            SELECT DISTINCT domain FROM Files
            WHERE domain LIKE 'AppDomain-%'
            ORDER BY domain
        """)

        for (domain,) in cursor.fetchall():
            if domain.startswith("AppDomain-"):
                bundle_id = domain[len("AppDomain-"):]
                apps.add((domain, bundle_id))

        conn.close()
        return sorted(apps, key=lambda x: x[1].lower())


def find_backups() -> List[iOSBackup]:
    backups_dir = Path.home() / "Library/Application Support/MobileSync/Backup"
    if not backups_dir.exists():
        return []

    backups = []
    for item in backups_dir.iterdir():
        if item.is_dir() and len(item.name) == 40:  # UDID = 40 chars
            backups.append(iOSBackup(item))

    # Сортируем по дате (новые сверху)
    backups.sort(key=lambda b: b.get_backup_date() or datetime.min, reverse=True)
    return backups