#!/usr/bin/env python3
"""
iOS Backup Inspector
Анализирует локальные бэкапы iOS и извлекает файлы конкретных приложений
Поддерживает Python 3.8+ (включая 3.14) с современным API tkinter
"""

import os
import sys
import sqlite3
import plistlib
import shutil
from pathlib import Path
from datetime import datetime
from tkinter import ttk, filedialog, messagebox
import tkinter as tk


class iOSBackupInspector:
    def __init__(self, root):
        self.root = root
        self.root.title("📱 iOS Backup Inspector")
        self.root.geometry("1200x750")
        self.root.configure(bg="#1e1e1e")
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)

        # Цветовая схема: тёмная тема с зелёным текстом
        self.colors = {
            "bg": "#1e1e1e",
            "fg": "#4cd137",  # зелёный текст
            "accent": "#2d2d2d",
            "select_bg": "#3d3d3d",
            "error": "#e84118",
            "warning": "#fbc531",
            "success": "#4cd137"
        }

        self.backups_dir = Path.home() / "Library/Application Support/MobileSync/Backup"
        self.current_backup_path = None
        self.current_manifest_conn = None
        self.app_files_cache = {}  # Кэш найденных файлов приложений

        self.setup_ui()
        self.load_backups()

    def setup_ui(self):
        # Верхняя панель: выбор бэкапа
        top_frame = tk.Frame(self.root, bg=self.colors["bg"], pady=10)
        top_frame.pack(fill=tk.X, padx=10)

        tk.Label(top_frame, text="📂 Доступные бэкапы:",
                 bg=self.colors["bg"], fg=self.colors["fg"], font=("Menlo", 12, "bold")).pack(anchor=tk.W)

        backup_frame = tk.Frame(top_frame, bg=self.colors["accent"], padx=5, pady=5)
        backup_frame.pack(fill=tk.X, pady=5)

        self.backup_listbox = tk.Listbox(
            backup_frame,
            height=6,
            bg=self.colors["bg"],
            fg=self.colors["fg"],
            selectbackground=self.colors["select_bg"],
            font=("Menlo", 11),
            exportselection=False
        )
        self.backup_listbox.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.backup_listbox.bind('<<ListboxSelect>>', self.on_backup_selected)

        scrollbar = ttk.Scrollbar(backup_frame, orient=tk.VERTICAL, command=self.backup_listbox.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.backup_listbox.config(yscrollcommand=scrollbar.set)

        # Средняя панель: информация о бэкапе + поиск приложения
        mid_frame = tk.Frame(self.root, bg=self.colors["bg"], pady=10)
        mid_frame.pack(fill=tk.X, padx=10)

        # Информация о бэкапе (левая часть)
        info_frame = tk.Frame(mid_frame, bg=self.colors["accent"], padx=10, pady=10)
        info_frame.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10))

        self.backup_info = tk.Text(
            info_frame,
            height=5,
            bg=self.colors["bg"],
            fg=self.colors["fg"],
            font=("Menlo", 10),
            wrap=tk.WORD,
            state=tk.DISABLED
        )
        self.backup_info.pack(fill=tk.BOTH, expand=True)

        # Поиск приложения (правая часть)
        search_frame = tk.Frame(mid_frame, bg=self.colors["accent"], padx=10, pady=10)
        search_frame.pack(side=tk.RIGHT, fill=tk.Y)

        tk.Label(search_frame, text="🔍 Bundle ID:",
                 bg=self.colors["accent"], fg=self.colors["fg"], font=("Menlo", 11)).pack(anchor=tk.W)

        self.bundle_id_var = tk.StringVar()
        # Используем trace_add вместо устаревшего trace
        self.bundle_id_var.trace_add("write", self.on_bundle_id_changed)
        self.bundle_id_entry = tk.Entry(
            search_frame,
            textvariable=self.bundle_id_var,
            bg=self.colors["bg"],
            fg=self.colors["fg"],
            insertbackground=self.colors["fg"],
            font=("Menlo", 11)
        )
        self.bundle_id_entry.pack(fill=tk.X, pady=(5, 10))

        # Кнопка поиска (для ручного запуска)
        tk.Button(
            search_frame,
            text="🔎 Найти приложение",
            command=self.manual_search,
            bg=self.colors["bg"],
            fg=self.colors["fg"],
            font=("Menlo", 10),
            padx=10,
            pady=3
        ).pack(fill=tk.X, pady=(0, 5))

        self.app_status_label = tk.Label(
            search_frame,
            text="Введите Bundle ID (например: com.whatsapp.WhatsApp)",
            bg=self.colors["accent"],
            fg="#a0a0a0",  # серый для подсказки
            font=("Menlo", 9, "italic"),
            wraplength=250,
            justify=tk.LEFT
        )
        self.app_status_label.pack(anchor=tk.W, pady=(5, 0))

        # Нижняя панель: файлы приложения
        bottom_frame = tk.Frame(self.root, bg=self.colors["bg"], pady=10)
        bottom_frame.pack(fill=tk.BOTH, expand=True, padx=10)

        tk.Label(bottom_frame, text="📁 Файлы приложения:",
                 bg=self.colors["bg"], fg=self.colors["fg"], font=("Menlo", 12, "bold")).pack(anchor=tk.W)

        files_frame = tk.Frame(bottom_frame, bg=self.colors["accent"], padx=5, pady=5)
        files_frame.pack(fill=tk.BOTH, expand=True)

        # Treeview для файлов
        columns = ("path", "size", "modified")
        self.files_tree = ttk.Treeview(
            files_frame,
            columns=columns,
            show="headings",
            selectmode="extended"
        )

        # Стилизация Treeview под тёмную тему
        style = ttk.Style()
        style.theme_use('clam')
        style.configure("Treeview",
                        background=self.colors["bg"],
                        foreground=self.colors["fg"],
                        fieldbackground=self.colors["bg"],
                        font=("Menlo", 10)
                        )
        style.configure("Treeview.Heading",
                        background=self.colors["accent"],
                        foreground=self.colors["fg"],
                        font=("Menlo", 10, "bold")
                        )
        style.map("Treeview", background=[('selected', self.colors["select_bg"])])

        # Заголовки
        self.files_tree.heading("path", text="Путь в приложении", anchor=tk.W)
        self.files_tree.heading("size", text="Размер", anchor=tk.E)
        self.files_tree.heading("modified", text="Изменён", anchor=tk.W)

        self.files_tree.column("path", width=650, anchor=tk.W)
        self.files_tree.column("size", width=100, anchor=tk.E)
        self.files_tree.column("modified", width=150, anchor=tk.W)

        self.files_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        tree_scroll = ttk.Scrollbar(files_frame, orient=tk.VERTICAL, command=self.files_tree.yview)
        tree_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.files_tree.config(yscrollcommand=tree_scroll.set)

        # Панель действий
        actions_frame = tk.Frame(self.root, bg=self.colors["bg"], pady=10)
        actions_frame.pack(fill=tk.X, padx=10)

        tk.Button(
            actions_frame,
            text="💾 Экспортировать выбранные",
            command=self.export_selected_files,
            bg=self.colors["accent"],
            fg=self.colors["fg"],
            font=("Menlo", 11),
            padx=15,
            pady=5
        ).pack(side=tk.LEFT, padx=(0, 10))

        tk.Button(
            actions_frame,
            text="📦 Экспортировать ВСЕ",
            command=self.export_all_files,
            bg=self.colors["accent"],
            fg=self.colors["fg"],
            font=("Menlo", 11),
            padx=15,
            pady=5
        ).pack(side=tk.LEFT, padx=(0, 10))

        tk.Button(
            actions_frame,
            text="🔄 Обновить список бэкапов",
            command=self.load_backups,
            bg=self.colors["accent"],
            fg=self.colors["fg"],
            font=("Menlo", 11),
            padx=15,
            pady=5
        ).pack(side=tk.LEFT)

        # Статусная строка
        self.status_var = tk.StringVar(value="Готов к работе")
        status_label = tk.Label(
            actions_frame,
            textvariable=self.status_var,
            bg=self.colors["bg"],
            fg=self.colors["fg"],
            font=("Menlo", 10, "italic")
        )
        status_label.pack(side=tk.RIGHT, padx=10)

    def load_backups(self):
        """Загружает список доступных бэкапов"""
        self.backup_listbox.delete(0, tk.END)
        self.clear_file_list()
        self.backup_info.config(state=tk.NORMAL)
        self.backup_info.delete(1.0, tk.END)
        self.backup_info.config(state=tk.DISABLED)
        self.app_files_cache.clear()

        if not self.backups_dir.exists():
            self.set_status(f"❌ Папка бэкапов не найдена: {self.backups_dir}", "error")
            messagebox.showerror(
                "Ошибка",
                f"Папка бэкапов не найдена:\n{self.backups_dir}\n\n"
                "Убедитесь, что вы создали хотя бы один бэкап через Finder."
            )
            return

        backups = []
        for item in self.backups_dir.iterdir():
            if item.is_dir() and len(item.name) == 40:  # UDID имеет длину 40 символов
                try:
                    mtime = item.stat().st_mtime
                    backups.append((mtime, item))
                except Exception:
                    continue

        if not backups:
            self.set_status("⚠️ Бэкапы не найдены", "warning")
            messagebox.showinfo(
                "Информация",
                "Бэкапы не найдены.\n\n"
                "Создайте бэкап через Finder:\n"
                "1. Подключите iPhone к Mac через USB\n"
                "2. Откройте Finder → выберите устройство в сайдбаре\n"
                "3. Нажмите «Создать резервную копию сейчас»"
            )
            return

        # Сортируем по дате (новые сверху)
        backups.sort(reverse=True)

        for mtime, backup_path in backups:
            date_str = datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M:%S")

            # Читаем имя устройства из Info.plist
            device_name = "Unknown Device"
            product_version = "Unknown iOS"
            info_path = backup_path / "Info.plist"
            if info_path.exists():
                try:
                    with open(info_path, 'rb') as f:
                        info = plistlib.load(f)
                        device_name = info.get('Device Name', device_name)
                        product_version = info.get('Product Version', product_version)
                except Exception:
                    pass

            display_text = f"{date_str} | iOS {product_version} | {device_name[:25]} | {backup_path.name[:8]}..."
            self.backup_listbox.insert(tk.END, display_text)

        # Автовыбор последнего бэкапа
        self.backup_listbox.selection_set(0)
        self.on_backup_selected(None)
        self.set_status(f"Найдено бэкапов: {len(backups)}")

    def on_backup_selected(self, event):
        """Обработчик выбора бэкапа"""
        selection = self.backup_listbox.curselection()
        if not selection:
            return

        idx = selection[0]
        # Получаем путь к бэкапу (парсим из списка)
        backup_subdirs = [d for d in self.backups_dir.iterdir()
                          if d.is_dir() and len(d.name) == 40]
        backup_subdirs.sort(key=lambda x: x.stat().st_mtime, reverse=True)

        if idx >= len(backup_subdirs):
            return

        self.current_backup_path = backup_subdirs[idx]
        self.load_backup_info()
        self.app_files_cache.clear()
        self.clear_file_list()
        self.bundle_id_var.set("")  # Очищаем поиск при смене бэкапа
        self.app_status_label.config(text="Введите Bundle ID приложения", fg="#a0a0a0")

    def load_backup_info(self):
        """Загружает информацию о выбранном бэкапе"""
        if not self.current_backup_path:
            return

        info_text = []
        info_path = self.current_backup_path / "Info.plist"
        status_path = self.current_backup_path / "Status.plist"

        # Информация об устройстве
        if info_path.exists():
            try:
                with open(info_path, 'rb') as f:
                    info = plistlib.load(f)

                info_text.append(f"📱 Устройство: {info.get('Device Name', 'N/A')}")
                info_text.append(f"📱 Модель: {info.get('Product Type', 'N/A')}")
                info_text.append(f"📱 iOS: {info.get('Product Version', 'N/A')}")
                info_text.append(f"📱 Serial: {info.get('Serial Number', 'N/A')}")
            except Exception as e:
                info_text.append(f"⚠️ Ошибка чтения Info.plist: {e}")

        # Статус бэкапа
        is_encrypted = False
        if status_path.exists():
            try:
                with open(status_path, 'rb') as f:
                    status = plistlib.load(f)

                is_encrypted = status.get('IsEncrypted', False)
                info_text.append(f"🔒 Шифрование: {'ДА (рекомендуется)' if is_encrypted else 'НЕТ ⚠️'}")

                if not is_encrypted:
                    info_text.append("   ⚠️ Без шифрования многие данные приложений НЕДОСТУПНЫ!")

                # Статистика
                backup_date = status.get('Date', 'N/A')
                if isinstance(backup_date, datetime):
                    backup_date = backup_date.strftime("%Y-%m-%d %H:%M:%S")
                info_text.append(f"📅 Дата бэкапа: {backup_date}")

                backup_size = status.get('BackupTotalBytes', 0)
                if backup_size > 0:
                    size_mb = backup_size / (1024 * 1024)
                    info_text.append(f"📦 Размер: {size_mb:.1f} MB")
            except Exception as e:
                info_text.append(f"⚠️ Ошибка чтения Status.plist: {e}")

        # Обновляем текстовое поле
        self.backup_info.config(state=tk.NORMAL)
        self.backup_info.delete(1.0, tk.END)
        self.backup_info.insert(tk.END, "\n".join(info_text))
        self.backup_info.config(state=tk.DISABLED)

    def on_bundle_id_changed(self, *args):
        """Обработчик изменения Bundle ID (для trace_add)"""
        # Не запускаем поиск автоматически при каждом символе (слишком медленно)
        # Поиск запускается по кнопке или при потере фокуса
        pass

    def manual_search(self):
        """Ручной поиск приложения по кнопке"""
        bundle_id = self.bundle_id_var.get().strip()
        if not bundle_id:
            messagebox.showwarning("Предупреждение", "Введите Bundle ID приложения")
            return

        if not self.current_backup_path:
            messagebox.showwarning("Предупреждение", "Сначала выберите бэкап из списка")
            return

        self.app_status_label.config(text="Поиск...", fg=self.colors["fg"])
        self.root.update()

        try:
            # Проверяем кэш сначала
            if bundle_id in self.app_files_cache:
                files = self.app_files_cache[bundle_id]
            else:
                files = self.find_app_files(bundle_id)
                self.app_files_cache[bundle_id] = files

            if not files:
                self.app_status_label.config(
                    text=f"❌ Приложение '{bundle_id}' не найдено в бэкапе",
                    fg=self.colors["error"]
                )
                self.clear_file_list()
                messagebox.showinfo(
                    "Не найдено",
                    f"Приложение с Bundle ID '{bundle_id}' не найдено в бэкапе.\n\n"
                    "Советы:\n"
                    "• Убедитесь, что приложение установлено на устройстве при создании бэкапа\n"
                    "• Проверьте правильность Bundle ID (регистр важен!)\n"
                    "• Некоторые приложения исключают данные из незашифрованных бэкапов"
                )
                return

            # Показываем файлы
            self.populate_file_list(files)

            # Статистика
            total_size = sum(f.get('size', 0) for f in files if f.get('exists', False))
            size_str = self.format_size(total_size)
            self.app_status_label.config(
                text=f"✅ Найдено файлов: {len(files)} | Общий размер: {size_str}",
                fg=self.colors["success"]
            )

            self.set_status(f"Найдено {len(files)} файлов для {bundle_id}")

        except sqlite3.OperationalError as e:
            self.app_status_label.config(
                text=f"❌ Ошибка базы данных: {str(e)}",
                fg=self.colors["error"]
            )
            messagebox.showerror(
                "Ошибка базы данных",
                f"Не удалось прочитать Manifest.db:\n{e}\n\n"
                "Возможно, бэкап повреждён или зашифрован."
            )
            self.clear_file_list()
        except Exception as e:
            self.app_status_label.config(
                text=f"❌ Ошибка: {str(e)}",
                fg=self.colors["error"]
            )
            messagebox.showerror("Ошибка", f"Произошла ошибка:\n{str(e)}")
            self.clear_file_list()

    def find_app_files(self, bundle_id):
        """Ищет файлы приложения по Bundle ID в Manifest.db"""
        manifest_path = self.current_backup_path / "Manifest.db"
        if not manifest_path.exists():
            raise FileNotFoundError("Manifest.db не найден в бэкапе. Возможно, бэкап повреждён.")

        # Подключаемся к базе
        conn = sqlite3.connect(str(manifest_path))
        cursor = conn.cursor()

        # Ищем файлы по домену приложения
        # Формат домена: AppDomain-com.example.app
        domain_pattern = f"AppDomain-{bundle_id}"

        cursor.execute("""
            SELECT fileID, domain, relativePath
            FROM Files
            WHERE domain LIKE ? AND relativePath != '' AND flags = 1
            ORDER BY relativePath
        """, (domain_pattern + '%',))

        results = []
        for row in cursor.fetchall():
            file_id, domain, rel_path = row

            # Определяем реальный путь к файлу в бэкапе
            file_folder = file_id[:2]
            file_path = self.current_backup_path / file_folder / file_id

            # Получаем метаданные
            exists = file_path.exists()
            size = file_path.stat().st_size if exists else 0
            mtime = file_path.stat().st_mtime if exists else 0

            results.append({
                'file_id': file_id,
                'domain': domain,
                'relative_path': rel_path,
                'backup_path': file_path,
                'size': size,
                'mtime': mtime,
                'exists': exists
            })

        conn.close()
        return results

    def populate_file_list(self, files):
        """Заполняет Treeview списком файлов"""
        self.clear_file_list()

        for f in files:
            size_str = self.format_size(f['size']) if f['exists'] else "—"
            mtime_str = datetime.fromtimestamp(f['mtime']).strftime("%Y-%m-%d %H:%M:%S") if f['mtime'] else "—"

            tags = ()
            if not f['exists']:
                tags = ("missing",)
            elif f['size'] > 10 * 1024 * 1024:  # > 10 MB
                tags = ("large",)

            self.files_tree.insert(
                "",
                tk.END,
                values=(f['relative_path'], size_str, mtime_str),
                tags=tags,
                iid=f['file_id']
            )

        # Стилизация строк
        self.files_tree.tag_configure("missing", foreground=self.colors["error"])
        self.files_tree.tag_configure("large", foreground="#40739e")

    def clear_file_list(self):
        """Очищает список файлов"""
        for item in self.files_tree.get_children():
            self.files_tree.delete(item)

    def export_selected_files(self):
        """Экспортирует выбранные файлы"""
        selection = self.files_tree.selection()
        if not selection:
            messagebox.showwarning("Предупреждение",
                                   "Выберите файлы для экспорта (удерживайте Cmd/Ctrl для множественного выбора)")
            return

        # Выбираем папку назначения
        dest_dir = filedialog.askdirectory(title="Выберите папку для экспорта")
        if not dest_dir:
            return

        exported = 0
        errors = 0
        bundle_id = self.bundle_id_var.get().strip() or "unknown_app"

        for file_id in selection:
            item = self.files_tree.item(file_id)
            rel_path = item['values'][0]

            # Ищем файл в кэше
            file_info = None
            for f in self.app_files_cache.get(bundle_id, []):
                if f['file_id'] == file_id:
                    file_info = f
                    break

            if not file_info or not file_info['exists']:
                errors += 1
                continue

            src_path = file_info['backup_path']
            dest_path = Path(dest_dir) / bundle_id / file_info['relative_path']
            dest_path.parent.mkdir(parents=True, exist_ok=True)

            try:
                shutil.copy2(src_path, dest_path)
                exported += 1
            except Exception as e:
                print(f"Ошибка копирования {rel_path}: {e}")
                errors += 1

        if exported > 0:
            messagebox.showinfo(
                "Экспорт завершён",
                f"✅ Успешно экспортировано: {exported}\n"
                f"❌ Ошибок: {errors}\n"
                f"📁 Папка: {dest_dir}/{bundle_id}"
            )
            self.set_status(f"Экспортировано {exported} файлов в {dest_dir}")
        elif errors > 0:
            messagebox.showerror("Ошибка экспорта", f"Не удалось экспортировать {errors} файл(ов)")

    def export_all_files(self):
        """Экспортирует все файлы текущего приложения"""
        bundle_id = self.bundle_id_var.get().strip()
        if not bundle_id:
            messagebox.showwarning("Предупреждение", "Сначала найдите приложение по Bundle ID")
            return

        files = self.app_files_cache.get(bundle_id, [])
        if not files:
            messagebox.showwarning("Предупреждение", "Нет файлов для экспорта")
            return

        dest_dir = filedialog.askdirectory(title="Выберите папку для экспорта")
        if not dest_dir:
            return

        exported = 0
        errors = 0

        for f in files:
            if not f['exists']:
                errors += 1
                continue

            src_path = f['backup_path']
            dest_path = Path(dest_dir) / bundle_id / f['relative_path']
            dest_path.parent.mkdir(parents=True, exist_ok=True)

            try:
                shutil.copy2(src_path, dest_path)
                exported += 1
            except Exception as e:
                print(f"Ошибка копирования {f['relative_path']}: {e}")
                errors += 1

        if exported > 0:
            messagebox.showinfo(
                "Экспорт завершён",
                f"✅ Успешно экспортировано: {exported}\n"
                f"❌ Ошибок: {errors}\n"
                f"📁 Папка: {dest_dir}/{bundle_id}"
            )
            self.set_status(f"Экспортировано {exported} файлов в {dest_dir}")
        elif errors > 0:
            messagebox.showerror("Ошибка экспорта", f"Не удалось экспортировать {errors} файл(ов)")

    @staticmethod
    def format_size(bytes_size):
        """Форматирует размер в человекочитаемый вид"""
        if bytes_size == 0:
            return "0 B"
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if bytes_size < 1024:
                return f"{bytes_size:.1f} {unit}"
            bytes_size /= 1024
        return f"{bytes_size:.1f} PB"

    def set_status(self, message, level="info"):
        """Устанавливает статусную строку"""
        self.status_var.set(message)

    def on_closing(self):
        """Обработчик закрытия окна"""
        if self.current_manifest_conn:
            try:
                self.current_manifest_conn.close()
            except:
                pass
        self.root.destroy()


def main():
    # Проверка ОС
    if sys.platform != "darwin":
        print("⚠️  Этот скрипт предназначен для macOS (папка бэкапов находится в ~/Library/...)")
        print("   На других ОС функционал будет ограничен.")
        if sys.platform == "win32":
            print("\n💡 Для Windows используйте путь: %APPDATA%\\Apple Computer\\MobileSync\\Backup\\")
        sys.exit(1)

    # Проверка наличия бэкапов
    backups_dir = Path.home() / "Library/Application Support/MobileSync/Backup"
    if not backups_dir.exists():
        print(f"❌ Папка бэкапов не найдена: {backups_dir}")
        print("   Убедитесь, что вы создали хотя бы один бэкап через Finder.")
        response = messagebox.askyesno(
            "Бэкапы не найдены",
            "Папка бэкапов не найдена.\n\n"
            "Хотите открыть инструкцию по созданию бэкапа в Finder?"
        )
        if response:
            import webbrowser
            webbrowser.open("https://support.apple.com/ru-ru/HT203977")
        sys.exit(1)

    # Запуск GUI
    root = tk.Tk()
    iOSBackupInspector(root)
    root.mainloop()
