"""Точка входа"""
import tkinter as tk
from .ui import BackupInspectorUI


def main():
    root = tk.Tk()
    app = BackupInspectorUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()