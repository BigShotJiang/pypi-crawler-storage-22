"""Работа с plist-файлами: парсинг, редактирование, сохранение"""
import plistlib
import difflib
from pathlib import Path
from typing import Any, Tuple


def read_plist(path: Path) -> Tuple[Any, str]:
    """
    Читает plist (binary или XML).
    Возвращает: (данные, исходный формат 'binary'/'xml')
    """
    with open(path, 'rb') as f:
        content = f.read()

    # Определяем формат по сигнатуре
    fmt = 'binary' if content.startswith(b'bplist') else 'xml'

    try:
        data = plistlib.loads(content)
        return data, fmt
    except Exception as e:
        raise ValueError(f"Ошибка парсинга plist: {e}")


def write_plist(path: Path, data: Any, fmt: str = 'xml'):
    """
    Сохраняет plist в указанном формате.
    Форматы: 'xml' (человекочитаемый) или 'binary' (оригинальный)
    """
    fmt_flag = plistlib.FMT_BINARY if fmt == 'binary' else plistlib.FMT_XML
    content = plistlib.dumps(data, fmt=fmt_flag)

    with open(path, 'wb') as f:
        f.write(content)


def generate_diff(old_data: Any, new_data: Any) -> str:
    """Генерирует текстовый diff между двумя версиями plist"""
    old_text = plistlib.dumps(old_data, fmt=plistlib.FMT_XML).decode('utf-8')
    new_text = plistlib.dumps(new_data, fmt=plistlib.FMT_XML).decode('utf-8')

    diff = difflib.unified_diff(
        old_text.splitlines(keepends=True),
        new_text.splitlines(keepends=True),
        fromfile='оригинал',
        tofile='изменения',
        lineterm=''
    )
    return ''.join(diff)