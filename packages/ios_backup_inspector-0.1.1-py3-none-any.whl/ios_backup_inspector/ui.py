"""Минималистичный GUI для инспектора бэкапов"""
import datetime
import plistlib
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
from typing import List, Optional, Tuple
from .backup import iOSBackup, BackupFile, find_backups
from .plist_utils import read_plist, write_plist, generate_diff
from tkinter.scrolledtext import ScrolledText

class BackupInspectorUI:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("iOS Backup Inspector")
        self.root.geometry("1000x650")

        self.backups: List[iOSBackup] = []
        self.current_backup: Optional[iOSBackup] = None
        self.current_files: List[BackupFile] = []

        self._create_widgets()
        self._load_backups()

    def _create_widgets(self):
        # Выбор бэкапа
        top = ttk.Frame(self.root, padding=10)
        top.pack(fill=tk.X)

        ttk.Label(top, text="Бэкап:").pack(side=tk.LEFT)
        self.backup_var = tk.StringVar()
        self.backup_combo = ttk.Combobox(top, textvariable=self.backup_var, width=80, state="readonly")
        self.backup_combo.pack(side=tk.LEFT, padx=5)
        self.backup_combo.bind("<<ComboboxSelected>>", self._on_backup_selected)

        # Bundle ID + кнопки
        mid = ttk.Frame(self.root, padding=10)
        mid.pack(fill=tk.X)

        ttk.Label(mid, text="Bundle ID:").pack(side=tk.LEFT)
        self.bundle_var = tk.StringVar()
        self.bundle_entry = ttk.Entry(mid, textvariable=self.bundle_var, width=40)
        self.bundle_entry.pack(side=tk.LEFT, padx=5)
        ttk.Button(mid, text="Найти", command=self._search_app).pack(side=tk.LEFT, padx=5)
        ttk.Button(mid, text="Список всех приложений", command=self._list_all_apps).pack(side=tk.LEFT, padx=5)

        # Список файлов
        bottom = ttk.Frame(self.root, padding=10)
        bottom.pack(fill=tk.BOTH, expand=True)

        columns = ("path", "size", "modified")
        self.tree = ttk.Treeview(bottom, columns=columns, show="headings")
        self.tree.heading("path", text="Путь")
        self.tree.heading("size", text="Размер")
        self.tree.heading("modified", text="Изменён")
        self.tree.column("path", width=600)
        self.tree.column("size", width=100, anchor=tk.E)
        self.tree.column("modified", width=150)

        vsb = ttk.Scrollbar(bottom, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)

        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)

        # Кнопки действий
        actions = ttk.Frame(self.root, padding=10)
        actions.pack(fill=tk.X)

        ttk.Button(actions, text="Экспортировать выбранные", command=self._export_selected).pack(side=tk.LEFT, padx=5)
        ttk.Button(actions, text="Экспортировать все", command=self._export_all).pack(side=tk.LEFT, padx=5)
        self._add_context_menu()

    def _load_backups(self):
        self.backups = find_backups()
        if not self.backups:
            messagebox.showwarning("Внимание",
                                   "Бэкапы не найдены.\n"
                                   "Создайте бэкап через Finder: Подключите iPhone → Finder → устройство → «Создать резервную копию»")
            self.root.quit()
            return

        self.backup_combo["values"] = [
            f"{b.get_backup_date().strftime('%Y-%m-%d %H:%M')} | {b.get_device_info().get('device_name', 'Unknown')} | iOS {b.get_device_info().get('product_version', '?')}"
            for b in self.backups
        ]
        self.backup_combo.current(0)
        self._on_backup_selected(None)

    def _on_backup_selected(self, _event):
        idx = self.backup_combo.current()
        if idx >= 0 and idx < len(self.backups):
            self.current_backup = self.backups[idx]
            self._update_tree([])

    def _search_app(self):
        if not self.current_backup:
            return

        bundle_id = self.bundle_var.get().strip()
        if not bundle_id:
            messagebox.showwarning("Внимание", "Введите Bundle ID")
            return

        try:
            self.current_files = self.current_backup.find_app_files(bundle_id)
            self._update_tree(self.current_files)

            if not self.current_files:
                messagebox.showinfo("Результат",
                                    f"Приложение '{bundle_id}' не найдено или его данные отсутствуют в бэкапе.\n"
                                    "Возможно:\n"
                                    "• Приложение не установлено при создании бэкапа\n"
                                    "• Bundle ID указан неверно\n"
                                    "• Данные исключены из незашифрованного бэкапа (часто банковские приложения)")
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось найти файлы:\n{e}")

    def _list_all_apps(self):
        if not self.current_backup:
            return

        try:
            apps = self.current_backup.list_all_apps()

            if not apps:
                messagebox.showinfo("Результат", "Приложения не найдены в бэкапе")
                return

            # Создаём окно со списком
            list_win = tk.Toplevel(self.root)
            list_win.title("Установленные приложения")
            list_win.geometry("600x500")

            # Поиск по списку
            search_frame = ttk.Frame(list_win, padding=5)
            search_frame.pack(fill=tk.X)
            ttk.Label(search_frame, text="Поиск:").pack(side=tk.LEFT)
            search_var = tk.StringVar()
            search_var.trace_add("write", lambda *args: self._filter_app_list(tree, apps, search_var.get()))
            ttk.Entry(search_frame, textvariable=search_var, width=50).pack(side=tk.LEFT, padx=5)

            # Таблица приложений
            tree_frame = ttk.Frame(list_win, padding=5)
            tree_frame.pack(fill=tk.BOTH, expand=True)

            columns = ("bundle",)
            tree = ttk.Treeview(tree_frame, columns=columns, show="headings")
            tree.heading("bundle", text="Bundle ID")
            tree.column("bundle", width=550)

            vsb = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=tree.yview)
            tree.configure(yscrollcommand=vsb.set)
            tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
            vsb.pack(side=tk.RIGHT, fill=tk.Y)

            # Заполняем
            for _, bundle_id in apps:
                tree.insert("", tk.END, values=(bundle_id,))

            # Двойной клик — копировать в поле ввода
            def on_double_click(event):
                item = tree.selection()[0]
                bundle_id = tree.item(item)["values"][0]
                self.bundle_var.set(bundle_id)
                list_win.destroy()

            tree.bind("<Double-1>", on_double_click)

            # Кнопка закрытия
            ttk.Button(list_win, text="Закрыть", command=list_win.destroy).pack(pady=10)

        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось получить список приложений:\n{e}")

    def _filter_app_list(self, tree, apps: List[Tuple[str, str]], query: str):
        """Фильтрует список приложений по поисковому запросу"""
        for item in tree.get_children():
            tree.delete(item)

        query = query.lower()
        for _, bundle_id in apps:
            if query in bundle_id.lower():
                tree.insert("", tk.END, values=(bundle_id,))

    def _update_tree(self, files: List[BackupFile]):
        for item in self.tree.get_children():
            self.tree.delete(item)

        for f in files:
            if f.size < 1024:
                size = f"{f.size} B"
            elif f.size < 1024 * 1024:
                size = f"{f.size / 1024:.1f} KB"
            else:
                size = f"{f.size / (1024 * 1024):.1f} MB"

            try:
                modified = datetime.datetime.fromtimestamp(f.mtime).strftime('%Y-%m-%d %H:%M:%S')
            except:
                modified = "-"

            exists_mark = "✓" if f.exists else "✗"
            self.tree.insert("", tk.END, iid=f.file_id, values=(f"{exists_mark} {f.relative_path}", size, modified))

    def _export_selected(self):
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("Внимание", "Выберите файлы для экспорта")
            return

        dest = filedialog.askdirectory(title="Папка для экспорта")
        if not dest:
            return

        exported = 0
        for file_id in selection:
            f = next((f for f in self.current_files if f.file_id == file_id), None)
            if f and f.exists:
                dest_path = Path(dest) / f.relative_path
                dest_path.parent.mkdir(parents=True, exist_ok=True)
                dest_path.write_bytes(f.backup_path.read_bytes())
                exported += 1

        messagebox.showinfo("Готово", f"Экспортировано файлов: {exported}")

    def _export_all(self):
        if not self.current_files:
            messagebox.showwarning("Внимание", "Нет файлов для экспорта")
            return

        dest = filedialog.askdirectory(title="Папка для экспорта")
        if not dest:
            return

        exported = 0
        for f in self.current_files:
            if f.exists:
                dest_path = Path(dest) / f.relative_path
                dest_path.parent.mkdir(parents=True, exist_ok=True)
                dest_path.write_bytes(f.backup_path.read_bytes())
                exported += 1

        messagebox.showinfo("Готово", f"Экспортировано файлов: {exported}")

    def _add_context_menu(self):
        """Добавляет контекстное меню для дерева файлов"""
        self.context_menu = tk.Menu(self.tree, tearoff=0)
        self.context_menu.add_command(label="Открыть как plist", command=self._open_as_plist)
        self.context_menu.add_command(label="Экспортировать", command=self._export_selected)

        def show_menu(event):
            item = self.tree.identify_row(event.y)
            if item:
                self.tree.selection_set(item)
                self.context_menu.post(event.x_root, event.y_root)
            else:
                self.tree.selection_remove(self.tree.selection())

        self.tree.bind("<Button-3>", show_menu)  # ПКМ на macOS: Ctrl+Click эмулируется системой
        self.tree.bind("<Control-Button-1>", show_menu)  # Альтернатива для macOS

    def _open_as_plist(self):
        """Открывает выбранный файл как plist для редактирования"""
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("Внимание", "Выберите файл для редактирования")
            return

        file_id = selection[0]
        f = next((f for f in self.current_files if f.file_id == file_id), None)
        if not f or not f.exists:
            messagebox.showerror("Ошибка", "Файл недоступен для чтения")
            return

        # Проверяем расширение
        if not f.relative_path.lower().endswith(('.plist', '.xml')):
            if not messagebox.askyesno("Подтверждение",
                                       "Файл не имеет расширения .plist. Открыть как plist anyway?"):
                return

        try:
            data, fmt = read_plist(f.backup_path)
            PlistEditorDialog(self.root, f.backup_path, data, fmt, self._on_plist_saved)
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось открыть как plist:\n{e}")

    def _on_plist_saved(self, path: Path):
        """Обработчик после успешного сохранения plist"""
        messagebox.showinfo("Успех", f"Файл сохранён:\n{path.name}")
        # Обновляем информацию о файле (размер, дата)
        self._search_app()  # Перезагружаем список файлов


class PlistEditorDialog:
    """Диалог редактирования plist-файла"""

    def __init__(self, parent, path: Path, data, fmt: str, on_save_callback):
        self.path = path
        self.original_data = data
        self.current_data = data
        self.original_format = fmt
        self.on_save_callback = on_save_callback

        self.dialog = tk.Toplevel(parent)
        self.dialog.title(f"Редактирование: {path.name}")
        self.dialog.geometry("800x600")

        # Переключатель режимов
        mode_frame = ttk.Frame(self.dialog, padding=5)
        mode_frame.pack(fill=tk.X)

        self.mode_var = tk.StringVar(value="text")
        ttk.Radiobutton(mode_frame, text="Текст (XML)", variable=self.mode_var,
                        value="text", command=self._switch_mode).pack(side=tk.LEFT)
        ttk.Radiobutton(mode_frame, text="Структура (ограничено)", variable=self.mode_var,
                        value="tree", command=self._switch_mode).pack(side=tk.LEFT, padx=10)

        # Текстовый редактор (по умолчанию)
        self.text_editor = ScrolledText(self.dialog, wrap=tk.NONE, font=("Menlo", 11))
        self.text_editor.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.text_editor.insert(tk.END, plistlib.dumps(data, fmt=plistlib.FMT_XML).decode('utf-8'))

        # Кнопки
        btn_frame = ttk.Frame(self.dialog, padding=5)
        btn_frame.pack(fill=tk.X)

        ttk.Button(btn_frame, text="Отмена", command=self.dialog.destroy).pack(side=tk.RIGHT, padx=5)
        ttk.Button(btn_frame, text="Сохранить", command=self._save).pack(side=tk.RIGHT, padx=5)

        # Горячие клавиши
        self.text_editor.bind("<Command-s>", lambda e: self._save())
        self.text_editor.focus_set()

    def _switch_mode(self):
        """Переключение между текстовым и древовидным режимом (заглушка для простоты)"""
        # Полноценный древовидный редактор сложен — оставляем только текстовый режим
        # Это минималистичная реализация
        if self.mode_var.get() == "tree":
            messagebox.showinfo("Инфо", "Древовидный режим временно недоступен.\nИспользуйте текстовый редактор.")
            self.mode_var.set("text")

    def _save(self):
        """Сохранение с подтверждением и созданием бэкапа"""
        try:
            # Парсим изменения из текста
            new_content = self.text_editor.get("1.0", tk.END).encode('utf-8')
            new_data = plistlib.loads(new_content)
        except Exception as e:
            messagebox.showerror("Ошибка", f"Некорректный XML/plist:\n{e}")
            return

        # Генерируем diff
        diff = generate_diff(self.original_data, new_data)
        if not diff.strip():
            messagebox.showinfo("Инфо", "Изменений не обнаружено")
            return

        # Показываем предпросмотр изменений
        preview = tk.Toplevel(self.dialog)
        preview.title("Подтверждение изменений")
        preview.geometry("700x400")

        ttk.Label(preview, text="Будут применены следующие изменения:").pack(pady=5)

        text = ScrolledText(preview, wrap=tk.NONE, font=("Menlo", 10))
        text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        text.insert(tk.END, diff)
        text.config(state=tk.DISABLED)

        def confirm():
            preview.destroy()
            self._do_save(new_data)

        btn_frame = ttk.Frame(preview, padding=5)
        btn_frame.pack(fill=tk.X)
        ttk.Button(btn_frame, text="Отмена", command=preview.destroy).pack(side=tk.RIGHT, padx=5)
        ttk.Button(btn_frame, text="Подтверждаю, сохранить",
                   command=confirm, style="Accent.TButton").pack(side=tk.RIGHT, padx=5)

        # Стиль для акцентной кнопки
        style = ttk.Style()
        style.configure("Accent.TButton", background="#4cd137", foreground="white")

    def _do_save(self, new_data):
        """Фактическое сохранение файла"""
        # 1. Создаём резервную копию оригинала
        backup_path = self.path.with_suffix(self.path.suffix + ".bak")
        if not backup_path.exists():
            self.path.rename(backup_path)

        # 2. Сохраняем новые данные в оригинальном формате
        try:
            write_plist(self.path, new_data, self.original_format)
        except Exception as e:
            # Восстанавливаем из бэкапа при ошибке
            if backup_path.exists():
                backup_path.rename(self.path)
            messagebox.showerror("Ошибка", f"Не удалось сохранить файл:\n{e}")
            return

        # 3. Удаляем бэкап после успешного сохранения (опционально)
        # backup_path.unlink()

        self.on_save_callback(self.path)
        self.dialog.destroy()