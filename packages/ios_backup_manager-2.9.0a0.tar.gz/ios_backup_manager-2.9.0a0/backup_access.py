import hashlib
import os
import sqlite3
import tempfile
import shutil
from typing import Optional


try:
    from iphone_backup_decrypt import EncryptedBackup
    from iphone_backup_decrypt import utils as ibd_utils
except Exception:
    EncryptedBackup = None
    ibd_utils = None


_BACKUP_ACCESS_REGISTRY = {}


def register_backup_access(backup_path: str, access: "BackupAccess") -> None:
    _BACKUP_ACCESS_REGISTRY[os.path.abspath(backup_path)] = access


def get_backup_access(backup_path: str) -> Optional["BackupAccess"]:
    return _BACKUP_ACCESS_REGISTRY.get(os.path.abspath(backup_path))


def clear_backup_access(backup_path: Optional[str] = None) -> None:
    if backup_path is None:
        _BACKUP_ACCESS_REGISTRY.clear()
        return
    _BACKUP_ACCESS_REGISTRY.pop(os.path.abspath(backup_path), None)


def cleanup_backup_access(backup_path: str) -> None:
    access = _BACKUP_ACCESS_REGISTRY.get(os.path.abspath(backup_path))
    if access is None:
        return
    try:
        access.cleanup_temp_dir()
    finally:
        _BACKUP_ACCESS_REGISTRY.pop(os.path.abspath(backup_path), None)


def is_encrypted_backup(backup_path: str) -> bool:
    manifest_plist = os.path.join(backup_path, "Manifest.plist")
    if not os.path.exists(manifest_plist):
        return False
    try:
        import plistlib

        with open(manifest_plist, "rb") as f:
            manifest = plistlib.load(f)
        return bool(manifest.get("IsEncrypted", False))
    except Exception:
        return False


class BackupAccess:
    """Provides manifest and file access for plain or encrypted backups."""

    def __init__(self, backup_path: str, password: Optional[str] = None):
        self.backup_path = backup_path
        self.is_encrypted = is_encrypted_backup(backup_path)
        self._password = password
        self._encrypted = None
        self._manifest_db_path = os.path.join(backup_path, "Manifest.db")
        self._file_cache = {}
        self._temp_dir = None

        if self.is_encrypted:
            if EncryptedBackup is None or ibd_utils is None:
                raise RuntimeError("Encrypted backup support not available (iphone_backup_decrypt missing).")
            if not password:
                raise ValueError("Encrypted backup requires a password.")
            self._encrypted = EncryptedBackup(backup_directory=backup_path, passphrase=password)
            # Decrypt Manifest.db on demand so it's ready for queries.
            self._encrypted._decrypt_manifest_db_file()
            self._manifest_db_path = self._encrypted._temp_decrypted_manifest_db_path
            self._temp_dir = tempfile.mkdtemp(prefix="ibm_decrypted_")

    @property
    def manifest_db_path(self) -> str:
        return self._manifest_db_path

    def _hash_path(self, domain: str, relative_path: str) -> str:
        return hashlib.sha1(f"{domain}-{relative_path}".encode()).hexdigest()

    def _physical_path(self, file_id: str) -> str:
        return os.path.join(self.backup_path, file_id[:2], file_id)

    def _fetch_file_row(self, file_id: str):
        conn = sqlite3.connect(self.manifest_db_path)
        try:
            cur = conn.cursor()
            cur.execute("SELECT fileID, file, domain, relativePath FROM Files WHERE fileID = ?", (file_id,))
            return cur.fetchone()
        finally:
            conn.close()

    def get_file_path(self, domain: str, relative_path: str) -> Optional[str]:
        file_id = self._hash_path(domain, relative_path)
        if not self.is_encrypted:
            physical_path = self._physical_path(file_id)
            return physical_path if os.path.exists(physical_path) else None

        return self.get_file_path_by_id(file_id)

    def get_file_path_by_id(self, file_id: str, file_bplist: Optional[bytes] = None) -> Optional[str]:
        if not self.is_encrypted:
            physical_path = self._physical_path(file_id)
            return physical_path if os.path.exists(physical_path) else None
        if not self._temp_dir or not os.path.exists(self._temp_dir):
            return None

        cached = self._file_cache.get(file_id)
        if cached and os.path.exists(cached):
            return cached

        if file_bplist is None:
            row = self._fetch_file_row(file_id)
            if not row:
                return None
            _, file_bplist, _, _ = row

        file_plist = ibd_utils.FilePlist(file_bplist)
        if file_plist.encryption_key is None:
            physical_path = self._physical_path(file_id)
            return physical_path if os.path.exists(physical_path) else None

        inner_key = self._encrypted._keybag.unwrapKeyForClass(
            file_plist.protection_class, file_plist.encryption_key
        )
        out_path = os.path.join(self._temp_dir, file_id[:2], file_id)
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        if not os.path.exists(out_path):
            physical_path = self._physical_path(file_id)
            if not os.path.exists(physical_path):
                return None
            try:
                ibd_utils.aes_decrypt_chunked(
                    in_filename=physical_path,
                    out_filepath=out_path,
                    key=inner_key,
                    file_plist=file_plist,
                )
            except FileNotFoundError:
                return None
        self._file_cache[file_id] = out_path
        return out_path

    def cleanup_temp_dir(self) -> None:
        if not self.is_encrypted or not self._temp_dir:
            return
        try:
            shutil.rmtree(self._temp_dir, ignore_errors=True)
        finally:
            self._temp_dir = None
            self._file_cache.clear()
