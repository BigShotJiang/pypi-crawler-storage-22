#!/usr/bin/env python3
"""
backup_merger_gui.py

GUI wrapper for iTunes Backup Merger
Provides user-friendly interface for merge_backups.py script
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import os
import sys
import threading
import subprocess
import plistlib
import json
from pathlib import Path
from datetime import datetime, timezone
import queue
from io import BytesIO
import time
import traceback
import tempfile

# Import schema validator for iOS version detection and compatibility checking
from schema_validator import detect_ios_version, validate_backup_merge_compatibility


def _read_app_config(config_path):
    try:
        if os.path.exists(config_path):
            with open(config_path, "r", encoding="utf-8") as f:
                return json.load(f) or {}
    except Exception:
        pass
    return {}


def _write_app_config(config_path, updates):
    try:
        config = _read_app_config(config_path)
        config.update(updates)
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(config, f)
    except Exception:
        pass


def _apply_windows_dpi_scaling(root):
    if sys.platform != "win32":
        return
    try:
        import ctypes
        try:
            ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
        except Exception:
            try:
                ctypes.windll.shcore.SetProcessDpiAwareness(2)
            except Exception:
                try:
                    ctypes.windll.user32.SetProcessDPIAware()
                except Exception:
                    pass
        dpi = None
        try:
            hwnd = root.winfo_id()
            dpi = ctypes.windll.user32.GetDpiForWindow(hwnd)
        except Exception:
            try:
                hdc = ctypes.windll.user32.GetDC(0)
                dpi = ctypes.windll.gdi32.GetDeviceCaps(hdc, 88)
                ctypes.windll.user32.ReleaseDC(0, hdc)
            except Exception:
                dpi = None
        if dpi:
            scale = max(1.0, float(dpi) / 96.0) * 1.25
            root.tk.call("tk", "scaling", scale)
    except Exception:
        pass

# Resource helpers
def get_resource_path(*parts):
    bases = [
        getattr(sys, "_MEIPASS", None),
        os.path.dirname(os.path.abspath(__file__)),
        sys.prefix,
    ]
    alt_parts = None
    if parts and parts[0] in ("resources", "template"):
        alt_parts = parts[1:]
    for base_path in bases:
        if not base_path:
            continue
        candidate = os.path.join(base_path, *parts)
        if os.path.exists(candidate):
            return candidate
        if alt_parts:
            candidate = os.path.join(base_path, *alt_parts)
            if os.path.exists(candidate):
                return candidate
    fallback = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(fallback, *parts)

# Ensure bundled DLLs are discoverable (needed for PyUSB on Windows).
def register_resource_dlls():
    if os.name != "nt":
        return
    dll_path = get_resource_path("resources", "libusb-1.0.dll")
    dll_dir = os.path.dirname(dll_path)
    globals()["_DLL_DIR_REGISTERED"] = False
    if os.path.exists(dll_path):
        try:
            os.add_dll_directory(dll_dir)
            globals()["_DLL_DIR_REGISTERED"] = True
        except Exception:
            pass

register_resource_dlls()

# Device detection diagnostics log (for packaged builds).
LAST_PYMOBILEDEVICE3_ERROR = None

def _device_log_path():
    base_dir = os.path.join(tempfile.gettempdir(), "iOSBackupManager")
    try:
        os.makedirs(base_dir, exist_ok=True)
    except Exception:
        base_dir = os.getcwd()
    return os.path.join(base_dir, "device_detection.log")

def log_device_detection(msg):
    log_path = _device_log_path()
    try:
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(msg + "\n")
    except Exception:
        pass
    return log_path

# Startup log to capture early crashes in debug builds.
def log_startup(msg):
    log_dir = os.path.join(tempfile.gettempdir(), "iOSBackupManager")
    try:
        os.makedirs(log_dir, exist_ok=True)
    except Exception:
        log_dir = os.getcwd()
    log_path = os.path.join(log_dir, "startup.log")
    try:
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(msg + "\n")
    except Exception:
        pass

# Extra diagnostics to capture import failures explicitly.
def diagnose_pymobiledevice3():
    try:
        import importlib
        log_device_detection("diagnose: importing pymobiledevice3.usbmux")
        importlib.import_module("pymobiledevice3.usbmux")
        log_device_detection("diagnose: importing pymobiledevice3.lockdown")
        importlib.import_module("pymobiledevice3.lockdown")
        log_device_detection("diagnose: importing pymobiledevice3.services.mobilebackup2")
        importlib.import_module("pymobiledevice3.services.mobilebackup2")
        log_device_detection("diagnose: import sequence OK")
        return None
    except BaseException as exc:
        log_device_detection(f"diagnose: import failed: {exc!r}\n{traceback.format_exc()}")
        return exc

# Build/version display
APP_VERSION = "2.9 Alpha"
BUILD_ENV_VAR = "IBM_BUILD"
BUILD_NUMBER_FILE = "build_number.txt"

def get_build_number():
    build = os.getenv(BUILD_ENV_VAR)
    if build:
        return build
    file_path = get_resource_path(BUILD_NUMBER_FILE)
    if os.path.exists(file_path):
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                value = f.read().strip()
                return value or "dev"
        except Exception:
            return "dev"
    return "dev"

def get_build_title():
    build_label = get_build_number()
    return f"iOS Backup Manager v{APP_VERSION} (Build {build_label})"

# Import cross-platform utilities
from file_manager import FileManager
from platform_utils import Platform
from theme_manager import get_theme

# Startup splash
def show_startup_splash(root):
    splash_path = get_resource_path("resources", "splash.png")
    image = None
    try:
        from PIL import Image as _Image, ImageTk as _ImageTk
    except Exception:
        _Image = None
        _ImageTk = None

    if _Image and _ImageTk and os.path.exists(splash_path):
        try:
            image = _Image.open(splash_path)
            max_w, max_h = 320, 480
            if image.width > max_w or image.height > max_h:
                scale = min(max_w / image.width, max_h / image.height)
                image = image.resize((int(image.width * scale), int(image.height * scale)), _Image.LANCZOS)
        except Exception:
            image = None

    splash = tk.Toplevel(root)
    splash.overrideredirect(True)
    splash.attributes("-topmost", True)
    splash.configure(bg="black")

    if image and _ImageTk:
        photo = _ImageTk.PhotoImage(image)
        img_label = tk.Label(splash, image=photo, bg="black")
        img_label.image = photo
        img_label.pack()
    else:
        title = tk.Label(splash, text="iOS Backup Manager", fg="white", bg="black", font=("Segoe UI", 14, "bold"))
        subtitle = tk.Label(splash, text="Loading...", fg="#cfd6f7", bg="black", font=("Segoe UI", 10))
        title.pack(padx=20, pady=(20, 4))
        subtitle.pack(padx=20, pady=(0, 10))

    progress = ttk.Progressbar(splash, mode="indeterminate", length=260)
    progress.pack(pady=(8, 12))
    progress.start(10)

    splash.update_idletasks()
    splash.update()
    width = splash.winfo_width()
    height = splash.winfo_height()
    screen_w = splash.winfo_screenwidth()
    screen_h = splash.winfo_screenheight()
    x = (screen_w - width) // 2
    y = (screen_h - height) // 2
    splash.geometry(f"{width}x{height}+{x}+{y}")
    return splash, time.monotonic(), progress

# Debug logging
DEBUG_LOG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "debug_toggle.txt")
def debug_log(msg):
    """Write debug message to log file and print to console"""
    timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
    full_msg = f"[{timestamp}] {msg}"
    print(full_msg)  # Also print to console
    try:
        with open(DEBUG_LOG, "a", encoding="utf-8") as f:
            f.write(full_msg + "\n")
    except:
        pass

# Try to import PIL for image handling
try:
    from PIL import Image, ImageTk, ImageDraw
    PIL_AVAILABLE = True
except ImportError:
    Image = None
    ImageTk = None
    ImageDraw = None
    PIL_AVAILABLE = False

# Try to import tkinterdnd2 for drag-and-drop
try:
    from tkinterdnd2 import TkinterDnD, DND_FILES
    DND_AVAILABLE = True
except ImportError:
    DND_AVAILABLE = False

# Try to import pymobiledevice3 for iOS device detection (lazy)
PYMOBILEDEVICE3_AVAILABLE = False
list_devices = None
create_using_usbmux = None
DiagnosticsService = None
SpringBoardServicesService = None
Mobilebackup2Service = None

def ensure_pymobiledevice3_loaded():
    global PYMOBILEDEVICE3_AVAILABLE, list_devices, create_using_usbmux
    global DiagnosticsService, SpringBoardServicesService, Mobilebackup2Service
    global LAST_PYMOBILEDEVICE3_ERROR
    if PYMOBILEDEVICE3_AVAILABLE:
        return True
    log_device_detection(
        "Attempting pymobiledevice3 load. "
        f"MEIPASS={getattr(sys, '_MEIPASS', None)} "
        f"libusb_exists={os.path.exists(get_resource_path('resources', 'libusb-1.0.dll'))} "
        f"dll_dir_registered={globals().get('_DLL_DIR_REGISTERED')}"
    )
    try:
        from pymobiledevice3.usbmux import list_devices as _list_devices
        from pymobiledevice3.lockdown import create_using_usbmux as _create_using_usbmux
        from pymobiledevice3.services.diagnostics import DiagnosticsService as _DiagnosticsService
        from pymobiledevice3.services.springboard import SpringBoardServicesService as _SpringBoardServicesService
        from pymobiledevice3.services.mobilebackup2 import Mobilebackup2Service as _Mobilebackup2Service
        list_devices = _list_devices
        create_using_usbmux = _create_using_usbmux
        DiagnosticsService = _DiagnosticsService
        SpringBoardServicesService = _SpringBoardServicesService
        Mobilebackup2Service = _Mobilebackup2Service
        PYMOBILEDEVICE3_AVAILABLE = True
        log_device_detection("pymobiledevice3 load OK")
        return True
    except BaseException as exc:
        PYMOBILEDEVICE3_AVAILABLE = False
        LAST_PYMOBILEDEVICE3_ERROR = exc
        msg = f"pymobiledevice3 load failed: {exc!r}\n{traceback.format_exc()}"
        print("Warning: pymobiledevice3 not available. Device detection will be disabled.")
        log_device_detection(msg)
        return False

# Try to import wmi for Windows device event monitoring
try:
    import wmi
    WMI_AVAILABLE = True
except ImportError:
    WMI_AVAILABLE = False
    print("Warning: WMI not available. Using polling fallback for device detection.")

# Device model decoder
DEVICE_MODELS = {
    # iPhone models
    "iPhone1,1": "iPhone", "iPhone1,2": "iPhone 3G", "iPhone2,1": "iPhone 3GS",
    "iPhone3,1": "iPhone 4", "iPhone3,2": "iPhone 4", "iPhone3,3": "iPhone 4",
    "iPhone4,1": "iPhone 4s", "iPhone5,1": "iPhone 5", "iPhone5,2": "iPhone 5",
    "iPhone5,3": "iPhone 5c", "iPhone5,4": "iPhone 5c", "iPhone6,1": "iPhone 5s",
    "iPhone6,2": "iPhone 5s", "iPhone7,1": "iPhone 6 Plus", "iPhone7,2": "iPhone 6",
    "iPhone8,1": "iPhone 6s", "iPhone8,2": "iPhone 6s Plus", "iPhone8,4": "iPhone SE",
    "iPhone9,1": "iPhone 7", "iPhone9,2": "iPhone 7 Plus", "iPhone9,3": "iPhone 7",
    "iPhone9,4": "iPhone 7 Plus", "iPhone10,1": "iPhone 8", "iPhone10,2": "iPhone 8 Plus",
    "iPhone10,3": "iPhone X", "iPhone10,4": "iPhone 8", "iPhone10,5": "iPhone 8 Plus",
    "iPhone10,6": "iPhone X", "iPhone11,2": "iPhone XS", "iPhone11,4": "iPhone XS Max",
    "iPhone11,6": "iPhone XS Max", "iPhone11,8": "iPhone XR", "iPhone12,1": "iPhone 11",
    "iPhone12,3": "iPhone 11 Pro", "iPhone12,5": "iPhone 11 Pro Max", "iPhone12,8": "iPhone SE (2nd gen)",
    "iPhone13,1": "iPhone 12 mini", "iPhone13,2": "iPhone 12", "iPhone13,3": "iPhone 12 Pro",
    "iPhone13,4": "iPhone 12 Pro Max", "iPhone14,2": "iPhone 13 Pro", "iPhone14,3": "iPhone 13 Pro Max",
    "iPhone14,4": "iPhone 13 mini", "iPhone14,5": "iPhone 13", "iPhone14,6": "iPhone SE (3rd gen)",
    "iPhone14,7": "iPhone 14", "iPhone14,8": "iPhone 14 Plus", "iPhone15,2": "iPhone 14 Pro",
    "iPhone15,3": "iPhone 14 Pro Max", "iPhone15,4": "iPhone 15", "iPhone15,5": "iPhone 15 Plus",
    "iPhone16,1": "iPhone 15 Pro", "iPhone16,2": "iPhone 15 Pro Max",

    # iPad models
    "iPad1,1": "iPad", "iPad2,1": "iPad 2", "iPad2,2": "iPad 2", "iPad2,3": "iPad 2",
    "iPad2,4": "iPad 2", "iPad2,5": "iPad mini", "iPad2,6": "iPad mini", "iPad2,7": "iPad mini",
    "iPad3,1": "iPad (3rd gen)", "iPad3,2": "iPad (3rd gen)", "iPad3,3": "iPad (3rd gen)",
    "iPad3,4": "iPad (4th gen)", "iPad3,5": "iPad (4th gen)", "iPad3,6": "iPad (4th gen)",
    "iPad4,1": "iPad Air", "iPad4,2": "iPad Air", "iPad4,3": "iPad Air",
    "iPad4,4": "iPad mini 2", "iPad4,5": "iPad mini 2", "iPad4,6": "iPad mini 2",
    "iPad4,7": "iPad mini 3", "iPad4,8": "iPad mini 3", "iPad4,9": "iPad mini 3",
    "iPad5,1": "iPad mini 4", "iPad5,2": "iPad mini 4", "iPad5,3": "iPad Air 2", "iPad5,4": "iPad Air 2",
    "iPad6,3": "iPad Pro 9.7\"", "iPad6,4": "iPad Pro 9.7\"", "iPad6,7": "iPad Pro 12.9\"",
    "iPad6,8": "iPad Pro 12.9\"", "iPad6,11": "iPad (5th gen)", "iPad6,12": "iPad (5th gen)",
    "iPad7,1": "iPad Pro 12.9\" (2nd gen)", "iPad7,2": "iPad Pro 12.9\" (2nd gen)",
    "iPad7,3": "iPad Pro 10.5\"", "iPad7,4": "iPad Pro 10.5\"", "iPad7,5": "iPad (6th gen)",
    "iPad7,6": "iPad (6th gen)", "iPad7,11": "iPad (7th gen)", "iPad7,12": "iPad (7th gen)",
    "iPad8,1": "iPad Pro 11\"", "iPad8,2": "iPad Pro 11\"", "iPad8,3": "iPad Pro 11\"",
    "iPad8,4": "iPad Pro 11\"", "iPad8,5": "iPad Pro 12.9\" (3rd gen)", "iPad8,6": "iPad Pro 12.9\" (3rd gen)",
    "iPad8,7": "iPad Pro 12.9\" (3rd gen)", "iPad8,8": "iPad Pro 12.9\" (3rd gen)",
    "iPad8,9": "iPad Pro 11\" (2nd gen)", "iPad8,10": "iPad Pro 11\" (2nd gen)",
    "iPad8,11": "iPad Pro 12.9\" (4th gen)", "iPad8,12": "iPad Pro 12.9\" (4th gen)",
    "iPad11,1": "iPad mini (5th gen)", "iPad11,2": "iPad mini (5th gen)",
    "iPad11,3": "iPad Air (3rd gen)", "iPad11,4": "iPad Air (3rd gen)",
    "iPad11,6": "iPad (8th gen)", "iPad11,7": "iPad (8th gen)",
    "iPad12,1": "iPad (9th gen)", "iPad12,2": "iPad (9th gen)",
    "iPad13,1": "iPad Air (4th gen)", "iPad13,2": "iPad Air (4th gen)",
    "iPad13,4": "iPad Pro 11\" (3rd gen)", "iPad13,5": "iPad Pro 11\" (3rd gen)",
    "iPad13,6": "iPad Pro 11\" (3rd gen)", "iPad13,7": "iPad Pro 11\" (3rd gen)",
    "iPad13,8": "iPad Pro 12.9\" (5th gen)", "iPad13,9": "iPad Pro 12.9\" (5th gen)",
    "iPad13,10": "iPad Pro 12.9\" (5th gen)", "iPad13,11": "iPad Pro 12.9\" (5th gen)",
    "iPad14,1": "iPad mini (6th gen)", "iPad14,2": "iPad mini (6th gen)",
}

def find_local_backup_for_device(udid, additional_paths=None):
    """Find local iTunes or Apple Devices backup for a specific device UDID"""
    import os
    import plistlib
    from datetime import datetime

    user_profile = os.path.expanduser("~")
    backup_locations = []

    # Add custom backup paths first (higher priority)
    if additional_paths:
        if isinstance(additional_paths, str):
            additional_paths = [additional_paths]
        backup_locations.extend(additional_paths)

    # Add platform-specific default backup locations
    backup_locations.extend(Platform.get_default_backup_locations())

    if Platform.is_windows():
        # --- Additional Windows-specific backup paths (beyond defaults) ---

        # Legacy XP-era (rare)
        backup_locations.append(os.path.join(
            "C:\\", "Documents and Settings",
            os.getenv("USERNAME", ""), "Application Data",
            "Apple Computer", "MobileSync", "Backup"
        ))

        # Possible LocalPackages sandboxed install (Store-sandboxed variants)
        local_appdata = os.getenv("LOCALAPPDATA", os.path.join(user_profile, "AppData", "Local"))
        packages_dir = os.path.join(local_appdata, "Packages")
        if os.path.isdir(packages_dir):
            for pkg in os.listdir(packages_dir):
                if pkg.lower().startswith("appleinc.") and "itunes" in pkg.lower():
                    sandboxed_path = os.path.join(
                        packages_dir, pkg, "Roaming", "Apple Computer", "MobileSync", "Backup"
                    )
                    backup_locations.append(sandboxed_path)

    # Deduplicate and keep only existing dirs
    backup_locations = list({p for p in backup_locations if os.path.isdir(p)})

    # Search for backup matching UDID
    for location in backup_locations:
        try:
            for folder_name in os.listdir(location):
                backup_path = os.path.join(location, folder_name)
                if not os.path.isdir(backup_path):
                    continue

                info_plist = os.path.join(backup_path, "Info.plist")
                if not os.path.exists(info_plist):
                    continue

                try:
                    with open(info_plist, 'rb') as f:
                        info = plistlib.load(f)

                    backup_udid = info.get('Target Identifier') or info.get('Unique Identifier')
                    if backup_udid and backup_udid.upper() == udid.upper():
                        return {
                            'path': backup_path,
                            'date': info.get('Last Backup Date'),
                            'device_name': info.get('Device Name', 'Unknown'),
                            'udid': backup_udid
                        }
                except Exception:
                    continue
        except Exception:
            continue

    return None

def format_bytes(bytes_value):
    """Format bytes to human-readable string (e.g., '128.5 GB')"""
    if bytes_value is None:
        return "—"

    for unit in ['bytes', 'KB', 'MB', 'GB', 'TB']:
        if bytes_value < 1024.0:
            if unit == 'bytes':
                return f"{bytes_value:.0f} {unit}"
            return f"{bytes_value:.1f} {unit}"
        bytes_value /= 1024.0
    return f"{bytes_value:.1f} PB"

def get_marketed_capacity(total_bytes):
    """Convert actual storage bytes to marketed capacity (e.g., 64GB, 128GB, 256GB)"""
    if total_bytes is None:
        return None

    # Convert to GB
    gb = total_bytes / (1024 ** 3)

    # Common Apple storage tiers (map actual to marketed)
    # Actual capacities are slightly less due to formatting
    tiers = [
        (16, "16GB"), (32, "32GB"), (64, "64GB"),
        (128, "128GB"), (256, "256GB"), (512, "512GB"),
        (1024, "1TB"), (2048, "2TB")
    ]

    # Find the closest tier (allow wider tolerance for lower capacities)
    for tier_gb, label in tiers:
        # Use percentage-based matching with generous tolerance for system/formatting overhead
        # iOS devices can show significantly less than marketed due to:
        # - Base 10 vs Base 2 conversion (1000 vs 1024)
        # - iOS system partition (larger on older devices)
        # - Formatting overhead
        # Lower capacities need more tolerance (e.g., 32GB iPhone 6S Plus shows ~23GB)
        lower_bound = tier_gb * 0.70  # Allow up to 30% below marketed capacity
        upper_bound = tier_gb * 1.02
        if lower_bound <= gb <= upper_bound:
            return label

    # If no match, return approximate
    return f"{int(round(gb))}GB"

def map_device_color_code(color_code):
    """Map iOS device color code to human-readable color name"""
    if color_code is None:
        print("[DEBUG] map_device_color_code: color_code is None")
        return None

    # Convert to string for consistent handling
    color_code_str = str(color_code)
    print(f"[DEBUG] map_device_color_code: Processing color_code_str = '{color_code_str}'")

    # Common iOS device color codes (numeric)
    color_map = {
        '1': 'Black',
        '2': 'White',
        '3': 'Silver',
        '4': 'Gold',
        '5': 'Rose Gold',
        '6': 'Space Gray',
        '7': 'Red (PRODUCT RED)',
        '8': 'Blue',
        '9': 'Midnight Green',
        '10': 'Pacific Blue',
        '11': 'Graphite',
        '12': 'Sierra Blue',
        '13': 'Alpine Green',
        '14': 'Deep Purple',
        '15': 'Starlight',
        '16': 'Pink'
    }

    # Try numeric code first
    if color_code_str in color_map:
        result = color_map[color_code_str]
        print(f"[DEBUG] map_device_color_code: Matched numeric code -> '{result}'")
        return result

    # Fallback: Handle hex color codes (DeviceEnclosureColor)
    # Map common hex colors to color names
    if color_code_str.startswith('#'):
        print(f"[DEBUG] map_device_color_code: Detected hex color code")
        hex_color_map = {
            '#b9b7ba': 'Silver',           # iPhone 6S Plus Silver enclosure
            '#e1e4e3': 'Silver',           # Silver variant
            '#f0f1f3': 'White',            # White
            '#faf8f6': 'White',            # White variant
            '#1e1e1e': 'Black',            # Black
            '#272728': 'Space Gray',       # Space Gray / Black front glass
            '#2c2c2e': 'Space Gray',       # Space Gray
            '#4a4a4a': 'Space Gray',       # Space Gray variant
            '#fad3c0': 'Gold',             # Gold
            '#f4e5dd': 'Gold',             # Gold variant
            '#facfc6': 'Rose Gold',        # Rose Gold
            '#e1ccbb': 'Rose Gold',        # Rose Gold variant
            '#ba0c2f': 'Red (PRODUCT RED)', # Red
            '#a50034': 'Red (PRODUCT RED)', # Red variant
        }
        # Try exact match first
        if color_code_str.lower() in [k.lower() for k in hex_color_map.keys()]:
            for hex_key, color_name in hex_color_map.items():
                if hex_key.lower() == color_code_str.lower():
                    print(f"[DEBUG] map_device_color_code: Matched hex color {color_code_str} -> '{color_name}'")
                    return color_name
        # If no exact match, just return generic description
        print(f"[DEBUG] map_device_color_code: No match for hex color {color_code_str}, returning None")
        return None  # Will be omitted from display

    result = f"Color {color_code}"
    print(f"[DEBUG] map_device_color_code: Unknown format -> '{result}'")
    return result

def get_free_space_at_path(path):
    """Get free space in bytes at the specified path"""
    import shutil

    if not path or not os.path.exists(path):
        # If path doesn't exist, try to get parent directory
        parent = os.path.dirname(path) if path else None
        if parent and os.path.exists(parent):
            path = parent
        else:
            return None

    try:
        stat = shutil.disk_usage(path)
        return stat.free
    except Exception as e:
        print(f"Error getting free space for {path}: {e}")
        return None

def format_time_ago(date_obj):
    """Format datetime object as 'X days ago' or 'X hours ago'"""
    from datetime import datetime, timezone

    if not date_obj:
        return "Unknown"

    # Ensure date_obj is timezone-aware
    if date_obj.tzinfo is None:
        # Assume UTC if no timezone
        date_obj = date_obj.replace(tzinfo=timezone.utc)

    now = datetime.now(timezone.utc)
    diff = now - date_obj

    days = diff.days
    hours = diff.seconds // 3600
    minutes = (diff.seconds % 3600) // 60

    if days > 365:
        years = days // 365
        return f"{years} year{'s' if years > 1 else ''} ago"
    elif days > 30:
        months = days // 30
        return f"{months} month{'s' if months > 1 else ''} ago"
    elif days > 0:
        return f"{days} day{'s' if days > 1 else ''} ago"
    elif hours > 0:
        return f"{hours} hour{'s' if hours > 1 else ''} ago"
    elif minutes > 0:
        return f"{minutes} minute{'s' if minutes > 1 else ''} ago"
    else:
        return "Just now"

def get_device_model(product_type):
    """Decode device product type to human-readable model name"""
    return DEVICE_MODELS.get(product_type, product_type)

def is_ipad(product_type):
    """Check if device is an iPad"""
    return product_type.startswith("iPad")

def get_default_itunes_backup_paths():
    """Get default iTunes backup locations on Windows"""
    paths = []

    # Windows Store iTunes location
    userprofile = os.environ.get('USERPROFILE', '')
    if userprofile:
        store_path = os.path.join(userprofile, 'Apple', 'MobileSync', 'Backup')
        if os.path.exists(store_path):
            paths.append(store_path)

    # Traditional iTunes location
    appdata = os.environ.get('APPDATA', '')
    if appdata:
        traditional_path = os.path.join(appdata, 'Apple Computer', 'MobileSync', 'Backup')
        if os.path.exists(traditional_path):
            paths.append(traditional_path)

    return paths

def compare_ios_versions(device_version, backup_version):
    """
    Compare two iOS version strings.
    Returns True if device_version >= backup_version, False otherwise.

    Args:
        device_version: iOS version string (e.g., "16.2.1")
        backup_version: iOS version string (e.g., "15.8")

    Returns:
        bool: True if device version is compatible (>= backup version)
    """
    try:
        # Parse version strings into tuples of integers
        device_parts = [int(x) for x in device_version.split('.')]
        backup_parts = [int(x) for x in backup_version.split('.')]

        # Pad shorter version with zeros (e.g., "15.8" becomes "15.8.0")
        max_len = max(len(device_parts), len(backup_parts))
        device_parts += [0] * (max_len - len(device_parts))
        backup_parts += [0] * (max_len - len(backup_parts))

        # Compare version components
        return tuple(device_parts) >= tuple(backup_parts)
    except (ValueError, AttributeError):
        # If parsing fails, allow the restore (don't block on parse errors)
        return True

def get_backup_ios_version(backup_path):
    """
    Extract iOS version from backup's Info.plist file.

    Args:
        backup_path: Path to the backup folder

    Returns:
        str or None: iOS version string (e.g., "15.8.1") or None if not found
    """
    try:
        info_plist_path = os.path.join(backup_path, 'Info.plist')

        if not os.path.exists(info_plist_path):
            return None

        # Read and parse Info.plist
        with open(info_plist_path, 'rb') as f:
            info = plistlib.load(f)

        # Extract 'Product Version' field
        return info.get('Product Version')
    except Exception as e:
        print(f"[DEBUG] Error reading backup iOS version: {e}")
        return None

def check_find_my_status(lockdown_client):
    """
    Best-effort check if Find My iPhone is enabled.

    Returns:
        True  -> clearly enabled
        False -> either clearly disabled OR unknown (we will not block on unknown;
                 the restore service will enforce MBErrorDomain/211 if needed).
    """
    try:
        if lockdown_client is None:
            return False

        candidates = [
            # (domain, key, description)
            # Official method matching ideviceinfo -q com.apple.fmip -k IsAssociated
            ('com.apple.fmip', 'IsAssociated', 'fmip/IsAssociated'),
            # Fallback candidates
            ('com.apple.mobile.lockdown', 'FMiPAccountExists', 'lockdown/FMiPAccountExists'),
            (None, 'FMiPAccountExists', 'global/FMiPAccountExists'),
            ('com.apple.mobileme', 'FMiPAccountExists', 'mobileme/FMiPAccountExists'),
            ('com.apple.mobile.lockdown', 'FMIPAccountExists', 'lockdown/FMIPAccountExists'),
        ]

        for domain, key, desc in candidates:
            try:
                if domain is not None:
                    val = lockdown_client.get_value(domain=domain, key=key)
                else:
                    val = lockdown_client.get_value(key=key)
                if val is not None:
                    return bool(val)
            except Exception:
                # MissingValue or similar; try next candidate
                pass

        # If we can't positively identify Find My as ON, return False;
        # device will still enforce via MBErrorDomain/211 during restore.
        return False

    except Exception:
        return False


def check_activation_status(lockdown_client):
    """
    Check if the device is activated.

    Returns:
        tuple: (is_activated: bool, activation_state: str)
               is_activated is True if ActivationState == "Activated"
               activation_state is the raw value returned by the device
    """
    try:
        if lockdown_client is None:
            print("[DEBUG] check_activation_status: lockdown_client is None")
            return False, "Unknown"

        # Get the ActivationState from the device
        activation_state = lockdown_client.get_value(key='ActivationState')
        # Removed debug spam: print(f"[DEBUG] ActivationState: {activation_state!r}")

        if activation_state is None:
            return False, "Unknown"

        # Check if state is "Activated" (case-sensitive)
        is_activated = (activation_state == "Activated")
        return is_activated, activation_state

    except Exception as e:
        print(f"[DEBUG] Error checking activation status: {e}")
        return False, "Error"


def calculate_backup_size(backup_path):
    """
    Calculate the total size of all files in a backup directory.
    Returns size in bytes, or 0 if calculation fails.
    """
    try:
        total_size = 0
        for dirpath, dirnames, filenames in os.walk(backup_path):
            for filename in filenames:
                filepath = os.path.join(dirpath, filename)
                try:
                    total_size += os.path.getsize(filepath)
                except (OSError, FileNotFoundError):
                    # Skip files that can't be accessed
                    continue
        return total_size
    except Exception as e:
        print(f"[DEBUG] Error calculating backup size: {e}")
        return 0

def normalize_backup_path(path):
    """
    Normalize backup path to handle:
    1. Direct backup folder (contains Info.plist)
    2. Parent folder containing UDID subfolder
    """
    if os.path.exists(os.path.join(path, "Info.plist")):
        return path

    if os.path.isdir(path):
        for item in os.listdir(path):
            item_path = os.path.join(path, item)
            if os.path.isdir(item_path):
                if os.path.exists(os.path.join(item_path, "Info.plist")):
                    return item_path

    return path


def classify_backup_path(path):
    """
    Classify a backup path as valid/legacy/invalid.
    Returns dict with keys: ok, legacy, reason, path
    """
    norm = normalize_backup_path(path)
    info_plist = os.path.join(norm, "Info.plist")
    manifest_db = os.path.join(norm, "Manifest.db")
    manifest_mbdb = os.path.join(norm, "Manifest.mbdb")
    manifest_mbdx = os.path.join(norm, "Manifest.mbdx")

    if not os.path.exists(info_plist):
        return {"ok": False, "legacy": False, "reason": "Missing Info.plist", "path": norm}

    if os.path.exists(manifest_db):
        return {"ok": True, "legacy": False, "reason": "", "path": norm}

    if os.path.exists(manifest_mbdb) or os.path.exists(manifest_mbdx):
        return {"ok": False, "legacy": True, "reason": "Legacy iTunes backup format (MBDB)", "path": norm}

    return {"ok": False, "legacy": False, "reason": "Missing Manifest.db", "path": norm}


def scan_for_backups(backup_root_path):
    """Scan a directory for iTunes backups (folders with Info.plist)"""
    backups = []

    try:
        if not os.path.exists(backup_root_path):
            return backups

        # List all subdirectories
        for item in os.listdir(backup_root_path):
            item_path = os.path.join(backup_root_path, item)

            # Check if it's a directory and has Info.plist
            if os.path.isdir(item_path):
                info_plist = os.path.join(item_path, 'Info.plist')
                manifest_db = os.path.join(item_path, 'Manifest.db')

                if os.path.exists(info_plist) and os.path.exists(manifest_db):
                    # Found a valid backup
                    try:
                        backup_info = BackupInfo(item_path)
                        if backup_info.is_valid:
                            backups.append(backup_info)
                    except Exception as e:
                        print(f"[DEBUG] Failed to load backup {item_path}: {e}")

    except Exception as e:
        print(f"[DEBUG] Failed to scan {backup_root_path}: {e}")

    # Sort by last backup date (most recent first)
    backups.sort(key=lambda b: b.last_backup, reverse=True)

    return backups

class BackupInfo:
    """Container for backup metadata"""
    def __init__(self, path, created_with_app=False, modified_with_app=False):
        self.original_path = path
        self.path = self._normalize_backup_path(path)
        self.name = "Unknown Device"
        self.udid = "Unknown"
        self.size_gb = 0
        self.size_gb_validated = None  # Accurate size after validation
        self.size_validation_in_progress = False
        self.size_validation_thread = None
        self.last_backup = "Unknown"
        self.ios_version = "Unknown"
        self.product_type = "Unknown"  # e.g., "iPhone8,1"
        self.device_model = "Unknown"  # e.g., "iPhone 6s"
        self.is_encrypted = False
        self.encryption_password = None
        self.backup_access = None
        self.is_valid = False
        self.validation_msg = ""
        self.is_supported = True
        self.is_legacy = False
        self.unsupported_reason = ""
        self.wallpaper_image = None  # PIL Image object
        self.created_with_app = created_with_app  # Flag for backups created with iOS Backup Manager
        self.modified_with_app = modified_with_app  # Flag for backups modified with iOS Backup Manager

        self._load_info()
        if self.is_valid and PIL_AVAILABLE:
            self._extract_wallpaper()
            

    # inside class BackupInfo:
    def get_created_timestamp(self):
        """Prefer Manifest.plist['Date'] (as UTC); fallback to folder mtime as UTC."""
        import os, plistlib
        try:
            mp_path = os.path.join(self.path, "Manifest.plist")
            if os.path.exists(mp_path):
                with open(mp_path, "rb") as f:
                    mp = plistlib.load(f)
                dt = mp.get("Date")
                if isinstance(dt, datetime):
                    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
                if isinstance(dt, str):
                    s = dt.strip()
                    if s.endswith("Z"):
                        return datetime.fromisoformat(s.replace("Z", "+00:00"))
                    parsed = datetime.fromisoformat(s)
                    return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
        except Exception:
            pass
        # Fallback: directory mtime as UTC
        try:
            ts = os.path.getmtime(self.path)
            return datetime.fromtimestamp(ts, tz=timezone.utc)
        except Exception:
            return None


    def get_created_timestamp_str(self):
        """Format created timestamp in LOCAL time as 'MM/DD/YYYY hh:mm AM/PM'."""
        dt = self.get_created_timestamp()
        if not dt:
            return "Unknown"
        try:
            local_dt = dt.astimezone()  # convert to local timezone
            return local_dt.strftime("%m/%d/%Y %I:%M%p")
        except Exception:
            return "Unknown"



    def _normalize_backup_path(self, path):
        """
        Normalize backup path to handle both:
        1. Direct backup folder (contains Info.plist, Manifest.db)
        2. Parent folder containing UDID subfolder
        """
        return normalize_backup_path(path)

    def get_backup_access(self, password: str = None):
        if self.backup_access is not None:
            try:
                if self.backup_access.is_encrypted:
                    temp_dir = getattr(self.backup_access, "_temp_dir", None)
                    temp_missing = (not temp_dir) or (not os.path.exists(temp_dir))
                    manifest_missing = not os.path.exists(self.backup_access.manifest_db_path)
                    if temp_missing or manifest_missing:
                        self.backup_access = None
                        return self.get_backup_access(password=password)
                if self.backup_access.is_encrypted and not os.path.exists(self.backup_access.manifest_db_path):
                    self.backup_access = None
            except Exception:
                self.backup_access = None
        if self.backup_access is not None:
            return self.backup_access
        if self.is_encrypted:
            if password:
                self.encryption_password = password
            if not self.encryption_password:
                raise ValueError("Encrypted backup requires a password.")
        try:
            from backup_access import BackupAccess, register_backup_access
        except Exception as exc:
            raise RuntimeError("Encrypted backup support is not available.") from exc
        access = BackupAccess(self.path, password=self.encryption_password)
        try:
            log_startup(f"Encrypted manifest db path: {access.manifest_db_path}")
        except Exception:
            pass
        register_backup_access(self.path, access)
        self.backup_access = access
        return access

    def _load_info(self):
        """Load backup metadata from Info.plist"""
        try:
            info_plist = os.path.join(self.path, "Info.plist")
            manifest_db = os.path.join(self.path, "Manifest.db")
            manifest_mbdb = os.path.join(self.path, "Manifest.mbdb")
            manifest_mbdx = os.path.join(self.path, "Manifest.mbdx")

            # Check if backup is valid
            if not os.path.exists(info_plist):
                self.validation_msg = "⚠️ Missing Info.plist"
                self.is_supported = False
                self.unsupported_reason = "Missing Info.plist"
                return

            if not os.path.exists(manifest_db):
                if os.path.exists(manifest_mbdb) or os.path.exists(manifest_mbdx):
                    self.validation_msg = "⚠️ Legacy iTunes backup format (MBDB)"
                    self.is_legacy = True
                    self.unsupported_reason = "Legacy iTunes backup format (MBDB)"
                else:
                    self.validation_msg = "⚠️ Missing Manifest.db"
                    self.unsupported_reason = "Missing Manifest.db"
                self.is_supported = False
                return

            # Load Info.plist
            with open(info_plist, 'rb') as f:
                info = plistlib.load(f)

            self.name = info.get("Device Name", "Unknown Device")
            self.udid = info.get("Target Identifier", "Unknown")
            self.ios_version = info.get("Product Version", "Unknown")
            self.product_type = info.get("Product Type", "Unknown")
            self.device_model = get_device_model(self.product_type)

            # Detect encrypted backups
            try:
                manifest_plist = os.path.join(self.path, "Manifest.plist")
                if os.path.exists(manifest_plist):
                    with open(manifest_plist, "rb") as mf:
                        manifest_data = plistlib.load(mf)
                    self.is_encrypted = bool(manifest_data.get("IsEncrypted", False))
            except Exception:
                self.is_encrypted = False

            # Get last backup date
            last_backup_date = info.get("Last Backup Date")
            if last_backup_date:
                self.last_backup = last_backup_date.strftime("%m/%d/%y")

            # Calculate size (estimate based on sample for speed)
            # For large backups, walking entire tree is slow - sample instead
            try:
                # Sample 16 evenly-distributed buckets for better accuracy
                total_size = 0
                # Evenly distributed across hex range (00-FF): every 16th bucket
                sample_buckets = ['00', '10', '20', '30', '40', '50', '60', '70',
                                '80', '90', 'a0', 'b0', 'c0', 'd0', 'e0', 'f0']

                for bucket in sample_buckets:
                    bucket_path = os.path.join(self.path, bucket)
                    if os.path.exists(bucket_path):
                        for file in os.listdir(bucket_path):
                            try:
                                fp = os.path.join(bucket_path, file)
                                if os.path.isfile(fp):
                                    total_size += os.path.getsize(fp)
                            except:
                                pass

                # Extrapolate to all 256 buckets
                avg_bucket_size = total_size / len(sample_buckets)
                estimated_size = avg_bucket_size * 256

                # Add plist files and Manifest.db
                for fname in ['Info.plist', 'Manifest.plist', 'Status.plist', 'Manifest.db']:
                    fpath = os.path.join(self.path, fname)
                    if os.path.exists(fpath):
                        estimated_size += os.path.getsize(fpath)

                self.size_gb = estimated_size / (1024**3)
            except:
                self.size_gb = 0

            self.is_valid = True
            self.validation_msg = "✅ Valid & Restorable"
            self.is_supported = True
            self.unsupported_reason = ""

        except Exception as e:
            self.validation_msg = f"❌ Error: {str(e)}"
            self.is_supported = False
            self.unsupported_reason = str(e)

    def _extract_wallpaper(self):
        """Extract wallpaper/homescreen image from backup"""
        try:
            import sqlite3
            import hashlib

            access = None
            # Connect to Manifest.db
            if self.is_encrypted:
                if not self.encryption_password:
                    return
                try:
                    access = self.get_backup_access()
                    manifest_db = access.manifest_db_path
                except Exception:
                    return
            else:
                manifest_db = os.path.join(self.path, "Manifest.db")
            if not os.path.exists(manifest_db):
                return

            conn = sqlite3.connect(manifest_db)
            cur = conn.cursor()
            try:
                # Common wallpaper paths in iOS backups
                wallpaper_paths = [
                    "Library/SpringBoard/HomeBackground.jpg",
                    "Library/SpringBoard/LockBackground.jpg",
                    "Library/SpringBoard/HomeBackground.png",
                    "Library/SpringBoard/LockBackground.png",
                    "Library/SpringBoard/HomeBackgroundThumbnail.jpg",
                    "Library/SpringBoard/HomeBackgroundThumbnaildark.jpg",
                    "Library/SpringBoard/LockBackgroundThumbnail.jpg",
                    "Library/SpringBoard/LockBackgroundThumbnaildark.jpg",
                ]

                # Try to find wallpaper in HomeDomain
                for relpath in wallpaper_paths:
                    file_id = hashlib.sha1(f"HomeDomain-{relpath}".encode()).hexdigest()
                    if self.is_encrypted and access:
                        file_path = access.get_file_path("HomeDomain", relpath)
                    else:
                        file_path = os.path.join(self.path, file_id[:2], file_id)
                    if file_path and os.path.exists(file_path):
                        try:
                            self.wallpaper_image = Image.open(file_path)
                            break
                        except Exception:
                            continue

                # Fallback: Try to find any image in SpringBoard directory
                if not self.wallpaper_image:
                    cur.execute(
                        "SELECT fileID, file FROM Files WHERE relativePath LIKE '%SpringBoard%' "
                        "AND (relativePath LIKE '%.jpg' OR relativePath LIKE '%.png') LIMIT 1"
                    )
                    row = cur.fetchone()
                    if row:
                        file_id, file_bplist = row
                        if self.is_encrypted and access:
                            file_path = access.get_file_path_by_id(file_id, file_bplist)
                        else:
                            file_path = os.path.join(self.path, file_id[:2], file_id)
                        if file_path and os.path.exists(file_path):
                            try:
                                self.wallpaper_image = Image.open(file_path)
                            except Exception:
                                pass
            finally:
                conn.close()

        except Exception:
            # Silently fail - wallpaper is nice-to-have
            pass

    def get_category_counts(self, update_callback=None):
        """
        Get entry counts for each database category.

        Args:
            update_callback: Optional callback(side, category, count) for async updates.
                           Called when accurate photo count is ready.
        """
        import sqlite3
        import hashlib

        counts = {
            "photos": 0,
            "sms": 0,
            "contacts": 0,
            "calendar": 0,
            "notes": 0,
            "call_history": 0,
            "voicemail": 0,
            "voice_memos": 0
        }

        if not self.is_valid:
            return counts

        if self.is_encrypted:
            if not self.encryption_password:
                return counts
            try:
                access = self.get_backup_access()
                manifest_db = access.manifest_db_path
            except Exception:
                return counts
        else:
            manifest_db = os.path.join(self.path, "Manifest.db")
        if not os.path.exists(manifest_db):
            return counts

        # Open Manifest.db connection once for file-based counting
        conn_manifest = None
        try:
            conn_manifest = sqlite3.connect(f"file:{manifest_db}?mode=ro", uri=True, timeout=5.0)
        except (sqlite3.OperationalError, sqlite3.DatabaseError):
            # If Manifest.db can't be opened (locked, corrupted, network issue), continue without it
            pass

        try:
            # Helper to find database file
            def find_db_file(domain, relpath):
                if self.is_encrypted:
                    file_path = access.get_file_path(domain, relpath)
                    return file_path if file_path and os.path.exists(file_path) else None
                file_id = hashlib.sha1(f"{domain}-{relpath}".encode()).hexdigest()
                file_path = os.path.join(self.path, file_id[:2], file_id)
                return file_path if os.path.exists(file_path) else None

            # Photos - use PhotosExtractor for hybrid count (includes Photos.sqlite + Manifest.db)
            try:
                photos_path = find_db_file("CameraRollDomain", "Media/PhotoData/Photos.sqlite")
                if photos_path:
                    photo_count = 0
                    conn = None  # Track connection for cleanup

                    # Use PhotosExtractor to get hybrid count (Photos.sqlite + additional files from Manifest.db)
                    # This matches Reincubate's behavior by including Live Photo MOV files, edited versions, etc.
                    try:
                        from extractors.photos_extractor import PhotosExtractor
                        photos_extractor = PhotosExtractor(self.path)
                        photo_count = photos_extractor.get_count()  # Fast estimate for hybrid extraction

                        # Start async validation to get accurate count
                        if update_callback:
                            def on_validated(accurate_count):
                                if accurate_count > 0:
                                    update_callback("photos", accurate_count)

                            photos_extractor.validate_count_async(callback=on_validated)
                    except Exception as e:
                        # Fallback to direct database query if PhotosExtractor fails
                        conn = sqlite3.connect(photos_path)
                        cur = conn.cursor()

                        # iOS 13+: Core Data schema with ZASSET table
                        try:
                            cur.execute("SELECT COUNT(*) FROM ZASSET WHERE ZTRASHEDSTATE = 0 OR ZTRASHEDSTATE IS NULL")
                            photo_count = cur.fetchone()[0]
                        except sqlite3.OperationalError:
                            # ZASSET table doesn't exist, try legacy schema
                            pass

                        # iOS 10 and earlier: Legacy schema with ZGENERICASSET or similar tables
                        if photo_count == 0:
                            try:
                                # Try ZGENERICASSET (common in iOS 10)
                                cur.execute("SELECT COUNT(*) FROM ZGENERICASSET")
                                photo_count = cur.fetchone()[0]
                            except sqlite3.OperationalError:
                                pass

                        # Alternative: Try ZMOMENT (photo collections/moments)
                        if photo_count == 0:
                            try:
                                cur.execute("SELECT COUNT(*) FROM ZMOMENT")
                                photo_count = cur.fetchone()[0]
                            except sqlite3.OperationalError:
                                pass

                        # Last resort: Try to detect any table with ASSET in name
                        if photo_count == 0:
                            try:
                                cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE '%ASSET%'")
                                asset_tables = [row[0] for row in cur.fetchall()]
                                if asset_tables:
                                    # Use first asset table found
                                    cur.execute(f"SELECT COUNT(*) FROM {asset_tables[0]}")
                                    photo_count = cur.fetchone()[0]
                            except:
                                pass

                    counts["photos"] = photo_count
                    if conn:
                        conn.close()
            except:
                pass

            # SMS
            try:
                sms_path = find_db_file("HomeDomain", "Library/SMS/sms.db")
                if sms_path:
                    conn = sqlite3.connect(sms_path)
                    cur = conn.cursor()
                    cur.execute("SELECT COUNT(*) FROM message")
                    counts["sms"] = cur.fetchone()[0]
                    conn.close()
            except:
                pass

            # Contacts
            try:
                contacts_path = find_db_file("HomeDomain", "Library/AddressBook/AddressBook.sqlitedb")
                if contacts_path:
                    conn = sqlite3.connect(contacts_path)
                    cur = conn.cursor()
                    cur.execute("SELECT COUNT(*) FROM ABPerson")
                    counts["contacts"] = cur.fetchone()[0]
                    conn.close()
            except:
                pass

            # Calendar (only count events, not reminders)
            try:
                calendar_path = find_db_file("HomeDomain", "Library/Calendar/Calendar.sqlitedb")
                if not calendar_path:
                    # Try alternate extension
                    calendar_path = find_db_file("HomeDomain", "Library/Calendar/Calendar.sqlite")
                if calendar_path:
                    conn = sqlite3.connect(calendar_path)
                    cur = conn.cursor()
                    cur.execute("SELECT COUNT(*) FROM CalendarItem WHERE entity_type = 2")
                    counts["calendar"] = cur.fetchone()[0]
                    conn.close()
            except:
                pass

            # Notes - count both modern NoteStore (iCloud) and legacy notes.sqlite
            try:
                note_total = 0

                # Modern NoteStore
                notestore_path = find_db_file("AppDomainGroup-group.com.apple.notes", "NoteStore.sqlite")
                if notestore_path:
                    try:
                        conn = sqlite3.connect(notestore_path)
                        cur = conn.cursor()
                        # Count actual note bodies to avoid folder/account rows
                        cur.execute("SELECT COUNT(*) FROM ZICNOTEDATA")
                        note_total += cur.fetchone()[0]
                    except Exception:
                        pass
                    finally:
                        try:
                            conn.close()
                        except Exception:
                            pass

                # Legacy/HomeDomain notes.sqlite (local/IMAP)
                legacy_notes = find_db_file("HomeDomain", "Library/Notes/notes.sqlite")
                if legacy_notes:
                    try:
                        conn = sqlite3.connect(legacy_notes)
                        cur = conn.cursor()
                        cur.execute("SELECT COUNT(*) FROM ZNOTE")
                        note_total += cur.fetchone()[0]
                    except Exception:
                        pass
                    finally:
                        try:
                            conn.close()
                        except Exception:
                            pass

                counts["notes"] = note_total
            except Exception:
                pass

            # Call History - try CallHistory.storedata first (iOS 8+), then sms.db (older iOS)
            try:
                call_count = 0

                # Try CallHistory.storedata first (modern iOS)
                call_db_path = find_db_file("HomeDomain", "Library/CallHistoryDB/CallHistory.storedata")
                if call_db_path:
                    try:
                        conn = sqlite3.connect(call_db_path)
                        cur = conn.cursor()
                        cur.execute("SELECT COUNT(*) FROM ZCALLRECORD")
                        call_count = cur.fetchone()[0]
                        conn.close()
                    except:
                        pass

                # Fallback to sms.db (older iOS)
                if call_count == 0:
                    sms_path = find_db_file("HomeDomain", "Library/SMS/sms.db")
                    if sms_path:
                        conn = sqlite3.connect(sms_path)
                        cur = conn.cursor()

                        # Check if 'call' table exists first
                        try:
                            cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='call'")
                            if cur.fetchone():
                                cur.execute("SELECT COUNT(*) FROM call")
                                call_count = cur.fetchone()[0]
                        except sqlite3.OperationalError:
                            pass

                        # Alternative: Try call_history table (some iOS versions)
                        if call_count == 0:
                            try:
                                cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='call_history'")
                                if cur.fetchone():
                                    cur.execute("SELECT COUNT(*) FROM call_history")
                                    call_count = cur.fetchone()[0]
                            except sqlite3.OperationalError:
                                pass

                        conn.close()

                counts["call_history"] = call_count
            except:
                pass

            # Voicemail - count actual audio files for accuracy (database may have incomplete entries)
            try:
                if conn_manifest:
                    cur_manifest = conn_manifest.cursor()
                    # Count .amr files in Voicemail directory
                    cur_manifest.execute("SELECT COUNT(*) FROM Files WHERE domain='HomeDomain' AND relativePath LIKE 'Library/Voicemail/%.amr'")
                    counts["voicemail"] = cur_manifest.fetchone()[0]
                else:
                    # Manifest not available, fallback to database count
                    raise Exception("Manifest not available")
            except:
                # Fallback to database count if file counting fails
                try:
                    voicemail_path = find_db_file("HomeDomain", "Library/Voicemail/voicemail.db")
                    if voicemail_path:
                        conn = sqlite3.connect(voicemail_path)
                        cur = conn.cursor()
                        cur.execute("SELECT COUNT(*) FROM voicemail")
                        counts["voicemail"] = cur.fetchone()[0]
                        conn.close()
                except:
                    pass

            # Voice Memos - use VoiceMemosExtractor for accurate count across all iOS versions
            try:
                from extractors.voice_memos_extractor import VoiceMemosExtractor
                voice_memos_extractor = VoiceMemosExtractor(self.path)
                counts["voice_memos"] = voice_memos_extractor.get_count()
            except:
                # If extractor fails (database not found), count is 0
                pass

        except Exception as e:
            # If anything fails, return zeros
            pass
        finally:
            # Ensure Manifest.db connection is closed
            if conn_manifest:
                try:
                    conn_manifest.close()
                except:
                    pass

        return counts

    def get_summary(self):
        """Get formatted summary string"""
        return f"{self.name} | iOS {self.ios_version} | {self.size_gb:.1f}GB | {self.last_backup}"

    def calculate_actual_size(self, callback=None):
        """Calculate actual backup size in background thread.

        Args:
            callback: Optional function(backup, size_gb) called when complete
        """
        import threading

        # Cancel any existing calculation
        if self.size_validation_in_progress and self.size_validation_thread:
            self.size_validation_in_progress = False

        def calculate():
            try:
                self.size_validation_in_progress = True
                total_size = 0

                # Walk entire directory
                for root, dirs, files in os.walk(self.path):
                    # Check if cancelled
                    if not self.size_validation_in_progress:
                        return  # Exit early

                    for file in files:
                        try:
                            filepath = os.path.join(root, file)
                            if os.path.isfile(filepath):  # Skip symlinks
                                total_size += os.path.getsize(filepath)
                        except (OSError, PermissionError):
                            pass  # Skip files we can't read

                size_gb = total_size / (1024**3)
                self.size_gb_validated = size_gb

                if callback and self.size_validation_in_progress:
                    callback(self, size_gb)

            except Exception as e:
                print(f"[DEBUG] Size validation failed for {self.name}: {e}")
                # Keep original estimate
            finally:
                self.size_validation_in_progress = False

        self.size_validation_thread = threading.Thread(target=calculate, daemon=True)
        self.size_validation_thread.start()

    def cancel_size_validation(self):
        """Cancel ongoing size validation."""
        if self.size_validation_in_progress:
            self.size_validation_in_progress = False
            # Thread will exit on next check

    def get_size_display_text(self):
        """Get formatted size text for display."""
        if self.size_gb_validated is not None:
            return f"{self.size_gb_validated:.1f} GB (verified)"
        elif self.size_validation_in_progress:
            return f"~{self.size_gb:.1f} GB (estimated, validating...)"
        else:
            return f"~{self.size_gb:.1f} GB (estimated)"


class iOSToggleSwitch(tk.Canvas):
    """iOS-style toggle switch widget"""

    def __init__(self, parent, variable, command=None, **kwargs):
        """
        Initialize toggle switch

        Args:
            parent: Parent widget
            variable: tk.IntVar to bind to (1=ON, 0=OFF)
            command: Optional callback when toggled
        """
        # Size constants
        self.width = 28
        self.height = 14
        self.padding = 1

        super().__init__(parent, width=self.width, height=self.height,
                        highlightthickness=0, **kwargs)

        self.variable = variable
        self.command = command
        self.is_enabled = True

        # Colors
        self.color_on = "#27ae60"
        self.color_off = "#bdc3c7"
        self.color_disabled = "#ecf0f1"
        self.knob_color = "white"

        # Draw initial state
        self._draw()

        # Bind click event
        self.bind("<Button-1>", self._on_click)

        # Watch variable changes
        self.variable.trace_add("write", lambda *args: self._draw())

    def _draw(self):
        """Redraw the toggle switch"""
        self.delete("all")

        # Determine state
        is_on = bool(self.variable.get())

        # Choose colors
        if not self.is_enabled:
            bg_color = self.color_disabled
            knob_pos = self.width - self.height + self.padding if is_on else self.padding
        else:
            bg_color = self.color_on if is_on else self.color_off
            knob_pos = self.width - self.height + self.padding if is_on else self.padding

        # Draw background (rounded rectangle)
        radius = self.height // 2
        self.create_oval(0, 0, self.height, self.height, fill=bg_color, outline="")
        self.create_rectangle(radius, 0, self.width - radius, self.height,
                            fill=bg_color, outline="")
        self.create_oval(self.width - self.height, 0, self.width, self.height,
                        fill=bg_color, outline="")

        # Draw knob (circle)
        knob_radius = (self.height - 2 * self.padding) // 2
        knob_x = knob_pos + knob_radius
        knob_y = self.height // 2

        # Draw knob with subtle gray border for depth
        self.create_oval(knob_x - knob_radius, knob_y - knob_radius,
                        knob_x + knob_radius, knob_y + knob_radius,
                        fill=self.knob_color, outline="#d0d0d0", width=1)

    def _on_click(self, event):
        """Handle click event"""
        if self.is_enabled:
            # Toggle value
            current = self.variable.get()
            self.variable.set(0 if current else 1)

            # Call command if provided
            if self.command:
                self.command()

    def configure_state(self, state):
        """Enable or disable the toggle"""
        self.is_enabled = (state != tk.DISABLED)
        if not self.is_enabled:
            self.config(cursor="")
        else:
            self.config(cursor="hand2")
        self._draw()

    def get_state(self):
        """Get current state (for compatibility with button interface)"""
        return tk.NORMAL if self.is_enabled else tk.DISABLED


class BackupMergerGUI:
    def __init__(self, root):
        self.root = root
        self._startup_timing = os.environ.get("IBM_STARTUP_TIMING") == "1"
        if self._startup_timing:
            self._startup_t0 = time.perf_counter()
            def _stamp(msg):
                elapsed = time.perf_counter() - self._startup_t0
                print(f"[STARTUP_TIMING] {msg}: {elapsed:.3f}s")
            self._startup_stamp = _stamp
        else:
            self._startup_stamp = lambda *_: None
        self.root.title(get_build_title())
        self.root.geometry("820x973")  # Width for backup toggle (40) + content (740) + device toggle (40)
        self.root.minsize(810, 800)
        self.root.maxsize(1620, 850)  # Allow for both panels expanded
        self.root.resizable(False, False)  # Lock width and height, no resizing

        # Initialize theme manager with root window for uniform appearance across platforms
        self.theme = get_theme(root)

        # State
        self.left_backup = None
        self.right_backup = None
        self.left_ios_version = None  # iOS version of left backup
        self.right_ios_version = None  # iOS version of right backup
        self.output_path = tk.StringVar(value="C:\\Backups\\Modified")
        self.modify_running = False
        self.process = None
        self.output_queue = queue.Queue()
        self.merge_start_time = None  # Track when merge starts for elapsed time/ETA
        self.log_window = None  # Reference to open log window (for real-time updates)
        self.log_text_widget = None  # Reference to log text widget
        self.log_update_job = None  # Reference to scheduled update job
        self.log_last_position = 0  # Track last position in log buffer for incremental updates
        self.detected_backups = []  # Auto-detected backups
        self._tracked_paths = set()  # normalized UDID paths that user added
        self._hidden_paths = set()   # normalized UDID paths to suppress

        # Device panel state (initialize BEFORE loading tracked backups)
        self.config_file = os.path.join(os.path.expanduser("~"), ".backup_merger_config.json")
        self.app_created_backups_file = os.path.join(os.path.expanduser("~"), ".backup_merger_app_created.json")
        self.modified_backups_file = os.path.join(os.path.expanduser("~"), ".backup_merger_modified.json")
        self.size_cache_file = os.path.join(os.path.expanduser("~"), ".backup_merger_size_cache.json")
        self.app_created_backup_paths = self._load_app_created_backups()  # Set of backup paths created with app
        self.modified_backup_paths = self._load_modified_backups()  # Set of backup paths modified with app

        # Load hidden backups (tracked backups are deferred until after UI shows)
        self._load_hidden_backups()
        self._pulse_startup_splash()
        self._startup_stamp("Loaded hidden backups")

        # Load panel state and manual toggle tracking
        panel_state = self._load_panel_state()
        self.device_panel_visible = panel_state['visible']
        self.backup_panel_visible = panel_state['backup_visible']
        self.user_has_manually_toggled = panel_state['manually_toggled']
        self._pulse_startup_splash()
        self._startup_stamp("Loaded panel state")

        # Track if user manually toggled each panel during this session
        self.device_panel_manually_toggled = False
        self.backup_panel_manually_toggled = False
        self.dpi_aware_enabled = panel_state['dpi_aware_enabled']
        self.dpi_aware_var = tk.BooleanVar(value=self.dpi_aware_enabled)

        # Check if device is connected at startup (quick synchronous check)
        # If device is connected, always start with panels expanded
        self.device_detected_at_startup = False
        # Defer device detection to background thread (avoid blocking startup)
        self._startup_stamp("Device detection check")

        self.has_connected_device = False
        self.current_device = None
        self.restore_target = tk.StringVar(value="browse")  # modified, left, right, or browse (default to browse)
        self.modified_backup_path = None  # Path to modified backup (set after modification completes)
        self.custom_restore_path = None  # Path from browse option

        # Device monitoring state
        self.monitoring_devices = True  # Flag to control monitoring thread
        self.device_monitor_thread = None
        self.last_detected_udid = None  # Track current device to detect disconnections
        self.cached_device_data = None  # Cache wallpaper/icons to avoid redundant fetches
        self.current_device_info = None  # NEW: unified snapshot for storage/ios validators

        # Device backup state
        self.backup_in_progress = False
        self.backup_cancelled = False
        self.current_device_lockdown = None

        # Device restore state
        self.restore_in_progress = False
        self.restore_cancelled = False
        self.restore_dialog = None

        # Category selection - Yes/No buttons for left and right backups
        # Default: All categories default to Yes/Yes (include from both) except Settings
        # Settings defaults to No/Yes (only from right backup)

        # Photos & Videos
        self.photos_left = tk.BooleanVar(value=True)
        self.photos_right = tk.BooleanVar(value=True)

        # SMS
        self.sms_left = tk.BooleanVar(value=True)
        self.sms_right = tk.BooleanVar(value=True)

        # Contacts
        self.contacts_left = tk.BooleanVar(value=True)
        self.contacts_right = tk.BooleanVar(value=True)

        # Calendar
        self.calendar_left = tk.BooleanVar(value=True)
        self.calendar_right = tk.BooleanVar(value=True)

        # Notes
        self.notes_left = tk.BooleanVar(value=True)
        self.notes_right = tk.BooleanVar(value=True)

        # Call History
        self.call_history_left = tk.BooleanVar(value=True)
        self.call_history_right = tk.BooleanVar(value=True)

        # Voicemail
        self.voicemail_left = tk.BooleanVar(value=True)
        self.voicemail_right = tk.BooleanVar(value=True)

        # Voice Memos
        self.voice_memos_left = tk.BooleanVar(value=True)
        self.voice_memos_right = tk.BooleanVar(value=True)

        # Settings (mutual exclusion: only one side can be Yes)
        self.settings_left = tk.BooleanVar(value=False)
        self.settings_right = tk.BooleanVar(value=True)

        # Advanced options
        self.prefer_backup = tk.StringVar(value="left")
        self.new_device = tk.StringVar(value="right")
        
        self._include_app_created_in_scan = True  # default on normal runs

        self._create_ui()
        self._startup_stamp("UI created")

        # If device was detected at startup, show both panels immediately
        if self.device_panel_visible:
            self._show_device_panel()
            print(f"[STARTUP] Showing device panel (device detected at startup)")
        if self.backup_panel_visible:
            self._show_backup_panel()
            print(f"[STARTUP] Showing backup panel (device detected at startup)")
        self._startup_stamp("Panels shown")

        # Start output monitor
        self.root.after(100, self._check_output_queue)

        # Auto-detect backups in background
        self.root.after(500, self._auto_detect_backups)
        # Load tracked backups after UI is visible
        self.root.after(600, self._load_tracked_backups)

        # Start device monitoring if available
        ensure_pymobiledevice3_loaded()
        if PYMOBILEDEVICE3_AVAILABLE:
            # Show loading state if device was detected at startup
            if self.device_detected_at_startup:
                self._show_device_loading_state()

            # Initial device check in background (non-blocking)
            self.root.after(100, self._check_for_ios_device_async)
            # Start background monitoring thread
            self._start_device_monitoring()

        # Save panel state on close
        self.root.protocol("WM_DELETE_WINDOW", self._on_closing)

    def _pulse_startup_splash(self):
        pulse = getattr(self.root, "_startup_splash_pulse", None)
        if pulse:
            try:
                pulse()
            except Exception:
                pass
        
    def _load_hidden_backups(self):
        import json, os
        self._hidden_paths = set()
        try:
            p = self._hidden_db_path()
            if os.path.exists(p):
                with open(p, "r", encoding="utf-8") as f:
                    items = json.load(f) or []
                    self._hidden_paths = { self._normalize_udid_path(x) for x in items }
        except Exception as e:
            print(f"[DEBUG] _load_hidden_backups error: {e}")

    def _save_hidden_backups(self):
        import json
        try:
            with open(self._hidden_db_path(), "w", encoding="utf-8") as f:
                json.dump(sorted(self._hidden_paths), f, indent=2)
        except Exception as e:
            print(f"[DEBUG] _save_hidden_backups error: {e}")

    def _is_hidden_backup(self, path: str) -> bool:
        return self._normalize_udid_path(path) in self._hidden_paths

    def _load_panel_state(self):
        """Load panel visibility state and manual toggle tracking from config file"""
        config = _read_app_config(self.config_file)
        return {
            'visible': config.get('device_panel_visible', False),
            'backup_visible': config.get('backup_panel_visible', False),
            'manually_toggled': config.get('user_has_manually_toggled', False),
            'dpi_aware_enabled': config.get('dpi_aware_enabled', False)
        }

    def _save_panel_state(self):
        """Save panel visibility state and manual toggle tracking to config file"""
        _write_app_config(self.config_file, {
            'device_panel_visible': self.device_panel_visible,
            'backup_panel_visible': self.backup_panel_visible,
            'user_has_manually_toggled': self.user_has_manually_toggled
        })

    def _load_app_created_backups(self):
        """Load list of app-created backup paths from config file"""
        try:
            if os.path.exists(self.app_created_backups_file):
                with open(self.app_created_backups_file, 'r') as f:
                    data = json.load(f)
                    # Return as set for fast lookup
                    return set(data.get('backup_paths', []))
        except Exception as e:
            print(f"[DEBUG] Failed to load app-created backups list: {e}")
        return set()  # Default to empty set

    def _save_app_created_backups(self):
        """Save list of app-created backup paths to config file"""
        try:
            config = {'backup_paths': list(self.app_created_backup_paths)}
            with open(self.app_created_backups_file, 'w') as f:
                json.dump(config, f, indent=2)
            print(f"[DEBUG] Saved app-created backups list: {len(self.app_created_backup_paths)} entries")
        except Exception as e:
            print(f"[DEBUG] Failed to save app-created backups list: {e}")

    def _load_modified_backups(self):
        """Load list of modified backup paths from config file"""
        try:
            if os.path.exists(self.modified_backups_file):
                with open(self.modified_backups_file, 'r') as f:
                    data = json.load(f)
                    # Return as set for fast lookup
                    return set(data.get('backup_paths', []))
        except Exception as e:
            print(f"[DEBUG] Failed to load modified backups list: {e}")
        return set()  # Default to empty set

    def _save_modified_backups(self):
        """Save list of modified backup paths to config file"""
        try:
            config = {'backup_paths': list(self.modified_backup_paths)}
            with open(self.modified_backups_file, 'w') as f:
                json.dump(config, f, indent=2)
            print(f"[DEBUG] Saved modified backups list: {len(self.modified_backup_paths)} entries")
        except Exception as e:
            print(f"[DEBUG] Failed to save modified backups list: {e}")

    def _load_size_cache(self):
        """Load validated backup sizes from cache file"""
        try:
            if os.path.exists(self.size_cache_file):
                with open(self.size_cache_file, 'r') as f:
                    data = json.load(f)
                    return data.get('sizes', {})
        except Exception as e:
            print(f"[DEBUG] Failed to load size cache: {e}")
        return {}

    def _save_size_cache(self, cache_data):
        """Save validated backup sizes to cache file"""
        try:
            config = {'sizes': cache_data}
            with open(self.size_cache_file, 'w') as f:
                json.dump(config, f, indent=2)
            print(f"[DEBUG] Saved size cache: {len(cache_data)} entries")
        except Exception as e:
            print(f"[DEBUG] Failed to save size cache: {e}")

    def _get_cached_size(self, backup_path):
        """Get cached size for a backup path, if valid"""
        try:
            cache = self._load_size_cache()
            if backup_path in cache:
                cached_entry = cache[backup_path]

                # Check if backup folder still exists
                if not os.path.exists(backup_path):
                    print(f"[DEBUG] Cache invalidated for {backup_path} (path no longer exists)")
                    return None

                # Cache is valid - return cached size
                # No mtime check - cache remains valid until manually cleared
                size_gb = cached_entry.get('size_gb')
                if size_gb is not None:
                    print(f"[DEBUG] Using cached size for {backup_path}: {size_gb:.1f} GB")
                    return size_gb
        except Exception as e:
            print(f"[DEBUG] Error reading cached size: {e}")
        return None

    def _save_validated_size(self, backup_path, size_gb):
        """Save a validated size to cache"""
        try:
            cache = self._load_size_cache()

            # Get folder modification time (stored for reference, not used for validation)
            mtime = os.path.getmtime(backup_path) if os.path.exists(backup_path) else None

            cache[backup_path] = {
                'size_gb': size_gb,
                'timestamp': datetime.now().isoformat(),
                'mtime': mtime
            }

            self._save_size_cache(cache)
        except Exception as e:
            print(f"[DEBUG] Failed to save validated size: {e}")

    def _clear_size_cache(self):
        """Clear all cached sizes"""
        try:
            if os.path.exists(self.size_cache_file):
                os.remove(self.size_cache_file)
                print("[DEBUG] Size cache cleared")
                messagebox.showinfo("Cache Cleared", "Cached backup sizes have been cleared.")
            else:
                messagebox.showinfo("Cache Cleared", "No cache file found.")
        except Exception as e:
            print(f"[DEBUG] Failed to clear size cache: {e}")
            messagebox.showerror("Error", f"Failed to clear cache: {e}")

    def _on_closing(self):
        """Handle window close event"""
        # Stop device monitoring thread
        self.monitoring_devices = False
        if self.device_monitor_thread and self.device_monitor_thread.is_alive():
            # Give the thread a moment to exit gracefully
            self.device_monitor_thread.join(timeout=1.0)

        self._save_panel_state()
        self.root.destroy()
        
    def _auto_detect_on_mousewheel(self, event):
        """Mouse wheel scroll for the Auto-Detected canvas."""
        # Windows / macOS: event.delta is ±120 multiples
        try:
            self.auto_detect_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        except Exception:
            pass
        # Update fade visibility while scrolling
        self._auto_detect_update_fade()

    def _auto_detect_update_fade(self):
        """Show the bottom 'more below' hint when not fully scrolled."""
        try:
            first, last = self.auto_detect_canvas.yview()
        except Exception:
            return
        # If content doesn't overflow, hide hint
        if last - first >= 0.999 or last == 1.0 and first == 0.0:
            self.auto_detect_fade.place_forget()
            return
        # If near bottom, hide; otherwise show at bottom center
        if last >= 0.995:
            self.auto_detect_fade.place_forget()
        else:
            # Place just above the canvas bottom, centered
            h = self.auto_detect_canvas.winfo_height()
            w = self.auto_detect_canvas.winfo_width()
            self.auto_detect_fade.place(x=w-100, y=h//2+12, anchor="s")

    def _hidden_db_path(self):
        """File to persist hidden (blocked) backups."""
        import os, sys
        if sys.platform.startswith("win"):
            base = os.environ.get("APPDATA", os.path.expanduser("~"))
        else:
            base = os.path.join(os.path.expanduser("~"), ".local", "share")
        appdir = os.path.join(base, "OntrackiOSBackupManager")
        os.makedirs(appdir, exist_ok=True)
        return os.path.join(appdir, "hidden_backups.json")

    def _normalize_udid_path(self, path: str) -> str:
        """Return the canonical UDID folder for this backup path (handles timestamped parent)."""
        import os, re
        path = os.path.abspath(path)
        # direct UDID folder?
        if os.path.exists(os.path.join(path, "Info.plist")) and os.path.exists(os.path.join(path, "Manifest.db")):
            return path
        # try UDID child under parent
        udid_like = re.compile(r"^[0-9a-fA-F]{40}$")
        try:
            for item in os.listdir(path):
                child = os.path.join(path, item)
                if os.path.isdir(child) and udid_like.match(item):
                    if (os.path.exists(os.path.join(child, "Info.plist"))
                            and os.path.exists(os.path.join(child, "Manifest.db"))):
                        return child
        except Exception:
            pass
        return path  # best effort


    def _create_menu_bar(self):
        """Create menu bar at top of window"""
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)

        # Tools menu
        tools_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Tools", menu=tools_menu)
        tools_menu.add_command(label="⚙️  Advanced Settings", command=self._show_advanced)
        tools_menu.add_command(label="📋  View Log", command=self._view_log)
        tools_menu.add_command(label="🧪  Validate Backup", command=self._validate_backup)
        tools_menu.add_separator()
        tools_menu.add_command(label="Exit", command=self._on_closing)

        # Help menu
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="About", command=self._show_about)
        
    def _menu_add_backup_to_list(self):
        """Browse for a backup folder and add to the Auto-Detected list + persist."""
        from tkinter import filedialog, messagebox
        import os, re

        path = filedialog.askdirectory(title="Select iOS Backup Folder (UDID folder or its timestamped parent)")
        if not path:
            return

        # Normalize to the actual UDID folder (40 hex), even when user picks the timestamped parent
        try:
            udid_like = re.compile(r"^[0-9a-fA-F]{40}$")
            norm = os.path.abspath(path)
            if not (os.path.exists(os.path.join(norm, "Info.plist")) and os.path.exists(os.path.join(norm, "Manifest.db"))):
                # try child UDID under parent/timestamped parent
                found = None
                for item in os.listdir(norm):
                    child = os.path.join(norm, item)
                    if os.path.isdir(child) and udid_like.match(item):
                        if os.path.exists(os.path.join(child, "Info.plist")) and os.path.exists(os.path.join(child, "Manifest.db")):
                            found = child
                            break
                if found:
                    norm = found

            if not (os.path.exists(os.path.join(norm, "Info.plist")) and os.path.exists(os.path.join(norm, "Manifest.db"))):
                messagebox.showerror("Not a valid backup",
                                     "The selected folder does not look like a valid iTunes/iOS backup (Info.plist/Manifest.db missing).")
                return
            self._tracked_paths.add(norm)
            self._save_tracked_backups()
            # Add to detected list (handles de-dup + sorting)
            self._add_backup_to_detected_list(path)
            # Persist
            self._save_tracked_backups()
            # Feedback
            self._log_message(f"[INFO] Added backup to list: {norm}")

        except Exception as e:
            messagebox.showerror("Error adding backup", str(e))

    def _menu_remove_backup_from_backup_list_do(self, listbox, win):
        """Remove selected backup with persistence (tracked removal or hidden block)."""
        from tkinter import messagebox
        try:
            sel = listbox.curselection()
            if not sel:
                return
            idx = sel[0]
            if 0 <= idx < len(self.detected_backups):
                bi = self.detected_backups[idx]
                norm = self._normalize_udid_path(getattr(bi, "path", ""))

                # If it was explicitly tracked by the user, untrack it.
                if norm in self._tracked_paths:
                    self._tracked_paths.remove(norm)
                    self._save_tracked_backups()
                else:
                    # It came from auto-detect: add to hidden so it won't reappear after restart.
                    self._hidden_paths.add(norm)
                    self._save_hidden_backups()

                # Remove from current UI list
                del self.detected_backups[idx]
                self._update_auto_detect_ui()
                self._log_message(f"[INFO] Removed backup from list (persisted): {norm}")
            win.destroy()
        except Exception as e:
            messagebox.showerror("Error removing backup", str(e))
            try:
                win.destroy()
            except Exception:
                pass

    def _menu_remove_backup_from_backup_list_render_label(self, bi):
        """Return the same text used for buttons in auto-detected list, for the remove dialog."""
        # Keep this consistent with your _update_auto_detect_ui() label build
        base = f"{bi.device_model} | {bi.name} |"
        if getattr(bi, "created_with_app", False):
            base += " (Created with iOS Backup Manager)"
        try:
            dt = bi.get_created_timestamp()
            age = self._format_backup_age(dt)
            return f"{base} - {age}"
        except Exception:
            return base

    def _menu_remove_backup_from_backup_list(self):
        """Open a simple picker to remove a backup from the list."""
        import tkinter as tk
        from tkinter import messagebox

        if not getattr(self, "detected_backups", []):
            messagebox.showinfo("Remove backup", "There are no backups in the list.")
            return

        win = tk.Toplevel(self.root)
        win.title("Remove a backup")
        win.geometry("520x280")
        win.transient(self.root)
        win.grab_set()

        tk.Label(win, text="Select a backup to remove:", font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=10, pady=(10, 6))

        frame = tk.Frame(win)
        frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))

        scrollbar = tk.Scrollbar(frame, orient="vertical")
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        listbox = tk.Listbox(frame, height=10)
        listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        listbox.config(yscrollcommand=scrollbar.set)
        scrollbar.config(command=listbox.yview)

        # Populate with labels matching the auto-detected display
        for bi in self.detected_backups:
            listbox.insert(tk.END, self._menu_remove_backup_from_backup_list_render_label(bi))

        btns = tk.Frame(win)
        btns.pack(fill=tk.X, padx=10, pady=(0, 10))

        tk.Button(btns, text="Cancel", command=win.destroy).pack(side=tk.RIGHT, padx=(6, 0))
        tk.Button(btns, text="Remove",
                  command=lambda: self._menu_remove_backup_from_backup_list_do(listbox, win)).pack(side=tk.RIGHT)


    def _show_about(self):
        """Show about dialog"""
        about_dialog = tk.Toplevel(self.root)
        about_dialog.title("About")
        about_dialog.geometry("400x200")
        about_dialog.transient(self.root)
        about_dialog.grab_set()

        frame = ttk.Frame(about_dialog, padding=20)
        frame.pack(fill=tk.BOTH, expand=True)

        ttk.Label(frame, text="iOS Backup Manager", font=("Arial", 14, "bold")).pack(pady=(0, 10))
        ttk.Label(frame, text=get_build_title(), font=("Arial", 10)).pack(pady=(0, 6))
        ttk.Label(frame, text="Merge and modify iTunes/Finder backups", font=("Arial", 10)).pack(pady=(0, 20))
        ttk.Label(frame, text="Created with Claude Code", font=("Arial", 9)).pack(pady=(0, 20))

        ttk.Button(frame, text="Close", command=about_dialog.destroy).pack()

    def _create_ui(self):
        """Create the main UI"""
        # Horizontal container for backup panel + toggle + main content + toggle + device panel
        horizontal_container = ttk.Frame(self.root)
        horizontal_container.pack(fill=tk.BOTH, expand=True)

        # === LEFT SIDE: DEVICE BACKUP PANEL ===
        self.backup_panel = self._create_device_backup_panel(horizontal_container)
        self.backup_panel.pack(side=tk.LEFT, fill=tk.BOTH, expand=False, padx=(0, 5))
        self.backup_panel.pack_forget()  # Initially hidden

        # Backup panel toggle button
        backup_toggle_frame = tk.Frame(horizontal_container, bg=self.theme.get_color('toggle_backup_inactive'), width=35)
        backup_toggle_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 5))
        backup_toggle_frame.pack_propagate(False)
        self.backup_toggle_frame = backup_toggle_frame  # Store reference for later use

        self.backup_toggle_btn = tk.Button(backup_toggle_frame, text="◀\n💾",
                                          bg=self.theme.get_color('toggle_backup_inactive'),
                                          fg=self.theme.get_color('toggle_fg'),
                                          font=("Arial", 10, "bold"),
                                          relief=tk.FLAT, bd=0,
                                          command=self._toggle_backup_panel,
                                          cursor="hand2")
        self.backup_toggle_btn.pack(expand=True, fill=tk.BOTH)

        # === SCROLLABLE MAIN CONTENT ===
        # Create canvas with scrollbar for main content
        canvas_frame = ttk.Frame(horizontal_container, width=740)
        canvas_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=False)
        canvas_frame.pack_propagate(False)

        # Canvas for scrolling
        self.main_canvas = tk.Canvas(canvas_frame, highlightthickness=0)

        # Scrollbar for main canvas (auto-hide when no overflow)
        main_scrollbar = ttk.Scrollbar(canvas_frame, orient="vertical", command=self.main_canvas.yview)

        # Scrollable frame inside canvas
        self.scrollable_frame = ttk.Frame(self.main_canvas, padding=0)

        self.main_canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")

        # Create a bounded yview that prevents scrolling above the top
        original_main_yview = self.main_canvas.yview
        def bounded_main_yview(*args):
            if args[0] == 'moveto':
                # Clamp position to not go below 0 (top of canvas)
                position = max(0.0, float(args[1]))
                return original_main_yview('moveto', position)
            elif args[0] == 'scroll':
                # Get current position
                current_pos = self.main_canvas.yview()[0]
                # Only allow scroll if we're not at top or scrolling down
                if current_pos > 0.0 or int(args[1]) > 0:
                    return original_main_yview(*args)
                # At top and trying to scroll up - do nothing
                return None
            else:
                return original_main_yview(*args)

        self.main_canvas.yview = bounded_main_yview

        # Pack canvas (scrollbar shown only when needed)
        self.main_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self._configure_autohide_scrollbar(self.main_canvas, main_scrollbar, self.scrollable_frame)

        # Bind hover-based mouse wheel scrolling
        self._bind_hover_scroll(self.main_canvas, self.main_canvas)

        # Force scrollable_frame to expand to full canvas width
        def _on_canvas_configure(event):
            self.main_canvas.itemconfig(self.main_canvas.find_withtag("all")[0], width=event.width)
        self.main_canvas.bind("<Configure>", _on_canvas_configure)

        # Store reference
        self.left_column = self.scrollable_frame

        # === MODIFY BACKUP PAGE HEADER ===
        modify_header_frame = tk.Frame(self.scrollable_frame, bg=self.theme.get_color('header_bg'), height=34)
        modify_header_frame.pack(fill=tk.X, pady=(0, 4))
        modify_header_frame.pack_propagate(False)

        modify_header_label = tk.Label(modify_header_frame, text="Work with Backup",
                                       bg=self.theme.get_color('header_bg'),
                                       fg=self.theme.get_color('header_fg'),
                                       font=("Arial", 12, "bold"))
        modify_header_label.pack(side=tk.LEFT, padx=10, pady=4)

        # Status label (will be updated during operations)
        self.modify_status_label = tk.Label(modify_header_frame, text="| Status: Ready",
                                            bg=self.theme.get_color('header_bg'),
                                            fg=self.theme.get_color('text_light'),
                                            font=("Arial", 10))
        self.modify_status_label.pack(side=tk.LEFT, padx=5, pady=4)

        # Auto-detected backups section
        self._create_auto_detect_section(self.scrollable_frame)

        # Separator
        ttk.Separator(self.scrollable_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=1)

        # Merge panel
        self._create_modify_panel(self.scrollable_frame)

        # Separator
        ttk.Separator(self.scrollable_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=2)

        # Data category matrix
        self._create_category_matrix(self.scrollable_frame)

        # Separator
        ttk.Separator(self.scrollable_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=2)

        # Progress & Control buttons (merged)
        self._create_output_section(self.scrollable_frame)

        # === RIGHT SIDE: DEVICE PANEL ===
        # Device panel toggle button
        device_toggle_frame = tk.Frame(horizontal_container, bg=self.theme.get_color('toggle_device_inactive'), width=35)
        device_toggle_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(5, 0))
        device_toggle_frame.pack_propagate(False)
        self.device_toggle_frame = device_toggle_frame  # Store reference

        self.toggle_btn = tk.Button(device_toggle_frame, text="📱\n▶",
                                    bg=self.theme.get_color('toggle_device_inactive'),
                                    fg=self.theme.get_color('toggle_fg'),
                                    font=("Arial", 10, "bold"),
                                    relief=tk.FLAT, bd=0,
                                    command=self._toggle_device_panel,
                                    cursor="hand2")
        self.toggle_btn.pack(expand=True, fill=tk.BOTH)

        # Full-height device panel
        self.device_panel = self._create_device_panel(horizontal_container)
        self.device_panel.pack(side=tk.LEFT, fill=tk.BOTH, expand=False, padx=(5, 0))

        # Apply initial state
        if self.device_panel_visible:
            # Visible on start
            self.device_panel.pack(
                side=tk.LEFT, fill=tk.BOTH, expand=False, padx=(5, 0),
                after=self.device_toggle_frame
            )
            self.toggle_btn.config(text="◀", bg=self.theme.get_color('toggle_device_active'))
        else:
            # Not visible on start: don't pack at all yet
            # (no pack_forget needed if it hasn't been packed)
            self.toggle_btn.config(text="📱\n▶", bg=self.theme.get_color('toggle_device_inactive'))

        # Debug: Show initial pack order
        print(f"\n[DEBUG _create_ui] INITIAL STATE:")
        print(f"  device_visible={self.device_panel_visible}, backup_visible={self.backup_panel_visible}")
        print(f"  Pack slaves: {[str(w).split('.')[-1] for w in horizontal_container.pack_slaves()]}\n")


    def _tracked_db_path(self):
        """Return a path for the tracked backups JSON (user profile safe)."""
        import os, sys
        # Windows Roaming; macOS/Linux fallback: ~/.local/share
        if sys.platform.startswith("win"):
            base = os.environ.get("APPDATA", os.path.expanduser("~"))
        else:
            base = os.path.join(os.path.expanduser("~"), ".local", "share")
        appdir = os.path.join(base, "OntrackiOSBackupManager")
        os.makedirs(appdir, exist_ok=True)
        return os.path.join(appdir, "tracked_backups.json")

    def _load_tracked_backups(self):
        import json, os
        self._tracked_paths = set()
        try:
            p = self._tracked_db_path()
            if os.path.exists(p):
                with open(p, "r", encoding="utf-8") as f:
                    items = json.load(f) or []
                    self._tracked_paths = { self._normalize_udid_path(x) for x in items }
            # Populate list from tracked (de-dup logic will handle collisions)
            # Use defer_save=True during bulk loading to avoid saving after each backup
            # TODO: PERFORMANCE IMPROVEMENT - Background/Async Backup Validation
            # Currently, backup validation happens synchronously during startup, blocking the UI
            # and causing slow initial loads when many backups are tracked (especially network paths).
            # Future improvements:
            #   - Perform backup validation in background thread/async
            #   - Show UI immediately with "validating..." status for each backup
            #   - Cache validation results with file modification timestamps
            #   - Lazy load backup metadata (only validate when user interacts)
            # This would provide instant startup and non-blocking UI updates.
            def load_tracked_in_background(paths):
                for path in paths:
                    try:
                        backup = BackupInfo(path, created_with_app=True, modified_with_app=False)
                    except Exception as e:
                        print(f"[DEBUG] Failed to load tracked backup {path}: {e}")
                        continue
                    self.root.after(0, lambda b=backup: self._add_backup_info_to_detected_list(b, defer_save=True))

                def finalize():
                    self._save_app_created_backups()
                    self._save_modified_backups()
                    self._update_auto_detect_ui()
                    self._startup_stamp("Loaded tracked backups")

                self.root.after(0, finalize)

            thread = threading.Thread(target=load_tracked_in_background, args=(sorted(self._tracked_paths),), daemon=True)
            thread.start()
        except Exception as e:
            print(f"[DEBUG] _load_tracked_backups error: {e}")

    def _save_tracked_backups(self):
        import json
        try:
            with open(self._tracked_db_path(), "w", encoding="utf-8") as f:
                json.dump(sorted(self._tracked_paths), f, indent=2)
        except Exception as e:
            print(f"[DEBUG] _save_tracked_backups error: {e}")

    def _is_hidden_backup(self, path: str) -> bool:
        return self._normalize_udid_path(path) in self._hidden_paths
    
    #Helpful to determine time since the backup took place
    def _format_backup_age(self, dt):
        """Return 'X days Y hours Z minutes ago' using consistent tz math."""
        from datetime import datetime, timezone
        if dt is None:
            return "Unknown age"
        # Ensure dt is tz-aware (UTC) to avoid negative deltas
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        now = datetime.now(dt.tzinfo)  # same tz as dt
        delta = now - dt
        total_seconds = max(int(delta.total_seconds()), 0)  # clamp small negatives
        total_minutes = total_seconds // 60
        days, rem_min = divmod(total_minutes, 1440)
        hours, minutes = divmod(rem_min, 60)
        parts = []
        if days: parts.append(f"{days} day{'s' if days != 1 else ''}")
        if hours: parts.append(f"{hours} hour{'s' if hours != 1 else ''}")
        if minutes or not parts: parts.append(f"{minutes} minute{'s' if minutes != 1 else ''}")
        return " ".join(parts) + " ago"

    def _open_backup_folder(self, path):
        """Open the backup folder in the OS file manager."""
        # Ensure we open the actual UDID folder (not the timestamp parent)
        try:
            udid_path = path
            if not os.path.exists(udid_path):
                return
            FileManager.open_folder(udid_path)
        except Exception as e:
            print(f"[DEBUG] Failed to open folder: {e}")


    def _bind_hover_scroll(self, canvas, scrollable_widget):
        """
        Bind mouse wheel to canvas only when hovering over the scrollable area.
        This prevents the mouse wheel from scrolling multiple panels simultaneously.

        Args:
            canvas: The canvas widget to scroll
            scrollable_widget: The widget that should trigger scrolling when hovered (usually the canvas itself)
        """
        def on_enter(event):
            """Bind mousewheel when mouse enters the scrollable area"""
            def on_scroll(e):
                canvas.yview_scroll(int(-1*(e.delta/120)), "units")
            canvas.bind_all("<MouseWheel>", on_scroll)
            # Store the binding so we can remove it later
            canvas._scroll_binding = on_scroll

        def on_leave(event):
            """Unbind mousewheel when mouse leaves the scrollable area"""
            if hasattr(canvas, '_scroll_binding'):
                try:
                    canvas.unbind_all("<MouseWheel>")
                except:
                    pass

        # Bind enter/leave events to the scrollable widget
        scrollable_widget.bind("<Enter>", on_enter)
        scrollable_widget.bind("<Leave>", on_leave)

    def _configure_autohide_scrollbar(self, canvas, scrollbar, content_frame, slack: int = 12):
        """Show scrollbar only when content exceeds canvas height."""
        canvas.configure(yscrollcommand=None)

        def _update():
            canvas.update_idletasks()
            canvas_height = canvas.winfo_height()
            if canvas_height <= 1:
                return
            content_height = content_frame.winfo_height()
            if content_height <= canvas_height + slack:
                if scrollbar.winfo_ismapped():
                    scrollbar.pack_forget()
                canvas.configure(scrollregion=(0, 0, canvas.winfo_width(), canvas_height))
                canvas.yview_moveto(0)
                canvas.configure(yscrollcommand=None)
            else:
                if not scrollbar.winfo_ismapped():
                    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
                canvas.configure(yscrollcommand=scrollbar.set)
                bbox = canvas.bbox("all")
                if bbox:
                    canvas.configure(scrollregion=(0, 0, bbox[2], bbox[3]))

        def _schedule(_event=None):
            canvas.after_idle(_update)

        content_frame.bind("<Configure>", _schedule)
        canvas.bind("<Configure>", _schedule)
        scrollbar.pack_forget()
        canvas.after_idle(_update)

    def _create_auto_detect_section(self, parent):
        """Create auto-detected backups section"""
        # Build the labelframe without text, and attach a custom labelwidget
        frame = ttk.LabelFrame(parent, padding=2)  # no 'text=' here
        frame.pack(fill=tk.X)

        # --- Header labelwidget: title left, hamburger right ---
        header = tk.Frame(frame)
        # Title
        title_lbl = ttk.Label(header, text="🔍 Auto-Detected Backups", font=("Arial", 10, "bold"))
        title_lbl.pack(side=tk.LEFT, padx=(2, 6))

        # Hamburger
        auto_menu_btn = ttk.Menubutton(header, text="☰")
        auto_menu = tk.Menu(auto_menu_btn, tearoff=0)
        auto_menu.add_command(label="Add a backup to backup list",
                              command=self._menu_add_backup_to_list)
        auto_menu.add_command(label="Remove a backup from backup list",
                              command=self._menu_remove_backup_from_backup_list)
        auto_menu_btn["menu"] = auto_menu
        auto_menu.add_separator()
        auto_menu.add_command(
            label="Reset Auto-Detected backups",
            command=self._menu_reset_auto_detected_backups
        )
        auto_menu.add_command(
            label="Clear Cached Settings",
            command=self._clear_size_cache
        )
        auto_menu_btn.pack(side=tk.RIGHT)

        # Attach the header as the labelwidget (puts both in the LF's top bar)
        frame.configure(labelwidget=header)
        # --- end header ---

        # (Keep your existing scrollable container code below — or the non-scroll version if you haven’t patched it yet)

        # If you already implemented the scrollable canvas from earlier, keep that here:
        # Canvas + scrollbar + inner container + fade hint etc.
        # Otherwise leave your original container:
        # self.auto_detect_container = tk.Frame(frame)
        # self.auto_detect_container.pack(fill=tk.X)

        # Example: if you already use the scrollable version, place it here:
        try:
            # Scrollable version (from our previous patch)
            self.auto_detect_canvas = tk.Canvas(frame, highlightthickness=0, height=56)
            self.auto_detect_canvas.pack(side=tk.LEFT, fill=tk.X, expand=True)

            self.auto_detect_scroll = ttk.Scrollbar(frame, orient="vertical",
                                                    command=self.auto_detect_canvas.yview)
            self.auto_detect_scroll.pack(side=tk.RIGHT, fill=tk.Y)
            self.auto_detect_canvas.configure(yscrollcommand=self.auto_detect_scroll.set)

            self.auto_detect_container = tk.Frame(self.auto_detect_canvas)
            self._auto_detect_window = self.auto_detect_canvas.create_window(
                (0, 0), window=self.auto_detect_container, anchor="nw"
            )

            def _auto_detect_on_configure(event):
                self.auto_detect_canvas.configure(scrollregion=self.auto_detect_canvas.bbox("all"))
                canvas_w = self.auto_detect_canvas.winfo_width()
                self.auto_detect_canvas.itemconfigure(self._auto_detect_window, width=canvas_w)
                self._auto_detect_update_fade()

            self.auto_detect_container.bind("<Configure>", _auto_detect_on_configure)

            def _wheel_bind(event):
                self.auto_detect_canvas.bind_all("<MouseWheel>", self._auto_detect_on_mousewheel)
            def _wheel_unbind(event):
                self.auto_detect_canvas.unbind_all("<MouseWheel>")

            self.auto_detect_canvas.bind("<Enter>", _wheel_bind)
            self.auto_detect_canvas.bind("<Leave>", _wheel_unbind)
            
            # Enable drag-and-drop on the Auto-Detected Backups area
            if DND_AVAILABLE:
                try:
                    self.auto_detect_canvas.drop_target_register(DND_FILES)
                    self.auto_detect_canvas.dnd_bind("<<Drop>>", self._handle_auto_detect_drop)
                except Exception as e:
                    print(f"[DEBUG] Failed to enable DnD on auto-detected canvas: {e}")


            self.auto_detect_fade = tk.Label(
                self.auto_detect_canvas,
                text="▼ Scroll to show more backups..",
                fg="#888",
                bg=self.root.cget('bg'),
            )
            self.auto_detect_fade.place_forget()

            # Initial loading message
            self.auto_detect_label = tk.Label(self.auto_detect_container,
                                              text="⏳ Scanning for backups...",
                                              fg="gray", font=("Arial", 8, "italic"))
            self.auto_detect_label.pack()
        except Exception:
            # Fallback to simple container if scrollable creation fails
            self.auto_detect_container = tk.Frame(frame)
            self.auto_detect_container.pack(fill=tk.X)
            self.auto_detect_label = tk.Label(self.auto_detect_container,
                                              text="⏳ Scanning for backups...",
                                              fg="gray", font=("Arial", 8, "italic"))
            self.auto_detect_label.pack()


    def _create_modify_panel(self, parent):
        """Create the main merge panel with left/right backup selections"""
        panel_frame = ttk.LabelFrame(parent, text="MODIFY PANEL (Use One or Both slots)", padding=3)
        panel_frame.pack(fill=tk.BOTH, expand=True)

        # Container for left and right panels
        backup_container = ttk.Frame(panel_frame)
        backup_container.pack(fill=tk.BOTH, expand=True)

        # Left backup panel
        self.left_panel = self._create_backup_panel(backup_container, "LEFT BACKUP - SLOT A", "left")
        self.left_panel.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 2))

        # Right backup panel
        self.right_panel = self._create_backup_panel(backup_container, "RIGHT BACKUP - SLOT B", "right")
        self.right_panel.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(2, 0))

    def _create_device_panel(self, parent):
        """Create the full-height connected device panel"""
        panel = ttk.Frame(parent, width=400)
        panel.pack_propagate(True)  # Maintain fixed width

        # Create canvas and scrollbar for scrolling support when content overflows
        canvas = tk.Canvas(panel, highlightthickness=0, bd=0)
        scrollbar = ttk.Scrollbar(panel, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw", width=385)

        # Create a bounded yview that prevents scrolling above the top
        original_yview = canvas.yview
        def bounded_yview(*args):
            if args[0] == 'moveto':
                # Clamp position to not go below 0 (top of canvas)
                position = max(0.0, float(args[1]))
                return original_yview('moveto', position)
            elif args[0] == 'scroll':
                # Get current position
                current_pos = canvas.yview()[0]
                # Only allow scroll if we're not at top or scrolling down
                if current_pos > 0.0 or int(args[1]) > 0:
                    return original_yview(*args)
                # At top and trying to scroll up - do nothing
                return None
            else:
                return original_yview(*args)

        canvas.yview = bounded_yview
        canvas.configure(yscrollcommand=None)

        # Pack canvas (scrollbar shown only when needed)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self._configure_autohide_scrollbar(canvas, scrollbar, scrollable_frame)

        # Bind hover-based mouse wheel scrolling (only scrolls when hovering over this panel)
        self._bind_hover_scroll(canvas, canvas)

        # === RESTORE DEVICE PAGE HEADER ===
        restore_header_frame = tk.Frame(scrollable_frame, bg=self.theme.get_color('header_bg'), height=40)
        restore_header_frame.pack(fill=tk.X, pady=(0, 10), padx=3)
        restore_header_frame.pack_propagate(False)

        restore_header_label = tk.Label(restore_header_frame, text="Restore Device",
                                        bg=self.theme.get_color('header_bg'),
                                        fg=self.theme.get_color('header_fg'),
                                        font=("Arial", 12, "bold"))
        restore_header_label.pack(side=tk.LEFT, padx=7, pady=8)

        # Device status label (will be updated with device name or "None")
        self.restore_device_status_label = tk.Label(restore_header_frame, text="| Device: None",
                                                    bg=self.theme.get_color('header_bg'),
                                                    fg=self.theme.get_color('text_light'),
                                                    font=("Arial", 10))
        self.restore_device_status_label.pack(side=tk.LEFT, padx=5, pady=8)

        # === DEVICE INFO CARD ===
        restore_device_card = tk.Frame(scrollable_frame, relief=tk.RIDGE, bg="#f0f0f0")
        restore_device_card.pack(fill=tk.X, pady=(0, 15), padx=5)

        # Top section: device image + info
        restore_top_section = tk.Frame(restore_device_card, bg="#f0f0f0")
        restore_top_section.pack(fill=tk.X, padx=10, pady=10)

        # LEFT: Device image placeholder
        restore_device_image_frame = tk.Frame(restore_top_section, width=107, height=221,
                                              bd=0, bg="#f0f0f0", relief=tk.FLAT)
        restore_device_image_frame.pack(side=tk.LEFT, padx=(0, 15))
        restore_device_image_frame.pack_propagate(False)

        # Load connect guide image as placeholder
        restore_device_image_placeholder = None
        if PIL_AVAILABLE:
            try:
                import os
                script_dir = os.path.dirname(os.path.abspath(__file__))
                connect_img_path = get_resource_path('connect_guide.png')
                if os.path.exists(connect_img_path):
                    # Load and resize image to fit frame (107x221) while maintaining aspect ratio
                    connect_img = Image.open(connect_img_path)
                    # Calculate size to fit frame
                    img_width, img_height = connect_img.size
                    aspect_ratio = img_width / img_height
                    target_height = 221
                    target_width = int(target_height * aspect_ratio)
                    # If width exceeds frame width, scale by width instead
                    if target_width > 107:
                        target_width = 107
                        target_height = int(target_width / aspect_ratio)
                    connect_img_resized = connect_img.resize((target_width, target_height), Image.Resampling.LANCZOS)
                    connect_photo = ImageTk.PhotoImage(connect_img_resized)
                    restore_device_image_placeholder = tk.Label(restore_device_image_frame, image=connect_photo, bg="#f0f0f0")
                    restore_device_image_placeholder.image = connect_photo  # Keep reference
                    restore_device_image_placeholder.pack(expand=True)
                else:
                    # Fallback to emoji if image not found
                    restore_device_image_placeholder = tk.Label(restore_device_image_frame, text="📱",
                                                               font=("Arial", 48), bg="#f0f0f0")
                    restore_device_image_placeholder.pack(expand=True)
            except Exception as e:
                print(f"[DEBUG] Could not load connect guide image: {e}")
                # Fallback to emoji
                restore_device_image_placeholder = tk.Label(restore_device_image_frame, text="📱",
                                                           font=("Arial", 48), bg="#f0f0f0")
                restore_device_image_placeholder.pack(expand=True)
        else:
            # PIL not available, use emoji fallback
            restore_device_image_placeholder = tk.Label(restore_device_image_frame, text="📱",
                                                       font=("Arial", 48), bg="#f0f0f0")
            restore_device_image_placeholder.pack(expand=True)

        # RIGHT: Device info labels
        restore_device_info_frame = tk.Frame(restore_top_section, bg="#f0f0f0")
        restore_device_info_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        restore_device_name_label = tk.Label(restore_device_info_frame, text="No Device Connected",
                                            font=("Arial", 11, "bold"), bg="#f0f0f0",
                                            anchor=tk.W)
        restore_device_name_label.pack(fill=tk.X, pady=(0, 5))

        restore_device_model_label = tk.Label(restore_device_info_frame, text="Model: —",
                                             font=("Arial", 9), bg="#f0f0f0",
                                             anchor=tk.W, fg="#7f8c8d")
        restore_device_model_label.pack(fill=tk.X, pady=2)

        restore_device_ios_label = tk.Label(restore_device_info_frame, text="iOS: —",
                                           font=("Arial", 9), bg="#f0f0f0",
                                           anchor=tk.W, fg="#7f8c8d")
        restore_device_ios_label.pack(fill=tk.X, pady=2)

        restore_device_trusted_label = tk.Label(restore_device_info_frame, text="Trusted: —",
                                               font=("Arial", 9), bg="#f0f0f0",
                                               anchor=tk.W, fg="#7f8c8d")
        restore_device_trusted_label.pack(fill=tk.X, pady=2)

        restore_device_activation_label = tk.Label(restore_device_info_frame, text="Activation: —",
                                                  font=("Arial", 9), bg="#f0f0f0",
                                                  anchor=tk.W, fg="#7f8c8d")
        restore_device_activation_label.pack(fill=tk.X, pady=2)

        restore_device_findmy_label = tk.Label(restore_device_info_frame, text="Find My: —",
                                              font=("Arial", 9), bg="#f0f0f0",
                                              anchor=tk.W, fg="#7f8c8d")
        restore_device_findmy_label.pack(fill=tk.X, pady=2)

        restore_device_udid_label = tk.Label(restore_device_info_frame, text="UDID: —",
                                            font=("Consolas", 8), bg="#f0f0f0",
                                            anchor=tk.W, fg="#95a5a6")
        restore_device_udid_label.pack(fill=tk.X, pady=2)

        restore_device_charging_label = tk.Label(restore_device_info_frame, text="Charging: —",
                                                font=("Arial", 9), bg="#f0f0f0",
                                                anchor=tk.W, fg="#7f8c8d")
        restore_device_charging_label.pack(fill=tk.X, pady=2)

        restore_device_color_capacity_label = tk.Label(restore_device_info_frame, text="Configuration: —",
                                                      font=("Arial", 9), bg="#f0f0f0",
                                                      anchor=tk.W, fg="#7f8c8d")
        restore_device_color_capacity_label.pack(fill=tk.X, pady=2)

        # === TOP SECTION: Storage Widget ===

        # Storage Widget
        storage_frame = tk.Frame(scrollable_frame, bg="#f9f9f9", relief=tk.FLAT)
        storage_frame.pack(fill=tk.X, pady=(0, 10))

        # Storage label
        storage_label = tk.Label(storage_frame, text="STORAGE",
                                font=("Arial", 7, "bold"), bg="#f9f9f9", fg="#7f8c8d")
        storage_label.pack(anchor=tk.W, padx=5, pady=(5, 2))

        # Storage bar canvas
        storage_canvas = tk.Canvas(storage_frame, height=25, bg="#f9f9f9",
                                  highlightthickness=0, bd=0)
        storage_canvas.pack(fill=tk.X, padx=5, pady=(0, 5))

        # Storage text label (will show "X GB free of Y GB")
        storage_text_label = tk.Label(storage_frame, text="",
                                     font=("Arial", 8), bg="#f9f9f9", fg="#5a6c7d")
        storage_text_label.pack(anchor=tk.W, padx=5, pady=(0, 5))

        # No backup warning banner (initially hidden)
        self.no_backup_warning = tk.Label(scrollable_frame,
                                         text="⚠️  NO LOCAL BACKUP FOUND\n\nThis device has not been backed up to this computer.\nConsider creating a backup before merging or restoring.",
                                         bg="#f39c12", fg="white",
                                         font=("Arial", 8, "bold"),
                                         pady=8, padx=5,
                                         justify=tk.LEFT,
                                         wraplength=350)
        # Don't pack it yet - will show conditionally when device has no backup

        # Storage warning banner (initially hidden) - shows when restore won't fit
        self.storage_warning = tk.Label(scrollable_frame, text="",
                                       bg="#e74c3c", fg="white",
                                       font=("Arial", 8, "bold"),
                                       pady=8, padx=5,
                                       justify=tk.LEFT,
                                       wraplength=350)
        # Don't pack it yet - will show conditionally when storage is insufficient

        # Separator
        ttk.Separator(scrollable_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=(0, 10))

        # === MIDDLE SECTION: Restore Target ===

        restore_frame = ttk.LabelFrame(scrollable_frame, text="RESTORE TARGET", padding=3)
        restore_frame.pack(fill=tk.X, pady=(0, 5))

        # Radio buttons for backup selection
        self.modified_backup_radio = ttk.Radiobutton(restore_frame, text="Modified Backup (Will apply changes)",
                                                     variable=self.restore_target, value="modified",
                                                     state=tk.DISABLED,  # Disabled until modification completes
                                                     command=self._on_restore_target_changed)
        self.modified_backup_radio.pack(anchor=tk.W, pady=2)

        ttk.Radiobutton(restore_frame, text="Left Backup (Will not apply changes)",
                       variable=self.restore_target, value="left",
                       command=self._on_restore_target_changed).pack(anchor=tk.W, pady=2)

        ttk.Radiobutton(restore_frame, text="Right Backup (Will not apply changes)",
                       variable=self.restore_target, value="right",
                       command=self._on_restore_target_changed).pack(anchor=tk.W, pady=2)

        # Browse option with inline button
        browse_frame = tk.Frame(restore_frame)
        browse_frame.pack(anchor=tk.W, pady=2, fill=tk.X)

        ttk.Radiobutton(browse_frame, text="Browse for other backup...",
                       variable=self.restore_target, value="browse",
                       command=self._on_restore_target_changed).pack(side=tk.LEFT)

        self.browse_restore_btn = ttk.Button(browse_frame, text="📁 Browse...",
                                            command=self._browse_for_restore_backup,
                                            width=12)
        self.browse_restore_btn.pack(side=tk.LEFT, padx=(10, 0))

        # Selected backup path display
        self.restore_path_label = ttk.Label(restore_frame, text="No backup selected",
                                           font=("Arial", 8), foreground="#7f8c8d",
                                           wraplength=350)
        self.restore_path_label.pack(anchor=tk.W, pady=(5, 0))

        # Store reference to restore_frame for later use
        self.restore_frame = restore_frame

        # === RESTORE PROGRESS SECTION ===

        restore_progress_section = ttk.LabelFrame(scrollable_frame, text="Restore Progress", padding=5)
        restore_progress_section.pack(fill=tk.X, pady=(0, 5))

        restore_progress_bar = ttk.Progressbar(restore_progress_section, mode='determinate', length=300)
        restore_progress_bar.pack(fill=tk.X, pady=(0, 5))

        restore_progress_status_label = tk.Label(restore_progress_section, text="Status: Idle",
                                                font=("Arial", 9), anchor=tk.W)
        restore_progress_status_label.pack(fill=tk.X)

        # === BOTTOM SECTION: Restore Buttons ===

        restore_buttons_frame = tk.Frame(scrollable_frame)
        restore_buttons_frame.pack(fill=tk.X, pady=(0, 5))

        # Restore to Device button (green, styled)
        self.restore_btn = self._create_styled_button(restore_buttons_frame, "🔄 Restore to Device",
                                                      self._restore_device, "#27ae60", "#229954",
                                                      font=("Arial", 9, "bold"), padx=12, pady=6,
                                                      state=tk.DISABLED)
        self.restore_btn.pack(side=tk.LEFT, padx=(0, 5))

        # Cancel button (gray, styled, starts disabled)
        restore_cancel_btn = self._create_styled_button(restore_buttons_frame, "⏹️  Cancel",
                                                        self._cancel_device_restore, "#95a5a6", "#7f8c8d",
                                                        font=("Arial", 9, "bold"), padx=12, pady=6,
                                                        state=tk.DISABLED)
        restore_cancel_btn.pack(side=tk.LEFT)

        # Store references
        self.device_storage_canvas = storage_canvas
        self.device_storage_label = storage_text_label
        self.restore_progress_bar = restore_progress_bar
        self.restore_progress_status_label = restore_progress_status_label
        self.restore_cancel_btn = restore_cancel_btn

        # Backwards-compat alias so all restore code uses the same label
        # Older / other parts of the code refer to self.restore_status_label
        # while the UI uses restore_progress_status_label.
        self.restore_status_label = self.restore_progress_status_label

        # Restore device info widget references
        self.restore_device_name_label = restore_device_name_label
        self.restore_device_model_label = restore_device_model_label
        self.restore_device_ios_label = restore_device_ios_label
        self.restore_device_trusted_label = restore_device_trusted_label
        self.restore_device_activation_label = restore_device_activation_label
        self.restore_device_udid_label = restore_device_udid_label
        self.restore_device_charging_label = restore_device_charging_label
        self.restore_device_color_capacity_label = restore_device_color_capacity_label
        self.restore_device_findmy_label = restore_device_findmy_label
        self.restore_device_image_frame = restore_device_image_frame
        self.restore_device_image_placeholder = restore_device_image_placeholder
        self.restore_device_image_label = None  # Initialize for dynamic wallpaper label

        self._configure_autohide_scrollbar(canvas, scrollbar, scrollable_frame)
        return panel

    def _create_backup_panel(self, parent, title, side):
        """Create a single backup selection panel"""
        label_frame = ttk.LabelFrame(parent, text=title, padding=3)

        # Create a regular tk.Frame wrapper inside for drag-and-drop support
        # (ttk widgets don't support tkinterdnd2 well)
        frame = tk.Frame(label_frame, bg=self.root.cget('bg'))
        frame.pack(fill=tk.BOTH, expand=True)

        # Enable drag-and-drop on wrapper frame
        if DND_AVAILABLE:
            frame.drop_target_register(DND_FILES)
            frame.dnd_bind('<<Drop>>', lambda e: self._handle_drop(e, side, None))

        # Paste path zone
        paste_frame = tk.Frame(frame)
        paste_frame.pack(fill=tk.X, pady=(0, 5))

        ttk.Label(paste_frame, text="Path:", font=("Arial", 8)).pack(side=tk.LEFT, padx=(0, 3))
        path_entry = ttk.Entry(paste_frame, width=28, font=("Arial", 8))
        path_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 3))
        ttk.Button(paste_frame, text="Load", command=lambda: self._load_from_entry(path_entry, side)).pack(side=tk.LEFT)

        # Store reference for later
        if side == "left":
            self.left_path_entry = path_entry
        else:
            self.right_path_entry = path_entry

        # iOS Version Label (new!)
        version_frame = tk.Frame(frame)
        version_frame.pack(fill=tk.X, pady=(3, 5))

        version_label = tk.Label(version_frame, text="iOS: —",
                                font=("Arial", 9, "bold"), fg="#7f8c8d",
                                anchor=tk.W)
        version_label.pack(side=tk.LEFT, padx=(0, 5))

        # Compatibility indicator (new!)
        compat_label = tk.Label(version_frame, text="",
                               font=("Arial", 8), anchor=tk.W)
        compat_label.pack(side=tk.LEFT)

        # Store references
        if side == "left":
            self.left_version_label = version_label
            self.left_compat_label = compat_label
        else:
            self.right_version_label = version_label
            self.right_compat_label = compat_label

        # Wallpaper preview / Drop zone
        wallpaper_frame = tk.Frame(frame, height=230, bg="#f0f0f0",
                                   relief=tk.GROOVE, borderwidth=0, cursor="hand2")
        wallpaper_frame.pack_propagate(False)
        wallpaper_frame.pack(fill=tk.X, pady=(0, 5))  # Always visible

        # Make frame clickable
        wallpaper_frame.bind("<Button-1>", lambda e: self._browse_backup(side))

        # Clear button (X) - top right corner, hidden by default
        # Modern, subtle styling to match interface
        clear_btn = tk.Button(
            wallpaper_frame,
            text="✕",
            font=("Arial", 10, "bold"),
            bg="#f0f0f0",
            fg="#7f8c8d",
            activebackground="#e74c3c",
            activeforeground="white",
            relief=tk.FLAT,
            borderwidth=1,
            highlightthickness=0,
            cursor="hand2",
            padx=3,
            pady=1,
            command=lambda: self._clear_backup(side)
        )

        info_btn = tk.Button(
            wallpaper_frame,
            text="ℹ",
            font=("Arial", 10, "bold"),
            bg="#f0f0f0",
            fg="#7f8c8d",
            activebackground="#4a90e2",
            activeforeground="white",
            relief=tk.FLAT,
            borderwidth=1,
            highlightthickness=0,
            cursor="hand2",
            width=2,
            height=1,
            padx=4,
            pady=1,
            command=lambda s=side: self._show_backup_info_for_side(s)
        )

        # Add hover effects for modern feel
        def on_enter(e):
            clear_btn.config(bg="#e74c3c", fg="white")
        def on_leave(e):
            clear_btn.config(bg="#f0f0f0", fg="#7f8c8d")

        clear_btn.bind("<Enter>", on_enter)
        clear_btn.bind("<Leave>", on_leave)

        def info_on_enter(e):
            info_btn.config(bg="#4a90e2", fg="white")
        def info_on_leave(e):
            info_btn.config(bg="#f0f0f0", fg="#7f8c8d")

        info_btn.bind("<Enter>", info_on_enter)
        info_btn.bind("<Leave>", info_on_leave)

        # Hide initially (don't place it yet)
        # Will be shown when backup loads

        # Drop zone placeholder (replaced when backup loads)
        wallpaper_label = tk.Label(wallpaper_frame,
                                  text="📁\n\nDrag & Drop Backup Folder Here\n\n(or click to browse)",
                                  font=("Arial", 9, "italic"), fg="gray", bg="#f0f0f0",
                                  justify=tk.CENTER, cursor="hand2")
        wallpaper_label.pack(expand=True, fill=tk.BOTH)

        # Make label clickable too
        wallpaper_label.bind("<Button-1>", lambda e: self._browse_backup(side))

        # Info display (bottom) - increased height
        info_text = tk.Text(frame, height=4, width=25, bg="#f9f9f9",
                           relief=tk.FLAT, font=("Consolas", 8), wrap=tk.WORD)
        info_text.pack(fill=tk.BOTH, expand=True)
        info_text.insert("1.0", "No backup selected")
        info_text.config(state=tk.DISABLED)

        extract_btn = ttk.Button(
            frame,
            text="Extract Data & Create Reports",
            command=lambda s=side: self._extract_backup_from_slot(s),
            state=tk.DISABLED
        )
        extract_btn.configure(padding=(6, 1))
        extract_btn.pack(fill=tk.X, pady=(2, 0))

        # Store references
        if side == "left":
            self.left_info_text = info_text
            self.left_wallpaper_label = wallpaper_label
            self.left_wallpaper_frame = wallpaper_frame
            self.left_panel_frame = label_frame
            self.left_clear_btn = clear_btn
            self.left_info_btn = info_btn
            self.left_extract_btn = extract_btn
        else:
            self.right_info_text = info_text
            self.right_wallpaper_label = wallpaper_label
            self.right_wallpaper_frame = wallpaper_frame
            self.right_panel_frame = label_frame
            self.right_clear_btn = clear_btn
            self.right_info_btn = info_btn
            self.right_extract_btn = extract_btn

        return label_frame

    def _update_backup_panel_titles(self):
        """Update backup panel titles to show single-backup or dual-backup mode"""
        # Detect single-backup mode
        single_backup_mode = bool(self.left_backup) != bool(self.right_backup)

        if single_backup_mode:
            # Single-backup mode - show which one is active
            if self.left_backup:
                self.left_panel_frame.config(text="LEFT BACKUP - SLOT A (Modifying)")
                self.right_panel_frame.config(text="RIGHT BACKUP - SLOT B (Empty)")
            else:
                self.left_panel_frame.config(text="LEFT BACKUP - SLOT A (Empty)")
                self.right_panel_frame.config(text="RIGHT BACKUP - SLOT B (Modifying)")
        else:
            # Dual-backup mode or no backups loaded
            self.left_panel_frame.config(text="LEFT BACKUP - SLOT A")
            self.right_panel_frame.config(text="RIGHT BACKUP - SLOT B")

    def _toggle_device_panel(self):
        """Toggle device panel visibility (manual user action)"""
        debug_log(f"\n[DEBUG _toggle_device_panel] ENTRY - device_visible={self.device_panel_visible}, backup_visible={self.backup_panel_visible}")

        if self.device_panel_visible:
            self._hide_device_panel()
        else:
            self._show_device_panel()

        # Mark that user has manually toggled panels (persists across sessions)
        self.user_has_manually_toggled = True
        # Mark that device panel was manually toggled during this session
        self.device_panel_manually_toggled = True

        # Save state
        self._save_panel_state()
        debug_log(f"[DEBUG _toggle_device_panel] EXIT - device_visible={self.device_panel_visible}, backup_visible={self.backup_panel_visible}\n")

    def _show_device_panel(self):
        """Show the device panel and expand window"""
        print(f"[DEBUG _show_device_panel] ENTRY - device_visible={self.device_panel_visible}, backup_visible={self.backup_panel_visible}")

        # Get horizontal_container to inspect pack order
        horizontal_container = self.backup_panel.master
        print(f"[DEBUG _show_device_panel] Pack slaves BEFORE: {[str(w).split('.')[-1] for w in horizontal_container.pack_slaves()]}")

        # Calculate new width based on backup panel state
        # Device panel (380) + padding (5) + toggle (35) + padding (5) + content (740) + padding (5) + toggle (35) + padding (5) + backup (380)
        if self.backup_panel_visible:
            new_width = 1630  # Both panels open (380 + 5 + 35 + 5 + 740 + 5 + 35 + 5 + 400)
        else:
            new_width = 1225  # Just device panel open (35 + 5 + 740 + 5 + 35 + 5 + 400)

        # Update geometry first
        self.root.geometry(f"{new_width}x973")
        self.root.update_idletasks()

        # Pack the panel
        self.device_panel.pack(side=tk.LEFT, fill=tk.BOTH, expand=False, padx=(5, 0), after=self.device_toggle_frame)
        self.device_panel_visible = True
        self.toggle_btn.config(text="◀", bg=self.theme.get_color('toggle_device_active'))

        # macOS fix: Use after() to ensure proper rendering
        def _finalize_show():
            self.root.update_idletasks()
            print(f"[DEBUG _show_device_panel] Pack slaves AFTER: {[str(w).split('.')[-1] for w in horizontal_container.pack_slaves()]}")
            print(f"[DEBUG _show_device_panel] EXIT - device_visible={self.device_panel_visible}, backup_visible={self.backup_panel_visible}")

        self.root.after(10, _finalize_show)

    def _hide_device_panel(self):
        """Hide the device panel and collapse window"""
        print(f"[DEBUG _hide_device_panel] ENTRY - device_visible={self.device_panel_visible}, backup_visible={self.backup_panel_visible}")

        # Get horizontal_container to inspect pack order
        horizontal_container = self.backup_panel.master
        print(f"[DEBUG _hide_device_panel] Pack slaves BEFORE: {[str(w).split('.')[-1] for w in horizontal_container.pack_slaves()]}")

        # Unpack panel
        self.device_panel.pack_forget()
        self.device_panel_visible = False

        # Calculate new width based on backup panel state
        if self.backup_panel_visible:
            new_width = 1225  # Just backup panel open
        else:
            new_width = 820  # Both panels closed

        self.root.geometry(f"{new_width}x973")

        # Update toggle button appearance based on device connection
        if self.has_connected_device:
            self.toggle_btn.config(text="📱\n▶\n🟢", bg=self.theme.get_color('toggle_device_connected'))  # Green when device connected
        else:
            self.toggle_btn.config(text="📱\n▶", bg=self.theme.get_color('toggle_device_inactive'))  # Blue when no device

        # macOS fix: Use after() to ensure proper rendering
        def _finalize_hide():
            self.root.update_idletasks()
            print(f"[DEBUG _hide_device_panel] Pack slaves AFTER: {[str(w).split('.')[-1] for w in horizontal_container.pack_slaves()]}")
            print(f"[DEBUG _hide_device_panel] EXIT - device_visible={self.device_panel_visible}, backup_visible={self.backup_panel_visible}")

        self.root.after(10, _finalize_hide)

    def _create_device_backup_panel(self, parent):
        """
        Create the left-side device backup panel with scrolling support.
        Returns a Frame that can be packed into the main window.
        """
        # Main container frame
        panel = ttk.Frame(parent, width=400)
        panel.pack_propagate(False)  # Maintain fixed width

        # Create canvas and scrollbar for scrolling support when content overflows
        canvas = tk.Canvas(panel, highlightthickness=0, bd=0)
        scrollbar = ttk.Scrollbar(panel, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=None)
        scrollable_frame = ttk.Frame(canvas)

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw", width=385)

        # Create a bounded yview that prevents scrolling above the top
        original_yview = canvas.yview
        def bounded_yview(*args):
            if args[0] == 'moveto':
                # Clamp position to not go below 0 (top of canvas)
                position = max(0.0, float(args[1]))
                return original_yview('moveto', position)
            elif args[0] == 'scroll':
                # Get current position
                current_pos = canvas.yview()[0]
                # Only allow scroll if we're not at top or scrolling down
                if current_pos > 0.0 or int(args[1]) > 0:
                    return original_yview(*args)
                # At top and trying to scroll up - do nothing
                return None
            else:
                return original_yview(*args)

        canvas.yview = bounded_yview
        canvas.configure(yscrollcommand=None)

        # Pack canvas (scrollbar shown only when needed)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self._configure_autohide_scrollbar(canvas, scrollbar, scrollable_frame)

        # Bind hover-based mouse wheel scrolling
        self._bind_hover_scroll(canvas, canvas)

        # === 1. HEADER BAR ===
        header_frame = tk.Frame(scrollable_frame, bg=self.theme.get_color('header_bg'), height=40)
        header_frame.pack(fill=tk.X, pady=(0, 10), padx=10)
        header_frame.pack_propagate(False)

        header_label = tk.Label(header_frame, text="Backup Device",
                               bg=self.theme.get_color('header_bg'),
                               fg=self.theme.get_color('header_fg'),
                               font=("Arial", 12, "bold"))
        header_label.pack(side=tk.LEFT, padx=0, pady=8)

        last_backup_label = tk.Label(header_frame, text="Last backup: Unknown",
                                    bg=self.theme.get_color('header_bg'),
                                    fg=self.theme.get_color('text_light'),
                                    font=("Arial", 9))
        last_backup_label.pack(side=tk.RIGHT, padx=10)

        refresh_btn = tk.Button(header_frame, text="🔄",
                               bg=self.theme.get_color('button_dark_bg'),
                               fg=self.theme.get_color('button_dark_fg'),
                               font=("Arial", 10), relief=tk.FLAT,
                               padx=8, cursor="hand2")
        # refresh_btn moved to footer_frame to save header space

        extract_report_btn = tk.Button(
            header_frame,
            text="Extract Report",
            bg=self.theme.get_color('button_dark_bg'),
            fg=self.theme.get_color('button_dark_fg'),
            font=("Arial", 8, "bold"),
            relief=tk.FLAT,
            padx=6,
            cursor="hand2",
            state=tk.DISABLED,
            command=self._extract_last_completed_backup
        )
        extract_report_btn.pack(side=tk.RIGHT, padx=(0, 5))

        # === 2. DEVICE INFO CARD ===
        device_card = tk.Frame(scrollable_frame, relief=tk.RIDGE, bg="#f0f0f0")
        device_card.pack(fill=tk.X, pady=(0, 15), padx=5)

        # Top section: device image + info
        top_section = tk.Frame(device_card, bg="#f0f0f0")
        top_section.pack(fill=tk.X, padx=10, pady=10)

        # LEFT: Device image placeholder
        device_image_frame = tk.Frame(top_section, width=107, height=221,
                                       bd=0, bg="#f0f0f0", relief=tk.FLAT)
        device_image_frame.pack(side=tk.LEFT, padx=(0, 15))
        device_image_frame.pack_propagate(False)

        # Load connect guide image as placeholder
        device_image_placeholder = None
        if PIL_AVAILABLE:
            try:
                import os
                script_dir = os.path.dirname(os.path.abspath(__file__))
                connect_img_path = get_resource_path('connect_guide.png')
                if os.path.exists(connect_img_path):
                    # Load and resize image to fit frame (107x221) while maintaining aspect ratio
                    connect_img = Image.open(connect_img_path)
                    # Calculate size to fit frame
                    img_width, img_height = connect_img.size
                    aspect_ratio = img_width / img_height
                    target_height = 221
                    target_width = int(target_height * aspect_ratio)
                    # If width exceeds frame width, scale by width instead
                    if target_width > 107:
                        target_width = 107
                        target_height = int(target_width / aspect_ratio)
                    connect_img_resized = connect_img.resize((target_width, target_height), Image.Resampling.LANCZOS)
                    connect_photo = ImageTk.PhotoImage(connect_img_resized)
                    device_image_placeholder = tk.Label(device_image_frame, image=connect_photo, bg="#f0f0f0")
                    device_image_placeholder.image = connect_photo  # Keep reference
                    device_image_placeholder.pack(expand=True)
                else:
                    # Fallback to emoji if image not found
                    device_image_placeholder = tk.Label(device_image_frame, text="📱",
                                                       font=("Arial", 48), bg="#f0f0f0")
                    device_image_placeholder.pack(expand=True)
            except Exception as e:
                print(f"[DEBUG] Could not load connect guide image: {e}")
                # Fallback to emoji
                device_image_placeholder = tk.Label(device_image_frame, text="📱",
                                                   font=("Arial", 48), bg="#f0f0f0")
                device_image_placeholder.pack(expand=True)
        else:
            # PIL not available, use emoji fallback
            device_image_placeholder = tk.Label(device_image_frame, text="📱",
                                               font=("Arial", 48), bg="#f0f0f0")
            device_image_placeholder.pack(expand=True)

        # RIGHT: Device info labels
        device_info_frame = tk.Frame(top_section, bg="#f0f0f0")
        device_info_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        device_name_label = tk.Label(device_info_frame, text="No Device Connected",
                                     font=("Arial", 11, "bold"), bg="#f0f0f0",
                                     anchor=tk.W)
        device_name_label.pack(fill=tk.X, pady=(0, 5))

        device_model_label = tk.Label(device_info_frame, text="Model: —",
                                      font=("Arial", 9), bg="#f0f0f0",
                                      anchor=tk.W, fg="#7f8c8d")
        device_model_label.pack(fill=tk.X, pady=2)

        device_ios_label = tk.Label(device_info_frame, text="iOS: —",
                                   font=("Arial", 9), bg="#f0f0f0",
                                   anchor=tk.W, fg="#7f8c8d")
        device_ios_label.pack(fill=tk.X, pady=2)

        device_trusted_label = tk.Label(device_info_frame, text="Trusted: —",
                                       font=("Arial", 9), bg="#f0f0f0",
                                       anchor=tk.W, fg="#7f8c8d")
        device_trusted_label.pack(fill=tk.X, pady=2)

        device_activation_label = tk.Label(device_info_frame, text="Activation: —",
                                          font=("Arial", 9), bg="#f0f0f0",
                                          anchor=tk.W, fg="#7f8c8d")
        device_activation_label.pack(fill=tk.X, pady=2)

        device_findmy_label = tk.Label(device_info_frame, text="Find My: —",
                                       font=("Arial", 9), bg="#f0f0f0",
                                       anchor=tk.W, fg="#7f8c8d")
        device_findmy_label.pack(fill=tk.X, pady=2)

        device_udid_label = tk.Label(device_info_frame, text="UDID: —",
                                     font=("Consolas", 8), bg="#f0f0f0",
                                     anchor=tk.W, fg="#95a5a6")
        device_udid_label.pack(fill=tk.X, pady=2)

        device_charging_label = tk.Label(device_info_frame, text="Charging: —",
                                        font=("Arial", 9), bg="#f0f0f0",
                                        anchor=tk.W, fg="#7f8c8d")
        device_charging_label.pack(fill=tk.X, pady=2)

        device_color_capacity_label = tk.Label(device_info_frame, text="Configuration: —",
                                               font=("Arial", 9), bg="#f0f0f0",
                                               anchor=tk.W, fg="#7f8c8d")
        device_color_capacity_label.pack(fill=tk.X, pady=2)

        # Capacity bar section
        capacity_bar_section = tk.Frame(device_card, bg="#f0f0f0")
        capacity_bar_section.pack(fill=tk.X, padx=10, pady=(5, 10))

        capacity_label = tk.Label(capacity_bar_section, text="Storage Breakdown:",
                                 font=("Arial", 9, "bold"), bg="#f0f0f0",
                                 anchor=tk.W)
        capacity_label.pack(fill=tk.X, pady=(0, 5))

        # Horizontal capacity bar with segments
        capacity_bar_container = tk.Frame(capacity_bar_section, height=25, bg="#f0f0f0",
                                         relief=tk.SOLID, bd=1, highlightthickness=0)
        capacity_bar_container.pack(fill=tk.X, pady=(0, 5))

        # Define segments with colors
        segments = [
            ("System", "#2c3e50", 0.20),      # Deep blue
            ("Apps", "#16a085", 0.15),         # Teal
            ("Photos", "#8e44ad", 0.25),       # Purple
            ("Media", "#f39c12", 0.10),        # Yellow
            ("Others", "#e67e22", 0.08),       # Orange
            ("Free", "#95a5a6", 0.22)          # Grey
        ]

        for label_text, color, width_fraction in segments:
            segment = tk.Frame(capacity_bar_container, bg=color, height=25)
            segment.pack(side=tk.LEFT, fill=tk.Y, expand=True)

        # Legend row
        legend_frame = tk.Frame(capacity_bar_section, bg="#f0f0f0")
        legend_frame.pack(fill=tk.X)

        for label_text, color, _ in segments:
            legend_item = tk.Frame(legend_frame, bg="#f0f0f0")
            legend_item.pack(side=tk.LEFT, padx=5)

            color_box = tk.Frame(legend_item, bg=color, width=12, height=12)
            color_box.pack(side=tk.LEFT, padx=(0, 3))
            color_box.pack_propagate(False)

            legend_label = tk.Label(legend_item, text=label_text,
                                   font=("Arial", 7), bg="#f0f0f0")
            legend_label.pack(side=tk.LEFT)

        # Warning label (initially hidden)
        encryption_warning = tk.Label(device_card,
                                     text="Backup encryption is enabled on this device.\nEncrypted backups are supported; you'll need the password later to access data.",
                                     bg="#3498db", fg="white",
                                     font=("Arial", 9, "bold"),
                                     pady=8, padx=10, justify=tk.LEFT)
        # Don't pack it yet - use pack_forget() or pack() dynamically

        # === 3. BACKUP LOCATION SECTION ===
        location_section = ttk.LabelFrame(scrollable_frame, text="Backup Location", padding=10)
        location_section.pack(fill=tk.X, pady=(0, 15))

        # Backup Name (optional) - label and entry on same row
        backup_name_row = tk.Frame(location_section)
        backup_name_row.pack(fill=tk.X, pady=(0, 5))

        backup_name_label = tk.Label(backup_name_row, text="Backup Name (optional):",
                                     font=("Arial", 9), width=22, anchor=tk.W)
        backup_name_label.pack(side=tk.LEFT)

        backup_name_entry = tk.Entry(backup_name_row, font=("Arial", 9))
        backup_name_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)

        # Backup Location - label, entry, and browse button on same row
        location_row = tk.Frame(location_section)
        location_row.pack(fill=tk.X, pady=(0, 10))

        location_label = tk.Label(location_row, text="Backup Location:",
                                 font=("Arial", 9), width=22, anchor=tk.W)
        location_label.pack(side=tk.LEFT)

        location_entry = tk.Entry(location_row, font=("Arial", 9))
        location_entry.insert(0, "Q:\\")
        location_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))

        browse_location_btn = ttk.Button(location_row, text="Browse...",
                                         command=lambda: self._browse_backup_location(location_entry))
        browse_location_btn.pack(side=tk.LEFT)

        # Checkbox for creating iTunes backup sub-folder
        create_itunes_subfolder_var = tk.BooleanVar(value=True)
        create_itunes_subfolder_check = tk.Checkbutton(location_section,
                                                       text="Create iTunes backup sub-folder in Backup Location",
                                                       variable=create_itunes_subfolder_var,
                                                       font=("Arial", 9))
        create_itunes_subfolder_check.pack(anchor=tk.W, pady=(0, 0))


        # === 4. BACKUP INFO SECTION ===
        backup_info_section = ttk.LabelFrame(scrollable_frame, text="Backup Information", padding=8)
        backup_info_section.pack(fill=tk.X, pady=(0, 15))

        info_line_2 = tk.Label(backup_info_section,
                               text="Encrypted backups are supported; you may be prompted for",
                               font=("Arial", 9), fg="#34495e",
                               anchor=tk.W, justify=tk.LEFT)
        info_line_2.pack(fill=tk.X, padx=(8, 8), pady=(0, 0))

        info_line_3 = tk.Label(backup_info_section,
                               text="a password later.",
                               font=("Arial", 9), fg="#34495e",
                               anchor=tk.W, justify=tk.LEFT)
        info_line_3.pack(fill=tk.X, padx=(8, 8), pady=(0, 6))

        estimated_size_label = tk.Label(backup_info_section,
                                       text="Estimated backup size: —",
                                       font=("Arial", 9), anchor=tk.W)
        estimated_size_label.pack(fill=tk.X, pady=1)

        free_space_label = tk.Label(backup_info_section,
                                   text="Free space at destination: —",
                                   font=("Arial", 9), anchor=tk.W)
        free_space_label.pack(fill=tk.X, pady=1)

        backup_type_label = tk.Label(backup_info_section,
                                    text="Backup type: Full",
                                    font=("Arial", 9), anchor=tk.W)
        backup_type_label.pack(fill=tk.X, pady=1)

        # === 5. PROGRESS SECTION ===
        progress_section = ttk.LabelFrame(scrollable_frame, text="Backup Progress", padding=10)
        progress_section.pack(fill=tk.X, pady=(0, 5))

        progress_bar = ttk.Progressbar(progress_section, mode='determinate', length=300)
        progress_bar.pack(fill=tk.X, pady=(0, 5))

        progress_status_label = tk.Label(progress_section, text="Status: Idle",
                                        font=("Arial", 9), anchor=tk.W)
        progress_status_label.pack(fill=tk.X)

        # === 6. FOOTER BUTTONS ===
        footer_frame = tk.Frame(scrollable_frame)
        footer_frame.pack(fill=tk.X, pady=(0, 0), padx=(5, 0))

        # Start Backup button (green)
        start_backup_btn = self._create_styled_button(footer_frame, "▶️  Create iOS Backup",
                                                      self._start_device_backup, "#27ae60", "#229954",
                                                      font=("Arial", 9, "bold"), padx=12, pady=6)
        start_backup_btn.pack(side=tk.LEFT, padx=(0, 5))

        # Cancel button (gray)
        cancel_btn = self._create_styled_button(footer_frame, "⏹️  Cancel",
                                                self._cancel_device_backup, "#95a5a6", "#7f8c8d",
                                                font=("Arial", 9, "bold"), padx=12, pady=6,
                                                state=tk.DISABLED)
        cancel_btn.pack(side=tk.LEFT, padx=(0, 5))

        refresh_btn.pack(side=tk.RIGHT, padx=(5, 0))

        # Modify Backup button (purple, disabled initially)

        modify_backup_btn = self._create_styled_button(footer_frame, "🔧  Modify Backup",
                                                       self._load_backup_to_modify, "#9b59b6", "#8e44ad",
                                                       font=("Arial", 9, "bold"), padx=12, pady=6,
                                                       state=tk.DISABLED)
        modify_backup_btn.pack(side=tk.LEFT)

        # Store widget references in the panel for later access
        panel.last_backup_label = last_backup_label
        panel.device_name_label = device_name_label
        panel.device_model_label = device_model_label
        panel.backup_type_label = backup_type_label
        panel.device_ios_label = device_ios_label
        panel.device_activation_label = device_activation_label
        panel.device_udid_label = device_udid_label
        panel.device_trusted_label = device_trusted_label
        panel.device_charging_label = device_charging_label
        panel.device_color_capacity_label = device_color_capacity_label
        panel.device_findmy_label = device_findmy_label
        panel.encryption_warning = encryption_warning
        panel.location_entry = location_entry
        panel.backup_name_entry = backup_name_entry
        panel.create_itunes_subfolder_var = create_itunes_subfolder_var
        panel.estimated_size_label = estimated_size_label
        panel.free_space_label = free_space_label
        panel.progress_bar = progress_bar
        panel.progress_status_label = progress_status_label
        panel.start_backup_btn = start_backup_btn
        panel.cancel_btn = cancel_btn
        panel.modify_backup_btn = modify_backup_btn
        panel.refresh_btn = refresh_btn
        panel.extract_report_btn = extract_report_btn
        panel.browse_location_btn = browse_location_btn
        panel.device_image_frame = device_image_frame
        panel.device_image_placeholder = device_image_placeholder
        panel.capacity_bar_container = capacity_bar_container
        panel.capacity_bar_section = capacity_bar_section
        panel.last_completed_backup = None  # Track last completed backup path

        # Initialize variables for dynamic image label
        panel.device_image_label = None

        return panel

    def _toggle_backup_panel(self):
        """Toggle backup panel visibility"""
        print(f"\n[DEBUG _toggle_backup_panel] ENTRY - device_visible={self.device_panel_visible}, backup_visible={self.backup_panel_visible}")

        if self.backup_panel_visible:
            self._hide_backup_panel()
        else:
            self._show_backup_panel()

        # Mark that backup panel was manually toggled during this session
        self.backup_panel_manually_toggled = True

        print(f"[DEBUG _toggle_backup_panel] EXIT - device_visible={self.device_panel_visible}, backup_visible={self.backup_panel_visible}\n")

    def _show_backup_panel(self):
        """Show the backup panel and expand window"""
        print(f"[DEBUG _show_backup_panel] ENTRY - device_visible={self.device_panel_visible}, backup_visible={self.backup_panel_visible}")

        # Get horizontal_container to inspect pack order
        horizontal_container = self.backup_panel.master
        print(f"[DEBUG _show_backup_panel] Pack slaves BEFORE: {[str(w).split('.')[-1] for w in horizontal_container.pack_slaves()]}")

        # Calculate new width based on device panel state
        if self.device_panel_visible:
            new_width = 1640  # Both panels open
        else:
            new_width = 1225  # Just backup panel open

        # Update geometry first
        self.root.geometry(f"{new_width}x973")
        self.root.update_idletasks()

        # Pack before the toggle button to ensure it appears on the left
        self.backup_panel.pack(side=tk.LEFT, fill=tk.BOTH, expand=False, padx=(0, 5), before=self.backup_toggle_frame)
        self.backup_panel_visible = True
        self.backup_toggle_btn.config(text="▶\n💾", bg=self.theme.get_color('toggle_backup_active'))

        # macOS fix: Use after() to ensure proper rendering
        def _finalize_show():
            self.root.update_idletasks()
            print(f"[DEBUG _show_backup_panel] Pack slaves AFTER: {[str(w).split('.')[-1] for w in horizontal_container.pack_slaves()]}")
            print(f"[DEBUG _show_backup_panel] EXIT - device_visible={self.device_panel_visible}, backup_visible={self.backup_panel_visible}")

        self.root.after(10, _finalize_show)

    def _hide_backup_panel(self):
        """Hide the backup panel and collapse window"""
        print(f"[DEBUG _hide_backup_panel] ENTRY - device_visible={self.device_panel_visible}, backup_visible={self.backup_panel_visible}")

        # Get horizontal_container to inspect pack order
        horizontal_container = self.backup_panel.master
        print(f"[DEBUG _hide_backup_panel] Pack slaves BEFORE: {[str(w).split('.')[-1] for w in horizontal_container.pack_slaves()]}")

        # Unpack panel
        self.backup_panel.pack_forget()
        self.backup_panel_visible = False
        self.backup_toggle_btn.config(text="◀\n💾", bg=self.theme.get_color('toggle_backup_inactive'))

        # Calculate new width based on device panel state
        if self.device_panel_visible:
            new_width = 1220  # Just device panel open
        else:
            new_width = 820  # Both panels closed

        self.root.geometry(f"{new_width}x973")

        # macOS fix: Use after() to ensure proper rendering
        def _finalize_hide():
            self.root.update_idletasks()
            print(f"[DEBUG _hide_backup_panel] Pack slaves AFTER: {[str(w).split('.')[-1] for w in horizontal_container.pack_slaves()]}")
            print(f"[DEBUG _hide_backup_panel] EXIT - device_visible={self.device_panel_visible}, backup_visible={self.backup_panel_visible}")

        self.root.after(10, _finalize_hide)

    def _update_backup_panel_info(self, device_info):
        """Update backup panel with connected device information"""
        # Update device info labels
        model = device_info.get('model', 'Unknown Device')
        name = device_info.get('name', 'Unknown')
        ios_version = device_info.get('ios_version', 'Unknown')
        total_capacity = device_info.get('total_capacity')
        battery_level = device_info.get('battery_level')
        is_charging = device_info.get('is_charging')

        # Update labels
        self.backup_panel.device_name_label.config(text=name, fg="#2c3e50")
        self.backup_panel.device_model_label.config(text=f"Model: {model}")
        self.backup_panel.device_ios_label.config(text=f"iOS: {ios_version}")

        # Activation status
        is_activated = device_info.get('is_activated', False)
        activation_state = device_info.get('activation_state', 'Unknown')
        if is_activated:
            self.backup_panel.device_activation_label.config(text=f"Activation: ✓ {activation_state}", fg="#27ae60")
        else:
            self.backup_panel.device_activation_label.config(text=f"Activation: ✗ {activation_state}", fg="#e74c3c")

        # UDID (shortened for display)
        udid = device_info.get('udid', 'Unknown')
        if udid and udid != 'Unknown':
            # Show last 16 characters if UDID is long
            udid_display = f"...{udid[-16:]}" if len(udid) > 20 else udid
            self.backup_panel.device_udid_label.config(text=f"UDID: {udid_display}")
        else:
            self.backup_panel.device_udid_label.config(text="UDID: —")

        # Battery/charging status
        if battery_level is not None:
            charge_emoji = "🔌" if is_charging else "🔋"
            self.backup_panel.device_charging_label.config(
                text=f"Battery: {charge_emoji} {battery_level:.0f}%"
            )
        else:
            self.backup_panel.device_charging_label.config(text="Battery: —")

        # Device color and storage capacity configuration
        device_color_code = device_info.get('device_color')
        print(f"[DEBUG] Display: device_color_code from device_info = {device_color_code}")
        device_color = map_device_color_code(device_color_code)
        print(f"[DEBUG] Display: device_color after mapping = {device_color}")
        marketed_capacity = get_marketed_capacity(total_capacity)
        print(f"[DEBUG] Display: marketed_capacity = {marketed_capacity}")

        if device_color or marketed_capacity:
            config_parts = []
            if marketed_capacity:
                config_parts.append(marketed_capacity)
            if device_color:
                config_parts.append(device_color)

            print(f"[DEBUG] Display: config_parts = {config_parts}")
            if config_parts:
                self.backup_panel.device_color_capacity_label.config(
                    text=f"Configuration: {', '.join(config_parts)}"
                )
            else:
                self.backup_panel.device_color_capacity_label.config(text="Configuration: —")
        else:
            self.backup_panel.device_color_capacity_label.config(text="Configuration: —")

        # Trust status - check if device is trusted (has valid lockdown connection)
        if hasattr(self, 'current_device_lockdown') and self.current_device_lockdown:
            # Device is successfully paired and trusted
            self.backup_panel.device_trusted_label.config(text="Trusted: ✓ Trusted", fg="#27ae60")
        else:
            # Device is not trusted or pairing failed
            self.backup_panel.device_trusted_label.config(text="Trusted: ✗ Not Trusted", fg="#e74c3c")

        # Find My status - check in background thread to avoid GUI freeze
        if hasattr(self, 'current_device_lockdown') and self.current_device_lockdown:
            # Show "checking" status immediately (non-blocking)
            self.backup_panel.device_findmy_label.config(text="Find My: ⏳ Checking...", fg="#7f8c8d")

            # Check Find My status in background thread
            def check_findmy_background():
                try:
                    find_my_enabled = check_find_my_status(self.current_device_lockdown)
                    # Update label on main thread
                    self.root.after(0, lambda: self._update_backup_panel_findmy_status(find_my_enabled))
                except Exception as e:
                    # On error, show unknown status
                    self.root.after(0, lambda: self.backup_panel.device_findmy_label.config(
                        text="Find My: —", fg="#7f8c8d"
                    ))

            import threading
            findmy_thread = threading.Thread(target=check_findmy_background, daemon=True)
            findmy_thread.start()
        else:
            self.backup_panel.device_findmy_label.config(text="Find My: —", fg="#7f8c8d")

        # Update device image with wallpaper and frame
        screenshot = device_info.get('screenshot')
        if screenshot and PIL_AVAILABLE:
            # Determine if this is an iPad
            device_class = device_info.get('device_class', '').lower()
            is_ipad = 'ipad' in device_class or 'pad' in device_class

            # Add device frame overlay
            framed_img = self._add_device_frame(screenshot, is_ipad)

            # Convert to PhotoImage
            photo = ImageTk.PhotoImage(framed_img)

            # Remove old label if exists
            if self.backup_panel.device_image_label:
                self.backup_panel.device_image_label.destroy()

            # Hide placeholder
            self.backup_panel.device_image_placeholder.pack_forget()

            # Create new image label
            self.backup_panel.device_image_label = tk.Label(
                self.backup_panel.device_image_frame,
                image=photo,
                bg="#f0f0f0"
            )
            self.backup_panel.device_image_label.image = photo  # Keep reference
            self.backup_panel.device_image_label.pack(expand=True)

        # Update storage bar with actual device data
        self._update_backup_panel_storage(device_info)

        # Update last backup time from device info
        last_backup = device_info.get('last_backup_date')
        if last_backup:
            # Format the date if it's a datetime object
            if hasattr(last_backup, 'strftime'):
                formatted_date = last_backup.strftime('%Y-%m-%d %I:%M %p')
            else:
                formatted_date = str(last_backup)
            self.backup_panel.last_backup_label.config(text=f"Last backup: {formatted_date}")
        else:
            self.backup_panel.last_backup_label.config(text="Last backup: Never")

        # Update backup size and free space information
        self._update_backup_size_and_space(device_info)

    def _update_backup_panel_findmy_status(self, find_my_enabled):
        """Update Find My status label in backup panel (called from background thread)."""
        if find_my_enabled:
            self.backup_panel.device_findmy_label.config(text="Find My: ✓ Enabled", fg="#e74c3c")
        else:
            self.backup_panel.device_findmy_label.config(text="Find My: ✗ Disabled", fg="#27ae60")

    def _update_backup_size_and_space(self, device_info):
        """Update estimated backup size and free space at destination"""
        # Calculate estimated backup size (used space on device)
        used_space = device_info.get('used_space')
        if used_space:
            estimated_size_str = format_bytes(used_space)
            self.backup_panel.estimated_size_label.config(
                text=f"Estimated backup size: {estimated_size_str}",
                fg="#2c3e50"
            )
        else:
            self.backup_panel.estimated_size_label.config(
                text="Estimated backup size: —",
                fg="#7f8c8d"
            )

        # Get backup location and calculate free space
        backup_location = self.backup_panel.location_entry.get().strip()
        if backup_location:
            free_space_bytes = get_free_space_at_path(backup_location)
            if free_space_bytes is not None:
                free_space_str = format_bytes(free_space_bytes)

                # Check if there's enough space (used_space + 20% buffer)
                if used_space:
                    required_space = used_space * 1.2  # 20% buffer
                    has_enough_space = free_space_bytes >= required_space

                    if has_enough_space:
                        self.backup_panel.free_space_label.config(
                            text=f"Free space at destination: {free_space_str}",
                            fg="#27ae60"  # Green
                        )
                        # Enable backup button
                        self.backup_panel.start_backup_btn.config(state=tk.NORMAL)
                    else:
                        self.backup_panel.free_space_label.config(
                            text=f"Free space at destination: {free_space_str} (Insufficient!)",
                            fg="#e74c3c"  # Red
                        )
                        # Disable backup button
                        self.backup_panel.start_backup_btn.config(state=tk.DISABLED)
                else:
                    self.backup_panel.free_space_label.config(
                        text=f"Free space at destination: {free_space_str}",
                        fg="#2c3e50"
                    )
            else:
                self.backup_panel.free_space_label.config(
                    text="Free space at destination: Unable to check",
                    fg="#e67e22"  # Orange warning
                )
        else:
            self.backup_panel.free_space_label.config(
                text="Free space at destination: —",
                fg="#7f8c8d"
            )

    def _browse_backup_location(self, location_entry):
        """Browse for backup location folder"""
        initial_dir = location_entry.get().strip() or "C:\\"
        folder_selected = filedialog.askdirectory(
            title="Select Backup Location",
            initialdir=initial_dir
        )
        if folder_selected:
            location_entry.delete(0, tk.END)
            location_entry.insert(0, folder_selected)
            # Update free space after location changes
            self._on_backup_location_changed()

    def _on_backup_location_changed(self):
        """Called when the backup location is changed"""
        # Only update if we have a connected device with storage info
        if hasattr(self, 'current_device') and self.current_device:
            self._update_backup_size_and_space(self.current_device)

    def _update_backup_panel_storage(self, device_info):
        """Update the storage bar in the backup panel with real device data - multi-colored breakdown"""
        total = device_info.get('total_capacity')
        available = device_info.get('available_space')
        used = device_info.get('used_space')
        system_bytes = device_info.get('system_bytes', 0)

        if not (total and available):
            return  # Keep static placeholder if data unavailable

        used_bytes = used if used else (total - available)

        # Clear existing segments
        for widget in self.backup_panel.capacity_bar_container.winfo_children():
            widget.destroy()

        # Calculate storage breakdown by category
        # Since iOS doesn't expose detailed per-app storage via lockdown,
        # we'll create a reasonable estimation based on typical usage patterns

        # System (iOS + reserved space)
        system_pct = min(0.15, system_bytes / total) if total and system_bytes else 0.12

        # Estimate other categories based on remaining used space
        remaining_used = used_bytes - (system_pct * total)
        if remaining_used < 0:
            remaining_used = used_bytes * 0.85

        # Distribute remaining used space across categories (estimated)
        apps_pct = (remaining_used * 0.35) / total if total else 0
        photos_pct = (remaining_used * 0.40) / total if total else 0
        media_pct = (remaining_used * 0.15) / total if total else 0
        others_pct = (remaining_used * 0.10) / total if total else 0
        free_pct = available / total if total else 0

        # Define segments with colors (matching the design)
        segments = [
            ("System", "#2c3e50", system_pct),      # Deep blue
            ("Apps", "#16a085", apps_pct),           # Teal
            ("Photos", "#8e44ad", photos_pct),       # Purple
            ("Media", "#f39c12", media_pct),         # Yellow/Orange
            ("Others", "#e67e22", others_pct),       # Orange
            ("Free", "#95a5a6", free_pct)            # Grey
        ]

        # Create colored segments
        for label_text, color, width_fraction in segments:
            if width_fraction > 0.001:  # Only show if > 0.1%
                if label_text == "Free":
                    # Free space expands to fill remaining width
                    segment = tk.Frame(self.backup_panel.capacity_bar_container,
                                     bg=color, height=25)
                    segment.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
                else:
                    # Fixed-width segments based on percentage
                    segment_width = int(360 * width_fraction)  # Total bar width ~360px
                    segment = tk.Frame(self.backup_panel.capacity_bar_container,
                                     bg=color, height=25, width=segment_width)
                    segment.pack(side=tk.LEFT, fill=tk.Y)
                    segment.pack_propagate(False)  # Maintain fixed width

    def _reset_backup_panel(self):
        """Reset backup panel to placeholder state"""
        # Reset device info labels
        self.backup_panel.device_name_label.config(text="No Device Connected", fg="#7f8c8d")
        self.backup_panel.device_model_label.config(text="Model: —")
        self.backup_panel.device_ios_label.config(text="iOS: —")
        self.backup_panel.device_trusted_label.config(text="Trusted: —", fg="#7f8c8d")
        self.backup_panel.device_activation_label.config(text="Activation: —", fg="#7f8c8d")
        self.backup_panel.device_udid_label.config(text="UDID: —")
        self.backup_panel.device_charging_label.config(text="Charging: —")
        self.backup_panel.device_color_capacity_label.config(text="Capacity: —")
        self.backup_panel.device_findmy_label.config(text="Find My: —", fg="#7f8c8d")

        # Remove device image if it exists
        if self.backup_panel.device_image_label:
            self.backup_panel.device_image_label.destroy()
            self.backup_panel.device_image_label = None

        # Show the placeholder icon again
        self.backup_panel.device_image_placeholder.pack(expand=True)

        # Reset storage bar to static placeholder
        for widget in self.backup_panel.capacity_bar_container.winfo_children():
            widget.destroy()

        # Recreate static placeholder segments
        segments = [
            ("System", "#2c3e50", 0.20),
            ("Apps", "#16a085", 0.15),
            ("Photos", "#8e44ad", 0.25),
            ("Media", "#f39c12", 0.10),
            ("Others", "#e67e22", 0.08),
            ("Free", "#95a5a6", 0.22)
        ]

        for label_text, color, width_fraction in segments:
            segment = tk.Frame(self.backup_panel.capacity_bar_container, bg=color, height=25)
            segment.pack(side=tk.LEFT, fill=tk.Y, expand=True)

        # Reset last backup label
        self.backup_panel.last_backup_label.config(text="Last backup: —")

    def _start_device_monitoring(self):
        """Start background thread for device monitoring"""
        if not PYMOBILEDEVICE3_AVAILABLE:
            return

        # Use WMI event-driven monitoring on Windows, polling fallback elsewhere
        if WMI_AVAILABLE:
            self.device_monitor_thread = threading.Thread(
                target=self._monitor_devices_wmi,
                daemon=True,
                name="DeviceMonitor-WMI"
            )
        else:
            self.device_monitor_thread = threading.Thread(
                target=self._monitor_devices_polling,
                daemon=True,
                name="DeviceMonitor-Polling"
            )

        self.device_monitor_thread.start()
        print(f"Device monitoring started using {'WMI events' if WMI_AVAILABLE else 'polling'}")

    def _monitor_devices_wmi(self):
        """Monitor for iOS devices using Windows WMI events (event-driven)"""
        try:
            # Initialize COM for this thread (required for WMI)
            import pythoncom
            import time
            pythoncom.CoInitialize()

            try:
                c = wmi.WMI()

                # We need to watch for both Creation and Deletion events
                # Since we can't watch both simultaneously with one watcher,
                # we'll use a hybrid approach: use WMI events to trigger checks,
                # but also poll periodically to catch disconnections
                creation_watcher = c.watch_for(
                    notification_type="Creation",
                    wmi_class="Win32_USBControllerDevice",
                    delay_secs=1
                )

                last_check = time.time()
                check_interval = 2  # Check every 2 seconds for disconnections

                while self.monitoring_devices:
                    try:
                        # Check for creation events with a timeout
                        # This allows us to also check for disconnections periodically
                        current_time = time.time()

                        # Always check for devices (both connection and disconnection)
                        if current_time - last_check >= check_interval:
                            self._check_for_ios_device()
                            last_check = current_time

                        # Also check when a USB device is added
                        # Use a non-blocking check with timeout
                        time.sleep(0.5)  # Small sleep to avoid busy-waiting

                    except Exception as e:
                        if self.monitoring_devices:  # Only log if we're still supposed to be monitoring
                            print(f"WMI monitoring error: {e}")
                            time.sleep(2)
            finally:
                # Clean up COM
                pythoncom.CoUninitialize()

        except Exception as e:
            print(f"Failed to start WMI monitoring: {e}")
            print("Falling back to polling...")
            # Fall back to polling if WMI fails
            self._monitor_devices_polling()

    def _monitor_devices_polling(self):
        """Monitor for iOS devices using polling (fallback for non-Windows or WMI failure)"""
        import time
        while self.monitoring_devices:
            try:
                self._check_for_ios_device()
                time.sleep(2)  # Poll every 2 seconds
            except Exception as e:
                if self.monitoring_devices:
                    print(f"Device polling error: {e}")
                    time.sleep(2)

    def _prompt_for_trust(self, device, basic_info, device_key):
        """Show dialog prompting user to trust the device with auto-dismiss when trusted"""
        import tkinter as tk
        from tkinter import ttk
        import threading
        import time

        # Extract device info from basic_info
        serial = basic_info.get('serial', 'Unknown')
        connection_type = basic_info.get('connection_type', 'USB')
        device_name = basic_info.get('device_name', 'Unknown Device')
        model_name = basic_info.get('model_name', 'Unknown')
        ios_version = basic_info.get('ios_version', 'Unknown')
        product_type = basic_info.get('product_type', 'Unknown')
        udid = basic_info.get('udid', serial)

        # Create custom dialog window (taller to accommodate image)
        dialog = tk.Toplevel(self.root)
        dialog.title("iOS Device Trust Required")
        dialog.configure(bg=self.theme.get_color('dialog_bg'))
        dialog.resizable(False, False)
        dialog.transient(self.root)
        # Don't use grab_set() - allow user to close main program even when dialog is open

        # Create content frame with themed background
        content_frame = tk.Frame(dialog, bg=self.theme.get_color('dialog_bg'), padx=30, pady=25)
        content_frame.pack(fill=tk.BOTH, expand=True)

        # Title with modern styling
        title_label = tk.Label(content_frame, text="iOS Device Detected",
                               font=('Segoe UI', 16, 'bold'), bg="#f0f0f0", fg="#1a1a1a")
        title_label.pack(pady=(0, 5))

        # Subtitle
        subtitle_label = tk.Label(content_frame, text="Device Trust Required",
                                  font=('Segoe UI', 10), bg="#f0f0f0", fg="#e74c3c")
        subtitle_label.pack(pady=(0, 0))

        # Trust guide image with aspect ratio preserved (moved above device info)
        try:
            from PIL import Image, ImageTk
            import os
            image_path = get_resource_path('trust_guide.png')
            if os.path.exists(image_path):
                # Load image and resize while maintaining aspect ratio
                pil_image = Image.open(image_path)

                # Calculate new size maintaining aspect ratio (max width 300px)
                max_width = 300
                if pil_image.width > max_width:
                    aspect_ratio = pil_image.height / pil_image.width
                    new_width = max_width
                    new_height = int(new_width * aspect_ratio)
                    pil_image = pil_image.resize((new_width, new_height), Image.Resampling.LANCZOS)

                photo = ImageTk.PhotoImage(pil_image)

                # Create frame for image with transparent background support
                image_frame = tk.Frame(content_frame, bg="#f0f0f0")
                image_frame.pack(pady=(0, 0), padx=(28, 0))

                image_label = tk.Label(image_frame, image=photo, bg="#f0f0f0", borderwidth=0)
                image_label.image = photo  # Keep a reference
                image_label.pack()
        except Exception as e:
            # If image can't be loaded, just skip it
            print(f"[DEBUG] Could not load trust guide image: {e}")

        # Device info frame with modern styling
        info_frame = tk.Frame(content_frame, bg="#f8f9fa", relief=tk.FLAT)
        info_frame.pack(fill=tk.X, pady=(0, 8))

        info_inner = tk.Frame(info_frame, bg="#f8f9fa", padx=20, pady=15)
        info_inner.pack(fill=tk.BOTH)

        # Build device info with grid layout for better alignment
        row = 0
        info_items = []
        if model_name != "Unknown":
            info_items.append(("Model", model_name, "📱"))
        if device_name != "Unknown Device":
            info_items.append(("Name", device_name, "✏️"))
        if ios_version != "Unknown":
            info_items.append(("iOS", ios_version, "💿"))
        if product_type != "Unknown":
            info_items.append(("Type", product_type, "🔧"))
        info_items.append(("Connection", connection_type, "🔌"))

        # Show full UDID or last 16 characters if available
        if udid:
            # If UDID is longer than 40 chars, show last 16, otherwise show full
            udid_display = f"...{udid[-16:]}" if len(udid) > 40 else udid
            info_items.append(("UDID", udid_display, "🔑"))

        for label_text, value_text, emoji in info_items:
            # Emoji/Icon
            emoji_label = tk.Label(info_inner, text=emoji, font=('Segoe UI', 11),
                                  bg="#f8f9fa", fg="#555", width=2, anchor=tk.W)
            emoji_label.grid(row=row, column=0, sticky=tk.W, pady=3)

            # Label
            label = tk.Label(info_inner, text=f"{label_text}:", font=('Segoe UI', 9),
                           bg="#f8f9fa", fg="#666", anchor=tk.W, width=10)
            label.grid(row=row, column=1, sticky=tk.W, pady=3, padx=(5, 10))

            # Value (use Consolas for UDID for better readability)
            font_family = 'Consolas' if label_text == "UDID" else 'Segoe UI'
            value = tk.Label(info_inner, text=value_text, font=(font_family, 9, 'bold'),
                           bg="#f8f9fa", fg="#1a1a1a", anchor=tk.W)
            value.grid(row=row, column=2, sticky=tk.W, pady=3)

            row += 1

        # Instructions with better formatting
        instructions = ("Please unlock your device and tap 'Trust'\n"
                       "when prompted on your iPhone or iPad.\n\n"
                       "This dialog will close automatically once trusted.")
        instructions_label = tk.Label(content_frame, text=instructions, justify=tk.CENTER,
                                     font=('Segoe UI', 10), bg="#f0f0f0", fg="#555", pady=10)
        instructions_label.pack(pady=(0, 15))

        # Status label with modern styling
        status_label = tk.Label(content_frame, text="⏳ Waiting for trust...",
                               font=('Segoe UI', 9), bg="#f0f0f0", fg="#888")
        status_label.pack(pady=(0, 10))

        # Button frame
        button_frame = tk.Frame(content_frame, bg="#f0f0f0")
        button_frame.pack(side=tk.BOTTOM, pady=(10, 0))

        # Calculate window size based on content
        dialog.update_idletasks()
        # Use a reasonable default size that accommodates the content
        dialog_width = 520
        dialog_height = 800  # Increased to ensure image and device info are both visible
        dialog.geometry(f"{dialog_width}x{dialog_height}")

        # Center the dialog
        x = (dialog.winfo_screenwidth() // 2) - (dialog_width // 2)
        y = (dialog.winfo_screenheight() // 2) - (dialog_height // 2)
        dialog.geometry(f"{dialog_width}x{dialog_height}+{x}+{y}")

        dialog_closed = [False]  # Use list to avoid closure issues

        def close_dialog():
            """Close the dialog and clear the flag"""
            if not dialog_closed[0]:
                dialog_closed[0] = True
                # Clear the active prompt flag
                if hasattr(self, '_trust_prompt_active') and device_key in self._trust_prompt_active:
                    self._trust_prompt_active.remove(device_key)
                    print(f"[DEBUG] Trust dialog closed. Cleared prompt flag for: {device_key}")
                try:
                    dialog.destroy()
                except:
                    pass

        def check_trust_status():
            """Background thread to check if device is trusted"""
            consecutive_not_found = 0
            while not dialog_closed[0]:
                try:
                    # First check if device is still connected by listing devices
                    from pymobiledevice3.usbmux import list_devices as list_usbmux_devices

                    current_devices = list_usbmux_devices()
                    device_serials = [d.serial for d in current_devices]

                    if serial not in device_serials:
                        # Device disconnected
                        consecutive_not_found += 1
                        print(f"[DEBUG] Device {serial} not found in device list (count: {consecutive_not_found})")

                        # If device missing for 3 consecutive checks (1.5 seconds), it's truly disconnected
                        if consecutive_not_found >= 3:
                            print(f"[DEBUG] Device {serial} disconnected - closing trust dialog")
                            if not dialog_closed[0]:
                                dialog.after(0, lambda: status_label.config(text="🔌 Device disconnected", fg="#f39c12"))
                                time.sleep(0.3)
                                dialog.after(0, close_dialog)
                            break
                        time.sleep(0.5)
                        continue

                    # Device is still connected, reset counter
                    consecutive_not_found = 0

                    # Try to start a service that TRULY requires active trust
                    # Basic lockdown and get_value() work with just cached pairing,
                    # but starting services like AFC requires actual trust
                    test_lockdown = create_using_usbmux(serial=serial, autopair=False, pair_timeout=1)

                    # Try to start a service that requires trust
                    # AFC (Apple File Conduit) is a good choice as it definitely needs trust
                    from pymobiledevice3.services.afc import AfcService
                    afc = AfcService(lockdown=test_lockdown)
                    # Try to list root directory - this will fail if not trusted
                    afc.listdir('/')

                    # If we got here, device is truly trusted!
                    device_name = test_lockdown.get_value(key='DeviceName')
                    print(f"[DEBUG] Device {serial} is now trusted! (verified with AFC service access for {device_name})")

                    # Update status label on main thread
                    if not dialog_closed[0]:
                        dialog.after(0, lambda: status_label.config(text="✅ Device trusted!", fg="#27ae60"))
                        # Wait a moment to show the success message
                        time.sleep(0.5)
                        # Close dialog on main thread
                        dialog.after(0, close_dialog)
                        # Refresh device info panels to show updated trust status
                        dialog.after(0, self._update_backup_panel_info)
                        dialog.after(0, self._update_restore_panel_info)
                    break

                except Exception as e:
                    # Still not trusted or other error, keep checking
                    exception_type = type(e).__name__
                    # Don't log expected trust-related errors (these are normal during trust flow)
                    expected_errors = ['PairingDialogResponsePendingError', 'NotPairedError', 'PairingError']
                    if exception_type not in expected_errors:
                        # Log unexpected errors for debugging
                        if consecutive_not_found == 0:  # Only log if device is connected
                            print(f"[DEBUG] Trust check exception: {exception_type}: {str(e)[:100]}")
                    pass

                # Check every 500ms
                time.sleep(0.5)

        # Cancel button
        cancel_btn = ttk.Button(button_frame, text="Cancel", command=close_dialog)
        cancel_btn.pack(side=tk.LEFT, padx=5)

        # Handle window close button
        dialog.protocol("WM_DELETE_WINDOW", close_dialog)

        # Start background trust checking
        trust_thread = threading.Thread(target=check_trust_status, daemon=True)
        trust_thread.start()

        print(f"[DEBUG] Showing auto-dismiss trust dialog for device: {device_key}")

    def _prompt_for_activation(self, device_info):
        """Show dialog prompting user to activate the device with auto-dismiss when activated"""
        import tkinter as tk
        from tkinter import ttk
        import threading
        import time

        # Extract device info
        serial = device_info.get('udid', 'Unknown')
        device_name = device_info.get('name', 'Unknown Device')
        model_name = device_info.get('model', 'Unknown')
        ios_version = device_info.get('ios_version', 'Unknown')
        product_type = device_info.get('product_type', 'Unknown')
        udid = device_info.get('udid', serial)

        # Create custom dialog window
        dialog = tk.Toplevel(self.root)
        dialog.title("iOS Device Activation Required")
        dialog.configure(bg=self.theme.get_color('dialog_bg'))
        dialog.resizable(False, False)
        dialog.transient(self.root)
        # Non-modal - allow user to close main program

        # Create content frame
        content_frame = tk.Frame(dialog, bg=self.theme.get_color('dialog_bg'), padx=30, pady=25)
        content_frame.pack(fill=tk.BOTH, expand=True)

        # Title
        title_label = tk.Label(content_frame, text="iOS Device Detected",
                               font=('Segoe UI', 16, 'bold'),
                               bg=self.theme.get_color('dialog_bg'),
                               fg=self.theme.get_color('text_primary'))
        title_label.pack(pady=(0, 5))

        # Subtitle
        subtitle_label = tk.Label(content_frame, text="Device Activation Required",
                                  font=('Segoe UI', 10), bg="#f0f0f0", fg="#e74c3c")
        subtitle_label.pack(pady=(0, 0))

        # Activation guide image
        try:
            from PIL import Image, ImageTk
            import os
            image_path = get_resource_path('activation_guide.png')
            if os.path.exists(image_path):
                # Load and resize image
                pil_image = Image.open(image_path)

                # Calculate new size maintaining aspect ratio (max width 300px)
                max_width = 300
                if pil_image.width > max_width:
                    aspect_ratio = pil_image.height / pil_image.width
                    new_width = max_width
                    new_height = int(new_width * aspect_ratio)
                    pil_image = pil_image.resize((new_width, new_height), Image.Resampling.LANCZOS)

                photo = ImageTk.PhotoImage(pil_image)

                # Create frame for image
                image_frame = tk.Frame(content_frame, bg="#f0f0f0")
                image_frame.pack(pady=(0, 0), padx=(28, 0))

                image_label = tk.Label(image_frame, image=photo, bg="#f0f0f0", borderwidth=0)
                image_label.image = photo  # Keep a reference
                image_label.pack()
        except Exception as e:
            print(f"[DEBUG] Could not load activation guide image: {e}")

        # Device info frame
        info_frame = tk.Frame(content_frame, bg="#f8f9fa", relief=tk.FLAT)
        info_frame.pack(fill=tk.X, pady=(0, 8))

        info_inner = tk.Frame(info_frame, bg="#f8f9fa", padx=20, pady=15)
        info_inner.pack(fill=tk.BOTH)

        # Build device info with grid layout (Type and UDID removed to prevent clipping)
        row = 0
        info_items = []
        if model_name != "Unknown":
            info_items.append(("Model", model_name, "📱"))
        if device_name != "Unknown Device":
            info_items.append(("Name", device_name, "✏️"))
        if ios_version != "Unknown":
            info_items.append(("iOS", ios_version, "💿"))

        for label_text, value_text, emoji in info_items:
            # Emoji/Icon
            emoji_label = tk.Label(info_inner, text=emoji, font=('Segoe UI', 11),
                                  bg="#f8f9fa", fg="#555", width=2, anchor=tk.W)
            emoji_label.grid(row=row, column=0, sticky=tk.W, pady=3)

            # Label
            label = tk.Label(info_inner, text=f"{label_text}:", font=('Segoe UI', 9),
                           bg="#f8f9fa", fg="#666", anchor=tk.W, width=10)
            label.grid(row=row, column=1, sticky=tk.W, pady=3, padx=(5, 10))

            # Value
            font_family = 'Consolas' if label_text == "UDID" else 'Segoe UI'
            value = tk.Label(info_inner, text=value_text, font=(font_family, 9, 'bold'),
                           bg="#f8f9fa", fg="#1a1a1a", anchor=tk.W)
            value.grid(row=row, column=2, sticky=tk.W, pady=3)

            row += 1

        # Instructions
        instructions = ("Please activate your device following the on-screen\n"
                       "instructions shown in the image above.\n\n"
                       "This dialog will close automatically once activated.")
        instructions_label = tk.Label(content_frame, text=instructions, justify=tk.CENTER,
                                     font=('Segoe UI', 10), bg="#f0f0f0", fg="#555", pady=10)
        instructions_label.pack(pady=(0, 15))

        # Status label
        status_label = tk.Label(content_frame, text="⏳ Waiting for activation...",
                               font=('Segoe UI', 9), bg="#f0f0f0", fg="#888")
        status_label.pack(pady=(0, 10))

        # Button frame
        button_frame = tk.Frame(content_frame, bg="#f0f0f0")
        button_frame.pack(side=tk.BOTTOM, pady=(10, 0))

        # Calculate window size
        dialog.update_idletasks()
        dialog_width = 520
        dialog_height = 800
        dialog.geometry(f"{dialog_width}x{dialog_height}")

        # Center the dialog
        x = (dialog.winfo_screenwidth() // 2) - (dialog_width // 2)
        y = (dialog.winfo_screenheight() // 2) - (dialog_height // 2)
        dialog.geometry(f"{dialog_width}x{dialog_height}+{x}+{y}")

        dialog_closed = [False]  # Use list to avoid closure issues

        def close_dialog():
            """Close the dialog and clear the flag"""
            if not dialog_closed[0]:
                dialog_closed[0] = True
                # Clear the active prompt flag
                if hasattr(self, '_activation_prompt_active') and serial in self._activation_prompt_active:
                    self._activation_prompt_active.remove(serial)
                    print(f"[DEBUG] Activation dialog closed. Cleared prompt flag for: {serial}")
                try:
                    dialog.destroy()
                except:
                    pass

        def check_activation_status_loop():
            """Background thread to check if device is activated"""
            while not dialog_closed[0]:
                try:
                    # Check if device is still connected and get activation status
                    if self.current_device_lockdown:
                        is_activated, activation_state = check_activation_status(self.current_device_lockdown)

                        if is_activated:
                            # Device is activated!
                            print(f"[DEBUG] Device {serial} is now activated!")
                            if not dialog_closed[0]:
                                dialog.after(0, lambda: status_label.config(text="✓ Device activated!", fg="#27ae60"))
                                time.sleep(0.5)
                                dialog.after(0, close_dialog)
                                # Refresh device info panels to show updated activation status
                                dialog.after(0, self._update_backup_panel_info)
                                dialog.after(0, self._update_restore_panel_info)
                            break
                        else:
                            # Still not activated
                            print(f"[DEBUG] Device {serial} activation status: {activation_state}")

                    time.sleep(2)  # Check every 2 seconds

                except Exception as e:
                    print(f"[DEBUG] Error checking activation status: {e}")
                    time.sleep(2)

        # Handle window close button
        dialog.protocol("WM_DELETE_WINDOW", close_dialog)

        # Start background activation checking
        activation_thread = threading.Thread(target=check_activation_status_loop, daemon=True)
        activation_thread.start()

        print(f"[DEBUG] Showing auto-dismiss activation dialog for device: {device_name}")

    def _prompt_for_find_my(self, device_info):
        """Show dialog prompting user to disable Find My with auto-dismiss when disabled"""
        import tkinter as tk
        from tkinter import ttk
        import threading
        import time

        # Extract device info
        serial = device_info.get('udid', 'Unknown')
        device_name = device_info.get('name', 'Unknown Device')
        model_name = device_info.get('model', 'Unknown')
        ios_version = device_info.get('ios_version', 'Unknown')
        product_type = device_info.get('product_type', 'Unknown')
        udid = device_info.get('udid', serial)

        # Create custom dialog window
        dialog = tk.Toplevel(self.root)
        dialog.title("Find My Must Be Disabled")
        dialog.configure(bg=self.theme.get_color('dialog_bg'))
        dialog.resizable(False, False)
        dialog.transient(self.root)
        # Non-modal - allow user to close main program

        # Create content frame
        content_frame = tk.Frame(dialog, bg=self.theme.get_color('dialog_bg'), padx=30, pady=25)
        content_frame.pack(fill=tk.BOTH, expand=True)

        # Title
        title_label = tk.Label(content_frame, text="iOS Device Detected",
                               font=('Segoe UI', 16, 'bold'), bg="#f0f0f0", fg="#1a1a1a")
        title_label.pack(pady=(0, 5))

        # Subtitle
        subtitle_label = tk.Label(content_frame, text="Find My iPhone Is Enabled",
                                  font=('Segoe UI', 10), bg="#f0f0f0", fg="#e74c3c")
        subtitle_label.pack(pady=(0, 0))

        # Find My guide image
        try:
            from PIL import Image, ImageTk
            import os
            image_path = get_resource_path('findmy_guide.png')
            if os.path.exists(image_path):
                # Load and resize image
                pil_image = Image.open(image_path)

                # Calculate new size maintaining aspect ratio (max width 300px)
                max_width = 300
                if pil_image.width > max_width:
                    aspect_ratio = pil_image.height / pil_image.width
                    new_width = max_width
                    new_height = int(new_width * aspect_ratio)
                    pil_image = pil_image.resize((new_width, new_height), Image.Resampling.LANCZOS)

                photo = ImageTk.PhotoImage(pil_image)

                # Create frame for image
                image_frame = tk.Frame(content_frame, bg="#f0f0f0")
                image_frame.pack(pady=(0, 0), padx=(28, 0))

                image_label = tk.Label(image_frame, image=photo, bg="#f0f0f0", borderwidth=0)
                image_label.image = photo  # Keep a reference
                image_label.pack()
        except Exception:
            pass

        # Device info frame
        info_frame = tk.Frame(content_frame, bg="#f8f9fa", relief=tk.FLAT)
        info_frame.pack(fill=tk.X, pady=(0, 8))

        info_inner = tk.Frame(info_frame, bg="#f8f9fa", padx=20, pady=15)
        info_inner.pack(fill=tk.BOTH)

        # Build device info with grid layout
        row = 0
        info_items = []
        if model_name != "Unknown":
            info_items.append(("Model", model_name, "📱"))
        if device_name != "Unknown Device":
            info_items.append(("Name", device_name, "✏️"))
        if ios_version != "Unknown":
            info_items.append(("iOS", ios_version, "💿"))

        for label_text, value_text, emoji in info_items:
            # Emoji/Icon
            emoji_label = tk.Label(info_inner, text=emoji, font=('Segoe UI', 11),
                                  bg="#f8f9fa", fg="#555", width=2, anchor=tk.W)
            emoji_label.grid(row=row, column=0, sticky=tk.W, pady=3)

            # Label
            label = tk.Label(info_inner, text=f"{label_text}:", font=('Segoe UI', 9),
                           bg="#f8f9fa", fg="#666", anchor=tk.W, width=10)
            label.grid(row=row, column=1, sticky=tk.W, pady=3, padx=(5, 10))

            # Value
            font_family = 'Consolas' if label_text == "UDID" else 'Segoe UI'
            value = tk.Label(info_inner, text=value_text, font=(font_family, 9, 'bold'),
                           bg="#f8f9fa", fg="#1a1a1a", anchor=tk.W)
            value.grid(row=row, column=2, sticky=tk.W, pady=3)

            row += 1

        # Instructions
        instructions = ("Please disable Find My iPhone on your device following\n"
                       "the instructions shown in the image above.\n\n"
                       "This dialog will close automatically once disabled.")
        instructions_label = tk.Label(content_frame, text=instructions, justify=tk.CENTER,
                                     font=('Segoe UI', 10), bg="#f0f0f0", fg="#555", pady=10)
        instructions_label.pack(pady=(0, 15))

        # Status label
        status_label = tk.Label(content_frame, text="⏳ Waiting for Find My to be disabled...",
                               font=('Segoe UI', 9), bg="#f0f0f0", fg="#888")
        status_label.pack(pady=(0, 10))

        # Button frame
        button_frame = tk.Frame(content_frame, bg="#f0f0f0")
        button_frame.pack(side=tk.BOTTOM, pady=(10, 0))

        # Calculate window size
        dialog.update_idletasks()
        dialog_width = 520
        dialog_height = 800
        dialog.geometry(f"{dialog_width}x{dialog_height}")

        # Center the dialog
        x = (dialog.winfo_screenwidth() // 2) - (dialog_width // 2)
        y = (dialog.winfo_screenheight() // 2) - (dialog_height // 2)
        dialog.geometry(f"{dialog_width}x{dialog_height}+{x}+{y}")

        dialog_closed = [False]  # Use list to avoid closure issues

        def close_dialog():
            """Close the dialog and clear the flag"""
            if not dialog_closed[0]:
                dialog_closed[0] = True
                # Clear the active prompt flag
                if hasattr(self, '_findmy_prompt_active') and serial in self._findmy_prompt_active:
                    self._findmy_prompt_active.remove(serial)
                try:
                    dialog.destroy()
                except:
                    pass

        def check_find_my_status_loop():
            """Background thread to check if Find My is disabled"""
            while not dialog_closed[0]:
                try:
                    # Check if device is still connected and get Find My status
                    if self.current_device_lockdown:
                        find_my_enabled = check_find_my_status(self.current_device_lockdown)

                        if not find_my_enabled:
                            # Find My is disabled!
                            if not dialog_closed[0]:
                                # Update device_info with new Find My status
                                updated_device_info = device_info.copy()
                                updated_device_info['find_my_enabled'] = False

                                # Update current_device_info if it exists
                                if hasattr(self, 'current_device_info') and self.current_device_info:
                                    self.current_device_info['find_my_enabled'] = False

                                dialog.after(0, lambda: status_label.config(text="✓ Find My disabled!", fg="#27ae60"))
                                time.sleep(0.5)
                                dialog.after(0, close_dialog)
                                # Refresh device info panels to show updated Find My status
                                dialog.after(0, lambda: self._update_backup_panel_info(updated_device_info))
                                dialog.after(0, lambda: self._update_restore_panel_info(updated_device_info))
                                dialog.after(0, lambda: self._update_device_info(updated_device_info))
                            break

                    time.sleep(2)  # Check every 2 seconds

                except Exception:
                    time.sleep(2)

        # Handle window close button
        dialog.protocol("WM_DELETE_WINDOW", close_dialog)

        # Start background Find My checking
        findmy_thread = threading.Thread(target=check_find_my_status_loop, daemon=True)
        findmy_thread.start()

    def _show_device_loading_state(self):
        """Show loading placeholder in device panel while detecting device"""
        # Update device info labels to show loading state
        if hasattr(self, 'restore_device_name_label'):
            self.restore_device_name_label.config(text="🔄 Detecting device...")
            self.restore_device_model_label.config(text="Please wait a moment", fg="#3498db")
            self.restore_device_ios_label.config(text="Retrieving device information...", fg="#3498db")
            self.restore_device_trusted_label.config(text="")

        # Update header status
        if hasattr(self, 'restore_device_status_label'):
            self.restore_device_status_label.config(text="| Detecting...", fg="#3498db")

        print("[STARTUP] Showing device loading state - detection running in background")

    def _check_for_ios_device_async(self):
        """Start device detection in background thread to avoid blocking UI"""
        def detect_in_background():
            # Run the actual detection (which can take 2-5 seconds)
            ensure_pymobiledevice3_loaded()
            self._check_for_ios_device()

        # Start background thread
        thread = threading.Thread(target=detect_in_background, daemon=True)
        thread.start()
        print("[STARTUP] Device detection started in background thread")

    def _check_for_ios_device(self):
        """Check for connected iOS devices and handle connection/disconnection with trust detection"""
        if not PYMOBILEDEVICE3_AVAILABLE:
            return

        if list_devices is None:
            return

        try:
            # Get list of connected USB devices
            devices = list_devices()

            if devices:
                # Device(s) found
                device = devices[0]  # Use first device if multiple connected

                try:
                    # Try to get device info using create_using_usbmux helper
                    # This requires the device to be trusted
                    # Set short timeout (3 seconds) so we can detect untrusted devices quickly
                    # without blocking for too long
                    lockdown = create_using_usbmux(serial=device.serial, autopair=True, pair_timeout=3)

                    # Store lockdown for backup functionality
                    self.current_device_lockdown = lockdown

                    # Check activation status
                    is_activated, activation_state = check_activation_status(lockdown)
                    # Removed debug spam: print(f"[DEBUG] Device activation status: {activation_state} (is_activated: {is_activated})")

                    # Check Find My status
                    find_my_enabled = check_find_my_status(lockdown)

                    # Get storage information
                    total_capacity = lockdown.get_value('com.apple.disk_usage', 'TotalDataCapacity')
                    available_space = lockdown.get_value('com.apple.disk_usage', 'TotalDataAvailable')

                    # Get detailed disk usage breakdown
                    try:
                        disk_usage = {}
                        disk_usage['AmountDataReserved'] = lockdown.get_value('com.apple.disk_usage', 'AmountDataReserved') or 0
                        disk_usage['AmountDataAvailable'] = lockdown.get_value('com.apple.disk_usage', 'AmountDataAvailable') or 0
                        disk_usage['TotalSystemCapacity'] = lockdown.get_value('com.apple.disk_usage', 'TotalSystemCapacity') or 0
                        disk_usage['TotalSystemAvailable'] = lockdown.get_value('com.apple.disk_usage', 'TotalSystemAvailable') or 0
                        # Calculate breakdown by category (estimated based on iOS disk usage reporting)
                        # Note: iOS doesn't expose per-app storage via lockdown, so we estimate categories
                        system_bytes = disk_usage.get('TotalSystemCapacity', 0) - disk_usage.get('TotalSystemAvailable', 0)
                    except Exception as e:
                        print(f"[DEBUG] Could not get detailed disk usage: {e}")
                        disk_usage = {}
                        system_bytes = 0

                    # Get battery information
                    try:
                        battery_level = lockdown.get_value('com.apple.mobile.battery', 'BatteryCurrentCapacity')
                        is_charging = lockdown.get_value('com.apple.mobile.battery', 'BatteryIsCharging')
                    except:
                        battery_level = None
                        is_charging = None

                    # Check if this is a new device or if we need to fetch wallpaper/icons
                    is_new_device = (self.last_detected_udid != lockdown.udid)

                    # Get additional device properties (only log once for new devices)
                    try:
                        # Device color/enclosure color
                        device_color = lockdown.get_value('', 'DeviceEnclosureColor')
                        device_color_code = lockdown.get_value('', 'DeviceColor')
                        if is_new_device:
                            print(f"[DEBUG] DeviceEnclosureColor: {device_color}, DeviceColor: {device_color_code}")

                        # Prefer DeviceEnclosureColor over DeviceColor for display
                        # DeviceEnclosureColor = actual device body color (what we want to show)
                        # DeviceColor = often the front glass color, which may differ from body color
                        # Example: Silver iPhone 6S Plus has #b9b7ba (silver) enclosure but #272728 (black) front
                        if device_color is not None:
                            # Use the enclosure color (this is the "device color" users think of)
                            final_color = device_color
                            if is_new_device:
                                print(f"[DEBUG] Using DeviceEnclosureColor for display: {final_color}")
                        elif device_color_code is not None:
                            # Fall back to DeviceColor if enclosure color not available
                            final_color = device_color_code
                            if is_new_device:
                                print(f"[DEBUG] Using DeviceColor as fallback: {final_color}")
                        else:
                            final_color = None

                        # Store the final color choice in device_color_code for consistency
                        device_color_code = final_color
                    except Exception as e:
                        device_color = None
                        device_color_code = None
                        if is_new_device:
                            print(f"[DEBUG] Error getting device color: {e}")

                    try:
                        # Wi-Fi and Bluetooth addresses
                        wifi_address = lockdown.get_value('', 'WiFiAddress')
                        bluetooth_address = lockdown.get_value('', 'BluetoothAddress')
                        if is_new_device:
                            print(f"[DEBUG] Device addresses - WiFi: {wifi_address}, Bluetooth: {bluetooth_address}")
                    except Exception as e:
                        wifi_address = None
                        bluetooth_address = None
                        if is_new_device:
                            print(f"[DEBUG] Error getting addresses: {e}")

                    try:
                        # Region, language, and locale settings
                        region_info = lockdown.get_value('', 'RegionInfo')
                        language = lockdown.get_value('', 'Language')
                        locale = lockdown.get_value('', 'Locale')
                        if is_new_device:
                            print(f"[DEBUG] Region: {region_info}, Language: {language}, Locale: {locale}")
                    except Exception as e:
                        region_info = None
                        language = None
                        locale = None
                        if is_new_device:
                            print(f"[DEBUG] Error getting locale info: {e}")

                    # Only fetch wallpaper and icons once per device connection
                    if is_new_device or not self.cached_device_data:
                        print("[DEBUG] Fetching wallpaper and icons for new device connection...")
                        # Fetch device wallpaper using SpringBoard service (no Developer Mode needed!)
                        wallpaper_img, wallpaper_error = self._fetch_device_wallpaper(lockdown)

                        # Composite app icons onto wallpaper for realistic home screen view
                        if wallpaper_img and not wallpaper_error:
                            wallpaper_img = self._composite_icons_on_wallpaper(wallpaper_img, lockdown)

                        # Cache the wallpaper data
                        self.cached_device_data = {
                            'screenshot': wallpaper_img,
                            'screenshot_error': wallpaper_error
                        }
                    else:
                        #print("[DEBUG] Using cached wallpaper and icons (avoiding redundant fetch)")
                        wallpaper_img = self.cached_device_data.get('screenshot')
                        wallpaper_error = self.cached_device_data.get('screenshot_error')

                    device_info = {
                        'udid': lockdown.udid,
                        'name': lockdown.display_name,
                        'model': get_device_model(lockdown.product_type),
                        'ios_version': lockdown.product_version,
                        'product_type': lockdown.product_type,
                        'device_class': lockdown.device_class.name if hasattr(lockdown.device_class, 'name') else str(lockdown.device_class),
                        'hardware_model': lockdown.hardware_model,
                        # Activation status
                        'is_activated': is_activated,
                        'activation_state': activation_state,
                        # Find My status
                        'find_my_enabled': find_my_enabled,
                        # Storage info in bytes
                        'total_capacity': total_capacity,
                        'available_space': available_space,
                        'used_space': total_capacity - available_space if (total_capacity and available_space) else None,
                        'disk_usage': disk_usage,
                        'system_bytes': system_bytes,
                        # Battery information
                        'battery_level': battery_level,
                        'is_charging': is_charging,
                        # Additional device properties
                        'device_color': device_color_code,  # Use numeric DeviceColor code, not hex DeviceEnclosureColor
                        'wifi_address': wifi_address,
                        'bluetooth_address': bluetooth_address,
                        'region_info': region_info,
                        'language': language,
                        'locale': locale,
                        # Wallpaper image (with icons composited if available)
                        'screenshot': wallpaper_img,
                        'screenshot_error': wallpaper_error,
                    }

                    # Search for local backup matching this device
                    # Include custom backup location from Backup Location field
                    custom_backup_path = None
                    if hasattr(self, 'backup_panel') and hasattr(self.backup_panel, 'location_entry'):
                        custom_backup_path = self.backup_panel.location_entry.get().strip()

                    local_backup = find_local_backup_for_device(lockdown.udid, additional_paths=custom_backup_path)
                    device_info['local_backup'] = local_backup
                    if local_backup:
                        device_info['last_backup_date'] = local_backup.get('date')
                        device_info['backup_path'] = local_backup.get('path')
                    else:
                        device_info['last_backup_date'] = None
                        device_info['backup_path'] = None

                    # Check if this is a new device or same device
                    if self.last_detected_udid != device_info['udid']:
                        # New device connected
                        self.last_detected_udid = device_info['udid']
                        # Schedule UI update on main thread
                        self.root.after(0, lambda: self._on_device_connected(device_info))

                except Exception as e:
                    import time
                    import traceback
                    error_msg = str(e)
                    error_type = type(e).__name__

                    # Check if this is a trust/pairing error
                    # Check both the error message and exception type
                    trust_keywords = [
                        'pairing', 'trust', 'pair', 'pairingdialogresponsepending',
                        'invalidhostid', 'userdeniedpairing', 'notpaired',
                        'pairrecord', 'escrowbag', 'lockdownerror', 'devicenotfound'
                    ]
                    is_trust_error = any(keyword in error_msg.lower() for keyword in trust_keywords)

                    # Also check exception type names
                    # PairingDialogResponsePendingError is thrown when "Trust This Computer?" dialog is shown
                    # DeviceNotFoundError is thrown when device is disconnected during pairing
                    trust_exception_types = [
                        'PairingError',
                        'NotPairedError',
                        'LockdownError',
                        'DeviceNotFoundError',
                        'PairingDialogResponsePendingError'  # The key one - thrown immediately!
                    ]
                    is_trust_error = is_trust_error or error_type in trust_exception_types

                    # Check if this is a restore/reboot error (expected during restore operations)
                    # SSLEOFError and ConnectionFailedError occur when device is rebooting after restore
                    restore_exception_types = [
                        'SSLEOFError',
                        'ConnectionFailedError',
                        'ConnectionAbortedError'
                    ]
                    is_restore_error = (error_type in restore_exception_types and
                                       getattr(self, 'restore_in_progress', False))

                    # Only print debug info for truly unexpected errors
                    if not is_trust_error and not is_restore_error:
                        print(f"[DEBUG] Unexpected exception type: {error_type}")
                        print(f"[DEBUG] Error getting device info: {e}")
                        print(f"[DEBUG] Full traceback:")
                        traceback.print_exc()

                    if is_trust_error:
                        # Device is connected but not trusted
                        # Show basic info and prompt user to trust
                        # (No need to log - this is expected during trust flow)

                        # Try to get basic device info (some info available without full trust)
                        device_name = "Unknown Device"
                        product_type = "Unknown"
                        ios_version = "Unknown"
                        model_name = "Unknown"
                        device_color = None
                        udid = device.serial

                        try:
                            # Try to create a basic lockdown connection without pairing
                            # This may give us access to some basic device properties
                            temp_lockdown = create_using_usbmux(serial=device.serial, autopair=False, pair_timeout=0)

                            # Try to get basic info (some may be available without full trust)
                            try:
                                device_name = temp_lockdown.get_value(key='DeviceName') or device_name
                            except:
                                pass
                            try:
                                product_type = temp_lockdown.get_value(key='ProductType') or product_type
                            except:
                                pass
                            try:
                                ios_version = temp_lockdown.get_value(key='ProductVersion') or ios_version
                            except:
                                pass
                            try:
                                device_color = temp_lockdown.get_value(key='DeviceColor')
                            except:
                                pass
                            try:
                                udid = temp_lockdown.get_value(key='UniqueDeviceID') or udid
                            except:
                                pass

                            # Convert ProductType to friendly model name
                            if product_type in DEVICE_MODELS:
                                model_name = DEVICE_MODELS[product_type]
                        except Exception as e:
                            print(f"[DEBUG] Could not get basic device info: {e}")
                            # Use defaults

                        # Create basic device info
                        basic_info = {
                            'serial': device.serial,
                            'connection_type': device.connection_type,
                            'is_trusted': False,
                            'trust_error': error_msg,
                            'device_name': device_name,
                            'model_name': model_name,
                            'product_type': product_type,
                            'ios_version': ios_version,
                            'device_color': device_color,
                            'udid': udid,
                        }

                        # Check if we should show trust prompt (don't spam with multiple prompts)
                        # Use a flag to track if a prompt is currently being shown for this device
                        if not hasattr(self, '_trust_prompt_active'):
                            self._trust_prompt_active = set()

                        device_key = device.serial
                        if device_key not in self._trust_prompt_active:
                            # Mark this device as having an active trust prompt
                            self._trust_prompt_active.add(device_key)
                            print(f"[DEBUG] Showing trust prompt for device: {device_key}")

                            # Schedule trust prompt on main thread
                            # Pass device_key so we can clear the flag when done
                            self.root.after(0, lambda dk=device_key, bi=basic_info:
                                          self._prompt_for_trust(device, bi, dk))
                        else:
                            print(f"[DEBUG] Trust prompt already active for device: {device_key}, skipping")

            else:
                # No devices found
                if self.last_detected_udid is not None:
                    # Device was connected, now disconnected
                    self.last_detected_udid = None
                    # Schedule UI update on main thread
                    self.root.after(0, self._on_device_disconnected)

        except Exception as e:
            print(f"Error checking for iOS devices: {e}")

    def _fetch_device_wallpaper(self, lockdown):
        """Fetch wallpaper from connected iOS device using SpringBoard service"""
        if not PYMOBILEDEVICE3_AVAILABLE:
            print("[DEBUG] pymobiledevice3 not available, cannot fetch wallpaper")
            return None, "pymobiledevice3 not available"

        if not PIL_AVAILABLE:
            print("[DEBUG] PIL not available, cannot process wallpaper")
            return None, "PIL not available"

        try:
            print("[DEBUG] ========== WALLPAPER FETCH ATTEMPT ==========")
            print(f"[DEBUG] Lockdown object: {lockdown}")
            print(f"[DEBUG] Device UDID: {lockdown.udid}")
            print(f"[DEBUG] Device name: {lockdown.display_name}")

            # Check if device is paired
            try:
                pair_record = lockdown.pair_record
                print(f"[DEBUG] Pair record exists: {pair_record is not None}")
                if not pair_record:
                    print("[DEBUG] Device not paired")
                    return None, "Device not paired - please trust this computer"
            except Exception as pair_err:
                print(f"[DEBUG] Could not check pairing status: {pair_err}")

            # Use SpringBoard service to get wallpaper (does NOT require Developer Mode!)
            try:
                print("[DEBUG] Creating SpringBoardServicesService...")
                springboard = SpringBoardServicesService(lockdown=lockdown)
                print("[DEBUG] SpringBoardServicesService created successfully")

                print("[DEBUG] Calling get_wallpaper_pngdata()...")
                wallpaper_data = springboard.get_wallpaper_pngdata()
                print(f"[DEBUG] get_wallpaper_pngdata() returned, data type: {type(wallpaper_data)}")

                # Convert to PIL Image
                if wallpaper_data:
                    print(f"[DEBUG] Wallpaper data received: {len(wallpaper_data)} bytes")
                    img = Image.open(BytesIO(wallpaper_data))
                    print(f"[DEBUG] Wallpaper image created: {img.size}, mode: {img.mode}")
                    print("[DEBUG] ========== WALLPAPER FETCH SUCCESS ==========")
                    return img, None
                else:
                    print("[DEBUG] No wallpaper data returned (None or empty)")
                    return None, "No wallpaper data"

            except Exception as service_error:
                service_error_msg = str(service_error)
                print(f"[ERROR] SpringBoard exception type: {type(service_error).__name__}")
                print(f"[ERROR] SpringBoard error: {service_error_msg}")
                import traceback
                print("[ERROR] Full traceback:")
                traceback.print_exc()

                # Provide specific error messages
                if "InvalidService" in service_error_msg:
                    return None, "SpringBoard service unavailable"
                elif "PairingDialogResponsePending" in service_error_msg:
                    return None, "Tap 'Trust' on device"
                elif "PasswordProtected" in service_error_msg:
                    return None, "Device is locked - unlock first"
                else:
                    return None, f"Service error: {service_error_msg[:50]}"

        except Exception as e:
            error_msg = str(e)
            print(f"[ERROR] Outer exception in _fetch_device_wallpaper: {error_msg}")
            import traceback
            traceback.print_exc()
            return None, f"Wallpaper error: {error_msg[:50]}"

    def _composite_icons_on_wallpaper(self, wallpaper_img, lockdown, max_icons=20):
        """Composite app icons onto wallpaper to create realistic home screen view"""
        if not PYMOBILEDEVICE3_AVAILABLE or not PIL_AVAILABLE or not wallpaper_img:
            return wallpaper_img

        try:
            print("[DEBUG] ========== COMPOSITING APP ICONS ON WALLPAPER ==========")

            # Create SpringBoard service
            springboard = SpringBoardServicesService(lockdown=lockdown)

            # Get icon state (all apps and their arrangement)
            print("[DEBUG] Getting icon state...")
            icon_state = springboard.get_icon_state()

            if not icon_state:
                print("[DEBUG] No icon state returned, returning wallpaper as-is")
                return wallpaper_img

            # Debug: Print icon_state structure
            print(f"[DEBUG] icon_state type: {type(icon_state)}")
            print(f"[DEBUG] icon_state length: {len(icon_state) if isinstance(icon_state, (list, dict)) else 'N/A'}")

            # Extract bundle IDs from first page and dock separately
            home_screen_icons = []
            dock_icons = []

            def extract_bundle_ids_to_list(items, target_list, depth=0):
                """Recursively extract bundle IDs from nested structures"""
                if isinstance(items, list):
                    for item in items:
                        if isinstance(item, dict):
                            # Check if this is an app icon
                            if 'bundleIdentifier' in item:
                                bundle_id = item['bundleIdentifier']
                                if bundle_id and bundle_id not in target_list:
                                    target_list.append(bundle_id)
                            # Check for nested lists (folders, etc.)
                            for key, value in item.items():
                                if isinstance(value, list) and depth < 2:
                                    extract_bundle_ids_to_list(value, target_list, depth + 1)
                        elif isinstance(item, list):
                            extract_bundle_ids_to_list(item, target_list, depth + 1)

            # Process icon_state structure
            # Typically: [dock, home_page, other_pages...]
            if isinstance(icon_state, list) and len(icon_state) > 0:
                # First item is usually the dock
                print(f"[DEBUG] Processing dock (index 0)...")
                extract_bundle_ids_to_list([icon_state[0]], dock_icons)
                print(f"[DEBUG] Found {len(dock_icons)} dock icons")

                # Second item is often the home screen
                if len(icon_state) > 1:
                    print(f"[DEBUG] Processing home screen (index 1)...")
                    extract_bundle_ids_to_list([icon_state[1]], home_screen_icons)
                    print(f"[DEBUG] Found {len(home_screen_icons)} home screen icons")

            # Limit home screen icons (leave room for dock)
            home_screen_icons = home_screen_icons[:16]  # Max 16 on home screen (4x4 grid)
            dock_icons = dock_icons[:4]  # Max 4 in dock

            print(f"[DEBUG] Using {len(home_screen_icons)} home screen + {len(dock_icons)} dock icons")

            if not home_screen_icons and not dock_icons:
                return wallpaper_img

            # === NORMALIZE WALLPAPER TO STANDARD DIMENSIONS ===
            # Use iPhone 12/13/14 dimensions as standard (1170x2532)
            # This ensures consistent icon and text positioning across all devices
            STANDARD_WIDTH = 1170
            STANDARD_HEIGHT = 2532

            print(f"[DEBUG] Original wallpaper size: {wallpaper_img.size}")

            # Resize wallpaper to standard dimensions
            # Use LANCZOS for high-quality downsampling
            wallpaper_normalized = wallpaper_img.resize(
                (STANDARD_WIDTH, STANDARD_HEIGHT),
                Image.Resampling.LANCZOS
            )

            print(f"[DEBUG] Normalized wallpaper size: {wallpaper_normalized.size}")

            # Create a copy of normalized wallpaper to composite onto
            composite = wallpaper_normalized.copy().convert('RGBA')
            wallpaper_width, wallpaper_height = composite.size

            # === POSITIONING CONFIGURATION ===
            # Fine-tuned for 1170x2532 normalized dimensions to match real iPhone layout
            # Adjust these percentages to perfectly align icons with actual device appearance
            TIME_Y_PERCENT = 0.12        # Time position from top (12% ≈ 304px) - moved down for larger font
            HOME_ICONS_Y_PERCENT = 0.33  # Home screen icons start (30% ≈ 760px)
            DOCK_Y_PERCENT = 0.875       # Dock position (87.5% ≈ 2216px)

            # Icon sizing
            cols = 4
            icon_size = int(wallpaper_width / 5.8)  # Slightly smaller for realistic sizing
            horizontal_padding = int(icon_size * 0.30)  # Horizontal space between icons (30% of icon size)
            vertical_padding = int(icon_size * 0.45)    # Vertical space between rows (45% of icon size - more spacing)

            print(f"[DEBUG] Icon size: {icon_size}px, H-Padding: {horizontal_padding}px, V-Padding: {vertical_padding}px")

            # === COMPOSITE HOME SCREEN ICONS ===
            # Starting position (roughly where icons start on iOS - below status bar/time)
            start_y = int(wallpaper_height * HOME_ICONS_Y_PERCENT)
            start_x = int((wallpaper_width - (cols * icon_size + (cols-1) * horizontal_padding)) / 2)

            print(f"[DEBUG] Home screen start position: ({start_x}, {start_y})")

            print(f"[DEBUG] Compositing {len(home_screen_icons)} home screen icons...")
            for idx, bundle_id in enumerate(home_screen_icons):
                try:
                    icon_data = springboard.get_icon_pngdata(bundle_id)

                    if icon_data:
                        icon_img = Image.open(BytesIO(icon_data)).convert('RGBA')
                        icon_img = icon_img.resize((icon_size, icon_size), Image.Resampling.LANCZOS)

                        # Calculate position in grid
                        row = idx // cols
                        col = idx % cols
                        x = start_x + col * (icon_size + horizontal_padding)
                        y = start_y + row * (icon_size + vertical_padding)

                        # Composite icon onto wallpaper
                        composite.paste(icon_img, (x, y), icon_img)
                        print(f"[DEBUG] Composited home icon {bundle_id} at ({x}, {y})")

                except Exception as e:
                    print(f"[DEBUG] Failed to composite home icon {bundle_id}: {e}")
                    continue

            # === COMPOSITE DOCK ICONS ===
            # Dock position (at the bottom of screen)
            dock_y = int(wallpaper_height * DOCK_Y_PERCENT)
            dock_start_x = int((wallpaper_width - (len(dock_icons) * icon_size + (len(dock_icons)-1) * horizontal_padding)) / 2)

            print(f"[DEBUG] Dock position: ({dock_start_x}, {dock_y})")
            print(f"[DEBUG] Compositing {len(dock_icons)} dock icons...")
            for idx, bundle_id in enumerate(dock_icons):
                try:
                    icon_data = springboard.get_icon_pngdata(bundle_id)

                    if icon_data:
                        icon_img = Image.open(BytesIO(icon_data)).convert('RGBA')
                        icon_img = icon_img.resize((icon_size, icon_size), Image.Resampling.LANCZOS)

                        # Calculate dock position
                        x = dock_start_x + idx * (icon_size + horizontal_padding)
                        y = dock_y

                        # Composite icon onto wallpaper
                        composite.paste(icon_img, (x, y), icon_img)
                        print(f"[DEBUG] Composited dock icon {bundle_id} at ({x}, {y})")

                except Exception as e:
                    print(f"[DEBUG] Failed to composite dock icon {bundle_id}: {e}")
                    continue

            # === ADD TIME AND DATE OVERLAY ===
            from datetime import datetime
            try:
                # Draw time and date at the top
                draw = ImageDraw.Draw(composite)

                # Get current time
                now = datetime.now()
                time_str = now.strftime("%I:%M").lstrip("0")  # Remove leading zero from hour
                date_str = now.strftime("%A, %b %d")  # "Tuesday, Nov 11"

                # Calculate font sizes based on image width (20% larger than before)
                time_font_size = int(wallpaper_width / 4.58)  # Large time (20% bigger)
                date_font_size = int(wallpaper_width / 13.33)  # Smaller date (20% bigger)

                # Try to use system font (fallback to PIL default if not available)
                try:
                    from PIL import ImageFont
                    # Try to load a system font
                    try:
                        time_font = ImageFont.truetype("arial.ttf", time_font_size)
                        date_font = ImageFont.truetype("arial.ttf", date_font_size)
                    except:
                        # Fallback to default font
                        time_font = ImageFont.load_default()
                        date_font = ImageFont.load_default()
                except:
                    time_font = None
                    date_font = None

                # Position for time (centered, using configured position)
                time_y = int(wallpaper_height * TIME_Y_PERCENT)

                print(f"[DEBUG] Time/date font sizes: time={time_font_size}px, date={date_font_size}px")
                print(f"[DEBUG] Time Y position: {time_y}px")

                # Draw time with shadow for visibility
                if time_font:
                    # Get text size for centering
                    bbox = draw.textbbox((0, 0), time_str, font=time_font)
                    time_width = bbox[2] - bbox[0]
                    time_x = (wallpaper_width - time_width) // 2

                    # Shadow
                    draw.text((time_x + 2, time_y + 2), time_str, font=time_font, fill=(0, 0, 0, 180))
                    # Main text
                    draw.text((time_x, time_y), time_str, font=time_font, fill=(255, 255, 255, 255))

                    # Draw date below time
                    date_y = time_y + int(time_font_size * 1.2)
                    bbox = draw.textbbox((0, 0), date_str, font=date_font)
                    date_width = bbox[2] - bbox[0]
                    date_x = (wallpaper_width - date_width) // 2

                    # Shadow
                    draw.text((date_x + 1, date_y + 1), date_str, font=date_font, fill=(0, 0, 0, 180))
                    # Main text
                    draw.text((date_x, date_y), date_str, font=date_font, fill=(255, 255, 255, 255))

                    print(f"[DEBUG] Added time/date overlay: {time_str} - {date_str}")

            except Exception as e:
                print(f"[DEBUG] Failed to add time/date overlay: {e}")

            print(f"[DEBUG] Successfully composited {len(home_screen_icons) + len(dock_icons)} icons onto wallpaper")
            return composite

        except Exception as e:
            print(f"[ERROR] Error compositing icons: {e}")
            import traceback
            traceback.print_exc()
            return wallpaper_img

    def _on_device_connected(self, device_info):
        """Called when iOS device is detected"""

        # Full rich device info (includes screenshot, device_class, etc.)
        self.current_device = device_info

        # Existing summarized info (keep this if other parts use it)
        self.current_device_info = {
            'total_bytes': device_info.get('total_capacity'),
            'available_bytes': device_info.get('available_space'),
            'used_bytes': device_info.get('used_space'),
            'ios_version': device_info.get('ios_version'),
            'udid': device_info.get('udid'),
            'name': device_info.get('name'),
        }
        self.has_connected_device = True

        # Always expand panels when device connects
        if not self.device_panel_visible:
            self._show_device_panel()
            self._log_message(f"iOS device connected: {device_info.get('name', 'Unknown')} - Device panel expanded")
        else:
            # Already visible, just log
            self._log_message(f"iOS device connected: {device_info.get('name', 'Unknown')}")

        # Also expand backup panel when device connects
        if not self.backup_panel_visible:
            self._show_backup_panel()

        # Update device panel with actual device info
        self._update_device_info(device_info)

        # Update backup panel with device info too
        self._update_backup_panel_info(device_info)

        # Get device name for use in logging and UI updates
        device_name = device_info.get('name', 'Unknown Device')

        # Check activation status and show dialog if not activated
        is_activated = device_info.get('is_activated', False)
        if not is_activated:
            # Initialize activation prompt tracking set if needed
            if not hasattr(self, '_activation_prompt_active'):
                self._activation_prompt_active = set()

            device_serial = device_info.get('udid', 'Unknown')
            if device_serial not in self._activation_prompt_active:
                # Mark this device as having an active activation prompt
                self._activation_prompt_active.add(device_serial)
                print(f"[DEBUG] Device not activated. Showing activation prompt for: {device_name}")
                self._prompt_for_activation(device_info)
            else:
                print(f"[DEBUG] Activation prompt already shown for device: {device_serial}")

        # Defer Find My prompt until restore is attempted.

        # Update restore device header status
        self.restore_device_status_label.config(text=f"| Device: {device_name}")

        # Enable restore button and update restore target display
        self.restore_btn.config(state=tk.NORMAL)
        self._on_restore_target_changed()  # Update path label based on current selection

    def _on_device_disconnected(self):
        """Called when iOS device is disconnected"""
        self.has_connected_device = False
        self.current_device = None

        # Clear cached device data so next connection fetches fresh data
        self.cached_device_data = None
        print("[DEBUG] Cleared cached device data on disconnection")

        # Collapse panels when device disconnects (only if not manually toggled)
        if self.device_panel_visible and not self.device_panel_manually_toggled:
            self._hide_device_panel()
            self._log_message("iOS device disconnected - Device panel collapsed")
        else:
            if self.device_panel_manually_toggled:
                self._log_message("iOS device disconnected - Device panel kept open (manually toggled)")
            else:
                self._log_message("iOS device disconnected")

        # Also collapse backup panel when device disconnects (only if not manually toggled)
        if self.backup_panel_visible and not self.backup_panel_manually_toggled:
            self._hide_backup_panel()

        # Reset device panel to placeholder
        self._reset_device_panel()

        # Reset backup panel to placeholder
        self._reset_backup_panel()

        # Reset restore device header status
        self.restore_device_status_label.config(text="| Device: None")

        # Disable restore button when device disconnects
        self.restore_btn.config(state=tk.DISABLED)

    def _update_device_info(self, device_info):
        """Update device panel with connected device information"""
        # Update Restore Device pane device info
        self._update_restore_panel_info(device_info)

        # Update storage widget
        total = device_info.get('total_capacity')
        available = device_info.get('available_space')
        used = device_info.get('used_space')

        if total and available:
            self._draw_storage_bar(total, used, available)
        else:
            # Hide storage if not available
            self.device_storage_label.config(text="Storage info unavailable")

        # Show/hide no backup warning
        has_local_backup = device_info.get('local_backup') is not None
        if not has_local_backup:
            # Show warning banner
            self.no_backup_warning.pack(fill=tk.X, pady=(0, 10))
            self._log_message("⚠️  Warning: Connected device has no local backup on this computer")
        else:
            # Hide warning banner
            self.no_backup_warning.pack_forget()

    def _update_restore_panel_info(self, device_info):
        """Update restore panel device info card with connected device information"""
        # Update device info labels
        model = device_info.get('model', 'Unknown Device')
        name = device_info.get('name', 'Unknown')
        ios_version = device_info.get('ios_version', 'Unknown')
        total_capacity = device_info.get('total_capacity')
        battery_level = device_info.get('battery_level')
        is_charging = device_info.get('is_charging')

        # Update labels (reset colors from loading state)
        self.restore_device_name_label.config(text=name, fg="#2c3e50")
        self.restore_device_model_label.config(text=f"Model: {model}", fg="#7f8c8d")
        self.restore_device_ios_label.config(text=f"iOS: {ios_version}", fg="#7f8c8d")

        # Activation status
        is_activated = device_info.get('is_activated', False)
        activation_state = device_info.get('activation_state', 'Unknown')
        if is_activated:
            self.restore_device_activation_label.config(text=f"Activation: ✓ {activation_state}", fg="#27ae60")
        else:
            self.restore_device_activation_label.config(text=f"Activation: ✗ {activation_state}", fg="#e74c3c")

        # UDID (shortened for display)
        udid = device_info.get('udid', 'Unknown')
        if udid and udid != 'Unknown':
            # Show last 16 characters if UDID is long
            udid_display = f"...{udid[-16:]}" if len(udid) > 20 else udid
            self.restore_device_udid_label.config(text=f"UDID: {udid_display}")
        else:
            self.restore_device_udid_label.config(text="UDID: —")

        # Battery/charging status
        if battery_level is not None:
            charge_emoji = "🔌" if is_charging else "🔋"
            self.restore_device_charging_label.config(
                text=f"Battery: {charge_emoji} {battery_level:.0f}%"
            )
        else:
            self.restore_device_charging_label.config(text="Battery: —")

        # Device color and storage capacity configuration
        device_color_code = device_info.get('device_color')
        device_color = map_device_color_code(device_color_code)
        marketed_capacity = get_marketed_capacity(total_capacity)

        if device_color or marketed_capacity:
            config_parts = []
            if marketed_capacity:
                config_parts.append(marketed_capacity)
            if device_color:
                config_parts.append(device_color)

            if config_parts:
                self.restore_device_color_capacity_label.config(
                    text=f"Configuration: {', '.join(config_parts)}"
                )
            else:
                self.restore_device_color_capacity_label.config(text="Configuration: —")
        else:
            self.restore_device_color_capacity_label.config(text="Configuration: —")

        # Trust status - check if device is trusted (has valid lockdown connection)
        if hasattr(self, 'current_device_lockdown') and self.current_device_lockdown:
            # Device is successfully paired and trusted
            self.restore_device_trusted_label.config(text="Trusted: ✓ Trusted", fg="#27ae60")
        else:
            # Device is not trusted or pairing failed
            self.restore_device_trusted_label.config(text="Trusted: ✗ Not Trusted", fg="#e74c3c")

        # Find My status - check in background thread to avoid GUI freeze
        if hasattr(self, 'current_device_lockdown') and self.current_device_lockdown:
            # Show "checking" status immediately (non-blocking)
            self.restore_device_findmy_label.config(text="Find My: ⏳ Checking...", fg="#7f8c8d")

            # Check Find My status in background thread
            def check_findmy_background():
                try:
                    find_my_enabled = check_find_my_status(self.current_device_lockdown)
                    # Update label on main thread
                    self.root.after(0, lambda: self._update_findmy_status(find_my_enabled))
                except Exception as e:
                    # On error, show unknown status
                    self.root.after(0, lambda: self.restore_device_findmy_label.config(
                        text="Find My: —", fg="#7f8c8d"
                    ))

            import threading
            findmy_thread = threading.Thread(target=check_findmy_background, daemon=True)
            findmy_thread.start()
        else:
            self.restore_device_findmy_label.config(text="Find My: —", fg="#7f8c8d")

    def _update_findmy_status(self, find_my_enabled):
        """Update Find My status label (called from background thread via root.after)."""

        # Update Find My label on the restore panel
        if find_my_enabled:
            self.restore_device_findmy_label.config(
                text="Find My: ✓ Enabled",
                fg="#e74c3c"
            )
        else:
            self.restore_device_findmy_label.config(
                text="Find My: ✗ Disabled",
                fg="#27ae60"
            )

        # Get the current device info safely
        device_info = getattr(self, "current_device", None)
        if not device_info:
            # No device info available; nothing more to do
            return

        # Update device image with wallpaper and frame
        screenshot = device_info.get("screenshot")
        if screenshot and PIL_AVAILABLE:
            # Determine if this is an iPad
            device_class = device_info.get("device_class", "").lower()
            is_ipad = "ipad" in device_class or "pad" in device_class

            # Add device frame overlay
            framed_img = self._add_device_frame(screenshot, is_ipad)

            # Convert to PhotoImage
            photo = ImageTk.PhotoImage(framed_img)

            # Remove old label if exists
            if getattr(self, "restore_device_image_label", None):
                self.restore_device_image_label.destroy()

            # Hide placeholder
            if getattr(self, "restore_device_image_placeholder", None):
                self.restore_device_image_placeholder.pack_forget()

            # Create new image label
            self.restore_device_image_label = tk.Label(
                self.restore_device_image_frame,
                image=photo,
                bg="#f0f0f0"
            )
            # Keep reference to avoid GC
            self.restore_device_image_label.image = photo
            self.restore_device_image_label.pack(expand=True)


    def _draw_storage_bar(self, total_bytes, used_bytes, available_bytes, backup_bytes=0):
        """
        Draw storage bar with color coding.
        Shows three segments: used (green), backup (orange), and free (remaining).
        """
        # Convert to GB for display
        total_gb = total_bytes / (1024**3)
        used_gb = used_bytes / (1024**3)
        available_gb = available_bytes / (1024**3)
        backup_gb = backup_bytes / (1024**3)

        # Calculate percentages
        percent_used = (used_bytes / total_bytes) * 100 if total_bytes else 0
        percent_backup = (backup_bytes / total_bytes) * 100 if total_bytes else 0
        percent_combined = percent_used + percent_backup

        # Determine remaining free space after backup
        remaining_free_bytes = available_bytes - backup_bytes
        remaining_free_gb = remaining_free_bytes / (1024**3)

        # Determine color and status based on remaining free space
        if backup_bytes > 0:
            # When a backup is selected
            if remaining_free_gb > 20:
                status_color = "#27ae60"  # Green
                status = "sufficient space"
            elif remaining_free_gb > 10:
                status_color = "#f39c12"  # Orange
                status = "moderate space remaining"
            elif remaining_free_bytes > 0:
                status_color = "#e67e22"  # Dark orange
                status = "low space remaining"
            else:
                status_color = "#e74c3c"  # Red
                status = "insufficient space"
        else:
            # No backup selected
            if available_gb > 20:
                status_color = "#27ae60"  # Green
                status = "plenty of space"
            elif available_gb > 10:
                status_color = "#f39c12"  # Orange
                status = "moderate space"
            else:
                status_color = "#e74c3c"  # Red
                status = "low space"

        # Clear canvas
        canvas = self.device_storage_canvas
        canvas.delete("all")

        # Get canvas width
        canvas.update_idletasks()
        width = canvas.winfo_width()
        if width <= 1:  # Not yet rendered
            width = 350  # Default width

        height = 25
        padding = 2

        # Draw background (free space)
        canvas.create_rectangle(padding, padding, width - padding, height - padding,
                               fill="#ecf0f1", outline="#bdc3c7", width=1)

        # Draw used space bar (green)
        used_width = int((width - 2 * padding) * percent_used / 100)
        if used_width > 0:
            canvas.create_rectangle(padding, padding, padding + used_width, height - padding,
                                   fill="#27ae60", outline="", width=0)

        # Draw backup space bar (orange) - stacked after used space
        if backup_bytes > 0:
            backup_width = int((width - 2 * padding) * percent_backup / 100)
            if backup_width > 0:
                canvas.create_rectangle(padding + used_width, padding,
                                       padding + used_width + backup_width, height - padding,
                                       fill="#e67e22", outline="", width=0)

        # Draw percentage text
        if backup_bytes > 0:
            canvas.create_text(width // 2, height // 2,
                              text=f"{percent_combined:.1f}% after restore",
                              font=("Arial", 9, "bold"), fill="#2c3e50")
        else:
            canvas.create_text(width // 2, height // 2,
                              text=f"{percent_used:.1f}% used",
                              font=("Arial", 9, "bold"), fill="#2c3e50")

        # Update text label
        if backup_bytes > 0:
            self.device_storage_label.config(
                text=f"{remaining_free_gb:.1f} GB will remain free after restoring {backup_gb:.1f} GB backup ({status})",
                fg=status_color
            )
        else:
            self.device_storage_label.config(
                text=f"{available_gb:.1f} GB free of {total_gb:.1f} GB ({status})",
                fg=status_color
            )

    def _reset_device_panel(self):
        """Reset device panel to placeholder state"""
        # Reset Restore Device pane device info
        self.restore_device_name_label.config(text="No Device Connected")
        self.restore_device_model_label.config(text="Model: —")
        self.restore_device_ios_label.config(text="iOS: —")
        self.restore_device_trusted_label.config(text="Trusted: —", fg="#7f8c8d")
        self.restore_device_activation_label.config(text="Activation: —", fg="#7f8c8d")
        self.restore_device_udid_label.config(text="UDID: —")
        self.restore_device_charging_label.config(text="Battery: —")
        self.restore_device_color_capacity_label.config(text="Configuration: —")
        self.restore_device_findmy_label.config(text="Find My: —", fg="#7f8c8d")

        # Remove device wallpaper if it exists in restore panel
        if self.restore_device_image_label:
            self.restore_device_image_label.destroy()
            self.restore_device_image_label = None

        # Show the placeholder label again in restore panel
        self.restore_device_image_placeholder.pack(expand=True)

        # Clear storage widget
        self.device_storage_canvas.delete("all")
        self.device_storage_label.config(text="")

        # Hide no backup warning
        self.no_backup_warning.pack_forget()

        # Hide storage warning
        self.storage_warning.pack_forget()

    def _validate_restore_storage(self, backup_path):
        """
        Validate if device has enough storage to accommodate the backup.
        Returns dict with status and message:
        - status: "ok", "insufficient_free", "insufficient_total"
        - message: Warning/error message
        - allow_restore: Boolean indicating if restore should be allowed
        """
        # Get device storage info
        if not self.current_device_info:
            return {"status": "ok", "message": "", "allow_restore": True}

        total_bytes = self.current_device_info.get('total_bytes', 0)
        available_bytes = self.current_device_info.get('available_bytes', 0)

        if total_bytes == 0 or available_bytes == 0:
            return {"status": "ok", "message": "", "allow_restore": True}

        # Calculate backup size
        backup_size = calculate_backup_size(backup_path)
        if backup_size == 0:
            # If we can't calculate size, allow restore (don't block on calculation errors)
            return {"status": "ok", "message": "", "allow_restore": True}

        backup_gb = backup_size / (1024**3)
        total_gb = total_bytes / (1024**3)
        available_gb = available_bytes / (1024**3)

        # Scenario 1: Backup larger than total device capacity (even if erased)
        if backup_size > total_bytes:
            return {
                "status": "insufficient_total",
                "color": "#e74c3c",  # Red - critical error
                "message": f"⚠️  INSUFFICIENT STORAGE CAPACITY\n\n"
                          f"Backup size ({backup_gb:.1f} GB) exceeds device capacity ({total_gb:.1f} GB).\n"
                          f"This backup cannot be restored to this device, even if the device is erased.\n\n"
                          f"You need a device with at least {backup_gb:.1f} GB of storage capacity.",
                "allow_restore": False
            }

        # Scenario 2: Insufficient free space but would fit if erased
        elif backup_size > available_bytes:
            return {
                "status": "insufficient_free",
                "color": "#f39c12",  # Yellow/Orange - warning (can be resolved by erasing)
                "message": f"⚠️  INSUFFICIENT FREE SPACE\n\n"
                          f"Backup size: {backup_gb:.1f} GB\n"
                          f"Available space: {available_gb:.1f} GB\n\n"
                          f"The device does not have enough free space to restore this backup.\n"
                          f"However, the backup would fit if the device is erased first.\n\n"
                          f"To restore this backup:\n"
                          f"  1. IMPORTANT: Create a backup of your current device data first!\n"
                          f"  2. Erase your device (Settings > General > Transfer or Reset iPhone > Erase All Content and Settings)\n"
                          f"  3. After erasing, reconnect and restore the backup\n\n"
                          f"Restore is currently blocked. Please erase device first.",
                "allow_restore": False
            }

        # Scenario 3: Sufficient free space
        return {"status": "ok", "message": "", "color": "", "allow_restore": True}

    def _on_restore_target_changed(self):
        """Handle restore target selection change and validate storage"""
        try:
            target = self.restore_target.get()
            backup_path = None
        except Exception as e:
            print(f"[DEBUG] Error in _on_restore_target_changed: {e}")
            import traceback
            traceback.print_exc()
            return

        # Determine backup path and update path label
        if target == "modified":
            if self.modified_backup_path and os.path.exists(self.modified_backup_path):
                backup_path = self.modified_backup_path
                self.restore_path_label.config(text=f"Path: {backup_path}", foreground="#2c3e50")
            else:
                self.restore_path_label.config(text="No modified backup available. Modify backup first.", foreground="#e74c3c")

        elif target == "left":
            if self.left_backup and self.left_backup.is_valid:
                backup_path = self.left_backup.path
                self.restore_path_label.config(text=f"Path: {backup_path}", foreground="#2c3e50")
            else:
                self.restore_path_label.config(text="No left backup loaded.", foreground="#e74c3c")

        elif target == "right":
            if self.right_backup and self.right_backup.is_valid:
                backup_path = self.right_backup.path
                self.restore_path_label.config(text=f"Path: {backup_path}", foreground="#2c3e50")
            else:
                self.restore_path_label.config(text="No right backup loaded.", foreground="#e74c3c")

        elif target == "browse":
            # Show custom backup path if already selected, otherwise show prompt
            if self.custom_restore_path and os.path.exists(self.custom_restore_path):
                backup_path = self.custom_restore_path
                self.restore_path_label.config(text=f"Path: {backup_path}", foreground="#2c3e50")
            else:
                self.restore_path_label.config(text="Click 'Browse...' button to select backup", foreground="#7f8c8d")

        # Validate storage and update UI if we have a valid backup path
        if backup_path and self.current_device_info:
            # Calculate backup size
            backup_size = calculate_backup_size(backup_path)

            # Update storage bar with backup size
            total = self.current_device_info.get('total_bytes', 0)
            used = self.current_device_info.get('used_bytes', 0)
            available = self.current_device_info.get('available_bytes', 0)

            if total > 0:
                self._draw_storage_bar(total, used, available, backup_bytes=backup_size)

            # Validate storage
            validation = self._validate_restore_storage(backup_path)

            # Update warning box and restore button based on validation
            if validation["status"] == "ok":
                # Hide warning, enable restore button
                self.storage_warning.pack_forget()
                if self.has_connected_device:
                    self.restore_btn.config(state=tk.NORMAL)
            else:
                # Show warning with appropriate color, disable restore button
                self.storage_warning.config(
                    text=validation["message"],
                    bg=validation.get("color", "#e74c3c")  # Use color from validation, default to red
                )
                self.storage_warning.pack(fill=tk.X, pady=(0, 5), before=self.restore_frame)
                self.restore_btn.config(state=tk.DISABLED)
        else:
            # No valid backup selected - hide warning, reset storage bar, disable restore button
            self.storage_warning.pack_forget()
            if self.current_device_info:
                total = self.current_device_info.get('total_bytes', 0)
                used = self.current_device_info.get('used_bytes', 0)
                available = self.current_device_info.get('available_bytes', 0)
                if total > 0:
                    self._draw_storage_bar(total, used, available, backup_bytes=0)
            self.restore_btn.config(state=tk.DISABLED)

    def _browse_for_restore_backup(self):
        """Open file dialog to browse for backup to restore"""
        folder = filedialog.askdirectory(title="Select Backup Folder to Restore")
        if folder:
            # Validate backup
            try:
                backup_info = BackupInfo(folder)
                if backup_info.is_valid:
                    self.restore_path_label.config(text=f"Path: {backup_info.path}", foreground="#2c3e50")
                    # Store the custom path for restore
                    self.custom_restore_path = backup_info.path
                else:
                    self.restore_path_label.config(text=f"Invalid backup: {backup_info.validation_msg}", foreground="#e74c3c")
                    self.custom_restore_path = None
            except Exception as e:
                self.restore_path_label.config(text=f"Error loading backup: {str(e)}", foreground="#e74c3c")
                self.custom_restore_path = None

    def _restore_device(self):
        """Restore backup to connected device"""
        if not self.has_connected_device:
            messagebox.showwarning("No Device", "No iOS device connected. Please connect a device first.")
            return

        # Check device activation status
        lockdown = getattr(self, "current_device_lockdown", None)
        if lockdown:
            is_activated, activation_state = check_activation_status(lockdown)
            if not is_activated:
                messagebox.showerror(
                    "Device Not Activated",
                    f"Cannot restore backup: Device is not activated.\n\n"
                    f"Activation Status: {activation_state}\n\n"
                    f"Please activate your device first:\n"
                    f"1. Connect to Wi-Fi or cellular\n"
                    f"2. Follow the on-screen setup instructions\n"
                    f"3. Sign in with your Apple ID when prompted"
                )
                # Show activation dialog
                if hasattr(self, 'current_device_info'):
                    self._prompt_for_activation(self.current_device_info)
                return

        # Get selected backup path
        target = self.restore_target.get()
        restore_path = None

        if target == "modified":
            restore_path = self.modified_backup_path
        elif target == "left":
            restore_path = self.left_backup.path if self.left_backup else None
        elif target == "right":
            restore_path = self.right_backup.path if self.right_backup else None
        elif target == "browse":
            restore_path = getattr(self, 'custom_restore_path', None)

        if not restore_path or not os.path.exists(restore_path):
            messagebox.showerror("Invalid Backup", "Selected backup path is not valid or does not exist.")
            return

        # === VALIDATION 1: Check iOS Version Compatibility ===
        backup_ios_version = get_backup_ios_version(restore_path)
        device_ios_version = self.current_device_info.get('ios_version') if self.current_device_info else None

        if backup_ios_version and device_ios_version:
            if not compare_ios_versions(device_ios_version, backup_ios_version):
                # Device iOS is older than backup iOS - incompatible
                messagebox.showerror(
                    "iOS Version Incompatible",
                    f"Cannot restore this backup to your device.\n\n"
                    f"Backup iOS Version: {backup_ios_version}\n"
                    f"Device iOS Version: {device_ios_version}\n\n"
                    f"The backup was created on a newer iOS version ({backup_ios_version}) "
                    f"than what is currently installed on your device ({device_ios_version}).\n\n"
                    f"To restore this backup, please update your device to iOS {backup_ios_version} or later:\n"
                    f"  1. Go to Settings > General > Software Update\n"
                    f"  2. Download and install the latest iOS version\n"
                    f"  3. Try restoring again after the update completes"
                )
                self._log_message(f"❌ Restore blocked: Backup iOS {backup_ios_version} > Device iOS {device_ios_version}")
                return

        # === VALIDATION 2: Check Find My Status ===
        lockdown = getattr(self, "current_device_lockdown", None)
        if lockdown is not None:
            find_my_enabled = check_find_my_status(lockdown)
            if find_my_enabled:
                # Find My is enabled - must be disabled before restore
                messagebox.showerror(
                    "Find My Must Be Disabled",
                    "Cannot restore while Find My is enabled on your device.\n\n"
                    "For security reasons, Find My iPhone must be disabled before restoring a backup.\n\n"
                    "To disable Find My:\n"
                    "  1. Open Settings on your device\n"
                    "  2. Tap your name at the top\n"
                    "  3. Tap 'Find My'\n"
                    "  4. Tap 'Find My iPhone'\n"
                    "  5. Toggle 'Find My iPhone' OFF\n"
                    "  6. Enter your Apple ID password when prompted\n\n"
                    "After disabling Find My, please try restoring again."
                )
                self._log_message("❌ Restore blocked: Find My is enabled on device")
                return

        # Start the restore process
        self._log_message(f"Restore initiated: {restore_path}")
        self._start_restore(restore_path)

    def _browse_backup(self, side):
        """Browse for backup folder"""
        folder = filedialog.askdirectory(title=f"Select {side.upper()} Backup Folder")
        if not folder:
            return

        proceed, normalized_path, allow_unsupported = self._validate_backup_path_for_load(folder)
        if not proceed:
            return

        # Show loading indicator
        info_text = self.left_info_text if side == "left" else self.right_info_text
        info_text.config(state=tk.NORMAL)
        info_text.delete("1.0", tk.END)
        info_text.insert("1.0", "Loading backup information...\n\nPlease wait...")
        info_text.config(state=tk.DISABLED)

        # Load backup in background thread
        thread = threading.Thread(
            target=self._load_backup_async,
            args=(normalized_path, side, allow_unsupported),
            daemon=True
        )
        thread.start()

    def _load_backup_async(self, folder, side, allow_unsupported=False):
        """Load backup information in background thread"""
        # Load backup info (this can take time for large backups)
        backup = BackupInfo(folder)
        backup.allow_unsupported = allow_unsupported

        # Queue UI update on main thread
        self.root.after(0, lambda: self._update_backup_display(backup, side))

    def _validate_backup_path_for_load(self, path):
        """Validate backup path before loading. Returns (proceed, normalized_path, allow_unsupported)."""
        info = classify_backup_path(path)
        if info["ok"]:
            return True, info["path"], False

        if info["legacy"]:
            title = "Unsupported Backup Format"
            msg = (
                "This appears to be an older iTunes backup format (MBDB), which is not supported.\n\n"
                "You can load it in read-only mode for inspection, but extraction is disabled.\n\n"
                "Load anyway (unsupported)?"
            )
        else:
            title = "Invalid Backup"
            msg = (
                "The selected folder does not look like a valid iTunes/Finder backup.\n\n"
                f"Reason: {info['reason']}\n\n"
                "You can load it in read-only mode for inspection, but extraction is disabled.\n\n"
                "Load anyway (unsupported)?"
            )

        load_anyway = messagebox.askyesno(title, msg, parent=self.root)
        return load_anyway, info["path"], load_anyway

    def _handle_drop(self, event, side, entry_widget):
        """Handle drag-and-drop of backup folder"""
        # Get dropped path (tkinterdnd2 format)
        path = event.data

        # Clean up the path
        path = path.strip('{}')  # Remove braces if present
        path = path.strip('"\'')  # Remove quotes

        # If dropped on panel (not entry), find the entry widget
        if entry_widget is None:
            entry_widget = self.left_path_entry if side == "left" else self.right_path_entry

        # Update entry widget
        entry_widget.delete(0, tk.END)
        entry_widget.insert(0, path)

        # Trigger load directly (without needing the entry widget)
        if not os.path.exists(path):
            messagebox.showerror("Invalid Path", f"Path does not exist:\n{path}")
            return

        proceed, normalized_path, allow_unsupported = self._validate_backup_path_for_load(path)
        if not proceed:
            return
        path = normalized_path
        if entry_widget is not None:
            entry_widget.delete(0, tk.END)
            entry_widget.insert(0, path)

        # Show loading indicator
        info_text = self.left_info_text if side == "left" else self.right_info_text
        info_text.config(state=tk.NORMAL)
        info_text.delete("1.0", tk.END)
        info_text.insert("1.0", "⏳ Loading backup information...\n\nPlease wait...")
        info_text.config(state=tk.DISABLED)

        # Load backup in background thread
        thread = threading.Thread(target=self._load_backup_async, args=(path, side, allow_unsupported), daemon=True)
        thread.start()
        
    def _handle_auto_detect_drop(self, event):
        """Handle drag-and-drop of a backup folder onto the Auto-Detected Backups area."""
        from tkinter import messagebox
        import os, re

        raw = event.data or ""
        raw = raw.strip()
        if not raw:
            return

        # tkinterdnd2 may send multiple paths like: {C:\path1} {C:\path2}
        # We only care about the first one.
        if raw.startswith("{") and "}" in raw:
            path = raw[1:raw.index("}")]
        else:
            parts = raw.split()
            path = parts[0] if parts else ""
        path = path.strip('{}"\' ')

        if not path:
            return
        if not os.path.isdir(path):
            messagebox.showerror("Invalid Path", f"Path is not a folder:\n{path}")
            return

        # Normalize to the actual UDID folder (40 hex), even when user drops the parent/timestamp folder
        try:
            udid_like = re.compile(r"^[0-9a-fA-F]{40}$")
            norm = os.path.abspath(path)

            if not (os.path.exists(os.path.join(norm, "Info.plist")) and
                    os.path.exists(os.path.join(norm, "Manifest.db"))):
                # Try child UDID under parent/timestamped parent
                found = None
                for item in os.listdir(norm):
                    child = os.path.join(norm, item)
                    if os.path.isdir(child) and udid_like.match(item):
                        if (os.path.exists(os.path.join(child, "Info.plist")) and
                                os.path.exists(os.path.join(child, "Manifest.db"))):
                            found = child
                            break
                if found:
                    norm = found

            proceed, normalized_path, allow_unsupported = self._validate_backup_path_for_load(norm)
            if not proceed:
                return
            norm = normalized_path

            # Track + add to detected list (same semantics as 'Add a backup to backup list')
            self._tracked_paths.add(norm)
            self._save_tracked_backups()

            # Add to detected list (handles de-dup + sorting)
            self._add_backup_to_detected_list(norm)
            self._save_tracked_backups()

            self._log_message(f"[INFO] Added backup to list via drag-and-drop: {norm}")

        except Exception as e:
            messagebox.showerror("Error adding backup", str(e))


    def _load_from_entry(self, entry_widget, side):
        """Load backup from pasted path"""
        path = entry_widget.get().strip()
        if not path:
            messagebox.showwarning("No Path", "Please paste a backup folder path first")
            return

        # Remove quotes if present (from Windows copy path)
        path = path.strip('"\'')

        if not os.path.exists(path):
            messagebox.showerror("Invalid Path", f"Path does not exist:\n{path}")
            return

        proceed, normalized_path, allow_unsupported = self._validate_backup_path_for_load(path)
        if not proceed:
            return
        path = normalized_path
        entry_widget.delete(0, tk.END)
        entry_widget.insert(0, path)

        # Show loading indicator
        info_text = self.left_info_text if side == "left" else self.right_info_text
        info_text.config(state=tk.NORMAL)
        info_text.delete("1.0", tk.END)
        info_text.insert("1.0", "⏳ Loading backup information...\n\nPlease wait...")
        info_text.config(state=tk.DISABLED)

        # Load backup in background thread
        thread = threading.Thread(target=self._load_backup_async, args=(path, side, allow_unsupported), daemon=True)
        thread.start()

    def _clear_backup(self, side):
        """Clear/unload a backup from the specified slot."""
        # Cancel size validation for backup being cleared
        backup_to_clear = self.left_backup if side == "left" else self.right_backup
        if backup_to_clear:
            backup_to_clear.cancel_size_validation()

        # Clear backup state (no confirmation needed)
        if side == "left":
            self.left_backup = None
            self.left_ios_version = None
            info_text = self.left_info_text
            wallpaper_label = self.left_wallpaper_label
            wallpaper_frame = self.left_wallpaper_frame
            path_entry = self.left_path_entry
            version_label = self.left_version_label
            compat_label = self.left_compat_label
            clear_btn = self.left_clear_btn
            info_btn = self.left_info_btn
        else:
            self.right_backup = None
            self.right_ios_version = None
            info_text = self.right_info_text
            wallpaper_label = self.right_wallpaper_label
            wallpaper_frame = self.right_wallpaper_frame
            path_entry = self.right_path_entry
            version_label = self.right_version_label
            compat_label = self.right_compat_label
            clear_btn = self.right_clear_btn
            info_btn = self.right_info_btn

        # Clear path entry
        path_entry.delete(0, tk.END)

        # Reset version labels
        version_label.config(text="iOS: —", fg="#7f8c8d")
        compat_label.config(text="")

        # Hide clear button
        clear_btn.place_forget()
        info_btn.place_forget()

        # Reset wallpaper to drop zone
        # Remove old wallpaper label if it exists
        for widget in wallpaper_frame.winfo_children():
            if isinstance(widget, tk.Label):
                widget.destroy()

        # Recreate drop zone placeholder
        new_wallpaper_label = tk.Label(
            wallpaper_frame,
            text="📁\n\nDrag & Drop Backup Folder Here\n\n(or click to browse)",
            font=("Arial", 9, "italic"),
            fg="gray",
            bg="#f0f0f0",
            justify=tk.CENTER,
            cursor="hand2"
        )
        new_wallpaper_label.pack(expand=True, fill=tk.BOTH)
        new_wallpaper_label.bind("<Button-1>", lambda e: self._browse_backup(side))

        # Update reference
        if side == "left":
            self.left_wallpaper_label = new_wallpaper_label
        else:
            self.right_wallpaper_label = new_wallpaper_label

        # Reset info text
        info_text.config(state=tk.NORMAL)
        info_text.delete("1.0", tk.END)
        info_text.insert("1.0", "No backup selected")
        info_text.config(state=tk.DISABLED)

        extract_btn = self.left_extract_btn if side == "left" else self.right_extract_btn
        if extract_btn:
            extract_btn.config(state=tk.DISABLED)

        # Disable category buttons for the cleared side
        self._disable_category_buttons(side)

        # Update UI state
        self._update_backup_panel_titles()
        self._update_compatibility_indicator()

        # Reset category counts for the cleared side
        self._update_category_counts()

        print(f"[CLEAR] Cleared {side} backup")

    def _update_backup_display(self, backup, side):
        """Update UI with loaded backup info (runs on main thread)"""
        # Cancel size validation for previous backup on this side
        previous_backup = self.left_backup if side == "left" else self.right_backup
        if previous_backup and previous_backup != backup:
            previous_backup.cancel_size_validation()

        # Update state
        if side == "left":
            self.left_backup = backup
            info_text = self.left_info_text
            wallpaper_label = self.left_wallpaper_label
            wallpaper_frame = self.left_wallpaper_frame
            version_label = self.left_version_label
            compat_label = self.left_compat_label
        else:
            self.right_backup = backup
            info_text = self.right_info_text
            wallpaper_label = self.right_wallpaper_label
            wallpaper_frame = self.right_wallpaper_frame
            version_label = self.right_version_label
            compat_label = self.right_compat_label

        # Detect iOS version
        ios_version = detect_ios_version(backup.path)
        if ios_version:
            version_label.config(text=f"iOS {ios_version}", fg="#2c3e50")
        else:
            version_label.config(text="iOS: Unknown", fg="#e74c3c")

        # Store version for compatibility checking
        if side == "left":
            self.left_ios_version = ios_version
        else:
            self.right_ios_version = ios_version

        # Update compatibility indicator
        self._update_compatibility_indicator()

        # Update wallpaper frame styling (remove drop zone styling)
        wallpaper_frame.config(bg="SystemButtonFace", relief=tk.FLAT,
                              highlightthickness=0, borderwidth=0, cursor="")
        wallpaper_label.config(bg="SystemButtonFace", cursor="")

        # Unbind click events (no longer needed once backup is loaded)
        wallpaper_frame.unbind("<Button-1>")
        wallpaper_label.unbind("<Button-1>")

        # Load cached size if available
        if backup.size_gb_validated is None:
            cached_size = self._get_cached_size(backup.path)
            if cached_size is not None:
                backup.size_gb_validated = cached_size

        # Update info text
        info_text.config(state=tk.NORMAL)
        info_text.delete("1.0", tk.END)

        size_text = backup.get_size_display_text()

        info_text.insert("1.0",
            f"📱 {backup.device_model}\n"
            f"👤 Name: {backup.name}\n"
            f"💾 Size: {size_text}\n"
            f"📅 Created: {backup.get_created_timestamp_str()}\n"
            f"{backup.validation_msg}"
        )
        if not backup.is_supported:
            info_text.insert(tk.END, "\nWARNING: Unsupported backup. Extraction disabled.")
        info_text.config(state=tk.DISABLED)

        extract_btn = self.left_extract_btn if side == "left" else self.right_extract_btn
        if extract_btn:
            extract_btn.config(state=tk.NORMAL)

        # Start size validation if not already done
        if backup.size_gb_validated is None and not backup.size_validation_in_progress:
            backup.calculate_actual_size(
                callback=lambda b, s: self._on_backup_size_validated(side, b)
            )
            # Schedule UI update to show "validating..." text after thread starts
            self.root.after(50, lambda: self._update_backup_size_display(side, backup))

        self._refresh_backup_wallpaper(backup, side)

        # Prompt for encrypted backup password to enable accurate counts
        if backup.is_supported and getattr(backup, 'is_encrypted', False):
            unlocked = self._ensure_encrypted_backup_access(backup, "load this backup")
            if unlocked and PIL_AVAILABLE:
                try:
                    # Refresh wallpaper now that encrypted access is available.
                    backup._extract_wallpaper()
                    self._refresh_backup_wallpaper(backup, side)
                except Exception:
                    pass

        # Update category counts after backup loads
        if backup.is_supported:
            self._update_category_counts()

            # Enable category buttons for this side now that backup is loaded
            self._enable_category_buttons(side)
        else:
            self._disable_category_buttons(side)

        # Update panel titles to reflect single-backup or dual-backup mode
        self._update_backup_panel_titles()

        # Show clear button (X) in top-right corner of wallpaper frame
        clear_btn = self.left_clear_btn if side == "left" else self.right_clear_btn
        info_btn = self.left_info_btn if side == "left" else self.right_info_btn

        # Position button in top-right corner (with 5px padding from edges)
        # Use update_idletasks to ensure wallpaper_frame has proper dimensions
        wallpaper_frame.update_idletasks()
        frame_width = wallpaper_frame.winfo_width()
        button_x = frame_width - 30  # Adjusted for smaller, modern button

        clear_btn.place(x=button_x, y=5)
        info_btn.place(x=5, y=5)
        clear_btn.lift()  # Raise button above wallpaper label
        info_btn.lift()

    def _on_backup_size_validated(self, side, backup):
        """Called when size validation completes (background thread)."""
        # Save validated size to cache
        if backup.size_gb_validated is not None:
            self._save_validated_size(backup.path, backup.size_gb_validated)

        # Schedule UI update on main thread
        self.root.after(0, lambda: self._update_backup_size_display(side, backup))

    def _refresh_backup_wallpaper(self, backup, side):
        """Update the wallpaper preview for a loaded backup."""
        if side == "left":
            wallpaper_label = self.left_wallpaper_label
            wallpaper_frame = self.left_wallpaper_frame
        else:
            wallpaper_label = self.right_wallpaper_label
            wallpaper_frame = self.right_wallpaper_frame

        if backup.wallpaper_image and PIL_AVAILABLE:
            try:
                def update_wallpaper():
                    try:
                        img = backup.wallpaper_image.copy()
                        is_ipad_device = is_ipad(backup.product_type)
                        framed_img = self._add_device_frame(img, is_ipad_device, target_height=210)
                        photo = ImageTk.PhotoImage(framed_img)
                        wallpaper_label.config(image=photo, text="")
                        wallpaper_label.image = photo
                        clear_btn = self.left_clear_btn if side == "left" else self.right_clear_btn
                        info_btn = self.left_info_btn if side == "left" else self.right_info_btn
                        clear_btn.lift()
                        info_btn.lift()
                    except Exception as e:
                        wallpaper_label.config(text=f"📱 Preview unavailable\n{str(e)}", image="")

                self.root.after(100, update_wallpaper)
            except Exception as e:
                wallpaper_label.config(text=f"📱 Preview unavailable\n{str(e)}", image="")
            return

        if not PIL_AVAILABLE:
            wallpaper_label.config(text="📱 Install Pillow for wallpaper preview:\npip install Pillow", image="")
            return

        # No wallpaper in backup - try to load default wallpaper
        try:
            is_ipad_device = is_ipad(backup.product_type)
            default_wallpaper_path = None
            if is_ipad_device:
                ipad_wallpaper_png = get_resource_path("resources", "default_wallpaper_ipad.png")
                ipad_wallpaper_jpg = get_resource_path("resources", "default_wallpaper_ipad.jpg")
                if os.path.exists(ipad_wallpaper_png):
                    default_wallpaper_path = ipad_wallpaper_png
                elif os.path.exists(ipad_wallpaper_jpg):
                    default_wallpaper_path = ipad_wallpaper_jpg

            if not default_wallpaper_path:
                default_wallpaper_png = get_resource_path("resources", "default_wallpaper.png")
                default_wallpaper_jpg = get_resource_path("resources", "default_wallpaper.jpg")
                if os.path.exists(default_wallpaper_png):
                    default_wallpaper_path = default_wallpaper_png
                elif os.path.exists(default_wallpaper_jpg):
                    default_wallpaper_path = default_wallpaper_jpg

            if default_wallpaper_path:
                def update_default_wallpaper():
                    try:
                        img = Image.open(default_wallpaper_path)
                        framed_img = self._add_device_frame(img, is_ipad_device, target_height=210)
                        photo = ImageTk.PhotoImage(framed_img)
                        wallpaper_label.config(image=photo, text="")
                        wallpaper_label.image = photo
                        clear_btn = self.left_clear_btn if side == "left" else self.right_clear_btn
                        clear_btn.lift()
                    except Exception as e:
                        wallpaper_label.config(text=f"📱 Preview unavailable\n{str(e)}", image="")

                self.root.after(100, update_default_wallpaper)
            else:
                wallpaper_label.config(text="📱 No wallpaper found in backup", image="")
        except Exception:
            wallpaper_label.config(text="📱 No wallpaper found in backup", image="")

    def _update_backup_size_display(self, side, backup):
        """Update size display after validation (main thread)."""
        # Get the info_text widget and current backup for this side
        if side == "left":
            info_text = self.left_info_text
            current_backup = self.left_backup
        else:
            info_text = self.right_info_text
            current_backup = self.right_backup

        # Only update if this backup is still displayed
        if current_backup != backup:
            return

        # Rebuild the info text with new size
        info_text.config(state=tk.NORMAL)
        info_text.delete("1.0", tk.END)

        size_text = backup.get_size_display_text()

        info_text.insert("1.0",
            f"📱 {backup.device_model}\n"
            f"👤 Name: {backup.name}\n"
            f"💾 Size: {size_text}\n"
            f"📅 Created: {backup.get_created_timestamp_str()}\n"
            f"{backup.validation_msg}"
        )
        info_text.config(state=tk.DISABLED)

    def _update_compatibility_indicator(self):
        """Update compatibility indicator based on iOS versions of both backups"""
        # Only show indicator if both backups are loaded
        if not self.left_ios_version or not self.right_ios_version:
            # Clear indicators if either backup is missing
            if hasattr(self, 'left_compat_label'):
                self.left_compat_label.config(text="")
            if hasattr(self, 'right_compat_label'):
                self.right_compat_label.config(text="")
            return

        # Compare versions
        if self.left_ios_version == self.right_ios_version:
            # Same version - perfect!
            status_text = "[OK] Schemas identical"
            status_color = "#27ae60"  # Green
        else:
            # Different versions - check compatibility
            status_text = "[!] Schema differences"
            status_color = "#f39c12"  # Orange/yellow

        # Update both labels
        self.left_compat_label.config(text=status_text, fg=status_color)
        self.right_compat_label.config(text=status_text, fg=status_color)

    def _check_merge_compatibility(self):
        """
        Check merge compatibility before starting merge.
        Shows warning dialog if schema differences detected.

        Returns:
            True if user wants to proceed, False if cancelled
        """
        # Same iOS version - no need to warn
        if self.left_ios_version == self.right_ios_version:
            return True

        # Different versions - run full compatibility check
        try:
            results = validate_backup_merge_compatibility(
                self.left_backup.path,
                self.right_backup.path
            )

            # If truly incompatible (type mismatches), block merge
            if not results['compatible']:
                messagebox.showerror(
                    "Incompatible Backups",
                    f"Cannot merge these backups:\n\n"
                    f"iOS {self.left_ios_version} ↔ iOS {self.right_ios_version}\n\n"
                    f"Type mismatches detected:\n" +
                    "\n".join(f"• {err}" for err in results['errors'][:5]) +
                    "\n\nMerge cannot proceed safely."
                )
                return False

            # Compatible but with warnings - show detailed dialog
            warning_count = len(results['warnings'])
            schema_diffs = results.get('database_schemas', {})

            # Build warning message
            message = f"Schema Compatibility Warning\n\n"
            message += f"Left Backup:  iOS {self.left_ios_version}\n"
            message += f"Right Backup: iOS {self.right_ios_version}\n\n"
            message += f"Detected {warning_count} schema differences.\n\n"

            # Show affected databases
            if schema_diffs:
                affected_dbs = [db for db, data in schema_diffs.items()
                               if data.get('column_differences')]
                if affected_dbs:
                    message += f"Affected databases:\n"
                    for db in affected_dbs[:5]:
                        message += f"  • {db}\n"
                    if len(affected_dbs) > 5:
                        message += f"  • ... and {len(affected_dbs) - 5} more\n"
                    message += "\n"

            message += "Impact:\n"
            message += "  • Column differences will be handled safely\n"
            message += "  • Data in non-common columns will be lost\n"
            message += "  • All basic data (messages, contacts, etc.) preserved\n\n"
            message += "Proceed with merge?"

            # Show yes/no dialog
            result = messagebox.askyesno(
                "Schema Differences Detected",
                message,
                icon='warning'
            )

            return result

        except Exception as e:
            # If validation fails, warn user but allow them to proceed
            result = messagebox.askyesno(
                "Compatibility Check Failed",
                f"Could not validate compatibility:\n{str(e)}\n\nProceed anyway?",
                icon='warning'
            )
            return result

    def _update_category_counts(self):
        """Update category labels with entry counts from both backups"""
        # Get counts from both backups in background thread
        def query_counts():
            # Callback for async photo count updates
            def make_update_callback(side):
                def callback(category, accurate_count):
                    # Update UI on main thread
                    self.root.after(0, lambda: self._update_single_category_count(side, category, accurate_count))
                return callback

            # Get initial counts with async validation callbacks
            left_counts = self.left_backup.get_category_counts(update_callback=make_update_callback("left")) if self.left_backup else {}
            right_counts = self.right_backup.get_category_counts(update_callback=make_update_callback("right")) if self.right_backup else {}

            # Update labels on main thread with initial counts
            self.root.after(0, lambda: self._apply_category_counts(left_counts, right_counts))

        thread = threading.Thread(target=query_counts, daemon=True)
        thread.start()

    def _update_single_category_count(self, side, category, count):
        """Update a single category label with accurate count (runs on main thread)"""
        category_names = {
            "photos": "📷 Photos & Videos",
            "sms": "💬 SMS",
            "contacts": "👤 Contacts",
            "calendar": "📅 Calendar",
            "notes": "📝 Notes",
            "call_history": "📞 Call History",
            "voicemail": "📧 Voicemail",
            "voice_memos": "🎤 Voice Memos"
        }

        base_name = category_names.get(category, category)
        label_text = f"{base_name} ({count:,})"

        # Update the appropriate label
        if side == "left" and category in self.category_labels_left:
            self.category_labels_left[category].config(text=label_text)
        elif side == "right" and category in self.category_labels_right:
            self.category_labels_right[category].config(text=label_text)

    def _apply_category_counts(self, left_counts, right_counts):
        """Apply counts to category labels (runs on main thread)"""
        category_names = {
            "photos": "📷 Photos & Videos",
            "sms": "💬 SMS",
            "contacts": "👤 Contacts",
            "calendar": "📅 Calendar",
            "notes": "📝 Notes",
            "call_history": "📞 Call History",
            "voicemail": "📧 Voicemail",
            "voice_memos": "🎤 Voice Memos"
        }

        for cat_id, base_name in category_names.items():
            # Update left label
            if cat_id in self.category_labels_left:
                left_count = left_counts.get(cat_id, 0)
                # Add validation indicator for photos (async validation in progress)
                suffix = " ~ validating..." if cat_id == "photos" and left_count > 0 else ""
                label_text = f"{base_name} ({left_count:,}{suffix})"
                self.category_labels_left[cat_id].config(text=label_text)

            # Update right label
            if cat_id in self.category_labels_right:
                right_count = right_counts.get(cat_id, 0)
                # Add validation indicator for photos (async validation in progress)
                suffix = " ~ validating..." if cat_id == "photos" and right_count > 0 else ""
                label_text = f"{base_name} ({right_count:,}{suffix})"
                self.category_labels_right[cat_id].config(text=label_text)

    def _enable_category_buttons(self, side):
        """Enable category toggle switches for the specified side (left or right)"""
        # Category IDs that have toggle switches
        category_ids = ["photos", "sms", "contacts", "calendar", "notes",
                       "call_history", "voicemail", "voice_memos", "settings"]

        # Enable all toggle switches for this side
        for cat_id in category_ids:
            toggle = self.category_buttons.get(f"{cat_id}_{side}")
            if toggle:
                toggle.configure_state(tk.NORMAL)

        # Enable master toggle for this side
        #if side == "left":
        #    self.master_left_toggle.configure_state(tk.NORMAL)
        #else:
        #    self.master_right_toggle.configure_state(tk.NORMAL)

    def _disable_category_buttons(self, side):
        """Disable category toggle switches for the specified side (left or right)"""
        # Category IDs that have toggle switches
        category_ids = ["photos", "sms", "contacts", "calendar", "notes",
                       "call_history", "voicemail", "voice_memos", "settings"]

        # Disable all toggle switches for this side
        for cat_id in category_ids:
            toggle = self.category_buttons.get(f"{cat_id}_{side}")
            if toggle:
                toggle.configure_state(tk.DISABLED)

    def _add_device_frame(self, wallpaper_img, is_ipad, target_height=220):
        """Add iOS device frame around wallpaper image using PNG assets

        Args:
            wallpaper_img: The wallpaper image to frame
            is_ipad: Whether this is an iPad device
            target_height: Target height for the frame in pixels (default 220 for connected device, 130 for merge panel)
        """
        try:
            # Get script directory to find frame assets
            script_dir = os.path.dirname(os.path.abspath(__file__))

            # Choose frame based on device type
            if is_ipad:
                frame_path = get_resource_path("iPadFrame.png")
            else:
                frame_path = get_resource_path("iPhoneFrame.png")

            # Check if frame asset exists
            if not os.path.exists(frame_path):
                print(f"[DEBUG] Frame asset not found: {frame_path}")
                return wallpaper_img

            # Load the frame PNG
            frame = Image.open(frame_path)
            orig_frame_width, orig_frame_height = frame.size

            # Scale frame to target height while maintaining frame aspect ratio
            frame_aspect = orig_frame_width / orig_frame_height
            scaled_frame_height = target_height
            scaled_frame_width = int(scaled_frame_height * frame_aspect)
            frame_scaled = frame.resize((scaled_frame_width, scaled_frame_height), Image.Resampling.LANCZOS)

            # Scale wallpaper to cover the frame area (no letterboxing)
            wp_width, wp_height = wallpaper_img.size
            if wp_width == 0 or wp_height == 0:
                return wallpaper_img
            scale = max(scaled_frame_width / wp_width, scaled_frame_height / wp_height)
            scaled_wp_width = int(wp_width * scale)
            scaled_wp_height = int(wp_height * scale)
            wallpaper_scaled = wallpaper_img.resize((scaled_wp_width, scaled_wp_height), Image.Resampling.LANCZOS)

            # Create canvas sized to frame
            canvas_width = scaled_frame_width
            canvas_height = scaled_frame_height

            # Create result canvas with transparent background
            result = Image.new('RGBA', (canvas_width, canvas_height), (0, 0, 0, 0))

            # Center wallpaper on canvas
            wp_x = (canvas_width - scaled_wp_width) // 2
            wp_y = (canvas_height - scaled_wp_height) // 2
            if wallpaper_scaled.mode != 'RGBA':
                wallpaper_scaled = wallpaper_scaled.convert('RGBA')
            result.paste(wallpaper_scaled, (wp_x, wp_y))

            # Composite frame on top - the frame's alpha channel will mask the wallpaper
            if frame_scaled.mode == 'RGBA':
                result.paste(frame_scaled, (0, 0), frame_scaled)
            else:
                result.paste(frame_scaled, (0, 0))

            return result

        except Exception as e:
            # If frame loading fails, return original image
            print(f"[DEBUG] Frame loading failed: {e}")
            import traceback
            traceback.print_exc()
            return wallpaper_img

    def _create_category_matrix(self, parent):
        """Create the data category selection matrix with ultra-compact 2-column layout"""
        frame = ttk.LabelFrame(parent, text="DATA CATEGORY SELECTION", padding=1)
        frame.pack(fill=tk.X)

        # Warning banner for empty selection (smaller font & padding)
        self.empty_warning = tk.Label(
            frame,
            text="⚠ No data categories selected. All data categories will be completely omitted from the output backup.",
            bg="#f39c12", fg="white", font=("Arial", 8, "bold"), pady=2
        )
        # Not packed yet — shown conditionally

        # Main container (tight padding)
        main_container = ttk.Frame(frame)
        main_container.pack(fill=tk.BOTH, expand=True, padx=4, pady=2)
        main_container.columnconfigure(0, weight=1)
        main_container.columnconfigure(1, weight=1)

        # ===== LEFT COLUMN =====
        left_frame = ttk.LabelFrame(main_container, text="Select items to keep from Left Backup", padding=1)
        left_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 3))
        left_frame.columnconfigure(0, weight=1)
        left_frame.rowconfigure(0, weight=1)

        #master_left_label = ttk.Label(left_frame, text="All Categories", font=("Arial", 8, "bold"))
        #master_left_label.grid(row=0, column=0, sticky=tk.W, padx=(0, 4), pady=(0, 1))

        #self.master_left_var = tk.IntVar(value=1)
        #self.master_left_toggle = iOSToggleSwitch(left_frame, self.master_left_var,
        #                                          command=lambda: self._on_master_toggle_left())
        #self.master_left_toggle.grid(row=0, column=1, sticky=tk.E, padx=(0, 4), pady=(0, 2))
        #self.master_left_toggle.configure_state(tk.DISABLED)

        # ===== RIGHT COLUMN =====
        right_frame = ttk.LabelFrame(main_container, text="Select items to keep from Right Backup", padding=1)
        right_frame.grid(row=0, column=1, sticky="nsew", padx=(3, 0))
        right_frame.columnconfigure(0, weight=1)
        right_frame.rowconfigure(0, weight=1)

        #master_right_label = ttk.Label(right_frame, text="All Categories", font=("Arial", 8, "bold"))
        #master_right_label.grid(row=0, column=0, sticky=tk.W, padx=(0, 4), pady=(0, 1))

        #self.master_right_var = tk.IntVar(value=1)
        #self.master_right_toggle = iOSToggleSwitch(right_frame, self.master_right_var,
        #                                           command=lambda: self._on_master_toggle_right())
        #self.master_right_toggle.grid(row=0, column=1, sticky=tk.E, padx=(0, 4), pady=(0, 2))
        #self.master_right_toggle.configure_state(tk.DISABLED)

        # ===== CATEGORY ROWS =====
        self.category_labels_left = {}
        self.category_labels_right = {}
        self.category_buttons = {}

        categories = [
            ("photos", "📷", "Photos & Videos", self.photos_left, self.photos_right, False),
            ("sms", "💬", "SMS", self.sms_left, self.sms_right, False),
            ("contacts", "👤", "Contacts", self.contacts_left, self.contacts_right, False),
            ("calendar", "📅", "Calendar", self.calendar_left, self.calendar_right, False),
            ("notes", "📝", "Notes", self.notes_left, self.notes_right, False),
            ("call_history", "📞", "Call History", self.call_history_left, self.call_history_right, False),
            ("voicemail", "🎤", "Voicemail", self.voicemail_left, self.voicemail_right, False),
            ("voice_memos", "🎵", "Voice Memos", self.voice_memos_left, self.voice_memos_right, False),
        ]

        # Categories that support preview
        previewable_categories = {'contacts', 'photos', 'sms', 'notes', 'calendar', 'call_history', 'voicemail', 'voice_memos'}

        for row_idx, (cat_id, emoji, name, left_var, right_var, is_settings) in enumerate(categories, start=1):
            # Left label
            left_label = ttk.Label(left_frame, text=f"{emoji} {name}", font=("Arial", 8))
            left_label.grid(row=row_idx, column=0, sticky=tk.W, padx=(0, 4), pady=1)
            self.category_labels_left[cat_id] = left_label

            # Make label clickable if preview is available
            if cat_id in previewable_categories:
                left_label.config(foreground="#3498db", cursor="hand2")
                left_label.bind("<Button-1>", lambda e, c=cat_id: self._open_category_preview(c, "left"))
                # Add tooltip hint
                left_label.bind("<Enter>", lambda e, l=left_label: l.config(font=("Arial", 8, "underline")))
                left_label.bind("<Leave>", lambda e, l=left_label: l.config(font=("Arial", 8)))

            # Left toggle
            toggle_left = iOSToggleSwitch(left_frame, left_var,
                                          command=lambda v=left_var, rv=right_var, s=is_settings, cid=cat_id, sd='left':
                                              self._on_toggle_change(v, rv, s, sd, cid))
            toggle_left.grid(row=row_idx, column=1, sticky=tk.E, padx=(0, 20), pady=2)
            toggle_left.configure_state(tk.DISABLED)
            self.category_buttons[f"{cat_id}_left"] = toggle_left

            # Right label
            right_label = ttk.Label(right_frame, text=f"{emoji} {name}", font=("Arial", 8))
            right_label.grid(row=row_idx, column=0, sticky=tk.W, padx=(0, 4), pady=1)
            self.category_labels_right[cat_id] = right_label

            # Make label clickable if preview is available
            if cat_id in previewable_categories:
                right_label.config(foreground="#3498db", cursor="hand2")
                right_label.bind("<Button-1>", lambda e, c=cat_id: self._open_category_preview(c, "right"))
                # Add tooltip hint
                right_label.bind("<Enter>", lambda e, l=right_label: l.config(font=("Arial", 8, "underline")))
                right_label.bind("<Leave>", lambda e, l=right_label: l.config(font=("Arial", 8)))

            # Right toggle
            toggle_right = iOSToggleSwitch(right_frame, right_var,
                                           command=lambda v=right_var, lv=left_var, s=is_settings, cid=cat_id, sd='right':
                                               self._on_toggle_change(v, lv, s, sd, cid))
            toggle_right.grid(row=row_idx, column=1, sticky=tk.E, padx=(0, 20), pady=2)
            toggle_right.configure_state(tk.DISABLED)
            self.category_buttons[f"{cat_id}_right"] = toggle_right


    def _open_category_preview(self, category_id: str, side: str):
        """Open preview window for a category.

        Args:
            category_id: Category to preview ('contacts', 'sms', etc.)
            side: Which backup ('left' or 'right')
        """
        # Get the backup for this side
        backup = self.left_backup if side == "left" else self.right_backup

        if not backup or not backup.is_valid:
            messagebox.showwarning(
                "No Backup Loaded",
                f"Please load a backup on the {side} side first."
            )
            return

        if not getattr(backup, 'is_supported', True):
            messagebox.showwarning(
                'Preview Unavailable',
                'This backup is not supported. Preview is disabled.',
                parent=self.root
            )
            return
        if getattr(backup, 'is_encrypted', False):
            if not self._ensure_encrypted_backup_access(backup, "preview"):
                return

        # Get backup label for window title
        backup_label = f"{'Left' if side == 'left' else 'Right'} Backup"

        try:
            # Import preview windows and extractors
            from extractors.contacts_extractor import ContactsExtractor
            from preview_windows.contacts_preview import ContactsPreviewWindow
            from extractors.photos_extractor import PhotosExtractor
            from preview_windows.photos_preview import PhotosPreviewWindow
            from extractors.sms_extractor import SMSExtractor
            from preview_windows.sms_preview import SMSPreviewWindow
            from extractors.notes_extractor import NotesExtractor
            from preview_windows.notes_preview import NotesPreviewWindow
            from extractors.calendar_extractor import CalendarExtractor
            from preview_windows.calendar_preview import CalendarPreviewWindow
            from extractors.call_history_extractor import CallHistoryExtractor
            from preview_windows.call_history_preview import CallHistoryPreviewWindow
            from extractors.voicemail_extractor import VoicemailExtractor
            from preview_windows.voicemail_preview import VoicemailPreviewWindow
            from extractors.voice_memos_extractor import VoiceMemosExtractor
            from preview_windows.voice_memos_preview import VoiceMemosPreviewWindow

            # Open appropriate preview window based on category
            if category_id == 'contacts':
                extractor = ContactsExtractor(backup.path)
                ContactsPreviewWindow(self.root, extractor, "Contacts", backup_label)
            elif category_id == 'photos':
                extractor = PhotosExtractor(backup.path)
                PhotosPreviewWindow(self.root, extractor, "Photos", backup_label)
            elif category_id == 'sms':
                extractor = SMSExtractor(backup.path)
                SMSPreviewWindow(self.root, extractor)
            elif category_id == 'notes':
                extractor = NotesExtractor(backup.path)
                NotesPreviewWindow(self.root, extractor, "Notes", backup_label)
            elif category_id == 'calendar':
                extractor = CalendarExtractor(backup.path)
                CalendarPreviewWindow(self.root, extractor, "Calendar", backup_label)
            elif category_id == 'call_history':
                extractor = CallHistoryExtractor(backup.path)
                CallHistoryPreviewWindow(self.root, extractor, "Call History", backup_label)
            elif category_id == 'voicemail':
                extractor = VoicemailExtractor(backup.path)
                VoicemailPreviewWindow(self.root, extractor, "Voicemail", backup_label)
            elif category_id == 'voice_memos':
                extractor = VoiceMemosExtractor(backup.path)
                VoiceMemosPreviewWindow(self.root, extractor, "Voice Memos", backup_label)
            else:
                messagebox.showinfo(
                    "Preview Not Available",
                    f"Preview for {category_id} is not yet implemented."
                )

        except FileNotFoundError as e:
            messagebox.showerror(
                "Database Not Found",
                f"Could not find {category_id} database in backup:\n\n{str(e)}"
            )
        except Exception as e:
            messagebox.showerror(
                "Preview Error",
                f"Error opening {category_id} preview:\n\n{str(e)}"
            )
            import traceback
            traceback.print_exc()

    def _on_toggle_change(self, var, other_var, is_settings, side, cat_id):
        """Handle toggle switch state changes"""
        # Variable is already updated by the toggle switch
        is_on = bool(var.get())

        # If this is Settings, enforce mutual exclusion
        if is_settings and is_on:
            other_var.set(False)
            # Link Settings selection to New/Target device dropdown
            self.new_device.set(side)

        # Update label styling based on toggle state
        self._update_category_label_style(cat_id, side, is_on)

        # Update master toggle state based on individual toggles
        self._update_master_toggle_state(side)

        self._check_empty_warning()

    def _show_backup_operations_menu(self, side: str):
        """Show context menu for backup operations (Extract All, etc.)."""
        backup = self.left_backup if side == 'left' else self.right_backup

        if not backup:
            messagebox.showinfo(
                "No Backup Loaded",
                f"Please load a backup on the {side} side first.",
                parent=self.root
            )
            return

        # Create context menu
        menu = tk.Menu(self.root, tearoff=0)

        extract_state = tk.NORMAL if backup.is_supported else tk.DISABLED
        menu.add_command(
            label="📤 Extract All Data...",
            command=lambda: self._start_full_extraction(backup, side),
            state=extract_state
        )

        menu.add_separator()

        menu.add_command(
            label="ℹ️ Backup Information",
            command=lambda: self._show_backup_info(backup)
        )

        # Show menu at cursor position
        try:
            menu.tk_popup(self.root.winfo_pointerx(), self.root.winfo_pointery())
        finally:
            menu.grab_release()

    def _show_backup_info_for_side(self, side: str):
        backup = self.left_backup if side == 'left' else self.right_backup
        if not backup:
            messagebox.showinfo(
                "No Backup Loaded",
                f"Please load a backup on the {side} side first.",
                parent=self.root
            )
            return
        self._show_backup_info(backup)

    def _show_backup_info(self, backup):
        """Show backup information dialog with copyable text and browseable paths."""
        import tkinter as tk
        from tkinter import ttk
        import subprocess
        import os

        # Create dialog window
        dialog = tk.Toplevel(self.root)
        dialog.title(f"Backup Information - {backup.name}")
        dialog.geometry("600x500")
        dialog.resizable(True, True)

        # Make it modal
        dialog.transient(self.root)
        dialog.grab_set()

        # Main frame with padding
        main_frame = ttk.Frame(dialog, padding=15)
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Title label
        title_label = ttk.Label(
            main_frame,
            text=f"📱 {backup.name}",
            font=("Arial", 12, "bold")
        )
        title_label.pack(pady=(0, 10))

        # Info text widget (scrollable and selectable)
        text_frame = ttk.Frame(main_frame)
        text_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))

        text_widget = tk.Text(
            text_frame,
            wrap=tk.WORD,
            font=("Consolas", 9),
            padx=10,
            pady=10,
            relief=tk.SOLID,
            borderwidth=1
        )
        scrollbar = ttk.Scrollbar(text_frame, command=text_widget.yview)
        text_widget.configure(yscrollcommand=scrollbar.set)

        text_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # Format and insert backup information
        # Get size text with validation status
        if backup.size_gb_validated is not None:
            size_text = f"{backup.size_gb_validated:.2f} GB (verified)"
        else:
            size_text = f"~{backup.size_gb:.2f} GB (estimated)"

        info_lines = [
            ("Device Name:", backup.name),
            ("Model:", backup.device_model),
            ("iOS Version:", backup.ios_version),
            ("Last Backup:", backup.last_backup),
            ("UDID:", backup.udid),
            ("Size:", size_text),
            ("Path:", backup.path),
        ]

        for label, value in info_lines:
            text_widget.insert(tk.END, f"{label}\n", "label")
            text_widget.insert(tk.END, f"  {value}\n\n", "value")

        # Configure text tags for styling
        text_widget.tag_configure("label", font=("Arial", 9, "bold"), foreground="#555")
        text_widget.tag_configure("value", font=("Consolas", 9), foreground="#000")

        # Make text read-only but still selectable
        text_widget.configure(state=tk.DISABLED)

        # Button frame
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=(5, 0))

        # Copy All button
        def copy_all():
            text_to_copy = "\n".join([f"{label} {value}" for label, value in info_lines])
            dialog.clipboard_clear()
            dialog.clipboard_append(text_to_copy)
            copy_btn.config(text="✓ Copied!")
            dialog.after(1500, lambda: copy_btn.config(text="📋 Copy All"))

        copy_btn = ttk.Button(button_frame, text="📋 Copy All", command=copy_all)
        copy_btn.pack(side=tk.LEFT, padx=(0, 5))

        # Browse to Path button
        def browse_to_path():
            if os.path.exists(backup.path):
                # Use cross-platform file manager to open and select backup folder
                FileManager.open_and_select(backup.path)
            else:
                messagebox.showwarning("Path Not Found", f"The backup path no longer exists:\n\n{backup.path}", parent=dialog)

        browse_btn = ttk.Button(button_frame, text="📂 Browse to Path", command=browse_to_path)
        browse_btn.pack(side=tk.LEFT, padx=(0, 5))

        # Close button
        close_btn = ttk.Button(button_frame, text="Close", command=dialog.destroy)
        close_btn.pack(side=tk.RIGHT)

        # Center the dialog on the parent window
        dialog.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - (dialog.winfo_width() // 2)
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - (dialog.winfo_height() // 2)
        dialog.geometry(f"+{x}+{y}")

    def _start_full_extraction(self, backup, side: str):
        """Start full extraction process."""
        if not getattr(backup, 'is_supported', True):
            messagebox.showwarning(
                'Extraction Disabled',
                'This backup is not supported. Extraction is disabled.',
                parent=self.root
            )
            return
        if getattr(backup, 'is_encrypted', False):
            if not self._ensure_encrypted_backup_access(backup, "extract"):
                return
        from full_extraction_manager import FullExtractionManager
        from full_extraction_dialogs import (
            FullExtractionDialog,
            FullExtractionProgressDialog,
            ParallelExtractionProgressDialog
        )

        try:
            # Create extraction manager to get available categories
            manager = FullExtractionManager(backup.path, "", backup_access=backup.backup_access)

            # Show configuration dialog
            dialog = FullExtractionDialog(self.root, backup, manager)
            self.root.wait_window(dialog.dialog)

            if not dialog.result:
                # User cancelled
                return
            # Get configuration
            output_dir = dialog.result['output_dir']
            categories = dialog.result['categories']
            options = dialog.result['options']
            options.setdefault("app_version", APP_VERSION)
            options.setdefault("build_number", get_build_number())
            options.setdefault("timezone", datetime.now().astimezone().tzname() or "Local")
            options.setdefault("extraction_type", "Full")

            # Create extraction manager with selected options
            manager = FullExtractionManager(
                backup.path,
                output_dir,
                categories=categories,
                options=options,
                backup_access=backup.backup_access,
            )

            # Choose dialog based on parallel mode
            if options.get('parallel_mode', True):
                # Use parallel extraction dialog
                try:
                    progress_dialog = ParallelExtractionProgressDialog(
                        self.root,
                        manager,
                        backup.name
                    )
                    progress_dialog.start()
                except Exception as parallel_error:
                    # Fallback to sequential on error
                    print(f"[WARNING] Parallel extraction failed, falling back to sequential: {parallel_error}")
                    import traceback
                    traceback.print_exc()

                    # Recreate manager for sequential extraction
                    manager = FullExtractionManager(
                        backup.path,
                        output_dir,
                        categories=categories,
                        options=options,
                        backup_access=backup.backup_access,
                    )
                    progress_dialog = FullExtractionProgressDialog(
                        self.root,
                        manager,
                        backup.name
                    )
                    progress_dialog.start()
            else:
                # Use sequential extraction dialog
                progress_dialog = FullExtractionProgressDialog(
                    self.root,
                    manager,
                    backup.name
                )
                progress_dialog.start()

        except Exception as e:
            messagebox.showerror(
                "Extraction Error",
                f"Failed to start extraction:\n\n{str(e)}",
                parent=self.root
            )
            import traceback
            traceback.print_exc()

    def _update_category_label_style(self, cat_id, side, is_on):
        """Update category label appearance based on toggle state"""
        label_dict = self.category_labels_left if side == 'left' else self.category_labels_right
        label = label_dict.get(cat_id)

        if label:
            # Categories that support preview (should stay blue)
            previewable_categories = {'contacts', 'photos', 'sms', 'notes', 'calendar', 'call_history', 'voicemail', 'voice_memos'}

            if is_on:
                # Normal appearance when ON
                # Keep blue color for previewable categories
                if cat_id in previewable_categories:
                    label.config(foreground="#3498db", font=("Arial", 8))
                else:
                    label.config(foreground="black", font=("Arial", 8))
            else:
                # Red with strikethrough when OFF
                label.config(foreground="red", font=("Arial", 8, "overstrike"))

    #def _on_master_toggle_left(self):
    #    """Handle left master toggle changes"""
    #    if self.master_left_var.get():
    #        self._select_all_left()
    #    else:
    #        self._deselect_all_left()
    #
    #def _on_master_toggle_right(self):
    #    """Handle right master toggle changes"""
    #    if self.master_right_var.get():
    #        self._select_all_right()
    #    else:
    #        self._deselect_all_right()
    #
    def _update_master_toggle_state(self, side):
        skip = "true"
    #    """Update master toggle state based on individual category toggles"""
    #    categories = ['photos', 'sms', 'contacts', 'calendar', 'notes',
    #                  'call_history', 'voicemail', 'voice_memos']
    #
    #    # Check if all categories are selected
    #    all_on = True
    #    for cat_id in categories:
    #        var = getattr(self, f"{cat_id}_{side}", None)
    #        if var is not None and not var.get():
    #            all_on = False
    #            break
    #
    #    # Update master toggle without triggering its command
    #    if side == 'left':
    #        # Temporarily disable trace to avoid recursion
    #        self.master_left_var.set(1 if all_on else 0)
    #    else:
    #        self.master_right_var.set(1 if all_on else 0)

    def _select_all_left(self):
        """Keep all left backup categories"""
        categories = ['photos', 'sms', 'contacts', 'calendar', 'notes',
                      'call_history', 'voicemail', 'voice_memos']

        for cat_id in categories:
            var = getattr(self, f"{cat_id}_left", None)
            if var is not None:
                var.set(True)  # Toggle switch will automatically update visually
                self._update_category_label_style(cat_id, 'left', True)

        # Settings logic only if the vars still exist
        if hasattr(self, "settings_left") and hasattr(self, "settings_right"):
            if not self.settings_right.get():
                self.settings_left.set(True)
                if hasattr(self, "new_device"):
                    self.new_device.set("left")
            else:
                self.settings_left.set(False)

        self._check_empty_warning()


    def _deselect_all_left(self):
        """Remove all left backup categories"""
        categories = ['photos', 'sms', 'contacts', 'calendar', 'notes',
                      'call_history', 'voicemail', 'voice_memos']

        for cat_id in categories:
            var = getattr(self, f"{cat_id}_left", None)
            if var is not None:
                var.set(False)  # Toggle switch will automatically update visually
                self._update_category_label_style(cat_id, 'left', False)

        # If settings vars still exist, make sure at least one side is selected
        if hasattr(self, "settings_left") and hasattr(self, "settings_right"):
            if not self.settings_right.get():
                self.settings_right.set(True)

        self._check_empty_warning()


    def _select_all_right(self):
        """Keep all right backup categories"""
        categories = ['photos', 'sms', 'contacts', 'calendar', 'notes',
                      'call_history', 'voicemail', 'voice_memos']

        for cat_id in categories:
            var = getattr(self, f"{cat_id}_right", None)
            if var is not None:
                var.set(True)  # Toggle switch will automatically update visually
                self._update_category_label_style(cat_id, 'right', True)

        # Settings logic only if present
        if hasattr(self, "settings_left") and hasattr(self, "settings_right"):
            if not self.settings_left.get():
                self.settings_right.set(True)
                if hasattr(self, "new_device"):
                    self.new_device.set("right")
            else:
                self.settings_right.set(False)

        self._check_empty_warning()


    def _deselect_all_right(self):
        """Remove all right backup categories"""
        categories = ['photos', 'sms', 'contacts', 'calendar', 'notes',
                      'call_history', 'voicemail', 'voice_memos']

        for cat_id in categories:
            var = getattr(self, f"{cat_id}_right", None)
            if var is not None:
                var.set(False)  # Toggle switch will automatically update visually
                self._update_category_label_style(cat_id, 'right', False)

        # Ensure settings has at least one side selected if settings still exists
        if hasattr(self, "settings_left") and hasattr(self, "settings_right"):
            if not self.settings_left.get():
                self.settings_left.set(True)

        self._check_empty_warning()


    def _check_empty_warning(self):
        """Show warning banner if no categories are selected"""
        # Check if any non-settings category is selected
        any_selected = (
            self.photos_left.get() or self.photos_right.get() or
            self.sms_left.get() or self.sms_right.get() or
            self.contacts_left.get() or self.contacts_right.get() or
            self.calendar_left.get() or self.calendar_right.get() or
            self.notes_left.get() or self.notes_right.get() or
            self.call_history_left.get() or self.call_history_right.get() or
            self.voicemail_left.get() or self.voicemail_right.get() or
            self.voice_memos_left.get() or self.voice_memos_right.get()
        )

        # Show or hide warning banner
        if not any_selected:
            self.empty_warning.pack(fill=tk.X, padx=10, pady=5, before=self.empty_warning.master.winfo_children()[1])
        else:
            self.empty_warning.pack_forget()

    def _create_styled_button(self, parent, text, command, bg_color, hover_color,
                              font=None, padx=None, pady=None, **kwargs):
        """Create a styled button with hover effects"""
        # Use defaults if not specified
        if font is None:
            font = ("Arial", 9, "bold")
        if padx is None:
            padx = 12
        if pady is None:
            pady = 6

        btn = tk.Button(parent, text=text, command=command, bg=bg_color, fg="white",
                       font=font, cursor="hand2", relief=tk.FLAT,
                       padx=padx, pady=pady, activebackground=hover_color, activeforeground="white",
                       **kwargs)

        # Bind hover effects
        def on_enter(e):
            if btn['state'] != 'disabled':
                btn['background'] = hover_color

        def on_leave(e):
            if btn['state'] != 'disabled':
                btn['background'] = bg_color

        btn.bind("<Enter>", on_enter)
        btn.bind("<Leave>", on_leave)

        return btn

    def _create_output_section(self, parent):
        """Create merged progress and control section"""
        # Container frame with custom header
        container = ttk.Frame(parent)
        container.pack(fill=tk.X)

        # Header with title, status, and hamburger menu
        header_frame = tk.Frame(container, bg="#e8e8e8", height=26)
        header_frame.pack(fill=tk.X)
        header_frame.pack_propagate(False)

        # Title label with status (updated dynamically)
        self.status_label = tk.Label(header_frame, text="Progress & Controls - Ready to create backup",
                                     bg="#e8e8e8", font=("Arial", 9, "bold"), fg="#333")
        self.status_label.pack(side=tk.LEFT, padx=10, pady=5)

        # Hamburger menu button (☰)
        hamburger_btn = tk.Button(header_frame, text="☰", bg="#e8e8e8", fg="#333",
                                 font=("Arial", 14), relief=tk.FLAT, cursor="hand2",
                                 command=self._show_hamburger_menu, padx=8, pady=0)
        hamburger_btn.pack(side=tk.RIGHT, padx=5)

        # Hover effect for hamburger
        def on_enter(e):
            hamburger_btn['bg'] = "#d0d0d0"
        def on_leave(e):
            hamburger_btn['bg'] = "#e8e8e8"
        hamburger_btn.bind("<Enter>", on_enter)
        hamburger_btn.bind("<Leave>", on_leave)

        # Main content frame
        content_frame = ttk.Frame(container, padding=8)
        content_frame.pack(fill=tk.X)

        # Main horizontal layout
        main_row = ttk.Frame(content_frame)
        main_row.pack(fill=tk.X)

        # === LEFT SIDE: Progress ===
        progress_frame = ttk.Frame(main_row)
        progress_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))

        # Progress bar (sized to match button height of ~33px)
        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(progress_frame, variable=self.progress_var, maximum=100)
        self.progress_bar.pack(fill=tk.BOTH, expand=True)
        # Set minimum height to match buttons
        self.progress_bar.config(length=200)
        progress_frame.config(height=33)

        # Log buffer for popup window
        self.log_buffer = ["Ready to start modification...\n"]

        # === RIGHT SIDE: Buttons (clean, just Create & Stop) ===
        buttons_frame = ttk.Frame(main_row)
        buttons_frame.pack(side=tk.RIGHT)

        # Start Processing button (green, more prominent)
        self.start_btn = self._create_styled_button(buttons_frame, "▶️  Modify iOS Backup",
                                                     self._start_modify, "#27ae60", "#229954",
                                                     font=("Arial", 9, "bold"), padx=15, pady=6)
        self.start_btn.pack(side=tk.LEFT, padx=(0, 5))

        # Stop Processing button (red, starts disabled)
        self.stop_btn = self._create_styled_button(buttons_frame, "⏹️  Stop",
                                                    self._stop_modify, "#e74c3c", "#c0392b",
                                                    font=("Arial", 9, "bold"), padx=15, pady=6,
                                                    state=tk.DISABLED)
        self.stop_btn.pack(side=tk.LEFT)

    def _show_hamburger_menu(self):
        """Show hamburger dropdown menu"""
        menu = tk.Menu(self.root, tearoff=0)
        menu.add_command(label="⚙️  Advanced Settings", command=self._show_advanced)
        menu.add_command(label="📋  View Log", command=self._view_log)
        menu.add_command(label="🧪  Validate Backup", command=self._validate_backup)

        # Position menu near the hamburger button
        try:
            x = self.root.winfo_pointerx()
            y = self.root.winfo_pointery()
            menu.post(x, y)
        except:
            pass

    def _browse_output(self):
        """Browse for output directory"""
        folder = filedialog.askdirectory(title="Select Output Directory")
        if folder:
            self.output_path.set(folder)

    def _show_advanced(self):
        """Show advanced settings dialog"""
        dialog = tk.Toplevel(self.root)
        dialog.title("Advanced Settings")
        dialog.geometry("500x360")
        dialog.transient(self.root)
        dialog.grab_set()

        frame = ttk.Frame(dialog, padding=20)
        frame.pack(fill=tk.BOTH, expand=True)

        # Prefer backup
        ttk.Label(frame, text="When conflicts occur, prefer data from:",
                 font=("Arial", 10, "bold")).pack(anchor=tk.W, pady=(0, 5))
        ttk.Radiobutton(frame, text="Left backup (Recovered)",
                       variable=self.prefer_backup, value="left").pack(anchor=tk.W)
        ttk.Radiobutton(frame, text="Right backup (Customer)",
                       variable=self.prefer_backup, value="right").pack(anchor=tk.W)

        ttk.Separator(frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=20)

        # New device
        ttk.Label(frame, text="Which backup represents the NEW/TARGET device?",
                 font=("Arial", 10, "bold")).pack(anchor=tk.W, pady=(0, 5))
        ttk.Label(frame, text="(Device metadata like UDID will be preserved from this backup)",
                 font=("Arial", 8), foreground="gray").pack(anchor=tk.W)
        ttk.Radiobutton(frame, text="Left backup (Recovered)",
                       variable=self.new_device, value="left").pack(anchor=tk.W)
        ttk.Radiobutton(frame, text="Right backup (Customer)",
                       variable=self.new_device, value="right").pack(anchor=tk.W)

        ttk.Separator(frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=20)

        # DPI scaling
        ttk.Label(frame, text="Display",
                 font=("Arial", 10, "bold")).pack(anchor=tk.W, pady=(0, 5))
        ttk.Checkbutton(
            frame,
            text="Enable DPI-aware scaling (requires restart)",
            variable=self.dpi_aware_var,
            command=self._on_dpi_setting_change
        ).pack(anchor=tk.W)

        ttk.Separator(frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=20)

        # Close button
        ttk.Button(frame, text="Close", command=dialog.destroy).pack()

    def _on_dpi_setting_change(self):
        enabled = bool(self.dpi_aware_var.get())
        self.dpi_aware_enabled = enabled
        _write_app_config(self.config_file, {'dpi_aware_enabled': enabled})
        messagebox.showinfo(
            "Restart Required",
            "Restart the app to apply DPI scaling changes."
        )

    def _create_progress_section(self, parent):
        """Create progress display section"""
        frame = ttk.LabelFrame(parent, text="Progress", padding=3)
        frame.pack(fill=tk.BOTH, expand=True)

        # Progress bar
        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(frame, variable=self.progress_var, maximum=100)
        self.progress_bar.pack(fill=tk.X, pady=(0, 3))

        # Status label
        self.status_label = ttk.Label(frame, text="Ready to modify", font=("Arial", 8))
        self.status_label.pack(anchor=tk.W)

        # Log buffer for popup window
        self.log_buffer = ["Ready to start modification...\n"]

    def _log_message(self, message):
        """Add message to log buffer"""
        self.log_buffer.append(message + "\n")

    def _show_output_location_dialog(self):
        """Show dialog to select output location for modified backup"""
        dialog = tk.Toplevel(self.root)
        dialog.title("Select Output Location")
        dialog.geometry("500x280")
        dialog.transient(self.root)
        dialog.grab_set()
        dialog.resizable(False, False)

        result = {"path": None}

        # Buttons frame at bottom (pack first to ensure it's always visible)
        button_container = tk.Frame(dialog, padx=20, pady=20)
        button_container.pack(side=tk.BOTTOM, fill=tk.X)

        # Main content frame
        main_frame = tk.Frame(dialog, padx=20)
        main_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True, pady=(20, 10))

        # Title
        title_label = tk.Label(main_frame, text="Where would you like to save the modified backup?",
                               font=("Arial", 11, "bold"))
        title_label.pack(pady=(0, 15))

        # Location choice variable
        location_choice = tk.StringVar(value="default")
        custom_path = tk.StringVar()

        # Get default iTunes backup location
        default_locations = Platform.get_default_backup_locations()
        default_path = default_locations[0] if default_locations else os.path.expanduser("~/")

        # Default location radio button
        default_radio = tk.Radiobutton(main_frame, text=f"Default iTunes Backup Location",
                                       variable=location_choice, value="default",
                                       font=("Arial", 10))
        default_radio.pack(anchor=tk.W, pady=5)

        default_path_label = tk.Label(main_frame, text=f"  {default_path}",
                                      font=("Arial", 8), fg="#666")
        default_path_label.pack(anchor=tk.W, padx=20)

        # Custom location radio button
        custom_radio = tk.Radiobutton(main_frame, text="Custom Location",
                                      variable=location_choice, value="custom",
                                      font=("Arial", 10))
        custom_radio.pack(anchor=tk.W, pady=(15, 5))

        # Custom path frame
        custom_frame = tk.Frame(main_frame)
        custom_frame.pack(fill=tk.X, padx=20, pady=5)

        custom_entry = tk.Entry(custom_frame, textvariable=custom_path, state="readonly",
                               font=("Arial", 9))
        custom_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))

        def browse_custom():
            folder = filedialog.askdirectory(title="Select Output Directory")
            if folder:
                custom_path.set(folder)
                location_choice.set("custom")

        browse_btn = tk.Button(custom_frame, text="Browse...", command=browse_custom,
                              bg="#3498db", fg="white", font=("Arial", 9),
                              padx=10, pady=2)
        browse_btn.pack(side=tk.LEFT)

        # Remember choice checkbox
        remember_var = tk.BooleanVar(value=False)
        remember_check = tk.Checkbutton(main_frame, text="Remember my choice",
                                        variable=remember_var, font=("Arial", 9))
        remember_check.pack(anchor=tk.W, pady=(15, 0))

        # Button callbacks
        def on_ok():
            if location_choice.get() == "default":
                result["path"] = default_path
            elif location_choice.get() == "custom":
                if custom_path.get():
                    result["path"] = custom_path.get()
                else:
                    messagebox.showerror("Error", "Please select a custom location or use the default.")
                    return

            # TODO: Save preference if remember_var.get() is True
            dialog.destroy()

        def on_cancel():
            result["path"] = None
            dialog.destroy()

        # Create buttons in the bottom button_container
        tk.Button(button_container, text="OK", command=on_ok, bg="#27ae60", fg="white",
                 font=("Arial", 10), padx=20, pady=5).pack(side=tk.LEFT, padx=5)
        tk.Button(button_container, text="Cancel", command=on_cancel, bg="#95a5a6", fg="white",
                 font=("Arial", 10), padx=20, pady=5).pack(side=tk.LEFT, padx=5)

        # Wait for dialog to close
        dialog.wait_window()

        return result["path"]

    def _start_modify(self):
        """Start the modification process"""
        # Validate inputs - require at least one backup
        if not self.left_backup and not self.right_backup:
            messagebox.showerror("Error", "Please load at least one backup (Left or Right)")
            return

        # Validate only the loaded backups
        if self.left_backup and not self.left_backup.is_valid:
            messagebox.showerror("Error", f"Left backup is invalid: {self.left_backup.validation_msg}")
            return

        if self.right_backup and not self.right_backup.is_valid:
            messagebox.showerror("Error", f"Right backup is invalid: {self.right_backup.validation_msg}")
            return

        # PRE-MERGE COMPATIBILITY CHECK (Option 2)
        # Check schema compatibility if both backups are loaded
        if self.left_backup and self.right_backup:
            if not self._check_merge_compatibility():
                return  # User cancelled merge

        if self.left_backup and getattr(self.left_backup, 'is_encrypted', False):
            if not self._ensure_encrypted_backup_access(self.left_backup, "merge this backup"):
                return

        if self.right_backup and getattr(self.right_backup, 'is_encrypted', False):
            if not self._ensure_encrypted_backup_access(self.right_backup, "merge this backup"):
                return

        # Detect single-backup mode
        single_backup_mode = bool(self.left_backup) != bool(self.right_backup)

        # Show output location dialog
        output_base_path = self._show_output_location_dialog()
        if not output_base_path:
            return  # User cancelled

        # Create timestamped subfolder
        # In single-backup mode, use the only available backup
        if single_backup_mode:
            new_device_backup = self.left_backup if self.left_backup else self.right_backup
        else:
            new_device_backup = self.right_backup if self.new_device.get() == "right" else self.left_backup

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        udid = new_device_backup.udid if new_device_backup else "unknown"
        subfolder_name = f"modified_backup_{timestamp}_{udid}"
        output_path = os.path.join(output_base_path, subfolder_name)

        # Set the output path
        self.output_path.set(output_path)

        # Build command
        script_dir = os.path.dirname(os.path.abspath(__file__))
        merge_script = os.path.join(script_dir, "merge_backups.py")

        cmd = [
            sys.executable,
            "-u",  # Force unbuffered output for real-time logging
            merge_script,
        ]

        # Add backup paths conditionally
        if self.left_backup:
            cmd.extend(["--recovered", self.left_backup.path])
        if self.right_backup:
            cmd.extend(["--customer", self.right_backup.path])

        if self.left_backup and self.left_backup.encryption_password:
            cmd.extend(["--recovered-password", self.left_backup.encryption_password])

        if self.right_backup and self.right_backup.encryption_password:
            cmd.extend(["--customer-password", self.right_backup.encryption_password])

        # Add output and device preference flags
        cmd.extend([
            "--out", self.output_path.get(),
            "--prefer", "customer" if self.prefer_backup.get() == "right" else "recovered",
            "--new-device", "customer" if self.new_device.get() == "right" else "recovered"
        ])

        # Add category merge mode flags
        # Translate Yes/No selections to mode strings:
        #
        # DUAL-BACKUP MODE (both backups loaded):
        #   Left=Yes, Right=Yes → "merge" (include from both)
        #   Left=Yes, Right=No → "source" (left only)
        #   Left=No, Right=Yes → "target" (right only)
        #   Left=No, Right=No → "skip" (completely omit from output)
        #
        # SINGLE-BACKUP MODE (only one backup loaded):
        #   Left only: Left=Yes → "source", Left=No → "skip"
        #   Right only: Right=Yes → "target", Right=No → "skip"

        def get_mode(left_var, right_var):
            """Convert left/right boolean selections to mode string"""
            left = left_var.get()
            right = right_var.get()

            # Single-backup mode - only consider the loaded backup's toggle
            if single_backup_mode:
                if self.left_backup and not self.right_backup:
                    # Left backup only - only consider left toggle
                    return "source" if left else "skip"
                elif self.right_backup and not self.left_backup:
                    # Right backup only - only consider right toggle
                    return "target" if right else "skip"

            # Dual-backup mode - combine both toggles
            if left and right:
                return "merge"
            elif left and not right:
                return "source"
            elif not left and right:
                return "target"
            else:
                # Both No - skip this category entirely
                return "skip"

        # Photos
        photos_mode = get_mode(self.photos_left, self.photos_right)
        cmd.extend(["--photos-mode", photos_mode])

        # SMS
        sms_mode = get_mode(self.sms_left, self.sms_right)
        cmd.extend(["--sms-mode", sms_mode])

        # Contacts
        contacts_mode = get_mode(self.contacts_left, self.contacts_right)
        cmd.extend(["--contacts-mode", contacts_mode])

        # Calendar
        calendar_mode = get_mode(self.calendar_left, self.calendar_right)
        cmd.extend(["--calendar-mode", calendar_mode])

        # Notes
        notes_mode = get_mode(self.notes_left, self.notes_right)
        cmd.extend(["--notes-mode", notes_mode])
        if notes_mode == "skip":
            messagebox.showwarning(
                "Notes Purge Warning",
                "Notes will be omitted from the backup. To validate a Notes purge,\n"
                "perform a full device erase before restore; otherwise existing\n"
                "\"On My iPhone\" notes may remain on the device."
            )

        # Call History
        call_history_mode = get_mode(self.call_history_left, self.call_history_right)
        cmd.extend(["--call-history-mode", call_history_mode])

        # Voicemail
        voicemail_mode = get_mode(self.voicemail_left, self.voicemail_right)
        cmd.extend(["--voicemail-mode", voicemail_mode])

        # Voice Memos
        voice_memos_mode = get_mode(self.voice_memos_left, self.voice_memos_right)
        cmd.extend(["--voice-memos-mode", voice_memos_mode])

        # Clear log buffer
        self.log_buffer = []

        self._log_message("Starting modification process...")
        self._log_message(f"Command: {' '.join(cmd)}")
        self._log_message("")

        # Update UI state
        self.modify_running = True
        self.merge_start_time = datetime.now()  # Track start time for elapsed/ETA
        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self.status_label.config(text="Progress & Controls - Initializing merge... This may take a few minutes for large backups. Please wait...")
        self.progress_var.set(0)

        # Start modification in background thread
        thread = threading.Thread(target=self._run_modify, args=(cmd,), daemon=True)
        thread.start()

    def _run_modify(self, cmd):
        """Run modification process in background"""
        try:
            # DEBUG: Log thread start
            self.output_queue.put(("log", "[DEBUG] Modification thread started"))
            self.output_queue.put(("log", f"[DEBUG] Command: {' '.join(cmd)}"))

            # Set environment to force unbuffered output
            env = os.environ.copy()
            env['PYTHONUNBUFFERED'] = '1'

            self.output_queue.put(("log", "[DEBUG] Creating subprocess..."))

            self.process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=0,  # Unbuffered
                universal_newlines=True,
                env=env
            )

            self.output_queue.put(("log", f"[DEBUG] Subprocess created with PID: {self.process.pid}"))
            self.output_queue.put(("log", "[DEBUG] Starting to read output..."))

            # Read output line by line
            line_count = 0
            for line in iter(self.process.stdout.readline, ''):
                if line:
                    line_count += 1
                    # Log every line for debugging
                    self.output_queue.put(("log", line.rstrip()))

                    # Log line count periodically
                    if line_count % 10 == 0:
                        self.output_queue.put(("log", f"[DEBUG] Read {line_count} lines so far"))

                    # Parse progress - improved parsing
                    if "[PROGRESS]" in line or "Processing file" in line:
                        # Extract percentage - look for pattern like "(4%)"
                        if "(" in line and "%" in line:
                            try:
                                # Find the part between ( and %)
                                start = line.rfind("(")
                                end = line.rfind("%")
                                if start != -1 and end != -1 and end > start:
                                    pct_str = line[start+1:end].strip()
                                    pct = float(pct_str)
                                    self.output_queue.put(("progress", pct))
                            except Exception as e:
                                self.output_queue.put(("log", f"[DEBUG] Progress parse error: {e}"))

            self.output_queue.put(("log", f"[DEBUG] Finished reading output. Total lines: {line_count}"))

            # Wait for completion
            return_code = self.process.wait()
            self.output_queue.put(("log", f"[DEBUG] Process exited with code: {return_code}"))

            if return_code == 0:
                self.output_queue.put(("complete", "success"))
            else:
                self.output_queue.put(("complete", "error"))

        except Exception as e:
            import traceback
            error_msg = f"[DEBUG] Exception in modification thread: {str(e)}\n{traceback.format_exc()}"
            self.output_queue.put(("log", error_msg))
            self.output_queue.put(("error", str(e)))

    def _stop_modify(self):
        """Stop the modification process"""
        if self.process:
            self.process.terminate()
            self._log_message("\n=== MODIFICATION STOPPED BY USER ===\n")
            self._modify_finished(False)

    def _format_elapsed_time(self, elapsed_seconds):
        """Format elapsed time in human-readable format (e.g., '2m 34s', '1h 15m')"""
        if elapsed_seconds < 60:
            return f"{int(elapsed_seconds)}s"
        elif elapsed_seconds < 3600:
            minutes = int(elapsed_seconds // 60)
            seconds = int(elapsed_seconds % 60)
            return f"{minutes}m {seconds}s"
        else:
            hours = int(elapsed_seconds // 3600)
            minutes = int((elapsed_seconds % 3600) // 60)
            return f"{hours}h {minutes}m"

    def _format_eta(self, eta_seconds):
        """Format ETA in human-readable format (e.g., '~3 minutes', '~1 hour')"""
        if eta_seconds < 60:
            return f"~{int(eta_seconds)} seconds"
        elif eta_seconds < 3600:
            minutes = int(eta_seconds // 60)
            if minutes == 1:
                return "~1 minute"
            return f"~{minutes} minutes"
        else:
            hours = int(eta_seconds // 3600)
            minutes = int((eta_seconds % 3600) // 60)
            if hours == 1 and minutes == 0:
                return "~1 hour"
            elif minutes == 0:
                return f"~{hours} hours"
            else:
                return f"~{hours}h {minutes}m"

    def _check_output_queue(self):
        """Check for output from background process"""
        try:
            while True:
                msg_type, data = self.output_queue.get_nowait()

                if msg_type == "log":
                    self._log_message(data)

                    # Update status label with current operation
                    if "[INFO]" in data or "[PROGRESS]" in data:
                        # Extract meaningful status
                        status = data.replace("[INFO]", "").replace("[PROGRESS]", "").strip()
                        if status and len(status) < 100:  # Only show short status
                            self.status_label.config(text=f"Progress & Controls - {status}")

                elif msg_type == "progress":
                    self.progress_var.set(data)

                    # Calculate elapsed time and ETA
                    status_parts = [f"Merging... {data:.0f}%"]

                    if self.merge_start_time:
                        elapsed = (datetime.now() - self.merge_start_time).total_seconds()
                        elapsed_str = self._format_elapsed_time(elapsed)
                        status_parts.append(f"Elapsed: {elapsed_str}")

                        # Calculate ETA if progress > 0
                        if data > 0:
                            total_estimated = elapsed / (data / 100)
                            remaining = total_estimated - elapsed
                            if remaining > 0:
                                eta_str = self._format_eta(remaining)
                                status_parts.append(f"{eta_str} remaining")

                    # Update status label with all parts
                    status_text = " • ".join(status_parts)
                    self.status_label.config(text=f"Progress & Controls - {status_text}")

                elif msg_type == "complete":
                    if data == "success":
                        self._modify_finished(True)
                    else:
                        self._modify_finished(False)
                elif msg_type == "error":
                    self._log_message(f"ERROR: {data}")
                    self._modify_finished(False)

        except queue.Empty:
            pass

        # Always schedule next check (not just when modification is running)
        self.root.after(100, self._check_output_queue)

    def _modify_finished(self, success):
        """Handle modification completion"""
        self.modify_running = False
        self.merge_start_time = None  # Reset timing for next merge
        self.start_btn.config(state=tk.NORMAL)
        self.stop_btn.config(state=tk.DISABLED)

        if success:
            self.status_label.config(text="Progress & Controls - ✅ Modification completed successfully!", foreground="green")
            self.progress_var.set(100)
            self._log_message("\n" + "="*60)
            self._log_message("✅ MODIFICATION COMPLETED SUCCESSFULLY!")
            self._log_message("="*60)
            self._log_message(f"Output location: {self.output_path.get()}")
            self._log_message("")

            # Set modified backup path for device restore
            # The modified backup is created at output_path/UDID where UDID comes from the new/target device
            # In single-backup mode, use the only available backup
            single_backup_mode = bool(self.left_backup) != bool(self.right_backup)
            if single_backup_mode:
                new_device_backup = self.left_backup if self.left_backup else self.right_backup
            else:
                new_device_backup = self.right_backup if self.new_device.get() == "right" else self.left_backup

            if new_device_backup and new_device_backup.is_valid:
                self.modified_backup_path = os.path.join(self.output_path.get(), new_device_backup.udid)
                self._log_message(f"Modified backup available for restore: {self.modified_backup_path}")

                # Enable the "Modified Backup (latest)" radio button now that modification is complete
                self.modified_backup_radio.config(state=tk.NORMAL)

                # Auto-select "Modified Backup" restore target
                self.restore_target.set("modified")
                self._on_restore_target_changed()

                # Add the modified backup to the Auto-Detected Backups list with red indicator
                self._add_backup_to_detected_list(self.modified_backup_path, modified=True)

            messagebox.showinfo("Success",
                              f"Modification completed successfully!\n\n"
                              f"Modified backup location:\n{self.output_path.get()}\n\n"
                              f"You can now restore this backup to your device.")
        else:
            self.status_label.config(text="Progress & Controls - ❌ Modification failed or was stopped", foreground="red")
            self._log_message("\n" + "="*60)
            self._log_message("❌ MODIFICATION FAILED OR WAS STOPPED")
            self._log_message("="*60)
            messagebox.showwarning("Modification Failed",
                                  "The modification process failed or was stopped.\n\n"
                                  "Check the log output above for details.")

    def _view_log(self):
        """View detailed log in popup window with real-time updates"""
        # If log window is already open, just focus it
        if self.log_window and self.log_window.winfo_exists():
            self.log_window.lift()
            self.log_window.focus()
            return

        # Create new log window
        self.log_window = tk.Toplevel(self.root)
        self.log_window.title("Modification Log (Real-time)")
        self.log_window.geometry("800x600")

        # Track last log position for incremental updates
        self.log_last_position = 0

        # Log text area
        self.log_text_widget = scrolledtext.ScrolledText(
            self.log_window, bg="#1e1e1e", fg="#00ff00",
            font=("Consolas", 9), wrap=tk.WORD
        )
        self.log_text_widget.pack(fill=tk.BOTH, expand=True, padx=10, pady=(10, 5))

        # Copy current log from buffer
        self.log_text_widget.insert("1.0", "".join(self.log_buffer))
        self.log_last_position = len(self.log_buffer)
        self.log_text_widget.see(tk.END)  # Scroll to bottom

        # Button frame
        button_frame = tk.Frame(self.log_window)
        button_frame.pack(fill=tk.X, padx=10, pady=(0, 10))

        # Save Log button
        def save_log():
            from tkinter import filedialog
            file_path = filedialog.asksaveasfilename(
                title="Save Log File",
                defaultextension=".txt",
                filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
            )
            if file_path:
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write("".join(self.log_buffer))
                messagebox.showinfo("Success", f"Log saved to:\n{file_path}")

        tk.Button(button_frame, text="Save Log", bg="#3498db", fg="white",
                 font=("Arial", 10), padx=20, pady=5,
                 command=save_log).pack(side=tk.LEFT, padx=(0, 5))

        # Close button
        def close_log():
            if self.log_window and self.log_window.winfo_exists():
                self.log_window.destroy()
            self._cleanup_log_window()

        tk.Button(button_frame, text="Close", bg="#95a5a6", fg="white",
                 font=("Arial", 10), padx=20, pady=5,
                 command=close_log).pack(side=tk.LEFT)

        # Handle window close event
        self.log_window.protocol("WM_DELETE_WINDOW", close_log)

        # Start real-time updates
        self._update_log_window()

    def _update_log_window(self):
        """Update log window with new log entries (called periodically)"""
        # Check if window still exists
        if not self.log_window or not self.log_window.winfo_exists():
            self._cleanup_log_window()
            return

        # Check if there are new log entries
        if len(self.log_buffer) > self.log_last_position:
            # Get new entries
            new_entries = self.log_buffer[self.log_last_position:]
            new_text = "".join(new_entries)

            # Append to text widget
            self.log_text_widget.config(state=tk.NORMAL)
            self.log_text_widget.insert(tk.END, new_text)
            self.log_text_widget.config(state=tk.DISABLED)

            # Auto-scroll to bottom
            self.log_text_widget.see(tk.END)

            # Update position
            self.log_last_position = len(self.log_buffer)

        # Schedule next update (every 100ms)
        if self.log_window and self.log_window.winfo_exists():
            self.log_update_job = self.root.after(100, self._update_log_window)

    def _cleanup_log_window(self):
        """Clean up log window references and scheduled updates"""
        # Cancel any scheduled updates
        if self.log_update_job:
            self.root.after_cancel(self.log_update_job)
            self.log_update_job = None

        # Clear references
        self.log_window = None
        self.log_text_widget = None
        self.log_last_position = 0

    def _validate_backup(self):
        """Validate merged backup (placeholder)"""
        messagebox.showinfo("Coming Soon",
                          "Backup validation feature coming soon!\n\n"
                          "For now, you can restore the backup to a device using:\n"
                          "idevicebackup2 restore <backup_path>")

    def _auto_detect_backups(self):
        """Auto-detect backups in default iTunes locations"""
        # Run detection in background thread
        thread = threading.Thread(target=self._scan_backups_async, daemon=True)
        thread.start()

    def _scan_backups_async(self, include_app_created=True):
        self._include_app_created_in_scan = bool(include_app_created)
        try:
            all_backups = []
            found_paths = set()  # Track which paths we've already found

            # Get default iTunes backup paths
            backup_paths = get_default_itunes_backup_paths()

            # Scan each path
            for path in backup_paths:
                backups = scan_for_backups(path)
                backups = [b for b in backups if not self._is_hidden_backup(b.path)]
                all_backups.extend(backups)
                # Track found paths
                for backup in backups:
                    found_paths.add(backup.path)

            # Load app-created backups that weren't found in default locations
            if self._include_app_created_in_scan:
                for app_backup_path in self.app_created_backup_paths:
                    if app_backup_path not in found_paths and not self._is_hidden_backup(app_backup_path):
                        # This backup is in a custom location, load it directly
                        try:
                            # Check if this is also a modified backup
                            is_modified = app_backup_path in self.modified_backup_paths
                            backup_info = BackupInfo(app_backup_path, created_with_app=True, modified_with_app=is_modified)
                            if backup_info.is_valid:
                                all_backups.append(backup_info)
                                found_paths.add(backup_info.path)
                                print(f"[DEBUG] Loaded app-created backup from custom location: {app_backup_path}")
                        except Exception as e:
                            print(f"[DEBUG] Failed to load app-created backup {app_backup_path}: {e}")
                        except Exception:
                            pass

            # Mark backups that were created/modified with the app (for those found in default locations)
            for backup in all_backups:
                if backup.path in self.app_created_backup_paths:
                    backup.created_with_app = True
                    print(f"[DEBUG] Marked backup as app-created: {backup.path}")
                if backup.path in self.modified_backup_paths:
                    backup.modified_with_app = True
                    print(f"[DEBUG] Marked backup as modified: {backup.path}")

            # Sort by last backup date (most recent first)
            all_backups.sort(key=lambda b: b.last_backup, reverse=True)

            # Update UI on main thread
            self.detected_backups = all_backups
            self.root.after(0, self._update_auto_detect_ui)

        except Exception as e:
            print(f"[DEBUG] Auto-detect failed: {e}")
            import traceback
            traceback.print_exc()

    def _menu_reset_auto_detected_backups(self):
        """Clear all add/remove rules and rebuild list from default auto-detected directories only."""
        from tkinter import messagebox
        import threading, os

        try:
            # 1) Clear tracked (manually added) + persist
            self._tracked_paths.clear()
            self._save_tracked_backups()

            # 2) Clear hidden (manually removed) + persist
            self._hidden_paths.clear()
            self._save_hidden_backups()

            # 3) Clear app-created and modified custom locations (so non-default paths won't re-inject)
            #    This uses your existing persistence for app-created/modified backups.
            try:
                self.app_created_backup_paths.clear()
            except Exception:
                pass
            try:
                self._save_app_created_backups()
            except Exception:
                pass
            try:
                self.modified_backup_paths.clear()
            except Exception:
                pass
            try:
                self._save_modified_backups()
            except Exception:
                pass

            # (Optional) also remove JSON files on disk for absolute cleanliness
            for path_provider in (self._tracked_db_path, self._hidden_db_path):
                try:
                    p = path_provider()
                    if os.path.exists(p):
                        os.remove(p)
                except Exception:
                    pass

            # 4) Clear current UI model & refresh
            self.detected_backups.clear()
            self._update_auto_detect_ui()

            # 5) Re-scan **only default roots** (no app-created injections for this pass)
            threading.Thread(
                target=self._scan_backups_async,
                kwargs={"include_app_created": False},
                daemon=True
            ).start()

            self._log_message("[INFO] Auto-Detected backups reset to defaults.")
        except Exception as e:
            messagebox.showerror("Reset failed", str(e))

    def _add_backup_to_detected_list(self, backup_folder, modified=False, defer_save=False):
        """Add a newly created or modified backup to the detected backups list

        Args:
            backup_folder: Path to the backup folder to add
            modified: True if this is a modified backup, False if created from device
            defer_save: If True, skip saving to disk (for bulk loading operations)
        """
        try:
            # Create BackupInfo object with appropriate flags
            if modified:
                new_backup = BackupInfo(backup_folder, created_with_app=True, modified_with_app=True)
            else:
                new_backup = BackupInfo(backup_folder, created_with_app=True, modified_with_app=False)

            # Add to persistent set of app-created backups
            normalized_path = new_backup.path
            self.app_created_backup_paths.add(normalized_path)
            if not defer_save:
                self._save_app_created_backups()

            # Add to persistent set of modified backups if applicable
            if modified:
                self.modified_backup_paths.add(normalized_path)
                if not defer_save:
                    self._save_modified_backups()

            # Check for duplicates by comparing normalized paths
            for existing_backup in self.detected_backups:
                if existing_backup.path == normalized_path:
                    print(f"[DEBUG] Backup already in list: {normalized_path}")
                    # Update the existing backup to mark it as app-created/modified
                    existing_backup.created_with_app = True
                    if modified:
                        existing_backup.modified_with_app = True
                    # Refresh UI to show updated styling
                    self._update_auto_detect_ui()
                    return
            
            norm = self._normalize_udid_path(backup_folder)
            if self._is_hidden_backup(norm):
                self._log_message(f"[INFO] Skipping add; backup is hidden: {norm}")
                return

            # Add to the beginning of the list (most recent first)
            self.detected_backups.insert(0, new_backup)
            print(f"[DEBUG] Added backup to detected list: {normalized_path}")

            # Refresh UI to show the new backup
            self._update_auto_detect_ui()

        except Exception as e:
            print(f"[DEBUG] Failed to add backup to detected list: {e}")
            import traceback
            traceback.print_exc()

    def _add_backup_info_to_detected_list(self, new_backup, modified=False, defer_save=False):
        """Add a pre-built BackupInfo object to the detected backups list."""
        try:
            normalized_path = new_backup.path
            self.app_created_backup_paths.add(normalized_path)
            if not defer_save:
                self._save_app_created_backups()

            if modified:
                self.modified_backup_paths.add(normalized_path)
                if not defer_save:
                    self._save_modified_backups()

            for existing_backup in self.detected_backups:
                if existing_backup.path == normalized_path:
                    print(f"[DEBUG] Backup already in list: {normalized_path}")
                    existing_backup.created_with_app = True
                    if modified:
                        existing_backup.modified_with_app = True
                    self._update_auto_detect_ui()
                    return

            norm = self._normalize_udid_path(normalized_path)
            if self._is_hidden_backup(norm):
                self._log_message(f"[INFO] Skipping add; backup is hidden: {norm}")
                return

            self.detected_backups.insert(0, new_backup)
            print(f"[DEBUG] Added backup to detected list: {normalized_path}")
            self._update_auto_detect_ui()

        except Exception as e:
            print(f"[DEBUG] Failed to add backup to detected list: {e}")
            import traceback
            traceback.print_exc()

    def _update_auto_detect_ui(self):
        """Update auto-detect UI with found backups"""
        # Guard: UI might not be created yet during initialization
        if not hasattr(self, 'auto_detect_container'):
            return

        # Clear loading message
        if hasattr(self, 'auto_detect_label') and self.auto_detect_label:
            self.auto_detect_label.destroy()

        # Clear container
        for widget in self.auto_detect_container.winfo_children():
            widget.destroy()

        if not self.detected_backups:
            # No backups found
            label = tk.Label(self.auto_detect_container,
                           text="No backups found in default iTunes locations. Use Browse buttons below.",
                           fg="gray", font=("Arial", 8, "italic"))
            label.pack()
            return

        # Display found backups in a scrollable frame
        # Create a frame for backup buttons
        button_frame = tk.Frame(self.auto_detect_container)
        button_frame.pack(fill=tk.X)

        for i, backup in enumerate(self.detected_backups[:5]):  # Show max 5 backups
            # Create button for each backup
            btn_text = f"{backup.device_model} | {backup.name} |"

            # Add identifier for app-created/modified backups
            if backup.modified_with_app:
                btn_text += " (Modified with iOS Backup Manager)"
            elif backup.created_with_app:
                btn_text += " (Created with iOS Backup Manager)"

            # Append relative age instead of absolute time
            try:
                dt = backup.get_created_timestamp()
                age_str = self._format_backup_age(dt)
            except Exception:
                age_str = "Unknown age"

            btn_text += f" - {age_str}"

            # Use different colors: red for modified, green for created, gray for others
            if backup.modified_with_app:
                bg_color = "#f8d7da"  # Light red
                hover_color = "#f1aeb5"  # Darker red on hover
            elif backup.created_with_app:
                bg_color = "#d4edda"  # Light green
                hover_color = "#c3e6cb"  # Darker green on hover
            else:
                bg_color = "#ecf0f1"  # Light gray
                hover_color = "#bdc3c7"  # Darker gray on hover

            backup_btn = tk.Button(button_frame, text=btn_text,
                                  bg=bg_color, fg="#2c3e50",
                                  font=("Arial", 8), relief=tk.FLAT,
                                  borderwidth=1, padx=5, pady=3,
                                  anchor=tk.W,
                                  command=lambda b=backup: self._show_backup_menu(b))
            backup_btn.pack(fill=tk.X, pady=1)

            # Hover effects with appropriate colors
            backup_btn.bind("<Enter>", lambda e, btn=backup_btn, hc=hover_color: btn.config(bg=hc))
            backup_btn.bind("<Leave>", lambda e, btn=backup_btn, bc=bg_color: btn.config(bg=bc))

        if len(self.detected_backups) > 10:
            label = tk.Label(self.auto_detect_container,
                           text=f"+ {len(self.detected_backups) - 10} more...",
                           fg="gray", font=("Arial", 7, "italic"))
            label.pack(pady=2)
        # Ensure the scrollregion and the fade/hint reflect the new content
        try:
            # Trigger geometry recalculation & fade update
            self.auto_detect_container.update_idletasks()
            self.auto_detect_canvas.configure(scrollregion=self.auto_detect_canvas.bbox("all"))
            self._auto_detect_update_fade()
        except Exception as exc:
            pass


    def _show_backup_menu(self, backup):
        """Show menu to load backup into left or right panel"""
        menu = tk.Menu(self.root, tearoff=0)
        menu.add_command(label=f"Load in Slot A (Left Backup)",
                        command=lambda: self._load_detected_backup(backup, "left"))
        menu.add_command(label=f"Load in Slot B (Right Backup)",
                        command=lambda: self._load_detected_backup(backup, "right"))
        menu.add_command(
            label="Remove from list",
            command=lambda b=backup: self._remove_single_backup_from_list(b)
        )
        menu.add_separator()
        menu.add_command(label=f"Explore to this folder",
                        command=lambda b=backup: self._open_backup_folder(getattr(b, "path", b)))

        # Show menu at mouse position
        menu.post(self.root.winfo_pointerx(), self.root.winfo_pointery())

    def _load_detected_backup(self, backup, side):
        """Load a detected backup into left or right panel and update the path field."""
        import threading, os, tkinter as tk

        # Derive a filesystem path no matter what we were given
        path = getattr(backup, "path", backup)
        allow_unsupported = False

        # Reflect the path into the entry field so the user sees it
        entry_widget = self.left_path_entry if side == "left" else self.right_path_entry
        try:
            entry_widget.delete(0, tk.END)
            entry_widget.insert(0, path)
        except Exception:
            pass  # don't hard-fail UI if the entry isn't available for some reason

        # If we already have a fully-built BackupInfo object, just update the display.
        # Otherwise (if it's a plain path), show a loading indicator and build it async.
        if isinstance(backup, BackupInfo):
            if not backup.is_supported:
                proceed, normalized_path, allow_unsupported = self._validate_backup_path_for_load(path)
                if not proceed:
                    return
                path = normalized_path
                backup.path = normalized_path
                backup.allow_unsupported = allow_unsupported
                try:
                    entry_widget.delete(0, tk.END)
                    entry_widget.insert(0, path)
                except Exception:
                    pass
            self._update_backup_display(backup, side)
        else:
            if not os.path.exists(path):
                messagebox.showerror("Invalid Path", f"Path does not exist:\n{path}")
                return

            proceed, normalized_path, allow_unsupported = self._validate_backup_path_for_load(path)
            if not proceed:
                return
            path = normalized_path
            try:
                entry_widget.delete(0, tk.END)
                entry_widget.insert(0, path)
            except Exception:
                pass

            info_text = self.left_info_text if side == "left" else self.right_info_text
            info_text.config(state=tk.NORMAL)
            info_text.delete("1.0", tk.END)
            info_text.insert("1.0", "Loading backup information...\n\nPlease wait...")
            info_text.config(state=tk.DISABLED)

            threading.Thread(target=self._load_backup_async, args=(path, side, allow_unsupported), daemon=True).start()



    def _remove_single_backup_from_list(self, backup):
        """Remove one backup from the list and persist (tracked→untrack, autodetected/app-created→hide/remove)."""
        from tkinter import messagebox
        import os

        try:
            # 1) Normalize the selected backup's path to a canonical UDID folder (absolute + case-insensitive)
            raw_path = getattr(backup, "path", backup)
            norm_udid = self._normalize_udid_path(raw_path)
            canon_target = os.path.normcase(os.path.abspath(norm_udid))

            # 2) If this backup was created with the app, also remove it from app_created_backup_paths
            try:
                new_app_created = set()
                for p in getattr(self, "app_created_backup_paths", set()):
                    canon_p = os.path.normcase(os.path.abspath(p))
                    if canon_p != canon_target:
                        new_app_created.add(p)
                if hasattr(self, "app_created_backup_paths"):
                    self.app_created_backup_paths = new_app_created
                    try:
                        self._save_app_created_backups()
                    except Exception as e:
                        print(f"[DEBUG] Failed to save app-created backups after remove: {e}")
            except Exception as e:
                print(f"[DEBUG] _remove_single_backup_from_list app-created handling error: {e}")

            # 3) Update tracked / hidden rules
            if norm_udid in self._tracked_paths:
                # Explicitly tracked by user → untrack it
                self._tracked_paths.discard(norm_udid)
                self._save_tracked_backups()
            else:
                # Not tracked: treat as auto-detected and hide it so scans skip it
                self._hidden_paths.add(norm_udid)
                self._save_hidden_backups()

            # 4) Remove from in-memory detected_backups (compare with canonical paths)
            removed_any = False
            for i in range(len(self.detected_backups) - 1, -1, -1):
                bi = self.detected_backups[i]
                bi_path = getattr(bi, "path", None)
                if not bi_path:
                    continue
                canon_bi = os.path.normcase(os.path.abspath(bi_path))
                if canon_bi == canon_target:
                    del self.detected_backups[i]
                    removed_any = True

            # 5) Refresh UI / logging
            if removed_any:
                self._update_auto_detect_ui()
                self._log_message(f"[INFO] Removed backup from list (persisted): {norm_udid}")
            else:
                print(f"[DEBUG] _remove_single_backup_from_list: no matching entry found for {norm_udid}")

        except Exception as e:
            messagebox.showerror("Remove failed", str(e))




    def _check_backup_encryption_enabled(self):
        """
        Check if backup encryption is enabled on the device.
        Returns True if encryption is enabled, False otherwise.
        """
        try:
            from pymobiledevice3.services.mobilebackup2 import Mobilebackup2Service

            debug_log("=== CHECKING BACKUP ENCRYPTION ===")

            # Method 1: Try to get WillEncrypt from lockdown (no domain)
            try:
                will_encrypt = self.current_device_lockdown.get_value(key='WillEncrypt')
                debug_log(f"Method 1 - WillEncrypt (no domain): {will_encrypt}")
                if will_encrypt is not None and will_encrypt:
                    return True
            except Exception as e:
                debug_log(f"Method 1 failed: {e}")

            # Method 2: Try com.apple.mobile.backup domain
            try:
                will_encrypt = self.current_device_lockdown.get_value(domain='com.apple.mobile.backup', key='WillEncrypt')
                debug_log(f"Method 2 - WillEncrypt (com.apple.mobile.backup): {will_encrypt}")
                if will_encrypt is not None and will_encrypt:
                    return True
            except Exception as e:
                debug_log(f"Method 2 failed: {e}")

            # Method 3: Check all available backup-related domains
            backup_domains = [
                'com.apple.mobile.backup',
                'com.apple.mobilebackup',
                'com.apple.MobileBackup',
                None  # No domain
            ]

            for domain in backup_domains:
                try:
                    if domain:
                        all_values = self.current_device_lockdown.get_value(domain=domain)
                        debug_log(f"Domain '{domain}' type: {type(all_values)}")
                        if isinstance(all_values, dict):
                            debug_log(f"Domain '{domain}' keys: {list(all_values.keys())}")
                            if 'WillEncrypt' in all_values:
                                will_encrypt = all_values['WillEncrypt']
                                debug_log(f"Found WillEncrypt in {domain}: {will_encrypt}")
                                if will_encrypt:
                                    return True
                except Exception as e:
                    debug_log(f"Failed to get values from domain '{domain}': {e}")

            # Method 4: Search all root-level keys for encryption-related values
            try:
                debug_log("Checking root level keys for encryption info...")
                # Get all keys at root level
                all_root_keys = self.current_device_lockdown.all_values
                debug_log(f"Root keys type: {type(all_root_keys)}")
                if isinstance(all_root_keys, dict):
                    encrypt_keys = {k: v for k, v in all_root_keys.items()
                                  if 'encrypt' in k.lower() or 'backup' in k.lower()}
                    debug_log(f"Encryption/Backup related keys at root: {encrypt_keys}")
            except Exception as e:
                debug_log(f"Failed to check root keys: {e}")

            debug_log("=== ENCRYPTION CHECK COMPLETE - NO ENCRYPTION DETECTED ===")
            debug_log("Please check the debug_toggle.txt file for detailed logs")
            return False

        except Exception as e:
            debug_log(f"[ERROR] Critical error checking backup encryption: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _disable_backup_encryption(self, password):
        """
        Disable backup encryption on the device using the provided password.
        Returns True if successful, False if password incorrect or failed.
        """
        try:
            from pymobiledevice3.services.mobilebackup2 import Mobilebackup2Service

            debug_log("[DEBUG] Attempting to disable backup encryption...")

            # Create backup service
            backup_service = Mobilebackup2Service(lockdown=self.current_device_lockdown)

            # Disable backup encryption using the correct method
            # Signature: change_password(backup_directory='.', old: str = '', new: str = '') -> None
            # To disable: change_password('', password) where password is the current backup password
            # This sets: backup_directory='', old=password, new='' (empty new password disables encryption)
            debug_log(f"[DEBUG] Disabling backup encryption with password...")

            # Use the correct method signature discovered through testing
            backup_service.change_password('', password)

            debug_log("[DEBUG] Backup encryption disabled successfully!")
            return True

        except Exception as e:
            error_msg = str(e).lower()
            debug_log(f"[DEBUG] Failed to disable encryption: {e}")
            import traceback
            traceback.print_exc()

            # Check if it's a password error
            if "password" in error_msg or "incorrect" in error_msg or "wrong" in error_msg:
                debug_log("[DEBUG] Incorrect password detected")
                return False
            else:
                # Some other error - show to user
                messagebox.showerror(
                    "Encryption Error",
                    f"Failed to disable backup encryption:\n\n{str(e)}\n\n"
                    "You can continue with an encrypted backup."
                )
                return False

    def _prompt_encryption_password(self, retry_count=0):
        """
        Prompt user for backup encryption password.
        Returns password string or None if cancelled.
        """
        # Create a simple password dialog
        dialog = tk.Toplevel(self.root)
        dialog.title("Backup Encryption Password" if retry_count == 0 else "Incorrect Password - Try Again")
        dialog.geometry("500x210")
        dialog.resizable(False, False)
        dialog.transient(self.root)
        dialog.grab_set()

        # Center the dialog
        dialog.update_idletasks()
        x = (dialog.winfo_screenwidth() // 2) - (dialog.winfo_width() // 2)
        y = (dialog.winfo_screenheight() // 2) - (dialog.winfo_height() // 2)
        dialog.geometry(f"+{x}+{y}")

        # Message
        if retry_count == 0:
            msg_text = ("Backup encryption is enabled on this device.\n\n"
                       "You can continue with an encrypted backup (recommended).\n"
                       "You'll need the password later to access data.\n\n"
                       "If you want to disable encryption now, enter the current password:")
        else:
            msg_text = ("WARNING: Password incorrect.\n\n"
                       "You can try again, or continue with encryption:")

        msg_label = tk.Label(dialog, text=msg_text, font=("Arial", 9), justify=tk.LEFT)
        msg_label.pack(pady=(15, 10), padx=15)

        # Password entry
        password_frame = tk.Frame(dialog)
        password_frame.pack(fill=tk.X, padx=15, pady=5)

        tk.Label(password_frame, text="Password:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 10))
        password_entry = tk.Entry(password_frame, show="*", font=("Arial", 10), width=25)
        password_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        password_entry.focus()

        # Result variable
        result = {'password': None, 'action': None}

        def on_ok():
            result['password'] = password_entry.get()
            result['action'] = 'remove_encryption'
            dialog.destroy()

        def on_cancel():
            result['action'] = 'cancel'
            dialog.destroy()

        def on_continue_encrypted():
            result['action'] = 'continue_encrypted'
            dialog.destroy()

        # Buttons
        button_frame = tk.Frame(dialog)
        button_frame.pack(fill=tk.X, padx=15, pady=(10, 15))
        button_frame.columnconfigure(0, weight=1)
        button_frame.columnconfigure(1, weight=1)
        button_frame.columnconfigure(2, weight=1)

        continue_btn = tk.Button(button_frame, text="Continue Encrypted", command=on_continue_encrypted,
                                bg="#3498db", fg="white", font=("Arial", 9, "bold"),
                                relief=tk.FLAT, padx=10, pady=8)
        continue_btn.grid(row=0, column=0, sticky="ew", padx=(0, 6))

        ok_btn = tk.Button(button_frame, text="Disable Encryption", command=on_ok,
                          bg="#27ae60", fg="white", font=("Arial", 9),
                          relief=tk.FLAT, padx=10, pady=8)
        ok_btn.grid(row=0, column=1, sticky="ew", padx=6)

        cancel_btn = tk.Button(button_frame, text="Cancel Backup", command=on_cancel,
                              bg="#95a5a6", fg="white", font=("Arial", 9),
                              relief=tk.FLAT, padx=10, pady=8)
        cancel_btn.grid(row=0, column=2, sticky="ew", padx=(6, 0))

        # Bind Enter key
        password_entry.bind('<Return>', lambda e: on_ok())

        # Wait for dialog to close
        dialog.wait_window()

        return result

    def _start_device_backup(self):
        """Start backing up the connected device"""
        global LAST_PYMOBILEDEVICE3_ERROR
        if not PYMOBILEDEVICE3_AVAILABLE:
            log_path = _device_log_path()
            if LAST_PYMOBILEDEVICE3_ERROR is None:
                ensure_pymobiledevice3_loaded()
            if PYMOBILEDEVICE3_AVAILABLE:
                return
            if LAST_PYMOBILEDEVICE3_ERROR is None:
                LAST_PYMOBILEDEVICE3_ERROR = diagnose_pymobiledevice3()
            detail = f"{LAST_PYMOBILEDEVICE3_ERROR!r}" if LAST_PYMOBILEDEVICE3_ERROR else "Unknown"
            log_device_detection(f"Device support unavailable. Detail={detail}")
            messagebox.showerror(
                "Error",
                "Device support is unavailable (pymobiledevice3 failed to load).\n"
                f"Details: {detail}\n"
                f"Log: {log_path}",
            )
            return

        if not hasattr(self, 'current_device_lockdown') or not self.current_device_lockdown:
            messagebox.showerror("Error", "No device connected or device lockdown not available.")
            return

        # Check device activation status
        is_activated, activation_state = check_activation_status(self.current_device_lockdown)
        if not is_activated:
            messagebox.showerror(
                "Device Not Activated",
                f"Cannot create backup: Device is not activated.\n\n"
                f"Activation Status: {activation_state}\n\n"
                f"Please activate your device first:\n"
                f"1. Connect to Wi-Fi or cellular\n"
                f"2. Follow the on-screen setup instructions\n"
                f"3. Sign in with your Apple ID when prompted"
            )
            # Show activation dialog
            if hasattr(self, 'current_device_info'):
                self._prompt_for_activation(self.current_device_info)
            return

        # Get backup location
        backup_location = self.backup_panel.location_entry.get().strip()
        if not backup_location:
            messagebox.showerror("Error", "Please specify a backup location.")
            return

        # Build final target root: base location -> optional backup name -> optional "iTunes Backup"
        backup_name = ""
        if hasattr(self.backup_panel, "backup_name_entry"):
            backup_name = self.backup_panel.backup_name_entry.get().strip()
        create_itunes_subfolder = False
        if hasattr(self.backup_panel, "create_itunes_subfolder_var"):
            try:
                create_itunes_subfolder = bool(self.backup_panel.create_itunes_subfolder_var.get())
            except Exception:
                create_itunes_subfolder = False

        target_root = backup_location
        if backup_name:
            target_root = os.path.join(target_root, backup_name)
        if create_itunes_subfolder:
            target_root = os.path.join(target_root, "iTunes Backup")

        # Create target root folder if it doesn't exist
        try:
            os.makedirs(target_root, exist_ok=True)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to create backup location:\n{e}")
            return

        # Check if there's enough free space at destination
        if hasattr(self.current_device_lockdown, 'udid'):
            # Get device storage info
            try:
                total_capacity = self.current_device_lockdown.get_value('com.apple.disk_usage', 'TotalDataCapacity')
                available_space = self.current_device_lockdown.get_value('com.apple.disk_usage', 'TotalDataAvailable')
                used_space = total_capacity - available_space if (total_capacity and available_space) else None

                if used_space:
                    # Check free space at destination
                    free_space_bytes = get_free_space_at_path(target_root)
                    if free_space_bytes is not None:
                        required_space = used_space * 1.2  # 20% buffer

                        if free_space_bytes < required_space:
                            # Not enough space
                            free_space_str = format_bytes(free_space_bytes)
                            required_str = format_bytes(required_space)
                            messagebox.showerror(
                                "Insufficient Space",
                                f"Not enough free space at destination!\n\n"
                                f"Required: {required_str}\n"
                                f"Available: {free_space_str}\n\n"
                                f"Please free up space or choose a different backup location."
                            )
                            return
            except Exception as e:
                print(f"[DEBUG] Error checking free space: {e}")
                # Continue anyway if we can't check

        # Check if backup encryption is enabled BEFORE starting backup
        encryption_enabled = self._check_backup_encryption_enabled()

        if encryption_enabled:
            print("[DEBUG] Backup encryption is enabled - prompting user")
            # Prompt user for action
            result = self._prompt_encryption_password(retry_count=0)

            if result['action'] == 'remove_encryption':
                # User wants to remove encryption
                password = result['password']
                if not password:
                    messagebox.showwarning("No Password", "No password provided. Backup cancelled.")
                    return

                # Try to disable encryption
                encryption_disabled = self._disable_backup_encryption(password)

                if not encryption_disabled:
                    proceed = messagebox.askyesno(
                        "Encryption Still Enabled",
                        "Unable to disable backup encryption.\n\n"
                        "Would you like to continue with an encrypted backup?\n"
                        "You will need the password later to access data."
                    )
                    if not proceed:
                        return
                    self._creating_encrypted_backup = True

                # Encryption was successfully disabled - reconnect to device
                if encryption_disabled:
                    debug_log("[DEBUG] Reconnecting to device after encryption change...")
                    try:
                        from pymobiledevice3.lockdown import create_using_usbmux

                        # Close the old connection
                        try:
                            self.current_device_lockdown.close()
                            debug_log("[DEBUG] Closed old lockdown connection")
                        except:
                            pass

                        # Reconnect (will connect to first available device)
                        self.current_device_lockdown = create_using_usbmux()
                        debug_log(f"[DEBUG] Successfully reconnected to device: {self.current_device_lockdown.get_value(key='DeviceName')}")

                    except Exception as e:
                        debug_log(f"[DEBUG] Failed to reconnect: {e}")
                        import traceback
                        traceback.print_exc()
                        messagebox.showerror(
                            "Connection Error",
                            f"Encryption was disabled but failed to reconnect to device:\n\n{e}\n\n"
                            "Please try the backup again."
                        )
                        return

                    messagebox.showinfo(
                        "Encryption Disabled",
                        "Backup encryption has been successfully disabled.\n\nProceeding with backup..."
                    )

            elif result['action'] == 'continue_encrypted':
                # User wants encrypted backup - mark it and continue
                self._creating_encrypted_backup = True

            else:  # cancel
                # User cancelled
                return

        # Get device UDID for backup folder naming
        udid = self.current_device_lockdown.udid

        backup_folder = os.path.join(target_root, udid)
        full_backup = True

        existing_backup = os.path.exists(os.path.join(backup_folder, "Info.plist"))
        if existing_backup:
            choice = messagebox.askyesnocancel(
                "Existing backup found",
                "A backup for this device already exists at this location.\n\n"
                "Yes: Update existing backup (incremental)\n"
                "No: Create a new full backup\n"
                "Cancel: Abort backup"
            )
            if choice is None:
                return
            if choice:
                full_backup = False
            else:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                timestamp_parent = os.path.join(target_root, f"{udid}_{timestamp}")
                os.makedirs(timestamp_parent, exist_ok=True)
                backup_folder = os.path.join(timestamp_parent, udid)
                full_backup = True

        if full_backup:
            os.makedirs(backup_folder, exist_ok=True)

        if hasattr(self.backup_panel, "backup_type_label"):
            label = "Full" if full_backup else "Incremental"
            self.backup_panel.backup_type_label.config(text=f"Backup type: {label}")

        # Start backup in separate thread
        self.backup_in_progress = True
        self.backup_cancelled = False

        # Update UI
        self.backup_panel.start_backup_btn.config(state=tk.DISABLED)
        self.backup_panel.cancel_btn.config(state=tk.NORMAL)
        self.backup_panel.progress_bar['value'] = 0
        self.backup_panel.progress_status_label.config(text="Status: Starting backup...")

        # Run backup in thread
        backup_thread = threading.Thread(
            target=self._perform_device_backup,
            args=(backup_folder, full_backup),
            daemon=True
        )
        backup_thread.start()

    def _perform_device_backup(self, backup_folder, full_backup: bool):
        """Perform the actual backup operation in a background thread"""
        try:
            print(f"[DEBUG] Starting backup to: {backup_folder}")

            # Update status
            self.root.after(0, lambda: self.backup_panel.progress_status_label.config(
                text=f"Status: Preparing backup..."))
            self.root.after(0, lambda: self.backup_panel.progress_bar.config(value=0))

            # Create backup service
            backup_service = Mobilebackup2Service(lockdown=self.current_device_lockdown)

            # Define progress callback
            def progress_callback(percentage, status_message=''):
                """Callback to update progress bar and status"""
                if self.backup_cancelled:
                    return False  # Signal cancellation

                # Update progress bar
                self.root.after(0, lambda p=percentage: self.backup_panel.progress_bar.config(value=p))

                # Update status message
                if status_message:
                    self.root.after(0, lambda msg=status_message: self.backup_panel.progress_status_label.config(
                        text=f"Status: {msg} ({percentage:.1f}%)"))
                else:
                    # Show if encrypted or not
                    is_encrypted = hasattr(self, '_creating_encrypted_backup') and self._creating_encrypted_backup
                    if full_backup:
                        status_text = "Backing up (encrypted)..." if is_encrypted else "Backing up device..."
                    else:
                        status_text = "Backing up (encrypted, incremental)..." if is_encrypted else "Backing up device (incremental)..."
                    self.root.after(0, lambda p=percentage, txt=status_text: self.backup_panel.progress_status_label.config(
                        text=f"Status: {txt} ({p:.1f}%)"))

                return True  # Continue backup

            # Start backup with progress callback
            backup_service.backup(
                full=full_backup,
                backup_directory=os.path.dirname(backup_folder),
                progress_callback=progress_callback
            )

            # Check if cancelled
            if self.backup_cancelled:
                self.root.after(0, lambda: self.backup_panel.progress_status_label.config(
                    text="Status: Backup cancelled"))
                self.root.after(0, lambda: self.backup_panel.progress_bar.config(value=0))
            else:
                # Backup complete
                self.root.after(0, lambda: self.backup_panel.progress_bar.config(value=100))
                self.root.after(0, lambda: self.backup_panel.progress_status_label.config(
                    text="Status: Backup completed successfully!"))

                # Update last backup time
                self.root.after(0, lambda: self.backup_panel.last_backup_label.config(
                    text=f"Last backup: {datetime.now().strftime('%Y-%m-%d %I:%M %p')}"))

                # Store the backup path
                self.backup_panel.last_completed_backup = backup_folder

                # Check if this was an encrypted backup
                is_encrypted = hasattr(self, '_creating_encrypted_backup') and self._creating_encrypted_backup

                if is_encrypted:
                    if not hasattr(self, 'encrypted_backups'):
                        self.encrypted_backups = set()
                    self.encrypted_backups.add(backup_folder)
                    self._creating_encrypted_backup = False

                    def show_encrypted_complete():
                        messagebox.showinfo(
                            "Encrypted Backup Complete",
                            "Encrypted backup completed successfully.\n\n"
                            "You'll be prompted for the password when accessing data."
                        )
                    self.root.after(0, show_encrypted_complete)

                # Enable modify button for all backups
                self.root.after(0, lambda: self.backup_panel.modify_backup_btn.config(state=tk.NORMAL))
                if hasattr(self.backup_panel, 'extract_report_btn'):
                    self.root.after(0, lambda: self.backup_panel.extract_report_btn.config(state=tk.NORMAL))

                # Ask if user wants to extract data and create a report
                def ask_load_backup():
                    result = messagebox.askyesno(
                        "Backup Complete",
                        "Device backup completed successfully!\n\n"
                        "Would you like to extract the data from this backup and create a report?"
                    )
                    # Create a BackupInfo object so extraction/load paths are consistent.
                    backup_info = BackupInfo(backup_folder, created_with_app=True, modified_with_app=False)
                    if result:
                        self._start_full_extraction(backup_info, "left")
                    else:
                        self._load_backup_to_inactive_slot(backup_info)

                self.root.after(0, ask_load_backup)

                # Add the new backup to the detected backups list
                self.root.after(0, lambda: self._add_backup_to_detected_list(backup_folder))

        except Exception as e:
            error_msg = str(e)
            print(f"[DEBUG] Backup error: {error_msg}")
            import traceback
            traceback.print_exc()

            # Show error to user
            self.root.after(0, lambda: self.backup_panel.progress_status_label.config(
                text=f"Status: Backup failed"))
            self.root.after(0, lambda msg=f"Backup failed:\n\n{error_msg}": messagebox.showerror("Backup Error", msg))

        finally:
            # Re-enable buttons
            self.backup_in_progress = False
            self.root.after(0, lambda: self.backup_panel.start_backup_btn.config(state=tk.NORMAL))
            self.root.after(0, lambda: self.backup_panel.cancel_btn.config(state=tk.DISABLED))

    def _cancel_device_backup(self):
        """Cancel the in-progress backup"""
        if self.backup_in_progress:
            result = messagebox.askyesno(
                "Cancel Backup",
                "Are you sure you want to cancel the backup in progress?"
            )
            if result:
                self.backup_cancelled = True
                self.backup_panel.progress_status_label.config(text="Status: Cancelling...")

    def _start_restore(self, restore_path):
        """Start restore process with progress dialog"""
        global LAST_PYMOBILEDEVICE3_ERROR
        if not PYMOBILEDEVICE3_AVAILABLE:
            log_path = _device_log_path()
            if LAST_PYMOBILEDEVICE3_ERROR is None:
                ensure_pymobiledevice3_loaded()
            if PYMOBILEDEVICE3_AVAILABLE:
                return
            if LAST_PYMOBILEDEVICE3_ERROR is None:
                LAST_PYMOBILEDEVICE3_ERROR = diagnose_pymobiledevice3()
            detail = f"{LAST_PYMOBILEDEVICE3_ERROR!r}" if LAST_PYMOBILEDEVICE3_ERROR else "Unknown"
            log_device_detection(f"Device support unavailable. Detail={detail}")
            messagebox.showerror(
                "Error",
                "Device support is unavailable (pymobiledevice3 failed to load).\n"
                f"Details: {detail}\n"
                f"Log: {log_path}",
            )
            return

        if self.restore_in_progress:
            messagebox.showwarning("Restore in Progress", "A restore operation is already in progress.")
            return

        # Check if backup is encrypted
        manifest_path = os.path.join(restore_path, "Manifest.plist")
        backup_password = None

        try:
            with open(manifest_path, 'rb') as f:
                manifest = plistlib.load(f)
                is_encrypted = manifest.get('IsEncrypted', False)

                if is_encrypted:
                    # Prompt for password
                    backup_password = self._prompt_for_password()
                    if backup_password is None:
                        self._log_message("Restore cancelled: Password required for encrypted backup")
                        return
        except Exception as e:
            messagebox.showerror("Error", f"Could not read backup manifest: {str(e)}")
            return

        # Check compatibility (warn but allow to proceed)
        #try:
        #    info_path = os.path.join(restore_path, "Info.plist")
        #    with open(info_path, 'rb') as f:
        #        info = plistlib.load(f)
        #        backup_device_name = info.get('Device Name', 'Unknown')
        #        backup_product_type = info.get('Product Type', 'Unknown')
        #        backup_ios_version = info.get('Product Version', 'Unknown')
        #
        #        # --- Determine current device info (prefer self.current_device, fall back to lockdown) ---
        #        current_device_name = "Unknown"
        #        current_product_type = "Unknown"
        #        current_ios_version = "Unknown"
        #
        #        # 1) Use the cached device_info dict if available
        #        if getattr(self, "current_device", None):
        #            current_device_name = self.current_device.get('name') or current_device_name
        #            current_product_type = self.current_device.get('product_type') or current_product_type
        #            current_ios_version = self.current_device.get('ios_version') or current_ios_version
        #
        #        # 2) Fallback to the active lockdown connection if needed
        #        lockdown = getattr(self, "current_device_lockdown", None)
        #        if lockdown is not None:
        #            try:
        #                if current_device_name == "Unknown":
        #                    current_device_name = getattr(lockdown, "display_name", current_device_name)
        #                if current_product_type == "Unknown":
        #                    current_product_type = getattr(lockdown, "product_type", current_product_type)
        #                if current_ios_version == "Unknown":
        #                    current_ios_version = getattr(lockdown, "product_version", current_ios_version)
        #            except Exception as e:
        #                print(f"[DEBUG] Could not get device info from lockdown in compatibility check: {e}")
        #
        #        # --- Only warn if we have real values on both sides and they actually mismatch ---
        #        def _known(v):
        #            return v not in (None, "", "Unknown")
        #
        #        mismatch = (
        #            _known(backup_product_type) and _known(current_product_type) and
        #            _known(backup_ios_version) and _known(current_ios_version) and
        #            (backup_product_type != current_product_type or backup_ios_version != current_ios_version)
        #        )
        #
        #        if mismatch:
        #            result = messagebox.askyesno(
        #                "Compatibility Warning",
        #                f"Backup Compatibility Check:\n\n"
        #                f"Backup from:\n"
        #                f"  Device: {backup_device_name}\n"
        #                f"  Model: {backup_product_type}\n"
        #                f"  iOS: {backup_ios_version}\n\n"
        #                f"Restoring to:\n"
        #                f"  Device: {current_device_name}\n"
        #                f"  Model: {current_product_type}\n"
        #                f"  iOS: {current_ios_version}\n\n"
        #                f"Model or iOS version mismatch detected. Restore may fail or cause issues.\n\n"
        #                f"Do you want to proceed anyway?",
        #                icon='warning'
        #            )
        #            if not result:
        #                self._log_message("Restore cancelled: User declined compatibility warning")
        #                return
        except Exception as e:
            print(f"[DEBUG] Could not check compatibility: {e}")
            # Continue anyway


        # Initialize in-pane progress widgets
        self.restore_progress_bar['value'] = 0
        self.restore_progress_status_label.config(text="Status: Preparing restore...")
        self.restore_cancel_btn.config(state=tk.NORMAL)
        self.restore_btn.config(state=tk.DISABLED)

        # Start restore in background thread
        self.restore_in_progress = True
        self.restore_cancelled = False

        restore_thread = threading.Thread(
            target=self._perform_device_restore,
            args=(restore_path, backup_password),
            daemon=True
        )
        restore_thread.start()

    def _prompt_for_password(self):
        """Prompt user for backup encryption password"""
        password_dialog = tk.Toplevel(self.root)
        password_dialog.title("Backup Password Required")
        password_dialog.geometry("400x180")
        password_dialog.transient(self.root)
        password_dialog.grab_set()

        # Center the dialog
        password_dialog.update_idletasks()
        x = (password_dialog.winfo_screenwidth() // 2) - (400 // 2)
        y = (password_dialog.winfo_screenheight() // 2) - (180 // 2)
        password_dialog.geometry(f"+{x}+{y}")

        password_value = [None]  # Use list to capture value from nested function

        # Message
        msg_label = tk.Label(password_dialog,
                           text="This backup is encrypted and requires a password.\n\n"
                                "Please enter the backup password:",
                           justify=tk.LEFT, padx=20, pady=20)
        msg_label.pack()

        # Password entry
        password_frame = tk.Frame(password_dialog)
        password_frame.pack(padx=20, pady=10)

        tk.Label(password_frame, text="Password:").pack(side=tk.LEFT, padx=(0, 10))
        password_entry = tk.Entry(password_frame, show="*", width=30)
        password_entry.pack(side=tk.LEFT)
        password_entry.focus()

        # Buttons
        button_frame = tk.Frame(password_dialog)
        button_frame.pack(pady=10)

        def on_ok():
            password_value[0] = password_entry.get()
            password_dialog.destroy()

        def on_cancel():
            password_value[0] = None
            password_dialog.destroy()

        ok_btn = tk.Button(button_frame, text="OK", command=on_ok, width=10)
        ok_btn.pack(side=tk.LEFT, padx=5)

        cancel_btn = tk.Button(button_frame, text="Cancel", command=on_cancel, width=10)
        cancel_btn.pack(side=tk.LEFT, padx=5)

        # Bind Enter key to OK
        password_entry.bind("<Return>", lambda e: on_ok())

        password_dialog.wait_window()
        return password_value[0]

    def _ensure_encrypted_backup_access(self, backup, purpose: str) -> bool:
        """Ensure encrypted backup is unlocked, prompting until valid or cancelled."""
        if not getattr(backup, 'is_encrypted', False):
            return True

        while True:
            if not backup.encryption_password:
                password = self._prompt_for_password()
                if not password:
                    messagebox.showwarning(
                        "Password Required",
                        f"Encrypted backups require a password to {purpose}.",
                        parent=self.root
                    )
                    return False
                backup.encryption_password = password

            try:
                backup.get_backup_access()
                return True
            except Exception:
                backup.encryption_password = None
                messagebox.showerror(
                    "Incorrect Password",
                    "The password you entered is incorrect. Please try again.",
                    parent=self.root
                )

    def _perform_device_restore(self, restore_path, password=None):
        """Perform the actual restore operation in a background thread"""
        try:
            print(f"[DEBUG] Starting restore from: {restore_path}")

            # Update status
            self.root.after(0, lambda: self.restore_status_label.config(
                text=f"Status: Preparing restore..."))
            self.root.after(0, lambda: self.restore_progress_bar.config(value=0))

            # --- NEW: sanity-check backup layout vs current device UDID ---

            # The folder the user selected (usually the UDID folder)
            backup_udid = os.path.basename(os.path.normpath(restore_path))

            # Root directory we pass to Mobilebackup2Service.restore()
            backup_root = os.path.dirname(os.path.normpath(restore_path))

            # Try to get the current device UDID from lockdown/device info
            current_udid = None
            try:
                if self.current_device_lockdown is not None:
                    # Many pymobiledevice3 Lockdown implementations expose .udid
                    current_udid = getattr(self.current_device_lockdown, "udid", None)
                    if not current_udid:
                        # Fallback to Lockdown value
                        current_udid = self.current_device_lockdown.get_value("UniqueDeviceID")
            except Exception as e:
                print(f"[DEBUG] Could not read UDID from current_device_lockdown: {e}")

            if not current_udid and self.current_device_info:
                current_udid = self.current_device_info.get("unique_device_id")

            print(f"[DEBUG] Backup UDID folder: {backup_udid}")
            print(f"[DEBUG] Current device UDID: {current_udid}")
            print(f"[DEBUG] Backup root for restore: {backup_root}")

            # Expected Info.plist path that pymobiledevice3 will check
            expected_info_plist = None
            if current_udid:
                expected_info_plist = os.path.join(backup_root, current_udid, "Info.plist")
                print(f"[DEBUG] Expected Info.plist for restore: {expected_info_plist}")

            # If we have a current UDID and the folder name doesn't match,
            # we know pymobiledevice3's _assert_backup_exists will fail.
            #if current_udid and backup_udid != current_udid:
            #    msg = (
            #        "The selected backup appears to belong to a different device.\n\n"
            #        f"Backup folder UDID: {backup_udid}\n"
            #        f"Connected device UDID: {current_udid}\n\n"
            #        "The underlying pymobiledevice3 restore API expects the backup\n"
            #        "directory structure to contain a folder named after the\n"
            #        "currently connected device's UDID (with Info.plist inside).\n\n"
            #        "Cross-device restores (restoring a backup from one device\n"
            #        "onto a different device UDID) are not currently supported\n"
            #        "by this restore path. Please either:\n"
            #        "  • Connect the original device for this backup, or\n"
            #        "  • Recreate the backup using this device.\n"
            #    )
            #    print("[DEBUG] Restore aborted due to UDID mismatch (avoiding AssertionError).")
            #    self.root.after(0, lambda: messagebox.showerror(
            #        "Incompatible Backup",
            #        msg
            #    ))
            #    self.root.after(0, lambda: self.restore_status_label.config(
            #        text="Status: Restore aborted – backup belongs to a different device"
            #    ))
            #    self.root.after(0, lambda: self.restore_progress_bar.config(value=0))
            #    return

            # If we *do* have a matching layout, verify Info.plist exists where
            # pymobiledevice3 expects it (or at least in restore_path for safety).
            #if current_udid:
            #    # Normal case: backup_root/current_udid/Info.plist
            #    if not os.path.exists(expected_info_plist):
            #        print("[DEBUG] Expected Info.plist for current device UDID not found "
            #              f"at {expected_info_plist}")
            #        self.root.after(0, lambda: messagebox.showerror(
            #            "Missing Backup Files",
            #            "The backup does not appear to be complete for the currently "
            #            "connected device (Info.plist not found in expected location).\n\n"
            #            f"Expected here:\n{expected_info_plist}"
            #        ))
            #        self.root.after(0, lambda: self.restore_status_label.config(
            #            text="Status: Restore aborted – backup files missing"
            #        ))
            #        self.root.after(0, lambda: self.restore_progress_bar.config(value=0))
            #        return
            #else:
            #    # Fallback: no current_udid – at minimum ensure Info.plist exists
            #    info_plist_path = os.path.join(restore_path, "Info.plist")
            #    print(f"[DEBUG] No current_udid available, checking {info_plist_path}")
            #    if not os.path.exists(info_plist_path):
            #        self.root.after(0, lambda: messagebox.showerror(
            #            "Missing Backup Files",
            #            "Info.plist could not be found in the selected backup folder.\n\n"
            #            f"Checked:\n{info_plist_path}"
            #        ))
            #        self.root.after(0, lambda: self.restore_status_label.config(
            #            text="Status: Restore aborted – Info.plist missing"
            #        ))
            #        self.root.after(0, lambda: self.restore_progress_bar.config(value=0))
            #        return

            # --- Proceed with actual restore if all checks passed ---

            # Create restore service
            restore_service = Mobilebackup2Service(lockdown=self.current_device_lockdown)

            # Define progress callback
            def progress_callback(percentage, status_message=''):
                """Callback to update progress bar and status"""
                if self.restore_cancelled:
                    return False  # Signal cancellation

                # Update progress bar
                self.root.after(0, lambda p=percentage: self.restore_progress_bar.config(value=p))

                # Update status message
                if status_message:
                    self.root.after(0, lambda msg=status_message: self.restore_status_label.config(
                        text=f"Status: {msg} ({percentage:.1f}%)"))
                else:
                    self.root.after(0, lambda p=percentage: self.restore_status_label.config(
                        text=f"Status: Restoring device... ({p:.1f}%)"))

                return True  # Continue restore

            # Compute backup root (parent folder) and backup ID (folder name)
            backup_root = os.path.dirname(os.path.normpath(restore_path))
            backup_id = os.path.basename(os.path.normpath(restore_path))

            print(f"[DEBUG] Mobilebackup2 restore: backup_root={backup_root}, source={backup_id}")
            print(f"[DEBUG] Current device UDID: {current_udid}")
            print(f"[DEBUG] Backup folder UDID: {backup_id}")

            # Handle cross-device restore: If backup UDID doesn't match device UDID,
            # pymobiledevice3 may ignore it. Create a temporary symlink/junction with device's UDID.
            temp_link_created = False
            temp_link_path = None

            if current_udid and backup_id != current_udid:
                print(f"[DEBUG] UDID mismatch detected - creating temporary link for cross-device restore")
                temp_link_path = os.path.join(backup_root, current_udid)

                # Check if target already exists
                if os.path.exists(temp_link_path):
                    print(f"[WARN] Target path already exists: {temp_link_path}")
                else:
                    try:
                        import subprocess
                        # Create directory junction (Windows) or symlink (Unix)
                        if os.name == 'nt':  # Windows
                            # Use mklink /J for directory junction
                            subprocess.run(['mklink', '/J', temp_link_path, restore_path],
                                         shell=True, check=True, capture_output=True)
                            temp_link_created = True
                            print(f"[DEBUG] Created junction: {temp_link_path} -> {restore_path}")
                        else:  # Unix/Mac
                            os.symlink(restore_path, temp_link_path)
                            temp_link_created = True
                            print(f"[DEBUG] Created symlink: {temp_link_path} -> {restore_path}")

                        # Update backup_id to use device's UDID
                        backup_id = current_udid
                    except Exception as e:
                        print(f"[ERROR] Failed to create temporary link: {e}")
                        # Continue anyway with original backup_id

            # Start restore with progress callback
            # Include system=True, settings=True, and reboot=True to ensure
            # system files and settings are restored, and device reboots after restore
            try:
                restore_service.restore(
                    backup_directory=backup_root,   # parent folder that contains the backup
                    source=backup_id,               # the specific backup folder / ID to restore
                    password=password,
                    system=True,                    # Restore system files
                    settings=True,                  # Restore settings
                    reboot=True,                    # Reboot device after restore
                    remove=True,
                    progress_callback=progress_callback
                )
            finally:
                # Clean up temporary link if created
                if temp_link_created and temp_link_path:
                    try:
                        if os.name == 'nt':  # Windows junction
                            os.rmdir(temp_link_path)
                        else:  # Unix symlink
                            os.unlink(temp_link_path)
                        print(f"[DEBUG] Cleaned up temporary link: {temp_link_path}")
                    except Exception as e:
                        print(f"[WARN] Failed to clean up temporary link: {e}")


            # Check if cancelled
            if self.restore_cancelled:
                self.root.after(0, lambda: self.restore_status_label.config(
                    text="Status: Restore cancelled"))
                self.root.after(0, lambda: self.restore_progress_bar.config(value=0))
            else:
                # Restore complete
                self.root.after(0, lambda: self.restore_progress_bar.config(value=100))
                self.root.after(0, lambda: self.restore_status_label.config(
                    text="Status: Restore completed successfully!"))

        except Exception as e:
            import traceback
            print("[DEBUG] Restore failed:")
            traceback.print_exc()

            # Be defensive: these labels may not exist if restore panel wasn't fully created
            has_status = hasattr(self, "restore_status_label")
            has_progress = hasattr(self, "restore_progress_bar")

            from pymobiledevice3.exceptions import PyMobileDevice3Exception

            # Special-case Find My error from device (MBErrorDomain/211)
            if isinstance(e, PyMobileDevice3Exception) and "MBErrorDomain/211" in str(e):
                msg = (
                    "The device reported that Find My iPhone is enabled and blocked the restore.\n\n"
                    "iOS requires Find My iPhone to be disabled before restoring a backup.\n\n"
                    "To disable Find My:\n"
                    "  1. Open Settings on your device\n"
                    "  2. Tap your name at the top\n"
                    "  3. Tap 'Find My'\n"
                    "  4. Tap 'Find My iPhone'\n"
                    "  5. Toggle 'Find My iPhone' OFF\n"
                    "  6. Enter your Apple ID password when prompted\n\n"
                    "After disabling Find My, please try the restore again."
                )
                if has_status:
                    self.root.after(0, lambda: self.restore_status_label.config(
                        text="Status: Restore blocked – Find My iPhone is enabled"
                    ))
                if has_progress:
                    self.root.after(0, lambda: self.restore_progress_bar.config(value=0))
                messagebox.showerror("Find My iPhone Enabled", msg)
                return

            # Generic failure handler for all other restore errors
            if has_status:
                self.root.after(0, lambda: self.restore_status_label.config(
                    text=f"Status: Restore failed: {e}"
                ))
            if has_progress:
                self.root.after(0, lambda: self.restore_progress_bar.config(value=0))

            messagebox.showerror("Restore Failed", f"An error occurred during restore:\n\n{e}")


        except Exception as e:
            error_msg = f"Restore failed: {str(e)}"
            print(f"[DEBUG] {error_msg}")
            import traceback
            traceback.print_exc()

            self.root.after(0, lambda: self.restore_progress_status_label.config(
                text=f"Status: {error_msg}"))
            self.root.after(0, lambda: messagebox.showerror("Restore Error", error_msg))

        finally:
            # Re-enable buttons and reset state
            self.restore_in_progress = False
            self.root.after(0, lambda: self.restore_cancel_btn.config(state=tk.DISABLED))
            self.root.after(0, lambda: self.restore_btn.config(state=tk.NORMAL))

    def _cancel_device_restore(self):
        """Cancel the in-progress restore"""
        if self.restore_in_progress:
            result = messagebox.askyesno(
                "Cancel Restore",
                "Are you sure you want to cancel the restore in progress?\n\n"
                "Cancelling may leave your device in an incomplete state."
            )
            if result:
                self.restore_cancelled = True
                self.restore_progress_status_label.config(text="Status: Cancelling...")

    def _load_backup_to_modify(self):
        """Load the last completed backup into the Modify Backup pane (left slot)"""
        if not hasattr(self.backup_panel, 'last_completed_backup') or not self.backup_panel.last_completed_backup:
            messagebox.showwarning("No Backup", "No backup available to modify.")
            return

        backup_path = self.backup_panel.last_completed_backup

        # Set the path in the left entry field
        self.left_path_entry.delete(0, tk.END)
        self.left_path_entry.insert(0, backup_path)

        # Trigger loading in background thread
        thread = threading.Thread(target=self._load_backup_async, args=(backup_path, "left"), daemon=True)
        thread.start()

        print(f"[DEBUG] Loading backup into Slot A (left): {backup_path}")

    def _extract_last_completed_backup(self):
        """Start extraction for the most recently completed backup."""
        if not hasattr(self.backup_panel, 'last_completed_backup') or not self.backup_panel.last_completed_backup:
            messagebox.showwarning("No Backup", "No backup available to extract.")
            return

        backup_path = self.backup_panel.last_completed_backup
        backup_info = BackupInfo(backup_path, created_with_app=True, modified_with_app=False)
        self._start_full_extraction(backup_info, "left")

    def _extract_backup_from_slot(self, side: str):
        """Start extraction for the backup loaded in the given slot."""
        backup = self.left_backup if side == "left" else self.right_backup
        if not backup:
            messagebox.showwarning("No Backup", f"No backup loaded in Slot {'A' if side == 'left' else 'B'}.")
            return
        self._start_full_extraction(backup, side)

    def _load_backup_to_inactive_slot(self, backup):
        """Load backup into the inactive slot without overwriting an existing slot."""
        # Prefer empty slot: A if none loaded, B if A loaded, A if B loaded.
        if not self.left_backup and not self.right_backup:
            target = "left"
        elif self.left_backup and not self.right_backup:
            target = "right"
        elif self.right_backup and not self.left_backup:
            target = "left"
        else:
            # Both slots filled: ask user which to overwrite.
            target = messagebox.askquestion(
                "Select Slot",
                "Both slots are currently loaded.\n\n"
                "Which slot would you like to load this backup into?",
                icon="question",
                type=messagebox.YESNO,
                default=messagebox.NO,
                detail="Yes = Slot A (Left) • No = Slot B (Right)"
            )
            target = "left" if target == "yes" else "right"

        self._load_detected_backup(backup, target)

    def _open_device_backup_folder(self):
        """Open the backup folder in file explorer"""
        backup_location = self.backup_panel.location_entry.get().strip()

        if not backup_location:
            messagebox.showwarning("No Location", "No backup location specified.")
            return

        if not os.path.exists(backup_location):
            result = messagebox.askyesno(
                "Folder Not Found",
                f"The backup location does not exist:\n{backup_location}\n\nWould you like to create it?"
            )
            if result:
                try:
                    os.makedirs(backup_location, exist_ok=True)
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to create folder:\n{e}")
                    return
            else:
                return

        # Open folder in file explorer
        FileManager.open_folder(backup_location)


def main():
    log_startup(f"Startup begin. version={get_build_title()} exe={sys.executable}")
    # Use TkinterDnD if available for drag-and-drop support
    if DND_AVAILABLE:
        root = TkinterDnD.Tk()
    else:
        root = tk.Tk()
        print("Note: Install tkinterdnd2 for drag-and-drop support: pip install tkinterdnd2")

    config_path = os.path.join(os.path.expanduser("~"), ".backup_merger_config.json")
    if _read_app_config(config_path).get("dpi_aware_enabled", False):
        _apply_windows_dpi_scaling(root)

    root.withdraw()
    splash_info = show_startup_splash(root)
    root.update_idletasks()
    min_splash_ms = 800
    init_delay_ms = 200
    app_ref = {}

    if splash_info is not None:
        splash, start_time, progress = splash_info
        def _pulse():
            if progress.winfo_exists():
                progress.step(6)
            splash.update_idletasks()
            splash.update()
        root._startup_splash_pulse = _pulse

    def init_app():
        timing_on = os.environ.get("IBM_STARTUP_TIMING") == "1"
        t0 = time.perf_counter() if timing_on else None
        try:
            app_ref["app"] = BackupMergerGUI(root)
        except BaseException as exc:
            log_startup(f"Startup failed: {exc!r}\n{traceback.format_exc()}")
            raise
        if timing_on and t0 is not None:
            print(f"[STARTUP_TIMING] App init total: {time.perf_counter() - t0:.3f}s")
        if splash_info is not None:
            splash, start_time, progress = splash_info
            elapsed_ms = int((time.monotonic() - start_time) * 1000)
            delay_ms = max(0, min_splash_ms - elapsed_ms)
            def close_splash():
                try:
                    progress.stop()
                except Exception:
                    pass
                if hasattr(root, "_startup_splash_pulse"):
                    delattr(root, "_startup_splash_pulse")
                splash.destroy()
                root.deiconify()
            root.after(delay_ms, close_splash)
        else:
            root.deiconify()

    root.after(init_delay_ms, init_app)
    root.mainloop()


if __name__ == "__main__":
    main()
