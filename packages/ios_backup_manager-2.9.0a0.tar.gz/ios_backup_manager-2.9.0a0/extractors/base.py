#!/usr/bin/env python3
"""
Base class for category data extractors.

Provides abstract interface for extracting and exporting data from
specific iOS backup categories.
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional
import sqlite3
import os
import time

from backup_access import BackupAccess, get_backup_access, is_encrypted_backup, register_backup_access


class CategoryDataExtractor(ABC):
    """
    Abstract base class for extracting data from iOS backup categories.

    Subclasses implement specific logic for each category (Contacts, SMS, etc.)
    """

    def __init__(self, backup_path: str, use_cache: bool = True):
        """
        Initialize extractor with backup path.

        Args:
            backup_path: Path to iOS backup directory (containing Manifest.db)
            use_cache: Enable file path caching for faster lookups (default: True)
        """
        self.backup_path = backup_path
        self.backup_access = get_backup_access(backup_path)
        if self.backup_access is None:
            if is_encrypted_backup(backup_path):
                raise ValueError("Encrypted backup requires a password.")
            self.backup_access = BackupAccess(backup_path)
            register_backup_access(backup_path, self.backup_access)
        self.manifest_db_path = self.backup_access.manifest_db_path

        # Cache for file path lookups (speeds up exports with many attachments)
        self._file_path_cache = {}
        self._use_cache = use_cache
        self.last_export_bytes = 0

        # Verify backup exists
        if not os.path.exists(self.manifest_db_path):
            raise FileNotFoundError(f"Manifest.db not found at {self.manifest_db_path}")

    def _reset_export_bytes(self) -> None:
        self.last_export_bytes = 0

    def _add_export_bytes(self, value) -> None:
        if value is None:
            return
        if isinstance(value, (int, float)):
            if value > 0:
                self.last_export_bytes += int(value)
            return
        try:
            if os.path.exists(value):
                self.last_export_bytes += os.path.getsize(value)
        except Exception:
            return

    def find_db_file(self, domain: str, relative_path: str) -> Optional[str]:
        """
        Find a database file in the backup using domain and relative path.

        Args:
            domain: iOS domain (e.g., 'HomeDomain', 'Library')
            relative_path: Relative path within domain

        Returns:
            Physical path to the database file, or None if not found
        """
        import hashlib

        # Create cache key
        cache_key = f"{domain}-{relative_path}"

        # Check cache first (if enabled)
        if self._use_cache and cache_key in self._file_path_cache:
            return self._file_path_cache[cache_key]

        physical_path = self.backup_access.get_file_path(domain, relative_path)

        if physical_path and os.path.exists(physical_path):
            if self._use_cache:
                self._file_path_cache[cache_key] = physical_path
            return physical_path

        if self._use_cache:
            self._file_path_cache[cache_key] = None
        return None

    def _resolve_file_id_path(self, file_id: str, file_bplist: Optional[bytes] = None) -> Optional[str]:
        return self.backup_access.get_file_path_by_id(file_id, file_bplist=file_bplist)

    def find_file_in_backup(self, domain: str, relative_path: str) -> Optional[str]:
        """
        Find any file in the backup using domain and relative path.

        This is an alias for find_db_file() but with a more generic name,
        since it works for any file type (not just databases).

        Args:
            domain: iOS domain (e.g., 'HomeDomain', 'MediaDomain')
            relative_path: Relative path within domain

        Returns:
            Physical path to the file, or None if not found
        """
        return self.find_db_file(domain, relative_path)

    @abstractmethod
    def get_count(self) -> int:
        """
        Get total count of items in this category.

        Returns:
            Total number of items
        """
        pass

    @abstractmethod
    def get_items(self, limit: Optional[int] = None, offset: int = 0,
                  search: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get items from this category with pagination and optional search.

        Args:
            limit: Maximum number of items to return (None = all)
            offset: Number of items to skip
            search: Optional search query string

        Returns:
            List of item dictionaries with category-specific fields
        """
        pass

    @abstractmethod
    def export(self, items: List[Dict[str, Any]], output_path: str,
               format: str = 'default') -> bool:
        """
        Export selected items to a file or directory.

        Args:
            items: List of items to export (from get_items)
            output_path: Output file or directory path
            format: Export format ('default', 'csv', 'json', etc.)

        Returns:
            True if export succeeded, False otherwise
        """
        pass

    @abstractmethod
    def get_item_summary(self, item: Dict[str, Any]) -> str:
        """
        Get a short summary string for displaying in list view.

        Args:
            item: Item dictionary from get_items()

        Returns:
            Short summary string (e.g., "John Doe - (555) 123-4567")
        """
        pass
