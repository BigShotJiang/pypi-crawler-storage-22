#!/usr/bin/env python3
"""
Unified Browsers extractor for iOS backups.

Focus:
- Firefox is history-authoritative (places.db / browser.db).
- Chrome/Edge: bookmarks + top sites + tabs/session are primary artifacts.
- History is best-effort only when a validated visit table is present.
- Logins meta is metadata only; passwords are not recoverable from iTunes backups.
"""

import hashlib
import json
import os
import plistlib
import re
import sqlite3
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional, Tuple

from .base import CategoryDataExtractor


class BrowsersExtractor(CategoryDataExtractor):
    """Extract browser artifacts from iOS backups and generate a unified report."""

    FIREFOX_DOMAINS = [
        "AppDomainGroup-group.org.mozilla.ios.Firefox",
        "AppDomain-org.mozilla.ios.Firefox",
    ]
    CHROME_DOMAINS = [
        "AppDomain-com.google.chrome.ios",
        "AppDomainGroup-group.com.google.chrome",
    ]
    EDGE_DOMAINS = [
        "AppDomain-com.microsoft.msedge",
    ]
    SAFARI_DOMAIN = "HomeDomain"
    SAFARI_BOOKMARKS_PATH = "Library/Safari/Bookmarks.db"

    def __init__(self, backup_path: str):
        super().__init__(backup_path)
        self._data = None
        self._records = None
        self._load_data()
        if not self._records:
            raise FileNotFoundError("No browser artifacts found in backup")

    def get_count(self) -> int:
        return len(self._records or [])

    def get_items(self, limit: Optional[int] = None, offset: int = 0,
                  search: Optional[str] = None) -> List[Dict[str, Any]]:
        items = self._records or []
        if search:
            needle = search.lower()
            items = [
                item for item in items
                if needle in (item.get("url", "") or "").lower()
                or needle in (item.get("title", "") or "").lower()
                or needle in (item.get("record_type", "") or "").lower()
                or needle in (item.get("browser", "") or "").lower()
            ]
        if offset > 0:
            items = items[offset:]
        if limit is not None:
            items = items[:limit]
        return items

    def get_item_summary(self, item: Dict[str, Any]) -> str:
        browser = item.get("browser", "browser")
        record_type = item.get("record_type", "item")
        title = item.get("title") or item.get("url") or "Unknown"
        return f"{browser} {record_type}: {title}"

    def export(self, items: List[Dict[str, Any]], output_path: str,
               format: str = "html", progress_callback=None, timeline_emitter=None) -> bool:
        if format not in ("html", "files"):
            raise ValueError(f"Unsupported export format: {format}")
        try:
            self._reset_export_bytes()
            os.makedirs(output_path, exist_ok=True)

            if self._data is None:
                self._load_data()

            if timeline_emitter is not None:
                self._emit_timeline_events(self._data, timeline_emitter)

            data_path = os.path.join(output_path, "Browsers_Data.json")
            with open(data_path, "w", encoding="utf-8") as f:
                json.dump(self._data, f, indent=2, ensure_ascii=False, default=str)
            self._add_export_bytes(data_path)

            report_path = os.path.join(output_path, "Browsers.html")
            self._write_report(report_path, self._data)
            self._add_export_bytes(report_path)
            return True
        except Exception as exc:
            print(f"[ERROR] Browsers export failed: {exc}")
            import traceback
            traceback.print_exc()
            return False

    def _load_data(self) -> None:
        firefox = self._extract_firefox()
        chrome = self._extract_chrome()
        edge = self._extract_edge()
        safari = self._extract_safari()

        data = {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "browsers": {
                "firefox": firefox,
                "chrome": chrome,
                "edge": edge,
                "safari": safari,
            }
        }
        self._data = data
        self._records = self._flatten_records(data["browsers"])

    def _flatten_records(self, browsers: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
        records = []
        for browser, info in browsers.items():
            for record_type in ("history", "bookmarks", "tabs", "topsites", "downloads", "logins_meta"):
                for record in info.get(record_type, []):
                    flat = dict(record)
                    flat["browser"] = browser
                    flat["record_type"] = record_type
                    records.append(flat)
        return records

    def _extract_firefox(self) -> Dict[str, Any]:
        files = self._find_manifest_files(self.FIREFOX_DOMAINS)
        info = self._init_browser_record("firefox")

        places = self._select_files(files, suffix="places.db")
        browser_db = self._select_files(files, suffix="browser.db")
        tabs_state = self._select_files(files, suffix="tabsState.archive")
        topsites = self._select_files(files, suffix="topSites.archive")

        history_rows = []
        bookmarks = []
        history_confidence = 0

        if places:
            for record in places:
                path = record["physical_path"]
                profile_id = self._profile_from_relpath(record["relative_path"])
                hist, has_visits = self._firefox_places_history(path, profile_id, record["relative_path"])
                if hist:
                    history_rows.extend(hist)
                bmarks = self._firefox_places_bookmarks(path, profile_id, record["relative_path"])
                if bmarks:
                    bookmarks.extend(bmarks)
                if has_visits:
                    history_confidence = 3

        if history_confidence < 3 and browser_db:
            for record in browser_db:
                path = record["physical_path"]
                profile_id = self._profile_from_relpath(record["relative_path"])
                hist, has_visits = self._firefox_browser_history(path, profile_id, record["relative_path"])
                if hist:
                    history_rows.extend(hist)
                if has_visits:
                    history_confidence = 3

        tabs = []
        for record in tabs_state:
            tab_rows = self._firefox_tabs(record["physical_path"], record["relative_path"])
            tabs.extend(tab_rows)

        topsites_rows = []
        for record in topsites:
            topsites_rows.extend(self._firefox_topsites(record["physical_path"], record["relative_path"]))

        if topsites_rows and history_confidence < 1:
            history_confidence = 1
        if tabs and history_confidence < 2:
            history_confidence = 2

        info.update({
            "history": history_rows,
            "bookmarks": bookmarks,
            "tabs": tabs,
            "topsites": topsites_rows,
            "history_confidence": history_confidence,
        })
        return info

    def _extract_chrome(self) -> Dict[str, Any]:
        files = self._find_manifest_files(self.CHROME_DOMAINS)
        info = self._init_browser_record("chrome")

        bookmarks = self._extract_chromium_bookmarks(files, "Library/Application Support/Google/Chrome/")
        topsites = self._extract_chromium_topsites(files, "Library/Application Support/Google/Chrome/")
        tabs = self._extract_chromium_tabs(files, "Library/Application Support/Google/Chrome/")
        logins_meta = self._extract_chromium_logins(files, "Library/Application Support/Google/Chrome/")
        history_rows, has_history = self._extract_chromium_history(files, "Library/Application Support/Google/Chrome/")

        history_confidence = 0
        if topsites:
            history_confidence = 1
        if tabs:
            history_confidence = max(history_confidence, 2)
        if has_history:
            history_confidence = 3

        info.update({
            "bookmarks": bookmarks,
            "topsites": topsites,
            "tabs": tabs,
            "logins_meta": logins_meta,
            "history": history_rows,
            "history_confidence": history_confidence,
        })
        return info

    def _extract_edge(self) -> Dict[str, Any]:
        files = self._find_manifest_files(self.EDGE_DOMAINS)
        info = self._init_browser_record("edge")

        bookmarks = self._extract_chromium_bookmarks(files, "Library/Application Support/Microsoft/Edge/")
        topsites = self._extract_edge_topsites(files)
        tabs = self._extract_chromium_tabs(files, "Library/Application Support/Microsoft/Edge/")
        logins_meta = self._extract_chromium_logins(files, "Library/Application Support/Microsoft/Edge/")
        downloads = self._extract_edge_downloads(files)
        history_rows, has_history = self._extract_chromium_history(files, "Library/Application Support/Microsoft/Edge/")

        history_confidence = 0
        if topsites:
            history_confidence = 1
        if tabs:
            history_confidence = max(history_confidence, 2)
        if has_history:
            history_confidence = 3

        info.update({
            "bookmarks": bookmarks,
            "topsites": topsites,
            "tabs": tabs,
            "logins_meta": logins_meta,
            "downloads": downloads,
            "history": history_rows,
            "history_confidence": history_confidence,
        })
        return info

    def _extract_safari(self) -> Dict[str, Any]:
        info = self._init_browser_record("safari")
        bookmarks = []
        bookmarks_db = self.find_file_in_backup(self.SAFARI_DOMAIN, self.SAFARI_BOOKMARKS_PATH)
        if bookmarks_db:
            bookmarks = self._safari_bookmarks(bookmarks_db, self.SAFARI_BOOKMARKS_PATH)
        info.update({
            "bookmarks": bookmarks,
        })
        return info

    def _init_browser_record(self, name: str) -> Dict[str, Any]:
        return {
            "browser": name,
            "history_confidence": 0,
            "history": [],
            "bookmarks": [],
            "tabs": [],
            "topsites": [],
            "downloads": [],
            "logins_meta": [],
        }

    def _find_manifest_files(self, domains: List[str]) -> List[Dict[str, Any]]:
        files = []
        conn = sqlite3.connect(f"file:{self.manifest_db_path}?mode=ro", uri=True)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        for domain in domains:
            cur.execute(
                "SELECT fileID, relativePath, file FROM Files WHERE domain = ? AND relativePath IS NOT NULL",
                (domain,)
            )
            for row in cur.fetchall():
                rel_path = row["relativePath"]
                if not rel_path or rel_path.endswith("/"):
                    continue
                physical = self._resolve_file_id_path(row["fileID"], row["file"])
                if not physical or not os.path.exists(physical):
                    continue
                files.append({
                    "domain": domain,
                    "relative_path": rel_path.replace("\\", "/"),
                    "physical_path": physical,
                })
        conn.close()
        return files

    def _select_files(self, files: List[Dict[str, Any]], suffix: str) -> List[Dict[str, Any]]:
        return [f for f in files if f["relative_path"].endswith(suffix)]

    def _profile_from_relpath(self, rel_path: str) -> str:
        if not rel_path:
            return "default"
        parts = rel_path.split("/")
        return parts[0] if parts else "default"

    def _safari_bookmarks(self, db_path: str, rel_path: str) -> List[Dict[str, Any]]:
        rows = []
        try:
            conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            if not self._table_exists(cur, "bookmarks"):
                conn.close()
                return rows
            cur.execute("""
                SELECT id, parent, title, url, last_modified
                FROM bookmarks
                WHERE type = 0 AND deleted = 0 AND parent NOT IN (2, 3)
                ORDER BY parent, order_index
            """)
            folder_cache = {}
            for row in cur.fetchall():
                folder_name = self._safari_folder_name(cur, row["parent"], folder_cache)
                rows.append({
                    "browser": "safari",
                    "profile_id": "default",
                    "title": row["title"] or "",
                    "url": row["url"] or "",
                    "folder": folder_name,
                    "date_added": self._format_timestamp(row["last_modified"]),
                    "raw_timestamp": row["last_modified"],
                    "raw_format": "safari_last_modified",
                    "raw_source_path": rel_path,
                })
            conn.close()
        except Exception:
            return rows
        return rows

    def _safari_folder_name(self, cur: sqlite3.Cursor, folder_id: Any,
                             cache: Dict[Any, str]) -> str:
        if folder_id in cache:
            return cache[folder_id]
        try:
            cur.execute("SELECT title FROM bookmarks WHERE id = ?", (folder_id,))
            row = cur.fetchone()
            if row and row["title"]:
                title = row["title"]
            else:
                title = "Bookmarks"
        except Exception:
            title = "Bookmarks"
        cache[folder_id] = title
        return title

    def _firefox_places_history(self, db_path: str, profile_id: str, rel_path: str) -> Tuple[List[Dict[str, Any]], bool]:
        rows = []
        has_visits = False
        try:
            conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()

            if not self._table_exists(cur, "moz_historyvisits") or not self._table_exists(cur, "moz_places"):
                conn.close()
                return rows, False

            cur.execute("SELECT COUNT(*) FROM moz_historyvisits")
            if cur.fetchone()[0] > 0:
                has_visits = True

            cur.execute("""
                SELECT p.url, p.title, v.visit_date
                FROM moz_historyvisits v
                JOIN moz_places p ON p.id = v.place_id
                ORDER BY v.visit_date DESC
                LIMIT 5000
            """)
            for row in cur.fetchall():
                rows.append({
                    "browser": "firefox",
                    "profile_id": profile_id,
                    "title": row["title"] or "",
                    "url": row["url"] or "",
                    "visit_time": self._format_timestamp(row["visit_date"]),
                    "raw_timestamp": row["visit_date"],
                    "raw_format": "firefox_visit_date",
                    "raw_source_path": rel_path,
                })
            conn.close()
        except Exception:
            return rows, has_visits
        return rows, has_visits

    def _firefox_places_bookmarks(self, db_path: str, profile_id: str, rel_path: str) -> List[Dict[str, Any]]:
        rows = []
        try:
            conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            if not self._table_exists(cur, "moz_bookmarks") or not self._table_exists(cur, "moz_places"):
                conn.close()
                return rows

            cur.execute("""
                SELECT b.title, b.dateAdded, p.url
                FROM moz_bookmarks b
                JOIN moz_places p ON p.id = b.fk
                WHERE b.type = 1
                ORDER BY b.dateAdded DESC
                LIMIT 5000
            """)
            for row in cur.fetchall():
                rows.append({
                    "browser": "firefox",
                    "profile_id": profile_id,
                    "title": row["title"] or "",
                    "url": row["url"] or "",
                    "date_added": self._format_timestamp(row["dateAdded"]),
                    "raw_timestamp": row["dateAdded"],
                    "raw_format": "firefox_bookmark_date_added",
                    "raw_source_path": rel_path,
                })
            conn.close()
        except Exception:
            return rows
        return rows

    def _firefox_browser_history(self, db_path: str, profile_id: str, rel_path: str) -> Tuple[List[Dict[str, Any]], bool]:
        rows = []
        has_visits = False
        try:
            conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            if not self._table_exists(cur, "visits") and not self._table_exists(cur, "history"):
                conn.close()
                return rows, False

            if self._table_exists(cur, "visits"):
                cur.execute("SELECT COUNT(*) FROM visits")
                if cur.fetchone()[0] > 0:
                    has_visits = True

            if self._table_exists(cur, "history"):
                cols = self._table_columns(cur, "history")
                url_col = self._pick_col(cols, ["url", "urlString"])
                title_col = self._pick_col(cols, ["title", "pageTitle"])
                date_col = self._pick_col(cols, ["lastVisited", "visitDate", "last_visit_date", "lastVisitTime"])
                if url_col:
                    query = f"SELECT {url_col} AS url, {title_col or 'NULL'} AS title, {date_col or 'NULL'} AS last_visit FROM history"
                    query += " ORDER BY last_visit DESC" if date_col else ""
                    query += " LIMIT 5000"
                    cur.execute(query)
                    for row in cur.fetchall():
                        rows.append({
                            "browser": "firefox",
                            "profile_id": profile_id,
                            "title": row["title"] or "",
                            "url": row["url"] or "",
                            "visit_time": self._format_timestamp(row["last_visit"]),
                            "raw_timestamp": row["last_visit"],
                            "raw_format": "firefox_browser_history",
                            "raw_source_path": rel_path,
                        })
            conn.close()
        except Exception:
            return rows, has_visits
        return rows, has_visits

    def _firefox_tabs(self, path: str, rel_path: str) -> List[Dict[str, Any]]:
        tabs = []
        try:
            with open(path, "rb") as f:
                data = plistlib.load(f)
        except Exception:
            return tabs

        windows = data.get("windows") if isinstance(data, dict) else None
        if not windows:
            windows = data.get("Windows") if isinstance(data, dict) else []
        if not windows and isinstance(data, dict) and "tabs" in data:
            windows = [data]
        if not isinstance(windows, list):
            return tabs

        for win_idx, window in enumerate(windows):
            tab_list = window.get("tabs") if isinstance(window, dict) else None
            if not tab_list:
                tab_list = window.get("Tabs") if isinstance(window, dict) else []
            if not isinstance(tab_list, list):
                continue
            for tab_idx, tab in enumerate(tab_list):
                entry = None
                entries = tab.get("entries") if isinstance(tab, dict) else None
                if not entries:
                    entries = tab.get("Entries") if isinstance(tab, dict) else []
                if isinstance(entries, list) and entries:
                    entry = entries[-1]
                url = ""
                title = ""
                if isinstance(entry, dict):
                    url = entry.get("url") or entry.get("URL") or ""
                    title = entry.get("title") or entry.get("Title") or ""
                if not url and isinstance(tab, dict):
                    url = tab.get("lastURL") or tab.get("url") or ""
                if not title:
                    title = url

                last_seen = None
                if isinstance(tab, dict):
                    last_seen = tab.get("lastAccessed") or tab.get("lastUsed")

                tabs.append({
                    "browser": "firefox",
                    "profile_id": self._profile_from_relpath(rel_path),
                    "title": title,
                    "url": url,
                    "last_seen_time": self._format_timestamp(last_seen),
                    "raw_timestamp": last_seen,
                    "raw_format": "firefox_tab_last_seen",
                    "window_id": win_idx,
                    "tab_index": tab_idx,
                    "is_incognito": bool(tab.get("private")) if isinstance(tab, dict) else False,
                    "raw_source_path": rel_path,
                })
        return tabs

    def _firefox_topsites(self, path: str, rel_path: str) -> List[Dict[str, Any]]:
        rows = []
        try:
            with open(path, "rb") as f:
                data = plistlib.load(f)
        except Exception:
            return rows

        items = []
        if isinstance(data, dict):
            items = data.get("topSites") or data.get("items") or []
        elif isinstance(data, list):
            items = data

        for entry in items or []:
            if not isinstance(entry, dict):
                continue
            rows.append({
                "browser": "firefox",
                "profile_id": self._profile_from_relpath(rel_path),
                "title": entry.get("title") or "",
                "url": entry.get("url") or "",
                "raw_timestamp": None,
                "raw_format": "firefox_topsites",
                "raw_source_path": rel_path,
            })
        return rows

    def _extract_chromium_bookmarks(self, files: List[Dict[str, Any]], base_prefix: str) -> List[Dict[str, Any]]:
        rows = []
        for record in files:
            rel = record["relative_path"]
            if not rel.startswith(base_prefix):
                continue
            if not rel.endswith("/Bookmarks") and not rel.endswith("\\Bookmarks"):
                continue
            profile_id = self._profile_from_relpath(rel.split(base_prefix, 1)[1])
            try:
                with open(record["physical_path"], "r", encoding="utf-8", errors="ignore") as f:
                    data = json.load(f)
            except Exception:
                continue
            roots = data.get("roots", {}) if isinstance(data, dict) else {}
            for root_name, root in roots.items():
                rows.extend(self._walk_bookmark_node(
                    root,
                    browser=base_prefix,
                    profile_id=profile_id,
                    folder=root_name,
                    rel_path=rel,
                ))
        return rows

    def _walk_bookmark_node(self, node: Dict[str, Any], browser: str,
                            profile_id: str, folder: str, rel_path: str) -> List[Dict[str, Any]]:
        rows = []
        if not isinstance(node, dict):
            return rows
        if node.get("type") == "url" or node.get("url"):
            rows.append({
                "browser": self._browser_name_from_prefix(browser),
                "profile_id": profile_id,
                "title": node.get("name") or "",
                "url": node.get("url") or "",
                "folder": folder,
                "date_added": self._format_timestamp(node.get("date_added")),
                "raw_timestamp": node.get("date_added"),
                "raw_format": "chromium_date_added",
                "raw_source_path": rel_path,
            })
        for child in node.get("children", []) or []:
            child_name = folder
            if isinstance(child, dict) and child.get("name"):
                child_name = f"{folder}/{child.get('name')}"
            rows.extend(self._walk_bookmark_node(child, browser, profile_id, child_name, rel_path))
        return rows

    def _extract_chromium_topsites(self, files: List[Dict[str, Any]], base_prefix: str) -> List[Dict[str, Any]]:
        rows = []
        for record in files:
            rel = record["relative_path"]
            if not rel.startswith(base_prefix) or not rel.endswith("Top Sites"):
                continue
            profile_id = self._profile_from_relpath(rel.split(base_prefix, 1)[1])
            tops = self._read_topsites_db(record["physical_path"], profile_id, rel, self._browser_name_from_prefix(base_prefix))
            rows.extend(tops)
        return rows

    def _read_topsites_db(self, path: str, profile_id: str, rel_path: str, browser: str) -> List[Dict[str, Any]]:
        rows = []
        try:
            conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            if not self._table_exists(cur, "top_sites"):
                conn.close()
                return rows
            cols = self._table_columns(cur, "top_sites")
            url_col = self._pick_col(cols, ["url", "url_list"])
            title_col = self._pick_col(cols, ["title", "title_list"])
            rank_col = self._pick_col(cols, ["url_rank", "rank"])
            query = f"SELECT {url_col or 'NULL'} AS url, {title_col or 'NULL'} AS title, {rank_col or 'NULL'} AS rank FROM top_sites"
            query += " ORDER BY rank ASC" if rank_col else ""
            query += " LIMIT 2000"
            cur.execute(query)
            for row in cur.fetchall():
                rows.append({
                    "browser": browser,
                    "profile_id": profile_id,
                    "title": row["title"] or "",
                    "url": row["url"] or "",
                    "rank": row["rank"],
                    "raw_timestamp": None,
                    "raw_format": "chromium_topsites",
                    "raw_source_path": rel_path,
                })
            conn.close()
        except Exception:
            return rows
        return rows

    def _extract_edge_topsites(self, files: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        rows = []
        for record in files:
            rel = record["relative_path"]
            if not rel.endswith("EdgeTopSites.json"):
                continue
            profile_id = self._profile_from_relpath(rel)
            try:
                with open(record["physical_path"], "r", encoding="utf-8", errors="ignore") as f:
                    data = json.load(f)
            except Exception:
                continue
            items = data.get("items") if isinstance(data, dict) else data
            if not isinstance(items, list):
                continue
            for item in items:
                if not isinstance(item, dict):
                    continue
                rows.append({
                    "browser": "edge",
                    "profile_id": profile_id,
                    "title": item.get("title") or "",
                    "url": item.get("url") or "",
                    "raw_timestamp": None,
                    "raw_format": "edge_topsites",
                    "raw_source_path": rel,
                })
        return rows

    def _extract_chromium_tabs(self, files: List[Dict[str, Any]], base_prefix: str) -> List[Dict[str, Any]]:
        rows = []
        session_files = []
        for record in files:
            rel = record["relative_path"]
            if not rel.startswith(base_prefix):
                continue
            if "/Sessions/" in rel and ("Tabs_" in rel or "Session_" in rel):
                session_files.append(record)

        for record in session_files:
            urls = self._extract_urls_from_binary(record["physical_path"], max_urls=500)
            profile_id = self._profile_from_relpath(record["relative_path"].split(base_prefix, 1)[1])
            for idx, url in enumerate(urls):
                rows.append({
                    "browser": self._browser_name_from_prefix(base_prefix),
                    "profile_id": profile_id,
                    "title": url,
                    "url": url,
                    "last_seen_time": self._format_timestamp(os.path.getmtime(record["physical_path"])),
                    "raw_timestamp": os.path.getmtime(record["physical_path"]),
                    "raw_format": "file_mtime",
                    "window_id": None,
                    "tab_index": idx,
                    "is_incognito": False,
                    "raw_source_path": record["relative_path"],
                })
        return rows

    def _extract_chromium_logins(self, files: List[Dict[str, Any]], base_prefix: str) -> List[Dict[str, Any]]:
        rows = []
        for record in files:
            rel = record["relative_path"]
            if not rel.startswith(base_prefix) or not rel.endswith("Login Data"):
                continue
            profile_id = self._profile_from_relpath(rel.split(base_prefix, 1)[1])
            rows.extend(self._read_logins_db(record["physical_path"], profile_id, rel, self._browser_name_from_prefix(base_prefix)))
        return rows

    def _read_logins_db(self, path: str, profile_id: str, rel_path: str, browser: str) -> List[Dict[str, Any]]:
        rows = []
        try:
            conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            if not self._table_exists(cur, "logins"):
                conn.close()
                return rows
            cols = self._table_columns(cur, "logins")
            origin_col = self._pick_col(cols, ["origin_url", "origin_url_list"])
            username_col = self._pick_col(cols, ["username_value", "username"])
            created_col = self._pick_col(cols, ["date_created", "created"])
            last_used_col = self._pick_col(cols, ["date_last_used", "last_used"])
            query = f"SELECT {origin_col or 'NULL'} AS origin_url, {username_col or 'NULL'} AS username, {created_col or 'NULL'} AS created, {last_used_col or 'NULL'} AS last_used FROM logins"
            query += " ORDER BY last_used DESC" if last_used_col else ""
            query += " LIMIT 5000"
            cur.execute(query)
            for row in cur.fetchall():
                rows.append({
                    "browser": browser,
                    "profile_id": profile_id,
                    "origin_url": row["origin_url"] or "",
                    "username": row["username"] or "",
                    "created": self._format_timestamp(row["created"]),
                    "last_used": self._format_timestamp(row["last_used"]),
                    "raw_source_path": rel_path,
                })
            conn.close()
        except Exception:
            return rows
        return rows

    def _extract_chromium_history(self, files: List[Dict[str, Any]], base_prefix: str) -> Tuple[List[Dict[str, Any]], bool]:
        rows = []
        has_history = False
        for record in files:
            rel = record["relative_path"]
            if not rel.startswith(base_prefix):
                continue
            if not rel.endswith("History") and not rel.endswith("History.db"):
                continue
            profile_id = self._profile_from_relpath(rel.split(base_prefix, 1)[1])
            history_rows, valid = self._read_history_db(record["physical_path"], profile_id, rel, self._browser_name_from_prefix(base_prefix))
            if valid:
                has_history = True
                rows.extend(history_rows)
        return rows, has_history

    def _read_history_db(self, path: str, profile_id: str, rel_path: str, browser: str) -> Tuple[List[Dict[str, Any]], bool]:
        rows = []
        valid = False
        try:
            conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            if not self._table_exists(cur, "visits") or not self._table_exists(cur, "urls"):
                conn.close()
                return rows, False
            cur.execute("SELECT COUNT(*) FROM visits")
            if cur.fetchone()[0] > 0:
                valid = True
            if valid:
                cur.execute("""
                    SELECT u.url, u.title, v.visit_time
                    FROM visits v
                    JOIN urls u ON u.id = v.url
                    ORDER BY v.visit_time DESC
                    LIMIT 5000
                """)
                for row in cur.fetchall():
                    rows.append({
                        "browser": browser,
                        "profile_id": profile_id,
                        "title": row["title"] or "",
                        "url": row["url"] or "",
                        "visit_time": self._format_timestamp(row["visit_time"]),
                        "raw_timestamp": row["visit_time"],
                        "raw_format": "chromium_visit_time",
                        "raw_source_path": rel_path,
                    })
            conn.close()
        except Exception:
            return rows, False
        return rows, valid

    def _extract_edge_downloads(self, files: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        rows = []
        for record in files:
            rel = record["relative_path"]
            if not rel.endswith("edge_download_aad.db") and not rel.endswith("edge_download_normal.db"):
                continue
            profile_id = self._profile_from_relpath(rel)
            rows.extend(self._read_edge_downloads(record["physical_path"], profile_id, rel))
        return rows

    def _read_edge_downloads(self, path: str, profile_id: str, rel_path: str) -> List[Dict[str, Any]]:
        rows = []
        try:
            conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            if not self._table_exists(cur, "t_edge_downloads"):
                conn.close()
                return rows
            cols = self._table_columns(cur, "t_edge_downloads")
            url_col = self._pick_col(cols, ["url"])
            file_col = self._pick_col(cols, ["file_name", "filename"])
            start_col = self._pick_col(cols, ["start_time", "startTime"])
            end_col = self._pick_col(cols, ["end_time", "endTime"])
            query = f"SELECT {url_col or 'NULL'} AS url, {file_col or 'NULL'} AS file_name, {start_col or 'NULL'} AS start_time, {end_col or 'NULL'} AS end_time FROM t_edge_downloads"
            query += " ORDER BY start_time DESC" if start_col else ""
            query += " LIMIT 5000"
            cur.execute(query)
            for row in cur.fetchall():
                rows.append({
                    "browser": "edge",
                    "profile_id": profile_id,
                    "url": row["url"] or "",
                    "file_name": row["file_name"] or "",
                    "start_time": self._format_timestamp(row["start_time"]),
                    "end_time": self._format_timestamp(row["end_time"]),
                    "raw_timestamp": row["start_time"],
                    "raw_format": "edge_download_start_time",
                    "raw_source_path": rel_path,
                })
            conn.close()
        except Exception:
            return rows
        return rows

    def _extract_urls_from_binary(self, path: str, max_urls: int = 500) -> List[str]:
        try:
            with open(path, "rb") as f:
                data = f.read()
        except Exception:
            return []
        matches = re.findall(rb"https?://[^\s\"\'<>\\x00]+", data)
        urls = []
        seen = set()
        for match in matches:
            try:
                url = match.decode("utf-8", errors="ignore")
            except Exception:
                continue
            if url in seen:
                continue
            seen.add(url)
            urls.append(url)
            if len(urls) >= max_urls:
                break
        return urls

    def _table_exists(self, cur: sqlite3.Cursor, table: str) -> bool:
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name = ?", (table,))
        return cur.fetchone() is not None

    def _table_columns(self, cur: sqlite3.Cursor, table: str) -> List[str]:
        cur.execute(f'PRAGMA table_info("{table}")')
        return [row[1] for row in cur.fetchall()]

    def _pick_col(self, columns: List[str], candidates: List[str]) -> Optional[str]:
        for candidate in candidates:
            if candidate in columns:
                return candidate
        return None

    def _browser_name_from_prefix(self, prefix: str) -> str:
        if "Google/Chrome" in prefix:
            return "chrome"
        if "Microsoft/Edge" in prefix:
            return "edge"
        return "browser"

    def _format_timestamp(self, value: Any) -> str:
        dt = self._convert_timestamp(value)
        if not dt:
            return ""
        return dt.strftime("%m-%d-%Y %H:%M:%S")

    def _convert_timestamp(self, value: Any) -> Optional[datetime]:
        if value is None or value == "":
            return None
        if isinstance(value, str):
            try:
                return datetime.fromisoformat(value)
            except Exception:
                return None
        try:
            val = float(value)
        except Exception:
            return None

        # Chromium/WebKit timestamp: microseconds since 1601-01-01
        if val > 1e15:
            base = datetime(1601, 1, 1, tzinfo=timezone.utc)
            seconds = val / 1e6
            return base + timedelta(seconds=seconds)

        # Microseconds since Unix epoch
        if val > 1e12:
            seconds = val / 1e6
            return datetime.fromtimestamp(seconds, tz=timezone.utc)

        # Milliseconds since Unix epoch
        if val > 1e10:
            seconds = val / 1e3
            return datetime.fromtimestamp(seconds, tz=timezone.utc)

        # Seconds since Unix epoch
        if val > 0:
            return datetime.fromtimestamp(val, tz=timezone.utc)
        return None

    def _emit_timeline_events(self, data: Dict[str, Any], emitter) -> None:
        browsers = data.get("browsers", {})
        for browser_name, info in browsers.items():
            app_name = browser_name.title()
            link_hint = "Browsers/Browsers.html"

            for record in info.get("history", []):
                self._emit_event(
                    emitter,
                    record,
                    app_name=app_name,
                    event_type="browser_visit",
                    title_prefix="Visited",
                    confidence="high",
                    report_anchor=self._make_anchor("history", record),
                    link_hint=link_hint,
                )

            for record in info.get("tabs", []):
                self._emit_event(
                    emitter,
                    record,
                    app_name=app_name,
                    event_type="browser_tab_open",
                    title_prefix="Open tab",
                    confidence="low",
                    report_anchor=self._make_anchor("tabs", record),
                    link_hint=link_hint,
                )

            for record in info.get("bookmarks", []):
                self._emit_event(
                    emitter,
                    record,
                    app_name=app_name,
                    event_type="bookmark_added",
                    title_prefix="Bookmark",
                    confidence="med",
                    report_anchor=self._make_anchor("bookmarks", record),
                    link_hint=link_hint,
                )

    def _emit_event(self, emitter, record: Dict[str, Any], app_name: str, event_type: str,
                    title_prefix: str, confidence: str, report_anchor: str, link_hint: str) -> None:
        timestamp = record.get("visit_time") or record.get("last_seen_time") or record.get("date_added")
        if not timestamp:
            return
        title = record.get("title") or record.get("url") or ""
        details = {
            "title": record.get("title"),
            "url": record.get("url"),
            "folder": record.get("folder"),
        }
        emitter.emit({
            "timestamp": timestamp,
            "timestamp_display": timestamp,
            "timestamp_utc": timestamp,
            "raw_timestamp": record.get("raw_timestamp"),
            "raw_format": record.get("raw_format"),
            "source_app": app_name,
            "source_category": "Browsers",
            "event_type": event_type,
            "title": f"{title_prefix}: {title}" if title else title_prefix,
            "details": details,
            "confidence": confidence,
            "raw_source_path": record.get("raw_source_path", ""),
            "profile_id": record.get("profile_id"),
            "report_anchor": report_anchor,
            "link_hint": link_hint,
        })

    def _make_anchor(self, record_type: str, record: Dict[str, Any]) -> str:
        url = record.get("url") or ""
        title = record.get("title") or ""
        ts = record.get("visit_time") or record.get("last_seen_time") or record.get("date_added") or ""
        profile = record.get("profile_id") or ""
        raw = f"{record_type}|{url}|{title}|{ts}|{profile}"
        digest = hashlib.sha1(raw.encode("utf-8", errors="ignore")).hexdigest()[:10]
        return f"{record_type}-{digest}"

    def _write_report(self, report_path: str, data: Dict[str, Any]) -> None:
        browsers = data.get("browsers", {})

        html = []
        html.extend([
            "<!DOCTYPE html>",
            "<html lang=\"en\">",
            "<head>",
            "<meta charset=\"UTF-8\">",
            "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">",
            "<title>Browsers</title>",
            "<style>",
            "body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;background:#f6f6f6;padding:20px;}",
            ".container{max-width:1200px;margin:0 auto;background:#fff;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,0.1);overflow:hidden;}",
            ".header{background:linear-gradient(135deg,#1f77b4,#6fb1e7);color:#fff;padding:30px;text-align:left;}",
            ".header h1{margin:0 0 10px 0;font-size:32px;font-weight:600;}",
            ".header p{opacity:0.9;margin:0;font-size:16px;}",
            ".breadcrumbs{display:flex;align-items:center;gap:8px;font-size:12px;letter-spacing:0.2px;color:rgba(255,255,255,0.85);margin-bottom:10px;}",
            ".breadcrumbs a{color:#fff;text-decoration:none;font-weight:600;}",
            ".breadcrumbs a:hover{text-decoration:underline;}",
            ".breadcrumbs .back-arrow{opacity:0.6;}",
            ".embedded .breadcrumbs{display:none;}",
            ".section{padding:20px;border-bottom:1px solid #eee;}",
            ".section h2{margin:0 0 10px;font-size:20px;}",
            ".note{color:#666;font-size:13px;margin-top:6px;}",
            ".summary-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;}",
            ".summary-card{border:1px solid #e5e7eb;border-radius:10px;padding:12px;background:#f9fafb;cursor:pointer;transition:background 0.2s, border-color 0.2s;}",
            ".summary-card:hover{background:#eef5ff;border-color:#cbd5f5;}",
            ".summary-title{font-weight:600;color:#111827;margin-bottom:8px;}",
            ".summary-meta{font-size:12px;color:#4b5563;display:grid;gap:4px;}",
            ".controls{padding:16px 20px;border-bottom:1px solid #eee;display:flex;flex-direction:column;gap:12px;max-width:100%;}",
            ".search-box{width:100%;position:relative;}",
            ".search-box input{width:100%;max-width:100%;box-sizing:border-box;padding:10px 40px 10px 14px;border:1px solid #d1d5db;border-radius:8px;font-size:14px;}",
            ".clear-search{position:absolute;right:18px;top:50%;transform:translateY(-50%);border:1px solid #d1d5db;background:#f3f4f6;color:#111827;border-radius:6px;padding:4px 8px;font-size:12px;cursor:pointer;display:none;}",
            ".clear-search.visible{display:inline-block;}",
            ".filter-row{display:flex;flex-wrap:wrap;gap:8px;align-items:center;}",
            ".filter-label{font-size:12px;font-weight:600;color:#374151;}",
            ".filter-chip{border:1px solid #d1d5db;background:#fff;color:#374151;padding:6px 10px;border-radius:999px;font-size:12px;cursor:pointer;}",
            ".filter-chip.active{background:#1f77b4;border-color:#1f77b4;color:#fff;}",
            ".browser-block{border:1px solid #e5e7eb;border-radius:12px;margin:16px 20px;overflow:hidden;}",
            ".browser-header{padding:16px 18px;background:#f3f6fb;display:flex;justify-content:space-between;align-items:center;cursor:pointer;}",
            ".browser-title{font-weight:600;color:#111827;font-size:16px;}",
            ".browser-count{background:#1f77b4;color:#fff;padding:4px 10px;border-radius:999px;font-size:12px;}",
            ".browser-body.collapsed{display:none;}",
            ".group{padding:16px 18px;border-top:1px solid #eee;}",
            ".group h3{margin:0 0 10px;font-size:15px;font-weight:600;color:#111827;display:flex;gap:8px;align-items:center;}",
            ".pill{display:inline-block;background:#eef2f6;border-radius:999px;padding:2px 8px;font-size:12px;}",
            ".card-list{display:flex;flex-direction:column;gap:10px;}",
            ".card{border:1px solid #e5e7eb;border-radius:10px;padding:12px;background:#fff;}",
            ".card{min-width:0;}",
            ".card-title{font-weight:600;font-size:14px;color:#111827;margin-bottom:6px;word-break:break-word;overflow-wrap:anywhere;}",
            ".card-url{font-size:12px;color:#1f77b4;word-break:break-all;overflow-wrap:anywhere;}",
            ".card-link{color:#1f77b4;text-decoration:none;}",
            ".card-link:hover{text-decoration:underline;}",
            ".card-meta{margin-top:8px;font-size:12px;color:#6b7280;display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:6px;align-items:start;}",
            ".card-meta span{display:block;min-width:0;word-break:break-word;overflow-wrap:anywhere;}",
            ".hidden{display:none !important;}",
            "@media (max-width: 980px){",
            "  body{padding:12px;}",
            "  .container{border-radius:10px;}",
            "  .controls{padding:12px;}",
            "  .browser-block{margin:12px;}",
            "  .card-meta{grid-template-columns:1fr;}",
            "}",
            "</style>",
            "</head>",
            "<body>",
            "<div class=\"container\">",
            "<div class=\"header\">",
            "<div class=\"breadcrumbs\"><span class=\"back-arrow\">&larr;</span><a href=\"../Start_Here.html\">Back</a></div>",
            "<h1>Browsers</h1>",
            f"<p>Extracted from iOS Backup on {datetime.now().strftime('%B %d, %Y')}</p>",
            "</div>",
        ])

        html.append("<div class=\"section\">")
        html.append("<h2>Summary</h2>")
        html.append("<div class=\"summary-grid\">")
        for name, info in browsers.items():
            html.append(f"<div class=\"summary-card\" data-browser=\"{self._escape_html(name)}\">")
            html.append(f"<div class=\"summary-title\">{name.title()}</div>")
            html.append("<div class=\"summary-meta\">")
            html.append(f"<span>History: {len(info.get('history', []))}</span>")
            html.append(f"<span>Bookmarks: {len(info.get('bookmarks', []))}</span>")
            html.append(f"<span>Tabs: {len(info.get('tabs', []))}</span>")
            html.append(f"<span>Top Sites: {len(info.get('topsites', []))}</span>")
            html.append(f"<span>Downloads: {len(info.get('downloads', []))}</span>")
            html.append(f"<span>Logins Meta: {len(info.get('logins_meta', []))}</span>")
            html.append(f"<span>History Confidence: {info.get('history_confidence', 0)}</span>")
            html.append("</div></div>")
        html.append("</div>")
        html.append("<div class=\"note\">History confidence: 0 = none, 1 = top sites, 2 = tabs/session, 3 = validated visit table.</div>")
        html.append("<div class=\"note\">Logins meta are metadata only (origin, username, timestamps). Passwords are not recoverable from iTunes backups.</div>")
        html.append("</div>")

        html.append("<div class=\"controls\">")
        html.append("<div class=\"search-box\"><input type=\"text\" id=\"searchInput\" placeholder=\"Search browsers report...\" onkeyup=\"filterItems()\"><button id=\"clearSearch\" class=\"clear-search\" title=\"Clear\" aria-label=\"Clear search\">X</button></div>")
        html.append("<div class=\"filter-row\" id=\"browserFilters\">")
        html.append("<span class=\"filter-label\">Browser</span>")
        html.append("<button class=\"filter-chip active\" data-filter-type=\"browser\" data-filter-value=\"all\">All</button>")
        for name in browsers.keys():
            html.append(f"<button class=\"filter-chip\" data-filter-type=\"browser\" data-filter-value=\"{self._escape_html(name)}\">{name.title()}</button>")
        html.append("</div>")
        html.append("<div class=\"filter-row\" id=\"typeFilters\">")
        html.append("<span class=\"filter-label\">Type</span>")
        html.append("<button class=\"filter-chip active\" data-filter-type=\"type\" data-filter-value=\"all\">All</button>")
        for label in ["tabs", "bookmarks", "history", "topsites", "downloads", "logins_meta"]:
            text = label.replace("_", " ").title()
            html.append(f"<button class=\"filter-chip\" data-filter-type=\"type\" data-filter-value=\"{label}\">{text}</button>")
        html.append("</div>")
        html.append("</div>")

        for name, info in browsers.items():
            total = sum(len(info.get(key, [])) for key in ("tabs", "bookmarks", "history", "topsites", "downloads", "logins_meta"))
            html.append(f"<div class=\"browser-block\" data-browser=\"{self._escape_html(name)}\">")
            html.append("<div class=\"browser-header\" onclick=\"toggleBrowser(this)\">")
            html.append(f"<div class=\"browser-title\">{name.title()}</div>")
            html.append(f"<div class=\"browser-count\">{total} items</div>")
            html.append("</div>")
            html.append("<div class=\"browser-body collapsed\">")
            html.append(self._render_cards("Tabs", "tabs", info.get("tabs", []), [
                ("title", "Title"),
                ("url", "URL"),
                ("last_seen_time", "Last Seen"),
                ("window_id", "Window"),
                ("tab_index", "Index"),
                ("raw_source_path", "Source"),
            ], anchor_id=f"{name}-tabs"))
            html.append(self._render_cards("Bookmarks", "bookmarks", info.get("bookmarks", []), [
                ("title", "Title"),
                ("url", "URL"),
                ("folder", "Folder"),
                ("date_added", "Added"),
                ("raw_source_path", "Source"),
            ], anchor_id=f"{name}-bookmarks"))
            html.append(self._render_cards("History (best-effort)", "history", info.get("history", []), [
                ("title", "Title"),
                ("url", "URL"),
                ("visit_time", "Visit Time"),
                ("raw_source_path", "Source"),
            ], anchor_id=f"{name}-history"))
            html.append(self._render_cards("Top Sites", "topsites", info.get("topsites", []), [
                ("title", "Title"),
                ("url", "URL"),
                ("rank", "Rank"),
                ("raw_source_path", "Source"),
            ], anchor_id=f"{name}-topsites"))
            html.append(self._render_cards("Downloads", "downloads", info.get("downloads", []), [
                ("file_name", "File"),
                ("url", "URL"),
                ("start_time", "Start"),
                ("end_time", "End"),
                ("raw_source_path", "Source"),
            ], anchor_id=f"{name}-downloads"))
            html.append(self._render_cards("Logins Meta", "logins_meta", info.get("logins_meta", []), [
                ("origin_url", "Origin"),
                ("username", "Username"),
                ("created", "Created"),
                ("last_used", "Last Used"),
                ("raw_source_path", "Source"),
            ], anchor_id=f"{name}-logins"))
            html.append("</div></div>")

        html.extend([
            "</div>",
            "<script>",
            "function toggleBrowser(header){",
            "  const body = header.nextElementSibling;",
            "  if(body){ body.classList.toggle('collapsed'); }",
            "}",
            "function setActiveFilter(type, value){",
            "  document.querySelectorAll(`.filter-chip[data-filter-type=\"${type}\"]`).forEach(chip=>{",
            "    chip.classList.toggle('active', chip.dataset.filterValue === value);",
            "  });",
            "}",
            "function getActiveFilter(type){",
            "  const active = document.querySelector(`.filter-chip[data-filter-type=\"${type}\"].active`);",
            "  return active ? active.dataset.filterValue : 'all';",
            "}",
            "function scrollToBrowser(name){",
            "  const block = document.querySelector(`.browser-block[data-browser=\"${name}\"]`);",
            "  if(!block){ return; }",
            "  block.classList.remove('hidden');",
            "  const body = block.querySelector('.browser-body');",
            "  if(body){ body.classList.remove('collapsed'); }",
            "  block.scrollIntoView({behavior:'smooth', block:'start'});",
            "}",
            "function filterItems(){",
            "  const input = document.getElementById('searchInput');",
            "  const query = input ? input.value.toLowerCase() : '';",
            "  const browserFilter = getActiveFilter('browser');",
            "  const typeFilter = getActiveFilter('type');",
            "  document.querySelectorAll('.browser-block').forEach(block=>{",
            "    const browser = block.dataset.browser;",
            "    let browserVisible = false;",
            "    block.querySelectorAll('.card').forEach(card=>{",
            "      const text = (card.dataset.search || '').toLowerCase();",
            "      const type = card.dataset.type || '';",
            "      let visible = true;",
            "      if(browserFilter !== 'all' && browser !== browserFilter){ visible = false; }",
            "      if(typeFilter !== 'all' && type !== typeFilter){ visible = false; }",
            "      if(query && text.indexOf(query) === -1){ visible = false; }",
            "      card.classList.toggle('hidden', !visible);",
            "      if(visible){ browserVisible = true; }",
            "    });",
            "    block.classList.toggle('hidden', !browserVisible);",
            "  });",
            "}",
            "document.querySelectorAll('.summary-card').forEach(card=>{",
            "  card.addEventListener('click', ()=>{",
            "    const browser = card.dataset.browser;",
            "    if(browser){",
            "      setActiveFilter('browser', browser);",
            "      setActiveFilter('type', 'all');",
            "      const input = document.getElementById('searchInput');",
            "      if(input){ input.value = ''; }",
            "      filterItems();",
            "      scrollToBrowser(browser);",
            "    }",
            "  });",
            "});",
            "const clearBtn = document.getElementById('clearSearch');",
            "const searchInput = document.getElementById('searchInput');",
            "if(clearBtn && searchInput){",
            "  const toggleClear = ()=> clearBtn.classList.toggle('visible', !!searchInput.value);",
            "  searchInput.addEventListener('input', toggleClear);",
            "  clearBtn.addEventListener('click', ()=>{",
            "    searchInput.value = '';",
            "    toggleClear();",
            "    filterItems();",
            "    searchInput.focus();",
            "  });",
            "  toggleClear();",
            "}",
            "document.querySelectorAll('.filter-chip').forEach(chip=>{",
            "  chip.addEventListener('click', ()=>{",
            "    setActiveFilter(chip.dataset.filterType, chip.dataset.filterValue);",
            "    filterItems();",
            "  });",
            "});",
            "filterItems();",
            "</script>",
            "<script>if (window.self !== window.top) { document.body.classList.add('embedded'); }</script>",
            "</body>",
            "</html>",
        ])

        with open(report_path, "w", encoding="utf-8") as f:
            f.write("\n".join(html))

    def _render_cards(self, title: str, record_type: str, rows: List[Dict[str, Any]],
                      columns: List[Tuple[str, str]], limit: int = 200, anchor_id: Optional[str] = None) -> str:
        html = []
        anchor_attr = f" id=\"{anchor_id}\"" if anchor_id else ""
        html.append(f"<div class=\"group\"{anchor_attr}>")
        html.append(f"<h3>{title} <span class=\"pill\">{len(rows)} items</span></h3>")
        if not rows:
            html.append("<div class=\"note\">No data found.</div>")
            html.append("</div>")
            return "\n".join(html)

        html.append("<div class=\"card-list\">")
        for row in rows[:limit]:
            title_val = row.get("title") or row.get("file_name") or row.get("origin_url") or row.get("url") or ""
            url_val = row.get("url") or row.get("origin_url") or ""
            search_blob = " ".join(str(row.get(key, "")) for key, _ in columns if row.get(key))
            anchor_id = self._make_anchor(record_type, row)
            html.append(
                f"<div class=\"card\" id=\"{anchor_id}\" data-type=\"{record_type}\" data-search=\"{self._escape_html(search_blob)}\">"
            )
            if title_val:
                if url_val:
                    html.append(
                        f"<div class=\"card-title\"><a class=\"card-link\" href=\"{self._escape_html(url_val)}\" target=\"_blank\" rel=\"noopener\">{self._escape_html(title_val)}</a></div>"
                    )
                else:
                    html.append(f"<div class=\"card-title\">{self._escape_html(title_val)}</div>")
            if url_val:
                html.append(
                    f"<div class=\"card-url\"><a class=\"card-link\" href=\"{self._escape_html(url_val)}\" target=\"_blank\" rel=\"noopener\">{self._escape_html(url_val)}</a></div>"
                )
            html.append("<div class=\"card-meta\">\n" + "\n".join(
                f"<span><strong>{label}:</strong> {self._escape_html(row.get(key, ''))}</span>"
                for key, label in columns if row.get(key) not in (None, "")
            ) + "\n</div>")
            html.append("</div>")
        html.append("</div>")
        if len(rows) > limit:
            html.append(f"<div class=\"note\">Showing first {limit} of {len(rows)} items.</div>")
        html.append("</div>")
        return "\n".join(html)

    def _escape_html(self, text: Any) -> str:
        if text is None:
            return ""
        value = str(text)
        return (value
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace('"', "&quot;")
                .replace("'", "&#39;"))
