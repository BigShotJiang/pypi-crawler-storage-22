#!/usr/bin/env python3
"""
Documents extractor for iOS backups.

Extracts documents and files from iOS Files app and various app document directories.
Organizes exported files by type (PDFs, Documents, Spreadsheets, etc.).
"""

import sqlite3
import os
import shutil
import plistlib
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime
from .base import CategoryDataExtractor


class DocumentsExtractor(CategoryDataExtractor):
    """Extract and export documents from iOS backup."""

    # File type categories and their extensions
    FILE_CATEGORIES = {
        'PDFs': ['.pdf'],
        'Text Documents': ['.txt', '.rtf', '.doc', '.docx', '.odt', '.pages'],
        'Spreadsheets': ['.xls', '.xlsx', '.csv', '.numbers', '.ods'],
        'Presentations': ['.ppt', '.pptx', '.key', '.odp'],
        'Archives': ['.zip', '.rar', '.7z', '.tar', '.gz', '.bz2'],
        'Code': ['.py', '.js', '.java', '.cpp', '.c', '.h', '.swift', '.kt', '.go', '.rs', '.php', '.html', '.css', '.sql'],
        'E-Books': ['.epub', '.mobi', '.azw', '.azw3'],
        'Other Documents': []  # Catch-all for other file types
    }

    def _escape_html(self, text: str) -> str:
        if text is None:
            return ''
        return (str(text)
                .replace('&', '&amp;')
                .replace('<', '&lt;')
                .replace('>', '&gt;')
                .replace('"', '&quot;')
                .replace("'", '&#39;'))

    def __init__(self, backup_path: str):
        super().__init__(backup_path)

        # Domains where documents might be stored
        self.document_domains = [
            'AppDomain-com.apple.DocumentsApp',
            'AppDomain-group.com.apple.FileProvider.LocalStorage',
            'AppDomainGroup-group.com.apple.FileProvider.LocalStorage',
            'AppDomain-com.apple.CloudDocs',
            'AppDomainGroup-group.com.apple.CloudDocs',
            'HomeDomain',  # User documents
            'CloudDocsDomain'  # iCloud Drive (if synced)
        ]

        # Scan for documents
        self.documents = self._scan_documents()

        if not self.documents:
            raise FileNotFoundError("No documents found in backup")

    def _scan_documents(self) -> List[Dict[str, Any]]:
        """
        Scan backup manifest for document files.

        Returns:
            List of document file info dictionaries
        """
        conn = sqlite3.connect(self.manifest_db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        documents = []

        # Build file extension pattern for SQL query
        # Include common document extensions
        all_extensions = []
        for category_exts in self.FILE_CATEGORIES.values():
            all_extensions.extend(category_exts)

        # Query for document files
        # We'll look for:
        # 1. Files in document-related domains
        # 2. Files with document extensions anywhere
        # 3. Files in common document paths

        conditions = []
        params = []

        # Condition 1: Document domains
        domain_conditions = ' OR '.join(['domain LIKE ?' for _ in self.document_domains])
        conditions.append(f"({domain_conditions})")
        for domain in self.document_domains:
            params.append(f"%{domain}%")

        # Condition 2: Document paths
        document_paths = [
            '%/Documents/%',
            '%/Downloads/%',
            '%/Files/%',
            '%/Inbox/%',
            'Documents/%',
            'Downloads/%',
            'Files/%',
            'Inbox/%',
            '%File Provider Storage/%',
            '%Library/Mobile Documents/com~apple~CloudDocs/%'
        ]
        path_conditions = ' OR '.join(['relativePath LIKE ?' for _ in document_paths])
        conditions.append(f"({path_conditions})")
        params.extend(document_paths)

        # Combine all conditions
        where_clause = ' OR '.join(conditions)

        query = f"""
        SELECT
            fileID,
            domain,
            relativePath,
            flags,
            file
        FROM Files
        WHERE ({where_clause})
            AND relativePath NOT LIKE ''
            AND relativePath NOT LIKE '%/'
            AND file IS NOT NULL
        ORDER BY domain, relativePath
        """

        cur.execute(query, params)
        rows = cur.fetchall()

        for row in rows:
            file_id = row['fileID']
            domain = row['domain']
            relative_path = row['relativePath']

            # Skip directories and system files
            if not relative_path or relative_path.endswith('/'):
                continue

            # Get file extension
            _, ext = os.path.splitext(relative_path)
            ext = ext.lower()

            # Check if this is a document file
            if not self._is_document_file(relative_path, ext):
                continue

            # Get physical path (decrypt if needed)
            physical_path = self._resolve_file_id_path(file_id, row['file'])
            missing_payload = False
            file_size = 0
            if not physical_path or not os.path.exists(physical_path):
                missing_payload = True
            else:
                file_size = os.path.getsize(physical_path)
                if file_size == 0:
                    missing_payload = True

            file_name = os.path.basename(relative_path)

            # Determine category
            category = self._get_file_category(ext)

            # Get source app/location from domain
            source = self._get_source_from_domain(domain, relative_path)

            timestamp_iso, raw_ts, raw_format = self._extract_file_timestamp(row['file'])

            documents.append({
                'file_id': file_id,
                'file_name': file_name,
                'relative_path': relative_path,
                'physical_path': physical_path,
                'domain': domain,
                'extension': ext,
                'category': category,
                'source': source,
                'file_size': file_size,
                'user_generated': self._is_user_generated_document(domain, relative_path, ext),
                'missing_payload': missing_payload,
                'timestamp_iso': timestamp_iso,
                'raw_timestamp': raw_ts,
                'raw_format': raw_format
            })

        conn.close()

        print(f"Found {len(documents)} document files in backup")
        return documents

    def _is_document_file(self, path: str, ext: str) -> bool:
        """
        Check if a file is a document.

        Args:
            path: Relative path
            ext: File extension

        Returns:
            True if document file
        """
        media_exts = {
            '.jpg', '.jpeg', '.png', '.gif', '.heic',
            '.mp4', '.mov', '.m4a', '.mp3', '.wav', '.m4b'
        }

        # Skip certain non-document files
        skip_patterns = [
            '.db', '.sqlite', '.plist', '.log', '.tmp', '.cache',
            '.DS_Store', '.localized', 'Thumbs.db',
        ]

        # Check if extension is in skip list
        if ext in skip_patterns:
            return False

        if ext in media_exts:
            return self._is_files_app_path(path)

        # Check if path contains skip patterns
        skip_path_patterns = [
            '/Caches/',
            '/tmp/',
            '/Library/Preferences/',
            '/Library/Cookies/',
            '/.Trash/',
            '/Logs/'
        ]

        path_lower = path.lower()
        for pattern in skip_path_patterns:
            if pattern.lower() in path_lower:
                return False

        # If extension is in our known categories, it's a document
        for category_exts in self.FILE_CATEGORIES.values():
            if ext in category_exts:
                return True

        # Check for common document paths
        document_indicators = [
            '/Documents/', '/Downloads/', '/Files/', '/Inbox/',
            'Documents/', 'Downloads/', 'Files/', 'Inbox/',
            'File Provider Storage/', 'Library/Mobile Documents/com~apple~CloudDocs/'
        ]
        for indicator in document_indicators:
            if indicator in path:
                # Additional check: file must have an extension
                if ext:
                    return True

        return False

    def _is_files_app_path(self, path: str) -> bool:
        path_lower = path.lower()
        markers = [
            'file provider storage/',
            '/documents/',
            '/downloads/',
            '/files/',
            '/inbox/',
            'documents/',
            'downloads/',
            'files/',
            'inbox/',
            'library/mobile documents/com~apple~clouddocs/'
        ]
        return any(marker in path_lower for marker in markers)

    def _is_user_generated_document(self, domain: str, path: str, ext: str) -> bool:
        domain_lower = (domain or '').lower()
        path_lower = (path or '').lower()
        ext = (ext or '').lower()

        non_user_exts = {
            '.db', '.sqlite', '.sqlite3', '.plist', '.log', '.tmp', '.cache',
            '.js', '.sql', '.vers'
        }

        if ext in non_user_exts:
            return False

        if any(token in domain_lower for token in ('documentsapp', 'fileprovider', 'clouddocs', 'icloud')):
            return True

        if 'homedomain' in domain_lower:
            markers = [
                '/documents/', '/downloads/', '/files/', '/inbox/',
                'documents/', 'downloads/', 'files/', 'inbox/',
                'library/mobile documents/com~apple~clouddocs/'
            ]
            return any(marker in path_lower for marker in markers)

        if 'appdomain' in domain_lower:
            markers = [
                '/documents/', '/downloads/', '/files/', '/inbox/',
                'documents/', 'downloads/', 'files/', 'inbox/'
            ]
            if not any(marker in path_lower for marker in markers):
                return False

            inbox_markers = (
                '/documents/inbox/', '/downloads/', '/documents/downloads/',
                'documents/inbox/', 'downloads/', 'documents/downloads/'
            )
            if any(marker in path_lower for marker in inbox_markers):
                return True

            user_doc_exts = {
                '.pdf', '.rtf', '.doc', '.docx', '.odt', '.pages',
                '.xls', '.xlsx', '.csv', '.numbers', '.ods',
                '.ppt', '.pptx', '.key', '.odp',
                '.zip', '.rar', '.7z', '.tar', '.gz', '.bz2',
                '.epub', '.mobi', '.azw', '.azw3',
                '.jpg', '.jpeg', '.png', '.gif', '.heic'
            }
            return ext in user_doc_exts

        return False

    def _extract_file_timestamp(self, file_bplist: Optional[bytes]) -> Tuple[Optional[str], Optional[float], Optional[str]]:
        if not file_bplist:
            return None, None, None

        try:
            plist = plistlib.loads(file_bplist)
        except Exception:
            return None, None, None

        if not isinstance(plist, dict):
            return None, None, None

        for key in ('LastModified', 'Birth', 'Created', 'CreationDate', 'Modified', 'LastAccessed'):
            if key not in plist:
                continue
            val = plist.get(key)
            if isinstance(val, datetime):
                return val.isoformat(), val.timestamp(), 'plist_datetime'
            if isinstance(val, (int, float)):
                if val > 1000000000:
                    try:
                        return datetime.fromtimestamp(val).isoformat(), float(val), 'unix_seconds'
                    except Exception:
                        continue
                if val > 0:
                    try:
                        apple_epoch = datetime(2001, 1, 1).timestamp()
                        unix_ts = apple_epoch + float(val)
                        return datetime.fromtimestamp(unix_ts).isoformat(), float(val), 'apple_epoch_seconds'
                    except Exception:
                        continue

        return None, None, None

    def _get_file_category(self, ext: str) -> str:
        """
        Get category for file extension.

        Args:
            ext: File extension (with dot)

        Returns:
            Category name
        """
        for category, extensions in self.FILE_CATEGORIES.items():
            if ext in extensions:
                return category

        return 'Other Documents'

    def _get_source_from_domain(self, domain: str, path: str) -> str:
        """
        Determine source app/location from domain and path.

        Args:
            domain: iOS domain
            path: Relative path

        Returns:
            Source description
        """
        if 'DocumentsApp' in domain:
            return 'Files App'
        elif 'FileProvider' in domain:
            return 'Files App (Local Storage)'
        elif 'CloudDocs' in domain or 'iCloud' in domain:
            return 'iCloud Drive'
        elif 'HomeDomain' in domain:
            if 'Library/Mobile Documents/com~apple~CloudDocs/' in path:
                return 'iCloud Drive'
            if '/Downloads/' in path or 'Downloads/' in path:
                return 'Downloads'
            elif '/Documents/' in path or 'Documents/' in path:
                return 'Documents'
            return 'iOS System'
        elif 'AppDomain-' in domain:
            # Extract app bundle ID from domain
            parts = domain.replace('AppDomain-', '').split('.')
            if len(parts) >= 2:
                app_key = parts[-1]
                if app_key.lower() == 'ios' and len(parts) >= 3:
                    app_key = parts[-2]
                return f"{app_key.title()} App"
            return 'Third-Party App'
        else:
            return 'Unknown'

    def get_count(self) -> int:
        """Get total number of documents."""
        return len(self.documents)

    def get_items(self, limit: Optional[int] = None, offset: int = 0,
                  search: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get documents with pagination and optional search.

        Args:
            limit: Maximum number of items to return (None = all)
            offset: Number of items to skip
            search: Optional search query string

        Returns:
            List of document dictionaries
        """
        # Filter by search if provided
        items = self.documents
        if search:
            search_lower = search.lower()
            items = [
                doc for doc in items
                if search_lower in doc['file_name'].lower()
                or search_lower in doc['category'].lower()
                or search_lower in doc['source'].lower()
            ]

        # Apply pagination
        if offset > 0:
            items = items[offset:]
        if limit is not None:
            items = items[:limit]

        return items

    def get_item_summary(self, item: Dict[str, Any]) -> str:
        """Get summary string for document item."""
        size_kb = item['file_size'] / 1024
        return f"{item['file_name']} ({size_kb:.1f} KB) - {item['category']}"

    def export(self, items: List[Dict[str, Any]], output_path: str,
               format: str = 'default', progress_callback=None, timeline_emitter=None) -> bool:
        """
        Export documents to organized directory structure.

        Creates subdirectories for each file type category:
        - PDFs/
        - Text Documents/
        - Spreadsheets/
        - etc.

        Also creates Documents.html index file.

        Args:
            items: List of documents to export (from get_items)
            output_path: Output directory path
            format: Export format ('default' for organized by type)
            progress_callback: Optional callback(current, total, item_name) -> bool

        Returns:
            True if export succeeded, False otherwise
        """
        try:
            self._reset_export_bytes()
            os.makedirs(output_path, exist_ok=True)

            # Track exported files by category
            exported_by_category = {}
            for category in self.FILE_CATEGORIES.keys():
                exported_by_category[category] = []

            total = len(items)

            # Export each document
            for i, doc in enumerate(items, 1):
                # Report progress
                if progress_callback:
                    if not progress_callback(i, total, f"Exporting: {doc['file_name']}"):
                        return False
                category = doc['category']
                source_path = doc['physical_path']
                file_name = doc['file_name']

                # Create category subdirectory
                category_dir = os.path.join(output_path, category)
                os.makedirs(category_dir, exist_ok=True)

                # Destination path
                dest_path = os.path.join(category_dir, file_name)

                # Handle duplicate filenames
                base, ext = os.path.splitext(file_name)
                counter = 1
                while os.path.exists(dest_path):
                    file_name = f"{base}_{counter}{ext}"
                    dest_path = os.path.join(category_dir, file_name)
                    counter += 1

                if doc.get('missing_payload'):
                    exported_by_category[category].append({
                        'file_id': doc.get('file_id', ''),
                        'file_name': file_name,
                        'original_name': doc['file_name'],
                        'source': doc['source'],
                        'file_size': doc['file_size'],
                        'relative_path': None,
                        'user_generated': doc.get('user_generated', False),
                        'missing_payload': True
                    })
                    continue

                # Copy file
                try:
                    shutil.copy2(source_path, dest_path)
                    self._add_export_bytes(doc.get('file_size'))
                    doc['export_relative_path'] = os.path.join(category, file_name)
                    exported_by_category[category].append({
                        'file_id': doc.get('file_id', ''),
                        'file_name': file_name,
                        'original_name': doc['file_name'],
                        'source': doc['source'],
                        'file_size': doc['file_size'],
                        'relative_path': os.path.join(category, file_name),
                        'user_generated': doc.get('user_generated', False),
                        'missing_payload': False
                    })
                    print(f"Exported: {file_name} -> {category}/")
                except Exception as e:
                    print(f"Warning: Could not export {doc['file_name']}: {e}")
                    continue

            # Create index HTML
            self._create_documents_index(output_path, exported_by_category)
            self._add_export_bytes(os.path.join(output_path, 'Documents.html'))

            if timeline_emitter is not None:
                self._emit_timeline_events(items, timeline_emitter)

            print(f"\nExported {sum(len(files) for files in exported_by_category.values())} documents")
            return True

        except Exception as e:
            print(f"Error exporting documents: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _create_documents_index(self, output_path: str, exported_by_category: Dict[str, List[Dict]]):
        """Create Documents.html index file."""
        index_file = os.path.join(output_path, 'Documents.html')

        total_docs = sum(len(files) for files in exported_by_category.values())
        all_files = []
        for category, files in exported_by_category.items():
            for file_info in files:
                file_info['category'] = category
                all_files.append(file_info)

        sources = sorted({f.get('source', 'Unknown') for f in all_files})
        categories = sorted({f.get('category', 'Other Documents') for f in all_files})

        source_counts = {}
        for file_info in all_files:
            source_counts[file_info.get('source', 'Unknown')] = source_counts.get(file_info.get('source', 'Unknown'), 0) + 1

        priority_sources = [
            'Files App',
            'Files App (Local Storage)',
            'iCloud Drive',
            'Downloads',
            'Documents',
            'Photos',
            'Camera',
            'Safari',
            'Chrome App',
            'Gmail App',
            'Outlook App',
            'Messages',
            'SMS'
        ]
        priority_rank = {name.lower(): idx for idx, name in enumerate(priority_sources)}
        sources = sorted(
            sources,
            key=lambda name: (priority_rank.get(name.lower(), len(priority_sources)), name.lower())
        )

        top_sources = sorted(source_counts.items(), key=lambda item: item[1], reverse=True)[:10]
        top_source_names = {name for name, _ in top_sources}

        source_groups: Dict[str, Dict[str, List[Dict]]] = {src: {} for src in sources}
        for file_info in all_files:
            src = file_info.get('source', 'Unknown')
            cat = file_info.get('category', 'Other Documents')
            source_groups.setdefault(src, {})
            source_groups[src].setdefault(cat, []).append(file_info)

        html_parts = [f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Documents</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: #f6f6f6;
            padding: 20px;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            overflow: hidden;
        }}
        .header {{
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            color: white;
            padding: 30px;
            text-align: left;
        }}
        .header h1 {{
            font-size: 32px;
            font-weight: 600;
            margin-bottom: 10px;
        }}
        .header p {{
            font-size: 16px;
            opacity: 0.9;
        }}
        .breadcrumbs {{
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            letter-spacing: 0.2px;
            color: rgba(255,255,255,0.85);
            margin-bottom: 10px;
        }}
        .breadcrumbs a {{
            color: #fff;
            text-decoration: none;
            font-weight: 600;
        }}
        .breadcrumbs a:hover {{
            text-decoration: underline;
        }}
        .breadcrumbs .back-arrow {{
            opacity: 0.6;
        }}
        .embedded .breadcrumbs {{
            display: none;
        }}
        .search-box {{
            position: relative;
            padding: 20px;
            border-bottom: 1px solid #e5e5e5;
        }}
        .search-box input {{
            width: 100%;
            padding: 12px 46px 12px 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
        }}
        .search-box input:focus {{
            outline: none;
            border-color: #4facfe;
        }}
        .clear-search {{
            position: absolute;
            right: 24px;
            top: 50%;
            transform: translateY(-50%);
            border: 1px solid #d1d5db;
            background: #f3f4f6;
            color: #111827;
            border-radius: 6px;
            padding: 4px 8px;
            font-size: 12px;
            cursor: pointer;
            display: none;
        }}
        .clear-search.visible {{ display: inline-block; }}
        .filters {{
            padding: 16px 20px;
            border-bottom: 1px solid #e5e5e5;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }}
        .filter-group {{
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            align-items: center;
        }}
        .filter-label {{
            font-size: 13px;
            font-weight: 600;
            color: #555;
            min-width: 70px;
        }}
        .filter-chips {{
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }}
        .filter-chip {{
            border: 1px solid #d1d5db;
            background: white;
            color: #374151;
            padding: 6px 10px;
            border-radius: 999px;
            font-size: 12px;
            cursor: pointer;
        }}
        .filter-chip.active {{
            background: #4facfe;
            border-color: #4facfe;
            color: white;
        }}
        .filter-toggle {{
            font-size: 13px;
            color: #555;
            display: flex;
            gap: 8px;
            align-items: center;
        }}
        .filter-actions {{
            display: flex;
            gap: 10px;
            align-items: center;
        }}
        .filter-reset {{
            border: 1px solid #d1d5db;
            background: white;
            color: #374151;
            padding: 6px 12px;
            border-radius: 8px;
            font-size: 12px;
            cursor: pointer;
        }}
        .filter-more {{
            border: 1px dashed #9ca3af;
            background: white;
            color: #374151;
            padding: 6px 10px;
            border-radius: 999px;
            font-size: 12px;
            cursor: pointer;
        }}
        .filter-panel {{
            border: 1px solid #e5e5e5;
            border-radius: 10px;
            padding: 12px;
            background: #f9fafb;
            display: none;
            flex-direction: column;
            gap: 10px;
        }}
        .filter-panel.visible {{
            display: flex;
        }}
        .filter-panel input {{
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            font-size: 13px;
        }}
        .filter-panel-list {{
            max-height: 180px;
            overflow: auto;
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }}
        .source-group {{
            border-bottom: 1px solid #e5e5e5;
        }}
        .source-header {{
            padding: 20px;
            background: #f3f6fb;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}
        .source-header:hover {{
            background: #e9eff9;
        }}
        .source-title {{
            font-size: 18px;
            font-weight: 600;
            color: #1f2937;
        }}
        .source-count {{
            background: #3b82f6;
            color: white;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 13px;
            font-weight: 600;
        }}
        .source-body.collapsed {{
            display: none;
        }}
        .category {{
            border-bottom: 1px solid #e5e5e5;
            margin-left: 14px;
            border-left: 3px solid #e5e7eb;
        }}
        .category:last-child {{
            border-bottom: none;
        }}
        .category-header {{
            padding: 20px 20px 20px 24px;
            background: #f9f9f9;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}
        .category-header:hover {{
            background: #f0f0f0;
        }}
        .category-title {{
            font-size: 18px;
            font-weight: 600;
            color: #333;
        }}
        .category-count {{
            background: #4facfe;
            color: white;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 600;
        }}
        .file-list {{
            padding: 0 0 0 12px;
        }}
        .file-list.collapsed {{
            display: none;
        }}
        .file-item {{
            padding: 15px 20px;
            border-bottom: 1px solid #f0f0f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}
        .file-item:last-child {{
            border-bottom: none;
        }}
        .file-item.hidden {{
            display: none;
        }}
        .file-info {{
            flex: 1;
        }}
        .file-name {{
            font-size: 14px;
            color: #333;
            margin-bottom: 4px;
        }}
        .file-name a {{
            color: #4facfe;
            text-decoration: none;
        }}
        .file-name a:hover {{
            text-decoration: underline;
        }}
        .file-name .missing {{
            color: #9ca3af;
            font-style: italic;
        }}
        .file-meta {{
            font-size: 12px;
            color: #999;
        }}
        .file-size {{
            font-size: 12px;
            color: #666;
            padding: 4px 8px;
            background: #f0f0f0;
            border-radius: 4px;
        }}
        .no-results {{
            text-align: center;
            padding: 40px;
            color: #999;
            display: none;
        }}
        .no-results.visible {{
            display: block;
        }}
        .export-info {{
            text-align: center;
            padding: 20px;
            color: #999;
            font-size: 14px;
            border-top: 1px solid #e5e5e5;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Start_Here.html">Back</a></div>
            <h1>Documents & Files</h1>
            <p>Extracted from iOS Backup on {datetime.now().strftime("%B %d, %Y")}</p>
        </div>

        <div class="search-box">
            <input type="text" id="searchInput" placeholder="Search documents..." onkeyup="filterDocuments()">
            <button id="clearSearch" class="clear-search" title="Clear" aria-label="Clear search">X</button>
        </div>

        <div class="filters">
            <div class="filter-group">
                <div class="filter-label">Source</div>
                <div class="filter-chips" id="sourceFilters">
                    <button class="filter-chip active" data-filter-type="source" data-filter-value="all">All</button>
''']

        for source in [name for name, _ in top_sources]:
            html_parts.append(
                f'                    <button class="filter-chip" data-filter-type="source" data-filter-value="{self._escape_html(source.lower())}">{self._escape_html(source)}</button>\n'
            )

        html_parts.append(
            '                    <button class="filter-more" id="sourceMoreToggle">More sources…</button>\n'
        )

        html_parts.append('''                </div>
                <div id="sourcePanel" class="filter-panel">
                    <input type="text" id="sourceSearch" placeholder="Search sources...">
                    <div class="filter-panel-list" id="sourcePanelList">
''')

        for source in sources:
            if source in top_source_names:
                continue
            html_parts.append(
                f'                        <button class="filter-chip" data-filter-type="source" data-filter-value="{self._escape_html(source.lower())}">{self._escape_html(source)}</button>\n'
            )

        html_parts.append('''                    </div>
                </div>
            </div>
            <div class="filter-group">
                <div class="filter-label">Type</div>
                <div class="filter-chips" id="typeFilters">
                    <button class="filter-chip active" data-filter-type="type" data-filter-value="all">All</button>
''')

        for category in categories:
            html_parts.append(
                f'                    <button class="filter-chip" data-filter-type="type" data-filter-value="{self._escape_html(category.lower())}">{self._escape_html(category)}</button>\n'
            )

        html_parts.append('''                </div>
            </div>
            <div class="filter-group">
                <label class="filter-toggle">
                    <input type="checkbox" id="userOnly" checked>
                    User files only
                </label>
                <label class="filter-toggle">
                    <input type="checkbox" id="availableOnly" checked>
                    Show available only
                </label>
                <div class="filter-actions">
                    <button class="filter-reset" id="resetFilters">Reset filters</button>
                </div>
            </div>
        </div>

        <div id="categoryContainer">
''')

        for source, categories_map in source_groups.items():
            source_files = sum(len(files) for files in categories_map.values())
            if not source_files:
                continue

            is_priority_source = source.lower() in priority_rank
            source_body_class = 'source-body' if is_priority_source else 'source-body collapsed'
            html_parts.append(f'''        <div class="source-group" data-source-group="{self._escape_html(source.lower())}">
            <div class="source-header" onclick="toggleSource(this)">
                <div class="source-title">{self._escape_html(source)}</div>
                <div class="source-count">{source_files}</div>
            </div>
            <div class="{source_body_class}">
''')

            for category, files in categories_map.items():
                if not files:
                    continue

                html_parts.append(f'''            <div class="category" data-category-group="{self._escape_html(category.lower())}">
                <div class="category-header" onclick="toggleCategory(this)">
                    <div class="category-title">{self._escape_html(category)}</div>
                    <div class="category-count">{len(files)}</div>
                </div>
                <div class="file-list">
''')

                for file_info in files:
                    size_mb = file_info['file_size'] / (1024 * 1024)
                    if file_info.get('missing_payload'):
                        size_str = "Not downloaded"
                    elif size_mb < 1:
                        size_str = f"{file_info['file_size'] / 1024:.1f} KB"
                    else:
                        size_str = f"{size_mb:.2f} MB"

                    if file_info.get('relative_path'):
                        file_link = f'<a href="{file_info["relative_path"]}">{file_info["file_name"]}</a>'
                    else:
                        file_link = f'<span class="missing">{file_info["file_name"]} (not downloaded)</span>'

                    html_parts.append(f'''                    <div class="file-item" id="doc-{file_info['file_id']}" data-name="{file_info['file_name'].lower()}" data-source="{file_info['source'].lower()}" data-category="{file_info['category'].lower()}" data-available="{str(not file_info.get('missing_payload')).lower()}" data-user="{str(file_info.get('user_generated', False)).lower()}">
                        <div class="file-info">
                            <div class="file-name">
                                {file_link}
                            </div>
                            <div class="file-meta">Source: {self._escape_html(file_info['source'])}</div>
                        </div>
                        <div class="file-size">{size_str}</div>
                    </div>
''')

                html_parts.append('''                </div>
            </div>
''')

            html_parts.append('''            </div>
        </div>
''')

        html_parts.append(f'''
        </div>

        <div class="no-results" id="noResults">No documents found matching your search</div>

        <div class="export-info">
            Total documents: {total_docs} | Organized by file type
        </div>
    </div>

    <script>
        function toggleCategory(header) {{
            const fileList = header.nextElementSibling;
            fileList.classList.toggle('collapsed');
        }}

        function toggleSource(header) {{
            const body = header.nextElementSibling;
            body.classList.toggle('collapsed');
        }}

        function setActiveFilter(type, value) {{
            const chips = document.querySelectorAll(`.filter-chip[data-filter-type="${{type}}"]`);
            chips.forEach(chip => {{
                chip.classList.toggle('active', chip.dataset.filterValue === value);
            }});
        }}

        function getActiveFilter(type) {{
            const active = document.querySelector(`.filter-chip[data-filter-type="${{type}}"].active`);
            return active ? active.dataset.filterValue : 'all';
        }}

        function isUserGeneratedFile(source, name) {{
            const src = (source || '').toLowerCase();
            const filename = (name || '').toLowerCase();
            const ext = filename.includes('.') ? filename.substring(filename.lastIndexOf('.')) : '';

            const nonUserExts = new Set(['.db', '.sqlite', '.sqlite3', '.plist', '.log', '.tmp', '.cache', '.js', '.sql', '.vers']);
            if (nonUserExts.has(ext)) return false;

            if (src.includes('files app') || src.includes('icloud drive') || src.includes('downloads') || src.includes('documents')) {{
                return true;
            }}

            if (src.includes('app')) {{
                const userDocExts = new Set([
                    '.pdf', '.rtf', '.doc', '.docx', '.odt', '.pages',
                    '.xls', '.xlsx', '.csv', '.numbers', '.ods',
                    '.ppt', '.pptx', '.key', '.odp',
                    '.zip', '.rar', '.7z', '.tar', '.gz', '.bz2',
                    '.epub', '.mobi', '.azw', '.azw3',
                    '.jpg', '.jpeg', '.png', '.gif', '.heic'
                ]);
                return userDocExts.has(ext);
            }}

            return false;
        }}

        function refreshUserFlags() {{
            document.querySelectorAll('.file-item').forEach(item => {{
                const name = item.getAttribute('data-name') || '';
                const source = item.getAttribute('data-source') || '';
                const current = item.getAttribute('data-user');
                if (current === null || current === 'false') {{
                    const isUser = isUserGeneratedFile(source, name);
                    item.setAttribute('data-user', isUser ? 'true' : 'false');
                }}
            }});
        }}

        function filterDocuments() {{
            const input = document.getElementById('searchInput');
            const filter = input.value.toLowerCase();
            const noResults = document.getElementById('noResults');
            const userOnly = document.getElementById('userOnly');
            const availableOnly = document.getElementById('availableOnly');
            const activeSource = getActiveFilter('source');
            const activeType = getActiveFilter('type');

            let hasVisibleItems = false;

            document.querySelectorAll('.source-group').forEach(sourceGroup => {{
                let sourceHasVisible = false;
                sourceGroup.querySelectorAll('.category').forEach(category => {{
                    let categoryHasVisible = false;
                    category.querySelectorAll('.file-item').forEach(item => {{
                        const name = item.getAttribute('data-name') || '';
                        const source = item.getAttribute('data-source') || '';
                        const categoryName = item.getAttribute('data-category') || '';
                        const available = item.getAttribute('data-available') === 'true';
                        const isUser = item.getAttribute('data-user') === 'true';

                        let matches = true;
                        if (filter && !(name.includes(filter) || source.includes(filter))) {{
                            matches = false;
                        }}
                        if (activeSource !== 'all' && source !== activeSource) {{
                            matches = false;
                        }}
                        if (activeType !== 'all' && categoryName !== activeType) {{
                            matches = false;
                        }}
                        if (userOnly && userOnly.checked && !isUser) {{
                            matches = false;
                        }}
                        if (availableOnly && availableOnly.checked && !available) {{
                            matches = false;
                        }}

                        if (matches) {{
                            item.classList.remove('hidden');
                            categoryHasVisible = true;
                            sourceHasVisible = true;
                            hasVisibleItems = true;
                        }} else {{
                            item.classList.add('hidden');
                        }}
                    }});
                    category.style.display = categoryHasVisible ? 'block' : 'none';
                }});
                sourceGroup.style.display = sourceHasVisible ? 'block' : 'none';
            }});

            if (!hasVisibleItems) {{
                noResults.classList.add('visible');
            }} else {{
                noResults.classList.remove('visible');
            }}
        }}

        document.querySelectorAll('.filter-chip').forEach(chip => {{
            chip.addEventListener('click', () => {{
                setActiveFilter(chip.dataset.filterType, chip.dataset.filterValue);
                filterDocuments();
            }});
        }});

        const sourceMoreToggle = document.getElementById('sourceMoreToggle');
        const sourcePanel = document.getElementById('sourcePanel');
        if (sourceMoreToggle && sourcePanel) {{
            sourceMoreToggle.addEventListener('click', () => {{
                sourcePanel.classList.toggle('visible');
            }});
        }}

        const sourceSearch = document.getElementById('sourceSearch');
        if (sourceSearch) {{
            sourceSearch.addEventListener('input', () => {{
                const query = sourceSearch.value.toLowerCase();
                document.querySelectorAll('#sourcePanelList .filter-chip').forEach(chip => {{
                    const label = (chip.textContent || '').toLowerCase();
                    chip.style.display = label.includes(query) ? '' : 'none';
                }});
            }});
        }}

        const userOnly = document.getElementById('userOnly');
        if (userOnly) {{
            userOnly.addEventListener('change', filterDocuments);
        }}

        const availableOnly = document.getElementById('availableOnly');
        if (availableOnly) {{
            availableOnly.addEventListener('change', filterDocuments);
        }}

        const resetFilters = document.getElementById('resetFilters');
        if (resetFilters) {{
            resetFilters.addEventListener('click', () => {{
                setActiveFilter('source', 'all');
                setActiveFilter('type', 'all');
                const input = document.getElementById('searchInput');
                if (input) input.value = '';
                if (availableOnly) availableOnly.checked = true;
                if (userOnly) userOnly.checked = true;
                filterDocuments();
            }});
        }}

        function applyTimelineParams() {{
            const params = new URLSearchParams(window.location.search);
            if (!params || params.toString().length === 0) return;
            const input = document.getElementById('searchInput');
            const query = params.get('q');
            if (input && query !== null) {{
                input.value = query;
            }}
            if (userOnly && params.get('userOnly') === '0') {{
                userOnly.checked = false;
            }}
            if (availableOnly && params.get('availableOnly') === '0') {{
                availableOnly.checked = false;
            }}
            if (params.get('expand') === '1') {{
                document.querySelectorAll('.source-body.collapsed').forEach(el => el.classList.remove('collapsed'));
                document.querySelectorAll('.file-list.collapsed').forEach(el => el.classList.remove('collapsed'));
            }}
        }}

        applyTimelineParams();
        refreshUserFlags();
        filterDocuments();
    </script>
    <script>
        const docSearchInput = document.getElementById('searchInput');
        const docClearBtn = document.getElementById('clearSearch');
        if (docSearchInput && docClearBtn) {{
            const toggleClear = () => docClearBtn.classList.toggle('visible', !!docSearchInput.value);
            docSearchInput.addEventListener('input', toggleClear);
            docClearBtn.addEventListener('click', () => {{
                docSearchInput.value = '';
                toggleClear();
                if (typeof filterDocuments === 'function') {{
                    filterDocuments();
                }}
                docSearchInput.focus();
            }});
            toggleClear();
        }}
    </script>
    <script>
        document.addEventListener('click', (event) => {{
            const link = event.target.closest('a');
            if (!link || !link.href) return;
            try {{
                if (window.parent && window.parent !== window) {{
                    window.parent.postMessage({{type: 'device-nav', href: link.href}}, '*');
                }}
            }} catch (err) {{}}
        }});
    </script>
    <script>
        (function() {{
            try {{
                if (window.parent && window.parent !== window) {{
                    window.parent.postMessage({{type: 'device-nav-root', href: window.location.href}}, '*');
                    window.parent.postMessage({{type: 'device-nav', href: window.location.href}}, '*');
                }}
            }} catch (err) {{}}
        }})();
    </script>
    <script>
        if (window.self !== window.top) {{
            document.body.classList.add('embedded');
        }}
    </script>
</body>
</html>''')

        html = ''.join(html_parts)

        # Write index file
        with open(index_file, 'w', encoding='utf-8') as f:
            f.write(html)

        print(f"Created Documents index: {index_file}")

    def _emit_timeline_events(self, items: List[Dict[str, Any]], timeline_emitter) -> None:
        for doc in items:
            ts_iso = doc.get('timestamp_iso')
            if not ts_iso:
                physical_path = doc.get('physical_path')
                if physical_path and os.path.exists(physical_path):
                    try:
                        mtime = os.path.getmtime(physical_path)
                        ts_iso = datetime.fromtimestamp(mtime).isoformat()
                        doc['raw_timestamp'] = mtime
                        doc['raw_format'] = 'file_mtime'
                    except Exception:
                        ts_iso = None
            if not ts_iso:
                continue
            details = {
                'filename': doc.get('file_name') or '',
                'category': doc.get('category') or '',
                'source': doc.get('source') or '',
                'relative_path': doc.get('relative_path') or '',
                'size_bytes': doc.get('file_size') or 0,
            }
            export_rel = doc.get('export_relative_path')
            if export_rel:
                details['preview_path'] = f"../Documents/{export_rel.replace(os.sep, '/')}"
            raw_path = ''
            if doc.get('domain') and doc.get('relative_path'):
                raw_path = f"{doc['domain']}/{doc['relative_path']}"
            timeline_emitter.emit({
                'timestamp': ts_iso,
                'raw_timestamp': doc.get('raw_timestamp'),
                'raw_format': doc.get('raw_format'),
                'source_app': doc.get('source') or 'Documents',
                'source_category': 'Documents',
                'event_type': 'document_file',
                'title': doc.get('file_name') or 'Document',
                'details': details,
                'confidence': 'low',
                'raw_source_path': raw_path,
                'report_anchor': f"doc-{doc.get('file_id')}",
                'link_hint': 'Documents/Documents.html',
            })
