#!/usr/bin/env python3
"""
Maps search history extractor for iOS backups.

Scans Maps-related databases for recent/search/history entries and exports
simple HTML/JSON reports.
"""

import os
import sqlite3
import plistlib
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from .base import CategoryDataExtractor


class MapsSearchExtractor(CategoryDataExtractor):
    """Extract Maps search/history entries from iOS backup databases."""

    _APPLE_EPOCH = datetime(2001, 1, 1)

    def __init__(self, backup_path: str):
        super().__init__(backup_path)
        self._db_sources = self._find_maps_databases()
        self._plist_sources = self._find_maps_plists()
        if not self._db_sources:
            if not self._plist_sources:
                raise FileNotFoundError("Maps search/history data not found in backup")
        self._cached_items: Optional[List[Dict[str, Any]]] = None

    def _find_maps_databases(self) -> List[Dict[str, str]]:
        sources = []
        manifest_path = self.manifest_db_path
        if not os.path.exists(manifest_path):
            return sources

        try:
            conn = sqlite3.connect(f"file:{manifest_path}?mode=ro", uri=True)
            cur = conn.cursor()
            cur.execute("""
                SELECT fileID, domain, relativePath
                FROM Files
                WHERE (
                    (
                        (
                            domain LIKE 'AppDomain-com.apple.Maps%'
                            OR domain LIKE 'AppDomainGroup-group.com.apple.Maps%'
                            OR domain LIKE 'AppDomainPlugin-com.apple.Maps%'
                        )
                        AND (
                            relativePath LIKE '%Maps%'
                            OR relativePath LIKE '%GeoHistory%'
                            OR relativePath LIKE '%Search%'
                            OR relativePath LIKE '%History%'
                        )
                    ) OR (
                        domain = 'HomeDomain'
                        AND (
                            relativePath LIKE '%Maps%'
                            OR relativePath LIKE '%GeoHistory%'
                        )
                    )
                )
                AND (relativePath LIKE '%.db' OR relativePath LIKE '%.sqlite')
                AND relativePath NOT LIKE '%-wal'
                AND relativePath NOT LIKE '%-shm'
            """)
            rows = cur.fetchall()
            conn.close()
        except Exception:
            return sources

        seen = set()
        for file_id, domain, relpath in rows:
            key = (domain, relpath)
            if key in seen:
                continue
            seen.add(key)
            db_path = self._resolve_file_id_path(file_id)
            if not db_path or not os.path.exists(db_path):
                continue
            sources.append({
                "domain": domain,
                "relative_path": relpath,
                "path": db_path,
            })

        return sources

    def _find_maps_plists(self) -> List[Dict[str, str]]:
        sources = []
        manifest_path = self.manifest_db_path
        if not os.path.exists(manifest_path):
            return sources

        candidates = [
            ("AppDomain-com.apple.Maps", "Library/Maps/GeoHistory.mapsdata"),
            ("AppDomain-com.apple.Maps", "Library/Maps/Pins.mapsdata"),
            ("AppDomain-com.apple.Maps", "Library/Maps/RoutingAppLaunches.mapsdata"),
        ]
        for domain, relpath in candidates:
            path = self.backup_access.get_file_path(domain, relpath)
            if path and os.path.exists(path):
                sources.append({
                    "domain": domain,
                    "relative_path": relpath,
                    "path": path,
                })

        return sources

    def _normalize_timestamp(self, value: Any) -> Optional[int]:
        try:
            ts = float(value)
        except Exception:
            return None
        if ts <= 0:
            return None
        if ts > 1e12:
            return int(ts / 1000)
        if ts > 1e10:
            return int(ts)
        if ts > 1e6:
            return int((self._APPLE_EPOCH + timedelta(seconds=ts)).timestamp())
        return None

    def _pick_columns(self, columns: List[str]) -> Dict[str, Optional[str]]:
        def find_any(candidates):
            for col in columns:
                lower = col.lower()
                for token in candidates:
                    if token in lower:
                        return col
            return None

        return {
            "name": find_any(["name", "title", "label", "display"]),
            "query": find_any(["query", "search", "term"]),
            "address": find_any(["address", "street", "formatted"]),
            "lat": find_any(["latitude", "lat"]),
            "lon": find_any(["longitude", "lon", "lng"]),
            "timestamp": find_any(["timestamp", "date", "time", "created", "modified", "last"]),
        }

    def _load_items(self) -> List[Dict[str, Any]]:
        if self._cached_items is not None:
            return self._cached_items

        items: List[Dict[str, Any]] = []
        for source in self._db_sources:
            db_path = source["path"]
            try:
                conn = sqlite3.connect(db_path)
                conn.row_factory = sqlite3.Row
                cur = conn.cursor()
                cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
                tables = [row[0] for row in cur.fetchall()]
            except Exception:
                continue

            for table in tables:
                table_lower = table.lower()
                if not any(token in table_lower for token in ("history", "search", "recent", "query", "route", "place")):
                    continue
                try:
                    cur.execute(f"PRAGMA table_info({table})")
                    columns = [row[1] for row in cur.fetchall()]
                except Exception:
                    continue

                if not columns:
                    continue

                picks = self._pick_columns(columns)
                if not any(picks.values()):
                    continue
                if not (picks["name"] or picks["query"] or picks["address"]):
                    continue

                select_cols = ["rowid"]
                for col in picks.values():
                    if col and col not in select_cols:
                        select_cols.append(col)

                where_parts = []
                if picks["query"]:
                    where_parts.append(f"{picks['query']} IS NOT NULL")
                if picks["name"]:
                    where_parts.append(f"{picks['name']} IS NOT NULL")
                if picks["address"]:
                    where_parts.append(f"{picks['address']} IS NOT NULL")
                where_clause = " OR ".join(where_parts) if where_parts else "1=1"
                order_col = picks["timestamp"] or "rowid"

                query = f"""
                    SELECT {", ".join(select_cols)}
                    FROM {table}
                    WHERE {where_clause}
                    ORDER BY {order_col} DESC
                    LIMIT 500
                """

                try:
                    cur.execute(query)
                    rows = cur.fetchall()
                except Exception:
                    continue

                for row in rows:
                    def get_val(col_name):
                        if not col_name:
                            return None
                        try:
                            val = row[col_name]
                        except Exception:
                            return None
                        if isinstance(val, bytes):
                            try:
                                return val.decode("utf-8", errors="ignore")
                            except Exception:
                                return None
                        return val

                    label = get_val(picks["query"]) or get_val(picks["name"]) or ""
                    address = get_val(picks["address"]) or ""
                    lat = get_val(picks["lat"])
                    lon = get_val(picks["lon"])
                    ts_raw = get_val(picks["timestamp"])
                    ts = self._normalize_timestamp(ts_raw)

                    items.append({
                        "label": str(label) if label is not None else "",
                        "address": str(address) if address is not None else "",
                        "latitude": lat,
                        "longitude": lon,
                        "timestamp": ts,
                        "source_db": source["relative_path"],
                        "source_table": table,
                    })

            conn.close()

        for source in self._plist_sources:
            relpath = source["relative_path"]
            try:
                with open(source["path"], "rb") as f:
                    plist = plistlib.load(f)
            except Exception:
                continue

            if relpath.endswith("GeoHistory.mapsdata") and isinstance(plist, dict):
                history = plist.get("MSPHistory")
                if isinstance(history, list):
                    for entry in history:
                        if not isinstance(entry, dict):
                            continue
                        label = (
                            entry.get("MSPHistoryItemTitle")
                            or entry.get("title")
                            or entry.get("name")
                            or entry.get("query")
                            or ""
                        )
                        address = (
                            entry.get("MSPHistoryItemSubtitle")
                            or entry.get("address")
                            or ""
                        )
                        ts = self._normalize_timestamp(
                            entry.get("date")
                            or entry.get("timestamp")
                            or entry.get("last_used")
                        )
                        items.append({
                            "label": str(label),
                            "address": str(address),
                            "latitude": entry.get("latitude"),
                            "longitude": entry.get("longitude"),
                            "timestamp": ts,
                            "source_db": relpath,
                            "source_table": "MSPHistory",
                        })

        items.sort(key=lambda x: x.get("timestamp") or 0, reverse=True)
        self._cached_items = items
        return items

    def get_count(self) -> int:
        return len(self._load_items())

    def get_items(self, limit: Optional[int] = None, offset: int = 0,
                  search: Optional[str] = None) -> List[Dict[str, Any]]:
        items = self._load_items()
        if search:
            term = search.lower()
            items = [
                item for item in items
                if term in (item.get("label") or "").lower()
                or term in (item.get("address") or "").lower()
            ]
        if limit:
            return items[offset:offset + limit]
        return items[offset:]

    def export(self, items: List[Dict[str, Any]], output_path: str,
               format: str = "html", progress_callback=None, timeline_emitter=None) -> bool:
        if format != "html":
            raise ValueError(f"Unsupported export format: {format}")

        try:
            self._reset_export_bytes()
            os.makedirs(output_path, exist_ok=True)

            if progress_callback:
                if not progress_callback(0, len(items), "Preparing Maps report..."):
                    return False

            html_path = os.path.join(output_path, "Maps_Search_History.html")
            json_path = os.path.join(output_path, "Maps_Search_History.json")

            with open(json_path, "w", encoding="utf-8") as f:
                import json
                json.dump(items, f, indent=2, ensure_ascii=False)
            self._add_export_bytes(json_path)

            rows = []
            for idx, item in enumerate(items, start=1):
                if progress_callback:
                    if not progress_callback(idx, len(items), item.get("label") or "Maps entry"):
                        return False

                ts = item.get("timestamp")
                ts_str = datetime.fromtimestamp(ts).isoformat() if ts else ""
                rows.append(
                    "<tr>"
                    f"<td>{self._escape_html(item.get('label') or '')}</td>"
                    f"<td>{self._escape_html(item.get('address') or '')}</td>"
                    f"<td>{self._escape_html(str(item.get('latitude') or ''))}</td>"
                    f"<td>{self._escape_html(str(item.get('longitude') or ''))}</td>"
                    f"<td>{self._escape_html(ts_str)}</td>"
                    f"<td>{self._escape_html(item.get('source_table') or '')}</td>"
                    "</tr>"
                )

                if timeline_emitter is not None and ts:
                    timeline_emitter.emit({
                        "timestamp": datetime.fromtimestamp(ts).isoformat(),
                        "raw_timestamp": ts,
                        "raw_format": "unix_seconds",
                        "source_app": "Maps",
                        "source_category": "Maps Search History",
                        "event_type": "maps_search",
                        "title": item.get("label") or "Maps Search",
                        "details": {
                            "address": item.get("address"),
                            "latitude": item.get("latitude"),
                            "longitude": item.get("longitude"),
                            "source_table": item.get("source_table"),
                        },
                        "confidence": "medium",
                        "raw_source_path": item.get("source_db") or "",
                        "report_anchor": "",
                        "link_hint": "Maps Search History/Maps_Search_History.html",
                    })

            html = """<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Maps Search History</title>
  <style>
    body { font-family: Arial, sans-serif; background: #f5f5f5; padding: 20px; }
    .container { background: #fff; border-radius: 8px; padding: 20px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { text-align: left; padding: 8px; border-bottom: 1px solid #e5e5e5; }
    th { background: #fafafa; }
  </style>
</head>
<body>
  <div class="container">
    <h1>Maps Search History</h1>
    <p>Total entries: """ + str(len(items)) + """</p>
    <table>
      <thead>
        <tr>
          <th>Label</th><th>Address</th><th>Latitude</th><th>Longitude</th><th>Timestamp</th><th>Table</th>
        </tr>
      </thead>
      <tbody>
        """ + "\n".join(rows) + """
      </tbody>
    </table>
  </div>
</body>
</html>
"""
            with open(html_path, "w", encoding="utf-8") as f:
                f.write(html)
            self._add_export_bytes(html_path)

            return True
        except Exception as e:
            print(f"Error exporting Maps search history: {e}")
            return False

    def get_item_summary(self, item: Dict[str, Any]) -> str:
        label = item.get("label") or "Maps entry"
        return label

    @staticmethod
    def _escape_html(text: str) -> str:
        if not text:
            return ""
        text = str(text)
        return (text.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;"))
