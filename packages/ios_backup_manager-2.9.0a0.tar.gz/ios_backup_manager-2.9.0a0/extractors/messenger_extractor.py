#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Facebook Messenger extractor for iOS backups - Integration wrapper.

This extractor wraps the third_party MessengerExtractor and provides
compatibility with the iOS Backup Manager extraction framework.
"""

import os
import re
import html
import sys
import sqlite3
from typing import List, Dict, Any, Optional
from datetime import datetime

from .base import CategoryDataExtractor


class MessengerExtractor(CategoryDataExtractor):
    """
    Extract Facebook Messenger conversations from iOS backups.

    Finds Messenger Lightspeed database in backup and exports conversations
    to HTML format (similar to WhatsApp and SMS).
    """

    # Messenger app domains (multiple patterns for different iOS/app versions)
    MESSENGER_DOMAINS = [
        "AppDomainGroup-group.com.facebook.Orca",      # Older Messenger
        "AppDomainGroup-group.com.facebook.Facebook",  # Newer Messenger/FB integrated
    ]

    def __init__(self, backup_path: str):
        """
        Initialize Messenger extractor.

        Args:
            backup_path: Path to iOS backup directory

        Raises:
            FileNotFoundError: If Messenger database not found in backup
        """
        super().__init__(backup_path)

        # Find Messenger database in backup (try multiple patterns)
        self.messenger_db_path = self._find_messenger_db()

        if not self.messenger_db_path:
            raise FileNotFoundError("Facebook Messenger database not found in backup")

    def _find_messenger_db(self) -> Optional[str]:
        """
        Find Facebook Messenger database.

        Tries multiple patterns as Facebook has changed database structure over versions:
        1. lightspeed-raw.db in Orca domain (older)
        2. fb-msys-*.db in Facebook domain (newer)
        3. lightspeed-shareextension-*.db in extensions (fallback)
        """
        # Pattern 1: Try old Messenger-specific domain with lightspeed-raw.db
        db_path = self.find_file_in_backup(
            "AppDomainGroup-group.com.facebook.Orca",
            "lightspeed-raw.db"
        )
        if db_path:
            return db_path

        # Pattern 2: Try newer Facebook integrated database (fb-msys-*.db)
        # This requires querying the manifest for files matching the pattern
        manifest_path = self.manifest_db_path
        if not os.path.exists(manifest_path):
            return None

        try:
            conn = sqlite3.connect(f"file:{manifest_path}?mode=ro", uri=True)
            cur = conn.cursor()

            # Search for fb-msys database in Facebook domain
            cur.execute("""
                SELECT fileID, relativePath
                FROM Files
                WHERE domain = 'AppDomainGroup-group.com.facebook.Facebook'
                AND relativePath LIKE '%fb-msys%.db'
                ORDER BY relativePath DESC
                LIMIT 1
            """)

            row = cur.fetchone()
            if row:
                file_id, rel_path = row
                physical_path = self._resolve_file_id_path(file_id)
                if physical_path and os.path.exists(physical_path):
                    # Verify it has the expected schema
                    if self._verify_messenger_schema(physical_path):
                        conn.close()
                        return physical_path

            # Pattern 3: Try ShareExtension as fallback (lightspeed-shareextension-*.db)
            cur.execute("""
                SELECT fileID, relativePath
                FROM Files
                WHERE domain = 'AppDomainPlugin-com.facebook.Messenger.ShareExtension'
                AND relativePath LIKE '%lightspeed%.db'
                ORDER BY relativePath DESC
                LIMIT 1
            """)

            row = cur.fetchone()
            if row:
                file_id, rel_path = row
                physical_path = self._resolve_file_id_path(file_id)
                if physical_path and os.path.exists(physical_path):
                    if self._verify_messenger_schema(physical_path):
                        conn.close()
                        return physical_path

            conn.close()

        except Exception as e:
            print(f"Error finding Messenger database: {e}")

        return None

    def _verify_messenger_schema(self, db_path: str) -> bool:
        """
        Verify that a database has the expected Messenger schema.

        Args:
            db_path: Path to database file

        Returns:
            True if database has threads and messages tables with required columns
        """
        try:
            conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
            cur = conn.cursor()

            # Check for required tables
            cur.execute("""
                SELECT name FROM sqlite_master
                WHERE type='table' AND name IN ('threads', 'messages')
            """)
            tables = [row[0] for row in cur.fetchall()]

            if 'threads' not in tables or 'messages' not in tables:
                conn.close()
                return False

            # Check for required columns in threads
            cur.execute("PRAGMA table_info(threads)")
            thread_cols = [row[1] for row in cur.fetchall()]
            required_thread_cols = ['thread_key', 'thread_name', 'thread_type']
            if not all(col in thread_cols for col in required_thread_cols):
                conn.close()
                return False

            # Check for required columns in messages
            cur.execute("PRAGMA table_info(messages)")
            msg_cols = [row[1] for row in cur.fetchall()]
            required_msg_cols = ['thread_key', 'message_id', 'timestamp_ms']
            if not all(col in msg_cols for col in required_msg_cols):
                conn.close()
                return False

            conn.close()
            return True

        except Exception:
            return False

    def get_count(self) -> int:
        """Get total number of conversation threads."""
        try:
            conn = sqlite3.connect(f"file:{self.messenger_db_path}?mode=ro", uri=True)
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) FROM threads")
            count = cur.fetchone()[0]
            conn.close()
            return count
        except Exception:
            return 0

    def get_item_summary(self, item: Dict[str, Any]) -> str:
        """Get a short summary string for displaying in list view."""
        thread_name = item.get('thread_name', 'Unknown')
        message_count = item.get('message_count', 0)
        return f"{thread_name} - {message_count} messages"

    def get_items(self, limit: Optional[int] = None, offset: int = 0, search: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get list of conversations with metadata.

        Args:
            limit: Maximum number of conversations to return
            offset: Number of conversations to skip
            search: Search filter (searches thread names)

        Returns:
            List of conversation dicts with thread_key, thread_name, last_activity, message_count
        """
        try:
            conn = sqlite3.connect(f"file:{self.messenger_db_path}?mode=ro", uri=True)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()

            # Build query
            query = """
                SELECT
                    t.thread_key,
                    t.thread_name,
                    t.thread_type,
                    t.last_activity_timestamp_ms,
                    t.snippet,
                    t.thread_picture_url,
                    t.thread_picture_url_fallback,
                    (SELECT COUNT(*) FROM messages m WHERE m.thread_key = t.thread_key) as message_count,
                    (SELECT COUNT(*) FROM participants p WHERE p.thread_key = t.thread_key) as participant_count
                FROM threads t
                WHERE 1=1
            """

            params = []
            if search:
                query += " AND (t.thread_name LIKE ? OR t.snippet LIKE ?)"
                search_pattern = f"%{search}%"
                params.extend([search_pattern, search_pattern])

            query += " ORDER BY t.last_activity_timestamp_ms DESC"

            if limit is not None:
                query += f" LIMIT {limit} OFFSET {offset}"

            cur.execute(query, params)
            rows = cur.fetchall()

            conversations = []
            for row in rows:
                # Format last activity timestamp
                last_activity = None
                if row['last_activity_timestamp_ms']:
                    try:
                        last_activity = datetime.fromtimestamp(row['last_activity_timestamp_ms'] / 1000.0)
                    except Exception:
                        pass

                # Determine conversation name
                thread_name = row['thread_name']
                if not thread_name:
                    # Try to get participant names
                    cur.execute("""
                        SELECT p.contact_id, c.name, c.first_name, c.last_name
                        FROM participants p
                        LEFT JOIN contacts c ON p.contact_id = c.id
                        WHERE p.thread_key = ?
                        LIMIT 3
                    """, (row['thread_key'],))
                    participants = cur.fetchall()

                    names = []
                    for p in participants:
                        if p['name']:
                            names.append(p['name'])
                        elif p['first_name'] or p['last_name']:
                            names.append(f"{p['first_name'] or ''} {p['last_name'] or ''}".strip())
                        else:
                            names.append(f"User {p['contact_id']}")

                    if names:
                        thread_name = ", ".join(names)
                        if len(participants) > 3:
                            thread_name += " + others"
                    else:
                        thread_name = f"Thread {row['thread_key']}"

                conversations.append({
                    'thread_key': row['thread_key'],
                    'thread_name': thread_name,
                    'thread_type': row['thread_type'],
                    'last_activity': last_activity,
                    'snippet': row['snippet'],
                    'message_count': row['message_count'],
                    'participant_count': row['participant_count'],
                    'thread_picture_url': row['thread_picture_url'],
                    'thread_picture_url_fallback': row['thread_picture_url_fallback']
                })

            conn.close()
            return conversations

        except Exception as e:
            print(f"Error getting Messenger conversations: {e}")
            return []

    def export(self, items: List[Dict[str, Any]], output_path: str, format: str = 'html', progress_callback=None, timeline_emitter=None) -> bool:
        """
        Export Messenger conversations to HTML files.

        Creates:
        - Messenger.html: Index of all conversations
        - Conversations/: Individual conversation HTML files

        Args:
            items: List of conversations from get_items()
            output_path: Output directory path
            format: Export format ('html')
            progress_callback: Optional callback(current, total, item_name) -> bool

        Returns:
            True if export succeeded
        """
        if format not in ('html', 'files'):
            raise ValueError(f"Unsupported export format: {format}")

        self._reset_export_bytes()
        # Create output structure
        os.makedirs(output_path, exist_ok=True)
        conversations_dir = os.path.join(output_path, "Conversations")
        os.makedirs(conversations_dir, exist_ok=True)

        # Import the core messenger extractor
        from third_party.messenger_extractor import MessengerExtractor as CoreMessengerExtractor

        # Create core extractor instance and extract ALL messages once
        core_extractor = CoreMessengerExtractor(self.messenger_db_path)

        # Extract all messages and group by conversation_id
        all_messages_by_conv = {}
        for msg in core_extractor.iter_messages():
            conv_id = msg['conversation_id']
            if conv_id not in all_messages_by_conv:
                all_messages_by_conv[conv_id] = []
            all_messages_by_conv[conv_id].append(msg)

        # Export each conversation
        total = len(items)
        conversation_files = []

        for idx, conversation in enumerate(items):
            thread_key = conversation['thread_key']
            thread_name = conversation['thread_name']

            # Progress callback
            if progress_callback:
                if not progress_callback(idx + 1, total, thread_name):
                    return False  # Cancelled

            # Generate safe filename
            safe_name = self._sanitize_filename(thread_name)
            html_filename = f"{thread_key}_{safe_name}.html"
            html_path = os.path.join(conversations_dir, html_filename)

            # Get messages for this conversation from the pre-grouped dict
            messages = all_messages_by_conv.get(str(thread_key), [])

            if not messages:
                continue

            # Generate conversation HTML with thread metadata
            self._generate_conversation_html(
                html_path,
                conversation,
                messages
            )

            if timeline_emitter is not None:
                self._emit_message_timeline_events(messages, conversation, html_filename, timeline_emitter)

            conversation_files.append({
                'thread_key': thread_key,
                'thread_name': thread_name,
                'message_count': len(messages),
                'filename': html_filename
            })

        # Generate index HTML
        index_path = os.path.join(output_path, "Messenger.html")
        self._generate_index_html(index_path, conversation_files)

        return True

    def _generate_conversation_html(self, output_path: str, conversation: Dict[str, Any], messages: List[Dict[str, Any]]):
        """Generate HTML file for a single conversation."""
        conversation_name = conversation.get('thread_name', 'Unknown')
        thread_picture = conversation.get('thread_picture_url') or conversation.get('thread_picture_url_fallback')
        participant_count = conversation.get('participant_count', 0)
        thread_type = conversation.get('thread_type', 1)

        # Determine if group chat (type 17 = group, type 15 = marketplace group, etc.)
        is_group = thread_type in [15, 17, 18, 19, 20]

        html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{self._escape_html(conversation_name)} - Facebook Messenger</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: #f6f6f6;
            padding: 20px;
        }}
        .container {{
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            overflow: hidden;
        }}
        .header {{
            background: linear-gradient(135deg, #0074FD 0%, #01C5FF 100%);
            color: white;
            padding: 30px;
            display: flex;
            align-items: center;
            gap: 15px;
        }}
        .breadcrumbs {{
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            letter-spacing: 0.2px;
            color: rgba(255,255,255,0.85);
            margin-bottom: 8px;
        }}
        .breadcrumbs a {{
            color: #fff;
            text-decoration: none;
            font-weight: 600;
        }}
        .breadcrumbs a:hover {{ text-decoration: underline; }}
        .breadcrumbs .back-arrow {{ opacity: 0.6; }}
        .embedded .breadcrumbs {{ display: none; }}
        .thread-picture {{
            width: 60px;
            height: 60px;
            border-radius: 50%;
            object-fit: cover;
            flex-shrink: 0;
        }}
        .header-content {{
            flex: 1;
        }}
        .thread-title {{
            margin: 0;
            font-size: 24px;
            color: white;
            font-weight: 600;
        }}
        .thread-info {{
            margin: 5px 0 0 0;
            font-size: 14px;
            color: rgba(255, 255, 255, 0.9);
        }}
        .thread-badge {{
            display: inline-block;
            background: #e4e6eb;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 12px;
            margin-right: 8px;
        }}
        .conversation {{
            background: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }}
        .message {{
            margin: 15px 0;
            display: flex;
            flex-direction: column;
        }}
        .highlight-target {{
            background-color: #fff3cd;
            outline: 2px solid #f59e0b;
        }}
        .highlight-target .message-bubble {{
            background-color: #fff3cd;
            color: #111827;
        }}
        .search-hit {{
            background: #ffec99;
            border-radius: 3px;
            padding: 0 1px;
        }}
        .search-hit-block {{
            background: #fff7d6;
            border: 2px solid #f59e0b;
            border-radius: 12px;
            padding: 4px;
        }}
        .message.outgoing {{
            align-items: flex-end;
        }}
        .message.incoming {{
            align-items: flex-start;
        }}
        .message-bubble {{
            max-width: 70%;
            padding: 10px 15px;
            border-radius: 18px;
            word-wrap: break-word;
        }}
        .message.outgoing .message-bubble {{
            background: #0074FD;
            color: white;
        }}
        .message.incoming .message-bubble {{
            background: #e4e6eb;
            color: #050505;
        }}
        .message-meta {{
            font-size: 11px;
            color: #65676b;
            margin-top: 4px;
        }}
        .sender-name {{
            font-weight: 600;
            margin-bottom: 4px;
            font-size: 12px;
            color: #65676b;
        }}
        .attachment {{
            margin-top: 8px;
            max-width: 100%;
        }}
        .attachment img {{
            max-width: 100%;
            border-radius: 8px;
            display: block;
        }}
        .attachment-link {{
            display: inline-block;
            margin-top: 4px;
            padding: 8px 12px;
            background: rgba(0,0,0,0.05);
            border-radius: 8px;
            text-decoration: none;
            color: #0074FD;
            font-size: 13px;
        }}
        .attachment-link:hover {{
            background: rgba(0,0,0,0.1);
        }}
        .attachment-error {{
            display: none;
            padding: 12px;
            background: #fff3cd;
            border: 1px solid #ffc107;
            border-radius: 8px;
            color: #856404;
            font-size: 13px;
            margin-top: 4px;
        }}
        .attachment-error::before {{
            content: '⚠️ ';
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">"""

        # Add thread picture if available
        if thread_picture:
            html += f"""
        <img src="{self._escape_html(thread_picture)}" alt="Thread picture" class="thread-picture" onerror="this.style.display='none'">"""

        html += f"""
        <div class="header-content">
            <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Messenger.html">Back to conversations</a></div>
            <h1 class="thread-title">{self._escape_html(conversation_name)}</h1>
            <div class="thread-info">"""

        # Add thread type badge
        if is_group:
            html += f"""
                <span class="thread-badge">👥 Group Chat</span>"""
        else:
            html += f"""
                <span class="thread-badge">💬 Direct Message</span>"""

        # Add participant count for groups
        if is_group and participant_count > 0:
            html += f"""
                <span class="thread-badge">{participant_count} members</span>"""

        # Add message count
        html += f"""
                <span class="thread-badge">{len(messages)} messages</span>
            </div>
        </div>
    </div>
    <div class="conversation">
"""

        for msg in messages:
            direction_class = "outgoing" if msg['direction'] == "outgoing" else "incoming"
            sender = msg.get('sender_display_name', 'Unknown')
            timestamp = msg['timestamp'].strftime("%b %d, %Y at %I:%M %p")
            text = self._escape_html(msg.get('text', '[No text]'))
            attachments = msg.get('attachments', [])

            html += f"""
        <div class="message {direction_class}" id="msg-{msg.get('message_id')}">
"""
            if msg['direction'] == "incoming":
                html += f"""
            <div class="sender-name">{self._escape_html(sender)}</div>
"""
            html += f"""
            <div class="message-bubble">
                {text}
"""
            # Render attachments
            if attachments:
                for att in attachments:
                    att_type = att.get('type', 0)
                    preview_url = att.get('preview_url')
                    playable_url = att.get('playable_url')
                    filename = att.get('filename', 'Attachment')

                    # Type 2 = Image
                    if att_type == 2 and (preview_url or playable_url):
                        img_url = preview_url or playable_url
                        html += f"""
                <div class="attachment">
                    <img src="{self._escape_html(img_url)}" alt="{self._escape_html(filename)}" loading="lazy" onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">
                    <div class="attachment-error">Image unavailable - URL expired ({self._escape_html(filename)})</div>
                </div>
"""
                    # Other types with URL - show as link
                    elif preview_url or playable_url:
                        link_url = playable_url or preview_url
                        html += f"""
                <div class="attachment">
                    <a href="{self._escape_html(link_url)}" target="_blank" class="attachment-link">
                        📎 {self._escape_html(filename or 'View Attachment')}
                    </a>
                </div>
"""
                    # Attachment without URL - show placeholder
                    else:
                        att_type_names = {1: 'Sticker', 2: 'Image', 7: 'Shared Content', 8: 'Video'}
                        type_name = att_type_names.get(att_type, f'Type {att_type}')
                        html += f"""
                <div class="attachment">
                    <span class="attachment-link" style="cursor: default; opacity: 0.6;">
                        📎 {type_name} (unavailable)
                    </span>
                </div>
"""

            html += f"""
            </div>
            <div class="message-meta">{timestamp}</div>
        </div>
"""

        html += """
    </div>  <!-- Close conversation -->
    </div>  <!-- Close container -->
<script>
    (function() {
        if (!window.location.hash) return;
        const target = document.querySelector(window.location.hash);
        if (!target) return;
        target.classList.add('highlight-target');
        try {
            target.scrollIntoView({ block: 'center' });
        } catch (e) {
            target.scrollIntoView();
        }
    })();
</script>
<script>
    (function() {
        const params = new URLSearchParams(window.location.search);
        const term = (params.get('q') || localStorage.getItem('messengerLastSearch') || '').trim();
        if (!term) return;

        function escapeRegExp(value) {
            return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        }

        function highlightInElement(element, query) {
            const regex = new RegExp(escapeRegExp(query), 'gi');
            const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT, {
                acceptNode(node) {
                    if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
                    const parent = node.parentElement;
                    if (!parent) return NodeFilter.FILTER_REJECT;
                    if (parent.classList && parent.classList.contains('search-hit')) return NodeFilter.FILTER_REJECT;
                    return NodeFilter.FILTER_ACCEPT;
                }
            });
            const nodes = [];
            let node;
            while ((node = walker.nextNode())) {
                if (regex.test(node.nodeValue)) {
                    nodes.push(node);
                }
            }
            nodes.forEach(textNode => {
                const text = textNode.nodeValue;
                const frag = document.createDocumentFragment();
                const local = new RegExp(escapeRegExp(query), 'gi');
                let lastIndex = 0;
                let match;
                while ((match = local.exec(text)) !== null) {
                    const before = text.slice(lastIndex, match.index);
                    if (before) frag.appendChild(document.createTextNode(before));
                    const mark = document.createElement('mark');
                    mark.className = 'search-hit';
                    mark.textContent = match[0];
                    frag.appendChild(mark);
                    lastIndex = match.index + match[0].length;
                }
                const after = text.slice(lastIndex);
                if (after) frag.appendChild(document.createTextNode(after));
                textNode.parentNode.replaceChild(frag, textNode);
            });
        }

        const targets = document.querySelectorAll('.message-bubble');
        targets.forEach(el => highlightInElement(el, term));
        document.querySelectorAll('.search-hit').forEach(mark => {
            const block = mark.closest('.message');
            if (block) block.classList.add('search-hit-block');
        });

        function scrollToFirstHit() {
            const first = document.querySelector('.search-hit');
            if (!first) return;
            try {
                first.scrollIntoView({ block: 'center' });
            } catch (e) {
                first.scrollIntoView();
            }
            const block = first.closest('.message');
            if (!block) return;
            const imgs = block.querySelectorAll('img');
            if (!imgs.length) return;
            let pending = imgs.length;
            imgs.forEach(img => {
                if (img.complete) {
                    pending -= 1;
                    return;
                }
                img.addEventListener('load', () => {
                    pending -= 1;
                    if (pending <= 0) {
                        try {
                            first.scrollIntoView({ block: 'center' });
                        } catch (e) {
                            first.scrollIntoView();
                        }
                    }
                }, { once: true });
            });
        }

        scrollToFirstHit();
        requestAnimationFrame(() => {
            scrollToFirstHit();
            setTimeout(scrollToFirstHit, 250);
        });

    })();
</script>
<script>
(function() {
    try {
        if (window.parent && window.parent !== window) {
            window.parent.postMessage({type: 'device-nav', href: window.location.href}, '*');
        }
    } catch (err) {}
})();
</script>
</body>
</html>
"""

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html)
        self._add_export_bytes(output_path)

    def _emit_message_timeline_events(self, messages: List[Dict[str, Any]], conversation: Dict[str, Any],
                                      html_filename: str, timeline_emitter) -> None:
        link_hint = f"Messenger/Conversations/{html_filename}"
        conversation_name = conversation.get('thread_name') or conversation.get('display_name') or 'Messenger Conversation'
        for msg in messages:
            ts = msg.get('timestamp')
            if isinstance(ts, datetime):
                ts_iso = ts.isoformat()
            else:
                ts_iso = None
            if not ts_iso:
                continue
            text = msg.get('text') or ''
            details = {
                'conversation': conversation_name,
                'direction': msg.get('direction') or '',
                'text': text[:200] if text else '',
            }
            timeline_emitter.emit({
                'timestamp': ts_iso,
                'raw_timestamp': ts.isoformat() if isinstance(ts, datetime) else ts,
                'raw_format': 'datetime',
                'source_app': 'Messenger',
                'source_category': 'Messenger',
                'event_type': 'message',
                'title': conversation_name,
                'details': details,
                'confidence': 'high',
                'raw_source_path': self.messenger_db_path,
                'report_anchor': f"msg-{msg.get('message_id')}",
                'link_hint': link_hint,
            })
            attachments = msg.get('attachments', []) or []
            for att in attachments:
                att_type = att.get('type')
                filename = att.get('filename') or att.get('title') or att.get('name') or 'Attachment'
                mime_type = (att.get('mime_type') or '').lower()
                event_type = 'file_attachment'
                if att_type == 2:
                    event_type = 'photo_attachment'
                elif att_type == 8:
                    event_type = 'video_attachment'
                elif mime_type.startswith('image/'):
                    event_type = 'photo_attachment'
                elif mime_type.startswith('video/'):
                    event_type = 'video_attachment'
                elif mime_type.startswith('audio/'):
                    event_type = 'audio_attachment'
                elif '.' in filename:
                    ext = os.path.splitext(filename)[1].lower()
                    if ext in ('.jpg', '.jpeg', '.png', '.gif', '.heic', '.heif', '.bmp', '.tif', '.tiff', '.webp'):
                        event_type = 'photo_attachment'
                    elif ext in ('.mov', '.mp4', '.m4v', '.avi', '.mkv', '.3gp', '.3gpp'):
                        event_type = 'video_attachment'
                    elif ext in ('.m4a', '.aac', '.mp3', '.wav', '.aiff', '.amr', '.caf', '.flac', '.opus'):
                        event_type = 'audio_attachment'
                timeline_emitter.emit({
                    'timestamp': ts_iso,
                    'raw_timestamp': ts.isoformat() if isinstance(ts, datetime) else ts,
                    'raw_format': 'datetime',
                    'source_app': 'Messenger',
                    'source_category': 'Messenger',
                    'event_type': event_type,
                    'title': f"{conversation_name}: {filename}",
                    'details': {
                        'conversation': conversation_name,
                        'filename': filename,
                        'mime_type': att.get('mime_type'),
                        'attachment_type': att_type,
                        'url': att.get('url') or att.get('playable_url') or att.get('preview_url'),
                    },
                    'confidence': 'low' if event_type == 'file_attachment' else 'high',
                    'raw_source_path': att.get('url') or att.get('playable_url') or att.get('preview_url') or '',
                    'report_anchor': f"msg-{msg.get('message_id')}",
                    'link_hint': link_hint,
                })

    def _generate_index_html(self, output_path: str, conversations: List[Dict[str, Any]]):
        """Generate index HTML with list of all conversations."""
        search_text_by_file = {}
        for conv in conversations:
            search_text = ""
            try:
                convo_path = os.path.join(output_path, "Conversations", conv["filename"])
                if not os.path.exists(convo_path):
                    print(f"[Messenger] Missing conversation HTML: {convo_path}")
                    search_text_by_file[conv["filename"]] = ""
                    continue
                with open(convo_path, "r", encoding="utf-8", errors="ignore") as convo_f:
                    convo_html = convo_f.read()
                parts = re.findall(r'<div class="message-bubble">(.*?)</div>', convo_html, re.S)
                cleaned = []
                for part in parts:
                    text_only = re.sub(r"<[^>]+>", "", part)
                    text_only = html.unescape(text_only).strip()
                    if text_only:
                        cleaned.append(text_only)
                if cleaned:
                    search_text = " ".join(cleaned)[:4000].lower()
            except Exception:
                search_text = ""
            search_text_by_file[conv["filename"]] = search_text

        html = """<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Facebook Messenger Conversations</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: #f6f6f6;
            padding: 20px;
        }
        .container {
            max-width: 1000px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #0074FD 0%, #01C5FF 100%);
            color: white;
            padding: 30px;
            text-align: left;
        }
        .header h1 {
            margin: 0 0 10px 0;
            font-size: 32px;
            font-weight: 600;
        }
        .breadcrumbs {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            letter-spacing: 0.2px;
            color: rgba(255,255,255,0.85);
            margin-bottom: 10px;
        }
        .breadcrumbs a {
            color: #fff;
            text-decoration: none;
            font-weight: 600;
        }
        .breadcrumbs a:hover {
            text-decoration: underline;
        }
        .breadcrumbs .back-arrow {
            opacity: 0.6;
        }
        .embedded .breadcrumbs {
            display: none;
        }
        .header p {
            margin: 0;
            font-size: 16px;
            opacity: 0.9;
        }
        .search-box {
            padding: 20px;
            border-bottom: 1px solid #e5e5e5;
            position: relative;
        }
        .search-box input {
            width: 100%;
            padding: 12px 46px 12px 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            box-sizing: border-box;
        }
        .search-box input:focus {
            outline: none;
            border-color: #0074FD;
        }
        .clear-search {
            position: absolute;
            right: 24px;
            top: 50%;
            transform: translateY(-50%);
            border: 1px solid #d1d5db;
            background: #f3f4f6;
            color: #111827;
            border-radius: 6px;
            padding: 4px 8px;
            font-size: 12px;
            cursor: pointer;
            display: none;
        }
        .clear-search.visible { display: inline-block; }
        .no-results {
            display: none;
            text-align: center;
            padding: 40px;
            color: #999;
            font-size: 16px;
        }
        .conversations {
            background: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        .conversation-item {
            padding: 15px;
            border-bottom: 1px solid #e4e6eb;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .conversation-item:last-child {
            border-bottom: none;
        }
        .conversation-item:hover {
            background: #f7f7f7;
        }
        .conversation-name {
            font-weight: 600;
            color: #050505;
        }
        .conversation-count {
            color: #65676b;
            font-size: 14px;
        }
        a {
            text-decoration: none;
            color: inherit;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Start_Here.html">Back</a></div>
            <h1>Facebook Messenger</h1>
            <p>Extracted from iOS Backup on """ + datetime.now().strftime("%B %d, %Y") + """ - """ + str(len(conversations)) + """ conversations</p>
        </div>

        <div class="search-box">
            <input type="text" id="searchInput" placeholder="Search conversations..." onkeyup="filterConversations()">
            <button id="clearSearch" class="clear-search" title="Clear" aria-label="Clear search">X</button>
        </div>

        <div class="conversations" id="conversationList">
"""

        for conv in conversations:
            html += f"""
        <div class="conversation-item" data-name="{self._escape_html(conv['thread_name'].lower())}" data-search="{self._escape_html(search_text_by_file.get(conv['filename'], ''))}">
            <a href="Conversations/{conv['filename']}" style="flex: 1;">
                <div class="conversation-name">{self._escape_html(conv['thread_name'])}</div>
                <div class="conversation-count">{conv['message_count']} messages</div>
            </a>
        </div>
"""

        html += """
        </div>  <!-- Close conversations -->
        <div class="no-results" id="noResults">No conversations found</div>
    </div>  <!-- Close container -->

    <script>
        function filterConversations() {
            const input = document.getElementById('searchInput');
            const clearBtn = document.getElementById('clearSearch');
            const rawTerm = input.value.trim();
            const filter = rawTerm.toLowerCase();
            if (rawTerm) {
                localStorage.setItem('messengerLastSearch', rawTerm);
            } else {
                localStorage.removeItem('messengerLastSearch');
            }
            const conversations = document.querySelectorAll('.conversation-item');
            const noResults = document.getElementById('noResults');

            let visibleCount = 0;

            conversations.forEach(conv => {
                const name = conv.getAttribute('data-name') || '';
                const link = conv.tagName === 'A' ? conv : conv.querySelector('a');
                if (link) {
                    if (!link.dataset.baseHref) {
                        link.dataset.baseHref = link.getAttribute('href');
                    }
                    if (rawTerm) {
                        link.setAttribute('href', `${link.dataset.baseHref}?q=${encodeURIComponent(rawTerm)}`);
                    } else {
                        link.setAttribute('href', link.dataset.baseHref);
                    }
                }

                if (name.includes(filter)) {
                    conv.style.display = '';
                    visibleCount++;
                } else {
                    conv.style.display = 'none';
                }
            });

            // Show "no results" message if nothing is visible
            if (visibleCount === 0) {
                noResults.style.display = 'block';
            } else {
                noResults.style.display = 'none';
            }
            if (clearBtn) {
                clearBtn.classList.toggle('visible', !!rawTerm);
            }
        }

        function applyStoredSearch() {
            const input = document.getElementById('searchInput');
            if (!input) {
                return;
            }
            const saved = localStorage.getItem('messengerLastSearch') || '';
            if (saved) {
                input.value = saved;
                filterConversations();
            }
        }

        document.addEventListener('DOMContentLoaded', () => {
            applyStoredSearch();
            const clearBtn = document.getElementById('clearSearch');
            const input = document.getElementById('searchInput');
            if (clearBtn && input) {
                clearBtn.addEventListener('click', () => {
                    input.value = '';
                    localStorage.removeItem('messengerLastSearch');
                    filterConversations();
                    clearBtn.classList.remove('visible');
                    input.focus();
                });
            }
        });

        window.addEventListener('pageshow', () => {
            const input = document.getElementById('searchInput');
            if (input && input.value.trim()) {
                filterConversations();
            }
        });
    </script>
    <script>
        (function() {
            try {
                if (window.parent && window.parent !== window) {
                    window.parent.postMessage({type: 'device-nav-root', href: window.location.href}, '*');
                    window.parent.postMessage({type: 'device-nav', href: window.location.href}, '*');
                }
            } catch (err) {}
        })();
    </script>
    <script>
        if (window.self !== window.top) {
            document.body.classList.add('embedded');
        }
    </script>
</body>
</html>
"""

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html)
        self._add_export_bytes(output_path)

    def _sanitize_filename(self, name: str) -> str:
        """Sanitize name for use in filename."""
        # Remove invalid filename characters
        invalid_chars = '<>:"/\\|?*'
        for char in invalid_chars:
            name = name.replace(char, '_')
        # Limit length
        return name[:100]

    def _escape_html(self, text: str) -> str:
        """Escape HTML special characters."""
        if not text:
            return ''
        return (text
                .replace('&', '&amp;')
                .replace('<', '&lt;')
                .replace('>', '&gt;')
                .replace('"', '&quot;')
                .replace("'", '&#39;'))
