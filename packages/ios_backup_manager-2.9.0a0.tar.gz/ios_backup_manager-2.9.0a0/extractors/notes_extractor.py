#!/usr/bin/env python3
"""
Notes data extractor for iOS backups.

Extracts notes from notes.sqlite (iOS 9+) and exports to HTML format.
Handles embedded attachments and HTML formatting.
"""

import sqlite3
import os
import gzip
import base64
import hashlib
import shutil
import re
import secrets
from typing import List, Dict, Any, Optional
from Crypto.Cipher import AES
from Crypto.Protocol.KDF import PBKDF2
from Crypto.Hash import SHA256
from .base import CategoryDataExtractor


class NotesExtractor(CategoryDataExtractor):
    """Extract and export notes from iOS backup."""

    def __init__(self, backup_path: str):
        super().__init__(backup_path)

        # Modern NoteStore (iOS 9+ / iCloud Notes)
        self.modern_db_path = self.find_db_file(
            "AppDomainGroup-group.com.apple.notes",
            "NoteStore.sqlite"
        )

        # Legacy local/IMAP notes (on‑device / mail‑backed)
        self.legacy_db_path = self.find_db_file(
            "HomeDomain",
            "Library/Notes/notes.sqlite"
        )

        if not self.modern_db_path and not self.legacy_db_path:
            raise FileNotFoundError("Notes database not found in backup")

        # Optional report-level lock for Notes (disabled by default).
        self.enable_report_lock = os.environ.get("IBM_LOCK_NOTES_REPORT", "").strip() == "1"
        self._note_crypto_defaults = self._load_note_crypto_defaults()

    def _load_note_crypto_defaults(self) -> Dict[str, Any]:
        """
        Load global crypto defaults for locked notes (salt/iterations/verifier), if present.
        """
        defaults = {}
        if not self.modern_db_path:
            return defaults
        try:
            conn = sqlite3.connect(self.modern_db_path)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            cur.execute("PRAGMA table_info(ZICCLOUDSYNCINGOBJECT)")
            columns = {row[1] for row in cur.fetchall()}
            if not {"ZCRYPTOSALT", "ZCRYPTOITERATIONCOUNT"}.issubset(columns):
                conn.close()
                return defaults
            cur.execute("""
                SELECT ZCRYPTOITERATIONCOUNT, ZCRYPTOSALT, ZCRYPTOVERIFIER, ZCRYPTOPASSPHRASEVERIFIER
                FROM ZICCLOUDSYNCINGOBJECT
                WHERE ZCRYPTOVERIFIER IS NOT NULL OR ZCRYPTOPASSPHRASEVERIFIER IS NOT NULL
                LIMIT 1
            """)
            row = cur.fetchone()
            conn.close()
            if row:
                defaults["iterations"] = row["ZCRYPTOITERATIONCOUNT"]
                defaults["salt"] = row["ZCRYPTOSALT"]
                defaults["verifier"] = row["ZCRYPTOVERIFIER"] or row["ZCRYPTOPASSPHRASEVERIFIER"]
        except Exception:
            return defaults
        return defaults

    def get_count(self) -> int:
        """Get total number of notes."""
        total = 0

        # Modern NoteStore rows (count the rows that actually have note bodies)
        if self.modern_db_path:
            try:
                conn = sqlite3.connect(self.modern_db_path)
                cur = conn.cursor()
                cur.execute("SELECT COUNT(*) FROM ZICNOTEDATA")
                total += cur.fetchone()[0]
            except Exception:
                pass
            finally:
                try:
                    conn.close()
                except Exception:
                    pass

        # Legacy local/IMAP notes.sqlite
        if self.legacy_db_path:
            try:
                conn = sqlite3.connect(self.legacy_db_path)
                cur = conn.cursor()
                cur.execute("SELECT COUNT(*) FROM ZNOTE")
                total += cur.fetchone()[0]
            except Exception:
                pass
            finally:
                try:
                    conn.close()
                except Exception:
                    pass

        return total

    def get_items(self, limit: Optional[int] = None, offset: int = 0,
                  search: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get notes with pagination and optional search.

        Returns list of note dictionaries with fields:
        - note_id: Note ID
        - title: Note title
        - content: Note content (plain text or HTML)
        - folder: Folder name
        - account: Account name
        - created: Creation timestamp
        - modified: Modification timestamp
        - has_attachments: Boolean indicating if note has attachments
        """
        notes: List[Dict[str, Any]] = []

        if self.modern_db_path:
            notes.extend(self._load_modern_notes(search))

        if self.legacy_db_path:
            notes.extend(self._load_legacy_notes(search))

        # Sort newest first to match previous behaviour
        notes.sort(key=lambda n: n.get('modified') or 0, reverse=True)

        # Apply pagination after merging sources
        if offset:
            notes = notes[offset:]
        if limit is not None:
            notes = notes[:limit]

        return notes

    def _load_modern_notes(self, search: Optional[str]) -> List[Dict[str, Any]]:
        """Load notes from modern NoteStore.sqlite (AppGroup)."""
        conn = sqlite3.connect(self.modern_db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        # Determine deletion column (keep the flag but do not exclude so we can show deleted items)
        deletion_col = None
        try:
            cur.execute("SELECT ZDELETED FROM ZICCLOUDSYNCINGOBJECT LIMIT 0")
            deletion_col = "n.ZDELETED"
        except sqlite3.OperationalError:
            try:
                cur.execute("SELECT ZMARKEDFORDELETION FROM ZICCLOUDSYNCINGOBJECT LIMIT 0")
                deletion_col = "n.ZMARKEDFORDELETION"
            except sqlite3.OperationalError:
                deletion_col = None

        # Determine locked/protected and crypto columns if present
        locked_col = None
        try:
            cur.execute("PRAGMA table_info(ZICCLOUDSYNCINGOBJECT)")
            columns = {row[1] for row in cur.fetchall()}
            for candidate in ("ZISPASSWORDPROTECTED", "ZISLOCKED", "ZPASSWORDPROTECTED", "ZLOCKED"):
                if candidate in columns:
                    locked_col = f"n.{candidate}"
                    break
        except Exception:
            locked_col = None
            columns = set()

        data_columns = set()
        try:
            cur.execute("PRAGMA table_info(ZICNOTEDATA)")
            data_columns = {row[1] for row in cur.fetchall()}
        except Exception:
            data_columns = set()

        def crypto_expr(name: str) -> str:
            n_col = name in columns
            d_col = name in data_columns
            if n_col and d_col:
                return f"COALESCE(n.{name}, d.{name})"
            if n_col:
                return f"n.{name}"
            if d_col:
                return f"d.{name}"
            return "NULL"

        unapplied_col = None
        if "ZUNAPPLIEDENCRYPTEDRECORDDATA" in columns:
            unapplied_col = "n.ZUNAPPLIEDENCRYPTEDRECORDDATA"
        elif "ZUNAPPLIEDENCRYPTEDRECORD" in columns:
            unapplied_col = "n.ZUNAPPLIEDENCRYPTEDRECORD"

        has_folder = "ZFOLDER" in columns
        folder_select = "f.ZTITLE2" if has_folder else "NULL"
        folder_join = "LEFT JOIN ZICCLOUDSYNCINGOBJECT f ON n.ZFOLDER = f.Z_PK" if has_folder else ""

        query = """
            SELECT
                n.Z_PK            AS note_id,
                n.ZTITLE1         AS title,
                n.ZSNIPPET        AS snippet,
                n.ZCREATIONDATE   AS created,
                n.ZMODIFICATIONDATE1 AS modified,
                {folder_select}   AS folder,
                a.ZNAME           AS account,
                d.ZDATA           AS data_blob,
                {deletion_col}    AS deletion_flag,
                {locked_col}      AS locked_flag,
                {crypto_iv}       AS crypto_iv,
                {crypto_tag}      AS crypto_tag,
                {crypto_salt}     AS crypto_salt,
                {crypto_iter}     AS crypto_iter,
                {crypto_wrapped}  AS crypto_wrapped,
                {crypto_verifier} AS crypto_verifier,
                {unapplied}       AS unapplied_encrypted
            FROM ZICNOTEDATA d
            JOIN ZICCLOUDSYNCINGOBJECT n ON d.ZNOTE = n.Z_PK
            {folder_join}
            LEFT JOIN ZICCLOUDSYNCINGOBJECT a ON n.ZACCOUNT2 = a.Z_PK
        """.format(
            deletion_col=deletion_col or "NULL",
            locked_col=locked_col or "NULL",
            crypto_iv=crypto_expr("ZCRYPTOINITIALIZATIONVECTOR"),
            crypto_tag=crypto_expr("ZCRYPTOTAG"),
            crypto_salt=crypto_expr("ZCRYPTOSALT"),
            crypto_iter=crypto_expr("ZCRYPTOITERATIONCOUNT"),
            crypto_wrapped=crypto_expr("ZCRYPTOWRAPPEDKEY"),
            crypto_verifier=crypto_expr("ZCRYPTOVERIFIER"),
            unapplied=unapplied_col or "NULL",
            folder_select=folder_select,
            folder_join=folder_join,
        )

        params: List[Any] = []
        where_clauses = []
        if search:
            where_clauses.append("(n.ZTITLE1 LIKE ? OR n.ZSNIPPET LIKE ?)")
            pattern = f"%{search}%"
            params.extend([pattern, pattern])

        if where_clauses:
            query += " WHERE " + " AND ".join(where_clauses)

        query += " ORDER BY n.ZMODIFICATIONDATE1 DESC"

        cur.execute(query, params)
        rows = cur.fetchall()

        notes: List[Dict[str, Any]] = []
        for row in rows:
            data_blob = row["data_blob"]
            content, parsed_attachments = self._parse_modern_content(data_blob, conn, row["note_id"])
            is_locked = bool(row["locked_flag"]) if row["locked_flag"] is not None else False
            if not is_locked and data_blob and not content and not (row["snippet"] or ""):
                # Heuristic: data blob with no visible text is likely locked/encrypted.
                is_locked = True

            # If searching, also check content for matches
            if search:
                found = False
                for field in (row["title"], row["snippet"], content):
                    if field and search.lower() in str(field).lower():
                        found = True
                        break
                if not found:
                    continue

            crypto_iv = row["crypto_iv"]
            crypto_tag = row["crypto_tag"]
            crypto_salt = row["crypto_salt"]
            crypto_iter = row["crypto_iter"] or 0
            crypto_wrapped = row["crypto_wrapped"]
            crypto_verifier = row["crypto_verifier"]
            crypto_unapplied = row["unapplied_encrypted"]

            encrypted_blob_primary = data_blob
            encrypted_blob_alt = None
            locked_payload = None
            if is_locked:
                locked_payload = self._extract_locked_payload(data_blob)
                if locked_payload and locked_payload.get("encrypted_data"):
                    encrypted_blob_primary = locked_payload.get("encrypted_data")
                    encrypted_blob_alt = data_blob

            if is_locked and crypto_unapplied:
                unapplied_payload = self._extract_locked_payload(crypto_unapplied)
                if unapplied_payload:
                    crypto_iv = unapplied_payload.get("crypto_iv") or crypto_iv
                    crypto_tag = unapplied_payload.get("crypto_tag") or crypto_tag
                    crypto_salt = unapplied_payload.get("crypto_salt") or crypto_salt
                    crypto_iter = unapplied_payload.get("crypto_iter") or crypto_iter
                    crypto_verifier = unapplied_payload.get("crypto_verifier") or crypto_verifier
                    crypto_wrapped = unapplied_payload.get("crypto_wrapped") or crypto_wrapped

            if is_locked:
                if not crypto_iter and self._note_crypto_defaults.get("iterations"):
                    crypto_iter = self._note_crypto_defaults.get("iterations") or 0
                if not crypto_salt and self._note_crypto_defaults.get("salt"):
                    crypto_salt = self._note_crypto_defaults.get("salt")
                if not crypto_verifier and self._note_crypto_defaults.get("verifier"):
                    crypto_verifier = self._note_crypto_defaults.get("verifier")

            wrapped_candidates = []
            seen = set()

            def add_wrapped(label: str, value: Optional[bytes]):
                if not isinstance(value, (bytes, bytearray)) or not value:
                    return
                key = bytes(value)
                if key in seen:
                    return
                seen.add(key)
                wrapped_candidates.append({"label": label, "value": key})

            add_wrapped("verifier", crypto_verifier)
            add_wrapped("wrapped", crypto_wrapped)
            if locked_payload:
                add_wrapped("locked_wrapped", locked_payload.get("wrapped_key"))

            crypto_supported = bool(
                is_locked and crypto_iv and crypto_tag and crypto_salt and wrapped_candidates and encrypted_blob_primary
            )

            notes.append({
                "note_id": row["note_id"],
                "title": row["title"] or "Untitled Note",
                "content": content or row["snippet"] or "",
                "snippet": row["snippet"] or "",
                "folder": row["folder"] or "Notes",
                "account": row["account"] or "iCloud",
                "created": row["created"],
                "modified": row["modified"],
                "has_attachments": any(a.get("file_path") for a in parsed_attachments),
                "is_deleted": bool(row["deletion_flag"]) if row["deletion_flag"] is not None else False,
                "is_locked": is_locked,
                "crypto_supported": crypto_supported,
                "crypto_iv": crypto_iv,
                "crypto_tag": crypto_tag,
                "crypto_salt": crypto_salt,
                "crypto_iter": crypto_iter,
                "crypto_wrapped": crypto_wrapped,
                "crypto_verifier": crypto_verifier,
                "crypto_wrapped_candidates": wrapped_candidates,
                "crypto_encrypted_blob": encrypted_blob_primary if is_locked else None,
                "crypto_encrypted_blob_alt": encrypted_blob_alt if is_locked else None,
                "source": "modern",
                "db_path": self.modern_db_path,
            })

        conn.close()
        return notes

    def _load_legacy_notes(self, search: Optional[str]) -> List[Dict[str, Any]]:
        """Load notes from legacy HomeDomain notes.sqlite (local/IMAP)."""
        conn = sqlite3.connect(self.legacy_db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        # Map stores for account names
        store_names = {}
        try:
            cur.execute("SELECT Z_PK, ZNAME, ZEXTERNALIDENTIFIER FROM ZSTORE")
            for row in cur.fetchall():
                name = row["ZNAME"] or "Notes"
                if row["ZEXTERNALIDENTIFIER"]:
                    name = row["ZEXTERNALIDENTIFIER"]
                store_names[row["Z_PK"]] = name
        except Exception:
            pass

        locked_col = None
        try:
            cur.execute("PRAGMA table_info(ZNOTE)")
            columns = {row[1] for row in cur.fetchall()}
            for candidate in ("ZISPASSWORDPROTECTED", "ZISLOCKED", "ZPASSWORDPROTECTED", "ZLOCKED"):
                if candidate in columns:
                    locked_col = f"n.{candidate}"
                    break
        except Exception:
            locked_col = None

        query = """
            SELECT
                n.Z_PK           AS note_id,
                n.ZTITLE         AS title,
                n.ZSUMMARY       AS snippet,
                n.ZCREATIONDATE  AS created,
                n.ZMODIFICATIONDATE AS modified,
                n.ZBODY          AS body_id,
                n.ZSTORE         AS store_id,
                n.ZDELETEDFLAG   AS deleted_flag,
                {locked_col}     AS locked_flag
            FROM ZNOTE n
        """.format(locked_col=locked_col or "NULL")
        params: List[Any] = []
        where_clauses = []
        if search:
            where_clauses.append("(n.ZTITLE LIKE ? OR n.ZSUMMARY LIKE ?)")
            pattern = f"%{search}%"
            params.extend([pattern, pattern])

        if where_clauses:
            query += " WHERE " + " AND ".join(where_clauses)

        query += " ORDER BY n.ZMODIFICATIONDATE DESC"
        cur.execute(query, params)
        rows = cur.fetchall()

        notes: List[Dict[str, Any]] = []
        # Preload body contents
        body_map = {}
        try:
            cur.execute("SELECT Z_PK, ZCONTENT FROM ZNOTEBODY")
            body_map = {row["Z_PK"]: row["ZCONTENT"] for row in cur.fetchall()}
        except Exception:
            pass

        # Attachment counts per note
        attachment_counts = {}
        try:
            cur.execute("SELECT ZNOTE, COUNT(*) FROM ZNOTEATTACHMENT GROUP BY ZNOTE")
            attachment_counts = {row[0]: row[1] for row in cur.fetchall()}
        except Exception:
            attachment_counts = {}

        for row in rows:
            content = body_map.get(row["body_id"], "") or ""
            is_locked = bool(row["locked_flag"]) if row["locked_flag"] is not None else False
            if not is_locked and row["body_id"] and not content and not (row["snippet"] or ""):
                is_locked = True

            if search and search.lower() not in content.lower():
                # already filtered by title/snippet above; if content also doesn't match, skip
                if not (row["title"] and search.lower() in row["title"].lower()) and \
                   not (row["snippet"] and search.lower() in row["snippet"].lower()):
                    continue

            notes.append({
                "note_id": row["note_id"],
                "title": row["title"] or "Untitled Note",
                "content": content or row["snippet"] or "",
                "snippet": row["snippet"] or "",
                "folder": "Notes",
                "account": store_names.get(row["store_id"], "Local"),
                "created": row["created"],
                "modified": row["modified"],
                "has_attachments": attachment_counts.get(row["note_id"], 0) > 0,
                "is_deleted": bool(row["deleted_flag"]),
                "is_locked": is_locked,
                "source": "legacy",
                "db_path": self.legacy_db_path,
            })

        conn.close()
        return notes

    def _parse_modern_content(self, data_blob: Optional[bytes], conn: sqlite3.Connection, note_id: int) -> tuple:
        """Extract plaintext from modern NoteStore data blobs and return (text, attachments)."""
        if not data_blob:
            return "", []

        data = data_blob
        try:
            if data[:2] == b'\x1f\x8b':
                data = gzip.decompress(data)
        except Exception:
            pass

        # Try protobuf-aware parsing with attachment replacement
        try:
            text, attachments = self._parse_protobuf_note_with_attachments(data)
            if text:
                text = self._replace_attachment_markers(text, attachments, conn, note_id)
                return text, attachments
        except Exception:
            # Fallback to best-effort text extraction
            try:
                text = self._extract_largest_text_field(data)
                if text:
                    return text, []
            except Exception:
                pass

        try:
            return data.decode("utf-8", errors="ignore"), []
        except Exception:
            return "", []

    def _extract_locked_payload(self, data_blob: Optional[bytes]) -> Optional[Dict[str, Any]]:
        """
        Extract encrypted payload from a locked note blob.

        Returns:
            Dict with encrypted_data/wrapped_key and crypto fields if present.
        """
        if not data_blob:
            return None
        try:
            from io import BytesIO
            import ccl_bplist

            plist = ccl_bplist.load(BytesIO(data_blob))
            parsed = ccl_bplist.deserialise_NsKeyedArchiver(plist, parse_whole_structure=True)
            root = parsed.get("root") or {}
            payload = {}
            encrypted_data = root.get("encryptedData")
            wrapped_key = root.get("wrappedEncryptionKey")
            if isinstance(encrypted_data, (bytes, bytearray)):
                payload["encrypted_data"] = bytes(encrypted_data)
            if isinstance(wrapped_key, (bytes, bytearray)):
                payload["wrapped_key"] = bytes(wrapped_key)
            for key_name, out_key in (
                ("CryptoInitializationVector", "crypto_iv"),
                ("CryptoTag", "crypto_tag"),
                ("CryptoSalt", "crypto_salt"),
                ("CryptoIterationCount", "crypto_iter"),
                ("CryptoWrappedKey", "crypto_wrapped"),
                ("CryptoVerifier", "crypto_verifier"),
            ):
                value = root.get(key_name)
                if isinstance(value, (bytes, bytearray)):
                    payload[out_key] = bytes(value)
                elif isinstance(value, int):
                    payload[out_key] = value
            if payload:
                return payload
        except Exception:
            pass
        return None

    def _parse_protobuf_note(self, data: bytes) -> str:
        """
        Parse Apple Notes protobuf format to extract plaintext.

        The protobuf structure is:
        NoteStoreProto {
          document (field 2) {
            note (field 3) {
              note_text (field 2): string  <-- This is what we want
            }
          }
        }

        We use manual parsing to extract the note_text field.
        """
        try:
            return self._extract_largest_text_field(data)
        except Exception as e:
            return ''

    def _extract_largest_text_field(self, data: bytes, depth: int = 0) -> str:
        """
        Recursively extract all text fields from protobuf and return the largest one.
        """
        if depth > 5:  # Prevent infinite recursion
            return ''

        text_candidates = []
        i = 0

        while i < len(data):
            if i >= len(data):
                break

            # Read field tag
            tag_byte = data[i]
            i += 1

            # Wire type is in lower 3 bits
            wire_type = tag_byte & 0x07
            field_number = tag_byte >> 3

            if wire_type == 2:  # Length-delimited (strings, embedded messages, bytes)
                # Read length (varint)
                length = 0
                shift = 0
                while i < len(data):
                    byte = data[i]
                    i += 1
                    length |= (byte & 0x7F) << shift
                    if not (byte & 0x80):
                        break
                    shift += 7

                # Extract the field data
                if i + length <= len(data):
                    field_data = data[i:i+length]
                    i += length

                    # Try to decode as UTF-8 text
                    try:
                        decoded = field_data.decode('utf-8')
                        # Check if this looks like actual text content
                        # Good indicators: mostly printable characters, reasonable length
                        if len(decoded) > 0:
                            printable_ratio = sum(c.isprintable() or c in '\n\r\t' for c in decoded) / len(decoded)

                            # Accept text if:
                            # - High printable ratio (>95%) and length > 5, OR
                            # - Very high printable ratio (>98%) for any length
                            if (printable_ratio > 0.95 and len(decoded) > 5) or printable_ratio > 0.98:
                                text_candidates.append(decoded)
                    except UnicodeDecodeError:
                        # Not valid UTF-8, might be an embedded message
                        # Recursively parse it
                        nested_text = self._extract_largest_text_field(field_data, depth + 1)
                        if nested_text:
                            text_candidates.append(nested_text)

            elif wire_type == 0:  # Varint
                # Skip the varint value
                while i < len(data) and data[i] & 0x80:
                    i += 1
                if i < len(data):
                    i += 1

            elif wire_type == 1:  # 64-bit
                i += 8

            elif wire_type == 5:  # 32-bit
                i += 4

            else:
                # Unknown wire type, stop parsing this message
                break

        # Return the longest text found (most likely to be the actual note content)
        if text_candidates:
            return max(text_candidates, key=len)

        return ''

    def _parse_protobuf_note_with_attachments(self, data: bytes) -> tuple:
        """
        Parse protobuf to extract both note text and attachment information.

        Returns:
            (text: str, attachments: List[Dict]) - text and list of attachment info
        """
        # First, extract the note text using existing method
        text = self._extract_largest_text_field(data)

        # Now parse AttributeRun messages to find attachment info
        attachments = []

        try:
            # Look for AttributeRun messages in the protobuf
            # AttributeRun has field number 5 in Note message
            # Each AttributeRun can contain AttachmentInfo at field 12

            # Search for attachment_identifier strings (field 1 in AttachmentInfo)
            # and type_uti strings (field 2 in AttachmentInfo)
            i = 0
            while i < len(data):
                # Look for field tag 0x62 (field 12, wire type 2 = AttachmentInfo)
                if i < len(data) - 1 and data[i] == 0x62:
                    i += 1
                    # Read length
                    length = 0
                    shift = 0
                    while i < len(data):
                        byte = data[i]
                        i += 1
                        length |= (byte & 0x7F) << shift
                        if not (byte & 0x80):
                            break
                        shift += 7

                    if i + length <= len(data):
                        att_data = data[i:i+length]
                        i += length

                        # Parse AttachmentInfo fields
                        att_id = None
                        att_uti = None

                        # Extract string fields from AttachmentInfo
                        j = 0
                        while j < len(att_data):
                            if j >= len(att_data):
                                break
                            tag = att_data[j]
                            j += 1

                            if (tag & 0x07) == 2:  # String field
                                # Read length
                                str_len = 0
                                shift = 0
                                while j < len(att_data):
                                    byte = att_data[j]
                                    j += 1
                                    str_len |= (byte & 0x7F) << shift
                                    if not (byte & 0x80):
                                        break
                                    shift += 7

                                if j + str_len <= len(att_data):
                                    str_val = att_data[j:j+str_len]
                                    j += str_len

                                    try:
                                        decoded = str_val.decode('utf-8')
                                        field_num = tag >> 3
                                        if field_num == 1:  # attachment_identifier
                                            att_id = decoded
                                        elif field_num == 2:  # type_uti
                                            att_uti = decoded
                                    except:
                                        pass

                        # Only add if it looks like a real attachment
                        # Real attachments have a UUID-style identifier or a valid UTI
                        if att_uti and ('.' in att_uti or 'com.' in att_uti):
                            # Has a valid UTI (contains dots like com.apple.drawing.2)
                            attachments.append({
                                'identifier': att_id,
                                'uti': att_uti
                            })
                        elif att_id and ('-' in att_id and len(att_id) > 30):
                            # Has a UUID-style identifier (contains hyphens and long)
                            attachments.append({
                                'identifier': att_id,
                                'uti': att_uti
                            })
                else:
                    i += 1

        except Exception as e:
            # If attachment parsing fails, just return text with empty attachments
            pass

        return text, attachments

    def _replace_attachment_markers(self, text: str, attachments: List[Dict],
                                    conn: sqlite3.Connection, note_id: int) -> str:
        """
        Replace U+FFFC object markers with descriptive attachment labels and embedded images.
        """
        if not attachments:
            return text

        # Query database for attachment details including identifiers
        cur = conn.cursor()
        attachment_details = {}

        try:
            cur.execute("""
                SELECT Z_PK, ZTYPEUTI, ZFILENAME, ZSUMMARY, ZIDENTIFIER
                FROM ZICCLOUDSYNCINGOBJECT
                WHERE ZNOTE = ?
            """, (note_id,))

            for row in cur.fetchall():
                uti = row[1]
                filename = row[2]
                summary = row[3]
                identifier = row[4]

                if uti:
                    attachment_details[uti] = {
                        'filename': filename,
                        'summary': summary,
                        'identifier': identifier,
                        'type': self._uti_to_type(uti)
                    }
        except:
            pass

        # Replace each U+FFFC marker with embedded content or descriptive text
        object_marker = '\ufffc'
        if object_marker not in text:
            return text

        result = []
        attachment_index = 0

        for char in text:
            if char == object_marker and attachment_index < len(attachments):
                att = attachments[attachment_index]
                attachment_index += 1

                # Get details from database if available
                uti = att.get('uti')
                identifier = att.get('identifier')

                if uti and uti in attachment_details:
                    details = attachment_details[uti]
                    att_type = details['type']
                    filename = details['filename']
                    db_identifier = details['identifier']

                    # Use database identifier if available, otherwise use protobuf identifier
                    use_identifier = db_identifier if db_identifier else identifier

                    # For images and drawings, try to embed preview
                    if att_type in ['Image', 'Drawing'] and use_identifier:
                        preview_data = self._get_attachment_preview(use_identifier)
                        if preview_data:
                            # Embed image with alt text
                            alt_text = filename if filename else att_type
                            result.append(f'<img src="{preview_data}" alt="{alt_text}" style="max-width: 100%; height: auto; margin: 10px 0;">')
                        else:
                            # No preview available, show text label
                            if filename:
                                result.append(f'[{att_type}: {filename}]')
                            else:
                                result.append(f'[{att_type}]')
                    else:
                        # For non-image attachments, show text label
                        if filename:
                            result.append(f'[{att_type}: {filename}]')
                        else:
                            result.append(f'[{att_type}]')
                elif uti:
                    att_type = self._uti_to_type(uti)
                    # Try to embed image even without database details
                    if att_type in ['Image', 'Drawing'] and identifier:
                        preview_data = self._get_attachment_preview(identifier)
                        if preview_data:
                            result.append(f'<img src="{preview_data}" alt="{att_type}" style="max-width: 100%; height: auto; margin: 10px 0;">')
                        else:
                            result.append(f'[{att_type}]')
                    else:
                        result.append(f'[{att_type}]')
                else:
                    result.append('[Attachment not available]')
            else:
                result.append(char)

        return ''.join(result)

    def _uti_to_type(self, uti: str) -> str:
        """Convert UTI (Uniform Type Identifier) to friendly name."""
        uti_map = {
            'com.apple.drawing.2': 'Drawing',
            'com.apple.drawing': 'Drawing',
            'public.jpeg': 'Image',
            'public.png': 'Image',
            'public.heic': 'Image',
            'public.image': 'Image',
            'com.adobe.pdf': 'PDF',
            'public.url': 'Link',
            'com.apple.notes.table': 'Table',
            'com.apple.notes.gallery': 'Gallery',
            'public.movie': 'Video',
            'public.audio': 'Audio',
        }

        # Try exact match first
        if uti in uti_map:
            return uti_map[uti]

        # Try partial matches
        uti_lower = uti.lower()
        if 'image' in uti_lower or 'jpeg' in uti_lower or 'png' in uti_lower:
            return 'Image'
        elif 'drawing' in uti_lower or 'sketch' in uti_lower:
            return 'Drawing'
        elif 'pdf' in uti_lower:
            return 'PDF'
        elif 'table' in uti_lower:
            return 'Table'
        elif 'video' in uti_lower or 'movie' in uti_lower:
            return 'Video'
        elif 'audio' in uti_lower:
            return 'Audio'
        elif 'url' in uti_lower or 'link' in uti_lower:
            return 'Link'

        return 'Attachment'

    def _get_attachment_preview(self, identifier: str) -> Optional[str]:
        """
        Extract preview image for an attachment and return as base64 string.

        Args:
            identifier: Attachment UUID

        Returns:
            Base64-encoded image string, or None if not found
        """
        try:
            # Open Manifest.db to find preview files
            manifest_path = self.manifest_db_path
            if not os.path.exists(manifest_path):
                return None

            manifest_conn = sqlite3.connect(f"file:{manifest_path}?mode=ro", uri=True)
            manifest_cur = manifest_conn.cursor()

            # Look for preview images for this identifier
            # Order by path DESC to get largest preview first
            manifest_cur.execute("""
                SELECT fileID, relativePath
                FROM Files
                WHERE domain = 'AppDomainGroup-group.com.apple.notes'
                AND relativePath LIKE ?
                ORDER BY relativePath DESC
                LIMIT 1
            """, (f'Previews/{identifier}%',))

            result = manifest_cur.fetchone()
            manifest_conn.close()

            if not result:
                # Try fallback images for drawings
                manifest_conn = sqlite3.connect(f"file:{manifest_path}?mode=ro", uri=True)
                manifest_cur = manifest_conn.cursor()

                manifest_cur.execute("""
                    SELECT fileID, relativePath
                    FROM Files
                    WHERE domain = 'AppDomainGroup-group.com.apple.notes'
                    AND relativePath LIKE ?
                    LIMIT 1
                """, (f'FallbackImages/{identifier}%',))

                result = manifest_cur.fetchone()
                manifest_conn.close()

                if not result:
                    return None

            file_id, rel_path = result

            # Read the preview file
            file_path = self._resolve_file_id_path(file_id)
            if not file_path or not os.path.exists(file_path):
                return None

            with open(file_path, 'rb') as f:
                image_data = f.read()

            # Encode as base64
            b64_data = base64.b64encode(image_data).decode('ascii')

            # Determine image type from file path
            if rel_path.endswith('.png'):
                img_type = 'png'
            elif rel_path.endswith('.jpg') or rel_path.endswith('.jpeg'):
                img_type = 'jpeg'
            else:
                # Try to detect from file header
                if image_data[:4] == b'\x89PNG':
                    img_type = 'png'
                elif image_data[:2] == b'\xff\xd8':
                    img_type = 'jpeg'
                else:
                    img_type = 'png'  # Default

            return f'data:image/{img_type};base64,{b64_data}'

        except Exception as e:
            # If anything fails, just return None
            return None

    def _extract_attachment_file(self, identifier: Optional[str], filename: str,
                                 attachments_dir: str,
                                 search_domains: Optional[List[str]] = None) -> Optional[str]:
        """
        Extract attachment file from backup and copy to attachments directory.

        Args:
            identifier: Attachment UUID (may be None for legacy filename-only lookups)
            filename: Original filename from database
            attachments_dir: Directory to copy attachment files to
            search_domains: Optional list of manifest domains to search (defaults to Notes + Home + CameraRoll)

        Returns:
            Relative path to copied file, or None if extraction failed
        """
        try:
            manifest_path = self.manifest_db_path
            if not os.path.exists(manifest_path):
                return None

            if not search_domains:
                search_domains = [
                    "AppDomainGroup-group.com.apple.notes",
                    "HomeDomain",
                    "CameraRollDomain",
                ]

            result = None
            manifest_conn = sqlite3.connect(f"file:{manifest_path}?mode=ro", uri=True)
            manifest_cur = manifest_conn.cursor()

            # Try identifier-based lookups first (modern notes)
            if identifier:
                for domain in search_domains:
                    manifest_cur.execute("""
                        SELECT fileID, relativePath
                        FROM Files
                        WHERE domain = ?
                        AND relativePath LIKE ?
                        AND relativePath NOT LIKE '%Previews/%'
                        AND relativePath NOT LIKE '%FallbackImages/%'
                        ORDER BY LENGTH(relativePath) ASC
                        LIMIT 1
                    """, (domain, f'%{identifier}%',))
                    result = manifest_cur.fetchone()
                    if result:
                        break

                # Alternate patterns
                if not result:
                    for domain in search_domains:
                        manifest_cur.execute("""
                            SELECT fileID, relativePath
                            FROM Files
                            WHERE domain = ?
                            AND (relativePath LIKE ? OR relativePath LIKE ?)
                            AND relativePath NOT LIKE '%Previews/%'
                            LIMIT 1
                        """, (domain, f'Media/{identifier}%', f'Accounts/%/{identifier}%'))
                        result = manifest_cur.fetchone()
                        if result:
                            break

            # Filename-based lookup (legacy notes.sqlite attachments)
            if not result and filename:
                for domain in search_domains:
                    manifest_cur.execute("""
                        SELECT fileID, relativePath
                        FROM Files
                        WHERE domain = ?
                        AND relativePath LIKE ?
                        ORDER BY LENGTH(relativePath) ASC
                        LIMIT 1
                    """, (domain, f'%{filename}%'))
                    result = manifest_cur.fetchone()
                    if result:
                        break

            manifest_conn.close()

            if not result:
                return None

            file_id, rel_path = result

            # Read the attachment file from backup
            file_path = self._resolve_file_id_path(file_id)
            if not file_path or not os.path.exists(file_path):
                return None

            # Sanitize filename and handle collisions
            safe_filename = "".join(c for c in filename if c.isalnum() or c in (' ', '-', '_', '.'))
            if not safe_filename:
                # Fallback to identifier-based name
                ext = os.path.splitext(rel_path)[1] if '.' in rel_path else ''
                safe_filename = f"{identifier[:8]}{ext}"

            # Handle filename collisions
            output_path = os.path.join(attachments_dir, safe_filename)
            if os.path.exists(output_path):
                base, ext = os.path.splitext(safe_filename)
                counter = 1
                while os.path.exists(output_path):
                    output_path = os.path.join(attachments_dir, f"{base}_{counter}{ext}")
                    counter += 1
                safe_filename = os.path.basename(output_path)

            # Copy file to attachments directory
            shutil.copy2(file_path, output_path)
            self._add_export_bytes(output_path)

            # Return relative path from Notes directory
            return f"Attachments/{safe_filename}"

        except Exception as e:
            # If extraction fails, return None (will fallback to label)
            return None

    def export(self, items: List[Dict[str, Any]], output_path: str,
               format: str = 'html', progress_callback=None, timeline_emitter=None) -> bool:
        """
        Export notes to HTML files.

        Args:
            items: List of notes to export
            output_path: Output directory path
            format: Export format ('html', 'txt')
            progress_callback: Optional callback(current, total, item_name) -> bool

        Returns:
            True if export succeeded
        """
        if format not in ['html', 'txt']:
            raise ValueError(f"Unsupported export format: {format}")

        try:
            self._reset_export_bytes()
            self._notes_report_passphrase = None
            encrypt_notes = (
                self.enable_report_lock
                and format == 'html'
                and any(note.get("is_locked") for note in items)
            )
            # Use output_path directly (already includes "Notes" from extraction manager)
            output_dir = output_path
            os.makedirs(output_dir, exist_ok=True)

            # Create Attachments subdirectory for HTML format
            attachments_dir = None
            if format == 'html':
                attachments_dir = os.path.join(output_dir, 'Attachments')
                os.makedirs(attachments_dir, exist_ok=True)

            if encrypt_notes:
                passphrase = self._generate_report_passphrase()
                self._notes_report_passphrase = passphrase
                passphrase_path = os.path.join(output_dir, "Notes_Report_Passphrase.txt")
                with open(passphrase_path, "w", encoding="utf-8") as f:
                    f.write(
                        "Notes Report Passphrase\n"
                        "------------------------\n"
                        f"{passphrase}\n\n"
                        "Keep this passphrase secure. It is required to unlock the Notes report.\n"
                    )
                self._add_export_bytes(passphrase_path)
                print(f"[Notes] Locked notes detected. Report passphrase: {passphrase}")

            total = len(items)
            for i, note in enumerate(items):
                # Call progress callback if provided
                if progress_callback:
                    if not progress_callback(i + 1, total, note['title']):
                        return False  # User cancelled

                if format == 'html':
                    self._export_note_html(note, output_dir, i + 1, attachments_dir, timeline_emitter)
                else:
                    self._export_note_txt(note, output_dir, i + 1)

            if timeline_emitter is not None:
                self._emit_timeline_events(items, timeline_emitter)

            # Create Notes.html index (with embedded search index)
            if format == 'html':
                self._create_index_html(items, output_dir, encrypt_passphrase=self._notes_report_passphrase)

            return True

        except Exception as e:
            print(f"Error exporting notes: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _extract_and_link_attachments(self, note: Dict[str, Any], attachments_dir: str,
                                      timeline_emitter=None) -> tuple:
        """
        Extract attachments for a note and return HTML with links.

        Args:
            note: Note dictionary (includes note_id and source)
            attachments_dir: Directory to extract attachments to

        Returns:
            (HTML string with attachment links, cid_map dict)
        """
        try:
            source = note.get("source", "modern")
            attachments = []
            search_domains: List[str] = []

            if source == "modern" and self.modern_db_path:
                conn = sqlite3.connect(self.modern_db_path)
                conn.row_factory = sqlite3.Row
                cur = conn.cursor()
                # Fetch data blob to parse attachment identifiers
                cur.execute("SELECT ZDATA FROM ZICNOTEDATA WHERE ZNOTE = ?", (note["note_id"],))
                row = cur.fetchone()
                conn.close()
                if row and row["ZDATA"]:
                    try:
                        data_blob = row["ZDATA"]
                        if data_blob[:2] == b'\x1f\x8b':
                            import gzip
                            data_blob = gzip.decompress(data_blob)
                        _, attachments = self._parse_protobuf_note_with_attachments(data_blob)
                    except Exception:
                        attachments = []
                search_domains = ["AppDomainGroup-group.com.apple.notes", "HomeDomain"]

            elif source == "legacy" and self.legacy_db_path:
                conn = sqlite3.connect(self.legacy_db_path)
                conn.row_factory = sqlite3.Row
                cur = conn.cursor()
                cur.execute("""
                    SELECT
                        ZCONTENTID as identifier,
                        ZFILENAME as filename,
                        ZMIMETYPE as type_uti
                    FROM ZNOTEATTACHMENT
                    WHERE ZNOTE = ?
                """, (note["note_id"],))
                attachments = cur.fetchall()
                conn.close()
                search_domains = ["HomeDomain", "CameraRollDomain"]
            else:
                return ""

            if not attachments:
                return "", {}

            # Extract each attachment and build HTML
            links = []
            cid_map = {}
            for att in attachments:
                if not isinstance(att, dict):
                    att = dict(att)

                identifier = att.get('identifier')
                filename = att.get('filename')
                type_uti = att.get('type_uti') or att.get('uti') or ''

                if not filename:
                    # derive a best-effort filename from identifier/uti
                    ext = ''
                    if type_uti:
                        guess = self._uti_to_type(type_uti)
                        if guess == 'Image':
                            ext = '.jpg'
                        elif guess == 'PDF':
                            ext = '.pdf'
                        elif guess == 'Audio':
                            ext = '.m4a'
                        elif guess == 'Video':
                            ext = '.mov'
                    base_name = identifier[:8] if identifier else "attachment"
                    filename = f"{base_name}{ext}" if ext else base_name

                # Extract file
                rel_path = self._extract_attachment_file(identifier, filename, attachments_dir, search_domains)

                if identifier:
                    # Normalize cid without mailto suffix; store even if missing so we can show labels
                    cid_key = identifier.replace("cid:", "").replace("mailto:", "")
                    cid_map[cid_key] = rel_path

                if rel_path:
                    # Determine attachment type for display
                    att_type = self._uti_to_type(type_uti)

                    # For images, show preview with link to full size
                    if att_type in ['Image', 'Drawing']:
                        links.append(f'''
                            <div>
                                <a href="../{rel_path}" target="_blank">
                                    <img src="../{rel_path}" class="attachment-preview" alt="{filename}" title="Click to open full size">
                                </a>
                                <br><small>{filename}</small>
                            </div>
                        ''')
                    else:
                        # For other files, show download link
                        links.append(f'<a href="../{rel_path}" class="attachment-link" download="{filename}">📎 {filename}</a>')

                    if timeline_emitter is not None:
                        ts_raw = note.get("modified") or note.get("created")
                        ts_iso = self._format_timestamp_iso(ts_raw)
                        event_type = "file_attachment"
                        ext = os.path.splitext(filename)[1].lower()
                        if att_type in ("Image", "Drawing") or ext in (".jpg", ".jpeg", ".png", ".gif", ".heic", ".heif", ".bmp", ".tif", ".tiff", ".webp"):
                            event_type = "photo_attachment"
                        elif att_type == "Video" or ext in (".mov", ".mp4", ".m4v", ".avi", ".mkv", ".3gp", ".3gpp"):
                            event_type = "video_attachment"
                        elif att_type == "Audio" or ext in (".m4a", ".aac", ".mp3", ".wav", ".aiff", ".amr", ".caf", ".flac", ".opus"):
                            event_type = "audio_attachment"
                        timeline_emitter.emit({
                            "timestamp": ts_iso or "",
                            "timestamp_display": ts_iso or "",
                            "timestamp_utc": ts_iso or "",
                            "raw_timestamp": ts_raw,
                            "raw_format": "apple_epoch_seconds",
                            "source_app": "Notes",
                            "source_category": "Notes",
                            "event_type": event_type,
                            "title": f"Note attachment: {filename}",
                            "details": {
                                "note_title": note.get("title", ""),
                                "filename": filename,
                                "attachment_type": att_type,
                                "path": rel_path,
                            },
                            "confidence": "low" if event_type == "file_attachment" else "high",
                            "raw_source_path": rel_path,
                            "report_anchor": f"note-{note.get('note_id', '')}",
                            "link_hint": "Notes/Notes.html",
                        })

            if links:
                return f'''
                <div class="attachments">
                    <h3>Attachments</h3>
                    {''.join(links)}
                </div>
                ''', cid_map

            return "", cid_map

        except Exception as e:
            # If attachment extraction fails, return empty (non-fatal)
            return "", {}

    def _export_note_html(self, note: Dict[str, Any], output_dir: str, index: int,
                          attachments_dir: Optional[str] = None, timeline_emitter=None):
        """Export single note as HTML file."""
        # Create Individual Notes subdirectory
        individual_notes_dir = os.path.join(output_dir, 'Individual Notes')
        os.makedirs(individual_notes_dir, exist_ok=True)

        # Sanitize filename
        safe_title = "".join(c for c in note['title'] if c.isalnum() or c in (' ', '-', '_'))[:50]
        filename = f"{index:04d}_{safe_title}.html"
        filepath = os.path.join(individual_notes_dir, filename)

        # Extract attachments if directory provided
        attachments_html = ""
        cid_map = {}
        if attachments_dir:
            attachments_html, cid_map = self._extract_and_link_attachments(note, attachments_dir, timeline_emitter)

        # Inline replace cid/object references using extracted attachments
        content_for_export = self._inline_embed_cid_objects(note['content'], cid_map)

        formatted_content = self._format_content(content_for_export)
        locked_notice = ""
        if note.get("is_locked"):
            # Avoid showing raw encrypted blobs in the report.
            formatted_content = ''
            locked_notice = '<div class="locked-note">This note is locked and requires its own passcode to decrypt.</div>'
        unlock_panel = ""
        if note.get("is_locked") and note.get("crypto_supported"):
            import json

            def b64(value: Optional[bytes]) -> str:
                if not value:
                    return ""
                return base64.b64encode(value).decode("ascii")

            wrapped_candidates = note.get("crypto_wrapped_candidates") or []
            wrapped_list = []
            for entry in wrapped_candidates:
                if not entry or not entry.get("value"):
                    continue
                wrapped_list.append({
                    "label": entry.get("label", "wrapped"),
                    "b64": b64(entry.get("value")),
                })
            wrapped_list_b64 = base64.b64encode(
                json.dumps(wrapped_list, ensure_ascii=True).encode("utf-8")
            ).decode("ascii") if wrapped_list else ""
            primary_wrapped = wrapped_candidates[0]["value"] if wrapped_candidates else note.get("crypto_wrapped")

            unlock_panel = f'''
        <div class="unlock-panel" data-locked="true">
            <h2>Unlock Locked Note</h2>
            <p>Enter the note passcode to decrypt this note.</p>
            <input type="password" id="notePassphrase" placeholder="Note passcode">
            <button id="unlockNoteBtn">Unlock Note</button>
            <div id="unlockError" class="unlock-error">Unable to unlock. Check the passcode.</div>
            <details class="unlock-debug">
                <summary>Debug details</summary>
                <pre id="unlockDebugText">Waiting for unlock attempt...</pre>
            </details>
        </div>
        <div id="lockedPayload"
             data-iv="{b64(note.get('crypto_iv'))}"
             data-tag="{b64(note.get('crypto_tag'))}"
             data-salt="{b64(note.get('crypto_salt'))}"
             data-iter="{note.get('crypto_iter') or ''}"
             data-wrapped="{b64(primary_wrapped)}"
             data-wrapped-list="{wrapped_list_b64}"
             data-blob="{b64(note.get('crypto_encrypted_blob'))}"
             data-blob-alt="{b64(note.get('crypto_encrypted_blob_alt'))}">
        </div>
        <div id="decryptedContent" class="decrypted-content"></div>
        '''
        elif note.get("is_locked"):
            unlock_panel = '''
        <div class="unlock-panel unsupported">
            <h2>Locked Note</h2>
            <p>This note is locked, but the required crypto fields are not available in this backup format.</p>
        </div>
        '''

        html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{note['title']}</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            max-width: 800px;
            margin: 40px auto;
            padding: 20px;
            line-height: 1.6;
        }}
        h1 {{
            color: #333;
            border-bottom: 2px solid #f0f0f0;
            padding-bottom: 10px;
        }}
        .meta {{
            color: #666;
            font-size: 14px;
            margin: 20px 0;
        }}
        .content {{
            margin-top: 30px;
        }}
        .attachments {{
            margin-top: 30px;
            padding: 15px;
            background: #f5f5f5;
            border-radius: 5px;
        }}
        .attachment-link {{
            display: inline-block;
            margin: 5px 10px 5px 0;
            padding: 8px 12px;
            background: #007aff;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-size: 14px;
        }}
        .attachment-link:hover {{
            background: #0051d5;
        }}
        .breadcrumbs {{
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 13px;
            color: #1f2937;
            margin-bottom: 16px;
        }}
        .breadcrumbs a {{
            color: #1f2937;
            text-decoration: none;
            font-weight: 600;
        }}
        .breadcrumbs a:hover {{
            text-decoration: underline;
        }}
        .breadcrumbs .back-arrow {{
            font-size: 16px;
        }}
        .embedded .breadcrumbs {{
            display: none;
        }}
        .attachment-preview {{
            max-width: 200px;
            max-height: 200px;
            margin: 10px 0;
            cursor: pointer;
        }}
        .attachment-inline {{
            max-width: 240px;
            max-height: 240px;
            display: block;
            margin: 10px 0;
        }}
        .attachment-missing {{
            color: #c62828;
            font-weight: 600;
        }}
        .attachment-inline {{
            max-width: 240px;
            max-height: 240px;
            display: block;
            margin: 10px 0;
        }}
        .attachment-missing {{
            color: #c62828;
            font-weight: 600;
        }}
        .locked-note {{
            padding: 12px 14px;
            background: #fff1f0;
            border: 1px solid #ffd4d2;
            color: #c62828;
            border-radius: 6px;
            margin-top: 20px;
            font-weight: 600;
        }}
        .unlock-panel {{
            margin-top: 24px;
            padding: 16px;
            border-radius: 8px;
            background: #f2f2f7;
        }}
        .unlock-panel h2 {{
            margin: 0 0 8px;
            font-size: 18px;
        }}
        .unlock-panel p {{
            margin: 0 0 12px;
            color: #636366;
        }}
        .unlock-panel input {{
            width: 100%;
            padding: 10px 12px;
            border-radius: 6px;
            border: 1px solid #d1d1d6;
            font-size: 14px;
            box-sizing: border-box;
            margin-bottom: 10px;
        }}
        .unlock-panel button {{
            padding: 10px 14px;
            border: none;
            border-radius: 6px;
            background: #007aff;
            color: white;
            font-size: 14px;
            cursor: pointer;
        }}
        .unlock-debug {{
            margin-top: 12px;
            font-size: 12px;
            color: #636366;
        }}
        .unlock-debug pre {{
            background: #ffffff;
            border: 1px solid #e5e5ea;
            border-radius: 6px;
            padding: 10px;
            white-space: pre-wrap;
            word-break: break-word;
        }}
        .unlock-error {{
            margin-top: 8px;
            color: #ff3b30;
            display: none;
        }}
        .decrypted-content {{
            margin-top: 20px;
            padding: 16px;
            border-radius: 8px;
            background: #ffffff;
            border: 1px solid #e5e5ea;
        }}
    </style>
</head>
<body>
    <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Notes.html">Back to Notes</a></div>
    <h1>{note['title']}</h1>
    <div class="meta">
        <strong>Folder:</strong> {note['folder']}<br>
        <strong>Account:</strong> {note['account']}<br>
        <strong>Modified:</strong> {self._format_timestamp(note['modified'])}
    </div>
    <div class="content">
        {formatted_content}
        {locked_notice}
    </div>
    {unlock_panel}
    {attachments_html}
    <script>
    (function() {{
        try {{
            if (window.parent && window.parent !== window) {{
                window.parent.postMessage({{type: 'device-nav', href: window.location.href}}, '*');
            }}
        }} catch (err) {{}}
        if (window.self !== window.top) {{
            document.body.classList.add('embedded');
        }}
    }})();
    </script>
</body>
</html>"""

        if note.get("is_locked") and note.get("crypto_supported"):
            html += """
<script>
function b64ToBytes(b64) {
    if (!b64) return new Uint8Array();
    const binary = atob(b64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
    }
    return bytes;
}

function concatBytes(a, b) {
    const out = new Uint8Array(a.length + b.length);
    out.set(a, 0);
    out.set(b, a.length);
    return out;
}

function encodeUtf16Le(text) {
    const buf = new Uint8Array(text.length * 2);
    for (let i = 0; i < text.length; i++) {
        const code = text.charCodeAt(i);
        buf[i * 2] = code & 0xff;
        buf[i * 2 + 1] = code >> 8;
    }
    return buf;
}

async function deriveKek(passphraseBytes, salt, iterations, lengthBytes, hashAlgo) {
    const baseKey = await crypto.subtle.importKey(
        'raw',
        passphraseBytes,
        'PBKDF2',
        false,
        ['deriveBits']
    );
    const bits = await crypto.subtle.deriveBits(
        { name: 'PBKDF2', salt: salt, iterations: iterations, hash: hashAlgo },
        baseKey,
        lengthBytes * 8
    );
    return new Uint8Array(bits);
}

async function unwrapKey(kekBytes, wrappedBytes) {
    const kekKey = await crypto.subtle.importKey(
        'raw',
        kekBytes,
        'AES-KW',
        false,
        ['unwrapKey']
    );
    const unwrappedKey = await crypto.subtle.unwrapKey(
        'raw',
        wrappedBytes,
        kekKey,
        'AES-KW',
        { name: 'AES-GCM', length: 256 },
        true,
        ['decrypt']
    );
    const raw = await crypto.subtle.exportKey('raw', unwrappedKey);
    return new Uint8Array(raw);
}

async function decryptNote(aesKeyBytes, iv, tag, ciphertext) {
    const key = await crypto.subtle.importKey(
        'raw',
        aesKeyBytes,
        { name: 'AES-GCM' },
        false,
        ['decrypt']
    );
    const combined = concatBytes(ciphertext, tag);
    const plaintext = await crypto.subtle.decrypt(
        { name: 'AES-GCM', iv: iv, tagLength: 128 },
        key,
        combined
    );
    return new Uint8Array(plaintext);
}

async function gunzipIfNeeded(bytes) {
    if (bytes.length < 3 || bytes[0] !== 0x1f || bytes[1] !== 0x8b || bytes[2] !== 0x08) {
        return bytes;
    }
    if (!('DecompressionStream' in window)) {
        return bytes;
    }
    const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));
    const buffer = await new Response(stream).arrayBuffer();
    return new Uint8Array(buffer);
}

function extractReadableText(text) {
    const matches = text.match(/[\\x20-\\x7E\\n\\r\\t]{20,}/g);
    if (!matches) {
        return text.trim();
    }
    let best = matches[0];
    for (const match of matches) {
        if (match.length > best.length) {
            best = match;
        }
    }
    return best.trim();
}

function scoreText(text) {
    if (!text) {
        return { score: 0, ratio: 0, length: 0, replacementRatio: 0 };
    }
    const printable = text.match(/[\\x20-\\x7E\\n\\r\\t]/g);
    const ratio = printable ? printable.length / text.length : 0;
    const replacements = (text.match(/\\uFFFD/g) || []).length;
    const replacementRatio = text.length ? (replacements / text.length) : 0;
    return {
        score: ratio * text.length,
        ratio: ratio,
        length: text.length,
        replacementRatio: replacementRatio
    };
}

function decodeTextCandidates(bytes) {
    const candidates = [];
    const decoders = [
        { label: 'utf-8', decoder: new TextDecoder('utf-8', { fatal: false }) },
        { label: 'utf-16le', decoder: new TextDecoder('utf-16le', { fatal: false }) },
        { label: 'utf-16be', decoder: new TextDecoder('utf-16be', { fatal: false }) },
    ];
    for (const entry of decoders) {
        try {
            const decoded = entry.decoder.decode(bytes);
            const cleaned = extractReadableText(decoded);
            const metrics = scoreText(cleaned);
            candidates.push({
                label: entry.label,
                text: cleaned,
                score: metrics.score,
                ratio: metrics.ratio,
                length: metrics.length,
                replacementRatio: metrics.replacementRatio
            });
        } catch (err) {
            // ignore
        }
    }
    if (!candidates.length) {
        return null;
    }
    candidates.sort((a, b) => b.score - a.score);
    return candidates[0] || null;
}

function extractProtobufText(bytes) {
    let best = '';
    let bestScore = 0;
    let i = 0;
    while (i < bytes.length) {
        const tag = bytes[i];
        i += 1;
        const wireType = tag & 0x07;
        if (wireType === 2) {
            let length = 0;
            let shift = 0;
            while (i < bytes.length) {
                const byte = bytes[i];
                i += 1;
                length |= (byte & 0x7f) << shift;
                if ((byte & 0x80) === 0) {
                    break;
                }
                shift += 7;
                if (shift > 28) {
                    break;
                }
            }
            if (length > 0 && i + length <= bytes.length) {
                const slice = bytes.slice(i, i + length);
                const decoded = decodeTextCandidates(slice);
                if (decoded && decoded.text) {
                    if (decoded.score > bestScore) {
                        bestScore = decoded.score;
                        best = decoded.text;
                    }
                }
            }
            i += length;
        } else if (wireType === 0) {
            while (i < bytes.length && (bytes[i] & 0x80) !== 0) {
                i += 1;
            }
            i += 1;
        } else if (wireType === 5) {
            i += 4;
        } else if (wireType === 1) {
            i += 8;
        } else {
            break;
        }
    }
    return best || null;
}

function extractPrintableStrings(bytes, minLen=8) {
    const results = [];
    let current = [];
    for (let i = 0; i < bytes.length; i++) {
        const b = bytes[i];
        if ((b >= 0x20 && b <= 0x7e) || b === 0x0a || b === 0x0d || b === 0x09) {
            current.push(String.fromCharCode(b));
        } else {
            if (current.length >= minLen) {
                results.push(current.join(''));
            }
            current = [];
        }
    }
    if (current.length >= minLen) {
        results.push(current.join(''));
    }
    if (!results.length) {
        return null;
    }
    results.sort((a, b) => b.length - a.length);
    return results[0];
}

async function tryDecryptWithKey(keyBytes, iv, tag, ciphertext) {
    try {
        const plaintext = await decryptNote(keyBytes, iv, tag, ciphertext);
        return plaintext;
    } catch (err) {
        return null;
    }
}

async function unlockNote() {
    const payload = document.getElementById('lockedPayload');
    const passphrase = document.getElementById('notePassphrase').value;
    const error = document.getElementById('unlockError');
    const out = document.getElementById('decryptedContent');
    error.style.display = 'none';
    out.textContent = '';

    const iv = b64ToBytes(payload.dataset.iv);
    const tag = b64ToBytes(payload.dataset.tag);
    const salt = b64ToBytes(payload.dataset.salt);
    const wrappedRaw = payload.dataset.wrapped || '';
    const wrappedListRaw = payload.dataset.wrappedList || '';
    const ciphertextPrimary = b64ToBytes(payload.dataset.blob);
    const ciphertextAlt = payload.dataset.blobAlt ? b64ToBytes(payload.dataset.blobAlt) : null;
    const iterations = parseInt(payload.dataset.iter || '0', 10);

    const debugEl = document.getElementById('unlockDebugText');
    const debugLines = [];
    function debug(line) {
        debugLines.push(line);
        if (debugEl) {
            debugEl.textContent = debugLines.join('\\n');
        }
    }

    const wrappedCandidates = [];
    if (wrappedListRaw) {
        try {
            const decoded = atob(wrappedListRaw);
            const parsed = JSON.parse(decoded);
            if (Array.isArray(parsed)) {
                for (const entry of parsed) {
                    if (entry && entry.b64) {
                        wrappedCandidates.push({
                            label: entry.label || 'wrapped',
                            bytes: b64ToBytes(entry.b64)
                        });
                    }
                }
            }
        } catch (err) {
            // ignore parse errors
        }
    }
    if (!wrappedCandidates.length && wrappedRaw) {
        wrappedCandidates.push({ label: 'wrapped', bytes: b64ToBytes(wrappedRaw) });
    }
    const directWrappedCandidates = [];
    for (const entry of wrappedCandidates) {
        if (entry.bytes && (entry.bytes.length === 16 || entry.bytes.length === 32)) {
            directWrappedCandidates.push(entry.bytes);
        }
    }
    const ciphertextCandidates = [];
    if (ciphertextPrimary && ciphertextPrimary.length) {
        ciphertextCandidates.push({ label: 'primary', bytes: ciphertextPrimary });
    }
    if (ciphertextAlt && ciphertextAlt.length) {
        ciphertextCandidates.push({ label: 'alt', bytes: ciphertextAlt });
    }

    debug(`iter=${iterations || '0'}, iv=${iv.length}, tag=${tag.length}, salt=${salt.length}, wrapped=${wrappedCandidates.length}, blob=${ciphertextCandidates.map((c) => c.bytes.length).join('/')}`);

    try {
        let plaintext = null;
        const iterCandidates = iterations > 0 ? [iterations] : [20000, 10000, 50000, 100000, 1000, 5000, 25000];
        const keyCandidates = [];
        const passphraseUtf8 = new TextEncoder().encode(passphrase);
        const passphraseUtf8Nfkd = new TextEncoder().encode(passphrase.normalize('NFKD'));
        const passphraseUtf16 = encodeUtf16Le(passphrase);
        const passphraseUtf16Nfkd = encodeUtf16Le(passphrase.normalize('NFKD'));
        const passphraseUtf16Be = (() => {
            const le = encodeUtf16Le(passphrase);
            const be = new Uint8Array(le.length);
            for (let i = 0; i < le.length; i += 2) {
                be[i] = le[i + 1];
                be[i + 1] = le[i];
            }
            return be;
        })();
        const hashCandidates = ['SHA-256', 'SHA-1', 'SHA-512'];
        const passphraseCandidates = [passphraseUtf8, passphraseUtf8Nfkd, passphraseUtf16, passphraseUtf16Nfkd, passphraseUtf16Be];
        const kekLengths = [16, 24, 32];
        let attempts = 0;
        let unwrapAttempts = 0;

        for (const key of directWrappedCandidates) {
            for (const payload of ciphertextCandidates) {
                attempts++;
                plaintext = await tryDecryptWithKey(key, iv, tag, payload.bytes);
                if (plaintext) {
                    break;
                }
            }
            if (plaintext) {
                break;
            }
        }

        for (const iter of iterCandidates) {
            for (const hashAlgo of hashCandidates) {
                for (const passBytes of passphraseCandidates) {
                    for (const kekLen of kekLengths) {
                        const directKey = await deriveKek(passBytes, salt, iter, kekLen, hashAlgo);
                        for (const payload of ciphertextCandidates) {
                            attempts++;
                            plaintext = await tryDecryptWithKey(directKey, iv, tag, payload.bytes);
                            if (plaintext) {
                                break;
                            }
                        }
                        if (plaintext) {
                            break;
                        }
                        for (const wrappedEntry of wrappedCandidates) {
                            try {
                                unwrapAttempts++;
                                const unwrapped = await unwrapKey(directKey, wrappedEntry.bytes);
                                keyCandidates.push(unwrapped);
                            } catch (err) {
                                // continue
                            }
                        }
                    }
                    if (plaintext) {
                        break;
                    }
                }
                if (plaintext) {
                    break;
                }
            }
            if (plaintext) {
                break;
            }

            for (const key of keyCandidates) {
                for (const payload of ciphertextCandidates) {
                    attempts++;
                    plaintext = await tryDecryptWithKey(key, iv, tag, payload.bytes);
                    if (plaintext) {
                        break;
                    }
                }
                if (plaintext) {
                    break;
                }
            }
            if (plaintext) {
                break;
            }
        }

        debug(`attempts=${attempts}, unwrap_attempts=${unwrapAttempts}, candidates=${keyCandidates.length}`);

        if (!plaintext) {
            throw new Error('decrypt failed');
        }

        plaintext = await gunzipIfNeeded(plaintext);
        let decoded = decodeTextCandidates(plaintext);
        let text = decoded && decoded.text ? decoded.text : null;
        let score = decoded && typeof decoded.score === 'number' ? decoded.score : 0;
        let ratio = decoded && typeof decoded.ratio === 'number' ? decoded.ratio : 0;
        let length = decoded && typeof decoded.length === 'number' ? decoded.length : 0;
        let replacementRatio = decoded && typeof decoded.replacementRatio === 'number' ? decoded.replacementRatio : 0;
        let source = 'decode';
        if (!text) {
            text = extractProtobufText(plaintext);
            const metrics = scoreText(text);
            score = metrics.score;
            ratio = metrics.ratio;
            length = metrics.length;
            replacementRatio = metrics.replacementRatio;
            source = 'protobuf';
        }
        if (!text) {
            text = extractPrintableStrings(plaintext);
            const metrics = scoreText(text);
            score = metrics.score;
            ratio = metrics.ratio;
            length = metrics.length;
            replacementRatio = metrics.replacementRatio;
            source = 'strings';
        }

        let minRatio = 0.6;
        let minLength = 20;
        let maxReplacementRatio = 0.02;
        if (source === 'strings') {
            minRatio = 0.5;
            minLength = 3;
            maxReplacementRatio = 0.05;
        }
        if (!text || ratio < minRatio || length < minLength || replacementRatio > maxReplacementRatio) {
            const hexPreview = Array.from(plaintext.slice(0, 256))
                .map((b) => b.toString(16).padStart(2, '0'))
                .join(' ');
            out.textContent = 'Decrypted, but content appears binary. Use the hex preview below or download the payload.';
            const hexBlock = document.createElement('pre');
            hexBlock.textContent = hexPreview;
            hexBlock.style.marginTop = '12px';
            hexBlock.style.whiteSpace = 'pre-wrap';
            out.appendChild(hexBlock);
            const blob = new Blob([plaintext], { type: 'application/octet-stream' });
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = 'locked_note_decrypted.bin';
            link.textContent = 'Download decrypted payload';
            link.style.display = 'inline-block';
            link.style.marginTop = '10px';
            out.appendChild(link);
        } else {
            out.textContent = text;
            document.querySelector('.unlock-panel').style.display = 'none';
        }
    } catch (err) {
        error.style.display = 'block';
    }
}

document.getElementById('unlockNoteBtn').addEventListener('click', unlockNote);
document.getElementById('notePassphrase').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        unlockNote();
    }
});
</script>
"""

        if self._notes_report_passphrase:
            self._write_encrypted_html(html, filepath, self._notes_report_passphrase, label=note['title'])
        else:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(html)
            self._add_export_bytes(filepath)

    def _export_note_txt(self, note: Dict[str, Any], output_dir: str, index: int):
        """Export single note as plain text file."""
        safe_title = "".join(c for c in note['title'] if c.isalnum() or c in (' ', '-', '_'))[:50]
        filename = f"{index:04d}_{safe_title}.txt"
        filepath = os.path.join(output_dir, filename)

        content = f"""Title: {note['title']}
Folder: {note['folder']}
Account: {note['account']}
Modified: {self._format_timestamp(note['modified'])}

{'=' * 60}

{note['content']}
"""

        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        self._add_export_bytes(filepath)

    def _create_index_html(self, notes: List[Dict[str, Any]], output_dir: str,
                           encrypt_passphrase: Optional[str] = None):
        """Create Notes.html for browsing exported notes with modern styling."""
        from datetime import datetime
        import json
        import re

        # Generate search index data for inlining
        print("Generating search index for full-content search...")
        search_index_data = []
        for i, note in enumerate(notes, 1):
            try:
                safe_title = "".join(c for c in note['title'] if c.isalnum() or c in (' ', '-', '_'))[:50]
                filename = f"{i:04d}_{safe_title}.html"

                if note.get('is_locked'):
                    content = ''
                else:
                    content = note.get('content', '')
                # Strip HTML tags for cleaner text search
                text_content = re.sub(r'<[^>]+>', ' ', content)
                text_content = text_content.replace('&nbsp;', ' ')
                text_content = text_content.replace('&lt;', '<')
                text_content = text_content.replace('&gt;', '>')
                text_content = text_content.replace('&amp;', '&')

                search_index_data.append({
                    'filename': filename,
                    'title': note['title'],
                    'text': text_content
                })
            except Exception as e:
                print(f"Warning: Could not index note {note['title']}: {e}")
                continue

        # Convert to JSON for embedding
        search_index_json = json.dumps({'version': '1.0', 'notes': search_index_data}, ensure_ascii=False)

        html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notes</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: #f6f6f6;
            padding: 20px;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            overflow: hidden;
        }}
        .header {{
            background: linear-gradient(135deg, #E4A711 0%, #FFF238 100%);
            color: white;
            padding: 30px;
            text-align: left;
        }}
        .header h1 {{
            font-size: 32px;
            font-weight: 600;
            margin-bottom: 10px;
        }}
        .breadcrumbs {{
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            letter-spacing: 0.2px;
            color: rgba(255,255,255,0.85);
            margin-bottom: 10px;
        }}
        .breadcrumbs a {{
            color: #fff;
            text-decoration: none;
            font-weight: 600;
        }}
        .breadcrumbs a:hover {{
            text-decoration: underline;
        }}
        .breadcrumbs .back-arrow {{
            opacity: 0.6;
        }}
        .embedded .breadcrumbs {{
            display: none;
        }}
        .header p {{
            font-size: 16px;
            opacity: 0.9;
            margin: 0;
        }}
        .search-box {{
            position: relative;
            padding: 20px;
            border-bottom: 1px solid #e5e5e5;
        }}
        .search-box input {{
            width: 100%;
            padding: 12px 46px 12px 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
        }}
        .search-box input:focus {{
            outline: none;
            border-color: #E4A711;
        }}
        .clear-search {{
            position: absolute;
            right: 24px;
            top: 50%;
            transform: translateY(-50%);
            border: 1px solid #d1d5db;
            background: #f3f4f6;
            color: #111827;
            border-radius: 6px;
            padding: 4px 8px;
            font-size: 12px;
            cursor: pointer;
            display: none;
        }}
        .clear-search.visible {{ display: inline-block; }}
        .note {{
            padding: 15px 20px;
            border-bottom: 1px solid #e5e5e5;
            cursor: pointer;
            transition: background-color 0.2s;
            display: block;
            text-decoration: none;
            color: inherit;
        }}
        .highlight-target {{
            background-color: #fff3cd;
            outline: 2px solid #f59e0b;
        }}
        .note:last-child {{
            border-bottom: none;
        }}
        .note:hover {{
            background-color: #f8f8f8;
        }}
        .note.hidden {{
            display: none;
        }}
        .note-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 6px;
        }}
        .note-title {{
            font-size: 16px;
            font-weight: 600;
            color: #000;
            flex: 1;
        }}
        .note-date {{
            font-size: 14px;
            color: #8E8E93;
            margin-left: 10px;
        }}
        .note-snippet {{
            font-size: 14px;
            color: #8E8E93;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }}
        .note-folder {{
            display: inline-block;
            background-color: #FFD60A;
            color: #000;
            border-radius: 10px;
            padding: 2px 8px;
            font-size: 12px;
            font-weight: 600;
            margin-left: 8px;
        }}
        .note-badge {{
            display: inline-block;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 12px;
            font-weight: 600;
            margin-left: 6px;
        }}
        .badge-attach {{ background: #e8f0fe; color: #1a73e8; }}
        .badge-deleted {{ background: #fde7e9; color: #c62828; }}
        .badge-locked {{ background: #f2e7fe; color: #6d28d9; }}
        .no-results {{
            text-align: center;
            padding: 40px;
            color: #8E8E93;
            font-size: 16px;
            display: none;
        }}
        .no-results.visible {{
            display: block;
        }}
        .export-info {{
            text-align: center;
            padding: 20px;
            color: #8E8E93;
            font-size: 14px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Start_Here.html">Back</a></div>
            <h1>Notes</h1>
            <p>Extracted from iOS Backup on {datetime.now().strftime("%B %d, %Y")}</p>
        </div>

        <div class="search-box">
            <input type="text" id="searchInput" placeholder="Search notes..." onkeyup="filterNotes()">
            <button id="clearSearch" class="clear-search" title="Clear" aria-label="Clear search">X</button>
        </div>

        <div id="noteList">
'''

        # Add each note
        for i, note in enumerate(notes, 1):
            safe_title = "".join(c for c in note['title'] if c.isalnum() or c in (' ', '-', '_'))[:50]
            filename = f"{i:04d}_{safe_title}.html"

            # Escape HTML special characters
            def escape_html(text):
                if not text:
                    return ''
                return (str(text)
                    .replace('&', '&amp;')
                    .replace('<', '&lt;')
                    .replace('>', '&gt;')
                    .replace('"', '&quot;')
                    .replace("'", '&#39;'))

            # Format timestamp
            timestamp_str = ""
            if note['modified']:
                try:
                    timestamp_str = self._format_timestamp(note['modified'])
                except:
                    timestamp_str = ""

            # Snippet
            snippet = note.get('snippet', '')
            if note.get('is_locked'):
                snippet = 'Locked note'
            if len(snippet) > 100:
                snippet = snippet[:100] + '...'

            # Folder badge
            folder_badge = ''
            if note['folder'] and note['folder'] != 'Notes':
                folder_badge = f'<span class="note-folder">{escape_html(note["folder"])}</span>'

            # Attachment / deleted / locked badges
            badge_html = ''
            if note.get('has_attachments'):
                badge_html += '<span class="note-badge badge-attach">Attachments</span>'
            if note.get('is_deleted'):
                badge_html += '<span class="note-badge badge-deleted">Deleted</span>'
            if note.get('is_locked'):
                badge_html += '<span class="note-badge badge-locked">Locked</span>'

            html += f'''            <a href="Individual Notes/{filename}" id="note-{note.get('note_id', i)}" class="note" data-title="{escape_html(note['title'].lower())}" data-snippet="{escape_html(snippet.lower())}" data-filename="{escape_html(filename)}">
                <div class="note-header">
                    <div class="note-title">{escape_html(note['title'])}{folder_badge}{badge_html}</div>
                    <div class="note-date">{timestamp_str}</div>
                </div>
                <div class="note-snippet">{escape_html(snippet)}</div>
            </a>
'''

        html += '''        </div>
        <div class="no-results" id="noResults">No notes found</div>
            <div class="export-info">
                Exported from iOS Backup Manager on ''' + datetime.now().strftime("%B %d, %Y at %I:%M %p") + f'''<br>
                Total notes: {len(notes)}
            </div>
        </div>
    </div>

    <script>
        // Inline search index data (loaded on first use to save initial page load time)
        let searchIndexData = {search_index_json};
        let searchIndex = null;

        // Parse search index on first search (lazy initialization)
        function initSearchIndex() {{
            if (searchIndex) return;
            searchIndex = searchIndexData;
            console.log('Search index initialized:', searchIndex.notes.length, 'notes');
            searchIndexData = null; // Free memory
        }}

        function filterNotes() {{
            const input = document.getElementById('searchInput');
            const filter = input.value.toLowerCase();
            const notes = document.querySelectorAll('.note');
            const noResults = document.getElementById('noResults');

            // Initialize search index if user is typing (lazy init)
            if (filter && !searchIndex) {{
                initSearchIndex();
            }}

            let visibleCount = 0;

            notes.forEach(note => {{
                const title = note.getAttribute('data-title');
                const snippet = note.getAttribute('data-snippet');
                const filename = note.getAttribute('data-filename');

                let matches = false;

                // First check title and snippet (fast)
                if (title.includes(filter) || snippet.includes(filter)) {{
                    matches = true;
                }} else if (searchIndex) {{
                    // Search full content using index
                    const indexEntry = searchIndex.notes.find(n => n.filename === filename);
                    if (indexEntry && indexEntry.text && indexEntry.text.toLowerCase().includes(filter)) {{
                        matches = true;
                    }}
                }}

                if (matches) {{
                    note.classList.remove('hidden');
                    visibleCount++;
                }} else {{
                    note.classList.add('hidden');
                }}
            }});

            if (visibleCount === 0 && filter !== '') {{
                noResults.classList.add('visible');
            }} else {{
                noResults.classList.remove('visible');
            }}
        }}
    </script>
    <script>
        const notesSearchInput = document.getElementById('searchInput');
        const notesClearBtn = document.getElementById('clearSearch');
        if (notesSearchInput && notesClearBtn) {{
            const toggleClear = () => notesClearBtn.classList.toggle('visible', !!notesSearchInput.value);
            notesSearchInput.addEventListener('input', toggleClear);
            notesClearBtn.addEventListener('click', () => {{
                notesSearchInput.value = '';
                toggleClear();
                if (typeof filterNotes === 'function') {{
                    filterNotes();
                }}
                notesSearchInput.focus();
            }});
            toggleClear();
        }}
    </script>
    <script>
        (function() {{
            if (!window.location.hash) return;
            const target = document.querySelector(window.location.hash);
            if (!target) return;
            target.classList.add('highlight-target');
            try {{
                target.scrollIntoView({{ block: 'center' }});
            }} catch (e) {{
                target.scrollIntoView();
            }}
        }})();
    </script>
    <script>
        (function() {{
            try {{
                if (window.parent && window.parent !== window) {{
                    window.parent.postMessage({{type: 'device-nav-root', href: window.location.href}}, '*');
                    window.parent.postMessage({{type: 'device-nav', href: window.location.href}}, '*');
                }}
            }} catch (err) {{}}
        }})();
    </script>
    <script>
        if (window.self !== window.top) {{
            document.body.classList.add('embedded');
        }}
    </script>
</body>
</html>'''

        # Save as Notes.html instead of index.html
        index_path = os.path.join(output_dir, "Notes.html")
        if encrypt_passphrase:
            self._write_encrypted_html(html, index_path, encrypt_passphrase, label="Notes Report")
        else:
            with open(index_path, 'w', encoding='utf-8') as f:
                f.write(html)
            self._add_export_bytes(index_path)

    def _generate_report_passphrase(self) -> str:
        token = secrets.token_urlsafe(18)
        return token.replace('-', '').replace('_', '')

    def _write_encrypted_html(self, html_text: str, output_path: str, passphrase: str, label: str):
        salt = secrets.token_bytes(16)
        nonce = secrets.token_bytes(12)
        iterations = 200000
        key = PBKDF2(passphrase, salt, dkLen=32, count=iterations, hmac_hash_module=SHA256)
        cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
        ciphertext, tag = cipher.encrypt_and_digest(html_text.encode("utf-8"))
        blob = ciphertext + tag
        payload_b64 = base64.b64encode(blob).decode("ascii")
        salt_b64 = base64.b64encode(salt).decode("ascii")
        nonce_b64 = base64.b64encode(nonce).decode("ascii")
        wrapper = self._build_encrypted_wrapper_html(
            label=label,
            payload_b64=payload_b64,
            salt_b64=salt_b64,
            nonce_b64=nonce_b64,
            iterations=iterations
        )
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(wrapper)
        self._add_export_bytes(output_path)

    def _build_encrypted_wrapper_html(self, label: str, payload_b64: str, salt_b64: str,
                                      nonce_b64: str, iterations: int) -> str:
        return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{label} (Locked)</title>
  <style>
    body {{
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      background: #f2f2f7;
      margin: 0;
      color: #1c1c1e;
    }}
    .wrap {{
      max-width: 640px;
      margin: 10vh auto 0;
      background: white;
      padding: 28px;
      border-radius: 16px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.12);
    }}
    h1 {{
      margin: 0 0 8px;
      font-size: 24px;
    }}
    p {{
      margin: 0 0 16px;
      color: #636366;
      line-height: 1.4;
    }}
    input {{
      width: 100%;
      padding: 12px 14px;
      font-size: 16px;
      border-radius: 10px;
      border: 1px solid #d1d1d6;
      box-sizing: border-box;
      margin-bottom: 12px;
    }}
    button {{
      width: 100%;
      padding: 12px 14px;
      font-size: 16px;
      border-radius: 10px;
      border: none;
      background: #007aff;
      color: white;
      cursor: pointer;
    }}
    .error {{
      color: #ff3b30;
      margin-top: 8px;
      display: none;
    }}
  </style>
</head>
<body>
  <div class="wrap">
    <h1>{label} (Locked)</h1>
    <p>This report contains locked notes. Enter the report passphrase to unlock.</p>
    <input type="password" id="passphrase" placeholder="Report passphrase" autofocus>
    <button id="unlockBtn">Unlock</button>
    <div id="error" class="error">Unable to unlock. Check the passphrase.</div>
  </div>
  <script>
    const payloadB64 = "{payload_b64}";
    const saltB64 = "{salt_b64}";
    const nonceB64 = "{nonce_b64}";
    const iterations = {iterations};

    function b64ToBytes(b64) {{
      const binary = atob(b64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) {{
        bytes[i] = binary.charCodeAt(i);
      }}
      return bytes;
    }}

    async function unlock() {{
      const passphrase = document.getElementById('passphrase').value;
      const error = document.getElementById('error');
      error.style.display = 'none';
      try {{
        const enc = b64ToBytes(payloadB64);
        const salt = b64ToBytes(saltB64);
        const nonce = b64ToBytes(nonceB64);
        const baseKey = await crypto.subtle.importKey(
          'raw',
          new TextEncoder().encode(passphrase),
          'PBKDF2',
          false,
          ['deriveKey']
        );
        const key = await crypto.subtle.deriveKey(
          {{
            name: 'PBKDF2',
            salt: salt,
            iterations: iterations,
            hash: 'SHA-256'
          }},
          baseKey,
          {{ name: 'AES-GCM', length: 256 }},
          false,
          ['decrypt']
        );
        const plaintext = await crypto.subtle.decrypt(
          {{
            name: 'AES-GCM',
            iv: nonce
          }},
          key,
          enc
        );
        const html = new TextDecoder().decode(plaintext);
        document.open();
        document.write(html);
        document.close();
      }} catch (err) {{
        error.style.display = 'block';
      }}
    }}

    document.getElementById('unlockBtn').addEventListener('click', unlock);
    document.getElementById('passphrase').addEventListener('keydown', (e) => {{
      if (e.key === 'Enter') {{
        unlock();
      }}
    }});
  </script>
</body>
</html>"""

    def _format_content(self, content: str) -> str:
        """Format note content for HTML display."""
        if not content:
            return '<p><em>No content</em></p>'

        # If content looks like HTML, use it as-is
        if content.strip().startswith('<'):
            return content

        # Otherwise, convert plain text to HTML paragraphs
        paragraphs = content.split('\n\n')
        html_paragraphs = [f'<p>{p.replace(chr(10), "<br>")}</p>' for p in paragraphs if p.strip()]
        return '\n'.join(html_paragraphs)

    def _inline_embed_cid_objects(self, content: str, cid_map: Dict[str, str]) -> str:
        """
        Replace legacy <object data="cid:..."> placeholders with inline images or labels.

        Args:
            content: Original note HTML content
            cid_map: Mapping of cid identifier -> relative attachment path

        Returns:
            Updated HTML content with inline images/labels.
        """
        if not content:
            return content

        try:
            def replace_object(match):
                cid_raw = match.group(1) or ''
                cid_clean = cid_raw.replace('cid:', '').replace('mailto:', '')
                rel_path = cid_map.get(cid_clean)
                if rel_path:
                    return f'<img src="../{rel_path}" class="attachment-inline" alt="Attachment" />'
                return f'<span class="attachment-missing">Attachment not available ({cid_clean})</span>'

            pattern = r'<object[\s\S]*?data=[\'"]([^\'"]+)[\'"][\s\S]*?>\s*(?:</object>|/>)'
            content = re.sub(pattern, replace_object, content, flags=re.IGNORECASE | re.DOTALL)

            # Also handle bare cid-style tokens left in text (e.g., $UUIDcom.apple.m4a-audio)
            def replace_bare(match):
                cid_raw = match.group(1) or ''
                # Strip control/non-filename chars
                cid_clean = re.sub(r'[^0-9A-Za-z@.\-]+', '', cid_raw)
                cid_clean = cid_clean.replace('cid:', '').replace('mailto:', '').lstrip('$')
                rel_path = cid_map.get(cid_clean)
                if rel_path:
                    return f'<span class="attachment-inline-text">Attachment: {os.path.basename(rel_path)}</span>'
                return f'<span class="attachment-missing">Attachment not available ({cid_clean})</span>'

            bare_pattern = r'(?:cid:)?(\$?[0-9A-Fa-f\-]{16,}[\s\S]{0,20}?com\.apple\.[A-Za-z0-9\.-]+)'
            content = re.sub(bare_pattern, replace_bare, content, flags=re.IGNORECASE)

            return content
        except Exception:
            return content

    def _format_timestamp(self, timestamp: Optional[float]) -> str:
        """Format Apple Core Data timestamp for display."""
        if timestamp is None:
            return "N/A"

        try:
            from datetime import datetime, timezone
            # Apple Core Data timestamp is seconds since 2001-01-01
            apple_epoch = datetime(2001, 1, 1, tzinfo=timezone.utc).timestamp()
            unix_timestamp = apple_epoch + timestamp
            dt = datetime.fromtimestamp(unix_timestamp)
            return dt.strftime("%m-%d-%Y %H:%M:%S")
        except:
            return str(timestamp)

    def _format_timestamp_iso(self, timestamp: Optional[float]) -> Optional[str]:
        if timestamp is None:
            return None
        try:
            from datetime import datetime, timezone
            apple_epoch = datetime(2001, 1, 1, tzinfo=timezone.utc).timestamp()
            unix_timestamp = apple_epoch + timestamp
            dt = datetime.fromtimestamp(unix_timestamp, tz=timezone.utc)
            return dt.isoformat()
        except Exception:
            return None

    def _emit_timeline_events(self, items: List[Dict[str, Any]], emitter) -> None:
        for note in items:
            raw_ts = note.get("modified")
            ts_iso = self._format_timestamp_iso(raw_ts)
            if not ts_iso:
                continue
            title = note.get("title") or "Note"
            snippet = note.get("snippet") or ""
            source = note.get("source", "")
            raw_source_path = ""
            if source == "modern":
                raw_source_path = getattr(self, "modern_db_path", "") or ""
            elif source == "legacy":
                raw_source_path = getattr(self, "legacy_db_path", "") or ""
            emitter.emit({
                "timestamp": ts_iso,
                "timestamp_display": ts_iso,
                "timestamp_utc": ts_iso,
                "raw_timestamp": raw_ts,
                "raw_format": "apple_coredata_seconds",
                "source_app": "Notes",
                "source_category": "Notes",
                "event_type": "note_modified",
                "title": title,
                "details": {
                    "title": title,
                    "snippet": snippet[:160],
                    "folder": note.get("folder", ""),
                    "account": note.get("account", ""),
                },
                "confidence": "high",
                "raw_source_path": raw_source_path,
                "report_anchor": f"note-{note.get('note_id', '')}",
                "link_hint": "Notes/Notes.html",
            })

    def get_item_summary(self, item: Dict[str, Any]) -> str:
        """Get short summary for list view."""
        title = item['title']
        folder = item.get('folder', '')

        # Truncate title if too long
        if len(title) > 50:
            title = title[:47] + "..."

        if folder and folder != 'Notes':
            return f"{title} ({folder})"
        return title
