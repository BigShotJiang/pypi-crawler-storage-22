#!/usr/bin/env python3
"""
Reminders data extractor for iOS backups.

Extracts reminders and lists from iOS Reminders app and exports to HTML format.
"""

import sqlite3
import os
import hashlib
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
from .base import CategoryDataExtractor


class RemindersExtractor(CategoryDataExtractor):
    """Extract and export reminders from iOS backup."""

    # Apple's Core Data epoch: 2001-01-01 00:00:00 UTC
    APPLE_EPOCH = datetime(2001, 1, 1)

    def __init__(self, backup_path: str):
        super().__init__(backup_path)

        # Find all Reminders database files
        # iOS stores multiple Data-*.sqlite files in the Reminders domain
        self.db_paths = self._find_all_reminder_databases()

        if not self.db_paths:
            raise FileNotFoundError("Reminders database not found in backup")

    def _find_all_reminder_databases(self) -> List[str]:
        """Find all Data-*.sqlite files in Reminders domain."""
        db_paths = []

        # Search for Data-*.sqlite files in the Reminders app domain
        manifest_path = self.manifest_db_path
        if not os.path.exists(manifest_path):
            return db_paths

        try:
            conn = sqlite3.connect(f"file:{manifest_path}?mode=ro", uri=True)
            cur = conn.cursor()

            cur.execute("""
                SELECT fileID, relativePath
                FROM Files
                WHERE domain = 'AppDomainGroup-group.com.apple.reminders'
                  AND relativePath LIKE 'Container_v1/Stores/Data-%.sqlite'
                  AND relativePath NOT LIKE '%-wal'
                  AND relativePath NOT LIKE '%-shm'
            """)

            for row in cur.fetchall():
                file_id = row[0]
                file_path = self._resolve_file_id_path(file_id)
                if file_path and os.path.exists(file_path):
                    db_paths.append(file_path)

            conn.close()
        except Exception:
            pass

        return db_paths

    @staticmethod
    def _convert_apple_timestamp(timestamp: float) -> Optional[datetime]:
        """Convert Apple Core Data timestamp to Python datetime."""
        if timestamp is None or timestamp == 0:
            return None
        try:
            return RemindersExtractor.APPLE_EPOCH + timedelta(seconds=timestamp)
        except:
            return None

    def get_count(self) -> int:
        """Get total number of reminders across all databases."""
        total_count = 0

        for db_path in self.db_paths:
            try:
                conn = sqlite3.connect(db_path)
                cur = conn.cursor()

                # Count reminders that are not marked for deletion
                cur.execute("""
                    SELECT COUNT(*)
                    FROM ZREMCDREMINDER
                    WHERE ZMARKEDFORDELETION = 0 OR ZMARKEDFORDELETION IS NULL
                """)
                total_count += cur.fetchone()[0]

                conn.close()
            except Exception:
                continue

        return total_count

    def get_items(self, limit: Optional[int] = None, offset: int = 0,
                  search: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get reminders with pagination and optional search.

        Returns list of reminder dictionaries with fields:
        - reminder_id: Unique reminder ID
        - title: Reminder title
        - notes: Reminder notes/description
        - list_name: Name of the list it belongs to
        - list_color: List color
        - completed: Boolean indicating if completed
        - flagged: Boolean indicating if flagged
        - priority: Priority level (0-9)
        - created: Creation datetime
        - modified: Last modified datetime
        - due_date: Due date (if set)
        - start_date: Start date (if set)
        - all_day: Boolean indicating all-day reminder
        """
        all_reminders = []

        for db_path in self.db_paths:
            try:
                conn = sqlite3.connect(db_path)
                conn.row_factory = sqlite3.Row
                cur = conn.cursor()

                # Get reminders with their list information
                query = """
                    SELECT
                        r.Z_PK as reminder_id,
                        r.ZTITLE as title,
                        r.ZNOTES as notes,
                        r.ZCOMPLETED as completed,
                        r.ZFLAGGED as flagged,
                        r.ZPRIORITY as priority,
                        r.ZALLDAY as all_day,
                        r.ZCREATIONDATE as created,
                        r.ZLASTMODIFIEDDATE as modified,
                        r.ZCOMPLETIONDATE as completion_date,
                        r.ZDUEDATE as due_date,
                        r.ZSTARTDATE as start_date,
                        l.ZNAME as list_name
                    FROM ZREMCDREMINDER r
                    LEFT JOIN ZREMCDBASELIST l ON r.ZLIST = l.Z_PK
                    WHERE (r.ZMARKEDFORDELETION = 0 OR r.ZMARKEDFORDELETION IS NULL)
                """

                # Add search filter if provided
                if search:
                    query += """ AND (
                        r.ZTITLE LIKE ? OR
                        r.ZNOTES LIKE ?
                    )"""
                    search_param = f'%{search}%'
                    cur.execute(query, (search_param, search_param))
                else:
                    cur.execute(query)

                for row in cur.fetchall():
                    reminder = {
                        'reminder_id': f"{db_path}_{row['reminder_id']}",  # Unique across DBs
                        'source_db_path': db_path,
                        'title': row['title'] or 'Untitled Reminder',
                        'notes': row['notes'] or '',
                        'list_name': row['list_name'] or 'Reminders',
                        'list_color': '#007AFF',  # Default iOS blue color
                        'completed': bool(row['completed']),
                        'flagged': bool(row['flagged']),
                        'priority': row['priority'] or 0,
                        'all_day': bool(row['all_day']),
                        'created': self._convert_apple_timestamp(row['created']),
                        'modified': self._convert_apple_timestamp(row['modified']),
                        'completion_date': self._convert_apple_timestamp(row['completion_date']),
                        'due_date': self._convert_apple_timestamp(row['due_date']),
                        'start_date': self._convert_apple_timestamp(row['start_date']),
                    }
                    all_reminders.append(reminder)

                conn.close()
            except Exception:
                continue

        # Sort by creation date (newest first)
        all_reminders.sort(key=lambda x: x['created'] if x['created'] else datetime.min, reverse=True)

        # Apply pagination
        if limit:
            return all_reminders[offset:offset + limit]
        return all_reminders[offset:]

    def export(self, items: List[Dict[str, Any]], output_path: str,
               format: str = 'html', progress_callback=None, timeline_emitter=None) -> bool:
        """
        Export reminders to HTML file.

        Args:
            items: List of reminders to export
            output_path: Output directory path
            format: Export format ('html')
            progress_callback: Optional callback(current, total, item_name) -> bool

        Returns:
            True if export succeeded
        """
        if format != 'html':
            raise ValueError(f"Unsupported export format: {format}")

        try:
            self._reset_export_bytes()
            output_dir = output_path
            os.makedirs(output_dir, exist_ok=True)

            total_items = len(items)

            # Report progress - starting
            if progress_callback:
                if not progress_callback(0, total_items, 'Preparing reminders...'):
                    return False  # Cancelled

            # Group reminders by list
            lists = {}
            for idx, reminder in enumerate(items):
                # Report progress for each reminder
                if progress_callback:
                    reminder_title = reminder.get('title', 'Untitled')
                    if not progress_callback(idx + 1, total_items, reminder_title):
                        return False  # Cancelled

                list_name = reminder['list_name']
                if list_name not in lists:
                    lists[list_name] = {
                        'name': list_name,
                        'color': reminder['list_color'],
                        'reminders': []
                    }
                lists[list_name]['reminders'].append(reminder)

            # Create HTML report
            html_path = os.path.join(output_dir, 'Reminders.html')
            self._create_html_report(lists, html_path, items)
            self._add_export_bytes(html_path)

            if timeline_emitter is not None:
                self._emit_timeline_events(items, timeline_emitter)

            # Report progress - completed
            if progress_callback:
                progress_callback(total_items, total_items, 'Export complete')

            return True

        except Exception as e:
            print(f"Error exporting reminders: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _format_timestamp_iso(self, timestamp: Optional[datetime]) -> Optional[str]:
        if not timestamp:
            return None
        return timestamp.isoformat()

    def _make_reminder_anchor(self, reminder_id: str) -> str:
        digest = hashlib.md5(reminder_id.encode('utf-8')).hexdigest()[:12]
        return f"reminder-{digest}"

    def _emit_timeline_events(self, items: List[Dict[str, Any]], timeline_emitter) -> None:
        for reminder in items:
            timestamp = (reminder.get('modified') or reminder.get('created') or
                         reminder.get('due_date') or reminder.get('completion_date') or
                         reminder.get('start_date'))
            ts_iso = self._format_timestamp_iso(timestamp)
            if not ts_iso:
                continue
            details = {
                'list': reminder.get('list_name') or 'Reminders',
                'status': 'completed' if reminder.get('completed') else 'pending',
                'due_date': reminder['due_date'].strftime('%m-%d-%Y %H:%M:%S') if reminder.get('due_date') else '',
                'created': reminder['created'].strftime('%m-%d-%Y %H:%M:%S') if reminder.get('created') else '',
                'modified': reminder['modified'].strftime('%m-%d-%Y %H:%M:%S') if reminder.get('modified') else '',
                'priority': reminder.get('priority') or 0,
                'flagged': bool(reminder.get('flagged')),
            }
            timeline_emitter.emit({
                'timestamp': ts_iso,
                'raw_timestamp': timestamp.isoformat(),
                'raw_format': 'datetime',
                'source_app': 'Reminders',
                'source_category': 'Reminders',
                'event_type': 'reminder',
                'title': reminder.get('title') or 'Untitled Reminder',
                'details': details,
                'confidence': 'medium',
                'raw_source_path': reminder.get('source_db_path') or '',
                'report_anchor': self._make_reminder_anchor(reminder.get('reminder_id', '')),
                'link_hint': 'Reminders/Reminders.html',
            })

    def _create_html_report(self, lists: Dict[str, Dict], output_path: str, all_items: List[Dict]):
        """Create HTML report with all reminders."""

        total_reminders = len(all_items)
        completed_count = sum(1 for r in all_items if r['completed'])
        pending_count = total_reminders - completed_count

        html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Reminders</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: #f5f5f7;
            padding: 20px;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
        }}
        .header {{
            background: linear-gradient(135deg, #B72E1F 0%, #FFC444 100%);
            color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }}
        .header h1 {{
            margin: 0 0 10px 0;
            font-size: 32px;
            font-weight: 600;
        }}
        .breadcrumbs {{
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            letter-spacing: 0.2px;
            color: rgba(255,255,255,0.85);
            margin-bottom: 10px;
        }}
        .breadcrumbs a {{
            color: #fff;
            text-decoration: none;
            font-weight: 600;
        }}
        .breadcrumbs a:hover {{
            text-decoration: underline;
        }}
        .breadcrumbs .back-arrow {{
            opacity: 0.6;
        }}
        .embedded .breadcrumbs {{
            display: none;
        }}
        .header p {{
            margin: 0;
            font-size: 16px;
            opacity: 0.9;
        }}
        .header-total {{
            margin-top: 8px;
            font-size: 14px;
            opacity: 0.85;
        }}
        .stats {{
            color: #6e6e73;
            margin-bottom: 30px;
            font-size: 14px;
        }}
        .filters {{
            background: white;
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }}
        .filter-group {{
            display: flex;
            gap: 15px;
            align-items: center;
            flex-wrap: wrap;
        }}
        .filter-group label {{
            font-weight: 500;
            color: #1d1d1f;
        }}
        .filter-group input[type="text"] {{
            flex: 1;
            padding: 8px 12px;
            border: 1px solid #d2d2d7;
            border-radius: 6px;
            font-size: 14px;
        }}
        .search-field {{
            position: relative;
            flex: 1;
            min-width: 200px;
        }}
        .search-field input[type="text"] {{
            width: 100%;
            padding-right: 42px;
        }}
        .clear-search {{
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            border: 1px solid #d1d5db;
            background: #f3f4f6;
            color: #111827;
            border-radius: 6px;
            padding: 4px 8px;
            font-size: 12px;
            cursor: pointer;
            display: none;
        }}
        .clear-search.visible {{ display: inline-block; }}
        .filter-group select {{
            padding: 8px 12px;
            border: 1px solid #d2d2d7;
            border-radius: 6px;
            font-size: 14px;
            min-width: 150px;
        }}
        @media (max-width: 900px) {{
            .filter-group {{
                flex-direction: column;
                align-items: stretch;
                gap: 10px;
            }}
            .filter-group label {{
                margin-bottom: -6px;
            }}
            .filter-group input[type="text"],
            .filter-group select {{
                width: 100%;
                min-width: 0;
            }}
        }}
        .list-section {{
            background: white;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            overflow: hidden;
        }}
        .list-header {{
            padding: 15px 20px;
            border-bottom: 1px solid #e5e5e7;
            display: flex;
            align-items: center;
            gap: 10px;
        }}
        .list-indicator {{
            width: 12px;
            height: 12px;
            border-radius: 50%;
        }}
        .list-title {{
            font-weight: 600;
            font-size: 18px;
            color: #1d1d1f;
        }}
        .list-count {{
            margin-left: auto;
            color: #6e6e73;
            font-size: 14px;
        }}
        .reminder {{
            padding: 15px 20px;
            border-bottom: 1px solid #f5f5f7;
            display: flex;
            gap: 15px;
            align-items: flex-start;
            transition: background 0.2s;
        }}
        .highlight-target {{
            background-color: #fff3cd;
            outline: 2px solid #f59e0b;
        }}
        .reminder:last-child {{
            border-bottom: none;
        }}
        .reminder:hover {{
            background: #f9f9f9;
        }}
        .reminder.completed {{
            opacity: 0.6;
        }}
        .checkbox {{
            width: 20px;
            height: 20px;
            border: 2px solid #d2d2d7;
            border-radius: 50%;
            flex-shrink: 0;
            margin-top: 2px;
            position: relative;
        }}
        .reminder.completed .checkbox {{
            background: #34c759;
            border-color: #34c759;
        }}
        .reminder.completed .checkbox::after {{
            content: '✓';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
            font-size: 14px;
            font-weight: bold;
        }}
        .reminder-content {{
            flex: 1;
        }}
        .reminder-title {{
            font-size: 15px;
            color: #1d1d1f;
            margin-bottom: 4px;
            font-weight: 500;
        }}
        .reminder.completed .reminder-title {{
            text-decoration: line-through;
        }}
        .reminder-notes {{
            font-size: 13px;
            color: #6e6e73;
            margin-bottom: 6px;
            white-space: pre-wrap;
        }}
        .reminder-meta {{
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            font-size: 12px;
            color: #86868b;
        }}
        .meta-item {{
            display: flex;
            align-items: center;
            gap: 4px;
        }}
        .flagged {{
            color: #ff9500;
        }}
        .priority-high {{
            color: #ff3b30;
            font-weight: 600;
        }}
        .due-date {{
            color: #007aff;
        }}
        .due-date.overdue {{
            color: #ff3b30;
        }}
        .empty-state {{
            text-align: center;
            padding: 60px 20px;
            color: #6e6e73;
        }}
        .empty-state h3 {{
            font-size: 20px;
            margin-bottom: 8px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Start_Here.html">Back</a></div>
            <h1>Reminders</h1>
            <p>Extracted from iOS Backup on {datetime.now().strftime("%B %d, %Y")}</p>
            <div class="header-total">{total_reminders} total &#183; {pending_count} pending &#183; {completed_count} completed</div>
        </div>

        <div class="filters">
            <div class="filter-group">
                <label>Search:</label>
                <div class="search-field">
                    <input type="text" id="searchInput" placeholder="Search reminders...">
                    <button id="clearSearch" class="clear-search" title="Clear" aria-label="Clear search">X</button>
                </div>
                <label>Show:</label>
                <select id="statusFilter">
                    <option value="all">All Reminders</option>
                    <option value="pending">Pending</option>
                    <option value="completed">Completed</option>
                </select>
                <label>List:</label>
                <select id="listFilter">
                    <option value="all">All Lists</option>
"""

        # Add list options
        for list_name in sorted(lists.keys()):
            html += f'                    <option value="{list_name}">{list_name}</option>\n'

        html += """                </select>
            </div>
        </div>

        <div id="reminderContainer">
"""

        # Add each list section
        for list_name in sorted(lists.keys()):
            list_data = lists[list_name]
            reminders = list_data['reminders']
            color = list_data['color']

            html += f"""
            <div class="list-section" data-list="{list_name}">
                <div class="list-header">
                    <div class="list-indicator" style="background-color: {color};"></div>
                    <div class="list-title">{list_name}</div>
                    <div class="list-count">{len(reminders)} reminder{'s' if len(reminders) != 1 else ''}</div>
                </div>
"""

            for reminder in reminders:
                completed_class = 'completed' if reminder['completed'] else ''
                flagged_icon = '🚩 ' if reminder['flagged'] else ''

                # Format dates
                meta_items = []

                if reminder['due_date']:
                    due_str = reminder['due_date'].strftime('%b %d, %Y')
                    is_overdue = not reminder['completed'] and reminder['due_date'] < datetime.now()
                    overdue_class = 'overdue' if is_overdue else ''
                    meta_items.append(f'<span class="meta-item due-date {overdue_class}">📅 Due: {due_str}</span>')

                if reminder['priority'] and reminder['priority'] > 0:
                    priority_class = 'priority-high' if reminder['priority'] >= 5 else ''
                    meta_items.append(f'<span class="meta-item {priority_class}">Priority: {reminder["priority"]}</span>')

                if reminder['created']:
                    created_str = reminder['created'].strftime('%b %d, %Y')
                    meta_items.append(f'<span class="meta-item">Created: {created_str}</span>')

                meta_html = ' '.join(meta_items) if meta_items else ''
                notes_html = f'<div class="reminder-notes">{reminder["notes"]}</div>' if reminder['notes'] else ''

                html += f"""
                <div class="reminder {completed_class}" id="{self._make_reminder_anchor(reminder['reminder_id'])}" data-completed="{str(reminder['completed']).lower()}">
                    <div class="checkbox"></div>
                    <div class="reminder-content">
                        <div class="reminder-title">{flagged_icon}{reminder['title']}</div>
                        {notes_html}
                        <div class="reminder-meta">{meta_html}</div>
                    </div>
                </div>
"""

            html += """
            </div>
"""

        html += """
        </div>
    </div>

    <script>
        // Filter functionality
        const searchInput = document.getElementById('searchInput');
        const statusFilter = document.getElementById('statusFilter');
        const listFilter = document.getElementById('listFilter');

        function filterReminders() {
            const searchTerm = searchInput.value.toLowerCase();
            const statusValue = statusFilter.value;
            const listValue = listFilter.value;

            const sections = document.querySelectorAll('.list-section');

            sections.forEach(section => {
                const listName = section.dataset.list;
                const reminders = section.querySelectorAll('.reminder');
                let visibleCount = 0;

                // Check if this list should be shown
                if (listValue !== 'all' && listName !== listValue) {
                    section.style.display = 'none';
                    return;
                }

                reminders.forEach(reminder => {
                    const title = reminder.querySelector('.reminder-title').textContent.toLowerCase();
                    const notes = reminder.querySelector('.reminder-notes')?.textContent.toLowerCase() || '';
                    const isCompleted = reminder.dataset.completed === 'true';

                    let show = true;

                    // Apply search filter
                    if (searchTerm && !title.includes(searchTerm) && !notes.includes(searchTerm)) {
                        show = false;
                    }

                    // Apply status filter
                    if (statusValue === 'pending' && isCompleted) {
                        show = false;
                    } else if (statusValue === 'completed' && !isCompleted) {
                        show = false;
                    }

                    reminder.style.display = show ? 'flex' : 'none';
                    if (show) visibleCount++;
                });

                // Hide section if no reminders are visible
                section.style.display = visibleCount > 0 ? 'block' : 'none';
            });
        }

        searchInput.addEventListener('input', filterReminders);
        statusFilter.addEventListener('change', filterReminders);
        listFilter.addEventListener('change', filterReminders);
        const clearBtn = document.getElementById('clearSearch');
        if (clearBtn && searchInput) {
            const toggleClear = () => clearBtn.classList.toggle('visible', !!searchInput.value);
            searchInput.addEventListener('input', toggleClear);
            clearBtn.addEventListener('click', () => {
                searchInput.value = '';
                toggleClear();
                filterReminders();
                searchInput.focus();
            });
            toggleClear();
        }
    </script>
    <script>
        (function() {
            if (!window.location.hash) return;
            const target = document.querySelector(window.location.hash);
            if (!target) return;
            target.classList.add('highlight-target');
            try {
                target.scrollIntoView({ block: 'center' });
            } catch (e) {
                target.scrollIntoView();
            }
        })();
    </script>
<script>
    if (window.self !== window.top) {{
        document.body.classList.add('embedded');
    }}
</script>
</body>
</html>"""

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html)

    def _format_timestamp(self, dt: Optional[datetime]) -> str:
        """Format datetime for display."""
        if not dt:
            return 'N/A'
        return dt.strftime('%B %d, %Y at %I:%M %p')

    def get_item_summary(self, item: Dict[str, Any]) -> str:
        """Get a short summary string for displaying in list view."""
        title = item.get('title', 'Untitled')
        list_name = item.get('list_name', 'Reminders')
        status = '[✓] ' if item.get('completed') else '[ ] '

        summary = f"{status}{title} ({list_name})"

        # Add due date if present
        if item.get('due_date'):
            due_str = item['due_date'].strftime('%m/%d/%Y')
            summary += f" - Due: {due_str}"

        return summary
