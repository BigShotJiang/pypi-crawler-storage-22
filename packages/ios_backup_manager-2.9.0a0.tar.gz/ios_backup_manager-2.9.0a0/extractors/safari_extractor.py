#!/usr/bin/env python3
"""
Safari Bookmarks Extractor

Extracts Safari bookmarks from iOS backup and generates HTML reports.
"""
import os
import sqlite3
from typing import Dict, Any, List, Optional
from datetime import datetime

from .base import CategoryDataExtractor


class SafariExtractor(CategoryDataExtractor):
    """
    Extractor for Safari bookmarks from iOS backups.

    Extracts bookmarks from HomeDomain/Library/Safari/Bookmarks.db
    and generates an HTML report organized by folders.
    """

    # Safari bookmarks database location
    SAFARI_DOMAIN = "HomeDomain"
    SAFARI_DB_PATH = "Library/Safari/Bookmarks.db"

    # Bookmark types
    TYPE_BOOKMARK = 0
    TYPE_FOLDER = 1

    def __init__(self, backup_path: str):
        """Initialize Safari extractor."""
        super().__init__(backup_path)
        self.bookmarks_db_path = None
        self._initialize()

    def _initialize(self):
        """Find and verify Safari bookmarks database."""
        self.bookmarks_db_path = self.find_file_in_backup(
            self.SAFARI_DOMAIN,
            self.SAFARI_DB_PATH
        )

        if not self.bookmarks_db_path:
            raise FileNotFoundError("Safari bookmarks database not found in backup")

    def get_count(self) -> int:
        """
        Get total count of bookmarks (excluding folders and Reading List).

        Returns:
            Number of bookmarks
        """
        try:
            conn = sqlite3.connect(f"file:{self.bookmarks_db_path}?mode=ro", uri=True)
            cur = conn.cursor()

            # Count bookmarks (type=0), excluding Reading List and Frequently Visited
            cur.execute("""
                SELECT COUNT(*)
                FROM bookmarks
                WHERE type = ?
                AND parent NOT IN (2, 3)
                AND deleted = 0
            """, (self.TYPE_BOOKMARK,))

            count = cur.fetchone()[0]
            conn.close()

            return count
        except Exception as e:
            print(f"[ERROR] Failed to count bookmarks: {e}")
            return 0

    def get_items(self, limit: Optional[int] = None, offset: int = 0) -> List[Dict[str, Any]]:
        """
        Get bookmarks for summary/counting.

        Returns:
            List of bookmark items
        """
        try:
            conn = sqlite3.connect(f"file:{self.bookmarks_db_path}?mode=ro", uri=True)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()

            # Get all bookmarks (excluding Reading List and Frequently Visited)
            cur.execute("""
                SELECT
                    id,
                    parent,
                    title,
                    url,
                    order_index,
                    last_modified
                FROM bookmarks
                WHERE type = ?
                AND parent NOT IN (2, 3)
                AND deleted = 0
                ORDER BY parent, order_index
            """, (self.TYPE_BOOKMARK,))

            bookmarks = []
            for row in cur.fetchall():
                bookmark = {
                    'id': row['id'],
                    'parent': row['parent'],
                    'title': row['title'] or 'Untitled',
                    'url': row['url'] or '',
                    'order_index': row['order_index'],
                    'last_modified': row['last_modified']
                }
                bookmarks.append(bookmark)

            conn.close()

            # Apply limit/offset if specified
            if limit is not None:
                bookmarks = bookmarks[offset:offset + limit]

            return bookmarks
        except Exception as e:
            print(f"[ERROR] Failed to get bookmarks: {e}")
            return []

    def get_item_summary(self, item: Dict[str, Any]) -> str:
        """Generate summary string for a bookmark folder."""
        title = item.get('title', 'Untitled')
        url = item.get('url', '')
        return f"{title} - {url}"

    def export(self, items: List[Dict[str, Any]], output_path: str, format: str = 'html',
               progress_callback=None, timeline_emitter=None) -> bool:
        """
        Export Safari bookmarks to HTML.

        Args:
            items: List of bookmark folders from get_items()
            output_path: Output directory path
            format: Export format ('html')
            progress_callback: Optional callback(current, total, item_name) -> bool

        Returns:
            True if export succeeded
        """
        if format != 'html':
            raise ValueError(f"Unsupported export format: {format}")

        try:
            self._reset_export_bytes()
            # Create output directory
            os.makedirs(output_path, exist_ok=True)

            # Open bookmarks database
            conn = sqlite3.connect(f"file:{self.bookmarks_db_path}?mode=ro", uri=True)
            conn.row_factory = sqlite3.Row

            # Get all bookmarks organized by folder
            bookmarks_by_folder = self._get_all_bookmarks(conn)

            # Generate HTML report
            self._generate_bookmarks_html(output_path, bookmarks_by_folder, progress_callback)
            self._add_export_bytes(os.path.join(output_path, 'Safari.html'))

            if timeline_emitter is not None:
                self._emit_timeline_events(bookmarks_by_folder, timeline_emitter)

            conn.close()
            return True

        except Exception as e:
            print(f"[ERROR] Failed to export bookmarks: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _get_all_bookmarks(self, conn: sqlite3.Connection) -> Dict[int, List[Dict[str, Any]]]:
        """
        Get all bookmarks organized by folder ID.

        Returns:
            Dict mapping folder_id to list of bookmarks
        """
        cur = conn.cursor()

        # Get all bookmarks (excluding Reading List and Frequently Visited)
        cur.execute("""
            SELECT
                id,
                parent,
                title,
                url,
                order_index,
                last_modified
            FROM bookmarks
            WHERE type = ?
            AND parent NOT IN (2, 3)
            AND deleted = 0
            ORDER BY parent, order_index
        """, (self.TYPE_BOOKMARK,))

        bookmarks_by_folder = {}
        for row in cur.fetchall():
            parent_id = row['parent']

            if parent_id not in bookmarks_by_folder:
                bookmarks_by_folder[parent_id] = []

            bookmark = {
                'id': row['id'],
                'title': row['title'] or 'Untitled',
                'url': row['url'] or '',
                'order_index': row['order_index'],
                'last_modified': row['last_modified']
            }
            bookmarks_by_folder[parent_id].append(bookmark)

        return bookmarks_by_folder

    def _get_folder_name(self, conn: sqlite3.Connection, folder_id: int) -> str:
        """Get folder name by ID."""
        cur = conn.cursor()
        cur.execute("SELECT title FROM bookmarks WHERE id = ?", (folder_id,))
        row = cur.fetchone()

        if row and row['title']:
            # Map special folder names
            if row['title'] == 'BookmarksBar':
                return 'Favorites'
            elif row['title'] == 'BookmarksMenu':
                return 'Bookmarks Menu'
            return row['title']

        return 'Untitled Folder'

    def _format_timestamp_iso(self, timestamp: Optional[float]) -> Optional[str]:
        if timestamp is None:
            return None
        try:
            ts = float(timestamp)
        except Exception:
            return None
        try:
            if ts > 1_000_000_000:
                return datetime.fromtimestamp(ts).isoformat()
            if ts > 0:
                apple_epoch = datetime(2001, 1, 1).timestamp()
                return datetime.fromtimestamp(apple_epoch + ts).isoformat()
        except Exception:
            return None
        return None

    def _emit_timeline_events(self, bookmarks_by_folder: Dict[int, List[Dict[str, Any]]], timeline_emitter) -> None:
        for bookmarks in bookmarks_by_folder.values():
            for bookmark in bookmarks:
                ts_iso = self._format_timestamp_iso(bookmark.get('last_modified'))
                if not ts_iso:
                    continue
                details = {
                    'url': bookmark.get('url') or '',
                    'title': bookmark.get('title') or '',
                }
                timeline_emitter.emit({
                    'timestamp': ts_iso,
                    'raw_timestamp': bookmark.get('last_modified'),
                    'raw_format': 'apple_epoch_seconds',
                    'source_app': 'Safari',
                    'source_category': 'Safari',
                    'event_type': 'bookmark_added',
                    'title': bookmark.get('title') or 'Safari Bookmark',
                    'details': details,
                    'confidence': 'medium',
                    'raw_source_path': self.bookmarks_db_path,
                    'report_anchor': f"bookmark-{bookmark.get('id')}",
                    'link_hint': 'Safari/Safari.html',
                })

    def _generate_bookmarks_html(self, output_path: str, bookmarks_by_folder: Dict[int, List[Dict[str, Any]]],
                                 progress_callback=None):
        """Generate HTML report for bookmarks."""
        html_path = os.path.join(output_path, 'Safari.html')

        # Open database to get folder names
        conn = sqlite3.connect(f"file:{self.bookmarks_db_path}?mode=ro", uri=True)
        conn.row_factory = sqlite3.Row

        # Start HTML
        html = """<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Safari Bookmarks</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: #f6f6f6;
            padding: 20px;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #810102 0%, #FE080A 100%);
            color: white;
            padding: 30px;
            text-align: left;
        }
        .header h1 {
            margin: 0 0 10px 0;
            font-size: 32px;
            font-weight: 600;
        }
        .breadcrumbs {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            letter-spacing: 0.2px;
            color: rgba(255,255,255,0.85);
            margin-bottom: 10px;
        }
        .breadcrumbs a {
            color: #fff;
            text-decoration: none;
            font-weight: 600;
        }
        .breadcrumbs a:hover {
            text-decoration: underline;
        }
        .breadcrumbs .back-arrow {
            opacity: 0.6;
        }
        .embedded .breadcrumbs {
            display: none;
        }
        .header p {
            opacity: 0.9;
            font-size: 16px;
            margin: 0;
        }
        .search-box {
            position: relative;
            padding: 20px;
            border-bottom: 1px solid #e5e5e5;
        }
        .search-box input {
            width: 100%;
            padding: 12px 46px 12px 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            box-sizing: border-box;
        }
        .search-box input:focus {
            outline: none;
            border-color: #810102;
        }
        .clear-search {
            position: absolute;
            right: 24px;
            top: 50%;
            transform: translateY(-50%);
            border: 1px solid #d1d5db;
            background: #f3f4f6;
            color: #111827;
            border-radius: 6px;
            padding: 4px 8px;
            font-size: 12px;
            cursor: pointer;
            display: none;
        }
        .clear-search.visible { display: inline-block; }
        .no-results {
            display: none;
            text-align: center;
            padding: 40px;
            color: #999;
            font-size: 16px;
        }
        .folder {
            background: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .folder-title {
            font-size: 20px;
            font-weight: 600;
            color: #333;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #810102;
        }
        .folder-badge {
            display: inline-block;
            background: #810102;
            color: white;
            padding: 3px 10px;
            border-radius: 12px;
            font-size: 12px;
            margin-left: 10px;
            font-weight: normal;
        }
        .bookmark {
            padding: 12px 0;
            border-bottom: 1px solid #eee;
        }
        .bookmark:last-child {
            border-bottom: none;
        }
        .bookmark-title {
            font-size: 15px;
            font-weight: 500;
            color: #333;
            margin-bottom: 4px;
        }
        .bookmark-link {
            color: #810102;
            text-decoration: none;
            font-size: 14px;
            word-break: break-all;
        }
        .bookmark-link:hover {
            text-decoration: underline;
        }
        .empty-folder {
            color: #999;
            font-style: italic;
            padding: 10px 0;
        }
        .stats {
            background: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }
        .stat-item {
            text-align: center;
        }
        .stat-value {
            font-size: 32px;
            font-weight: 600;
            color: #810102;
        }
        .stat-label {
            font-size: 14px;
            color: #666;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Start_Here.html">Back</a></div>
            <h1>Safari Bookmarks</h1>
            <p>Extracted from iOS Backup on """ + datetime.now().strftime("%B %d, %Y") + """</p>
        </div>

        <div class="search-box">
            <input type="text" id="searchInput" placeholder="Search bookmarks by title or URL..." onkeyup="filterBookmarks()">
            <button id="clearSearch" class="clear-search" title="Clear" aria-label="Clear search">X</button>
        </div>
"""

        # Calculate statistics
        total_bookmarks = sum(len(bookmarks) for bookmarks in bookmarks_by_folder.values())
        total_folders = len(bookmarks_by_folder)

        html += f"""
        <div id="bookmarkContent">
            <div class="stats">
                <div class="stats-grid">
                    <div class="stat-item">
                        <div class="stat-value">{total_bookmarks}</div>
                        <div class="stat-label">Total Bookmarks</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value">{total_folders}</div>
                        <div class="stat-label">Folders</div>
                    </div>
                </div>
            </div>
"""

        # Generate bookmarks by folder
        folder_index = 0
        for folder_id in sorted(bookmarks_by_folder.keys()):
            bookmarks = bookmarks_by_folder[folder_id]
            folder_name = self._get_folder_name(conn, folder_id)

            folder_index += 1
            if progress_callback:
                if not progress_callback(folder_index, total_folders, folder_name):
                    break  # Cancelled

            html += f"""
    <div class="folder">
        <h2 class="folder-title">📁 {self._escape_html(folder_name)} <span class="folder-badge">{len(bookmarks)}</span></h2>
"""

            if bookmarks:
                for bookmark in bookmarks:
                    title = self._escape_html(bookmark['title'])
                    url = self._escape_html(bookmark['url'])

                    html += f"""
        <div class="bookmark" id="bookmark-{bookmark['id']}">
            <div class="bookmark-title">{title}</div>
            <a href="{url}" target="_blank" class="bookmark-link">{url}</a>
        </div>
"""
            else:
                html += """
        <div class="empty-folder">No bookmarks in this folder</div>
"""

            html += """
    </div>
"""

        # Close HTML
        html += """
        </div>  <!-- Close bookmarkContent -->
        <div class="no-results" id="noResults">No bookmarks found</div>
    </div>  <!-- Close container -->

    <script>
        function filterBookmarks() {
            const input = document.getElementById('searchInput');
            const filter = input.value.toLowerCase();
            const content = document.getElementById('bookmarkContent');
            const folders = content.querySelectorAll('.folder');
            const noResults = document.getElementById('noResults');

            let visibleCount = 0;

            folders.forEach(folder => {
                const bookmarks = folder.querySelectorAll('.bookmark');
                let folderHasVisibleBookmarks = false;

                bookmarks.forEach(bookmark => {
                    const title = bookmark.querySelector('.bookmark-title').textContent.toLowerCase();
                    const url = bookmark.querySelector('.bookmark-link').textContent.toLowerCase();

                    if (title.includes(filter) || url.includes(filter)) {
                        bookmark.style.display = '';
                        folderHasVisibleBookmarks = true;
                        visibleCount++;
                    } else {
                        bookmark.style.display = 'none';
                    }
                });

                // Show folder if it has visible bookmarks, hide if not
                if (folderHasVisibleBookmarks) {
                    folder.style.display = '';
                } else {
                    folder.style.display = 'none';
                }
            });

            // Show "no results" message if nothing is visible
            if (visibleCount === 0) {
                noResults.style.display = 'block';
                content.style.display = 'none';
            } else {
                noResults.style.display = 'none';
                content.style.display = 'block';
            }
        }
    </script>
    <script>
        const safariSearchInput = document.getElementById('searchInput');
        const safariClearBtn = document.getElementById('clearSearch');
        if (safariSearchInput && safariClearBtn) {
            const toggleClear = () => safariClearBtn.classList.toggle('visible', !!safariSearchInput.value);
            safariSearchInput.addEventListener('input', toggleClear);
            safariClearBtn.addEventListener('click', () => {
                safariSearchInput.value = '';
                toggleClear();
                if (typeof filterBookmarks === 'function') {
                    filterBookmarks();
                }
                safariSearchInput.focus();
            });
            toggleClear();
        }
    </script>
<script>
    if (window.self !== window.top) {
        document.body.classList.add('embedded');
    }
</script>
</body>
</html>
"""

        # Write to file
        with open(html_path, 'w', encoding='utf-8') as f:
            f.write(html)

        conn.close()

    def _escape_html(self, text: str) -> str:
        """Escape HTML special characters."""
        if not text:
            return ""
        return (text
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace('"', "&quot;")
                .replace("'", "&#39;"))
