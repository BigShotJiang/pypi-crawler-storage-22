#!/usr/bin/env python3
"""
Screen Time extractor for iOS backups.

Discovers Screen Time artifacts in Manifest.db, parses RMAdminStore databases,
and generates an HTML report with corroboration from knowledgeC.db when present.
"""

import hashlib
import os
import sqlite3
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from .base import CategoryDataExtractor


class ScreenTimeExtractor(CategoryDataExtractor):
    """Extract Screen Time artifacts from iOS backups."""

    _APPLE_EPOCH = datetime(2001, 1, 1)
    _MAX_TABLE_SCAN = 50000
    _MAX_TIMELINE_ROWS = 5000

    def __init__(self, backup_path: str):
        super().__init__(backup_path)
        self._artifacts = self._discover_artifacts()
        self._rm_local = self._pick_artifact("RMAdminStore-Local.sqlite")
        self._rm_cloud = self._pick_artifact("RMAdminStore-Cloud.sqlite")
        self._knowledge = self._pick_knowledge_artifact()
        self._cached_data: Optional[Dict[str, Any]] = None
        if not self._rm_local and not self._rm_cloud and not self._knowledge:
            raise FileNotFoundError("Screen Time artifacts not found in backup")

    def _discover_artifacts(self) -> List[Dict[str, Any]]:
        artifacts: List[Dict[str, Any]] = []
        manifest = self.manifest_db_path
        if not os.path.exists(manifest):
            return artifacts

        try:
            conn = sqlite3.connect(f"file:{manifest}?mode=ro", uri=True)
            cur = conn.cursor()
            cur.execute("""
                SELECT domain, relativePath, fileID, file
                FROM Files
                WHERE lower(relativePath) LIKE '%rmadminstore%'
                   OR lower(relativePath) LIKE '%remotemanagementd%'
                   OR lower(relativePath) LIKE '%screentime%'
                   OR lower(relativePath) LIKE '%knowledg%'
                   OR lower(relativePath) LIKE '%coreduet%'
            """)
            rows = cur.fetchall()
        except Exception:
            return artifacts
        finally:
            try:
                conn.close()
            except Exception:
                pass

        for domain, relpath, file_id, file_bplist in rows:
            if not relpath:
                continue
            resolved = self._resolve_file_id_path(file_id, file_bplist=file_bplist)
            size = os.path.getsize(resolved) if resolved and os.path.exists(resolved) else None
            artifacts.append({
                "domain": domain or "",
                "relative_path": relpath,
                "file_id": file_id,
                "path": resolved,
                "size": size,
            })

        if artifacts:
            print("[ScreenTime] Artifact inventory:")
            for entry in artifacts:
                print(
                    f"  {entry['domain']} | {entry['relative_path']} | "
                    f"{entry['file_id']} | {entry.get('size') or 'n/a'} bytes"
                )
        else:
            print("[ScreenTime] No artifacts matched discovery patterns.")

        return artifacts

    def _pick_artifact(self, filename: str) -> Optional[Dict[str, Any]]:
        filename_lower = filename.lower()
        for entry in self._artifacts:
            if entry["relative_path"].lower().endswith(filename_lower):
                return entry
        for entry in self._artifacts:
            if filename_lower in entry["relative_path"].lower():
                return entry
        return None

    def _pick_knowledge_artifact(self) -> Optional[Dict[str, Any]]:
        for entry in self._artifacts:
            if entry["relative_path"].lower().endswith("knowledgec.db"):
                return entry
        for entry in self._artifacts:
            if "knowledge" in entry["relative_path"].lower():
                if entry["relative_path"].lower().endswith(".db"):
                    return entry
        return None

    def _sha256(self, path: Optional[str]) -> str:
        if not path or not os.path.exists(path):
            return ""
        h = hashlib.sha256()
        try:
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(1024 * 1024), b""):
                    h.update(chunk)
        except Exception:
            return ""
        return h.hexdigest()

    def _normalize_timestamp(self, value: Any) -> Optional[int]:
        try:
            ts = float(value)
        except Exception:
            return None
        if ts <= 0:
            return None
        if ts > 1e12:
            return int(ts / 1000)
        if ts > 1e10:
            return int(ts)
        if ts > 1e9:
            return int(ts)
        if ts > 1e6:
            return int((self._APPLE_EPOCH + timedelta(seconds=ts)).timestamp())
        return None

    def _format_duration(self, seconds: Optional[float]) -> str:
        if seconds is None:
            return ""
        try:
            seconds = float(seconds)
        except Exception:
            return ""
        if seconds < 0:
            return ""
        minutes, sec = divmod(int(seconds), 60)
        hours, minutes = divmod(minutes, 60)
        if hours:
            return f"{hours}h {minutes}m"
        if minutes:
            return f"{minutes}m {sec}s"
        return f"{sec}s"

    def _bundle_like(self, value: Any) -> bool:
        if not value:
            return False
        if isinstance(value, (bytes, bytearray)):
            try:
                value = value.decode("utf-8", errors="ignore")
            except Exception:
                return False
        text = str(value)
        if "." not in text:
            return False
        if " " in text:
            return False
        return 3 <= len(text) <= 200

    def _find_columns(self, columns: List[str], keywords: List[str]) -> Optional[str]:
        for col in columns:
            name = col.lower()
            if any(key in name for key in keywords):
                return col
        return None

    def _parse_rmadminstore(self, entry: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        results = {
            "available": False,
            "tables_used": [],
            "per_app": [],
            "per_day": [],
            "pickups": [],
            "notifications": [],
        }
        if not entry or not entry.get("path") or not os.path.exists(entry["path"]):
            return results

        path = entry["path"]
        results["available"] = True
        try:
            conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = [row[0] for row in cur.fetchall()]
        except Exception:
            return results

        best_usage = None
        best_rows = 0
        per_app_totals = {}
        per_day_totals = {}

        for table in tables:
            try:
                cur.execute(f"PRAGMA table_info(\"{table}\")")
                columns = [row[1] for row in cur.fetchall()]
            except Exception:
                continue

            bundle_col = self._find_columns(columns, ["bundle", "identifier", "app"])
            duration_col = self._find_columns(columns, ["duration", "seconds", "usage", "time", "total"])
            start_col = self._find_columns(columns, ["start", "begin"])
            end_col = self._find_columns(columns, ["end", "finish"])
            date_col = self._find_columns(columns, ["date", "day", "timestamp"])

            if not bundle_col or not (duration_col or (start_col and end_col) or date_col):
                continue

            select_cols = [bundle_col]
            if duration_col:
                select_cols.append(duration_col)
            if start_col:
                select_cols.append(start_col)
            if end_col:
                select_cols.append(end_col)
            if date_col and date_col not in select_cols:
                select_cols.append(date_col)

            query = f"SELECT {', '.join([f'\"{c}\"' for c in select_cols])} FROM \"{table}\" LIMIT {self._MAX_TABLE_SCAN}"
            try:
                cur.execute(query)
                rows = cur.fetchall()
            except Exception:
                continue

            matched_rows = 0
            table_per_app = {}
            table_per_day = {}

            for row in rows:
                bundle_val = row[bundle_col]
                if not self._bundle_like(bundle_val):
                    continue
                bundle = str(bundle_val)
                duration = None
                if duration_col:
                    duration = row[duration_col]
                if duration is None and start_col and end_col:
                    start_ts = self._normalize_timestamp(row[start_col])
                    end_ts = self._normalize_timestamp(row[end_col])
                    if start_ts and end_ts and end_ts >= start_ts:
                        duration = end_ts - start_ts
                if duration is None:
                    duration = 0

                matched_rows += 1
                try:
                    duration = float(duration)
                except Exception:
                    duration = 0
                if duration > 1e6:
                    duration = duration / 1000.0

                table_per_app[bundle] = table_per_app.get(bundle, 0) + duration

                date_val = None
                if date_col:
                    date_val = self._normalize_timestamp(row[date_col])
                elif start_col:
                    date_val = self._normalize_timestamp(row[start_col])
                if date_val:
                    day_key = datetime.fromtimestamp(date_val).strftime("%Y-%m-%d")
                    table_per_day[day_key] = table_per_day.get(day_key, 0) + duration

            if matched_rows > best_rows:
                best_rows = matched_rows
                best_usage = {
                    "table": table,
                    "bundle_col": bundle_col,
                    "duration_col": duration_col,
                    "start_col": start_col,
                    "end_col": end_col,
                    "date_col": date_col,
                }
                per_app_totals = table_per_app
                per_day_totals = table_per_day

        if best_usage:
            results["tables_used"].append(best_usage)
            results["per_app"] = [
                {
                    "bundle_id": bundle,
                    "duration_seconds": total,
                    "duration_human": self._format_duration(total),
                }
                for bundle, total in sorted(per_app_totals.items(), key=lambda x: x[1], reverse=True)
            ]
            results["per_day"] = [
                {
                    "date": day,
                    "duration_seconds": total,
                    "duration_human": self._format_duration(total),
                }
                for day, total in sorted(per_day_totals.items(), key=lambda x: x[0])
            ]

        # Pickups / notifications (heuristic)
        for table in tables:
            try:
                cur.execute(f"PRAGMA table_info(\"{table}\")")
                columns = [row[1] for row in cur.fetchall()]
            except Exception:
                continue
            if not any("pickup" in col.lower() for col in columns) and not any("notification" in col.lower() for col in columns):
                continue

            date_col = self._find_columns(columns, ["date", "day", "timestamp"])
            count_by_day = {}
            query = f"SELECT {', '.join([f'\"{c}\"' for c in columns])} FROM \"{table}\" LIMIT {self._MAX_TABLE_SCAN}"
            try:
                cur.execute(query)
                rows = cur.fetchall()
            except Exception:
                continue
            for row in rows:
                date_val = self._normalize_timestamp(row[date_col]) if date_col else None
                if date_val:
                    key = datetime.fromtimestamp(date_val).strftime("%Y-%m-%d")
                else:
                    key = "Unknown"
                count_by_day[key] = count_by_day.get(key, 0) + 1
            entry = {
                "table": table,
                "date_col": date_col or "",
                "counts": [{"date": k, "count": v} for k, v in sorted(count_by_day.items())],
            }
            if any("pickup" in col.lower() for col in columns):
                results["pickups"].append(entry)
            if any("notification" in col.lower() for col in columns):
                results["notifications"].append(entry)

        try:
            conn.close()
        except Exception:
            pass

        return results

    def _parse_knowledge(self, entry: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        results = {
            "available": False,
            "tables_used": [],
            "timeline": [],
            "top_apps": [],
        }
        if not entry or not entry.get("path") or not os.path.exists(entry["path"]):
            return results
        path = entry["path"]
        results["available"] = True

        try:
            conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = [row[0] for row in cur.fetchall()]
        except Exception:
            return results

        best_table = None
        best_rows = 0
        best_cols = {}
        timeline = []
        totals = {}

        for table in tables:
            try:
                cur.execute(f"PRAGMA table_info(\"{table}\")")
                columns = [row[1] for row in cur.fetchall()]
            except Exception:
                continue

            bundle_col = self._find_columns(columns, ["bundle", "identifier", "app"])
            start_col = self._find_columns(columns, ["start", "begin", "timestamp", "date"])
            end_col = self._find_columns(columns, ["end", "finish"])
            duration_col = self._find_columns(columns, ["duration", "seconds", "time"])

            if not bundle_col or not (start_col or duration_col):
                continue

            select_cols = [bundle_col]
            if start_col:
                select_cols.append(start_col)
            if end_col:
                select_cols.append(end_col)
            if duration_col and duration_col not in select_cols:
                select_cols.append(duration_col)

            query = f"SELECT {', '.join([f'\"{c}\"' for c in select_cols])} FROM \"{table}\" LIMIT {self._MAX_TABLE_SCAN}"
            try:
                cur.execute(query)
                rows = cur.fetchall()
            except Exception:
                continue

            matched_rows = 0
            local_timeline = []
            local_totals = {}

            for row in rows:
                bundle_val = row[bundle_col]
                if not self._bundle_like(bundle_val):
                    continue
                bundle = str(bundle_val)
                start_ts = self._normalize_timestamp(row[start_col]) if start_col else None
                end_ts = self._normalize_timestamp(row[end_col]) if end_col else None
                duration = None
                if duration_col:
                    duration = row[duration_col]
                if duration is None and start_ts and end_ts and end_ts >= start_ts:
                    duration = end_ts - start_ts
                if duration is None:
                    duration = 0
                try:
                    duration = float(duration)
                except Exception:
                    duration = 0
                if duration > 1e6:
                    duration = duration / 1000.0

                matched_rows += 1
                local_totals[bundle] = local_totals.get(bundle, 0) + duration

                if start_ts:
                    local_timeline.append({
                        "start": start_ts,
                        "end": end_ts,
                        "duration_seconds": duration,
                        "bundle_id": bundle,
                    })

            if matched_rows > best_rows:
                best_rows = matched_rows
                best_table = table
                best_cols = {
                    "bundle_col": bundle_col,
                    "start_col": start_col,
                    "end_col": end_col,
                    "duration_col": duration_col,
                }
                timeline = local_timeline
                totals = local_totals

        if best_table:
            results["tables_used"].append({
                "table": best_table,
                **best_cols,
            })
            timeline_sorted = sorted(timeline, key=lambda x: x.get("start") or 0, reverse=True)
            results["timeline"] = timeline_sorted[: self._MAX_TIMELINE_ROWS]
            results["top_apps"] = [
                {
                    "bundle_id": bundle,
                    "duration_seconds": total,
                    "duration_human": self._format_duration(total),
                }
                for bundle, total in sorted(totals.items(), key=lambda x: x[1], reverse=True)
            ]

        try:
            conn.close()
        except Exception:
            pass

        return results

    def _load_data(self) -> Dict[str, Any]:
        if self._cached_data is not None:
            return self._cached_data

        encrypted_flag = None
        manifest_plist = os.path.join(self.backup_path, "Manifest.plist")
        if os.path.exists(manifest_plist):
            try:
                import plistlib
                with open(manifest_plist, "rb") as f:
                    manifest = plistlib.load(f)
                encrypted_flag = bool(manifest.get("IsEncrypted", False))
            except Exception:
                encrypted_flag = None

        data = {
            "encrypted": encrypted_flag,
            "artifacts": self._artifacts,
            "rm_local": self._rm_local,
            "rm_cloud": self._rm_cloud,
            "rm_results": self._parse_rmadminstore(self._rm_local),
            "knowledge": self._knowledge,
            "knowledge_results": self._parse_knowledge(self._knowledge),
        }

        self._cached_data = data
        return data

    def get_count(self) -> int:
        data = self._load_data()
        per_app = data["rm_results"].get("per_app") or []
        if per_app:
            return len(per_app)
        timeline = data["knowledge_results"].get("timeline") or []
        return len(timeline)

    def get_items(self, limit: Optional[int] = None, offset: int = 0,
                  search: Optional[str] = None) -> List[Dict[str, Any]]:
        data = self._load_data()
        items = data["rm_results"].get("per_app") or []
        if not items:
            items = data["knowledge_results"].get("timeline") or []
        if search:
            term = search.lower()
            items = [item for item in items if term in str(item).lower()]
        if limit:
            return items[offset:offset + limit]
        return items[offset:]

    def export(self, items: List[Dict[str, Any]], output_path: str,
               format: str = "html", progress_callback=None, timeline_emitter=None) -> bool:
        if format != "html":
            raise ValueError(f"Unsupported export format: {format}")

        self._reset_export_bytes()
        os.makedirs(output_path, exist_ok=True)

        data = self._load_data()
        html_path = os.path.join(output_path, "Screen_Time.html")
        json_path = os.path.join(output_path, "Screen_Time.json")

        import json
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        self._add_export_bytes(json_path)

        rm_results = data["rm_results"]
        knowledge_results = data["knowledge_results"]

        def format_table(rows: List[Dict[str, Any]], headers: List[str]) -> str:
            if not rows:
                return "<p>No data found.</p>"
            thead = "".join([f"<th>{h}</th>" for h in headers])
            body_rows = []
            for row in rows:
                cols = [self._escape_html(str(row.get(h, ""))) for h in headers]
                body_rows.append("<tr>" + "".join([f"<td>{c}</td>" for c in cols]) + "</tr>")
            return f"<table><thead><tr>{thead}</tr></thead><tbody>{''.join(body_rows)}</tbody></table>"

        def per_app_rows(rows: List[Dict[str, Any]]) -> str:
            if not rows:
                return "<p>No per-app usage data found.</p>"
            body = []
            for row in rows:
                body.append(
                    "<tr>"
                    f"<td>{self._escape_html(row.get('bundle_id') or '')}</td>"
                    f"<td>{self._escape_html(row.get('duration_human') or '')}</td>"
                    f"<td>{self._escape_html(str(int(row.get('duration_seconds') or 0)))}</td>"
                    "</tr>"
                )
            return (
                "<table><thead><tr><th>App Bundle ID</th><th>Duration</th><th>Seconds</th>"
                "</tr></thead><tbody>"
                + "".join(body) + "</tbody></table>"
            )

        def per_day_rows(rows: List[Dict[str, Any]]) -> str:
            if not rows:
                return "<p>No per-day totals found.</p>"
            body = []
            for row in rows:
                body.append(
                    "<tr>"
                    f"<td>{self._escape_html(row.get('date') or '')}</td>"
                    f"<td>{self._escape_html(row.get('duration_human') or '')}</td>"
                    f"<td>{self._escape_html(str(int(row.get('duration_seconds') or 0)))}</td>"
                    "</tr>"
                )
            return (
                "<table><thead><tr><th>Date</th><th>Total Usage</th><th>Seconds</th>"
                "</tr></thead><tbody>"
                + "".join(body) + "</tbody></table>"
            )

        def timeline_rows(rows: List[Dict[str, Any]]) -> str:
            if not rows:
                return "<p>No timeline events found.</p>"
            body = []
            for row in rows:
                start = row.get("start")
                end = row.get("end")
                start_str = datetime.fromtimestamp(start).strftime("%m/%d/%Y %I:%M %p") if start else ""
                end_str = datetime.fromtimestamp(end).strftime("%m/%d/%Y %I:%M %p") if end else ""
                body.append(
                    "<tr>"
                    f"<td>{self._escape_html(start_str)}</td>"
                    f"<td>{self._escape_html(end_str)}</td>"
                    f"<td>{self._escape_html(row.get('bundle_id') or '')}</td>"
                    f"<td>{self._escape_html(self._format_duration(row.get('duration_seconds')))}</td>"
                    "</tr>"
                )
            return (
                "<table><thead><tr><th>Start</th><th>End</th><th>App Bundle ID</th><th>Duration</th>"
                "</tr></thead><tbody>"
                + "".join(body) + "</tbody></table>"
            )

        def artifact_row(entry: Optional[Dict[str, Any]], label: str) -> str:
            if not entry:
                return f"<tr><td>{label}</td><td>Missing</td><td></td><td></td></tr>"
            return (
                "<tr>"
                f"<td>{self._escape_html(label)}</td>"
                f"<td>Found</td>"
                f"<td>{self._escape_html(entry.get('domain') or '')}</td>"
                f"<td>{self._escape_html(entry.get('relative_path') or '')}</td>"
                "</tr>"
            )

        encrypted_label = "Unknown"
        if data["encrypted"] is True:
            encrypted_label = "Yes"
        elif data["encrypted"] is False:
            encrypted_label = "No"
        local_hash = self._sha256(self._rm_local.get("path") if self._rm_local else None)
        cloud_hash = self._sha256(self._rm_cloud.get("path") if self._rm_cloud else None)
        knowledge_hash = self._sha256(self._knowledge.get("path") if self._knowledge else None)

        html = f"""<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Screen Time (iTunes Backup)</title>
  <style>
    body {{
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
      margin: 20px;
      background-color: #f5f5f5;
    }}
    .header {{
      background: linear-gradient(135deg, #1f4b99 0%, #3aa0d8 100%);
      color: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      margin-bottom: 20px;
    }}
    .header h1 {{ margin: 0 0 10px 0; font-size: 32px; font-weight: 600; }}
    .breadcrumbs {{
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 12px;
      letter-spacing: 0.2px;
      color: rgba(255,255,255,0.85);
      margin-bottom: 10px;
    }}
    .breadcrumbs a {{ color: #fff; text-decoration: none; font-weight: 600; }}
    .breadcrumbs a:hover {{ text-decoration: underline; }}
    .embedded .breadcrumbs {{ display: none; }}
    .section {{
      background: #fff;
      border-radius: 12px;
      padding: 20px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.08);
      margin-bottom: 20px;
    }}
    table {{
      width: 100%;
      border-collapse: collapse;
    }}
    th, td {{
      text-align: left;
      padding: 8px;
      border-bottom: 1px solid #e5e5e5;
      font-size: 13px;
    }}
    th {{ background: #fafafa; }}
    code {{ background: #f3f4f6; padding: 2px 6px; border-radius: 6px; font-size: 12px; }}
  </style>
</head>
<body>
  <div class="header">
    <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Start_Here.html">Back</a></div>
    <h1>Screen Time (iTunes Backup)</h1>
    <p>Report generated from available Screen Time artifacts.</p>
  </div>

  <div class="section">
    <h2>Acquisition Summary</h2>
    <p><strong>Backup type:</strong> iTunes-style</p>
    <p><strong>Encrypted:</strong> {self._escape_html(encrypted_label)}</p>
    <table>
      <thead><tr><th>Artifact</th><th>Status</th><th>Domain</th><th>Relative Path</th></tr></thead>
      <tbody>
        {artifact_row(self._rm_local, "RMAdminStore-Local.sqlite")}
        {artifact_row(self._rm_cloud, "RMAdminStore-Cloud.sqlite")}
        {artifact_row(self._knowledge, "knowledgeC.db")}
      </tbody>
    </table>
    <p><strong>SHA-256 hashes:</strong></p>
    <table>
      <thead><tr><th>Artifact</th><th>SHA-256</th></tr></thead>
      <tbody>
        <tr><td>RMAdminStore-Local.sqlite</td><td><code>{self._escape_html(local_hash)}</code></td></tr>
        <tr><td>RMAdminStore-Cloud.sqlite</td><td><code>{self._escape_html(cloud_hash)}</code></td></tr>
        <tr><td>knowledgeC.db</td><td><code>{self._escape_html(knowledge_hash)}</code></td></tr>
      </tbody>
    </table>
  </div>

  <div class="section">
    <h2>Screen Time Summary (RMAdminStore-Local)</h2>
    <p><strong>Tables/fields used:</strong></p>
    {format_table(rm_results.get("tables_used") or [], ["table", "bundle_col", "duration_col", "start_col", "end_col", "date_col"])}
    <h3>Per-app usage</h3>
    {per_app_rows(rm_results.get("per_app") or [])}
    <h3>Per-day totals</h3>
    {per_day_rows(rm_results.get("per_day") or [])}
  </div>

  <div class="section">
    <h2>Corroboration Timeline (knowledgeC.db)</h2>
    <p><strong>Tables/fields used:</strong></p>
    {format_table(knowledge_results.get("tables_used") or [], ["table", "bundle_col", "start_col", "end_col", "duration_col"])}
    <h3>Top apps by observed foreground time</h3>
    {per_app_rows(knowledge_results.get("top_apps") or [])}
    <h3>Usage timeline</h3>
    {timeline_rows(knowledge_results.get("timeline") or [])}
  </div>

  <div class="section">
    <h2>Limitations</h2>
    <ul>
      <li>Screen Time can be cleared/reset by the user.</li>
      <li>Schema varies by iOS version; tables/fields used are reported above.</li>
      <li>Unencrypted backups may omit protected Screen Time data.</li>
    </ul>
  </div>

  <script>
    if (window.self !== window.top) {{
      document.body.classList.add('embedded');
    }}
  </script>
</body>
</html>
"""

        with open(html_path, "w", encoding="utf-8") as f:
            f.write(html)
        self._add_export_bytes(html_path)

        return True

    def get_item_summary(self, item: Dict[str, Any]) -> str:
        return str(item.get("bundle_id") or "Screen Time")

    @staticmethod
    def _escape_html(text: str) -> str:
        if not text:
            return ""
        text = str(text)
        return (text.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;"))
