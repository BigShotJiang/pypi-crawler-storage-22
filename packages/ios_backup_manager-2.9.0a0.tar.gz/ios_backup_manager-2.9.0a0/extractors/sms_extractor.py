#!/usr/bin/env python3
"""
SMS/iMessage data extractor for iOS backups.

Extracts messages, conversations, and attachments from sms.db
and supports export to HTML format.
"""

import sqlite3
import os
import shutil
import plistlib
import re
from typing import List, Dict, Any, Optional
from datetime import datetime, timezone
from .base import CategoryDataExtractor

# Try to import PIL for HEIC conversion
try:
    from PIL import Image
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

# Try to import pillow_heif for HEIC conversion
try:
    from pillow_heif import register_heif_opener
    # Register HEIF opener with PIL
    register_heif_opener()
    HEIC_CONVERSION_AVAILABLE = True
except ImportError:
    HEIC_CONVERSION_AVAILABLE = False


class SMSExtractor(CategoryDataExtractor):
    """Extract and export SMS/iMessage data from iOS backup."""

    def __init__(self, backup_path: str):
        super().__init__(backup_path)

        # Find SMS database
        self.sms_db_path = self.find_db_file(
            "HomeDomain",
            "Library/SMS/sms.db"
        )

        if not self.sms_db_path:
            raise FileNotFoundError("sms.db not found in backup")

        # Check if database has data
        conn = sqlite3.connect(self.sms_db_path)
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM message")
        message_count = cur.fetchone()[0]
        conn.close()

        if message_count == 0:
            raise FileNotFoundError("sms.db exists but contains no messages")

        # Find contacts database (optional - for name resolution)
        self.contacts_db_path = self.find_db_file(
            "HomeDomain",
            "Library/AddressBook/AddressBook.sqlitedb"
        )

        # Contact name cache for performance
        self._contact_cache = {}
        self._cameraroll_filename_map = None

    def _get_contact_name(self, phone_or_email: str) -> Optional[str]:
        """
        Look up contact name by phone number or email.

        Args:
            phone_or_email: Phone number or email address

        Returns:
            Contact name (First Last) or None if not found
        """
        if not self.contacts_db_path or not phone_or_email:
            return None

        # Check cache first
        if phone_or_email in self._contact_cache:
            return self._contact_cache[phone_or_email]

        try:
            # Normalize phone number for matching (remove formatting)
            normalized = ''.join(c for c in phone_or_email if c.isdigit())

            conn = sqlite3.connect(self.contacts_db_path)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()

            # Search in phone numbers (property = 3)
            cur.execute("""
                SELECT p.First, p.Last, p.Organization
                FROM ABPerson p
                JOIN ABMultiValue mv ON p.ROWID = mv.record_id
                WHERE mv.property = 3 AND mv.value LIKE ?
                LIMIT 1
            """, (f'%{normalized[-10:]}%',))  # Match last 10 digits

            row = cur.fetchone()

            # If not found in phones, try emails (property = 4)
            if not row and '@' in phone_or_email:
                cur.execute("""
                    SELECT p.First, p.Last, p.Organization
                    FROM ABPerson p
                    JOIN ABMultiValue mv ON p.ROWID = mv.record_id
                    WHERE mv.property = 4 AND mv.value = ?
                    LIMIT 1
                """, (phone_or_email,))
                row = cur.fetchone()

            conn.close()

            if row:
                # Build name from first/last/organization
                parts = []
                if row['First']:
                    parts.append(row['First'])
                if row['Last']:
                    parts.append(row['Last'])

                if parts:
                    name = ' '.join(parts)
                elif row['Organization']:
                    name = row['Organization']
                else:
                    name = None

                # Cache result
                self._contact_cache[phone_or_email] = name
                return name

        except Exception as e:
            # Silently fail if contacts database has issues
            pass

        # Cache miss
        self._contact_cache[phone_or_email] = None
        return None

    def get_conversations(self, limit: Optional[int] = None, offset: int = 0, search: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get list of conversations (chats) with preview info.

        Args:
            limit: Maximum number of conversations to return
            offset: Number of conversations to skip
            search: Optional search string to filter conversations by name, number, or message content

        Returns list of conversation dictionaries with fields:
        - chat_id: Chat ROWID
        - chat_guid: Chat GUID
        - display_name: Name or phone number
        - last_message: Last message text
        - last_message_date: Timestamp of last message
        - message_count: Total messages in conversation
        - is_group: Whether this is a group chat
        - participants: List of participant names/numbers (for group chats)
        """
        conn = sqlite3.connect(self.sms_db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        # Build search conditions
        search_condition = ""
        params = []
        if search:
            search_pattern = f"%{search}%"
            # Search in display name, chat identifier, participant handles, or any message text in the conversation
            search_condition = """ AND (
                c.display_name LIKE ? OR
                c.chat_identifier LIKE ? OR
                EXISTS (
                    SELECT 1 FROM handle h
                    JOIN chat_handle_join chj ON h.ROWID = chj.handle_id
                    WHERE chj.chat_id = c.ROWID AND h.id LIKE ?
                ) OR
                EXISTS (
                    SELECT 1 FROM message m
                    JOIN chat_message_join cmj ON m.ROWID = cmj.message_id
                    WHERE cmj.chat_id = c.ROWID AND m.text LIKE ?
                )
            )"""
            params = [search_pattern, search_pattern, search_pattern, search_pattern]

        # Detect pinned columns (schema varies by iOS version)
        cur.execute("PRAGMA table_info(chat)")
        chat_columns = {row[1] for row in cur.fetchall()}
        pin_flag_col = next((c for c in ("is_pinned", "pinned") if c in chat_columns), None)
        pin_order_col = next(
            (c for c in (
                "pinned_order",
                "pinning_order",
                "pinning_index",
                "pinned_index",
                "pinning_rank",
                "pinned_rank",
            ) if c in chat_columns),
            None
        )

        if pin_flag_col:
            pin_flag_expr = f"COALESCE(c.{pin_flag_col}, 0)"
        elif pin_order_col:
            pin_flag_expr = f"CASE WHEN c.{pin_order_col} IS NULL THEN 0 ELSE 1 END"
        else:
            pin_flag_expr = "0"

        if pin_order_col:
            pin_order_expr = f"c.{pin_order_col}"
        else:
            pin_order_expr = "NULL"

        # Get conversations with their latest message (including recoverable/deleted messages)
        query = f"""
        SELECT
            c.ROWID as chat_id,
            c.guid as chat_guid,
            c.chat_identifier,
            c.display_name,
            c.service_name,
            ((SELECT COUNT(*) FROM chat_message_join cmj WHERE cmj.chat_id = c.ROWID) +
             (SELECT COUNT(*) FROM chat_recoverable_message_join crmj WHERE crmj.chat_id = c.ROWID)) as message_count,
            (SELECT m.text FROM message m
             WHERE m.ROWID IN (
                 SELECT message_id FROM chat_message_join WHERE chat_id = c.ROWID
                 UNION ALL
                 SELECT message_id FROM chat_recoverable_message_join WHERE chat_id = c.ROWID
             )
             ORDER BY m.date DESC LIMIT 1) as last_message,
            (SELECT m.date FROM message m
             WHERE m.ROWID IN (
                 SELECT message_id FROM chat_message_join WHERE chat_id = c.ROWID
                 UNION ALL
                 SELECT message_id FROM chat_recoverable_message_join WHERE chat_id = c.ROWID
             )
             ORDER BY m.date DESC LIMIT 1) as last_message_date,
            (SELECT m.is_from_me FROM message m
             WHERE m.ROWID IN (
                 SELECT message_id FROM chat_message_join WHERE chat_id = c.ROWID
                 UNION ALL
                 SELECT message_id FROM chat_recoverable_message_join WHERE chat_id = c.ROWID
             )
             ORDER BY m.date DESC LIMIT 1) as last_message_from_me,
             EXISTS (SELECT 1 FROM chat_recoverable_message_join crmj WHERE crmj.chat_id = c.ROWID) as has_deleted,
             {pin_flag_expr} as is_pinned,
             {pin_order_expr} as pin_order
        FROM chat c
        WHERE (EXISTS (SELECT 1 FROM chat_message_join cmj WHERE cmj.chat_id = c.ROWID) OR
               EXISTS (SELECT 1 FROM chat_recoverable_message_join crmj WHERE crmj.chat_id = c.ROWID)){search_condition}
        ORDER BY is_pinned DESC, COALESCE(pin_order, 999999) ASC, last_message_date DESC
        """

        if limit is not None:
            query += f" LIMIT {limit} OFFSET {offset}"

        cur.execute(query, params)
        chats = cur.fetchall()

        conversations = []
        for chat in chats:
            # Get participants for this chat
            cur.execute("""
                SELECT h.id, h.service
                FROM handle h
                JOIN chat_handle_join chj ON h.ROWID = chj.handle_id
                WHERE chj.chat_id = ?
                ORDER BY h.id
            """, (chat['chat_id'],))
            participants = [{'id': row[0], 'service': row[1]} for row in cur.fetchall()]

            # Determine display name
            display_name = chat['display_name']
            if not display_name:
                if len(participants) == 1:
                    # Try to get contact name first
                    contact_name = self._get_contact_name(participants[0]['id'])
                    display_name = contact_name or self._format_handle(participants[0]['id'])
                elif len(participants) > 1:
                    # For group chats, try to resolve each participant name
                    names = []
                    for p in participants[:3]:
                        contact_name = self._get_contact_name(p['id'])
                        names.append(contact_name or self._format_handle(p['id']))
                    display_name = ", ".join(names)
                    if len(participants) > 3:
                        display_name += f" +{len(participants) - 3} more"
                else:
                    display_name = chat['chat_identifier'] or "Unknown"

            conversations.append({
                'chat_id': chat['chat_id'],
                'chat_guid': chat['chat_guid'],
                'display_name': display_name,
                'last_message': chat['last_message'] or '(Media)',
                'last_message_date': chat['last_message_date'],
                'last_message_from_me': bool(chat['last_message_from_me']),
                'message_count': chat['message_count'],
                'is_group': len(participants) > 1,
                'participants': participants,
                'service_name': chat['service_name'],
                'has_deleted': bool(chat['has_deleted']),
                'is_pinned': bool(chat['is_pinned']) if 'is_pinned' in chat.keys() else False
            })

        conn.close()
        return conversations

    def get_conversation_ids(self) -> List[int]:
        """
        Get list of all conversation (chat) IDs.

        This is a lightweight alternative to get_conversations() when you only need IDs.
        Much faster for operations like "Select All".

        Returns:
            List of chat ROWIDs
        """
        conn = sqlite3.connect(self.sms_db_path)
        cur = conn.cursor()

        # Simple query - just get chat IDs where there are messages (including recoverable)
        cur.execute("""
            SELECT c.ROWID
            FROM chat c
            WHERE EXISTS (
                SELECT 1 FROM chat_message_join cmj WHERE cmj.chat_id = c.ROWID
            ) OR EXISTS (
                SELECT 1 FROM chat_recoverable_message_join crmj WHERE crmj.chat_id = c.ROWID
            )
            ORDER BY c.ROWID
        """)

        chat_ids = [row[0] for row in cur.fetchall()]
        conn.close()
        return chat_ids

    def get_conversation_count(self) -> int:
        """Get total number of conversations (including recoverable/deleted messages)."""
        conn = sqlite3.connect(self.sms_db_path)
        cur = conn.cursor()
        cur.execute("""
            SELECT COUNT(DISTINCT c.ROWID)
            FROM chat c
            WHERE EXISTS (
                SELECT 1 FROM chat_message_join cmj WHERE cmj.chat_id = c.ROWID
            ) OR EXISTS (
                SELECT 1 FROM chat_recoverable_message_join crmj WHERE crmj.chat_id = c.ROWID
            )
        """)
        count = cur.fetchone()[0]
        conn.close()
        return count

    def get_total_message_count(self) -> int:
        """Get total number of messages (for overall counts)."""
        conn = sqlite3.connect(self.sms_db_path)
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM message")
        total = cur.fetchone()[0]
        conn.close()
        return total

    def get_messages(self, chat_id: int, limit: Optional[int] = None, offset: int = 0) -> List[Dict[str, Any]]:
        """
        Get messages for a specific conversation.

        Args:
            chat_id: Chat ROWID
            limit: Max messages to return
            offset: Offset for pagination

        Returns:
            List of message dictionaries with fields:
            - message_id: Message ROWID
            - text: Message text content
            - date: Timestamp
            - is_from_me: Whether sent by device owner
            - handle: Sender's phone/email (for received messages)
            - service: 'iMessage' or 'SMS'
            - attachments: List of attachment info
        """
        conn = sqlite3.connect(self.sms_db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        # Get messages for this chat, including recoverable/deleted messages
        query = """
        SELECT * FROM (
            SELECT
                m.ROWID as message_id,
                m.guid,
                m.text,
                m.attributedBody,
                m.date,
                m.date_delivered,
                m.date_read,
                m.is_from_me,
                m.handle_id,
                m.service,
                m.account,
                m.subject,
                h.id as handle_id_str,
                h.service as handle_service,
                'normal' as msg_source
            FROM message m
            JOIN chat_message_join cmj ON m.ROWID = cmj.message_id
            LEFT JOIN handle h ON m.handle_id = h.ROWID
            WHERE cmj.chat_id = ?
            UNION ALL
            SELECT
                m.ROWID as message_id,
                m.guid,
                m.text,
                m.attributedBody,
                m.date,
                m.date_delivered,
                m.date_read,
                m.is_from_me,
                m.handle_id,
                m.service,
                m.account,
                m.subject,
                h.id as handle_id_str,
                h.service as handle_service,
                'recoverable' as msg_source
            FROM message m
            JOIN chat_recoverable_message_join crmj ON m.ROWID = crmj.message_id
            LEFT JOIN handle h ON m.handle_id = h.ROWID
            WHERE crmj.chat_id = ?
            EXCEPT
            SELECT
                m.ROWID as message_id,
                m.guid,
                m.text,
                m.attributedBody,
                m.date,
                m.date_delivered,
                m.date_read,
                m.is_from_me,
                m.handle_id,
                m.service,
                m.account,
                m.subject,
                h.id as handle_id_str,
                h.service as handle_service,
                'recoverable' as msg_source
            FROM message m
            JOIN chat_recoverable_message_join crmj ON m.ROWID = crmj.message_id
            LEFT JOIN handle h ON m.handle_id = h.ROWID
            JOIN chat_message_join cmj2 ON cmj2.message_id = m.ROWID AND cmj2.chat_id = crmj.chat_id
            WHERE crmj.chat_id = ?
        )
        ORDER BY date ASC
        """

        params = (chat_id, chat_id, chat_id)
        if limit is not None:
            query += f" LIMIT {limit} OFFSET {offset}"

        cur.execute(query, params)
        messages = cur.fetchall()

        # OPTIMIZATION: Fetch all attachments for all messages in batches (avoid N+1 problem)
        # SQLite has a parameter limit (~999), so we chunk the queries
        message_ids = [msg['message_id'] for msg in messages]
        attachments_by_message = {}

        if message_ids:
            # Process message IDs in chunks to avoid SQLite parameter limits
            chunk_size = 500  # Safe batch size well below SQLite's typical 999 limit

            for i in range(0, len(message_ids), chunk_size):
                chunk = message_ids[i:i + chunk_size]

                # Build placeholders for IN clause
                placeholders = ','.join('?' * len(chunk))
                cur.execute(f"""
                    SELECT
                        maj.message_id,
                        a.ROWID as attachment_id,
                        a.filename,
                        a.mime_type,
                        a.transfer_name,
                        a.total_bytes
                    FROM attachment a
                    JOIN message_attachment_join maj ON a.ROWID = maj.attachment_id
                    WHERE maj.message_id IN ({placeholders})
                    ORDER BY maj.message_id, a.ROWID
                """, chunk)

                # Group attachments by message_id
                for row in cur.fetchall():
                    msg_id = row[0]
                    attachment = {
                        'attachment_id': row[1],
                        'filename': row[2],
                        'mime_type': row[3],
                        'transfer_name': row[4],
                        'total_bytes': row[5]
                    }
                    if msg_id not in attachments_by_message:
                        attachments_by_message[msg_id] = []
                    attachments_by_message[msg_id].append(attachment)

        result = []
        for msg in messages:
            # Get attachments from pre-fetched dictionary
            attachments = attachments_by_message.get(msg['message_id'], [])
            try:
                attributed_blob = msg['attributedBody']
            except Exception:
                attributed_blob = None
            attributed_text = self._decode_attributed_body(attributed_blob)
            is_deleted = False
            try:
                if msg['msg_source'] == 'recoverable':
                    is_deleted = True
            except Exception:
                pass

            result.append({
                'message_id': msg['message_id'],
                'guid': msg['guid'],
                'text': msg['text'] or '',
                'date': msg['date'],
                'date_delivered': msg['date_delivered'],
                'date_read': msg['date_read'],
                'is_from_me': bool(msg['is_from_me']),
                'handle': msg['handle_id_str'],
                'handle_service': msg['handle_service'],
                'service': msg['service'],
                'subject': msg['subject'] or '',
                'has_attributed_body': bool(attributed_blob),
                'attributed_text': attributed_text,
                'attachments': attachments,
                'is_deleted': is_deleted,
                'msg_source': msg['msg_source']
            })

        conn.close()
        return result

    def _decode_attributed_body(self, blob: Optional[bytes]) -> str:
        """
        Attempt to recover text from attributedBody (NSAttributedString archive).
        Returns empty string if no text can be extracted.
        """
        if not blob:
            return ''

        # If the blob contains a binary plist, try to decode NSKeyedArchiver.
        try:
            start = blob.find(b'bplist00')
            if start != -1:
                payload = blob[start:]
                plist = plistlib.loads(payload)
                objects = plist.get('$objects', []) if isinstance(plist, dict) else []
                strings = [o for o in objects if isinstance(o, str)]
                if strings:
                    # Prefer the longest string as the message body.
                    return max(strings, key=len)
        except Exception:
            pass

        # Fallback: extract readable UTF-8 / UTF-16LE runs.
        try:
            candidates = []
            # UTF-8 printable runs
            for m in re.findall(rb'[ -~]{4,}', blob):
                try:
                    candidates.append(m.decode('utf-8', errors='ignore'))
                except Exception:
                    continue
            # UTF-16LE printable runs
            for m in re.findall(rb'(?:[ -~]\x00){4,}', blob):
                try:
                    candidates.append(m.decode('utf-16le', errors='ignore'))
                except Exception:
                    continue
            if candidates:
                # Pick the longest plausible string
                candidates = [c.strip() for c in candidates if c.strip()]
                if candidates:
                    return max(candidates, key=len)
        except Exception:
            pass

        return ''

    def get_message_count(self, chat_id: int) -> int:
        """Get total number of messages in a conversation."""
        conn = sqlite3.connect(self.sms_db_path)
        cur = conn.cursor()
        cur.execute("""
            SELECT COUNT(*)
            FROM message m
            WHERE EXISTS (SELECT 1 FROM chat_message_join cmj WHERE cmj.message_id = m.ROWID AND cmj.chat_id = ?)
               OR EXISTS (SELECT 1 FROM chat_recoverable_message_join crmj WHERE crmj.message_id = m.ROWID AND crmj.chat_id = ?)
        """, (chat_id, chat_id))
        count = cur.fetchone()[0]
        conn.close()
        return count

    def get_attachment_path(self, attachment_filename: str) -> Optional[str]:
        """
        Get full path to attachment file in backup.

        Uses multiple fallback strategies:
        1. Try full path with MediaDomain
        2. Try directory path without filename (iOS sometimes stores this way)
        3. Search CameraRollDomain for matching filename (photos/videos)

        Args:
            attachment_filename: Filename from attachment table (starts with ~/)

        Returns:
            Full path to attachment file, or None if not found
        """
        if not attachment_filename:
            return None

        # Attachment filename is like "~/Library/SMS/Attachments/xx/xx/..."
        # Remove the ~/ prefix
        if attachment_filename.startswith('~/'):
            relative_path = attachment_filename[2:]
        else:
            relative_path = attachment_filename

        # Strategy 1: Try full path with MediaDomain
        file_path = self.find_db_file("MediaDomain", relative_path)
        if file_path:
            return file_path

        # Strategy 2: Try directory path without filename
        # iOS sometimes stores SMS attachments with the directory path as the fileID
        # Example: "Library/SMS/Attachments/e4/04/at_0_UUID" instead of including "/filename.jpg"
        if '/' in relative_path:
            directory_path = relative_path.rsplit('/', 1)[0]  # Remove last component (filename)
            file_path = self.find_db_file("MediaDomain", directory_path)
            if file_path:
                return file_path

        # Strategy 3: Search CameraRollDomain for matching filename
        # SMS attachments that are photos/videos often reference files stored in Photos app
        import os
        filename = os.path.basename(relative_path)
        file_path = self._search_cameraroll_for_file(filename)
        if file_path:
            return file_path

        return None

    def _search_cameraroll_for_file(self, filename: str) -> Optional[str]:
        """
        Search CameraRollDomain in manifest for a file matching the given filename.

        This helps find SMS attachments that are stored as photos/videos in the Photos app
        rather than in the SMS attachments directory.

        Args:
            filename: Base filename to search for (e.g., "IMG_1015.jpg")

        Returns:
            Physical path to matching file, or None if not found
        """
        import sqlite3
        import os

        if filename:
            if self._cameraroll_filename_map is None:
                self._cameraroll_filename_map = self._build_cameraroll_filename_map()
            file_id = self._cameraroll_filename_map.get(filename)
            if file_id:
                physical_path = self._resolve_file_id_path(file_id)
                if physical_path and os.path.exists(physical_path):
                    return physical_path

        # Connect to manifest database
        manifest_path = self.manifest_db_path
        if not os.path.exists(manifest_path):
            return None

        try:
            conn = sqlite3.connect(manifest_path)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()

            # Search for files in CameraRollDomain matching this filename
            # Look for the actual file first (not thumbnails)
            cur.execute("""
            SELECT fileID, relativePath
            FROM Files
            WHERE domain = 'CameraRollDomain'
              AND relativePath LIKE ?
              AND relativePath NOT LIKE '%/Thumbnails/%'
              AND relativePath NOT LIKE '%thumbnail%'
            ORDER BY LENGTH(relativePath) ASC
            LIMIT 1
            """, (f'%{filename}',))

            row = cur.fetchone()
            if row:
                file_id = row['fileID']
                physical_path = self._resolve_file_id_path(file_id)
                if physical_path and os.path.exists(physical_path):
                    conn.close()
                    return physical_path

            # If no full-size file found, try thumbnails as fallback
            cur.execute("""
            SELECT fileID, relativePath
            FROM Files
            WHERE domain = 'CameraRollDomain'
              AND relativePath LIKE ?
            ORDER BY LENGTH(relativePath) DESC
            LIMIT 1
            """, (f'%{filename}%',))

            row = cur.fetchone()
            if row:
                file_id = row['fileID']
                physical_path = self._resolve_file_id_path(file_id)
                if physical_path and os.path.exists(physical_path):
                    conn.close()
                    return physical_path

            conn.close()
        except Exception:
            # Silently fail - this is a fallback search
            pass

        return None

    def _build_cameraroll_filename_map(self) -> Dict[str, str]:
        """Build filename -> fileID map for CameraRollDomain for fast attachment lookup."""
        manifest_path = self.manifest_db_path
        if not os.path.exists(manifest_path):
            return {}

        try:
            conn = sqlite3.connect(manifest_path)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            cur.execute("""
                SELECT fileID, relativePath
                FROM Files
                WHERE domain = 'CameraRollDomain'
                  AND relativePath NOT LIKE '%/Thumbnails/%'
                  AND relativePath NOT LIKE '%thumbnail%'
            """)
            mapping = {}
            for row in cur.fetchall():
                rel_path = row['relativePath']
                name = os.path.basename(rel_path)
                if name and name not in mapping:
                    mapping[name] = row['fileID']
            conn.close()
            return mapping
        except Exception:
            return {}

    def export_conversation_html(self, chat_id: int, output_path: str,
                                 conversation_name: str = "Conversation",
                                 progress_callback=None,
                                 timeline_emitter=None) -> bool:
        """
        Export a conversation to HTML file(s).

        Automatically splits into multiple files if >10,000 messages.

        Args:
            chat_id: Chat ROWID to export
            output_path: Output HTML file path (base name)
            conversation_name: Display name for conversation

        Returns:
            True if export succeeded
        """
        try:
            # Get total message count
            total_messages = self.get_message_count(chat_id)

            if total_messages == 0:
                print(f"No messages found for chat {chat_id}")
                return False

            # Create attachments directory
            # If output_path is in a "Conversations" subdirectory, create attachments at parent level
            output_dir = os.path.dirname(output_path)
            if os.path.basename(output_dir) == "Conversations":
                # Go up one level to place attachments at root of export directory
                parent_dir = os.path.dirname(output_dir)
                attachments_dir = os.path.join(parent_dir, "Message Attachments")
            else:
                attachments_dir = os.path.join(output_dir, "Message Attachments")
            os.makedirs(attachments_dir, exist_ok=True)

            # Calculate pages needed (10,000 messages per page)
            messages_per_page = 10000
            total_pages = (total_messages + messages_per_page - 1) // messages_per_page

            # Prepare base filename (remove .html extension if present)
            base_path = output_path
            if base_path.endswith('.html'):
                base_path = base_path[:-5]

            # Export each page
            exported_files = []
            for page in range(total_pages):
                # Report progress
                if progress_callback:
                    status = f"Exporting page {page + 1} of {total_pages}..." if total_pages > 1 else "Exporting messages..."
                    progress_callback(page, total_pages, status)

                # Calculate offset for this page
                offset = page * messages_per_page

                # Get messages for this page
                messages = self.get_messages(chat_id, limit=messages_per_page, offset=offset)

                if not messages:
                    continue

                # Generate filename for this page
                if total_pages > 1:
                    page_path = f"{base_path}_Page_{page + 1}.html"
                else:
                    page_path = f"{base_path}.html"

                # Generate HTML with navigation for multi-page exports
                page_filename = os.path.basename(page_path)
                if os.path.basename(output_dir) == "Conversations":
                    link_hint = f"Messages/Conversations/{page_filename}"
                else:
                    link_hint = page_filename

                html = self._generate_html(
                    messages,
                    conversation_name,
                    attachments_dir,
                    current_page=page + 1,
                    total_pages=total_pages,
                    base_filename=os.path.basename(base_path),
                    output_path=page_path,
                    timeline_emitter=timeline_emitter,
                    link_hint=link_hint
                )

                # Write HTML file
                with open(page_path, 'w', encoding='utf-8') as f:
                    f.write(html)
                self._add_export_bytes(page_path)

                exported_files.append(page_path)
                print(f"Exported page {page + 1}/{total_pages}: {len(messages)} messages to {page_path}")

            # Final progress update
            if progress_callback:
                progress_callback(total_pages, total_pages, "Completed!")

            # Summary
            if total_pages > 1:
                print(f"Exported {total_messages} messages to {total_pages} files")
            else:
                print(f"Exported {total_messages} messages to {exported_files[0]}")

            # Return the last page's basename so conversations open to newest content
            last_file = os.path.basename(exported_files[-1]) if exported_files else None
            return last_file

        except Exception as e:
            print(f"Error exporting conversation: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _generate_html(self, messages: List[Dict[str, Any]],
                      conversation_name: str, attachments_dir: str,
                      current_page: int = 1, total_pages: int = 1,
                      base_filename: str = "",
                      output_path: str = "",
                      timeline_emitter=None,
                      link_hint: str = "") -> str:
        """
        Generate HTML for messages.

        Args:
            messages: List of messages to include
            conversation_name: Name of conversation
            attachments_dir: Directory for attachments
            current_page: Current page number (1-indexed)
            total_pages: Total number of pages
            base_filename: Base filename for navigation links
            output_path: Full path to the HTML file being generated

        Returns:
            HTML string
        """
        # Calculate correct relative path from HTML to attachments directory
        if output_path:
            html_dir = os.path.dirname(output_path)
            rel_path_prefix = os.path.relpath(attachments_dir, html_dir).replace('\\', '/')
        else:
            # Fallback for backwards compatibility
            rel_path_prefix = "../Message Attachments"

        html_header = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{conversation_name}</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}

        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            background: #f5f5f5;
            padding: 20px;
        }}

        .container {{
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }}

        .header {{
            background: linear-gradient(135deg, #20C83E 0%, #60F67B 100%);
            color: white;
            padding: 30px;
            margin-bottom: 0;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            text-align: left;
        }}

        .header h1 {{
            font-size: 32px;
            font-weight: 600;
            margin-bottom: 10px;
        }}
        .breadcrumbs {{
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            letter-spacing: 0.2px;
            color: rgba(255,255,255,0.85);
            margin-bottom: 10px;
        }}
        .breadcrumbs a {{
            color: #fff;
            text-decoration: none;
            font-weight: 600;
        }}
        .breadcrumbs a:hover {{
            text-decoration: underline;
        }}
        .breadcrumbs .back-arrow {{
            opacity: 0.6;
        }}
        .embedded .breadcrumbs {{
            display: none;
        }}

        .header p {{
            font-size: 16px;
            opacity: 0.9;
            margin: 0;
        }}

        .messages {{
            padding: 20px;
            min-height: 400px;
        }}

        .date-separator {{
            text-align: center;
            margin: 20px 0;
            color: #999;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }}

        .message {{
            margin: 10px 0;
            display: flex;
            clear: both;
        }}
        .highlight-target {{
            background-color: #fff3cd;
            outline: 2px solid #f59e0b;
        }}
        .highlight-target .bubble {{
            background-color: #fff3cd;
        }}
        .search-hit {{
            background: #ffec99;
            border-radius: 3px;
            padding: 0 1px;
        }}
        .search-hit-block {{
            background: #fff7d6;
            border: 2px solid #f59e0b;
            border-radius: 12px;
            padding: 4px;
        }}
        .message.deleted .bubble {{
            border: 1px dashed #c0392b;
            background: #fdf2f2;
        }}

        .message.sent {{
            justify-content: flex-end;
        }}

        .message.received {{
            justify-content: flex-start;
        }}

        .bubble {{
            max-width: 65%;
            padding: 10px 15px;
            border-radius: 18px;
            word-wrap: break-word;
            position: relative;
        }}

        .message.sent .bubble {{
            background: #d2f6cb;
            color: #000;
        }}

        .message.received .bubble {{
            background: #f0f0f0;
            color: #000;
        }}

        .bubble-content {{
            margin-bottom: 5px;
        }}

        .bubble-placeholder {{
            font-style: italic;
            opacity: 0.7;
        }}

        .timestamp {{
            font-size: 10px;
            color: #666;
            margin-top: 5px;
        }}
        .deleted-badge {{
            display: inline-block;
            padding: 2px 6px;
            background: #c0392b;
            color: white;
            border-radius: 6px;
            font-size: 11px;
            margin-right: 6px;
            font-weight: 600;
        }}

        .attachment {{
            margin-top: 10px;
            border-radius: 10px;
            overflow: hidden;
            max-width: 100%;
        }}

        .attachment img {{
            max-width: 100%;
            display: block;
            border-radius: 8px;
        }}

        .attachment video {{
            max-width: 100%;
            display: block;
            border-radius: 8px;
        }}

        .attachment audio {{
            max-width: 100%;
            display: block;
            margin-bottom: 5px;
        }}

        .attachment-filename {{
            font-size: 11px;
            color: #666;
            margin-top: 5px;
        }}

        .attachment-link {{
            display: block;
            padding: 10px;
            background: rgba(0,0,0,0.05);
            border-radius: 5px;
            margin-top: 5px;
            text-decoration: none;
            color: #007aff;
            font-size: 12px;
        }}

        .attachment-link:hover {{
            background: rgba(0,0,0,0.1);
        }}

        .attachment-pdf {{
            background: rgba(255,0,0,0.05);
        }}

        .attachment-contact {{
            background: rgba(0,122,255,0.05);
        }}

        .pagination {{
            background: #f9f9f9;
            padding: 15px 20px;
            border-bottom: 1px solid #e0e0e0;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 20px;
            font-size: 14px;
        }}

        .pagination a {{
            color: #007aff;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 6px;
            background: white;
            border: 1px solid #007aff;
            transition: all 0.2s;
        }}

        .pagination a:hover {{
            background: #007aff;
            color: white;
        }}

        .pagination a.disabled {{
            color: #ccc;
            border-color: #ccc;
            pointer-events: none;
            cursor: not-allowed;
        }}

        .pagination .page-info {{
            color: #666;
            font-weight: 500;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Messages.html">Back to conversations</a></div>
            <h1>{conversation_name}</h1>
        </div>
{{navigation_top}}
        <div class="messages">
"""

        html_footer = """
        </div>
{navigation_bottom}
    </div>
  <script>
      (function() {
          if (!window.location.hash) return;
          const target = document.querySelector(window.location.hash);
          if (!target) return;
          target.classList.add('highlight-target');
          try {
              target.scrollIntoView({ block: 'center' });
          } catch (e) {
              target.scrollIntoView();
          }
      })();
  </script>
  <script>
      (function() {
          const params = new URLSearchParams(window.location.search);
          const term = (params.get('q') || localStorage.getItem('messagesLastSearch') || '').trim();
          if (!term) return;

          function highlightInElement(element, query) {
              const needle = query.toLowerCase();
              const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT, {
                  acceptNode(node) {
                      if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
                      const parent = node.parentElement;
                      if (!parent) return NodeFilter.FILTER_REJECT;
                      if (parent.classList && parent.classList.contains('search-hit')) return NodeFilter.FILTER_REJECT;
                      return NodeFilter.FILTER_ACCEPT;
                  }
              });
              const nodes = [];
              let node;
              while ((node = walker.nextNode())) {
                  if (node.nodeValue.toLowerCase().includes(needle)) {
                      nodes.push(node);
                  }
              }
              nodes.forEach(textNode => {
                  const text = textNode.nodeValue;
                  const lower = text.toLowerCase();
                  const frag = document.createDocumentFragment();
                  let lastIndex = 0;
                  let idx = lower.indexOf(needle, lastIndex);
                  while (idx !== -1) {
                      const before = text.slice(lastIndex, idx);
                      if (before) frag.appendChild(document.createTextNode(before));
                      const mark = document.createElement('mark');
                      mark.className = 'search-hit';
                      mark.textContent = text.slice(idx, idx + needle.length);
                      frag.appendChild(mark);
                      lastIndex = idx + needle.length;
                      idx = lower.indexOf(needle, lastIndex);
                  }
                  const after = text.slice(lastIndex);
                  if (after) frag.appendChild(document.createTextNode(after));
                  textNode.parentNode.replaceChild(frag, textNode);
              });
          }

          const targets = document.querySelectorAll('.bubble-content, .bubble-placeholder');
          targets.forEach(el => highlightInElement(el, term));
          document.querySelectorAll('.search-hit').forEach(mark => {
              const block = mark.closest('.message');
              if (block) block.classList.add('search-hit-block');
          });

          function scrollToFirstHit() {
              const first = document.querySelector('.search-hit');
              if (!first) return;
              try {
                  first.scrollIntoView({ block: 'center' });
              } catch (e) {
                  first.scrollIntoView();
              }
              const block = first.closest('.message');
              if (!block) return;
              const imgs = block.querySelectorAll('img');
              if (!imgs.length) return;
              let pending = imgs.length;
              imgs.forEach(img => {
                  if (img.complete) {
                      pending -= 1;
                      return;
                  }
                  img.addEventListener('load', () => {
                      pending -= 1;
                      if (pending <= 0) {
                          try {
                              first.scrollIntoView({ block: 'center' });
                          } catch (e) {
                              first.scrollIntoView();
                          }
                      }
                  }, { once: true });
              });
          }

          scrollToFirstHit();
          requestAnimationFrame(() => {
              scrollToFirstHit();
              setTimeout(scrollToFirstHit, 250);
          });
      })();
  </script>
  <script>
  (function() {
    try {
      if (window.parent && window.parent !== window) {
        window.parent.postMessage({type: 'device-nav', href: window.location.href}, '*');
      }
    } catch (err) {}
  })();
  </script>
  </body>
  </html>
  """

        # Build message HTML
        messages_html = []
        last_date = None

        for msg in messages:
            # Format date
            msg_date = self._format_apple_timestamp(msg['date'])
            msg_date_str = msg_date.strftime('%B %d, %Y') if msg_date else 'Unknown Date'
            msg_time_str = msg_date.strftime('%I:%M %p') if msg_date else ''

            # Add date separator if date changed
            if msg_date_str != last_date:
                messages_html.append(f'<div class="date-separator">{msg_date_str}</div>')
                last_date = msg_date_str

            # Message bubble
            msg_class = 'sent' if msg['is_from_me'] else 'received'
            if msg.get('is_deleted'):
                msg_class += ' deleted'

            bubble_content = ''

            # Add text content
            if msg.get('is_deleted'):
                badge = '<span class="deleted-badge">Deleted</span>'
            else:
                badge = ''

            if msg['text']:
                bubble_content += f'<div class="bubble-content">{badge}{self._escape_html(msg["text"])}</div>'
            elif msg.get('subject'):
                bubble_content += f'<div class="bubble-content">{badge}{self._escape_html(msg["subject"])}</div>'
            elif msg.get('attributed_text'):
                bubble_content += f'<div class="bubble-content">{badge}{self._escape_html(msg["attributed_text"])}</div>'
            elif badge:
                bubble_content += f'<div class="bubble-content">{badge}Deleted message</div>'

            # Add attachments
            for att in msg['attachments']:
                attachment_html = self._format_attachment(att, attachments_dir, rel_path_prefix)
                if attachment_html:
                    bubble_content += attachment_html

            if not msg['text'] and not msg.get('subject') and not msg.get('attributed_text') and not msg['attachments']:
                if msg.get('has_attributed_body'):
                    bubble_content += f'<div class="bubble-placeholder">{badge}Message content stored as rich text (not decoded)</div>'
                elif msg.get('is_deleted'):
                    bubble_content += f'<div class="bubble-placeholder">{badge}Deleted message</div>'
                else:
                    bubble_content += '<div class="bubble-placeholder">No content recovered (possibly deleted)</div>'

            msg_anchor = f"msg-{msg.get('message_id', '')}"
            if timeline_emitter is not None:
                self._emit_message_timeline_event(msg, conversation_name, msg_date, timeline_emitter, link_hint, msg_anchor)

            messages_html.append(f'''
            <div class="message {msg_class}" id="{self._escape_html(msg_anchor)}">
                <div class="bubble">
                    {bubble_content}
                    <div class="timestamp">{msg_time_str}</div>
                </div>
            </div>
            ''')

        # Generate navigation HTML if multi-page
        navigation_html = ""
        if total_pages > 1:
            # Build navigation links
            prev_link = ""
            if current_page > 1:
                prev_filename = f"{base_filename}_Page_{current_page - 1}.html"
                prev_link = f'<a href="{prev_filename}">← Previous</a>'
            else:
                prev_link = '<a class="disabled">← Previous</a>'

            next_link = ""
            if current_page < total_pages:
                next_filename = f"{base_filename}_Page_{current_page + 1}.html"
                next_link = f'<a href="{next_filename}">Next →</a>'
            else:
                next_link = '<a class="disabled">Next →</a>'

            navigation_html = f'''
        <div class="pagination">
            {prev_link}
            <span class="page-info">Page {current_page} of {total_pages}</span>
            {next_link}
        </div>'''

        # Replace navigation placeholders
        html_header = html_header.replace('{navigation_top}', navigation_html)
        html_footer = html_footer.replace('{navigation_bottom}', navigation_html)

        return html_header + '\n'.join(messages_html) + html_footer

    def _format_attachment(self, attachment: Dict[str, Any], attachments_dir: str, rel_path_prefix: str = "../Message Attachments") -> str:
        """Format attachment HTML."""
        if not attachment['filename']:
            return ''

        # Get attachment file from backup
        source_path = self.get_attachment_path(attachment['filename'])

        if not source_path or not os.path.exists(source_path):
            return f'<div class="attachment-link">[Attachment not found: {attachment.get("transfer_name", "unknown")}]</div>'

        # Copy attachment to export directory
        filename = attachment['transfer_name'] or os.path.basename(attachment['filename'])
        dest_path = os.path.join(attachments_dir, filename)

        # Handle duplicate filenames
        base, ext = os.path.splitext(filename)
        counter = 1
        while os.path.exists(dest_path):
            filename = f"{base}_{counter}{ext}"
            dest_path = os.path.join(attachments_dir, filename)
            counter += 1

        try:
            # Use copyfile for faster copying (timestamps not critical for SMS attachments)
            shutil.copyfile(source_path, dest_path)
            self._add_export_bytes(dest_path)

            # Handle pluginPayloadAttachment files (detect actual type and rename)
            if filename.endswith('.pluginPayloadAttachment') and PIL_AVAILABLE:
                try:
                    # Detect actual file type using PIL
                    img = Image.open(dest_path)
                    img_format = img.format.lower() if img.format else None
                    img.close()

                    if img_format:
                        # Create new filename with correct extension
                        base_name = os.path.splitext(filename)[0]
                        if img_format == 'jpeg':
                            new_filename = f"{base_name}.jpg"
                            new_mime_type = 'image/jpeg'
                        elif img_format == 'png':
                            new_filename = f"{base_name}.png"
                            new_mime_type = 'image/png'
                        elif img_format == 'gif':
                            new_filename = f"{base_name}.gif"
                            new_mime_type = 'image/gif'
                        elif img_format == 'webp':
                            new_filename = f"{base_name}.webp"
                            new_mime_type = 'image/webp'
                        else:
                            # Other image types
                            new_filename = f"{base_name}.{img_format}"
                            new_mime_type = f'image/{img_format}'

                        # Create copy with correct extension
                        new_dest_path = os.path.join(attachments_dir, new_filename)
                        shutil.copyfile(dest_path, new_dest_path)
                        self._add_export_bytes(new_dest_path)

                        # Update references to use the correctly-named file
                        filename = new_filename
                        dest_path = new_dest_path

                        # Update mime_type if it was missing or wrong
                        if not attachment['mime_type'] or not attachment['mime_type'].startswith('image/'):
                            attachment['mime_type'] = new_mime_type

                        print(f"Converted pluginPayloadAttachment to {new_filename} (detected as {img_format})")
                except Exception as e:
                    print(f"Warning: Could not process pluginPayloadAttachment {filename}: {e}")
                    # Continue with original file

            # Convert HEIC images to JPG for Windows compatibility
            if HEIC_CONVERSION_AVAILABLE and PIL_AVAILABLE:
                file_ext = os.path.splitext(filename)[1].lower()
                if file_ext in ['.heic', '.heif']:
                    try:
                        # Open HEIC and convert to JPG
                        img = Image.open(dest_path)
                        jpg_filename = os.path.splitext(filename)[0] + '.jpg'
                        jpg_path = os.path.join(attachments_dir, jpg_filename)

                        # Convert to RGB if necessary (HEIC can be in different color modes)
                        if img.mode in ('RGBA', 'LA', 'P'):
                            img = img.convert('RGB')

                        img.save(jpg_path, 'JPEG', quality=95)

                        # Use JPG instead of HEIC for HTML reference
                        filename = jpg_filename
                        dest_path = jpg_path

                        print(f"Converted HEIC to JPG: {jpg_filename}")
                    except Exception as e:
                        print(f"Warning: Could not convert HEIC {filename}: {e}")
                        # Continue with original HEIC file

        except Exception as e:
            print(f"Warning: Could not copy attachment {filename}: {e}")
            return f'<div class="attachment-link">[Could not copy: {filename}]</div>'

        # Generate HTML based on mime type
        mime_type = attachment['mime_type'] or ''
        # Use calculated relative path from HTML to attachments directory
        rel_path = f"{rel_path_prefix}/{filename}"

        if mime_type.startswith('image/'):
            return f'<div class="attachment"><img src="{rel_path}" alt="{filename}"></div>'
        elif mime_type.startswith('video/'):
            return f'<div class="attachment"><video src="{rel_path}" controls></video></div>'
        elif mime_type.startswith('audio/'):
            # Audio files including voice messages
            return f'<div class="attachment"><audio src="{rel_path}" controls></audio><div class="attachment-filename">🎤 {filename}</div></div>'
        elif mime_type == 'application/pdf':
            return f'<a href="{rel_path}" class="attachment-link attachment-pdf">📄 {filename}</a>'
        elif mime_type in ('text/vcard', 'text/x-vcard'):
            return f'<a href="{rel_path}" class="attachment-link attachment-contact">👤 {filename}</a>'
        elif mime_type.startswith('text/'):
            return f'<a href="{rel_path}" class="attachment-link">📝 {filename}</a>'
        else:
            return f'<a href="{rel_path}" class="attachment-link">📎 {filename}</a>'

    def _format_apple_timestamp(self, timestamp: Optional[float]) -> Optional[datetime]:
        """
        Convert Apple/iOS timestamp to datetime.

        iOS Messages uses nanoseconds since 2001-01-01 00:00:00 UTC.
        Some other iOS databases use seconds since 2001-01-01.
        """
        if timestamp is None or timestamp == 0:
            return None
        try:
            # Apple epoch is 2001-01-01 00:00:00 UTC
            apple_epoch = datetime(2001, 1, 1, tzinfo=timezone.utc).timestamp()

            # iOS Messages uses nanoseconds (very large numbers)
            # Detect format based on magnitude
            if timestamp > 1000000000000:  # Likely nanoseconds
                # Convert nanoseconds to seconds
                timestamp_seconds = timestamp / 1000000000.0
            else:
                # Already in seconds
                timestamp_seconds = timestamp

            unix_timestamp = apple_epoch + timestamp_seconds

            return datetime.fromtimestamp(unix_timestamp)
        except Exception:
            return None

    def _format_timestamp_iso(self, timestamp: Optional[float]) -> Optional[str]:
        dt = self._format_apple_timestamp(timestamp)
        if not dt:
            return None
        try:
            return dt.isoformat()
        except Exception:
            return None

    def _emit_message_timeline_event(self, msg: Dict[str, Any], conversation_name: str,
                                     msg_date: Optional[datetime], emitter, link_hint: str,
                                     anchor: str) -> None:
        timestamp_iso = self._format_timestamp_iso(msg.get('date'))
        if not timestamp_iso:
            return
        title_text = msg.get('text') or msg.get('subject') or msg.get('attributed_text') or "(No content)"
        direction = "sent" if msg.get('is_from_me') else "received"
        emitter.emit({
            "timestamp": timestamp_iso,
            "timestamp_display": timestamp_iso,
            "timestamp_utc": timestamp_iso,
            "raw_timestamp": msg.get('date'),
            "raw_format": "apple_message_date",
            "source_app": "Messages",
            "source_category": "Messages",
            "event_type": f"message_{direction}",
            "title": f"{conversation_name}: {title_text[:80]}",
            "details": {
                "conversation": conversation_name,
                "message": title_text,
                "service": msg.get('service', ''),
                "handle": msg.get('handle', ''),
            },
            "confidence": "high",
            "raw_source_path": "sms.db",
            "report_anchor": anchor,
            "link_hint": link_hint,
        })
        attachments = msg.get("attachments") or []
        for att in attachments:
            filename = att.get("transfer_name") or os.path.basename(att.get("filename") or "")
            if not filename:
                continue
            mime_type = (att.get("mime_type") or "").lower()
            event_type = "file_attachment"
            if mime_type.startswith("image/"):
                event_type = "photo_attachment"
            elif mime_type.startswith("video/"):
                event_type = "video_attachment"
            elif mime_type.startswith("audio/"):
                event_type = "audio_attachment"
            elif not mime_type and "." in filename:
                ext = os.path.splitext(filename)[1].lower()
                if ext in (".jpg", ".jpeg", ".png", ".gif", ".heic", ".heif", ".bmp", ".tif", ".tiff", ".webp"):
                    event_type = "photo_attachment"
                elif ext in (".mov", ".mp4", ".m4v", ".avi", ".mkv", ".3gp", ".3gpp"):
                    event_type = "video_attachment"
                elif ext in (".m4a", ".aac", ".mp3", ".wav", ".aiff", ".amr", ".caf", ".flac", ".opus"):
                    event_type = "audio_attachment"
            emitter.emit({
                "timestamp": timestamp_iso,
                "timestamp_display": timestamp_iso,
                "timestamp_utc": timestamp_iso,
                "raw_timestamp": msg.get("date"),
                "raw_format": "apple_message_date",
                "source_app": "Messages",
                "source_category": "Messages",
                "event_type": event_type,
                "title": f"{conversation_name}: {filename}",
                "details": {
                    "conversation": conversation_name,
                    "filename": filename,
                    "mime_type": att.get("mime_type"),
                    "attachment_id": att.get("attachment_id"),
                    "direction": direction,
                },
                "confidence": "low" if event_type == "file_attachment" else "high",
                "raw_source_path": att.get("filename") or "",
                "report_anchor": anchor,
                "link_hint": link_hint,
            })

    def _format_handle(self, handle_id: str) -> str:
        """Format handle (phone/email) for display."""
        if not handle_id:
            return "Unknown"

        # Format phone numbers
        if handle_id.startswith('+1') and len(handle_id) == 12:
            # US phone number: +1XXXXXXXXXX -> (XXX) XXX-XXXX
            return f"({handle_id[2:5]}) {handle_id[5:8]}-{handle_id[8:]}"

        return handle_id

    def _escape_html(self, text: str) -> str:
        """Escape HTML special characters."""
        if not text:
            return ''

        return (text
                .replace('&', '&amp;')
                .replace('<', '&lt;')
                .replace('>', '&gt;')
                .replace('"', '&quot;')
                .replace("'", '&#39;')
                .replace('\n', '<br>'))

    # Methods for compatibility with CategoryDataExtractor base class
    def get_count(self) -> int:
        """Get total number of messages for Extract All counts."""
        return self.get_total_message_count()

    def get_items(self, limit: Optional[int] = None, offset: int = 0, **kwargs) -> List[Dict[str, Any]]:
        """Get conversations (for base class compatibility)."""
        search = kwargs.get('search', None)
        return self.get_conversations(limit, offset, search)

    def get_item_summary(self, item: Dict[str, Any]) -> str:
        """Get summary string for conversation list."""
        return f"{item['display_name']} - {item['last_message'][:50]}"

    def export(self, items: List[Dict[str, Any]], output_path: str, format: str = 'html',
               progress_callback=None, timeline_emitter=None) -> bool:
        """
        Export conversations to HTML files with index.

        Creates:
        - Messages.html: Index of all conversations with search
        - Conversations/: Subdirectory containing individual conversation HTML files
        - Message Attachments/: Directory for media files

        Args:
            items: List of conversations (chat IDs or full conversation dicts)
            output_path: Output directory path
            format: 'html'
            progress_callback: Optional callback(current, total, item_name) -> bool

        Returns:
            True if export succeeded
        """
        if format != 'html':
            raise ValueError(f"Unsupported export format: {format}")

        try:
            self._reset_export_bytes()
            os.makedirs(output_path, exist_ok=True)

            # Create Conversations subdirectory
            conversations_dir = os.path.join(output_path, 'Conversations')
            os.makedirs(conversations_dir, exist_ok=True)

            # Track conversation info for index
            conversation_list = []

            # Track used filenames to prevent collisions between conversations with same display name
            used_filenames = set()

            total = len(items) + 1  # +1 for creating index at the end

            # Build lookup for conversation metadata (used when items are chat IDs)
            conv_lookup = None
            if any(not isinstance(it, dict) for it in items):
                try:
                    conv_lookup = {c['chat_id']: c for c in self.get_conversations()}
                except Exception:
                    conv_lookup = {}

            for i, item in enumerate(items):
                if isinstance(item, dict):
                    chat_id = item['chat_id']
                    display_name = item['display_name']
                    last_message = item.get('last_message', '')
                    last_message_date = item.get('last_message_date', 0)
                    message_count = item.get('message_count', 0)
                    is_group = item.get('is_group', False)
                    has_deleted = bool(item.get('has_deleted'))
                else:
                    chat_id = item
                    meta = conv_lookup.get(chat_id, {}) if conv_lookup else {}
                    display_name = meta.get('display_name', f"Conversation_{chat_id}")
                    last_message = meta.get('last_message', '')
                    last_message_date = meta.get('last_message_date', 0)
                    message_count = meta.get('message_count', 0)
                    is_group = meta.get('is_group', False)
                    has_deleted = bool(meta.get('has_deleted'))

                # Report progress
                if progress_callback:
                    if not progress_callback(i + 1, total, f"Exporting: {display_name}"):
                        return False

                # Sanitize filename
                safe_name = "".join(c for c in display_name if c.isalnum() or c in (' ', '-', '_')).strip()

                # Prevent filename collisions (e.g., SMS and iMessage conversations with same contact)
                base_name = safe_name
                if base_name in used_filenames:
                    # Append chat_id to make it unique
                    safe_name = f"{base_name}_chat{chat_id}"
                used_filenames.add(safe_name)

                html_file = os.path.join(conversations_dir, f"{safe_name}.html")

                # Export individual conversation (returns last page filename)
                last_page = self.export_conversation_html(
                    chat_id,
                    html_file,
                    display_name,
                    timeline_emitter=timeline_emitter
                )

                # Track for index (use actual first page filename for multi-page conversations)
                conversation_list.append({
                    'chat_id': chat_id,  # Add chat_id for search index generation
                    'display_name': display_name,
                    'safe_name': safe_name,
                    'file_name': last_page or f"{safe_name}.html",  # Use actual filename or fallback
                    'last_message': last_message,
                    'last_message_date': last_message_date,
                    'message_count': message_count,
                    'is_group': is_group,
                    'has_deleted': has_deleted
                })

            # Create Messages.html index
            if progress_callback:
                if not progress_callback(total, total, "Creating index..."):
                    return False

            # Create Messages.html index (with embedded search index)
            self._create_messages_index(output_path, conversation_list, progress_callback=progress_callback)

            return True

        except Exception as e:
            print(f"Error exporting conversations: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _create_messages_index(self, output_path: str, conversations: List[Dict[str, Any]], progress_callback=None):
        """Create Messages.html index with all conversations."""
        import json

        index_file = os.path.join(output_path, 'Messages.html')

        # Generate search index data for inlining
        print(f"Generating search index for full-content search ({len(conversations)} conversations)...", flush=True)
        search_index_data = []
        indexed_count = 0
        failed_count = 0
        indexed_messages = 0
        total_messages = sum(max(0, conv.get('message_count', 0)) for conv in conversations)

        for conv in conversations:
            try:
                # Get all messages for this conversation
                messages = self.get_messages(conv['chat_id'], limit=None, offset=0)

                # Concatenate all message text for searching
                message_text_parts = []
                for msg in messages:
                    if msg.get('text'):
                        text = msg['text'].replace('<br>', ' ')
                        message_text_parts.append(text)

                all_message_text = ' '.join(message_text_parts)

                # Add to search index
                search_index_data.append({
                    'safe_name': conv['safe_name'],
                    'display_name': conv['display_name'],
                    'text': all_message_text
                })
                indexed_count += 1
                indexed_messages += len(messages)

                if progress_callback and total_messages:
                    progress_callback(indexed_messages, total_messages, "Indexing messages for search...")
                    if indexed_messages == len(messages) and indexed_count == 1:
                        print("[INFO] Indexing messages for search...")

                # Progress indicator every 100 conversations
                if indexed_count % 100 == 0:
                    print(f"  Indexed {indexed_count}/{len(conversations)} conversations...", flush=True)

            except Exception as e:
                failed_count += 1
                print(f"Warning: Could not index conversation '{conv['display_name']}': {e}", flush=True)
                if failed_count <= 5:  # Show traceback for first few errors
                    import traceback
                    traceback.print_exc()
                continue

        print(f"Search index complete: {indexed_count} indexed, {failed_count} failed", flush=True)

        if indexed_count == 0 and len(conversations) > 0:
            print(f"ERROR: No conversations were indexed! All {len(conversations)} conversations failed.", flush=True)
            print("Full-content search will not work. Please report this issue.", flush=True)

        # Convert to JSON for embedding
        search_index_json = json.dumps({'version': '1.0', 'conversations': search_index_data}, ensure_ascii=False)

        html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messages</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: #f6f6f6;
            padding: 20px;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            overflow: hidden;
        }}
        .header {{
            background: linear-gradient(135deg, #20C83E 0%, #60F67B 100%);
            color: white;
            padding: 30px;
            text-align: left;
        }}
        .header h1 {{
            font-size: 32px;
            font-weight: 600;
            margin-bottom: 10px;
        }}
        .breadcrumbs {{
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            letter-spacing: 0.2px;
            color: rgba(255,255,255,0.85);
            margin-bottom: 10px;
        }}
        .breadcrumbs a {{
            color: #fff;
            text-decoration: none;
            font-weight: 600;
        }}
        .breadcrumbs a:hover {{
            text-decoration: underline;
        }}
        .breadcrumbs .back-arrow {{
            opacity: 0.6;
        }}
        .embedded .breadcrumbs {{
            display: none;
        }}
        .header p {{
            font-size: 16px;
            opacity: 0.9;
            margin: 0;
        }}
        .search-box {{
            padding: 20px;
            border-bottom: 1px solid #e5e5e5;
            position: relative;
        }}
        .search-box input {{
            width: 100%;
            padding: 12px 46px 12px 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
        }}
        .search-box input:focus {{
            outline: none;
            border-color: #20C83E;
        }}
        .clear-search {{
            position: absolute;
            right: 24px;
            top: 50%;
            transform: translateY(-50%);
            border: 1px solid #d1d5db;
            background: #f3f4f6;
            color: #111827;
            border-radius: 6px;
            padding: 4px 8px;
            font-size: 12px;
            cursor: pointer;
            display: none;
        }}
        .clear-search.visible {{ display: inline-block; }}
        .conversation {{
            padding: 15px 20px;
            border-bottom: 1px solid #e5e5e5;
            cursor: pointer;
            transition: background-color 0.2s;
            display: block;
            text-decoration: none;
            color: inherit;
        }}
        .conversation:last-child {{
            border-bottom: none;
        }}
        .conversation:hover {{
            background-color: #f8f8f8;
        }}
        .conversation.hidden {{
            display: none;
        }}
        .conv-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 6px;
        }}
        .conv-name {{
            font-size: 16px;
            font-weight: 600;
            color: #000;
            flex: 1;
        }}
        .conv-date {{
            font-size: 14px;
            color: #8E8E93;
            margin-left: 10px;
        }}
        .conv-preview {{
            font-size: 14px;
            color: #8E8E93;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }}
        .conv-badge {{
            display: inline-block;
            background-color: #007AFF;
            color: white;
            border-radius: 10px;
            padding: 2px 8px;
            font-size: 12px;
            font-weight: 600;
            margin-left: 8px;
        }}
        .conv-deleted {{
            display: inline-block;
            background-color: #c0392b;
            color: white;
            border-radius: 10px;
            padding: 2px 8px;
            font-size: 12px;
            font-weight: 600;
            margin-left: 8px;
        }}
        .conv-pinned {{
            display: inline-block;
            background-color: #f1c40f;
            color: #2c3e50;
            border-radius: 10px;
            padding: 2px 8px;
            font-size: 12px;
            font-weight: 600;
            margin-left: 8px;
        }}
        .no-results {{
            text-align: center;
            padding: 40px;
            color: #8E8E93;
            font-size: 16px;
            display: none;
        }}
        .no-results.visible {{
            display: block;
        }}
        .export-info {{
            text-align: center;
            padding: 20px;
            color: #8E8E93;
            font-size: 14px;
        }}
        .group-icon {{
            color: #8E8E93;
            margin-right: 4px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Start_Here.html">Back</a></div>
            <h1>Messages</h1>
            <p>Extracted from iOS Backup on {datetime.now().strftime("%B %d, %Y")}</p>
        </div>

        <div class="search-box">
            <input type="text" id="searchInput" placeholder="Search conversations..." onkeyup="filterConversations()">
            <button id="clearSearch" class="clear-search" title="Clear" aria-label="Clear search">X</button>
        </div>

        <div id="conversationList">
'''

        # Add each conversation
        for conv in conversations:
            # Format timestamp
            timestamp_str = ""
            if conv['last_message_date']:
                try:
                    dt = self._format_apple_timestamp(conv['last_message_date'])
                    if dt:
                        now = datetime.now(timezone.utc)
                        if dt.date() == now.date():
                            timestamp_str = dt.strftime("%I:%M %p")
                        elif (now - dt).days < 7:
                            timestamp_str = dt.strftime("%A")
                        else:
                            timestamp_str = dt.strftime("%m/%d/%y")
                except:
                    timestamp_str = ""

            # Preview text
            preview = conv['last_message'] or '(No preview available)'
            if len(preview) > 100:
                preview = preview[:100] + '...'

            # Group icon
            group_icon = '<span class="group-icon">&#128101;</span>' if conv['is_group'] else ''

            # Message count badge, pinned badge, and deleted badge
            count_badge = f'<span class="conv-badge">{conv["message_count"]}</span>' if conv['message_count'] > 0 else ''
            pinned_badge = '<span class="conv-pinned">Pinned</span>' if conv.get('is_pinned') else ''
            deleted_badge = '<span class="conv-deleted">Deleted</span>' if conv.get('has_deleted') else ''

            # Use actual filename (handles multi-page conversations correctly)
            file_name = conv.get('file_name', f"{conv['safe_name']}.html")

            html += f'''            <a href="Conversations/{file_name}" class="conversation" data-name="{self._escape_html(conv['display_name'].lower())}" data-preview="{self._escape_html(preview.lower())}" data-safe-name="{self._escape_html(conv['safe_name'])}">
                <div class="conv-header">
                    <div class="conv-name">{group_icon}{self._escape_html(conv['display_name'])}{pinned_badge}{count_badge}{deleted_badge}</div>
                    <div class="conv-date">{timestamp_str}</div>
                </div>
                <div class="conv-preview">{self._escape_html(preview)}</div>
            </a>
'''

        html += '''            </div>
            <div class="no-results" id="noResults">No conversations found</div>
            <div class="export-info">
                Exported from iOS Backup Manager on ''' + datetime.now().strftime("%B %d, %Y at %I:%M %p") + f'''<br>
                Total conversations: {len(conversations)} | Total messages: {total_messages}
            </div>
        </div>
    </div>

    <script>
        // Inline search index data (loaded on first use to save initial page load time)
        let searchIndexData = {search_index_json};
        let searchIndex = null;

        // Parse search index on first search (lazy initialization)
        function initSearchIndex() {{
            if (searchIndex) return;
            searchIndex = searchIndexData;
            console.log('Search index initialized:', searchIndex.conversations.length, 'conversations');
            searchIndexData = null; // Free memory
        }}

        function filterConversations() {{
            const input = document.getElementById('searchInput');
            const clearBtn = document.getElementById('clearSearch');
            const rawTerm = input.value.trim();
            const filter = rawTerm.toLowerCase();
            if (rawTerm) {{
                localStorage.setItem('messagesLastSearch', rawTerm);
            }} else {{
                localStorage.removeItem('messagesLastSearch');
            }}
            const conversations = document.querySelectorAll('.conversation');
            const noResults = document.getElementById('noResults');

            // Initialize search index if user is typing (lazy init)
            if (filter && !searchIndex) {{
                initSearchIndex();
            }}

            let visibleCount = 0;

            conversations.forEach(conv => {{
                const name = conv.getAttribute('data-name') || '';
                const preview = conv.getAttribute('data-preview') || '';
                const safeName = conv.getAttribute('data-safe-name') || '';
                const link = conv.tagName === 'A' ? conv : conv.querySelector('a');
                if (link) {{
                    if (!link.dataset.baseHref) {{
                        link.dataset.baseHref = link.getAttribute('href');
                    }}
                    if (rawTerm) {{
                        link.setAttribute('href', `${{link.dataset.baseHref}}?q=${{encodeURIComponent(rawTerm)}}`);
                    }} else {{
                        link.setAttribute('href', link.dataset.baseHref);
                    }}
                }}

                let matches = false;

                // First check name and preview (fast)
                if (name.includes(filter) || preview.includes(filter)) {{
                    matches = true;
                }} else if (searchIndex) {{
                    // Search full content using index
                    const indexEntry = searchIndex.conversations.find(c => c.safe_name === safeName);
                    if (indexEntry && indexEntry.text && indexEntry.text.toLowerCase().includes(filter)) {{
                        matches = true;
                    }}
                }}

                if (matches) {{
                    conv.classList.remove('hidden');
                    visibleCount++;
                }} else {{
                    conv.classList.add('hidden');
                }}
            }});

            if (visibleCount === 0 && filter !== '') {{
                noResults.classList.add('visible');
            }} else {{
                noResults.classList.remove('visible');
            }}
            if (clearBtn) {{
                clearBtn.classList.toggle('visible', !!rawTerm);
            }}
        }}

        function applyStoredSearch() {{
            const input = document.getElementById('searchInput');
            if (!input) {{
                return;
            }}
            const saved = localStorage.getItem('messagesLastSearch') || '';
            if (saved) {{
                input.value = saved;
                filterConversations();
            }}
        }}

        document.addEventListener('DOMContentLoaded', () => {{
            applyStoredSearch();
            const clearBtn = document.getElementById('clearSearch');
            const input = document.getElementById('searchInput');
            if (clearBtn && input) {{
                clearBtn.addEventListener('click', () => {{
                    input.value = '';
                    localStorage.removeItem('messagesLastSearch');
                    filterConversations();
                    clearBtn.classList.remove('visible');
                    input.focus();
                }});
            }}
        }});

        window.addEventListener('pageshow', () => {{
            const input = document.getElementById('searchInput');
            if (input && input.value.trim()) {{
                filterConversations();
            }}
        }});
    </script>
    <script>
        (function() {{
            try {{
                if (window.parent && window.parent !== window) {{
                    window.parent.postMessage({{type: 'device-nav-root', href: window.location.href}}, '*');
                    window.parent.postMessage({{type: 'device-nav', href: window.location.href}}, '*');
                }}
            }} catch (err) {{}}
        }})();
    </script>
    <script>
        if (window.self !== window.top) {{
            document.body.classList.add('embedded');
        }}
    </script>
</body>
</html>'''

        # Write index file
        with open(index_file, 'w', encoding='utf-8') as f:
            f.write(html)
        self._add_export_bytes(index_file)

        print(f"Created Messages index: {index_file}")
