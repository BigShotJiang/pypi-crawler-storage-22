#!/usr/bin/env python3
"""
Snapchat extractor (tiered).

Tier 1: prefs/logs/caches + artifact inventory (always)
Tier 2: SQLite discovery summaries (when readable SQLite present)
Tier 3: full decrypt only when required DBs + keychain material exist (report-only for now)
"""

import base64
import binascii
import hashlib
import json
import math
import os
import re
import shutil
import sqlite3
from io import BytesIO
from typing import Any, Dict, List, Optional, Tuple

from .base import CategoryDataExtractor
from keychain_decoder import decode_keychain_item
from blob_decoders import decode_unknown_blob


class SnapchatExtractor(CategoryDataExtractor):
    """Extract Snapchat artifacts and summaries from iOS backups."""

    SNAPCHAT_DOMAIN = "AppDomain-com.toyopagroup.picaboo"
    SNAPCHAT_GROUP_DOMAIN = "AppDomainGroup-group.snapchat.picaboo"
    KEYCHAIN_DOMAIN = "KeychainDomain"

    SQLITE_EXTENSIONS = (".db", ".sqlite", ".sqlite3")
    SQLITE_HINTS = ("contentmanagerdb.db", "arroyo.db", "scdb-")

    KEYWORDS = [
        "snap", "picaboo", "user", "username", "account", "session", "token", "auth",
        "friend", "media", "story", "chat", "message",
    ]

    def __init__(self, backup_path: str):
        self._is_filesystem = False
        manifest_path = os.path.join(backup_path, "Manifest.db")
        if os.path.exists(manifest_path):
            super().__init__(backup_path)
        else:
            # FFS mode: treat backup_path as an app container root.
            self.backup_path = backup_path
            self.backup_access = None
            self.manifest_db_path = None
            self._file_path_cache = {}
            self._use_cache = False
            self.last_export_bytes = 0
            docs = os.path.join(backup_path, "Documents")
            lib = os.path.join(backup_path, "Library")
            if not (os.path.isdir(docs) and os.path.isdir(lib)):
                raise FileNotFoundError("Manifest.db not found and no app container detected.")
            self._is_filesystem = True
        self._items = self._scan_items()

        if not self._items:
            raise FileNotFoundError("Snapchat artifacts not found in backup")

    def get_count(self) -> int:
        return len(self._items)

    def get_items(self, limit: Optional[int] = None, offset: int = 0,
                  search: Optional[str] = None) -> List[Dict[str, Any]]:
        items = self._items
        if search:
            needle = search.lower()
            items = [
                item for item in items
                if needle in item.get("relative_path", "").lower()
                or needle in item.get("category", "").lower()
            ]
        if offset > 0:
            items = items[offset:]
        if limit is not None:
            items = items[:limit]
        return items

    def get_item_summary(self, item: Dict[str, Any]) -> str:
        rel_path = item.get("relative_path", "Unknown")
        size = item.get("file_size", 0)
        return f"{rel_path} ({size} bytes)"

    def export(self, items: List[Dict[str, Any]], output_path: str,
               format: str = "html", progress_callback=None) -> bool:
        try:
            self._reset_export_bytes()
            os.makedirs(output_path, exist_ok=True)

            folders = {
                "prefs": os.path.join(output_path, "Preferences"),
                "logs": os.path.join(output_path, "Logs"),
                "caches": os.path.join(output_path, "Caches"),
                "sqlite": os.path.join(output_path, "SQLite"),
                "artifacts": os.path.join(output_path, "Artifacts"),
                "sqlcipher": os.path.join(output_path, "SQLCipher"),
                "contentmanager": os.path.join(output_path, "ContentManager"),
                "reports": output_path,
            }
            for folder in folders.values():
                os.makedirs(folder, exist_ok=True)

            exported = {
                "prefs": [],
                "logs": [],
                "caches": [],
                "sqlite": [],
                "artifacts": [],
            }

            total = len(items)
            for idx, item in enumerate(items, 1):
                if progress_callback:
                    if not progress_callback(idx, total, item.get("relative_path", "")):
                        return False

                category = item.get("category")
                src_path = item.get("physical_path")
                if not src_path or not os.path.exists(src_path):
                    continue

                dest_dir = folders.get(category, output_path)
                dest_path = os.path.join(dest_dir, os.path.basename(item.get("relative_path", "item")))
                dest_path = self._dedupe_path(dest_path)

                try:
                    shutil.copy2(src_path, dest_path)
                except Exception:
                    continue

                record = {
                    "relative_path": item.get("relative_path"),
                    "domain": item.get("domain"),
                    "file_size": item.get("file_size"),
                    "manifest_size": item.get("manifest_size"),
                    "output_path": os.path.relpath(dest_path, output_path),
                }
                exported[category].append(record)
                self._add_export_bytes(dest_path)

            sqlite_summary = self._build_sqlite_summary(exported.get("sqlite", []), output_path)
            artifact_inventory = self._build_artifact_inventory(items, output_path)
            tier_status = self._get_tier_status(items)

            key_candidates = []
            keychain_entries = tier_status.get("keychain", {}).get("entries", [])
            if keychain_entries:
                fidelius_dir = os.path.join(output_path, "Fidelius")
                os.makedirs(fidelius_dir, exist_ok=True)
                key_candidates = self._collect_key_candidates(keychain_entries, cap=300)
                keybag = None
                if getattr(self.backup_access, "_encrypted", None) is not None:
                    keybag = getattr(self.backup_access._encrypted, "_keybag", None)
                if keybag is not None:
                    try:
                        import plistlib
                        keychain_path = self._get_keychain_path()
                        if keychain_path and os.path.exists(keychain_path):
                            with open(keychain_path, "rb") as f:
                                keychain_data = plistlib.load(f)
                            extra_entries = self._collect_key_candidates_from_keychain(
                                keychain_data,
                                keybag,
                                cap=500,
                            )
                            db_entries = self._collect_key_candidates_from_snapchat_dbs(
                                items,
                                cap=300,
                            )
                            combined = keychain_entries + extra_entries + db_entries
                            if combined:
                                key_candidates = self._collect_key_candidates(
                                    combined,
                                    cap=800,
                                )
                    except Exception:
                        pass

                json_entries = []
                for entry in keychain_entries:
                    if entry.get("fidelius_raw"):
                        raw_bytes = entry["fidelius_raw"]
                        acct = entry.get("acct") or "fidelius"
                        safe_name = f"{acct}_{entry.get('index', 0)}.bin"
                        out_path = self._dedupe_path(os.path.join(fidelius_dir, safe_name))
                        with open(out_path, "wb") as raw_out:
                            raw_out.write(raw_bytes)
                        entry["fidelius_file"] = os.path.relpath(out_path, output_path)
                        fidelius_analysis, window_files = self._analyze_fidelius_blob(
                            raw_bytes,
                            fidelius_dir,
                            os.path.basename(out_path),
                            key_candidates=key_candidates,
                        )
                        print(f"[INFO] Fidelius blob written: {os.path.relpath(out_path, output_path)}")
                        entry["fidelius_analysis"] = fidelius_analysis
                        analysis_path = os.path.splitext(out_path)[0] + "_analysis.json"
                        with open(analysis_path, "w", encoding="utf-8") as analysis_out:
                            json.dump(fidelius_analysis, analysis_out, indent=2, ensure_ascii=False, default=str)
                        entry["fidelius_analysis_file"] = os.path.relpath(analysis_path, output_path)
                        if window_files:
                            entry["fidelius_windows"] = [os.path.relpath(p, output_path) for p in window_files]
                            for window_file in window_files:
                                print(f"[INFO] Fidelius marker window: {os.path.relpath(window_file, output_path)}")
                        payload_dump = self._dump_fidelius_payload(entry, fidelius_dir, os.path.basename(out_path))
                        if payload_dump:
                            entry["fidelius_payload_dump"] = payload_dump
                            fidelius_analysis["payload_dump"] = payload_dump
                        self._add_export_bytes(analysis_path)
                        encrypted_identity = fidelius_analysis.get("encrypted_identity", {})
                        rel_identity = encrypted_identity.get("file_relpath")
                        if rel_identity:
                            identity_path = os.path.join(fidelius_dir, rel_identity)
                            self._add_export_bytes(identity_path)
                            print(f"[INFO] Encrypted identity carved: {os.path.relpath(identity_path, output_path)}")
                        for inner_blob in encrypted_identity.get("inner_blobs", []):
                            rel_inner = inner_blob.get("file_relpath")
                            if rel_inner:
                                inner_path = os.path.join(fidelius_dir, rel_inner)
                                self._add_export_bytes(inner_path)
                        for split in encrypted_identity.get("encrypted_identity_splits", []):
                            for key in ("nonce_file_relpath", "ciphertext_file_relpath", "tag_file_relpath", "ct_tag_file_relpath"):
                                rel_split = split.get(key)
                                if rel_split:
                                    split_path = os.path.join(fidelius_dir, rel_split)
                                    self._add_export_bytes(split_path)
                        if payload_dump:
                            rel_dump = payload_dump.get("file_relpath")
                            if rel_dump:
                                dump_path = os.path.join(fidelius_dir, rel_dump)
                                self._add_export_bytes(dump_path)
                        self._add_export_bytes(out_path)
                        entry.pop("fidelius_raw", None)

                    json_entries.append(entry)

                keychain_path = os.path.join(output_path, "Snapchat_Keychain.json")
                with open(keychain_path, "w", encoding="utf-8") as f:
                    json.dump(json_entries, f, indent=2, ensure_ascii=False, default=str)
                self._add_export_bytes(keychain_path)

            sqlcipher_summary = None
            if key_candidates:
                sqlcipher_summary = self._attempt_sqlcipher_gallery(items, key_candidates, folders["sqlcipher"])

            contentmanager_summary = self._extract_contentmanager_key_candidates(
                items,
                folders["contentmanager"],
            )

            report_path = os.path.join(output_path, "Snapchat.html")
            self._write_report(
                report_path,
                exported,
                sqlite_summary,
                artifact_inventory,
                tier_status,
                sqlcipher_summary=sqlcipher_summary,
                contentmanager_summary=contentmanager_summary,
            )
            self._add_export_bytes(report_path)

            return True
        except Exception as exc:
            print(f"[ERROR] Snapchat export failed: {exc}")
            import traceback
            traceback.print_exc()
            return False

    def _scan_items(self) -> List[Dict[str, Any]]:
        if self._is_filesystem:
            return self._scan_items_filesystem()
        items = []
        conn = sqlite3.connect(self.manifest_db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        for domain in (self.SNAPCHAT_DOMAIN, self.SNAPCHAT_GROUP_DOMAIN):
            cur.execute(
                "SELECT fileID, domain, relativePath, file FROM Files WHERE domain = ?",
                (domain,),
            )
            for row in cur.fetchall():
                rel = row["relativePath"]
                if not rel or rel.endswith("/"):
                    continue

                file_path = self._resolve_file_id_path(row["fileID"], row["file"])
                if not file_path or not os.path.exists(file_path):
                    continue

                manifest_size = self._get_manifest_size(row["file"])
                file_size = os.path.getsize(file_path)

                category = self._categorize_path(rel)
                if category is None:
                    continue

                items.append({
                    "file_id": row["fileID"],
                    "domain": domain,
                    "relative_path": rel,
                    "physical_path": file_path,
                    "file_size": file_size,
                    "manifest_size": manifest_size,
                    "category": category,
                })

        conn.close()
        return items

    def _scan_items_filesystem(self) -> List[Dict[str, Any]]:
        items = []
        for root, _, files in os.walk(self.backup_path):
            for name in files:
                full_path = os.path.join(root, name)
                rel = os.path.relpath(full_path, self.backup_path).replace("\\", "/")
                if not rel or rel.endswith("/"):
                    continue
                category = self._categorize_path(rel)
                if category is None:
                    continue
                try:
                    file_size = os.path.getsize(full_path)
                except Exception:
                    file_size = None
                items.append({
                    "file_id": None,
                    "domain": "filesystem",
                    "relative_path": rel,
                    "physical_path": full_path,
                    "file_size": file_size,
                    "manifest_size": None,
                    "category": category,
                })
        return items

    def _get_manifest_size(self, file_bplist: Optional[bytes]) -> Optional[int]:
        if not file_bplist:
            return None
        try:
            from iphone_backup_decrypt import utils as ibd_utils
            fp = ibd_utils.FilePlist(file_bplist)
            return fp.filesize
        except Exception:
            return None

    def _categorize_path(self, rel_path: str) -> Optional[str]:
        rel_lower = rel_path.lower()
        if "/caches/" in rel_lower or rel_lower.endswith(".cache"):
            return "caches"
        if rel_lower.endswith(".plist"):
            return "prefs"
        if rel_lower.endswith((".log", ".txt")) or "kscrash" in rel_lower:
            return "logs"
        if rel_lower.endswith(self.SQLITE_EXTENSIONS) or any(h in rel_lower for h in self.SQLITE_HINTS):
            return "sqlite"
        if rel_lower.startswith("documents/") or rel_lower.startswith("library/"):
            artifact_roots = (
                "documents/gallery_encrypted_db",
                "documents/gallery_data_object",
                "documents/user_scoped",
                "documents/global_scoped",
                "documents/gallery_search",
                "documents/laguna",
                "documents/html_crawl",
            )
            for root in artifact_roots:
                if rel_lower.startswith(root):
                    return "artifacts"
        return None

    def _build_sqlite_summary(self, sqlite_exports: List[Dict[str, Any]], output_path: str) -> Dict[str, Any]:
        summaries = []
        for record in sqlite_exports:
            rel = record.get("output_path")
            if not rel:
                continue
            abs_path = os.path.join(output_path, rel)
            summary = {
                "path": record.get("relative_path"),
                "output_path": rel,
                "size": record.get("file_size"),
                "manifest_size": record.get("manifest_size"),
                "tables": [],
                "errors": [],
            }

            if not os.path.exists(abs_path):
                summary["errors"].append("missing exported file")
                summaries.append(summary)
                continue

            try:
                db = sqlite3.connect(abs_path)
                cur = db.cursor()
                cur.execute(
                    "SELECT name, sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
                )
                table_defs = cur.fetchall()
                for table_name, table_sql in table_defs:
                    table_info = self._get_table_summary(db, table_name)
                    table_info["sql"] = table_sql or ""
                    summary["tables"].append(table_info)
                db.close()
            except Exception as exc:
                summary["errors"].append(str(exc))
            summaries.append(summary)

        return {"databases": summaries}

    def _get_table_summary(self, db: sqlite3.Connection, table: str) -> Dict[str, Any]:
        cur = db.cursor()
        safe_table = table.replace('"', '""')
        cur.execute(f'PRAGMA table_info("{safe_table}")')
        info_rows = cur.fetchall()
        columns = [row[1] for row in info_rows]
        row_count = 0
        try:
            cur.execute(f'SELECT COUNT(*) FROM "{safe_table}"')
            row_count = cur.fetchone()[0]
        except Exception:
            row_count = 0

        text_cols = self._text_columns(info_rows)
        hits, samples = self._keyword_scan(db, table, text_cols)

        return {
            "name": table,
            "columns": columns,
            "row_count": row_count,
            "keyword_hits": hits,
            "keyword_samples": samples,
        }

    def _text_columns(self, info_rows: List[Tuple[Any, ...]]) -> List[str]:
        cols = []
        for _, name, col_type, *_ in info_rows:
            if col_type is None:
                col_type = ""
            col_type_upper = str(col_type).upper()
            if any(t in col_type_upper for t in ("CHAR", "CLOB", "TEXT", "VARCHAR")) or col_type_upper == "":
                cols.append(name)
        return cols

    def _keyword_scan(self, db: sqlite3.Connection, table: str, text_cols: List[str]) -> Tuple[int, List[Any]]:
        if not text_cols:
            return 0, []
        cur = db.cursor()
        where_parts = []
        params = []
        for col in text_cols:
            safe_col = col.replace('"', '""')
            for kw in self.KEYWORDS:
                where_parts.append(f'"{safe_col}" LIKE ? COLLATE NOCASE')
                params.append(f"%{kw}%")
        where_clause = " OR ".join(where_parts)
        safe_table = table.replace('"', '""')
        try:
            cur.execute(f'SELECT COUNT(*) FROM "{safe_table}" WHERE {where_clause}', params)
            count = cur.fetchone()[0]
        except Exception as exc:
            return -1, [f"error: {exc}"]

        samples = []
        try:
            cols_sql = ", ".join(['"{}"'.format(col.replace('"', '""')) for col in text_cols])
            cur.execute(
                f'SELECT {cols_sql} FROM "{safe_table}" WHERE {where_clause} LIMIT 5',
                params,
            )
            samples = cur.fetchall()
        except Exception as exc:
            samples = [f"error: {exc}"]
        return count, samples

    def _build_artifact_inventory(self, items: List[Dict[str, Any]], output_path: str) -> Dict[str, Any]:
        inventory = []
        for item in items:
            if item.get("category") != "artifacts":
                continue
            src = item.get("physical_path")
            if not src or not os.path.exists(src):
                continue
            head16 = self._read_head16(src)
            sha256 = self._hash_file(src)
            inventory.append({
                "relative_path": item.get("relative_path"),
                "domain": item.get("domain"),
                "file_size": item.get("file_size"),
                "manifest_size": item.get("manifest_size"),
                "head16": head16,
                "sha256": sha256,
            })

        missing_gallery_db = self._gallery_db_missing()
        wal_header = self._find_gallery_wal_header(items)
        wal_is_standard = bool(wal_header) and wal_header.lower() == "57 41 4c 00 00 00 00 00 00 00 00 00 00 00 00 00"

        return {
            "artifacts": inventory,
            "gallery_db_missing": missing_gallery_db,
            "wal_header": wal_header,
            "wal_is_standard": wal_is_standard,
        }

    def _gallery_db_missing(self) -> bool:
        if self._is_filesystem:
            for root, _, files in os.walk(self.backup_path):
                for name in files:
                    if name == "gallery.encrypteddb":
                        return False
            return True
        conn = sqlite3.connect(self.manifest_db_path)
        cur = conn.cursor()
        cur.execute(
            "SELECT COUNT(*) FROM Files WHERE domain=? AND relativePath LIKE '%gallery.encrypteddb'",
            (self.SNAPCHAT_DOMAIN,),
        )
        count = cur.fetchone()[0]
        conn.close()
        return count == 0

    def _find_gallery_wal_header(self, items: List[Dict[str, Any]]) -> str:
        for item in items:
            rel = item.get("relative_path", "")
            if rel.endswith("gallery.encrypteddb-wal"):
                src = item.get("physical_path")
                if src and os.path.exists(src):
                    return self._read_head16(src)
        return ""

    def _get_tier_status(self, items: List[Dict[str, Any]]) -> Dict[str, Any]:
        required_dbs = [
            "gallery.encrypteddb",
            "contentmanagerdb.db",
            "arroyo.db",
        ]
        required_present = {name: False for name in required_dbs}
        scdb_present = False

        for item in items:
            rel = item.get("relative_path", "").lower()
            for name in required_dbs:
                if rel.endswith(name):
                    required_present[name] = True
            if "scdb-" in rel and rel.endswith(".sqlite3"):
                scdb_present = True

        keychain_path = self._get_keychain_path()
        keychain_summary = self._inspect_keychain(keychain_path)

        tier3_ready = all(required_present.values()) and scdb_present and keychain_summary.get("snap_entries", 0) > 0

        return {
            "tier1": True,
            "tier2": any(item.get("category") == "sqlite" for item in items),
            "tier3": tier3_ready,
            "required_present": required_present,
            "scdb_present": scdb_present,
            "keychain": keychain_summary,
        }

    def _get_keychain_path(self) -> Optional[str]:
        if self._is_filesystem:
            return None
        return self.find_file_in_backup(self.KEYCHAIN_DOMAIN, "keychain-backup.plist")

    def _inspect_keychain(self, keychain_path: Optional[str]) -> Dict[str, Any]:
        summary = {
            "present": False,
            "item_count": 0,
            "has_metadata": False,
            "snap_matches": 0,
            "snap_entries": 0,
            "entries": [],
            "keybag_available": False,
            "decode_failures": 0,
        }
        if not keychain_path or not os.path.exists(keychain_path):
            return summary
        summary["present"] = True

        keybag = None
        if self.backup_access is not None and getattr(self.backup_access, "_encrypted", None) is not None:
            keybag = getattr(self.backup_access._encrypted, "_keybag", None)
        summary["keybag_available"] = keybag is not None

        try:
            import plistlib
            with open(keychain_path, "rb") as f:
                data = plistlib.load(f)
            sections = []
            if isinstance(data, dict):
                for key in ("genp", "inet", "cert", "keys"):
                    sections.extend(data.get(key, []))
            elif isinstance(data, list):
                sections = data
            summary["item_count"] = len(sections)

            for item in sections:
                keys = set(item.keys())
                if keys - {"v_Data", "v_PersistentRef"}:
                    summary["has_metadata"] = True
                v_data = item.get("v_Data")
                if isinstance(v_data, bytes):
                    low = v_data.lower()
                    if b"snap" in low or b"picaboo" in low or b"toyopa" in low:
                        summary["snap_matches"] += 1

            if keybag is None:
                return summary

            snap_entries = self._decode_snapchat_keychain_entries(data, keybag)
            summary["entries"] = snap_entries
            summary["snap_entries"] = len(snap_entries)
            if snap_entries:
                summary["has_metadata"] = True
            return summary
        except Exception:
            return summary

    def _decode_snapchat_keychain_entries(self, data: Any, keybag) -> List[Dict[str, Any]]:
        entries = []
        if not isinstance(data, dict):
            return entries

        try:
            import ccl_bplist  # type: ignore
            ccl_bplist.set_object_converter(ccl_bplist.NSKeyedArchiver_common_objects_convertor)
        except Exception:
            ccl_bplist = None

        decoded_rows = []
        snap_agrps = set()
        snap_markers = ("picaboo", "snapchat")

        for table in ("genp", "inet"):
            for idx, item in enumerate(data.get(table, [])):
                blob = item.get("v_Data")
                if not blob:
                    continue
                try:
                    result = decode_keychain_item(blob, keybag=keybag)
                except Exception:
                    continue

                decoded = result.get("decoded") or {}
                svce = decoded.get("svce")
                agrp = decoded.get("agrp")
                acct = decoded.get("acct")

                if isinstance(agrp, str) and any(marker in agrp.lower() for marker in snap_markers):
                    snap_agrps.add(agrp)
                if isinstance(svce, str) and any(marker in svce.lower() for marker in snap_markers):
                    snap_agrps.add(agrp)

                decoded_rows.append({
                    "table": table,
                    "index": idx,
                    "result": result,
                    "decoded": decoded,
                    "svce": svce,
                    "agrp": agrp,
                    "acct": acct,
                })

        for row in decoded_rows:
            svce = row["svce"]
            agrp = row["agrp"]
            acct = row["acct"]
            decoded = row["decoded"]
            result = row["result"]

            is_snap = False
            if isinstance(svce, str) and any(marker in svce.lower() for marker in snap_markers):
                is_snap = True
            if isinstance(agrp, str) and agrp in snap_agrps:
                is_snap = True
            if isinstance(acct, str) and acct.lower().startswith("fidelius"):
                is_snap = True

            if not is_snap:
                continue

            entry = {
                "table": row["table"],
                "index": row["index"],
                "svce": svce,
                "acct": acct,
                "agrp": agrp,
                "status": result.get("status"),
                "decoded": result.get("decoded"),
                "decoded_format": result.get("decoded_format"),
                "protobuf": result.get("protobuf"),
                "string_hints": result.get("string_hints"),
            }

            v_data = decoded.get("v_Data")
            if isinstance(v_data, bytes):
                entry["v_data_len"] = len(v_data)
                entry["v_data_head16"] = self._read_head16_bytes(v_data)

                if ccl_bplist is not None:
                    decoded_payload = self._decode_nskeyed_archiver(v_data, ccl_bplist)
                    if decoded_payload is not None:
                        entry["payload"] = decoded_payload

                if isinstance(acct, str) and acct.lower().startswith("fidelius"):
                    entry["fidelius_raw"] = v_data

            entries.append(entry)
        return entries

    def _decode_nskeyed_archiver(self, blob: bytes, ccl_bplist) -> Optional[Any]:
        try:
            plist_obj = ccl_bplist.load(BytesIO(blob))
            decoded = ccl_bplist.deserialise_NsKeyedArchiver(plist_obj)
            if isinstance(decoded, dict) and len(decoded) == 1:
                return list(decoded.values())[0]
            return decoded
        except Exception:
            return None

    def _collect_key_candidates(self, keychain_entries: List[Dict[str, Any]], cap: int = 300) -> List[Dict[str, Any]]:
        candidates: List[Dict[str, Any]] = []
        seen = set()

        def add_key(key_bytes: bytes, source: str) -> None:
            if not isinstance(key_bytes, bytes):
                return
            if len(key_bytes) not in (16, 24, 32):
                return
            sha = self._hash_bytes(key_bytes)
            if sha in seen:
                return
            seen.add(sha)
            candidates.append({
                "key": key_bytes,
                "sha256": sha,
                "source": source,
                "len": len(key_bytes),
            })

        def add_derived_keys(raw_bytes: bytes, source: str) -> None:
            if not isinstance(raw_bytes, bytes):
                return
            if len(raw_bytes) in (16, 24, 32):
                return
            if len(raw_bytes) < 8 or len(raw_bytes) > 256:
                return
            sha256_bytes = hashlib.sha256(raw_bytes).digest()
            add_key(sha256_bytes, f"{source}:sha256")

        def try_decode_string(value: str, source: str) -> None:
            text = value.strip()
            if len(text) >= 32 and all(c in "0123456789abcdefABCDEF" for c in text):
                if len(text) in (32, 48, 64):
                    try:
                        raw = bytes.fromhex(text)
                        add_key(raw, f"{source}:hex")
                        add_derived_keys(raw, f"{source}:hex")
                    except ValueError:
                        pass
            if len(text) >= 24:
                try:
                    raw = base64.b64decode(text, validate=True)
                except Exception:
                    raw = None
                if raw:
                    add_key(raw, f"{source}:b64")
                    add_derived_keys(raw, f"{source}:b64")

        def walk(value: Any, source: str) -> None:
            if isinstance(value, dict):
                for k, v in value.items():
                    key_name = k.decode("utf-8", errors="ignore") if isinstance(k, bytes) else str(k)
                    walk(v, f"{source}.{key_name}")
                return
            if isinstance(value, list):
                for idx, item in enumerate(value):
                    walk(item, f"{source}[{idx}]")
                return
            if isinstance(value, bytes):
                add_key(value, source)
                add_derived_keys(value, source)
                return
            if isinstance(value, str):
                try_decode_string(value, source)

        for entry in keychain_entries:
            if len(candidates) >= cap:
                break
            payload = entry.get("payload")
            if payload is not None:
                walk(payload, "payload")
            decoded = entry.get("decoded")
            if decoded is not None:
                walk(decoded, "decoded")
            proto = entry.get("protobuf")
            if proto is not None:
                walk(proto, "protobuf")
            hints = entry.get("string_hints")
            if hints is not None:
                walk(hints, "string_hints")

        return candidates

    def _collect_key_candidates_from_keychain(
        self,
        data: Any,
        keybag,
        cap: int = 500,
    ) -> List[Dict[str, Any]]:
        if not isinstance(data, dict):
            return []
        entries: List[Dict[str, Any]] = []
        for table in ("genp", "inet"):
            entries.extend(data.get(table, []))
        results: List[Dict[str, Any]] = []
        if not entries:
            return results
        for idx, item in enumerate(entries):
            blob = item.get("v_Data")
            if not blob:
                continue
            try:
                decoded = decode_keychain_item(blob, keybag=keybag)
            except Exception:
                continue
            results.append({
                "decoded": decoded.get("decoded"),
                "protobuf": decoded.get("protobuf"),
                "string_hints": decoded.get("string_hints"),
                "payload": None,
            })
            if len(results) >= cap:
                break
        return results

    def _collect_key_candidates_from_snapchat_dbs(
        self,
        items: List[Dict[str, Any]],
        cap: int = 300,
        row_limit: int = 200,
    ) -> List[Dict[str, Any]]:
        entries: List[Dict[str, Any]] = []
        for item in items:
            if item.get("category") != "sqlite":
                continue
            path = item.get("physical_path")
            if not path or not os.path.exists(path):
                continue
            try:
                conn = sqlite3.connect(path)
                conn.row_factory = sqlite3.Row
                cur = conn.cursor()
                tables = [r[0] for r in cur.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                ).fetchall()]
                for table in tables:
                    if len(entries) >= cap:
                        break
                    cols = cur.execute(f"PRAGMA table_info('{table}')").fetchall()
                    col_names = [c[1] for c in cols]
                    col_types = {c[1]: (c[2] or "").upper() for c in cols}
                    scan_cols = [
                        name for name in col_names
                        if any(t in col_types.get(name, "") for t in ("BLOB", "TEXT", "CHAR"))
                    ]
                    if not scan_cols:
                        continue
                    sql = f"SELECT {', '.join(scan_cols)} FROM '{table}' LIMIT {row_limit}"
                    for row in cur.execute(sql):
                        for name in scan_cols:
                            val = row[name]
                            if isinstance(val, bytes):
                                if 8 <= len(val) <= 256:
                                    entries.append({"payload": val})
                            elif isinstance(val, str):
                                text = val.strip()
                                if len(text) < 24:
                                    continue
                                entries.append({"string_hints": [text]})
                            if len(entries) >= cap:
                                break
                        if len(entries) >= cap:
                            break
                conn.close()
            except Exception:
                continue
            if len(entries) >= cap:
                break
        return entries

    def _read_head16_bytes(self, data: bytes) -> str:
        return " ".join(f"{b:02x}" for b in data[:16])

    def _hash_bytes(self, data: bytes) -> str:
        return hashlib.sha256(data).hexdigest()

    def _dump_fidelius_payload(
        self,
        entry: Dict[str, Any],
        out_dir: str,
        base_name: str,
    ) -> Optional[Dict[str, Any]]:
        payload = entry.get("payload")
        proto = entry.get("protobuf")
        decoded = entry.get("decoded")
        if payload is None and proto is None and decoded is None:
            return None

        dump = {
            "acct": entry.get("acct"),
            "svce": entry.get("svce"),
            "agrp": entry.get("agrp"),
            "payload": payload,
            "protobuf": proto,
            "decoded": decoded,
        }
        scan = self._scan_payload_for_candidates(dump)

        stem = os.path.splitext(base_name)[0]
        dump_path = self._dedupe_path(os.path.join(out_dir, f"{stem}_payload_dump.json"))
        with open(dump_path, "w", encoding="utf-8") as out:
            json.dump(dump, out, indent=2, ensure_ascii=False, default=str)

        return {
            "file_relpath": os.path.relpath(dump_path, out_dir),
            "scan": scan,
        }

    def _scan_payload_for_candidates(self, payload: Any) -> Dict[str, Any]:
        byte_candidates = []
        string_candidates = []
        keyword_hits = []
        keywords = ("fidelius", "identity", "devicegraph", "tsaf", "backup", "snap", "picaboo")

        def walk(value: Any, path: str) -> None:
            if isinstance(value, dict):
                for k, v in value.items():
                    key_name = k.decode("utf-8", errors="ignore") if isinstance(k, bytes) else str(k)
                    walk(v, f"{path}.{key_name}" if path else key_name)
                return
            if isinstance(value, list):
                for idx, item in enumerate(value):
                    walk(item, f"{path}[{idx}]")
                return
            if isinstance(value, bytes):
                if 8 <= len(value) <= 256:
                    byte_candidates.append({
                        "path": path,
                        "size": len(value),
                        "sha256": self._hash_bytes(value),
                        "head16_hex": self._read_head16_bytes(value),
                    })
                return
            if isinstance(value, str):
                text = value.strip()
                lower = text.lower()
                if any(k in lower for k in keywords):
                    keyword_hits.append({"path": path, "value": text[:200]})
                if len(text) >= 8:
                    string_candidates.append({"path": path, "value": text[:200]})
                return

        walk(payload, "")
        return {
            "byte_candidates": byte_candidates[:100],
            "string_candidates": string_candidates[:100],
            "keyword_hits": keyword_hits[:100],
        }

    def _extract_contentmanager_key_candidates(
        self,
        items: List[Dict[str, Any]],
        out_dir: str,
        max_per_db: int = 2000,
    ) -> Dict[str, Any]:
        os.makedirs(out_dir, exist_ok=True)
        summaries = []
        b64_re = re.compile(rb"[A-Za-z0-9+/]{16,}={0,2}")
        hex_re = re.compile(rb"[0-9a-fA-F]{32,64}")

        for item in items:
            rel = item.get("relative_path", "")
            if not rel:
                continue
            rel_lower = rel.lower()
            if "contentmanagerdb.db" not in rel_lower:
                continue
            path = item.get("physical_path")
            if not path or not os.path.exists(path):
                continue

            name = os.path.basename(path)
            candidates = []
            try:
                db = sqlite3.connect(path)
                cur = db.cursor()
                cur.execute("SELECT CONTENT_KEY, CONTENT_DEFINITION FROM CONTENT_OBJECT_TABLE")
                rows = cur.fetchall()
                for idx, (ckey, cdef) in enumerate(rows):
                    if not isinstance(cdef, (bytes, bytearray)):
                        continue
                    for m in hex_re.finditer(cdef):
                        raw = m.group(0)
                        if len(raw) not in (32, 64):
                            continue
                        try:
                            decoded = bytes.fromhex(raw.decode("ascii"))
                        except Exception:
                            continue
                        candidates.append({
                            "row": idx,
                            "content_key": ckey,
                            "offset": m.start(),
                            "type": "hex",
                            "len": len(decoded),
                            "hex": decoded.hex(),
                        })
                        if len(candidates) >= max_per_db:
                            break
                    if len(candidates) >= max_per_db:
                        break
                    for m in b64_re.finditer(cdef):
                        raw = m.group(0)
                        try:
                            decoded = base64.b64decode(raw, validate=True)
                        except Exception:
                            continue
                        if len(decoded) not in (16, 24, 32, 48, 64):
                            continue
                        candidates.append({
                            "row": idx,
                            "content_key": ckey,
                            "offset": m.start(),
                            "type": "b64",
                            "len": len(decoded),
                            "hex": decoded.hex(),
                        })
                        if len(candidates) >= max_per_db:
                            break
                    if len(candidates) >= max_per_db:
                        break
                db.close()
            except Exception:
                continue

            if not candidates:
                summaries.append({
                    "name": name,
                    "count": 0,
                    "sample": "-",
                })
                continue

            out_path = os.path.join(out_dir, f"{name}_key_candidates.json")
            with open(out_path, "w", encoding="utf-8") as f:
                json.dump(candidates, f, indent=2)
            self._add_export_bytes(out_path)

            sample = candidates[0]
            sample_text = f"{sample.get('type')} len={sample.get('len')} {sample.get('hex')[:32]}..."
            summaries.append({
                "name": name,
                "count": len(candidates),
                "sample": sample_text,
                "file_relpath": os.path.relpath(out_path, out_dir),
            })

        return {
            "databases": summaries,
            "notes": "Candidates extracted from CONTENT_DEFINITION blobs (hex/b64 strings of 16/24/32/48/64 bytes).",
        }

    def _attempt_sqlcipher_gallery(
        self,
        items: List[Dict[str, Any]],
        key_candidates: List[Dict[str, Any]],
        out_dir: str,
    ) -> Dict[str, Any]:
        summary = {"status": "not_found"}
        gallery_item = None
        wal_item = None
        shm_item = None
        possible_bases = []
        for item in items:
            rel = item.get("relative_path", "").lower()
            if rel.endswith("gallery.encrypteddb"):
                gallery_item = item
                break
            if rel.endswith("gallery.encrypteddb-wal"):
                wal_item = item
            if rel.endswith("gallery.encrypteddb-shm"):
                shm_item = item
            if "gallery_encrypted_db" in rel:
                if rel.endswith(".db") and not rel.endswith(("-wal", "-shm")):
                    possible_bases.append(item)
        if not gallery_item:
            if wal_item or shm_item:
                summary["status"] = "base_missing"
                if wal_item:
                    summary["wal_relpath"] = wal_item.get("relative_path")
                    summary["wal_size"] = wal_item.get("file_size")
                if shm_item:
                    summary["shm_relpath"] = shm_item.get("relative_path")
                    summary["shm_size"] = shm_item.get("file_size")
                if possible_bases:
                    summary["status"] = "base_candidates"
                    summary["base_candidates"] = [b.get("relative_path") for b in possible_bases[:10]]
            return summary
            return summary

        src_path = gallery_item.get("physical_path")
        if not src_path or not os.path.exists(src_path):
            summary["status"] = "missing_source"
            return summary

        try:
            from Crypto.Cipher import AES  # type: ignore
        except Exception:
            summary["status"] = "crypto_unavailable"
            return summary

        page_size = 0x400
        iv_len = 16
        header_skip = 0x10

        candidates = [c for c in key_candidates if isinstance(c.get("key"), bytes) and len(c["key"]) == 32]
        if not candidates:
            summary["status"] = "no_32byte_keys"
            return summary

        def decrypt_page(page_bytes: bytes, key_bytes: bytes, page_index: int) -> bytes:
            if page_index == 0:
                enc = page_bytes[header_skip:page_size - iv_len]
                iv = page_bytes[page_size - iv_len:page_size]
                cipher = AES.new(key_bytes, AES.MODE_CBC, iv=iv)
                dec = cipher.decrypt(enc)
                out = bytearray(page_size)
                out[0:header_skip] = dec[:header_skip]
                out[header_skip:page_size - iv_len] = dec[header_skip:]
                out[page_size - iv_len:page_size] = b"\x00" * iv_len
                return bytes(out)
            enc = page_bytes[0:page_size - iv_len]
            iv = page_bytes[page_size - iv_len:page_size]
            cipher = AES.new(key_bytes, AES.MODE_CBC, iv=iv)
            dec = cipher.decrypt(enc)
            out = bytearray(page_size)
            out[0:page_size - iv_len] = dec
            out[page_size - iv_len:page_size] = b"\x00" * iv_len
            return bytes(out)

        matched_key = None
        with open(src_path, "rb") as f:
            first_page = f.read(page_size)
        for candidate in candidates:
            key_bytes = candidate["key"]
            try:
                decrypted_page = decrypt_page(first_page, key_bytes, 0)
            except Exception:
                continue
            if decrypted_page[:16] == b"SQLite format 3\x00":
                matched_key = candidate
                break

        if not matched_key:
            summary["status"] = "no_key_match"
            return summary

        out_name = os.path.splitext(os.path.basename(src_path))[0] + "_decrypted.sqlite"
        out_path = self._dedupe_path(os.path.join(out_dir, out_name))

        try:
            with open(src_path, "rb") as f_in, open(out_path, "wb") as f_out:
                page_index = 0
                while True:
                    page = f_in.read(page_size)
                    if not page:
                        break
                    if len(page) < page_size:
                        break
                    dec_page = decrypt_page(page, matched_key["key"], page_index)
                    f_out.write(dec_page)
                    page_index += 1
        except Exception as exc:
            summary["status"] = "decrypt_failed"
            summary["error"] = str(exc)
            return summary

        summary.update({
            "status": "decrypted",
            "key_sha256": matched_key.get("sha256"),
            "decrypted_relpath": os.path.relpath(out_path, out_dir),
        })

        snap_key_iv_path = None
        snap_key_iv_count = 0
        try:
            conn = sqlite3.connect(out_path)
            cur = conn.cursor()
            cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='snap_key_iv'")
            if cur.fetchone():
                cur.execute("SELECT * FROM snap_key_iv")
                rows = cur.fetchall()
                cols = [d[0] for d in cur.description]
                snap_key_iv_count = len(rows)
                csv_path = self._dedupe_path(os.path.join(out_dir, "snap_key_iv.csv"))
                with open(csv_path, "w", encoding="utf-8") as csv_out:
                    csv_out.write(",".join(cols) + "\n")
                    for row in rows:
                        out_row = []
                        for val in row:
                            if isinstance(val, bytes):
                                out_row.append(binascii.hexlify(val).decode("ascii"))
                            else:
                                out_row.append(str(val))
                        csv_out.write(",".join(out_row) + "\n")
                snap_key_iv_path = os.path.relpath(csv_path, out_dir)
            conn.close()
        except Exception as exc:
            summary["error"] = str(exc)

        summary["snap_key_iv_count"] = snap_key_iv_count
        summary["snap_key_iv_relpath"] = snap_key_iv_path
        return summary

    def _extract_strings(self, data: bytes, min_len: int = 8) -> List[str]:
        try:
            text = data.decode("utf-8", errors="ignore")
        except Exception:
            return []
        pattern = re.compile(rf"[ -~]{{{min_len},}}")
        return pattern.findall(text)

    def _extract_field_like_strings(self, data: bytes, min_len: int = 6, cap: int = 100) -> List[Dict[str, Any]]:
        results = []
        text = data.decode("utf-8", errors="ignore")
        pattern = re.compile(rf"[A-Za-z0-9_]{{{min_len},}}")
        for match in pattern.finditer(text):
            results.append({"offset": match.start(), "value": match.group(0)})
            if len(results) >= cap:
                break
        return results

    def _analyze_fidelius_blob(
        self,
        data: bytes,
        out_dir: Optional[str] = None,
        base_name: Optional[str] = None,
        key_candidates: Optional[List[Dict[str, Any]]] = None,
    ) -> Tuple[Dict[str, Any], List[str]]:
        analysis = {
            "magic": data[:4].decode("ascii", errors="ignore"),
            "size": len(data),
            "head16": self._read_head16_bytes(data),
            "sha256": self._hash_bytes(data),
        }

        field_like = self._extract_field_like_strings(data, min_len=6, cap=100)
        if field_like:
            analysis["field_like_strings"] = field_like

        incidental = self._extract_strings(data, min_len=8)
        if incidental:
            analysis["incidental_strings_sample"] = incidental[:50]
            analysis["incidental_strings_count"] = len(incidental)

        analysis["tsaf_header"] = self._parse_tsaf_header(data)
        markers, window_files = self._scan_markers(
            data,
            markers=(
                "ENCRYPTED_IDENTITY",
                "HASHED_BETA",
                "hashedBeta",
                "SCFideliusDeviceGraph",
                "SCFideliusEncryptedBackupRecord",
            ),
            out_dir=out_dir,
            base_name=base_name,
        )
        analysis["markers"] = markers

        encrypted_identity = self._carve_encrypted_identity(
            data,
            out_dir=out_dir,
            base_name=base_name,
            key_candidates=key_candidates,
        )
        analysis["encrypted_identity"] = encrypted_identity

        hashed_beta = self._carve_hashed_beta(data)
        analysis["hashed_beta"] = hashed_beta

        # Best-effort decode attempts (non-fatal).
        decoded = decode_unknown_blob(data)
        if decoded:
            analysis["decoded_format"] = decoded.get("format")
            analysis["decoded_value_preview"] = str(decoded.get("value"))[:500]

        return analysis, window_files

    def _parse_tsaf_header(self, data: bytes) -> Dict[str, Any]:
        header = {
            "magic": data[:4].decode("ascii", errors="ignore"),
            "raw_head16": self._read_head16_bytes(data),
        }
        if len(data) >= 16:
            header["u16_le"] = [int.from_bytes(data[i:i + 2], "little") for i in range(4, 16, 2)]
            header["u16_be"] = [int.from_bytes(data[i:i + 2], "big") for i in range(4, 16, 2)]
        if len(data) >= 12:
            header["u32_le"] = [int.from_bytes(data[i:i + 4], "little") for i in range(4, 12, 4)]
            header["u32_be"] = [int.from_bytes(data[i:i + 4], "big") for i in range(4, 12, 4)]
        return header

    def _scan_markers(
        self,
        data: bytes,
        markers: Tuple[str, ...],
        out_dir: Optional[str] = None,
        base_name: Optional[str] = None,
    ) -> Tuple[List[Dict[str, Any]], List[str]]:
        results = []
        window_files: List[str] = []
        for marker in markers:
            m_bytes = marker.encode("utf-8")
            offset = data.find(m_bytes)
            if offset == -1:
                continue
            entry = {"marker": marker, "offset": offset}
            after = offset + len(m_bytes)
            entry["window_b64"] = self._window_b64(data, offset, before=128, after=256)
            entry["window_hex"] = self._window_hex(data, offset, before=128, after=256)
            entry["entropy_windows"] = self._entropy_windows(data, after, max_len=512, window=32, step=8)

            if out_dir and base_name:
                window_path = os.path.join(out_dir, f"{os.path.splitext(base_name)[0]}_{marker}_window.bin")
                window_path = self._dedupe_path(window_path)
                start = max(0, offset - 128)
                end = min(len(data), offset + 256)
                with open(window_path, "wb") as window_out:
                    window_out.write(data[start:end])
                window_files.append(window_path)

            varint = self._parse_varint(data, after)
            if varint:
                length, varint_len = varint
                entry["varint_len"] = varint_len
                entry["payload_len_varint"] = length
                payload_start = after + varint_len
                if 0 < length <= len(data) - payload_start:
                    payload = data[payload_start:payload_start + length]
                    entry["payload_head16_varint"] = self._read_head16_bytes(payload)
                    entry["payload_sha256_varint"] = self._hash_bytes(payload)
                    entry["payload_size_varint"] = length
            if after + 4 <= len(data):
                le_len = int.from_bytes(data[after:after + 4], "little")
                be_len = int.from_bytes(data[after:after + 4], "big")
                entry["len_le"] = le_len
                entry["len_be"] = be_len

                for length, endian in ((le_len, "le"), (be_len, "be")):
                    if 0 < length <= len(data) - (after + 4):
                        payload = data[after + 4: after + 4 + length]
                        entry[f"payload_head16_{endian}"] = self._read_head16_bytes(payload)
                        entry[f"payload_sha256_{endian}"] = self._hash_bytes(payload)
                        entry[f"payload_size_{endian}"] = length
                        break
            results.append(entry)
        return results, window_files

    def _window_b64(self, data: bytes, center: int, before: int = 64, after: int = 64) -> str:
        start = max(0, center - before)
        end = min(len(data), center + after)
        return base64.b64encode(data[start:end]).decode("ascii")

    def _window_hex(self, data: bytes, center: int, before: int = 64, after: int = 64) -> str:
        start = max(0, center - before)
        end = min(len(data), center + after)
        return binascii.hexlify(data[start:end]).decode("ascii")

    def _parse_varint(self, data: bytes, offset: int) -> Optional[Tuple[int, int]]:
        value = 0
        shift = 0
        for i in range(0, 10):
            if offset + i >= len(data):
                return None
            byte = data[offset + i]
            value |= (byte & 0x7F) << shift
            shift += 7
            if (byte & 0x80) == 0:
                return value, i + 1
        return None

    def _shannon_entropy(self, data: bytes) -> float:
        if not data:
            return 0.0
        counts = [0] * 256
        for b in data:
            counts[b] += 1
        entropy = 0.0
        length = len(data)
        for c in counts:
            if c == 0:
                continue
            p = c / length
            entropy -= p * math.log2(p)
        return entropy

    def _entropy_windows(self, data: bytes, start: int, max_len: int = 512, window: int = 32, step: int = 8) -> List[Dict[str, Any]]:
        results = []
        end = min(len(data), start + max_len)
        for offset in range(start, end - window + 1, step):
            chunk = data[offset:offset + window]
            results.append({
                "offset": offset,
                "shannon_entropy": round(self._shannon_entropy(chunk), 4),
                "head8_hex": binascii.hexlify(chunk[:8]).decode("ascii"),
            })
        return results

    def _carve_encrypted_identity(
        self,
        data: bytes,
        out_dir: Optional[str] = None,
        base_name: Optional[str] = None,
        key_candidates: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        marker = b"ENCRYPTED_IDENTITY"
        offset = data.find(marker)
        if offset == -1:
            return {"carve_status": "marker_not_found"}

        scan_start = offset + len(marker)
        # Try two little-endian u32 lengths right after marker.
        if scan_start + 8 <= len(data):
            len_a = int.from_bytes(data[scan_start:scan_start + 4], "little")
            len_b = int.from_bytes(data[scan_start + 4:scan_start + 8], "little")
            remaining = len(data) - (scan_start + 8)
            for candidate in (len_a, len_b):
                if 16 <= candidate <= remaining:
                    payload = data[scan_start + 8: scan_start + 8 + candidate]
                    result = {
                        "carve_status": "ok_len_u32",
                        "offset_start": scan_start + 8,
                        "offset_end": scan_start + 8 + candidate,
                        "size": len(payload),
                        "sha256": self._hash_bytes(payload),
                        "head16_hex": self._read_head16_bytes(payload),
                    }
                    result.update(self._analyze_encrypted_payload(payload, out_dir, base_name, key_candidates))
                    if out_dir and base_name:
                        out_path = os.path.join(out_dir, f"{os.path.splitext(base_name)[0]}_encrypted_identity.bin")
                        out_path = self._dedupe_path(out_path)
                        with open(out_path, "wb") as out:
                            out.write(payload)
                        result["file_relpath"] = os.path.relpath(out_path, out_dir)
                    return result

        windows = self._entropy_windows(data, scan_start, max_len=1024, window=32, step=8)
        start_offset = None
        for w in windows:
            if w["shannon_entropy"] >= 7.2:
                start_offset = w["offset"]
                break
        if start_offset is None:
            return {"carve_status": "no_high_entropy_window"}

        end_offset = start_offset
        dip_count = 0
        for w in windows:
            if w["offset"] < start_offset:
                continue
            if w["shannon_entropy"] >= 7.0:
                dip_count = 0
                end_offset = w["offset"] + 32
            else:
                dip_count += 1
                if dip_count > 2:
                    break

        if end_offset <= start_offset:
            return {"carve_status": "invalid_bounds"}

        payload = data[start_offset:end_offset]
        if len(payload) < 16:
            return {"carve_status": "payload_too_small", "offset_start": start_offset, "offset_end": end_offset}

        result = {
            "carve_status": "ok",
            "offset_start": start_offset,
            "offset_end": end_offset,
            "size": len(payload),
            "sha256": self._hash_bytes(payload),
            "head16_hex": self._read_head16_bytes(payload),
        }
        result.update(self._analyze_encrypted_payload(payload, out_dir, base_name, key_candidates))

        if out_dir and base_name:
            out_path = os.path.join(out_dir, f"{os.path.splitext(base_name)[0]}_encrypted_identity.bin")
            out_path = self._dedupe_path(out_path)
            with open(out_path, "wb") as out:
                out.write(payload)
            result["file_relpath"] = os.path.relpath(out_path, out_dir)
        return result

    def _analyze_encrypted_payload(
        self,
        payload: bytes,
        out_dir: Optional[str],
        base_name: Optional[str],
        key_candidates: Optional[List[Dict[str, Any]]],
    ) -> Dict[str, Any]:
        analysis = {
            "payload_entropy": round(self._shannon_entropy(payload), 4),
        }
        analysis["payload_format_guess"] = self._guess_payload_format(payload)
        fields = self._scan_length_delimited_fields(payload)
        analysis["payload_fields"] = fields

        splits = self._generate_aead_splits(payload, out_dir, base_name)
        analysis["encrypted_identity_splits"] = splits

        aad_candidates = self._build_fidelius_aad_candidates(
            marker=b"ENCRYPTED_IDENTITY",
            header_prefix=payload[:16],
        )
        trials = self._attempt_decrypt_trials(payload, key_candidates, aad_candidates=aad_candidates)
        if trials:
            analysis["decrypt_trials"] = trials

        inner_blobs = []
        if out_dir and base_name:
            for idx, field in enumerate(fields[:10]):
                data_bytes = field.get("data")
                if not data_bytes:
                    continue
                inner_path = os.path.join(out_dir, f"{os.path.splitext(base_name)[0]}_encrypted_identity_inner_{idx}.bin")
                inner_path = self._dedupe_path(inner_path)
                with open(inner_path, "wb") as out:
                    out.write(data_bytes)
                inner_blobs.append({
                    "offset": field.get("offset"),
                    "size": len(data_bytes),
                    "sha256": self._hash_bytes(data_bytes),
                    "head16_hex": self._read_head16_bytes(data_bytes),
                    "file_relpath": os.path.relpath(inner_path, out_dir),
                })
        for field in fields:
            field.pop("data", None)
        analysis["inner_blobs"] = inner_blobs
        return analysis

    def _generate_aead_splits(
        self,
        payload: bytes,
        out_dir: Optional[str],
        base_name: Optional[str],
    ) -> List[Dict[str, Any]]:
        schemes = [
            ("aead_12_16", 12, 16),
            ("aead_16_16", 16, 16),
            ("aead_12_12", 12, 12),
        ]
        results = []
        stem = os.path.splitext(base_name or "payload")[0]

        for label, nonce_len, tag_len in schemes:
            if len(payload) <= nonce_len + tag_len:
                results.append({
                    "scheme": label,
                    "carve_status": "too_short",
                })
                continue

            nonce = payload[:nonce_len]
            tag = payload[-tag_len:]
            ciphertext = payload[nonce_len:-tag_len]
            ct_tag = payload[nonce_len:]

            entry = {
                "scheme": label,
                "carve_status": "ok",
                "nonce_hex": binascii.hexlify(nonce).decode("ascii"),
                "tag_hex": binascii.hexlify(tag).decode("ascii"),
                "ciphertext_len": len(ciphertext),
                "ciphertext_sha256": self._hash_bytes(ciphertext),
                "ciphertext_head16_hex": self._read_head16_bytes(ciphertext),
            }

            if out_dir and base_name:
                nonce_path = self._dedupe_path(os.path.join(out_dir, f"{stem}_encrypted_identity_{label}_nonce.bin"))
                ct_path = self._dedupe_path(os.path.join(out_dir, f"{stem}_encrypted_identity_{label}_ciphertext.bin"))
                tag_path = self._dedupe_path(os.path.join(out_dir, f"{stem}_encrypted_identity_{label}_tag.bin"))
                ct_tag_path = self._dedupe_path(os.path.join(out_dir, f"{stem}_encrypted_identity_{label}_ct_tag.bin"))

                with open(nonce_path, "wb") as out:
                    out.write(nonce)
                with open(ct_path, "wb") as out:
                    out.write(ciphertext)
                with open(tag_path, "wb") as out:
                    out.write(tag)
                with open(ct_tag_path, "wb") as out:
                    out.write(ct_tag)

                entry["nonce_file_relpath"] = os.path.relpath(nonce_path, out_dir)
                entry["ciphertext_file_relpath"] = os.path.relpath(ct_path, out_dir)
                entry["tag_file_relpath"] = os.path.relpath(tag_path, out_dir)
                entry["ct_tag_file_relpath"] = os.path.relpath(ct_tag_path, out_dir)

            results.append(entry)

        return results

    def _attempt_decrypt_trials(
        self,
        payload: bytes,
        key_candidates: Optional[List[Dict[str, Any]]],
        max_keys: int = 50,
        aad_candidates: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        if not key_candidates:
            return {"attempt_count": 0, "success_count": 0, "status": "no_key_candidates"}

        try:
            from Crypto.Cipher import AES  # type: ignore
        except Exception:
            return {"attempt_count": 0, "success_count": 0, "status": "crypto_unavailable"}

        schemes = [
            ("aead_12_16", 12, 16),
            ("aead_16_16", 16, 16),
            ("aead_12_12", 12, 12),
        ]

        aad_list = aad_candidates or [{"label": "empty", "data": b""}]

        candidates = []
        for entry in key_candidates[:max_keys]:
            key_bytes = entry.get("key")
            if not isinstance(key_bytes, bytes):
                continue
            if len(key_bytes) not in (16, 24, 32):
                continue
            candidates.append(entry)

        if not candidates:
            return {"attempt_count": 0, "success_count": 0, "status": "no_valid_keys"}

        attempts = 0
        successes = []

        for label, nonce_len, tag_len in schemes:
            if len(payload) <= nonce_len + tag_len:
                continue
            nonce = payload[:nonce_len]
            tag = payload[-tag_len:]
            ciphertext = payload[nonce_len:-tag_len]
            for entry in candidates:
                key_bytes = entry["key"]
                for aad in aad_list:
                    attempts += 1
                    try:
                        cipher = AES.new(key_bytes, AES.MODE_GCM, nonce=nonce)
                        aad_bytes = aad.get("data") if isinstance(aad, dict) else b""
                        if aad_bytes:
                            cipher.update(aad_bytes)
                        plaintext = cipher.decrypt_and_verify(ciphertext, tag)
                    except Exception:
                        continue
                    successes.append({
                        "scheme": label,
                        "aad_label": aad.get("label") if isinstance(aad, dict) else "unknown",
                        "key_sha256": self._hash_bytes(key_bytes),
                        "key_source": entry.get("source"),
                        "plaintext_len": len(plaintext),
                        "plaintext_head16_hex": self._read_head16_bytes(plaintext),
                        "plaintext_format_guess": self._guess_payload_format(plaintext),
                        "plaintext_entropy": round(self._shannon_entropy(plaintext), 4),
                    })
                    if len(successes) >= 10:
                        break
                if len(successes) >= 10:
                    break
            if len(successes) >= 10:
                break

        return {
            "attempt_count": attempts,
            "success_count": len(successes),
            "successes": successes,
            "status": "done",
        }

    def _guess_payload_format(self, payload: bytes) -> str:
        if payload.startswith(b"bplist00"):
            return "bplist00"
        if payload.startswith(b"\x1f\x8b"):
            return "gzip"
        if payload[:2] in (b"\x78\x9c", b"\x78\xda"):
            return "zlib"

        fields = self._scan_length_delimited_fields(payload)
        if fields:
            return "protobuf_length_delimited"
        return "unknown"

    def _scan_length_delimited_fields(self, payload: bytes) -> List[Dict[str, Any]]:
        fields = []
        offset = 0
        length = len(payload)
        while offset < length:
            tag_info = self._parse_varint(payload, offset)
            if not tag_info:
                break
            tag, tag_len = tag_info
            offset += tag_len
            wire = tag & 0x7
            field_number = tag >> 3
            if wire != 2:
                offset += 1
                continue

            len_info = self._parse_varint(payload, offset)
            if not len_info:
                break
            field_len, field_len_size = len_info
            offset += field_len_size
            if field_len < 0 or offset + field_len > length:
                break
            data_bytes = payload[offset:offset + field_len]
            fields.append({
                "field_number": field_number,
                "offset": offset,
                "size": field_len,
                "head16_hex": self._read_head16_bytes(data_bytes),
                "sha256": self._hash_bytes(data_bytes),
                "data": data_bytes,
            })
            offset += field_len
        return fields

    def _build_fidelius_aad_candidates(
        self,
        marker: bytes,
        header_prefix: bytes,
        marker_len_u32: Optional[bytes] = None,
    ) -> List[Dict[str, Any]]:
        if marker_len_u32 is None:
            marker_len_u32 = len(marker).to_bytes(4, "little")
        candidates = [
            {"label": "empty", "data": b""},
            {"label": "marker", "data": marker},
            {"label": "marker_len16", "data": marker + len(marker).to_bytes(2, "little")},
            {"label": "header16", "data": header_prefix},
            {"label": "header16_marker", "data": header_prefix + marker},
            {"label": "marker_len32", "data": marker + marker_len_u32},
            {"label": "header16_marker_len32", "data": header_prefix + marker + marker_len_u32},
        ]
        return candidates

    def _carve_hashed_beta(self, data: bytes) -> Dict[str, Any]:
        for marker in (b"HASHED_BETA", b"hashedBeta"):
            offset = data.find(marker)
            if offset == -1:
                continue

            start = offset + len(marker)
            # Try base64 immediately after marker.
            tail = data[start:start + 200]
            m = re.search(rb"[A-Za-z0-9+/=]{20,}", tail)
            if m:
                b64_candidate = m.group(0)
                try:
                    decoded = base64.b64decode(b64_candidate, validate=True)
                    if len(decoded) == 32:
                        return {
                            "carve_status": "ok",
                            "b64": b64_candidate.decode("ascii"),
                            "bytes_len": 32,
                            "hex": binascii.hexlify(decoded).decode("ascii"),
                            "sha256": self._hash_bytes(decoded),
                        }
                except Exception:
                    pass

            # Fallback: take 32 bytes after marker if plausible.
            if start + 32 <= len(data):
                raw = data[start:start + 32]
                return {
                    "carve_status": "ok_fallback",
                    "bytes_len": 32,
                    "hex": binascii.hexlify(raw).decode("ascii"),
                    "sha256": self._hash_bytes(raw),
                }

        return {"carve_status": "marker_not_found"}

    def _write_report(self, report_path: str, exported: Dict[str, List[Dict[str, Any]]],
                      sqlite_summary: Dict[str, Any], artifact_inventory: Dict[str, Any],
                      tier_status: Dict[str, Any], sqlcipher_summary: Optional[Dict[str, Any]] = None,
                      contentmanager_summary: Optional[Dict[str, Any]] = None) -> None:
        def _fmt_bool(value: bool) -> str:
            return "Yes" if value else "No"

        html = [
            "<!DOCTYPE html>",
            "<html lang=\"en\">",
            "<head>",
            "<meta charset=\"UTF-8\">",
            "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">",
            "<title>Snapchat Report</title>",
            "<style>",
            "body{font-family:Segoe UI,Arial,sans-serif;background:#f6f6f6;padding:20px;}",
            ".container{max-width:1200px;margin:0 auto;background:#fff;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,0.1);overflow:hidden;}",
            ".header{background:linear-gradient(135deg,#fcee58,#f9d423);color:#1b1b1b;padding:24px;}",
            ".section{padding:20px;border-bottom:1px solid #eee;}",
            "h1{margin:0;font-size:28px;}",
            "h2{margin:0 0 10px;font-size:18px;}",
            "table{width:100%;border-collapse:collapse;font-size:13px;}",
            "th,td{text-align:left;padding:8px;border-bottom:1px solid #eee;vertical-align:top;}",
            ".pill{display:inline-block;padding:2px 8px;border-radius:10px;background:#eee;margin-left:6px;font-size:12px;}",
            ".note{color:#666;font-size:13px;}",
            "</style>",
            "</head>",
            "<body>",
            "<div class=\"container\">",
            "<div class=\"header\">",
            "<h1>Snapchat Report</h1>",
            "<div class=\"note\">Tiered extraction summary</div>",
            "</div>",
        ]

        html.append("<div class=\"section\">")
        html.append("<h2>Tier status</h2>")
        html.append("<table>")
        html.append("<tr><th>Tier 1 (prefs/logs/artifacts)</th><td>{}</td></tr>".format(_fmt_bool(tier_status.get("tier1"))))
        html.append("<tr><th>Tier 2 (SQLite summaries)</th><td>{}</td></tr>".format(_fmt_bool(tier_status.get("tier2"))))
        html.append("<tr><th>Tier 3 (full decrypt)</th><td>{}</td></tr>".format(_fmt_bool(tier_status.get("tier3"))))
        html.append("</table>")
        if not tier_status.get("tier3"):
            req = tier_status.get("required_present", {})
            html.append("<p class=\"note\">Tier 3 unavailable. Required DBs present: {}</p>".format(req))
            html.append("<p class=\"note\">SCDB present: {} | Keychain metadata present: {}</p>".format(
                _fmt_bool(tier_status.get("scdb_present")),
                _fmt_bool(tier_status.get("keychain", {}).get("has_metadata")),
            ))
        html.append("</div>")

        html.append("<div class=\"section\">")
        html.append("<h2>Keychain summary</h2>")
        keychain = tier_status.get("keychain", {})
        html.append("<table>")
        html.append("<tr><th>Keychain present</th><td>{}</td></tr>".format(_fmt_bool(keychain.get("present"))))
        html.append("<tr><th>Item count</th><td>{}</td></tr>".format(keychain.get("item_count", 0)))
        html.append("<tr><th>Has metadata beyond v_Data/v_PersistentRef</th><td>{}</td></tr>".format(
            _fmt_bool(keychain.get("has_metadata"))
        ))
        html.append("<tr><th>Snapchat string matches in v_Data</th><td>{}</td></tr>".format(
            keychain.get("snap_matches", 0)
        ))
        html.append("<tr><th>Snapchat keychain entries decoded</th><td>{}</td></tr>".format(
            keychain.get("snap_entries", 0)
        ))
        html.append("</table>")
        if keychain.get("entries"):
            html.append("<p class=\"note\">Detailed keychain entries exported to Snapchat_Keychain.json</p>")
        html.append("</div>")

        fidelius_entries = []
        for entry in keychain.get("entries", []):
            if entry.get("fidelius_analysis"):
                fidelius_entries.append(entry)

        if fidelius_entries:
            html.append("<div class=\"section\">")
            html.append("<h2>Fidelius (TSAF) Analysis</h2>")
            html.append("<table>")
            html.append("<tr><th>Account</th><th>Magic</th><th>Size</th><th>SHA256</th><th>Markers</th><th>Encrypted Identity</th><th>Hashed Beta</th><th>Payload Entropy</th><th>Splits</th><th>Decrypt Trials</th><th>Decrypt Success</th></tr>")
            for entry in fidelius_entries:
                analysis = entry.get("fidelius_analysis", {})
                markers = analysis.get("markers", [])
                marker_names = ", ".join(sorted({m.get("marker", "") for m in markers if m.get("marker")})) or "-"
                enc = analysis.get("encrypted_identity", {})
                enc_size = enc.get("size") or "-"
                enc_file = enc.get("file_relpath")
                if enc_file and not enc_file.startswith("Fidelius"):
                    enc_file = os.path.join("Fidelius", enc_file)
                enc_link = f"<a href=\"{enc_file}\">{enc_size}</a>" if enc_file else str(enc_size)
                enc_entropy = enc.get("payload_entropy")
                enc_entropy_text = f"{enc_entropy:.2f}" if isinstance(enc_entropy, (int, float)) else "-"

                splits = enc.get("encrypted_identity_splits", []) if isinstance(enc, dict) else []
                split_links = []
                for split in splits:
                    label = split.get("scheme", "split")
                    ct_tag = split.get("ct_tag_file_relpath")
                    if ct_tag:
                        if not ct_tag.startswith("Fidelius"):
                            ct_tag = os.path.join("Fidelius", ct_tag)
                        split_links.append(f"<a href=\"{ct_tag}\">{label}</a>")
                split_text = ", ".join(split_links) if split_links else "-"
                split_count = len(splits) if splits else 0

                decrypt = enc.get("decrypt_trials", {}) if isinstance(enc, dict) else {}
                attempt_count = decrypt.get("attempt_count", 0)
                success_count = decrypt.get("success_count", 0)

                hb = analysis.get("hashed_beta", {})
                hb_val = hb.get("b64") or hb.get("hex") or "-"
                html.append("<tr><td>{}</td><td>{}</td><td>{}</td><td style=\"font-family:monospace;\">{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td></tr>".format(
                    entry.get("acct", ""),
                    analysis.get("magic", ""),
                    analysis.get("size", ""),
                    analysis.get("sha256", ""),
                    marker_names,
                    enc_link,
                    hb_val,
                    enc_entropy_text,
                    f"{split_count} ({split_text})",
                    attempt_count,
                    success_count,
                ))
            html.append("</table>")
            html.append("</div>")

        if sqlcipher_summary:
            html.append("<div class=\"section\">")
            html.append("<h2>SQLCipher gallery.encrypteddb</h2>")
            html.append("<table>")
            html.append("<tr><th>Status</th><td>{}</td></tr>".format(sqlcipher_summary.get("status", "unknown")))
            html.append("<tr><th>Key SHA256</th><td style=\"font-family:monospace;\">{}</td></tr>".format(
                sqlcipher_summary.get("key_sha256", "-")
            ))
            html.append("<tr><th>Decrypted DB</th><td>{}</td></tr>".format(
                f"<a href=\"{sqlcipher_summary.get('decrypted_relpath')}\">open</a>"
                if sqlcipher_summary.get("decrypted_relpath") else "-"
            ))
            if sqlcipher_summary.get("base_candidates"):
                html.append("<tr><th>Base candidates</th><td>{}</td></tr>".format(
                    "; ".join(sqlcipher_summary.get("base_candidates") or [])
                ))
            html.append("<tr><th>WAL</th><td>{}</td></tr>".format(
                sqlcipher_summary.get("wal_relpath", "-")
            ))
            html.append("<tr><th>WAL size</th><td>{}</td></tr>".format(
                sqlcipher_summary.get("wal_size", "-")
            ))
            html.append("<tr><th>SHM</th><td>{}</td></tr>".format(
                sqlcipher_summary.get("shm_relpath", "-")
            ))
            html.append("<tr><th>SHM size</th><td>{}</td></tr>".format(
                sqlcipher_summary.get("shm_size", "-")
            ))
            html.append("<tr><th>snap_key_iv entries</th><td>{}</td></tr>".format(
                sqlcipher_summary.get("snap_key_iv_count", 0)
            ))
            html.append("<tr><th>snap_key_iv export</th><td>{}</td></tr>".format(
                f"<a href=\"{sqlcipher_summary.get('snap_key_iv_relpath')}\">snap_key_iv.csv</a>"
                if sqlcipher_summary.get("snap_key_iv_relpath") else "-"
            ))
            html.append("</table>")
            if sqlcipher_summary.get("error"):
                html.append("<div class=\"note\">Error: {}</div>".format(sqlcipher_summary.get("error")))
            html.append("</div>")

        if contentmanager_summary:
            html.append("<div class=\"section\">")
            html.append("<h2>ContentManager key candidates</h2>")
            html.append("<table>")
            html.append("<tr><th>Database</th><th>Candidate count</th><th>Sample</th></tr>")
            for entry in contentmanager_summary.get("databases", []):
                sample = entry.get("sample", "-")
                html.append("<tr><td>{}</td><td>{}</td><td style=\"font-family:monospace;\">{}</td></tr>".format(
                    entry.get("name", ""),
                    entry.get("count", 0),
                    sample,
                ))
            html.append("</table>")
            if contentmanager_summary.get("notes"):
                html.append("<div class=\"note\">{}</div>".format(contentmanager_summary.get("notes")))
            html.append("</div>")

        html.append("<div class=\"section\">")
        html.append("<h2>Exported files</h2>")
        html.append("<table>")
        html.append("<tr><th>Category</th><th>Count</th><th>Sample</th></tr>")
        for cat in ("prefs", "logs", "caches", "sqlite", "artifacts"):
            sample = exported.get(cat, [])[:3]
            sample_text = ", ".join([s.get("relative_path", "") for s in sample]) or "-"
            html.append("<tr><td>{}</td><td>{}</td><td>{}</td></tr>".format(
                cat, len(exported.get(cat, [])), sample_text
            ))
        html.append("</table>")
        html.append("</div>")

        html.append("<div class=\"section\">")
        html.append("<h2>SQLite discovery summary</h2>")
        for db_info in sqlite_summary.get("databases", []):
            html.append("<h3>{}</h3>".format(db_info.get("path")))
            html.append("<div class=\"note\">Size: {} | Manifest size: {}</div>".format(
                db_info.get("size"), db_info.get("manifest_size"),
            ))
            if db_info.get("errors"):
                html.append("<div class=\"note\">Errors: {}</div>".format("; ".join(db_info.get("errors"))))
                continue
            html.append("<table>")
            html.append("<tr><th>Table</th><th>Columns</th><th>Rows</th><th>Keyword hits</th><th>Samples</th></tr>")
            for table in db_info.get("tables", []):
                samples = table.get("keyword_samples", [])
                if isinstance(samples, list):
                    sample_text = "; ".join([str(s) for s in samples[:3]])
                else:
                    sample_text = str(samples)
                html.append(
                    "<tr><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td></tr>".format(
                        table.get("name"),
                        ", ".join(table.get("columns", [])),
                        table.get("row_count"),
                        table.get("keyword_hits"),
                        sample_text,
                    )
                )
            html.append("</table>")
        html.append("</div>")

        html.append("<div class=\"section\">")
        html.append("<h2>Artifact inventory</h2>")
        gallery_missing = artifact_inventory.get("gallery_db_missing")
        wal_header = artifact_inventory.get("wal_header", "")
        wal_is_standard = artifact_inventory.get("wal_is_standard", False)
        html.append("<p class=\"note\">gallery.encrypteddb present: {}</p>".format(_fmt_bool(not gallery_missing)))
        if gallery_missing:
            html.append("<p class=\"note\">gallery.encrypteddb is missing from the manifest.</p>")
        if wal_header:
            html.append("<p class=\"note\">gallery.encrypteddb-wal head16: {}</p>".format(wal_header))
            html.append("<p class=\"note\">gallery.encrypteddb-wal header is standard WAL: {}</p>".format(
                _fmt_bool(wal_is_standard)
            ))
            if not wal_is_standard:
                html.append("<p class=\"note\">gallery.encrypteddb-wal header does not match WAL\\0 (non-standard/opaque).</p>")
        html.append("<table>")
        html.append("<tr><th>Relative path</th><th>Size</th><th>SHA256</th><th>Head16</th></tr>")
        for artifact in artifact_inventory.get("artifacts", []):
            html.append(
                "<tr><td>{}</td><td>{}</td><td>{}</td><td>{}</td></tr>".format(
                    artifact.get("relative_path"),
                    artifact.get("file_size"),
                    artifact.get("sha256"),
                    artifact.get("head16"),
                )
            )
        html.append("</table>")
        html.append("</div>")

        html.append("</div></body></html>")

        with open(report_path, "w", encoding="utf-8") as f:
            f.write("\n".join(html))

    def _hash_file(self, path: str) -> str:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()

    def _read_head16(self, path: str) -> str:
        with open(path, "rb") as f:
            data = f.read(16)
        return " ".join(f"{b:02x}" for b in data)

    def _dedupe_path(self, path: str) -> str:
        base, ext = os.path.splitext(path)
        counter = 1
        new_path = path
        while os.path.exists(new_path):
            new_path = f"{base}_{counter}{ext}"
            counter += 1
        return new_path
