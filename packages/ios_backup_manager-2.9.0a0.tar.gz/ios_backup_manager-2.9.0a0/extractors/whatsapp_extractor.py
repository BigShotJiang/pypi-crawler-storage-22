#!/usr/bin/env python3
"""
WhatsApp data extractor for iOS backups.

Extracts messages, conversations, and attachments from WhatsApp ChatStorage.sqlite
and supports export to HTML format (similar to SMS extractor).
"""

import sqlite3
import os
import shutil
import re
import html
from typing import List, Dict, Any, Optional
from datetime import datetime, timezone
from .base import CategoryDataExtractor

# Try to import PIL for image handling
try:
    from PIL import Image
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False


class WhatsAppExtractor(CategoryDataExtractor):
    """Extract and export WhatsApp data from iOS backup."""

    def __init__(self, backup_path: str):
        super().__init__(backup_path)

        # WhatsApp stores data in a shared group container
        self.whatsapp_domain = "AppDomainGroup-group.net.whatsapp.WhatsApp.shared"

        # Find ChatStorage database
        self.chat_db_path = self.find_db_file(
            self.whatsapp_domain,
            "ChatStorage.sqlite"
        )

        if not self.chat_db_path:
            raise FileNotFoundError("WhatsApp ChatStorage.sqlite not found in backup")

        # Check if database has data
        conn = sqlite3.connect(self.chat_db_path)
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM ZWAMESSAGE")
        message_count = cur.fetchone()[0]
        conn.close()

        if message_count == 0:
            raise FileNotFoundError("WhatsApp database exists but contains no messages")

        # Find contacts database (optional - for enhanced name resolution)
        self.contacts_db_path = self.find_db_file(
            "HomeDomain",
            "Library/AddressBook/AddressBook.sqlitedb"
        )

        # Contact name cache for performance
        self._contact_cache = {}

    def _get_contact_name(self, jid: str) -> Optional[str]:
        """
        Look up contact name by WhatsApp JID.

        Args:
            jid: WhatsApp JID (e.g., 17782278499@s.whatsapp.net)

        Returns:
            Contact name or None if not found
        """
        if not jid:
            return None

        # Check cache first
        if jid in self._contact_cache:
            return self._contact_cache[jid]

        # Extract phone number from JID
        phone = jid.split('@')[0] if '@' in jid else jid

        # Try iOS contacts database first
        if self.contacts_db_path:
            try:
                # Normalize phone number for matching (remove formatting)
                normalized = ''.join(c for c in phone if c.isdigit())

                conn = sqlite3.connect(self.contacts_db_path)
                conn.row_factory = sqlite3.Row
                cur = conn.cursor()

                # Search in phone numbers (property = 3)
                cur.execute("""
                    SELECT p.First, p.Last, p.Organization
                    FROM ABPerson p
                    JOIN ABMultiValue mv ON p.ROWID = mv.record_id
                    WHERE mv.property = 3 AND mv.value LIKE ?
                    LIMIT 1
                """, (f'%{normalized[-10:]}%',))  # Match last 10 digits

                row = cur.fetchone()
                conn.close()

                if row:
                    # Build name from first/last/organization
                    parts = []
                    if row['First']:
                        parts.append(row['First'])
                    if row['Last']:
                        parts.append(row['Last'])

                    if parts:
                        name = ' '.join(parts)
                    elif row['Organization']:
                        name = row['Organization']
                    else:
                        name = None

                    # Cache result
                    self._contact_cache[jid] = name
                    return name

            except Exception:
                pass  # Silently fail if contacts database has issues

        # Cache miss
        self._contact_cache[jid] = None
        return None

    def get_conversations(self, limit: Optional[int] = None, offset: int = 0, search: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get list of WhatsApp conversations (chats) with preview info.

        Args:
            limit: Maximum number of conversations to return
            offset: Number of conversations to skip
            search: Optional search string to filter conversations

        Returns list of conversation dictionaries with fields:
        - chat_id: Chat primary key
        - contact_jid: WhatsApp JID
        - display_name: Contact name or phone number
        - last_message: Last message text
        - last_message_date: Timestamp of last message
        - message_count: Total messages in conversation
        - is_group: Whether this is a group chat
        - unread_count: Number of unread messages
        """
        conn = sqlite3.connect(self.chat_db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        # Build search conditions
        search_condition = ""
        params = []
        if search:
            search_pattern = f"%{search}%"
            # Search in display name, contact JID, or any message text in the conversation
            search_condition = """ AND (
                c.ZPARTNERNAME LIKE ? OR
                c.ZCONTACTJID LIKE ? OR
                EXISTS (
                    SELECT 1 FROM ZWAMESSAGE m
                    WHERE m.ZCHATSESSION = c.Z_PK AND m.ZTEXT LIKE ?
                )
            )"""
            params = [search_pattern, search_pattern, search_pattern]

        # Get conversations with their latest message
        # Filter out status messages (ZSESSIONTYPE = 3); include hidden chats but mark them
        query = f"""
        SELECT
            c.Z_PK as chat_id,
            c.ZCONTACTJID as contact_jid,
            c.ZPARTNERNAME as partner_name,
            c.ZLASTMESSAGEDATE as last_message_date,
            c.ZHIDDEN as is_hidden,
            (SELECT m.ZTEXT FROM ZWAMESSAGE m
             WHERE m.ZCHATSESSION = c.Z_PK
             ORDER BY m.ZMESSAGEDATE DESC LIMIT 1) as last_message_text,
            c.ZUNREADCOUNT as unread_count,
            c.ZSESSIONTYPE as session_type,
            c.ZGROUPINFO as group_info,
            (SELECT COUNT(*) FROM ZWAMESSAGE m WHERE m.ZCHATSESSION = c.Z_PK) as message_count
        FROM ZWACHATSESSION c
        WHERE c.ZSESSIONTYPE != 3
          AND EXISTS (SELECT 1 FROM ZWAMESSAGE m WHERE m.ZCHATSESSION = c.Z_PK)
          {search_condition}
        ORDER BY c.ZLASTMESSAGEDATE DESC
        """

        if limit is not None:
            query += f" LIMIT {limit} OFFSET {offset}"

        cur.execute(query, params)
        chats = cur.fetchall()

        conversations = []
        for chat in chats:
            # Determine display name
            display_name = chat['partner_name']
            if not display_name:
                # Try to get name from contacts
                contact_name = self._get_contact_name(chat['contact_jid'])
                display_name = contact_name or self._format_jid(chat['contact_jid'])

            # Check if group chat
            is_group = chat['group_info'] is not None

            # Format last message preview
            last_message = chat['last_message_text'] or '(Media)'
            # Truncate long preview
            if len(last_message) > 100:
                last_message = last_message[:100] + '...'

            conversations.append({
                'chat_id': chat['chat_id'],
                'contact_jid': chat['contact_jid'],
                'display_name': display_name,
                'last_message': last_message,
                'last_message_date': chat['last_message_date'],
                'message_count': chat['message_count'],
                'is_group': is_group,
                'unread_count': chat['unread_count'] or 0,
                'is_hidden': bool(chat['is_hidden'])
            })

        conn.close()
        return conversations

    def get_conversation_ids(self) -> List[int]:
        """
        Get list of all conversation (chat) IDs.

        Returns:
            List of chat primary keys
        """
        conn = sqlite3.connect(self.chat_db_path)
        cur = conn.cursor()

        cur.execute("""
            SELECT Z_PK
            FROM ZWACHATSESSION
            WHERE ZSESSIONTYPE != 3
              AND EXISTS (SELECT 1 FROM ZWAMESSAGE m WHERE m.ZCHATSESSION = ZWACHATSESSION.Z_PK)
            ORDER BY ZLASTMESSAGEDATE DESC
        """)

        chat_ids = [row[0] for row in cur.fetchall()]
        conn.close()
        return chat_ids

    def get_conversation_count(self) -> int:
        """Get total number of WhatsApp conversations."""
        conn = sqlite3.connect(self.chat_db_path)
        cur = conn.cursor()
        cur.execute("""
            SELECT COUNT(*)
            FROM ZWACHATSESSION
            WHERE ZSESSIONTYPE != 3
              AND EXISTS (SELECT 1 FROM ZWAMESSAGE m WHERE m.ZCHATSESSION = ZWACHATSESSION.Z_PK)
        """)
        count = cur.fetchone()[0]
        conn.close()
        return count

    def get_total_message_count(self) -> int:
        """Get total number of WhatsApp messages (for overall counts)."""
        conn = sqlite3.connect(self.chat_db_path)
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM ZWAMESSAGE")
        total = cur.fetchone()[0]
        conn.close()
        return total

    def get_messages(self, chat_id: int, limit: Optional[int] = None, offset: int = 0) -> List[Dict[str, Any]]:
        """
        Get messages for a specific WhatsApp conversation.

        Args:
            chat_id: Chat primary key
            limit: Max messages to return
            offset: Offset for pagination

        Returns:
            List of message dictionaries with fields:
            - message_id: Message primary key
            - text: Message text content
            - date: Timestamp
            - is_from_me: Whether sent by device owner
            - from_jid: Sender's WhatsApp JID
            - to_jid: Recipient's JID
            - message_type: Type of message (0=text, 1=image, 2=video, etc.)
            - media_item: Media item info (if applicable)
        """
        conn = sqlite3.connect(self.chat_db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        # Get messages for this chat (handle optional columns across WhatsApp versions)
        cur.execute("PRAGMA table_info(ZWAMESSAGE)")
        message_columns = {row[1] for row in cur.fetchall()}
        select_fields = [
            "m.Z_PK as message_id",
            "m.ZTEXT as text",
            "m.ZMESSAGEDATE as message_date",
            "m.ZSENTDATE as sent_date",
            "m.ZISFROMME as is_from_me",
            "m.ZFROMJID as from_jid",
            "m.ZTOJID as to_jid",
            "m.ZMESSAGETYPE as message_type",
            "m.ZMEDIAITEM as media_item_id",
            "m.ZPUSHNAME as push_name",
            "m.ZSTANZAID as stanza_id",
        ]
        if "ZMEDIALOCALPATH" in message_columns:
            select_fields.append("m.ZMEDIALOCALPATH as media_local_path")
        if "ZMEDIAURL" in message_columns:
            select_fields.append("m.ZMEDIAURL as media_url")
        if "ZMEDIATHUMBNAILLOCALPATH" in message_columns:
            select_fields.append("m.ZMEDIATHUMBNAILLOCALPATH as media_thumbnail_path")

        query = f"""
        SELECT
            {", ".join(select_fields)}
        FROM ZWAMESSAGE m
        WHERE m.ZCHATSESSION = ?
        ORDER BY m.ZMESSAGEDATE ASC
        """

        if limit is not None:
            query += f" LIMIT {limit} OFFSET {offset}"

        cur.execute(query, (chat_id,))
        messages = cur.fetchall()

        result = []
        for msg in messages:
            msg_row = dict(msg)
            # Get media item if present
            media_item = None
            if msg_row.get('media_item_id'):
                cur.execute("""
                    SELECT
                        Z_PK as media_id,
                        ZMEDIALOCALPATH as media_path,
                        ZTHUMBNAILLOCALPATH as thumbnail_path,
                        ZFILESIZE as file_size,
                        ZTITLE as title,
                        ZVCARDSTRING as mime_type,
                        ZMEDIAURL as media_url
                    FROM ZWAMEDIAITEM
                    WHERE Z_PK = ?
                """, (msg_row.get('media_item_id'),))
                media_row = cur.fetchone()
                if media_row:
                    media_item = {
                        'media_id': media_row['media_id'],
                        'media_path': media_row['media_path'],
                        'thumbnail_path': media_row['thumbnail_path'],
                        'file_size': media_row['file_size'],
                        'title': media_row['title'],
                        'mime_type': media_row['mime_type'],
                        'media_url': media_row['media_url']
                    }
            if not media_item:
                media_path = msg_row.get('media_local_path')
                media_url = msg_row.get('media_url')
                thumbnail_path = msg_row.get('media_thumbnail_path')
                if media_path or media_url:
                    media_item = {
                        'media_id': None,
                        'media_path': media_path,
                        'thumbnail_path': thumbnail_path,
                        'file_size': None,
                        'title': None,
                        'mime_type': None,
                        'media_url': media_url,
                    }

            result.append({
                'message_id': msg_row.get('message_id'),
                'text': msg_row.get('text') or '',
                'date': msg_row.get('message_date'),
                'sent_date': msg_row.get('sent_date'),
                'is_from_me': bool(msg_row.get('is_from_me')),
                'from_jid': msg_row.get('from_jid'),
                'to_jid': msg_row.get('to_jid'),
                'message_type': msg_row.get('message_type'),
                'push_name': msg_row.get('push_name'),
                'stanza_id': msg_row.get('stanza_id'),
                'media_item': media_item
            })

        conn.close()
        return result

    def get_message_count(self, chat_id: int) -> int:
        """Get total number of messages in a conversation."""
        conn = sqlite3.connect(self.chat_db_path)
        cur = conn.cursor()
        cur.execute("""
            SELECT COUNT(*)
            FROM ZWAMESSAGE
            WHERE ZCHATSESSION = ?
        """, (chat_id,))
        count = cur.fetchone()[0]
        conn.close()
        return count

    def get_media_path(self, media_local_path: str) -> Optional[str]:
        """
        Get full path to media file in backup.

        Args:
            media_local_path: Path from ZWAMEDIAITEM.ZMEDIALOCALPATH
                             (e.g., "Media/17782278499@s.whatsapp.net/0/5/file.jpg")

        Returns:
            Full path to media file, or None if not found
        """
        if not media_local_path:
            return None

        # WhatsApp media is stored in Message/Media/ but database has just Media/
        # Need to prepend "Message/" to the path
        relative_path = f"Message/{media_local_path}"

        # Find the file in the backup
        file_path = self.find_file_in_backup(
            self.whatsapp_domain,
            relative_path
        )

        return file_path

    def _format_whatsapp_timestamp(self, timestamp: Optional[float]) -> Optional[datetime]:
        """
        Convert WhatsApp timestamp to datetime.

        WhatsApp uses Apple's Core Data timestamp (seconds since 2001-01-01).
        """
        if timestamp is None or timestamp == 0:
            return None

        try:
            # Apple epoch is 2001-01-01 00:00:00 UTC
            apple_epoch = datetime(2001, 1, 1, tzinfo=timezone.utc).timestamp()
            unix_timestamp = apple_epoch + timestamp

            return datetime.fromtimestamp(unix_timestamp)
        except Exception:
            return None

    def _format_timestamp_iso(self, timestamp: Optional[float]) -> Optional[str]:
        dt = self._format_whatsapp_timestamp(timestamp)
        if not dt:
            return None
        return dt.isoformat()

    def _emit_message_timeline_events(self, messages: List[Dict[str, Any]], conversation_name: str,
                                      output_path: str, timeline_emitter) -> None:
        file_name = os.path.basename(output_path)
        link_hint = f"WhatsApp/Conversations/{file_name}"
        attachments_rel = "../WhatsApp/WhatsApp Attachments"
        for msg in messages:
            ts_iso = self._format_timestamp_iso(msg.get('date'))
            if not ts_iso:
                continue
            title = conversation_name or "WhatsApp Message"
            text = msg.get('text') or ''
            details = {
                'conversation': conversation_name,
                'direction': 'outgoing' if msg.get('is_from_me') else 'incoming',
                'text': text[:200] if text else '',
            }
            timeline_emitter.emit({
                'timestamp': ts_iso,
                'raw_timestamp': msg.get('date'),
                'raw_format': 'apple_epoch_seconds',
                'source_app': 'WhatsApp',
                'source_category': 'WhatsApp',
                'event_type': 'message',
                'title': title,
                'details': details,
                'confidence': 'high',
                'raw_source_path': self.chat_db_path,
                'report_anchor': f"msg-{msg.get('message_id')}",
                'link_hint': link_hint,
            })
            media_item = msg.get('media_item')
            if media_item:
                filename = os.path.basename(media_item.get('media_path') or '') or media_item.get('title') or 'Attachment'
                mime_type = (media_item.get('mime_type') or '').lower()
                ext = os.path.splitext(filename)[1].lower()
                event_type = 'file_attachment'
                if mime_type.startswith('image/'):
                    event_type = 'photo_attachment'
                elif mime_type.startswith('video/'):
                    event_type = 'video_attachment'
                elif mime_type.startswith('audio/'):
                    event_type = 'audio_attachment'
                elif ext:
                    if ext in ('.jpg', '.jpeg', '.png', '.gif', '.heic', '.heif', '.bmp', '.tif', '.tiff', '.webp', '.svg'):
                        event_type = 'photo_attachment'
                    elif ext in ('.mov', '.mp4', '.m4v', '.avi', '.mkv', '.3gp', '.3gpp'):
                        event_type = 'video_attachment'
                    elif ext in ('.m4a', '.aac', '.mp3', '.wav', '.aiff', '.amr', '.caf', '.flac', '.opus'):
                        event_type = 'audio_attachment'

                preview_type = None
                category_bucket = None
                if event_type.startswith('photo'):
                    preview_type = 'image'
                    category_bucket = 'Photos'
                elif event_type.startswith('video'):
                    preview_type = 'video'
                    category_bucket = 'Videos'
                elif event_type.startswith('audio'):
                    preview_type = 'audio'
                    category_bucket = 'Audio'
                elif ext in ('.pdf', '.txt', '.rtf', '.md', '.json', '.csv', '.xml', '.log', '.html', '.htm'):
                    preview_type = 'text' if ext != '.pdf' else 'pdf'
                    category_bucket = 'Text' if preview_type == 'text' else 'Files'

                preview_path = f"{attachments_rel}/{filename}" if filename else ''
                timeline_emitter.emit({
                    'timestamp': ts_iso,
                    'raw_timestamp': msg.get('date'),
                    'raw_format': 'apple_epoch_seconds',
                    'source_app': 'WhatsApp',
                    'source_category': 'WhatsApp',
                    'event_type': event_type,
                    'title': f"{conversation_name}: {filename}",
                    'details': {
                        'conversation': conversation_name,
                        'filename': filename,
                        'mime_type': media_item.get('mime_type'),
                        'media_path': media_item.get('media_path'),
                        'media_url': media_item.get('media_url'),
                        'preview_path': preview_path,
                        'preview_type': preview_type,
                    },
                    'category_bucket': category_bucket,
                    'confidence': 'low' if event_type == 'file_attachment' else 'high',
                    'raw_source_path': media_item.get('media_path') or '',
                    'report_anchor': f"msg-{msg.get('message_id')}",
                    'link_hint': link_hint,
                })

    def _format_jid(self, jid: str) -> str:
        """Format WhatsApp JID for display."""
        if not jid:
            return "Unknown"

        # Extract phone number from JID
        if '@' in jid:
            phone = jid.split('@')[0]
            # Format phone numbers (US format)
            if phone.startswith('1') and len(phone) == 11:
                return f"+1 ({phone[1:4]}) {phone[4:7]}-{phone[7:]}"
            elif len(phone) >= 10:
                return f"+{phone}"

        return jid

    def _escape_html(self, text: str) -> str:
        """Escape HTML special characters."""
        if not text:
            return ''

        return (text
                .replace('&', '&amp;')
                .replace('<', '&lt;')
                .replace('>', '&gt;')
                .replace('"', '&quot;')
                .replace("'", '&#39;')
                .replace('\n', '<br>'))

    # Methods for compatibility with CategoryDataExtractor base class
    def get_count(self) -> int:
        """Get total number of messages (for base class compatibility/counts)."""
        return self.get_total_message_count()

    def get_items(self, limit: Optional[int] = None, offset: int = 0, **kwargs) -> List[Dict[str, Any]]:
        """Get conversations (for base class compatibility)."""
        search = kwargs.get('search', None)
        return self.get_conversations(limit, offset, search)

    def get_item_summary(self, item: Dict[str, Any]) -> str:
        """Get summary string for conversation list."""
        return f"{item['display_name']} - {item['last_message'][:50]}"

    def export(self, items: List[Dict[str, Any]], output_path: str, format: str = 'html',
               progress_callback=None, skip_attachments: bool = False, timeline_emitter=None) -> bool:
        """
        Export WhatsApp conversations to HTML files (similar to SMS export).

        Creates:
        - WhatsApp.html: Index of all conversations with search
        - Conversations/: Subdirectory containing individual conversation HTML files
        - WhatsApp Attachments/: Directory for media files

        Args:
            items: List of conversations (chat IDs or full conversation dicts)
            output_path: Output directory path
            format: 'html' or 'files' (both treated as HTML export)
            progress_callback: Optional callback(current, total, item_name) -> bool

        Returns:
            True if export succeeded
        """
        # Accept both 'html' and 'files' format (treat them the same)
        if format not in ('html', 'files'):
            raise ValueError(f"Unsupported export format: {format}")

        try:
            self._reset_export_bytes()
            os.makedirs(output_path, exist_ok=True)

            # Create Conversations subdirectory
            conversations_dir = os.path.join(output_path, 'Conversations')
            os.makedirs(conversations_dir, exist_ok=True)

            # Create Attachments directory at output root
            attachments_dir = os.path.join(output_path, 'WhatsApp Attachments')
            os.makedirs(attachments_dir, exist_ok=True)

            # Track conversation info for index
            conversation_list = []

            # Track used filenames to prevent collisions
            used_filenames = set()

            total = len(items) + 1  # +1 for creating index at the end

            for i, item in enumerate(items):
                if isinstance(item, dict):
                    chat_id = item['chat_id']
                    display_name = item['display_name']
                    last_message = item.get('last_message', '')
                    last_message_date = item.get('last_message_date', 0)
                    message_count = item.get('message_count', 0)
                    is_group = item.get('is_group', False)
                else:
                    chat_id = item
                    display_name = f"Conversation_{chat_id}"
                    last_message = ''
                    last_message_date = 0
                    message_count = 0
                    is_group = False

                # Report progress
                if progress_callback:
                    if not progress_callback(i + 1, total, f"Exporting: {display_name}"):
                        return False

                # Sanitize filename
                safe_name = "".join(c for c in display_name if c.isalnum() or c in (' ', '-', '_')).strip()

                # Prevent filename collisions
                base_name = safe_name
                if base_name in used_filenames:
                    safe_name = f"{base_name}_chat{chat_id}"
                used_filenames.add(safe_name)

                html_file = os.path.join(conversations_dir, f"{safe_name}.html")

                # Export individual conversation
                export_result = self.export_conversation_html(
                    chat_id, html_file, display_name, attachments_dir,
                    progress_callback=progress_callback,
                    skip_attachments=skip_attachments,
                    timeline_emitter=timeline_emitter
                )
                if isinstance(export_result, tuple):
                    first_page = export_result[0]
                    valid_message_count = export_result[1] if len(export_result) > 1 else None
                    search_text = export_result[2] if len(export_result) > 2 else None
                else:
                    first_page = export_result
                    valid_message_count = 0 if export_result is None else None
                    search_text = None

                # Track for index
                conversation_list.append({
                    'chat_id': chat_id,
                    'display_name': display_name,
                    'safe_name': safe_name,
                    'file_name': first_page or f"{safe_name}.html",
                    'last_message': last_message,
                    'last_message_date': last_message_date,
                    'message_count': message_count,
                    'valid_message_count': valid_message_count,
                    'search_text': search_text,
                    'is_group': is_group,
                    'is_hidden': bool(item.get('is_hidden')) if isinstance(item, dict) else False
                })

            # Create WhatsApp.html index
            if progress_callback:
                if not progress_callback(total, total, "Creating index..."):
                    return False

            self._create_whatsapp_index(output_path, conversation_list)

            return True

        except Exception as e:
            print(f"Error exporting WhatsApp conversations: {e}")
            import traceback
            traceback.print_exc()
            return False

    def export_conversation_html(self, chat_id: int, output_path: str,
                                 conversation_name: str = "Conversation",
                                 attachments_dir: str = None,
                                 progress_callback=None,
                                 skip_attachments: bool = False,
                                 timeline_emitter=None) -> str:
        """
        Export a WhatsApp conversation to HTML file.

        Args:
            chat_id: Chat primary key to export
            output_path: Output HTML file path (base name)
            conversation_name: Display name for conversation
            attachments_dir: Directory for attachments
            progress_callback: Optional progress callback

        Returns:
            Tuple of (filename, valid_message_count, search_text) or None if failed
        """
        try:
            # Get total message count
            total_messages = self.get_message_count(chat_id)

            if total_messages == 0:
                print(f"No messages found for chat {chat_id}")
                return None

            # Get all messages
            messages = self.get_messages(chat_id)

            if not messages:
                return None

            if timeline_emitter is not None:
                self._emit_message_timeline_events(messages, conversation_name, output_path, timeline_emitter)

            # Generate search text from message bodies
            search_text_parts = [msg.get('text', '') for msg in messages if msg.get('text')]
            search_text = ' '.join(search_text_parts)
            search_text = re.sub(r'\s+', ' ', search_text).strip().lower()
            if len(search_text) > 4000:
                search_text = search_text[:4000]

            # Generate filename
            html_path = output_path if output_path.endswith('.html') else f"{output_path}.html"

            # Generate HTML
            html, valid_message_count = self._generate_whatsapp_html(
                messages,
                conversation_name,
                attachments_dir,
                html_path,
                skip_attachments=skip_attachments
            )

            # Write HTML file
            with open(html_path, 'w', encoding='utf-8') as f:
                f.write(html)
            self._add_export_bytes(html_path)

            print(f"Exported {len(messages)} WhatsApp messages to {html_path}")

            return os.path.basename(html_path), valid_message_count, search_text

        except Exception as e:
            print(f"Error exporting WhatsApp conversation: {e}")
            import traceback
            traceback.print_exc()
            return None

    def _generate_whatsapp_html(self, messages: List[Dict[str, Any]],
                                conversation_name: str, attachments_dir: str,
                                output_path: str, skip_attachments: bool = False) -> tuple[str, int]:
        """Generate HTML for WhatsApp messages."""

        # Calculate relative path from HTML to attachments directory
        if output_path and attachments_dir:
            html_dir = os.path.dirname(output_path)
            rel_path_prefix = os.path.relpath(attachments_dir, html_dir).replace('\\', '/')
        else:
            rel_path_prefix = "../WhatsApp Attachments"

        html_header = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{self._escape_html(conversation_name)}</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}

        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            background: #FFFFFF;
            padding: 20px;
        }}

        .container {{
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }}

        .header {{
            background: linear-gradient(135deg, #09BC26 0%, #68FC82 100%);
            color: white;
            padding: 30px;
            border-radius: 12px;
            margin-bottom: 0;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            text-align: left;
        }}

        .header h1 {{
            font-size: 32px;
            font-weight: 600;
            margin-bottom: 10px;
        }}
        .breadcrumbs {{
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            letter-spacing: 0.2px;
            color: rgba(255,255,255,0.85);
            margin-bottom: 10px;
        }}
        .breadcrumbs a {{
            color: #fff;
            text-decoration: none;
            font-weight: 600;
        }}
        .breadcrumbs a:hover {{
            text-decoration: underline;
        }}
        .breadcrumbs .back-arrow {{
            opacity: 0.6;
        }}
        .embedded .breadcrumbs {{
            display: none;
        }}

        .header p {{
            font-size: 16px;
            opacity: 0.9;
            margin: 0;
        }}

        .messages {{
            padding: 20px;
            min-height: 400px;
            background: #FFFFFF;
        }}

        .date-separator {{
            text-align: center;
            margin: 20px 0;
            color: #667;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }}

        .message {{
            margin: 10px 0;
            display: flex;
            clear: both;
        }}
        .highlight-target {{
            background-color: #fff3cd;
            outline: 2px solid #f59e0b;
        }}
        .highlight-target .bubble {{
            background-color: #fff3cd;
        }}
        .search-hit {{
            background: #ffec99;
            border-radius: 3px;
            padding: 0 1px;
        }}
        .search-hit-block {{
            background: #fff7d6;
            border: 2px solid #f59e0b;
            border-radius: 12px;
            padding: 4px;
        }}

        .message.sent {{
            justify-content: flex-end;
        }}

        .message.received {{
            justify-content: flex-start;
        }}

        .bubble {{
            max-width: 65%;
            padding: 8px 12px;
            border-radius: 8px;
            word-wrap: break-word;
            position: relative;
        }}

        .message.sent .bubble {{
            background: #dcf8c6;
            color: #000;
        }}

        .message.received .bubble {{
            background: white;
            color: #000;
        }}

        .bubble-content {{
            margin-bottom: 5px;
        }}

        .timestamp {{
            font-size: 10px;
            color: #667;
            margin-top: 5px;
            text-align: right;
        }}

        .attachment {{
            margin-top: 10px;
            border-radius: 8px;
            overflow: hidden;
            max-width: 100%;
        }}

        .attachment img {{
            max-width: 100%;
            display: block;
            border-radius: 8px;
        }}

        .attachment video {{
            max-width: 100%;
            display: block;
            border-radius: 8px;
        }}

        .attachment audio {{
            max-width: 100%;
            display: block;
            margin-bottom: 5px;
        }}

        .attachment-filename {{
            font-size: 11px;
            color: #667;
            margin-top: 5px;
        }}

        .attachment-link {{
            display: block;
            padding: 10px;
            background: rgba(0,0,0,0.05);
            border-radius: 5px;
            margin-top: 5px;
            text-decoration: none;
            color: #09BC26;
            font-size: 12px;
        }}

        .attachment-link:hover {{
            background: rgba(0,0,0,0.1);
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../WhatsApp.html">Back to conversations</a></div>
            <h1>💬 {self._escape_html(conversation_name)}</h1>
        </div>
        <div class="messages">
"""

        html_footer = """
        </div>
    </div>
<script>
    (function() {
        if (!window.location.hash) return;
        const target = document.querySelector(window.location.hash);
        if (!target) return;
        target.classList.add('highlight-target');
        try {
            target.scrollIntoView({ block: 'center' });
        } catch (e) {
            target.scrollIntoView();
        }
    })();
</script>
<script>
    (function() {
        const params = new URLSearchParams(window.location.search);
        let savedTerm = '';
        try {
            savedTerm = localStorage.getItem('whatsappLastSearch') || '';
        } catch (err) {}
        const term = (params.get('q') || savedTerm || '').trim();
        if (!term) return;

        function highlightInElement(element, query) {
            const needle = query.toLowerCase();
            const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT, {
                acceptNode(node) {
                    if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
                    const parent = node.parentElement;
                    if (!parent) return NodeFilter.FILTER_REJECT;
                    if (parent.classList && parent.classList.contains('search-hit')) return NodeFilter.FILTER_REJECT;
                    return NodeFilter.FILTER_ACCEPT;
                }
            });
            const nodes = [];
            let node;
            while ((node = walker.nextNode())) {
                if (node.nodeValue.toLowerCase().includes(needle)) {
                    nodes.push(node);
                }
            }
            nodes.forEach(textNode => {
                const text = textNode.nodeValue;
                const lower = text.toLowerCase();
                const frag = document.createDocumentFragment();
                let lastIndex = 0;
                let idx = lower.indexOf(needle, lastIndex);
                while (idx !== -1) {
                    const before = text.slice(lastIndex, idx);
                    if (before) frag.appendChild(document.createTextNode(before));
                    const mark = document.createElement('mark');
                    mark.className = 'search-hit';
                    mark.textContent = text.slice(idx, idx + needle.length);
                    frag.appendChild(mark);
                    lastIndex = idx + needle.length;
                    idx = lower.indexOf(needle, lastIndex);
                }
                const after = text.slice(lastIndex);
                if (after) frag.appendChild(document.createTextNode(after));
                textNode.parentNode.replaceChild(frag, textNode);
            });
        }

        const targets = document.querySelectorAll('.bubble-content');
        targets.forEach(el => highlightInElement(el, term));
        document.querySelectorAll('.search-hit').forEach(mark => {
            const block = mark.closest('.message');
            if (block) block.classList.add('search-hit-block');
        });

        function scrollToFirstHit() {
            const first = document.querySelector('.search-hit');
            if (!first) return;
            try {
                first.scrollIntoView({ block: 'center' });
            } catch (e) {
                first.scrollIntoView();
            }
            const block = first.closest('.message');
            if (!block) return;
            const imgs = block.querySelectorAll('img');
            if (!imgs.length) return;
            let pending = imgs.length;
            imgs.forEach(img => {
                if (img.complete) {
                    pending -= 1;
                    return;
                }
                img.addEventListener('load', () => {
                    pending -= 1;
                    if (pending <= 0) {
                        try {
                            first.scrollIntoView({ block: 'center' });
                        } catch (e) {
                            first.scrollIntoView();
                        }
                    }
                }, { once: true });
            });
        }

        scrollToFirstHit();
        requestAnimationFrame(() => {
            scrollToFirstHit();
            setTimeout(scrollToFirstHit, 250);
        });
    })();
</script>
<script>
(function() {
    try {
        if (window.parent && window.parent !== window) {
            window.parent.postMessage({type: 'device-nav', href: window.location.href}, '*');
        }
    } catch (err) {}
})();
</script>
</body>
</html>
"""

        # Build message HTML
        messages_html = []
        last_date = None
        valid_message_count = 0

        for idx, msg in enumerate(messages, 1):
            # Format date
            msg_date = self._format_whatsapp_timestamp(msg['date'])
            msg_date_str = msg_date.strftime('%B %d, %Y') if msg_date else 'Unknown Date'
            msg_time_str = msg_date.strftime('%I:%M %p') if msg_date else ''

            # Add date separator if date changed
            if msg_date_str != last_date:
                messages_html.append(f'<div class="date-separator">{msg_date_str}</div>')
                last_date = msg_date_str

            # Message bubble
            msg_class = 'sent' if msg['is_from_me'] else 'received'

            bubble_content = ''

            # Add text content
            if msg['text']:
                bubble_content += f'<div class="bubble-content">{self._escape_html(msg["text"])}</div>'

            # Add media attachment
            if msg['media_item'] and not skip_attachments:
                attachment_html = self._format_whatsapp_attachment(
                    msg['media_item'], attachments_dir, rel_path_prefix
                )
                if attachment_html:
                    bubble_content += attachment_html
            elif msg['media_item'] and skip_attachments:
                # Placeholder when skipping attachments
                title = msg['media_item'].get('title') or os.path.basename(msg['media_item'].get('media_path', 'attachment'))
                bubble_content += f'<div class="attachment-link">[Attachment skipped: {self._escape_html(title)}]</div>'

            if bubble_content.strip():
                valid_message_count += 1

            messages_html.append(f'''
            <div class="message {msg_class}" id="msg-{msg['message_id']}">
                <div class="bubble">
                    {bubble_content}
                    <div class="timestamp">{msg_time_str}</div>
                </div>
            </div>
            ''')

            # Periodic progress updates to avoid UI looking hung
            # Periodic progress updates to avoid UI looking hung
            # (progress_callback is passed down from export)
            if 'progress_callback' in locals() and progress_callback and idx % 100 == 0:
                try:
                    progress_callback(idx, len(messages), f"Rendering messages... {idx}/{len(messages)}")
                except Exception:
                    pass

        return html_header + '\n'.join(messages_html) + html_footer, valid_message_count

    def _format_whatsapp_attachment(self, media_item: Dict[str, Any],
                                    attachments_dir: str, rel_path_prefix: str) -> str:
        """Format WhatsApp media attachment HTML."""
        if not media_item or not media_item.get('media_path'):
            return ''

        def _sanitize_parts(base: str, ext: str) -> tuple[str, str]:
            """Sanitize base/ext for Windows paths (strip invalid chars, limit length)."""
            invalid = '<>:"/\\\\|?*'
            for ch in invalid:
                base = base.replace(ch, '_')
                ext = ext.replace(ch, '_')
            base = ''.join(c for c in base if c >= ' ' or c == '\t')
            ext = ''.join(c for c in ext if c >= ' ' or c == '\t')
            if not base:
                base = "attachment"
            base = base.rstrip('. ')
            if len(ext) > 10:
                ext = ext[:10]
            if len(base) > 150:
                base = base[:150]
            return base, ext

        # Get media file from backup
        source_path = self.get_media_path(media_item['media_path'])

        if not source_path or not os.path.exists(source_path):
            title = media_item.get('title', 'unknown')
            return f'<div class="attachment-link">[Attachment not found: {title}]</div>'

        # Determine filename
        original_filename = os.path.basename(media_item['media_path'])
        # Use title if available, otherwise use original filename
        if media_item.get('title') and media_item['title'].strip():
            # Sanitize title for filename
            safe_title = "".join(c for c in media_item['title'] if c.isalnum() or c in (' ', '-', '_', '.')).strip()
            ext = os.path.splitext(original_filename)[1]
            filename = safe_title if safe_title.endswith(ext) else f"{safe_title}{ext}"
        else:
            filename = original_filename

        base, ext = os.path.splitext(filename)
        base, ext = _sanitize_parts(base, ext)
        filename = f"{base}{ext}"
        dest_path = os.path.join(attachments_dir, filename)

        # Handle duplicate filenames
        base, ext = os.path.splitext(filename)
        counter = 1
        while os.path.exists(dest_path):
            suffix = f"_{counter}"
            max_base_len = max(1, 200 - len(suffix) - len(ext))
            adj_base = base[:max_base_len]
            filename = f"{adj_base}{suffix}{ext}"
            dest_path = os.path.join(attachments_dir, filename)
            counter += 1
            if counter > 500:
                print(f"Warning: too many duplicate attachment names for {filename}, skipping further renames")
                break

        try:
            # Copy file
            shutil.copyfile(source_path, dest_path)
            self._add_export_bytes(dest_path)
        except Exception as e:
            print(f"Warning: Could not copy attachment {filename}: {e}")
            return f'<div class="attachment-link">[Could not copy: {self._escape_html(filename)}]</div>'

        # Generate HTML based on mime type
        mime_type = media_item.get('mime_type') or ''
        rel_path = f"{rel_path_prefix}/{filename}"

        if mime_type.startswith('image/'):
            return f'<div class="attachment"><img src="{rel_path}" alt="{filename}"></div>'
        elif mime_type.startswith('video/'):
            return f'<div class="attachment"><video src="{rel_path}" controls></video></div>'
        elif mime_type.startswith('audio/'):
            return f'<div class="attachment"><audio src="{rel_path}" controls></audio><div class="attachment-filename">🎤 {filename}</div></div>'
        else:
            return f'<a href="{rel_path}" class="attachment-link">📎 {filename}</a>'

    def _create_whatsapp_index(self, output_path: str, conversations: List[Dict[str, Any]]):
        """Create WhatsApp.html index with all conversations."""
        index_file = os.path.join(output_path, 'WhatsApp.html')
        total_messages = sum(conv.get('message_count', 0) for conv in conversations)
        search_text_by_chat = {}
        search_text_by_file = {}
        conn = None
        try:
            conn = sqlite3.connect(self.chat_db_path)
            cur = conn.cursor()
            cur.execute("PRAGMA table_info(ZWAMESSAGE)")
            columns = {row[1] for row in cur.fetchall() if row}
            if "ZTEXT" in columns:
                for conv in conversations:
                    chat_id = conv.get('chat_id')
                    if chat_id is None:
                        continue
                    try:
                        cur.execute("""
                            SELECT ZTEXT
                            FROM ZWAMESSAGE
                            WHERE ZCHATSESSION = ?
                              AND ZTEXT IS NOT NULL
                            ORDER BY ZDATE DESC
                            LIMIT 200
                        """, (chat_id,))
                        texts = [row[0] for row in cur.fetchall() if row and row[0]]
                        if texts:
                            combined = " ".join(texts)
                            search_text_by_chat[chat_id] = combined[:4000].lower()
                    except sqlite3.Error:
                        continue
        finally:
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass

        for conv in conversations:
            file_name = conv.get('file_name')
            if not file_name:
                continue
            convo_file = os.path.join(output_path, "Conversations", file_name)
            try:
                with open(convo_file, "r", encoding="utf-8", errors="ignore") as convo_f:
                    convo_html = convo_f.read()
                text_matches = re.findall(r'<div class="bubble-content">(.*?)</div>', convo_html, re.S)
                if text_matches:
                    cleaned = []
                    for part in text_matches:
                        text_only = re.sub(r'<[^>]+>', '', part)
                        text_only = html.unescape(text_only).strip()
                        if text_only:
                            cleaned.append(text_only)
                    if cleaned:
                        search_text_by_file[file_name] = " ".join(cleaned)[:4000].lower()
            except Exception:
                continue

        html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WhatsApp Messages</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: #f6f6f6;
            padding: 20px;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            overflow: hidden;
        }}
        .header {{
            background: linear-gradient(135deg, #09BC26 0%, #68FC82 100%);
            color: white;
            padding: 30px;
            text-align: left;
        }}
        .header h1 {{
            font-size: 32px;
            font-weight: 600;
            margin-bottom: 10px;
        }}
        .breadcrumbs {{
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            letter-spacing: 0.2px;
            color: rgba(255,255,255,0.85);
            margin-bottom: 10px;
        }}
        .breadcrumbs a {{
            color: #fff;
            text-decoration: none;
            font-weight: 600;
        }}
        .breadcrumbs a:hover {{
            text-decoration: underline;
        }}
        .breadcrumbs .back-arrow {{
            opacity: 0.6;
        }}
        .embedded .breadcrumbs {{
            display: none;
        }}
        .header p {{
            font-size: 16px;
            opacity: 0.9;
            margin: 0;
        }}
        .search-box {{
            padding: 20px;
            border-bottom: 1px solid #e5e5e5;
            position: relative;
        }}
        .search-box input {{
            width: 100%;
            padding: 12px 46px 12px 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
        }}
        .search-box input:focus {{
            outline: none;
            border-color: #09BC26;
        }}
        .clear-search {{
            position: absolute;
            right: 24px;
            top: 50%;
            transform: translateY(-50%);
            border: 1px solid #d1d5db;
            background: #f3f4f6;
            color: #111827;
            border-radius: 6px;
            padding: 4px 8px;
            font-size: 12px;
            cursor: pointer;
            display: none;
        }}
        .clear-search.visible {{ display: inline-block; }}
        .conversation {{
            padding: 15px 20px;
            border-bottom: 1px solid #e5e5e5;
            cursor: pointer;
            transition: background-color 0.2s;
            display: block;
            text-decoration: none;
            color: inherit;
        }}
        .conversation:last-child {{
            border-bottom: none;
        }}
        .conversation:hover {{
            background-color: #f8f8f8;
        }}
        .conversation.hidden {{
            display: none;
        }}
        .conv-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 6px;
        }}
        .conv-name {{
            font-size: 16px;
            font-weight: 600;
            color: #000;
            flex: 1;
        }}
        .conv-date {{
            font-size: 14px;
            color: #8E8E93;
            margin-left: 10px;
        }}
        .conv-preview {{
            font-size: 14px;
            color: #8E8E93;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }}
        .conv-badge {{
            display: inline-block;
            background-color: #25d366;
            color: white;
            border-radius: 10px;
            padding: 2px 8px;
            font-size: 12px;
            font-weight: 600;
            margin-left: 8px;
        }}
        .conv-missing-badge {{
            display: inline-block;
            background-color: #ef4444;
            color: white;
            border-radius: 10px;
            padding: 2px 8px;
            font-size: 12px;
            font-weight: 600;
            margin-left: 6px;
        }}
        .conv-hidden-badge {{
            display: inline-block;
            background-color: #8e8e93;
            color: white;
            border-radius: 10px;
            padding: 2px 8px;
            font-size: 12px;
            font-weight: 600;
            margin-left: 8px;
        }}
        .no-results {{
            text-align: center;
            padding: 40px;
            color: #8E8E93;
            font-size: 16px;
            display: none;
        }}
        .no-results.visible {{
            display: block;
        }}
        .export-info {{
            text-align: center;
            padding: 20px;
            color: #8E8E93;
            font-size: 14px;
        }}
        .group-icon {{
            color: #8E8E93;
            margin-right: 4px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Start_Here.html">Back</a></div>
            <h1>WhatsApp Messages</h1>
            <p>Extracted from iOS Backup on {datetime.now().strftime("%B %d, %Y")}</p>
        </div>

        <div class="search-box">
            <input type="text" id="searchInput" placeholder="Search conversations..." onkeyup="filterConversations()">
            <button id="clearSearch" class="clear-search" title="Clear" aria-label="Clear search">X</button>
        </div>

        <div id="conversationList">
'''

        # Add each conversation
        for conv in conversations:
            # Format timestamp
            timestamp_str = ""
            if conv['last_message_date']:
                try:
                    dt = self._format_whatsapp_timestamp(conv['last_message_date'])
                    if dt:
                        now = datetime.now(timezone.utc)
                        if dt.date() == now.date():
                            timestamp_str = dt.strftime("%I:%M %p")
                        elif (now - dt).days < 7:
                            timestamp_str = dt.strftime("%A")
                        else:
                            timestamp_str = dt.strftime("%m/%d/%y")
                except:
                    timestamp_str = ""

            # Preview text
            preview = conv['last_message'] or '(No preview available)'
            if len(preview) > 100:
                preview = preview[:100] + '...'

            # Group icon
            group_icon = '<span class="group-icon">&#128101;</span>' if conv['is_group'] else ''

            total_count = conv.get('message_count') or 0
            valid_count = conv.get('valid_message_count')
            if valid_count is None:
                valid_count = total_count
            missing_count = max(total_count - valid_count, 0)

            # Message count badges
            count_badge = f'<span class="conv-badge">{valid_count}</span>' if valid_count > 0 else ''
            missing_badge = f'<span class="conv-missing-badge">{missing_count}</span>' if missing_count > 0 else ''

            hidden_badge = '<span class="conv-hidden-badge">Hidden</span>' if conv.get('is_hidden') else ''

            file_name = conv.get('file_name', f"{conv['safe_name']}.html")

            search_text = conv.get('search_text') or search_text_by_chat.get(conv.get('chat_id'), '')
            if not search_text:
                search_text = search_text_by_file.get(file_name, '')
            html += f'''            <a href="Conversations/{file_name}" class="conversation" data-name="{self._escape_html(conv['display_name'].lower())}" data-preview="{self._escape_html(preview.lower())}" data-search="{self._escape_html(search_text)}">
                <div class="conv-header">
                    <div class="conv-name">{group_icon}{self._escape_html(conv['display_name'])}{count_badge}{missing_badge}{hidden_badge}</div>
                    <div class="conv-date">{timestamp_str}</div>
                </div>
                <div class="conv-preview">{self._escape_html(preview)}</div>
            </a>
'''

        html += '''        </div>  <!-- Close conversationList -->
        <div class="no-results" id="noResults">No conversations found</div>
        <div class="export-info">
            Exported from iOS Backup Manager on ''' + datetime.now().strftime("%B %d, %Y at %I:%M %p") + f'''<br>
            Total conversations: {len(conversations)} | Total messages: {total_messages}
        </div>
    </div>  <!-- Close container -->

    <script>
        function filterConversations() {{
            const input = document.getElementById('searchInput');
            const clearBtn = document.getElementById('clearSearch');
            const rawTerm = input.value.trim();
            const filter = rawTerm.toLowerCase();
            try {{
                if (rawTerm) {{
                    localStorage.setItem('whatsappLastSearch', rawTerm);
                }} else {{
                    localStorage.removeItem('whatsappLastSearch');
                }}
            }} catch (err) {{}}
            const conversations = document.querySelectorAll('.conversation');
            const noResults = document.getElementById('noResults');

            let visibleCount = 0;

            conversations.forEach(conv => {{
                const name = conv.getAttribute('data-name') || '';
                const preview = conv.getAttribute('data-preview') || '';
                const searchText = conv.getAttribute('data-search') || '';
                const link = conv.tagName === 'A' ? conv : conv.querySelector('a');
                if (link) {{
                    if (!link.dataset.baseHref) {{
                        link.dataset.baseHref = link.getAttribute('href');
                    }}
                    if (rawTerm) {{
                        link.setAttribute('href', `${{link.dataset.baseHref}}?q=${{encodeURIComponent(rawTerm)}}`);
                    }} else {{
                        link.setAttribute('href', link.dataset.baseHref);
                    }}
                }}

                if (name.includes(filter) || preview.includes(filter) || searchText.includes(filter)) {{
                    conv.classList.remove('hidden');
                    visibleCount++;
                }} else {{
                    conv.classList.add('hidden');
                }}
            }});

            if (visibleCount === 0 && filter !== '') {{
                noResults.classList.add('visible');
            }} else {{
                noResults.classList.remove('visible');
            }}
            if (clearBtn) {{
                clearBtn.classList.toggle('visible', !!rawTerm);
            }}
        }}

        function applyStoredSearch() {{
            const input = document.getElementById('searchInput');
            if (!input) {{
                return;
            }}
            let saved = '';
            try {{
                saved = localStorage.getItem('whatsappLastSearch') || '';
            }} catch (err) {{}}
            if (saved) {{
                input.value = saved;
                filterConversations();
            }}
        }}

        document.addEventListener('DOMContentLoaded', () => {{
            applyStoredSearch();
            const clearBtn = document.getElementById('clearSearch');
            const input = document.getElementById('searchInput');
            if (clearBtn && input) {{
                clearBtn.addEventListener('click', () => {{
                    input.value = '';
                    try {{
                        localStorage.removeItem('whatsappLastSearch');
                    }} catch (err) {{}}
                    filterConversations();
                    clearBtn.classList.remove('visible');
                    input.focus();
                }});
            }}
        }});

        window.addEventListener('pageshow', () => {{
            const input = document.getElementById('searchInput');
            if (input && input.value.trim()) {{
                filterConversations();
            }}
        }});
    </script>
    <script>
        (function() {{
            try {{
                if (window.parent && window.parent !== window) {{
                    window.parent.postMessage({{type: 'device-nav-root', href: window.location.href}}, '*');
                    window.parent.postMessage({{type: 'device-nav', href: window.location.href}}, '*');
                }}
            }} catch (err) {{}}
        }})();
    </script>
    <script>
        if (window.self !== window.top) {{
            document.body.classList.add('embedded');
        }}
    </script>
</body>
</html>'''

        # Write index file
        with open(index_file, 'w', encoding='utf-8') as f:
            f.write(html)
        self._add_export_bytes(index_file)

        print(f"Created WhatsApp index: {index_file}")
