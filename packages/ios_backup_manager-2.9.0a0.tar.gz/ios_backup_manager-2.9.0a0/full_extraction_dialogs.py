#!/usr/bin/env python3
"""
Full Extraction Dialogs - UI components for full backup extraction.
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import os
import threading
import time
import json
from typing import Dict, Any, Optional
from datetime import datetime

# Import cross-platform utilities
from file_manager import FileManager
from theme_manager import get_theme


class FullExtractionDialog:
    """Dialog for configuring full extraction."""

    def __init__(self, parent, backup, extraction_manager):
        """
        Initialize extraction configuration dialog.

        Args:
            parent: Parent window
            backup: Backup object
            extraction_manager: FullExtractionManager instance (for getting available categories)
        """
        self.parent = parent
        self.backup = backup
        self.manager = extraction_manager
        self.theme = get_theme()  # Initialize theme manager

        self.result = None  # Will be set to dict if user confirms
        self.output_dir = None
        self.selected_categories = []
        self.options = {}
        self.case_info = {}

        # Category checkboxes
        self.category_vars = {}
        self.category_available = {}
        self.select_all_var = tk.BooleanVar(value=False)
        self._categories_frame = None
        self._available_cats = None
        self._counts_button = None
        self._counts_loading = False
        self._scan_token = 0
        self._cancelled_scans = set()
        self._scan_progress = None
        self._scan_cancel_btn = None
        self._scan_controls = None
        self.count_scan_threshold_gb = 5.0

        # Preferences file
        self.preferences_file = os.path.join(os.path.expanduser("~"), ".backup_merger_extract_preferences.json")

        # Default preferences
        self.default_preferences = {
            'convert_heic': True,
            'organize_by_date': True,
            'organize_by_category': True,
            'parallel_mode': True,
            'generate_summary': True,
            'include_cached_thumbnails': False,
            'forensic_mode': False,
            'hash_payloads': False
        }

        # Load saved preferences
        self.preferences = self._load_preferences()

        self._create_dialog()

    def _create_dialog(self):
        """Create the dialog window."""
        self.dialog = tk.Toplevel(self.parent)
        self.dialog.title(f"Extract All Data from {self.backup.name}")
        self.dialog.geometry("600x770")
        self.dialog.resizable(True, True)
        self.dialog.minsize(600, 700)

        # Keep dialog on top of parent (non-modal - allows main window interaction)
        self.dialog.transient(self.parent)
        # Removed grab_set() to allow concurrent operations in main window

        # Center dialog on parent
        self.dialog.update_idletasks()
        x = self.parent.winfo_x() + (self.parent.winfo_width() // 2) - (600 // 2)
        y = self.parent.winfo_y() + (self.parent.winfo_height() // 2) - (770 // 2)
        self.dialog.geometry(f"+{x}+{y}")

        # Main container
        main_frame = ttk.Frame(self.dialog, padding="16")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Title
        title_label = tk.Label(
            main_frame,
            text="Select Categories to Extract",
            font=("Arial", 14, "bold")
        )
        title_label.pack(anchor='w', pady=(0, 15))

        # Category selection frame (scrollable)
        cat_frame = ttk.LabelFrame(main_frame, text="Data Categories", padding="10")
        cat_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 15))

        # Create canvas for scrolling
        canvas = tk.Canvas(cat_frame, height=190)
        scrollbar = ttk.Scrollbar(cat_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        def _sync_select_all():
            available_vars = [
                var for cat_id, var in self.category_vars.items()
                if self.category_available.get(cat_id)
            ]
            if not available_vars:
                self.select_all_var.set(False)
                return
            self.select_all_var.set(all(var.get() for var in available_vars))

        def _set_all_categories():
            target = self.select_all_var.get()
            for cat_id, var in self.category_vars.items():
                if self.category_available.get(cat_id):
                    var.set(target)
            _sync_select_all()

        select_all_cb = ttk.Checkbutton(
            scrollable_frame,
            text="Select/Deselect All",
            variable=self.select_all_var,
            command=_set_all_categories
        )
        select_all_cb.pack(anchor='w', pady=(0, 6))

        # Load categories asynchronously to avoid UI blocking
        self._categories_frame = scrollable_frame
        loading_label = tk.Label(scrollable_frame, text="Loading categories...", font=("Arial", 10), fg="#666")
        loading_label.pack(anchor='w', pady=10)
        self._start_load_categories()

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Options frame
        options_frame = ttk.LabelFrame(main_frame, text="Options", padding="10")
        options_frame.pack(fill=tk.X, pady=(0, 15))

        # Use saved preferences for checkbox values
        self.convert_heic_var = tk.BooleanVar(value=self.preferences.get('convert_heic', True))
        convert_heic_cb = ttk.Checkbutton(
            options_frame,
            text="Convert HEIC photos to JPG",
            variable=self.convert_heic_var
        )
        convert_heic_cb.pack(anchor='w', pady=3)

        self.organize_by_date_var = tk.BooleanVar(value=self.preferences.get('organize_by_date', True))
        organize_by_date_cb = ttk.Checkbutton(
            options_frame,
            text="Organize photos by date (Year/Month)",
            variable=self.organize_by_date_var
        )
        organize_by_date_cb.pack(anchor='w', pady=3)

        self.organize_var = tk.BooleanVar(value=self.preferences.get('organize_by_category', True))
        organize_cb = ttk.Checkbutton(
            options_frame,
            text="Organize by category (create subfolders)",
            variable=self.organize_var
        )
        organize_cb.pack(anchor='w', pady=3)

        self.parallel_mode_var = tk.BooleanVar(value=self.preferences.get('parallel_mode', True))
        parallel_cb = ttk.Checkbutton(
            options_frame,
            text="⚡ Enable parallel extraction (faster)",
            variable=self.parallel_mode_var
        )
        parallel_cb.pack(anchor='w', pady=3)

        self.generate_summary_var = tk.BooleanVar(value=self.preferences.get('generate_summary', True))
        self.include_cached_thumbnails_var = tk.BooleanVar(
            value=self.preferences.get('include_cached_thumbnails', False)
        )
        summary_row = ttk.Frame(options_frame)
        summary_row.pack(fill=tk.X, pady=3)
        generate_summary_cb = ttk.Checkbutton(
            summary_row,
            text="Generate extraction summary",
            variable=self.generate_summary_var
        )
        generate_summary_cb.pack(side='left', padx=(0, 12))
        cached_thumbs_cb = ttk.Checkbutton(
            summary_row,
            text="Include cached thumbnails (Photos)",
            variable=self.include_cached_thumbnails_var
        )
        cached_thumbs_cb.pack(side='left')

        self.forensic_mode_var = tk.BooleanVar(value=self.preferences.get('forensic_mode', False))
        forensic_mode_cb = ttk.Checkbutton(
            options_frame,
            text="Forensic Mode (enhanced audit + report hashing)",
            variable=self.forensic_mode_var
        )
        forensic_mode_cb.pack(anchor='w', pady=3)

        self.hash_payloads_var = tk.BooleanVar(value=self.preferences.get('hash_payloads', False))
        hash_payloads_cb = ttk.Checkbutton(
            options_frame,
            text="Hash extracted payloads (forensic only)",
            variable=self.hash_payloads_var
        )
        hash_payloads_cb.pack(anchor='w', pady=3)

        def _sync_forensic_controls():
            if self.forensic_mode_var.get():
                hash_payloads_cb.state(["!disabled"])
            else:
                self.hash_payloads_var.set(False)
                hash_payloads_cb.state(["disabled"])

        self.forensic_mode_var.trace_add("write", lambda *args: _sync_forensic_controls())
        _sync_forensic_controls()

        case_btn = ttk.Button(
            options_frame,
            text="Case info...",
            command=self._open_case_info_dialog
        )
        case_btn.pack(anchor='w', pady=(6, 0))

        # Output directory selection
        output_frame = ttk.LabelFrame(main_frame, text="Output Directory", padding="10")
        output_frame.pack(fill=tk.X, pady=(0, 15))

        # Default output directory - Try to parse backup path for smart prepopulation
        default_dir = self._get_smart_output_directory()
        self.output_dir = default_dir

        self.output_var = tk.StringVar(value=default_dir)

        output_entry_frame = ttk.Frame(output_frame)
        output_entry_frame.pack(fill=tk.X)

        output_entry = ttk.Entry(output_entry_frame, textvariable=self.output_var)
        output_entry.pack(side='left', fill=tk.X, expand=True, padx=(0, 5))

        browse_btn = ttk.Button(
            output_entry_frame,
            text="Browse...",
            command=self._browse_output
        )
        browse_btn.pack(side='right')

        # Estimates frame
        estimates_frame = ttk.Frame(main_frame)
        estimates_frame.pack(fill=tk.X, pady=(0, 15))

        self.estimate_label = tk.Label(
            estimates_frame,
            text="Calculating estimates...",
            font=("Arial", 9),
            fg="#666"
        )
        self.estimate_label.pack(anchor='w')
        self._scan_controls = ttk.Frame(estimates_frame)
        self._scan_controls.pack(fill=tk.X, pady=(6, 0))

        self._scan_controls.columnconfigure(0, weight=1)
        self._scan_controls.columnconfigure(1, weight=0)
        self._scan_progress = ttk.Progressbar(self._scan_controls, mode="indeterminate")
        self._scan_progress.grid(row=0, column=0, sticky="we")
        self._scan_progress.grid_remove()

        self._scan_cancel_btn = ttk.Button(
            self._scan_controls,
            text="Cancel scan",
            command=self._cancel_category_scan
        )
        self._scan_cancel_btn.grid(row=0, column=1, padx=(8, 0), sticky="e")
        self._scan_cancel_btn.grid_remove()

        self._counts_button = ttk.Button(
            self._scan_controls,
            text="Refresh counts (full scan)",
            command=lambda: self._start_load_categories(force_full=True)
        )
        self._counts_button.grid(row=0, column=0, columnspan=2, sticky="w")

        # Buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X)

        # Restore Defaults button on the left
        restore_defaults_btn = ttk.Button(
            button_frame,
            text="Restore Defaults",
            command=self._restore_defaults
        )
        restore_defaults_btn.pack(side='left')

        # Cancel and Extract buttons on the right
        cancel_btn = ttk.Button(
            button_frame,
            text="Cancel",
            command=self._cancel
        )
        cancel_btn.pack(side='right', padx=(5, 0))

        extract_btn = ttk.Button(
            button_frame,
            text="Start Extraction",
            command=self._start_extraction,
            style='Accent.TButton'
        )
        extract_btn.pack(side='right')

    def _parse_backup_path(self, backup_path):
        """
        Parse backup path to extract Backup Location and Backup Name.

        Returns:
            tuple: (backup_location, backup_name, has_itunes_subfolder)
        """
        if not backup_path:
            return (None, None, False)

        # Normalize path
        path = os.path.normpath(backup_path)
        parts = path.split(os.sep)

        if len(parts) < 2:
            return (None, None, False)

        # Find UDID (last component)
        udid = parts[-1]

        # Pattern 1: ...\{name}\iTunes Backup\{udid}
        if len(parts) >= 3 and parts[-2] == "iTunes Backup":
            backup_name = parts[-3]
            backup_location = self._rejoin_path(parts[:-3])
            return (backup_location, backup_name, True)

        # Pattern 2: ...\{name}\{udid} (check if parent is likely a Backup Name)
        elif len(parts) >= 2:
            potential_name = parts[-2]
            # If parent is NOT "iTunes Backup" and looks like a custom name
            if potential_name != "iTunes Backup" and self._is_likely_backup_name(potential_name):
                backup_name = potential_name
                backup_location = self._rejoin_path(parts[:-2])
                return (backup_location, backup_name, False)

        # Pattern 3: ...\{udid} (no Backup Name detected)
        return (self._rejoin_path(parts[:-1]), None, False)

    def _rejoin_path(self, parts):
        """
        Rejoin path parts, handling drive letters correctly on Windows.

        Args:
            parts: List of path components

        Returns:
            Properly formatted path string
        """
        if not parts:
            return None

        # Single component
        if len(parts) == 1:
            # Check if it's a drive letter
            if len(parts[0]) == 2 and parts[0][1] == ':':
                # Drive letter - add backslash
                return parts[0] + os.sep
            return parts[0]

        # Multiple components - check if first is a drive letter
        if len(parts[0]) == 2 and parts[0][1] == ':':
            # First component is drive letter - add backslash before joining
            parts[0] = parts[0] + os.sep

        # Use os.path.join
        return os.path.join(*parts)

    def _is_likely_backup_name(self, name):
        """Check if folder name looks like a custom Backup Name vs generic path."""
        # Avoid generic folder names
        generic_names = ["iTunes", "Backup", "Backups", "Apple", "MobileSync", "iTunes Backup"]
        if name in generic_names:
            return False
        # Must be reasonable length
        if len(name) > 50 or len(name) == 0:
            return False
        return True

    def _get_smart_output_directory(self):
        """
        Get smart default output directory based on backup path structure.

        If backup follows the pattern {base}\{name}\iTunes Backup\{udid},
        prepopulate with {base}\{name}\Recovered Files
        """
        try:
            # Get backup path
            backup_path = self.backup.path if hasattr(self.backup, 'path') else None
            if not backup_path:
                # Fallback to default
                return os.path.join(
                    os.path.expanduser("~"),
                    "Documents",
                    f"{self.backup.name}_Export_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                )

            # Parse the backup path
            backup_location, backup_name, has_itunes_subfolder = self._parse_backup_path(backup_path)

            if backup_location and backup_name:
                # Use: {backup_location}\{backup_name}\Recovered Files
                return os.path.join(backup_location, backup_name, "Recovered Files")
            elif backup_location:
                # Use parent of backup with Recovered Files
                return os.path.join(backup_location, "Recovered Files")
            else:
                # Fallback to default
                return os.path.join(
                    os.path.expanduser("~"),
                    "Documents",
                    f"{self.backup.name}_Export_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                )

        except Exception as e:
            # On any error, fall back to default
            print(f"[DEBUG] Error getting smart output directory: {e}")
            return os.path.join(
                os.path.expanduser("~"),
                "Documents",
                f"{self.backup.name}_Export_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            )

    def _browse_output(self):
        """Browse for output directory."""
        directory = filedialog.askdirectory(
            parent=self.dialog,
            title="Select Output Directory",
            initialdir=os.path.dirname(self.output_var.get())
        )

        if directory:
            self.output_var.set(directory)
            self.output_dir = directory

    def _start_load_categories(self, force_full: bool = False):
        if self._counts_loading:
            return
        self._counts_loading = True
        self._scan_token += 1
        token = self._scan_token
        if self._counts_button:
            self._counts_button.state(["disabled"])
            self._counts_button.grid_remove()
        if self._scan_progress:
            self._scan_progress.grid()
            self._scan_progress.start(10)
        if self._scan_cancel_btn:
            self._scan_cancel_btn.grid()
        if force_full:
            self._safe_update_estimate(text="Running full scan... this can take several minutes.")
        else:
            self._safe_update_estimate(text="Loading categories...")
        threading.Thread(target=self._load_categories, kwargs={"force_full": force_full, "token": token}, daemon=True).start()

    def _load_categories(self, force_full: bool = False, token: Optional[int] = None):
        """Load available categories in the background."""
        try:
            fast_mode = self._should_fast_scan(force_full=force_full)
            available_cats = self.manager.get_available_categories(fast_mode=fast_mode)
            error = None
        except Exception as e:
            available_cats = {}
            error = e
        self._available_cats = available_cats if not error else None

        def _apply():
            if not self.dialog.winfo_exists():
                return
            if token is not None and token in self._cancelled_scans:
                return
            self._counts_loading = False
            if self._scan_progress:
                self._scan_progress.stop()
                self._scan_progress.grid_remove()
            if self._scan_cancel_btn:
                self._scan_cancel_btn.grid_remove()
            if self._counts_button:
                self._counts_button.state(["!disabled"])
                self._counts_button.configure(text="Refresh counts (full scan)")
                self._counts_button.grid()
            self._populate_categories(available_cats, error)

        self.dialog.after(0, _apply)
    
    def _should_fast_scan(self, force_full: bool = False) -> bool:
        if force_full:
            return False
        if getattr(self.backup, "is_encrypted", False):
            return True
        size_gb = getattr(self.backup, "size_gb_validated", None)
        if size_gb is None:
            size_gb = getattr(self.backup, "size_gb", 0) or 0
        if size_gb <= 0:
            return True
        return size_gb > self.count_scan_threshold_gb

    def _cancel_category_scan(self):
        token = self._scan_token
        self._cancelled_scans.add(token)
        self._counts_loading = False
        if self._scan_progress:
            self._scan_progress.stop()
            self._scan_progress.grid_remove()
        if self._scan_cancel_btn:
            self._scan_cancel_btn.grid_remove()
        if self._counts_button:
            self._counts_button.state(["!disabled"])
            self._counts_button.configure(text="Refresh counts (full scan)")
            self._counts_button.grid()
        self._safe_update_estimate(text="Scan cancelled.")

    def _populate_categories(self, available_cats, error=None):
        if not self._categories_frame:
            return

        for child in self._categories_frame.winfo_children():
            child.destroy()

        if error:
            tk.Label(
                self._categories_frame,
                text=f"Unable to load categories: {error}",
                font=("Arial", 10),
                fg="#a00"
            ).pack(anchor='w', pady=10)
            return

        def _sync_select_all():
            available_vars = [
                var for cat_id, var in self.category_vars.items()
                if self.category_available.get(cat_id)
            ]
            if not available_vars:
                self.select_all_var.set(False)
                return
            self.select_all_var.set(all(var.get() for var in available_vars))

        def _set_all_categories():
            target = self.select_all_var.get()
            for cat_id, var in self.category_vars.items():
                if self.category_available.get(cat_id):
                    var.set(target)
            _sync_select_all()

        select_all_cb = ttk.Checkbutton(
            self._categories_frame,
            text="Select/Deselect All",
            variable=self.select_all_var,
            command=_set_all_categories
        )
        select_all_cb.pack(anchor='w', pady=(0, 6))

        # Add categories
        for cat_id, cat_info in available_cats.items():
            emoji = cat_info['emoji']
            name = cat_info['display_name']
            count = cat_info['count']
            available = cat_info['available']

            var = tk.BooleanVar(value=available)  # Check by default if available
            self.category_vars[cat_id] = var
            self.category_available[cat_id] = available

            if available:
                if count is None:
                    label = f"{emoji} {name} (count pending)"
                else:
                    label = f"{emoji} {name} ({count:,} items)"
            else:
                label = f"{emoji} {name} (Not available)"

            cb = ttk.Checkbutton(
                self._categories_frame,
                text=label,
                variable=var,
                state='normal' if available else 'disabled',
                command=_sync_select_all
            )
            cb.pack(anchor='w', pady=3)

        _sync_select_all()

        # Calculate estimates in background
        threading.Thread(target=self._calculate_estimates, daemon=True).start()

    def _calculate_estimates(self):
        """Calculate size and time estimates (background thread)."""
        try:
            # Get selected categories
            selected = [cat_id for cat_id, var in self.category_vars.items() if var.get()]

            if not selected:
                self._safe_update_estimate(text="No categories selected")
                return

            available_cats = self._available_cats or {}
            if not available_cats:
                self._safe_update_estimate(text="Unable to calculate estimates")
                return
            total_items = 0
            pending_counts = False
            for cat_id in selected:
                info = available_cats.get(cat_id)
                if not info or not info.get('available'):
                    continue
                count = info.get('count')
                if count is None:
                    pending_counts = True
                    continue
                total_items += count

            if pending_counts:
                if total_items > 0:
                    estimate_text = (
                        f"Estimated: >= {total_items:,} items (some counts pending). "
                        "Run a full scan for a more accurate estimate."
                    )
                else:
                    estimate_text = "Estimated: counts pending. Run a full scan for a more accurate estimate."
                self._safe_update_estimate(text=estimate_text)
                return

            # Rough time estimate (varies by category, but ~1000 items/minute is reasonable)
            estimated_minutes = max(1, total_items // 1000)

            estimate_text = f"Estimated: ~{total_items:,} items"
            if estimated_minutes < 60:
                estimate_text += f" • ~{estimated_minutes} minute{'s' if estimated_minutes != 1 else ''}"
            else:
                hours = estimated_minutes // 60
                mins = estimated_minutes % 60
                estimate_text += f" • ~{hours}h {mins}m"

            self._safe_update_estimate(text=estimate_text)

        except Exception as e:
            print(f"[DEBUG] Error calculating estimates: {e}")
            self._safe_update_estimate(text="Unable to calculate estimates")

    def _start_extraction(self):
        """Start extraction - validate and close dialog."""
        # Get selected categories
        selected = [cat_id for cat_id, var in self.category_vars.items() if var.get()]

        if not selected:
            messagebox.showwarning(
                "No Categories Selected",
                "Please select at least one category to extract.",
                parent=self.dialog
            )
            return

        # Get output directory
        output_dir = self.output_var.get()
        if not output_dir:
            messagebox.showwarning(
                "No Output Directory",
                "Please select an output directory.",
                parent=self.dialog
            )
            return

        # Confirm if directory exists and has files
        if os.path.exists(output_dir) and os.listdir(output_dir):
            confirm = messagebox.askyesno(
                "Directory Not Empty",
                f"The directory already exists and contains files:\n{output_dir}\n\n"
                "Extraction will add files to this directory. Continue?",
                parent=self.dialog
            )
            if not confirm:
                return

        # Set results
        self.output_dir = output_dir
        self.selected_categories = selected
        self.options = {
            'convert_heic': self.convert_heic_var.get(),
            'organize_by_date': self.organize_by_date_var.get(),
            'organize_by_category': self.organize_var.get(),
            'parallel_mode': self.parallel_mode_var.get(),
            'generate_summary': self.generate_summary_var.get(),
            'include_cached_thumbnails': self.include_cached_thumbnails_var.get(),
            'audit_mode': 'forensic' if self.forensic_mode_var.get() else 'minimal',
            'audit_verbose': False,
            'audit_hash_reports': bool(self.forensic_mode_var.get()),
            'audit_hash_payloads': bool(self.forensic_mode_var.get() and self.hash_payloads_var.get()),
            'case_info': self.case_info
        }

        self.result = {
            'output_dir': self.output_dir,
            'categories': self.selected_categories,
            'options': self.options
        }

        # Save preferences for next time
        self._save_preferences()

        self.dialog.destroy()

    def _safe_update_estimate(self, text: str):
        """Update estimate label safely if dialog is still alive."""
        def _apply():
            if not self.dialog.winfo_exists():
                return
            try:
                self.estimate_label.config(text=text)
            except tk.TclError:
                pass
        try:
            self.dialog.after(0, _apply)
        except tk.TclError:
            pass

    def _cancel(self):
        """Cancel dialog."""
        self.result = None
        self.dialog.destroy()

    def _open_case_info_dialog(self):
        dialog = tk.Toplevel(self.dialog)
        dialog.title("Case Information (Optional)")
        dialog.geometry("420x320")
        dialog.resizable(True, True)
        dialog.transient(self.dialog)

        frame = ttk.Frame(dialog, padding="14")
        frame.pack(fill=tk.BOTH, expand=True)

        fields = [
            ("Case Number", "case_number"),
            ("Evidence Number", "evidence_number"),
            ("Examiner", "examiner"),
            ("Department", "department"),
            ("Location", "location"),
        ]
        entries = {}

        for label_text, key in fields:
            row = ttk.Frame(frame)
            row.pack(fill=tk.X, pady=4)
            label = ttk.Label(row, text=label_text, width=18)
            label.pack(side=tk.LEFT)
            entry = ttk.Entry(row)
            entry.insert(0, self.case_info.get(key, ""))
            entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
            entries[key] = entry

        def _save():
            case_info = {}
            for key, entry in entries.items():
                value = entry.get().strip()
                if value:
                    case_info[key] = value
            self.case_info = case_info
            dialog.destroy()

        def _clear():
            for entry in entries.values():
                entry.delete(0, tk.END)
            self.case_info = {}

        button_row = ttk.Frame(frame)
        button_row.pack(fill=tk.X, pady=(12, 0))
        ttk.Button(button_row, text="Clear", command=_clear).pack(side=tk.LEFT)
        ttk.Button(button_row, text="Save", command=_save).pack(side=tk.RIGHT)

        dialog.update_idletasks()
        x = self.dialog.winfo_x() + (self.dialog.winfo_width() // 2) - (dialog.winfo_width() // 2)
        y = self.dialog.winfo_y() + (self.dialog.winfo_height() // 2) - (dialog.winfo_height() // 2)
        dialog.geometry(f"+{x}+{y}")

    def _load_preferences(self) -> Dict[str, bool]:
        """Load saved preferences from JSON file."""
        try:
            if os.path.exists(self.preferences_file):
                with open(self.preferences_file, 'r') as f:
                    saved_prefs = json.load(f)
                    # Merge with defaults to handle new preferences added in updates
                    return {**self.default_preferences, **saved_prefs}
        except Exception as e:
            print(f"[DEBUG] Failed to load preferences: {e}")
        return self.default_preferences.copy()

    def _save_preferences(self):
        """Save current checkbox states to preferences file."""
        try:
            preferences = {
                'convert_heic': self.convert_heic_var.get(),
                'organize_by_date': self.organize_by_date_var.get(),
                'organize_by_category': self.organize_var.get(),
                'parallel_mode': self.parallel_mode_var.get(),
                'generate_summary': self.generate_summary_var.get(),
                'include_cached_thumbnails': self.include_cached_thumbnails_var.get(),
                'forensic_mode': self.forensic_mode_var.get(),
                'hash_payloads': self.hash_payloads_var.get()
            }
            with open(self.preferences_file, 'w') as f:
                json.dump(preferences, f, indent=2)
        except Exception as e:
            print(f"[DEBUG] Failed to save preferences: {e}")

    def _restore_defaults(self):
        """Restore all options to default values."""
        self.convert_heic_var.set(self.default_preferences['convert_heic'])
        self.organize_by_date_var.set(self.default_preferences['organize_by_date'])
        self.organize_var.set(self.default_preferences['organize_by_category'])
        self.parallel_mode_var.set(self.default_preferences['parallel_mode'])
        self.generate_summary_var.set(self.default_preferences['generate_summary'])
        self.include_cached_thumbnails_var.set(self.default_preferences['include_cached_thumbnails'])
        self.forensic_mode_var.set(self.default_preferences['forensic_mode'])
        self.hash_payloads_var.set(self.default_preferences['hash_payloads'])


class FullExtractionProgressDialog:
    """Progress dialog for full extraction with multi-level tracking."""

    def __init__(self, parent, extraction_manager, device_name):
        """
        Initialize progress dialog.

        Args:
            parent: Parent window
            extraction_manager: FullExtractionManager instance
            device_name: Device name for title
        """
        self.parent = parent
        self.manager = extraction_manager
        self.device_name = device_name
        self.theme = get_theme()  # Initialize theme manager

        self.cancelled = False
        self.completed = False
        self.start_time = None
        self.summary = None

        # Progress tracking
        self.completed_categories = []
        self.current_category = None

        self._create_dialog()

    def _create_dialog(self):
        """Create progress dialog window."""
        self.dialog = tk.Toplevel(self.parent)
        self.dialog.title(f"Extracting Data from {self.device_name}")
        self.dialog.geometry("650x500")
        self.dialog.resizable(True, True)

        # Keep dialog on top of parent (non-modal - allows main window interaction)
        self.dialog.transient(self.parent)
        # Removed grab_set() to allow concurrent operations in main window

        # Center on parent
        self.dialog.update_idletasks()
        x = self.parent.winfo_x() + (self.parent.winfo_width() // 2) - (650 // 2)
        y = self.parent.winfo_y() + (self.parent.winfo_height() // 2) - (500 // 2)
        self.dialog.geometry(f"+{x}+{y}")

        # Prevent closing during extraction
        self.dialog.protocol("WM_DELETE_WINDOW", self._on_close)

        # Main frame
        main_frame = ttk.Frame(self.dialog, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Overall progress section
        overall_label = tk.Label(
            main_frame,
            text="Overall Progress:",
            font=("Arial", 11, "bold")
        )
        overall_label.pack(anchor='w', pady=(0, 5))

        self.overall_text = tk.Label(
            main_frame,
            text="Starting extraction...",
            font=("Arial", 10)
        )
        self.overall_text.pack(anchor='w', pady=(0, 5))

        self.overall_progress = ttk.Progressbar(
            main_frame,
            mode='determinate',
            length=600
        )
        self.overall_progress.pack(fill=tk.X, pady=(0, 20))

        # Current category section
        current_label = tk.Label(
            main_frame,
            text="Current Category:",
            font=("Arial", 11, "bold")
        )
        current_label.pack(anchor='w', pady=(0, 5))

        self.current_text = tk.Label(
            main_frame,
            text="—",
            font=("Arial", 10)
        )
        self.current_text.pack(anchor='w', pady=(0, 5))

        self.current_progress = ttk.Progressbar(
            main_frame,
            mode='determinate',
            length=600
        )
        self.current_progress.pack(fill=tk.X, pady=(0, 5))

        self.item_text = tk.Label(
            main_frame,
            text="",
            font=("Arial", 9),
            fg="#666"
        )
        self.item_text.pack(anchor='w', pady=(0, 20))

        # Completed categories section
        completed_label = tk.Label(
            main_frame,
            text="Completed:",
            font=("Arial", 11, "bold")
        )
        completed_label.pack(anchor='w', pady=(0, 5))

        # Scrollable completed list
        completed_frame = ttk.Frame(main_frame)
        completed_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 15))

        self.completed_text = tk.Text(
            completed_frame,
            height=8,
            width=70,
            wrap='word',
            font=("Arial", 9),
            state='disabled',
            bg='#f0f0f0'
        )
        completed_scrollbar = ttk.Scrollbar(completed_frame, command=self.completed_text.yview)
        self.completed_text.configure(yscrollcommand=completed_scrollbar.set)

        self.completed_text.pack(side='left', fill=tk.BOTH, expand=True)
        completed_scrollbar.pack(side='right', fill='y')

        # ETA
        self.eta_label = tk.Label(
            main_frame,
            text="Calculating time remaining...",
            font=("Arial", 9),
            fg="#666"
        )
        self.eta_label.pack(anchor='w', pady=(0, 15))

        # Cancel button
        self.cancel_btn = ttk.Button(
            main_frame,
            text="Cancel",
            command=self._cancel
        )
        self.cancel_btn.pack(side='right')

    def start(self):
        """Start extraction in background thread."""
        self.start_time = time.time()

        # Run extraction in background thread
        thread = threading.Thread(target=self._run_extraction, daemon=True)
        thread.start()

    def _run_extraction(self):
        """Run extraction (background thread)."""
        try:
            self.summary = self.manager.extract_all(progress_callback=self._update_progress)
            self.completed = True
            self.dialog.after(0, self._on_complete)
        except Exception as e:
            print(f"[ERROR] Extraction failed: {e}")
            import traceback
            traceback.print_exc()
            self.dialog.after(0, lambda: self._on_error(str(e)))

    def _update_progress(self, progress: Dict[str, Any]):
        """Update progress display (called from background thread)."""
        self.dialog.after(0, lambda: self._update_ui(progress))

    def _update_ui(self, progress: Dict[str, Any]):
        """Update UI with progress (main thread)."""
        try:
            overall_current = progress.get('overall_current', 0)
            overall_total = progress.get('overall_total', 1)
            category = progress.get('category', '')
            emoji = progress.get('emoji', '')
            item_current = progress.get('item_current', 0)
            item_total = progress.get('item_total', 0)
            item_name = progress.get('item_name', '')
            status = progress.get('status', 'extracting')

            # Update overall progress
            overall_pct = (overall_current / overall_total * 100) if overall_total > 0 else 0
            self.overall_progress['value'] = overall_pct
            self.overall_text.config(text=f"{overall_current} of {overall_total} categories")

            # Update current category
            if status == 'extracting':
                self.current_text.config(text=f"{emoji} {category}")

                if item_total > 0:
                    item_pct = (item_current / item_total * 100)
                    self.current_progress['value'] = item_pct

                    if item_name:
                        # Truncate long item names
                        display_name = item_name if len(item_name) <= 60 else item_name[:57] + "..."
                        self.item_text.config(text=f"{item_current:,} of {item_total:,}: {display_name}")
                    else:
                        self.item_text.config(text=f"{item_current:,} of {item_total:,} items")
                else:
                    self.current_progress['value'] = 0
                    self.item_text.config(text="Preparing...")

            elif status in ('completed', 'skipped', 'failed'):
                # Add to completed list
                if progress.get('category_id') not in [c['id'] for c in self.completed_categories]:
                    self.completed_categories.append({
                        'id': progress.get('category_id'),
                        'name': category,
                        'emoji': emoji,
                        'status': status,
                        'count': item_current
                    })

                    # Update completed text
                    self.completed_text.config(state='normal')
                    if status == 'completed':
                        self.completed_text.insert('end', f"✓ {emoji} {category} ({item_current:,} items)\n")
                    elif status == 'skipped':
                        self.completed_text.insert('end', f"⚠ {emoji} {category} (Not available)\n")
                    elif status == 'failed':
                        self.completed_text.insert('end', f"✗ {emoji} {category} (Failed: {item_name})\n")
                    self.completed_text.see('end')
                    self.completed_text.config(state='disabled')

            # Update ETA
            if self.start_time and overall_current > 0:
                elapsed = time.time() - self.start_time
                rate = overall_current / elapsed
                remaining_categories = overall_total - overall_current

                if rate > 0:
                    eta_seconds = remaining_categories / rate
                    eta_text = self._format_duration(eta_seconds)
                    self.eta_label.config(text=f"Estimated time remaining: {eta_text}")

        except Exception as e:
            print(f"[DEBUG] Error updating UI: {e}")

    def _on_complete(self):
        """Handle extraction completion."""
        self.cancel_btn.config(text="Close")

        # Show completion summary dialog
        self._show_summary()

    def _on_error(self, error: str):
        """Handle extraction error."""
        messagebox.showerror(
            "Extraction Error",
            f"An error occurred during extraction:\n\n{error}",
            parent=self.dialog
        )
        self.dialog.destroy()

    def _show_summary(self):
        """Show extraction summary dialog."""
        summary = self.summary
        if not summary:
            self.dialog.destroy()
            return

        # Create summary dialog
        summary_dialog = tk.Toplevel(self.dialog)
        summary_dialog.title("Extraction Complete")
        summary_dialog.geometry("550x650")
        summary_dialog.resizable(True, True)
        summary_dialog.transient(self.dialog)

        # Center on parent dialog
        summary_dialog.update_idletasks()
        x = self.dialog.winfo_x() + (self.dialog.winfo_width() // 2) - (550 // 2)
        y = self.dialog.winfo_y() + (self.dialog.winfo_height() // 2) - (650 // 2)
        summary_dialog.geometry(f"+{x}+{y}")

        main_frame = ttk.Frame(summary_dialog, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Title
        title = tk.Label(
            main_frame,
            text="✓ Extraction Complete!" if not summary['cancelled'] else "Extraction Cancelled",
            font=("Arial", 16, "bold"),
            fg="#27ae60" if not summary['cancelled'] else "#e67e22"
        )
        title.pack(pady=(0, 15))

        # Summary stats
        stats_frame = ttk.Frame(main_frame)
        stats_frame.pack(fill=tk.X, pady=(0, 15))

        tk.Label(
            stats_frame,
            text=f"Successfully extracted data from {self.device_name}",
            font=("Arial", 10)
        ).pack(anchor='w', pady=2)

        tk.Label(
            stats_frame,
            text=f"Total items extracted: {summary['total_items']:,}",
            font=("Arial", 10, "bold")
        ).pack(anchor='w', pady=2)

        tk.Label(
            stats_frame,
            text=f"Duration: {self._format_duration(summary['duration'])}",
            font=("Arial", 9),
            fg="#666"
        ).pack(anchor='w', pady=2)

        # Results list
        results_label = tk.Label(
            main_frame,
            text="Results:",
            font=("Arial", 11, "bold")
        )
        results_label.pack(anchor='w', pady=(10, 5))

        results_text = tk.Text(
            main_frame,
            height=15,
            width=65,
            wrap='word',
            font=("Arial", 9),
            bg='#f0f0f0'
        )
        results_scroll = ttk.Scrollbar(main_frame, command=results_text.yview)
        results_text.configure(yscrollcommand=results_scroll.set)

        # Add results
        for cat_id, result in summary['results'].items():
            emoji = self.manager.CATEGORY_REGISTRY.get(cat_id, ('', '', '', ''))[1]
            name = self.manager.CATEGORY_REGISTRY.get(cat_id, ('', '', '', ''))[0]
            status = result['status']
            count = result.get('count', 0)

            if status == 'success':
                results_text.insert('end', f"✓ {emoji} {name}: {count:,} items\n", 'success')
            elif status == 'skipped':
                error = result.get('error', 'Unknown')
                results_text.insert('end', f"⚠ {emoji} {name}: {error}\n", 'warning')
            elif status == 'failed':
                error = result.get('error', 'Unknown error')
                results_text.insert('end', f"✗ {emoji} {name}: Failed ({error})\n", 'error')

        results_text.config(state='disabled')
        results_text.pack(side='left', fill=tk.BOTH, expand=True, pady=(0, 15))
        results_scroll.pack(side='right', fill='y', pady=(0, 15))

        # Output location
        output_frame = ttk.Frame(main_frame)
        output_frame.pack(fill=tk.X, pady=(0, 15))

        tk.Label(
            output_frame,
            text="Output location:",
            font=("Arial", 9),
            fg="#666"
        ).pack(anchor='w')

        tk.Label(
            output_frame,
            text=summary['output_dir'],
            font=("Arial", 9, "bold")
        ).pack(anchor='w')

        # Buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=(10, 0))

        ttk.Button(
            button_frame,
            text="Close",
            command=lambda: [summary_dialog.destroy(), self.dialog.destroy()],
            width=15
        ).pack(side='right', padx=(5, 0))

        ttk.Button(
            button_frame,
            text="Open Folder",
            command=lambda: self._open_output_folder(summary['output_dir']),
            width=15
        ).pack(side='right')

    def _open_output_folder(self, path: str):
        """Open output folder in file explorer."""
        try:
            FileManager.open_folder(path)
        except Exception as e:
            print(f"[ERROR] Failed to open folder: {e}")
            messagebox.showerror(
                "Error",
                f"Failed to open folder:\n{e}",
                parent=self.dialog
            )

    def _format_duration(self, seconds: float) -> str:
        """Format duration for display."""
        if seconds < 60:
            return f"{int(seconds)}s"
        elif seconds < 3600:
            mins = int(seconds // 60)
            secs = int(seconds % 60)
            return f"{mins}m {secs}s"
        else:
            hours = int(seconds // 3600)
            mins = int((seconds % 3600) // 60)
            return f"{hours}h {mins}m"

    def _cancel(self):
        """Cancel extraction."""
        if self.completed:
            self.dialog.destroy()
            return

        confirm = messagebox.askyesno(
            "Cancel Extraction",
            "Are you sure you want to cancel the extraction?\n\n"
            "Partial results will be preserved.",
            parent=self.dialog
        )

        if confirm:
            self.cancelled = True
            self.manager.cancel()
            self.cancel_btn.config(state='disabled', text="Cancelling...")

    def _on_close(self):
        """Handle window close button."""
        if self.completed:
            self.dialog.destroy()
        else:
            self._cancel()


class ParallelExtractionProgressDialog:
    """Progress dialog for parallel extraction with per-category progress bars."""

    def __init__(self, parent, extraction_manager, device_name):
        """
        Initialize parallel extraction progress dialog.

        Args:
            parent: Parent window
            extraction_manager: FullExtractionManager instance
            device_name: Device name for title
        """
        self.parent = parent
        self.manager = extraction_manager
        self.device_name = device_name
        self.theme = get_theme()  # Initialize theme manager

        self.cancelled = False
        self.completed = False
        self.start_time = None
        self.summary = None

        # Progress tracking
        self.category_widgets = {}  # category_id -> widget dict
        self.category_states = {}   # category_id -> progress state

        # UI update throttling (limit to 20 updates per second)
        self.last_ui_update = 0
        self.ui_update_interval = 0.05  # 50ms = 20 updates/second
        self.pending_ui_update = None

        self._create_dialog()

    def _create_dialog(self):
        """Create parallel progress dialog window."""
        self.dialog = tk.Toplevel(self.parent)
        self.dialog.title(f"Extracting Data from {self.device_name}")
        self.dialog.geometry("750x850")
        self.dialog.resizable(True, True)

        # Keep dialog on top of parent (non-modal - allows main window interaction)
        self.dialog.transient(self.parent)
        # Removed grab_set() to allow concurrent operations in main window

        # Center on parent
        self.dialog.update_idletasks()
        x = self.parent.winfo_x() + (self.parent.winfo_width() // 2) - (750 // 2)
        y = self.parent.winfo_y() + (self.parent.winfo_height() // 2) - (850 // 2)
        self.dialog.geometry(f"+{x}+{y}")

        # Prevent closing during extraction
        self.dialog.protocol("WM_DELETE_WINDOW", self._on_close)

        # Main frame
        main_frame = ttk.Frame(self.dialog, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Title
        title_label = tk.Label(
            main_frame,
            text="Extracting all categories in parallel...",
            font=("Arial", 12, "bold")
        )
        title_label.pack(anchor='w', pady=(0, 10))

        # Overall progress section
        overall_label = tk.Label(
            main_frame,
            text="Overall Progress:",
            font=("Arial", 11, "bold")
        )
        overall_label.pack(anchor='w', pady=(0, 5))

        self.overall_text = tk.Label(
            main_frame,
            text="0 of 0 categories completed",
            font=("Arial", 10)
        )
        self.overall_text.pack(anchor='w', pady=(0, 5))

        self.overall_progress = ttk.Progressbar(
            main_frame,
            mode='determinate',
            length=700
        )
        self.overall_progress.pack(fill=tk.X, pady=(0, 15))

        # Categories progress section
        categories_label = tk.Label(
            main_frame,
            text="Category Progress:",
            font=("Arial", 11, "bold")
        )
        categories_label.pack(anchor='w', pady=(0, 5))

        # Scrollable frame for category widgets
        categories_container = ttk.Frame(main_frame)
        categories_container.pack(fill=tk.BOTH, expand=True, pady=(0, 15))

        # Create canvas for scrolling
        canvas = tk.Canvas(categories_container, height=600)
        scrollbar = ttk.Scrollbar(categories_container, orient="vertical", command=canvas.yview)
        self.scrollable_frame = ttk.Frame(canvas)

        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Bind mouse wheel for scrolling
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")

        canvas.bind_all("<MouseWheel>", _on_mousewheel)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Buttons frame
        buttons_frame = ttk.Frame(main_frame)
        buttons_frame.pack(fill=tk.X, pady=(10, 0))

        # Open Output Folder button
        self.open_folder_btn = ttk.Button(
            buttons_frame,
            text="Open Output Folder",
            command=self._open_output_folder
        )
        self.open_folder_btn.pack(side='left')

        # Cancel button
        self.cancel_btn = ttk.Button(
            buttons_frame,
            text="Cancel",
            command=self._cancel
        )
        self.cancel_btn.pack(side='right')

    def _create_category_widget(self, category_id: str, display_name: str, emoji: str):
        """
        Create progress widget for one category.

        Args:
            category_id: Category identifier (e.g., 'photos', 'sms')
            display_name: Display name for category
            emoji: Emoji for category
        """
        # Container frame for this category
        frame = ttk.Frame(self.scrollable_frame, padding="5")
        frame.pack(fill=tk.X, pady=5)

        # Top row: Status icon + Name + Duration
        top_row = ttk.Frame(frame)
        top_row.pack(fill=tk.X, pady=(0, 3))

        # Status icon (✓/⏳/⏺/✗/⚠)
        status_icon = tk.Label(
            top_row,
            text="⏺",
            font=("Segoe UI Emoji", 14),
            width=2
        )
        status_icon.pack(side='left', padx=(0, 5))

        # Category name with emoji (clickable with hyperlink style)
        name_label = tk.Label(
            top_row,
            text=f"{emoji} {display_name}",
            font=("Arial", 10, "bold"),
            anchor='w',
            fg="#0066cc",
            cursor="hand2"
        )
        name_label.pack(side='left', fill=tk.X, expand=True)

        # Make label clickable to open category folder
        def on_name_click(event):
            self._open_category_folder(category_id)

        def on_name_enter(event):
            name_label.config(font=("Arial", 10, "bold", "underline"))

        def on_name_leave(event):
            name_label.config(font=("Arial", 10, "bold"))

        name_label.bind("<Button-1>", on_name_click)
        name_label.bind("<Enter>", on_name_enter)
        name_label.bind("<Leave>", on_name_leave)

        # Duration label
        duration_label = tk.Label(
            top_row,
            text="",
            font=("Arial", 9),
            fg="#666",
            anchor='e'
        )
        duration_label.pack(side='right', padx=(5, 0))

        # Progress bar
        progress_bar = ttk.Progressbar(
            frame,
            mode='determinate',
            length=650
        )
        progress_bar.pack(fill=tk.X, pady=(0, 3))

        # Details label (items, current item)
        details_label = tk.Label(
            frame,
            text="Waiting to start...",
            font=("Arial", 9),
            fg="#666",
            anchor='w'
        )
        details_label.pack(fill=tk.X)

        # Store widget references
        self.category_widgets[category_id] = {
            'frame': frame,
            'status_icon': status_icon,
            'name_label': name_label,
            'progress_bar': progress_bar,
            'details_label': details_label,
            'duration_label': duration_label
        }

        # Initialize state
        self.category_states[category_id] = {
            'status': 'pending',
            'item_current': 0,
            'item_total': 0,
            'item_name': '',
            'start_time': None,
            'end_time': None
        }

    def start(self):
        """Start parallel extraction in background thread."""
        self.start_time = time.time()

        # Create category widgets for all categories
        for category_id in self.manager.categories:
            display_name, emoji, _, _ = self.manager.CATEGORY_REGISTRY.get(category_id, ('', '', '', ''))
            if display_name:  # Only create widget if category exists
                self._create_category_widget(category_id, display_name, emoji)

        # Run extraction in background thread
        thread = threading.Thread(target=self._run_extraction, daemon=True)
        thread.start()

    def _run_extraction(self):
        """Run parallel extraction (background thread)."""
        try:
            self.summary = self.manager.extract_all_parallel(progress_callback=self._update_progress)
            self.completed = True
            self.dialog.after(0, self._on_complete)
        except Exception as e:
            print(f"[ERROR] Parallel extraction failed: {e}")
            import traceback
            traceback.print_exc()
            self.dialog.after(0, lambda: self._on_error(str(e)))

    def _update_progress(self, progress: Dict[str, Any]):
        """Update progress display (called from background thread) with rate limiting."""
        category_id = progress.get('category_id')
        if not category_id:
            return

        # Update state immediately (in memory)
        if category_id in self.category_states:
            state = self.category_states[category_id]
            state.update({
                'status': progress.get('status', state['status']),
                'item_current': progress.get('item_current', state['item_current']),
                'item_total': progress.get('item_total', state['item_total']),
                'item_name': progress.get('item_name', state['item_name']),
                'start_time': progress.get('start_time', state['start_time']),
                'end_time': progress.get('end_time', state['end_time'])
            })

        # Check if status changed (always update UI immediately for status changes)
        status = progress.get('status')
        is_status_change = status in ('running', 'completed', 'failed', 'skipped')

        # Rate limit UI updates (except for status changes)
        current_time = time.time()
        if is_status_change or (current_time - self.last_ui_update) >= self.ui_update_interval:
            self.last_ui_update = current_time
            self.dialog.after(0, lambda: self._update_ui_all())
        elif self.pending_ui_update is None:
            # Schedule a UI update for later if one isn't already scheduled
            delay_ms = int(self.ui_update_interval * 1000)
            self.pending_ui_update = self.dialog.after(delay_ms, self._schedule_ui_update)

    def _schedule_ui_update(self):
        """Called by timer to update UI."""
        self.pending_ui_update = None
        self.last_ui_update = time.time()
        self._update_ui_all()

    def _update_ui_all(self):
        """Update UI for all categories (main thread)."""
        try:
            # Update all category widgets
            for category_id, state in self.category_states.items():
                self._update_category_widget(category_id, state)

            # Update overall progress
            self._update_overall_progress()

        except Exception as e:
            print(f"[DEBUG] Error updating parallel UI: {e}")
            import traceback
            traceback.print_exc()

    def _update_category_widget(self, category_id: str, state: Dict[str, Any]):
        """Update a single category widget."""
        if category_id not in self.category_widgets:
            return

        widgets = self.category_widgets[category_id]
        status = state['status']

        # Update status icon
        status_icons = {
            'pending': '⏺',
            'running': '⏳',
            'completed': '✓',
            'failed': '✗',
            'skipped': '⚠'
        }
        status_colors = {
            'pending': '#999',
            'running': '#0066cc',
            'completed': '#00aa00',
            'failed': '#cc0000',
            'skipped': '#ff8800'
        }
        widgets['status_icon'].config(
            text=status_icons.get(status, '⏺'),
            fg=status_colors.get(status, '#000')
        )

        # Update progress bar
        if status == 'completed':
            widgets['progress_bar']['value'] = 100
        elif status == 'failed' or status == 'skipped':
            # Keep current progress for failed/skipped
            pass
        elif state['item_total'] > 0:
            percent = (state['item_current'] / state['item_total']) * 100
            widgets['progress_bar']['value'] = percent
        elif status == 'running':
            widgets['progress_bar']['value'] = 0

        # Update details text
        if status == 'running':
            if state['item_total'] > 0:
                details_text = f"{state['item_current']:,} of {state['item_total']:,} items"
                if state['item_name']:
                    # Truncate long item names
                    item_display = state['item_name'] if len(state['item_name']) <= 40 else state['item_name'][:37] + "..."
                    details_text += f" • {item_display}"
                widgets['details_label'].config(text=details_text)
            else:
                widgets['details_label'].config(text="Starting...")
        elif status == 'completed':
            widgets['details_label'].config(text=f"Completed • {state['item_current']:,} items extracted")
        elif status == 'failed':
            error_msg = state.get('error', 'Unknown error')
            widgets['details_label'].config(text=f"Failed: {error_msg}")
        elif status == 'skipped':
            widgets['details_label'].config(text="Not available in backup")
        elif status == 'pending':
            widgets['details_label'].config(text="Waiting to start...")

        # Update duration
        if state['start_time']:
            if state['end_time']:
                duration = state['end_time'] - state['start_time']
            else:
                duration = time.time() - state['start_time']
            widgets['duration_label'].config(text=self._format_duration(duration))

    def _update_overall_progress(self):
        """Update overall progress based on category states."""
        total_categories = len(self.category_states)
        completed_categories = sum(
            1 for state in self.category_states.values()
            if state['status'] in ('completed', 'failed', 'skipped')
        )

        if total_categories > 0:
            overall_pct = (completed_categories / total_categories) * 100
            self.overall_progress['value'] = overall_pct
            self.overall_text.config(text=f"{completed_categories} of {total_categories} categories completed")

    def _format_duration(self, seconds: float) -> str:
        """Format duration in seconds to human-readable string."""
        if seconds < 60:
            return f"{int(seconds)}s"
        elif seconds < 3600:
            minutes = int(seconds / 60)
            secs = int(seconds % 60)
            return f"{minutes}m {secs}s"
        else:
            hours = int(seconds / 3600)
            minutes = int((seconds % 3600) / 60)
            return f"{hours}h {minutes}m"

    def _on_complete(self):
        """Handle extraction completion."""
        self.cancel_btn.config(text="Close", state='normal', command=self.dialog.destroy)

        # Show completion summary
        messagebox.showinfo(
            "Extraction Complete",
            f"Successfully extracted {self.summary['total_items']:,} items in {self._format_duration(self.summary['duration'])}",
            parent=self.dialog
        )

    def _on_error(self, error_msg: str):
        """Handle extraction error."""
        self.cancel_btn.config(text="Close", state='normal', command=self.dialog.destroy)

        messagebox.showerror(
            "Extraction Error",
            f"An error occurred during extraction:\n\n{error_msg}",
            parent=self.dialog
        )

    def _open_category_folder(self, category_id: str):
        """Open the output folder for a specific category."""
        # Get category subfolder name
        _, _, _, subfolder = self.manager.CATEGORY_REGISTRY.get(category_id, ('', '', '', ''))
        if not subfolder:
            return

        # Determine output directory
        if self.manager.options.get('organize_by_category', True):
            output_dir = os.path.join(self.manager.output_base_dir, subfolder)
        else:
            output_dir = self.manager.output_base_dir

        # Open folder if it exists
        if os.path.exists(output_dir):
            try:
                FileManager.open_folder(output_dir)
            except Exception as e:
                print(f"[ERROR] Failed to open folder: {e}")
        else:
            messagebox.showwarning(
                "Folder Not Found",
                f"The output folder does not exist yet:\n{output_dir}",
                parent=self.dialog
            )

    def _open_output_folder(self):
        """Open the main output folder."""
        output_dir = self.manager.output_base_dir
        if os.path.exists(output_dir):
            try:
                FileManager.open_folder(output_dir)
            except Exception as e:
                print(f"[ERROR] Failed to open folder: {e}")
        else:
            messagebox.showwarning(
                "Folder Not Found",
                f"The output folder does not exist yet:\n{output_dir}",
                parent=self.dialog
            )

    def _cancel(self):
        """Handle cancel button."""
        if not self.cancelled and not self.completed:
            result = messagebox.askyesno(
                "Cancel Extraction",
                "Are you sure you want to cancel the extraction?\n\nPartial results will be saved.",
                parent=self.dialog
            )

            if result:
                self.cancelled = True
                self.manager.cancel()
                self.cancel_btn.config(state='disabled', text="Cancelling...")

    def _on_close(self):
        """Handle window close button."""
        if self.completed:
            self.dialog.destroy()
        else:
            self._cancel()
