#!/usr/bin/env python3
"""
Full Extraction Manager - Orchestrates extraction of all data categories from an iOS backup.
"""

import os
import shutil
import time
import queue
import threading
import concurrent.futures
import plistlib
import sqlite3
import uuid
import platform
import sys
import json
from typing import Dict, List, Optional, Callable, Any
from datetime import datetime

from backup_access import is_encrypted_backup, cleanup_backup_access
from audit_logger import AuditLogger, hash_file


class FullExtractionManager:
    """Manages full backup extraction across all data categories."""

    # Category metadata: (display_name, emoji, extractor_class_name, export_subfolder)
    CATEGORY_REGISTRY = {
        'contacts': ('Contacts', '📇', 'ContactsExtractor', 'Contacts'),
        'photos': ('Photos & Videos', '📸', 'PhotosExtractor', 'Photos & Videos'),
        'sms': ('Messages', '💬', 'SMSExtractor', 'Messages'),
        'notes': ('Notes', '📝', 'NotesExtractor', 'Notes'),
        'calendar': ('Calendar', '📅', 'CalendarExtractor', 'Calendar'),
        'call_history': ('Call History', '📞', 'CallHistoryExtractor', 'Call History'),
        'voicemail': ('Voicemail', '🎤', 'VoicemailExtractor', 'Voicemail'),
        'voice_memos': ('Voice Memos', '🎵', 'VoiceMemosExtractor', 'Voice Memos'),
        'documents': ('Documents & Files', '📁', 'DocumentsExtractor', 'Documents'),
        'bluetooth': ('Bluetooth Pairings', '🔵', 'BluetoothExtractor', 'Bluetooth'),
        'significant_locations': ('Significant Locations', '📍', 'SignificantLocationsExtractor', 'Significant Locations'),
        'timeline': ('Timeline', 'TL', 'TimelineExtractor', 'Timeline'),
        'safari': ('Safari Bookmarks', '🔖', 'SafariExtractor', 'Safari'),
        'browsers': ('Browsers', 'BR', 'BrowsersExtractor', 'Browsers'),
        'reminders': ('Reminders', '✅', 'RemindersExtractor', 'Reminders'),
        'whatsapp': ('WhatsApp Messages', '💬', 'WhatsAppExtractor', 'WhatsApp'),
        'viber': ('Viber', 'VB', 'ViberExtractor', 'Viber'),
        'messenger': ('Facebook Messenger', '💬', 'MessengerExtractor', 'Messenger'),
        'instagram': ('Instagram Direct', '📷', 'InstagramExtractor', 'Instagram'),
        'kik': ('Kik', 'KiK', 'KikExtractor', 'Kik'),
        'line': ('LINE', 'LINE', 'LineExtractor', 'Line'),
        'snapchat': ('Snapchat', 'SC', 'SnapchatExtractor', 'Snapchat'),
        'screen_time': ('Screen Time', '⏱', 'ScreenTimeExtractor', 'Screen Time'),
        'health_fitness': ('Health & Fitness', '🏃', 'HealthFitnessExtractor', 'Health & Fitness'),
        'passwords': ('Passwords', 'PW', 'PasswordsExtractor', 'Passwords'),
    }
    DISABLED_CATEGORIES = {'snapchat'}
    SLOW_CATEGORY_COUNTS = {'documents', 'browsers'}
    DOCUMENT_DOMAIN_HINTS = [
        'AppDomain-com.apple.DocumentsApp',
        'AppDomain-group.com.apple.FileProvider.LocalStorage',
        'AppDomainGroup-group.com.apple.FileProvider.LocalStorage',
        'AppDomain-com.apple.CloudDocs',
        'AppDomainGroup-group.com.apple.CloudDocs',
        'HomeDomain',
        'CloudDocsDomain'
    ]
    DOCUMENT_PATH_HINTS = [
        '%/Documents/%',
        '%/Downloads/%',
        '%/Files/%',
        '%/Inbox/%',
        'Documents/%',
        'Downloads/%',
        'Files/%',
        'Inbox/%',
        '%File Provider Storage/%',
        '%Library/Mobile Documents/com~apple~CloudDocs/%'
    ]
    BROWSER_DOMAIN_HINTS = [
        'AppDomainGroup-group.org.mozilla.ios.Firefox',
        'AppDomain-org.mozilla.ios.Firefox',
        'AppDomain-com.google.chrome.ios',
        'AppDomainGroup-group.com.google.chrome',
        'AppDomain-com.microsoft.msedge',
    ]
    SAFARI_DOMAIN_HINT = 'HomeDomain'
    SAFARI_BOOKMARKS_HINT = 'Library/Safari/Bookmarks.db'

    def __init__(self, backup_path: str, output_base_dir: str,
                 categories: Optional[List[str]] = None,
                 options: Optional[Dict[str, Any]] = None,
                 backup_access=None,
                 experimental_categories: Optional[set] = None):
        """
        Initialize full extraction manager.

        Args:
            backup_path: Path to iOS backup directory
            output_base_dir: Base output directory for extraction
            categories: List of category IDs to extract (None = all)
            options: Extraction options (convert_heic, organize_by_category, etc.)
        """
        self.backup_path = backup_path
        self.output_base_dir = output_base_dir
        self.experimental_categories = experimental_categories or set()
        if categories is None:
            self.categories = [cat for cat in self.CATEGORY_REGISTRY.keys()
                               if cat not in self.DISABLED_CATEGORIES
                               or cat in self.experimental_categories]
        else:
            self.categories = categories
        # Always run timeline after other categories
        if 'timeline' in self.categories:
            self.categories = [c for c in self.categories if c != 'timeline'] + ['timeline']
        self.options = options or {}
        self.backup_access = backup_access
        if self.backup_access is not None:
            self.is_encrypted = bool(getattr(self.backup_access, "is_encrypted", False))
        else:
            self.is_encrypted = is_encrypted_backup(self.backup_path)
        self.allow_passwords_plain = bool(self.options.get("allow_passwords_plain", False))
        self.keep_decrypted_temp = bool(self.options.get("keep_decrypted_temp", False))
        self.audit_mode = str(self.options.get("audit_mode", "minimal")).lower().strip()
        if self.audit_mode not in ("minimal", "forensic"):
            self.audit_mode = "minimal"
        self.audit_enabled = bool(self.options.get("audit_enabled", True)) or self.audit_mode == "forensic"
        self.audit_verbose = bool(self.options.get("audit_verbose", False))
        self.audit_hash_reports = bool(
            self.options.get("audit_hash_reports", self.audit_mode == "forensic")
        )
        self.audit_hash_payloads = bool(self.options.get("audit_hash_payloads", False))
        if self.audit_mode != "forensic":
            self.audit_hash_reports = False
            self.audit_hash_payloads = False
        self._available_cache = {}
        self._audit_logger = None
        self._audit_run_id = None
        self._payload_hash_lock = threading.Lock()
        self._audit_dir = None
        self._audit_inputs = {}
        self._output_heartbeat_path = os.path.join(self.output_base_dir, ".ibm_output_heartbeat") if self.output_base_dir else ""
        self._heartbeat_created = False
        if self.backup_access is not None:
            try:
                from backup_access import register_backup_access
                register_backup_access(self.backup_path, self.backup_access)
            except Exception:
                pass

        # Extraction state
        self.cancelled = False
        self.start_time = None
        self.results = {}  # category_id -> {'status': 'success'|'failed'|'skipped', 'count': int, 'error': str}
        self.timeline_emitter = None
        try:
            if self.output_base_dir:
                from extractors.timeline_emitter import TimelineEmitter
                timeline_dir = os.path.join(self.output_base_dir, "Timeline")
                case_id = os.path.basename(os.path.abspath(self.backup_path))
                self.timeline_emitter = TimelineEmitter(timeline_dir, case_id=case_id)
                if self.timeline_emitter.uses_staging():
                    print("[WARN] Timeline output not writable; staging timeline files locally for this run.")
        except Exception:
            self.timeline_emitter = None

    def _output_path_available(self) -> bool:
        if not self.output_base_dir:
            return False
        try:
            os.makedirs(self.output_base_dir, exist_ok=True)
            with open(self._output_heartbeat_path, "a", encoding="utf-8") as f:
                f.write("")
            os.utime(self._output_heartbeat_path, None)
            self._heartbeat_created = True
            return True
        except Exception:
            return False

    def _cleanup_output_heartbeat(self) -> None:
        if not self._output_heartbeat_path or not self._heartbeat_created:
            return
        for _ in range(3):
            try:
                if os.path.exists(self._output_heartbeat_path):
                    os.remove(self._output_heartbeat_path)
                return
            except Exception:
                time.sleep(0.05)

    def get_available_categories(self, fast_mode: Optional[bool] = None) -> Dict[str, Dict[str, Any]]:
        """
        Detect which categories are available in the backup.

        Returns:
            Dict mapping category_id to metadata dict with:
            - available: bool
            - count: int (if available)
            - display_name: str
            - emoji: str
        """
        if fast_mode is None:
            fast_mode = bool(self.options.get("fast_category_scan", False))
        cache_key = "fast" if fast_mode else "full"
        cached = self._available_cache.get(cache_key)
        if cached is not None:
            return cached

        available = {}

        for cat_id in self.categories:
            if cat_id not in self.CATEGORY_REGISTRY:
                continue

            display_name, emoji, extractor_class, _ = self.CATEGORY_REGISTRY[cat_id]
            if cat_id == 'passwords' and not self.is_encrypted and not self.allow_passwords_plain:
                available[cat_id] = {
                    'available': False,
                    'count': 0,
                    'display_name': display_name,
                    'emoji': emoji
                }
                continue
            if cat_id == 'timeline':
                available[cat_id] = {
                    'available': True,
                    'count': 0,
                    'display_name': display_name,
                    'emoji': emoji
                }
                continue

            if cat_id in self.DISABLED_CATEGORIES and cat_id not in self.experimental_categories:
                available[cat_id] = {
                    'available': False,
                    'count': 0,
                    'display_name': display_name,
                    'emoji': emoji
                }
                continue

            try:
                start_time = time.perf_counter()
                if fast_mode and cat_id in self.SLOW_CATEGORY_COUNTS:
                    available_flag = self._quick_check_category(cat_id)
                    count = None if available_flag else 0
                else:
                    # Try to initialize extractor to check if category exists
                    extractor = self._get_extractor(cat_id)
                    count = extractor.get_count()
                    available_flag = True
                elapsed = time.perf_counter() - start_time
                if elapsed >= 0.05:
                    print(f"[DEBUG] Category scan '{cat_id}' took {elapsed:.2f}s (count={count})")

                available[cat_id] = {
                    'available': available_flag,
                    'count': count,
                    'display_name': display_name,
                    'emoji': emoji
                }
            except FileNotFoundError:
                # Category doesn't exist in backup
                available[cat_id] = {
                    'available': False,
                    'count': 0,
                    'display_name': display_name,
                    'emoji': emoji
                }
            except Exception as e:
                # Other error - mark as unavailable
                elapsed = time.perf_counter() - start_time if 'start_time' in locals() else 0.0
                if elapsed >= 0.05:
                    print(f"[DEBUG] Category scan '{cat_id}' failed after {elapsed:.2f}s: {e}")
                else:
                    print(f"[DEBUG] Error checking {cat_id}: {e}")
                available[cat_id] = {
                    'available': False,
                    'count': 0,
                    'display_name': display_name,
                    'emoji': emoji
                }

        self._available_cache[cache_key] = available
        return available

    def _get_manifest_db_path(self) -> str:
        if self.backup_access is not None:
            return self.backup_access.manifest_db_path
        return os.path.join(self.backup_path, "Manifest.db")

    def _quick_check_category(self, category_id: str) -> bool:
        if category_id == "documents":
            return self._quick_check_documents()
        if category_id == "browsers":
            return self._quick_check_browsers()
        return False

    def _quick_check_documents(self) -> bool:
        manifest_db = self._get_manifest_db_path()
        if not os.path.exists(manifest_db):
            return False
        conn = sqlite3.connect(f"file:{manifest_db}?mode=ro", uri=True)
        try:
            cur = conn.cursor()
            domain_conditions = ' OR '.join(['domain LIKE ?' for _ in self.DOCUMENT_DOMAIN_HINTS])
            path_conditions = ' OR '.join(['relativePath LIKE ?' for _ in self.DOCUMENT_PATH_HINTS])
            where_clause = f"({domain_conditions}) OR ({path_conditions})"
            params = [f"%{domain}%" for domain in self.DOCUMENT_DOMAIN_HINTS]
            params.extend(self.DOCUMENT_PATH_HINTS)
            query = f"""
                SELECT 1
                FROM Files
                WHERE ({where_clause})
                  AND relativePath NOT LIKE ''
                  AND relativePath NOT LIKE '%/'
                  AND file IS NOT NULL
                LIMIT 1
            """
            cur.execute(query, params)
            return cur.fetchone() is not None
        except Exception:
            return False
        finally:
            conn.close()

    def _quick_check_browsers(self) -> bool:
        manifest_db = self._get_manifest_db_path()
        if not os.path.exists(manifest_db):
            return False
        conn = sqlite3.connect(f"file:{manifest_db}?mode=ro", uri=True)
        try:
            cur = conn.cursor()
            domain_placeholders = ",".join("?" for _ in self.BROWSER_DOMAIN_HINTS)
            query = f"""
                SELECT 1
                FROM Files
                WHERE domain IN ({domain_placeholders})
                   OR (domain = ? AND relativePath = ?)
                LIMIT 1
            """
            params = list(self.BROWSER_DOMAIN_HINTS)
            params.extend([self.SAFARI_DOMAIN_HINT, self.SAFARI_BOOKMARKS_HINT])
            cur.execute(query, params)
            return cur.fetchone() is not None
        except Exception:
            return False
        finally:
            conn.close()

    def _get_extractor(self, category_id: str):
        """
        Get extractor instance for a category.

        Args:
            category_id: Category identifier

        Returns:
            Extractor instance

        Raises:
            FileNotFoundError: If category database not found in backup
        """
        if category_id not in self.CATEGORY_REGISTRY:
            raise ValueError(f"Unknown category: {category_id}")

        _, _, extractor_class_name, _ = self.CATEGORY_REGISTRY[category_id]
        if category_id in self.DISABLED_CATEGORIES and category_id not in self.experimental_categories:
            raise FileNotFoundError("Category is disabled.")

        # Import extractor class dynamically
        if category_id == 'contacts':
            from extractors.contacts_extractor import ContactsExtractor
            return ContactsExtractor(self.backup_path)
        elif category_id == 'photos':
            from extractors.photos_extractor import PhotosExtractor
            return PhotosExtractor(self.backup_path)
        elif category_id == 'sms':
            from extractors.sms_extractor import SMSExtractor
            return SMSExtractor(self.backup_path)
        elif category_id == 'notes':
            from extractors.notes_extractor import NotesExtractor
            return NotesExtractor(self.backup_path)
        elif category_id == 'calendar':
            from extractors.calendar_extractor import CalendarExtractor
            return CalendarExtractor(self.backup_path)
        elif category_id == 'call_history':
            from extractors.call_history_extractor import CallHistoryExtractor
            return CallHistoryExtractor(self.backup_path)
        elif category_id == 'voicemail':
            from extractors.voicemail_extractor import VoicemailExtractor
            return VoicemailExtractor(self.backup_path)
        elif category_id == 'voice_memos':
            from extractors.voice_memos_extractor import VoiceMemosExtractor
            return VoiceMemosExtractor(self.backup_path)
        elif category_id == 'documents':
            from extractors.documents_extractor import DocumentsExtractor
            return DocumentsExtractor(self.backup_path)
        elif category_id == 'bluetooth':
            from extractors.bluetooth_extractor import BluetoothExtractor
            return BluetoothExtractor(self.backup_path)
        elif category_id == 'significant_locations':
            from extractors.significant_locations_extractor import SignificantLocationsExtractor
            return SignificantLocationsExtractor(self.backup_path)
        elif category_id == 'safari':
            from extractors.safari_extractor import SafariExtractor
            return SafariExtractor(self.backup_path)
        elif category_id == 'browsers':
            from extractors.browsers_extractor import BrowsersExtractor
            return BrowsersExtractor(self.backup_path)
        elif category_id == 'reminders':
            from extractors.reminders_extractor import RemindersExtractor
            return RemindersExtractor(self.backup_path)
        elif category_id == 'whatsapp':
            from extractors.whatsapp_extractor import WhatsAppExtractor
            return WhatsAppExtractor(self.backup_path)
        elif category_id == 'viber':
            from extractors.viber_extractor import ViberExtractor
            return ViberExtractor(self.backup_path)
        elif category_id == 'messenger':
            from extractors.messenger_extractor import MessengerExtractor
            return MessengerExtractor(self.backup_path)
        elif category_id == 'instagram':
            from extractors.instagram_extractor import InstagramExtractor
            return InstagramExtractor(self.backup_path)
        elif category_id == 'kik':
            from extractors.kik_extractor import KikExtractor
            return KikExtractor(self.backup_path)
        elif category_id == 'line':
            from extractors.line_extractor import LineExtractor
            return LineExtractor(self.backup_path)
        elif category_id == 'snapchat':
            from extractors.snapchat_extractor import SnapchatExtractor
            return SnapchatExtractor(self.backup_path)
        elif category_id == 'screen_time':
            from extractors.screen_time_extractor import ScreenTimeExtractor
            return ScreenTimeExtractor(self.backup_path)
        elif category_id == 'health_fitness':
            from extractors.health_fitness_extractor import HealthFitnessExtractor
            return HealthFitnessExtractor(self.backup_path)
        elif category_id == 'passwords':
            if not self.is_encrypted and not self.allow_passwords_plain:
                raise FileNotFoundError("Passwords extraction requires an encrypted backup.")
            from extractors.passwords_extractor import PasswordsExtractor
            return PasswordsExtractor(self.backup_path)
        else:
            raise ValueError(f"No extractor implementation for: {category_id}")

    def extract_all(self, progress_callback: Optional[Callable] = None) -> Dict[str, Any]:
        """
        Extract all selected categories.

        Args:
            progress_callback: Optional callback for progress updates
                              Called with dict containing:
                              - overall_current: int (category index)
                              - overall_total: int (total categories)
                              - category: str (category name)
                              - category_id: str
                              - item_current: int
                              - item_total: int
                              - item_name: str
                              - status: str ('extracting', 'completed', 'failed', 'skipped')

        Returns:
            Summary dict with extraction results
        """
        self.start_time = time.time()
        self.cancelled = False
        self.results = {}

        total_categories = len(self.categories)

        try:
            self._audit_init()
            for idx, category_id in enumerate(self.categories):
                if self.cancelled:
                    break

                # Get category metadata
                if category_id not in self.CATEGORY_REGISTRY:
                    continue

                display_name, emoji, _, subfolder = self.CATEGORY_REGISTRY[category_id]
                category_started = time.time()
                self._audit_emit({
                    "event": "category_start",
                    "category_id": category_id,
                    "category_name": display_name
                })

                # Update progress - starting category
                if progress_callback:
                    progress_callback({
                        'overall_current': idx + 1,
                        'overall_total': total_categories,
                        'category': display_name,
                        'category_id': category_id,
                        'emoji': emoji,
                        'item_current': 0,
                        'item_total': 0,
                        'item_name': '',
                        'status': 'extracting'
                    })

                # Extract category
                try:
                    result = self._extract_category(
                        category_id,
                        subfolder,
                        progress_callback,
                        idx + 1,
                        total_categories
                    )
                    self.results[category_id] = result
                    self._audit_emit({
                        "event": "category_end",
                        "category_id": category_id,
                        "category_name": display_name,
                        "status": result.get("status", "success"),
                        "count": result.get("count", 0),
                        "elapsed_sec": round(time.time() - category_started, 3)
                    })

                    # Update progress - completed
                    if progress_callback and not self.cancelled:
                        progress_callback({
                            'overall_current': idx + 1,
                            'overall_total': total_categories,
                            'category': display_name,
                            'category_id': category_id,
                            'emoji': emoji,
                            'item_current': result.get('count', 0),
                            'item_total': result.get('count', 0),
                            'item_name': '',
                            'status': 'completed'
                        })

                except FileNotFoundError:
                    # Category doesn't exist in backup - skip
                    self.results[category_id] = {
                        'status': 'skipped',
                        'count': 0,
                        'error': 'Not available in backup'
                    }
                    self._audit_emit({
                        "event": "category_end",
                        "category_id": category_id,
                        "category_name": display_name,
                        "status": "skipped",
                        "count": 0,
                        "elapsed_sec": round(time.time() - category_started, 3)
                    })

                    if progress_callback:
                        progress_callback({
                            'overall_current': idx + 1,
                            'overall_total': total_categories,
                            'category': display_name,
                            'category_id': category_id,
                            'emoji': emoji,
                            'item_current': 0,
                            'item_total': 0,
                            'item_name': '',
                            'status': 'skipped'
                        })

                except Exception as e:
                    # Extraction error - log and continue
                    error_msg = str(e)
                    print(f"[ERROR] Failed to extract {category_id}: {error_msg}")

                    self.results[category_id] = {
                        'status': 'failed',
                        'count': 0,
                        'error': error_msg
                    }
                    self._audit_emit({
                        "event": "category_end",
                        "category_id": category_id,
                        "category_name": display_name,
                        "status": "failed",
                        "count": 0,
                        "error": error_msg,
                        "elapsed_sec": round(time.time() - category_started, 3)
                    })

                    if progress_callback:
                        progress_callback({
                            'overall_current': idx + 1,
                            'overall_total': total_categories,
                            'category': display_name,
                            'category_id': category_id,
                            'emoji': emoji,
                            'item_current': 0,
                            'item_total': 0,
                            'item_name': error_msg,
                            'status': 'failed'
                        })

            # Generate summary
            summary = self._generate_summary()
            self._audit_emit({
                "event": "run_end",
                "total_items": summary.get("total_items", 0),
                "duration_sec": summary.get("duration", 0),
                "status": "cancelled" if self.cancelled else "completed"
            })
            self._write_audit_summary(summary)
            return summary
        finally:
            self._cleanup_decrypted_temp()
            self._cleanup_output_heartbeat()
            self._audit_close()

    def extract_all_parallel(self, progress_callback: Optional[Callable] = None) -> Dict[str, Any]:
        """
        Extract all selected categories in parallel using ThreadPoolExecutor.

        Args:
            progress_callback: Optional callback for progress updates
                              Called with dict containing category progress

        Returns:
            Summary dict with extraction results
        """
        self.start_time = time.time()
        self.cancelled = False
        self.results = {}
        self.progress_queue = queue.Queue()
        timeline_pending = False

        # Submit all categories to thread pool immediately (filtering happens in worker threads)
        try:
            if not self._output_path_available():
                self.cancelled = True
                error = "Output path unavailable or not writable"
                for category_id in self.categories:
                    self.results[category_id] = {
                        'status': 'failed',
                        'count': 0,
                        'error': error
                    }
                    display_name, emoji, _, _ = self.CATEGORY_REGISTRY.get(category_id, ('', '', '', ''))
                    self.progress_queue.put({
                        'category_id': category_id,
                        'category': display_name,
                        'emoji': emoji,
                        'status': 'failed',
                        'error': error,
                        'end_time': time.time()
                    })
                summary = self._generate_summary()
                return summary
            self._audit_init()
            with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
                futures = {}

                for category_id in self.categories:
                    if self.cancelled:
                        break
                    if category_id == 'timeline':
                        timeline_pending = True
                        continue

                    # Get subfolder for this category
                    _, _, _, subfolder = self.CATEGORY_REGISTRY[category_id]

                    # Submit extraction job
                    future = executor.submit(
                        self._extract_category_parallel,
                        category_id,
                        subfolder
                    )
                    futures[category_id] = future

                # Start progress polling thread if callback provided
                poll_thread = None
                if progress_callback:
                    poll_thread = threading.Thread(
                        target=self._poll_progress_queue,
                        args=(progress_callback, len(self.categories)),
                        daemon=True
                    )
                    poll_thread.start()

                # Wait for all futures to complete
                for category_id, future in futures.items():
                    if self.cancelled:
                        # Don't wait for remaining futures
                        executor.shutdown(wait=False)
                        break

                    try:
                        result = future.result()
                        self.results[category_id] = result
                    except FileNotFoundError as e:
                        self.results[category_id] = {
                            'status': 'skipped',
                            'count': 0,
                            'error': 'Not available in backup'
                        }
                        display_name, emoji, _, _ = self.CATEGORY_REGISTRY.get(category_id, ('', '', '', ''))
                        self.progress_queue.put({
                            'category_id': category_id,
                            'category': display_name,
                            'emoji': emoji,
                            'status': 'skipped',
                            'error': str(e),
                            'end_time': time.time()
                        })
                    except Exception as e:
                        print(f"[ERROR] {category_id} extraction failed: {e}")
                        import traceback
                        traceback.print_exc()

                        self.results[category_id] = {
                            'status': 'failed',
                            'count': 0,
                            'error': str(e)
                        }

                        display_name, emoji, _, _ = self.CATEGORY_REGISTRY.get(category_id, ('', '', '', ''))
                        # Send error update to queue
                        self.progress_queue.put({
                            'category_id': category_id,
                            'category': display_name,
                            'emoji': emoji,
                            'status': 'failed',
                            'error': str(e),
                            'end_time': time.time()
                        })

                if timeline_pending and not self.cancelled:
                    display_name, emoji, _, _ = self.CATEGORY_REGISTRY.get('timeline', ('Timeline', '', '', ''))
                    self._audit_emit({
                        "event": "category_start",
                        "category_id": "timeline",
                        "category_name": display_name
                    })
                    self.progress_queue.put({
                        'category_id': 'timeline',
                        'category': display_name,
                        'emoji': emoji,
                        'status': 'running',
                        'item_current': 0,
                        'item_total': 0,
                        'item_name': 'Building timeline...',
                        'start_time': time.time()
                    })
                    try:
                        result = self._extract_timeline()
                        self.results['timeline'] = result
                        self.progress_queue.put({
                            'category_id': 'timeline',
                            'category': display_name,
                            'emoji': emoji,
                            'status': 'completed',
                            'item_current': result.get('count', 0),
                            'item_total': result.get('count', 0),
                            'end_time': time.time()
                        })
                        self._audit_emit({
                            "event": "category_end",
                            "category_id": "timeline",
                            "category_name": display_name,
                            "status": "success",
                            "count": result.get("count", 0)
                        })
                    except Exception as e:
                        self.results['timeline'] = {'status': 'failed', 'count': 0, 'error': str(e)}
                        self.progress_queue.put({
                            'category_id': 'timeline',
                            'category': display_name,
                            'emoji': emoji,
                            'status': 'failed',
                            'error': str(e),
                            'end_time': time.time()
                        })
                        self._audit_emit({
                            "event": "category_end",
                            "category_id": "timeline",
                            "category_name": display_name,
                            "status": "failed",
                            "count": 0,
                            "error": str(e)
                        })

                # Stop polling thread
                if poll_thread:
                    self.progress_queue.put(None)  # Sentinel to stop polling
                    poll_thread.join(timeout=1.0)

            # Generate summary
            summary = self._generate_summary()
            self._audit_emit({
                "event": "run_end",
                "total_items": summary.get("total_items", 0),
                "duration_sec": summary.get("duration", 0),
                "status": "cancelled" if self.cancelled else "completed"
            })
            self._write_audit_summary(summary)
            return summary
        finally:
            self._cleanup_decrypted_temp()
            self._cleanup_output_heartbeat()
            self._audit_close()

    def _cleanup_decrypted_temp(self) -> None:
        if not self.is_encrypted or self.keep_decrypted_temp:
            return
        try:
            cleanup_backup_access(self.backup_path)
            print("[INFO] Cleaned decrypted temp data.")
        except Exception as exc:
            print(f"[DEBUG] Failed to clean decrypted temp data: {exc}")

    def _audit_init(self) -> None:
        if not self.audit_enabled:
            return
        if self._audit_logger is not None:
            return
        self._audit_run_id = str(uuid.uuid4())
        self._audit_dir = os.path.join(self.output_base_dir, "Audit")
        self._audit_logger = AuditLogger(self._audit_dir, run_id=self._audit_run_id)
        self._audit_emit({
            "event": "run_start",
            "audit_mode": self.audit_mode,
            "audit_verbose": self.audit_verbose,
            "hash_reports": self.audit_hash_reports,
            "hash_payloads": self.audit_hash_payloads,
            "backup_path": self.backup_path,
            "is_encrypted": self.is_encrypted,
            "python_version": sys.version.split()[0],
            "platform": platform.platform(),
            "app_version": str(self.options.get("app_version", "")),
            "build_number": str(self.options.get("build_number", "")),
            "output_dir": self.output_base_dir
        })
        self._audit_hash_inputs()

    def _audit_close(self) -> None:
        if self._audit_logger is None:
            return
        try:
            self._audit_logger.close()
        finally:
            self._audit_logger = None

    def _audit_emit(self, event: Dict[str, Any]) -> None:
        if not self.audit_enabled or self._audit_logger is None:
            return
        self._audit_logger.emit(event)

    def _audit_hash_inputs(self) -> None:
        if not self.audit_enabled or self._audit_logger is None:
            return
        manifest_path = self._get_manifest_db_path()
        info_plist = os.path.join(self.backup_path, "Info.plist")
        manifest_hash = hash_file(manifest_path)
        info_hash = hash_file(info_plist)
        self._audit_inputs = {
            "manifest_db": manifest_path,
            "manifest_sha256": manifest_hash or "",
            "info_plist": info_plist if os.path.exists(info_plist) else "",
            "info_plist_sha256": info_hash or ""
        }
        self._audit_emit({
            "event": "inputs_hashed",
            **self._audit_inputs
        })

    def _audit_hash_reports(self, output_dir: str, category_id: str) -> None:
        if not self.audit_hash_reports or self._audit_logger is None:
            return
        if not output_dir or not os.path.exists(output_dir):
            return
        for root, _, files in os.walk(output_dir):
            for name in files:
                if not (name.endswith(".html") or name.endswith(".json")):
                    continue
                path = os.path.join(root, name)
                digest = hash_file(path)
                if not digest:
                    continue
                rel_path = os.path.relpath(path, self.output_base_dir)
                self._audit_emit({
                    "event": "output_hashed",
                    "category_id": category_id,
                    "path": rel_path.replace("\\", "/"),
                    "sha256": digest,
                    "size_bytes": os.path.getsize(path)
                })

    def _audit_hash_payloads(self, output_dir: str, category_id: str) -> None:
        if not self.audit_hash_payloads or self._audit_logger is None:
            return
        if not output_dir or not os.path.exists(output_dir):
            return
        audit_dir = self._audit_dir or os.path.join(self.output_base_dir, "Audit")
        os.makedirs(audit_dir, exist_ok=True)
        manifest_path = os.path.join(audit_dir, "payload_hashes.ndjson")
        total_files = 0
        total_bytes = 0
        with self._payload_hash_lock:
            with open(manifest_path, "a", encoding="utf-8") as f:
                for root, _, files in os.walk(output_dir):
                    for name in files:
                        if name.endswith(".html") or name.endswith(".json"):
                            continue
                        file_path = os.path.join(root, name)
                        digest = hash_file(file_path)
                        if not digest:
                            continue
                        rel_path = os.path.relpath(file_path, self.output_base_dir).replace("\\", "/")
                        size_bytes = os.path.getsize(file_path)
                        f.write(json.dumps({
                            "category_id": category_id,
                            "path": rel_path,
                            "sha256": digest,
                            "size_bytes": size_bytes
                        }, ensure_ascii=True) + "\n")
                        total_files += 1
                        total_bytes += size_bytes
        self._audit_emit({
            "event": "payloads_hashed",
            "category_id": category_id,
            "count": total_files,
            "total_bytes": total_bytes,
            "manifest": os.path.relpath(manifest_path, self.output_base_dir).replace("\\", "/")
        })

    def _write_audit_summary(self, summary: Dict[str, Any]) -> None:
        if self.audit_mode != "forensic" or self._audit_logger is None:
            return
        audit_dir = self._audit_dir or os.path.join(self.output_base_dir, "Audit")
        os.makedirs(audit_dir, exist_ok=True)
        out_path = os.path.join(audit_dir, "Audit_Summary.html")
        inputs = self._audit_inputs or {}
        audit_log_rel = "audit_log.ndjson"
        payload_rel = "payload_hashes.ndjson"
        payload_exists = os.path.exists(os.path.join(audit_dir, payload_rel))
        payload_html = (
            f'<div>Payload hashes: <a href="{payload_rel}">{payload_rel}</a></div>'
            if payload_exists else ""
        )
        rows = []
        for category_id, result in (self.results or {}).items():
            status = result.get("status", "")
            count = result.get("count", 0)
            rows.append(f"<tr><td>{category_id}</td><td>{status}</td><td>{count:,}</td></tr>")
        category_rows = "\n".join(rows) if rows else "<tr><td colspan=\"3\">No categories recorded</td></tr>"
        case_info = self.options.get("case_info") or {}
        case_rows = []
        for key, label in [
            ("case_number", "Case Number"),
            ("evidence_number", "Evidence Number"),
            ("examiner", "Examiner"),
            ("department", "Department"),
            ("location", "Location"),
        ]:
            value = case_info.get(key)
            if value:
                case_rows.append(f"<tr><td>{label}</td><td>{value}</td></tr>")
        case_table = ""
        if case_rows:
            case_table = (
                "<table><thead><tr><th>Case Field</th><th>Value</th></tr></thead>"
                f"<tbody>{''.join(case_rows)}</tbody></table>"
            )

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Audit Summary</title>
  <style>
    :root {{
      --bg: #f3f4f6;
      --card: #ffffff;
      --line: #e5e7eb;
      --ink: #111827;
      --muted: #6b7280;
    }}
    body {{ font-family: "Trebuchet MS", "Verdana", sans-serif; background: var(--bg); color: var(--ink); margin: 0; }}
    header {{ background: linear-gradient(135deg, #283048, #859398); color: #fff; padding: 18px 20px; margin: 20px 20px 0px 20px; border-radius: 12px; overflow: hidden; }}
    header h1 {{ margin: 0; font-size: 24px; }}
    header p {{ margin: 6px 0 0; font-size: 13px; color: rgba(255,255,255,0.82); }}
    .wrap {{ max-width: 980px; margin: 18px auto 24px; background: var(--card); padding: 18px; border-radius: 14px; box-shadow: 0 8px 18px rgba(0,0,0,0.06); }}
    h2 {{ margin: 0 0 10px; font-size: 16px; }}
    .meta {{ font-size: 13px; color: #6b7280; margin-bottom: 16px; }}
    table {{ width: 100%; border-collapse: collapse; margin-top: 12px; }}
    th, td {{ text-align: left; padding: 8px 10px; border-bottom: 1px solid #e5e7eb; font-size: 13px; }}
    th {{ background: #f3f4f6; }}
    code {{ background: #f3f4f6; padding: 2px 6px; border-radius: 6px; }}
    .links a {{ color: #1d4ed8; text-decoration: none; }}
    .cards {{ display: none; }}
    .card-row {{ background: #f9fafb; border: 1px solid var(--line); border-radius: 10px; padding: 10px; margin-bottom: 8px; }}
    .card-row strong {{ display: block; font-size: 13px; }}
    .card-row span {{ display: block; font-size: 12px; color: var(--muted); }}
    @media (max-width: 780px) {{
      .wrap {{ margin: 0; border-radius: 0; box-shadow: none; }}
      table {{ display: none; }}
      .cards {{ display: block; margin-top: 12px; }}
    }}
  </style>
</head>
<body>
  <header>
    <h1>Audit Summary</h1>
    <p>Forensic mode compliance details</p>
  </header>
  <div class="wrap">
    <h2>Run Overview</h2>
    <div class="meta">Run ID: {self._audit_run_id or ""}</div>
    <div class="meta">Backup: {self.backup_path}</div>
    <div class="meta">Encrypted: {"Yes" if self.is_encrypted else "No"}</div>
    <div class="meta">Total items: {summary.get("total_items", 0):,} | Duration: {summary.get("duration", 0)}s</div>
    <div class="meta">Manifest.db: <code>{inputs.get("manifest_sha256","")}</code></div>
    <div class="meta">Info.plist: <code>{inputs.get("info_plist_sha256","")}</code></div>
    <div class="links">
      <div>Audit log: <a href="{audit_log_rel}">{audit_log_rel}</a></div>
      {payload_html}
    </div>
    {case_table}
    <h2>Category Results</h2>
    <table>
      <thead><tr><th>Category</th><th>Status</th><th>Count</th></tr></thead>
      <tbody>
        {category_rows}
      </tbody>
    </table>
    <div class="cards">
      {''.join([f'<div class="card-row"><strong>{row.split("<td>")[1].split("</td>")[0]}</strong><span>Status: {row.split("<td>")[2].split("</td>")[0]} | Count: {row.split("<td>")[3].split("</td>")[0]}</span></div>' for row in rows])}
    </div>
  </div>
</body>
</html>"""
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(html)

    def _extract_category_parallel(self, category_id: str, subfolder: str) -> Dict[str, Any]:
        """
        Extract single category in worker thread.

        Args:
            category_id: Category identifier (e.g., 'photos', 'sms')
            subfolder: Output subfolder name

        Returns:
            Result dict with status, count, etc.
        """
        # Get category display info
        display_name, emoji, _, _ = self.CATEGORY_REGISTRY.get(category_id, ('', '', '', ''))

        if not self._output_path_available():
            self.cancelled = True
            raise RuntimeError("Output path unavailable or not writable")

        if category_id == 'timeline':
            return self._extract_timeline()

        category_started = time.time()
        self._audit_emit({
            "event": "category_start",
            "category_id": category_id,
            "category_name": display_name
        })
        # Send start update to queue
        self.progress_queue.put({
            'category_id': category_id,
            'category': display_name,
            'emoji': emoji,
            'status': 'running',
            'item_current': 0,
            'item_total': 0,
            'item_name': '',
            'start_time': time.time()
        })
        if category_id == 'documents':
            self.progress_queue.put({
                'category_id': category_id,
                'item_current': 0,
                'item_total': 1,
                'item_name': 'Scanning documents...'
            })

        try:
            # Get extractor
            extractor = self._get_extractor(category_id)

            # Get items - handle database errors gracefully
            # Use filter_by_existence=False when supported for extraction to get maximum coverage
            # Some items may fail during extraction if files don't exist (iCloud-only photos)
            try:
                items = self._get_items_for_extraction(extractor)
            except Exception as e:
                # Database table doesn't exist or other DB error
                if 'no such table' in str(e).lower() or 'database' in str(e).lower():
                    # Send completion update
                    self.progress_queue.put({
                        'category_id': category_id,
                        'status': 'completed',
                        'end_time': time.time()
                    })
                    self._audit_emit({
                        "event": "category_end",
                        "category_id": category_id,
                        "category_name": display_name,
                        "status": "success",
                        "count": 0,
                        "elapsed_sec": round(time.time() - category_started, 3)
                    })
                    return {'status': 'success', 'count': 0, 'bytes_written': 0}
                else:
                    # Re-raise other errors
                    raise

            force_export = bool(getattr(extractor, "export_even_if_empty", False))
            if not items and not force_export:
                # Send completion update
                self.progress_queue.put({
                    'category_id': category_id,
                    'status': 'completed',
                    'end_time': time.time()
                })
                self._audit_emit({
                    "event": "category_end",
                    "category_id": category_id,
                    "category_name": display_name,
                    "status": "success",
                    "count": 0,
                    "elapsed_sec": round(time.time() - category_started, 3)
                })
                return {'status': 'success', 'count': 0, 'bytes_written': 0}

            # Determine output directory
            if self.options.get('organize_by_category', True):
                output_dir = os.path.join(self.output_base_dir, subfolder)
            else:
                output_dir = self.output_base_dir

            os.makedirs(output_dir, exist_ok=True)

            # Create progress callback that writes to queue
            def category_progress(current: int, total: int, item_name: str) -> bool:
                """Progress callback for this category."""
                self.progress_queue.put({
                    'category_id': category_id,
                    'item_current': current,
                    'item_total': total,
                    'item_name': item_name
                })
                return not self.cancelled

            # Determine export format based on category
            export_format = self._get_export_format(category_id)

            # Export items - check if extractor supports progress_callback and category-specific options
            import inspect
            export_sig = inspect.signature(extractor.export)
            export_kwargs = {
                'format': export_format
            }

            # Add progress_callback if supported
            if 'progress_callback' in export_sig.parameters:
                export_kwargs['progress_callback'] = category_progress
            if 'timeline_emitter' in export_sig.parameters and self.timeline_emitter is not None:
                export_kwargs['timeline_emitter'] = self.timeline_emitter

            # Add category-specific options for photos
            if category_id == 'photos':
                if 'convert_heic' in export_sig.parameters:
                    export_kwargs['convert_heic'] = self.options.get('convert_heic', False)
                if 'organize_by_date' in export_sig.parameters:
                    export_kwargs['organize_by_date'] = self.options.get('organize_by_date', False)
                if 'generate_html_report' in export_sig.parameters:
                    # Always generate HTML report for Extract All Data
                    export_kwargs['generate_html_report'] = True
                if 'include_cached_thumbnails' in export_sig.parameters:
                    export_kwargs['include_cached_thumbnails'] = self.options.get('include_cached_thumbnails', False)

            success = extractor.export(items, output_dir, **export_kwargs)

            if not success:
                raise Exception("Export failed")

            # Send completion update
            self.progress_queue.put({
                'category_id': category_id,
                'status': 'completed',
                'end_time': time.time()
            })

            bytes_written = getattr(extractor, 'last_export_bytes', 0) or 0
            if self.audit_hash_reports:
                self._audit_hash_reports(output_dir, category_id)
            if self.audit_hash_payloads:
                self._audit_hash_payloads(output_dir, category_id)
            result = {
                'status': 'success',
                'count': len(items),
                'bytes_written': bytes_written
            }
            self._audit_emit({
                "event": "category_end",
                "category_id": category_id,
                "category_name": display_name,
                "status": "success",
                "count": len(items),
                "elapsed_sec": round(time.time() - category_started, 3)
            })
            return result

        except FileNotFoundError:
            # Category doesn't exist in backup - skip
            self.progress_queue.put({
                'category_id': category_id,
                'category': display_name,
                'emoji': emoji,
                'status': 'skipped',
                'end_time': time.time()
            })
            self._audit_emit({
                "event": "category_end",
                "category_id": category_id,
                "category_name": display_name,
                "status": "skipped",
                "count": 0,
                "elapsed_sec": round(time.time() - category_started, 3)
            })
            return {
                'status': 'skipped',
                'count': 0,
                'error': 'Not available in backup'
            }
        except Exception as e:
            # Send error update
            self.progress_queue.put({
                'category_id': category_id,
                'category': display_name,
                'emoji': emoji,
                'status': 'failed',
                'error': str(e),
                'end_time': time.time()
            })
            self._audit_emit({
                "event": "category_end",
                "category_id": category_id,
                "category_name": display_name,
                "status": "failed",
                "count": 0,
                "error": str(e),
                "elapsed_sec": round(time.time() - category_started, 3)
            })
            raise

    def _poll_progress_queue(self, callback: Callable, total_categories: int):
        """
        Poll progress queue and forward updates to callback.

        Runs in a separate daemon thread. Continuously polls the queue
        and calls the callback with each progress update until a sentinel
        value (None) is received.

        Args:
            callback: Function to call with progress updates
            total_categories: Total number of categories being extracted
        """
        while not self.cancelled:
            try:
                # Wait for update with timeout
                update = self.progress_queue.get(timeout=0.1)

                # Check for sentinel to stop
                if update is None:
                    break

                # Forward update to callback
                callback(update)

            except queue.Empty:
                # No update available, continue polling
                continue

    def _extract_category(self, category_id: str, subfolder: str,
                         progress_callback: Optional[Callable],
                         category_idx: int, total_categories: int) -> Dict[str, Any]:
        """
        Extract a single category.

        Returns:
            Result dict with status, count, etc.
        """
        if category_id == 'timeline':
            return self._extract_timeline()

        # Get extractor
        extractor = self._get_extractor(category_id)

        # Get items - handle database errors gracefully
        # Use filter_by_existence=False when supported for extraction to get maximum coverage
        try:
            items = self._get_items_for_extraction(extractor)
        except Exception as e:
            # Database table doesn't exist or other DB error
            if 'no such table' in str(e).lower() or 'database' in str(e).lower():
                return {'status': 'success', 'count': 0}
            else:
                # Re-raise other errors
                raise

        force_export = bool(getattr(extractor, "export_even_if_empty", False))
        if not items and not force_export:
            return {'status': 'success', 'count': 0, 'bytes_written': 0}

        # Determine output directory
        if self.options.get('organize_by_category', True):
            output_dir = os.path.join(self.output_base_dir, subfolder)
        else:
            output_dir = self.output_base_dir

        os.makedirs(output_dir, exist_ok=True)

        # Create progress wrapper for this category
        category_progress_callback = self._make_category_progress_callback(
            progress_callback,
            category_id,
            category_idx,
            total_categories
        )

        # Determine export format based on category
        export_format = self._get_export_format(category_id)

        # Export items - check if extractor supports progress_callback and category-specific options
        import inspect
        export_sig = inspect.signature(extractor.export)
        export_kwargs = {
            'format': export_format
        }

        # Add progress_callback if supported
        if 'progress_callback' in export_sig.parameters:
            export_kwargs['progress_callback'] = category_progress_callback
        if 'timeline_emitter' in export_sig.parameters and self.timeline_emitter is not None:
            export_kwargs['timeline_emitter'] = self.timeline_emitter

        # Add category-specific options for photos
        if category_id == 'photos':
            if 'convert_heic' in export_sig.parameters:
                export_kwargs['convert_heic'] = self.options.get('convert_heic', False)
            if 'organize_by_date' in export_sig.parameters:
                export_kwargs['organize_by_date'] = self.options.get('organize_by_date', False)

        success = extractor.export(items, output_dir, **export_kwargs)

        if not success:
            raise Exception("Export failed")

        bytes_written = getattr(extractor, 'last_export_bytes', 0) or 0
        if self.audit_hash_reports:
            self._audit_hash_reports(output_dir, category_id)
        if self.audit_hash_payloads:
            self._audit_hash_payloads(output_dir, category_id)
        return {
            'status': 'success',
            'count': len(items),
            'bytes_written': bytes_written
        }

    def _make_category_progress_callback(self, overall_callback: Optional[Callable],
                                        category_id: str, category_idx: int,
                                        total_categories: int) -> Optional[Callable]:
        """
        Create a progress callback wrapper for a specific category.

        Translates category-specific progress to overall progress format.
        """
        if not overall_callback:
            return None

        display_name, emoji, _, _ = self.CATEGORY_REGISTRY.get(category_id, ('', '', '', ''))

        def callback(current: int, total: int, item_name: str) -> bool:
            """Category-level progress callback."""
            overall_callback({
                'overall_current': category_idx,
                'overall_total': total_categories,
                'category': display_name,
                'category_id': category_id,
                'emoji': emoji,
                'item_current': current,
                'item_total': total,
                'item_name': item_name,
                'status': 'extracting'
            })

            # Return False to cancel if needed
            return not self.cancelled

        return callback

    def _get_items_for_extraction(self, extractor):
        """Fetch items from an extractor, using filter_by_existence when supported."""
        import inspect
        get_items_sig = inspect.signature(extractor.get_items)
        kwargs = {
            'limit': None,
            'offset': 0
        }
        if 'filter_by_existence' in get_items_sig.parameters:
            kwargs['filter_by_existence'] = False
        return extractor.get_items(**kwargs)

    def _get_export_format(self, category_id: str) -> str:
        """Get appropriate export format for a category."""
        # Return appropriate format for each category
        format_map = {
            'contacts': 'files',  # Exports VCF, CSV, HTML
            'photos': 'files',    # Exports to DCIM structure
            'sms': 'html',        # Exports HTML conversations
            'notes': 'html',      # Exports HTML notes
            'calendar': 'files',  # Exports ICS, CSV, HTML
            'call_history': 'files',  # Exports CSV, HTML
            'voicemail': 'files', # Exports audio + reports
            'voice_memos': 'files',  # Exports M4A files
            'documents': 'files',  # Exports organized document files
            'bluetooth': 'html',  # Exports HTML + JSON
            'significant_locations': 'html',  # Exports HTML + JSON
            'safari': 'html',     # Exports HTML bookmarks
            'browsers': 'html',   # Exports unified browsers report
            'timeline': 'html',   # Derived timeline report
            'reminders': 'html',  # Exports HTML reminders
            'whatsapp': 'html',  # Exports HTML conversations
            'messenger': 'html',  # Exports HTML conversations
            'instagram': 'html',  # Exports HTML conversations
            'snapchat': 'html',   # Exports tiered Snapchat report
            'screen_time': 'html',  # Exports HTML + JSON
            'health_fitness': 'html',  # Exports HTML + JSON
            'passwords': 'html'   # Exports keychain/passwords report
        }

        return format_map.get(category_id, 'files')

    def _extract_timeline(self) -> Dict[str, Any]:
        """Finalize timeline events and generate Timeline.html."""
        timeline_dir = os.path.join(self.output_base_dir, "Timeline")
        os.makedirs(timeline_dir, exist_ok=True)
        event_count = 0
        report_dir = timeline_dir
        if self.timeline_emitter is not None:
            try:
                event_count = self.timeline_emitter.finalize()
                report_dir = self.timeline_emitter.get_report_dir()
            except Exception:
                event_count = 0
        else:
            timeline_json = os.path.join(timeline_dir, "timeline_events.json")
            if not os.path.exists(timeline_json):
                with open(timeline_json, "w", encoding="utf-8") as f:
                    f.write("[]")

        try:
            from timeline_report_generator import generate_timeline_report
            generate_timeline_report(report_dir, backup_date=self._get_backup_date())
        except Exception as exc:
            return {'status': 'failed', 'count': 0, 'error': str(exc)}

        if report_dir != timeline_dir:
            for name in ("Timeline.html", "timeline_events.json"):
                src = os.path.join(report_dir, name)
                dst = os.path.join(timeline_dir, name)
                if os.path.exists(src):
                    try:
                        shutil.copy2(src, dst)
                    except Exception:
                        pass

        bytes_written = 0
        for name in ("Timeline.html", "timeline_events.json"):
            path = os.path.join(timeline_dir, name)
            if os.path.exists(path):
                bytes_written += os.path.getsize(path)
            else:
                alt_path = os.path.join(report_dir, name)
                if os.path.exists(alt_path):
                    bytes_written += os.path.getsize(alt_path)

        return {
            'status': 'success',
            'count': event_count,
            'bytes_written': bytes_written
        }

    def _get_backup_date(self) -> Optional[datetime]:
        manifest_path = os.path.join(self.backup_path, "Manifest.plist")
        if os.path.exists(manifest_path):
            try:
                with open(manifest_path, "rb") as f:
                    manifest = plistlib.load(f)
                date_val = manifest.get("Date")
                if isinstance(date_val, datetime):
                    return date_val
            except Exception:
                pass

        try:
            mtime = os.path.getmtime(self.backup_path)
            return datetime.fromtimestamp(mtime)
        except Exception:
            return None

    def _generate_summary(self) -> Dict[str, Any]:
        """Generate extraction summary."""
        end_time = time.time()
        duration = end_time - self.start_time if self.start_time else 0

        if 'timeline' not in self.results:
            try:
                self.results['timeline'] = self._extract_timeline()
            except Exception as exc:
                self.results['timeline'] = {'status': 'failed', 'count': 0, 'error': str(exc)}

        successful = [k for k, v in self.results.items() if v['status'] == 'success']
        failed = [k for k, v in self.results.items() if v['status'] == 'failed']
        skipped = [k for k, v in self.results.items() if v['status'] == 'skipped']

        total_items = sum(
            v['count'] for k, v in self.results.items()
            if v['status'] == 'success' and k != 'timeline'
        )
        total_storage_estimate = sum(
            v.get('bytes_written', 0)
            for v in self.results.values()
            if v['status'] == 'success'
        )

        summary = {
            'duration': duration,
            'start_time': self.start_time,
            'end_time': end_time,
            'cancelled': self.cancelled,
            'total_categories': len(self.categories),
            'successful': len(successful),
            'failed': len(failed),
            'skipped': len(skipped),
            'total_items': total_items,
            'total_storage_estimate': total_storage_estimate,
            'results': self.results,
            'output_dir': self.output_base_dir
        }

        # Write summary file
        self._write_summary_file(summary)
        self._generate_master_report(summary)
        self._generate_device_info_report(summary)

        return summary

    def _generate_master_report(self, summary: Dict[str, Any]):
        """Generate the master report (Start_Here.html) when enabled."""
        if not self.options.get('generate_master_report', True):
            return
        try:
            from master_report_generator import generate_master_report
            generate_master_report(
                self.backup_path,
                self.output_base_dir,
                summary,
                self.options,
                backup_access=self.backup_access,
            )
        except Exception as e:
            print(f"[WARNING] Failed to generate master report: {e}")

    def _generate_device_info_report(self, summary: Dict[str, Any]) -> None:
        if not self.options.get('generate_master_report', True):
            return
        try:
            from device_information_report_generator import generate_device_information_report
            generate_device_information_report(
                self.backup_path,
                self.output_base_dir,
                summary,
                self.options,
                backup_access=self.backup_access,
            )
        except Exception as e:
            print(f"[WARNING] Failed to generate device information report: {e}")

    def _write_summary_file(self, summary: Dict[str, Any]):
        """Write extraction summary to text file."""
        try:
            # Check if user wants to generate summary
            generate_summary = self.options.get('generate_summary', True)
            if not generate_summary:
                return  # Don't generate summary if option is disabled

            summary_path = os.path.join(self.output_base_dir, 'EXTRACTION_SUMMARY.txt')
            file_exists = os.path.exists(summary_path)

            # Always append to existing file, create new if doesn't exist
            mode = 'a' if file_exists else 'w'

            with open(summary_path, mode, encoding='utf-8') as f:
                # If appending to existing file, add separator
                if mode == 'a':
                    f.write("\n\n")
                    f.write("=" * 80 + "\n")
                    f.write("NEW EXTRACTION RUN\n")
                    f.write("=" * 80 + "\n\n")
                else:
                    # New file - add header
                    f.write("=" * 80 + "\n")
                    f.write("iOS BACKUP EXTRACTION SUMMARY\n")
                    f.write("=" * 80 + "\n\n")

                f.write(f"Extraction Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"Backup Path: {self.backup_path}\n")
                f.write(f"Output Directory: {self.output_base_dir}\n")
                f.write(f"Duration: {self._format_duration(summary['duration'])}\n\n")

                f.write(f"Total Categories: {summary['total_categories']}\n")
                f.write(f"  Successful: {summary['successful']}\n")
                f.write(f"  Failed: {summary['failed']}\n")
                f.write(f"  Skipped: {summary['skipped']}\n")
                f.write(f"Total Items Extracted: {summary['total_items']:,}\n\n")

                f.write("-" * 80 + "\n")
                f.write("EXTRACTION OPTIONS\n")
                f.write("-" * 80 + "\n\n")
                for key, label in [
                    ("convert_heic", "Convert HEIC to JPG"),
                    ("organize_by_date", "Organize photos by date"),
                    ("organize_by_category", "Organize by category"),
                    ("include_cached_thumbnails", "Include cached thumbnails"),
                    ("generate_summary", "Generate extraction summary"),
                ]:
                    enabled = "Enabled" if self.options.get(key, False) else "Not enabled"
                    f.write(f"{label}: {enabled}\n")
                audit_mode = str(self.options.get("audit_mode", "minimal")).lower().strip()
                forensic = "Enabled" if audit_mode == "forensic" else "Not enabled"
                f.write(f"Forensic Mode: {forensic}\n")
                f.write("\n")

                f.write("-" * 80 + "\n")
                f.write("EXTRACTION RESULTS\n")
                f.write("-" * 80 + "\n\n")

                for cat_id, result in summary['results'].items():
                    display_name, emoji, _, _ = self.CATEGORY_REGISTRY.get(cat_id, (cat_id, '', '', ''))
                    status = result['status']
                    count = result.get('count', 0)

                    if status == 'success':
                        f.write(f"✓ {emoji} {display_name}: {count:,} items\n")
                    elif status == 'skipped':
                        error = result.get('error', 'Unknown')
                        f.write(f"⚠ {emoji} {display_name}: {error}\n")
                    elif status == 'failed':
                        error = result.get('error', 'Unknown error')
                        f.write(f"✗ {emoji} {display_name}: Failed ({error})\n")

                f.write("\n" + "=" * 80 + "\n")
                f.write("END OF EXTRACTION RUN\n")
                f.write("=" * 80 + "\n")

        except Exception as e:
            print(f"[WARNING] Failed to write summary file: {e}")

    def _format_duration(self, seconds: float) -> str:
        """Format duration in seconds to human-readable string."""
        if seconds < 60:
            return f"{int(seconds)}s"
        elif seconds < 3600:
            mins = int(seconds // 60)
            secs = int(seconds % 60)
            return f"{mins}m {secs}s"
        else:
            hours = int(seconds // 3600)
            mins = int((seconds % 3600) // 60)
            secs = int(seconds % 60)
            return f"{hours}h {mins}m {secs}s"

    def cancel(self):
        """Cancel extraction."""
        self.cancelled = True
