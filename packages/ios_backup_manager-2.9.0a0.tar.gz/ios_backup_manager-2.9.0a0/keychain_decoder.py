import base64
import binascii
import importlib
import os
import re
import sys
from io import BytesIO
from typing import Any, Dict, Optional, Tuple, List

try:
    from Crypto.Cipher import AES
except Exception:
    AES = None

from blob_decoders import decode_unknown_blob

_GCM_R = 0xE1000000000000000000000000000000


def _gf_mul(x: int, y: int) -> int:
    z = 0
    v = y
    for i in range(128):
        if (x >> (127 - i)) & 1:
            z ^= v
        if v & 1:
            v = (v >> 1) ^ _GCM_R
        else:
            v >>= 1
    return z


def _ghash(h: bytes, aad: bytes, ciphertext: bytes) -> bytes:
    h_int = int.from_bytes(h, "big")
    y = 0

    def blocks(data: bytes):
        for i in range(0, len(data), 16):
            block = data[i:i + 16]
            if len(block) < 16:
                block = block + b"\x00" * (16 - len(block))
            yield int.from_bytes(block, "big")

    for block in blocks(aad):
        y = _gf_mul(y ^ block, h_int)
    for block in blocks(ciphertext):
        y = _gf_mul(y ^ block, h_int)

    lengths = (len(aad) * 8 << 64) | (len(ciphertext) * 8)
    y = _gf_mul(y ^ lengths, h_int)
    return y.to_bytes(16, "big")


def _gcm_open_null_iv(key: bytes, ciphertext_with_tag: bytes, aad: bytes) -> Optional[bytes]:
    if AES is None or len(ciphertext_with_tag) < 16:
        return None
    tag = ciphertext_with_tag[-16:]
    ciphertext = ciphertext_with_tag[:-16]
    cipher = AES.new(key, AES.MODE_ECB)
    h = cipher.encrypt(b"\x00" * 16)
    y0 = b"\x00" * 16
    tag_mask = cipher.encrypt(y0)
    expected = _ghash(h, aad, ciphertext)
    expected = bytes(a ^ b for a, b in zip(expected, tag_mask))
    if expected != tag:
        return None

    # CTR decrypt with counter starting at 1 (increment last 32 bits).
    counter = bytearray(16)
    counter[-1] = 1
    out = bytearray()
    for i in range(0, len(ciphertext), 16):
        block = ciphertext[i:i + 16]
        mask = cipher.encrypt(bytes(counter))
        out.extend(bytes(a ^ b for a, b in zip(block, mask[:len(block)])))
        # Increment last 32 bits (big endian).
        for j in range(15, 11, -1):
            counter[j] = (counter[j] + 1) & 0xFF
            if counter[j] != 0:
                break
    return bytes(out)


def _parse_der_length(data: bytes, offset: int) -> Optional[Tuple[int, int]]:
    if offset >= len(data):
        return None
    first = data[offset]
    if first < 0x80:
        return first, offset + 1
    num = first & 0x7F
    if num == 0 or offset + 1 + num > len(data):
        return None
    length = int.from_bytes(data[offset + 1:offset + 1 + num], "big")
    return length, offset + 1 + num


def _parse_der_node(data: bytes, offset: int = 0) -> Optional[Tuple[Dict[str, Any], int]]:
    if offset >= len(data):
        return None
    tag = data[offset]
    offset += 1
    length_info = _parse_der_length(data, offset)
    if length_info is None:
        return None
    length, offset = length_info
    end = offset + length
    if end > len(data):
        return None
    value = data[offset:end]
    node = {
        "tag": tag,
        "value": value,
        "children": [],
    }
    if tag in (0x30, 0x31):  # SEQUENCE or SET
        child_offset = offset
        while child_offset < end:
            child = _parse_der_node(data, child_offset)
            if child is None:
                break
            child_node, child_offset = child
            node["children"].append(child_node)
    return node, end


def _decode_octet_string(value: bytes) -> Any:
    if not value:
        return value
    # Try UTF-8 if mostly printable.
    try:
        text = value.decode("utf-8")
        if "\x00" in text:
            text = text.replace("\x00", "")
        printable = sum(1 for ch in text if ch.isprintable())
        if printable / max(len(text), 1) >= 0.9:
            return text
    except Exception:
        pass
    return value


def _decode_der_value(node: Dict[str, Any]) -> Any:
    tag = node["tag"]
    value = node["value"]
    if tag == 0x01:
        return value != b"\x00"
    if tag == 0x02:
        return int.from_bytes(value, "big", signed=False)
    if tag in (0x0c, 0x13, 0x16):  # UTF8String, PrintableString, IA5String
        try:
            return value.decode("utf-8")
        except Exception:
            return value.decode("latin-1", errors="replace")
    if tag in (0x17, 0x18):  # UTCTime, GeneralizedTime
        try:
            return value.decode("ascii")
        except Exception:
            return value.hex()
    if tag == 0x04:  # OctetString
        return _decode_octet_string(value)
    if tag == 0x05:  # NULL
        return None
    if tag == 0x06:  # OID
        return value.hex()
    if tag in (0x30, 0x31):
        return [_decode_der_value(child) for child in node["children"]]
    return value


def _parse_der_keychain_record(blob: bytes) -> Optional[Dict[str, Any]]:
    root = _parse_der_node(blob, 0)
    if root is None:
        return None
    node, _ = root
    if node["tag"] not in (0x30, 0x31):
        return None
    entries = {}
    field_order = []
    field_types = []
    for child in node["children"]:
        if child["tag"] != 0x30 or len(child["children"]) < 2:
            continue
        key_node = child["children"][0]
        val_node = child["children"][1]
        key = _decode_der_value(key_node)
        if not isinstance(key, str):
            continue
        value = _decode_der_value(val_node)
        entries[key] = value
        field_order.append(key)
        field_types.append(type(value).__name__)
    if not entries:
        return None
    entries["_fieldOrder"] = ",".join(field_order)
    entries["_fieldTypes"] = ",".join(field_types)
    return entries

_KEYCHAIN_PROTO = None


def _load_keychain_proto():
    global _KEYCHAIN_PROTO
    if _KEYCHAIN_PROTO is not None:
        return _KEYCHAIN_PROTO

    _KEYCHAIN_PROTO = {}
    search_path = os.getenv("IBM_KEYCHAIN_DECRYPTER_PATH") or os.getenv("KEYCHAIN_DECRYPTER_PATH")
    if search_path and os.path.isdir(search_path):
        if search_path not in sys.path:
            sys.path.insert(0, search_path)
    def import_pb2(name):
        try:
            return importlib.import_module(name)
        except TypeError:
            # Fallback for older protobuf-generated code.
            os.environ.setdefault("PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION", "python")
            try:
                return importlib.import_module(name)
            except Exception:
                return None
        except Exception:
            return None

    item_pb2 = import_pb2("SecDbKeychainSerializedItemV7_pb2")
    if item_pb2:
        _KEYCHAIN_PROTO["item_pb2"] = item_pb2
    secret_pb2 = import_pb2("SecDbKeychainSerializedSecretData_pb2")
    if secret_pb2:
        _KEYCHAIN_PROTO["secret_pb2"] = secret_pb2
    meta_pb2 = import_pb2("SecDbKeychainSerializedMetadata_pb2")
    if meta_pb2:
        _KEYCHAIN_PROTO["meta_pb2"] = meta_pb2
    wrapped_pb2 = import_pb2("SecDbKeychainSerializedAKSWrappedKey_pb2")
    if wrapped_pb2:
        _KEYCHAIN_PROTO["wrapped_pb2"] = wrapped_pb2
    try:
        import ccl_bplist  # type: ignore
        _KEYCHAIN_PROTO["ccl_bplist"] = ccl_bplist
    except Exception:
        pass
    try:
        from pyasn1.codec.der.decoder import decode as der_decode  # type: ignore
        _KEYCHAIN_PROTO["der_decode"] = der_decode
    except Exception:
        pass

    return _KEYCHAIN_PROTO


def _looks_like_plist(data: bytes) -> bool:
    return data.startswith(b"bplist00") or data.lstrip().startswith(b"<?xml")


def _pkcs7_unpad(data: bytes) -> Optional[bytes]:
    if not data:
        return None
    pad_len = data[-1]
    if pad_len < 1 or pad_len > 16:
        return None
    if data[-pad_len:] != bytes([pad_len]) * pad_len:
        return None
    return data[:-pad_len]


def _score_plaintext(data: bytes) -> int:
    if not data:
        return 0
    if _looks_like_plist(data):
        return 3
    printable = sum(1 for b in data[:128] if 32 <= b <= 126 or b in (9, 10, 13))
    return 2 if printable > 80 else 1


def _parse_record_header(data: bytes) -> Optional[Dict[str, Any]]:
    if len(data) < 12:
        return None
    for endian in ("little", "big"):
        version = int.from_bytes(data[0:4], endian)
        pclass = int.from_bytes(data[4:8], endian)
        key_len = int.from_bytes(data[8:12], endian)
        if key_len <= 0 or key_len > len(data) - 12:
            continue
        if version < 0 or version > 10:
            continue
        wrapped_key = data[12:12 + key_len]
        payload = data[12 + key_len:]
        return {
            "version": version,
            "protection_class": pclass,
            "key_len": key_len,
            "wrapped_key": wrapped_key,
            "payload": payload,
            "endian": endian,
        }
    return None


def _string_hints(data: bytes, max_items: int = 8) -> list:
    if not data:
        return []
    hints = []
    for match in re.finditer(rb"[ -~]{4,}", data):
        try:
            hints.append(match.group(0).decode("utf-8", errors="ignore"))
        except Exception:
            continue
        if len(hints) >= max_items:
            break
    return hints


def _try_decode_nskeyed(blob: bytes):
    decoded = decode_unknown_blob(blob)
    if decoded:
        return decoded.get("value")
    return None


def _try_parse_protobuf(payload: bytes) -> Optional[Dict[str, Any]]:
    proto = _load_keychain_proto()
    item_pb2 = proto.get("item_pb2")
    if not item_pb2:
        return None

    for offset in (0, 4):
        try:
            item = item_pb2.SecDbKeychainSerializedItemV7()
            item.ParseFromString(payload[offset:])
            if not item.ListFields():
                continue
            info = {
                "offset": offset,
                "keyclass": getattr(item, "keyclass", None),
                "has_secret": bool(getattr(item, "encryptedSecretData", b"")),
                "has_metadata": bool(getattr(item, "encryptedMetadata", b"")),
                "secret_len": len(getattr(item, "encryptedSecretData", b"")),
                "metadata_len": len(getattr(item, "encryptedMetadata", b"")),
                "item": item,
            }
            return info
        except Exception:
            continue
    return None


def _find_embedded_bplist(data: bytes) -> Optional[Dict[str, Any]]:
    if not data:
        return None
    idx = data.find(b"bplist00")
    if idx < 0:
        return None
    blob = data[idx:]
    decoded = decode_unknown_blob(blob)
    if decoded:
        value = decoded.get("value")
        if isinstance(value, dict):
            return {"keys": list(value.keys())[:20]}
        return {"type": type(value).__name__}
    return None


def _decode_gcm_bplist(blob: bytes, key: bytes) -> Optional[bytes]:
    proto = _load_keychain_proto()
    ccl_bplist = proto.get("ccl_bplist")
    if ccl_bplist is None or AES is None:
        return None
    try:
        plist_obj = ccl_bplist.load(BytesIO(blob))
        decoded_bplist = ccl_bplist.deserialise_NsKeyedArchiver(plist_obj, parse_whole_structure=True)
        root = decoded_bplist.get("root", {})
        iv = root.get("SFInitializationVector")
        ct = root.get("SFCiphertext")
        tag = root.get("SFAuthenticationCode")
        if not iv or not ct or not tag:
            return None
        gcm = AES.new(key[:32], AES.MODE_GCM, nonce=iv)
        return gcm.decrypt_and_verify(ct, tag)
    except Exception:
        return None


def _decode_proto_payload(payload: bytes, keybag) -> Optional[Dict[str, Any]]:
    proto = _load_keychain_proto()
    item_pb2 = proto.get("item_pb2")
    secret_pb2 = proto.get("secret_pb2")
    meta_pb2 = proto.get("meta_pb2")
    wrapped_pb2 = proto.get("wrapped_pb2")
    der_decode = proto.get("der_decode")
    if not item_pb2 or not secret_pb2 or not wrapped_pb2:
        return None

    info = _try_parse_protobuf(payload)
    if not info:
        return None
    item = info.get("item")
    keyclass = getattr(item, "keyclass", None)
    result = {
        "offset": info.get("offset"),
        "keyclass": keyclass,
        "has_secret": bool(getattr(item, "encryptedSecretData", b"")),
        "has_metadata": bool(getattr(item, "encryptedMetadata", b"")),
        "secret_len": len(getattr(item, "encryptedSecretData", b"")),
        "metadata_len": len(getattr(item, "encryptedMetadata", b"")),
    }

    # Decrypt secret data
    try:
        if getattr(item, "encryptedSecretData", b""):
            secret = secret_pb2.SecDbKeychainSerializedSecretData()
            secret.ParseFromString(item.encryptedSecretData)
            wrapped = wrapped_pb2.SecDbKeychainSerializedAKSWrappedKey()
            wrapped.ParseFromString(secret.wrappedKey)
            inner_secret = keybag.unwrapKeyForClass(keyclass, wrapped.wrappedKey)
            if inner_secret:
                secret_plain = _decode_gcm_bplist(secret.ciphertext, inner_secret)
                if secret_plain:
                    result["secret_preview"] = _hex_preview(secret_plain)
                    result["secret_string_hints"] = _string_hints(secret_plain, max_items=6)
                    if der_decode:
                        try:
                            der_obj = der_decode(secret_plain)[0]
                            result["secret_der"] = str(der_obj)
                        except Exception:
                            pass
    except Exception:
        pass

    # Decrypt metadata (best-effort)
    try:
        if meta_pb2 and getattr(item, "encryptedMetadata", b""):
            meta = meta_pb2.SecDbKeychainSerializedMetadata()
            meta.ParseFromString(item.encryptedMetadata)
            wrapped_meta = wrapped_pb2.SecDbKeychainSerializedAKSWrappedKey()
            wrapped_meta.ParseFromString(meta.wrappedKey)
            inner_meta = keybag.unwrapKeyForClass(keyclass, wrapped_meta.wrappedKey)
            if inner_meta:
                meta_plain = _decode_gcm_bplist(meta.ciphertext, inner_meta)
                if meta_plain:
                    result["metadata_preview"] = _hex_preview(meta_plain)
                    result["metadata_string_hints"] = _string_hints(meta_plain, max_items=6)
                    if der_decode:
                        try:
                            der_obj = der_decode(meta_plain)[0]
                            result["metadata_der"] = str(der_obj)
                        except Exception:
                            pass
    except Exception:
        pass

    return result


def _try_decrypt_payload(
    inner_key: bytes,
    payload: bytes,
    require_gcm: bool = False,
    aad_candidates: Optional[List[bytes]] = None,
) -> Tuple[Optional[bytes], Optional[str]]:
    if AES is None:
        return None, "crypto_unavailable"

    attempts = []

    def _add_gcm(mode: str, nonce: bytes, ciphertext: bytes, tag: bytes) -> None:
        attempts.append((mode, nonce, ciphertext + tag, len(tag)))

    # AES-GCM nonce prefix (12-byte), tag suffix
    if len(payload) >= 28:
        _add_gcm("gcm_nonce_12_tag_suffix_16", payload[:12], payload[12:-16], payload[-16:])
        if len(payload) >= 24:
            _add_gcm("gcm_nonce_12_tag_suffix_12", payload[:12], payload[12:-12], payload[-12:])

    # AES-GCM empty nonce, tag suffix (Apple keychain backup uses null IV)
    if len(payload) >= 16:
        _add_gcm("gcm_nonce_empty_tag_suffix_16", b"", payload[:-16], payload[-16:])

    # AES-GCM nonce prefix (16-byte), tag suffix
    if len(payload) >= 32:
        _add_gcm("gcm_nonce_16_tag_suffix_16", payload[:16], payload[16:-16], payload[-16:])
        if len(payload) >= 28:
            _add_gcm("gcm_nonce_16_tag_suffix_12", payload[:16], payload[16:-12], payload[-12:])

    # AES-GCM nonce prefix (12-byte), tag prefix
    if len(payload) >= 28:
        nonce = payload[:12]
        tag = payload[12:28]
        ct = payload[28:]
        _add_gcm("gcm_nonce_12_tag_prefix_16", nonce, ct, tag)
        tag = payload[12:24]
        ct = payload[24:]
        _add_gcm("gcm_nonce_12_tag_prefix_12", nonce, ct, tag)

    # AES-GCM nonce prefix (16-byte), tag prefix
    if len(payload) >= 32:
        nonce = payload[:16]
        tag = payload[16:32]
        ct = payload[32:]
        _add_gcm("gcm_nonce_16_tag_prefix_16", nonce, ct, tag)
        tag = payload[16:28]
        ct = payload[28:]
        _add_gcm("gcm_nonce_16_tag_prefix_12", nonce, ct, tag)

    # AES-GCM tag prefix (16-byte), nonce after tag (12/16)
    if len(payload) >= 44:
        tag = payload[:16]
        nonce = payload[16:28]
        ct = payload[28:]
        _add_gcm("gcm_tag_prefix_nonce12", nonce, ct, tag)
    if len(payload) >= 48:
        tag = payload[:16]
        nonce = payload[16:32]
        ct = payload[32:]
        _add_gcm("gcm_tag_prefix_nonce16", nonce, ct, tag)

    # AES-GCM nonce suffix (12/16), tag suffix (16/12)
    if len(payload) >= 28:
        nonce = payload[-28:-16]
        tag = payload[-16:]
        ct = payload[:-28]
        _add_gcm("gcm_nonce_suffix12_tag_suffix16", nonce, ct, tag)
    if len(payload) >= 24:
        nonce = payload[-24:-12]
        tag = payload[-12:]
        ct = payload[:-24]
        _add_gcm("gcm_nonce_suffix12_tag_suffix12", nonce, ct, tag)
    if len(payload) >= 32:
        nonce = payload[-32:-16]
        tag = payload[-16:]
        ct = payload[:-32]
        _add_gcm("gcm_nonce_suffix16_tag_suffix16", nonce, ct, tag)

    # AES-GCM tag prefix (16), nonce suffix (12/16)
    if len(payload) >= 28:
        tag = payload[:16]
        nonce = payload[-12:]
        ct = payload[16:-12]
        _add_gcm("gcm_tag_prefix_nonce_suffix12", nonce, ct, tag)
    if len(payload) >= 32:
        tag = payload[:16]
        nonce = payload[-16:]
        ct = payload[16:-16]
        _add_gcm("gcm_tag_prefix_nonce_suffix16", nonce, ct, tag)

    if not require_gcm:
        # AES-CBC with zero IV
        if len(payload) % 16 == 0:
            attempts.append(("cbc_zero_iv", b"\x00" * 16, payload, None))

        # AES-CBC with IV prefix
        if len(payload) >= 32 and (len(payload) - 16) % 16 == 0:
            attempts.append(("cbc_iv_prefix", payload[:16], payload[16:], None))

        # AES-CTR with IV prefix
        if len(payload) >= 16:
            attempts.append(("ctr_iv_prefix", payload[:16], payload[16:], None))

    best = None
    best_mode = None
    best_score = 0
    aad_candidates = aad_candidates or [b""]

    for mode, iv, ct, tag_len in attempts:
        try:
            if mode.startswith("cbc"):
                pt = AES.new(inner_key, AES.MODE_CBC, iv).decrypt(ct)
                unpadded = _pkcs7_unpad(pt)
                candidate = unpadded if unpadded is not None else pt
            elif mode == "ctr_iv_prefix":
                initial = int.from_bytes(iv, "big")
                pt = AES.new(inner_key, AES.MODE_CTR, nonce=b"", initial_value=initial).decrypt(ct)
                candidate = pt
            else:
                # GCM: ct includes tag at end
                tag_size = tag_len or 16
                if len(ct) < tag_size:
                    continue
                if mode == "gcm_nonce_empty_tag_suffix_16" and tag_size == 16:
                    candidate = None
                    for aad in aad_candidates:
                        pt = _gcm_open_null_iv(inner_key, ct, aad)
                        if pt is not None:
                            candidate = pt
                            break
                    if candidate is None:
                        continue
                else:
                    tag = ct[-tag_size:]
                    ciphertext = ct[:-tag_size]
                    candidate = None
                    for aad in aad_candidates:
                        gcm = AES.new(inner_key, AES.MODE_GCM, nonce=iv, mac_len=tag_size)
                        if aad:
                            gcm.update(aad)
                        pt = gcm.decrypt_and_verify(ciphertext, tag)
                        candidate = pt
                        if candidate is not None:
                            break
                    if candidate is None:
                        continue
            score = _score_plaintext(candidate)
            if score > best_score:
                best_score = score
                best = candidate
                best_mode = mode
            if score >= 3:
                break
        except Exception:
            continue

    return best, best_mode


def _normalize_decoded(value: Any) -> Dict[str, Any]:
    if isinstance(value, dict):
        normalized = {}
        for key, val in value.items():
            if isinstance(key, bytes):
                key_str = key.decode("utf-8", errors="ignore")
            else:
                key_str = str(key)
            normalized[key_str] = val
        return normalized
    return {"value": value}


def _hex_preview(data: bytes, max_len: int = 32) -> str:
    if not data:
        return ""
    return binascii.hexlify(data[:max_len]).decode("ascii")


def decode_keychain_item(
    data: bytes,
    keybag=None,
    include_plaintext: bool = False,
    aad_extra: Optional[bytes] = None,
) -> Dict[str, Any]:
    """
    Decode a keychain backup v_Data blob.

    Returns a dict with:
      status: plaintext|decrypted|opaque|no_keybag|unwrap_failed|invalid|crypto_unavailable
      decoded: normalized dict (if decoded)
      raw_preview: hex preview of plaintext or payload
    """
    if not data:
        return {"status": "invalid", "raw_preview": ""}

    if _looks_like_plist(data):
        decoded = decode_unknown_blob(data)
        if decoded:
            return {
                "status": "plaintext",
                "decoded": _normalize_decoded(decoded.get("value")),
                "decoded_format": decoded.get("format"),
                "raw_preview": _hex_preview(data),
            }
        return {"status": "opaque", "raw_preview": _hex_preview(data)}

    if keybag is not None:
        proto_decoded = _decode_proto_payload(data, keybag)
        if proto_decoded:
            result = {
                "status": "proto",
                "raw_preview": _hex_preview(data),
                "protobuf": proto_decoded,
                "string_hints": _string_hints(data),
            }
            if include_plaintext:
                result["plaintext_b64"] = base64.b64encode(data).decode("ascii")
            return result

    header = _parse_record_header(data)
    if not header:
        return {"status": "invalid", "raw_preview": _hex_preview(data)}

    payload = header["payload"]
    result = {
        "status": "opaque",
        "version": header["version"],
        "protection_class": header["protection_class"],
        "key_len": header["key_len"],
        "payload_len": len(payload),
        "raw_preview": _hex_preview(payload),
        "header": {
            "version": header["version"],
            "protection_class": header["protection_class"],
            "key_len": header["key_len"],
            "endian": header["endian"],
        },
    }
    if include_plaintext:
        result["wrapped_key_b64"] = base64.b64encode(header["wrapped_key"]).decode("ascii")
        result["payload_b64"] = base64.b64encode(payload).decode("ascii")

    if keybag is None:
        result["status"] = "no_keybag"
        return result

    try:
        inner_key = keybag.unwrapKeyForClass(header["protection_class"], header["wrapped_key"])
    except Exception:
        inner_key = None

    if not inner_key:
        result["status"] = "unwrap_failed"
        return result

    header_bytes = data[:12]
    aad_candidates = [b"", header_bytes, header_bytes + header["wrapped_key"]]
    if aad_extra:
        aad_candidates.append(aad_extra)
        aad_candidates.append(header_bytes + aad_extra)
    plaintext, mode = _try_decrypt_payload(
        inner_key,
        payload,
        require_gcm=True,
        aad_candidates=aad_candidates,
    )
    if plaintext is None:
        result["status"] = "crypto_unavailable" if AES is None else "opaque"
        return result

    if include_plaintext:
        result["plaintext_b64"] = base64.b64encode(plaintext).decode("ascii")

    proto_info = _decode_proto_payload(plaintext, keybag)
    if proto_info:
        result["protobuf"] = proto_info

    der_record = _parse_der_keychain_record(plaintext)
    if der_record:
        result.update({
            "status": "decrypted",
            "decoded": _normalize_decoded(der_record),
            "decoded_format": "der",
            "decrypt_mode": mode,
            "raw_preview": _hex_preview(plaintext),
            "string_hints": _string_hints(plaintext),
        })
        return result

    decoded = decode_unknown_blob(plaintext)
    if decoded:
        result.update({
            "status": "decrypted",
            "decoded": _normalize_decoded(decoded.get("value")),
            "decoded_format": decoded.get("format"),
            "decrypt_mode": mode,
            "raw_preview": _hex_preview(plaintext),
            "string_hints": _string_hints(plaintext),
        })
    else:
        result.update({
            "status": "decrypted",
            "decrypt_mode": mode,
            "raw_preview": _hex_preview(plaintext),
            "string_hints": _string_hints(plaintext),
        })
        embedded = _find_embedded_bplist(plaintext)
        if embedded:
            result["embedded_bplist"] = embedded

    if proto_info:
        if proto_info.get("secret_string_hints"):
            result["secret_string_hints"] = proto_info.get("secret_string_hints")
        if proto_info.get("metadata_string_hints"):
            result["metadata_string_hints"] = proto_info.get("metadata_string_hints")
    return result
