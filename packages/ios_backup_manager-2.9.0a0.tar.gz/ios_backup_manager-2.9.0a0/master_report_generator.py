import os
import sys
import plistlib
import hashlib
import sqlite3
import shutil
from datetime import datetime
from urllib.parse import quote
from typing import Optional, List


def _normalize_url_path(path: str) -> str:
    return quote(path.replace("\\", "/"))


def _safe_load_plist(path: str) -> dict:
    if not path or not os.path.exists(path):
        return {}
    try:
        with open(path, "rb") as f:
            return plistlib.load(f)
    except Exception:
        return {}


def _get_plist_value(info: dict, status: dict, keys: List[str]) -> str:
    for key in keys:
        if key in info and info.get(key) not in (None, ""):
            return str(info.get(key))
        if key in status and status.get(key) not in (None, ""):
            return str(status.get(key))
    return ""


def _find_accounts_db_path(backup_path: str, backup_access=None) -> str:
    rel_path = "Library/Accounts/Accounts3.sqlite"
    if backup_access is not None:
        path = backup_access.get_file_path("HomeDomain", rel_path)
        if path and os.path.exists(path):
            return path
    file_id = hashlib.sha1(f"HomeDomain-{rel_path}".encode()).hexdigest()
    path = os.path.join(backup_path, file_id[:2], file_id)
    return path if os.path.exists(path) else ""


def _find_apple_id_from_accounts(backup_path: str, backup_access=None) -> str:
    path = _find_accounts_db_path(backup_path, backup_access=backup_access)
    if not path:
        return ""
    try:
        conn = sqlite3.connect(path)
        cur = conn.cursor()
        cur.execute("SELECT Z_PK, ZIDENTIFIER FROM ZACCOUNTTYPE")
        acct_types = {row[0]: row[1] for row in cur.fetchall()}
        cur.execute("SELECT ZUSERNAME, ZACCOUNTTYPE FROM ZACCOUNT WHERE ZUSERNAME IS NOT NULL")
        rows = cur.fetchall()
        conn.close()
    except Exception:
        return ""

    apple_accounts = []
    for username, type_id in rows:
        ident = acct_types.get(type_id, "") or ""
        if "AppleAccount" in ident:
            apple_accounts.append(str(username))
    if not apple_accounts:
        return ""
    for candidate in apple_accounts:
        if "@icloud.com" in candidate.lower():
            return candidate
    return apple_accounts[0]


def _find_commcenter_plist(backup_path: str, backup_access=None) -> dict:
    rel_path = "Library/Preferences/com.apple.commcenter.plist"
    path = ""
    if backup_access is not None:
        path = backup_access.get_file_path("WirelessDomain", rel_path)
    if not path:
        file_id = hashlib.sha1(f"WirelessDomain-{rel_path}".encode()).hexdigest()
        candidate = os.path.join(backup_path, file_id[:2], file_id)
        if os.path.exists(candidate):
            path = candidate
    if not path or not os.path.exists(path):
        return {}
    try:
        with open(path, "rb") as f:
            data = plistlib.load(f)
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}



def _get_device_info(backup_path: str, backup_access=None) -> dict:
    info_path = os.path.join(backup_path, "Info.plist")
    status_path = os.path.join(backup_path, "Status.plist")
    manifest_path = os.path.join(backup_path, "Manifest.plist")
    info = _safe_load_plist(info_path)
    status = _safe_load_plist(status_path)
    manifest = _safe_load_plist(manifest_path)
    device_name = info.get("Device Name", "Unknown Device")
    product_type = info.get("Product Type", "Unknown")
    ios_version = info.get("Product Version", "Unknown")
    build_version = info.get("Build Version", "Unknown")
    udid = _get_plist_value(info, status, ["Unique Identifier", "Target Identifier", "UniqueDeviceID"])
    serial = _get_plist_value(info, status, ["Serial Number", "SerialNumber"])
    apple_id = _get_plist_value(info, status, ["Apple ID", "AppleID", "AppleId"])
    if not apple_id:
        apple_id = _find_apple_id_from_accounts(backup_path, backup_access=backup_access)
    phone = _get_plist_value(info, status, ["Phone Number", "PhoneNumber"])
    phone2 = _get_plist_value(info, status, ["Phone Number 2", "PhoneNumber2"])
    encrypted = bool(manifest.get("IsEncrypted", False)) if isinstance(manifest, dict) else False
    commcenter = _find_commcenter_plist(backup_path, backup_access=backup_access)
    iccid = _get_plist_value(info, status, ["ICCID", "Last ICCID", "LastICCID"])
    if not iccid:
        iccid = str(commcenter.get("LastKnownICCID") or commcenter.get("NetworkPhoneNumberICCID") or "")
    if not phone:
        phone = str(commcenter.get("SIMPhoneNumber") or commcenter.get("PhoneNumber") or commcenter.get("NetworkPhoneNumber") or "")
    try:
        from backup_merger_gui import get_device_model
        device_model = get_device_model(product_type)
    except Exception:
        device_model = "Unknown"
    return {
        "device_name": device_name,
        "product_type": product_type,
        "ios_version": ios_version,
        "build_version": build_version,
        "device_model": device_model,
        "udid": udid,
        "serial": serial,
        "apple_id": apple_id,
        "iccid": iccid,
        "phone": phone,
        "phone2": phone2,
        "encrypted": encrypted,
    }


def _find_wallpaper_in_backup(backup_path: str, backup_access=None) -> str:
    manifest_db = os.path.join(backup_path, "Manifest.db")
    if backup_access is not None:
        manifest_db = backup_access.manifest_db_path
    if not os.path.exists(manifest_db):
        return ""

    wallpaper_paths = [
        "Library/SpringBoard/HomeBackground.jpg",
        "Library/SpringBoard/LockBackground.jpg",
        "Library/SpringBoard/HomeBackground.png",
        "Library/SpringBoard/LockBackground.png",
        "Library/SpringBoard/LockBackgroundThumbnail.jpg",
    ]

    for relpath in wallpaper_paths:
        if backup_access is not None:
            file_path = backup_access.get_file_path("HomeDomain", relpath)
        else:
            file_id = hashlib.sha1(f"HomeDomain-{relpath}".encode()).hexdigest()
            file_path = os.path.join(backup_path, file_id[:2], file_id)
        if file_path and os.path.exists(file_path):
            return file_path

    try:
        conn = sqlite3.connect(manifest_db)
        cur = conn.cursor()
        cur.execute(
            "SELECT fileID, relativePath FROM Files WHERE relativePath LIKE '%SpringBoard%' "
            "AND (relativePath LIKE '%.jpg' OR relativePath LIKE '%.png') LIMIT 1"
        )
        row = cur.fetchone()
        conn.close()
        if row:
            file_id = row[0]
            if backup_access is not None:
                file_path = backup_access.get_file_path_by_id(file_id)
            else:
                file_path = os.path.join(backup_path, file_id[:2], file_id)
            if file_path and os.path.exists(file_path):
                return file_path
    except Exception:
        return ""

    return ""


def _default_wallpaper_path(is_ipad: bool) -> str:
    script_dir = os.path.dirname(os.path.abspath(__file__))
    resources = os.path.join(script_dir, "resources")

    candidates = []
    if is_ipad:
        candidates.extend([
            os.path.join(resources, "default_wallpaper_ipad.png"),
            os.path.join(resources, "default_wallpaper_ipad.jpg"),
        ])
    candidates.extend([
        os.path.join(resources, "default_wallpaper.png"),
        os.path.join(resources, "default_wallpaper.jpg"),
    ])
    for path in candidates:
        if os.path.exists(path):
            return path
    return ""


def _copy_wallpaper(backup_path: str, output_base_dir: str, product_type: str, backup_access=None) -> str:
    source_path = _find_wallpaper_in_backup(backup_path, backup_access=backup_access)
    if not source_path:
        is_ipad = str(product_type).lower().startswith("ipad")
        source_path = _default_wallpaper_path(is_ipad)
    if not source_path:
        return ""

    ext = os.path.splitext(source_path)[1].lower() or ".jpg"
    dest_dir = os.path.join(output_base_dir, "Photos & Videos", "Wallpaper")
    os.makedirs(dest_dir, exist_ok=True)
    dest_path = os.path.join(dest_dir, f"_wallpaper{ext}")
    try:
        shutil.copy2(source_path, dest_path)
    except Exception:
        return ""
    rel_path = os.path.relpath(dest_path, output_base_dir)
    return _normalize_url_path(rel_path)


def _format_count(value: int) -> str:
    try:
        return f"{int(value):,}"
    except Exception:
        return str(value)


def _format_storage_estimate(value) -> str:
    if value is None:
        return "Unknown"
    if isinstance(value, str):
        cleaned = value.strip()
        return cleaned if cleaned else "Unknown"
    try:
        bytes_value = float(value)
    except Exception:
        return "Unknown"
    if bytes_value <= 0:
        return "Unknown"
    gb = bytes_value / (1024 ** 3)
    if gb >= 1:
        return f"{gb:.1f} GB"
    mb = bytes_value / (1024 ** 2)
    if mb >= 1:
        return f"{mb:.1f} MB"
    kb = bytes_value / 1024
    return f"{kb:.1f} KB"


def _format_datetime(value: Optional[float]) -> str:
    if not value:
        return "Unknown"
    try:
        return datetime.fromtimestamp(value).strftime("%m-%d-%Y %I:%M %p")
    except Exception:
        return "Unknown"


def _format_duration(seconds: float) -> str:
    try:
        seconds = int(seconds)
    except Exception:
        return "Unknown"
    if seconds <= 0:
        return "Unknown"
    minutes, sec = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    if hours:
        return f"{hours}h {minutes}m {sec}s"
    if minutes:
        return f"{minutes}m {sec}s"
    return f"{sec}s"

def _format_app_version(app_version: str, build_number: str) -> str:
    app_version = app_version or "Unknown"
    build_number = (build_number or "").strip()
    if build_number:
        return f"{app_version} (Build {build_number})"
    return app_version


def _build_extraction_summary(summary: dict, options: dict, device_info_link: str, device_info: dict) -> str:
    extraction_type = options.get("extraction_type", "Full")
    timezone = options.get("timezone") or datetime.now().astimezone().tzname() or "Local"
    app_version = options.get("app_version") or "Unknown"
    build_number = options.get("build_number") or ""
    display_version = _format_app_version(app_version, build_number)
    start_ts = summary.get("start_time")
    end_ts = summary.get("end_time")
    duration = _format_duration(summary.get("duration", 0))
    udid = device_info.get("udid") or "Unknown"
    serial = device_info.get("serial") or "Unknown"
    apple_id = device_info.get("apple_id") or "Unknown"
    phone = device_info.get("phone") or "Unknown"
    phone2 = device_info.get("phone2") or "Unknown"
    encrypted = "Yes" if device_info.get("encrypted") else "No"

    case_info = options.get("case_info") or {}
    case_rows = []
    for key, label in [
        ("case_number", "Case Number"),
        ("evidence_number", "Evidence Number"),
        ("examiner", "Examiner"),
        ("department", "Department"),
        ("location", "Location"),
    ]:
        value = case_info.get(key)
        if value:
            case_rows.append(f"<div class=\"summary-field\"><span>{label}</span><strong>{value}</strong></div>")

    case_html = ""
    if case_rows:
        case_html = f"<div class=\"summary-grid\">{''.join(case_rows)}</div>"

    return f"""
    <div class="summary-card">
        <div class="summary-row">
            <div>
                <div class="summary-title">Extraction Summary</div>
                <div class="summary-sub">{extraction_type} extraction - {timezone}</div>
            </div>
            <a class="summary-link device-info-link" href="{device_info_link}">Full Device Information</a>
        </div>
        <div class="summary-grid">
            <div class="summary-field"><span>Unique Identifier</span><strong>{udid}</strong></div>
            <div class="summary-field"><span>Serial Number</span><strong>{serial}</strong></div>
            <div class="summary-field"><span>Apple ID</span><strong>{apple_id}</strong></div>
            <div class="summary-field"><span>Phone Number</span><strong>{phone}</strong></div>
        </div>
        <details class="summary-details">
            <summary>Show more</summary>
            <div class="summary-grid">
                <div class="summary-field"><span>Start Time</span><strong>{_format_datetime(start_ts)}</strong></div>
                <div class="summary-field"><span>End Time</span><strong>{_format_datetime(end_ts)}</strong></div>
                <div class="summary-field"><span>Duration</span><strong>{duration}</strong></div>
                <div class="summary-field"><span>Software Version</span><strong>{display_version}</strong></div>
            </div>
            {case_html}
        </details>
    </div>
    """


def _get_report_map():
    return {
        "photos": "Photos_and_Videos.html",
        "sms": "Messages.html",
        "whatsapp": "WhatsApp.html",
        "viber": "Viber.html",
        "kik": "Kik.html",
        "line": "Line.html",
        "contacts": "Contacts.html",
        "notes": "Notes.html",
        "calendar": "Calendar.html",
        "reminders": "Reminders.html",
        "significant_locations": "Significant_Locations.html",
        "documents": "Documents.html",
        "safari": "Safari.html",
        "browsers": "Browsers.html",
        "timeline": "Timeline.html",
        "voicemail": "Voicemail.html",
        "voice_memos": "Voice_Memos.html",
        "call_history": "Call_History.html",
        "messenger": "Messenger.html",
        "instagram": "Instagram.html",
        "snapchat": "Snapchat.html",
        "screen_time": "Screen_Time.html",
        "health_fitness": "Health_Fitness.html",
        "passwords": "Passwords.html",
        "device_information": "Device_Information.html",
        "audit": os.path.join("Audit", "Audit_Summary.html"),
    }


def _get_units():
    return {
        "photos": "items",
        "sms": "conversations",
        "whatsapp": "conversations",
        "viber": "conversations",
        "kik": "conversations",
        "line": "conversations",
        "contacts": "entries",
        "notes": "notes",
        "calendar": "events",
        "reminders": "reminders",
        "significant_locations": "locations",
        "documents": "files",
        "safari": "bookmarks",
        "browsers": "items",
        "timeline": "events",
        "voicemail": "voicemails",
        "voice_memos": "recordings",
        "call_history": "calls",
        "messenger": "conversations",
        "instagram": "conversations",
        "snapchat": "items",
        "screen_time": "apps",
        "health_fitness": "entries",
        "passwords": "items",
    }


def _get_display_names():
    return {
        "photos": "Photos & Videos",
        "sms": "Messages",
        "whatsapp": "WhatsApp",
        "viber": "Viber",
        "kik": "Kik",
        "line": "LINE",
        "contacts": "Contacts",
        "notes": "Notes",
        "calendar": "Calendar",
        "reminders": "Reminders",
        "significant_locations": "Significant Locations",
        "documents": "Documents",
        "safari": "Safari Bookmarks",
        "browsers": "Browsers",
        "timeline": "Timeline",
        "voicemail": "Voicemail",
        "voice_memos": "Voice Memos",
        "call_history": "Call History",
        "messenger": "Messenger",
        "instagram": "Instagram",
        "snapchat": "Snapchat",
        "screen_time": "Screen Time",
        "health_fitness": "Health & Fitness",
        "passwords": "Passwords",
    }


def _get_photos_report_count(output_base_dir: str) -> Optional[int]:
    report_path = os.path.join(output_base_dir, "Photos & Videos", "Photos_and_Videos.html")
    if not os.path.exists(report_path):
        return None
    try:
        with open(report_path, "r", encoding="utf-8", errors="ignore") as f:
            html = f.read()
        # Look for JSON script blocks (items + albums). Use the largest list as item count.
        import re
        import json

        matches = re.findall(r"<script[^>]*type=\"application/json\"[^>]*>(.*?)</script>", html, re.DOTALL | re.IGNORECASE)
        best = None
        for blob in matches:
            blob = blob.strip()
            if not blob:
                continue
            try:
                data = json.loads(blob)
            except Exception:
                continue
            if isinstance(data, list):
                size = len(data)
                if best is None or size > best:
                    best = size
        return best
    except Exception:
        return None


def _get_device_labels():
    return {
        "photos": "Photos",
        "sms": "Messages",
        "whatsapp": "WhatsApp",
        "viber": "Viber",
        "kik": "Kik",
        "line": "LINE",
        "contacts": "Contacts",
        "notes": "Notes",
        "calendar": "Calendar",
        "reminders": "Reminders",
        "significant_locations": "Locations",
        "documents": "Documents",
        "safari": "Safari",
        "browsers": "Browsers",
        "timeline": "Timeline",
        "voicemail": "Voicemail",
        "voice_memos": "Voice Memos",
        "call_history": "Call History",
        "messenger": "Messenger",
        "instagram": "Instagram",
        "snapchat": "Snapchat",
        "screen_time": "Screen Time",
        "health_fitness": "Health",
        "passwords": "Passwords",
    }


def _get_icon_data():
    return {
        "photos": {
            "gradient": "linear-gradient(135deg,#667eea,#764ba2)",
            "svg_tile": "<svg width=\"26\" height=\"26\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M4 7h16v10H4z\" stroke=\"#fff\" stroke-width=\"1.5\" /><circle cx=\"9\" cy=\"11\" r=\"2\" fill=\"#fff\" /><path d=\"M4 15l4-3 3 2 3-3 6 4\" stroke=\"#fff\" stroke-width=\"1.5\" fill=\"none\"/></svg>",
            "svg_app": "<svg width=\"30\" height=\"30\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M12 6v12M6 12h12\" stroke=\"#fff\" stroke-width=\"1.6\"/><circle cx=\"12\" cy=\"12\" r=\"5\" stroke=\"#fff\" stroke-width=\"1.6\"/></svg>",
        },
        "sms": {
            "gradient": "linear-gradient(135deg,#20C83E,#60F67B)",
            "svg_tile": "<svg width=\"26\" height=\"26\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M4 6h16v9H7l-3 3z\" stroke=\"#fff\" stroke-width=\"1.5\"/><circle cx=\"9\" cy=\"10\" r=\"1\" fill=\"#fff\"/><circle cx=\"13\" cy=\"10\" r=\"1\" fill=\"#fff\"/><circle cx=\"17\" cy=\"10\" r=\"1\" fill=\"#fff\"/></svg>",
            "svg_app": "<svg width=\"30\" height=\"30\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M4 6h16v9H7l-3 3z\" stroke=\"#fff\" stroke-width=\"1.6\"/><circle cx=\"9\" cy=\"10\" r=\"1\" fill=\"#fff\"/><circle cx=\"13\" cy=\"10\" r=\"1\" fill=\"#fff\"/><circle cx=\"17\" cy=\"10\" r=\"1\" fill=\"#fff\"/></svg>",
        },
        "whatsapp": {
            "gradient": "linear-gradient(135deg,#09BC26,#68FC82)",
            "svg_tile": "<svg width=\"26\" height=\"26\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M12 4a7 7 0 0 0-6 10.6L5 20l5.6-1A7 7 0 1 0 12 4z\" stroke=\"#fff\" stroke-width=\"1.5\"/><path d=\"M9 9.5c1.5 2.5 3 3.5 5.5 4.5\" stroke=\"#fff\" stroke-width=\"1.5\"/></svg>",
            "svg_app": "<svg width=\"30\" height=\"30\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M12 4a7 7 0 0 0-6 10.6L5 20l5.6-1A7 7 0 1 0 12 4z\" stroke=\"#fff\" stroke-width=\"1.6\"/><path d=\"M9 9.5c1.5 2.5 3 3.5 5.5 4.5\" stroke=\"#fff\" stroke-width=\"1.6\"/></svg>",
        },
        "viber": {
            "gradient": "linear-gradient(135deg,#7f3bdc,#b978ff)",
            "svg_tile": "<svg width=\"26\" height=\"26\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M4 6h16v9H7l-3 3V6z\" stroke=\"#fff\" stroke-width=\"1.5\" fill=\"none\"/></svg>",
            "svg_app": "<svg width=\"30\" height=\"30\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M4 6h16v9H7l-3 3V6z\" stroke=\"#fff\" stroke-width=\"1.6\" fill=\"none\"/></svg>",
        },
        "kik": {
            "gradient": "linear-gradient(135deg,#00c6ff,#0072ff)",
            "svg_tile": "<svg width=\"26\" height=\"26\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M4 6h16v9H7l-3 3V6z\" stroke=\"#fff\" stroke-width=\"1.5\" fill=\"none\"/></svg>",
            "svg_app": "<svg width=\"30\" height=\"30\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M4 6h16v9H7l-3 3V6z\" stroke=\"#fff\" stroke-width=\"1.6\" fill=\"none\"/></svg>",
        },
        "line": {
            "gradient": "linear-gradient(135deg,#19c25e,#4be47f)",
            "svg_tile": "<svg width=\"26\" height=\"26\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M4 7h16v8H8l-4 3V7z\" stroke=\"#fff\" stroke-width=\"1.5\" fill=\"none\"/></svg>",
            "svg_app": "<svg width=\"30\" height=\"30\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M4 7h16v8H8l-4 3V7z\" stroke=\"#fff\" stroke-width=\"1.6\" fill=\"none\"/></svg>",
        },
        "contacts": {
            "gradient": "linear-gradient(135deg,#007AFF,#007AFF)",
            "svg_tile": "<svg width=\"26\" height=\"26\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><circle cx=\"12\" cy=\"9\" r=\"3\" stroke=\"#fff\" stroke-width=\"1.5\"/><path d=\"M6 19c1.5-3 10.5-3 12 0\" stroke=\"#fff\" stroke-width=\"1.5\"/></svg>",
            "svg_app": "<svg width=\"30\" height=\"30\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><circle cx=\"12\" cy=\"9\" r=\"3\" stroke=\"#fff\" stroke-width=\"1.6\"/><path d=\"M6 19c1.5-3 10.5-3 12 0\" stroke=\"#fff\" stroke-width=\"1.6\"/></svg>",
        },
        "notes": {
            "gradient": "linear-gradient(135deg,#E4A711,#FFF238)",
            "svg_tile": "<svg width=\"26\" height=\"26\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M6 4h9l3 3v13H6z\" stroke=\"#fff\" stroke-width=\"1.5\"/><path d=\"M9 10h6M9 14h6\" stroke=\"#fff\" stroke-width=\"1.5\"/></svg>",
            "svg_app": "<svg width=\"30\" height=\"30\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M6 4h9l3 3v13H6z\" stroke=\"#fff\" stroke-width=\"1.6\"/><path d=\"M9 10h6M9 14h6\" stroke=\"#fff\" stroke-width=\"1.6\"/></svg>",
        },
        "calendar": {
            "gradient": "linear-gradient(135deg,#1BADF8,#1BADF8)",
            "svg_tile": "<svg width=\"26\" height=\"26\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><rect x=\"4\" y=\"6\" width=\"16\" height=\"14\" stroke=\"#fff\" stroke-width=\"1.5\"/><path d=\"M8 4v4M16 4v4M4 10h16\" stroke=\"#fff\" stroke-width=\"1.5\"/></svg>",
            "svg_app": "<svg width=\"30\" height=\"30\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><rect x=\"4\" y=\"6\" width=\"16\" height=\"14\" stroke=\"#fff\" stroke-width=\"1.6\"/><path d=\"M8 4v4M16 4v4M4 10h16\" stroke=\"#fff\" stroke-width=\"1.6\"/></svg>",
        },
        "reminders": {
            "gradient": "linear-gradient(135deg,#007AFF,#007AFF)",
            "svg_tile": "<svg width=\"26\" height=\"26\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><circle cx=\"8\" cy=\"9\" r=\"1.7\" fill=\"#fff\"/><path d=\"M12 9h6M12 14h6\" stroke=\"#fff\" stroke-width=\"1.5\"/><circle cx=\"8\" cy=\"14\" r=\"1.7\" fill=\"#fff\"/></svg>",
            "svg_app": "<svg width=\"30\" height=\"30\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><circle cx=\"8\" cy=\"9\" r=\"2\" fill=\"#fff\"/><circle cx=\"8\" cy=\"14\" r=\"2\" fill=\"#fff\"/><path d=\"M12 9h6M12 14h6\" stroke=\"#fff\" stroke-width=\"1.6\"/></svg>",
        },
        "significant_locations": {
            "gradient": "linear-gradient(135deg,#3b82f6,#22d3ee)",
            "svg_tile": "<svg width=\"26\" height=\"26\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M12 3a6 6 0 0 1 6 6c0 4.2-6 12-6 12S6 13.2 6 9a6 6 0 0 1 6-6z\" stroke=\"#fff\" stroke-width=\"1.5\" fill=\"none\"/><circle cx=\"12\" cy=\"9\" r=\"2\" fill=\"#fff\"/></svg>",
            "svg_app": "<svg width=\"30\" height=\"30\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M12 3a6 6 0 0 1 6 6c0 4.2-6 12-6 12S6 13.2 6 9a6 6 0 0 1 6-6z\" stroke=\"#fff\" stroke-width=\"1.6\" fill=\"none\"/><circle cx=\"12\" cy=\"9\" r=\"2\" fill=\"#fff\"/></svg>",
        },
        "documents": {
            "gradient": "linear-gradient(135deg,#4facfe,#00f2fe)",
            "svg_tile": "<svg width=\"26\" height=\"26\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M6 4h9l3 3v13H6z\" stroke=\"#fff\" stroke-width=\"1.5\"/><path d=\"M9 11h6M9 15h6\" stroke=\"#fff\" stroke-width=\"1.5\"/></svg>",
            "svg_app": "<svg width=\"30\" height=\"30\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M6 4h9l3 3v13H6z\" stroke=\"#fff\" stroke-width=\"1.6\"/><path d=\"M9 11h6M9 15h6\" stroke=\"#fff\" stroke-width=\"1.6\"/></svg>",
        },
        "safari": {
            "gradient": "linear-gradient(135deg,#810102,#FE080A)",
            "svg_tile": "<svg width=\"26\" height=\"26\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><circle cx=\"12\" cy=\"12\" r=\"8\" stroke=\"#fff\" stroke-width=\"1.5\"/><path d=\"M12 7v5l3 3\" stroke=\"#fff\" stroke-width=\"1.5\"/></svg>",
            "svg_app": "<svg width=\"30\" height=\"30\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><circle cx=\"12\" cy=\"12\" r=\"7\" stroke=\"#fff\" stroke-width=\"1.6\"/><path d=\"M12 7v5l3 3\" stroke=\"#fff\" stroke-width=\"1.6\"/></svg>",
        },
        "browsers": {
            "gradient": "linear-gradient(135deg,#1f77b4,#6fb1e7)",
            "svg_tile": "<svg width=\"26\" height=\"26\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><circle cx=\"12\" cy=\"12\" r=\"8\" stroke=\"#fff\" stroke-width=\"1.5\"/><path d=\"M4 12h16M12 4a10 10 0 0 0 0 16M12 4a10 10 0 0 1 0 16\" stroke=\"#fff\" stroke-width=\"1.5\"/></svg>",
            "svg_app": "<svg width=\"30\" height=\"30\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><circle cx=\"12\" cy=\"12\" r=\"7\" stroke=\"#fff\" stroke-width=\"1.6\"/><path d=\"M5 12h14M12 5a9 9 0 0 0 0 14M12 5a9 9 0 0 1 0 14\" stroke=\"#fff\" stroke-width=\"1.6\"/></svg>",
        },
        "timeline": {
            "gradient": "linear-gradient(135deg,#3f51b5,#7b8ef3)",
            "svg_tile": "<svg width=\"26\" height=\"26\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M4 6h16v12H4z\" stroke=\"#fff\" stroke-width=\"1.5\"/><path d=\"M8 4v4M16 4v4M4 10h16\" stroke=\"#fff\" stroke-width=\"1.5\"/></svg>",
            "svg_app": "<svg width=\"30\" height=\"30\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><rect x=\"4\" y=\"6\" width=\"16\" height=\"14\" stroke=\"#fff\" stroke-width=\"1.6\"/><path d=\"M8 4v4M16 4v4M4 10h16\" stroke=\"#fff\" stroke-width=\"1.6\"/></svg>",
        },
        "voicemail": {
            "gradient": "linear-gradient(135deg,#5856D6,#5856D6)",
            "svg_tile": "<svg width=\"26\" height=\"26\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M6 10a3 3 0 1 0 0 6h2a3 3 0 1 0 0-6H6zm10 0a3 3 0 1 0 0 6h2a3 3 0 1 0 0-6h-2z\" stroke=\"#fff\" stroke-width=\"1.5\"/><path d=\"M8 13h8\" stroke=\"#fff\" stroke-width=\"1.5\"/></svg>",
            "svg_app": "<svg width=\"30\" height=\"30\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M6 10a3 3 0 1 0 0 6h2a3 3 0 1 0 0-6H6zm10 0a3 3 0 1 0 0 6h2a3 3 0 1 0 0-6h-2z\" stroke=\"#fff\" stroke-width=\"1.6\"/><path d=\"M8 13h8\" stroke=\"#fff\" stroke-width=\"1.6\"/></svg>",
        },
        "call_history": {
            "gradient": "linear-gradient(135deg,#b0bec5,#90a4ae)",
            "svg_tile": "<svg width=\"26\" height=\"26\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M7 7h10v10H7z\" stroke=\"#fff\" stroke-width=\"1.5\"/><path d=\"M9 10h6M9 14h6\" stroke=\"#fff\" stroke-width=\"1.5\"/></svg>",
            "svg_app": "<svg width=\"30\" height=\"30\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M7 7h10v10H7z\" stroke=\"#fff\" stroke-width=\"1.6\"/><path d=\"M9 10h6M9 14h6\" stroke=\"#fff\" stroke-width=\"1.6\"/></svg>",
        },
        "voice_memos": {
            "gradient": "linear-gradient(135deg,#b0bec5,#90a4ae)",
            "svg_tile": "<svg width=\"26\" height=\"26\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M5 8h14v8H5z\" stroke=\"#fff\" stroke-width=\"1.5\"/><path d=\"M9 12h6\" stroke=\"#fff\" stroke-width=\"1.5\"/></svg>",
            "svg_app": "<svg width=\"30\" height=\"30\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M5 8h14v8H5z\" stroke=\"#fff\" stroke-width=\"1.6\"/><path d=\"M9 12h6\" stroke=\"#fff\" stroke-width=\"1.6\"/></svg>",
        },
        "messenger": {
            "gradient": "linear-gradient(135deg,#b0bec5,#90a4ae)",
            "svg_tile": "<svg width=\"26\" height=\"26\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M4 6h16v12H4z\" stroke=\"#fff\" stroke-width=\"1.5\"/><path d=\"M7 10h10M7 14h7\" stroke=\"#fff\" stroke-width=\"1.5\"/></svg>",
            "svg_app": "<svg width=\"30\" height=\"30\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M4 6h16v12H4z\" stroke=\"#fff\" stroke-width=\"1.6\"/><path d=\"M7 10h10M7 14h7\" stroke=\"#fff\" stroke-width=\"1.6\"/></svg>",
        },
        "instagram": {
            "gradient": "linear-gradient(135deg,#b0bec5,#90a4ae)",
            "svg_tile": "<svg width=\"26\" height=\"26\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><circle cx=\"12\" cy=\"12\" r=\"6\" stroke=\"#fff\" stroke-width=\"1.5\"/><circle cx=\"12\" cy=\"12\" r=\"2\" fill=\"#fff\"/></svg>",
            "svg_app": "<svg width=\"30\" height=\"30\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><circle cx=\"12\" cy=\"12\" r=\"6\" stroke=\"#fff\" stroke-width=\"1.6\"/><circle cx=\"12\" cy=\"12\" r=\"2\" fill=\"#fff\"/></svg>",
        },
        "snapchat": {
            "gradient": "linear-gradient(135deg,#ffe148,#ffd200)",
            "svg_tile": "<svg width=\"26\" height=\"26\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M12 5c2 0 3 1.3 3 3 0 1 .3 1.8 1.2 2.6.7.6 1.1 1.1 1.1 1.6 0 .6-.6 1-1.6 1.2-.8.1-1.3.7-1.5 1.4-.3.9-1.5 1.2-2.2.8-.3-.2-.7-.2-1 0-.7.4-1.9.1-2.2-.8-.2-.7-.7-1.3-1.5-1.4-1-.2-1.6-.6-1.6-1.2 0-.5.4-1 1.1-1.6.9-.8 1.2-1.6 1.2-2.6 0-1.7 1-3 3-3z\" stroke=\"#fff\" stroke-width=\"1.4\" fill=\"none\"/></svg>",
            "svg_app": "<svg width=\"30\" height=\"30\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M12 5c2 0 3 1.3 3 3 0 1 .3 1.8 1.2 2.6.7.6 1.1 1.1 1.1 1.6 0 .6-.6 1-1.6 1.2-.8.1-1.3.7-1.5 1.4-.3.9-1.5 1.2-2.2.8-.3-.2-.7-.2-1 0-.7.4-1.9.1-2.2-.8-.2-.7-.7-1.3-1.5-1.4-1-.2-1.6-.6-1.6-1.2 0-.5.4-1 1.1-1.6.9-.8 1.2-1.6 1.2-2.6 0-1.7 1-3 3-3z\" stroke=\"#fff\" stroke-width=\"1.6\" fill=\"none\"/></svg>",
        },
        "screen_time": {
            "gradient": "linear-gradient(135deg,#1f4b99,#3aa0d8)",
            "svg_tile": "<svg width=\"26\" height=\"26\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><circle cx=\"12\" cy=\"12\" r=\"7\" stroke=\"#fff\" stroke-width=\"1.5\"/><path d=\"M12 7v5l3 3\" stroke=\"#fff\" stroke-width=\"1.5\"/></svg>",
            "svg_app": "<svg width=\"30\" height=\"30\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><circle cx=\"12\" cy=\"12\" r=\"7\" stroke=\"#fff\" stroke-width=\"1.6\"/><path d=\"M12 7v5l3 3\" stroke=\"#fff\" stroke-width=\"1.6\"/></svg>",
        },
        "health_fitness": {
            "gradient": "linear-gradient(135deg,#1a7f4b,#7fd36a)",
            "svg_tile": "<svg width=\"26\" height=\"26\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M12 4l2.5 2.5L17 6l-1 3 2.5 2.5L15 13l-1 3-2-2-2 2-1-3-3.5-1.5L8 9 7 6l2.5.5L12 4z\" stroke=\"#fff\" stroke-width=\"1.5\" fill=\"none\"/></svg>",
            "svg_app": "<svg width=\"30\" height=\"30\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M12 4l2.5 2.5L17 6l-1 3 2.5 2.5L15 13l-1 3-2-2-2 2-1-3-3.5-1.5L8 9 7 6l2.5.5L12 4z\" stroke=\"#fff\" stroke-width=\"1.6\" fill=\"none\"/></svg>",
        },
        "passwords": {
            "gradient": "linear-gradient(135deg,#2c3e50,#4b6b88)",
            "svg_tile": "<svg width=\"26\" height=\"26\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><rect x=\"6\" y=\"10\" width=\"12\" height=\"9\" rx=\"2\" stroke=\"#fff\" stroke-width=\"1.5\"/><path d=\"M9 10V8a3 3 0 0 1 6 0v2\" stroke=\"#fff\" stroke-width=\"1.5\"/></svg>",
            "svg_app": "<svg width=\"30\" height=\"30\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><rect x=\"6\" y=\"10\" width=\"12\" height=\"9\" rx=\"2\" stroke=\"#fff\" stroke-width=\"1.6\"/><path d=\"M9 10V8a3 3 0 0 1 6 0v2\" stroke=\"#fff\" stroke-width=\"1.6\"/></svg>",
        },
    }


def _build_device_apps(categories, availability, counts, links):
    icon_data = _get_icon_data()
    labels = _get_device_labels()
    html = []
    for cat_id in categories:
        if cat_id == "timeline":
            continue
        info = icon_data.get(cat_id)
        if not info:
            continue
        label = labels.get(cat_id, cat_id.title())
        count = counts.get(cat_id, 0)
        href = links.get(cat_id, "#")
        if availability.get(cat_id):
            badge = f"<div class=\"badge\">{_format_count(count)}</div>" if count else ""
            html.append(
                f"<a class=\"app app-link\" onclick=\"return window.__deviceOpenApp ? window.__deviceOpenApp(this) : true;\" "
                f"target=\"report-frame\" href=\"{href}\">"
                f"{badge}"
                f"<div class=\"icon\" style=\"background: {info['gradient']};\">{info['svg_app']}</div>"
                f"<div class=\"app-label\">{label}</div>"
                f"</a>"
            )
        else:
            html.append(
                f"<div class=\"app disabled\">"
                f"<div class=\"icon\" style=\"background: {info['gradient']};\">{info['svg_app']}</div>"
                f"<div class=\"app-label\">{label}</div>"
                f"</div>"
            )
    return "\n".join(html)


def _build_tiles(categories, availability, counts, links):
    icon_data = _get_icon_data()
    display_names = _get_display_names()
    units = _get_units()
    html = []
    for cat_id in categories:
        info = icon_data.get(cat_id)
        if not info:
            continue
        title = display_names.get(cat_id, cat_id.title())
        unit = units.get(cat_id, "items")
        count = counts.get(cat_id, 0)
        href = links.get(cat_id, "#")
        if availability.get(cat_id):
            html.append(
                f"<a class=\"tile\" href=\"{href}\">"
                f"<div class=\"icon\" style=\"background: {info['gradient']};\">{info['svg_tile']}</div>"
                f"<div class=\"title\">{title}</div>"
                f"<div class=\"count\">{_format_count(count)}</div>"
                f"<div class=\"unit\">{unit}</div>"
                f"<div class=\"pill\">Open</div>"
                f"</a>"
            )
        else:
            html.append(
                f"<div class=\"tile disabled\">"
                f"<div class=\"icon\" style=\"background: {info['gradient']};\">{info['svg_tile']}</div>"
                f"<div class=\"title\">{title}</div>"
                f"<div class=\"count\">0</div>"
                f"<div class=\"unit\">not extracted</div>"
                f"<div class=\"pill\">Missing</div>"
                f"</div>"
            )
    return "\n".join(html)


def generate_master_report(backup_path: str, output_base_dir: str, summary: dict, options: dict, backup_access=None) -> None:
    module_dir = os.path.dirname(os.path.abspath(__file__))
    candidates = [
        os.path.join(module_dir, "template", "Start_Here.html"),
        os.path.join(module_dir, "Start_Here.html"),
        os.path.join(sys.prefix, "template", "Start_Here.html"),
        os.path.join(sys.prefix, "Start_Here.html"),
    ]
    template_path = ""
    for candidate in candidates:
        if os.path.exists(candidate):
            template_path = candidate
            break
    if not template_path:
        print(f"[WARNING] Master report template not found. Tried: {candidates}")
        return

    with open(template_path, "r", encoding="utf-8") as f:
        html = f.read()

    device_info = _get_device_info(backup_path, backup_access=backup_access)
    wallpaper_rel = _copy_wallpaper(
        backup_path, output_base_dir, device_info.get("product_type", ""), backup_access=backup_access
    )

    report_map = _get_report_map()
    category_order = [
        "photos", "timeline", "significant_locations", "sms", "whatsapp", "viber", "kik", "line", "contacts", "notes",
        "calendar", "reminders", "documents", "safari", "browsers", "voicemail", "call_history", "voice_memos", "messenger",
        "instagram", "snapchat", "screen_time", "health_fitness", "passwords"
    ]

    counts = {}
    availability = {}
    links = {}

    from full_extraction_manager import FullExtractionManager

    for cat_id in category_order:
        result = summary.get("results", {}).get(cat_id)
        success = bool(result and result.get("status") == "success")
        count = int(result.get("count", 0) or 0) if success else 0
        counts[cat_id] = count

        subfolder = FullExtractionManager.CATEGORY_REGISTRY.get(cat_id, ("", "", "", ""))[3]
        filename = report_map.get(cat_id, "")
        rel_path = os.path.join(subfolder, filename) if subfolder else filename
        rel_path = rel_path.replace("\\", "/")
        links[cat_id] = _normalize_url_path(rel_path)

        report_path = os.path.join(output_base_dir, rel_path)
        availability[cat_id] = success and os.path.exists(report_path)

    # Override Photos count using report data when available (prevents mismatch)
    photos_report_count = _get_photos_report_count(output_base_dir)
    if photos_report_count is not None and photos_report_count > 0:
        counts["photos"] = photos_report_count

    total_items = summary.get("total_items", sum(counts.values()))
    # Keep total_items consistent with tile counts when overrides apply
    if photos_report_count is not None:
        total_items = sum(counts.values())
    categories_found = sum(1 for k in category_order if availability.get(k))
    not_extracted = len(category_order) - categories_found
    extraction_date = datetime.now().strftime("%b %d, %Y")
    total_storage_raw = (
        summary.get("total_storage_estimate")
        or summary.get("total_size_bytes")
        or summary.get("total_bytes")
        or summary.get("output_bytes")
    )
    total_storage = _format_storage_estimate(total_storage_raw)
    device_view_attr = ""
    product_type = device_info.get("product_type", "")
    if str(product_type).lower().startswith("ipad"):
        device_view_attr = ' data-device="ipad"'

    dock_timeline_link = links.get("timeline", "Timeline/Timeline.html")
    dock_timeline_class = "" if availability.get("timeline") else "disabled"
    dock_device_link = _normalize_url_path(os.path.join("Device Information", "Device_Information.html"))
    dock_device_class = ""
    audit_rel = os.path.join("Audit", "Audit_Summary.html")
    audit_path = os.path.join(output_base_dir, audit_rel)
    dock_audit_link = _normalize_url_path(audit_rel)
    if options.get("audit_mode") == "forensic":
        dock_audit_class = ""
    else:
        dock_audit_class = "" if os.path.exists(audit_path) else "disabled"

    replacements = {
        "{{WALLPAPER_PATH}}": wallpaper_rel,
        "{{DEVICE_NAME}}": device_info.get("device_name", "Unknown Device"),
        "{{DEVICE_MODEL}}": device_info.get("device_model", "Unknown"),
        "{{PRODUCT_TYPE}}": device_info.get("product_type", "Unknown"),
        "{{IOS_VERSION}}": device_info.get("ios_version", "Unknown"),
        "{{BUILD_VERSION}}": device_info.get("build_version", "Unknown"),
        "{{TOTAL_ITEMS}}": _format_count(total_items),
        "{{TOTAL_STORAGE}}": total_storage,
        "{{CATEGORIES_FOUND}}": str(categories_found),
        "{{NOT_EXTRACTED}}": str(not_extracted),
        "{{EXTRACTION_DATE}}": extraction_date,
        "{{DEVICE_APPS}}": _build_device_apps(category_order, availability, counts, links),
        "{{TILES}}": _build_tiles(category_order, availability, counts, links),
        "{{DEVICE_VIEW_ATTR}}": device_view_attr,
        "{{EXTRACTION_SUMMARY_BLOCK}}": _build_extraction_summary(
            summary,
            options,
            _normalize_url_path(os.path.join("Device Information", "Device_Information.html")),
            device_info,
        ),
        "{{DOCK_TIMELINE_LINK}}": dock_timeline_link,
        "{{DOCK_TIMELINE_CLASS}}": dock_timeline_class,
        "{{DOCK_DEVICE_LINK}}": dock_device_link,
        "{{DOCK_DEVICE_CLASS}}": dock_device_class,
        "{{DOCK_AUDIT_LINK}}": dock_audit_link,
        "{{DOCK_AUDIT_CLASS}}": dock_audit_class,
    }

    for key, value in replacements.items():
        html = html.replace(key, value)

    output_path = os.path.join(output_base_dir, "Start_Here.html")
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)
