"""
Preview windows for iOS backup categories.

Provides base classes and implementations for displaying category data
in preview windows with search, selection, and export functionality.
"""

from .base import CategoryPreviewWindow

__all__ = ['CategoryPreviewWindow']
