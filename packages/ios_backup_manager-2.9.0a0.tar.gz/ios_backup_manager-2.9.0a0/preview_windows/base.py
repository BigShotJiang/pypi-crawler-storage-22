#!/usr/bin/env python3
"""
Base class for category preview windows.

Provides common UI components and functionality for previewing
and exporting category data.
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from typing import Optional
from abc import ABC, abstractmethod
from .export_utils import prompt_open_export_folder

_GLOBAL_LAST_EXPORT_DIR = None  # shared across preview windows


class CategoryPreviewWindow(tk.Toplevel, ABC):
    """
    Abstract base class for category preview windows.

    Provides common UI:
    - Title and header
    - Search bar
    - Item list (left pane)
    - Detail view (right pane)
    - Export button
    - Pagination controls
    """

    def __init__(self, parent, extractor, category_name: str, backup_label: str = ""):
        """
        Initialize preview window.

        Args:
            parent: Parent tkinter window
            extractor: CategoryDataExtractor instance
            category_name: Display name for category (e.g., "Contacts")
            backup_label: Label for which backup (e.g., "Left Backup")
        """
        super().__init__(parent)

        self.extractor = extractor
        self.category_name = category_name
        self.backup_label = backup_label

        # State
        self.items = []
        self.selected_item = None
        self.selected_item_ids = set()  # Track selected items across pages by ID
        self.current_page = 0
        self.items_per_page = 100
        self.total_count = 0
        self.search_query = ""
        self.last_export_path = None  # Remember last export directory

        # Window setup
        self.title(f"{category_name} Preview - {backup_label}")
        self.geometry("900x600")

        # Build UI
        self._build_ui()

        # Load initial data
        self.load_items()

    def _build_ui(self):
        """Build the common UI components."""
        # Header
        header = tk.Frame(self, bg="#2c3e50", height=60)
        header.pack(fill=tk.X)
        header.pack_propagate(False)

        tk.Label(
            header,
            text=f"📋 {self.category_name}",
            font=("Arial", 16, "bold"),
            bg="#2c3e50",
            fg="white"
        ).pack(side=tk.LEFT, padx=20, pady=15)

        self.count_label = tk.Label(
            header,
            text="Loading...",
            font=("Arial", 10),
            bg="#2c3e50",
            fg="#95a5a6"
        )
        self.count_label.pack(side=tk.LEFT, pady=15)

        # Search bar
        search_frame = tk.Frame(self, bg="white")
        search_frame.pack(fill=tk.X, padx=10, pady=5)

        tk.Label(search_frame, text="🔍", font=("Arial", 12), bg="white").pack(side=tk.LEFT, padx=5)

        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *args: self._on_search_changed())

        search_entry = tk.Entry(
            search_frame,
            textvariable=self.search_var,
            font=("Arial", 10),
            width=40
        )
        search_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)

        tk.Button(
            search_frame,
            text="Clear",
            command=self._clear_search,
            font=("Arial", 9)
        ).pack(side=tk.LEFT, padx=5)

        # Main content area (split pane)
        content = tk.Frame(self)
        content.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        # Left pane: Item list
        list_frame = tk.Frame(content, width=350)
        list_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=False)
        list_frame.pack_propagate(False)

        tk.Label(
            list_frame,
            text=f"{self.category_name} List",
            font=("Arial", 10, "bold"),
            anchor=tk.W
        ).pack(fill=tk.X, pady=(0, 5))

        # Listbox with scrollbar
        list_scroll_frame = tk.Frame(list_frame)
        list_scroll_frame.pack(fill=tk.BOTH, expand=True)

        scrollbar = tk.Scrollbar(list_scroll_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.listbox = tk.Listbox(
            list_scroll_frame,
            yscrollcommand=scrollbar.set,
            font=("Arial", 9),
            activestyle='none',
            selectmode=tk.EXTENDED  # Enable multi-selection
        )
        self.listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.listbox.yview)

        self.listbox.bind('<<ListboxSelect>>', self._on_item_selected)

        # Pagination controls
        page_frame = tk.Frame(list_frame)
        page_frame.pack(fill=tk.X, pady=5)

        self.prev_btn = tk.Button(
            page_frame,
            text="◀ Prev",
            command=self._prev_page,
            font=("Arial", 9),
            state=tk.DISABLED
        )
        self.prev_btn.pack(side=tk.LEFT, padx=2)

        self.page_label = tk.Label(
            page_frame,
            text="Page 1",
            font=("Arial", 9)
        )
        self.page_label.pack(side=tk.LEFT, padx=10)

        self.next_btn = tk.Button(
            page_frame,
            text="Next ▶",
            command=self._next_page,
            font=("Arial", 9)
        )
        self.next_btn.pack(side=tk.LEFT, padx=2)

        # Right pane: Detail view
        detail_frame = tk.Frame(content)
        detail_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(10, 0))

        tk.Label(
            detail_frame,
            text="Details",
            font=("Arial", 10, "bold"),
            anchor=tk.W
        ).pack(fill=tk.X, pady=(0, 5))

        # Detail content (subclass fills this)
        self.detail_content = tk.Frame(detail_frame, bg="white", relief=tk.SUNKEN, borderwidth=1)
        self.detail_content.pack(fill=tk.BOTH, expand=True)

        # Bottom buttons
        button_frame = tk.Frame(self)
        button_frame.pack(fill=tk.X, padx=10, pady=10)

        self.export_btn = tk.Button(
            button_frame,
            text="Export All...",
            command=self._export_all,
            font=("Arial", 10),
            bg="#3498db",
            fg="white",
            padx=20,
            pady=5,
            state=tk.DISABLED
        )
        self.export_btn.pack(side=tk.LEFT, padx=(0, 5))

        self.clear_selection_btn = tk.Button(
            button_frame,
            text="Clear Selection",
            command=self._clear_selection,
            font=("Arial", 10),
            bg="#e67e22",
            fg="white",
            padx=20,
            pady=5
        )
        # Don't pack yet - only show when items are selected

        tk.Button(
            button_frame,
            text="Close",
            command=self.destroy,
            font=("Arial", 10),
            bg="#95a5a6",
            fg="white",
            padx=20,
            pady=5
        ).pack(side=tk.LEFT)

    def load_items(self, search: Optional[str] = None):
        """Load items from extractor with current page and search."""
        try:
            # Get total count
            self.total_count = self.extractor.get_count()

            # Update count label
            if search:
                self.count_label.config(text=f"Searching... (Total: {self.total_count})")
            else:
                self.count_label.config(text=f"Total: {self.total_count}")

            # Load page of items
            offset = self.current_page * self.items_per_page
            self.items = self.extractor.get_items(
                limit=self.items_per_page,
                offset=offset,
                search=search
            )

            # Update listbox
            self.listbox.delete(0, tk.END)
            for item in self.items:
                summary = self.extractor.get_item_summary(item)
                self.listbox.insert(tk.END, summary)

            # Restore selections for items on this page
            for idx, item in enumerate(self.items):
                item_id = self.get_item_id(item)
                if item_id in self.selected_item_ids:
                    self.listbox.selection_set(idx)

            # Update pagination
            total_pages = (self.total_count + self.items_per_page - 1) // self.items_per_page
            self.page_label.config(text=f"Page {self.current_page + 1} of {total_pages}")

            self.prev_btn.config(state=tk.NORMAL if self.current_page > 0 else tk.DISABLED)
            self.next_btn.config(state=tk.NORMAL if offset + len(self.items) < self.total_count else tk.DISABLED)

            # Enable export if items exist
            self.export_btn.config(state=tk.NORMAL if self.items else tk.DISABLED)

        except Exception as e:
            messagebox.showerror("Error", f"Failed to load {self.category_name}:\n{str(e)}")

    def _on_search_changed(self):
        """Handle search query change."""
        # Debounce: only search after user stops typing for 300ms
        if hasattr(self, '_search_timer'):
            self.after_cancel(self._search_timer)

        self._search_timer = self.after(300, self._perform_search)

    def _perform_search(self):
        """Perform the search."""
        self.search_query = self.search_var.get().strip()
        self.current_page = 0  # Reset to first page
        self.load_items(search=self.search_query if self.search_query else None)

    def _clear_search(self):
        """Clear search and reload all items."""
        self.search_var.set("")
        self.search_query = ""
        self.current_page = 0
        self.load_items()

    def _prev_page(self):
        """Go to previous page."""
        if self.current_page > 0:
            self.current_page -= 1
            self.load_items(search=self.search_query if self.search_query else None)

    def _next_page(self):
        """Go to next page."""
        self.current_page += 1
        self.load_items(search=self.search_query if self.search_query else None)

    def _on_item_selected(self, event):
        """Handle item selection in listbox."""
        selection = self.listbox.curselection()

        # Update selected_item_ids set based on current selection
        # First, remove items on this page that are no longer selected
        current_page_ids = {self.get_item_id(item) for item in self.items}
        self.selected_item_ids = {id for id in self.selected_item_ids if id not in current_page_ids}

        # Then add currently selected items
        for idx in selection:
            if 0 <= idx < len(self.items):
                item_id = self.get_item_id(self.items[idx])
                self.selected_item_ids.add(item_id)

        # Update button visibility and text based on total selection count
        total_selected = len(self.selected_item_ids)
        if total_selected > 0:
            self.export_btn.config(text=f"Export Selected ({total_selected})...")
            # Show clear selection button
            if not self.clear_selection_btn.winfo_ismapped():
                self.clear_selection_btn.pack(side=tk.LEFT, padx=(0, 5), before=self.export_btn.master.winfo_children()[-1])
        else:
            self.export_btn.config(text="Export All...")
            # Hide clear selection button
            if self.clear_selection_btn.winfo_ismapped():
                self.clear_selection_btn.pack_forget()

        # Display details for first selected item on current page
        if selection:
            index = selection[0]
            if 0 <= index < len(self.items):
                self.selected_item = self.items[index]
                self.display_item_details(self.selected_item)

    def _clear_selection(self):
        """Clear all selected items."""
        self.selected_item_ids.clear()
        self.listbox.selection_clear(0, tk.END)
        self.export_btn.config(text="Export All...")
        if self.clear_selection_btn.winfo_ismapped():
            self.clear_selection_btn.pack_forget()

    @abstractmethod
    def get_item_id(self, item):
        """
        Get unique ID for an item (for tracking selections across pages).

        Args:
            item: Item dictionary from extractor

        Returns:
            Unique identifier for this item (e.g., rowid, GUID)
        """
        pass

    @abstractmethod
    def display_item_details(self, item):
        """
        Display details for selected item in detail pane.

        Subclasses implement this to show category-specific details.

        Args:
            item: Item dictionary from extractor
        """
        pass

    def _export_all(self):
        """Export selected items, or all items if none selected."""
        import os
        import threading
        from .progress_dialog import ProgressDialog

        try:
            # Determine what to export
            if self.selected_item_ids:
                # Export all selected items (across all pages)
                # Get all items, then filter by selected IDs
                all_items = self.extractor.get_items(
                    limit=None,
                    offset=0,
                    search=self.search_query if self.search_query else None
                )
                items_to_export = [item for item in all_items if self.get_item_id(item) in self.selected_item_ids]
                export_desc = f"{len(items_to_export)} selected"
            else:
                # Export all items matching current search
                items_to_export = self.extractor.get_items(
                    limit=None,
                    offset=0,
                    search=self.search_query if self.search_query else None
                )
                export_desc = f"all {len(items_to_export)}"

            if not items_to_export:
                messagebox.showwarning("Nothing to Export", "No items to export.")
                return

            # Get base export directory (with path memory)
            base_export_dir = None

            # Prefer this window's last path; fallback to global shared path
            candidate_path = self.last_export_path if (self.last_export_path and os.path.exists(self.last_export_path)) else None
            global_path = None
            try:
                from preview_windows import base as _base_mod
                global_path = getattr(_base_mod, "_GLOBAL_LAST_EXPORT_DIR", None)
                if global_path and not os.path.exists(global_path):
                    global_path = None
            except Exception:
                global_path = None
            if not candidate_path and global_path:
                candidate_path = global_path

            if candidate_path:
                # Ask if user wants to use previous path
                result = messagebox.askyesnocancel(
                    "Export Directory",
                    f"Export to previous location?\n\n{candidate_path}\n\n"
                    "Yes = Use this location\n"
                    "No = Choose different location\n"
                    "Cancel = Cancel export"
                )

                if result is None:  # User cancelled
                    return
                elif result:  # User clicked Yes
                    base_export_dir = candidate_path
                # If result is False (No), ask for new directory below

            # Ask for new directory if needed
            if not base_export_dir:
                base_export_dir = filedialog.askdirectory(
                    title=f"Select directory to export {self.category_name}"
                )

                if not base_export_dir:
                    return  # User cancelled

                # Remember this path for next time
                self.last_export_path = base_export_dir
                try:
                    from preview_windows import base as _base_mod
                    _base_mod._GLOBAL_LAST_EXPORT_DIR = base_export_dir
                except Exception:
                    pass
            else:
                # Store back into globals for cross-category reuse
                try:
                    from preview_windows import base as _base_mod
                    _base_mod._GLOBAL_LAST_EXPORT_DIR = base_export_dir
                except Exception:
                    pass

            # Create category subfolder for organized output
            export_dir = os.path.join(base_export_dir, self.category_name)
            os.makedirs(export_dir, exist_ok=True)

            # Create progress dialog
            progress = ProgressDialog(
                self,
                title=f"Exporting {self.category_name}",
                total_items=len(items_to_export),
                allow_cancel=True
            )

            def progress_callback(current, total, item_name):
                """Update progress dialog (called from worker thread)."""
                # Schedule update in main thread
                self.after(0, lambda: progress.update_progress(
                    current=current,
                    total=total,
                    current_item_name=item_name
                ))

                # Check for cancellation
                return not progress.is_cancelled()

            def export_worker():
                """Run export in background thread."""
                try:
                    # Export with progress callback
                    # Pass directory path (not file path) - extractors create their own file structure
                    success = self.extractor.export(
                        items_to_export,
                        export_dir,
                        progress_callback=progress_callback
                    )

                    # Mark complete
                    if progress.is_cancelled():
                        self.after(0, lambda: progress.set_complete(
                            success=False,
                            message=f"Export cancelled"
                        ))
                    elif success:
                        self.after(0, lambda: progress.set_complete(
                            success=True,
                            message=f"Exported {len(items_to_export)} items successfully!"
                        ))
                        # Prompt to open folder (respects user prefs for auto-open/suppress)
                        self.after(0, lambda: prompt_open_export_folder(
                            self,
                            export_dir,
                            f"{self.category_name} Export Complete",
                            f"Exported {len(items_to_export)} items to:\n{export_dir}"
                        ))
                    else:
                        self.after(0, lambda: progress.set_complete(
                            success=False,
                            message="Export failed - check console for details"
                        ))

                    # Close after 1.5 seconds
                    self.after(1500, progress.close)

                except Exception as e:
                    self.after(0, lambda: progress.set_complete(
                        success=False,
                        message=f"Export error: {e}"
                    ))
                    self.after(2000, progress.close)

            # Start export thread
            thread = threading.Thread(target=export_worker, daemon=True)
            thread.start()

        except Exception as e:
            messagebox.showerror("Export Error", f"Error exporting data:\n{str(e)}")

    @abstractmethod
    def get_default_export_extension(self) -> str:
        """Get default file extension for exports (e.g., '.vcf')."""
        pass

    @abstractmethod
    def get_export_filetypes(self) -> list:
        """Get file types for export dialog (e.g., [('vCard', '*.vcf')])."""
        pass
