#!/usr/bin/env python3
"""Calendar preview window for displaying calendar events."""

import tkinter as tk
from tkinter import ttk, scrolledtext
from datetime import datetime, timezone
from .base import CategoryPreviewWindow


class CalendarPreviewWindow(CategoryPreviewWindow):
    """Preview window for calendar events."""

    def get_item_id(self, item):
        """Get unique ID for an event."""
        return item['event_id']

    def display_item_details(self, item):
        """Display event details in the detail pane."""
        # Clear existing content
        for widget in self.detail_content.winfo_children():
            widget.destroy()

        # Create scrollable frame
        canvas = tk.Canvas(self.detail_content, bg='white', highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.detail_content, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Event title
        title_label = tk.Label(
            scrollable_frame,
            text=item['summary'],
            font=('Segoe UI', 16, 'bold'),
            bg='white',
            fg='#333',
            wraplength=580,
            justify='left'
        )
        title_label.pack(anchor='w', padx=20, pady=(20, 10))

        # Calendar badge
        calendar_frame = tk.Frame(scrollable_frame, bg='white')
        calendar_frame.pack(anchor='w', padx=20, pady=5)

        try:
            # Parse hex color
            color = item['calendar_color']
            if color and color.startswith('#'):
                badge_color = color
            else:
                badge_color = '#1BADF8'
        except:
            badge_color = '#1BADF8'

        calendar_badge = tk.Label(
            calendar_frame,
            text=item['calendar_name'],
            bg=badge_color,
            fg='white',
            font=('Segoe UI', 9),
            padx=8,
            pady=3
        )
        calendar_badge.pack(side='left')

        # All-day badge
        if item['all_day']:
            allday_badge = tk.Label(
                calendar_frame,
                text='All Day',
                bg='#999',
                fg='white',
                font=('Segoe UI', 9),
                padx=8,
                pady=3
            )
            allday_badge.pack(side='left', padx=5)

        # Recurring badge
        if item['has_recurrence']:
            recurring_badge = tk.Label(
                calendar_frame,
                text='Recurring',
                bg='#666',
                fg='white',
                font=('Segoe UI', 9),
                padx=8,
                pady=3
            )
            recurring_badge.pack(side='left', padx=5)

        # Separator
        sep1 = ttk.Separator(scrollable_frame, orient='horizontal')
        sep1.pack(fill='x', padx=20, pady=15)

        # Date/Time information
        datetime_frame = tk.Frame(scrollable_frame, bg='white')
        datetime_frame.pack(anchor='w', padx=20, pady=5, fill='x')

        # Start date
        start_label = tk.Label(
            datetime_frame,
            text='Start:',
            font=('Segoe UI', 10, 'bold'),
            bg='white',
            fg='#666',
            width=12,
            anchor='w'
        )
        start_label.grid(row=0, column=0, sticky='w', pady=3)

        start_value = tk.Label(
            datetime_frame,
            text=self._format_timestamp(item['start_date'], item['all_day']),
            font=('Segoe UI', 10),
            bg='white',
            fg='#333',
            anchor='w'
        )
        start_value.grid(row=0, column=1, sticky='w', pady=3, padx=10)

        # End date
        end_label = tk.Label(
            datetime_frame,
            text='End:',
            font=('Segoe UI', 10, 'bold'),
            bg='white',
            fg='#666',
            width=12,
            anchor='w'
        )
        end_label.grid(row=1, column=0, sticky='w', pady=3)

        end_value = tk.Label(
            datetime_frame,
            text=self._format_timestamp(item['end_date'], item['all_day']),
            font=('Segoe UI', 10),
            bg='white',
            fg='#333',
            anchor='w'
        )
        end_value.grid(row=1, column=1, sticky='w', pady=3, padx=10)

        # Duration
        if item['start_date'] and item['end_date']:
            duration_seconds = item['end_date'] - item['start_date']
            duration_str = self._format_duration(duration_seconds)

            duration_label = tk.Label(
                datetime_frame,
                text='Duration:',
                font=('Segoe UI', 10, 'bold'),
                bg='white',
                fg='#666',
                width=12,
                anchor='w'
            )
            duration_label.grid(row=2, column=0, sticky='w', pady=3)

            duration_value = tk.Label(
                datetime_frame,
                text=duration_str,
                font=('Segoe UI', 10),
                bg='white',
                fg='#333',
                anchor='w'
            )
            duration_value.grid(row=2, column=1, sticky='w', pady=3, padx=10)

        # Location
        if item['location']:
            sep2 = ttk.Separator(scrollable_frame, orient='horizontal')
            sep2.pack(fill='x', padx=20, pady=15)

            location_label = tk.Label(
                scrollable_frame,
                text='Location',
                font=('Segoe UI', 11, 'bold'),
                bg='white',
                fg='#333',
                anchor='w'
            )
            location_label.pack(anchor='w', padx=20, pady=(5, 5))

            location_text = tk.Label(
                scrollable_frame,
                text=item['location'],
                font=('Segoe UI', 10),
                bg='white',
                fg='#333',
                wraplength=580,
                justify='left',
                anchor='w'
            )
            location_text.pack(anchor='w', padx=20, pady=(0, 10))

        # Description
        if item['description']:
            sep3 = ttk.Separator(scrollable_frame, orient='horizontal')
            sep3.pack(fill='x', padx=20, pady=15)

            description_label = tk.Label(
                scrollable_frame,
                text='Description',
                font=('Segoe UI', 11, 'bold'),
                bg='white',
                fg='#333',
                anchor='w'
            )
            description_label.pack(anchor='w', padx=20, pady=(5, 5))

            description_text = scrolledtext.ScrolledText(
                scrollable_frame,
                font=('Segoe UI', 10),
                bg='#f9f9f9',
                fg='#333',
                height=8,
                width=70,
                wrap='word',
                relief='flat',
                padx=10,
                pady=10
            )
            description_text.pack(anchor='w', padx=20, pady=(0, 10))
            description_text.insert('1.0', item['description'])
            description_text.configure(state='disabled')

        # Pack canvas and scrollbar
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Bind mousewheel
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

        canvas.bind_all("<MouseWheel>", _on_mousewheel)

    def _format_timestamp(self, timestamp, all_day=False):
        """Format Apple Core Data timestamp for display."""
        if timestamp is None:
            return "N/A"

        try:
            # Apple Core Data timestamp is seconds since 2001-01-01
            apple_epoch = datetime(2001, 1, 1, tzinfo=timezone.utc).timestamp()
            unix_timestamp = apple_epoch + timestamp
            dt = datetime.fromtimestamp(unix_timestamp)

            if all_day:
                return dt.strftime("%B %d, %Y")
            else:
                return dt.strftime("%B %d, %Y at %I:%M %p")
        except:
            return str(timestamp)

    def _format_duration(self, seconds):
        """Format duration in seconds to human-readable string."""
        if seconds < 60:
            return f"{int(seconds)} seconds"
        elif seconds < 3600:
            minutes = int(seconds / 60)
            return f"{minutes} minute{'s' if minutes != 1 else ''}"
        elif seconds < 86400:
            hours = int(seconds / 3600)
            minutes = int((seconds % 3600) / 60)
            if minutes > 0:
                return f"{hours} hour{'s' if hours != 1 else ''}, {minutes} minute{'s' if minutes != 1 else ''}"
            return f"{hours} hour{'s' if hours != 1 else ''}"
        else:
            days = int(seconds / 86400)
            hours = int((seconds % 86400) / 3600)
            if hours > 0:
                return f"{days} day{'s' if days != 1 else ''}, {hours} hour{'s' if hours != 1 else ''}"
            return f"{days} day{'s' if days != 1 else ''}"

    def get_display_text(self, item):
        """Get text to display in the list for this item."""
        summary = item['summary']
        if len(summary) > 50:
            summary = summary[:47] + "..."

        # Format start date
        start = self._format_timestamp(item['start_date'], item['all_day'])

        return f"{summary}\n{start}"

    def get_default_export_extension(self) -> str:
        """Default extension for calendar export."""
        return '.ics'

    def get_export_filetypes(self) -> list:
        """File types for calendar export."""
        return [
            ('iCalendar Files', '*.ics'),
            ('All Files', '*.*')
        ]
