#!/usr/bin/env python3
"""
Notes preview window implementation.

Displays notes from iOS backup with search, detail view, and HTML export.
"""

import tkinter as tk
from tkinter import scrolledtext
from .base import CategoryPreviewWindow


class NotesPreviewWindow(CategoryPreviewWindow):
    """Preview window for notes data."""

    def get_item_id(self, item):
        """Get unique ID for a note."""
        return item['note_id']

    def display_item_details(self, item):
        """Display note details in the detail pane."""
        # Clear existing content
        for widget in self.detail_content.winfo_children():
            widget.destroy()

        # Create scrollable detail view
        canvas = tk.Canvas(self.detail_content, bg="white", highlightthickness=0)
        scrollbar = tk.Scrollbar(self.detail_content, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg="white")

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Title section
        title_frame = tk.Frame(scrollable_frame, bg="white")
        title_frame.pack(fill=tk.X, padx=15, pady=(15, 5))

        tk.Label(
            title_frame,
            text=item['title'],
            font=("Arial", 18, "bold"),
            bg="white",
            anchor=tk.W,
            wraplength=450,
            justify=tk.LEFT
        ).pack(fill=tk.X)

        # Metadata section
        meta_frame = tk.Frame(scrollable_frame, bg="white")
        meta_frame.pack(fill=tk.X, padx=15, pady=(5, 10))

        meta_items = [
            f"📁 Folder: {item['folder']}",
            f"💾 Account: {item['account']}",
        ]

        if item['created']:
            meta_items.append(f"📅 Created: {self._format_timestamp(item['created'])}")
        if item['modified']:
            meta_items.append(f"✏️ Modified: {self._format_timestamp(item['modified'])}")

        for meta_text in meta_items:
            tk.Label(
                meta_frame,
                text=meta_text,
                font=("Arial", 9),
                bg="white",
                fg="#7f8c8d",
                anchor=tk.W
            ).pack(fill=tk.X)

        # Separator
        tk.Frame(scrollable_frame, height=1, bg="#ecf0f1").pack(fill=tk.X, padx=15, pady=10)

        # Content section
        content_frame = tk.Frame(scrollable_frame, bg="white")
        content_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=(0, 15))

        tk.Label(
            content_frame,
            text="Content",
            font=("Arial", 11, "bold"),
            bg="white",
            anchor=tk.W
        ).pack(fill=tk.X, pady=(0, 5))

        # Scrollable text widget for note content
        text_widget = scrolledtext.ScrolledText(
            content_frame,
            wrap=tk.WORD,
            font=("Arial", 10),
            bg="#f9f9f9",
            relief=tk.FLAT,
            borderwidth=1,
            padx=10,
            pady=10,
            height=15
        )
        text_widget.pack(fill=tk.BOTH, expand=True)

        # Insert content (plain text if no HTML formatting)
        content = item.get('content', '')
        if not content:
            content = "(No content)"

        text_widget.insert("1.0", content)
        text_widget.config(state=tk.DISABLED)

    def _format_timestamp(self, timestamp):
        """Format Apple Core Data timestamp for display."""
        if timestamp is None:
            return "N/A"

        try:
            from datetime import datetime, timezone

            # Apple Core Data timestamp is seconds since 2001-01-01
            apple_epoch = datetime(2001, 1, 1, tzinfo=timezone.utc).timestamp()
            unix_timestamp = apple_epoch + timestamp
            dt = datetime.fromtimestamp(unix_timestamp)
            return dt.strftime("%B %d, %Y at %I:%M %p")
        except:
            return str(timestamp)

    def get_default_export_extension(self) -> str:
        """Default extension for notes export."""
        return ''  # Export to directory, not single file

    def get_export_filetypes(self) -> list:
        """File types for notes export."""
        return [
            ('HTML Files', '*.html'),
            ('Text Files', '*.txt')
        ]
