#!/usr/bin/env python3
"""
Progress dialog for long-running operations.

Provides a modal dialog with progress bar, ETA, and cancellation support.
"""

import tkinter as tk
from tkinter import ttk
import time
from typing import Optional, Callable


class ProgressDialog(tk.Toplevel):
    """
    Modal progress dialog for long-running operations.

    Features:
    - Progress bar
    - Current item display
    - Elapsed time
    - ETA calculation
    - Cancel button
    - Thread-safe updates
    """

    def __init__(self, parent, title: str = "Progress",
                 total_items: int = 100,
                 allow_cancel: bool = True):
        """
        Initialize progress dialog.

        Args:
            parent: Parent window
            title: Dialog title
            total_items: Total number of items to process
            allow_cancel: Whether to show cancel button
        """
        super().__init__(parent)

        self.title(title)
        self.geometry("500x200")
        self.resizable(False, False)

        # Make modal
        self.transient(parent)
        self.grab_set()

        # State
        self.total_items = total_items
        self.current_item = 0
        self.start_time = time.time()
        self.cancelled = False

        # Build UI
        self._build_ui(allow_cancel)

        # Center on parent
        self.update_idletasks()
        x = parent.winfo_x() + (parent.winfo_width() - self.winfo_width()) // 2
        y = parent.winfo_y() + (parent.winfo_height() - self.winfo_height()) // 2
        self.geometry(f"+{x}+{y}")

    def _build_ui(self, allow_cancel: bool):
        """Build the dialog UI."""
        # Main frame
        main_frame = tk.Frame(self, padx=20, pady=20)
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Status label
        self.status_label = tk.Label(
            main_frame,
            text="Preparing...",
            font=("Arial", 10),
            anchor=tk.W
        )
        self.status_label.pack(fill=tk.X, pady=(0, 10))

        # Progress bar
        self.progress_var = tk.DoubleVar(value=0)
        self.progress_bar = ttk.Progressbar(
            main_frame,
            variable=self.progress_var,
            maximum=100,
            mode='determinate',
            length=460
        )
        self.progress_bar.pack(fill=tk.X, pady=(0, 10))

        # Current item label
        self.current_item_label = tk.Label(
            main_frame,
            text="",
            font=("Arial", 9),
            fg="#555",
            anchor=tk.W
        )
        self.current_item_label.pack(fill=tk.X, pady=(0, 5))

        # Time info frame
        time_frame = tk.Frame(main_frame)
        time_frame.pack(fill=tk.X, pady=(0, 15))

        self.elapsed_label = tk.Label(
            time_frame,
            text="Elapsed: 0s",
            font=("Arial", 9),
            fg="#555"
        )
        self.elapsed_label.pack(side=tk.LEFT)

        self.eta_label = tk.Label(
            time_frame,
            text="",
            font=("Arial", 9),
            fg="#555"
        )
        self.eta_label.pack(side=tk.RIGHT)

        # Cancel button
        if allow_cancel:
            self.cancel_btn = tk.Button(
                main_frame,
                text="Cancel",
                command=self._on_cancel,
                font=("Arial", 10),
                bg="#e74c3c",
                fg="white",
                padx=20,
                pady=5
            )
            self.cancel_btn.pack()

    def update_progress(self, current: int, total: Optional[int] = None,
                       current_item_name: str = "", status: str = ""):
        """
        Update progress.

        Args:
            current: Current item number (0-based or 1-based, depending on your preference)
            total: Total items (if different from initial)
            current_item_name: Name of current item being processed
            status: Status text to display
        """
        if total is not None:
            self.total_items = total

        self.current_item = current

        # Calculate percentage
        if self.total_items > 0:
            percentage = (current / self.total_items) * 100
        else:
            percentage = 0

        self.progress_var.set(percentage)

        # Update status
        if status:
            self.status_label.config(text=status)
        else:
            self.status_label.config(
                text=f"Processing: {current} of {self.total_items} ({percentage:.1f}%)"
            )

        # Update current item
        if current_item_name:
            # Truncate long names
            if len(current_item_name) > 60:
                current_item_name = current_item_name[:57] + "..."
            self.current_item_label.config(text=f"Current: {current_item_name}")

        # Update elapsed time
        elapsed = time.time() - self.start_time
        self.elapsed_label.config(text=f"Elapsed: {self._format_time(elapsed)}")

        # Calculate and update ETA
        if current > 0 and self.total_items > 0:
            items_per_second = current / elapsed
            remaining_items = self.total_items - current

            if items_per_second > 0:
                eta_seconds = remaining_items / items_per_second
                self.eta_label.config(text=f"Remaining: ~{self._format_time(eta_seconds)}")
            else:
                self.eta_label.config(text="Calculating...")
        else:
            self.eta_label.config(text="")

        # Process events to update UI
        self.update_idletasks()

    def set_complete(self, success: bool = True, message: str = ""):
        """
        Mark operation as complete.

        Args:
            success: Whether operation succeeded
            message: Completion message
        """
        if success:
            self.progress_var.set(100)
            self.status_label.config(text=message or "Complete!")
            self.status_label.config(fg="#27ae60")
        else:
            self.status_label.config(text=message or "Failed")
            self.status_label.config(fg="#e74c3c")

        # Disable cancel button if present
        if hasattr(self, 'cancel_btn'):
            self.cancel_btn.config(state=tk.DISABLED)

    def is_cancelled(self) -> bool:
        """Check if user cancelled the operation."""
        return self.cancelled

    def _on_cancel(self):
        """Handle cancel button click."""
        self.cancelled = True
        self.status_label.config(text="Cancelling...", fg="#e67e22")
        if hasattr(self, 'cancel_btn'):
            self.cancel_btn.config(state=tk.DISABLED)

    def _format_time(self, seconds: float) -> str:
        """Format seconds as human-readable time string."""
        if seconds < 60:
            return f"{int(seconds)}s"
        elif seconds < 3600:
            minutes = int(seconds // 60)
            secs = int(seconds % 60)
            return f"{minutes}m {secs}s"
        else:
            hours = int(seconds // 3600)
            minutes = int((seconds % 3600) // 60)
            return f"{hours}h {minutes}m"

    def close(self):
        """Close the dialog."""
        self.grab_release()
        self.destroy()


# Example usage:
if __name__ == "__main__":
    import threading

    def simulate_work(dialog):
        """Simulate a long-running operation."""
        for i in range(1, 101):
            if dialog.is_cancelled():
                dialog.set_complete(False, "Cancelled by user")
                break

            # Simulate work
            time.sleep(0.05)

            # Update progress
            dialog.update_progress(
                current=i,
                current_item_name=f"Item_{i:04d}.jpg",
                status=f"Processing item {i} of 100"
            )
        else:
            dialog.set_complete(True, "All items processed successfully!")

        # Close after 1 second
        time.sleep(1)
        dialog.close()

    # Demo
    root = tk.Tk()
    root.geometry("400x300")

    def start_demo():
        dialog = ProgressDialog(root, "Demo Progress", total_items=100)
        thread = threading.Thread(target=simulate_work, args=(dialog,), daemon=True)
        thread.start()

    tk.Button(root, text="Start Demo", command=start_demo).pack(pady=100)
    root.mainloop()
