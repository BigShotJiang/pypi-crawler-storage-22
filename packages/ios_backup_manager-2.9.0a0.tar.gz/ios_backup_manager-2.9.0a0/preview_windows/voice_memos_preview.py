#!/usr/bin/env python3
"""Voice Memos preview window for displaying voice memo recordings."""

import tkinter as tk
from tkinter import ttk, scrolledtext
from datetime import datetime
from .base import CategoryPreviewWindow


class VoiceMemosPreviewWindow(CategoryPreviewWindow):
    """Preview window for voice memo recordings."""

    def get_item_id(self, item):
        """Get unique ID for a voice memo."""
        return item.get('unique_id', item['z_pk'])

    def display_item_details(self, item):
        """Display voice memo details in the detail pane."""
        # Clear existing content
        for widget in self.detail_content.winfo_children():
            widget.destroy()

        # Create scrollable frame
        canvas = tk.Canvas(self.detail_content, bg='white', highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.detail_content, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Recording title (custom label or filename)
        title = item['custom_label'] if item['custom_label'] else item['filename']
        if not title:
            title = f"Recording {item['z_pk']}"

        title_label = tk.Label(
            scrollable_frame,
            text=title,
            font=('Segoe UI', 20, 'bold'),
            bg='white',
            fg='#333'
        )
        title_label.pack(anchor='w', padx=20, pady=(20, 5))

        # Date and duration
        date_str = self._format_timestamp(item['date'])
        duration_str = self._format_duration(item['duration'])

        info_label = tk.Label(
            scrollable_frame,
            text=f"{date_str} • {duration_str}",
            font=('Segoe UI', 12),
            bg='white',
            fg='#666'
        )
        info_label.pack(anchor='w', padx=20, pady=(0, 15))

        # Status badges
        badge_frame = tk.Frame(scrollable_frame, bg='white')
        badge_frame.pack(anchor='w', padx=20, pady=5)

        if item['has_audio']:
            audio_badge = tk.Label(
                badge_frame,
                text='🎵 Audio Available',
                bg='#34C759',
                fg='white',
                font=('Segoe UI', 10, 'bold'),
                padx=10,
                pady=4
            )
            audio_badge.pack(side='left', padx=(0, 5))

        # Separator
        sep1 = ttk.Separator(scrollable_frame, orient='horizontal')
        sep1.pack(fill='x', padx=20, pady=15)

        # Details section
        details_frame = tk.Frame(scrollable_frame, bg='white')
        details_frame.pack(anchor='w', padx=20, pady=5, fill='x')

        # Filename
        if item['filename']:
            filename_label = tk.Label(
                details_frame,
                text='Filename:',
                font=('Segoe UI', 11, 'bold'),
                bg='white',
                fg='#666',
                width=15,
                anchor='w'
            )
            filename_label.grid(row=0, column=0, sticky='w', pady=5)

            filename_value = tk.Label(
                details_frame,
                text=item['filename'],
                font=('Segoe UI', 11),
                bg='white',
                fg='#333',
                anchor='w'
            )
            filename_value.grid(row=0, column=1, sticky='w', pady=5, padx=10)

        # Custom label (if different from filename)
        if item['custom_label']:
            label_label = tk.Label(
                details_frame,
                text='Custom Label:',
                font=('Segoe UI', 11, 'bold'),
                bg='white',
                fg='#666',
                width=15,
                anchor='w'
            )
            label_label.grid(row=1, column=0, sticky='w', pady=5)

            label_value = tk.Label(
                details_frame,
                text=item['custom_label'],
                font=('Segoe UI', 11),
                bg='white',
                fg='#333',
                anchor='w'
            )
            label_value.grid(row=1, column=1, sticky='w', pady=5, padx=10)

        # Recording date
        if item['date']:
            date_label = tk.Label(
                details_frame,
                text='Recording Date:',
                font=('Segoe UI', 11, 'bold'),
                bg='white',
                fg='#666',
                width=15,
                anchor='w'
            )
            date_label.grid(row=2, column=0, sticky='w', pady=5)

            date_value = tk.Label(
                details_frame,
                text=date_str,
                font=('Segoe UI', 11),
                bg='white',
                fg='#333',
                anchor='w'
            )
            date_value.grid(row=2, column=1, sticky='w', pady=5, padx=10)

        # Duration
        duration_label = tk.Label(
            details_frame,
            text='Duration:',
            font=('Segoe UI', 11, 'bold'),
            bg='white',
            fg='#666',
            width=15,
            anchor='w'
        )
        duration_label.grid(row=3, column=0, sticky='w', pady=5)

        duration_value = tk.Label(
            details_frame,
            text=duration_str,
            font=('Segoe UI', 11),
            bg='white',
            fg='#333',
            anchor='w'
        )
        duration_value.grid(row=3, column=1, sticky='w', pady=5, padx=10)

        # Recording path (technical info)
        if item['path']:
            sep2 = ttk.Separator(scrollable_frame, orient='horizontal')
            sep2.pack(fill='x', padx=20, pady=15)

            path_label = tk.Label(
                scrollable_frame,
                text='Technical Information',
                font=('Segoe UI', 12, 'bold'),
                bg='white',
                fg='#333',
                anchor='w'
            )
            path_label.pack(anchor='w', padx=20, pady=(5, 10))

            path_frame = tk.Frame(scrollable_frame, bg='#f9f9f9')
            path_frame.pack(anchor='w', padx=20, pady=(0, 10), fill='x')

            path_text = tk.Label(
                path_frame,
                text=f"Path: {item['path']}",
                font=('Consolas', 9),
                bg='#f9f9f9',
                fg='#666',
                anchor='w',
                justify='left'
            )
            path_text.pack(anchor='w', padx=10, pady=10)

        # Audio file info
        if item['has_audio']:
            sep3 = ttk.Separator(scrollable_frame, orient='horizontal')
            sep3.pack(fill='x', padx=20, pady=15)

            audio_info_label = tk.Label(
                scrollable_frame,
                text='ℹ️ Audio file will be exported in original format (.m4a)',
                font=('Segoe UI', 10),
                bg='#E3F2FD',
                fg='#1976D2',
                padx=15,
                pady=10
            )
            audio_info_label.pack(anchor='w', padx=20, pady=(0, 20), fill='x')
        else:
            # No audio warning
            sep3 = ttk.Separator(scrollable_frame, orient='horizontal')
            sep3.pack(fill='x', padx=20, pady=15)

            warning_label = tk.Label(
                scrollable_frame,
                text='⚠️ Audio file not found in backup',
                font=('Segoe UI', 10),
                bg='#FFF3E0',
                fg='#F57C00',
                padx=15,
                pady=10
            )
            warning_label.pack(anchor='w', padx=20, pady=(0, 20), fill='x')

        # Pack canvas and scrollbar
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Bind mousewheel
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

        canvas.bind_all("<MouseWheel>", _on_mousewheel)

    def _format_timestamp(self, timestamp):
        """Format Unix timestamp for display."""
        if timestamp is None:
            return "N/A"

        try:
            dt = datetime.fromtimestamp(timestamp)
            return dt.strftime("%B %d, %Y at %I:%M:%S %p")
        except:
            return str(timestamp)

    def _format_duration(self, seconds):
        """Format duration in seconds to human-readable string."""
        if seconds is None or seconds == 0:
            return "0 seconds"

        seconds = int(seconds)
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        secs = seconds % 60

        parts = []
        if hours > 0:
            parts.append(f"{hours} hour{'s' if hours != 1 else ''}")
        if minutes > 0:
            parts.append(f"{minutes} minute{'s' if minutes != 1 else ''}")
        if secs > 0 or not parts:  # Always show seconds if no other parts
            parts.append(f"{secs} second{'s' if secs != 1 else ''}")

        return ", ".join(parts)

    def get_display_text(self, item):
        """Get text to display in the list for this item."""
        # Use custom label if available, otherwise filename
        title = item['custom_label'] if item['custom_label'] else item['filename']
        if not title:
            title = f"Recording {item['z_pk']}"

        # Truncate long titles
        if len(title) > 25:
            title = title[:22] + "..."

        # Format timestamp
        timestamp = item['date']
        try:
            dt = datetime.fromtimestamp(timestamp) if timestamp else None
            time_str = dt.strftime("%m/%d/%y %I:%M %p") if dt else "Unknown"
        except:
            time_str = "Unknown"

        # Format duration
        duration = self._format_duration(item['duration'])

        return f"{title}\n{time_str} • {duration}"

    def get_default_export_extension(self) -> str:
        """Default extension for voice memos export (directory)."""
        return ''

    def get_export_filetypes(self) -> list:
        """File types for voice memos export."""
        return [
            ('All Files', '*.*')
        ]
