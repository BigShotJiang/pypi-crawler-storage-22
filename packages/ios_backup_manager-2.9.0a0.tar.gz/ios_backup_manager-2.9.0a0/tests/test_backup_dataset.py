#!/usr/bin/env python3
"""
test_backup_dataset.py

Comprehensive testing tool for analyzing a dataset of iOS backups.

Capabilities:
- Scan folder of backups and detect iOS versions
- Build compatibility matrix across all backup pairs
- Identify schema differences between iOS versions
- Generate detailed HTML/text reports
- Recommend test merge candidates
- Validate schema compatibility implementation

Usage:
    python test_backup_dataset.py <backups_folder> [--report-html output.html]
"""

import os
import sys
import json
from typing import Dict, List, Tuple, Optional, Set
from collections import defaultdict
from datetime import datetime
import sqlite3
import time

# Import our schema validator
from schema_validator import (
    detect_ios_version,
    get_database_schema,
    compare_schemas,
    validate_backup_merge_compatibility
)


class BackupDatasetAnalyzer:
    """Analyzes a dataset of iOS backups for compatibility testing."""

    def __init__(self, backups_folder: str):
        """
        Initialize the analyzer.

        Args:
            backups_folder: Path to folder containing backup directories
        """
        self.backups_folder = backups_folder
        self.backups = []  # List of {path, uuid, ios_version, device_name}
        self.compatibility_matrix = {}  # (backup1_uuid, backup2_uuid) -> results
        self.schema_differences = defaultdict(list)  # ios_version_pair -> differences

    def scan_backups(self) -> int:
        """
        Scan backups folder and detect all backups with their iOS versions.

        Returns:
            Number of backups found
        """
        print(f"[SCAN] Scanning backups in: {self.backups_folder}")
        print()

        if not os.path.isdir(self.backups_folder):
            print(f"[ERROR] Folder not found: {self.backups_folder}")
            return 0

        # Get all subdirectories (each should be a backup UUID)
        for item in os.listdir(self.backups_folder):
            backup_path = os.path.join(self.backups_folder, item)

            # Check if it's a directory
            if not os.path.isdir(backup_path):
                continue

            # Check if it looks like a backup (has Manifest.db or Info.plist)
            manifest_db = os.path.join(backup_path, "Manifest.db")
            info_plist = os.path.join(backup_path, "Info.plist")

            if not (os.path.exists(manifest_db) or os.path.exists(info_plist)):
                print(f"[SKIP] Not a backup: {item}")
                continue

            # Detect iOS version
            ios_version = detect_ios_version(backup_path)

            # Get device name from Info.plist if available
            device_name = "Unknown"
            if os.path.exists(info_plist):
                try:
                    import plistlib
                    with open(info_plist, 'rb') as f:
                        info = plistlib.load(f)
                        device_name = info.get('Device Name', 'Unknown')
                except:
                    pass

            backup_info = {
                'path': backup_path,
                'uuid': item,
                'ios_version': ios_version or "Unknown",
                'device_name': device_name
            }

            self.backups.append(backup_info)
            print(f"[FOUND] {item}")
            print(f"        iOS: {ios_version or 'Unknown'}")
            print(f"        Device: {device_name}")
            print()

        print(f"[SCAN] Found {len(self.backups)} backups")
        return len(self.backups)

    def group_by_ios_version(self) -> Dict[str, List[Dict]]:
        """
        Group backups by iOS version.

        Returns:
            Dict mapping iOS version to list of backups
        """
        groups = defaultdict(list)
        for backup in self.backups:
            version = backup['ios_version']
            groups[version].append(backup)
        return dict(groups)

    def analyze_compatibility_matrix(self, sample_size: Optional[int] = None, quick_mode: bool = False) -> Dict:
        """
        Build compatibility matrix by comparing all backup pairs.

        PERFORMANCE NOTE: This operation is FAST even for large (100GB+) backups because
        it only reads metadata (plist files and database schemas), NOT actual backup data.

        Expected time: ~10-30 seconds per iOS version pair comparison
        Total time for 20 backups: ~5-10 minutes

        Args:
            sample_size: If specified, only compare this many random pairs (for large datasets)
            quick_mode: If True, only compare sms.db schema (skip other databases)

        Returns:
            Dict containing analysis results
        """
        print("[ANALYSIS] Building compatibility matrix...")
        print("[ANALYSIS] NOTE: Only reading metadata (schemas), NOT actual backup data")
        print("[ANALYSIS] Expected time: ~5-10 minutes for 20 backups")
        print()

        # Group by iOS version first
        version_groups = self.group_by_ios_version()

        # For each iOS version pair, pick one backup from each and compare
        versions = sorted([v for v in version_groups.keys() if v != "Unknown"])

        results = {
            'total_comparisons': 0,
            'compatible_pairs': 0,
            'incompatible_pairs': 0,
            'version_pairs': {},
            'schema_changes': {}
        }

        # Compare each iOS version pair
        for i, version1 in enumerate(versions):
            for version2 in versions[i:]:  # Only compare each pair once (including same version)
                # Pick first backup from each version
                backup1 = version_groups[version1][0]
                backup2 = version_groups[version2][0]

                pair_key = f"{version1} ↔ {version2}"
                print(f"[COMPARE] {pair_key}")
                print(f"          Backup 1: {backup1['uuid'][:8]}... ({backup1['device_name']})")
                print(f"          Backup 2: {backup2['uuid'][:8]}... ({backup2['device_name']})")

                # Time the comparison (to show it's fast)
                start_time = time.time()

                # Run compatibility validation
                validation_results = validate_backup_merge_compatibility(
                    backup1['path'],
                    backup2['path']
                )

                elapsed = time.time() - start_time

                results['total_comparisons'] += 1

                if validation_results['compatible']:
                    results['compatible_pairs'] += 1
                    status = "✓ COMPATIBLE"
                else:
                    results['incompatible_pairs'] += 1
                    status = "✗ INCOMPATIBLE"

                print(f"          Status: {status} (took {elapsed:.1f}s)")

                # Store results
                results['version_pairs'][pair_key] = {
                    'backup1': backup1,
                    'backup2': backup2,
                    'validation': validation_results
                }

                # Extract schema differences
                if validation_results['database_schemas']:
                    schema_diffs = {}
                    for db_name, comparison in validation_results['database_schemas'].items():
                        if comparison['column_differences']:
                            schema_diffs[db_name] = comparison['column_differences']

                    if schema_diffs:
                        results['schema_changes'][pair_key] = schema_diffs
                        print(f"          Schema differences found in {len(schema_diffs)} databases")

                print()

        self.compatibility_matrix = results
        return results

    def generate_text_report(self) -> str:
        """
        Generate a human-readable text report.

        Returns:
            Report text
        """
        lines = []
        lines.append("=" * 100)
        lines.append("iOS BACKUP DATASET ANALYSIS REPORT")
        lines.append("=" * 100)
        lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"Dataset: {self.backups_folder}")
        lines.append("")

        # Summary
        lines.append("SUMMARY")
        lines.append("-" * 100)
        lines.append(f"Total Backups: {len(self.backups)}")

        # Group by iOS version
        version_groups = self.group_by_ios_version()
        lines.append(f"iOS Versions Found: {len([v for v in version_groups.keys() if v != 'Unknown'])}")
        lines.append("")

        # iOS Version Distribution
        lines.append("iOS VERSION DISTRIBUTION")
        lines.append("-" * 100)
        for version in sorted(version_groups.keys()):
            count = len(version_groups[version])
            lines.append(f"  iOS {version:12s} : {count:2d} backup{'s' if count > 1 else ''}")
            for backup in version_groups[version]:
                lines.append(f"    - {backup['uuid'][:16]}... ({backup['device_name']})")
        lines.append("")

        # Compatibility Matrix
        if self.compatibility_matrix:
            lines.append("COMPATIBILITY MATRIX")
            lines.append("-" * 100)
            results = self.compatibility_matrix
            lines.append(f"Total Comparisons: {results['total_comparisons']}")
            lines.append(f"Compatible Pairs: {results['compatible_pairs']}")
            lines.append(f"Incompatible Pairs: {results['incompatible_pairs']}")
            lines.append("")

            # Detail each version pair
            for pair_key, pair_data in results['version_pairs'].items():
                validation = pair_data['validation']
                status = "✓ COMPATIBLE" if validation['compatible'] else "✗ INCOMPATIBLE"

                lines.append(f"{pair_key}: {status}")

                if validation['warnings']:
                    lines.append(f"  Warnings: {len(validation['warnings'])}")
                    for warning in validation['warnings'][:3]:  # Show first 3
                        lines.append(f"    ⚠ {warning}")
                    if len(validation['warnings']) > 3:
                        lines.append(f"    ... and {len(validation['warnings']) - 3} more")

                if validation['errors']:
                    lines.append(f"  Errors: {len(validation['errors'])}")
                    for error in validation['errors'][:3]:  # Show first 3
                        lines.append(f"    ✗ {error}")
                    if len(validation['errors']) > 3:
                        lines.append(f"    ... and {len(validation['errors']) - 3} more")

                lines.append("")

        # Schema Changes
        if self.compatibility_matrix and self.compatibility_matrix['schema_changes']:
            lines.append("SCHEMA CHANGES ACROSS iOS VERSIONS")
            lines.append("-" * 100)

            for pair_key, schema_diffs in self.compatibility_matrix['schema_changes'].items():
                lines.append(f"{pair_key}:")

                for db_name, table_diffs in schema_diffs.items():
                    lines.append(f"  {db_name}:")

                    for table, diffs in table_diffs.items():
                        lines.append(f"    Table '{table}':")

                        if diffs['db1_only']:
                            lines.append(f"      Columns only in first backup: {diffs['db1_only']}")

                        if diffs['db2_only']:
                            lines.append(f"      Columns only in second backup: {diffs['db2_only']}")

                lines.append("")

        # Recommendations
        lines.append("TESTING RECOMMENDATIONS")
        lines.append("-" * 100)

        # Find most different iOS versions
        if self.compatibility_matrix and self.compatibility_matrix['schema_changes']:
            most_different = max(
                self.compatibility_matrix['schema_changes'].items(),
                key=lambda x: len(x[1]),
                default=(None, None)
            )

            if most_different[0]:
                lines.append(f"Most schema differences: {most_different[0]}")
                lines.append(f"  → Good candidate for cross-version merge testing")
                lines.append("")

        # Find identical versions for baseline testing
        version_groups = self.group_by_ios_version()
        for version, backups in version_groups.items():
            if len(backups) >= 2 and version != "Unknown":
                lines.append(f"Multiple backups on iOS {version}: {len(backups)} backups")
                lines.append(f"  → Good candidate for same-version merge testing (baseline)")
                lines.append(f"  → Backups: {', '.join([b['uuid'][:8] + '...' for b in backups[:3]])}")
                lines.append("")

        lines.append("=" * 100)

        return "\n".join(lines)

    def generate_html_report(self) -> str:
        """
        Generate an HTML report with interactive tables.

        Returns:
            HTML content
        """
        # Build version groups
        version_groups = self.group_by_ios_version()

        html = f"""<!DOCTYPE html>
<html>
<head>
    <title>iOS Backup Dataset Analysis</title>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 20px;
            background-color: #f5f5f5;
        }}
        h1, h2 {{
            color: #333;
        }}
        .summary {{
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }}
        th, td {{
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }}
        th {{
            background-color: #4CAF50;
            color: white;
        }}
        tr:hover {{
            background-color: #f5f5f5;
        }}
        .compatible {{
            color: green;
            font-weight: bold;
        }}
        .incompatible {{
            color: red;
            font-weight: bold;
        }}
        .warning {{
            color: orange;
        }}
        .code {{
            font-family: 'Courier New', monospace;
            background-color: #f0f0f0;
            padding: 2px 5px;
            border-radius: 3px;
        }}
        .metric {{
            display: inline-block;
            margin: 10px 20px 10px 0;
        }}
        .metric-value {{
            font-size: 2em;
            font-weight: bold;
            color: #4CAF50;
        }}
        .metric-label {{
            color: #666;
            font-size: 0.9em;
        }}
    </style>
</head>
<body>
    <h1>iOS Backup Dataset Analysis Report</h1>
    <p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
    <p>Dataset: <span class="code">{self.backups_folder}</span></p>

    <div class="summary">
        <h2>Summary</h2>
        <div class="metric">
            <div class="metric-value">{len(self.backups)}</div>
            <div class="metric-label">Total Backups</div>
        </div>
        <div class="metric">
            <div class="metric-value">{len([v for v in version_groups.keys() if v != 'Unknown'])}</div>
            <div class="metric-label">iOS Versions</div>
        </div>"""

        if self.compatibility_matrix:
            html += f"""
        <div class="metric">
            <div class="metric-value">{self.compatibility_matrix['total_comparisons']}</div>
            <div class="metric-label">Comparisons</div>
        </div>
        <div class="metric">
            <div class="metric-value" style="color: green;">{self.compatibility_matrix['compatible_pairs']}</div>
            <div class="metric-label">Compatible</div>
        </div>
        <div class="metric">
            <div class="metric-value" style="color: red;">{self.compatibility_matrix['incompatible_pairs']}</div>
            <div class="metric-label">Incompatible</div>
        </div>"""

        html += """
    </div>

    <h2>iOS Version Distribution</h2>
    <table>
        <tr>
            <th>iOS Version</th>
            <th>Count</th>
            <th>Backups</th>
        </tr>"""

        for version in sorted(version_groups.keys()):
            backups = version_groups[version]
            backup_list = ", ".join([f"{b['uuid'][:8]}..." for b in backups])
            html += f"""
        <tr>
            <td>iOS {version}</td>
            <td>{len(backups)}</td>
            <td class="code">{backup_list}</td>
        </tr>"""

        html += """
    </table>"""

        # Compatibility matrix
        if self.compatibility_matrix:
            html += """
    <h2>Compatibility Matrix</h2>
    <table>
        <tr>
            <th>iOS Version Pair</th>
            <th>Status</th>
            <th>Warnings</th>
            <th>Errors</th>
            <th>Schema Differences</th>
        </tr>"""

            for pair_key, pair_data in self.compatibility_matrix['version_pairs'].items():
                validation = pair_data['validation']
                status_class = "compatible" if validation['compatible'] else "incompatible"
                status_text = "✓ Compatible" if validation['compatible'] else "✗ Incompatible"

                schema_diff_count = 0
                if pair_key in self.compatibility_matrix['schema_changes']:
                    schema_diff_count = len(self.compatibility_matrix['schema_changes'][pair_key])

                html += f"""
        <tr>
            <td class="code">{pair_key}</td>
            <td class="{status_class}">{status_text}</td>
            <td>{len(validation['warnings'])}</td>
            <td>{len(validation['errors'])}</td>
            <td>{schema_diff_count} database(s)</td>
        </tr>"""

            html += """
    </table>"""

        # Schema changes detail
        if self.compatibility_matrix and self.compatibility_matrix['schema_changes']:
            html += """
    <h2>Schema Changes Across iOS Versions</h2>"""

            for pair_key, schema_diffs in self.compatibility_matrix['schema_changes'].items():
                html += f"""
    <h3>{pair_key}</h3>
    <table>
        <tr>
            <th>Database</th>
            <th>Table</th>
            <th>Columns in First Only</th>
            <th>Columns in Second Only</th>
        </tr>"""

                for db_name, table_diffs in schema_diffs.items():
                    for table, diffs in table_diffs.items():
                        cols1 = ", ".join(diffs['db1_only']) if diffs['db1_only'] else "-"
                        cols2 = ", ".join(diffs['db2_only']) if diffs['db2_only'] else "-"

                        html += f"""
        <tr>
            <td class="code">{db_name}</td>
            <td class="code">{table}</td>
            <td class="code">{cols1}</td>
            <td class="code">{cols2}</td>
        </tr>"""

                html += """
    </table>"""

        html += """
</body>
</html>"""

        return html

    def save_report(self, output_path: str, format: str = "text"):
        """
        Save report to file.

        Args:
            output_path: Path to output file
            format: "text" or "html"
        """
        if format == "html":
            content = self.generate_html_report()
        else:
            content = self.generate_text_report()

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(content)

        print(f"[REPORT] Saved to: {output_path}")


def main():
    """Main entry point."""
    if len(sys.argv) < 2:
        print("Usage: python test_backup_dataset.py <backups_folder> [options]")
        print()
        print("Options:")
        print("  --report-html <file>  Generate HTML report")
        print("  --report-text <file>  Generate text report")
        print("  --quick               Quick mode: only scan iOS versions (skip schema comparison)")
        print("  --scan-only           Only scan and list backups (no compatibility analysis)")
        print()
        print("Examples:")
        print('  python test_backup_dataset.py "C:\\Backups\\iTunes" --report-html report.html')
        print('  python test_backup_dataset.py "C:\\Backups\\iTunes" --quick')
        print('  python test_backup_dataset.py "C:\\Backups\\iTunes" --scan-only')
        print()
        print("PERFORMANCE NOTES:")
        print("  - All operations are FAST (metadata only, no actual backup data)")
        print("  - Scanning: ~1 second per backup")
        print("  - Schema comparison: ~10-30 seconds per iOS version pair")
        print("  - Expected total time for 20 backups: ~5-10 minutes")
        sys.exit(1)

    backups_folder = sys.argv[1]

    # Parse options
    html_report = None
    text_report = None
    quick_mode = False
    scan_only = False

    for i, arg in enumerate(sys.argv[2:], start=2):
        if arg == "--report-html" and i + 1 < len(sys.argv):
            html_report = sys.argv[i + 1]
        elif arg == "--report-text" and i + 1 < len(sys.argv):
            text_report = sys.argv[i + 1]
        elif arg == "--quick":
            quick_mode = True
        elif arg == "--scan-only":
            scan_only = True

    # Create analyzer
    analyzer = BackupDatasetAnalyzer(backups_folder)

    # Scan backups
    start_time = time.time()
    count = analyzer.scan_backups()
    scan_time = time.time() - start_time

    if count == 0:
        print("[ERROR] No backups found!")
        sys.exit(1)

    print(f"[SCAN] Completed in {scan_time:.1f} seconds")
    print()

    # If scan-only mode, just print summary and exit
    if scan_only:
        version_groups = analyzer.group_by_ios_version()
        print("=" * 80)
        print("iOS VERSION SUMMARY")
        print("=" * 80)
        for version in sorted(version_groups.keys()):
            backups = version_groups[version]
            print(f"iOS {version:12s}: {len(backups):2d} backup{'s' if len(backups) > 1 else ''}")
            for backup in backups:
                print(f"  - {backup['uuid'][:20]}... ({backup['device_name']})")
        print("=" * 80)
        print(f"\nTotal: {count} backups across {len([v for v in version_groups.keys() if v != 'Unknown'])} iOS versions")
        print("\nTo run full analysis, remove --scan-only flag")
        sys.exit(0)

    # Analyze compatibility
    print("[ANALYSIS] Starting compatibility analysis...")
    analysis_start = time.time()
    analyzer.analyze_compatibility_matrix(quick_mode=quick_mode)
    analysis_time = time.time() - analysis_start
    print(f"[ANALYSIS] Completed in {analysis_time:.1f} seconds ({analysis_time/60:.1f} minutes)")

    print()

    # Generate and print text report
    text_content = analyzer.generate_text_report()
    print(text_content)

    # Save reports
    if html_report:
        analyzer.save_report(html_report, format="html")

    if text_report:
        analyzer.save_report(text_report, format="text")
    elif not html_report:
        # Default: save text report
        default_report = f"backup_analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        analyzer.save_report(default_report, format="text")


if __name__ == "__main__":
    main()
