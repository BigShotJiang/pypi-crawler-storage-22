#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test batch video thumbnail extraction to check for performance and hanging issues.

Tests extracting thumbnails from multiple videos to see if we encounter
the hanging issues seen in the full test.
"""

import os
import sys
import subprocess
import time
import glob

def test_batch_thumbnails():
    """Test thumbnail extraction on multiple videos."""

    print("=" * 80)
    print("Batch Video Thumbnail Extraction Test")
    print("=" * 80)
    print()

    # Find all exported videos
    video_pattern = r"C:\Users\Ontrack\Desktop\html_report_full_test\DCIM\**\*.MOV"
    videos = glob.glob(video_pattern, recursive=True)[:20]  # Test first 20 videos

    if not videos:
        print("No videos found")
        return 1

    print(f"Found {len(videos)} videos to test")
    print()

    # Get ffmpeg path
    try:
        import imageio_ffmpeg
        ffmpeg_exe = imageio_ffmpeg.get_ffmpeg_exe()
    except ImportError:
        print("imageio-ffmpeg not available")
        return 1

    # Test extraction with timeout
    results = []
    total_time = 0

    print("Extracting thumbnails...")
    print()

    for idx, video_path in enumerate(videos, 1):
        filename = os.path.basename(video_path)
        size_mb = os.path.getsize(video_path) / (1024 * 1024)

        output = f"batch_thumb_{idx}.jpg"
        if os.path.exists(output):
            os.remove(output)

        # Use direct ffmpeg with timeout (Method 3 from previous test)
        cmd = [
            ffmpeg_exe,
            '-i', video_path,
            '-vf', 'scale=300:300:force_original_aspect_ratio=decrease',
            '-frames:v', '1',
            '-q:v', '5',
            '-y',
            output
        ]

        start = time.time()
        success = False
        error_msg = None

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=5  # 5 second timeout per video
            )

            elapsed = time.time() - start

            if result.returncode == 0 and os.path.exists(output):
                thumb_kb = os.path.getsize(output) / 1024
                print(f"[{idx:2d}/{len(videos)}] {filename:30s} | {size_mb:5.1f}MB | {elapsed:4.2f}s | {thumb_kb:5.1f}KB | OK")
                success = True
                total_time += elapsed
                os.remove(output)  # Clean up
            else:
                elapsed = time.time() - start
                error_msg = "Failed"
                print(f"[{idx:2d}/{len(videos)}] {filename:30s} | {size_mb:5.1f}MB | {elapsed:4.2f}s | FAILED")

        except subprocess.TimeoutExpired:
            elapsed = time.time() - start
            error_msg = "Timeout"
            print(f"[{idx:2d}/{len(videos)}] {filename:30s} | {size_mb:5.1f}MB | {elapsed:4.2f}s | TIMEOUT")

        except Exception as e:
            elapsed = time.time() - start
            error_msg = str(e)
            print(f"[{idx:2d}/{len(videos)}] {filename:30s} | {size_mb:5.1f}MB | {elapsed:4.2f}s | ERROR: {e}")

        results.append({
            'filename': filename,
            'size_mb': size_mb,
            'time': elapsed,
            'success': success,
            'error': error_msg
        })

    # Summary
    print()
    print("=" * 80)
    print("SUMMARY")
    print("=" * 80)
    print()

    success_count = sum(1 for r in results if r['success'])
    failed_count = len(results) - success_count
    timeout_count = sum(1 for r in results if r.get('error') == 'Timeout')

    print(f"Total videos: {len(results)}")
    print(f"Successful: {success_count}")
    print(f"Failed: {failed_count}")
    print(f"Timeouts: {timeout_count}")
    print()

    if success_count > 0:
        avg_time = total_time / success_count
        print(f"Average time per thumbnail: {avg_time:.2f}s")
        print(f"Total time for successful extractions: {total_time:.2f}s")
        print()

        # Extrapolate to 10k items with 30% videos
        video_count_10k = 3000
        estimated_time = avg_time * video_count_10k
        estimated_minutes = estimated_time / 60

        print(f"PERFORMANCE PROJECTION:")
        print(f"  For 10,000 items (30% videos = 3,000 videos)")
        print(f"  Estimated time: {estimated_minutes:.1f} minutes ({estimated_time:.0f} seconds)")
        print()

        if timeout_count > 0:
            print(f"WARNING: {timeout_count} videos timed out!")
            print("This indicates some videos may still cause hanging issues.")
            print()

    if failed_count > 0:
        print("Failed videos:")
        for r in results:
            if not r['success']:
                error = r.get('error', 'Unknown')
                print(f"  - {r['filename']}: {error}")
        print()

    print("RECOMMENDATION:")
    if timeout_count == 0 and failed_count == 0:
        print("All videos extracted successfully with no timeouts!")
        print("Direct ffmpeg approach is reliable and performant.")
    elif timeout_count > 0:
        print("Some videos still cause timeouts even with 5s limit.")
        print("Consider making video thumbnails OPTIONAL or using placeholders.")
    else:
        print("Some extractions failed but no timeouts detected.")
        print("Investigate failed videos to determine cause.")

    return 0


if __name__ == "__main__":
    sys.exit(test_batch_thumbnails())
