"""
Test dual-mode filtering for Photos & Videos extractor

Tests that:
1. Extraction mode (filter_by_existence=False) gets all Photos.sqlite items (~28,000+)
2. Preview mode (filter_by_existence=True, default) gets only items with files (~15,765)
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from extractors.photos_extractor import PhotosExtractor

backup_path = r"Q:\6697994\iTunes Backup\00008130-001A642E2162001C"

print("=" * 80)
print("Testing Dual-Mode Filtering: Extraction vs Preview")
print("=" * 80)
print()

extractor = PhotosExtractor(backup_path)

# Test 1: Extraction mode (filter_by_existence=False)
print("Test 1: EXTRACTION MODE (filter_by_existence=False)")
print("-" * 80)
extraction_count = extractor.get_count(filter_by_existence=False)
print(f"  Total count: {extraction_count:,}")
print(f"  Expected: ~28,000+ items (all Photos.sqlite items)")
print()

# Get a sample of extraction items
extraction_items = extractor.get_items(limit=10, offset=0, filter_by_existence=False)
print(f"  Sample items retrieved: {len(extraction_items)}")
print(f"  First 3 items:")
for i, item in enumerate(extraction_items[:3], 1):
    fn = item.get('filename', 'Unknown')[:40]
    src = item.get('source', 'unknown')
    print(f"    {i}. {fn:40} source={src}")
print()

# Test 2: Preview mode (filter_by_existence=True, default)
print("Test 2: PREVIEW MODE (filter_by_existence=True, default)")
print("-" * 80)
preview_count = extractor.get_count(filter_by_existence=True)
# Also test default parameter
preview_count_default = extractor.get_count()
print(f"  Total count (explicit True): {preview_count:,}")
print(f"  Total count (default):       {preview_count_default:,}")
print(f"  Expected: ~15,765 items (only files that exist)")
print()

# Get a sample of preview items
preview_items = extractor.get_items(limit=10, offset=0, filter_by_existence=True)
preview_items_default = extractor.get_items(limit=10, offset=0)
print(f"  Sample items retrieved (explicit True): {len(preview_items)}")
print(f"  Sample items retrieved (default):       {len(preview_items_default)}")
print(f"  First 3 items:")
for i, item in enumerate(preview_items[:3], 1):
    fn = item.get('filename', 'Unknown')[:40]
    src = item.get('source', 'unknown')
    print(f"    {i}. {fn:40} source={src}")
print()

# Test 3: Verify difference
print("Test 3: COMPARISON")
print("-" * 80)
difference = extraction_count - preview_count
print(f"  Extraction count:  {extraction_count:,}")
print(f"  Preview count:     {preview_count:,}")
print(f"  Difference:        {difference:,} items")
print(f"  (These are Photos.sqlite items without files in backup)")
print()

# Test 4: Verify defaults match
print("Test 4: DEFAULT PARAMETER VERIFICATION")
print("-" * 80)
counts_match = preview_count == preview_count_default
items_match = len(preview_items) == len(preview_items_default)
print(f"  Count with explicit True matches default: {counts_match}")
print(f"  Items with explicit True match default:   {items_match}")
print()

# Summary
print("=" * 80)
print("SUMMARY")
print("=" * 80)

extraction_ok = 25000 < extraction_count < 45000
preview_ok = 15000 < preview_count < 17000
difference_ok = 10000 < difference < 30000
defaults_ok = counts_match and items_match

print(f"[OK] Extraction mode count in range (25k-45k):    {extraction_ok}")
print(f"[OK] Preview mode count in range (15k-17k):       {preview_ok}")
print(f"[OK] Difference in range (10k-30k):               {difference_ok}")
print(f"[OK] Default parameters work correctly:           {defaults_ok}")
print()

if extraction_ok and preview_ok and difference_ok and defaults_ok:
    print("[SUCCESS] ALL TESTS PASSED")
    print()
    print("Dual-mode filtering is working correctly:")
    print("  - Extraction will attempt all items for maximum coverage")
    print("  - Preview will show only items with existing files (no broken thumbnails)")
else:
    print("[FAILED] SOME TESTS FAILED - Review results above")

print("=" * 80)
