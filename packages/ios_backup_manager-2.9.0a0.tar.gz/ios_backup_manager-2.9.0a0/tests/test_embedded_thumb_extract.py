#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test extracting embedded thumbnails from iOS videos using ffmpeg.

iOS videos (especially from iPhone) may contain embedded thumbnail images
that can be extracted much faster than frame decoding.
"""

import os
import sys
import subprocess
import time

def test_embedded_thumbnail_extraction():
    """Test if we can extract embedded thumbnails from iOS videos."""

    print("=" * 80)
    print("Embedded Thumbnail Extraction Test")
    print("=" * 80)
    print()

    # Use an exported test video
    test_video = r"C:\Users\Ontrack\Desktop\html_report_full_test\DCIM\104APPLE\IMG_4003.MOV"

    if not os.path.exists(test_video):
        print(f"Test video not found: {test_video}")
        return 1

    print(f"Test video: {os.path.basename(test_video)}")
    size_mb = os.path.getsize(test_video) / (1024 * 1024)
    print(f"Size: {size_mb:.1f} MB")
    print()

    # Get ffmpeg path from imageio-ffmpeg
    try:
        import imageio_ffmpeg
        ffmpeg_exe = imageio_ffmpeg.get_ffmpeg_exe()
        print(f"Using ffmpeg: {ffmpeg_exe}")
        print()
    except ImportError:
        print("imageio-ffmpeg not available")
        return 1

    # Test 1: Try to extract embedded thumbnail
    print("=" * 80)
    print("TEST 1: Extract embedded thumbnail (attached_pic)")
    print("=" * 80)
    print()

    output1 = "test_thumb_embedded.jpg"
    if os.path.exists(output1):
        os.remove(output1)

    # Try to extract attached picture stream
    # iOS videos may have an embedded poster frame
    cmd1 = [
        ffmpeg_exe,
        '-i', test_video,
        '-map', '0:v:0',  # First video stream (might be poster)
        '-frames:v', '1',
        '-f', 'image2',
        '-y',
        output1
    ]

    print("Command:", ' '.join(cmd1))
    print()

    start = time.time()
    try:
        result = subprocess.run(
            cmd1,
            capture_output=True,
            text=True,
            timeout=5
        )
        elapsed = time.time() - start

        if result.returncode == 0 and os.path.exists(output1):
            size_kb = os.path.getsize(output1) / 1024
            print(f"SUCCESS! Extracted thumbnail in {elapsed:.2f}s")
            print(f"  Output: {output1}")
            print(f"  Size: {size_kb:.1f} KB")
            print()
        else:
            print(f"Failed (took {elapsed:.2f}s)")
            if result.stderr:
                print("Error:", result.stderr[:500])
            print()

    except subprocess.TimeoutExpired:
        print("TIMEOUT - command took > 5 seconds")
        print()

    # Test 2: Try imageio first frame extraction
    print("=" * 80)
    print("TEST 2: Extract first frame with imageio.v3")
    print("=" * 80)
    print()

    output2 = "test_thumb_imageio.jpg"
    if os.path.exists(output2):
        os.remove(output2)

    try:
        import imageio.v3 as iio
        from PIL import Image

        print("Using imageio to extract first frame...")
        start = time.time()

        # Read first frame
        frame = iio.imread(test_video, index=0)
        elapsed = time.time() - start

        # Convert to PIL and save
        img = Image.fromarray(frame)
        img.thumbnail((300, 300), Image.LANCZOS)
        img.save(output2, 'JPEG', quality=85)

        size_kb = os.path.getsize(output2) / 1024
        print(f"SUCCESS! Extracted frame in {elapsed:.2f}s")
        print(f"  Output: {output2}")
        print(f"  Size: {size_kb:.1f} KB")
        print()

    except Exception as e:
        elapsed = time.time() - start
        print(f"FAILED in {elapsed:.2f}s")
        print(f"Error: {e}")
        print()

    # Test 3: Try ffmpeg direct frame extraction
    print("=" * 80)
    print("TEST 3: Extract first frame directly with ffmpeg")
    print("=" * 80)
    print()

    output3 = "test_thumb_ffmpeg.jpg"
    if os.path.exists(output3):
        os.remove(output3)

    cmd3 = [
        ffmpeg_exe,
        '-i', test_video,
        '-vf', 'scale=300:300:force_original_aspect_ratio=decrease',
        '-frames:v', '1',
        '-q:v', '5',
        '-y',
        output3
    ]

    print("Command:", ' '.join(cmd3))
    print()

    start = time.time()
    try:
        result = subprocess.run(
            cmd3,
            capture_output=True,
            text=True,
            timeout=10
        )
        elapsed = time.time() - start

        if result.returncode == 0 and os.path.exists(output3):
            size_kb = os.path.getsize(output3) / 1024
            print(f"SUCCESS! Extracted thumbnail in {elapsed:.2f}s")
            print(f"  Output: {output3}")
            print(f"  Size: {size_kb:.1f} KB")
            print()
        else:
            print(f"Failed (took {elapsed:.2f}s)")
            if result.stderr:
                print("Error:", result.stderr[:500])
            print()

    except subprocess.TimeoutExpired:
        elapsed = time.time() - start
        print(f"TIMEOUT - command took > {elapsed:.0f} seconds")
        print()

    # Summary
    print("=" * 80)
    print("SUMMARY")
    print("=" * 80)
    print()

    results = []
    if os.path.exists(output1):
        results.append(f"Method 1 (embedded): {output1}")
    if os.path.exists(output2):
        results.append(f"Method 2 (imageio): {output2}")
    if os.path.exists(output3):
        results.append(f"Method 3 (ffmpeg): {output3}")

    if results:
        print("Successful methods:")
        for r in results:
            print(f"  - {r}")
        print()
        print("Compare the files to see which is fastest and best quality.")
    else:
        print("All methods failed - this video may be problematic.")

    print()
    print("Next steps:")
    print("  1. Check the generated thumbnails")
    print("  2. Compare extraction times")
    print("  3. Determine which method is most reliable")
    print()

    return 0


if __name__ == "__main__":
    sys.exit(test_embedded_thumbnail_extraction())
