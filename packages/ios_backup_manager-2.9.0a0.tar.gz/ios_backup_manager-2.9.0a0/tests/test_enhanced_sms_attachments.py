"""
Test enhanced SMS attachment lookup with multiple fallback strategies
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from extractors.sms_extractor import SMSExtractor

backup_path = r"Q:\6697994\iTunes Backup\00008130-001A642E2162001C"

print("=" * 80)
print("Testing Enhanced SMS Attachment Lookup")
print("=" * 80)
print()

# Initialize extractor
extractor = SMSExtractor(backup_path)

# Test attachment paths from Julie conversation
test_attachments = [
    "~/Library/SMS/Attachments/e4/04/at_0_486EE520-C418-4FD3-96EF-827E9A3B62C6/IMG_1015.jpg",
    "~/Library/SMS/Attachments/ac/12/at_0_1EA50915-0919-4F7D-A08C-349A5A3F4054/IMG_7148.jpeg",
    "~/Library/SMS/Attachments/ad/13/at_1_1EA50915-0919-4F7D-A08C-349A5A3F4054/IMG_7145.jpeg",
    "~/Library/SMS/Attachments/d0/00/at_0_62485580-8237-42C9-9635-1ACFD8B5BECE/tmp.gif",
    "~/Library/SMS/Attachments/c7/07/at_0_1ACB2019-3BE6-422D-8D99-7F738EC43345/RenderedImage.jpg",
]

found_count = 0
not_found_count = 0

for att_path in test_attachments:
    filename = os.path.basename(att_path)
    print(f"Testing: {filename}")
    print(f"  Full path: {att_path}")

    result = extractor.get_attachment_path(att_path)

    if result:
        found_count += 1
        print(f"  [FOUND]: {result}")
        # Check file size
        if os.path.exists(result):
            size = os.path.getsize(result)
            print(f"    Size: {size:,} bytes ({size / 1024:.1f} KB)")
    else:
        not_found_count += 1
        print(f"  [NOT FOUND]")
    print()

print("=" * 80)
print("SUMMARY:")
print(f"  Found: {found_count}/{len(test_attachments)}")
print(f"  Not found: {not_found_count}/{len(test_attachments)}")
print()

if found_count > 0:
    print("SUCCESS! Enhanced lookup is finding more attachments!")
    print("These attachments will now appear in SMS exports instead of showing")
    print("'[Attachment not found]' placeholders.")
else:
    print("No additional attachments found with enhanced lookup.")
    print("This backup may not have these files (iCloud Photos, etc.)")

print("=" * 80)
