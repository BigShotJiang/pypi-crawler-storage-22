"""
Verify that extraction behavior is unchanged after adding filter_by_existence parameter.

This tests that extraction gets the same items as before (or more).
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from extractors.photos_extractor import PhotosExtractor

backup_path = r"Q:\6697994\iTunes Backup\00008130-001A642E2162001C"

print("=" * 80)
print("Verifying Extraction Behavior Unchanged")
print("=" * 80)
print()

extractor = PhotosExtractor(backup_path)

# Test 1: Extraction mode (what full_extraction_manager.py uses)
print("Test 1: EXTRACTION MODE (filter_by_existence=False)")
print("-" * 80)
extraction_count = extractor.get_count(filter_by_existence=False)
extraction_items = extractor.get_items(limit=None, offset=0, filter_by_existence=False)
print(f"  Count: {extraction_count:,}")
print(f"  Items retrieved: {len(extraction_items):,}")
print(f"  Breakdown:")

from_database = sum(1 for item in extraction_items if item.get('source') == 'database')
from_manifest = sum(1 for item in extraction_items if item.get('source') == 'manifest')
print(f"    From Photos.sqlite: {from_database:,}")
print(f"    From Manifest only: {from_manifest:,}")
print()

# Test 2: Verify we get ALL items (no filtering)
print("Test 2: VERIFY NO FILTERING IN EXTRACTION MODE")
print("-" * 80)
print(f"  Total items: {len(extraction_items):,}")
print(f"  Expected: 40,000-45,000 (all Photos.sqlite + Manifest items)")

# Sample a few items to check if they include items without files
sample_items = extraction_items[:20]
print(f"  Sample first 20 items (should include some without files):")
for i, item in enumerate(sample_items[:5], 1):
    fn = item.get('filename', 'Unknown')[:35]
    src = item.get('source', 'unknown')
    print(f"    {i}. {fn:35} source={src}")
print()

# Test 3: Preview mode for comparison (what preview dialog uses)
print("Test 3: PREVIEW MODE for comparison (filter_by_existence=True)")
print("-" * 80)
preview_count = extractor.get_count(filter_by_existence=True)
preview_items = extractor.get_items(limit=10, offset=0, filter_by_existence=True)
print(f"  Count: {preview_count:,}")
print(f"  Items retrieved: {len(preview_items)}")
print()

# Summary
print("=" * 80)
print("SUMMARY")
print("=" * 80)

extraction_ok = 40000 < extraction_count < 45000
extraction_items_ok = len(extraction_items) == extraction_count
preview_ok = 15000 < preview_count < 18000
different = extraction_count > preview_count

print(f"[OK] Extraction gets all items (40k-45k):        {extraction_ok} ({extraction_count:,})")
print(f"[OK] Extraction items match count:               {extraction_items_ok}")
print(f"[OK] Preview filters correctly (15k-18k):        {preview_ok} ({preview_count:,})")
print(f"[OK] Extraction gets more than preview:          {different}")
print()

if extraction_ok and extraction_items_ok and preview_ok and different:
    print("[SUCCESS] Extraction behavior is UNCHANGED (or improved)!")
    print()
    print("Extraction will attempt all items:")
    print(f"  - {from_database:,} Photos.sqlite items")
    print(f"  - {from_manifest:,} Manifest-only items")
    print(f"  - Total: {extraction_count:,} items")
    print()
    print("Expected extraction results:")
    print(f"  - ~3,240 Photos.sqlite items will succeed (have files)")
    print(f"  - ~12,500 Manifest-only items will succeed")
    print(f"  - Total: ~15,740 successful extractions")
    print(f"  - ~{extraction_count - 16000:,} items will fail (no files/iCloud-only)")
else:
    print("[WARNING] Some tests failed - review results")

print("=" * 80)
