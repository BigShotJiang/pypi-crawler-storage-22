"""
Find the correct domain for SMS attachments in the manifest
"""
import sqlite3
import os

backup_path = r"Q:\6697994\iTunes Backup\00008130-001A642E2162001C"
manifest_db = os.path.join(backup_path, "Manifest.db")

conn = sqlite3.connect(manifest_db)
conn.row_factory = sqlite3.Row
cur = conn.cursor()

print("=" * 80)
print("Finding SMS Attachment Files in Manifest")
print("=" * 80)
print()

# Search for files with SMS/Attachments in their path
print("Files containing 'SMS/Attachments' in path:")
print("-" * 80)

cur.execute("""
SELECT domain, relativePath, fileID
FROM Files
WHERE relativePath LIKE '%SMS/Attachments%'
LIMIT 20
""")

sms_attachments = cur.fetchall()
if sms_attachments:
    print(f"Found {len(sms_attachments)} files:")
    for f in sms_attachments:
        print(f"Domain: {f['domain']}")
        print(f"Path: {f['relativePath']}")
        print(f"FileID: {f['fileID']}")
        print()
else:
    print("NO FILES FOUND with 'SMS/Attachments' in path!")
    print()

# Search for files with SMS in their path (broader search)
print()
print("Files containing 'SMS' anywhere in path:")
print("-" * 80)

cur.execute("""
SELECT domain, relativePath, fileID
FROM Files
WHERE relativePath LIKE '%SMS%'
LIMIT 20
""")

sms_files = cur.fetchall()
if sms_files:
    print(f"Found {len(sms_files)} files:")
    for f in sms_files:
        print(f"Domain: {f['domain']}")
        print(f"Path: {f['relativePath'][:80]}")
        print()
else:
    print("NO FILES FOUND with 'SMS' in path!")
    print()

# Get all unique domains in manifest
print()
print("All unique domains in manifest:")
print("-" * 80)

cur.execute("SELECT DISTINCT domain FROM Files ORDER BY domain")
domains = [row[0] for row in cur.fetchall()]
for domain in domains:
    cur.execute("SELECT COUNT(*) FROM Files WHERE domain = ?", (domain,))
    count = cur.fetchone()[0]
    print(f"  {domain:50} ({count} files)")

conn.close()

print()
print("=" * 80)
