"""
Test HTML export with FullSizeRender files to verify thumbnail issue.
"""
import sys
import os
import shutil

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from extractors.photos_extractor import PhotosExtractor

# Backup with FullSizeRender files
backup_path = r"Q:\6697994\iTunes Backup\00008130-001A642E2162001C"
output_dir = r"C:\Users\Ontrack\Desktop\fullsizerender_test"

print("=" * 80)
print("FullSizeRender Thumbnail Test")
print("=" * 80)
print()
print(f"Backup: {backup_path}")
print(f"Output: {output_dir}")
print()

# Clean output directory
if os.path.exists(output_dir):
    print(f"Cleaning existing output directory...")
    shutil.rmtree(output_dir)
    print()

# Initialize extractor
print("Initializing extractor...")
extractor = PhotosExtractor(backup_path)
extractor.use_hybrid_extraction = True
print()

# Get newest 100 items (should include many FullSizeRender files)
print("Fetching newest 100 items (date-desc)...")
items = extractor.get_items_hybrid(limit=100, offset=0, sort_by='date-desc', filter_by_existence=True)
print(f"Fetched {len(items)} items")
print()

# Count FullSizeRender files
fullsize_items = [item for item in items if 'FullSizeRender' in item.get('filename', '')]
print(f"FullSizeRender files in this batch: {len(fullsize_items)}")
if fullsize_items:
    print()
    print("Sample FullSizeRender files:")
    for item in fullsize_items[:5]:
        print(f"  - {item.get('filename')} (in {item.get('directory', 'Unknown')})")
print()

# Export with HTML report
print("=" * 80)
print("Exporting with HTML report...")
print("=" * 80)
print()

def progress_cb(current, total, item_name):
    if current % 10 == 0:
        print(f"[{current}/{total}] {item_name}")
    return True

exported, failed = extractor.export(
    items=items,
    output_path=output_dir,
    format='files',
    organize_by_date=False,  # Preserve directory structure
    convert_heic=False,
    generate_html_report=True,
    progress_callback=progress_cb
)

print()
print("=" * 80)
print("RESULTS")
print("=" * 80)
print(f"Exported: {exported} items")
print(f"Failed: {failed} items")
print()
print(f"HTML Report: {output_dir}\\index.html")
print()

# Inspect thumbnails directory
thumb_dir = os.path.join(output_dir, 'thumbnails')
if os.path.exists(thumb_dir):
    thumb_files = [f for f in os.listdir(thumb_dir) if f.endswith('.jpg')]
    fullsize_thumbs = [f for f in thumb_files if 'FullSizeRender' in f]

    print(f"Total thumbnails: {len(thumb_files)}")
    print(f"FullSizeRender thumbnails: {len(fullsize_thumbs)}")
    print()

    if fullsize_thumbs:
        print("FullSizeRender thumbnail filenames (first 10):")
        for fname in sorted(fullsize_thumbs)[:10]:
            fpath = os.path.join(thumb_dir, fname)
            size = os.path.getsize(fpath)
            print(f"  - {fname} ({size:,} bytes)")
        print()

        # Check for identical file sizes (might indicate duplicates)
        size_groups = {}
        for fname in fullsize_thumbs:
            fpath = os.path.join(thumb_dir, fname)
            size = os.path.getsize(fpath)
            if size not in size_groups:
                size_groups[size] = []
            size_groups[size].append(fname)

        duplicates = {size: files for size, files in size_groups.items() if len(files) > 1}
        if duplicates:
            print("[WARNING] Thumbnails with identical file sizes (might be duplicates):")
            for size, files in list(duplicates.items())[:3]:
                print(f"  {size:,} bytes ({len(files)} files):")
                for fname in files[:5]:
                    print(f"    - {fname}")
            print()
        else:
            print("[PASS] All FullSizeRender thumbnails have unique file sizes")
            print()

print("=" * 80)
print("Next Steps:")
print("  1. Open: file:///C:/Users/Ontrack/Desktop/fullsizerender_test/index.html")
print("  2. Scroll to find FullSizeRender files")
print("  3. Check if all FullSizeRender files have unique thumbnails")
print("  4. Click each thumbnail to verify it matches the full-size image")
print("=" * 80)
