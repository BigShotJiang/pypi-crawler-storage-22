#!/usr/bin/env python3
"""Test if VoiceMemosExtractor works when imported the same way the GUI does."""

import sys

BACKUP_PATH = r"Q:\6695545\iTunes Backup\00008020-0019145E0102002E"

print("Testing GUI integration for Voice Memos...")
print(f"Backup: {BACKUP_PATH}")
print()

try:
    # Import the same way full_extraction_manager.py does
    from extractors.voice_memos_extractor import VoiceMemosExtractor

    print("1. Creating VoiceMemosExtractor instance...")
    extractor = VoiceMemosExtractor(BACKUP_PATH)
    print(f"   [OK] Extractor created")
    print(f"   Database: {extractor.recordings_db_path}")
    print(f"   Domain: {extractor.voice_memos_domain}")
    print(f"   Table: {extractor.table_name}")
    print()

    print("2. Calling get_count()...")
    count = extractor.get_count()
    print(f"   [OK] Count: {count}")
    print()

    if count > 0:
        print(f"SUCCESS! GUI should show {count} voice memos")
    else:
        print("WARNING: Count is 0 - GUI will show 0")

except FileNotFoundError as e:
    print(f"[ERROR] FileNotFoundError: {e}")
    print("GUI will mark voice memos as unavailable")
except Exception as e:
    print(f"[ERROR] Unexpected exception: {e}")
    print("GUI will mark voice memos as unavailable")
    import traceback
    traceback.print_exc()
