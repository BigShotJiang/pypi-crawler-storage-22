#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test script for Photos HTML Report Generation.

This script tests the complete flow:
1. Export photos with thumbnails
2. Generate HTML report
3. Verify HTML file is created

Usage:
    python test_html_report.py [backup_path]
"""

import os
import sys

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from extractors.photos_extractor import PhotosExtractor


def progress_callback(current, total, item_name):
    """Simple progress display."""
    percentage = (current / total) * 100
    print(f"[{current}/{total}] ({percentage:.1f}%) - {item_name}")
    return True  # Continue processing


def test_html_report():
    """Test HTML report generation."""

    print("=" * 80)
    print("Photos HTML Report Generation Test")
    print("=" * 80)
    print()

    # Get backup path
    if len(sys.argv) > 1:
        backup_path = sys.argv[1]
        test_count = int(sys.argv[2]) if len(sys.argv) > 2 else 250
    else:
        # Use default test backup (good dataset)
        backup_path = r"Q:\6690340\iTunes Backup\00008020-000E09393C89002E"
        test_count = 250
        print(f"Using default test backup: {backup_path}")
        print()

    if not os.path.isdir(backup_path):
        print(f"ERROR: Backup path not found: {backup_path}")
        return 1

    print(f"Backup path: {backup_path}")
    print()

    # Set test count
    print(f"Testing with {test_count} photos")
    print()

    # Set output directory
    output_path = os.path.join(os.path.expanduser("~"), "Desktop", "html_report_full_test")
    print(f"Output: {output_path}")
    print()

    # Create output directory
    os.makedirs(output_path, exist_ok=True)

    # Initialize extractor
    print("Initializing photos extractor...")
    try:
        extractor = PhotosExtractor(backup_path)
    except Exception as e:
        print(f"ERROR: Failed to initialize extractor: {e}")
        import traceback
        traceback.print_exc()
        return 1

    # Get photo count
    total_photos = extractor.get_count()
    print(f"Found {total_photos} total photos/videos in backup")
    print()

    if total_photos == 0:
        print("No photos found in backup")
        return 1

    # Get a small subset
    print(f"Fetching {test_count} items...")
    items = extractor.get_items(limit=test_count)

    if not items:
        print("Failed to fetch items")
        return 1

    print(f"Fetched {len(items)} items")
    print()

    # Show what we're exporting
    print("Items to export:")
    for idx, item in enumerate(items[:5], 1):
        filename = item.get('filename', 'Unknown')
        kind = 'Video' if item.get('kind') == 1 else 'Photo'
        print(f"  {idx}. {filename} ({kind})")
    if len(items) > 5:
        print(f"  ... and {len(items) - 5} more")
    print()

    # Export with HTML report generation
    print("=" * 80)
    print("Starting export with HTML report generation...")
    print("=" * 80)
    print()

    try:
        exported, failed = extractor.export(
            items=items,
            output_path=output_path,
            format='files',
            progress_callback=progress_callback,
            convert_heic=True,
            organize_by_date=False,
            generate_html_report=True  # ← THIS ENABLES HTML REPORT GENERATION
        )

        print()
        print("=" * 80)
        print("RESULTS")
        print("=" * 80)
        print(f"Exported: {exported} items")
        print(f"Failed:   {failed} items")
        print()

        # Check if HTML report was created
        html_path = os.path.join(output_path, 'index.html')
        if os.path.exists(html_path):
            html_size = os.path.getsize(html_path) / 1024
            print(f"HTML Report created: {html_path}")
            print(f"   Size: {html_size:.1f} KB")
            print()

            # Check if thumbnails were created
            thumb_dir = os.path.join(output_path, 'thumbnails')
            if os.path.exists(thumb_dir):
                thumbnails = [f for f in os.listdir(thumb_dir) if f.endswith('.jpg')]
                print(f"Thumbnails created: {len(thumbnails)}")
                print(f"   Location: {thumb_dir}")
                print()
        else:
            print(f"HTML Report NOT created at {html_path}")
            print()
            return 1

        # Check exported files
        photos_dir = os.path.join(output_path, 'Photos')
        videos_dir = os.path.join(output_path, 'Videos')

        photo_count = len(os.listdir(photos_dir)) if os.path.exists(photos_dir) else 0
        video_count = len(os.listdir(videos_dir)) if os.path.exists(videos_dir) else 0

        print(f"Photos exported: {photo_count}")
        if photo_count > 0:
            print(f"   Location: {photos_dir}")
        print()

        if video_count > 0:
            print(f"Videos exported: {video_count}")
            print(f"   Location: {videos_dir}")
            print()

        print("=" * 80)
        print("TEST COMPLETE!")
        print("=" * 80)
        print()
        print("Next steps:")
        print("  1. Open the HTML report in your browser:")
        print(f"     {html_path}")
        print("  2. Test the following features:")
        print("     • Grid view displays all photos")
        print("     • List view shows metadata")
        print("     • Map view plots GPS-tagged photos")
        print("     • Click a photo to open detail modal")
        print("     • Test filtering (by type)")
        print("     • Test sorting (by date, name, size)")
        print("     • Test search (type filename)")
        print("     • Test keyboard navigation (arrow keys in modal)")
        print()
        print(f"Output directory: {output_path}")

        return 0

    except Exception as e:
        print()
        print("=" * 80)
        print("ERROR DURING EXPORT")
        print("=" * 80)
        print(f"{e}")
        print()
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(test_html_report())
