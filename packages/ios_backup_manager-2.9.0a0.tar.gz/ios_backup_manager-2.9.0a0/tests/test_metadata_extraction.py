#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test script for metadata extraction.

Tests EXIF extraction from the photo exported in the previous test.
"""

import os
import sys
import json

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from extractors.photos_extractor import PhotosExtractor


def test_metadata_extraction():
    """Test metadata extraction on exported photo."""

    print("=" * 80)
    print("📊 Metadata Extraction Test")
    print("=" * 80)
    print()

    # Use the photo exported in previous test
    test_photo = r"O:\Personal\Martin\JIT\iOSBackupMerger\testdata\2021-01-26_12-40-07_IMG_7354.heic"

    if not os.path.exists(test_photo):
        print(f"❌ Test photo not found: {test_photo}")
        print()
        print("Please run test_thumbnail_generation.py first to create test files.")
        return 1

    print(f"✅ Test photo found: {os.path.basename(test_photo)}")
    print()

    # Create extractor instance (need backup path, but we're testing directly on file)
    # For this test, we'll instantiate PhotosExtractor and call methods directly
    backup_path = r"Q:\6674965\iTunes Backup\bdc8c86654f6e875524f098618620ee06685f31c"

    try:
        extractor = PhotosExtractor(backup_path)
    except Exception as e:
        print(f"⚠️  Warning: Could not initialize extractor: {e}")
        print("   (This is OK for metadata testing - we can still test extraction methods)")
        # Create a minimal instance just for testing
        extractor = PhotosExtractor.__new__(PhotosExtractor)

    print("🔍 Extracting metadata...")
    print()

    # Test photo metadata extraction
    metadata = extractor._extract_photo_metadata(
        file_path=test_photo,
        relative_path="PhotoData\CPLAssets\group160\6C019C58-24F6-40E1-93B1-D512036305A0.JPG",
        
        converted_from_heic=False
    )

    print("=" * 80)
    print("📋 EXTRACTED METADATA")
    print("=" * 80)
    print()

    # Display metadata in formatted way
    print("📄 Basic Info:")
    print(f"   Filename: {metadata.get('filename')}")
    print(f"   Type: {metadata.get('type')}")
    print(f"   Size: {metadata.get('size', 0) / (1024*1024):.2f} MB")
    if 'width' in metadata and 'height' in metadata:
        mp = (metadata['width'] * metadata['height']) / 1_000_000
        print(f"   Resolution: {metadata['width']} × {metadata['height']} ({mp:.1f} MP)")
    print()

    if 'date_taken' in metadata:
        print("📅 Date & Time:")
        print(f"   Date Taken: {metadata['date_taken']}")
        print()

    if 'gps' in metadata:
        print("📍 Location (GPS):")
        gps = metadata['gps']
        print(f"   Latitude: {gps['lat']}°")
        print(f"   Longitude: {gps['lon']}°")
        print(f"   Google Maps: https://www.google.com/maps?q={gps['lat']},{gps['lon']}")
        print()
    else:
        print("📍 Location: No GPS data")
        print()

    if 'camera' in metadata:
        print("📷 Camera Info:")
        camera = metadata['camera']
        if 'make' in camera or 'model' in camera:
            print(f"   Device: {camera.get('make', '')} {camera.get('model', '')}")
        if 'iso' in camera:
            print(f"   ISO: {camera['iso']}")
        if 'aperture' in camera:
            print(f"   Aperture: f/{camera['aperture']}")
        if 'shutter_speed' in camera:
            print(f"   Shutter Speed: {camera['shutter_speed']}")
        print()
    else:
        print("📷 Camera Info: Not available")
        print()

    print("=" * 80)
    print("📝 RAW METADATA (JSON)")
    print("=" * 80)
    print(json.dumps(metadata, indent=2))
    print()

    print("=" * 80)
    print("✅ METADATA EXTRACTION TEST COMPLETE")
    print("=" * 80)
    print()

    # Check what data was extracted
    has_exif = 'date_taken' in metadata or 'gps' in metadata or 'camera' in metadata

    if has_exif:
        print("✅ EXIF data successfully extracted")
        if 'gps' in metadata:
            print("✅ GPS location found")
        if 'camera' in metadata:
            print("✅ Camera information found")
    else:
        print("⚠️  No EXIF data found (photo may not have metadata)")

    print()
    print("This metadata will be used in the HTML report for:")
    print("  • Date range filtering")
    print("  • Location-based grouping")
    print("  • Camera/device filtering")
    print("  • Detailed photo information modal")

    return 0


if __name__ == "__main__":
    sys.exit(test_metadata_extraction())
