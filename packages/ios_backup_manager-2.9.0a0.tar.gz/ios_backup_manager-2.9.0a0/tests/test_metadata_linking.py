"""
Test metadata linking for Adjustments/Mutations files.
"""
import sys
import os
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from extractors.photos_extractor import PhotosExtractor

backup_path = r"Q:\6697994\iTunes Backup\00008130-001A642E2162001C"

APPLE_EPOCH = datetime(2001, 1, 1)

print("=" * 80)
print("TESTING METADATA LINKING FOR ADJUSTMENTS FILES")
print("=" * 80)
print()

# Initialize extractor (this will build the metadata lookup index)
print("Initializing extractor...")
extractor = PhotosExtractor(backup_path)
extractor.use_hybrid_extraction = True

print()
print(f"Metadata lookup index entries: {len(extractor._metadata_lookup_index):,}")
print()

# Test 1: Get all items and check for our known Adjustments files
print("=" * 80)
print("Test 1: Searching for IMG_9952.JPG and IMG_0115 FullSizeRender")
print("=" * 80)
print()

all_items = extractor.get_items_hybrid(limit=None, offset=0, sort_by='date-desc', filter_by_existence=True)
print(f"Total items: {len(all_items):,}")
print()

# Search for IMG_9952
img_9952_items = [item for item in all_items if '9952' in item.get('filename', '')]
if img_9952_items:
    print(f"Found {len(img_9952_items)} items with '9952' in filename:")
    for item in img_9952_items:
        filename = item.get('filename')
        date_created = item.get('date_created')
        source = item.get('source')
        metadata_source = item.get('metadata_source', 'N/A')
        position = all_items.index(item) + 1

        print(f"  {filename}")
        print(f"    Position: {position} of {len(all_items):,}")
        print(f"    Source: {source}")
        print(f"    Metadata source: {metadata_source}")
        print(f"    Date Created (raw): {date_created}")
        if date_created:
            readable_date = APPLE_EPOCH + timedelta(seconds=date_created)
            print(f"    Date Created: {readable_date.strftime('%b %d, %Y, %I:%M %p')}")
        print()
else:
    print("[X] No items with '9952' found")
    print()

# Search for IMG_0115
img_0115_items = [item for item in all_items if '0115' in item.get('filename', '') or
                  ('0115' in item.get('directory', '') and 'FullSizeRender' in item.get('filename', ''))]
if img_0115_items:
    print(f"Found {len(img_0115_items)} items related to IMG_0115:")
    for item in img_0115_items:
        filename = item.get('filename')
        date_created = item.get('date_created')
        source = item.get('source')
        metadata_source = item.get('metadata_source', 'N/A')
        directory = item.get('directory', '')
        position = all_items.index(item) + 1

        # Only show FullSizeRender in Adjustments for IMG_0115
        if 'Adjustments' in directory and '0115' in directory:
            print(f"  {filename}")
            print(f"    Position: {position} of {len(all_items):,}")
            print(f"    Directory: {directory}")
            print(f"    Source: {source}")
            print(f"    Metadata source: {metadata_source}")
            print(f"    Date Created (raw): {date_created}")
            if date_created:
                readable_date = APPLE_EPOCH + timedelta(seconds=date_created)
                print(f"    Date Created: {readable_date.strftime('%b %d, %Y, %I:%M %p')}")
            print()

# Test 2: Check top 5 newest items
print("=" * 80)
print("Test 2: Top 5 Newest Items (Should include our Adjustments files)")
print("=" * 80)
print()

for i, item in enumerate(all_items[:5], 1):
    filename = item.get('filename', 'Unknown')
    date_created = item.get('date_created')
    source = item.get('source')
    metadata_source = item.get('metadata_source', 'N/A')

    date_str = "N/A"
    if date_created:
        readable_date = APPLE_EPOCH + timedelta(seconds=date_created)
        date_str = readable_date.strftime('%b %d, %Y, %I:%M %p')

    print(f"{i}. {filename[:50]:50}")
    print(f"   Date: {date_str}")
    print(f"   Source: {source}, Metadata: {metadata_source}")
    print()

# Test 3: Verify FullSizeRender files got metadata
print("=" * 80)
print("Test 3: All FullSizeRender Files with Metadata")
print("=" * 80)
print()

fullsize_items = [item for item in all_items if 'FullSizeRender' in item.get('filename', '')]
fullsize_with_metadata = [item for item in fullsize_items if item.get('date_created') is not None]

print(f"Total FullSizeRender files: {len(fullsize_items)}")
print(f"FullSizeRender with metadata: {len(fullsize_with_metadata)}")
print(f"Success rate: {len(fullsize_with_metadata) / len(fullsize_items) * 100:.1f}%" if fullsize_items else "N/A")
print()

if fullsize_with_metadata:
    print("Sample FullSizeRender files with metadata (first 5):")
    for i, item in enumerate(fullsize_with_metadata[:5], 1):
        filename = item.get('filename')
        date_created = item.get('date_created')
        directory = item.get('directory', '')

        date_str = "N/A"
        if date_created:
            readable_date = APPLE_EPOCH + timedelta(seconds=date_created)
            date_str = readable_date.strftime('%b %d, %Y, %I:%M %p')

        print(f"  {i}. {filename}")
        print(f"     Directory: {directory[:70]}...")
        print(f"     Date: {date_str}")
        print()

print("=" * 80)
print("SUMMARY")
print("=" * 80)

# Expected results
expected_img_9952_date = "Nov 24, 2025"
expected_img_0115_date = "Nov 25, 2025"

img_9952_pass = any(item.get('date_created') and
                     APPLE_EPOCH + timedelta(seconds=item.get('date_created')) > datetime(2025, 11, 24)
                     for item in img_9952_items) if img_9952_items else False

img_0115_pass = any(item.get('date_created') and
                     APPLE_EPOCH + timedelta(seconds=item.get('date_created')) > datetime(2025, 11, 25)
                     for item in img_0115_items) if img_0115_items else False

print(f"[{'PASS' if img_9952_pass else 'FAIL'}] IMG_9952.JPG has metadata from original")
print(f"[{'PASS' if img_0115_pass else 'FAIL'}] IMG_0115 FullSizeRender has metadata from original")
print(f"[{'PASS' if fullsize_with_metadata else 'FAIL'}] FullSizeRender files linked to metadata")
print()

if img_9952_pass and img_0115_pass:
    print("[SUCCESS] Metadata linking is working correctly!")
    print("          Adjustments files now inherit metadata from originals.")
else:
    print("[REVIEW] Some items may not have been linked correctly.")

print("=" * 80)
