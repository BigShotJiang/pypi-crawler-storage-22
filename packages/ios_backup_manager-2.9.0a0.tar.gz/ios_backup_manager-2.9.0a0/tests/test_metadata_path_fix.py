"""
Test that removing the '/Metadata/' filter includes the 1,079 missing files.

This test verifies that files in PhotoData/Metadata/PhotoData/CPLAssets/ paths
are now included in the preview.
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from extractors.photos_extractor import PhotosExtractor

backup_path = r"Q:\6697994\iTunes Backup\00008130-001A642E2162001C"

print("=" * 80)
print("TESTING METADATA PATH FIX")
print("=" * 80)
print()

extractor = PhotosExtractor(backup_path)
extractor.use_hybrid_extraction = True

# Test get_count() - should return 16,811
print("Step 1: Check get_count() with filter_by_existence=True")
print("-" * 80)
count = extractor.get_count(filter_by_existence=True)
print(f"  get_count() returns: {count:,}")
print(f"  Expected: 16,811")
print(f"  Match: {count == 16811}")
print()

# Test get_available_count() - should also return 16,811 now
print("Step 2: Check get_available_count() (what preview uses)")
print("-" * 80)
available_count = extractor.get_available_count()
print(f"  get_available_count() returns: {available_count:,}")
print(f"  Expected: 16,811")
print(f"  Match: {available_count == 16811}")
print()

# Get hybrid items and check for Metadata paths
print("Step 3: Check that Metadata path files are included")
print("-" * 80)
hybrid_items = extractor.get_items_hybrid(limit=None, offset=0, filter_by_existence=True)
print(f"  Total hybrid items: {len(hybrid_items):,}")

# Look for files with 'Metadata' in their paths
metadata_path_items = []
for item in hybrid_items:
    path = item.get('directory') or item.get('path') or ''
    if 'Metadata' in path:
        metadata_path_items.append(item)
        if len(metadata_path_items) <= 5:
            print(f"    Found: {item.get('filename')} from {path[:70]}")

print(f"  Items with 'Metadata' in path: {len(metadata_path_items):,}")
print(f"  Expected: ~1,079")
print()

# Calculate pagination
print("Step 4: Calculate Preview Pagination")
print("-" * 80)
items_per_page = 50
total_pages = (available_count + items_per_page - 1) // items_per_page
print(f"  Total items: {available_count:,}")
print(f"  Items per page: {items_per_page}")
print(f"  Total pages: {total_pages}")
print(f"  Expected pages: 337")
print()

# Summary
print("=" * 80)
print("TEST RESULTS")
print("=" * 80)
print()

count_matches = count == 16811
available_matches = available_count == 16811
has_metadata_files = len(metadata_path_items) >= 1000
pagination_correct = total_pages == 337

print(f"[{'PASS' if count_matches else 'FAIL'}] get_count() returns 16,811")
print(f"[{'PASS' if available_matches else 'FAIL'}] get_available_count() returns 16,811")
print(f"[{'PASS' if has_metadata_files else 'FAIL'}] Metadata path files included (~1,079)")
print(f"[{'PASS' if pagination_correct else 'FAIL'}] Pagination is 337 pages")
print()

if count_matches and available_matches and has_metadata_files and pagination_correct:
    print("[SUCCESS] Fix verified! Preview will now show all 16,811 items!")
    print()
    print("Preview dialog will display:")
    print(f"  - Header: 'Total: {available_count:,}'")
    print(f"  - All Photos album: {available_count:,} items")
    print(f"  - Pagination: {total_pages} pages (50 items/page)")
    print("  - Includes CPLAssets files from Metadata paths")
else:
    print("[FAILED] Some tests failed")
    if not count_matches:
        print(f"  - get_count() returned {count:,} instead of 16,811")
    if not available_matches:
        print(f"  - get_available_count() returned {available_count:,} instead of 16,811")
    if not has_metadata_files:
        print(f"  - Only {len(metadata_path_items):,} Metadata path files found (expected ~1,079)")
    if not pagination_correct:
        print(f"  - Pagination is {total_pages} pages (expected 337)")

print("=" * 80)
