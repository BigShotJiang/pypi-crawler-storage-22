"""
Test Photos extractor file existence filtering
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from extractors.photos_extractor import PhotosExtractor

backup_path = r"Q:\6697994\iTunes Backup\00008130-001A642E2162001C"

print("=" * 80)
print("Testing Photos Count with File Existence Filtering")
print("=" * 80)
print()

try:
    print("Initializing PhotosExtractor...")
    extractor = PhotosExtractor(backup_path)
    print()

    print("Getting accurate count...")
    count = extractor.get_count()
    print(f"Total photos with existing files: {count:,}")
    print()

    print("=" * 80)
    print(f"Expected: ~16,388 photos")
    print(f"Actual: {count:,} photos")
    print("=" * 80)

except Exception as e:
    print(f"[ERROR] {e}")
    import traceback
    traceback.print_exc()
