"""
Test that preview filtering works correctly when hybrid extraction is disabled.

This simulates what the preview dialog does:
1. Disables hybrid extraction
2. Calls get_items() and get_count()
3. Should only get items with existing files (filtered)
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from extractors.photos_extractor import PhotosExtractor

backup_path = r"Q:\6697994\iTunes Backup\00008130-001A642E2162001C"

print("=" * 80)
print("Testing Preview Filtering (Non-Hybrid Path)")
print("=" * 80)
print()

extractor = PhotosExtractor(backup_path)

# Simulate what the preview does: disable hybrid extraction
print("Step 1: Simulating Preview Behavior")
print("-" * 80)
saved_hybrid = extractor.use_hybrid_extraction
print(f"  Original use_hybrid_extraction: {saved_hybrid}")
extractor.use_hybrid_extraction = False
print(f"  After disabling: {extractor.use_hybrid_extraction}")
print()

# Test with filter_by_existence=True (default, what preview should use)
print("Step 2: Get Count with Filtering (filter_by_existence=True, default)")
print("-" * 80)
count_filtered = extractor.get_count(filter_by_existence=True)
count_default = extractor.get_count()  # Should use default True
print(f"  Count (explicit True): {count_filtered:,}")
print(f"  Count (default):       {count_default:,}")
print(f"  Expected: ~3,240 (Photos.sqlite items with files)")
print()

# Test without filtering
print("Step 3: Get Count without Filtering (filter_by_existence=False)")
print("-" * 80)
count_unfiltered = extractor.get_count(filter_by_existence=False)
print(f"  Count: {count_unfiltered:,}")
print(f"  Expected: ~28,053 (all Photos.sqlite items)")
print()

# Test get_items with filtering
print("Step 4: Get Items with Filtering")
print("-" * 80)
items_filtered = extractor.get_items(limit=10, offset=0, filter_by_existence=True)
items_default = extractor.get_items(limit=10, offset=0)  # Should use default True
print(f"  Items retrieved (explicit True): {len(items_filtered)}")
print(f"  Items retrieved (default):       {len(items_default)}")
print(f"  Sample filenames:")
for i, item in enumerate(items_filtered[:3], 1):
    fn = item.get('filename', 'Unknown')[:40]
    src = item.get('source', 'unknown')
    print(f"    {i}. {fn:40} source={src}")
print()

# Restore hybrid setting
extractor.use_hybrid_extraction = saved_hybrid
print(f"Restored use_hybrid_extraction to: {saved_hybrid}")
print()

# Summary
print("=" * 80)
print("SUMMARY")
print("=" * 80)

# Check if counts are in expected ranges
filtered_ok = 3000 < count_filtered < 4000
unfiltered_ok = 27000 < count_unfiltered < 29000
defaults_ok = count_filtered == count_default and len(items_filtered) == len(items_default)
items_ok = len(items_filtered) == 10 and len(items_default) == 10

print(f"[OK] Filtered count in range (3k-4k):        {filtered_ok} ({count_filtered:,})")
print(f"[OK] Unfiltered count in range (27k-29k):    {unfiltered_ok} ({count_unfiltered:,})")
print(f"[OK] Default parameters work correctly:      {defaults_ok}")
print(f"[OK] Items retrieved correctly:              {items_ok}")
print()

if filtered_ok and unfiltered_ok and defaults_ok and items_ok:
    print("[SUCCESS] Preview filtering works correctly!")
    print()
    print("Preview will now show:")
    print(f"  - Accurate count: ~{count_filtered:,} items (not {count_unfiltered:,})")
    print("  - No broken thumbnails (all items have files)")
    print("  - Correct pagination")
else:
    print("[FAILED] Some tests failed - review results above")

print("=" * 80)
