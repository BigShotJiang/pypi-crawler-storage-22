"""
Test that preview shows all 16,811 items with hybrid extraction enabled.

This simulates the preview behavior after enabling hybrid extraction:
1. Enables hybrid extraction
2. Uses filter_by_existence=True (default)
3. Should get 16,811 items (Photos.sqlite + Manifest-only, filtered)
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from extractors.photos_extractor import PhotosExtractor

backup_path = r"Q:\6697994\iTunes Backup\00008130-001A642E2162001C"

print("=" * 80)
print("Testing Preview Shows All 16,811 Items")
print("=" * 80)
print()

extractor = PhotosExtractor(backup_path)

# Simulate what the preview now does: enable hybrid extraction
print("Step 1: Simulating Preview Behavior (Hybrid Enabled)")
print("-" * 80)
print(f"  Original use_hybrid_extraction: {extractor.use_hybrid_extraction}")
extractor.use_hybrid_extraction = True
print(f"  After enabling: {extractor.use_hybrid_extraction}")
print()

# Test count with filter_by_existence=True (default for preview)
print("Step 2: Get Count (filter_by_existence=True, default)")
print("-" * 80)
count = extractor.get_count()  # Uses default filter_by_existence=True
print(f"  Total count: {count:,}")
print(f"  Expected: 16,811 items")
print()

# Test pagination - get first page
print("Step 3: Get First Page of Items (50 items)")
print("-" * 80)
items = extractor.get_items(limit=50, offset=0)  # Uses default filter_by_existence=True
print(f"  Items retrieved: {len(items)}")
print()

# Breakdown by source
from_database = sum(1 for item in items if item.get('source') == 'database')
from_manifest = sum(1 for item in items if item.get('source') == 'manifest')
print(f"  Breakdown:")
print(f"    From Photos.sqlite: {from_database}")
print(f"    From Manifest only: {from_manifest}")
print()

# Sample items
print(f"  Sample first 5 items:")
for i, item in enumerate(items[:5], 1):
    fn = item.get('filename', 'Unknown')[:35]
    src = item.get('source', 'unknown')
    print(f"    {i}. {fn:35} source={src}")
print()

# Calculate expected pagination
print("Step 4: Calculate Pagination")
print("-" * 80)
items_per_page = 50
total_pages = (count + items_per_page - 1) // items_per_page
print(f"  Total items: {count:,}")
print(f"  Items per page: {items_per_page}")
print(f"  Total pages: {total_pages}")
print()

# Test a page in the middle to verify we get both types
print("Step 5: Get Middle Page (page 100)")
print("-" * 80)
middle_page_items = extractor.get_items(limit=50, offset=100*50)
print(f"  Items retrieved: {len(middle_page_items)}")
middle_from_db = sum(1 for item in middle_page_items if item.get('source') == 'database')
middle_from_manifest = sum(1 for item in middle_page_items if item.get('source') == 'manifest')
print(f"  From Photos.sqlite: {middle_from_db}")
print(f"  From Manifest only: {middle_from_manifest}")
print()

# Summary
print("=" * 80)
print("SUMMARY")
print("=" * 80)

count_ok = count == 16811
items_ok = len(items) == 50
pagination_ok = total_pages == 337  # 16811 / 50 = 337 pages
both_sources = from_database > 0 and from_manifest > 0

print(f"[OK] Count is exactly 16,811:                     {count_ok} ({count:,})")
print(f"[OK] First page has 50 items:                     {items_ok}")
print(f"[OK] Pagination is correct (337 pages):           {pagination_ok} ({total_pages})")
print(f"[OK] Preview shows both source types:             {both_sources}")
print()

if count_ok and items_ok and pagination_ok and both_sources:
    print("[SUCCESS] Preview will show all 16,811 items!")
    print()
    print("Preview dialog will display:")
    print(f"  - Header: 'Total: {count:,}'")
    print(f"  - All Photos album: {count:,} items")
    print(f"  - Pagination: {total_pages} pages")
    print("  - Mix of Photos.sqlite and Manifest-only items")
    print("  - No broken thumbnails (all items have files)")
else:
    print("[FAILED] Some tests failed - review results")

print("=" * 80)
