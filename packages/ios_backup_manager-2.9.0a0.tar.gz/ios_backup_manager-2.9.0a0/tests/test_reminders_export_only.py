"""
Test Reminders export without printing unicode titles
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from extractors.reminders_extractor import RemindersExtractor

backup_path = r"Q:\6697994\iTunes Backup\00008130-001A642E2162001C"
output_dir = r"C:\Users\Ontrack\Desktop\test_reminders_export"

print("=" * 80)
print("Testing Reminders Export")
print("=" * 80)
print()

try:
    extractor = RemindersExtractor(backup_path)
    print(f"Initialized extractor with {len(extractor.db_paths)} database file(s)")

    count = extractor.get_count()
    print(f"Total reminders count: {count}")

    reminders = extractor.get_items()
    print(f"Retrieved {len(reminders)} reminder(s)")
    print()

    if reminders:
        print("Exporting to HTML...")
        success = extractor.export(reminders, output_dir)

        if success:
            html_path = os.path.join(output_dir, 'Reminders.html')
            if os.path.exists(html_path):
                size = os.path.getsize(html_path)
                print(f"[SUCCESS] Export complete!")
                print(f"  File: {html_path}")
                print(f"  Size: {size:,} bytes ({size / 1024:.1f} KB)")
            else:
                print("[ERROR] HTML file not found after export")
        else:
            print("[ERROR] Export failed")
    else:
        print("No reminders to export")

    print()
    print("=" * 80)

except Exception as e:
    print(f"[ERROR] {e}")
    import traceback
    traceback.print_exc()
