"""
Search for SMS attachments by their GUID in the manifest
"""
import sqlite3
import os

backup_path = r"Q:\6697994\iTunes Backup\00008130-001A642E2162001C"
manifest_db = os.path.join(backup_path, "Manifest.db")

# Extract GUIDs from sample attachment paths
test_guids = [
    "486EE520-C418-4FD3-96EF-827E9A3B62C6",  # IMG_1015.jpg
    "1EA50915-0919-4F7D-A08C-349A5A3F4054",  # IMG_7148.jpeg
    "D4D20F51-9408-43A1-A972-9FC85BA33168",  # .HEIC file
    "76B1D720-F8F4-480C-A43A-CD8AF955EF5B",  # IMG_0997.jpeg
]

print("=" * 80)
print("Searching for Files by GUID")
print("=" * 80)
print()

conn = sqlite3.connect(manifest_db)
conn.row_factory = sqlite3.Row
cur = conn.cursor()

for guid in test_guids:
    print(f"GUID: {guid}")
    print("-" * 80)

    # Search for this GUID anywhere in the path
    cur.execute("""
    SELECT fileID, domain, relativePath
    FROM Files
    WHERE relativePath LIKE ?
    LIMIT 10
    """, (f'%{guid}%',))

    results = cur.fetchall()
    if results:
        print(f"  FOUND {len(results)} files:")
        for r in results:
            print(f"    Domain: {r['domain']}")
            path_display = r['relativePath'] if len(r['relativePath']) < 100 else r['relativePath'][:100] + '...'
            print(f"    Path: {path_display}")

            # Check physical existence
            physical_path = os.path.join(backup_path, r['fileID'][:2], r['fileID'])
            if os.path.exists(physical_path):
                size = os.path.getsize(physical_path)
                print(f"    EXISTS: {size:,} bytes")
            else:
                print(f"    MISSING")
            print()
    else:
        print(f"  NOT FOUND")
    print()

conn.close()

print("=" * 80)
