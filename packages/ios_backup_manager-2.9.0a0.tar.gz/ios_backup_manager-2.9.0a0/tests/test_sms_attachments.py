"""
Test SMS attachment file lookup in backup manifest
"""
import sqlite3
import hashlib
import os

backup_path = r"Q:\6697994\iTunes Backup\00008130-001A642E2162001C"

# Connect to SMS database
sms_db = None
for subdir in ['3d', '']:
    potential_path = os.path.join(backup_path, subdir, '3d0d7e5fb2ce288813306e4d4636395e047a3d28')
    if os.path.exists(potential_path):
        sms_db = potential_path
        break

if not sms_db:
    print("ERROR: SMS database not found")
    exit(1)

print("=" * 80)
print("SMS Attachment Investigation")
print("=" * 80)
print()

# Get sample attachments for Julie conversation (chat 1823)
conn_sms = sqlite3.connect(sms_db)
conn_sms.row_factory = sqlite3.Row
cur_sms = conn_sms.cursor()

print("Sample attachments from Julie conversation:")
print("-" * 80)

cur_sms.execute("""
SELECT a.ROWID, a.filename, a.mime_type, a.total_bytes
FROM attachment a
JOIN message_attachment_join maj ON a.ROWID = maj.attachment_id
JOIN chat_message_join cmj ON maj.message_id = cmj.message_id
WHERE cmj.chat_id = 1823
LIMIT 10
""")

attachments = cur_sms.fetchall()
for att in attachments:
    print(f"Attachment {att['ROWID']}:")
    print(f"  Filename: {att['filename']}")
    print(f"  MIME: {att['mime_type']}")
    print(f"  Size: {att['total_bytes']} bytes")
    print()

conn_sms.close()

# Now check manifest for these files
print()
print("=" * 80)
print("Checking Manifest.db")
print("=" * 80)
print()

manifest_db = os.path.join(backup_path, "Manifest.db")
if not os.path.exists(manifest_db):
    print("ERROR: Manifest.db not found")
    exit(1)

conn_manifest = sqlite3.connect(manifest_db)
conn_manifest.row_factory = sqlite3.Row
cur_manifest = conn_manifest.cursor()

# Check first attachment
if attachments:
    first_att = attachments[0]
    filename = first_att['filename']

    print(f"Looking for: {filename}")
    print()

    # Try MediaDomain lookup (what the code currently does)
    if filename.startswith('~/'):
        relative_path = filename[2:]
    else:
        relative_path = filename

    cache_key = f"MediaDomain-{relative_path}"
    file_id = hashlib.sha1(cache_key.encode()).hexdigest()

    print(f"MediaDomain lookup:")
    print(f"  Cache key: {cache_key}")
    print(f"  File ID: {file_id}")

    cur_manifest.execute("SELECT fileID, domain, relativePath FROM Files WHERE fileID = ?", (file_id,))
    row = cur_manifest.fetchone()
    if row:
        print(f"  FOUND in manifest!")
        print(f"    Domain: {row['domain']}")
        print(f"    Path: {row['relativePath']}")
    else:
        print(f"  NOT FOUND in manifest")
    print()

    # Try to find it by searching for the filename
    print(f"Searching manifest for files containing this path:")
    cur_manifest.execute("""
    SELECT fileID, domain, relativePath
    FROM Files
    WHERE relativePath LIKE ?
    LIMIT 5
    """, (f'%{os.path.basename(relative_path)}%',))

    matches = cur_manifest.fetchall()
    if matches:
        print(f"  Found {len(matches)} potential matches:")
        for match in matches:
            print(f"    Domain: {match['domain']}")
            print(f"    Path: {match['relativePath']}")
            print(f"    FileID: {match['fileID']}")
            print()
    else:
        print(f"  No matches found")

    # Try searching for any SMS attachment-like files
    print()
    print("Searching for SMS/MMS attachments in manifest:")
    cur_manifest.execute("""
    SELECT fileID, domain, relativePath
    FROM Files
    WHERE relativePath LIKE '%/SMS/Attachments/%'
       OR relativePath LIKE '%/Attachments/%'
       OR domain LIKE '%Media%'
    LIMIT 10
    """)

    sms_files = cur_manifest.fetchall()
    if sms_files:
        print(f"  Found {len(sms_files)} SMS/media files:")
        for f in sms_files:
            print(f"    {f['domain']} - {f['relativePath']}")
    else:
        print(f"  No SMS attachment files found")

conn_manifest.close()

print()
print("=" * 80)
