#!/usr/bin/env python3
"""
Test script for SMS HTML export functionality.

Tests that the HTML export works correctly with real backup data.
"""

import os
import sys
from extractors.sms_extractor import SMSExtractor

def test_sms_export():
    """Test SMS export with real backup data."""

    # Use the backup path from the working directory
    backup_path = r"C:\Backups\iTunes\b866887c5a84768aef9a10b01c9a3296c9981b4d"

    if not os.path.exists(backup_path):
        print(f"ERROR: Backup not found at {backup_path}")
        return False

    print(f"Testing SMS export with backup: {backup_path}")
    print("-" * 60)

    try:
        # Create extractor
        print("Creating SMS extractor...")
        extractor = SMSExtractor(backup_path)

        # Get conversations
        print("Loading conversations...")
        conversations = extractor.get_conversations(limit=5)

        if not conversations:
            print("ERROR: No conversations found in backup")
            return False

        print(f"Found {len(conversations)} conversations")

        # Export first conversation
        conv = conversations[0]
        print(f"\nExporting conversation: {conv['display_name']}")
        print(f"  Chat ID: {conv['chat_id']}")
        print(f"  Message count: {conv['message_count']}")

        # Create output directory
        output_dir = r"O:\Personal\Martin\JIT\iOSBackupMerger\test_output"
        os.makedirs(output_dir, exist_ok=True)

        # Export to HTML
        output_file = os.path.join(output_dir, "test_conversation.html")
        print(f"\nExporting to: {output_file}")

        success = extractor.export_conversation_html(
            conv['chat_id'],
            output_file,
            conv['display_name']
        )

        if not success:
            print("ERROR: Export failed")
            return False

        # Verify output
        if not os.path.exists(output_file):
            print("ERROR: HTML file was not created")
            return False

        # Check file size
        file_size = os.path.getsize(output_file)
        print(f"\nSUCCESS! HTML file created: {file_size} bytes")

        # Check for attachments directory
        attachments_dir = os.path.join(output_dir, "Message Attachments")
        if os.path.exists(attachments_dir):
            attachment_files = os.listdir(attachments_dir)
            print(f"Attachments directory created with {len(attachment_files)} files")
        else:
            print("No attachments directory (conversation may have no attachments)")

        # Read and display first 500 characters of HTML
        with open(output_file, 'r', encoding='utf-8') as f:
            html_preview = f.read(500)

        print("\nHTML Preview (first 500 chars):")
        print("-" * 60)
        print(html_preview)
        print("-" * 60)

        print(f"\n✓ Test PASSED - Open in browser: {output_file}")
        return True

    except Exception as e:
        print(f"ERROR: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_sms_export()
    sys.exit(0 if success else 1)
