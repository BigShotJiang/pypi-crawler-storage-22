"""
Test SMS extractor with recoverable messages
"""
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from extractors.sms_extractor import SMSExtractor

# Test backup path
backup_path = r"Q:\6695545\iTunes Backup\00008020-0019145E0102002E"

print("=" * 80)
print("SMS Extractor Test - Recoverable Messages")
print("=" * 80)
print()
print(f"Backup: {backup_path}")
print()

try:
    # Initialize extractor
    print("Initializing SMS extractor...")
    extractor = SMSExtractor(backup_path)

    # Get conversation count
    count = extractor.get_conversation_count()
    print(f"Total conversations (including recoverable): {count}")
    print()

    # Get all conversations
    print("Fetching conversations...")
    conversations = extractor.get_conversations()
    print(f"Retrieved {len(conversations)} conversations")
    print()

    # Get conversation IDs
    chat_ids = extractor.get_conversation_ids()
    print(f"Total conversation IDs: {len(chat_ids)}")
    print()

    # Show sample conversations
    print("Sample conversations:")
    for i, conv in enumerate(conversations[:5], 1):
        print(f"  {i}. {conv['display_name']}")
        print(f"     Messages: {conv['message_count']}")
        last_msg = conv['last_message'] or '(no text)'
        if len(last_msg) > 50:
            last_msg = last_msg[:50] + '...'
        print(f"     Last: {last_msg}")
        print()

    # Expected results
    print("=" * 80)
    print("Expected Results:")
    print("  - Previous conversation count: 16")
    print("  - Total with recoverable: 102")
    print("  - Reincubate extraction: 103")
    print()
    print("Actual Results:")
    print(f"  - Total conversations: {count}")
    print(f"  - Retrieved conversations: {len(conversations)}")
    print(f"  - Conversation IDs: {len(chat_ids)}")
    print()

    if count >= 102:
        print("SUCCESS: Recoverable messages are now included!")
        print(f"Difference from Reincubate: {103 - count} (likely spam/system messages)")
    elif count > 16:
        print("PARTIAL SUCCESS: More conversations found, but count may not match expected")
    else:
        print("FAILED: Conversation count did not increase")

    print()
    print("=" * 80)

except Exception as e:
    print(f"ERROR: {e}")
    import traceback
    traceback.print_exc()
