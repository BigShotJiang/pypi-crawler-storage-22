#!/usr/bin/env python3
"""
Diagnostic script to test SMS search index generation.
Tests why the search index might be empty.
"""

import sys
import os
import io

# Set UTF-8 encoding for stdout
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

# Add parent directory to path
sys.path.insert(0, os.path.dirname(__file__))

from extractors.sms_extractor import SMSExtractor

def test_search_index(backup_path):
    """Test search index generation for SMS."""
    print(f"Testing SMS search index for: {backup_path}\n")

    try:
        # Initialize extractor
        print("Initializing SMS extractor...")
        extractor = SMSExtractor(backup_path)
        print("✓ SMS extractor initialized\n")

        # Get conversations
        print("Getting conversations...")
        conversations = extractor.get_items(limit=5, offset=0)  # Test with first 5
        print(f"✓ Found {len(conversations)} conversations (testing first 5)\n")

        if not conversations:
            print("ERROR: No conversations found!")
            return

        # Test search index generation for each conversation
        success_count = 0
        fail_count = 0

        for i, conv in enumerate(conversations):
            print(f"Testing conversation {i+1}: {conv['display_name']}")
            print(f"  Chat ID: {conv.get('chat_id', 'MISSING!')}")
            print(f"  Safe name: {conv.get('safe_name', 'MISSING!')}")

            try:
                # Try to get messages
                messages = extractor.get_messages(conv['chat_id'], limit=None, offset=0)
                print(f"  ✓ Got {len(messages)} messages")

                # Count messages with text
                text_count = sum(1 for msg in messages if msg.get('text'))
                print(f"  ✓ {text_count} messages have text content")

                # Concatenate text (same as search index does)
                message_text_parts = []
                for msg in messages:
                    if msg.get('text'):
                        text = msg['text'].replace('<br>', ' ')
                        message_text_parts.append(text)

                all_message_text = ' '.join(message_text_parts)
                print(f"  ✓ Total search text length: {len(all_message_text)} characters")

                if len(all_message_text) > 0:
                    # Show first 100 chars as sample
                    sample = all_message_text[:100] + "..." if len(all_message_text) > 100 else all_message_text
                    print(f"  Sample text: {sample}")

                success_count += 1
                print(f"  ✓ SUCCESS\n")

            except Exception as e:
                fail_count += 1
                print(f"  ✗ FAILED: {e}")
                import traceback
                traceback.print_exc()
                print()

        print(f"\n{'='*60}")
        print(f"SUMMARY: {success_count} succeeded, {fail_count} failed")
        print(f"{'='*60}")

        if success_count > 0:
            print("\n✓ Search index generation should work!")
            print("  The search index in your Messages.html might be from an old extraction.")
            print("  Try re-exporting SMS to regenerate it.")
        else:
            print("\n✗ Search index generation is failing!")
            print("  Check the error messages above for details.")

    except Exception as e:
        print(f"ERROR: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python test_sms_search_index.py <backup_path>")
        print("\nExample:")
        print("  python test_sms_search_index.py \"Q:\\testdata\\testphone12\"")
        sys.exit(1)

    backup_path = sys.argv[1]
    test_search_index(backup_path)
