#!/usr/bin/env python3
"""Test decoding voicemail transcript files."""

import sys
import os
import plistlib
sys.path.insert(0, '.')
from extractors.voicemail_extractor import VoicemailExtractor

def decode_transcript(transcript_path):
    """
    Decode a voicemail transcript file.

    Returns the transcript text or None if decoding fails.
    """
    try:
        with open(transcript_path, 'rb') as f:
            data = f.read()

        # Parse as NSKeyedArchiver plist
        plist_data = plistlib.loads(data)
        objects = plist_data.get('$objects', [])

        # The transcript text is usually one of the longer strings
        # in the $objects array
        # Search for strings longer than 50 characters
        candidates = []
        for obj in objects:
            if isinstance(obj, str) and len(obj) > 50:
                candidates.append(obj)

        # Return the longest string, which is likely the transcript
        if candidates:
            return max(candidates, key=len)

        return None

    except Exception as e:
        print(f"Error decoding transcript: {e}")
        return None


def test_transcript_decode():
    """Test decoding voicemail transcripts."""
    backup_path = r"Q:\6692745\iTunes Backup\00008030-001E215E02B9402E"

    print(f"{'='*70}")
    print(f"Testing Voicemail Transcript Decoding")
    print('='*70)

    try:
        # Initialize extractor
        extractor = VoicemailExtractor(backup_path)

        # Get first 5 voicemails with transcripts
        voicemails = extractor.get_items(limit=20)

        count = 0
        for vm in voicemails:
            if vm['has_transcript'] and count < 5:
                count += 1
                print(f"\n{'='*70}")
                print(f"Voicemail #{count} from: {vm['sender']}")
                print(f"Date: {extractor._format_timestamp(vm['date'])}")

                # Get transcript file path
                transcript_path = extractor._get_transcript_file_path(vm['rowid'])

                if transcript_path and os.path.exists(transcript_path):
                    transcript_text = decode_transcript(transcript_path)

                    if transcript_text:
                        print(f"\nTranscript ({len(transcript_text)} chars):")
                        print(f"{transcript_text}")
                    else:
                        print("\nCould not decode transcript")

        return True

    except Exception as e:
        print(f"[ERROR] {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = test_transcript_decode()
    sys.exit(0 if success else 1)
