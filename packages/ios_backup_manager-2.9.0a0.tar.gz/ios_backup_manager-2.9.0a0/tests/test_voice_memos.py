#!/usr/bin/env python3
"""
Test Voice Memos extraction from iOS backup.
"""

import sys
import os
sys.path.insert(0, '.')

from extractors.voice_memos_extractor import VoiceMemosExtractor

def test_voice_memos_extraction():
    """Test voice memos extraction on newer iOS backup (iOS 13+)."""

    # This backup has 17 voice memos and uses newer iOS database location
    backup_path = r"Q:\6695545\iTunes Backup\00008020-0019145E0102002E"

    print("="*80)
    print("Voice Memos Extraction Test - Newer iOS Database Location")
    print("="*80)
    print(f"\nBackup: {backup_path}")
    print("Expected: 17 voice memos in newer iOS location\n")

    try:
        # Initialize extractor
        print("1. Initializing VoiceMemosExtractor...")
        extractor = VoiceMemosExtractor(backup_path)
        print(f"   [OK] VoiceMemosExtractor initialized")
        print(f"   Database found: {extractor.recordings_db_path}")
        print(f"   Domain: {extractor.voice_memos_domain}")
        print(f"   Base path: {extractor.voice_memos_base_path}")
        print(f"   Available columns: {sorted(extractor._available_columns)}")

        # Get count
        print("\n2. Getting voice memos count...")
        count = extractor.get_count()
        print(f"   [OK] Total voice memos: {count}")

        if count == 0:
            print("\n   [INFO] No voice memos found in this backup")
            print("   This is normal - not all backups contain voice memos")
            return True

        # Get items
        print("\n3. Retrieving voice memos...")
        items = extractor.get_items(limit=None, offset=0)
        print(f"   [OK] Retrieved {len(items)} voice memos")

        # Display details for each memo
        print("\n4. Voice Memos Details:")
        print("-" * 80)
        for i, memo in enumerate(items, 1):
            print(f"\n   Recording {i}:")
            print(f"      ID: {memo['z_pk']}")
            print(f"      Date: {extractor._format_timestamp(memo['date'])}")
            print(f"      Duration: {extractor._format_duration(memo['duration'])}")
            print(f"      Filename: {memo['filename']}")

            if memo['custom_label']:
                print(f"      Custom Label: {memo['custom_label']}")

            print(f"      Path: {memo['path']}")
            print(f"      Has Audio: {'Yes' if memo['has_audio'] else 'No'}")

            if memo['encrypted']:
                print(f"      Encrypted: Yes")

        # Test export
        if count > 0:
            print("\n5. Testing export...")
            output_dir = r"O:\Personal\Martin\JIT\iOSBackupMerger\test_output\voice_memos_test"

            # Create clean output directory
            if os.path.exists(output_dir):
                import shutil
                shutil.rmtree(output_dir)

            os.makedirs(output_dir, exist_ok=True)

            # Export all voice memos
            success = extractor.export(items, output_dir, format='audio')

            if success:
                print(f"   [OK] Export successful to: {output_dir}")

                # List exported files
                if os.path.exists(output_dir):
                    print(f"\n   Exported files:")
                    audio_dir = os.path.join(output_dir, 'audio')
                    if os.path.exists(audio_dir):
                        audio_files = os.listdir(audio_dir)
                        for f in audio_files:
                            file_path = os.path.join(audio_dir, f)
                            size = os.path.getsize(file_path)
                            print(f"      - {f} ({size:,} bytes)")

                    # Check for reports
                    csv_file = os.path.join(output_dir, 'voice_memos_report.csv')
                    html_file = os.path.join(output_dir, 'voice_memos_report.html')

                    if os.path.exists(csv_file):
                        print(f"      - voice_memos_report.csv")
                    if os.path.exists(html_file):
                        print(f"      - voice_memos_report.html")
            else:
                print(f"   [FAIL] Export failed")
                return False

        print("\n" + "="*80)
        print("TEST COMPLETED SUCCESSFULLY")
        print("="*80)

        return True

    except FileNotFoundError as e:
        print(f"\n[INFO] {e}")
        print("\nThis backup does not contain voice memos.")
        print("This is normal - voice memos are optional data.")
        return True
    except Exception as e:
        print(f"\n[FAIL] Error during test: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_voice_memos_extraction()
    sys.exit(0 if success else 1)
