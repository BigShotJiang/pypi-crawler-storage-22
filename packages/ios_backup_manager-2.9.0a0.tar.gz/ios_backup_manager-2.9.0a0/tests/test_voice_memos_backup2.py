#!/usr/bin/env python3
"""Diagnose voice memos issue for backup Q:\6697994\iTunes Backup\00008130-001A642E2162001C"""

import sqlite3
import os

BACKUP_PATH = r"Q:\6697994\iTunes Backup\00008130-001A642E2162001C"

def main():
    print("="*80)
    print("Voice Memos Diagnostic for backup:")
    print(BACKUP_PATH)
    print("="*80)
    print()

    # Check Manifest.db for voice memos related files
    manifest_path = os.path.join(BACKUP_PATH, 'Manifest.db')
    if not os.path.exists(manifest_path):
        print("ERROR: Manifest.db not found!")
        return

    conn = sqlite3.connect(manifest_path)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    # Search for voice memos databases
    print("1. Searching for voice memos databases...")
    cur.execute("""
        SELECT domain, relativePath, fileID
        FROM Files
        WHERE (relativePath LIKE '%Recording%' AND relativePath LIKE '%.db')
           OR (domain LIKE '%VoiceMemos%' AND relativePath LIKE '%.db')
        ORDER BY domain, relativePath
    """)

    databases = cur.fetchall()
    if databases:
        print(f"   Found {len(databases)} database(s):")
        for db in databases:
            print(f"   - {db['domain']} -> {db['relativePath']}")
    else:
        print("   No voice memos databases found")
    print()

    # Search for .m4a files in voice memos domains
    print("2. Searching for .m4a audio files in voice memos domains...")
    cur.execute("""
        SELECT domain, relativePath, fileID
        FROM Files
        WHERE (relativePath LIKE '%.m4a' OR relativePath LIKE '%.m4v')
          AND (domain LIKE '%VoiceMemos%' OR domain = 'MediaDomain')
        ORDER BY domain, relativePath
    """)

    audio_files = cur.fetchall()
    if audio_files:
        print(f"   Found {len(audio_files)} audio file(s):")
        # Group by domain
        by_domain = {}
        for f in audio_files:
            domain = f['domain']
            if domain not in by_domain:
                by_domain[domain] = []
            by_domain[domain].append(f['relativePath'])

        for domain, files in by_domain.items():
            print(f"\n   {domain}:")
            for path in files[:10]:  # Show first 10
                print(f"      - {path}")
            if len(files) > 10:
                print(f"      ... and {len(files) - 10} more")
    else:
        print("   No .m4a/.m4v files found in voice memos domains")
    print()

    # Try to test our extractor
    print("3. Testing VoiceMemosExtractor...")
    try:
        from extractors.voice_memos_extractor import VoiceMemosExtractor

        extractor = VoiceMemosExtractor(BACKUP_PATH)
        print(f"   [OK] Extractor initialized")
        print(f"   Database: {extractor.recordings_db_path}")
        print(f"   Domain: {extractor.voice_memos_domain}")
        print(f"   Base path: {extractor.voice_memos_base_path}")
        print(f"   Table: {extractor.table_name}")

        count = extractor.get_count()
        print(f"   Count: {count}")

        if count == 0:
            print("\n   [WARNING] Extractor returns 0 voice memos!")
            print("   Let's check the database directly...")

            db_conn = sqlite3.connect(extractor.recordings_db_path)
            db_cur = db_conn.cursor()

            # Check both tables
            for table in ['ZRECORDING', 'ZCLOUDRECORDING']:
                db_cur.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{table}'")
                if db_cur.fetchone():
                    db_cur.execute(f"SELECT COUNT(*) FROM {table}")
                    table_count = db_cur.fetchone()[0]
                    print(f"      {table}: {table_count} records")

                    if table_count > 0:
                        db_cur.execute(f"PRAGMA table_info({table})")
                        columns = [row[1] for row in db_cur.fetchall()]
                        print(f"         Columns: {', '.join(columns[:10])}")

                        # Check for ZPATH
                        if 'ZPATH' in columns:
                            db_cur.execute(f"SELECT COUNT(*) FROM {table} WHERE ZPATH IS NOT NULL AND ZPATH != ''")
                            with_path = db_cur.fetchone()[0]
                            print(f"         Records with ZPATH: {with_path}")

            db_conn.close()

    except FileNotFoundError as e:
        print(f"   [ERROR] {e}")
    except Exception as e:
        print(f"   [ERROR] Error: {e}")
        import traceback
        traceback.print_exc()

    conn.close()

if __name__ == '__main__':
    main()
