#!/usr/bin/env python3
"""Test voicemail extractor."""

import sys
import os
sys.path.insert(0, '.')
from extractors.voicemail_extractor import VoicemailExtractor

def test_voicemail():
    """Test voicemail extraction."""
    # Use backup with voicemail data
    backup_path = r"Q:\6692745\iTunes Backup\00008030-001E215E02B9402E"
    output_dir = r"O:\Personal\Martin\JIT\iOSBackupMerger\test_output\voicemail_test"

    print(f"{'='*70}")
    print(f"Testing Voicemail Extractor")
    print('='*70)

    try:
        # Initialize extractor
        extractor = VoicemailExtractor(backup_path)
        count = extractor.get_count()
        print(f"\nTotal voicemails: {count}")

        # Get first 5 voicemails for testing
        voicemails = extractor.get_items(limit=5)
        print(f"\nSample voicemails:")
        for i, vm in enumerate(voicemails, 1):
            print(f"\n  {i}. From: {vm['sender']}")
            print(f"     Date: {extractor._format_timestamp(vm['date'])}")
            print(f"     Duration: {extractor._format_duration(vm['duration'])}")
            print(f"     Has Audio: {vm['has_audio']}")
            print(f"     Has Transcript: {vm['has_transcript']}")
            if vm['transcript_text']:
                preview = vm['transcript_text'][:100]
                if len(vm['transcript_text']) > 100:
                    preview += "..."
                print(f"     Transcript: {preview}")

        # Test export
        print(f"\n{'='*70}")
        print(f"Testing Export")
        print('='*70)

        def progress_callback(current, total, item_name):
            """Simple progress callback."""
            print(f"  [{current}/{total}] {item_name}")
            return True

        success = extractor.export(voicemails, output_dir, progress_callback=progress_callback)

        if success:
            print(f"\n[SUCCESS] Export completed!")
            print(f"\nExport directory: {output_dir}")

            # Check what was created
            if os.path.exists(output_dir):
                print(f"\nContents:")
                for root, dirs, files in os.walk(output_dir):
                    level = root.replace(output_dir, '').count(os.sep)
                    indent = ' ' * 2 * level
                    print(f"{indent}{os.path.basename(root)}/")
                    subindent = ' ' * 2 * (level + 1)
                    for file in files:
                        file_path = os.path.join(root, file)
                        size = os.path.getsize(file_path)
                        print(f"{subindent}{file} ({size:,} bytes)")

            return True
        else:
            print(f"\n[FAILED] Export failed")
            return False

    except FileNotFoundError as e:
        print(f"[ERROR] {e}")
        return False
    except Exception as e:
        print(f"[ERROR] {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = test_voicemail()
    sys.exit(0 if success else 1)
