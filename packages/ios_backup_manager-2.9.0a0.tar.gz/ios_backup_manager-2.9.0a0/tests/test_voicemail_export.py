#!/usr/bin/env python3
"""Test voicemail export with AMR to MP3 conversion support."""

import sys
import os
sys.path.insert(0, '.')

from extractors.voicemail_extractor import VoicemailExtractor

def test_voicemail_export():
    """Test voicemail export."""

    backup_path = r"Q:\6685679\iTunes Backup\95c5156d9e88e4a770fe910f3efdd746c227dbd9"
    output_path = r"Q:\testdata\sampleoutput\Voicemail_Test"

    print(f"{'='*70}")
    print("Testing Voicemail Export with Audio Conversion")
    print(f"{'='*70}")

    try:
        # Create extractor
        print(f"\n1. Creating voicemail extractor...")
        extractor = VoicemailExtractor(backup_path)

        # Get count
        total_count = extractor.get_count()
        print(f"   Total voicemails: {total_count}")

        # Get a few voicemails for testing
        print(f"\n2. Loading first 3 voicemails...")
        voicemails = extractor.get_items(limit=3)
        print(f"   Loaded {len(voicemails)} voicemails")

        # Show what we're exporting
        print(f"\n3. Voicemails to export:")
        for i, vm in enumerate(voicemails, 1):
            print(f"   {i}. {vm['sender']} - {extractor._format_duration(vm['duration'])}")
            print(f"      Audio: {'Yes' if vm['has_audio'] else 'No'}")
            print(f"      Transcript: {'Yes' if vm['has_transcript'] else 'No'}")

        # Export
        print(f"\n4. Exporting to: {output_path}")
        print(f"   Note: This will check for FFmpeg and show conversion status")
        print()
        success = extractor.export(voicemails, output_path)

        if not success:
            print("\n[FAILED] Export failed")
            return False

        # Check output
        print(f"\n5. Verifying export...")
        html_file = os.path.join(output_path, 'voicemail_report.html')
        audio_dir = os.path.join(output_path, 'audio')

        if os.path.exists(html_file):
            size = os.path.getsize(html_file)
            print(f"   [OK] voicemail_report.html ({size:,} bytes)")
        else:
            print(f"   [FAIL] voicemail_report.html not found")

        mp3_files = []
        if os.path.exists(audio_dir):
            audio_files = os.listdir(audio_dir)
            mp3_files = [f for f in audio_files if f.endswith('.mp3')]
            amr_files = [f for f in audio_files if f.endswith('.amr')]

            print(f"   [OK] audio/ directory")
            print(f"        - AMR files: {len(amr_files)}")
            print(f"        - MP3 files: {len(mp3_files)}")

            if mp3_files:
                print(f"   [SUCCESS] FFmpeg conversion worked! MP3 files created.")
            else:
                print(f"   [INFO] No MP3 files (FFmpeg not available)")
        else:
            print(f"   [FAIL] audio/ directory not found")

        print(f"\n{'='*70}")
        print("[SUCCESS] Export complete!")
        print(f"{'='*70}")
        print(f"\nOpen in browser: {html_file}")

        if not mp3_files:
            print(f"\nTo enable browser-playable audio:")
            print(f"1. Install FFmpeg: https://ffmpeg.org/download.html")
            print(f"2. Re-run the export")

        return True

    except Exception as e:
        print(f"\n[ERROR] {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_voicemail_export()
    sys.exit(0 if success else 1)
