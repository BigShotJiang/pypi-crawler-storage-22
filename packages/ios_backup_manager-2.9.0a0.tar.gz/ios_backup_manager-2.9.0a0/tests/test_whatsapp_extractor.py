#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test WhatsApp extractor.
"""

import sys
import os
import io

# Fix Windows console encoding
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

# Add parent directory to path
sys.path.insert(0, os.path.dirname(__file__))

from extractors.whatsapp_extractor import WhatsAppExtractor

backup_path = r"Q:\6692745\iTunes Backup\00008030-001E215E02B9402E"

print("=== Testing WhatsApp Extractor ===\n")

try:
    # Initialize extractor
    print("1. Initializing WhatsApp extractor...")
    extractor = WhatsAppExtractor(backup_path)
    print("   ✓ Extractor initialized successfully")

    # Get conversation count
    print("\n2. Getting conversation count...")
    count = extractor.get_count()
    print(f"   ✓ Found {count} conversations")

    # Get conversations
    print("\n3. Getting first 5 conversations...")
    conversations = extractor.get_conversations(limit=5)
    print(f"   ✓ Retrieved {len(conversations)} conversations")

    for i, conv in enumerate(conversations, 1):
        print(f"\n   Conversation {i}:")
        print(f"     Name: {conv['display_name']}")
        print(f"     Messages: {conv['message_count']}")
        print(f"     Group: {conv['is_group']}")
        print(f"     Preview: {conv['last_message'][:50]}...")

    # Get messages from first conversation
    if conversations:
        print(f"\n4. Getting messages from first conversation...")
        chat_id = conversations[0]['chat_id']
        messages = extractor.get_messages(chat_id, limit=3)
        print(f"   ✓ Retrieved {len(messages)} messages")

        for i, msg in enumerate(messages, 1):
            print(f"\n   Message {i}:")
            print(f"     From me: {msg['is_from_me']}")
            print(f"     Text: {msg['text'][:50] if msg['text'] else '(No text)'}...")
            if msg['media_item']:
                print(f"     Media: {msg['media_item']['mime_type']}")

    print("\n\n=== WhatsApp Extractor Test Complete ===")
    print("✓ All tests passed!")

except Exception as e:
    print(f"\n✗ Error: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
