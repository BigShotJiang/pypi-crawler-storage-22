"""
Test WhatsApp HTML report generation with hidden badge
"""
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from extractors.whatsapp_extractor import WhatsAppExtractor

# Test backup path
backup_path = r"Q:\6695545\iTunes Backup\00008020-0019145E0102002E"
output_dir = r"C:\Users\Ontrack\Desktop\whatsapp_test_export"

print("=" * 80)
print("WhatsApp HTML Export Test (with Hidden Badge)")
print("=" * 80)
print()
print(f"Backup: {backup_path}")
print(f"Output: {output_dir}")
print()

try:
    # Clean output directory if it exists
    if os.path.exists(output_dir):
        import shutil
        print(f"Cleaning existing output directory...")
        shutil.rmtree(output_dir)

    # Initialize extractor
    print("Initializing WhatsApp extractor...")
    extractor = WhatsAppExtractor(backup_path)

    # Get conversations
    print("Fetching conversations...")
    conversations = extractor.get_conversations()  # Get all conversations
    print(f"Retrieved {len(conversations)} conversations for test")
    print()

    # Show which conversations we're exporting
    hidden_count = sum(1 for c in conversations if c.get('is_hidden', False))
    print(f"Export will include {hidden_count} hidden conversations")
    print()

    # Export with HTML report
    print("Exporting conversations with HTML report...")
    success = extractor.export(
        items=conversations,
        output_path=output_dir,
        format='html',
        progress_callback=lambda current, total, msg: print(f"[{current}/{total}] {msg}")
    )

    if success:
        print()
        print("=" * 80)
        print("SUCCESS!")
        print("=" * 80)
        print()
        print(f"HTML Report: {os.path.join(output_dir, 'WhatsApp.html')}")
        print()
        print("To verify the hidden badge:")
        print("  1. Open WhatsApp.html in your browser")
        print("  2. Look for conversations with 'HIDDEN' badge (gray badge)")
        print("  3. Should see 4 hidden conversations labeled with the badge")
        print()

        # Check if HTML file was created
        html_path = os.path.join(output_dir, "WhatsApp.html")
        if os.path.exists(html_path):
            # Read and check if hidden badge is in HTML
            with open(html_path, 'r', encoding='utf-8') as f:
                html_content = f.read()
                if 'hidden-badge' in html_content:
                    badge_count = html_content.count('hidden-badge')
                    print(f"Verification: Found {badge_count} hidden badges in HTML")
                else:
                    print("WARNING: No hidden badges found in HTML!")
    else:
        print("FAILED: Export returned False")

except Exception as e:
    print(f"ERROR: {e}")
    import traceback
    traceback.print_exc()
