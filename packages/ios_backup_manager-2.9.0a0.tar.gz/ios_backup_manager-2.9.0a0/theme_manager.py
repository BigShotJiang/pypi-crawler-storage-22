#!/usr/bin/env python3
"""
theme_manager.py

Cross-platform theme manager for iOS Backup Manager.
Provides UNIFORM appearance across all platforms (Windows, macOS, Linux).
Ignores system appearance settings to maintain consistent look.
"""

import sys
import tkinter as tk
from tkinter import ttk


class ThemeManager:
    """
    Manages application theming with uniform appearance across all platforms.
    Forces consistent colors and style, ignoring OS theme preferences.
    """

    def __init__(self, root=None):
        self.root = root
        self.is_windows = sys.platform == "win32"

        # Windows: Use original colors (no theming needed)
        # macOS/Linux: Use uniform scheme to prevent system appearance interference
        if self.is_windows:
            self.colors = self._get_windows_original_scheme()
        else:
            self.colors = self._get_macos_linux_scheme()

        # Configure ttk styles for all platforms to ensure consistent widget appearance
        if root:
            if self.is_windows:
                self._configure_ttk_styles_windows()
            else:
                self._configure_ttk_styles()
                self._configure_root_window()

    def _configure_ttk_styles_windows(self):
        """Configure ttk widget styles for Windows to ensure modern, consistent appearance"""
        if not self.root:
            return

        try:
            style = ttk.Style(self.root)

            # Use 'vista' theme on Windows for modern scrollbars and widgets
            # Falls back to 'winnative' or 'default' if vista isn't available
            try:
                style.theme_use('vista')
            except:
                try:
                    style.theme_use('winnative')
                except:
                    try:
                        style.theme_use('xpnative')
                    except:
                        pass  # Use whatever default is available

            # Note: We don't override colors on Windows, just ensure modern widget styling
            # This gives us modern scrollbars with draggable thumb and hover arrows

        except Exception as e:
            print(f"[ThemeManager] Could not configure Windows ttk styles: {e}")

    def _configure_root_window(self):
        """Configure root window to prevent system theme inheritance"""
        if not self.root:
            return

        try:
            # Set explicit background color
            self.root.configure(bg=self.colors['bg_secondary'])

            # macOS-specific: Try to disable system appearance
            if sys.platform == "darwin":
                try:
                    # Attempt to set appearance to light mode explicitly
                    # This may require additional macOS-specific configuration
                    pass
                except:
                    pass
        except Exception as e:
            print(f"[ThemeManager] Could not configure root window: {e}")

    def _configure_ttk_styles(self):
        """Configure ttk widget styles to use our colors"""
        if not self.root:
            return

        try:
            style = ttk.Style(self.root)

            # Force a base theme that doesn't inherit system appearance
            # Try 'clam' theme which is more customizable
            try:
                style.theme_use('clam')
            except:
                # If clam isn't available, try default
                try:
                    style.theme_use('default')
                except:
                    pass

            # Configure Frame backgrounds
            style.configure('TFrame', background=self.colors['bg_primary'])

            # Configure Label styles
            style.configure('TLabel',
                          background=self.colors['bg_primary'],
                          foreground=self.colors['text_primary'])

            # Configure Button styles
            style.configure('TButton',
                          background=self.colors['button_primary_bg'],
                          foreground=self.colors['button_primary_fg'])

            # Configure LabelFrame styles
            style.configure('TLabelframe',
                          background=self.colors['bg_primary'],
                          foreground=self.colors['text_primary'])
            style.configure('TLabelframe.Label',
                          background=self.colors['bg_primary'],
                          foreground=self.colors['text_primary'])

        except Exception as e:
            print(f"[ThemeManager] Could not configure ttk styles: {e}")

    def _get_windows_original_scheme(self):
        """Original Windows color scheme (before theme manager)"""
        return {
            # Headers and primary elements
            'header_bg': '#2c3e50',
            'header_fg': '#ffffff',

            # Toggle buttons
            'toggle_device_active': '#95a5a6',
            'toggle_device_inactive': '#3498db',
            'toggle_device_connected': '#27ae60',
            'toggle_backup_active': '#1abc9c',
            'toggle_backup_inactive': '#16a085',
            'toggle_fg': '#ffffff',

            # Buttons
            'button_primary_bg': '#3498db',
            'button_primary_fg': '#ffffff',
            'button_success_bg': '#27ae60',
            'button_success_fg': '#ffffff',
            'button_danger_bg': '#e74c3c',
            'button_danger_fg': '#ffffff',
            'button_secondary_bg': '#ecf0f1',
            'button_secondary_fg': '#7f8c8d',
            'button_dark_bg': '#34495e',
            'button_dark_fg': '#ffffff',

            # Status indicators
            'status_success': '#27ae60',
            'status_error': '#e74c3c',
            'status_warning': '#f39c12',
            'status_info': '#3498db',

            # Text
            'text_primary': '#2c3e50',
            'text_secondary': '#7f8c8d',
            'text_light': '#ecf0f1',

            # Backgrounds (original white backgrounds for Windows)
            'bg_primary': '#ffffff',
            'bg_secondary': '#ecf0f1',
            'bg_dark': '#2c3e50',

            # Dialog backgrounds
            'dialog_bg': '#ffffff',
        }

    def _get_macos_linux_scheme(self):
        """Uniform scheme for macOS/Linux to prevent system appearance interference"""
        return {
            # Headers and primary elements
            'header_bg': '#2c3e50',
            'header_fg': '#ffffff',

            # Toggle buttons
            'toggle_device_active': '#95a5a6',
            'toggle_device_inactive': '#3498db',
            'toggle_device_connected': '#27ae60',
            'toggle_backup_active': '#1abc9c',
            'toggle_backup_inactive': '#16a085',
            'toggle_fg': '#ffffff',

            # Buttons
            'button_primary_bg': '#3498db',
            'button_primary_fg': '#ffffff',
            'button_success_bg': '#27ae60',
            'button_success_fg': '#ffffff',
            'button_danger_bg': '#e74c3c',
            'button_danger_fg': '#ffffff',
            'button_secondary_bg': '#ecf0f1',
            'button_secondary_fg': '#7f8c8d',
            'button_dark_bg': '#34495e',
            'button_dark_fg': '#ffffff',

            # Status indicators
            'status_success': '#27ae60',
            'status_error': '#e74c3c',
            'status_warning': '#f39c12',
            'status_info': '#3498db',

            # Text
            'text_primary': '#2c3e50',
            'text_secondary': '#7f8c8d',
            'text_light': '#ecf0f1',

            # Backgrounds (uniform #f0f0f0 for macOS/Linux)
            'bg_primary': '#f0f0f0',
            'bg_secondary': '#f0f0f0',
            'bg_dark': '#2c3e50',

            # Dialog backgrounds
            'dialog_bg': '#f0f0f0',
        }

    def get_color(self, key):
        """Get color by key name"""
        return self.colors.get(key, '#000000')


# Global theme instance
_theme_instance = None

def get_theme(root=None):
    """
    Get global theme instance.

    Args:
        root: Optional root window for ttk style configuration
    """
    global _theme_instance
    if _theme_instance is None:
        _theme_instance = ThemeManager(root)
    elif root and not _theme_instance.root:
        # Update with root window if not already set
        _theme_instance.root = root
        _theme_instance._configure_ttk_styles()
        _theme_instance._configure_root_window()
    return _theme_instance
