#!/usr/bin/env python3
"""
Audit logger utilities for forensic-aware extraction runs.
"""

import json
import os
import threading
import time
import hashlib
from typing import Any, Dict, Optional


class AuditLogger:
    """Buffered NDJSON audit logger."""

    def __init__(self, output_dir: str, run_id: str, buffer_size: int = 50, flush_interval: float = 1.0):
        self.output_dir = output_dir
        self.run_id = run_id
        self.buffer_size = max(1, buffer_size)
        self.flush_interval = max(0.1, flush_interval)
        self._path = os.path.join(output_dir, "audit_log.ndjson")
        self._buffer = []
        self._lock = threading.Lock()
        self._last_flush = time.time()
        os.makedirs(output_dir, exist_ok=True)

    @property
    def path(self) -> str:
        return self._path

    def emit(self, event: Dict[str, Any]) -> None:
        if "ts_utc" not in event:
            event["ts_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        if "run_id" not in event:
            event["run_id"] = self.run_id
        with self._lock:
            self._buffer.append(event)
            now = time.time()
            if len(self._buffer) >= self.buffer_size or (now - self._last_flush) >= self.flush_interval:
                self._flush_locked()

    def flush(self) -> None:
        with self._lock:
            self._flush_locked()

    def close(self) -> None:
        self.flush()

    def _flush_locked(self) -> None:
        if not self._buffer:
            return
        try:
            with open(self._path, "a", encoding="utf-8") as f:
                for entry in self._buffer:
                    f.write(json.dumps(entry, ensure_ascii=True) + "\n")
        finally:
            self._buffer = []
            self._last_flush = time.time()


def hash_file(path: str, algo: str = "sha256", chunk_size: int = 1024 * 1024) -> Optional[str]:
    if not path or not os.path.exists(path):
        return None
    h = hashlib.new(algo)
    try:
        with open(path, "rb") as f:
            while True:
                chunk = f.read(chunk_size)
                if not chunk:
                    break
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return None
