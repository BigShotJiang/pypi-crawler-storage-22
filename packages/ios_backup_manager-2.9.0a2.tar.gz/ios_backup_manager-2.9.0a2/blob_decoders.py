"""
blob_decoders.py

Helpers for decoding binary plist / NSKeyedArchiver blobs from iOS app databases.
All extra decoders are optional; the module degrades gracefully if any are missing.
"""

from __future__ import annotations
import plistlib
from typing import Any, Optional


def _try_plist(blob: bytes) -> Optional[Any]:
    """Try to decode blob as a plain binary or XML plist."""
    try:
        return plistlib.loads(blob)
    except Exception:
        return None


def _try_nskeyed_unarchiver(blob: bytes) -> Optional[Any]:
    """
    Try to decode as NSKeyedArchiver using available third-party libraries.
    """
    # 1) NSKeyedUnArchiver
    try:
        import NSKeyedUnArchiver  # type: ignore
        return NSKeyedUnArchiver.unarchive(blob)
    except Exception:
        pass

    # 2) nska_deserialize
    try:
        import nska_deserialize  # type: ignore
        return nska_deserialize.deserialize_plist(blob)
    except Exception:
        pass

    return None


def decode_unknown_blob(blob: bytes) -> Optional[dict]:
    """
    Attempt to decode an opaque blob into a JSON-serializable structure.

    Returns:
        A dict like {"format": "plist"|"nskeyed", "value": <decoded>}
        or None if it could not be decoded.
    """
    # 1) Straight plist
    obj = _try_plist(blob)
    if obj is not None:
        return {"format": "plist", "value": obj}

    # 2) NSKeyedArchiver variants
    obj = _try_nskeyed_unarchiver(blob)
    if obj is not None:
        return {"format": "nskeyed", "value": obj}

    return None
