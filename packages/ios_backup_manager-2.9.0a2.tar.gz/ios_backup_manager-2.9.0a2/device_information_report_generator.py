import os
import sqlite3
import plistlib
import hashlib
from datetime import datetime
from typing import Dict, List, Optional

from backup_access import is_encrypted_backup


def _format_datetime(value: Optional[float]) -> str:
    if not value:
        return "Unknown"
    try:
        return datetime.fromtimestamp(value).strftime("%m-%d-%Y %I:%M %p")
    except Exception:
        return "Unknown"


def _format_duration(seconds: float) -> str:
    try:
        seconds = int(seconds)
    except Exception:
        return "Unknown"
    if seconds <= 0:
        return "Unknown"
    minutes, sec = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    if hours:
        return f"{hours}h {minutes}m {sec}s"
    if minutes:
        return f"{minutes}m {sec}s"
    return f"{sec}s"

def _format_app_version(app_version: str, build_number: str) -> str:
    app_version = (app_version or "Unknown").strip()
    build_number = (build_number or "").strip()
    if build_number:
        return f"{app_version} (Build {build_number})"
    return app_version


def _safe_load_plist(path: str) -> dict:
    if not path or not os.path.exists(path):
        return {}
    try:
        with open(path, "rb") as f:
            return plistlib.load(f)
    except Exception:
        return {}


def _get_plist_value(info: dict, status: dict, keys: List[str]) -> str:
    for key in keys:
        if key in info and info.get(key) not in (None, ""):
            return str(info.get(key))
        if key in status and status.get(key) not in (None, ""):
            return str(status.get(key))
    return ""


def _find_accounts_db_path(backup_path: str, backup_access=None) -> str:
    rel_path = "Library/Accounts/Accounts3.sqlite"
    if backup_access is not None:
        path = backup_access.get_file_path("HomeDomain", rel_path)
        if path and os.path.exists(path):
            return path
    file_id = hashlib.sha1(f"HomeDomain-{rel_path}".encode()).hexdigest()
    path = os.path.join(backup_path, file_id[:2], file_id)
    return path if os.path.exists(path) else ""


def _find_apple_id_from_accounts(backup_path: str, backup_access=None) -> str:
    path = _find_accounts_db_path(backup_path, backup_access=backup_access)
    if not path:
        return ""
    try:
        conn = sqlite3.connect(path)
        cur = conn.cursor()
        cur.execute("SELECT Z_PK, ZIDENTIFIER FROM ZACCOUNTTYPE")
        acct_types = {row[0]: row[1] for row in cur.fetchall()}
        cur.execute("SELECT ZUSERNAME, ZACCOUNTTYPE FROM ZACCOUNT WHERE ZUSERNAME IS NOT NULL")
        rows = cur.fetchall()
        conn.close()
    except Exception:
        return ""

    apple_accounts = []
    for username, type_id in rows:
        ident = acct_types.get(type_id, "") or ""
        if "AppleAccount" in ident:
            apple_accounts.append(str(username))
    if not apple_accounts:
        return ""
    for candidate in apple_accounts:
        if "@icloud.com" in candidate.lower():
            return candidate
    return apple_accounts[0]


def _find_commcenter_plist(backup_path: str, backup_access=None) -> dict:
    rel_path = "Library/Preferences/com.apple.commcenter.plist"
    path = ""
    if backup_access is not None:
        path = backup_access.get_file_path("WirelessDomain", rel_path)
    if not path:
        file_id = hashlib.sha1(f"WirelessDomain-{rel_path}".encode()).hexdigest()
        candidate = os.path.join(backup_path, file_id[:2], file_id)
        if os.path.exists(candidate):
            path = candidate
    if not path or not os.path.exists(path):
        return {}
    try:
        with open(path, "rb") as f:
            data = plistlib.load(f)
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _collect_installed_apps(manifest_db: str, info: dict) -> List[Dict[str, str]]:
    apps = []
    app_meta = info.get("Applications", {}) if isinstance(info.get("Applications"), dict) else {}
    seen = set()
    if not manifest_db or not os.path.exists(manifest_db):
        return apps
    try:
        conn = sqlite3.connect(manifest_db)
        cur = conn.cursor()
        cur.execute("SELECT DISTINCT domain FROM Files WHERE domain LIKE 'AppDomain-%'")
        rows = cur.fetchall()
        conn.close()
    except Exception:
        return apps

    for row in rows:
        domain = row[0] or ""
        if not domain.startswith("AppDomain-"):
            continue
        bundle_id = domain.replace("AppDomain-", "", 1)
        if not bundle_id or bundle_id in seen:
            continue
        seen.add(bundle_id)
        display_name = ""
        app_info = app_meta.get(bundle_id)
        if isinstance(app_info, dict):
            display_name = (
                app_info.get("ApplicationName")
                or app_info.get("CFBundleDisplayName")
                or app_info.get("CFBundleName")
                or ""
            )
        apps.append({
            "bundle_id": bundle_id,
            "display_name": str(display_name) if display_name else "",
        })

    apps.sort(key=lambda item: (item["display_name"] or item["bundle_id"]).lower())
    return apps


def generate_device_information_report(
    backup_path: str,
    output_base_dir: str,
    summary: dict,
    options: dict,
    backup_access=None,
) -> None:
    info = _safe_load_plist(os.path.join(backup_path, "Info.plist"))
    status = _safe_load_plist(os.path.join(backup_path, "Status.plist"))

    app_version = str(options.get("app_version") or "").strip()
    build_number = str(options.get("build_number") or "").strip()
    display_version = _format_app_version(app_version, build_number)
    options_rows = []
    for key, label in [
        ("convert_heic", "Convert HEIC to JPG"),
        ("organize_by_date", "Organize photos by date"),
        ("organize_by_category", "Organize by category"),
        ("include_cached_thumbnails", "Include cached thumbnails"),
        ("generate_summary", "Generate extraction summary"),
    ]:
        value = options.get(key, False)
        options_rows.append(
            f"<div class=\"field\"><span>{label}</span><strong>{'Enabled' if value else 'Not enabled'}</strong></div>"
        )
    audit_mode = str(options.get("audit_mode", "minimal")).lower().strip()
    options_rows.append(
        f"<div class=\"field\"><span>Forensic Mode</span><strong>{'Enabled' if audit_mode == 'forensic' else 'Not enabled'}</strong></div>"
    )
    timezone = options.get("timezone") or datetime.now().astimezone().tzname() or "Local"
    extraction_type = options.get("extraction_type", "Full")
    start_ts = summary.get("start_time")
    end_ts = summary.get("end_time")
    duration = _format_duration(summary.get("duration", 0))

    encrypted = False
    if backup_access is not None and getattr(backup_access, "is_encrypted", False):
        encrypted = True
    else:
        encrypted = is_encrypted_backup(backup_path)

    device_name = info.get("Device Name", "Unknown")
    display_name = info.get("Display Name", "")
    product_type = info.get("Product Type", "Unknown")
    product_version = info.get("Product Version", "Unknown")
    serial = _get_plist_value(info, status, ["Serial Number", "SerialNumber"])
    udid = _get_plist_value(info, status, ["Unique Identifier", "Target Identifier", "UniqueDeviceID"])
    apple_id = _get_plist_value(info, status, ["Apple ID", "AppleID", "AppleId"])
    if not apple_id:
        apple_id = _find_apple_id_from_accounts(backup_path, backup_access=backup_access)
    commcenter = _find_commcenter_plist(backup_path, backup_access=backup_access)
    iccid = _get_plist_value(info, status, ["ICCID", "Last ICCID", "LastICCID"])
    if not iccid:
        iccid = str(commcenter.get("LastKnownICCID") or commcenter.get("NetworkPhoneNumberICCID") or "")
    imei = _get_plist_value(info, status, ["IMEI"])
    imei2 = _get_plist_value(info, status, ["IMEI2", "IMEI 2", "Second IMEI", "SecondIMEI"])
    if not imei2:
        imei2 = str(commcenter.get("IMEI2") or commcenter.get("SecondIMEI") or "")
    phone = _get_plist_value(info, status, ["Phone Number", "PhoneNumber"])
    if not phone:
        phone = str(commcenter.get("SIMPhoneNumber") or commcenter.get("PhoneNumber") or commcenter.get("NetworkPhoneNumber") or "")
    phone2 = _get_plist_value(info, status, ["Phone Number 2", "PhoneNumber2"])
    last_activation = _get_plist_value(info, status, ["Last Activation Date", "LastActivationDate"])
    last_iccid = _get_plist_value(info, status, ["Last ICCID", "LastICCID"])

    manifest_db = backup_access.manifest_db_path if backup_access is not None else os.path.join(backup_path, "Manifest.db")
    apps = _collect_installed_apps(manifest_db, info)

    case_info = options.get("case_info") or {}
    case_rows = []
    if case_info:
        for key, label in [
            ("case_number", "Case Number"),
            ("evidence_number", "Evidence Number"),
            ("examiner", "Examiner"),
            ("department", "Department"),
            ("location", "Location"),
        ]:
            value = case_info.get(key)
            if value:
                case_rows.append(f"<div class=\"field\"><span>{label}</span><strong>{value}</strong></div>")

    app_rows = []
    for item in apps:
        name = item["display_name"] or ""
        bundle_id = item["bundle_id"]
        if name:
            app_rows.append(f"<div class=\"app-row\"><div class=\"app-name\">{name}</div><div class=\"app-bundle\">{bundle_id}</div></div>")
        else:
            app_rows.append(f"<div class=\"app-row\"><div class=\"app-name\">{bundle_id}</div></div>")

    case_html = ""
    if case_rows:
        case_html = f"""
        <div class="card">
            <h2>Case Information</h2>
            <div class="grid">{''.join(case_rows)}</div>
        </div>
        """

    apps_html = ""
    if apps:
        apps_html = f"""
        <details class="card" open>
            <summary>Installed Apps ({len(apps):,})</summary>
            <div class="apps-list">
                {''.join(app_rows)}
            </div>
        </details>
        """

    output_dir = os.path.join(output_base_dir, "Device Information")
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, "Device_Information.html")

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Device Information</title>
  <style>
    :root {{
      --bg: #f3f4f6;
      --card: #ffffff;
      --line: #e5e7eb;
      --ink: #111827;
      --muted: #6b7280;
      --accent: #2563eb;
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      font-family: "Trebuchet MS", "Verdana", sans-serif;
      background: var(--bg);
      color: var(--ink);
    }}
    header {{
      background: linear-gradient(135deg, #283048, #859398);
      color: #fff;
      padding: 0;
      margin: 20px auto 20px auto;
      border-radius: 12px;
      overflow: hidden;
    }}
    .header-inner {{
      max-width: 1100px;
      margin: 0 auto;
      padding: 22px 20px 18px 20px;
    }}
    .breadcrumbs {{
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 12px;
      letter-spacing: 0.2px;
      color: rgba(255,255,255,0.85);
      margin-bottom: 10px;
    }}
    .breadcrumbs a {{
      color: #fff;
      text-decoration: none;
      font-weight: 600;
    }}
    .breadcrumbs a:hover {{
      text-decoration: underline;
    }}
    .breadcrumbs .back-arrow {{
      opacity: 0.6;
    }}
    .embedded .breadcrumbs {{
      display: none;
    }}
    header h1 {{ margin: 0 0 6px; font-size: 28px; }}
    header p {{ margin: 0; color: rgba(255,255,255,0.8); }}
    .wrap {{
      max-width: 1100px;
      margin: 0 auto;
      padding: 20px;
    }}
    .card {{
      background: var(--card);
      border: 1px solid var(--line);
      border-radius: 14px;
      padding: 16px;
      margin-bottom: 16px;
    }}
    .card h2 {{
      margin: 0 0 12px 0;
      font-size: 18px;
    }}
    .grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 12px;
    }}
    .field {{
      background: #f9fafb;
      border: 1px solid var(--line);
      border-radius: 10px;
      padding: 10px 12px;
    }}
    .field span {{
      display: block;
      font-size: 11px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: var(--muted);
    }}
    .field strong {{
      display: block;
      font-size: 14px;
      margin-top: 4px;
    }}
    details.card summary {{
      cursor: pointer;
      font-weight: 700;
      font-size: 16px;
      color: var(--accent);
      list-style: none;
    }}
    details.card summary::-webkit-details-marker {{ display: none; }}
    .apps-list {{
      margin-top: 12px;
      border-top: 1px solid var(--line);
      padding-top: 12px;
      display: grid;
      gap: 8px;
    }}
    .app-row {{
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        flex-wrap: wrap;
        gap: 10px;
        background: #f9fafb;
        border: 1px solid var(--line);
        border-radius: 10px;
      padding: 8px 10px;
    }}
    .app-name {{ flex: 1 1 220px; min-width: 0; font-weight: 600; overflow-wrap: anywhere; }}
    .app-bundle {{ flex: 1 1 260px; min-width: 0; color: var(--muted); font-size: 12px; overflow-wrap: anywhere; word-break: break-word; }}
  </style>
</head>
<body>
  <div class="wrap">
    <header>
      <div class="header-inner">
        <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Start_Here.html">Back</a></div>
        <h1>Device Information</h1>
        <p>Extraction summary and device metadata</p>
      </div>
    </header>
    <div class="card">
      <h2>Extraction Summary</h2>
      <div class="grid">
        <div class="field"><span>Extraction Type</span><strong>{extraction_type}</strong></div>
        <div class="field"><span>Start Time</span><strong>{_format_datetime(start_ts)}</strong></div>
        <div class="field"><span>End Time</span><strong>{_format_datetime(end_ts)}</strong></div>
        <div class="field"><span>Duration</span><strong>{duration}</strong></div>
        <div class="field"><span>Time Zone</span><strong>{timezone}</strong></div>
        <div class="field"><span>Software Version</span><strong>{display_version}</strong></div>
      </div>
      <div class="grid" style="margin-top:12px;">
        {''.join(options_rows)}
      </div>
    </div>
    {case_html}
    <div class="card">
      <h2>Device Information</h2>
      <div class="grid">
        <div class="field"><span>Device Name</span><strong>{device_name}</strong></div>
        <div class="field"><span>Display Name</span><strong>{display_name or "Unknown"}</strong></div>
        <div class="field"><span>Product Type</span><strong>{product_type}</strong></div>
        <div class="field"><span>Product Version</span><strong>{product_version}</strong></div>
        <div class="field"><span>Unique Identifier</span><strong>{udid or "Unknown"}</strong></div>
        <div class="field"><span>Serial Number</span><strong>{serial or "Unknown"}</strong></div>
        <div class="field"><span>Encrypted Backup</span><strong>{"Yes" if encrypted else "No"}</strong></div>
        <div class="field"><span>Apple ID</span><strong>{apple_id or "Unknown"}</strong></div>
        <div class="field"><span>ICCID</span><strong>{iccid or "Unknown"}</strong></div>
        <div class="field"><span>Last ICCID</span><strong>{last_iccid or "Unknown"}</strong></div>
        <div class="field"><span>IMEI</span><strong>{imei or "Unknown"}</strong></div>
        <div class="field"><span>IMEI 2</span><strong>{imei2 or "Unknown"}</strong></div>
        <div class="field"><span>Phone Number</span><strong>{phone or "Unknown"}</strong></div>
        <div class="field"><span>Phone Number 2</span><strong>{phone2 or "Unknown"}</strong></div>
        <div class="field"><span>Last Activation</span><strong>{last_activation or "Unknown"}</strong></div>
      </div>
    </div>
    {apps_html}
  </div>
  <script>
    if (window.self !== window.top) {{ document.body.classList.add('embedded'); }}
  </script>
</body>
</html>"""

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)
