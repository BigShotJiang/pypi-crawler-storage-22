"""
Data extractors for iOS backup categories.

Provides base classes and implementations for extracting and exporting
data from specific categories (Contacts, SMS, Photos, etc.)
"""

from .base import CategoryDataExtractor

__all__ = ['CategoryDataExtractor']
