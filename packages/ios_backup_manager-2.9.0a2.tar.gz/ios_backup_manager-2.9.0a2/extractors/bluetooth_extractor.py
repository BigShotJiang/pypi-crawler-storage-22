#!/usr/bin/env python3
"""
Bluetooth pairings extractor for iOS backups.

Scans preference plists in HomeDomain/Library/Preferences to identify
paired Bluetooth devices and emits a simple HTML/JSON report.
"""

import os
import plistlib
import sqlite3
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from .base import CategoryDataExtractor


class BluetoothExtractor(CategoryDataExtractor):
    """Extract paired Bluetooth devices from iOS backup plists."""

    _PLIST_KEYWORDS = ("Bluetooth", "Paired", "DeviceCache", "PairedDevices")
    _APPLE_EPOCH = datetime(2001, 1, 1)

    def __init__(self, backup_path: str):
        super().__init__(backup_path)
        self._plist_sources = self._find_bluetooth_plists()
        self._db_sources = self._find_bluetooth_databases()
        if not self._plist_sources and not self._db_sources:
            raise FileNotFoundError("Bluetooth pairing data not found in backup")

    def _find_bluetooth_plists(self) -> List[Dict[str, Any]]:
        sources = []
        manifest_path = self.manifest_db_path
        if not os.path.exists(manifest_path):
            return sources

        try:
            conn = sqlite3.connect(f"file:{manifest_path}?mode=ro", uri=True)
            cur = conn.cursor()
            cur.execute("""
                SELECT fileID, relativePath
                FROM Files
                WHERE (domain = 'HomeDomain'
                       OR domain = 'SysSharedContainerDomain-systemgroup.com.apple.bluetooth')
                  AND relativePath LIKE 'Library/Preferences/%'
                  AND relativePath LIKE '%.plist'
            """)
            rows = cur.fetchall()
            conn.close()
        except Exception:
            return sources

        for file_id, relpath in rows:
            plist_path = self._resolve_file_id_path(file_id)
            if not plist_path or not os.path.exists(plist_path):
                continue
            try:
                if os.path.getsize(plist_path) > 10 * 1024 * 1024:
                    continue
                with open(plist_path, "rb") as f:
                    plist = plistlib.load(f)
            except Exception:
                continue

            if not self._plist_has_bluetooth_data(plist, relpath):
                continue

            sources.append({
                "relative_path": relpath,
                "file_path": plist_path,
                "plist": plist,
            })

        return sources

    def _find_bluetooth_databases(self) -> List[Dict[str, Any]]:
        sources = []
        manifest_path = self.manifest_db_path
        if not os.path.exists(manifest_path):
            return sources

        try:
            conn = sqlite3.connect(f"file:{manifest_path}?mode=ro", uri=True)
            cur = conn.cursor()
            cur.execute("""
                SELECT fileID, domain, relativePath
                FROM Files
                WHERE (domain LIKE '%bluetooth%' OR relativePath LIKE '%Bluetooth%' OR relativePath LIKE '%MobileBluetooth%')
                  AND (relativePath LIKE '%.db' OR relativePath LIKE '%.sqlite')
                  AND relativePath NOT LIKE '%-wal'
                  AND relativePath NOT LIKE '%-shm'
            """)
            rows = cur.fetchall()
            conn.close()
        except Exception:
            return sources

        seen = set()
        for file_id, domain, relpath in rows:
            key = (domain, relpath)
            if key in seen:
                continue
            seen.add(key)
            db_path = self._resolve_file_id_path(file_id)
            if not db_path or not os.path.exists(db_path):
                continue
            sources.append({
                "domain": domain,
                "relative_path": relpath,
                "path": db_path,
            })

        return sources

    def _plist_has_bluetooth_data(self, plist: Any, relpath: str) -> bool:
        if "bluetooth" in relpath.lower():
            return True

        def scan(obj: Any, depth: int = 0) -> bool:
            if depth > 4:
                return False
            if isinstance(obj, dict):
                for key, value in obj.items():
                    if any(token.lower() in str(key).lower() for token in self._PLIST_KEYWORDS):
                        return True
                    if scan(value, depth + 1):
                        return True
            elif isinstance(obj, list):
                for entry in obj:
                    if scan(entry, depth + 1):
                        return True
            elif isinstance(obj, str):
                return any(token.lower() in obj.lower() for token in self._PLIST_KEYWORDS)
            return False

        return scan(plist)

    def _normalize_timestamp(self, value: Any) -> Optional[int]:
        try:
            ts = float(value)
        except Exception:
            return None
        if ts <= 0:
            return None
        # milliseconds since Unix epoch
        if ts > 1e12:
            return int(ts / 1000)
        # seconds since Unix epoch
        if ts > 1e10:
            return int(ts)
        # likely Apple epoch seconds
        if ts > 1e6:
            return int((self._APPLE_EPOCH + timedelta(seconds=ts)).timestamp())
        return None

    def _extract_items(self) -> List[Dict[str, Any]]:
        devices: Dict[str, Dict[str, Any]] = {}

        for source in self._plist_sources:
            relpath = source["relative_path"]
            plist = source["plist"]

            if isinstance(plist, dict):
                device_cache = plist.get("DeviceCache") or plist.get("deviceCache")
                if isinstance(device_cache, dict):
                    for address, info in device_cache.items():
                        if not isinstance(info, dict):
                            continue
                        name = (
                            info.get("Name")
                            or info.get("DeviceName")
                            or info.get("Nickname")
                            or info.get("DisplayName")
                            or ""
                        )
                        last_seen = self._normalize_timestamp(
                            info.get("LastSeenTime")
                            or info.get("LastSeenTimeUTC")
                            or info.get("LastSeen")
                        )
                        devices.setdefault(str(address), {
                            "address": str(address),
                            "name": name,
                            "last_seen": last_seen,
                            "source_file": relpath,
                            "source_table": "DeviceCache",
                            "raw": info,
                        })

                paired_list = plist.get("PairedDevices") or plist.get("PairedDevicesArray")
                if isinstance(paired_list, list):
                    for entry in paired_list:
                        address = str(entry)
                        devices.setdefault(address, {
                            "address": address,
                            "name": "",
                            "last_seen": None,
                            "source_file": relpath,
                            "source_table": "",
                            "raw": entry,
                        })

        for source in self._db_sources:
            db_path = source["path"]
            try:
                conn = sqlite3.connect(db_path)
                conn.row_factory = sqlite3.Row
                cur = conn.cursor()
                cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
                tables = [row[0] for row in cur.fetchall()]
            except Exception:
                continue

            for table in tables:
                if table != "PairedDevices":
                    continue
                try:
                    cur.execute(f"PRAGMA table_info({table})")
                    cols = {row[1] for row in cur.fetchall()}
                except Exception:
                    continue

                name_col = "Name" if "Name" in cols else None
                address_col = "Address" if "Address" in cols else None
                last_seen_col = "LastSeenTime" if "LastSeenTime" in cols else None
                last_conn_col = "LastConnectionTime" if "LastConnectionTime" in cols else None

                select_cols = [col for col in (name_col, address_col, last_seen_col, last_conn_col) if col]
                if not select_cols:
                    continue

                try:
                    cur.execute(f"SELECT {', '.join(select_cols)} FROM {table}")
                    rows = cur.fetchall()
                except Exception:
                    continue

                for row in rows:
                    name = row[name_col] if name_col else ""
                    address = row[address_col] if address_col else ""
                    last_seen = self._normalize_timestamp(row[last_seen_col]) if last_seen_col else None
                    last_conn = self._normalize_timestamp(row[last_conn_col]) if last_conn_col else None
                    ts = last_conn or last_seen
                    key = str(address) if address else f"{table}:{name}"
                    devices.setdefault(key, {
                        "address": str(address) if address else "",
                        "name": str(name) if name else "",
                        "last_seen": ts,
                        "source_file": source["relative_path"],
                        "source_table": table,
                        "raw": {
                            "last_seen": row[last_seen_col] if last_seen_col else None,
                            "last_connection": row[last_conn_col] if last_conn_col else None,
                        },
                    })

            conn.close()

        return list(devices.values())

    def get_count(self) -> int:
        return len(self._extract_items())

    def get_items(self, limit: Optional[int] = None, offset: int = 0,
                  search: Optional[str] = None) -> List[Dict[str, Any]]:
        items = self._extract_items()
        if search:
            term = search.lower()
            items = [
                item for item in items
                if term in (item.get("name") or "").lower()
                or term in (item.get("address") or "").lower()
            ]
        items.sort(key=lambda x: x.get("last_seen") or 0, reverse=True)
        if limit:
            return items[offset:offset + limit]
        return items[offset:]

    def export(self, items: List[Dict[str, Any]], output_path: str,
               format: str = "html", progress_callback=None, timeline_emitter=None) -> bool:
        if format != "html":
            raise ValueError(f"Unsupported export format: {format}")

        try:
            self._reset_export_bytes()
            os.makedirs(output_path, exist_ok=True)

            if progress_callback:
                if not progress_callback(0, len(items), "Preparing Bluetooth report..."):
                    return False

            html_path = os.path.join(output_path, "Bluetooth.html")
            json_path = os.path.join(output_path, "Bluetooth.json")

            with open(json_path, "w", encoding="utf-8") as f:
                import json
                json.dump(items, f, indent=2, ensure_ascii=False)
            self._add_export_bytes(json_path)

            rows = []
            for idx, item in enumerate(items, start=1):
                if progress_callback:
                    if not progress_callback(idx, len(items), item.get("name") or item.get("address") or "Device"):
                        return False

                ts = item.get("last_seen")
                ts_str = datetime.fromtimestamp(ts).isoformat() if ts else ""
                rows.append(
                    "<tr>"
                    f"<td>{self._escape_html(item.get('name') or '')}</td>"
                    f"<td>{self._escape_html(item.get('address') or '')}</td>"
                    f"<td>{self._escape_html(ts_str)}</td>"
                    f"<td>{self._escape_html(item.get('source_file') or '')}</td>"
                    "</tr>"
                )

                if timeline_emitter is not None and ts:
                    timeline_emitter.emit({
                        "timestamp": datetime.fromtimestamp(ts).isoformat(),
                        "raw_timestamp": ts,
                        "raw_format": "unix_seconds",
                        "source_app": "Bluetooth",
                        "source_category": "Bluetooth Pairings",
                        "event_type": "bluetooth_pairing",
                        "title": item.get("name") or item.get("address") or "Bluetooth Device",
                        "details": {
                            "address": item.get("address"),
                            "name": item.get("name"),
                            "source_file": item.get("source_file"),
                        },
                        "confidence": "medium",
                        "raw_source_path": item.get("source_file") or "",
                        "report_anchor": "",
                        "link_hint": "Bluetooth/Bluetooth.html",
                    })

            html = """<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Bluetooth Pairings</title>
  <style>
    body { font-family: Arial, sans-serif; background: #f5f5f5; padding: 20px; }
    .container { background: #fff; border-radius: 8px; padding: 20px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { text-align: left; padding: 8px; border-bottom: 1px solid #e5e5e5; }
    th { background: #fafafa; }
  </style>
</head>
<body>
  <div class="container">
    <h1>Bluetooth Pairings</h1>
    <p>Total devices: """ + str(len(items)) + """</p>
    <table>
      <thead>
        <tr><th>Name</th><th>Address</th><th>Last Seen</th><th>Source</th></tr>
      </thead>
      <tbody>
        """ + "\n".join(rows) + """
      </tbody>
    </table>
  </div>
</body>
</html>
"""
            with open(html_path, "w", encoding="utf-8") as f:
                f.write(html)
            self._add_export_bytes(html_path)

            return True
        except Exception as e:
            print(f"Error exporting Bluetooth pairings: {e}")
            return False

    def get_item_summary(self, item: Dict[str, Any]) -> str:
        name = item.get("name") or "Unknown"
        address = item.get("address") or ""
        return f"{name} ({address})".strip()

    @staticmethod
    def _escape_html(text: str) -> str:
        if not text:
            return ""
        text = str(text)
        return (text.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;"))
