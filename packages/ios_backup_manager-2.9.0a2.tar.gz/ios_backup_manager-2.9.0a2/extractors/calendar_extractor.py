#!/usr/bin/env python3
"""
Calendar data extractor for iOS backups.

Extracts calendar events and reminders from Calendar.sqlitedb and exports to ICS format.
"""

import sqlite3
import json
import os
from typing import List, Dict, Any, Optional
from datetime import datetime, timezone
from .base import CategoryDataExtractor


class CalendarExtractor(CategoryDataExtractor):
    """Extract and export calendar events from iOS backup."""

    def __init__(self, backup_path: str):
        super().__init__(backup_path)

        # Find Calendar database
        self.calendar_db_path = self.find_db_file(
            "HomeDomain",
            "Library/Calendar/Calendar.sqlitedb"
        )

        # Try alternate extension
        if not self.calendar_db_path:
            self.calendar_db_path = self.find_db_file(
                "HomeDomain",
                "Library/Calendar/Calendar.sqlite"
            )

        if not self.calendar_db_path:
            raise FileNotFoundError("Calendar database not found in backup")

    def get_count(self) -> int:
        """Get total number of calendar events."""
        conn = sqlite3.connect(self.calendar_db_path)
        cur = conn.cursor()

        # Count calendar items (events)
        # entity_type: 2 = event (not 0 as might be expected)
        cur.execute("""
            SELECT COUNT(*)
            FROM CalendarItem
            WHERE entity_type = 2
        """)
        count = cur.fetchone()[0]

        conn.close()
        return count

    def get_items(self, limit: Optional[int] = None, offset: int = 0,
                  search: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get calendar events with pagination and optional search.

        Returns list of event dictionaries with fields:
        - event_id: Event ID
        - summary: Event title/summary
        - start_date: Start datetime
        - end_date: End datetime
        - all_day: Boolean indicating all-day event
        - location: Location name
        - description: Event description
        - calendar_name: Calendar name
        - calendar_color: Calendar color (hex)
        - has_recurrence: Boolean indicating recurring event
        - has_attendees: Boolean indicating event has attendees
        """
        conn = sqlite3.connect(self.calendar_db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        query = """
            SELECT
                ci.ROWID as event_id,
                ci.summary,
                ci.start_date,
                ci.end_date,
                ci.all_day,
                ci.description,
                ci.calendar_id,
                ci.location_id,
                ci.has_recurrences,
                ci.has_attendees,
                c.title as calendar_name,
                c.color as calendar_color,
                l.title as location_title,
                l.address as location_address
            FROM CalendarItem ci
            LEFT JOIN Calendar c ON ci.calendar_id = c.ROWID
            LEFT JOIN Location l ON ci.location_id = l.ROWID
            WHERE ci.entity_type = 2
        """
        params = []

        if search:
            query += " AND (ci.summary LIKE ? OR ci.description LIKE ? OR l.title LIKE ?)"
            search_pattern = f"%{search}%"
            params.extend([search_pattern, search_pattern, search_pattern])

        query += " ORDER BY ci.start_date DESC"

        if limit is not None:
            query += f" LIMIT {limit} OFFSET {offset}"

        cur.execute(query, params)
        rows = cur.fetchall()

        events = []
        for row in rows:
            # Combine location information
            location = None
            if row['location_title']:
                location = row['location_title']
                if row['location_address']:
                    location += f", {row['location_address']}"
            elif row['location_address']:
                location = row['location_address']

            event = {
                'event_id': row['event_id'],
                'summary': row['summary'] or 'Untitled Event',
                'start_date': row['start_date'],
                'end_date': row['end_date'],
                'all_day': bool(row['all_day']),
                'location': location,
                'description': row['description'] or '',
                'calendar_name': row['calendar_name'] or 'Calendar',
                'calendar_color': row['calendar_color'] or '#1BADF8',
                'has_recurrence': bool(row['has_recurrences']),
                'has_attendees': bool(row['has_attendees']),
            }
            events.append(event)

        conn.close()
        return events

    def export(self, items: List[Dict[str, Any]], output_path: str,
               format: str = 'ics', progress_callback=None, timeline_emitter=None) -> bool:
        """
        Export calendar events to ICS, HTML, and CSV formats.

        Args:
            items: List of events to export
            output_path: Output directory or file path
            format: Export format ('ics' - exports all three formats)
            progress_callback: Optional callback(current, total, item_name) -> bool

        Returns:
            True if export succeeded
        """
        try:
            self._reset_export_bytes()
            # Determine output directory and base filename
            if os.path.isdir(output_path):
                output_dir = output_path
                base_name = 'calendar_export'
            else:
                output_dir = os.path.dirname(output_path)
                base_name = os.path.splitext(os.path.basename(output_path))[0]

            os.makedirs(output_dir, exist_ok=True)

            # Export to all three formats
            total = len(items) * 3  # 3 formats
            current = 0

            # 1. Export ICS
            ics_file = os.path.join(output_dir, f'{base_name}.ics')
            with open(ics_file, 'w', encoding='utf-8') as f:
                f.write("BEGIN:VCALENDAR\n")
                f.write("VERSION:2.0\n")
                f.write("PRODID:-//iOS Backup Manager//Calendar Export//EN\n")
                f.write("CALSCALE:GREGORIAN\n")
                f.write("METHOD:PUBLISH\n")

                for i, event in enumerate(items):
                    current = i
                    if progress_callback:
                        if not progress_callback(current + 1, total, f"ICS: {event['summary']}"):
                            return False

                    self._write_ics_event(f, event)

                f.write("END:VCALENDAR\n")

            # 2. Export HTML
            html_file = os.path.join(output_dir, 'Calendar.html')
            if not self._export_html(items, html_file, progress_callback, len(items), total):
                return False

            # 3. Export CSV
            csv_file = os.path.join(output_dir, f'{base_name}.csv')
            if not self._export_csv(items, csv_file, progress_callback, len(items) * 2, total):
                return False

            if timeline_emitter is not None:
                self._emit_timeline_events(items, timeline_emitter)

            self._add_export_bytes(ics_file)
            self._add_export_bytes(html_file)
            self._add_export_bytes(csv_file)

            return True

        except Exception as e:
            print(f"Error exporting calendar: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _write_ics_event(self, file, event: Dict[str, Any]):
        """Write a single event in ICS format."""
        file.write("BEGIN:VEVENT\n")

        # UID (unique identifier)
        file.write(f"UID:{event['event_id']}@iosbackupmerger\n")

        # Summary (title)
        summary = self._escape_ics_text(event['summary'])
        file.write(f"SUMMARY:{summary}\n")

        # Description
        if event['description']:
            description = self._escape_ics_text(event['description'])
            file.write(f"DESCRIPTION:{description}\n")

        # Location
        if event['location']:
            location = self._escape_ics_text(event['location'])
            file.write(f"LOCATION:{location}\n")

        # Start and end dates
        if event['all_day']:
            # All-day events use DATE format (YYYYMMDD)
            start_str = self._format_ics_date(event['start_date'], all_day=True)
            end_str = self._format_ics_date(event['end_date'], all_day=True)
            file.write(f"DTSTART;VALUE=DATE:{start_str}\n")
            file.write(f"DTEND;VALUE=DATE:{end_str}\n")
        else:
            # Regular events use DATETIME format
            start_str = self._format_ics_datetime(event['start_date'])
            end_str = self._format_ics_datetime(event['end_date'])
            file.write(f"DTSTART:{start_str}\n")
            file.write(f"DTEND:{end_str}\n")

        # Categories (calendar name)
        if event['calendar_name']:
            calendar_name = self._escape_ics_text(event['calendar_name'])
            file.write(f"CATEGORIES:{calendar_name}\n")

        file.write("END:VEVENT\n")

    def _escape_ics_text(self, text: str) -> str:
        """Escape special characters for ICS format."""
        if not text:
            return ""
        # Escape backslashes, semicolons, commas, and newlines
        text = text.replace('\\', '\\\\')
        text = text.replace(';', '\\;')
        text = text.replace(',', '\\,')
        text = text.replace('\n', '\\n')
        return text

    def _format_ics_date(self, timestamp: float, all_day: bool = False) -> str:
        """Format Apple timestamp as ICS DATE (YYYYMMDD)."""
        if timestamp is None:
            return ""

        try:
            # Apple Core Data timestamp is seconds since 2001-01-01
            apple_epoch = datetime(2001, 1, 1, tzinfo=timezone.utc).timestamp()
            unix_timestamp = apple_epoch + timestamp
            dt = datetime.fromtimestamp(unix_timestamp, tz=timezone.utc)
            return dt.strftime("%Y%m%d")
        except:
            return ""

    def _format_ics_datetime(self, timestamp: float) -> str:
        """Format Apple timestamp as ICS DATETIME (YYYYMMDDTHHmmssZ)."""
        if timestamp is None:
            return ""

        try:
            # Apple Core Data timestamp is seconds since 2001-01-01
            apple_epoch = datetime(2001, 1, 1, tzinfo=timezone.utc).timestamp()
            unix_timestamp = apple_epoch + timestamp
            dt = datetime.fromtimestamp(unix_timestamp, tz=timezone.utc)
            return dt.strftime("%Y%m%dT%H%M%SZ")
        except:
            return ""

    def _format_timestamp(self, timestamp: Optional[float]) -> str:
        """Format Apple Core Data timestamp for display."""
        if timestamp is None:
            return "N/A"

        try:
            # Apple Core Data timestamp is seconds since 2001-01-01
            apple_epoch = datetime(2001, 1, 1, tzinfo=timezone.utc).timestamp()
            unix_timestamp = apple_epoch + timestamp
            dt = datetime.fromtimestamp(unix_timestamp)
            return dt.strftime("%m-%d-%Y %H:%M:%S")
        except:
            return str(timestamp)

    def _format_timestamp_iso(self, timestamp: Optional[float]) -> Optional[str]:
        """Format Apple Core Data timestamp as ISO 8601."""
        dt = self._to_datetime(timestamp)
        if not dt:
            return None
        return dt.isoformat()

    def _to_datetime(self, timestamp: Optional[float]) -> Optional[datetime]:
        """Convert Apple Core Data timestamp to datetime."""
        if timestamp is None:
            return None
        try:
            apple_epoch = datetime(2001, 1, 1, tzinfo=timezone.utc).timestamp()
            unix_timestamp = apple_epoch + timestamp
            return datetime.fromtimestamp(unix_timestamp)
        except Exception:
            return None

    def get_item_summary(self, item: Dict[str, Any]) -> str:
        """Get short summary for list view."""
        summary = item['summary']
        start = self._format_timestamp(item['start_date'])

        # Truncate summary if too long
        if len(summary) > 40:
            summary = summary[:37] + "..."

        return f"{summary} ({start})"

    def _emit_timeline_events(self, items: List[Dict[str, Any]], timeline_emitter) -> None:
        for event in items:
            ts_iso = self._format_timestamp_iso(event.get('start_date'))
            if not ts_iso:
                continue
            details = {
                'summary': event.get('summary') or 'Untitled Event',
                'location': event.get('location') or '',
                'calendar': event.get('calendar_name') or 'Calendar',
                'start': self._format_timestamp(event.get('start_date')),
                'end': self._format_timestamp(event.get('end_date')),
                'all_day': bool(event.get('all_day')),
            }
            timeline_emitter.emit({
                'timestamp': ts_iso,
                'raw_timestamp': event.get('start_date'),
                'raw_format': 'apple_coredata_seconds',
                'source_app': 'Calendar',
                'source_category': 'Calendar',
                'event_type': 'calendar_event',
                'title': details['summary'],
                'details': details,
                'confidence': 'medium',
                'raw_source_path': self.calendar_db_path,
                'report_anchor': f"event-{event.get('event_id')}",
                'link_hint': 'Calendar/Calendar.html',
            })

    def _export_html(self, items: List[Dict[str, Any]], html_file: str,
                     progress_callback, offset: int, total: int) -> bool:
        """Export calendar events to HTML format."""
        try:
            events_data = []
            for event in items:
                start_dt = self._to_datetime(event.get('start_date'))
                end_dt = self._to_datetime(event.get('end_date'))
                events_data.append({
                    'title': event.get('summary') or 'Untitled Event',
                    'start_date': start_dt.strftime('%m-%d-%Y') if start_dt else '',
                    'start_key': start_dt.strftime('%Y-%m-%d') if start_dt else '',
                    'start_time': start_dt.strftime('%I:%M %p') if start_dt else '',
                    'end_date': end_dt.strftime('%m-%d-%Y') if end_dt else '',
                    'calendar': event.get('calendar_name') or 'Calendar',
                    'color': event.get('calendar_color') or '#1BADF8',
                    'all_day': bool(event.get('all_day')),
                })
            events_json = json.dumps(events_data, ensure_ascii=True)

            with open(html_file, 'w', encoding='utf-8') as f:
                # Write HTML header
                f.write("""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendar</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;
            margin: 20px;
            background-color: #f5f5f5;
        }
        .header {
            background: linear-gradient(135deg, #1F1C2C 0%, #928DAB 100%);
            color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .header h1 {
            margin: 0 0 10px 0;
            font-size: 32px;
            font-weight: 600;
        }
        .breadcrumbs {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            letter-spacing: 0.2px;
            color: rgba(255,255,255,0.85);
            margin-bottom: 10px;
        }
        .breadcrumbs a {
            color: #fff;
            text-decoration: none;
            font-weight: 600;
        }
        .breadcrumbs a:hover {
            text-decoration: underline;
        }
        .breadcrumbs .back-arrow {
            opacity: 0.6;
        }
        .embedded .breadcrumbs {
            display: none;
        }
        .header p {
            margin: 0;
            font-size: 16px;
            opacity: 0.9;
        }
        .header-total {
            margin-top: 8px;
            font-size: 14px;
            opacity: 0.85;
        }
        .export-info {
            color: #666;
            font-size: 14px;
            margin-bottom: 30px;
        }
        .search-box {
            position: relative;
            margin-bottom: 20px;
        }
        .search-box input {
            width: 100%;
            padding: 12px 46px 12px 16px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            box-sizing: border-box;
        }
        .search-box input:focus {
            outline: none;
            border-color: #007AFF;
        }
        .clear-search {
            position: absolute;
            right: 24px;
            top: 50%;
            transform: translateY(-50%);
            border: 1px solid #d1d5db;
            background: #f3f4f6;
            color: #111827;
            border-radius: 6px;
            padding: 4px 8px;
            font-size: 12px;
            cursor: pointer;
            display: none;
        }
        .clear-search.visible { display: inline-block; }
        .view-toggle {
            display: flex;
            gap: 10px;
            margin-bottom: 16px;
        }
        .toggle-btn {
            border: 1px solid #d1d5db;
            background: white;
            color: #374151;
            padding: 8px 14px;
            border-radius: 8px;
            font-size: 13px;
            cursor: pointer;
        }
        .toggle-btn.active {
            background: #007AFF;
            border-color: #007AFF;
            color: white;
        }
        .month-nav-btn {
            border: 1px solid #d1d5db;
            background: white;
            color: #374151;
            padding: 8px 14px;
            border-radius: 8px;
            font-size: 13px;
            cursor: pointer;
        }
        .month-view {
            background: white;
            border-radius: 12px;
            padding: 16px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .month-view.hidden {
            display: none;
        }
        .month-controls {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            align-items: center;
            margin-bottom: 12px;
        }
        .month-title {
            font-size: 20px;
            font-weight: 600;
            color: #111827;
            margin: 6px 0 12px;
        }
        .month-controls select {
            padding: 8px 12px;
            border-radius: 8px;
            border: 1px solid #d1d5db;
            font-size: 14px;
        }
        .month-grid {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 6px;
        }
        .month-header {
            font-weight: 600;
            font-size: 12px;
            color: #6b7280;
            text-transform: uppercase;
            text-align: center;
            padding: 6px 0;
        }
        .month-cell {
            min-height: 96px;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 6px;
            font-size: 12px;
            background: #fafafa;
            display: flex;
            flex-direction: column;
            gap: 4px;
            min-width: 0;
        }
        .month-cell .day {
            font-weight: 600;
            color: #111827;
        }
        .event-chip {
            padding: 3px 6px;
            border-radius: 6px;
            font-size: 11px;
            color: white;
            line-height: 1.3;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            max-width: 100%;
        }
        .month-chip-more {
            background: #6b7280;
            cursor: pointer;
        }
        .month-modal {
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, 0.55);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 9999;
        }
        .month-modal.visible {
            display: flex;
        }
        .month-modal-content {
            background: white;
            border-radius: 12px;
            padding: 20px;
            width: min(520px, 92vw);
            max-height: 80vh;
            overflow: auto;
            box-shadow: 0 10px 30px rgba(15, 23, 42, 0.2);
        }
        .month-modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
        }
        .month-modal-title {
            font-size: 16px;
            font-weight: 600;
            color: #111827;
        }
        .month-modal-close {
            border: none;
            background: #e5e7eb;
            color: #111827;
            border-radius: 999px;
            width: 28px;
            height: 28px;
            cursor: pointer;
            font-size: 16px;
            line-height: 1;
        }
        .month-modal-event {
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 10px 12px;
            margin-bottom: 8px;
            font-size: 13px;
            color: #374151;
        }
        .month-modal-event-title {
            font-weight: 600;
            margin-bottom: 4px;
        }
        .month-modal-event-time {
            font-size: 12px;
            color: #6b7280;
        }
        /* NEW: main content wrapper */
        .page-container {
            max-width: 1200px;
            margin: 20px auto;   /* center horizontally, space from top */
            padding: 0;
        }
        .event {
            background: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .highlight-target {
            background-color: #fff3cd;
            outline: 2px solid #f59e0b;
        }
        .event.hidden {
            display: none;
        }
        .event-title {
            font-size: 18px;
            font-weight: bold;
            color: #333;
            margin-bottom: 10px;
        }
        .event-meta {
            display: flex;
            gap: 10px;
            margin-bottom: 15px;
            flex-wrap: wrap;
        }
        .badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
            color: white;
        }
        .badge-calendar {
            background-color: #1BADF8;
        }
        .badge-allday {
            background-color: #999;
        }
        .badge-recurring {
            background-color: #666;
        }
        .event-details {
            border-top: 1px solid #eee;
            padding-top: 15px;
            margin-top: 15px;
        }
        .detail-row {
            margin-bottom: 10px;
        }
        .detail-label {
            font-weight: bold;
            color: #666;
            display: inline-block;
            width: 100px;
        }
        .detail-value {
            color: #333;
        }
        .description {
            background-color: #f9f9f9;
            padding: 15px;
            border-radius: 4px;
            margin-top: 10px;
            white-space: pre-wrap;
            font-size: 14px;
            line-height: 1.5;
        }
        .no-results {
            display: none;
            text-align: center;
            color: #999;
            font-size: 14px;
            margin: 20px 0 10px;
        }
        .no-results.visible {
            display: block;
        }
        @media print {
            body {
                background-color: white;
            }
            .event {
                box-shadow: none;
                border: 1px solid #ddd;
                page-break-inside: avoid;
            }
        }
    </style>
</head>
<body>
    <div class="page-container">
    <div class="header">
        <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Start_Here.html">Back</a></div>
        <h1>Calendar</h1>
        <p>Extracted from iOS Backup on """ + datetime.now().strftime("%B %d, %Y") + """</p>
        <div class="header-total">Total events: """ + f"{len(items):,}" + """</div>
    </div>
    <div class="view-toggle">
        <button class="toggle-btn active" data-view="list">List</button>
        <button class="toggle-btn" data-view="month">Month</button>
    </div>
    <div id="listView">
    <div class="search-box">
        <input type="text" id="searchInput" placeholder="Search events..." onkeyup="filterEvents()">
        <button id="clearSearch" class="clear-search" title="Clear" aria-label="Clear search">X</button>
    </div>
""")

                # Write each event
                for i, event in enumerate(items):
                    current = offset + i
                    if progress_callback:
                        if not progress_callback(current + 1, total, f"HTML: {event['summary']}"):
                            return False

                    # Determine calendar color
                    calendar_color = event['calendar_color'] if event['calendar_color'] else '#1BADF8'
                    start_date = self._format_timestamp(event['start_date'])
                    end_date = self._format_timestamp(event['end_date'])
                    search_parts = [
                        event['summary'],
                        event['calendar_name'],
                        event['location'] or '',
                        event['description'] or '',
                        start_date,
                        end_date
                    ]
                    search_blob = ' '.join([part for part in search_parts if part]).lower()

                    f.write(f"""    <div class="event" id="event-{event['event_id']}" data-search="{self._escape_html(search_blob)}">
        <div class="event-title">{self._escape_html(event['summary'])}</div>
        <div class="event-meta">
            <span class="badge badge-calendar" style="background-color: {calendar_color}">
                {self._escape_html(event['calendar_name'])}
            </span>
""")

                    if event['all_day']:
                        f.write('            <span class="badge badge-allday">All Day</span>\n')

                    if event['has_recurrence']:
                        f.write('            <span class="badge badge-recurring">Recurring</span>\n')

                    f.write('        </div>\n')
                    f.write('        <div class="event-details">\n')

                    # Start date
                    f.write(f'            <div class="detail-row">\n')
                    f.write(f'                <span class="detail-label">Start:</span>\n')
                    f.write(f'                <span class="detail-value">{start_date}</span>\n')
                    f.write(f'            </div>\n')

                    # End date
                    f.write(f'            <div class="detail-row">\n')
                    f.write(f'                <span class="detail-label">End:</span>\n')
                    f.write(f'                <span class="detail-value">{end_date}</span>\n')
                    f.write(f'            </div>\n')

                    # Location
                    if event['location']:
                        f.write(f'            <div class="detail-row">\n')
                        f.write(f'                <span class="detail-label">Location:</span>\n')
                        f.write(f'                <span class="detail-value">{self._escape_html(event["location"])}</span>\n')
                        f.write(f'            </div>\n')

                    # Has attendees
                    if event['has_attendees']:
                        f.write(f'            <div class="detail-row">\n')
                        f.write(f'                <span class="detail-label">Attendees:</span>\n')
                        f.write(f'                <span class="detail-value">Yes</span>\n')
                        f.write(f'            </div>\n')

                    # Description
                    if event['description']:
                        f.write(f'            <div class="detail-row">\n')
                        f.write(f'                <span class="detail-label">Description:</span>\n')
                        f.write(f'            </div>\n')
                        f.write(f'            <div class="description">{self._escape_html(event["description"])}</div>\n')

                    f.write('        </div>\n')
                    f.write('    </div>\n')

                # Write HTML footer
                f.write("""    <div class="no-results" id="noResults">No events found matching your search</div>
    </div>
    <div id="monthView" class="month-view hidden">
        <div class="month-controls">
            <button id="monthPrev" class="month-nav-btn">‹ Prev</button>
            <button id="monthNext" class="month-nav-btn">Next ›</button>
            <label for="monthSelect">Month:</label>
            <select id="monthSelect"></select>
        </div>
        <div id="monthTitle" class="month-title"></div>
        <div id="monthGrid" class="month-grid"></div>
    </div>
    <div id="monthModal" class="month-modal">
        <div class="month-modal-content">
            <div class="month-modal-header">
                <div id="monthModalTitle" class="month-modal-title"></div>
                <button id="monthModalClose" class="month-modal-close" aria-label="Close">×</button>
            </div>
            <div id="monthModalBody"></div>
        </div>
    </div>
</div>
<script>
const EVENTS = """)
                f.write(events_json)
                f.write(""";
const buttons = document.querySelectorAll('.toggle-btn[data-view]');
const listView = document.getElementById('listView');
const monthView = document.getElementById('monthView');
const monthSelect = document.getElementById('monthSelect');
const monthGrid = document.getElementById('monthGrid');
const monthTitle = document.getElementById('monthTitle');
const monthPrev = document.getElementById('monthPrev');
const monthNext = document.getElementById('monthNext');
const monthModal = document.getElementById('monthModal');
const monthModalTitle = document.getElementById('monthModalTitle');
const monthModalBody = document.getElementById('monthModalBody');
const monthModalClose = document.getElementById('monthModalClose');

function setActive(view) {
  buttons.forEach(btn => {
    btn.classList.toggle('active', btn.dataset.view === view);
  });
  if (listView) listView.style.display = view === 'list' ? '' : 'none';
  if (monthView) monthView.classList.toggle('hidden', view !== 'month');
}

function notifyPortrait() {
  try {
    try { localStorage.setItem('deviceOrientation', 'portrait'); } catch (err) {}
    if (window.parent && window.parent !== window) {
      if (typeof window.parent.__setDeviceOrientation === 'function') {
        window.parent.__setDeviceOrientation('portrait');
      }
      window.parent.postMessage({ type: 'device-rotate', mode: 'portrait' }, '*');
    }
    if (window.top && window.top !== window) {
      if (typeof window.top.__setDeviceOrientation === 'function') {
        window.top.__setDeviceOrientation('portrait');
      }
      window.top.postMessage({ type: 'device-rotate', mode: 'portrait' }, '*');
    }
  } catch (err) {}
}

function notifyLandscape() {
  try {
    try { localStorage.setItem('deviceOrientation', 'landscape'); } catch (err) {}
    if (window.parent && window.parent !== window) {
      if (typeof window.parent.__setDeviceOrientation === 'function') {
        window.parent.__setDeviceOrientation('landscape');
      }
      window.parent.postMessage({ type: 'device-rotate', mode: 'landscape' }, '*');
    }
    if (window.top && window.top !== window) {
      if (typeof window.top.__setDeviceOrientation === 'function') {
        window.top.__setDeviceOrientation('landscape');
      }
      window.top.postMessage({ type: 'device-rotate', mode: 'landscape' }, '*');
    }
  } catch (err) {}
}

function setViewHash(view) {
  try {
    window.location.hash = view ? '#' + view : '';
  } catch (err) {}
}

function formatMonthLabel(monthKey) {
  if (!monthKey) return '';
  const [year, month] = monthKey.split('-').map(Number);
  const date = new Date(year, month - 1, 1);
  return date.toLocaleString(undefined, { month: 'long', year: 'numeric' });
}

  function eventKey(ev) {
    return ev.start_key || ev.start_date || '';
  }

  function buildMonthOptions() {
    if (!monthSelect) return;
    const months = Array.from(new Set(EVENTS.map(e => eventKey(e).slice(0,7)).filter(Boolean))).sort();
    monthSelect.innerHTML = '';
    months.forEach(m => {
      const opt = document.createElement('option');
    opt.value = m;
    opt.textContent = m;
    monthSelect.appendChild(opt);
  });
  const now = new Date();
  const currentKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2,'0')}`;
  if (months.length) {
    monthSelect.value = months.includes(currentKey) ? currentKey : months[months.length - 1];
    renderMonth(monthSelect.value);
  } else {
    monthSelect.value = currentKey;
    renderMonth(currentKey);
  }
}

function stepMonth(step) {
  if (!monthSelect || !monthSelect.options.length) return;
  const idx = monthSelect.selectedIndex;
  const next = Math.min(Math.max(idx + step, 0), monthSelect.options.length - 1);
  monthSelect.selectedIndex = next;
  renderMonth(monthSelect.value);
}

  function renderMonth(monthKey) {
    if (!monthGrid) return;
    monthGrid.innerHTML = '';
    if (monthTitle) monthTitle.textContent = formatMonthLabel(monthKey);
  const [year, month] = monthKey.split('-').map(Number);
  const first = new Date(year, month - 1, 1);
  const last = new Date(year, month, 0);
  const startDay = first.getDay();
  const daysInMonth = last.getDate();
  const headers = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  headers.forEach(h => {
    const el = document.createElement('div');
    el.className = 'month-header';
    el.textContent = h;
    monthGrid.appendChild(el);
  });
  for (let i = 0; i < startDay; i++) {
    const pad = document.createElement('div');
    pad.className = 'month-cell';
    pad.style.visibility = 'hidden';
    monthGrid.appendChild(pad);
  }
    for (let day = 1; day <= daysInMonth; day++) {
      const dateKey = `${year}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
      const cell = document.createElement('div');
      cell.className = 'month-cell';
    const dayEl = document.createElement('div');
    dayEl.className = 'day';
    dayEl.textContent = day;
    cell.appendChild(dayEl);
    const dayEvents = EVENTS.filter(e => eventKey(e) === dateKey);
    dayEvents.slice(0, 3).forEach(ev => {
      const chip = document.createElement('div');
      chip.className = 'event-chip';
      chip.style.background = ev.color || '#1BADF8';
      const time = ev.all_day ? '' : (ev.start_time ? ev.start_time + ' ' : '');
      chip.textContent = (time + ev.title).trim();
      cell.appendChild(chip);
    });
    if (dayEvents.length > 3) {
      const more = document.createElement('div');
      more.className = 'event-chip month-chip-more';
      more.textContent = `+${dayEvents.length - 3} more`;
      more.addEventListener('click', () => showMonthDetails(dateKey, dayEvents));
      cell.appendChild(more);
    }
    monthGrid.appendChild(cell);
  }
}

function showMonthDetails(dateKey, dayEvents) {
  if (!monthModal || !monthModalBody) return;
  const [year, month, day] = dateKey.split('-').map(Number);
  const date = new Date(year, month - 1, day);
  if (monthModalTitle) {
    monthModalTitle.textContent = date.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
  }
  monthModalBody.innerHTML = '';
  dayEvents.forEach(ev => {
    const row = document.createElement('div');
    row.className = 'month-modal-event';
    const title = document.createElement('div');
    title.className = 'month-modal-event-title';
    title.textContent = ev.title || 'Untitled Event';
    const time = document.createElement('div');
    time.className = 'month-modal-event-time';
    const start = ev.all_day ? 'All Day' : `${ev.start_date} ${ev.start_time || ''}`.trim();
    const end = ev.end_date ? ` → ${ev.end_date} ${ev.end_time || ''}`.trim() : '';
    time.textContent = `${start}${end}`;
    row.appendChild(title);
    row.appendChild(time);
    monthModalBody.appendChild(row);
  });
  monthModal.classList.add('visible');
}

if (monthModalClose) {
  monthModalClose.addEventListener('click', () => {
    monthModal.classList.remove('visible');
  });
}
if (monthModal) {
  monthModal.addEventListener('click', (event) => {
    if (event.target === monthModal) {
      monthModal.classList.remove('visible');
    }
  });
}

if (monthSelect) {
  monthSelect.addEventListener('change', () => renderMonth(monthSelect.value));
}
if (monthPrev) {
  monthPrev.addEventListener('click', () => stepMonth(-1));
}
if (monthNext) {
  monthNext.addEventListener('click', () => stepMonth(1));
}
buttons.forEach(btn => {
  btn.addEventListener('click', () => {
    setActive(btn.dataset.view);
    if (btn.dataset.view === 'month') {
      buildMonthOptions();
      notifyLandscape();
      setViewHash('month');
    } else {
      notifyPortrait();
      setViewHash('list');
    }
  });
});

// Default to month view on load (no orientation change here).
setActive('month');
buildMonthOptions();
setViewHash('month');

    function filterEvents() {
        const input = document.getElementById('searchInput');
        const filter = input.value.toLowerCase();
        const events = document.querySelectorAll('.event');
        const noResults = document.getElementById('noResults');
        let visibleCount = 0;

        events.forEach(eventEl => {
            const haystack = eventEl.getAttribute('data-search') || '';
            if (!filter || haystack.includes(filter)) {
                eventEl.classList.remove('hidden');
                visibleCount += 1;
            } else {
                eventEl.classList.add('hidden');
            }
        });

        if (noResults) {
            if (!visibleCount && filter) {
                noResults.classList.add('visible');
            } else {
                noResults.classList.remove('visible');
            }
        }
    }
</script>
<script>
    const calSearchInput = document.getElementById('searchInput');
    const calClearBtn = document.getElementById('clearSearch');
    if (calSearchInput && calClearBtn) {
        const toggleClear = () => calClearBtn.classList.toggle('visible', !!calSearchInput.value);
        calSearchInput.addEventListener('input', toggleClear);
        calClearBtn.addEventListener('click', () => {
            calSearchInput.value = '';
            toggleClear();
            if (typeof filterEvents === 'function') {
                filterEvents();
            }
            calSearchInput.focus();
        });
        toggleClear();
    }
</script>
<script>
    (function() {
        if (!window.location.hash) return;
        const target = document.querySelector(window.location.hash);
        if (!target) return;
        target.classList.add('highlight-target');
        try {
            target.scrollIntoView({ block: 'center' });
        } catch (e) {
            target.scrollIntoView();
        }
    })();
</script>
<script>
    if (window.self !== window.top) {
        document.body.classList.add('embedded');
    }
</script>
</body>
</html>
""")

            return True

        except Exception as e:
            print(f"Error exporting HTML: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _export_csv(self, items: List[Dict[str, Any]], csv_file: str,
                    progress_callback, offset: int, total: int) -> bool:
        """Export calendar events to CSV format."""
        try:
            import csv

            with open(csv_file, 'w', encoding='utf-8', newline='') as f:
                writer = csv.writer(f)

                # Write header
                writer.writerow([
                    'Summary',
                    'Calendar',
                    'Start Date',
                    'End Date',
                    'All Day',
                    'Location',
                    'Description',
                    'Recurring',
                    'Has Attendees'
                ])

                # Write each event
                for i, event in enumerate(items):
                    current = offset + i
                    if progress_callback:
                        if not progress_callback(current + 1, total, f"CSV: {event['summary']}"):
                            return False

                    writer.writerow([
                        event['summary'],
                        event['calendar_name'],
                        self._format_timestamp(event['start_date']),
                        self._format_timestamp(event['end_date']),
                        'Yes' if event['all_day'] else 'No',
                        event['location'] or '',
                        event['description'] or '',
                        'Yes' if event['has_recurrence'] else 'No',
                        'Yes' if event['has_attendees'] else 'No'
                    ])

            return True

        except Exception as e:
            print(f"Error exporting CSV: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _escape_html(self, text: str) -> str:
        """Escape HTML special characters."""
        if not text:
            return ""
        text = text.replace('&', '&amp;')
        text = text.replace('<', '&lt;')
        text = text.replace('>', '&gt;')
        text = text.replace('"', '&quot;')
        text = text.replace("'", '&#39;')
        return text
