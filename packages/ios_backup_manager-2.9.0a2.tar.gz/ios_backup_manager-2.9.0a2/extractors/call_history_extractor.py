#!/usr/bin/env python3
"""
Call History data extractor for iOS backups.

Extracts call history from CallHistory.storedata and exports to CSV and HTML formats.
Note: Call history is not always present in iOS backups (often syncs via iCloud).
"""

import sqlite3
import os
from typing import List, Dict, Any, Optional
from datetime import datetime, timezone
from .base import CategoryDataExtractor


class CallHistoryExtractor(CategoryDataExtractor):
    """Extract and export call history from iOS backup."""

    def __init__(self, backup_path: str):
        super().__init__(backup_path)

        # Try CallHistory.storedata first (iOS 8+)
        self.call_db_path = self.find_db_file(
            "HomeDomain",
            "Library/CallHistoryDB/CallHistory.storedata"
        )

        if self.call_db_path:
            # Core Data format - use ZCALLRECORD table
            self.call_table_name = "ZCALLRECORD"
            self.db_format = "coredata"
        else:
            # Try sms.db as fallback (older iOS versions)
            self.call_db_path = self.find_db_file(
                "HomeDomain",
                "Library/SMS/sms.db"
            )

            if not self.call_db_path:
                raise FileNotFoundError("Call history database not found in backup")

            # Check if call table exists in sms.db
            conn = sqlite3.connect(self.call_db_path)
            cur = conn.cursor()
            cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name IN ('call', 'call_history')")
            result = cur.fetchone()
            conn.close()

            if not result:
                raise FileNotFoundError("Call history table not found in backup (may not be backed up)")

            self.call_table_name = result[0]
            self.db_format = "sms"

    def get_count(self) -> int:
        """Get total number of call records."""
        conn = sqlite3.connect(self.call_db_path)
        cur = conn.cursor()

        cur.execute(f"SELECT COUNT(*) FROM {self.call_table_name}")
        count = cur.fetchone()[0]

        conn.close()
        return count

    def get_items(self, limit: Optional[int] = None, offset: int = 0,
                  search: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get call history records with pagination and optional search.

        Returns list of call dictionaries with fields:
        - call_id: Call record ID
        - address: Phone number or contact identifier
        - date: Call date/time
        - duration: Call duration in seconds
        - call_type: Incoming, Outgoing, or Missed
        - service: Phone, FaceTime Audio, or FaceTime Video
        - read: Whether call has been viewed
        - contact_name: Contact name (if available)
        - location: Location information (if available)
        """
        conn = sqlite3.connect(self.call_db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        calls = []

        if self.db_format == "coredata":
            # Core Data format (CallHistory.storedata)
            calls = self._get_items_coredata(cur, limit, offset, search)
        else:
            # sms.db format (older iOS)
            calls = self._get_items_sms(cur, limit, offset, search)

        conn.close()
        return calls

    def _get_items_coredata(self, cur, limit, offset, search):
        """Get items from Core Data format (ZCALLRECORD)."""
        query = f"""
            SELECT
                Z_PK as call_id,
                ZADDRESS as address,
                ZDATE as date,
                ZDURATION as duration,
                ZCALLTYPE as call_type,
                ZORIGINATED as originated,
                ZANSWERED as answered,
                ZSERVICE_PROVIDER as service_provider,
                ZREAD as read,
                ZNAME as contact_name,
                ZLOCATION as location
            FROM {self.call_table_name}
            WHERE 1=1
        """
        params = []

        if search:
            # Search in address (need to handle BLOB) and name
            query += " AND (ZNAME LIKE ? OR CAST(ZADDRESS AS TEXT) LIKE ?)"
            search_pattern = f"%{search}%"
            params.extend([search_pattern, search_pattern])

        query += " ORDER BY ZDATE DESC"

        if limit is not None:
            query += f" LIMIT {limit} OFFSET {offset}"

        try:
            cur.execute(query, params)
            rows = cur.fetchall()
        except sqlite3.OperationalError as e:
            print(f"Warning: Call history schema mismatch: {e}")
            return []

        calls = []
        for row in rows:
            # Decode address from BLOB
            address_blob = row['address']
            if address_blob:
                try:
                    address = address_blob.decode('utf-8', errors='ignore').strip()
                    # Clean up non-breaking spaces and formatting
                    address = address.replace('\xc2\xa0', ' ').replace('\xa0', ' ')
                except:
                    address = str(address_blob)
            else:
                address = 'Unknown'

            # Determine call type
            # ZCALLTYPE: 1 = regular call, 8 = FaceTime, 16 = other?
            # ZORIGINATED: 1 = outgoing, 0/NULL = incoming
            # ZANSWERED: 1 = answered, 0/NULL = not answered
            originated = row['originated']
            answered = row['answered']

            if originated:
                call_type = "Outgoing"
            elif answered:
                call_type = "Incoming"
            else:
                call_type = "Missed"

            # Determine service type
            service_provider = row['service_provider']
            call_type_code = row['call_type']

            if service_provider and 'FaceTime' in service_provider:
                if call_type_code == 8:
                    service_name = "FaceTime Audio"
                else:
                    service_name = "FaceTime Video"
            else:
                service_name = "Phone"

            call = {
                'call_id': row['call_id'],
                'address': address,
                'date': row['date'],
                'duration': row['duration'] if row['duration'] else 0,
                'call_type': call_type,
                'service': service_name,
                'read': bool(row['read']) if row['read'] else True,
                'contact_name': row['contact_name'],
                'location': row['location']
            }
            calls.append(call)

        return calls

    def _get_items_sms(self, cur, limit, offset, search):
        """Get items from sms.db format (older iOS)."""
        query = f"""
            SELECT
                ROWID as call_id,
                address,
                date,
                duration,
                flags,
                service,
                read
            FROM {self.call_table_name}
            WHERE 1=1
        """
        params = []

        if search:
            query += " AND (address LIKE ?)"
            search_pattern = f"%{search}%"
            params.append(search_pattern)

        query += " ORDER BY date DESC"

        if limit is not None:
            query += f" LIMIT {limit} OFFSET {offset}"

        try:
            cur.execute(query, params)
            rows = cur.fetchall()
        except sqlite3.OperationalError as e:
            print(f"Warning: Call history schema mismatch: {e}")
            return []

        calls = []
        for row in rows:
            # Determine call type from flags
            # flags: 4 = outgoing, 5 = incoming, others may indicate missed/cancelled
            flags = row['flags'] if 'flags' in row.keys() else 0
            if flags == 4:
                call_type = "Outgoing"
            elif flags == 5:
                call_type = "Incoming"
            elif flags in [1, 2, 3]:
                call_type = "Missed"
            else:
                call_type = f"Unknown ({flags})"

            # Determine service type
            service = row['service'] if 'service' in row.keys() else None
            if service:
                if 'FaceTime' in service:
                    if 'Video' in service:
                        service_name = "FaceTime Video"
                    else:
                        service_name = "FaceTime Audio"
                else:
                    service_name = "Phone"
            else:
                service_name = "Phone"

            call = {
                'call_id': row['call_id'],
                'address': row['address'] or 'Unknown',
                'date': row['date'],
                'duration': row['duration'] if row['duration'] else 0,
                'call_type': call_type,
                'service': service_name,
                'read': bool(row['read']) if 'read' in row.keys() else True,
                'contact_name': None,
                'location': None
            }
            calls.append(call)

        return calls

    def export(self, items: List[Dict[str, Any]], output_path: str,
               format: str = 'csv', progress_callback=None, timeline_emitter=None) -> bool:
        """
        Export call history to CSV and HTML formats.

        Args:
            items: List of calls to export
            output_path: Output directory or file path
            format: Export format ('csv' - exports both CSV and HTML)
            progress_callback: Optional callback(current, total, item_name) -> bool

        Returns:
            True if export succeeded
        """
        try:
            self._reset_export_bytes()
            # Determine output directory and base filename
            if os.path.isdir(output_path):
                output_dir = output_path
                base_name = 'call_history_export'
            else:
                output_dir = os.path.dirname(output_path)
                base_name = os.path.splitext(os.path.basename(output_path))[0]

            os.makedirs(output_dir, exist_ok=True)

            if timeline_emitter is not None:
                self._emit_timeline_events(items, timeline_emitter)

            # Export to both formats
            total = len(items) * 2  # 2 formats
            current = 0

            # 1. Export CSV
            csv_file = os.path.join(output_dir, f'{base_name}.csv')
            if not self._export_csv(items, csv_file, progress_callback, 0, total):
                return False

            # 2. Export HTML
            html_file = os.path.join(output_dir, 'Call_History.html')
            if not self._export_html(items, html_file, progress_callback, len(items), total):
                return False

            self._add_export_bytes(csv_file)
            self._add_export_bytes(html_file)

            return True

        except Exception as e:
            print(f"Error exporting call history: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _export_csv(self, items: List[Dict[str, Any]], csv_file: str,
                    progress_callback, offset: int, total: int) -> bool:
        """Export call history to CSV format."""
        try:
            import csv

            with open(csv_file, 'w', encoding='utf-8', newline='') as f:
                writer = csv.writer(f)

                # Write header
                writer.writerow([
                    'Date',
                    'Phone Number',
                    'Contact Name',
                    'Call Type',
                    'Service',
                    'Duration',
                    'Location',
                    'Read'
                ])

                # Write each call
                for i, call in enumerate(items):
                    current = offset + i
                    if progress_callback:
                        if not progress_callback(current + 1, total, f"CSV: {call['address']}"):
                            return False

                    writer.writerow([
                        self._format_timestamp(call['date']),
                        call['address'],
                        call.get('contact_name') or '',
                        call['call_type'],
                        call['service'],
                        self._format_duration(call['duration']),
                        call.get('location') or '',
                        'Yes' if call['read'] else 'No'
                    ])

            return True

        except Exception as e:
            print(f"Error exporting CSV: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _export_html(self, items: List[Dict[str, Any]], html_file: str,
                     progress_callback, offset: int, total: int) -> bool:
        """Export call history to HTML format."""
        try:
            with open(html_file, 'w', encoding='utf-8') as f:
                # Write HTML header
                f.write("""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Call History</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;
            margin: 20px;
            background-color: #f5f5f5;
        }
        .header {
            background: linear-gradient(135deg, #536976 0%, #BBD2C5 100%);
            color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .header h1 {
            margin: 0 0 10px 0;
            font-size: 32px;
            font-weight: 600;
        }
        .breadcrumbs {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            letter-spacing: 0.2px;
            color: rgba(255,255,255,0.85);
            margin-bottom: 10px;
        }
        .breadcrumbs a {
            color: #fff;
            text-decoration: none;
            font-weight: 600;
        }
        .breadcrumbs a:hover {
            text-decoration: underline;
        }
        .breadcrumbs .back-arrow {
            opacity: 0.6;
        }
        .embedded .breadcrumbs {
            display: none;
        }
        .header p {
            margin: 0;
            font-size: 16px;
            opacity: 0.9;
        }
        .header-total {
            margin-top: 8px;
            font-size: 14px;
            opacity: 0.85;
        }
        .export-info {
            color: #666;
            font-size: 14px;
            margin-bottom: 30px;
        }
        /* NEW: main content wrapper */
        .page-container {
            max-width: 1200px;
            margin: 20px auto;   /* center horizontally, space from top */
            padding: 0 20px;     /* same feel as old body margin */
        }
        .table-wrap {
            overflow-x: auto;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            background: white;
        }
        table {
            width: 100%;
            background: white;
            border-collapse: collapse;
            min-width: 900px;
            table-layout: fixed;
        }
        th {
            background-color: #007AFF;
            color: white;
            padding: 12px;
            text-align: left;
            font-weight: 600;
        }
        td {
            padding: 12px;
            border-bottom: 1px solid #eee;
            overflow-wrap: anywhere;
            word-break: break-word;
        }
        th.col-phone,
        td.col-phone,
        th:nth-child(2),
        td:nth-child(2) {
            width: 180px;
        }
        th.col-contact,
        td.col-contact,
        th:nth-child(3),
        td:nth-child(3) {
            width: 180px;
        }
        th.col-location,
        td.col-location,
        th:nth-child(7),
        td:nth-child(7) {
            width: 200px;
        }
        tr:last-child td {
            border-bottom: none;
        }
        tr:hover {
            background-color: #f9f9f9;
        }
        .call-incoming {
            color: #34C759;
        }
        .call-outgoing {
            color: #007AFF;
        }
        .call-missed {
            color: #FF3B30;
        }
        .service-badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 500;
            background-color: #E5E5EA;
            color: #333;
        }
        tr:target,
        tr.highlight-row {
            background-color: #fff3cd;
            outline: 2px solid #f59e0b;
        }
        tr.highlight-row td {
            background-color: #fff3cd;
        }
        @media (max-width: 1100px) {
            body {
                margin: 12px;
            }
            .page-container {
                padding: 0 12px;
            }
            th, td {
                padding: 8px;
                font-size: 12px;
            }
            .export-info {
                margin-bottom: 18px;
            }
        }
        @media print {
            body {
                background-color: white;
            }
            table {
                box-shadow: none;
            }
        }
    </style>
</head>
<body>
    <div class="page-container">
    <div class="header">
        <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Start_Here.html">Back</a></div>
        <h1>Call History</h1>
        <p>Extracted from iOS Backup on """ + datetime.now().strftime("%B %d, %Y") + """</p>
        <div class="header-total">Total calls: """ + f"{len(items):,}" + """</div>
    </div>
    <div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th class="col-phone">Phone Number</th>
                <th class="col-contact">Contact</th>
                <th>Type</th>
                <th>Service</th>
                <th>Duration</th>
                <th class="col-location">Location</th>
            </tr>
        </thead>
        <tbody>
""")

                # Write each call
                for i, call in enumerate(items):
                    current = offset + i
                    if progress_callback:
                        if not progress_callback(current + 1, total, f"HTML: {call['address']}"):
                            return False

                    # Determine call type class for color
                    call_class = ""
                    if "Incoming" in call['call_type']:
                        call_class = "call-incoming"
                    elif "Outgoing" in call['call_type']:
                        call_class = "call-outgoing"
                    elif "Missed" in call['call_type']:
                        call_class = "call-missed"

                    contact_name = call.get('contact_name') or ''
                    location = call.get('location') or ''

                    row_id = f"call-{call.get('call_id', current)}"
                    f.write(f"""            <tr id="{self._escape_html(row_id)}">
                <td>{self._escape_html(self._format_timestamp(call['date']))}</td>
                <td class="col-phone">{self._escape_html(call['address'])}</td>
                <td class="col-contact">{self._escape_html(contact_name)}</td>
                <td class="{call_class}">{self._escape_html(call['call_type'])}</td>
                <td><span class="service-badge">{self._escape_html(call['service'])}</span></td>
                <td>{self._escape_html(self._format_duration(call['duration']))}</td>
                <td class="col-location">{self._escape_html(location)}</td>
            </tr>
""")

                # Write HTML footer
                f.write("""        </tbody>
    </table>
    </div>
</div>
<script>
    (function() {
        if (!window.location.hash) return;
        const row = document.querySelector(window.location.hash);
        if (!row) return;
        row.classList.add('highlight-row');
        try {
            row.scrollIntoView({ block: 'center' });
        } catch (e) {
            row.scrollIntoView();
        }
    })();
</script>
<script>
    if (window.self !== window.top) {
        document.body.classList.add('embedded');
    }
</script>
</body>
</html>
""")

            return True

        except Exception as e:
            print(f"Error exporting HTML: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _format_timestamp(self, timestamp: Optional[float]) -> str:
        """Format Apple Core Data timestamp for display."""
        if timestamp is None:
            return "N/A"

        try:
            # Apple Core Data timestamp is seconds since 2001-01-01
            apple_epoch = datetime(2001, 1, 1, tzinfo=timezone.utc).timestamp()
            unix_timestamp = apple_epoch + timestamp
            dt = datetime.fromtimestamp(unix_timestamp)
            return dt.strftime("%m-%d-%Y %I:%M:%S %p")
        except:
            return str(timestamp)

    def _format_timestamp_iso(self, timestamp: Optional[float]) -> Optional[str]:
        if timestamp is None:
            return None
        try:
            apple_epoch = datetime(2001, 1, 1, tzinfo=timezone.utc).timestamp()
            unix_timestamp = apple_epoch + timestamp
            dt = datetime.fromtimestamp(unix_timestamp, tz=timezone.utc)
            return dt.isoformat()
        except Exception:
            return None

    def _emit_timeline_events(self, items: List[Dict[str, Any]], emitter) -> None:
        for call in items:
            raw_timestamp = call.get('date')
            timestamp_utc = self._format_timestamp_iso(raw_timestamp)
            timestamp_display = self._format_timestamp(raw_timestamp)
            if not timestamp_utc and not timestamp_display:
                continue
            address = call.get('address', 'Unknown')
            details = {
                "address": address,
                "duration": call.get('duration', 0),
                "call_type": call.get('call_type', ''),
                "service": call.get('service', ''),
            }
            emitter.emit({
                "timestamp": timestamp_display if timestamp_display != "N/A" else (timestamp_utc or ""),
                "timestamp_display": timestamp_display if timestamp_display != "N/A" else (timestamp_utc or ""),
                "timestamp_utc": timestamp_utc or "",
                "raw_timestamp": raw_timestamp,
                "raw_format": "apple_coredata_seconds",
                "source_app": "Phone",
                "source_category": "Call History",
                "event_type": "call",
                "title": f"Call {address}",
                "details": details,
                "confidence": "high",
                "raw_source_path": getattr(self, 'call_history_db_path', '') or '',
                "report_anchor": f"call-{call.get('call_id', '')}",
                "link_hint": "Call History/Call_History.html",
            })

    def _format_duration(self, seconds: Optional[float]) -> str:
        """Format call duration in seconds to human-readable string."""
        if seconds is None or seconds == 0:
            return "0s"

        seconds = int(seconds)
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        secs = seconds % 60

        parts = []
        if hours > 0:
            parts.append(f"{hours}h")
        if minutes > 0:
            parts.append(f"{minutes}m")
        if secs > 0 or len(parts) == 0:
            parts.append(f"{secs}s")

        return " ".join(parts)

    def _escape_html(self, text: str) -> str:
        """Escape HTML special characters."""
        if not text:
            return ""
        text = str(text)
        text = text.replace('&', '&amp;')
        text = text.replace('<', '&lt;')
        text = text.replace('>', '&gt;')
        text = text.replace('"', '&quot;')
        text = text.replace("'", '&#39;')
        return text

    def get_item_summary(self, item: Dict[str, Any]) -> str:
        """Get short summary for list view."""
        address = item['address']
        date_str = self._format_timestamp(item['date'])

        return f"{item['call_type']}: {address} ({date_str})"
