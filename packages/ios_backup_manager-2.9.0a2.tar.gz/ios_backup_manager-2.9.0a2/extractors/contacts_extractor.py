#!/usr/bin/env python3
"""
Contacts data extractor for iOS backups.

Extracts contact information from AddressBook.sqlitedb and supports
export to vCard (.vcf) format.
"""

import sqlite3
import os
from datetime import datetime
from typing import List, Dict, Any, Optional
from .base import CategoryDataExtractor


class ContactsExtractor(CategoryDataExtractor):
    """Extract and export contacts from iOS backup."""

    def __init__(self, backup_path: str):
        super().__init__(backup_path)

        # Find AddressBook database
        self.contacts_db_path = self.find_db_file(
            "HomeDomain",
            "Library/AddressBook/AddressBook.sqlitedb"
        )

        if not self.contacts_db_path:
            raise FileNotFoundError("AddressBook.sqlitedb not found in backup")

    def get_count(self) -> int:
        """Get total number of contacts."""
        conn = sqlite3.connect(self.contacts_db_path)
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM ABPerson")
        count = cur.fetchone()[0]
        conn.close()
        return count

    def get_items(self, limit: Optional[int] = None, offset: int = 0,
                  search: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get contacts with pagination and optional search.

        Returns list of contact dictionaries with fields:
        - rowid: Contact ID
        - first_name: First name
        - last_name: Last name
        - organization: Company/organization
        - phones: List of phone numbers
        - emails: List of email addresses
        - addresses: List of postal addresses
        """
        conn = sqlite3.connect(self.contacts_db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        # Build query with optional search
        query = "SELECT ROWID, First, Last, Organization, Birthday, CreationDate, ModificationDate FROM ABPerson"
        params = []

        if search:
            # Search in first name, last name, or organization
            query += " WHERE First LIKE ? OR Last LIKE ? OR Organization LIKE ?"
            search_pattern = f"%{search}%"
            params.extend([search_pattern, search_pattern, search_pattern])

        query += " ORDER BY Last, First"

        if limit is not None:
            query += f" LIMIT {limit} OFFSET {offset}"

        cur.execute(query, params)
        persons = cur.fetchall()

        contacts = []
        for person in persons:
            contact = {
                'rowid': person['ROWID'],
                'first_name': person['First'] or '',
                'last_name': person['Last'] or '',
                'organization': person['Organization'] or '',
                'birthday': person['Birthday'],
                'created': person['CreationDate'],
                'modified': person['ModificationDate'],
                'phones': [],
                'emails': [],
                'addresses': []
            }

            # Get phone numbers
            cur.execute("""
                SELECT value, label FROM ABMultiValue
                WHERE record_id = ? AND property = 3
                ORDER BY UID
            """, (person['ROWID'],))
            contact['phones'] = [
                {'value': row[0], 'label': self._format_label(row[1])}
                for row in cur.fetchall()
            ]

            # Get email addresses
            cur.execute("""
                SELECT value, label FROM ABMultiValue
                WHERE record_id = ? AND property = 4
                ORDER BY UID
            """, (person['ROWID'],))
            contact['emails'] = [
                {'value': row[0], 'label': self._format_label(row[1])}
                for row in cur.fetchall()
            ]

            # Get addresses
            cur.execute("""
                SELECT value, label FROM ABMultiValue
                WHERE record_id = ? AND property = 5
                ORDER BY UID
            """, (person['ROWID'],))
            for row in cur.fetchall():
                # Address is stored as plist XML string
                address_value = row[0]
                if address_value:
                    contact['addresses'].append({
                        'value': address_value,
                        'label': self._format_label(row[1])
                    })

            contacts.append(contact)

        conn.close()
        return contacts

    def get_item_summary(self, item: Dict[str, Any]) -> str:
        """Get summary string for contact list view."""
        name_parts = []

        if item['first_name']:
            name_parts.append(item['first_name'])
        if item['last_name']:
            name_parts.append(item['last_name'])

        if name_parts:
            name = ' '.join(name_parts)
        elif item['organization']:
            name = item['organization']
        else:
            name = "(No Name)"

        # Add primary phone or email if available
        details = []
        if item['phones']:
            details.append(item['phones'][0]['value'])
        elif item['emails']:
            details.append(item['emails'][0]['value'])

        if details:
            return f"{name} - {details[0]}"
        return name

    def export(self, items: List[Dict[str, Any]], output_path: str,
               format: str = 'vcf', progress_callback=None, timeline_emitter=None) -> bool:
        """
        Export contacts to VCF, CSV, and HTML formats.

        Args:
            items: List of contacts to export
            output_path: Output file path or directory
            format: 'vcf' (exports all three formats: VCF, CSV, HTML)
            progress_callback: Optional callback function(current, total, item_name) -> bool
                              Returns False to cancel export

        Returns:
            True if export succeeded
        """
        try:
            self._reset_export_bytes()
            # Determine output directory and base filename
            if os.path.isdir(output_path):
                output_dir = output_path
                base_name = 'contacts_export'
            else:
                output_dir = os.path.dirname(output_path)
                base_name = os.path.splitext(os.path.basename(output_path))[0]

            os.makedirs(output_dir, exist_ok=True)

            # Export to all three formats
            total = len(items) * 3  # 3 formats
            current = 0

            # 1. Export VCF
            vcf_file = os.path.join(output_dir, f'{base_name}.vcf')
            if not self._export_vcf(items, vcf_file, progress_callback, 0, total):
                return False

            # 2. Export CSV
            csv_file = os.path.join(output_dir, f'{base_name}.csv')
            if not self._export_csv(items, csv_file, progress_callback, len(items), total):
                return False

            # 3. Export HTML
            html_file = os.path.join(output_dir, 'Contacts.html')
            if not self._export_html(items, html_file, progress_callback, len(items) * 2, total):
                return False

            if timeline_emitter is not None:
                self._emit_timeline_events(items, timeline_emitter)

            self._add_export_bytes(vcf_file)
            self._add_export_bytes(csv_file)
            self._add_export_bytes(html_file)

            return True

        except Exception as e:
            print(f"Error exporting contacts: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _export_vcf(self, items: List[Dict[str, Any]], vcf_file: str,
                    progress_callback, offset: int, total: int) -> bool:
        """Export contacts to vCard format."""
        try:
            with open(vcf_file, 'w', encoding='utf-8') as f:
                for i, contact in enumerate(items):
                    current = offset + i
                    if progress_callback:
                        contact_name = ' '.join([
                            contact['first_name'] or '',
                            contact['last_name'] or ''
                        ]).strip() or contact['organization'] or f"Contact {i+1}"

                        if not progress_callback(current + 1, total, f"VCF: {contact_name}"):
                            return False

                    # Write vCard 3.0 format
                    f.write("BEGIN:VCARD\n")
                    f.write("VERSION:3.0\n")

                    # Name
                    last = contact['last_name'] or ''
                    first = contact['first_name'] or ''
                    f.write(f"N:{last};{first};;;\n")

                    # Full name
                    full_name = ' '.join([first, last]).strip()
                    if full_name:
                        f.write(f"FN:{full_name}\n")
                    elif contact['organization']:
                        f.write(f"FN:{contact['organization']}\n")

                    # Organization
                    if contact['organization']:
                        f.write(f"ORG:{contact['organization']}\n")

                    # Phone numbers
                    for phone in contact['phones']:
                        phone_type = phone['label'].upper() if phone['label'] else 'VOICE'
                        f.write(f"TEL;TYPE={phone_type}:{phone['value']}\n")

                    # Email addresses
                    for email in contact['emails']:
                        email_type = email['label'].upper() if email['label'] else 'INTERNET'
                        f.write(f"EMAIL;TYPE={email_type}:{email['value']}\n")

                    # Addresses
                    for j, addr in enumerate(contact['addresses']):
                        addr_type = addr['label'].upper() if addr['label'] else 'HOME'
                        f.write(f"NOTE:Address {j+1} ({addr_type}): See original backup\n")

                    f.write("END:VCARD\n")

            return True

        except Exception as e:
            print(f"Error exporting VCF: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _export_csv(self, items: List[Dict[str, Any]], csv_file: str,
                    progress_callback, offset: int, total: int) -> bool:
        """Export contacts to CSV format."""
        try:
            import csv

            with open(csv_file, 'w', encoding='utf-8', newline='') as f:
                writer = csv.writer(f)

                # Write header
                writer.writerow([
                    'First Name',
                    'Last Name',
                    'Organization',
                    'Phone Numbers',
                    'Email Addresses',
                    'Number of Addresses'
                ])

                # Write each contact
                for i, contact in enumerate(items):
                    current = offset + i
                    if progress_callback:
                        contact_name = ' '.join([
                            contact['first_name'] or '',
                            contact['last_name'] or ''
                        ]).strip() or contact['organization'] or f"Contact {i+1}"

                        if not progress_callback(current + 1, total, f"CSV: {contact_name}"):
                            return False

                    # Format phone numbers
                    phones = '; '.join([
                        f"{p['value']} ({p['label'] or 'Phone'})"
                        for p in contact['phones']
                    ])

                    # Format emails
                    emails = '; '.join([
                        f"{e['value']} ({e['label'] or 'Email'})"
                        for e in contact['emails']
                    ])

                    writer.writerow([
                        contact['first_name'] or '',
                        contact['last_name'] or '',
                        contact['organization'] or '',
                        phones,
                        emails,
                        len(contact['addresses'])
                    ])

            return True

        except Exception as e:
            print(f"Error exporting CSV: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _export_html(self, items: List[Dict[str, Any]], html_file: str,
                     progress_callback, offset: int, total: int) -> bool:
        """Export contacts to HTML format."""
        try:
            from datetime import datetime

            with open(html_file, 'w', encoding='utf-8') as f:
                # Write HTML header
                f.write("""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contacts</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;
            margin: 20px;
            background-color: #f5f5f5;
        }
        .header {
            background: linear-gradient(135deg, #283048 0%, #859398 100%);
            color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .header h1 {
            margin: 0 0 10px 0;
            font-size: 32px;
            font-weight: 600;
        }
        .breadcrumbs {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            letter-spacing: 0.2px;
            color: rgba(255,255,255,0.85);
            margin-bottom: 10px;
        }
        .breadcrumbs a {
            color: #fff;
            text-decoration: none;
            font-weight: 600;
        }
        .breadcrumbs a:hover {
            text-decoration: underline;
        }
        .breadcrumbs .back-arrow {
            opacity: 0.6;
        }
        .embedded .breadcrumbs {
            display: none;
        }
        .header p {
            margin: 0;
            font-size: 16px;
            opacity: 0.9;
        }
        .header-total {
            margin-top: 8px;
            font-size: 14px;
            opacity: 0.85;
        }
        .export-info {
            color: #666;
            font-size: 14px;
            margin-bottom: 30px;
        }
        .search-box {
            position: relative;
            margin-bottom: 20px;
        }
        .search-box input {
            width: 100%;
            padding: 12px 46px 12px 16px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            box-sizing: border-box;
        }
        .search-box input:focus {
            outline: none;
            border-color: #007AFF;
        }
        .clear-search {
            position: absolute;
            right: 24px;
            top: 50%;
            transform: translateY(-50%);
            border: 1px solid #d1d5db;
            background: #f3f4f6;
            color: #111827;
            border-radius: 6px;
            padding: 4px 8px;
            font-size: 12px;
            cursor: pointer;
            display: none;
        }
        .clear-search.visible { display: inline-block; }
        /* NEW: main content wrapper */
        .page-container {
            max-width: 1200px;
            margin: 20px auto;   /* center horizontally, space from top */
            padding: 0;
        }
        .contact-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }
        .contact-card {
            background: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .highlight-target {
            background-color: #fff3cd;
            outline: 2px solid #f59e0b;
        }
        .contact-card.hidden {
            display: none;
        }
        .contact-name {
            font-size: 18px;
            font-weight: bold;
            color: #333;
            margin-bottom: 5px;
        }
        .contact-org {
            color: #666;
            font-size: 14px;
            margin-bottom: 15px;
        }
        .contact-detail {
            margin-bottom: 10px;
        }
        .detail-label {
            font-weight: 600;
            color: #666;
            font-size: 12px;
            text-transform: uppercase;
            display: block;
            margin-bottom: 3px;
        }
        .detail-value {
            color: #333;
            font-size: 14px;
        }
        .phone-link {
            color: #007AFF;
            text-decoration: none;
        }
        .phone-link:hover {
            text-decoration: underline;
        }
        .email-link {
            color: #007AFF;
            text-decoration: none;
        }
        .email-link:hover {
            text-decoration: underline;
        }
        .label-badge {
            display: inline-block;
            background-color: #E5E5EA;
            color: #666;
            font-size: 11px;
            padding: 2px 6px;
            border-radius: 3px;
            margin-left: 5px;
        }
        .no-results {
            display: none;
            text-align: center;
            color: #999;
            font-size: 14px;
            margin: 20px 0 10px;
        }
        .no-results.visible {
            display: block;
        }
        @media print {
            body {
                background-color: white;
            }
            .contact-card {
                box-shadow: none;
                border: 1px solid #ddd;
                page-break-inside: avoid;
            }
        }
    </style>
</head>
<body>
    <div class="page-container">
    <div class="header">
        <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Start_Here.html">Back</a></div>
        <h1>Contacts</h1>
        <p>Extracted from iOS Backup on """ + datetime.now().strftime("%B %d, %Y") + """</p>
        <div class="header-total">Total contacts: """ + f"{len(items):,}" + """</div>
    </div>
    <div class="search-box">
        <input type="text" id="searchInput" placeholder="Search contacts..." onkeyup="filterContacts()">
        <button id="clearSearch" class="clear-search" title="Clear" aria-label="Clear search">X</button>
    </div>
    <div class="contact-grid">
""")

                # Write each contact
                for i, contact in enumerate(items):
                    current = offset + i
                    if progress_callback:
                        contact_name = ' '.join([
                            contact['first_name'] or '',
                            contact['last_name'] or ''
                        ]).strip() or contact['organization'] or f"Contact {i+1}"

                        if not progress_callback(current + 1, total, f"HTML: {contact_name}"):
                            return False

                    # Build contact name
                    full_name = ' '.join([
                        contact['first_name'] or '',
                        contact['last_name'] or ''
                    ]).strip()

                    if not full_name:
                        full_name = contact['organization'] or "(No Name)"

                    search_parts = [
                        full_name,
                        contact['organization'] or '',
                        ' '.join([p['value'] for p in contact['phones']]) if contact['phones'] else '',
                        ' '.join([e['value'] for e in contact['emails']]) if contact['emails'] else ''
                    ]
                    search_blob = ' '.join([part for part in search_parts if part]).lower()

                    f.write(f"""        <div class="contact-card" id="contact-{contact['rowid']}" data-search="{self._escape_html(search_blob)}">
            <div class="contact-name">{self._escape_html(full_name)}</div>
""")

                    if contact['organization'] and full_name != contact['organization']:
                        f.write(f"""            <div class="contact-org">{self._escape_html(contact['organization'])}</div>
""")

                    # Phone numbers
                    if contact['phones']:
                        f.write("""            <div class="contact-detail">
                <span class="detail-label">Phone</span>
""")
                        for phone in contact['phones']:
                            phone_label = phone['label'] or 'Phone'
                            f.write(f"""                <div class="detail-value">
                    <a href="tel:{self._escape_html(phone['value'])}" class="phone-link">{self._escape_html(phone['value'])}</a>
                    <span class="label-badge">{self._escape_html(phone_label)}</span>
                </div>
""")
                        f.write("""            </div>
""")

                    # Email addresses
                    if contact['emails']:
                        f.write("""            <div class="contact-detail">
                <span class="detail-label">Email</span>
""")
                        for email in contact['emails']:
                            email_label = email['label'] or 'Email'
                            f.write(f"""                <div class="detail-value">
                    <a href="mailto:{self._escape_html(email['value'])}" class="email-link">{self._escape_html(email['value'])}</a>
                    <span class="label-badge">{self._escape_html(email_label)}</span>
                </div>
""")
                        f.write("""            </div>
""")

                    # Addresses
                    if contact['addresses']:
                        f.write(f"""            <div class="contact-detail">
                <span class="detail-label">Addresses</span>
                <div class="detail-value">{len(contact['addresses'])} address(es)</div>
            </div>
""")

                    f.write("""        </div>
""")

                # Write HTML footer
                f.write("""    </div>
    <div class="no-results" id="noResults">No contacts found matching your search</div>
</div>
<script>
    function filterContacts() {
        const input = document.getElementById('searchInput');
        const filter = input.value.toLowerCase();
        const cards = document.querySelectorAll('.contact-card');
        const noResults = document.getElementById('noResults');
        let visibleCount = 0;

        cards.forEach(card => {
            const haystack = card.getAttribute('data-search') || '';
            if (!filter || haystack.includes(filter)) {
                card.classList.remove('hidden');
                visibleCount += 1;
            } else {
                card.classList.add('hidden');
            }
        });

        if (noResults) {
            if (!visibleCount && filter) {
                noResults.classList.add('visible');
            } else {
                noResults.classList.remove('visible');
            }
        }
    }
</script>
<script>
    const contactsSearchInput = document.getElementById('searchInput');
    const contactsClearBtn = document.getElementById('clearSearch');
    if (contactsSearchInput && contactsClearBtn) {
        const toggleClear = () => contactsClearBtn.classList.toggle('visible', !!contactsSearchInput.value);
        contactsSearchInput.addEventListener('input', toggleClear);
        contactsClearBtn.addEventListener('click', () => {
            contactsSearchInput.value = '';
            toggleClear();
            if (typeof filterContacts === 'function') {
                filterContacts();
            }
            contactsSearchInput.focus();
        });
        toggleClear();
    }
</script>
<script>
    (function() {
        if (window.self !== window.top) {
            document.body.classList.add('embedded');
        }
    })();
</script>
<script>
    (function() {
        if (!window.location.hash) return;
        const target = document.querySelector(window.location.hash);
        if (!target) return;
        target.classList.add('highlight-target');
        try {
            target.scrollIntoView({ block: 'center' });
        } catch (e) {
            target.scrollIntoView();
        }
    })();
</script>
</body>
</html>
""")

            return True

        except Exception as e:
            print(f"Error exporting HTML: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _escape_html(self, text: str) -> str:
        """Escape HTML special characters."""
        if not text:
            return ""
        text = str(text)
        text = text.replace('&', '&amp;')
        text = text.replace('<', '&lt;')
        text = text.replace('>', '&gt;')
        text = text.replace('"', '&quot;')
        text = text.replace("'", '&#39;')
        return text

    def _format_label(self, label: Optional[str]) -> str:
        """Format ABMultiValue label for display."""
        if not label:
            return ''

        # Convert to string if it's an integer (predefined label ID)
        if isinstance(label, int):
            # Map common label IDs to names
            label_map = {
                1: 'Home',
                2: 'Work',
                3: 'Other',
                4: 'Mobile',
                5: 'Main',
                6: 'Home Fax',
                7: 'Work Fax',
                8: 'Pager',
                9: 'iPhone',
            }
            return label_map.get(label, f'Label {label}')

        # Labels are like "_$!<Mobile>!$_" or "_$!<Home>!$_"
        label_str = str(label)
        if label_str.startswith('_$!<') and label_str.endswith('>!$_'):
            return label_str[4:-4]  # Extract "Mobile" or "Home"

        return label_str

    def _format_timestamp_iso(self, timestamp: Optional[float]) -> Optional[str]:
        if timestamp is None:
            return None
        try:
            ts = float(timestamp)
        except Exception:
            return None
        try:
            if ts > 1_000_000_000:
                return datetime.fromtimestamp(ts).isoformat()
            if ts > 0:
                apple_epoch = datetime(2001, 1, 1).timestamp()
                return datetime.fromtimestamp(apple_epoch + ts).isoformat()
        except Exception:
            return None
        return None

    def _emit_timeline_events(self, items: List[Dict[str, Any]], timeline_emitter) -> None:
        for contact in items:
            raw_ts = contact.get('modified') or contact.get('created')
            ts_iso = self._format_timestamp_iso(raw_ts)
            if not ts_iso:
                continue
            name_parts = [contact.get('first_name') or '', contact.get('last_name') or '']
            full_name = ' '.join([part for part in name_parts if part]).strip()
            if not full_name:
                full_name = contact.get('organization') or '(No Name)'
            details = {
                'organization': contact.get('organization') or '',
                'phones': ', '.join([p.get('value', '') for p in contact.get('phones', []) if p.get('value')]),
                'emails': ', '.join([e.get('value', '') for e in contact.get('emails', []) if e.get('value')]),
            }
            timeline_emitter.emit({
                'timestamp': ts_iso,
                'raw_timestamp': raw_ts,
                'raw_format': 'apple_epoch_seconds',
                'source_app': 'Contacts',
                'source_category': 'Contacts',
                'event_type': 'contact',
                'title': full_name,
                'details': details,
                'confidence': 'medium',
                'raw_source_path': self.contacts_db_path,
                'report_anchor': f"contact-{contact.get('rowid')}",
                'link_hint': 'Contacts/Contacts.html',
            })
