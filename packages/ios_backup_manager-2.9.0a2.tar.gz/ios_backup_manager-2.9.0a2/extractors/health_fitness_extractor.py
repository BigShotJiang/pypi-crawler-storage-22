#!/usr/bin/env python3
"""
Health & Fitness extractor for iOS backups.

Parses HealthDomain/Health/healthdb_secure.sqlite and generates an HTML/JSON report
covering daily activity, workouts, sleep schedules, and heart classifications.
"""

import hashlib
import os
import sqlite3
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from .base import CategoryDataExtractor


class HealthFitnessExtractor(CategoryDataExtractor):
    """Extract Health & Fitness artifacts from iOS backups."""
    export_even_if_empty = True

    _APPLE_EPOCH = datetime(2001, 1, 1)
    _MAX_ROWS = 10000

    def __init__(self, backup_path: str):
        super().__init__(backup_path)
        self._secure_db_path = self.backup_access.get_file_path(
            "HealthDomain", "Health/healthdb_secure.sqlite"
        )
        self._plain_db_path = self.backup_access.get_file_path(
            "HealthDomain", "Health/healthdb.sqlite"
        )
        self._cached_data: Optional[Dict[str, Any]] = None
        if not self._secure_db_path or not os.path.exists(self._secure_db_path):
            raise FileNotFoundError("Health database not found in backup")

    def _sha256(self, path: Optional[str]) -> str:
        if not path or not os.path.exists(path):
            return ""
        h = hashlib.sha256()
        try:
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(1024 * 1024), b""):
                    h.update(chunk)
        except Exception:
            return ""
        return h.hexdigest()

    def _normalize_apple_timestamp(self, value: Any) -> Optional[int]:
        try:
            ts = float(value)
        except Exception:
            return None
        if ts <= 0:
            return None
        return int((self._APPLE_EPOCH + timedelta(seconds=ts)).timestamp())

    def _format_timestamp(self, value: Any) -> str:
        ts = self._normalize_apple_timestamp(value)
        if not ts:
            return ""
        return datetime.fromtimestamp(ts).strftime("%m/%d/%Y %I:%M %p")

    def _format_duration(self, seconds: Optional[float]) -> str:
        if seconds is None:
            return ""
        try:
            seconds = float(seconds)
        except Exception:
            return ""
        if seconds < 0:
            return ""
        minutes, sec = divmod(int(seconds), 60)
        hours, minutes = divmod(minutes, 60)
        if hours:
            return f"{hours}h {minutes}m"
        if minutes:
            return f"{minutes}m {sec}s"
        return f"{sec}s"

    def _format_duration_hms(self, seconds: Optional[float]) -> str:
        if seconds is None:
            return ""
        try:
            seconds = int(float(seconds))
        except Exception:
            return ""
        if seconds < 0:
            return ""
        hours, rem = divmod(seconds, 3600)
        minutes, sec = divmod(rem, 60)
        if hours:
            return f"{hours}h {minutes}m {sec}s"
        if minutes:
            return f"{minutes}m {sec}s"
        return f"{sec}s"

    def _workout_type_label(self, value: Any) -> str:
        mapping = {
            1: "Running",
            2: "Walking",
            3: "Cycling",
            4: "Elliptical",
            5: "Rowing",
            6: "Swimming",
            7: "Hiking",
            8: "Cross Training",
            9: "Stair Climbing",
            10: "Strength Training",
            11: "Yoga",
            13: "Dance",
            16: "Traditional Strength Training",
            18: "Functional Strength Training",
            19: "Core Training",
            37: "Soccer",
            38: "Basketball",
            39: "Baseball",
            40: "Softball",
            44: "Golf",
            52: "Cycling (Indoor)",
            53: "Cycling (Outdoor)",
            60: "Swimming (Pool)",
            61: "Swimming (Open Water)",
            63: "Tennis",
            70: "Walking (Treadmill)",
            75: "Rowing (Indoor)",
            79: "Elliptical",
            80: "Stair Stepper",
            82: "HIIT",
            83: "Core Training",
            84: "Flexibility",
            86: "Mind & Body",
        }
        try:
            key = int(value)
        except Exception:
            return str(value) if value is not None else ""
        return mapping.get(key, f"Workout Type {key}")

    def _connect_secure(self) -> sqlite3.Connection:
        return sqlite3.connect(f"file:{self._secure_db_path}?mode=ro", uri=True)

    def _load_activity_caches(self) -> List[Dict[str, Any]]:
        items = []
        try:
            conn = self._connect_secure()
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            cur.execute("""
                SELECT
                    a.data_id,
                    a.activity_mode,
                    a.wheelchair_use,
                    a.energy_burned,
                    a.move_minutes,
                    a.brisk_minutes,
                    a.active_hours,
                    a.steps,
                    a.pushes,
                    a.walk_distance,
                    a.flights,
                    s.start_date,
                    s.end_date
                FROM activity_caches a
                LEFT JOIN samples s ON a.data_id = s.data_id
                ORDER BY s.start_date DESC
                LIMIT ?
            """, (self._MAX_ROWS,))
            rows = cur.fetchall()
        except Exception:
            return items
        finally:
            try:
                conn.close()
            except Exception:
                pass

        for row in rows:
            items.append({
                "start": row["start_date"],
                "end": row["end_date"],
                "activity_mode": row["activity_mode"],
                "wheelchair_use": row["wheelchair_use"],
                "energy_burned": row["energy_burned"],
                "move_minutes": row["move_minutes"],
                "brisk_minutes": row["brisk_minutes"],
                "active_hours": row["active_hours"],
                "steps": row["steps"],
                "pushes": row["pushes"],
                "walk_distance": row["walk_distance"],
                "flights": row["flights"],
            })

        return items

    def _load_workouts(self) -> List[Dict[str, Any]]:
        items = []
        try:
            conn = self._connect_secure()
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            cur.execute("""
                SELECT
                    wa.owner_id,
                    wa.activity_type,
                    wa.location_type,
                    wa.start_date as activity_start,
                    wa.end_date as activity_end,
                    wa.duration as activity_duration,
                    w.total_distance,
                    s.start_date as sample_start,
                    s.end_date as sample_end
                FROM workout_activities wa
                LEFT JOIN workouts w ON wa.owner_id = w.data_id
                LEFT JOIN samples s ON wa.owner_id = s.data_id
                ORDER BY COALESCE(wa.start_date, s.start_date) DESC
                LIMIT ?
            """, (self._MAX_ROWS,))
            rows = cur.fetchall()
        except Exception:
            return items
        finally:
            try:
                conn.close()
            except Exception:
                pass

        for row in rows:
            start = row["activity_start"] or row["sample_start"]
            end = row["activity_end"] or row["sample_end"]
            duration = row["activity_duration"]
            if duration is None and start and end:
                start_ts = self._normalize_apple_timestamp(start)
                end_ts = self._normalize_apple_timestamp(end)
                if start_ts and end_ts and end_ts >= start_ts:
                    duration = end_ts - start_ts
            items.append({
                "start": start,
                "end": end,
                "duration_seconds": duration,
                "activity_type": row["activity_type"],
                "location_type": row["location_type"],
                "total_distance": row["total_distance"],
            })

        return items

    def _load_sleep_schedules(self) -> List[Dict[str, Any]]:
        items = []
        try:
            conn = self._connect_secure()
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            cur.execute("""
                SELECT
                    s.data_id,
                    s.monday, s.tuesday, s.wednesday, s.thursday, s.friday, s.saturday, s.sunday,
                    s.wake_hour, s.wake_minute, s.bed_hour, s.bed_minute,
                    sam.start_date,
                    sam.end_date
                FROM sleep_schedule_samples s
                LEFT JOIN samples sam ON s.data_id = sam.data_id
                ORDER BY sam.start_date DESC
                LIMIT ?
            """, (self._MAX_ROWS,))
            rows = cur.fetchall()
        except Exception:
            return items
        finally:
            try:
                conn.close()
            except Exception:
                pass

        for row in rows:
            items.append({
                "start": row["start_date"],
                "end": row["end_date"],
                "days": {
                    "mon": row["monday"], "tue": row["tuesday"], "wed": row["wednesday"],
                    "thu": row["thursday"], "fri": row["friday"], "sat": row["saturday"], "sun": row["sunday"],
                },
                "wake_hour": row["wake_hour"],
                "wake_minute": row["wake_minute"],
                "bed_hour": row["bed_hour"],
                "bed_minute": row["bed_minute"],
            })

        return items

    def _load_heart_classifications(self) -> List[Dict[str, Any]]:
        items = []
        try:
            conn = self._connect_secure()
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            cur.execute("""
                SELECT sample_start_date, sample_duration, classification, sample_time_zone
                FROM heart_sample_classifications
                ORDER BY sample_start_date DESC
                LIMIT ?
            """, (self._MAX_ROWS,))
            rows = cur.fetchall()
        except Exception:
            return items
        finally:
            try:
                conn.close()
            except Exception:
                pass

        for row in rows:
            items.append({
                "start": row["sample_start_date"],
                "duration_seconds": row["sample_duration"],
                "classification": row["classification"],
                "time_zone": row["sample_time_zone"],
            })

        return items

    def _load_data(self) -> Dict[str, Any]:
        if self._cached_data is not None:
            return self._cached_data

        encrypted_flag = None
        manifest_plist = os.path.join(self.backup_path, "Manifest.plist")
        if os.path.exists(manifest_plist):
            try:
                import plistlib
                with open(manifest_plist, "rb") as f:
                    manifest = plistlib.load(f)
                encrypted_flag = bool(manifest.get("IsEncrypted", False))
            except Exception:
                encrypted_flag = None

        data = {
            "encrypted": encrypted_flag,
            "secure_db_path": self._secure_db_path,
            "secure_db_hash": self._sha256(self._secure_db_path),
            "plain_db_path": self._plain_db_path,
            "plain_db_hash": self._sha256(self._plain_db_path),
            "activity_caches": self._load_activity_caches(),
            "workouts": self._load_workouts(),
            "sleep_schedules": self._load_sleep_schedules(),
            "heart_classifications": self._load_heart_classifications(),
        }

        self._cached_data = data
        return data

    def get_count(self) -> int:
        data = self._load_data()
        return (
            len(data.get("activity_caches") or [])
            + len(data.get("workouts") or [])
            + len(data.get("sleep_schedules") or [])
            + len(data.get("heart_classifications") or [])
        )

    def get_items(self, limit: Optional[int] = None, offset: int = 0,
                  search: Optional[str] = None) -> List[Dict[str, Any]]:
        data = self._load_data()
        items = [
            {"category": "Activity", **item} for item in data.get("activity_caches") or []
        ]
        items.extend([{"category": "Workout", **item} for item in data.get("workouts") or []])
        items.extend([{"category": "Sleep", **item} for item in data.get("sleep_schedules") or []])
        items.extend([{"category": "Heart", **item} for item in data.get("heart_classifications") or []])
        if search:
            term = search.lower()
            items = [item for item in items if term in str(item).lower()]
        if limit:
            return items[offset:offset + limit]
        return items[offset:]

    def export(self, items: List[Dict[str, Any]], output_path: str,
               format: str = "html", progress_callback=None, timeline_emitter=None) -> bool:
        if format != "html":
            raise ValueError(f"Unsupported export format: {format}")

        self._reset_export_bytes()
        os.makedirs(output_path, exist_ok=True)

        data = self._load_data()
        html_path = os.path.join(output_path, "Health_Fitness.html")
        json_path = os.path.join(output_path, "Health_Fitness.json")

        import json
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        self._add_export_bytes(json_path)

        encrypted_label = "Unknown"
        if data["encrypted"] is True:
            encrypted_label = "Yes"
        elif data["encrypted"] is False:
            encrypted_label = "No"

        activity_rows = []
        activity_daily = {}
        for row in data.get("activity_caches") or []:
            day_key = ""
            start_ts = self._normalize_apple_timestamp(row.get("start"))
            if start_ts:
                day_key = datetime.fromtimestamp(start_ts).strftime("%Y-%m-%d")
                entry = activity_daily.setdefault(day_key, {
                    "steps": 0,
                    "energy": 0,
                    "move_minutes": 0,
                    "brisk_minutes": 0,
                    "active_hours": 0,
                    "distance": 0,
                    "flights": 0,
                })
                entry["steps"] += row.get("steps") or 0
                entry["energy"] += row.get("energy_burned") or 0
                entry["move_minutes"] += row.get("move_minutes") or 0
                entry["brisk_minutes"] += row.get("brisk_minutes") or 0
                entry["active_hours"] += row.get("active_hours") or 0
                entry["distance"] += row.get("walk_distance") or 0
                entry["flights"] += row.get("flights") or 0
            activity_rows.append(
                "<tr>"
                f"<td>{self._escape_html(self._format_timestamp(row.get('start')))}</td>"
                f"<td>{self._escape_html(str(row.get('steps') or ''))}</td>"
                f"<td>{self._escape_html(str(row.get('energy_burned') or ''))}</td>"
                f"<td>{self._escape_html(str(row.get('move_minutes') or ''))}</td>"
                f"<td>{self._escape_html(str(row.get('active_hours') or ''))}</td>"
                f"<td>{self._escape_html(str(row.get('walk_distance') or ''))}</td>"
                f"<td>{self._escape_html(str(row.get('flights') or ''))}</td>"
                "</tr>"
            )

        workout_rows = []
        workout_counts = {}
        workout_daily = {}
        workout_count_daily = {}
        for row in data.get("workouts") or []:
            activity_type = row.get("activity_type")
            activity_label = self._workout_type_label(activity_type)
            if activity_type is not None:
                key = activity_label
                workout_counts[key] = workout_counts.get(key, 0) + 1
            start_ts = self._normalize_apple_timestamp(row.get("start"))
            if start_ts:
                day_key = datetime.fromtimestamp(start_ts).strftime("%Y-%m-%d")
                workout_daily[day_key] = workout_daily.get(day_key, 0) + (row.get("duration_seconds") or 0)
                workout_count_daily[day_key] = workout_count_daily.get(day_key, 0) + 1
            workout_rows.append(
                "<tr>"
                f"<td>{self._escape_html(self._format_timestamp(row.get('start')))}</td>"
                f"<td>{self._escape_html(self._format_timestamp(row.get('end')))}</td>"
                f"<td>{self._escape_html(activity_label)}</td>"
                f"<td>{self._escape_html(self._format_duration_hms(row.get('duration_seconds')))}</td>"
                f"<td>{self._escape_html(str(row.get('total_distance') or ''))}</td>"
                "</tr>"
            )

        sleep_rows = []
        sleep_day_counts = {}
        for row in data.get("sleep_schedules") or []:
            days = row.get("days") or {}
            active_days = [k.capitalize() for k, v in days.items() if v]
            for key in active_days:
                sleep_day_counts[key] = sleep_day_counts.get(key, 0) + 1
            wake = f"{row.get('wake_hour', '')}:{str(row.get('wake_minute', '')).zfill(2)}"
            bed = f"{row.get('bed_hour', '')}:{str(row.get('bed_minute', '')).zfill(2)}"
            sleep_rows.append(
                "<tr>"
                f"<td>{self._escape_html(self._format_timestamp(row.get('start')))}</td>"
                f"<td>{self._escape_html(', '.join(active_days) or '')}</td>"
                f"<td>{self._escape_html(bed)}</td>"
                f"<td>{self._escape_html(wake)}</td>"
                "</tr>"
            )

        heart_rows = []
        heart_counts = {}
        for row in data.get("heart_classifications") or []:
            key = str(row.get("classification") or "Unknown")
            heart_counts[key] = heart_counts.get(key, 0) + 1
            heart_rows.append(
                "<tr>"
                f"<td>{self._escape_html(self._format_timestamp(row.get('start')))}</td>"
                f"<td>{self._escape_html(str(row.get('classification') or ''))}</td>"
                f"<td>{self._escape_html(self._format_duration(row.get('duration_seconds')))}</td>"
                f"<td>{self._escape_html(str(row.get('time_zone') or ''))}</td>"
                "</tr>"
            )

        # Prepare chart datasets
        activity_days = sorted(activity_daily.keys())[-30:]
        activity_series = {
            "labels": activity_days,
            "steps": [activity_daily[d]["steps"] for d in activity_days],
            "energy": [activity_daily[d]["energy"] for d in activity_days],
            "move": [activity_daily[d]["move_minutes"] for d in activity_days],
            "brisk": [activity_daily[d]["brisk_minutes"] for d in activity_days],
            "active": [activity_daily[d]["active_hours"] for d in activity_days],
            "distance": [activity_daily[d]["distance"] for d in activity_days],
        }
        workout_count_series = [workout_count_daily.get(day, 0) for day in activity_days]
        workout_type_labels = list(workout_counts.keys())
        workout_type_values = [workout_counts[k] for k in workout_type_labels]
        workout_days = sorted(workout_daily.keys())[-30:]
        workout_duration_series = [workout_daily[d] for d in workout_days]
        sleep_day_labels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        sleep_day_values = [sleep_day_counts.get(k, 0) for k in sleep_day_labels]
        heart_labels = list(heart_counts.keys())
        heart_values = [heart_counts[k] for k in heart_labels]

        total_steps = sum(activity_series["steps"])
        avg_steps = int(total_steps / len(activity_series["steps"])) if activity_series["steps"] else 0
        total_active_hours = sum(activity_series["active"])
        total_workouts = len(data.get("workouts") or [])
        total_distance_km = sum(activity_series["distance"]) / 1000.0 if activity_series["distance"] else 0.0

        import json
        activity_series_labels = json.dumps(activity_series["labels"])
        activity_series_steps = json.dumps(activity_series["steps"])
        activity_series_energy = json.dumps(activity_series["energy"])
        activity_series_move = json.dumps(activity_series["move"])
        activity_series_brisk = json.dumps(activity_series["brisk"])
        activity_series_active = json.dumps(activity_series["active"])
        activity_series_distance = json.dumps([v / 1000.0 for v in activity_series["distance"]])
        activity_series_flights = json.dumps([activity_daily[d].get("flights", 0) for d in activity_series["labels"]])
        workout_count_series_json = json.dumps(workout_count_series)
        workout_type_labels_json = json.dumps(workout_type_labels)
        workout_type_values_json = json.dumps(workout_type_values)
        workout_duration_labels_json = json.dumps(workout_days)
        workout_duration_values_json = json.dumps(workout_duration_series)
        heart_labels_json = json.dumps(heart_labels)
        heart_values_json = json.dumps(heart_values)

        html = f"""<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Health & Fitness</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
  <style>
    :root {{
      --green-900: #145a32;
      --green-800: #1a7f4b;
      --green-700: #2f9d57;
      --green-600: #4bb464;
      --green-500: #7fd36a;
      --teal-500: #3aa59b;
      --blue-500: #3f7fbf;
      --amber-500: #c9972e;
      --slate-900: #111827;
      --slate-700: #374151;
      --slate-500: #6b7280;
      --slate-200: #e5e7eb;
      --slate-100: #f8fafc;
    }}
    body {{
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
      margin: 20px;
      background-color: #f5f5f5;
    }}
    .header {{
      background: linear-gradient(135deg, var(--green-800) 0%, var(--green-500) 100%);
      color: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      margin-bottom: 20px;
    }}
    .header h1 {{ margin: 0 0 10px 0; font-size: 32px; font-weight: 600; }}
    .breadcrumbs {{
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 12px;
      letter-spacing: 0.2px;
      color: rgba(255,255,255,0.85);
      margin-bottom: 10px;
    }}
    .breadcrumbs a {{ color: #fff; text-decoration: none; font-weight: 600; }}
    .breadcrumbs a:hover {{ text-decoration: underline; }}
    .embedded .breadcrumbs {{ display: none; }}
    .section {{
      background: #fff;
      border-radius: 12px;
      padding: 20px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.08);
      margin-bottom: 20px;
    }}
    .summary-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 14px;
    }}
    .summary-card {{
      background: var(--slate-100);
      border: 1px solid var(--slate-200);
      border-radius: 12px;
      padding: 14px;
    }}
    .summary-card .value {{
      font-size: 22px;
      font-weight: 700;
    }}
    .summary-card .label {{
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: 0.6px;
      color: var(--slate-500);
    }}
    .summary-card .sub-value {{
      margin-top: 6px;
      font-size: 12px;
      color: var(--slate-500);
    }}
    .toggle-row {{
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
      margin: 12px 0 0 0;
    }}
    .toggle-row button {{
      border: 1px solid var(--slate-200);
      background: #fff;
      padding: 6px 10px;
      border-radius: 999px;
      font-size: 12px;
      cursor: pointer;
    }}
    .toggle-row button.active {{
      background: var(--slate-900);
      color: #fff;
      border-color: var(--slate-900);
    }}
    .chart-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 18px;
    }}
    .chart-card {{
      background: #fff;
      border-radius: 12px;
      border: 1px solid var(--slate-200);
      padding: 14px;
    }}
    .chart-card h3 {{
      margin: 0 0 8px 0;
      font-size: 14px;
      letter-spacing: 0.4px;
      text-transform: uppercase;
      color: var(--slate-700);
    }}
    table {{
      width: 100%;
      border-collapse: collapse;
    }}
    th, td {{
      text-align: left;
      padding: 8px;
      border-bottom: 1px solid #e5e5e5;
      font-size: 13px;
      vertical-align: top;
      word-break: break-word;
    }}
    th {{ background: #fafafa; }}
    code {{ background: #f3f4f6; padding: 2px 6px; border-radius: 6px; font-size: 12px; }}
    .table-scroll {{
      overflow-x: auto;
      -webkit-overflow-scrolling: touch;
    }}
    .table-scroll table {{
      min-width: 520px;
    }}
    .embedded table {{
      font-size: 12px;
    }}
    .embedded code {{
      display: inline-block;
      max-width: 260px;
      white-space: normal;
      word-break: break-all;
    }}
  </style>
</head>
<body>
  <div class="header">
    <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Start_Here.html">Back</a></div>
    <h1>Health & Fitness</h1>
    <p>Summary extracted from the Health database.</p>
  </div>

  <div class="section">
    <div class="summary-grid">
      <div class="summary-card">
        <div class="value" id="stepsCard">{total_steps:,}</div>
        <div class="label">Steps Total</div>
        <div class="sub-value" id="stepsAvgCard">Avg/day: {avg_steps:,}</div>
      </div>
      <div class="summary-card">
        <div class="value" id="activeCard">{int(total_active_hours):,}</div>
        <div class="label">Active Hours Total</div>
        <div class="sub-value" id="activeAvgCard">Avg/day: {avg_steps:,}</div>
      </div>
      <div class="summary-card">
        <div class="value" id="distanceCard">{total_distance_km:.1f} km</div>
        <div class="label">Distance Total</div>
        <div class="sub-value" id="distanceAvgCard">Avg/day: {total_distance_km:.1f} km</div>
      </div>
      <div class="summary-card">
        <div class="value" id="workoutsCard">{total_workouts:,}</div>
        <div class="label">Workouts Total</div>
        <div class="sub-value" id="workoutsAvgCard">Avg/day: {total_workouts:,}</div>
      </div>
      <div class="summary-card">
        <div class="value" id="stepsAvgOnlyCard">{avg_steps:,}</div>
        <div class="label">Avg Steps / Day</div>
        <div class="sub-value" id="windowLabelCard">Last 30 Days</div>
      </div>
    </div>
    <div class="toggle-row" id="windowToggles">
      <button data-window="1">Day</button>
      <button data-window="7">Week</button>
      <button data-window="30" class="active">Month</button>
      <button data-window="365">Year</button>
    </div>
  </div>

  <div class="section">
    <h2>Activity Overview</h2>
    <div class="chart-grid">
      <div class="chart-card">
        <h3>Steps (Last 30 Days)</h3>
        <canvas id="stepsChart" height="140"></canvas>
      </div>
      <div class="chart-card">
        <h3>Energy Burned</h3>
        <canvas id="energyChart" height="140"></canvas>
      </div>
      <div class="chart-card">
        <h3>Move Minutes</h3>
        <canvas id="moveChart" height="140"></canvas>
      </div>
      <div class="chart-card">
        <h3>Brisk Minutes</h3>
        <canvas id="briskChart" height="140"></canvas>
      </div>
      <div class="chart-card">
        <h3>Active Hours</h3>
        <canvas id="activeChart" height="140"></canvas>
      </div>
      <div class="chart-card">
        <h3>Distance</h3>
        <canvas id="distanceChart" height="140"></canvas>
      </div>
      <div class="chart-card">
        <h3>Flights Climbed</h3>
        <canvas id="flightsChart" height="140"></canvas>
      </div>
    </div>
  </div>

  <div class="section">
    <h2>Workouts</h2>
    <div class="chart-grid">
      <div class="chart-card">
        <h3>Workout Types</h3>
        <canvas id="workoutTypeChart" height="160"></canvas>
      </div>
      <div class="chart-card">
        <h3>Workout Duration (Last 30 Days)</h3>
        <canvas id="workoutDurationChart" height="160"></canvas>
      </div>
    </div>
  </div>

  <div class="section">
    <h2>Sleep Schedule</h2>
    <div class="chart-grid">
      <div class="chart-card">
        <h3>Schedule Details</h3>
        <table>
          <thead>
            <tr><th>Recorded</th><th>Days</th><th>Bed Time</th><th>Wake Time</th></tr>
          </thead>
          <tbody>
            {''.join(sleep_rows) if sleep_rows else '<tr><td colspan="4">No sleep schedule data found.</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="section">
    <h2>Heart Classifications</h2>
    <div class="chart-grid">
      <div class="chart-card">
        <h3>Classification Counts</h3>
        <canvas id="heartChart" height="160"></canvas>
      </div>
      <div class="chart-card">
        <h3>Recent Events</h3>
        <table>
          <thead>
            <tr><th>Start</th><th>Classification</th><th>Duration</th><th>Time Zone</th></tr>
          </thead>
          <tbody>
            {''.join(heart_rows) if heart_rows else '<tr><td colspan="4">No heart classification data found.</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <details class="section">
    <summary><strong>Acquisition Summary</strong></summary>
    <p><strong>Backup type:</strong> iTunes-style</p>
    <p><strong>Encrypted:</strong> {self._escape_html(encrypted_label)}</p>
    <div class="table-scroll">
      <table>
        <thead><tr><th>Artifact</th><th>Details</th></tr></thead>
        <tbody>
          <tr>
            <td>healthdb_secure.sqlite</td>
            <td>
              <details>
                <summary>Show details</summary>
                <div><strong>Path:</strong> {self._escape_html(data.get('secure_db_path') or '')}</div>
                <div><strong>SHA-256:</strong> <code>{self._escape_html(data.get('secure_db_hash') or '')}</code></div>
              </details>
            </td>
          </tr>
          <tr>
            <td>healthdb.sqlite</td>
            <td>
              <details>
                <summary>Show details</summary>
                <div><strong>Path:</strong> {self._escape_html(data.get('plain_db_path') or '')}</div>
                <div><strong>SHA-256:</strong> <code>{self._escape_html(data.get('plain_db_hash') or '')}</code></div>
              </details>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </details>

  <div class="section">
    <h2>Limitations</h2>
    <ul>
      <li>Some health categories may be absent if the user disabled collection or cleared data.</li>
      <li>Schema varies by iOS version; not all tables are present in every backup.</li>
      <li>Health data is typically only available in encrypted backups.</li>
    </ul>
  </div>

  <script>
    const activityLabels = {activity_series_labels};
    const stepsData = {activity_series_steps};
    const energyData = {activity_series_energy};
    const moveData = {activity_series_move};
    const briskData = {activity_series_brisk};
    const activeData = {activity_series_active};
    const distanceData = {activity_series_distance};
    const flightsData = {activity_series_flights};
    const workoutCountData = {workout_count_series_json};

    const workoutTypeLabels = {workout_type_labels_json};
    const workoutTypeValues = {workout_type_values_json};
    const workoutDurationLabels = {workout_duration_labels_json};
    const workoutDurationValues = {workout_duration_values_json};

    const heartLabels = {heart_labels_json};
    const heartValues = {heart_values_json};

    const palette = {{
      steps: '#2f9d57',
      energy: '#3f7fbf',
      move: '#4bb464',
      brisk: '#c9972e',
      active: '#3aa59b',
      distance: '#1a7f4b',
      flights: '#7fbf9b',
      workoutTypes: ['#1a7f4b', '#2f9d57', '#4bb464', '#7fd36a', '#3aa59b', '#3f7fbf'],
      workoutDuration: '#145a32',
      heart: '#c44f4f'
    }};

    function makeChart(ctx, config) {{
      if (!ctx) return null;
      return new Chart(ctx, config);
    }}

    const stepsChart = makeChart(document.getElementById('stepsChart'), {{
      type: 'bar',
      data: {{
        labels: activityLabels,
        datasets: [{{ label: 'Steps', data: stepsData, backgroundColor: palette.steps }}]
      }},
      options: {{ responsive: true, scales: {{ x: {{ display: false }} }} }}
    }});

    const energyChart = makeChart(document.getElementById('energyChart'), {{
      type: 'line',
      data: {{
        labels: activityLabels,
        datasets: [
          {{ label: 'Energy', data: energyData, borderColor: palette.energy, backgroundColor: 'rgba(63,127,191,0.2)' }}
        ]
      }},
      options: {{ responsive: true, scales: {{ x: {{ display: false }} }} }}
    }});

    const moveChart = makeChart(document.getElementById('moveChart'), {{
      type: 'line',
      data: {{
        labels: activityLabels,
        datasets: [
          {{ label: 'Move Minutes', data: moveData, borderColor: palette.move, backgroundColor: 'rgba(75,180,100,0.2)' }}
        ]
      }},
      options: {{ responsive: true, scales: {{ x: {{ display: false }} }} }}
    }});

    const briskChart = makeChart(document.getElementById('briskChart'), {{
      type: 'line',
      data: {{
        labels: activityLabels,
        datasets: [
          {{ label: 'Brisk Minutes', data: briskData, borderColor: palette.brisk, backgroundColor: 'rgba(201,151,46,0.2)' }}
        ]
      }},
      options: {{ responsive: true, scales: {{ x: {{ display: false }} }} }}
    }});

    const activeChart = makeChart(document.getElementById('activeChart'), {{
      type: 'bar',
      data: {{
        labels: activityLabels,
        datasets: [{{ label: 'Active Hours', data: activeData, backgroundColor: palette.active }}]
      }},
      options: {{ responsive: true, scales: {{ x: {{ display: false }} }} }}
    }});

    const distanceChart = makeChart(document.getElementById('distanceChart'), {{
      type: 'line',
      data: {{
        labels: activityLabels,
        datasets: [{{ label: 'Distance', data: distanceData, borderColor: palette.distance, backgroundColor: 'rgba(26,127,75,0.2)' }}]
      }},
      options: {{ responsive: true, scales: {{ x: {{ display: false }} }} }}
    }});

    const flightsChart = makeChart(document.getElementById('flightsChart'), {{
      type: 'bar',
      data: {{
        labels: activityLabels,
        datasets: [{{ label: 'Flights', data: flightsData, backgroundColor: palette.flights }}]
      }},
      options: {{ responsive: true, scales: {{ x: {{ display: false }} }} }}
    }});

    makeChart(document.getElementById('workoutTypeChart'), {{
      type: 'doughnut',
      data: {{
        labels: workoutTypeLabels,
        datasets: [{{ data: workoutTypeValues, backgroundColor: palette.workoutTypes }}]
      }},
      options: {{ responsive: true }}
    }});

    makeChart(document.getElementById('workoutDurationChart'), {{
      type: 'line',
      data: {{
        labels: workoutDurationLabels,
        datasets: [{{ label: 'Duration (min)', data: workoutDurationValues.map(v => v / 60), borderColor: palette.workoutDuration }}]
      }},
      options: {{ responsive: true, scales: {{ x: {{ display: false }} }} }}
    }});

    makeChart(document.getElementById('heartChart'), {{
      type: 'bar',
      data: {{
        labels: heartLabels,
        datasets: [{{ label: 'Count', data: heartValues, backgroundColor: palette.heart }}]
      }},
      options: {{ responsive: true }}
    }});

    function sliceForWindow(days) {{
      if (!activityLabels.length) return {{ labels: [], steps: [], energy: [], move: [], brisk: [], active: [], distance: [], flights: [], workouts: [] }};
      const count = Math.min(days, activityLabels.length);
      const start = activityLabels.length - count;
      return {{
        labels: activityLabels.slice(start),
        steps: stepsData.slice(start),
        energy: energyData.slice(start),
        move: moveData.slice(start),
        brisk: briskData.slice(start),
        active: activeData.slice(start),
        distance: distanceData.slice(start),
        flights: flightsData.slice(start),
        workouts: workoutCountData.slice(start)
      }};
    }}

    function updateSummaryCards(series) {{
      const totalSteps = series.steps.reduce((a,b) => a + b, 0);
      const avgSteps = series.steps.length ? Math.round(totalSteps / series.steps.length) : 0;
      const totalActive = series.active.reduce((a,b) => a + b, 0);
      const avgActive = series.active.length ? (totalActive / series.active.length) : 0;
      const totalDistance = series.distance.reduce((a,b) => a + b, 0);
      const avgDistance = series.distance.length ? (totalDistance / series.distance.length) : 0;
      const totalWorkouts = series.workouts.reduce((a,b) => a + b, 0);
      const avgWorkouts = series.labels.length ? (totalWorkouts / series.labels.length) : 0;
      const stepsCard = document.getElementById('stepsCard');
      const stepsAvgCard = document.getElementById('stepsAvgCard');
      const activeCard = document.getElementById('activeCard');
      const activeAvgCard = document.getElementById('activeAvgCard');
      const distanceCard = document.getElementById('distanceCard');
      const distanceAvgCard = document.getElementById('distanceAvgCard');
      const workoutsCard = document.getElementById('workoutsCard');
      const workoutsAvgCard = document.getElementById('workoutsAvgCard');
      const stepsAvgOnlyCard = document.getElementById('stepsAvgOnlyCard');
      if (stepsCard) stepsCard.textContent = totalSteps.toLocaleString();
      if (stepsAvgCard) stepsAvgCard.textContent = 'Avg/day: ' + avgSteps.toLocaleString();
      if (activeCard) activeCard.textContent = Math.round(totalActive).toLocaleString();
      if (activeAvgCard) activeAvgCard.textContent = 'Avg/day: ' + avgActive.toFixed(1);
      if (distanceCard) distanceCard.textContent = totalDistance.toFixed(1) + ' km';
      if (distanceAvgCard) distanceAvgCard.textContent = 'Avg/day: ' + avgDistance.toFixed(1) + ' km';
      if (workoutsCard) workoutsCard.textContent = totalWorkouts.toLocaleString();
      if (workoutsAvgCard) workoutsAvgCard.textContent = 'Avg/day: ' + avgWorkouts.toFixed(2);
      if (stepsAvgOnlyCard) stepsAvgOnlyCard.textContent = avgSteps.toLocaleString();
    }}

    function applyWindow(days) {{
      const series = sliceForWindow(days);
      if (stepsChart) {{
        stepsChart.data.labels = series.labels;
        stepsChart.data.datasets[0].data = series.steps;
        stepsChart.update();
      }}
      if (energyChart) {{
        energyChart.data.labels = series.labels;
        energyChart.data.datasets[0].data = series.energy;
        energyChart.update();
      }}
      if (moveChart) {{
        moveChart.data.labels = series.labels;
        moveChart.data.datasets[0].data = series.move;
        moveChart.update();
      }}
      if (briskChart) {{
        briskChart.data.labels = series.labels;
        briskChart.data.datasets[0].data = series.brisk;
        briskChart.update();
      }}
      if (activeChart) {{
        activeChart.data.labels = series.labels;
        activeChart.data.datasets[0].data = series.active;
        activeChart.update();
      }}
      if (distanceChart) {{
        distanceChart.data.labels = series.labels;
        distanceChart.data.datasets[0].data = series.distance;
        distanceChart.update();
      }}
      if (flightsChart) {{
        flightsChart.data.labels = series.labels;
        flightsChart.data.datasets[0].data = series.flights;
        flightsChart.update();
      }}
      updateSummaryCards(series);
    }}

    document.querySelectorAll('#windowToggles button').forEach(btn => {{
      btn.addEventListener('click', () => {{
        document.querySelectorAll('#windowToggles button').forEach(el => el.classList.remove('active'));
        btn.classList.add('active');
        const days = parseInt(btn.getAttribute('data-window'), 10);
        applyWindow(days);
      }});
    }});

    applyWindow(30);

    if (window.self !== window.top) {{
      document.body.classList.add('embedded');
    }}
  </script>
</body>
</html>
"""

        with open(html_path, "w", encoding="utf-8") as f:
            f.write(html)
        self._add_export_bytes(html_path)

        return True

    def get_item_summary(self, item: Dict[str, Any]) -> str:
        return f"{item.get('category', 'Health')} entry"

    @staticmethod
    def _escape_html(text: str) -> str:
        if not text:
            return ""
        text = str(text)
        return (text.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;"))
