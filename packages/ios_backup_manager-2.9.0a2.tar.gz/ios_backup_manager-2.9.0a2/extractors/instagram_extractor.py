#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Instagram Direct Messages extractor for iOS backups - Integration wrapper.

This extractor wraps the third_party InstagramExtractor and provides
compatibility with the iOS Backup Manager extraction framework.
"""

import os
import sys
import sqlite3
import glob
from typing import List, Dict, Any, Optional
from datetime import datetime

from .base import CategoryDataExtractor


class InstagramExtractor(CategoryDataExtractor):
    """
    Extract Instagram Direct messages from iOS backups.

    Finds Instagram Direct database in backup and exports conversations
    to HTML format (similar to WhatsApp and SMS).
    """

    # Instagram app domain
    INSTAGRAM_DOMAIN = "AppDomain-com.burbn.instagram"

    def __init__(self, backup_path: str):
        """
        Initialize Instagram extractor.

        Args:
            backup_path: Path to iOS backup directory

        Raises:
            FileNotFoundError: If Instagram database not found in backup
        """
        super().__init__(backup_path)

        # Find Instagram Direct database in backup
        # Instagram stores databases with names like "5620318585.db" (user ID)
        self.instagram_db_path = self._find_instagram_db()

        if not self.instagram_db_path:
            raise FileNotFoundError("Instagram Direct database not found in backup")

    def _find_instagram_db(self) -> Optional[str]:
        """
        Find Instagram Direct Messages database.

        Instagram stores Direct messages in databases named by user ID (e.g., 5620318585.db).
        Look for files matching this pattern in the Instagram domain.
        """
        # Try to find database files in Instagram domain
        # Pattern: digits.db (e.g., 5620318585.db)
        domain_path = self.manifest_db_path

        if not os.path.exists(domain_path):
            return None

        try:
            import sqlite3
            conn = sqlite3.connect(f"file:{domain_path}?mode=ro", uri=True)
            cur = conn.cursor()

            # Find files in Instagram domain that look like Direct DB
            cur.execute("""
                SELECT fileID, relativePath
                FROM Files
                WHERE domain = ? AND relativePath LIKE '%.db'
                AND (relativePath LIKE '%/%.db' OR relativePath NOT LIKE '%/%')
                ORDER BY relativePath
            """, (self.INSTAGRAM_DOMAIN,))

            for row in cur.fetchall():
                file_id, rel_path = row
                # Check if filename is all digits (user ID database)
                filename = os.path.basename(rel_path)
                if filename.replace('.db', '').isdigit():
                    # Found a potential Direct messages database
                    file_hash = file_id
                    physical_path = self._resolve_file_id_path(file_hash)
                    if physical_path and os.path.exists(physical_path):
                        # Verify it has messages table
                        try:
                            test_conn = sqlite3.connect(f"file:{physical_path}?mode=ro", uri=True)
                            test_cur = test_conn.cursor()
                            test_cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='messages'")
                            if test_cur.fetchone():
                                test_conn.close()
                                conn.close()
                                return physical_path
                            test_conn.close()
                        except Exception:
                            pass

            conn.close()

        except Exception as e:
            print(f"Error finding Instagram database: {e}")

        return None

    def get_count(self) -> int:
        """Get total number of conversation threads."""
        try:
            conn = sqlite3.connect(f"file:{self.instagram_db_path}?mode=ro", uri=True)
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) FROM threads")
            count = cur.fetchone()[0]
            conn.close()
            return count
        except Exception:
            return 0

    def get_item_summary(self, item: Dict[str, Any]) -> str:
        """Get a short summary string for displaying in list view."""
        thread_name = item.get('thread_name', 'Unknown')
        message_count = item.get('message_count', 0)
        return f"{thread_name} - {message_count} messages"

    def get_items(self, limit: Optional[int] = None, offset: int = 0, search: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get list of conversations with metadata.

        Args:
            limit: Maximum number of conversations to return
            offset: Number of conversations to skip
            search: Search filter (searches thread IDs)

        Returns:
            List of conversation dicts with thread_id, thread_name, message_count
        """
        try:
            conn = sqlite3.connect(f"file:{self.instagram_db_path}?mode=ro", uri=True)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()

            # Build query
            query = """
                SELECT
                    t.thread_id,
                    t.thread_id_v2,
                    t.viewer_id,
                    (SELECT COUNT(*) FROM messages m WHERE m.thread_id = t.thread_id) as message_count
                FROM threads t
                WHERE 1=1
            """

            params = []
            if search:
                query += " AND (t.thread_id LIKE ? OR t.thread_id_v2 LIKE ?)"
                search_pattern = f"%{search}%"
                params.extend([search_pattern, search_pattern])

            query += " ORDER BY t.row_id DESC"

            if limit is not None:
                query += f" LIMIT {limit} OFFSET {offset}"

            cur.execute(query, params)
            rows = cur.fetchall()

            conversations = []
            for row in rows:
                # Use thread_id_v2 as display name if available
                thread_name = row['thread_id_v2'] if row['thread_id_v2'] else f"Thread {row['thread_id']}"

                conversations.append({
                    'thread_id': row['thread_id'],
                    'thread_name': thread_name,
                    'viewer_id': row['viewer_id'],
                    'message_count': row['message_count']
                })

            conn.close()
            return conversations

        except Exception as e:
            print(f"Error getting Instagram conversations: {e}")
            return []

    def export(self, items: List[Dict[str, Any]], output_path: str, format: str = 'html', progress_callback=None, timeline_emitter=None) -> bool:
        """
        Export Instagram Direct conversations to HTML files.

        Creates:
        - Instagram.html: Index of all conversations
        - Conversations/: Individual conversation HTML files

        Args:
            items: List of conversations from get_items()
            output_path: Output directory path
            format: Export format ('html')
            progress_callback: Optional callback(current, total, item_name) -> bool

        Returns:
            True if export succeeded
        """
        if format not in ('html', 'files'):
            raise ValueError(f"Unsupported export format: {format}")

        self._reset_export_bytes()
        # Create output structure
        os.makedirs(output_path, exist_ok=True)
        conversations_dir = os.path.join(output_path, "Conversations")
        os.makedirs(conversations_dir, exist_ok=True)

        # Import the core instagram extractor
        from third_party.instagram_extractor import InstagramExtractor as CoreInstagramExtractor

        # Create core extractor instance
        core_extractor = CoreInstagramExtractor(self.instagram_db_path)

        # Export each conversation
        total = len(items)
        conversation_files = []

        for idx, conversation in enumerate(items):
            thread_id = conversation['thread_id']
            thread_name = conversation['thread_name']

            # Progress callback
            if progress_callback:
                if not progress_callback(idx + 1, total, thread_name):
                    return False  # Cancelled

            # Generate safe filename
            safe_name = self._sanitize_filename(thread_name)
            html_filename = f"{thread_id[:20]}_{safe_name}.html"
            html_path = os.path.join(conversations_dir, html_filename)

            # Extract messages for this conversation
            messages = []
            for msg in core_extractor.iter_messages():
                if msg['conversation_id'] == thread_id:
                    messages.append(msg)

            if not messages:
                continue

            # Generate conversation HTML
            self._generate_conversation_html(
                html_path,
                thread_name,
                messages
            )

            if timeline_emitter is not None:
                self._emit_message_timeline_events(messages, thread_name, html_filename, timeline_emitter)

            search_text = " ".join([msg.get("text") for msg in messages if msg.get("text")])[:4000].lower()
            conversation_files.append({
                'thread_id': thread_id,
                'thread_name': thread_name,
                'message_count': len(messages),
                'filename': html_filename,
                'search_text': search_text
            })

        # Generate index HTML
        index_path = os.path.join(output_path, "Instagram.html")
        self._generate_index_html(index_path, conversation_files)

        return True

    def _generate_conversation_html(self, output_path: str, conversation_name: str, messages: List[Dict[str, Any]]):
        """Generate HTML file for a single conversation."""
        html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{self._escape_html(conversation_name)} - Instagram Direct</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: #f6f6f6;
            padding: 20px;
        }}
        .container {{
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            overflow: hidden;
        }}
        .header {{
            background: linear-gradient(135deg, #6D20FF 0%, #F021D9 100%);
            color: white;
            padding: 30px;
            text-align: left;
        }}
        .header h1 {{
            margin: 0 0 10px 0;
            font-size: 32px;
            font-weight: 600;
        }}
        .header p {{
            margin: 0;
            font-size: 16px;
            opacity: 0.9;
        }}
        .breadcrumbs {{
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            letter-spacing: 0.2px;
            color: rgba(255,255,255,0.85);
            margin-bottom: 10px;
        }}
        .breadcrumbs a {{
            color: #fff;
            text-decoration: none;
            font-weight: 600;
        }}
        .breadcrumbs a:hover {{
            text-decoration: underline;
        }}
        .breadcrumbs .back-arrow {{
            opacity: 0.6;
        }}
        .embedded .breadcrumbs {{
            display: none;
        }}
        .conversation {{
            background: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
        }}
        .message {{
            margin: 15px 0;
            display: flex;
            flex-direction: column;
        }}
        .highlight-target {{
            background-color: #fff3cd;
            outline: 2px solid #f59e0b;
        }}
        .highlight-target .message-bubble {{
            background-color: #fff3cd;
            color: #111827;
        }}
        .search-hit {{
            background: #ffe6fb;
            padding: 0 2px;
            border-radius: 3px;
        }}
        .search-hit-block {{
            background: rgba(240, 33, 217, 0.08);
            border-radius: 10px;
            outline: 2px solid rgba(240, 33, 217, 0.25);
        }}
        .message.outgoing {{
            align-items: flex-end;
        }}
        .message.incoming {{
            align-items: flex-start;
        }}
        .message-bubble {{
            max-width: 70%;
            padding: 10px 15px;
            border-radius: 18px;
            word-wrap: break-word;
        }}
        .message.outgoing .message-bubble {{
            background: #6D20FF;
            color: white;
        }}
        .message.incoming .message-bubble {{
            background: #efefef;
            color: #262626;
        }}
        .message-meta {{
            font-size: 11px;
            color: #8e8e8e;
            margin-top: 4px;
        }}
        .sender-name {{
            font-weight: 600;
            margin-bottom: 4px;
            font-size: 12px;
            color: #8e8e8e;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Instagram.html">Back to conversations</a></div>
            <h1>{self._escape_html(conversation_name)}</h1>
            <p>{len(messages)} messages</p>
        </div>
        <div class="conversation">
"""

        for msg in messages:
            direction_class = "outgoing" if msg['direction'] == "outgoing" else "incoming"
            sender = msg.get('sender_display_name', 'Unknown')
            timestamp = msg['timestamp'].strftime("%b %d, %Y at %I:%M %p")
            text = self._escape_html(msg.get('text', '[No text]'))

            html += f"""
        <div class="message {direction_class}" id="msg-{msg.get('message_id')}">
"""
            if msg['direction'] == "incoming":
                html += f"""
            <div class="sender-name">{self._escape_html(sender)}</div>
"""
            html += f"""
            <div class="message-bubble">{text}</div>
            <div class="message-meta">{timestamp}</div>
        </div>
"""

        html += """
    </div>  <!-- Close conversation -->
    </div>  <!-- Close container -->
<script>
    (function() {
        if (!window.location.hash) return;
        const target = document.querySelector(window.location.hash);
        if (!target) return;
        target.classList.add('highlight-target');
        try {
            target.scrollIntoView({ block: 'center' });
        } catch (e) {
            target.scrollIntoView();
        }
    })();
</script>
<script>
    (function() {
        const params = new URLSearchParams(window.location.search);
        const term = (params.get('q') || '').trim();
        if (!term) return;

        function highlightInElement(element, query) {
            const needle = query.toLowerCase();
            const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT, {
                acceptNode(node) {
                    if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
                    const parent = node.parentElement;
                    if (!parent) return NodeFilter.FILTER_REJECT;
                    if (parent.classList && parent.classList.contains('search-hit')) return NodeFilter.FILTER_REJECT;
                    return NodeFilter.FILTER_ACCEPT;
                }
            });
            const nodes = [];
            let node;
            while ((node = walker.nextNode())) {
                if (node.nodeValue.toLowerCase().includes(needle)) {
                    nodes.push(node);
                }
            }
            nodes.forEach(textNode => {
                const text = textNode.nodeValue;
                const lower = text.toLowerCase();
                const frag = document.createDocumentFragment();
                let lastIndex = 0;
                let idx = lower.indexOf(needle, lastIndex);
                while (idx !== -1) {
                    const before = text.slice(lastIndex, idx);
                    if (before) frag.appendChild(document.createTextNode(before));
                    const mark = document.createElement('mark');
                    mark.className = 'search-hit';
                    mark.textContent = text.slice(idx, idx + needle.length);
                    frag.appendChild(mark);
                    lastIndex = idx + needle.length;
                    idx = lower.indexOf(needle, lastIndex);
                }
                const after = text.slice(lastIndex);
                if (after) frag.appendChild(document.createTextNode(after));
                textNode.parentNode.replaceChild(frag, textNode);
            });
        }

        const targets = document.querySelectorAll('.message-bubble');
        targets.forEach(el => highlightInElement(el, term));
        document.querySelectorAll('.search-hit').forEach(mark => {
            const block = mark.closest('.message');
            if (block) block.classList.add('search-hit-block');
        });

        function scrollToFirstHit() {
            const first = document.querySelector('.search-hit');
            if (!first) return;
            try {
                first.scrollIntoView({ block: 'center' });
            } catch (e) {
                first.scrollIntoView();
            }
        }

        scrollToFirstHit();
        requestAnimationFrame(() => {
            scrollToFirstHit();
            setTimeout(scrollToFirstHit, 250);
        });
    })();
</script>
<script>
(function() {
    try {
        if (window.parent && window.parent !== window) {
            window.parent.postMessage({type: 'device-nav', href: window.location.href}, '*');
        }
    } catch (err) {}
})();
</script>
</body>
</html>
"""

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html)
        self._add_export_bytes(output_path)

    def _emit_message_timeline_events(self, messages: List[Dict[str, Any]], conversation_name: str,
                                      html_filename: str, timeline_emitter) -> None:
        link_hint = f"Instagram/Conversations/{html_filename}"
        for msg in messages:
            ts = msg.get('timestamp')
            if isinstance(ts, datetime):
                ts_iso = ts.isoformat()
            else:
                ts_iso = None
            if not ts_iso:
                continue
            text = msg.get('text') or ''
            details = {
                'conversation': conversation_name,
                'direction': msg.get('direction') or '',
                'text': text[:200] if text else '',
            }
            timeline_emitter.emit({
                'timestamp': ts_iso,
                'raw_timestamp': ts.isoformat() if isinstance(ts, datetime) else ts,
                'raw_format': 'datetime',
                'source_app': 'Instagram',
                'source_category': 'Instagram',
                'event_type': 'message',
                'title': conversation_name or 'Instagram Direct',
                'details': details,
                'confidence': 'high',
                'raw_source_path': self.instagram_db_path,
                'report_anchor': f"msg-{msg.get('message_id')}",
                'link_hint': link_hint,
            })

    def _generate_index_html(self, output_path: str, conversations: List[Dict[str, Any]]):
        """Generate index HTML with list of all conversations."""
        html = """<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Instagram Direct Messages</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: #f6f6f6;
            padding: 20px;
        }
        .container {
            max-width: 1000px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #6D20FF 0%, #F021D9 100%);
            color: white;
            padding: 30px;
            text-align: left;
        }
        .header h1 {
            margin: 0 0 10px 0;
            font-size: 32px;
            font-weight: 600;
        }
        .breadcrumbs {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            letter-spacing: 0.2px;
            color: rgba(255,255,255,0.85);
            margin-bottom: 10px;
        }
        .breadcrumbs a {
            color: #fff;
            text-decoration: none;
            font-weight: 600;
        }
        .breadcrumbs a:hover {
            text-decoration: underline;
        }
        .breadcrumbs .back-arrow {
            opacity: 0.6;
        }
        .embedded .breadcrumbs {
            display: none;
        }
        .header p {
            margin: 0;
            font-size: 16px;
            opacity: 0.9;
        }
        .search-box {
            position: relative;
            padding: 20px;
            border-bottom: 1px solid #e5e5e5;
        }
        .search-box input {
            width: 100%;
            padding: 12px 46px 12px 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            box-sizing: border-box;
        }
        .search-box input:focus {
            outline: none;
            border-color: #6D20FF;
        }
        .clear-search {
            position: absolute;
            right: 24px;
            top: 50%;
            transform: translateY(-50%);
            border: 1px solid #d1d5db;
            background: #f3f4f6;
            color: #111827;
            border-radius: 6px;
            padding: 4px 8px;
            font-size: 12px;
            cursor: pointer;
            display: none;
        }
        .clear-search.visible { display: inline-block; }
        .no-results {
            display: none;
            text-align: center;
            padding: 40px;
            color: #999;
            font-size: 16px;
        }
        .conversations {
            background: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
        }
        .conversation-item {
            padding: 15px;
            border-bottom: 1px solid #efefef;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .conversation-item:last-child {
            border-bottom: none;
        }
        .conversation-item:hover {
            background: #fafafa;
        }
        .conversation-name {
            font-weight: 600;
            color: #262626;
        }
        .conversation-count {
            color: #8e8e8e;
            font-size: 14px;
        }
        a {
            text-decoration: none;
            color: inherit;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Start_Here.html">Back</a></div>
            <h1>Instagram Direct</h1>
            <p>Extracted from iOS Backup on """ + datetime.now().strftime("%B %d, %Y") + """ - """ + str(len(conversations)) + """ conversations</p>
        </div>

        <div class="search-box">
            <input type="text" id="searchInput" placeholder="Search conversations..." onkeyup="filterConversations()">
            <button id="clearSearch" class="clear-search" title="Clear" aria-label="Clear search">X</button>
        </div>

        <div class="conversations" id="conversationList">
"""

        for conv in conversations:
            html += f"""
        <div class="conversation-item" data-name="{self._escape_html(conv['thread_name'].lower())}" data-search="{self._escape_html((conv.get('search_text') or '').lower())}">
            <a href="Conversations/{conv['filename']}" style="flex: 1;">
                <div class="conversation-name">{self._escape_html(conv['thread_name'])}</div>
                <div class="conversation-count">{conv['message_count']} messages</div>
            </a>
        </div>
"""

        html += """
        </div>  <!-- Close conversations -->
        <div class="no-results" id="noResults">No conversations found</div>
    </div>  <!-- Close container -->

    <script>
        function filterConversations() {
            const input = document.getElementById('searchInput');
            const clearBtn = document.getElementById('clearSearch');
            const rawTerm = input.value.trim();
            const filter = rawTerm.toLowerCase();
            const conversations = document.querySelectorAll('.conversation-item');
            const noResults = document.getElementById('noResults');

            let visibleCount = 0;

            conversations.forEach(conv => {
                const name = conv.getAttribute('data-name');
                const searchText = conv.getAttribute('data-search') || '';
                const link = conv.tagName === 'A' ? conv : conv.querySelector('a');
                if (link) {
                    if (!link.dataset.baseHref) {
                        link.dataset.baseHref = link.getAttribute('href');
                    }
                    if (rawTerm) {
                        link.setAttribute('href', `${link.dataset.baseHref}?q=${encodeURIComponent(rawTerm)}`);
                    } else {
                        link.setAttribute('href', link.dataset.baseHref);
                    }
                }

                if (name.includes(filter) || searchText.includes(filter)) {
                    conv.style.display = '';
                    visibleCount++;
                } else {
                    conv.style.display = 'none';
                }
            });

            // Show "no results" message if nothing is visible
            if (visibleCount === 0 && filter !== '') {
                noResults.style.display = 'block';
            } else {
                noResults.style.display = 'none';
            }
            if (clearBtn) {
                clearBtn.classList.toggle('visible', !!rawTerm);
            }
        }
    </script>
    <script>
        const igSearchInput = document.getElementById('searchInput');
        const igClearBtn = document.getElementById('clearSearch');
        if (igSearchInput && igClearBtn) {
            const toggleClear = () => igClearBtn.classList.toggle('visible', !!igSearchInput.value);
            igSearchInput.addEventListener('input', toggleClear);
            igClearBtn.addEventListener('click', () => {
                igSearchInput.value = '';
                toggleClear();
                if (typeof filterConversations === 'function') {
                    filterConversations();
                }
                igSearchInput.focus();
            });
            toggleClear();
        }
    </script>
    <script>
        (function() {
            try {
                if (window.parent && window.parent !== window) {
                    window.parent.postMessage({type: 'device-nav-root', href: window.location.href}, '*');
                    window.parent.postMessage({type: 'device-nav', href: window.location.href}, '*');
                }
            } catch (err) {}
        })();
    </script>
    <script>
        if (window.self !== window.top) {
            document.body.classList.add('embedded');
        }
    </script>
</body>
</html>
"""

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html)
        self._add_export_bytes(output_path)

    def _sanitize_filename(self, name: str) -> str:
        """Sanitize name for use in filename."""
        # Remove invalid filename characters
        invalid_chars = '<>:"/\\|?*'
        for char in invalid_chars:
            name = name.replace(char, '_')
        # Limit length
        return name[:100]

    def _escape_html(self, text: str) -> str:
        """Escape HTML special characters."""
        if not text:
            return ''
        return (text
                .replace('&', '&amp;')
                .replace('<', '&lt;')
                .replace('>', '&gt;')
                .replace('"', '&quot;')
                .replace("'", '&#39;'))
