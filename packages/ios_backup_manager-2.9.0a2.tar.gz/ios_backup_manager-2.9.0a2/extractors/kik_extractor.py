#!/usr/bin/env python3
"""
Kik data extractor for iOS backups.

Extracts chats, messages, and attachments from Kik's kik.sqlite database
and exports an HTML report similar to WhatsApp/SMS.
"""

import os
import re
import html
import sqlite3
import shutil
import plistlib
from typing import List, Dict, Any, Optional
from datetime import datetime, timezone

from .base import CategoryDataExtractor


class KikExtractor(CategoryDataExtractor):
    """Extract and export Kik data from iOS backups."""

    KIK_DOMAIN = "AppDomain-com.kik.chat"
    KIK_GROUP_DOMAIN = "AppDomainGroup-group.com.kik.chat"

    def __init__(self, backup_path: str):
        super().__init__(backup_path)

        self.kik_db_path = self._find_kik_db()
        if not self.kik_db_path:
            raise FileNotFoundError("Kik database not found in backup")

        self.kik_root_rel = self._find_kik_root_rel()
        self._self_username = self._load_self_username()

    def _find_kik_db(self) -> Optional[str]:
        conn = sqlite3.connect(f"file:{self.manifest_db_path}?mode=ro", uri=True)
        try:
            cur = conn.cursor()
            cur.execute("""
                SELECT fileID, relativePath
                FROM Files
                WHERE domain = ?
                AND relativePath LIKE '%kik.sqlite'
                ORDER BY relativePath DESC
                LIMIT 1
            """, (self.KIK_GROUP_DOMAIN,))
            row = cur.fetchone()
            if row:
                file_id, rel_path = row
                return self._resolve_file_id_path(file_id)
        finally:
            conn.close()
        return None

    def _find_kik_root_rel(self) -> Optional[str]:
        conn = sqlite3.connect(f"file:{self.manifest_db_path}?mode=ro", uri=True)
        try:
            cur = conn.cursor()
            cur.execute("""
                SELECT relativePath
                FROM Files
                WHERE domain = ?
                AND relativePath LIKE '%kik.sqlite'
                ORDER BY relativePath DESC
                LIMIT 1
            """, (self.KIK_GROUP_DOMAIN,))
            row = cur.fetchone()
            if not row:
                return None
            rel_path = row[0]
        finally:
            conn.close()

        # kik.sqlite lives under cores/private/<core_id>/
        return os.path.dirname(rel_path)

    def _load_self_username(self) -> Optional[str]:
        prefs_path = self.find_file_in_backup(
            self.KIK_GROUP_DOMAIN,
            "Library/Preferences/group.com.kik.chat.plist"
        )
        if not prefs_path or not os.path.exists(prefs_path):
            return None
        try:
            with open(prefs_path, "rb") as f:
                data = plistlib.load(f)
            for key, value in data.items():
                if key.endswith(":username") and isinstance(value, str) and value:
                    return value
        except Exception:
            return None
        return None

    def _format_kik_timestamp(self, timestamp: Optional[float]) -> Optional[datetime]:
        if timestamp is None or timestamp == 0:
            return None
        try:
            apple_epoch = datetime(2001, 1, 1, tzinfo=timezone.utc).timestamp()
            unix_timestamp = apple_epoch + float(timestamp)
            return datetime.fromtimestamp(unix_timestamp)
        except Exception:
            return None

    def _escape_html(self, text: str) -> str:
        if not text:
            return ''
        return (str(text)
                .replace('&', '&amp;')
                .replace('<', '&lt;')
                .replace('>', '&gt;')
                .replace('"', '&quot;')
                .replace("'", '&#39;')
                .replace('\n', '<br>'))

    def _guess_extension(self, path: str) -> str:
        try:
            with open(path, "rb") as f:
                head = f.read(12)
            if head.startswith(b"\xff\xd8\xff"):
                return ".jpg"
            if head.startswith(b"\x89PNG\r\n\x1a\n"):
                return ".png"
            if head.startswith(b"GIF87a") or head.startswith(b"GIF89a"):
                return ".gif"
        except Exception:
            return ""
        return ""

    def _is_image_file(self, filename: str) -> bool:
        ext = os.path.splitext(filename or "")[1].lower()
        return ext in (".jpg", ".jpeg", ".png", ".gif", ".heic", ".webp")

    def _parse_attachment_plist(self, path: str) -> Dict[str, str]:
        try:
            with open(path, "rb") as f:
                data = plistlib.load(f)
            out = {}
            for entry in data.get("string", []):
                name = entry.get("name")
                value = entry.get("value")
                if name and isinstance(value, str):
                    out[name] = value
            return out
        except Exception:
            return {}

    def _resolve_attachment(self, content_id: str, output_dir: str) -> Optional[Dict[str, str]]:
        if not self.kik_root_rel:
            return None
        data_rel = os.path.join(self.kik_root_rel, "content_manager", "data_cache", content_id).replace("\\", "/")
        meta_rel = os.path.join(self.kik_root_rel, "attachments", content_id).replace("\\", "/")
        data_path = self.find_file_in_backup(self.KIK_GROUP_DOMAIN, data_rel)
        meta_path = self.find_file_in_backup(self.KIK_GROUP_DOMAIN, meta_rel)
        if not data_path or not os.path.exists(data_path):
            return None

        meta = self._parse_attachment_plist(meta_path) if meta_path else {}
        filename = meta.get("file-name", "")
        ext = os.path.splitext(filename)[1] if filename else self._guess_extension(data_path)
        if not ext:
            ext = ".bin"

        safe_name = f"{content_id}{ext}"
        dest_path = os.path.join(output_dir, safe_name)
        if not os.path.exists(dest_path):
            shutil.copy2(data_path, dest_path)
        self._add_export_bytes(dest_path)
        return {
            "content_id": content_id,
            "file_name": safe_name,
            "file_url": meta.get("file-url", ""),
        }

    def get_total_message_count(self) -> int:
        conn = sqlite3.connect(self.kik_db_path)
        try:
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) FROM ZKIKMESSAGE")
            return cur.fetchone()[0]
        finally:
            conn.close()

    def get_conversations(self, limit: Optional[int] = None, offset: int = 0,
                          search: Optional[str] = None) -> List[Dict[str, Any]]:
        conn = sqlite3.connect(self.kik_db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        search_condition = ""
        params: List[Any] = []
        if search:
            search_condition = "WHERE u.ZDISPLAYNAME LIKE ? OR u.ZUSERNAME LIKE ? OR u.ZJID LIKE ?"
            pattern = f"%{search}%"
            params.extend([pattern, pattern, pattern])

        cur.execute(f"""
            SELECT c.Z_PK as chat_id, c.ZLASTMESSAGE, c.ZDATEUPDATED,
                   u.ZDISPLAYNAME, u.ZUSERNAME, u.ZJID
            FROM ZKIKCHAT c
            LEFT JOIN ZKIKUSER u ON u.Z_PK = c.ZUSER
            {search_condition}
            ORDER BY c.ZDATEUPDATED DESC
        """, params)

        chats = cur.fetchall()
        results = []
        for row in chats:
            chat_id = row["chat_id"]
            cur.execute("SELECT COUNT(*) FROM Z_4MESSAGES WHERE Z_4CHAT = ?", (chat_id,))
            message_count = cur.fetchone()[0]
            last_message = ""
            last_message_date = None
            if row["ZLASTMESSAGE"]:
                cur.execute("SELECT ZBODY, ZTIMESTAMP FROM ZKIKMESSAGE WHERE Z_PK = ?", (row["ZLASTMESSAGE"],))
                last_row = cur.fetchone()
                if last_row:
                    last_message = last_row[0] or ""
                    last_message_date = last_row[1]
            display_name = row["ZDISPLAYNAME"] or row["ZUSERNAME"] or row["ZJID"] or "Unknown"
            results.append({
                "chat_id": chat_id,
                "display_name": display_name,
                "last_message": last_message,
                "last_message_date": last_message_date,
                "message_count": message_count,
                "user_jid": row["ZJID"] or "",
            })

        conn.close()
        if offset:
            results = results[offset:]
        if limit:
            results = results[:limit]
        return results

    def _load_messages_for_chat(self, chat_id: int) -> List[Dict[str, Any]]:
        conn = sqlite3.connect(self.kik_db_path)
        conn.row_factory = sqlite3.Row
        try:
            cur = conn.cursor()
            cur.execute("""
                SELECT m.Z_PK, m.ZBODY, m.ZTIMESTAMP, m.ZTYPE, m.ZSTATE, m.ZUSER,
                       u.ZDISPLAYNAME, u.ZUSERNAME, u.ZJID
                FROM Z_4MESSAGES cm
                JOIN ZKIKMESSAGE m ON m.Z_PK = cm.Z_6MESSAGES
                LEFT JOIN ZKIKUSER u ON u.Z_PK = m.ZUSER
                WHERE cm.Z_4CHAT = ?
                ORDER BY m.ZTIMESTAMP ASC
            """, (chat_id,))
            messages = [dict(r) for r in cur.fetchall()]

            # Attachments
            msg_ids = [m["Z_PK"] for m in messages]
            attachments = {}
            if msg_ids:
                placeholders = ",".join(["?"] * len(msg_ids))
                cur.execute(f"""
                    SELECT ZMESSAGE, ZCONTENT
                    FROM ZKIKATTACHMENT
                    WHERE ZMESSAGE IN ({placeholders})
                """, msg_ids)
                for row in cur.fetchall():
                    attachments.setdefault(row["ZMESSAGE"], []).append(row["ZCONTENT"])
            for msg in messages:
                msg["attachments"] = attachments.get(msg["Z_PK"], [])
            return messages
        finally:
            conn.close()

    def get_count(self) -> int:
        return self.get_total_message_count()

    def get_items(self, limit: Optional[int] = None, offset: int = 0, **kwargs) -> List[Dict[str, Any]]:
        search = kwargs.get("search")
        return self.get_conversations(limit, offset, search)

    def get_item_summary(self, item: Dict[str, Any]) -> str:
        return f"{item['display_name']} - {item.get('last_message', '')[:50]}"

    def _load_call_history(self) -> List[Dict[str, Any]]:
        conn = sqlite3.connect(self.kik_db_path)
        conn.row_factory = sqlite3.Row
        try:
            cur = conn.cursor()
            cur.execute("""
                SELECT m.ZTIMESTAMP, m.ZTYPE, m.ZBODY, u.ZDISPLAYNAME, u.ZUSERNAME, u.ZJID
                FROM ZKIKMESSAGE m
                LEFT JOIN ZKIKUSER u ON u.Z_PK = m.ZUSER
                WHERE m.ZTYPE = 5
                ORDER BY m.ZTIMESTAMP DESC
            """)
            calls = []
            for row in cur.fetchall():
                name = row["ZDISPLAYNAME"] or row["ZUSERNAME"] or row["ZJID"] or "Unknown"
                calls.append({
                    "name": name,
                    "timestamp": row["ZTIMESTAMP"],
                    "body": row["ZBODY"] or "Call event",
                })
            return calls
        finally:
            conn.close()

    def export(self, items: List[Dict[str, Any]], output_path: str, format: str = 'html',
               progress_callback=None, skip_attachments: bool = False, timeline_emitter=None) -> bool:
        if format not in ('html', 'files'):
            raise ValueError(f"Unsupported export format: {format}")
        try:
            self._reset_export_bytes()
            os.makedirs(output_path, exist_ok=True)
            conversations_dir = os.path.join(output_path, "Conversations")
            os.makedirs(conversations_dir, exist_ok=True)
            attachments_dir = os.path.join(output_path, "Kik Attachments")
            os.makedirs(attachments_dir, exist_ok=True)

            used_filenames = set()
            conversation_list = []
            total = len(items) + 1

            for i, item in enumerate(items):
                if isinstance(item, dict):
                    chat_id = item["chat_id"]
                    display_name = item["display_name"]
                    last_message = item.get("last_message", "")
                    last_message_date = item.get("last_message_date", 0)
                    message_count = item.get("message_count", 0)
                else:
                    chat_id = item
                    display_name = f"Chat {chat_id}"
                    last_message = ""
                    last_message_date = 0
                    message_count = 0

                filename_base = display_name.replace("/", "_").replace("\\", "_")
                filename = f"{filename_base}.html"
                if filename in used_filenames:
                    filename = f"{filename_base}_{chat_id}.html"
                used_filenames.add(filename)
                out_file = os.path.join(conversations_dir, filename)

                messages = self._load_messages_for_chat(chat_id)
                if timeline_emitter is not None:
                    self._emit_message_timeline_events(messages, display_name, filename, attachments_dir, timeline_emitter)
                html = self._render_conversation_html(display_name, messages, attachments_dir, skip_attachments)
                with open(out_file, "w", encoding="utf-8") as f:
                    f.write(html)
                self._add_export_bytes(out_file)

                conversation_list.append({
                    "display_name": display_name,
                    "filename": filename,
                    "last_message": last_message,
                    "last_message_date": last_message_date,
                    "message_count": message_count,
                })

                if progress_callback:
                    progress_callback(i + 1, total, display_name)

            index_html = self._render_index_html(conversation_list, output_path)
            index_path = os.path.join(output_path, "Kik.html")
            with open(index_path, "w", encoding="utf-8") as f:
                f.write(index_html)
            self._add_export_bytes(index_path)

            if progress_callback:
                progress_callback(total, total, "Index")
            return True
        except Exception as e:
            print(f"Error exporting Kik: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _message_direction(self, msg: Dict[str, Any]) -> str:
        if self._self_username:
            username = (msg.get("ZUSERNAME") or "").lower()
            if username and username == self._self_username.lower():
                return "sent"
        ztype = msg.get("ZTYPE")
        if ztype == 1:
            return "sent"
        if ztype == 2:
            return "received"
        return "system"

    def _format_timestamp_iso(self, timestamp: Optional[float]) -> Optional[str]:
        dt = self._format_kik_timestamp(timestamp)
        if not dt:
            return None
        return dt.isoformat()

    def _emit_message_timeline_events(self, messages: List[Dict[str, Any]], conversation_name: str,
                                      html_filename: str, attachments_dir: str, timeline_emitter) -> None:
        link_hint = f"Kik/Conversations/{html_filename}"
        for msg in messages:
            ts_iso = self._format_timestamp_iso(msg.get("ZTIMESTAMP"))
            if not ts_iso:
                continue
            text = msg.get("ZBODY") or ""
            details = {
                "conversation": conversation_name,
                "direction": self._message_direction(msg),
                "text": text[:200] if text else "",
            }
            timeline_emitter.emit({
                "timestamp": ts_iso,
                "raw_timestamp": msg.get("ZTIMESTAMP"),
                "raw_format": "apple_epoch_seconds",
                "source_app": "Kik",
                "source_category": "Kik",
                "event_type": "message",
                "title": conversation_name or "Kik Message",
                "details": details,
                "confidence": "high",
                "raw_source_path": self.kik_db_path,
                "report_anchor": f"msg-{msg.get('Z_PK')}",
                "link_hint": link_hint,
            })
            for content_id in msg.get("attachments") or []:
                attach = self._resolve_attachment(content_id, attachments_dir) if attachments_dir else None
                filename = attach.get("file_name") if attach else None
                if not filename:
                    continue
                event_type = "file_attachment"
                if self._is_image_file(filename):
                    event_type = "photo_attachment"
                elif os.path.splitext(filename)[1].lower() in (".mov", ".mp4", ".m4v", ".avi", ".mkv", ".3gp", ".3gpp"):
                    event_type = "video_attachment"
                elif os.path.splitext(filename)[1].lower() in (".m4a", ".aac", ".mp3", ".wav", ".aiff", ".amr", ".caf", ".flac", ".opus"):
                    event_type = "audio_attachment"
                timeline_emitter.emit({
                    "timestamp": ts_iso,
                    "raw_timestamp": msg.get("ZTIMESTAMP"),
                    "raw_format": "apple_epoch_seconds",
                    "source_app": "Kik",
                    "source_category": "Kik",
                    "event_type": event_type,
                    "title": f"{conversation_name}: {filename}",
                    "details": {
                        "conversation": conversation_name,
                        "filename": filename,
                        "content_id": content_id,
                    },
                    "confidence": "low" if event_type == "file_attachment" else "high",
                    "raw_source_path": content_id,
                    "report_anchor": f"msg-{msg.get('Z_PK')}",
                    "link_hint": link_hint,
                })

    def _render_conversation_html(self, title: str, messages: List[Dict[str, Any]],
                                  attachments_dir: str, skip_attachments: bool) -> str:
        msg_html = []
        for msg in messages:
            direction = self._message_direction(msg)
            body = msg.get("ZBODY") or ""
            timestamp = self._format_kik_timestamp(msg.get("ZTIMESTAMP"))
            time_str = timestamp.strftime("%m-%d-%Y %I:%M %p") if timestamp else ""
            sender = msg.get("ZDISPLAYNAME") or msg.get("ZUSERNAME") or msg.get("ZJID") or ""

            attachment_html = ""
            if msg.get("attachments") and not skip_attachments:
                attachment_html = "<div class=\"attachments\">"
                for content_id in msg["attachments"]:
                    attach = self._resolve_attachment(content_id, attachments_dir)
                    if not attach:
                        continue
                    rel_path = os.path.join("..", "Kik Attachments", attach["file_name"]).replace("\\", "/")
                    if self._is_image_file(attach["file_name"]):
                        attachment_html += f"<a href=\"{rel_path}\" target=\"_blank\">"
                        attachment_html += f"<img src=\"{rel_path}\" alt=\"attachment\"></a>"
                    else:
                        attachment_html += (
                            f"<a class=\"file-link\" href=\"{rel_path}\" target=\"_blank\">"
                            f"{self._escape_html(attach['file_name'])}</a>"
                        )
                attachment_html += "</div>"

            msg_html.append(f"""
            <div class="message {direction}" id="msg-{msg.get('Z_PK')}">
              <div class="bubble">
                <div class="meta">{self._escape_html(sender)} {self._escape_html(time_str)}</div>
                <div class="body">{self._escape_html(body)}</div>
                {attachment_html}
              </div>
            </div>
            """)

        call_rows = []
        for call in self._load_call_history():
            ts = self._format_kik_timestamp(call.get("timestamp"))
            ts_str = ts.strftime("%m-%d-%Y %I:%M %p") if ts else ""
            call_rows.append(f"""
            <div class=\"call-row\">
              <div class=\"call-name\">{self._escape_html(call.get('name') or 'Unknown')}</div>
              <div class=\"call-meta\">{self._escape_html(call.get('body') or 'Call event')}</div>
              <div class=\"call-time\">{self._escape_html(ts_str)}</div>
            </div>
            """)

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Kik Conversation</title>
  <style>
    body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif; background: #f5f6fa; margin: 20px; }}
    .header {{ background: linear-gradient(135deg, #5BCA10, #C3E3AD); color: white; padding: 24px; border-radius: 12px 12px 0 0; }}
    .header h1 {{ margin: 0 0 10px; font-size: 32px; font-weight: 600; }}
    .header p {{ margin: 0; font-size: 16px; opacity: 0.9; }}
    .breadcrumbs {{ display: flex; align-items: center; gap: 8px; font-size: 12px; letter-spacing: 0.2px; color: rgba(255,255,255,0.85); margin-bottom: 10px; }}
    .breadcrumbs a {{ color: #fff; text-decoration: none; font-weight: 600; }}
    .breadcrumbs a:hover {{ text-decoration: underline; }}
    .breadcrumbs .back-arrow {{ opacity: 0.6; }}
    .embedded .breadcrumbs {{ display: none; }}
    .container {{ max-width: 900px; margin: 20px auto; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }}
    .messages {{ padding: 20px; }}
    .message {{ margin-bottom: 16px; display: flex; }}
    .highlight-target {{ background-color: #fff3cd; outline: 2px solid #f59e0b; }}
    .highlight-target .bubble {{ background-color: #fff3cd; }}
    .search-hit {{ background: #ffec99; border-radius: 3px; padding: 0 1px; }}
    .search-hit-block {{ background: #fff7d6; border: 2px solid #f59e0b; border-radius: 12px; padding: 4px; }}
    .message.sent {{ justify-content: flex-end; }}
    .message.received {{ justify-content: flex-start; }}
    .message.system {{ justify-content: center; }}
    .bubble {{ max-width: 70%; padding: 10px 14px; border-radius: 12px; background: #f1f5f9; }}
    .sent .bubble {{ background: #dbeafe; }}
    .meta {{ font-size: 11px; color: #6b7280; margin-bottom: 6px; }}
    .body {{ font-size: 14px; line-height: 1.4; }}
    .attachments img {{ max-width: 240px; border-radius: 8px; margin-top: 8px; display: block; }}
    .file-link {{
      display: inline-block;
      margin-top: 8px;
      color: #2563eb;
      font-size: 13px;
      text-decoration: none;
    }}
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Kik.html">Back to conversations</a></div>
      <h1>{self._escape_html(title)}</h1>
    </div>
    <div class="messages">
      {''.join(msg_html)}
    </div>
  </div>
  <script>
    (function() {{
      if (!window.location.hash) return;
      const target = document.querySelector(window.location.hash);
      if (!target) return;
      target.classList.add('highlight-target');
      try {{
        target.scrollIntoView({{ block: 'center' }});
      }} catch (e) {{
        target.scrollIntoView();
      }}
    }})();
  </script>
  <script>
    (function() {{
      const params = new URLSearchParams(window.location.search);
      const term = (params.get('q') || localStorage.getItem('kikLastSearch') || '').trim();
      if (!term) return;

      function highlightInElement(element, query) {{
        const needle = query.toLowerCase();
        const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT, {{
          acceptNode(node) {{
            if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
            const parent = node.parentElement;
            if (!parent) return NodeFilter.FILTER_REJECT;
            if (parent.classList && parent.classList.contains('search-hit')) return NodeFilter.FILTER_REJECT;
            return NodeFilter.FILTER_ACCEPT;
          }}
        }});
        const nodes = [];
        let node;
        while ((node = walker.nextNode())) {{
          if (node.nodeValue.toLowerCase().includes(needle)) {{
            nodes.push(node);
          }}
        }}
        nodes.forEach(textNode => {{
          const text = textNode.nodeValue;
          const lower = text.toLowerCase();
          const frag = document.createDocumentFragment();
          let lastIndex = 0;
          let idx = lower.indexOf(needle, lastIndex);
          while (idx !== -1) {{
            const before = text.slice(lastIndex, idx);
            if (before) frag.appendChild(document.createTextNode(before));
            const mark = document.createElement('mark');
            mark.className = 'search-hit';
            mark.textContent = text.slice(idx, idx + needle.length);
            frag.appendChild(mark);
            lastIndex = idx + needle.length;
            idx = lower.indexOf(needle, lastIndex);
          }}
          const after = text.slice(lastIndex);
          if (after) frag.appendChild(document.createTextNode(after));
          textNode.parentNode.replaceChild(frag, textNode);
        }});
      }}

      const targets = document.querySelectorAll('.body');
      targets.forEach(el => highlightInElement(el, term));
      document.querySelectorAll('.search-hit').forEach(mark => {{
        const block = mark.closest('.message');
        if (block) block.classList.add('search-hit-block');
      }});
      const first = document.querySelector('.search-hit');
      if (first) {{
        try {{
          first.scrollIntoView({{ block: 'center' }});
        }} catch (e) {{
          first.scrollIntoView();
        }}
      }}
    }})();
  </script>
  <script>
  (function() {{
    try {{
      if (window.parent && window.parent !== window) {{
        window.parent.postMessage({{type: 'device-nav', href: window.location.href}}, '*');
      }}
    }} catch (err) {{}}
  }})();
  </script>
</body>
</html>
"""

    def _render_index_html(self, conversations: List[Dict[str, Any]], output_path: str) -> str:
        rows = []
        search_text_by_file = {}
        for conv in conversations:
            last_msg = conv.get("last_message") or ""
            ts = self._format_kik_timestamp(conv.get("last_message_date"))
            ts_str = ts.strftime("%m-%d-%Y %I:%M %p") if ts else ""
            search_text = ""
            try:
                convo_path = os.path.join(output_path, "Conversations", conv["filename"])
                with open(convo_path, "r", encoding="utf-8", errors="ignore") as convo_f:
                    convo_html = convo_f.read()
                parts = re.findall(r'<div class="body">(.*?)</div>', convo_html, re.S)
                cleaned = []
                for part in parts:
                    text_only = re.sub(r'<[^>]+>', '', part)
                    text_only = html.unescape(text_only).strip()
                    if text_only:
                        cleaned.append(text_only)
                if cleaned:
                    search_text = " ".join(cleaned)[:4000].lower()
            except Exception:
                search_text = ""
            search_text_by_file[conv["filename"]] = search_text
            rows.append(f"""
            <a class="conv" href="Conversations/{conv['filename']}" data-search="{self._escape_html(search_text_by_file.get(conv['filename'], ''))}">
              <div class="title">{self._escape_html(conv['display_name'])}</div>
              <div class="sub">{self._escape_html(last_msg)}</div>
              <div class="meta">{conv.get('message_count', 0)} messages • {self._escape_html(ts_str)}</div>
            </a>
            """)

        call_rows = []
        for call in self._load_call_history():
            ts = self._format_kik_timestamp(call.get("timestamp"))
            ts_str = ts.strftime("%m-%d-%Y %I:%M %p") if ts else ""
            call_rows.append(f"""
            <div class=\"call-row\">
              <div class=\"call-name\">{self._escape_html(call.get('name') or 'Unknown')}</div>
              <div class=\"call-meta\">{self._escape_html(call.get('body') or 'Call event')}</div>
              <div class=\"call-time\">{self._escape_html(ts_str)}</div>
            </div>
            """)

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Kik Messages</title>
  <style>
    body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif; background: #f5f6fa; margin: 20px; }}
    .header {{ background: linear-gradient(135deg, #5BCA10, #C3E3AD); color: white; padding: 24px; border-radius: 12px 12px 0 0; }}
    .header h1 {{ margin: 0 0 10px; font-size: 32px; font-weight: 600; }}
    .header p {{ margin: 0; font-size: 16px; opacity: 0.9; }}
    .breadcrumbs {{ display: flex; align-items: center; gap: 8px; font-size: 12px; letter-spacing: 0.2px; color: rgba(255,255,255,0.85); margin-bottom: 10px; }}
    .breadcrumbs a {{ color: #fff; text-decoration: none; font-weight: 600; }}
    .breadcrumbs a:hover {{ text-decoration: underline; }}
    .breadcrumbs .back-arrow {{ opacity: 0.6; }}
    .embedded .breadcrumbs {{ display: none; }}
    .page {{ max-width: 900px; margin: 20px auto; }}
    .search-box {{
      padding: 20px;
      border-bottom: 1px solid #e5e5e5;
      background: white;
      position: relative;
    }}
    .search-box input {{
      width: 100%;
      padding: 12px 46px 12px 20px;
      border: 1px solid #ddd;
      border-radius: 8px;
      font-size: 16px;
      box-sizing: border-box;
    }}
    .search-box input:focus {{
      outline: none;
      border-color: #00c6ff;
    }}
    .clear-search {{
      position: absolute;
      right: 24px;
      top: 50%;
      transform: translateY(-50%);
      border: 1px solid #d1d5db;
      background: #f3f4f6;
      color: #111827;
      border-radius: 6px;
      padding: 4px 8px;
      font-size: 12px;
      cursor: pointer;
      display: none;
    }}
    .clear-search.visible {{ display: inline-block; }}
    .list {{ background: white; border-radius: 0 0 12px 12px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }}
    .conv {{ display: block; padding: 16px 18px; border-bottom: 1px solid #eef0f4; text-decoration: none; color: inherit; }}
    .conv:last-child {{ border-bottom: none; }}
    .title {{ font-weight: 600; margin-bottom: 4px; }}
    .sub {{ color: #555; font-size: 13px; margin-bottom: 6px; }}
    .meta {{ font-size: 12px; color: #8a8f98; }}
    .section {{ margin-top: 24px; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }}
    .section h2 {{ margin: 0; padding: 16px 18px; font-size: 18px; border-bottom: 1px solid #eef0f4; }}
    .call-row {{ display: grid; grid-template-columns: 2fr 2fr 1fr; gap: 12px; padding: 12px 18px; border-bottom: 1px solid #eef0f4; font-size: 13px; }}
    .call-row:last-child {{ border-bottom: none; }}
    .call-name {{ font-weight: 600; }}
    .call-meta {{ color: #1d4ed8; }}
    .call-time {{ color: #6b7280; }}
    @media (max-width: 900px) {{
      .call-row {{ grid-template-columns: 1fr; }}
    }}
  </style>
</head>
<body>
  <div class="page">
    <div class="header">
      <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Start_Here.html">Back</a></div>
      <h1>Kik Messages</h1>
      <p>Extracted from iOS Backup on {datetime.now().strftime("%B %d, %Y")}</p>
    </div>
    <div class="search-box">
      <input id="searchInput" placeholder="Search conversations">
      <button id="clearSearch" class="clear-search" title="Clear" aria-label="Clear search">X</button>
    </div>
    <div class="list" id="convList">
      {''.join(rows)}
    </div>
    <div class="section">
      <h2>Call History</h2>
      {''.join(call_rows) if call_rows else '<div class="call-row"><div class="call-name">No call records found</div></div>'}
    </div>
  </div>
<script>
const searchInput = document.getElementById('searchInput');
const list = document.getElementById('convList');
const clearBtn = document.getElementById('clearSearch');
function applyFilter() {{
  if (!searchInput || !list) {{
    return;
  }}
  const rawTerm = searchInput.value.trim();
  const term = rawTerm.toLowerCase();
  if (rawTerm) {{
    localStorage.setItem('kikLastSearch', rawTerm);
  }} else {{
    localStorage.removeItem('kikLastSearch');
  }}
  list.querySelectorAll('.conv').forEach(row => {{
    const text = row.innerText.toLowerCase();
    const searchText = (row.getAttribute('data-search') || '').toLowerCase();
    if (!row.dataset.baseHref) {{
      row.dataset.baseHref = row.getAttribute('href');
    }}
    if (rawTerm) {{
      row.setAttribute('href', `${{row.dataset.baseHref}}?q=${{encodeURIComponent(rawTerm)}}`);
    }} else {{
      row.setAttribute('href', row.dataset.baseHref);
    }}
    row.style.display = !term || text.includes(term) || searchText.includes(term) ? '' : 'none';
  }});
  if (clearBtn) {{
    clearBtn.classList.toggle('visible', !!rawTerm);
  }}
}}
if (searchInput && list) {{
  searchInput.addEventListener('input', applyFilter);
  const saved = localStorage.getItem('kikLastSearch') || '';
  if (saved) {{
    searchInput.value = saved;
    applyFilter();
  }}
  window.addEventListener('pageshow', () => {{
    if (searchInput.value.trim()) {{
      applyFilter();
    }}
  }});
}}
if (clearBtn) {{
  clearBtn.addEventListener('click', () => {{
    searchInput.value = '';
    localStorage.removeItem('kikLastSearch');
    applyFilter();
    clearBtn.classList.remove('visible');
    searchInput.focus();
  }});
}}
 </script>
 <script>
  (function() {{
    try {{
      if (window.parent && window.parent !== window) {{
        window.parent.postMessage({{type: 'device-nav-root', href: window.location.href}}, '*');
        window.parent.postMessage({{type: 'device-nav', href: window.location.href}}, '*');
      }}
    }} catch (err) {{}}
  }})();
 </script>
 <script>
  if (window.self !== window.top) {{ document.body.classList.add('embedded'); }}
 </script>
</body>
</html>
"""
