#!/usr/bin/env python3
"""
LINE data extractor for iOS backups.

Extracts chats, messages, and attachments from LINE's Line.sqlite database
and exports an HTML report similar to WhatsApp/SMS.
"""

import os
import re
import html
import sqlite3
import shutil
import sys
from io import BytesIO
from typing import List, Dict, Any, Optional
from datetime import datetime

from .base import CategoryDataExtractor


class LineExtractor(CategoryDataExtractor):
    """Extract and export LINE data from iOS backups."""

    LINE_APP_DOMAIN = "AppDomain-jp.naver.line"
    LINE_GROUP_DOMAIN = "AppDomainGroup-group.com.linecorp.line"

    def __init__(self, backup_path: str):
        super().__init__(backup_path)

        self.line_db_path, self.line_db_rel = self._find_line_db()
        if not self.line_db_path or not self.line_db_rel:
            raise FileNotFoundError("LINE database not found in backup")

        self.line_root_rel = self._get_line_root_rel(self.line_db_rel)
        self.attach_root_rel = os.path.join(self.line_root_rel, "Message Attachments")
        self.attach_root_rel = self.attach_root_rel.replace("\\", "/")
        self._user_by_mid, self._user_by_pk = self._load_users()
        self._attachment_index = self._build_attachment_index()
        self._call_history = self._load_call_history()

    def _find_line_db(self) -> (Optional[str], Optional[str]):
        conn = sqlite3.connect(f"file:{self.manifest_db_path}?mode=ro", uri=True)
        try:
            cur = conn.cursor()
            cur.execute("""
                SELECT fileID, relativePath
                FROM Files
                WHERE domain = ?
                  AND relativePath LIKE '%/Messages/Line.sqlite'
                ORDER BY relativePath
                LIMIT 1
            """, (self.LINE_GROUP_DOMAIN,))
            row = cur.fetchone()
            if row:
                file_id, rel_path = row
                return self._resolve_file_id_path(file_id), rel_path
        finally:
            conn.close()
        return None, None

    def _get_line_root_rel(self, rel_path: str) -> str:
        # .../PrivateStore/<profile>/Messages/Line.sqlite -> .../PrivateStore/<profile>
        return os.path.dirname(os.path.dirname(rel_path))

    def _escape_html(self, text: str) -> str:
        if not text:
            return ''
        return (str(text)
                .replace('&', '&amp;')
                .replace('<', '&lt;')
                .replace('>', '&gt;')
                .replace('"', '&quot;')
                .replace("'", '&#39;')
                .replace('\n', '<br>'))

    def _format_line_timestamp(self, timestamp_ms: Optional[float]) -> Optional[datetime]:
        if not timestamp_ms:
            return None
        try:
            ts = float(timestamp_ms)
            if ts > 1e12:
                return datetime.fromtimestamp(ts / 1000.0)
            if ts > 1e9:
                return datetime.fromtimestamp(ts)
            apple_epoch = datetime(2001, 1, 1).timestamp()
            return datetime.fromtimestamp(apple_epoch + ts)
        except Exception:
            return None

    def _guess_extension(self, path: str) -> str:
        try:
            with open(path, "rb") as f:
                head = f.read(12)
            if head.startswith(b"\xff\xd8\xff"):
                return ".jpg"
            if head.startswith(b"\x89PNG\r\n\x1a\n"):
                return ".png"
            if head.startswith(b"GIF87a") or head.startswith(b"GIF89a"):
                return ".gif"
        except Exception:
            return ""
        return ""

    def _is_image_file(self, filename: str) -> bool:
        ext = os.path.splitext(filename or "")[1].lower()
        return ext in (".jpg", ".jpeg", ".png", ".gif", ".heic", ".webp")

    def _load_users(self) -> (Dict[str, Dict[str, Any]], Dict[int, Dict[str, Any]]):
        users_by_mid = {}
        users_by_pk = {}
        conn = sqlite3.connect(self.line_db_path)
        conn.row_factory = sqlite3.Row
        try:
            cur = conn.cursor()
            cur.execute("SELECT Z_PK, ZMID, ZNAME, ZCUSTOMNAME FROM ZUSER")
            for row in cur.fetchall():
                name = row["ZCUSTOMNAME"] or row["ZNAME"] or row["ZMID"] or "Unknown"
                entry = {"mid": row["ZMID"], "name": name}
                if row["ZMID"]:
                    users_by_mid[row["ZMID"]] = entry
                users_by_pk[row["Z_PK"]] = entry
        finally:
            conn.close()
        return users_by_mid, users_by_pk

    def _build_attachment_index(self) -> Dict[str, Dict[str, str]]:
        index = {}
        conn = sqlite3.connect(f"file:{self.manifest_db_path}?mode=ro", uri=True)
        try:
            cur = conn.cursor()
            cur.execute("""
                SELECT fileID, relativePath
                FROM Files
                WHERE domain = ?
                  AND relativePath LIKE ?
            """, (self.LINE_APP_DOMAIN, f"{self.attach_root_rel}/%"))
            for file_id, rel_path in cur.fetchall():
                filename = os.path.basename(rel_path)
                base, ext = os.path.splitext(filename)
                if not base:
                    continue
                if base not in index:
                    index[base] = {"file_id": file_id, "rel_path": rel_path, "filename": filename}
        finally:
            conn.close()
        return index

    def _find_call_history_path(self) -> Optional[str]:
        conn = sqlite3.connect(f"file:{self.manifest_db_path}?mode=ro", uri=True)
        try:
            cur = conn.cursor()
            cur.execute("""
                SELECT fileID
                FROM Files
                WHERE domain = ?
                  AND relativePath LIKE 'Library/NCXVoIP/%_CallHistory.db'
                ORDER BY relativePath
                LIMIT 1
            """, (self.LINE_GROUP_DOMAIN,))
            row = cur.fetchone()
            if row:
                return self._resolve_file_id_path(row[0])
        finally:
            conn.close()
        return None

    def _load_call_history(self) -> List[Dict[str, Any]]:
        path = self._find_call_history_path()
        if not path or not os.path.exists(path):
            return []

        root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        ccl_path = os.path.join(root_dir, "docs", "online_research", "4n6notebooks-master")
        if ccl_path not in sys.path and os.path.isdir(ccl_path):
            sys.path.insert(0, ccl_path)
        try:
            import ccl_bplist  # type: ignore
        except Exception:
            return []

        try:
            with open(path, "rb") as f:
                data = f.read()
            plist_obj = ccl_bplist.load(BytesIO(data))
            decoded = ccl_bplist.deserialise_NsKeyedArchiver(plist_obj, parse_whole_structure=True)
            root = decoded.get("root")
            objs = root.get("NS.objects") if isinstance(root, dict) else None
            if not isinstance(objs, list):
                return []
        except Exception:
            return []

        calls = []
        for item in objs:
            if not isinstance(item, dict):
                continue
            if "mStartDate" not in item:
                continue
            start_info = item.get("mStartDate")
            ts = None
            if isinstance(start_info, dict):
                ts = start_info.get("NS.time")
            elif isinstance(start_info, (int, float)):
                ts = start_info
            start_dt = None
            if isinstance(ts, (int, float)):
                apple_epoch = datetime(2001, 1, 1).timestamp()
                try:
                    start_dt = datetime.fromtimestamp(apple_epoch + float(ts))
                except Exception:
                    start_dt = None

            mid = item.get("mIdentifier")
            contact = self._user_by_mid.get(mid, {}) if mid else {}
            name = contact.get("name") or mid or "Unknown"
            duration = item.get("mDuration")
            incoming = bool(item.get("mIncomingCall"))
            video = bool(item.get("mVideoCall"))
            end_type = item.get("sEndType")

            calls.append({
                "name": name,
                "mid": mid,
                "start_dt": start_dt,
                "duration": duration,
                "incoming": incoming,
                "video": video,
                "end_type": end_type,
            })

        calls.sort(key=lambda c: c["start_dt"] or datetime.min, reverse=True)
        return calls

    def _resolve_attachment(self, message_id: Optional[str], output_dir: str) -> Optional[Dict[str, str]]:
        if not message_id:
            return None
        entry = self._attachment_index.get(str(message_id))
        if not entry:
            return None

        file_path = self._resolve_file_id_path(entry["file_id"])
        if not file_path or not os.path.exists(file_path):
            return None

        filename = entry["filename"]
        base, ext = os.path.splitext(filename)
        if not ext:
            ext = self._guess_extension(file_path) or ".bin"
            filename = f"{base}{ext}" if base else f"{message_id}{ext}"

        dest_path = os.path.join(output_dir, filename)
        if not os.path.exists(dest_path):
            shutil.copy2(file_path, dest_path)
        self._add_export_bytes(dest_path)
        return {"file_name": filename, "path": dest_path}

    def get_total_message_count(self) -> int:
        conn = sqlite3.connect(self.line_db_path)
        try:
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) FROM ZMESSAGE")
            return cur.fetchone()[0]
        finally:
            conn.close()

    def get_conversations(self, limit: Optional[int] = None, offset: int = 0,
                          search: Optional[str] = None) -> List[Dict[str, Any]]:
        conn = sqlite3.connect(self.line_db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        search_condition = ""
        params: List[Any] = []
        if search:
            search_condition = "WHERE (u.ZNAME LIKE ? OR u.ZCUSTOMNAME LIKE ? OR c.ZLASTMESSAGE LIKE ?)"
            pattern = f"%{search}%"
            params.extend([pattern, pattern, pattern])

        cur.execute(f"""
            SELECT c.Z_PK as chat_id, c.ZMID, c.ZLASTMESSAGE, c.ZLASTUPDATED, c.ZTYPE,
                   u.ZNAME, u.ZCUSTOMNAME
            FROM ZCHAT c
            LEFT JOIN ZUSER u ON u.ZMID = c.ZMID
            {search_condition}
            ORDER BY c.ZLASTUPDATED DESC
        """, params)

        conversations = []
        for row in cur.fetchall():
            chat_id = row["chat_id"]
            display_name = row["ZCUSTOMNAME"] or row["ZNAME"]
            if not display_name:
                display_name = row["ZMID"] or f"Chat {chat_id}"

            cur.execute("SELECT COUNT(*) FROM ZMESSAGE WHERE ZCHAT = ?", (chat_id,))
            message_count = cur.fetchone()[0]

            last_message = row["ZLASTMESSAGE"] or ""
            last_message_date = row["ZLASTUPDATED"]
            if not last_message:
                cur.execute("""
                    SELECT ZTEXT, ZTIMESTAMP
                    FROM ZMESSAGE
                    WHERE ZCHAT = ?
                    ORDER BY ZTIMESTAMP DESC
                    LIMIT 1
                """, (chat_id,))
                last_row = cur.fetchone()
                if last_row:
                    last_message = last_row["ZTEXT"] or ""
                    last_message_date = last_row["ZTIMESTAMP"]

            conversations.append({
                "chat_id": chat_id,
                "display_name": display_name,
                "last_message": last_message,
                "last_message_date": last_message_date,
                "message_count": message_count,
            })

        conn.close()
        if offset:
            conversations = conversations[offset:]
        if limit:
            conversations = conversations[:limit]
        return conversations

    def _load_messages_for_chat(self, chat_id: int) -> List[Dict[str, Any]]:
        conn = sqlite3.connect(self.line_db_path)
        conn.row_factory = sqlite3.Row
        try:
            cur = conn.cursor()
            cur.execute("""
                SELECT Z_PK, ZTEXT, ZTIMESTAMP, ZCONTENTTYPE, ZCHAT, ZSENDER, ZID, ZLATITUDE, ZLONGITUDE
                FROM ZMESSAGE
                WHERE ZCHAT = ?
                ORDER BY ZTIMESTAMP ASC
            """, (chat_id,))
            return [dict(r) for r in cur.fetchall()]
        finally:
            conn.close()

    def get_count(self) -> int:
        return self.get_total_message_count()

    def get_items(self, limit: Optional[int] = None, offset: int = 0, **kwargs) -> List[Dict[str, Any]]:
        search = kwargs.get("search")
        return self.get_conversations(limit, offset, search)

    def get_item_summary(self, item: Dict[str, Any]) -> str:
        return f"{item['display_name']} - {item.get('last_message', '')[:50]}"

    def export(self, items: List[Dict[str, Any]], output_path: str, format: str = 'html',
               progress_callback=None, skip_attachments: bool = False, timeline_emitter=None) -> bool:
        if format not in ('html', 'files'):
            raise ValueError(f"Unsupported export format: {format}")
        try:
            self._reset_export_bytes()
            os.makedirs(output_path, exist_ok=True)
            conversations_dir = os.path.join(output_path, "Conversations")
            os.makedirs(conversations_dir, exist_ok=True)
            attachments_dir = os.path.join(output_path, "Line Attachments")
            os.makedirs(attachments_dir, exist_ok=True)

            used_filenames = set()
            conversation_list = []
            total = len(items) + 1

            for i, item in enumerate(items):
                if isinstance(item, dict):
                    chat_id = item["chat_id"]
                    display_name = item["display_name"]
                    last_message = item.get("last_message", "")
                    last_message_date = item.get("last_message_date", 0)
                    message_count = item.get("message_count", 0)
                else:
                    chat_id = item
                    display_name = f"Chat {chat_id}"
                    last_message = ""
                    last_message_date = 0
                    message_count = 0

                filename_base = display_name.replace("/", "_").replace("\\", "_")
                filename = f"{filename_base}.html"
                if filename in used_filenames:
                    filename = f"{filename_base}_{chat_id}.html"
                used_filenames.add(filename)
                out_file = os.path.join(conversations_dir, filename)

                messages = self._load_messages_for_chat(chat_id)
                if timeline_emitter is not None:
                    self._emit_message_timeline_events(messages, display_name, filename, attachments_dir, timeline_emitter)
                html = self._render_conversation_html(display_name, messages, attachments_dir, skip_attachments)
                with open(out_file, "w", encoding="utf-8") as f:
                    f.write(html)
                self._add_export_bytes(out_file)

                conversation_list.append({
                    "display_name": display_name,
                    "filename": filename,
                    "last_message": last_message,
                    "last_message_date": last_message_date,
                    "message_count": message_count,
                })

                if progress_callback:
                    progress_callback(i + 1, total, display_name)

            index_html = self._render_index_html(conversation_list, output_path)
            index_path = os.path.join(output_path, "Line.html")
            with open(index_path, "w", encoding="utf-8") as f:
                f.write(index_html)
            self._add_export_bytes(index_path)

            if progress_callback:
                progress_callback(total, total, "Index")
            return True
        except Exception as e:
            print(f"Error exporting LINE: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _message_direction(self, msg: Dict[str, Any]) -> str:
        sender = msg.get("ZSENDER")
        if sender is None:
            return "sent"
        return "received"

    def _format_timestamp_iso(self, timestamp: Optional[float]) -> Optional[str]:
        dt = self._format_line_timestamp(timestamp)
        if not dt:
            return None
        return dt.isoformat()

    def _emit_message_timeline_events(self, messages: List[Dict[str, Any]], conversation_name: str,
                                      html_filename: str, attachments_dir: str, timeline_emitter) -> None:
        link_hint = f"Line/Conversations/{html_filename}"
        for msg in messages:
            ts_iso = self._format_timestamp_iso(msg.get("ZTIMESTAMP"))
            if not ts_iso:
                continue
            text = msg.get("ZTEXT") or ""
            details = {
                "conversation": conversation_name,
                "direction": self._message_direction(msg),
                "text": text[:200] if text else "",
            }
            timeline_emitter.emit({
                "timestamp": ts_iso,
                "raw_timestamp": msg.get("ZTIMESTAMP"),
                "raw_format": "line_timestamp",
                "source_app": "LINE",
                "source_category": "LINE",
                "event_type": "message",
                "title": conversation_name or "LINE Message",
                "details": details,
                "confidence": "high",
                "raw_source_path": self.line_db_path,
                "report_anchor": f"msg-{msg.get('Z_PK')}",
                "link_hint": link_hint,
            })
            if msg.get("ZCONTENTTYPE") == 1:
                attach = self._resolve_attachment(msg.get("ZID"), attachments_dir) if attachments_dir else None
                filename = attach.get("file_name") if attach else None
                if filename:
                    event_type = "file_attachment"
                    if self._is_image_file(filename):
                        event_type = "photo_attachment"
                    elif os.path.splitext(filename)[1].lower() in (".mov", ".mp4", ".m4v", ".avi", ".mkv", ".3gp", ".3gpp"):
                        event_type = "video_attachment"
                    elif os.path.splitext(filename)[1].lower() in (".m4a", ".aac", ".mp3", ".wav", ".aiff", ".amr", ".caf", ".flac", ".opus"):
                        event_type = "audio_attachment"
                    timeline_emitter.emit({
                        "timestamp": ts_iso,
                        "raw_timestamp": msg.get("ZTIMESTAMP"),
                        "raw_format": "line_timestamp",
                        "source_app": "LINE",
                        "source_category": "LINE",
                        "event_type": event_type,
                        "title": f"{conversation_name}: {filename}",
                        "details": {
                            "conversation": conversation_name,
                            "filename": filename,
                            "message_id": msg.get("Z_PK"),
                        },
                        "confidence": "low" if event_type == "file_attachment" else "high",
                        "raw_source_path": msg.get("ZID") or "",
                        "report_anchor": f"msg-{msg.get('Z_PK')}",
                        "link_hint": link_hint,
                    })

    def _format_message_body(self, msg: Dict[str, Any]) -> str:
        content_type = msg.get("ZCONTENTTYPE")
        text = msg.get("ZTEXT") or ""
        if content_type == 6 and text:
            return text
        if content_type == 100:
            if text:
                return text.strip()
            lat = msg.get("ZLATITUDE")
            lng = msg.get("ZLONGITUDE")
            if lat is not None and lng is not None:
                return f"Shared location ({lat}, {lng})"
            return "Shared location"
        if content_type == 17 and not text.strip():
            return "Rich content"
        if not text:
            return "Attachment"
        return text

    def _render_conversation_html(self, title: str, messages: List[Dict[str, Any]],
                                  attachments_dir: str, skip_attachments: bool) -> str:
        msg_html = []
        for msg in messages:
            direction = self._message_direction(msg)
            body = self._format_message_body(msg)
            timestamp = self._format_line_timestamp(msg.get("ZTIMESTAMP"))
            time_str = timestamp.strftime("%m-%d-%Y %I:%M %p") if timestamp else ""

            attachment_html = ""
            if msg.get("ZCONTENTTYPE") == 1 and not skip_attachments:
                attach = self._resolve_attachment(msg.get("ZID"), attachments_dir)
                if attach:
                    rel_path = os.path.join("..", "Line Attachments", attach["file_name"]).replace("\\", "/")
                    if self._is_image_file(attach["file_name"]):
                        attachment_html = (
                            f"<a href=\"{rel_path}\" target=\"_blank\">"
                            f"<img src=\"{rel_path}\" alt=\"attachment\"></a>"
                        )
                    else:
                        attachment_html = (
                            f"<a class=\"file-link\" href=\"{rel_path}\" target=\"_blank\">"
                            f"{self._escape_html(attach['file_name'])}</a>"
                        )
                else:
                    attachment_html = "<div class=\"missing-attachment\">Attachment not found</div>"

            msg_html.append(f"""
            <div class="message {direction}" id="msg-{msg.get('Z_PK')}">
              <div class="bubble">
                <div class="meta">{self._escape_html(time_str)}</div>
                <div class="body">{self._escape_html(body)}</div>
                <div class="attachments">{attachment_html}</div>
              </div>
            </div>
            """)

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>LINE Conversation</title>
  <style>
    body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif; background: #f5f6fa; margin: 20px; }}
    .container {{ max-width: 900px; margin: 0 auto; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }}
    .header {{ background: linear-gradient(135deg, #06C152, #ACEAC5); color: white; padding: 24px; border-radius: 12px 12px 0 0; }}
    .header h1 {{ margin: 0 0 10px; font-size: 32px; font-weight: 600; }}
    .header p {{ margin: 0; font-size: 16px; opacity: 0.9; }}
    .breadcrumbs {{ display: flex; align-items: center; gap: 8px; font-size: 12px; letter-spacing: 0.2px; color: rgba(255,255,255,0.85); margin-bottom: 10px; }}
    .breadcrumbs a {{ color: #fff; text-decoration: none; font-weight: 600; }}
    .breadcrumbs a:hover {{ text-decoration: underline; }}
    .breadcrumbs .back-arrow {{ opacity: 0.6; }}
    .embedded .breadcrumbs {{ display: none; }}
    .messages {{ padding: 20px; }}
    .message {{ margin-bottom: 16px; display: flex; }}
    .highlight-target {{ background-color: #fff3cd; outline: 2px solid #f59e0b; }}
    .highlight-target .bubble {{ background-color: #fff3cd; }}
    .search-hit {{ background: #ffec99; border-radius: 3px; padding: 0 1px; }}
    .search-hit-block {{ background: #fff7d6; border: 2px solid #f59e0b; border-radius: 12px; padding: 4px; }}
    .message.sent {{ justify-content: flex-end; }}
    .message.received {{ justify-content: flex-start; }}
    .bubble {{ max-width: 70%; padding: 10px 14px; border-radius: 12px; background: #f1f5f9; }}
    .sent .bubble {{ background: #dcfce7; }}
    .meta {{ font-size: 11px; color: #6b7280; margin-bottom: 6px; }}
    .body {{ font-size: 14px; line-height: 1.4; }}
    .attachments img {{ max-width: 240px; border-radius: 8px; margin-top: 8px; display: block; }}
    .file-link {{
      display: inline-block;
      margin-top: 8px;
      color: #15803d;
      font-size: 13px;
      text-decoration: none;
    }}
    .missing-attachment {{
      margin-top: 8px;
      font-size: 12px;
      color: #b91c1c;
    }}
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Line.html">Back to conversations</a></div>
      <h1>{self._escape_html(title)}</h1>
    </div>
    <div class="messages">
      {''.join(msg_html)}
    </div>
  </div>
  <script>
    (function() {{
      if (!window.location.hash) return;
      const target = document.querySelector(window.location.hash);
      if (!target) return;
      target.classList.add('highlight-target');
      try {{
        target.scrollIntoView({{ block: 'center' }});
      }} catch (e) {{
        target.scrollIntoView();
      }}
    }})();
  </script>
  <script>
    (function() {{
      const params = new URLSearchParams(window.location.search);
      const term = (params.get('q') || localStorage.getItem('lineLastSearch') || '').trim();
      if (!term) return;

      function escapeRegExp(value) {{
        return value.replace(/[.*+?^${{}}()|[\\]\\\\]/g, '\\\\$&');
      }}

      function highlightInElement(element, query) {{
        const regex = new RegExp(escapeRegExp(query), 'gi');
        const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT, {{
          acceptNode(node) {{
            if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
            const parent = node.parentElement;
            if (!parent) return NodeFilter.FILTER_REJECT;
            if (parent.classList && parent.classList.contains('search-hit')) return NodeFilter.FILTER_REJECT;
            return NodeFilter.FILTER_ACCEPT;
          }}
        }});
        const nodes = [];
        let node;
        while ((node = walker.nextNode())) {{
          if (regex.test(node.nodeValue)) {{
            nodes.push(node);
          }}
        }}
        nodes.forEach(textNode => {{
          const text = textNode.nodeValue;
          const frag = document.createDocumentFragment();
          const local = new RegExp(escapeRegExp(query), 'gi');
          let lastIndex = 0;
          let match;
          while ((match = local.exec(text)) !== null) {{
            const before = text.slice(lastIndex, match.index);
            if (before) frag.appendChild(document.createTextNode(before));
            const mark = document.createElement('mark');
            mark.className = 'search-hit';
            mark.textContent = match[0];
            frag.appendChild(mark);
            lastIndex = match.index + match[0].length;
          }}
          const after = text.slice(lastIndex);
          if (after) frag.appendChild(document.createTextNode(after));
          textNode.parentNode.replaceChild(frag, textNode);
        }});
      }}

      const targets = document.querySelectorAll('.body');
      targets.forEach(el => highlightInElement(el, term));
      document.querySelectorAll('.search-hit').forEach(mark => {{
        const block = mark.closest('.message');
        if (block) block.classList.add('search-hit-block');
      }});
      const first = document.querySelector('.search-hit');
      if (first) {{
        try {{
          first.scrollIntoView({{ block: 'center' }});
        }} catch (e) {{
          first.scrollIntoView();
        }}
      }}
    }})();
  </script>
  <script>
  (function() {{
    try {{
      if (window.parent && window.parent !== window) {{
        window.parent.postMessage({{type: 'device-nav', href: window.location.href}}, '*');
      }}
    }} catch (err) {{}}
  }})();
  </script>
</body>
</html>
"""

    def _render_index_html(self, conversations: List[Dict[str, Any]], output_path: str) -> str:
        rows = []
        search_text_by_file = {}
        for conv in conversations:
            last_msg = conv.get("last_message") or ""
            ts = self._format_line_timestamp(conv.get("last_message_date"))
            ts_str = ts.strftime("%m-%d-%Y %I:%M %p") if ts else ""
            search_text = ""
            try:
                convo_path = os.path.join(output_path, "Conversations", conv["filename"])
                with open(convo_path, "r", encoding="utf-8", errors="ignore") as convo_f:
                    convo_html = convo_f.read()
                parts = re.findall(r'<div class="body">(.*?)</div>', convo_html, re.S)
                cleaned = []
                for part in parts:
                    text_only = re.sub(r'<[^>]+>', '', part)
                    text_only = html.unescape(text_only).strip()
                    if text_only:
                        cleaned.append(text_only)
                if cleaned:
                    search_text = " ".join(cleaned)[:4000].lower()
            except Exception:
                search_text = ""
            search_text_by_file[conv["filename"]] = search_text
            rows.append(f"""
            <a class="conv" href="Conversations/{conv['filename']}" data-search="{self._escape_html(search_text_by_file.get(conv['filename'], ''))}">
              <div class="title">{self._escape_html(conv['display_name'])}</div>
              <div class="sub">{self._escape_html(last_msg)}</div>
              <div class="meta">{conv.get('message_count', 0)} messages • {self._escape_html(ts_str)}</div>
            </a>
            """)

        call_rows = []
        for call in self._call_history:
            start_dt = call.get("start_dt")
            start_str = start_dt.strftime("%m-%d-%Y %I:%M %p") if start_dt else ""
            direction = "Incoming" if call.get("incoming") else "Outgoing"
            mode = "Video" if call.get("video") else "Audio"
            duration = call.get("duration")
            if isinstance(duration, (int, float)) and duration > 0:
                mins = int(duration) // 60
                secs = int(duration) % 60
                dur_text = f"{mins:d}:{secs:02d}"
            else:
                dur_text = ""
            end_type = call.get("end_type") or ""
            call_rows.append(f"""
            <div class="call-row">
              <div class="call-name">{self._escape_html(call.get('name') or 'Unknown')}</div>
              <div class="call-meta">{self._escape_html(direction)} {self._escape_html(mode)}</div>
              <div class="call-time">{self._escape_html(start_str)}</div>
              <div class="call-extra">{self._escape_html(dur_text)}</div>
              <div class="call-extra">{self._escape_html(str(end_type))}</div>
            </div>
            """)

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>LINE Messages</title>
  <style>
    body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif; background: #f5f6fa; margin: 20px; }}
    .page {{ max-width: 900px; margin: 0 auto; }}
      .header {{ background: linear-gradient(135deg, #06C152, #ACEAC5); color: white; padding: 24px; border-radius: 12px 12px 0 0; }}
      .header h1 {{ margin: 0 0 10px; font-size: 32px; font-weight: 600; }}
      .header p {{ margin: 0; font-size: 16px; opacity: 0.9; }}
      .breadcrumbs {{ display: flex; align-items: center; gap: 8px; font-size: 12px; letter-spacing: 0.2px; color: rgba(255,255,255,0.85); margin-bottom: 10px; }}
      .breadcrumbs a {{ color: #fff; text-decoration: none; font-weight: 600; }}
      .breadcrumbs a:hover {{ text-decoration: underline; }}
      .breadcrumbs .back-arrow {{ opacity: 0.6; }}
      .embedded .breadcrumbs {{ display: none; }}
      .search-box {{
      padding: 20px;
      border-bottom: 1px solid #e5e5e5;
      background: white;
      position: relative;
    }}
    .search-box input {{
      width: 100%;
      padding: 12px 46px 12px 20px;
      border: 1px solid #ddd;
      border-radius: 8px;
      font-size: 16px;
      box-sizing: border-box;
    }}
    .search-box input:focus {{
      outline: none;
      border-color: #19c25e;
    }}
    .clear-search {{
      position: absolute;
      right: 24px;
      top: 50%;
      transform: translateY(-50%);
      border: 1px solid #d1d5db;
      background: #f3f4f6;
      color: #111827;
      border-radius: 6px;
      padding: 4px 8px;
      font-size: 12px;
      cursor: pointer;
      display: none;
    }}
    .clear-search.visible {{ display: inline-block; }}
    .list {{ background: white; border-radius: 0 0 12px 12px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }}
    .conv {{ display: block; padding: 16px 18px; border-bottom: 1px solid #eef0f4; text-decoration: none; color: inherit; }}
    .conv:last-child {{ border-bottom: none; }}
    .title {{ font-weight: 600; margin-bottom: 4px; }}
    .sub {{ color: #555; font-size: 13px; margin-bottom: 6px; }}
    .meta {{ font-size: 12px; color: #8a8f98; }}
    .section {{ margin-top: 24px; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }}
    .section h2 {{ margin: 0; padding: 16px 18px; font-size: 18px; border-bottom: 1px solid #eef0f4; }}
    .call-row {{ display: grid; grid-template-columns: 2fr 1fr 1.3fr 0.6fr 1fr; gap: 12px; padding: 12px 18px; border-bottom: 1px solid #eef0f4; font-size: 13px; }}
    .call-row:last-child {{ border-bottom: none; }}
    .call-name {{ font-weight: 600; }}
    .call-meta {{ color: #166534; }}
    .call-time {{ color: #4b5563; }}
    .call-extra {{ color: #6b7280; }}
    @media (max-width: 900px) {{
      .call-row {{ grid-template-columns: 1fr 1fr; }}
    }}
  </style>
</head>
<body>
  <div class="page">
    <div class="header">
      <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Start_Here.html">Back</a></div>
      <h1>LINE Messages</h1>
      <p>Extracted from iOS Backup on {datetime.now().strftime("%B %d, %Y")}</p>
    </div>
    <div class="search-box">
      <input id="searchInput" placeholder="Search conversations">
      <button id="clearSearch" class="clear-search" title="Clear" aria-label="Clear search">X</button>
    </div>
    <div class="list" id="convList">
      {''.join(rows)}
    </div>
    {f'''
    <div class="section">
      <h2>Call History</h2>
      {''.join(call_rows) if call_rows else '<div class="call-row"><div class="call-name">No call records found</div></div>'}
    </div>
    ''' if call_rows is not None else ''}
  </div>
<script>
const searchInput = document.getElementById('searchInput');
const list = document.getElementById('convList');
const clearBtn = document.getElementById('clearSearch');
function applyFilter() {{
  if (!searchInput || !list) {{
    return;
  }}
  const rawTerm = searchInput.value.trim();
  const term = rawTerm.toLowerCase();
  if (rawTerm) {{
    localStorage.setItem('lineLastSearch', rawTerm);
  }} else {{
    localStorage.removeItem('lineLastSearch');
  }}
  list.querySelectorAll('.conv').forEach(row => {{
    const text = row.innerText.toLowerCase();
    const searchText = (row.getAttribute('data-search') || '').toLowerCase();
    if (!row.dataset.baseHref) {{
      row.dataset.baseHref = row.getAttribute('href');
    }}
    if (rawTerm) {{
      row.setAttribute('href', `${{row.dataset.baseHref}}?q=${{encodeURIComponent(rawTerm)}}`);
    }} else {{
      row.setAttribute('href', row.dataset.baseHref);
    }}
    row.style.display = !term || text.includes(term) || searchText.includes(term) ? '' : 'none';
  }});
  if (clearBtn) {{
    clearBtn.classList.toggle('visible', !!rawTerm);
  }}
}}
if (searchInput && list) {{
  searchInput.addEventListener('input', applyFilter);
  const saved = localStorage.getItem('lineLastSearch') || '';
  if (saved) {{
    searchInput.value = saved;
    applyFilter();
  }}
  window.addEventListener('pageshow', () => {{
    if (searchInput.value.trim()) {{
      applyFilter();
    }}
  }});
}}
if (clearBtn) {{
  clearBtn.addEventListener('click', () => {{
    searchInput.value = '';
    localStorage.removeItem('lineLastSearch');
    applyFilter();
    clearBtn.classList.remove('visible');
    searchInput.focus();
  }});
}}
 </script>
 <script>
  (function() {{
    try {{
      if (window.parent && window.parent !== window) {{
        window.parent.postMessage({{type: 'device-nav-root', href: window.location.href}}, '*');
        window.parent.postMessage({{type: 'device-nav', href: window.location.href}}, '*');
      }}
    }} catch (err) {{}}
  }})();
 </script>
 <script>
  if (window.self !== window.top) {{ document.body.classList.add('embedded'); }}
 </script>
</body>
</html>
"""
