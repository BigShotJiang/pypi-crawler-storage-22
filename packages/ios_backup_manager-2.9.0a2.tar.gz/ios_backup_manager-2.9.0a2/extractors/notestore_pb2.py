"""
Generated protobuf schema for Apple Notes NoteStore.sqlite
Based on reverse-engineered schema from Apple's Notes app

This is a minimal implementation focusing on text extraction.
"""

try:
    from google.protobuf import descriptor as _descriptor
    from google.protobuf import message as _message
    from google.protobuf import reflection as _reflection
    from google.protobuf import descriptor_pb2
    PROTOBUF_AVAILABLE = True
except ImportError:
    PROTOBUF_AVAILABLE = False
    # Provide dummy classes if protobuf not available
    class _message:
        class Message:
            pass


if PROTOBUF_AVAILABLE:
    DESCRIPTOR = _descriptor.FileDescriptor(
        name='notestore.proto',
        package='',
        syntax='proto2',
    )

    _ATTRIBUTERUN = _descriptor.Descriptor(
        name='AttributeRun',
        full_name='AttributeRun',
        filename=None,
        file=DESCRIPTOR,
        containing_type=None,
        fields=[
            _descriptor.FieldDescriptor(
                name='length', full_name='AttributeRun.length', index=0,
                number=1, type=5, cpp_type=1, label=2,
                default_value=0, message_type=None, enum_type=None,
                containing_type=None, is_extension=False, extension_scope=None,
                options=None),
        ],
        extensions=[],
        nested_types=[],
        enum_types=[],
        options=None,
        is_extendable=False,
        syntax='proto2',
        extension_ranges=[],
        oneofs=[],
        serialized_start=None,
        serialized_end=None,
    )

    _NOTE = _descriptor.Descriptor(
        name='Note',
        full_name='Note',
        filename=None,
        file=DESCRIPTOR,
        containing_type=None,
        fields=[
            _descriptor.FieldDescriptor(
                name='note_text', full_name='Note.note_text', index=0,
                number=2, type=9, cpp_type=9, label=2,
                default_value="", message_type=None, enum_type=None,
                containing_type=None, is_extension=False, extension_scope=None,
                options=None),
            _descriptor.FieldDescriptor(
                name='attribute_run', full_name='Note.attribute_run', index=1,
                number=5, type=11, cpp_type=10, label=3,
                default_value=[], message_type=None, enum_type=None,
                containing_type=None, is_extension=False, extension_scope=None,
                options=None),
        ],
        extensions=[],
        nested_types=[],
        enum_types=[],
        options=None,
        is_extendable=False,
        syntax='proto2',
        extension_ranges=[],
        oneofs=[],
        serialized_start=None,
        serialized_end=None,
    )

    _DOCUMENT = _descriptor.Descriptor(
        name='Document',
        full_name='Document',
        filename=None,
        file=DESCRIPTOR,
        containing_type=None,
        fields=[
            _descriptor.FieldDescriptor(
                name='version', full_name='Document.version', index=0,
                number=2, type=5, cpp_type=1, label=2,
                default_value=0, message_type=None, enum_type=None,
                containing_type=None, is_extension=False, extension_scope=None,
                options=None),
            _descriptor.FieldDescriptor(
                name='note', full_name='Document.note', index=1,
                number=3, type=11, cpp_type=10, label=2,
                default_value=None, message_type=None, enum_type=None,
                containing_type=None, is_extension=False, extension_scope=None,
                options=None),
        ],
        extensions=[],
        nested_types=[],
        enum_types=[],
        options=None,
        is_extendable=False,
        syntax='proto2',
        extension_ranges=[],
        oneofs=[],
        serialized_start=None,
        serialized_end=None,
    )

    _NOTESTOREPROTO = _descriptor.Descriptor(
        name='NoteStoreProto',
        full_name='NoteStoreProto',
        filename=None,
        file=DESCRIPTOR,
        containing_type=None,
        fields=[
            _descriptor.FieldDescriptor(
                name='document', full_name='NoteStoreProto.document', index=0,
                number=2, type=11, cpp_type=10, label=2,
                default_value=None, message_type=None, enum_type=None,
                containing_type=None, is_extension=False, extension_scope=None,
                options=None),
        ],
        extensions=[],
        nested_types=[],
        enum_types=[],
        options=None,
        is_extendable=False,
        syntax='proto2',
        extension_ranges=[],
        oneofs=[],
        serialized_start=None,
        serialized_end=None,
    )

    # Set up type references
    _NOTE.fields_by_name['attribute_run'].message_type = _ATTRIBUTERUN
    _DOCUMENT.fields_by_name['note'].message_type = _NOTE
    _NOTESTOREPROTO.fields_by_name['document'].message_type = _DOCUMENT

    DESCRIPTOR.message_types_by_name['AttributeRun'] = _ATTRIBUTERUN
    DESCRIPTOR.message_types_by_name['Note'] = _NOTE
    DESCRIPTOR.message_types_by_name['Document'] = _DOCUMENT
    DESCRIPTOR.message_types_by_name['NoteStoreProto'] = _NOTESTOREPROTO

    # Create message classes
    class AttributeRun(_message.Message):
        __metaclass__ = _reflection.GeneratedProtocolMessageType
        DESCRIPTOR = _ATTRIBUTERUN

    class Note(_message.Message):
        __metaclass__ = _reflection.GeneratedProtocolMessageType
        DESCRIPTOR = _NOTE

    class Document(_message.Message):
        __metaclass__ = _reflection.GeneratedProtocolMessageType
        DESCRIPTOR = _DOCUMENT

    class NoteStoreProto(_message.Message):
        __metaclass__ = _reflection.GeneratedProtocolMessageType
        DESCRIPTOR = _NOTESTOREPROTO

    _reflection.GeneratedProtocolMessageType('AttributeRun', (_message.Message,), dict(
        DESCRIPTOR=_ATTRIBUTERUN,
        __module__='notestore_pb2'
    ))

    _reflection.GeneratedProtocolMessageType('Note', (_message.Message,), dict(
        DESCRIPTOR=_NOTE,
        __module__='notestore_pb2'
    ))

    _reflection.GeneratedProtocolMessageType('Document', (_message.Message,), dict(
        DESCRIPTOR=_DOCUMENT,
        __module__='notestore_pb2'
    ))

    _reflection.GeneratedProtocolMessageType('NoteStoreProto', (_message.Message,), dict(
        DESCRIPTOR=_NOTESTOREPROTO,
        __module__='notestore_pb2'
    ))

else:
    # Protobuf not available - provide fallback
    class NoteStoreProto:
        pass
    class Document:
        pass
    class Note:
        pass
    class AttributeRun:
        pass
