#!/usr/bin/env python3
"""
Passwords extractor for iOS backups.

Reads keychain-backup.plist and attempts to decrypt keychain items.
Designed to be schema-flexible across iOS versions; opaque records are
reported but not parsed.
"""

import os
import plistlib
from datetime import datetime
from typing import List, Dict, Any, Optional

from .base import CategoryDataExtractor
from keychain_decoder import decode_keychain_item


class PasswordsExtractor(CategoryDataExtractor):
    KEYCHAIN_DOMAIN = "KeychainDomain"
    KEYCHAIN_PATH = "keychain-backup.plist"
    SECTIONS = ("inet", "genp", "cert", "keys")

    def __init__(self, backup_path: str):
        super().__init__(backup_path)
        self.keychain_path = self.find_file_in_backup(self.KEYCHAIN_DOMAIN, self.KEYCHAIN_PATH)
        if not self.keychain_path:
            raise FileNotFoundError("keychain-backup.plist not found in backup")
        self._keychain_cache = None

    def _load_keychain(self) -> Dict[str, Any]:
        if self._keychain_cache is not None:
            return self._keychain_cache
        with open(self.keychain_path, "rb") as f:
            self._keychain_cache = plistlib.load(f)
        return self._keychain_cache

    def get_count(self) -> int:
        plist_data = self._load_keychain()
        return sum(len(plist_data.get(section) or []) for section in ("inet", "genp"))

    def get_items(self, limit: Optional[int] = None, offset: int = 0,
                  search: Optional[str] = None) -> List[Dict[str, Any]]:
        plist_data = self._load_keychain()
        items = []
        for section in self.SECTIONS:
            section_items = plist_data.get(section) or []
            for idx, item in enumerate(section_items):
                items.append({
                    "section": section,
                    "index": idx,
                    "v_Data": item.get("v_Data"),
                    "raw_item": item,
                })

        if offset:
            items = items[offset:]
        if limit is not None:
            items = items[:limit]

        if search:
            needle = search.lower()
            filtered = []
            for item in items:
                blob = item.get("v_Data") or b""
                if isinstance(blob, bytes) and needle.encode("utf-8", errors="ignore") in blob.lower():
                    filtered.append(item)
            items = filtered

        return items

    def get_item_summary(self, item: Dict[str, Any]) -> str:
        return f"{item.get('section')} item {item.get('index')}"

    def export(self, items: List[Dict[str, Any]], output_path: str,
               format: str = 'html', progress_callback=None, timeline_emitter=None) -> bool:
        try:
            self._reset_export_bytes()
            output_dir = output_path if os.path.isdir(output_path) else os.path.dirname(output_path)
            os.makedirs(output_dir, exist_ok=True)
            report_path = os.path.join(output_dir, "Passwords.html")
            raw_path = os.path.join(output_dir, "Passwords_Raw.html")
            friendly_path = os.path.join(output_dir, "Passwords_Friendly.html")
            app_like_path = os.path.join(output_dir, "Passwords_AppLike.html")

            keybag = None
            if getattr(self.backup_access, "is_encrypted", False):
                try:
                    keybag = self.backup_access._encrypted._keybag
                except Exception:
                    keybag = None

            decoded_items = []
            dump_items = []
            total = len(items)
            for i, item in enumerate(items, start=1):
                if progress_callback:
                    if not progress_callback(i, total, "Decrypting keychain items"):
                        return False
                decoded = decode_keychain_item(
                    item.get("v_Data") or b"",
                    keybag=keybag,
                    include_plaintext=True,
                    aad_extra=item.get("v_PersistentRef") if isinstance(item.get("v_PersistentRef"), (bytes, bytearray)) else None,
                )
                record = self._extract_fields(item, decoded)
                decoded_items.append(record)
                dump_items.append(self._build_dump_record(item, decoded))

            if timeline_emitter is not None:
                self._emit_timeline_events(decoded_items, timeline_emitter)

            raw_html = self._build_report(decoded_items)
            with open(raw_path, "w", encoding="utf-8") as f:
                f.write(raw_html)
            self._add_export_bytes(raw_path)
            friendly_html = self._build_friendly_report(decoded_items)
            with open(friendly_path, "w", encoding="utf-8") as f:
                f.write(friendly_html)
            self._add_export_bytes(friendly_path)
            app_like_html = self._build_app_like_report(decoded_items)
            with open(app_like_path, "w", encoding="utf-8") as f:
                f.write(app_like_html)
            self._add_export_bytes(app_like_path)
            with open(report_path, "w", encoding="utf-8") as f:
                f.write(app_like_html)
            self._add_export_bytes(report_path)
            dump_path = os.path.join(output_dir, "Passwords_dump.json")
            with open(dump_path, "w", encoding="utf-8") as f:
                import json
                json.dump(dump_items, f, indent=2)
            self._add_export_bytes(dump_path)
            return True
        except Exception as e:
            print(f"Error exporting passwords: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _extract_fields(self, item: Dict[str, Any], decoded: Dict[str, Any]) -> Dict[str, Any]:
        raw = decoded.get("decoded") or {}
        section = item.get("section")
        raw_item = item.get("raw_item") or {}

        def norm_value(value):
            if isinstance(value, bytes):
                try:
                    return value.decode("utf-8")
                except Exception:
                    return value.hex()
            if value is None:
                return ""
            return str(value)

        def find_key(keys):
            for key in keys:
                if key in raw:
                    return raw.get(key)
            return None

        account = norm_value(find_key(("acct", "account")))
        service = norm_value(find_key(("svce", "service")))
        server = norm_value(find_key(("srvr", "server")))
        label = norm_value(find_key(("labl", "label")))
        description = norm_value(find_key(("desc", "description")))
        group = norm_value(find_key(("agrp", "group")))
        path = norm_value(find_key(("path",)))
        port = norm_value(find_key(("port",)))
        protocol = norm_value(find_key(("ptcl", "protocol")))
        password = norm_value(find_key(("data", "v_Data", "kSecValueData", "value")))

        # Wi-Fi (AirPort) friendly labels.
        if service == "AirPort":
            if not description:
                description = "Wi-Fi network password"
            if not account and label:
                account = label

        created_raw, modified_raw = self._extract_keychain_dates(raw, raw_item)
        return {
            "section": section,
            "anchor": f"pw-{section}-{item.get('index')}",
            "status": decoded.get("status", "unknown"),
            "decrypt_mode": decoded.get("decrypt_mode", ""),
            "string_hints": decoded.get("string_hints") or [],
            "protobuf": decoded.get("protobuf") or {},
            "secret_hints": decoded.get("secret_string_hints") or [],
            "metadata_hints": decoded.get("metadata_string_hints") or [],
            "embedded_bplist": decoded.get("embedded_bplist"),
            "account": account,
            "service": service,
            "server": server,
            "label": label,
            "description": description,
            "group": group,
            "path": path,
            "port": port,
            "protocol": protocol,
            "password": password,
            "password_raw": find_key(("data", "v_Data", "kSecValueData", "value")),
            "raw_preview": decoded.get("raw_preview", ""),
            "created_raw": created_raw,
            "modified_raw": modified_raw,
        }

    def _build_dump_record(self, item: Dict[str, Any], decoded: Dict[str, Any]) -> Dict[str, Any]:
        raw_item = item.get("raw_item") or {}
        raw_meta, raw_fields = self._extract_raw_item_metadata(raw_item)
        return {
            "section": item.get("section"),
            "index": item.get("index"),
            "status": decoded.get("status"),
            "decrypt_mode": decoded.get("decrypt_mode"),
            "protobuf": decoded.get("protobuf"),
            "embedded_bplist": decoded.get("embedded_bplist"),
            "string_hints": decoded.get("string_hints"),
            "secret_string_hints": decoded.get("secret_string_hints"),
            "raw_preview": decoded.get("raw_preview"),
            "plaintext_b64": decoded.get("plaintext_b64"),
            "header": decoded.get("header"),
            "wrapped_key_b64": decoded.get("wrapped_key_b64"),
            "payload_b64": decoded.get("payload_b64"),
            "raw_item_meta": raw_meta,
            "raw_item_fields": raw_fields,
            "v_Data_b64": self._b64_bytes(raw_item.get("v_Data")),
            "v_PersistentRef_b64": self._b64_bytes(raw_item.get("v_PersistentRef")),
        }

    def _extract_keychain_dates(self, decoded: Dict[str, Any], raw_item: Dict[str, Any]) -> (Optional[Any], Optional[Any]):
        def pick(key):
            if key in decoded:
                return decoded.get(key)
            if key in raw_item:
                return raw_item.get(key)
            return None

        created = pick("cdat")
        modified = pick("mdat")
        return created, modified

    def _format_timestamp_iso(self, value: Any) -> Optional[str]:
        if value is None:
            return None
        if isinstance(value, datetime):
            return value.isoformat()
        try:
            ts = float(value)
        except Exception:
            return None
        try:
            if ts > 1_000_000_000_000:
                return datetime.fromtimestamp(ts / 1000.0).isoformat()
            if ts > 1_000_000_000:
                return datetime.fromtimestamp(ts).isoformat()
            if ts > 0:
                apple_epoch = datetime(2001, 1, 1).timestamp()
                return datetime.fromtimestamp(apple_epoch + ts).isoformat()
        except Exception:
            return None
        return None

    def _emit_timeline_events(self, items: List[Dict[str, Any]], timeline_emitter) -> None:
        for item in items:
            raw_ts = item.get("modified_raw") or item.get("created_raw")
            ts_iso = self._format_timestamp_iso(raw_ts)
            if not ts_iso:
                continue
            title = item.get("service") or item.get("server") or item.get("label") or item.get("account") or "Password Item"
            details = {
                "account": item.get("account") or "",
                "service": item.get("service") or "",
                "server": item.get("server") or "",
                "description": item.get("description") or "",
            }
            timeline_emitter.emit({
                "timestamp": ts_iso,
                "raw_timestamp": raw_ts,
                "raw_format": "keychain_date",
                "source_app": "Passwords",
                "source_category": "Passwords",
                "event_type": "credential",
                "title": title,
                "details": details,
                "confidence": "low",
                "raw_source_path": self.keychain_path,
                "report_anchor": item.get("anchor"),
                "link_hint": "Passwords/Passwords.html",
            })

    def _build_report(self, items: List[Dict[str, Any]]) -> str:
        rows = []
        for item in items:
            proto = item.get("protobuf") or {}
            if proto:
                if proto.get("has_secret") or proto.get("has_metadata"):
                    item["status"] = f"{item.get('status')} (proto)"
            rows.append(
                "<tr>"
                f"<td>{self._escape(item.get('section'))}</td>"
                f"<td>{self._escape(item.get('account'))}</td>"
                f"<td>{self._escape(item.get('service'))}</td>"
                f"<td>{self._escape(item.get('server'))}</td>"
                f"<td>{self._escape(item.get('label'))}</td>"
                f"<td>{self._escape(item.get('description'))}</td>"
                f"<td>{self._escape(item.get('protocol'))}</td>"
                f"<td>{self._escape(item.get('path'))}</td>"
                f"<td>{self._escape(item.get('port'))}</td>"
                f"<td class=\"password\">{self._format_value(item.get('password'), item.get('password_raw'))}</td>"
                f"<td class=\"status\">{self._escape(item.get('status'))}</td>"
                f"<td class=\"hints\">{self._escape(self._build_hints(item))}</td>"
                f"<td class=\"hints\">{self._escape(str(item.get('embedded_bplist') or ''))}</td>"
                "</tr>"
            )

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Passwords</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
            background: #f5f6fa;
            color: #1c1c1e;
            margin: 0;
        }}
        .page {{
            max-width: 1200px;
            margin: 20px auto;
            padding: 0 20px 40px;
        }}
        h1 {{
            margin: 10px 0 6px;
        }}
        .note {{
            color: #555;
            font-size: 14px;
            margin-bottom: 16px;
        }}
        .search {{
            margin: 10px 0 16px;
        }}
        .search input {{
            width: 100%;
            padding: 10px 12px;
            border-radius: 8px;
            border: 1px solid #d0d4da;
            font-size: 14px;
            box-sizing: border-box;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 2px 6px rgba(0,0,0,0.06);
            border-radius: 10px;
            overflow: hidden;
        }}
        th, td {{
            padding: 10px 12px;
            border-bottom: 1px solid #eef0f4;
            text-align: left;
            font-size: 13px;
        }}
        th {{
            background: #f0f3f7;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.02em;
        }}
        tr.hidden {{
            display: none;
        }}
        td.password {{
            font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace;
        }}
        td.password details {{
            cursor: pointer;
        }}
        td.password .blob {{
            margin-top: 6px;
            white-space: pre-wrap;
            word-break: break-all;
        }}
        td.status {{
            color: #6b7280;
            font-size: 12px;
        }}
        td.hints {{
            font-size: 12px;
            color: #5f6b7a;
        }}
        .search {{
            position: relative;
            margin: 16px 0;
        }}
        .search input {{
            width: 100%;
            padding: 10px 40px 10px 14px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            font-size: 14px;
            box-sizing: border-box;
        }}
        .clear-search {{
            position: absolute;
            right: 16px;
            top: 50%;
            transform: translateY(-50%);
            border: 1px solid #d1d5db;
            background: #f3f4f6;
            color: #111827;
            border-radius: 6px;
            padding: 4px 8px;
            font-size: 12px;
            cursor: pointer;
            display: none;
        }}
        .clear-search.visible {{ display: inline-block; }}
    </style>
</head>
<body>
    <div class="page">
        <h1>Passwords</h1>
        <div class="note">
            Keychain items may vary across iOS versions. Items that could not be decoded are listed with status.
        </div>
        <div class="search">
            <input type="text" id="searchInput" placeholder="Search accounts, services, servers..." onkeyup="filterRows()">
            <button id="clearSearch" class="clear-search" title="Clear" aria-label="Clear search">X</button>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Type</th>
                    <th>Account</th>
                    <th>Service</th>
                    <th>Server</th>
                    <th>Label</th>
                    <th>Description</th>
                    <th>Protocol</th>
                    <th>Path</th>
                    <th>Port</th>
                    <th>Password</th>
                    <th>Status</th>
                    <th>Hints</th>
                    <th>Embedded</th>
                </tr>
            </thead>
            <tbody id="rows">
                {''.join(rows)}
            </tbody>
        </table>
    </div>
<script>
function filterRows() {{
    const input = document.getElementById('searchInput');
    const filter = input.value.toLowerCase();
    const rows = document.querySelectorAll('#rows tr');
    rows.forEach(row => {{
        const text = row.innerText.toLowerCase();
        row.classList.toggle('hidden', filter && !text.includes(filter));
    }});
}}
</script>
<script>
const pwSearchInput = document.getElementById('searchInput');
const pwClearBtn = document.getElementById('clearSearch');
if (pwSearchInput && pwClearBtn) {{
    const toggleClear = () => pwClearBtn.classList.toggle('visible', !!pwSearchInput.value);
    pwSearchInput.addEventListener('input', toggleClear);
    pwClearBtn.addEventListener('click', () => {{
        pwSearchInput.value = '';
        toggleClear();
        if (typeof filterRows === 'function') {{
            filterRows();
        }}
        pwSearchInput.focus();
    }});
    toggleClear();
}}
</script>
</body>
</html>
"""

    def _build_friendly_report(self, items: List[Dict[str, Any]]) -> str:
        cards = []
        categories = ["Wi-Fi", "Websites", "Apps & Services", "Tokens", "Certificates", "Keys", "Other"]
        now = datetime.now()
        date_label = f"{now:%B} {now.day}, {now:%Y}"
        header_sub = f"Extracted from iOS Backup on {date_label}"
        for idx, item in enumerate(items):
            password = item.get("password")
            has_password = bool(password)
            is_human = self._is_human_password(password)
            account = item.get("account") or item.get("label") or ""
            service = item.get("service") or ""
            server = item.get("server") or ""
            description = item.get("description") or ""
            title = account or service or server or "Unnamed"
            subtitle = service or server or description
            category = self._categorize_item(item)
            if category == "Websites" and not is_human:
                category = "Tokens"
            if category == "Apps & Services" and not is_human and not any([account, service, server]):
                category = "Other"
            template = (
                "<div class=\"card\" data-category=\"{cat}\" data-has-password=\"{has_pw}\" data-human-password=\"{human_pw}\">"
                "<div class=\"card-header\">"
                "<div class=\"title\">{title}</div>"
                "<div class=\"subtitle\">{subtitle}</div>"
                "</div>"
                "<div class=\"row\">"
                "<span class=\"label\">Category</span>"
                "<span class=\"value\">{cat}</span>"
                "</div>"
                "<div class=\"row\">"
                "<span class=\"label\">Account</span>"
                "<span class=\"value\">{account}</span>"
                "</div>"
                "<div class=\"row\">"
                "<span class=\"label\">Password</span>"
                "<span class=\"value password\" data-raw=\"{pwd}\">"
                "<span class=\"masked\">********</span>"
                "<button class=\"reveal\" type=\"button\" data-target=\"pw-{idx}\">Show</button>"
                "</span>"
                "</div>"
                "<details class=\"details\">"
                "<summary>Details</summary>"
                "<div class=\"detail-grid\">"
                "<div><span class=\"label\">Service</span><span class=\"value\">{service}</span></div>"
                "<div><span class=\"label\">Server</span><span class=\"value\">{server}</span></div>"
                "<div><span class=\"label\">Description</span><span class=\"value\">{desc}</span></div>"
                "<div><span class=\"label\">Protocol</span><span class=\"value\">{protocol}</span></div>"
                "<div><span class=\"label\">Path</span><span class=\"value\">{path}</span></div>"
                "<div><span class=\"label\">Port</span><span class=\"value\">{port}</span></div>"
                "</div>"
                "</details>"
                "</div>"
            )
            cards.append(template.format(
                cat=self._escape(category),
                has_pw="true" if has_password else "false",
                human_pw="true" if is_human else "false",
                title=self._escape(title),
                subtitle=self._escape(subtitle),
                account=self._escape(account),
                pwd=self._escape(password) if password else "",
                idx=idx,
                service=self._escape(service),
                server=self._escape(server),
                desc=self._escape(description),
                protocol=self._escape(item.get("protocol") or ""),
                path=self._escape(item.get("path") or ""),
                port=self._escape(item.get("port") or ""),
            ))
        chip_html = "".join(
            f"<button class=\"chip\" data-category=\"{self._escape(cat)}\">{self._escape(cat)}</button>"
            for cat in categories
        )
        return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Passwords</title>
  <style>
    :root {{
      --bg: #f5f6fa;
      --card: #ffffff;
      --text: #1c1c1e;
      --muted: #6b7280;
      --accent: #2d6cdf;
      --border: #e5e7eb;
    }}
    body {{
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
      background: var(--bg);
      color: var(--text);
      margin: 0;
    }}
    .page {{
      max-width: 1200px;
      margin: 20px auto;
      padding: 0 20px 40px;
    }}
    h1 {{
      margin: 10px 0 6px;
    }}
    .note {{
      color: var(--muted);
      font-size: 14px;
      margin-bottom: 16px;
    }}
    .toolbar {{
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      align-items: center;
      margin-bottom: 16px;
    }}
    .search-wrap {{
      position: relative;
      flex: 1 1 240px;
      min-width: 220px;
    }}
    .search-wrap input {{
      width: 100%;
      padding: 10px 40px 10px 12px;
      border-radius: 8px;
      border: 1px solid var(--border);
      font-size: 14px;
      box-sizing: border-box;
    }}
    .clear-search {{
      position: absolute;
      right: 12px;
      top: 50%;
      transform: translateY(-50%);
      border: 1px solid #d1d5db;
      background: #f3f4f6;
      color: #111827;
      border-radius: 6px;
      padding: 4px 8px;
      font-size: 12px;
      cursor: pointer;
      display: none;
    }}
    .clear-search.visible {{ display: inline-block; }}
    .chips {{
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
    }}
    .chip {{
      border: 1px solid var(--border);
      background: #fff;
      padding: 6px 10px;
      border-radius: 999px;
      font-size: 12px;
      color: var(--muted);
      cursor: pointer;
    }}
    .chip.active {{
      border-color: var(--accent);
      color: var(--accent);
      font-weight: 600;
    }}
    .toggle {{
      display: inline-flex;
      align-items: center;
      gap: 8px;
      font-size: 12px;
      color: var(--muted);
    }}
    .count {{
      font-size: 12px;
      color: var(--muted);
      margin-left: auto;
    }}
    .grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
      gap: 14px;
    }}
    .card {{
      background: var(--card);
      border: 1px solid var(--border);
      border-radius: 14px;
      padding: 14px;
      box-shadow: 0 4px 10px rgba(15, 23, 42, 0.05);
    }}
    .card-header {{
      margin-bottom: 10px;
    }}
    .title {{
      font-weight: 600;
      font-size: 15px;
    }}
    .subtitle {{
      font-size: 12px;
      color: var(--muted);
    }}
    .row {{
      display: flex;
      justify-content: space-between;
      gap: 10px;
      padding: 6px 0;
      border-bottom: 1px solid #f2f4f7;
    }}
    .row:last-child {{
      border-bottom: none;
    }}
    .label {{
      color: var(--muted);
      font-size: 12px;
      min-width: 72px;
    }}
    .value {{
      font-size: 13px;
      word-break: break-word;
      text-align: right;
    }}
    .password {{
      display: inline-flex;
      gap: 8px;
      align-items: center;
    }}
    .masked {{
      letter-spacing: 2px;
    }}
    .reveal {{
      border: 1px solid var(--border);
      background: #fff;
      color: var(--accent);
      font-size: 11px;
      border-radius: 999px;
      padding: 4px 8px;
      cursor: pointer;
    }}
    details {{
      margin-top: 8px;
      font-size: 12px;
      color: var(--muted);
    }}
    .detail-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
      gap: 8px;
      margin-top: 8px;
    }}
    .detail-grid .value {{
      text-align: left;
      color: var(--text);
    }}
    .header {{
      background: linear-gradient(135deg, #0f172a, #1d4ed8);
      color: #fff;
      padding: 24px 20px;
      max-width: 1200px;
      margin: 20px 20px 0 20px;
      border-radius: 12px;
      box-shadow: 0 8px 18px rgba(15, 23, 42, 0.12);
    }}
    .header-inner {{
      max-width: 1200px;
      margin: 0 auto;
    }}
    .breadcrumbs {{
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 12px;
      letter-spacing: 0.2px;
      color: rgba(255,255,255,0.85);
      margin-bottom: 10px;
    }}
    .breadcrumbs a {{
      color: #fff;
      text-decoration: none;
      font-weight: 600;
    }}
    .breadcrumbs a:hover {{
      text-decoration: underline;
    }}
    .breadcrumbs .back-arrow {{
      opacity: 0.6;
    }}
    .embedded .breadcrumbs {{
      display: none;
    }}
    .header-title {{
      font-size: 22px;
      font-weight: 700;
      margin: 0 0 4px;
    }}
    .header-sub {{
      font-size: 13px;
      opacity: 0.85;
      margin: 0;
    }}
  </style>
</head>
<body>
  <div class="header">
    <div class="header-inner">
      <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Start_Here.html">Back</a></div>
      <div class="header-title">Passwords</div>
      <div class="header-sub">{header_sub}</div>
    </div>
  </div>
  <div class="page">
    <h1>Passwords</h1>
    <div class="note">Sensitive data. Use filters and search to find the item you need.</div>
    <div class="toolbar">
      <div class="search-wrap">
        <input type="text" id="searchInput" placeholder="Search by name, service, or server">
        <button id="clearSearch" class="clear-search" title="Clear" aria-label="Clear search">X</button>
      </div>
      <label class="toggle"><input type="checkbox" id="onlyWithPassword" checked> Only show items with passwords</label>
      <label class="toggle"><input type="checkbox" id="onlyHumanPasswords" checked> Only show human passwords</label>
      <span class="count" id="visibleCount"></span>
    </div>
    <div class="chips" id="chips">{chip_html}</div>
    <div class="grid" id="grid">
      {''.join(cards)}
    </div>
  </div>
<script>
const grid = document.getElementById('grid');
const searchInput = document.getElementById('searchInput');
const onlyWithPassword = document.getElementById('onlyWithPassword');
const onlyHumanPasswords = document.getElementById('onlyHumanPasswords');
const visibleCount = document.getElementById('visibleCount');
const chips = document.querySelectorAll('.chip');
let activeCategory = '';

function filterCards() {{
  const term = searchInput.value.toLowerCase();
  let visible = 0;
  grid.querySelectorAll('.card').forEach(card => {{
    const matchesSearch = !term || card.innerText.toLowerCase().includes(term);
    const matchesCategory = !activeCategory || card.dataset.category === activeCategory;
    const matchesPassword = !onlyWithPassword.checked || card.dataset.hasPassword === 'true';
    const matchesHuman = !onlyHumanPasswords.checked || card.dataset.humanPassword === 'true';
    const show = (matchesSearch && matchesCategory && matchesPassword && matchesHuman);
    card.style.display = show ? '' : 'none';
    if (show) {{
      visible += 1;
    }}
  }});
  visibleCount.textContent = `${{visible}} shown`;
}}

chips.forEach(chip => {{
  chip.addEventListener('click', () => {{
    const category = chip.dataset.category;
    if (activeCategory === category) {{
      activeCategory = '';
    }} else {{
      activeCategory = category;
    }}
    chips.forEach(c => c.classList.toggle('active', c.dataset.category === activeCategory));
    filterCards();
  }});
}});

searchInput.addEventListener('input', filterCards);
onlyWithPassword.addEventListener('change', filterCards);
onlyHumanPasswords.addEventListener('change', filterCards);
const clearBtn = document.getElementById('clearSearch');
if (clearBtn && searchInput) {{
  const toggleClear = () => clearBtn.classList.toggle('visible', !!searchInput.value);
  searchInput.addEventListener('input', toggleClear);
  clearBtn.addEventListener('click', () => {{
    searchInput.value = '';
    toggleClear();
    filterCards();
    searchInput.focus();
  }});
  toggleClear();
}}
filterCards();

grid.addEventListener('click', (event) => {{
  if (!event.target.classList.contains('reveal')) return;
  const btn = event.target;
  const valueEl = btn.closest('.password');
  const raw = valueEl.dataset.raw || '';
  const masked = valueEl.querySelector('.masked');
  if (btn.textContent === 'Show') {{
    masked.textContent = raw || 'N/A';
    btn.textContent = 'Hide';
  }} else {{
    masked.textContent = '********';
    btn.textContent = 'Show';
  }}
}});
</script>
</body>
</html>
"""

    def _categorize_item(self, item: Dict[str, Any]) -> str:
        section = (item.get("section") or "").lower()
        service = (item.get("service") or "").lower()
        label = (item.get("label") or "").lower()
        description = (item.get("description") or "").lower()
        if service == "airport" or "wifi" in description:
            return "Wi-Fi"
        if section == "inet":
            return "Websites"
        if "token" in service or "token" in label or "token" in description:
            return "Tokens"
        if section == "genp":
            return "Apps & Services"
        if section == "cert":
            return "Certificates"
        if section == "keys":
            return "Keys"
        return "Other"

    def _build_app_like_report(self, items: List[Dict[str, Any]]) -> str:
        now = datetime.now()
        date_label = f"{now:%B} {now.day}, {now:%Y}"
        header_sub = f"Extracted from iOS Backup on {date_label}"
        normalized = []
        for item in items:
            account = item.get("account") or ""
            label = item.get("label") or ""
            service = item.get("service") or ""
            server = item.get("server") or ""
            description = item.get("description") or ""
            password = item.get("password") or ""
            human_password = self._is_human_password(password)
            category = self._categorize_item(item)
            if category == "Websites" and not human_password:
                category = "Tokens"
            if category == "Apps & Services" and not human_password and not any([account, label, service, server]):
                category = "Other"

            display = service or server or label or account or "Unnamed"
            secondary = account if display in (service, server) and account else (server or description or "")
            normalized.append({
                "category": category,
                "display": display,
                "secondary": secondary,
                "account": account,
                "service": service,
                "server": server,
                "description": description,
                "protocol": item.get("protocol") or "",
                "path": item.get("path") or "",
                "port": item.get("port") or "",
                "password": password,
                "human_password": human_password,
                "anchor": item.get("anchor") or "",
            })

        # Compute weak/reused flags on human passwords.
        from collections import Counter
        password_map = {}
        for entry in normalized:
            pwd = entry.get("password") or ""
            if self._is_human_password(pwd):
                password_map.setdefault(pwd, []).append(entry)
        reused_set = {pwd for pwd, entries in password_map.items() if len(entries) > 1}

        for entry in normalized:
            pwd = entry.get("password") or ""
            entry["weak"] = entry["human_password"] and self._is_weak_password(pwd)
            entry["reused"] = entry["human_password"] and pwd in reused_set

        counts = {
            "All": len(normalized),
            "Wi-Fi": sum(1 for e in normalized if e["category"] == "Wi-Fi"),
            "Websites": sum(1 for e in normalized if e["category"] == "Websites"),
            "Apps & Services": sum(1 for e in normalized if e["category"] == "Apps & Services"),
            "Tokens": sum(1 for e in normalized if e["category"] == "Tokens"),
            "Security": sum(1 for e in normalized if e["weak"] or e["reused"]),
        }

        rows_data = []
        for idx, entry in enumerate(normalized):
            flags = []
            if entry["weak"]:
                flags.append("weak")
            if entry["reused"]:
                flags.append("reused")
            rows_data.append({
                "index": idx,
                "anchor": entry.get("anchor") or "",
                "category": entry["category"],
                "flags": flags,
                "human": entry["human_password"],
                "has_password": bool(entry["password"]),
                "display": entry["display"],
                "secondary": entry["secondary"],
                "account": entry["account"],
                "service": entry["service"],
                "server": entry["server"],
                "description": entry["description"],
                "protocol": entry["protocol"],
                "path": entry["path"],
                "port": entry["port"],
                "password": entry["password"],
                "icon": entry["category"][:1],
            })

        import json
        rows_json = json.dumps(rows_data).replace("</", "<\\/")

        rail_html = "".join(
            "<button data-category=\"{cat}\">{cat}<span>{count}</span></button>".format(
                cat=self._escape(cat),
                count=counts[cat],
            )
            for cat in counts
        )

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Passwords</title>
  <style>
    :root {{
      --bg: #f5f6fa;
      --panel: #ffffff;
      --text: #1c1c1e;
      --muted: #6b7280;
      --accent: #2d6cdf;
      --border: #e5e7eb;
      --badge: #eef2ff;
      --row-height: 72px;
    }}
    body {{
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
      background: var(--bg);
      color: var(--text);
      margin: 0;
    }}
    .page-wrap {{
      max-width: 1400px;
      margin: 0 auto;
    }}
    .header {{
      background: linear-gradient(135deg, #0f172a, #1d4ed8);
      color: #fff;
      padding: 24px 20px;
      margin: 0;
      border-radius: 16px 16px 0 0;
      box-shadow: 0 10px 22px rgba(15, 23, 42, 0.15);
    }}
    .header-title {{
      font-size: 32px;
      font-weight: 600;
      margin: 0 0 10px;
    }}
    .header-sub {{
      font-size: 16px;
      opacity: 0.9;
      margin: 0;
    }}
    .breadcrumbs {{
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 12px;
      letter-spacing: 0.2px;
      color: rgba(255,255,255,0.85);
      margin-bottom: 10px;
    }}
    .breadcrumbs a {{
      color: #fff;
      text-decoration: none;
      font-weight: 600;
    }}
    .breadcrumbs a:hover {{
      text-decoration: underline;
    }}
    .breadcrumbs .back-arrow {{
      opacity: 0.6;
    }}
    .embedded .breadcrumbs {{
      display: none;
    }}
    .layout {{
      display: grid;
      grid-template-columns: 220px 1fr 360px;
      column-gap: 16px;
      row-gap: 0;
      padding: 20px;
      margin: 0;
    }}
    .layout .header {{
      grid-column: 1 / -1;
    }}
    .panel.rail {{
      border-top-left-radius: 0;
      border-top-right-radius: 0;
    }}
    .panel {{
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 16px;
      padding: 16px;
      box-shadow: 0 4px 10px rgba(15, 23, 42, 0.05);
      min-width: 0;
    }}
    .rail h2 {{
      font-size: 16px;
      margin: 0 0 12px;
    }}
    .rail button {{
      width: 100%;
      display: flex;
      justify-content: space-between;
      padding: 8px 10px;
      border: 1px solid transparent;
      background: transparent;
      border-radius: 10px;
      font-size: 13px;
      color: var(--text);
      cursor: pointer;
    }}
    .rail button.active {{
      background: var(--badge);
      border-color: #c7d2fe;
      color: #1d4ed8;
      font-weight: 600;
    }}
    .search-wrap {{
      position: relative;
      margin-bottom: 12px;
    }}
    .search {{
      width: 100%;
      padding: 10px 40px 10px 12px;
      border-radius: 10px;
      border: 1px solid var(--border);
      font-size: 13px;
      box-sizing: border-box;
    }}
    .clear-search {{
      position: absolute;
      right: 12px;
      top: 50%;
      transform: translateY(-50%);
      border: 1px solid #d1d5db;
      background: #f3f4f6;
      color: #111827;
      border-radius: 6px;
      padding: 4px 8px;
      font-size: 12px;
      cursor: pointer;
      display: none;
    }}
    .clear-search.visible {{ display: inline-block; }}
    .toolbar {{
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      align-items: center;
      margin-bottom: 12px;
      font-size: 12px;
      color: var(--muted);
    }}
    .toggle input {{
      margin-right: 6px;
    }}
    .count {{
      margin-left: auto;
      font-size: 12px;
      color: var(--muted);
    }}
    .list {{
      position: relative;
      height: 70vh;
      overflow: auto;
    }}
    .list-spacer {{
      height: 0;
    }}
    .list-items {{
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
    }}
    .list.no-virtual .list-spacer {{
      display: none;
    }}
    .list.no-virtual .list-items {{
      position: static;
      transform: none !important;
    }}
    .list-row {{
      display: flex;
      gap: 12px;
      align-items: center;
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 10px;
      cursor: pointer;
      background: #fff;
      position: relative;
      height: var(--row-height);
      box-sizing: border-box;
      min-width: 0;
      max-width: 100%;
    }}
    .list.no-virtual .list-row {{
      height: auto;
      margin-bottom: 8px;
    }}
    .list-row.active {{
      border-color: var(--accent);
      box-shadow: 0 6px 12px rgba(45, 108, 223, 0.15);
    }}
    .row-icon {{
      width: 34px;
      height: 34px;
      border-radius: 10px;
      background: var(--badge);
      display: flex;
      align-items: center;
      justify-content: center;
      color: var(--accent);
      font-weight: 700;
    }}
    .row-main {{
      min-width: 0;
      flex: 1 1 auto;
    }}
    .row-title {{
      font-size: 14px;
      font-weight: 600;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      overflow-wrap: anywhere;
      word-break: break-word;
    }}
    .row-sub {{
      font-size: 12px;
      color: var(--muted);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      overflow-wrap: anywhere;
      word-break: break-word;
    }}
    .row-badges {{
      margin-left: auto;
      display: flex;
      gap: 6px;
    }}
    .row-details {{
      display: none;
      width: 100%;
      padding-top: 10px;
      border-top: 1px solid #f2f4f7;
      margin-top: 6px;
    }}
    .list-row.expanded .row-details {{
      display: block;
    }}
    .badge {{
      background: var(--badge);
      color: #4338ca;
      font-size: 10px;
      padding: 2px 6px;
      border-radius: 999px;
    }}
    .detail h3 {{
      margin: 0 0 8px;
    }}
    .detail-row {{
      display: flex;
      justify-content: space-between;
      gap: 12px;
      padding: 6px 0;
      border-bottom: 1px solid #f2f4f7;
      font-size: 13px;
      min-width: 0;
    }}
    .detail-row:last-child {{
      border-bottom: none;
    }}
    .detail-label {{
      color: var(--muted);
      min-width: 90px;
    }}
    .detail-value {{
      min-width: 0;
      flex: 1 1 auto;
      max-width: 100%;
      overflow-wrap: anywhere;
      word-break: break-word;
    }}
    .password-value {{
      font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace;
    }}
    .reveal {{
      border: 1px solid var(--border);
      background: #fff;
      color: var(--accent);
      font-size: 11px;
      border-radius: 999px;
      padding: 4px 8px;
      cursor: pointer;
      margin-left: 8px;
    }}
    @media (max-width: 1100px) {{
      .layout {{
        grid-template-columns: 1fr;
      }}
      .list {{
        height: 60vh;
      }}
      .panel.detail {{
        display: none;
      }}
    }}
  </style>
</head>
<body>
  <div class="page-wrap">
    <div class="layout">
      <div class="header">
        <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Start_Here.html">Back</a></div>
        <div class="header-title">Passwords</div>
        <div class="header-sub">{header_sub}</div>
      </div>
    <div class="panel rail">
      <h2>Passwords</h2>
      {rail_html}
    </div>
    <div class="panel">
      <div class="search-wrap">
        <input class="search" id="searchInput" placeholder="Search by name, service, or server">
        <button id="clearSearch" class="clear-search" title="Clear" aria-label="Clear search">X</button>
      </div>
      <div class="toolbar">
        <label class="toggle"><input type="checkbox" id="onlyWithPassword" checked> Only show items with passwords</label>
        <label class="toggle"><input type="checkbox" id="onlyHumanPasswords" checked> Only show human passwords</label>
        <span class="count" id="visibleCount"></span>
      </div>
      <div class="list" id="list">
        <div class="list-spacer" id="listSpacer"></div>
        <div class="list-items" id="listItems"></div>
      </div>
    </div>
    <div class="panel detail" id="detail">
      <h3>Select a password</h3>
      <div class="detail-row"><span class="detail-label">Account</span><span class="detail-value" id="detailAccount">-</span></div>
      <div class="detail-row"><span class="detail-label">Password</span><span class="detail-value password-value" id="detailPassword">-</span></div>
      <div class="detail-row"><span class="detail-label">Service</span><span class="detail-value" id="detailService">-</span></div>
      <div class="detail-row"><span class="detail-label">Server</span><span class="detail-value" id="detailServer">-</span></div>
      <div class="detail-row"><span class="detail-label">Description</span><span class="detail-value" id="detailDescription">-</span></div>
      <div class="detail-row"><span class="detail-label">Protocol</span><span class="detail-value" id="detailProtocol">-</span></div>
      <div class="detail-row"><span class="detail-label">Path</span><span class="detail-value" id="detailPath">-</span></div>
      <div class="detail-row"><span class="detail-label">Port</span><span class="detail-value" id="detailPort">-</span></div>
    </div>
    </div>
  </div>
<script>
const data = {rows_json};
const list = document.getElementById('list');
const listSpacer = document.getElementById('listSpacer');
const listItems = document.getElementById('listItems');
const searchInput = document.getElementById('searchInput');
const onlyWithPassword = document.getElementById('onlyWithPassword');
const onlyHumanPasswords = document.getElementById('onlyHumanPasswords');
const visibleCount = document.getElementById('visibleCount');
const railButtons = document.querySelectorAll('.rail button');
let activeCategory = 'All';
let filtered = data.slice();
let activeIndex = null;
let rowHeight = 72;
let renderRaf = null;

data.forEach((item) => {{
  const parts = [
    item.display,
    item.secondary,
    item.account,
    item.service,
    item.server,
    item.description,
    item.protocol,
    item.path,
    item.port,
    item.password,
  ];
  item.search = parts.filter(Boolean).join(' ').toLowerCase();
}});

function updateRowHeight() {{
  const rootStyles = getComputedStyle(document.documentElement);
  const value = rootStyles.getPropertyValue('--row-height');
  const parsed = parseFloat(value);
  if (!Number.isNaN(parsed) && parsed > 0) {{
    rowHeight = parsed;
  }}
}}

function buildRow(item, inlineDetails) {{
  const row = document.createElement('div');
  row.className = 'list-row';
  if (item.anchor) row.id = item.anchor;
  if (item.index === activeIndex) {{
    row.classList.add('active');
  }}
  row.dataset.index = item.index;

  const icon = document.createElement('div');
  icon.className = 'row-icon';
  icon.textContent = item.icon || '';

  const main = document.createElement('div');
  main.className = 'row-main';
  const title = document.createElement('div');
  title.className = 'row-title';
  title.textContent = item.display || 'Unnamed';
  const sub = document.createElement('div');
  sub.className = 'row-sub';
  sub.textContent = item.secondary || '';
  title.title = title.textContent || '';
  sub.title = sub.textContent || '';
  main.appendChild(title);
  main.appendChild(sub);

  const badges = document.createElement('div');
  badges.className = 'row-badges';
  (item.flags || []).forEach(flag => {{
    const badge = document.createElement('span');
    badge.className = 'badge';
    badge.textContent = flag;
    badges.appendChild(badge);
  }});

  row.appendChild(icon);
  row.appendChild(main);
  row.appendChild(badges);
  if (inlineDetails) {{
    const details = document.createElement('div');
    details.className = 'row-details';
    details.innerHTML = `
      <div class="detail-row"><span class="detail-label">Account</span><span class="detail-value"></span></div>
      <div class="detail-row"><span class="detail-label">Password</span><span class="detail-value password-value"></span></div>
      <div class="detail-row"><span class="detail-label">Service</span><span class="detail-value"></span></div>
      <div class="detail-row"><span class="detail-label">Server</span><span class="detail-value"></span></div>
      <div class="detail-row"><span class="detail-label">Description</span><span class="detail-value"></span></div>
      <div class="detail-row"><span class="detail-label">Protocol</span><span class="detail-value"></span></div>
      <div class="detail-row"><span class="detail-label">Path</span><span class="detail-value"></span></div>
      <div class="detail-row"><span class="detail-label">Port</span><span class="detail-value"></span></div>
    `;
    row.appendChild(details);
  }}
  return row;
}}

function setDetail(item) {{
  const empty = !item;
  const account = empty ? '-' : (item.account || '-');
  const password = empty ? '-' : (item.password || '-');
  const service = empty ? '-' : (item.service || '-');
  const server = empty ? '-' : (item.server || '-');
  const description = empty ? '-' : (item.description || '-');
  const protocol = empty ? '-' : (item.protocol || '-');
  const path = empty ? '-' : (item.path || '-');
  const port = empty ? '-' : (item.port || '-');
  const detailAccount = document.getElementById('detailAccount');
  const detailPassword = document.getElementById('detailPassword');
  const detailService = document.getElementById('detailService');
  const detailServer = document.getElementById('detailServer');
  const detailDescription = document.getElementById('detailDescription');
  const detailProtocol = document.getElementById('detailProtocol');
  const detailPath = document.getElementById('detailPath');
  const detailPort = document.getElementById('detailPort');
  detailAccount.textContent = account;
  detailPassword.textContent = password;
  detailService.textContent = service;
  detailServer.textContent = server;
  detailDescription.textContent = description;
  detailProtocol.textContent = protocol;
  detailPath.textContent = path;
  detailPort.textContent = port;
  detailAccount.title = account;
  detailPassword.title = password;
  detailService.title = service;
  detailServer.title = server;
  detailDescription.title = description;
  detailProtocol.title = protocol;
  detailPath.title = path;
  detailPort.title = port;
}}

function setInlineDetail(row, item) {{
  const values = row.querySelectorAll('.row-details .detail-value');
  if (values.length < 8) {{
    return;
  }}
  const account = item.account || '-';
  const password = item.password || '-';
  const service = item.service || '-';
  const server = item.server || '-';
  const description = item.description || '-';
  const protocol = item.protocol || '-';
  const path = item.path || '-';
  const port = item.port || '-';
  values[0].textContent = account;
  values[1].textContent = password;
  values[2].textContent = service;
  values[3].textContent = server;
  values[4].textContent = description;
  values[5].textContent = protocol;
  values[6].textContent = path;
  values[7].textContent = port;
  values[0].title = account;
  values[1].title = password;
  values[2].title = service;
  values[3].title = server;
  values[4].title = description;
  values[5].title = protocol;
  values[6].title = path;
  values[7].title = port;
}}

function isNarrow() {{
  return window.matchMedia('(max-width: 1100px)').matches;
}}

function applyFilters() {{
  const term = searchInput.value.trim().toLowerCase();
  filtered = data.filter(item => {{
    const isSecurity = activeCategory === 'Security';
    const matchesCategory = activeCategory === 'All' || (isSecurity ? true : item.category === activeCategory);
    const matchesSecurity = !isSecurity || (item.flags && item.flags.length > 0);
    const matchesSearch = !term || (item.search && item.search.includes(term));
    const matchesPassword = !onlyWithPassword.checked || item.has_password;
    const matchesHuman = !onlyHumanPasswords.checked || item.human;
    return matchesCategory && matchesSecurity && matchesSearch && matchesPassword && matchesHuman;
  }});
  visibleCount.textContent = `${{filtered.length}} shown`;
  if (activeIndex !== null) {{
    const stillVisible = filtered.some(item => item.index === activeIndex);
    if (!stillVisible) {{
      activeIndex = null;
      setDetail(null);
    }}
  }}
  if (isNarrow()) {{
    renderAll();
  }} else {{
    updateSpacer();
    renderVisible();
  }}
}}

function updateSpacer() {{
  listSpacer.style.height = `${{filtered.length * rowHeight}}px`;
}}

function renderVisible() {{
  if (isNarrow()) {{
    return;
  }}
  if (renderRaf) {{
    cancelAnimationFrame(renderRaf);
  }}
  renderRaf = requestAnimationFrame(() => {{
    const scrollTop = list.scrollTop;
    const viewportHeight = list.clientHeight;
    const start = Math.max(0, Math.floor(scrollTop / rowHeight) - 10);
    const end = Math.min(filtered.length, Math.ceil((scrollTop + viewportHeight) / rowHeight) + 10);
    listItems.style.transform = `translateY(${{start * rowHeight}}px)`;
    listItems.innerHTML = '';
    const fragment = document.createDocumentFragment();
    for (let i = start; i < end; i += 1) {{
      fragment.appendChild(buildRow(filtered[i], false));
    }}
    listItems.appendChild(fragment);
  }});
}}

function renderAll() {{
  list.classList.add('no-virtual');
  listItems.innerHTML = '';
  const fragment = document.createDocumentFragment();
  filtered.forEach(item => {{
    const row = buildRow(item, true);
    if (item.index === activeIndex) {{
      row.classList.add('expanded');
      setInlineDetail(row, item);
    }}
    fragment.appendChild(row);
  }});
  listItems.appendChild(fragment);
}}

railButtons.forEach(btn => {{
  btn.addEventListener('click', () => {{
    railButtons.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    activeCategory = btn.dataset.category;
    applyFilters();
  }});
}});
if (railButtons.length) {{
  railButtons[0].classList.add('active');
}}

listItems.addEventListener('click', (event) => {{
  const row = event.target.closest('.list-row');
  if (!row) {{
    return;
  }}
  const idx = Number(row.dataset.index);
  if (Number.isNaN(idx)) {{
    return;
  }}
  activeIndex = idx;
  const item = data.find(entry => entry.index === idx);
  if (isNarrow()) {{
    listItems.querySelectorAll('.list-row').forEach(r => r.classList.remove('expanded'));
    row.classList.add('expanded');
    if (item) {{
      setInlineDetail(row, item);
    }}
  }} else {{
    setDetail(item || null);
  }}
  renderVisible();
}});

list.addEventListener('scroll', renderVisible);
searchInput.addEventListener('input', applyFilters);
onlyWithPassword.addEventListener('change', applyFilters);
onlyHumanPasswords.addEventListener('change', applyFilters);
const clearBtn = document.getElementById('clearSearch');
if (clearBtn && searchInput) {{
  const toggleClear = () => clearBtn.classList.toggle('visible', !!searchInput.value);
  searchInput.addEventListener('input', toggleClear);
  clearBtn.addEventListener('click', () => {{
    searchInput.value = '';
    toggleClear();
    applyFilters();
    searchInput.focus();
  }});
  toggleClear();
}}

updateRowHeight();
applyFilters();
window.addEventListener('resize', () => {{
  updateRowHeight();
  if (isNarrow()) {{
    renderAll();
  }} else {{
    list.classList.remove('no-virtual');
    updateSpacer();
    renderVisible();
  }}
}});
</script>
<script>
  if (window.self !== window.top) {{ document.body.classList.add('embedded'); }}
</script>
<script>
  if (window.self !== window.top) {{ document.body.classList.add('embedded'); }}
</script>
</body>
</html>
"""

    def _is_human_password(self, value: Any) -> bool:
        if not value:
            return False
        text = str(value).strip()
        if len(text) == 0:
            return False
        if "\x00" in text or "\ufffd" in text:
            return False
        if len(text) > 48:
            return False
        # Base64-like tokens are not human passwords.
        b64_chars = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=")
        if len(text) >= 24 and all(ch in b64_chars for ch in text):
            return False
        # Require mostly printable characters.
        printable = sum(1 for ch in text if ch.isprintable())
        if printable / len(text) < 0.9:
            return False
        # Require some variety (avoid tokens with only one class).
        has_alpha = any(ch.isalpha() for ch in text)
        has_digit = any(ch.isdigit() for ch in text)
        if not (has_alpha and has_digit):
            return False
        return True

    def _is_weak_password(self, value: Any) -> bool:
        if not value:
            return False
        text = str(value).strip()
        if len(text) < 8:
            return True
        if text.isalpha() or text.isdigit():
            return True
        return False

    def _build_hints(self, item: Dict[str, Any]) -> str:
        hints = []
        for key in ("string_hints", "secret_hints", "metadata_hints"):
            hints.extend(item.get(key) or [])
        # De-duplicate while preserving order.
        seen = set()
        ordered = []
        for hint in hints:
            if hint in seen:
                continue
            seen.add(hint)
            ordered.append(hint)
        return ", ".join(ordered)

    def _format_value(self, value: Any, raw: Any = None) -> str:
        if value is None:
            return ""
        text = str(value)
        if len(text) <= 200:
            return self._escape(text)
        raw_bytes = raw if isinstance(raw, (bytes, bytearray)) else None
        if raw_bytes is not None:
            import base64
            payload = base64.b64encode(raw_bytes).decode("ascii")
        else:
            payload = text
        summary = f"[binary {len(payload)} chars]"
        return (
            "<details>"
            f"<summary>{self._escape(summary)}</summary>"
            f"<div class=\"blob\">{self._escape(payload)}</div>"
            "</details>"
        )

    def _escape(self, value: Any) -> str:
        if value is None:
            return ""
        text = str(value)
        return (
            text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
            .replace("'", "&#39;")
        )

    def _b64_bytes(self, value: Any) -> Optional[str]:
        if not isinstance(value, (bytes, bytearray)):
            return None
        import base64
        return base64.b64encode(bytes(value)).decode("ascii")

    def _extract_raw_item_metadata(self, raw_item: Dict[str, Any]) -> (Dict[str, Any], Dict[str, Any]):
        raw_meta = {
            "item_keys": sorted(raw_item.keys()),
        }
        raw_fields = {}
        candidate_keys = (
            "v_KeyClass",
            "keyclass",
            "class",
            "kSecAttrAccessible",
            "agrp",
            "acct",
            "svce",
            "srvr",
            "labl",
            "desc",
            "ptcl",
            "path",
            "port",
            "uuid",
            "musr",
            "sync",
        )
        for key in candidate_keys:
            if key not in raw_item:
                continue
            value = raw_item.get(key)
            if isinstance(value, (bytes, bytearray)):
                raw_fields[key] = {
                    "b64": self._b64_bytes(value),
                    "len": len(value),
                }
            else:
                raw_fields[key] = value
        return raw_meta, raw_fields
