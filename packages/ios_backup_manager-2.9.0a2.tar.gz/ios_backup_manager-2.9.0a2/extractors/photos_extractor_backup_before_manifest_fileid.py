#!/usr/bin/env python3
"""
Photos data extractor for iOS backups.

Extracts photos/videos from iOS backups with actual image file access,
thumbnail generation, and export to directory with original filenames.
"""

import sqlite3
import os
import hashlib
import shutil
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime, timezone
from io import BytesIO
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading
from .base import CategoryDataExtractor

# Try to import PIL for image processing
try:
    from PIL import Image
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False
    print("[WARNING] PIL (Pillow) not available - thumbnail generation will be disabled")

# Try to import pillow_heif for HEIC conversion
try:
    from pillow_heif import register_heif_opener
    # Register HEIF opener with PIL
    register_heif_opener()
    HEIC_CONVERSION_AVAILABLE = True
except ImportError:
    HEIC_CONVERSION_AVAILABLE = False


class PhotosExtractor(CategoryDataExtractor):
    """Extract and export photos/videos from iOS backup."""

    def __init__(self, backup_path: str):
        super().__init__(backup_path)

        # Find Photos database
        self.photos_db_path = self.find_db_file(
            "CameraRollDomain",
            "Media/PhotoData/Photos.sqlite"
        )

        if not self.photos_db_path:
            raise FileNotFoundError("Photos.sqlite not found in backup")

        # Detect schema version
        self.schema_version = self._detect_schema()

        # Detect album relationship table name (varies by iOS version)
        self.album_assets_table = self._detect_album_assets_table()

        # Detect column names (vary by iOS version)
        self._detect_asset_columns()

        # Thumbnail cache {photo_id: PIL.Image}
        self.thumbnail_cache = {}

        # Path to Manifest.db for hybrid extraction
        self.manifest_db_path = os.path.join(backup_path, 'Manifest.db')

        # Enable hybrid extraction with proper filtering
        # This ensures we only extract files that exist, but keep metadata from Photos.sqlite
        self.use_hybrid_extraction = True
        # Optional cache of manifest paths
        self._manifest_camroll_paths = None
        # Cache of available CameraRoll files from Manifest.db (relative paths)

        # Cache for hybrid extraction results to avoid re-processing on every call
        self._hybrid_items_cache = None
        self._hybrid_cache_params = None  # Store params used for cache

        # Build file existence cache for accurate counts and filtering
        # Only full-res files (thumbnails used as fallback during extraction if needed)
        print("[INFO] Building file existence cache...")
        self._file_existence_cache, self._thumbnail_only_cache, self._actual_file_count = self._build_file_existence_cache()
        print(f"[INFO] File existence cache built: {self._actual_file_count:,} full-res files found")

        # Build metadata lookup index for linking Adjustments/Mutations files to originals
        print("[INFO] Building metadata lookup index...")
        self._metadata_lookup_index = self._build_metadata_lookup_index()
        print(f"[INFO] Metadata lookup index built: {len(self._metadata_lookup_index):,} entries")

    def _build_file_existence_cache(self):
        """
        Build TWO caches of photo/video files that exist in the backup.

        Uses Manifest.db as the source of truth. Builds:
        1. Full-res cache: All standard media files (excluding thumbnails)
        2. Thumbnail-only cache: Filenames that ONLY exist as thumbnails (no full-res version)

        This allows complete coverage while prioritizing full-res files.

        Returns:
            Tuple of (full_res_cache, thumbnail_only_cache, full_res_count) where:
            - full_res_cache: Set of paths/filenames for full-resolution files
            - thumbnail_only_cache: Set of filenames that only exist as thumbnails
            - full_res_count: Number of unique full-resolution files
        """
        if not os.path.exists(self.manifest_db_path):
            return set(), set(), 0

        try:
            conn = sqlite3.connect(f"file:{self.manifest_db_path}?mode=ro", uri=True)
            cur = conn.cursor()

            # Get all full-res media files from CameraRollDomain (excluding thumbnails)
            cur.execute("""
                SELECT relativePath
                FROM Files
                WHERE domain = 'CameraRollDomain'
                  AND relativePath NOT LIKE '%Thumbnails%'
                  AND relativePath NOT LIKE '%.db%'
                  AND relativePath NOT LIKE '%.plist%'
                  AND relativePath NOT LIKE '%.sqlite%'
                  AND (relativePath LIKE '%.JPG' OR relativePath LIKE '%.jpg'
                       OR relativePath LIKE '%.jpeg' OR relativePath LIKE '%.JPEG'
                       OR relativePath LIKE '%.PNG' OR relativePath LIKE '%.png'
                       OR relativePath LIKE '%.HEIC' OR relativePath LIKE '%.heic'
                       OR relativePath LIKE '%.DNG' OR relativePath LIKE '%.dng'
                       OR relativePath LIKE '%.MOV' OR relativePath LIKE '%.mov'
                       OR relativePath LIKE '%.MP4' OR relativePath LIKE '%.mp4'
                       OR relativePath LIKE '%.M4V' OR relativePath LIKE '%.m4v'
                       OR relativePath LIKE '%.gif' OR relativePath LIKE '%.GIF')
            """)

            # Build set of paths and filenames, filtering out derivatives
            derivative_patterns = [
                'FullSizeRender.',
                'Adjusted.',
                'proxy.heic',
                'portrait-layer_background.',
            ]

            # Build full-res cache
            full_res_paths = set()
            full_res_basenames = set()
            file_count = 0

            for row in cur.fetchall():
                rel_path = row[0]
                basename = os.path.basename(rel_path)

                # Skip derivative/adjusted files
                is_derivative = any(pattern in basename for pattern in derivative_patterns)
                if not is_derivative:
                    file_count += 1
                    # Store both the full relative path and just the basename
                    # Strip 'Media/' prefix if present for Photos.sqlite compatibility
                    normalized_path = rel_path[6:] if rel_path.startswith('Media/') else rel_path
                    full_res_paths.add(normalized_path)  # e.g., 'DCIM/100APPLE/IMG_0001.JPG'
                    full_res_paths.add(basename)  # e.g., 'IMG_0001.JPG' (for backward compat)
                    full_res_basenames.add(basename)  # Track basenames separately

            # Now build thumbnail-only cache for filenames that don't have full-res versions
            # Only include high-quality V2 thumbnails (worth extracting as fallback)
            cur.execute("""
                SELECT relativePath
                FROM Files
                WHERE domain = 'CameraRollDomain'
                  AND (relativePath LIKE '%Thumbnails/V2/%'
                       OR relativePath LIKE '%PhotoData/Thumbnails/%')
                  AND (relativePath LIKE '%.JPG' OR relativePath LIKE '%.jpg'
                       OR relativePath LIKE '%.jpeg' OR relativePath LIKE '%.JPEG'
                       OR relativePath LIKE '%.PNG' OR relativePath LIKE '%.png'
                       OR relativePath LIKE '%.HEIC' OR relativePath LIKE '%.heic'
                       OR relativePath LIKE '%.DNG' OR relativePath LIKE '%.dng'
                       OR relativePath LIKE '%.MOV' OR relativePath LIKE '%.mov'
                       OR relativePath LIKE '%.MP4' OR relativePath LIKE '%.mp4'
                       OR relativePath LIKE '%.M4V' OR relativePath LIKE '%.m4v'
                       OR relativePath LIKE '%.gif' OR relativePath LIKE '%.GIF')
            """)

            thumbnail_only_basenames = set()
            for row in cur.fetchall():
                rel_path = row[0]
                basename = os.path.basename(rel_path)

                # Only add if no full-res version exists
                if basename not in full_res_basenames:
                    is_derivative = any(pattern in basename for pattern in derivative_patterns)
                    if not is_derivative:
                        thumbnail_only_basenames.add(basename)

            conn.close()

            return full_res_paths, thumbnail_only_basenames, file_count

        except Exception as e:
            print(f"[WARNING] Failed to build file existence cache: {e}")
            return set(), set(), 0

    def _photo_file_exists(self, filename: str = None, directory: str = None) -> bool:
        """
        Check if a full-res photo file exists in the backup by filename or path.

        Checks ONLY full-res files (thumbnails are used as fallback during extraction,
        not during filtering, to match old extraction behavior).

        Args:
            filename: Photo filename (e.g., 'IMG_0001.JPG')
            directory: Photo directory (e.g., 'DCIM/100APPLE')

        Returns:
            True if full-res file exists in backup, False otherwise
        """
        if not filename:
            return False

        # If directory is provided, check full path first (most accurate)
        if directory:
            full_path = f"{directory}/{filename}"
            if full_path in self._file_existence_cache:
                return True  # Full-res file exists

        # Check filename in full-res cache
        if filename in self._file_existence_cache:
            return True

        # Controlled fallback: allow DNGs that only exist as thumbnails (V2/high-quality)
        ext = os.path.splitext(filename)[1].lower()
        if ext == '.dng' and filename in self._thumbnail_only_cache:
            return True

        return False

    def _detect_schema(self) -> str:
        """
        Detect which schema version this Photos database uses.

        Returns:
            'ios13+' for ZASSET table (iOS 13+)
            'legacy' for ZGENERICASSET table (iOS 10 and earlier)
        """
        conn = sqlite3.connect(self.photos_db_path)
        cur = conn.cursor()

        # Check for ZASSET table (iOS 13+)
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='ZASSET'")
        if cur.fetchone():
            conn.close()
            return 'ios13+'

        # Check for ZGENERICASSET table (iOS 10 and earlier)
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='ZGENERICASSET'")
        if cur.fetchone():
            conn.close()
            return 'legacy'

        conn.close()
        raise ValueError("Unknown Photos.sqlite schema - neither ZASSET nor ZGENERICASSET table found")

    def _detect_album_assets_table(self) -> Optional[str]:
        """
        Detect the name of the album-assets relationship table.

        Core Data generates tables like Z_26ASSETS, Z_27ASSETS, etc.
        The number varies by iOS version.

        Returns:
            Table name or None if not found
        """
        conn = sqlite3.connect(self.photos_db_path)
        cur = conn.cursor()

        # Find table names that match pattern Z_XXASSETS
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'Z_%ASSETS'")
        tables = [row[0] for row in cur.fetchall()]

        # Look for a table with columns that link albums to assets
        for table in tables:
            try:
                cur.execute(f"PRAGMA table_info({table})")
                columns = [row[1] for row in cur.fetchall()]

                # Check if it has the expected columns (album and asset foreign keys)
                # Typical pattern: Z_XXALBUMS and Z_XXASSETS or similar
                album_col = next((col for col in columns if 'ALBUM' in col.upper()), None)
                asset_col = next((col for col in columns if 'ASSET' in col.upper()), None)

                if album_col and asset_col:
                    pass  # Detected album-assets table
                    conn.close()
                    return table
            except:
                continue

        conn.close()
        print("[WARNING] Could not detect album-assets relationship table")
        return None

    def _detect_asset_columns(self):
        """
        Detect actual column names in ZASSET table.

        iOS versions vary in their column naming:
        - Some use ZPIXELWIDTH/ZPIXELHEIGHT
        - Others use ZWIDTH/ZHEIGHT
        """
        conn = sqlite3.connect(self.photos_db_path)
        cur = conn.cursor()

        # Default values
        self.width_column = 'ZWIDTH'
        self.height_column = 'ZHEIGHT'

        if self.schema_version == 'ios13+':
            # Get column names from ZASSET table
            cur.execute("PRAGMA table_info(ZASSET)")
            columns = [row[1] for row in cur.fetchall()]

            # Check which dimension columns exist
            if 'ZPIXELWIDTH' in columns:
                self.width_column = 'ZPIXELWIDTH'
                self.height_column = 'ZPIXELHEIGHT'
            elif 'ZWIDTH' in columns:
                self.width_column = 'ZWIDTH'
                self.height_column = 'ZHEIGHT'

            pass  # Detected dimension columns
        else:
            # Legacy schema always uses ZWIDTH/ZHEIGHT
            self.width_column = 'ZWIDTH'
            self.height_column = 'ZHEIGHT'

        conn.close()

    def get_albums(self) -> List[Dict[str, Any]]:
        """
        Get list of albums from Photos database.

        Returns:
            List of album dictionaries with 'z_pk', 'title', and 'count' fields
        """
        conn = sqlite3.connect(self.photos_db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        albums = []

        # Add "All Photos" as first option
        total_count = self.get_count()
        albums.append({
            'z_pk': None,
            'title': 'All Photos',
            'count': total_count
        })

        # Query albums from ZGENERICALBUM table
        try:
            # Get albums with their photo counts
            if self.schema_version == 'ios13+' and self.album_assets_table:
                # iOS 13+ with detected relationship table
                # First, get column names from relationship table
                cur.execute(f"PRAGMA table_info({self.album_assets_table})")
                columns = [row[1] for row in cur.fetchall()]
                album_col = next((col for col in columns if 'ALBUM' in col.upper()), None)

                if album_col:
                    cur.execute(f"""
                        SELECT
                            Z_PK,
                            ZTITLE,
                            (SELECT COUNT(*)
                             FROM {self.album_assets_table}
                             WHERE {album_col} = ZGENERICALBUM.Z_PK) as photo_count
                        FROM ZGENERICALBUM
                        WHERE ZTITLE IS NOT NULL
                        ORDER BY ZTITLE
                    """)
                else:
                    # Fallback: no counts
                    cur.execute("""
                        SELECT Z_PK, ZTITLE, 0 as photo_count
                        FROM ZGENERICALBUM
                        WHERE ZTITLE IS NOT NULL
                        ORDER BY ZTITLE
                    """)
            else:
                # Legacy schema or no relationship table detected
                cur.execute("""
                    SELECT
                        Z_PK,
                        ZTITLE,
                        0 as photo_count
                    FROM ZGENERICALBUM
                    WHERE ZTITLE IS NOT NULL
                    ORDER BY ZTITLE
                """)

            for row in cur.fetchall():
                count = row['photo_count'] if row['photo_count'] else 0
                # Only include albums with photos
                if count > 0:
                    albums.append({
                        'z_pk': row['Z_PK'],
                        'title': row['ZTITLE'] or 'Unnamed Album',
                        'count': count
                    })

        except sqlite3.OperationalError as e:
            # Table might not exist or schema might be different
            print(f"[WARNING] Could not query albums: {e}")

        conn.close()
        return albums

    def get_count(self, album_id: Optional[int] = None, filter_by_existence: bool = True,
                  date_from: Optional[float] = None, date_to: Optional[float] = None) -> int:
        """
        Get total number of photos/videos.

        Args:
            album_id: Optional album Z_PK to filter by
            filter_by_existence: If True (default), return count of files that exist in backup.
                                If False, return all Photos.sqlite items (extraction mode).
            date_from: Optional start date filter (Apple epoch timestamp)
            date_to: Optional end date filter (Apple epoch timestamp)

        Returns:
            Count of photos/videos

        Note: When filter_by_existence=True, uses Manifest.db as source of truth.
        When filter_by_existence=False, returns all Photos.sqlite items for maximum coverage.
        """
        if album_id is None:
            if filter_by_existence:
                # Preview mode: Return count of actual files
                if self.use_hybrid_extraction:
                    # Hybrid mode: If date filter, count items; else return cached count
                    if date_from is not None or date_to is not None:
                        items = self.get_items_hybrid(limit=None, offset=0, filter_by_existence=True,
                                                       date_from=date_from, date_to=date_to)
                        return len(items)
                    else:
                        return self._actual_file_count
                else:
                    # Non-hybrid mode: Get Photos.sqlite items and count those with files
                    items = self.get_items(limit=None, offset=0, filter_by_existence=True,
                                          date_from=date_from, date_to=date_to)
                    return len(items)
            else:
                # Extraction mode: Return all Photos.sqlite items
                if self.use_hybrid_extraction:
                    # Get all items without filtering and return the count
                    items = self.get_items_hybrid(limit=None, offset=0, filter_by_existence=False,
                                                   date_from=date_from, date_to=date_to)
                    return len(items)
                else:
                    # Count all Photos.sqlite items with date filter
                    conn = sqlite3.connect(self.photos_db_path)
                    cur = conn.cursor()
                    if self.schema_version == 'ios13+':
                        query = """
                            SELECT COUNT(*)
                            FROM ZASSET
                            WHERE (ZTRASHEDSTATE = 0 OR ZTRASHEDSTATE IS NULL)
                        """
                        params = []
                        if date_from is not None:
                            query += " AND ZDATECREATED >= ?"
                            params.append(date_from)
                        if date_to is not None:
                            query += " AND ZDATECREATED <= ?"
                            params.append(date_to)
                        cur.execute(query, params)
                    else:
                        cur.execute("SELECT COUNT(*) FROM ZGENERICASSET")
                    count = cur.fetchone()[0]
                    conn.close()
                    return count
        else:
            # Album-specific count
            # For accurate counts with file existence filtering, get items and count them
            if filter_by_existence:
                # Get filtered items for this album and count them (with date filter)
                items = self.get_items(limit=None, offset=0, album_id=album_id, filter_by_existence=True,
                                      date_from=date_from, date_to=date_to)
                return len(items)
            else:
                # Extraction mode: return database count (may include items without files)
                conn = sqlite3.connect(self.photos_db_path)
                conn.row_factory = sqlite3.Row
                cur = conn.cursor()

                if self.schema_version == 'ios13+' and self.album_assets_table:
                    # Get column names from relationship table
                    temp_conn = sqlite3.connect(self.photos_db_path)
                    temp_cur = temp_conn.cursor()
                    temp_cur.execute(f"PRAGMA table_info({self.album_assets_table})")
                    columns = [row[1] for row in temp_cur.fetchall()]
                    album_col = next((col for col in columns if 'ALBUM' in col.upper()), None)
                    asset_col = next((col for col in columns if 'ASSET' in col.upper()), None)
                    temp_conn.close()

                    if album_col and asset_col:
                        cur.execute(f"""
                            SELECT COUNT(*)
                            FROM ZASSET
                            JOIN {self.album_assets_table} ON ZASSET.Z_PK = {self.album_assets_table}.{asset_col}
                            WHERE {self.album_assets_table}.{album_col} = ?
                              AND (ZASSET.ZTRASHEDSTATE = 0 OR ZASSET.ZTRASHEDSTATE IS NULL)
                        """, (album_id,))
                        count = cur.fetchone()[0]
                        conn.close()
                        return count
                    else:
                        conn.close()
                        return 0
                else:
                    # Legacy schema - return all photos
                    cur.execute("SELECT COUNT(*) FROM ZGENERICASSET")
                    count = cur.fetchone()[0]
                    conn.close()
                    return count

    def validate_count_async(self, callback=None, album_id: Optional[int] = None):
        """
        Validate the actual count in a background thread (for hybrid extraction).
        This performs the slow validation without blocking the UI.

        Args:
            callback: Function to call with accurate count when done: callback(count)
            album_id: Optional album filter
        """
        def _validate_in_background():
            try:
                # Get exact count with file validation
                conn = sqlite3.connect(self.photos_db_path)
                cur = conn.cursor()

                # Same query logic as get_count()
                if album_id is not None:
                    try:
                        cur.execute("""
                            SELECT COUNT(DISTINCT a.Z_PK)
                            FROM ZASSET a
                            JOIN Z_26ASSETS aa ON a.Z_PK = aa.Z_3ASSETS
                            JOIN ZGENERICALBUM ga ON aa.Z_26ALBUMS = ga.Z_PK
                            WHERE ga.Z_PK = ?
                            AND (a.ZTRASHEDSTATE = 0 OR a.ZTRASHEDSTATE IS NULL)
                        """, (album_id,))
                    except sqlite3.OperationalError:
                        cur.execute("SELECT 0")
                else:
                    try:
                        cur.execute("SELECT COUNT(*) FROM ZASSET WHERE ZTRASHEDSTATE = 0 OR ZTRASHEDSTATE IS NULL")
                    except sqlite3.OperationalError:
                        try:
                            cur.execute("SELECT COUNT(*) FROM ZGENERICASSET")
                        except sqlite3.OperationalError:
                            cur.execute("SELECT 0")

                count = cur.fetchone()[0]
                conn.close()

                # Validate actual file existence for accurate count
                # Get all items (database + manifest if hybrid)
                saved_hybrid_setting = self.use_hybrid_extraction
                all_items = self.get_items(limit=None, offset=0)
                self.use_hybrid_extraction = saved_hybrid_setting

                # Count only items where files actually exist
                valid_count = 0
                for item in all_items:
                    source_path = self.find_image_file(item)
                    if source_path and os.path.exists(source_path):
                        valid_count += 1

                # Call callback with accurate count (only existing files)
                if callback:
                    callback(valid_count)

            except Exception as e:
                # If validation fails, log error and don't update count
                print(f"[ERROR] validate_count_async failed: {e}")
                import traceback
                traceback.print_exc()
                # Don't call callback on error - leave the estimate in place

        # Start background thread
        thread = threading.Thread(target=_validate_in_background, daemon=True)
        thread.start()
        return thread

    def get_items(self, limit: Optional[int] = None, offset: int = 0,
                  search: Optional[str] = None, album_id: Optional[int] = None,
                  sort_by: str = 'date-desc', filter_by_existence: bool = True,
                  date_from: Optional[float] = None, date_to: Optional[float] = None) -> List[Dict[str, Any]]:
        """
        Get photos/videos with pagination and optional search.

        Uses Manifest.db as source of truth for file existence when hybrid mode is disabled.
        Uses Photos.sqlite only for metadata enrichment.

        Args:
            limit: Maximum number of items to return
            offset: Number of items to skip
            search: Optional search filter
            album_id: Optional album filter
            sort_by: Sort order ('date-desc', 'date-asc', etc.)
            filter_by_existence: If True (default), only return items whose files exist in backup.
                                If False, return all items (extraction mode - some may fail).
            date_from: Optional start date filter (Apple epoch timestamp)
            date_to: Optional end date filter (Apple epoch timestamp)

        Returns list of photo dictionaries with fields:
        - z_pk: Primary key
        - uuid: Photo UUID
        - filename: Original filename
        - date_created: Creation date (Apple epoch timestamp)
        - width: Image width in pixels
        - height: Image height in pixels
        - kind: Media type (0=photo, 1=video)
        - duration: Video duration in seconds (if video)
        - directory: Directory path (e.g., "DCIM/100APPLE")
        - source: 'database' or 'manifest' (indicates data source)
        """
        # If hybrid extraction is enabled and no album filter, use hybrid method
        if self.use_hybrid_extraction and album_id is None:
            return self.get_items_hybrid(limit=limit, offset=offset, search=search, album_id=album_id,
                                        sort_by=sort_by, filter_by_existence=filter_by_existence,
                                        date_from=date_from, date_to=date_to)

        # Otherwise, use Photos.sqlite (for all other cases)
        conn = sqlite3.connect(self.photos_db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        if self.schema_version == 'ios13+':
            # iOS 13+ schema with ZASSET
            if album_id is None:
                # All photos
                query = f"""
                    SELECT
                        ZASSET.Z_PK,
                        ZASSET.ZUUID,
                        ZASSET.ZFILENAME,
                        ZASSET.ZDATECREATED,
                        ZASSET.{self.width_column} as ZPIXELWIDTH,
                        ZASSET.{self.height_column} as ZPIXELHEIGHT,
                        ZASSET.ZKIND,
                        ZASSET.ZDURATION,
                        ZASSET.ZDIRECTORY
                    FROM ZASSET
                    WHERE (ZASSET.ZTRASHEDSTATE = 0 OR ZASSET.ZTRASHEDSTATE IS NULL)
                """
                # Add date range filter if specified
                if date_from is not None:
                    query += " AND ZASSET.ZDATECREATED >= ?"
                if date_to is not None:
                    query += " AND ZASSET.ZDATECREATED <= ?"
            else:
                # Photos in specific album - need to detect column names
                if self.album_assets_table:
                    temp_conn = sqlite3.connect(self.photos_db_path)
                    temp_cur = temp_conn.cursor()
                    temp_cur.execute(f"PRAGMA table_info({self.album_assets_table})")
                    columns = [row[1] for row in temp_cur.fetchall()]
                    album_col = next((col for col in columns if 'ALBUM' in col.upper()), None)
                    asset_col = next((col for col in columns if 'ASSET' in col.upper()), None)
                    temp_conn.close()

                    if album_col and asset_col:
                        query = f"""
                            SELECT
                                ZASSET.Z_PK,
                                ZASSET.ZUUID,
                                ZASSET.ZFILENAME,
                                ZASSET.ZDATECREATED,
                                ZASSET.{self.width_column} as ZPIXELWIDTH,
                                ZASSET.{self.height_column} as ZPIXELHEIGHT,
                                ZASSET.ZKIND,
                                ZASSET.ZDURATION,
                                ZASSET.ZDIRECTORY
                            FROM ZASSET
                            JOIN {self.album_assets_table} ON ZASSET.Z_PK = {self.album_assets_table}.{asset_col}
                            WHERE {self.album_assets_table}.{album_col} = ?
                            AND (ZASSET.ZTRASHEDSTATE = 0 OR ZASSET.ZTRASHEDSTATE IS NULL)
                        """
                        # Add date range filter if specified
                        if date_from is not None:
                            query += " AND ZASSET.ZDATECREATED >= ?"
                        if date_to is not None:
                            query += " AND ZASSET.ZDATECREATED <= ?"
                    else:
                        # Fallback: just show all photos
                        query = f"""
                            SELECT
                                ZASSET.Z_PK,
                                ZASSET.ZUUID,
                                ZASSET.ZFILENAME,
                                ZASSET.ZDATECREATED,
                                ZASSET.{self.width_column} as ZPIXELWIDTH,
                                ZASSET.{self.height_column} as ZPIXELHEIGHT,
                                ZASSET.ZKIND,
                                ZASSET.ZDURATION,
                                ZASSET.ZDIRECTORY
                            FROM ZASSET
                            WHERE (ZASSET.ZTRASHEDSTATE = 0 OR ZASSET.ZTRASHEDSTATE IS NULL)
                        """
                        # Add date range filter if specified
                        if date_from is not None:
                            query += " AND ZASSET.ZDATECREATED >= ?"
                        if date_to is not None:
                            query += " AND ZASSET.ZDATECREATED <= ?"
                else:
                    # No relationship table - just show all photos
                    query = f"""
                        SELECT
                            ZASSET.Z_PK,
                            ZASSET.ZUUID,
                            ZASSET.ZFILENAME,
                            ZASSET.ZDATECREATED,
                            ZASSET.{self.width_column} as ZPIXELWIDTH,
                            ZASSET.{self.height_column} as ZPIXELHEIGHT,
                            ZASSET.ZKIND,
                            ZASSET.ZDURATION,
                            ZASSET.ZDIRECTORY
                        FROM ZASSET
                        WHERE (ZASSET.ZTRASHEDSTATE = 0 OR ZASSET.ZTRASHEDSTATE IS NULL)
                    """
                    # Add date range filter if specified
                    if date_from is not None:
                        query += " AND ZASSET.ZDATECREATED >= ?"
                    if date_to is not None:
                        query += " AND ZASSET.ZDATECREATED <= ?"

            params = [album_id] if album_id is not None and self.album_assets_table else []

            # Add date filter parameters
            if date_from is not None:
                params.append(date_from)
            if date_to is not None:
                params.append(date_to)

            if search:
                # Search in filename
                query += " AND ZASSET.ZFILENAME LIKE ?"
                params.append(f"%{search}%")

            # Apply sorting
            if sort_by == 'date-asc':
                query += " ORDER BY ZASSET.ZDATECREATED ASC"
            elif sort_by == 'name-asc':
                query += " ORDER BY ZASSET.ZFILENAME ASC"
            elif sort_by == 'name-desc':
                query += " ORDER BY ZASSET.ZFILENAME DESC"
            else:
                query += " ORDER BY ZASSET.ZDATECREATED DESC"

            # Only apply LIMIT/OFFSET at SQL level if NOT filtering by existence
            # When filtering, we need to get all items, filter them, then paginate
            if limit is not None and not filter_by_existence:
                query += f" LIMIT {limit} OFFSET {offset}"

        else:
            # Legacy schema with ZGENERICASSET
            query = """
                SELECT
                    Z_PK,
                    ZUUID,
                    ZFILENAME,
                    ZDATECREATED,
                    ZWIDTH as ZPIXELWIDTH,
                    ZHEIGHT as ZPIXELHEIGHT,
                    ZKIND,
                    ZDURATION,
                    ZDIRECTORY
                FROM ZGENERICASSET
            """
            params = []

            if search:
                query += " WHERE ZFILENAME LIKE ?"
                params.append(f"%{search}%")

            if sort_by == 'date-asc':
                query += " ORDER BY ZDATECREATED ASC"
            elif sort_by == 'name-asc':
                query += " ORDER BY ZFILENAME ASC"
            elif sort_by == 'name-desc':
                query += " ORDER BY ZFILENAME DESC"
            else:
                query += " ORDER BY ZDATECREATED DESC"

            # Only apply LIMIT/OFFSET at SQL level if NOT filtering by existence
            # When filtering, we need to get all items, filter them, then paginate
            if limit is not None and not filter_by_existence:
                query += f" LIMIT {limit} OFFSET {offset}"

        cur.execute(query, params)
        rows = cur.fetchall()

        photos = []
        for row in rows:
            filename = row['ZFILENAME'] or 'Unknown'
            directory = row['ZDIRECTORY'] or 'DCIM/100APPLE'
            # Normalize directory to avoid double "Media/" or backslashes
            dir_norm = directory.replace('\\', '/').lstrip('/')
            if dir_norm.lower().startswith('media/'):
                dir_norm = dir_norm[6:]

            photo = {
                'z_pk': row['Z_PK'],
                'uuid': row['ZUUID'] or '',
                'filename': filename,
                'date_created': row['ZDATECREATED'],
                'width': row['ZPIXELWIDTH'] or 0,
                'height': row['ZPIXELHEIGHT'] or 0,
                'kind': row['ZKIND'] or 0,  # 0=photo, 1=video
                'duration': row['ZDURATION'] or 0,
                'directory': directory,
                'source': 'database'  # Mark as coming from Photos.sqlite
            }
            photos.append(photo)

        conn.close()

        # Apply file existence filtering if requested
        if filter_by_existence:
            # Filter to only items whose files exist in backup
            filtered_photos = []
            for photo in photos:
                filename = photo.get('filename')
                directory = photo.get('directory')
                if filename and self._photo_file_exists(filename=filename, directory=directory):
                    filtered_photos.append(photo)

            # Apply pagination to filtered results (since we got ALL items from DB)
            if limit is not None:
                return filtered_photos[offset:offset+limit]
            return filtered_photos
        else:
            # Return all items (extraction mode)
            # Pagination already applied at SQL level
            return photos

    def _build_metadata_lookup_index(self) -> Dict[Tuple[str, str], Dict[str, Any]]:
        """
        Build a lookup index mapping (directory, base_filename) to photo metadata.

        This enables linking Adjustments/Mutations files (like FullSizeRender.jpg)
        to their original photos in Photos.sqlite, inheriting metadata like date_created.

        Returns:
            Dict mapping (directory, base_filename_without_ext) to metadata dict containing:
            - date_created, width, height, kind, duration, etc.
        """
        if not os.path.exists(self.photos_db_path):
            return {}

        conn = sqlite3.connect(self.photos_db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        try:
            # Query all assets with their directory and filename
            query = f"""
                SELECT
                    Z_PK as z_pk,
                    ZFILENAME as filename,
                    ZDIRECTORY as directory,
                    ZDATECREATED as date_created,
                    {self.width_column} as width,
                    {self.height_column} as height,
                    ZKIND as kind,
                    ZDURATION as duration
                FROM ZASSET
                WHERE ZTRASHEDSTATE = 0 OR ZTRASHEDSTATE IS NULL
            """

            cur.execute(query)

            index = {}
            for row in cur.fetchall():
                directory = row['directory']
                filename = row['filename']

                if not directory or not filename:
                    continue

                # Extract base filename without extension
                # e.g., "IMG_9952.HEIC" -> "IMG_9952"
                base_filename = os.path.splitext(filename)[0]

                # Create lookup key (directory, base_filename)
                key = (directory, base_filename)

                # Store metadata (if multiple matches, keep first/newest)
                if key not in index:
                    index[key] = {
                        'z_pk': row['z_pk'],
                        'date_created': row['date_created'],
                        'width': row['width'] or 0,
                        'height': row['height'] or 0,
                        'kind': row['kind'],
                        'duration': row['duration'] or 0
                    }

            return index

        except Exception as e:
            print(f"[WARNING] Failed to build metadata lookup index: {e}")
            return {}
        finally:
            conn.close()

    def _get_manifest_items(self) -> List[Dict[str, Any]]:
        """
        Get additional media files from CameraRollDomain in Manifest.db.

        These are files that exist in the backup but aren't tracked in Photos.sqlite:
        - Live Photo companion MOV files
        - Edited versions in Mutations folder
        - CPLAssets (iCloud Photo Library assets) in Metadata folders
        - Other media files not indexed in database

        Returns:
            List of items with same structure as get_items(), but with source='manifest'
        """
        if not os.path.exists(self.manifest_db_path):
            print("[WARNING] Manifest.db not found - hybrid extraction disabled")
            return []

        conn = sqlite3.connect(self.manifest_db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        # Get full-res media from CameraRollDomain, excluding thumbnails.
        # Controlled fallback: include DNG even if only present in thumbnails (V2/high quality).
        cur.execute("""
            SELECT fileID, relativePath, domain
            FROM Files
            WHERE domain = 'CameraRollDomain'
              AND (
                  (
                      relativePath NOT LIKE '%/Thumbnails/%' AND (
                          relativePath LIKE '%.heic' OR
                          relativePath LIKE '%.heif' OR
                          relativePath LIKE '%.jpg' OR
                          relativePath LIKE '%.jpeg' OR
                          relativePath LIKE '%.png' OR
                          relativePath LIKE '%.mov' OR
                          relativePath LIKE '%.mp4' OR
                          relativePath LIKE '%.m4v' OR
                          relativePath LIKE '%.HEIC' OR
                          relativePath LIKE '%.HEIF' OR
                          relativePath LIKE '%.JPG' OR
                          relativePath LIKE '%.JPEG' OR
                          relativePath LIKE '%.PNG' OR
                          relativePath LIKE '%.MOV' OR
                          relativePath LIKE '%.MP4' OR
                          relativePath LIKE '%.M4V'
                      )
                  )
                  OR lower(relativePath) LIKE '%.dng'
              )
            ORDER BY relativePath
        """)

        # Derivative file patterns to filter out (same as in _build_file_existence_cache)
        derivative_patterns = [
            'FullSizeRender.',
            'Adjusted.',
            'proxy.heic',
            'portrait-layer_background.',
        ]

        items = []
        for row in cur.fetchall():
            file_id = row['fileID']
            rel_path = row['relativePath']

            filename = os.path.basename(rel_path)

            # Check if this is a derivative file in Adjustments/Mutations folder
            is_adjustments_file = '/Adjustments/' in rel_path and 'Mutations/' in rel_path
            is_derivative = any(pattern in filename for pattern in derivative_patterns)

            # Skip derivative files UNLESS they're in Adjustments (those we want to link to originals)
            if is_derivative and not is_adjustments_file:
                continue

            # Extract directory - preserve structure relative to Media/
            # Examples:
            #   Media/DCIM/100APPLE/IMG_0001.JPG -> DCIM/100APPLE
            #   Media/PhotoData/Mutations/DCIM/104APPLE/IMG_4195/Adjustments/FullSizeRender.jpg -> PhotoData/Mutations/DCIM/104APPLE/IMG_4195/Adjustments
            if rel_path.startswith('Media/'):
                directory_path = os.path.dirname(rel_path[6:])  # Remove 'Media/' prefix
            else:
                directory_path = os.path.dirname(rel_path)

            # Determine media kind from extension
            ext = os.path.splitext(filename)[1].lower()
            is_video = ext in ['.mov', '.mp4', '.m4v']

            # Initialize item with default (no metadata)
            item = {
                'z_pk': None,  # No database PK for manifest items
                'uuid': file_id,  # Use file_id as uuid
                'filename': filename,
                'date_created': None,  # No metadata available from Manifest
                'width': 0,
                'height': 0,
                'kind': 1 if is_video else 0,  # 0=photo, 1=video
                'duration': 0,
                'directory': directory_path,
                'source': 'manifest',  # Flag to indicate this came from Manifest
                'manifest_path': rel_path  # Store full path for extraction
            }

            # Try to link Adjustments files to their original photo metadata
            if is_adjustments_file:
                # Path format: Media/PhotoData/Mutations/{original_dir}/{base_filename}/Adjustments/{edited_file}
                # Example: Media/PhotoData/Mutations/DCIM/110APPLE/IMG_0115/Adjustments/FullSizeRender.jpg
                #   original_dir = "DCIM/110APPLE"
                #   base_filename = "IMG_0115"

                # Split path to extract original directory and base filename
                path_parts = rel_path.split('/')
                if 'Adjustments' in path_parts:
                    adj_index = path_parts.index('Adjustments')
                    # Base filename is the folder before /Adjustments/
                    base_filename = path_parts[adj_index - 1] if adj_index > 0 else None

                    # Original directory is everything between Mutations/ and /{base_filename}/
                    if 'Mutations' in path_parts:
                        mut_index = path_parts.index('Mutations')
                        # Original dir parts are between Mutations and base_filename folder
                        original_dir_parts = path_parts[mut_index + 1:adj_index - 1]
                        original_directory = '/'.join(original_dir_parts)

                        if base_filename and original_directory:
                            # Look up metadata using (directory, base_filename)
                            lookup_key = (original_directory, base_filename)
                            metadata = self._metadata_lookup_index.get(lookup_key)

                            if metadata:
                                # Merge metadata into item (inherit from original)
                                item['date_created'] = metadata.get('date_created')
                                item['width'] = metadata.get('width', 0)
                                item['height'] = metadata.get('height', 0)
                                item['kind'] = metadata.get('kind', item['kind'])
                                item['duration'] = metadata.get('duration', 0)
                                # Keep z_pk as None to avoid confusion (this is still a manifest item)
                                # Add flag to indicate metadata was inherited
                                item['metadata_source'] = 'linked_from_original'

            items.append(item)

        conn.close()
        return items

    def _get_manifest_camroll_paths(self) -> Optional[set]:
        """
        Load set of relative paths for CameraRollDomain media (excluding thumbnails).
        Used to pre-filter assets to those actually present in the backup.
        """
        if not os.path.exists(self.manifest_db_path):
            print("[WARNING] Manifest.db not found - manifest path filter disabled")
            return None
        conn = sqlite3.connect(self.manifest_db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        try:
            cur.execute("""
                SELECT relativePath
                FROM Files
                WHERE domain = 'CameraRollDomain'
                  AND relativePath NOT LIKE '%/Thumbnails/%'
                  AND (
                      relativePath LIKE '%.heic' OR
                      relativePath LIKE '%.heif' OR
                      relativePath LIKE '%.jpg' OR
                      relativePath LIKE '%.jpeg' OR
                      relativePath LIKE '%.png' OR
                      relativePath LIKE '%.mov' OR
                      relativePath LIKE '%.mp4' OR
                      relativePath LIKE '%.m4v' OR
                      relativePath LIKE '%.HEIC' OR
                      relativePath LIKE '%.HEIF' OR
                      relativePath LIKE '%.JPG' OR
                      relativePath LIKE '%.JPEG' OR
                      relativePath LIKE '%.PNG' OR
                      relativePath LIKE '%.MOV' OR
                      relativePath LIKE '%.MP4' OR
                      relativePath LIKE '%.M4V'
                  )
            """)
            return {row['relativePath'] for row in cur.fetchall()}
        except Exception as e:
            print(f"[WARNING] Failed to load manifest paths: {e}")
            return None
        finally:
            conn.close()

    def get_items_hybrid(self, limit: Optional[int] = None, offset: int = 0,
                         search: Optional[str] = None, album_id: Optional[int] = None,
                         sort_by: str = 'date-desc', filter_by_existence: bool = True,
                         date_from: Optional[float] = None, date_to: Optional[float] = None) -> List[Dict[str, Any]]:
        """
        Get photos/videos from both Photos.sqlite and CameraRollDomain (hybrid extraction).

        This matches Reincubate's behavior by:
        1. Getting all items from Photos.sqlite (with full metadata)
        2. Getting additional items from CameraRollDomain not in Photos.sqlite
        3. Merging them together

        Args:
            limit: Optional limit on number of items
            offset: Offset for pagination
            search: Optional search filter (applied to Photos.sqlite only)
            album_id: Optional album filter (applied to Photos.sqlite only)
            sort_by: Sort order
            filter_by_existence: If True, filter to only items whose files exist.
                                If False, include all items (extraction mode).
            date_from: Optional start date filter (Apple epoch timestamp)
            date_to: Optional end date filter (Apple epoch timestamp)

        Returns:
            Combined list of items from both sources
        """
        # Check if we can use cached results (cache is invalidated by search/album_id/sort_by/filter/date changes)
        cache_key = (search, album_id, sort_by, filter_by_existence, date_from, date_to)
        if self._hybrid_items_cache is not None and self._hybrid_cache_params == cache_key:
            # Use cached results - just apply pagination
            all_items = self._hybrid_items_cache
            if limit:
                return all_items[offset:offset+limit]
            return all_items[offset:]

        # Cache miss - need to rebuild
        # Get items from Photos.sqlite - temporarily disable hybrid to avoid recursion
        # Pass filter_by_existence=False to get ALL Photos.sqlite items (no filtering at this stage)
        saved_hybrid_setting = self.use_hybrid_extraction
        self.use_hybrid_extraction = False
        photos_db_items_raw = self.get_items(limit=None, offset=0, search=search, album_id=album_id,
                                              filter_by_existence=False, date_from=date_from, date_to=date_to)
        self.use_hybrid_extraction = saved_hybrid_setting

        # Get items from Manifest.db to build filename-to-path mapping
        manifest_items = self._get_manifest_items()

        # Build filename-to-manifest-path mapping for fast lookup
        filename_to_manifest_path = {}
        for manifest_item in manifest_items:
            fn = manifest_item.get('filename')
            path = manifest_item.get('manifest_path')
            if fn and path:
                # Use filename as key; if duplicate, keep first occurrence
                if fn not in filename_to_manifest_path:
                    filename_to_manifest_path[fn] = path

        # Filter Photos.sqlite items based on filter_by_existence parameter
        # If filter_by_existence=True (preview mode): Only keep items whose files exist
        # If filter_by_existence=False (extraction mode): Keep all items, some may fail during extraction
        # In both cases, add manifest_path to items for find_image_file()
        # Also deduplicate by filename (keep first occurrence) to handle shared album duplicates
        photos_db_items = []
        seen_filenames = set()
        for item in photos_db_items_raw:
            filename = item.get('filename')
            directory = item.get('directory')

            # Skip duplicates (same filename already seen) when no album filter
            # This handles photos appearing in multiple shared albums
            if album_id is None and filename and filename in seen_filenames:
                continue

            if filter_by_existence:
                # Preview mode: Only include items whose files exist
                if filename and self._photo_file_exists(filename=filename, directory=directory):
                    # Add manifest_path to item for find_image_file()
                    if filename in filename_to_manifest_path:
                        item['manifest_path'] = filename_to_manifest_path[filename]
                    photos_db_items.append(item)
                    if filename:
                        seen_filenames.add(filename)
            else:
                # Extraction mode: Include ALL items (better coverage, some may fail)
                # Add manifest_path if available for successful file finding
                if filename and filename in filename_to_manifest_path:
                    item['manifest_path'] = filename_to_manifest_path[filename]
                # Always append item in extraction mode (don't filter)
                photos_db_items.append(item)
                if filename:
                    seen_filenames.add(filename)

        # Build set of filenames from Photos.sqlite (after filtering and deduplication)
        photos_db_filenames = {item['filename'] for item in photos_db_items if item.get('filename')}

        # Filter manifest items - only keep those NOT in Photos.sqlite and that exist in manifest
        # IMPORTANT: When date filtering is active, skip manifest-only items entirely since they
        # don't have date metadata and can't be filtered by date
        additional_items = []
        if date_from is None and date_to is None:
            # No date filter - include manifest-only items
            manifest_paths = self._manifest_camroll_paths if self._manifest_camroll_paths is not None else self._get_manifest_camroll_paths()
            for item in manifest_items:
                rel_path = item.get('manifest_path') or item.get('path')
                if not rel_path:
                    continue
                if item['filename'] in photos_db_filenames:
                    continue
                if manifest_paths is not None and rel_path not in manifest_paths:
                    continue
                additional_items.append(item)
        # else: Date filter active - skip manifest-only items (they have no date_created field)

        pass  # Hybrid extraction complete

        # Merge (Photos.sqlite first for better metadata)
        all_items = photos_db_items + additional_items

        # Apply sorting
        if sort_by == 'date-asc':
            # Oldest first: items without dates (0) sort to beginning
            all_items.sort(key=lambda x: x.get('date_created') or 0)
        elif sort_by == 'name-asc':
            all_items.sort(key=lambda x: (x.get('filename') or '').lower())
        elif sort_by == 'name-desc':
            all_items.sort(key=lambda x: (x.get('filename') or '').lower(), reverse=True)
        else:
            # Newest first (default): items without dates (0) sort to bottom
            all_items.sort(key=lambda x: x.get('date_created') or 0, reverse=True)

        # Cache the results for future calls with same parameters
        self._hybrid_items_cache = all_items
        self._hybrid_cache_params = cache_key

        # Apply pagination if requested
        if limit:
            return all_items[offset:offset+limit]
        return all_items[offset:]

    def get_item_summary(self, item: Dict[str, Any]) -> str:
        """Get summary string for photo (used in fallback views)."""
        filename = item['filename']
        date_str = self._format_timestamp(item['date_created'])
        dimensions = f"{item['width']}x{item['height']}" if item['width'] and item['height'] else "?"
        media_type = "📹 Video" if item['kind'] == 1 else "📷 Photo"
        return f"{media_type} {filename} - {date_str} ({dimensions})"

    def find_image_file(self, item: Dict[str, Any]) -> Optional[str]:
        """
        Find the actual image/video file in the backup for a photo item.

        Handles both Photos.sqlite items and Manifest.db items.
        Falls back to thumbnails for iCloud-optimized photos.

        Args:
            item: Photo item dictionary from get_items()

        Returns:
            Physical path to image file (full-res or thumbnail), or None if not found
        """
        # Strategy 1: Use manifest_path if available (most reliable)
        if item.get('manifest_path'):
            file_path = self.find_db_file("CameraRollDomain", item['manifest_path'])
            if file_path:
                return file_path
            # If manifest_path points to a thumbnail location, still return it as a fallback
            manifest_rel = item['manifest_path']
            if 'Thumbnails' in manifest_rel:
                file_path = self.find_db_file("CameraRollDomain", manifest_rel)
                if file_path:
                    return file_path

        # Strategy 2: Try constructed path from directory/filename
        directory = item.get('directory')
        filename = item.get('filename')

        if directory and directory != '' and filename and filename != '' and filename != 'Unknown':
            # Build relative path: Media/{directory}/{filename}
            # Example: Media/DCIM/100APPLE/IMG_0001.JPG
            relative_path = f"Media/{directory}/{filename}"
            file_path = self.find_db_file("CameraRollDomain", relative_path)
            if file_path:
                return file_path

        # Strategy 3: Fallback to thumbnail search (for iCloud-optimized photos)
        # Search Manifest.db for thumbnail version of this filename
        if filename and filename != 'Unknown':
            return self._find_thumbnail_file(filename)

        return None

    def _find_thumbnail_file(self, filename: str) -> Optional[str]:
        """
        Search for thumbnail version of a file in Manifest.db.

        Used as fallback for iCloud-optimized photos that only have thumbnails.

        Args:
            filename: Photo filename to search for

        Returns:
            Physical path to thumbnail file, or None if not found
        """
        if not os.path.exists(self.manifest_db_path):
            return None

        try:
            conn = sqlite3.connect(f"file:{self.manifest_db_path}?mode=ro", uri=True)
            cur = conn.cursor()

            # Search for V2 thumbnails (high-quality) with this filename
            # Prioritize PhotoData/Thumbnails over V2 (usually better quality)
            cur.execute("""
                SELECT fileID, relativePath
                FROM Files
                WHERE domain = 'CameraRollDomain'
                  AND (relativePath LIKE ? OR relativePath LIKE ?)
                  AND (relativePath LIKE '%PhotoData/Thumbnails%' OR relativePath LIKE '%Thumbnails/V2/%')
                ORDER BY
                    CASE
                        WHEN relativePath LIKE '%PhotoData/Thumbnails%' THEN 1
                        WHEN relativePath LIKE '%Thumbnails/V2/%' THEN 2
                        ELSE 3
                    END
                LIMIT 1
            """, (f'%/{filename}', f'%{filename}'))

            result = cur.fetchone()
            conn.close()

            if result:
                file_id, rel_path = result
                # Build physical path: {backup_path}/{first_2_chars_of_fileID}/{fileID}
                physical_path = os.path.join(self.backup_path, file_id[:2], file_id)
                if os.path.exists(physical_path):
                    return physical_path

        except Exception as e:
            pass  # Silently fail, return None

        return None

    def get_image_data(self, item: Dict[str, Any]) -> Optional[bytes]:
        """
        Get raw image/video data from backup.

        Args:
            item: Photo item dictionary from get_items()

        Returns:
            Raw file bytes, or None if not found
        """
        file_path = self.find_image_file(item)
        if not file_path or not os.path.exists(file_path):
            return None

        try:
            with open(file_path, 'rb') as f:
                return f.read()
        except Exception as e:
            print(f"[WARNING] Could not read image file {file_path}: {e}")
            return None

    def get_thumbnail(self, item: Dict[str, Any], size: Tuple[int, int] = (150, 150)) -> Optional['Image.Image']:
        """
        Generate thumbnail for photo/video.

        Args:
            item: Photo item dictionary from get_items()
            size: Thumbnail size (width, height)

        Returns:
            PIL Image object, or None if generation failed
        """
        if not PIL_AVAILABLE:
            return None

        # Check cache first
        cache_key = f"{item['z_pk']}_{size[0]}x{size[1]}"
        if cache_key in self.thumbnail_cache:
            return self.thumbnail_cache[cache_key]

        # Get image data
        image_data = self.get_image_data(item)
        if not image_data:
            return None

        try:
            # For videos, PIL can't process them - return placeholder
            if item['kind'] == 1:
                # Create a simple gray placeholder for videos
                thumbnail = Image.new('RGB', size, color=(100, 100, 100))
                self.thumbnail_cache[cache_key] = thumbnail
                return thumbnail

            # Load and resize image
            image = Image.open(BytesIO(image_data))

            # Convert to RGB if needed (handles RGBA, P, etc.)
            if image.mode not in ('RGB', 'L'):
                image = image.convert('RGB')

            # Generate thumbnail (maintains aspect ratio)
            # Use NEAREST for fastest generation (5-10x faster than LANCZOS)
            # At 100x100 the quality difference is minimal
            image.thumbnail(size, Image.Resampling.NEAREST)

            # Cache and return
            self.thumbnail_cache[cache_key] = image
            return image

        except Exception as e:
            print(f"[WARNING] Could not generate thumbnail for {item['filename']}: {e}")
            return None

    def get_available_count(self, album_id: Optional[int] = None,
                            date_from: Optional[float] = None, date_to: Optional[float] = None) -> int:
        """
        Count items whose files are present in the backup (manifest-filtered).

        Args:
            album_id: Optional album Z_PK to filter by
            date_from: Optional start date filter (Apple epoch timestamp)
            date_to: Optional end date filter (Apple epoch timestamp)

        Returns:
            Count of available photos/videos
        """
        items = self.get_items(limit=None, offset=0, album_id=album_id,
                              date_from=date_from, date_to=date_to)
        return len(items)

    def _is_heic_file(self, filename: str) -> bool:
        """Check if filename is a HEIC/HEIF image."""
        if not filename:
            return False
        ext = os.path.splitext(filename)[1].lower()
        return ext in ['.heic', '.heif']

    def _convert_heic_to_jpeg(self, heic_path: str, jpeg_path: str) -> bool:
        """
        Convert HEIC image to JPEG using pillow-heif.

        Args:
            heic_path: Path to source HEIC file
            jpeg_path: Path to output JPEG file

        Returns:
            True if conversion succeeded, False otherwise
        """
        if not HEIC_CONVERSION_AVAILABLE or not PIL_AVAILABLE:
            return False

        try:
            # Open HEIC file using PIL (pillow-heif registers the opener)
            image = Image.open(heic_path)

            # Extract EXIF metadata before any conversion to preserve it
            exif_data = image.getexif()

            # Convert to RGB if needed (HEIC can be RGBA)
            if image.mode in ('RGBA', 'LA', 'P'):
                # Create white background for transparent images
                background = Image.new('RGB', image.size, (255, 255, 255))
                if image.mode == 'P':
                    image = image.convert('RGBA')
                background.paste(image, mask=image.split()[-1] if image.mode == 'RGBA' else None)
                image = background
            elif image.mode != 'RGB':
                image = image.convert('RGB')

            # Save as JPEG with high quality (95%), preserving EXIF metadata
            if exif_data:
                image.save(jpeg_path, 'JPEG', quality=95, optimize=True, exif=exif_data)
            else:
                # No EXIF data to preserve, save normally
                image.save(jpeg_path, 'JPEG', quality=95, optimize=True)

            return True
        except Exception as e:
            pass  # HEIC conversion failed silently
            return False

    def _create_photo_thumbnail(self, source_path: str, thumb_path: str) -> bool:
        """
        Create photo thumbnail (300x300, quality 80).

        Args:
            source_path: Path to source photo
            thumb_path: Path to output thumbnail

        Returns:
            True if successful, False otherwise
        """
        if not PIL_AVAILABLE:
            return False

        try:
            from PIL import Image, ImageOps

            # Open image
            img = Image.open(source_path)

            # Preserve orientation from EXIF (auto-rotate if needed)
            try:
                img = ImageOps.exif_transpose(img)
            except Exception:
                pass  # No EXIF or orientation issue

            # Create thumbnail (maintains aspect ratio, fits within 300x300)
            img.thumbnail((300, 300), Image.LANCZOS)

            # Convert to RGB if needed (for JPEG compatibility)
            if img.mode in ('RGBA', 'LA', 'P'):
                # Create white background for transparent images
                background = Image.new('RGB', img.size, (255, 255, 255))
                if img.mode == 'P':
                    img = img.convert('RGBA')
                if img.mode == 'RGBA':
                    background.paste(img, mask=img.split()[-1])
                else:
                    background.paste(img)
                img = background
            elif img.mode != 'RGB':
                img = img.convert('RGB')

            # Save as JPEG
            img.save(thumb_path, 'JPEG', quality=80, optimize=True)

            return True

        except Exception as e:
            # Thumbnail generation failed
            return False

    def _create_video_thumbnail(self, source_path: str, thumb_path: str) -> bool:
        """
        Create video thumbnail from first frame using ffmpeg directly.

        This uses ffmpeg subprocess with explicit timeout to avoid hanging issues
        that can occur with imageio wrapper. Tested to be reliable and fast
        (~0.2s per video, no timeouts on 20 test videos).

        Args:
            source_path: Path to source video
            thumb_path: Path to output thumbnail

        Returns:
            True if successful, False otherwise
        """
        try:
            import subprocess
            import imageio_ffmpeg

            # Get ffmpeg executable from imageio-ffmpeg
            ffmpeg_exe = imageio_ffmpeg.get_ffmpeg_exe()

            # Use ffmpeg directly with timeout protection
            # This approach is much more reliable than imageio's wrapper
            cmd = [
                ffmpeg_exe,
                '-i', source_path,
                '-vf', 'scale=300:300:force_original_aspect_ratio=decrease',
                '-frames:v', '1',
                '-q:v', '5',  # Quality (1-31, lower is better)
                '-y',  # Overwrite output file
                thumb_path
            ]

            # Run with 5 second timeout
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=5
            )

            # Check if successful
            if result.returncode == 0 and os.path.exists(thumb_path):
                return True
            else:
                # Failed - create placeholder
                return self._create_placeholder_thumbnail(thumb_path, "VIDEO")

        except subprocess.TimeoutExpired:
            # Video took too long to process - create placeholder
            return self._create_placeholder_thumbnail(thumb_path, "VIDEO")

        except Exception as e:
            # Any other error - create placeholder
            return self._create_placeholder_thumbnail(thumb_path, "VIDEO")

    def _create_placeholder_thumbnail(self, thumb_path: str, label: str = "ERROR") -> bool:
        """
        Create placeholder thumbnail when source file can't be processed.

        Args:
            thumb_path: Path to output thumbnail
            label: Text to display on placeholder

        Returns:
            True if successful, False otherwise
        """
        if not PIL_AVAILABLE:
            return False

        try:
            from PIL import Image, ImageDraw, ImageFont

            # Create 300x300 gray placeholder
            img = Image.new('RGB', (300, 300), color=(240, 240, 240))
            draw = ImageDraw.Draw(img)

            # Draw border
            draw.rectangle([10, 10, 289, 289], outline=(200, 200, 200), width=2)

            # Draw text (simple, no custom font needed)
            text_bbox = draw.textbbox((150, 150), label, anchor="mm")
            draw.text((150, 150), label, fill=(150, 150, 150), anchor="mm")

            # Save
            img.save(thumb_path, 'JPEG', quality=80, optimize=True)

            return True

        except Exception:
            return False

    def _generate_thumbnails(self, exported_items: List[Dict[str, Any]],
                            output_path: str, progress_callback=None) -> int:
        """
        Generate thumbnails for all exported photos/videos.

        Args:
            exported_items: List of successfully exported items with paths
            output_path: Base output directory (thumbnails/ will be created inside)
            progress_callback: Optional callback(current, total, item_name, cancelled_check)

        Returns:
            Number of thumbnails successfully generated
        """
        # Create thumbnails directory
        thumb_dir = os.path.join(output_path, 'thumbnails')
        os.makedirs(thumb_dir, exist_ok=True)

        generated_count = 0
        total = len(exported_items)
        thumb_name_counter = {}  # Track duplicate filenames

        for idx, item in enumerate(exported_items):
            # Check for cancellation
            if progress_callback:
                should_continue = progress_callback(
                    current=idx + 1,
                    total=total,
                    item_name=f"Generating thumbnail {idx + 1}/{total}"
                )
                if not should_continue:
                    break  # Cancelled

            # Get source file path
            source_path = item.get('exported_path')
            if not source_path or not os.path.exists(source_path):
                continue

            # Determine thumbnail filename with unique suffix for duplicates
            filename = item.get('filename', os.path.basename(source_path))
            base_name = os.path.splitext(filename)[0]

            # Add counter suffix if this filename has been seen before
            if base_name in thumb_name_counter:
                thumb_name_counter[base_name] += 1
                thumb_name = f"{base_name}_{thumb_name_counter[base_name]}.jpg"
            else:
                thumb_name_counter[base_name] = 1
                thumb_name = f"{base_name}.jpg"

            thumb_path = os.path.join(thumb_dir, thumb_name)
            thumb_rel = f"thumbnails/{thumb_name}"

            # Skip if thumbnail already exists (shouldn't happen with unique names, but safety check)
            if os.path.exists(thumb_path):
                generated_count += 1
                item['thumbnail_path'] = thumb_path
                item['thumbnail'] = thumb_rel
                continue

            # Generate thumbnail based on type
            item_type = item.get('type', 'photo')
            success = False

            if item_type == 'video':
                success = self._create_video_thumbnail(source_path, thumb_path)
            else:  # photo
                # For RAW/DNG we may not be able to decode; fall back to placeholder if needed
                ext = os.path.splitext(filename)[1].lower()
                if ext == '.dng':
                    success = self._create_photo_thumbnail(source_path, thumb_path)
                    if not success:
                        success = self._create_placeholder_thumbnail(thumb_path, "DNG")
                else:
                    success = self._create_photo_thumbnail(source_path, thumb_path)

            if success:
                generated_count += 1
                item['thumbnail_path'] = thumb_path  # Add thumbnail path to item metadata
                item['thumbnail'] = thumb_rel
            else:
                # Try creating placeholder as last resort
                if self._create_placeholder_thumbnail(thumb_path, "ERROR"):
                    generated_count += 1
                    item['thumbnail_path'] = thumb_path
                    item['thumbnail'] = thumb_rel

        return generated_count

    def _parse_gps(self, gps_info) -> Optional[Dict[str, float]]:
        """
        Parse GPS coordinates from EXIF data.

        Args:
            gps_info: GPS IFD from EXIF

        Returns:
            Dict with 'lat' and 'lon' keys, or None if parsing fails
        """
        try:
            def convert_to_degrees(value):
                """Convert GPS coordinate from degrees/minutes/seconds to decimal."""
                d, m, s = value
                return float(d) + (float(m) / 60.0) + (float(s) / 3600.0)

            lat = gps_info.get(2)  # GPSLatitude
            lat_ref = gps_info.get(1)  # GPSLatitudeRef (N or S)
            lon = gps_info.get(4)  # GPSLongitude
            lon_ref = gps_info.get(3)  # GPSLongitudeRef (E or W)

            if lat and lon:
                latitude = convert_to_degrees(lat)
                if lat_ref == 'S':
                    latitude = -latitude

                longitude = convert_to_degrees(lon)
                if lon_ref == 'W':
                    longitude = -longitude

                return {
                    'lat': round(latitude, 6),
                    'lon': round(longitude, 6)
                }
        except Exception:
            pass

        return None

    def _extract_photo_metadata(self, file_path: str, relative_path: str,
                                converted_from_heic: bool = False, original_filename: str = None) -> Dict[str, Any]:
        """
        Extract comprehensive metadata from photo file.

        Args:
            file_path: Full path to photo file
            relative_path: Path relative to output directory
            converted_from_heic: Whether this was converted from HEIC
            original_filename: Original filename (before export/conversion)

        Returns:
            Metadata dict with file info, EXIF data, GPS, camera settings, etc.
        """
        # Use original filename for thumbnail path (matches thumbnail generation naming)
        if original_filename:
            thumb_base = os.path.splitext(original_filename)[0]
        else:
            thumb_base = os.path.splitext(os.path.basename(file_path))[0]

        ext = os.path.splitext(file_path)[1].lower()
        media_type = 'dng' if ext == '.dng' else 'photo'

        metadata = {
            'filename': os.path.basename(file_path),
            'path': relative_path.replace('\\', '/'),  # Web-friendly paths
            'thumbnail': f"thumbnails/{thumb_base}.jpg",
            'type': media_type,
            'converted_from_heic': converted_from_heic
        }

        try:
            # File size
            metadata['size'] = os.path.getsize(file_path)

            # Try to extract EXIF data
            if not PIL_AVAILABLE:
                return metadata

            from PIL import Image

            img = Image.open(file_path)
            metadata['width'] = img.width
            metadata['height'] = img.height

            # Get EXIF data
            exif_data = img.getexif()
            if exif_data:
                # Date taken (tag 306 = DateTime, or 36867 = DateTimeOriginal)
                date_taken = exif_data.get(36867) or exif_data.get(306)  # DateTimeOriginal or DateTime
                if date_taken:
                    try:
                        from datetime import datetime
                        # Format: "2024:12:10 14:23:45"
                        dt = datetime.strptime(date_taken, '%Y:%m:%d %H:%M:%S')
                        metadata['date_taken'] = dt.isoformat()
                    except Exception:
                        pass

                # GPS data
                gps_ifd = exif_data.get_ifd(0x8825)  # GPS IFD tag
                if gps_ifd:
                    gps = self._parse_gps(gps_ifd)
                    if gps:
                        metadata['gps'] = gps

                # Camera info
                camera = {}
                make = exif_data.get(271)  # Make
                model = exif_data.get(272)  # Model
                if make:
                    camera['make'] = str(make).strip()
                if model:
                    camera['model'] = str(model).strip()

                # Camera settings
                iso = exif_data.get(34855)  # ISOSpeedRatings
                aperture = exif_data.get(33437)  # FNumber
                shutter = exif_data.get(33434)  # ExposureTime

                if iso:
                    camera['iso'] = int(iso)
                if aperture:
                    # Aperture is a rational number
                    try:
                        camera['aperture'] = float(aperture)
                    except Exception:
                        pass
                if shutter:
                    # Shutter speed - convert to readable format
                    try:
                        shutter_float = float(shutter)
                        if shutter_float < 1:
                            camera['shutter_speed'] = f"1/{int(1/shutter_float)}"
                        else:
                            camera['shutter_speed'] = f"{shutter_float}s"
                    except Exception:
                        pass

                if camera:
                    metadata['camera'] = camera

        except Exception as e:
            # If metadata extraction fails, return basic metadata
            pass

        return metadata

    def _extract_video_metadata(self, file_path: str, relative_path: str, original_filename: str = None) -> Dict[str, Any]:
        """
        Extract metadata from video file.

        Args:
            file_path: Full path to video file
            relative_path: Path relative to output directory
            original_filename: Original filename (before export)

        Returns:
            Metadata dict with file info
        """
        # Use original filename for thumbnail path (matches thumbnail generation naming)
        if original_filename:
            thumb_base = os.path.splitext(original_filename)[0]
        else:
            thumb_base = os.path.splitext(os.path.basename(file_path))[0]

        metadata = {
            'filename': os.path.basename(file_path),
            'path': relative_path.replace('\\', '/'),
            'thumbnail': f"thumbnails/{thumb_base}.jpg",
            'type': 'video',
            'size': os.path.getsize(file_path) if os.path.exists(file_path) else 0
        }

        try:
            # Try to get video properties using imageio
            import imageio.v3 as iio

            props = iio.improps(file_path)

            # Get resolution
            if hasattr(props, 'shape') and len(props.shape) >= 2:
                metadata['height'] = props.shape[0]
                metadata['width'] = props.shape[1]

            # Get duration
            if hasattr(props, 'duration'):
                metadata['duration'] = props.duration

            # Get frame count and calculate duration if not available
            if 'duration' not in metadata and hasattr(props, 'n_images'):
                fps = getattr(props, 'fps', 30)  # Default to 30 fps
                if fps > 0:
                    metadata['duration'] = props.n_images / fps

        except Exception:
            # If video metadata extraction fails, return basic metadata
            pass

        return metadata

    def _build_metadata_index(self, exported_items: List[Dict[str, Any]],
                              organize_by_date: bool) -> Dict[str, Any]:
        """
        Build comprehensive metadata index for all exported items.

        Args:
            exported_items: List of successfully exported items with paths
            organize_by_date: Whether files are organized by date

        Returns:
            Dict with complete metadata structure for photos_data.json
        """
        from datetime import datetime

        metadata_items = []
        total_photos = 0
        total_videos = 0

        for item in exported_items:
            item_type = item.get('type')
            exported_path = item.get('exported_path')
            relative_path = item.get('relative_path')
            original_filename = item.get('filename')  # Original filename (before export/conversion)
            original_item = item.get('item_data', {})
            asset_id = original_item.get('Z_PK') or original_item.get('z_pk')

            # Extract metadata based on type
            if item_type == 'video':
                # Seed duration from DB value before extraction
                base_dur_num = None
                try:
                    base_dur = original_item.get('duration')
                    if base_dur is not None:
                        val = float(base_dur)
                        if val > 0:
                            base_dur_num = val
                except Exception:
                    pass

                metadata = self._extract_video_metadata(exported_path, relative_path, original_filename)

                # If extraction failed to provide duration, use DB value
                if base_dur_num is not None:
                    try:
                        dur_val = metadata.get('duration')
                        if dur_val is None or not isinstance(dur_val, (int, float)) or not math.isfinite(dur_val) or dur_val <= 0:
                            metadata['duration'] = base_dur_num
                    except Exception:
                        metadata['duration'] = base_dur_num
                total_videos += 1
            else:  # photo
                # Check if this was converted from HEIC
                converted_from_heic = item.get('converted_from_heic', False)
                metadata = self._extract_photo_metadata(exported_path, relative_path, converted_from_heic, original_filename)
                total_photos += 1

            # Ensure duration for videos (prefer extracted, otherwise DB value)
            if item_type == 'video':
                orig_dur = original_item.get('duration')
                try:
                    if orig_dur is not None:
                        orig_dur_num = float(orig_dur)
                        if orig_dur_num > 0:
                            metadata['duration'] = metadata.get('duration') or orig_dur_num
                except Exception:
                    pass

            # Fallback date from original item if EXIF missing
            if 'date_taken' not in metadata and original_item.get('date_created') is not None:
                try:
                    apple_epoch = datetime(2001, 1, 1, tzinfo=timezone.utc).timestamp()
                    unix_ts = apple_epoch + original_item.get('date_created')
                    metadata['date_taken'] = datetime.fromtimestamp(unix_ts).isoformat()
                except Exception:
                    pass

            # Attach album names if present on original item (populated in _generate_html_report)
            if item.get('albums'):
                metadata['albums'] = item.get('albums')

            # Preserve minimal item_data so album mapping in _generate_html_report can work
            if asset_id is not None:
                metadata['item_data'] = {'Z_PK': asset_id}

            metadata_items.append(metadata)

        # Build complete structure
        index = {
            'export_date': datetime.now().isoformat(),
            'total_photos': total_photos,
            'total_videos': total_videos,
            'organized_by_date': organize_by_date,
            'items': metadata_items
        }

        return index

    def _write_metadata_json(self, metadata_index: Dict[str, Any], output_path: str) -> bool:
        """
        Write metadata index to photos_data.json.

        Args:
            metadata_index: Complete metadata structure
            output_path: Output directory path

        Returns:
            True if successful, False otherwise
        """
        import json

        json_path = os.path.join(output_path, 'photos_data.json')

        try:
            with open(json_path, 'w', encoding='utf-8') as f:
                json.dump(metadata_index, f, indent=2, ensure_ascii=False)

            print(f"[INFO] Metadata index saved: {json_path}")
            return True

        except Exception as e:
            print(f"[WARNING] Failed to write metadata JSON: {e}")
            return False

    def export(self, items: List[Dict[str, Any]], output_path: str,
               format: str = 'files', progress_callback=None, convert_heic: bool = False,
               organize_by_date: bool = False, generate_html_report: bool = False) -> tuple:
        """
        Export photos/videos to directory with original filenames.

        Args:
            items: List of photos to export
            output_path: Output directory path
            format: 'files' (copy image files) or 'csv'/'json' (metadata only)
            progress_callback: Optional callback function(current, total, item_name, cancelled_check)
                              Returns True if operation should continue, False to cancel
            convert_heic: If True, convert HEIC to JPEG and replace HEIC files (default: False)
            organize_by_date: If True, organize into Year/Month folders (default: False)
            generate_html_report: If True, generate thumbnails and HTML report (default: False)

        Returns:
            Tuple of (success_count, failed_count)
        """
        try:
            if format == 'files':
                return self._export_files(items, output_path, progress_callback, convert_heic,
                                         organize_by_date, generate_html_report)
            elif format == 'csv':
                result = self._export_csv(items, output_path)
                return (len(items), 0) if result else (0, len(items))
            elif format == 'json':
                result = self._export_json(items, output_path)
                return (len(items), 0) if result else (0, len(items))
            else:
                raise ValueError(f"Unsupported export format: {format}")
        except Exception as e:
            print(f"Error exporting photos: {e}")
            import traceback
            traceback.print_exc()
            return (0, len(items))

    def _export_files(self, items: List[Dict[str, Any]], output_dir: str,
                      progress_callback=None, convert_heic: bool = False,
                      organize_by_date: bool = False, generate_html_report: bool = False) -> tuple:
        """
        Export actual image/video files to directory.

        Creates directory structure preserving albums/folders or organizing by date.
        Optionally converts HEIC files to JPEG for Windows compatibility.

        Args:
            items: List of items to export
            output_dir: Output directory
            progress_callback: Optional callback(current, total, item_name, cancelled_check)
            convert_heic: If True, convert HEIC to JPEG and replace HEIC files (default: False)
            organize_by_date: If True, organize into Year/Month folders (default: False)
            generate_html_report: If True, generate thumbnails after export (default: False)

        Returns:
            Tuple of (exported_count, failed_count)
        """
        # Create output directory if needed
        os.makedirs(output_dir, exist_ok=True)

        # Track exported items for thumbnail generation (only if needed)
        exported_items = [] if generate_html_report else None

        # Check if HEIC conversion is available and requested
        if convert_heic:
            if HEIC_CONVERSION_AVAILABLE:
                pass  # HEIC conversion enabled
            else:
                print("[WARNING] HEIC conversion requested but not available")
                print("[WARNING] Install required package: pip install pillow-heif")
                print("[INFO] HEIC files will be exported as-is")
        else:
            pass  # HEIC conversion disabled

        exported_count = 0
        failed_count = 0
        missing_metadata = 0
        file_not_found = 0
        copy_errors = 0
        heic_converted = 0
        total = len(items)

        # Combined progress planning: copy stage + thumbnail stage (approx 2x items)
        combined_total_pre = total * 2  # optimistic upper bound for combined progress

        def copy_progress_wrapper(current, item_name):
            if progress_callback:
                return progress_callback(current=current, total=combined_total_pre, item_name=item_name)
            return True

        # TODO: PERFORMANCE - Implement Parallel File Copying (40-70% speedup)
        # Current: Files copied sequentially in a loop
        # Proposed: Use ThreadPoolExecutor with 4-8 worker threads
        # Implementation approach:
        #   1. Create ThreadPoolExecutor(max_workers=4)
        #   2. Create a _copy_single_file() helper method
        #   3. Submit all copy tasks: futures = [executor.submit(_copy_single_file, item) for item in items]
        #   4. Use as_completed(futures) to process results and update progress
        #   5. Use threading.Lock() for thread-safe counter updates
        #   6. Make max_workers configurable via options
        # Benefits: 2-4x faster for photo-heavy extractions
        # Challenges: Thread-safe progress callbacks, error handling
        # Risk: Medium (requires thorough testing with different backup sizes)

        for idx, item in enumerate(items):
            # Check for cancellation
            if copy_progress_wrapper:
                should_continue = copy_progress_wrapper(idx + 1, item.get('filename', 'Unknown'))
                if not should_continue:
                    pass  # Export cancelled by user
                    break
            # Skip items with missing critical metadata
            if not item['filename'] or item['filename'] == 'Unknown' or not item['directory']:
                # Silently skip items with missing metadata
                failed_count += 1
                missing_metadata += 1
                continue

            # Find source file
            source_path = self.find_image_file(item)
            if not source_path or not os.path.exists(source_path):
                # Skip files that don't exist (iCloud photos, deleted files, incomplete backups)
                # Silently skip to avoid console spam - counters track this
                failed_count += 1
                file_not_found += 1
                continue

            # Determine output path based on organization mode
            if organize_by_date:
                # Organize by date: Photos by Year/YYYY/YYYY-MM MonthName/
                try:
                    # Determine media type
                    is_video = item.get('kind') == 1
                    media_type = "Videos by Year" if is_video else "Photos by Year"

                    # Extract date from Apple Core Data timestamp
                    date_created = item.get('date_created')
                    if date_created:
                        # Apple Core Data timestamp is seconds since 2001-01-01
                        apple_epoch = datetime(2001, 1, 1, tzinfo=timezone.utc).timestamp()
                        unix_timestamp = apple_epoch + date_created
                        dt = datetime.fromtimestamp(unix_timestamp)

                        year = dt.strftime("%Y")
                        month = dt.strftime("%Y-%m %B")  # e.g., "2021-01 January"
                        directory = os.path.join(media_type, year, month)
                    else:
                        # No date available
                        directory = os.path.join(media_type, "Unknown Date")
                except Exception as e:
                    # Fallback to Unknown Date if date parsing fails
                    directory = os.path.join("Photos by Year", "Unknown Date")
            else:
                # Preserve original directory structure
                directory = item['directory'] or 'Unknown'

                # Sanitize directory name for Windows/filesystem compatibility
                # First, normalize path separators to OS-specific
                directory = directory.replace('/', os.sep).replace('\\', os.sep)

                # Remove invalid characters: < > : " | ? *
                # Note: / and \ are handled separately as path separators
                invalid_chars = '<>:"|?*'
                for char in invalid_chars:
                    directory = directory.replace(char, '_')

                # Split path into components to check each part
                path_parts = directory.split(os.sep)
                sanitized_parts = []

                # Windows reserved device names (case-insensitive)
                reserved_names = {
                    'CON', 'PRN', 'AUX', 'NUL',
                    'COM1', 'COM2', 'COM3', 'COM4', 'COM5', 'COM6', 'COM7', 'COM8', 'COM9',
                    'LPT1', 'LPT2', 'LPT3', 'LPT4', 'LPT5', 'LPT6', 'LPT7', 'LPT8', 'LPT9'
                }

                for part in path_parts:
                    # Remove leading/trailing spaces and dots (Windows doesn't allow these)
                    part = part.strip('. ')

                    # Check if this is a reserved name (case-insensitive)
                    if part.upper() in reserved_names:
                        part = f'{part}_dir'

                    # Ensure part is not empty
                    if not part:
                        part = 'Unknown'

                    sanitized_parts.append(part)

                # Rejoin the path
                directory = os.sep.join(sanitized_parts)

                # Final check - ensure directory name is not empty
                if not directory:
                    directory = 'Unknown'

            filename = item['filename']

            # Create subdirectory if needed
            output_subdir = os.path.join(output_dir, directory)
            os.makedirs(output_subdir, exist_ok=True)

            # Copy file
            output_file_path = os.path.join(output_subdir, filename)

            # Handle filename conflicts
            if os.path.exists(output_file_path):
                base, ext = os.path.splitext(filename)
                counter = 1
                while os.path.exists(output_file_path):
                    output_file_path = os.path.join(output_subdir, f"{base}_{counter}{ext}")
                    counter += 1

            try:
                # Use copyfile (faster than copy2) then set timestamp from database
                shutil.copyfile(source_path, output_file_path)

                # Set file modification time to photo's actual creation date
                # This is MORE accurate than copy2 (which uses backup timestamp)
                if item['date_created'] is not None:
                    # Convert Apple epoch to Unix timestamp
                    apple_epoch_offset = 978307200  # Seconds between 1970 and 2001
                    unix_timestamp = item['date_created'] + apple_epoch_offset
                    # Set both access and modification time
                    os.utime(output_file_path, (unix_timestamp, unix_timestamp))

                exported_count += 1

                # Track exported item for thumbnail generation (if enabled)
                if exported_items is not None:
                    # Determine item type
                    is_video = item.get('kind') == 1
                    item_type = 'video' if is_video else 'photo'

                    # Determine relative path for HTML report
                    relative_path = os.path.relpath(output_file_path, output_dir).replace('\\', '/')

                    # Add to exported items list
                    exported_items.append({
                        'filename': filename,
                        'exported_path': output_file_path,
                        'relative_path': relative_path,
                        'type': item_type,
                        'item_data': item  # Keep reference to original item for metadata
                    })

                # Handle HEIC conversion if requested
                if self._is_heic_file(filename) and convert_heic and HEIC_CONVERSION_AVAILABLE:
                    # Create JPEG filename (replace .heic/.heif with .jpg)
                    base, ext = os.path.splitext(filename)
                    jpeg_filename = f"{base}.jpg"
                    jpeg_path = os.path.join(output_subdir, jpeg_filename)

                    # Handle conflicts
                    if os.path.exists(jpeg_path):
                        counter = 1
                        while os.path.exists(jpeg_path):
                            jpeg_path = os.path.join(output_subdir, f"{base}_{counter}.jpg")
                            counter += 1

                    # Convert HEIC to JPEG
                    if self._convert_heic_to_jpeg(output_file_path, jpeg_path):
                        heic_converted += 1

                        # SAFETY CHECK: Verify JPEG exists and has content before deleting HEIC
                        if os.path.exists(jpeg_path) and os.path.getsize(jpeg_path) > 0:
                            # Safely delete the HEIC file after successful conversion
                            try:
                                os.remove(output_file_path)
                                pass  # Replaced HEIC with JPEG

                                # Update tracked item to point to JPEG instead of HEIC
                                if exported_items is not None and len(exported_items) > 0:
                                    # Update the last added item (the HEIC we just exported)
                                    last_item = exported_items[-1]
                                    last_item['filename'] = jpeg_filename
                                    last_item['exported_path'] = jpeg_path
                                    last_item['relative_path'] = os.path.relpath(jpeg_path, output_dir).replace('\\', '/')

                            except Exception as delete_error:
                                print(f"[WARNING] Failed to delete HEIC file {filename}: {delete_error}")
                                print(f"[WARNING] Both HEIC and JPEG versions exist")
                        else:
                            print(f"[WARNING] JPEG conversion produced empty file for {filename}")
                            print(f"[WARNING] Keeping both HEIC and JPEG files")

            except Exception as e:
                print(f"[WARNING] Failed to copy {filename}: {e}")
                failed_count += 1
                copy_errors += 1

        # Final progress update for copy phase
        if copy_progress_wrapper:
            copy_progress_wrapper(exported_count, "Copy complete")

        # Export complete (summary removed for performance)

        # Generate thumbnails and HTML report if requested
        if generate_html_report and exported_items:
            try:
                print(f"[INFO] Generating thumbnails for {len(exported_items)} items...")
                combined_total = max(combined_total_pre, exported_count + len(exported_items))

                def thumb_progress(*args, **kwargs):
                    # Accept both positional and keyword to match _generate_thumbnails callback shape
                    current = kwargs.get('current') if kwargs else (args[0] if args else 0)
                    item_name = kwargs.get('item_name') if kwargs else (args[2] if len(args) > 2 else '')
                    if progress_callback:
                        return progress_callback(
                            current=exported_count + current,
                            total=combined_total,
                            item_name=item_name
                        )
                    return True

                thumb_count = self._generate_thumbnails(exported_items, output_dir, progress_callback=thumb_progress if progress_callback else None)
                print(f"[INFO] Generated {thumb_count} thumbnails")

                # Extract metadata from exported files (EXIF, GPS, camera info, etc.)
                print(f"[INFO] Extracting metadata from {len(exported_items)} items...")
                metadata_index = self._build_metadata_index(exported_items, organize_by_date)
                metadata_items = metadata_index.get('items', [])
                print(f"[INFO] Metadata extracted successfully")

                # Generate HTML report with enriched metadata
                print(f"[INFO] Generating HTML report...")
                self._generate_html_report(metadata_items, output_dir)
                print(f"[INFO] HTML report generated successfully")
            except Exception as e:
                # Thumbnail/HTML generation failure should not break the export
                print(f"[WARNING] HTML report generation failed: {e}")
                import traceback
                traceback.print_exc()

        return (exported_count, failed_count)

    def _export_csv(self, items: List[Dict[str, Any]], output_path: str) -> bool:
        """Export metadata to CSV format."""
        import csv

        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)

            # Header
            writer.writerow([
                'Filename',
                'Date Created',
                'Width',
                'Height',
                'Type',
                'Duration (seconds)',
                'Directory',
                'UUID'
            ])

            # Data
            for item in items:
                media_type = 'Video' if item['kind'] == 1 else 'Photo'
                date_str = self._format_timestamp(item['date_created'])

                writer.writerow([
                    item['filename'],
                    date_str,
                    item['width'],
                    item['height'],
                    media_type,
                    item['duration'] if item['kind'] == 1 else '',
                    item['directory'],
                    item['uuid']
                ])

        return True

    def _export_json(self, items: List[Dict[str, Any]], output_path: str) -> bool:
        """Export metadata to JSON format."""
        import json

        export_items = []
        for item in items:
            export_item = {
                'filename': item['filename'],
                'date_created': self._format_timestamp(item['date_created']),
                'width': item['width'],
                'height': item['height'],
                'type': 'video' if item['kind'] == 1 else ('dng' if item['filename'].lower().endswith('.dng') else 'photo'),
                'duration_seconds': item['duration'] if item['kind'] == 1 else None,
                'directory': item['directory'],
                'uuid': item['uuid']
            }
            export_items.append(export_item)

        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(export_items, f, indent=2)

        return True

    def _format_timestamp(self, timestamp) -> str:
        """Format Apple Core Data timestamp for display."""
        if timestamp is None:
            return "N/A"

        try:
            # Apple Core Data timestamp is seconds since 2001-01-01 00:00:00 UTC
            apple_epoch = datetime(2001, 1, 1, tzinfo=timezone.utc).timestamp()
            unix_timestamp = apple_epoch + timestamp

            dt = datetime.fromtimestamp(unix_timestamp)
            return dt.strftime("%m-%d-%Y %H:%M:%S")
        except:
            return str(timestamp)

    def _extract_album_data(self) -> List[Dict[str, Any]]:
        """
        Extract album data from Photos.sqlite.

        Returns:
            List of albums with id, title, and photo count
        """
        albums = []

        try:
            conn = sqlite3.connect(self.photos_db_path)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()

            # Query albums from ZGENERICALBUM table
            if self.schema_version == 'ios13+' and self.album_assets_table:
                # Get column names from relationship table
                cur.execute(f"PRAGMA table_info({self.album_assets_table})")
                columns = [row[1] for row in cur.fetchall()]
                album_col = next((col for col in columns if 'ALBUM' in col.upper()), None)

                if album_col:
                    # Query with photo counts
                    cur.execute(f"""
                        SELECT
                            Z_PK,
                            ZTITLE,
                            (SELECT COUNT(*)
                             FROM {self.album_assets_table}
                             WHERE {album_col} = ZGENERICALBUM.Z_PK) as photo_count
                        FROM ZGENERICALBUM
                        WHERE ZTITLE IS NOT NULL
                        ORDER BY ZTITLE
                    """)
                else:
                    # Fallback without counts
                    cur.execute("""
                        SELECT Z_PK, ZTITLE, 0 as photo_count
                        FROM ZGENERICALBUM
                        WHERE ZTITLE IS NOT NULL
                        ORDER BY ZTITLE
                    """)
            else:
                # Legacy schema or no relationship table
                cur.execute("""
                    SELECT Z_PK, ZTITLE, 0 as photo_count
                    FROM ZGENERICALBUM
                    WHERE ZTITLE IS NOT NULL
                    ORDER BY ZTITLE
                """)

            for row in cur.fetchall():
                albums.append({
                    'id': row['Z_PK'],
                    'title': row['ZTITLE'] or 'Unnamed Album',
                    'count': row['photo_count'] if row['photo_count'] else 0
                })

            conn.close()

        except sqlite3.OperationalError as e:
            print(f"[WARNING] Could not query albums: {e}")

        return albums

    def _build_asset_album_mapping(self) -> Dict[int, List[str]]:
        """
        Build mapping of asset ID to list of album names.

        Returns:
            Dictionary: {asset_z_pk: [album_name1, album_name2, ...]}
        """
        mapping = {}

        try:
            conn = sqlite3.connect(self.photos_db_path)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()

            if self.schema_version == 'ios13+' and self.album_assets_table:
                # Get column names from relationship table
                cur.execute(f"PRAGMA table_info({self.album_assets_table})")
                columns = [row[1] for row in cur.fetchall()]
                album_col = next((col for col in columns if 'ALBUM' in col.upper()), None)
                asset_col = next((col for col in columns if 'ASSET' in col.upper()), None)

                if album_col and asset_col:
                    # Query asset-album relationships
                    cur.execute(f"""
                        SELECT
                            aa.{asset_col} as asset_id,
                            ga.ZTITLE as album_name
                        FROM {self.album_assets_table} aa
                        JOIN ZGENERICALBUM ga ON aa.{album_col} = ga.Z_PK
                        WHERE ga.ZTITLE IS NOT NULL
                        ORDER BY aa.{asset_col}, ga.ZTITLE
                    """)

                    for row in cur.fetchall():
                        asset_id = row['asset_id']
                        album_name = (row['album_name'] or '').strip()
                        if not album_name:
                            continue

                        if asset_id not in mapping:
                            mapping[asset_id] = []
                        mapping[asset_id].append(album_name)

            conn.close()

        except sqlite3.OperationalError as e:
            print(f"[WARNING] Could not build asset-album mapping: {e}")

        return mapping

    def _generate_html_report(self, exported_items: List[Dict[str, Any]],
                             output_dir: str) -> bool:
        """
        Generate interactive HTML report for photos and videos.

        Args:
            exported_items: List of exported photo/video metadata dicts
            output_dir: Output directory where HTML report will be saved

        Returns:
            True if successful, False otherwise
        """
        try:
            # Extract album data and build asset-to-album mapping
            print("[INFO] Extracting album data...")
            albums = self._extract_album_data()
            asset_album_mapping = self._build_asset_album_mapping()
            print(f"[INFO] Found {len(albums)} albums, {len(asset_album_mapping)} photos with album associations")

            # Enrich exported_items with album information
            for item in exported_items:
                item_data = item.get('item_data', {})
                # Asset primary key can be stored as 'z_pk' (lowercase) in metadata dicts
                raw_asset_id = item_data.get('Z_PK') or item_data.get('z_pk')
                asset_id = None
                if raw_asset_id is not None:
                    try:
                        asset_id = int(raw_asset_id)
                    except (ValueError, TypeError):
                        asset_id = raw_asset_id

                mapping_entry = None
                if asset_id is not None:
                    mapping_entry = asset_album_mapping.get(asset_id)
                    if mapping_entry is None:
                        mapping_entry = asset_album_mapping.get(str(asset_id))

                if mapping_entry:
                    # Trim album names for consistent matching
                    item['albums'] = [a.strip() for a in mapping_entry if a and a.strip()]
                else:
                    item['albums'] = []

            # exported_items here are already enriched (metadata_items)
            enriched_items = exported_items

            # Sort photos by date (newest first) for HTML report default order
            # This ensures grid/list views show correct order immediately on page load
            from datetime import datetime
            enriched_items.sort(key=lambda x: datetime.fromisoformat(x.get('date_taken', '1970-01-01T00:00:00')) if x.get('date_taken') else datetime(1970, 1, 1), reverse=True)

            # Attach people/memories metadata from Photos.sqlite (if available)
            try:
                self._attach_people_and_memories(enriched_items)
            except Exception as enrich_err:
                print(f"[WARNING] Failed to attach people/memories metadata: {enrich_err}")

            # Calculate statistics
            total_items = len(enriched_items)
            photo_count = sum(1 for item in enriched_items if item.get('type') == 'photo')
            video_count = sum(1 for item in enriched_items if item.get('type') == 'video')
            gps_count = sum(1 for item in enriched_items if item.get('gps'))

            # Sanitize metadata (remove Infinity/NaN values that break JSON)
            import json
            import math

            def sanitize_for_json(obj):
                """Recursively sanitize data structure for JSON serialization."""
                if isinstance(obj, dict):
                    return {k: sanitize_for_json(v) for k, v in obj.items()}
                elif isinstance(obj, list):
                    return [sanitize_for_json(item) for item in obj]
                elif isinstance(obj, float):
                    if math.isnan(obj) or math.isinf(obj):
                        return None
                    return obj
                else:
                    return obj

            sanitized_items = sanitize_for_json(enriched_items)
            metadata_json = json.dumps(sanitized_items, indent=2, default=str)

            # Sanitize albums for JSON
            sanitized_albums = sanitize_for_json(albums)
            albums_json = json.dumps(sanitized_albums, indent=2, default=str)

            # Generate HTML
            html_content = self._generate_html_template(
                total_items=total_items,
                photo_count=photo_count,
                video_count=video_count,
                gps_count=gps_count,
                metadata_json=metadata_json,
                albums_json=albums_json
            )

            # Write HTML file
            html_path = os.path.join(output_dir, 'index.html')
            with open(html_path, 'w', encoding='utf-8') as f:
                f.write(html_content)

            print(f"[INFO] Generated HTML report: {html_path}")
            return True

        except Exception as e:
            print(f"[ERROR] Failed to generate HTML report: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _generate_html_template(self, total_items: int, photo_count: int,
                                video_count: int, gps_count: int,
                                metadata_json: str, albums_json: str = "[]") -> str:
        """Generate the complete HTML template with embedded CSS and JavaScript."""

        template = r"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Photos & Videos Report</title>

    <!-- Leaflet.js for map view -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            background: #f5f5f5;
            color: #333;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
        }

        /* Header */
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            text-align: left;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            border-radius: 12px;
        }

        .header h1 {
            font-size: 36px;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .header .stats {
            font-size: 16px;
            opacity: 0.95;
            margin-top: 10px;
            margin: 0 0px;
            display: inline-block;
        }

        .stat-sep {
            margin: 0 8px;
            opacity: 0.7;
        }

        .header-spacer {
            height: 6px;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 24px;
        }

        .header-left {
            flex: 1;
            min-width: 0;
        }

        .header-date-range {
            width: 360px;
            max-width: 100%;
            background: rgba(255, 255, 255, 0.12);
            border: 1px solid rgba(255, 255, 255, 0.25);
            border-radius: 10px;
            padding: 14px 16px;
            color: #fff;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.12);
        }

        .header-date-range .date-range-label {
            display: block;
            font-size: 13px;
            font-weight: 700;
            letter-spacing: 0.2px;
            margin-bottom: 8px;
            color: #eef1ff;
        }

        .header-date-range .date-range-picker {
            width: 100%;
            background: rgba(255, 255, 255, 0.96);
            border: 1px solid rgba(255, 255, 255, 0.4);
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.6);
        }

        .header-date-range .date-range-picker input[type="date"] {
            min-width: 0;
        }

        .header-date-range .clear-date-btn {
            background: #ececf7;
            color: #444;
        }

        /* Responsive header stacking */
        @media (max-width: 900px) {
            .header-content {
                flex-direction: column;
                align-items: stretch;
            }

            .header-date-range {
                width: 100%;
            }
        }

        /* Controls Bar */
        .controls {
            background: white;
            padding: 20px;
            border-bottom: 1px solid #e0e0e0;
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            align-items: center;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            border-radius: 12px;
        }

        .view-buttons {
            display: flex;
            gap: 5px;
            border: 1px solid #ddd;
            border-radius: 6px;
            overflow: hidden;
        }

        .view-buttons button {
            padding: 12px 16px;
            border: none;
            background: white;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.2s;
        }

        .view-buttons button:hover {
            background: #f0f0f0;
        }

        .view-buttons button.active {
            background: #667eea;
            color: white;
        }

        .search-box {
            flex: 1;
            min-width: 200px;
        }

        .search-box input {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
        }

        .filter-group {
            display: flex;
            gap: 10px;
            align-items: center;
	    min-width: 350px;
        }

        .filter-group select {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
            cursor: pointer;
        }

        /* Main Content */
        .content {
            padding: 20px;
            min-height: 600px;
        }

        .view {
            display: none;
        }

        .view.active {
            display: block;
        }

        /* Grid View */
        .grid-view {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
        }

        .photo-card {
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .photo-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }

        .photo-card .thumbnail {
            width: 100%;
            height: 200px;
            object-fit: cover;
            display: block;
            background: #f0f0f0;
        }

        .photo-card .info {
            padding: 10px;
        }

        .photo-card .filename {
            font-size: 13px;
            font-weight: 500;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            margin-bottom: 5px;
        }

        .photo-card .date {
            font-size: 12px;
            color: #666;
        }

        .photo-card .type-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background: rgba(0,0,0,0.7);
            color: white;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 600;
        }
        .photo-card .type-badge.dng {
            background: #8e44ad;
        }

        .photo-card .thumbnail-wrapper {
            position: relative;
        }

        /* List View */
        .list-view {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .list-item {
            display: flex;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            cursor: pointer;
            transition: box-shadow 0.2s;
        }

        .list-item:hover {
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }

        .list-item .thumbnail {
            width: 150px;
            height: 150px;
            object-fit: cover;
            flex-shrink: 0;
        }

        .list-item .details {
            padding: 15px;
            flex: 1;
        }

        .list-item .filename {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .list-item .metadata {
            font-size: 13px;
            color: #666;
            line-height: 1.6;
        }

        .list-item .metadata-row {
            margin-bottom: 5px;
        }

        .list-item .metadata-label {
            font-weight: 600;
            display: inline-block;
            width: 100px;
        }

        /* Map View */
        #map {
            width: 100%;
            height: 600px;
            border-radius: 8px;
        }

        .map-photo-popup {
            text-align: center;
        }

        .map-photo-popup img {
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 4px;
            margin-bottom: 8px;
        }

        .map-photo-popup .filename {
            font-size: 12px;
            font-weight: 600;
        }

        /* Photo Modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.9);
            overflow: auto;
        }

        .modal.active {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .modal-content {
            background: white;
            max-width: 1200px;
            max-height: 90vh;
            margin: 20px;
            border-radius: 8px;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }

        .modal-header {
            padding: 20px;
            border-bottom: 1px solid #e0e0e0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-header h2 {
            font-size: 18px;
            font-weight: 600;
        }

        .modal-close {
            background: none;
            border: none;
            font-size: 28px;
            cursor: pointer;
            color: #666;
            padding: 0;
            width: 30px;
            height: 30px;
            line-height: 28px;
        }

        .modal-body {
            display: flex;
            flex: 1;
            overflow: hidden;
        }

        .modal-preview {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #000;
            padding: 20px;
        }

        .modal-preview img,
        .modal-preview video {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }

        .modal-metadata {
            width: 350px;
            padding: 20px;
            overflow-y: auto;
            border-left: 1px solid #e0e0e0;
            background: #f9f9f9;
        }

        .metadata-section {
            margin-bottom: 20px;
        }

        .metadata-section h3 {
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 10px;
            color: #667eea;
        }

        .metadata-item {
            margin-bottom: 8px;
            font-size: 13px;
        }

        .metadata-item strong {
            display: inline-block;
            width: 120px;
            color: #666;
        }

        .album-badge {
            display: inline-block;
            padding: 4px 10px;
            margin: 2px 4px 2px 0;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 500;
        }

        .modal-nav {
            padding: 15px 20px;
            border-top: 1px solid #e0e0e0;
            display: flex;
            justify-content: space-between;
        }

        .modal-nav button {
            padding: 8px 16px;
            border: 1px solid #ddd;
            background: white;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
        }

        .modal-nav button:hover {
            background: #f0f0f0;
        }

        .modal-nav button:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        /* Loading Spinner */
        .loading {
            text-align: center;
            padding: 20px;
            color: #666;
        }

        .spinner {
            border: 3px solid #f3f3f3;
            border-top: 3px solid #667eea;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #666;
        }

        .empty-state h3 {
            font-size: 20px;
            margin-bottom: 10px;
        }

        /* Pagination Controls */
        .pagination-controls {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            margin-top: 30px;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            flex-wrap: wrap;
            gap: 15px;
        }

        .pagination-info {
            color: #333;
            font-size: 14px;
            font-weight: 500;
        }

        .pagination-buttons {
            display: flex;
            gap: 8px;
        }

        .pagination-buttons button {
            padding: 8px 16px;
            background: white;
            border: 2px solid #667eea;
            border-radius: 6px;
            color: #667eea;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            box-shadow: 0 2px 4px rgba(102, 126, 234, 0.2);
        }

        .pagination-buttons button:hover:not(:disabled) {
            background: #667eea;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(102, 126, 234, 0.3);
        }

        .pagination-buttons button:active:not(:disabled) {
            transform: translateY(0);
            box-shadow: 0 2px 4px rgba(102, 126, 234, 0.2);
        }

        .pagination-buttons button:disabled {
            background: #e0e0e0;
            border-color: #ccc;
            color: #999;
            cursor: not-allowed;
            box-shadow: none;
        }

        /* Layout rows */
        .controls {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 12px;
            flex-wrap: wrap;
        }

        .filters-toggle {
            padding: 12px 16px;
            border: 1px solid #dcdcdc;
            border-radius: 8px;
            background: #f7f7fb;
            cursor: pointer;
            font-weight: 600;
            color: #444;
            transition: all 0.2s ease;
        }

        .filters-toggle:hover {
            background: #ececf7;
        }

        .filters-toggle.active {
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.2);
            color: #2f3d73;
        }

        .search-inline {
            display: flex;
            gap: 10px;
            align-items: center;
            flex: 1;
            min-width: 280px;
        }

        .search-box {
            flex: 1;
        }

        .result-count {
            font-size: 14px;
            color: #555;
            min-width: 140px;
        }

        .search-box input {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid #dcdcdc;
            border-radius: 10px;
            font-size: 15px;
        }

        .sort-box select {
            padding: 10px 12px;
            border: 1px solid #dcdcdc;
            border-radius: 8px;
            font-size: 14px;
            background: white;
        }

        .filters-row {
            margin-top: 10px;
            display: flex;
            flex-direction: column;
            gap: 12px;
            max-height: 800px;
            overflow: hidden;
            transition: max-height 0.25s ease, opacity 0.2s ease, margin-top 0.2s ease;
            opacity: 1;
        }

        .filters-row-section {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            column-gap: 14px;
            row-gap: 10px;
            align-items: start;
        }

        .filters-row.collapsed {
            max-height: 0;
            opacity: 0;
            margin-top: 0;
            pointer-events: none;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
	    min-width: 300px;
            gap: 6px;
        }

        .filters-controls {
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .filters-clear {
            padding: 8px 10px;
            border: 1px solid #dcdcdc;
            background: #fff;
            border-radius: 8px;
            cursor: pointer;
        }

        .filters-clear:hover {
            background: #f0f0f0;
        }

        .filters-toggle #filter-count {
            font-weight: 600;
        }

        .filters-toggle .filter-count-hidden {
            display: none;
        }

        .search-box {
            position: relative;
        }

        .search-box .clear-search {
            position: absolute;
            right: 8px;
            top: 50%;
            transform: translateY(-50%);
            border: none;
            background: transparent;
            cursor: pointer;
            font-size: 14px;
            color: #666;
            padding: 4px;
        }

        .search-box .clear-search:hover {
            color: #000;
        }

        .filter-group label {
            font-size: 13px;
            font-weight: 600;
            color: #444;
        }

        .filter-group select {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
            background: white;
            min-width: 200px;
            width: 85%;
        }

        /* Date Range Picker */
        .date-range-picker {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 4px 5px;
            background: #f7f7fb;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.6);
	    min-width: 300px;
            width: 85%;
        }

        .date-range-picker input[type="date"] {
            padding: 8px 10px;
            border: 1px solid #dcdcdc;
            border-radius: 6px;
            font-size: 14px;
            color: #333;
            background: white;
            flex: 1;
            min-width: 0;
        }

        .date-range-picker input[type="date"]:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.2);
        }

        .date-separator {
            color: #777;
            font-weight: 600;
            flex-shrink: 0;
        }

        .clear-date-btn {
            border: none;
            background: #f0f0f5;
            color: #666;
            border-radius: 50%;
            width: 28px;
            height: 28px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            transition: all 0.15s ease;
            flex-shrink: 0;
        }

        .clear-date-btn:hover {
            background: #e0e0ea;
            color: #333;
        }

        /* Timeline View */
        .timeline-container {
            display: flex;
            flex-direction: column;
            gap: 16px;
            padding: 10px;
        }

        .timeline-year {
            background: #f5f7ff;
            border: 1px solid #e2e6f5;
            border-radius: 12px;
            padding: 12px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.04);
        }

        .timeline-year h2 {
            margin: 0 0 10px 0;
            font-size: 20px;
            color: #3a4a92;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .timeline-month {
            background: white;
            border: 1px solid #e6e8f0;
            border-radius: 10px;
            margin-bottom: 10px;
            overflow: hidden;
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.8);
        }

        .timeline-month-header {
            background: linear-gradient(135deg, #f7f9ff 0%, #ecf1ff 100%);
            padding: 10px 14px;
            border-bottom: 1px solid #e6e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-weight: 600;
            color: #2f3d73;
        }

        .timeline-day {
            padding: 12px 14px 6px 14px;
        }

        .timeline-day-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
            color: #444;
            font-weight: 600;
        }

        .timeline-day-header .count {
            color: #667eea;
            font-size: 13px;
        }

        .timeline-day-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
            gap: 10px;
        }

        .timeline-photo {
            border: 1px solid #e6e6e6;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 1px 4px rgba(0,0,0,0.05);
            cursor: pointer;
            background: white;
            transition: transform 0.15s ease, box-shadow 0.15s ease;
        }

        .timeline-photo:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(0,0,0,0.08);
        }

        .timeline-photo img {
            width: 100%;
            height: 110px;
            object-fit: cover;
            display: block;
        }

        .timeline-photo .thumb-info {
            padding: 8px;
        }

        .timeline-photo .thumb-info .name {
            font-size: 13px;
            font-weight: 600;
            color: #333;
            margin-bottom: 4px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .timeline-photo .thumb-info .time {
            font-size: 12px;
            color: #666;
        }

        /* Responsive */
        @media (max-width: 900px) {
            .header h1 {
                font-size: 24px;
            }

            .controls {
                flex-direction: column;
                align-items: stretch;
            }

            .search-inline {
                flex-direction: column;
                align-items: stretch;
            }

            .filters-row {
                grid-template-columns: 1fr;
            }

            .grid-view {
                grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
                gap: 10px;
            }

            .list-item {
                flex-direction: column;
            }

            .list-item .thumbnail {
                width: 100%;
                height: 200px;
            }

            .modal-content {
                max-width: 100%;
                height: 100vh;
                margin: 0;
                border-radius: 0;
            }

            .modal-body {
                flex-direction: column;
            }

            .modal-metadata {
                width: 100%;
                border-left: none;
                border-top: 1px solid #e0e0e0;
            }
        }
    
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div class="header-content">
                <div class="header-left">
                    <h1>Photos & Videos</h1>
                    <div class="stats">
                        <span>Total: __TOTAL_ITEMS__ items</span>
                        <span class="stat-sep">|</span>
                        <span>__PHOTO_COUNT__ photos</span>
                        <span class="stat-sep">|</span>
                        <span>__VIDEO_COUNT__ videos</span>
                        <span class="stat-sep">|</span>
                        <span>__GPS_COUNT__ with GPS</span>
                    </div>
                    <div class="header-spacer"></div>
                </div>
                <div class="header-date-range">
                    <label for="date-from" class="date-range-label">Date Range</label>
                    <div class="date-range-picker">
                        <input type="date" id="date-from" onchange="applyFilters()" placeholder="From Date">
                        <span class="date-separator">to</span>
                        <input type="date" id="date-to" onchange="applyFilters()" placeholder="To Date">
                        <button onclick="clearDateFilter()" class="clear-date-btn" title="Clear date filter">&times;</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Controls -->
        <div class="controls">
            <div class="view-buttons">
                <button onclick="switchView('grid')" class="active" id="btn-grid">Grid</button>
                <button onclick="switchView('list')" id="btn-list">List</button>
                <button onclick="switchView('timeline')" id="btn-timeline">Timeline</button>
                <button onclick="switchView('map')" id="btn-map">Map</button>
            </div>
            <div class="filters-controls">
                <button id="toggle-filters" class="filters-toggle" onclick="toggleFilters()">Filters <span id="filter-count"></span></button>
                <button id="clear-filters-btn" class="filters-clear" onclick="clearAllFilters()" title="Clear all filters">✕</button>
            </div>
            <div class="search-inline">
                <div class="search-box">
                    <input type="text" id="search-input" placeholder="Search by filename..." oninput="handleSearch()" />
                    <button id="clear-search-btn" class="clear-search" onclick="clearSearch()" title="Clear search">✕</button>
                </div>
                <div id="results-count" class="result-count"></div>
                <div class="sort-box">
                    <select id="sort-by" onchange="applySorting()">
                        <option value="date-desc">Newest First</option>
                        <option value="date-asc">Oldest First</option>
                        <option value="name-asc">Name (A-Z)</option>
                        <option value="name-desc">Name (Z-A)</option>
                        <option value="size-desc">Largest First</option>
                        <option value="size-asc">Smallest First</option>
                    </select>
                </div>
            </div>
        </div>

        <!-- Filters Row -->
        <div class="filters-row" id="filters-row">
            <div class="filters-row-section">
                <div class="filter-group">
                    <label for="filter-album">Albums</label>
                    <select id="filter-album" onchange="applyFilters()">
                        <option value="all">All Albums</option>
                        <!-- Populated dynamically from albums data -->
                    </select>
                </div>

                <div class="filter-group">
                    <label for="filter-type">Type</label>
                    <select id="filter-type" onchange="applyFilters()">
                        <option value="all">All Types</option>
                        <option value="photo">Photos Only</option>
                        <option value="video">Videos Only</option>
                    </select>
                </div>

                <div class="filter-group">
                    <label for="filter-camera">Camera</label>
                    <select id="filter-camera" onchange="applyFilters()">
                        <option value="all">All Cameras</option>
                        <!-- Populated dynamically -->
                    </select>
                </div>
            </div>

            <div class="filters-row-section">
                <div class="filter-group">
                    <label for="filter-person">People</label>
                    <select id="filter-person" onchange="applyFilters()">
                        <option value="all">All People</option>
                        <!-- Populated dynamically -->
                    </select>
                </div>

                <div class="filter-group">
                    <label for="filter-memory">Memories</label>
                    <select id="filter-memory" onchange="applyFilters()">
                        <option value="all">All Memories</option>
                        <!-- Populated dynamically -->
                    </select>
                </div>

                <div class="filter-group">
                    <label for="filter-pet">Pets</label>
                    <select id="filter-pet" disabled>
                        <option value="coming-soon">Coming soon</option>
                    </select>
                </div>
            </div>

            <div class="filters-row-section">
                <div class="filter-group">
                    <label for="filter-favorite">Favorites / Hidden</label>
                    <select id="filter-favorite" onchange="applyFilters()">
                        <option value="all">All Items</option>
                        <option value="fav">Favorites only</option>
                        <option value="not-fav">Non-favorites</option>
                        <option value="hidden">Hidden only</option>
                        <option value="not-hidden">Visible only</option>
                    </select>
                </div>

                <div class="filter-group">
                    <label for="filter-orientation">Orientation</label>
                    <select id="filter-orientation" onchange="applyFilters()">
                        <option value="all">All Orientations</option>
                        <option value="landscape">Landscape</option>
                        <option value="portrait">Portrait</option>
                        <option value="square">Square</option>
                    </select>
                </div>

                <div class="filter-group">
                    <label for="filter-size">Size</label>
                    <select id="filter-size" onchange="applyFilters()">
                        <option value="all">All Sizes</option>
                        <option value="lt1">Under 1 MB</option>
                        <option value="1to5">1 - 5 MB</option>
                        <option value="5to20">5 - 20 MB</option>
                        <option value="gt20">Over 20 MB</option>
                    </select>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="content">
            <!-- Grid View -->
            <div id="grid-view" class="view active">
                <div class="grid-view" id="grid-container">
                    <div class="loading">
                        <div class="spinner"></div>
                        <p>Loading photos...</p>
                    </div>
                </div>
            </div>

            <!-- List View -->
            <div id="list-view" class="view">
                <div class="list-view" id="list-container">
                    <div class="loading">
                        <div class="spinner"></div>
                        <p>Loading photos...</p>
                    </div>
                </div>
            </div>

            <!-- Map View -->
            <div id="map-view" class="view">
                <div id="map"></div>
            </div>

            <!-- Timeline View -->
            <div id="timeline-view" class="view">
                <div class="timeline-container" id="timeline-container">
                    <div class="loading">
                        <div class="spinner"></div>
                        <p>Loading timeline...</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Photo Modal -->
    <div id="photo-modal" class="modal" onclick="closeModalOnBackdrop(event)">
        <div class="modal-content" onclick="event.stopPropagation()">
            <div class="modal-header">
                <h2 id="modal-title">Photo Details</h2>
                <button class="modal-close" onclick="closeModal()">&times;</button>
            </div>
            <div class="modal-body">
                <div class="modal-preview" id="modal-preview">
                    <!-- Preview content goes here -->
                </div>
                <div class="modal-metadata" id="modal-metadata">
                    <!-- Metadata content goes here -->
                </div>
            </div>
            <div class="modal-nav">
                <button onclick="navigateModal(-1)" id="modal-prev">← Previous</button>
                <button onclick="navigateModal(1)" id="modal-next">Next →</button>
            </div>
        </div>
    </div>

    <!-- Photo Data (embedded JSON) -->
    <script id="photo-data" type="application/json">
__METADATA_JSON__
    </script>

    <!-- Album Data (embedded JSON) -->
    <script id="album-data" type="application/json">
__ALBUMS_JSON__
    </script>

    <!-- JavaScript -->
    <script>
        // Global state
        let allPhotos = [];
        let filteredPhotos = [];
        let allAlbums = [];
        let allCameras = [];
        let currentView = 'grid';
        let currentPhotoIndex = -1;
        let map = null;
        let searchCriteria = {
            terms: [],
            type: null,
            album: null,
            camera: null,
            hasLocation: null,
            dateFrom: null,
            dateTo: null,
            monthAnyYear: null,
            dayOfMonth: null,
            monthRangeAnyYear: null,
            monthDayRangeAnyYear: null,
            ext: null,
            sizeGt: null,
            sizeLt: null,
            durationGt: null,
            durationLt: null
        };
        let filtersVisible = false;

        // Pagination state
        let currentPage = 1;
        let itemsPerPage = 2500;  // Max items to render at once (adjustable based on performance testing)
        let totalPages = 1;
        const placeholderExamples = [
            '🔍 All pictures in November...',
            '🔍 Videos longer than 5 minutes...',
            '🔍 Pictures larger than 2mb...',
            '🔍 Photos taken with iphone...',
            '🔍 All photos with GPS...',
            '🔍 No location...',
            '🔍 Photos from 2022...',
            '🔍 Album: "Vacation"...',
            '🔍 HEIC photos only...',
            '🔍 PNG files only...',
            '🔍 Photos last month...',
            '🔍 Videos from yesterday...',
            '🔍 Photos taken on January 5 2023...',
            '🔍 All videos...',
            '🔍 Pictures taken with an Iphone...',
            '🔍 Pictures taken with a Nikon...',
            '🔍 Pictures larger than 2mb...'
        ];
        let placeholderTimer = null;
        let placeholderIndex = 0;
        let datasetLatestDate = null; // latest date in dataset for relative date parsing
        let allPeople = [];
        let allMemories = [];
        let activeFilterCount = 0;
        const parseDateSafe = (val) => {
            if (!val) return null;
            const cleaned = typeof val === 'string' ? val.replace(' ', 'T') : val;
            const d = new Date(cleaned);
            return isNaN(d) ? null : d;
        };

        // Initialize
        document.addEventListener('DOMContentLoaded', function() {
            loadPhotoData();
            loadAlbumData();
            populateAlbumFilter();
            buildPeopleIndex();
            buildMemoryIndex();
            initializeViews();
            startPlaceholderRotation();
            updateFilterCount();
            // Sync filters toggle state on load
            const filtersRow = document.getElementById('filters-row');
            const toggleBtn = document.getElementById('toggle-filters');
            if (filtersRow && toggleBtn) {
                filtersRow.classList.add('collapsed');
                toggleBtn.classList.remove('active');
            }
        });

        // Load photo data from embedded JSON
        function loadPhotoData() {
            try {
                const dataElement = document.getElementById('photo-data');
                allPhotos = JSON.parse(dataElement.textContent);
                filteredPhotos = [...allPhotos];
                // Compute latest date in dataset for relative queries
                const validDates = allPhotos
                    .map(p => parseDateSafe(p.date_taken))
                    .filter(d => d);
                if (validDates.length > 0) {
                    datasetLatestDate = new Date(Math.max(...validDates.map(d => d.getTime())));
                }
                buildCameraIndex();
                buildPeopleIndex();
                buildMemoryIndex();
                console.log(`Loaded ${allPhotos.length} photos`);
                renderCurrentView();
            } catch (error) {
                console.error('Error loading photo data:', error);
                showError('Failed to load photo data');
            }
        }

        // Load album data from embedded JSON
        function loadAlbumData() {
            try {
                const dataElement = document.getElementById('album-data');
                allAlbums = JSON.parse(dataElement.textContent);
                console.log(`Loaded ${allAlbums.length} albums`);
            } catch (error) {
                console.error('Error loading album data:', error);
                allAlbums = [];
            }
        }

        // Populate album filter dropdown
        function populateAlbumFilter() {
            const albumSelect = document.getElementById('filter-album');
            if (!albumSelect || allAlbums.length === 0) return;

            // Clear existing options except "All Albums"
            albumSelect.innerHTML = '<option value="all">All Albums</option>';

            // Add album options sorted by title
            const sortedAlbums = [...allAlbums]
                .filter(a => a.count === undefined || a.count > 0)  // hide empty albums
                .sort((a, b) => a.title.localeCompare(b.title));
            sortedAlbums.forEach(album => {
                const option = document.createElement('option');
                option.value = album.title;
                option.textContent = `${album.title} (${album.count})`;
                albumSelect.appendChild(option);
            });
        }

        // Build camera list and populate filter
        function buildCameraIndex() {
            const cameraSet = new Set();
            allPhotos.forEach(photo => {
                if (photo.camera) {
                    const make = photo.camera.make || '';
                    const model = photo.camera.model || '';
                    const label = `${make} ${model}`.trim();
                    if (label) {
                        cameraSet.add(label);
                    }
                }
            });

            allCameras = Array.from(cameraSet).sort((a, b) => a.localeCompare(b));

            const cameraSelect = document.getElementById('filter-camera');
            if (!cameraSelect) return;

            cameraSelect.innerHTML = '<option value="all">All Cameras</option>';
            if (allCameras.length > 0) {
                allCameras.forEach(cam => {
                    const opt = document.createElement('option');
                    opt.value = cam;
                    opt.textContent = cam;
                    cameraSelect.appendChild(opt);
                });
            }

            // Include Unknown option if any photo lacks camera info
            const hasUnknown = allPhotos.some(p => !p.camera);
            if (hasUnknown) {
                const optUnknown = document.createElement('option');
                optUnknown.value = '__unknown__';
                optUnknown.textContent = 'Unknown';
                cameraSelect.appendChild(optUnknown);
            }
        }

        // Build people list (from enriched metadata) and populate filter
        function buildPeopleIndex() {
            const personMap = new Map();
            allPhotos.forEach(photo => {
                (photo.people || []).forEach(p => {
                    const key = (p.uuid && p.uuid.toString().trim()) || (p.id !== undefined ? `id:${p.id}` : null);
                    if (!key) return;
                    const label = (p.name && p.name.trim()) ? p.name.trim() : `Person ${p.id ?? key}`;
                    if (!personMap.has(key)) {
                        personMap.set(key, label);
                    }
                });
            });
            allPeople = Array.from(personMap.entries()).map(([value, label]) => ({ value, label })).sort((a, b) => a.label.localeCompare(b.label));

            const personSelect = document.getElementById('filter-person');
            if (!personSelect) return;
            personSelect.innerHTML = '<option value=\"all\">All People</option>';
            allPeople.forEach(p => {
                const opt = document.createElement('option');
                opt.value = p.value;
                opt.textContent = p.label;
                personSelect.appendChild(opt);
            });
        }

        // Build memory list (from enriched metadata) and populate filter
        function buildMemoryIndex() {
            // Collapse memories with identical titles into a single option (track counts/ids)
            const memMap = new Map(); // key: normalized label -> {label, ids:Set, count}
            allPhotos.forEach(photo => {
                (photo.memories || []).forEach(m => {
                    if (m.id === null || m.id === undefined) return;
                    const labelRaw = (m.title && m.title.trim()) ? m.title.trim() : `Memory ${m.id}`;
                    const key = labelRaw.toLowerCase();
                    if (!memMap.has(key)) {
                        memMap.set(key, { label: labelRaw, ids: new Set(), count: 0 });
                    }
                    const entry = memMap.get(key);
                    entry.ids.add(String(m.id));
                    entry.count += 1;
                });
            });
            allMemories = Array.from(memMap.entries()).map(([value, obj]) => ({
                value, // normalized key
                label: obj.count > 1 ? `${obj.label} (${obj.count})` : obj.label,
                ids: Array.from(obj.ids)
            })).sort((a, b) => a.label.localeCompare(b.label));

            const memSelect = document.getElementById('filter-memory');
            if (!memSelect) return;
            memSelect.innerHTML = '<option value="all">All Memories</option>';
            allMemories.forEach(m => {
                const opt = document.createElement('option');
                opt.value = m.value;
                opt.textContent = m.label;
                memSelect.appendChild(opt);
            });
        }

        // Rotate search placeholder through example NL queries (only when empty/unfocused)
        function startPlaceholderRotation() {
            const input = document.getElementById('search-input');
            if (!input || placeholderExamples.length === 0) return;

            const updatePlaceholder = () => {
                if (document.activeElement === input) return;
                if (input.value && input.value.trim().length > 0) return;
                input.placeholder = placeholderExamples[placeholderIndex % placeholderExamples.length];
                placeholderIndex = (placeholderIndex + 1) % placeholderExamples.length;
            };

            // Kick off immediately then rotate every few seconds
            updatePlaceholder();
            if (placeholderTimer) {
                clearInterval(placeholderTimer);
            }
            placeholderTimer = setInterval(updatePlaceholder, 4000);

            // Light touch UX: hide placeholder when typing/focused, restore when empty
            input.addEventListener('input', () => {
                if (input.value.trim() === '') {
                    updatePlaceholder();
                } else {
                    input.placeholder = '';
                }
            });
            input.addEventListener('focus', () => {
                if (input.value.trim()) {
                    input.placeholder = '';
                }
            });
            input.addEventListener('blur', () => {
                if (!input.value.trim()) {
                    updatePlaceholder();
                }
            });
        }

        // Initialize views
        function initializeViews() {
            // Setup lazy loading for grid view
            setupLazyLoading();
        }

        // Toggle filters visibility
        function toggleFilters() {
            filtersVisible = !filtersVisible;
            const filtersRow = document.getElementById('filters-row');
            const toggleBtn = document.getElementById('toggle-filters');
            if (filtersRow) {
                filtersRow.classList.toggle('collapsed', !filtersVisible);
            }
            if (toggleBtn) {
                toggleBtn.classList.toggle('active', filtersVisible);
            }
        }

        function clearSearch() {
            const input = document.getElementById('search-input');
            if (input) {
                input.value = '';
                handleSearch();
            }
        }

        // Switch view
        function switchView(viewName) {
            currentView = viewName;

            // Update active button
            document.querySelectorAll('.view-buttons button').forEach(btn => {
                btn.classList.remove('active');
            });
            document.getElementById(`btn-${viewName}`).classList.add('active');

            // Show/hide views
            document.querySelectorAll('.view').forEach(view => {
                view.classList.remove('active');
            });
            document.getElementById(`${viewName}-view`).classList.add('active');

            // Render view
            renderCurrentView();
        }

        // Render current view
        function renderCurrentView() {
            if (currentView === 'grid') {
                renderGridView();
            } else if (currentView === 'list') {
                renderListView();
            } else if (currentView === 'map') {
                renderMapView();
            } else if (currentView === 'timeline') {
                renderTimelineView();
            }
        }

        // Render grid view (with pagination)
        function renderGridView() {
            const container = document.getElementById('grid-container');

            if (filteredPhotos.length === 0) {
                container.innerHTML = `
                    <div class="empty-state">
                        <h3>No photos found</h3>
                        <p>Try adjusting your filters or search</p>
                    </div>
                `;
                return;
            }

            // Calculate pagination
            totalPages = Math.ceil(filteredPhotos.length / itemsPerPage);
            currentPage = Math.min(currentPage, totalPages);  // Ensure current page is valid

            const startIndex = (currentPage - 1) * itemsPerPage;
            const endIndex = Math.min(startIndex + itemsPerPage, filteredPhotos.length);
            const pagePhotos = filteredPhotos.slice(startIndex, endIndex);

            container.innerHTML = '';

            // Render only current page items
            pagePhotos.forEach((photo, pageIndex) => {
                const actualIndex = startIndex + pageIndex;  // Index in filteredPhotos array
                const card = createPhotoCard(photo, actualIndex);
                container.appendChild(card);
            });

            setupLazyLoading();
            renderPaginationControls();
        }

        // Create photo card element
        function createPhotoCard(photo, index) {
            const card = document.createElement('div');
            card.className = 'photo-card';
            card.onclick = () => openModal(index);

            const isVideo = photo.type === 'video';
            let typeBadge = '';
            if (photo.type === 'dng') {
                typeBadge = 'RAW';
            } else if (isVideo) {
                typeBadge = '🎬 VIDEO';
            }

            card.innerHTML = `
                <div class="thumbnail-wrapper">
                    <img class="thumbnail lazy" data-src="${photo.thumbnail}" alt="${photo.filename}">
                    ${typeBadge ? `<div class="type-badge ${photo.type === 'dng' ? 'dng' : ''}">${typeBadge}</div>` : ''}
                </div>
                <div class="info">
                    <div class="filename">${photo.filename}</div>
                    <div class="date">${formatDate(photo.date_taken)}</div>
                </div>
            `;

            return card;
        }

        // Render list view
        function renderListView() {
            const container = document.getElementById('list-container');

            if (filteredPhotos.length === 0) {
                container.innerHTML = `
                    <div class="empty-state">
                        <h3>No photos found</h3>
                        <p>Try adjusting your filters or search</p>
                    </div>
                `;
                return;
            }

            // Calculate pagination
            totalPages = Math.ceil(filteredPhotos.length / itemsPerPage);
            currentPage = Math.min(currentPage, totalPages);  // Ensure current page is valid

            const startIndex = (currentPage - 1) * itemsPerPage;
            const endIndex = Math.min(startIndex + itemsPerPage, filteredPhotos.length);
            const pagePhotos = filteredPhotos.slice(startIndex, endIndex);

            container.innerHTML = '';

            // Render only current page items
            pagePhotos.forEach((photo, pageIndex) => {
                const actualIndex = startIndex + pageIndex;  // Index in filteredPhotos array
                const item = createListItem(photo, actualIndex);
                container.appendChild(item);
            });

            setupLazyLoading();
            renderPaginationControls();
        }

        // Create list item element
        function createListItem(photo, index) {
            const item = document.createElement('div');
            item.className = 'list-item';
            item.onclick = () => openModal(index);

            const resolution = photo.width && photo.height ?
                `${photo.width} × ${photo.height}` : 'N/A';
            const size = photo.size ? formatFileSize(photo.size) : 'N/A';
            const camera = photo.camera ?
                `${photo.camera.make || ''} ${photo.camera.model || ''}`.trim() : 'Unknown';
            const location = photo.gps ?
                `${photo.gps.lat.toFixed(6)}, ${photo.gps.lon.toFixed(6)}` : 'No GPS data';

            item.innerHTML = `
                <img class="thumbnail lazy" data-src="${photo.thumbnail}" alt="${photo.filename}">
                <div class="details">
                    <div class="filename">${photo.filename}</div>
                    <div class="metadata">
                        <div class="metadata-row">
                            <span class="metadata-label">Type:</span>
                            ${photo.type === 'video' ? '?? Video' : (photo.type === 'dng' ? 'RAW (DNG)' : '?? Photo')}
                        </div>
                        <div class="metadata-row">
                            <span class="metadata-label">Date:</span>
                            ${formatDate(photo.date_taken)}
                        </div>
                        <div class="metadata-row">
                            <span class="metadata-label">Resolution:</span>
                            ${resolution}
                        </div>
                        <div class="metadata-row">
                            <span class="metadata-label">Size:</span>
                            ${size}
                        </div>
                        <div class="metadata-row">
                            <span class="metadata-label">Camera:</span>
                            ${camera}
                        </div>
                        <div class="metadata-row">
                            <span class="metadata-label">Location:</span>
                            ${location}
                        </div>
                    </div>
                </div>
            `;

            return item;
        }

        // Render map view
        function renderMapView() {
            if (!map) {
                initMap();
            }

            // Clear existing markers
            if (map) {
                map.eachLayer(layer => {
                    if (layer instanceof L.Marker) {
                        map.removeLayer(layer);
                    }
                });

                // Add markers for photos with GPS
                const photosWithGPS = filteredPhotos.filter(p => p.gps);

                if (photosWithGPS.length === 0) {
                    alert('No photos with GPS data found');
                    return;
                }

                photosWithGPS.forEach((photo, index) => {
                    const marker = L.marker([photo.gps.lat, photo.gps.lon]);
                    marker.bindPopup(`
                        <div class="map-photo-popup">
                            <img src="${photo.thumbnail}" alt="${photo.filename}">
                            <div class="filename">${photo.filename}</div>
                        </div>
                    `);
                    marker.on('click', () => {
                        const originalIndex = allPhotos.indexOf(photo);
                        openModal(originalIndex);
                    });
                    marker.addTo(map);
                });

                // Fit map to markers
                if (photosWithGPS.length > 0) {
                    const bounds = photosWithGPS.map(p => [p.gps.lat, p.gps.lon]);
                    map.fitBounds(bounds);
                }
            }
        }

        // Initialize Leaflet map
        function initMap() {
            try {
                map = L.map('map').setView([37.7749, -122.4194], 10);

                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '© OpenStreetMap contributors',
                    maxZoom: 19
                }).addTo(map);

                // Invalidate size after switching to map view
                setTimeout(() => map.invalidateSize(), 100);
            } catch (error) {
                console.error('Error initializing map:', error);
            }
        }

        // Setup lazy loading for images
        function setupLazyLoading() {
            const images = document.querySelectorAll('img.lazy');

            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        img.src = img.dataset.src;
                        img.classList.remove('lazy');
                        observer.unobserve(img);
                    }
                });
            });

            images.forEach(img => imageObserver.observe(img));
        }

        function defaultSearchCriteria() {
            return {
                terms: [],
                type: null,
                album: null,
                camera: null,
                hasLocation: null,
                dateFrom: null,
                dateTo: null,
                monthAnyYear: null,
                dayOfMonth: null,
                monthRangeAnyYear: null,
                monthDayRangeAnyYear: null,
                ext: null,
                sizeGt: null,
                sizeLt: null,
                durationGt: null,
                durationLt: null
            };
        }

        // Parse natural language-ish search into structured criteria
        function parseSearchQuery(rawQuery) {
            const criteria = defaultSearchCriteria();

            if (!rawQuery || !rawQuery.trim()) return criteria;

            let q = rawQuery.trim().toLowerCase();
            q = q.replace(/motnh/g, 'month');  // tolerate typo
            const now = new Date();  // use current date as reference for relative ranges

            const startOfDay = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0, 0, 0);
            const endOfDay = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate(), 23, 59, 59);

            const monthMap = {
                january: 0, jan: 0,
                february: 1, feb: 1,
                march: 2, mar: 2,
                april: 3, apr: 3,
                may: 4,
                june: 5, jun: 5,
                july: 6, jul: 6,
                august: 7, aug: 7,
                september: 8, sep: 8, sept: 8,
                october: 9, oct: 9,
                november: 10, nov: 10,
                december: 11, dec: 11
            };
            const monthPattern = '(?:january|jan|february|feb|march|mar|april|apr|may|june|jun|july|jul|august|aug|september|sept|sep|october|oct|november|nov|december|dec)';

            const numberWords = {
                one: 1, two: 2, three: 3, four: 4, five: 5, six: 6,
                seven: 7, eight: 8, nine: 9, ten: 10, eleven: 11, twelve: 12
            };

            const trySetDateRange = (fromDate, toDate) => {
                if (fromDate && !isNaN(fromDate)) {
                    criteria.dateFrom = criteria.dateFrom ? new Date(Math.max(criteria.dateFrom, fromDate)) : fromDate;
                }
                if (toDate && !isNaN(toDate)) {
                    criteria.dateTo = criteria.dateTo ? new Date(Math.min(criteria.dateTo, toDate)) : toDate;
                }
            };

            const normalizeOrdinal = (text) => text.replace(/(\d)(st|nd|rd|th)\b/g, '$1');
            const parseMonthDayYear = (text) => {
                if (!text) return null;
                const cleaned = normalizeOrdinal(text.toLowerCase().trim());
                const md = cleaned.match(new RegExp(`\\\\b(${monthPattern})\\\\s+(\\\\d{1,2})(?:\\\\s+((?:19|20)\\\\d{2}))?`));
                if (md) {
                    return {
                        month: monthMap[md[1]],
                        day: parseInt(md[2], 10),
                        year: md[3] ? parseInt(md[3], 10) : null
                    };
                }
                const my = cleaned.match(new RegExp(`\\\\b(${monthPattern})\\\\s+((?:19|20)\\\\d{2})`));
                if (my) {
                    return { month: monthMap[my[1]], day: null, year: parseInt(my[2], 10) };
                }
                const mOnly = cleaned.match(new RegExp(`\\\\b(${monthPattern})\\\\b`));
                if (mOnly) {
                    return { month: monthMap[mOnly[1]], day: null, year: null };
                }
                return null;
            };
            let monthRangeSet = false;  // track if month-based range was set to avoid overrides

            // Type hints (lenient contains)
            if (q.includes('video') || q.includes('videos') || q.includes('clip') || q.includes('movie')) criteria.type = 'video';
            if ((q.includes('photo') || q.includes('photos') || q.includes('picture') || q.includes('pictures') || q.includes('image') || q.includes('images') || q.includes('pic') || q.includes('pics')) && criteria.type !== 'video') criteria.type = 'photo';

            // Location hints (allow plain "location" unless negated)
            const hasNoLocation = q.includes('no location') || q.includes('without gps') || q.includes('missing gps') || q.includes('no gps');
            const hasYesLocation = q.includes('has location') || q.includes('with gps') || q.includes('geotagged') || q.includes('gps') || (q.includes('location') && !hasNoLocation);
            if (hasYesLocation) criteria.hasLocation = true;
            if (hasNoLocation) criteria.hasLocation = false;

            // Extension hints
            if (/\\bheic\\b/.test(q)) criteria.ext = '.heic';
            if (/\\bjpe?g\\b/.test(q)) criteria.ext = '.jpg';
            if (/\\bpng\\b/.test(q)) criteria.ext = '.png';
            if (/\\bmov\\b/.test(q)) criteria.ext = '.mov';
            if (/\\bmp4\\b/.test(q)) criteria.ext = '.mp4';

            // Album hint: album:"Family Vacation"
            const albumMatch = q.match(/album[:=]\s*"([^"]+)"|album[:=]\s*'([^']+)'|album[:=]\s*([a-z0-9 _-]+)/);
            if (albumMatch) {
                criteria.album = (albumMatch[1] || albumMatch[2] || albumMatch[3] || '').trim();
            }

            // Camera hint: camera:"iPhone 12"
            const cameraMatch = q.match(/camera[:=]\s*"([^"]+)"|camera[:=]\s*'([^']+)'|camera[:=]\s*([a-z0-9 _-]+)/);
            if (cameraMatch) {
                criteria.camera = (cameraMatch[1] || cameraMatch[2] || cameraMatch[3] || '').trim();
            }
            // Generic camera keyword (e.g., 'iphone')
            if (!criteria.camera && /\\biphone\\b/.test(q)) {
                criteria.camera = 'iphone';
            }

            // Size filters (e.g., ">2mb", "larger than 2mb", "<500kb")
            const sizeTokens = q.match(/([<>]|larger than|bigger than|smaller than|less than)\s*(\d+(?:\.\d+)?)(kb|mb|gb)/);
            if (sizeTokens) {
                const dir = sizeTokens[1];
                const num = parseFloat(sizeTokens[2]);
                const unit = sizeTokens[3];
                let bytes = num;
                if (unit === 'kb') bytes *= 1024;
                if (unit === 'mb') bytes *= 1024 * 1024;
                if (unit === 'gb') bytes *= 1024 * 1024 * 1024;
                if (dir === '<' || dir.includes('smaller') || dir.includes('less')) {
                    criteria.sizeLt = bytes;
                } else {
                    criteria.sizeGt = bytes;
                }
            }

            // Duration filters for video (e.g., ">5 min", "longer than 30s")
            const durTokens = q.match(/([<>]|longer than|shorter than)\s*(\d+(?:\.\d+)?)[\s]*(s|sec|secs|second|seconds|m|min|mins|minute|minutes)/);
            if (durTokens) {
                const dir = durTokens[1];
                const num = parseFloat(durTokens[2]);
                const unit = durTokens[3];
                let seconds = num;
                if (/m/.test(unit)) seconds = num * 60; // treat m/min as minutes
                if (/sec|s/.test(unit)) seconds = num;
                if (dir === '<' || dir.includes('shorter')) {
                    criteria.durationLt = seconds;
                } else {
                    criteria.durationGt = seconds;
                }
            }
            
            // Specific date (supports ordinals)
            const specificDate = q.match(new RegExp(`\\\\b(?:photos?\\\\s+(?:from|on|taken on|taken from)\\\\s+)?(${monthPattern})\\\\s+(\\\\d{1,2})(?:st|nd|rd|th)?(?:\\\\s+((?:19|20)\\\\d{2}))?\\\\b`));
            if (specificDate) {
                const mNum = monthMap[specificDate[1]];
                const dNum = parseInt(specificDate[2], 10);
                const yNum = specificDate[3] ? parseInt(specificDate[3], 10) : null;
                if (yNum) {
                    trySetDateRange(startOfDay(new Date(yNum, mNum, dNum)), endOfDay(new Date(yNum, mNum, dNum)));
                    // also set month/day for safety
                    criteria.monthAnyYear = mNum;
                    criteria.dayOfMonth = dNum;
                } else {
                    criteria.monthAnyYear = mNum;
                    criteria.dayOfMonth = dNum;
                }
            }
            // Fallback simple month-day (no extra wording)
            const mdSimple = q.match(new RegExp(`\\\\b(${monthPattern})\\\\s+(\\\\d{1,2})\\\\b`));
            if (!specificDate && mdSimple) {
                const mNum = monthMap[mdSimple[1]];
                const dNum = parseInt(mdSimple[2], 10);
                criteria.monthAnyYear = mNum;
                criteria.dayOfMonth = dNum;
            }

            // Date range (between/from X and/to Y)
            const rangeMatch = q.match(/\\b(?:between|from)\\s+(.+?)\\s+(?:and|to)\\s+(.+)/);
            if (rangeMatch) {
                const left = parseMonthDayYear(rangeMatch[1]);
                const right = parseMonthDayYear(rangeMatch[2]);
                if (left && right) {
                    monthRangeSet = true;
                    // Clear any prior month-only match so range rules apply cleanly
                    criteria.monthAnyYear = null;
                    criteria.dayOfMonth = null;
                    if (!left.year && !right.year) {
                        if (left.day !== null && right.day !== null) {
                            criteria.monthDayRangeAnyYear = {
                                start: { month: left.month, day: left.day },
                                end: { month: right.month, day: right.day }
                            };
                        } else {
                            criteria.monthRangeAnyYear = {
                                start: left.month,
                                end: right.month
                            };
                        }
                    } else {
                        if (left.year && !right.year) right.year = left.year;
                        if (!left.year && right.year) left.year = right.year;
                        if (!left.year && !right.year) {
                            left.year = now.getFullYear();
                            right.year = now.getFullYear();
                        }
                        if (left.day !== null && right.day !== null) {
                            trySetDateRange(
                                startOfDay(new Date(left.year, left.month, left.day)),
                                endOfDay(new Date(right.year, right.month, right.day))
                            );
                        } else {
                            trySetDateRange(
                                startOfDay(new Date(left.year, left.month, 1)),
                                endOfDay(new Date(right.year, right.month + 1, 0))
                            );
                        }
                    }
                }
            }

            // Year range: 2020-2022 or 2020 to 2022
            const yearRange = q.match(/\\b((?:19|20)\d{2})\s*(?:-|to)\s*((?:19|20)\d{2})\\b/);
            if (yearRange) {
                const startY = parseInt(yearRange[1], 10);
                const endY = parseInt(yearRange[2], 10);
                trySetDateRange(new Date(startY, 0, 1), new Date(endY, 11, 31, 23, 59, 59));
            }

            // Single year
            const yearMatch = q.match(/\\b((?:19|20)\d{2})\\b/);
            if (yearMatch) {
                const y = parseInt(yearMatch[1], 10);
                trySetDateRange(new Date(y, 0, 1), new Date(y, 11, 31, 23, 59, 59));
            }

            // Month + optional year (e.g., "may 2022" or "march") only if no month range already set
            if (!monthRangeSet) {
                Object.keys(monthMap).forEach(mName => {
                    const mRegex = new RegExp("\\\\b" + mName + "(?:\\\\s+(19|20)\\\\d{2})?\\\\b", 'i');
                    const m = q.match(mRegex);
                    if (m) {
                        const monthNum = monthMap[mName];
                        if (m[1]) {
                            const yearVal = parseInt(m[1], 10);
                            trySetDateRange(new Date(yearVal, monthNum, 1), new Date(yearVal, monthNum + 1, 0, 23, 59, 59));
                        } else {
                            criteria.monthAnyYear = monthNum;  // Month-only match across all years
                        }
                    }
                });

                // Fallback month/day without explicit wording
                const mdFallback = parseMonthDayYear(q);
                if (mdFallback && mdFallback.day !== null && mdFallback.year === null) {
                    criteria.monthAnyYear = mdFallback.month;
                    criteria.dayOfMonth = mdFallback.day;
                }
            }

            // Relative dates
            if (/\\btoday\\b/.test(q)) {
                trySetDateRange(startOfDay(now), endOfDay(now));
            }
            if (/\\byesterday\\b/.test(q)) {
                const y = new Date(now);
                y.setDate(now.getDate() - 1);
                trySetDateRange(startOfDay(y), endOfDay(y));
            }
            if (/\\blast week\\b/.test(q)) {
                const start = new Date(now);
                start.setDate(now.getDate() - 7);
                trySetDateRange(startOfDay(start), endOfDay(now));
            }
            if (/\\blast month\\b/.test(q)) {
                const start = new Date(now.getFullYear(), now.getMonth() - 1, 1);
                const end = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59);
                trySetDateRange(start, end);
            }
            if (/\\b(last|past) year\\b/.test(q)) {
                const year = now.getFullYear() - 1;
                trySetDateRange(new Date(year, 0, 1), new Date(year, 11, 31, 23, 59, 59));
            }
            if (/\\bthis year\\b/.test(q)) {
                const year = now.getFullYear();
                trySetDateRange(new Date(year, 0, 1), new Date(year, 11, 31, 23, 59, 59));
            }

            // Rolling ranges: last/past (optional N) days/weeks/months/years
            const lastRange = q.match(/\\b(?:last|past)\\s+((\\d+)|(?:one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve))?\\s*(day|days|week|weeks|month|months|year|years)\\b/);
            if (lastRange) {
                const count = lastRange[2] ? parseInt(lastRange[2], 10) : (lastRange[1] ? numberWords[lastRange[1]] || 0 : 1);
                const unit = lastRange[3];
                if (count > 0) {
                    const start = new Date(now);
                    if (unit.startsWith('day')) {
                        start.setDate(now.getDate() - count);
                    } else if (unit.startsWith('week')) {
                        start.setDate(now.getDate() - count * 7);
                    } else if (unit.startsWith('month')) {
                        start.setMonth(now.getMonth() - count);
                    } else if (unit.startsWith('year')) {
                        start.setFullYear(now.getFullYear() - count);
                    }
                    trySetDateRange(startOfDay(start), endOfDay(now));
                }
            }

            // "N units ago" (e.g., "2 months ago", "from 2 months ago")
            const agoMatch = q.match(/\\b(?:from\\s+)?((\\d+)|(?:one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve))\\s+(day|days|week|weeks|month|months|year|years)\\s+ago\\b/);
            const applyAgoRange = (match) => {
                if (!match) return;
                const count = match[2] ? parseInt(match[2], 10) : (numberWords[match[1]] || 0);
                const unit = match[3];
                if (count > 0) {
                    const anchor = new Date(now);
                    if (unit.startsWith('day')) {
                        anchor.setDate(now.getDate() - count);
                        trySetDateRange(startOfDay(anchor), endOfDay(anchor));
                    } else if (unit.startsWith('week')) {
                        anchor.setDate(now.getDate() - count * 7);
                        trySetDateRange(startOfDay(anchor), endOfDay(anchor));
                    } else if (unit.startsWith('month')) {
                        anchor.setMonth(now.getMonth() - count);
                        const start = new Date(anchor.getFullYear(), anchor.getMonth(), 1);
                        const end = new Date(anchor.getFullYear(), anchor.getMonth() + 1, 0, 23, 59, 59);
                        trySetDateRange(start, end);
                    } else if (unit.startsWith('year')) {
                        anchor.setFullYear(now.getFullYear() - count);
                        const start = new Date(anchor.getFullYear(), 0, 1);
                        const end = new Date(anchor.getFullYear(), 11, 31, 23, 59, 59);
                        trySetDateRange(start, end);
                    }
                }
            };
            if (agoMatch) {
                applyAgoRange(agoMatch);
            } else {
                // Simpler fallback (e.g., "2 months ago" without extra words)
                const agoSimple = q.match(/\\b(\\d+)\\s+(day|days|week|weeks|month|months|year|years)\\s+ago\\b/);
                if (agoSimple) {
                    applyAgoRange([null, agoSimple[1], agoSimple[1], agoSimple[2]]);
                }
            }

            // Terms: keep remaining words that aren't reserved keywords
            const stopWords = new Set([
                'photo','photos','picture','pictures','image','images','pic','pics','video','videos','clip','clips','movie','movies',
                'album','camera','gps','location','with','without','no','has','last','this','year','years','month','months','week','weeks','day','days','today','yesterday',
                'all','in','on','at','by','from','to','for','of','the','a','an','and','between','ago','taken','captured','shot','recorded',
                'larger','bigger','smaller','less','greater','over','under','than','longer','shorter','during',
                'second','seconds','sec','secs','s','minute','minutes','min','mins','m','hour','hours','hr','hrs','duration','time',
                'mile','miles','km','kilometer','kilometers','kilometre','kilometres',
                'kb','mb','gb','size','files','items','please','show','me','only',
                'png','jpg','jpeg','heic','mov','mp4',
                'january','jan','february','feb','march','mar','april','apr','may','june','jun','july','jul','august','aug','september','sept','sep','october','oct','november','nov','december','dec',
                'one','two','three','four','five','six','seven','eight','nine','ten','eleven','twelve'
            ]);
            const measurementToken = /^(?:\d+(?:\.\d+)?)(?:kb|mb|gb|s|sec|secs|second|seconds|m|min|mins|minute|minutes|hr|hrs|hour|hours|mi|mile|miles|km|kilometer|kilometers|kilometre|kilometres)$/;
            q.split(/[\s,]+/).forEach(token => {
                if (!token) return;
                if (stopWords.has(token)) return;
                if (monthMap.hasOwnProperty(token)) return;
                if (/^(19|20)\d{2}$/.test(token)) return;
                if (/^\d+(st|nd|rd|th)$/.test(token)) return;
                if (/^\d+$/.test(token)) return; // likely a year/day; skip as term
                if (measurementToken.test(token)) return;
                if (criteria.camera && token === criteria.camera.toLowerCase()) return;
                if (criteria.album && token === criteria.album.toLowerCase()) return;
                criteria.terms.push(token);
            });

            return criteria;
        }

        // Apply filters
        function applyFilters() {
            currentPage = 1;  // Reset to first page when filters change

            // Re-parse current search box to avoid stale criteria
            const searchInput = document.getElementById('search-input');
            if (searchInput) {
                searchCriteria = parseSearchQuery(searchInput.value);

                // Extra guard: if query mentions common extensions, ensure ext is set
                const rawLower = (searchInput.value || '').toLowerCase();
                if (!searchCriteria.ext) {
                    if (rawLower.includes('png')) searchCriteria.ext = '.png';
                    else if (rawLower.includes('jpg') || rawLower.includes('jpeg')) searchCriteria.ext = '.jpg';
                    else if (rawLower.includes('heic')) searchCriteria.ext = '.heic';
                    else if (rawLower.includes('mov')) searchCriteria.ext = '.mov';
                    else if (rawLower.includes('mp4')) searchCriteria.ext = '.mp4';
                }
            }
            const typeFilter = document.getElementById('filter-type').value;
            const albumFilter = document.getElementById('filter-album')?.value || 'all';
            const cameraFilter = document.getElementById('filter-camera')?.value || 'all';
            const personFilter = document.getElementById('filter-person')?.value || 'all';
            const memoryFilter = document.getElementById('filter-memory')?.value || 'all';
            const favFilter = document.getElementById('filter-favorite')?.value || 'all';
            const orientationFilter = document.getElementById('filter-orientation')?.value || 'all';
            const sizeFilter = document.getElementById('filter-size')?.value || 'all';
            const fromInput = document.getElementById('date-from').value;
            const toInput = document.getElementById('date-to').value;
            const fromDate = fromInput ? parseDateSafe(fromInput + 'T00:00:00') : null;
            const toDate = toInput ? parseDateSafe(toInput + 'T23:59:59') : null;

            // Merge dropdown filters with parsed search criteria
            const effectiveType = typeFilter !== 'all' ? typeFilter : (searchCriteria.type || 'all');
            const effectiveAlbum = albumFilter !== 'all' ? albumFilter : (searchCriteria.album || 'all');
            const effectiveCamera = cameraFilter !== 'all' ? cameraFilter : (searchCriteria.camera || 'all');
            const effectivePerson = personFilter !== 'all' ? personFilter : null;
            const effectiveMemory = memoryFilter !== 'all' ? memoryFilter : null;
            const effectiveFav = favFilter !== 'all' ? favFilter : null;
            const effectiveOrientation = orientationFilter !== 'all' ? orientationFilter : null;
            const effectiveSize = sizeFilter !== 'all' ? sizeFilter : null;
            const effectiveFrom = searchCriteria.dateFrom && (!fromDate || searchCriteria.dateFrom > fromDate)
                ? searchCriteria.dateFrom : fromDate;
            const effectiveTo = searchCriteria.dateTo && (!toDate || searchCriteria.dateTo < toDate)
                ? searchCriteria.dateTo : toDate;

            filteredPhotos = allPhotos.filter(photo => {
                // Type filter
                if (effectiveType !== 'all' && photo.type !== effectiveType) {
                    return false;
                }

                // Album filter
                if (effectiveAlbum !== 'all') {
                    const photoAlbums = photo.albums || [];
                    const target = effectiveAlbum.trim().toLowerCase();
                    const hasAlbum = photoAlbums.some(a => (a || '').toString().trim().toLowerCase() === target);
                    if (!hasAlbum) {
                        return false;
                    }
                }

            // Camera filter
            if (effectiveCamera !== 'all') {
                const cameraLabel = photo.camera
                    ? `${photo.camera.make || ''} ${photo.camera.model || ''}`.trim()
                    : '';
                const camLower = cameraLabel.toLowerCase();
                const effLower = effectiveCamera.toLowerCase();
                if (effectiveCamera === '__unknown__') {
                    if (cameraLabel) return false;
                } else if (cameraFilter !== 'all') {
                    // Dropdown path: exact match
                    if (camLower !== effLower) return false;
                } else {
                    // NL path: allow contains match
                    if (!camLower.includes(effLower)) return false;
                }
            }

            // People filter
            if (effectivePerson) {
                const hasPerson = (photo.people || []).some(p => {
                    const key = (p.uuid && p.uuid.toString().trim()) || (p.id !== undefined ? `id:${p.id}` : null);
                    return key === effectivePerson;
                });
                if (!hasPerson) return false;
            }

            // Memory filter
            if (effectiveMemory) {
                const hasMem = (photo.memories || []).some(m => {
                    const labelRaw = (m.title && m.title.trim()) ? m.title.trim() : `Memory ${m.id}`;
                    return labelRaw.toLowerCase() === effectiveMemory;
                });
                if (!hasMem) return false;
            }

            // Favorites / Hidden filter
            if (effectiveFav) {
                const isFav = !!photo.favorite;
                const isHidden = !!photo.hidden;
                if (effectiveFav === 'fav' && !isFav) return false;
                if (effectiveFav === 'not-fav' && isFav) return false;
                if (effectiveFav === 'hidden' && !isHidden) return false;
                if (effectiveFav === 'not-hidden' && isHidden) return false;
            }

            // Orientation filter
            if (effectiveOrientation) {
                const w = Number(photo.width) || 0;
                const h = Number(photo.height) || 0;
                if (w > 0 && h > 0) {
                    let ori = 'square';
                    if (w > h) ori = 'landscape';
                    else if (h > w) ori = 'portrait';
                    if (ori !== effectiveOrientation) return false;
                }
            }

            // Size buckets filter
            if (effectiveSize) {
                const sz = Number(photo.size) || 0;
                const mb = sz / (1024 * 1024);
                if (effectiveSize === 'lt1' && !(mb < 1)) return false;
                if (effectiveSize === '1to5' && !(mb >= 1 && mb < 5)) return false;
                if (effectiveSize === '5to20' && !(mb >= 5 && mb < 20)) return false;
                if (effectiveSize === 'gt20' && !(mb >= 20)) return false;
            }

            // Date range filter
            if (effectiveFrom || effectiveTo) {
                const photoDate = parseDateSafe(photo.date_taken);
                if (!photoDate) {
                        return false;
                    }
                if (effectiveFrom && photoDate < effectiveFrom) {
                    return false;
                }
                if (effectiveTo && photoDate > effectiveTo) {
                    return false;
                }
            }

            // Location filter
            if (searchCriteria.hasLocation === true && !photo.gps) {
                return false;
            }
            if (searchCriteria.hasLocation === false && photo.gps) {
                return false;
            }

            // Month-only filter (any year)
            if (searchCriteria.monthAnyYear !== null) {
                const photoDate = parseDateSafe(photo.date_taken);
                if (!photoDate || photoDate.getMonth() !== searchCriteria.monthAnyYear) {
                    return false;
                }
                if (searchCriteria.dayOfMonth !== null && photoDate.getDate() !== searchCriteria.dayOfMonth) {
                    return false;
                }
            }

            // Month-only range (any year)
            if (searchCriteria.monthRangeAnyYear) {
                const photoDate = parseDateSafe(photo.date_taken);
                if (!photoDate) return false;
                const m = photoDate.getMonth();
                const startM = searchCriteria.monthRangeAnyYear.start;
                const endM = searchCriteria.monthRangeAnyYear.end;
                const inRange = startM <= endM ? (m >= startM && m <= endM) : (m >= startM || m <= endM);
                if (!inRange) return false;
            }

            // Month+day range (any year)
            if (searchCriteria.monthDayRangeAnyYear) {
                const photoDate = parseDateSafe(photo.date_taken);
                if (!photoDate) return false;
                const val = photoDate.getMonth() * 31 + photoDate.getDate();
                const startVal = searchCriteria.monthDayRangeAnyYear.start.month * 31 + searchCriteria.monthDayRangeAnyYear.start.day;
                const endVal = searchCriteria.monthDayRangeAnyYear.end.month * 31 + searchCriteria.monthDayRangeAnyYear.end.day;
                const inRange = startVal <= endVal ? (val >= startVal && val <= endVal) : (val >= startVal || val <= endVal);
                if (!inRange) return false;
            }

            // Size filters
            if (searchCriteria.sizeGt !== null) {
                const sz = Number(photo.size) || 0;
                if (sz <= searchCriteria.sizeGt) return false;
            }
            if (searchCriteria.sizeLt !== null) {
                const sz = Number(photo.size) || 0;
                if (sz >= searchCriteria.sizeLt) return false;
            }

            // Duration filters (videos)
            if (photo.type === 'video') {
                if (searchCriteria.durationGt !== null) {
                    const dur = Number(photo.duration) || 0;
                    if (dur <= searchCriteria.durationGt) return false;
                }
                if (searchCriteria.durationLt !== null) {
                    const dur = Number(photo.duration) || 0;
                    if (dur >= searchCriteria.durationLt) return false;
                }
            }

            // Extension filter
            if (searchCriteria.ext) {
                const ext = searchCriteria.ext.toLowerCase();
                const fname = (photo.filename || '').toLowerCase();
                const ppath = (photo.path || '').toLowerCase();
                // Support "png pictures only" etc. by checking both filename and path, lowercase
                if (!fname.endsWith(ext) && !ppath.endsWith(ext)) {
                    return false;
                }
            }

                // Text terms across filename, albums, camera label
                if (searchCriteria.terms && searchCriteria.terms.length > 0) {
                    const filename = (photo.filename || '').toLowerCase();
                    const albums = (photo.albums || []).map(a => (a || '').toString().toLowerCase());
                    const cameraLabel = photo.camera
                        ? `${photo.camera.make || ''} ${photo.camera.model || ''}`.trim().toLowerCase()
                        : '';

                    const matchesAll = searchCriteria.terms.every(term => {
                        return filename.includes(term)
                            || albums.some(a => a.includes(term))
                            || cameraLabel.includes(term);
                    });

                    if (!matchesAll) return false;
                }

                return true;
            });

            applySorting();
            updateFilterCount();
        }

        // Apply sorting
        function applySorting() {
            const sortBy = document.getElementById('sort-by').value;

            filteredPhotos.sort((a, b) => {
                switch (sortBy) {
                    case 'date-desc':
                        return new Date(b.date_taken) - new Date(a.date_taken);
                    case 'date-asc':
                        return new Date(a.date_taken) - new Date(b.date_taken);
                    case 'name-asc':
                        return a.filename.localeCompare(b.filename);
                    case 'name-desc':
                        return b.filename.localeCompare(a.filename);
                    case 'size-desc':
                        return (b.size || 0) - (a.size || 0);
                    case 'size-asc':
                        return (a.size || 0) - (b.size || 0);
                    default:
                        return 0;
                }
            });

            renderCurrentView();

            // Update visible count
            updateResultCount();
            updateFilterCount();
        }

        // Update result count near the search box
        function updateResultCount() {
            const el = document.getElementById('results-count');
            const input = document.getElementById('search-input');
            if (!el || !input) return;
            const queryText = input.value && input.value.trim() ? input.value.trim() : 'All items';
            el.textContent = `${queryText} - Found ${filteredPhotos.length}`;
        }

        function updateFilterCount() {
            let count = 0;
            const checkSelect = (id, defVal = 'all') => {
                const el = document.getElementById(id);
                if (el && el.value && el.value !== defVal) count++;
            };
            const dateFrom = document.getElementById('date-from')?.value;
            const dateTo = document.getElementById('date-to')?.value;
            if (dateFrom) count++;
            if (dateTo) count++;

            checkSelect('filter-album');
            checkSelect('filter-type');
            checkSelect('filter-camera');
            checkSelect('filter-person');
            checkSelect('filter-memory');
            checkSelect('filter-favorite');
            checkSelect('filter-orientation');
            checkSelect('filter-size');

            activeFilterCount = count;

            const countSpan = document.getElementById('filter-count');
            if (countSpan) {
                countSpan.textContent = count > 0 ? `(${count})` : '';
            }
            const clearBtn = document.getElementById('clear-filters-btn');
            if (clearBtn) {
                clearBtn.style.visibility = count > 0 ? 'visible' : 'hidden';
            }
        }

        // Debounced search handling
        let searchDebounceTimer = null;
        function handleSearch() {
            if (searchDebounceTimer) {
                clearTimeout(searchDebounceTimer);
            }
            searchDebounceTimer = setTimeout(() => {
                currentPage = 1;  // Reset to first page when search changes
                const raw = document.getElementById('search-input').value;
            searchCriteria = parseSearchQuery(raw);
            applyFilters();
            updateResultCount();
            updateFilterCount();
        }, 200);  // debounce delay (ms)
    }

    // Clear date range filter
        function clearDateFilter() {
            const fromInput = document.getElementById('date-from');
            const toInput = document.getElementById('date-to');
            if (fromInput) fromInput.value = '';
            if (toInput) toInput.value = '';
            applyFilters();
            updateFilterCount();
        }

        // Clear all filter dropdowns and date inputs
        function clearAllFilters() {
            const selects = [
                { id: 'filter-album', val: 'all' },
                { id: 'filter-type', val: 'all' },
                { id: 'filter-camera', val: 'all' },
                { id: 'filter-person', val: 'all' },
                { id: 'filter-memory', val: 'all' },
                { id: 'filter-favorite', val: 'all' },
                { id: 'filter-orientation', val: 'all' },
                { id: 'filter-size', val: 'all' }
            ];
            selects.forEach(({ id, val }) => {
                const el = document.getElementById(id);
                if (el) el.value = val;
            });
            // Clear dates
            const fromInput = document.getElementById('date-from');
            const toInput = document.getElementById('date-to');
            if (fromInput) fromInput.value = '';
            if (toInput) toInput.value = '';
            applyFilters();
            updateFilterCount();
        }

        // Open photo modal
        function openModal(index) {
            currentPhotoIndex = index;
            const photo = filteredPhotos[index];  // FIX: Use filteredPhotos, not allPhotos

            const modal = document.getElementById('photo-modal');
            const title = document.getElementById('modal-title');
            const preview = document.getElementById('modal-preview');
            const metadata = document.getElementById('modal-metadata');

            title.textContent = photo.filename;

            // Preview
            if (photo.type === 'video') {
                preview.innerHTML = `
                    <video controls>
                        <source src="${photo.path}" type="video/mp4">
                        Your browser does not support video playback.
                    </video>
                `;
            } else {
                preview.innerHTML = `<img src="${photo.path}" alt="${photo.filename}">`;
            }

            // Metadata
            const resolution = photo.width && photo.height ?
                `${photo.width} × ${photo.height} (${(photo.width * photo.height / 1000000).toFixed(1)} MP)` : 'N/A';
            const size = photo.size ? formatFileSize(photo.size) : 'N/A';
            const camera = photo.camera ?
                `${photo.camera.make || ''} ${photo.camera.model || ''}`.trim() : 'Unknown';

            let metadataHTML = `
                <div class="metadata-section">
                    <h3>📄 Basic Info</h3>
                    <div class="metadata-item"><strong>Filename:</strong> ${photo.filename}</div>
                    <div class="metadata-item"><strong>Type:</strong> ${photo.type === 'video' ? 'Video' : 'Photo'}</div>
                    <div class="metadata-item"><strong>Size:</strong> ${size}</div>
                    <div class="metadata-item"><strong>Resolution:</strong> ${resolution}</div>
                </div>

                <div class="metadata-section">
                    <h3>📅 Date & Time</h3>
                    <div class="metadata-item"><strong>Date Taken:</strong> ${formatDate(photo.date_taken)}</div>
                </div>
            `;

            if (photo.camera) {
                metadataHTML += `
                    <div class="metadata-section">
                        <h3>📷 Camera</h3>
                        <div class="metadata-item"><strong>Device:</strong> ${camera}</div>
                        ${photo.camera.iso ? `<div class="metadata-item"><strong>ISO:</strong> ${photo.camera.iso}</div>` : ''}
                        ${photo.camera.aperture ? `<div class="metadata-item"><strong>Aperture:</strong> f/${photo.camera.aperture}</div>` : ''}
                        ${photo.camera.shutter_speed ? `<div class="metadata-item"><strong>Shutter:</strong> ${photo.camera.shutter_speed}</div>` : ''}
                    </div>
                `;
            }

            if (photo.gps) {
                metadataHTML += `
                    <div class="metadata-section">
                        <h3>📍 Location</h3>
                        <div class="metadata-item"><strong>Latitude:</strong> ${photo.gps.lat.toFixed(6)}°</div>
                        <div class="metadata-item"><strong>Longitude:</strong> ${photo.gps.lon.toFixed(6)}°</div>
                        <div class="metadata-item">
                            <a href="https://www.google.com/maps?q=${photo.gps.lat},${photo.gps.lon}"
                               target="_blank" style="color: #667eea;">View on Google Maps →</a>
                        </div>
                    </div>
                `;
            }

            if (photo.albums && photo.albums.length > 0) {
                const albumsList = photo.albums.map(album => `<span class="album-badge">${album}</span>`).join(' ');
                metadataHTML += `
                    <div class="metadata-section">
                        <h3>📁 Albums</h3>
                        <div class="metadata-item">${albumsList}</div>
                    </div>
                `;
            }

            metadata.innerHTML = metadataHTML;

            // Update nav buttons (FIX: Use filteredPhotos.length)
            document.getElementById('modal-prev').disabled = index === 0;
            document.getElementById('modal-next').disabled = index === filteredPhotos.length - 1;

            modal.classList.add('active');
        }

        // Close modal
        function closeModal() {
            document.getElementById('photo-modal').classList.remove('active');
        }

        // Close modal on backdrop click
        function closeModalOnBackdrop(event) {
            if (event.target.id === 'photo-modal') {
                closeModal();
            }
        }

        // Navigate modal (previous/next)
        function navigateModal(direction) {
            const newIndex = currentPhotoIndex + direction;
            if (newIndex >= 0 && newIndex < filteredPhotos.length) {  // FIX: Use filteredPhotos.length
                openModal(newIndex);
            }
        }

        // Keyboard navigation
        document.addEventListener('keydown', function(e) {
            if (document.getElementById('photo-modal').classList.contains('active')) {
                if (e.key === 'Escape') {
                    closeModal();
                } else if (e.key === 'ArrowLeft') {
                    navigateModal(-1);
                } else if (e.key === 'ArrowRight') {
                    navigateModal(1);
                }
            }
        });

        // Pagination functions
        function changePage(delta) {
            const newPage = currentPage + delta;
            if (newPage >= 1 && newPage <= totalPages) {
                currentPage = newPage;
                renderCurrentView();
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        }

        function goToPage(page) {
            if (page >= 1 && page <= totalPages) {
                currentPage = page;
                renderCurrentView();
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        }

        function renderPaginationControls() {
            // Only show pagination if more than itemsPerPage items
            if (filteredPhotos.length <= itemsPerPage) {
                // No pagination needed
                const container = document.getElementById('grid-container');
                const existingPagination = container.querySelector('.pagination-controls');
                if (existingPagination) {
                    existingPagination.remove();
                }
                return;
            }

            const container = document.getElementById('grid-container');
            let paginationDiv = container.querySelector('.pagination-controls');

            if (!paginationDiv) {
                paginationDiv = document.createElement('div');
                paginationDiv.className = 'pagination-controls';
                container.appendChild(paginationDiv);
            }

            const startItem = (currentPage - 1) * itemsPerPage + 1;
            const endItem = Math.min(currentPage * itemsPerPage, filteredPhotos.length);

            paginationDiv.innerHTML = `
                <div class="pagination-info">
                    Showing ${startItem}-${endItem} of ${filteredPhotos.length} items
                    (Page ${currentPage} of ${totalPages})
                </div>
                <div class="pagination-buttons">
                    <button onclick="goToPage(1)" ${currentPage === 1 ? 'disabled' : ''}>« First</button>
                    <button onclick="changePage(-1)" ${currentPage === 1 ? 'disabled' : ''}>‹ Prev</button>
                    <button onclick="changePage(1)" ${currentPage === totalPages ? 'disabled' : ''}>Next ›</button>
                    <button onclick="goToPage(${totalPages})" ${currentPage === totalPages ? 'disabled' : ''}>Last »</button>
                </div>
            `;
        }

        // Utility functions
        function formatDate(dateStr) {
            if (!dateStr) return 'Unknown';
            try {
                const date = new Date(dateStr);
                return date.toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                });
            } catch {
                return dateStr;
            }
        }

        function formatTimeOnly(dateStr) {
            if (!dateStr) return '';
            try {
                const date = new Date(dateStr);
                return date.toLocaleTimeString('en-US', {
                    hour: '2-digit',
                    minute: '2-digit'
                });
            } catch {
                return '';
            }
        }

        // Timeline view rendering
        function renderTimelineView() {
            const container = document.getElementById('timeline-container');
            container.innerHTML = '';

            if (filteredPhotos.length === 0) {
                container.innerHTML = `
                    <div class="empty-state">
                        <h3>No photos found</h3>
                        <p>Try adjusting your filters or search</p>
                    </div>
                `;
                return;
            }

            const groups = groupPhotosByDate(filteredPhotos);

            const years = Object.values(groups).sort((a, b) => b.sortValue - a.sortValue);

            years.forEach(yearGroup => {
                const yearBlock = document.createElement('div');
                yearBlock.className = 'timeline-year';

                const yearTitle = document.createElement('h2');
                yearTitle.textContent = yearGroup.label;
                yearBlock.appendChild(yearTitle);

                const months = Object.values(yearGroup.months).sort((a, b) => b.sortValue - a.sortValue);

                months.forEach(monthGroup => {
                    const monthBlock = document.createElement('div');
                    monthBlock.className = 'timeline-month';

                    const monthHeader = document.createElement('div');
                    monthHeader.className = 'timeline-month-header';
                    monthHeader.textContent = monthGroup.label;
                    monthBlock.appendChild(monthHeader);

                    const days = Object.values(monthGroup.days).sort((a, b) => b.sortValue - a.sortValue);

                    days.forEach(dayGroup => {
                        const dayBlock = document.createElement('div');
                        dayBlock.className = 'timeline-day';

                        const header = document.createElement('div');
                        header.className = 'timeline-day-header';
                        const countLabel = document.createElement('span');
                        countLabel.className = 'count';
                        countLabel.textContent = `${dayGroup.photos.length} item${dayGroup.photos.length === 1 ? '' : 's'}`;
                        header.innerHTML = `<span>${dayGroup.label}</span>`;
                        header.appendChild(countLabel);
                        dayBlock.appendChild(header);

                        const grid = document.createElement('div');
                        grid.className = 'timeline-day-grid';

                        dayGroup.photos.forEach(photo => {
                            const idx = filteredPhotos.indexOf(photo);
                            const card = document.createElement('div');
                            card.className = 'timeline-photo';
                            card.onclick = () => openModal(idx);
                            const timeText = formatTimeOnly(photo.date_taken);
                            card.innerHTML = `
                                <img class="lazy" data-src="${photo.thumbnail}" alt="${photo.filename}">
                                <div class="thumb-info">
                                    <div class="name" title="${photo.filename}">${photo.filename}</div>
                                    <div class="time">${timeText}</div>
                                </div>
                            `;
                            grid.appendChild(card);
                        });

                        dayBlock.appendChild(grid);
                        monthBlock.appendChild(dayBlock);
                    });

                    yearBlock.appendChild(monthBlock);
                });

                container.appendChild(yearBlock);
            });

            setupLazyLoading();
        }

        function groupPhotosByDate(photos) {
            const result = {};

            photos.forEach(photo => {
                let date = null;
                if (photo.date_taken) {
                    const parsed = new Date(photo.date_taken);
                    if (!isNaN(parsed)) {
                        date = parsed;
                    }
                }

                const hasDate = !!date;
                const yearVal = hasDate ? date.getFullYear() : null;
                const yearKey = hasDate ? String(yearVal) : 'Unknown';
                const monthIndex = hasDate ? date.getMonth() : -1;
                const monthLabel = hasDate ? `${date.toLocaleString('en-US', { month: 'long' })} ${yearKey}` : 'Unknown Month';
                const monthKey = hasDate ? `${yearKey}-${String(monthIndex + 1).padStart(2, '0')}` : 'Unknown';
                const dayLabel = hasDate ? date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : 'Unknown Day';
                const dayKey = hasDate ? date.toISOString().slice(0, 10) : 'Unknown';
                const daySort = hasDate ? new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime() : -Infinity;
                const monthSort = hasDate ? new Date(date.getFullYear(), date.getMonth(), 1).getTime() : -Infinity;
                const yearSort = hasDate ? yearVal : -Infinity;

                if (!result[yearKey]) {
                    result[yearKey] = {
                        label: hasDate ? yearKey : 'Unknown Date',
                        sortValue: yearSort,
                        months: {}
                    };
                }

                if (!result[yearKey].months[monthKey]) {
                    result[yearKey].months[monthKey] = {
                        label: monthLabel,
                        sortValue: monthSort,
                        days: {}
                    };
                }

                if (!result[yearKey].months[monthKey].days[dayKey]) {
                    result[yearKey].months[monthKey].days[dayKey] = {
                        label: dayLabel,
                        sortValue: daySort,
                        photos: []
                    };
                }

                result[yearKey].months[monthKey].days[dayKey].photos.push(photo);
            });

            return result;
        }

        function formatFileSize(bytes) {
            if (bytes === 0) return '0 B';
            const k = 1024;
            const sizes = ['B', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
        }

        function showError(message) {
            console.error(message);
            alert(message);
        }
    </script>
</body>
</html>"""

        # Inject dynamic values (explicit placeholder replacement avoids f-string brace escaping issues)
        template = template.replace("__TOTAL_ITEMS__", f"{total_items:,}")
        template = template.replace("__PHOTO_COUNT__", f"{photo_count:,}")
        template = template.replace("__VIDEO_COUNT__", f"{video_count:,}")
        template = template.replace("__GPS_COUNT__", f"{gps_count:,}")
        template = template.replace("__METADATA_JSON__", metadata_json)
        template = template.replace("__ALBUMS_JSON__", albums_json)
        return template

    def _attach_people_and_memories(self, items: List[Dict[str, Any]]) -> None:
        """
        Enrich exported items with people/pet and memory membership info from Photos.sqlite.

        This runs a single pass over Photos.sqlite to avoid repeated queries.
        """
        if not items:
            return

        # Map asset_id -> item
        asset_to_item: Dict[int, Dict[str, Any]] = {}
        for it in items:
            asset_id = self._safe_asset_id(it.get('item_data', {}))
            if asset_id is not None:
                asset_to_item[asset_id] = it

        if not asset_to_item:
            return

        conn = sqlite3.connect(self.photos_db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        # Build person lookup (id -> info)
        people_lookup: Dict[int, Dict[str, Any]] = {}
        try:
            for row in cur.execute("""
                SELECT Z_PK, ZDISPLAYNAME, ZFULLNAME, ZPERSONUUID,
                       ZTYPE, ZAGETYPE, ZDETECTIONTYPE, ZGENDERTYPE
                FROM ZPERSON
            """):
                name = (row["ZDISPLAYNAME"] or row["ZFULLNAME"] or "").strip()
                if not name:
                    name = f"Person {row['Z_PK']}"
                people_lookup[row["Z_PK"]] = {
                    "id": row["Z_PK"],
                    "name": name,
                    "uuid": row["ZPERSONUUID"],
                    "type": row["ZTYPE"],
                    "agetype": row["ZAGETYPE"],
                    "detection_type": row["ZDETECTIONTYPE"],
                    "gender_type": row["ZGENDERTYPE"],
                }
        except Exception as e:
            print(f"[WARNING] Failed to read people metadata: {e}")

        # Map assets to people
        try:
            for row in cur.execute("""
                SELECT ZASSETFORFACE AS asset_id, ZPERSONFORFACE AS person_id
                FROM ZDETECTEDFACE
                WHERE ZASSETFORFACE IS NOT NULL AND ZPERSONFORFACE IS NOT NULL
            """):
                asset_id = row["asset_id"]
                person_id = row["person_id"]
                if asset_id in asset_to_item and person_id in people_lookup:
                    item = asset_to_item[asset_id]
                    people_list = item.setdefault("people", [])
                    people_list.append(people_lookup[person_id])
        except Exception as e:
            print(f"[WARNING] Failed to map faces to people: {e}")

        # Map favorites/hidden flags
        try:
            for row in cur.execute("""
                SELECT Z_PK, ZFAVORITE, ZHIDDEN
                FROM ZASSET
            """):
                asset_id = row["Z_PK"]
                if asset_id in asset_to_item:
                    asset_to_item[asset_id]["favorite"] = bool(row["ZFAVORITE"])
                    asset_to_item[asset_id]["hidden"] = bool(row["ZHIDDEN"])
        except Exception as e:
            print(f"[WARNING] Failed to read favorites/hidden: {e}")

        # Map assets to memories (if join table exists)
        try:
            cur.execute("""
                SELECT name FROM sqlite_master
                WHERE type='table' AND name='Z_3MEMORIESBEINGCURATEDASSETS'
            """)
            if cur.fetchone():
                for row in cur.execute("""
                    SELECT
                        j.Z_3CURATEDASSETS AS asset_id,
                        m.Z_PK AS memory_id,
                        m.ZTITLE AS title,
                        m.ZCATEGORY AS category,
                        m.ZSUBCATEGORY AS subcategory,
                        m.ZSTARTDATE AS start_date,
                        m.ZENDDATE AS end_date
                    FROM Z_3MEMORIESBEINGCURATEDASSETS j
                    JOIN ZMEMORY m ON m.Z_PK = j.Z_51MEMORIESBEINGCURATEDASSETS
                """):
                    asset_id = row["asset_id"]
                    if asset_id in asset_to_item:
                        mem_list = asset_to_item[asset_id].setdefault("memories", [])
                        mem_list.append({
                            "id": row["memory_id"],
                            "title": row["title"],
                            "category": row["category"],
                            "subcategory": row["subcategory"],
                            "start_date": row["start_date"],
                            "end_date": row["end_date"],
                        })
        except Exception as e:
            print(f"[WARNING] Failed to map memories: {e}")
        finally:
            conn.close()

        enriched_count = sum(1 for it in items if it.get("people") or it.get("memories") or it.get("favorite") is not None or it.get("hidden") is not None)
        print(f"[INFO] Enriched items with people/memories/fav/hidden: {enriched_count}/{len(items)}")

    @staticmethod
    def _safe_asset_id(item_data: Dict[str, Any]) -> Optional[int]:
        """
        Normalize asset id from item_data (handles str/int).
        """
        raw = item_data.get('Z_PK') or item_data.get('z_pk')
        if raw is None:
            return None
        try:
            return int(raw)
        except (ValueError, TypeError):
            return None
