#!/usr/bin/env python3
"""
Significant Locations (shared locations) extractor for iOS backups.

Aggregates user-shared location messages from supported apps and builds
an interactive map report (Leaflet) plus JSON export.
"""

import os
import sqlite3
import shutil
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from .base import CategoryDataExtractor

try:
    from PIL import Image, ImageOps
    PIL_AVAILABLE = True
except Exception:
    PIL_AVAILABLE = False
try:
    import pillow_heif
    HEIF_AVAILABLE = True
except Exception:
    HEIF_AVAILABLE = False

class SignificantLocationsExtractor(CategoryDataExtractor):
    """Aggregate shared locations from multiple app databases."""

    _APPLE_EPOCH = datetime(2001, 1, 1)
    _heif_registered = False

    def __init__(self, backup_path: str):
        super().__init__(backup_path)
        self._cached_items: Optional[List[Dict[str, Any]]] = None
        if not self._load_items():
            raise FileNotFoundError("Significant locations data not found in backup")

    def _normalize_apple_timestamp(self, value: Any) -> Optional[int]:
        try:
            ts = float(value)
        except Exception:
            return None
        if ts <= 0:
            return None
        return int((self._APPLE_EPOCH + timedelta(seconds=ts)).timestamp())

    def _normalize_timestamp_guess(self, value: Any) -> Optional[int]:
        try:
            ts = float(value)
        except Exception:
            return None
        if ts <= 0:
            return None
        if ts > 1e12:
            return int(ts / 1000)
        if ts > 1e10:
            return int(ts)
        if ts > 1e9:
            return int(ts)
        if ts > 1e6:
            return self._normalize_apple_timestamp(ts)
        return None

    def _normalize_line_timestamp(self, value: Any) -> Optional[int]:
        try:
            ts = float(value)
        except Exception:
            return None
        if ts <= 0:
            return None
        if ts > 1e12:
            return int(ts / 1000)
        if ts > 1e10:
            return int(ts)
        if ts > 1e6:
            return int((self._APPLE_EPOCH + timedelta(seconds=ts)).timestamp())
        return None

    def _valid_latlon(self, lat: Any, lon: Any) -> bool:
        try:
            lat_f = float(lat)
            lon_f = float(lon)
        except Exception:
            return False
        if lat_f == 0.0 and lon_f == 0.0:
            return False
        return -90.0 <= lat_f <= 90.0 and -180.0 <= lon_f <= 180.0

    def _is_lat_column(self, name: str) -> bool:
        name_l = name.lower()
        if name_l in ("lat", "latitude", "zlatitude"):
            return True
        if name_l.endswith("_lat") or name_l.endswith("_latitude"):
            return True
        if name_l.endswith("latitude"):
            return True
        return False

    def _is_lon_column(self, name: str) -> bool:
        name_l = name.lower()
        if name_l in ("lon", "lng", "long", "longitude", "zlongitude"):
            return True
        if name_l.endswith("_lon") or name_l.endswith("_lng") or name_l.endswith("_longitude"):
            return True
        if name_l.endswith("longitude"):
            return True
        return False

    def _quote_identifier(self, name: str) -> str:
        return '"' + name.replace('"', '""') + '"'

    def _pick_column(self, columns: List[str], candidates: List[str]) -> Optional[str]:
        if not columns:
            return None
        columns_lower = {col.lower(): col for col in columns}
        for key in candidates:
            if key in columns_lower:
                return columns_lower[key]
        for col in columns:
            col_l = col.lower()
            for key in candidates:
                if key in col_l:
                    return col
        return None

    def _scan_db_for_latlon_tables(self, db_path: str, source_app: str) -> List[Dict[str, Any]]:
        items: List[Dict[str, Any]] = []
        if not db_path or not os.path.exists(db_path):
            return items

        try:
            conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = [row[0] for row in cur.fetchall()]
        except Exception:
            try:
                conn.close()
            except Exception:
                pass
            return items

        for table in tables:
            try:
                cur.execute(f"PRAGMA table_info({self._quote_identifier(table)})")
                columns = [row[1] for row in cur.fetchall()]
            except Exception:
                continue

            lat_col = next((col for col in columns if self._is_lat_column(col)), None)
            lon_col = next((col for col in columns if self._is_lon_column(col)), None)
            if not lat_col or not lon_col:
                continue

            ts_col = self._pick_column(
                columns,
                ["timestamp_ms", "timestamp", "time", "date", "created_at", "sent_at", "server_timestamp", "ts"]
            )
            msg_col = self._pick_column(
                columns,
                ["text", "message", "body", "content", "payload", "address", "location_name", "title", "name"]
            )
            conv_col = self._pick_column(
                columns,
                ["thread_name", "thread_id", "conversation", "chat_name", "chat_id", "room_name"]
            )

            select_cols = [
                f"{self._quote_identifier(lat_col)} AS lat",
                f"{self._quote_identifier(lon_col)} AS lon",
            ]
            if ts_col:
                select_cols.append(f"{self._quote_identifier(ts_col)} AS ts")
            if msg_col:
                select_cols.append(f"{self._quote_identifier(msg_col)} AS message")
            if conv_col:
                select_cols.append(f"{self._quote_identifier(conv_col)} AS conversation")

            query = (
                f"SELECT {', '.join(select_cols)} "
                f"FROM {self._quote_identifier(table)} "
                f"WHERE {self._quote_identifier(lat_col)} IS NOT NULL "
                f"AND {self._quote_identifier(lon_col)} IS NOT NULL"
            )

            try:
                cur.execute(query)
                rows = cur.fetchall()
            except Exception:
                continue

            for row in rows:
                lat = row["lat"]
                lon = row["lon"]
                if not self._valid_latlon(lat, lon):
                    continue
                ts = self._normalize_timestamp_guess(row["ts"]) if "ts" in row.keys() else None
                message = row["message"] if "message" in row.keys() else None
                if isinstance(message, (bytes, bytearray)):
                    message = None
                conversation = row["conversation"] if "conversation" in row.keys() else None
                if conversation is None:
                    conversation = f"{source_app} {table}"
                items.append({
                    "source_app": source_app,
                    "conversation": conversation,
                    "timestamp": ts,
                    "lat": float(lat),
                    "lon": float(lon),
                    "message": message or "",
                    "source_detail": f"{os.path.basename(db_path)}:{table}",
                    "message_id": None,
                })

        try:
            conn.close()
        except Exception:
            pass

        return items

    def _extract_latlon_from_archive(self, archive: Any) -> Optional[Dict[str, float]]:
        if archive is None:
            return None
        stack = [archive]
        visited = set()
        while stack:
            obj = stack.pop()
            obj_id = id(obj)
            if obj_id in visited:
                continue
            visited.add(obj_id)

            if isinstance(obj, dict):
                lat = None
                lon = None
                for key, value in obj.items():
                    key_l = str(key).lower()
                    if self._is_lat_column(key_l) or key_l.endswith("latitude"):
                        lat = value
                    if self._is_lon_column(key_l) or key_l.endswith("longitude"):
                        lon = value
                if lat is not None and lon is not None and self._valid_latlon(lat, lon):
                    return {"lat": float(lat), "lon": float(lon)}
                stack.extend(obj.values())
            elif isinstance(obj, (list, tuple, set)):
                stack.extend(list(obj))
        return None

    def _load_whatsapp_locations(self) -> List[Dict[str, Any]]:
        items = []
        domain = "AppDomainGroup-group.net.whatsapp.WhatsApp.shared"
        db_path = self.backup_access.get_file_path(domain, "ChatStorage.sqlite")
        if not db_path or not os.path.exists(db_path):
            return items

        try:
            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            query = """
                SELECT
                    media.ZLATITUDE as lat,
                    media.ZLONGITUDE as lon,
                    msg.ZMESSAGEDATE as msg_date,
                    msg.ZTEXT as msg_text,
                    msg.Z_PK as msg_id,
                    chat.ZPARTNERNAME as chat_name,
                    chat.ZCONTACTJID as chat_jid
                FROM ZWAMEDIAITEM media
                LEFT JOIN ZWAMESSAGE msg ON media.ZMESSAGE = msg.Z_PK
                LEFT JOIN ZWACHATSESSION chat ON msg.ZCHATSESSION = chat.Z_PK
                WHERE media.ZLATITUDE IS NOT NULL
                  AND media.ZLONGITUDE IS NOT NULL
            """
            cur.execute(query)
            rows = cur.fetchall()
        except Exception:
            return items
        finally:
            try:
                conn.close()
            except Exception:
                pass

        for row in rows:
            lat = row["lat"]
            lon = row["lon"]
            if not self._valid_latlon(lat, lon):
                continue
            ts = self._normalize_apple_timestamp(row["msg_date"])
            items.append({
                "source_app": "WhatsApp",
                "conversation": row["chat_name"] or row["chat_jid"] or "WhatsApp",
                "timestamp": ts,
                "lat": float(lat),
                "lon": float(lon),
                "message": row["msg_text"] or "",
                "source_detail": "ZWAMEDIAITEM",
                "message_id": row["msg_id"],
            })

        return items

    def _find_viber_db(self) -> Optional[str]:
        domain = "AppDomainGroup-group.viber.share.container"
        rel = "com.viber/database/Contacts.data"
        path = self.backup_access.get_file_path(domain, rel)
        if path and os.path.exists(path):
            return path

        try:
            conn = sqlite3.connect(f"file:{self.manifest_db_path}?mode=ro", uri=True)
            cur = conn.cursor()
            cur.execute("""
                SELECT fileID
                FROM Files
                WHERE relativePath LIKE '%Contacts.data'
                  AND (domain LIKE 'AppDomain-com.viber%' OR domain LIKE 'AppDomainGroup-group.viber%')
                ORDER BY domain, relativePath
                LIMIT 1
            """)
            row = cur.fetchone()
            if row:
                return self._resolve_file_id_path(row[0])
        except Exception:
            return None
        finally:
            try:
                conn.close()
            except Exception:
                pass
        return None

    def _load_viber_locations(self) -> List[Dict[str, Any]]:
        items = []
        db_path = self._find_viber_db()
        if not db_path or not os.path.exists(db_path):
            return items

        try:
            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            query = """
                SELECT
                    loc.ZLATITUDE as lat,
                    loc.ZLONGITUDE as lon,
                    loc.ZDATE as loc_date,
                    loc.ZADDRESS as address,
                    msg.ZTEXT as msg_text,
                    msg.Z_PK as msg_id,
                    conv.ZNAME as conv_name
                FROM ZVIBERLOCATION loc
                LEFT JOIN ZVIBERMESSAGE msg ON loc.ZMESSAGE = msg.Z_PK
                LEFT JOIN ZCONVERSATION conv ON msg.ZCONVERSATION = conv.Z_PK
                WHERE loc.ZLATITUDE IS NOT NULL
                  AND loc.ZLONGITUDE IS NOT NULL
            """
            cur.execute(query)
            rows = cur.fetchall()
        except Exception:
            return items
        finally:
            try:
                conn.close()
            except Exception:
                pass

        for row in rows:
            lat = row["lat"]
            lon = row["lon"]
            if not self._valid_latlon(lat, lon):
                continue
            ts = self._normalize_apple_timestamp(row["loc_date"])
            items.append({
                "source_app": "Viber",
                "conversation": row["conv_name"] or "Viber",
                "timestamp": ts,
                "lat": float(lat),
                "lon": float(lon),
                "message": row["msg_text"] or row["address"] or "",
                "source_detail": "ZVIBERLOCATION",
                "message_id": row["msg_id"],
            })

        return items

    def _load_line_locations(self) -> List[Dict[str, Any]]:
        items = []
        domain = "AppDomainGroup-group.com.linecorp.line"
        try:
            conn = sqlite3.connect(f"file:{self.manifest_db_path}?mode=ro", uri=True)
            cur = conn.cursor()
            cur.execute("""
                SELECT fileID, relativePath
                FROM Files
                WHERE domain = ?
                  AND relativePath LIKE '%/Messages/Line.sqlite'
                ORDER BY relativePath
                LIMIT 1
            """, (domain,))
            row = cur.fetchone()
        except Exception:
            return items
        finally:
            try:
                conn.close()
            except Exception:
                pass
        if not row:
            return items
        db_path = self._resolve_file_id_path(row[0])
        if not db_path or not os.path.exists(db_path):
            return items

        try:
            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            query = """
                SELECT
                    m.ZLATITUDE as lat,
                    m.ZLONGITUDE as lon,
                    m.ZTIMESTAMP as ts,
                    m.ZTEXT as msg_text,
                    c.ZNAME as conv_name,
                    m.Z_PK as msg_id
                FROM ZMESSAGE m
                LEFT JOIN ZCHAT c ON m.ZCHAT = c.Z_PK
                WHERE m.ZLATITUDE IS NOT NULL
                  AND m.ZLONGITUDE IS NOT NULL
            """
            cur.execute(query)
            rows = cur.fetchall()
        except Exception:
            return items
        finally:
            try:
                conn.close()
            except Exception:
                pass

        for row in rows:
            lat = row["lat"]
            lon = row["lon"]
            if not self._valid_latlon(lat, lon):
                continue
            ts = self._normalize_line_timestamp(row["ts"])
            items.append({
                "source_app": "LINE",
                "conversation": row["conv_name"] or "LINE",
                "timestamp": ts,
                "lat": float(lat),
                "lon": float(lon),
                "message": row["msg_text"] or "",
                "source_detail": "ZMESSAGE",
                "message_id": row["msg_id"],
            })

        return items

    def _find_instagram_db(self) -> Optional[str]:
        domain = "AppDomain-com.burbn.instagram"
        if not os.path.exists(self.manifest_db_path):
            return None
        try:
            conn = sqlite3.connect(f"file:{self.manifest_db_path}?mode=ro", uri=True)
            cur = conn.cursor()
            cur.execute("""
                SELECT fileID, relativePath
                FROM Files
                WHERE domain = ? AND relativePath LIKE '%.db'
                AND (relativePath LIKE '%/%.db' OR relativePath NOT LIKE '%/%')
                ORDER BY relativePath
            """, (domain,))
            rows = cur.fetchall()
        except Exception:
            return None
        finally:
            try:
                conn.close()
            except Exception:
                pass

        for row in rows:
            file_id, rel_path = row
            filename = os.path.basename(rel_path)
            if not filename.replace(".db", "").isdigit():
                continue
            physical_path = self._resolve_file_id_path(file_id)
            if physical_path and os.path.exists(physical_path):
                return physical_path
        return None

    def _load_instagram_locations(self) -> List[Dict[str, Any]]:
        items: List[Dict[str, Any]] = []
        db_path = self._find_instagram_db()
        if not db_path or not os.path.exists(db_path):
            return items

        try:
            from third_party.instagram_extractor import InstagramExtractor as CoreInstagramExtractor
        except Exception:
            return items

        core = CoreInstagramExtractor(db_path)
        for msg in core.iter_messages():
            archive = msg.get("raw", {}).get("decoded_archive")
            loc = self._extract_latlon_from_archive(archive)
            if not loc:
                continue
            ts = msg.get("timestamp")
            ts_unix = int(ts.timestamp()) if hasattr(ts, "timestamp") else None
            items.append({
                "source_app": "Instagram",
                "conversation": msg.get("conversation_name") or "Instagram",
                "timestamp": ts_unix,
                "lat": float(loc["lat"]),
                "lon": float(loc["lon"]),
                "message": msg.get("text") or "",
                "source_detail": "Instagram archive",
                "message_id": msg.get("message_id"),
            })

        return items

    def _find_messenger_db(self) -> Optional[str]:
        db_path = self.find_file_in_backup(
            "AppDomainGroup-group.com.facebook.Orca",
            "lightspeed-raw.db"
        )
        if db_path and os.path.exists(db_path):
            return db_path

        if not os.path.exists(self.manifest_db_path):
            return None
        try:
            conn = sqlite3.connect(f"file:{self.manifest_db_path}?mode=ro", uri=True)
            cur = conn.cursor()
            cur.execute("""
                SELECT fileID
                FROM Files
                WHERE domain = 'AppDomainGroup-group.com.facebook.Facebook'
                AND relativePath LIKE '%fb-msys%.db'
                ORDER BY relativePath DESC
                LIMIT 1
            """)
            row = cur.fetchone()
            if row:
                physical_path = self._resolve_file_id_path(row[0])
                if physical_path and os.path.exists(physical_path):
                    return physical_path

            cur.execute("""
                SELECT fileID
                FROM Files
                WHERE domain = 'AppDomainPlugin-com.facebook.Messenger.ShareExtension'
                AND relativePath LIKE '%lightspeed%.db'
                ORDER BY relativePath DESC
                LIMIT 1
            """)
            row = cur.fetchone()
            if row:
                physical_path = self._resolve_file_id_path(row[0])
                if physical_path and os.path.exists(physical_path):
                    return physical_path
        except Exception:
            return None
        finally:
            try:
                conn.close()
            except Exception:
                pass
        return None

    def _load_messenger_locations(self) -> List[Dict[str, Any]]:
        db_path = self._find_messenger_db()
        return self._scan_db_for_latlon_tables(db_path, "Messenger") if db_path else []

    def _find_kik_db(self) -> Optional[str]:
        if not os.path.exists(self.manifest_db_path):
            return None
        try:
            conn = sqlite3.connect(f"file:{self.manifest_db_path}?mode=ro", uri=True)
            cur = conn.cursor()
            cur.execute("""
                SELECT fileID
                FROM Files
                WHERE domain = 'AppDomainGroup-group.com.kik.chat'
                AND relativePath LIKE '%kik.sqlite'
                ORDER BY relativePath DESC
                LIMIT 1
            """)
            row = cur.fetchone()
            if row:
                physical_path = self._resolve_file_id_path(row[0])
                if physical_path and os.path.exists(physical_path):
                    return physical_path
        except Exception:
            return None
        finally:
            try:
                conn.close()
            except Exception:
                pass
        return None

    def _load_kik_locations(self) -> List[Dict[str, Any]]:
        db_path = self._find_kik_db()
        return self._scan_db_for_latlon_tables(db_path, "Kik") if db_path else []

    def _resolve_sms_attachment_path(self, attachment_filename: str) -> Optional[str]:
        if not attachment_filename:
            return None
        if attachment_filename.startswith('~/'):
            relative_path = attachment_filename[2:]
        else:
            relative_path = attachment_filename

        file_path = self.find_db_file("MediaDomain", relative_path)
        if file_path:
            return file_path

        if '/' in relative_path:
            directory_path = relative_path.rsplit('/', 1)[0]
            file_path = self.find_db_file("MediaDomain", directory_path)
            if file_path:
                return file_path

        return None

    def _parse_vlocation_vcf(self, path: str) -> Optional[Dict[str, Any]]:
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
        except Exception:
            return None

        lat = lon = None
        for line in content.splitlines():
            line = line.strip()
            if line.upper().startswith("GEO:"):
                value = line.split(":", 1)[1]
                if ";" in value:
                    parts = value.split(";")
                else:
                    parts = value.split(",")
                if len(parts) >= 2:
                    lat, lon = parts[0], parts[1]
            if "maps.apple.com" in line and "ll=" in line:
                try:
                    ll = line.split("ll=", 1)[1].split("&", 1)[0]
                    ll = ll.replace("\\", "")
                    parts = ll.split(",")
                    if len(parts) >= 2:
                        lat, lon = parts[0], parts[1]
                except Exception:
                    pass
            if "geo:" in line.lower() and lat is None:
                try:
                    geo = line.split("geo:", 1)[1]
                    geo = geo.replace("\\", "")
                    parts = geo.replace(";", ",").split(",")
                    if len(parts) >= 2:
                        lat, lon = parts[0], parts[1]
                except Exception:
                    pass

        if lat is None or lon is None:
            return None
        if not self._valid_latlon(lat, lon):
            return None
        return {"lat": float(lat), "lon": float(lon), "raw": content}

    def _normalize_sms_timestamp(self, value: Any) -> Optional[int]:
        try:
            ts = float(value)
        except Exception:
            return None
        if ts <= 0:
            return None
        if ts > 1000000000000:
            ts = ts / 1000000000.0
        return int((self._APPLE_EPOCH + timedelta(seconds=ts)).timestamp())

    def _load_sms_locations(self) -> List[Dict[str, Any]]:
        items = []
        sms_path = self.backup_access.get_file_path("HomeDomain", "Library/SMS/sms.db")
        if not sms_path or not os.path.exists(sms_path):
            return items

        try:
            conn = sqlite3.connect(sms_path)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            query = """
                SELECT
                    a.ROWID as attachment_id,
                    a.filename as attachment_filename,
                    a.transfer_name as transfer_name,
                    a.mime_type as mime_type,
                    a.uti as uti,
                    m.ROWID as message_id,
                    m.date as message_date,
                    m.text as message_text,
                    m.cache_roomnames as roomnames,
                    h.id as handle_id,
                    c.display_name as chat_name,
                    c.room_name as room_name,
                    c.service_name as service_name
                FROM attachment a
                JOIN message_attachment_join maj ON a.ROWID = maj.attachment_id
                JOIN message m ON maj.message_id = m.ROWID
                LEFT JOIN handle h ON m.handle_id = h.ROWID
                LEFT JOIN chat_message_join cmj ON m.ROWID = cmj.message_id
                LEFT JOIN chat c ON cmj.chat_id = c.ROWID
                WHERE a.mime_type = 'text/x-vlocation'
                   OR a.uti = 'public.vlocation'
            """
            cur.execute(query)
            rows = cur.fetchall()
        except Exception:
            return items
        finally:
            try:
                conn.close()
            except Exception:
                pass

        for row in rows:
            attachment_path = self._resolve_sms_attachment_path(row["attachment_filename"] or "")
            if not attachment_path:
                continue
            loc = self._parse_vlocation_vcf(attachment_path)
            if not loc:
                continue
            ts = self._normalize_sms_timestamp(row["message_date"])
            conversation = row["chat_name"] or row["room_name"] or row["roomnames"] or row["handle_id"] or "Messages"
            message_text = row["message_text"] or row["transfer_name"] or "Shared Location"
            items.append({
                "source_app": "Messages",
                "conversation": conversation,
                "timestamp": ts,
                "lat": loc["lat"],
                "lon": loc["lon"],
                "message": message_text,
                "source_detail": "sms.db vlocation",
                "message_id": row["message_id"],
            })

        return items

    def _load_photo_locations(self) -> List[Dict[str, Any]]:
        items = []
        photos_db = self.find_db_file("CameraRollDomain", "Media/PhotoData/Photos.sqlite")
        if not photos_db or not os.path.exists(photos_db):
            return items

        try:
            conn = sqlite3.connect(photos_db)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            cur.execute("""
                SELECT ZLATITUDE as lat,
                       ZLONGITUDE as lon,
                       ZDATECREATED as date_created,
                       ZFILENAME as filename,
                       ZDIRECTORY as directory,
                       ZUUID as uuid
                FROM ZASSET
                WHERE ZLATITUDE IS NOT NULL
                  AND ZLONGITUDE IS NOT NULL
            """)
            rows = cur.fetchall()
        except Exception:
            return items
        finally:
            try:
                conn.close()
            except Exception:
                pass

        for row in rows:
            lat = row["lat"]
            lon = row["lon"]
            if not self._valid_latlon(lat, lon):
                continue
            ts = self._normalize_apple_timestamp(row["date_created"])
            filename = row["filename"] or ""
            items.append({
                "source_app": "Photos",
                "conversation": "Camera Roll",
                "timestamp": ts,
                "lat": float(lat),
                "lon": float(lon),
                "message": filename,
                "source_detail": "Photos.sqlite",
                "message_id": row["uuid"] or filename,
                "photo_filename": filename,
                "photo_directory": row["directory"] or "",
            })

        return items

    def _normalize_html_path(self, path: str) -> str:
        return path.replace("\\", "/")

    def _sanitize_filename(self, name: str) -> str:
        if not name:
            return "preview"
        invalid_chars = '<>:"/\\|?*'
        for char in invalid_chars:
            name = name.replace(char, "_")
        return name[:120]

    def _register_heif_opener(self) -> None:
        if not HEIF_AVAILABLE or self.__class__._heif_registered:
            return
        try:
            pillow_heif.register_heif_opener()
            self.__class__._heif_registered = True
        except Exception:
            return

    def _get_photo_source_path(self, directory: str, filename: str) -> Optional[str]:
        if not directory or not filename:
            return None
        if directory.startswith("Media/"):
            rel = f"{directory}/{filename}"
        else:
            rel = f"Media/{directory}/{filename}"
        rel = rel.replace("\\", "/").strip("/")
        return self.backup_access.get_file_path("CameraRollDomain", rel)

    def _build_photo_preview(self, item: Dict[str, Any], output_path: str) -> Optional[str]:
        if item.get("source_app") != "Photos":
            return None
        filename = item.get("photo_filename") or ""
        directory = item.get("photo_directory") or ""
        src_path = self._get_photo_source_path(directory, filename)
        if not src_path or not os.path.exists(src_path):
            return None

        preview_dir = os.path.join(output_path, "Photo_Previews")
        os.makedirs(preview_dir, exist_ok=True)
        base_name = self._sanitize_filename(item.get("message_id") or filename or "photo")
        preview_path = os.path.join(preview_dir, f"{base_name}.jpg")

        if os.path.exists(preview_path):
            return self._normalize_html_path(os.path.relpath(preview_path, output_path))

        if PIL_AVAILABLE:
            try:
                self._register_heif_opener()
                with Image.open(src_path) as img:
                    img = ImageOps.exif_transpose(img)
                    img = img.convert("RGB")
                    img.thumbnail((240, 240))
                    img.save(preview_path, format="JPEG", quality=85)
            except Exception:
                return None
        else:
            try:
                _, ext = os.path.splitext(src_path)
                if ext.lower() not in (".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tif", ".tiff"):
                    return None
                shutil.copy2(src_path, preview_path)
            except Exception:
                return None

        if os.path.exists(preview_path):
            return self._normalize_html_path(os.path.relpath(preview_path, output_path))
        return None

    def _copy_original_media(self, item: Dict[str, Any], output_path: str) -> Optional[str]:
        if item.get("source_app") != "Photos":
            return None
        filename = item.get("photo_filename") or ""
        directory = item.get("photo_directory") or ""
        src_path = self._get_photo_source_path(directory, filename)
        if not src_path or not os.path.exists(src_path):
            return None

        originals_dir = os.path.join(output_path, "Original_Files")
        os.makedirs(originals_dir, exist_ok=True)
        base_name = self._sanitize_filename(item.get("message_id") or filename or "media")
        _, ext = os.path.splitext(filename)
        if not ext:
            _, ext = os.path.splitext(src_path)
        ext = ext or ""
        dest_path = os.path.join(originals_dir, f"{base_name}{ext}")
        if not os.path.exists(dest_path):
            try:
                shutil.copy2(src_path, dest_path)
            except Exception:
                return None
        if os.path.exists(dest_path):
            return self._normalize_html_path(os.path.relpath(dest_path, output_path))
        return None

    def _load_items(self) -> List[Dict[str, Any]]:
        if self._cached_items is not None:
            return self._cached_items

        items: List[Dict[str, Any]] = []
        items.extend(self._load_photo_locations())
        items.extend(self._load_whatsapp_locations())
        items.extend(self._load_viber_locations())
        items.extend(self._load_line_locations())
        items.extend(self._load_sms_locations())
        items.extend(self._load_messenger_locations())
        items.extend(self._load_instagram_locations())
        items.extend(self._load_kik_locations())

        items.sort(key=lambda x: x.get("timestamp") or 0, reverse=True)
        self._cached_items = items
        return items

    def get_count(self) -> int:
        return len(self._load_items())

    def get_items(self, limit: Optional[int] = None, offset: int = 0,
                  search: Optional[str] = None) -> List[Dict[str, Any]]:
        items = self._load_items()
        if search:
            term = search.lower()
            items = [
                item for item in items
                if term in (item.get("source_app") or "").lower()
                or term in (item.get("conversation") or "").lower()
                or term in (item.get("message") or "").lower()
            ]
        if limit:
            return items[offset:offset + limit]
        return items[offset:]

    def export(self, items: List[Dict[str, Any]], output_path: str,
               format: str = "html", progress_callback=None, timeline_emitter=None) -> bool:
        if format != "html":
            raise ValueError(f"Unsupported export format: {format}")

        try:
            self._reset_export_bytes()
            os.makedirs(output_path, exist_ok=True)

            if progress_callback:
                if not progress_callback(0, len(items), "Preparing locations report..."):
                    return False

            html_path = os.path.join(output_path, "Significant_Locations.html")
            json_path = os.path.join(output_path, "Significant_Locations.json")

            for item in items:
                preview = self._build_photo_preview(item, output_path)
                if preview:
                    item["preview_url"] = preview
                original = self._copy_original_media(item, output_path)
                if original:
                    item["original_url"] = original

            with open(json_path, "w", encoding="utf-8") as f:
                import json
                json.dump(items, f, indent=2, ensure_ascii=False)
            self._add_export_bytes(json_path)

            rows = []
            for idx, item in enumerate(items, start=1):
                if progress_callback:
                    label = item.get("conversation") or item.get("source_app") or "Location"
                    if not progress_callback(idx, len(items), label):
                        return False

                ts = item.get("timestamp")
                ts_str = datetime.fromtimestamp(ts).strftime("%m/%d/%Y %I:%M %p") if ts else ""
                raw_message = item.get("message") or ""
                msg_text = str(raw_message)
                if len(msg_text) > 120:
                    msg_display = msg_text[:117] + "..."
                else:
                    msg_display = msg_text
                rows.append(
                    f"<tr data-index=\"{idx - 1}\">"
                    f"<td>{self._escape_html(item.get('source_app') or '')}</td>"
                    f"<td>{self._escape_html(item.get('conversation') or '')}</td>"
                    f"<td title=\"{self._escape_html(msg_text)}\">{self._escape_html(msg_display)}</td>"
                    f"<td>{self._escape_html(ts_str)}</td>"
                    "</tr>"
                )

                if timeline_emitter is not None and ts:
                    title = f"{item.get('source_app') or 'Location'}: {item.get('conversation') or ''}".strip()
                    timeline_emitter.emit({
                        "timestamp": datetime.fromtimestamp(ts).isoformat(),
                        "raw_timestamp": ts,
                        "raw_format": "unix_seconds",
                        "source_app": item.get("source_app") or "Locations",
                        "source_category": "Significant Locations",
                        "event_type": "shared_location",
                        "title": title or "Shared Location",
                        "details": {
                            "conversation": item.get("conversation"),
                            "message": item.get("message"),
                            "latitude": item.get("lat"),
                            "longitude": item.get("lon"),
                            "source_detail": item.get("source_detail"),
                        },
                        "confidence": "high",
                        "raw_source_path": "",
                        "report_anchor": "",
                        "link_hint": "Significant Locations/Significant_Locations.html",
                    })

            html = """<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Significant Locations</title>
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
  <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
      margin: 20px;
      background-color: #f5f5f5;
    }
    .header {
      background: linear-gradient(135deg, #3b82f6 0%, #22d3ee 100%);
      color: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      margin-bottom: 20px;
    }
    .header h1 {
      margin: 0 0 10px 0;
      font-size: 32px;
      font-weight: 600;
    }
    .breadcrumbs {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 12px;
      letter-spacing: 0.2px;
      color: rgba(255,255,255,0.85);
      margin-bottom: 10px;
    }
    .breadcrumbs a {
      color: #fff;
      text-decoration: none;
      font-weight: 600;
    }
    .breadcrumbs a:hover { text-decoration: underline; }
    .embedded .breadcrumbs { display: none; }
    .container {
      background: #fff;
      border-radius: 12px;
      padding: 20px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.08);
      margin-bottom: 20px;
    }
    .map-highlight {
      box-shadow: 0 0 0 3px rgba(59,130,246,0.35), 0 8px 18px rgba(31,42,54,0.12);
      transition: box-shadow 240ms ease;
    }
    #map { height: 520px; border-radius: 10px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { text-align: left; padding: 8px; border-bottom: 1px solid #e5e5e5; }
    th { background: #fafafa; }
    tbody tr { cursor: pointer; }
    tbody tr:hover { background: #f2f7ff; }
    tbody tr.active-row { background: #e0f2fe; }
    td:nth-child(3) {
      max-width: 320px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .leaflet-popup-content { margin: 12px 14px; max-width: 260px; }
    .leaflet-popup-content img,
    .leaflet-popup-content video,
    .leaflet-popup-content audio {
      max-width: 100%;
      width: 100%;
      height: auto;
      box-sizing: border-box;
    }
  </style>
</head>
<body>
  <div class="header">
    <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Start_Here.html">Back</a></div>
    <h1>Significant Locations</h1>
    <p>Total locations: """ + str(len(items)) + """</p>
  </div>
  <div class="container" id="map-container">
    <div id="map"></div>
  </div>
  <div class="container">
    <table>
      <thead>
        <tr>
          <th>Source</th><th>Conversation</th><th>Message</th><th>Timestamp</th>
        </tr>
      </thead>
      <tbody>
        """ + "\n".join(rows) + """
      </tbody>
    </table>
  </div>
  <script>
    const locations = """ + self._escape_json(items) + """;
    const map = L.map('map').setView([37.7749, -122.4194], 4);
    const streets = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);
    const satellite = L.tileLayer(
      'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
      {
        attribution: 'Tiles &copy; Esri &mdash; Source: Esri, Maxar, Earthstar Geographics, and the GIS User Community'
      }
    );
    L.control.layers({ 'Streets': streets, 'Satellite': satellite }, null, { position: 'topright' }).addTo(map);

    const markers = [];
    let activeRow = null;
    locations.forEach(loc => {
      if (loc.lat === null || loc.lon === null) return;
      const preview = loc.preview_url
        ? `<div style="margin-top:6px;"><img src="${loc.preview_url}" style="display:block; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.2);" /></div>`
        : '';
      let media = '';
      if (loc.original_url) {
        const lower = loc.original_url.toLowerCase();
        if (lower.endsWith('.mp4') || lower.endsWith('.mov') || lower.endsWith('.m4v')) {
          media = `<div style="margin-top:6px;"><video controls src="${loc.original_url}" style="display:block; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.2);"></video></div>`;
        } else if (lower.endsWith('.mp3') || lower.endsWith('.m4a') || lower.endsWith('.wav') || lower.endsWith('.aac')) {
          media = `<div style="margin-top:6px;"><audio controls src="${loc.original_url}"></audio></div>`;
        }
      }
      const originalLink = loc.original_url
        ? `<div style="margin-top:6px;"><a href="${loc.original_url}" target="_blank" rel="noopener">Open original</a></div>`
        : '';
      const coord = (loc.lat !== null && loc.lon !== null)
        ? `<div style="font-size: 12px; color: #4b5563; margin-top: 4px;">Lat/Lon: ${Number(loc.lat).toFixed(6)}, ${Number(loc.lon).toFixed(6)}</div>`
        : '';
      const popup = `
        <strong>${loc.source_app || 'Location'}</strong><br>
        ${loc.conversation || ''}<br>
        ${loc.message || ''}<br>
        ${loc.timestamp ? new Date(loc.timestamp * 1000).toLocaleString('en-US') : ''}
        ${coord}
        ${preview}
        ${media}
        ${originalLink}
      `;
      const marker = L.marker([loc.lat, loc.lon]).bindPopup(popup);
      marker.addTo(map);
      markers.push(marker);
    });

    if (markers.length) {
      const bounds = markers.map(m => m.getLatLng());
      map.fitBounds(bounds, { padding: [30, 30] });
    }

    function clearActiveRow() {
      if (activeRow) {
        activeRow.classList.remove('active-row');
      }
      activeRow = null;
    }

    function flashMap() {
      const container = document.getElementById('map-container');
      if (!container) return;
      container.classList.add('map-highlight');
      container.scrollIntoView({ behavior: 'smooth', block: 'start' });
      setTimeout(() => container.classList.remove('map-highlight'), 900);
    }

    document.querySelectorAll('tbody tr[data-index]').forEach(row => {
      row.addEventListener('click', () => {
        const idx = parseInt(row.getAttribute('data-index'), 10);
        if (Number.isNaN(idx) || !markers[idx]) return;
        clearActiveRow();
        activeRow = row;
        activeRow.classList.add('active-row');
        const marker = markers[idx];
        map.setView(marker.getLatLng(), Math.max(map.getZoom(), 12), { animate: true });
        marker.openPopup();
        flashMap();
      });
    });
  </script>
  <script>
    if (window.self !== window.top) {
      document.body.classList.add('embedded');
    }
  </script>
</body>
</html>
"""
            with open(html_path, "w", encoding="utf-8") as f:
                f.write(html)
            self._add_export_bytes(html_path)

            return True
        except Exception as e:
            print(f"Error exporting significant locations: {e}")
            return False

    def get_item_summary(self, item: Dict[str, Any]) -> str:
        return f"{item.get('source_app', 'Location')} - {item.get('conversation', '')}"

    @staticmethod
    def _escape_html(text: str) -> str:
        if not text:
            return ""
        text = str(text)
        return (text.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;"))

    @staticmethod
    def _escape_json(items: List[Dict[str, Any]]) -> str:
        import json
        return json.dumps(items, ensure_ascii=False)
