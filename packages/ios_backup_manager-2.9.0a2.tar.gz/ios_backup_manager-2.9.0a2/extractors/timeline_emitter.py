#!/usr/bin/env python3
"""
Timeline event emitter.

Writes newline-delimited JSON (NDJSON) for streaming writes, then compacts
and sorts into a JSON array for report generation.
"""

import json
import os
import tempfile
import threading
from typing import Any, Dict, List


IMAGE_EXTS = {"jpg", "jpeg", "png", "gif", "heic", "heif", "tif", "tiff", "bmp", "webp", "svg"}
VIDEO_EXTS = {"mov", "mp4", "m4v", "avi", "mkv", "3gp", "3gpp", "webm"}
AUDIO_EXTS = {"m4a", "aac", "mp3", "wav", "aiff", "aif", "amr", "caf", "opus", "flac"}
TEXT_EXTS = {"txt", "rtf", "md", "json", "csv", "xml", "log"}
FILE_EXTS = {"pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "zip", "rar", "7z", "pages", "numbers", "key"}


def _get_ext(value: str) -> str:
    if not value:
        return ""
    value = value.lower()
    for sep in ("?", "#"):
        if sep in value:
            value = value.split(sep, 1)[0]
    if "." not in value:
        return ""
    return value.rsplit(".", 1)[-1]


def _categorize_event(event: Dict[str, Any]) -> str:
    event_type = str(event.get("event_type") or "").lower()
    source_category = str(event.get("source_category") or "").lower()
    details = event.get("details") or {}
    if isinstance(details, dict):
        candidates = [
            details.get("filename"),
            details.get("path"),
            details.get("title"),
            details.get("url"),
            event.get("title"),
        ]
    else:
        candidates = [event.get("title")]
    ext = _get_ext(" ".join([c for c in candidates if isinstance(c, str)]))

    if "calendar" in event_type or source_category == "calendar":
        return "Text"
    if "reminder" in event_type or source_category == "reminders":
        return "Text"
    if "photo" in event_type or "image" in event_type or ext in IMAGE_EXTS:
        return "Photos"
    if "video" in event_type or ext in VIDEO_EXTS:
        return "Videos"
    if "voice" in event_type or "audio" in event_type or ext in AUDIO_EXTS:
        return "Audio"
    if any(token in event_type for token in ("bookmark", "browser", "tab", "history")):
        return "Text"
    if any(token in event_type for token in ("message", "note", "call", "contact", "credential")):
        return "Text"
    if isinstance(details, dict) and details.get("url"):
        return "Text"
    if ext in TEXT_EXTS:
        return "Text"
    if "download" in event_type or ext in FILE_EXTS:
        return "Files"
    return "Files"


class TimelineEmitter:
    """Append-only timeline event emitter with finalize/sort helper."""

    def __init__(self, output_dir: str, case_id: str = "default", tz: str = "America/Chicago"):
        self.output_dir = output_dir
        self.case_id = case_id
        self.tz = tz
        self._disabled = False
        self._warned = False
        os.makedirs(output_dir, exist_ok=True)
        self._staging_dir = os.path.join(tempfile.gettempdir(), "ibm_timeline", case_id)
        self._ndjson_dir = output_dir
        self._json_dir = output_dir
        if not self._can_write_dir(output_dir):
            self._json_dir = self._staging_dir
        self.ndjson_path = os.path.join(self._ndjson_dir, "timeline_events.ndjson")
        self.json_path = os.path.join(self._json_dir, "timeline_events.json")
        if not self._can_open_ndjson():
            os.makedirs(self._staging_dir, exist_ok=True)
            self._ndjson_dir = self._staging_dir
            self.ndjson_path = os.path.join(self._ndjson_dir, "timeline_events.ndjson")
        self._lock = threading.Lock()

    def _warn_once(self, message: str) -> None:
        if self._warned:
            return
        self._warned = True
        print(message)

    def _can_write_dir(self, directory: str) -> bool:
        try:
            os.makedirs(directory, exist_ok=True)
            test_path = os.path.join(directory, ".timeline_write_test")
            with open(test_path, "wb") as f:
                f.write(b"1")
            os.remove(test_path)
            return True
        except Exception:
            return False

    def _can_open_ndjson(self) -> bool:
        try:
            os.makedirs(self._ndjson_dir, exist_ok=True)
            with open(self.ndjson_path, "a", encoding="utf-8"):
                pass
            return True
        except Exception:
            return False

    def get_report_dir(self) -> str:
        return os.path.dirname(self.json_path)

    def uses_staging(self) -> bool:
        return self._ndjson_dir == self._staging_dir or self._json_dir == self._staging_dir

    def emit(self, event: Dict[str, Any]) -> None:
        """Append a single event to NDJSON stream."""
        if self._disabled:
            return
        if not event.get("category_bucket"):
            event["category_bucket"] = _categorize_event(event)
        try:
            with self._lock:
                with open(self.ndjson_path, "a", encoding="utf-8") as f:
                    f.write(json.dumps(event, ensure_ascii=False, default=str) + "\n")
        except PermissionError:
            self._disabled = True
            self._warn_once("[WARN] Timeline emitter disabled: permission denied writing timeline_events.ndjson")
        except Exception:
            self._disabled = True
            self._warn_once("[WARN] Timeline emitter disabled: failed to write timeline_events.ndjson")

    def finalize(self) -> int:
        """Compact NDJSON into a sorted JSON array. Returns event count."""
        events: List[Dict[str, Any]] = []
        if not os.path.exists(self.ndjson_path):
            try:
                os.makedirs(os.path.dirname(self.json_path), exist_ok=True)
                with open(self.json_path, "w", encoding="utf-8") as f:
                    f.write("[]")
            except Exception:
                return 0
            return 0

        with open(self.ndjson_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    events.append(json.loads(line))
                except Exception:
                    continue

        def _sort_key(ev: Dict[str, Any]) -> str:
            return ev.get("timestamp_utc") or ev.get("timestamp") or ev.get("timestamp_display") or ""

        events.sort(key=_sort_key, reverse=True)

        try:
            os.makedirs(os.path.dirname(self.json_path), exist_ok=True)
            with open(self.json_path, "w", encoding="utf-8") as f:
                json.dump(events, f, indent=2, ensure_ascii=False, default=str)
        except PermissionError:
            if self._json_dir != self._staging_dir:
                try:
                    os.makedirs(self._staging_dir, exist_ok=True)
                    self.json_path = os.path.join(self._staging_dir, "timeline_events.json")
                    with open(self.json_path, "w", encoding="utf-8") as f:
                        json.dump(events, f, indent=2, ensure_ascii=False, default=str)
                except Exception:
                    return len(events)
            else:
                return len(events)
        except Exception:
            return len(events)

        return len(events)
