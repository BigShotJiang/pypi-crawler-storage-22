#!/usr/bin/env python3
"""
Viber data extractor for iOS backups.

Extracts messages, conversations, and attachments from Viber's Contacts.data
database and exports an HTML report similar to WhatsApp/SMS.
"""

import os
import re
import html
import sqlite3
import shutil
from typing import List, Dict, Any, Optional
from datetime import datetime, timezone

from .base import CategoryDataExtractor


class ViberExtractor(CategoryDataExtractor):
    """Extract and export Viber data from iOS backups."""

    VIBER_DOMAIN = "AppDomain-com.viber"
    VIBER_GROUP_DOMAIN = "AppDomainGroup-group.viber.share.container"
    CONTACTS_DATA_REL = "com.viber/database/Contacts.data"

    def __init__(self, backup_path: str):
        super().__init__(backup_path)

        self.db_path = self._find_viber_db()
        if not self.db_path:
            raise FileNotFoundError("Viber Contacts.data not found in backup")

    def _find_viber_db(self) -> Optional[str]:
        # Preferred location in group container.
        path = self.find_file_in_backup(self.VIBER_GROUP_DOMAIN, self.CONTACTS_DATA_REL)
        if path:
            return path

        # Fallback: search manifest for Contacts.data under Viber domains.
        conn = sqlite3.connect(f"file:{self.manifest_db_path}?mode=ro", uri=True)
        try:
            cur = conn.cursor()
            cur.execute("""
                SELECT fileID, relativePath, domain
                FROM Files
                WHERE relativePath LIKE '%Contacts.data'
                  AND (domain LIKE 'AppDomain-com.viber%' OR domain LIKE 'AppDomainGroup-group.viber%')
                ORDER BY domain, relativePath
                LIMIT 1
            """)
            row = cur.fetchone()
            if row:
                file_id = row[0]
                return self._resolve_file_id_path(file_id)
        finally:
            conn.close()
        return None

    def _format_viber_timestamp(self, timestamp: Optional[float]) -> Optional[datetime]:
        if timestamp is None or timestamp == 0:
            return None
        try:
            apple_epoch = datetime(2001, 1, 1, tzinfo=timezone.utc).timestamp()
            unix_timestamp = apple_epoch + float(timestamp)
            return datetime.fromtimestamp(unix_timestamp)
        except Exception:
            return None

    def _format_timestamp_iso(self, timestamp: Optional[float]) -> Optional[str]:
        dt = self._format_viber_timestamp(timestamp)
        if not dt:
            return None
        return dt.isoformat()

    def _escape_html(self, text: str) -> str:
        if not text:
            return ''
        return (str(text)
                .replace('&', '&amp;')
                .replace('<', '&lt;')
                .replace('>', '&gt;')
                .replace('"', '&quot;')
                .replace("'", '&#39;')
                .replace('\n', '<br>'))

    def _guess_extension(self, path: str) -> str:
        try:
            with open(path, "rb") as f:
                head = f.read(12)
            if head.startswith(b"\xff\xd8\xff"):
                return ".jpg"
            if head.startswith(b"\x89PNG\r\n\x1a\n"):
                return ".png"
            if head.startswith(b"GIF87a") or head.startswith(b"GIF89a"):
                return ".gif"
        except Exception:
            return ""
        return ""

    def _is_image_file(self, filename: str) -> bool:
        ext = os.path.splitext(filename or "")[1].lower()
        return ext in (".jpg", ".jpeg", ".png", ".gif", ".heic", ".webp")

    def _find_attachment_path(self, name: str) -> Optional[str]:
        if not name:
            return None
        rel = f"Documents/Attachments/{name}"
        path = self.find_file_in_backup(self.VIBER_DOMAIN, rel)
        if path:
            return path

        # Fallback: search by name in manifest for Viber domain.
        conn = sqlite3.connect(f"file:{self.manifest_db_path}?mode=ro", uri=True)
        try:
            cur = conn.cursor()
            cur.execute("""
                SELECT fileID
                FROM Files
                WHERE domain = ?
                  AND relativePath LIKE ?
                LIMIT 1
            """, (self.VIBER_DOMAIN, f"%{name}%"))
            row = cur.fetchone()
            if row:
                return self._resolve_file_id_path(row[0])
        finally:
            conn.close()
        return None

    def _resolve_attachment(self, name: str, output_dir: str) -> Optional[Dict[str, str]]:
        path = self._find_attachment_path(name)
        if not path or not os.path.exists(path):
            return None

        base, ext = os.path.splitext(name)
        if not ext:
            ext = self._guess_extension(path) or ".bin"
        filename = f"{base}{ext}" if base else f"{name}{ext}"

        dest_path = os.path.join(output_dir, filename)
        if not os.path.exists(dest_path):
            shutil.copy2(path, dest_path)
        self._add_export_bytes(dest_path)
        return {
            "file_name": filename,
            "path": dest_path,
        }

    def get_total_message_count(self) -> int:
        conn = sqlite3.connect(self.db_path)
        try:
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) FROM ZVIBERMESSAGE")
            return cur.fetchone()[0]
        finally:
            conn.close()

    def get_conversations(self, limit: Optional[int] = None, offset: int = 0,
                          search: Optional[str] = None) -> List[Dict[str, Any]]:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        search_condition = ""
        params: List[Any] = []
        if search:
            search_condition = "WHERE m.ZDISPLAYFULLNAME LIKE ? OR m.ZNAME LIKE ?"
            pattern = f"%{search}%"
            params.extend([pattern, pattern])

        cur.execute(f"""
            SELECT c.Z_PK as chat_id, c.ZDATE, c.ZLASTMESSAGETEXT, c.ZINTERLOCUTOR, c.ZGROUPID,
                   m.ZDISPLAYFULLNAME, m.ZNAME
            FROM ZCONVERSATION c
            LEFT JOIN ZMEMBER m ON m.Z_PK = c.ZINTERLOCUTOR
            {search_condition}
            ORDER BY c.ZDATE DESC
        """, params)

        conversations = []
        for row in cur.fetchall():
            chat_id = row["chat_id"]
            display_name = row["ZDISPLAYFULLNAME"] or row["ZNAME"]
            if not display_name:
                display_name = f"Group {row['ZGROUPID']}" if row["ZGROUPID"] else f"Conversation {chat_id}"

            cur.execute("SELECT COUNT(*) FROM ZVIBERMESSAGE WHERE ZCONVERSATION = ?", (chat_id,))
            message_count = cur.fetchone()[0]

            last_message = row["ZLASTMESSAGETEXT"] or ""
            last_message_date = row["ZDATE"]

            if not last_message:
                cur.execute("""
                    SELECT ZTEXT, ZDATE
                    FROM ZVIBERMESSAGE
                    WHERE ZCONVERSATION = ?
                    ORDER BY ZDATE DESC
                    LIMIT 1
                """, (chat_id,))
                last_row = cur.fetchone()
                if last_row:
                    last_message = last_row["ZTEXT"] or ""
                    last_message_date = last_row["ZDATE"]

            conversations.append({
                "chat_id": chat_id,
                "display_name": display_name,
                "last_message": last_message,
                "last_message_date": last_message_date,
                "message_count": message_count,
            })

        conn.close()
        if offset:
            conversations = conversations[offset:]
        if limit:
            conversations = conversations[:limit]
        return conversations

    def _load_messages_for_chat(self, chat_id: int) -> List[Dict[str, Any]]:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            cur = conn.cursor()
            cur.execute("""
                SELECT m.Z_PK, m.ZTEXT, m.ZDATE, m.ZSTATE, m.ZATTACHMENT,
                       m.ZSYSTEMTYPE, m.ZCALLTYPE, m.ZCALLDURATION, m.ZCALLSCOUNT
                FROM ZVIBERMESSAGE m
                WHERE m.ZCONVERSATION = ?
                ORDER BY m.ZDATE ASC
            """, (chat_id,))
            messages = [dict(r) for r in cur.fetchall()]

            attachment_ids = [m["ZATTACHMENT"] for m in messages if m.get("ZATTACHMENT")]
            attachments = {}
            if attachment_ids:
                placeholders = ",".join(["?"] * len(attachment_ids))
                cur.execute(f"""
                    SELECT Z_PK, ZNAME, ZTYPE
                    FROM ZATTACHMENT
                    WHERE Z_PK IN ({placeholders})
                """, attachment_ids)
                for row in cur.fetchall():
                    attachments[row["Z_PK"]] = {"name": row["ZNAME"], "type": row["ZTYPE"]}

            for msg in messages:
                attach = attachments.get(msg.get("ZATTACHMENT"))
                msg["attachment_name"] = attach["name"] if attach else None
                msg["attachment_type"] = attach["type"] if attach else None
            return messages
        finally:
            conn.close()

    def get_count(self) -> int:
        return self.get_total_message_count()

    def get_items(self, limit: Optional[int] = None, offset: int = 0, **kwargs) -> List[Dict[str, Any]]:
        search = kwargs.get("search")
        return self.get_conversations(limit, offset, search)

    def get_item_summary(self, item: Dict[str, Any]) -> str:
        return f"{item['display_name']} - {item.get('last_message', '')[:50]}"

    def _load_call_history(self) -> List[Dict[str, Any]]:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            cur = conn.cursor()
            cur.execute("""
                SELECT m.ZDATE, m.ZCALLTYPE, m.ZCALLDURATION, m.ZSYSTEMTYPE,
                       c.ZINTERLOCUTOR, mem.ZDISPLAYFULLNAME, mem.ZNAME
                FROM ZVIBERMESSAGE m
                LEFT JOIN ZCONVERSATION c ON c.Z_PK = m.ZCONVERSATION
                LEFT JOIN ZMEMBER mem ON mem.Z_PK = c.ZINTERLOCUTOR
                WHERE m.ZSYSTEMTYPE = 'systemCallLog' OR m.ZCALLTYPE IS NOT NULL
                ORDER BY m.ZDATE DESC
            """)
            calls = []
            for row in cur.fetchall():
                display_name = row["ZDISPLAYFULLNAME"] or row["ZNAME"] or "Unknown"
                call_text = self._format_call_entry(dict(row))
                calls.append({
                    "name": display_name,
                    "call_text": call_text or "Call",
                    "timestamp": row["ZDATE"],
                })
            return calls
        finally:
            conn.close()

    def export(self, items: List[Dict[str, Any]], output_path: str, format: str = 'html',
               progress_callback=None, skip_attachments: bool = False, timeline_emitter=None) -> bool:
        if format not in ('html', 'files'):
            raise ValueError(f"Unsupported export format: {format}")
        try:
            self._reset_export_bytes()
            os.makedirs(output_path, exist_ok=True)
            conversations_dir = os.path.join(output_path, "Conversations")
            os.makedirs(conversations_dir, exist_ok=True)
            attachments_dir = os.path.join(output_path, "Viber Attachments")
            os.makedirs(attachments_dir, exist_ok=True)

            used_filenames = set()
            conversation_list = []
            total = len(items) + 1

            for i, item in enumerate(items):
                if isinstance(item, dict):
                    chat_id = item["chat_id"]
                    display_name = item["display_name"]
                    last_message = item.get("last_message", "")
                    last_message_date = item.get("last_message_date", 0)
                    message_count = item.get("message_count", 0)
                else:
                    chat_id = item
                    display_name = f"Chat {chat_id}"
                    last_message = ""
                    last_message_date = 0
                    message_count = 0

                filename_base = display_name.replace("/", "_").replace("\\", "_")
                filename = f"{filename_base}.html"
                if filename in used_filenames:
                    filename = f"{filename_base}_{chat_id}.html"
                used_filenames.add(filename)
                out_file = os.path.join(conversations_dir, filename)

                messages = self._load_messages_for_chat(chat_id)
                if timeline_emitter is not None:
                    self._emit_message_timeline_events(messages, display_name, filename, attachments_dir, timeline_emitter)
                html = self._render_conversation_html(display_name, messages, attachments_dir, skip_attachments)
                with open(out_file, "w", encoding="utf-8") as f:
                    f.write(html)
                self._add_export_bytes(out_file)

                conversation_list.append({
                    "display_name": display_name,
                    "filename": filename,
                    "last_message": last_message,
                    "last_message_date": last_message_date,
                    "message_count": message_count,
                })

                if progress_callback:
                    progress_callback(i + 1, total, display_name)

            index_html = self._render_index_html(conversation_list, output_path)
            index_path = os.path.join(output_path, "Viber.html")
            with open(index_path, "w", encoding="utf-8") as f:
                f.write(index_html)
            self._add_export_bytes(index_path)

            if progress_callback:
                progress_callback(total, total, "Index")
            return True
        except Exception as e:
            print(f"Error exporting Viber: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _message_direction(self, msg: Dict[str, Any]) -> str:
        state = (msg.get("ZSTATE") or "").lower()
        system_type = (msg.get("ZSYSTEMTYPE") or "").lower()
        if system_type == "systemcalllog":
            return "system"
        if state == "received":
            return "received"
        if state:
            return "sent"
        return "system"

    def _emit_message_timeline_events(self, messages: List[Dict[str, Any]], conversation_name: str,
                                      html_filename: str, attachments_dir: str, timeline_emitter) -> None:
        link_hint = f"Viber/Conversations/{html_filename}"
        attachments_rel = "../Viber/Viber Attachments"
        for msg in messages:
            ts_iso = self._format_timestamp_iso(msg.get("ZDATE"))
            if not ts_iso:
                continue
            text = msg.get("ZTEXT") or ""
            call_text = self._format_call_entry(msg) or ""
            body = call_text or text
            details = {
                "conversation": conversation_name,
                "direction": self._message_direction(msg),
                "text": body[:200] if body else "",
            }
            timeline_emitter.emit({
                "timestamp": ts_iso,
                "raw_timestamp": msg.get("ZDATE"),
                "raw_format": "apple_epoch_seconds",
                "source_app": "Viber",
                "source_category": "Viber",
                "event_type": "message",
                "title": conversation_name or "Viber Message",
                "details": details,
                "confidence": "high",
                "raw_source_path": self.db_path,
                "report_anchor": f"msg-{msg.get('Z_PK')}",
                "link_hint": link_hint,
            })
            if msg.get("attachment_name"):
                attach = self._resolve_attachment(msg["attachment_name"], attachments_dir) if attachments_dir else None
                filename = attach.get("file_name") if attach else msg.get("attachment_name")
                if filename:
                    event_type = "file_attachment"
                    if self._is_image_file(filename):
                        event_type = "photo_attachment"
                    elif os.path.splitext(filename)[1].lower() in (".mov", ".mp4", ".m4v", ".avi", ".mkv", ".3gp", ".3gpp"):
                        event_type = "video_attachment"
                    elif os.path.splitext(filename)[1].lower() in (".m4a", ".aac", ".mp3", ".wav", ".aiff", ".amr", ".caf", ".flac", ".opus"):
                        event_type = "audio_attachment"
                    preview_type = None
                    category_bucket = None
                    if event_type.startswith("photo"):
                        preview_type = "image"
                        category_bucket = "Photos"
                    elif event_type.startswith("video"):
                        preview_type = "video"
                        category_bucket = "Videos"
                    elif event_type.startswith("audio"):
                        preview_type = "audio"
                        category_bucket = "Audio"
                    preview_path = f"{attachments_rel}/{filename}" if filename else ""
                    timeline_emitter.emit({
                        "timestamp": ts_iso,
                        "raw_timestamp": msg.get("ZDATE"),
                        "raw_format": "apple_epoch_seconds",
                        "source_app": "Viber",
                        "source_category": "Viber",
                        "event_type": event_type,
                        "title": f"{conversation_name}: {filename}",
                        "details": {
                            "conversation": conversation_name,
                            "filename": filename,
                            "attachment_type": msg.get("attachment_type"),
                            "preview_path": preview_path,
                            "preview_type": preview_type,
                        },
                        "category_bucket": category_bucket,
                        "confidence": "low" if event_type == "file_attachment" else "high",
                        "raw_source_path": msg.get("attachment_name") or "",
                        "report_anchor": f"msg-{msg.get('Z_PK')}",
                        "link_hint": link_hint,
                    })

    def _format_call_entry(self, msg: Dict[str, Any]) -> Optional[str]:
        system_type = (msg.get("ZSYSTEMTYPE") or "").lower()
        call_type = (msg.get("ZCALLTYPE") or "").lower()
        if system_type != "systemcalllog" and not call_type:
            return None

        direction = "Call"
        if call_type.startswith("outgoing"):
            direction = "Outgoing call"
        elif call_type.startswith("incoming"):
            direction = "Incoming call"

        mode = "audio"
        if "video" in call_type:
            mode = "video"

        duration = msg.get("ZCALLDURATION")
        duration_text = ""
        if isinstance(duration, (int, float)) and duration > 0:
            mins = int(duration) // 60
            secs = int(duration) % 60
            duration_text = f" • {mins:d}:{secs:02d}"

        return f"{direction} ({mode}){duration_text}"

    def _render_conversation_html(self, title: str, messages: List[Dict[str, Any]],
                                  attachments_dir: str, skip_attachments: bool) -> str:
        msg_html = []
        for msg in messages:
            direction = self._message_direction(msg)
            body = msg.get("ZTEXT") or ""
            call_text = self._format_call_entry(msg)
            if call_text:
                body = call_text
            system_type = (msg.get("ZSYSTEMTYPE") or "").lower()
            if not body and system_type == "customlocation":
                body = "Shared location"
            timestamp = self._format_viber_timestamp(msg.get("ZDATE"))
            time_str = timestamp.strftime("%m-%d-%Y %I:%M %p") if timestamp else ""

            attachment_html = ""
            if msg.get("attachment_name") and not skip_attachments:
                attach = self._resolve_attachment(msg["attachment_name"], attachments_dir)
                if attach:
                    rel_path = os.path.join("..", "Viber Attachments", attach["file_name"]).replace("\\", "/")
                    if self._is_image_file(attach["file_name"]):
                        attachment_html = (
                            f"<a href=\"{rel_path}\" target=\"_blank\">"
                            f"<img src=\"{rel_path}\" alt=\"attachment\"></a>"
                        )
                    else:
                        attachment_html = (
                            f"<a class=\"file-link\" href=\"{rel_path}\" target=\"_blank\">"
                            f"{self._escape_html(attach['file_name'])}</a>"
                        )
                else:
                    if (msg.get("attachment_type") or "").lower() == "customlocation":
                        attachment_html = "<div class=\"missing-attachment\">Location attachment not available</div>"
                    else:
                        attachment_html = "<div class=\"missing-attachment\">Attachment not found</div>"

            msg_html.append(f"""
            <div class="message {direction}" id="msg-{msg.get('Z_PK')}">
              <div class="bubble">
                <div class="meta">{self._escape_html(time_str)}</div>
                <div class="body">{self._escape_html(body)}</div>
                <div class="attachments">{attachment_html}</div>
              </div>
            </div>
            """)

        call_rows = []
        for call in self._load_call_history():
            ts = self._format_viber_timestamp(call.get("timestamp"))
            ts_str = ts.strftime("%m-%d-%Y %I:%M %p") if ts else ""
            call_rows.append(f"""
            <div class=\"call-row\">
              <div class=\"call-name\">{self._escape_html(call.get('name') or 'Unknown')}</div>
              <div class=\"call-meta\">{self._escape_html(call.get('call_text') or 'Call')}</div>
              <div class=\"call-time\">{self._escape_html(ts_str)}</div>
            </div>
            """)

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Viber Conversation</title>
  <style>
    body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif; background: #f5f6fa; margin: 20px; }}
    .container {{ max-width: 900px; margin: 0 auto; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }}
    .header {{ background: linear-gradient(135deg, #793BAA, #D2BBE3); color: white; padding: 24px; border-radius: 12px 12px 0 0; }}
    .header h1 {{ margin: 0 0 10px; font-size: 32px; font-weight: 600; }}
    .header p {{ margin: 0; font-size: 16px; opacity: 0.9; }}
    .breadcrumbs {{ display: flex; align-items: center; gap: 8px; font-size: 12px; letter-spacing: 0.2px; color: rgba(255,255,255,0.85); margin-bottom: 10px; }}
    .breadcrumbs a {{ color: #fff; text-decoration: none; font-weight: 600; }}
    .breadcrumbs a:hover {{ text-decoration: underline; }}
    .breadcrumbs .back-arrow {{ opacity: 0.6; }}
    .embedded .breadcrumbs {{ display: none; }}
    .messages {{ padding: 20px; }}
    .message {{ margin-bottom: 16px; display: flex; }}
    .highlight-target {{ background-color: #fff3cd; outline: 2px solid #f59e0b; }}
    .highlight-target .bubble {{ background-color: #fff3cd; }}
    .search-hit {{ background: #ffec99; border-radius: 3px; padding: 0 1px; }}
    .search-hit-block {{ background: #fff7d6; border: 2px solid #f59e0b; border-radius: 12px; padding: 4px; }}
    .message.sent {{ justify-content: flex-end; }}
    .message.received {{ justify-content: flex-start; }}
    .message.system {{ justify-content: center; }}
    .bubble {{ max-width: 70%; padding: 10px 14px; border-radius: 12px; background: #f1f5f9; }}
    .sent .bubble {{ background: #ede9fe; }}
    .meta {{ font-size: 11px; color: #6b7280; margin-bottom: 6px; }}
    .body {{ font-size: 14px; line-height: 1.4; }}
    .attachments img {{ max-width: 240px; border-radius: 8px; margin-top: 8px; display: block; }}
    .file-link {{
      display: inline-block;
      margin-top: 8px;
      color: #6d28d9;
      font-size: 13px;
      text-decoration: none;
    }}
    .missing-attachment {{
      margin-top: 8px;
      font-size: 12px;
      color: #b91c1c;
    }}
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Viber.html">Back to conversations</a></div>
      <h1>{self._escape_html(title)}</h1>
    </div>
    <div class="messages">
      {''.join(msg_html)}
    </div>
  </div>
  <script>
    (function() {{
      if (!window.location.hash) return;
      const target = document.querySelector(window.location.hash);
      if (!target) return;
      target.classList.add('highlight-target');
      try {{
        target.scrollIntoView({{ block: 'center' }});
      }} catch (e) {{
        target.scrollIntoView();
      }}
    }})();
  </script>
  <script>
    (function() {{
      const params = new URLSearchParams(window.location.search);
      const term = (params.get('q') || localStorage.getItem('viberLastSearch') || '').trim();
      if (!term) return;

      function escapeRegExp(value) {{
        return value.replace(/[.*+?^${{}}()|[\\]\\\\]/g, '\\\\$&');
      }}

      function highlightInElement(element, query) {{
        const regex = new RegExp(escapeRegExp(query), 'gi');
        const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT, {{
          acceptNode(node) {{
            if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
            const parent = node.parentElement;
            if (!parent) return NodeFilter.FILTER_REJECT;
            if (parent.classList && parent.classList.contains('search-hit')) return NodeFilter.FILTER_REJECT;
            return NodeFilter.FILTER_ACCEPT;
          }}
        }});
        const nodes = [];
        let node;
        while ((node = walker.nextNode())) {{
          if (regex.test(node.nodeValue)) {{
            nodes.push(node);
          }}
        }}
        nodes.forEach(textNode => {{
          const text = textNode.nodeValue;
          const frag = document.createDocumentFragment();
          const local = new RegExp(escapeRegExp(query), 'gi');
          let lastIndex = 0;
          let match;
          while ((match = local.exec(text)) !== null) {{
            const before = text.slice(lastIndex, match.index);
            if (before) frag.appendChild(document.createTextNode(before));
            const mark = document.createElement('mark');
            mark.className = 'search-hit';
            mark.textContent = match[0];
            frag.appendChild(mark);
            lastIndex = match.index + match[0].length;
          }}
          const after = text.slice(lastIndex);
          if (after) frag.appendChild(document.createTextNode(after));
          textNode.parentNode.replaceChild(frag, textNode);
        }});
      }}

      const targets = document.querySelectorAll('.body');
      targets.forEach(el => highlightInElement(el, term));
      document.querySelectorAll('.search-hit').forEach(mark => {{
        const block = mark.closest('.message');
        if (block) block.classList.add('search-hit-block');
      }});
      const first = document.querySelector('.search-hit');
      if (first) {{
        try {{
          first.scrollIntoView({{ block: 'center' }});
        }} catch (e) {{
          first.scrollIntoView();
        }}
      }}
    }})();
  </script>
  <script>
  (function() {{
    try {{
      if (window.parent && window.parent !== window) {{
        window.parent.postMessage({{type: 'device-nav', href: window.location.href}}, '*');
      }}
    }} catch (err) {{}}
  }})();
  </script>
</body>
</html>
"""

    def _render_index_html(self, conversations: List[Dict[str, Any]], output_path: str) -> str:
        rows = []
        search_text_by_file = {}
        for conv in conversations:
            last_msg = conv.get("last_message") or ""
            ts = self._format_viber_timestamp(conv.get("last_message_date"))
            ts_str = ts.strftime("%m-%d-%Y %I:%M %p") if ts else ""
            search_text = ""
            try:
                convo_path = os.path.join(output_path, "Conversations", conv["filename"])
                with open(convo_path, "r", encoding="utf-8", errors="ignore") as convo_f:
                    convo_html = convo_f.read()
                parts = re.findall(r'<div class="body">(.*?)</div>', convo_html, re.S)
                cleaned = []
                for part in parts:
                    text_only = re.sub(r'<[^>]+>', '', part)
                    text_only = html.unescape(text_only).strip()
                    if text_only:
                        cleaned.append(text_only)
                if cleaned:
                    search_text = " ".join(cleaned)[:4000].lower()
            except Exception:
                search_text = ""
            search_text_by_file[conv["filename"]] = search_text
            rows.append(f"""
            <a class="conv" href="Conversations/{conv['filename']}" data-search="{self._escape_html(search_text_by_file.get(conv['filename'], ''))}">
              <div class="title">{self._escape_html(conv['display_name'])}</div>
              <div class="sub">{self._escape_html(last_msg)}</div>
              <div class="meta">{conv.get('message_count', 0)} messages • {self._escape_html(ts_str)}</div>
            </a>
            """)

        call_rows = []
        for call in self._load_call_history():
            ts = self._format_viber_timestamp(call.get("timestamp"))
            ts_str = ts.strftime("%m-%d-%Y %I:%M %p") if ts else ""
            call_rows.append(f"""
            <div class=\"call-row\">
              <div class=\"call-name\">{self._escape_html(call.get('name') or 'Unknown')}</div>
              <div class=\"call-meta\">{self._escape_html(call.get('call_text') or 'Call')}</div>
              <div class=\"call-time\">{self._escape_html(ts_str)}</div>
            </div>
            """)

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Viber Messages</title>
  <style>
    body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif; background: #f5f6fa; margin: 20px; }}
    .page {{ max-width: 900px; margin: 0 auto; }}
      .header {{ background: linear-gradient(135deg, #793BAA, #D2BBE3); color: white; padding: 24px; border-radius: 12px 12px 0 0; }}
      .header h1 {{ margin: 0 0 10px; font-size: 32px; font-weight: 600; }}
      .header p {{ margin: 0; font-size: 16px; opacity: 0.9; }}
      .breadcrumbs {{ display: flex; align-items: center; gap: 8px; font-size: 12px; letter-spacing: 0.2px; color: rgba(255,255,255,0.85); margin-bottom: 10px; }}
      .breadcrumbs a {{ color: #fff; text-decoration: none; font-weight: 600; }}
      .breadcrumbs a:hover {{ text-decoration: underline; }}
      .breadcrumbs .back-arrow {{ opacity: 0.6; }}
      .embedded .breadcrumbs {{ display: none; }}
      .search-box {{
      padding: 20px;
      border-bottom: 1px solid #e5e5e5;
      background: white;
      position: relative;
    }}
    .search-box input {{
      width: 100%;
      padding: 12px 46px 12px 20px;
      border: 1px solid #ddd;
      border-radius: 8px;
      font-size: 16px;
      box-sizing: border-box;
    }}
    .search-box input:focus {{
      outline: none;
      border-color: #7f3bdc;
    }}
    .clear-search {{
      position: absolute;
      right: 24px;
      top: 50%;
      transform: translateY(-50%);
      border: 1px solid #d1d5db;
      background: #f3f4f6;
      color: #111827;
      border-radius: 6px;
      padding: 4px 8px;
      font-size: 12px;
      cursor: pointer;
      display: none;
    }}
    .clear-search.visible {{ display: inline-block; }}
    .list {{ background: white; border-radius: 0 0 12px 12px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }}
    .conv {{ display: block; padding: 16px 18px; border-bottom: 1px solid #eef0f4; text-decoration: none; color: inherit; }}
    .conv:last-child {{ border-bottom: none; }}
    .title {{ font-weight: 600; margin-bottom: 4px; }}
    .sub {{ color: #555; font-size: 13px; margin-bottom: 6px; }}
    .meta {{ font-size: 12px; color: #8a8f98; }}
    .section {{ margin-top: 24px; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }}
    .section h2 {{ margin: 0; padding: 16px 18px; font-size: 18px; border-bottom: 1px solid #eef0f4; }}
    .call-row {{ display: grid; grid-template-columns: 2fr 2fr 1fr; gap: 12px; padding: 12px 18px; border-bottom: 1px solid #eef0f4; font-size: 13px; }}
    .call-row:last-child {{ border-bottom: none; }}
    .call-name {{ font-weight: 600; }}
    .call-meta {{ color: #5b21b6; }}
    .call-time {{ color: #6b7280; }}
    @media (max-width: 900px) {{
      .call-row {{ grid-template-columns: 1fr; }}
    }}
  </style>
</head>
<body>
  <div class="page">
    <div class="header">
      <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Start_Here.html">Back</a></div>
      <h1>Viber Messages</h1>
      <p>Extracted from iOS Backup on {datetime.now().strftime("%B %d, %Y")}</p>
    </div>
    <div class="search-box">
      <input id="searchInput" placeholder="Search conversations">
      <button id="clearSearch" class="clear-search" title="Clear" aria-label="Clear search">X</button>
    </div>
    <div class="list" id="convList">
      {''.join(rows)}
    </div>
    <div class="section">
      <h2>Call History</h2>
      {''.join(call_rows) if call_rows else '<div class="call-row"><div class="call-name">No call records found</div></div>'}
    </div>
  </div>
<script>
const searchInput = document.getElementById('searchInput');
const list = document.getElementById('convList');
const clearBtn = document.getElementById('clearSearch');
function applyFilter() {{
  if (!searchInput || !list) {{
    return;
  }}
  const rawTerm = searchInput.value.trim();
  const term = rawTerm.toLowerCase();
  if (rawTerm) {{
    localStorage.setItem('viberLastSearch', rawTerm);
  }} else {{
    localStorage.removeItem('viberLastSearch');
  }}
  list.querySelectorAll('.conv').forEach(row => {{
    const text = row.innerText.toLowerCase();
    const searchText = (row.getAttribute('data-search') || '').toLowerCase();
    if (!row.dataset.baseHref) {{
      row.dataset.baseHref = row.getAttribute('href');
    }}
    if (rawTerm) {{
      row.setAttribute('href', `${{row.dataset.baseHref}}?q=${{encodeURIComponent(rawTerm)}}`);
    }} else {{
      row.setAttribute('href', row.dataset.baseHref);
    }}
    row.style.display = !term || text.includes(term) || searchText.includes(term) ? '' : 'none';
  }});
  if (clearBtn) {{
    clearBtn.classList.toggle('visible', !!rawTerm);
  }}
}}
if (searchInput && list) {{
  searchInput.addEventListener('input', applyFilter);
  const saved = localStorage.getItem('viberLastSearch') || '';
  if (saved) {{
    searchInput.value = saved;
    applyFilter();
  }}
  window.addEventListener('pageshow', () => {{
    if (searchInput.value.trim()) {{
      applyFilter();
    }}
  }});
}}
if (clearBtn) {{
  clearBtn.addEventListener('click', () => {{
    searchInput.value = '';
    localStorage.removeItem('viberLastSearch');
    applyFilter();
    clearBtn.classList.remove('visible');
    searchInput.focus();
  }});
}}
 </script>
 <script>
  (function() {{
    try {{
      if (window.parent && window.parent !== window) {{
        window.parent.postMessage({{type: 'device-nav-root', href: window.location.href}}, '*');
        window.parent.postMessage({{type: 'device-nav', href: window.location.href}}, '*');
      }}
    }} catch (err) {{}}
  }})();
 </script>
 <script>
  if (window.self !== window.top) {{ document.body.classList.add('embedded'); }}
 </script>
</body>
</html>
"""
