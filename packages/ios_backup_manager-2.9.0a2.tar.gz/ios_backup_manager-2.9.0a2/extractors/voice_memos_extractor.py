#!/usr/bin/env python3
"""
Voice Memos data extractor for iOS backups.

Extracts voice memo recordings from Recordings.db and copies audio files (.m4a).
"""

import sqlite3
import os
import shutil
from typing import List, Dict, Any, Optional
from datetime import datetime
from .base import CategoryDataExtractor


class VoiceMemosExtractor(CategoryDataExtractor):
    """Extract and export voice memos from iOS backup."""

    @staticmethod
    def _count_records_for_db(db_path: str, table_name: str, columns: set) -> int:
        """Return count of records in a specific table with basic filtering."""
        try:
            conn = sqlite3.connect(db_path)
            cur = conn.cursor()
            if "ZPATH" in columns:
                cur.execute(f"SELECT COUNT(*) FROM {table_name} WHERE ZPATH IS NOT NULL AND ZPATH != ''")
            else:
                cur.execute(f"SELECT COUNT(*) FROM {table_name}")
            count = cur.fetchone()[0]
            conn.close()
            return count
        except Exception:
            return 0

    @staticmethod
    def _detect_table_name_for_db(db_path: str) -> str:
        """Detect which table contains voice memos for a given database."""
        conn = sqlite3.connect(db_path)
        cur = conn.cursor()

        # Prefer ZCLOUDRECORDING when it has data
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='ZCLOUDRECORDING'")
        if cur.fetchone():
            cur.execute("SELECT COUNT(*) FROM ZCLOUDRECORDING")
            if cur.fetchone()[0] > 0:
                conn.close()
                return "ZCLOUDRECORDING"

        # Fall back to ZRECORDING when it has data
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='ZRECORDING'")
        if cur.fetchone():
            cur.execute("SELECT COUNT(*) FROM ZRECORDING")
            if cur.fetchone()[0] > 0:
                conn.close()
                return "ZRECORDING"

        # If both exist but empty, prefer ZRECORDING
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='ZRECORDING'")
        if cur.fetchone():
            conn.close()
            return "ZRECORDING"

        conn.close()
        return "ZCLOUDRECORDING"

    @staticmethod
    def _get_available_columns_for_db(db_path: str, table_name: str) -> set:
        """Get list of available columns for a specific table."""
        conn = sqlite3.connect(db_path)
        cur = conn.cursor()
        cur.execute(f"PRAGMA table_info({table_name})")
        columns = {row[1] for row in cur.fetchall()}
        conn.close()
        return columns

    def __init__(self, backup_path: str):
        super().__init__(backup_path)

        # Find voice memos database - try multiple locations for different iOS versions
        # Track which domain we found it in for audio file lookups
        self.voice_memos_domain = None
        self.voice_memos_base_path = None
        self._db_sources = []

        def add_db_source(domain: str, relative_path: str, base_path: str) -> None:
            path = self.find_db_file(domain, relative_path)
            if path:
                self._db_sources.append({
                    "path": path,
                    "domain": domain,
                    "base_path": base_path,
                })

        # App group locations (iOS 13+)
        add_db_source(
            "AppDomainGroup-group.com.apple.VoiceMemos.shared",
            "Recordings/CloudRecordings.db",
            "Recordings"
        )
        add_db_source(
            "AppDomainGroup-group.com.apple.VoiceMemos.shared",
            "Recordings/EncryptedCloudRecordings/EncryptedCloudRecordings.db",
            "Recordings"
        )
        add_db_source(
            "AppDomainGroup-group.com.apple.VoiceMemos.shared",
            "Recordings/Recordings.db",
            "Recordings"
        )

        # Media domain locations
        add_db_source(
            "MediaDomain",
            "Media/Recordings/Recordings.db",
            "Media/Recordings"
        )
        add_db_source(
            "MediaDomain",
            "Library/Recordings/CloudRecordings.db",
            "Library/Recordings"
        )
        add_db_source(
            "MediaDomain",
            "Library/Recordings/EncryptedCloudRecordings/EncryptedCloudRecordings.db",
            "Library/Recordings"
        )
        add_db_source(
            "MediaDomain",
            "Library/Recordings/Recordings.db",
            "Library/Recordings"
        )

        if not self._db_sources:
            raise FileNotFoundError("Voice Memos database not found in backup (tried multiple iOS versions)")

        # Inspect each DB and keep metadata
        for source in self._db_sources:
            source["table_name"] = self._detect_table_name_for_db(source["path"])
            source["columns"] = self._get_available_columns_for_db(source["path"], source["table_name"])
            source["count"] = self._count_records_for_db(
                source["path"], source["table_name"], source["columns"]
            )

        # Pick a primary DB for compatibility (highest record count)
        primary = max(self._db_sources, key=lambda s: s["count"])
        self.recordings_db_path = primary["path"]
        self.voice_memos_domain = primary["domain"]
        self.voice_memos_base_path = primary["base_path"]
        self.table_name = primary["table_name"]
        self._available_columns = primary["columns"]

    def get_count(self) -> int:
        """Get total number of voice memo recordings."""
        if len(self._db_sources) <= 1:
            return self._count_records_for_db(
                self.recordings_db_path, self.table_name, self._available_columns
            )

        total = 0
        for source in self._db_sources:
            total += source["count"]
        return total

    def _get_items_for_db(self, source: Dict[str, Any], limit: Optional[int],
                          offset: int, search: Optional[str]) -> List[Dict[str, Any]]:
        """Fetch items for a single voice memos database."""
        conn = sqlite3.connect(source["path"])
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        table_name = source["table_name"]
        columns = source["columns"]

        # Build column list based on what's available in this database schema
        columns_list = ['Z_PK']
        optional_columns = [
            'ZDATE', 'ZDURATION', 'ZPATH', 'ZCUSTOMLABEL',
            'ZEVICTIONDATE', 'ZENCRYPTED', 'ZITUNESUTRANSACTIONID'
        ]

        for col in optional_columns:
            if col in columns:
                columns_list.append(col)

        query = f"""
            SELECT {', '.join(columns_list)}
            FROM {table_name}
            WHERE 1=1
        """
        params = []

        # Only include recordings with valid paths (not deleted)
        if 'ZPATH' in columns:
            query += " AND ZPATH IS NOT NULL AND ZPATH != ''"

        # Search filter
        if search:
            search_conditions = []
            if 'ZCUSTOMLABEL' in columns:
                search_conditions.append("ZCUSTOMLABEL LIKE ?")
                params.append(f"%{search}%")
            if 'ZPATH' in columns:
                search_conditions.append("ZPATH LIKE ?")
                params.append(f"%{search}%")

            if search_conditions:
                query += " AND (" + " OR ".join(search_conditions) + ")"

        # Order by date (most recent first)
        if 'ZDATE' in columns:
            query += " ORDER BY ZDATE DESC"
        else:
            query += " ORDER BY Z_PK DESC"

        if limit is not None:
            query += f" LIMIT {limit} OFFSET {offset}"

        cur.execute(query, params)
        rows = cur.fetchall()

        recordings = []
        for row in rows:
            z_pk = row['Z_PK']

            def get_col(name, default=None):
                return row[name] if name in columns and row[name] is not None else default

            path = get_col('ZPATH', '')
            filename = os.path.basename(path) if path else f"recording_{z_pk}.m4a"

            audio_path = self._get_audio_file_path(
                path, domain=source["domain"], base_path=source["base_path"]
            ) if path else None
            has_audio = os.path.exists(audio_path) if audio_path else False

            date = get_col('ZDATE')
            if date is not None:
                date = int(date + 978307200)

            recordings.append({
                'z_pk': z_pk,
                'unique_id': f"{source['path']}:{z_pk}",
                'date': date,
                'duration': get_col('ZDURATION', 0.0),
                'path': path,
                'custom_label': get_col('ZCUSTOMLABEL', ''),
                'has_audio': has_audio,
                'filename': filename,
                'eviction_date': get_col('ZEVICTIONDATE'),
                'encrypted': get_col('ZENCRYPTED', 0)
            })

        conn.close()
        return recordings

    def get_items(self, limit: Optional[int] = None, offset: int = 0,
                  search: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get voice memo recordings with pagination and optional search.

        Returns list of recording dictionaries with fields:
        - z_pk: Recording ID (primary key)
        - date: Unix timestamp (Apple epoch)
        - duration: Duration in seconds
        - path: Relative path to audio file
        - custom_label: User-defined recording name
        - has_audio: Whether audio file exists in backup
        - filename: Audio filename (extracted from path)
        """
        if len(self._db_sources) <= 1:
            return self._get_items_for_db(self._db_sources[0], limit, offset, search)

        # Multi-DB: aggregate and then apply paging
        all_items = []
        for source in self._db_sources:
            all_items.extend(self._get_items_for_db(source, None, 0, search))

        def sort_key(item):
            date = item.get('date')
            return (date is None, -(date or 0), item.get('z_pk') or 0)

        all_items.sort(key=sort_key)

        if offset:
            all_items = all_items[offset:]
        if limit is not None:
            all_items = all_items[:limit]
        return all_items

    def _get_audio_file_path(self, relative_path: str,
                             domain: Optional[str] = None,
                             base_path: Optional[str] = None) -> Optional[str]:
        """
        Get physical path to audio file for a voice memo.

        Args:
            relative_path: Path from ZPATH field (can be full iOS path or just filename)
                          e.g., "/var/mobile/Media/Recordings/20230815 143022.m4a"
                          or "20230815 143022.m4a"

        Returns:
            Physical file path in backup, or None if not found
        """
        if not relative_path:
            return None

        # Extract filename from path (ZPATH may contain full iOS path)
        # Path can be like "/var/mobile/Media/Recordings/20230815 143022.m4a"
        # or just "20230815 143022.m4a"
        filename = os.path.basename(relative_path)

        # Use the domain and base path we detected in __init__ (or explicit overrides)
        # For newer iOS: AppDomainGroup-group.com.apple.VoiceMemos.shared/Recordings/
        # For older iOS: MediaDomain/Media/Recordings/
        domain = domain or self.voice_memos_domain
        base_path = base_path or self.voice_memos_base_path
        full_path = f"{base_path}/{filename}"

        audio_file = self.find_file_in_backup(domain, full_path)
        return audio_file

    @staticmethod
    def _memo_unique_id(memo: Dict[str, Any]):
        return memo.get('unique_id', memo.get('z_pk'))

    def export(self, items: List[Dict[str, Any]], output_path: str,
               format: str = 'audio', progress_callback=None, timeline_emitter=None) -> bool:
        """
        Export voice memo recordings with audio files.

        Creates:
        - Audio files (original filenames or custom labels)
        - CSV report
        - HTML report

        Args:
            items: List of voice memos to export
            output_path: Output directory
            format: Export format (always exports audio + reports)
            progress_callback: Optional callback(current, total, item_name) -> bool

        Returns:
            True if export succeeded
        """
        try:
            self._reset_export_bytes()
            # Use output_path as the directory (already includes "Voice Memos" from extraction manager)
            output_dir = output_path
            os.makedirs(output_dir, exist_ok=True)

            # Create audio subdirectory
            audio_dir = os.path.join(output_dir, 'audio')
            os.makedirs(audio_dir, exist_ok=True)

            # Calculate total operations
            # For each recording: copy audio + CSV + HTML
            total = len(items) + len(items) + 2
            current = 0

            # Copy audio files
            for i, memo in enumerate(items):
                if memo['has_audio']:
                    current = i
                    if progress_callback:
                        label = memo['custom_label'] or memo['filename']
                        if not progress_callback(current + 1, total, f"Audio: {label}"):
                            return False

                    audio_path = self._get_audio_file_path(memo['path'])
                    if audio_path and os.path.exists(audio_path):
                        # Determine output filename
                        if memo['custom_label']:
                            # Use custom label if available
                            # Sanitize label for filename
                            label = memo['custom_label']
                            label = label.replace('/', '_').replace('\\', '_').replace(':', '_')
                            # Keep original extension or use .m4a
                            ext = os.path.splitext(memo['filename'])[1] or '.m4a'
                            filename = f"{label}{ext}"
                        else:
                            # Use original filename
                            filename = memo['filename']

                        # Add date prefix if not already present
                        if memo['date'] and not filename[0].isdigit():
                            date_str = datetime.fromtimestamp(memo['date']).strftime("%Y%m%d_%H%M%S")
                            name, ext = os.path.splitext(filename)
                            filename = f"{date_str}_{name}{ext}"

                        dest_path = os.path.join(audio_dir, filename)

                        # Handle duplicate filenames
                        counter = 1
                        original_dest = dest_path
                        while os.path.exists(dest_path):
                            name, ext = os.path.splitext(original_dest)
                            dest_path = f"{name}_{counter}{ext}"
                            counter += 1

                        # Use copyfile for faster copying
                        shutil.copyfile(audio_path, dest_path)
                        self._add_export_bytes(dest_path)

            # Export CSV
            csv_file = os.path.join(output_dir, 'voice_memos_report.csv')
            if not self._export_csv(items, csv_file, progress_callback, len(items), total):
                return False

            # Export HTML
            html_file = os.path.join(output_dir, 'Voice_Memos.html')
            if not self._export_html(items, html_file, progress_callback, len(items) + 1, total):
                return False

            if timeline_emitter is not None:
                self._emit_timeline_events(items, timeline_emitter)

            self._add_export_bytes(csv_file)
            self._add_export_bytes(html_file)

            return True

        except Exception as e:
            print(f"Error exporting voice memos: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _export_csv(self, items: List[Dict[str, Any]], csv_file: str,
                    progress_callback, offset: int, total: int) -> bool:
        """Export voice memos list to CSV."""
        try:
            import csv

            with open(csv_file, 'w', encoding='utf-8', newline='') as f:
                writer = csv.writer(f)

                writer.writerow([
                    'Date',
                    'Name',
                    'Duration',
                    'Filename',
                    'Has Audio'
                ])

                if progress_callback:
                    if not progress_callback(offset + 1, total, "Generating CSV"):
                        return False

                for memo in items:
                    writer.writerow([
                        self._format_timestamp(memo['date']),
                        memo['custom_label'] or '(Untitled)',
                        self._format_duration(memo['duration']),
                        memo['filename'],
                        'Yes' if memo['has_audio'] else 'No'
                    ])

            return True

        except Exception as e:
            print(f"Error exporting CSV: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _export_html(self, items: List[Dict[str, Any]], html_file: str,
                     progress_callback, offset: int, total: int) -> bool:
        """Export voice memos list to HTML with embedded audio players."""
        try:
            with open(html_file, 'w', encoding='utf-8') as f:
                f.write("""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voice Memos</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;
            margin: 20px;
            background-color: #f5f5f5;
        }
        .header {
            background: linear-gradient(135deg, #E21B01 0%, #FDDCD7 100%);
            color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .header h1 {
            margin: 0 0 10px 0;
            font-size: 32px;
            font-weight: 600;
        }
        .breadcrumbs {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            letter-spacing: 0.2px;
            color: rgba(255,255,255,0.85);
            margin-bottom: 10px;
        }
        .breadcrumbs a {
            color: #fff;
            text-decoration: none;
            font-weight: 600;
        }
        .breadcrumbs a:hover {
            text-decoration: underline;
        }
        .breadcrumbs .back-arrow {
            opacity: 0.6;
        }
        .embedded .breadcrumbs {
            display: none;
        }
        .header p {
            margin: 0;
            font-size: 16px;
            opacity: 0.9;
        }
        .header-total {
            margin-top: 8px;
            font-size: 14px;
            opacity: 0.85;
        }
        .export-info {
            color: #666;
            font-size: 14px;
            margin-bottom: 30px;
        }
        /* NEW: main content wrapper */
        .page-container {
            max-width: 1200px;
            margin: 20px auto;   /* center horizontally, space from top */
            padding: 0;
        }
        .memo-list {
            background: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .memo-item {
            border-bottom: 1px solid #eee;
            padding: 15px 0;
        }
        .highlight-target {
            background-color: #fff3cd;
            outline: 2px solid #f59e0b;
        }
        .memo-item:last-child {
            border-bottom: none;
        }
        .memo-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
        }
        .memo-title {
            font-weight: bold;
            color: #333;
            font-size: 16px;
        }
        .memo-date {
            color: #666;
            font-size: 14px;
        }
        .memo-duration {
            color: #007AFF;
            font-size: 14px;
            font-weight: 500;
        }
        .memo-filename {
            color: #999;
            font-size: 12px;
            margin-top: 4px;
        }
        .memo-audio-player {
            margin-top: 8px;
            width: 100%;
            max-width: 500px;
        }
        audio {
            width: 100%;
            height: 32px;
        }
        .badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 500;
            margin-left: 8px;
            background-color: #34C759;
            color: white;
        }
        @media print {
            body {
                background-color: white;
            }
            .memo-list {
                box-shadow: none;
            }
        }
    </style>
</head>
<body>
    <div class="page-container">
    <div class="header">
        <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Start_Here.html">Back</a></div>
        <h1>Voice Memos</h1>
        <p>Extracted from iOS Backup on """ + datetime.now().strftime("%B %d, %Y") + """</p>
        <div class="header-total">Total voice memos: """ + f"{len(items):,}" + """</div>
    </div>
    <div class="memo-list">
""")

                if progress_callback:
                    if not progress_callback(offset + 1, total, "Generating HTML"):
                        return False

                for memo in items:
                    # Get title (custom label or filename)
                    title = memo['custom_label'] if memo['custom_label'] else memo['filename']

                    # Build audio filename for reference
                    if memo['custom_label']:
                        label = memo['custom_label']
                        label = label.replace('/', '_').replace('\\', '_').replace(':', '_')
                        ext = os.path.splitext(memo['filename'])[1] or '.m4a'
                        audio_filename = f"{label}{ext}"
                    else:
                        audio_filename = memo['filename']

                    # Add date prefix if not already present
                    if memo['date'] and not audio_filename[0].isdigit():
                        date_str = datetime.fromtimestamp(memo['date']).strftime("%Y%m%d_%H%M%S")
                        name, ext = os.path.splitext(audio_filename)
                        audio_filename = f"{date_str}_{name}{ext}"

                    f.write(f"""        <div class="memo-item" id="memo-{self._memo_unique_id(memo)}">
            <div class="memo-header">
                <div>
                    <span class="memo-title">{self._escape_html(title)}</span>
                    {('<span class="badge">Audio</span>' if memo['has_audio'] else '')}
                </div>
                <div class="memo-date">{self._escape_html(self._format_timestamp(memo['date']))}</div>
            </div>
            <div class="memo-duration">Duration: {self._format_duration(memo['duration'])}</div>
            <div class="memo-filename">{self._escape_html(memo['filename'])}</div>
""")

                    # Add audio player if audio file exists
                    if memo['has_audio']:
                        f.write(f"""            <div class="memo-audio-player">
                <audio controls preload="metadata">
                    <source src="audio/{self._escape_html(audio_filename)}" type="audio/mp4">
                    Your browser does not support the audio element.
                </audio>
            </div>
""")

                    f.write("""        </div>
""")

                f.write("""    </div>
</div>
<script>
    (function() {
        if (!window.location.hash) return;
        const target = document.querySelector(window.location.hash);
        if (!target) return;
        target.classList.add('highlight-target');
        try {
            target.scrollIntoView({ block: 'center' });
        } catch (e) {
            target.scrollIntoView();
        }
    })();
</script>
<script>
    if (window.self !== window.top) {
        document.body.classList.add('embedded');
    }
</script>
</body>
</html>
""")

            return True

        except Exception as e:
            print(f"Error exporting HTML: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _format_timestamp(self, timestamp: Optional[int]) -> str:
        """Format Unix timestamp for display."""
        if timestamp is None:
            return "N/A"

        try:
            dt = datetime.fromtimestamp(timestamp)
            return dt.strftime("%m-%d-%Y %I:%M:%S %p")
        except:
            return str(timestamp)

    def _format_timestamp_iso(self, timestamp: Optional[int]) -> Optional[str]:
        if timestamp is None:
            return None
        try:
            return datetime.fromtimestamp(timestamp).isoformat()
        except Exception:
            return None

    def _emit_timeline_events(self, items: List[Dict[str, Any]], timeline_emitter) -> None:
        for memo in items:
            ts_iso = self._format_timestamp_iso(memo.get('date'))
            if not ts_iso:
                continue
            title = memo.get('custom_label') or memo.get('filename') or 'Voice Memo'
            details = {
                'filename': memo.get('filename') or '',
                'duration': self._format_duration(memo.get('duration')),
                'has_audio': bool(memo.get('has_audio')),
                'path': memo.get('path') or '',
            }
            timeline_emitter.emit({
                'timestamp': ts_iso,
                'raw_timestamp': memo.get('date'),
                'raw_format': 'unix_seconds',
                'source_app': 'Voice Memos',
                'source_category': 'Voice Memos',
                'event_type': 'voice_memo',
                'title': title,
                'details': details,
                'confidence': 'medium',
                'raw_source_path': self.recordings_db_path,
                'report_anchor': f"memo-{self._memo_unique_id(memo)}",
                'link_hint': 'Voice Memos/Voice_Memos.html',
            })

    def _format_duration(self, seconds: Optional[float]) -> str:
        """Format duration in seconds to human-readable string."""
        if seconds is None or seconds == 0:
            return "0s"

        seconds = int(seconds)
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        secs = seconds % 60

        if hours > 0:
            return f"{hours}h {minutes}m {secs}s"
        elif minutes > 0:
            return f"{minutes}m {secs}s"
        return f"{secs}s"

    def _escape_html(self, text: str) -> str:
        """Escape HTML special characters."""
        if not text:
            return ""
        text = str(text)
        text = text.replace('&', '&amp;')
        text = text.replace('<', '&lt;')
        text = text.replace('>', '&gt;')
        text = text.replace('"', '&quot;')
        text = text.replace("'", '&#39;')
        return text

    def get_item_summary(self, item: Dict[str, Any]) -> str:
        """Get short summary for list view."""
        title = item['custom_label'] if item['custom_label'] else item['filename']
        date_str = self._format_timestamp(item['date'])
        duration = self._format_duration(item['duration'])

        return f"{title} - {duration} ({date_str})"
