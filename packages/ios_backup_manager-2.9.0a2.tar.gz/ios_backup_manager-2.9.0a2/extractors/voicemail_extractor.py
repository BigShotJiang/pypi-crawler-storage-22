#!/usr/bin/env python3
"""
Voicemail data extractor for iOS backups.

Extracts voicemail messages from voicemail.db and copies audio files (.amr) and transcripts.
"""

import sqlite3
import os
import shutil
import plistlib
from typing import List, Dict, Any, Optional
from datetime import datetime
from .base import CategoryDataExtractor

# Media conversion imports (optional dependencies)
try:
    import imageio_ffmpeg
    import subprocess

    # Get FFmpeg executable from imageio_ffmpeg
    FFMPEG_EXE = imageio_ffmpeg.get_ffmpeg_exe()
    AUDIO_CONVERSION_AVAILABLE = True
except ImportError:
    FFMPEG_EXE = None
    AUDIO_CONVERSION_AVAILABLE = False


class VoicemailExtractor(CategoryDataExtractor):
    """Extract and export voicemail messages from iOS backup."""

    def __init__(self, backup_path: str):
        super().__init__(backup_path)

        # Find voicemail database
        self.voicemail_db_path = self.find_db_file(
            "HomeDomain",
            "Library/Voicemail/voicemail.db"
        )

        if not self.voicemail_db_path:
            raise FileNotFoundError("Voicemail database not found in backup")

        # Cache available columns for this database schema
        self._available_columns = self._get_available_columns()

    def _get_available_columns(self) -> set:
        """Get list of available columns in the voicemail table."""
        conn = sqlite3.connect(self.voicemail_db_path)
        cur = conn.cursor()
        cur.execute("PRAGMA table_info(voicemail)")
        columns = {row[1] for row in cur.fetchall()}
        conn.close()
        return columns

    def get_count(self) -> int:
        """Get total number of voicemail messages."""
        conn = sqlite3.connect(self.voicemail_db_path)
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM voicemail")
        count = cur.fetchone()[0]
        conn.close()
        return count

    def get_items(self, limit: Optional[int] = None, offset: int = 0,
                  search: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get voicemail messages with pagination and optional search.

        Returns list of voicemail dictionaries with fields:
        - rowid: Voicemail ID
        - sender: Phone number of sender
        - callback_num: Callback number (if available)
        - receiver: Phone number of receiver
        - date: Unix timestamp
        - duration: Duration in seconds
        - flags: Voicemail flags (read/unread, etc.)
        - has_audio: Whether audio file exists
        - has_transcript: Whether transcript exists
        - transcript_text: Transcript text (if available)
        """
        conn = sqlite3.connect(self.voicemail_db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        # Build column list based on what's available in this database schema
        # Core columns that should always exist
        columns = ['ROWID', 'date', 'sender']

        # Optional columns with their defaults
        optional_columns = [
            'remote_uid', 'token', 'callback_num', 'duration',
            'expiration', 'trashed_date', 'flags', 'receiver', 'label', 'uuid'
        ]

        # Add optional columns if they exist
        for col in optional_columns:
            if col in self._available_columns:
                columns.append(col)

        query = f"""
            SELECT {', '.join(columns)}
            FROM voicemail
            WHERE 1=1
        """
        params = []

        if search:
            search_conditions = []
            if 'sender' in self._available_columns:
                search_conditions.append("sender LIKE ?")
                params.append(f"%{search}%")
            if 'callback_num' in self._available_columns:
                search_conditions.append("callback_num LIKE ?")
                params.append(f"%{search}%")

            if search_conditions:
                query += " AND (" + " OR ".join(search_conditions) + ")"

        query += " ORDER BY date DESC"

        if limit is not None:
            query += f" LIMIT {limit} OFFSET {offset}"

        cur.execute(query, params)
        rows = cur.fetchall()

        voicemails = []
        for row in rows:
            rowid = row['ROWID']

            # Check if audio file exists
            audio_path = self._get_audio_file_path(rowid)
            has_audio = os.path.exists(audio_path) if audio_path else False

            # Check if transcript exists (but don't decode yet for performance)
            transcript_path = self._get_transcript_file_path(rowid)
            has_transcript = os.path.exists(transcript_path) if transcript_path else False

            # Store transcript path for lazy decoding
            # Decoding is expensive, so we only do it when displaying or exporting
            transcript_text = None

            # Helper function to safely get column value
            def get_col(name, default=''):
                return row[name] if name in self._available_columns else default

            voicemail = {
                'rowid': rowid,
                'sender': row['sender'] or 'Unknown',
                'callback_num': get_col('callback_num'),
                'receiver': get_col('receiver'),
                'date': row['date'],
                'duration': get_col('duration', 0) or 0,
                'flags': get_col('flags', 0) or 0,
                'has_audio': has_audio,
                'has_transcript': has_transcript,
                'transcript_text': transcript_text,
                'token': get_col('token'),
                'uuid': get_col('uuid')
            }
            voicemails.append(voicemail)

        conn.close()
        return voicemails

    def _get_audio_file_path(self, rowid: int) -> Optional[str]:
        """Get path to audio file for a voicemail."""
        audio_file = self.find_file_in_backup(
            "HomeDomain",
            f"Library/Voicemail/{rowid}.amr"
        )
        return audio_file

    def _get_transcript_file_path(self, rowid: int) -> Optional[str]:
        """Get path to transcript file for a voicemail."""
        transcript_file = self.find_file_in_backup(
            "HomeDomain",
            f"Library/Voicemail/{rowid}.transcript"
        )
        return transcript_file

    def _decode_transcript(self, transcript_path: str) -> Optional[str]:
        """
        Decode voicemail transcript from NSKeyedArchiver binary plist.

        Args:
            transcript_path: Path to .transcript file

        Returns:
            Transcript text, or None if decoding fails
        """
        try:
            with open(transcript_path, 'rb') as f:
                data = f.read()

            # Parse as NSKeyedArchiver plist
            plist_data = plistlib.loads(data)
            objects = plist_data.get('$objects', [])

            # The transcript text is usually one of the longer strings
            # in the $objects array. Search for strings longer than 50 characters
            # and return the longest one, which is likely the transcript.
            candidates = []
            for obj in objects:
                if isinstance(obj, str) and len(obj) > 50:
                    candidates.append(obj)

            if candidates:
                return max(candidates, key=len)

            return None

        except Exception:
            # If decoding fails, return None
            # The original .transcript file will still be exported
            return None

    def _is_ffmpeg_available(self) -> bool:
        """Check if audio conversion is available via pydub and imageio-ffmpeg."""
        return AUDIO_CONVERSION_AVAILABLE

    def _convert_amr_to_mp3(self, amr_path: str, mp3_path: str) -> bool:
        """
        Convert AMR audio file to MP3 using FFmpeg via imageio-ffmpeg.

        Args:
            amr_path: Path to source AMR file
            mp3_path: Path to output MP3 file

        Returns:
            True if conversion succeeded, False otherwise
        """
        if not AUDIO_CONVERSION_AVAILABLE or not FFMPEG_EXE:
            return False

        try:
            # Prepare subprocess arguments to hide console window on Windows
            kwargs = {
                'stdout': subprocess.DEVNULL,
                'stderr': subprocess.DEVNULL,
                'check': True
            }

            # On Windows, prevent console window from appearing
            if hasattr(subprocess, 'CREATE_NO_WINDOW'):
                kwargs['creationflags'] = subprocess.CREATE_NO_WINDOW

            # Use FFmpeg directly for conversion
            subprocess.run([
                FFMPEG_EXE,
                '-i', amr_path,           # Input file
                '-ar', '22050',           # Sample rate (22.05 kHz, good for voice)
                '-b:a', '64k',            # Audio bitrate (64 kbps)
                '-y',                     # Overwrite output file
                mp3_path                  # Output file
            ], **kwargs)

            return True
        except Exception as e:
            pass  # AMR conversion failed
            return False

    def export(self, items: List[Dict[str, Any]], output_path: str,
               format: str = 'audio', progress_callback=None, timeline_emitter=None) -> bool:
        """
        Export voicemail messages with audio files and transcripts.

        Creates:
        - Audio files ({sender}_{date}.amr)
        - Transcript files ({sender}_{date}.txt)
        - CSV report
        - HTML report

        Args:
            items: List of voicemails to export
            output_path: Output directory
            format: Export format (always exports audio + reports)
            progress_callback: Optional callback(current, total, item_name) -> bool

        Returns:
            True if export succeeded
        """
        try:
            self._reset_export_bytes()
            # Use output_path as-is - caller determines the directory structure
            output_dir = output_path
            os.makedirs(output_dir, exist_ok=True)

            # Create subdirectories
            audio_dir = os.path.join(output_dir, 'audio')
            transcripts_dir = os.path.join(output_dir, 'transcripts')
            os.makedirs(audio_dir, exist_ok=True)
            os.makedirs(transcripts_dir, exist_ok=True)

            # Check if audio conversion is available
            has_conversion = self._is_ffmpeg_available()
            if has_conversion:
                pass  # Audio conversion available
            else:
                print("[WARNING] Audio conversion not available - audio files will be exported as AMR format")
                print("[WARNING] AMR files cannot be played in web browsers")
                print("[WARNING] Install required packages: pip install pydub imageio-ffmpeg")

            # Calculate total operations
            # For each voicemail: copy audio + copy transcript + CSV + HTML
            total = len(items) * 2 + len(items) * 2  # audio/transcript copies + CSV/HTML writes
            current = 0

            # Track which voicemails have MP3 files (for HTML generation)
            voicemail_audio_formats = {}  # rowid -> 'mp3' or 'amr'

            # Copy audio files and transcripts
            for i, vm in enumerate(items):
                # Copy and convert audio file
                if vm['has_audio']:
                    current = i * 2
                    if progress_callback:
                        if not progress_callback(current + 1, total, f"Audio: {vm['sender']}"):
                            return False

                    audio_path = self._get_audio_file_path(vm['rowid'])
                    if audio_path:
                        # Create sanitized filename
                        date_str = datetime.fromtimestamp(vm['date']).strftime("%Y%m%d_%H%M%S")
                        sender_clean = vm['sender'].replace('+', '').replace(' ', '')

                        # Always copy the original AMR file
                        amr_filename = f"{sender_clean}_{date_str}.amr"
                        amr_dest_path = os.path.join(audio_dir, amr_filename)
                        # Use copyfile for faster copying
                        shutil.copyfile(audio_path, amr_dest_path)
                        self._add_export_bytes(amr_dest_path)

                        # Try to convert to MP3 if conversion is available
                        if has_conversion:
                            mp3_filename = f"{sender_clean}_{date_str}.mp3"
                            mp3_dest_path = os.path.join(audio_dir, mp3_filename)

                            if self._convert_amr_to_mp3(amr_dest_path, mp3_dest_path):
                                voicemail_audio_formats[vm['rowid']] = 'mp3'
                                self._add_export_bytes(mp3_dest_path)
                            else:
                                voicemail_audio_formats[vm['rowid']] = 'amr'
                        else:
                            voicemail_audio_formats[vm['rowid']] = 'amr'

                # Copy transcript (decode from binary plist to readable text)
                if vm['has_transcript']:
                    current = i * 2 + 1
                    if progress_callback:
                        if not progress_callback(current + 1, total, f"Transcript: {vm['sender']}"):
                            return False

                    transcript_path = self._get_transcript_file_path(vm['rowid'])
                    if transcript_path:
                        date_str = datetime.fromtimestamp(vm['date']).strftime("%Y%m%d_%H%M%S")
                        sender_clean = vm['sender'].replace('+', '').replace(' ', '')
                        transcript_filename = f"{sender_clean}_{date_str}.txt"
                        dest_path = os.path.join(transcripts_dir, transcript_filename)

                        # Decode the transcript from NSKeyedArchive binary plist
                        transcript_text = self._decode_transcript(transcript_path)

                        if transcript_text:
                            # Write decoded text to file
                            with open(dest_path, 'w', encoding='utf-8') as f:
                                f.write(transcript_text)
                            self._add_export_bytes(dest_path)
                        else:
                            # If decoding fails, copy the raw file as fallback
                            # Use copyfile for faster copying
                            shutil.copyfile(transcript_path, dest_path)
                            self._add_export_bytes(dest_path)

            # Export CSV
            csv_file = os.path.join(output_dir, 'voicemail_report.csv')
            if not self._export_csv(items, csv_file, progress_callback, len(items) * 2, total):
                return False

            # Export HTML
            html_file = os.path.join(output_dir, 'Voicemail.html')
            if not self._export_html(items, html_file, voicemail_audio_formats, progress_callback,
                                     len(items) * 2 + len(items), total):
                return False

            if timeline_emitter is not None:
                self._emit_timeline_events(items, timeline_emitter)

            self._add_export_bytes(csv_file)
            self._add_export_bytes(html_file)

            return True

        except Exception as e:
            print(f"Error exporting voicemail: {e}")
            import traceback
            traceback.print_exc()
            return False


    def _export_csv(self, items: List[Dict[str, Any]], csv_file: str,
                    progress_callback, offset: int, total: int) -> bool:
        """Export voicemail list to CSV."""
        try:
            import csv

            with open(csv_file, 'w', encoding='utf-8', newline='') as f:
                writer = csv.writer(f)

                writer.writerow([
                    'Date',
                    'From',
                    'To',
                    'Duration',
                    'Has Audio',
                    'Has Transcript',
                    'Transcript Preview'
                ])

                for i, vm in enumerate(items):
                    current = offset + i
                    if progress_callback:
                        if not progress_callback(current + 1, total, f"CSV: {vm['sender']}"):
                            return False

                    # Decode transcript on-demand for CSV export
                    transcript_text = None
                    if vm['has_transcript']:
                        transcript_path = self._get_transcript_file_path(vm['rowid'])
                        if transcript_path:
                            transcript_text = self._decode_transcript(transcript_path)

                    # Get transcript preview (first 100 chars)
                    transcript_preview = ''
                    if transcript_text:
                        transcript_preview = transcript_text[:100]
                        if len(transcript_text) > 100:
                            transcript_preview += '...'

                    writer.writerow([
                        self._format_timestamp(vm['date']),
                        vm['sender'],
                        vm['receiver'],
                        self._format_duration(vm['duration']),
                        'Yes' if vm['has_audio'] else 'No',
                        'Yes' if vm['has_transcript'] else 'No',
                        transcript_preview
                    ])

            return True

        except Exception as e:
            print(f"Error exporting CSV: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _export_html(self, items: List[Dict[str, Any]], html_file: str,
                     audio_formats: Dict[int, str],
                     progress_callback, offset: int, total: int) -> bool:
        """
        Export voicemail list to HTML.

        Args:
            items: List of voicemail items
            html_file: Output HTML file path
            audio_formats: Dictionary mapping rowid to audio format ('mp3' or 'amr')
            progress_callback: Progress callback function
            offset: Progress offset
            total: Total progress steps
        """
        try:
            with open(html_file, 'w', encoding='utf-8') as f:
                f.write("""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voicemail</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;
            margin: 20px;
            background-color: #f5f5f5;
        }
        .header {
            background: linear-gradient(135deg, #1C3E35 0%, #99F2D1 100%);
            color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .header h1 {
            margin: 0 0 10px 0;
            font-size: 32px;
            font-weight: 600;
        }
        .breadcrumbs {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            letter-spacing: 0.2px;
            color: rgba(255,255,255,0.85);
            margin-bottom: 10px;
        }
        .breadcrumbs a {
            color: #fff;
            text-decoration: none;
            font-weight: 600;
        }
        .breadcrumbs a:hover {
            text-decoration: underline;
        }
        .breadcrumbs .back-arrow {
            opacity: 0.6;
        }
        .embedded .breadcrumbs {
            display: none;
        }
        .header p {
            margin: 0;
            font-size: 16px;
            opacity: 0.9;
        }
        .header-total {
            margin-top: 8px;
            font-size: 14px;
            opacity: 0.85;
        }
        .export-info {
            color: #666;
            font-size: 14px;
            margin-bottom: 30px;
        }
        .search-box {
            position: relative;
            margin-bottom: 20px;
        }
        .search-box input {
            width: 100%;
            padding: 12px 46px 12px 16px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            box-sizing: border-box;
        }
        .search-box input:focus {
            outline: none;
            border-color: #007AFF;
        }
        .clear-search {
            position: absolute;
            right: 24px;
            top: 50%;
            transform: translateY(-50%);
            border: 1px solid #d1d5db;
            background: #f3f4f6;
            color: #111827;
            border-radius: 6px;
            padding: 4px 8px;
            font-size: 12px;
            cursor: pointer;
            display: none;
        }
        .clear-search.visible { display: inline-block; }
        /* NEW: main content wrapper */
        .page-container {
            max-width: 1200px;
            margin: 20px auto;   /* center horizontally, space from top */
            padding: 0;
        }
        .voicemail-list {
            background: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .voicemail-item {
            border-bottom: 1px solid #eee;
            padding: 15px 0;
        }
        .highlight-target {
            background-color: #fff3cd;
            outline: 2px solid #f59e0b;
        }
        .voicemail-item:last-child {
            border-bottom: none;
        }
        .voicemail-item.hidden {
            display: none;
        }
        .vm-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
        }
        .vm-from {
            font-weight: bold;
            color: #333;
            font-size: 16px;
        }
        .vm-date {
            color: #666;
            font-size: 14px;
        }
        .vm-duration {
            color: #007AFF;
            font-size: 14px;
            font-weight: 500;
        }
        .vm-transcript {
            background-color: #f9f9f9;
            padding: 12px;
            border-radius: 6px;
            margin-top: 8px;
            font-size: 14px;
            line-height: 1.5;
            color: #333;
        }
        .vm-audio-player {
            margin-top: 8px;
            width: 100%;
            max-width: 400px;
        }
        audio {
            width: 100%;
            height: 32px;
        }
        .badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 500;
            margin-left: 8px;
        }
        .badge-audio {
            background-color: #34C759;
            color: white;
        }
        .badge-transcript {
            background-color: #5856D6;
            color: white;
        }
        .no-results {
            display: none;
            text-align: center;
            color: #999;
            font-size: 14px;
            margin: 20px 0 10px;
        }
        .no-results.visible {
            display: block;
        }
        @media print {
            body {
                background-color: white;
            }
            .voicemail-list {
                box-shadow: none;
            }
        }
    </style>
</head>
<body>
    <div class="page-container">
    <div class="header">
        <div class="breadcrumbs"><span class="back-arrow">&larr;</span><a href="../Start_Here.html">Back</a></div>
        <h1>Voicemail</h1>
        <p>Extracted from iOS Backup on """ + datetime.now().strftime("%B %d, %Y") + """</p>
        <div class="header-total">Total voicemails: """ + f"{len(items):,}" + """</div>
    </div>
    <div class="search-box">
        <input type="text" id="searchInput" placeholder="Search voicemails..." onkeyup="filterVoicemails()">
        <button id="clearSearch" class="clear-search" title="Clear" aria-label="Clear search">X</button>
    </div>
    <div class="voicemail-list">
""")

                for i, vm in enumerate(items):
                    current = offset + i
                    if progress_callback:
                        if not progress_callback(current + 1, total, f"HTML: {vm['sender']}"):
                            return False

                    # Decode transcript on-demand for HTML export
                    transcript_text = None
                    if vm['has_transcript']:
                        transcript_path = self._get_transcript_file_path(vm['rowid'])
                        if transcript_path:
                            transcript_text = self._decode_transcript(transcript_path)

                    # Build audio filename for reference
                    date_str = datetime.fromtimestamp(vm['date']).strftime("%Y%m%d_%H%M%S")
                    sender_clean = vm['sender'].replace('+', '').replace(' ', '')

                    # Determine audio format to use (prefer MP3 if available)
                    audio_format = audio_formats.get(vm['rowid'], 'amr')
                    audio_filename = f"{sender_clean}_{date_str}.{audio_format}"
                    audio_mime = 'audio/mpeg' if audio_format == 'mp3' else 'audio/amr'

                    formatted_date = self._format_timestamp(vm['date'])
                    search_parts = [
                        vm['sender'],
                        vm.get('callback_num') or '',
                        vm.get('receiver') or '',
                        formatted_date,
                        transcript_text or ''
                    ]
                    search_blob = ' '.join([part for part in search_parts if part]).lower()

                    f.write(f"""        <div class="voicemail-item" id="vm-{vm['rowid']}" data-search="{self._escape_html(search_blob)}">
            <div class="vm-header">
                <div>
                    <span class="vm-from">{self._escape_html(vm['sender'])}</span>
                    {('<span class="badge badge-audio">Audio</span>' if vm['has_audio'] else '')}
                    {('<span class="badge badge-transcript">Transcript</span>' if vm['has_transcript'] else '')}
                </div>
                <div class="vm-date">{self._escape_html(formatted_date)}</div>
            </div>
            <div class="vm-duration">Duration: {self._format_duration(vm['duration'])}</div>
""")

                    # Add audio player if audio file exists
                    if vm['has_audio']:
                        f.write(f"""            <div class="vm-audio-player">
                <audio controls preload="metadata">
                    <source src="audio/{self._escape_html(audio_filename)}" type="{audio_mime}">
                    Your browser does not support the audio element.
                </audio>
            </div>
""")

                    if transcript_text:
                        f.write(f"""            <div class="vm-transcript">{self._escape_html(transcript_text)}</div>
""")

                    f.write("""        </div>
""")

                f.write("""    </div>
    <div class="no-results" id="noResults">No voicemails found matching your search</div>
</div>
<script>
    function filterVoicemails() {
        const input = document.getElementById('searchInput');
        const filter = input.value.toLowerCase();
        const items = document.querySelectorAll('.voicemail-item');
        const noResults = document.getElementById('noResults');
        let visibleCount = 0;

        items.forEach(item => {
            const haystack = item.getAttribute('data-search') || '';
            if (!filter || haystack.includes(filter)) {
                item.classList.remove('hidden');
                visibleCount += 1;
            } else {
                item.classList.add('hidden');
            }
        });

        if (noResults) {
            if (!visibleCount && filter) {
                noResults.classList.add('visible');
            } else {
                noResults.classList.remove('visible');
            }
        }
    }
</script>
<script>
    const vmSearchInput = document.getElementById('searchInput');
    const vmClearBtn = document.getElementById('clearSearch');
    if (vmSearchInput && vmClearBtn) {
        const toggleClear = () => vmClearBtn.classList.toggle('visible', !!vmSearchInput.value);
        vmSearchInput.addEventListener('input', toggleClear);
        vmClearBtn.addEventListener('click', () => {
            vmSearchInput.value = '';
            toggleClear();
            if (typeof filterVoicemails === 'function') {
                filterVoicemails();
            }
            vmSearchInput.focus();
        });
        toggleClear();
    }
</script>
<script>
    (function() {
        if (!window.location.hash) return;
        const target = document.querySelector(window.location.hash);
        if (!target) return;
        target.classList.add('highlight-target');
        try {
            target.scrollIntoView({ block: 'center' });
        } catch (e) {
            target.scrollIntoView();
        }
    })();
</script>
<script>
    if (window.self !== window.top) {
        document.body.classList.add('embedded');
    }
</script>
</body>
</html>
""")

            return True

        except Exception as e:
            print(f"Error exporting HTML: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _format_timestamp(self, timestamp: Optional[int]) -> str:
        """Format Unix timestamp for display."""
        if timestamp is None:
            return "N/A"

        try:
            dt = datetime.fromtimestamp(timestamp)
            return dt.strftime("%m-%d-%Y %I:%M:%S %p")
        except:
            return str(timestamp)

    def _format_timestamp_iso(self, timestamp: Optional[int]) -> Optional[str]:
        if timestamp is None:
            return None
        try:
            return datetime.fromtimestamp(timestamp).isoformat()
        except Exception:
            return None

    def _emit_timeline_events(self, items: List[Dict[str, Any]], timeline_emitter) -> None:
        for vm in items:
            ts_iso = self._format_timestamp_iso(vm.get('date'))
            if not ts_iso:
                continue
            details = {
                'sender': vm.get('sender') or 'Unknown',
                'receiver': vm.get('receiver') or '',
                'callback_num': vm.get('callback_num') or '',
                'duration': self._format_duration(vm.get('duration')),
                'has_audio': bool(vm.get('has_audio')),
                'has_transcript': bool(vm.get('has_transcript')),
            }
            timeline_emitter.emit({
                'timestamp': ts_iso,
                'raw_timestamp': vm.get('date'),
                'raw_format': 'unix_seconds',
                'source_app': 'Voicemail',
                'source_category': 'Voicemail',
                'event_type': 'voicemail',
                'title': f"Voicemail from {details['sender']}",
                'details': details,
                'confidence': 'medium',
                'raw_source_path': self.voicemail_db_path,
                'report_anchor': f"vm-{vm.get('rowid')}",
                'link_hint': 'Voicemail/Voicemail.html',
            })

    def _format_duration(self, seconds: Optional[int]) -> str:
        """Format duration in seconds to human-readable string."""
        if seconds is None or seconds == 0:
            return "0s"

        minutes = seconds // 60
        secs = seconds % 60

        if minutes > 0:
            return f"{minutes}m {secs}s"
        return f"{secs}s"

    def _escape_html(self, text: str) -> str:
        """Escape HTML special characters."""
        if not text:
            return ""
        text = str(text)
        text = text.replace('&', '&amp;')
        text = text.replace('<', '&lt;')
        text = text.replace('>', '&gt;')
        text = text.replace('"', '&quot;')
        text = text.replace("'", '&#39;')
        return text

    def get_item_summary(self, item: Dict[str, Any]) -> str:
        """Get short summary for list view."""
        sender = item['sender']
        date_str = self._format_timestamp(item['date'])
        duration = self._format_duration(item['duration'])

        return f"From {sender} - {duration} ({date_str})"
