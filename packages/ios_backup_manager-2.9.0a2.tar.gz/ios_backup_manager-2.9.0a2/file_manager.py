#!/usr/bin/env python3
"""
Cross-platform file manager operations.
Provides consistent file manager integration across Windows, macOS, and Linux.
"""

import platform
import subprocess
import os


class FileManager:
    """Cross-platform file manager operations"""

    @staticmethod
    def open_folder(path: str):
        """
        Open folder in the system's default file manager.

        Args:
            path: Path to folder to open

        Note:
            - Windows: Opens in Explorer
            - macOS: Opens in Finder
            - Linux: Opens in default file manager (xdg-open, nautilus, etc.)
        """
        if not os.path.exists(path):
            print(f"[WARNING] Path does not exist: {path}")
            return

        try:
            if platform.system() == 'Windows':
                # Windows: Open in Explorer
                subprocess.Popen(['explorer', path])
            elif platform.system() == 'Darwin':
                # macOS: Open in Finder
                subprocess.Popen(['open', path])
            else:
                # Linux: Try common file managers
                for file_manager in ['xdg-open', 'nautilus', 'dolphin', 'thunar', 'pcmanfm']:
                    try:
                        subprocess.Popen([file_manager, path])
                        return
                    except FileNotFoundError:
                        continue
                print(f"[WARNING] No file manager found to open: {path}")
        except Exception as e:
            print(f"[ERROR] Failed to open folder: {e}")

    @staticmethod
    def open_and_select(path: str):
        """
        Open folder and select/highlight the specified file or folder.

        Args:
            path: Path to file or folder to select

        Note:
            - Windows: Opens Explorer with file selected
            - macOS: Opens Finder with file revealed
            - Linux: Opens parent folder (no native "select" support)
        """
        if not os.path.exists(path):
            print(f"[WARNING] Path does not exist: {path}")
            return

        try:
            if platform.system() == 'Windows':
                # Windows: Open Explorer and select file
                subprocess.run(['explorer', '/select,', os.path.normpath(path)])
            elif platform.system() == 'Darwin':
                # macOS: Reveal file in Finder
                subprocess.run(['open', '-R', path])
            else:
                # Linux: No native "select" - open parent folder
                parent_dir = os.path.dirname(path) if os.path.isfile(path) else path
                FileManager.open_folder(parent_dir)
        except Exception as e:
            print(f"[ERROR] Failed to open and select: {e}")

    @staticmethod
    def show_in_file_manager(path: str, select: bool = False):
        """
        Show path in file manager, optionally selecting it.

        Args:
            path: Path to show
            select: If True, select/highlight the item; if False, just open folder

        Note:
            Convenience method that calls either open_and_select() or open_folder()
        """
        if select:
            FileManager.open_and_select(path)
        else:
            if os.path.isfile(path):
                path = os.path.dirname(path)
            FileManager.open_folder(path)
