import argparse
import getpass
import os
import sys
import json
from typing import Dict, List, Optional, Tuple

from backup_access import BackupAccess, is_encrypted_backup
from full_extraction_manager import FullExtractionManager
from ios_backup_manager import __version__

def _get_build_number() -> str:
    candidates = [
        os.path.join(os.getcwd(), "build_number.txt"),
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "build_number.txt"),
    ]
    for path in candidates:
        try:
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    value = f.read().strip()
                    return value or "dev"
        except Exception:
            continue
    return "dev"


def _is_ffs_container(path: str) -> bool:
    docs = os.path.join(path, "Documents")
    lib = os.path.join(path, "Library")
    return os.path.isdir(docs) and os.path.isdir(lib)


def _validate_backup_path(backup_path: str) -> Tuple[bool, List[str], bool]:
    required = ["Manifest.plist", "Manifest.db"]
    missing = [name for name in required if not os.path.exists(os.path.join(backup_path, name))]
    if len(missing) == 0:
        return True, missing, False
    if _is_ffs_container(backup_path):
        return True, missing, True
    return False, missing, False


def _prompt_password(backup_path: str) -> str:
    prompt = f"Password for encrypted backup '{backup_path}': "
    password = getpass.getpass(prompt)
    return password.strip()


def _get_backup_access(backup_path: str, password: Optional[str]) -> Optional[BackupAccess]:
    if not is_encrypted_backup(backup_path):
        return None
    if not password:
        password = _prompt_password(backup_path)
    if not password:
        raise ValueError("Password required for encrypted backup.")
    return BackupAccess(backup_path, password=password)


def _parse_categories(raw: Optional[str]) -> List[str]:
    if not raw:
        return []
    if raw.strip().lower() == "all":
        return []
    aliases = {
        "browser": "browsers",
    }
    categories = []
    for item in raw.split(","):
        name = item.strip()
        if not name:
            continue
        key = name.lower()
        categories.append(aliases.get(key, name))
    return categories


def _build_options(args: argparse.Namespace) -> Dict[str, object]:
    case_info = {
        "case_number": args.case_number,
        "evidence_number": args.evidence_number,
        "examiner": args.examiner,
        "department": args.department,
        "location": args.location,
    }
    case_info = {k: v for k, v in case_info.items() if v}
    return {
        "convert_heic": args.convert_heic,
        "organize_by_date": args.organize_by_date,
        "organize_by_category": args.organize_by_category,
        "generate_master_report": args.generate_master_report,
        "generate_summary": args.generate_summary,
        "allow_passwords_plain": args.allow_passwords_plain,
        "audit_mode": args.audit_mode,
        "audit_verbose": args.audit_verbose,
        "audit_hash_reports": args.audit_hash_reports,
        "audit_hash_payloads": args.audit_hash_payloads,
        "include_cached_thumbnails": args.include_cached_thumbnails,
        "app_version": __version__,
        "build_number": _get_build_number(),
        "timezone": args.timezone,
        "extraction_type": "Full",
        "case_info": case_info,
    }


def _progress_printer():
    last_state = {"category_id": None, "status": None}

    def _callback(update: Dict[str, object]) -> None:
        status = update.get("status")
        category = update.get("category")
        category_id = update.get("category_id")
        item_current = update.get("item_current", 0)
        item_total = update.get("item_total", 0)

        if status == "extracting" and category_id != last_state["category_id"]:
            print(f"[{category}] extracting...")
            last_state["category_id"] = category_id
            last_state["status"] = status
            return

        if status == "completed":
            print(f"[{category}] completed ({item_total} items)")
            last_state["status"] = status
            return

        if status == "failed":
            print(f"[{category}] failed")
            last_state["status"] = status
            return

        if status == "skipped":
            print(f"[{category}] skipped")
            last_state["status"] = status
            return

        if item_total and status == "extracting":
            if item_current == item_total or item_current % 250 == 0:
                print(f"[{category}] {item_current}/{item_total}")

    return _callback


def _audit_dump(output_dir: str) -> None:
    path = os.path.join(output_dir, "Audit", "audit_log.ndjson")
    if not os.path.exists(path):
        legacy = os.path.join(output_dir, "audit_log.ndjson")
        if os.path.exists(legacy):
            path = legacy
    if not os.path.exists(path):
        print("Audit log not found.")
        return
    last_run_end = None
    last_run_id = None
    last_inputs = None
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    record = json.loads(line)
                except Exception:
                    continue
                if record.get("event") == "run_end":
                    last_run_end = record
                    last_run_id = record.get("run_id")
                elif record.get("event") == "inputs_hashed":
                    last_inputs = record
    except Exception as exc:
        print(f"Failed to read audit log: {exc}")
        return

    if not last_run_end:
        print("No run_end entry found in audit log.")
        return

    category_count = 0
    output_hashed = 0
    payload_hashed = 0
    categories = []
    if last_run_id:
        try:
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        record = json.loads(line)
                    except Exception:
                        continue
                    if record.get("run_id") != last_run_id:
                        continue
                    if record.get("event") == "category_end":
                        category_count += 1
                        categories.append(record)
                    elif record.get("event") == "output_hashed":
                        output_hashed += 1
                    elif record.get("event") == "payloads_hashed":
                        payload_hashed += 1
        except Exception:
            pass

    print("Audit summary:")
    print(f"  run_id: {last_run_id or 'unknown'}")
    print(f"  status: {last_run_end.get('status', 'unknown')}")
    print(f"  total_items: {last_run_end.get('total_items', 0)}")
    print(f"  duration_sec: {last_run_end.get('duration_sec', 0)}")
    if last_inputs:
        manifest_hash = last_inputs.get("manifest_sha256", "")
        info_hash = last_inputs.get("info_plist_sha256", "")
        if manifest_hash or info_hash:
            print("  input_hashes:")
            if manifest_hash:
                print(f"    Manifest.db: {manifest_hash}")
            if info_hash:
                print(f"    Info.plist: {info_hash}")
    print(f"  categories: {category_count}")
    print(f"  output_hashed: {output_hashed}")
    print(f"  payloads_hashed: {payload_hashed}")
    if categories:
        print("  category_details:")
        for record in categories:
            name = record.get("category_name", record.get("category_id", ""))
            status = record.get("status", "")
            count = record.get("count", 0)
            print(f"    - {name}: {status} ({count})")


def _list_categories(backup_path: str, password: Optional[str], allow_passwords_plain: bool = False) -> int:
    access = _get_backup_access(backup_path, password)
    manager = FullExtractionManager(
        backup_path,
        output_base_dir=".",
        backup_access=access,
        options={"allow_passwords_plain": allow_passwords_plain},
    )
    categories = manager.get_available_categories()
    for cat_id, info in categories.items():
        status = "available" if info.get("available") else "missing"
        count = info.get("count", 0)
        name = info.get("display_name", cat_id)
        print(f"{cat_id}: {name} ({status}, count={count})")
    return 0


def _extract(args: argparse.Namespace) -> int:
    ok, missing, is_ffs = _validate_backup_path(args.backup)
    if not ok:
        print(f"Invalid backup path. Missing: {', '.join(missing)}", file=sys.stderr)
        return 2

    categories = _parse_categories(args.categories)
    if is_ffs:
        if not categories or any(cat != "snapchat" for cat in categories):
            print("FFS container mode only supports the snapchat extractor. Please pass --categories snapchat.", file=sys.stderr)
            return 2
        if is_encrypted_backup(args.backup):
            print("FFS container mode does not support encrypted iTunes backups.", file=sys.stderr)
            return 2
    options = _build_options(args)
    access = _get_backup_access(args.backup, args.password)
    manager = FullExtractionManager(
        args.backup,
        args.output,
        categories=categories or None,
        options=options,
        backup_access=access,
        experimental_categories=set(args.experimental_categories or []),
    )
    callback = _progress_printer()
    if args.parallel:
        result = manager.extract_all_parallel(progress_callback=callback)
    else:
        result = manager.extract_all(progress_callback=callback)
    if args.audit_dump:
        _audit_dump(args.output)
    success = all(item.get("status") == "success" for item in result.get("results", {}).values())
    return 0 if success else 1


def _find_backups(root: str, max_depth: int) -> List[str]:
    root = os.path.abspath(root)
    matches = []
    for current, dirs, files in os.walk(root):
        rel = os.path.relpath(current, root)
        depth = 0 if rel == "." else rel.count(os.sep) + 1
        if depth > max_depth:
            dirs[:] = []
            continue
        if "Manifest.plist" in files and "Manifest.db" in files:
            matches.append(current)
    return matches


def _list_backups(root: str, max_depth: int) -> int:
    backups = _find_backups(root, max_depth)
    if not backups:
        print("No backups found.")
        return 1
    for path in backups:
        print(path)
    return 0


def _menu() -> int:
    while True:
        print("\n=== iOS Backup Manager ===")
        print("1) Extract data")
        print("2) List categories")
        print("3) Scan for backups")
        print("4) Quit")
        choice = input("Select an option: ").strip()
        if choice == "1":
            backup = input("Backup path: ").strip()
            output = input("Output path: ").strip()
            print("Available categories:")
            for cat_id, meta in FullExtractionManager.CATEGORY_REGISTRY.items():
                print(f"  - {cat_id}: {meta[0]}")
            categories = input("Categories (comma list or 'all'): ").strip()
            password = None
            if is_encrypted_backup(backup):
                password = _prompt_password(backup)
            parser = _build_parser()
            args = parser.parse_args(
                ["extract", "--backup", backup, "--output", output, "--categories", categories]
            )
            args.password = password
            args.generate_master_report = not args.no_master_report
            args.generate_summary = bool(getattr(args, "summary", False)) and not args.no_summary
            return _extract(args)
        if choice == "2":
            backup = input("Backup path: ").strip()
            password = None
            if is_encrypted_backup(backup):
                password = _prompt_password(backup)
            return _list_categories(backup, password)
        if choice == "3":
            root = input("Root path: ").strip()
            depth = input("Max depth (default 4): ").strip()
            max_depth = int(depth) if depth else 4
            return _list_backups(root, max_depth)
        if choice == "4":
            return 0
        print("Invalid choice.")


def gui_main() -> None:
    if sys.platform != "win32":
        print("GUI is only available on Windows.")
        raise SystemExit(1)
    from backup_merger_gui import main as gui_entry
    gui_entry()


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="iosbackup",
        description="iOS Backup Manager CLI",
    )
    build_number = _get_build_number()
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__} (Build {build_number})",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    extract = sub.add_parser("extract", help="Extract data from a backup")
    extract.add_argument("--backup", required=True, help="Backup directory")
    extract.add_argument("--output", required=True, help="Output directory")
    extract.add_argument(
        "--categories",
        default="all",
        help="Comma-separated list of categories or 'all'",
    )
    extract.add_argument("--password", help="Backup password (encrypted backups)")
    extract.add_argument("--parallel", action="store_true", default=True, help="Enable parallel extraction")
    extract.add_argument("--no-parallel", action="store_false", dest="parallel", help="Disable parallel extraction")
    extract.add_argument("--convert-heic", action="store_true", default=True, help="Convert HEIC to JPG")
    extract.add_argument("--no-convert-heic", action="store_false", dest="convert_heic", help="Disable HEIC conversion")
    extract.add_argument("--organize-by-date", action="store_true", default=True, help="Organize photos by date")
    extract.add_argument(
        "--no-organize-by-date",
        action="store_false",
        dest="organize_by_date",
        help="Disable photo date organization",
    )
    extract.add_argument("--organize-by-category", action="store_true", default=True, help="Create category subfolders")
    extract.add_argument(
        "--no-organize-by-category",
        action="store_false",
        dest="organize_by_category",
        help="Disable category subfolders",
    )
    extract.add_argument("--no-master-report", action="store_true", help="Skip master report generation")
    extract.add_argument("--summary", action="store_true", help="Generate extraction summary")
    extract.add_argument("--no-summary", action="store_true", help="Skip extraction summary")
    extract.add_argument(
        "--include-cached-thumbnails",
        action="store_true",
        help="Include cached thumbnails in Photos & Videos export",
    )
    extract.add_argument(
        "--allow-passwords-plain",
        action="store_true",
        help="Allow passwords extraction on non-encrypted backups",
    )
    extract.add_argument(
        "--experimental-category",
        dest="experimental_categories",
        action="append",
        default=[],
        help="Enable experimental category (CLI only)",
    )
    extract.add_argument(
        "--audit-mode",
        choices=["minimal", "forensic"],
        default="minimal",
        help="Audit logging profile (default: minimal)",
    )
    extract.add_argument(
        "--audit-verbose",
        action="store_true",
        help="Enable verbose audit logging (forensic mode only)",
    )
    extract.add_argument(
        "--audit-hash-reports",
        action="store_true",
        help="Hash report outputs (forensic mode only)",
    )
    extract.add_argument(
        "--audit-hash-payloads",
        action="store_true",
        help="Hash extracted payloads (forensic mode only)",
    )
    extract.add_argument(
        "--audit-dump",
        action="store_true",
        help="Print a summary of the most recent audit log entries",
    )
    extract.add_argument("--timezone", default="UTC", help="Timezone label to record in reports (default: UTC)")
    extract.add_argument("--case-number", default="", help="Optional case number for reports/audit")
    extract.add_argument("--evidence-number", default="", help="Optional evidence number for reports/audit")
    extract.add_argument("--examiner", default="", help="Optional examiner name for reports/audit")
    extract.add_argument("--department", default="", help="Optional department for reports/audit")
    extract.add_argument("--location", default="", help="Optional location for reports/audit")

    list_cat = sub.add_parser("list-categories", help="List available categories in backup")
    list_cat.add_argument("--backup", required=True, help="Backup directory")
    list_cat.add_argument("--password", help="Backup password (encrypted backups)")
    list_cat.add_argument(
        "--allow-passwords-plain",
        action="store_true",
        help="List passwords category even for non-encrypted backups",
    )

    list_backups = sub.add_parser("list-backups", help="Scan for backups in a root directory")
    list_backups.add_argument("--root", required=True, help="Root directory to scan")
    list_backups.add_argument("--max-depth", type=int, default=4, help="Max depth to scan")

    audit_dump = sub.add_parser("audit-dump", help="Print summary of audit log in an output directory")
    audit_dump.add_argument("--output", required=True, help="Output directory containing Audit/audit_log.ndjson")

    sub.add_parser("menu", help="Interactive menu")

    return parser


def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()
    if args.command == "extract":
        args.generate_master_report = not args.no_master_report
        args.generate_summary = bool(getattr(args, "summary", False)) and not args.no_summary
        raise SystemExit(_extract(args))
    if args.command == "list-categories":
        raise SystemExit(_list_categories(args.backup, args.password, args.allow_passwords_plain))
    if args.command == "list-backups":
        raise SystemExit(_list_backups(args.root, args.max_depth))
    if args.command == "audit-dump":
        _audit_dump(args.output)
        raise SystemExit(0)
    if args.command == "menu":
        raise SystemExit(_menu())
    parser.print_help()
    raise SystemExit(2)
