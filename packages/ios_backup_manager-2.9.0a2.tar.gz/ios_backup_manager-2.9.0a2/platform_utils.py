#!/usr/bin/env python3
"""
Platform detection and cross-platform utilities.
Provides consistent platform detection across the application.
"""

import platform
import sys


class Platform:
    """Platform detection utilities"""

    @staticmethod
    def is_windows():
        """Check if running on Windows"""
        return platform.system() == 'Windows'

    @staticmethod
    def is_macos():
        """Check if running on macOS"""
        return platform.system() == 'Darwin'

    @staticmethod
    def is_linux():
        """Check if running on Linux"""
        return platform.system() == 'Linux'

    @staticmethod
    def get_platform_name():
        """
        Get platform name.

        Returns:
            str: 'Windows', 'macOS', or 'Linux'
        """
        system = platform.system()
        if system == 'Darwin':
            return 'macOS'
        return system

    @staticmethod
    def get_default_backup_locations():
        """
        Get platform-specific default iOS backup locations.

        Returns:
            list: List of default backup directory paths
        """
        import os

        if Platform.is_windows():
            return [
                os.path.expandvars('%APPDATA%\\Apple Computer\\MobileSync\\Backup'),
                os.path.expandvars('%USERPROFILE%\\Apple\\MobileSync\\Backup')
            ]
        elif Platform.is_macos():
            return [
                os.path.expanduser('~/Library/Application Support/MobileSync/Backup')
            ]
        else:  # Linux
            return [
                os.path.expanduser('~/.local/share/MobileSync/Backup'),
                os.path.expanduser('~/snap/apple-music/common/MobileSync/Backup')
            ]
