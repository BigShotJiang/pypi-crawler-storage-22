#!/usr/bin/env python3
"""Call History preview window for displaying call records."""

import tkinter as tk
from tkinter import ttk
from datetime import datetime, timezone
from .base import CategoryPreviewWindow


class CallHistoryPreviewWindow(CategoryPreviewWindow):
    """Preview window for call history records."""

    def get_item_id(self, item):
        """Get unique ID for a call record."""
        return item['call_id']

    def display_item_details(self, item):
        """Display call details in the detail pane."""
        # Clear existing content
        for widget in self.detail_content.winfo_children():
            widget.destroy()

        # Create scrollable frame
        canvas = tk.Canvas(self.detail_content, bg='white', highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.detail_content, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Phone number / address
        address_label = tk.Label(
            scrollable_frame,
            text=item['address'],
            font=('Segoe UI', 20, 'bold'),
            bg='white',
            fg='#333'
        )
        address_label.pack(anchor='w', padx=20, pady=(20, 10))

        # Call type and service badges
        badge_frame = tk.Frame(scrollable_frame, bg='white')
        badge_frame.pack(anchor='w', padx=20, pady=5)

        # Call type badge with color
        if "Incoming" in item['call_type']:
            type_color = '#34C759'  # Green
            type_icon = '📞 '
        elif "Outgoing" in item['call_type']:
            type_color = '#007AFF'  # Blue
            type_icon = '📱 '
        elif "Missed" in item['call_type']:
            type_color = '#FF3B30'  # Red
            type_icon = '📵 '
        else:
            type_color = '#999'  # Gray
            type_icon = '📞 '

        type_badge = tk.Label(
            badge_frame,
            text=f"{type_icon}{item['call_type']}",
            bg=type_color,
            fg='white',
            font=('Segoe UI', 10, 'bold'),
            padx=10,
            pady=4
        )
        type_badge.pack(side='left', padx=(0, 5))

        # Service badge
        service_badge = tk.Label(
            badge_frame,
            text=item['service'],
            bg='#E5E5EA',
            fg='#333',
            font=('Segoe UI', 10),
            padx=10,
            pady=4
        )
        service_badge.pack(side='left')

        # Separator
        sep1 = ttk.Separator(scrollable_frame, orient='horizontal')
        sep1.pack(fill='x', padx=20, pady=15)

        # Call details
        details_frame = tk.Frame(scrollable_frame, bg='white')
        details_frame.pack(anchor='w', padx=20, pady=5, fill='x')

        # Date/Time
        date_label = tk.Label(
            details_frame,
            text='Date/Time:',
            font=('Segoe UI', 11, 'bold'),
            bg='white',
            fg='#666',
            width=15,
            anchor='w'
        )
        date_label.grid(row=0, column=0, sticky='w', pady=8)

        date_value = tk.Label(
            details_frame,
            text=self._format_timestamp(item['date']),
            font=('Segoe UI', 11),
            bg='white',
            fg='#333',
            anchor='w'
        )
        date_value.grid(row=0, column=1, sticky='w', pady=8, padx=10)

        # Duration
        duration_label = tk.Label(
            details_frame,
            text='Duration:',
            font=('Segoe UI', 11, 'bold'),
            bg='white',
            fg='#666',
            width=15,
            anchor='w'
        )
        duration_label.grid(row=1, column=0, sticky='w', pady=8)

        duration_value = tk.Label(
            details_frame,
            text=self._format_duration(item['duration']),
            font=('Segoe UI', 11),
            bg='white',
            fg='#333',
            anchor='w'
        )
        duration_value.grid(row=1, column=1, sticky='w', pady=8, padx=10)

        # Read status
        if not item['read']:
            sep2 = ttk.Separator(scrollable_frame, orient='horizontal')
            sep2.pack(fill='x', padx=20, pady=15)

            unread_label = tk.Label(
                scrollable_frame,
                text='⚠ Unread Call',
                font=('Segoe UI', 10),
                bg='#FFF3CD',
                fg='#856404',
                padx=10,
                pady=5
            )
            unread_label.pack(anchor='w', padx=20, pady=5)

        # Pack canvas and scrollbar
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Bind mousewheel
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

        canvas.bind_all("<MouseWheel>", _on_mousewheel)

    def _format_timestamp(self, timestamp):
        """Format Apple/Unix timestamp for display."""
        if timestamp is None:
            return "N/A"

        try:
            # iOS call timestamps are in Mac absolute time (seconds since 2001-01-01)
            # But may also be Unix timestamps in some versions
            if timestamp > 978307200:  # After 2001-01-01 in Unix time
                # Likely Unix timestamp
                dt = datetime.fromtimestamp(timestamp)
            else:
                # Mac absolute time - convert to Unix
                mac_epoch = datetime(2001, 1, 1, tzinfo=timezone.utc).timestamp()
                unix_timestamp = mac_epoch + timestamp
                dt = datetime.fromtimestamp(unix_timestamp)

            return dt.strftime("%B %d, %Y at %I:%M:%S %p")
        except:
            return str(timestamp)

    def _format_duration(self, seconds):
        """Format call duration in seconds to human-readable string."""
        if seconds is None or seconds == 0:
            return "0 seconds"

        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = int(seconds % 60)

        parts = []
        if hours > 0:
            parts.append(f"{hours} hour{'s' if hours != 1 else ''}")
        if minutes > 0:
            parts.append(f"{minutes} minute{'s' if minutes != 1 else ''}")
        if secs > 0 or len(parts) == 0:
            parts.append(f"{secs} second{'s' if secs != 1 else ''}")

        return ", ".join(parts)

    def get_display_text(self, item):
        """Get text to display in the list for this item."""
        # Format: "Type: Number (Time)"
        call_type = item['call_type']
        address = item['address']
        if len(address) > 20:
            address = address[:17] + "..."

        # Short time format for list
        timestamp = item['date']
        try:
            if timestamp > 978307200:
                dt = datetime.fromtimestamp(timestamp)
            else:
                mac_epoch = datetime(2001, 1, 1, tzinfo=timezone.utc).timestamp()
                unix_timestamp = mac_epoch + timestamp
                dt = datetime.fromtimestamp(unix_timestamp)
            time_str = dt.strftime("%m/%d/%y %I:%M %p")
        except:
            time_str = "Unknown"

        return f"{call_type}: {address}\n{time_str}"

    def get_default_export_extension(self) -> str:
        """Default extension for call history export."""
        return '.csv'

    def get_export_filetypes(self) -> list:
        """File types for call history export."""
        return [
            ('CSV Files', '*.csv'),
            ('All Files', '*.*')
        ]
