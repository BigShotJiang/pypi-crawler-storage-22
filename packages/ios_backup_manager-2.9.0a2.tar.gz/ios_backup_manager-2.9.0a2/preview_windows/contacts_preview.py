#!/usr/bin/env python3
"""
Contacts preview window implementation.

Displays contacts from iOS backup with search, detail view, and vCard export.
"""

import tkinter as tk
from tkinter import scrolledtext
from .base import CategoryPreviewWindow


class ContactsPreviewWindow(CategoryPreviewWindow):
    """Preview window for contacts data."""

    def get_item_id(self, item):
        """Get unique ID for a contact (ROWID)."""
        return item['rowid']

    def display_item_details(self, item):
        """Display contact details in the detail pane."""
        # Clear existing content
        for widget in self.detail_content.winfo_children():
            widget.destroy()

        # Create scrollable detail view
        canvas = tk.Canvas(self.detail_content, bg="white", highlightthickness=0)
        scrollbar = tk.Scrollbar(self.detail_content, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg="white")

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Build contact details
        # Name section
        name_frame = tk.Frame(scrollable_frame, bg="white")
        name_frame.pack(fill=tk.X, padx=15, pady=(15, 5))

        name_parts = []
        if item['first_name']:
            name_parts.append(item['first_name'])
        if item['last_name']:
            name_parts.append(item['last_name'])

        full_name = ' '.join(name_parts) if name_parts else "(No Name)"

        tk.Label(
            name_frame,
            text=full_name,
            font=("Arial", 18, "bold"),
            bg="white",
            anchor=tk.W
        ).pack(fill=tk.X)

        if item['organization']:
            tk.Label(
                name_frame,
                text=item['organization'],
                font=("Arial", 12),
                bg="white",
                fg="#7f8c8d",
                anchor=tk.W
            ).pack(fill=tk.X)

        # Separator
        tk.Frame(scrollable_frame, height=1, bg="#ecf0f1").pack(fill=tk.X, padx=15, pady=10)

        # Phone numbers
        if item['phones']:
            self._add_detail_section(scrollable_frame, "📞 Phone Numbers", item['phones'])

        # Email addresses
        if item['emails']:
            self._add_detail_section(scrollable_frame, "✉️ Email Addresses", item['emails'])

        # Addresses
        if item['addresses']:
            self._add_detail_section(scrollable_frame, "🏠 Addresses", item['addresses'], is_address=True)

        # Metadata
        metadata_frame = tk.Frame(scrollable_frame, bg="white")
        metadata_frame.pack(fill=tk.X, padx=15, pady=(15, 5))

        tk.Label(
            metadata_frame,
            text="ℹ️ Metadata",
            font=("Arial", 10, "bold"),
            bg="white",
            anchor=tk.W
        ).pack(fill=tk.X)

        metadata_text = f"Contact ID: {item['rowid']}"
        if item['created']:
            metadata_text += f"\nCreated: {self._format_timestamp(item['created'])}"
        if item['modified']:
            metadata_text += f"\nModified: {self._format_timestamp(item['modified'])}"

        tk.Label(
            metadata_frame,
            text=metadata_text,
            font=("Arial", 9),
            bg="white",
            fg="#95a5a6",
            anchor=tk.W,
            justify=tk.LEFT
        ).pack(fill=tk.X, padx=10)

    def _add_detail_section(self, parent, title, items, is_address=False):
        """Add a detail section with title and items."""
        section_frame = tk.Frame(parent, bg="white")
        section_frame.pack(fill=tk.X, padx=15, pady=(0, 10))

        # Section title
        tk.Label(
            section_frame,
            text=title,
            font=("Arial", 10, "bold"),
            bg="white",
            anchor=tk.W
        ).pack(fill=tk.X)

        # Items
        for item in items:
            item_frame = tk.Frame(section_frame, bg="white")
            item_frame.pack(fill=tk.X, padx=10, pady=2)

            # Label (e.g., "Mobile", "Home")
            if item['label']:
                tk.Label(
                    item_frame,
                    text=item['label'],
                    font=("Arial", 9),
                    bg="white",
                    fg="#7f8c8d",
                    width=10,
                    anchor=tk.W
                ).pack(side=tk.LEFT)

            # Value
            if is_address:
                # Addresses are plist XML - just show simplified version
                tk.Label(
                    item_frame,
                    text="(Address data - see export)",
                    font=("Arial", 9),
                    bg="white",
                    fg="#3498db",
                    anchor=tk.W
                ).pack(side=tk.LEFT, fill=tk.X, expand=True)
            else:
                tk.Label(
                    item_frame,
                    text=item['value'],
                    font=("Arial", 9, "bold"),
                    bg="white",
                    anchor=tk.W
                ).pack(side=tk.LEFT, fill=tk.X, expand=True)

    def _format_timestamp(self, timestamp):
        """Format Apple Core Data timestamp for display."""
        if timestamp is None:
            return "N/A"

        # Apple Core Data timestamp is seconds since 2001-01-01
        # Convert to Unix timestamp (seconds since 1970-01-01)
        from datetime import datetime, timezone
        import time

        try:
            # Apple epoch is 2001-01-01 00:00:00 UTC
            apple_epoch = datetime(2001, 1, 1, tzinfo=timezone.utc).timestamp()
            unix_timestamp = apple_epoch + timestamp

            dt = datetime.fromtimestamp(unix_timestamp)
            return dt.strftime("%Y-%m-%d %H:%M:%S")
        except:
            return str(timestamp)

    def get_default_export_extension(self) -> str:
        """Default extension for contacts export."""
        return '.vcf'

    def get_export_filetypes(self) -> list:
        """File types for contacts export."""
        return [
            ('vCard files', '*.vcf'),
            ('All files', '*.*')
        ]
