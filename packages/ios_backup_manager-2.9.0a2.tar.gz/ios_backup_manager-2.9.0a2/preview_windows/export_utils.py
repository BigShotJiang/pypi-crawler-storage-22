#!/usr/bin/env python3
"""
Helpers for export completion behavior in preview windows.
"""

import json
import os
import tkinter as tk
from tkinter import messagebox

_PREFS_PATH = os.path.join(os.path.expanduser("~"), ".backup_merger_preview_preferences.json")


def _load_prefs() -> dict:
    try:
        if os.path.exists(_PREFS_PATH):
            with open(_PREFS_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {}


def _save_prefs(prefs: dict) -> None:
    try:
        with open(_PREFS_PATH, "w", encoding="utf-8") as f:
            json.dump(prefs, f, indent=2)
    except Exception:
        pass


def _open_folder(path: str) -> None:
    if path and os.path.isdir(path):
        try:
            os.startfile(path)
        except Exception:
            pass


def prompt_open_export_folder(parent, export_dir: str, title: str, message: str) -> None:
    prefs = _load_prefs()
    auto_open = prefs.get("auto_open_export_folder")
    suppress = prefs.get("suppress_success_popup")

    # If user set auto-open, honor it regardless of suppression
    if auto_open:
        _open_folder(export_dir)
    if suppress:
        return

    dialog = tk.Toplevel(parent)
    dialog.title(title)
    dialog.transient(parent)
    dialog.grab_set()
    dialog.resizable(False, False)

    frame = tk.Frame(dialog, padx=16, pady=14)
    frame.pack(fill=tk.BOTH, expand=True)

    label = tk.Label(frame, text=message, justify="left", wraplength=420)
    label.pack(anchor="w")

    always_var = tk.BooleanVar(value=False)
    chk = tk.Checkbutton(
        frame,
        text="Always open automatically after successful exports",
        variable=always_var
    )
    chk.pack(anchor="w", pady=(10, 0))

    suppress_var = tk.BooleanVar(value=False)
    chk2 = tk.Checkbutton(
        frame,
        text="Don't show this message again (use my preference)",
        variable=suppress_var
    )
    chk2.pack(anchor="w", pady=(4, 0))

    result = {"open": False}

    def on_open():
        if always_var.get():
            prefs["auto_open_export_folder"] = True
            _save_prefs(prefs)
        if suppress_var.get():
            prefs["suppress_success_popup"] = True
            _save_prefs(prefs)
        result["open"] = True
        dialog.destroy()

    def on_close():
        if suppress_var.get():
            prefs["suppress_success_popup"] = True
            _save_prefs(prefs)
        dialog.destroy()

    btn_frame = tk.Frame(frame)
    btn_frame.pack(anchor="e", pady=(12, 0))

    tk.Button(btn_frame, text="Open Folder", command=on_open, width=12).pack(side=tk.LEFT, padx=5)
    tk.Button(btn_frame, text="Close", command=on_close, width=10).pack(side=tk.LEFT)

    dialog.wait_window()

    if result["open"]:
        _open_folder(export_dir)
