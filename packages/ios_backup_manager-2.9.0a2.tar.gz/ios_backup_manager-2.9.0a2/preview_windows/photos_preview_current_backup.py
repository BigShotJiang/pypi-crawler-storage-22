#!/usr/bin/env python3
"""
Photos preview window implementation.

Displays photos/videos from iOS backup in a grid layout with thumbnails,
selection support, and export to directory with original files.
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from typing import Optional, Dict, List
import threading
import os
from .progress_dialog import ProgressDialog
from .export_utils import prompt_open_export_folder

# Try to import PIL
try:
    from PIL import Image, ImageTk
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False


class PhotosPreviewWindow(tk.Toplevel):
    """Preview window for photos/videos with grid layout."""

    def __init__(self, parent, extractor, category_name: str, backup_label: str = ""):
        super().__init__(parent)

        self.extractor = extractor
        self.category_name = category_name
        self.backup_label = backup_label

        # State
        self.items = []
        self.selected_item_ids = set()  # Track selected by ID
        self.current_page = 0
        self.items_per_page = 50  # 50 photos per page
        self.total_count = 0
        self.sort_by = 'date-desc'
        self.current_album_id = None  # None = All Photos
        self.albums = []  # List of albums
        self.last_export_path = None  # Remember last export directory

        # Grid state
        self.grid_widgets = []  # List of (item, frame, checkbox_var, thumbnail_label)
        self.columns = 5  # 5 columns of thumbnails
        self.thumbnail_size = (100, 100)  # Optimized size
        self.thumbnail_loading = False  # Flag to stop background loading

        # Window setup
        self.title(f"{category_name} Preview - {backup_label}")
        self.geometry("1100x700")

        if not PIL_AVAILABLE:
            messagebox.showwarning(
                "PIL Not Available",
                "Pillow (PIL) is not installed. Photos will be shown as placeholders.\n\n"
                "To enable thumbnail preview, install Pillow:\n"
                "pip install Pillow"
            )

        # Build UI
        self._build_ui()

        # Load albums and initial data
        self._load_albums()

    def _build_ui(self):
        """Build the UI components."""
        # Header
        header = tk.Frame(self, bg="#2c3e50", height=60)
        header.pack(fill=tk.X)
        header.pack_propagate(False)

        tk.Label(
            header,
            text=f"📷 {self.category_name}",
            font=("Arial", 16, "bold"),
            bg="#2c3e50",
            fg="white"
        ).pack(side=tk.LEFT, padx=20, pady=15)

        self.count_label = tk.Label(
            header,
            text="Loading...",
            font=("Arial", 10),
            bg="#2c3e50",
            fg="#95a5a6"
        )
        self.count_label.pack(side=tk.LEFT, pady=15)

        # Album selector
        album_frame = tk.Frame(self, bg="white")
        album_frame.pack(fill=tk.X, padx=10, pady=(5, 0))

        tk.Label(
            album_frame,
            text="Album:",
            font=("Arial", 9, "bold"),
            bg="white"
        ).pack(side=tk.LEFT, padx=(0, 5))

        self.album_var = tk.StringVar()
        self.album_dropdown = ttk.Combobox(
            album_frame,
            textvariable=self.album_var,
            state="readonly",
            font=("Arial", 9),
            width=40
        )
        self.album_dropdown.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.album_dropdown.bind("<<ComboboxSelected>>", self._on_album_changed)

        # Sort selector
        tk.Label(
            album_frame,
            text="Sort:",
            font=("Arial", 9, "bold"),
            bg="white"
        ).pack(side=tk.LEFT, padx=(10, 5))

        self.sort_var = tk.StringVar(value="Newest First")
        self.sort_dropdown = ttk.Combobox(
            album_frame,
            textvariable=self.sort_var,
            state="readonly",
            font=("Arial", 9),
            width=20,
            values=["Newest First", "Oldest First", "Name (A-Z)", "Name (Z-A)"]
        )
        self.sort_dropdown.pack(side=tk.LEFT, padx=(0, 5))
        self.sort_dropdown.bind("<<ComboboxSelected>>", self._on_sort_changed)

        # Main content area (split pane)
        content = tk.Frame(self)
        content.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        # Left pane: Photo grid
        grid_frame = tk.Frame(content)
        grid_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Grid header with select all checkbox
        grid_header = tk.Frame(grid_frame)
        grid_header.pack(fill=tk.X, pady=(0, 5))

        self.select_all_var = tk.BooleanVar()
        tk.Checkbutton(
            grid_header,
            text="Select All",
            variable=self.select_all_var,
            command=self._toggle_select_all,
            font=("Arial", 9)
        ).pack(side=tk.LEFT)

        # Scrollable grid container
        grid_scroll_frame = tk.Frame(grid_frame)
        grid_scroll_frame.pack(fill=tk.BOTH, expand=True)

        # Canvas with scrollbar for grid
        self.grid_canvas = tk.Canvas(grid_scroll_frame, bg="white")
        grid_scrollbar = tk.Scrollbar(grid_scroll_frame, orient="vertical", command=self.grid_canvas.yview)

        self.grid_container = tk.Frame(self.grid_canvas, bg="white")
        self.grid_container.bind(
            "<Configure>",
            lambda e: self.grid_canvas.configure(scrollregion=self.grid_canvas.bbox("all"))
        )

        self.grid_canvas.create_window((0, 0), window=self.grid_container, anchor="nw")
        self.grid_canvas.configure(yscrollcommand=grid_scrollbar.set)

        self.grid_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        grid_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # Pagination controls
        page_frame = tk.Frame(grid_frame)
        page_frame.pack(fill=tk.X, pady=5)

        self.prev_btn = tk.Button(
            page_frame,
            text="◀ Previous Page",
            command=self._prev_page,
            font=("Arial", 9),
            state=tk.DISABLED
        )
        self.prev_btn.pack(side=tk.LEFT, padx=2)

        self.page_label = tk.Label(
            page_frame,
            text="Page 1",
            font=("Arial", 9)
        )
        self.page_label.pack(side=tk.LEFT, padx=10)

        self.next_btn = tk.Button(
            page_frame,
            text="Next Page ▶",
            command=self._next_page,
            font=("Arial", 9)
        )
        self.next_btn.pack(side=tk.LEFT, padx=2)

        # Loading indicator
        self.loading_label = tk.Label(
            page_frame,
            text="",
            font=("Arial", 9),
            fg="#3498db"
        )
        self.loading_label.pack(side=tk.LEFT, padx=20)

        # Right pane: Detail view
        detail_frame = tk.Frame(content, width=300)
        detail_frame.pack(side=tk.LEFT, fill=tk.BOTH, padx=(10, 0))
        detail_frame.pack_propagate(False)

        tk.Label(
            detail_frame,
            text="Details",
            font=("Arial", 10, "bold"),
            anchor=tk.W
        ).pack(fill=tk.X, pady=(0, 5))

        self.detail_content = tk.Frame(detail_frame, bg="white", relief=tk.SUNKEN, borderwidth=1)
        self.detail_content.pack(fill=tk.BOTH, expand=True)

        # Show initial message
        tk.Label(
            self.detail_content,
            text="Select a photo to view details",
            font=("Arial", 10),
            bg="white",
            fg="#7f8c8d"
        ).pack(expand=True)

        # Bottom buttons
        button_frame = tk.Frame(self)
        button_frame.pack(fill=tk.X, padx=10, pady=10)

        # HEIC conversion toggle
        self.convert_heic_var = tk.BooleanVar(value=True)  # Default: ON (opt-out)
        tk.Checkbutton(
            button_frame,
            text="Convert HEIC to JPEG",
            variable=self.convert_heic_var,
            font=("Arial", 9)
        ).pack(side=tk.LEFT, padx=(0, 20))

        # Organize by date toggle
        self.organize_by_date_var = tk.BooleanVar(value=True)  # Default: ON (opt-out)
        tk.Checkbutton(
            button_frame,
            text="Organize by Date (Year/Month)",
            variable=self.organize_by_date_var,
            font=("Arial", 9)
        ).pack(side=tk.LEFT, padx=(0, 20))

        self.export_btn = tk.Button(
            button_frame,
            text="Export All Photos...",
            command=self._export_photos,
            font=("Arial", 10),
            bg="#3498db",
            fg="white",
            padx=20,
            pady=5,
            state=tk.DISABLED
        )
        self.export_btn.pack(side=tk.LEFT, padx=(0, 5))

        self.clear_selection_btn = tk.Button(
            button_frame,
            text="Clear Selection",
            command=self._clear_selection,
            font=("Arial", 10),
            bg="#e67e22",
            fg="white",
            padx=20,
            pady=5
        )
        # Don't pack yet - only show when items selected

        tk.Button(
            button_frame,
            text="Close",
            command=self.destroy,
            font=("Arial", 10),
            bg="#95a5a6",
            fg="white",
            padx=20,
            pady=5
        ).pack(side=tk.LEFT)

    def _load_albums(self):
        """Load albums from database."""
        try:
            self.albums = self.extractor.get_albums()
            # Update "All Photos" count with available count if possible
            if self.albums:
                try:
                    self.albums[0]['count'] = self.extractor.get_available_count()
                except Exception:
                    pass

            # Populate dropdown
            album_names = [f"{album['title']} ({album['count']})" for album in self.albums]
            self.album_dropdown['values'] = album_names

            # Select "All Photos" by default
            if self.albums:
                self.album_dropdown.current(0)
                self.current_album_id = self.albums[0]['z_pk']

            # Now load items
            self.load_items()

        except Exception as e:
            print(f"[WARNING] Could not load albums: {e}")
            # Still load items even if albums failed
            self.load_items()

    def _on_album_changed(self, event):
        """Handle album selection change."""
        selected_index = self.album_dropdown.current()
        if 0 <= selected_index < len(self.albums):
            self.current_album_id = self.albums[selected_index]['z_pk']
            self.current_page = 0  # Reset to first page
            self.selected_item_ids.clear()  # Clear selection when changing albums
            self.load_items()

    def _on_sort_changed(self, event):
        """Handle sort selection change."""
        label = self.sort_var.get()
        mapping = {
            "Newest First": "date-desc",
            "Oldest First": "date-asc",
            "Name (A-Z)": "name-asc",
            "Name (Z-A)": "name-desc",
        }
        self.sort_by = mapping.get(label, "date-desc")
        self.current_page = 0
        self.load_items()

    def load_items(self):
        """Load photos for current page with pagination."""
        saved_hybrid = getattr(self.extractor, "use_hybrid_extraction", False)
        try:
            # Preview should avoid hybrid/manifest-only items to keep counts and ordering accurate
            self.extractor.use_hybrid_extraction = False

            # Get total count
            try:
                self.total_count = self.extractor.get_available_count(album_id=self.current_album_id)
            except Exception:
                self.total_count = self.extractor.get_count(album_id=self.current_album_id)

            # Update count label
            if self.current_album_id is None:
                self.count_label.config(text=f"Total: {self.total_count}")
            else:
                album_name = next((a['title'] for a in self.albums if a['z_pk'] == self.current_album_id), "Album")
                self.count_label.config(text=f"{album_name}: {self.total_count}")

            # Show loading indicator
            self.loading_label.config(text="Loading thumbnails...")
            self.update_idletasks()

            # Load page of items
            offset = self.current_page * self.items_per_page
            self.items = self.extractor.get_items(
                limit=self.items_per_page,
                offset=offset,
                album_id=self.current_album_id,
                sort_by=self.sort_by
            )

            # Restore hybrid flag
            self.extractor.use_hybrid_extraction = saved_hybrid

            # Stop any ongoing thumbnail loading
            self.thumbnail_loading = False

            # Clear existing grid
            for widget_data in self.grid_widgets:
                widget_data[1].destroy()  # Destroy frame
            self.grid_widgets.clear()

            # Populate grid
            self._populate_grid()

            # Update pagination
            total_pages = (self.total_count + self.items_per_page - 1) // self.items_per_page
            self.page_label.config(text=f"Page {self.current_page + 1} of {total_pages}")

            self.prev_btn.config(state=tk.NORMAL if self.current_page > 0 else tk.DISABLED)
            self.next_btn.config(state=tk.NORMAL if offset + len(self.items) < self.total_count else tk.DISABLED)

            # Enable export if items exist
            self.export_btn.config(state=tk.NORMAL if self.items else tk.DISABLED)

            # Clear loading indicator
            self.loading_label.config(text="")

        except Exception as e:
            messagebox.showerror("Error", f"Failed to load {self.category_name}:\n{str(e)}")
            import traceback
            traceback.print_exc()
        finally:
            if hasattr(self.extractor, "use_hybrid_extraction"):
                self.extractor.use_hybrid_extraction = saved_hybrid

    def _populate_grid(self):
        """Populate the grid with photo thumbnails."""
        for idx, item in enumerate(self.items):
            row = idx // self.columns
            col = idx % self.columns

            # Create frame for this photo
            photo_frame = tk.Frame(self.grid_container, bg="white", relief=tk.RIDGE, borderwidth=1)
            photo_frame.grid(row=row, column=col, padx=5, pady=5, sticky="nsew")

            # Checkbox for selection
            checkbox_var = tk.BooleanVar()
            item_id = self._get_item_id(item)
            if item_id in self.selected_item_ids:
                checkbox_var.set(True)

            checkbox = tk.Checkbutton(
                photo_frame,
                variable=checkbox_var,
                command=lambda i=item, v=checkbox_var: self._on_checkbox_changed(i, v),
                bg="white"
            )
            checkbox.pack(anchor=tk.NW)

            # Thumbnail
            thumbnail_label = tk.Label(photo_frame, bg="white")
            thumbnail_label.pack(padx=5, pady=5)

            # Bind click to show details
            thumbnail_label.bind("<Button-1>", lambda e, i=item: self._show_details(i))

            # Filename label
            filename = item['filename']
            if len(filename) > 20:
                filename = filename[:17] + "..."

            tk.Label(
                photo_frame,
                text=filename,
                font=("Arial", 8),
                bg="white",
                wraplength=self.thumbnail_size[0]
            ).pack()

            # Store widget data
            self.grid_widgets.append((item, photo_frame, checkbox_var, thumbnail_label))

        # Load thumbnails in background thread
        self.thumbnail_loading = True
        threading.Thread(target=self._load_thumbnails, daemon=True).start()

    def _load_thumbnails(self):
        """Load thumbnails for current page (runs in background thread)."""
        for item, frame, checkbox_var, thumbnail_label in self.grid_widgets:
            # Check if we should stop loading (user changed page)
            if not self.thumbnail_loading:
                break

            try:
                # Generate thumbnail
                thumb = self.extractor.get_thumbnail(item, size=self.thumbnail_size)

                if thumb:
                    # Convert to PhotoImage
                    photo = ImageTk.PhotoImage(thumb)

                    # Update label in main thread
                    def update_thumb(lbl=thumbnail_label, img=photo):
                        try:
                            if lbl.winfo_exists():
                                lbl.config(image=img)
                                lbl.image = img
                        except tk.TclError:
                            pass
                    self.after(0, update_thumb)
                else:
                    # Placeholder if thumbnail failed
                    def update_placeholder(lbl=thumbnail_label, i=item):
                        try:
                            if lbl.winfo_exists():
                                media_icon = "📹" if i['kind'] == 1 else "📷"
                                lbl.config(text=f"{media_icon}\n{i['width']}x{i['height']}", font=("Arial", 10))
                        except tk.TclError:
                            pass
                    self.after(0, update_placeholder)

            except Exception as e:
                print(f"[WARNING] Failed to load thumbnail for {item['filename']}: {e}")

    def _prev_page(self):
        """Go to previous page."""
        if self.current_page > 0:
            self.current_page -= 1
            self.load_items()

    def _next_page(self):
        """Go to next page."""
        self.current_page += 1
        self.load_items()

    def _get_item_id(self, item):
        """Get unique ID for photo."""
        return item['uuid'] if item['uuid'] else item['z_pk']

    def _on_checkbox_changed(self, item, checkbox_var):
        """Handle checkbox state change."""
        item_id = self._get_item_id(item)

        if checkbox_var.get():
            self.selected_item_ids.add(item_id)
        else:
            self.selected_item_ids.discard(item_id)

        self._update_export_button()

    def _toggle_select_all(self):
        """Toggle select all items in current album."""
        select_all = self.select_all_var.get()

        if select_all:
            # Select ALL items in album (not just loaded ones)
            # Get all items for current album
            all_items = self.extractor.get_items(limit=None, offset=0, album_id=self.current_album_id)

            # Add all IDs to selected set
            for item in all_items:
                item_id = self._get_item_id(item)
                self.selected_item_ids.add(item_id)

            # Check all visible checkboxes
            for item, frame, checkbox_var, thumbnail_label in self.grid_widgets:
                checkbox_var.set(True)
        else:
            # Deselect all
            self.selected_item_ids.clear()

            # Uncheck all visible checkboxes
            for item, frame, checkbox_var, thumbnail_label in self.grid_widgets:
                checkbox_var.set(False)

        self._update_export_button()

    def _clear_selection(self):
        """Clear all selections."""
        self.selected_item_ids.clear()

        # Uncheck all checkboxes on current page
        for item, frame, checkbox_var, thumbnail_label in self.grid_widgets:
            checkbox_var.set(False)

        self.select_all_var.set(False)
        self._update_export_button()

    def _update_export_button(self):
        """Update export button text based on selection."""
        total_selected = len(self.selected_item_ids)

        if total_selected > 0:
            self.export_btn.config(text=f"Export Selected ({total_selected}) Photos...")
            if not self.clear_selection_btn.winfo_ismapped():
                self.clear_selection_btn.pack(side=tk.LEFT, padx=(0, 5), before=self.export_btn.master.winfo_children()[-1])
        else:
            self.export_btn.config(text="Export All Photos...")
            if self.clear_selection_btn.winfo_ismapped():
                self.clear_selection_btn.pack_forget()

    def _show_details(self, item):
        """Show details for selected photo."""
        # Clear existing content
        for widget in self.detail_content.winfo_children():
            widget.destroy()

        # Create scrollable detail view
        canvas = tk.Canvas(self.detail_content, bg="white", highlightthickness=0)
        scrollbar = tk.Scrollbar(self.detail_content, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg="white")

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Header
        media_icon = "📹" if item['kind'] == 1 else "📷"
        media_type = "Video" if item['kind'] == 1 else "Photo"

        tk.Label(
            scrollable_frame,
            text=f"{media_icon} {item['filename']}",
            font=("Arial", 12, "bold"),
            bg="white",
            anchor=tk.W
        ).pack(fill=tk.X, padx=10, pady=(10, 5))

        tk.Label(
            scrollable_frame,
            text=media_type,
            font=("Arial", 9),
            bg="white",
            fg="#7f8c8d",
            anchor=tk.W
        ).pack(fill=tk.X, padx=10)

        # Separator
        tk.Frame(scrollable_frame, height=1, bg="#ecf0f1").pack(fill=tk.X, padx=10, pady=10)

        # Details
        details_text = f"Date: {self._format_timestamp(item['date_created'])}\n"
        details_text += f"Dimensions: {item['width']} × {item['height']} pixels\n"

        if item['width'] and item['height']:
            megapixels = (item['width'] * item['height']) / 1_000_000
            if megapixels >= 1:
                details_text += f"Resolution: {megapixels:.1f} MP\n"

        if item['kind'] == 1 and item['duration']:
            details_text += f"Duration: {self._format_duration(item['duration'])}\n"

        details_text += f"\nDirectory: {item['directory']}\n"
        details_text += f"UUID: {item['uuid']}"

        tk.Label(
            scrollable_frame,
            text=details_text,
            font=("Arial", 9),
            bg="white",
            anchor=tk.W,
            justify=tk.LEFT
        ).pack(fill=tk.X, padx=10)

    def _export_photos(self):
        """Export selected or all photos to directory."""
        try:
            # Determine what to export
            if self.selected_item_ids:
                # Get all selected items across all pages (filtered by current album)
                all_items = self.extractor.get_items(limit=None, offset=0, album_id=self.current_album_id)
                items_to_export = [item for item in all_items if self._get_item_id(item) in self.selected_item_ids]
                export_desc = f"{len(items_to_export)} selected"
            else:
                # Export all items (filtered by current album)
                items_to_export = self.extractor.get_items(limit=None, offset=0, album_id=self.current_album_id)
                if self.current_album_id is None:
                    export_desc = f"all {len(items_to_export)}"
                else:
                    album_name = next((a['title'] for a in self.albums if a['z_pk'] == self.current_album_id), "album")
                    export_desc = f"all {len(items_to_export)} from {album_name}"

            if not items_to_export:
                messagebox.showwarning("Nothing to Export", "No photos to export.")
                return

            # Get base export directory (with path memory)
            base_export_dir = None

            if self.last_export_path and os.path.exists(self.last_export_path):
                # Ask if user wants to use previous path
                result = messagebox.askyesnocancel(
                    "Export Directory",
                    f"Export to previous location?\n\n{self.last_export_path}\n\n"
                    "Yes = Use this location\n"
                    "No = Choose different location\n"
                    "Cancel = Cancel export"
                )

                if result is None:  # User cancelled
                    return
                elif result:  # User clicked Yes
                    base_export_dir = self.last_export_path
                # If result is False (No), ask for new directory below

            # Ask for new directory if needed
            if not base_export_dir:
                base_export_dir = filedialog.askdirectory(
                    title=f"Select directory to export {export_desc} photos"
                )

                if not base_export_dir:
                    return  # User cancelled

                # Remember this path for next time
                self.last_export_path = base_export_dir

            # Create category subfolder for organized output
            export_dir = os.path.join(base_export_dir, "Photos & Videos")
            os.makedirs(export_dir, exist_ok=True)

            # Create progress dialog
            progress = ProgressDialog(
                self,
                title="Exporting Photos",
                total_items=len(items_to_export),
                allow_cancel=True
            )

            # Results container (shared between threads)
            results = {'exported': 0, 'failed': 0, 'error': None}

            def progress_callback(current, total, item_name):
                """Update progress dialog (called from worker thread)."""
                # Schedule update in main thread
                self.after(0, lambda: progress.update_progress(
                    current=current,
                    total=total,
                    current_item_name=item_name
                ))

                # Check for cancellation
                return not progress.is_cancelled()

            def export_worker():
                """Run export in background thread."""
                try:
                    exported, failed = self.extractor.export(
                        items_to_export,
                        export_dir,
                        format='files',
                        progress_callback=progress_callback,
                        convert_heic=self.convert_heic_var.get(),
                        organize_by_date=self.organize_by_date_var.get(),
                        generate_html_report=True
                    )
                    results['exported'] = exported
                    results['failed'] = failed

                    # Mark complete
                    if progress.is_cancelled():
                        self.after(0, lambda: progress.set_complete(
                            success=False,
                            message=f"Cancelled after exporting {exported} photos"
                        ))
                    else:
                        self.after(0, lambda: progress.set_complete(
                            success=True,
                            message=f"Exported {exported} photos successfully!"
                        ))

                except Exception as e:
                    results['error'] = str(e)
                    self.after(0, lambda: progress.set_complete(
                        success=False,
                        message=f"Error: {str(e)}"
                    ))
                    import traceback
                    traceback.print_exc()

                # Close progress dialog after a brief pause
                self.after(1500, lambda: self._show_export_results(progress, results, export_dir))

            # Start export in background thread
            thread = threading.Thread(target=export_worker, daemon=True)
            thread.start()

        except Exception as e:
            messagebox.showerror("Export Error", f"Error exporting photos:\n{str(e)}")
            import traceback
            traceback.print_exc()

    def _show_export_results(self, progress_dialog, results, export_dir):
        """Show export results and close progress dialog."""
        progress_dialog.close()

        exported_count = results['exported']
        failed_count = results['failed']
        error = results['error']

        if error:
            messagebox.showerror(
                "Export Error",
                f"Error during export:\n{error}"
            )
        elif exported_count > 0:
            report_path = os.path.join(export_dir, "index.html")
            report_note = f"\nHTML report: {report_path}" if os.path.exists(report_path) else ""
            if failed_count == 0:
                messagebox.showinfo(
                    "Export Successful",
                    f"Successfully exported {exported_count} photos to:\n{export_dir}\n\n"
                    "Photos are organized by album/directory."
                    f"{report_note}"
                )
                prompt_open_export_folder(
                    self,
                    export_dir,
                    "Export Complete",
                    f"Exported {exported_count} photos to:\n{export_dir}{report_note}"
                )
            else:
                messagebox.showwarning(
                    "Export Partially Successful",
                    f"Export completed with some failures:\n\n"
                    f"✓ Exported: {exported_count} photos\n"
                    f"✗ Failed: {failed_count} photos\n\n"
                    f"Destination: {export_dir}\n\n"
                    "Photos are organized by album/directory.\n"
                    f"{report_note}\n"
                    "Check console for details about failures."
                )
                prompt_open_export_folder(
                    self,
                    export_dir,
                    "Export Complete (with warnings)",
                    f"Exported {exported_count} photos (failed {failed_count}) to:\n{export_dir}{report_note}"
                )
        else:
            messagebox.showerror(
                "Export Failed",
                f"Failed to export photos. All {failed_count} items failed.\n\n"
                "Check console for details about failures."
            )

    def _format_timestamp(self, timestamp) -> str:
        """Format Apple Core Data timestamp for display."""
        if timestamp is None:
            return "N/A"

        from datetime import datetime, timezone

        try:
            apple_epoch = datetime(2001, 1, 1, tzinfo=timezone.utc).timestamp()
            unix_timestamp = apple_epoch + timestamp
            dt = datetime.fromtimestamp(unix_timestamp)
            return dt.strftime("%Y-%m-%d %H:%M:%S")
        except:
            return str(timestamp)

    def _format_duration(self, seconds) -> str:
        """Format video duration."""
        if seconds is None:
            return "N/A"

        try:
            seconds = int(seconds)
            hours = seconds // 3600
            minutes = (seconds % 3600) // 60
            secs = seconds % 60

            if hours > 0:
                return f"{hours}h {minutes}m {secs}s"
            elif minutes > 0:
                return f"{minutes}m {secs}s"
            else:
                return f"{secs}s"
        except:
            return str(seconds)
