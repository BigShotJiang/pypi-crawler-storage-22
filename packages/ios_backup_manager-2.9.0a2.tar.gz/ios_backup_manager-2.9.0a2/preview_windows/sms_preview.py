#!/usr/bin/env python3
"""
SMS/Messages preview window implementation.

Displays SMS and iMessage conversations with:
- Left pane: Conversation list
- Right pane: iMessage-style message bubbles
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
from typing import Dict, Any, List, Optional
from PIL import Image, ImageTk
import os
import threading
from .export_utils import prompt_open_export_folder


class SMSPreviewWindow(tk.Toplevel):
    """Preview window for SMS/iMessage data."""

    def __init__(self, parent, extractor):
        super().__init__(parent)

        self.extractor = extractor
        self.parent = parent

        # Window setup
        self.title("SMS/iMessage Preview")
        self.geometry("1200x800")

        # State
        self.conversations = []
        self.selected_conversation = None
        self.current_conv_page = 0  # Current page in conversation list
        self.conversations_per_page = 50
        self.total_conversations = 0

        self.messages = []
        self.total_messages = 0
        self.current_message_page = 0  # Current page in message pagination (0 = most recent)
        self.messages_per_page = 100  # Load 100 messages per page

        self.selected_conversation_ids = set()  # For export
        self.last_export_path = None  # Remember last export directory

        # Build UI
        self._build_ui()

        # Load conversations
        self.load_conversations()

    def _build_ui(self):
        """Build the UI layout."""
        # Top toolbar
        toolbar = tk.Frame(self, bg="#f0f0f0", height=50)
        toolbar.pack(fill=tk.X, side=tk.TOP)

        # Title and count
        title_frame = tk.Frame(toolbar, bg="#f0f0f0")
        title_frame.pack(side=tk.LEFT, padx=10, pady=10)

        tk.Label(
            title_frame,
            text="💬 Messages",
            font=("Arial", 16, "bold"),
            bg="#f0f0f0"
        ).pack(side=tk.LEFT)

        self.count_label = tk.Label(
            title_frame,
            text="",
            font=("Arial", 10),
            bg="#f0f0f0",
            fg="#666"
        )
        self.count_label.pack(side=tk.LEFT, padx=10)

        # Export button
        self.export_btn = tk.Button(
            toolbar,
            text="Export Selected",
            command=self._export_selected,
            font=("Arial", 10),
            bg="#3498db",
            fg="white",
            padx=15,
            pady=5,
            state=tk.DISABLED
        )
        self.export_btn.pack(side=tk.RIGHT, padx=10, pady=10)

        # Select all checkbox
        self.select_all_var = tk.BooleanVar(value=False)
        self.select_all_check = tk.Checkbutton(
            toolbar,
            text="Select All",
            variable=self.select_all_var,
            command=self._toggle_select_all,
            font=("Arial", 9),
            bg="#f0f0f0"
        )
        self.select_all_check.pack(side=tk.RIGHT, padx=5)

        # Main content area - split pane
        content = tk.PanedWindow(self, orient=tk.HORIZONTAL, sashrelief=tk.RAISED, sashwidth=5)
        content.pack(fill=tk.BOTH, expand=True)

        # Left pane: Conversation list
        left_pane = tk.Frame(content, width=400)
        content.add(left_pane, minsize=300)

        self._build_conversation_list(left_pane)

        # Right pane: Message view
        right_pane = tk.Frame(content)
        content.add(right_pane, minsize=400)

        self._build_message_view(right_pane)

    def _build_conversation_list(self, parent):
        """Build the conversation list (left pane)."""
        # Header
        header = tk.Frame(parent, bg="#34495e", height=40)
        header.pack(fill=tk.X)

        tk.Label(
            header,
            text="Conversations",
            font=("Arial", 12, "bold"),
            bg="#34495e",
            fg="white"
        ).pack(side=tk.LEFT, padx=10, pady=10)

        # Search box
        search_frame = tk.Frame(parent, bg="white", padx=5, pady=5)
        search_frame.pack(fill=tk.X)

        self.search_var = tk.StringVar()
        self.search_var.trace('w', lambda *args: self._on_search())

        search_entry = tk.Entry(
            search_frame,
            textvariable=self.search_var,
            font=("Arial", 10)
        )
        search_entry.pack(fill=tk.X, padx=5, pady=2)

        # Conversation list with scrollbar
        list_frame = tk.Frame(parent)
        list_frame.pack(fill=tk.BOTH, expand=True)

        scrollbar = tk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.conv_listbox = tk.Listbox(
            list_frame,
            yscrollcommand=scrollbar.set,
            font=("Arial", 10),
            selectmode=tk.SINGLE,
            activestyle='none',
            highlightthickness=0
        )
        self.conv_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.conv_listbox.yview)

        # Bind selection and clicks
        self.conv_listbox.bind('<<ListboxSelect>>', self._on_conversation_select)
        self.conv_listbox.bind('<Button-1>', self._on_conversation_click)

        # Pagination controls
        page_frame = tk.Frame(parent, bg="white")
        page_frame.pack(fill=tk.X, pady=5)

        self.conv_prev_btn = tk.Button(
            page_frame,
            text="◀ Prev",
            command=self._conv_prev_page,
            font=("Arial", 9),
            state=tk.DISABLED
        )
        self.conv_prev_btn.pack(side=tk.LEFT, padx=2)

        self.conv_page_label = tk.Label(
            page_frame,
            text="Page 1",
            font=("Arial", 9),
            bg="white"
        )
        self.conv_page_label.pack(side=tk.LEFT, padx=10)

        self.conv_next_btn = tk.Button(
            page_frame,
            text="Next ▶",
            command=self._conv_next_page,
            font=("Arial", 9)
        )
        self.conv_next_btn.pack(side=tk.LEFT, padx=2)

    def _build_message_view(self, parent):
        """Build the message view (right pane)."""
        # Header
        header = tk.Frame(parent, bg="#34495e", height=40)
        header.pack(fill=tk.X)

        self.conversation_title = tk.Label(
            header,
            text="Select a conversation",
            font=("Arial", 12, "bold"),
            bg="#34495e",
            fg="white"
        )
        self.conversation_title.pack(side=tk.LEFT, padx=10, pady=10)

        # Export this conversation button
        self.export_single_btn = tk.Button(
            header,
            text="Export This",
            command=self._export_current_conversation,
            font=("Arial", 9),
            bg="#27ae60",
            fg="white",
            padx=10,
            pady=3,
            state=tk.DISABLED
        )
        self.export_single_btn.pack(side=tk.RIGHT, padx=10, pady=5)

        # Message pagination controls
        pagination_frame = tk.Frame(parent, bg="#ecf0f1", height=40)
        pagination_frame.pack(fill=tk.X)
        pagination_frame.pack_propagate(False)

        self.msg_prev_btn = tk.Button(
            pagination_frame,
            text="◀ Previous 100",
            command=self._prev_message_page,
            font=("Arial", 9),
            state=tk.DISABLED
        )
        self.msg_prev_btn.pack(side=tk.LEFT, padx=10, pady=8)

        self.msg_page_label = tk.Label(
            pagination_frame,
            text="Page 1 of 1",
            font=("Arial", 9),
            bg="#ecf0f1"
        )
        self.msg_page_label.pack(side=tk.LEFT, padx=10)

        self.msg_next_btn = tk.Button(
            pagination_frame,
            text="Next 100 ▶",
            command=self._next_message_page,
            font=("Arial", 9),
            state=tk.DISABLED
        )
        self.msg_next_btn.pack(side=tk.LEFT, padx=10, pady=8)

        # Message display area
        self.message_canvas = tk.Canvas(parent, bg="white", highlightthickness=0)
        msg_scrollbar = tk.Scrollbar(parent, orient="vertical", command=self.message_canvas.yview)

        self.message_frame = tk.Frame(self.message_canvas, bg="white")

        self.message_canvas.configure(yscrollcommand=msg_scrollbar.set)

        msg_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.message_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.message_canvas_window = self.message_canvas.create_window(
            (0, 0),
            window=self.message_frame,
            anchor="nw",
            width=self.message_canvas.winfo_width()
        )

        # Bind canvas resize
        self.message_canvas.bind('<Configure>', self._on_canvas_resize)
        self.message_frame.bind('<Configure>', lambda e: self.message_canvas.configure(
            scrollregion=self.message_canvas.bbox("all")
        ))

        # Bind mouse wheel scrolling
        self.message_canvas.bind('<Enter>', self._bind_mousewheel)
        self.message_canvas.bind('<Leave>', self._unbind_mousewheel)

    def _on_canvas_resize(self, event):
        """Handle canvas resize."""
        self.message_canvas.itemconfig(self.message_canvas_window, width=event.width)

    def _bind_mousewheel(self, event):
        """Bind mouse wheel when entering canvas."""
        self.message_canvas.bind_all("<MouseWheel>", self._on_mousewheel)
        self.message_canvas.bind_all("<Button-4>", self._on_mousewheel)
        self.message_canvas.bind_all("<Button-5>", self._on_mousewheel)

    def _unbind_mousewheel(self, event):
        """Unbind mouse wheel when leaving canvas."""
        self.message_canvas.unbind_all("<MouseWheel>")
        self.message_canvas.unbind_all("<Button-4>")
        self.message_canvas.unbind_all("<Button-5>")

    def _on_mousewheel(self, event):
        """Handle mouse wheel scrolling."""
        if event.num == 5 or event.delta < 0:
            # Scroll down
            self.message_canvas.yview_scroll(1, "units")
        elif event.num == 4 or event.delta > 0:
            # Scroll up
            self.message_canvas.yview_scroll(-1, "units")

    def load_conversations(self):
        """Load conversations for current page."""
        try:
            # Get total count
            self.total_conversations = self.extractor.get_conversation_count()
            self.count_label.config(text=f"Total: {self.total_conversations} conversations")

            # Load page of conversations
            offset = self.current_conv_page * self.conversations_per_page
            self.conversations = self.extractor.get_conversations(
                limit=self.conversations_per_page,
                offset=offset
            )

            # Populate listbox
            self.conv_listbox.delete(0, tk.END)
            for conv in self.conversations:
                # Format list item
                name = conv['display_name']
                last_msg = conv['last_message'][:40] + "..." if len(conv['last_message']) > 40 else conv['last_message']

                # Add checkbox indicator
                checkbox = "☑" if conv['chat_id'] in self.selected_conversation_ids else "☐"

                self.conv_listbox.insert(tk.END, f"{checkbox} {name}")

                # Color group chats differently
                if conv['is_group']:
                    self.conv_listbox.itemconfig(tk.END, fg="#2980b9")

            # Update pagination
            total_pages = (self.total_conversations + self.conversations_per_page - 1) // self.conversations_per_page
            self.conv_page_label.config(text=f"Page {self.current_conv_page + 1} of {total_pages}")

            self.conv_prev_btn.config(state=tk.NORMAL if self.current_conv_page > 0 else tk.DISABLED)
            self.conv_next_btn.config(
                state=tk.NORMAL if offset + len(self.conversations) < self.total_conversations else tk.DISABLED
            )

        except Exception as e:
            messagebox.showerror("Error", f"Failed to load conversations: {e}")

    def _conv_prev_page(self):
        """Go to previous page of conversations."""
        if self.current_conv_page > 0:
            self.current_conv_page -= 1
            self.load_conversations()

    def _conv_next_page(self):
        """Go to next page of conversations."""
        self.current_conv_page += 1
        self.load_conversations()

    def _on_conversation_select(self, event):
        """Handle conversation selection."""
        selection = self.conv_listbox.curselection()
        if not selection:
            return

        idx = selection[0]
        if idx >= len(self.conversations):
            return

        self.selected_conversation = self.conversations[idx]

        # Load messages for this conversation
        self.load_messages()

        # Enable export button
        self.export_single_btn.config(state=tk.NORMAL)

    def _on_conversation_click(self, event):
        """Handle click on conversation list - toggle checkbox if clicking checkbox area."""
        # Get clicked item index
        index = self.conv_listbox.nearest(event.y)
        if index >= len(self.conversations):
            return

        # Check if click is in checkbox area (first ~25 pixels)
        # The checkbox character ☑/☐ is displayed at the start of each line
        if event.x < 25:
            # Click was on checkbox - toggle selection
            conv = self.conversations[index]
            chat_id = conv['chat_id']

            # Toggle selection
            if chat_id in self.selected_conversation_ids:
                self.selected_conversation_ids.remove(chat_id)
            else:
                self.selected_conversation_ids.add(chat_id)

            # Update the listbox display to show new checkbox state
            self.load_conversations()

            # Update export button state
            self._update_export_button_state()

            # Prevent default selection behavior
            return "break"
        # If click is outside checkbox area, let default selection happen (handled by <<ListboxSelect>>)

    def _update_export_button_state(self):
        """Enable/disable export button based on selection count."""
        if self.selected_conversation_ids:
            count = len(self.selected_conversation_ids)
            self.export_btn.config(
                state=tk.NORMAL,
                text=f"Export Selected ({count})"
            )
        else:
            self.export_btn.config(
                state=tk.DISABLED,
                text="Export Selected"
            )

    def load_messages(self):
        """Load messages for selected conversation in background thread."""
        if not self.selected_conversation:
            return

        # Reset to first page (most recent messages) when loading new conversation
        self.current_message_page = 0

        # Update header and show loading indicator
        chat_id = self.selected_conversation['chat_id']
        display_name = self.selected_conversation['display_name']
        self.conversation_title.config(text=f"{display_name} - Loading...")

        # Clear existing messages and show loading
        for widget in self.message_frame.winfo_children():
            widget.destroy()

        loading_label = tk.Label(
            self.message_frame,
            text="Loading messages...",
            font=("Arial", 12),
            fg="#999",
            bg="white"
        )
        loading_label.pack(pady=50)

        # Disable conversation list while loading
        self.conv_listbox.config(state=tk.DISABLED)

        # Load messages in background thread
        def load_in_background():
            try:
                # Get total message count
                total_messages = self.extractor.get_message_count(chat_id)

                # Load most recent page of messages (ORDER BY date DESC)
                offset = self.current_message_page * self.messages_per_page
                messages = self.extractor.get_messages(
                    chat_id,
                    limit=self.messages_per_page,
                    offset=offset
                )

                # Update UI on main thread
                self.after(0, lambda: self._display_loaded_messages(messages, display_name, total_messages))

            except Exception as e:
                # Show error on main thread
                self.after(0, lambda: self._show_load_error(str(e)))

        # Start background thread
        thread = threading.Thread(target=load_in_background, daemon=True)
        thread.start()

    def _display_loaded_messages(self, messages, display_name, total_messages):
        """Display messages after loading in background (runs on main thread)."""
        try:
            # Update header
            self.conversation_title.config(text=display_name)
            self.total_messages = total_messages
            self.messages = messages

            # Clear existing widgets (including loading label)
            for widget in self.message_frame.winfo_children():
                widget.destroy()

            # Reset scroll position and scrollregion
            self.message_canvas.yview_moveto(0.0)
            self.message_canvas.configure(scrollregion=(0, 0, 0, 0))

            # Display messages
            self._display_messages()

            # Force layout update and recalculate scrollregion
            self.message_frame.update_idletasks()
            self.message_canvas.configure(scrollregion=self.message_canvas.bbox("all"))

            # Auto-scroll to bottom after layout is complete
            self.after(100, lambda: self.message_canvas.yview_moveto(1.0))

            # Update pagination controls
            self._update_message_pagination()

            # Re-enable conversation list
            self.conv_listbox.config(state=tk.NORMAL)

        except Exception as e:
            self._show_load_error(str(e))

    def _show_load_error(self, error_msg):
        """Show error message (runs on main thread)."""
        # Clear widgets
        for widget in self.message_frame.winfo_children():
            widget.destroy()

        # Show error
        error_label = tk.Label(
            self.message_frame,
            text=f"Error loading messages:\n{error_msg}",
            font=("Arial", 10),
            fg="red",
            bg="white"
        )
        error_label.pack(pady=50)

        # Re-enable conversation list
        self.conv_listbox.config(state=tk.NORMAL)

        messagebox.showerror("Error", f"Failed to load messages: {error_msg}")

    def _prev_message_page(self):
        """Load previous page of messages (older messages)."""
        if not self.selected_conversation:
            return

        # Increment page to go further back in time
        self.current_message_page += 1

        # Reload messages for this page
        self._reload_current_message_page()

    def _next_message_page(self):
        """Load next page of messages (newer messages)."""
        if not self.selected_conversation:
            return

        # Decrement page to go forward in time
        if self.current_message_page > 0:
            self.current_message_page -= 1

            # Reload messages for this page
            self._reload_current_message_page()

    def _reload_current_message_page(self):
        """Reload messages for current page."""
        if not self.selected_conversation:
            return

        chat_id = self.selected_conversation['chat_id']
        display_name = self.selected_conversation['display_name']

        # Show loading indicator
        for widget in self.message_frame.winfo_children():
            widget.destroy()

        loading_label = tk.Label(
            self.message_frame,
            text="Loading messages...",
            font=("Arial", 12),
            fg="#999",
            bg="white"
        )
        loading_label.pack(pady=50)

        # Load messages in background
        def load_in_background():
            try:
                offset = self.current_message_page * self.messages_per_page
                messages = self.extractor.get_messages(
                    chat_id,
                    limit=self.messages_per_page,
                    offset=offset
                )

                # Update UI on main thread
                self.after(0, lambda: self._display_loaded_messages(messages, display_name, self.total_messages))

            except Exception as e:
                self.after(0, lambda: self._show_load_error(str(e)))

        thread = threading.Thread(target=load_in_background, daemon=True)
        thread.start()

    def _update_message_pagination(self):
        """Update pagination button states and labels."""
        if self.total_messages == 0:
            # No messages
            self.msg_prev_btn.config(state=tk.DISABLED)
            self.msg_next_btn.config(state=tk.DISABLED)
            self.msg_page_label.config(text="No messages")
            return

        # Calculate total pages
        total_pages = (self.total_messages + self.messages_per_page - 1) // self.messages_per_page

        # Update page label (page numbers are 1-indexed for display)
        current_page_display = self.current_message_page + 1
        self.msg_page_label.config(text=f"Page {current_page_display} of {total_pages}")

        # Update Previous button (enabled if there are older messages)
        max_offset = self.total_messages - 1
        current_offset = self.current_message_page * self.messages_per_page
        has_previous = current_offset + self.messages_per_page < self.total_messages

        self.msg_prev_btn.config(state=tk.NORMAL if has_previous else tk.DISABLED)

        # Update Next button (enabled if not on first page)
        self.msg_next_btn.config(state=tk.NORMAL if self.current_message_page > 0 else tk.DISABLED)

    def _display_messages(self):
        """Display messages in iMessage style."""
        last_date = None

        for msg in self.messages:
            # Format date
            msg_date = self.extractor._format_apple_timestamp(msg['date'])
            msg_date_str = msg_date.strftime('%B %d, %Y') if msg_date else 'Unknown Date'
            msg_time_str = msg_date.strftime('%I:%M %p') if msg_date else ''

            # Add date separator if date changed
            if msg_date_str != last_date:
                date_sep = tk.Label(
                    self.message_frame,
                    text=msg_date_str,
                    font=("Arial", 10),
                    fg="#999",
                    bg="white"
                )
                date_sep.pack(pady=10)
                last_date = msg_date_str

            # Message bubble
            self._create_message_bubble(msg, msg_time_str)

    def _create_message_bubble(self, msg: Dict[str, Any], time_str: str):
        """Create a message bubble widget."""
        # Container for message (for alignment)
        msg_container = tk.Frame(self.message_frame, bg="white")
        msg_container.pack(fill=tk.X, padx=10, pady=3)

        # Determine alignment
        is_sent = msg['is_from_me']

        # Bubble frame
        bubble = tk.Frame(
            msg_container,
            bg="#d2f6cb" if is_sent else "#f0f0f0",
            padx=10,
            pady=8
        )

        if is_sent:
            bubble.pack(side=tk.RIGHT, anchor='e')
        else:
            bubble.pack(side=tk.LEFT, anchor='w')

        # Message text
        if msg['text']:
            text_label = tk.Label(
                bubble,
                text=msg['text'],
                font=("Arial", 10),
                bg="#d2f6cb" if is_sent else "#f0f0f0",
                wraplength=400,
                justify=tk.LEFT,
                anchor='w'
            )
            text_label.pack(fill=tk.X)

        # Attachments
        if msg['attachments']:
            for att in msg['attachments']:
                self._display_attachment(bubble, att, is_sent)

        # Timestamp
        time_label = tk.Label(
            bubble,
            text=time_str,
            font=("Arial", 8),
            fg="#666",
            bg="#d2f6cb" if is_sent else "#f0f0f0"
        )
        time_label.pack(anchor='e', pady=(2, 0))

    def _display_attachment(self, parent, attachment: Dict[str, Any], is_sent: bool):
        """Display attachment in message bubble."""
        mime_type = attachment.get('mime_type') or ''
        filename = attachment.get('transfer_name') or 'attachment'

        bg_color = "#d2f6cb" if is_sent else "#f0f0f0"

        # Try to load thumbnail for images
        if mime_type and mime_type.startswith('image/'):
            att_path = self.extractor.get_attachment_path(attachment['filename'])
            if att_path and os.path.exists(att_path):
                try:
                    # Load thumbnail
                    img = Image.open(att_path)
                    img.thumbnail((200, 200), Image.Resampling.NEAREST)
                    photo = ImageTk.PhotoImage(img)

                    img_label = tk.Label(parent, image=photo, bg=bg_color)
                    img_label.image = photo  # Keep reference
                    img_label.pack(pady=5)
                except Exception as e:
                    # Fallback to text
                    tk.Label(
                        parent,
                        text=f"📷 {filename}",
                        font=("Arial", 9),
                        fg="#007aff",
                        bg=bg_color
                    ).pack()
            else:
                tk.Label(
                    parent,
                    text=f"📷 {filename} (not found)",
                    font=("Arial", 9),
                    fg="#999",
                    bg=bg_color
                ).pack()

        elif mime_type and mime_type.startswith('video/'):
            tk.Label(
                parent,
                text=f"🎥 {filename}",
                font=("Arial", 9),
                fg="#007aff",
                bg=bg_color
            ).pack()

        elif mime_type and mime_type.startswith('audio/'):
            # Audio files including voice messages
            tk.Label(
                parent,
                text=f"🎤 {filename}",
                font=("Arial", 9),
                fg="#007aff",
                bg=bg_color
            ).pack()

        elif mime_type == 'application/pdf':
            tk.Label(
                parent,
                text=f"📄 {filename}",
                font=("Arial", 9),
                fg="#007aff",
                bg=bg_color
            ).pack()

        elif mime_type in ('text/vcard', 'text/x-vcard'):
            tk.Label(
                parent,
                text=f"👤 {filename}",
                font=("Arial", 9),
                fg="#007aff",
                bg=bg_color
            ).pack()

        elif mime_type and mime_type.startswith('text/'):
            tk.Label(
                parent,
                text=f"📝 {filename}",
                font=("Arial", 9),
                fg="#007aff",
                bg=bg_color
            ).pack()

        else:
            tk.Label(
                parent,
                text=f"📎 {filename}",
                font=("Arial", 9),
                fg="#007aff",
                bg=bg_color
            ).pack()

    def _on_search(self):
        """Handle search (to be implemented)."""
        # TODO: Implement search functionality
        pass

    def _toggle_select_all(self):
        """Toggle select all conversations."""
        select_all = self.select_all_var.get()

        if select_all:
            # Select all conversations (all pages) - use fast ID-only method
            all_chat_ids = self.extractor.get_conversation_ids()
            self.selected_conversation_ids.update(all_chat_ids)
        else:
            # Deselect all
            self.selected_conversation_ids.clear()

        # Update listbox display
        self.load_conversations()
        self._update_export_button_state()

    def _export_selected(self):
        """Export selected conversations to HTML."""
        if not self.selected_conversation_ids:
            messagebox.showwarning("No Selection", "Please select conversations to export")
            return

        # Get base export directory (with path memory)
        base_output_dir = None

        if self.last_export_path and os.path.exists(self.last_export_path):
            # Ask if user wants to use previous path
            result = messagebox.askyesnocancel(
                "Export Directory",
                f"Export to previous location?\n\n{self.last_export_path}\n\n"
                "Yes = Use this location\n"
                "No = Choose different location\n"
                "Cancel = Cancel export"
            )

            if result is None:  # User cancelled
                return
            elif result:  # User clicked Yes
                base_output_dir = self.last_export_path
            # If result is False (No), ask for new directory below

        # Ask for new directory if needed
        if not base_output_dir:
            base_output_dir = filedialog.askdirectory(title="Select Export Directory")
            if not base_output_dir:
                return

            # Remember this path for next time
            self.last_export_path = base_output_dir

        # Create category subfolder for organized output
        output_dir = os.path.join(base_output_dir, "SMS")
        os.makedirs(output_dir, exist_ok=True)

        try:
            # Show progress dialog IMMEDIATELY (before any slow operations)
            from .progress_dialog import ProgressDialog

            # Estimate based on selected count (will update once we know actual count)
            progress = ProgressDialog(
                self,
                title="Exporting Conversations",
                total_items=len(self.selected_conversation_ids),
                allow_cancel=True
            )

            # Copy selected IDs to avoid threading issues
            selected_ids = self.selected_conversation_ids.copy()

            def export_thread():
                try:
                    # Update status to show we're preparing
                    self.after(0, lambda: progress.update_progress(
                        current=0,
                        total=len(selected_ids),
                        status="Preparing conversations..."
                    ))

                    # Get full conversation details for selected IDs (now in background thread)
                    conversations_to_export = []
                    all_convs = self.extractor.get_conversations(limit=None, offset=0)
                    for conv in all_convs:
                        if conv['chat_id'] in selected_ids:
                            conversations_to_export.append(conv)

                    # Create progress wrapper that updates our dialog
                    def progress_callback(current, total, item_name):
                        if progress.is_cancelled():
                            return False

                        self.after(0, lambda: progress.update_progress(
                            current=current,
                            total=total,
                            current_item_name=item_name,
                            status=f"Exporting {current} of {total}"
                        ))
                        return True

                    # Use the extractor's export() method which handles:
                    # - Creating Conversations/ subdirectory
                    # - Generating Messages.html index
                    # - Filename collision detection
                    success = self.extractor.export(
                        conversations_to_export,
                        output_dir,
                        format='html',
                        progress_callback=progress_callback
                    )

                    if success:
                        progress.set_complete(True, f"Exported {len(conversations_to_export)} conversations!")
                    else:
                        progress.set_complete(False, "Export was cancelled or failed")

                    # Close after 1 second
                    self.after(1000, progress.close)

                except Exception as e:
                    progress.set_complete(False, f"Export failed: {e}")
                    import traceback
                    traceback.print_exc()
                    self.after(2000, progress.close)

            thread = threading.Thread(target=export_thread, daemon=True)
            thread.start()

        except Exception as e:
            messagebox.showerror("Export Error", f"Failed to export: {e}")

    def _export_current_conversation(self):
        """Export currently selected conversation."""
        if not self.selected_conversation:
            return

        # Get base export directory (with path memory)
        base_output_dir = None

        if self.last_export_path and os.path.exists(self.last_export_path):
            # Ask if user wants to use previous path
            result = messagebox.askyesnocancel(
                "Export Directory",
                f"Export to previous location?\n\n{self.last_export_path}\n\n"
                "Yes = Use this location\n"
                "No = Choose different location\n"
                "Cancel = Cancel export"
            )

            if result is None:  # User cancelled
                return
            elif result:  # User clicked Yes
                base_output_dir = self.last_export_path
            # If result is False (No), ask for new directory below

        # Ask for new directory if needed
        if not base_output_dir:
            base_output_dir = filedialog.askdirectory(title="Select Export Directory")
            if not base_output_dir:
                return

            # Remember this path for next time
            self.last_export_path = base_output_dir

        # Create category subfolder for organized output
        output_dir = os.path.join(base_output_dir, "SMS")
        os.makedirs(output_dir, exist_ok=True)

        # Generate safe filename
        safe_name = "".join(c for c in self.selected_conversation['display_name']
                           if c.isalnum() or c in (' ', '-', '_')).strip()
        if not safe_name:
            safe_name = f"conversation_{self.selected_conversation['chat_id']}"

        output_file = os.path.join(output_dir, f"{safe_name}.html")

        try:
            # Show progress dialog
            from .progress_dialog import ProgressDialog
            progress = ProgressDialog(
                self,
                title="Exporting Conversation",
                total_items=1,
                allow_cancel=False
            )

            # Store conversation info for thread
            conv_id = self.selected_conversation['chat_id']
            conv_name = self.selected_conversation['display_name']

            def export_thread():
                try:
                    # Progress callback to update dialog
                    def update_export_progress(current, total, status):
                        self.after(0, lambda: progress.update_progress(
                            current=current,
                            total=total,
                            current_item_name=conv_name,
                            status=status
                        ))

                    self.extractor.export_conversation_html(
                        conv_id,
                        output_file,
                        conv_name,
                        progress_callback=update_export_progress
                    )

                    progress.set_complete(True, f"Conversation exported!")
                    self.after(1000, progress.close)
                    self.after(1100, lambda: prompt_open_export_folder(
                        self,
                        os.path.dirname(output_file),
                        "Export Complete",
                        f"Conversation exported to:\n{output_file}"
                    ))

                except Exception as e:
                    progress.set_complete(False, f"Export failed: {e}")
                    self.after(2000, progress.close)
                    self.after(2100, lambda e=e: messagebox.showerror("Export Error", f"Failed to export: {e}"))

            thread = threading.Thread(target=export_thread, daemon=True)
            thread.start()

        except Exception as e:
            messagebox.showerror("Export Error", f"Failed to export: {e}")
