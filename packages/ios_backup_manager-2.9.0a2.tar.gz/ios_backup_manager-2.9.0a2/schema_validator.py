#!/usr/bin/env python3
"""
schema_validator.py

Schema validation utility for iOS backup databases.

Provides tools to:
- Detect iOS version from backups
- Compare database schemas across iOS versions
- Validate merge compatibility
- Generate schema compatibility reports
"""

import sqlite3
import os
import plistlib
from typing import Dict, List, Tuple, Optional, Set
from collections import defaultdict


def detect_ios_version(backup_path: str) -> Optional[str]:
    """
    Detect iOS version from backup.

    Args:
        backup_path: Path to backup directory

    Returns:
        iOS version string (e.g., "15.7.1") or None if not found
    """
    manifest_path = os.path.join(backup_path, "Manifest.plist")
    info_path = os.path.join(backup_path, "Info.plist")

    # Try Manifest.plist first
    if os.path.exists(manifest_path):
        try:
            with open(manifest_path, 'rb') as f:
                manifest = plistlib.load(f)
                lockdown = manifest.get('Lockdown', {})
                version = lockdown.get('ProductVersion')
                if version:
                    return version
        except Exception as e:
            print(f"[WARN] Could not read Manifest.plist: {e}")

    # Fall back to Info.plist
    if os.path.exists(info_path):
        try:
            with open(info_path, 'rb') as f:
                info = plistlib.load(f)
                version = info.get('Product Version')
                if version:
                    return version
        except Exception as e:
            print(f"[WARN] Could not read Info.plist: {e}")

    return None


def get_database_schema(db_path: str) -> Dict[str, Dict[str, any]]:
    """
    Extract schema information from SQLite database.

    Args:
        db_path: Path to SQLite database file

    Returns:
        Dict mapping table names to column information
    """
    if not os.path.exists(db_path):
        return {}

    try:
        conn = sqlite3.connect(db_path)
        cur = conn.cursor()

        # Get all tables
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
        tables = [row[0] for row in cur.fetchall()]

        schema = {}
        for table in tables:
            # Get column info for this table
            cur.execute(f"PRAGMA table_info({table})")
            columns = {}
            for row in cur.fetchall():
                col_name = row[1]
                columns[col_name] = {
                    'cid': row[0],
                    'type': row[2],
                    'notnull': row[3],
                    'default': row[4],
                    'pk': row[5]
                }
            schema[table] = columns

        conn.close()
        return schema

    except Exception as e:
        # Silently skip databases with special extensions (RTREE, custom tokenizers)
        # These are typically AddressBook or Calendar databases with Apple-specific SQLite extensions
        error_str = str(e).lower()
        if 'tokenizer' not in error_str and 'rtree' not in error_str and 'module' not in error_str:
            print(f"[WARN] Could not read schema from {os.path.basename(db_path)}: {e}")
        return {}


def compare_schemas(schema1: Dict, schema2: Dict, db_name: str = "database") -> Dict:
    """
    Compare two database schemas and report differences.

    UPDATED COMPATIBILITY LOGIC (based on real-world testing):
    - Column differences = COMPATIBLE (with warnings) - merger handles via column intersection
    - Type mismatches = INCOMPATIBLE - cannot safely merge different data types

    Args:
        schema1: Schema from first database
        schema2: Schema from second database
        db_name: Name of database being compared (for reporting)

    Returns:
        Dict containing comparison results
    """
    results = {
        'compatible': True,
        'table_differences': {},
        'column_differences': {},
        'warnings': [],
        'errors': []
    }

    # Get table sets
    tables1 = set(schema1.keys())
    tables2 = set(schema2.keys())
    common_tables = tables1 & tables2
    tables1_only = tables1 - tables2
    tables2_only = tables2 - tables1

    # Report table differences
    if tables1_only:
        results['warnings'].append(f"Tables only in DB1: {sorted(tables1_only)}")
        results['table_differences']['db1_only'] = sorted(tables1_only)

    if tables2_only:
        results['warnings'].append(f"Tables only in DB2: {sorted(tables2_only)}")
        results['table_differences']['db2_only'] = sorted(tables2_only)

    # Compare columns for common tables
    for table in sorted(common_tables):
        cols1 = set(schema1[table].keys())
        cols2 = set(schema2[table].keys())
        common_cols = cols1 & cols2
        cols1_only = cols1 - cols2
        cols2_only = cols2 - cols1

        if cols1_only or cols2_only:
            # Column differences are OK - merger handles via column intersection
            # Only mark as incompatible if there are type mismatches (checked below)
            results['column_differences'][table] = {
                'common': sorted(common_cols),
                'db1_only': sorted(cols1_only),
                'db2_only': sorted(cols2_only)
            }

            if cols1_only:
                results['warnings'].append(
                    f"Table '{table}': Columns only in DB1: {sorted(cols1_only)} (will be NULL in merged records)"
                )
            if cols2_only:
                results['warnings'].append(
                    f"Table '{table}': Columns only in DB2: {sorted(cols2_only)} (will be ignored during merge)"
                )

        # Check for type mismatches in common columns
        for col in common_cols:
            type1 = schema1[table][col]['type']
            type2 = schema2[table][col]['type']
            if type1 != type2:
                results['errors'].append(
                    f"Table '{table}', Column '{col}': Type mismatch ({type1} vs {type2})"
                )
                results['compatible'] = False

    return results


def validate_backup_merge_compatibility(backup1_path: str, backup2_path: str) -> Dict:
    """
    Validate if two backups can be safely merged.

    Checks:
    - iOS version compatibility
    - Database schema compatibility
    - Critical database presence

    Args:
        backup1_path: Path to first backup directory
        backup2_path: Path to second backup directory

    Returns:
        Dict containing validation results
    """
    results = {
        'compatible': True,
        'ios_versions': {},
        'database_schemas': {},
        'warnings': [],
        'errors': []
    }

    # Detect iOS versions
    version1 = detect_ios_version(backup1_path)
    version2 = detect_ios_version(backup2_path)
    results['ios_versions'] = {
        'backup1': version1 or 'Unknown',
        'backup2': version2 or 'Unknown'
    }

    if version1 and version2:
        if version1 != version2:
            results['warnings'].append(
                f"iOS version mismatch: {version1} vs {version2} - schema differences possible"
            )

    # Check critical databases that might be merged
    critical_dbs = {
        'sms.db': ('HomeDomain', 'Library/SMS/sms.db'),
        'AddressBook.sqlitedb': ('HomeDomain', 'Library/AddressBook/AddressBook.sqlitedb'),
        'Calendar.sqlitedb': ('HomeDomain', 'Library/Calendar/Calendar.sqlitedb'),
        'notes.sqlite': ('HomeDomain', 'Library/Notes/notes.sqlite'),
        'Photos.sqlite': ('CameraRollDomain', 'Media/PhotoData/Photos.sqlite')
    }

    # Helper to find database file in backup
    def find_db_file(backup_path, domain, relpath):
        """Find database file in backup by searching Manifest.db."""
        manifest_db = os.path.join(backup_path, "Manifest.db")
        if not os.path.exists(manifest_db):
            return None

        try:
            conn = sqlite3.connect(manifest_db)
            cur = conn.cursor()
            cur.execute(
                "SELECT fileID FROM Files WHERE domain=? AND relativePath=?",
                (domain, relpath)
            )
            row = cur.fetchone()
            conn.close()

            if row:
                file_id = row[0]
                db_path = os.path.join(backup_path, file_id[:2], file_id)
                if os.path.exists(db_path):
                    return db_path
        except Exception:
            pass

        return None

    # Validate schemas for each critical database
    for db_name, (domain, relpath) in critical_dbs.items():
        db1_path = find_db_file(backup1_path, domain, relpath)
        db2_path = find_db_file(backup2_path, domain, relpath)

        if db1_path and db2_path:
            schema1 = get_database_schema(db1_path)
            schema2 = get_database_schema(db2_path)

            if schema1 and schema2:
                comparison = compare_schemas(schema1, schema2, db_name)
                results['database_schemas'][db_name] = comparison

                if not comparison['compatible']:
                    results['compatible'] = False
                    results['errors'].append(
                        f"{db_name}: Schema incompatibility detected"
                    )

                # Merge warnings and errors
                results['warnings'].extend(
                    [f"{db_name}: {w}" for w in comparison['warnings']]
                )
                results['errors'].extend(
                    [f"{db_name}: {e}" for e in comparison['errors']]
                )

    return results


def print_validation_report(results: Dict):
    """
    Print a human-readable validation report.

    Args:
        results: Validation results from validate_backup_merge_compatibility()
    """
    print("=" * 80)
    print("iOS BACKUP MERGE COMPATIBILITY REPORT")
    print("=" * 80)

    # iOS Versions
    print("\nBackup iOS Versions:")
    print(f"  Backup 1: {results['ios_versions']['backup1']}")
    print(f"  Backup 2: {results['ios_versions']['backup2']}")

    # Overall compatibility
    if results['compatible']:
        if results['warnings']:
            print(f"\nOverall Compatibility: [OK] COMPATIBLE (with warnings)")
            print("  -> Column differences detected but merge is safe via column intersection")
        else:
            print(f"\nOverall Compatibility: [OK] COMPATIBLE (schemas identical)")
    else:
        print(f"\nOverall Compatibility: [!!] INCOMPATIBLE")
        print("  -> Type mismatches detected - merge may cause data corruption")

    # Warnings
    if results['warnings']:
        print(f"\nWarnings ({len(results['warnings'])}):")
        for warning in results['warnings']:
            print(f"  [!] {warning}")

    # Errors
    if results['errors']:
        print(f"\nErrors ({len(results['errors'])}):")
        for error in results['errors']:
            print(f"  [X] {error}")

    # Database-specific reports
    if results['database_schemas']:
        print("\nDatabase Schema Analysis:")
        for db_name, comparison in results['database_schemas'].items():
            print(f"\n  {db_name}:")
            if comparison['column_differences']:
                for table, diffs in comparison['column_differences'].items():
                    print(f"    Table '{table}':")
                    if diffs['db1_only']:
                        print(f"      Columns only in Backup 1: {diffs['db1_only']}")
                    if diffs['db2_only']:
                        print(f"      Columns only in Backup 2: {diffs['db2_only']}")
            else:
                print("    [OK] Schemas identical")

    print("\n" + "=" * 80)


if __name__ == "__main__":
    import sys

    if len(sys.argv) != 3:
        print("Usage: python schema_validator.py <backup1_path> <backup2_path>")
        sys.exit(1)

    backup1 = sys.argv[1]
    backup2 = sys.argv[2]

    if not os.path.isdir(backup1):
        print(f"Error: Backup 1 path not found: {backup1}")
        sys.exit(1)

    if not os.path.isdir(backup2):
        print(f"Error: Backup 2 path not found: {backup2}")
        sys.exit(1)

    print(f"Validating merge compatibility...")
    print(f"  Backup 1: {backup1}")
    print(f"  Backup 2: {backup2}")
    print()

    results = validate_backup_merge_compatibility(backup1, backup2)
    print_validation_report(results)

    # Exit with error code if incompatible
    sys.exit(0 if results['compatible'] else 1)
