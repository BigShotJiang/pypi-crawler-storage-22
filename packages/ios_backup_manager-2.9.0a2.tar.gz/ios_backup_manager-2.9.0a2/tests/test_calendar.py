#!/usr/bin/env python3
"""Test Calendar extractor implementation."""

import sys
import os
sys.path.insert(0, '.')
from extractors.calendar_extractor import CalendarExtractor

def test_calendar_extractor(backup_path, backup_name):
    """Test Calendar extractor for a single backup."""
    print(f"\n{'='*70}")
    print(f"Testing: {backup_name}")
    print('='*70)

    try:
        extractor = CalendarExtractor(backup_path)
        count = extractor.get_count()
        print(f"[OK] Found {count} calendar events")

        if count == 0:
            print("  (No events to test)")
            return True

        # Get first 10 events
        events = extractor.get_items(limit=10)
        print(f"[OK] Retrieved {len(events)} events")

        # Display some sample events
        print(f"\nSample events:")
        for i, event in enumerate(events[:5], 1):
            summary = event['summary'][:50]
            calendar = event['calendar_name']
            print(f"  {i}. {summary}")
            print(f"     Calendar: {calendar}")
            print(f"     Start: {extractor._format_timestamp(event['start_date'])}")
            if event['location']:
                print(f"     Location: {event['location'][:50]}")
            if event['all_day']:
                print(f"     All-day event")
            if event['has_recurrence']:
                print(f"     Recurring")

        # Test export
        test_output = os.path.join('test_output', f'{backup_name}_calendar_test')
        os.makedirs(test_output, exist_ok=True)

        output_file = os.path.join(test_output, 'calendar_export.ics')
        print(f"\nExporting to: {output_file}")

        success = extractor.export(events, output_file, format='ics')
        if success:
            # Check file was created
            if os.path.exists(output_file):
                file_size = os.path.getsize(output_file)
                print(f"[OK] Export successful: {file_size} bytes")

                # Show first few lines
                with open(output_file, 'r', encoding='utf-8') as f:
                    lines = f.readlines()[:15]
                    print(f"\nFirst 15 lines of ICS file:")
                    for line in lines:
                        print(f"  {line.rstrip()}")
            else:
                print(f"[ERROR] File not created")
                return False
        else:
            print(f"[ERROR] Export failed")
            return False

        return True

    except FileNotFoundError as e:
        print(f"[INFO] {e}")
        return True  # Not a failure, just no calendar data

    except Exception as e:
        print(f"[ERROR] {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Test Calendar implementation with known backups."""
    test_backups = [
        (r'Q:\6681422\iTunes Backup\00008130-001A655820E1401C', '6681422'),
        (r'Q:\6683384\iTunes Backup\00008030-001654413612802E', '6683384'),
    ]

    results = []
    for backup_path, backup_name in test_backups:
        success = test_calendar_extractor(backup_path, backup_name)
        results.append((backup_name, success))

    # Summary
    print(f"\n{'='*70}")
    print("TEST SUMMARY")
    print('='*70)
    for name, success in results:
        status = "[PASS]" if success else "[FAIL]"
        print(f"{status}: {name}")

    all_passed = all(success for _, success in results)
    if all_passed:
        print("\n[OK] All calendar tests passed!")
        print("\nCalendar implementation complete:")
        print("  - CalendarExtractor: Extracts events from Calendar.sqlitedb")
        print("  - CalendarPreviewWindow: Displays events with details")
        print("  - ICS Export: Exports to standard iCalendar format")
        print("  - GUI Integration: Calendar preview clickable in GUI")
    else:
        print("\n[WARN] Some tests had issues")

    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())
