#!/usr/bin/env python3
"""Test calendar multi-format export (ICS, HTML, CSV)."""

import sys
import os
sys.path.insert(0, '.')
from extractors.calendar_extractor import CalendarExtractor

def test_export():
    """Test exporting calendar to all three formats."""
    # Use the reference backup with known count
    backup_path = r"Q:\6692745\iTunes Backup\00008030-001E215E02B9402E"
    output_dir = r"O:\Personal\Martin\JIT\iOSBackupMerger\test_output"

    print(f"{'='*70}")
    print(f"Testing Calendar Multi-Format Export")
    print('='*70)

    try:
        # Create output directory
        os.makedirs(output_dir, exist_ok=True)

        # Initialize extractor
        extractor = CalendarExtractor(backup_path)
        count = extractor.get_count()
        print(f"\nTotal calendar events: {count}")

        # Get first 10 events for testing
        events = extractor.get_items(limit=10)
        print(f"Exporting {len(events)} sample events...")

        # Export to all formats
        output_path = os.path.join(output_dir, "calendar_test_export.ics")

        def progress_callback(current, total, item_name):
            """Simple progress callback."""
            print(f"  [{current}/{total}] {item_name}")
            return True

        success = extractor.export(events, output_path, progress_callback=progress_callback)

        if success:
            print(f"\n[SUCCESS] Export completed!")

            # Check if all three files were created
            base_name = "calendar_test_export"
            ics_file = os.path.join(output_dir, f"{base_name}.ics")
            html_file = os.path.join(output_dir, f"{base_name}.html")
            csv_file = os.path.join(output_dir, f"{base_name}.csv")

            print(f"\nFiles created:")
            for file_path in [ics_file, html_file, csv_file]:
                if os.path.exists(file_path):
                    size = os.path.getsize(file_path)
                    print(f"  [OK] {os.path.basename(file_path)} ({size:,} bytes)")
                else:
                    print(f"  [MISSING] {os.path.basename(file_path)}")

            # Show sample from HTML file
            if os.path.exists(html_file):
                print(f"\nHTML file preview (first 500 chars):")
                with open(html_file, 'r', encoding='utf-8') as f:
                    content = f.read(500)
                    print(content)

            return True
        else:
            print(f"\n[FAILED] Export failed")
            return False

    except FileNotFoundError as e:
        print(f"[ERROR] {e}")
        return False
    except Exception as e:
        print(f"[ERROR] {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = test_export()
    sys.exit(0 if success else 1)
