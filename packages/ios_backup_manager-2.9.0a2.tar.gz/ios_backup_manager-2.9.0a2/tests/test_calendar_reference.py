#!/usr/bin/env python3
"""Test Calendar extractor against Reincubate reference."""

import sys
sys.path.insert(0, '.')
from extractors.calendar_extractor import CalendarExtractor

def test_reference_backup():
    """Test against backup with known calendar count from Reincubate."""
    backup_path = r"Q:\6692745\iTunes Backup\00008030-001E215E02B9402E"
    expected_count = 119

    print(f"{'='*70}")
    print(f"Testing Reference Backup: 6692745")
    print(f"Expected count (from Reincubate): {expected_count}")
    print('='*70)

    try:
        extractor = CalendarExtractor(backup_path)
        actual_count = extractor.get_count()

        print(f"\nOur count: {actual_count}")

        if actual_count == expected_count:
            print(f"[SUCCESS] Count matches Reincubate exactly!")
        else:
            print(f"[MISMATCH] Expected {expected_count}, got {actual_count}")
            print(f"Difference: {actual_count - expected_count}")

        # Show sample events
        if actual_count > 0:
            events = extractor.get_items(limit=10)
            print(f"\nSample events from backup:")
            for i, event in enumerate(events[:5], 1):
                print(f"  {i}. {event['summary'][:60]}")
                print(f"     Calendar: {event['calendar_name']}")
                print(f"     Date: {extractor._format_timestamp(event['start_date'])}")

        return actual_count == expected_count

    except FileNotFoundError as e:
        print(f"[ERROR] {e}")
        return False
    except Exception as e:
        print(f"[ERROR] {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = test_reference_backup()
    sys.exit(0 if success else 1)
