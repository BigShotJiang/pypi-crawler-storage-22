#!/usr/bin/env python3
"""Test call history extractor."""

import sys
sys.path.insert(0, '.')
from extractors.call_history_extractor import CallHistoryExtractor

def test_call_history():
    """Test call history extraction."""
    backup_path = r"Q:\6685679\iTunes Backup\95c5156d9e88e4a770fe910f3efdd746c227dbd9"
    expected_count = 1090

    print(f"{'='*70}")
    print(f"Testing Call History Extractor")
    print(f"Expected count: {expected_count}")
    print('='*70)

    try:
        extractor = CallHistoryExtractor(backup_path)
        actual_count = extractor.get_count()

        print(f"\nOur count: {actual_count}")

        if actual_count == expected_count:
            print(f"[SUCCESS] Count matches exactly!")
        else:
            print(f"[MISMATCH] Expected {expected_count}, got {actual_count}")
            print(f"Difference: {actual_count - expected_count}")

        # Show sample calls
        if actual_count > 0:
            calls = extractor.get_items(limit=10)
            print(f"\nSample calls from backup:")
            for i, call in enumerate(calls, 1):
                print(f"\n  {i}. {call['call_type']}: {call['address']}")
                print(f"     Service: {call['service']}")
                print(f"     Date: {extractor._format_timestamp(call['date'])}")
                print(f"     Duration: {extractor._format_duration(call['duration'])}")

        return actual_count == expected_count

    except FileNotFoundError as e:
        print(f"[ERROR] {e}")
        return False
    except Exception as e:
        print(f"[ERROR] {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = test_call_history()
    sys.exit(0 if success else 1)
