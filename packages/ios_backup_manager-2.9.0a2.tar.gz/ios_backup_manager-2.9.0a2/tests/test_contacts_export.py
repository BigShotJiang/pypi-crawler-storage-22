#!/usr/bin/env python3
"""Test contacts multi-format export."""

import sys
import os
sys.path.insert(0, '.')
from extractors.contacts_extractor import ContactsExtractor

def test_export():
    """Test exporting contacts to all three formats."""
    # Use a backup with contacts
    backup_path = r"Q:\6692745\iTunes Backup\00008030-001E215E02B9402E"
    output_dir = r"O:\Personal\Martin\JIT\iOSBackupMerger\test_output"

    print(f"{'='*70}")
    print(f"Testing Contacts Multi-Format Export")
    print('='*70)

    try:
        # Create output directory
        os.makedirs(output_dir, exist_ok=True)

        # Initialize extractor
        extractor = ContactsExtractor(backup_path)
        count = extractor.get_count()
        print(f"\nTotal contacts: {count}")

        # Get first 10 contacts for testing
        contacts = extractor.get_items(limit=10)
        print(f"Exporting {len(contacts)} sample contacts...")

        # Export to all formats
        output_path = os.path.join(output_dir, "contacts_test_export.vcf")

        def progress_callback(current, total, item_name):
            """Simple progress callback."""
            print(f"  [{current}/{total}] {item_name}")
            return True

        success = extractor.export(contacts, output_path, progress_callback=progress_callback)

        if success:
            print(f"\n[SUCCESS] Export completed!")

            # Check if all three files were created
            base_name = "contacts_test_export"
            vcf_file = os.path.join(output_dir, f"{base_name}.vcf")
            csv_file = os.path.join(output_dir, f"{base_name}.csv")
            html_file = os.path.join(output_dir, f"{base_name}.html")

            print(f"\nFiles created:")
            for file_path in [vcf_file, csv_file, html_file]:
                if os.path.exists(file_path):
                    size = os.path.getsize(file_path)
                    print(f"  [OK] {os.path.basename(file_path)} ({size:,} bytes)")
                else:
                    print(f"  [MISSING] {os.path.basename(file_path)}")

            # Show sample from CSV file
            if os.path.exists(csv_file):
                print(f"\nCSV file preview (first 5 lines):")
                with open(csv_file, 'r', encoding='utf-8') as f:
                    for i, line in enumerate(f):
                        if i >= 5:
                            break
                        print(f"  {line.rstrip()}")

            return True
        else:
            print(f"\n[FAILED] Export failed")
            return False

    except FileNotFoundError as e:
        print(f"[ERROR] {e}")
        return False
    except Exception as e:
        print(f"[ERROR] {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = test_export()
    sys.exit(0 if success else 1)
