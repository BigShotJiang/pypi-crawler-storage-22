#!/usr/bin/env python3
"""
test_database_validation.py

Automated tests for database merge validation.

Tests:
- Schema compatibility detection
- Cross-iOS-version merge validation
- Data integrity after merge
- Record count validation
"""

import sqlite3
import os
import sys
from typing import Dict, List, Tuple, Optional


def validate_database_integrity(db_path: str) -> Tuple[bool, List[str]]:
    """
    Validate database integrity using SQLite's built-in checks.

    Args:
        db_path: Path to SQLite database

    Returns:
        Tuple of (is_valid, errors)
    """
    errors = []

    if not os.path.exists(db_path):
        return False, [f"Database file not found: {db_path}"]

    try:
        conn = sqlite3.connect(db_path)
        cur = conn.cursor()

        # Run integrity check
        cur.execute("PRAGMA integrity_check")
        result = cur.fetchone()

        if result[0] != "ok":
            errors.append(f"Integrity check failed: {result[0]}")

        # Check foreign key violations
        cur.execute("PRAGMA foreign_key_check")
        fk_violations = cur.fetchall()
        if fk_violations:
            errors.append(f"Foreign key violations found: {len(fk_violations)}")
            for violation in fk_violations[:5]:  # Show first 5
                errors.append(f"  FK violation: {violation}")

        conn.close()
        return len(errors) == 0, errors

    except Exception as e:
        return False, [f"Database validation error: {e}"]


def validate_record_counts(db1_path: str, db2_path: str, merged_path: str,
                           tables: List[str], dedup_expected: Dict[str, int] = None) -> Tuple[bool, List[str]]:
    """
    Validate that merged database has expected record counts.

    Expected formula: merged_count = db1_count + db2_count - duplicates

    Args:
        db1_path: Path to first database
        db2_path: Path to second database
        merged_path: Path to merged database
        tables: List of table names to validate
        dedup_expected: Dict of table -> expected duplicate count (optional)

    Returns:
        Tuple of (is_valid, errors)
    """
    errors = []

    if not dedup_expected:
        dedup_expected = {}

    try:
        conn1 = sqlite3.connect(db1_path)
        conn2 = sqlite3.connect(db2_path)
        conn_merged = sqlite3.connect(merged_path)

        for table in tables:
            try:
                # Get counts from each database
                cur1 = conn1.cursor()
                cur1.execute(f"SELECT COUNT(*) FROM {table}")
                count1 = cur1.fetchone()[0]

                cur2 = conn2.cursor()
                cur2.execute(f"SELECT COUNT(*) FROM {table}")
                count2 = cur2.fetchone()[0]

                cur_merged = conn_merged.cursor()
                cur_merged.execute(f"SELECT COUNT(*) FROM {table}")
                count_merged = cur_merged.fetchone()[0]

                # Calculate expected count
                duplicates = dedup_expected.get(table, 0)
                expected_count = count1 + count2 - duplicates

                # Validate
                if count_merged != expected_count:
                    errors.append(
                        f"Table '{table}': Count mismatch - "
                        f"Expected {expected_count} (db1:{count1} + db2:{count2} - dupes:{duplicates}), "
                        f"Got {count_merged}"
                    )
                else:
                    print(f"✓ Table '{table}': Count validated ({count_merged} records)")

            except Exception as e:
                errors.append(f"Table '{table}': Count validation failed - {e}")

        conn1.close()
        conn2.close()
        conn_merged.close()

        return len(errors) == 0, errors

    except Exception as e:
        return False, [f"Record count validation error: {e}"]


def validate_no_duplicate_guids(db_path: str, tables_with_guids: List[str]) -> Tuple[bool, List[str]]:
    """
    Validate that merged database has no duplicate GUIDs.

    Args:
        db_path: Path to merged database
        tables_with_guids: List of table names that have 'guid' column

    Returns:
        Tuple of (is_valid, errors)
    """
    errors = []

    try:
        conn = sqlite3.connect(db_path)
        cur = conn.cursor()

        for table in tables_with_guids:
            try:
                # Check for duplicate GUIDs
                cur.execute(f"""
                    SELECT guid, COUNT(*) as cnt
                    FROM {table}
                    WHERE guid IS NOT NULL
                    GROUP BY guid
                    HAVING cnt > 1
                """)
                duplicates = cur.fetchall()

                if duplicates:
                    errors.append(
                        f"Table '{table}': {len(duplicates)} duplicate GUIDs found"
                    )
                    for guid, count in duplicates[:5]:  # Show first 5
                        errors.append(f"  GUID '{guid}' appears {count} times")
                else:
                    print(f"✓ Table '{table}': No duplicate GUIDs")

            except Exception as e:
                # Table might not have guid column - skip
                pass

        conn.close()
        return len(errors) == 0, errors

    except Exception as e:
        return False, [f"GUID validation error: {e}"]


def validate_primary_keys(db_path: str, tables: List[str]) -> Tuple[bool, List[str]]:
    """
    Validate that primary keys are not NULL and are unique.

    Args:
        db_path: Path to database
        tables: List of table names to validate

    Returns:
        Tuple of (is_valid, errors)
    """
    errors = []

    try:
        conn = sqlite3.connect(db_path)
        cur = conn.cursor()

        for table in tables:
            try:
                # Get primary key column
                cur.execute(f"PRAGMA table_info({table})")
                pk_col = None
                for row in cur.fetchall():
                    if row[5] == 1:  # pk column
                        pk_col = row[1]
                        break

                if not pk_col:
                    continue  # No PK defined

                # Check for NULL primary keys
                cur.execute(f"SELECT COUNT(*) FROM {table} WHERE {pk_col} IS NULL")
                null_count = cur.fetchone()[0]

                if null_count > 0:
                    errors.append(
                        f"Table '{table}': {null_count} NULL primary keys found"
                    )
                else:
                    print(f"✓ Table '{table}': No NULL primary keys")

            except Exception as e:
                errors.append(f"Table '{table}': PK validation failed - {e}")

        conn.close()
        return len(errors) == 0, errors

    except Exception as e:
        return False, [f"Primary key validation error: {e}"]


def run_full_validation_suite(merged_db_path: str, db1_path: str = None,
                              db2_path: str = None, tables: List[str] = None) -> Dict:
    """
    Run full validation suite on a merged database.

    Args:
        merged_db_path: Path to merged database
        db1_path: Path to first source database (optional, for count validation)
        db2_path: Path to second source database (optional, for count validation)
        tables: List of tables to validate (optional)

    Returns:
        Dict containing validation results
    """
    results = {
        'passed': True,
        'tests_run': 0,
        'tests_passed': 0,
        'tests_failed': 0,
        'errors': []
    }

    print("=" * 80)
    print("DATABASE VALIDATION SUITE")
    print("=" * 80)
    print(f"\nValidating: {merged_db_path}\n")

    # Test 1: Database Integrity
    print("[1/4] Testing database integrity...")
    is_valid, errors = validate_database_integrity(merged_db_path)
    results['tests_run'] += 1
    if is_valid:
        results['tests_passed'] += 1
        print("  ✓ Database integrity check passed")
    else:
        results['tests_failed'] += 1
        results['passed'] = False
        results['errors'].extend([f"Integrity: {e}" for e in errors])
        print("  ✗ Database integrity check failed")
        for error in errors:
            print(f"    {error}")

    # Test 2: Primary Key Validation
    if tables:
        print("\n[2/4] Testing primary key constraints...")
        is_valid, errors = validate_primary_keys(merged_db_path, tables)
        results['tests_run'] += 1
        if is_valid:
            results['tests_passed'] += 1
            print("  ✓ Primary key validation passed")
        else:
            results['tests_failed'] += 1
            results['passed'] = False
            results['errors'].extend([f"PK: {e}" for e in errors])
            print("  ✗ Primary key validation failed")
            for error in errors:
                print(f"    {error}")
    else:
        print("\n[2/4] Skipping primary key validation (no tables specified)")

    # Test 3: GUID Uniqueness
    if tables:
        print("\n[3/4] Testing GUID uniqueness...")
        is_valid, errors = validate_no_duplicate_guids(merged_db_path, tables)
        results['tests_run'] += 1
        if is_valid:
            results['tests_passed'] += 1
            print("  ✓ GUID uniqueness validation passed")
        else:
            results['tests_failed'] += 1
            results['passed'] = False
            results['errors'].extend([f"GUID: {e}" for e in errors])
            print("  ✗ GUID uniqueness validation failed")
            for error in errors:
                print(f"    {error}")
    else:
        print("\n[3/4] Skipping GUID validation (no tables specified)")

    # Test 4: Record Count Validation
    if db1_path and db2_path and tables:
        print("\n[4/4] Testing record counts...")
        is_valid, errors = validate_record_counts(db1_path, db2_path, merged_db_path, tables)
        results['tests_run'] += 1
        if is_valid:
            results['tests_passed'] += 1
            print("  ✓ Record count validation passed")
        else:
            results['tests_failed'] += 1
            results['passed'] = False
            results['errors'].extend([f"Count: {e}" for e in errors])
            print("  ✗ Record count validation failed")
            for error in errors:
                print(f"    {error}")
    else:
        print("\n[4/4] Skipping record count validation (source databases not provided)")

    # Summary
    print("\n" + "=" * 80)
    print("VALIDATION SUMMARY")
    print("=" * 80)
    print(f"Tests Run: {results['tests_run']}")
    print(f"Tests Passed: {results['tests_passed']}")
    print(f"Tests Failed: {results['tests_failed']}")
    print(f"Overall Result: {'✓ PASSED' if results['passed'] else '✗ FAILED'}")
    print("=" * 80)

    return results


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python test_database_validation.py <merged_db_path> [db1_path] [db2_path]")
        print("\nExample:")
        print("  python test_database_validation.py merged_sms.db source1_sms.db source2_sms.db")
        sys.exit(1)

    merged_db = sys.argv[1]
    db1 = sys.argv[2] if len(sys.argv) > 2 else None
    db2 = sys.argv[3] if len(sys.argv) > 3 else None

    # Define tables to test (SMS database example)
    sms_tables = ['handle', 'chat', 'message', 'attachment',
                  'chat_handle_join', 'chat_message_join', 'message_attachment_join']

    results = run_full_validation_suite(merged_db, db1, db2, sms_tables)

    sys.exit(0 if results['passed'] else 1)
