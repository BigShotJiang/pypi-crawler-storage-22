"""
Test if SMS attachment "directories" in manifest are actually the files
"""
import sqlite3
import os
import hashlib

backup_path = r"Q:\6697994\iTunes Backup\00008130-001A642E2162001C"
manifest_db = os.path.join(backup_path, "Manifest.db")

# Test cases - try to find files using directory path (without final filename)
test_cases = [
    ("~/Library/SMS/Attachments/e4/04/at_0_486EE520-C418-4FD3-96EF-827E9A3B62C6/IMG_1015.jpg",
     "Library/SMS/Attachments/e4/04/at_0_486EE520-C418-4FD3-96EF-827E9A3B62C6"),

    ("~/Library/SMS/Attachments/ac/12/at_0_1EA50915-0919-4F7D-A08C-349A5A3F4054/IMG_7148.jpeg",
     "Library/SMS/Attachments/ac/12/at_0_1EA50915-0919-4F7D-A08C-349A5A3F4054"),

    ("~/Library/SMS/Attachments/d0/00/at_0_62485580-8237-42C9-9635-1ACFD8B5BECE/tmp.gif",
     "Library/SMS/Attachments/d0/00/at_0_62485580-8237-42C9-9635-1ACFD8B5BECE"),
]

print("=" * 80)
print("Testing if Directory Paths Are Actually Files")
print("=" * 80)
print()

conn = sqlite3.connect(manifest_db)
conn.row_factory = sqlite3.Row
cur = conn.cursor()

for full_path, dir_path in test_cases:
    print(f"Full path: {full_path}")
    print(f"Directory path: {dir_path}")
    print("-" * 80)

    # Try to find using directory path with MediaDomain
    domain = "MediaDomain"
    cache_key = f"{domain}-{dir_path}"
    file_id = hashlib.sha1(cache_key.encode()).hexdigest()

    print(f"Looking up: {cache_key}")
    print(f"File ID: {file_id}")

    # Check manifest
    cur.execute("SELECT fileID, relativePath FROM Files WHERE fileID = ?", (file_id,))
    row = cur.fetchone()

    if row:
        print(f"FOUND in manifest: {row['relativePath']}")

        # Check physical file
        physical_path = os.path.join(backup_path, file_id[:2], file_id)
        if os.path.exists(physical_path):
            size = os.path.getsize(physical_path)
            print(f"Physical file EXISTS: {size:,} bytes")

            # Try to identify file type
            with open(physical_path, 'rb') as f:
                header = f.read(16)
                magic = header[:4].hex()
                print(f"File header (magic bytes): {magic}")

                # Check for common file signatures
                if header[:3] == b'\xff\xd8\xff':
                    print("File type: JPEG")
                elif header[:4] == b'\x89PNG':
                    print("File type: PNG")
                elif header[:4] == b'GIF8':
                    print("File type: GIF")
                elif header[:8] == b'\x00\x00\x00\x18ftypheic' or header[:8] == b'\x00\x00\x00\x1cftyp':
                    print("File type: HEIC/HEIF")
                elif header[:4] in [b'ftyp', b'moov', b'mdat'] or header[4:8] == b'ftyp':
                    print("File type: MOV/MP4")
                else:
                    print("File type: Unknown")
        else:
            print(f"Physical file NOT FOUND")
    else:
        print(f"NOT in manifest")

    print()

conn.close()

print("=" * 80)
print("CONCLUSION:")
print("If these directory paths resolve to actual media files, then the fix is to:")
print("use the directory path (without filename) when looking up SMS attachments.")
print("=" * 80)
