#!/usr/bin/env python3
"""
Test script to find the correct way to disable backup encryption
Run this with: python test_disable_encryption.py
"""

import sys
from pymobiledevice3.lockdown import create_using_usbmux
from pymobiledevice3.services.mobilebackup2 import Mobilebackup2Service

def test_disable_encryption(password="123456"):
    """Test different methods to disable backup encryption"""

    print("=" * 60)
    print("Testing Backup Encryption Removal")
    print("=" * 60)

    # Connect to device
    print("\n[1] Connecting to device via USB...")
    try:
        lockdown = create_using_usbmux()
        print(f"    ✓ Connected to: {lockdown.get_value(key='DeviceName')}")
    except Exception as e:
        print(f"    ✗ Failed to connect: {e}")
        return

    # Check encryption status
    print("\n[2] Checking encryption status...")
    try:
        will_encrypt = lockdown.get_value(domain='com.apple.mobile.backup', key='WillEncrypt')
        print(f"    WillEncrypt = {will_encrypt}")

        if not will_encrypt:
            print("    ⚠ Backup encryption is already disabled!")
            return
    except Exception as e:
        print(f"    ⚠ Could not check encryption status: {e}")

    # Create backup service
    print("\n[3] Creating Mobilebackup2Service...")
    try:
        backup_service = Mobilebackup2Service(lockdown=lockdown)
        print(f"    ✓ Service created")

        # List available methods
        methods = [m for m in dir(backup_service) if not m.startswith('_')]
        print(f"    Available methods: {methods}")

    except Exception as e:
        print(f"    ✗ Failed to create service: {e}")
        return

    # Try different method signatures
    print(f"\n[4] Testing different change_password signatures with password: '{password}'")
    print("-" * 60)

    test_cases = [
        ("change_password('', password)", lambda: backup_service.change_password('', password)),
        ("change_password(password, '')", lambda: backup_service.change_password(password, '')),
        ("change_password('')", lambda: backup_service.change_password('')),
        ("change_password(password)", lambda: backup_service.change_password(password)),
        ("change_password(None, password)", lambda: backup_service.change_password(None, password)),
        ("change_password(password, None)", lambda: backup_service.change_password(password, None)),
    ]

    # Try with keyword arguments if they exist
    import inspect
    try:
        sig = inspect.signature(backup_service.change_password)
        print(f"\nMethod signature: change_password{sig}")
        params = list(sig.parameters.keys())
        print(f"Parameters: {params}")

        # Try keyword argument variations based on parameter names
        if len(params) >= 2:
            p1, p2 = params[0], params[1]
            test_cases.extend([
                (f"change_password({p1}='', {p2}=password)", lambda: backup_service.change_password(**{p1: '', p2: password})),
                (f"change_password({p1}=password, {p2}='')", lambda: backup_service.change_password(**{p1: password, p2: ''})),
            ])

    except Exception as e:
        print(f"Could not inspect signature: {e}")

    print(f"\nTrying {len(test_cases)} different method calls...\n")

    success = False
    for i, (desc, test_func) in enumerate(test_cases, 1):
        print(f"Test {i}: {desc}")
        try:
            test_func()
            print("    ✓✓✓ SUCCESS! This method worked! ✓✓✓")
            success = True
            break
        except Exception as e:
            error_str = str(e)
            if len(error_str) > 100:
                error_str = error_str[:100] + "..."
            print(f"    ✗ Failed: {error_str}")

    print("\n" + "=" * 60)
    if success:
        print("✓ Found working method to disable backup encryption!")
        print(f"  Use: {desc}")

        # Verify encryption is disabled
        print("\n[5] Verifying encryption status...")
        try:
            # Need to reconnect to get fresh status
            lockdown2 = create_using_usbmux()
            will_encrypt = lockdown2.get_value(domain='com.apple.mobile.backup', key='WillEncrypt')
            print(f"    WillEncrypt = {will_encrypt}")
            if not will_encrypt:
                print("    ✓✓✓ Encryption successfully disabled!")
            else:
                print("    ⚠ Encryption still enabled - method may not have worked")
        except Exception as e:
            print(f"    Could not verify: {e}")

    else:
        print("✗ No working method found")
        print("\nPlease try checking the pymobiledevice3 documentation or source code")
        print("for the correct change_password() signature")

    print("=" * 60)

if __name__ == "__main__":
    password = "123456"
    if len(sys.argv) > 1:
        password = sys.argv[1]

    test_disable_encryption(password)
