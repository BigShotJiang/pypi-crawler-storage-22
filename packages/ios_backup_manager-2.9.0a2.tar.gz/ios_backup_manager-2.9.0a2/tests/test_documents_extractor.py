#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test Documents extractor.
"""

import sys
import os
import io

# Fix Windows console encoding
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

# Add parent directory to path
sys.path.insert(0, os.path.dirname(__file__))

from extractors.documents_extractor import DocumentsExtractor

backup_path = r"Q:\6692745\iTunes Backup\00008030-001E215E02B9402E"

print("=== Testing Documents Extractor ===\n")

try:
    # Initialize extractor
    print("1. Initializing Documents extractor...")
    extractor = DocumentsExtractor(backup_path)
    print(f"   ✓ Extractor initialized successfully")

    # Get document count
    print("\n2. Getting document count...")
    count = extractor.get_count()
    print(f"   ✓ Found {count} documents")

    # Get documents
    print("\n3. Getting first 10 documents...")
    documents = extractor.get_items(limit=10)
    print(f"   ✓ Retrieved {len(documents)} documents")

    # Group by category
    by_category = {}
    for doc in documents:
        category = doc['category']
        if category not in by_category:
            by_category[category] = []
        by_category[category].append(doc)

    print("\n4. Documents by category:")
    for category, docs in by_category.items():
        print(f"\n   {category} ({len(docs)} files):")
        for doc in docs:
            size_kb = doc['file_size'] / 1024
            print(f"     - {doc['file_name']} ({size_kb:.1f} KB) from {doc['source']}")

    # Show all categories with counts
    print("\n5. All documents by category:")
    all_docs = extractor.get_items()
    category_counts = {}
    for doc in all_docs:
        category = doc['category']
        category_counts[category] = category_counts.get(category, 0) + 1

    for category, count in sorted(category_counts.items()):
        print(f"   {category}: {count} files")

    print("\n\n=== Documents Extractor Test Complete ===")
    print("✓ All tests passed!")

except Exception as e:
    print(f"\n✗ Error: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
