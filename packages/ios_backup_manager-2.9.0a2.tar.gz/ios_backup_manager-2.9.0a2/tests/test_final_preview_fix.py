"""
FINAL TEST: Verify preview will show correct count with Metadata paths included.
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from extractors.photos_extractor import PhotosExtractor

backup_path = r"Q:\6697994\iTunes Backup\00008130-001A642E2162001C"

print("=" * 80)
print("FINAL VERIFICATION: Preview Count Fix")
print("=" * 80)
print()

extractor = PhotosExtractor(backup_path)

# Simulate preview behavior
print("PREVIEW SIMULATION (Hybrid Enabled)")
print("-" * 80)
extractor.use_hybrid_extraction = True

# Test get_available_count() - what preview uses
available_count = extractor.get_available_count()
print(f"get_available_count(): {available_count:,}")
print()

# Test get_count() - alternative method
count = extractor.get_count(filter_by_existence=True)
print(f"get_count(): {count:,}")
print()

# Get first page of items
items_page1 = extractor.get_items(limit=50, offset=0)
print(f"First page (50 items): {len(items_page1)} items retrieved")
print()

# Get a middle page
items_page100 = extractor.get_items(limit=50, offset=5000)
print(f"Page 100 (offset=5000): {len(items_page100)} items retrieved")
print()

# Calculate pagination
items_per_page = 50
total_pages = (available_count + items_per_page - 1) // items_per_page
print(f"Total pages: {total_pages}")
print()

# Check for Metadata path items
print("Checking for Metadata path items...")
sample_items = extractor.get_items(limit=1000, offset=0)
metadata_items = [item for item in sample_items if 'Metadata' in (item.get('directory') or item.get('path') or '')]
print(f"  Sample 1000 items: {len(metadata_items)} have Metadata in path")
print()

# Summary
print("=" * 80)
print("PREVIEW WILL DISPLAY:")
print("=" * 80)
print()
print(f"  Header: 'Total: {available_count:,}'")
print(f"  All Photos album: {available_count:,} items")
print(f"  Pagination: {total_pages} pages (50 items/page)")
print(f"  Includes Metadata/CPLAssets files: YES ({len(metadata_items)} in first 1000)")
print()

# Expected behavior
expected_min = 16000
expected_max = 17000

if expected_min <= available_count <= expected_max:
    print(f"[SUCCESS] Count is in expected range ({expected_min:,} to {expected_max:,})")
    print()
    print("This includes:")
    print("  - Photos from Photos.sqlite with metadata")
    print("  - Manifest-only files (Live Photos, etc.)")
    print("  - CPLAssets from Metadata/PhotoData paths (~1,079 files)")
    print()
    print("Note: Count may be slightly higher than 16,811 due to duplicate")
    print("      filenames in shared albums (34 duplicates found)")
else:
    print(f"[WARNING] Count outside expected range")
    print(f"  Expected: {expected_min:,} to {expected_max:,}")
    print(f"  Actual: {available_count:,}")

print("=" * 80)
