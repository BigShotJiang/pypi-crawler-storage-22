"""
FINAL VERIFICATION: Preview and Extraction Behavior

This test verifies:
1. Preview shows 16,811 items (all items with files)
2. Extraction attempts 40,578 items (maximum coverage)
3. Both use correct filtering
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from extractors.photos_extractor import PhotosExtractor

backup_path = r"Q:\6697994\iTunes Backup\00008130-001A642E2162001C"

print("=" * 80)
print("FINAL VERIFICATION: Preview and Extraction")
print("=" * 80)
print()

extractor = PhotosExtractor(backup_path)

# Test 1: PREVIEW MODE (what preview dialog will show)
print("Test 1: PREVIEW MODE (Hybrid Enabled, Filtered)")
print("-" * 80)
extractor.use_hybrid_extraction = True
preview_count = extractor.get_count()  # Uses default filter_by_existence=True
preview_items = extractor.get_items(limit=50, offset=0)  # First page

print(f"  Total count: {preview_count:,}")
print(f"  First page items: {len(preview_items)}")
print(f"  Total pages: {(preview_count + 49) // 50}")
print()

# Test 2: EXTRACTION MODE (what full_extraction_manager.py will use)
print("Test 2: EXTRACTION MODE (filter_by_existence=False)")
print("-" * 80)
extraction_count = extractor.get_count(filter_by_existence=False)
extraction_items = extractor.get_items(limit=10, offset=0, filter_by_existence=False)

from_db = sum(1 for item in extraction_items if item.get('source') == 'database')
from_manifest = sum(1 for item in extraction_items if item.get('source') == 'manifest')

print(f"  Total count: {extraction_count:,}")
print(f"  Sample items: {len(extraction_items)}")
print(f"    From Photos.sqlite: {from_db}")
print(f"    From Manifest only: {from_manifest}")
print()

# Summary
print("=" * 80)
print("FINAL VERIFICATION RESULTS")
print("=" * 80)
print()

preview_ok = preview_count == 16811
extraction_ok = extraction_count == 40578
preview_pages_ok = (preview_count + 49) // 50 == 337

print(f"[OK] Preview shows 16,811 items:                  {preview_ok}")
print(f"[OK] Preview pagination (337 pages):              {preview_pages_ok}")
print(f"[OK] Extraction attempts 40,578 items:            {extraction_ok}")
print()

if preview_ok and extraction_ok and preview_pages_ok:
    print("[SUCCESS] Everything is working correctly!")
    print()
    print("=" * 80)
    print("PREVIEW DIALOG:")
    print("  - Header will show: 'Total: 16,811'")
    print("  - All Photos album will show: 16,811 items")
    print("  - Pagination: 337 pages (50 items per page)")
    print("  - No broken thumbnails (all items have files)")
    print()
    print("EXTRACTION:")
    print("  - Will attempt: 40,578 items")
    print("  - Expected successes: ~15,740 items")
    print("  - Expected failures: ~24,838 items (iCloud-only)")
    print("=" * 80)
else:
    print("[FAILED] Some tests failed")

print()
