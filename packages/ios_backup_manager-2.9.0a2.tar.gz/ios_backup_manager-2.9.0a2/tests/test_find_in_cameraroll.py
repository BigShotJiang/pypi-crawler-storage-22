"""
Check if SMS attachments can be found in CameraRollDomain
"""
import sqlite3
import os

backup_path = r"Q:\6697994\iTunes Backup\00008130-001A642E2162001C"
manifest_db = os.path.join(backup_path, "Manifest.db")

# Sample attachments from SMS database
test_files = [
    "IMG_1015.jpg",
    "IMG_7148.jpeg",
    "IMG_7145.jpeg",
    "IMG_0997.jpeg",
    "tmp.gif",
    "IMG_1331.jpeg"
]

print("=" * 80)
print("Searching for SMS Attachment Files in CameraRollDomain")
print("=" * 80)
print()

conn = sqlite3.connect(manifest_db)
conn.row_factory = sqlite3.Row
cur = conn.cursor()

for filename in test_files:
    print(f"Searching for: {filename}")
    print("-" * 80)

    # Search in CameraRollDomain
    cur.execute("""
    SELECT fileID, domain, relativePath
    FROM Files
    WHERE domain LIKE '%Camera%'
      AND relativePath LIKE ?
    LIMIT 5
    """, (f'%{filename}%',))

    results = cur.fetchall()
    if results:
        print(f"  FOUND {len(results)} matches in CameraRollDomain:")
        for r in results:
            print(f"    Domain: {r['domain']}")
            path_display = r['relativePath'] if len(r['relativePath']) < 100 else r['relativePath'][:100] + '...'
            print(f"    Path: {path_display}")
            print(f"    FileID: {r['fileID']}")

            # Check if physical file exists
            physical_path = os.path.join(backup_path, r['fileID'][:2], r['fileID'])
            exists = os.path.exists(physical_path)
            if exists:
                size = os.path.getsize(physical_path)
                print(f"    Physical: EXISTS ({size:,} bytes)")
            else:
                print(f"    Physical: NOT FOUND")
            print()
    else:
        print(f"  NOT FOUND")
    print()

# Get statistics on CameraRollDomain
print()
print("=" * 80)
print("CameraRollDomain Statistics")
print("=" * 80)

cur.execute("""
SELECT COUNT(*) as count
FROM Files
WHERE domain = 'CameraRollDomain'
""")
total = cur.fetchone()['count']
print(f"Total files in CameraRollDomain: {total:,}")

# Count by file type
cur.execute("""
SELECT
    CASE
        WHEN relativePath LIKE '%.jpg' OR relativePath LIKE '%.JPG' THEN 'JPG'
        WHEN relativePath LIKE '%.jpeg' OR relativePath LIKE '%.JPEG' THEN 'JPEG'
        WHEN relativePath LIKE '%.png' OR relativePath LIKE '%.PNG' THEN 'PNG'
        WHEN relativePath LIKE '%.heic' OR relativePath LIKE '%.HEIC' THEN 'HEIC'
        WHEN relativePath LIKE '%.mov' OR relativePath LIKE '%.MOV' THEN 'MOV'
        WHEN relativePath LIKE '%.mp4' OR relativePath LIKE '%.MP4' THEN 'MP4'
        ELSE 'OTHER'
    END as file_type,
    COUNT(*) as count
FROM Files
WHERE domain = 'CameraRollDomain'
GROUP BY file_type
ORDER BY count DESC
""")

print()
print("File types in CameraRollDomain:")
for row in cur.fetchall():
    print(f"  {row['file_type']:10} {row['count']:>6} files")

conn.close()

print()
print("=" * 80)
