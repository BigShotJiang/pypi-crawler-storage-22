#!/usr/bin/env python3
"""
Test HEIC conversion toggle functionality.

Tests both modes:
1. convert_heic=False (default): HEIC files exported as-is
2. convert_heic=True: HEIC files converted to JPEG and replaced
"""

import sys
import os
sys.path.insert(0, '.')

from extractors.photos_extractor import PhotosExtractor
import shutil

def test_heic_toggle():
    """Test HEIC conversion toggle with iPhone XS Max backup."""

    # iPhone XS Max backup path (has HEIC files)
    backup_path = r"Q:\6690340\iTunes Backup\00008020-000E09393C89002E"

    print("="*70)
    print("Testing HEIC Conversion Toggle")
    print("="*70)

    # Initialize extractor
    print("\n1. Initializing Photos extractor...")
    try:
        extractor = PhotosExtractor(backup_path)
        print(f"   [OK] Photos database found")
        print(f"   [OK] Schema version: {extractor.schema_version}")
    except Exception as e:
        print(f"   [FAIL] Could not initialize extractor: {e}")
        return False

    # Get some HEIC items to export
    print("\n2. Finding HEIC files to test...")
    all_items = extractor.get_items(limit=None, offset=0)
    heic_items = [item for item in all_items if item['filename'].lower().endswith(('.heic', '.heif'))]

    if not heic_items:
        print("   [FAIL] No HEIC files found in backup")
        return False

    print(f"   [OK] Found {len(heic_items)} HEIC files")
    print(f"   [OK] Using first 3 files for testing")

    test_items = heic_items[:3]
    for item in test_items:
        print(f"        - {item['filename']}")

    # Test 1: Export with convert_heic=False (default behavior)
    print("\n3. Test 1: Export with convert_heic=False (default)")
    print("   Expected: HEIC files exported as-is, no conversion")

    test_dir_1 = "test_output/heic_test_default"
    if os.path.exists(test_dir_1):
        shutil.rmtree(test_dir_1)
    os.makedirs(test_dir_1, exist_ok=True)

    exported, failed = extractor.export(
        test_items,
        test_dir_1,
        format='files',
        convert_heic=False
    )

    print(f"   [INFO] Exported: {exported}, Failed: {failed}")

    # Check results
    files_test_1 = []
    for root, dirs, files in os.walk(test_dir_1):
        files_test_1.extend(files)

    heic_count_1 = len([f for f in files_test_1 if f.lower().endswith(('.heic', '.heif'))])
    jpeg_count_1 = len([f for f in files_test_1 if f.lower().endswith('.jpg')])

    print(f"   [INFO] Files in output: {len(files_test_1)} total")
    print(f"   [INFO]   - HEIC files: {heic_count_1}")
    print(f"   [INFO]   - JPEG files: {jpeg_count_1}")

    if heic_count_1 == len(test_items) and jpeg_count_1 == 0:
        print("   [OK] Test 1 PASSED: HEIC files exported without conversion")
    else:
        print("   [FAIL] Test 1 FAILED: Unexpected file types")
        return False

    # Test 2: Export with convert_heic=True (replacement behavior)
    print("\n4. Test 2: Export with convert_heic=True")
    print("   Expected: HEIC files converted to JPEG and replaced")

    test_dir_2 = "test_output/heic_test_replace"
    if os.path.exists(test_dir_2):
        shutil.rmtree(test_dir_2)
    os.makedirs(test_dir_2, exist_ok=True)

    exported, failed = extractor.export(
        test_items,
        test_dir_2,
        format='files',
        convert_heic=True
    )

    print(f"   [INFO] Exported: {exported}, Failed: {failed}")

    # Check results
    files_test_2 = []
    for root, dirs, files in os.walk(test_dir_2):
        files_test_2.extend(files)

    heic_count_2 = len([f for f in files_test_2 if f.lower().endswith(('.heic', '.heif'))])
    jpeg_count_2 = len([f for f in files_test_2 if f.lower().endswith('.jpg')])

    print(f"   [INFO] Files in output: {len(files_test_2)} total")
    print(f"   [INFO]   - HEIC files: {heic_count_2}")
    print(f"   [INFO]   - JPEG files: {jpeg_count_2}")

    if heic_count_2 == 0 and jpeg_count_2 == len(test_items):
        print("   [OK] Test 2 PASSED: HEIC files replaced with JPEG")
    else:
        print("   [FAIL] Test 2 FAILED: HEIC files not properly replaced")
        return False

    # Verify JPEG files are valid and have content
    print("\n5. Verifying JPEG file integrity...")
    all_valid = True
    for filename in files_test_2:
        if filename.lower().endswith('.jpg'):
            filepath = None
            for root, dirs, files in os.walk(test_dir_2):
                if filename in files:
                    filepath = os.path.join(root, filename)
                    break

            if filepath:
                file_size = os.path.getsize(filepath)
                if file_size > 0:
                    print(f"   [OK] {filename}: {file_size:,} bytes")
                else:
                    print(f"   [FAIL] {filename}: Empty file!")
                    all_valid = False

    if not all_valid:
        print("   [FAIL] Some JPEG files are empty")
        return False

    print("\n" + "="*70)
    print("[SUCCESS] All tests passed!")
    print("="*70)
    print("\nSummary:")
    print(f"  - convert_heic=False: {heic_count_1} HEIC files, {jpeg_count_1} JPEG files")
    print(f"  - convert_heic=True:  {heic_count_2} HEIC files, {jpeg_count_2} JPEG files")
    print("\nBehavior verified:")
    print("  - Default (OFF): HEIC files exported as-is")
    print("  - Toggle ON: HEIC files replaced with JPEG")
    print("  - Safety checks: JPEG verified before HEIC deletion")

    return True

if __name__ == "__main__":
    success = test_heic_toggle()
    sys.exit(0 if success else 1)
