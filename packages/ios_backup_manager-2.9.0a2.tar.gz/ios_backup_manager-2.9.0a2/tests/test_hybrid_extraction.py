#!/usr/bin/env python3
"""
Test hybrid Photos & Videos extraction to verify it matches Reincubate's count.
"""

import sys
import os
sys.path.insert(0, '.')

from extractors.photos_extractor import PhotosExtractor

def test_hybrid_extraction():
    """Test hybrid extraction on the iPhone XS Max backup."""

    backup_path = r"Q:\6690340\iTunes Backup\00008020-000E09393C89002E"

    print("="*80)
    print("Hybrid Photos & Videos Extraction Test")
    print("="*80)
    print(f"\nBackup: {backup_path}")
    print(f"\nExpected count (Reincubate): 2,597")
    print(f"Our previous count (Photos.sqlite only): 2,135")
    print(f"Expected with hybrid: ~2,597\n")

    # Test with hybrid extraction (default)
    print("1. Testing with hybrid extraction (default)...")
    print("-" * 80)

    try:
        extractor = PhotosExtractor(backup_path)
        print(f"[OK] PhotosExtractor initialized")
        print(f"     Schema version: {extractor.schema_version}")
        print(f"     Hybrid extraction: {extractor.use_hybrid_extraction}")

        # Get count
        count = extractor.get_count()
        print(f"\n[INFO] Total count: {count:,}")

        # Get items
        items = extractor.get_items(limit=None, offset=0)
        print(f"[INFO] Items returned: {len(items):,}")

        # Breakdown by source
        db_items = [i for i in items if i.get('source') == 'database']
        manifest_items = [i for i in items if i.get('source') == 'manifest']

        print(f"\n[INFO] Source breakdown:")
        print(f"       From Photos.sqlite: {len(db_items):,}")
        print(f"       From Manifest.db: {len(manifest_items):,}")
        print(f"       Total: {len(items):,}")

        # Show sample manifest items
        print(f"\n[INFO] Sample files from Manifest.db (first 10):")
        for i, item in enumerate(manifest_items[:10]):
            print(f"       {i+1}. {item['directory']}/{item['filename']}")

        # Compare with Reincubate
        print(f"\n{'='*80}")
        print("COMPARISON WITH REINCUBATE")
        print("="*80)
        print(f"Reincubate extraction: 2,597 files")
        print(f"Our hybrid extraction: {len(items):,} files")
        difference = len(items) - 2597

        if difference == 0:
            print(f"\n✓ PERFECT MATCH! Counts are identical.")
        elif abs(difference) <= 10:
            print(f"\n≈ VERY CLOSE! Difference: {difference:+,} files ({abs(difference*100/2597):.1f}%)")
        elif abs(difference) <= 50:
            print(f"\n∼ CLOSE! Difference: {difference:+,} files ({abs(difference*100/2597):.1f}%)")
        else:
            print(f"\n✗ MISMATCH! Difference: {difference:+,} files ({abs(difference*100/2597):.1f}%)")

        # File type breakdown
        print(f"\n{'='*80}")
        print("FILE TYPE BREAKDOWN")
        print("="*80)

        from collections import defaultdict
        by_ext = defaultdict(int)
        for item in items:
            ext = os.path.splitext(item['filename'])[1].lower()
            by_ext[ext] += 1

        for ext in sorted(by_ext.keys(), key=lambda x: by_ext[x], reverse=True):
            print(f"  {ext or '(no extension)': <10} {by_ext[ext]:>6,}")

        print(f"\n{'='*80}")
        print("TEST COMPLETED")
        print("="*80)

        return len(items) == 2597

    except Exception as e:
        print(f"[FAIL] Error during test: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_hybrid_extraction()
    sys.exit(0 if success else 1)
