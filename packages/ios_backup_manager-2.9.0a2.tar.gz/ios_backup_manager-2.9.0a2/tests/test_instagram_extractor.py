#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test script for Instagram Direct Messages extractor.

Usage:
    python test_instagram_extractor.py <path_to_instagram_db>
"""

import sys
import os
from datetime import datetime
from third_party.instagram_extractor import InstagramExtractor


def test_instagram_extractor(db_path: str):
    """Test the Instagram extractor and print first 5 messages."""

    if not os.path.exists(db_path):
        print(f"Error: Database not found: {db_path}")
        return False

    print("=" * 80)
    print("Instagram Direct Messages Extractor Test")
    print("=" * 80)
    print(f"Database: {db_path}\n")

    try:
        extractor = InstagramExtractor(db_path)

        print("Extracting messages...\n")
        message_count = 0

        for msg in extractor.iter_messages():
            message_count += 1

            # Print first 5 messages in detail
            if message_count <= 5:
                print(f"Message #{message_count}")
                print(f"  App: {msg['app']}")
                print(f"  Conversation: {msg['conversation_name']} (ID: {msg['conversation_id']})")
                print(f"  From: {msg['sender_display_name']} (ID: {msg['sender_id']})")
                print(f"  Direction: {msg['direction']}")
                print(f"  Timestamp: {msg['timestamp']}")
                print(f"  Text: {msg['text'][:100] if msg['text'] else '[No text]'}{'...' if msg['text'] and len(msg['text']) > 100 else ''}")
                print(f"  Participants: {', '.join(msg['participants'][:3])}{'...' if len(msg['participants']) > 3 else ''}")
                print(f"  Attachments: {len(msg['attachments'])}")
                print()

            # Stop after processing 100 messages for this test
            if message_count >= 100:
                break

        print("=" * 80)
        print(f"Total messages processed: {message_count}")
        print("=" * 80)
        print("\nTest completed successfully!")
        return True

    except Exception as e:
        print(f"Error during extraction: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    if len(sys.argv) < 2:
        print("Usage: python test_instagram_extractor.py <path_to_instagram_db>")
        print("\nExample:")
        print("  python test_instagram_extractor.py SchemaTests/5620318585.db")
        print("  python test_instagram_extractor.py Q:\\6674965\\iTunes Backup\\<UUID>\\<hash1>\\<hash2>")
        sys.exit(1)

    db_path = sys.argv[1]
    success = test_instagram_extractor(db_path)
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
