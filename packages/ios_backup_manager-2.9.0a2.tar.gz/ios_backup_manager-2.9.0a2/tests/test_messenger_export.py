#!/usr/bin/env python3
"""
Test script to verify Messenger extraction with attachments and enhanced HTML.
"""
import sys
import os
import io

# Fix encoding for Windows console
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

# Add project to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from extractors.messenger_extractor import MessengerExtractor

def main():
    # Use the test backup
    backup_path = r'Q:\6631808\iTunes Backup\00008110-001E4D993642401E'
    output_path = r'Q:\testdata\messenger_test_output'

    print('Testing Messenger Extraction with Enhanced HTML and Attachments')
    print('=' * 80)
    print(f'Backup: {backup_path}')
    print(f'Output: {output_path}')
    print()

    try:
        # Create extractor
        print('Initializing extractor...')
        extractor = MessengerExtractor(backup_path)
        print(f'✓ Database found: {extractor.messenger_db_path}')

        # Get conversations with attachments
        print('\nGetting conversations...')
        conversations = extractor.get_items(limit=10)
        print(f'✓ Found {len(conversations)} conversations')

        # Show sample conversation metadata
        if conversations:
            conv = conversations[0]
            print(f'\nSample conversation:')
            print(f'  Name: {conv.get("thread_name")}')
            print(f'  Type: {conv.get("thread_type")}')
            print(f'  Messages: {conv.get("message_count")}')
            print(f'  Participants: {conv.get("participant_count")}')
            print(f'  Picture: {conv.get("thread_picture_url", "N/A")[:60]}...')

        # Export conversations
        print(f'\nExporting to {output_path}...')
        success = extractor.export(conversations, output_path, format='html')

        if success:
            print('✓ Export completed successfully!')
            print(f'\nView results at:')
            print(f'  Index: {output_path}\\Messenger.html')
            print(f'  Conversations: {output_path}\\Conversations\\')

            # Check if attachments were extracted
            from third_party.messenger_extractor import MessengerExtractor as CoreExtractor
            core = CoreExtractor(extractor.messenger_db_path)

            att_count = 0
            for msg in core.iter_messages():
                att_count += len(msg.get('attachments', []))
                if att_count >= 5:  # Just sample first few
                    break

            print(f'\n✓ Attachments in messages: {att_count} found')
        else:
            print('✗ Export failed')

    except Exception as e:
        print(f'✗ Error: {e}')
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    main()
