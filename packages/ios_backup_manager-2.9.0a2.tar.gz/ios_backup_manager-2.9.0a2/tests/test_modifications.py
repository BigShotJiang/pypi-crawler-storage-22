#!/usr/bin/env python3
"""
Test script to isolate what modification breaks the backup.
Makes incremental changes to a working backup to find the issue.
"""

import plistlib
import sqlite3
import os
import shutil
import uuid
import datetime

def test_status_plist_change():
    """Test 1: Change only Status.plist (new UUID, new date)"""
    test_path = r'C:\backups\jon\test_minimal\b866887c5a84768aef9a10b01c9a3296c9981b4d'

    print("TEST 1: Modifying Status.plist only...")
    status_path = os.path.join(test_path, 'Status.plist')

    with open(status_path, 'rb') as f:
        status = plistlib.load(f)

    # Change UUID and Date (like our script does)
    status['UUID'] = str(uuid.uuid4()).upper()
    status['Date'] = datetime.datetime.utcnow().replace(microsecond=0)

    with open(status_path, 'wb') as f:
        plistlib.dump(status, f)

    print(f"  New UUID: {status['UUID']}")
    print(f"  New Date: {status['Date']}")
    print("\nNow test restore:")
    print(f'  idevicebackup2 restore --system --reboot "{test_path}"')
    print("\nIf this FAILS, the problem is Status.plist modification!")
    print("If this WORKS, proceed to test_manifest_plist_change()")

def test_manifest_plist_date():
    """Test 2: Change Manifest.plist Date only"""
    test_path = r'C:\backups\jon\test_minimal\b866887c5a84768aef9a10b01c9a3296c9981b4d'

    print("TEST 2: Modifying Manifest.plist Date only...")
    manifest_path = os.path.join(test_path, 'Manifest.plist')

    with open(manifest_path, 'rb') as f:
        manifest = plistlib.load(f)

    # Change only the Date
    manifest['Date'] = datetime.datetime.utcnow().replace(microsecond=0)

    with open(manifest_path, 'wb') as f:
        plistlib.dump(manifest, f)

    print(f"  New Date: {manifest['Date']}")
    print("\nNow test restore:")
    print(f'  idevicebackup2 restore --system --reboot "{test_path}"')
    print("\nIf this FAILS, the problem is Manifest.plist Date modification!")

def test_add_one_file():
    """Test 3: Add ONE file from recovered backup to Manifest.db"""
    test_path = r'C:\backups\jon\test_minimal\b866887c5a84768aef9a10b01c9a3296c9981b4d'
    recovered_path = r'C:\backups\jon\2\iTunes Backup\b866887c5a84768aef9a10b01c9a3296c9981b4d'

    print("TEST 3: Adding one file from recovered backup...")

    # Find a file that's ONLY in recovered backup
    recovered_conn = sqlite3.connect(os.path.join(recovered_path, 'Manifest.db'))
    recovered_conn.row_factory = sqlite3.Row
    cur = recovered_conn.cursor()
    cur.execute("SELECT fileID, domain, relativePath, flags, file FROM Files WHERE flags = 1 LIMIT 100")
    recovered_files = [dict(r) for r in cur.fetchall()]
    recovered_conn.close()

    test_conn = sqlite3.connect(os.path.join(test_path, 'Manifest.db'))

    # Find one file not in customer backup
    added_file = None
    for rec_file in recovered_files:
        test_cur = test_conn.cursor()
        test_cur.execute("SELECT COUNT(*) FROM Files WHERE domain = ? AND relativePath = ?",
                        (rec_file['domain'], rec_file['relativePath']))
        if test_cur.fetchone()[0] == 0:
            added_file = rec_file
            break

    if not added_file:
        print("  No unique files found in recovered backup!")
        test_conn.close()
        return

    # Add this file to Manifest.db
    test_cur = test_conn.cursor()
    test_cur.execute(
        "INSERT INTO Files (fileID, domain, relativePath, flags, file) VALUES (?, ?, ?, ?, ?)",
        (added_file['fileID'], added_file['domain'], added_file['relativePath'],
         added_file['flags'], sqlite3.Binary(added_file['file'] or b""))
    )
    test_conn.commit()
    test_conn.close()

    # Copy the physical file
    src_file = os.path.join(recovered_path, added_file['fileID'][:2], added_file['fileID'])
    if not os.path.exists(src_file):
        src_file = os.path.join(recovered_path, added_file['fileID'])

    if os.path.exists(src_file):
        dst_dir = os.path.join(test_path, added_file['fileID'][:2])
        os.makedirs(dst_dir, exist_ok=True)
        dst_file = os.path.join(dst_dir, added_file['fileID'])
        shutil.copy2(src_file, dst_file)

        print(f"  Added file: {added_file['domain']}/{added_file['relativePath']}")
        print(f"  fileID: {added_file['fileID']}")
        print("\nNow test restore:")
        print(f'  idevicebackup2 restore --system --reboot "{test_path}"')
        print("\nIf this FAILS, the problem is adding files to Manifest.db!")
    else:
        print(f"  ERROR: Source file not found: {src_file}")

if __name__ == "__main__":
    print("=" * 70)
    print("BACKUP MODIFICATION TESTING SCRIPT")
    print("=" * 70)
    print("\nThis script will make incremental modifications to isolate the issue.")
    print("Run each test in sequence and test restore after each one.\n")

    print("Available tests:")
    print("  1. test_status_plist_change() - Change Status.plist UUID/Date")
    print("  2. test_manifest_plist_date() - Change Manifest.plist Date")
    print("  3. test_add_one_file() - Add one file from recovered backup")
    print("\nRun in Python console: python -c 'from test_modifications import *; test_status_plist_change()'")
