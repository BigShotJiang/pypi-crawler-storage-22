"""
Test Notes extractor with dual database support (modern + legacy)
"""
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from extractors.notes_extractor import NotesExtractor

# Test backup path
backup_path = r"Q:\6690847\iTunes Backup\00008101-000E28A002C2001E"

print("=" * 80)
print("Notes Extractor Test - Dual Database Support")
print("=" * 80)
print()
print(f"Backup: {backup_path}")
print()

try:
    # Initialize extractor
    print("Initializing Notes extractor...")
    extractor = NotesExtractor(backup_path)

    # Check which databases were found
    print(f"Modern database: {extractor.modern_db_path}")
    print(f"Legacy database: {extractor.legacy_db_path}")
    print()

    # Get note count
    count = extractor.get_count()
    print(f"Total note count: {count}")
    print()

    # Get notes
    print("Fetching notes...")
    notes = extractor.get_items()
    print(f"Retrieved {len(notes)} notes")
    print()

    # Count by source
    modern_count = sum(1 for n in notes if n.get('source') == 'modern')
    legacy_count = sum(1 for n in notes if n.get('source') == 'legacy')
    print(f"Modern notes: {modern_count}")
    print(f"Legacy notes: {legacy_count}")
    print()

    # Show sample notes from each source
    print("Sample modern notes:")
    modern_notes = [n for n in notes if n.get('source') == 'modern'][:3]
    for i, note in enumerate(modern_notes, 1):
        title = note['title']
        if len(title) > 60:
            title = title[:60] + '...'
        print(f"  {i}. {title}")
        print(f"     Folder: {note['folder']}")
    print()

    print("Sample legacy notes:")
    legacy_notes = [n for n in notes if n.get('source') == 'legacy'][:3]
    for i, note in enumerate(legacy_notes, 1):
        title = note['title']
        if len(title) > 60:
            title = title[:60] + '...'
        print(f"  {i}. {title}")
        print(f"     Folder: {note['folder']}")
    print()

    # Expected results
    print("=" * 80)
    print("Expected Results:")
    print("  - Previous note count: 13")
    print("  - Modern database: ~17 notes")
    print("  - Legacy database: ~175 notes")
    print("  - Total expected: ~192 notes")
    print("  - Reincubate extraction: 188 notes")
    print()
    print("Actual Results:")
    print(f"  - Total notes: {count}")
    print(f"  - Modern: {modern_count}")
    print(f"  - Legacy: {legacy_count}")
    print(f"  - Retrieved: {len(notes)}")
    print()

    if count >= 180:
        print("SUCCESS: Both databases are now being read!")
        print(f"Difference from Reincubate: {abs(188 - count)} notes")
    elif count > 13:
        print("PARTIAL SUCCESS: More notes found, but count may not match expected")
    else:
        print("FAILED: Note count did not increase")

    print()
    print("=" * 80)

except Exception as e:
    print(f"ERROR: {e}")
    import traceback
    traceback.print_exc()
