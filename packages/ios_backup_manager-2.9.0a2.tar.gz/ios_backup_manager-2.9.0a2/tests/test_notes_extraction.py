#!/usr/bin/env python3
"""
Test script for Notes extraction across multiple backups.
Validates that notes are properly extracted without corruption.
"""

import sys
from extractors.notes_extractor import NotesExtractor


def test_backup(backup_path, backup_name):
    """Test notes extraction for a single backup."""
    print(f"\n{'='*60}")
    print(f"Testing: {backup_name}")
    print(f"Path: {backup_path}")
    print('='*60)

    try:
        extractor = NotesExtractor(backup_path)
        count = extractor.get_count()
        print(f"[OK] Found {count} notes")

        if count == 0:
            print("  (No notes to test)")
            return True

        # Extract all notes
        notes = extractor.get_items(limit=None)
        print(f"[OK] Extracted {len(notes)} notes")

        # Validate each note
        issues = []
        empty_count = 0
        corrupt_count = 0

        for i, note in enumerate(notes):
            title = note['title']
            content = note['content']

            # Check for empty content
            if len(content.strip()) < 2:
                empty_count += 1
                issues.append(f"  [WARN] Empty: {title}")

            # Check for binary corruption
            binary_chars = sum(1 for c in content if ord(c) < 32 and c not in '\n\r\t')
            if binary_chars > 0:
                corrupt_count += 1
                issues.append(f"  [FAIL] Corrupt: {title} ({binary_chars} binary chars in {len(content)} total)")

        # Report results
        clean_count = len(notes) - empty_count - corrupt_count
        print(f"\nResults:")
        print(f"  Clean notes: {clean_count}/{len(notes)}")

        if empty_count > 0:
            print(f"  Empty notes: {empty_count}")
        if corrupt_count > 0:
            print(f"  Corrupted notes: {corrupt_count}")

        if issues:
            print(f"\nIssues found:")
            for issue in issues[:10]:  # Show first 10 issues
                print(issue)
            if len(issues) > 10:
                print(f"  ... and {len(issues) - 10} more")

        # Sample a few notes
        if len(notes) > 0:
            print(f"\nSample notes:")
            for i, note in enumerate(notes[:3]):
                print(f"  {i+1}. {note['title'][:50]} ({len(note['content'])} chars)")

        success = corrupt_count == 0
        if success:
            print(f"\n[SUCCESS] All notes extracted cleanly!")
        else:
            print(f"\n[ISSUES] {corrupt_count} notes have corruption")

        return success

    except FileNotFoundError as e:
        print(f"[INFO] Notes database not found: {e}")
        return True  # Not a failure, just no notes

    except Exception as e:
        print(f"[ERROR] {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Test multiple backups."""
    test_backups = [
        (r"Q:\6690340\iTunes Backup\00008020-000E09393C89002E", "Backup 1 (28 notes)"),
        (r"Q:\6683431\iTunes Backup\00008110-000229261A31801E", "Backup 2 (138 notes)"),
    ]

    # Allow user to specify backup path as argument
    if len(sys.argv) > 1:
        test_backups = [(sys.argv[1], "User-specified backup")]

    results = []
    for backup_path, backup_name in test_backups:
        success = test_backup(backup_path, backup_name)
        results.append((backup_name, success))

    # Summary
    print(f"\n\n{'='*60}")
    print("SUMMARY")
    print('='*60)
    for name, success in results:
        status = "[PASS]" if success else "[FAIL]"
        print(f"{status}: {name}")

    all_passed = all(success for _, success in results)
    if all_passed:
        print("\n[OK] All backups passed validation!")
    else:
        print("\n[WARN] Some backups had issues")

    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())
