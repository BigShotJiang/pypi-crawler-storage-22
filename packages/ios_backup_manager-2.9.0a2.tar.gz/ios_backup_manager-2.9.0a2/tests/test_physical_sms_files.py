"""
Check if SMS attachment files exist physically in backup
"""
import hashlib
import os

backup_path = r"Q:\6697994\iTunes Backup\00008130-001A642E2162001C"

# Test file from SMS database
test_file = "~/Library/SMS/Attachments/e4/04/at_0_486EE520-C418-4FD3-96EF-827E9A3B62C6/IMG_1015.jpg"
relative_path = test_file[2:]  # Remove ~/

print("=" * 80)
print("Checking Physical File Existence")
print("=" * 80)
print()
print(f"Test file: {test_file}")
print(f"Relative path: {relative_path}")
print()

# Try MediaDomain
domain = "MediaDomain"
cache_key = f"{domain}-{relative_path}"
file_id = hashlib.sha1(cache_key.encode()).hexdigest()

print(f"MediaDomain lookup:")
print(f"  Cache key: {cache_key}")
print(f"  File ID: {file_id}")
print()

# Check if physical file exists
physical_path_1 = os.path.join(backup_path, file_id)
physical_path_2 = os.path.join(backup_path, file_id[:2], file_id)

print(f"Checking physical paths:")
print(f"  Path 1: {physical_path_1}")
print(f"    Exists: {os.path.exists(physical_path_1)}")
print(f"  Path 2: {physical_path_2}")
print(f"    Exists: {os.path.exists(physical_path_2)}")
print()

# Try without domain (old iOS backup style)
file_id_no_domain = hashlib.sha1(relative_path.encode()).hexdigest()
print(f"No-domain lookup (old style):")
print(f"  File ID: {file_id_no_domain}")

physical_path_3 = os.path.join(backup_path, file_id_no_domain)
physical_path_4 = os.path.join(backup_path, file_id_no_domain[:2], file_id_no_domain)

print(f"  Path 1: {physical_path_3}")
print(f"    Exists: {os.path.exists(physical_path_3)}")
print(f"  Path 2: {physical_path_4}")
print(f"    Exists: {os.path.exists(physical_path_4)}")
print()

# Check backup structure - list first level
print("Backup root structure:")
items = os.listdir(backup_path)
# Count files vs directories
files = [i for i in items if os.path.isfile(os.path.join(backup_path, i))]
dirs = [i for i in items if os.path.isdir(os.path.join(backup_path, i))]
print(f"  Files: {len(files)}")
print(f"  Directories: {len(dirs)}")
print(f"  Directory names: {', '.join(sorted(dirs)[:20])}")
print()

print("=" * 80)
