#!/usr/bin/env python3
"""Test preview image embedding in notes export."""

import sys
import os
sys.path.insert(0, '.')
from extractors.notes_extractor import NotesExtractor

def test_preview_embedding(backup_path, backup_name, note_title_filter):
    """Test that preview images are embedded in notes export."""
    print(f"\n{'='*70}")
    print(f"Testing: {backup_name}")
    print(f"Filter: {note_title_filter}")
    print('='*70)

    try:
        extractor = NotesExtractor(backup_path)
        notes = extractor.get_items(limit=None)

        # Find notes with the filter text
        matching_notes = [n for n in notes if note_title_filter.lower() in n['title'].lower()]

        print(f"\nFound {len(matching_notes)} note(s) matching '{note_title_filter}':")

        for note in matching_notes:
            print(f"\n  Note: {note['title']}")
            print(f"  Content length: {len(note['content'])} chars")

            # Check if content has embedded images
            if '<img src="data:image/' in note['content']:
                img_count = note['content'].count('<img src="data:image/')
                print(f"  [SUCCESS] Contains {img_count} embedded image(s)")

                # Show snippet of embedded image
                img_start = note['content'].find('<img src="data:image/')
                snippet = note['content'][img_start:img_start+100]
                print(f"  Preview: {snippet}...")
            elif '[Image' in note['content'] or '[Drawing' in note['content']:
                print(f"  [INFO] Has attachment markers but no embedded images")
                # Show what attachments are present
                if '[Image' in note['content']:
                    print(f"    - Contains [Image] markers")
                if '[Drawing' in note['content']:
                    print(f"    - Contains [Drawing] markers")
            else:
                print(f"  [INFO] No attachments detected")

        # Export one note to HTML for visual inspection
        if matching_notes:
            test_output = os.path.join('test_output', 'preview_test')
            os.makedirs(test_output, exist_ok=True)

            print(f"\n  Exporting to: {test_output}")
            extractor.export(matching_notes[:1], test_output, format='html')
            print(f"  [DONE] Check the HTML file to verify image embedding")

    except Exception as e:
        print(f"[ERROR] {e}")
        import traceback
        traceback.print_exc()


def main():
    """Test with known backups that have attachments."""
    test_cases = [
        (r'Q:\6681422\iTunes Backup\00008130-001A655820E1401C', '6681422', 'UA Important Info'),
        (r'Q:\6683384\iTunes Backup\00008030-001654413612802E', '6683384', 'Bets'),
    ]

    for backup_path, backup_name, note_filter in test_cases:
        test_preview_embedding(backup_path, backup_name, note_filter)

    print(f"\n{'='*70}")
    print("TEST SUMMARY")
    print('='*70)
    print("Check the exported HTML files to verify:")
    print("  1. Images are embedded (not broken links)")
    print("  2. Images display correctly in browser")
    print("  3. Non-image attachments show as text labels")


if __name__ == "__main__":
    main()
