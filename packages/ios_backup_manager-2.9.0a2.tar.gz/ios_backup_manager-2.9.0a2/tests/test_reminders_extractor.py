"""
Test script for Reminders extractor
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from extractors.reminders_extractor import RemindersExtractor

# Test with the backup that has reminders
backup_path = r"Q:\6697994\iTunes Backup\00008130-001A642E2162001C"

print("=" * 80)
print("Testing Reminders Extractor")
print("=" * 80)
print()

try:
    # Initialize extractor
    extractor = RemindersExtractor(backup_path)
    print(f"[OK] Extractor initialized successfully")
    print(f"  Found {len(extractor.db_paths)} database file(s)")
    print()

    # Get count
    count = extractor.get_count()
    print(f"Total reminders: {count}")
    print()

    # Get reminders
    if count > 0:
        reminders = extractor.get_items()
        print(f"Retrieved {len(reminders)} reminders")
        print()

        # Show first few reminders
        for i, reminder in enumerate(reminders[:5], 1):
            print(f"Reminder {i}:")
            print(f"  Title: {reminder['title']}")
            print(f"  List: {reminder['list_name']}")
            print(f"  Completed: {reminder['completed']}")
            if reminder['due_date']:
                print(f"  Due: {reminder['due_date']}")
            if reminder['notes']:
                print(f"  Notes: {reminder['notes'][:100]}")
            print()

        # Test export
        output_dir = r"C:\Users\Ontrack\Desktop\test_reminders_export"
        print(f"Exporting to: {output_dir}")
        success = extractor.export(reminders, output_dir)
        if success:
            print(f"[OK] Export successful!")
            print(f"  Check: {output_dir}\\Reminders.html")
        else:
            print(f"[FAIL] Export failed")
    else:
        print("No reminders found in this backup")

    print()
    print("=" * 80)
    print("Test completed successfully!")
    print("=" * 80)

except FileNotFoundError as e:
    print(f"[ERROR] {e}")
    print("This backup may not have any reminders data")
except Exception as e:
    print(f"[ERROR] Unexpected error: {e}")
    import traceback
    traceback.print_exc()
