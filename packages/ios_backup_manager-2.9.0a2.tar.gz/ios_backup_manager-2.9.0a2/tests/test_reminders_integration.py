"""
Test Reminders extractor integration with FullExtractionManager
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from full_extraction_manager import FullExtractionManager

# Test with the backup that has reminders
backup_path = r"Q:\6697994\iTunes Backup\00008130-001A642E2162001C"
output_dir = r"C:\Users\Ontrack\Desktop\test_reminders_integration"

print("=" * 80)
print("Testing Reminders Integration with FullExtractionManager")
print("=" * 80)
print()

try:
    # Initialize extraction manager with only reminders category
    manager = FullExtractionManager(
        backup_path=backup_path,
        output_base_dir=output_dir,
        categories=['reminders']
    )
    print("[OK] FullExtractionManager initialized")
    print()

    # Get available categories
    print("Checking available categories...")
    available = manager.get_available_categories()

    if 'reminders' in available:
        reminders_info = available['reminders']
        print(f"  Reminders category found:")
        print(f"    Display Name: {reminders_info['display_name']}")
        print(f"    Available: {reminders_info['available']}")
        print(f"    Count: {reminders_info['count']}")
        print()

        if reminders_info['available']:
            print("[OK] Reminders category is available in backup")
            print()

            # Test extraction
            print("Testing extraction...")
            os.makedirs(output_dir, exist_ok=True)

            def progress_callback(update):
                """Print progress updates."""
                category = update.get('category', 'Unknown')
                status = update.get('status', '')
                item_current = update.get('item_current', 0)
                item_total = update.get('item_total', 0)

                if status == 'extracting':
                    print(f"  {category}: {item_current}/{item_total}")
                elif status == 'completed':
                    print(f"  {category}: Completed ({item_current} items)")
                elif status == 'skipped':
                    print(f"  {category}: Skipped")
                elif status == 'failed':
                    error = update.get('item_name', 'Unknown error')
                    print(f"  {category}: Failed - {error}")

            summary = manager.extract_all(progress_callback=progress_callback)

            print()
            print("=" * 80)
            print("Extraction Summary:")
            print(f"  Duration: {summary['duration']:.1f}s")
            print(f"  Successful: {summary['successful']}")
            print(f"  Failed: {summary['failed']}")
            print(f"  Skipped: {summary['skipped']}")
            print(f"  Total Items: {summary['total_items']}")
            print()

            if 'reminders' in summary['results']:
                result = summary['results']['reminders']
                print(f"  Reminders Status: {result['status']}")
                print(f"  Reminders Count: {result.get('count', 0)}")

                if result['status'] == 'success':
                    print()
                    print(f"[OK] Reminders extracted successfully!")
                    print(f"  Check: {output_dir}\\Reminders\\Reminders.html")
                else:
                    error = result.get('error', 'Unknown')
                    print(f"[FAIL] Extraction failed: {error}")

            print("=" * 80)
        else:
            print("[INFO] Reminders category not available in this backup")
    else:
        print("[ERROR] Reminders category not found in registry")

except Exception as e:
    print(f"[ERROR] {e}")
    import traceback
    traceback.print_exc()
