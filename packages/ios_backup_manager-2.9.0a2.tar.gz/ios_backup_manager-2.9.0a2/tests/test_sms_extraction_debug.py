"""
Debug SMS extraction issues for backup Q:\6697994
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from extractors.sms_extractor import SMSExtractor

backup_path = r"Q:\6697994\iTunes Backup\00008130-001A642E2162001C"

print("=" * 80)
print("SMS Extraction Debug")
print("=" * 80)
print()

try:
    extractor = SMSExtractor(backup_path)

    # Get all conversations
    conversations = extractor.get_conversations()
    print(f"Total conversations: {len(conversations)}")
    print()

    # Find Julie conversation (+16124327236)
    julie_conv = None
    for conv in conversations:
        # Check if any participant has this phone number
        for participant in conv['participants']:
            if "6124327236" in participant['id']:
                julie_conv = conv
                break
        if julie_conv:
            break

    if julie_conv:
        chat_id = julie_conv['chat_id']
        participant_ids = [p['id'] for p in julie_conv['participants']]
        print(f"Found Julie conversation:")
        print(f"  Chat ID: {chat_id}")
        try:
            print(f"  Display Name: {julie_conv['display_name']}")
        except UnicodeEncodeError:
            print(f"  Display Name: (contains unicode characters)")
        print(f"  Participants: {', '.join(participant_ids)}")
        print(f"  Message count (from conv list): {julie_conv['message_count']}")
        print()

        # Get messages
        print("Fetching messages...")
        messages = extractor.get_messages(chat_id)
        print(f"Retrieved {len(messages)} messages")
        print()

        # Count messages with attachments
        with_att = sum(1 for m in messages if m['attachments'])
        total_att = sum(len(m['attachments']) for m in messages)
        print(f"Messages with attachments: {with_att}")
        print(f"Total attachments: {total_att}")
        print()

        # Show sample
        print("Sample of first 10 messages:")
        for i, msg in enumerate(messages[:10], 1):
            text = msg['text'][:50] if msg['text'] else '(no text)'
            att_count = len(msg['attachments'])
            print(f"  {i}. {text} [attachments: {att_count}]")
    else:
        print("Julie conversation not found")

except Exception as e:
    print(f"ERROR: {e}")
    import traceback
    traceback.print_exc()
