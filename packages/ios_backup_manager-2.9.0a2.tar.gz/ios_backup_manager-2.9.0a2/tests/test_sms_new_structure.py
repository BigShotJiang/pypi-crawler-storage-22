#!/usr/bin/env python3
"""Test the new SMS export structure with Messages.html index."""

import sys
import os
sys.path.insert(0, '.')

from extractors.sms_extractor import SMSExtractor

def test_new_structure():
    """Test SMS export with new structure."""

    backup_path = r"Q:\6685679\iTunes Backup\95c5156d9e88e4a770fe910f3efdd746c227dbd9"
    output_path = r"Q:\testdata\sampleoutput\SMS_NEW_TEST"

    print(f"{'='*70}")
    print("Testing New SMS Export Structure")
    print(f"{'='*70}")

    try:
        # Create extractor
        print(f"\n1. Creating SMS extractor...")
        extractor = SMSExtractor(backup_path)

        # Get conversations (limit to 5 for quick test)
        print(f"2. Loading conversations...")
        conversations = extractor.get_items(limit=5)
        print(f"   Found {len(conversations)} conversations")

        # Show what we're exporting
        print(f"\n3. Conversations to export:")
        for i, conv in enumerate(conversations, 1):
            print(f"   {i}. {conv['display_name']} ({conv['message_count']} messages)")

        # Export with new structure
        print(f"\n4. Exporting to: {output_path}")
        success = extractor.export(conversations, output_path)

        if not success:
            print("[FAILED] Export failed")
            return False

        # Check new structure
        print(f"\n5. Verifying new structure...")

        messages_html = os.path.join(output_path, 'Messages.html')
        conversations_dir = os.path.join(output_path, 'Conversations')
        attachments_dir = os.path.join(output_path, 'Message Attachments')

        checks = [
            ('Messages.html exists', os.path.exists(messages_html)),
            ('Conversations/ directory exists', os.path.exists(conversations_dir)),
            ('Message Attachments/ directory exists', os.path.exists(attachments_dir))
        ]

        for check_name, result in checks:
            status = '✓' if result else '✗'
            print(f"   [{status}] {check_name}")

        # Count files in Conversations directory
        if os.path.exists(conversations_dir):
            conv_files = [f for f in os.listdir(conversations_dir) if f.endswith('.html')]
            print(f"   [✓] {len(conv_files)} conversation HTML files in Conversations/")

        # Show Messages.html size
        if os.path.exists(messages_html):
            size = os.path.getsize(messages_html)
            print(f"   [✓] Messages.html size: {size:,} bytes")

        print(f"\n{'='*70}")
        print("[SUCCESS] New structure created!")
        print(f"{'='*70}")
        print(f"\nOpen in browser: {messages_html}")

        return True

    except Exception as e:
        print(f"[ERROR] {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_new_structure()
    sys.exit(0 if success else 1)
