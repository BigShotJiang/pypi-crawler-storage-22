#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test script to verify Messenger and Instagram integration with iOS Backup Manager.
"""

import sys
import os
import io

# Fix Windows console encoding
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')


def test_messenger_integration():
    """Test that Messenger extractor can be instantiated via extraction manager."""
    print("\n" + "=" * 80)
    print("Testing Facebook Messenger Integration")
    print("=" * 80)

    try:
        from full_extraction_manager import FullExtractionManager

        # Check if messenger is in registry
        if 'messenger' not in FullExtractionManager.CATEGORY_REGISTRY:
            print("❌ FAIL: 'messenger' not found in CATEGORY_REGISTRY")
            return False

        metadata = FullExtractionManager.CATEGORY_REGISTRY['messenger']
        print(f"✓ Found in registry: {metadata[0]} {metadata[1]}")
        print(f"  - Extractor class: {metadata[2]}")
        print(f"  - Export folder: {metadata[3]}")

        # Try to import the extractor class
        from extractors.messenger_extractor import MessengerExtractor
        print("✓ MessengerExtractor class imports successfully")

        # Check it has required methods
        required_methods = ['get_count', 'get_items', 'export']
        for method in required_methods:
            if not hasattr(MessengerExtractor, method):
                print(f"❌ FAIL: MessengerExtractor missing method '{method}'")
                return False
        print(f"✓ All required methods present: {', '.join(required_methods)}")

        print("\n✅ Messenger integration test PASSED")
        return True

    except Exception as e:
        print(f"❌ FAIL: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_instagram_integration():
    """Test that Instagram extractor can be instantiated via extraction manager."""
    print("\n" + "=" * 80)
    print("Testing Instagram Direct Integration")
    print("=" * 80)

    try:
        from full_extraction_manager import FullExtractionManager

        # Check if instagram is in registry
        if 'instagram' not in FullExtractionManager.CATEGORY_REGISTRY:
            print("❌ FAIL: 'instagram' not found in CATEGORY_REGISTRY")
            return False

        metadata = FullExtractionManager.CATEGORY_REGISTRY['instagram']
        print(f"✓ Found in registry: {metadata[0]} {metadata[1]}")
        print(f"  - Extractor class: {metadata[2]}")
        print(f"  - Export folder: {metadata[3]}")

        # Try to import the extractor class
        from extractors.instagram_extractor import InstagramExtractor
        print("✓ InstagramExtractor class imports successfully")

        # Check it has required methods
        required_methods = ['get_count', 'get_items', 'export']
        for method in required_methods:
            if not hasattr(InstagramExtractor, method):
                print(f"❌ FAIL: InstagramExtractor missing method '{method}'")
                return False
        print(f"✓ All required methods present: {', '.join(required_methods)}")

        print("\n✅ Instagram integration test PASSED")
        return True

    except Exception as e:
        print(f"❌ FAIL: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_manager_can_detect_categories():
    """Test that FullExtractionManager can detect new categories."""
    print("\n" + "=" * 80)
    print("Testing Category Detection via FullExtractionManager")
    print("=" * 80)

    try:
        from full_extraction_manager import FullExtractionManager

        # Use a dummy backup path
        dummy_backup = r"O:\Personal\Martin\JIT\iOSBackupMerger\SchemaTests"

        # Create manager (it won't find actual databases, but should handle gracefully)
        manager = FullExtractionManager(
            backup_path=dummy_backup,
            output_base_dir=r"O:\temp\test_output",
            categories=['messenger', 'instagram']
        )

        print("✓ FullExtractionManager instantiated with messenger and instagram")

        # Try to get available categories (will mark them as unavailable, but shouldn't crash)
        available = manager.get_available_categories()

        if 'messenger' in available:
            print(f"✓ Messenger category detected (available: {available['messenger']['available']})")
        else:
            print("❌ FAIL: Messenger category not in available dict")
            return False

        if 'instagram' in available:
            print(f"✓ Instagram category detected (available: {available['instagram']['available']})")
        else:
            print("❌ FAIL: Instagram category not in available dict")
            return False

        print("\n✅ Category detection test PASSED")
        return True

    except Exception as e:
        print(f"❌ FAIL: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    print("\n" + "=" * 80)
    print("iOS Backup Manager - Third Party Integration Tests")
    print("=" * 80)

    results = {
        'messenger': test_messenger_integration(),
        'instagram': test_instagram_integration(),
        'detection': test_manager_can_detect_categories()
    }

    print("\n" + "=" * 80)
    print("Test Summary")
    print("=" * 80)

    for test_name, passed in results.items():
        status = "✅ PASSED" if passed else "❌ FAILED"
        print(f"{test_name.ljust(20)}: {status}")

    all_passed = all(results.values())
    print("\n" + "=" * 80)
    if all_passed:
        print("✅ ALL TESTS PASSED - Integration successful!")
    else:
        print("❌ SOME TESTS FAILED - Please review errors above")
    print("=" * 80)

    sys.exit(0 if all_passed else 1)


if __name__ == "__main__":
    main()
