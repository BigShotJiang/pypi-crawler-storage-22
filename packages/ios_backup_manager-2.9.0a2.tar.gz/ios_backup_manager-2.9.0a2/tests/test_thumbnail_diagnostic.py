"""
Diagnostic script to investigate thumbnail issue with FullSizeRender files.
Tests whether manifest_path is preserved and find_image_file() returns correct paths.
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from extractors.photos_extractor import PhotosExtractor

backup_path = r"Q:\6697994\iTunes Backup\00008130-001A642E2162001C"

print("=" * 80)
print("THUMBNAIL DIAGNOSTIC TEST")
print("=" * 80)
print()

# Initialize extractor
print("Initializing extractor...")
extractor = PhotosExtractor(backup_path)
extractor.use_hybrid_extraction = True
print()

# Get all items
all_items = extractor.get_items_hybrid(limit=None, offset=0, sort_by='date-desc', filter_by_existence=True)
print(f"Total items: {len(all_items):,}")
print()

# Find all FullSizeRender files
fullsize_items = [item for item in all_items if 'FullSizeRender' in item.get('filename', '')]
print(f"Found {len(fullsize_items)} FullSizeRender files")
print()

# Test first 5 FullSizeRender files
print("=" * 80)
print("Testing find_image_file() for first 5 FullSizeRender files")
print("=" * 80)
print()

for i, item in enumerate(fullsize_items[:5], 1):
    filename = item.get('filename')
    directory = item.get('directory', '')
    manifest_path = item.get('manifest_path')
    source = item.get('source')
    metadata_source = item.get('metadata_source', 'N/A')

    print(f"{i}. {filename}")
    print(f"   Directory: {directory}")
    print(f"   Manifest Path: {manifest_path}")
    print(f"   Source: {source}")
    print(f"   Metadata Source: {metadata_source}")

    # Call find_image_file() to see what path it returns
    resolved_path = extractor.find_image_file(item)

    if resolved_path:
        print(f"   Resolved Path: {resolved_path}")
        print(f"   File Exists: {os.path.exists(resolved_path)}")

        # Extract just the last part of the path for readability
        if 'Mutations' in resolved_path or 'Adjustments' in resolved_path:
            # Show relevant part of path
            parts = resolved_path.split(os.sep)
            if 'Mutations' in parts:
                mut_idx = parts.index('Mutations')
                relevant_path = os.sep.join(parts[mut_idx:])
                print(f"   -> {relevant_path}")
        else:
            # Show just filename if not in Mutations
            print(f"   -> {os.path.basename(resolved_path)}")
    else:
        print(f"   Resolved Path: None (FILE NOT FOUND)")

    print()

# Now test if different FullSizeRender files resolve to same path (that would be the bug!)
print("=" * 80)
print("Checking for duplicate resolved paths (THE BUG)")
print("=" * 80)
print()

path_to_items = {}
for item in fullsize_items:
    resolved_path = extractor.find_image_file(item)
    if resolved_path:
        if resolved_path not in path_to_items:
            path_to_items[resolved_path] = []
        path_to_items[resolved_path].append(item.get('filename'))

# Find duplicates
duplicates = {path: filenames for path, filenames in path_to_items.items() if len(filenames) > 1}

if duplicates:
    print(f"[BUG FOUND!] {len(duplicates)} paths resolve to multiple FullSizeRender files:")
    print()
    for path, filenames in list(duplicates.items())[:5]:  # Show first 5
        print(f"Path: {path}")
        print(f"  Resolves to {len(filenames)} files:")
        for fname in filenames:
            print(f"    - {fname}")
        print()
else:
    print("[PASS] No duplicate paths found - each FullSizeRender resolves to unique file")
    print()

print("=" * 80)
print("SUMMARY")
print("=" * 80)
print(f"Total FullSizeRender files: {len(fullsize_items)}")
print(f"Unique resolved paths: {len(path_to_items)}")
print(f"Duplicate paths (BUG): {len(duplicates)}")
print()

if duplicates:
    print("[DIAGNOSIS] Multiple FullSizeRender files are resolving to the same source file!")
    print("            This causes all thumbnails to show the same image.")
    print("            The issue is likely in find_image_file() strategy fallback.")
else:
    print("[DIAGNOSIS] find_image_file() is working correctly.")
    print("            The thumbnail issue may be elsewhere (caching, etc.)")

print("=" * 80)
