#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test script for thumbnail generation.

This script extracts a small set of photos from a backup and tests
thumbnail generation before integrating into the main UI.

Usage:
    python test_thumbnail_generation.py
"""

import os
import sys

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from extractors.photos_extractor import PhotosExtractor


def progress_callback(current, total, item_name):
    """
    Simple progress display.

    Args:
        current: Current item number
        total: Total items
        item_name: Name of current item

    Returns:
        True to continue, False to cancel
    """
    percentage = (current / total) * 100
    print(f"[{current}/{total}] ({percentage:.1f}%) - {item_name}")
    return True  # Continue processing


def test_thumbnail_generation():
    """Test thumbnail generation on a small photo set."""

    print("=" * 80)
    print("📷 Thumbnail Generation Test")
    print("=" * 80)
    print()

    # Get backup path
    if len(sys.argv) > 1:
        backup_path = sys.argv[1]
    else:
        print("Enter the path to an iOS backup directory:")
        print("(The folder containing Manifest.db)")
        print()
        backup_path = input("Backup path: ").strip()

        # Remove quotes if present
        if backup_path.startswith('"') and backup_path.endswith('"'):
            backup_path = backup_path[1:-1]
        if backup_path.startswith("'") and backup_path.endswith("'"):
            backup_path = backup_path[1:-1]

    if not backup_path:
        print("❌ No path provided. Exiting.")
        return 1

    if not os.path.isdir(backup_path):
        print(f"❌ ERROR: Path is not a directory: {backup_path}")
        return 1

    print()
    print(f"✅ Backup path: {backup_path}")
    print()

    # Get number of photos to test
    try:
        count_str = input("How many photos to test? (default: 20): ").strip()
        test_count = int(count_str) if count_str else 20
    except ValueError:
        test_count = 20

    print()
    print(f"📊 Testing with {test_count} photos")
    print()

    # Ask for output directory
    default_output = os.path.join(os.path.expanduser("~"), "Desktop", "thumbnail_test")
    output_str = input(f"Output directory (default: {default_output}): ").strip()
    output_path = output_str if output_str else default_output

    print()
    print(f"💾 Output: {output_path}")
    print()

    # Create output directory
    os.makedirs(output_path, exist_ok=True)

    # Initialize extractor
    print("🔍 Initializing photos extractor...")
    try:
        extractor = PhotosExtractor(backup_path)
    except Exception as e:
        print(f"❌ ERROR: Failed to initialize extractor: {e}")
        import traceback
        traceback.print_exc()
        return 1

    # Get photo count
    total_photos = extractor.get_count()
    print(f"✅ Found {total_photos} total photos/videos in backup")
    print()

    if total_photos == 0:
        print("❌ No photos found in backup")
        return 1

    # Get a small subset
    print(f"📥 Fetching {test_count} items...")
    items = extractor.get_items(limit=test_count)

    if not items:
        print("❌ Failed to fetch items")
        return 1

    print(f"✅ Fetched {len(items)} items")
    print()

    # Show what we're exporting
    print("Items to export:")
    for idx, item in enumerate(items[:5], 1):
        filename = item.get('filename', 'Unknown')
        kind = 'Video' if item.get('kind') == 1 else 'Photo'
        print(f"  {idx}. {filename} ({kind})")
    if len(items) > 5:
        print(f"  ... and {len(items) - 5} more")
    print()

    # Export with thumbnail generation
    print("=" * 80)
    print("🚀 Starting export with thumbnail generation...")
    print("=" * 80)
    print()

    try:
        exported, failed = extractor.export(
            items=items,
            output_path=output_path,
            format='files',
            progress_callback=progress_callback,
            convert_heic=True,  # Convert HEIC to JPEG
            organize_by_date=False,  # Keep flat structure for testing
            generate_html_report=True  # ← THIS ENABLES THUMBNAIL GENERATION
        )

        print()
        print("=" * 80)
        print("📊 RESULTS")
        print("=" * 80)
        print(f"✅ Exported: {exported} items")
        print(f"❌ Failed:   {failed} items")
        print()

        # Check if thumbnails were created
        thumb_dir = os.path.join(output_path, 'thumbnails')
        if os.path.exists(thumb_dir):
            thumbnails = [f for f in os.listdir(thumb_dir) if f.endswith('.jpg')]
            print(f"✅ Thumbnails created: {len(thumbnails)}")
            print(f"   Location: {thumb_dir}")
            print()

            # Show sample thumbnails
            if thumbnails:
                print("Sample thumbnails:")
                for thumb in thumbnails[:5]:
                    thumb_path = os.path.join(thumb_dir, thumb)
                    size_kb = os.path.getsize(thumb_path) / 1024
                    print(f"  • {thumb} ({size_kb:.1f} KB)")
                if len(thumbnails) > 5:
                    print(f"  ... and {len(thumbnails) - 5} more")
            print()
        else:
            print("⚠️  No thumbnails directory found")
            print()

        # Check exported files
        photos_dir = os.path.join(output_path, 'Photos')
        if os.path.exists(photos_dir):
            photos = os.listdir(photos_dir)
            print(f"✅ Photos exported: {len(photos)}")
            print(f"   Location: {photos_dir}")
            print()

        videos_dir = os.path.join(output_path, 'Videos')
        if os.path.exists(videos_dir):
            videos = os.listdir(videos_dir)
            print(f"✅ Videos exported: {len(videos)}")
            print(f"   Location: {videos_dir}")
            print()

        print("=" * 80)
        print("✅ TEST COMPLETE!")
        print("=" * 80)
        print()
        print("Next steps:")
        print("  1. Check the output directory for exported files")
        print("  2. Open thumbnails/ folder to verify thumbnail quality")
        print("  3. Compare thumbnail sizes vs full images")
        print("  4. Verify video thumbnails (first frames extracted)")
        print()
        print(f"Output directory: {output_path}")

        return 0

    except Exception as e:
        print()
        print("=" * 80)
        print("❌ ERROR DURING EXPORT")
        print("=" * 80)
        print(f"{e}")
        print()
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(test_thumbnail_generation())
