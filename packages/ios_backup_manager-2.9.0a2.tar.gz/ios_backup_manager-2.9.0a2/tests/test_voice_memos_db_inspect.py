#!/usr/bin/env python3
"""Inspect the CloudRecordings.db database to understand its structure."""

import sqlite3
import os

# Test backup with 17 voice memos (newer iOS)
BACKUP_PATH = r"Q:\6695545\iTunes Backup\00008020-0019145E0102002E"
DB_FILE = r"Q:\6695545\iTunes Backup\00008020-0019145E0102002E\01\0184f304aede0effc040e5afb4acf16f210f8472"

def main():
    print("Inspecting CloudRecordings.db structure...")
    print(f"Database: {DB_FILE}")
    print()

    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    # List all tables
    print("=== Tables in database ===")
    cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = cur.fetchall()
    for table in tables:
        print(f"  - {table['name']}")
    print()

    # Check ZRECORDING table structure
    print("=== ZRECORDING table columns ===")
    cur.execute("PRAGMA table_info(ZRECORDING)")
    columns = cur.fetchall()
    for col in columns:
        print(f"  {col['name']:30} {col['type']:15} (NOT NULL: {col['notnull']}, DEFAULT: {col['dflt_value']})")
    print()

    # Count total records
    print("=== Record counts ===")
    cur.execute("SELECT COUNT(*) FROM ZRECORDING")
    total = cur.fetchone()[0]
    print(f"  Total records: {total}")

    # Check how many have ZPATH
    cur.execute("SELECT COUNT(*) FROM ZRECORDING WHERE ZPATH IS NOT NULL AND ZPATH != ''")
    with_path = cur.fetchone()[0]
    print(f"  Records with ZPATH: {with_path}")

    cur.execute("SELECT COUNT(*) FROM ZRECORDING WHERE ZPATH IS NULL OR ZPATH = ''")
    without_path = cur.fetchone()[0]
    print(f"  Records without ZPATH: {without_path}")
    print()

    # Show sample records from ZRECORDING
    print("=== Sample records from ZRECORDING (first 5) ===")
    cur.execute("SELECT * FROM ZRECORDING LIMIT 5")
    records = cur.fetchall()

    for i, record in enumerate(records, 1):
        print(f"\nRecord {i}:")
        for key in record.keys():
            value = record[key]
            if value is not None:
                print(f"  {key:30} = {value}")

    # Check ZCLOUDRECORDING table
    print("\n" + "="*80)
    print("=== ZCLOUDRECORDING table ===")
    cur.execute("PRAGMA table_info(ZCLOUDRECORDING)")
    columns = cur.fetchall()
    print("Columns:")
    for col in columns:
        print(f"  {col['name']:30} {col['type']:15} (NOT NULL: {col['notnull']}, DEFAULT: {col['dflt_value']})")

    cur.execute("SELECT COUNT(*) FROM ZCLOUDRECORDING")
    cloud_count = cur.fetchone()[0]
    print(f"\nTotal records in ZCLOUDRECORDING: {cloud_count}")

    if cloud_count > 0:
        print("\nSample records from ZCLOUDRECORDING (first 5):")
        cur.execute("SELECT * FROM ZCLOUDRECORDING LIMIT 5")
        cloud_records = cur.fetchall()

        for i, record in enumerate(cloud_records, 1):
            print(f"\nRecord {i}:")
            for key in record.keys():
                value = record[key]
                if value is not None:
                    print(f"  {key:30} = {value}")

    # Check for the actual audio files in Manifest.db
    print("\n" + "="*80)
    print("=== Checking Manifest.db for .m4a files ===")
    manifest_path = os.path.join(BACKUP_PATH, 'Manifest.db')
    if os.path.exists(manifest_path):
        manifest_conn = sqlite3.connect(manifest_path)
        manifest_conn.row_factory = sqlite3.Row
        manifest_cur = manifest_conn.cursor()

        manifest_cur.execute("""
            SELECT domain, relativePath, fileID
            FROM Files
            WHERE relativePath LIKE '%.m4a'
            AND domain LIKE '%VoiceMemos%'
            ORDER BY relativePath
        """)

        m4a_files = manifest_cur.fetchall()
        print(f"\nFound {len(m4a_files)} .m4a files in VoiceMemos domain:")
        for f in m4a_files:
            print(f"  {f['domain']} -> {f['relativePath']}")

        manifest_conn.close()

    conn.close()

if __name__ == '__main__':
    main()
