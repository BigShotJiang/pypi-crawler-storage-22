#!/usr/bin/env python3
"""
Test Voice Memos GUI preview window.
"""

import sys
import tkinter as tk
sys.path.insert(0, '.')

from extractors.voice_memos_extractor import VoiceMemosExtractor
from preview_windows.voice_memos_preview import VoiceMemosPreviewWindow

def test_voice_memos_preview():
    """Test voice memos preview window."""

    backup_path = r"Q:\6690340\iTunes Backup\00008020-000E09393C89002E"

    print("="*80)
    print("Voice Memos GUI Preview Test")
    print("="*80)
    print(f"\nBackup: {backup_path}\n")

    try:
        # Initialize extractor
        print("1. Initializing VoiceMemosExtractor...")
        extractor = VoiceMemosExtractor(backup_path)
        print(f"   [OK] VoiceMemosExtractor initialized")

        # Get count
        count = extractor.get_count()
        print(f"   Total voice memos: {count}")

        if count == 0:
            print("\n   [INFO] No voice memos to preview")
            return True

        # Create Tkinter root window
        print("\n2. Creating preview window...")
        root = tk.Tk()
        root.withdraw()  # Hide root window

        # Open preview window
        preview = VoiceMemosPreviewWindow(
            root,
            extractor,
            "Voice Memos",
            "iPhone XS Max"
        )

        print(f"   [OK] Preview window opened")
        print(f"\n   The preview window is now open.")
        print(f"   - Check that voice memos are listed correctly")
        print(f"   - Click on a memo to see its details")
        print(f"   - Verify the preview shows: title, date, duration, filename")
        print(f"   - Close the window when done testing\n")

        # Run the Tkinter event loop
        root.mainloop()

        print("\n" + "="*80)
        print("GUI PREVIEW TEST COMPLETED")
        print("="*80)

        return True

    except FileNotFoundError as e:
        print(f"\n[INFO] {e}")
        print("\nThis backup does not contain voice memos.")
        return True
    except Exception as e:
        print(f"\n[FAIL] Error during test: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_voice_memos_preview()
    sys.exit(0 if success else 1)
