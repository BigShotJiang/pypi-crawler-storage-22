#!/usr/bin/env python3
"""Test voicemail preview window with decoded transcripts."""

import sys
sys.path.insert(0, '.')
from extractors.voicemail_extractor import VoicemailExtractor

def test_preview():
    """Test that transcripts are decoded for preview."""
    backup_path = r"Q:\6692745\iTunes Backup\00008030-001E215E02B9402E"

    print(f"{'='*70}")
    print(f"Testing Voicemail Preview Data")
    print('='*70)

    try:
        # Initialize extractor
        extractor = VoicemailExtractor(backup_path)

        # Get first 3 voicemails with transcripts
        voicemails = extractor.get_items(limit=10)

        count = 0
        for vm in voicemails:
            if vm['has_transcript'] and vm['transcript_text'] and count < 3:
                count += 1
                print(f"\nVoicemail #{count}")
                print(f"From: {vm['sender']}")
                print(f"Date: {extractor._format_timestamp(vm['date'])}")
                print(f"Duration: {extractor._format_duration(vm['duration'])}")
                print(f"\nTranscript for preview ({len(vm['transcript_text'])} chars):")
                print(f"{vm['transcript_text']}")
                print(f"\n{'='*70}")

        print(f"\n[SUCCESS] Transcripts are properly decoded for preview display")
        return True

    except Exception as e:
        print(f"[ERROR] {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = test_preview()
    sys.exit(0 if success else 1)
