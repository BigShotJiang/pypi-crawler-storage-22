"""
Test script to verify WhatsApp hidden conversation fix
"""
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from extractors.whatsapp_extractor import WhatsAppExtractor

# Test backup path (the one with WhatsApp data)
backup_path = r"Q:\6695545\iTunes Backup\00008020-0019145E0102002E"

print("=" * 80)
print("WhatsApp Hidden Conversation Test")
print("=" * 80)
print()
print(f"Backup: {backup_path}")
print()

try:
    # Initialize extractor
    print("Initializing WhatsApp extractor...")
    extractor = WhatsAppExtractor(backup_path)

    # Get conversation count
    count = extractor.get_conversation_count()
    print(f"Total conversations (including hidden with messages): {count}")
    print()

    # Get all conversations
    print("Fetching conversations...")
    conversations = extractor.get_conversations()
    print(f"Retrieved {len(conversations)} conversations")
    print()

    # Count hidden conversations
    hidden_conversations = [conv for conv in conversations if conv.get('is_hidden', False)]
    print(f"Hidden conversations: {len(hidden_conversations)}")
    print()

    if hidden_conversations:
        print("Hidden conversation details:")
        for i, conv in enumerate(hidden_conversations, 1):
            print(f"  {i}. {conv['display_name']}")
            print(f"     Messages: {conv['message_count']}")
            print(f"     Last message: {conv['last_message'][:50]}..." if len(conv['last_message']) > 50 else f"     Last message: {conv['last_message']}")
            print()

    # Expected results
    print("=" * 80)
    print("Expected Results:")
    print("  - Total conversations: 32 (28 visible + 4 hidden with messages)")
    print("  - Hidden conversations: 4")
    print()
    print("Actual Results:")
    print(f"  - Total conversations: {count}")
    print(f"  - Hidden conversations: {len(hidden_conversations)}")
    print()

    if count >= 32 and len(hidden_conversations) == 4:
        print("SUCCESS: Hidden conversations are now included!")
    elif count > 28:
        print("PARTIAL SUCCESS: More conversations found, but count may not match expected")
    else:
        print("FAILED: Conversation count did not increase")

    print()
    print("=" * 80)

except Exception as e:
    print(f"ERROR: {e}")
    import traceback
    traceback.print_exc()
