"""
Third-party messaging app extractors
"""
