#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Instagram Direct Messages extractor for iOS backups.

Extracts messages from Instagram's DirectSQLiteDatabase (e.g., 5620318585.db)
and yields them in a normalized format.
"""

import sqlite3
from datetime import datetime, timedelta
from typing import Iterator, Dict, Any, Optional
import sys
import os

# Add parent directory to path to import blob_decoders
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from blob_decoders import decode_unknown_blob


class InstagramExtractor:
    """
    Extract Instagram Direct messages from iOS backup databases.

    Database schema:
    - messages: Contains message_id, thread_id, archive (BLOB), class_name
    - threads: Contains thread_id, viewer_id, metadata (BLOB)

    The archive column contains NSKeyedArchiver-encoded data with message content.
    """

    # Apple's reference date (2001-01-01 00:00:00 UTC)
    APPLE_EPOCH = datetime(2001, 1, 1)

    def __init__(self, db_path: str):
        """
        Initialize the Instagram extractor.

        Args:
            db_path: Path to the Instagram Direct database file (e.g., 5620318585.db)
        """
        self.db_path = db_path
        self._viewer_id: Optional[str] = None
        self._thread_cache: Dict[str, Dict[str, Any]] = {}

    def _get_viewer_id(self, conn: sqlite3.Connection) -> Optional[str]:
        """
        Get the viewer's Instagram user ID (account owner).

        The viewer_id is stored in the threads table.
        """
        if self._viewer_id is not None:
            return self._viewer_id

        cur = conn.cursor()
        try:
            cur.execute("SELECT viewer_id FROM threads LIMIT 1")
            row = cur.fetchone()
            if row:
                self._viewer_id = row[0]
            return self._viewer_id
        except sqlite3.OperationalError:
            return None

    def _resolve_uid(self, value: Any, objects: list) -> Any:
        """Resolve a UID reference to its object."""
        # Handle plistlib.UID objects
        if hasattr(value, 'data') and hasattr(value, '__class__') and value.__class__.__name__ == 'UID':
            try:
                uid = value.data
                if 0 <= uid < len(objects):
                    return objects[uid]
            except (AttributeError, IndexError):
                pass
        # Handle string representations (shouldn't happen with plistlib, but just in case)
        elif isinstance(value, str) and value.startswith("UID(") and value.endswith(")"):
            uid_str = value[4:-1]
            try:
                uid = int(uid_str)
                if 0 <= uid < len(objects):
                    return objects[uid]
            except (ValueError, IndexError):
                pass
        return value

    def _find_key_in_object(self, obj: dict, key: str, objects: list) -> Any:
        """
        Find a key in an object, trying various name patterns.

        Instagram uses type-prefixed keys like "NSString*senderPk" or just "senderPk".
        """
        # Try exact key first
        if key in obj:
            return self._resolve_uid(obj[key], objects)

        # Try with common type prefixes
        for prefix in ["NSString*", "NSDate*", "NSArray*", "NSSet*", "NSDictionary*", "BOOL", "NSInteger"]:
            full_key = f"{prefix}{key}"
            if full_key in obj:
                return self._resolve_uid(obj[full_key], objects)

        # Try to find any key ending with the target key
        for obj_key in obj.keys():
            if obj_key.endswith(f"*{key}") or obj_key == key:
                return self._resolve_uid(obj[obj_key], objects)

        return None

    def _parse_nskeyed_object(self, obj: Dict[str, Any], key_path: str) -> Any:
        """
        Navigate an NSKeyedArchiver object structure using a key path.

        Args:
            obj: The decoded NSKeyedArchiver object
            key_path: Dot-separated path (e.g., "metadata.senderPk")

        Returns:
            The value at that path, or None
        """
        if not isinstance(obj, dict):
            return None

        # NSKeyedArchiver structure has $objects array
        objects = obj.get("$objects", [])
        if not objects:
            return None

        # Root object is typically at index 1
        root = objects[1] if len(objects) > 1 else None
        if not root or not isinstance(root, dict):
            return None

        # Navigate the key path
        keys = key_path.split(".")
        current = root

        for key in keys:
            if not isinstance(current, dict):
                return None

            # Find the key in current object
            value = self._find_key_in_object(current, key, objects)
            if value is None:
                return None

            # Handle NSDate objects
            if isinstance(value, dict) and "$class" in value and "NS.time" in value:
                return value.get("NS.time")

            current = value

        return current

    def _extract_text_from_content(self, decoded: Dict[str, Any]) -> Optional[str]:
        """
        Extract text from Instagram message content.

        Message content can be in different locations depending on message type:
        - Text messages: content.text or similar
        - Shared stories: content.placeholderTitle/placeholderMessage
        - Other types: various locations
        """
        if not isinstance(decoded, dict):
            return None

        objects = decoded.get("$objects", [])
        if not objects:
            return None

        # Search through all objects for text content
        # Common patterns:
        # - Direct text string
        # - placeholderTitle/placeholderMessage for shares
        # - message/text fields

        for obj in objects:
            if isinstance(obj, str) and len(obj) > 0:
                # Skip UIDs, class names, and system strings
                if obj.startswith(("UID(", "$", "SUBTYPE_", "NS", "IG", "FB")):
                    continue
                # Skip single characters
                if len(obj) == 1:
                    continue
                # This might be message text
                # Only return strings that look like actual message content
                if any(char.isalpha() for char in obj):
                    return obj

        return None

    def _get_thread_info(self, thread_id: str) -> Dict[str, Any]:
        """Get thread information from cache or database."""
        if thread_id in self._thread_cache:
            return self._thread_cache[thread_id]

        try:
            # Use a separate connection to avoid cursor nesting issues
            conn = sqlite3.connect(f"file:{self.db_path}?mode=ro", uri=True)
            cur = conn.cursor()

            cur.execute("""
                SELECT thread_id, thread_id_v2, viewer_id, metadata
                FROM threads
                WHERE thread_id = ?
                LIMIT 1
            """, (thread_id,))

            row = cur.fetchone()
            conn.close()

            if row:
                thread_info = {
                    "thread_id": row[0],
                    "thread_id_v2": row[1],
                    "viewer_id": row[2],
                    "metadata_blob": row[3]
                }

                # Try to decode metadata for thread name
                if row[3]:
                    decoded = decode_unknown_blob(row[3])
                    if decoded:
                        thread_info["metadata"] = decoded

                self._thread_cache[thread_id] = thread_info
                return thread_info

        except sqlite3.OperationalError:
            pass

        return {"thread_id": thread_id}

    def iter_messages(self) -> Iterator[Dict[str, Any]]:
        """
        Iterate over all Instagram Direct messages in normalized format.

        Yields:
            dict with keys:
                - app: "Instagram Direct"
                - conversation_id: str
                - conversation_name: str
                - message_id: str
                - sender_id: str
                - sender_display_name: str
                - participants: list[str]
                - timestamp: datetime
                - direction: "outgoing" | "incoming"
                - text: str | None
                - attachments: list (empty for now)
                - raw: dict (original row data)
        """
        conn = sqlite3.connect(f"file:{self.db_path}?mode=ro", uri=True)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        # Get viewer ID to determine message direction
        viewer_id = self._get_viewer_id(conn)

        try:
            # Query all messages
            cur.execute("""
                SELECT
                    message_id,
                    thread_id,
                    archive,
                    class_name,
                    row_id
                FROM messages
                ORDER BY row_id ASC
            """)

            for row in cur:
                message_id = row['message_id']
                thread_id = row['thread_id']
                archive_blob = row['archive']
                class_name = row['class_name']

                # Decode the archive BLOB
                decoded = decode_unknown_blob(archive_blob)
                if not decoded:
                    # Skip messages we can't decode
                    continue

                archive_data = decoded.get("value", {})

                # Extract sender ID from metadata
                sender_id = self._parse_nskeyed_object(archive_data, "metadata.senderPk")
                if not sender_id:
                    sender_id = "Unknown"

                # Extract timestamp from metadata
                timestamp_value = self._parse_nskeyed_object(archive_data, "metadata.serverTimestamp")

                if timestamp_value and isinstance(timestamp_value, (int, float)):
                    # Convert from Apple epoch (seconds since 2001-01-01)
                    timestamp = self.APPLE_EPOCH + timedelta(seconds=timestamp_value)
                else:
                    # Fallback to current time if we can't parse timestamp
                    timestamp = datetime.now()

                # Extract text from content
                text = self._extract_text_from_content(archive_data)
                if not text:
                    # Check for placeholder messages
                    placeholder_title = self._parse_nskeyed_object(archive_data, "content.placeholderTitle")
                    placeholder_msg = self._parse_nskeyed_object(archive_data, "content.placeholderMessage")

                    if placeholder_title or placeholder_msg:
                        text = f"[{placeholder_title or 'Shared Content'}]"
                        if placeholder_msg:
                            text += f" {placeholder_msg}"
                    else:
                        text = "[Media or Attachment]"

                # Get thread information
                thread_info = self._get_thread_info(thread_id)

                # Determine direction
                if viewer_id and str(sender_id) == str(viewer_id):
                    direction = "outgoing"
                elif viewer_id:
                    direction = "incoming"
                else:
                    direction = "unknown"

                # Build sender display name
                sender_display_name = f"Instagram User {sender_id}"

                # Conversation name (use thread_id_v2 if available, otherwise thread_id)
                conversation_name = thread_info.get("thread_id_v2", f"Thread {thread_id}")

                yield {
                    "app": "Instagram Direct",
                    "conversation_id": thread_id,
                    "conversation_name": conversation_name,
                    "message_id": message_id,
                    "sender_id": str(sender_id),
                    "sender_display_name": sender_display_name,
                    "participants": [],  # TODO: Extract from thread metadata
                    "timestamp": timestamp,
                    "direction": direction,
                    "text": text,
                    "attachments": [],  # TODO: Extract media attachments
                    "raw": {
                        "message_id": message_id,
                        "thread_id": thread_id,
                        "class_name": class_name,
                        "decoded_archive": archive_data
                    }
                }

        finally:
            conn.close()
