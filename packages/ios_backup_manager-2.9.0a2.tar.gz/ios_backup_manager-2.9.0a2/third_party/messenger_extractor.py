#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Facebook Messenger (Lightspeed) extractor for iOS backups.

Extracts messages from Facebook Messenger's lightspeed-raw.db database
and yields them in a normalized format.
"""

import sqlite3
from datetime import datetime
from typing import Iterator, Dict, Any, Optional


class MessengerExtractor:
    """
    Extract Facebook Messenger messages from iOS backup databases.

    Database schema (Lightspeed):
    - messages: Contains message text, sender_id, timestamp_ms
    - threads: Contains thread_name, thread_type
    - participants: Links contacts to threads
    - contacts: Contains contact names
    """

    def __init__(self, db_path: str):
        """
        Initialize the Messenger extractor.

        Args:
            db_path: Path to the lightspeed-raw.db file
        """
        self.db_path = db_path
        self._viewer_id: Optional[int] = None

    def _get_viewer_id(self, conn: sqlite3.Connection) -> Optional[int]:
        """
        Determine the viewer's user ID (account owner).

        Strategy: Find the contact_id that appears most frequently in
        participants where there's message activity (i.e., the primary account).
        """
        if self._viewer_id is not None:
            return self._viewer_id

        cur = conn.cursor()
        try:
            # Try to find the viewer ID from participants table
            # Look for the contact who is in the most threads
            cur.execute("""
                SELECT contact_id, COUNT(*) as thread_count
                FROM participants
                GROUP BY contact_id
                ORDER BY thread_count DESC
                LIMIT 1
            """)
            row = cur.fetchone()
            if row:
                self._viewer_id = row[0]
            return self._viewer_id
        except sqlite3.OperationalError:
            # If query fails, return None
            return None

    def _get_contact_name(self, conn: sqlite3.Connection, contact_id: int) -> Optional[str]:
        """Get display name for a contact ID."""
        try:
            # Use a separate cursor to avoid interfering with main iteration
            cur = conn.cursor()
            cur.execute("""
                SELECT name, first_name, last_name
                FROM contacts
                WHERE id = ?
                LIMIT 1
            """, (contact_id,))
            row = cur.fetchone()
            cur.close()
            if row:
                name, first_name, last_name = row
                if name:
                    return name
                if first_name or last_name:
                    return f"{first_name or ''} {last_name or ''}".strip()
            return None
        except sqlite3.OperationalError:
            # contacts table might not exist or have different schema
            return None

    def _get_participant_names(self, conn: sqlite3.Connection, thread_key: int) -> list:
        """Get list of participant names for a thread."""
        try:
            # Use a separate cursor to avoid interfering with main iteration
            cur = conn.cursor()
            cur.execute("""
                SELECT p.contact_id, p.nickname, c.name, c.first_name, c.last_name
                FROM participants p
                LEFT JOIN contacts c ON p.contact_id = c.id
                WHERE p.thread_key = ?
            """, (thread_key,))

            participants = []
            for row in cur.fetchall():
                contact_id, nickname, name, first_name, last_name = row
                if nickname:
                    participants.append(nickname)
                elif name:
                    participants.append(name)
                elif first_name or last_name:
                    participants.append(f"{first_name or ''} {last_name or ''}".strip())
                else:
                    participants.append(f"User {contact_id}")

            cur.close()
            return participants
        except sqlite3.OperationalError:
            return []

    def _get_attachments(self, conn: sqlite3.Connection, message_id: str) -> list:
        """Get attachments for a message."""
        try:
            # Use a separate cursor to avoid interfering with main iteration
            cur = conn.cursor()
            cur.execute("""
                SELECT
                    attachment_fbid,
                    attachment_type,
                    filename,
                    filesize,
                    preview_url,
                    playable_url,
                    playable_url_mime_type,
                    playable_duration_ms
                FROM attachments
                WHERE message_id = ?
            """, (message_id,))

            attachments = []
            for row in cur.fetchall():
                fbid, att_type, filename, filesize, preview_url, playable_url, mime_type, duration = row

                attachment = {
                    'id': fbid,
                    'type': att_type,
                    'filename': filename,
                    'filesize': filesize,
                    'preview_url': preview_url,
                    'playable_url': playable_url,
                    'mime_type': mime_type,
                    'duration_ms': duration
                }
                attachments.append(attachment)

            cur.close()
            return attachments
        except sqlite3.OperationalError:
            # attachments table might not exist
            return []

    def iter_messages(self) -> Iterator[Dict[str, Any]]:
        """
        Iterate over all messages in normalized format.

        Yields:
            dict with keys:
                - app: "Facebook Messenger"
                - conversation_id: str
                - conversation_name: str
                - message_id: str
                - sender_id: str
                - sender_display_name: str
                - participants: list[str]
                - timestamp: datetime
                - direction: "outgoing" | "incoming"
                - text: str | None
                - attachments: list (empty for now)
                - raw: dict (original row data)
        """
        conn = sqlite3.connect(f"file:{self.db_path}?mode=ro", uri=True)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        # Get viewer ID to determine message direction
        viewer_id = self._get_viewer_id(conn)

        try:
            # Query messages with thread information
            cur.execute("""
                SELECT
                    m.*,
                    t.thread_name,
                    t.thread_type,
                    t.snippet
                FROM messages m
                INNER JOIN threads t ON m.thread_key = t.thread_key
                ORDER BY m.timestamp_ms ASC
            """)

            for row in cur:
                thread_key = row['thread_key']
                sender_id = row['sender_id']
                timestamp_ms = row['timestamp_ms']
                message_id = row['message_id']
                text = row['text']
                thread_name = row['thread_name']
                is_unsent = row['is_unsent']

                # Skip unsent messages
                if is_unsent:
                    continue

                # Get sender name (pass conn instead of cur to avoid cursor conflicts)
                sender_name = self._get_contact_name(conn, sender_id)
                if not sender_name:
                    sender_name = f"User {sender_id}"

                # Get participant list (pass conn instead of cur)
                participants = self._get_participant_names(conn, thread_key)

                # Determine conversation name
                if thread_name:
                    conversation_name = thread_name
                elif participants:
                    # For 1:1 chats, use the other person's name
                    if len(participants) == 2 and viewer_id:
                        # Find participants that aren't the viewer
                        # Use separate cursor for safety
                        temp_cur = conn.cursor()
                        temp_cur.execute("SELECT contact_id FROM participants WHERE thread_key = ?", (thread_key,))
                        participant_ids = [row[0] for row in temp_cur.fetchall()]
                        temp_cur.close()

                        other_participants = [participants[i] for i, pid in enumerate(participant_ids) if pid != viewer_id]
                        conversation_name = other_participants[0] if other_participants else "Direct Message"
                    elif len(participants) == 1:
                        conversation_name = participants[0]
                    else:
                        conversation_name = ", ".join(participants[:3])
                        if len(participants) > 3:
                            conversation_name += f" +{len(participants) - 3} more"
                else:
                    conversation_name = f"Thread {thread_key}"

                # Determine direction
                if viewer_id and sender_id == viewer_id:
                    direction = "outgoing"
                elif viewer_id:
                    direction = "incoming"
                else:
                    # Can't determine direction without viewer_id
                    direction = "unknown"

                # Convert timestamp (Unix timestamp in milliseconds)
                timestamp = datetime.fromtimestamp(timestamp_ms / 1000.0)

                # Get attachments for this message
                attachments = self._get_attachments(conn, message_id)

                # Handle missing text (e.g., attachment-only messages)
                if text:
                    display_text = text
                elif attachments:
                    # Describe attachment type
                    if len(attachments) == 1:
                        display_text = "[Attachment]"
                    else:
                        display_text = f"[{len(attachments)} Attachments]"
                else:
                    display_text = "[No content]"

                # Convert row to dict for raw data
                raw_data = dict(row)

                yield {
                    "app": "Facebook Messenger",
                    "conversation_id": str(thread_key),
                    "conversation_name": conversation_name,
                    "message_id": message_id,
                    "sender_id": str(sender_id),
                    "sender_display_name": sender_name,
                    "participants": participants,
                    "timestamp": timestamp,
                    "direction": direction,
                    "text": display_text,
                    "attachments": attachments,
                    "raw": raw_data
                }

        finally:
            conn.close()
