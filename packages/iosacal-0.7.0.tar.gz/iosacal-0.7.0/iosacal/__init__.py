import importlib.metadata

from iosacal.core import R, combine, simulate
from iosacal.plot import iplot

__VERSION__ = importlib.metadata.version("iosacal")
