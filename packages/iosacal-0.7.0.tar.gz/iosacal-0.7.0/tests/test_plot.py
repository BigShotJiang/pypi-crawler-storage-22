import pytest
import iosacal.plot as plot

from iosacal.core import R, CalibrationCurve


class TestSinglePlot:
    @pytest.fixture(autouse=True)
    def determination(self):
        determination = R(7345, 32, "Test-A")
        self.cal_age = determination.calibrate(CalibrationCurve("intcal13"))

    @pytest.mark.mpl_image_compare
    def test_succeeds(self):
        fig = plot.single_plot(self.cal_age)


class TestMultiPlot:
    @pytest.fixture(autouse=True)
    def determinations(self):
        determinations = (
            R(7345, 35, "Test-A"),
            R(7387, 21, "Test-B"),
            R(7329, 40, "Test-C"),
        )
        self.cal_ages = [
            determination.calibrate("intcal20") for determination in determinations
        ]

    @pytest.mark.mpl_image_compare
    def test_succeeds(self):
        fig = plot.stacked_plot(self.cal_ages)
