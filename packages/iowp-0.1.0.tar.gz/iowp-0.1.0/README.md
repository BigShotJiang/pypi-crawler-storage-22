# IOWP - IO-Warrior Python Library

This library provides a Python interface for **IO-Warrior** devices, manufactured by [Code Mercenaries Hard- und Software GmbH](https://www.codemercs.com/en/io). 

It is a Python port of the **IOWJ** Java library, originally created by **Thomas Wagner**. 
The `iowp.iowkit` module is a reconstruction of the original `iowkit.dll` logic, designed to work natively on modern platforms like macOS (Apple Silicon) without the need for JNI or external binaries.

## Credits & Acknowledgments
- **Thomas Wagner**: Original author and lead developer.
- **Antigravity / Google Gemini**: Assisted in the automated porting and refactoring process from Java to Python.

## Installation

To install the library locally:

```bash
pip install .
```

This will automatically install the required `hidapi` dependency.

## Features

- Support for all IO-Warrior models including IO-Warrior24 (no longer available), IO-Warrior28, IO-Warrior40 (no longer available), IO-Warrior56, and **IO-Warrior100**.

> [!NOTE]
> The official name of the devices is **IO-Warrior** (e.g., IO-Warrior100). This library uses "IOW" as a shorthand for better readability in code.
- Fully self-contained package.
- Direct device control via the `IowFactory`.
- Event-based port listeners.
- Special mode functions (I2C, LCD).

## Usage Example

```python
from iowp.factory import IowFactory

# Get the factory instance and list connected devices
factory = IowFactory.get_instance()
devices = factory.get_devices()

for dev in devices:
    print(f"Found {dev.name} (Serial: {dev.serial})")
```

## Running the Factory Script

You can also run the bundled factory script to list devices:

```bash
iowp-factory
```
(or `python3 iowp/factory.py`)

## License & Use
This project is released under the **GNU General Public License v3.0 (GPLv3)**. 
This ensures the library remains free and open source. Commercial use in closed-source products may require a different licensing arrangement.

## Professional Services & Support
If you need professional assistance, custom implementations, or commercial support for your IO-Warrior project, please contact:

**Thomas Wagner - Ideenbüro Wagner**
[www.ideenbuero-wagner.de](https://www.ideenbuero-wagner.de/)

We offer:
- Custom driver and library development.
- Hardware integration and consulting.
- Commercial licensing for embedded projects.
