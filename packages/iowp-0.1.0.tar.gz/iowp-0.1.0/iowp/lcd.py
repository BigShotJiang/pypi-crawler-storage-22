import time
from typing import List, Optional
from iowp.special import SpecialModeFunction
from iowp.devices import IowDevice

class HD44780(SpecialModeFunction):
    """
    Implementation of the LCD special mode function for HD44780 controllers.
    Matches de.wagner_ibw.iow.lcd.HD44780.
    """
    FIRST_CTRL = 0
    SECOND_CTRL = 0x40
    NO_CTRL = 0

    def __init__(self):
        super().__init__()
        self.rows = 0
        self.cols = 0
        self.physical_rows = 0
        self.line_start_adr = []
        self.disp_on = True
        self.cursor_on = False
        self.char_blinking = False

    def get_name(self) -> str:
        return "LCD"

    def get_special_mode_function_id(self) -> int:
        return self.SMF_LCD_ID

    def get_report_ids(self) -> List[int]:
        return [0x06] # Note: Java code says 0x06, but matchReportId returns false. 
                      # This ID is for read reports which are handled by the device.

    def report_received(self, read_buffer: List[int]):
        pass # Not interested in reports

    def get_enable_report(self) -> List[int]:
        return [0x04, 0x01]

    def get_disable_report(self) -> List[int]:
        return [0x04, 0x00]

    def get_iow_special_bits(self, product_id: int) -> List[int]:
        if product_id == IowDevice.IOW24ID:
            return [0xf0, 0xff]
        elif product_id == IowDevice.IOW40ID:
            return [0x3c, 0xff]
        elif product_id == IowDevice.IOW56ID:
            return [0x00, 0x00, 0x00, 0xff, 0x1f]
        return []

    def set_iow_device(self, iow):
        super().set_iow_device(iow)
        if iow:
            self.init_lcd(self.FIRST_CTRL)

    def write_cmd(self, cmd: int, ctrl: int = FIRST_CTRL) -> int:
        wbuf = [0x05, 0x01 | ctrl, cmd]
        return self.iow.write_report(1, wbuf)

    def write_data(self, data: int, ctrl: int = FIRST_CTRL) -> int:
        wbuf = [0x05, 0x81 | ctrl, data]
        return self.iow.write_report(1, wbuf)

    def init_lcd(self, ctrl: int = FIRST_CTRL) -> int:
        wbuf = [0x05, 0x03 | ctrl, 0x34, 0x01, 0x0F]
        if self.physical_rows > 1:
            wbuf[2] |= 0x08
        return self.iow.write_report(1, wbuf)

    def clear_lcd(self):
        self.write_cmd(0x01)
        time.sleep(0.002)

    def set_cursor_home(self):
        self.write_cmd(0x02, self.FIRST_CTRL)
        time.sleep(0.002)

    def set_entry_mode(self, move_forward: bool, shift_disp: bool):
        cmd = 0x04
        if move_forward: cmd |= 0x02
        if shift_disp:   cmd |= 0x01
        self.write_cmd(cmd, self.FIRST_CTRL)

    def set_display_control(self, disp_on: bool, cursor_on: bool, char_blinking: bool):
        self.disp_on = disp_on
        self.cursor_on = cursor_on
        self.char_blinking = char_blinking
        cmd = 0x08
        if char_blinking: cmd |= 0x01
        if cursor_on:     cmd |= 0x02
        if disp_on:       cmd |= 0x04
        self.write_cmd(cmd, self.FIRST_CTRL)

    def set_shift_control(self, shift_disp: bool, shift_dir: bool):
        cmd = 0x10
        if shift_dir:  cmd |= 0x04
        if shift_disp: cmd |= 0x08
        self.write_cmd(cmd, self.FIRST_CTRL)

    def write_line(self, row: int, col_or_clear, clear_or_str=None, str_val=None):
        """
        Implementation of the overloaded writeLine methods.
        Matches:
        public void writeLine(int row, boolean clear, String str)
        public void writeLine(int row, int col, boolean clear, String str)
        """
        if str_val is not None:
            # writeLine(int row, int col, boolean clear, String str)
            col = col_or_clear
            clear = clear_or_str
            str_data = str_val
        elif isinstance(clear_or_str, str):
            # writeLine(int row, boolean clear, String str)
            col = 1
            clear = col_or_clear
            str_data = clear_or_str
        else:
            raise ValueError("Invalid arguments for write_line")

        if row > self.rows:
            raise ValueError(f"Only row 1...{self.rows} allowed!")
        if col > self.cols:
            raise ValueError(f"Only column 1...{self.cols} allowed!")

        if clear:
            self.set_ddram_addr(self.line_start_adr[row - 1] + col - 1, self.FIRST_CTRL)
            padding = " " * (self.cols - (col - 1))
            self.write_string(padding)

        available = self.cols - (col - 1)
        trimmed_str = str_data[:available]
        self.set_ddram_addr(self.line_start_adr[row - 1] + col - 1, self.FIRST_CTRL)
        self.write_string(trimmed_str)

    def write_string(self, str_data: str, ctrl: int = FIRST_CTRL):
        if not str_data:
            return
            
        payload_size = self.iow._smf_report_length - 2
        data_bytes = [ord(c) for c in str_data]
        pointer = 0
        total = len(data_bytes)

        while pointer < total:
            chunk_len = min(total - pointer, payload_size)
            wbuf = [0] * self.iow._smf_report_length
            wbuf[0] = 0x05
            wbuf[1] = 0x80 | ctrl | chunk_len
            
            for i in range(chunk_len):
                wbuf[i + 2] = data_bytes[pointer + i]
            
            self.iow.write_report(1, wbuf)
            pointer += chunk_len

    def set_ddram_addr(self, address: int, ctrl: int = FIRST_CTRL):
        cmd = 0x80 | address
        return self.write_cmd(cmd, ctrl)

    def set_cgram_addr(self, address: int, ctrl: int = FIRST_CTRL):
        cmd = 0x40 | address
        return self.write_cmd(cmd, ctrl)

    def set_cursor(self, row: int, col: int):
        if row > self.rows:
            raise ValueError(f"Only row 1...{self.rows} allowed!")
        address = self.line_start_adr[row - 1] + col - 1
        self.set_ddram_addr(address, self.FIRST_CTRL)

    def set_cursor_disp_on(self):
        self.set_display_control(True, self.cursor_on, self.char_blinking)

    def set_disp_off(self):
        self.set_display_control(False, self.cursor_on, self.char_blinking)

    def set_cursor_on(self):
        self.set_display_control(self.disp_on, True, self.char_blinking)

    def set_cursor_off(self):
        self.set_display_control(self.disp_on, False, self.char_blinking)

    def set_cursor_left(self):
        self.write_cmd(0x10, self.FIRST_CTRL)

    def set_cursor_right(self):
        self.write_cmd(0x14, self.FIRST_CTRL)

    def move_sprite(self, row: int, sprites: List[str], wait_ms: int):
        if row > self.rows:
            raise ValueError(f"Only row 1...{self.rows} allowed!")
            
        count_steps = len(sprites)
        self.write_line(row, True, "")
        
        step = 0
        space = ""
        for i in range(self.cols + 1):
            if i != 0:
                space = " " + space
            
            self.write_line(row, False, space + sprites[step])
            step += 1
            if step == count_steps:
                step = 0
            
            time.sleep(wait_ms / 1000.0)

    def set_special_char(self, code: int, pattern: List[int]):
        if not (0 <= code <= 7):
            raise ValueError("Only code 0...7 allowed!")
        if len(pattern) != 8:
            raise ValueError("Pattern must be 8 lines!")

        self.set_cgram_addr(code * 8, self.FIRST_CTRL)
        
        # Write first 6 bytes
        wbuf1 = [0x05, 0x86] + pattern[:6]
        self.iow.write_report(1, wbuf1)
        
        # Write remaining 2 bytes
        wbuf2 = [0x05, 0x82] + pattern[6:8] + [0, 0, 0, 0]
        self.iow.write_report(1, wbuf2)

class LCD2x16(HD44780):
    """
    Concrete implementation for 2x16 LCD displays.
    """
    def __init__(self):
        super().__init__()
        self.cols = 16
        self.rows = 2
        self.physical_rows = 2
        self.line_start_adr = [0x00, 0x40]

class LCD2x40(HD44780):
    """
    Concrete implementation for 2x16 LCD displays.
    """
    def __init__(self):
        super().__init__()
        self.cols = 40
        self.rows = 2
        self.physical_rows = 2
        self.line_start_adr = [0x00, 0x40]