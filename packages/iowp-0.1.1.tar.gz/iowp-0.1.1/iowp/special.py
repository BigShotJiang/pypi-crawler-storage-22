from abc import ABC, abstractmethod
from typing import List, Optional

class SpecialModeFunction(ABC):
    """
    Base class for special mode function implementations (e.g. I2C, LCD, ADC).
    Matches de.wagner_ibw.iow.SpecialModeFunction.
    """
    
    SMF_LCD_ID   = 1
    SMF_RC5_ID   = 2
    SMF_I2C_ID   = 4
    SMF_CPS_ID   = 8
    SMF_SPI_ID   = 16
    SMF_SMX_ID   = 32
    SMF_LED_ID   = 64
    SMF_SMX16_ID = 128
    SMF_CTI_ID   = 256
    SMF_ADC_ID   = 512
    SMF_PWM_ID   = 1024

    def __init__(self):
        self.iow = None

    @abstractmethod
    def get_special_mode_function_id(self) -> int:
        raise NotImplementedError

    @abstractmethod
    def get_report_ids(self) -> List[int]:
        raise NotImplementedError

    @abstractmethod
    def report_received(self, read_buffer: List[int]):
        raise NotImplementedError

    def match_report_id(self, report_id: int) -> bool:
        return report_id in self.get_report_ids()

    def set_iow_device(self, iow):
        self.iow = iow

    @abstractmethod
    def get_iow_special_bits(self, product_id: int) -> List[int]:
        raise NotImplementedError

    @abstractmethod
    def get_enable_report(self) -> List[int]:
        raise NotImplementedError

    @abstractmethod
    def get_disable_report(self) -> List[int]:
        raise NotImplementedError

    @abstractmethod
    def get_name(self) -> str:
        raise NotImplementedError

    def check_compatibility(self, product_id: int, rev: int, special_modes: int) -> Optional[str]:
        return None  # Default: compatible
