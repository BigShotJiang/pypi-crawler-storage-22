from ipanema.models import database_connection, Language, LanguageFamily, Label


def query_language(s):
    with database_connection():
        return Language.query(s)


def query_family(s):
    with database_connection():
        return LanguageFamily.query(s)


def query_label(s):
    lang_code, label = s.split(":", 2)
    with database_connection():
        return Label.query(lang_code, label or lang_code)
