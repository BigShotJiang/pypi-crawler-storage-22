from . import base, Language
from peewee import TextField, ForeignKeyField, CompositeKey, DoesNotExist
from playhouse.sqlite_ext import JSONField
from typing import Self


class Label(base.Model):
    language = ForeignKeyField(Language, db_column="lang_code", backref='labels')
    name = TextField(null=False)
    accent_display = TextField(null=True)
    accent_wikipedia = TextField(null=True)
    wikidata_item = TextField(null=True)
    wikipedia = TextField(null=True)
    region = TextField(null=True)
    regional_categories = TextField(null=True)
    aliases = JSONField(null=True)
    parent_label = TextField(null=True)

    class Meta:
        table_name = 'labels'
        primary_key = CompositeKey('language', 'name')

    @classmethod
    def query(cls, lang_code: str, name: str) -> Self | None:
        """
        :param name: a label name
        :return: the label or None
        """
        try:
            return cls.get((cls.language == lang_code) & (cls.name == name))
        except DoesNotExist:
            alias = cls.aliases.children().alias('aliases')
            return cls.select() \
                      .from_(cls, alias) \
                      .where((cls.language == lang_code) & (alias.c.value == name)) \
                      .get()
