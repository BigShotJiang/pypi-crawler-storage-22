from ipmg.cli.commands import run

if __name__ == "__main__":
    run()
