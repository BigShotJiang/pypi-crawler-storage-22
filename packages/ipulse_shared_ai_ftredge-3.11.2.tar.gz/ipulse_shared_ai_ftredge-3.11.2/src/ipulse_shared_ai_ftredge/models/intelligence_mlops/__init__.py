# pylint: disable=missing-module-docstring
"""
🚀 INTELLIGENCE MLOPS MODELS
"""

from .ai_model_serving_instance import AIModelServingInstance

__all__ = ["AIModelServingInstance"]
