# Intelligence Outputs - Classifications
from .classification_inference_base import ClassificationInference

__all__ = [
    'ClassificationInference',
]
