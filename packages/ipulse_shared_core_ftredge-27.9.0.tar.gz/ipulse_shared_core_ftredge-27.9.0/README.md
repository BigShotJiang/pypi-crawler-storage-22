# ipulse_shared_core
Shared Models like User, Organization etc. Also includes shared enum_sets
