import uuid
import typing_extensions as typing

import discord_typings
import interactions as ipy

import modal_backport.components as components
from modal_backport.enums import ComponentType

__all__ = (
    "FileUploadComponent",
    "InputText",
    "LabelComponent",
    "Modal",
    "ParagraphText",
    "ShortText",
)


class InputText(ipy.InputText):
    def __init__(
        self,
        *,
        label: typing.Optional[str] = ipy.MISSING,
        style: typing.Union[ipy.TextStyles, int],
        custom_id: typing.Optional[str] = ipy.MISSING,
        placeholder: typing.Optional[str] = ipy.MISSING,
        value: typing.Optional[str] = ipy.MISSING,
        required: bool = True,
        min_length: typing.Optional[int] = ipy.MISSING,
        max_length: typing.Optional[int] = ipy.MISSING,
    ) -> None:
        super().__init__(
            label=label,
            style=style,
            custom_id=custom_id,
            placeholder=placeholder,
            value=value,
            required=required,
            min_length=min_length,
            max_length=max_length,
        )

    @classmethod
    def from_dict(cls, data: dict[str, typing.Any]) -> typing.Self:
        if data["style"] == ipy.TextStyles.SHORT:
            cls = ShortText
        elif data["style"] == ipy.TextStyles.PARAGRAPH:
            cls = ParagraphText

        return cls(
            label=data.get("label", ipy.MISSING),
            custom_id=data["custom_id"],
            placeholder=data["placeholder"],
            value=data["value"],
            required=data["required"],
            min_length=data["min_length"],
            max_length=data["max_length"],
        )


if typing.TYPE_CHECKING:

    class ShortText(ipy.ShortText):
        def __init__(
            self,
            *,
            label: typing.Optional[str] = ipy.MISSING,
            custom_id: typing.Optional[str] = ipy.MISSING,
            placeholder: typing.Optional[str] = ipy.MISSING,
            value: typing.Optional[str] = ipy.MISSING,
            required: bool = True,
            min_length: typing.Optional[int] = ipy.MISSING,
            max_length: typing.Optional[int] = ipy.MISSING,
        ) -> None: ...

    class ParagraphText(ipy.ParagraphText):
        def __init__(
            self,
            *,
            label: typing.Optional[str] = ipy.MISSING,
            custom_id: typing.Optional[str] = ipy.MISSING,
            placeholder: typing.Optional[str] = ipy.MISSING,
            value: typing.Optional[str] = ipy.MISSING,
            required: bool = True,
            min_length: typing.Optional[int] = ipy.MISSING,
            max_length: typing.Optional[int] = ipy.MISSING,
        ) -> None: ...

else:

    class ShortText(InputText):
        def __init__(
            self,
            *,
            label: typing.Optional[str] = ipy.MISSING,
            custom_id: typing.Optional[str] = ipy.MISSING,
            placeholder: typing.Optional[str] = ipy.MISSING,
            value: typing.Optional[str] = ipy.MISSING,
            required: bool = True,
            min_length: typing.Optional[int] = ipy.MISSING,
            max_length: typing.Optional[int] = ipy.MISSING,
        ) -> None:
            super().__init__(
                style=ipy.TextStyles.SHORT,
                label=label,
                custom_id=custom_id,
                placeholder=placeholder,
                value=value,
                required=required,
                min_length=min_length,
                max_length=max_length,
            )

    class ParagraphText(InputText):
        def __init__(
            self,
            *,
            label: typing.Optional[str] = ipy.MISSING,
            custom_id: typing.Optional[str] = ipy.MISSING,
            placeholder: typing.Optional[str] = ipy.MISSING,
            value: typing.Optional[str] = ipy.MISSING,
            required: bool = True,
            min_length: typing.Optional[int] = ipy.MISSING,
            max_length: typing.Optional[int] = ipy.MISSING,
        ) -> None:
            super().__init__(
                style=ipy.TextStyles.PARAGRAPH,
                label=label,
                custom_id=custom_id,
                placeholder=placeholder,
                value=value,
                required=required,
                min_length=min_length,
                max_length=max_length,
            )


class FileUploadComponent(ipy.BaseComponent):
    """
    An interactive component that allows users to upload files in modals.

    Attributes:
        custom_id: A unique identifier for the component.
        min_values: The minimum number of files that can be uploaded.
        max_values: The maximum number of files that can be uploaded.
        required: Whether the file upload is required.

    """

    def __init__(
        self,
        custom_id: typing.Optional[str] = None,
        min_values: int = 1,
        max_values: int = 1,
        required: bool = True,
    ):
        self.custom_id = custom_id or str(uuid.uuid4())
        self.min_values = min_values
        self.max_values = max_values
        self.required = required
        self.type = ComponentType.FILE_UPLOAD

    def to_dict(self) -> dict:
        return ipy.utils.dict_filter_none(
            {
                "type": self.type,
                "custom_id": self.custom_id,
                "min_values": self.min_values,
                "max_values": self.max_values,
                "required": self.required,
            }
        )

    @classmethod
    def from_dict(cls, data: dict) -> typing.Self:
        return cls(
            custom_id=data.get("custom_id"),
            min_values=data.get("min_values"),
            max_values=data.get("max_values"),
            required=data.get("required", True),
        )


class LabelComponent(ipy.BaseComponent):
    """
    A top-level layout component that wraps modal components with text as a label and optional description.

    Attributes:
        label: The text label for the component.
        description: An optional description for the component.
        component: The component to be wrapped.
        type: The type of the component, always ComponentType.LABEL.

    """

    def __init__(
        self,
        *,
        label: str,
        description: typing.Optional[str] = None,
        component: (
            ipy.BaseSelectMenu
            | components.BaseSelectMenu
            | ipy.InputText
            | FileUploadComponent
        ),
    ):
        self.label = label
        self.component = component
        self.description = description
        self.type = ComponentType.LABEL

    def to_dict(self) -> dict:
        return ipy.utils.dict_filter_none(
            {
                "type": self.type,
                "label": self.label,
                "description": self.description,
                "component": (
                    self.component.to_dict()
                    if hasattr(self.component, "to_dict")
                    else self.component
                ),
            }
        )

    @classmethod
    def from_dict(cls, data: dict) -> typing.Self:
        return cls(
            label=data["label"],
            description=data.get("description"),
            component=ipy.BaseComponent.from_dict_factory(
                data["component"],
                alternate_mapping={
                    ComponentType.INPUT_TEXT: ipy.InputText,
                    ComponentType.CHANNEL_SELECT: components.ChannelSelectMenu,
                    ComponentType.STRING_SELECT: components.StringSelectMenu,
                    ComponentType.USER_SELECT: components.UserSelectMenu,
                    ComponentType.ROLE_SELECT: components.RoleSelectMenu,
                    ComponentType.MENTIONABLE_SELECT: components.MentionableSelectMenu,
                    ComponentType.FILE_UPLOAD: FileUploadComponent,
                },
            ),
        )


class Modal(ipy.Modal):
    def __init__(
        self,
        *components: ipy.InputText | LabelComponent | ipy.TextDisplayComponent,
        title: str,
        custom_id: typing.Optional[str] = None,
    ) -> None:
        self.title: str = title
        self.components: list[
            ipy.InputText | LabelComponent | ipy.TextDisplayComponent
        ] = list(components)
        self.custom_id: str = custom_id or str(uuid.uuid4())

        self.type = ipy.CallbackType.MODAL

    def to_dict(self) -> discord_typings.ModalInteractionData:
        dict_components: list[dict] = []

        for component in self.components:
            if isinstance(component, ipy.InputText):
                dict_components.append(
                    {
                        "type": ComponentType.ACTION_ROW,
                        "components": [component.to_dict()],
                    }
                )
            elif isinstance(component, (LabelComponent, ipy.TextDisplayComponent)):
                dict_components.append(component.to_dict())
            else:
                # backwards compatibility behavior, remove in v6
                dict_components.append(
                    {
                        "type": ComponentType.ACTION_ROW,
                        "components": [component],
                    }
                )

        return {
            "type": self.type,
            "data": {
                "title": self.title,
                "custom_id": self.custom_id,
                "components": dict_components,
            },
        }

    def add_components(
        self, *components: ipy.InputText | LabelComponent | ipy.TextDisplayComponent
    ) -> None:
        """
        Add components to the modal.

        Args:
            *components: The components to add.

        """
        if len(components) == 1 and isinstance(components[0], (list, tuple)):
            components = components[0]
        self.components.extend(components)
