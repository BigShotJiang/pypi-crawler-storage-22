from pathlib import Path
from typing import Optional

from anywidget import AnyWidget
from pyannote.core import SlidingWindowFeature
from traitlets import Bool, Dict, Float, Integer, List, Unicode

from ..utils.sync import js_sync
from .labels import Labels


class TimeSeries(AnyWidget):
    """Display time series data

    Parameters
    ----------
    series : SlidingWindowFeature, optional
        Time series data to display.
        If provided, `duration` is inferred from `series`.
    duration : float, optional
        Duration of the audio the time series is associated with (in seconds).
        Required if `series` is not provided.
    labels: Labels, optional
        Labels with which to associate time series names.
        If not provided, a new Labels instance is created.
    height : int, optional
        Height of a plot (in pixels).
        Defaults to container height.
    overlay: bool, optional
        Whether to overlay plots or stack them vertically.
        Default is False (stacked).
    fill: bool, optional
        Whether to fill the area under the plot.
        Defaults to False (not filling).
    **kwargs : dict[str, list[float | int]]
        Time series data to display. Each keyword argument corresponds to a
        different time series, where the key is the name of the series and the
        value is a list of values between 0 and 1.
    """

    _esm = Path(__file__).parent.parent / "static" / "series.js"
    _css = Path(__file__).parent.parent / "static" / "series.css"

    # used to display time series
    duration = Float().tag(sync=True)
    time_series = Dict(key_trait=Unicode(), value_trait=List(Float())).tag(sync=True)

    # used to synchronize with a player
    current_time = Float(0.0).tag(sync=True)
    scroll_time = Float(0.0).tag(sync=True)
    zoom = Float().tag(sync=True)

    # height of a plot (in pixels)
    height = Integer(allow_none=True).tag(sync=True)
    # whether to overlay plots or stack them vertically
    overlay = Bool(False).tag(sync=True)
    # whether to fill the area under the plot
    fill = Bool(False).tag(sync=True)

    offset = Float(0.0).tag(sync=True)

    # used to synchronize pool of labels
    labels = Dict(key_trait=Unicode(), value_trait=Unicode()).tag(sync=True)

    def __init__(
        self,
        series: Optional[SlidingWindowFeature] = None,
        duration: Optional[float] = None,
        labels: Optional[Labels] = None,
        height: Optional[int] = None,
        overlay: bool = False,
        fill: bool = False,
        **kwargs: list[float | int],
    ):
        super().__init__()

        self._labels = labels or Labels()
        js_sync(self._labels, self, ["labels"])

        if series is not None:
            self.duration = series.sliding_window.step * series.data.shape[0]
            _, num_series = series.data.shape
            series_labels = getattr(series, "labels") or [f"#{i}" for i in range(num_series)]
            self.time_series = {
                label: series.data[:, i].tolist()
                for i, label in enumerate(series_labels)
            }

            for label in series_labels:
                _ = self._labels[label]

            self.offset = series.sliding_window.start

        else:
            if self.duration is None:
                raise ValueError("`duration` or `series` must be provided")

            self.duration = duration
            self.time_series = {k: v[:] for k, v in kwargs.items()}

            for label in self.time_series:
                _ = self._labels[label]

        self.height = height
        self.overlay = overlay
        self.fill = fill

    def __setitem__(self, name: str, values: list[float | int]):
        """Set time series data for a given name.

        Parameters
        ----------
        name : str
            Name of the time series.
        values : list of float or int
            Time series data to set.
        """
        time_series = {k: v[:] for k, v in self.time_series.items()}

        time_series[name] = values[:]

        _ = self._labels[name]
        # trigger traitlets sync
        self.time_series = time_series

    def __getitem__(self, name: str) -> list[float | int]:
        """Get time series data for a given name.
        Parameters
        ----------
        name : str
            Name of the time series.

        Returns
        -------
        time_series: list of float or int
            Time series data associated with the given name.
        """
        return self.time_series[name]
