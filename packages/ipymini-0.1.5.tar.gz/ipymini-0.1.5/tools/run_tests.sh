#!/usr/bin/env bash
pytest -q
pytest -q -m slow
