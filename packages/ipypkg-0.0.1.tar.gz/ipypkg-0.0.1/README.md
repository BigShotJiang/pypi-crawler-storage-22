# IPyPKG
A python package for my personal use