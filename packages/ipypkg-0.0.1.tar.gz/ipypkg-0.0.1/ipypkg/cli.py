import argparse
from ipypkg.noti import send_noti


def main():
    parser = argparse.ArgumentParser(prog="ipypkg", description="A python package for my personal use")
    subparsers = parser.add_subparsers(dest="command", required=True)

    noti = subparsers.add_parser("noti", help="noti.send_noti")
    noti.add_argument("--title", default="title from ipypkg cli")
    noti.add_argument("--message", default="message from ipypkg cli")
    noti.set_defaults(func=lambda args: send_noti(args.title, args.message))

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
