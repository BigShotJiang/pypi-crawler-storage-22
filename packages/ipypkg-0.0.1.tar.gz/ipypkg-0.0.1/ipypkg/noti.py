import requests

BASE_URL = "https://proxy.jae.one/v5/noti-admin"


def send_noti(title: str, message: str, noti_type: str = "IPyPKG"):
    data = {
        "type": noti_type,
        "title": title,
        "message": message,
    }
    try:
        requests.post(BASE_URL, data=data)
    except Exception as e:
        print(f"failed to send notification: {e}")
