from setuptools import setup, find_packages

setup(
    name="ipypkg",
    version="0.0.1",
    description="A python package for my personal use",
    author="jaeeewon",
    author_email="jaeeewon24@hufs.ac.kr",
    url="https://github.com/jaeeewon/ipypkg",
    packages=find_packages(),
    install_requires=["requests"],
    keywords=["debugging"],
    python_requires=">=3.6",
    entry_points={
        "console_scripts": [
            "ipypkg=ipypkg.cli:main",
        ],
    },
)
