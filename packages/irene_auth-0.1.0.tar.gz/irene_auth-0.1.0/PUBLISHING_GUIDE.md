# Publishing Irene Auth to PyPI

## Prerequisites

### 1. PyPI Account
- Create account at: https://pypi.org/account/register/
- Verify your email address

### 2. Get API Token
1. Go to: https://pypi.org/manage/account/token/
2. Click "Add API token"
3. Name: `irene-auth-upload`
4. Scope: "Entire account" (or specific to irene-auth after first upload)
5. Copy the token (starts with `pypi-`)
6. **IMPORTANT**: Save it securely - you can't see it again!

## Publishing Steps

### Option 1: Using Maturin (Recommended)

```powershell
# Set your PyPI token as environment variable
$env:MATURIN_PYPI_TOKEN="pypi-YOUR_TOKEN_HERE"

# Build and publish in one command
cd c:\Users\Sequa\Downloads\irene-auth
maturin publish
```

### Option 2: Build then Upload Separately

```powershell
# Build the wheel
cd c:\Users\Sequa\Downloads\irene-auth
maturin build --release

# Install twine if not already installed
pip install twine

# Upload to PyPI
twine upload target\wheels\irene_auth-0.1.0-cp313-cp313-win_amd64.whl
# Enter your PyPI username and password/token when prompted
```

### Option 3: Test on TestPyPI First (Recommended for First Time)

```powershell
# Build
maturin build --release

# Upload to TestPyPI
$env:MATURIN_PYPI_TOKEN="pypi-YOUR_TEST_PYPI_TOKEN"
maturin upload --repository testpypi

# Or with twine:
twine upload --repository testpypi target\wheels\irene_auth-0.1.0-cp313-cp313-win_amd64.whl

# Test installation from TestPyPI
pip install --index-url https://test.pypi.org/simple/ irene-auth
```

## Pre-Publication Checklist

- [x] All 8 features implemented
- [x] All tests passing
- [x] Documentation complete (README.md)
- [x] License file included (MIT)
- [x] Version number set (0.1.0)
- [x] Package metadata in pyproject.toml
- [x] Wheel built successfully
- [ ] PyPI account created
- [ ] API token obtained
- [ ] Package name available on PyPI

## Check Package Name Availability

Before publishing, check if the name is available:
https://pypi.org/project/irene-auth/

If taken, you may need to choose a different name in `pyproject.toml`.

## After Publishing

1. **Verify the package**:
   ```bash
   pip install irene-auth
   python -c "import irene_auth; print(irene_auth.__version__)"
   ```

2. **View on PyPI**:
   https://pypi.org/project/irene-auth/

3. **Add badges to README** (optional):
   ```markdown
   [![PyPI version](https://badge.fury.io/py/irene-auth.svg)](https://badge.fury.io/py/irene-auth)
   [![Downloads](https://pepy.tech/badge/irene-auth)](https://pepy.tech/project/irene-auth)
   ```

## Common Issues

### Issue: "Package name already taken"
**Solution**: Choose a different name in `pyproject.toml` under `[project]` section

### Issue: "Invalid token"
**Solution**: Regenerate token on PyPI and ensure it's copied correctly

### Issue: "Wheel platform not supported"
**Solution**: Build wheels for multiple platforms using GitHub Actions (see CI/CD section)

### Issue: "Missing long_description"
**Solution**: Already handled - we're using README.md as long description

## Multi-Platform Wheels (Optional)

To support Linux and macOS, use GitHub Actions:

1. Create `.github/workflows/release.yml` (already exists if you generated CI files)
2. Push a git tag: `git tag v0.1.0 && git push origin v0.1.0`
3. GitHub Actions will build wheels for all platforms
4. Download and upload all wheels to PyPI

## Version Updates

For future releases:

1. Update version in `pyproject.toml` and `Cargo.toml`
2. Update `CHANGELOG.md` (create if doesn't exist)
3. Build and test locally
4. Publish new version:
   ```bash
   maturin publish
   ```

## Security Considerations

✅ **Never commit your PyPI token to git**  
✅ **Use environment variables for tokens**  
✅ **Enable 2FA on your PyPI account**  
✅ **Use project-scoped tokens when possible**  
✅ **Regularly rotate your tokens**

---

## Quick Publish Command

Once you have your token:

```powershell
$env:MATURIN_PYPI_TOKEN="pypi-YOUR_TOKEN_HERE"
cd c:\Users\Sequa\Downloads\irene-auth
maturin publish
```

That's it! Your package will be live on PyPI within minutes.
