#!/usr/bin/env pwsh
# Quick publish script for Irene Auth

Write-Host "=" -NoNewline -ForegroundColor Cyan
Write-Host "=" * 69 -ForegroundColor Cyan
Write-Host "  IRENE AUTH - PyPI Publishing Script" -ForegroundColor Yellow
Write-Host "=" -NoNewline -ForegroundColor Cyan
Write-Host "=" * 69 -ForegroundColor Cyan
Write-Host ""

# Check if token is set
if (-not $env:MATURIN_PYPI_TOKEN) {
    Write-Host "[ERROR] PyPI token not set!" -ForegroundColor Red
    Write-Host ""
    Write-Host "Please set your PyPI token:" -ForegroundColor Yellow
    Write-Host '  $env:MATURIN_PYPI_TOKEN="pypi-YOUR_TOKEN_HERE"' -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Get your token from: https://pypi.org/manage/account/token/" -ForegroundColor Gray
    Write-Host ""
    exit 1
}

Write-Host "[1/3] Checking package name availability..." -ForegroundColor Cyan
Write-Host "      Visit: https://pypi.org/project/irene-auth/" -ForegroundColor Gray
Write-Host ""

Write-Host "[2/3] Building wheel with maturin..." -ForegroundColor Cyan
maturin build --release

if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "[ERROR] Build failed!" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "[3/3] Publishing to PyPI..." -ForegroundColor Cyan
Write-Host "      This may take a few minutes..." -ForegroundColor Gray
Write-Host ""

maturin publish

if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "[ERROR] Publishing failed!" -ForegroundColor Red
    Write-Host ""
    Write-Host "Common issues:" -ForegroundColor Yellow
    Write-Host "  - Package name already taken (choose different name)" -ForegroundColor Gray
    Write-Host "  - Invalid token (regenerate on PyPI)" -ForegroundColor Gray
    Write-Host "  - Version already published (bump version number)" -ForegroundColor Gray
    Write-Host ""
    exit 1
}

Write-Host ""
Write-Host "=" -NoNewline -ForegroundColor Green
Write-Host "=" * 69 -ForegroundColor Green
Write-Host "  SUCCESS! Package published to PyPI" -ForegroundColor Green
Write-Host "=" -NoNewline -ForegroundColor Green
Write-Host "=" * 69 -ForegroundColor Green
Write-Host ""
Write-Host "View your package at:" -ForegroundColor Yellow
Write-Host "  https://pypi.org/project/irene-auth/" -ForegroundColor Cyan
Write-Host ""
Write-Host "Install with:" -ForegroundColor Yellow
Write-Host "  pip install irene-auth" -ForegroundColor Cyan
Write-Host ""
