"""
Irene Auth - Production-grade authentication library

Combines Rust-powered cryptography with Python workflows for FastAPI applications.

Features:
    - User management with SQLAlchemy models
    - Argon2id password hashing
    - JWT access tokens (HS256 + RS256)
    - Refresh token management
    - Role-based access control (RBAC)
    - Password reset flow
    - Email verification flow
    - FastAPI integration

Example:
    >>> from irene_auth import AuthManager
    >>> from fastapi import FastAPI, Depends
    >>> 
    >>> app = FastAPI()
    >>> auth = AuthManager(
    ...     database_url="sqlite:///./auth.db",
    ...     secret_key="your-secret-key"
    ... )
    >>> 
    >>> @app.post("/signup")
    >>> async def signup(email: str, password: str):
    ...     return await auth.signup(email, password)
"""

from .auth import AuthManager
from .models import User, Role, RefreshToken, Base
from .dependencies import get_current_user, get_current_active_user, require_role, require_any_role
from .rbac import RBACManager
from .config import AuthConfig

# Import Rust crypto functions
from .irene_auth import (
    hash_password,
    verify_password,
    generate_token,
    hash_token,
    verify_token_hash,
    jwt_encode,
    jwt_decode,
)

__version__ = "0.1.0"

__all__ = [
    # Main classes
    "AuthManager",
    "RBACManager",
    "AuthConfig",
    
    # Models
    "User",
    "Role",
    "RefreshToken",
    "Base",
    
    # Dependencies
    "get_current_user",
    "get_current_active_user",
    "require_role",
    "require_any_role",
    
    # Crypto functions (from Rust)
    "hash_password",
    "verify_password",
    "generate_token",
    "hash_token",
    "verify_token_hash",
    "jwt_encode",
    "jwt_decode",
]
