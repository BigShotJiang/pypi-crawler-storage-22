//! Error types for authentication operations

use thiserror::Error;

/// Result type for auth operations
pub type Result<T> = std::result::Result<T, AuthError>;

/// Errors that can occur during authentication operations
#[derive(Error, Debug)]
pub enum AuthError {
    #[error("Password hashing failed: {0}")]
    PasswordHashError(String),

    #[error("Password verification failed")]
    PasswordVerificationFailed,

    #[error("Invalid password hash format")]
    InvalidPasswordHashFormat,

    #[error("Token generation failed: {0}")]
    TokenGenerationError(String),

    #[error("Token hashing failed: {0}")]
    TokenHashError(String),

    #[error("JWT encoding failed: {0}")]
    JwtEncodeError(String),

    #[error("JWT decoding failed: {0}")]
    JwtDecodeError(String),

    #[error("JWT validation failed: {0}")]
    JwtValidationError(String),

    #[error("Invalid algorithm: {0}")]
    InvalidAlgorithm(String),

    #[error("Token expired")]
    TokenExpired,

    #[error("Invalid token")]
    InvalidToken,
}
