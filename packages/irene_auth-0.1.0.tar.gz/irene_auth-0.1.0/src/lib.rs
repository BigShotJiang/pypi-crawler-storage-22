//! Irene Auth - Production-grade authentication library
//! 
//! This library provides secure authentication primitives combining Rust cryptography
//! with Python workflows for FastAPI applications.
//! 
//! # Architecture
//! 
//! - **Rust**: All cryptographic operations (passwords, tokens, JWT)
//! - **Python**: Database models, auth workflows, FastAPI integration
//! 
//! # Security Model
//! 
//! - Password hashing: Argon2id (memory-hard)
//! - Token generation: Cryptographically secure RNG
//! - Token storage: SHA-256 hashed in database
//! - JWT: HS256 and RS256 support with validation
//! - Comparisons: Constant-time to prevent timing attacks

mod error;
mod password;
mod token;
mod jwt;

#[cfg(feature = "python")]
mod python_bindings;

pub use error::{AuthError, Result};
pub use password::{hash_password, verify_password};
pub use token::{generate_token, hash_token, verify_token_hash};
pub use jwt::{encode_jwt, decode_jwt, JwtClaims};
