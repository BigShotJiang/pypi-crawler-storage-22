"""
Irene Cipher - Production-grade cryptographic library for Python, written in Rust.

See README.md for full documentation.

Quick Start:
    >>> import irene_cipher
    >>> 
    >>> # Encrypt text
    >>> ciphertext = irene_cipher.encrypt_text("Hello!", "password")
    >>> plaintext = irene_cipher.decrypt_text(ciphertext, "password")
    >>> 
    >>> # Encrypt files
    >>> irene_cipher.encrypt_file("data.pdf", "data.pdf.enc", "password")
    >>> irene_cipher.decrypt_file("data.pdf.enc", "data.pdf", "password")
"""

from .irene_cipher import (
    generate_key,
    encrypt_text,
    decrypt_text,
    encrypt_bytes,
    decrypt_bytes,
    encrypt_file,
    decrypt_file,
)

__all__ = [
    "generate_key",
    "encrypt_text",
    "decrypt_text",
    "encrypt_bytes",
    "decrypt_bytes",
    "encrypt_file",
    "decrypt_file",
]

__version__ = "0.1.0"
