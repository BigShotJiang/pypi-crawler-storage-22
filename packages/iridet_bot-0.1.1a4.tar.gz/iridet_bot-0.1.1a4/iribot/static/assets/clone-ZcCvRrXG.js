import{ar as o}from"./index-Drrpbg7e.js";var a=4;function n(r){return o(r,a)}export{n as c};
