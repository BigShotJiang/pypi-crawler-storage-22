from .iron_oxide import *

__doc__ = iron_oxide.__doc__
if hasattr(iron_oxide, "__all__"):
    __all__ = iron_oxide.__all__