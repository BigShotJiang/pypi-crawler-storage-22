# Note that version is also in pyproject.toml
__version__ = "4.5.0"
ENV_MAIN_PROCESS_PID = "IRRD_MAIN_PROCESS_PID"
ENV_MAIN_STARTUP_TIME = "IRRD_MAIN_STARTUP_TIME"
META_KEY_HTTP_CLIENT_IP = "HTTP-Client-IP"
