UPDATE_NOTIFICATION_FILENAME = "update-notification-file.jose"
