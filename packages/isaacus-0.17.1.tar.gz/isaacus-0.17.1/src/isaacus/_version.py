# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "isaacus"
__version__ = "0.17.1"  # x-release-please-version
