# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from .span import Span
from ...._models import BaseModel

__all__ = ["Quote"]


class Quote(BaseModel):
    """A quotation within a document."""

    source_segment: Optional[str] = None
    """A unique identifier for a segment in the format `seg:{identifier}`."""

    source_document: Optional[str] = None
    """A unique identifier for an external document in the format `exd:{identifier}`."""

    source_person: Optional[str] = None
    """A unique identifier for a legal person in the format `per:{identifier}`."""

    amending: bool
    """
    Whether the quote is being used to amend or modify content, typically in other
    documents.
    """

    span: Span
    """A zero-based, half-open span into the Unicode code point space of input text.

    All spans are globally laminar and well-nested similar to XML—it is impossible
    for any two spans to partially overlap; they can only be disjoint, adjacent, or
    wholly nested. Spans of the exact same type (e.g., segments) will never be
    duplicated.

    A span cannot be empty and will never start or end at whitespace (though a
    span's `end` index, being an exclusive index, may obviosuly land on a whitespace
    character).

    Note that, when using programming languages other than Python (which uses
    zero-based, half-open, Unicode code point-spaced string indexing), indices may
    need to be translated accordingly (for example, JavaScript slices into UTF-16
    code units instead of Unicode code points).
    """
