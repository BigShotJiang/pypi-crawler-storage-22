"""Version information for pypi-publisher."""

__version__ = "0.1.8.8"
__author__ = "IntelliStream Team"
__email__ = "shuhao_zhang@hust.edu.cn"
