"""测试 entry points 注册和发现。"""

from __future__ import annotations


def test_backend_entry_points_registered():
    """测试 backend entry points 是否正确注册。"""
    from sagellm_backend.providers.mock import create_mock_backend

    from sagellm_backend.providers.cpu import create_cpu_backend

    # 验证工厂函数可以直接调用
    mock_backend = create_mock_backend()
    assert mock_backend is not None

    cpu_backend = create_cpu_backend()
    assert cpu_backend is not None
