"""Verification tests removed: mock providers are forbidden."""
