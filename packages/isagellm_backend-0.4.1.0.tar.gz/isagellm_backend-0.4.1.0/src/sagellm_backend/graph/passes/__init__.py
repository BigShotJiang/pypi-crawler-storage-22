"""CPU-specific optimization passes."""

from sagellm_backend.graph.passes.constant_folding import ConstantFoldingPass
from sagellm_backend.graph.passes.dead_node_elimination import DeadNodeEliminationPass
from sagellm_backend.graph.passes.identity_elimination import IdentityEliminationPass

__all__ = [
    "ConstantFoldingPass",
    "DeadNodeEliminationPass",
    "IdentityEliminationPass",
]
