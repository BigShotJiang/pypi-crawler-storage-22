"""sagellm-comm: Communication Layer for sageLLM distributed inference."""

from __future__ import annotations

__version__ = "0.3.0.5"

# MVP: 公共 API 导出
from sagellm_comm.backend import (
    CommBackend,
    CommBackendType,
    CommGroup,
    CommOp,
    TopologyNode,
)
from sagellm_comm.gloo_backend import GlooBackend
from sagellm_comm.topology import Topology, TopologyDetector

__all__ = [
    "__version__",
    # Backend
    "CommBackend",
    "CommBackendType",
    "CommGroup",
    "CommOp",
    "TopologyNode",
    # Implementations
    "GlooBackend",
    # Topology
    "Topology",
    "TopologyDetector",
]
