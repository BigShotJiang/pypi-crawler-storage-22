"""sagellm-compression: Model Compression & Acceleration Module for sageLLM."""

from __future__ import annotations

from sagellm_compression.quantization import (
    Calibrator,
    Exporter,
    FP8Config,
    QuantizationConfig,
    Quantizer,
    W4A16Config,
    W8A8Config,
)

__version__ = "0.4.0.11"

# Public API
__all__ = [
    "__version__",
    # Quantization (Task 3.1)
    "Calibrator",
    "Quantizer",
    "Exporter",
    "QuantizationConfig",
    "W8A8Config",
    "W4A16Config",
    "FP8Config",
    # Future: Sparsity, SpeculativeDecoder, KernelFusion
]
