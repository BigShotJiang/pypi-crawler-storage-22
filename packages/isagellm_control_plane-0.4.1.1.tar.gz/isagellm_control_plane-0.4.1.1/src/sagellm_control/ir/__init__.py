"""Scheduler IR (Intermediate Representation) for sageLLM Control Plane.

The Scheduler IR provides a structured representation of scheduling decisions
and execution plans for inference tasks.

Key Components:
- SchedulerIR: Core IR structure representing a scheduling plan
- IRBuilder: Constructs IR from requests
- IROptimizer: Optimizes IR for better resource utilization
- IRExecutor: Interface for executing IR plans

Example:
    from sagellm_control.ir import IRBuilder, IROptimizer
    from sagellm_protocol import Request

    # Build IR from request
    builder = IRBuilder()
    ir = builder.build_from_request(request)

    # Optimize IR
    optimizer = IROptimizer()
    optimized_ir = optimizer.optimize(ir)

    # Execute IR
    executor = IRExecutor(engine)
    await executor.execute(optimized_ir)
"""

from __future__ import annotations

from sagellm_control.ir.builder import IRBuilder
from sagellm_control.ir.executor import IRExecutor
from sagellm_control.ir.optimizer import IROptimizer
from sagellm_control.ir.types import (
    ComputationNode,
    DependencyEdge,
    IRNode,
    ParallelismConfig,
    ResourceAllocation,
    SchedulerIR,
    TaskNode,
)

__all__ = [
    # Core IR types
    "SchedulerIR",
    "IRNode",
    "TaskNode",
    "ComputationNode",
    "DependencyEdge",
    "ResourceAllocation",
    "ParallelismConfig",
    # Builder
    "IRBuilder",
    # Optimizer
    "IROptimizer",
    # Executor
    "IRExecutor",
]
