"""Tests for PyTorch Engine - lightweight interface tests only.

These tests verify the engine interface without loading real models.
For real model tests, see test_pytorch_engine_integration.py (requires GPU).
"""

from __future__ import annotations

import pytest

from sagellm_core.engines.pytorch_engine import PyTorchEngine


class TestPyTorchEngineInterface:
    """Test PyTorchEngine class methods (no model loading)."""

    def test_is_available(self):
        """Test is_available() class method."""
        # Should return True if torch is installed (no GPU required)
        available = PyTorchEngine.is_available()
        assert isinstance(available, bool)
        # If torch is installed, should be True
        try:
            import importlib.util

            torch_spec = importlib.util.find_spec("torch")

            assert available is True if torch_spec else False
        except ImportError:
            assert available is False

    def test_priority(self):
        """Test priority() class method."""
        priority = PyTorchEngine.priority()
        assert isinstance(priority, int)
        assert priority == 20  # Expected priority

    def test_backend_type(self):
        """Test backend_type() class method."""
        backend_type = PyTorchEngine.backend_type()
        assert isinstance(backend_type, str)
        assert backend_type in ["pytorch-cuda", "pytorch-ascend", "pytorch-cpu"]

    def test_backend_type_logic(self):
        """Test backend_type() returns correct type based on hardware."""
        try:
            import torch

            backend = PyTorchEngine.backend_type()

            # Verify logic
            if torch.cuda.is_available():
                assert backend == "pytorch-cuda"
            elif hasattr(torch, "npu") and torch.npu.is_available():
                assert backend == "pytorch-ascend"
            else:
                assert backend == "pytorch-cpu"
        except ImportError:
            pytest.skip("torch not available")


# Skip GPU tests by default (add --run-gpu to enable)
@pytest.mark.skipif(
    True,  # Always skip by default
    reason="GPU tests require real hardware and models (slow)",
)
class TestPyTorchEngineIntegration:
    """Integration tests requiring real GPU and models.

    Run with: pytest -v -m gpu --run-gpu
    """

    @pytest.mark.gpu
    async def test_execute_with_real_model(self):
        """Test execute() with real model (requires GPU)."""
        pytest.skip("Implement when GPU is available")

    @pytest.mark.gpu
    async def test_stream_with_real_model(self):
        """Test stream() with real model (requires GPU)."""
        pytest.skip("Implement when GPU is available")
