"""Model layers that use backend kernels.

This module provides PyTorch-style nn.Module layers that delegate
compute operations to BackendProvider kernels.

Key design:
- Layers are standard torch.nn.Module subclasses
- Forward passes use backend.get_kernel() instead of native ops
- Supports tensor parallelism via CommBackend
- Hardware-agnostic (CPU/CUDA/NPU/etc.)
"""

from sagellm_core.layers.base import BaseLayer
from sagellm_core.layers.embedding import Embedding, LMHead
from sagellm_core.layers.linear import ColumnParallelLinear, LinearLayer, RowParallelLinear
from sagellm_core.layers.normalization import LayerNorm, RMSNorm
from sagellm_core.layers.activation import SiLU, SiLUAndMul

__all__ = [
    "BaseLayer",
    "LinearLayer",
    "ColumnParallelLinear",
    "RowParallelLinear",
    "Embedding",
    "LMHead",
    "RMSNorm",
    "LayerNorm",
    "SiLU",
    "SiLUAndMul",
]
