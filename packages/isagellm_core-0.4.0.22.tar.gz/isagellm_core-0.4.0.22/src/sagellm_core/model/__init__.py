"""Model definitions using backend kernels.

This module provides model architectures that use sagellm-core layers
instead of direct HuggingFace implementations.

Key models:
- BaseLLMModel: Abstract base for all LLM models
- GPT2Model: GPT-2 architecture (for testing)
- LlamaModel: LLaMA/LLaMA-2/LLaMA-3 architecture
- Qwen2Model: Qwen2/Qwen2.5 architecture
- MixtralModel: Mixtral Mixture of Experts architecture
- create_model_from_config: Factory function to create models

Model loading (Task 3):
- ModelLoadConfig: Configuration for model loading
- get_model_loader: Factory to get appropriate loader
- HFModelLoader: HuggingFace compatible loader
- SageModelLoader: Optimized sageLLM loader

Registry system:
- MODEL_REGISTRY: Central registry of model types
- HF_ARCHITECTURE_REGISTRY: HF architecture name mappings
- register_model: Decorator to register new models
- register_hf_architecture: Decorator to register HF architectures
- get_model_class: Look up model class by type
- get_model_architecture: Get HF architecture from model path

Weight loading:
- WeightLoaderProtocol: Protocol for weight loaders
- WEIGHT_LOADERS: Registry of weight formats
- SafetensorsLoader, PytorchLoader: Built-in loaders
- QuantizedWeightLoader: Quantized weight loading (INT8/AWQ/GPTQ)

Quantization:
- QuantConfig: Quantization configuration
- detect_quantization: Auto-detect quantization format
"""

# Registry (import first to ensure registration works)
from sagellm_core.model.registry import (
    MODEL_REGISTRY,
    HF_ARCHITECTURE_REGISTRY,
    get_model_class,
    get_model_class_by_architecture,
    get_model_architecture,
    is_model_registered,
    is_hf_architecture_supported,
    list_registered_models,
    list_supported_architectures,
    register_model,
    register_hf_architecture,
)

# Model loading configuration and loaders (Task 3)
from sagellm_core.model.load_config import ModelLoadConfig
from sagellm_core.model.loader import ModelLoader as BaseModelLoader, get_model_loader
from sagellm_core.model.hf_loader import HFModelLoader
from sagellm_core.model.sage_loader import SageModelLoader

# Base class
from sagellm_core.model.base import BaseLLMModel

# Factory
from sagellm_core.model.factory import create_model_from_config, load_model_weights

# Models (import triggers registration)
from sagellm_core.model.gpt2 import GPT2Model
from sagellm_core.model.llama import (
    LlamaModel,
    LlamaAttention,
    LlamaMLP,
    LlamaDecoderLayer,
    LlamaRotaryEmbedding,
)
from sagellm_core.model.qwen2 import (
    Qwen2Model,
    Qwen2Attention,
    Qwen2MLP,
    Qwen2DecoderLayer,
)
from sagellm_core.model.mixtral import (
    MixtralModel,
    MixtralSparseMoE,
    MixtralMLP,
    MixtralDecoderLayer,
)

# Quantization
from sagellm_core.model.quantization import (
    QuantConfig,
    QuantizationType,
    detect_quantization,
)

# Weight loaders
from sagellm_core.model.weight_loader import (
    WEIGHT_LOADERS,
    WeightLoaderProtocol,
    WeightNameMapper,
    SafetensorsLoader,
    PytorchLoader,
    detect_weight_format,
    get_weight_loader,
    list_weight_loaders,
    load_weights_into_model,
    register_weight_loader,
)
from sagellm_core.model.weight_loader.quantized import QuantizedWeightLoader

# Legacy compatibility
from sagellm_core.model.model_loader import ModelLoader, load_model

__all__ = [
    # Base
    "BaseLLMModel",
    # Models
    "GPT2Model",
    "LlamaModel",
    "LlamaAttention",
    "LlamaMLP",
    "LlamaDecoderLayer",
    "LlamaRotaryEmbedding",
    "Qwen2Model",
    "Qwen2Attention",
    "Qwen2MLP",
    "Qwen2DecoderLayer",
    "MixtralModel",
    "MixtralSparseMoE",
    "MixtralMLP",
    "MixtralDecoderLayer",
    # Factory
    "create_model_from_config",
    "load_model_weights",
    # Registry
    "MODEL_REGISTRY",
    "HF_ARCHITECTURE_REGISTRY",
    "register_model",
    "register_hf_architecture",
    "get_model_class",
    "get_model_class_by_architecture",
    "get_model_architecture",
    "list_registered_models",
    "list_supported_architectures",
    "is_model_registered",
    "is_hf_architecture_supported",
    # Model loading (Task 3)
    "ModelLoadConfig",
    "BaseModelLoader",
    "get_model_loader",
    "HFModelLoader",
    "SageModelLoader",
    # Quantization
    "QuantConfig",
    "QuantizationType",
    "detect_quantization",
    # Weight loaders
    "WEIGHT_LOADERS",
    "WeightLoaderProtocol",
    "WeightNameMapper",
    "SafetensorsLoader",
    "PytorchLoader",
    "QuantizedWeightLoader",
    "detect_weight_format",
    "get_weight_loader",
    "list_weight_loaders",
    "load_weights_into_model",
    "register_weight_loader",
    # Legacy
    "ModelLoader",
    "load_model",
]

