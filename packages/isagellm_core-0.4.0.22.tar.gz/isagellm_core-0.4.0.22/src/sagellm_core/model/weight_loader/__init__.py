"""Weight loader module.

This module provides utilities for loading model weights from various formats:
- safetensors: Fast, secure tensor format (recommended)
- pytorch: Standard PyTorch .bin/.pt checkpoints

Usage:
    from sagellm_core.model.weight_loader import (
        get_weight_loader,
        detect_weight_format,
        load_weights_into_model,
    )

    # Auto-detect format and load
    load_weights_into_model(model, "path/to/model")

    # Or manually:
    loader = get_weight_loader("safetensors")
    for name, tensor in loader.load_weights("path/to/model"):
        print(f"{name}: {tensor.shape}")
"""

from sagellm_core.model.weight_loader.base import (
    WEIGHT_LOADERS,
    WeightLoaderProtocol,
    WeightNameMapper,
    detect_weight_format,
    get_weight_loader,
    is_weight_loader_registered,
    list_weight_loaders,
    load_weights_into_model,
    register_weight_loader,
)

# Import loaders to trigger registration
from sagellm_core.model.weight_loader.safetensors import SafetensorsLoader
from sagellm_core.model.weight_loader.pytorch import PytorchLoader

__all__ = [
    # Protocol and registry
    "WeightLoaderProtocol",
    "WEIGHT_LOADERS",
    "register_weight_loader",
    "get_weight_loader",
    "list_weight_loaders",
    "is_weight_loader_registered",
    # Utilities
    "detect_weight_format",
    "WeightNameMapper",
    "load_weights_into_model",
    # Concrete loaders
    "SafetensorsLoader",
    "PytorchLoader",
]
