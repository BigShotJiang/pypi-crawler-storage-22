"""Weight loading pipeline for sageLLM.

This module provides a complete pipeline for loading model weights with support for:
- Multiple formats (safetensors, pytorch)
- Weight name mapping (HuggingFace → sageLLM)
- Tensor parallel sharding
- Weight fusion (QKV, GateUp)

Example usage:
    from sagellm_core.model.weights import WeightPipeline, get_weight_iterator

    # Basic usage
    pipeline = (
        WeightPipeline(get_weight_iterator(model_path))
        .with_mapping({"qkv_proj": ["q_proj", "k_proj", "v_proj"]})
        .with_sharding(tp_size=2, tp_rank=0)
        .with_fusion({"qkv_proj": ["q_proj", "k_proj", "v_proj"]})
    )

    for name, tensor in pipeline:
        model.load_weight(name, tensor)
"""

from sagellm_core.model.weights.iterator import (
    WeightIterator,
    SafetensorsIterator,
    PytorchIterator,
    get_weight_iterator,
)
from sagellm_core.model.weights.mapper import WeightNameMapper
from sagellm_core.model.weights.sharding import WeightSharder
from sagellm_core.model.weights.fusion import WeightFuser
from sagellm_core.model.weights.pipeline import WeightPipeline
from sagellm_core.model.weights.utils import (
    download_model,
    get_weight_files,
    estimate_model_size,
)

__all__ = [
    # Iterators
    "WeightIterator",
    "SafetensorsIterator",
    "PytorchIterator",
    "get_weight_iterator",
    # Mapper
    "WeightNameMapper",
    # Sharding
    "WeightSharder",
    # Fusion
    "WeightFuser",
    # Pipeline
    "WeightPipeline",
    # Utils
    "download_model",
    "get_weight_files",
    "estimate_model_size",
]
