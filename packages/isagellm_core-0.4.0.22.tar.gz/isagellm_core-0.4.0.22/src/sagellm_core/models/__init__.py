"""sageLLM custom model implementations.

This module provides custom model implementations that support:
- PagedAttention (via AttentionMetadata)
- Tensor Parallel (TP) with automatic weight sharding
- Weight fusion (QKV/GateUp)
- Streaming weight loading via weight_loader callbacks

Models:
- GPT2LMHeadModel: GPT-2
- LlamaForCausalLM: LLaMA/LLaMA-2/LLaMA-3
- Qwen2ForCausalLM: Qwen2/Qwen2.5

Usage:
    from sagellm_core.models import LlamaForCausalLM
    
    model = LlamaForCausalLM(config, tp_size=2, tp_rank=0)
    model.load_weights(weight_iterator)
    output = model.forward(input_ids, positions, kv_caches, attn_metadata)
"""

from sagellm_core.models.base import SagePretrainedModel
from sagellm_core.models.gpt2 import GPT2LMHeadModel
from sagellm_core.models.llama import LlamaForCausalLM
from sagellm_core.models.qwen2 import Qwen2ForCausalLM

__all__ = [
    "SagePretrainedModel",
    "GPT2LMHeadModel",
    "LlamaForCausalLM",
    "Qwen2ForCausalLM",
]
