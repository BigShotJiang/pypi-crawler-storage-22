"""Integration tests for KV cache functionality.

Tests:
1. AttentionMetadata with KV cache support
2. SageAttention with KV cache read/write
3. SagePretrainedModel.generate() with KV cache enabled/disabled
4. Output consistency between KV cache enabled and disabled
"""

import pytest
import torch

from sagellm_core.models.attention import SageAttention
from sagellm_core.models.attention_metadata import AttentionMetadata


class TestAttentionMetadata:
    """Test AttentionMetadata with KV cache support."""

    def test_basic_metadata(self):
        """Test basic metadata creation."""
        metadata = AttentionMetadata(
            is_prompt=True,
            seq_lens=torch.tensor([10, 20]),
            max_seq_len=20,
            num_prefill_tokens=30,
            num_decode_tokens=0,
        )
        
        assert metadata.is_prompt
        assert metadata.max_seq_len == 20
        assert metadata.num_prefill_tokens == 30

    def test_from_simple_batch(self):
        """Test creating metadata from simple batch."""
        metadata = AttentionMetadata.from_simple_batch(
            batch_size=2,
            seq_len=10,
            is_prompt=True,
        )
        
        assert metadata.is_prompt
        assert metadata.max_seq_len == 10
        assert len(metadata.seq_lens) == 2

    def test_slot_mapping_computation(self):
        """Test slot mapping computation from block tables."""
        block_size = 16
        batch_size = 2
        seq_len = 24  # Needs 2 blocks per sequence
        
        # Create block tables
        block_tables = torch.tensor([
            [0, 1],  # Seq 0: blocks 0, 1
            [2, 3],  # Seq 1: blocks 2, 3
        ])
        
        seq_lens = torch.tensor([seq_len, seq_len])
        
        metadata = AttentionMetadata(
            is_prompt=True,
            seq_lens=seq_lens,
            block_tables=block_tables,
        )
        
        slot_mapping = metadata.compute_slot_mapping(block_size)
        
        # Verify slot mapping
        assert slot_mapping is not None
        assert len(slot_mapping) == seq_len * batch_size
        
        # First token of seq 0 should map to block 0, offset 0
        assert slot_mapping[0] == 0
        # 17th token of seq 0 should map to block 1, offset 0
        assert slot_mapping[16] == 16  # block 1 * 16 + 0
        
        # First token of seq 1 should map to block 2, offset 0
        assert slot_mapping[24] == 32  # block 2 * 16 + 0

    def test_from_kv_cache_batch(self):
        """Test creating metadata with KV cache support."""
        block_size = 16
        seq_lens = torch.tensor([10, 20])
        block_tables = torch.tensor([
            [0, 1],
            [2, 3],
        ])
        
        cache_config = {
            "block_size": block_size,
            "dtype": "torch.float16",
        }
        
        metadata = AttentionMetadata.from_kv_cache_batch(
            seq_lens=seq_lens,
            block_tables=block_tables,
            is_prompt=False,
            cache_config=cache_config,
        )
        
        assert not metadata.is_prompt
        assert metadata.slot_mapping is not None
        assert metadata.cache_config == cache_config


class TestSageAttention:
    """Test SageAttention with KV cache."""

    def test_attention_without_kv_cache(self):
        """Test standard attention without KV cache."""
        batch_size = 2
        seq_len = 10
        num_heads = 8
        num_kv_heads = 8
        head_dim = 64
        
        attention = SageAttention(
            num_heads=num_heads,
            head_dim=head_dim,
            num_kv_heads=num_kv_heads,
        )
        
        # Create inputs
        query = torch.randn(batch_size, seq_len, num_heads, head_dim)
        key = torch.randn(batch_size, seq_len, num_kv_heads, head_dim)
        value = torch.randn(batch_size, seq_len, num_kv_heads, head_dim)
        positions = torch.arange(seq_len).unsqueeze(0).expand(batch_size, -1)
        
        # Forward without KV cache
        output = attention.forward(query, key, value, positions)
        
        assert output.shape == (batch_size, seq_len, num_heads * head_dim)

    def test_attention_with_kv_cache(self):
        """Test attention with KV cache."""
        batch_size = 2
        seq_len = 24
        num_heads = 8
        num_kv_heads = 8
        head_dim = 64
        block_size = 16
        num_blocks = 4
        
        attention = SageAttention(
            num_heads=num_heads,
            head_dim=head_dim,
            num_kv_heads=num_kv_heads,
        )
        
        # Create KV cache
        kv_cache = torch.zeros(num_blocks, 2, block_size, num_kv_heads, head_dim)
        
        # Create inputs
        query = torch.randn(batch_size, seq_len, num_heads, head_dim)
        key = torch.randn(batch_size, seq_len, num_kv_heads, head_dim)
        value = torch.randn(batch_size, seq_len, num_kv_heads, head_dim)
        positions = torch.arange(seq_len).unsqueeze(0).expand(batch_size, -1)
        
        # Create metadata
        block_tables = torch.tensor([
            [0, 1],
            [2, 3],
        ])
        seq_lens = torch.tensor([seq_len, seq_len])
        
        cache_config = {"block_size": block_size}
        metadata = AttentionMetadata.from_kv_cache_batch(
            seq_lens=seq_lens,
            block_tables=block_tables,
            is_prompt=True,
            cache_config=cache_config,
        )
        
        # Forward with KV cache
        output = attention.forward(query, key, value, positions, kv_cache, metadata)
        
        assert output.shape == (batch_size, seq_len, num_heads * head_dim)
        
        # Verify KV cache is not all zeros (should have written to it)
        assert not torch.allclose(kv_cache, torch.zeros_like(kv_cache))

    def test_kv_write_and_read(self):
        """Test that KV cache write and read work correctly."""
        batch_size = 1
        seq_len = 16
        num_heads = 4
        num_kv_heads = 4
        head_dim = 32
        block_size = 16
        num_blocks = 1
        
        attention = SageAttention(
            num_heads=num_heads,
            head_dim=head_dim,
            num_kv_heads=num_kv_heads,
        )
        
        # Create KV cache
        kv_cache = torch.zeros(num_blocks, 2, block_size, num_kv_heads, head_dim)
        
        # Create inputs
        query = torch.randn(batch_size, seq_len, num_heads, head_dim)
        key = torch.randn(batch_size, seq_len, num_kv_heads, head_dim)
        value = torch.randn(batch_size, seq_len, num_kv_heads, head_dim)
        positions = torch.arange(seq_len).unsqueeze(0)
        
        # Create metadata
        block_tables = torch.tensor([[0]])
        seq_lens = torch.tensor([seq_len])
        cache_config = {"block_size": block_size}
        
        metadata = AttentionMetadata.from_kv_cache_batch(
            seq_lens=seq_lens,
            block_tables=block_tables,
            is_prompt=True,
            cache_config=cache_config,
        )
        
        # Write to KV cache
        slot_mapping = torch.arange(seq_len)
        attention._write_to_kv_cache(key, value, kv_cache, slot_mapping)
        
        # Read from KV cache
        key_cache, value_cache = attention._read_from_kv_cache(
            kv_cache, block_tables, seq_lens, cache_config
        )
        
        # Verify read matches written
        assert torch.allclose(key_cache[0], key[0], atol=1e-6)
        assert torch.allclose(value_cache[0], value[0], atol=1e-6)


class TestKVCacheConsistency:
    """Test output consistency with and without KV cache."""

    @pytest.mark.parametrize("batch_size,seq_len", [(1, 10), (2, 20)])
    def test_attention_output_consistency(self, batch_size, seq_len):
        """Test that attention output is consistent with/without KV cache."""
        num_heads = 8
        num_kv_heads = 8
        head_dim = 64
        block_size = 16
        
        # Create attention layer
        attention = SageAttention(
            num_heads=num_heads,
            head_dim=head_dim,
            num_kv_heads=num_kv_heads,
        )
        
        # Create inputs (same for both paths)
        torch.manual_seed(42)
        query = torch.randn(batch_size, seq_len, num_heads, head_dim)
        key = torch.randn(batch_size, seq_len, num_kv_heads, head_dim)
        value = torch.randn(batch_size, seq_len, num_kv_heads, head_dim)
        positions = torch.arange(seq_len).unsqueeze(0).expand(batch_size, -1)
        
        # Output without KV cache
        output_no_cache = attention.forward(query, key, value, positions)
        
        # Output with KV cache
        num_blocks_per_seq = (seq_len + block_size - 1) // block_size
        num_blocks = num_blocks_per_seq * batch_size
        kv_cache = torch.zeros(num_blocks, 2, block_size, num_kv_heads, head_dim)
        
        # Create block tables
        block_tables = torch.zeros(batch_size, num_blocks_per_seq, dtype=torch.long)
        for i in range(batch_size):
            start_block = i * num_blocks_per_seq
            block_tables[i] = torch.arange(start_block, start_block + num_blocks_per_seq)
        
        seq_lens = torch.tensor([seq_len] * batch_size)
        cache_config = {"block_size": block_size}
        
        metadata = AttentionMetadata.from_kv_cache_batch(
            seq_lens=seq_lens,
            block_tables=block_tables,
            is_prompt=True,
            cache_config=cache_config,
        )
        
        output_with_cache = attention.forward(
            query, key, value, positions, kv_cache, metadata
        )
        
        # Outputs should be identical (or very close)
        assert torch.allclose(output_no_cache, output_with_cache, atol=1e-5)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
