"""Tests for LlamaModel implementation."""

import pytest
import torch
from transformers import LlamaConfig

from sagellm_backend import get_provider
from sagellm_core.model import LlamaModel, LlamaAttention, LlamaMLP, LlamaRotaryEmbedding


@pytest.fixture
def cpu_backend():
    """Get CPU backend for testing."""
    return get_provider("cpu")


@pytest.fixture
def tiny_llama_config():
    """Create a tiny LlamaConfig for fast testing."""
    return LlamaConfig(
        vocab_size=1000,
        hidden_size=128,
        intermediate_size=256,
        num_hidden_layers=2,
        num_attention_heads=4,
        num_key_value_heads=2,  # GQA: 2 Q heads per KV head
        max_position_embeddings=512,
        rms_norm_eps=1e-6,
    )


@pytest.fixture
def standard_llama_config():
    """Create a standard LlamaConfig (no GQA)."""
    return LlamaConfig(
        vocab_size=1000,
        hidden_size=128,
        intermediate_size=256,
        num_hidden_layers=2,
        num_attention_heads=4,
        num_key_value_heads=4,  # MHA: same as num_heads
        max_position_embeddings=512,
    )


class TestLlamaModel:
    """Test LlamaModel instantiation and forward pass."""

    def test_model_creation(self, cpu_backend, tiny_llama_config):
        """Test that LlamaModel can be instantiated."""
        model = LlamaModel(tiny_llama_config, cpu_backend)
        
        assert model is not None
        assert isinstance(model, LlamaModel)
        assert model.config is tiny_llama_config
        assert model.backend is cpu_backend

    def test_model_layers(self, cpu_backend, tiny_llama_config):
        """Test that model has correct number of layers."""
        model = LlamaModel(tiny_llama_config, cpu_backend)
        
        assert len(model.layers) == tiny_llama_config.num_hidden_layers
        assert model.vocab_size == tiny_llama_config.vocab_size

    def test_parameter_count(self, cpu_backend, tiny_llama_config):
        """Test that model has parameters."""
        model = LlamaModel(tiny_llama_config, cpu_backend)
        
        num_params = model.get_num_params()
        assert num_params > 0
        
        # Should have embedding, layers, norm, lm_head
        assert hasattr(model, "embed_tokens")
        assert hasattr(model, "layers")
        assert hasattr(model, "norm")
        assert hasattr(model, "lm_head")

    def test_forward_pass_shape(self, cpu_backend, tiny_llama_config):
        """Test forward pass output shape."""
        model = LlamaModel(tiny_llama_config, cpu_backend)
        
        batch_size = 2
        seq_len = 10
        input_ids = torch.randint(0, tiny_llama_config.vocab_size, (batch_size, seq_len))
        
        with torch.no_grad():
            logits = model(input_ids)
        
        # Check output shape
        assert logits.shape == (batch_size, seq_len, tiny_llama_config.vocab_size)
        assert logits.dtype == torch.float32

    def test_forward_pass_no_error(self, cpu_backend, tiny_llama_config):
        """Test that forward pass runs without errors."""
        model = LlamaModel(tiny_llama_config, cpu_backend)
        
        input_ids = torch.randint(0, tiny_llama_config.vocab_size, (1, 5))
        
        # Should not raise any exception
        with torch.no_grad():
            logits = model(input_ids)
        
        assert logits is not None

    def test_forward_with_position_ids(self, cpu_backend, tiny_llama_config):
        """Test forward pass with explicit position_ids."""
        model = LlamaModel(tiny_llama_config, cpu_backend)
        
        batch_size = 2
        seq_len = 8
        input_ids = torch.randint(0, tiny_llama_config.vocab_size, (batch_size, seq_len))
        position_ids = torch.arange(seq_len).unsqueeze(0).expand(batch_size, -1)
        
        with torch.no_grad():
            logits = model(input_ids, position_ids=position_ids)
        
        assert logits.shape == (batch_size, seq_len, tiny_llama_config.vocab_size)

    def test_forward_different_batch_sizes(self, cpu_backend, tiny_llama_config):
        """Test forward pass with different batch sizes."""
        model = LlamaModel(tiny_llama_config, cpu_backend)
        
        for batch_size in [1, 2, 4]:
            input_ids = torch.randint(0, tiny_llama_config.vocab_size, (batch_size, 6))
            
            with torch.no_grad():
                logits = model(input_ids)
            
            assert logits.shape[0] == batch_size


class TestLlamaAttention:
    """Test LlamaAttention with GQA."""

    def test_gqa_attention_creation(self, cpu_backend, tiny_llama_config):
        """Test creating attention with GQA (num_kv_heads < num_heads)."""
        attn = LlamaAttention(tiny_llama_config, cpu_backend, layer_idx=0)
        
        assert attn.num_heads == 4
        assert attn.num_kv_heads == 2
        assert attn.num_kv_groups == 2  # 4 / 2
        assert attn.head_dim == 32  # 128 / 4

    def test_mha_attention_creation(self, cpu_backend, standard_llama_config):
        """Test creating attention without GQA (num_kv_heads == num_heads)."""
        attn = LlamaAttention(standard_llama_config, cpu_backend, layer_idx=0)
        
        assert attn.num_heads == 4
        assert attn.num_kv_heads == 4
        assert attn.num_kv_groups == 1  # No grouping

    def test_attention_forward(self, cpu_backend, tiny_llama_config):
        """Test attention forward pass."""
        attn = LlamaAttention(tiny_llama_config, cpu_backend, layer_idx=0)
        
        batch_size = 2
        seq_len = 6
        hidden_states = torch.randn(batch_size, seq_len, tiny_llama_config.hidden_size)
        
        with torch.no_grad():
            output, cache = attn(hidden_states, use_cache=False)
        
        assert output.shape == hidden_states.shape
        assert cache is None  # use_cache=False

    def test_attention_with_cache(self, cpu_backend, tiny_llama_config):
        """Test attention with KV cache."""
        attn = LlamaAttention(tiny_llama_config, cpu_backend, layer_idx=0)
        
        batch_size = 1
        seq_len = 4
        hidden_states = torch.randn(batch_size, seq_len, tiny_llama_config.hidden_size)
        
        with torch.no_grad():
            output, cache = attn(hidden_states, use_cache=True)
        
        assert output.shape == hidden_states.shape
        assert cache is not None
        assert len(cache) == 2  # (key, value)


class TestLlamaRotaryEmbedding:
    """Test LlamaRotaryEmbedding."""

    def test_rope_creation(self):
        """Test creating rotary embedding."""
        rope = LlamaRotaryEmbedding(
            dim=64,
            max_position_embeddings=2048,
            base=10000.0,
        )
        
        assert rope.dim == 64
        assert rope.max_position_embeddings == 2048

    def test_rope_output_shape(self):
        """Test rotary embedding output shape."""
        rope = LlamaRotaryEmbedding(dim=64, max_position_embeddings=512)
        
        batch_size = 2
        seq_len = 10
        x = torch.randn(batch_size, 4, seq_len, 64)  # [batch, heads, seq, dim]
        position_ids = torch.arange(seq_len).unsqueeze(0).expand(batch_size, -1)
        
        cos, sin = rope(x, position_ids)
        
        # Should return cos/sin for positions
        assert cos.shape == (batch_size, seq_len, 64)
        assert sin.shape == (batch_size, seq_len, 64)

    def test_rope_cache_extension(self):
        """Test that RoPE cache extends when needed."""
        rope = LlamaRotaryEmbedding(dim=64, max_position_embeddings=100)
        
        # Initial cache
        initial_max = rope.max_seq_len_cached
        
        # Request longer sequence
        x = torch.randn(1, 4, 150, 64)
        position_ids = torch.arange(150).unsqueeze(0)
        
        cos, sin = rope(x, position_ids)
        
        # Cache should be extended
        assert rope.max_seq_len_cached >= 150
        assert rope.max_seq_len_cached > initial_max

    def test_rope_with_scaling(self):
        """Test RoPE with position interpolation scaling."""
        rope = LlamaRotaryEmbedding(
            dim=64,
            max_position_embeddings=512,
            scaling_factor=2.0,  # Position interpolation
        )
        
        assert rope.scaling_factor == 2.0
        
        x = torch.randn(1, 4, 10, 64)
        position_ids = torch.arange(10).unsqueeze(0)
        
        cos, sin = rope(x, position_ids)
        assert cos.shape == (1, 10, 64)


class TestLlamaMLP:
    """Test LlamaMLP with SwiGLU."""

    def test_mlp_creation(self, cpu_backend, tiny_llama_config):
        """Test creating MLP."""
        mlp = LlamaMLP(tiny_llama_config, cpu_backend)
        
        assert mlp.hidden_size == tiny_llama_config.hidden_size
        assert mlp.intermediate_size == tiny_llama_config.intermediate_size

    def test_mlp_forward(self, cpu_backend, tiny_llama_config):
        """Test MLP forward pass."""
        mlp = LlamaMLP(tiny_llama_config, cpu_backend)
        
        batch_size = 2
        seq_len = 5
        hidden_states = torch.randn(batch_size, seq_len, tiny_llama_config.hidden_size)
        
        with torch.no_grad():
            output = mlp(hidden_states)
        
        # Output should match input shape
        assert output.shape == hidden_states.shape

    def test_mlp_output_range(self, cpu_backend, tiny_llama_config):
        """Test that MLP output is in reasonable range."""
        mlp = LlamaMLP(tiny_llama_config, cpu_backend)
        
        hidden_states = torch.randn(1, 3, tiny_llama_config.hidden_size)
        
        with torch.no_grad():
            output = mlp(hidden_states)
        
        # Output should be finite
        assert torch.isfinite(output).all()
        assert not torch.isnan(output).any()
