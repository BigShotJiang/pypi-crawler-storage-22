"""Tests for MixtralModel (Mixture of Experts).

Tests:
- MixtralModel forward pass shape correctness
- MoE routing mechanism (top-k expert selection)
- Expert activation and weight aggregation
- Compatibility with MixtralConfig
"""

from __future__ import annotations

import pytest
import torch

from sagellm_backend import get_provider
from sagellm_core.model import MixtralModel, get_model_class, is_model_registered


class TestMixtralModelRegistry:
    """Test Mixtral model registration."""

    def test_mixtral_registered(self):
        """Test Mixtral is registered with correct aliases."""
        assert is_model_registered("mixtral")
        assert is_model_registered("mixtral-moe")

    def test_mixtral_lookup(self):
        """Test Mixtral class lookup."""
        model_cls = get_model_class("mixtral")
        assert model_cls is MixtralModel


class TestMixtralSparseMoE:
    """Test MixtralSparseMoE layer."""

    @pytest.fixture
    def small_config(self):
        """Create a small Mixtral-like config."""

        class SmallConfig:
            hidden_size = 64
            intermediate_size = 128
            num_local_experts = 8
            num_experts_per_tok = 2

        return SmallConfig()

    @pytest.fixture
    def backend(self):
        return get_provider("cpu")

    def test_moe_creation(self, small_config, backend):
        """Test MoE layer creation."""
        from sagellm_core.model.mixtral import MixtralSparseMoE

        moe = MixtralSparseMoE(small_config, backend)

        assert moe.num_experts == 8
        assert moe.top_k == 2
        assert len(moe.experts) == 8

    def test_moe_forward(self, small_config, backend):
        """Test MoE forward pass."""
        from sagellm_core.model.mixtral import MixtralSparseMoE

        moe = MixtralSparseMoE(small_config, backend)
        moe.eval()

        batch_size = 2
        seq_len = 4
        hidden_states = torch.randn(batch_size, seq_len, small_config.hidden_size)

        with torch.no_grad():
            output = moe(hidden_states)

        assert output.shape == (batch_size, seq_len, small_config.hidden_size)

    def test_routing_mechanism(self, small_config, backend):
        """Test top-k expert routing."""
        from sagellm_core.model.mixtral import MixtralSparseMoE

        moe = MixtralSparseMoE(small_config, backend)
        moe.eval()

        batch_size = 1
        seq_len = 2
        hidden_states = torch.randn(batch_size, seq_len, small_config.hidden_size)

        with torch.no_grad():
            # Get router logits
            hidden_flat = hidden_states.view(-1, small_config.hidden_size)
            router_logits = moe.gate(hidden_flat)

            # Check top-k selection
            routing_weights, selected_experts = torch.topk(
                router_logits, k=moe.top_k, dim=-1
            )

            # Should select top-2 experts for each token
            assert selected_experts.shape == (batch_size * seq_len, 2)
            assert routing_weights.shape == (batch_size * seq_len, 2)

            # Selected expert indices should be valid
            assert torch.all(selected_experts >= 0)
            assert torch.all(selected_experts < 8)

    def test_expert_activation(self, small_config, backend):
        """Test that only selected experts are activated."""
        from sagellm_core.model.mixtral import MixtralSparseMoE

        moe = MixtralSparseMoE(small_config, backend)
        moe.eval()

        batch_size = 1
        seq_len = 1
        hidden_states = torch.randn(batch_size, seq_len, small_config.hidden_size)

        # Track which experts are called
        expert_calls = [0] * 8

        # Monkey-patch experts to track calls
        original_forwards = [expert.forward for expert in moe.experts]

        def make_tracking_forward(idx):
            def tracking_forward(x):
                expert_calls[idx] += 1
                return original_forwards[idx](x)

            return tracking_forward

        for i, expert in enumerate(moe.experts):
            expert.forward = make_tracking_forward(i)

        with torch.no_grad():
            _ = moe(hidden_states)

        # Only top-2 experts should be called
        num_activated = sum(1 for count in expert_calls if count > 0)
        assert num_activated <= 2, f"Expected ≤2 experts activated, got {num_activated}"


class TestMixtralModel:
    """Test MixtralModel."""

    @pytest.fixture
    def small_config(self):
        """Create a small Mixtral config."""

        class SmallConfig:
            hidden_size = 64
            num_attention_heads = 8
            num_key_value_heads = 4
            num_hidden_layers = 2
            vocab_size = 1000
            intermediate_size = 128
            rms_norm_eps = 1e-5
            rope_theta = 10000.0
            max_position_embeddings = 512
            num_local_experts = 8
            num_experts_per_tok = 2
            model_type = "mixtral"

        return SmallConfig()

    @pytest.fixture
    def backend(self):
        return get_provider("cpu")

    def test_mixtral_creation(self, small_config, backend):
        """Test MixtralModel creation."""
        model = MixtralModel(small_config, backend)

        assert model.vocab_size == small_config.vocab_size
        assert model.hidden_size == small_config.hidden_size
        assert model.num_layers == small_config.num_hidden_layers

    def test_mixtral_forward(self, small_config, backend):
        """Test Mixtral forward pass."""
        model = MixtralModel(small_config, backend)
        model.eval()

        batch_size = 2
        seq_len = 8
        input_ids = torch.randint(0, small_config.vocab_size, (batch_size, seq_len))

        with torch.no_grad():
            logits = model(input_ids)

        assert logits.shape == (batch_size, seq_len, small_config.vocab_size)

    def test_mixtral_with_cache(self, small_config, backend):
        """Test Mixtral with KV cache."""
        model = MixtralModel(small_config, backend)
        model.eval()

        batch_size = 1
        seq_len = 4
        input_ids = torch.randint(0, small_config.vocab_size, (batch_size, seq_len))

        with torch.no_grad():
            # First forward pass
            logits, cache = model(input_ids, use_cache=True)

            assert logits.shape == (batch_size, seq_len, small_config.vocab_size)
            assert len(cache) == small_config.num_hidden_layers

            # Second forward pass with cache
            next_ids = torch.randint(0, small_config.vocab_size, (batch_size, 1))
            logits2, cache2 = model(next_ids, past_key_values=cache, use_cache=True)

            assert logits2.shape == (batch_size, 1, small_config.vocab_size)
            assert cache2[0][0].shape[2] == seq_len + 1  # Extended cache

    def test_mixtral_decoder_layer(self, small_config, backend):
        """Test MixtralDecoderLayer uses MoE instead of MLP."""
        from sagellm_core.model.mixtral import MixtralDecoderLayer, MixtralSparseMoE

        layer = MixtralDecoderLayer(small_config, backend)

        # Should have block_sparse_moe instead of mlp
        assert hasattr(layer, "block_sparse_moe")
        assert isinstance(layer.block_sparse_moe, MixtralSparseMoE)


class TestMixtralMLP:
    """Test MixtralMLP (single expert)."""

    @pytest.fixture
    def small_config(self):
        class SmallConfig:
            hidden_size = 64
            intermediate_size = 128

        return SmallConfig()

    @pytest.fixture
    def backend(self):
        return get_provider("cpu")

    def test_expert_mlp_forward(self, small_config, backend):
        """Test single expert MLP."""
        from sagellm_core.model.mixtral import MixtralMLP

        mlp = MixtralMLP(small_config, backend)
        mlp.eval()

        batch_size = 2
        seq_len = 4
        x = torch.randn(batch_size, seq_len, small_config.hidden_size)

        with torch.no_grad():
            output = mlp(x)

        assert output.shape == (batch_size, seq_len, small_config.hidden_size)

    def test_expert_swiglu_activation(self, small_config, backend):
        """Test SwiGLU activation in expert."""
        from sagellm_core.model.mixtral import MixtralMLP

        mlp = MixtralMLP(small_config, backend)

        # Should have gate, up, down projections
        assert hasattr(mlp, "gate_proj")
        assert hasattr(mlp, "up_proj")
        assert hasattr(mlp, "down_proj")


class TestMixtralIntegration:
    """Integration tests for Mixtral."""

    @pytest.fixture
    def backend(self):
        return get_provider("cpu")

    def test_full_forward_pass(self, backend):
        """Test full Mixtral forward pass with realistic config."""

        class RealisticConfig:
            hidden_size = 128
            num_attention_heads = 8
            num_key_value_heads = 4
            num_hidden_layers = 4
            vocab_size = 5000
            intermediate_size = 256
            rms_norm_eps = 1e-5
            rope_theta = 10000.0
            max_position_embeddings = 1024
            num_local_experts = 8
            num_experts_per_tok = 2
            model_type = "mixtral"

        config = RealisticConfig()
        model = MixtralModel(config, backend)
        model.eval()

        batch_size = 2
        seq_len = 16
        input_ids = torch.randint(0, config.vocab_size, (batch_size, seq_len))

        with torch.no_grad():
            logits = model(input_ids)

        assert logits.shape == (batch_size, seq_len, config.vocab_size)
        assert not torch.isnan(logits).any()
        assert not torch.isinf(logits).any()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
