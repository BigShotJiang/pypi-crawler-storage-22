"""Tests for MODEL_REGISTRY and model registration system."""

import pytest

from sagellm_core.model.base import BaseLLMModel
from sagellm_core.model.registry import (
    MODEL_REGISTRY,
    get_model_class,
    is_model_registered,
    list_registered_models,
    register_model,
    unregister_model,
)


class TestModelRegistry:
    """Test MODEL_REGISTRY functionality."""

    def test_builtin_models_registered(self):
        """Test that built-in models are registered."""
        registered = list_registered_models()
        
        # Should have at least gpt2 and llama
        assert "gpt2" in registered
        assert "llama" in registered
        assert len(registered) >= 2

    def test_get_model_class_success(self):
        """Test getting a registered model class."""
        # Get GPT2Model
        gpt2_cls = get_model_class("gpt2")
        assert gpt2_cls.__name__ == "GPT2Model"
        assert issubclass(gpt2_cls, BaseLLMModel)
        
        # Get LlamaModel
        llama_cls = get_model_class("llama")
        assert llama_cls.__name__ == "LlamaModel"
        assert issubclass(llama_cls, BaseLLMModel)

    def test_get_model_class_case_insensitive(self):
        """Test that model lookup is case-insensitive."""
        cls1 = get_model_class("gpt2")
        cls2 = get_model_class("GPT2")
        cls3 = get_model_class("Gpt2")
        
        assert cls1 is cls2 is cls3

    def test_get_model_class_not_found(self):
        """Test that KeyError is raised for unregistered model."""
        with pytest.raises(KeyError) as exc_info:
            get_model_class("nonexistent_model")
        
        assert "not registered" in str(exc_info.value).lower()
        assert "available types" in str(exc_info.value).lower()

    def test_is_model_registered(self):
        """Test checking if model is registered."""
        assert is_model_registered("gpt2") is True
        assert is_model_registered("llama") is True
        assert is_model_registered("nonexistent") is False

    def test_register_model_decorator(self):
        """Test @register_model decorator."""
        # Create a test model class
        @register_model("test_model_unique_123")
        class TestModel(BaseLLMModel):
            def forward(self, input_ids, **kwargs):
                pass

        try:
            # Verify registration
            assert is_model_registered("test_model_unique_123")
            cls = get_model_class("test_model_unique_123")
            assert cls is TestModel
        finally:
            # Cleanup
            unregister_model("test_model_unique_123")

    def test_register_model_multiple_aliases(self):
        """Test registering model with multiple aliases."""
        @register_model("alias1_xyz", "alias2_xyz", "alias3_xyz")
        class MultiAliasModel(BaseLLMModel):
            def forward(self, input_ids, **kwargs):
                pass

        try:
            # All aliases should point to the same class
            cls1 = get_model_class("alias1_xyz")
            cls2 = get_model_class("alias2_xyz")
            cls3 = get_model_class("alias3_xyz")
            
            assert cls1 is cls2 is cls3 is MultiAliasModel
        finally:
            # Cleanup
            unregister_model("alias1_xyz")
            unregister_model("alias2_xyz")
            unregister_model("alias3_xyz")

    def test_register_duplicate_error(self):
        """Test that registering duplicate model type raises ValueError."""
        @register_model("duplicate_test_abc")
        class Model1(BaseLLMModel):
            def forward(self, input_ids, **kwargs):
                pass

        try:
            # Try to register another model with the same name
            with pytest.raises(ValueError) as exc_info:
                @register_model("duplicate_test_abc")
                class Model2(BaseLLMModel):
                    def forward(self, input_ids, **kwargs):
                        pass
            
            assert "already registered" in str(exc_info.value).lower()
        finally:
            # Cleanup
            unregister_model("duplicate_test_abc")

    def test_unregister_model(self):
        """Test unregistering a model."""
        @register_model("temp_model_xyz")
        class TempModel(BaseLLMModel):
            def forward(self, input_ids, **kwargs):
                pass

        # Verify registered
        assert is_model_registered("temp_model_xyz")
        
        # Unregister
        unregister_model("temp_model_xyz")
        
        # Verify unregistered
        assert not is_model_registered("temp_model_xyz")

    def test_unregister_not_found(self):
        """Test that unregistering non-existent model raises KeyError."""
        with pytest.raises(KeyError) as exc_info:
            unregister_model("model_that_does_not_exist_xyz")
        
        assert "not registered" in str(exc_info.value).lower()

    def test_llama_aliases(self):
        """Test that llama, llama2, llama3 all point to LlamaModel."""
        llama_cls = get_model_class("llama")
        llama2_cls = get_model_class("llama2")
        llama3_cls = get_model_class("llama3")
        
        # All should be the same class
        assert llama_cls is llama2_cls is llama3_cls
        assert llama_cls.__name__ == "LlamaModel"

    def test_registry_contents(self):
        """Test direct access to MODEL_REGISTRY."""
        # Registry should be a dict
        assert isinstance(MODEL_REGISTRY, dict)
        
        # Should contain expected models
        assert "gpt2" in MODEL_REGISTRY
        assert "llama" in MODEL_REGISTRY
        
        # Values should be classes
        for cls in MODEL_REGISTRY.values():
            assert isinstance(cls, type)
            assert issubclass(cls, BaseLLMModel)
