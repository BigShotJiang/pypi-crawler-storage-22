"""Tests for quantized weight loading.

Tests:
- QuantConfig creation and detection
- QuantizedWeightLoader registration
- INT8 weight loading
- AWQ weight loading (simplified)
- GPTQ weight loading (simplified)
"""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest
import torch

from sagellm_core.model.quantization import (
    QuantConfig,
    QuantizationType,
    detect_quantization,
)
from sagellm_core.model.weight_loader import get_weight_loader, is_weight_loader_registered
from sagellm_core.model.weight_loader.quantized import QuantizedWeightLoader


class TestQuantConfig:
    """Test QuantConfig."""

    def test_int8_config(self):
        """Test INT8 config creation."""
        config = QuantConfig(
            quant_type=QuantizationType.INT8,
            bits=8,
            group_size=-1,
        )

        assert config.quant_type == QuantizationType.INT8
        assert config.bits == 8
        assert config.group_size == -1

    def test_awq_config(self):
        """Test AWQ config creation."""
        config = QuantConfig(
            quant_type=QuantizationType.AWQ,
            bits=4,
            group_size=128,
        )

        assert config.quant_type == QuantizationType.AWQ
        assert config.bits == 4
        assert config.group_size == 128

    def test_from_dict_awq(self):
        """Test creating QuantConfig from AWQ dict."""
        config_dict = {
            "quant_method": "awq",
            "bits": 4,
            "group_size": 128,
            "version": "gemm",
        }

        config = QuantConfig.from_dict(config_dict)

        assert config.quant_type == QuantizationType.AWQ
        assert config.bits == 4
        assert config.group_size == 128
        assert config.quant_method == "awq"

    def test_from_dict_gptq(self):
        """Test creating QuantConfig from GPTQ dict."""
        config_dict = {
            "quant_method": "gptq",
            "bits": 4,
            "group_size": 128,
            "desc_act": True,
        }

        config = QuantConfig.from_dict(config_dict)

        assert config.quant_type == QuantizationType.GPTQ
        assert config.bits == 4
        assert config.desc_act is True

    def test_from_dict_int8(self):
        """Test creating QuantConfig from INT8 dict."""
        config_dict = {
            "quant_method": "int8",
            "bits": 8,
        }

        config = QuantConfig.from_dict(config_dict)

        assert config.quant_type == QuantizationType.INT8
        assert config.bits == 8


class TestQuantConfigDetection:
    """Test quantization detection."""

    def test_detect_awq(self):
        """Test detecting AWQ quantization."""
        with tempfile.TemporaryDirectory() as tmpdir:
            model_path = Path(tmpdir)

            # Create quantize_config.json
            config = {
                "quant_method": "awq",
                "bits": 4,
                "group_size": 128,
                "version": "gemm",
            }

            with open(model_path / "quantize_config.json", "w") as f:
                json.dump(config, f)

            # Detect
            detected = detect_quantization(str(model_path))

            assert detected is not None
            assert detected.quant_type == QuantizationType.AWQ
            assert detected.bits == 4

    def test_detect_no_quantization(self):
        """Test no quantization detected."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Empty directory
            detected = detect_quantization(tmpdir)
            assert detected is None


class TestQuantizedWeightLoaderRegistry:
    """Test QuantizedWeightLoader registration."""

    def test_quantized_loader_registered(self):
        """Test quantized loader is registered."""
        assert is_weight_loader_registered("quantized")
        assert is_weight_loader_registered("awq")
        assert is_weight_loader_registered("gptq")
        assert is_weight_loader_registered("int8")

    def test_get_quantized_loader(self):
        """Test getting quantized weight loader."""
        loader = get_weight_loader("quantized")
        assert isinstance(loader, QuantizedWeightLoader)

        loader = get_weight_loader("awq")
        assert isinstance(loader, QuantizedWeightLoader)


class TestQuantizedWeightLoader:
    """Test QuantizedWeightLoader."""

    @pytest.fixture
    def int8_config(self):
        """INT8 quantization config."""
        return QuantConfig(
            quant_type=QuantizationType.INT8,
            bits=8,
            group_size=-1,
        )

    @pytest.fixture
    def awq_config(self):
        """AWQ quantization config."""
        return QuantConfig(
            quant_type=QuantizationType.AWQ,
            bits=4,
            group_size=128,
        )

    def test_loader_creation(self, int8_config):
        """Test creating quantized weight loader."""
        loader = QuantizedWeightLoader(int8_config)
        assert loader.quant_config == int8_config

    def test_loader_no_config(self):
        """Test creating loader without config (auto-detect)."""
        loader = QuantizedWeightLoader()
        assert loader.quant_config is None

    def test_is_quantized_weight(self, int8_config):
        """Test detecting quantized weight names."""
        loader = QuantizedWeightLoader(int8_config)

        assert loader._is_quantized_weight("model.layers.0.qweight")
        assert loader._is_quantized_weight("model.layers.0.scales")
        assert loader._is_quantized_weight("model.layers.0.qzeros")
        assert not loader._is_quantized_weight("model.layers.0.weight")

    def test_find_weight_files_safetensors(self):
        """Test finding safetensors weight files."""
        with tempfile.TemporaryDirectory() as tmpdir:
            model_path = Path(tmpdir)

            # Create dummy safetensors files
            (model_path / "model-00001-of-00002.safetensors").touch()
            (model_path / "model-00002-of-00002.safetensors").touch()

            loader = QuantizedWeightLoader()
            files = loader._find_weight_files(model_path)

            assert len(files) == 2
            assert all(f.suffix == ".safetensors" for f in files)

    def test_find_weight_files_pytorch(self):
        """Test finding PyTorch weight files."""
        with tempfile.TemporaryDirectory() as tmpdir:
            model_path = Path(tmpdir)

            # Create dummy bin files
            (model_path / "pytorch_model.bin").touch()

            loader = QuantizedWeightLoader()
            files = loader._find_weight_files(model_path)

            assert len(files) == 1
            assert files[0].suffix == ".bin"

    def test_dequantize_int8_no_scale(self, int8_config):
        """Test INT8 dequantization without scale."""
        loader = QuantizedWeightLoader(int8_config)

        # Simulate INT8 weight
        qweight = torch.randint(-128, 127, (10, 10), dtype=torch.int8)

        # Dequantize without scale (just cast)
        weight_fp = loader._dequantize_int8(
            "model.qweight", qweight, {}, torch.float16
        )

        assert weight_fp.dtype == torch.float16
        assert weight_fp.shape == qweight.shape

    def test_dequantize_int8_with_scale(self, int8_config):
        """Test INT8 dequantization with scale."""
        loader = QuantizedWeightLoader(int8_config)

        # Simulate INT8 weight and scale
        qweight = torch.randint(-128, 127, (10, 10), dtype=torch.int8)
        scale = torch.rand(10, 10)

        weight_dict = {"model.scale": scale}

        # Dequantize with scale
        weight_fp = loader._dequantize_int8(
            "model.qweight", qweight, weight_dict, torch.float16
        )

        assert weight_fp.dtype == torch.float16
        # Should be roughly qweight * scale
        expected = qweight.to(torch.float16) * scale.to(torch.float16)
        assert torch.allclose(weight_fp, expected, atol=1e-3)


class TestQuantizedLoaderIntegration:
    """Integration tests for quantized weight loading."""

    def test_load_mock_int8_weights(self):
        """Test loading mock INT8 weights."""
        with tempfile.TemporaryDirectory() as tmpdir:
            model_path = Path(tmpdir)

            # Create quantization config
            quant_config_dict = {
                "quant_method": "int8",
                "bits": 8,
            }

            with open(model_path / "quantize_config.json", "w") as f:
                json.dump(quant_config_dict, f)

            # Create mock INT8 weights (PyTorch format)
            state_dict = {
                "model.embed_tokens.qweight": torch.randint(
                    -128, 127, (1000, 256), dtype=torch.int8
                ),
                "model.embed_tokens.scale": torch.rand(1000, 256),
                "lm_head.weight": torch.randn(1000, 256),
            }

            torch.save(state_dict, model_path / "pytorch_model.bin")

            # Load weights
            loader = QuantizedWeightLoader()
            weights = list(loader.load_weights(model_path, device="cpu", dtype=torch.float16))

            # Should have loaded and dequantized weights
            assert len(weights) > 0

            # Check weight names and types
            names = [name for name, _ in weights]
            assert any("embed_tokens" in name for name in names)

            # All should be float tensors (dequantized)
            for name, tensor in weights:
                assert tensor.dtype == torch.float16

    def test_load_with_auto_detect(self):
        """Test loading with auto-detection of quantization."""
        with tempfile.TemporaryDirectory() as tmpdir:
            model_path = Path(tmpdir)

            # Create AWQ config
            quant_config_dict = {
                "quant_method": "awq",
                "bits": 4,
                "group_size": 128,
            }

            with open(model_path / "quantize_config.json", "w") as f:
                json.dump(quant_config_dict, f)

            # Create mock weights
            state_dict = {
                "model.layers.0.qweight": torch.randint(
                    0, 255, (256, 64), dtype=torch.uint8
                ),
                "model.layers.0.scales": torch.rand(256, 1),
            }

            torch.save(state_dict, model_path / "pytorch_model.bin")

            # Load without providing quant_config (auto-detect)
            loader = QuantizedWeightLoader()
            list(loader.load_weights(model_path, device="cpu"))

            # Should auto-detect AWQ
            assert loader.quant_config is not None
            assert loader.quant_config.quant_type == QuantizationType.AWQ


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
