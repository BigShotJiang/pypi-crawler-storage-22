"""Tests for Qwen2Model implementation.

Tests:
- Qwen2Model forward pass shape correctness
- QKV projections have bias
- GQA attention mechanism
- Compatibility with Qwen2Config
"""

from __future__ import annotations

import pytest
import torch

from sagellm_backend import get_provider
from sagellm_core.model import Qwen2Model, get_model_class, is_model_registered


class TestQwen2ModelRegistry:
    """Test Qwen2 model registration."""

    def test_qwen2_registered(self):
        """Test Qwen2 is registered with correct aliases."""
        assert is_model_registered("qwen2")
        assert is_model_registered("qwen2.5")

    def test_qwen2_lookup(self):
        """Test Qwen2 class lookup."""
        model_cls = get_model_class("qwen2")
        assert model_cls is Qwen2Model

        model_cls = get_model_class("qwen2.5")
        assert model_cls is Qwen2Model


class TestQwen2Config:
    """Test Qwen2 with HuggingFace configs."""

    @pytest.fixture
    def qwen2_config(self):
        """Create a minimal Qwen2 config for testing."""
        try:
            from transformers import AutoConfig
        except ImportError:
            pytest.skip("transformers not installed")

        # Use a small config for testing
        config = AutoConfig.from_pretrained("Qwen/Qwen2-0.5B")
        return config

    @pytest.fixture
    def backend(self):
        """Create CPU backend."""
        return get_provider("cpu")

    def test_qwen2_model_creation(self, qwen2_config, backend):
        """Test creating Qwen2Model from config."""
        model = Qwen2Model(qwen2_config, backend)

        assert model.vocab_size == qwen2_config.vocab_size
        assert model.hidden_size == qwen2_config.hidden_size
        assert model.num_layers == qwen2_config.num_hidden_layers

    def test_qwen2_forward_shape(self, qwen2_config, backend):
        """Test Qwen2 forward pass output shape."""
        model = Qwen2Model(qwen2_config, backend)
        model.eval()

        batch_size = 2
        seq_len = 10
        input_ids = torch.randint(0, qwen2_config.vocab_size, (batch_size, seq_len))

        with torch.no_grad():
            logits = model(input_ids)

        assert logits.shape == (batch_size, seq_len, qwen2_config.vocab_size)

    def test_qwen2_with_cache(self, qwen2_config, backend):
        """Test Qwen2 with KV cache."""
        model = Qwen2Model(qwen2_config, backend)
        model.eval()

        batch_size = 1
        seq_len = 5
        input_ids = torch.randint(0, qwen2_config.vocab_size, (batch_size, seq_len))

        with torch.no_grad():
            # First forward pass
            logits, cache = model(input_ids, use_cache=True)

            assert logits.shape == (batch_size, seq_len, qwen2_config.vocab_size)
            assert len(cache) == qwen2_config.num_hidden_layers
            assert cache[0][0].shape[2] == seq_len  # key cache seq dim

            # Second forward pass with cache
            next_ids = torch.randint(0, qwen2_config.vocab_size, (batch_size, 1))
            logits2, cache2 = model(next_ids, past_key_values=cache, use_cache=True)

            assert logits2.shape == (batch_size, 1, qwen2_config.vocab_size)
            assert cache2[0][0].shape[2] == seq_len + 1  # Extended cache


class TestQwen2Attention:
    """Test Qwen2Attention with bias."""

    @pytest.fixture
    def small_config(self):
        """Create a small Qwen2-like config."""

        class SmallConfig:
            hidden_size = 64
            num_attention_heads = 8
            num_key_value_heads = 4  # GQA
            num_hidden_layers = 2
            vocab_size = 1000
            intermediate_size = 128
            rms_norm_eps = 1e-6
            rope_theta = 10000.0
            max_position_embeddings = 512
            model_type = "qwen2"

        return SmallConfig()

    @pytest.fixture
    def backend(self):
        return get_provider("cpu")

    def test_attention_has_bias(self, small_config, backend):
        """Test Qwen2Attention QKV projections have bias."""
        from sagellm_core.model.qwen2 import Qwen2Attention

        attn = Qwen2Attention(small_config, backend)

        # Check QKV projections have bias
        assert attn.q_proj.bias is not None
        assert attn.k_proj.bias is not None
        assert attn.v_proj.bias is not None
        assert attn.o_proj.bias is not None

    def test_attention_forward(self, small_config, backend):
        """Test Qwen2Attention forward pass."""
        from sagellm_core.model.qwen2 import Qwen2Attention

        attn = Qwen2Attention(small_config, backend)
        attn.eval()

        batch_size = 2
        seq_len = 8
        hidden_states = torch.randn(batch_size, seq_len, small_config.hidden_size)

        with torch.no_grad():
            output, cache = attn(hidden_states, use_cache=True)

        assert output.shape == (batch_size, seq_len, small_config.hidden_size)
        assert cache[0].shape[2] == seq_len  # key cache

    def test_gqa_mechanism(self, small_config, backend):
        """Test GQA with num_kv_heads < num_heads."""
        from sagellm_core.model.qwen2 import Qwen2Attention

        attn = Qwen2Attention(small_config, backend)

        # Verify GQA configuration
        assert attn.num_heads == 8
        assert attn.num_kv_heads == 4
        assert attn.num_kv_groups == 2  # 8 / 4 = 2

        # Check projection dimensions
        assert attn.q_size == 64  # 8 * 8
        assert attn.kv_size == 32  # 4 * 8


class TestQwen2MLP:
    """Test Qwen2MLP (SwiGLU activation)."""

    @pytest.fixture
    def small_config(self):
        class SmallConfig:
            hidden_size = 64
            intermediate_size = 128

        return SmallConfig()

    @pytest.fixture
    def backend(self):
        return get_provider("cpu")

    def test_mlp_no_bias(self, small_config, backend):
        """Test Qwen2MLP has no bias in projections."""
        from sagellm_core.model.qwen2 import Qwen2MLP

        mlp = Qwen2MLP(small_config, backend)

        # MLP projections should NOT have bias
        assert mlp.gate_proj.bias is None
        assert mlp.up_proj.bias is None
        assert mlp.down_proj.bias is None

    def test_mlp_forward(self, small_config, backend):
        """Test Qwen2MLP forward pass."""
        from sagellm_core.model.qwen2 import Qwen2MLP

        mlp = Qwen2MLP(small_config, backend)
        mlp.eval()

        batch_size = 2
        seq_len = 8
        x = torch.randn(batch_size, seq_len, small_config.hidden_size)

        with torch.no_grad():
            output = mlp(x)

        assert output.shape == (batch_size, seq_len, small_config.hidden_size)


class TestQwen2DecoderLayer:
    """Test Qwen2DecoderLayer."""

    @pytest.fixture
    def small_config(self):
        class SmallConfig:
            hidden_size = 64
            num_attention_heads = 8
            num_key_value_heads = 4
            intermediate_size = 128
            rms_norm_eps = 1e-6
            rope_theta = 10000.0
            max_position_embeddings = 512
            model_type = "qwen2"

        return SmallConfig()

    @pytest.fixture
    def backend(self):
        return get_provider("cpu")

    def test_decoder_layer_forward(self, small_config, backend):
        """Test Qwen2DecoderLayer forward pass."""
        from sagellm_core.model.qwen2 import Qwen2DecoderLayer

        layer = Qwen2DecoderLayer(small_config, backend)
        layer.eval()

        batch_size = 2
        seq_len = 8
        hidden_states = torch.randn(batch_size, seq_len, small_config.hidden_size)

        with torch.no_grad():
            output, cache = layer(hidden_states, use_cache=True)

        assert output.shape == (batch_size, seq_len, small_config.hidden_size)
        assert cache is not None

    def test_residual_connections(self, small_config, backend):
        """Test residual connections work correctly."""
        from sagellm_core.model.qwen2 import Qwen2DecoderLayer

        layer = Qwen2DecoderLayer(small_config, backend)
        layer.eval()

        batch_size = 1
        seq_len = 4
        hidden_states = torch.randn(batch_size, seq_len, small_config.hidden_size)

        with torch.no_grad():
            output, _ = layer(hidden_states, use_cache=False)

        # Output should be different from input due to transformations
        assert not torch.allclose(output, hidden_states, atol=1e-3)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
