"""Integration tests for Task 1: End-to-end model loading and inference.

Tests that LLaMA model can load HuggingFace weights and perform inference.
"""

import pytest
import torch


@pytest.mark.integration
class TestLlamaIntegration:
    """Integration tests for LLaMA model with HuggingFace weights."""

    def test_llama_load_from_huggingface_weights(self):
        """Test loading HuggingFace LLaMA weights into our custom model."""
        from transformers import LlamaConfig, LlamaForCausalLM as HFLlamaForCausalLM

        from sagellm_core.models.llama import LlamaForCausalLM

        # Create a small HF model
        hf_config = LlamaConfig(
            vocab_size=1000,
            hidden_size=256,
            intermediate_size=512,
            num_hidden_layers=2,
            num_attention_heads=4,
            num_key_value_heads=4,
            max_position_embeddings=512,
        )
        hf_model = HFLlamaForCausalLM(hf_config)

        # Create our custom model with same config
        sage_model = LlamaForCausalLM(hf_config, tp_size=1, tp_rank=0)

        # Extract weights from HF model
        def weight_iterator():
            for name, param in hf_model.named_parameters():
                # Map HF names to our names
                sage_name = name.replace("model.", "")
                yield (sage_name, param.data.clone())

        # Load weights into our model
        loaded_params = sage_model.load_weights(weight_iterator())

        # Verify loading
        print(f"Loaded {len(loaded_params)} parameters")

    def test_llama_inference_comparison(self):
        """Compare output between HF and our implementation."""
        from transformers import LlamaConfig, LlamaForCausalLM as HFLlamaForCausalLM

        from sagellm_core.models.attention_metadata import AttentionMetadata
        from sagellm_core.models.llama import LlamaForCausalLM

        # Create models
        config = LlamaConfig(
            vocab_size=1000,
            hidden_size=256,
            intermediate_size=512,
            num_hidden_layers=2,
            num_attention_heads=4,
            num_key_value_heads=4,
            max_position_embeddings=512,
        )

        hf_model = HFLlamaForCausalLM(config)
        hf_model.eval()

        sage_model = LlamaForCausalLM(config, tp_size=1, tp_rank=0)
        sage_model.eval()

        # Copy weights from HF to Sage
        def weight_iterator():
            for name, param in hf_model.named_parameters():
                sage_name = name.replace("model.", "")
                yield (sage_name, param.data.clone())

        sage_model.load_weights(weight_iterator())

        # Create input
        batch_size, seq_len = 1, 8
        input_ids = torch.randint(0, 1000, (batch_size, seq_len))
        positions = torch.arange(seq_len).unsqueeze(0)

        # HF forward
        with torch.no_grad():
            hf_output = hf_model(input_ids=input_ids).logits

        # Sage forward
        with torch.no_grad():
            attn_metadata = AttentionMetadata.from_simple_batch(
                batch_size, seq_len, is_prompt=True
            )
            sage_output = sage_model(input_ids, positions, [], attn_metadata)

        print(f"HF output shape: {hf_output.shape}")
        print(f"Sage output shape: {sage_output.shape}")

        # Note: Outputs might not be exactly the same due to differences in implementation
        # But shapes should match
        assert hf_output.shape == sage_output.shape


class TestModelRegistry:
    """Tests for model registry and factory pattern."""

    def test_model_can_be_imported(self):
        """Test that models can be imported from package."""
        from sagellm_core.models import LlamaForCausalLM, Qwen2ForCausalLM, SagePretrainedModel

        assert issubclass(LlamaForCausalLM, SagePretrainedModel)
        assert issubclass(Qwen2ForCausalLM, SagePretrainedModel)

    def test_packed_modules_mapping_exists(self):
        """Test that all models define packed_modules_mapping."""
        from sagellm_core.models import LlamaForCausalLM, Qwen2ForCausalLM

        for model_cls in [LlamaForCausalLM, Qwen2ForCausalLM]:
            assert hasattr(model_cls, "packed_modules_mapping")
            assert isinstance(model_cls.packed_modules_mapping, dict)
            assert "qkv_proj" in model_cls.packed_modules_mapping
            assert "gate_up_proj" in model_cls.packed_modules_mapping


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-m", "integration"])
