"""Unit tests for Task 1: Model Architecture Layer.

Tests for:
- Linear layers (Column/Row/QKV/Merged)
- Attention layer
- RoPE, RMSNorm
- LLaMA and Qwen2 models
"""

import pytest
import torch
import torch.nn as nn


class TestLinearLayers:
    """Tests for parallel linear layers."""

    def test_column_parallel_linear(self):
        """Test ColumnParallelLinear basic functionality."""
        from sagellm_core.models.linear import ColumnParallelLinear

        # Create layer
        layer = ColumnParallelLinear(
            input_size=512,
            output_size=1024,
            bias=False,
            tp_size=2,
            tp_rank=0,
        )

        # Check weight shape
        assert layer.weight.shape == (512, 512)  # 1024 / 2 = 512

        # Test forward
        x = torch.randn(2, 8, 512)  # [batch, seq_len, input_size]
        output = layer(x)
        assert output.shape == (2, 8, 512)  # [batch, seq_len, output_size_per_partition]

    def test_row_parallel_linear(self):
        """Test RowParallelLinear basic functionality."""
        from sagellm_core.models.linear import RowParallelLinear

        layer = RowParallelLinear(
            input_size=1024,
            output_size=512,
            bias=False,
            tp_size=2,
            tp_rank=0,
        )

        # Check weight shape: [output_size, input_size_per_partition]
        assert layer.weight.shape == (512, 512)  # input 1024 / 2 = 512

        # Test forward
        x = torch.randn(2, 8, 512)  # [batch, seq_len, input_size_per_partition]
        output = layer(x)
        assert output.shape == (2, 8, 512)

    def test_qkv_parallel_linear(self):
        """Test QKVParallelLinear weight fusion."""
        from sagellm_core.models.linear import QKVParallelLinear

        hidden_size = 512
        num_heads = 8
        num_kv_heads = 8
        head_dim = 64

        layer = QKVParallelLinear(
            hidden_size=hidden_size,
            num_heads=num_heads,
            num_kv_heads=num_kv_heads,
            head_dim=head_dim,
            bias=False,
            tp_size=1,
            tp_rank=0,
        )

        # Total output: Q (8*64) + K (8*64) + V (8*64) = 1536
        assert layer.output_size == 1536
        assert layer.weight.shape == (1536, 512)

        # Test weight_loader with q/k/v shards
        q_weight = torch.randn(512, 512)  # [num_heads * head_dim, hidden_size]
        k_weight = torch.randn(512, 512)
        v_weight = torch.randn(512, 512)

        layer.weight.weight_loader(layer.weight, q_weight, shard_id="q")
        layer.weight.weight_loader(layer.weight, k_weight, shard_id="k")
        layer.weight.weight_loader(layer.weight, v_weight, shard_id="v")

        # Verify weights were copied to correct positions
        assert torch.allclose(layer.weight.data[:512], q_weight)
        assert torch.allclose(layer.weight.data[512:1024], k_weight)
        assert torch.allclose(layer.weight.data[1024:1536], v_weight)

    def test_merged_column_parallel_linear(self):
        """Test MergedColumnParallelLinear (Gate-Up fusion)."""
        from sagellm_core.models.linear import MergedColumnParallelLinear

        layer = MergedColumnParallelLinear(
            input_size=512,
            output_sizes=[2048, 2048],  # gate and up
            bias=False,
            tp_size=1,
            tp_rank=0,
        )

        # Total output: 2048 + 2048 = 4096
        assert layer.output_size == 4096
        assert layer.weight.shape == (4096, 512)

        # Test weight_loader
        gate_weight = torch.randn(2048, 512)
        up_weight = torch.randn(2048, 512)

        layer.weight.weight_loader(layer.weight, gate_weight, shard_id="gate")
        layer.weight.weight_loader(layer.weight, up_weight, shard_id="up")

        # Verify
        assert torch.allclose(layer.weight.data[:2048], gate_weight)
        assert torch.allclose(layer.weight.data[2048:], up_weight)


class TestRotaryEmbedding:
    """Tests for RoPE."""

    def test_rotary_embedding_basic(self):
        """Test RoPE basic functionality."""
        from sagellm_core.models.rotary_embedding import RotaryEmbedding

        rope = RotaryEmbedding(
            dim=64,
            max_position_embeddings=2048,
            base=10000.0,
        )

        # Test forward
        x = torch.randn(2, 16, 64)  # [batch, seq_len, head_dim]
        positions = torch.arange(16).unsqueeze(0).expand(2, -1)  # [batch, seq_len]

        cos, sin = rope(x, positions)

        assert cos.shape == (2, 16, 64)
        assert sin.shape == (2, 16, 64)

    def test_apply_rotary_pos_emb(self):
        """Test applying RoPE to Q and K."""
        from sagellm_core.models.rotary_embedding import (
            RotaryEmbedding,
            apply_rotary_pos_emb,
        )

        rope = RotaryEmbedding(dim=64, max_position_embeddings=2048)

        # Create Q and K
        batch, seq_len, num_heads, head_dim = 2, 16, 8, 64
        q = torch.randn(batch, seq_len, num_heads, head_dim)
        k = torch.randn(batch, seq_len, num_heads, head_dim)
        positions = torch.arange(seq_len).unsqueeze(0).expand(batch, -1)

        cos, sin = rope(q, positions)
        q_rotated, k_rotated = apply_rotary_pos_emb(q, k, cos, sin)

        assert q_rotated.shape == q.shape
        assert k_rotated.shape == k.shape


class TestRMSNorm:
    """Tests for RMSNorm."""

    def test_rmsnorm_forward(self):
        """Test RMSNorm forward pass."""
        from sagellm_core.models.rmsnorm import RMSNorm

        norm = RMSNorm(hidden_size=512, eps=1e-6)

        x = torch.randn(2, 16, 512)
        output = norm(x)

        assert output.shape == x.shape

        # Check that output has unit variance (approximately)
        variance = output.pow(2).mean(-1)
        assert torch.allclose(variance, torch.ones_like(variance), atol=1e-3)


class TestAttention:
    """Tests for SageAttention."""

    def test_sage_attention_basic(self):
        """Test SageAttention basic functionality."""
        from sagellm_core.models.attention import SageAttention
        from sagellm_core.models.attention_metadata import AttentionMetadata

        attn = SageAttention(
            num_heads=8,
            head_dim=64,
            num_kv_heads=8,
            tp_size=1,
            tp_rank=0,
        )

        batch, seq_len = 2, 16
        q = torch.randn(batch, seq_len, 8, 64)
        k = torch.randn(batch, seq_len, 8, 64)
        v = torch.randn(batch, seq_len, 8, 64)
        positions = torch.arange(seq_len).unsqueeze(0).expand(batch, -1)

        metadata = AttentionMetadata.from_simple_batch(batch, seq_len, is_prompt=True)

        output = attn(q, k, v, positions, kv_cache=None, attn_metadata=metadata)

        assert output.shape == (batch, seq_len, 8 * 64)

    def test_sage_attention_gqa(self):
        """Test GQA (num_kv_heads < num_heads)."""
        from sagellm_core.models.attention import SageAttention
        from sagellm_core.models.attention_metadata import AttentionMetadata

        attn = SageAttention(
            num_heads=8,
            head_dim=64,
            num_kv_heads=2,  # GQA: 8 / 2 = 4 queries per KV
            tp_size=1,
            tp_rank=0,
        )

        batch, seq_len = 2, 16
        q = torch.randn(batch, seq_len, 8, 64)
        k = torch.randn(batch, seq_len, 2, 64)  # Fewer KV heads
        v = torch.randn(batch, seq_len, 2, 64)
        positions = torch.arange(seq_len).unsqueeze(0).expand(batch, -1)

        metadata = AttentionMetadata.from_simple_batch(batch, seq_len, is_prompt=True)

        output = attn(q, k, v, positions, kv_cache=None, attn_metadata=metadata)

        assert output.shape == (batch, seq_len, 8 * 64)


class TestLlamaModel:
    """Tests for LLaMA model."""

    def test_llama_model_creation(self):
        """Test creating a small LLaMA model."""
        from transformers import LlamaConfig

        from sagellm_core.models.llama import LlamaForCausalLM

        # Create small config for testing
        config = LlamaConfig(
            vocab_size=1000,
            hidden_size=256,
            intermediate_size=512,
            num_hidden_layers=2,
            num_attention_heads=4,
            num_key_value_heads=4,
            max_position_embeddings=512,
        )

        model = LlamaForCausalLM(config, tp_size=1, tp_rank=0)

        # Check structure
        assert len(model.layers) == 2
        assert model.embed_tokens.num_embeddings == 1000
        assert model.lm_head.vocab_size == 1000

    def test_llama_forward(self):
        """Test LLaMA forward pass."""
        from transformers import LlamaConfig

        from sagellm_core.models.attention_metadata import AttentionMetadata
        from sagellm_core.models.llama import LlamaForCausalLM

        config = LlamaConfig(
            vocab_size=1000,
            hidden_size=256,
            intermediate_size=512,
            num_hidden_layers=2,
            num_attention_heads=4,
            num_key_value_heads=4,
            max_position_embeddings=512,
        )

        model = LlamaForCausalLM(config, tp_size=1, tp_rank=0)

        # Create input
        batch_size, seq_len = 2, 8
        input_ids = torch.randint(0, 1000, (batch_size, seq_len))
        positions = torch.arange(seq_len).unsqueeze(0).expand(batch_size, -1)
        kv_caches = []
        attn_metadata = AttentionMetadata.from_simple_batch(
            batch_size, seq_len, is_prompt=True
        )

        # Forward
        logits = model(input_ids, positions, kv_caches, attn_metadata)

        assert logits.shape == (batch_size, seq_len, 1000)

    def test_llama_packed_modules_mapping(self):
        """Test that packed_modules_mapping is defined."""
        from sagellm_core.models.llama import LlamaForCausalLM

        assert "qkv_proj" in LlamaForCausalLM.packed_modules_mapping
        assert "gate_up_proj" in LlamaForCausalLM.packed_modules_mapping
        assert LlamaForCausalLM.packed_modules_mapping["qkv_proj"] == [
            "q_proj",
            "k_proj",
            "v_proj",
        ]
        assert LlamaForCausalLM.packed_modules_mapping["gate_up_proj"] == [
            "gate_proj",
            "up_proj",
        ]


class TestQwen2Model:
    """Tests for Qwen2 model."""

    def test_qwen2_model_creation(self):
        """Test creating a small Qwen2 model."""
        from transformers import Qwen2Config

        from sagellm_core.models.qwen2 import Qwen2ForCausalLM

        config = Qwen2Config(
            vocab_size=1000,
            hidden_size=256,
            intermediate_size=512,
            num_hidden_layers=2,
            num_attention_heads=4,
            num_key_value_heads=4,
            max_position_embeddings=512,
        )

        model = Qwen2ForCausalLM(config, tp_size=1, tp_rank=0)

        assert len(model.layers) == 2

    def test_qwen2_forward(self):
        """Test Qwen2 forward pass."""
        from transformers import Qwen2Config

        from sagellm_core.models.attention_metadata import AttentionMetadata
        from sagellm_core.models.qwen2 import Qwen2ForCausalLM

        config = Qwen2Config(
            vocab_size=1000,
            hidden_size=256,
            intermediate_size=512,
            num_hidden_layers=2,
            num_attention_heads=4,
            num_key_value_heads=4,
            max_position_embeddings=512,
        )

        model = Qwen2ForCausalLM(config, tp_size=1, tp_rank=0)

        batch_size, seq_len = 2, 8
        input_ids = torch.randint(0, 1000, (batch_size, seq_len))
        positions = torch.arange(seq_len).unsqueeze(0).expand(batch_size, -1)
        kv_caches = []
        attn_metadata = AttentionMetadata.from_simple_batch(
            batch_size, seq_len, is_prompt=True
        )

        logits = model(input_ids, positions, kv_caches, attn_metadata)

        assert logits.shape == (batch_size, seq_len, 1000)


class TestWeightLoader:
    """Tests for weight loading mechanism."""

    def test_base_model_load_weights(self):
        """Test that load_weights method works."""
        from transformers import LlamaConfig

        from sagellm_core.models.llama import LlamaForCausalLM

        config = LlamaConfig(
            vocab_size=100,
            hidden_size=64,
            intermediate_size=128,
            num_hidden_layers=1,
            num_attention_heads=2,
            num_key_value_heads=2,
            max_position_embeddings=128,
        )

        model = LlamaForCausalLM(config, tp_size=1, tp_rank=0)

        # Create fake weights iterator
        def weight_iterator():
            for name, param in model.named_parameters():
                # Create fake weight with same shape
                fake_weight = torch.randn_like(param)
                yield (name, fake_weight)

        # Load weights
        loaded_params = model.load_weights(weight_iterator())

        # Check that all parameters were loaded
        all_param_names = set(name for name, _ in model.named_parameters())
        assert loaded_params == all_param_names


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
