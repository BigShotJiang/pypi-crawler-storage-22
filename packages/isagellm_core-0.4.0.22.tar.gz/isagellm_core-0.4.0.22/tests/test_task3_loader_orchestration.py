"""Tests for Task 3: Model Loader Orchestration.

This test module validates:
1. ModelLoadConfig creation and conversion
2. Loader selection logic (factory pattern)
3. HFModelLoader backward compatibility
4. SageModelLoader integration (when Task 1 models are available)
5. LLMEngine integration

Test strategy:
- Unit tests for config and factory
- Integration tests with tiny models (sshleifer/tiny-gpt2)
- Mock tests for SageModelLoader (when Task 1 not complete)
"""

import pytest
import torch

from sagellm_core.llm_engine import LLMEngine, LLMEngineConfig
from sagellm_core.model import (
    HFModelLoader,
    ModelLoadConfig,
    SageModelLoader,
    get_model_loader,
)


class TestModelLoadConfig:
    """Test ModelLoadConfig creation and validation."""

    def test_create_basic_config(self):
        """Test creating basic ModelLoadConfig."""
        config = ModelLoadConfig(
            model_path="gpt2",
            dtype="float16",
        )

        assert config.model_path == "gpt2"
        assert config.dtype == "float16"
        assert config.tensor_parallel_size == 1
        assert config.use_optimized_model is False

    def test_from_engine_config(self):
        """Test creating ModelLoadConfig from LLMEngineConfig."""
        engine_config = LLMEngineConfig(
            model_path="gpt2",
            dtype="float32",
            max_model_len=2048,
            tensor_parallel_size=1,
        )

        load_config = ModelLoadConfig.from_engine_config(engine_config, backend=None)

        assert load_config.model_path == "gpt2"
        assert load_config.dtype == "float32"
        assert load_config.max_model_len == 2048
        assert load_config.tensor_parallel_size == 1

    def test_auto_enable_optimized_for_tp(self):
        """Test auto-enabling optimized model for TP > 1."""
        engine_config = LLMEngineConfig(
            model_path="gpt2",
            tensor_parallel_size=2,
        )

        load_config = ModelLoadConfig.from_engine_config(engine_config, backend=None)

        # Should auto-enable optimized model for TP
        assert load_config.use_optimized_model is True

    def test_get_torch_dtype(self):
        """Test torch dtype resolution."""
        config = ModelLoadConfig(model_path="gpt2", dtype="float16")
        assert config.get_torch_dtype() == torch.float16

        config = ModelLoadConfig(model_path="gpt2", dtype="bfloat16")
        assert config.get_torch_dtype() == torch.bfloat16

        config = ModelLoadConfig(model_path="gpt2", dtype="float32")
        assert config.get_torch_dtype() == torch.float32

    def test_get_torch_dtype_auto(self):
        """Test auto dtype selection."""
        config = ModelLoadConfig(model_path="gpt2", dtype="auto", device="cpu")
        assert config.get_torch_dtype() == torch.float32

        config = ModelLoadConfig(model_path="gpt2", dtype="auto", device="cuda")
        assert config.get_torch_dtype() == torch.float16

    def test_get_device_map(self):
        """Test device map generation for HF transformers."""
        config = ModelLoadConfig(model_path="gpt2", device="cpu")
        assert config.get_device_map() == "cpu"

        config = ModelLoadConfig(model_path="gpt2", device="cuda")
        assert config.get_device_map() == "auto"

        config = ModelLoadConfig(model_path="gpt2", device="auto")
        assert config.get_device_map() == "auto"


class TestLoaderFactory:
    """Test loader selection factory (get_model_loader)."""

    def test_default_to_hf_loader(self):
        """Test default selection is HFModelLoader."""
        config = ModelLoadConfig(
            model_path="gpt2",
            use_optimized_model=False,
        )

        loader = get_model_loader(config)
        assert isinstance(loader, HFModelLoader)

    def test_hf_loader_for_unsupported_architecture(self):
        """Test fallback to HFModelLoader for unsupported architectures."""
        config = ModelLoadConfig(
            model_path="sshleifer/tiny-gpt2",  # GPT2 architecture
            use_optimized_model=True,  # Request optimized
        )

        loader = get_model_loader(config)
        # Should fallback to HFModelLoader since GPT2 may not be registered
        # (depends on Task 1 implementation)
        assert isinstance(loader, (HFModelLoader, SageModelLoader))

    def test_sage_loader_for_supported_architecture(self):
        """Test SageModelLoader selection for supported architectures."""
        # This test will pass when Task 1 has registered models
        # For now, it should fallback to HFModelLoader
        config = ModelLoadConfig(
            model_path="sshleifer/tiny-gpt2",
            use_optimized_model=True,
        )

        loader = get_model_loader(config)
        # Will be SageModelLoader when GPT2 is registered in Task 1
        assert loader is not None


class TestHFModelLoader:
    """Test HFModelLoader functionality."""

    @pytest.mark.slow
    def test_load_tiny_model(self):
        """Test loading tiny-gpt2 with HFModelLoader."""
        config = ModelLoadConfig(
            model_path="sshleifer/tiny-gpt2",
            dtype="float32",
            device="cpu",
        )

        loader = HFModelLoader()
        model, tokenizer = loader.load(config)

        assert model is not None
        assert tokenizer is not None
        assert hasattr(model, "forward")
        assert hasattr(tokenizer, "encode")

    def test_hf_loader_supports_all(self):
        """Test HFModelLoader.supports() returns True for all configs."""
        config = ModelLoadConfig(model_path="any-model")
        loader = HFModelLoader()

        assert loader.supports(config) is True


class TestSageModelLoader:
    """Test SageModelLoader functionality."""

    def test_sage_loader_supports_check(self):
        """Test SageModelLoader.supports() for unsupported models."""
        config = ModelLoadConfig(
            model_path="sshleifer/tiny-gpt2",
        )

        loader = SageModelLoader()
        # Will return False until GPT2 is registered in Task 1
        supports = loader.supports(config)
        assert isinstance(supports, bool)

    @pytest.mark.skip(reason="Requires Task 1 model implementations")
    def test_load_with_sage_loader(self):
        """Test loading model with SageModelLoader."""
        # This test will be enabled when Task 1 is complete
        config = ModelLoadConfig(
            model_path="sshleifer/tiny-gpt2",
            use_optimized_model=True,
            device="cpu",
        )

        loader = SageModelLoader()
        model, tokenizer = loader.load(config)

        assert model is not None
        assert tokenizer is not None


class TestLLMEngineIntegration:
    """Test LLMEngine integration with new ModelLoader."""

    @pytest.mark.slow
    @pytest.mark.asyncio
    async def test_llm_engine_with_hf_loader(self):
        """Test LLMEngine uses HFModelLoader by default."""
        config = LLMEngineConfig(
            model_path="sshleifer/tiny-gpt2",
            backend_type="cpu",
            max_batch_size=1,
        )

        engine = LLMEngine(config)
        await engine.start()

        assert engine.is_running
        assert engine._model is not None
        assert engine._tokenizer is not None

        # Test generation
        response = await engine.generate("Hello", max_tokens=5)
        assert response.output_text

        await engine.stop()

    @pytest.mark.asyncio
    async def test_llm_engine_config_conversion(self):
        """Test LLMEngine creates correct ModelLoadConfig."""
        config = LLMEngineConfig(
            model_path="sshleifer/tiny-gpt2",
            backend_type="cpu",
            dtype="float32",
            max_model_len=512,
        )

        engine = LLMEngine(config)
        await engine.start()

        # Verify model was loaded
        assert engine._model is not None

        await engine.stop()

    @pytest.mark.skip(reason="Requires Task 1 + optimized model support")
    @pytest.mark.asyncio
    async def test_llm_engine_with_sage_loader(self):
        """Test LLMEngine with SageModelLoader (when available)."""
        config = LLMEngineConfig(
            model_path="sshleifer/tiny-gpt2",
            backend_type="cpu",
            tensor_parallel_size=1,
        )
        # Manually enable optimized model
        config.use_optimized_model = True

        engine = LLMEngine(config)
        await engine.start()

        assert engine.is_running
        # Should use SageModelLoader if GPT2 is registered

        await engine.stop()


class TestBackwardCompatibility:
    """Test backward compatibility with existing LLMEngine behavior."""

    @pytest.mark.slow
    @pytest.mark.asyncio
    async def test_existing_code_still_works(self):
        """Test existing LLMEngine usage patterns still work."""
        # This is the existing pattern - should continue to work
        config = LLMEngineConfig(
            model_path="sshleifer/tiny-gpt2",
            backend_type="cpu",
        )

        engine = LLMEngine(config)
        await engine.start()

        response = await engine.generate(
            prompt="Hello world",
            max_tokens=10,
            temperature=0.0,
        )

        assert response.output_text
        assert response.metrics.ttft_ms >= 0
        assert response.metrics.throughput_tps >= 0

        await engine.stop()

    @pytest.mark.slow
    @pytest.mark.asyncio
    async def test_sampling_params_still_work(self):
        """Test sampling parameter handling still works."""
        from sagellm_protocol.sampling import SamplingParams, DecodingStrategy

        config = LLMEngineConfig(
            model_path="sshleifer/tiny-gpt2",
            backend_type="cpu",
        )

        engine = LLMEngine(config)
        await engine.start()

        # Test with SamplingParams object
        sampling_params = SamplingParams(
            strategy=DecodingStrategy.GREEDY,
            max_tokens=5,
        )

        response = await engine.generate(
            prompt="Hello",
            sampling_params=sampling_params,
        )

        assert response.output_text

        await engine.stop()


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
