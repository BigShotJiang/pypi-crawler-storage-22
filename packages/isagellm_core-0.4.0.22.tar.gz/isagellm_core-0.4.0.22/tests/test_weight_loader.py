"""Tests for weight loader system."""

import json
import tempfile
from pathlib import Path

import pytest
import torch

from sagellm_core.model.weight_loader import (
    WEIGHT_LOADERS,
    WeightLoaderProtocol,
    SafetensorsLoader,
    PytorchLoader,
    get_weight_loader,
    list_weight_loaders,
    detect_weight_format,
    register_weight_loader,
)


class TestWeightLoaderRegistry:
    """Test WEIGHT_LOADERS registry functionality."""

    def test_builtin_loaders_registered(self):
        """Test that built-in loaders are registered."""
        loaders = list_weight_loaders()
        
        assert "safetensors" in loaders
        assert "pytorch" in loaders
        # Aliases
        assert "pt" in loaders
        assert "bin" in loaders

    def test_get_weight_loader_success(self):
        """Test getting a registered loader."""
        # Get safetensors loader
        loader = get_weight_loader("safetensors")
        assert isinstance(loader, SafetensorsLoader)
        assert isinstance(loader, WeightLoaderProtocol)
        
        # Get pytorch loader
        loader = get_weight_loader("pytorch")
        assert isinstance(loader, PytorchLoader)

    def test_get_weight_loader_case_insensitive(self):
        """Test that loader lookup is case-insensitive."""
        loader1 = get_weight_loader("safetensors")
        loader2 = get_weight_loader("SAFETENSORS")
        loader3 = get_weight_loader("SafeTensors")
        
        # Should be same class
        assert type(loader1) is type(loader2) is type(loader3)

    def test_get_weight_loader_not_found(self):
        """Test that KeyError is raised for unregistered format."""
        with pytest.raises(KeyError) as exc_info:
            get_weight_loader("nonexistent_format")
        
        assert "not registered" in str(exc_info.value).lower()

    def test_register_weight_loader_decorator(self):
        """Test @register_weight_loader decorator."""
        @register_weight_loader("test_format_xyz")
        class TestLoader:
            def load_weights(self, model_path, device="cpu", dtype=None):
                return iter([])
            
            def get_weight_files(self, model_path):
                return []

        try:
            # Verify registration
            loader = get_weight_loader("test_format_xyz")
            assert isinstance(loader, TestLoader)
        finally:
            # Cleanup
            del WEIGHT_LOADERS["test_format_xyz"]

    def test_pytorch_aliases(self):
        """Test that pytorch, pt, bin all point to PytorchLoader."""
        loader1 = get_weight_loader("pytorch")
        loader2 = get_weight_loader("pt")
        loader3 = get_weight_loader("bin")
        
        # All should be PytorchLoader instances
        assert type(loader1) is type(loader2) is type(loader3)
        assert isinstance(loader1, PytorchLoader)


class TestSafetensorsLoader:
    """Test SafetensorsLoader functionality."""

    def test_loader_creation(self):
        """Test creating SafetensorsLoader."""
        loader = SafetensorsLoader()
        assert loader is not None

    def test_get_weight_files_single_file(self):
        """Test getting weight files for single .safetensors file."""
        loader = SafetensorsLoader()
        
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            
            # Create a single safetensors file
            weight_file = tmpdir / "model.safetensors"
            weight_file.touch()
            
            files = loader.get_weight_files(tmpdir)
            assert len(files) == 1
            assert files[0] == weight_file

    def test_get_weight_files_sharded(self):
        """Test getting weight files for sharded model."""
        loader = SafetensorsLoader()
        
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            
            # Create sharded files
            shard1 = tmpdir / "model-00001-of-00002.safetensors"
            shard2 = tmpdir / "model-00002-of-00002.safetensors"
            shard1.touch()
            shard2.touch()
            
            # Create index file
            index = {
                "metadata": {"total_size": 1000000},
                "weight_map": {
                    "layer1.weight": "model-00001-of-00002.safetensors",
                    "layer2.weight": "model-00002-of-00002.safetensors",
                }
            }
            index_file = tmpdir / "model.safetensors.index.json"
            with open(index_file, "w") as f:
                json.dump(index, f)
            
            files = loader.get_weight_files(tmpdir)
            assert len(files) == 2
            assert shard1 in files
            assert shard2 in files

    def test_get_weight_files_file_not_found(self):
        """Test that FileNotFoundError is raised for non-existent path."""
        loader = SafetensorsLoader()
        
        with pytest.raises(FileNotFoundError):
            loader.get_weight_files("/nonexistent/path/xyz123")

    def test_get_weight_files_no_safetensors(self):
        """Test behavior when no .safetensors files found."""
        loader = SafetensorsLoader()
        
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            
            # Empty directory
            files = loader.get_weight_files(tmpdir)
            assert len(files) == 0

    def test_get_weight_files_direct_file(self):
        """Test passing a direct .safetensors file path."""
        loader = SafetensorsLoader()
        
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            weight_file = tmpdir / "checkpoint.safetensors"
            weight_file.touch()
            
            files = loader.get_weight_files(weight_file)
            assert len(files) == 1
            assert files[0] == weight_file

    def test_get_weight_files_wrong_extension(self):
        """Test that ValueError is raised for wrong file extension."""
        loader = SafetensorsLoader()
        
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            wrong_file = tmpdir / "model.bin"
            wrong_file.touch()
            
            with pytest.raises(ValueError) as exc_info:
                loader.get_weight_files(wrong_file)
            
            assert "safetensors" in str(exc_info.value).lower()


class TestPytorchLoader:
    """Test PytorchLoader functionality."""

    def test_loader_creation(self):
        """Test creating PytorchLoader."""
        loader = PytorchLoader()
        assert loader is not None

    def test_get_weight_files_single_bin(self):
        """Test getting weight files for single .bin file."""
        loader = PytorchLoader()
        
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            
            # Create pytorch_model.bin
            weight_file = tmpdir / "pytorch_model.bin"
            weight_file.touch()
            
            files = loader.get_weight_files(tmpdir)
            assert len(files) == 1
            assert files[0] == weight_file

    def test_get_weight_files_sharded_pytorch(self):
        """Test getting weight files for sharded pytorch model."""
        loader = PytorchLoader()
        
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            
            # Create sharded files
            shard1 = tmpdir / "pytorch_model-00001-of-00002.bin"
            shard2 = tmpdir / "pytorch_model-00002-of-00002.bin"
            shard1.touch()
            shard2.touch()
            
            # Create index file
            index = {
                "metadata": {"total_size": 1000000},
                "weight_map": {
                    "layer1.weight": "pytorch_model-00001-of-00002.bin",
                    "layer2.weight": "pytorch_model-00002-of-00002.bin",
                }
            }
            index_file = tmpdir / "pytorch_model.bin.index.json"
            with open(index_file, "w") as f:
                json.dump(index, f)
            
            files = loader.get_weight_files(tmpdir)
            assert len(files) == 2

    def test_get_weight_files_pt_extension(self):
        """Test loading .pt files."""
        loader = PytorchLoader()
        
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            
            # Create .pt file
            weight_file = tmpdir / "model.pt"
            weight_file.touch()
            
            files = loader.get_weight_files(tmpdir)
            assert len(files) >= 1
            # Should find the .pt file
            assert any(f.suffix == ".pt" for f in files)

    def test_get_weight_files_file_not_found(self):
        """Test that FileNotFoundError is raised for non-existent path."""
        loader = PytorchLoader()
        
        with pytest.raises(FileNotFoundError):
            loader.get_weight_files("/nonexistent/path/abc456")

    def test_get_weight_files_direct_bin_file(self):
        """Test passing a direct .bin file path."""
        loader = PytorchLoader()
        
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            weight_file = tmpdir / "checkpoint.bin"
            weight_file.touch()
            
            files = loader.get_weight_files(weight_file)
            assert len(files) == 1
            assert files[0] == weight_file

    def test_get_weight_files_wrong_extension(self):
        """Test that ValueError is raised for wrong file extension."""
        loader = PytorchLoader()
        
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            wrong_file = tmpdir / "model.txt"
            wrong_file.touch()
            
            with pytest.raises(ValueError) as exc_info:
                loader.get_weight_files(wrong_file)
            
            assert ".bin" in str(exc_info.value).lower() or ".pt" in str(exc_info.value).lower()


class TestDetectWeightFormat:
    """Test automatic weight format detection."""

    def test_detect_safetensors(self):
        """Test detecting safetensors format."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            
            # Create safetensors file
            (tmpdir / "model.safetensors").touch()
            
            format_name = detect_weight_format(tmpdir)
            assert format_name == "safetensors"

    def test_detect_pytorch(self):
        """Test detecting pytorch format."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            
            # Create .bin file
            (tmpdir / "pytorch_model.bin").touch()
            
            format_name = detect_weight_format(tmpdir)
            assert format_name == "pytorch"

    def test_detect_safetensors_priority(self):
        """Test that safetensors is preferred over pytorch."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            
            # Create both formats
            (tmpdir / "model.safetensors").touch()
            (tmpdir / "pytorch_model.bin").touch()
            
            format_name = detect_weight_format(tmpdir)
            # Safetensors should be preferred
            assert format_name == "safetensors"

    def test_detect_single_file(self):
        """Test detecting format from single file path."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            
            # Test safetensors file
            st_file = tmpdir / "model.safetensors"
            st_file.touch()
            assert detect_weight_format(st_file) == "safetensors"
            
            # Test pytorch file
            pt_file = tmpdir / "model.bin"
            pt_file.touch()
            assert detect_weight_format(pt_file) == "pytorch"

    def test_detect_not_found(self):
        """Test that ValueError is raised when no weights found."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            
            # Empty directory
            with pytest.raises(ValueError) as exc_info:
                detect_weight_format(tmpdir)
            
            assert "could not detect" in str(exc_info.value).lower()

    def test_detect_path_not_exists(self):
        """Test that FileNotFoundError is raised for non-existent path."""
        with pytest.raises(FileNotFoundError):
            detect_weight_format("/nonexistent/path/def789")


class TestWeightLoadingIntegration:
    """Integration tests for weight loading."""

    def test_load_weights_with_safetensors(self):
        """Test loading weights using SafetensorsLoader (requires safetensors package)."""
        pytest.importorskip("safetensors")
        
        loader = SafetensorsLoader()
        
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            
            # Create a simple safetensors file
            from safetensors.torch import save_file
            
            tensors = {
                "weight1": torch.randn(10, 20),
                "weight2": torch.randn(5, 5),
            }
            
            save_file(tensors, tmpdir / "model.safetensors")
            
            # Load weights
            loaded = list(loader.load_weights(tmpdir))
            
            assert len(loaded) == 2
            names = [name for name, _ in loaded]
            assert "weight1" in names
            assert "weight2" in names

    def test_load_weights_with_pytorch(self):
        """Test loading weights using PytorchLoader."""
        loader = PytorchLoader()
        
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            
            # Create a simple pytorch checkpoint
            state_dict = {
                "layer1.weight": torch.randn(10, 20),
                "layer2.bias": torch.randn(5),
            }
            
            torch.save(state_dict, tmpdir / "pytorch_model.bin")
            
            # Load weights
            loaded = list(loader.load_weights(tmpdir))
            
            assert len(loaded) == 2
            names = [name for name, _ in loaded]
            assert "layer1.weight" in names
            assert "layer2.bias" in names
