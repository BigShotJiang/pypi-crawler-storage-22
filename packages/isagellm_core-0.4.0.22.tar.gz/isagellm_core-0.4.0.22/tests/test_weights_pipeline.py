"""Tests for weight loading pipeline components.

Tests cover:
- Weight iterators (SafetensorsIterator, PytorchIterator)
- Weight name mapping
- Tensor parallel sharding
- Weight fusion
- Complete pipeline integration
"""

import tempfile
from pathlib import Path

import pytest
import torch

from sagellm_core.model.weights import (
    SafetensorsIterator,
    PytorchIterator,
    WeightNameMapper,
    WeightSharder,
    WeightFuser,
    WeightPipeline,
    get_weight_iterator,
)


class TestWeightIterators:
    """Test weight iterator implementations."""

    @pytest.fixture
    def temp_safetensors_file(self):
        """Create a temporary safetensors file."""
        try:
            from safetensors.torch import save_file
        except ImportError:
            pytest.skip("safetensors not installed")

        with tempfile.NamedTemporaryFile(suffix=".safetensors", delete=False) as f:
            temp_path = Path(f.name)

        # Create test tensors
        tensors = {
            "layer.0.weight": torch.randn(128, 256),
            "layer.0.bias": torch.randn(128),
            "layer.1.weight": torch.randn(256, 128),
        }
        save_file(tensors, str(temp_path))

        yield temp_path

        # Cleanup
        temp_path.unlink()

    @pytest.fixture
    def temp_pytorch_file(self):
        """Create a temporary PyTorch file."""
        with tempfile.NamedTemporaryFile(suffix=".bin", delete=False) as f:
            temp_path = Path(f.name)

        tensors = {
            "layer.0.weight": torch.randn(128, 256),
            "layer.0.bias": torch.randn(128),
        }
        torch.save(tensors, str(temp_path))

        yield temp_path

        # Cleanup
        temp_path.unlink()

    def test_safetensors_iterator(self, temp_safetensors_file):
        """Test SafetensorsIterator loads weights correctly."""
        iterator = SafetensorsIterator(temp_safetensors_file)
        weights = list(iterator)

        assert len(weights) == 3
        names = [name for name, _ in weights]
        assert "layer.0.weight" in names
        assert "layer.0.bias" in names
        assert "layer.1.weight" in names

    def test_pytorch_iterator(self, temp_pytorch_file):
        """Test PytorchIterator loads weights correctly."""
        iterator = PytorchIterator(temp_pytorch_file)
        weights = list(iterator)

        assert len(weights) == 2
        names = [name for name, _ in weights]
        assert "layer.0.weight" in names
        assert "layer.0.bias" in names

    def test_get_weight_iterator_safetensors(self, temp_safetensors_file):
        """Test factory function selects SafetensorsIterator."""
        iterator = get_weight_iterator(temp_safetensors_file)
        assert isinstance(iterator, SafetensorsIterator)

    def test_get_weight_iterator_pytorch(self, temp_pytorch_file):
        """Test factory function selects PytorchIterator."""
        iterator = get_weight_iterator(temp_pytorch_file)
        assert isinstance(iterator, PytorchIterator)


class TestWeightNameMapper:
    """Test weight name mapping."""

    def test_basic_mapping(self):
        """Test basic prefix and substring mapping."""
        mapper = WeightNameMapper()
        result = mapper.map("model.layers.0.self_attn.weight")

        # Should remove "model." prefix and replace "self_attn" with "attention"
        assert result.sage_name == "layers.0.attention.weight"
        assert result.shard_id == -1
        assert not result.is_fused

    def test_qkv_fusion_mapping(self):
        """Test QKV fusion mapping."""
        packed_modules = {"qkv_proj": ["q_proj", "k_proj", "v_proj"]}
        mapper = WeightNameMapper(packed_modules)

        # Test q_proj
        result = mapper.map("model.layers.0.self_attn.q_proj.weight")
        assert result.sage_name == "layers.0.attention.qkv_proj.weight"
        assert result.shard_id == 0
        assert result.is_fused

        # Test k_proj
        result = mapper.map("model.layers.0.self_attn.k_proj.weight")
        assert result.sage_name == "layers.0.attention.qkv_proj.weight"
        assert result.shard_id == 1
        assert result.is_fused

        # Test v_proj
        result = mapper.map("model.layers.0.self_attn.v_proj.weight")
        assert result.sage_name == "layers.0.attention.qkv_proj.weight"
        assert result.shard_id == 2
        assert result.is_fused

    def test_gate_up_fusion_mapping(self):
        """Test gate_up fusion mapping."""
        packed_modules = {"gate_up_proj": ["gate_proj", "up_proj"]}
        mapper = WeightNameMapper(packed_modules)

        result = mapper.map("model.layers.0.mlp.gate_proj.weight")
        assert result.sage_name == "layers.0.mlp.gate_up_proj.weight"
        assert result.shard_id == 0

        result = mapper.map("model.layers.0.mlp.up_proj.weight")
        assert result.sage_name == "layers.0.mlp.gate_up_proj.weight"
        assert result.shard_id == 1


class TestWeightSharder:
    """Test tensor parallel sharding."""

    def test_no_sharding_tp1(self):
        """Test that TP=1 doesn't shard."""
        sharder = WeightSharder(tp_size=1, tp_rank=0)
        tensor = torch.randn(1024, 512)

        result = sharder.shard("q_proj.weight", tensor)
        assert result.shape == tensor.shape
        assert torch.equal(result, tensor)

    def test_column_parallel_sharding(self):
        """Test column parallel sharding (q_proj, k_proj, etc.)."""
        sharder = WeightSharder(tp_size=2, tp_rank=0)
        tensor = torch.randn(1024, 512)  # [out_features, in_features]

        result = sharder.shard("q_proj.weight", tensor)
        assert result.shape == (512, 512)  # Split along dim=0

        # Rank 1 should get different shard
        sharder_rank1 = WeightSharder(tp_size=2, tp_rank=1)
        result_rank1 = sharder_rank1.shard("q_proj.weight", tensor)
        assert result_rank1.shape == (512, 512)
        assert not torch.equal(result, result_rank1)

    def test_row_parallel_sharding(self):
        """Test row parallel sharding (o_proj, down_proj)."""
        sharder = WeightSharder(tp_size=2, tp_rank=0)
        tensor = torch.randn(512, 1024)  # [out_features, in_features]

        result = sharder.shard("o_proj.weight", tensor)
        assert result.shape == (512, 512)  # Split along dim=1

    def test_no_shard_patterns(self):
        """Test that norm layers are not sharded."""
        sharder = WeightSharder(tp_size=2, tp_rank=0)
        tensor = torch.randn(1024)

        result = sharder.shard("input_layernorm.weight", tensor)
        assert result.shape == tensor.shape
        assert torch.equal(result, tensor)


class TestWeightFuser:
    """Test weight fusion."""

    def test_qkv_fusion(self):
        """Test QKV weight fusion."""
        fusion_mapping = {"qkv_proj": ["q_proj", "k_proj", "v_proj"]}
        fuser = WeightFuser(fusion_mapping)

        q_tensor = torch.randn(1024, 512)
        k_tensor = torch.randn(1024, 512)
        v_tensor = torch.randn(1024, 512)

        # Process q - should buffer
        result = list(fuser.process("qkv_proj.weight", q_tensor, shard_id=0))
        assert len(result) == 0

        # Process k - should buffer
        result = list(fuser.process("qkv_proj.weight", k_tensor, shard_id=1))
        assert len(result) == 0

        # Process v - should output fused weight
        result = list(fuser.process("qkv_proj.weight", v_tensor, shard_id=2))
        assert len(result) == 1
        name, fused = result[0]
        assert name == "qkv_proj.weight"
        assert fused.shape == (3072, 512)  # 3 * 1024

        # Verify concatenation order
        assert torch.equal(fused[:1024], q_tensor)
        assert torch.equal(fused[1024:2048], k_tensor)
        assert torch.equal(fused[2048:], v_tensor)

    def test_non_fused_passthrough(self):
        """Test that non-fused weights pass through immediately."""
        fusion_mapping = {"qkv_proj": ["q_proj", "k_proj", "v_proj"]}
        fuser = WeightFuser(fusion_mapping)

        tensor = torch.randn(1024, 512)
        result = list(fuser.process("other.weight", tensor, shard_id=-1))

        assert len(result) == 1
        name, output = result[0]
        assert name == "other.weight"
        assert torch.equal(output, tensor)

    def test_flush_incomplete(self):
        """Test flushing incomplete fusion."""
        fusion_mapping = {"qkv_proj": ["q_proj", "k_proj", "v_proj"]}
        fuser = WeightFuser(fusion_mapping)

        q_tensor = torch.randn(1024, 512)
        k_tensor = torch.randn(1024, 512)

        # Only process q and k
        list(fuser.process("qkv_proj.weight", q_tensor, shard_id=0))
        list(fuser.process("qkv_proj.weight", k_tensor, shard_id=1))

        # Flush should output partial fusion
        with pytest.warns(UserWarning, match="Incomplete fusion"):
            result = list(fuser.flush())
        
        assert len(result) == 1
        name, fused = result[0]
        assert fused.shape == (2048, 512)  # Only q and k


class TestWeightPipeline:
    """Test complete weight pipeline."""

    @pytest.fixture
    def sample_weights(self):
        """Create sample weights in memory."""
        return {
            "model.layers.0.self_attn.q_proj.weight": torch.randn(1024, 512),
            "model.layers.0.self_attn.k_proj.weight": torch.randn(1024, 512),
            "model.layers.0.self_attn.v_proj.weight": torch.randn(1024, 512),
            "model.layers.0.self_attn.o_proj.weight": torch.randn(512, 1024),
            "model.layers.0.input_layernorm.weight": torch.randn(512),
        }

    def test_full_pipeline(self, sample_weights):
        """Test complete pipeline with mapping, sharding, and fusion."""
        # Create a mock iterator
        class MockIterator:
            def __init__(self, weights):
                self.weights = weights

            def __iter__(self):
                return iter(self.weights.items())

        packed_modules = {"qkv_proj": ["q_proj", "k_proj", "v_proj"]}

        pipeline = (
            WeightPipeline(MockIterator(sample_weights))
            .with_mapping(packed_modules)
            .with_sharding(tp_size=2, tp_rank=0)
            .with_fusion(packed_modules)
        )

        results = {name: tensor for name, tensor in pipeline}

        # Should have qkv_proj (fused), o_proj, and layernorm
        assert "layers.0.attention.qkv_proj.weight" in results
        assert "layers.0.attention.o_proj.weight" in results
        assert "layers.0.input_layernorm.weight" in results

        # QKV should be fused (3 * 1024 = 3072) and sharded (3072 / 2 = 1536)
        qkv = results["layers.0.attention.qkv_proj.weight"]
        assert qkv.shape[0] == 1536  # Sharded

        # o_proj should be sharded along dim=1
        o_proj = results["layers.0.attention.o_proj.weight"]
        assert o_proj.shape[1] == 512  # Sharded from 1024

        # layernorm should not be sharded
        ln = results["layers.0.input_layernorm.weight"]
        assert ln.shape[0] == 512  # Not sharded

    def test_pipeline_without_fusion(self, sample_weights):
        """Test pipeline without fusion."""
        class MockIterator:
            def __init__(self, weights):
                self.weights = weights

            def __iter__(self):
                return iter(self.weights.items())

        pipeline = (
            WeightPipeline(MockIterator(sample_weights))
            .with_mapping({})  # No fusion
            .with_sharding(tp_size=1, tp_rank=0)
        )

        results = {name: tensor for name, tensor in pipeline}

        # Should have separate q, k, v
        assert "layers.0.attention.q_proj.weight" in results
        assert "layers.0.attention.k_proj.weight" in results
        assert "layers.0.attention.v_proj.weight" in results


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
