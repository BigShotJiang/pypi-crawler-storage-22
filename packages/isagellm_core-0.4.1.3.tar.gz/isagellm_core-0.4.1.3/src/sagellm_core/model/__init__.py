"""Model loading for sageLLM.

This module provides HuggingFace-based model loading. All custom model
reimplementations (GPT-2, LLaMA, Qwen2, Mixtral) have been removed in favor
of the HF-first approach (2026-02 refactor).

Architecture decision:
    sageLLM loads models via HuggingFace transformers exclusively.
    Performance optimizations are applied on top of HF models:
    - FlashAttention: attn_implementation="flash_attention_2"
    - Quantization: bitsandbytes, GPTQ, AWQ via HF integration
    - KV Cache: HF generate() handles past_key_values natively
    - Tensor Parallel: torch.distributed.tensor_parallel

Model loading:
- ModelLoadConfig: Configuration for model loading
- get_model_loader: Factory to get loader (always returns HFModelLoader)
- HFModelLoader: HuggingFace compatible loader (the only loader)

Quantization:
- QuantConfig: Quantization configuration
- detect_quantization: Auto-detect quantization format
"""

# Model loading configuration and loaders
from sagellm_core.model.load_config import ModelLoadConfig
from sagellm_core.model.loader import ModelLoader as BaseModelLoader, get_model_loader
from sagellm_core.model.hf_loader import HFModelLoader

# Quantization
from sagellm_core.model.quantization import (
    QuantConfig,
    QuantizationType,
    detect_quantization,
)

# Legacy compatibility — simple HF loader utility
from sagellm_core.model.model_loader import ModelLoader, load_model

__all__ = [
    # Model loading
    "ModelLoadConfig",
    "BaseModelLoader",
    "get_model_loader",
    "HFModelLoader",
    # Quantization
    "QuantConfig",
    "QuantizationType",
    "detect_quantization",
    # Legacy
    "ModelLoader",
    "load_model",
]
