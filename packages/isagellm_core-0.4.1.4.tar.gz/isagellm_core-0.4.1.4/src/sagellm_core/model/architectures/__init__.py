"""Model architecture implementations."""

from __future__ import annotations

__all__ = []
