"""Custom model layers for sageLLM.

This module provides custom implementations of neural network layers
that can be injected with backend-specific kernels via the operator
mapping protocol defined in sagellm-protocol.

Layer hierarchy:
- base.py: Base layer classes and interfaces
- linear.py: Linear/projection layers
- attention.py: Attention mechanisms
- normalization.py: Layer/RMS normalization
- activation.py: Activation functions
- embedding.py: Token embeddings

All layers support kernel injection through the OperatorRegistry
mechanism defined in issue #34.
"""

from __future__ import annotations

from sagellm_core.model.layers.activation import GELU, SiLU, SwiGLU
from sagellm_core.model.layers.attention import Attention
from sagellm_core.model.layers.base import SageLLMLayer, WeightLoader
from sagellm_core.model.layers.embedding import Embedding
from sagellm_core.model.layers.linear import (
    ColumnParallelLinear,
    Linear,
    RowParallelLinear,
)
from sagellm_core.model.layers.normalization import LayerNorm, RMSNorm

__all__ = [
    "SageLLMLayer",
    "WeightLoader",
    "Linear",
    "ColumnParallelLinear",
    "RowParallelLinear",
    "RMSNorm",
    "LayerNorm",
    "Embedding",
    "Attention",
    "SiLU",
    "GELU",
    "SwiGLU",
]
