# sagellm-dev-tools: sageLLM Developer Tools

**Status**: 🚧 Under Development\
**PyPI Package**: `isagellm-dev-tools`\
**CLI Tool**: `sagellm-dev`

## 🎯 Purpose

Unified developer toolkit for sageLLM multi-repository development workflow.

## 📦 Installation

```bash
# Install from PyPI
pip install isagellm-dev-tools

# Or install from source
git clone git@github.com:intellistream/sagellm-dev-tools.git
cd sagellm-dev-tools
pip install -e .
```

## 🚀 Quick Start

```bash
# Initialize development environment (clone all repos)
sagellm-dev init

# Sync all repositories
sagellm-dev sync

# Check architecture and dependencies
sagellm-dev check

# Install git hooks to all repos
sagellm-dev hooks install

# Push all repositories
sagellm-dev push
```

## 📖 Command Reference

### Repository Management

```bash
sagellm-dev init                    # Clone all sageLLM repositories
sagellm-dev sync [--all]           # Sync all repos (git pull)
sagellm-dev push [--check]         # Batch push
sagellm-dev merge <from> <to>      # Batch merge branches
sagellm-dev status                 # Show status of all repos
```

### Architecture & Dependency Checks

```bash
sagellm-dev check                  # Run all checks
sagellm-dev check --arch          # Architecture conformance
sagellm-dev check --deps          # Dependency versions
sagellm-dev check --hooks         # Git hooks integrity
```

### Tool Fixes

```bash
sagellm-dev fix                   # Run all fixes
sagellm-dev fix --tools           # Fix tool versions (ruff, pre-commit)
sagellm-dev fix --deps            # Fix dependency mismatches
```

### Git Hooks Management

```bash
sagellm-dev hooks install         # Install hooks to all repos
sagellm-dev hooks uninstall       # Remove hooks
sagellm-dev hooks update          # Update hook templates
sagellm-dev hooks status          # Check hooks status
```

### PyTorch Management

```bash
sagellm-dev pytorch download <version> <platform>  # Download wheels
sagellm-dev pytorch upload <version> <platform>    # Upload to GitHub
sagellm-dev pytorch list                           # List versions

# Examples:
sagellm-dev pytorch download 2.5.1 cu121           # CUDA 12.1
sagellm-dev pytorch download 2.5.1 cpu             # CPU only
```

### Information

```bash
sagellm-dev info                  # Show environment info
sagellm-dev version               # Show version
```

### GitHub Issue Management

```bash
sagellm-dev gh list <repo>                                # List open issues
sagellm-dev gh view <repo> <issue>                        # View issue details
sagellm-dev gh assign <repo> <issue> <user>               # Assign issue to user
sagellm-dev gh assign-batch <repo> <user> <issues...>     # Batch assign
sagellm-dev gh priority <repo>                            # Group by assignee/priority
sagellm-dev gh create <repo> --title "..."                # Create issue
		[--body "..."] [--assignee user]... [--label label]...

# Examples:
sagellm-dev gh create sagellm-website --title "[Feature] Leaderboard" \
	--body "负责人：王明琪" --assignee MingqiWang-coder --label enhancement
```

## 🏗️ Architecture

```
sagellm-dev-tools/
├── src/sagellm_dev_tools/
│   ├── cli.py                 # Main CLI entry
│   ├── repo_manager.py        # Repository operations
│   ├── checker.py             # Architecture/dependency checks
│   ├── fixer.py               # Automated fixes
│   ├── hooks_manager.py       # Git hooks management
│   ├── pytorch_manager.py     # PyTorch download/upload
│   ├── constants.py           # Constants
│   └── templates/             # Git hook templates
└── tests/
```

## 🔒 Privacy

This is a **private** repository. Internal use only for sageLLM development team.

## 📄 License

Proprietary - Internal Use Only

______________________________________________________________________

**Maintainer**: IntelliStream Team\
**Related**: [sagellm](https://github.com/intellistream/sagellm)
