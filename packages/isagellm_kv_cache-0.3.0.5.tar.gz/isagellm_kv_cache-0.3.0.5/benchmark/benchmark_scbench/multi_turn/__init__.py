"""
Multi-Turn 模式 SCBench 评测
============================

使用 golden answers 构建对话历史，避免错误传播。
适用于：远程 API 或本地 vLLM。
"""
