"""Prefix cache indexing primitives."""

from __future__ import annotations

from .index import PrefixIndex

__all__ = ["PrefixIndex"]
