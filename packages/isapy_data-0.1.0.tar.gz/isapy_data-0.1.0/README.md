# ISAPy

Data package for *Introduction to Sports Analytics using Python* by Ryan Elmore.

## Installation

```bash
pip install isapy-data
```

For development:

```bash
pip install -e ".[dev]"
```

## Usage

```python
import isapy_data

# List all available datasets
isapy_data.list_datasets()

# Load a dataset
masters = isapy_data.load_data("masters")

# Get information about a specific dataset
isapy_data.describe("masters")

# Print info about all datasets
isapy_data.info()
```

## Available Datasets

### Golf
- `masters` - Masters Tournament data
- `ow_golf_rankings` - Official World Golf Rankings
- `pga_tournaments` - PGA Tour tournament data

### NBA
- `nba_adv_team_2021`, `nba_adv_team_2023`, `nba_adv_team_2024`, `nba_adv_team_2025` - Advanced team statistics
- `nba_ff_team_2021`, `nba_ff_team_2023`, `nba_ff_team_2024`, `nba_ff_team_2025` - Four factors team statistics
- `nba_games_2021`, `nba_games_2023`, `nba_games_2024`, `nba_games_2025` - Game results
- `nba_nuggets_shots` - Denver Nuggets shot location data

### NHL
- `avs_roster_2021`, `avs_roster_2022` - Colorado Avalanche roster data
- `avs_stats_2021`, `avs_stats_2022` - Colorado Avalanche player statistics
- `nhl_data_hockey_reference` - NHL data from Hockey Reference
- `nhl_team_stats_2021`, `nhl_team_stats_2022` - NHL team statistics

### English Premier League
- `epl_gk_stats_2022` through `epl_gk_stats_2025` - Goalkeeper statistics
- `epl_player_stats_2022` through `epl_player_stats_2025` - Player statistics
- `epl_team_stats`, `epl_team_stats_2023`, `epl_team_stats_2024`, `epl_team_stats_2025` - Team statistics

### NWSL
- `nwsl_player_stats`, `nwsl_player_stats_2023`, `nwsl_player_stats_2024` - Player statistics

### DraftKings
- `dk_edm_col` - Edmonton vs Colorado
- `dk_lac_dal` - LA Clippers vs Dallas
- `dk_mem_utah` - Memphis vs Utah
- `dk_nyr_car` - NY Rangers vs Carolina

## Development

### Exporting Data from ISAR

To export data from the R package ISAR to CSV format:

```bash
Rscript scripts/export_rda_to_csv.R
```

### Building the Package

```bash
python -m build
```

### Publishing to PyPI

```bash
python -m twine upload dist/*
```

## License

MIT

## Citation

If you use this data in your research, please cite:

> Elmore, R. (2025). *Introduction to Sports Analytics using Python*.
