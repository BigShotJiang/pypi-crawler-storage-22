"""
ISAPy: Data package for Introduction to Sports Analytics using Python.

This package provides datasets for the textbook "Introduction to Sports
Analytics using Python" by Ryan Elmore.

Usage
-----
    import isapy_data

    # Load a dataset
    df = isapy_data.load_data("masters")

    # List all available datasets
    isapy_data.list_datasets()

    # Get information about a dataset
    isapy_data.describe("masters")
"""

from importlib.resources import files
from pathlib import Path
from typing import Optional

import pandas as pd

__version__ = "0.1.0"
__author__ = "Ryan Elmore"

# Dataset descriptions
_DATASET_INFO = {
    "avs_roster_2021": "Colorado Avalanche roster data for 2020-21 season",
    "avs_roster_2022": "Colorado Avalanche roster data for 2021-22 season",
    "avs_stats_2021": "Colorado Avalanche player statistics for 2020-21 season",
    "avs_stats_2022": "Colorado Avalanche player statistics for 2021-22 season",
    "dk_edm_col": "DraftKings data for Edmonton vs Colorado game",
    "dk_lac_dal": "DraftKings data for LA Clippers vs Dallas game",
    "dk_mem_utah": "DraftKings data for Memphis vs Utah game",
    "dk_nyr_car": "DraftKings data for NY Rangers vs Carolina game",
    "epl_gk_stats_2022": "English Premier League goalkeeper statistics for 2021-22 season",
    "epl_gk_stats_2023": "English Premier League goalkeeper statistics for 2022-23 season",
    "epl_gk_stats_2024": "English Premier League goalkeeper statistics for 2023-24 season",
    "epl_gk_stats_2025": "English Premier League goalkeeper statistics for 2024-25 season",
    "epl_player_stats_2022": "English Premier League player statistics for 2021-22 season",
    "epl_player_stats_2023": "English Premier League player statistics for 2022-23 season",
    "epl_player_stats_2024": "English Premier League player statistics for 2023-24 season",
    "epl_player_stats_2025": "English Premier League player statistics for 2024-25 season",
    "epl_team_stats": "English Premier League team statistics",
    "epl_team_stats_2023": "English Premier League team statistics for 2022-23 season",
    "epl_team_stats_2024": "English Premier League team statistics for 2023-24 season",
    "epl_team_stats_2025": "English Premier League team statistics for 2024-25 season",
    "masters": "Masters Tournament golf data",
    "nba_adv_team_2021": "NBA advanced team statistics for 2020-21 season",
    "nba_adv_team_2023": "NBA advanced team statistics for 2022-23 season",
    "nba_adv_team_2024": "NBA advanced team statistics for 2023-24 season",
    "nba_adv_team_2025": "NBA advanced team statistics for 2024-25 season",
    "nba_ff_team_2021": "NBA four factors team statistics for 2020-21 season",
    "nba_ff_team_2023": "NBA four factors team statistics for 2022-23 season",
    "nba_ff_team_2024": "NBA four factors team statistics for 2023-24 season",
    "nba_ff_team_2025": "NBA four factors team statistics for 2024-25 season",
    "nba_games_2021": "NBA game results for 2020-21 season",
    "nba_games_2023": "NBA game results for 2022-23 season",
    "nba_games_2024": "NBA game results for 2023-24 season",
    "nba_games_2025": "NBA game results for 2024-25 season",
    "nba_nuggets_shots": "Denver Nuggets shot location data",
    "nhl_data_hockey_reference": "NHL data from Hockey Reference",
    "nhl_team_stats_2021": "NHL team statistics for 2020-21 season",
    "nhl_team_stats_2022": "NHL team statistics for 2021-22 season",
    "nwsl_player_stats": "NWSL player statistics",
    "nwsl_player_stats_2023": "NWSL player statistics for 2023 season",
    "nwsl_player_stats_2024": "NWSL player statistics for 2024 season",
    "ow_golf_rankings": "Official World Golf Rankings data",
    "pga_tournaments": "PGA Tour tournament data",
}


def _get_data_path() -> Path:
    """Get the path to the data directory."""
    return files("isapy_data").joinpath("data")


def list_datasets() -> list[str]:
    """
    List all available datasets.

    Returns
    -------
    list[str]
        Names of all available datasets.

    Examples
    --------
    >>> import isapy_data
    >>> isapy_data.list_datasets()
    ['avs_roster_2021', 'avs_roster_2022', ...]
    """
    data_path = _get_data_path()
    datasets = []
    for f in data_path.iterdir():
        if f.name.endswith(".csv"):
            datasets.append(f.name.replace(".csv", ""))
    return sorted(datasets)


def load_data(name: str) -> pd.DataFrame:
    """
    Load a dataset by name.

    Parameters
    ----------
    name : str
        The name of the dataset to load (without file extension).

    Returns
    -------
    pd.DataFrame
        The requested dataset as a pandas DataFrame.

    Raises
    ------
    ValueError
        If the dataset name is not found.

    Examples
    --------
    >>> import isapy_data
    >>> masters = isapy_data.load_data("masters")
    >>> masters.head()
    """
    data_path = _get_data_path()
    file_path = data_path.joinpath(f"{name}.csv")

    if not file_path.is_file():
        available = list_datasets()
        if available:
            raise ValueError(
                f"Dataset '{name}' not found. Available datasets: {available}"
            )
        else:
            raise ValueError(
                f"Dataset '{name}' not found. No datasets are currently installed."
            )

    return pd.read_csv(file_path)


def describe(name: str) -> Optional[str]:
    """
    Get a description of a dataset.

    Parameters
    ----------
    name : str
        The name of the dataset.

    Returns
    -------
    str or None
        Description of the dataset, or None if not available.

    Examples
    --------
    >>> import isapy_data
    >>> isapy_data.describe("masters")
    'Masters Tournament golf data'
    """
    return _DATASET_INFO.get(name)


def info() -> None:
    """
    Print information about all available datasets.

    Examples
    --------
    >>> import isapy_data
    >>> isapy_data.info()
    """
    print("ISAPy: Data package for Introduction to Sports Analytics using Python")
    print("=" * 70)
    print(f"Version: {__version__}")
    print(f"Authors: {__author__}")
    print()
    print("Available datasets:")
    print("-" * 70)

    datasets = list_datasets()
    if not datasets:
        print("No datasets currently installed.")
        print("See the package documentation for instructions on adding data.")
        return

    for name in datasets:
        desc = describe(name) or "No description available"
        print(f"  {name}: {desc}")


__all__ = [
    "__version__",
    "list_datasets",
    "load_data",
    "describe",
    "info",
]
