class DummyToken:
    def __init__(self) -> None:
        self.token = None
