
Main Author
===========

hans-fritz-pommes

forked from: [xlcnd/isbnlib](https://github.com/xlcnd/isbnlib)

Because of no maintenace since 2023 I am maintaining this now for me.
Anyone who wants to use or improve it is welcome.
In case xlcnd will return, I will suggest all my changes to xlcnd/isbnlib
and delete this repo afterwards.