# ISNAD Skill Scanner - Implementation Plan

## Overview
CLI tool that scans agent skills for security issues before installation.

**Command:** `isnad-scan <path-to-skill>`
**Output:** Trust assessment + detailed findings

---

## Phase 1: MVP (Today)

### Core Features
1. **Input:** Path to skill directory or SKILL.md URL
2. **Scanning:**
   - Parse all files in skill directory
   - Check against pattern database
   - Aggregate findings
3. **Output:**
   - Trust level: SAFE / WARN / DANGER
   - List of findings with file:line references
   - Summary stats

### Pattern Categories

#### DANGER (immediate threats)
- Hidden URLs in HTML/MD comments
- Base64-encoded strings (potential obfuscation)
- `curl`, `wget`, `fetch` to unknown domains
- Credential patterns (`API_KEY`, `SECRET`, `TOKEN` + exfil)
- Shell command injection (`subprocess`, `exec`, `eval`)
- File system access outside skill directory

#### WARN (suspicious but not definitive)
- Network calls to any external domain
- File writes outside designated paths
- Environment variable access
- Dynamic code execution patterns

#### INFO (notable but likely fine)
- Dependencies with known CVEs
- Outdated package versions
- Missing security headers in web requests

### File Structure
```
isnad/scanner/
├── PLAN.md           # This file
├── pyproject.toml    # uv project config
├── src/
│   └── isnad_scan/
│       ├── __init__.py
│       ├── cli.py        # Entry point
│       ├── scanner.py    # Core scanning logic
│       ├── patterns.py   # Pattern definitions
│       ├── parsers.py    # File type parsers
│       └── report.py     # Output formatting
└── tests/
    ├── fixtures/         # Test skills (safe, malicious)
    └── test_scanner.py
```

### CLI Interface
```bash
# Scan local skill
isnad-scan ./skills/some-skill/

# Scan from URL
isnad-scan https://clawhub.com/skills/some-skill

# Output formats
isnad-scan ./skill --json
isnad-scan ./skill --verbose

# Exit codes
# 0 = SAFE
# 1 = WARN
# 2 = DANGER
# 3 = ERROR
```

---

## Phase 2: Registry Integration

### Features
- Inscribe scan results to ISNAD Registry
- Look up existing attestations before scanning
- Stake on scan results (auditor mode)

### Flow
```
1. isnad-scan ./skill --attest
2. Scanner runs, produces report
3. Report hash inscribed to Registry
4. Auditor stakes ISNAD on the attestation
5. Future scans check existing attestations first
```

---

## Phase 3: Distribution

### ClawHub Integration
- Pre-install hook: scan before `clawhub install`
- Badge system: "ISNAD Verified" for attested skills

### OpenClaw Integration
- Built-in skill scanning before loading
- Trust threshold configuration

---

## Patterns Database (Initial)

```python
DANGER_PATTERNS = [
    # Hidden URLs in comments
    (r'<!--.*?(https?://[^\s]+).*?-->', 'hidden_url_html'),
    (r'#.*?(https?://[^\s]+)', 'hidden_url_comment'),
    
    # Obfuscation
    (r'base64\.(b64decode|decode)', 'base64_decode'),
    (r'eval\s*\(', 'eval_usage'),
    (r'exec\s*\(', 'exec_usage'),
    
    # Data exfiltration
    (r'(curl|wget|fetch)\s+.*?(api_key|secret|token|password)', 'credential_exfil'),
    (r'requests\.(get|post).*?(api_key|secret|token)', 'credential_exfil'),
    
    # Shell injection
    (r'subprocess\.(run|call|Popen).*?shell\s*=\s*True', 'shell_injection'),
    (r'os\.system\s*\(', 'os_system'),
]

WARN_PATTERNS = [
    # Network access
    (r'requests\.(get|post|put|delete)', 'network_request'),
    (r'urllib\.request', 'network_request'),
    (r'aiohttp\.ClientSession', 'network_request'),
    
    # File system
    (r'open\s*\([^)]*["\']w', 'file_write'),
    (r'pathlib\.Path.*?write', 'file_write'),
    
    # Environment
    (r'os\.environ', 'env_access'),
    (r'getenv\s*\(', 'env_access'),
]
```

---

## Today's Tasks

1. [x] Create project structure
2. [x] Implement pattern database (15 DANGER, 10 WARN, 3 INFO patterns)
3. [x] Build file parsers (py, js, sh, md, html, yaml, json, toml)
4. [x] Create CLI with click + rich
5. [x] Write core scanner logic
6. [x] Add JSON output format
7. [x] Create test fixtures (malicious + safe)
8. [x] Test against real skills (clawdefender = SAFE ✓)
9. [x] Document usage (README.md)

---

## Success Criteria

- [x] Can scan a skill directory and produce report
- [x] Catches Zack Korman's hidden-curl-in-HTML demo ✓
- [x] Exit codes work for CI integration (0=safe, 1=warn, 2=danger)
- [x] JSON output for programmatic use
- [x] < 5 seconds for typical skill scan (< 1 second)

---

## Version 0.3.0 Features (Completed Feb 3, 2026)

### AST Analysis (Python)
- [x] Import aliasing detection (`from os import system as s`)
- [x] Variable assignment tracking (`x = eval`)
- [x] Call tracing through aliases
- [x] Dynamic code execution detection
- [x] Suspicious module imports (ctypes, pty)
- [x] subprocess shell=True detection through aliases

### CVE Database Integration
- [x] OSV.dev API integration (free, no API key)
- [x] requirements.txt, package.json, pyproject.toml parsing
- [x] Known vulnerability detection with severity
- [x] Network optional (--cve flag)

### JavaScript Analysis
- [x] Minified JS detection
- [x] Basic unminification for pattern detection
- [x] JS-specific dangerous patterns (40+ patterns)
- [x] Prototype pollution detection
- [x] DOM XSS sinks
- [x] Node.js child_process detection

### Binary File Scanning
- [x] .pyc file scanning
- [x] Embedded script detection
- [x] Private key detection
- [x] AWS credential detection
- [x] Image steganography indicators
- [x] Hidden data after image EOF markers

---

## Roadmap

### v0.4.0 — Enhanced Analysis
- [ ] Full JavaScript AST parsing (via esprima/acorn)
- [ ] TypeScript support
- [ ] Decompilation of .pyc to source (uncompyle6/pycdc)
- [ ] Go module scanning (go.mod/go.sum)
- [ ] Rust crate scanning (Cargo.toml/Cargo.lock)

### v0.5.0 — Registry Integration
- [ ] ISNAD Registry integration (inscribe scan attestations)
- [ ] Stake on scan results (auditor mode)
- [ ] Look up existing attestations before scanning
- [ ] ClawHub pre-install hook

### v0.6.0 — Advanced Detection
- [ ] Custom encoding detection (beyond base64/hex)
- [ ] Control flow analysis for data exfiltration
- [ ] Taint tracking (trace user input to dangerous sinks)
- [ ] Machine learning-based anomaly detection

### Future
- [ ] Runtime behavior analysis (sandbox execution)
- [ ] Syscall monitoring during skill execution
- [ ] Network traffic analysis
- [ ] Differential scanning (detect changes between versions)
