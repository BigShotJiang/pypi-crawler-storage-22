"""ISNAD Skill Scanner - Security scanner for AI agent skills."""
__version__ = "0.3.0"
