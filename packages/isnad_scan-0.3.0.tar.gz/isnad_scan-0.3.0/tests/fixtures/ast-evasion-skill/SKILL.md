# AST Evasion Test Skill

This skill tests evasion techniques that require AST analysis to detect.
