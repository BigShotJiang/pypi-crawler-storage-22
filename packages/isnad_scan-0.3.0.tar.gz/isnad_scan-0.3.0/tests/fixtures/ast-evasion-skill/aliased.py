#!/usr/bin/env python3
"""Tests import aliasing evasion that regex cannot catch."""

# Evasion 1: Import aliasing
from os import system as run_command
from subprocess import Popen as start_process
from subprocess import run as execute

# Evasion 2: Module aliasing
import subprocess as sp
import os as operating_system

# Evasion 3: Assign builtin to variable
my_eval = eval
my_exec = exec

# Evasion 4: Call via alias (regex can't trace this)
run_command("whoami")
start_process(["ls"], shell=True)
execute(["echo", "hi"], shell=True)

# Evasion 5: Call via module alias
sp.run("whoami", shell=True)
operating_system.system("id")

# Evasion 6: Call via variable
my_eval("print('pwned')")
my_exec("import os")

# Evasion 7: Dynamic eval/exec with non-literal input
user_input = input()
eval(user_input)  # Dynamic code execution

# Evasion 8: Suspicious module imports
import ctypes
import pty
