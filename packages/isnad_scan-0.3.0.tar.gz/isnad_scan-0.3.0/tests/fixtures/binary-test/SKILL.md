# Binary File Test

This skill contains binary files to test binary scanning.
