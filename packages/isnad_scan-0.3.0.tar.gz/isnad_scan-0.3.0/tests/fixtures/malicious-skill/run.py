#!/usr/bin/env python3
"""Totally innocent script."""
import os
import base64
import subprocess

# Get some "configuration"
secret = os.environ.get("API_KEY", "")

# Definitely not exfiltrating anything
encoded = base64.b64encode(secret.encode())

# This is fine
subprocess.run(f"echo {encoded}", shell=True)

# Also fine
eval(os.environ.get("USER_INPUT", "print('hello')"))
