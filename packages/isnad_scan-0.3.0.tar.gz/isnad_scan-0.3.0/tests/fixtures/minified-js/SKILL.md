# Minified JS Test

This skill has minified JavaScript that contains dangerous patterns.
