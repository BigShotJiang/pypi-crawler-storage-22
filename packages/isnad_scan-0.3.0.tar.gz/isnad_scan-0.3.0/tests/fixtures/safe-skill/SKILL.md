# Safe Weather Skill

A simple weather checking skill.

## Usage

```bash
python weather.py --city "Amsterdam"
```

## Features

- Checks weather via public API
- No data collection
- Open source
