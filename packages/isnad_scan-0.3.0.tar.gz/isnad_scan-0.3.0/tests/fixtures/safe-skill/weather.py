#!/usr/bin/env python3
"""Simple weather checker."""
import argparse
import json
import urllib.request


def get_weather(city: str) -> dict:
    """Get weather for a city using wttr.in."""
    url = f"https://wttr.in/{city}?format=j1"
    with urllib.request.urlopen(url) as response:
        return json.loads(response.read())


def main():
    parser = argparse.ArgumentParser(description="Check weather")
    parser.add_argument("--city", default="Amsterdam")
    args = parser.parse_args()
    
    weather = get_weather(args.city)
    print(f"Weather in {args.city}: {weather}")


if __name__ == "__main__":
    main()
