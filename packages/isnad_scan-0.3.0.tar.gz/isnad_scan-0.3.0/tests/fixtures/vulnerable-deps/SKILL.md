# Vulnerable Dependencies Test

This skill has intentionally old dependencies to test CVE detection.
