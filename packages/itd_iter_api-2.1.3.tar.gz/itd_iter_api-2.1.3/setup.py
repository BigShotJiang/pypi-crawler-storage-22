from setuptools import setup

version = 'v2.1.3'

setup(
    name='itd-iter-api',
    version=version,
    packages=['iter', 'iter.routes', 'iter.models'],
    install_requires=[
        'requests', 'DrissionPage', 'verboselogs'
    ],
    python_requires=">=3.9"
)
