Iterative Ensemble Smoother
===========================

[![License: GPL v3](https://img.shields.io/badge/License-GPLv3-blue.svg)](https://github.com/equinor/iterative_ensemble_smoother/blob/main/COPYING)
[![Stars](https://img.shields.io/github/stars/equinor/iterative_ensemble_smoother.svg?style=social&label=Star&maxAge=2592000)](https://github.com/equinor/iterative_ensemble_smoother/stargazers)
[![Python](https://img.shields.io/pypi/pyversions/iterative_ensemble_smoother.svg)](https://pypi.org/pypi/iterative_ensemble_smoother)
[![PyPI](https://img.shields.io/pypi/v/iterative_ensemble_smoother.svg)](https://pypi.org/pypi/iterative_ensemble_smoother)
[![Downloads](https://static.pepy.tech/badge/iterative_ensemble_smoother)](https://pepy.tech/project/iterative_ensemble_smoother)
[![Build Status](https://github.com/equinor/iterative_ensemble_smoother/actions/workflows/upload_to_pypi.yml/badge.svg)](https://github.com/equinor/iterative_ensemble_smoother/actions/workflows/main.yml)
[![Precommit: enabled](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit)](https://github.com/pre-commit/pre-commit)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)
[![Mypy](https://www.mypy-lang.org/static/mypy_badge.svg)](https://mypy-lang.org/)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)
[![docs](https://readthedocs.org/projects/iterative_ensemble_smoother/badge/?version=latest&style=plastic)](https://iterative-ensemble-smoother.readthedocs.io/)

## About

**iterative_ensemble_smoother** is a Python library for **data assimilation and history matching** using ensemble-based methods. It implements efficient algorithms particularly effective for problems with a large number of parameters (e.g., millions) and relatively few realizations (e.g., hundreds).

The package provides two main algorithms:

- **ESMDA** (Ensemble Smoother with Multiple Data Assimilation) - A non-iterative method with multiple data assimilation steps, described in [Emerick & Reynolds 2013](https://doi.org/10.1016/j.cageo.2012.03.011)
- **SIES** (Subspace Iterative Ensemble Smoother) - An iterative Gauss-Newton method described in [Evensen et al. 2019](https://www.frontiersin.org/articles/10.3389/fams.2019.00047/full)

The package also supports two methods of localization: correlation-based (`AdaptiveESMDA`) and distance-based (`DistanceESMDA`).

## Installation

**iterative_ensemble_smoother** is on PyPi and can be installed using pip:

```text
pip install iterative_ensemble_smoother
```

If you want to do development, then run:

```text
git clone https://github.com/equinor/iterative_ensemble_smoother.git
cd iterative_ensemble_smoother
<create environment>
pip install --editable '.[doc,dev]'
```

## Usage

**iterative_ensemble_smoother** mainly implements the two classes `SIES` and `ESMDA`.
Check out the examples section to see how to use them.

## Building the documentation

```bash
apt install pandoc # Pandoc is required to build the documentation.
pip install .[doc]
sphinx-build -c docs/source/ -b html docs/source/ docs/build/html/
```

## Releasing a new version

- Create a tag, e.g. `git tag -a v1.0.0 -m "A short note" cf2c87270d3` locally on the commit.
- Push the tag, e.g. `git push upstream v1.0.0`.
- Create a release on the GitHub GUI.
