# src/top_academy_api/auth.py

from .exceptions import TopAcademyAuthError
from .client import TopAcademyClient
from .config import APP_KEY

class AuthManager:
    """Менеджер авторизации"""
    def __init__(self, client: TopAcademyClient):
        self._client = client
        self.token: str | None = None

    async def login(self, username: str, password: str):
        payload = {
            "username": username,
            "password": password,
            "application_key": APP_KEY
        }
        try:
            data = await self._client._request("POST", "/auth/login", json=payload)
        except Exception as e:
            raise TopAcademyAuthError(f"Ошибка авторизации: {e}")

        token = data.get("access_token")
        if not token:
            raise TopAcademyAuthError("Не получили access_token")
        self.token = token

        # обновляем хедеры клиента
        self._client._client.headers.update({"Authorization": f"Bearer {token}"})

    async def logout(self):
        if not self.token:
            return
        await self._client._request("POST", "/auth/logout")
        self.token = None
