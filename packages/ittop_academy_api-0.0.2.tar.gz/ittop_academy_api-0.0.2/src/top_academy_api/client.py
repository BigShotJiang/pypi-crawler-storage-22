import httpx

from . import config

from .auth import AuthManager
from .endpoints.user import UserEndpoints
from .endpoints.schedule import ScheduleEndpoints
from .endpoints.metrics import MetricsEndpoints
from .endpoints.rating import RatingEndpoints
from .endpoints.homework import HomeworkEndpoints
from .exceptions import TopAcademyError


class TopAcademyClient:
    def __init__(self, base_url=config.BASE_URL, timeout=config.TIMEOUT):
        self.base_url = base_url
        self.timeout = timeout
        self._client: httpx.AsyncClient | None = None

        # endpoints
        self.user: UserEndpoints | None = None
        self.schedule: ScheduleEndpoints | None = None
        self.metrics: MetricsEndpoints | None = None
        self.rating: RatingEndpoints | None = None
        self.homework: HomeworkEndpoints | None = None

    async def __aenter__(self):
        self._client = httpx.AsyncClient(base_url=self.base_url, timeout=self.timeout)
        self.auth = AuthManager(self)

        # инициализация endpoints
        self.user = UserEndpoints(self)
        self.schedule = ScheduleEndpoints(self)
        self.metrics = MetricsEndpoints(self)
        self.rating = RatingEndpoints(self)
        self.homework = HomeworkEndpoints(self)
        return self

    async def __aexit__(self, exc_type, exc, tb):
        await self._client.aclose()

    async def _request(self, method: str, endpoint: str, *, params=None, json=None) -> dict:
        if not self._client:
            raise TopAcademyError("Client not initialized. Use 'async with TopAcademyClient()'")

        response = await self._client.request(method, endpoint, params=params, json=json)
        response.raise_for_status()
        return response.json()
