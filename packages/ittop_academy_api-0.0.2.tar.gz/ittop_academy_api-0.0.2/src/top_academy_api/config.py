# src/top_academy_api/config.py

BASE_URL = "https://msapi.top-academy.ru/api/v2"
APP_KEY = "6a56a5df2667e65aab73ce76d1dd737f7d1faef9c52e8b8c55ac75f565d8e8a6"

USER_AGENT = "Mozilla/5.0 (Python SDK; TopAcademyBot)"
REFERER = "https://journal.top-academy.ru/"
ORIGIN = "https://journal.top-academy.ru/"
TIMEOUT = 15.0
