from top_academy_api.models.homework import HomeworkCounters


class HomeworkEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_homework_counters(self) -> HomeworkCounters:
        data = await self._client._request("GET", "/count/homework")
        return HomeworkCounters.model_validate(data)