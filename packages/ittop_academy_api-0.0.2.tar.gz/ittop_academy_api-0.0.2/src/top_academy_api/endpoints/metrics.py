from src.top_academy_api.models.metrics import AverageGrade, AttendanceMetrics


class MetricsEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client


    async def get_future_exams(self) -> UserFutureExams:
        data = await self._client._request("GET", "/dashboard/info/future-exams")
        return UserFutureExams.model_validate(data)

    async def get_attendance(self) -> AttendanceMetrics:
        data = await self._client._request("GET", "/dashboard/chart/attendance")
        return AttendanceMetrics.model_validate(data)

    async def get_average_grade(self) -> AverageGrade:
        data = await self._client._request("GET", "/dashboard/chart/average-progress")
        return AverageGrade.model_validate(data)