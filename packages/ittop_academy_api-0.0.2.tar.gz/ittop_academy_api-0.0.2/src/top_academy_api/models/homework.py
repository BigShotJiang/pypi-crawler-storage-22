from pydantic import BaseModel

class HomeworkCounter(BaseModel):
    type: str
    count: int

class HomeworkCounters(BaseModel):
    counters: list[HomeworkCounter]
