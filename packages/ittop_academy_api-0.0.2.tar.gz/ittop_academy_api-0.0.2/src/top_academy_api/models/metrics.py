from pydantic import BaseModel

class AttendanceMetrics(BaseModel):
    present: int
    absent: int
    late: int

class AverageGrade(BaseModel):
    value: float
