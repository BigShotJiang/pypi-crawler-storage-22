from pydantic import BaseModel
from typing import List

class RatingEntry(BaseModel):
    student_name: str
    grade: float

class GroupRating(BaseModel):
    entries: List[RatingEntry]

class StreamRating(BaseModel):
    entries: List[RatingEntry]
