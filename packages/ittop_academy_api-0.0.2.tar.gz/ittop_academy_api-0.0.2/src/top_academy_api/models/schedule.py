from pydantic import BaseModel


class ScheduleMonth(BaseModel):
    schedule: dict

class ScheduleDay(BaseModel):
    schedule: dict