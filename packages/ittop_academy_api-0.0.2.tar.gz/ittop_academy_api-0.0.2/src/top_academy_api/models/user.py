from pydantic import BaseModel, Field
from typing import List, Optional

class GamingPoint(BaseModel):
    type_id: int = Field(alias="new_gaming_point_types__id")
    points: int

class UserInfo(BaseModel):
    full_name: str
    age: int
    group_name: str
    stream_name: str
    birthday: str
    gaming_points: List[GamingPoint]

