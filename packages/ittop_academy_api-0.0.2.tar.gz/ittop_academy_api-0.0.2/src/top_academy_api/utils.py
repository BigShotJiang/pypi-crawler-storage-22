# src/top_academy_api/utils.py
from datetime import datetime

def validate_date(date_str: str):
    """Проверяет формат даты YYYY-MM-DD"""
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
    except ValueError:
        raise ValueError(f"Неправильный формат даты: {date_str}. Используйте YYYY-MM-DD")
