from typing import List, Optional
from pydantic import BaseModel

class HomeworkCounter(BaseModel):
    type: str
    count: int

class HomeworkCounters(BaseModel):
    counters: list[HomeworkCounter]

class HomeworkStudentInfo(BaseModel):
    id: int
    filename: Optional[str]
    file_path: Optional[str]
    tmp_file: Optional[str]
    mark: Optional[int]
    creation_time: Optional[str]
    stud_answer: Optional[str]
    auto_mark: bool


class HomeworkItem(BaseModel):
    id: int
    id_spec: int
    id_teach: int
    id_group: int
    fio_teach: str
    theme: str
    completion_time: str
    creation_time: str
    overdue_time: Optional[str]
    filename: Optional[str]
    file_path: Optional[str]
    comment: Optional[str]
    name_spec: str
    status: int
    common_status: Optional[int]
    homework_stud: Optional[HomeworkStudentInfo]
    homework_comment: Optional[str]
    cover_image: Optional[str]


class HomeworkList(BaseModel):
    items: List[HomeworkItem]

class HomeworkUploadResponse(BaseModel):
    id: int
    filename: Optional[str]
    file_path: Optional[str]
    tmp_file: Optional[str]
    mark: Optional[int]
    creation_time: str
    stud_answer: Optional[str]
    auto_mark: bool


class HomeworkEvaluationResponse(BaseModel):
    id: int
    id_dom_zad: int
    id_stud: int
    mark: int
    comment: str
    tags: List[str]
