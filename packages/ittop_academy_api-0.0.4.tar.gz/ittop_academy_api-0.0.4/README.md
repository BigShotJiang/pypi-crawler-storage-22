# top-academy-api

Неофициальный Python SDK для API Top Academy.

## Локальный запуск без установки

Проект использует `src/` layout. Для запуска скриптов вида `python tests/main.py`
из корня репозитория добавлен `sitecustomize.py`, который автоматически
подключает `src` в `PYTHONPATH`.

## Установка

```bash
pip install -e .
```

После установки импорт работает стандартно:

```python
from top_academy_api import TopAcademyClient
```
