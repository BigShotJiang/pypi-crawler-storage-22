import asyncio
import logging
from pathlib import Path

from top_academy_api import TopAcademyClient

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s | %(levelname)s | %(message)s",
)

logger = logging.getLogger("top_academy_api_debug")


async def main():
    async with TopAcademyClient(logger=logger) as api:
        # Авторизация
        await api.auth.login(
            username="YOUR_LOGIN",
            password="YOUR_PASSWORD",
        )

        # ID домашнего задания (берётся из списка домашек)
        homework_id = 12345

        # Путь к файлу
        # Поддерживается только https/http формат
        file_path = Path("docs/solution.pdf")

        if not file_path.exists():
            print(f"File not found: {file_path}")
            return

        # Создание и отправка домашки с файлом
        response = await api.homework.create_homework(
            id_=homework_id,
            file_path=str(file_path),
            answer_text="Прикрепляю решение в PDF.",
            spent_hours="01",
            spent_minutes="30",
        )

        print("Homework uploaded successfully")
        print(response)


if __name__ == "__main__":
    asyncio.run(main())
