import asyncio
import logging
from typing import List

from top_academy_api import TopAcademyClient

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s | %(levelname)s | %(message)s",
)

logger = logging.getLogger("top_academy_api_debug")


async def main():
    async with TopAcademyClient(logger=logger) as api:
        # Авторизация
        await api.auth.login(
            username="YOUR_LOGIN",
            password="YOUR_PASSWORD",
        )

        # Будущие экзамены
        exams = await api.metrics.get_future_exams()
        print(exams)

        # Посещаемость
        attendance: List = await api.metrics.get_attendance()
        print(attendance)

        # Средний балл
        average_grade: List = await api.metrics.get_average_grade()
        print(average_grade)

if __name__ == "__main__":
    asyncio.run(main())
