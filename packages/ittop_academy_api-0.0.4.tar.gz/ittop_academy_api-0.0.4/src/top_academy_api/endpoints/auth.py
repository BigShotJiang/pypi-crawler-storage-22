from ..exceptions import TopAcademyAuthError
from ..models.auth import AuthLogin, AuthLogout


class AuthEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def login(self, app_key: str, username: str, password: str) -> AuthLogin:

        payload = {
            "application_key": app_key,
            "id_city": None,
            "username": username,
            "password": password
        }

        try:
            data = await self._client._request("POST", "/auth/login", json_=payload)
        except:

            raise TopAcademyAuthError("")

        model: AuthLogin = AuthLogin.model_validate(data)



        # обновляем хедеры клиента
        self._client._client.headers.update({"Authorization": f"Bearer {model.access_token}"})

        return model

    async def logout(self) -> None:

        await self._client._request("POST", "/auth/logout")
