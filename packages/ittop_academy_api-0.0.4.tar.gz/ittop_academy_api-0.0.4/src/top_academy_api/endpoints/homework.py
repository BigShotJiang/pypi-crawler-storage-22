import json
from pathlib import Path
from typing import List, Optional

from ..models.homework import (
    HomeworkList,
    HomeworkItem,
    HomeworkCounters,
    HomeworkUploadResponse,
    HomeworkEvaluationResponse,
)


class HomeworkEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_counters(self) -> HomeworkCounters:
        data = await self._client._request("GET", "/count/homework")
        return HomeworkCounters.model_validate(data)

    async def get_info(self, id_: int) -> HomeworkItem:
        data = await self._client._request(
            "GET",
            "/homework/evaluation/operations/get",
            params={"id": id_},
        )
        return HomeworkItem.model_validate(data)

    async def has_material(self, id_: int) -> bool:
        data = await self._client._request(
            "GET",
            "/homework/operations/has-material",
            json={"id": id_},
        )
        return bool(data)

    async def list_homeworks(
        self,
        page_start: int = 1,
        status: int = 0,
        type_: int = 0,
        group_id: Optional[int] = None,
    ) -> HomeworkList:

        items: List[HomeworkItem] = []

        for page in range(page_start, 11):
            params = {
                "page": page,
                "status": status,
                "type": type_,
                "group_id": group_id,
            }

            data = await self._client._request(
                "GET",
                "/homework/operations/list",
                params=params,
            )

            if not data:
                break

            page_items = [HomeworkItem.model_validate(i) for i in data]
            items.extend(page_items)

            # если вернулось меньше 10 — дальше страниц нет
            if len(data) < 10:
                break

        return HomeworkList(items=items)


    async def create_homework(
        self,
        id_: int,
        file_path: Optional[str] = None,
        answer_text: Optional[str] = None,
        spent_hours: str = "00",
        spent_minutes: str = "00",
    ) -> HomeworkUploadResponse:

        files = {}
        data = {
            "id": str(id_),
            "answerText": answer_text or "",
            "spentTimeHour": spent_hours,
            "spentTimeMin": spent_minutes,
        }

        if file_path:
            file = Path(file_path)
            files["file"] = (file.name, file.open("rb"))

        response = await self._client._client.post(
            "/homework/operations/create",
            data=data,
            files=files if files else None,
        )

        response.raise_for_status()
        return HomeworkUploadResponse.model_validate(response.json())

    async def rate_homework(
        self,
        id_dom_zad: int,
        mark: int,
        comment: str = "",
        tags: Optional[List[str]] = None,
    ) -> HomeworkEvaluationResponse:

        payload = {
            "EvaluationHomeworkForm": json.dumps({
                "id": None,
                "idDomZad": id_dom_zad,
                "idStud": None,
                "mark": mark,
                "comment": comment,
                "tags": tags or [],
            })
        }

        response = await self._client._client.post(
            "/homework/evaluation/operations/save",
            data=payload,
        )

        response.raise_for_status()
        return HomeworkEvaluationResponse.model_validate(response.json())
