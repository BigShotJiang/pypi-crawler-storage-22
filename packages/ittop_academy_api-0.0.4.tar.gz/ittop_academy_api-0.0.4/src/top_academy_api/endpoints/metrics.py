from typing import Any, List

from ..models.metrics import AttendanceMetrics, AverageGradesMetrics


class MetricsEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_future_exams(self) -> Any:
        return await self._client._request("GET", "/dashboard/info/future-exams")

    async def get_attendance(self) -> AttendanceMetrics:
        data = await self._client._request("GET", "/dashboard/chart/attendance")
        return AttendanceMetrics.model_validate(data)

    async def get_average_grade(self) -> AverageGradesMetrics:
        data = await self._client._request("GET", "/dashboard/chart/average-progress")
        return AverageGradesMetrics.model_validate(data)
