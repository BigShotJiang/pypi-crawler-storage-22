from ..models.rating import GroupRating


class RatingEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_group_leaders(self) -> GroupRating:
        data = await self._client._request("GET", "/dashboard/progress/leader-group")
        return GroupRating.model_validate(data)
