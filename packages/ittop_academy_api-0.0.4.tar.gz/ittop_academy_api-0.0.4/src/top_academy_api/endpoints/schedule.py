from ..models.schedule import ScheduleDay, ScheduleMonth


class ScheduleEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_schedule_month(self, date: str) -> ScheduleMonth:
        data = await self._client._request("GET", "/schedule/operations/get-month", params={"date_filter": date})
        return ScheduleMonth.model_validate(data)

    async def get_schedule_day(self, date: str) -> ScheduleDay:
        data = await self._client._request("GET", "/schedule/operations/get-by-date", params={"date_filter": date})
        return ScheduleDay.model_validate(data)
