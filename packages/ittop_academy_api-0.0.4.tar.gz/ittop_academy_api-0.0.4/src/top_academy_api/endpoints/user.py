from ..models.user import UserInfo


class UserEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_info(self) -> UserInfo:
        data = await self._client._request("GET", "/settings/user-info")
        return UserInfo.model_validate(data)
