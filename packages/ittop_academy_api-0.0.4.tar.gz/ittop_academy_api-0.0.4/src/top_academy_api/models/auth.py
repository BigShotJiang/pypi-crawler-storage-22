from pydantic import BaseModel, Field


class CityData(BaseModel):
    id_city: int
    name: str

class AuthLogin(BaseModel):

    access_token: str = Field(
        description="JWT токен доступа. Срок жизни - 6 часов",
        examples=["eyJ0eXAiOiJKV1QiLCJhbGc..."]
    )
    refresh_token: str = Field(
        description="JWT токен обновления. Срок жизни - 30 дней",
        examples=["eyJ0eXAiOiJKV1QiLCJhbGc..."]
    )
    expires_in_refresh: int = Field(
        description="Unix timestamp истечения refresh_token",
        examples=[1770993859]
    )
    expires_in_access: int = Field(
        description="Unix timestamp истечения access_token",
        examples=[1770993859]
    )
    city_data: CityData = Field(
        alias="city_data",
        description="Информация о городе, к которому привязан пользователь"
    )

class AuthLogout(BaseModel):
    pass
