from typing import List, Iterator

from pydantic import BaseModel, RootModel


class AttendanceItem(BaseModel):
    date: str
    points: int | None = None
    previous_points: int | None = None
    has_rasp: bool


class AttendanceMetrics(RootModel):
    root: List[AttendanceItem]

    def __iter__(self) -> Iterator[AttendanceItem]:
        return iter(self.root)

    def __getitem__(self, index) -> AttendanceItem:
        return self.root[index]

    def __len__(self) -> int:
        return len(self.root)

    def __str__(self) -> str:
        return str(self.root)


class AverageGradeItem(BaseModel):
    date: str
    points: int | None = None
    previous_points: int | None = None
    has_rasp: bool | None = None


class AverageGradesMetrics(RootModel):
    root: List[AverageGradeItem]

    def __iter__(self) -> Iterator[AverageGradeItem]:
        return iter(self.root)

    def __getitem__(self, index) -> AverageGradeItem:
        return self.root[index]

    def __len__(self) -> int:
        return len(self.root)

    def __str__(self) -> str:
        return str(self.root)

