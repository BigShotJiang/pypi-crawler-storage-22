from typing import List, Iterator

from pydantic import BaseModel, RootModel


class RatingEntry(BaseModel):
    amount: int | None
    id: int | None
    full_name: str | None
    photo_path: str | None
    position: int

class GroupRating(RootModel[List[RatingEntry]]):
    root: List[RatingEntry]

    def __iter__(self) -> Iterator[RatingEntry]:
        return iter(self.root)

    def __getitem__(self, index) -> RatingEntry:
        return self.root[index]

    def __len__(self) -> int:
        return len(self.root)

    def __str__(self) -> str:
        return str(self.root)

class StreamRating(RootModel[List[RatingEntry]]):
    root: List[RatingEntry]

    def __iter__(self) -> Iterator[RatingEntry]:
        return iter(self.root)

    def __getitem__(self, index) -> RatingEntry:
        return self.root[index]

    def __len__(self) -> int:
        return len(self.root)

    def __str__(self) -> str:
        return str(self.root)