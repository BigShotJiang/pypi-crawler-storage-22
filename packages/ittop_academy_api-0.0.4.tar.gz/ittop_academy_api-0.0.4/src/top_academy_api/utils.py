# src/top_academy_api/utils.py
from datetime import datetime

SENSITIVE_KEYS = {
    "password",
    "username",
    "access_token",
    "refresh_token",
    "authorization",
    "token",
}


def sanitize_data(data):
    """
    Рекурсивно маскирует чувствительные поля в dict/list.
    """
    if isinstance(data, dict):
        return {
            key: ("***MASKED***" if key.lower() in SENSITIVE_KEYS else sanitize_data(value))
            for key, value in data.items()
        }
    elif isinstance(data, list):
        return [sanitize_data(item) for item in data]
    else:
        return data


def validate_date(date_str: str):
    """Проверяет формат даты YYYY-MM-DD"""
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
    except ValueError:
        raise ValueError(f"Неправильный формат даты: {date_str}. Используйте YYYY-MM-DD")
