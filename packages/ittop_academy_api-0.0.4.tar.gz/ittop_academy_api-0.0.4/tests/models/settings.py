import os
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

from pydantic import SecretStr, Field

print(f"Current directory: {Path.cwd()}")
print(f".env exists: {Path('.env').exists()}")
print(f"Env vars: LOGIN={os.getenv('LOGIN', 'NOT FOUND')}")

class Settings(BaseSettings):

    login: SecretStr = Field(validation_alias='LOGIN')
    password: SecretStr = Field(validation_alias='PASSWORD')

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )