"""Compatibility package for running the project from source without installation."""

from pathlib import Path

__path__ = [str(Path(__file__).resolve().parent.parent / "src" / "top_academy_api")]

from .client import TopAcademyClient

__all__ = ["TopAcademyClient"]
