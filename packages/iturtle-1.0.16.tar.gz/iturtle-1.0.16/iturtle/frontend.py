"""
Information about the frontend package of the widgets.
"""

MODULE_NAME = "iturtle"
MODULE_VERSION = "^0.1.0"
