from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path
import typer

try:
    # Python 3.9+
    from importlib.resources import files as ir_files
except ImportError:
    ir_files = None  # type: ignore

app = typer.Typer(help="ivbox CLI - Framework sobre Flet")


def _template_project_dir() -> Path:
    """
    Devuelve la ruta real en disco a ivbox/templates/project.
    Funciona con paquete instalado (PyPI) y en modo editable.
    """
    if ir_files is None:
        raise RuntimeError("Python >= 3.9 requerido para usar templates con importlib.resources")

    # Ojo: "ivbox" aquí es el nombre del PAQUETE (carpeta ivbox/)
    template = ir_files("ivbox").joinpath("templates", "project")

    # importlib.resources devuelve un objeto traversable.
    # convertimos a Path real (debe existir en filesystem)
    try:
        return Path(template)
    except TypeError:
        # en algunos casos puede no ser Path directo
        return Path(str(template))


def _copytree(src: Path, dst: Path) -> None:
    if not src.exists():
        raise FileNotFoundError(f"No encuentro la plantilla: {src}")

    if dst.exists():
        raise FileExistsError(f"La carpeta '{dst.name}' ya existe en: {dst.parent}")

    shutil.copytree(src, dst)


def _run(cmd: list[str], cwd: Path | None = None) -> None:
    typer.echo(f"▶ Ejecutando: {' '.join(cmd)}")
    subprocess.run(cmd, cwd=str(cwd) if cwd else None, check=True)


@app.command()
def new(
    name: str = typer.Argument(..., help="Nombre del proyecto (carpeta a crear)."),
    install: bool = typer.Option(False, "--install", help="Instala dependencias tras crear el proyecto."),
):
    """
    Crea un nuevo proyecto ivbox copiando la plantilla incluida en el paquete.
    """
    target = Path.cwd() / name
    template_dir = _template_project_dir()

    typer.echo(f"Creando proyecto: {name}")
    _copytree(template_dir, target)
    typer.echo(f"✅ Proyecto creado en: {target}")

    if install:
        typer.echo("Instalando dependencias...")
        # Si tu plantilla trae pyproject.toml puedes instalar con pip desde la carpeta.
        # Si no, ajusta a requirements.txt.
        try:
            _run([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"], cwd=target)
        except FileNotFoundError:
            # fallback: instala dependencias mínimas
            _run([sys.executable, "-m", "pip", "install", "flet"], cwd=target)
            # si quieres instalar ivbox-utils aquí:
            _run([sys.executable, "-m", "pip", "install", "ivbox-utils[flet]"], cwd=target)


@app.command()
def create(
    kind: str = typer.Argument(..., help="Tipo: view|middleware|component"),
    name: str = typer.Argument(..., help="Nombre del recurso"),
):
    """Crea recursos: view, middleware, component, etc."""
    typer.echo(f"Creando {kind}: {name}")
    # TODO: aquí irán tus generadores reales


def main():
    app()


if __name__ == "__main__":
    main()