"""iwa.plugins.olas package."""

from iwa.plugins.olas.plugin import OlasPlugin

__all__ = ["OlasPlugin"]
