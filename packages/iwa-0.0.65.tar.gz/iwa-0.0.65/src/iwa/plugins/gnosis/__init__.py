"""iwa.plugins.gnosis package."""

from iwa.plugins.gnosis.plugin import GnosisPlugin

__all__ = ["GnosisPlugin"]
