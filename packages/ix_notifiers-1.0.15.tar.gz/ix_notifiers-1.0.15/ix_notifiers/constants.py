#!/usr/bin/env python3
# -*- coding: utf-8 -*-
""" Constants declarations """

# These get overwritten at build time. See build.sh
VERSION = '1.0.15'
BUILD = '2328034270'
NAME = 'ix-notifiers'
