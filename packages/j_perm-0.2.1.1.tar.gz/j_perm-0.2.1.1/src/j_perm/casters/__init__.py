from ._bool import cast_bool
from ._float import cast_float
from ._int import cast_int
from ._str import cast_str
