"""Model definitions for JabsVision."""
