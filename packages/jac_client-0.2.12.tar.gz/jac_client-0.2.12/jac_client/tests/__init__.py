"""Tests for jac-client package."""
