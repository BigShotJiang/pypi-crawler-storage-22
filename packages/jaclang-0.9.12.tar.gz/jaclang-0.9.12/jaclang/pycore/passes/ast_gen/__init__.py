"""Common helpers for AST generation passes."""

from .base_ast_gen_pass import BaseAstGenPass

__all__ = ["BaseAstGenPass"]
