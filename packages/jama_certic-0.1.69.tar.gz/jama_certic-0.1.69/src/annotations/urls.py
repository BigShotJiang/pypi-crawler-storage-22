urlpatterns = []
app_name = "annotations"
