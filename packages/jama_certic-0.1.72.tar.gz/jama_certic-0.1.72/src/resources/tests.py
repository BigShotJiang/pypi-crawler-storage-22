from django.test import TestCase


class ServiceTestCase(TestCase):
    def setUp(self):
        pass
