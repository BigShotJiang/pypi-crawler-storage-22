from django.apps import AppConfig


class RpcConfig(AppConfig):
    name = "rpc"
