# API Reference

Python API documentation for jamb's public modules.

```{toctree}
:maxdepth: 2

core
config
storage
cli
pytest_plugin
matrix
publish
yaml_io
```
