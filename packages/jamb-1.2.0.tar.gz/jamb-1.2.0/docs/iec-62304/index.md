# IEC 62304 Guide

This section provides an educational overview of IEC 62304 and how jamb supports compliance with its requirements.

```{toctree}
:maxdepth: 2

overview
safety-classifications
lifecycle
traceability
risk-management
```
