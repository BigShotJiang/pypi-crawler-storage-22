"""CLI commands for jamb."""

from jamb.cli.commands import cli

__all__ = ["cli"]
