"""Configuration handling for jamb."""

from jamb.config.loader import JambConfig, load_config

__all__ = ["load_config", "JambConfig"]
