"""Streaming LMM association runner.

Two-pass disk streaming: (1) SNP statistics, (2) association per chunk.
Never allocates the full genotype matrix.
"""

import contextlib
import gc
import time
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np
from loguru import logger

from jamma.core.memory import estimate_lmm_streaming_memory
from jamma.core.progress import progress_iterator
from jamma.core.snp_filter import compute_snp_filter_mask
from jamma.core.threading import blas_threads
from jamma.io.plink import (
    get_plink_metadata,
    stream_genotype_chunks,
    validate_genotype_values,
)
from jamma.lmm.chunk import _compute_chunk_size
from jamma.lmm.io import IncrementalAssocWriter
from jamma.lmm.likelihood_jax import (
    batch_calc_score_stats,
    batch_calc_wald_stats,
    batch_compute_iab,
    batch_compute_uab,
    calc_lrt_pvalue_jax,
    golden_section_optimize_lambda_mle,
)
from jamma.lmm.prepare import (
    _build_covariate_matrix,
    _compute_null_model,
    _eigendecompose_or_reuse,
    _grid_optimize_lambda_batched,
    _select_jax_device,
)
from jamma.lmm.results import _concat_jax_accumulators, _yield_chunk_results
from jamma.lmm.stats import AssocResult
from jamma.utils.logging import log_rss_memory


class _LazySnpMeta:
    """Lazy view over PLINK metadata arrays, avoiding per-SNP dict materialization.

    Instead of building a list of n_snps dicts at construction time, this wrapper
    holds references to the underlying metadata arrays and materializes a single
    dict on each __getitem__ access. This saves O(n_snps) dict + string objects.

    Compatible with all snp_info consumers that use integer indexing (snp_info[idx]).
    """

    __slots__ = ("_chr", "_rs", "_pos", "_a1", "_a0")

    def __init__(self, meta: dict) -> None:
        self._chr = meta["chromosome"]
        self._rs = meta["sid"]
        self._pos = meta["bp_position"]
        self._a1 = meta["allele_1"]
        self._a0 = meta["allele_2"]

    def __len__(self) -> int:
        return len(self._rs)

    def __getitem__(self, i: int) -> dict:
        return {
            "chr": str(self._chr[i]),
            "rs": self._rs[i],
            "pos": int(self._pos[i]),
            "a1": self._a1[i],
            "a0": self._a0[i],
        }


_ACCUM_KEYS = {
    1: ("lambdas", "logls", "betas", "ses", "pwalds"),
    2: ("lambdas_mle", "p_lrts"),
    3: ("betas", "ses", "p_scores"),
    4: (
        "lambdas",
        "logls",
        "betas",
        "ses",
        "pwalds",
        "lambdas_mle",
        "p_lrts",
        "p_scores",
    ),
}

_FIRST_ARRAY_KEY = {1: "lambdas", 2: "lambdas_mle", 3: "betas", 4: "lambdas"}

_TEST_TYPE_MAP = {1: "wald", 2: "lrt", 3: "score", 4: "all"}


def _init_accumulators(lmm_mode: int) -> dict[str, list]:
    """Create empty accumulator dict for the given mode."""
    return {k: [] for k in _ACCUM_KEYS[lmm_mode]}


def _append_chunk_results(
    lmm_mode: int,
    accum: dict[str, list],
    actual_len: int,
    needs_padding: bool,
    local_vars: dict,
) -> None:
    """Strip padding from JAX arrays and append to accumulators."""
    _var_map = {
        "lambdas": "best_lambdas",
        "logls": "best_logls",
        "betas": "betas",
        "ses": "ses",
        "pwalds": "p_walds",
        "lambdas_mle": "best_lambdas_mle",
        "p_lrts": "p_lrts",
        "p_scores": "p_scores",
    }
    first_key = _FIRST_ARRAY_KEY[lmm_mode]
    first_var = _var_map[first_key]
    arr = local_vars[first_var]
    slice_len = actual_len if needs_padding else len(arr)
    for key in _ACCUM_KEYS[lmm_mode]:
        accum[key].append(local_vars[_var_map[key]][:slice_len])


def run_lmm_association_streaming(
    bed_path: Path,
    phenotypes: np.ndarray,
    kinship: np.ndarray | None = None,
    snp_info: list | None = None,
    covariates: np.ndarray | None = None,
    eigenvalues: np.ndarray | None = None,
    eigenvectors: np.ndarray | None = None,
    maf_threshold: float = 0.01,
    miss_threshold: float = 0.05,
    l_min: float = 1e-5,
    l_max: float = 1e5,
    n_grid: int = 50,
    n_refine: int = 10,
    chunk_size: int = 10_000,
    use_gpu: bool = False,
    check_memory: bool = True,
    show_progress: bool = True,
    output_path: Path | None = None,
    lmm_mode: int = 1,
    snps_indices: np.ndarray | None = None,
    hwe_threshold: float = 0.0,
    validate_genotypes: bool = True,
) -> list[AssocResult]:
    """Run LMM association tests by streaming genotypes from disk.

    Reads genotypes per-chunk, never allocating the full genotype matrix.
    Two-pass: (1) SNP statistics for filtering, (2) association per chunk.

    Args:
        bed_path: PLINK file prefix (without .bed/.bim/.fam extension).
        phenotypes: Phenotype vector (n_samples,).
        kinship: Kinship matrix (n_samples, n_samples), or None when
            pre-computed eigenvalues and eigenvectors are provided.
        snp_info: List of SNP metadata dicts, or None to build from PLINK.
        covariates: Covariate matrix (n_samples, n_cvt) or None for intercept-only.
        eigenvalues: Pre-computed eigenvalues (sorted ascending) or None.
        eigenvectors: Pre-computed eigenvectors or None.
        maf_threshold: Minimum MAF for SNP inclusion.
        miss_threshold: Maximum missing rate for SNP inclusion.
        l_min: Minimum lambda for optimization.
        l_max: Maximum lambda for optimization.
        n_grid: Grid search resolution for lambda bracketing.
        n_refine: Golden section iterations for lambda refinement.
        chunk_size: Number of SNPs per disk chunk (default: 10,000).
        use_gpu: Whether to use GPU acceleration.
        check_memory: Check available memory before workflow.
        show_progress: Show progress bars and GEMMA-style logging.
        output_path: Path for incremental result writing, or None for in-memory.
        lmm_mode: Test type: 1=Wald, 2=LRT, 3=Score, 4=All.
        snps_indices: Pre-resolved column indices for -snps restriction, or None.
        hwe_threshold: HWE p-value threshold; SNPs with p < threshold are
            removed. 0.0 disables HWE filtering (default).
        validate_genotypes: Check for unexpected genotype values during pass-1
            (default True).

    Returns:
        List of AssocResult (empty if output_path is set -- results on disk).

    Raises:
        MemoryError: If check_memory=True and insufficient memory.
        ValueError: If only one of eigenvalues/eigenvectors is provided.
    """
    start_time = time.perf_counter()

    if (eigenvalues is None) != (eigenvectors is None):
        raise ValueError(
            "Must provide both eigenvalues and eigenvectors, or neither. "
            f"Got eigenvalues={eigenvalues is not None}, "
            f"eigenvectors={eigenvectors is not None}"
        )

    if kinship is None and eigenvalues is None:
        raise ValueError(
            "Either kinship or pre-computed eigendecomposition (eigenvalues + "
            "eigenvectors) must be provided"
        )

    if lmm_mode not in (1, 2, 3, 4):
        raise ValueError(
            f"lmm_mode must be 1 (Wald), 2 (LRT), 3 (Score), or 4 (All), got {lmm_mode}"
        )

    meta = get_plink_metadata(bed_path)
    n_samples_total = meta["n_samples"]
    n_snps = meta["n_snps"]

    if snp_info is None:
        snp_info = _LazySnpMeta(meta)

    valid_mask = ~np.isnan(phenotypes) & (phenotypes != -9.0)
    if covariates is not None:
        valid_covariate = np.all(~np.isnan(covariates), axis=1)
        valid_mask = valid_mask & valid_covariate
    n_valid = int(np.sum(valid_mask))
    if not np.all(valid_mask):
        phenotypes = phenotypes[valid_mask]
        if kinship is not None:
            kinship = kinship[np.ix_(valid_mask, valid_mask)]
        if covariates is not None:
            covariates = covariates[valid_mask, :]

    n_samples = phenotypes.shape[0]

    # Always log memory estimate (useful even without hard check)
    est = estimate_lmm_streaming_memory(n_samples, n_snps, chunk_size=chunk_size)
    logger.info(
        f"LMM streaming memory: estimated peak {est.total_peak_gb:.1f}GB, "
        f"available {est.available_gb:.1f}GB"
    )
    if check_memory and not est.sufficient:
        raise MemoryError(
            f"Insufficient memory for streaming LMM with {n_samples:,} samples "
            f"x {n_snps:,} SNPs (chunk_size={chunk_size:,}).\n"
            f"Peak: {est.total_peak_gb:.1f}GB, "
            f"Available: {est.available_gb:.1f}GB\n"
            f"Breakdown: kinship={est.kinship_gb:.1f}GB, "
            f"eigenvectors={est.eigenvectors_gb:.1f}GB, "
            f"eigendecomp_workspace={est.eigendecomp_workspace_gb:.1f}GB"
        )

    if show_progress:
        logger.info("Performing LMM Association Test (streaming)")
        logger.info(f"  Total individuals: {n_samples_total:,}")
        logger.info(f"  Analyzed individuals: {n_valid:,}")
        logger.info(f"  Total SNPs: {n_snps:,}")
        logger.info(f"  Lambda range: [{l_min:.2e}, {l_max:.2e}]")

    device = _select_jax_device(use_gpu)

    # === PASS 1: SNP statistics (without loading all genotypes) ===
    t_io_start = time.perf_counter()
    all_means = np.zeros(n_snps, dtype=np.float64)
    all_miss_counts = np.zeros(n_snps, dtype=np.int32)
    all_vars = np.zeros(n_snps, dtype=np.float64)

    # HWE genotype count accumulators (only when threshold > 0)
    if hwe_threshold > 0:
        all_n_aa = np.zeros(n_snps, dtype=np.int64)
        all_n_ab = np.zeros(n_snps, dtype=np.int64)
        all_n_bb = np.zeros(n_snps, dtype=np.int64)

    # Genotype validation accumulator
    n_unexpected_total = 0

    stats_iterator = stream_genotype_chunks(
        bed_path, chunk_size=chunk_size, dtype=np.float32, show_progress=False
    )
    if show_progress:
        n_chunks = (n_snps + chunk_size - 1) // chunk_size
        stats_iterator = progress_iterator(
            stats_iterator, total=n_chunks, desc="Computing SNP statistics"
        )

    for chunk, start, end in stats_iterator:
        # Apply sample filtering
        if not np.all(valid_mask):
            chunk = chunk[valid_mask, :]

        # Compute stats for this chunk
        chunk_miss_counts = np.sum(np.isnan(chunk), axis=0)
        with np.errstate(invalid="ignore"):
            chunk_means = np.nanmean(chunk, axis=0)
            chunk_vars = np.nanvar(chunk, axis=0)
        chunk_means = np.nan_to_num(chunk_means, nan=0.0)
        chunk_vars = np.nan_to_num(chunk_vars, nan=0.0)

        all_means[start:end] = chunk_means
        all_miss_counts[start:end] = chunk_miss_counts
        all_vars[start:end] = chunk_vars

        # Accumulate HWE genotype counts (no extra disk pass)
        if hwe_threshold > 0:
            valid_geno = ~np.isnan(chunk)
            all_n_aa[start:end] += np.sum((chunk == 0) & valid_geno, axis=0)
            all_n_ab[start:end] += np.sum((chunk == 1) & valid_geno, axis=0)
            all_n_bb[start:end] += np.sum((chunk == 2) & valid_geno, axis=0)

        if validate_genotypes:
            n_unexpected_total += validate_genotype_values(chunk)

    if validate_genotypes and n_unexpected_total > 0:
        logger.warning(
            f"Genotype validation: {n_unexpected_total} values outside "
            f"expected range {{0, 1, 2, NaN}}"
        )

    t_io_end = time.perf_counter()

    # === SNP statistics: filtering + stats construction ===
    t_snp_start = time.perf_counter()
    snp_mask, allele_freqs, _mafs = compute_snp_filter_mask(
        all_means, all_miss_counts, all_vars, n_samples, maf_threshold, miss_threshold
    )
    del all_vars  # Only used by compute_snp_filter_mask

    # Apply SNP list restriction (if -snps provided)
    if snps_indices is not None:
        from jamma.core.snp_filter import apply_snp_list_mask

        apply_snp_list_mask(snp_mask, snps_indices, n_snps, "SNP list filter")

    # Apply HWE filter (if -hwe threshold > 0)
    if hwe_threshold > 0:
        from jamma.core.snp_filter import compute_hwe_pvalues

        hwe_pvalues = compute_hwe_pvalues(all_n_aa, all_n_ab, all_n_bb)
        hwe_pass = hwe_pvalues >= hwe_threshold
        n_hwe_fail = int(np.sum(~hwe_pass & snp_mask))
        snp_mask &= hwe_pass
        logger.info(f"HWE filter: {n_hwe_fail} SNPs removed (p < {hwe_threshold})")

    snp_indices = np.where(snp_mask)[0]
    n_filtered = len(snp_indices)

    if show_progress:
        logger.info(f"  Analyzed SNPs: {n_filtered:,}")

    if output_path is None and n_filtered > 100_000:
        logger.warning(
            f"In-memory mode with {n_filtered:,} SNPs. Results will accumulate "
            f"in memory. Provide output_path to stream results to disk."
        )

    if n_filtered == 0:
        if output_path is not None:
            with IncrementalAssocWriter(
                output_path, test_type=_TEST_TYPE_MAP[lmm_mode]
            ):
                pass  # Context manager writes header, no data rows
        if show_progress:
            elapsed = time.perf_counter() - start_time
            logger.info(
                f"LMM Association completed in {elapsed:.2f}s (no SNPs passed filter)"
            )
        return []

    snp_stats = list(
        zip(
            allele_freqs[snp_indices],
            all_miss_counts[snp_indices].astype(int),
            strict=True,
        )
    )
    del all_miss_counts, allele_freqs
    filtered_means = all_means[snp_indices]
    del all_means
    if hwe_threshold > 0:
        del all_n_aa, all_n_ab, all_n_bb

    t_snp_end = time.perf_counter()

    # === Eigendecomp + setup ===
    t_eigen_start = time.perf_counter()
    eigenvalues_np, U = _eigendecompose_or_reuse(
        kinship,
        eigenvalues,
        eigenvectors,
        show_progress,
        "lmm_streaming",
        check_memory=check_memory,
    )
    if kinship is not None:
        del kinship
    gc.collect()

    W, n_cvt = _build_covariate_matrix(covariates, n_samples)

    # Prepare rotated matrices (numpy BLAS matmuls)
    with blas_threads():
        UtW = U.T @ W
        Uty = U.T @ phenotypes

    logl_H0, lambda_null_mle, Hi_eval_null_jax = _compute_null_model(
        lmm_mode, eigenvalues_np, UtW, Uty, n_cvt, device, show_progress
    )

    # Device-resident shared arrays - placed on device ONCE before chunk loop
    eigenvalues = jax.device_put(eigenvalues_np, device)
    UtW_jax = jax.device_put(UtW, device)
    Uty_jax = jax.device_put(Uty, device)

    jax_chunk_size = _compute_chunk_size(n_samples, n_filtered, n_grid, n_cvt)
    t_eigen_end = time.perf_counter()

    # Timing accumulators for per-chunk phases
    t_rotation_total = 0.0
    t_jax_compute_total = 0.0
    t_result_write_total = 0.0

    # === PASS 2: Association ===
    # Track results for in-memory mode (when output_path is None)
    all_results: list[AssocResult] = []

    with contextlib.ExitStack() as stack:
        writer = None
        if output_path is not None:
            writer = stack.enter_context(
                IncrementalAssocWriter(output_path, test_type=_TEST_TYPE_MAP[lmm_mode])
            )
        assoc_iterator = stream_genotype_chunks(
            bed_path, chunk_size=chunk_size, dtype=np.float64, show_progress=False
        )
        if show_progress:
            n_chunks = (n_snps + chunk_size - 1) // chunk_size
            assoc_iterator = progress_iterator(
                assoc_iterator, total=n_chunks, desc="Running LMM association"
            )

        def _prepare_jax_chunk(
            start: int, geno: np.ndarray, total: int
        ) -> tuple[np.ndarray, int, bool]:
            """Prepare a JAX chunk for device transfer (CPU work)."""
            end = min(start + jax_chunk_size, total)
            actual_len = end - start

            geno_jax_chunk = geno[:, start:end]

            needs_pad = actual_len < jax_chunk_size
            if needs_pad:
                pad_width = jax_chunk_size - actual_len
                geno_jax_chunk = np.pad(
                    geno_jax_chunk, ((0, 0), (0, pad_width)), mode="constant"
                )

            with blas_threads():
                UtG_chunk = np.ascontiguousarray(U.T @ geno_jax_chunk)
            return UtG_chunk, actual_len, needs_pad

        for chunk, file_start, file_end in assoc_iterator:
            # Apply sample filtering
            if not np.all(valid_mask):
                chunk = chunk[valid_mask, :]

            # Binary search for filtered SNPs in this chunk: O(log n) vs O(n)
            # snp_indices is sorted (from np.where), so searchsorted is valid
            left = np.searchsorted(snp_indices, file_start, side="left")
            right = np.searchsorted(snp_indices, file_end, side="left")

            if left == right:
                continue

            chunk_filtered_local_idx = np.arange(left, right)
            chunk_filtered_col_idx_arr = snp_indices[left:right] - file_start
            geno_subset = chunk[:, chunk_filtered_col_idx_arr]

            # Vectorized imputation: broadcast filtered_means to match geno_subset shape
            filtered_means_broadcast = filtered_means[chunk_filtered_local_idx].reshape(
                1, -1
            )
            missing_mask = np.isnan(geno_subset)
            geno_subset = np.where(missing_mask, filtered_means_broadcast, geno_subset)

            n_subset = geno_subset.shape[1]
            jax_starts = list(range(0, n_subset, jax_chunk_size))

            # Dict-based accumulators for this file chunk
            accum: dict[str, list] = _init_accumulators(lmm_mode)

            # Prepare first JAX chunk
            t_rot_start = time.perf_counter()
            UtG_np, actual_jax_len, needs_padding = _prepare_jax_chunk(
                jax_starts[0], geno_subset, n_subset
            )
            t_rot_end = time.perf_counter()
            t_rotation_total += t_rot_end - t_rot_start
            UtG_jax = jax.device_put(UtG_np, device)
            del UtG_np

            for i, _jax_start in enumerate(jax_starts):
                current_actual_len = actual_jax_len
                current_needs_padding = needs_padding
                current_UtG = UtG_jax

                # Start async transfer of next JAX chunk while computing current
                if i + 1 < len(jax_starts):
                    t_rot_start = time.perf_counter()
                    UtG_np, actual_jax_len, needs_padding = _prepare_jax_chunk(
                        jax_starts[i + 1], geno_subset, n_subset
                    )
                    t_rot_end = time.perf_counter()
                    t_rotation_total += t_rot_end - t_rot_start
                    UtG_jax = jax.device_put(UtG_np, device)
                    del UtG_np

                # --- JAX compute timing ---
                t_jax_start = time.perf_counter()

                # Batch compute Uab (shared across all modes)
                Uab_batch = batch_compute_uab(n_cvt, UtW_jax, Uty_jax, current_UtG)

                if lmm_mode == 1:  # Wald (existing, unchanged)
                    Iab_batch = batch_compute_iab(n_cvt, Uab_batch)
                    best_lambdas, best_logls = _grid_optimize_lambda_batched(
                        n_cvt,
                        eigenvalues,
                        Uab_batch,
                        Iab_batch,
                        l_min,
                        l_max,
                        n_grid,
                        n_refine,
                    )
                    betas, ses, p_walds = batch_calc_wald_stats(
                        n_cvt, best_lambdas, eigenvalues, Uab_batch, n_samples
                    )
                    p_walds.block_until_ready()

                elif lmm_mode == 3:  # Score
                    betas, ses, p_scores = batch_calc_score_stats(
                        n_cvt, Hi_eval_null_jax, Uab_batch, n_samples
                    )
                    p_scores.block_until_ready()

                elif lmm_mode == 2:  # LRT
                    best_lambdas_mle, best_logls_mle = (
                        golden_section_optimize_lambda_mle(
                            n_cvt,
                            eigenvalues,
                            Uab_batch,
                            l_min=l_min,
                            l_max=l_max,
                            n_grid=n_grid,
                            n_iter=max(n_refine, 20),
                        )
                    )
                    p_lrts = jax.vmap(calc_lrt_pvalue_jax)(
                        best_logls_mle, jnp.full_like(best_logls_mle, logl_H0)
                    )
                    p_lrts.block_until_ready()

                elif lmm_mode == 4:  # All tests
                    # Score test (cheapest, no optimization)
                    _, _, p_scores = batch_calc_score_stats(
                        n_cvt, Hi_eval_null_jax, Uab_batch, n_samples
                    )

                    # MLE optimization for LRT
                    best_lambdas_mle, best_logls_mle = (
                        golden_section_optimize_lambda_mle(
                            n_cvt,
                            eigenvalues,
                            Uab_batch,
                            l_min=l_min,
                            l_max=l_max,
                            n_grid=n_grid,
                            n_iter=max(n_refine, 20),
                        )
                    )
                    p_lrts = jax.vmap(calc_lrt_pvalue_jax)(
                        best_logls_mle, jnp.full_like(best_logls_mle, logl_H0)
                    )

                    # REML optimization for Wald
                    Iab_batch = batch_compute_iab(n_cvt, Uab_batch)
                    best_lambdas, best_logls = _grid_optimize_lambda_batched(
                        n_cvt,
                        eigenvalues,
                        Uab_batch,
                        Iab_batch,
                        l_min,
                        l_max,
                        n_grid,
                        n_refine,
                    )
                    betas, ses, p_walds = batch_calc_wald_stats(
                        n_cvt, best_lambdas, eigenvalues, Uab_batch, n_samples
                    )
                    # Block all async results for accurate timing
                    p_scores.block_until_ready()
                    p_lrts.block_until_ready()
                    p_walds.block_until_ready()

                t_jax_end = time.perf_counter()
                t_jax_compute_total += t_jax_end - t_jax_start

                # Strip padding and append to dict-based accumulators
                _append_chunk_results(
                    lmm_mode,
                    accum,
                    current_actual_len,
                    current_needs_padding,
                    locals(),
                )

            # Concatenate, build results, write/accumulate
            if any(accum.values()):
                t_write_start = time.perf_counter()
                arrays = _concat_jax_accumulators(lmm_mode, accum)
                for result in _yield_chunk_results(
                    lmm_mode,
                    chunk_filtered_local_idx,
                    snp_indices,
                    snp_stats,
                    snp_info,
                    arrays,
                ):
                    if writer is not None:
                        writer.write(result)
                    else:
                        all_results.append(result)
                del arrays, accum
                t_write_end = time.perf_counter()
                t_result_write_total += t_write_end - t_write_start

        if show_progress:
            log_rss_memory("lmm_streaming", "after_association")

            elapsed = time.perf_counter() - start_time
            t_io = t_io_end - t_io_start
            t_snp = t_snp_end - t_snp_start
            t_eigen = t_eigen_end - t_eigen_start
            accounted = (
                t_io
                + t_snp
                + t_eigen
                + t_rotation_total
                + t_jax_compute_total
                + t_result_write_total
            )
            logger.info("Timing breakdown:")
            logger.info(f"  I/O read (pass 1):   {t_io:.2f}s")
            logger.info(f"  SNP statistics:      {t_snp:.2f}s")
            logger.info(f"  Eigendecomp+setup:   {t_eigen:.2f}s")
            logger.info(f"  UT@G rotation:       {t_rotation_total:.2f}s")
            logger.info(f"  JAX compute:         {t_jax_compute_total:.2f}s")
            logger.info(f"  Result write:        {t_result_write_total:.2f}s")
            logger.info("  ----")
            logger.info(f"  Accounted:           {accounted:.2f}s")
            logger.info(f"  Total:               {elapsed:.2f}s")

        del eigenvalues, UtW_jax, Uty_jax

        if writer is not None and show_progress:
            logger.info(f"Wrote {writer.count:,} results to {output_path}")

    jax.clear_caches()

    if show_progress:
        elapsed = time.perf_counter() - start_time
        logger.info(f"LMM Association completed in {elapsed:.2f}s")

    return [] if output_path is not None else all_results
