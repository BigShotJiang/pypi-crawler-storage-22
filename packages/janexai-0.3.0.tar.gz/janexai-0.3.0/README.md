# JanexAI CLI

AI-powered code security and quality analysis from your terminal.

## Installation

```bash
pip install janexai
```

## Quick Start

```bash
# Scan a public repository
janex scan https://github.com/user/repo

# Or use owner/repo format
janex scan user/repo

# Save report to file
janex scan user/repo -o report.json
```

## Authentication

For private repositories or higher rate limits, authenticate with your API token:

```bash
janex login --token YOUR_API_TOKEN
```

Get your token at [janex.ai/settings](https://janex.ai/settings)

## Commands

### `janex scan`

Scan a repository for security and quality issues.

```bash
janex scan <repo> [OPTIONS]

Arguments:
  repo              GitHub repo URL or owner/repo format

Options:
  -o, --output      Save report to JSON file
  --no-claude       Skip Claude AI analysis (faster)
  -v, --verbose     Verbose output
```

### `janex login`

Authenticate with your API token.

```bash
janex login --token YOUR_TOKEN
```

### `janex config`

Configure CLI settings.

```bash
# Show current config
janex config --show

# Set custom API URL (for self-hosted)
janex config --api-url https://your-server.com
```

### `janex version`

Show CLI version.

## Environment Variables

- `JANEX_API_TOKEN` - API token (alternative to `janex login`)
- `JANEX_API_URL` - Custom API URL (for self-hosted instances)

## Example Output

```
╭──────────────── JanexAI ─────────────────╮
│ Scanning repository: vercel/next.js      │
╰──────────────────────────────────────────╯

✓ Repository ingested (2,847 files)
✓ Analysis complete!

        Scores
┏━━━━━━━━━━┳━━━━━━━━┓
┃ Category ┃  Score ┃
┡━━━━━━━━━━╇━━━━━━━━┩
│ Security │ 85/100 │
│ Quality  │ 78/100 │
└──────────┴────────┘

    Security Findings
┏━━━━━━━━━━┳━━━━━━━┓
┃ Severity ┃ Count ┃
┡━━━━━━━━━━╇━━━━━━━┩
│ Medium   │     3 │
│ Low      │    12 │
└──────────┴───────┘

✓ No critical security issues found

╭─────────── Architecture Summary ───────────╮
│ Next.js app with App Router architecture.  │
│ Uses React Server Components with proper   │
│ data fetching patterns...                  │
╰────────────────────────────────────────────╯
```

## License

MIT
