"""JanexAI CLI - AI-powered code security and quality analysis."""

__version__ = "0.3.0"
