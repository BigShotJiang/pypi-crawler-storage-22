# JAO Auction Data API Package

This package provides a small, focused Python client for the JAO Auction Data API, plus helpers to parse auctions, bids, and curtailments and plot a professional bid stack chart.

## Features
- Authenticated REST client for `getcorridors`, `gethorizons`, `getauctions`, `getbids`, `getcurtailment`
- Parsing utilities for auction IDs and corridor codes
- Offered-capacity detection in auction/bid payloads
- Bid stack visualization (cumulative step curve)
- Enum helpers for corridors, horizons, and curtailment reasons
- Curtailment stacked-bar visualization by reason

## Install
```bash
pip install jao-auction-api
```

## Quick Start
```python
from jao_auction_api import (
    JaoClient,
    load_env,
    extract_auction_ids,
    extract_corridor_codes,
    plot_bid_stack_step,
    plot_curtailment_stacked_bar,
    corridor_enum,
)

load_env()  # reads .env into environment variables if present
client = JaoClient()

auctions = client.get_auctions(
    corridor="FR-DE",
    fromdate="YYYY-MM-DD-HH:MM:SS",
    todate="YYYY-MM-DD-HH:MM:SS",
)
auction_ids = extract_auction_ids(auctions)

bids = client.get_bids(auction_ids[0])
fig, ax = plot_bid_stack_step(bids)

corridors = client.get_corridors()
corridor_codes = extract_corridor_codes(corridors)
Corridor = corridor_enum(corridor_codes)

curtailments = client.get_curtailment(
    corridor=Corridor.FR_DE.value,
    fromdate="YYYY-MM-DD-HH:MM:SS",
    todate="YYYY-MM-DD-HH:MM:SS",
)
fig2, ax2 = plot_curtailment_stacked_bar(curtailments)
```

## Environment
Set `JAO_API_KEY` in your environment or `.env` file.
