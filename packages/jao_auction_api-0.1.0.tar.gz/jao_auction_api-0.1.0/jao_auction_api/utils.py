"""Lightweight helpers for configuration and labels."""

from __future__ import annotations

from pathlib import Path
import os
import re
from typing import Dict


def load_env(path: str = ".env") -> Dict[str, str]:
    """Load key=value pairs from a .env file into environment variables.

    Existing environment variables are not overridden. Returns the values found.
    """
    env_path = Path(path)
    values: Dict[str, str] = {}
    if not env_path.exists():
        return values

    for raw in env_path.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, val = line.split("=", 1)
        key = key.strip()
        val = val.strip().strip("'").strip('"')
        values[key] = val
        os.environ.setdefault(key, val)
    return values


def humanize_label(name: str | None) -> str:
    """Convert snake_case or camelCase identifiers into human-friendly labels."""
    if name is None:
        return ""
    text = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", str(name))
    text = text.replace("_", " ")
    text = " ".join(text.split())
    return text.lower()
