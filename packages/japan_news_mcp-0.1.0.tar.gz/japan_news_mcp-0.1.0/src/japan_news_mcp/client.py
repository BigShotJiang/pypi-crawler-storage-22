"""RSS feed client for japan-news-mcp."""

from __future__ import annotations

import asyncio
from datetime import datetime
from typing import TYPE_CHECKING, Any

import feedparser  # type: ignore[import-untyped]
import httpx
from loguru import logger
from pydantic import HttpUrl

from japan_news_mcp.models import NewsArticle, NewsSource

if TYPE_CHECKING:
    from collections.abc import Sequence


# Default RSS sources
DEFAULT_SOURCES: dict[str, NewsSource] = {
    "yahoo_business": NewsSource(
        id="yahoo_business",
        name="Yahoo!ニュース ビジネス",
        url=HttpUrl("https://news.yahoo.co.jp/rss/topics/business.xml"),
        description="Yahoo! JAPAN ビジネスニュース",
        language="ja",
    ),
    "nhk_economy": NewsSource(
        id="nhk_economy",
        name="NHKニュース 経済",
        url=HttpUrl("https://www3.nhk.or.jp/rss/news/cat5.xml"),
        description="NHK 経済ニュース",
        language="ja",
    ),
    "reuters_jp": NewsSource(
        id="reuters_jp",
        name="Reuters Japan",
        url=HttpUrl("https://assets.wor.jp/rss/rdf/reuters/business.rdf"),
        description="ロイター経済ニュース",
        language="ja",
    ),
    "toyokeizai": NewsSource(
        id="toyokeizai",
        name="東洋経済オンライン",
        url=HttpUrl("https://toyokeizai.net/list/feed/rss"),
        description="東洋経済オンライン",
        language="ja",
    ),
}


class NewsClient:
    """Client for fetching and parsing RSS news feeds."""

    def __init__(self, timeout: float = 30.0) -> None:
        """Initialize the client.

        Args:
            timeout: HTTP request timeout in seconds.
        """
        self.timeout = timeout
        self._client: httpx.AsyncClient | None = None
        self._sources = DEFAULT_SOURCES.copy()

    async def _get_http_client(self) -> httpx.AsyncClient:
        """Get or create the HTTP client."""
        if self._client is None:
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(self.timeout),
                follow_redirects=True,
            )
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    def get_sources(self) -> list[NewsSource]:
        """Get all available news sources.

        Returns:
            List of NewsSource objects.
        """
        return list(self._sources.values())

    def get_source(self, source_id: str) -> NewsSource | None:
        """Get a specific news source by ID.

        Args:
            source_id: The source identifier.

        Returns:
            NewsSource if found, None otherwise.
        """
        return self._sources.get(source_id)

    async def fetch_feed(self, source: NewsSource) -> list[NewsArticle]:
        """Fetch and parse an RSS feed.

        Args:
            source: The news source to fetch.

        Returns:
            List of NewsArticle objects.
        """
        client = await self._get_http_client()

        try:
            logger.debug(f"Fetching feed from {source.name}: {source.url}")
            response = await client.get(str(source.url))
            response.raise_for_status()

            # Parse RSS feed
            feed = feedparser.parse(response.content)
            articles: list[NewsArticle] = []

            for entry in feed.entries:
                article = self._parse_entry(entry, source)
                if article:
                    articles.append(article)

            logger.info(f"Fetched {len(articles)} articles from {source.name}")
            return articles

        except httpx.HTTPError as e:
            logger.error(f"HTTP error fetching {source.name}: {e}")
            return []
        except Exception as e:
            logger.error(f"Error parsing {source.name}: {e}")
            return []

    def _parse_entry(self, entry: Any, source: NewsSource) -> NewsArticle | None:
        """Parse a feed entry into a NewsArticle.

        Args:
            entry: A feedparser entry.
            source: The source this entry came from.

        Returns:
            NewsArticle or None if parsing fails.
        """
        try:
            title = entry.get("title", "").strip()
            link = entry.get("link", "").strip()

            if not title or not link:
                return None

            # Parse published date
            published = None
            if hasattr(entry, "published_parsed") and entry.published_parsed:
                published = datetime(*entry.published_parsed[:6])
            elif hasattr(entry, "updated_parsed") and entry.updated_parsed:
                published = datetime(*entry.updated_parsed[:6])

            # Get summary/description
            summary = ""
            if hasattr(entry, "summary"):
                summary = entry.summary
            elif hasattr(entry, "description"):
                summary = entry.description

            # Clean up HTML in summary
            summary = self._clean_html(summary)

            # Get categories
            categories = []
            if hasattr(entry, "tags"):
                categories = [tag.term for tag in entry.tags if hasattr(tag, "term")]
            elif hasattr(entry, "category"):
                categories = [entry.category]

            # Get author
            author = None
            if hasattr(entry, "author"):
                author = entry.author
            elif hasattr(entry, "author_detail") and entry.author_detail:
                author = entry.author_detail.get("name")

            return NewsArticle(
                title=title,
                link=link,
                summary=summary,
                published=published,
                source_id=source.id,
                source_name=source.name,
                categories=categories,
                author=author,
            )

        except Exception as e:
            logger.warning(f"Failed to parse entry: {e}")
            return None

    def _clean_html(self, html: str) -> str:
        """Remove HTML tags from text.

        Args:
            html: HTML text.

        Returns:
            Plain text.
        """
        if not html:
            return ""

        try:
            from bs4 import BeautifulSoup

            soup = BeautifulSoup(html, "html.parser")
            return soup.get_text(separator=" ", strip=True)
        except Exception:
            # Fallback: simple regex
            import re

            text = re.sub(r"<[^>]+>", " ", html)
            return " ".join(text.split())

    async def fetch_all_feeds(self) -> list[NewsArticle]:
        """Fetch all configured RSS feeds.

        Returns:
            List of all articles from all sources.
        """
        tasks = [self.fetch_feed(source) for source in self._sources.values()]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        all_articles: list[NewsArticle] = []
        for result in results:
            if isinstance(result, list):
                all_articles.extend(result)
            else:
                logger.error(f"Feed fetch error: {result}")

        # Sort by published date (newest first)
        all_articles.sort(key=lambda a: a.published or datetime.min, reverse=True)

        return all_articles

    async def search(
        self,
        query: str,
        sources: Sequence[str] | None = None,
        limit: int = 20,
    ) -> list[NewsArticle]:
        """Search for articles matching a query.

        Args:
            query: Search query string (case-insensitive).
            sources: Optional list of source IDs to search. If None, searches all.
            limit: Maximum number of results.

        Returns:
            List of matching articles.
        """
        query_lower = query.lower()

        # Determine which sources to search
        if sources:
            source_list = [self._sources[sid] for sid in sources if sid in self._sources]
        else:
            source_list = list(self._sources.values())

        # Fetch feeds concurrently
        tasks = [self.fetch_feed(s) for s in source_list]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Filter matching articles
        matches: list[NewsArticle] = []
        for result in results:
            if isinstance(result, list):
                for article in result:
                    if self._matches_query(article, query_lower):
                        matches.append(article)

        # Sort by date and limit results
        matches.sort(key=lambda a: a.published or datetime.min, reverse=True)

        return matches[:limit]

    def _matches_query(self, article: NewsArticle, query_lower: str) -> bool:
        """Check if an article matches the search query.

        Args:
            article: The article to check.
            query_lower: Lowercase search query.

        Returns:
            True if article matches.
        """
        searchable_text = " ".join(
            [
                article.title.lower(),
                article.summary.lower(),
                " ".join(c.lower() for c in article.categories),
            ]
        )
        return query_lower in searchable_text

    async def get_headlines(
        self,
        source_id: str | None = None,
        limit: int = 10,
    ) -> list[NewsArticle]:
        """Get latest headlines.

        Args:
            source_id: Optional source ID to filter by.
            limit: Maximum number of headlines.

        Returns:
            List of latest articles.
        """
        if source_id:
            source = self._sources.get(source_id)
            if not source:
                return []
            articles = await self.fetch_feed(source)
        else:
            articles = await self.fetch_all_feeds()

        return articles[:limit]
