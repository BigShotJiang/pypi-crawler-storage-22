# japan-news-mcp

[![CI](https://github.com/ajtgjmdjp/japan-news-mcp/actions/workflows/ci.yml/badge.svg)](https://github.com/ajtgjmdjp/japan-news-mcp/actions/workflows/ci.yml)
[![PyPI version](https://badge.fury.io/py/japan-news-mcp.svg)](https://pypi.org/project/japan-news-mcp/)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: Apache-2.0](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)

MCP (Model Context Protocol) server for Japanese financial and business news RSS feeds.

## Features

- **4 RSS Sources**: Yahoo!ニュース ビジネス, NHKニュース 経済, Reuters Japan, 東洋経済オンライン
- **4 MCP Tools**: search_news, get_headlines, get_article_summary, list_sources
- **No API Key Required**: All feeds are publicly available RSS feeds
- **Fast & Async**: Built with `httpx` and `asyncio` for concurrent feed fetching

## Installation

```bash
pip install japan-news-mcp
```

Or with `uv`:

```bash
uv pip install japan-news-mcp
```

## CLI Usage

```bash
# List available sources
japan-news-mcp sources

# Get latest headlines
japan-news-mcp headlines --limit 10

# Search for news
japan-news-mcp search "株価" --limit 20

# Test RSS feed connections
japan-news-mcp test

# Start MCP server
japan-news-mcp serve
```

## MCP Server Configuration

Add to your Claude Desktop config (`claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "japan-news": {
      "command": "uvx",
      "args": ["japan-news-mcp", "serve"]
    }
  }
}
```

## Available Tools

### list_sources
List all configured RSS feed sources.

### search_news
Search for articles by keyword across all or specific sources.

Parameters:
- `query`: Search keyword (e.g., "経済", "株価")
- `sources`: Optional list of source IDs
- `limit`: Maximum results (default: 20)

### get_headlines
Get latest headlines from all or a specific source.

Parameters:
- `source_id`: Optional source ID
- `limit`: Maximum headlines (default: 10)

### get_article_summary
Get summary information for a specific article by URL.

## Sources

| ID | Name | URL |
|---|---|---|
| yahoo_business | Yahoo!ニュース ビジネス | https://news.yahoo.co.jp/rss/topics/business.xml |
| nhk_economy | NHKニュース 経済 | https://www3.nhk.or.jp/rss/news/cat5.xml |
| reuters_jp | Reuters Japan | https://assets.wor.jp/rss/rdf/reuters/business.rdf |
| toyokeizai | 東洋経済オンライン | https://toyokeizai.net/list/feed/rss |

## Data Attribution & Disclaimer

This tool aggregates publicly available RSS feeds. No full article text is scraped — only headlines, links, and RSS summary snippets are returned.

> **Disclaimer**: RSS content is copyrighted by its respective publishers.
> This tool reads publicly available RSS feeds only and does not scrape web pages.
> Respect each source's terms of service and copyright.

## License

Apache-2.0
