"""Japan News MCP - RSS feed reader for Japanese financial news."""

from japan_news_mcp.client import DEFAULT_SOURCES, NewsClient
from japan_news_mcp.models import HeadlinesResult, NewsArticle, NewsSource, SearchResult

__all__ = [
    "DEFAULT_SOURCES",
    "HeadlinesResult",
    "NewsArticle",
    "NewsClient",
    "NewsSource",
    "SearchResult",
]

__version__ = "0.1.1"
