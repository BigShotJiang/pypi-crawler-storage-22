"""CLI for japan-news-mcp."""

from __future__ import annotations

import asyncio
import json
import sys
from typing import Any

import click
from loguru import logger

from japan_news_mcp import __version__
from japan_news_mcp.client import NewsClient


@click.group()
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose logging")
def cli(verbose: bool) -> None:
    """Japan News MCP - RSS feed reader for Japanese financial news."""
    if verbose:
        logger.remove()
        logger.add(sys.stderr, level="DEBUG")
    else:
        logger.remove()
        logger.add(sys.stderr, level="WARNING")


@cli.command()
def version() -> None:
    """Show version information."""
    click.echo(f"japan-news-mcp {__version__}")


@cli.command()
@click.argument("query")
@click.option("--source", "-s", multiple=True, help="Source ID to search (can specify multiple)")
@click.option("--limit", "-l", default=20, help="Maximum results (default: 20)")
@click.option("--json-output", "-j", is_flag=True, help="Output as JSON")
def search(query: str, source: tuple[str, ...], limit: int, json_output: bool) -> None:
    """Search for news articles by keyword.

    Example: japan-news-mcp search "株価" --limit 10
    """

    async def _search() -> None:
        client = NewsClient()
        try:
            sources = list(source) if source else None
            articles = await client.search(query, sources=sources, limit=limit)

            if json_output:
                result: dict[str, Any] = {
                    "query": query,
                    "total_count": len(articles),
                    "articles": [a.to_dict() for a in articles],
                }
                click.echo(json.dumps(result, ensure_ascii=False, indent=2))
            else:
                click.echo(f"Search results for: {query}")
                click.echo(f"Found {len(articles)} articles\n")

                for i, article in enumerate(articles, 1):
                    if article.published:
                        published = article.published.strftime("%Y-%m-%d %H:%M")
                    else:
                        published = "Unknown"
                    click.echo(f"{i}. {article.title}")
                    click.echo(f"   Source: {article.source_name}")
                    click.echo(f"   Published: {published}")
                    click.echo(f"   Link: {article.link}")
                    if article.summary:
                        if len(article.summary) > 150:
                            summary = article.summary[:150] + "..."
                        else:
                            summary = article.summary
                        click.echo(f"   Summary: {summary}")
                    click.echo()
        finally:
            await client.close()

    asyncio.run(_search())


@cli.command()
@click.option("--source", "-s", help="Source ID (if not specified, shows all sources)")
@click.option("--limit", "-l", default=10, help="Maximum headlines (default: 10)")
@click.option("--json-output", "-j", is_flag=True, help="Output as JSON")
def headlines(source: str | None, limit: int, json_output: bool) -> None:
    """Get latest headlines.

    Example: japan-news-mcp headlines --source yahoo_business --limit 5
    """

    async def _headlines() -> None:
        client = NewsClient()
        try:
            articles = await client.get_headlines(source_id=source, limit=limit)

            if json_output:
                result: dict[str, Any] = {
                    "source_id": source or "all",
                    "total_count": len(articles),
                    "articles": [a.to_dict() for a in articles],
                }
                click.echo(json.dumps(result, ensure_ascii=False, indent=2))
            else:
                source_name = source or "All Sources"
                click.echo(f"Latest headlines from: {source_name}")
                click.echo(f"Showing {len(articles)} articles\n")

                for i, article in enumerate(articles, 1):
                    if article.published:
                        published = article.published.strftime("%Y-%m-%d %H:%M")
                    else:
                        published = "Unknown"
                    click.echo(f"{i}. [{article.source_name}] {article.title}")
                    click.echo(f"   {published}")
                    click.echo(f"   {article.link}")
                    click.echo()
        finally:
            await client.close()

    asyncio.run(_headlines())


@cli.command()
def sources() -> None:
    """List all available news sources."""
    client = NewsClient()
    sources_list = client.get_sources()

    click.echo("Available news sources:\n")
    for s in sources_list:
        click.echo(f"  {s.id}")
        click.echo(f"    Name: {s.name}")
        click.echo(f"    URL: {s.url}")
        click.echo(f"    Description: {s.description}")
        click.echo()


@cli.command()
def test() -> None:
    """Test connection to all RSS feeds."""

    async def _test() -> None:
        client = NewsClient()
        try:
            click.echo("Testing RSS feed connections...\n")

            all_ok = True
            for source in client.get_sources():
                click.echo(f"Testing {source.name}... ", nl=False)
                try:
                    articles = await client.fetch_feed(source)
                    if articles:
                        click.echo(click.style(f"OK ({len(articles)} articles)", fg="green"))
                    else:
                        click.echo(click.style("OK (0 articles)", fg="yellow"))
                except Exception as e:
                    click.echo(click.style(f"FAILED: {e}", fg="red"))
                    all_ok = False

            click.echo()
            if all_ok:
                click.echo(click.style("All feeds accessible!", fg="green"))
            else:
                click.echo(click.style("Some feeds failed. Check your connection.", fg="yellow"))
                sys.exit(1)
        finally:
            await client.close()

    asyncio.run(_test())


@cli.command()
@click.option("--transport", "-t", default="stdio", help="Transport type (stdio or sse)")
@click.option("--port", "-p", default=8000, help="Port for SSE transport (default: 8000)")
def serve(transport: str, port: int) -> None:
    """Start the MCP server.

    Example: japan-news-mcp serve
    """
    from japan_news_mcp.server import mcp

    if transport == "sse":
        mcp.run(transport="sse", port=port)
    else:
        mcp.run()


if __name__ == "__main__":
    cli()
