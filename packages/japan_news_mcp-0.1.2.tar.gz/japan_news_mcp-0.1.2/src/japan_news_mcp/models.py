"""Domain models for japan-news-mcp."""

from __future__ import annotations

from datetime import datetime  # noqa: TC003
from typing import Any

from pydantic import BaseModel, Field, HttpUrl


class NewsSource(BaseModel):
    """A news source/RSS feed.

    Attributes:
        id: Unique identifier for the source.
        name: Display name of the source.
        url: RSS feed URL.
        description: Brief description of the source.
        language: Language code (e.g., 'ja', 'en').
    """

    id: str
    name: str
    url: HttpUrl
    description: str = ""
    language: str = "ja"

    model_config = {"frozen": True}


class NewsArticle(BaseModel):
    """A news article from an RSS feed.

    Attributes:
        title: Article title.
        link: URL to the full article.
        summary: Brief summary or description.
        published: Publication datetime.
        source_id: ID of the source this article came from.
        source_name: Name of the source.
        categories: List of category tags.
        author: Author name if available.
    """

    title: str
    link: HttpUrl
    summary: str = ""
    published: datetime | None = None
    source_id: str
    source_name: str
    categories: list[str] = Field(default_factory=list)
    author: str | None = None

    model_config = {"frozen": True}

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "title": self.title,
            "link": str(self.link),
            "summary": self.summary,
            "published": self.published.isoformat() if self.published else None,
            "source_id": self.source_id,
            "source_name": self.source_name,
            "categories": self.categories,
            "author": self.author,
        }


class SearchResult(BaseModel):
    """Result of a news search.

    Attributes:
        query: The search query used.
        articles: List of matching articles.
        total_count: Total number of matches.
        sources_searched: List of source IDs that were searched.
    """

    query: str
    articles: list[NewsArticle] = Field(default_factory=list)
    total_count: int = 0
    sources_searched: list[str] = Field(default_factory=list)

    model_config = {"frozen": True}

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "query": self.query,
            "articles": [a.to_dict() for a in self.articles],
            "total_count": self.total_count,
            "sources_searched": self.sources_searched,
        }


class HeadlinesResult(BaseModel):
    """Result of a headlines request.

    Attributes:
        source_id: Source ID if specific source was requested.
        articles: List of headline articles.
        total_count: Total number of articles.
    """

    source_id: str | None = None
    articles: list[NewsArticle] = Field(default_factory=list)
    total_count: int = 0

    model_config = {"frozen": True}

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "source_id": self.source_id,
            "articles": [a.to_dict() for a in self.articles],
            "total_count": self.total_count,
        }
