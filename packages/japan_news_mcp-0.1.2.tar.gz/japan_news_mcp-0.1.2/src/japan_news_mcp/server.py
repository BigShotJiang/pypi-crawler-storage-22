"""MCP server exposing japan-news tools to LLMs via FastMCP.

This module defines the MCP (Model Context Protocol) server that allows
AI assistants like Claude to search and retrieve Japanese financial news
from multiple RSS feeds.

Usage with Claude Desktop (add to ``claude_desktop_config.json``)::

    {
      "mcpServers": {
        "japan-news": {
          "command": "uvx",
          "args": ["japan-news-mcp", "serve"]
        }
      }
    }
"""

from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING, Annotated, Any

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

from fastmcp import FastMCP
from pydantic import Field

from japan_news_mcp.client import NewsClient

# Lazily initialized client with lock for concurrent-safe access
_client: NewsClient | None = None
_client_lock = asyncio.Lock()


async def _get_client() -> NewsClient:
    """Return the shared NewsClient, creating it on first call."""
    global _client
    if _client is not None:
        return _client
    async with _client_lock:
        if _client is None:
            _client = NewsClient()
    return _client


@asynccontextmanager
async def _lifespan(server: FastMCP[dict[str, Any]]) -> AsyncIterator[dict[str, Any]]:
    """Manage NewsClient lifecycle."""
    global _client
    yield {}
    if _client is not None:
        await _client.close()
        _client = None


mcp = FastMCP(
    name="JapanNews",
    lifespan=_lifespan,
    instructions=(
        "Japan News MCP server provides tools for accessing Japanese financial "
        "and business news from multiple RSS feeds.\n\n"
        "Available sources:\n"
        "- Yahoo!ニュース ビジネス (yahoo_business)\n"
        "- NHKニュース 経済 (nhk_economy)\n"
        "- Reuters Japan (reuters_jp)\n"
        "- 東洋経済オンライン (toyokeizai)\n\n"
        "Key tools:\n"
        "- search_news: Search for news articles by keyword\n"
        "- get_headlines: Get latest headlines from all or specific sources\n"
        "- get_article_summary: Get a summary of a specific article\n"
        "- list_sources: List all available news sources\n\n"
        "All feeds are publicly available RSS feeds. No API key required."
    ),
)


@mcp.tool()
async def list_sources() -> list[dict[str, Any]]:
    """List all available news sources.

    Returns information about all configured RSS feed sources including
    their IDs, names, and descriptions.

    Returns:
        List of source information dictionaries.
    """
    client = await _get_client()
    sources = client.get_sources()

    return [
        {
            "id": s.id,
            "name": s.name,
            "url": str(s.url),
            "description": s.description,
            "language": s.language,
        }
        for s in sources
    ]


@mcp.tool()
async def search_news(
    query: Annotated[
        str,
        Field(
            description="Search query keyword (Japanese or English). Example: '株価' or 'economy'"
        ),
    ],
    sources: Annotated[
        list[str] | None,
        Field(
            description="Optional list of source IDs to search. If not provided, searches all. "
            "Available: yahoo_business, nhk_economy, reuters_jp, toyokeizai",
        ),
    ] = None,
    limit: Annotated[
        int,
        Field(description="Maximum number of results (default: 20)", ge=1, le=50),
    ] = 20,
) -> dict[str, Any]:
    """Search for news articles by keyword.

    Searches across all configured RSS feeds for articles matching the query.
    The search is case-insensitive and matches against titles, summaries,
    and categories.

    Args:
        query: Search keyword (e.g., '株式', '為替', 'GDP').
        sources: Optional list of source IDs to limit search scope.
        limit: Maximum number of articles to return.

    Returns:
        Dictionary containing query, total count, and list of matching articles.
    """
    if not query or not query.strip():
        return {
            "query": query,
            "total_count": 0,
            "sources_searched": sources or ["all"],
            "articles": [],
        }

    client = await _get_client()
    articles = await client.search(query.strip(), sources=sources, limit=limit)

    return {
        "query": query.strip(),
        "total_count": len(articles),
        "sources_searched": sources or ["all"],
        "articles": [a.to_dict() for a in articles],
    }


@mcp.tool()
async def get_headlines(
    source_id: Annotated[
        str | None,
        Field(
            description="Optional source ID to get headlines from. "
            "If not provided, gets headlines from all sources. "
            "Available: yahoo_business, nhk_economy, reuters_jp, toyokeizai",
        ),
    ] = None,
    limit: Annotated[
        int,
        Field(description="Maximum number of headlines (default: 10)", ge=1, le=30),
    ] = 10,
) -> dict[str, Any]:
    """Get latest headlines from news sources.

    Fetches the most recent articles from the specified source or all sources.
    Results are sorted by publication date (newest first).

    Args:
        source_id: Optional source ID to filter by.
        limit: Maximum number of headlines to return.

    Returns:
        Dictionary containing source ID and list of headline articles.
    """
    valid_ids = {"yahoo_business", "nhk_economy", "reuters_jp", "toyokeizai"}
    if source_id is not None and source_id not in valid_ids:
        return {
            "source_id": source_id,
            "total_count": 0,
            "articles": [],
            "error": f"Unknown source_id: {source_id!r}. Valid: {sorted(valid_ids)}",
        }

    client = await _get_client()
    articles = await client.get_headlines(source_id=source_id, limit=limit)

    return {
        "source_id": source_id or "all",
        "total_count": len(articles),
        "articles": [a.to_dict() for a in articles],
    }


@mcp.tool()
async def get_article_summary(
    article_link: Annotated[
        str,
        Field(description="URL of the article to summarize"),
    ],
) -> dict[str, Any]:
    """Get summary information for a specific article.

    Note: This tool returns metadata about the article. For full content,
    visit the article link directly.

    Args:
        article_link: The URL of the article.

    Returns:
        Article information if found.
    """
    client = await _get_client()

    # Search through all feeds to find the article
    all_articles = await client.fetch_all_feeds()

    for article in all_articles:
        if str(article.link) == article_link:
            return {
                "found": True,
                "article": article.to_dict(),
            }

    return {
        "found": False,
        "article_link": article_link,
        "message": (
            "Article not found in current RSS feeds. "
            "It may have expired or the link may be incorrect."
        ),
    }
