"""Tests for japan-news-mcp CLI."""

from unittest.mock import AsyncMock, Mock, patch

from click.testing import CliRunner

from japan_news_mcp.cli import cli


class TestCliVersion:
    """Test version command."""

    def test_version(self) -> None:
        """Test version command output."""
        runner = CliRunner()
        result = runner.invoke(cli, ["version"])

        assert result.exit_code == 0
        assert "0.1.2" in result.output


class TestCliSources:
    """Test sources command."""

    def test_sources_lists_all(self) -> None:
        """Test that sources command lists all sources."""
        runner = CliRunner()
        result = runner.invoke(cli, ["sources"])

        assert result.exit_code == 0
        assert "yahoo_business" in result.output
        assert "nhk_economy" in result.output
        assert "reuters_jp" in result.output
        assert "toyokeizai" in result.output


class TestCliSearch:
    """Test search command."""

    def test_search_with_no_results(self) -> None:
        """Test search with no results."""
        runner = CliRunner()

        with patch("japan_news_mcp.cli.NewsClient") as mock_client_class:
            mock_client = Mock()
            mock_client.search = AsyncMock(return_value=[])
            mock_client.close = AsyncMock()
            mock_client_class.return_value = mock_client

            result = runner.invoke(cli, ["search", "test"])

            assert result.exit_code == 0
            assert "Found 0 articles" in result.output


class TestCliHeadlines:
    """Test headlines command."""

    def test_headlines_with_no_results(self) -> None:
        """Test headlines with no results."""
        runner = CliRunner()

        with patch("japan_news_mcp.cli.NewsClient") as mock_client_class:
            mock_client = Mock()
            mock_client.get_headlines = AsyncMock(return_value=[])
            mock_client.close = AsyncMock()
            mock_client_class.return_value = mock_client

            result = runner.invoke(cli, ["headlines"])

            assert result.exit_code == 0
            assert "Showing 0 articles" in result.output


class TestCliTest:
    """Test test command."""

    def test_test_command(self) -> None:
        """Test the test command."""
        runner = CliRunner()

        with patch("japan_news_mcp.cli.NewsClient") as mock_client_class:
            mock_client = Mock()
            mock_client.get_sources = Mock(return_value=[Mock(id="test", name="Test Source")])
            mock_client.fetch_feed = AsyncMock(return_value=[Mock()])
            mock_client.close = AsyncMock()
            mock_client_class.return_value = mock_client

            result = runner.invoke(cli, ["test"])

            assert result.exit_code == 0
