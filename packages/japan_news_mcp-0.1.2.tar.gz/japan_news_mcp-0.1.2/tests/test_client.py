"""Tests for japan-news-mcp client."""

from unittest.mock import Mock

from japan_news_mcp.client import DEFAULT_SOURCES, NewsClient
from japan_news_mcp.models import NewsArticle


class TestNewsClientInit:
    """Test NewsClient initialization."""

    def test_default_init(self) -> None:
        """Test default initialization."""
        client = NewsClient()

        assert client.timeout == 30.0
        assert client._client is None
        assert len(client._sources) == 4

    def test_custom_timeout(self) -> None:
        """Test initialization with custom timeout."""
        client = NewsClient(timeout=60.0)

        assert client.timeout == 60.0


class TestNewsClientSources:
    """Test NewsClient source management."""

    def test_get_sources(self) -> None:
        """Test getting all sources."""
        client = NewsClient()
        sources = client.get_sources()

        assert len(sources) == 4
        source_ids = {s.id for s in sources}
        assert source_ids == {"yahoo_business", "nhk_economy", "reuters_jp", "toyokeizai"}

    def test_get_source_existing(self) -> None:
        """Test getting an existing source."""
        client = NewsClient()
        source = client.get_source("yahoo_business")

        assert source is not None
        assert source.id == "yahoo_business"
        assert source.name == "Yahoo!ニュース ビジネス"

    def test_get_source_nonexistent(self) -> None:
        """Test getting a non-existent source."""
        client = NewsClient()
        source = client.get_source("nonexistent")

        assert source is None


class TestNewsClientParsing:
    """Test NewsClient parsing methods."""

    def test_clean_html(self) -> None:
        """Test HTML cleaning."""
        client = NewsClient()
        html = "<p>This is <b>bold</b> text</p>"

        result = client._clean_html(html)

        assert "bold" in result
        assert "<p>" not in result
        assert "<b>" not in result

    def test_clean_html_empty(self) -> None:
        """Test cleaning empty HTML."""
        client = NewsClient()

        assert client._clean_html("") == ""
        assert client._clean_html(None) == ""  # type: ignore

    def test_parse_entry_valid(self) -> None:
        """Test parsing a valid feed entry."""
        client = NewsClient()
        source = DEFAULT_SOURCES["yahoo_business"]

        # Create entry that mimics feedparser structure (supports both dict and attr access)
        class FeedEntry:
            def __init__(self) -> None:
                self.title = "Test Title"
                self.link = "https://example.com/article"
                self.summary = "Test summary"
                self.published_parsed = (2024, 1, 15, 10, 30, 0, 0, 0, 0)
                self.updated_parsed = None
                self.tags = [Mock(term="business")]
                self.author = "Test Author"
                self.description = ""
                self.author_detail = None

            def get(self, key: str, default: str = "") -> str:
                return getattr(self, key, default)

        entry = FeedEntry()

        article = client._parse_entry(entry, source)

        assert article is not None
        assert article.title == "Test Title"
        assert article.source_id == "yahoo_business"
        assert article.published is not None

    def test_parse_entry_no_title(self) -> None:
        """Test parsing entry without title."""
        client = NewsClient()
        source = DEFAULT_SOURCES["yahoo_business"]

        entry = Mock()
        entry.title = ""
        entry.link = "https://example.com/article"

        article = client._parse_entry(entry, source)

        assert article is None

    def test_parse_entry_no_link(self) -> None:
        """Test parsing entry without link."""
        client = NewsClient()
        source = DEFAULT_SOURCES["yahoo_business"]

        entry = Mock()
        entry.title = "Test"
        entry.link = ""

        article = client._parse_entry(entry, source)

        assert article is None


class TestNewsClientSearch:
    """Test NewsClient search functionality."""

    def test_matches_query_in_title(self) -> None:
        """Test matching query in title."""
        client = NewsClient()
        article = NewsArticle(
            title="Stock prices rise",
            link="https://example.com",
            source_id="test",
            source_name="Test",
        )

        assert client._matches_query(article, "stock")
        assert client._matches_query(article, "prices")

    def test_matches_query_in_summary(self) -> None:
        """Test matching query in summary."""
        client = NewsClient()
        article = NewsArticle(
            title="News",
            link="https://example.com",
            source_id="test",
            source_name="Test",
            summary="The economy is growing",
        )

        assert client._matches_query(article, "economy")
        assert client._matches_query(article, "growing")

    def test_matches_query_in_categories(self) -> None:
        """Test matching query in categories."""
        client = NewsClient()
        article = NewsArticle(
            title="News",
            link="https://example.com",
            source_id="test",
            source_name="Test",
            categories=["business", "economy"],
        )

        assert client._matches_query(article, "business")

    def test_matches_query_case_insensitive(self) -> None:
        """Test case-insensitive matching."""
        client = NewsClient()
        article = NewsArticle(
            title="STOCK Prices",
            link="https://example.com",
            source_id="test",
            source_name="Test",
        )

        # Query should already be lowercased when passed to _matches_query
        assert client._matches_query(article, "stock")
        assert client._matches_query(article, "prices")

    def test_matches_query_no_match(self) -> None:
        """Test non-matching query."""
        client = NewsClient()
        article = NewsArticle(
            title="Stock prices",
            link="https://example.com",
            source_id="test",
            source_name="Test",
        )

        assert not client._matches_query(article, "weather")


class TestDefaultSources:
    """Test default sources configuration."""

    def test_yahoo_business_source(self) -> None:
        """Test Yahoo Business source config."""
        source = DEFAULT_SOURCES["yahoo_business"]

        assert source.id == "yahoo_business"
        assert "yahoo" in str(source.url).lower()

    def test_nhk_economy_source(self) -> None:
        """Test NHK Economy source config."""
        source = DEFAULT_SOURCES["nhk_economy"]

        assert source.id == "nhk_economy"
        assert "nhk" in str(source.url).lower()

    def test_reuters_source(self) -> None:
        """Test Reuters source config."""
        source = DEFAULT_SOURCES["reuters_jp"]

        assert source.id == "reuters_jp"
        assert "reuters" in str(source.url).lower()

    def test_toyokeizai_source(self) -> None:
        """Test Toyokeizai source config."""
        source = DEFAULT_SOURCES["toyokeizai"]

        assert source.id == "toyokeizai"
        assert "toyokeizai" in str(source.url).lower()
