"""Integration tests for japan-news-mcp."""

import pytest

from japan_news_mcp.client import NewsClient


class TestIntegration:
    """Integration tests using real RSS feeds (optional)."""

    @pytest.mark.asyncio
    @pytest.mark.integration
    async def test_fetch_yahoo_feed(self) -> None:
        """Test fetching Yahoo Business feed (real network call)."""
        client = NewsClient()
        try:
            source = client.get_source("yahoo_business")
            assert source is not None

            articles = await client.fetch_feed(source)

            # Yahoo feed should return articles (if available)
            assert isinstance(articles, list)

            if articles:
                article = articles[0]
                assert article.title
                assert article.link
                assert article.source_id == "yahoo_business"
        finally:
            await client.close()

    @pytest.mark.asyncio
    @pytest.mark.integration
    async def test_fetch_all_feeds(self) -> None:
        """Test fetching all feeds (real network call)."""
        client = NewsClient()
        try:
            articles = await client.fetch_all_feeds()

            assert isinstance(articles, list)
            # Articles should be sorted by date (newest first)
            if len(articles) > 1:
                dates = [a.published for a in articles if a.published]
                if len(dates) > 1:
                    assert dates[0] >= dates[1]
        finally:
            await client.close()

    @pytest.mark.asyncio
    @pytest.mark.integration
    async def test_search_integration(self) -> None:
        """Test search functionality (real network call)."""
        client = NewsClient()
        try:
            articles = await client.search("経済", limit=5)

            assert isinstance(articles, list)
            assert len(articles) <= 5
        finally:
            await client.close()


class TestClientLifecycle:
    """Test client lifecycle management."""

    @pytest.mark.asyncio
    async def test_client_close(self) -> None:
        """Test closing the client."""
        client = NewsClient()

        # Get HTTP client (creates it)
        http_client = await client._get_http_client()
        assert http_client is not None

        # Close should clean up
        await client.close()
        assert client._client is None

    @pytest.mark.asyncio
    async def test_client_multiple_closes(self) -> None:
        """Test that multiple closes don't raise errors."""
        client = NewsClient()

        await client.close()
        await client.close()  # Should not raise
