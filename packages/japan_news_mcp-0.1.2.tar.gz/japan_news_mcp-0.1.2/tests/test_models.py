"""Tests for japan-news-mcp models."""

from datetime import datetime

import pytest
from pydantic import ValidationError

from japan_news_mcp.models import HeadlinesResult, NewsArticle, NewsSource, SearchResult


class TestNewsSource:
    """Test NewsSource model."""

    def test_create_source(self) -> None:
        """Test creating a NewsSource."""
        source = NewsSource(
            id="test_source",
            name="Test Source",
            url="https://example.com/feed.xml",
            description="A test source",
            language="ja",
        )

        assert source.id == "test_source"
        assert source.name == "Test Source"
        assert str(source.url) == "https://example.com/feed.xml"
        assert source.description == "A test source"
        assert source.language == "ja"

    def test_source_immutable(self) -> None:
        """Test that NewsSource is immutable."""
        source = NewsSource(
            id="test",
            name="Test",
            url="https://example.com/feed.xml",
        )

        with pytest.raises(ValidationError):
            source.name = "Changed"

    def test_source_defaults(self) -> None:
        """Test NewsSource default values."""
        source = NewsSource(
            id="test",
            name="Test",
            url="https://example.com/feed.xml",
        )

        assert source.description == ""
        assert source.language == "ja"


class TestNewsArticle:
    """Test NewsArticle model."""

    def test_create_article(self) -> None:
        """Test creating a NewsArticle."""
        now = datetime.now()
        article = NewsArticle(
            title="Test Article",
            link="https://example.com/article",
            summary="Test summary",
            published=now,
            source_id="test_source",
            source_name="Test Source",
            categories=["business", "economy"],
            author="Test Author",
        )

        assert article.title == "Test Article"
        assert str(article.link) == "https://example.com/article"
        assert article.summary == "Test summary"
        assert article.published == now
        assert article.source_id == "test_source"
        assert article.source_name == "Test Source"
        assert article.categories == ["business", "economy"]
        assert article.author == "Test Author"

    def test_article_defaults(self) -> None:
        """Test NewsArticle default values."""
        article = NewsArticle(
            title="Test",
            link="https://example.com/article",
            source_id="test",
            source_name="Test",
        )

        assert article.summary == ""
        assert article.published is None
        assert article.categories == []
        assert article.author is None

    def test_article_to_dict(self) -> None:
        """Test converting NewsArticle to dict."""
        now = datetime.now()
        article = NewsArticle(
            title="Test",
            link="https://example.com/article",
            source_id="test",
            source_name="Test",
            published=now,
        )

        d = article.to_dict()

        assert d["title"] == "Test"
        assert d["link"] == "https://example.com/article"
        assert d["source_id"] == "test"
        assert d["published"] == now.isoformat()

    def test_article_to_dict_no_published(self) -> None:
        """Test converting NewsArticle to dict without published date."""
        article = NewsArticle(
            title="Test",
            link="https://example.com/article",
            source_id="test",
            source_name="Test",
        )

        d = article.to_dict()

        assert d["published"] is None

    def test_article_immutable(self) -> None:
        """Test that NewsArticle is immutable."""
        article = NewsArticle(
            title="Test",
            link="https://example.com/article",
            source_id="test",
            source_name="Test",
        )

        with pytest.raises(ValidationError):
            article.title = "Changed"


class TestSearchResult:
    """Test SearchResult model."""

    def test_create_search_result(self) -> None:
        """Test creating a SearchResult."""
        article = NewsArticle(
            title="Test",
            link="https://example.com/article",
            source_id="test",
            source_name="Test",
        )

        result = SearchResult(
            query="test query",
            articles=[article],
            total_count=1,
            sources_searched=["test"],
        )

        assert result.query == "test query"
        assert len(result.articles) == 1
        assert result.total_count == 1
        assert result.sources_searched == ["test"]

    def test_search_result_defaults(self) -> None:
        """Test SearchResult default values."""
        result = SearchResult(query="test")

        assert result.articles == []
        assert result.total_count == 0
        assert result.sources_searched == []

    def test_search_result_to_dict(self) -> None:
        """Test converting SearchResult to dict."""
        article = NewsArticle(
            title="Test",
            link="https://example.com/article",
            source_id="test",
            source_name="Test",
        )

        result = SearchResult(
            query="test",
            articles=[article],
            total_count=1,
            sources_searched=["test"],
        )

        d = result.to_dict()

        assert d["query"] == "test"
        assert d["total_count"] == 1
        assert len(d["articles"]) == 1
        assert d["sources_searched"] == ["test"]


class TestHeadlinesResult:
    """Test HeadlinesResult model."""

    def test_create_headlines_result(self) -> None:
        """Test creating a HeadlinesResult."""
        article = NewsArticle(
            title="Test",
            link="https://example.com/article",
            source_id="test",
            source_name="Test",
        )

        result = HeadlinesResult(
            source_id="test",
            articles=[article],
            total_count=1,
        )

        assert result.source_id == "test"
        assert len(result.articles) == 1
        assert result.total_count == 1

    def test_headlines_result_defaults(self) -> None:
        """Test HeadlinesResult default values."""
        result = HeadlinesResult()

        assert result.source_id is None
        assert result.articles == []
        assert result.total_count == 0

    def test_headlines_result_to_dict(self) -> None:
        """Test converting HeadlinesResult to dict."""
        article = NewsArticle(
            title="Test",
            link="https://example.com/article",
            source_id="test",
            source_name="Test",
        )

        result = HeadlinesResult(
            source_id="test",
            articles=[article],
            total_count=1,
        )

        d = result.to_dict()

        assert d["source_id"] == "test"
        assert d["total_count"] == 1
        assert len(d["articles"]) == 1
