"""Tests for japan-news-mcp server."""

from unittest.mock import AsyncMock, Mock, patch

import pytest

# Import the module to test the functions directly
import japan_news_mcp.server as server_module


class TestListSources:
    """Test list_sources tool."""

    @pytest.mark.asyncio
    async def test_list_sources_returns_all(self) -> None:
        """Test that list_sources returns all configured sources."""
        with (
            patch.object(server_module, "_client", None),
            patch("japan_news_mcp.server.NewsClient") as mock_client_class,
        ):
            mock_client = Mock()
            mock_client.get_sources.return_value = [
                Mock(
                    id="test1",
                    name="Test 1",
                    url="http://test1.com",
                    description="Desc 1",
                    language="ja",
                ),
                Mock(
                    id="test2",
                    name="Test 2",
                    url="http://test2.com",
                    description="Desc 2",
                    language="ja",
                ),
            ]
            mock_client_class.return_value = mock_client

            client = await server_module._get_client()
            sources = client.get_sources()

            assert len(sources) >= 2

    @pytest.mark.asyncio
    async def test_list_sources_has_required_fields(self) -> None:
        """Test that each source has required fields."""
        with (
            patch.object(server_module, "_client", None),
            patch("japan_news_mcp.server.NewsClient") as mock_client_class,
        ):
            mock_client = Mock()
            mock_client.get_sources.return_value = [
                Mock(
                    id="test",
                    name="Test",
                    url="http://test.com",
                    description="Desc",
                    language="ja",
                ),
            ]
            mock_client_class.return_value = mock_client

            client = await server_module._get_client()
            sources = client.get_sources()

            for source in sources:
                assert hasattr(source, "id")
                assert hasattr(source, "name")


class TestServerFunctions:
    """Test server function logic."""

    @pytest.mark.asyncio
    async def test_search_logic(self) -> None:
        """Test the search logic through client."""
        from japan_news_mcp.client import NewsClient

        client = NewsClient()

        with patch.object(
            client,
            "search",
            new=AsyncMock(return_value=[]),
        ) as mock_search:
            result = await client.search("test", limit=5)
            mock_search.assert_awaited_once()
            assert result == []

    @pytest.mark.asyncio
    async def test_headlines_logic(self) -> None:
        """Test the headlines logic through client."""
        from japan_news_mcp.client import NewsClient

        client = NewsClient()

        with patch.object(
            client,
            "get_headlines",
            new=AsyncMock(return_value=[]),
        ) as mock_headlines:
            result = await client.get_headlines(limit=10)
            mock_headlines.assert_awaited_once()
            assert result == []

    @pytest.mark.asyncio
    async def test_article_summary_logic(self) -> None:
        """Test the article summary logic."""
        from japan_news_mcp.models import NewsArticle

        client = Mock()
        article = NewsArticle(
            title="Test Article",
            link="https://example.com/article",
            source_id="test",
            source_name="Test",
        )
        client.fetch_all_feeds = AsyncMock(return_value=[article])

        result = await client.fetch_all_feeds()

        assert len(result) == 1
        assert str(result[0].link) == "https://example.com/article"
