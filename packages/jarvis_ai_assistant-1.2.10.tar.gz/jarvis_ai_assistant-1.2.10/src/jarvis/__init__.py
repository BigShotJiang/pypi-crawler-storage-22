# -*- coding: utf-8 -*-
"""Jarvis AI Assistant"""

__version__ = "1.2.10"
