"""
    Drissionpage-mcp中纯Cv领域的相关功能，为Vl模型赋能
"""
import os
from typing import Any

from fastmcp import FastMCP

from tools.tools import dp_mcp_message_pack

html_source_code_local_save_path = os.path.join(os.getcwd(), "html-source-code")
