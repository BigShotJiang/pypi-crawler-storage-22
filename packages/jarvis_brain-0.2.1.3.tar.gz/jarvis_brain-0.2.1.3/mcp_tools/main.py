from fastmcp import FastMCP

from mcp_tools.dp_base import *
from mcp_tools.dp_html import *
from mcp_tools.dp_cv import *
from tools.browser_manager import browser_manager
from tools.browser_proxy import client_manager

mcp = FastMCP("Jarvis Brain Mcp Tools")

# 根据环境变量加载模块
enabled_modules = os.getenv("MCP_MODULES", "Dp-Base,Dp-Html").split(",")
base_cwd = os.getenv("BASE_CWD", os.path.expanduser('~'))

if "Dp-Base" in enabled_modules:
    # 页面管理
    register_close_tab(mcp, browser_manager)
    register_switch_tab(mcp, browser_manager)
    register_get_new_tab(mcp, browser_manager, client_manager)
    register_quit_browser(mcp, browser_manager)
    # 基础功能
    register_visit_url(mcp, browser_manager, client_manager)
    register_get_html(mcp, browser_manager)
    register_check_selector(mcp, browser_manager)
    register_pop_first_packet(mcp, browser_manager, client_manager)
    register_get_screenshot(mcp, browser_manager)
    register_get_ele_info(mcp, browser_manager)

if "Dp-Html" in enabled_modules:
    # 使用html分析出来的Selector进行交互
    # 页面交互
    register_click_action(mcp, browser_manager)
    register_scroll_action(mcp, browser_manager)
    register_mouse_hover(mcp, browser_manager)

if "Dp-Cv" in enabled_modules:
    # Cv模式的基础功能
    # todo:
    #  1. 根据xy坐标查询某一个element
    #  2. 根据元素相对位置的bboxes，计算出对应元素的中心点xy
    #  3. 根据Selector获取一个元素的xy center
    #  4. 根据xy坐标查询某一个element的abs css Selector【这个需要考虑是否需要与第一个合并？】
    # 页面交互
    register_click_action(mcp, browser_manager)
    register_scroll_action(mcp, browser_manager)
    register_mouse_hover(mcp, browser_manager)


def main():
    mcp.run(transport="stdio", show_banner=False)


if __name__ == '__main__':
    main()
