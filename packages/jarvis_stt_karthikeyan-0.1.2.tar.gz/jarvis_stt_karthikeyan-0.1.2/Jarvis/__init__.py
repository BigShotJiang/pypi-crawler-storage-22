import os
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

class JarvisSTT:
    def __init__(self, headless=True):
        self.chrome_options = webdriver.ChromeOptions()
        self.chrome_options.add_argument("--use-fake-ui-for-media-stream")
        if headless:
            self.chrome_options.add_argument("--headless=new")
        
        # Additional flags to prevent crashes in some environments
        self.chrome_options.add_argument("--no-sandbox")
        self.chrome_options.add_argument("--disable-dev-shm-usage")
        self.chrome_options.add_argument("--disable-gpu")

        self.driver = webdriver.Chrome(
            service=Service(ChromeDriverManager().install()), 
            options=self.chrome_options
        )
        
        # Determine the path to index.html
        # If installed as a package, it might be in a different location
        # Determine the path to index.html
        current_dir = os.path.dirname(os.path.abspath(__file__))
        file_path = os.path.join(current_dir, "index.html").replace("\\", "/")
        self.website = f"file:///{file_path}"
        print(f"Loading: {self.website}")
        self.rec_file = os.path.join(os.getcwd(), "index.txt")

    def listen(self):
        try:
            self.driver.get(self.website)
            start_button = WebDriverWait(self.driver, 20).until(
                EC.element_to_be_clickable((By.ID, "startButton"))
            )
            start_button.click()

            print("Listening...")

            last_clean_text = ""
            while True:
                output_element = WebDriverWait(self.driver, 20).until(
                    EC.presence_of_element_located((By.ID, "output"))
                )
                raw_text = output_element.text.strip()
                if not raw_text:
                    continue

                # Remove the timestamp marker for clean output
                clean_text = raw_text.split(" |")[0].strip()

                if clean_text and clean_text != last_clean_text:
                    last_clean_text = clean_text
                    with open(self.rec_file, "w") as file:
                        file.write(clean_text.lower())
                    print("USER : " + clean_text)
                    
        except KeyboardInterrupt:
            print("\nStopped by user.")
        except Exception as e:
            print(f"An error occurred: {e}")
        finally:
            self.driver.quit()

def listen():
    """Compatibility function for the user's previous script."""
    stt = JarvisSTT(headless=True)
    stt.listen()

if __name__ == "__main__":
    listen()