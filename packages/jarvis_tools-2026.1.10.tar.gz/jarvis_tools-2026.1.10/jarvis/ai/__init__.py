"""Modules for AI applications."""
