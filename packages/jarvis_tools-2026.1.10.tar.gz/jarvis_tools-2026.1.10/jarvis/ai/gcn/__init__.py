"""Module for graph generation using atoms."""
