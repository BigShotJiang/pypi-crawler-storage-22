"""Modules for AI uncertainty."""
