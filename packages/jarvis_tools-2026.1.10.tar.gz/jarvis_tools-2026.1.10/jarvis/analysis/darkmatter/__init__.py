"""Modules for dark-matter detection materials."""
