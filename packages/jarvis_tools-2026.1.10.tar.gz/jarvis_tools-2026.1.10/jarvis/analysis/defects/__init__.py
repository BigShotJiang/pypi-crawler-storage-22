"""Modules for defect generation in solids."""
