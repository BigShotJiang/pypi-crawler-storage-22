"""Module for X-ray and Neutron diffractions."""
