"""Module for analyzing elastic tensor."""
