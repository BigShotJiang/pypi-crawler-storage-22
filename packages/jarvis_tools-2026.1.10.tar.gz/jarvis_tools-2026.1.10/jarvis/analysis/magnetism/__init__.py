"""Modules for magnetism related analysis."""
