"""Modules for predicting theoretical solar-efficiency."""
