"""Module to simulate STEM images."""
