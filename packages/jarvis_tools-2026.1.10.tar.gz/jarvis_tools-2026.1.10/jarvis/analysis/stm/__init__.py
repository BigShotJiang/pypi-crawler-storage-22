"""Modules for generating Scanning Tunneling Microscopy images."""
