"""Modules for crystal structure analysis."""
