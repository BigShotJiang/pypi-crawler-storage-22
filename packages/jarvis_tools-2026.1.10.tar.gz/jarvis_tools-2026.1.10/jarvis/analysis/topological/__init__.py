"""Module to predict topological SOC spillage."""
