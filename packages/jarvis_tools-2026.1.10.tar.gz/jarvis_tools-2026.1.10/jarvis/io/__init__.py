"""For reading, writing, analyzing infromation from different softwares."""
