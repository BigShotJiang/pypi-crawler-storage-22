"""Module to prepare and parse input files."""
