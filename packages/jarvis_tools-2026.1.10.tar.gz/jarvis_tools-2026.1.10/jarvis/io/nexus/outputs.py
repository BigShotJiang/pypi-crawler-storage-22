"""Module to parse output files."""
