"""Module to prepare input file for prismatic."""
