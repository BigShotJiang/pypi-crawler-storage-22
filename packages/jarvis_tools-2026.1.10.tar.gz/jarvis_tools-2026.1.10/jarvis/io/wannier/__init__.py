"""Methods for handling input/output files for Wannier90."""
