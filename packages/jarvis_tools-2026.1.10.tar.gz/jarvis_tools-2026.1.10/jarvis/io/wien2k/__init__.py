"""Module for processing WIEN2k input output files."""
