"""Modules for calculation jon submissions."""
