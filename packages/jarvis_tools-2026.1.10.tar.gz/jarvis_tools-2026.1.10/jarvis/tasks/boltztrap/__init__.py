"""Module to run BoltzTrap. Assumes x_trans in PATH."""
