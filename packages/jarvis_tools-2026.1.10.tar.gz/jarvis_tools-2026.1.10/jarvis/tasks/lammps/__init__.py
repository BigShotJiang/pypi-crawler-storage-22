"""Modules for high-throughput LAMMPS calculations."""
