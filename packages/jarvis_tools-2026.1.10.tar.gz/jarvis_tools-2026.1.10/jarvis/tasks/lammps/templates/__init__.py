"""Provide LAMMPS templates for .mod files."""
