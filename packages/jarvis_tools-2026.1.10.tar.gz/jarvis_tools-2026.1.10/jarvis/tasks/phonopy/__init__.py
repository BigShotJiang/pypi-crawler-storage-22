"""Module to run phonopy. Assumes phonopy in PATH."""
