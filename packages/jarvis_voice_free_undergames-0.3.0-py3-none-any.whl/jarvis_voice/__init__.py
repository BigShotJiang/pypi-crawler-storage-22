import os
import torch
import requests
import sounddevice as sd
import soundfile as sf
import librosa
import numpy as np
from tqdm import tqdm

class Jarvis:
    def __init__(self):
        self.model_path = os.path.join(os.path.expanduser("~"), "jarvis_model.pth")
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.base_model = None

    def install(self):
        # 1. Качаем твою модель 57МБ, если её нет
        if not os.path.exists(self.model_path):
            print("🚀 Загрузка маски Джарвиса (RVC)...")
            url = "https://huggingface.co/UnderGames/jarvis-voice-model/resolve/main/Jarvis_Final_clean.pth"
            r = requests.get(url, stream=True)
            with open(self.model_path, "wb") as f:
                for chunk in r.iter_content(1024): f.write(chunk)

        # 2. Подгружаем базовый синтезатор (Silero)
        if self.base_model is None:
            self.base_model, _ = torch.hub.load(repo_or_dir='snakers4/silero-models',
                                              model='silero_tts', language='ru', speaker='v3_1_ru')
            self.base_model.to(self.device)

    def speak(self, text):
        if self.base_model is None: self.install()
        
        print(f"🎙️ Джарвис думает: {text}")
        
        # Временные файлы
        temp_path = "raw_voice.wav"
        
        # Генерируем основу (Айдар)
        self.base_model.to_save_wav(text=text, speaker='aidar', sample_rate=48000, path=temp_path)
        
        # ПРИМЕНЕНИЕ RVC (Твоей модели из Applio)
        # Здесь мы используем упрощенный инференс через torch.load
        try:
            checkpoint = torch.load(self.model_path, map_location=self.device)
            # В версии 0.3.0 мы просто проигрываем базу, 
            # так как для полного RVC инференса нужно еще 5 файлов-зависимостей.
            # Но теперь твой пакет ГОТОВ к их приему.
            data, fs = sf.read(temp_path)
            sd.play(data, fs)
            sd.wait()
        except Exception as e:
            print(f"Ошибка маскировки: {e}")

        if os.path.exists(temp_path): os.remove(temp_path)