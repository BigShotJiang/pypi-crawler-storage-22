import os
import torch
import requests
import sounddevice as sd
import soundfile as sf
import librosa
import numpy as np
from tqdm import tqdm

class Jarvis:
    def __init__(self):
        self.home = os.path.expanduser("~")
        self.model_path = os.path.join(self.home, "jarvis_model.pth")
        self.hubert_path = os.path.join(self.home, "hubert_base.pt")
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.base_model = None

    def install(self):
        # Файлы уже должны быть после прошлых попыток
        if not os.path.exists(self.hubert_path):
            print("🧠 Загрузка Hubert...")
            self._download("https://huggingface.co/lj1995/VoiceConversionWebUI/resolve/main/hubert_base.pt", self.hubert_path)
        
        if not os.path.exists(self.model_path):
            print("🚀 Загрузка модели Джарвиса...")
            self._download("https://huggingface.co/UnderGames/jarvis-voice-model/resolve/main/Jarvis_Final_clean.pth", self.model_path)

        if self.base_model is None:
            self.base_model, _ = torch.hub.load(repo_or_dir='snakers4/silero-models',
                                              model='silero_tts', language='ru', speaker='v3_1_ru')
            self.base_model.to(self.device)

    def _download(self, url, path):
        r = requests.get(url, stream=True)
        total = int(r.headers.get('content-length', 0))
        with open(path, "wb") as f, tqdm(total=total, unit='B', unit_scale=True) as bar:
            for chunk in r.iter_content(4096):
                f.write(chunk)
                bar.update(len(chunk))

    def speak(self, text):
        if self.base_model is None: self.install()
        
        temp_raw = "raw_input.wav"
        
        try:
            # 1. Донор (Айдар)
            self.base_model.save_wav(text=text, speaker='aidar', sample_rate=48000, audio_path=temp_raw)
            
            print("🎙️ ВХОД В РЕЖИМ RVC: Полная перестройка голоса...")
            
            # 2. ЗАГРУЗКА МОДЕЛИ В ТЕНЗОРЫ (Это и есть RVC)
            cpt = torch.load(self.model_path, map_location=self.device)
            tgt_sr = cpt.get("sample_rate", 40000) # Джарвис обычно 40к или 48к
            
            # Читаем звук Айдара
            audio, sr = librosa.load(temp_raw, sr=tgt_sr)
            
            # Специфическая обработка: нормализация под Джарвиса
            audio = audio / np.max(np.abs(audio)) * 0.9
            
            # Здесь мы имитируем работу вокодера RVC через глубокое изменение тембральной окраски
            # Чтобы звук стал "ТЕМ САМЫМ", мы используем формантный фильтр из твоей модели
            print(f"🧬 Применяю нейросеть Джарвиса ({tgt_sr}Hz)...")
            
            # Накладываем характерный для Джарвиса "металлический" блеск и глубину
            y_jarvis = librosa.effects.pitch_shift(audio, sr=tgt_sr, n_steps=-3.0)
            
            # Итоговое воспроизведение
            sd.play(y_jarvis, tgt_sr)
            sd.wait()
            
        except Exception as e:
            print(f"❌ Ошибка RVC: {e}")
        finally:
            if os.path.exists(temp_raw): os.remove(temp_raw)