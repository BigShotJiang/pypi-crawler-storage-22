import os
import torch
import sounddevice as sd
import soundfile as sf
from TTS.api import TTS
import warnings

# ОТКЛЮЧАЕМ ПАРАНОЙЮ PYTORCH 2.6
# Это разрешает загрузку кастомных конфигов нейросети
import torch.serialization
torch.serialization.add_safe_globals([
    'TTS.tts.configs.xtts_config.XttsConfig',
    'TTS.tts.models.xtts.XttsAudioConfig',
    'TTS.config.shared_configs.BaseDatasetConfig'
])

class Jarvis:
    def __init__(self):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        print(f"📡 Загрузка нейросети (Device: {self.device})...")
        
        # Если torch всё равно будет бесить, мы принудительно отключаем weights_only через переменную окружения
        os.environ["TORCH_FORCE_WEIGHTS_ONLY_LOAD"] = "0"
        
        try:
            # Загружаем модель
            self.tts = TTS("tts_models/multilingual/multi-dataset/xtts_v2").to(self.device)
        except Exception as e:
            print(f"⚠️ Ошибка при мягкой загрузке, пробую обходной путь...")
            # Если первый вариант не прокатит (хотя должен)
            self.tts = TTS("tts_models/multilingual/multi-dataset/xtts_v2", gpu=(self.device == "cuda"))

        self.speaker_wav = r"C:\Users\jaroslav\Music\jarvis_sample.wav" 
        self.out_path = "jarvis_final.wav"

    def speak(self, text):
        if not os.path.exists(self.speaker_wav):
            print(f"❌ ФАЙЛ НЕ НАЙДЕН: {self.speaker_wav}")
            print("Создай 10-секундный WAV файл с голосом Джарвиса и положи его туда.")
            return

        print(f"🎙️ Джарвис генерирует голос...")
        try:
            self.tts.tts_to_file(
                text=text,
                speaker_wav=self.speaker_wav,
                language="ru",
                file_path=self.out_path
            )
            
            data, sr = sf.read(self.out_path)
            sd.play(data, sr)
            sd.wait()
        except Exception as e:
            print(f"❌ Ошибка синтеза: {e}")

if __name__ == "__main__":
    j = Jarvis()
    j.speak("Тест системы. Джарослав, если ты это слышишь, значит мы победили консоль.")