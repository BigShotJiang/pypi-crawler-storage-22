"""
JarvisCore CLI Tools

Command-line utilities for setup, validation, and testing.
"""

__all__ = ['check', 'smoketest']
