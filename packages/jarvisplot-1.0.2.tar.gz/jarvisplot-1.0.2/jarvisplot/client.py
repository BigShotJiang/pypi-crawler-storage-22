#!/usr/bin/env python3 

def main():
    from jarvisplot.core import JarvisPLOT
    jp = JarvisPLOT()
    jp.init()
    return 0