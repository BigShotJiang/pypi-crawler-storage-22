# jax-silicon

`jax-silicon` is a PJRT plugin that enables JAX to run on Apple Metal (MPS)
GPUs on Apple Silicon.

## Requirements

- macOS 13+ on Apple Silicon
- Python 3.11+
- `jax` and `jaxlib` 0.9.x

## Install

```bash
pip install jax-silicon
```

## Build From Source

```bash
brew install cmake ninja
uv pip install -e .
```

On first build, missing native dependencies are bootstrapped automatically by
running `scripts/setup_deps.sh`.

To disable auto-bootstrap:

```bash
CMAKE_ARGS="-DJAX_SILICON_AUTO_SETUP_DEPS=OFF" uv pip install -e .
```

## Use

The plugin backend name in JAX is still `mps`.

```bash
JAX_PLATFORMS=mps python -c "import jax; print(jax.devices())"
```

Optional library path overrides:

- `JAX_SILICON_LIBRARY_PATH`
- `JAX_MPS_LIBRARY_PATH` (legacy compatibility)

## Test

```bash
uv run pytest
```

## Repository Layout

- `src/jax_plugins/silicon/` Python plugin entrypoint
- `src/pjrt_plugin/` C++/Objective-C++ PJRT implementation
- `scripts/setup_deps.sh` dependency bootstrap
- `tests/` test suite

## License

Apache-2.0.

This repository is a derivative of `tillahoffmann/jax-mps`.
