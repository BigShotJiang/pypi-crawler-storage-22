// Binary operations: add, subtract, multiply, divide, maximum, minimum,
// compare, select, clamp, next_after, dot, dot_general

#import "pjrt_plugin/ops/registry.h"
#include <limits>
#include <sstream>

namespace jax_silicon {

REGISTER_MLIR_BINARY_OP("stablehlo.add", addition, add);
REGISTER_MLIR_BINARY_OP("stablehlo.subtract", subtraction, subtract);
REGISTER_MLIR_BINARY_OP("stablehlo.multiply", multiplication, multiply);
REGISTER_MLIR_BINARY_OP("stablehlo.divide", division, divide);
REGISTER_MLIR_BINARY_OP("stablehlo.maximum", maximum, maximum);
REGISTER_MLIR_BINARY_OP("stablehlo.minimum", minimum, minimum);
REGISTER_MLIR_BINARY_OP("stablehlo.remainder", modulo, remainder);
REGISTER_MLIR_BINARY_OP("stablehlo.power", power, power);
REGISTER_MLIR_BINARY_OP("stablehlo.atan2", atan2, atan2);

// Matrix multiplication (dot)
static ProcessResult HandleDot(HandlerContext& ctx) {
    MPSGraphTensor* lhs = GetInputTensor(ctx, 0);
    MPSGraphTensor* rhs = GetInputTensor(ctx, 1);
    if (!lhs || !rhs)
        return ProcessResult::Error("dot: missing input tensor");
    MPSGraphTensor* result = [ctx.graph matrixMultiplicationWithPrimaryTensor:lhs
                                                              secondaryTensor:rhs
                                                                         name:nil];
    return Result(ctx, result, "dot");
}
REGISTER_MPS_OP("stablehlo.dot", HandleDot);

namespace {

static bool IsIdentityPermutation(NSArray<NSNumber*>* permutation) {
    for (NSUInteger i = 0; i < permutation.count; ++i) {
        if ([permutation[i] integerValue] != (NSInteger)i) {
            return false;
        }
    }
    return true;
}

static std::string JoinInts(llvm::ArrayRef<int64_t> values) {
    std::ostringstream oss;
    oss << "[";
    for (size_t i = 0; i < values.size(); ++i) {
        if (i > 0) {
            oss << ", ";
        }
        oss << values[i];
    }
    oss << "]";
    return oss.str();
}

static std::string ShapeToString(NSArray<NSNumber*>* shape) {
    std::ostringstream oss;
    oss << "[";
    for (NSUInteger i = 0; i < shape.count; ++i) {
        if (i > 0) {
            oss << ", ";
        }
        oss << [shape[i] longLongValue];
    }
    oss << "]";
    return oss.str();
}

static bool ProductDims(const std::vector<int64_t>& dims, int64_t* out) {
    int64_t prod = 1;
    for (int64_t d : dims) {
        if (d <= 0) {
            return false;
        }
        if (prod > (std::numeric_limits<int64_t>::max() / d)) {
            return false;
        }
        prod *= d;
    }
    *out = prod;
    return true;
}

static std::vector<int64_t> ComplementDims(NSUInteger rank, const std::vector<bool>& used) {
    std::vector<int64_t> dims;
    for (NSUInteger d = 0; d < rank; ++d) {
        if (!used[d]) {
            dims.push_back((int64_t)d);
        }
    }
    return dims;
}

static std::vector<int64_t> GetDimSizes(NSArray<NSNumber*>* shape, llvm::ArrayRef<int64_t> dims) {
    std::vector<int64_t> sizes;
    sizes.reserve(dims.size());
    for (int64_t d : dims) {
        sizes.push_back([shape[(NSUInteger)d] longLongValue]);
    }
    return sizes;
}

static NSArray<NSNumber*>* ToNSArray(const std::vector<int64_t>& values) {
    NSMutableArray<NSNumber*>* out = [NSMutableArray arrayWithCapacity:values.size()];
    for (int64_t v : values) {
        [out addObject:@(v)];
    }
    return out;
}

}  // namespace

// Generalized matrix multiplication (dot_general)
// Handles contracting dimensions and batch dimensions
static ProcessResult HandleDotGeneral(HandlerContext& ctx) {
    auto dotOp = mlir::dyn_cast<mlir::stablehlo::DotGeneralOp>(ctx.op);
    if (!dotOp) {
        return ProcessResult::Error("dot_general: expected DotGeneralOp");
    }

    MPSGraphTensor* lhsInput = GetInputTensor(ctx, 0);
    MPSGraphTensor* rhsInput = GetInputTensor(ctx, 1);
    if (!lhsInput || !rhsInput)
        return ProcessResult::Error("dot_general: missing input tensor");

    auto dimNumbers = dotOp.getDotDimensionNumbers();
    auto lhsContractingDims = dimNumbers.getLhsContractingDimensions();
    auto rhsContractingDims = dimNumbers.getRhsContractingDimensions();
    auto lhsBatchDims = dimNumbers.getLhsBatchingDimensions();
    auto rhsBatchDims = dimNumbers.getRhsBatchingDimensions();

    NSArray<NSNumber*>* lhsShape = lhsInput.shape;
    NSArray<NSNumber*>* rhsShape = rhsInput.shape;
    NSUInteger lhsRank = lhsShape.count;
    NSUInteger rhsRank = rhsShape.count;

    if (lhsBatchDims.size() != rhsBatchDims.size()) {
        return ProcessResult::Error(
            "dot_general: lhs/rhs batching dims size mismatch (lhs=" + JoinInts(lhsBatchDims) +
            ", rhs=" + JoinInts(rhsBatchDims) + ")");
    }
    if (lhsContractingDims.size() != rhsContractingDims.size()) {
        return ProcessResult::Error(
            "dot_general: lhs/rhs contracting dims size mismatch (lhs=" +
            JoinInts(lhsContractingDims) + ", rhs=" + JoinInts(rhsContractingDims) + ")");
    }

    auto validateDims = [](llvm::ArrayRef<int64_t> dims, NSUInteger rank, const char* kind,
                           std::vector<bool>& seen, std::string& error) -> bool {
        for (int64_t d : dims) {
            if (d < 0 || d >= (int64_t)rank) {
                error = std::string("dot_general: ") + kind +
                        " dimension out of range: " + std::to_string(d);
                return false;
            }
            if (seen[(NSUInteger)d]) {
                error = std::string("dot_general: duplicate dimension in ") + kind +
                        ": " + std::to_string(d);
                return false;
            }
            seen[(NSUInteger)d] = true;
        }
        return true;
    };

    std::vector<bool> lhsUsed(lhsRank, false);
    std::vector<bool> rhsUsed(rhsRank, false);
    std::string dimError;
    if (!validateDims(lhsBatchDims, lhsRank, "lhs_batching", lhsUsed, dimError) ||
        !validateDims(lhsContractingDims, lhsRank, "lhs_contracting", lhsUsed, dimError) ||
        !validateDims(rhsBatchDims, rhsRank, "rhs_batching", rhsUsed, dimError) ||
        !validateDims(rhsContractingDims, rhsRank, "rhs_contracting", rhsUsed, dimError)) {
        return ProcessResult::Error(dimError);
    }

    for (size_t i = 0; i < lhsBatchDims.size(); ++i) {
        int64_t lhsDimSize = [lhsShape[(NSUInteger)lhsBatchDims[i]] longLongValue];
        int64_t rhsDimSize = [rhsShape[(NSUInteger)rhsBatchDims[i]] longLongValue];
        if (lhsDimSize <= 0 || rhsDimSize <= 0 || lhsDimSize != rhsDimSize) {
            return ProcessResult::Error(
                "dot_general: incompatible batch dimensions (lhs_shape=" + ShapeToString(lhsShape) +
                ", rhs_shape=" + ShapeToString(rhsShape) + ", lhs_batch=" + JoinInts(lhsBatchDims) +
                ", rhs_batch=" + JoinInts(rhsBatchDims) + ")");
        }
    }
    for (size_t i = 0; i < lhsContractingDims.size(); ++i) {
        int64_t lhsDimSize = [lhsShape[(NSUInteger)lhsContractingDims[i]] longLongValue];
        int64_t rhsDimSize = [rhsShape[(NSUInteger)rhsContractingDims[i]] longLongValue];
        if (lhsDimSize <= 0 || rhsDimSize <= 0 || lhsDimSize != rhsDimSize) {
            return ProcessResult::Error(
                "dot_general: incompatible contracting dimensions (lhs_shape=" +
                ShapeToString(lhsShape) + ", rhs_shape=" + ShapeToString(rhsShape) +
                ", lhs_contracting=" + JoinInts(lhsContractingDims) +
                ", rhs_contracting=" + JoinInts(rhsContractingDims) + ")");
        }
    }

    std::vector<int64_t> lhsBatch(lhsBatchDims.begin(), lhsBatchDims.end());
    std::vector<int64_t> rhsBatch(rhsBatchDims.begin(), rhsBatchDims.end());
    std::vector<int64_t> lhsContract(lhsContractingDims.begin(), lhsContractingDims.end());
    std::vector<int64_t> rhsContract(rhsContractingDims.begin(), rhsContractingDims.end());
    std::vector<int64_t> lhsFree = ComplementDims(lhsRank, lhsUsed);
    std::vector<int64_t> rhsFree = ComplementDims(rhsRank, rhsUsed);

    std::vector<int64_t> lhsPerm = lhsBatch;
    lhsPerm.insert(lhsPerm.end(), lhsFree.begin(), lhsFree.end());
    lhsPerm.insert(lhsPerm.end(), lhsContract.begin(), lhsContract.end());
    std::vector<int64_t> rhsPerm = rhsBatch;
    rhsPerm.insert(rhsPerm.end(), rhsContract.begin(), rhsContract.end());
    rhsPerm.insert(rhsPerm.end(), rhsFree.begin(), rhsFree.end());

    MPSGraphTensor* lhs = lhsInput;
    NSArray<NSNumber*>* lhsPermArray = ToNSArray(lhsPerm);
    if (!IsIdentityPermutation(lhsPermArray)) {
        lhs = [ctx.graph transposeTensor:lhsInput permutation:lhsPermArray name:nil];
    }

    MPSGraphTensor* rhs = rhsInput;
    NSArray<NSNumber*>* rhsPermArray = ToNSArray(rhsPerm);
    if (!IsIdentityPermutation(rhsPermArray)) {
        rhs = [ctx.graph transposeTensor:rhsInput permutation:rhsPermArray name:nil];
    }

    std::vector<int64_t> batchSizes = GetDimSizes(lhsShape, lhsBatchDims);
    std::vector<int64_t> lhsFreeSizes = GetDimSizes(lhsShape, lhsFree);
    std::vector<int64_t> rhsFreeSizes = GetDimSizes(rhsShape, rhsFree);
    std::vector<int64_t> contractingSizes = GetDimSizes(lhsShape, lhsContractingDims);

    int64_t m = 1;
    int64_t k = 1;
    int64_t n = 1;
    int64_t batchCheck = 1;
    if (!ProductDims(batchSizes, &batchCheck) || !ProductDims(lhsFreeSizes, &m) ||
        !ProductDims(contractingSizes, &k) || !ProductDims(rhsFreeSizes, &n)) {
        return ProcessResult::Error(
            "dot_general: unsupported non-positive or overflowing dimensions");
    }

    std::vector<int64_t> lhsMatShape = batchSizes;
    lhsMatShape.push_back(m);
    lhsMatShape.push_back(k);
    std::vector<int64_t> rhsMatShape = batchSizes;
    rhsMatShape.push_back(k);
    rhsMatShape.push_back(n);

    lhs = [ctx.graph reshapeTensor:lhs withShape:ToNSArray(lhsMatShape) name:nil];
    rhs = [ctx.graph reshapeTensor:rhs withShape:ToNSArray(rhsMatShape) name:nil];

    MPSGraphTensor* result =
        [ctx.graph matrixMultiplicationWithPrimaryTensor:lhs secondaryTensor:rhs name:nil];

    std::vector<int64_t> logicalOutputShape = batchSizes;
    logicalOutputShape.insert(logicalOutputShape.end(), lhsFreeSizes.begin(), lhsFreeSizes.end());
    logicalOutputShape.insert(logicalOutputShape.end(), rhsFreeSizes.begin(), rhsFreeSizes.end());

    NSArray<NSNumber*>* expectedOutputShape = GetOutputShape(ctx.op);
    if (expectedOutputShape) {
        result = [ctx.graph reshapeTensor:result withShape:expectedOutputShape name:nil];
    } else {
        result = [ctx.graph reshapeTensor:result withShape:ToNSArray(logicalOutputShape) name:nil];
    }

    return Result(ctx, result, "dot_general");
}
REGISTER_MPS_OP("stablehlo.dot_general", HandleDotGeneral);

// Compare operation
static ProcessResult HandleCompare(HandlerContext& ctx) {
    auto compareOp = mlir::dyn_cast<mlir::stablehlo::CompareOp>(ctx.op);
    if (!compareOp) {
        return ProcessResult::Error("compare: expected CompareOp");
    }

    MPSGraphTensor* lhs = GetInputTensor(ctx, 0);
    MPSGraphTensor* rhs = GetInputTensor(ctx, 1);
    if (!lhs || !rhs)
        return ProcessResult::Error("compare: missing input tensor");

    auto direction = compareOp.getComparisonDirection();
    using Dir = mlir::stablehlo::ComparisonDirection;

    MPSGraphTensor* result = nil;
    switch (direction) {
        case Dir::LT:
            result = [ctx.graph lessThanWithPrimaryTensor:lhs secondaryTensor:rhs name:nil];
            break;
        case Dir::LE:
            result = [ctx.graph lessThanOrEqualToWithPrimaryTensor:lhs
                                                   secondaryTensor:rhs
                                                              name:nil];
            break;
        case Dir::GT:
            result = [ctx.graph greaterThanWithPrimaryTensor:lhs secondaryTensor:rhs name:nil];
            break;
        case Dir::GE:
            result = [ctx.graph greaterThanOrEqualToWithPrimaryTensor:lhs
                                                      secondaryTensor:rhs
                                                                 name:nil];
            break;
        case Dir::EQ:
            result = [ctx.graph equalWithPrimaryTensor:lhs secondaryTensor:rhs name:nil];
            break;
        case Dir::NE:
            result = [ctx.graph notEqualWithPrimaryTensor:lhs secondaryTensor:rhs name:nil];
            break;
        default:
            return ProcessResult::Error("compare: unknown compare direction");
    }

    return Result(ctx, result, "compare");
}
REGISTER_MPS_OP("stablehlo.compare", HandleCompare);

// Select operation (conditional selection: pred ? true_val : false_val)
static ProcessResult HandleSelect(HandlerContext& ctx) {
    MPSGraphTensor* pred = GetInputTensor(ctx, 0);
    MPSGraphTensor* onTrue = GetInputTensor(ctx, 1);
    MPSGraphTensor* onFalse = GetInputTensor(ctx, 2);
    if (!pred || !onTrue || !onFalse)
        return ProcessResult::Error("select: missing input tensor");

    MPSGraphTensor* result = [ctx.graph selectWithPredicateTensor:pred
                                              truePredicateTensor:onTrue
                                             falsePredicateTensor:onFalse
                                                             name:nil];
    return Result(ctx, result, "select");
}
REGISTER_MPS_OP("stablehlo.select", HandleSelect);

// Clamp operation: clamp(min, x, max)
static ProcessResult HandleClamp(HandlerContext& ctx) {
    MPSGraphTensor* minVal = GetInputTensor(ctx, 0);
    MPSGraphTensor* operand = GetInputTensor(ctx, 1);
    MPSGraphTensor* maxVal = GetInputTensor(ctx, 2);
    if (!minVal || !operand || !maxVal)
        return ProcessResult::Error("clamp: missing input tensor");

    MPSGraphTensor* result = [ctx.graph clampWithTensor:operand
                                         minValueTensor:minVal
                                         maxValueTensor:maxVal
                                                   name:nil];
    return Result(ctx, result, "clamp");
}
REGISTER_MPS_OP("stablehlo.clamp", HandleClamp);

// next_after(x, y) - returns the next representable floating point value from x towards y
// Implementation follows IEEE 754 nextafter semantics:
// 1. If x == y, return y
// 2. If x or y is NaN, return NaN
// 3. If x == 0, return smallest subnormal with sign of y
// 4. Otherwise, treat x as integer bits and increment/decrement based on direction
static ProcessResult HandleNextAfter(HandlerContext& ctx) {
    MPSGraphTensor* x = GetInputTensor(ctx, 0);
    MPSGraphTensor* y = GetInputTensor(ctx, 1);
    if (!x || !y)
        return ProcessResult::Error("next_after: missing input tensor");

    MPSDataType dtype = x.dataType;

    // Handle scalar tensors - MPS reinterpretCast doesn't support rank-0
    NSArray<NSNumber*>* xShape = x.shape;
    bool isScalar = (xShape.count == 0);
    if (isScalar) {
        x = [ctx.graph reshapeTensor:x withShape:@[@1] name:nil];
        y = [ctx.graph reshapeTensor:y withShape:@[@1] name:nil];
    }

    // Constants
    MPSGraphTensor* zero = [ctx.graph constantWithScalar:0.0 dataType:dtype];
    MPSGraphTensor* one_int = [ctx.graph constantWithScalar:1 dataType:MPSDataTypeInt32];
    MPSGraphTensor* neg_one_int = [ctx.graph constantWithScalar:-1 dataType:MPSDataTypeInt32];
    MPSGraphTensor* min_positive_int = [ctx.graph constantWithScalar:1 dataType:MPSDataTypeInt32];
    MPSGraphTensor* min_negative_int = [ctx.graph constantWithScalar:0x80000001
                                                            dataType:MPSDataTypeInt32];

    // Bitcast x to int32 (reinterpret bits)
    MPSGraphTensor* x_as_int = [ctx.graph reinterpretCastTensor:x toType:MPSDataTypeInt32 name:nil];

    // Check if x == y
    MPSGraphTensor* x_eq_y = [ctx.graph equalWithPrimaryTensor:x secondaryTensor:y name:nil];

    // Check if x is zero
    MPSGraphTensor* x_is_zero = [ctx.graph equalWithPrimaryTensor:x secondaryTensor:zero name:nil];

    // Check if y > 0 (to determine direction when x == 0)
    MPSGraphTensor* y_gt_zero = [ctx.graph greaterThanWithPrimaryTensor:y
                                                        secondaryTensor:zero
                                                                   name:nil];

    // When x == 0, return smallest positive or negative subnormal
    MPSGraphTensor* zero_result_int = [ctx.graph selectWithPredicateTensor:y_gt_zero
                                                       truePredicateTensor:min_positive_int
                                                      falsePredicateTensor:min_negative_int
                                                                      name:nil];
    MPSGraphTensor* zero_result = [ctx.graph reinterpretCastTensor:zero_result_int
                                                            toType:dtype
                                                              name:nil];

    // For non-zero x, determine direction and increment/decrement
    // If x > 0 and y > x, or x < 0 and y > x: increment (add 1 to int representation)
    // If x > 0 and y < x, or x < 0 and y < x: decrement (subtract 1 from int representation)
    MPSGraphTensor* y_gt_x = [ctx.graph greaterThanWithPrimaryTensor:y secondaryTensor:x name:nil];

    // x > 0
    MPSGraphTensor* x_gt_zero = [ctx.graph greaterThanWithPrimaryTensor:x
                                                        secondaryTensor:zero
                                                                   name:nil];

    // Determine if we should increment the int representation
    // Increment when: (x > 0 && y > x) || (x < 0 && y < x)
    // Which simplifies to: (x > 0) == (y > x)
    MPSGraphTensor* should_increment = [ctx.graph equalWithPrimaryTensor:x_gt_zero
                                                         secondaryTensor:y_gt_x
                                                                    name:nil];

    // Compute the delta (+1 or -1)
    MPSGraphTensor* delta = [ctx.graph selectWithPredicateTensor:should_increment
                                             truePredicateTensor:one_int
                                            falsePredicateTensor:neg_one_int
                                                            name:nil];

    // Add delta to x_as_int
    MPSGraphTensor* result_int = [ctx.graph additionWithPrimaryTensor:x_as_int
                                                      secondaryTensor:delta
                                                                 name:nil];

    // Bitcast back to float
    MPSGraphTensor* non_zero_result = [ctx.graph reinterpretCastTensor:result_int
                                                                toType:dtype
                                                                  name:nil];

    // Select between zero and non-zero cases
    MPSGraphTensor* non_equal_result = [ctx.graph selectWithPredicateTensor:x_is_zero
                                                        truePredicateTensor:zero_result
                                                       falsePredicateTensor:non_zero_result
                                                                       name:nil];

    // If x == y, return y; otherwise return the computed result
    MPSGraphTensor* result = [ctx.graph selectWithPredicateTensor:x_eq_y
                                              truePredicateTensor:y
                                             falsePredicateTensor:non_equal_result
                                                             name:nil];

    // Reshape back to scalar if needed
    if (isScalar) {
        result = [ctx.graph reshapeTensor:result withShape:@[] name:nil];
    }

    return Result(ctx, result, "next_after");
}
REGISTER_MPS_OP("chlo.next_after", HandleNextAfter);

}  // namespace jax_silicon
