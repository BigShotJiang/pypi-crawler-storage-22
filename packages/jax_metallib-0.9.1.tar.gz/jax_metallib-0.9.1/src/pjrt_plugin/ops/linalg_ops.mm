// Linear algebra operations: cholesky, triangular_solve
// Uses native MPS kernels (MPSMatrixDecompositionCholesky, MPSMatrixSolveTriangular)
// via the NativeOpRegistry.

#import <MetalPerformanceShaders/MetalPerformanceShaders.h>

#import "pjrt_plugin/mps_buffer.h"
#import "pjrt_plugin/ops/registry.h"

#include <sstream>

#include "llvm/Support/raw_ostream.h"

namespace jax_silicon {

namespace {

std::string TypeToString(mlir::Type type) {
    std::string out;
    llvm::raw_string_ostream os(out);
    type.print(os);
    return os.str();
}

}  // namespace

// ---------------------------------------------------------------------------
// Helpers for MPS row-byte alignment.
// MPS requires 16-byte-aligned row strides; rowBytesFromColumns returns the
// recommended value (e.g. 16 for a 2-column float32 matrix instead of 8).
// When the data stride differs we blit rows into an aligned staging buffer
// before calling the MPS kernel and blit back afterwards.
// ---------------------------------------------------------------------------

/// Blit rows between buffers with different row strides and base offsets.
static void BlitRowsWithOffsets(id<MTLCommandBuffer> cmdBuf, id<MTLBuffer> src,
                                NSUInteger srcBaseOffset, NSUInteger srcRowBytes,
                                id<MTLBuffer> dst, NSUInteger dstBaseOffset,
                                NSUInteger dstRowBytes, int64_t rows, NSUInteger copyBytes) {
    id<MTLBlitCommandEncoder> blit = [cmdBuf blitCommandEncoder];
    for (int64_t r = 0; r < rows; r++) {
        [blit copyFromBuffer:src
                 sourceOffset:srcBaseOffset + (NSUInteger)r * srcRowBytes
                     toBuffer:dst
            destinationOffset:dstBaseOffset + (NSUInteger)r * dstRowBytes
                         size:copyBytes];
    }
    [blit endEncoding];
}

/// Blit rows between buffers with different row strides on the command buffer.
static void BlitRows(id<MTLCommandBuffer> cmdBuf, id<MTLBuffer> src, NSUInteger srcRowBytes,
                     id<MTLBuffer> dst, NSUInteger dstRowBytes, int64_t rows,
                     NSUInteger copyBytes) {
    BlitRowsWithOffsets(cmdBuf, src, 0, srcRowBytes, dst, 0, dstRowBytes, rows, copyBytes);
}

/// Allocate a zero-filled staging buffer and blit contiguous rows into it.
/// Returns the staging buffer, or the original buffer if no padding is needed.
static id<MTLBuffer> PadBuffer(id<MTLDevice> device, id<MTLCommandBuffer> cmdBuf, id<MTLBuffer> src,
                               int64_t rows, NSUInteger dataRowBytes, NSUInteger mpsRowBytes) {
    if (mpsRowBytes == dataRowBytes)
        return src;
    id<MTLBuffer> padded = [device newBufferWithLength:mpsRowBytes * (NSUInteger)rows
                                               options:MTLResourceStorageModeShared];
    memset(padded.contents, 0, mpsRowBytes * (NSUInteger)rows);
    BlitRows(cmdBuf, src, dataRowBytes, padded, mpsRowBytes, rows, dataRowBytes);
    return padded;
}

/// Blit rows from a padded staging buffer into a new contiguous output buffer.
/// Returns the padded buffer directly if no padding was needed.
static id<MTLBuffer> UnpadBuffer(id<MTLDevice> device, id<MTLCommandBuffer> cmdBuf,
                                 id<MTLBuffer> padded, int64_t rows, NSUInteger dataRowBytes,
                                 NSUInteger mpsRowBytes) {
    if (mpsRowBytes == dataRowBytes)
        return padded;
    size_t outSize = (size_t)rows * dataRowBytes;
    id<MTLBuffer> out = [device newBufferWithLength:outSize options:MTLResourceStorageModeShared];
    BlitRows(cmdBuf, padded, mpsRowBytes, out, dataRowBytes, rows, dataRowBytes);
    return out;
}

static bool ComputeBatchCount(llvm::ArrayRef<int64_t> shape, size_t matrixRank,
                              NSUInteger* batchCountOut) {
    if (shape.size() < matrixRank) {
        return false;
    }
    NSUInteger batchCount = 1;
    for (size_t i = 0; i < shape.size() - matrixRank; ++i) {
        if (shape[i] <= 0) {
            return false;
        }
        batchCount *= (NSUInteger)shape[i];
    }
    *batchCountOut = batchCount;
    return true;
}

static id<MTLComputePipelineState> GetCholeskyVerifyPipeline(id<MTLDevice> device) {
    static id<MTLComputePipelineState> verifyPipeline = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
      NSString* source = @"#include <metal_stdlib>\n"
                          "using namespace metal;\n"
                          "kernel void cholesky_verify(\n"
                          "    device float *allL [[buffer(0)]],\n"
                          "    constant uint &n [[buffer(1)]],\n"
                          "    constant uint &stride [[buffer(2)]],\n"
                          "    constant uint &sliceStride [[buffer(3)]],\n"
                          "    constant uint &batchCount [[buffer(4)]],\n"
                          "    uint tid [[thread_position_in_grid]]\n"
                          ") {\n"
                          "    if (tid >= batchCount) return;\n"
                          "    device float *L = allL + tid * sliceStride;\n"
                          "    for (uint j = 0; j < n; j++) {\n"
                          "        if (L[j * stride + j] <= 0.0f) {\n"
                          "            for (uint r = 0; r < n; r++)\n"
                          "                for (uint c = 0; c < n; c++)\n"
                          "                    L[r * stride + c] = NAN;\n"
                          "            return;\n"
                          "        }\n"
                          "    }\n"
                          "}\n";
      NSError* error = nil;
      id<MTLLibrary> lib = [device newLibraryWithSource:source options:nil error:&error];
      if (lib) {
          id<MTLFunction> func = [lib newFunctionWithName:@"cholesky_verify"];
          verifyPipeline = [device newComputePipelineStateWithFunction:func error:&error];
      }
      if (!verifyPipeline) {
          MPS_LOG_ERROR("cholesky: failed to compile verify shader: %s\n",
                        error.localizedDescription.UTF8String);
      }
    });
    return verifyPipeline;
}

static void EncodeCholeskyVerify(id<MTLDevice> device, id<MTLCommandBuffer> cmdBuf,
                                 id<MTLBuffer> resultBuf, uint32_t n, uint32_t lStride,
                                 uint32_t sliceStride, uint32_t batchCount) {
    id<MTLComputePipelineState> verifyPipeline = GetCholeskyVerifyPipeline(device);
    if (!verifyPipeline) {
        return;
    }

    id<MTLComputeCommandEncoder> enc = [cmdBuf computeCommandEncoder];
    [enc setComputePipelineState:verifyPipeline];
    [enc setBuffer:resultBuf offset:0 atIndex:0];
    [enc setBytes:&n length:sizeof(n) atIndex:1];
    [enc setBytes:&lStride length:sizeof(lStride) atIndex:2];
    [enc setBytes:&sliceStride length:sizeof(sliceStride) atIndex:3];
    [enc setBytes:&batchCount length:sizeof(batchCount) atIndex:4];
    [enc dispatchThreads:MTLSizeMake(batchCount, 1, 1) threadsPerThreadgroup:MTLSizeMake(1, 1, 1)];
    [enc endEncoding];
}

// ---------------------------------------------------------------------------
// Helpers for dtype casting between float16 and float32 (used for float16 linalg ops).
// ---------------------------------------------------------------------------

struct CastPipelines {
    id<MTLComputePipelineState> halfToFloat = nil;
    id<MTLComputePipelineState> floatToHalf = nil;
};

static CastPipelines GetCastPipelines(id<MTLDevice> device) {
    static CastPipelines pipelines;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
      NSString* source =
          @"#include <metal_stdlib>\n"
           "using namespace metal;\n"
           "kernel void cast_half_to_float_strided(\n"
           "    device const half* src [[buffer(0)]],\n"
           "    device float* dst [[buffer(1)]],\n"
           "    constant uint &rows [[buffer(2)]],\n"
           "    constant uint &cols [[buffer(3)]],\n"
           "    constant uint &dstRowStride [[buffer(4)]],\n"
           "    constant uint &dstSliceStride [[buffer(5)]],\n"
           "    constant uint &batchCount [[buffer(6)]],\n"
           "    uint gid [[thread_position_in_grid]]\n"
           ") {\n"
           "    uint count = batchCount * rows * cols;\n"
           "    if (gid >= count) return;\n"
           "    uint b = gid / (rows * cols);\n"
           "    uint rem = gid - b * rows * cols;\n"
           "    uint r = rem / cols;\n"
           "    uint c = rem - r * cols;\n"
           "    dst[b * dstSliceStride + r * dstRowStride + c] = float(src[b * rows * cols + r * cols + c]);\n"
           "}\n"
           "kernel void cast_float_to_half_strided(\n"
           "    device const float* src [[buffer(0)]],\n"
           "    device half* dst [[buffer(1)]],\n"
           "    constant uint &rows [[buffer(2)]],\n"
           "    constant uint &cols [[buffer(3)]],\n"
           "    constant uint &srcRowStride [[buffer(4)]],\n"
           "    constant uint &srcSliceStride [[buffer(5)]],\n"
           "    constant uint &batchCount [[buffer(6)]],\n"
           "    uint gid [[thread_position_in_grid]]\n"
           ") {\n"
           "    uint count = batchCount * rows * cols;\n"
           "    if (gid >= count) return;\n"
           "    uint b = gid / (rows * cols);\n"
           "    uint rem = gid - b * rows * cols;\n"
           "    uint r = rem / cols;\n"
           "    uint c = rem - r * cols;\n"
           "    dst[b * rows * cols + r * cols + c] = half(src[b * srcSliceStride + r * srcRowStride + c]);\n"
           "}\n";

      NSError* error = nil;
      id<MTLLibrary> lib = [device newLibraryWithSource:source options:nil error:&error];
      if (lib) {
          id<MTLFunction> h2f = [lib newFunctionWithName:@"cast_half_to_float_strided"];
          id<MTLFunction> f2h = [lib newFunctionWithName:@"cast_float_to_half_strided"];
          pipelines.halfToFloat = h2f ? [device newComputePipelineStateWithFunction:h2f error:&error] : nil;
          pipelines.floatToHalf = f2h ? [device newComputePipelineStateWithFunction:f2h error:&error] : nil;
      }
      if (!pipelines.halfToFloat || !pipelines.floatToHalf) {
          MPS_LOG_ERROR("linalg: failed to compile cast shaders: %s\n",
                        error.localizedDescription.UTF8String);
      }
    });
    return pipelines;
}

static bool EncodeCastHalfToFloatStrided(id<MTLDevice> device, id<MTLCommandBuffer> cmdBuf,
                                         id<MTLBuffer> srcHalfContig, id<MTLBuffer> dstFloatStrided,
                                         uint32_t rows, uint32_t cols, uint32_t dstRowStride,
                                         uint32_t dstSliceStride, uint32_t batchCount) {
    CastPipelines p = GetCastPipelines(device);
    if (!p.halfToFloat) {
        return false;
    }

    uint32_t count = batchCount * rows * cols;
    if (count == 0) {
        return true;
    }

    id<MTLComputeCommandEncoder> enc = [cmdBuf computeCommandEncoder];
    [enc setComputePipelineState:p.halfToFloat];
    [enc setBuffer:srcHalfContig offset:0 atIndex:0];
    [enc setBuffer:dstFloatStrided offset:0 atIndex:1];
    [enc setBytes:&rows length:sizeof(rows) atIndex:2];
    [enc setBytes:&cols length:sizeof(cols) atIndex:3];
    [enc setBytes:&dstRowStride length:sizeof(dstRowStride) atIndex:4];
    [enc setBytes:&dstSliceStride length:sizeof(dstSliceStride) atIndex:5];
    [enc setBytes:&batchCount length:sizeof(batchCount) atIndex:6];

    NSUInteger tg = MIN((NSUInteger)256, p.halfToFloat.maxTotalThreadsPerThreadgroup);
    [enc dispatchThreads:MTLSizeMake(count, 1, 1) threadsPerThreadgroup:MTLSizeMake(tg, 1, 1)];
    [enc endEncoding];
    return true;
}

static bool EncodeCastFloatToHalfStrided(id<MTLDevice> device, id<MTLCommandBuffer> cmdBuf,
                                         id<MTLBuffer> srcFloatStrided, id<MTLBuffer> dstHalfContig,
                                         uint32_t rows, uint32_t cols, uint32_t srcRowStride,
                                         uint32_t srcSliceStride, uint32_t batchCount) {
    CastPipelines p = GetCastPipelines(device);
    if (!p.floatToHalf) {
        return false;
    }

    uint32_t count = batchCount * rows * cols;
    if (count == 0) {
        return true;
    }

    id<MTLComputeCommandEncoder> enc = [cmdBuf computeCommandEncoder];
    [enc setComputePipelineState:p.floatToHalf];
    [enc setBuffer:srcFloatStrided offset:0 atIndex:0];
    [enc setBuffer:dstHalfContig offset:0 atIndex:1];
    [enc setBytes:&rows length:sizeof(rows) atIndex:2];
    [enc setBytes:&cols length:sizeof(cols) atIndex:3];
    [enc setBytes:&srcRowStride length:sizeof(srcRowStride) atIndex:4];
    [enc setBytes:&srcSliceStride length:sizeof(srcSliceStride) atIndex:5];
    [enc setBytes:&batchCount length:sizeof(batchCount) atIndex:6];

    NSUInteger tg = MIN((NSUInteger)256, p.floatToHalf.maxTotalThreadsPerThreadgroup);
    [enc dispatchThreads:MTLSizeMake(count, 1, 1) threadsPerThreadgroup:MTLSizeMake(tg, 1, 1)];
    [enc endEncoding];
    return true;
}

// ---------------------------------------------------------------------------
// stablehlo.cholesky – native MPSMatrixDecompositionCholesky
// ---------------------------------------------------------------------------

static id<MTLBuffer> NativeHandle_cholesky(id<MTLDevice> device, id<MTLCommandBuffer> cmdBuf,
                                           mlir::Operation* op,
                                           const std::vector<id<MTLBuffer>>& inputs) {
    auto choleskyOp = mlir::dyn_cast<mlir::stablehlo::CholeskyOp>(op);
    if (!choleskyOp) {
        MPS_LOG_ERROR("cholesky: expected CholeskyOp\n");
        return nil;
    }

    bool lower = true;
    if (choleskyOp.getLowerAttr()) {
        lower = choleskyOp.getLower();
    }

    auto resultType = mlir::cast<mlir::RankedTensorType>(op->getResult(0).getType());
    auto shape = resultType.getShape();
    if (shape.size() < 2) {
        MPS_LOG_ERROR("cholesky: expected rank >= 2 input (got rank %zu)\n", shape.size());
        return nil;
    }
    int64_t n = shape.back();
    if (shape[shape.size() - 2] != n) {
        MPS_LOG_ERROR("cholesky: expected square matrices in last two dims (got %lld x %lld)\n",
                      (long long)shape[shape.size() - 2], (long long)n);
        return nil;
    }

    if (!resultType.getElementType().isF32()) {
        MPS_LOG_ERROR("cholesky: only float32 is supported (got %s)\n",
                      TypeToString(resultType.getElementType()).c_str());
        return nil;
    }

    NSUInteger batchCount = 0;
    if (!ComputeBatchCount(shape, 2, &batchCount)) {
        MPS_LOG_ERROR("cholesky: invalid batch dimensions in input shape\n");
        return nil;
    }

    MPSDataType mps_dtype = MlirTypeToMps(resultType.getElementType());
    int pjrt_dtype = MlirTypeToPjrtDtype(resultType.getElementType());
    size_t elem_size = DtypeByteSize(pjrt_dtype);
    NSUInteger dataRowBytes = (NSUInteger)(n * (int64_t)elem_size);
    NSUInteger mpsRowBytes = [MPSMatrixDescriptor rowBytesFromColumns:(NSUInteger)n
                                                             dataType:mps_dtype];
    NSUInteger dataSliceBytes = dataRowBytes * (NSUInteger)n;
    NSUInteger mpsSliceBytes = mpsRowBytes * (NSUInteger)n;
    uint32_t n32 = (uint32_t)n;
    uint32_t lStride = (uint32_t)(mpsRowBytes / elem_size);
    uint32_t sliceStride = lStride * n32;

    MPSMatrixDescriptor* desc = [MPSMatrixDescriptor matrixDescriptorWithRows:(NSUInteger)n
                                                                      columns:(NSUInteger)n
                                                                     rowBytes:mpsRowBytes
                                                                     dataType:mps_dtype];
    MPSMatrixDecompositionCholesky* cholesky =
        [[MPSMatrixDecompositionCholesky alloc] initWithDevice:device
                                                         lower:lower
                                                         order:(NSUInteger)n];
    if (!cholesky) {
        MPS_LOG_ERROR("cholesky: failed to create native MPS cholesky kernel\n");
        return nil;
    }

    // Fast path for rank-2 input.
    if (shape.size() == 2) {
        id<MTLBuffer> srcBuf = PadBuffer(device, cmdBuf, inputs[0], n, dataRowBytes, mpsRowBytes);
        id<MTLBuffer> resultBuf = [device newBufferWithLength:mpsSliceBytes
                                                      options:MTLResourceStorageModeShared];
        memset(resultBuf.contents, 0, mpsSliceBytes);
        MPSMatrix* sourceMatrix = [[MPSMatrix alloc] initWithBuffer:srcBuf descriptor:desc];
        MPSMatrix* resultMatrix = [[MPSMatrix alloc] initWithBuffer:resultBuf descriptor:desc];

        // The status buffer is unreliable on Apple Silicon — it always writes 0
        // (success) regardless of whether the input is positive definite.
        // See https://developer.apple.com/forums/thread/736787
        [cholesky encodeToCommandBuffer:cmdBuf
                           sourceMatrix:sourceMatrix
                           resultMatrix:resultMatrix
                                 status:nil];

        EncodeCholeskyVerify(device, cmdBuf, resultBuf, n32, lStride, sliceStride, 1);
        return UnpadBuffer(device, cmdBuf, resultBuf, n, dataRowBytes, mpsRowBytes);
    }

    // Batched rank>2 path.
    bool needsPadding = mpsRowBytes != dataRowBytes;
    id<MTLBuffer> srcBuf = inputs[0];
    NSUInteger srcSliceBytes = dataSliceBytes;
    if (needsPadding) {
        srcSliceBytes = mpsSliceBytes;
        srcBuf = [device newBufferWithLength:mpsSliceBytes * batchCount
                                     options:MTLResourceStorageModeShared];
        memset(srcBuf.contents, 0, mpsSliceBytes * batchCount);
        for (NSUInteger b = 0; b < batchCount; ++b) {
            BlitRowsWithOffsets(cmdBuf, inputs[0], b * dataSliceBytes, dataRowBytes, srcBuf,
                                b * mpsSliceBytes, mpsRowBytes, n, dataRowBytes);
        }
    }

    id<MTLBuffer> resultBuf = [device newBufferWithLength:mpsSliceBytes * batchCount
                                                  options:MTLResourceStorageModeShared];
    memset(resultBuf.contents, 0, mpsSliceBytes * batchCount);

    for (NSUInteger b = 0; b < batchCount; ++b) {
        MPSMatrix* sourceMatrix =
            [[MPSMatrix alloc] initWithBuffer:srcBuf
                                       offset:b * srcSliceBytes
                                   descriptor:desc];
        MPSMatrix* resultMatrix =
            [[MPSMatrix alloc] initWithBuffer:resultBuf
                                       offset:b * mpsSliceBytes
                                   descriptor:desc];
        [cholesky encodeToCommandBuffer:cmdBuf
                           sourceMatrix:sourceMatrix
                           resultMatrix:resultMatrix
                                 status:nil];
    }

    EncodeCholeskyVerify(device, cmdBuf, resultBuf, n32, lStride, sliceStride,
                         (uint32_t)batchCount);

    if (!needsPadding) {
        return resultBuf;
    }

    id<MTLBuffer> outBuf = [device newBufferWithLength:dataSliceBytes * batchCount
                                               options:MTLResourceStorageModeShared];
    for (NSUInteger b = 0; b < batchCount; ++b) {
        BlitRowsWithOffsets(cmdBuf, resultBuf, b * mpsSliceBytes, mpsRowBytes, outBuf,
                            b * dataSliceBytes, dataRowBytes, n, dataRowBytes);
    }
    return outBuf;
}

REGISTER_NATIVE_MPS_OP("stablehlo.cholesky", NativeHandle_cholesky);

// ---------------------------------------------------------------------------
// stablehlo.triangular_solve – native MPSMatrixSolveTriangular
// ---------------------------------------------------------------------------

static id<MTLBuffer> NativeHandle_triangular_solve(id<MTLDevice> device,
                                                   id<MTLCommandBuffer> cmdBuf, mlir::Operation* op,
                                                   const std::vector<id<MTLBuffer>>& inputs) {
    auto triSolveOp = mlir::dyn_cast<mlir::stablehlo::TriangularSolveOp>(op);
    if (!triSolveOp) {
        MPS_LOG_ERROR("triangular_solve: expected TriangularSolveOp\n");
        return nil;
    }

    bool leftSide = triSolveOp.getLeftSide();
    bool lower = triSolveOp.getLower();
    bool unitDiagonal = triSolveOp.getUnitDiagonal();
    auto transposeA = triSolveOp.getTransposeA();
    bool transpose = (transposeA == mlir::stablehlo::Transpose::TRANSPOSE ||
                      transposeA == mlir::stablehlo::Transpose::ADJOINT);

    auto aType = mlir::cast<mlir::RankedTensorType>(op->getOperand(0).getType());
    auto bType = mlir::cast<mlir::RankedTensorType>(op->getOperand(1).getType());
    auto aShape = aType.getShape();
    auto bShape = bType.getShape();
    if (aShape.size() < 2 || bShape.size() < 2) {
        MPS_LOG_ERROR("triangular_solve: expected rank >= 2 inputs (got ranks %zu, %zu)\n",
                      aShape.size(), bShape.size());
        return nil;
    }
    if (aShape.size() != bShape.size()) {
        MPS_LOG_ERROR(
            "triangular_solve: unsupported layout (A and B must have same rank, got %zu and %zu)\n",
            aShape.size(), bShape.size());
        return nil;
    }
    bool aOk = aType.getElementType().isF32() || aType.getElementType().isF16();
    bool bOk = bType.getElementType().isF32() || bType.getElementType().isF16();
    if (!aOk || !bOk || aType.getElementType() != bType.getElementType()) {
        MPS_LOG_ERROR(
            "triangular_solve: only matching float16/float32 dtypes are supported (got A=%s, B=%s)\n",
            TypeToString(aType.getElementType()).c_str(), TypeToString(bType.getElementType()).c_str());
        return nil;
    }

    int64_t n = aShape.back();
    int64_t aRows = aShape[aShape.size() - 2];
    if (aRows != n) {
        MPS_LOG_ERROR("triangular_solve: A must be square in last two dims (got %lld x %lld)\n",
                      (long long)aRows, (long long)n);
        return nil;
    }

    int64_t bRows = bShape[bShape.size() - 2];
    int64_t bCols = bShape[bShape.size() - 1];
    if ((leftSide && bRows != n) || (!leftSide && bCols != n)) {
        MPS_LOG_ERROR(
            "triangular_solve: incompatible matrix dimensions for left_side=%d (A=%lldx%lld, B=%lldx%lld)\n",
            leftSide ? 1 : 0, (long long)aRows, (long long)n, (long long)bRows,
            (long long)bCols);
        return nil;
    }

    size_t batchRank = aShape.size() - 2;
    for (size_t i = 0; i < batchRank; ++i) {
        if (aShape[i] != bShape[i] || aShape[i] <= 0) {
            MPS_LOG_ERROR(
                "triangular_solve: unsupported batch layout (A and B batch dims must match and be > 0)\n");
            return nil;
        }
    }

    NSUInteger batchCount = 0;
    if (!ComputeBatchCount(aShape, 2, &batchCount)) {
        MPS_LOG_ERROR("triangular_solve: invalid batch dimensions in A shape\n");
        return nil;
    }

    // MPSMatrixSolveTriangular appears to be unreliable for float16 on some platforms.
    // Upcast to float32 for compute, then downcast to float16 output.
    bool isF16 = aType.getElementType().isF16();
    if (isF16) {
        uint32_t n32 = (uint32_t)n;
        uint32_t bRows32 = (uint32_t)bRows;
        uint32_t bCols32 = (uint32_t)bCols;
        uint32_t batchCount32 = (uint32_t)batchCount;

        // Float32 row strides and slice strides (MPS-aligned).
        MPSDataType computeDtype = MPSDataTypeFloat32;
        NSUInteger aRowBytes32 = [MPSMatrixDescriptor rowBytesFromColumns:(NSUInteger)n
                                                                 dataType:computeDtype];
        NSUInteger bRowBytes32 = [MPSMatrixDescriptor rowBytesFromColumns:(NSUInteger)bCols
                                                                 dataType:computeDtype];
        NSUInteger aSliceBytes32 = aRowBytes32 * (NSUInteger)n;
        NSUInteger bSliceBytes32 = bRowBytes32 * (NSUInteger)bRows;
        uint32_t aStride32 = (uint32_t)(aRowBytes32 / sizeof(float));
        uint32_t bStride32 = (uint32_t)(bRowBytes32 / sizeof(float));
        uint32_t aSliceStride32 = aStride32 * n32;
        uint32_t bSliceStride32 = bStride32 * bRows32;

        // Original float16 output layout (contiguous).
        NSUInteger bDataRowBytes16 = (NSUInteger)(bCols * (int64_t)sizeof(uint16_t));
        NSUInteger bDataSliceBytes16 = bDataRowBytes16 * (NSUInteger)bRows;

        id<MTLBuffer> a32Buf = [device newBufferWithLength:aSliceBytes32 * batchCount
                                                   options:MTLResourceStorageModeShared];
        id<MTLBuffer> b32Buf = [device newBufferWithLength:bSliceBytes32 * batchCount
                                                   options:MTLResourceStorageModeShared];
        memset(a32Buf.contents, 0, aSliceBytes32 * batchCount);
        memset(b32Buf.contents, 0, bSliceBytes32 * batchCount);

        if (!EncodeCastHalfToFloatStrided(device, cmdBuf, inputs[0], a32Buf, n32, n32, aStride32,
                                          aSliceStride32, batchCount32) ||
            !EncodeCastHalfToFloatStrided(device, cmdBuf, inputs[1], b32Buf, bRows32, bCols32,
                                          bStride32, bSliceStride32, batchCount32)) {
            MPS_LOG_ERROR("triangular_solve: failed to encode float16->float32 cast kernels\n");
            return nil;
        }

        MPSMatrixDescriptor* aDesc = [MPSMatrixDescriptor matrixDescriptorWithRows:(NSUInteger)n
                                                                            columns:(NSUInteger)n
                                                                           rowBytes:aRowBytes32
                                                                           dataType:computeDtype];
        MPSMatrixDescriptor* bDesc = [MPSMatrixDescriptor matrixDescriptorWithRows:(NSUInteger)bRows
                                                                            columns:(NSUInteger)bCols
                                                                           rowBytes:bRowBytes32
                                                                           dataType:computeDtype];

        id<MTLBuffer> sol32Buf = [device newBufferWithLength:bSliceBytes32 * batchCount
                                                    options:MTLResourceStorageModeShared];

        NSUInteger nrhsLocal = leftSide ? (NSUInteger)bCols : (NSUInteger)bRows;
        MPSMatrixSolveTriangular* solver =
            [[MPSMatrixSolveTriangular alloc] initWithDevice:device
                                                       right:!leftSide
                                                       upper:!lower
                                                   transpose:transpose
                                                        unit:unitDiagonal
                                                       order:(NSUInteger)n
                                      numberOfRightHandSides:nrhsLocal
                                                       alpha:1.0];
        if (!solver) {
            MPS_LOG_ERROR("triangular_solve: failed to create native MPS solver\n");
            return nil;
        }

        for (NSUInteger b = 0; b < batchCount; ++b) {
            MPSMatrix* sourceMatrix =
                [[MPSMatrix alloc] initWithBuffer:a32Buf offset:b * aSliceBytes32 descriptor:aDesc];
            MPSMatrix* rhsMatrix =
                [[MPSMatrix alloc] initWithBuffer:b32Buf offset:b * bSliceBytes32 descriptor:bDesc];
            MPSMatrix* solutionMatrix =
                [[MPSMatrix alloc] initWithBuffer:sol32Buf offset:b * bSliceBytes32 descriptor:bDesc];
            [solver encodeToCommandBuffer:cmdBuf
                             sourceMatrix:sourceMatrix
                      rightHandSideMatrix:rhsMatrix
                           solutionMatrix:solutionMatrix];
        }

        id<MTLBuffer> out16Buf =
            [device newBufferWithLength:bDataSliceBytes16 * batchCount
                                options:MTLResourceStorageModeShared];
        if (!EncodeCastFloatToHalfStrided(device, cmdBuf, sol32Buf, out16Buf, bRows32, bCols32,
                                          bStride32, bSliceStride32, batchCount32)) {
            MPS_LOG_ERROR("triangular_solve: failed to encode float32->float16 cast kernel\n");
            return nil;
        }
        return out16Buf;
    }

    MPSDataType mps_dtype = MlirTypeToMps(bType.getElementType());
    int pjrt_dtype = MlirTypeToPjrtDtype(bType.getElementType());
    size_t elem_size = DtypeByteSize(pjrt_dtype);

    // Number of right-hand sides depends on whether A is on the left or right.
    NSUInteger nrhs = leftSide ? (NSUInteger)bCols : (NSUInteger)bRows;

    // Row strides: data-contiguous vs MPS-recommended.
    NSUInteger aDataRowBytes = (NSUInteger)(n * (int64_t)elem_size);
    NSUInteger aMpsRowBytes = [MPSMatrixDescriptor rowBytesFromColumns:(NSUInteger)n
                                                              dataType:mps_dtype];
    NSUInteger bDataRowBytes = (NSUInteger)(bCols * (int64_t)elem_size);
    NSUInteger bMpsRowBytes = [MPSMatrixDescriptor rowBytesFromColumns:(NSUInteger)bCols
                                                              dataType:mps_dtype];
    NSUInteger aDataSliceBytes = aDataRowBytes * (NSUInteger)n;
    NSUInteger aMpsSliceBytes = aMpsRowBytes * (NSUInteger)n;
    NSUInteger bDataSliceBytes = bDataRowBytes * (NSUInteger)bRows;
    NSUInteger bMpsSliceBytes = bMpsRowBytes * (NSUInteger)bRows;

    // Fast path for rank-2 input.
    if (aShape.size() == 2) {
        id<MTLBuffer> aBuf = PadBuffer(device, cmdBuf, inputs[0], n, aDataRowBytes, aMpsRowBytes);
        id<MTLBuffer> bBuf =
            PadBuffer(device, cmdBuf, inputs[1], bRows, bDataRowBytes, bMpsRowBytes);

        MPSMatrixDescriptor* aDesc = [MPSMatrixDescriptor matrixDescriptorWithRows:(NSUInteger)n
                                                                            columns:(NSUInteger)n
                                                                           rowBytes:aMpsRowBytes
                                                                           dataType:mps_dtype];
        MPSMatrixDescriptor* bDesc =
            [MPSMatrixDescriptor matrixDescriptorWithRows:(NSUInteger)bRows
                                                  columns:(NSUInteger)bCols
                                                 rowBytes:bMpsRowBytes
                                                 dataType:mps_dtype];
        MPSMatrix* sourceMatrix = [[MPSMatrix alloc] initWithBuffer:aBuf descriptor:aDesc];
        MPSMatrix* rhsMatrix = [[MPSMatrix alloc] initWithBuffer:bBuf descriptor:bDesc];
        id<MTLBuffer> solBuf = [device newBufferWithLength:bMpsSliceBytes
                                                   options:MTLResourceStorageModeShared];
        MPSMatrix* solutionMatrix = [[MPSMatrix alloc] initWithBuffer:solBuf descriptor:bDesc];

        MPSMatrixSolveTriangular* solver =
            [[MPSMatrixSolveTriangular alloc] initWithDevice:device
                                                       right:!leftSide
                                                       upper:!lower
                                                   transpose:transpose
                                                        unit:unitDiagonal
                                                       order:(NSUInteger)n
                                      numberOfRightHandSides:nrhs
                                                       alpha:1.0];
        if (!solver) {
            MPS_LOG_ERROR("triangular_solve: failed to create native MPS solver\n");
            return nil;
        }

        [solver encodeToCommandBuffer:cmdBuf
                         sourceMatrix:sourceMatrix
                  rightHandSideMatrix:rhsMatrix
                       solutionMatrix:solutionMatrix];
        return UnpadBuffer(device, cmdBuf, solBuf, bRows, bDataRowBytes, bMpsRowBytes);
    }

    // Batched rank>2 path.
    bool aNeedsPadding = aMpsRowBytes != aDataRowBytes;
    bool bNeedsPadding = bMpsRowBytes != bDataRowBytes;

    id<MTLBuffer> aBuf = inputs[0];
    NSUInteger aSliceBytes = aDataSliceBytes;
    if (aNeedsPadding) {
        aSliceBytes = aMpsSliceBytes;
        aBuf = [device newBufferWithLength:aMpsSliceBytes * batchCount
                                   options:MTLResourceStorageModeShared];
        memset(aBuf.contents, 0, aMpsSliceBytes * batchCount);
        for (NSUInteger b = 0; b < batchCount; ++b) {
            BlitRowsWithOffsets(cmdBuf, inputs[0], b * aDataSliceBytes, aDataRowBytes, aBuf,
                                b * aMpsSliceBytes, aMpsRowBytes, n, aDataRowBytes);
        }
    }

    id<MTLBuffer> bBuf = inputs[1];
    NSUInteger bSliceBytes = bDataSliceBytes;
    if (bNeedsPadding) {
        bSliceBytes = bMpsSliceBytes;
        bBuf = [device newBufferWithLength:bMpsSliceBytes * batchCount
                                   options:MTLResourceStorageModeShared];
        memset(bBuf.contents, 0, bMpsSliceBytes * batchCount);
        for (NSUInteger b = 0; b < batchCount; ++b) {
            BlitRowsWithOffsets(cmdBuf, inputs[1], b * bDataSliceBytes, bDataRowBytes, bBuf,
                                b * bMpsSliceBytes, bMpsRowBytes, bRows, bDataRowBytes);
        }
    }

    MPSMatrixDescriptor* aDesc = [MPSMatrixDescriptor matrixDescriptorWithRows:(NSUInteger)n
                                                                        columns:(NSUInteger)n
                                                                       rowBytes:aMpsRowBytes
                                                                       dataType:mps_dtype];
    MPSMatrixDescriptor* bDesc = [MPSMatrixDescriptor matrixDescriptorWithRows:(NSUInteger)bRows
                                                                        columns:(NSUInteger)bCols
                                                                       rowBytes:bMpsRowBytes
                                                                       dataType:mps_dtype];
    id<MTLBuffer> solBuf = [device newBufferWithLength:bMpsSliceBytes * batchCount
                                               options:MTLResourceStorageModeShared];

    MPSMatrixSolveTriangular* solver =
        [[MPSMatrixSolveTriangular alloc] initWithDevice:device
                                                   right:!leftSide
                                                   upper:!lower
                                               transpose:transpose
                                                    unit:unitDiagonal
                                                   order:(NSUInteger)n
                                  numberOfRightHandSides:nrhs
                                                   alpha:1.0];
    if (!solver) {
        MPS_LOG_ERROR("triangular_solve: failed to create native MPS solver\n");
        return nil;
    }

    for (NSUInteger b = 0; b < batchCount; ++b) {
        MPSMatrix* sourceMatrix =
            [[MPSMatrix alloc] initWithBuffer:aBuf offset:b * aSliceBytes descriptor:aDesc];
        MPSMatrix* rhsMatrix =
            [[MPSMatrix alloc] initWithBuffer:bBuf offset:b * bSliceBytes descriptor:bDesc];
        MPSMatrix* solutionMatrix =
            [[MPSMatrix alloc] initWithBuffer:solBuf offset:b * bMpsSliceBytes descriptor:bDesc];
        [solver encodeToCommandBuffer:cmdBuf
                         sourceMatrix:sourceMatrix
                  rightHandSideMatrix:rhsMatrix
                       solutionMatrix:solutionMatrix];
    }

    if (!bNeedsPadding) {
        return solBuf;
    }

    id<MTLBuffer> outBuf = [device newBufferWithLength:bDataSliceBytes * batchCount
                                               options:MTLResourceStorageModeShared];
    for (NSUInteger b = 0; b < batchCount; ++b) {
        BlitRowsWithOffsets(cmdBuf, solBuf, b * bMpsSliceBytes, bMpsRowBytes, outBuf,
                            b * bDataSliceBytes, bDataRowBytes, bRows, bDataRowBytes);
    }
    return outBuf;
}

REGISTER_NATIVE_MPS_OP("stablehlo.triangular_solve", NativeHandle_triangular_solve);

}  // namespace jax_silicon
