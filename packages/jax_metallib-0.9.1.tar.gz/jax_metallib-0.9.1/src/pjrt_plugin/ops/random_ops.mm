// Random operations (StableHLO RNG ops).
//
// NOTE: JAX's PRNG is usually lowered to deterministic bitwise computations, not StableHLO RNG
// ops. When these ops do appear, correctness requires exact algorithm + determinism, so we fail
// explicitly with actionable diagnostics until we have a vetted implementation.

#import "pjrt_plugin/ops/registry.h"

#include "pjrt_plugin/issue_url.h"

namespace jax_silicon {

static ProcessResult HandleRng(HandlerContext& ctx) {
    auto rngOp = mlir::dyn_cast<mlir::stablehlo::RngOp>(ctx.op);
    if (!rngOp) {
        return ProcessResult::Error("rng: expected RngOp");
    }

    return ProcessResult::Error(
        "rng: stablehlo.rng is intentionally unsupported on MPS (determinism/algorithm semantics "
        "not implemented).\n\n" +
        UnsupportedOpsMessage({"stablehlo.rng"}));
}
REGISTER_MPS_OP("stablehlo.rng", HandleRng);

static ProcessResult HandleRngBitGenerator(HandlerContext& ctx) {
    auto op = mlir::dyn_cast<mlir::stablehlo::RngBitGeneratorOp>(ctx.op);
    if (!op) {
        return ProcessResult::Error("rng_bit_generator: expected RngBitGeneratorOp");
    }

    return ProcessResult::Error(
        "rng_bit_generator: stablehlo.rng_bit_generator is intentionally unsupported on MPS "
        "(determinism/algorithm semantics not implemented).\n\n" +
        UnsupportedOpsMessage({"stablehlo.rng_bit_generator"}));
}
REGISTER_MPS_OP("stablehlo.rng_bit_generator", HandleRngBitGenerator);

}  // namespace jax_silicon

