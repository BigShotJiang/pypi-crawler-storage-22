// Reduction operations: reduce (sum, product, max, min, and, or, argmax, argmin)

#import "pjrt_plugin/ops/registry.h"
#include "stablehlo/dialect/StablehloOps.h"
#include <cmath>
#include <sstream>

namespace jax_silicon {

namespace {

// Helper to identify the reduction operation type from the region body
// Returns the operation name if it's a simple binary reduction, empty string otherwise
std::string GetReductionOpType(mlir::Region& body) {
    if (body.empty())
        return "";

    mlir::Block& block = body.front();

    // The reduction body should have exactly one operation (plus terminator)
    // that is the reduction function
    for (mlir::Operation& op : block) {
        std::string opName = op.getName().getStringRef().str();

        // Skip the terminator (stablehlo.return)
        if (opName == "stablehlo.return")
            continue;

        // Return the first binary operation we find
        return opName;
    }

    return "";
}

// For detecting argmax/argmin patterns in multi-result reduce
enum class ArgReduceKind { kUnknown, kMax, kMin };

bool IsBlockArg(mlir::Value value, mlir::Block& block, unsigned index) {
    auto arg = mlir::dyn_cast<mlir::BlockArgument>(value);
    return arg && arg.getOwner() == &block && arg.getArgNumber() == index;
}

ArgReduceKind detectArgReduceKind(mlir::stablehlo::ReduceOp reduceOp) {
    if (reduceOp.getBody().empty()) {
        return ArgReduceKind::kUnknown;
    }
    mlir::Block& body = reduceOp.getBody().front();
    if (body.getNumArguments() < 4) {
        return ArgReduceKind::kUnknown;
    }

    for (mlir::Operation& nestedOp : body) {
        auto compareOp = mlir::dyn_cast<mlir::stablehlo::CompareOp>(&nestedOp);
        if (!compareOp) {
            continue;
        }

        bool forwardValueCompare =
            IsBlockArg(compareOp.getLhs(), body, 0) && IsBlockArg(compareOp.getRhs(), body, 2);
        bool reversedValueCompare =
            IsBlockArg(compareOp.getLhs(), body, 2) && IsBlockArg(compareOp.getRhs(), body, 0);
        if (!forwardValueCompare && !reversedValueCompare) {
            continue;
        }

        auto dir = compareOp.getComparisonDirection();
        bool lhsWins = false;
        if (dir == mlir::stablehlo::ComparisonDirection::GT ||
            dir == mlir::stablehlo::ComparisonDirection::GE) {
            lhsWins = true;
        } else if (dir == mlir::stablehlo::ComparisonDirection::LT ||
                   dir == mlir::stablehlo::ComparisonDirection::LE) {
            lhsWins = false;
        } else {
            continue;
        }

        // If the compare operands are swapped, the max/min interpretation flips.
        if (reversedValueCompare) {
            lhsWins = !lhsWins;
        }
        return lhsWins ? ArgReduceKind::kMax : ArgReduceKind::kMin;
    }
    return ArgReduceKind::kUnknown;
}

std::string JoinInts(llvm::ArrayRef<int64_t> values) {
    std::ostringstream oss;
    oss << "[";
    for (size_t i = 0; i < values.size(); ++i) {
        if (i > 0) {
            oss << ", ";
        }
        oss << values[i];
    }
    oss << "]";
    return oss.str();
}

std::string JoinPadding(const std::vector<std::pair<int64_t, int64_t>>& padding) {
    std::ostringstream oss;
    oss << "[";
    for (size_t i = 0; i < padding.size(); ++i) {
        if (i > 0) {
            oss << ", ";
        }
        oss << "[" << padding[i].first << ", " << padding[i].second << "]";
    }
    oss << "]";
    return oss.str();
}

bool ReadArrayOrDefaultOnes(std::optional<llvm::ArrayRef<int64_t>> attr, size_t rank,
                            std::vector<int64_t>& out) {
    out.assign(rank, 1);
    if (!attr.has_value()) {
        return true;
    }
    if (attr->size() != rank) {
        return false;
    }
    out.assign(attr->begin(), attr->end());
    return true;
}

bool ReadPaddingOrDefaultZeros(std::optional<mlir::DenseIntElementsAttr> paddingAttr, size_t rank,
                               std::vector<std::pair<int64_t, int64_t>>& out) {
    out.clear();
    out.resize(rank, {0, 0});
    if (!paddingAttr.has_value()) {
        return true;
    }

    std::vector<int64_t> flatPadding;
    flatPadding.reserve(rank * 2);
    for (int64_t value : paddingAttr->getValues<int64_t>()) {
        flatPadding.push_back(value);
    }
    if (flatPadding.size() != rank * 2) {
        return false;
    }

    for (size_t i = 0; i < rank; ++i) {
        out[i] = {flatPadding[2 * i], flatPadding[2 * i + 1]};
    }
    return true;
}

std::string DescribeReduceWindowPattern(mlir::stablehlo::ReduceWindowOp op, llvm::ArrayRef<int64_t> windowDims,
                                        llvm::ArrayRef<int64_t> windowStrides,
                                        llvm::ArrayRef<int64_t> baseDilations,
                                        llvm::ArrayRef<int64_t> windowDilations,
                                        const std::vector<std::pair<int64_t, int64_t>>& padding,
                                        const std::string& reducerType) {
    std::ostringstream oss;
    oss << "reducer=" << reducerType << ", window_dimensions=" << JoinInts(windowDims)
        << ", window_strides=" << JoinInts(windowStrides)
        << ", base_dilations=" << JoinInts(baseDilations)
        << ", window_dilations=" << JoinInts(windowDilations)
        << ", padding=" << JoinPadding(padding) << ", input_shape=";
    auto inputType =
        mlir::dyn_cast<mlir::RankedTensorType>(op.getInputs().front().getType());
    if (!inputType) {
        oss << "<unranked>";
    } else {
        oss << JoinInts(inputType.getShape());
    }
    return oss.str();
}

bool GetScalarConstantAttr(mlir::Value value, mlir::DenseElementsAttr& outDense) {
    outDense = {};
    if (!value) {
        return false;
    }
    auto* defOp = value.getDefiningOp();
    auto constOp = mlir::dyn_cast_or_null<mlir::stablehlo::ConstantOp>(defOp);
    if (!constOp) {
        return false;
    }
    auto denseAttr = mlir::dyn_cast<mlir::DenseElementsAttr>(constOp.getValue());
    if (!denseAttr) {
        return false;
    }
    if (denseAttr.getNumElements() != 1) {
        return false;
    }
    outDense = denseAttr;
    return true;
}

bool IsScalarZero(mlir::Value value) {
    mlir::DenseElementsAttr dense;
    if (!GetScalarConstantAttr(value, dense)) {
        return false;
    }
    auto elemType = dense.getElementType();
    if (mlir::isa<mlir::FloatType>(elemType)) {
        llvm::APFloat ap = *dense.getValues<llvm::APFloat>().begin();
        return ap.isZero();
    }
    if (auto intType = mlir::dyn_cast<mlir::IntegerType>(elemType)) {
        llvm::APInt ap = *dense.getValues<llvm::APInt>().begin();
        return ap.isZero();
    }
    return false;
}

bool IsScalarNegInfOrMin(mlir::Value value) {
    mlir::DenseElementsAttr dense;
    if (!GetScalarConstantAttr(value, dense)) {
        return false;
    }
    auto elemType = dense.getElementType();
    if (mlir::isa<mlir::FloatType>(elemType)) {
        llvm::APFloat ap = *dense.getValues<llvm::APFloat>().begin();
        return ap.isInfinity() && ap.isNegative();
    }
    if (auto intType = mlir::dyn_cast<mlir::IntegerType>(elemType)) {
        llvm::APInt ap = *dense.getValues<llvm::APInt>().begin();
        llvm::APInt minV = llvm::APInt::getSignedMinValue(intType.getWidth());
        return ap == minV;
    }
    return false;
}

bool IsScalarPosInfOrMax(mlir::Value value) {
    mlir::DenseElementsAttr dense;
    if (!GetScalarConstantAttr(value, dense)) {
        return false;
    }
    auto elemType = dense.getElementType();
    if (mlir::isa<mlir::FloatType>(elemType)) {
        llvm::APFloat ap = *dense.getValues<llvm::APFloat>().begin();
        return ap.isInfinity() && !ap.isNegative();
    }
    if (auto intType = mlir::dyn_cast<mlir::IntegerType>(elemType)) {
        llvm::APInt ap = *dense.getValues<llvm::APInt>().begin();
        llvm::APInt maxV = llvm::APInt::getSignedMaxValue(intType.getWidth());
        return ap == maxV;
    }
    return false;
}

}  // namespace

// Single-result reduce: sum, product, max, min, and, or
static ProcessResult HandleSingleResultReduce(HandlerContext& ctx) {
    auto reduceOp = mlir::dyn_cast<mlir::stablehlo::ReduceOp>(ctx.op);
    if (!reduceOp) {
        return ProcessResult::Error("reduce: expected ReduceOp");
    }

    // Get the input tensor (first operand)
    MPSGraphTensor* input = GetInputTensor(ctx, 0);
    if (!input) {
        return ProcessResult::Error("reduce: input tensor not found");
    }

    // Get reduction dimensions
    auto dimensions = reduceOp.getDimensions();
    NSMutableArray<NSNumber*>* axes = [NSMutableArray array];
    for (int64_t dim : dimensions) {
        [axes addObject:@(dim)];
    }

    // Identify the reduction operation from the body
    std::string reductionType = GetReductionOpType(reduceOp.getBody());

    MPSGraphTensor* result = nullptr;
    if (reductionType == "stablehlo.add") {
        result = [ctx.graph reductionSumWithTensor:input axes:axes name:nil];
    } else if (reductionType == "stablehlo.multiply") {
        result = [ctx.graph reductionProductWithTensor:input axes:axes name:nil];
    } else if (reductionType == "stablehlo.maximum") {
        result = [ctx.graph reductionMaximumWithTensor:input axes:axes name:nil];
    } else if (reductionType == "stablehlo.minimum") {
        result = [ctx.graph reductionMinimumWithTensor:input axes:axes name:nil];
    } else if (reductionType == "stablehlo.and") {
        result = [ctx.graph reductionAndWithTensor:input axes:axes name:nil];
    } else if (reductionType == "stablehlo.or") {
        result = [ctx.graph reductionOrWithTensor:input axes:axes name:nil];
    } else {
        return ProcessResult::Error("reduce: unsupported reduction type: " + reductionType);
    }

    // MPS Graph reduction keeps dimensions (with size 1), but StableHLO reduce removes them
    // Reshape to the expected output shape from the MLIR operation
    NSArray<NSNumber*>* outputShape = GetOutputShape(ctx.op);
    if (outputShape && result) {
        result = [ctx.graph reshapeTensor:result withShape:outputShape name:nil];
    }

    return Result(ctx, result, "reduce");
}

// Multi-result reduce: argmax/argmin patterns
static ProcessResult HandleMultiResultReduce(HandlerContext& ctx) {
    auto reduceOp = mlir::dyn_cast<mlir::stablehlo::ReduceOp>(ctx.op);
    if (!reduceOp) {
        return ProcessResult::Error("reduce: expected ReduceOp");
    }
    if (ctx.op->getNumResults() != 2 || ctx.op->getNumOperands() < 2) {
        return ProcessResult::Error("reduce: unsupported multi-result shape");
    }

    MPSGraphTensor* valueInput = GetInputTensor(ctx, 0);
    if (!valueInput) {
        return ProcessResult::Error("reduce: value input tensor not found");
    }

    auto dimensions = reduceOp.getDimensions();
    if (dimensions.size() != 1) {
        return ProcessResult::Error("reduce: only single-axis multi-result reduce is supported");
    }
    NSInteger axis = (NSInteger)dimensions[0];

    ArgReduceKind kind = detectArgReduceKind(reduceOp);
    if (kind == ArgReduceKind::kUnknown) {
        return ProcessResult::Error("reduce: unsupported multi-result reduce body");
    }

    MPSGraphTensor* valueOut = nullptr;
    MPSGraphTensor* indexOut = nullptr;
    if (kind == ArgReduceKind::kMax) {
        valueOut = [ctx.graph reductionMaximumWithTensor:valueInput axis:axis name:nil];
        indexOut = [ctx.graph reductionArgMaximumWithTensor:valueInput axis:axis name:nil];
    } else {
        valueOut = [ctx.graph reductionMinimumWithTensor:valueInput axis:axis name:nil];
        indexOut = [ctx.graph reductionArgMinimumWithTensor:valueInput axis:axis name:nil];
    }
    if (!valueOut || !indexOut) {
        return ProcessResult::Error("reduce: failed to lower multi-result reduce");
    }

    MPSDataType valueType = GetResultMpsType(ctx.op, 0);
    if (valueType != MPSDataTypeInvalid && valueOut.dataType != valueType) {
        valueOut = [ctx.graph castTensor:valueOut toType:valueType name:nil];
    }
    MPSDataType indexType = GetResultMpsType(ctx.op, 1);
    if (indexType != MPSDataTypeInvalid && indexOut.dataType != indexType) {
        indexOut = [ctx.graph castTensor:indexOut toType:indexType name:nil];
    }

    NSArray<NSNumber*>* valueShape = GetOutputShape(ctx.op, 0);
    if (valueShape && valueOut) {
        valueOut = [ctx.graph reshapeTensor:valueOut withShape:valueShape name:nil];
    }
    NSArray<NSNumber*>* indexShape = GetOutputShape(ctx.op, 1);
    if (indexShape && indexOut) {
        indexOut = [ctx.graph reshapeTensor:indexOut withShape:indexShape name:nil];
    }

    ctx.values[ctx.op->getResult(0).getAsOpaquePointer()] = valueOut;
    ctx.values[ctx.op->getResult(1).getAsOpaquePointer()] = indexOut;
    return ProcessResult{};
}

// Unified reduce handler - dispatches based on result count
static ProcessResult HandleReduce(HandlerContext& ctx) {
    if (ctx.op->getNumResults() > 1) {
        return HandleMultiResultReduce(ctx);
    }
    return HandleSingleResultReduce(ctx);
}
REGISTER_MPS_OP("stablehlo.reduce", HandleReduce);

// reduce_window:
// - cumulative patterns (cumsum/cumprod/cummax/cummin) generated from StableHLO reduce_window
// - pooling-like patterns (sum/max/min) for NHWC (rank-4) and NWC (rank-3, lifted to NHWC with H=1)
static ProcessResult HandleReduceWindow(HandlerContext& ctx) {
    auto reduceWindowOp = mlir::dyn_cast<mlir::stablehlo::ReduceWindowOp>(ctx.op);
    if (!reduceWindowOp) {
        return ProcessResult::Error("reduce_window: expected ReduceWindowOp");
    }
    if (ctx.op->getNumOperands() != 2 || ctx.op->getNumResults() != 1) {
        return ProcessResult::Error(
            "reduce_window: only single-input single-result reduce_window is supported");
    }

    MPSGraphTensor* input = GetInputTensor(ctx, 0);
    if (!input) {
        return ProcessResult::Error("reduce_window: input tensor not found");
    }

    auto windowDimensions = reduceWindowOp.getWindowDimensions();
    size_t rank = windowDimensions.size();
    if (rank == 0) {
        return ProcessResult::Error("reduce_window: rank-0 reduce_window is not supported");
    }

    std::vector<int64_t> windowStrides;
    std::vector<int64_t> baseDilations;
    std::vector<int64_t> windowDilations;
    std::vector<std::pair<int64_t, int64_t>> padding;
    if (!ReadArrayOrDefaultOnes(reduceWindowOp.getWindowStrides(), rank, windowStrides)) {
        return ProcessResult::Error("reduce_window: invalid window_strides rank mismatch");
    }
    if (!ReadArrayOrDefaultOnes(reduceWindowOp.getBaseDilations(), rank, baseDilations)) {
        return ProcessResult::Error("reduce_window: invalid base_dilations rank mismatch");
    }
    if (!ReadArrayOrDefaultOnes(reduceWindowOp.getWindowDilations(), rank, windowDilations)) {
        return ProcessResult::Error("reduce_window: invalid window_dilations rank mismatch");
    }
    if (!ReadPaddingOrDefaultZeros(reduceWindowOp.getPadding(), rank, padding)) {
        return ProcessResult::Error("reduce_window: invalid padding shape");
    }

    std::string reducerType = GetReductionOpType(reduceWindowOp.getBody());
    NSInteger cumulativeAxis = -1;
    bool patternMatches = true;
    for (size_t dim = 0; dim < rank; ++dim) {
        if (windowStrides[dim] != 1 || baseDilations[dim] != 1 || windowDilations[dim] != 1) {
            patternMatches = false;
            break;
        }

        int64_t window = windowDimensions[dim];
        int64_t padLow = padding[dim].first;
        int64_t padHigh = padding[dim].second;
        if (window > 1) {
            if (cumulativeAxis != -1 || padLow != window - 1 || padHigh != 0) {
                patternMatches = false;
                break;
            }
            cumulativeAxis = (NSInteger)dim;
        } else if (window == 1) {
            if (padLow != 0 || padHigh != 0) {
                patternMatches = false;
                break;
            }
        } else {
            patternMatches = false;
            break;
        }
    }

    if (cumulativeAxis < 0 || !patternMatches) {
        // Pooling-like reduce_window patterns (common JAX lowering for pooling):
        // - NHWC rank-4 input
        // - NWC rank-3 input (treated as NHWC with H=1)
        // - window dims / strides only on spatial dims (H, W) (or just W for 1D-by-2D trick)
        // - base_dilations == 1
        // - window_dilations == 1 (for now)
        // - padding only on spatial dims
        //
        // We lower to MPSGraph pooling ops (max/avg) where possible.
        auto inputType = mlir::dyn_cast<mlir::RankedTensorType>(ctx.op->getOperand(0).getType());
        bool is2DPooling = (rank == 4 && inputType && inputType.getRank() == 4 &&
                            windowDimensions.size() == 4 && windowStrides.size() == 4 &&
                            baseDilations.size() == 4 && windowDilations.size() == 4 &&
                            windowDimensions[0] == 1 && windowDimensions[3] == 1 &&
                            windowStrides[0] == 1 && windowStrides[3] == 1 &&
                            baseDilations[0] == 1 && baseDilations[1] == 1 && baseDilations[2] == 1 &&
                            baseDilations[3] == 1 && windowDilations[0] == 1 &&
                            windowDilations[1] == 1 && windowDilations[2] == 1 &&
                            windowDilations[3] == 1 && padding[0].first == 0 && padding[0].second == 0 &&
                            padding[3].first == 0 && padding[3].second == 0 && padding[1].first >= 0 &&
                            padding[1].second >= 0 && padding[2].first >= 0 && padding[2].second >= 0 &&
                            windowDimensions[1] >= 1 && windowDimensions[2] >= 1 &&
                            windowStrides[1] >= 1 && windowStrides[2] >= 1);

        bool is1DPooling = (rank == 3 && inputType && inputType.getRank() == 3 &&
                            windowDimensions.size() == 3 && windowStrides.size() == 3 &&
                            baseDilations.size() == 3 && windowDilations.size() == 3 &&
                            windowDimensions[0] == 1 && windowDimensions[2] == 1 &&
                            windowStrides[0] == 1 && windowStrides[2] == 1 &&
                            baseDilations[0] == 1 && baseDilations[1] == 1 && baseDilations[2] == 1 &&
                            windowDilations[0] == 1 && windowDilations[1] == 1 && windowDilations[2] == 1 &&
                            padding[0].first == 0 && padding[0].second == 0 && padding[2].first == 0 &&
                            padding[2].second == 0 && padding[1].first >= 0 && padding[1].second >= 0 &&
                            windowDimensions[1] >= 1 && windowStrides[1] >= 1);

        if (is2DPooling || is1DPooling) {
            int64_t kH = is2DPooling ? windowDimensions[1] : 1;
            int64_t kW = is2DPooling ? windowDimensions[2] : windowDimensions[1];
            int64_t sH = is2DPooling ? windowStrides[1] : 1;
            int64_t sW = is2DPooling ? windowStrides[2] : windowStrides[1];
            int64_t padTop = is2DPooling ? padding[1].first : 0;
            int64_t padBottom = is2DPooling ? padding[1].second : 0;
            int64_t padLeft = is2DPooling ? padding[2].first : padding[1].first;
            int64_t padRight = is2DPooling ? padding[2].second : padding[1].second;

            // Lift NWC -> NHWC with H=1 so we can use pooling2D.
            if (is1DPooling) {
                if (!input.shape || input.shape.count != 3) {
                    return ProcessResult::Error(
                        "reduce_window: expected rank-3 NWC tensor for 1D pooling");
                }
                input = [ctx.graph reshapeTensor:input
                                      withShape:@[input.shape[0], @1, input.shape[1], input.shape[2]]
                                           name:nil];
            }

            MPSGraphPooling2DOpDescriptor* desc = [MPSGraphPooling2DOpDescriptor
                descriptorWithKernelWidth:(NSUInteger)kW
                              kernelHeight:(NSUInteger)kH
                                 strideInX:(NSUInteger)sW
                                 strideInY:(NSUInteger)sH
                           dilationRateInX:1
                           dilationRateInY:1
                               paddingLeft:(NSUInteger)padLeft
                              paddingRight:(NSUInteger)padRight
                                paddingTop:(NSUInteger)padTop
                             paddingBottom:(NSUInteger)padBottom
                              paddingStyle:MPSGraphPaddingStyleExplicit
                                dataLayout:MPSGraphTensorNamedDataLayoutNHWC];

            if (reducerType == "stablehlo.add") {
                // Sum-pooling via avg-pooling * window_size with zero padding included.
                if (input.dataType != MPSDataTypeFloat16 && input.dataType != MPSDataTypeFloat32) {
                    return ProcessResult::Error(
                        "reduce_window: sum-pooling only supported for float16/float32 (" +
                        DescribeReduceWindowPattern(reduceWindowOp, windowDimensions, windowStrides,
                                                    baseDilations, windowDilations, padding,
                                                    reducerType) +
                        ")");
                }
                desc.includeZeroPadToAverage = YES;
                MPSGraphTensor* avg =
                    [ctx.graph avgPooling2DWithSourceTensor:input descriptor:desc name:nil];
                MPSGraphTensor* scale = [ctx.graph constantWithScalar:(double)(kH * kW)
                                                            dataType:input.dataType];
                MPSGraphTensor* result =
                    [ctx.graph multiplicationWithPrimaryTensor:avg secondaryTensor:scale name:nil];
                NSArray<NSNumber*>* outputShape = GetOutputShape(ctx.op);
                if (result && outputShape) {
                    result = [ctx.graph reshapeTensor:result withShape:outputShape name:nil];
                }
                return Result(ctx, result, "reduce_window");
            }

            if (reducerType == "stablehlo.maximum") {
                MPSGraphTensor* result =
                    [ctx.graph maxPooling2DWithSourceTensor:input descriptor:desc name:nil];
                NSArray<NSNumber*>* outputShape = GetOutputShape(ctx.op);
                if (result && outputShape) {
                    result = [ctx.graph reshapeTensor:result withShape:outputShape name:nil];
                }
                return Result(ctx, result, "reduce_window");
            }

            if (reducerType == "stablehlo.minimum") {
                // Min-pooling via max-pooling on negated input (padding semantics match with +/-inf).
                if (input.dataType != MPSDataTypeFloat16 && input.dataType != MPSDataTypeFloat32) {
                    return ProcessResult::Error(
                        "reduce_window: min-pooling only supported for float16/float32 (" +
                        DescribeReduceWindowPattern(reduceWindowOp, windowDimensions, windowStrides,
                                                    baseDilations, windowDilations, padding,
                                                    reducerType) +
                        ")");
                }
                MPSGraphTensor* neg = [ctx.graph negativeWithTensor:input name:nil];
                MPSGraphTensor* pooled =
                    [ctx.graph maxPooling2DWithSourceTensor:neg descriptor:desc name:nil];
                MPSGraphTensor* result = [ctx.graph negativeWithTensor:pooled name:nil];
                NSArray<NSNumber*>* outputShape = GetOutputShape(ctx.op);
                if (result && outputShape) {
                    result = [ctx.graph reshapeTensor:result withShape:outputShape name:nil];
                }
                return Result(ctx, result, "reduce_window");
            }
        }

        return ProcessResult::Error(
            "reduce_window: unsupported pattern (" +
            DescribeReduceWindowPattern(reduceWindowOp, windowDimensions, windowStrides,
                                        baseDilations, windowDilations, padding, reducerType) +
            ")");
    }

    MPSGraphTensor* result = nullptr;
    if (reducerType == "stablehlo.add") {
        result = [ctx.graph cumulativeSumWithTensor:input axis:cumulativeAxis name:nil];
    } else if (reducerType == "stablehlo.multiply") {
        result = [ctx.graph cumulativeProductWithTensor:input axis:cumulativeAxis name:nil];
    } else if (reducerType == "stablehlo.maximum") {
        result = [ctx.graph cumulativeMaximumWithTensor:input axis:cumulativeAxis name:nil];
    } else if (reducerType == "stablehlo.minimum") {
        result = [ctx.graph cumulativeMinimumWithTensor:input axis:cumulativeAxis name:nil];
    } else {
        return ProcessResult::Error(
            "reduce_window: unsupported reducer for cumulative lowering (" +
            DescribeReduceWindowPattern(reduceWindowOp, windowDimensions, windowStrides,
                                        baseDilations, windowDilations, padding, reducerType) +
            ")");
    }

    NSArray<NSNumber*>* outputShape = GetOutputShape(ctx.op);
    if (result && outputShape) {
        result = [ctx.graph reshapeTensor:result withShape:outputShape name:nil];
    }
    return Result(ctx, result, "reduce_window");
}
REGISTER_MPS_OP("stablehlo.reduce_window", HandleReduceWindow);

// stablehlo.select_and_scatter is used by pooling gradients (e.g. reduce_window(max) backwards).
// We currently support the common NHWC max-pool gradient pattern:
// - select: compare GE/GT
// - scatter: add
// - init: 0
static ProcessResult HandleSelectAndScatter(HandlerContext& ctx) {
    auto op = mlir::dyn_cast<mlir::stablehlo::SelectAndScatterOp>(ctx.op);
    if (!op) {
        return ProcessResult::Error("select_and_scatter: expected SelectAndScatterOp");
    }

    MPSGraphTensor* operand = GetInputTensor(ctx, 0);
    MPSGraphTensor* source = GetInputTensor(ctx, 1);
    if (!operand || !source) {
        return ProcessResult::Error("select_and_scatter: missing input tensors");
    }

    // Validate common region bodies.
    bool isMaxSelect = false;
    if (!op.getSelect().empty()) {
        for (mlir::Operation& nestedOp : op.getSelect().front()) {
            auto compareOp = mlir::dyn_cast<mlir::stablehlo::CompareOp>(&nestedOp);
            if (!compareOp) {
                continue;
            }
            auto dir = compareOp.getComparisonDirection();
            isMaxSelect = (dir == mlir::stablehlo::ComparisonDirection::GT ||
                           dir == mlir::stablehlo::ComparisonDirection::GE);
            break;
        }
    }

    std::string scatterType = GetReductionOpType(op.getScatter());
    mlir::Value initValue = ctx.op->getOperand(2);

    if (!isMaxSelect || scatterType != "stablehlo.add" || !IsScalarZero(initValue)) {
        return ProcessResult::Error(
            "select_and_scatter: unsupported region bodies (expected select=GT/GE and scatter=add, "
            "init=0)");
    }

    auto windowDimensionsOpt = op.getWindowDimensions();
    auto windowStridesOpt = op.getWindowStrides();
    if (!windowDimensionsOpt || !windowStridesOpt) {
        return ProcessResult::Error("select_and_scatter: missing window_dimensions/window_strides");
    }
    auto windowDimensions = *windowDimensionsOpt;
    auto windowStrides = *windowStridesOpt;
    size_t rank = windowDimensions.size();
    if (rank != 4 || windowStrides.size() != 4) {
        return ProcessResult::Error("select_and_scatter: only rank-4 NHWC is supported");
    }

    std::vector<std::pair<int64_t, int64_t>> padding;
    std::optional<mlir::DenseIntElementsAttr> paddingAttr;
    if (auto attr = ctx.op->getAttrOfType<mlir::DenseIntElementsAttr>("padding")) {
        paddingAttr = attr;
    }
    if (!ReadPaddingOrDefaultZeros(paddingAttr, rank, padding)) {
        return ProcessResult::Error("select_and_scatter: invalid padding attribute");
    }

    // Expect NHWC pooling dims.
    if (windowDimensions[0] != 1 || windowDimensions[3] != 1 || windowStrides[0] != 1 ||
        windowStrides[3] != 1 || padding[0].first != 0 || padding[0].second != 0 ||
        padding[3].first != 0 || padding[3].second != 0 || padding[1].first < 0 ||
        padding[1].second < 0 || padding[2].first < 0 || padding[2].second < 0) {
        return ProcessResult::Error("select_and_scatter: unsupported NHWC pooling parameters");
    }

    int64_t kH = windowDimensions[1];
    int64_t kW = windowDimensions[2];
    int64_t sH = windowStrides[1];
    int64_t sW = windowStrides[2];
    int64_t padTop = padding[1].first;
    int64_t padBottom = padding[1].second;
    int64_t padLeft = padding[2].first;
    int64_t padRight = padding[2].second;

    MPSGraphPooling2DOpDescriptor* desc = [MPSGraphPooling2DOpDescriptor
        descriptorWithKernelWidth:(NSUInteger)kW
                      kernelHeight:(NSUInteger)kH
                         strideInX:(NSUInteger)sW
                         strideInY:(NSUInteger)sH
                   dilationRateInX:1
                   dilationRateInY:1
                       paddingLeft:(NSUInteger)padLeft
                      paddingRight:(NSUInteger)padRight
                        paddingTop:(NSUInteger)padTop
                     paddingBottom:(NSUInteger)padBottom
                      paddingStyle:MPSGraphPaddingStyleExplicit
                        dataLayout:MPSGraphTensorNamedDataLayoutNHWC];

    MPSGraphTensor* result =
        [ctx.graph maxPooling2DGradientWithGradientTensor:source
                                             sourceTensor:operand
                                               descriptor:desc
                                                     name:nil];
    NSArray<NSNumber*>* outputShape = GetOutputShape(ctx.op);
    if (result && outputShape) {
        result = [ctx.graph reshapeTensor:result withShape:outputShape name:nil];
    }
    return Result(ctx, result, "select_and_scatter");
}
REGISTER_MPS_OP("stablehlo.select_and_scatter", HandleSelectAndScatter);

// stablehlo.return is a terminator used inside regions (e.g., reduce body)
// It's handled implicitly by parent operations, not executed directly
static ProcessResult HandleReturn(HandlerContext& ctx) {
    // This should never be called directly - it's handled by the block processor as a terminator.
    // We keep it registered so module verification doesn't flag it as unsupported.
    MPS_LOG_DEBUG("stablehlo.return terminator encountered; skipping execution\n");
    return ProcessResult{};
}
REGISTER_MPS_OP("stablehlo.return", HandleReturn);

}  // namespace jax_silicon
