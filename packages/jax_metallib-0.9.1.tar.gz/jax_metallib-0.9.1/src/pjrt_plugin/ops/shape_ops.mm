// Shape operations: broadcast, reshape, convert, slice, concatenate,
// custom_call, etc.

#import "pjrt_plugin/ops/registry.h"
#include <algorithm>
#include <sstream>

namespace jax_silicon {

namespace {

bool ReadConstantIntVector(mlir::Value value, std::vector<int64_t>& out) {
    out.clear();
    if (!value) {
        return false;
    }

    auto* defOp = value.getDefiningOp();
    auto constOp = mlir::dyn_cast_or_null<mlir::stablehlo::ConstantOp>(defOp);
    if (!constOp) {
        return false;
    }

    auto denseAttr = mlir::dyn_cast<mlir::DenseElementsAttr>(constOp.getValue());
    if (!denseAttr) {
        return false;
    }

    auto elemType = denseAttr.getElementType();
    auto intType = mlir::dyn_cast<mlir::IntegerType>(elemType);
    if (!intType) {
        return false;
    }

    out.reserve(denseAttr.getNumElements());
    for (llvm::APInt v : denseAttr.getValues<llvm::APInt>()) {
        // For signless integers (the default in StableHLO), use sign-extend.
        out.push_back(intType.isUnsigned() ? (int64_t)v.getZExtValue() : v.getSExtValue());
    }
    return true;
}

bool ReadConstantIntScalar(mlir::Value value, int64_t& out) {
    std::vector<int64_t> values;
    if (!ReadConstantIntVector(value, values) || values.size() != 1) {
        return false;
    }
    out = values[0];
    return true;
}

}  // namespace

static ProcessResult HandleBroadcast(HandlerContext& ctx) {
    MPSGraphTensor* input = GetInputTensor(ctx, 0);
    if (!input)
        return ProcessResult::Error("broadcast: missing input tensor");
    NSArray<NSNumber*>* outputShape = GetOutputShape(ctx.op);
    MPSGraphTensor* result = [ctx.graph broadcastTensor:input toShape:outputShape name:nil];
    return Result(ctx, result, "broadcast");
}
REGISTER_MPS_OP("stablehlo.broadcast", HandleBroadcast);

// broadcast_in_dim needs special handling for dimension mapping
static ProcessResult HandleBroadcastInDim(HandlerContext& ctx) {
    auto broadcastOp = mlir::dyn_cast<mlir::stablehlo::BroadcastInDimOp>(ctx.op);
    if (!broadcastOp) {
        return ProcessResult::Error("broadcast_in_dim: expected BroadcastInDimOp");
    }

    MPSGraphTensor* input = GetInputTensor(ctx, 0);
    if (!input) {
        return ProcessResult::Error("broadcast_in_dim: input tensor not found");
    }

    NSArray<NSNumber*>* inputShape = input.shape;
    NSUInteger inputRank = inputShape.count;

    NSArray<NSNumber*>* outputShape = GetOutputShape(ctx.op);
    NSUInteger outputRank = outputShape.count;

    auto broadcastDims = broadcastOp.getBroadcastDimensions();

    MPSGraphTensor* result = nil;

    // If broadcast_dims is empty or ranks match, just broadcast directly
    if (broadcastDims.empty() || inputRank == outputRank) {
        result = [ctx.graph broadcastTensor:input toShape:outputShape name:nil];
    } else {
        // Build intermediate shape: start with all 1s, then fill in from broadcast_dims
        NSMutableArray<NSNumber*>* intermediateShape =
            [NSMutableArray arrayWithCapacity:outputRank];
        for (NSUInteger i = 0; i < outputRank; i++) {
            [intermediateShape addObject:@1];
        }

        // Map input dimensions to output dimensions according to broadcast_dims
        for (size_t i = 0; i < broadcastDims.size() && i < inputRank; i++) {
            int64_t outDim = broadcastDims[i];
            if (outDim >= 0 && (NSUInteger)outDim < outputRank) {
                intermediateShape[outDim] = inputShape[i];
            }
        }

        // Reshape input to intermediate shape (same rank as output)
        MPSGraphTensor* reshaped = [ctx.graph reshapeTensor:input
                                                  withShape:intermediateShape
                                                       name:nil];

        // Now broadcast to final output shape
        result = [ctx.graph broadcastTensor:reshaped toShape:outputShape name:nil];
    }

    return Result(ctx, result, "broadcast_in_dim");
}
REGISTER_MPS_OP("stablehlo.broadcast_in_dim", HandleBroadcastInDim);

// dynamic_broadcast_in_dim: like broadcast_in_dim, but the output shape is provided as a tensor.
// We currently only support the "static-in-practice" case where output_dimensions is a compile-time constant.
static ProcessResult HandleDynamicBroadcastInDim(HandlerContext& ctx) {
    auto op = mlir::dyn_cast<mlir::stablehlo::DynamicBroadcastInDimOp>(ctx.op);
    if (!op) {
        return ProcessResult::Error("dynamic_broadcast_in_dim: expected DynamicBroadcastInDimOp");
    }

    MPSGraphTensor* input = GetInputTensor(ctx, 0);
    if (!input) {
        return ProcessResult::Error("dynamic_broadcast_in_dim: missing input tensor");
    }

    std::vector<int64_t> outDims;
    if (!ReadConstantIntVector(op.getOutputDimensions(), outDims)) {
        return ProcessResult::Error(
            "dynamic_broadcast_in_dim: dynamic output_dimensions is not supported (must be a "
            "stablehlo.constant)");
    }

    NSMutableArray<NSNumber*>* outputShape =
        [NSMutableArray arrayWithCapacity:static_cast<NSUInteger>(outDims.size())];
    for (int64_t d : outDims) {
        if (d < 0) {
            return ProcessResult::Error(
                "dynamic_broadcast_in_dim: dynamic (unknown) output dimension is not supported");
        }
        [outputShape addObject:@(d)];
    }

    NSArray<NSNumber*>* inputShape = input.shape;
    NSUInteger inputRank = inputShape.count;
    NSUInteger outputRank = outputShape.count;

    auto broadcastDims = op.getBroadcastDimensions();

    MPSGraphTensor* result = nil;
    if (broadcastDims.empty() || inputRank == outputRank) {
        result = [ctx.graph broadcastTensor:input toShape:outputShape name:nil];
    } else {
        NSMutableArray<NSNumber*>* intermediateShape =
            [NSMutableArray arrayWithCapacity:outputRank];
        for (NSUInteger i = 0; i < outputRank; i++) {
            [intermediateShape addObject:@1];
        }

        for (size_t i = 0; i < broadcastDims.size() && i < inputRank; i++) {
            int64_t outDim = broadcastDims[i];
            if (outDim >= 0 && (NSUInteger)outDim < outputRank) {
                intermediateShape[outDim] = inputShape[i];
            }
        }

        MPSGraphTensor* reshaped = [ctx.graph reshapeTensor:input
                                                  withShape:intermediateShape
                                                       name:nil];
        result = [ctx.graph broadcastTensor:reshaped toShape:outputShape name:nil];
    }

    return Result(ctx, result, "dynamic_broadcast_in_dim");
}
REGISTER_MPS_OP("stablehlo.dynamic_broadcast_in_dim", HandleDynamicBroadcastInDim);

static ProcessResult HandleReshape(HandlerContext& ctx) {
    MPSGraphTensor* input = GetInputTensor(ctx, 0);
    if (!input)
        return ProcessResult::Error("reshape: missing input tensor");
    NSArray<NSNumber*>* outputShape = GetOutputShape(ctx.op);
    MPSGraphTensor* result = [ctx.graph reshapeTensor:input withShape:outputShape name:nil];
    return Result(ctx, result, "reshape");
}
REGISTER_MPS_OP("stablehlo.reshape", HandleReshape);

// dynamic_reshape: reshape with output shape provided as a tensor.
// We currently only support the "static-in-practice" case where output_shape is a compile-time constant.
static ProcessResult HandleDynamicReshape(HandlerContext& ctx) {
    auto op = mlir::dyn_cast<mlir::stablehlo::DynamicReshapeOp>(ctx.op);
    if (!op) {
        return ProcessResult::Error("dynamic_reshape: expected DynamicReshapeOp");
    }

    MPSGraphTensor* input = GetInputTensor(ctx, 0);
    if (!input) {
        return ProcessResult::Error("dynamic_reshape: missing input tensor");
    }

    std::vector<int64_t> outDims;
    if (!ReadConstantIntVector(op.getOutputShape(), outDims)) {
        return ProcessResult::Error(
            "dynamic_reshape: dynamic output_shape is not supported (must be a stablehlo.constant)");
    }

    NSMutableArray<NSNumber*>* outputShape =
        [NSMutableArray arrayWithCapacity:static_cast<NSUInteger>(outDims.size())];
    for (int64_t d : outDims) {
        if (d < 0) {
            return ProcessResult::Error(
                "dynamic_reshape: dynamic (unknown) output dimension is not supported");
        }
        [outputShape addObject:@(d)];
    }

    MPSGraphTensor* result = [ctx.graph reshapeTensor:input withShape:outputShape name:nil];
    return Result(ctx, result, "dynamic_reshape");
}
REGISTER_MPS_OP("stablehlo.dynamic_reshape", HandleDynamicReshape);

// get_dimension_size: returns the size of a dimension as an int32 scalar.
// For now we only support statically-known shapes.
static ProcessResult HandleGetDimensionSize(HandlerContext& ctx) {
    auto op = mlir::dyn_cast<mlir::stablehlo::GetDimensionSizeOp>(ctx.op);
    if (!op) {
        return ProcessResult::Error("get_dimension_size: expected GetDimensionSizeOp");
    }

    auto inputType = mlir::dyn_cast<mlir::RankedTensorType>(op.getOperand().getType());
    if (!inputType) {
        return ProcessResult::Error("get_dimension_size: expected ranked tensor operand");
    }

    int64_t dim = op.getDimension();
    auto shape = inputType.getShape();
    if (dim < 0 || dim >= (int64_t)shape.size()) {
        return ProcessResult::Error("get_dimension_size: dimension out of bounds");
    }
    if (shape[dim] < 0) {
        return ProcessResult::Error("get_dimension_size: dynamic dimension size is not supported");
    }

    MPSDataType dtype = GetResultMpsType(ctx.op);
    if (dtype == MPSDataTypeInvalid) {
        return ProcessResult::Error("get_dimension_size: invalid result dtype");
    }

    MPSGraphTensor* result = [ctx.graph constantWithScalar:(double)shape[dim] dataType:dtype];
    return Result(ctx, result, "get_dimension_size");
}
REGISTER_MPS_OP("stablehlo.get_dimension_size", HandleGetDimensionSize);

// set_dimension_size: a marker op used for dynamic shapes. For static shapes, treat it as identity.
static ProcessResult HandleSetDimensionSize(HandlerContext& ctx) {
    auto op = mlir::dyn_cast<mlir::stablehlo::SetDimensionSizeOp>(ctx.op);
    if (!op) {
        return ProcessResult::Error("set_dimension_size: expected SetDimensionSizeOp");
    }

    MPSGraphTensor* input = GetInputTensor(ctx, 0);
    if (!input) {
        return ProcessResult::Error("set_dimension_size: missing input tensor");
    }

    int64_t dim = op.getDimension();
    auto inputType = mlir::dyn_cast<mlir::RankedTensorType>(ctx.op->getOperand(0).getType());
    if (!inputType) {
        return ProcessResult::Error("set_dimension_size: expected ranked tensor operand");
    }

    auto shape = inputType.getShape();
    if (dim < 0 || dim >= (int64_t)shape.size()) {
        return ProcessResult::Error("set_dimension_size: dimension out of bounds");
    }

    // Best-effort validation: if the requested size is a compile-time constant and the input
    // dimension is statically known, ensure they match.
    int64_t requested = 0;
    if (shape[dim] >= 0 && ReadConstantIntScalar(op.getSize(), requested) && requested != shape[dim]) {
        return ProcessResult::Error("set_dimension_size: requested size " + std::to_string(requested) +
                                    " does not match static dim size " + std::to_string(shape[dim]));
    }

    SetOutputTensor(ctx.values, ctx.op, input);
    return ProcessResult{};
}
REGISTER_MPS_OP("stablehlo.set_dimension_size", HandleSetDimensionSize);

static ProcessResult HandleTranspose(HandlerContext& ctx) {
    auto transposeOp = mlir::dyn_cast<mlir::stablehlo::TransposeOp>(ctx.op);
    if (!transposeOp) {
        return ProcessResult::Error("transpose: expected TransposeOp");
    }

    MPSGraphTensor* input = GetInputTensor(ctx, 0);
    if (!input)
        return ProcessResult::Error("transpose: missing input tensor");

    auto permutation = transposeOp.getPermutation();
    NSMutableArray<NSNumber*>* perm = [NSMutableArray array];
    for (int64_t d : permutation) {
        [perm addObject:@(d)];
    }

    MPSGraphTensor* result = [ctx.graph transposeTensor:input permutation:perm name:nil];
    return Result(ctx, result, "transpose");
}
REGISTER_MPS_OP("stablehlo.transpose", HandleTranspose);

static ProcessResult HandleConvert(HandlerContext& ctx) {
    MPSGraphTensor* input = GetInputTensor(ctx, 0);
    if (!input)
        return ProcessResult::Error("convert: missing input tensor");

    MPSDataType dtype = GetResultMpsType(ctx.op);
    if (dtype == MPSDataTypeInvalid) {
        return ProcessResult::Error("convert: invalid dtype for convert operation");
    }
    MPSGraphTensor* result = [ctx.graph castTensor:input toType:dtype name:nil];
    return Result(ctx, result, "convert");
}
REGISTER_MPS_OP("stablehlo.convert", HandleConvert);

// Slice - extract a portion of a tensor (static indices)
static ProcessResult HandleSlice(HandlerContext& ctx) {
    auto sliceOp = mlir::dyn_cast<mlir::stablehlo::SliceOp>(ctx.op);
    if (!sliceOp) {
        return ProcessResult::Error("slice: expected SliceOp");
    }

    MPSGraphTensor* input = GetInputTensor(ctx, 0);
    if (!input)
        return ProcessResult::Error("slice: missing input tensor");

    NSMutableArray<NSNumber*>* starts = [NSMutableArray array];
    NSMutableArray<NSNumber*>* ends = [NSMutableArray array];
    NSMutableArray<NSNumber*>* strides = [NSMutableArray array];

    for (int64_t s : sliceOp.getStartIndices()) {
        [starts addObject:@(s)];
    }
    for (int64_t l : sliceOp.getLimitIndices()) {
        [ends addObject:@(l)];
    }
    for (int64_t s : sliceOp.getStrides()) {
        [strides addObject:@(s)];
    }

    MPSGraphTensor* result = [ctx.graph sliceTensor:input
                                             starts:starts
                                               ends:ends
                                            strides:strides
                                               name:nil];
    return Result(ctx, result, "slice");
}
REGISTER_MPS_OP("stablehlo.slice", HandleSlice);

// Dynamic slice - extract a portion using runtime indices
static ProcessResult HandleDynamicSlice(HandlerContext& ctx) {
    auto dynSliceOp = mlir::dyn_cast<mlir::stablehlo::DynamicSliceOp>(ctx.op);
    if (!dynSliceOp) {
        return ProcessResult::Error("dynamic_slice: expected DynamicSliceOp");
    }

    MPSGraphTensor* input = GetInputTensor(ctx, 0);
    if (!input)
        return ProcessResult::Error("dynamic_slice: missing input tensor");

    auto sliceSizes = dynSliceOp.getSliceSizes();
    NSUInteger rank = sliceSizes.size();
    NSArray<NSNumber*>* inputShape = input.shape;
    if (inputShape.count != rank) {
        return ProcessResult::Error("dynamic_slice: input rank does not match slice_sizes rank");
    }

    // Build the output shape from slice sizes
    NSMutableArray<NSNumber*>* outputShape = [NSMutableArray array];
    for (int64_t s : sliceSizes) {
        [outputShape addObject:@(s)];
    }

    // Get start indices as tensors (operands 1 through N)
    // and create coordinate tensors offset by the start indices
    NSMutableArray<MPSGraphTensor*>* indexTensors = [NSMutableArray array];
    for (NSUInteger dim = 0; dim < rank; dim++) {
        // Get the start index tensor for this dimension (scalar tensor)
        MPSGraphTensor* startIdx = GetInputTensor(ctx, dim + 1);
        if (!startIdx) {
            return ProcessResult::Error("dynamic_slice: missing start index for dimension");
        }

        // StableHLO/XLA semantics clamp start indices to keep the slice in-bounds.
        startIdx = EnsureInt32(ctx.graph, startIdx);
        int64_t inputDim = [inputShape[dim] longLongValue];
        int64_t sliceSize = sliceSizes[dim];
        if (sliceSize < 0) {
            return ProcessResult::Error("dynamic_slice: negative slice size is not supported");
        }
        int64_t maxStart = inputDim - sliceSize;
        if (maxStart < 0) {
            return ProcessResult::Error("dynamic_slice: slice size exceeds input dimension");
        }
        MPSGraphTensor* zero = [ctx.graph constantWithScalar:0 dataType:startIdx.dataType];
        MPSGraphTensor* maxStartTensor =
            [ctx.graph constantWithScalar:maxStart dataType:startIdx.dataType];
        startIdx = [ctx.graph maximumWithPrimaryTensor:startIdx secondaryTensor:zero name:nil];
        startIdx =
            [ctx.graph minimumWithPrimaryTensor:startIdx secondaryTensor:maxStartTensor name:nil];

        // Create coordinate tensor for this dimension (0, 1, 2, ..., slice_size-1)
        MPSGraphTensor* coords = [ctx.graph coordinateAlongAxis:(NSInteger)dim
                                                      withShape:outputShape
                                                           name:nil];
        coords = [ctx.graph castTensor:coords toType:startIdx.dataType name:nil];

        // Add start index to coordinates (broadcasts the scalar start index)
        MPSGraphTensor* adjustedCoords = [ctx.graph additionWithPrimaryTensor:coords
                                                              secondaryTensor:startIdx
                                                                         name:nil];

        [indexTensors addObject:adjustedCoords];
    }

    // Stack the coordinate tensors along a new last axis to form indices tensor
    // Shape: [slice_size_0, slice_size_1, ..., rank]
    MPSGraphTensor* indices = [ctx.graph stackTensors:indexTensors axis:(NSInteger)rank name:nil];
    indices = EnsureInt32(ctx.graph, indices);

    // Use gatherND to gather the slice from the input tensor
    // batchDimensions: 0 means no batch dimensions
    MPSGraphTensor* result = [ctx.graph gatherNDWithUpdatesTensor:input
                                                    indicesTensor:indices
                                                  batchDimensions:0
                                                             name:nil];
    return Result(ctx, result, "dynamic_slice");
}
REGISTER_MPS_OP("stablehlo.dynamic_slice", HandleDynamicSlice);

// Bitcast convert - reinterpret bits as a different type
static ProcessResult HandleBitcastConvert(HandlerContext& ctx) {
    MPSGraphTensor* input = GetInputTensor(ctx, 0);
    if (!input)
        return ProcessResult::Error("bitcast_convert: missing input tensor");

    MPSDataType dtype = GetResultMpsType(ctx.op);
    if (dtype == MPSDataTypeInvalid) {
        return ProcessResult::Error("bitcast_convert: invalid dtype");
    }

    // MPS reinterpretCastTensor doesn't support rank-0 (scalar) tensors.
    // Work around by reshaping to rank-1, casting, then reshaping back.
    NSArray<NSNumber*>* inputShape = input.shape;
    bool isScalar = (inputShape.count == 0);

    if (isScalar) {
        // Reshape scalar to [1]
        input = [ctx.graph reshapeTensor:input withShape:@[@1] name:nil];
    }

    // Use reinterpretCast which preserves bit patterns
    MPSGraphTensor* result = [ctx.graph reinterpretCastTensor:input toType:dtype name:nil];

    if (isScalar) {
        // Reshape back to scalar
        result = [ctx.graph reshapeTensor:result withShape:@[] name:nil];
    }

    return Result(ctx, result, "bitcast_convert");
}
REGISTER_MPS_OP("stablehlo.bitcast_convert", HandleBitcastConvert);

// Concatenate - joins tensors along a dimension
static ProcessResult HandleConcatenate(HandlerContext& ctx) {
    auto concatOp = mlir::dyn_cast<mlir::stablehlo::ConcatenateOp>(ctx.op);
    if (!concatOp) {
        return ProcessResult::Error("concatenate: expected ConcatenateOp");
    }

    // Gather all input tensors
    NSMutableArray<MPSGraphTensor*>* input_tensors = [NSMutableArray array];
    for (mlir::Value operand : ctx.op->getOperands()) {
        MPSGraphTensor* tensor = GetTensor(ctx.values, operand);
        if (tensor) {
            [input_tensors addObject:tensor];
        }
    }

    if (input_tensors.count == 0) {
        return ProcessResult::Error("concatenate: no valid inputs");
    }

    // Get the concatenate dimension from the op
    NSInteger dimension = static_cast<NSInteger>(concatOp.getDimension());

    MPSGraphTensor* result = [ctx.graph concatTensors:input_tensors dimension:dimension name:nil];
    return Result(ctx, result, "concatenate");
}
REGISTER_MPS_OP("stablehlo.concatenate", HandleConcatenate);

// Sharding is a marker used by JAX for partitioning - just pass through the input
static ProcessResult HandleSharding(HandlerContext& ctx) {
    unsigned numOperands = ctx.op->getNumOperands();
    unsigned numResults = ctx.op->getNumResults();

    // `Sharding` is treated as a pure marker op; on single-device it must behave
    // like an identity/pass-through.
    if (numOperands != numResults) {
        return ProcessResult::Error("sharding: operand/result arity mismatch (operands=" +
                                    std::to_string(numOperands) +
                                    ", results=" + std::to_string(numResults) + ")");
    }

    for (unsigned i = 0; i < numOperands; ++i) {
        MPSGraphTensor* input = GetInputTensor(ctx, i);
        if (!input) {
            return ProcessResult::Error("sharding: missing input tensor at operand " +
                                        std::to_string(i));
        }
        SetOutputTensor(ctx.values, ctx.op, input, i);
    }
    return ProcessResult{};
}
REGISTER_CUSTOM_CALL("Sharding", HandleSharding, sharding);

// Pad - add padding around tensor
static ProcessResult HandlePad(HandlerContext& ctx) {
    auto padOp = mlir::dyn_cast<mlir::stablehlo::PadOp>(ctx.op);
    if (!padOp) {
        return ProcessResult::Error("pad: expected PadOp");
    }

    MPSGraphTensor* input = GetInputTensor(ctx, 0);
    MPSGraphTensor* paddingValue = GetInputTensor(ctx, 1);
    if (!input || !paddingValue)
        return ProcessResult::Error("pad: missing input tensor");

    auto edgePaddingLow = padOp.getEdgePaddingLow();
    auto edgePaddingHigh = padOp.getEdgePaddingHigh();
    auto interiorPadding = padOp.getInteriorPadding();
    if (edgePaddingLow.size() != edgePaddingHigh.size()) {
        return ProcessResult::Error("pad: edge padding rank mismatch");
    }
    if (edgePaddingLow.size() != interiorPadding.size()) {
        return ProcessResult::Error("pad: interior padding rank mismatch");
    }

    // Check if interior padding is all zeros (fast path).
    bool hasInteriorPadding = false;
    for (int64_t p : interiorPadding) {
        if (p < 0) {
            return ProcessResult::Error("pad: negative interior padding is not supported");
        }
        if (p != 0) {
            hasInteriorPadding = true;
            break;
        }
    }

    NSArray<NSNumber*>* inputShape = input.shape;
    if (inputShape.count != edgePaddingLow.size()) {
        return ProcessResult::Error("pad: input rank does not match padding rank");
    }

    // Get output shape and create a tensor filled with padding value
    NSArray<NSNumber*>* outputShape = GetOutputShape(ctx.op);
    MPSGraphTensor* padded = [ctx.graph broadcastTensor:paddingValue toShape:outputShape name:nil];

    if (hasInteriorPadding) {
        NSUInteger rank = inputShape.count;
        NSMutableArray<NSNumber*>* preCropShape = [NSMutableArray arrayWithCapacity:rank];
        NSMutableArray<NSNumber*>* cropStarts = [NSMutableArray arrayWithCapacity:rank];
        NSMutableArray<NSNumber*>* cropEnds = [NSMutableArray arrayWithCapacity:rank];
        NSMutableArray<NSNumber*>* cropStrides = [NSMutableArray arrayWithCapacity:rank];

        bool hasElements = true;
        bool needsCrop = false;
        for (NSUInteger i = 0; i < rank; ++i) {
            int64_t low = edgePaddingLow[i];
            int64_t high = edgePaddingHigh[i];
            int64_t interior = interiorPadding[i];
            int64_t inputDim = [inputShape[i] longLongValue];
            int64_t outputDim = [outputShape[i] longLongValue];
            if (inputDim < 0 || outputDim < 0) {
                return ProcessResult::Error("pad: negative input/output dimension");
            }

            int64_t baseDim = 0;
            if (inputDim > 0) {
                baseDim = inputDim + (inputDim - 1) * interior;
            }
            int64_t preDim = std::max<int64_t>(low, 0) + baseDim + std::max<int64_t>(high, 0);
            int64_t cropLow = std::max<int64_t>(-low, 0);
            int64_t cropHigh = std::max<int64_t>(-high, 0);
            int64_t expectedOut = preDim - cropLow - cropHigh;
            if (expectedOut != outputDim) {
                return ProcessResult::Error("pad: inconsistent output shape for padding config");
            }

            if (low < 0 || high < 0) {
                needsCrop = true;
            }
            if (inputDim == 0 || outputDim == 0) {
                hasElements = false;
            }
            [preCropShape addObject:@(preDim)];
            [cropStarts addObject:@(cropLow)];
            [cropEnds addObject:@(cropLow + outputDim)];
            [cropStrides addObject:@1];
        }

        MPSGraphTensor* prePadded =
            [ctx.graph broadcastTensor:paddingValue toShape:preCropShape name:nil];

        if (!hasElements) {
            MPSGraphTensor* result = prePadded;
            if (needsCrop) {
                result = [ctx.graph sliceTensor:result
                                         starts:cropStarts
                                           ends:cropEnds
                                        strides:cropStrides
                                           name:nil];
            }
            if (outputShape && result) {
                result = [ctx.graph reshapeTensor:result withShape:outputShape name:nil];
            }
            return Result(ctx, result, "pad");
        }

        // Scatter input values into their interior-dilated coordinates.
        NSMutableArray<MPSGraphTensor*>* indexTensors = [NSMutableArray arrayWithCapacity:rank];
        for (NSUInteger dim = 0; dim < rank; ++dim) {
            MPSGraphTensor* coords = [ctx.graph coordinateAlongAxis:(NSInteger)dim
                                                          withShape:inputShape
                                                               name:nil];
            int64_t interior = interiorPadding[dim];
            int64_t step = interior + 1;
            if (step != 1) {
                MPSGraphTensor* stepTensor =
                    [ctx.graph constantWithScalar:step dataType:coords.dataType];
                coords = [ctx.graph multiplicationWithPrimaryTensor:coords
                                                     secondaryTensor:stepTensor
                                                                name:nil];
            }
            int64_t low = edgePaddingLow[dim];
            int64_t shift = std::max<int64_t>(low, 0);
            if (shift != 0) {
                MPSGraphTensor* shiftTensor =
                    [ctx.graph constantWithScalar:shift dataType:coords.dataType];
                coords = [ctx.graph additionWithPrimaryTensor:coords
                                               secondaryTensor:shiftTensor
                                                          name:nil];
            }
            [indexTensors addObject:coords];
        }

        MPSGraphTensor* indices =
            [ctx.graph stackTensors:indexTensors axis:(NSInteger)rank name:nil];
        indices = EnsureInt32(ctx.graph, indices);
        MPSGraphTensor* result = [ctx.graph scatterNDWithDataTensor:prePadded
                                                      updatesTensor:input
                                                      indicesTensor:indices
                                                    batchDimensions:0
                                                               mode:MPSGraphScatterModeSet
                                                               name:nil];
        if (needsCrop) {
            result = [ctx.graph sliceTensor:result
                                     starts:cropStarts
                                       ends:cropEnds
                                    strides:cropStrides
                                       name:nil];
        }
        if (outputShape && result) {
            result = [ctx.graph reshapeTensor:result withShape:outputShape name:nil];
        }
        return Result(ctx, result, "pad");
    }

    // StableHLO pad supports negative edge paddings (cropping).
    // We lower this by slicing the input first, then updating the padded output.
    NSMutableArray<NSNumber*>* inputSliceStarts = [NSMutableArray array];
    NSMutableArray<NSNumber*>* inputSliceEnds = [NSMutableArray array];
    NSMutableArray<NSNumber*>* inputSliceStrides = [NSMutableArray array];

    NSMutableArray<NSNumber*>* starts = [NSMutableArray array];
    NSMutableArray<NSNumber*>* ends = [NSMutableArray array];
    NSMutableArray<NSNumber*>* strides = [NSMutableArray array];

    bool needsInputSlice = false;
    bool hasNonEmptyUpdate = true;
    for (NSUInteger i = 0; i < edgePaddingLow.size(); i++) {
        int64_t low = edgePaddingLow[i];
        int64_t high = edgePaddingHigh[i];
        int64_t inputDim = [inputShape[i] longLongValue];
        int64_t cropLow = std::max<int64_t>(-low, 0);
        int64_t cropHigh = std::max<int64_t>(-high, 0);
        int64_t sliceStart = cropLow;
        int64_t sliceEnd = inputDim - cropHigh;
        if (sliceEnd < sliceStart) {
            sliceEnd = sliceStart;
        }
        int64_t slicedDim = sliceEnd - sliceStart;
        if (slicedDim == 0) {
            hasNonEmptyUpdate = false;
        }
        if (sliceStart != 0 || sliceEnd != inputDim) {
            needsInputSlice = true;
        }
        [inputSliceStarts addObject:@(sliceStart)];
        [inputSliceEnds addObject:@(sliceEnd)];
        [inputSliceStrides addObject:@1];

        int64_t outputStart = std::max<int64_t>(low, 0);
        [starts addObject:@(outputStart)];
        [ends addObject:@(outputStart + slicedDim)];
        [strides addObject:@1];
    }

    if (!hasNonEmptyUpdate) {
        return Result(ctx, padded, "pad");
    }

    MPSGraphTensor* updateTensor = input;
    if (needsInputSlice) {
        updateTensor = [ctx.graph sliceTensor:input
                                       starts:inputSliceStarts
                                         ends:inputSliceEnds
                                      strides:inputSliceStrides
                                         name:nil];
    }

    // Use sliceUpdateDataTensor to insert input into the padded tensor
    MPSGraphTensor* result = [ctx.graph sliceUpdateDataTensor:padded
                                                 updateTensor:updateTensor
                                                       starts:starts
                                                         ends:ends
                                                      strides:strides
                                                         name:nil];
    return Result(ctx, result, "pad");
}
REGISTER_MPS_OP("stablehlo.pad", HandlePad);

// Dynamic update slice - update a portion of a tensor with new values
static ProcessResult HandleDynamicUpdateSlice(HandlerContext& ctx) {
    auto updateSliceOp = mlir::dyn_cast<mlir::stablehlo::DynamicUpdateSliceOp>(ctx.op);
    if (!updateSliceOp) {
        return ProcessResult::Error("dynamic_update_slice: expected DynamicUpdateSliceOp");
    }

    MPSGraphTensor* operand = GetInputTensor(ctx, 0);
    MPSGraphTensor* update = GetInputTensor(ctx, 1);
    if (!operand || !update)
        return ProcessResult::Error("dynamic_update_slice: missing input tensor");

    NSArray<NSNumber*>* operandShape = operand.shape;
    NSArray<NSNumber*>* updateShape = update.shape;
    NSUInteger rank = updateShape.count;
    if (operandShape.count != rank) {
        return ProcessResult::Error(
            "dynamic_update_slice: operand rank does not match update rank");
    }

    // Get start indices (operands 2 through N)
    NSMutableArray<MPSGraphTensor*>* startIndices = [NSMutableArray array];
    for (NSUInteger i = 0; i < rank; i++) {
        MPSGraphTensor* startIdx = GetInputTensor(ctx, i + 2);
        if (!startIdx) {
            return ProcessResult::Error("dynamic_update_slice: missing start index");
        }
        [startIndices addObject:startIdx];
    }

    // Build starts array by reading the scalar start indices
    // For sliceUpdateDataTensor, we need static starts/ends/strides
    // But the start indices are dynamic tensors, so we need to use scatter instead

    // Create coordinate tensors for the update region
    NSMutableArray<MPSGraphTensor*>* indexTensors = [NSMutableArray array];
    for (NSUInteger dim = 0; dim < rank; dim++) {
        MPSGraphTensor* startIdx = EnsureInt32(ctx.graph, startIndices[dim]);

        // Clamp start indices to keep the update in-bounds (XLA semantics).
        int64_t operandDim = [operandShape[dim] longLongValue];
        int64_t updateDim = [updateShape[dim] longLongValue];
        int64_t maxStart = operandDim - updateDim;
        if (maxStart < 0) {
            return ProcessResult::Error(
                "dynamic_update_slice: update dimension exceeds operand dimension");
        }
        MPSGraphTensor* zero = [ctx.graph constantWithScalar:0 dataType:startIdx.dataType];
        MPSGraphTensor* maxStartTensor =
            [ctx.graph constantWithScalar:maxStart dataType:startIdx.dataType];
        startIdx = [ctx.graph maximumWithPrimaryTensor:startIdx secondaryTensor:zero name:nil];
        startIdx =
            [ctx.graph minimumWithPrimaryTensor:startIdx secondaryTensor:maxStartTensor name:nil];

        // Create coordinate tensor for this dimension (0, 1, 2, ..., update_size-1)
        MPSGraphTensor* coords = [ctx.graph coordinateAlongAxis:(NSInteger)dim
                                                      withShape:updateShape
                                                           name:nil];
        coords = [ctx.graph castTensor:coords toType:startIdx.dataType name:nil];

        // Add start index to coordinates
        MPSGraphTensor* adjustedCoords = [ctx.graph additionWithPrimaryTensor:coords
                                                              secondaryTensor:startIdx
                                                                         name:nil];

        [indexTensors addObject:adjustedCoords];
    }

    // Stack the coordinate tensors along a new last axis to form indices tensor
    MPSGraphTensor* indices = [ctx.graph stackTensors:indexTensors axis:(NSInteger)rank name:nil];

    // Cast indices to int32 if needed
    indices = EnsureInt32(ctx.graph, indices);

    // Use scatterND to update the operand at the specified indices
    MPSGraphTensor* result = [ctx.graph scatterNDWithDataTensor:operand
                                                  updatesTensor:update
                                                  indicesTensor:indices
                                                batchDimensions:0
                                                           mode:MPSGraphScatterModeSet
                                                           name:nil];
    return Result(ctx, result, "dynamic_update_slice");
}
REGISTER_MPS_OP("stablehlo.dynamic_update_slice", HandleDynamicUpdateSlice);

static std::string JoinInts(llvm::ArrayRef<int64_t> values) {
    std::ostringstream oss;
    oss << "[";
    for (size_t i = 0; i < values.size(); ++i) {
        if (i > 0) {
            oss << ", ";
        }
        oss << values[i];
    }
    oss << "]";
    return oss.str();
}

static std::string ShapeToString(NSArray<NSNumber*>* shape) {
    std::ostringstream oss;
    oss << "[";
    for (NSUInteger i = 0; i < shape.count; ++i) {
        if (i > 0) {
            oss << ", ";
        }
        oss << [shape[i] longLongValue];
    }
    oss << "]";
    return oss.str();
}

static bool ContainsDim(llvm::ArrayRef<int64_t> dims, int64_t dim) {
    for (int64_t d : dims) {
        if (d == dim)
            return true;
    }
    return false;
}

static bool IsIdentityPermutation(NSArray<NSNumber*>* permutation) {
    for (NSUInteger i = 0; i < permutation.count; ++i) {
        if ([permutation[i] integerValue] != (NSInteger)i) {
            return false;
        }
    }
    return true;
}

static std::string GatherDebugString(mlir::stablehlo::GatherOp gatherOp, MPSGraphTensor* operand,
                                     MPSGraphTensor* startIndices) {
    auto dimNumbers = gatherOp.getDimensionNumbers();
    auto offsetDims = dimNumbers.getOffsetDims();
    auto collapsedSliceDims = dimNumbers.getCollapsedSliceDims();
    auto operandBatchingDims = dimNumbers.getOperandBatchingDims();
    auto startIndicesBatchingDims = dimNumbers.getStartIndicesBatchingDims();
    auto startIndexMap = dimNumbers.getStartIndexMap();
    auto sliceSizes = gatherOp.getSliceSizes();
    std::ostringstream oss;
    oss << "operand_shape=" << ShapeToString(operand.shape)
        << ", indices_shape=" << ShapeToString(startIndices.shape)
        << ", offset_dims=" << JoinInts(offsetDims)
        << ", collapsed_slice_dims=" << JoinInts(collapsedSliceDims)
        << ", operand_batching_dims=" << JoinInts(operandBatchingDims)
        << ", start_indices_batching_dims=" << JoinInts(startIndicesBatchingDims)
        << ", start_index_map=" << JoinInts(startIndexMap)
        << ", index_vector_dim=" << dimNumbers.getIndexVectorDim()
        << ", slice_sizes=" << JoinInts(sliceSizes);
    return oss.str();
}

// Gather - generalized indexing operation
// Handles embedding lookups and other gather patterns
static ProcessResult HandleGather(HandlerContext& ctx) {
    auto gatherOp = mlir::dyn_cast<mlir::stablehlo::GatherOp>(ctx.op);
    if (!gatherOp) {
        return ProcessResult::Error("gather: expected GatherOp");
    }

    MPSGraphTensor* operand = GetInputTensor(ctx, 0);
    MPSGraphTensor* startIndices = GetInputTensor(ctx, 1);
    if (!operand || !startIndices)
        return ProcessResult::Error("gather: missing input tensor");

    auto dimNumbers = gatherOp.getDimensionNumbers();
    auto offsetDims = dimNumbers.getOffsetDims();
    auto collapsedSliceDims = dimNumbers.getCollapsedSliceDims();
    auto operandBatchingDims = dimNumbers.getOperandBatchingDims();
    auto startIndicesBatchingDims = dimNumbers.getStartIndicesBatchingDims();
    auto startIndexMap = dimNumbers.getStartIndexMap();
    int64_t indexVectorDim = dimNumbers.getIndexVectorDim();
    auto sliceSizes = gatherOp.getSliceSizes();

    // Handle common embedding lookup pattern:
    // operand: [num_embeddings, embedding_dim]
    // indices: [batch..., 1] where the last dim is the index vector
    // offset_dims: [last_dim] - the embedding dimension
    // collapsed_slice_dims: [0] - the looked-up dimension
    // start_index_map: [0] - indices point into dim 0

    NSArray<NSNumber*>* indicesShape = startIndices.shape;
    NSArray<NSNumber*>* operandShape = operand.shape;
    NSUInteger indicesRank = indicesShape.count;
    NSUInteger operandRank = operandShape.count;

    bool collapsedGatherDim = startIndexMap.size() == 1 && collapsedSliceDims.size() == 1 &&
                              collapsedSliceDims[0] == startIndexMap[0];
    bool nonCollapsedGatherDim = startIndexMap.size() == 1 && collapsedSliceDims.empty();

    // Embedding gather (unbatched and 1D-batched variants).
    bool embeddingPattern = indicesRank > 0 && indexVectorDim == (int64_t)indicesRank - 1 &&
                            [indicesShape[indicesRank - 1] integerValue] == 1 &&
                            startIndexMap.size() == 1 &&
                            (collapsedGatherDim || nonCollapsedGatherDim) &&
                            startIndexMap[0] >= 0 && startIndexMap[0] < (int64_t)sliceSizes.size() &&
                            sliceSizes[startIndexMap[0]] == 1;
    if (embeddingPattern) {
        int64_t gatherAxis = startIndexMap[0];
        if (gatherAxis < 0 || gatherAxis >= (int64_t)operandRank) {
            return ProcessResult::Error("gather: gather axis out of bounds (" +
                                        GatherDebugString(gatherOp, operand, startIndices) + ")");
        }

        NSUInteger batchDimensions = 0;
        if (!operandBatchingDims.empty() || !startIndicesBatchingDims.empty()) {
            if (operandBatchingDims.size() != 1 || startIndicesBatchingDims.size() != 1 ||
                operandBatchingDims[0] != 0 || startIndicesBatchingDims[0] != 0) {
                return ProcessResult::Error(
                    "gather: unsupported batched embedding layout (" +
                    GatherDebugString(gatherOp, operand, startIndices) + ")");
            }
            batchDimensions = 1;
        }

        // StableHLO semantics: operand dims that are not indexed (start_index_map) and not
        // batching dims are sliced starting at 0 with length slice_sizes[dim].
        //
        // MPSGraph gather returns full slices for these dims, so if slice_sizes request a smaller
        // window we slice the operand first.
        if (sliceSizes.size() == operandRank) {
            bool needsSlice = false;
            NSMutableArray<NSNumber*>* starts = [NSMutableArray arrayWithCapacity:operandRank];
            NSMutableArray<NSNumber*>* ends = [NSMutableArray arrayWithCapacity:operandRank];
            NSMutableArray<NSNumber*>* strides = [NSMutableArray arrayWithCapacity:operandRank];
            for (NSUInteger dim = 0; dim < operandRank; ++dim) {
                [starts addObject:@0];
                [strides addObject:@1];
                int64_t operandDim = [operand.shape[dim] longLongValue];
                int64_t end = operandDim;
                if ((int64_t)dim != gatherAxis && !ContainsDim(operandBatchingDims, (int64_t)dim)) {
                    int64_t slice = sliceSizes[dim];
                    if (slice < 0 || operandDim <= 0 || slice > operandDim) {
                        return ProcessResult::Error(
                            "gather: invalid slice_sizes for operand dim " + std::to_string(dim) +
                            " (" + GatherDebugString(gatherOp, operand, startIndices) + ")");
                    }
                    end = slice;
                    if (slice != operandDim) {
                        needsSlice = true;
                    }
                }
                [ends addObject:@(end)];
            }
            if (needsSlice) {
                operand =
                    [ctx.graph sliceTensor:operand starts:starts ends:ends strides:strides name:nil];
                operandShape = operand.shape;
            }
        }

        MPSGraphTensor* gatherIndices = startIndices;
        if (collapsedGatherDim) {
            // Squeeze [batch..., 1] -> [batch...] when gather dim is collapsed.
            NSMutableArray<NSNumber*>* squeezedShape = [NSMutableArray array];
            for (NSUInteger i = 0; i < indicesRank - 1; i++) {
                [squeezedShape addObject:indicesShape[i]];
            }
            gatherIndices = [ctx.graph reshapeTensor:startIndices withShape:squeezedShape name:nil];
        }

        // Cast indices to int32 if needed (MPS gather requires int32).
        gatherIndices = EnsureInt32(ctx.graph, gatherIndices);

        // Use gatherWithUpdatesTensor:indicesTensor:axis:batchDimensions:
        // This gathers slices from operand along the specified axis using indices
        // Result shape: indices.shape + operand.shape[axis+1:]
        // For embedding [100, 5] with indices [3]: result is [3, 5]
        MPSGraphTensor* result = [ctx.graph gatherWithUpdatesTensor:operand
                                                      indicesTensor:gatherIndices
                                                               axis:(NSUInteger)gatherAxis
                                                    batchDimensions:batchDimensions
                                                               name:nil];
        NSArray<NSNumber*>* expectedShape = GetOutputShape(ctx.op);
        if (expectedShape && result) {
            result = [ctx.graph reshapeTensor:result withShape:expectedShape name:nil];
        }

        return Result(ctx, result, "gather");
    }

    // Point-index gather lowering via gatherND.
    // Supports patterns where start_index_map dims are fully collapsed with slice_sizes=1.
    bool pointGatherNdPattern = indicesRank > 0 && indexVectorDim == (int64_t)indicesRank - 1 &&
                                startIndexMap.size() > 1 && operandBatchingDims.empty() &&
                                startIndicesBatchingDims.empty() &&
                                (NSUInteger)startIndexMap.size() == [indicesShape[indicesRank - 1] integerValue] &&
                                collapsedSliceDims.size() == startIndexMap.size() &&
                                sliceSizes.size() == operandRank;
    if (pointGatherNdPattern) {
        bool mappingValid = true;
        for (int64_t mappedDim : startIndexMap) {
            if (mappedDim < 0 || mappedDim >= (int64_t)operandRank || !ContainsDim(collapsedSliceDims, mappedDim) ||
                sliceSizes[mappedDim] != 1) {
                mappingValid = false;
                break;
            }
        }
        if (!mappingValid) {
            pointGatherNdPattern = false;
        }
    }

    if (pointGatherNdPattern) {
        // StableHLO semantics: operand dims that are not indexed by start_index_map are sliced
        // starting at 0 with length slice_sizes[dim]. If any such slice_sizes are smaller than the
        // operand dimension, slice the operand first so gatherND's "full remaining dims" match.
        if (sliceSizes.size() == operandRank) {
            bool needsSlice = false;
            NSMutableArray<NSNumber*>* starts = [NSMutableArray arrayWithCapacity:operandRank];
            NSMutableArray<NSNumber*>* ends = [NSMutableArray arrayWithCapacity:operandRank];
            NSMutableArray<NSNumber*>* strides = [NSMutableArray arrayWithCapacity:operandRank];
            for (NSUInteger dim = 0; dim < operandRank; ++dim) {
                [starts addObject:@0];
                [strides addObject:@1];
                int64_t operandDim = [operand.shape[dim] longLongValue];
                int64_t end = operandDim;
                if (!ContainsDim(startIndexMap, (int64_t)dim)) {
                    int64_t slice = sliceSizes[dim];
                    if (slice < 0 || operandDim <= 0 || slice > operandDim) {
                        return ProcessResult::Error(
                            "gather: invalid slice_sizes for operand dim " + std::to_string(dim) +
                            " (" + GatherDebugString(gatherOp, operand, startIndices) + ")");
                    }
                    end = slice;
                    if (slice != operandDim) {
                        needsSlice = true;
                    }
                }
                [ends addObject:@(end)];
            }
            if (needsSlice) {
                operand =
                    [ctx.graph sliceTensor:operand starts:starts ends:ends strides:strides name:nil];
                operandShape = operand.shape;
            }
        }

        NSUInteger indexPrefixRank = indicesRank - 1;
        NSUInteger mappedRank = startIndexMap.size();
        NSUInteger remainingRank = operandRank - mappedRank;
        NSUInteger outputRank = indexPrefixRank + remainingRank;

        if (offsetDims.size() != remainingRank) {
            return ProcessResult::Error("gather: unsupported gatherND offset dims (" +
                                        GatherDebugString(gatherOp, operand, startIndices) + ")");
        }

        NSMutableArray<NSNumber*>* operandPerm = [NSMutableArray arrayWithCapacity:operandRank];
        std::vector<bool> isMapped(operandRank, false);
        for (int64_t mappedDim : startIndexMap) {
            if (mappedDim < 0 || mappedDim >= (int64_t)operandRank || isMapped[mappedDim]) {
                return ProcessResult::Error("gather: invalid start_index_map for gatherND (" +
                                            GatherDebugString(gatherOp, operand, startIndices) +
                                            ")");
            }
            isMapped[mappedDim] = true;
            [operandPerm addObject:@(mappedDim)];
        }
        for (NSUInteger dim = 0; dim < operandRank; ++dim) {
            if (!isMapped[dim]) {
                [operandPerm addObject:@((NSInteger)dim)];
            }
        }

        MPSGraphTensor* transposedOperand = operand;
        if (!IsIdentityPermutation(operandPerm)) {
            transposedOperand = [ctx.graph transposeTensor:operand permutation:operandPerm name:nil];
        }

        MPSGraphTensor* int32Indices = EnsureInt32(ctx.graph, startIndices);
        MPSGraphTensor* gathered = [ctx.graph gatherNDWithUpdatesTensor:transposedOperand
                                                          indicesTensor:int32Indices
                                                        batchDimensions:0
                                                                   name:nil];

        // gatherND output order is [index_prefix_dims, remaining_dims].
        // Reorder to StableHLO output order using offset_dims.
        std::vector<int64_t> remainingDimToOutputAxis(remainingRank, -1);
        std::vector<bool> outputAxisUsed(outputRank, false);
        for (NSUInteger rem = 0; rem < remainingRank; ++rem) {
            int64_t axis = offsetDims[rem];
            if (axis < 0 || axis >= (int64_t)outputRank || outputAxisUsed[axis]) {
                return ProcessResult::Error("gather: invalid offset_dims for gatherND (" +
                                            GatherDebugString(gatherOp, operand, startIndices) +
                                            ")");
            }
            outputAxisUsed[axis] = true;
            remainingDimToOutputAxis[rem] = axis;
        }

        NSMutableArray<NSNumber*>* outputPermutation = [NSMutableArray arrayWithCapacity:outputRank];
        NSUInteger nextPrefixDim = 0;
        for (NSUInteger outAxis = 0; outAxis < outputRank; ++outAxis) {
            bool isOffsetAxis = false;
            NSUInteger remSourceIndex = 0;
            for (; remSourceIndex < remainingRank; ++remSourceIndex) {
                if (remainingDimToOutputAxis[remSourceIndex] == (int64_t)outAxis) {
                    isOffsetAxis = true;
                    break;
                }
            }

            NSInteger sourceAxis = 0;
            if (isOffsetAxis) {
                sourceAxis = (NSInteger)(indexPrefixRank + remSourceIndex);
            } else {
                if (nextPrefixDim >= indexPrefixRank) {
                    return ProcessResult::Error("gather: invalid prefix/offset mapping (" +
                                                GatherDebugString(gatherOp, operand, startIndices) +
                                                ")");
                }
                sourceAxis = (NSInteger)nextPrefixDim;
                ++nextPrefixDim;
            }
            [outputPermutation addObject:@(sourceAxis)];
        }

        MPSGraphTensor* result = gathered;
        if (outputRank > 1 && !IsIdentityPermutation(outputPermutation)) {
            result = [ctx.graph transposeTensor:gathered permutation:outputPermutation name:nil];
        }
        NSArray<NSNumber*>* expectedShape = GetOutputShape(ctx.op);
        if (expectedShape && result) {
            result = [ctx.graph reshapeTensor:result withShape:expectedShape name:nil];
        }
        return Result(ctx, result, "gather");
    }

    return ProcessResult::Error("gather: unsupported gather pattern (" +
                                GatherDebugString(gatherOp, operand, startIndices) + ")");
}
REGISTER_MPS_OP("stablehlo.gather", HandleGather);

// Helper to determine scatter mode from the update computation region
static MPSGraphScatterMode GetScatterMode(mlir::stablehlo::ScatterOp scatterOp) {
    MPSGraphScatterMode mode = MPSGraphScatterModeSet;
    auto& updateRegion = scatterOp.getUpdateComputation();
    if (!updateRegion.empty()) {
        auto& block = updateRegion.front();
        for (auto& innerOp : block) {
            if (mlir::isa<mlir::stablehlo::AddOp>(innerOp)) {
                return MPSGraphScatterModeAdd;
            } else if (mlir::isa<mlir::stablehlo::SubtractOp>(innerOp)) {
                return MPSGraphScatterModeSub;
            } else if (mlir::isa<mlir::stablehlo::MulOp>(innerOp)) {
                return MPSGraphScatterModeMul;
            } else if (mlir::isa<mlir::stablehlo::DivOp>(innerOp)) {
                return MPSGraphScatterModeDiv;
            } else if (mlir::isa<mlir::stablehlo::MaxOp>(innerOp)) {
                return MPSGraphScatterModeMax;
            } else if (mlir::isa<mlir::stablehlo::MinOp>(innerOp)) {
                return MPSGraphScatterModeMin;
            }
        }
    }
    return mode;
}

static std::string ScatterDebugString(mlir::stablehlo::ScatterOp scatterOp, MPSGraphTensor* input,
                                      MPSGraphTensor* scatterIndices,
                                      MPSGraphTensor* updates) {
    auto dimNumbers = scatterOp.getScatterDimensionNumbers();
    auto updateWindowDims = dimNumbers.getUpdateWindowDims();
    auto insertedWindowDims = dimNumbers.getInsertedWindowDims();
    auto scatterDimsToOperandDims = dimNumbers.getScatterDimsToOperandDims();
    auto inputBatchingDims = dimNumbers.getInputBatchingDims();
    auto scatterIndicesBatchingDims = dimNumbers.getScatterIndicesBatchingDims();
    std::ostringstream oss;
    oss << "input_shape=" << ShapeToString(input.shape)
        << ", indices_shape=" << ShapeToString(scatterIndices.shape)
        << ", updates_shape=" << ShapeToString(updates.shape)
        << ", update_window_dims=" << JoinInts(updateWindowDims)
        << ", inserted_window_dims=" << JoinInts(insertedWindowDims)
        << ", scatter_dims_to_operand_dims=" << JoinInts(scatterDimsToOperandDims)
        << ", input_batching_dims=" << JoinInts(inputBatchingDims)
        << ", scatter_indices_batching_dims=" << JoinInts(scatterIndicesBatchingDims)
        << ", index_vector_dim=" << dimNumbers.getIndexVectorDim();
    return oss.str();
}

// Scatter - update tensor at specified indices
// This handles the common pattern used by gather gradients
static ProcessResult HandleScatter(HandlerContext& ctx) {
    auto scatterOp = mlir::dyn_cast<mlir::stablehlo::ScatterOp>(ctx.op);
    if (!scatterOp) {
        return ProcessResult::Error("scatter: expected ScatterOp");
    }

    // Get inputs (may be variadic, but we handle single input case)
    MPSGraphTensor* input = GetInputTensor(ctx, 0);
    MPSGraphTensor* scatterIndices = GetInputTensor(ctx, 1);
    MPSGraphTensor* updates = GetInputTensor(ctx, 2);
    if (!input || !scatterIndices || !updates)
        return ProcessResult::Error("scatter: missing input tensor");

    auto dimNumbers = scatterOp.getScatterDimensionNumbers();
    auto updateWindowDims = dimNumbers.getUpdateWindowDims();
    auto insertedWindowDims = dimNumbers.getInsertedWindowDims();
    auto scatterDimsToOperandDims = dimNumbers.getScatterDimsToOperandDims();
    auto inputBatchingDims = dimNumbers.getInputBatchingDims();
    auto scatterIndicesBatchingDims = dimNumbers.getScatterIndicesBatchingDims();
    int64_t indexVectorDim = dimNumbers.getIndexVectorDim();

    NSArray<NSNumber*>* indicesShape = scatterIndices.shape;
    NSUInteger indicesRank = indicesShape.count;
    MPSGraphScatterMode mode = GetScatterMode(scatterOp);

    // Diagonal scatter-add:
    // input [N, N], indices [N, 2], updates [N],
    // dim_numbers inserted_window_dims=[0,1], scatter_dims_to_operand_dims=[0,1],
    // index_vector_dim=1, additive combiner.
    if (mode == MPSGraphScatterModeAdd && input.shape.count == 2 && updates.shape.count == 1 &&
        inputBatchingDims.empty() && scatterIndicesBatchingDims.empty() &&
        updateWindowDims.empty() && insertedWindowDims.size() == 2 &&
        scatterDimsToOperandDims.size() == 2 && insertedWindowDims[0] == 0 &&
        insertedWindowDims[1] == 1 && scatterDimsToOperandDims[0] == 0 &&
        scatterDimsToOperandDims[1] == 1 && indexVectorDim == (int64_t)indicesRank - 1 &&
        [indicesShape[indicesRank - 1] integerValue] == 2) {
        MPSGraphTensor* int32Indices = EnsureInt32(ctx.graph, scatterIndices);
        MPSGraphTensor* result = [ctx.graph scatterNDWithDataTensor:input
                                                      updatesTensor:updates
                                                      indicesTensor:int32Indices
                                                    batchDimensions:0
                                                               mode:mode
                                                               name:nil];
        return Result(ctx, result, "scatter");
    }

    // Batched diagonal scatter-add:
    // input [B, N, N], indices [N, 2], updates [B, N],
    // dim_numbers update_window_dims=[0], inserted_window_dims=[1,2],
    // scatter_dims_to_operand_dims=[1,2], index_vector_dim=1.
    if (mode == MPSGraphScatterModeAdd && input.shape.count == 3 && updates.shape.count == 2 &&
        inputBatchingDims.empty() && scatterIndicesBatchingDims.empty() &&
        updateWindowDims.size() == 1 && updateWindowDims[0] == 0 &&
        insertedWindowDims.size() == 2 && insertedWindowDims[0] == 1 &&
        insertedWindowDims[1] == 2 && scatterDimsToOperandDims.size() == 2 &&
        scatterDimsToOperandDims[0] == 1 && scatterDimsToOperandDims[1] == 2 &&
        indexVectorDim == (int64_t)indicesRank - 1 &&
        [indicesShape[indicesRank - 1] integerValue] == 2) {
        NSMutableArray<NSNumber*>* expandedIndicesShape =
            [NSMutableArray arrayWithCapacity:indicesRank + 1];
        [expandedIndicesShape addObject:@1];
        for (NSUInteger i = 0; i < indicesRank; ++i) {
            [expandedIndicesShape addObject:indicesShape[i]];
        }
        MPSGraphTensor* expandedIndices = [ctx.graph reshapeTensor:scatterIndices
                                                         withShape:expandedIndicesShape
                                                              name:nil];

        NSMutableArray<NSNumber*>* broadcastShape = [NSMutableArray arrayWithCapacity:indicesRank + 1];
        [broadcastShape addObject:input.shape[0]];
        for (NSUInteger i = 0; i < indicesRank; ++i) {
            [broadcastShape addObject:indicesShape[i]];
        }
        MPSGraphTensor* batchedIndices = [ctx.graph broadcastTensor:expandedIndices
                                                             toShape:broadcastShape
                                                                name:nil];
        batchedIndices = EnsureInt32(ctx.graph, batchedIndices);

        MPSGraphTensor* result = [ctx.graph scatterNDWithDataTensor:input
                                                      updatesTensor:updates
                                                      indicesTensor:batchedIndices
                                                    batchDimensions:1
                                                               mode:mode
                                                               name:nil];
        return Result(ctx, result, "scatter");
    }

    // Handle batched scatter pattern used by sort gradients:
    // Pattern: scatter with batching dimensions where each batch element scatters independently
    // Example: input [5,7], indices [5,7,1], updates [5,7]
    //   - input_batching_dims = [0], scatter_indices_batching_dims = [0]
    //   - For each batch i, scatter updates[i,:] into input[i,:] at indices[i,:,0]
    if (!inputBatchingDims.empty() && !scatterIndicesBatchingDims.empty() &&
        inputBatchingDims.size() == scatterIndicesBatchingDims.size() &&
        scatterDimsToOperandDims.size() == 1 && insertedWindowDims.size() == 1 &&
        indexVectorDim == (int64_t)indicesRank - 1 &&
        [indicesShape[indicesRank - 1] integerValue] == 1) {
        int64_t scatterAxis = scatterDimsToOperandDims[0];

        // This is a general "scatter along one axis" pattern, but StableHLO can represent
        // scatter updates that only cover a prefix window of some non-scatter dim(s)
        // (e.g., gather gradients with slice_sizes < full dim size).
        //
        // MPSGraph scatterAlongAxis requires:
        // - indices.shape == updates.shape
        // - data.shape == updates.shape, except at `axis`
        //
        // So we:
        // 1. slice the input tensor down to the updates window (if needed),
        // 2. broadcast indices to match updates rank,
        // 3. scatter along the axis,
        // 4. concatenate the untouched tail (only supported when at most one window dim is
        //    truncated).

        if (insertedWindowDims[0] != scatterAxis) {
            return ProcessResult::Error("scatter: unsupported batched scatter layout (" +
                                        ScatterDebugString(scatterOp, input, scatterIndices,
                                                           updates) +
                                        ")");
        }

        // Squeeze the index vector dimension from indices: [batch..., N, 1] -> [batch..., N]
        NSMutableArray<NSNumber*>* squeezedShape = [NSMutableArray array];
        for (NSUInteger i = 0; i < indicesRank - 1; i++) {
            [squeezedShape addObject:indicesShape[i]];
        }
        MPSGraphTensor* squeezedIndices = [ctx.graph reshapeTensor:scatterIndices
                                                         withShape:squeezedShape
                                                              name:nil];

        // Slice the input tensor down to the updates window (if necessary).
        MPSGraphTensor* scatterInput = input;
        NSInteger truncatedDim = -1;
        int64_t truncatedSize = -1;
        if (input.shape.count == updates.shape.count) {
            for (NSUInteger dim = 0; dim < input.shape.count; ++dim) {
                if ((int64_t)dim == scatterAxis) {
                    continue;
                }
                int64_t inDim = [input.shape[dim] longLongValue];
                int64_t upDim = [updates.shape[dim] longLongValue];
                if (inDim <= 0 || upDim < 0) {
                    return ProcessResult::Error("scatter: dynamic/unknown shapes not supported for "
                                                "window scatter");
                }
                if (upDim > inDim) {
                    return ProcessResult::Error(
                        "scatter: updates window exceeds input dim (" +
                        ScatterDebugString(scatterOp, input, scatterIndices, updates) + ")");
                }
                if (upDim < inDim) {
                    if (truncatedDim != -1) {
                        return ProcessResult::Error(
                            "scatter: multiple truncated window dims are not supported (" +
                            ScatterDebugString(scatterOp, input, scatterIndices, updates) + ")");
                    }
                    truncatedDim = (NSInteger)dim;
                    truncatedSize = upDim;
                }
            }

            if (truncatedDim != -1) {
                NSMutableArray<NSNumber*>* starts =
                    [NSMutableArray arrayWithCapacity:input.shape.count];
                NSMutableArray<NSNumber*>* ends = [NSMutableArray arrayWithCapacity:input.shape.count];
                NSMutableArray<NSNumber*>* strides =
                    [NSMutableArray arrayWithCapacity:input.shape.count];
                for (NSUInteger dim = 0; dim < input.shape.count; ++dim) {
                    [starts addObject:@0];
                    [strides addObject:@1];
                    int64_t end = [input.shape[dim] longLongValue];
                    if ((NSInteger)dim == truncatedDim) {
                        end = truncatedSize;
                    }
                    [ends addObject:@(end)];
                }
                scatterInput =
                    [ctx.graph sliceTensor:input starts:starts ends:ends strides:strides name:nil];
            }
        }

        // Broadcast indices to match updates shape (scatterAlongAxis requires equal shapes).
        MPSGraphTensor* indicesForScatter = squeezedIndices;
        NSUInteger idxRank = indicesForScatter.shape.count;
        NSUInteger updRank = updates.shape.count;
        if (idxRank > updRank) {
            return ProcessResult::Error("scatter: indices rank exceeds updates rank (" +
                                        ScatterDebugString(scatterOp, input, scatterIndices,
                                                           updates) +
                                        ")");
        }
        if (idxRank < updRank) {
            NSMutableArray<NSNumber*>* expandedShape =
                [NSMutableArray arrayWithCapacity:idxRank + (updRank - idxRank)];
            for (NSUInteger i = 0; i < idxRank; ++i) {
                [expandedShape addObject:indicesForScatter.shape[i]];
            }
            for (NSUInteger i = idxRank; i < updRank; ++i) {
                [expandedShape addObject:@1];
            }
            indicesForScatter =
                [ctx.graph reshapeTensor:indicesForScatter withShape:expandedShape name:nil];
        }
        if (updates.shape && indicesForScatter) {
            indicesForScatter = [ctx.graph broadcastTensor:indicesForScatter
                                                  toShape:updates.shape
                                                     name:nil];
        }
        indicesForScatter = EnsureInt32(ctx.graph, indicesForScatter);

        // Use scatterAlongAxis which handles batched scatter correctly:
        // For each position in updates, it scatters to the position given by indices at that
        // position
        MPSGraphTensor* resultWindow =
            [ctx.graph scatterAlongAxis:static_cast<NSInteger>(scatterAxis)
                           withDataTensor:scatterInput
                            updatesTensor:updates
                            indicesTensor:indicesForScatter
                                   mode:mode
                                   name:nil];

        if (truncatedDim == -1) {
            return Result(ctx, resultWindow, "scatter");
        }

        // Append the untouched tail from the original input along the truncated dim.
        int64_t inDim = [input.shape[truncatedDim] longLongValue];
        if (truncatedSize >= inDim) {
            return Result(ctx, resultWindow, "scatter");
        }
        NSMutableArray<NSNumber*>* tailStarts = [NSMutableArray arrayWithCapacity:input.shape.count];
        NSMutableArray<NSNumber*>* tailEnds = [NSMutableArray arrayWithCapacity:input.shape.count];
        NSMutableArray<NSNumber*>* tailStrides = [NSMutableArray arrayWithCapacity:input.shape.count];
        for (NSUInteger dim = 0; dim < input.shape.count; ++dim) {
            int64_t start = 0;
            int64_t end = [input.shape[dim] longLongValue];
            if ((NSInteger)dim == truncatedDim) {
                start = truncatedSize;
            }
            [tailStarts addObject:@(start)];
            [tailEnds addObject:@(end)];
            [tailStrides addObject:@1];
        }
        MPSGraphTensor* tail =
            [ctx.graph sliceTensor:input starts:tailStarts ends:tailEnds strides:tailStrides name:nil];
        MPSGraphTensor* result =
            [ctx.graph concatTensors:@[ resultWindow, tail ] dimension:truncatedDim name:nil];
        return Result(ctx, result, "scatter");
    }

    // Handle common embedding gradient pattern (reverse of gather):
    // input: [num_embeddings, embedding_dim] - zeros initially
    // indices: [batch..., 1] where last dim is index vector
    // updates: [batch..., embedding_dim] - gradients to scatter
    // Result: accumulate updates into input at specified indices

    // Check for the common pattern where:
    // - index_vector_dim is the last dimension of indices
    // - indices has size 1 in that dimension
    // - we're scattering along a single dimension
    // - no batching dimensions
    if (inputBatchingDims.empty() && indexVectorDim == (int64_t)indicesRank - 1 &&
        [indicesShape[indicesRank - 1] integerValue] == 1 && scatterDimsToOperandDims.size() == 1 &&
        insertedWindowDims.size() == 1 && insertedWindowDims[0] == scatterDimsToOperandDims[0]) {
        int64_t scatterAxis = scatterDimsToOperandDims[0];

        // Squeeze the index vector dimension from indices
        NSMutableArray<NSNumber*>* squeezedShape = [NSMutableArray array];
        for (NSUInteger i = 0; i < indicesRank - 1; i++) {
            [squeezedShape addObject:indicesShape[i]];
        }

        // If squeezing produces a scalar, keep as [1] so MPS has a valid rank for the axis
        if (squeezedShape.count == 0)
            [squeezedShape addObject:@1];

        MPSGraphTensor* squeezedIndices = [ctx.graph reshapeTensor:scatterIndices
                                                         withShape:squeezedShape
                                                              name:nil];
        squeezedIndices = EnsureInt32(ctx.graph, squeezedIndices);

        // Ensure updates is at least rank 1 (MPS doesn't support scalar updates)
        if (updates.shape.count == 0)
            updates = [ctx.graph reshapeTensor:updates withShape:@[@1] name:nil];

        // StableHLO scatter can represent "window scatters" where updates only cover a prefix of
        // non-scatter dims (e.g., gradient of gather with slice_sizes < full dim size).
        //
        // MPSGraph scatter expects updates to match the full non-scatter shape, so we:
        // 1. slice the input tensor down to the updates window,
        // 2. scatter into the sliced input,
        // 3. concatenate the untouched tail of the original input (only supported when at most
        //    one window dim is truncated).
        MPSGraphTensor* scatterInput = input;
        NSInteger truncatedDim = -1;
        int64_t truncatedSize = -1;
        if (input.shape.count == updates.shape.count) {
            for (NSUInteger dim = 0; dim < input.shape.count; ++dim) {
                if ((int64_t)dim == scatterAxis) {
                    continue;
                }
                int64_t inDim = [input.shape[dim] longLongValue];
                int64_t upDim = [updates.shape[dim] longLongValue];
                if (inDim <= 0 || upDim < 0) {
                    return ProcessResult::Error("scatter: dynamic/unknown shapes not supported for "
                                                "window scatter");
                }
                if (upDim > inDim) {
                    return ProcessResult::Error(
                        "scatter: updates window exceeds input dim (" +
                        ScatterDebugString(scatterOp, input, scatterIndices, updates) + ")");
                }
                if (upDim < inDim) {
                    if (truncatedDim != -1) {
                        return ProcessResult::Error(
                            "scatter: multiple truncated window dims are not supported (" +
                            ScatterDebugString(scatterOp, input, scatterIndices, updates) + ")");
                    }
                    truncatedDim = (NSInteger)dim;
                    truncatedSize = upDim;
                }
            }

            if (truncatedDim != -1) {
                NSMutableArray<NSNumber*>* starts =
                    [NSMutableArray arrayWithCapacity:input.shape.count];
                NSMutableArray<NSNumber*>* ends =
                    [NSMutableArray arrayWithCapacity:input.shape.count];
                NSMutableArray<NSNumber*>* strides =
                    [NSMutableArray arrayWithCapacity:input.shape.count];
                for (NSUInteger dim = 0; dim < input.shape.count; ++dim) {
                    [starts addObject:@0];
                    [strides addObject:@1];
                    int64_t end = [input.shape[dim] longLongValue];
                    if ((NSInteger)dim == truncatedDim) {
                        end = truncatedSize;
                    }
                    [ends addObject:@(end)];
                }
                scatterInput =
                    [ctx.graph sliceTensor:input starts:starts ends:ends strides:strides name:nil];
            }
        }

        // Scatter into the (possibly sliced) input.
        MPSGraphTensor* resultWindow =
            [ctx.graph scatterWithDataTensor:scatterInput
                               updatesTensor:updates
                               indicesTensor:squeezedIndices
                                        axis:static_cast<NSInteger>(scatterAxis)
                                        mode:mode
                                        name:nil];

        if (truncatedDim == -1) {
            return Result(ctx, resultWindow, "scatter");
        }

        // Append the untouched tail from the original input along the truncated dim.
        int64_t inDim = [input.shape[truncatedDim] longLongValue];
        if (truncatedSize >= inDim) {
            return Result(ctx, resultWindow, "scatter");
        }
        NSMutableArray<NSNumber*>* tailStarts = [NSMutableArray arrayWithCapacity:input.shape.count];
        NSMutableArray<NSNumber*>* tailEnds = [NSMutableArray arrayWithCapacity:input.shape.count];
        NSMutableArray<NSNumber*>* tailStrides = [NSMutableArray arrayWithCapacity:input.shape.count];
        for (NSUInteger dim = 0; dim < input.shape.count; ++dim) {
            int64_t start = 0;
            int64_t end = [input.shape[dim] longLongValue];
            if ((NSInteger)dim == truncatedDim) {
                start = truncatedSize;
            }
            [tailStarts addObject:@(start)];
            [tailEnds addObject:@(end)];
            [tailStrides addObject:@1];
        }
        MPSGraphTensor* tail =
            [ctx.graph sliceTensor:input starts:tailStarts ends:tailEnds strides:tailStrides name:nil];
        MPSGraphTensor* result =
            [ctx.graph concatTensors:@[ resultWindow, tail ] dimension:truncatedDim name:nil];
        return Result(ctx, result, "scatter");
    }

    return ProcessResult::Error("scatter: unsupported scatter pattern (" +
                                ScatterDebugString(scatterOp, input, scatterIndices, updates) +
                                ")");
}
REGISTER_MPS_OP("stablehlo.scatter", HandleScatter);

// Reverse - reverse elements along specified dimensions
static ProcessResult HandleReverse(HandlerContext& ctx) {
    auto reverseOp = mlir::dyn_cast<mlir::stablehlo::ReverseOp>(ctx.op);
    if (!reverseOp) {
        return ProcessResult::Error("reverse: expected ReverseOp");
    }

    MPSGraphTensor* input = GetInputTensor(ctx, 0);
    if (!input)
        return ProcessResult::Error("reverse: missing input tensor");

    auto dimensions = reverseOp.getDimensions();
    NSMutableArray<NSNumber*>* axes = [NSMutableArray array];
    for (int64_t dim : dimensions) {
        [axes addObject:@(dim)];
    }

    MPSGraphTensor* result = [ctx.graph reverseTensor:input axes:axes name:nil];
    return Result(ctx, result, "reverse");
}
REGISTER_MPS_OP("stablehlo.reverse", HandleReverse);

}  // namespace jax_silicon
