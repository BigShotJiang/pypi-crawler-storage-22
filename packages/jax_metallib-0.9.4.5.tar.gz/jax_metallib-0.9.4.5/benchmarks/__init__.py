"""Benchmark harness for jax-metallib (manual, opt-in).

Run:
  uv run python -m benchmarks.bench list
  uv run python -m benchmarks.bench run --case anchor.* --platform mps
"""

