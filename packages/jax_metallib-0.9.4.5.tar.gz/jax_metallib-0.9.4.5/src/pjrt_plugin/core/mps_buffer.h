// Copyright 2026 Erfan Zare Chavoshi (@erfanzar)
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include "pjrt_plugin/core/completion_event.h"

#include <cstdint>
#include <functional>
#include <string>
#include <vector>

namespace jax_metallib {

class MpsDevice;

// Represents a buffer on Metal GPU
class MpsBuffer {
public:
    using BufferReleaser = std::function<void(void* metal_buffer)>;

    MpsBuffer(MpsDevice* device,
              void* metal_buffer, // id<MTLBuffer>
              int dtype, const std::vector<int64_t>& dims, BufferReleaser releaser = {},
              CompletionEvent producer_completion = nullptr);
    ~MpsBuffer();

    // Buffer info
    MpsDevice* device() const {
        return device_;
    }
    int dtype() const {
        return dtype_;
    }
    const std::vector<int64_t>& dimensions() const {
        return dims_;
    }
    int64_t element_count() const;
    size_t byte_size() const;

    // Data access
    void* metal_buffer() const {
        return metal_buffer_;
    }

    // Copy to host (full buffer)
    bool ToHostBuffer(void* dst, std::function<void()> on_done, std::string* error = nullptr);

    // Copy raw bytes from buffer to host at given offset
    bool CopyRawToHost(void* dst, int64_t offset, int64_t transfer_size, std::string* error = nullptr);

    // Clone this buffer (creates a new Metal buffer with same contents)
    std::unique_ptr<MpsBuffer> Clone(std::string* error = nullptr) const;

    CompletionEvent producer_completion() const {
        return producer_completion_;
    }
    void set_producer_completion(CompletionEvent completion) {
        producer_completion_ = completion ? std::move(completion) : MakeReadyCompletionEvent();
    }
    bool WaitForProducer(std::string* error = nullptr) const;

    // Check if buffer is deleted
    bool IsDeleted() const {
        return is_deleted_;
    }
    void Delete();

private:
    MpsDevice* device_;
    void* metal_buffer_; // id<MTLBuffer>
    int dtype_;
    std::vector<int64_t> dims_;
    BufferReleaser releaser_;
    CompletionEvent producer_completion_;
    bool is_deleted_ = false;
};

// Size of each dtype in bytes
size_t DtypeByteSize(int dtype);

} // namespace jax_metallib
