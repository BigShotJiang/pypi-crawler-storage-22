// Copyright 2026 Erfan Zare Chavoshi (@erfanzar)
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include <memory>
#include <string>
#include <vector>

// Forward declarations for Metal types (defined in .mm files)
#ifdef __OBJC__
@class MTLDevice;
@class MPSGraph;
#else
typedef void* MTLDevice;
typedef void* MPSGraph;
#endif

namespace mps {
struct ParsedModule;
}

namespace jax_metallib {

class MpsDevice;
class MpsBuffer;
class MpsExecutable;

// Represents a Metal GPU client for PJRT
class MpsClient {
public:
    static std::unique_ptr<MpsClient> Create();
    ~MpsClient();

    // Client info
    const std::string& platform_name() const {
        return platform_name_;
    }
    const std::string& platform_version() const {
        return platform_version_;
    }
    int process_index() const {
        return 0;
    } // Single process

    // Device management
    int device_count() const;
    int addressable_device_count() const;
    MpsDevice* device(int index);
    MpsDevice* addressable_device(int index);
    MpsDevice* LookupDevice(int device_id);

    // Buffer operations
    // byte_strides: number of bytes between elements in each dimension.
    // If empty, assumes dense row-major layout.
    std::unique_ptr<MpsBuffer> BufferFromHostBuffer(const void* data,
                                                    int dtype, // PJRT dtype enum
                                                    const std::vector<int64_t>& dims,
                                                    const std::vector<int64_t>& byte_strides,
                                                    MpsDevice* device);

    // Create an uninitialized Metal buffer of the given shape
    std::unique_ptr<MpsBuffer> CreateUninitializedBuffer(int dtype, const std::vector<int64_t>& dims,
                                                         MpsDevice* device);

    // Compilation - takes ownership of ParsedModule
    std::unique_ptr<MpsExecutable> CompileStableHLO(mps::ParsedModule module, MpsDevice* device);

    // Memory statistics reported via PJRT_Device_MemoryStats
    struct MemoryStats {
        int64_t bytes_in_use = 0; // currentAllocatedSize
        int64_t bytes_limit = 0;  // recommendedMaxWorkingSetSize
        bool bytes_limit_is_set = false;
    };

    // Query live Metal memory statistics from the device
    MemoryStats GetMemoryStats() const;

    // Internal: get Metal device and command queue
    void* metal_device() const {
        return metal_device_;
    }
    void* command_queue() const {
        return command_queue_;
    }

private:
    MpsClient();
    bool Initialize();

    std::string platform_name_;
    std::string platform_version_;
    void* metal_device_;  // id<MTLDevice>
    void* command_queue_; // id<MTLCommandQueue>
    std::vector<std::unique_ptr<MpsDevice>> devices_;
};

} // namespace jax_metallib
