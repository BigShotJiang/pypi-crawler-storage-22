// Copyright 2026 Erfan Zare Chavoshi (@erfanzar)
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include "mlir/IR/BuiltinTypes.h"
#include "mlir/IR/Types.h"

#import <MetalPerformanceShadersGraph/MetalPerformanceShadersGraph.h>
#include <xla/pjrt/c/pjrt_c_api.h>

namespace jax_metallib {

// Convert PJRT dtype to MPSDataType
MPSDataType PjrtDtypeToMps(int dtype);

// Convert MPSDataType to PJRT dtype
int MpsToPjrtDtype(MPSDataType mps_type);

// Convert MLIR type to MPSDataType
MPSDataType MlirTypeToMps(mlir::Type type);

// Convert MLIR type to PJRT dtype
int MlirTypeToPjrtDtype(mlir::Type type);

} // namespace jax_metallib
