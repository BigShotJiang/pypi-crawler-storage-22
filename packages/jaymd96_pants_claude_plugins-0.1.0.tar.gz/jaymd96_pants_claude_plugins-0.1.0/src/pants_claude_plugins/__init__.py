"""Pants plugin for installing Claude Code plugins into projects."""

from pants_claude_plugins.version import VERSION

__version__ = VERSION
