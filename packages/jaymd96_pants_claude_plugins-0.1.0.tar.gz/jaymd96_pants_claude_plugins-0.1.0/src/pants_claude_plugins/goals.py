"""Goal definitions for Claude Code plugin installation."""

from __future__ import annotations

import logging
from dataclasses import dataclass

from pants.engine.addresses import Addresses
from pants.engine.console import Console
from pants.engine.goal import Goal, GoalSubsystem
from pants.engine.internals.selectors import Get, MultiGet
from pants.engine.rules import collect_rules, goal_rule
from pants.engine.target import Targets, WrappedTarget, WrappedTargetRequest
from pants.util.strutil import softwrap

from pants_claude_plugins.rules import (
    ClaudePluginBatchInstallRequest,
    ClaudePluginBatchInstallResult,
    ClaudePluginFromTargetRequest,
    ClaudePluginInstallRequest,
)
from pants_claude_plugins.subsystem import ClaudePluginsSubsystem
from pants_claude_plugins.targets import ClaudePlugin, EnabledField

logger = logging.getLogger(__name__)


class ClaudeInstallSubsystem(GoalSubsystem):
    """Install Claude Code plugins defined in BUILD files."""

    name = "claude-install"
    help = softwrap(
        """
        Install Claude Code plugins defined as `claude_plugin` targets.

        This goal reads `claude_plugin` targets from your BUILD files and installs
        them using the Claude Code CLI.

        Example usage:

            # Install all plugins in the repo
            pants claude-install ::

            # Install plugins in a specific directory
            pants claude-install tools/claude:

            # Install a specific plugin target
            pants claude-install tools/claude:github-integration

            # Dry run to see what would be installed
            pants claude-install --dry-run ::
        """
    )


class ClaudeInstall(Goal):
    """The claude-install goal."""

    subsystem_cls = ClaudeInstallSubsystem


@goal_rule
async def claude_install(
    console: Console,
    targets: Targets,
    subsystem: ClaudePluginsSubsystem,
) -> ClaudeInstall:
    """Install Claude Code plugins from claude_plugin targets."""
    if subsystem.skip:
        console.print_stderr("Skipping claude-install (--skip is set)")
        return ClaudeInstall(exit_code=0)

    # Filter to only ClaudePlugin targets that are enabled
    plugin_targets = [
        t for t in targets
        if t.has_field(EnabledField) and t[EnabledField].value
    ]

    if not plugin_targets:
        console.print_stdout("No enabled claude_plugin targets found.")
        return ClaudeInstall(exit_code=0)

    # Convert targets to install requests
    wrapped_targets = await MultiGet(
        Get(WrappedTarget, WrappedTargetRequest(t.address, description_of_origin="claude-install goal"))
        for t in plugin_targets
    )

    install_requests = await MultiGet(
        Get(ClaudePluginInstallRequest, ClaudePluginFromTargetRequest(wt))
        for wt in wrapped_targets
    )

    # Log what we're about to do
    mode = "[DRY RUN] " if subsystem.dry_run else ""
    console.print_stdout(f"\n{mode}Installing {len(install_requests)} Claude Code plugin(s):\n")

    for req in install_requests:
        console.print_stdout(f"  - {req.plugin_name}@{req.marketplace} (scope: {req.scope})")

    console.print_stdout("")

    # Perform the installations
    batch_result = await Get(
        ClaudePluginBatchInstallResult,
        ClaudePluginBatchInstallRequest(plugins=tuple(install_requests)),
    )

    # Report results
    success_count = len(batch_result.succeeded)
    fail_count = len(batch_result.failed)

    for result in batch_result.succeeded:
        console.print_stdout(f"✓ Installed {result.full_name}")
        if result.output.strip():
            for line in result.output.strip().split("\n"):
                console.print_stdout(f"    {line}")

    for result in batch_result.failed:
        console.print_stderr(f"✗ Failed to install {result.full_name}")
        if result.error.strip():
            for line in result.error.strip().split("\n"):
                console.print_stderr(f"    {line}")

    console.print_stdout(f"\n{mode}Summary: {success_count} succeeded, {fail_count} failed")

    if batch_result.failed and subsystem.fail_on_error:
        return ClaudeInstall(exit_code=1)

    return ClaudeInstall(exit_code=0)


def rules():
    """Return all rules for this module."""
    return collect_rules()
