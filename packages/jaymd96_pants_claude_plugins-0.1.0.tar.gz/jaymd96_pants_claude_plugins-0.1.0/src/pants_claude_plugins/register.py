"""Registration entry point for the pants-claude-plugins backend.

This module is loaded by Pants when the backend is enabled in pants.toml:

    [GLOBAL]
    backend_packages = ["pants_claude_plugins"]
"""

from pants.engine.rules import collect_rules

from pants_claude_plugins import goals as goals_module
from pants_claude_plugins import rules as rules_module
from pants_claude_plugins.subsystem import ClaudePluginsSubsystem
from pants_claude_plugins.targets import ClaudePlugin


def rules():
    """Return all rules for this plugin."""
    return [
        *collect_rules(goals_module),
        *collect_rules(rules_module),
        *ClaudePluginsSubsystem.rules(),
    ]


def target_types():
    """Return all target types for this plugin."""
    return [ClaudePlugin]
