"""Configuration subsystem for Claude Code plugin installation."""

from __future__ import annotations

from pants.option.option_types import BoolOption, EnumOption, StrOption
from pants.option.subsystem import Subsystem
from pants.util.strutil import softwrap


class InstallScope:
    """Installation scope for Claude Code plugins."""

    PROJECT = "project"
    USER = "user"
    LOCAL = "local"


class ClaudePluginsSubsystem(Subsystem):
    """Configuration options for installing Claude Code plugins.

    Use these options to control how the `claude-install` goal behaves.

    Example pants.toml configuration:

        [claude-plugins]
        default_scope = "project"
        claude_binary = "claude"
        skip = false
    """

    options_scope = "claude-plugins"
    help = softwrap(
        """
        Options for installing Claude Code plugins into your project.

        This plugin allows you to define `claude_plugin` targets in your BUILD files
        and install them using the `claude-install` goal.
        """
    )

    default_scope = StrOption(
        default="project",
        help=softwrap(
            """
            The default installation scope for plugins when not specified per-target.

            Valid values are:
            - "project": Install for all collaborators on the repository
              (adds to .claude/settings.json)
            - "user": Install for the current user across all projects
            - "local": Install for yourself in this repository only
            """
        ),
    )

    claude_binary = StrOption(
        default="claude",
        help=softwrap(
            """
            Path to the Claude Code CLI binary.

            If not an absolute path, it will be looked up in $PATH.
            """
        ),
    )

    skip = BoolOption(
        default=False,
        help=softwrap(
            """
            If true, skip running the claude-install goal entirely.

            Useful for CI environments where Claude Code is not installed.
            """
        ),
    )

    fail_on_error = BoolOption(
        default=True,
        help=softwrap(
            """
            If true, fail the build if any plugin installation fails.

            If false, log warnings but continue with other plugins.
            """
        ),
    )

    dry_run = BoolOption(
        default=False,
        help=softwrap(
            """
            If true, print what would be installed without actually installing.

            Useful for previewing changes before applying them.
            """
        ),
    )
