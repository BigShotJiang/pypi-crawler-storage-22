"""Version information for pants-claude-plugins."""

VERSION = "0.1.0"
