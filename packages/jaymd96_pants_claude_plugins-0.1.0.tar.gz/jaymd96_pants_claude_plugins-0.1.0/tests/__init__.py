"""Tests for pants-claude-plugins."""
