"""Pytest configuration and fixtures for pants-claude-plugins tests."""

from __future__ import annotations

import pytest
from pants.testutil.rule_runner import RuleRunner

from pants_claude_plugins.register import rules, target_types


@pytest.fixture
def rule_runner() -> RuleRunner:
    """Create a RuleRunner with the plugin's rules and target types registered."""
    return RuleRunner(
        rules=rules(),
        target_types=target_types(),
    )
