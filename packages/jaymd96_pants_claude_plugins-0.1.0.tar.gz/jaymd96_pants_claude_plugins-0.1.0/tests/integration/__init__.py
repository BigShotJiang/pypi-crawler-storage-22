"""Integration tests for pants-claude-plugins."""
