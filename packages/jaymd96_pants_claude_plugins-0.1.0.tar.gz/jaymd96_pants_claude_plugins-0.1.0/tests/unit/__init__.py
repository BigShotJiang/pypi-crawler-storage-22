"""Unit tests for pants-claude-plugins."""
