"""Unit tests for plugin installation rules."""

from __future__ import annotations

import pytest
from pants.testutil.rule_runner import RuleRunner

from pants_claude_plugins.rules import (
    ClaudePluginInstallRequest,
    ClaudePluginInstallResult,
    ClaudePluginBatchInstallRequest,
    ClaudePluginBatchInstallResult,
)


def test_install_request_creation() -> None:
    """Test that install requests can be created."""
    request = ClaudePluginInstallRequest(
        plugin_name="github",
        marketplace="claude-plugins-official",
        scope="project",
    )

    assert request.plugin_name == "github"
    assert request.marketplace == "claude-plugins-official"
    assert request.scope == "project"


def test_install_result_success() -> None:
    """Test successful install result."""
    result = ClaudePluginInstallResult(
        plugin_name="github",
        marketplace="claude-plugins-official",
        scope="project",
        success=True,
        output="Installed successfully",
    )

    assert result.success is True
    assert result.full_name == "github@claude-plugins-official"
    assert result.error == ""


def test_install_result_failure() -> None:
    """Test failed install result."""
    result = ClaudePluginInstallResult(
        plugin_name="nonexistent",
        marketplace="fake-marketplace",
        scope="project",
        success=False,
        output="",
        error="Plugin not found",
    )

    assert result.success is False
    assert result.full_name == "nonexistent@fake-marketplace"
    assert result.error == "Plugin not found"


def test_batch_install_result_all_successful() -> None:
    """Test batch result when all succeed."""
    results = (
        ClaudePluginInstallResult("p1", "m1", "project", True, "ok"),
        ClaudePluginInstallResult("p2", "m2", "user", True, "ok"),
    )
    batch = ClaudePluginBatchInstallResult(results=results)

    assert batch.all_successful is True
    assert len(batch.succeeded) == 2
    assert len(batch.failed) == 0


def test_batch_install_result_some_failed() -> None:
    """Test batch result when some fail."""
    results = (
        ClaudePluginInstallResult("p1", "m1", "project", True, "ok"),
        ClaudePluginInstallResult("p2", "m2", "user", False, "", "error"),
    )
    batch = ClaudePluginBatchInstallResult(results=results)

    assert batch.all_successful is False
    assert len(batch.succeeded) == 1
    assert len(batch.failed) == 1
    assert batch.failed[0].plugin_name == "p2"


def test_batch_install_request_from_targets(rule_runner: RuleRunner) -> None:
    """Test creating batch install request from targets with dry-run."""
    rule_runner.write_files({
        "BUILD": """
claude_plugin(
    name="github",
    plugin="github",
    marketplace="claude-plugins-official",
    scope="project",
)

claude_plugin(
    name="commit",
    plugin="commit-commands",
    marketplace="anthropics-claude-code",
)
"""
    })

    rule_runner.set_options(["--claude-plugins-dry-run=true"])

    # Just verify we can parse the targets
    targets = rule_runner.get_targets(["//"])
    assert len(targets) == 2
