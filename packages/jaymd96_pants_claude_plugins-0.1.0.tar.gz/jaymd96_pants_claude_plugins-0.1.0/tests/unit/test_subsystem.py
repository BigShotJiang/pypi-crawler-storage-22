"""Unit tests for ClaudePluginsSubsystem configuration."""

from __future__ import annotations

import pytest
from pants.testutil.rule_runner import RuleRunner

from pants_claude_plugins.subsystem import ClaudePluginsSubsystem


def test_subsystem_default_values(rule_runner: RuleRunner) -> None:
    """Test that the subsystem has expected default values."""
    rule_runner.set_options([])

    subsystem = rule_runner.request(ClaudePluginsSubsystem, [])

    assert subsystem.default_scope == "project"
    assert subsystem.claude_binary == "claude"
    assert subsystem.skip is False
    assert subsystem.fail_on_error is True
    assert subsystem.dry_run is False


def test_subsystem_custom_options(rule_runner: RuleRunner) -> None:
    """Test that subsystem options can be customized via pants.toml."""
    rule_runner.set_options([
        "--claude-plugins-default-scope=user",
        "--claude-plugins-claude-binary=/usr/local/bin/claude",
        "--claude-plugins-skip=true",
        "--claude-plugins-fail-on-error=false",
        "--claude-plugins-dry-run=true",
    ])

    subsystem = rule_runner.request(ClaudePluginsSubsystem, [])

    assert subsystem.default_scope == "user"
    assert subsystem.claude_binary == "/usr/local/bin/claude"
    assert subsystem.skip is True
    assert subsystem.fail_on_error is False
    assert subsystem.dry_run is True


def test_subsystem_scope_options(rule_runner: RuleRunner) -> None:
    """Test different scope values."""
    for scope in ["project", "user", "local"]:
        rule_runner.set_options([f"--claude-plugins-default-scope={scope}"])
        subsystem = rule_runner.request(ClaudePluginsSubsystem, [])
        assert subsystem.default_scope == scope
