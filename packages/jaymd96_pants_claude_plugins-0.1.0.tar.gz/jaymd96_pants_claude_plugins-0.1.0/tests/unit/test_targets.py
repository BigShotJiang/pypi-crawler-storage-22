"""Unit tests for claude_plugin target type."""

from __future__ import annotations

import pytest
from pants.testutil.rule_runner import RuleRunner

from pants_claude_plugins.targets import (
    ClaudePlugin,
    EnabledField,
    MarketplaceField,
    PluginNameField,
    ScopeField,
)


def test_claude_plugin_target_creation(rule_runner: RuleRunner) -> None:
    """Test that claude_plugin targets can be created with required fields."""
    rule_runner.write_files({
        "BUILD": """
claude_plugin(
    name="test-plugin",
    plugin="github",
    marketplace="claude-plugins-official",
)
"""
    })

    targets = rule_runner.get_targets(["//"])
    assert len(targets) == 1

    target = targets[0]
    assert target.alias == "claude_plugin"
    assert target[PluginNameField].value == "github"
    assert target[MarketplaceField].value == "claude-plugins-official"
    assert target[EnabledField].value is True  # default
    assert target[ScopeField].value is None  # default, uses subsystem


def test_claude_plugin_target_with_all_fields(rule_runner: RuleRunner) -> None:
    """Test that claude_plugin targets can be created with all optional fields."""
    rule_runner.write_files({
        "BUILD": """
claude_plugin(
    name="full-plugin",
    plugin="commit-commands",
    marketplace="anthropics-claude-code",
    scope="project",
    enabled=True,
    description="Git workflow commands",
    tags=["workflow", "required"],
)
"""
    })

    targets = rule_runner.get_targets(["//"])
    assert len(targets) == 1

    target = targets[0]
    assert target[PluginNameField].value == "commit-commands"
    assert target[MarketplaceField].value == "anthropics-claude-code"
    assert target[ScopeField].value == "project"
    assert target[EnabledField].value is True


def test_claude_plugin_disabled(rule_runner: RuleRunner) -> None:
    """Test that claude_plugin targets can be disabled."""
    rule_runner.write_files({
        "BUILD": """
claude_plugin(
    name="disabled-plugin",
    plugin="some-plugin",
    marketplace="some-marketplace",
    enabled=False,
)
"""
    })

    targets = rule_runner.get_targets(["//"])
    assert len(targets) == 1
    assert targets[0][EnabledField].value is False


def test_multiple_claude_plugins(rule_runner: RuleRunner) -> None:
    """Test multiple claude_plugin targets in the same BUILD file."""
    rule_runner.write_files({
        "BUILD": """
claude_plugin(
    name="plugin-1",
    plugin="github",
    marketplace="claude-plugins-official",
)

claude_plugin(
    name="plugin-2",
    plugin="commit-commands",
    marketplace="anthropics-claude-code",
    scope="user",
)

claude_plugin(
    name="plugin-3",
    plugin="typescript-lsp",
    marketplace="claude-plugins-official",
    scope="local",
    enabled=False,
)
"""
    })

    targets = rule_runner.get_targets(["//"])
    assert len(targets) == 3

    # Verify they're all claude_plugin targets
    for target in targets:
        assert target.alias == "claude_plugin"
