# pants-release-hub

Pure Python release hub publishing client for Pants plugins.

Provides release type detection, publish request/result models, and an HTTP client for Apollo Hub API — with zero external dependencies.
