"""Pure Python release hub publishing client (no Pants dependencies).

Provides:
  - Release type detection from SLS version strings
  - Publish request/result models
  - ApolloHubClient for HTTP communication with Apollo Hub API
"""

from __future__ import annotations

import json
import re
import urllib.request
import urllib.error
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


# =============================================================================
# Release type detection
# =============================================================================


class ReleaseType(str, Enum):
    """Release type derived from SLS orderable version format."""

    RELEASE = "release"  # X.Y.Z
    RELEASE_CANDIDATE = "release_candidate"  # X.Y.Z-rcN
    SNAPSHOT = "snapshot"  # X.Y.Z-N-gHASH
    RC_SNAPSHOT = "rc_snapshot"  # X.Y.Z-rcN-N-gHASH


_RELEASE_RE = re.compile(r"^[0-9]+\.[0-9]+\.[0-9]+$")
_RC_RE = re.compile(r"^[0-9]+\.[0-9]+\.[0-9]+-rc[0-9]+$")
_SNAPSHOT_RE = re.compile(r"^[0-9]+\.[0-9]+\.[0-9]+-[0-9]+-g[a-f0-9]+$")
_RC_SNAPSHOT_RE = re.compile(r"^[0-9]+\.[0-9]+\.[0-9]+-rc[0-9]+-[0-9]+-g[a-f0-9]+$")


def detect_release_type(version: str) -> ReleaseType:
    """Detect the release type from an SLS orderable version string.

    Args:
        version: SLS orderable version (e.g., "1.0.0", "1.0.0-rc1").

    Returns:
        ReleaseType enum value.

    Raises:
        ValueError: If the version doesn't match any known SLS pattern.
    """
    if _RELEASE_RE.match(version):
        return ReleaseType.RELEASE
    if _RC_RE.match(version):
        return ReleaseType.RELEASE_CANDIDATE
    if _RC_SNAPSHOT_RE.match(version):
        return ReleaseType.RC_SNAPSHOT
    if _SNAPSHOT_RE.match(version):
        return ReleaseType.SNAPSHOT
    raise ValueError(f"Cannot detect release type for version: {version!r}")


def default_channel_for_release_type(release_type: ReleaseType) -> str:
    """Return the default channel for a release type."""
    return {
        ReleaseType.RELEASE: "stable",
        ReleaseType.RELEASE_CANDIDATE: "beta",
        ReleaseType.SNAPSHOT: "dev",
        ReleaseType.RC_SNAPSHOT: "dev",
    }[release_type]


# =============================================================================
# Publish request / result models
# =============================================================================


@dataclass(frozen=True)
class PublishRequest:
    """Request to publish an SLS distribution to a release hub."""

    # Product identity
    product_group: str
    product_name: str
    product_version: str
    product_type: str

    # Artifact
    artifact_url: str  # e.g., "oci://registry.example.io/my-service:1.0.0"

    # Content
    manifest_yaml: str

    # Options
    channel: str | None = None  # None = auto-detect from version
    release_type: ReleaseType | None = None  # None = auto-detect from version
    changelog: str | None = None
    published_by: str | None = None
    labels: dict[str, str] = field(default_factory=dict)
    dry_run: bool = False

    @property
    def product_id(self) -> str:
        return f"{self.product_group}:{self.product_name}"

    @property
    def resolved_release_type(self) -> ReleaseType:
        if self.release_type is not None:
            return self.release_type
        return detect_release_type(self.product_version)

    @property
    def resolved_channel(self) -> str:
        if self.channel is not None:
            return self.channel
        return default_channel_for_release_type(self.resolved_release_type)

    def to_api_payload(self) -> dict[str, Any]:
        """Build the API request payload for POST /api/v1/releases."""
        return {
            "product_id": self.product_id,
            "version": self.product_version,
            "artifact_url": self.artifact_url,
            "metadata": {
                "release_type": self.resolved_release_type.value,
                "manifest_yaml": self.manifest_yaml,
                "product_type": self.product_type,
                "channel": self.resolved_channel,
                **({"changelog": self.changelog} if self.changelog else {}),
                **({"published_by": self.published_by} if self.published_by else {}),
                **({"labels": self.labels} if self.labels else {}),
            },
        }


@dataclass(frozen=True)
class PublishResult:
    """Result of publishing to a release hub."""

    success: bool
    release_id: str | None = None
    message: str = ""
    dry_run: bool = False
    api_response: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def dry_run_result(cls, request: PublishRequest) -> PublishResult:
        return cls(
            success=True,
            message=(
                f"[DRY RUN] Would publish {request.product_id} "
                f"v{request.product_version} to channel {request.resolved_channel}"
            ),
            dry_run=True,
        )

    @classmethod
    def from_api_response(cls, response: dict[str, Any]) -> PublishResult:
        return cls(
            success=True,
            release_id=str(response.get("id", "")),
            message=f"Published release {response.get('id', 'unknown')}",
            api_response=response,
        )

    @classmethod
    def failure(cls, message: str) -> PublishResult:
        return cls(success=False, message=message)


# =============================================================================
# Error types
# =============================================================================


class PublishError(Exception):
    """Base error for publish operations."""

    pass


class PublishAuthError(PublishError):
    """Authentication or authorization failure."""

    pass


class PublishValidationError(PublishError):
    """Server-side validation failure."""

    pass


class PublishConnectionError(PublishError):
    """Cannot reach the release hub."""

    pass


# =============================================================================
# Apollo Hub Client
# =============================================================================


class ApolloHubClient:
    """HTTP client for Apollo Hub API.

    Uses urllib.request (stdlib) to avoid external HTTP library dependencies.
    """

    def __init__(
        self,
        base_url: str,
        auth_token: str | None = None,
        timeout: int = 30,
    ) -> None:
        # Strip trailing slash
        self.base_url = base_url.rstrip("/")
        self.auth_token = auth_token
        self.timeout = timeout

    @property
    def _headers(self) -> dict[str, str]:
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "pants-release-hub/0.1.0",
        }
        if self.auth_token:
            headers["Authorization"] = f"Bearer {self.auth_token}"
        return headers

    def _url(self, path: str) -> str:
        return f"{self.base_url}{path}"

    def publish_release(self, request: PublishRequest) -> PublishResult:
        """Publish a release to Apollo Hub.

        Args:
            request: Publish request with all release metadata.

        Returns:
            PublishResult with success/failure and release ID.

        Raises:
            PublishAuthError: On 401/403.
            PublishValidationError: On 400.
            PublishConnectionError: On connection failure.
            PublishError: On other errors.
        """
        if request.dry_run:
            return PublishResult.dry_run_result(request)

        payload = request.to_api_payload()
        return self._post("/api/v1/releases", payload)

    def check_health(self) -> bool:
        """Check if Apollo Hub is reachable.

        Returns:
            True if the Hub responds, False otherwise.
        """
        try:
            self._get("/api/v1/health")
            return True
        except Exception:
            return False

    def get_product(self, product_id: str) -> dict[str, Any] | None:
        """Look up a product by ID. Returns None if not found."""
        try:
            return self._get(f"/api/v1/products/{product_id}")
        except PublishError:
            return None

    def _post(self, path: str, payload: dict[str, Any]) -> PublishResult:
        """Make a POST request to the Hub API."""
        url = self._url(path)
        data = json.dumps(payload).encode("utf-8")

        req = urllib.request.Request(
            url,
            data=data,
            headers=self._headers,
            method="POST",
        )

        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                body = json.loads(resp.read().decode("utf-8"))
                return PublishResult.from_api_response(body)
        except urllib.error.HTTPError as exc:
            return self._handle_http_error(exc)
        except urllib.error.URLError as exc:
            raise PublishConnectionError(
                f"Cannot reach Apollo Hub at {self.base_url}: {exc.reason}"
            ) from exc

    def _get(self, path: str) -> dict[str, Any]:
        """Make a GET request to the Hub API."""
        url = self._url(path)

        req = urllib.request.Request(url, headers=self._headers, method="GET")

        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            self._handle_http_error(exc)
            return {}  # unreachable, _handle_http_error always raises
        except urllib.error.URLError as exc:
            raise PublishConnectionError(
                f"Cannot reach Apollo Hub at {self.base_url}: {exc.reason}"
            ) from exc

    def _handle_http_error(self, exc: urllib.error.HTTPError) -> PublishResult:
        """Handle HTTP error responses from the Hub API."""
        try:
            body = json.loads(exc.read().decode("utf-8"))
            detail = body.get("detail", str(body))
        except Exception:
            detail = exc.reason or str(exc)

        if exc.code in (401, 403):
            raise PublishAuthError(f"Authentication failed ({exc.code}): {detail}") from exc
        if exc.code == 400:
            raise PublishValidationError(f"Validation error: {detail}") from exc
        if exc.code == 404:
            raise PublishError(f"Not found: {detail}") from exc

        raise PublishError(f"Hub API error ({exc.code}): {detail}") from exc


def build_artifact_url(
    *,
    registry: str,
    product_name: str,
    product_version: str,
) -> str:
    """Build an OCI artifact URL for the published Docker image.

    Args:
        registry: Docker registry (e.g., "registry.example.io").
        product_name: Product name.
        product_version: Product version.

    Returns:
        OCI artifact URL (e.g., "oci://registry.example.io/my-service:1.0.0").
    """
    if registry:
        return f"oci://{registry}/{product_name}:{product_version}"
    return f"oci://{product_name}:{product_version}"
