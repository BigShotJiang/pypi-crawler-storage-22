# jayzz

jayzz is a lightweight Python umbrella package that provides unified access to popular data science libraries — NumPy, Pandas, Seaborn, and Matplotlib — using a single import.

## Why jayzz?
Instead of importing multiple libraries separately, jayzz allows you to write cleaner and more readable code by accessing all core data science tools through one namespace.

## Installation
```bash
pip install jayzz
