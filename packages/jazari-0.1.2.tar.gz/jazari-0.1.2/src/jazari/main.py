import typer, os
from jazari.commands.status import status_command
from jazari.commands.kill import kill_command
from jazari.commands.logs import logs_command
from jazari.commands.init import init_command
from jazari.commands.run import run_command

os.umask(0o077)

# Initializing the Typer app
app = typer.Typer(
    name            = "jazari",
    help            = "🐘 The orchestration layer for modern Slurm clusters.",
    add_completion  = False,
    no_args_is_help = True
)

# Register the commands
app.command(name="status")(status_command)
app.command(name="kill")(kill_command)
app.command(name="logs")(logs_command)
app.command(name="init")(init_command)
app.command(name="run")(run_command)

if __name__ == "__main__":
    app()