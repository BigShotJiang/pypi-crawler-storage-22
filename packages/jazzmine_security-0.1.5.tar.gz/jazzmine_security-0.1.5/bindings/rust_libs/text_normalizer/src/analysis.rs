use std::collections::{HashSet, HashMap};
use unicode_normalization::char::is_combining_mark;
use crate::constants::*;

pub struct CharacterAnalyzer {
    chars: Vec<char>,
    total_chars: usize,
    chars_with_strikethrough: HashSet<usize>,
    chars_with_combining_marks: HashSet<usize>,
    strikethrough_intensity: HashMap<usize, usize>,
    combining_mark_intensity: HashMap<usize, usize>,
}

impl CharacterAnalyzer {
    pub fn new(chars: &[char]) -> Self {
        let total_chars = chars.len();
        let chars = chars.to_vec();
        
        let (
            chars_with_strikethrough,
            chars_with_combining_marks,
            strikethrough_intensity,
            combining_mark_intensity,
        ) = Self::analyze_modifiers(&chars);
        
        Self {
            chars,
            total_chars,
            chars_with_strikethrough,
            chars_with_combining_marks,
            strikethrough_intensity,
            combining_mark_intensity,
        }
    }
    
    fn analyze_modifiers(chars: &[char]) -> (
        HashSet<usize>,
        HashSet<usize>,
        HashMap<usize, usize>,
        HashMap<usize, usize>,
    ) {
        let mut chars_with_strikethrough = HashSet::new();
        let mut chars_with_combining_marks = HashSet::new();
        let mut strikethrough_intensity = HashMap::new();
        let mut combining_mark_intensity = HashMap::new();
        
        let mut i = 0;
        while i < chars.len() {
            let mut strike_count = 0;
            let mut j = i + 1;
            while j < chars.len() && matches!(chars[j], '\u{0336}' | '\u{0337}' | '\u{0338}') {
                strike_count += 1;
                j += 1;
            }
            if strike_count > 0 {
                chars_with_strikethrough.insert(i);
                strikethrough_intensity.insert(i, strike_count);
            }
            
            let mut combining_count = 0;
            let mut k = i + 1;
            while k < chars.len() && is_combining_mark(chars[k]) {
                combining_count += 1;
                k += 1;
            }
            if combining_count > 0 {
                chars_with_combining_marks.insert(i);
                combining_mark_intensity.insert(i, combining_count);
            }
            
            i += 1;
        }
        
        (
            chars_with_strikethrough,
            chars_with_combining_marks,
            strikethrough_intensity,
            combining_mark_intensity,
        )
    }
    
    pub fn get_obfuscation_positions(&self) -> Vec<usize> {
        let mut positions = Vec::new();
        
        for (i, &c) in self.chars.iter().enumerate() {
            let is_obfuscated = self.is_char_obfuscated(c, i);
            if is_obfuscated {
                positions.push(i);
            }
        }
        
        positions
    }
    
    fn is_char_obfuscated(&self, c: char, pos: usize) -> bool {
        matches!(c, '\u{200B}'..='\u{200D}' | '\u{FEFF}' | '\u{00AD}' | '\u{034F}' | 
                    '\u{061C}' | '\u{115F}' | '\u{1160}' | '\u{17B4}' | '\u{17B5}' | 
                    '\u{180E}' | '\u{2060}'..='\u{2064}' | '\u{2066}'..='\u{206F}' | 
                    '\u{3164}' | '\u{FFA0}' | '\u{FFF0}'..='\u{FFF8}' |
                    '\u{200E}' | '\u{200F}' | '\u{202A}'..='\u{202E}' |
                    '\u{E0020}'..='\u{E007F}' | '\u{E0100}'..='\u{E01EF}') ||
        HOMOGLYPH_MAP.contains_key(&c) ||
        ((c as u32) >= 0xFF01 && (c as u32) <= 0xFF5E) ||
        FLIPPED_CHARS.contains_key(&c) ||
        LEETSPEAK_MAP.contains_key(&c) ||
        self.strikethrough_intensity.contains_key(&pos) ||
        self.combining_mark_intensity.contains_key(&pos)
    }
    
    pub fn get_total_chars(&self) -> usize {
        self.total_chars
    }
    
    pub fn get_metrics(&self) -> CharacterMetrics {
        let invisible_chars_count = self.count_invisible_chars();
        let directionality_chars_count = self.count_directionality_chars();
        let tag_chars_count = self.count_tag_chars();
        let homoglyph_count = self.count_homoglyphs();
        let flipped_chars_count = self.count_flipped_chars();
        let leetspeak_count = self.count_leetspeak();
        let emoji_count = self.count_emojis();
        
        let strikethrough_metrics = self.calculate_strikethrough_metrics();
        let combining_marks_metrics = self.calculate_combining_marks_metrics();
        let superscript_count = self.count_superscripts();
        let subscript_count = self.count_subscripts();
        
        CharacterMetrics {
            invisible_chars_count,
            invisible_char_ratio: invisible_chars_count as f64 / self.total_chars as f64,
            directionality_chars_count,
            directionality_char_ratio: directionality_chars_count as f64 / self.total_chars as f64,
            tag_chars_count,
            tag_char_ratio: tag_chars_count as f64 / self.total_chars as f64,
            homoglyph_count,
            homoglyph_ratio: homoglyph_count as f64 / self.total_chars as f64,
            flipped_chars_count,
            flipped_char_ratio: flipped_chars_count as f64 / self.total_chars as f64,
            leetspeak_count,
            leetspeak_ratio: leetspeak_count as f64 / self.total_chars as f64,
            emoji_count,
            emoji_ratio: emoji_count as f64 / self.total_chars as f64,
            strikethrough_modifier_count: strikethrough_metrics.0,
            strikethrough_affected_chars: strikethrough_metrics.1,
            strikethrough_affected_ratio: strikethrough_metrics.2,
            strikethrough_avg_intensity: strikethrough_metrics.3,
            strikethrough_max_intensity: strikethrough_metrics.4,
            combining_marks_modifier_count: combining_marks_metrics.0,
            combining_marks_affected_chars: combining_marks_metrics.1,
            combining_marks_affected_ratio: combining_marks_metrics.2,
            combining_marks_avg_intensity: combining_marks_metrics.3,
            combining_marks_max_intensity: combining_marks_metrics.4,
            is_zalgo_text: combining_marks_metrics.5,
            zalgo_char_count: combining_marks_metrics.6,
            superscript_count,
            subscript_count,
            super_sub_script_ratio: (superscript_count + subscript_count) as f64 / self.total_chars as f64,
        }
    }
    
    fn count_invisible_chars(&self) -> usize {
        self.chars.iter().filter(|&&c| {
            matches!(c,
                '\u{200B}'..='\u{200D}' | '\u{FEFF}' | '\u{00AD}' | '\u{034F}' | 
                '\u{061C}' | '\u{115F}' | '\u{1160}' | '\u{17B4}' | '\u{17B5}' | 
                '\u{180E}' | '\u{2060}'..='\u{2064}' | '\u{2066}'..='\u{206F}' | 
                '\u{3164}' | '\u{FFA0}' | '\u{FFF0}'..='\u{FFF8}'
            )
        }).count()
    }
    
    fn count_directionality_chars(&self) -> usize {
        self.chars.iter().filter(|&&c| {
            matches!(c,
                '\u{061C}' | '\u{200E}' | '\u{200F}' | '\u{202A}'..='\u{202E}' | 
                '\u{2066}'..='\u{206F}' | '\u{10800}'..='\u{10805}' | '\u{10808}' | 
                '\u{1080A}'..='\u{10835}' | '\u{10837}' | '\u{10838}' | '\u{1083C}' | 
                '\u{1083F}'..='\u{10855}' | '\u{10857}'..='\u{1089E}' | '\u{108A7}'..='\u{108AF}'
            )
        }).count()
    }
    
    fn count_tag_chars(&self) -> usize {
        self.chars.iter().filter(|&&c| {
            (c >= '\u{E0020}' && c <= '\u{E007F}') || 
            (c >= '\u{E0100}' && c <= '\u{E01EF}')
        }).count()
    }
    
    fn count_homoglyphs(&self) -> usize {
        let from_map = self.chars.iter().filter(|c| HOMOGLYPH_MAP.contains_key(c)).count();
        let fullwidth = self.chars.iter().filter(|&&c| {
            let code = c as u32;
            code >= 0xFF01 && code <= 0xFF5E
        }).count();
        from_map + fullwidth
    }
    
    fn count_flipped_chars(&self) -> usize {
        self.chars.iter().filter(|c| FLIPPED_CHARS.contains_key(c)).count()
    }
    
    fn count_leetspeak(&self) -> usize {
        self.chars.iter().filter(|c| LEETSPEAK_MAP.contains_key(c)).count()
    }
    
    fn count_emojis(&self) -> usize {
        self.chars.iter().filter(|c| {
            emojis::get(c.to_string().as_str()).is_some()
        }).count()
    }
    
    fn count_superscripts(&self) -> usize {
        self.chars.iter().filter(|c| SUPERSCRIPT_MAP.contains_key(c)).count()
    }
    
    fn count_subscripts(&self) -> usize {
        self.chars.iter().filter(|c| SUBSCRIPT_MAP.contains_key(c)).count()
    }
    
    fn calculate_strikethrough_metrics(&self) -> (usize, usize, f64, f64, usize) {
        let modifier_count = self.chars.iter().filter(|&&c| {
            matches!(c, '\u{0336}' | '\u{0337}' | '\u{0338}')
        }).count();
        
        let affected_chars = self.chars_with_strikethrough.len();
        let affected_ratio = affected_chars as f64 / self.total_chars as f64;
        
        let avg_intensity = if affected_chars > 0 {
            self.strikethrough_intensity.values().sum::<usize>() as f64 / affected_chars as f64
        } else {
            0.0
        };
        
        let max_intensity = self.strikethrough_intensity.values().max().copied().unwrap_or(0);
        
        (modifier_count, affected_chars, affected_ratio, avg_intensity, max_intensity)
    }
    
    fn calculate_combining_marks_metrics(&self) -> (usize, usize, f64, f64, usize, bool, usize) {
        let modifier_count = self.chars.iter().filter(|c| is_combining_mark(**c)).count();
        let affected_chars = self.chars_with_combining_marks.len();
        let affected_ratio = affected_chars as f64 / self.total_chars as f64;
        
        let avg_intensity = if affected_chars > 0 {
            self.combining_mark_intensity.values().sum::<usize>() as f64 / affected_chars as f64
        } else {
            0.0
        };
        
        let max_intensity = self.combining_mark_intensity.values().max().copied().unwrap_or(0);
        let is_zalgo_text = max_intensity > 5;
        let zalgo_char_count = self.combining_mark_intensity.iter()
            .filter(|(_, &intensity)| intensity > 5)
            .count();
        
        (modifier_count, affected_chars, affected_ratio, avg_intensity, max_intensity, is_zalgo_text, zalgo_char_count)
    }
}

pub struct CharacterMetrics {
    pub invisible_chars_count: usize,
    pub invisible_char_ratio: f64,
    pub directionality_chars_count: usize,
    pub directionality_char_ratio: f64,
    pub tag_chars_count: usize,
    pub tag_char_ratio: f64,
    pub homoglyph_count: usize,
    pub homoglyph_ratio: f64,
    pub flipped_chars_count: usize,
    pub flipped_char_ratio: f64,
    pub leetspeak_count: usize,
    pub leetspeak_ratio: f64,
    pub emoji_count: usize,
    pub emoji_ratio: f64,
    pub strikethrough_modifier_count: usize,
    pub strikethrough_affected_chars: usize,
    pub strikethrough_affected_ratio: f64,
    pub strikethrough_avg_intensity: f64,
    pub strikethrough_max_intensity: usize,
    pub combining_marks_modifier_count: usize,
    pub combining_marks_affected_chars: usize,
    pub combining_marks_affected_ratio: f64,
    pub combining_marks_avg_intensity: f64,
    pub combining_marks_max_intensity: usize,
    pub is_zalgo_text: bool,
    pub zalgo_char_count: usize,
    pub superscript_count: usize,
    pub subscript_count: usize,
    pub super_sub_script_ratio: f64,
}

pub struct WordAnalyzer {
    words: Vec<String>,
    word_start_positions: Vec<usize>,
    obfuscated_words: HashSet<usize>,
}

impl WordAnalyzer {
    pub fn new(text: &str) -> Self {
        let words: Vec<String> = text.split_whitespace().map(|s| s.to_string()).collect();
        let word_start_positions = Self::find_word_positions(text, &words);
        let obfuscated_words = HashSet::new();
        
        Self {
            words,
            word_start_positions,
            obfuscated_words,
        }
    }
    
    fn find_word_positions(text: &str, words: &[String]) -> Vec<usize> {
        let mut positions = Vec::new();
        let mut pos = 0;
        
        for word in words {
            if let Some(word_pos) = text[pos..].find(word.as_str()) {
                positions.push(pos + word_pos);
                pos += word_pos + word.len();
            }
        }
        
        positions
    }
    
    pub fn mark_obfuscated_words(&mut self, obfuscation_positions: &[usize]) {
        for (word_idx, &word_start) in self.word_start_positions.iter().enumerate() {
            let word = &self.words[word_idx];
            let word_end = word_start + word.chars().count();
            
            let has_obfuscation = obfuscation_positions.iter()
                .any(|&pos| pos >= word_start && pos < word_end);
                
            if has_obfuscation {
                self.obfuscated_words.insert(word_idx);
            }
        }
    }
    
    pub fn get_metrics(&self) -> WordMetrics {
        let word_count = self.words.len();
        let avg_word_length = if word_count > 0 {
            self.words.iter().map(|w| w.len()).sum::<usize>() as f64 / word_count as f64
        } else {
            0.0
        };
        
        let single_char_words = self.words.iter().filter(|w| w.chars().count() == 1).count();
        let single_char_word_ratio = if word_count > 0 {
            single_char_words as f64 / word_count as f64
        } else {
            0.0
        };
        
        let obfuscated_word_count = self.obfuscated_words.len();
        let obfuscated_word_ratio = if word_count > 0 {
            obfuscated_word_count as f64 / word_count as f64
        } else {
            0.0
        };
        
        WordMetrics {
            word_count,
            avg_word_length,
            single_char_words,
            single_char_word_ratio,
            obfuscated_word_count,
            obfuscated_word_ratio,
        }
    }
    
    pub fn get_words(&self) -> &[String] {
        &self.words
    }
}

pub struct WordMetrics {
    pub word_count: usize,
    pub avg_word_length: f64,
    pub single_char_words: usize,
    pub single_char_word_ratio: f64,
    pub obfuscated_word_count: usize,
    pub obfuscated_word_ratio: f64,
}

pub struct ScriptAnalyzer {
    script_blocks: HashMap<&'static str, usize>,
    total_chars: usize,
    alphabetic_char_count: usize,
    words_with_script_mixing: usize,
    max_scripts_in_word: usize,
}

impl ScriptAnalyzer {
    pub fn new(chars: &[char]) -> Self {
        let mut script_blocks = HashMap::new();
        
        for &c in chars {
            let script = get_unicode_script(c);
            *script_blocks.entry(script).or_insert(0) += 1;
        }
        
        let total_chars = chars.len();
        let alphabetic_char_count = chars.iter().filter(|c| c.is_alphabetic()).count();
        
        Self {
            script_blocks,
            total_chars,
            alphabetic_char_count,
            words_with_script_mixing: 0,
            max_scripts_in_word: 0,
        }
    }
    
    pub fn analyze_words(&mut self, words: &[String]) {
        let mut words_with_mixing = 0;
        let mut max_scripts = 0;
        
        for word in words {
            let mut word_scripts = HashSet::new();
            for c in word.chars() {
                if c.is_alphabetic() {
                    word_scripts.insert(get_unicode_script(c));
                }
            }
            
            let script_count = word_scripts.len();
            if script_count > 1 {
                words_with_mixing += 1;
            }
            max_scripts = max_scripts.max(script_count);
        }
        
        self.words_with_script_mixing = words_with_mixing;
        self.max_scripts_in_word = max_scripts;
    }
    
    pub fn get_metrics(&self) -> ScriptMetrics {
        let unique_scripts = self.script_blocks.len();
        
        let script_mixing_ratio = if unique_scripts > 1 {
            let dominant_script_count = self.script_blocks.values().max().copied().unwrap_or(0);
            1.0 - (dominant_script_count as f64 / self.total_chars as f64)
        } else {
            0.0
        };
        
        let non_dominant_alphabetic = if self.alphabetic_char_count > 0 {
            let dominant_script = self.script_blocks.iter()
                .filter(|(script, _)| !matches!(**script, "Emoji" | "Math" | "Other"))
                .max_by_key(|(_, count)| **count);
            
            if let Some((_, dominant_count)) = dominant_script {
                if self.alphabetic_char_count > *dominant_count {
                    self.alphabetic_char_count - dominant_count
                } else {
                    0
                }
            } else {
                0
            }
        } else {
            0
        };
        
        let script_mixing_in_alphabetic_ratio = if self.alphabetic_char_count > 0 {
            non_dominant_alphabetic as f64 / self.alphabetic_char_count as f64
        } else {
            0.0
        };
        
        let has_latin = self.script_blocks.contains_key("Latin");
        let has_cyrillic = self.script_blocks.contains_key("Cyrillic");
        let has_greek = self.script_blocks.contains_key("Greek");
        
        ScriptMetrics {
            unique_scripts,
            script_mixing_ratio,
            script_mixing_in_alphabetic_ratio,
            words_with_script_mixing: self.words_with_script_mixing,
            max_scripts_in_word: self.max_scripts_in_word,
            has_latin,
            has_cyrillic,
            has_greek,
            latin_cyrillic_mixing: has_latin && has_cyrillic,
            latin_greek_mixing: has_latin && has_greek,
        }
    }
}

pub struct ScriptMetrics {
    pub unique_scripts: usize,
    pub script_mixing_ratio: f64,
    pub script_mixing_in_alphabetic_ratio: f64,
    pub words_with_script_mixing: usize,
    pub max_scripts_in_word: usize,
    pub has_latin: bool,
    pub has_cyrillic: bool,
    pub has_greek: bool,
    pub latin_cyrillic_mixing: bool,
    pub latin_greek_mixing: bool,
}

pub fn get_unicode_script(c: char) -> &'static str {
    let code = c as u32;
    match code {
        0x0000..=0x007F | 0x0080..=0x00FF | 0x0100..=0x017F | 0x0180..=0x024F | 
        0x1E00..=0x1EFF | 0x2C60..=0x2C7F | 0xA720..=0xA7FF => "Latin",
        0x0400..=0x04FF | 0x0500..=0x052F | 0x2DE0..=0x2DFF | 0xA640..=0xA69F => "Cyrillic",
        0x0370..=0x03FF | 0x1F00..=0x1FFF => "Greek",
        0x0600..=0x06FF | 0x0750..=0x077F | 0x08A0..=0x08FF | 
        0xFB50..=0xFDFF | 0xFE70..=0xFEFF => "Arabic",
        0x0590..=0x05FF | 0xFB1D..=0xFB4F => "Hebrew",
        0x4E00..=0x9FFF | 0x3400..=0x4DBF | 0x20000..=0x2A6DF | 0x2A700..=0x2B73F |
        0x2B740..=0x2B81F | 0x2B820..=0x2CEAF | 0xF900..=0xFAFF | 0x2F800..=0x2FA1F => "CJK",
        0x3040..=0x309F => "Hiragana",
        0x30A0..=0x30FF | 0x31F0..=0x31FF => "Katakana",
        0xAC00..=0xD7AF | 0x1100..=0x11FF | 0x3130..=0x318F | 0xA960..=0xA97F => "Hangul",
        0x0900..=0x097F => "Devanagari",
        0x0E00..=0x0E7F => "Thai",
        0x0530..=0x058F | 0xFB13..=0xFB17 => "Armenian",
        0x10A0..=0x10FF | 0x2D00..=0x2D2F => "Georgian",
        0x1F300..=0x1F9FF | 0x2600..=0x26FF | 0x2700..=0x27BF => "Emoji",
        0x2200..=0x22FF | 0x2A00..=0x2AFF | 0x27C0..=0x27EF | 0x2980..=0x29FF => "Math",
        _ => "Other"
    }
}