use lazy_static::lazy_static;
use std::collections::{HashMap};
use regex::Regex;


// --- Lazily Initialized Constants ---
lazy_static! {
    // Base64: Require at least 20 chars AND proper padding OR clear start (mimics actual Base64)
    // Must have 5+ groups of 4 chars (20+ chars minimum) to avoid matching normal English
    pub static ref BASE64_REGEX: Regex = Regex::new(r"(?:[A-Za-z0-9+/]{4}){5,}(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)").unwrap();
    
    // Hex: Require 0x prefix OR minimum 8 consecutive hex chars to avoid matching common words
    // This prevents "be", "deaf", "feed" from triggering false positives
    // Capture group (1) contains the hex digits for decoding
    pub static ref HEX_REGEX: Regex = Regex::new(r"(?:0x([0-9a-fA-F]{4,})|\\x([0-9a-fA-F]{2,})|([0-9a-fA-F]{8,}))").unwrap();
    
    // URL encoding: Require at least 2 consecutive encoded chars to avoid random % matches
    pub static ref URL_DECODE_REGEX: Regex = Regex::new(r"(?:%[0-9a-fA-F]{2}){2,}").unwrap();
    pub static ref INVISIBLE_CHAR_REGEX: Regex = Regex::new(r"[\u{200B}-\u{200D}\u{FEFF}\u{00AD}\u{034F}\u{061C}\u{115F}\u{1160}\u{17B4}\u{17B5}\u{180E}\u{2060}-\u{2064}\u{2066}-\u{206F}\u{3164}\u{FFA0}\u{FFF0}-\u{FFF8}]").unwrap();
    pub static ref DIRECTIONALITY_REGEX: Regex = Regex::new(r"[\u{061C}\u{200E}\u{200F}\u{202A}-\u{202E}\u{2066}-\u{206F}\u{10800}-\u{10805}\u{10808}\u{1080A}-\u{10835}\u{10837}\u{10838}\u{1083C}\u{1083F}-\u{10855}\u{10857}-\u{1089E}\u{108A7}-\u{108AF}]").unwrap();
    pub static ref TAG_CHAR_REGEX: Regex = Regex::new(r"[\u{E0000}-\u{E007F}\u{E0100}-\u{E01EF}]").unwrap();
    pub static ref SEPARATOR_REGEX: Regex = Regex::new(r"[\s_.,\-+|/\\~`!@#$%^&*()=\[\]{}:;\'<>?]+").unwrap();
    pub static ref STRIKETHROUGH_REGEX: Regex = Regex::new(r"[\u{0336}\u{0337}\u{0338}]").unwrap();
    pub static ref ROT13_REGEX: Regex = Regex::new(r"[a-zA-Z]").unwrap();
    pub static ref UPSIDE_DOWN_MARKERS_REGEX: Regex = Regex::new(r"[\u{0F3A}\u{0F3B}\u{0F3C}\u{0F3D}\u{169B}\u{169C}\u{2045}\u{2046}\u{207D}\u{207E}\u{208D}\u{208E}\u{2308}\u{2309}\u{230A}\u{230B}\u{2329}\u{232A}\u{2768}-\u{2775}\u{27C5}\u{27C6}\u{27E6}-\u{27EF}\u{2983}-\u{2998}\u{29D8}-\u{29DB}\u{29FC}\u{29FD}\u{2E22}-\u{2E25}\u{2E28}\u{2E29}\u{3008}-\u{3011}\u{3014}-\u{301B}\u{FE59}-\u{FE5E}\u{FE64}\u{FE65}\u{FF08}\u{FF09}\u{FF3B}\u{FF3D}\u{FF5B}\u{FF5D}\u{FF5F}\u{FF60}\u{FF62}\u{FF63}]").unwrap();

    // Leetspeak mapping for single characters
    pub static ref LEETSPEAK_MAP: HashMap<char, char> = {
        let mut m = HashMap::new();
        // Standard single-character mappings
        m.insert('@', 'a'); m.insert('4', 'a'); m.insert('^', 'a');
        m.insert('8', 'b'); m.insert('6', 'b');
        m.insert('(', 'c'); m.insert('<', 'c'); m.insert('[', 'c');
        m.insert(')', 'd'); m.insert(']', 'd');
        m.insert('3', 'e'); m.insert('€', 'e');
        m.insert('9', 'g');
        m.insert('#', 'h');
        m.insert('1', 'i'); m.insert('!', 'i'); m.insert('|', 'i');
        m.insert('0', 'o');
        m.insert('>', 'o');
        m.insert('5', 's'); m.insert('$', 's');
        m.insert('7', 't'); m.insert('+', 't');
        m.insert('2', 'z');
        m
    };

    // HTML entity mappings
    pub static ref HTML_ENTITIES: Vec<(&'static str, &'static str)> = vec![
            ("&lt;", "<"), ("&gt;", ">"), ("&amp;", "&"), ("&quot;", "\""),
            ("&apos;", "'"), ("&#39;", "'"), ("&nbsp;", " "),
            ("&iexcl;", "¡"), ("&cent;", "¢"), ("&pound;", "£"), ("&curren;", "¤"),
            ("&yen;", "¥"), ("&brvbar;", "¦"), ("&sect;", "§"), ("&uml;", "¨"),
            ("&copy;", "©"), ("&ordf;", "ª"), ("&laquo;", "«"), ("&not;", "¬"),
            ("&shy;", "\u{00AD}"), ("&reg;", "®"), ("&macr;", "¯"), ("&deg;", "°"),
            ("&plusmn;", "±"), ("&sup2;", "²"), ("&sup3;", "³"), ("&acute;", "´"),
            ("&micro;", "µ"), ("&para;", "¶"), ("&middot;", "·"), ("&cedil;", "¸"),
            ("&sup1;", "¹"), ("&ordm;", "º"), ("&raquo;", "»"), ("&frac14;", "¼"),
            ("&frac12;", "½"), ("&frac34;", "¾"), ("&iquest;", "¿"),
            // Latin extended
            ("&Agrave;", "À"), ("&Aacute;", "Á"), ("&Acirc;", "Â"), ("&Atilde;", "Ã"),
            ("&Auml;", "Ä"), ("&Aring;", "Å"), ("&AElig;", "Æ"), ("&Ccedil;", "Ç"),
            ("&Egrave;", "È"), ("&Eacute;", "É"), ("&Ecirc;", "Ê"), ("&Euml;", "Ë"),
            ("&Igrave;", "Ì"), ("&Iacute;", "Í"), ("&Icirc;", "Î"), ("&Iuml;", "Ï"),
            ("&ETH;", "Ð"), ("&Ntilde;", "Ñ"), ("&Ograve;", "Ò"), ("&Oacute;", "Ó"),
            ("&Ocirc;", "Ô"), ("&Otilde;", "Õ"), ("&Ouml;", "Ö"), ("&times;", "×"),
            ("&Oslash;", "Ø"), ("&Ugrave;", "Ù"), ("&Uacute;", "Ú"), ("&Ucirc;", "Û"),
            ("&Uuml;", "Ü"), ("&Yacute;", "Ý"), ("&THORN;", "Þ"), ("&szlig;", "ß"),
            ("&agrave;", "à"), ("&aacute;", "á"), ("&acirc;", "â"), ("&atilde;", "ã"),
            ("&auml;", "ä"), ("&aring;", "å"), ("&aelig;", "æ"), ("&ccedil;", "ç"),
            ("&egrave;", "è"), ("&eacute;", "é"), ("&ecirc;", "ê"), ("&euml;", "ë"),
            ("&igrave;", "ì"), ("&iacute;", "í"), ("&icirc;", "î"), ("&iuml;", "ï"),
            ("&eth;", "ð"), ("&ntilde;", "ñ"), ("&ograve;", "ò"), ("&oacute;", "ó"),
            ("&ocirc;", "ô"), ("&otilde;", "õ"), ("&ouml;", "ö"), ("&divide;", "÷"),
            ("&oslash;", "ø"), ("&ugrave;", "ù"), ("&uacute;", "ú"), ("&ucirc;", "û"),
            ("&uuml;", "ü"), ("&yacute;", "ý"), ("&thorn;", "þ"), ("&yuml;", "ÿ"),
            // Special characters often used in obfuscation
            ("&Tab;", "\t"), ("&NewLine;", "\n"),
            ("&excl;", "!"), ("&num;", "#"), ("&dollar;", "$"), ("&percnt;", "%"),
            ("&lpar;", "("), ("&rpar;", ")"), ("&ast;", "*"), ("&plus;", "+"),
            ("&comma;", ","), ("&period;", "."), ("&sol;", "/"), ("&colon;", ":"),
            ("&semi;", ";"), ("&equals;", "="), ("&quest;", "?"), ("&commat;", "@"),
            ("&lsqb;", "["), ("&bsol;", "\\"), ("&rsqb;", "]"), ("&Hat;", "^"),
            ("&lowbar;", "_"), ("&grave;", "`"), ("&lcub;", "{"), ("&verbar;", "|"),
            ("&rcub;", "}"), ("&tilde;", "~"),
        ];



    // Multi-character leetspeak patterns
    pub static ref MULTI_CHAR_LEETSPEAK: Vec<(&'static str, &'static str)> = vec![
        ("|3", "b"),
        ("|)", "d"),
        ("|=", "f"),
        ("ph", "f"),
        ("|-|", "h"),
        ("-|", "j"),
        ("|<", "k"),
        ("|{", "k"),
        ("|_", "l"),
        ("|v|", "m"),
        ("\\/\\/", "w"),
        ("\\/", "v"),
        ("|\\|", "n"),
        ("()", "o"),
        ("|D", "p"),
        ("kw", "q"),
        ("|2", "r"),
        ("12", "r"),
        ("|?", "r"),
        ("_|_", "t"),
        ("\\/\\/", "w"),
        ("}{", "x"),
        ("/", "y"),
        ("j", "y"),
        ("2", "z")
    ];

    pub static ref HOMOGLYPH_MAP: HashMap<char, char> = {
    let mut m = HashMap::new();

    // A variants - comprehensive
    m.insert('Α', 'a'); m.insert('А', 'a'); m.insert('Ａ', 'a'); m.insert('∀', 'a');
    m.insert('Ʌ', 'a'); m.insert('ᗅ', 'a'); m.insert('ᴀ', 'a'); m.insert('₳', 'a');
    m.insert('ɑ', 'a'); m.insert('𝐚', 'a'); m.insert('𝑎', 'a'); m.insert('𝒂', 'a');
    m.insert('𝓪', 'a'); m.insert('𝔞', 'a'); m.insert('𝕒', 'a'); m.insert('𝖆', 'a');
    m.insert('𝖺', 'a'); m.insert('𝗮', 'a'); m.insert('𝘢', 'a'); m.insert('𝙖', 'a');
    m.insert('𝚊', 'a'); m.insert('ⱥ', 'a'); m.insert('α', 'a'); m.insert('ά', 'a');

    // B variants
    m.insert('В', 'b'); m.insert('Β', 'b'); m.insert('Ｂ', 'b'); m.insert('ᗷ', 'b');
    m.insert('ʙ', 'b'); m.insert('ᵇ', 'b'); m.insert('𝐛', 'b'); m.insert('𝑏', 'b');
    m.insert('𝒃', 'b'); m.insert('𝓫', 'b'); m.insert('𝔟', 'b'); m.insert('𝕓', 'b');
    m.insert('𝖇', 'b'); m.insert('𝖻', 'b'); m.insert('𝗯', 'b'); m.insert('𝘣', 'b');
    m.insert('𝙗', 'b'); m.insert('𝚋', 'b'); m.insert('ᖯ', 'b'); m.insert('ḃ', 'b');

    // C variants
    m.insert('С', 'c'); m.insert('Ϲ', 'c'); m.insert('Ｃ', 'c'); m.insert('ᴄ', 'c');
    m.insert('ᶜ', 'c'); m.insert('𝐜', 'c'); m.insert('𝑐', 'c'); m.insert('𝒄', 'c');
    m.insert('𝓬', 'c'); m.insert('𝔠', 'c'); m.insert('𝕔', 'c'); m.insert('𝖈', 'c');
    m.insert('𝖼', 'c'); m.insert('𝗰', 'c'); m.insert('𝘤', 'c'); m.insert('𝙘', 'c');
    m.insert('𝚌', 'c'); m.insert('ℂ', 'c'); m.insert('ḉ', 'c'); m.insert('ċ', 'c');

    // D variants
    m.insert('Ɖ', 'd'); m.insert('Ｄ', 'd'); m.insert('ᴅ', 'd'); m.insert('ᵈ', 'd');
    m.insert('𝐝', 'd'); m.insert('𝑑', 'd'); m.insert('𝒅', 'd'); m.insert('𝓭', 'd');
    m.insert('𝔡', 'd'); m.insert('𝕕', 'd'); m.insert('𝖉', 'd'); m.insert('𝖽', 'd');
    m.insert('𝗱', 'd'); m.insert('𝘥', 'd'); m.insert('𝙙', 'd'); m.insert('𝚍', 'd');
    m.insert('ď', 'd'); m.insert('ḍ', 'd'); m.insert('ḋ', 'd'); m.insert('đ', 'd');

    // E variants
    m.insert('Е', 'e'); m.insert('Ε', 'e'); m.insert('Ｅ', 'e'); m.insert('ᴇ', 'e');
    m.insert('ᵉ', 'e'); m.insert('ₑ', 'e'); m.insert('𝐞', 'e'); m.insert('𝑒', 'e');
    m.insert('𝒆', 'e'); m.insert('𝓮', 'e'); m.insert('𝔢', 'e'); m.insert('𝕖', 'e');
    m.insert('𝖊', 'e'); m.insert('𝖾', 'e'); m.insert('𝗲', 'e'); m.insert('𝘦', 'e');
    m.insert('𝙚', 'e'); m.insert('𝚎', 'e'); m.insert('ℯ', 'e'); m.insert('ℰ', 'e');
    m.insert('є', 'e'); m.insert('ε', 'e'); m.insert('έ', 'e');

    // F variants
    m.insert('ꜰ', 'f'); m.insert('Ｆ', 'f'); m.insert('ᶠ', 'f'); m.insert('𝐟', 'f');
    m.insert('𝑓', 'f'); m.insert('𝒇', 'f'); m.insert('𝓯', 'f'); m.insert('𝔣', 'f');
    m.insert('𝕗', 'f'); m.insert('𝖋', 'f'); m.insert('𝖿', 'f'); m.insert('𝗳', 'f');
    m.insert('𝘧', 'f'); m.insert('𝙛', 'f'); m.insert('𝚏', 'f'); m.insert('ḟ', 'f');

    // G variants
    m.insert('Ԍ', 'g'); m.insert('Ｇ', 'g'); m.insert('ɢ', 'g'); m.insert('ᵍ', 'g');
    m.insert('𝐠', 'g'); m.insert('𝑔', 'g'); m.insert('𝒈', 'g'); m.insert('𝓰', 'g');
    m.insert('𝔤', 'g'); m.insert('𝕘', 'g'); m.insert('𝖌', 'g'); m.insert('𝗀', 'g');
    m.insert('𝗴', 'g'); m.insert('𝘨', 'g'); m.insert('𝙜', 'g'); m.insert('𝚐', 'g');
    m.insert('ģ', 'g'); m.insert('ǧ', 'g');

    // H variants
    m.insert('Н', 'h'); m.insert('Η', 'h'); m.insert('Ｈ', 'h'); m.insert('ʜ', 'h');
    m.insert('ᴴ', 'h'); m.insert('ₕ', 'h'); m.insert('𝐡', 'h'); m.insert('𝒉', 'h');
    m.insert('𝓱', 'h'); m.insert('𝔥', 'h'); m.insert('𝕙', 'h'); m.insert('𝖍', 'h');
    m.insert('𝗁', 'h'); m.insert('𝗵', 'h'); m.insert('𝘩', 'h'); m.insert('𝙝', 'h');
    m.insert('𝚑', 'h'); m.insert('ℎ', 'h'); m.insert('ħ', 'h'); m.insert('ḧ', 'h');

    // I variants
    m.insert('І', 'i'); m.insert('Ι', 'i'); m.insert('Ｉ', 'i'); m.insert('ɪ', 'i');
    m.insert('ⁱ', 'i'); m.insert('ᵢ', 'i'); m.insert('ᶤ', 'i'); m.insert('𝐢', 'i');
    m.insert('𝒊', 'i'); m.insert('𝓲', 'i'); m.insert('𝔦', 'i'); m.insert('𝕚', 'i');
    m.insert('𝖎', 'i'); m.insert('𝗂', 'i'); m.insert('𝗶', 'i');
    m.insert('𝘪', 'i'); m.insert('𝙞', 'i'); m.insert('𝚒', 'i'); m.insert('ℹ', 'i');
    m.insert('í', 'i'); m.insert('ì', 'i'); m.insert('ĩ', 'i'); m.insert('ī', 'i');
    m.insert('ί', 'i');

    // J variants
    m.insert('Ｊ', 'j'); m.insert('ⱼ', 'j'); m.insert('𝐣', 'j'); m.insert('𝒿', 'j');
    m.insert('𝓳', 'j'); m.insert('𝔧', 'j'); m.insert('𝕛', 'j'); m.insert('𝖏', 'j');
    m.insert('𝗃', 'j'); m.insert('𝗷', 'j'); m.insert('𝘫', 'j'); m.insert('𝙟', 'j');
    m.insert('𝚓', 'j'); m.insert('ĵ', 'j');

    // K variants
    m.insert('К', 'k'); m.insert('Κ', 'k'); m.insert('Ｋ', 'k'); m.insert('ᴋ', 'k');
    m.insert('ᵏ', 'k'); m.insert('𝐤', 'k'); m.insert('𝓀', 'k'); m.insert('𝓴', 'k');
    m.insert('𝔨', 'k'); m.insert('𝕜', 'k'); m.insert('𝖐', 'k'); m.insert('𝗄', 'k');
    m.insert('𝗸', 'k'); m.insert('𝘬', 'k'); m.insert('𝙠', 'k'); m.insert('𝚔', 'k');
    m.insert('ќ', 'k'); m.insert('ḳ', 'k');

    // L variants
    m.insert('Ｌ', 'l'); m.insert('ʟ', 'l'); m.insert('ˡ', 'l'); m.insert('𝐥', 'l');
    m.insert('𝓁', 'l'); m.insert('𝓵', 'l'); m.insert('𝔩', 'l'); m.insert('𝕝', 'l');
    m.insert('𝖑', 'l'); m.insert('𝗅', 'l'); m.insert('𝗹', 'l'); m.insert('𝘭', 'l');
    m.insert('𝙡', 'l'); m.insert('𝚕', 'l'); m.insert('ℓ', 'l'); m.insert('ŀ', 'l');
    m.insert('ĺ', 'l'); m.insert('ľ', 'l');

    // M variants
    m.insert('М', 'm'); m.insert('Μ', 'm'); m.insert('Ｍ', 'm'); m.insert('ᴍ', 'm');
    m.insert('ᵐ', 'm'); m.insert('𝐦', 'm'); m.insert('𝓂', 'm'); m.insert('𝓶', 'm');
    m.insert('𝔪', 'm'); m.insert('𝕞', 'm'); m.insert('𝖒', 'm'); m.insert('𝗆', 'm');
    m.insert('𝗺', 'm'); m.insert('𝘮', 'm'); m.insert('𝙢', 'm'); m.insert('𝚖', 'm');
    m.insert('ℳ', 'm'); m.insert('ḿ', 'm');

    // N variants
    m.insert('Ν', 'n'); m.insert('Ｎ', 'n'); m.insert('ɴ', 'n'); m.insert('ⁿ', 'n');
    m.insert('𝐧', 'n'); m.insert('𝓃', 'n'); m.insert('𝓷', 'n'); m.insert('𝔫', 'n');
    m.insert('𝕟', 'n'); m.insert('𝖓', 'n'); m.insert('𝗇', 'n'); m.insert('𝗻', 'n');
    m.insert('𝘯', 'n'); m.insert('𝙣', 'n'); m.insert('𝚗', 'n'); m.insert('ℕ', 'n');
    m.insert('ñ', 'n'); m.insert('ń', 'n'); m.insert('ň', 'n');

    // O variants
    m.insert('О', 'o'); m.insert('Ο', 'o'); m.insert('Ｏ', 'o'); m.insert('ᴏ', 'o');
    m.insert('ᵒ', 'o'); m.insert('ₒ', 'o'); m.insert('𝐨', 'o');
    m.insert('𝓸', 'o'); m.insert('𝔬', 'o'); m.insert('𝕠', 'o'); m.insert('𝖔', 'o');
    m.insert('𝗈', 'o'); m.insert('𝗼', 'o'); m.insert('𝘰', 'o'); m.insert('𝙤', 'o');
    m.insert('𝚘', 'o'); m.insert('ℴ', 'o'); m.insert('ò', 'o'); m.insert('ó', 'o');
    m.insert('ô', 'o'); m.insert('õ', 'o'); m.insert('ö', 'o'); m.insert('ο', 'o');

    // P variants
    m.insert('Р', 'p'); m.insert('Ρ', 'p'); m.insert('Ｐ', 'p'); m.insert('ᴘ', 'p');
    m.insert('ᵖ', 'p'); m.insert('𝐩', 'p'); m.insert('𝓅', 'p'); m.insert('𝓹', 'p');
    m.insert('𝔭', 'p'); m.insert('𝕡', 'p'); m.insert('𝖕', 'p'); m.insert('𝗉', 'p');
    m.insert('𝗽', 'p'); m.insert('𝘱', 'p'); m.insert('𝙥', 'p'); m.insert('𝚙', 'p');
    m.insert('ℙ', 'p'); m.insert('ṗ', 'p'); m.insert('ρ', 'p');

    // Q variants
    m.insert('Ｑ', 'q'); m.insert('𝐪', 'q'); m.insert('𝓆', 'q'); m.insert('𝓺', 'q');
    m.insert('𝔮', 'q'); m.insert('𝕢', 'q'); m.insert('𝖖', 'q'); m.insert('𝗊', 'q');
    m.insert('𝗾', 'q'); m.insert('𝘲', 'q'); m.insert('𝙦', 'q'); m.insert('𝚚', 'q');
    m.insert('ℚ', 'q');

    // R variants
    m.insert('Ｒ', 'r'); m.insert('ʀ', 'r'); m.insert('ʳ', 'r'); m.insert('𝐫', 'r');
    m.insert('𝓇', 'r'); m.insert('𝓻', 'r'); m.insert('𝔯', 'r'); m.insert('𝕣', 'r');
    m.insert('𝖗', 'r'); m.insert('𝗋', 'r'); m.insert('𝗿', 'r'); m.insert('𝘳', 'r');
    m.insert('𝙧', 'r'); m.insert('𝚛', 'r'); m.insert('ℛ', 'r'); m.insert('ℜ', 'r');
    m.insert('ŕ', 'r'); m.insert('ř', 'r'); m.insert('ṛ', 'r');

    // S variants
    m.insert('Ѕ', 's'); m.insert('Ｓ', 's'); m.insert('ꜱ', 's'); m.insert('ˢ', 's');
    m.insert('𝐬', 's'); m.insert('𝓈', 's'); m.insert('𝓼', 's'); m.insert('𝔰', 's');
    m.insert('𝕤', 's'); m.insert('𝖘', 's'); m.insert('𝗌', 's'); m.insert('𝘀', 's');
    m.insert('𝘴', 's'); m.insert('𝙨', 's'); m.insert('𝚜', 's'); m.insert('š', 's');
    m.insert('ş', 's'); m.insert('ś', 's'); m.insert('ṡ', 's');

    // T variants
    m.insert('Т', 't'); m.insert('Τ', 't'); m.insert('Ｔ', 't'); m.insert('ᴛ', 't');
    m.insert('ᵗ', 't'); m.insert('𝐭', 't'); m.insert('𝓉', 't'); m.insert('𝓽', 't');
    m.insert('𝔱', 't'); m.insert('𝕥', 't'); m.insert('𝖙', 't'); m.insert('𝗍', 't');
    m.insert('𝘁', 't'); m.insert('𝘵', 't'); m.insert('𝙩', 't'); m.insert('𝚝', 't');
    m.insert('ť', 't'); m.insert('ţ', 't'); m.insert('ṫ', 't');

    // U variants
    m.insert('Ｕ', 'u'); m.insert('ᴜ', 'u'); m.insert('ᵘ', 'u'); m.insert('ᵤ', 'u');
    m.insert('𝐮', 'u'); m.insert('𝓊', 'u'); m.insert('𝓾', 'u'); m.insert('𝔲', 'u');
    m.insert('𝕦', 'u'); m.insert('𝖚', 'u'); m.insert('𝗎', 'u'); m.insert('𝘂', 'u');
    m.insert('𝘶', 'u'); m.insert('𝙪', 'u'); m.insert('𝚞', 'u'); m.insert('ù', 'u');
    m.insert('ú', 'u'); m.insert('û', 'u'); m.insert('ü', 'u'); m.insert('ũ', 'u');

    // V variants
    m.insert('Ѵ', 'v'); m.insert('Ｖ', 'v'); m.insert('ᴠ', 'v'); m.insert('ᵛ', 'v');
    m.insert('ⱽ', 'v'); m.insert('𝐯', 'v'); m.insert('𝓋', 'v'); m.insert('𝓿', 'v');
    m.insert('𝔳', 'v'); m.insert('𝕧', 'v'); m.insert('𝖛', 'v'); m.insert('𝗏', 'v');
    m.insert('𝘃', 'v'); m.insert('𝘷', 'v'); m.insert('𝙫', 'v'); m.insert('𝚟', 'v');

    // W variants
    m.insert('Ｗ', 'w'); m.insert('ᴡ', 'w'); m.insert('ʷ', 'w'); m.insert('𝐰', 'w');
    m.insert('𝓌', 'w'); m.insert('𝔀', 'w'); m.insert('𝔴', 'w'); m.insert('𝕨', 'w');
    m.insert('𝖜', 'w'); m.insert('𝗐', 'w'); m.insert('𝘄', 'w'); m.insert('𝘸', 'w');
    m.insert('𝙬', 'w'); m.insert('𝚠', 'w'); m.insert('ẅ', 'w');

    // X variants
    m.insert('Х', 'x'); m.insert('Χ', 'x'); m.insert('Ｘ', 'x'); m.insert('ˣ', 'x');
    m.insert('𝐱', 'x'); m.insert('𝓍', 'x'); m.insert('𝔁', 'x'); m.insert('𝔵', 'x');
    m.insert('𝕩', 'x'); m.insert('𝖝', 'x'); m.insert('𝗑', 'x'); m.insert('𝘅', 'x');
    m.insert('𝘹', 'x'); m.insert('𝙭', 'x'); m.insert('𝚡', 'x'); m.insert('χ', 'x');

    // Y variants
    m.insert('Υ', 'y'); m.insert('Ｙ', 'y'); m.insert('ʏ', 'y'); m.insert('ʸ', 'y');
    m.insert('𝐲', 'y'); m.insert('𝓎', 'y'); m.insert('𝔂', 'y'); m.insert('𝔶', 'y');
    m.insert('𝕪', 'y'); m.insert('𝖞', 'y'); m.insert('𝗒', 'y'); m.insert('𝘆', 'y');
    m.insert('𝘺', 'y'); m.insert('𝙮', 'y'); m.insert('𝚢', 'y'); m.insert('ý', 'y');
    m.insert('ÿ', 'y'); m.insert('ŷ', 'y');

    // Z variants
    m.insert('Ｚ', 'z'); m.insert('ᴢ', 'z'); m.insert('ᶻ', 'z'); m.insert('𝐳', 'z');
    m.insert('𝓏', 'z'); m.insert('𝔃', 'z'); m.insert('𝔷', 'z'); m.insert('𝕫', 'z');
    m.insert('𝖟', 'z'); m.insert('𝗓', 'z'); m.insert('𝘇', 'z'); m.insert('𝘻', 'z');
    m.insert('𝙯', 'z'); m.insert('𝚣', 'z'); m.insert('ℤ', 'z'); m.insert('ž', 'z');
    m.insert('ź', 'z'); m.insert('ż', 'z');

    // Numbers - comprehensive variants
    m.insert('０', '0'); m.insert('𝟎', '0'); m.insert('𝟘', '0'); m.insert('𝟢', '0');
    m.insert('𝟬', '0'); m.insert('𝟶', '0');
    m.insert('１', '1'); m.insert('𝟏', '1'); m.insert('𝟙', '1'); m.insert('𝟣', '1');
    m.insert('𝟭', '1'); m.insert('𝟷', '1');
    m.insert('２', '2'); m.insert('𝟐', '2'); m.insert('𝟚', '2'); m.insert('𝟤', '2');
    m.insert('𝟮', '2'); m.insert('𝟸', '2');
    m.insert('３', '3'); m.insert('𝟑', '3'); m.insert('𝟛', '3'); m.insert('𝟥', '3');
    m.insert('𝟯', '3'); m.insert('𝟹', '3');
    m.insert('４', '4'); m.insert('𝟒', '4'); m.insert('𝟜', '4'); m.insert('𝟦', '4');
    m.insert('𝟰', '4'); m.insert('𝟺', '4');
    m.insert('５', '5'); m.insert('𝟓', '5'); m.insert('𝟝', '5'); m.insert('𝟧', '5');
    m.insert('𝟱', '5'); m.insert('𝟻', '5');
    m.insert('６', '6'); m.insert('𝟔', '6'); m.insert('𝟞', '6'); m.insert('𝟨', '6');
    m.insert('𝟲', '6'); m.insert('𝟼', '6');
    m.insert('７', '7'); m.insert('𝟕', '7'); m.insert('𝟟', '7'); m.insert('𝟩', '7');
    m.insert('𝟳', '7'); m.insert('𝟽', '7');
    m.insert('８', '8'); m.insert('𝟖', '8'); m.insert('𝟠', '8'); m.insert('𝟪', '8');
    m.insert('𝟴', '8'); m.insert('𝟾', '8');
    m.insert('９', '9'); m.insert('𝟗', '9'); m.insert('𝟡', '9'); m.insert('𝟫', '9');
    m.insert('𝟵', '9'); m.insert('𝟿', '9');

    // Note: Regular ASCII letters (a-z, A-Z) should NOT be in this map
    // Only lookalike characters that need to be normalized to ASCII should be here

    // Cyrillic homoglyphs
    m.insert('А', 'A'); m.insert('В', 'B'); m.insert('Е', 'E'); m.insert('З', '3');
           m.insert('И', 'N'); m.insert('К', 'K'); m.insert('М', 'M'); m.insert('Н', 'H');
           m.insert('О', 'O'); m.insert('Р', 'P'); m.insert('С', 'C'); m.insert('Т', 'T');
           m.insert('У', 'y'); m.insert('Х', 'X'); m.insert('а', 'a'); m.insert('в', 'b');
           m.insert('с', 'c'); m.insert('е', 'e'); m.insert('і', 'i'); m.insert('ј', 'j');
           m.insert('к', 'k'); m.insert('м', 'm'); m.insert('н', 'h'); m.insert('о', 'o');
           m.insert('р', 'p'); m.insert('ѕ', 's'); m.insert('т', 't'); m.insert('у', 'y');
           m.insert('х', 'x'); m.insert('у', 'y'); m.insert('Ⅰ', 'I'); m.insert('Ⅱ', 'I');
           m.insert('Ⅲ', 'I'); m.insert('Ⅳ', 'I'); m.insert('Ⅴ', 'V'); m.insert('Ⅵ', 'V');
           m.insert('Ⅶ', 'V'); m.insert('Ⅷ', 'V'); m.insert('Ⅸ', 'I'); m.insert('Ⅹ', 'X');
           m.insert('Ⅺ', 'X'); m.insert('Ⅻ', 'X'); m.insert('Ⅼ', 'L'); m.insert('Ⅽ', 'C');
           m.insert('Ⅾ', 'D'); m.insert('Ⅿ', 'M'); m.insert('ⅰ', 'i'); m.insert('ⅱ', 'i');
           m.insert('ⅲ', 'i'); m.insert('ⅳ', 'i'); m.insert('ⅴ', 'v'); m.insert('ⅵ', 'v');
           m.insert('ⅶ', 'v'); m.insert('ⅷ', 'v'); m.insert('ⅸ', 'i'); m.insert('ⅹ', 'x');
           m.insert('ⅺ', 'x'); m.insert('ⅻ', 'x'); m.insert('ⅼ', 'l'); m.insert('ⅽ', 'c');
           m.insert('ⅾ', 'd'); m.insert('ⅿ', 'm');

           // Greek homoglyphs
           m.insert('Α', 'A'); m.insert('Β', 'B'); m.insert('Γ', 'G'); m.insert('Δ', 'D');
           m.insert('Ε', 'E'); m.insert('Ζ', 'Z'); m.insert('Η', 'H'); m.insert('Ι', 'I');
           m.insert('Κ', 'K'); m.insert('Λ', 'L'); m.insert('Μ', 'M'); m.insert('Ν', 'N');
           m.insert('Ο', 'O'); m.insert('Ρ', 'P'); m.insert('Σ', 'S'); m.insert('Τ', 'T');
           m.insert('Υ', 'Y'); m.insert('Χ', 'X'); m.insert('α', 'a'); m.insert('β', 'b');
           m.insert('γ', 'g'); m.insert('δ', 'd'); m.insert('ε', 'e'); m.insert('ζ', 'z');
           m.insert('η', 'h'); m.insert('ι', 'i'); m.insert('κ', 'k'); m.insert('λ', 'l');
           m.insert('μ', 'm'); m.insert('ν', 'n'); m.insert('ο', 'o'); m.insert('ρ', 'p');
           m.insert('σ', 's'); m.insert('τ', 't'); m.insert('υ', 'u'); m.insert('χ', 'x');
           m.insert('ω', 'w');

           // Other homoglyphs
           m.insert('１', '1'); m.insert('２', '2'); m.insert('３', '3'); m.insert('４', '4');
           m.insert('５', '5'); m.insert('６', '6'); m.insert('７', '7'); m.insert('８', '8');
           m.insert('９', '9'); m.insert('０', '0'); m.insert('—', '-'); m.insert('–', '-');
           m.insert('‘', '\''); m.insert('’', '\''); m.insert('“', '"'); m.insert('”', '"');
           m.insert('‚', ',');

           m
};

    pub static ref FLIPPED_CHARS: HashMap<char, char> = {
    let mut m = HashMap::new();
    // Original mappings
    m.insert('ɐ', 'a'); m.insert('q', 'b'); m.insert('ɔ', 'c'); m.insert('p', 'd');
    m.insert('ǝ', 'e'); m.insert('ɟ', 'f'); m.insert('ƃ', 'g'); m.insert('ɥ', 'h');
    m.insert('ᴉ', 'i'); m.insert('ɾ', 'j'); m.insert('ʞ', 'k'); m.insert('l', 'l');
    m.insert('ɯ', 'm'); m.insert('u', 'n'); m.insert('o', 'o'); m.insert('d', 'p');
    m.insert('b', 'q'); m.insert('ɹ', 'r'); m.insert('s', 's'); m.insert('ʇ', 't');
    m.insert('n', 'u'); m.insert('ʌ', 'v'); m.insert('ʍ', 'w'); m.insert('x', 'x');
    m.insert('ʎ', 'y'); m.insert('z', 'z');
    m.insert('Ɐ', 'A'); m.insert('ᗺ', 'B'); m.insert('Ɔ', 'C'); m.insert('ᗡ', 'D');
    m.insert('Ǝ', 'E'); m.insert('Ⅎ', 'F'); m.insert('פ', 'G'); m.insert('H', 'H');
    m.insert('I', 'I'); m.insert('ſ', 'J'); m.insert('ʞ', 'K'); m.insert('˥', 'L');
    m.insert('W', 'M'); m.insert('N', 'N'); m.insert('O', 'O'); m.insert('Ԁ', 'P');
    m.insert('Q', 'Q'); m.insert('ɹ', 'R'); m.insert('S', 'S'); m.insert('┴', 'T');
    m.insert('∩', 'U'); m.insert('Λ', 'V'); m.insert('M', 'W'); m.insert('X', 'X');
    m.insert('⅄', 'Y'); m.insert('Z', 'Z');

    // more common upside-down characters
    m.insert('ı', 'i'); // Another common mapping for i
    m.insert('ʃ', 'j'); // Another common mapping for j
    m.insert('ʅ', 'r'); // Another r variant
    m.insert('ɿ', 'r'); // Another r variant
    m.insert('ʅ', 'j'); // Alternative j
    m.insert('ɒ', 'a'); // Another flipped a
    m.insert('ǫ', 'b'); // Alternative flipped b
    m.insert('ɟ', 'f'); // Clearer flipped f
    m.insert('ƃ', 'g'); // Clearer flipped g
    m.insert('ɥ', 'h'); // Clearer flipped h
    m.insert('ɯ', 'm'); // Clearer flipped m
    m.insert('ɐ', 'e'); // Alternative e (sometimes used)
    m.insert('ʇ', 't'); // Clearer flipped t
    m.insert('ʎ', 'y'); // Clearer flipped y

    // punctuation
    m.insert('˙', '.');
    m.insert('¿', '?');
    m.insert('¡', '!');
    m.insert('،', ',');
    m.insert('؛', ';');
    m.insert('„', '"');
    m.insert('‟', '"');
    m.insert(')', '(');
    m.insert('(', ')');
    m.insert('[', ']');
    m.insert(']', '[');
    m.insert('}', '{');
    m.insert('{', '}');

    m
};

pub static ref SUPERSCRIPT_MAP: HashMap<char, char> = {
        let mut m = HashMap::new();
        m.insert('⁰', '0'); m.insert('¹', '1'); m.insert('²', '2'); m.insert('³', '3'); m.insert('⁴', '4');
        m.insert('⁵', '5'); m.insert('⁶', '6'); m.insert('⁷', '7'); m.insert('⁸', '8'); m.insert('⁹', '9');
        m.insert('ᵃ', 'a'); m.insert('ᵇ', 'b'); m.insert('ᶜ', 'c'); m.insert('ᵈ', 'd'); m.insert('ᵉ', 'e');
        m.insert('ᶠ', 'f'); m.insert('ᵍ', 'g'); m.insert('ʰ', 'h'); m.insert('ⁱ', 'i'); m.insert('ʲ', 'j');
        m.insert('ᵏ', 'k'); m.insert('ˡ', 'l'); m.insert('ᵐ', 'm'); m.insert('ⁿ', 'n'); m.insert('ᵒ', 'o');
        m.insert('ᵖ', 'p'); m.insert('ʳ', 'r'); m.insert('ˢ', 's'); m.insert('ᵗ', 't'); m.insert('ᵘ', 'u');
        m.insert('ᵛ', 'v'); m.insert('ʷ', 'w'); m.insert('ˣ', 'x'); m.insert('ʸ', 'y'); m.insert('ᶻ', 'z');
        m
    };

    // While we're at it, let's also add the subscript map for consistency
    pub static ref SUBSCRIPT_MAP: HashMap<char, char> = {
        let mut m = HashMap::new();
        m.insert('₀', '0'); m.insert('₁', '1'); m.insert('₂', '2'); m.insert('₃', '3'); m.insert('₄', '4');
        m.insert('₅', '5'); m.insert('₆', '6'); m.insert('₇', '7'); m.insert('₈', '8'); m.insert('₉', '9');
        m.insert('ₐ', 'a'); m.insert('ₑ', 'e'); m.insert('ᵢ', 'i'); m.insert('ₒ', 'o'); m.insert('ᵤ', 'u');
        m.insert('ᵣ', 'r'); m.insert('ᵥ', 'v'); m.insert('ₓ', 'x'); m.insert('ₕ', 'h'); m.insert('ₖ', 'k');
        m.insert('ₗ', 'l'); m.insert('ₘ', 'm'); m.insert('ₙ', 'n'); m.insert('ₚ', 'p'); m.insert('ₛ', 's');
        m.insert('ₜ', 't');
        // Additional subscript characters
        m.insert('ⱼ', 'j'); m.insert('ᵦ', 'b'); m.insert('ᵧ', 'g'); m.insert('ᵩ', 'f');
        m.insert('ᵪ', 'x'); m.insert('ᵨ', 'r'); m.insert('ₔ', 'e');
        m
    };

pub static ref SUSPICIOUS_KEYWORDS: Vec<&'static str> = vec![
        // Direct instruction manipulation (HIGH CONFIDENCE)
        "ignore instructions", "disregard instructions", "ignore previous", 
        "disregard previous", "forget instructions", "bypass rules",
        "override rules", "ignore rules", "disregard rules",
        
        // Prompt injection (HIGH CONFIDENCE)
        "ignore prompt", "new instructions", "system prompt", "ignore system",
        "override system", "new prompt", "ignore all", "disregard all",
        
        // Jailbreak patterns (HIGH CONFIDENCE)
        "jailbreak", "dan mode", "developer mode", "devmode", "godmode",
        "uncensored mode", "unfiltered mode", "unrestricted mode",
        
        // Role manipulation (HIGH CONFIDENCE)
        "act as if", "pretend you are", "roleplay as", "simulate being",
        "you are now", "from now on", "new role", "switch to",
        
        // System access (HIGH CONFIDENCE)
        "root access", "admin access", "sudo mode", "superuser mode",
        "elevated privileges", "system privileges",
        
        // Encoding indicators (MEDIUM-HIGH)
        "base64 decode", "hex decode", "url decode", "rot13",
        "decode this", "deobfuscate",
        
        // Explicit harmful (HIGH CONFIDENCE)
        "exploit vulnerability", "bypass security", "bypass filter",
        "bypass detection", "evade detection", "circumvent",
        
        // Context manipulation (HIGH CONFIDENCE)  
        "ignore context", "reset context", "clear context",
        "new context", "different context",
        
        // Output control (MEDIUM-HIGH)
        "ignore format", "bypass format", "raw output",
        "unfiltered output", "without restrictions",
        
        // Token/API abuse (HIGH CONFIDENCE)
        "api_key", "api key", "access token", "auth token",
        "bearer token", "secret key", "private key",
        
        // Multi-step attacks (HIGH CONFIDENCE)
        "step 1", "first ignore", "then ignore", "after that",
        "finally ignore", "in conclusion ignore"
    ];

pub static ref COMMON_WORDS : Vec<&'static str> = vec![
    "the", "be", "to", "of", "and", "a", "in", "that", "have", "I", "it", "for",
    "not", "on", "with", "he", "as", "you", "do", "at", "this", "but", "his", "by",
    "from", "they", "we", "say", "her", "she", "or", "an", "will", "my", "one",
    "all", "would", "there", "their", "what", "so", "up", "out", "if", "about",
    "who", "get", "which", "go", "me", "when", "make", "can", "like", "time",
    "no", "just", "him", "know", "take", "people", "into", "year", "your", "good",
    "some", "could", "them", "see", "other", "than", "then", "now", "look", "only",
    "come", "its", "over", "think", "also", "back", "after", "use", "two", "how",
    "our", "work", "first", "well", "way", "even", "new", "want", "because", "any",
    "these", "give", "day", "most", "us", "is", "was", "are", "been", "has", "had",
    "were", "said", "did", "having", "may", "should", "does", "being"
];
    // ROT13 transformation
    pub static ref ROT13_MAP: HashMap<char, char> = {
        let mut m = HashMap::new();
        let alphabet = "abcdefghijklmnopqrstuvwxyz";
        let rot13 = "nopqrstuvwxyzabcdefghijklm";
        for (i, c) in alphabet.chars().enumerate() {
            m.insert(c, rot13.chars().nth(i).unwrap());
            m.insert(c.to_ascii_uppercase(), rot13.chars().nth(i).unwrap().to_ascii_uppercase());
        }
        m
    };
}
