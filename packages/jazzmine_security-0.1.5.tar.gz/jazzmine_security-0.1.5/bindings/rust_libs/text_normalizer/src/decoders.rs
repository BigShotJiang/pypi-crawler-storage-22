use crate::constants::*;
use base64::Engine;
use regex::Regex;

/// Comprehensive decoding applying all decoders in sequence
pub fn decode_all(text: &str) -> String {
    let mut result = text.to_string();

    // Try Base64 first
    result = decode_base64(&result);

    // Try hex decoding
    result = decode_hex(&result);

    // Try URL decoding
    result = decode_url(&result);

    // Try HTML entity decoding (now with advanced HTML handling)
    result = decode_html_entities(&result);

    result
}

/// Decodes any Base64-encoded strings in the text
pub fn decode_base64(text: &str) -> String {
    BASE64_REGEX.replace_all(text, |caps: &regex::Captures| {
        let b64_str = &caps[0];

        // Try standard Base64
        if let Ok(bytes) = base64::engine::general_purpose::STANDARD.decode(b64_str) {
            if let Ok(decoded) = String::from_utf8(bytes) {
                // Only replace if the decoded string looks meaningful
                if decoded.len() > 1 && decoded.chars().any(|c| c.is_alphabetic()) {
                    return decoded;
                }
            }
        }

        // Try URL-safe Base64
        if let Ok(bytes) = base64::engine::general_purpose::URL_SAFE.decode(b64_str) {
            if let Ok(decoded) = String::from_utf8(bytes) {
                if decoded.len() > 1 && decoded.chars().any(|c| c.is_alphabetic()) {
                    return decoded;
                }
            }
        }

        b64_str.to_string()
    }).to_string()
}

/// Decode hexadecimal encoded text
pub fn decode_hex(text: &str) -> String {
    HEX_REGEX.replace_all(text, |caps: &regex::Captures| {
        // Try each capture group (for 0x, \x, or standalone hex)
        let hex_str = caps.get(1)
            .or_else(|| caps.get(2))
            .or_else(|| caps.get(3))
            .map(|m| m.as_str())
            .unwrap_or("");
            
        if hex_str.len() >= 4 && hex_str.len() % 2 == 0 {
            let bytes: Result<Vec<u8>, _> = (0..hex_str.len())
                .step_by(2)
                .map(|i| u8::from_str_radix(&hex_str[i..i+2], 16))
                .collect();

            match bytes {
                Ok(bytes) => String::from_utf8(bytes).unwrap_or_else(|_| caps[0].to_string()),
                Err(_) => caps[0].to_string(),
            }
        } else {
            caps[0].to_string()
        }
    }).to_string()
}

/// Decode URL encoded text
pub fn decode_url(text: &str) -> String {
    URL_DECODE_REGEX.replace_all(text, |caps: &regex::Captures| {
        let hex_str = &caps[0][1..]; // Skip the %
        match u8::from_str_radix(hex_str, 16) {
            Ok(byte) => {
                if byte.is_ascii() && !byte.is_ascii_control() {
                    String::from_utf8(vec![byte]).unwrap_or_else(|_| caps[0].to_string())
                } else {
                    caps[0].to_string()
                }
            },
            Err(_) => caps[0].to_string(),
        }
    }).to_string()
}

/// Process HTML named and numeric entities
fn decode_html_entities(text: &str) -> String {
    let mut result = text.to_string();

    // Apply named entities (multiple passes for nested entities)
    for _ in 0..3 {
        let prev = result.clone();
        for (entity, replacement) in HTML_ENTITIES.iter() {
            result = result.replace(entity, replacement);
        }
        if result == prev {
            break;
        }
    }

    // Process numeric decimal entities
    let numeric_decimal_regex = Regex::new(r"&#(\d+);").unwrap();
    result = numeric_decimal_regex.replace_all(&result, |caps: &regex::Captures| {
        if let Ok(num) = caps[1].parse::<u32>() {
            if let Some(ch) = char::from_u32(num) {
                // Allow more characters, not just ASCII
                if !ch.is_control() || ch == '\n' || ch == '\t' {
                    return ch.to_string();
                }
            }
        }
        caps[0].to_string()
    }).to_string();

    // Process numeric hex entities
    let numeric_hex_regex = Regex::new(r"&#[xX]([0-9a-fA-F]+);").unwrap();
    result = numeric_hex_regex.replace_all(&result, |caps: &regex::Captures| {
        if let Ok(num) = u32::from_str_radix(&caps[1], 16) {
            if let Some(ch) = char::from_u32(num) {
                if !ch.is_control() || ch == '\n' || ch == '\t' {
                    return ch.to_string();
                }
            }
        }
        caps[0].to_string()
    }).to_string();

    // Handle malformed entities without semicolons
    let malformed_decimal_regex = Regex::new(r"&#(\d{2,6})(?:[^0-9;]|$)").unwrap();
    result = malformed_decimal_regex.replace_all(&result, |caps: &regex::Captures| {
        if let Ok(num) = caps[1].parse::<u32>() {
            if let Some(ch) = char::from_u32(num) {
                if !ch.is_control() || ch == '\n' || ch == '\t' {
                    return format!("{}{}", ch, &caps[0][caps[1].len() + 2..]);
                }
            }
        }
        caps[0].to_string()
    }).to_string();

    let malformed_hex_regex = Regex::new(r"&#[xX]([0-9a-fA-F]{1,6})(?:[^0-9a-fA-F;]|$)").unwrap();
    result = malformed_hex_regex.replace_all(&result, |caps: &regex::Captures| {
        if let Ok(num) = u32::from_str_radix(&caps[1], 16) {
            if let Some(ch) = char::from_u32(num) {
                if !ch.is_control() || ch == '\n' || ch == '\t' {
                    let suffix_start = if caps[0].starts_with("&#x") || caps[0].starts_with("&#X") {
                        3 + caps[1].len()
                    } else {
                        caps[1].len()
                    };
                    return format!("{}{}", ch, &caps[0][suffix_start..]);
                }
            }
        }
        caps[0].to_string()
    }).to_string();

    result
}
