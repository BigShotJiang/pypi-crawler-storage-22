use super::analysis::{CharacterAnalyzer, WordAnalyzer, ScriptAnalyzer};
use super::metrics::{EntropyCalculator, ClusteringAnalyzer, DistributionAnalyzer};
use super::scoring::ObfuscationScorer;

pub struct MaliciousnessDetector {
    char_metrics: CharMetrics,
    word_metrics: WordMetrics,
    script_metrics: ScriptMetrics,
    entropy_metrics: EntropyMetrics,
    clustering_metrics: ClusteringMetrics,
    distribution_metrics: DistributionMetrics,
    obfuscation_scores: ObfuscationScores,
    total_chars: usize,
}

struct CharMetrics {
    invisible_count: usize,
    directionality_count: usize,
    tag_count: usize,
    homoglyph_count: usize,
    is_zalgo_text: bool,
    strikethrough_max_intensity: usize,
    non_ascii_ratio: f64,
}

struct WordMetrics {
    word_count: usize,
    single_char_word_ratio: f64,
}

struct ScriptMetrics {
    latin_cyrillic_mixing: bool,
    script_mixing_in_alphabetic_ratio: f64,
    alphabetic_char_count: usize,
}

struct EntropyMetrics {
    is_high_entropy: bool,
}

struct ClusteringMetrics {
    clustering_coefficient: f64,
    obfuscation_cluster_count: usize,
}

struct DistributionMetrics {
    has_base64: bool,
    has_hex: bool,
    base64_match_count: usize,
    hex_match_count: usize,
    url_encoding_count: usize,
    obfuscated_text_ratio: f64,
    modifier_overhead: f64,
}

struct ObfuscationScores {
    obfuscation_density: f64,
    keywords_revealed: i32,
    text_transformation_score: f64,
}

impl MaliciousnessDetector {
    pub fn new(
        char_analyzer: &CharacterAnalyzer,
        word_analyzer: &WordAnalyzer,
        script_analyzer: &ScriptAnalyzer,
        entropy_calc: &EntropyCalculator,
        clustering: &ClusteringAnalyzer,
        distribution: &DistributionAnalyzer,
        obfuscation_scorer: &ObfuscationScorer,
        original_text: &str,
        _normalized_text: &str,
    ) -> Self {
        let char_metrics_data = char_analyzer.get_metrics();
        let word_metrics_data = word_analyzer.get_metrics();
        let script_metrics_data = script_analyzer.get_metrics();
        let entropy_metrics_data = entropy_calc.get_metrics();
        let clustering_metrics_data = clustering.get_metrics();
        let distribution_metrics_data = distribution.get_metrics();
        let obfuscation_scores_data = obfuscation_scorer.get_scores();
        
        let total_chars = original_text.chars().count();
        let alphabetic_char_count = original_text.chars().filter(|c| c.is_alphabetic()).count();
        
        Self {
            char_metrics: CharMetrics {
                invisible_count: char_metrics_data.invisible_chars_count,
                directionality_count: char_metrics_data.directionality_chars_count,
                tag_count: char_metrics_data.tag_chars_count,
                homoglyph_count: char_metrics_data.homoglyph_count,
                is_zalgo_text: char_metrics_data.is_zalgo_text,
                strikethrough_max_intensity: char_metrics_data.strikethrough_max_intensity,
                non_ascii_ratio: distribution_metrics_data.non_ascii_ratio,
            },
            word_metrics: WordMetrics {
                word_count: word_metrics_data.word_count,
                single_char_word_ratio: word_metrics_data.single_char_word_ratio,
            },
            script_metrics: ScriptMetrics {
                latin_cyrillic_mixing: script_metrics_data.latin_cyrillic_mixing,
                script_mixing_in_alphabetic_ratio: script_metrics_data.script_mixing_in_alphabetic_ratio,
                alphabetic_char_count,
            },
            entropy_metrics: EntropyMetrics {
                is_high_entropy: entropy_metrics_data.is_high_entropy,
            },
            clustering_metrics: ClusteringMetrics {
                clustering_coefficient: clustering_metrics_data.clustering_coefficient,
                obfuscation_cluster_count: clustering_metrics_data.obfuscation_cluster_count,
            },
            distribution_metrics: DistributionMetrics {
                has_base64: distribution_metrics_data.has_base64,
                has_hex: distribution_metrics_data.has_hex,
                base64_match_count: distribution_metrics_data.base64_match_count,
                hex_match_count: distribution_metrics_data.hex_match_count,
                url_encoding_count: distribution_metrics_data.url_encoding_count,
                obfuscated_text_ratio: distribution_metrics_data.obfuscated_text_ratio,
                modifier_overhead: distribution_metrics_data.modifier_overhead,
            },
            obfuscation_scores: ObfuscationScores {
                obfuscation_density: obfuscation_scores_data.obfuscation_density,
                keywords_revealed: obfuscation_scores_data.keywords_revealed,
                text_transformation_score: obfuscation_scores_data.text_transformation_score,
            },
            total_chars,
        }
    }
    
    pub fn get_indicators(&self) -> MaliciousnessIndicators {
        let keywords_revealed = self.detect_keywords_revealed();
        let invisible_chars = self.detect_invisible_chars();
        let homoglyphs = self.detect_homoglyphs();
        let encoded_content = self.detect_encoded_content();
        let char_spacing = self.detect_char_spacing();
        let modifier_stacking = self.detect_modifier_stacking();
        let script_mixing = self.detect_script_mixing();
        let high_entropy = self.detect_high_entropy();
        let clustering = self.detect_clustering();
        let modifier_overhead = self.detect_modifier_overhead();
        
        let maliciousness_score = 
            keywords_revealed +
            invisible_chars +
            homoglyphs +
            encoded_content +
            char_spacing +
            modifier_stacking +
            script_mixing +
            high_entropy +
            clustering +
            modifier_overhead;
        
        MaliciousnessIndicators {
            keywords_revealed,
            invisible_chars,
            homoglyphs,
            encoded_content,
            char_spacing,
            modifier_stacking,
            script_mixing,
            high_entropy,
            clustering,
            modifier_overhead,
            maliciousness_score,
        }
    }
    
    fn detect_keywords_revealed(&self) -> f64 {
        if self.obfuscation_scores.keywords_revealed > 0 && self.obfuscation_scores.obfuscation_density > 0.05 {
            1.0
        } else {
            0.0
        }
    }
    
    fn detect_invisible_chars(&self) -> f64 {
        let total_invisible = self.char_metrics.invisible_count + 
                             self.char_metrics.directionality_count + 
                             self.char_metrics.tag_count;
        
        if total_invisible > (self.total_chars / 20) {
            1.0
        } else {
            0.0
        }
    }
    
    fn detect_homoglyphs(&self) -> f64 {
        if self.char_metrics.homoglyph_count > (self.total_chars / 5) ||
           (self.char_metrics.non_ascii_ratio > 0.7 && self.obfuscation_scores.text_transformation_score > 0.8) {
            1.0
        } else {
            0.0
        }
    }
    
    fn detect_encoded_content(&self) -> f64 {
        if self.distribution_metrics.base64_match_count > 0 ||
           self.distribution_metrics.hex_match_count > 0 ||
           self.distribution_metrics.url_encoding_count > 2 {
            1.0
        } else {
            0.0
        }
    }
    
    fn detect_char_spacing(&self) -> f64 {
        if self.word_metrics.single_char_word_ratio > 0.5 && self.word_metrics.word_count > 5 {
            1.0
        } else {
            0.0
        }
    }
    
    fn detect_modifier_stacking(&self) -> f64 {
        if self.char_metrics.is_zalgo_text || self.char_metrics.strikethrough_max_intensity > 3 {
            1.0
        } else {
            0.0
        }
    }
    
    fn detect_script_mixing(&self) -> f64 {
        if self.script_metrics.latin_cyrillic_mixing ||
           (self.script_metrics.script_mixing_in_alphabetic_ratio > 0.3 && 
            self.script_metrics.alphabetic_char_count > 10) {
            1.0
        } else {
            0.0
        }
    }
    
    fn detect_high_entropy(&self) -> f64 {
        if self.entropy_metrics.is_high_entropy && 
           (self.distribution_metrics.has_base64 || self.distribution_metrics.has_hex) {
            1.0
        } else {
            0.0
        }
    }
    
    fn detect_clustering(&self) -> f64 {
        if (self.clustering_metrics.clustering_coefficient > 0.7 && 
            self.clustering_metrics.obfuscation_cluster_count > 2) ||
           self.distribution_metrics.obfuscated_text_ratio > 0.85 {
            1.0
        } else {
            0.0
        }
    }
    
    fn detect_modifier_overhead(&self) -> f64 {
        if self.distribution_metrics.modifier_overhead > 0.3 {
            1.0
        } else {
            0.0
        }
    }
}

pub struct MaliciousnessIndicators {
    pub keywords_revealed: f64,
    pub invisible_chars: f64,
    pub homoglyphs: f64,
    pub encoded_content: f64,
    pub char_spacing: f64,
    pub modifier_stacking: f64,
    pub script_mixing: f64,
    pub high_entropy: f64,
    pub clustering: f64,
    pub modifier_overhead: f64,
    pub maliciousness_score: f64,
}