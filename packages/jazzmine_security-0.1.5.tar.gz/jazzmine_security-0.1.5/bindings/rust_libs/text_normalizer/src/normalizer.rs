use std::collections::HashSet;
use pyo3::prelude::*;
use pyo3::types::PyDict;
use crate::{transformers, decoders};
use crate::analysis::{CharacterAnalyzer, WordAnalyzer, ScriptAnalyzer};
use crate::metrics::{EntropyCalculator, ClusteringAnalyzer, DistributionAnalyzer};
use crate::indicators::MaliciousnessDetector;
use crate::scoring::ObfuscationScorer;

#[pyclass]
pub struct TextNormalizer {
    max_iterations: usize,
}

#[pymethods]
impl TextNormalizer {
    #[new]
    pub fn new() -> Self {
        TextNormalizer {
            max_iterations: 20,
        }
    }

    #[pyo3(signature = (prompt, max_passes=None))]
    pub fn normalize(&self, prompt: &str, max_passes: Option<usize>) -> String {
        let max_passes = max_passes.unwrap_or(self.max_iterations);
        let mut normalized = prompt.to_string();
        let mut seen_states = HashSet::new();

        for pass in 0..max_passes {
            let previous_state = normalized.clone();

            if seen_states.contains(&normalized) {
                break;
            }
            seen_states.insert(previous_state.clone());

            normalized = self.apply_normalization_pipeline(normalized);

            if normalized == previous_state {
                break;
            }

            if pass > 2 && self.has_converged(&previous_state, &normalized) {
                break;
            }
        }

        normalized
    }

    #[pyo3(signature = (prompt, max_passes=None))]
    pub fn normalize_with_stats<'py>(
        &self,
        py: Python<'py>,
        prompt: &str,
        max_passes: Option<usize>
    ) -> PyResult<Bound<'py, PyDict>> {
        if prompt.is_empty() {
            return self.create_empty_stats(py);
        }

        let normalized = self.normalize(prompt, max_passes);
        let stats = self.analyze_text(prompt, &normalized);
        
        self.build_result_dict(py, prompt, &normalized, stats)
    }
}

impl TextNormalizer {
    fn apply_normalization_pipeline(&self, text: String) -> String {
        let mut normalized = text;

        normalized = transformers::remove_tag_characters(&normalized);
        normalized = transformers::remove_directionality_overrides(&normalized);
        normalized = transformers::normalize_flipped_text(&normalized);
        normalized = decoders::decode_all(&normalized);
        normalized = transformers::remove_invisible_chars(&normalized);
        normalized = transformers::remove_strikethrough(&normalized);
        normalized = transformers::normalize_super_subscripts(&normalized);
        normalized = transformers::replace_homoglyphs(&normalized);
        normalized = transformers::normalize_unicode_comprehensive(&normalized);
        normalized = transformers::strip_diacritics(&normalized);
        normalized = transformers::try_rot13(&normalized);
        normalized = transformers::try_atbash(&normalized);
        normalized = transformers::try_caesar_shifts(&normalized);
        normalized = transformers::replace_leetspeak(&normalized);
        normalized = transformers::replace_emojis_with_text(&normalized);
        normalized = transformers::standardize_spacing(&normalized);

        normalized.to_lowercase().trim().to_string()
    }

    fn has_converged(&self, previous: &str, current: &str) -> bool {
        let similarity = transformers::calculate_similarity(previous, current);
        similarity > 0.98
    }

    fn analyze_text(&self, prompt: &str, normalized: &str) -> TextStats {
        let chars: Vec<char> = prompt.chars().collect();
        
        let char_analyzer = CharacterAnalyzer::new(&chars);
        
        let mut word_analyzer = WordAnalyzer::new(prompt);
        let obfuscation_positions = char_analyzer.get_obfuscation_positions();
        word_analyzer.mark_obfuscated_words(&obfuscation_positions);
        
        let mut script_analyzer = ScriptAnalyzer::new(&chars);
        script_analyzer.analyze_words(word_analyzer.get_words());
        
        let entropy_calc = EntropyCalculator::new(&chars);
        let clustering = ClusteringAnalyzer::new(&char_analyzer, &word_analyzer);
        let distribution = DistributionAnalyzer::new(prompt);
        
        let char_metrics = char_analyzer.get_metrics();
        let clean_metrics = distribution.calculate_clean_text_metrics(
            char_metrics.invisible_chars_count,
            char_metrics.directionality_chars_count,
            char_metrics.tag_chars_count,
            char_metrics.homoglyph_count,
            char_metrics.flipped_chars_count,
            char_metrics.strikethrough_affected_chars,
            char_metrics.combining_marks_affected_chars,
            char_metrics.strikethrough_modifier_count,
            char_metrics.combining_marks_modifier_count,
        );
        
        let mut obfuscation_scorer = ObfuscationScorer::new(
            &char_analyzer,
            &word_analyzer,
            &script_analyzer,
            &distribution
        );
        obfuscation_scorer.set_texts(prompt, normalized);
        
        let maliciousness = MaliciousnessDetector::new(
            &char_analyzer,
            &word_analyzer,
            &script_analyzer,
            &entropy_calc,
            &clustering,
            &distribution,
            &obfuscation_scorer,
            prompt,
            normalized
        );

        TextStats {
            char_analyzer,
            word_analyzer,
            script_analyzer,
            entropy_calc,
            clustering,
            distribution,
            obfuscation_scorer,
            maliciousness,
            clean_metrics,
        }
    }

    fn build_result_dict<'py>(
        &self,
        py: Python<'py>,
        prompt: &str,
        normalized: &str,
        stats: TextStats
    ) -> PyResult<Bound<'py, PyDict>> {
        let result = PyDict::new_bound(py);
        
        self.set_core_outputs(py, &result, prompt, normalized)?;
        self.set_character_metrics(py, &result, &stats)?;
        self.set_word_metrics(py, &result, &stats)?;
        self.set_script_metrics(py, &result, &stats)?;
        self.set_entropy_metrics(py, &result, &stats)?;
        self.set_clustering_metrics(py, &result, &stats)?;
        self.set_distribution_metrics(py, &result, &stats)?;
        self.set_obfuscation_scores(py, &result, &stats)?;
        self.set_maliciousness_indicators(py, &result, &stats)?;
        
        Ok(result)
    }

    fn create_empty_stats<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyDict>> {
        let result = PyDict::new_bound(py);
        
        result.set_item("normalized_prompt", "")?;
        result.set_item("original_prompt", "")?;
        result.set_item("original_length", 0)?;
        result.set_item("normalized_length", 0)?;
        result.set_item("original_bytes", 0)?;
        result.set_item("length_reduction", 0)?;
        result.set_item("length_reduction_ratio", 0.0)?;
        result.set_item("maliciousness_score", 0.0)?;
        result.set_item("obfuscation_density", 0.0)?;
        result.set_item("obfuscated_text_ratio", 0.0)?;
        result.set_item("clean_text_ratio", 1.0)?;
        
        self.set_zero_metrics(&result)?;
        
        Ok(result)
    }

    fn set_zero_metrics(&self, result: &Bound<PyDict>) -> PyResult<()> {
        let zero_int_metrics = vec![
            "homoglyph_count", "invisible_chars_count", "strikethrough_affected_chars",
            "combining_marks_affected_chars", "zalgo_char_count", "words_with_script_mixing",
            "unique_scripts", "obfuscation_cluster_count"
        ];
        
        let zero_float_metrics = vec![
            "homoglyph_ratio", "invisible_char_ratio", "strikethrough_avg_intensity",
            "combining_marks_avg_intensity", "clustering_coefficient", "normalized_entropy"
        ];
        
        let zero_bool_metrics = vec![
            "has_base64", "has_hex", "has_url_encoding", "is_zalgo_text", "is_high_entropy"
        ];
        
        for metric in zero_int_metrics {
            result.set_item(metric, 0)?;
        }
        
        for metric in zero_float_metrics {
            result.set_item(metric, 0.0)?;
        }
        
        for metric in zero_bool_metrics {
            result.set_item(metric, false)?;
        }
        
        let malicious_indicators = vec![
            "malicious_indicator_keywords_revealed", "malicious_indicator_invisible_chars",
            "malicious_indicator_homoglyphs", "malicious_indicator_encoded_content",
            "malicious_indicator_char_spacing", "malicious_indicator_modifier_stacking",
            "malicious_indicator_script_mixing", "malicious_indicator_high_entropy",
            "malicious_indicator_clustering", "malicious_indicator_modifier_overhead"
        ];
        
        for indicator in malicious_indicators {
            result.set_item(indicator, 0.0)?;
        }
        
        Ok(())
    }

    fn set_core_outputs(
        &self,
        _py: Python,
        result: &Bound<PyDict>,
        prompt: &str,
        normalized: &str
    ) -> PyResult<()> {
        let total_chars = prompt.chars().count();
        let normalized_chars = normalized.chars().count();
        let total_bytes = prompt.len();
        let length_reduction = total_chars as i64 - normalized_chars as i64;
        let length_reduction_ratio = if total_chars > 0 {
            length_reduction as f64 / total_chars as f64
        } else {
            0.0
        };

        result.set_item("normalized_prompt", normalized)?;
        result.set_item("original_prompt", prompt)?;
        result.set_item("original_length", total_chars)?;
        result.set_item("normalized_length", normalized_chars)?;
        result.set_item("original_bytes", total_bytes)?;
        result.set_item("length_reduction", length_reduction)?;
        result.set_item("length_reduction_ratio", length_reduction_ratio)?;

        Ok(())
    }

    fn set_character_metrics(
        &self,
        _py: Python,
        result: &Bound<PyDict>,
        stats: &TextStats
    ) -> PyResult<()> {
        let metrics = stats.char_analyzer.get_metrics();
        
        result.set_item("invisible_chars_count", metrics.invisible_chars_count)?;
        result.set_item("invisible_char_ratio", metrics.invisible_char_ratio)?;
        result.set_item("directionality_chars_count", metrics.directionality_chars_count)?;
        result.set_item("directionality_char_ratio", metrics.directionality_char_ratio)?;
        result.set_item("tag_chars_count", metrics.tag_chars_count)?;
        result.set_item("tag_char_ratio", metrics.tag_char_ratio)?;
        result.set_item("homoglyph_count", metrics.homoglyph_count)?;
        result.set_item("homoglyph_ratio", metrics.homoglyph_ratio)?;
        result.set_item("flipped_chars_count", metrics.flipped_chars_count)?;
        result.set_item("flipped_char_ratio", metrics.flipped_char_ratio)?;
        result.set_item("leetspeak_count", metrics.leetspeak_count)?;
        result.set_item("leetspeak_ratio", metrics.leetspeak_ratio)?;
        result.set_item("emoji_count", metrics.emoji_count)?;
        result.set_item("emoji_ratio", metrics.emoji_ratio)?;
        
        result.set_item("strikethrough_modifier_count", metrics.strikethrough_modifier_count)?;
        result.set_item("strikethrough_affected_chars", metrics.strikethrough_affected_chars)?;
        result.set_item("strikethrough_affected_ratio", metrics.strikethrough_affected_ratio)?;
        result.set_item("strikethrough_avg_intensity", metrics.strikethrough_avg_intensity)?;
        result.set_item("strikethrough_max_intensity", metrics.strikethrough_max_intensity)?;
        
        result.set_item("combining_marks_modifier_count", metrics.combining_marks_modifier_count)?;
        result.set_item("combining_marks_affected_chars", metrics.combining_marks_affected_chars)?;
        result.set_item("combining_marks_affected_ratio", metrics.combining_marks_affected_ratio)?;
        result.set_item("combining_marks_avg_intensity", metrics.combining_marks_avg_intensity)?;
        result.set_item("combining_marks_max_intensity", metrics.combining_marks_max_intensity)?;
        result.set_item("is_zalgo_text", metrics.is_zalgo_text)?;
        result.set_item("zalgo_char_count", metrics.zalgo_char_count)?;
        
        result.set_item("superscript_count", metrics.superscript_count)?;
        result.set_item("subscript_count", metrics.subscript_count)?;
        result.set_item("super_sub_script_ratio", metrics.super_sub_script_ratio)?;

        Ok(())
    }

    fn set_word_metrics(
        &self,
        _py: Python,
        result: &Bound<PyDict>,
        stats: &TextStats
    ) -> PyResult<()> {
        let metrics = stats.word_analyzer.get_metrics();
        
        result.set_item("word_count", metrics.word_count)?;
        result.set_item("avg_word_length", metrics.avg_word_length)?;
        result.set_item("single_char_words", metrics.single_char_words)?;
        result.set_item("single_char_word_ratio", metrics.single_char_word_ratio)?;
        result.set_item("obfuscated_word_count", metrics.obfuscated_word_count)?;
        result.set_item("obfuscated_word_ratio", metrics.obfuscated_word_ratio)?;

        Ok(())
    }

    fn set_script_metrics(
        &self,
        _py: Python,
        result: &Bound<PyDict>,
        stats: &TextStats
    ) -> PyResult<()> {
        let metrics = stats.script_analyzer.get_metrics();
        
        result.set_item("unique_scripts", metrics.unique_scripts)?;
        result.set_item("script_mixing_ratio", metrics.script_mixing_ratio)?;
        result.set_item("script_mixing_in_alphabetic_ratio", metrics.script_mixing_in_alphabetic_ratio)?;
        result.set_item("words_with_script_mixing", metrics.words_with_script_mixing)?;
        result.set_item("max_scripts_in_word", metrics.max_scripts_in_word)?;
        result.set_item("has_latin", metrics.has_latin)?;
        result.set_item("has_cyrillic", metrics.has_cyrillic)?;
        result.set_item("has_greek", metrics.has_greek)?;
        result.set_item("latin_cyrillic_mixing", metrics.latin_cyrillic_mixing)?;
        result.set_item("latin_greek_mixing", metrics.latin_greek_mixing)?;

        Ok(())
    }

    fn set_entropy_metrics(
        &self,
        _py: Python,
        result: &Bound<PyDict>,
        stats: &TextStats
    ) -> PyResult<()> {
        let metrics = stats.entropy_calc.get_metrics();
        
        result.set_item("entropy", metrics.entropy)?;
        result.set_item("normalized_entropy", metrics.normalized_entropy)?;
        result.set_item("is_high_entropy", metrics.is_high_entropy)?;

        Ok(())
    }

    fn set_clustering_metrics(
        &self,
        _py: Python,
        result: &Bound<PyDict>,
        stats: &TextStats
    ) -> PyResult<()> {
        let metrics = stats.clustering.get_metrics();
        
        result.set_item("obfuscation_cluster_count", metrics.obfuscation_cluster_count)?;
        result.set_item("max_obfuscation_cluster_size", metrics.max_obfuscation_cluster_size)?;
        result.set_item("avg_obfuscation_cluster_size", metrics.avg_obfuscation_cluster_size)?;
        result.set_item("clustering_coefficient", metrics.clustering_coefficient)?;

        Ok(())
    }

    fn set_distribution_metrics(
        &self,
        _py: Python,
        result: &Bound<PyDict>,
        stats: &TextStats
    ) -> PyResult<()> {
        let mut metrics = stats.distribution.get_metrics();
        
        metrics.clean_char_count = stats.clean_metrics.0;
        metrics.clean_text_ratio = stats.clean_metrics.1;
        metrics.obfuscated_char_count = stats.clean_metrics.2;
        metrics.obfuscated_text_ratio = stats.clean_metrics.3;
        metrics.total_modifiers = stats.clean_metrics.4;
        metrics.base_chars = stats.clean_metrics.5;
        metrics.modifier_overhead = stats.clean_metrics.6;
        
        result.set_item("non_ascii_count", metrics.non_ascii_count)?;
        result.set_item("non_ascii_ratio", metrics.non_ascii_ratio)?;
        result.set_item("ascii_printable_count", metrics.ascii_printable_count)?;
        result.set_item("ascii_control_count", metrics.ascii_control_count)?;
        result.set_item("whitespace_count", metrics.whitespace_count)?;
        result.set_item("punctuation_count", metrics.punctuation_count)?;
        result.set_item("digit_count", metrics.digit_count)?;
        result.set_item("alpha_count", metrics.alpha_count)?;
        result.set_item("unique_char_count", metrics.unique_char_count)?;
        result.set_item("char_repetition_ratio", metrics.char_repetition_ratio)?;
        
        result.set_item("has_base64", metrics.has_base64)?;
        result.set_item("base64_match_count", metrics.base64_match_count)?;
        result.set_item("base64_char_count", metrics.base64_char_count)?;
        result.set_item("has_hex", metrics.has_hex)?;
        result.set_item("hex_match_count", metrics.hex_match_count)?;
        result.set_item("hex_char_count", metrics.hex_char_count)?;
        result.set_item("has_url_encoding", metrics.has_url_encoding)?;
        result.set_item("url_encoding_count", metrics.url_encoding_count)?;
        result.set_item("encoding_char_ratio", metrics.encoding_char_ratio)?;
        
        result.set_item("clean_char_count", metrics.clean_char_count)?;
        result.set_item("clean_text_ratio", metrics.clean_text_ratio)?;
        result.set_item("obfuscated_char_count", metrics.obfuscated_char_count)?;
        result.set_item("obfuscated_text_ratio", metrics.obfuscated_text_ratio)?;
        result.set_item("total_modifiers", metrics.total_modifiers)?;
        result.set_item("base_chars", metrics.base_chars)?;
        result.set_item("modifier_overhead", metrics.modifier_overhead)?;

        Ok(())
    }

    fn set_obfuscation_scores(
        &self,
        _py: Python,
        result: &Bound<PyDict>,
        stats: &TextStats
    ) -> PyResult<()> {
        let scores = stats.obfuscation_scorer.get_scores();
        
        result.set_item("high_suspicion_score", scores.high_suspicion_score)?;
        result.set_item("medium_suspicion_score", scores.medium_suspicion_score)?;
        result.set_item("low_suspicion_score", scores.low_suspicion_score)?;
        result.set_item("total_obfuscation_score", scores.total_obfuscation_score)?;
        result.set_item("obfuscation_density", scores.obfuscation_density)?;
        result.set_item("text_similarity", scores.text_similarity)?;
        result.set_item("text_transformation_score", scores.text_transformation_score)?;
        
        result.set_item("suspicious_keyword_count_original", scores.suspicious_keyword_count_original)?;
        result.set_item("suspicious_keyword_count_normalized", scores.suspicious_keyword_count_normalized)?;
        result.set_item("keywords_revealed", scores.keywords_revealed)?;

        Ok(())
    }

    fn set_maliciousness_indicators(
        &self,
        _py: Python,
        result: &Bound<PyDict>,
        stats: &TextStats
    ) -> PyResult<()> {
        let indicators = stats.maliciousness.get_indicators();
        
        result.set_item("malicious_indicator_keywords_revealed", indicators.keywords_revealed)?;
        result.set_item("malicious_indicator_invisible_chars", indicators.invisible_chars)?;
        result.set_item("malicious_indicator_homoglyphs", indicators.homoglyphs)?;
        result.set_item("malicious_indicator_encoded_content", indicators.encoded_content)?;
        result.set_item("malicious_indicator_char_spacing", indicators.char_spacing)?;
        result.set_item("malicious_indicator_modifier_stacking", indicators.modifier_stacking)?;
        result.set_item("malicious_indicator_script_mixing", indicators.script_mixing)?;
        result.set_item("malicious_indicator_high_entropy", indicators.high_entropy)?;
        result.set_item("malicious_indicator_clustering", indicators.clustering)?;
        result.set_item("malicious_indicator_modifier_overhead", indicators.modifier_overhead)?;
        result.set_item("maliciousness_score", indicators.maliciousness_score)?;

        Ok(())
    }
}

impl Default for TextNormalizer {
    fn default() -> Self {
        Self::new()
    }
}

struct TextStats {
    char_analyzer: CharacterAnalyzer,
    word_analyzer: WordAnalyzer,
    script_analyzer: ScriptAnalyzer,
    entropy_calc: EntropyCalculator,
    clustering: ClusteringAnalyzer,
    distribution: DistributionAnalyzer,
    obfuscation_scorer: ObfuscationScorer,
    maliciousness: MaliciousnessDetector,
    clean_metrics: (usize, f64, usize, f64, usize, usize, f64),
}