use crate::{transformers, constants::SUSPICIOUS_KEYWORDS};
use super::analysis::{CharacterAnalyzer, WordAnalyzer, ScriptAnalyzer};
use super::metrics::DistributionAnalyzer;

pub struct ObfuscationScorer {
    char_metrics: CharacterMetrics,
    word_metrics: WordMetrics,
    script_metrics: ScriptMetrics,
    distribution_metrics: DistributionMetrics,
    original_text: String,
    normalized_text: String,
}

struct CharacterMetrics {
    invisible_count: usize,
    directionality_count: usize,
    tag_count: usize,
    homoglyph_count: usize,
    flipped_count: usize,
    combining_marks_affected: usize,
    strikethrough_affected: usize,
    zalgo_count: usize,
    leetspeak_count: usize,
    superscript_count: usize,
    subscript_count: usize,
    base64_char_count: usize,
    hex_char_count: usize,
    url_encoding_count: usize,
}

struct WordMetrics {
    words_with_script_mixing: usize,
}

struct ScriptMetrics {}

struct DistributionMetrics {}

impl ObfuscationScorer {
    pub fn new(
        char_analyzer: &CharacterAnalyzer,
        _word_analyzer: &WordAnalyzer,
        script_analyzer: &ScriptAnalyzer,
        distribution: &DistributionAnalyzer,
    ) -> Self {
        let char_metrics_data = char_analyzer.get_metrics();
        let script_metrics_data = script_analyzer.get_metrics();
        let distribution_metrics_data = distribution.get_metrics();
        
        Self {
            char_metrics: CharacterMetrics {
                invisible_count: char_metrics_data.invisible_chars_count,
                directionality_count: char_metrics_data.directionality_chars_count,
                tag_count: char_metrics_data.tag_chars_count,
                homoglyph_count: char_metrics_data.homoglyph_count,
                flipped_count: char_metrics_data.flipped_chars_count,
                combining_marks_affected: char_metrics_data.combining_marks_affected_chars,
                strikethrough_affected: char_metrics_data.strikethrough_affected_chars,
                zalgo_count: char_metrics_data.zalgo_char_count,
                leetspeak_count: char_metrics_data.leetspeak_count,
                superscript_count: char_metrics_data.superscript_count,
                subscript_count: char_metrics_data.subscript_count,
                base64_char_count: distribution_metrics_data.base64_char_count,
                hex_char_count: distribution_metrics_data.hex_char_count,
                url_encoding_count: distribution_metrics_data.url_encoding_count,
            },
            word_metrics: WordMetrics {
                words_with_script_mixing: script_metrics_data.words_with_script_mixing,
            },
            script_metrics: ScriptMetrics {},
            distribution_metrics: DistributionMetrics {},
            original_text: String::new(),
            normalized_text: String::new(),
        }
    }
    
    pub fn set_texts(&mut self, original: &str, normalized: &str) {
        self.original_text = original.to_string();
        self.normalized_text = normalized.to_string();
    }
    
    pub fn get_scores(&self) -> ObfuscationScores {
        let keyword_metrics = self.analyze_keywords();
        
        let high_suspicion_score = 
            (self.char_metrics.invisible_count as f64 * 3.0) +
            (self.char_metrics.directionality_count as f64 * 3.0) +
            (self.char_metrics.tag_count as f64 * 3.0) +
            (self.char_metrics.homoglyph_count as f64 * 2.5) +
            (self.char_metrics.base64_char_count as f64 * 0.1) +
            (self.char_metrics.hex_char_count as f64 * 0.1) +
            (keyword_metrics.keywords_revealed.max(0) as f64 * 5.0) +
            (self.char_metrics.zalgo_count as f64 * 4.0);
        
        let medium_suspicion_score = 
            (self.char_metrics.flipped_count as f64 * 1.5) +
            (self.char_metrics.combining_marks_affected as f64 * 1.0) +
            (self.char_metrics.leetspeak_count as f64 * 1.0) +
            (self.char_metrics.strikethrough_affected as f64 * 1.5) +
            (self.char_metrics.url_encoding_count as f64 * 1.5) +
            (self.word_metrics.words_with_script_mixing as f64 * 2.0);
        
        let low_suspicion_score = 
            (self.char_metrics.superscript_count as f64 * 0.5) +
            (self.char_metrics.subscript_count as f64 * 0.5);
        
        let total_obfuscation_score = high_suspicion_score + medium_suspicion_score + low_suspicion_score;
        
        let total_chars = self.original_text.chars().count();
        let obfuscation_density = if total_chars > 0 {
            total_obfuscation_score / total_chars as f64
        } else {
            0.0
        };
        
        let text_similarity = transformers::calculate_similarity(&self.original_text, &self.normalized_text);
        let text_transformation_score = 1.0 - text_similarity;
        
        ObfuscationScores {
            high_suspicion_score,
            medium_suspicion_score,
            low_suspicion_score,
            total_obfuscation_score,
            obfuscation_density,
            text_similarity,
            text_transformation_score,
            suspicious_keyword_count_original: keyword_metrics.original_count,
            suspicious_keyword_count_normalized: keyword_metrics.normalized_count,
            keywords_revealed: keyword_metrics.keywords_revealed,
        }
    }
    
    fn analyze_keywords(&self) -> KeywordMetrics {
        let lowercase_original = self.original_text.to_lowercase();
        let lowercase_normalized = self.normalized_text.to_lowercase();
        
        let original_count = SUSPICIOUS_KEYWORDS.iter()
            .filter(|&&keyword| lowercase_original.contains(keyword))
            .count();
        
        let normalized_count = SUSPICIOUS_KEYWORDS.iter()
            .filter(|&&keyword| lowercase_normalized.contains(keyword))
            .count();
        
        let keywords_revealed = normalized_count as i32 - original_count as i32;
        
        KeywordMetrics {
            original_count,
            normalized_count,
            keywords_revealed,
        }
    }
}

struct KeywordMetrics {
    original_count: usize,
    normalized_count: usize,
    keywords_revealed: i32,
}

pub struct ObfuscationScores {
    pub high_suspicion_score: f64,
    pub medium_suspicion_score: f64,
    pub low_suspicion_score: f64,
    pub total_obfuscation_score: f64,
    pub obfuscation_density: f64,
    pub text_similarity: f64,
    pub text_transformation_score: f64,
    pub suspicious_keyword_count_original: usize,
    pub suspicious_keyword_count_normalized: usize,
    pub keywords_revealed: i32,
}