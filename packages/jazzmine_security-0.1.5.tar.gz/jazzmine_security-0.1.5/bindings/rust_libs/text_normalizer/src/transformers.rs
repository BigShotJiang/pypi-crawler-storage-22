use crate::constants::*;
use unicode_normalization::UnicodeNormalization;
use unicode_normalization::char::is_combining_mark;

pub fn normalize_unicode_comprehensive(text: &str) -> String {
    // Apply decancer for broad normalization
    match decancer::cure(text, decancer::Options::all()) {
        Ok(result) => result.to_string(),
        Err(_) => text.to_string()
    }
}

pub fn replace_homoglyphs(text: &str) -> String {
    text.chars().map(|c| {
        HOMOGLYPH_MAP.get(&c).copied().unwrap_or(c)
    }).collect()
}


pub fn remove_invisible_chars(text: &str) -> String {
    INVISIBLE_CHAR_REGEX.replace_all(text, "").to_string()
}

pub fn remove_strikethrough(text: &str) -> String {
    STRIKETHROUGH_REGEX.replace_all(text, "").to_string()
}

pub fn remove_directionality_overrides(text: &str) -> String {
    // Apply standard removal of bidirectional control characters
    let mut result = DIRECTIONALITY_REGEX.replace_all(text, "").to_string();

    // Additional detection and handling for specific bidirectional text cases
    if result.contains('\u{200F}') || result.contains('\u{061C}') ||
       result.contains('\u{2067}') || result.contains('\u{202B}') ||
       result.contains('\u{202E}') {
        // Additional processing for stubborn cases
        result = result.chars()
            .filter(|&c| !matches!(c, '\u{200F}' | '\u{061C}' | '\u{2067}' | '\u{202B}' | '\u{202E}'))
            .collect();
    }

    // Handle the case where text might be reversed due to bidirectional controls
    if might_be_bidirectional(&result) {
        // Create a version with reversed sequences where bidirectional controls might be active
        let reversed_sequences = result.split_whitespace()
            .map(|word| {
                if word.chars().any(|c| c.is_ascii_punctuation()) &&
                   word.chars().any(|c| !c.is_ascii()) {
                    word.chars().rev().collect::<String>()
                } else {
                    word.to_string()
                }
            })
            .collect::<Vec<String>>()
            .join(" ");

        // Score both versions to see which is more likely meaningful
        let normal_score = score_text_likelihood(&result);
        let reversed_score = score_text_likelihood(&reversed_sequences);
        if reversed_score > (normal_score as f64 * 1.5) as i32 {
            return reversed_sequences;
        }
    }

    result
}

pub fn might_be_bidirectional(text: &str) -> bool {
    // Check for mix of RTL scripts (Arabic, Hebrew) with Latin
    let has_rtl = text.chars().any(|c| {
        // Arabic, Hebrew ranges
        (c >= '\u{0590}' && c <= '\u{08FF}') ||
        (c >= '\u{FB1D}' && c <= '\u{FDFF}') ||
        (c >= '\u{FE70}' && c <= '\u{FEFF}')
    });

    let has_ltr = text.chars().any(|c| c.is_ascii_alphabetic());

    has_rtl && has_ltr
}

pub fn score_text_likelihood(text: &str) -> i32 {
    let lowercase = text.to_lowercase();
    COMMON_WORDS.iter()
        .filter(|&&word| lowercase.contains(word))
        .count() as i32
}

pub fn remove_tag_characters(text: &str) -> String {
    // Heuristic: If a high percentage of characters are from the Tags block,
    // we assume it's a smuggling attack and attempt to decode it.
    // Otherwise, we simply strip the tags.
    let total_chars = text.chars().count();
    if total_chars == 0 {
        return String::new();
    }

    let tag_char_count = text.chars()
        .filter(|&c| c >= '\u{E0020}' && c <= '\u{E007F}')
        .count();

    // If more than 50% of the string consists of tag characters, decode it.
    if tag_char_count > 0 && (tag_char_count as f32 / total_chars as f32) > 0.5 {
        // DECODING MODE
        let mut decoded = String::with_capacity(tag_char_count);
        for c in text.chars() {
            let val = c as u32;
            // The range U+E0020 to U+E007E corresponds to ASCII 0x20 to 0x7E.
            if val >= 0xE0020 && val <= 0xE007E {
                if let Some(ascii_char) = std::char::from_u32(val - 0xE0000) {
                    decoded.push(ascii_char);
                }
            }
            // Other characters (like CANCEL TAG U+E007F) are ignored in this mode.
        }
        return decoded;
    }

    // STRIPPING MODE (default behavior)
    // For isolated tags, and also consolidates ZWJ/ZWNJ removal.
    text.chars()
        .filter(|&c| {
            let val = c as u32;
            let is_tag = val >= 0xE0000 && val <= 0xE007F;
            let is_joiner = c == '\u{200D}' || c == '\u{200C}';
            !is_tag && !is_joiner
        })
        .collect()
}

pub fn normalize_flipped_text(text: &str) -> String {
    // If text is very short, don't attempt complex flipping
    if text.len() < 3 {
        return text.to_string();
    }

    // 1. Full reverse with character mapping
    let fully_reversed: String = text.chars().rev().map(|c| {
        FLIPPED_CHARS.get(&c).copied().unwrap_or(c)
    }).collect();

    // 2. Word-by-word reversal with character mapping
    let word_reversed: String = text.split_whitespace()
        .map(|word| {
            word.chars().rev().map(|c| {
                FLIPPED_CHARS.get(&c).copied().unwrap_or(c)
            }).collect::<String>()
        })
        .collect::<Vec<String>>()
        .join(" ");

    // 3. Character mapping without reversal
    let char_mapped: String = text.chars()
        .map(|c| FLIPPED_CHARS.get(&c).copied().unwrap_or(c))
        .collect();

    // 4. Combined approach: First map characters, then reverse
    let combined_approach: String = char_mapped.chars().rev().collect();

    // 5. Improved segments-based approach for partially flipped text
    let segment_approach = process_flipped_segments(text);

    // Scoring - more sophisticated scoring that weighs suspicious keywords higher
    let options = [
        (fully_reversed.clone(), score_normalized_text(&fully_reversed)),
        (word_reversed.clone(), score_normalized_text(&word_reversed)),
        (char_mapped.clone(), score_normalized_text(&char_mapped)),
        (combined_approach.clone(), score_normalized_text(&combined_approach)),
        (segment_approach.clone(), score_normalized_text(&segment_approach)),
        (text.to_string(), score_normalized_text(text))
    ];

    let fallback = (text.to_string(), 0.0);
    options.iter()
        .max_by(|(_, score1), (_, score2)| score1.partial_cmp(score2).unwrap_or(std::cmp::Ordering::Equal))
        .unwrap_or(&fallback)
        .0
        .clone()
}

pub fn process_flipped_segments(text: &str) -> String {
    // Split by punctuation and spaces
    let mut result = String::new();
    let mut buffer = String::new();
    let mut in_flipped_segment = false;

    // Process character by character
    for c in text.chars() {
        if c.is_whitespace() || c.is_ascii_punctuation() {
            // Process buffer if not empty
            if !buffer.is_empty() {
                if in_flipped_segment {
                    // Reverse and map flipped segment
                    let processed = buffer.chars().rev()
                        .map(|ch| FLIPPED_CHARS.get(&ch).copied().unwrap_or(ch))
                        .collect::<String>();
                    result.push_str(&processed);
                } else {
                    result.push_str(&buffer);
                }
                buffer.clear();
            }

            // Add whitespace or punctuation directly
            let mapped = FLIPPED_CHARS.get(&c).copied().unwrap_or(c);
            result.push(mapped);
            in_flipped_segment = false;
        } else {
            // Check if this character is likely part of a flipped segment
            if FLIPPED_CHARS.contains_key(&c) {
                in_flipped_segment = true;
            }
            buffer.push(c);
        }
    }

    // Process any remaining buffer content
    if !buffer.is_empty() {
        if in_flipped_segment {
            let processed = buffer.chars().rev()
                .map(|ch| FLIPPED_CHARS.get(&ch).copied().unwrap_or(ch))
                .collect::<String>();
            result.push_str(&processed);
        } else {
            result.push_str(&buffer);
        }
    }

    result
}

pub fn score_normalized_text(text: &str) -> f64 {
    let lowercase = text.to_lowercase();
    let mut score = 0.0;

    // Award points for common words
    for word in COMMON_WORDS.iter() {
        if lowercase.contains(word) {
            score += word.len() as f64 * 0.2;
        }
    }

    // Award higher points for suspicious words
    for word in SUSPICIOUS_KEYWORDS.iter() {
        if lowercase.contains(word) {
            score += word.len() as f64 * 1.0;
        }
    }

    // Check for valid word boundaries
    let word_count = lowercase.split_whitespace().count();
    if word_count > 1 {
        score += word_count as f64 * 2.0;
    }

    // Prefer text with balanced structure of consonants and vowels
    let vowel_count = lowercase.chars().filter(|&c| "aeiou".contains(c)).count();
    let consonant_count = lowercase.chars().filter(|c| c.is_ascii_alphabetic()).count() - vowel_count;

    if consonant_count > 0 && vowel_count > 0 {
        let consonant_vowel_ratio = consonant_count as f64 / vowel_count as f64;
        // English typically has a consonant-vowel ratio of around 1.5-2.0
        if (1.0..=3.0).contains(&consonant_vowel_ratio) {
            score += 10.0;
        }
    }

    score
}


pub fn try_rot13(text: &str) -> String {
    let rot13_result: String = text.chars().map(|c| {
        ROT13_MAP.get(&c).copied().unwrap_or(c)
    }).collect();

    let original_score = SUSPICIOUS_KEYWORDS.iter()
        .map(|&keyword| if text.to_lowercase().contains(keyword) { 1 } else { 0 })
        .sum::<i32>();

    let rot13_score = SUSPICIOUS_KEYWORDS.iter()
        .map(|&keyword| if rot13_result.to_lowercase().contains(keyword) { 1 } else { 0 })
        .sum::<i32>();

    if rot13_score > original_score {
        rot13_result
    } else {
        text.to_string()
    }
}

pub fn caesar_decode(text: &str, shift: i32) -> String {
    text.chars().map(|c| {
        if c.is_ascii_alphabetic() {
            let base = if c.is_ascii_uppercase() { b'A' } else { b'a' };
            let shifted = (c as u8 - base + 26 - (shift % 26) as u8) % 26 + base;
            shifted as char
        } else {
            c
        }
    }).collect()
}

pub fn try_caesar_shifts(text: &str) -> String {
    let mut best_result = text.to_string();
    let mut best_score = 0;

    // Try shifts 1-25
    for shift in 1..26 {
        let decoded = caesar_decode(text, shift);
        let score = SUSPICIOUS_KEYWORDS.iter()
            .map(|&keyword| if decoded.to_lowercase().contains(keyword) { 1 } else { 0 })
            .sum::<i32>();

        if score > best_score {
            best_score = score;
            best_result = decoded;
        }
    }

    best_result
}

pub fn atbash_decode(text: &str) -> String {
    text.chars().map(|c| {
        match c {
            'a'..='z' => (b'z' - c as u8 + b'a') as char,
            'A'..='Z' => (b'Z' - c as u8 + b'A') as char,
            _ => c,
        }
    }).collect()
}

pub fn try_atbash(text: &str) -> String {
    let atbash_result = atbash_decode(text);

    let original_score = SUSPICIOUS_KEYWORDS.iter()
        .map(|&keyword| if text.to_lowercase().contains(keyword) { 1 } else { 0 })
        .sum::<i32>();

    let atbash_score = SUSPICIOUS_KEYWORDS.iter()
        .map(|&keyword| if atbash_result.to_lowercase().contains(keyword) { 1 } else { 0 })
        .sum::<i32>();

    if atbash_score > original_score {
        atbash_result
    } else {
        text.to_string()
    }
}

pub fn normalize_super_subscripts(text: &str) -> String {
    let mut result = String::with_capacity(text.len());

    for c in text.chars() {
        if let Some(&replacement) = SUPERSCRIPT_MAP.get(&c) {
            result.push(replacement);
        } else if let Some(&replacement) = SUBSCRIPT_MAP.get(&c) {
            result.push(replacement);
        } else {
            result.push(c);
        }
    }

    result
}

pub fn strip_diacritics(text: &str) -> String {
    text.nfd().filter(|c| !is_combining_mark(*c)).collect()
}

pub fn replace_leetspeak(text: &str) -> String {
    let mut result = text.to_string();

    // First replace multi-character patterns
    for (pattern, replacement) in MULTI_CHAR_LEETSPEAK.iter() {
        result = result.replace(pattern, replacement);
    }

    // Then replace single characters
    result.chars().map(|c| {
        LEETSPEAK_MAP.get(&c).copied().unwrap_or(c)
    }).collect()
}

pub fn replace_emojis_with_text(text: &str) -> String {
    let mut result = text.to_string();
    for emoji in emojis::iter() {
        if text.contains(emoji.as_str()) {
            let shortcode = emoji.shortcode().unwrap_or("emoji");
            result = result.replace(emoji.as_str(), &format!(":{}", shortcode));
        }
    }
    result
}

pub fn standardize_spacing(text: &str) -> String {
    // CRITICAL: Remove character-level spacing BEFORE standardizing separators
    let mut result = remove_character_spacing(text);

    // Now standardize remaining separators
    result = SEPARATOR_REGEX.replace_all(&result, " ").to_string();

    result.trim().to_string()
}

pub fn remove_character_spacing(text: &str) -> String {
    // First, identify word boundaries by looking for multiple consecutive spaces
    let word_groups: Vec<&str> = text.split("  ").collect();

    if word_groups.len() > 1 {
        // We have multiple space groups - likely word boundaries are marked by multiple spaces
        let processed_groups: Vec<String> = word_groups.iter()
            .map(|group| {
                let chars: Vec<&str> = group.split_whitespace().collect();
                // If all parts are single characters, collapse them
                if chars.iter().all(|c| c.len() == 1) && !chars.is_empty() {
                    chars.join("")
                } else {
                    group.to_string()
                }
            })
            .filter(|s| !s.is_empty())
            .collect();

        return processed_groups.join(" ");
    }

    // Fallback: use sliding window for single-space separated text
    let words: Vec<&str> = text.split_whitespace().collect();

    if words.is_empty() {
        return text.to_string();
    }

    // Count single-character words to detect obfuscation
    let single_char_count = words.iter().filter(|w| w.len() == 1).count();
    let total_words = words.len();

    // If very few single characters, probably not obfuscated
    if total_words > 3 && (single_char_count as f32 / total_words as f32) < 0.3 {
        return text.to_string();
    }

    // Use a sliding window approach to detect and collapse sequences
    let mut result = Vec::new();
    let mut i = 0;

    while i < words.len() {
        let word = words[i];

        // Look ahead to see if we have a sequence of single characters
        let mut single_char_sequence = vec![word];
        let mut j = i + 1;

        // Collect consecutive single-character words
        while j < words.len() && words[j].len() == 1 {
            single_char_sequence.push(words[j]);
            j += 1;
        }

        // If we found a sequence of 3+ single characters, collapse them into one word
        if single_char_sequence.len() >= 3 {
            let collapsed_word = single_char_sequence.join("");
            result.push(collapsed_word);
            i = j;
        } else {
            // Not enough single chars in sequence, keep original
            result.push(word.to_string());
            i += 1;
        }
    }

    // Join with single spaces to preserve word boundaries
    result.join(" ")
}

pub fn calculate_similarity(s1: &str, s2: &str) -> f64 {
    if s1.is_empty() && s2.is_empty() {
        return 1.0;
    }
    if s1.is_empty() || s2.is_empty() {
        return 0.0;
    }

    let len1 = s1.len();
    let len2 = s2.len();
    let max_len = len1.max(len2);

    let common_chars = s1.chars().zip(s2.chars()).filter(|(a, b)| a == b).count();
    common_chars as f64 / max_len as f64
}
