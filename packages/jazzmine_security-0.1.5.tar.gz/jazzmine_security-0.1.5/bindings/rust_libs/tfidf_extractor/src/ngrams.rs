use regex::Regex;
use lazy_static::lazy_static;

pub fn tokenize_words(text: &str) -> Vec<String> {
    lazy_static! {
        static ref WORD_RE: Regex = Regex::new(r"\b\w+\b").unwrap();
    }
    
    WORD_RE
        .find_iter(&text.to_lowercase())
        .map(|m| m.as_str().to_string())
        .collect()
}

pub fn generate_bigrams(words: &[String]) -> Vec<String> {
    if words.len() < 2 {
        return Vec::new();
    }
    
    words
        .windows(2)
        .map(|w| format!("{} {}", w[0], w[1]))
        .collect()
}

pub fn generate_trigrams(words: &[String]) -> Vec<String> {
    if words.len() < 3 {
        return Vec::new();
    }
    
    words
        .windows(3)
        .map(|w| format!("{} {} {}", w[0], w[1], w[2]))
        .collect()
}

pub fn generate_char_ngrams(text: &str, n: usize) -> Vec<String> {
    if text.len() < n {
        return Vec::new();
    }
    
    let lower = text.to_lowercase();
    let chars: Vec<char> = lower.chars().collect();
    
    chars
        .windows(n)
        .map(|w| w.iter().collect())
        .collect()
}

pub fn count_special_chars(text: &str) -> usize {
    text.chars()
        .filter(|c| !c.is_alphanumeric() && !c.is_whitespace())
        .count()
}

pub fn count_uppercase(text: &str) -> usize {
    text.chars().filter(|c| c.is_uppercase()).count()
}

pub fn count_digits(text: &str) -> usize {
    text.chars().filter(|c| c.is_ascii_digit()).count()
}
