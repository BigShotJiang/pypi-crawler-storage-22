from __future__ import annotations

from typing import Any, Dict, Optional


class SecurityError(Exception):
    """Base exception for all security-related errors.

    Attributes:
        message: Human-readable description of the error.
        cause: Optional original exception that caused this error.
        context: Optional dictionary with extra context information.
    """

    def __init__(self, message: str = "A security error occurred.", *, cause: Optional[Exception] = None, context: Optional[Dict[str, Any]] = None):
        super().__init__(message)
        self.message = message
        self.cause = cause
        self.context = context or {}

    def __str__(self) -> str:
        return f""" {self.message} \n Caused by: {self.cause} \n Context: {self.context}"""


# Model related exceptions
class ModelError(SecurityError):
    """Base exception for model-related errors."""


class ModelNotFoundError(ModelError, FileNotFoundError):
    """Raised when a model file or directory cannot be found."""


class ModelLoadError(ModelError):
    """Raised when a model or tokenizer fails to load."""


class ModelSaveError(ModelError):
    """Raised when saving a model to disk fails."""


class ChecksumMismatchError(ModelError, ValueError):
    """Raised when a checksum does not match the expected value."""


class ModelDecompressError(ModelError):
    """Raised when decompressing a packaged model archive fails."""


# Explainability and analysis exceptions
class ExplainabilityError(SecurityError):
    """Base exception for explainability operations."""


class SHAPComputeError(ExplainabilityError):
    """Raised when SHAP values cannot be computed or are malformed."""


class FeatureImportanceError(ExplainabilityError):
    """Raised when feature importance cannot be computed or mapped to feature names."""


# Detector/prediction exceptions
class DetectorError(SecurityError):
    """Base exception for toxicity/enforcement detectors."""


class DetectorInitializationError(DetectorError):
    """Raised when a detector cannot initialize (missing model, invalid config)."""


class PredictionError(DetectorError):
    """Raised when a prediction or post-processing step fails."""


class FeatureNameMismatchError(DetectorError, KeyError):
    """Raised when model feature names do not match extracted features."""


# Sanitizer exceptions
class SanitizationError(SecurityError):
    """Base exception for content sanitization errors."""


class PDFSanitizationError(SanitizationError):
    """Raised when a PDF cannot be sanitized correctly."""


class CSVSanitizationError(SanitizationError):
    """Raised when CSV sanitization fails or input format is invalid."""


class HTMLSanitizationError(SanitizationError):
    """Raised when HTML sanitization fails or produces an invalid result."""


# Moderation/model service exceptions
class ModeratorError(SecurityError):
    """Base exception for moderator services (input/output)."""


class TokenizerLoadError(ModeratorError):
    """Raised when a tokenizer cannot be loaded or is missing required assets."""


class PipelineLoadError(ModeratorError):
    """Raised when the NLP pipeline couldn't be constructed (missing model/tokenizer)."""


class ModelNotLoadedError(ModeratorError):
    """Raised when an operation requires a loaded model but none is available."""


class InvalidModelError(ModeratorError):
    """Raised when a model artifact is invalid (missing files, corrupted, wrong type)."""


# Data pipeline exceptions
class DataPipelineError(SecurityError):
    """Base exception for data pipeline errors (feature extraction, parsing)."""


class CSVParseError(DataPipelineError):
    """Raised when CSV parsing fails or rows are malformed."""


class FeatureExtractionError(DataPipelineError):
    """Raised when feature extraction fails for an input prompt."""


class MergeError(DataPipelineError):
    """Raised when merging datasets fails or results are inconsistent."""




# Training and serialization
class TrainingError(SecurityError):
    """Base exception for training and checkpointing errors."""


class SaveCheckpointError(TrainingError):
    """Raised when saving a checkpoint fails."""


class LoadCheckpointError(TrainingError):
    """Raised when a checkpoint cannot be loaded."""


# Utility / file and lock errors
class FileLockError(SecurityError):
    """Raised when acquiring or releasing a file lock fails."""


class CompressionError(SecurityError):
    """Raised when compression or decompression of model artifacts fails."""


__all__ = [
    "SecurityError",
    "ModelError",
    "ModelNotFoundError",
    "ModelLoadError",
    "ModelSaveError",
    "ChecksumMismatchError",
    "ModelDecompressError",
    "ExplainabilityError",
    "SHAPComputeError",
    "FeatureImportanceError",
    "DetectorError",
    "DetectorInitializationError",
    "PredictionError",
    "FeatureNameMismatchError",
    "SanitizationError",
    "PDFSanitizationError",
    "CSVSanitizationError",
    "HTMLSanitizationError",
    "ModeratorError",
    "TokenizerLoadError",
    "PipelineLoadError",
    "ModelNotLoadedError",
    "InvalidModelError",
    "PermissionError",
    "PermissionDeniedError",
    "RoleNotFoundError",
    "PermissionConfigurationError",
    "DataPipelineError",
    "CSVParseError",
    "FeatureExtractionError",
    "MergeError",
    "RateLimiterError",
    "RateLimitExceededError",
    "RateLimiterConfigurationError",
    "TrainingError",
    "SaveCheckpointError",
    "LoadCheckpointError",
    "FileLockError",
    "CompressionError",
]
    
    
