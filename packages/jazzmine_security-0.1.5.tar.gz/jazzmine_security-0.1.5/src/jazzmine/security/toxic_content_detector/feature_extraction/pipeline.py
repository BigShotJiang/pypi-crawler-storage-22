"""Feature extraction pipeline for adversarial prompt detection."""

from typing import Dict

from jazzmine.security.toxic_content_detector.feature_extraction.text_normalizer import TextNormalizer
from jazzmine.security.toxic_content_detector.feature_extraction.tfidf_extractor import TFIDFExtractor
from jazzmine.security.toxic_content_detector.feature_extraction.semantic_extractor import SemanticExtractor


class FeatureExtractionPipeline:
    """Extracts 267 features: 104 obfuscation + 29 TF-IDF + 134 semantic."""
    
    def __init__(self):
        self.normalizer = TextNormalizer()
        self.tfidf_extractor = TFIDFExtractor()
        self.semantic_extractor = SemanticExtractor()
    
    def extract_features(self, text: str) -> Dict[str, float]:
        """Extract all features in model order: obfuscation -> TF-IDF -> semantic."""
        features = {}
        
        # 1. Normalize and get obfuscation stats
        stats = self.normalizer.normalize_with_stats(text)
        
        # Convert stats to float features with obf_ prefix (skip string values)
        for key, value in stats.items():
            if key not in ['normalized_prompt', 'original_prompt']:
                if isinstance(value, (int, float, bool)):
                    features[f'obf_{key}'] = float(value)
        
        # 2. Extract TF-IDF features
        tfidf_features = self.tfidf_extractor.extract_features(text)
        features.update(tfidf_features)
        
        # 3. Extract semantic features
        semantic_features = self.semantic_extractor.extract_features(text)
        features.update(semantic_features)
        
        return features
    
    
    def extract_features_with_positions(self, text: str) -> tuple[Dict[str, float], Dict[str, list]]:
        """
        Extract features and match positions for text highlighting.
        
        Returns:
            Tuple of (features dict, positions dict)
            Positions dict maps pattern names to lists of (start, end) tuples
        """
        features = self.extract_features(text)
        positions = self.semantic_extractor.extract_match_positions(text)
        return features, positions