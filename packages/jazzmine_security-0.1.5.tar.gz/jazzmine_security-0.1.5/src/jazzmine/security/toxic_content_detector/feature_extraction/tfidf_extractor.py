"""
TF-IDF feature extractor for adversarial prompt detection.

Provides high-performance lexical and statistical feature extraction
with Rust acceleration (3.35x speedup) and automatic Python fallback.
"""

from typing import Dict, List

from jazzmine_security_rust import TFIDFExtractor as RustTFIDFExtractor

class TFIDFExtractor:
    """
    Extracts 29 lexical features for prompt injection detection.
    
    Features include jailbreak terms, domain vocabulary, n-grams,
    co-occurrence patterns, lexical diversity, and statistical metrics.
    
    Attributes:
        backend: Current implementation ('rust' or 'python')
    """
    
    def __init__(self):
        self.extractor = RustTFIDFExtractor()
    
    def extract_features(self, text: str) -> Dict[str, float]:
        """
        Extract all TF-IDF features from input text.
        
        Args:
            text: Input text to analyze
            
        Returns:
            Dictionary of 29 features with float values
        """
        return self.extractor.extract_features(text)
    
    def get_feature_count(self) -> int:
        """Returns feature count (29)."""
        return self.extractor.get_feature_count()
    
    def get_feature_names(self) -> List[str]:
        """Returns list of 29 feature names."""
        return self.extractor.get_feature_names()
    

    
    

