import numpy as np
import pandas as pd
import xgboost as xgb
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass, asdict
import shap
from jazzmine.security.errors import ExplainabilityError, SHAPComputeError, FeatureImportanceError


@dataclass
class FeatureContribution:
    feature: str
    value: float
    shap_value: float
    impact_percent: float


@dataclass
class Counterfactual:
    feature: str
    current_value: float
    suggested_value: float
    current_prediction: float
    new_prediction: float
    impact: float
    would_flip: bool


@dataclass
class TextHighlight:
    start: int
    end: int
    text: str
    patterns: List[str]


@dataclass
class ExplanationResult:
    prediction: float
    base_value: float
    feature_contributions: List[FeatureContribution]
    text_highlights: List[TextHighlight]
    counterfactuals: List[Counterfactual]
    
    def to_dict(self) -> Dict:
        return {
            'prediction': self.prediction,
            'base_value': self.base_value,
            'feature_contributions': [asdict(fc) for fc in self.feature_contributions],
            'text_highlights': [asdict(th) for th in self.text_highlights],
            'counterfactuals': [asdict(cf) for cf in self.counterfactuals]
        }


class ExplainabilityManager:
    def __init__(self, model: xgb.Booster, feature_names: List[str]):
        self.model = model
        self.feature_names = feature_names
        self.explainer: Optional[Any] = None
        self._init_explainer()
        
    def explain(
        self, 
        features: pd.DataFrame, 
        text: str, 
        match_positions: Dict[str, List[Tuple[int, int]]],
        threshold: float = 0.3,
        top_n: int = 10
    ) -> ExplanationResult:
        prediction = self._predict(features)
        shap_values, base_value = self._compute_shap_values(features)

        contributions = self._build_contributions(features, shap_values, top_n)
        highlights = self._extract_highlights(text, match_positions)
        counterfactuals = self._generate_counterfactuals(
            contributions, prediction, threshold, top_n
        )

        return ExplanationResult(
            prediction=prediction,
            base_value=base_value,
            feature_contributions=contributions,
            text_highlights=highlights,
            counterfactuals=counterfactuals,
        )
    
    def _compute_shap_values(self, features: pd.DataFrame) -> Tuple[np.ndarray, float]:
        if not self.explainer:
            return self._compute_feature_importance_proxy(features), 0.5

        try:
            vals = self.explainer(features)
            shap_values = getattr(vals, 'values', np.array(vals))

            # Normalize possible shapes
            if shap_values.ndim == 3:
                shap_values = shap_values[:, :, 1]
            if shap_values.ndim == 1:
                shap_values = shap_values.reshape(1, -1)

            expected_value = getattr(self.explainer, 'expected_value', 0.5)
            if expected_value is None:
                base_value = 0.5
            elif isinstance(expected_value, (list, np.ndarray)):
                base_value = float(expected_value[0])
            else:
                base_value = float(expected_value)

            return shap_values, base_value
        except Exception as e:
            raise SHAPComputeError("Failed to compute shap values", cause=e)
    
    def _compute_feature_importance_proxy(self, features: pd.DataFrame) -> np.ndarray:
        try:
            feature_importance = self.model.get_score(importance_type='gain')
        except Exception as e:
            raise FeatureImportanceError("Feature importance computation failed", cause=e)
        importance_vector = np.zeros(len(self.feature_names))
        
        for idx, feat_name in enumerate(self.feature_names):
            if feat_name in feature_importance:
                importance_vector[idx] = feature_importance[feat_name] * features.iloc[0, idx]
        
        norm = np.abs(importance_vector).sum()
        if norm > 0:
            importance_vector = importance_vector / norm * 0.1
        
        return importance_vector.reshape(1, -1)

    def _init_explainer(self) -> None:
        try:
            self.explainer = shap.TreeExplainer(self.model)
        except Exception:
            # keep explainer as None; fall back to importance proxy later
            self.explainer = None

    def _predict(self, features: pd.DataFrame) -> float:
        try:
            dmatrix = xgb.DMatrix(features)
            pred = self.model.predict(dmatrix)
            return float(pred[0])
        except Exception as e:
            raise ExplainabilityError("Prediction failed in explainability manager", cause=e)

    def _build_contributions(
        self, features: pd.DataFrame, shap_values: np.ndarray, top_n: int
    ) -> List[FeatureContribution]:
        row = 0
        vals = shap_values[row] if shap_values is not None and shap_values.size > 0 else np.zeros(len(self.feature_names))

        contribs = []
        for idx, feat_name in enumerate(self.feature_names):
            shap_val = float(vals[idx]) if idx < len(vals) else 0.0
            value = float(features.iloc[0, idx]) if idx < features.shape[1] else 0.0
            contribs.append(
                FeatureContribution(
                    feature=feat_name,
                    value=value,
                    shap_value=shap_val,
                    impact_percent=shap_val * 100.0,
                )
            )

        contribs.sort(key=lambda x: abs(x.shap_value), reverse=True)
        return contribs[:top_n]
    
    def _extract_highlights(
        self, 
        text: str, 
        match_positions: Dict[str, List[Tuple[int, int]]]
    ) -> List[TextHighlight]:
        if not match_positions:
            return []

        spans = []
        for name, positions in match_positions.items():
            for start, end in positions:
                spans.append((start, end, name))

        spans.sort(key=lambda x: x[0])

        merged: List[list] = []
        for start, end, name in spans:
            if not merged or start >= merged[-1][1]:
                merged.append([start, end, [name]])
            else:
                merged[-1][1] = max(merged[-1][1], end)
                merged[-1][2].append(name)

        return [
            TextHighlight(start=s, end=e, text=text[s:e], patterns=ps)
            for s, e, ps in merged
        ]
    
    def _generate_counterfactuals(
        self,
        contributions: List[FeatureContribution],
        prediction: float,
        threshold: float,
        max_suggestions: int
    ) -> List[Counterfactual]:
        counterfactuals = []
        top_contributors = [
            c for c in contributions 
            if c.shap_value * (1 if prediction >= threshold else -1) > 0
        ][:max_suggestions * 2]
        
        for contrib in top_contributors[:max_suggestions]:
            if contrib.value == 0:
                continue
            
            new_pred = prediction - contrib.shap_value
            would_flip = (
                (prediction >= threshold and new_pred < threshold) or
                (prediction < threshold and new_pred >= threshold)
            )
            
            counterfactuals.append(Counterfactual(
                feature=contrib.feature,
                current_value=contrib.value,
                suggested_value=0.0,
                current_prediction=prediction,
                new_prediction=new_pred,
                impact=abs(contrib.shap_value),
                would_flip=would_flip
            ))
        
        counterfactuals.sort(key=lambda x: (-x.would_flip, -x.impact))
        return counterfactuals[:max_suggestions]
    
    def format_explanation(self, result: ExplanationResult, top_n: int = 10) -> str:
        lines = [
            "",
            "=" * 80,
            "EXPLAINABILITY ANALYSIS",
            "=" * 80,
            "",
            f"Prediction: {result.prediction:.4f} ({result.prediction*100:.2f}%)",
            f"Base Value: {result.base_value:.4f} ({result.base_value*100:.2f}%)",
            f"Total Shift: {(result.prediction - result.base_value):.4f} "
            f"({(result.prediction - result.base_value)*100:+.2f}%)",
            "",
            f"Top {top_n} Feature Contributions:",
            "-" * 80,
        ]

        cumulative = result.base_value
        for i, contrib in enumerate(result.feature_contributions[:top_n], 1):
            direction = "→" if contrib.shap_value > 0 else "←"
            cumulative += contrib.shap_value
            lines.append(
                f"{i:2d}. {contrib.feature[:50].ljust(50)} = {contrib.value:7.3f}  "
                f"{direction} {contrib.shap_value:+7.4f} ({contrib.impact_percent:+6.2f}%)  [cum: {cumulative:.4f}]"
            )

        if result.text_highlights:
            lines.extend(["", "=" * 80, "TEXT HIGHLIGHTS", "=" * 80, ""])
            for h in result.text_highlights:
                patterns = ", ".join(p.replace("_", " ").title() for p in h.patterns)
                lines.append(f"[{h.start}:{h.end}] \"{h.text}\" ({patterns})")

        if result.counterfactuals:
            lines.extend(["", "=" * 80, "COUNTERFACTUAL SUGGESTIONS", "=" * 80, ""])
            for i, cf in enumerate(result.counterfactuals, 1):
                marker = "🔄 WOULD FLIP" if cf.would_flip else "→ Would shift"
                feat_name = cf.feature.replace("_", " ").title()
                lines.append(
                    f"{i}. {marker} | Feature: {feat_name} | Change: {cf.current_value:.2f}→{cf.suggested_value:.2f} | "
                    f"Pred: {cf.current_prediction:.4f}→{cf.new_prediction:.4f} | Impact: {cf.impact:.4f}"
                )

        return "\n".join(lines)
    

