# Jcy_utils

A comprehensive Python utility library for image processing, file management, and metric calculations.

## 📦 Installation

```bash
pip install Jcy_utils
