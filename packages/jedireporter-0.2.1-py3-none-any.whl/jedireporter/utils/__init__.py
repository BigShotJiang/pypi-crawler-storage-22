# Utils module for jedireporter
