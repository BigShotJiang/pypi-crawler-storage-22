jenkinsflow.flow module
=======================

.. automodule:: jenkinsflow.flow
    :members:
    :show-inheritance:

.. autoclass:: _Flow()
    :members:

.. autoclass:: _JobControl()
    :members: message
