jenkinsflow.jenkins_api module
==================================

.. autoclass:: jenkinsflow.jenkins_api.JenkinsApi
    :members:
