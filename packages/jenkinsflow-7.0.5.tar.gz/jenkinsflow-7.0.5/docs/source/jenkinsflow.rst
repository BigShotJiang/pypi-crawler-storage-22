`jenkinsflow`
=====================

.. program-output:: jenkinsflow --help
    :cwd: ../..

.. program-output:: jenkinsflow set-build-description --help
    :cwd: ../..

You can also use :doc:`jenkinsflow.utils.set_build_description` in your python script.
