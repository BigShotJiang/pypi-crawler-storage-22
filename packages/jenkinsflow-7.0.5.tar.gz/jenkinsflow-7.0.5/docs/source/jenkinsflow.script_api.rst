jenkinsflow.script_api module
=====================================

.. autoclass:: jenkinsflow.script_api.ScriptApi
    :members:
