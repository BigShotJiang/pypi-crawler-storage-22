jenkinsflow.utils.set_build_description module
==============================================

.. automodule:: jenkinsflow.utils.set_build_description
    :members:
    :show-inheritance:
