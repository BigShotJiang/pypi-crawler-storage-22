# MultiAvroReader

::: jetliner.MultiAvroReader
