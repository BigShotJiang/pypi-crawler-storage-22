# 2026.01.29 - 0.4.1

* Republish to PyPI

# 2025.08.06

* Relax package requirements to be compatible with litellm
