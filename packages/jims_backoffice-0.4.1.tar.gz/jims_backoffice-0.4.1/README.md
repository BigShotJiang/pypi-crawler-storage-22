# JIMS UI

Simple FastUI viewer of JIMS threads
