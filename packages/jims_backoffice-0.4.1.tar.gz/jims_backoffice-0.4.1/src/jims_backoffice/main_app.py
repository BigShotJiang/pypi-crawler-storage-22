from fastapi import FastAPI

application = FastAPI(docs_url=None, redoc_url=None)
