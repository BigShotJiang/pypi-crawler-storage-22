# 2026.01.29 - 0.4.1

* Republish to PyPI

# 2025.11.25 - 0.3.0

* Add support for InlineKeyboardMarkup, along with distinguishing various
  "comm.*" events

# 2025.10.29 - 0.2.0

* Change thread_id <-> user_id logic: /start command resets thread_id, clearing conversation context.

# 2025.09.05

* Add CLI `jims-telegram` which loads `JimsApp` from provided module and runs
  Telegram bot

# 0.1.1

* fix markdown view in assistant's messages

# 0.1.0

* vedana-telegram: initial commit
