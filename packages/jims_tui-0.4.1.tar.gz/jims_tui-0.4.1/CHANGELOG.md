# 2026.01.29 - 0.4.1

* Republish to PyPI

# 2025.09.05

* Add CLI `jims-tui` which loads `JimsApp` from provided module and runs TUI app
