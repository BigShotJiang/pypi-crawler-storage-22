Simple TUI for interactive demo of ThreadController and given answering pipeline

## Run as TUI

```
jims-tui --app jims_demo.app
```

## Run as Telegram bot

```
jims-telegram --app jims_demo.app
```
