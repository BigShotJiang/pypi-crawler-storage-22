# MCP Server for JIRA

A Model Context Protocol (MCP) server that provides seamless integration with Jira. This server enables AI assistants to retrieve issue information, comments, and attachments from any Jira instance.

## Features

- 🎫 **Issue Management**: Get, create, update, and transition issues
- 🔍 **Advanced Search**: JQL-based issue search with custom fields
- 📊 **Epic & Sprint Tracking**: Monitor progress, story points, and completion
- 🔗 **Issue Relationships**: View and manage issue links
- 💬 **Comments**: Add and retrieve issue comments
- 📎 **Attachments**: Download issue attachments
- 📜 **History**: Track all changes to issues
- 🚀 **Release Management**: View project versions and releases
- 👥 **Assignment**: Assign/unassign issues to users
- 🔒 **Secure Authentication**: Uses Jira API tokens

## Prerequisites

- Python 3.10 or higher
- Jira API token ([How to create](https://jsw.ibm.com/plugins/servlet/de.resolution.apitokenauth/admin))
- UV package manager ([Installation guide](https://docs.astral.sh/uv/getting-started/installation/))

## Installation

### MCP Client Configuration

For Bob, go to Settings > MCP > Global MCPs.
Add to your MCP client configuration:

```json
{
  "mcpServers": {
    "jira": {
      "command": "uvx",
      "args": ["jira-mcp-tools"],
      "env": {
        "JIRA_URL": "https://jsw.ibm.com/",
        "JIRA_EMAIL": "your-email@ibm.com",
        "JIRA_TOKEN": "your-api-token"
      }
    }
  }
}
```

## Available Tools

### Issue Operations
- **`get_jira_ticket_info(issue_key)`** - Get issue details, description, and comments
- **`get_jira_ticket_attachments(issue_key)`** - Download issue attachments
- **`get_issue_history(issue_key)`** - View complete change history
- **`get_issue_links(issue_key)`** - Get linked issues (blocks, relates to, etc.)
- **`get_development_links(issue_key)`** - Get GitHub branches, PRs, and commits

### Search & Query
- **`search_issues(jql, max_results=50, fields=None)`** - JQL-based issue search
- **`search_issues_by_team(team_name, max_results=50, additional_jql=None)`** - Search issues by team name (searches components, labels, and team custom fields)
- **`search_issues_by_board(board_id, max_results=50, additional_jql=None)`** - Search all issues on a specific board

### Board, Epic & Sprint
- **`get_board_info(board_id)`** - Get board details including name and configuration
- **`get_epic_details(epic_key)`** - Epic info with child issues and progress
- **`get_sprint_info(board_id, sprint_id=None)`** - Sprint details and issues

### Project Management
- **`get_project_releases(project_key)`** - All releases/versions with issues

### Issue Modification
- **`create_issue(project_key, summary, description, issue_type="Task")`** - Create new issue
- **`update_issue(issue_key, fields)`** - Update issue fields
- **`transition_issue(issue_key, transition_name)`** - Change issue status
- **`assign_issue(issue_key, assignee)`** - Assign/unassign issue
- **`add_comment(issue_key, comment_text)`** - Add comment to issue

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

MIT License - see [LICENSE](LICENSE) file for details.

## Support

- **Issues**: [GitHub Issues](https://github.com/IBM/mcp-jira/issues)
- **Documentation**: [Full Documentation](https://github.com/IBM/mcp-jira)

## Acknowledgments

Built with:
- [FastMCP](https://github.com/jlowin/fastmcp) - Fast MCP server framework
- [jira-python](https://github.com/pycontribs/jira) - Python Jira library
- [Model Context Protocol](https://modelcontextprotocol.io/) - MCP specification
