"""Python unit tests for jl_db_comp."""
