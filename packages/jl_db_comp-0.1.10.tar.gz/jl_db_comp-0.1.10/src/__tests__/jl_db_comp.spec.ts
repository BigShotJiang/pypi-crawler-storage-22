/**
 * Example of [Jest](https://jestjs.io/docs/getting-started) unit tests
 */

describe('jl_db_comp', () => {
  it('should be tested', () => {
    expect(1 + 1).toEqual(2);
  });
});
