"""
Jobs package for scheduled tasks.

This package contains cleanup jobs and scheduled maintenance tasks.
To run the raw memory cleanup job, use:
    python -m mirix.jobs.cleanup_raw_memories
"""
