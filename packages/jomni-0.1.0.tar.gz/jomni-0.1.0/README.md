# Jomni

**A personal database designed to last a lifetime.**

AI-native, local-first, future-proof.

## Installation

```bash
pip install jomni
```

## Quick Start

### 1. Run Setup Wizard

```bash
jomni setup
```

This launches a GUI to configure your API keys and database connection.

### 2. Start the Server

```bash
jomni serve
```

Your personal database is now running at `http://localhost:8000`.

### 3. Use with Claude Desktop

```bash
jomni register-mcp
```

Restart Claude Desktop, and Jomni is available as a tool.

## Commands

| Command | Description |
|---------|-------------|
| `jomni setup` | Launch the setup wizard |
| `jomni serve` | Start the API server |
| `jomni mcp` | Start the MCP server (for Claude) |
| `jomni health` | Check server health |
| `jomni register-mcp` | Register with Claude Desktop |
| `jomni version` | Show version info |

## What is Jomni?

Jomni is your personal AI-powered database. It stores:

- **Tasks** – things you need to do
- **Notes** – things you want to remember
- **Goals** – things you want to achieve
- **People** – contacts and relationships
- **Events** – things that happened

Everything is:

- **Searchable** via natural language
- **Connected** through AI-powered relationships
- **Accessible** from any AI assistant via MCP
- **Yours** – stored in your own Supabase database

## Requirements

- Python 3.10+
- Supabase account (for database)
- Anthropic or OpenAI API key (for AI features)

## Configuration

Jomni uses environment variables for configuration. The setup wizard writes these to `~/.jomni/.env`:

```bash
JOMNI_SUPABASE_URL=https://your-project.supabase.co
JOMNI_SUPABASE_SERVICE_KEY=your-service-key
JOMNI_ANTHROPIC_API_KEY=sk-ant-...
JOMNI_OPENAI_API_KEY=sk-...
```

## License

MIT
