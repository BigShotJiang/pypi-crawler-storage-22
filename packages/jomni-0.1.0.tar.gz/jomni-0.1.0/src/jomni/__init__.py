"""
Pillar: A personal database designed to last a lifetime.

AI-native, local-first, future-proof.
"""

__version__ = "0.1.0"
