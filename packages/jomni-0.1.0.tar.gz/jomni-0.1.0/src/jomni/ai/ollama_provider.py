"""
Ollama Local LLM Provider.

Provides local LLM fallback when cloud providers (Claude/OpenAI) are unavailable.
Uses the Ollama API running locally for self-hosted inference.

FALLBACK CHAIN:
1. Claude (Anthropic) — primary
2. Ollama (local) — fallback for offline/rate-limited scenarios
3. Human review — if both AI providers fail (Task 5.1)
"""

import logging
from typing import Any

import httpx

from jomni.config import get_settings
from jomni.models import ItemType, TriageRequest, TriageSuggestion

logger = logging.getLogger(__name__)


class OllamaProvider:
    """
    Ollama local LLM provider for offline/fallback triage.
    
    Uses httpx for async HTTP calls to the Ollama API.
    Compatible with any Ollama-hosted model (llama3.2, mistral, etc.)
    """
    
    def __init__(self, base_url: str | None = None, model: str | None = None):
        settings = get_settings()
        self.base_url = base_url or settings.ollama_base_url
        self.model = model or settings.ollama_model
        self.timeout = 60.0  # Local models can be slow
        
    async def is_available(self) -> bool:
        """Check if Ollama is running and responsive."""
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                response = await client.get(f"{self.base_url}/api/tags")
                return response.status_code == 200
        except Exception:
            return False
    
    async def triage(
        self,
        request: TriageRequest,
        few_shot_examples: list[dict[str, Any]] | None = None,
    ) -> TriageSuggestion:
        """
        Classify a capture into the appropriate item type using local LLM.
        
        This is the fallback for when Claude is unavailable.
        Uses a simpler prompt format optimized for smaller models.
        """
        prompt = self._build_triage_prompt(request.text, request.context, few_shot_examples)
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.post(
                    f"{self.base_url}/api/generate",
                    json={
                        "model": self.model,
                        "prompt": prompt,
                        "stream": False,
                        "format": "json",  # Request JSON output
                        "options": {
                            "temperature": 0.3,  # More deterministic for classification
                        }
                    }
                )
                response.raise_for_status()
                result = response.json()
                
                return self._parse_response(result.get("response", "{}"))
                
        except Exception as e:
            logger.error(f"Ollama triage failed: {e}")
            raise
    
    def _build_triage_prompt(
        self,
        text: str,
        context: dict[str, Any],
        examples: list[dict[str, Any]] | None = None,
    ) -> str:
        """Build a prompt for local LLM triage."""
        
        # Valid types
        valid_types = ["task", "idea", "note", "habit", "goal", "project", "reference", "event"]
        
        prompt_parts = [
            "You are a classification assistant. Classify the following text into ONE of these types:",
            ", ".join(valid_types),
            "",
            "Respond with ONLY valid JSON in this format:",
            '{"type": "task", "confidence": 0.85, "reasoning": "Contains action verb", "tags": ["work"]}',
            "",
        ]
        
        # Add few-shot examples if available
        if examples:
            prompt_parts.append("EXAMPLES OF PAST CORRECTIONS:")
            for ex in examples[:3]:  # Limit to 3
                ai_type = ex.get("ai_suggestion", {}).get("item_type", "unknown")
                user_type = ex.get("user_correction", {}).get("item_type", "unknown")
                ex_text = ex.get("input_text", "")[:100]
                prompt_parts.append(f'- "{ex_text}" was {ai_type} but should be {user_type}')
            prompt_parts.append("")
        
        prompt_parts.extend([
            f"TEXT TO CLASSIFY: {text}",
            "",
            "JSON RESPONSE:"
        ])
        
        return "\n".join(prompt_parts)
    
    def _parse_response(self, response_text: str) -> TriageSuggestion:
        """Parse the LLM response into a TriageSuggestion."""
        import json
        
        try:
            # Clean the response (remove markdown code blocks if present)
            cleaned = response_text.strip()
            if cleaned.startswith("```"):
                cleaned = cleaned.split("```")[1]
                if cleaned.startswith("json"):
                    cleaned = cleaned[4:]
            cleaned = cleaned.strip()
            
            data = json.loads(cleaned)
            
            # Map type string to enum
            type_str = data.get("type", "capture").lower()
            try:
                item_type = ItemType(type_str)
            except ValueError:
                item_type = ItemType.CAPTURE
            
            return TriageSuggestion(
                item_type=item_type,
                confidence=min(0.85, float(data.get("confidence", 0.7))),  # Cap local model confidence
                reasoning=f"[Ollama/{self.model}] " + data.get("reasoning", "Local model classification"),
                suggested_tags=data.get("tags", []),
                alternatives=[],
            )
            
        except (json.JSONDecodeError, KeyError) as e:
            logger.warning(f"Failed to parse Ollama response: {e}")
            # Return a low-confidence fallback
            return TriageSuggestion(
                item_type=ItemType.CAPTURE,
                confidence=0.3,
                reasoning=f"[Ollama] Parse error - needs human review",
                suggested_tags=["needs-human-review"],
                alternatives=[],
            )


# Singleton instance
_ollama_provider: OllamaProvider | None = None


def get_ollama() -> OllamaProvider:
    """Get or create the Ollama provider singleton."""
    global _ollama_provider
    if _ollama_provider is None:
        _ollama_provider = OllamaProvider()
    return _ollama_provider
