"""
Jomni AI integration layer.

Handles all AI operations: triage classification, embeddings, and learning from corrections.
Designed to be model-agnostic—swap providers without changing the interface.

NOTE: Uses async clients (AsyncAnthropic, AsyncOpenAI) to avoid blocking
the event loop. All methods are properly async and awaited.
"""

import hashlib
import json
from typing import Any

from anthropic import AsyncAnthropic
from openai import AsyncOpenAI

from jomni.config import get_settings
from jomni.models import (
    ItemType, TriageRequest, TriageSuggestion,
)


class AIProvider:
    """
    AI provider abstraction.
    
    Handles both Claude (for reasoning) and OpenAI (for embeddings).
    Uses async clients to avoid blocking the event loop.
    """
    
    def __init__(self):
        settings = get_settings()
        
        # LINUS-D10: Add timeouts to prevent hanging requests
        self.anthropic = AsyncAnthropic(
            api_key=settings.anthropic_api_key,
            timeout=30.0,
        )
        self.openai = AsyncOpenAI(
            api_key=settings.openai_api_key,
            timeout=30.0,
        )
        
        # Model settings
        self.triage_model = settings.default_triage_model
        self.chat_model = settings.default_chat_model
        self.embedding_model = settings.default_embedding_model
        self.embedding_dimensions = settings.embedding_dimensions
        
        # Thresholds
        self.auto_accept_threshold = settings.triage_auto_accept_threshold
        self.suggest_threshold = settings.triage_suggest_threshold
    
    # =========================================================================
    # TRIAGE
    # =========================================================================
    
    async def triage(
        self,
        request: TriageRequest,
        few_shot_examples: list[dict[str, Any]] | None = None,
    ) -> TriageSuggestion:
        """
        Classify a raw capture into an item type using AI.
        
        CONTEXT:
        When users capture text quickly ("buy milk", "what if we tried X"),
        the AI determines the appropriate type (TASK, IDEA, NOTE, etc.).
        High-confidence classifications can be auto-accepted; low-confidence
        ones are shown to the user for review.
        
        EXAMPLE:
        Input: "buy milk on the way home"
        Output: TriageSuggestion(
            item_type=TASK,
            confidence=0.95,
            reasoning="Clear actionable task with verb 'buy'",
            suggested_tags=["errands", "shopping"]
        )
        
        FALLBACK CHAIN:
        1. Claude (Anthropic) — primary, best quality
        2. Ollama (local) — fallback for offline/rate-limited
        3. Raises RuntimeError — caught by triage.py for human review
        
        TECHNICAL:
        Args:
            request: Text to classify + optional context dict
            few_shot_examples: Past user corrections for personalization (max 5 used)
            
        Returns:
            TriageSuggestion with:
            - item_type: Predicted type (TASK, IDEA, NOTE, etc.)
            - confidence: 0.0-1.0 float
            - reasoning: AI's explanation
            - suggested_tags: Auto-generated tags
            - alternatives: Other possible classifications
            
        Raises:
            RuntimeError: If all AI providers fail (Claude + Ollama)
            
        Performance:
            Typical: 500-1500ms (Claude API latency)
            Fallback: 200-800ms (Ollama local)
            Uses claude-3-5-haiku by default (fast + cheap)
            
        Rate limits: Anthropic tier limits apply. Safe for 10 req/sec.
        
        COMPLEXITY: High
        Core AI classification. Changes affect item routing and user experience.
        """
        import logging
        logger = logging.getLogger(__name__)
        
        # Attempt 1: Claude (primary)
        try:
            prompt = self._build_triage_prompt(request.text, request.context, few_shot_examples)
            response = await self.anthropic.messages.create(
                model=self.triage_model,
                max_tokens=1024,
                messages=[{"role": "user", "content": prompt}],
            )
            
            # Track AI usage for cost monitoring (TASK-012)
            if hasattr(response, 'usage') and response.usage:
                from jomni.api.metrics import record_ai_tokens
                record_ai_tokens(
                    provider="anthropic",
                    model=self.triage_model,
                    operation="triage",
                    input_tokens=response.usage.input_tokens,
                    output_tokens=response.usage.output_tokens,
                )
            
            return self._parse_triage_response(response.content[0].text)
            
        except Exception as claude_error:
            logger.warning(f"Claude triage failed: {claude_error}, trying Ollama fallback")
            
            # Attempt 2: Ollama (fallback)
            settings = get_settings()
            if settings.ollama_enabled:
                try:
                    from jomni.ai.ollama_provider import get_ollama
                    ollama = get_ollama()
                    
                    if await ollama.is_available():
                        logger.info("Falling back to Ollama for triage")
                        return await ollama.triage(request, few_shot_examples)
                    else:
                        logger.warning("Ollama not available")
                        
                except Exception as ollama_error:
                    logger.warning(f"Ollama triage failed: {ollama_error}")
            
            # Both failed - re-raise for human review handling
            raise RuntimeError(f"All AI providers failed. Claude: {claude_error}")
    
    def _build_triage_prompt(
        self,
        text: str,
        context: dict[str, Any],
        examples: list[dict[str, Any]] | None = None,
    ) -> str:
        """Build the triage classification prompt."""
        
        prompt = """You are a personal data triage assistant. Classify the following capture into the most appropriate category.

## Categories

- **task**: Something the user needs to DO. Has a clear action. Can be completed.
  Examples: "buy milk", "email John about the proposal", "fix the leaky faucet"

- **idea**: Something to EXPLORE or THINK ABOUT. Open-ended. May or may not lead to action.
  Examples: "what if we tried a subscription model", "learn about stoicism", "maybe a trip to Japan"

- **note**: Information to REMEMBER or REFERENCE. Facts, observations, quotes.
  Examples: "John's birthday is March 15", "the API rate limit is 100/minute", "interesting quote from book"

- **habit**: A RECURRING behavior to track. Something done regularly.
  Examples: "morning meditation", "weekly review", "drink 8 glasses of water"

- **goal**: A desired OUTCOME or state. Bigger than a single task.
  Examples: "get promoted to senior engineer", "run a marathon", "save $10k emergency fund"

- **project**: A CONTAINER for related items. Multiple tasks working toward something.
  Examples: "kitchen renovation", "launch new product", "plan wedding"

- **reference**: Static INFORMATION to store. Longer-form content, documents.
  Examples: recipe, code snippet, article summary, contact details

## Response Format

Respond with a JSON object:
```json
{
  "item_type": "task|idea|note|habit|goal|project|reference",
  "confidence": 0.0-1.0,
  "reasoning": "Brief explanation of why this classification",
  "suggested_tags": ["tag1", "tag2"],
  "alternatives": [
    {"item_type": "other_type", "confidence": 0.X, "reasoning": "why this could also apply"}
  ]
}
```

"""
        
        # Add few-shot examples from past corrections
        if examples:
            prompt += "\n## Examples from your past preferences\n\n"
            for ex in examples[:5]:  # Limit to 5 examples
                prompt += f"Input: {ex['input_text']}\n"
                prompt += f"Classification: {ex['user_correction']['item_type']}\n\n"
        
        # Add context if provided
        if context:
            prompt += f"\n## Additional context\n{json.dumps(context, indent=2)}\n"
        
        # Add the capture to classify
        prompt += f"\n## Capture to classify\n\n{text}\n\n"
        prompt += "Respond with only the JSON object, no other text."
        
        return prompt
    
    def _parse_triage_response(self, response_text: str) -> TriageSuggestion:
        """
        Parse Claude's triage response into a TriageSuggestion.
        
        Handles edge cases gracefully:
        - Invalid JSON → fallback to CAPTURE with 0.0 confidence
        - Invalid item_type enum → fallback to CAPTURE with 0.3 confidence
        """
        # Extract JSON from response (handle markdown code blocks)
        text = response_text.strip()
        if text.startswith("```"):
            # Remove markdown code block markers
            lines = text.split("\n")
            text = "\n".join(lines[1:-1])
        
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            # Fallback to capture if parsing fails
            return TriageSuggestion(
                item_type=ItemType.CAPTURE,
                confidence=0.0,
                reasoning="Failed to parse AI response",
                alternatives=[],
            )
        
        # Parse item_type with graceful fallback for unrecognized values
        raw_type = data.get("item_type", "capture").lower()
        try:
            item_type = ItemType(raw_type)
        except ValueError:
            # AI returned an unrecognized type (e.g., "action", "reminder")
            # Fall back to CAPTURE so user can manually classify
            item_type = ItemType.CAPTURE
            data["reasoning"] = f"[AI suggested '{raw_type}' - not a valid type] " + data.get("reasoning", "")
            data["confidence"] = min(float(data.get("confidence", 0.5)), 0.3)  # Cap confidence
        
        return TriageSuggestion(
            item_type=item_type,
            confidence=float(data.get("confidence", 0.5)),
            reasoning=data.get("reasoning", ""),
            suggested_tags=data.get("suggested_tags", []),
            alternatives=data.get("alternatives", []),
        )
    
    # =========================================================================
    # EMBEDDINGS
    # =========================================================================
    
    async def embed(self, text: str) -> tuple[list[float], str]:
        """
        Generate an embedding for the given text.
        
        Returns:
            Tuple of (embedding vector, source hash for staleness detection)
            
        On API failure, returns a zero vector so operations can continue
        (semantic search won't match but item will still be created).
        """
        import logging
        logger = logging.getLogger(__name__)
        
        # Compute hash of source text for staleness detection
        source_hash = hashlib.sha256(text.encode()).hexdigest()[:16]
        
        try:
            # Call OpenAI embeddings API (await async client)
            response = await self.openai.embeddings.create(
                model=self.embedding_model,
                input=text,
                dimensions=self.embedding_dimensions,
            )
            
            # Track AI usage for cost monitoring (TASK-012)
            if hasattr(response, 'usage') and response.usage:
                from jomni.api.metrics import record_ai_tokens
                record_ai_tokens(
                    provider="openai",
                    model=self.embedding_model,
                    operation="embedding",
                    input_tokens=response.usage.total_tokens,
                    output_tokens=0,  # Embeddings don't have output tokens
                )
            
            embedding = response.data[0].embedding
            return embedding, source_hash
            
        except Exception as e:
            logger.warning(f"Embedding generation failed: {e}")
            # Return zero vector - item will be saved but not searchable semantically
            zero_vector = [0.0] * self.embedding_dimensions
            return zero_vector, f"error-{source_hash}"
    
    async def embed_batch(self, texts: list[str]) -> list[tuple[list[float], str]]:
        """
        Generate embeddings for multiple texts efficiently.
        
        Returns:
            List of (embedding vector, source hash) tuples
        """
        # Compute hashes
        hashes = [hashlib.sha256(t.encode()).hexdigest()[:16] for t in texts]
        
        # Batch embed (await async client)
        response = await self.openai.embeddings.create(
            model=self.embedding_model,
            input=texts,
            dimensions=self.embedding_dimensions,
        )
        
        return [
            (response.data[i].embedding, hashes[i])
            for i in range(len(texts))
        ]
    
    # =========================================================================
    # CONTEXT BUILDING
    # =========================================================================
    
    async def get_triage_context(
        self,
        text: str,
        db,  # Database client
    ) -> dict[str, Any]:
        """
        Build context for triage by finding semantically similar items.
        
        This helps the AI understand patterns in how the user classifies things.
        """
        # Embed the input text
        embedding, _ = await self.embed(text)
        
        # Find similar items
        similar_items = await db.semantic_search(embedding, limit=5)
        
        # Find similar corrections
        similar_corrections = await db.get_similar_corrections(
            embedding, 
            correction_type="classification",
            limit=3,
        )
        
        return {
            "similar_items": [
                {
                    "type": item.item_type.value,
                    "text": item.content.get("text", "")[:200],
                    "similarity": score,
                }
                for item, score in similar_items
            ],
            "past_corrections": similar_corrections,
        }
    
    # =========================================================================
    # CHAT STREAMING
    # =========================================================================
    
    async def stream_chat(
        self,
        message: str,
        context: dict[str, Any] | None = None,
        system_prompt: str | None = None,
    ):
        """
        Stream chat response token by token.
        
        Uses Claude's async streaming API to yield tokens as they're generated.
        
        Args:
            message: User's message
            context: Optional context dict (goals, tasks, etc.)
            system_prompt: Optional system prompt (defaults to Jomni assistant)
            
        Yields:
            Text tokens as they're generated
        """
        if system_prompt is None:
            system_prompt = (
                "You are Jomni, a helpful personal AI assistant. "
                "Be concise and helpful. You have access to the user's "
                "tasks, goals, notes, and calendar through the context provided."
            )
        
        # Build messages
        messages = [{"role": "user", "content": message}]
        
        # Use Anthropic async streaming (async context manager)
        async with self.anthropic.messages.stream(
            model=self.chat_model,
            max_tokens=2048,
            system=system_prompt,
            messages=messages,
        ) as stream:
            async for text in stream.text_stream:
                yield text


# =============================================================================
# DEPENDENCY INJECTION
# LINUS-D03: Refactored from global singleton to support proper DI and testing.
# =============================================================================

# For backward compatibility with existing code, we keep the singleton pattern
# but make it resettable for testing and document the preferred DI approach.
_ai: AIProvider | None = None


def get_ai() -> AIProvider:
    """
    Get or create the AI provider instance.
    
    PREFERRED USAGE (FastAPI dependency injection):
        async def endpoint(ai: AIProvider = Depends(get_ai)):
            ...
    
    For testing, use reset_ai() or mock the provider directly.
    
    NOTE: In production, consider storing AIProvider on app.state in lifespan
    and using a dependency that reads from request.app.state.ai instead.
    This enables per-request configuration and cleaner testing.
    """
    global _ai
    if _ai is None:
        _ai = AIProvider()
    return _ai


def reset_ai() -> None:
    """
    Reset the AI provider singleton.
    
    Use in tests to ensure clean state between test cases:
        @pytest.fixture(autouse=True)
        def reset_providers():
            reset_ai()
            yield
            reset_ai()
    """
    global _ai
    _ai = None

