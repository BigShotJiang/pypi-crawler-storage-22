"""
Skills Loader for Jomni.

Loads markdown skill files and provides them to Claude based on context.
Skills teach Claude about Jomni's capabilities, integrations, and domains.
"""

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

# Default skills directory (relative to this file's location)
SKILLS_DIR = Path(__file__).parent.parent.parent.parent / "skills"


@dataclass
class Skill:
    """A loaded skill file."""
    name: str
    category: str  # integrations, capabilities, domains, personal
    path: Path
    content: str
    keywords: list[str] = field(default_factory=list)


class SkillsLoader:
    """
    Loads and manages skills for injection into Claude's context.
    
    Skills are organized in folders:
    - integrations/  (supabase, google_calendar, n8n, etc.)
    - capabilities/  (triage, prioritization, etc.)
    - domains/       (cognitive_patterns, productivity, etc.)
    - personal/      (user workflows, preferences)
    """
    
    def __init__(self, skills_dir: Path | None = None):
        self.skills_dir = skills_dir or SKILLS_DIR
        self.skills: dict[str, Skill] = {}
        self._loaded = False
        
    def load_all(self) -> int:
        """
        Load all skill files from the skills directory.
        
        Returns:
            Number of skills loaded
        """
        if not self.skills_dir.exists():
            logger.warning(f"Skills directory not found: {self.skills_dir}")
            return 0
        
        count = 0
        for category_dir in self.skills_dir.iterdir():
            if not category_dir.is_dir() or category_dir.name.startswith('.'):
                continue
                
            category = category_dir.name
            
            for skill_file in category_dir.glob("*.md"):
                try:
                    skill = self._load_skill(skill_file, category)
                    key = f"{category}/{skill.name}"
                    self.skills[key] = skill
                    count += 1
                    logger.debug(f"Loaded skill: {key}")
                except Exception as e:
                    logger.error(f"Failed to load skill {skill_file}: {e}")
        
        self._loaded = True
        logger.info(f"Loaded {count} skills from {self.skills_dir}")
        return count
    
    def _load_skill(self, path: Path, category: str) -> Skill:
        """Load a single skill file."""
        content = path.read_text(encoding="utf-8")
        name = path.stem  # filename without extension
        
        # Extract keywords from the content (words in headers, code examples)
        keywords = self._extract_keywords(content)
        
        return Skill(
            name=name,
            category=category,
            path=path,
            content=content,
            keywords=keywords
        )
    
    def _extract_keywords(self, content: str) -> list[str]:
        """Extract likely keywords from skill content."""
        keywords = []
        
        for line in content.split('\n'):
            # Headers are good keyword sources
            if line.startswith('#'):
                words = line.lstrip('#').strip().lower().split()
                keywords.extend(w for w in words if len(w) > 3)
            
            # Table names, column names often in backticks
            if '`' in line:
                import re
                matches = re.findall(r'`([^`]+)`', line)
                keywords.extend(m.lower() for m in matches if len(m) > 2)
        
        return list(set(keywords))  # Dedupe
    
    def get_skill(self, key: str) -> Skill | None:
        """Get a specific skill by key (category/name)."""
        if not self._loaded:
            self.load_all()
        return self.skills.get(key)
    
    def get_by_category(self, category: str) -> list[Skill]:
        """Get all skills in a category."""
        if not self._loaded:
            self.load_all()
        return [s for s in self.skills.values() if s.category == category]
    
    def select_relevant(self, query: str, max_skills: int = 3) -> list[Skill]:
        """
        Select skills relevant to a user query.
        
        Uses keyword matching for now. Could be upgraded to embeddings later.
        
        Args:
            query: The user's message
            max_skills: Maximum number of skills to return
            
        Returns:
            List of relevant skills, most relevant first
        """
        if not self._loaded:
            self.load_all()
        
        query_lower = query.lower()
        query_words = set(query_lower.split())
        
        # Score each skill by keyword overlap
        scored: list[tuple[float, Skill]] = []
        
        for skill in self.skills.values():
            score = 0.0
            
            # Check for skill name in query
            if skill.name in query_lower:
                score += 5.0
            
            # Check for category in query
            if skill.category in query_lower:
                score += 2.0
            
            # Check keyword overlap
            skill_keywords = set(skill.keywords)
            overlap = query_words & skill_keywords
            score += len(overlap) * 1.0
            
            # Some heuristics for common patterns
            if 'database' in query_lower or 'items' in query_lower or 'table' in query_lower:
                if 'supabase' in skill.name:
                    score += 3.0
            
            if 'triage' in query_lower or 'classify' in query_lower or 'type' in query_lower:
                if 'triage' in skill.name:
                    score += 3.0
            
            if score > 0:
                scored.append((score, skill))
        
        # Sort by score descending, take top N
        scored.sort(key=lambda x: x[0], reverse=True)
        return [skill for _, skill in scored[:max_skills]]
    
    def format_for_prompt(self, skills: list[Skill]) -> str:
        """Format skills for injection into system prompt."""
        if not skills:
            return ""
        
        parts = ["## Available Skills\n"]
        
        for skill in skills:
            parts.append(f"### {skill.category}/{skill.name}\n")
            parts.append(skill.content)
            parts.append("\n---\n")
        
        return "\n".join(parts)
    
    def list_all(self) -> list[str]:
        """List all available skill keys."""
        if not self._loaded:
            self.load_all()
        return list(self.skills.keys())


# Singleton instance
_skills_loader: SkillsLoader | None = None


def get_skills_loader() -> SkillsLoader:
    """Get the global skills loader instance."""
    global _skills_loader
    if _skills_loader is None:
        _skills_loader = SkillsLoader()
        _skills_loader.load_all()
    return _skills_loader
