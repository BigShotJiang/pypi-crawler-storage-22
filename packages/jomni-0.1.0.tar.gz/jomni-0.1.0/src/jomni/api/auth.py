"""
Authentication API Router.
Handles OAuth flows for external services.
"""

import logging
from datetime import datetime, timedelta
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import RedirectResponse, JSONResponse
from google_auth_oauthlib.flow import Flow

from jomni.config import get_settings
from jomni.db import get_database
from jomni.db.protocol import DatabaseProtocol
from jomni.models import ServiceCredential
from jomni.security import encrypt_token
from jomni.utils.datetime import utc_now

router = APIRouter(tags=["auth"])
logger = logging.getLogger(__name__)

SCOPES = [
    "https://www.googleapis.com/auth/calendar",
    "https://www.googleapis.com/auth/gmail.modify",
    "https://www.googleapis.com/auth/contacts.readonly",
    "https://www.googleapis.com/auth/drive.readonly",
    "https://www.googleapis.com/auth/drive.activity.readonly",
    "https://www.googleapis.com/auth/tasks",
    "openid",
    "https://www.googleapis.com/auth/userinfo.email",
    "https://www.googleapis.com/auth/userinfo.profile",
]

def get_google_flow():
    settings = get_settings()
    if not settings.google_client_id or not settings.google_client_secret:
        raise HTTPException(status_code=500, detail="Google OAuth not configured")
        
    return Flow.from_client_config(
        {
            "web": {
                "client_id": settings.google_client_id,
                "client_secret": settings.google_client_secret,
                "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                "token_uri": "https://oauth2.googleapis.com/token",
            }
        },
        scopes=SCOPES,
        redirect_uri=settings.google_redirect_uri
    )

@router.get("/login")
async def google_login():
    """
    Redirect user to Google consent screen.
    
    SECURITY: Generates a random state parameter and stores it in an
    HTTP-only cookie to prevent CSRF attacks on the callback.
    """
    flow = get_google_flow()
    authorization_url, state = flow.authorization_url(
        access_type="offline",
        prompt="consent",  # Force consent to always get refresh token
        include_granted_scopes="true"
    )
    
    # Create redirect response and set state cookie for CSRF protection
    response = RedirectResponse(authorization_url)
    response.set_cookie(
        key="oauth_state",
        value=state,
        httponly=True,      # Not accessible to JavaScript
        secure=True,        # Only sent over HTTPS
        samesite="lax",     # CSRF protection
        max_age=600,        # 10 minute expiry
    )
    
    return response

@router.get("/callback")
async def google_callback(
    request: Request,
    code: str,
    state: str,  # State from Google redirect
    db: Annotated[DatabaseProtocol, Depends(get_database)]
):
    """
    Handle Google OAuth callback.
    
    SECURITY: Validates the state parameter matches the cookie set during login
    to prevent CSRF attacks.
    """
    # Validate state parameter against cookie (CSRF protection)
    cookie_state = request.cookies.get("oauth_state")
    if not cookie_state or cookie_state != state:
        logger.warning(f"OAuth state mismatch - possible CSRF attack")
        raise HTTPException(
            status_code=403,
            detail="Invalid OAuth state - please try logging in again"
        )
    
    flow = get_google_flow()
    
    try:
        flow.fetch_token(code=code)
        credentials = flow.credentials
        
        # Encrypt tokens
        encrypted_access = encrypt_token(credentials.token)
        encrypted_refresh = encrypt_token(credentials.refresh_token) if credentials.refresh_token else None
        
        # Store in DB
        creds = ServiceCredential(
            service_name="google",
            access_token=encrypted_access,
            refresh_token=encrypted_refresh,
            expires_at=credentials.expiry,
            updated_at=utc_now()
        )
        
        await db.store_credentials(creds)
        
        # Clear the state cookie on success
        response = JSONResponse({"status": "success", "message": "Google account connected successfully"})
        response.delete_cookie("oauth_state")
        return response
        
    except Exception as e:
        logger.error(f"OAuth callback failed: {e}")
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/status")
async def google_status(
    db: Annotated[DatabaseProtocol, Depends(get_database)]
):
    """Check if Google is connected."""
    service = await db.get_service("google")
    return {
        "connected": service.is_connected if service else False,
        "connected_at": service.connected_at if service else None
    }
