"""
Jomni API route for quick capture.

This is a simplified endpoint for external integrations (email, webhooks, etc.)
that just need to capture text without the full item creation API.
"""

from typing import Annotated

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from jomni.db import get_database
from jomni.db.protocol import DatabaseProtocol
from jomni.models import ItemCreate, ItemType, ItemStatus, ActorType


router = APIRouter(tags=["capture"])


class CaptureRequest(BaseModel):
    """Simple capture request - just text."""
    text: str = Field(..., max_length=50000)


class CaptureResponse(BaseModel):
    """Response from capture endpoint."""
    success: bool
    item_id: str
    message: str


@router.post("/capture", response_model=CaptureResponse)
async def capture(
    data: CaptureRequest,
    db: Annotated[DatabaseProtocol, Depends(get_database)],
) -> CaptureResponse:
    """
    Quick capture endpoint for external integrations.
    
    This is a simplified version of POST /api/v1/items designed for
    external services like email routing, webhooks, etc. that just
    need to capture text without dealing with the full item schema.
    
    The captured text goes into the inbox as a CAPTURE type item
    awaiting triage.
    """
    # Use explicit actor parameter instead of stateful set_actor()
    # to prevent race conditions in concurrent async endpoints
    actor = (ActorType.SYSTEM, "email-capture")
    
    # Create the item with explicit actor
    item = await db.create_item(
        ItemCreate(
            item_type=ItemType.CAPTURE,
            status=ItemStatus.INBOX,
            content={"text": data.text},
            metadata={"source": "email"},
        ),
        actor=actor,
        reasoning="Captured via email integration",
    )
    
    return CaptureResponse(
        success=True,
        item_id=str(item.id),
        message=f"Captured: '{data.text[:50]}...' - now in inbox for triage",
    )
