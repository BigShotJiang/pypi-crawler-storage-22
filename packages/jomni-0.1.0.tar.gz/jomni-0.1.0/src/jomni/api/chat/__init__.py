"""
Jomni Chat API Package.

Provides AI chat with tool use capabilities - Claude can delete items,
complete tasks, create captures, and search.

Structure:
- tools.py: Tool definitions in Anthropic format
- executor.py: Tool execution logic
- prompts.py: System prompt builders
- __init__.py: Router and endpoint (this file)

Usage:
    from jomni.api.chat import router
    app.include_router(router, prefix="/api/v1/chat")
"""

import json
import logging
from typing import Any, AsyncIterator
from uuid import UUID

from fastapi import APIRouter, Depends, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from slowapi import Limiter
from slowapi.util import get_remote_address

from jomni.ai.provider import AIProvider, get_ai
from jomni.db import get_database
from jomni.db.protocol import DatabaseProtocol
from jomni.models import (
    ChatSession, ChatSessionCreate, ChatMessage, ChatMessageCreate,
    MessageRole, SessionMode
)
from jomni.db.repositories.sessions import SessionRepository, MessageRepository
from jomni.ai.skills_loader import get_skills_loader

# Import from submodules
from jomni.api.chat.tools import CHAT_TOOLS
from jomni.api.chat.executor import execute_tool
from jomni.api.chat.prompts import build_system_prompt


logger = logging.getLogger(__name__)
router = APIRouter(prefix="/chat", tags=["chat"])
limiter = Limiter(key_func=get_remote_address)


# =============================================================================
# REQUEST/RESPONSE MODELS
# =============================================================================

class ChatRequest(BaseModel):
    """Chat request from frontend."""
    message: str = Field(..., max_length=50000)
    session_id: UUID | None = None  # Optional - creates new if not provided
    session_mode: SessionMode = SessionMode.PERSISTENT
    context: dict[str, Any] = {}
    include_context: bool = True


# =============================================================================
# CHAT WITH TOOLS
# =============================================================================

async def generate_chat_with_tools(
    message: str,
    ai: AIProvider,
    db: DatabaseProtocol,
    session_id: UUID | None = None,
    session_mode: SessionMode = SessionMode.PERSISTENT,
) -> AsyncIterator[str]:
    """
    Chat with Claude using tool calls, then stream the final response.
    
    If session_id is provided, loads history from that session.
    If not, creates a new session (for persistent mode) or runs stateless (ephemeral).
    """
    # =========================================================================
    # REPOSITORY SELECTION (Added 2025-12 for offline chat support)
    # Use SQLite repos when in offline mode, Supabase repos otherwise.
    # This enables chat to work without cloud connectivity.
    # =========================================================================
    from jomni.db.sqlite_client import SQLiteClient
    
    if isinstance(db, SQLiteClient):
        # Offline mode: use SQLAlchemy-based repos that work with SQLite
        from jomni.db.repositories.sqlite_sessions import SQLiteSessionRepository, SQLiteMessageRepository
        session_repo = SQLiteSessionRepository(db)
        message_repo = SQLiteMessageRepository(db)
    else:
        # Online mode: use Supabase repos with .table().insert() API
        session_repo = SessionRepository(db.client)
        message_repo = MessageRepository(db.client)
    
    # Handle session creation/loading
    session: ChatSession | None = None
    history_messages: list[dict[str, Any]] = []
    
    if session_mode == SessionMode.PERSISTENT:
        if session_id:
            # Load existing session
            session = await session_repo.get_by_id(session_id)
            if session:
                # Load last 20 messages for context
                history = await message_repo.get_session_history(session_id, limit=20)
                for msg in history:
                    history_messages.append({
                        "role": msg.role.value if hasattr(msg.role, 'value') else msg.role,
                        "content": msg.content.get("text", "") if isinstance(msg.content, dict) else msg.content
                    })
        
        if not session:
            # Create new session
            session = await session_repo.create(ChatSessionCreate(mode=session_mode))
            session_id = session.id
    
    # Build system prompt with skills
    system_prompt = await build_system_prompt(db)
    
    # Add skills based on message content
    skills_loader = get_skills_loader()
    relevant_skills = skills_loader.select_relevant(message, max_skills=2)
    if relevant_skills:
        skills_text = skills_loader.format_for_prompt(relevant_skills)
        system_prompt = system_prompt + "\n\n" + skills_text
    
    # Build messages array with history + new message
    messages = history_messages + [{"role": "user", "content": message}]
    
    # Store user message if persistent
    if session and session_mode == SessionMode.PERSISTENT:
        await message_repo.create(ChatMessageCreate(
            session_id=session.id,
            role=MessageRole.USER,
            content={"text": message},
        ))
    
    # Tool call loop - keep calling until Claude has no more tool calls
    max_iterations = 10  # Safety limit
    iteration = 0
    
    while iteration < max_iterations:
        iteration += 1
        
        # Call Claude with tools
        response = await ai.anthropic.messages.create(
            model=ai.chat_model,
            max_tokens=4096,
            system=system_prompt,
            tools=CHAT_TOOLS,
            messages=messages,
        )
        
        # Track AI usage for cost monitoring (TASK-012)
        if hasattr(response, 'usage') and response.usage:
            from jomni.api.metrics import record_ai_tokens
            record_ai_tokens(
                provider="anthropic",
                model=ai.chat_model,
                operation="chat",
                input_tokens=response.usage.input_tokens,
                output_tokens=response.usage.output_tokens,
            )
        
        # Check if Claude wants to use tools
        tool_use_blocks = [b for b in response.content if b.type == "tool_use"]
        
        if not tool_use_blocks:
            # No tools - extract text and stream it
            text_content = ""
            for block in response.content:
                if hasattr(block, "text"):
                    text_content += block.text
            
            # Store assistant response if persistent
            if session and session_mode == SessionMode.PERSISTENT:
                await message_repo.create(ChatMessageCreate(
                    session_id=session.id,
                    role=MessageRole.ASSISTANT,
                    content={"text": text_content},
                ))
            
            # Send session_id first so client can track it
            if session:
                yield f"data: {json.dumps({'type': 'session', 'session_id': str(session.id)})}\n\n"
            
            # Stream the response token by token (simulate streaming)
            for i in range(0, len(text_content), 10):
                chunk = text_content[i:i+10]
                yield f"data: {json.dumps({'type': 'token', 'content': chunk})}\n\n"
            
            yield f"data: {json.dumps({'type': 'done', 'content': ''})}\n\n"
            return
        
        # Execute tools and add results to messages
        messages.append({"role": "assistant", "content": response.content})
        
        tool_results = []
        for tool_block in tool_use_blocks:
            logger.info(f"Executing tool: {tool_block.name} with {tool_block.input}")
            
            result = await execute_tool(tool_block.name, tool_block.input, db)
            
            tool_results.append({
                "type": "tool_result",
                "tool_use_id": tool_block.id,
                "content": json.dumps(result),
            })
        
        messages.append({"role": "user", "content": tool_results})
    
    # Safety: exceeded iterations
    yield f"data: {json.dumps({'type': 'error', 'content': 'Too many tool iterations'})}\n\n"


# =============================================================================
# ENDPOINT
# =============================================================================

@router.post("")
@limiter.limit("10/minute")
async def chat(
    request: Request,
    chat_request: ChatRequest,
    ai: AIProvider = Depends(get_ai),
    db: DatabaseProtocol = Depends(get_database),
) -> StreamingResponse:
    """
    Chat with Claude - now with session support and action capabilities.
    
    Args:
        message: User's message
        session_id: Optional session ID for continuing conversation
        session_mode: 'persistent' (stores messages) or 'ephemeral' (stateless)
    
    Returns:
        SSE stream with:
        - type: 'session' - session_id for client to track
        - type: 'token' - streaming response chunks
        - type: 'done' - completion marker
    """
    return StreamingResponse(
        generate_chat_with_tools(
            chat_request.message,
            ai,
            db,
            session_id=chat_request.session_id,
            session_mode=chat_request.session_mode,
        ),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


# Re-export for backward compatibility
__all__ = [
    "router",
    "ChatRequest",
    "CHAT_TOOLS",
    "execute_tool",
    "generate_chat_with_tools",
]
