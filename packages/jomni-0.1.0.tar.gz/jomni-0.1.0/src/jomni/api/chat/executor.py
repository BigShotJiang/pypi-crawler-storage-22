"""
Chat tool executor for Jomni.

Executes tool calls from Claude and returns results.
Handles all tool logic, error handling, and database operations.

ARCHITECTURE:
    This module is the handler layer for the Chat API. When Claude calls a tool,
    the chat endpoint routes to execute_tool() which dispatches to specific handlers.
    
    Handler Sources:
    1. Shared handlers (jomni/tools/handlers.py) - Used for tools shared with MCP
       - handle_capture, handle_search, handle_delete_item, etc.
    2. Local handlers (_execute_*) - Chat API specific implementations
       - _execute_get_events, _execute_list_memories, _execute_snooze, etc.
    
    Data Flow:
        Claude tool_use → execute_tool() → handler → db protocol → response

PROTOCOL METHODS:
    Since Phase 2 cleanup, handlers use DatabaseProtocol methods instead of
    direct db.client calls. This enables database backend swapping.

See Also:
    - jomni/tools/handlers.py: Shared handler implementations
    - jomni/tools/schemas.py: Tool schema definitions
    - jomni/api/chat/tools.py: Tool schema exports
"""

import logging
from typing import Any
from uuid import UUID

from jomni.db.protocol import DatabaseProtocol
from jomni.ai.provider import get_ai
from jomni.models import (
    ItemType, ItemStatus, ItemCreate, ItemUpdate, ActorType,
)
from jomni.tools.handlers import (
    handle_capture,
    handle_complete_item,
    handle_delete_item,
    handle_restore_item,
    handle_search,
    handle_create_goal,
)

logger = logging.getLogger(__name__)


async def execute_tool(
    tool_name: str,
    tool_input: dict[str, Any],
    db: DatabaseProtocol,
) -> dict[str, Any]:
    """
    Execute a tool and return the result.
    
    Args:
        tool_name: Name of the tool to execute
        tool_input: Input parameters from Claude
        db: Database client
        
    Returns:
        Dict with at minimum {"success": bool} and either "message" or "error"
    """
    actor = (ActorType.AI, "chat:claude")
    
    try:
        if tool_name == "delete_item":
            return await handle_delete_item(
                db, actor,
                item_id=tool_input["item_id"],
                reasoning=tool_input.get("reason", "Deleted via chat"),
            )
            
        elif tool_name == "complete_item":
            return await handle_complete_item(
                db, actor,
                item_id=tool_input["item_id"],
            )
            
        elif tool_name == "capture":
            # Parse item_type with fallback to TASK for invalid values
            item_type = ItemType.TASK
            if tool_input.get("item_type"):
                try:
                    item_type = ItemType(tool_input["item_type"])
                except ValueError:
                    item_type = ItemType.TASK
            return await handle_capture(
                db, actor,
                text=tool_input["text"],
                item_type=item_type,
                source="chat",
            )
        
        elif tool_name == "bulk_capture":
            items_to_capture = tool_input.get("items", [])
            if not items_to_capture:
                return {"success": False, "error": "items list is required"}
            created_ids = []
            failed_count = 0
            for item_data in items_to_capture:
                try:
                    result = await handle_capture(
                        db, actor,
                        text=item_data.get("text", ""),
                        context=item_data.get("context"),
                        source="chat-bulk",
                    )
                    if result.get("success") and result.get("item_id"):
                        created_ids.append(result["item_id"])
                    else:
                        failed_count += 1
                except Exception as e:
                    logger.warning(f"Failed to capture item in bulk: {e}")
                    failed_count += 1
            return {"success": True, "created": len(created_ids), "failed": failed_count, "ids": created_ids}
            
        elif tool_name == "list_items":
            return await _execute_list_items(tool_input, db)
            
        elif tool_name == "delete_multiple_items":
            return await _execute_delete_multiple(tool_input, db, actor)
            
        elif tool_name == "get_events":
            return await _execute_get_events(tool_input, db)
            
        elif tool_name == "get_deleted_items":
            return await _execute_get_deleted(tool_input, db)
            
        elif tool_name == "search":
            ai = get_ai()
            return await handle_search(
                db, ai,
                query=tool_input["query"],
                item_types=tool_input.get("item_types"),
                limit=tool_input.get("limit", 10),
            )
            
        elif tool_name == "restore_item":
            return await handle_restore_item(
                db, actor,
                item_id=tool_input["item_id"],
            )
            
        elif tool_name == "update_item":
            return await _execute_update(tool_input, db, actor)
            
        elif tool_name == "archive_item":
            return await _execute_archive(tool_input, db, actor)
            
        elif tool_name == "snooze_item":
            return await _execute_snooze(tool_input, db, actor)
            
        # Memory tools
        elif tool_name == "store_memory":
            return await _execute_store_memory(tool_input, db, actor)
            
        elif tool_name == "list_memories":
            return await _execute_list_memories(tool_input, db)
            
        elif tool_name == "delete_memory":
            return await _execute_delete_memory(tool_input, db, actor)
        
        # Goal tools
        elif tool_name == "create_goal":
            return await handle_create_goal(
                db, actor,
                title=tool_input["title"],
                horizon=tool_input.get("timeframe", "monthly"),
                source="chat",
            )
        
        elif tool_name == "bulk_update_items":
            return await _execute_bulk_update(tool_input, db, actor)
        
        # Discovery tools
        elif tool_name == "list_inbox":
            limit = tool_input.get("limit", 50)
            items = await db.get_inbox(limit=limit)
            return {
                "success": True,
                "count": len(items),
                "items": [{"id": str(i.id), "text": (i.content.get("text", "")[:100] if i.content else "")} for i in items]
            }
        
        elif tool_name == "get_context":
            ai = get_ai()
            from jomni.mcp.server import _handle_get_context
            return await _handle_get_context(db, tool_input)
        
        elif tool_name == "what_now":
            from jomni.mcp.server import _handle_what_now
            limit = tool_input.get("limit", 5)
            return await _handle_what_now(db, limit)
        
        elif tool_name == "generate_digest":
            from jomni.mcp.server import _handle_generate_digest
            return await _handle_generate_digest(db)
        
        # Goal tools
        elif tool_name == "list_goals":
            status = tool_input.get("status", "active")
            horizon = tool_input.get("horizon")
            limit = tool_input.get("limit", 20)
            goals = await db.list_items(item_type=ItemType.GOAL, status=ItemStatus(status) if status else None, limit=limit)
            if horizon:
                goals = [g for g in goals if g.metadata and g.metadata.get("horizon") == horizon]
            return {"success": True, "count": len(goals), "goals": [{"id": str(g.id), "title": g.content.get("text", "")[:100] if g.content else ""} for g in goals]}
        
        elif tool_name == "link_to_goal":
            from jomni.mcp.server import _handle_link_to_goal
            return await _handle_link_to_goal(db, actor, tool_input)
        
        elif tool_name == "assess_goal":
            goal = await db.get_item(UUID(tool_input["goal_id"]))
            if not goal:
                return {"success": False, "error": "Goal not found"}
            metadata = dict(goal.metadata) if goal.metadata else {}
            metadata["progress"] = tool_input["progress"]
            if tool_input.get("notes"):
                metadata["progress_notes"] = tool_input["notes"]
            if tool_input.get("blockers"):
                metadata["blockers"] = tool_input["blockers"]
            await db.update_item(UUID(tool_input["goal_id"]), ItemUpdate(metadata=metadata), actor=actor, reasoning="Goal assessment via chat")
            return {"success": True, "message": f"Updated goal progress to {tool_input['progress']}%"}
        
        elif tool_name == "update_goal":
            goal = await db.get_item(UUID(tool_input["goal_id"]))
            if not goal:
                return {"success": False, "error": "Goal not found"}
            updates = {}
            if tool_input.get("title"):
                content = dict(goal.content) if goal.content else {}
                content["text"] = tool_input["title"]
                updates["content"] = content
            metadata = dict(goal.metadata) if goal.metadata else {}
            if tool_input.get("horizon"):
                metadata["horizon"] = tool_input["horizon"]
            if tool_input.get("target_date"):
                metadata["target_date"] = tool_input["target_date"]
            if metadata:
                updates["metadata"] = metadata
            await db.update_item(UUID(tool_input["goal_id"]), ItemUpdate(**updates), actor=actor, reasoning="Goal update via chat")
            return {"success": True, "message": "Goal updated"}
        
        # Tag tools
        elif tool_name == "add_tags":
            await db.add_tags_to_item(UUID(tool_input["item_id"]), tool_input["tags"])
            return {"success": True, "message": f"Added {len(tool_input['tags'])} tags"}
        
        elif tool_name == "remove_tag":
            await db.remove_tag_from_item(UUID(tool_input["item_id"]), tool_input["tag"])
            return {"success": True, "message": f"Removed tag: {tool_input['tag']}"}
        
        # Google integration tools
        elif tool_name == "sync_gmail":
            from jomni.integrations.google.auth import GoogleAuth
            from jomni.integrations.google.gmail import GmailSync
            auth = GoogleAuth(db)
            sync = GmailSync(db, auth)
            return await sync.sync(max_results=tool_input.get("max_results", 100), full_sync=tool_input.get("full_sync", False))
        
        elif tool_name == "sync_calendar":
            from jomni.integrations.google.auth import GoogleAuth
            from jomni.integrations.google.calendar import CalendarSync
            auth = GoogleAuth(db)
            sync = CalendarSync(db, auth)
            return await sync.sync(days_past=tool_input.get("days_past", 30), days_future=tool_input.get("days_future", 90))
        
        elif tool_name == "list_emails":
            limit = tool_input.get("limit", 20)
            status = ItemStatus(tool_input["status"]) if tool_input.get("status") else None
            emails = await db.list_items(item_type=ItemType.EMAIL, status=status, limit=limit)
            return {"success": True, "count": len(emails), "emails": [{"id": str(e.id), "subject": e.content.get("subject", "")[:50] if e.content else ""} for e in emails]}
        
        elif tool_name == "archive_email":
            from jomni.integrations.google.auth import GoogleAuth
            from jomni.integrations.google.gmail import GmailSync
            auth = GoogleAuth(db)
            sync = GmailSync(db, auth)
            return await sync.archive_email(UUID(tool_input["item_id"]))
        
        # Triage tools
        elif tool_name == "triage":
            from jomni.mcp.server import _handle_triage
            ai = get_ai()
            return await _handle_triage(db, ai, actor, tool_input)
        
        elif tool_name == "accept_triage":
            from jomni.mcp.server import _handle_accept_triage
            ai = get_ai()
            return await _handle_accept_triage(db, ai, actor, tool_input)
        
        # Bulk delete
        elif tool_name == "delete_items":
            item_ids = tool_input["item_ids"]
            deleted = 0
            for item_id in item_ids:
                try:
                    await db.delete_item(UUID(item_id), actor=actor, reasoning=tool_input.get("reasoning", "Bulk delete via chat"))
                    deleted += 1
                except Exception as e:
                    logger.warning(f"Failed to delete item {item_id} in bulk: {e}")
            return {"success": True, "deleted_count": deleted}
            
        else:
            return {"success": False, "error": f"Unknown tool: {tool_name}"}
            
    except Exception as e:
        logger.error(f"Tool {tool_name} failed: {e}", exc_info=True)
        return {"success": False, "error": str(e)}




async def _execute_archive(
    tool_input: dict[str, Any],
    db: DatabaseProtocol,
    actor: tuple,
) -> dict[str, Any]:
    """Archive an item."""
    item_id = UUID(tool_input["item_id"])
    
    item = await db.update_item(
        item_id,
        ItemUpdate(status=ItemStatus.ARCHIVED),
        actor=actor,
        reasoning="Archived via chat"
    )
    
    if not item:
        return {"success": False, "error": "Item not found"}
    
    item_text = item.content.get("text", "")[:50] if item.content else ""
    return {"success": True, "message": f"Archived: '{item_text}'"}


async def _execute_update(
    tool_input: dict[str, Any],
    db: DatabaseProtocol,
    actor: tuple,
) -> dict[str, Any]:
    """Update an item."""
    item_id = UUID(tool_input["item_id"])
    
    updates = {}
    if "text" in tool_input:
        updates["content"] = {"text": tool_input["text"]}
    if "item_type" in tool_input:
        updates["item_type"] = ItemType(tool_input["item_type"])
    if "priority" in tool_input:
        item = await db.get_item(item_id)
        if item and item.content:
            content = dict(item.content)
            content["priority"] = tool_input["priority"]
            updates["content"] = content
    
    if not updates:
        return {"success": False, "error": "No updates provided"}
    
    item = await db.update_item(
        item_id,
        ItemUpdate(**updates),
        actor=actor,
        reasoning="Updated via chat"
    )
    
    if not item:
        return {"success": False, "error": "Item not found"}
    
    return {"success": True, "message": f"Updated item {item_id}"}


# =============================================================================
# DISCOVERY TOOLS
# =============================================================================

async def _execute_list_items(
    tool_input: dict[str, Any],
    db: DatabaseProtocol,
) -> dict[str, Any]:
    """List items with optional filters."""
    item_type = None
    status = None
    limit = tool_input.get("limit", 20)
    
    if tool_input.get("item_type"):
        try:
            item_type = ItemType(tool_input["item_type"])
        except ValueError:
            pass
            
    if tool_input.get("status"):
        try:
            status = ItemStatus(tool_input["status"])
        except ValueError:
            pass
    
    items = await db.list_items(
        item_type=item_type,
        status=status,
        limit=limit,
    )
    
    return {
        "success": True,
        "count": len(items),
        "items": [
            {
                "id": str(item.id),
                "type": item.item_type.value,
                "status": item.status.value,
                "text": (item.content.get("text", "")[:100] if item.content else ""),
            }
            for item in items
        ]
    }


async def _execute_get_events(
    tool_input: dict[str, Any],
    db: DatabaseProtocol,
) -> dict[str, Any]:
    """Get recent events."""
    limit = tool_input.get("limit", 20)
    action_filter = tool_input.get("action_type")
    
    # Use protocol method instead of db.client
    event_objects = await db.get_events(action_type=action_filter, limit=limit)
    
    events = []
    for event in event_objects:
        item_text = ""
        if event.changes:
            changes = event.changes
            if isinstance(changes, dict):
                if "item" in changes:
                    item_text = changes["item"].get("content", {}).get("text", "")[:50]
                elif "deleted_item" in changes:
                    item_text = changes["deleted_item"].get("content", {}).get("text", "")[:50]
        
        events.append({
            "action": event.action,
            "item_id": str(event.item_id),
            "occurred_at": event.occurred_at.isoformat() if event.occurred_at else None,
            "actor": event.actor_type.value if event.actor_type else "unknown",
            "reasoning": event.reasoning or "",
            "item_text": item_text,
        })
    
    return {"success": True, "count": len(events), "events": events}


async def _execute_get_deleted(
    tool_input: dict[str, Any],
    db: DatabaseProtocol,
) -> dict[str, Any]:
    """Get deleted items."""
    limit = tool_input.get("limit", 20)
    
    # Use protocol method instead of db.client
    items = await db.get_deleted_items(limit=limit)
    
    deleted_items = [
        {
            "id": str(item.id),
            "type": item.item_type.value,
            "text": (item.content.get("text", "")[:80] if item.content else ""),
            "deleted_at": item.updated_at.isoformat() if item.updated_at else None,
        }
        for item in items
    ]
    
    return {"success": True, "count": len(deleted_items), "deleted_items": deleted_items}


# =============================================================================
# BULK OPERATIONS
# =============================================================================

async def _execute_delete_multiple(
    tool_input: dict[str, Any],
    db: DatabaseProtocol,
    actor: tuple,
) -> dict[str, Any]:
    """Delete multiple items."""
    item_ids = [UUID(id_str) for id_str in tool_input["item_ids"]]
    reason = tool_input.get("reason", "Bulk delete via chat")
    
    deleted_count = 0
    for item_id in item_ids:
        try:
            await db.delete_item(item_id, actor=actor, reasoning=reason)
            deleted_count += 1
        except Exception as e:
            logger.warning(f"Failed to delete item {item_id} in bulk operation: {e}")
    
    return {
        "success": True,
        "deleted_count": deleted_count,
        "message": f"Deleted {deleted_count} items"
    }


async def _execute_bulk_update(
    tool_input: dict[str, Any],
    db: DatabaseProtocol,
    actor: tuple,
) -> dict[str, Any]:
    """Bulk update items matching filters."""
    set_status = tool_input.get("set_status")
    if not set_status:
        return {"success": False, "error": "set_status is required"}
    
    filter_type = tool_input.get("filter_type")
    filter_status = tool_input.get("filter_status")
    limit = tool_input.get("limit", 1000)
    reasoning = tool_input.get("reasoning", "Bulk update via chat")
    
    updated_count = await db.bulk_update_items(
        set_status=ItemStatus(set_status),
        filter_type=ItemType(filter_type) if filter_type else None,
        filter_status=ItemStatus(filter_status) if filter_status else None,
        limit=limit,
        actor=actor,
        reasoning=reasoning,
    )
    
    return {
        "success": True,
        "updated_count": updated_count,
        "set_status": set_status,
        "message": f"Updated {updated_count} items to {set_status}"
    }


# =============================================================================
# SCHEDULING TOOLS
# =============================================================================

async def _execute_snooze(
    tool_input: dict[str, Any],
    db: DatabaseProtocol,
    actor: tuple,
) -> dict[str, Any]:
    """Snooze an item until a specific time."""
    import dateparser
    
    item_id = UUID(tool_input["item_id"])
    until_str = tool_input["until"]
    
    snooze_until = dateparser.parse(until_str, settings={'PREFER_DATES_FROM': 'future'})
    
    if not snooze_until:
        return {"success": False, "error": f"Could not parse date: {until_str}"}
    
    item = await db.get_item(item_id)
    if not item:
        return {"success": False, "error": "Item not found"}
    
    metadata = dict(item.metadata) if item.metadata else {}
    metadata["snoozed_until"] = snooze_until.isoformat()
    
    await db.update_item(
        item_id,
        ItemUpdate(metadata=metadata, status=ItemStatus.STALE),
        actor=actor,
        reasoning=f"Snoozed until {snooze_until.strftime('%Y-%m-%d')}"
    )
    
    item_text = item.content.get("text", "")[:50] if item.content else ""
    return {
        "success": True,
        "message": f"Snoozed '{item_text}' until {snooze_until.strftime('%Y-%m-%d')}"
    }


# =============================================================================
# MEMORY TOOLS
# =============================================================================

async def _execute_store_memory(
    tool_input: dict[str, Any],
    db: DatabaseProtocol,
    actor: tuple,
) -> dict[str, Any]:
    """Store an explicit memory about the user."""
    content = tool_input["content"]
    
    # Create a memory item with #explicit tag
    item = await db.create_item(
        ItemCreate(
            item_type=ItemType.NOTE,  # Memories are stored as notes
            status=ItemStatus.ACTIVE,
            content={"text": content, "memory_type": "explicit"},
            metadata={"source": "chat", "memory": True},
        ),
        actor=actor,
        reasoning="User requested to remember this"
    )
    
    # Add the explicit tag
    await db.add_tags_to_item(item.id, ["memory", "explicit"])
    
    return {
        "success": True,
        "memory_id": str(item.id),
        "message": f"I'll remember: '{content[:50]}...'" if len(content) > 50 else f"I'll remember: '{content}'"
    }


async def _execute_list_memories(
    tool_input: dict[str, Any],
    db: DatabaseProtocol,
) -> dict[str, Any]:
    """List stored memories."""
    memory_type = tool_input.get("memory_type", "all")
    limit = tool_input.get("limit", 20)
    
    # Use protocol method instead of db.client
    items = await db.list_memories(memory_type=memory_type, limit=limit)
    
    memories = []
    for item in items:
        item_memory_type = item.content.get("memory_type", "explicit") if item.content else "explicit"
        
        memories.append({
            "id": str(item.id),
            "type": item_memory_type,
            "content": item.content.get("text", "") if item.content else "",
            "created_at": item.created_at.isoformat() if item.created_at else None,
        })
    
    return {
        "success": True,
        "count": len(memories),
        "memories": memories
    }


async def _execute_delete_memory(
    tool_input: dict[str, Any],
    db: DatabaseProtocol,
    actor: tuple,
) -> dict[str, Any]:
    """Delete a memory, optionally with cascade."""
    memory_id = UUID(tool_input["memory_id"])
    cascade = tool_input.get("cascade", False)
    
    item = await db.get_item(memory_id)
    if not item:
        return {"success": False, "error": "Memory not found"}
    
    content = item.content.get("text", "")[:50] if item.content else ""
    
    # If cascade, find related implicit memories
    related_count = 0
    if cascade:
        # Find implicit memories that might be related (simple approach)
        # In a full implementation, we'd track parent_id for implicit memories
        result = db.client.table("items")\
            .select("id")\
            .contains("metadata", {"memory": True, "source_memory_id": str(memory_id)})\
            .is_("deleted_at", "null")\
            .execute()
        
        for related in result.data:
            await db.delete_item(UUID(related["id"]), actor=actor, reasoning="Cascade delete from parent memory")
            related_count += 1
    
    await db.delete_item(memory_id, actor=actor, reasoning="User requested to forget this")
    
    message = f"Forgotten: '{content}'"
    if related_count > 0:
        message += f" (and {related_count} related memories)"
    
    return {"success": True, "message": message, "cascade_count": related_count}

