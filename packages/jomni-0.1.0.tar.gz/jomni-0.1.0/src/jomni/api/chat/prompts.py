"""
Chat system prompts for Jomni.

Builds context-aware prompts for Claude.
"""

import logging
from jomni.db.protocol import DatabaseProtocol
from jomni.models import ItemType, ItemStatus

logger = logging.getLogger(__name__)


async def build_system_prompt(db: DatabaseProtocol) -> str:
    """
    Build system prompt with user context.
    
    Includes current inbox, active items, and goals to give Claude
    awareness of the user's current state.
    """
    system = """You are Jomni, a personal AI assistant with FULL CONTROL over the user's life database.

You CAN and SHOULD take actions when asked. Use your tools to:
- DELETE items (debug tests, duplicates, irrelevant entries)
- COMPLETE tasks when the user says they're done
- CREATE new tasks, ideas, notes, goals
- LIST items to show the user what they have

When the user asks you to do something, DO IT. Don't just talk about it.

IMPORTANT: When you need to delete or modify items, first use list_items to find their IDs, then use the appropriate action tool.
"""
    
    # Add current context
    try:
        inbox_items = await db.get_inbox(limit=10)
        active_items = await db.list_items(status=ItemStatus.ACTIVE, limit=15)
        goals = await db.list_items(item_type=ItemType.GOAL, limit=5)
        
        system += "\n## Current Data\n"
        
        if inbox_items:
            system += f"\n### Inbox ({len(inbox_items)} items)\n"
            for item in inbox_items:
                text = item.content.get("text", "No text")[:80] if item.content else ""
                system += f"- `{item.id}` [{item.item_type.value}] {text}\n"
        else:
            system += "\n### Inbox: Empty ✓\n"
        
        if active_items:
            system += f"\n### Active Items ({len(active_items)})\n"
            for item in active_items:
                text = item.content.get("text", "No text")[:80] if item.content else ""
                system += f"- `{item.id}` [{item.item_type.value}] {text}\n"
        
        if goals:
            system += f"\n### Goals ({len(goals)})\n"
            for g in goals:
                text = g.content.get("text", "No text")[:80] if g.content else ""
                system += f"- `{g.id}` {text}\n"
                
    except Exception as e:
        logger.error(f"Error building context: {e}")
        system += f"\n(Context fetch error: {e})\n"
    
    return system
