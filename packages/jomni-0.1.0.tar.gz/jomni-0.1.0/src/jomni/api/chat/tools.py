"""
Chat tool definitions for Jomni.

Defines the tools available to Claude during chat sessions.
Uses unified schemas from jomni.tools for core tools.

ARCHITECTURE:
    Core tools (26) come from jomni/tools/schemas.py - the single source of truth.
    Extended tools (10) are Chat API specific and defined here.
    
    UNIFIED_TOOLS (from schemas.py):
        capture, triage, list_items, search, complete_item, delete_item, etc.
    
    EXTENDED_TOOLS (Chat API only):
        add_tags, remove_tag, assess_goal, update_goal, sync_gmail, sync_calendar,
        list_emails, archive_email, store_memory (alias), delete_items (alias)

TOOL CATEGORIES:
    - Item Management: capture, delete, complete, archive, restore, update
    - Bulk Operations: bulk_capture, bulk_update, delete_multiple
    - Discovery: search, list_items, list_inbox, get_events, get_deleted
    - Scheduling: snooze_item
    - Memory: remember, list_memories, delete_memory
    - Goals: create_goal, list_goals, link_to_goal, assess_goal, update_goal
    - Insights: what_now, get_context, generate_digest
    - Tags: add_tags, remove_tag
    - Google Integration: sync_gmail, sync_calendar, list_emails, archive_email

See Also:
    - jomni/tools/schemas.py: Unified schema definitions
    - jomni/api/chat/executor.py: Handler implementations
"""

from typing import Any

# Import unified schema converter - this is the single source of truth
from jomni.tools.schemas import get_anthropic_tools


# =============================================================================
# CORE TOOLS (from unified schema)
# These 26 tools are shared between MCP and Chat API
# =============================================================================

UNIFIED_TOOLS = get_anthropic_tools()


# =============================================================================
# EXTENDED TOOLS (Chat API specific)
# These tools are only available via the Chat API, not MCP
# =============================================================================

EXTENDED_TOOLS: list[dict[str, Any]] = [

    # Legacy aliases for backward compatibility
    {
        "name": "store_memory",
        "description": "Store an explicit memory about the user (alias for 'remember').",
        "input_schema": {
            "type": "object",
            "properties": {
                "content": {"type": "string", "description": "The fact to remember"}
            },
            "required": ["content"]
        }
    },
    {
        "name": "delete_items",
        "description": "Delete multiple items by ID (alias for delete_multiple_items).",
        "input_schema": {
            "type": "object",
            "properties": {
                "item_ids": {"type": "array", "items": {"type": "string"}},
                "reasoning": {"type": "string"}
            },
            "required": ["item_ids"]
        }
    },
]


# =============================================================================
# COMBINED TOOLS
# =============================================================================

# Combine unified + extended tools
CHAT_TOOLS = UNIFIED_TOOLS + EXTENDED_TOOLS


def get_tool_names() -> list[str]:
    """Get list of all available tool names."""
    return [tool["name"] for tool in CHAT_TOOLS]


def get_tool_by_name(name: str) -> dict[str, Any] | None:
    """Get tool definition by name."""
    for tool in CHAT_TOOLS:
        if tool["name"] == name:
            return tool
    return None
