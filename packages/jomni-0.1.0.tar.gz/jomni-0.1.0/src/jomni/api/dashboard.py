"""
Jomni dashboard API endpoints.

Provides data for the dashboard modules: NOW, TODAY, and GOALS.
These are read-optimized endpoints that aggregate data for display.
"""

from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Annotated, Any
from uuid import UUID

from fastapi import APIRouter, Depends
from pydantic import BaseModel

from jomni.db import get_database
from jomni.db.protocol import DatabaseProtocol
from jomni.models import Item, ItemType, ItemStatus
from jomni.utils.datetime import utc_now, parse_iso


# =============================================================================
# SCORING CONFIGURATION
# =============================================================================
# These weights determine how items are prioritized in the NOW view.
# Higher scores = higher priority. Extracted here for easy tuning.

@dataclass(frozen=True)
class ScoringWeights:
    """Configuration for dashboard item prioritization."""
    
    # Due date scoring
    overdue: int = 100          # Past due date
    due_today: int = 50         # Due today
    due_soon: int = 20          # Due within 3 days
    due_soon_days: int = 3      # Threshold for "due soon"
    
    # Relationship scoring
    supports_goal: int = 15     # Connected to a goal
    
    # Item type scoring
    task_boost: int = 10        # Tasks get slight priority
    
    # Freshness scoring
    stale_penalty: int = -10    # Untouched for 7+ days
    stale_days: int = 7         # When staleness kicks in


# Default scoring weights (can be overridden for A/B testing)
SCORING = ScoringWeights()


router = APIRouter(prefix="/dashboard", tags=["dashboard"])


# =============================================================================
# RESPONSE MODELS
# =============================================================================

class NowItem(BaseModel):
    """A prioritized item for the NOW module."""
    id: str
    text: str
    item_type: str
    score: float
    why: str  # Reason for priority


class NowResponse(BaseModel):
    """Response for /now endpoint."""
    focus: list[NowItem]
    blocked: list[NowItem]


class TodayTask(BaseModel):
    """A task for today."""
    id: str
    text: str
    done: bool
    due_time: str | None = None


class CalendarEvent(BaseModel):
    """A calendar event."""
    time: str
    event: str
    source: str = "calendar"


class TodayResponse(BaseModel):
    """Response for /today endpoint."""
    tasks: list[TodayTask]
    events: list[CalendarEvent]
    stats: dict[str, int]


class GoalProgress(BaseModel):
    """A goal with progress tracking."""
    id: str
    name: str
    progress: int
    horizon: str
    target_date: str | None = None
    status: str


class GoalsResponse(BaseModel):
    """Response for /goals endpoint."""
    goals: list[GoalProgress]


# =============================================================================
# NOW ENDPOINT
# =============================================================================

@router.get("/now", response_model=NowResponse)
async def get_now(
    db: Annotated[DatabaseProtocol, Depends(get_database)],
    limit: int = 5,
) -> NowResponse:
    """
    Get what the user should focus on RIGHT NOW.
    
    CONTEXT:
    The "NOW" module is Jomni's answer to overwhelm. Instead of showing
    every task, it surfaces the most important items with reasoning for
    WHY they're prioritized. This is the primary dashboard view.
    
    SCORING ALGORITHM (points determine ranking):
    - Overdue items: +100 points (always surface these)
    - Due today: +50 points
    - Due within 3 days: +20 points
    - Supports a goal (via relation): +15 points
    - Is a task type (vs. idea/note): +10 points
    - Stale (untouched 7+ days): -10 points (penalize neglected items)
    
    EXAMPLE RESPONSE:
    {
        "focus": [
            {"id": "...", "text": "Write proposal", "score": 100, "why": "OVERDUE"},
            {"id": "...", "text": "Review PR", "score": 65, "why": "Due today, Supports goal"}
        ],
        "blocked": [
            {"id": "...", "text": "Deploy feature", "score": 0, "why": "Blocked"}
        ]
    }
    
    TECHNICAL:
    Args:
        limit: Max items to return in focus/blocked lists (default 5)
        
    Returns:
        NowResponse with:
        - focus: Top N items by score, descending
        - blocked: Items with "blocked_by" relations (can't proceed)
        
    Performance: O(n) where n = active items, typically <100ms.
    Fetches up to 100 active items, scores locally, returns top N.
    
    COMPLEXITY: Medium
    Scoring weights are tunable. Changes directly affect user experience.
    """
    now = utc_now()
    
    # Get active and inbox items
    active_items = await db.list_items(status=ItemStatus.ACTIVE, limit=100)
    
    if not active_items:
        return NowResponse(focus=[], blocked=[])
    
    # Get relations for goal connections
    item_ids = [item.id for item in active_items]
    relations = await db.get_relations_for_items(item_ids)
    
    scored_items = []
    blocked_items = []
    
    for item in active_items:
        # Skip goals themselves from focus list
        if item.item_type == ItemType.GOAL:
            continue
            
        score = 0.0
        reasons = []
        
        # Check for blockers
        item_relations = relations.get(item.id, [])
        is_blocked = any(r.relation_type.value == "blocked_by" for r in item_relations)
        
        if is_blocked:
            blocked_items.append(NowItem(
                id=str(item.id),
                text=item.content.get("text", "Untitled")[:100],
                item_type=item.item_type.value,
                score=0,
                why="Blocked",
            ))
            continue
        
        # Due date scoring
        due_date = item.content.get("due_date") or item.metadata.get("due_date")
        if due_date:
            try:
                due = parse_iso(due_date)
                days_until = (due - now).days
                if days_until < 0:
                    score += SCORING.overdue
                    reasons.append("OVERDUE")
                elif days_until == 0:
                    score += SCORING.due_today
                    reasons.append("Due today")
                elif days_until <= SCORING.due_soon_days:
                    score += SCORING.due_soon
                    reasons.append(f"Due in {days_until}d")
            except (ValueError, TypeError):
                pass
        
        # Goal connection scoring
        supports_goal = any(r.relation_type.value == "supports" for r in item_relations)
        if supports_goal:
            score += SCORING.supports_goal
            reasons.append("Supports goal")
        
        # Task type boost
        if item.item_type == ItemType.TASK:
            score += SCORING.task_boost
            reasons.append("Task")
        
        # Staleness check
        days_since_update = (now - item.updated_at).days
        if days_since_update > SCORING.stale_days:
            score += SCORING.stale_penalty  # Note: negative value
            reasons.append(f"Stale ({days_since_update}d)")
        
        scored_items.append(NowItem(
            id=str(item.id),
            text=item.content.get("text", "Untitled")[:100],
            item_type=item.item_type.value,
            score=score,
            why=", ".join(reasons) if reasons else "Active",
        ))
    
    # Sort by score descending
    scored_items.sort(key=lambda x: x.score, reverse=True)
    
    return NowResponse(
        focus=scored_items[:limit],
        blocked=blocked_items[:limit],
    )


# =============================================================================
# TODAY ENDPOINT  
# =============================================================================

@router.get("/today", response_model=TodayResponse)
async def get_today(
    db: Annotated[DatabaseProtocol, Depends(get_database)],
) -> TodayResponse:
    """
    Get tasks and events for today.
    
    CONTEXT:
    The "TODAY" module shows a time-ordered view of the day. Unlike NOW
    (priority-based), TODAY is chronological: what's scheduled when.
    Useful for users who need to see their day as a timeline.
    
    TECHNICAL:
    Returns:
        TodayResponse with:
        - tasks: Active tasks + tasks completed today
        - events: Calendar events synced from Google (EVENT type items)
        - stats: Counts for active/completed/inbox items
    
    Performance: O(n) where n = active + completed tasks, typically <100ms.
    Fetches up to 50 tasks and 20 events.
    
    COMPLEXITY: Low
    Read-only aggregation. No scoring logic.
    """
    now = utc_now()
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    today_end = today_start + timedelta(days=1)
    
    # Get active tasks
    active_items = await db.list_items(
        item_type=ItemType.TASK,
        status=ItemStatus.ACTIVE,
        limit=50,
    )
    
    # Get completed today
    completed_items = await db.list_items(
        item_type=ItemType.TASK,
        status=ItemStatus.COMPLETED,
        limit=50,
    )
    completed_today = [
        item for item in completed_items
        if item.updated_at >= today_start
    ]
    
    # Build task list
    tasks = []
    for item in active_items:
        tasks.append(TodayTask(
            id=str(item.id),
            text=item.content.get("text", "Untitled")[:100],
            done=False,
            due_time=item.content.get("due_time"),
        ))
    
    for item in completed_today:
        tasks.append(TodayTask(
            id=str(item.id),
            text=item.content.get("text", "Untitled")[:100],
            done=True,
            due_time=item.content.get("due_time"),
        ))
    
    # Fetch calendar events (EVENT type items synced from Google Calendar)
    event_items = await db.list_items(
        item_type=ItemType.EVENT,
        status=ItemStatus.ACTIVE,
        limit=20,
    )
    
    events: list[CalendarEvent] = []
    for item in event_items:
        # Filter to events happening today
        start_time = item.content.get("start_time")
        if start_time:
            try:
                event_date = parse_iso(start_time)
                if today_start <= event_date < today_end:
                    events.append(CalendarEvent(
                        time=event_date.strftime("%H:%M"),
                        event=item.content.get("title", item.content.get("text", "Event"))[:100],
                        source=item.metadata.get("source", "calendar"),
                    ))
            except (ValueError, TypeError):
                pass
    
    # Sort events by time
    events.sort(key=lambda e: e.time)
    
    # Stats - with fallback for SQLite mode
    try:
        stats = await db.get_stats()
    except AttributeError:
        # SQLite fallback doesn't have get_stats
        stats = {"active": len(active_items), "inbox": 0}
    
    return TodayResponse(
        tasks=tasks,
        events=events,
        stats={
            "active": stats.get("active", len(active_items)),
            "completed_today": len(completed_today),
            "inbox": stats.get("inbox", 0),
        },
    )


# =============================================================================
# GOALS ENDPOINT
# =============================================================================

@router.get("/goals", response_model=GoalsResponse)
async def get_goals(
    db: Annotated[DatabaseProtocol, Depends(get_database)],
) -> GoalsResponse:
    """
    Get all active goals with progress.
    
    CONTEXT:
    The "GOALS" module shows what the user is working toward. Goals have
    horizons (short/medium/long) and progress percentages. Tasks can be
    linked to goals via "supports" relations for purpose tracking.
    
    TECHNICAL:
    Returns:
        GoalsResponse with goals sorted by horizon (short → medium → long)
        
    Performance: O(n) where n = active goals, typically <50ms.
    
    COMPLEXITY: Low
    Simple read operation with sorting.
    """
    # Get active goals
    goals_items = await db.list_items(
        item_type=ItemType.GOAL,
        status=ItemStatus.ACTIVE,
        limit=50,
    )
    
    goals = []
    for item in goals_items:
        goals.append(GoalProgress(
            id=str(item.id),
            name=item.content.get("text", "Untitled goal"),
            progress=item.content.get("progress", 0),
            horizon=item.metadata.get("horizon", "medium"),
            target_date=item.content.get("target_date"),
            status=item.status.value,
        ))
    
    # Sort by horizon: short first, then medium, then long
    horizon_order = {"short": 0, "medium": 1, "long": 2}
    goals.sort(key=lambda g: horizon_order.get(g.horizon, 1))
    
    return GoalsResponse(goals=goals)
