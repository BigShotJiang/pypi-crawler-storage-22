"""
Jomni Data Export API.

GDPR Article 20 compliant data portability endpoint.
Exports all user data in a structured, machine-readable JSON format.
"""

import logging
from datetime import datetime
from typing import Annotated, Any

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from jomni.db import get_database
from jomni.db.protocol import DatabaseProtocol
from jomni.utils.datetime import utc_now

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/user", tags=["export"])


class DataExport(BaseModel):
    """Full user data export."""
    exported_at: datetime
    version: str = "1.0"
    items: list[dict[str, Any]]
    events: list[dict[str, Any]]
    relations: list[dict[str, Any]]
    tags: list[dict[str, Any]]
    services: list[dict[str, Any]]
    corrections: list[dict[str, Any]]


@router.get("/data", response_model=DataExport)
async def export_all_data(
    db: Annotated[DatabaseProtocol, Depends(get_database)],
) -> DataExport:
    """
    Export all user data in a portable format.
    
    GDPR Article 20: Right to data portability
    
    Returns a complete snapshot of:
    - All items (including soft-deleted)
    - All events (audit trail)
    - All relations between items
    - All tags
    - Connected services (without credentials)
    - AI corrections (learning data)
    
    The export is in a structured JSON format that can be
    imported into other systems or archived.
    """
    try:
        # Export all items including deleted ones
        items = await db.list_items(limit=10000, include_deleted=True)
        items_data = [item.model_dump(mode="json") for item in items]
        
        # Export events (audit trail)
        events_data = []
        if hasattr(db, 'client'):
            try:
                result = db.client.table("events").select("*").limit(50000).execute()
                events_data = result.data or []
            except Exception as e:
                logger.warning(f"Could not export events: {e}")
        
        # Export relations
        relations_data = []
        if hasattr(db, 'client'):
            try:
                result = db.client.table("relations").select("*").execute()
                relations_data = result.data or []
            except Exception as e:
                logger.warning(f"Could not export relations: {e}")
        
        # Export tags
        tags_data = []
        if hasattr(db, 'client'):
            try:
                result = db.client.table("tags").select("*").execute()
                tags_data = result.data or []
            except Exception as e:
                logger.warning(f"Could not export tags: {e}")
        
        # Export services (metadata only, no credentials)
        services_data = []
        if hasattr(db, 'client'):
            try:
                result = db.client.table("services").select(
                    "name,is_connected,connected_at,metadata"
                ).execute()
                services_data = result.data or []
            except Exception as e:
                logger.warning(f"Could not export services: {e}")
        
        # Export AI corrections
        corrections_data = []
        if hasattr(db, 'client'):
            try:
                result = db.client.table("ai_corrections").select(
                    "id,item_id,input_text,ai_suggestion,user_correction,correction_type,created_at"
                ).execute()
                corrections_data = result.data or []
            except Exception as e:
                logger.warning(f"Could not export corrections: {e}")
        
        return DataExport(
            exported_at=utc_now(),
            items=items_data,
            events=events_data,
            relations=relations_data,
            tags=tags_data,
            services=services_data,
            corrections=corrections_data,
        )
        
    except Exception as e:
        logger.error(f"Data export failed: {e}")
        raise


@router.get("/data/items")
async def export_items_only(
    db: Annotated[DatabaseProtocol, Depends(get_database)],
) -> dict[str, Any]:
    """
    Export only items data (lighter weight than full export).
    """
    items = await db.list_items(limit=10000, include_deleted=True)
    return {
        "exported_at": utc_now().isoformat(),
        "count": len(items),
        "items": [item.model_dump(mode="json") for item in items],
    }
