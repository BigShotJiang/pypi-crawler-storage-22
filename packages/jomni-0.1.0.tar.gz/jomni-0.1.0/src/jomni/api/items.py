"""
Jomni API routes for items.

All mutations automatically log events for complete audit trail.

IMPORTANT: Route order matters in FastAPI. Specific paths (/inbox) must be
defined BEFORE parameterized paths (/{item_id}) or they'll never match.
"""

from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query

from jomni.db import get_database
from jomni.db.protocol import DatabaseProtocol
from jomni.models import (
    Item, ItemCreate, ItemUpdate, ItemType, ItemStatus,
    Event, ActorType,
)


router = APIRouter(prefix="/items", tags=["items"])


# =============================================================================
# COLLECTION OPERATIONS (no path parameters)
# =============================================================================

@router.post("", response_model=Item)
async def create_item(
    data: ItemCreate,
    db: Annotated[DatabaseProtocol, Depends(get_database)],
) -> Item:
    """
    Create a new item.
    
    The item starts in the provided status (default: inbox).
    An 'created' event is automatically logged.
    """
    return await db.create_item(data, actor=(ActorType.HUMAN, "api"))


@router.get("", response_model=list[Item])
async def list_items(
    db: Annotated[DatabaseProtocol, Depends(get_database)],
    item_type: ItemType | None = None,
    status: ItemStatus | None = None,
    parent_id: UUID | None = None,
    limit: Annotated[int, Query(le=100)] = 50,
    offset: int = 0,
) -> list[Item]:
    """
    List items with optional filters.
    
    Supports filtering by type, status, and parent.
    Returns newest items first.
    """
    return await db.list_items(
        item_type=item_type,
        status=status,
        parent_id=parent_id,
        limit=limit,
        offset=offset,
    )


# =============================================================================
# SPECIFIC NAMED ROUTES (must come BEFORE /{item_id})
# =============================================================================

@router.get("/inbox", response_model=list[Item])
async def get_inbox(
    db: Annotated[DatabaseProtocol, Depends(get_database)],
    limit: Annotated[int, Query(le=100)] = 50,
) -> list[Item]:
    """
    Get all items in inbox (awaiting triage).
    
    This is the primary entry point for new captures.
    """
    return await db.get_inbox(limit=limit)


# =============================================================================
# SINGLE ITEM OPERATIONS (parameterized routes last)
# =============================================================================

@router.get("/{item_id}", response_model=Item)
async def get_item(
    item_id: UUID,
    db: Annotated[DatabaseProtocol, Depends(get_database)],
) -> Item:
    """Get a single item by ID."""
    item = await db.get_item(item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    return item


@router.patch("/{item_id}", response_model=Item)
async def update_item(
    item_id: UUID,
    data: ItemUpdate,
    db: Annotated[DatabaseProtocol, Depends(get_database)],
) -> Item:
    """
    Update an item.
    
    Only provided fields are updated.
    An 'updated' event is automatically logged with the changes.
    """
    item = await db.update_item(item_id, data, actor=(ActorType.HUMAN, "api"))
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    return item


@router.post("/{item_id}/archive", response_model=Item)
async def archive_item(
    item_id: UUID,
    db: Annotated[DatabaseProtocol, Depends(get_database)],
) -> Item:
    """
    Archive an item (soft delete).
    
    The item remains in the database but is hidden from active views.
    Can be restored by updating status back to 'active'.
    """
    item = await db.archive_item(item_id, actor=(ActorType.HUMAN, "api"))
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    return item


@router.post("/{item_id}/complete", response_model=Item)
async def complete_item(
    item_id: UUID,
    db: Annotated[DatabaseProtocol, Depends(get_database)],
) -> Item:
    """
    Mark an item as completed.
    
    Typically used for tasks and habits.
    """
    item = await db.complete_item(item_id, actor=(ActorType.HUMAN, "api"))
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    return item


@router.delete("/{item_id}")
async def delete_item(
    item_id: UUID,
    db: Annotated[DatabaseProtocol, Depends(get_database)],
    hard: bool = False,
) -> dict:
    """
    Delete an item.
    
    By default performs a soft delete (sets deleted_at timestamp).
    The item remains in the database but is hidden from active views.
    
    Set hard=true query param for permanent deletion (cannot be undone).
    """
    success = await db.delete_item(
        item_id,
        actor=(ActorType.HUMAN, "api"),
        hard_delete=hard,
    )
    if not success:
        raise HTTPException(status_code=404, detail="Item not found")
    return {"success": True, "message": f"Item {item_id} deleted", "hard_delete": hard}


@router.get("/{item_id}/history", response_model=list[Event])
async def get_item_history(
    item_id: UUID,
    db: Annotated[DatabaseProtocol, Depends(get_database)],
    limit: Annotated[int, Query(le=100)] = 50,
) -> list[Event]:
    """
    Get the audit trail for an item.
    
    CONTEXT:
    Every change to an item (create, update, archive, delete) is logged
    as an Event. This provides complete transparency into what changed,
    when, who did it, and why—essential for debugging and AI accountability.
    
    TECHNICAL:
    Returns:
        List of Events, NEWEST FIRST (descending by occurred_at).
        Each event includes:
        - action: "created", "updated", "deleted", etc.
        - changes: Dict of what changed (old vs new values)
        - actor_type: HUMAN, AI, or SYSTEM
        - actor_id: Who made the change (e.g., "api", "claude-3-5-haiku")
        - reasoning: Why the change was made (especially useful for AI)
        - confidence: AI confidence 0.0-1.0 (if actor was AI)
        
    Raises:
        HTTPException 404: If item_id doesn't exist
        
    Performance: Indexed query on (item_id, occurred_at), ~20-50ms.
    
    COMPLEXITY: Low
    """
    item = await db.get_item(item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    
    return await db.get_item_history(item_id, limit=limit)
