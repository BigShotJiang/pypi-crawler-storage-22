"""
API Keys endpoints for Jomni.

Provides scoped API key management for external service authentication.
"""

import hashlib
import secrets
from datetime import datetime, timezone
from typing import Any
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Header
from pydantic import BaseModel

from jomni.db import get_database
from jomni.db.protocol import DatabaseProtocol


router = APIRouter(prefix="/api/keys", tags=["api-keys"])


class CreateKeyRequest(BaseModel):
    name: str
    scopes: list[str] = ["capture"]
    expires_at: datetime | None = None


class CreateKeyResponse(BaseModel):
    id: str
    name: str
    key: str  # Only returned once at creation
    scopes: list[str]
    expires_at: datetime | None


class KeyInfo(BaseModel):
    id: str
    name: str
    scopes: list[str]
    created_at: datetime
    last_used_at: datetime | None
    expires_at: datetime | None


def hash_key(key: str) -> str:
    """Hash an API key for storage."""
    return hashlib.sha256(key.encode()).hexdigest()


@router.post("", response_model=CreateKeyResponse)
async def create_api_key(
    request: CreateKeyRequest,
    db: DatabaseProtocol = Depends(get_database),
):
    """Create a new API key. Returns the key once - store it safely."""
    # Generate a secure random key
    key = f"jomni_{secrets.token_urlsafe(32)}"
    key_hash = hash_key(key)
    
    # Insert into database
    result = db.client.table("api_keys").insert({
        "name": request.name,
        "key_hash": key_hash,
        "scopes": request.scopes,
        "expires_at": request.expires_at.isoformat() if request.expires_at else None,
    }).execute()
    
    row = result.data[0]
    
    return CreateKeyResponse(
        id=row["id"],
        name=row["name"],
        key=key,  # Only time we return the actual key
        scopes=row["scopes"],
        expires_at=row["expires_at"],
    )


@router.get("", response_model=list[KeyInfo])
async def list_api_keys(
    db: DatabaseProtocol = Depends(get_database),
):
    """List all API keys (without secrets)."""
    result = db.client.table("api_keys").select("*").order("created_at", desc=True).execute()
    
    return [
        KeyInfo(
            id=row["id"],
            name=row["name"],
            scopes=row["scopes"],
            created_at=row["created_at"],
            last_used_at=row["last_used_at"],
            expires_at=row["expires_at"],
        )
        for row in result.data
    ]


@router.delete("/{key_id}")
async def revoke_api_key(
    key_id: UUID,
    db: DatabaseProtocol = Depends(get_database),
):
    """Revoke (delete) an API key."""
    db.client.table("api_keys").delete().eq("id", str(key_id)).execute()
    return {"success": True, "message": f"Key {key_id} revoked"}


# =============================================================================
# MIDDLEWARE HELPER
# =============================================================================

async def validate_api_key(
    authorization: str | None = Header(None, alias="Authorization"),
    x_api_key: str | None = Header(None, alias="X-API-Key"),
    db: DatabaseProtocol = Depends(get_database),
) -> dict[str, Any] | None:
    """
    Validate API key from Authorization header or X-API-Key header.
    Returns key info dict if valid, None if no key provided.
    Raises HTTPException if key is invalid or expired.
    """
    key = None
    
    # Check Authorization: Bearer <key>
    if authorization and authorization.startswith("Bearer "):
        key = authorization[7:]
    # Check X-API-Key header
    elif x_api_key:
        key = x_api_key
    
    if not key:
        return None
    
    # Hash and lookup
    key_hash = hash_key(key)
    result = db.client.table("api_keys").select("*").eq("key_hash", key_hash).maybeSingle().execute()
    
    if not result.data:
        raise HTTPException(status_code=401, detail="Invalid API key")
    
    key_info = result.data
    
    # Check expiration
    if key_info.get("expires_at"):
        expires = datetime.fromisoformat(key_info["expires_at"].replace("Z", "+00:00"))
        if expires < datetime.now(timezone.utc):
            raise HTTPException(status_code=401, detail="API key expired")
    
    # Update last_used_at
    db.client.table("api_keys").update({
        "last_used_at": datetime.now(timezone.utc).isoformat()
    }).eq("id", key_info["id"]).execute()
    
    return key_info


def require_scope(scope: str):
    """Dependency that requires a specific scope."""
    async def check_scope(key_info: dict = Depends(validate_api_key)):
        if not key_info:
            raise HTTPException(status_code=401, detail="API key required")
        if scope not in key_info.get("scopes", []) and "admin" not in key_info.get("scopes", []):
            raise HTTPException(status_code=403, detail=f"Scope '{scope}' required")
        return key_info
    return check_scope
