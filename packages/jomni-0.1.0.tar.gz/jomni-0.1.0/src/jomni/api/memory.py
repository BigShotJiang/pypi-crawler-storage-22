"""
Jomni Memory API.

Provides memory synthesis and temporal query endpoints for AI context
window resilience. When AI sessions reset, these endpoints help rebuild
context from historical data.

TASK 5.4: Memory Synthesis — summarize patterns and preferences
TASK 5.5: Temporal Queries — query items by time range
"""

import logging
from datetime import datetime, timedelta
from typing import Annotated, Any

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field

from jomni.ai.provider import AIProvider, get_ai
from jomni.db import get_database
from jomni.db.protocol import DatabaseProtocol
from jomni.models import Item, ItemType, ItemStatus
from jomni.utils.datetime import utc_now

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/memory", tags=["memory"])


# =============================================================================
# MODELS
# =============================================================================

class MemorySynthesis(BaseModel):
    """Synthesized memory context for AI sessions."""
    generated_at: datetime
    user_patterns: dict[str, Any] = Field(
        default_factory=dict,
        description="Detected patterns (item types, tags, timing)"
    )
    active_goals: list[dict[str, Any]] = Field(
        default_factory=list,
        description="Current active goals"
    )
    recent_corrections: list[dict[str, Any]] = Field(
        default_factory=list,
        description="Recent user corrections for AI learning"
    )
    # TYPE FIX (2025-12): Changed from dict[str, int] to dict[str, Any]
    # because this contains nested dicts: {"by_type": {...}, "by_status": {...}}
    item_statistics: dict[str, Any] = Field(
        default_factory=dict,
        description="Item counts by type and status"
    )
    context_summary: str = Field(
        default="",
        description="Natural language summary for AI context"
    )


class TemporalQuery(BaseModel):
    """Items matching a temporal query."""
    query_start: datetime
    query_end: datetime
    total_count: int
    items: list[Item]
    by_type: dict[str, int]
    by_status: dict[str, int]


# =============================================================================
# ENDPOINTS
# =============================================================================

@router.get("/synthesis", response_model=MemorySynthesis)
async def synthesize_memory(
    db: Annotated[DatabaseProtocol, Depends(get_database)],
    days_back: int = Query(default=30, description="Days of history to analyze"),
) -> MemorySynthesis:
    """
    Synthesize user memory for AI context window recovery.
    
    Returns:
    - User patterns (common item types, tags, timing)
    - Active goals
    - Recent corrections for learning
    - Item statistics
    - Natural language summary
    
    Use this when starting a new AI session to rebuild context.
    """
    now = utc_now()
    cutoff = now - timedelta(days=days_back)
    
    # Get active goals
    goals = await db.list_items(
        item_type=ItemType.GOAL,
        status=ItemStatus.ACTIVE,
        limit=20,
    )
    active_goals = [
        {
            "id": str(g.id),
            "title": g.content.get("title", g.content.get("text", "")[:50]),
            "horizon": g.metadata.get("horizon", "medium"),
            "target_date": g.content.get("target_date"),
        }
        for g in goals
    ]
    
    # Get recent corrections for learning
    corrections = []
    if hasattr(db, 'client'):
        try:
            result = db.client.table("ai_corrections").select(
                "input_text,ai_suggestion,user_correction,correction_type,created_at"
            ).order("created_at", desc=True).limit(10).execute()
            corrections = result.data or []
        except Exception as e:
            logger.warning(f"Could not fetch corrections: {e}")
    
    # Get item statistics
    all_items = await db.list_items(limit=1000)
    by_type: dict[str, int] = {}
    by_status: dict[str, int] = {}
    tag_counts: dict[str, int] = {}
    
    for item in all_items:
        # Count by type
        type_key = item.item_type.value
        by_type[type_key] = by_type.get(type_key, 0) + 1
        
        # Count by status
        status_key = item.status.value
        by_status[status_key] = by_status.get(status_key, 0) + 1
        
        # Count tags
        tags = item.content.get("tags", [])
        for tag in tags:
            tag_counts[tag] = tag_counts.get(tag, 0) + 1
    
    # Detect patterns
    patterns = {
        "top_item_types": sorted(by_type.items(), key=lambda x: -x[1])[:5],
        "top_tags": sorted(tag_counts.items(), key=lambda x: -x[1])[:10],
        "total_items": len(all_items),
        "inbox_count": by_status.get("inbox", 0),
        "active_count": by_status.get("active", 0),
        "completed_count": by_status.get("completed", 0),
    }
    
    # Build context summary
    summary_parts = [
        f"User has {len(all_items)} items total.",
        f"{by_status.get('inbox', 0)} in inbox, {by_status.get('active', 0)} active.",
    ]
    
    if active_goals:
        summary_parts.append(f"{len(active_goals)} active goals.")
    
    if top_types := patterns.get("top_item_types"):
        type_str = ", ".join(f"{t[0]}({t[1]})" for t in top_types[:3])
        summary_parts.append(f"Most common: {type_str}.")
    
    if corrections:
        summary_parts.append(f"{len(corrections)} recent corrections for learning.")
    
    return MemorySynthesis(
        generated_at=now,
        user_patterns=patterns,
        active_goals=active_goals,
        recent_corrections=corrections,
        item_statistics={"by_type": by_type, "by_status": by_status},
        context_summary=" ".join(summary_parts),
    )


@router.get("/temporal", response_model=TemporalQuery)
async def query_temporal(
    db: Annotated[DatabaseProtocol, Depends(get_database)],
    days_back: int = Query(default=7, description="Days back from now"),
    item_type: ItemType | None = Query(default=None, description="Filter by type"),
    status: ItemStatus | None = Query(default=None, description="Filter by status"),
    limit: int = Query(default=100, le=500, description="Max items to return"),
) -> TemporalQuery:
    """
    Query items by time range.
    
    Returns items created/updated within the specified time window.
    Useful for "what did I capture last week?" type queries.
    """
    now = utc_now()
    start = now - timedelta(days=days_back)
    
    # Get items with filters
    items = await db.list_items(
        item_type=item_type,
        status=status,
        limit=limit,
    )
    
    # Filter by time range (created_at within window)
    filtered = [
        item for item in items
        if item.created_at >= start
    ]
    
    # Count by type and status
    by_type: dict[str, int] = {}
    by_status: dict[str, int] = {}
    
    for item in filtered:
        type_key = item.item_type.value
        by_type[type_key] = by_type.get(type_key, 0) + 1
        
        status_key = item.status.value
        by_status[status_key] = by_status.get(status_key, 0) + 1
    
    return TemporalQuery(
        query_start=start,
        query_end=now,
        total_count=len(filtered),
        items=filtered,
        by_type=by_type,
        by_status=by_status,
    )


@router.get("/timeline")
async def get_timeline(
    db: Annotated[DatabaseProtocol, Depends(get_database)],
    days_back: int = Query(default=30, description="Days of history"),
) -> dict[str, Any]:
    """
    Get a timeline view of activity.
    
    Groups items by date for visualization.
    """
    now = utc_now()
    start = now - timedelta(days=days_back)
    
    # Get recent items
    items = await db.list_items(limit=500)
    
    # Group by date
    by_date: dict[str, list[dict]] = {}
    
    for item in items:
        if item.created_at >= start:
            date_key = item.created_at.strftime("%Y-%m-%d")
            if date_key not in by_date:
                by_date[date_key] = []
            by_date[date_key].append({
                "id": str(item.id),
                "type": item.item_type.value,
                "status": item.status.value,
                "text": item.content.get("text", item.content.get("title", ""))[:100],
                "created_at": item.created_at.isoformat(),
            })
    
    return {
        "start": start.isoformat(),
        "end": now.isoformat(),
        "days": days_back,
        "total_items": sum(len(v) for v in by_date.values()),
        "by_date": dict(sorted(by_date.items(), reverse=True)),
    }
