"""
Prometheus metrics endpoint for Jomni.

Exposes /metrics endpoint for Prometheus scraping.
Provides basic application metrics without adding heavy dependencies.
"""

from fastapi import APIRouter, Request
from typing import Any
from slowapi import Limiter
from slowapi.util import get_remote_address

from jomni.config import get_settings
from jomni.utils.datetime import utc_now

router = APIRouter(tags=["monitoring"])

# LINUS-D08: Rate limit metrics to prevent information disclosure via rapid polling
limiter = Limiter(key_func=get_remote_address)


# Simple in-memory counters (reset on restart)
# For production, use prometheus-client library
_counters: dict[str, int] = {}
_gauges: dict[str, float] = {}


def increment(name: str, value: int = 1) -> None:
    """Increment a counter metric."""
    _counters[name] = _counters.get(name, 0) + value


def set_gauge(name: str, value: float) -> None:
    """Set a gauge metric."""
    _gauges[name] = value


@router.get("/metrics")
@limiter.limit("5/minute")
async def metrics(request: Request) -> str:
    """
    Expose metrics in Prometheus text format.
    
    Format: metric_name{label="value"} numeric_value
    
    Example output:
        # HELP jomni_requests_total Total API requests
        # TYPE jomni_requests_total counter
        jomni_requests_total 42
    """
    from jomni.db import get_database
    from jomni.scheduler import scheduler
    
    lines: list[str] = []
    settings = get_settings()
    
    # App info
    lines.append('# HELP jomni_info Application information')
    lines.append('# TYPE jomni_info gauge')
    lines.append(f'jomni_info{{version="0.1.0",environment="{settings.environment}"}} 1')
    
    # Database metrics
    try:
        db = get_database()
        
        # Item counts by status
        for status in ["inbox", "active", "completed", "archived", "stale"]:
            result = db.client.table("items")\
                .select("id", count="exact")\
                .eq("status", status)\
                .is_("deleted_at", "null")\
                .execute()
            count = result.count or 0
            lines.append(f'jomni_items_count{{status="{status}"}} {count}')
        
        # Total events
        events_result = db.client.table("events")\
            .select("id", count="exact")\
            .execute()
        lines.append(f'jomni_events_total {events_result.count or 0}')
        
    except Exception as e:
        lines.append(f'# Database metrics unavailable: {e}')
    
    # Scheduler metrics
    try:
        if scheduler.running:
            lines.append('jomni_scheduler_running 1')
            lines.append(f'jomni_scheduler_jobs {len(scheduler.get_jobs())}')
        else:
            lines.append('jomni_scheduler_running 0')
    except Exception:
        lines.append('jomni_scheduler_running 0')
    
    # Custom counters
    for name, value in _counters.items():
        lines.append(f'jomni_{name} {value}')
    
    # Custom gauges
    for name, value in _gauges.items():
        lines.append(f'jomni_{name} {value}')
    
    # AI token metrics
    lines.append('# HELP jomni_ai_tokens_total Total AI tokens used')
    lines.append('# TYPE jomni_ai_tokens_total counter')
    for name, value in _ai_tokens.items():
        lines.append(f'jomni_ai_tokens{{{name.replace("_", "=")}}} {value}')
    
    # AI cost metrics (in cents)
    lines.append('# HELP jomni_ai_cost_cents Estimated AI cost in USD cents')
    lines.append('# TYPE jomni_ai_cost_cents counter')
    for name, value in _ai_cost_cents.items():
        lines.append(f'jomni_ai_cost_cents{{category="{name}"}} {value:.4f}')
    
    # Timestamp
    lines.append(f'jomni_metrics_timestamp {int(utc_now().timestamp())}')
    
    return "\n".join(lines) + "\n"


# Middleware-style increment functions for common metrics
def record_request(method: str, path: str, status: int) -> None:
    """Record an API request."""
    increment("requests_total")
    increment(f"requests_{status // 100}xx")


def record_ai_call(provider: str, success: bool) -> None:
    """Record an AI API call."""
    increment("ai_calls_total")
    if success:
        increment(f"ai_calls_{provider}_success")
    else:
        increment(f"ai_calls_{provider}_failure")


# =============================================================================
# AI COST TRACKING (TASK-012)
# =============================================================================

# Token counters by provider/model/operation
_ai_tokens: dict[str, int] = {}

# Cost estimates (in USD cents for precision)
_ai_cost_cents: dict[str, float] = {}

# Approximate costs per 1K tokens (as of Dec 2024)
AI_COSTS_PER_1K = {
    # Anthropic Claude
    "claude-3-5-sonnet-20241022": {"input": 0.3, "output": 1.5},
    "claude-3-haiku-20240307": {"input": 0.025, "output": 0.125},
    # OpenAI
    "gpt-4-turbo": {"input": 1.0, "output": 3.0},
    "text-embedding-3-small": {"input": 0.002, "output": 0.0},
    "text-embedding-3-large": {"input": 0.013, "output": 0.0},
}


def record_ai_tokens(
    provider: str,
    model: str,
    operation: str,
    input_tokens: int,
    output_tokens: int,
) -> None:
    """
    Record AI token usage for cost tracking.
    
    Args:
        provider: "anthropic" or "openai"
        model: Model name (e.g., "claude-3-5-sonnet-20241022")
        operation: "triage", "chat", "embedding", etc.
        input_tokens: Number of input tokens
        output_tokens: Number of output tokens
    """
    total_tokens = input_tokens + output_tokens
    
    # Increment token counters
    _ai_tokens[f"{provider}_total"] = _ai_tokens.get(f"{provider}_total", 0) + total_tokens
    _ai_tokens[f"{provider}_{operation}"] = _ai_tokens.get(f"{provider}_{operation}", 0) + total_tokens
    _ai_tokens[f"model_{model}"] = _ai_tokens.get(f"model_{model}", 0) + total_tokens
    
    # Estimate cost
    if model in AI_COSTS_PER_1K:
        costs = AI_COSTS_PER_1K[model]
        cost_cents = (
            (input_tokens / 1000) * costs["input"] +
            (output_tokens / 1000) * costs["output"]
        )
        _ai_cost_cents["total"] = _ai_cost_cents.get("total", 0) + cost_cents
        _ai_cost_cents[provider] = _ai_cost_cents.get(provider, 0) + cost_cents
        _ai_cost_cents[operation] = _ai_cost_cents.get(operation, 0) + cost_cents


def get_ai_token_metrics() -> dict[str, int]:
    """Get all AI token metrics."""
    return _ai_tokens.copy()


def get_ai_cost_metrics() -> dict[str, float]:
    """Get estimated AI costs in USD cents."""
    return _ai_cost_cents.copy()


def get_ai_cost_usd() -> float:
    """Get total estimated AI cost in USD."""
    return _ai_cost_cents.get("total", 0) / 100

