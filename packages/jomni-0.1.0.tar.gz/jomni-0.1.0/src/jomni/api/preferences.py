"""
User Preferences API (Privacy & Consent).

Provides endpoints for managing user consent and privacy preferences.
Critical for GDPR/CCPA compliance and making Jomni sellable.

Created: 2025-12

Consent Types:
    ai_training_consent (default: OFF)
        - Must OPT-IN to allow AI corrections to be stored
        - If OFF, corrections are not stored and cannot train models
        
    analytics_consent (default: ON)
        - Anonymous usage analytics
        - Can OPT-OUT if desired
        
    data_sync_consent (default: ON)
        - Sync data to cloud
        - Can OPT-OUT to keep data local only

API Endpoints:
    GET  /preferences          - Get current preferences
    PUT  /preferences          - Update preferences
    GET  /preferences/export   - Export all preferences (GDPR)
"""

from typing import Annotated
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from jomni.db import get_database
from jomni.db.protocol import DatabaseProtocol
from jomni.db.sqlite_client import SQLiteClient
from jomni.utils.datetime import utc_now


router = APIRouter(prefix="/preferences", tags=["preferences"])


# =============================================================================
# MODELS
# =============================================================================

class UserPreferences(BaseModel):
    """
    User privacy preferences.
    
    These control what data Jomni collects and how it's used.
    Designed for GDPR/CCPA compliance.
    """
    ai_training_consent: bool = Field(
        default=False,
        description="Allow AI corrections to be stored for model improvement (OPT-IN required)"
    )
    analytics_consent: bool = Field(
        default=True,
        description="Allow anonymous usage analytics (OPT-OUT available)"
    )
    data_sync_consent: bool = Field(
        default=True,
        description="Allow data sync to cloud (OPT-OUT available)"
    )
    updated_at: datetime | None = None


class PreferencesUpdate(BaseModel):
    """Request to update preferences. All fields optional."""
    ai_training_consent: bool | None = None
    analytics_consent: bool | None = None
    data_sync_consent: bool | None = None


# =============================================================================
# PREFERENCE STORAGE FUNCTIONS
# =============================================================================

async def get_preferences(db: DatabaseProtocol) -> UserPreferences:
    """
    Get current user preferences.
    
    Creates default preferences if none exist (first run).
    Uses 'default' as the single-user ID.
    """
    if not isinstance(db, SQLiteClient):
        # For Supabase, would need different implementation
        # For now, return defaults
        return UserPreferences()
    
    from sqlalchemy import select
    
    with db.engine.connect() as conn:
        stmt = select(db.user_preferences).where(
            db.user_preferences.c.id == "default"
        )
        result = conn.execute(stmt).first()
        
        if result:
            data = dict(result._mapping)
            return UserPreferences(
                ai_training_consent=bool(data.get("ai_training_consent", 0)),
                analytics_consent=bool(data.get("analytics_consent", 1)),
                data_sync_consent=bool(data.get("data_sync_consent", 1)),
                updated_at=datetime.fromisoformat(data["updated_at"]) if data.get("updated_at") else None,
            )
        
        # No preferences yet - create defaults
        now = utc_now().isoformat()
        conn.execute(
            db.user_preferences.insert().values(
                id="default",
                ai_training_consent=0,  # OPT-IN: default OFF
                analytics_consent=1,     # OPT-OUT: default ON
                data_sync_consent=1,     # OPT-OUT: default ON
                created_at=now,
                updated_at=now,
            )
        )
        conn.commit()
        return UserPreferences()


async def update_preferences(
    db: DatabaseProtocol,
    updates: PreferencesUpdate,
) -> UserPreferences:
    """
    Update user preferences.
    
    Only updates fields that are provided (not None).
    Always updates updated_at timestamp.
    """
    if not isinstance(db, SQLiteClient):
        raise HTTPException(status_code=400, detail="Preferences only available in offline mode")
    
    # Ensure preferences exist
    await get_preferences(db)
    
    # Build update dict
    values = {"updated_at": utc_now().isoformat()}
    
    if updates.ai_training_consent is not None:
        values["ai_training_consent"] = 1 if updates.ai_training_consent else 0
    if updates.analytics_consent is not None:
        values["analytics_consent"] = 1 if updates.analytics_consent else 0
    if updates.data_sync_consent is not None:
        values["data_sync_consent"] = 1 if updates.data_sync_consent else 0
    
    with db.engine.connect() as conn:
        conn.execute(
            db.user_preferences.update()
            .where(db.user_preferences.c.id == "default")
            .values(**values)
        )
        conn.commit()
    
    return await get_preferences(db)


async def has_ai_training_consent(db: DatabaseProtocol) -> bool:
    """
    Check if user has consented to AI training data collection.
    
    ╔══════════════════════════════════════════════════════════════════════════╗
    ║ CRITICAL: This function MUST be called before storing ANY AI correction ║
    ║                                                                          ║
    ║ If this returns False, you MUST NOT store the correction.                ║
    ║ If this raises an exception, you MUST NOT store the correction.          ║
    ║                                                                          ║
    ║ FAIL-CLOSED: Any error = no consent = no storage                         ║
    ╚══════════════════════════════════════════════════════════════════════════╝
    
    Why this matters:
        - GDPR requires explicit opt-in for AI training data
        - Storing without consent = potential €20M+ fine
        - Default is OFF - user MUST actively enable this
    
    Usage:
        # CORRECT: Check before storing
        if await has_ai_training_consent(db):
            await store_correction(...)
        
        # WRONG: Storing without check
        await store_correction(...)  # NEVER DO THIS
    
    Returns:
        True ONLY if user has explicitly opted in.
        False in ALL other cases (no consent, error, unknown state).
    """
    import logging
    logger = logging.getLogger(__name__)
    
    try:
        prefs = await get_preferences(db)
        has_consent = prefs.ai_training_consent
        
        # Log for audit trail (without PII)
        logger.debug(f"AI training consent check: {'GRANTED' if has_consent else 'DENIED'}")
        
        return has_consent
        
    except Exception as e:
        # FAIL-CLOSED: Any error means NO consent
        # This protects user privacy even if something goes wrong
        logger.error(f"Consent check failed (treating as NO consent): {e}")
        return False


# =============================================================================
# API ENDPOINTS
# =============================================================================

@router.get("", response_model=UserPreferences)
async def get_user_preferences(
    db: Annotated[DatabaseProtocol, Depends(get_database)],
) -> UserPreferences:
    """
    Get current user preferences.
    
    Returns consent flags for AI training, analytics, and sync.
    Creates default preferences on first access.
    """
    return await get_preferences(db)


@router.put("", response_model=UserPreferences)
async def update_user_preferences(
    updates: PreferencesUpdate,
    db: Annotated[DatabaseProtocol, Depends(get_database)],
) -> UserPreferences:
    """
    Update user preferences.
    
    Only include fields you want to change. Example:
    
        PUT /preferences
        {"ai_training_consent": true}
        
    This enables AI training consent while leaving other settings unchanged.
    """
    return await update_preferences(db, updates)


@router.get("/export")
async def export_preferences(
    db: Annotated[DatabaseProtocol, Depends(get_database)],
) -> dict:
    """
    Export all preferences (GDPR data export).
    
    Returns complete preferences record for data portability.
    """
    prefs = await get_preferences(db)
    return {
        "preferences": prefs.model_dump(),
        "exported_at": utc_now().isoformat(),
        "note": "This is a complete export of your privacy preferences.",
    }
