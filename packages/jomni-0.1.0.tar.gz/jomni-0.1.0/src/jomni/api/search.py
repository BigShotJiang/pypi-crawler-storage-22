"""
Jomni API routes for search.

Hybrid search combining semantic similarity (vectors) with keyword matching (FTS).
Uses Reciprocal Rank Fusion to combine results without needing score normalization.
"""

import re
from typing import Annotated

from fastapi import APIRouter, Depends, Request
from slowapi import Limiter
from slowapi.util import get_remote_address

from jomni.ai.provider import AIProvider, get_ai
from jomni.db import get_database
from jomni.db.protocol import DatabaseProtocol
from jomni.models import (
    Item, ItemType, ItemStatus,
    SearchRequest, SearchResponse, SearchResult,
)


def escape_like_pattern(s: str) -> str:
    """
    Escape ILIKE/LIKE special characters to prevent wildcard injection.
    
    Without escaping, user input containing % or _ could match unintended patterns:
    - '%' matches any sequence of characters
    - '_' matches any single character
    - '\\' is the escape character itself
    
    Example: searching for "100%" without escaping would match everything.
    """
    return re.sub(r'([%_\\])', r'\\\\\\1', s)


router = APIRouter(prefix="/search", tags=["search"])

# LINUS-D06: Per-endpoint rate limit (higher for search since less expensive)
limiter = Limiter(key_func=get_remote_address)


def reciprocal_rank_fusion(
    rankings: list[list[tuple[str, float]]],
    k: int = 60,
) -> list[tuple[str, float]]:
    """
    Combine multiple search rankings into one unified ranking.
    
    CONTEXT:
    Jomni search combines semantic (vector) and keyword (BM25) results.
    These have different score scales (cosine similarity 0-1 vs BM25 0-∞).
    RRF combines them by POSITION, not score, avoiding normalization issues.
    
    EXAMPLE:
    Vector search returns: [("item_a", 0.95), ("item_b", 0.80)]
    Keyword search returns: [("item_b", 12.5), ("item_c", 8.2)]
    
    RRF produces: [("item_b", 0.032), ("item_a", 0.016), ("item_c", 0.016)]
    item_b ranks high in both sources, so it wins.
    
    TUNING THE k PARAMETER:
    - k=60 is standard in IR literature (Cormack et al., 2009)
    - Lower k (e.g., 10): Top positions dominate more strongly
    - Higher k (e.g., 200): Flatter curve, less emphasis on top positions
    - Most use cases don't need to change k=60
    
    TECHNICAL:
    Args:
        rankings: List of rankings. Each ranking is list of (item_id, score).
                  Scores are used only for ordering within each ranking.
        k: Smoothing constant. Higher k = less weight to top positions.
           
    Returns:
        Fused ranking as (item_id, fused_score). Scores are relative,
        typically range 0.01-0.05 for top results.
        
    Performance: O(n) where n = total items across all rankings.
    
    COMPLEXITY: Medium
    Core search ranking logic. Changing k affects result quality.
    """
    scores: dict[str, float] = {}
    
    for ranking in rankings:
        for rank, (item_id, _) in enumerate(ranking):
            if item_id not in scores:
                scores[item_id] = 0.0
            scores[item_id] += 1.0 / (k + rank + 1)  # +1 because rank is 0-indexed
    
    # Sort by fused score descending
    return sorted(scores.items(), key=lambda x: x[1], reverse=True)


@router.post("", response_model=SearchResponse)
@limiter.limit("30/minute")
async def search_items(
    request: Request,  # Required for rate limiter (must be named 'request')
    search_request: SearchRequest,
    db: Annotated[DatabaseProtocol, Depends(get_database)],
    ai: Annotated[AIProvider, Depends(get_ai)],
) -> SearchResponse:
    """
    Search items using hybrid semantic + keyword matching.
    
    The search combines:
    - Semantic similarity via vector embeddings (if semantic=True)
    - Keyword matching via full-text search (if keyword=True)
    
    Results are fused using Reciprocal Rank Fusion for robust ranking
    that doesn't depend on score normalization.
    """
    rankings: list[list[tuple[str, float]]] = []
    items_by_id: dict[str, Item] = {}
    
    # Semantic search using embeddings
    if search_request.semantic:
        query_embedding, _ = await ai.embed(search_request.query)
        semantic_results = await db.semantic_search(
            embedding=query_embedding,
            limit=search_request.limit * 2,  # Fetch more for fusion
            item_types=search_request.item_types,
            statuses=search_request.statuses,
        )
        
        semantic_ranking = []
        for item, score in semantic_results:
            items_by_id[str(item.id)] = item
            semantic_ranking.append((str(item.id), score))
        
        if semantic_ranking:
            rankings.append(semantic_ranking)
    
    # Keyword search using full-text search
    if search_request.keyword:
        # Build keyword search query
        keyword_results = await _keyword_search(
            db=db,
            query=search_request.query,
            item_types=search_request.item_types,
            statuses=search_request.statuses,
            limit=search_request.limit * 2,
        )
        
        keyword_ranking = []
        for item, score in keyword_results:
            items_by_id[str(item.id)] = item
            keyword_ranking.append((str(item.id), score))
        
        if keyword_ranking:
            rankings.append(keyword_ranking)
    
    # Fuse rankings
    if rankings:
        fused = reciprocal_rank_fusion(rankings)
    else:
        fused = []
    
    # Build response with fused scores
    results = []
    for item_id, score in fused[:search_request.limit]:
        item = items_by_id.get(item_id)
        if item:
            results.append(SearchResult(
                item=item,
                score=score,
                highlights=_generate_highlights(item, search_request.query),
            ))
    
    return SearchResponse(
        results=results,
        total=len(fused),
        query=search_request.query,
    )


async def _keyword_search(
    db: DatabaseProtocol,
    query: str,
    item_types: list[ItemType] | None,
    statuses: list[ItemStatus] | None,
    limit: int,
) -> list[tuple[Item, float]]:
    """
    Perform keyword search.
    
    For Supabase: Uses FTS RPC function with GIN-indexed tsvector.
    For SQLite: Uses LIKE-based text matching via SQLAlchemy.
    """
    import logging
    from jomni.db.sqlite_client import SQLiteClient
    
    logger = logging.getLogger(__name__)
    
    # Check if we're using SQLite (offline mode)
    if isinstance(db, SQLiteClient):
        return await _sqlite_keyword_search(db, query, item_types, statuses, limit)
    
    # Supabase path: Use FTS RPC function
    params = {
        "query_text": query,
        "result_limit": limit,
    }
    
    if item_types:
        params["filter_types"] = [t.value for t in item_types]
    if statuses:
        params["filter_statuses"] = [s.value for s in statuses]
    
    try:
        # Use FTS RPC function (requires 003_fts.sql migration)
        result = db.client.rpc("search_items_fts", params).execute()
        
        items_with_scores = []
        for row in result.data:
            # Separate rank from item fields
            rank = row.pop("rank", 0.0)
            item = Item(**row)
            items_with_scores.append((item, float(rank)))
        
        return items_with_scores
        
    except Exception as e:
        # Fall back to ILIKE if FTS not available (migration not run)
        logger.warning(f"FTS search failed, falling back to ILIKE: {e}")
        
        escaped_query = escape_like_pattern(query)
        results = db.client.table("items")\
            .select("*")\
            .ilike("content->>text", f"%{escaped_query}%")
        
        if item_types:
            results = results.in_("item_type", [t.value for t in item_types])
        if statuses:
            results = results.in_("status", [s.value for s in statuses])
        
        results = results.is_("deleted_at", "null").limit(limit).execute()
        
        # Simple scoring based on position of match
        items_with_scores = []
        for row in results.data:
            item = Item(**row)
            text = item.content.get("text", "").lower()
            query_lower = query.lower()
            
            pos = text.find(query_lower)
            score = 1.0 / (1.0 + pos) if pos >= 0 else 0.0
            items_with_scores.append((item, score))
        
        return sorted(items_with_scores, key=lambda x: x[1], reverse=True)


async def _sqlite_keyword_search(
    db,  # SQLiteClient
    query: str,
    item_types: list[ItemType] | None,
    statuses: list[ItemStatus] | None,
    limit: int,
) -> list[tuple[Item, float]]:
    """
    SQLite-specific keyword search using SQLAlchemy LIKE.
    
    SQLite doesn't have Supabase's .client API, so we use
    the SQLAlchemy engine and tables directly.
    """
    from sqlalchemy import select, and_, func
    
    escaped_query = escape_like_pattern(query)
    
    with db.engine.connect() as conn:
        # Build base query - search in content JSON field
        # SQLite JSON: json_extract(content, '$.text')
        stmt = select(db.items).where(
            and_(
                db.items.c.deleted_at.is_(None),
                func.json_extract(db.items.c.content, '$.text').like(f"%{escaped_query}%")
            )
        )
        
        # Apply type filter
        if item_types:
            type_values = [t.value for t in item_types]
            stmt = stmt.where(db.items.c.item_type.in_(type_values))
        
        # Apply status filter
        if statuses:
            status_values = [s.value for s in statuses]
            stmt = stmt.where(db.items.c.status.in_(status_values))
        
        stmt = stmt.limit(limit)
        
        results = conn.execute(stmt).fetchall()
        
        # Score by position of match
        items_with_scores = []
        for row in results:
            item = Item(**row._mapping)
            text = item.content.get("text", "").lower()
            query_lower = query.lower()
            
            pos = text.find(query_lower)
            score = 1.0 / (1.0 + pos) if pos >= 0 else 0.0
            items_with_scores.append((item, score))
        
        return sorted(items_with_scores, key=lambda x: x[1], reverse=True)


def _generate_highlights(item: Item, query: str) -> dict[str, str]:
    """
    Generate highlighted snippets showing query matches.
    
    Returns dict mapping field names to highlighted snippets.
    """
    highlights = {}
    text = item.content.get("text", "")
    
    if not text or not query:
        return highlights
    
    # Find the query in the text (case-insensitive)
    lower_text = text.lower()
    lower_query = query.lower()
    pos = lower_text.find(lower_query)
    
    if pos >= 0:
        # Extract snippet around the match
        start = max(0, pos - 50)
        end = min(len(text), pos + len(query) + 50)
        
        snippet = text[start:end]
        if start > 0:
            snippet = "..." + snippet
        if end < len(text):
            snippet = snippet + "..."
        
        highlights["text"] = snippet
    
    return highlights


@router.get("/suggest")
async def search_suggestions(
    q: str,
    db: Annotated[DatabaseProtocol, Depends(get_database)],
    limit: int = 5,
) -> list[str]:
    """
    Get search suggestions based on partial query.
    
    Returns list of suggested completions based on existing items.
    Useful for autocomplete in search UI.
    """
    # Simple prefix matching on recent items
    # TODO: Implement proper autocomplete with frequency weighting
    
    escaped_q = escape_like_pattern(q)
    results = db.client.table("items")\
        .select("content->>text")\
        .ilike("content->>text", f"{escaped_q}%")\
        .limit(limit)\
        .execute()
    
    suggestions = []
    for row in results.data:
        text = row.get("text", "")
        if text:
            # Take first line or first 50 chars
            suggestion = text.split("\n")[0][:50]
            if suggestion not in suggestions:
                suggestions.append(suggestion)
    
    return suggestions
