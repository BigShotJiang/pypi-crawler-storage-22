"""
Session inference for Jomni.

Runs end-of-session inference to extract implicit memories from conversations.
Triggered by session end (toggle off, timeout, new session).
"""

import json
import logging
from uuid import UUID

from jomni.ai.provider import AIProvider, get_ai
from jomni.db.protocol import DatabaseProtocol
from jomni.db.repositories.sessions import SessionRepository, MessageRepository
from jomni.models import (
    ChatSessionUpdate, ChatMessageCreate, MessageRole,
    ItemCreate, ItemType, ItemStatus, ActorType
)

logger = logging.getLogger(__name__)


INFERENCE_PROMPT = """Review this conversation and identify any lasting facts or patterns you learned about the user.

Focus on:
- Explicit preferences they stated
- Patterns in their behavior or requests
- Goals or projects they mentioned
- Personal facts (schedule preferences, work style, etc.)

Return a JSON array of inferences. Each should have:
- "fact": A concise statement of what you learned
- "confidence": 0.0-1.0 how confident you are
- "evidence": Brief quote or reference from the conversation

If nothing significant was learned, return an empty array: []

IMPORTANT: Only include genuinely useful, lasting observations. Skip transactional exchanges.

Conversation:
{conversation}

Respond with ONLY valid JSON, no markdown or explanation."""


async def run_session_inference(
    session_id: UUID,
    db: DatabaseProtocol,
    ai: AIProvider | None = None,
) -> list[dict]:
    """
    Run end-of-session inference to extract implicit memories.
    
    Args:
        session_id: The session to analyze
        db: Database client
        ai: AI provider (uses default if not provided)
        
    Returns:
        List of created memory items
    """
    if ai is None:
        ai = get_ai()
    
    session_repo = SessionRepository(db.client)
    message_repo = MessageRepository(db.client)
    
    # Load session
    session = await session_repo.get_by_id(session_id)
    if not session:
        logger.warning(f"Session {session_id} not found for inference")
        return []
    
    if session.inference_complete:
        logger.debug(f"Session {session_id} already had inference run")
        return []
    
    # Load all messages (not just last 20)
    messages = await message_repo.get_session_history(session_id, limit=100)
    
    if not messages:
        logger.debug(f"Session {session_id} has no messages")
        # Mark complete anyway
        await session_repo.update(session_id, ChatSessionUpdate(inference_complete=True))
        return []
    
    # Format conversation for Claude
    conversation = ""
    for msg in messages:
        role = msg.role.value if hasattr(msg.role, 'value') else msg.role
        text = msg.content.get("text", "") if isinstance(msg.content, dict) else str(msg.content)
        conversation += f"{role.upper()}: {text}\n\n"
    
    # Call Claude for inference
    try:
        prompt = INFERENCE_PROMPT.format(conversation=conversation)
        
        response = await ai.anthropic.messages.create(
            model=ai.triage_model,  # Use cheaper model for inference
            max_tokens=1024,
            messages=[{"role": "user", "content": prompt}]
        )
        
        # Parse the response
        response_text = response.content[0].text if response.content else "[]"
        
        # Clean up potential markdown formatting
        response_text = response_text.strip()
        if response_text.startswith("```"):
            response_text = response_text.split("\n", 1)[1]
            if response_text.endswith("```"):
                response_text = response_text[:-3]
            response_text = response_text.strip()
        
        inferences = json.loads(response_text)
        
        if not isinstance(inferences, list):
            inferences = []
            
    except Exception as e:
        logger.error(f"Inference failed for session {session_id}: {e}", exc_info=True)
        # Mark complete anyway to avoid retrying
        await session_repo.update(session_id, ChatSessionUpdate(inference_complete=True))
        return []
    
    # Store inferences as implicit memory items
    actor = (ActorType.AI, "session:inference")
    created_memories = []
    
    for inference in inferences:
        if not isinstance(inference, dict) or "fact" not in inference:
            continue
        
        fact = inference.get("fact", "")
        confidence = inference.get("confidence", 0.5)
        evidence = inference.get("evidence", "")
        
        try:
            item = await db.create_item(
                ItemCreate(
                    item_type=ItemType.NOTE,
                    status=ItemStatus.ACTIVE,
                    content={
                        "text": fact,
                        "memory_type": "implicit",
                        "evidence": evidence,
                    },
                    metadata={
                        "source": "session_inference",
                        "memory": True,
                        "source_session_id": str(session_id),
                        "confidence": confidence,
                    },
                ),
                actor=actor,
                reasoning=f"Inferred from conversation: {evidence[:100]}",
                confidence=confidence,
            )
            
            # Tag it
            await db.add_tags_to_item(item.id, ["memory", "implicit"])
            
            created_memories.append({
                "id": str(item.id),
                "fact": fact,
                "confidence": confidence,
            })
            
            logger.info(f"Created implicit memory: {fact[:50]}... (confidence: {confidence})")
            
        except Exception as e:
            logger.error(f"Failed to create memory for '{fact[:30]}...': {e}")
    
    # Mark session as inference complete
    await session_repo.update(session_id, ChatSessionUpdate(inference_complete=True))
    
    logger.info(f"Session {session_id} inference complete: {len(created_memories)} memories created")
    
    return created_memories


async def check_idle_sessions_and_run_inference(
    db: DatabaseProtocol,
    idle_minutes: int = 10,
) -> int:
    """
    Check for idle sessions and run inference on them.
    
    This is meant to be called by a scheduler job.
    
    Args:
        db: Database client
        idle_minutes: How long a session must be idle to trigger inference
        
    Returns:
        Number of sessions processed
    """
    session_repo = SessionRepository(db.client)
    
    idle_sessions = await session_repo.get_idle_sessions(idle_minutes=idle_minutes)
    
    if not idle_sessions:
        return 0
    
    logger.info(f"Found {len(idle_sessions)} idle sessions for inference")
    
    processed = 0
    for session in idle_sessions:
        try:
            await run_session_inference(session.id, db)
            processed += 1
        except Exception as e:
            logger.error(f"Failed to run inference on session {session.id}: {e}")
    
    return processed
