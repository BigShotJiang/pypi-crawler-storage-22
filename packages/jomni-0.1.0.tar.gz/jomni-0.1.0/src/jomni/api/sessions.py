"""
Session management API endpoints.

Provides endpoints for:
- Ending a session (with or without inference)
- Getting session status
- Listing memories
"""

import logging
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from jomni.db import get_database
from jomni.db.protocol import DatabaseProtocol
from jomni.db.repositories.sessions import SessionRepository, MessageRepository
from jomni.models import ChatSession, ChatSessionUpdate, SessionMode
from jomni.api.session_inference import run_session_inference
from jomni.ai.provider import get_ai

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/sessions", tags=["sessions"])


# =============================================================================
# REQUEST/RESPONSE MODELS
# =============================================================================

class EndSessionRequest(BaseModel):
    """Request to end a session."""
    session_id: UUID
    run_inference: bool = False  # If true, run end-of-session inference


class SessionResponse(BaseModel):
    """Session status response."""
    id: UUID
    mode: str
    message_count: int
    summary: str | None
    inference_complete: bool
    created_at: str
    last_activity: str


class InferenceResult(BaseModel):
    """Result of running session inference."""
    session_id: UUID
    memories_created: int
    memories: list[dict]


# =============================================================================
# ENDPOINTS
# =============================================================================

@router.post("/end")
async def end_session(
    request: EndSessionRequest,
    db: DatabaseProtocol = Depends(get_database),
) -> dict:
    """
    End a chat session.
    
    If run_inference is True, runs end-of-session learning before closing.
    This is the "End & Remember" action.
    """
    session_repo = SessionRepository(db.client)
    
    session = await session_repo.get_by_id(request.session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    result = {"session_id": str(request.session_id), "action": "ended"}
    
    if request.run_inference and not session.inference_complete:
        try:
            memories = await run_session_inference(request.session_id, db)
            result["inference_run"] = True
            result["memories_created"] = len(memories)
            result["memories"] = memories
        except Exception as e:
            logger.error(f"Inference failed: {e}")
            result["inference_run"] = False
            result["error"] = str(e)
    
    # Mark session as complete
    await session_repo.update(
        request.session_id,
        ChatSessionUpdate(inference_complete=True)
    )
    
    return result


@router.get("/{session_id}")
async def get_session(
    session_id: UUID,
    db: DatabaseProtocol = Depends(get_database),
) -> SessionResponse:
    """Get session status and info."""
    session_repo = SessionRepository(db.client)
    message_repo = MessageRepository(db.client)
    
    session = await session_repo.get_by_id(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    message_count = await message_repo.count_session_messages(session_id)
    
    return SessionResponse(
        id=session.id,
        mode=session.mode.value if hasattr(session.mode, 'value') else session.mode,
        message_count=message_count,
        summary=session.summary,
        inference_complete=session.inference_complete,
        created_at=session.created_at.isoformat(),
        last_activity=session.last_activity.isoformat(),
    )


@router.post("/{session_id}/inference")
async def run_inference(
    session_id: UUID,
    db: DatabaseProtocol = Depends(get_database),
) -> InferenceResult:
    """
    Manually trigger inference for a session.
    
    Useful for "End & Remember" button or manual review.
    """
    session_repo = SessionRepository(db.client)
    
    session = await session_repo.get_by_id(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    if session.inference_complete:
        return InferenceResult(
            session_id=session_id,
            memories_created=0,
            memories=[]
        )
    
    try:
        memories = await run_session_inference(session_id, db)
        return InferenceResult(
            session_id=session_id,
            memories_created=len(memories),
            memories=memories
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/new")
async def create_session(
    db: DatabaseProtocol = Depends(get_database),
) -> dict:
    """Create a new session explicitly."""
    from jomni.models import ChatSessionCreate
    
    session_repo = SessionRepository(db.client)
    session = await session_repo.create(ChatSessionCreate(mode=SessionMode.PERSISTENT))
    
    return {
        "session_id": str(session.id),
        "mode": session.mode.value,
        "created_at": session.created_at.isoformat(),
    }
