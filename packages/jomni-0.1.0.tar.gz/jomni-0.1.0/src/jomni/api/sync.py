"""
Sync API Endpoints.

Provides REST endpoints for offline-first sync operations between SQLite (local)
and Supabase (cloud). Part of the sync engine implemented in Phase 1-3.

Created: 2025-12

API Endpoints:
    GET  /sync/status              - Get pending/conflict counts
    POST /sync/push                - Push local changes to cloud
    POST /sync/pull                - Pull cloud changes to local
    POST /sync/all                 - Full sync (pull then push)
    GET  /sync/conflicts           - List items with conflicts
    GET  /sync/conflicts/{id}      - Get conflict detail with diff
    POST /sync/conflicts/{id}/resolve - Resolve with strategy
    POST /sync/realtime/start      - Start live sync (Supabase Realtime)
    POST /sync/realtime/stop       - Stop live sync
    GET  /sync/realtime/status     - Check if realtime is running

Note:
    These endpoints only work in SQLite (offline) mode. In Supabase mode,
    they return 400 errors since sync is not needed when directly connected.
"""

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from jomni.db import get_database
from jomni.db.protocol import DatabaseProtocol
from jomni.db.sqlite_client import SQLiteClient


router = APIRouter(prefix="/sync", tags=["sync"])


class SyncStatus(BaseModel):
    """Current sync status."""
    pending_count: int
    conflict_count: int
    last_sync: str | None


class SyncResult(BaseModel):
    """Result of sync operation."""
    pull: dict
    push: dict
    last_sync: str


class ConflictResolution(BaseModel):
    """Conflict resolution request."""
    resolution: str  # 'local' or 'cloud'


@router.get("/status", response_model=SyncStatus)
async def get_sync_status(
    db: Annotated[DatabaseProtocol, Depends(get_database)],
) -> SyncStatus:
    """
    Get current sync status.
    
    Returns count of pending items and conflicts.
    """
    if not isinstance(db, SQLiteClient):
        raise HTTPException(
            status_code=400,
            detail="Sync only available in offline mode"
        )
    
    from jomni.sync import SyncManager
    
    sync = SyncManager(db)
    
    return SyncStatus(
        pending_count=sync.get_pending_count(),
        conflict_count=sync.get_conflict_count(),
        last_sync=sync._last_sync_time,
    )


@router.post("/push")
async def push_changes(
    db: Annotated[DatabaseProtocol, Depends(get_database)],
) -> dict:
    """
    Push pending local changes to cloud.
    
    Only pushes items that have been modified locally.
    """
    if not isinstance(db, SQLiteClient):
        raise HTTPException(
            status_code=400,
            detail="Sync only available in offline mode"
        )
    
    from jomni.sync import SyncManager
    
    sync = SyncManager(db)
    return await sync.push_only()


@router.post("/pull")
async def pull_changes(
    db: Annotated[DatabaseProtocol, Depends(get_database)],
    since: str | None = None,
) -> dict:
    """
    Pull changes from cloud.
    
    Args:
        since: Optional ISO timestamp - only pull items updated after this
    """
    if not isinstance(db, SQLiteClient):
        raise HTTPException(
            status_code=400,
            detail="Sync only available in offline mode"
        )
    
    from jomni.sync import SyncManager
    
    sync = SyncManager(db)
    return await sync.pull_only(since=since)


@router.post("/all", response_model=SyncResult)
async def sync_all(
    db: Annotated[DatabaseProtocol, Depends(get_database)],
) -> SyncResult:
    """
    Perform full sync: pull then push.
    
    This is the recommended sync operation - it pulls cloud changes
    first to detect conflicts, then pushes local changes.
    """
    if not isinstance(db, SQLiteClient):
        raise HTTPException(
            status_code=400,
            detail="Sync only available in offline mode"
        )
    
    from jomni.sync import SyncManager
    
    sync = SyncManager(db)
    result = await sync.sync_all()
    
    return SyncResult(**result)


@router.get("/conflicts")
async def get_conflicts(
    db: Annotated[DatabaseProtocol, Depends(get_database)],
) -> list[dict]:
    """
    Get all items with sync conflicts.
    
    Conflicts occur when both local and cloud have changes since last sync.
    Each conflict includes a diff showing what changed.
    """
    if not isinstance(db, SQLiteClient):
        raise HTTPException(
            status_code=400,
            detail="Sync only available in offline mode"
        )
    
    from jomni.sync import SyncManager
    
    sync = SyncManager(db)
    conflicts = sync.get_conflicts()
    
    # Enrich with diff info if we have cloud access
    try:
        from jomni.sync import ConflictResolver
        resolver = ConflictResolver()
        
        for conflict in conflicts:
            sync_id = conflict.get("sync_id")
            if sync_id:
                try:
                    cloud_item = sync.cloud_client.table("items").select("*").eq("id", sync_id).single().execute()
                    if cloud_item.data:
                        conflict["_cloud_version"] = cloud_item.data
                        conflict["_diff"] = resolver.get_diff(conflict, cloud_item.data)
                except Exception:
                    pass  # Cloud not available
    except Exception:
        pass  # No cloud access
    
    return conflicts


@router.get("/conflicts/{item_id}")
async def get_conflict_detail(
    item_id: str,
    db: Annotated[DatabaseProtocol, Depends(get_database)],
) -> dict:
    """
    Get detailed conflict info for a specific item.
    
    Returns local version, cloud version, and diff.
    """
    if not isinstance(db, SQLiteClient):
        raise HTTPException(
            status_code=400,
            detail="Sync only available in offline mode"
        )
    
    from sqlalchemy import select
    
    # Get local item
    with db.engine.connect() as conn:
        stmt = select(db.items).where(db.items.c.id == item_id)
        local = conn.execute(stmt).first()
    
    if not local:
        raise HTTPException(status_code=404, detail="Item not found")
    
    local_item = dict(local._mapping)
    
    if local_item.get("sync_status") != "conflict":
        raise HTTPException(status_code=400, detail="Item is not in conflict")
    
    # Get cloud version
    sync_id = local_item.get("sync_id")
    cloud_item = None
    diff = None
    
    if sync_id:
        try:
            from jomni.sync import SyncManager, ConflictResolver
            sync = SyncManager(db)
            result = sync.cloud_client.table("items").select("*").eq("id", sync_id).single().execute()
            if result.data:
                cloud_item = result.data
                resolver = ConflictResolver()
                diff = resolver.get_diff(local_item, cloud_item)
        except Exception as e:
            cloud_item = {"error": str(e)}
    
    return {
        "local": local_item,
        "cloud": cloud_item,
        "diff": diff,
    }


@router.post("/conflicts/{item_id}/resolve")
async def resolve_conflict(
    item_id: str,
    resolution: ConflictResolution,
    db: Annotated[DatabaseProtocol, Depends(get_database)],
) -> dict:
    """
    Resolve a sync conflict.
    
    Args:
        item_id: ID of conflicting item
        resolution: Strategy to use:
            - 'local' or 'local_wins': Keep local version
            - 'cloud' or 'cloud_wins': Use cloud version
            - 'last_write_wins': Newer timestamp wins
            - 'field_merge': Merge non-conflicting fields
    """
    if not isinstance(db, SQLiteClient):
        raise HTTPException(
            status_code=400,
            detail="Sync only available in offline mode"
        )
    
    # Map simple names to full strategy names
    strategy_map = {
        "local": "local_wins",
        "cloud": "cloud_wins",
        "local_wins": "local_wins",
        "cloud_wins": "cloud_wins",
        "last_write_wins": "last_write_wins",
        "field_merge": "field_merge",
    }
    
    strategy = strategy_map.get(resolution.resolution)
    if not strategy:
        raise HTTPException(
            status_code=400,
            detail=f"Unknown resolution: {resolution.resolution}. Use: local, cloud, last_write_wins, or field_merge"
        )
    
    from jomni.sync import SyncManager
    
    sync = SyncManager(db)
    success = await sync.resolve_conflict(item_id, strategy)
    
    if not success:
        raise HTTPException(status_code=404, detail="Item not found")
    
    return {"status": "resolved", "resolution": strategy}


# =============================================================================
# REALTIME SYNC (Phase 3 - Added 2025-12)
# Live sync via Supabase Realtime + network reconnect monitoring
# =============================================================================

# Global instances for realtime services (singleton pattern)
# These persist across requests to maintain WebSocket connections
_realtime_sync = None
_network_monitor = None


@router.post("/realtime/start")
async def start_realtime_sync(
    db: Annotated[DatabaseProtocol, Depends(get_database)],
) -> dict:
    """
    Start realtime sync.
    
    Subscribes to Supabase Realtime for live updates.
    """
    global _realtime_sync, _network_monitor
    
    if not isinstance(db, SQLiteClient):
        raise HTTPException(
            status_code=400,
            detail="Realtime sync only available in offline mode"
        )
    
    from jomni.sync import SyncManager, RealtimeSync, NetworkMonitor
    
    sync = SyncManager(db)
    
    # Start realtime sync
    _realtime_sync = RealtimeSync(sync)
    started = await _realtime_sync.start()
    
    # Start network monitor
    _network_monitor = NetworkMonitor(sync)
    await _network_monitor.start()
    
    return {
        "status": "started" if started else "failed",
        "realtime": started,
        "network_monitor": True,
    }


@router.post("/realtime/stop")
async def stop_realtime_sync() -> dict:
    """
    Stop realtime sync.
    """
    global _realtime_sync, _network_monitor
    
    if _realtime_sync:
        await _realtime_sync.stop()
        _realtime_sync = None
    
    if _network_monitor:
        await _network_monitor.stop()
        _network_monitor = None
    
    return {"status": "stopped"}


@router.get("/realtime/status")
async def get_realtime_status() -> dict:
    """
    Get realtime sync status.
    """
    global _realtime_sync, _network_monitor
    
    return {
        "realtime_running": _realtime_sync.is_running if _realtime_sync else False,
        "network_monitor_running": _network_monitor._running if _network_monitor else False,
    }
