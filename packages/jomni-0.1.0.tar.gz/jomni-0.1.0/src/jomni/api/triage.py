"""
Jomni API routes for AI triage.

The triage system classifies raw captures into appropriate item types
with confidence-based routing for human review.
"""

from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request
from slowapi import Limiter
from slowapi.util import get_remote_address

from jomni.ai.provider import AIProvider, get_ai
from jomni.db import get_database
from jomni.db.protocol import DatabaseProtocol
from jomni.models import (
    Item, ItemCreate, ItemUpdate, ItemType, ItemStatus, ActorType,
    TriageRequest, TriageResponse, TriageSuggestion,
)


router = APIRouter(prefix="/triage", tags=["triage"])

# LINUS-D06: Per-endpoint rate limit for expensive AI operations
limiter = Limiter(key_func=get_remote_address)


@router.post("", response_model=TriageResponse)
@limiter.limit("10/minute")
async def triage_capture(
    request: Request,  # Required for rate limiter (must be named 'request')
    triage_request: TriageRequest,
    db: Annotated[DatabaseProtocol, Depends(get_database)],
    ai: Annotated[AIProvider, Depends(get_ai)],
) -> TriageResponse:
    """
    Triage a raw capture into the appropriate item type.
    
    The AI analyzes the text and returns a classification with confidence.
    Based on confidence thresholds:
    - High (>0.90): Auto-accepts and creates the item
    - Medium (0.70-0.90): Returns suggestion for user review
    - Low (<0.70): Returns suggestion with alternatives
    
    If auto_accepted is True, the response includes the created item.
    """
    # Build context from similar items and past corrections
    context = await ai.get_triage_context(triage_request.text, db)
    
    # Get similar corrections for few-shot learning
    if triage_request.text:
        embedding, _ = await ai.embed(triage_request.text)
        similar_corrections = await db.get_similar_corrections(
            embedding,
            correction_type="classification",
            limit=5,
        )
    else:
        similar_corrections = []
    
    # Merge user-provided context with retrieved context
    full_context = {**context, **triage_request.context}
    
    # Get AI suggestion with graceful degradation
    try:
        suggestion = await ai.triage(
            TriageRequest(text=triage_request.text, context=full_context),
            few_shot_examples=similar_corrections,
        )
        ai_failed = False
    except Exception as ai_error:
        # AI failed - create a fallback suggestion for human review
        # LINUS-D02: Don't leak internal error details in reasoning/metadata
        import logging
        logging.getLogger(__name__).error(f"AI triage failed: {ai_error}")
        
        suggestion = TriageSuggestion(
            item_type=ItemType.CAPTURE,  # Keep as raw capture
            confidence=0.0,
            reasoning="AI temporarily unavailable",  # Generic, no internals
            suggested_tags=["needs-human-review"],
            alternatives=[],
        )
        ai_failed = True
    
    # Determine if we should auto-accept
    auto_accepted = suggestion.confidence >= ai.auto_accept_threshold and not ai_failed
    created_item = None
    
    if ai_failed:
        # AI failed - create item in PENDING_REVIEW status for human triage
        created_item = await db.create_item(
            ItemCreate(
                item_type=ItemType.CAPTURE,
                status=ItemStatus.PENDING_REVIEW,
                content={
                    "text": triage_request.text,
                    "tags": ["needs-human-review"],
                },
                metadata={
                    "needs_human_triage": True,  # No ai_error field
                },
            ),
            actor=(ActorType.SYSTEM, "triage-fallback"),
            reasoning="AI unavailable - awaiting human review",
        )
    elif auto_accepted:
        # LINUS-D09: Log suspiciously high confidence for overconfidence detection
        if suggestion.confidence > 0.98:
            import logging
            logging.getLogger(__name__).warning(
                f"Unusually high AI confidence ({suggestion.confidence:.2f}) for triage. "
                f"Type: {suggestion.item_type.value}, Text: {request.text[:50]}..."
            )
        
        # Create the item automatically
        created_item = await db.create_item(
            ItemCreate(
                item_type=suggestion.item_type,
                status=ItemStatus.ACTIVE,  # Skip inbox since triaged
                content={
                    "text": triage_request.text,
                    "tags": suggestion.suggested_tags,
                },
            ),
            actor=(ActorType.AI, ai.triage_model),
            reasoning=suggestion.reasoning,
            confidence=suggestion.confidence,
        )
        
        # Store the embedding for future search
        embedding, source_hash = await ai.embed(request.text)
        from jomni.models import EmbeddingCreate
        await db.store_embedding(EmbeddingCreate(
            item_id=created_item.id,
            model_name=ai.embedding_model,
            model_version="v1",
            dimensions=ai.embedding_dimensions,
            embedding=embedding,
            source_hash=source_hash,
        ))
    
    return TriageResponse(
        suggestion=suggestion,
        auto_accepted=auto_accepted,
        item=created_item,
    )


@router.post("/{item_id}/accept", response_model=Item)
async def accept_triage(
    item_id: UUID,
    db: Annotated[DatabaseProtocol, Depends(get_database)],
) -> Item:
    """
    Accept an AI triage suggestion and activate the item.
    
    Used when auto_accepted was False but user approves the suggestion.
    """
    item = await db.update_item(
        item_id,
        ItemUpdate(status=ItemStatus.ACTIVE),
        actor=(ActorType.HUMAN, "api"),
        reasoning="User accepted AI triage suggestion",
    )
    
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    return item


@router.post("/{item_id}/correct", response_model=Item)
async def correct_triage(
    item_id: UUID,
    correction: ItemUpdate,
    db: Annotated[DatabaseProtocol, Depends(get_database)],
    ai: Annotated[AIProvider, Depends(get_ai)],
) -> Item:
    """
    Correct an AI triage suggestion.
    
    Stores the correction for future learning—the AI will use this
    to improve suggestions for similar captures.
    """
    # Get the original item
    item = await db.get_item(item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    
    # ╔═══════════════════════════════════════════════════════════════════════╗
    # ║ CRITICAL: AI TRAINING CONSENT CHECK (GDPR Requirement)                ║
    # ║                                                                       ║
    # ║ DO NOT store corrections without consent.                             ║
    # ║ DO NOT bypass this check for any reason.                              ║
    # ║ Violation = potential €20M+ fine under GDPR Article 83.               ║
    # ╚═══════════════════════════════════════════════════════════════════════╝
    from jomni.api.preferences import has_ai_training_consent
    import logging
    logger = logging.getLogger(__name__)
    
    original_text = item.content.get("text", "")
    
    # has_ai_training_consent() is FAIL-CLOSED: errors = no consent
    if original_text and await has_ai_training_consent(db):
        logger.info(f"Storing correction for item {item_id} (consent granted)")
        embedding, _ = await ai.embed(original_text)
        await db.store_correction(
            item_id=item_id,
            input_text=original_text,
            ai_suggestion={
                "item_type": item.item_type.value,
                "status": item.status.value,
            },
            user_correction={
                "item_type": correction.item_type.value if correction.item_type else item.item_type.value,
                "status": correction.status.value if correction.status else item.status.value,
            },
            correction_type="classification",
            input_embedding=embedding,
        )
    else:
        logger.debug(f"Skipped correction storage for item {item_id} (no consent or no text)")
    
    # Apply the correction
    updated_item = await db.update_item(
        item_id,
        correction,
        actor=(ActorType.HUMAN, "api"),
        reasoning="User corrected AI triage suggestion",
    )
    
    if not updated_item:
        raise HTTPException(status_code=404, detail="Item not found")
    return updated_item


@router.get("/needs-review", response_model=list[Item])
async def get_items_needing_review(
    db: Annotated[DatabaseProtocol, Depends(get_database)],
    limit: int = 50,
) -> list[Item]:
    """
    Get all items that need human review.
    
    Returns items in PENDING_REVIEW status - these are captures where
    AI triage failed and a human needs to classify them manually.
    """
    items = await db.list_items(
        status=ItemStatus.PENDING_REVIEW,
        limit=limit,
    )
    return items
