"""
User Data API (GDPR Data Deletion).

Provides the complete data deletion endpoint required for GDPR/CCPA compliance.
This is the "right to be forgotten" implementation.

Created: 2025-12

IMPORTANT: This endpoint permanently deletes ALL user data.
- Items (tasks, goals, notes, etc.)
- Relations between items
- Tags
- Events/audit trail
- AI corrections
- Chat sessions and messages
- Embeddings
- Preferences

API Endpoints:
    DELETE /user/data       - Delete all user data (with confirmation)
    GET    /user/data/stats - Get data statistics before deletion
"""

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel

from jomni.db import get_database
from jomni.db.protocol import DatabaseProtocol
from jomni.db.sqlite_client import SQLiteClient
from jomni.utils.datetime import utc_now


router = APIRouter(prefix="/user", tags=["user"])


# =============================================================================
# MODELS
# =============================================================================

class DataStats(BaseModel):
    """Statistics about user data before deletion."""
    items_count: int
    relations_count: int
    tags_count: int
    events_count: int
    corrections_count: int
    sessions_count: int
    messages_count: int
    embeddings_count: int


class DeletionResult(BaseModel):
    """Result of data deletion operation."""
    success: bool
    deleted_at: str
    items_deleted: int
    relations_deleted: int
    tags_deleted: int
    events_deleted: int
    corrections_deleted: int
    sessions_deleted: int
    messages_deleted: int
    embeddings_deleted: int
    preferences_reset: bool


# =============================================================================
# DATA DELETION FUNCTIONS
# =============================================================================

async def get_data_stats(db: DatabaseProtocol) -> DataStats:
    """
    Get statistics about all user data.
    
    Useful to show user what will be deleted before confirmation.
    """
    if not isinstance(db, SQLiteClient):
        # For Supabase, would need different implementation
        return DataStats(
            items_count=0, relations_count=0, tags_count=0,
            events_count=0, corrections_count=0, sessions_count=0,
            messages_count=0, embeddings_count=0
        )
    
    from sqlalchemy import select, func
    
    stats = {}
    
    with db.engine.connect() as conn:
        # Count items
        result = conn.execute(select(func.count()).select_from(db.items))
        stats["items_count"] = result.scalar() or 0
        
        # Count relations
        result = conn.execute(select(func.count()).select_from(db.relations))
        stats["relations_count"] = result.scalar() or 0
        
        # Count tags
        result = conn.execute(select(func.count()).select_from(db.item_tags))
        stats["tags_count"] = result.scalar() or 0
        
        # Count chat sessions
        result = conn.execute(select(func.count()).select_from(db.chat_sessions))
        stats["sessions_count"] = result.scalar() or 0
        
        # Count chat messages
        result = conn.execute(select(func.count()).select_from(db.chat_messages))
        stats["messages_count"] = result.scalar() or 0
        
        # Events and corrections may not have tables in SQLite
        stats["events_count"] = 0
        stats["corrections_count"] = 0
        stats["embeddings_count"] = 0
    
    return DataStats(**stats)


async def delete_all_data(db: DatabaseProtocol) -> DeletionResult:
    """
    Delete ALL user data from the database.
    
    This is a cascading delete in the correct order to respect foreign keys:
    1. Chat messages (references sessions)
    2. Chat sessions
    3. Item tags (references items)
    4. Relations (references items)
    5. Items
    6. Preferences (reset to defaults)
    
    WARNING: This is irreversible!
    """
    if not isinstance(db, SQLiteClient):
        raise HTTPException(
            status_code=400,
            detail="Data deletion only available in offline mode"
        )
    
    deleted = {
        "items_deleted": 0,
        "relations_deleted": 0,
        "tags_deleted": 0,
        "events_deleted": 0,
        "corrections_deleted": 0,
        "sessions_deleted": 0,
        "messages_deleted": 0,
        "embeddings_deleted": 0,
        "preferences_reset": False,
    }
    
    with db.engine.connect() as conn:
        # Delete in reverse dependency order
        
        # 1. Chat messages
        result = conn.execute(db.chat_messages.delete())
        deleted["messages_deleted"] = result.rowcount
        
        # 2. Chat sessions
        result = conn.execute(db.chat_sessions.delete())
        deleted["sessions_deleted"] = result.rowcount
        
        # 3. Item tags
        result = conn.execute(db.item_tags.delete())
        deleted["tags_deleted"] = result.rowcount
        
        # 4. Relations
        result = conn.execute(db.relations.delete())
        deleted["relations_deleted"] = result.rowcount
        
        # 5. Items
        result = conn.execute(db.items.delete())
        deleted["items_deleted"] = result.rowcount
        
        # 6. Reset preferences to defaults
        now = utc_now().isoformat()
        conn.execute(
            db.user_preferences.update()
            .where(db.user_preferences.c.id == "default")
            .values(
                ai_training_consent=0,
                analytics_consent=1,
                data_sync_consent=1,
                updated_at=now,
            )
        )
        deleted["preferences_reset"] = True
        
        conn.commit()
    
    return DeletionResult(
        success=True,
        deleted_at=utc_now().isoformat(),
        **deleted,
    )


# =============================================================================
# API ENDPOINTS
# =============================================================================

@router.get("/data/stats", response_model=DataStats)
async def get_user_data_stats(
    db: Annotated[DatabaseProtocol, Depends(get_database)],
) -> DataStats:
    """
    Get statistics about all user data.
    
    Use this before deletion to show what will be removed.
    """
    return await get_data_stats(db)


@router.delete("/data", response_model=DeletionResult)
async def delete_user_data(
    db: Annotated[DatabaseProtocol, Depends(get_database)],
    confirm: bool = Query(
        default=False,
        description="Must be true to confirm deletion"
    ),
) -> DeletionResult:
    """
    Delete ALL user data (GDPR "right to be forgotten").
    
    ⚠️ WARNING: This is IRREVERSIBLE!
    
    You must pass `?confirm=true` to execute the deletion.
    
    Example:
        DELETE /user/data?confirm=true
        
    This will delete:
    - All items (tasks, goals, notes, etc.)
    - All relations and tags
    - All chat sessions and messages
    - All AI corrections and events
    - All embeddings
    
    Preferences will be reset to defaults.
    """
    if not confirm:
        raise HTTPException(
            status_code=400,
            detail="Deletion not confirmed. Pass ?confirm=true to proceed. This action is IRREVERSIBLE."
        )
    
    return await delete_all_data(db)
