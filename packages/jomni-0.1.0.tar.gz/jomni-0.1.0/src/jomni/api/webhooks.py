"""
Webhooks endpoints for Jomni.

Provides webhook registration and async delivery for external integrations.
"""

import asyncio
import hashlib
import hmac
import json
import logging
from datetime import datetime, timezone
from typing import Any
from uuid import UUID

import httpx
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from pydantic import BaseModel

from jomni.db import get_database
from jomni.db.protocol import DatabaseProtocol


logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/webhooks", tags=["webhooks"])


class CreateWebhookRequest(BaseModel):
    url: str
    events: list[str]
    secret: str | None = None


class WebhookInfo(BaseModel):
    id: str
    url: str
    events: list[str]
    active: bool
    created_at: datetime
    last_triggered_at: datetime | None
    failure_count: int


@router.post("", response_model=WebhookInfo)
async def create_webhook(
    request: CreateWebhookRequest,
    db: DatabaseProtocol = Depends(get_database),
):
    """Register a new webhook."""
    result = db.client.table("webhooks").insert({
        "url": request.url,
        "events": request.events,
        "secret": request.secret,
        "active": True,
    }).execute()
    
    row = result.data[0]
    return WebhookInfo(
        id=row["id"],
        url=row["url"],
        events=row["events"],
        active=row["active"],
        created_at=row["created_at"],
        last_triggered_at=row.get("last_triggered_at"),
        failure_count=row.get("failure_count", 0),
    )


@router.get("", response_model=list[WebhookInfo])
async def list_webhooks(
    db: DatabaseProtocol = Depends(get_database),
):
    """List all registered webhooks."""
    result = db.client.table("webhooks").select("*").order("created_at", desc=True).execute()
    
    return [
        WebhookInfo(
            id=row["id"],
            url=row["url"],
            events=row["events"],
            active=row["active"],
            created_at=row["created_at"],
            last_triggered_at=row.get("last_triggered_at"),
            failure_count=row.get("failure_count", 0),
        )
        for row in result.data
    ]


@router.delete("/{webhook_id}")
async def delete_webhook(
    webhook_id: UUID,
    db: DatabaseProtocol = Depends(get_database),
):
    """Remove a webhook."""
    db.client.table("webhooks").delete().eq("id", str(webhook_id)).execute()
    return {"success": True, "message": f"Webhook {webhook_id} removed"}


@router.post("/{webhook_id}/test")
async def test_webhook(
    webhook_id: UUID,
    background_tasks: BackgroundTasks,
    db: DatabaseProtocol = Depends(get_database),
):
    """Send a test payload to the webhook."""
    result = db.client.table("webhooks").select("*").eq("id", str(webhook_id)).maybeSingle().execute()
    
    if not result.data:
        raise HTTPException(status_code=404, detail="Webhook not found")
    
    webhook = result.data
    test_payload = {
        "event": "webhook.test",
        "data": {
            "message": "This is a test webhook delivery",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    }
    
    background_tasks.add_task(deliver_webhook, webhook, test_payload, db)
    return {"success": True, "message": "Test webhook queued for delivery"}


# =============================================================================
# WEBHOOK DELIVERY
# =============================================================================

async def deliver_webhook(webhook: dict, payload: dict, db: DatabaseProtocol, retries: int = 3):
    """Deliver a webhook with retry logic."""
    url = webhook["url"]
    secret = webhook.get("secret")
    
    # Sign payload if secret exists
    body = json.dumps(payload)
    headers = {"Content-Type": "application/json"}
    
    if secret:
        signature = hmac.new(secret.encode(), body.encode(), hashlib.sha256).hexdigest()
        headers["X-Webhook-Signature"] = f"sha256={signature}"
    
    # Retry with exponential backoff
    for attempt in range(retries):
        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(url, content=body, headers=headers, timeout=10.0)
                
            if response.status_code < 400:
                # Success - reset failure count
                db.client.table("webhooks").update({
                    "last_triggered_at": datetime.now(timezone.utc).isoformat(),
                    "failure_count": 0,
                }).eq("id", webhook["id"]).execute()
                logger.info(f"Webhook delivered to {url}: {response.status_code}")
                return
                
        except Exception as e:
            logger.warning(f"Webhook delivery attempt {attempt + 1} failed: {e}")
        
        if attempt < retries - 1:
            await asyncio.sleep(2 ** attempt)  # Exponential backoff
    
    # All retries failed
    current_failures = webhook.get("failure_count", 0) + 1
    updates = {
        "failure_count": current_failures,
        "last_triggered_at": datetime.now(timezone.utc).isoformat(),
    }
    
    # Disable after 10 consecutive failures
    if current_failures >= 10:
        updates["active"] = False
        logger.error(f"Webhook {webhook['id']} disabled after 10 failures")
    
    db.client.table("webhooks").update(updates).eq("id", webhook["id"]).execute()


async def trigger_webhooks(event: str, data: dict, db: DatabaseProtocol):
    """
    Trigger all active webhooks that match the event.
    
    Call this after mutations to emit events.
    """
    result = db.client.table("webhooks").select("*").eq("active", True).execute()
    
    payload = {
        "event": event,
        "data": data,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
    
    for webhook in result.data:
        if event in webhook.get("events", []):
            # Fire and forget - don't await
            asyncio.create_task(deliver_webhook(webhook, payload, db))
