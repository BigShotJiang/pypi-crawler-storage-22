#!/usr/bin/env python3
"""
Jomni CLI - Unified command-line interface.

Usage:
    jomni setup          Launch the setup wizard
    jomni serve          Start the API server
    jomni mcp            Start the MCP server (for Claude Desktop)
    jomni version        Show version info
    jomni health         Check server health
    jomni register-mcp   Register with Claude Desktop
"""

import argparse
import json
import os
import sys
from pathlib import Path

from jomni import __version__


def cmd_version(args):
    """Show version information."""
    print(f"Jomni v{__version__}")
    print("A personal database designed to last a lifetime.")
    print("https://github.com/Joseph-Smoke/jomni")


def cmd_serve(args):
    """Start the API server."""
    from jomni.main import run
    run()


def cmd_mcp(args):
    """Start the MCP server."""
    from jomni.mcp.server import run
    run()


def cmd_setup(args):
    """Launch the setup wizard."""
    # Import here to avoid tkinter dependency for non-GUI commands
    try:
        from jomni.setup.wizard import JomniSetupWizard
        wizard = JomniSetupWizard()
        wizard.run()
    except ImportError as e:
        if "tkinter" in str(e):
            print("Error: tkinter not found.")
            print()
            print("Install tkinter:")
            print("  - Windows: Use Python from python.org (includes tkinter)")
            print("  - macOS: brew install python-tk")
            print("  - Linux: sudo apt install python3-tk")
            sys.exit(1)
        raise


def cmd_health(args):
    """Check server health."""
    import urllib.request
    import urllib.error
    
    host = args.host or "localhost"
    port = args.port or 8000
    url = f"http://{host}:{port}/health"
    
    try:
        with urllib.request.urlopen(url, timeout=5) as response:
            data = json.loads(response.read().decode())
            
            status = data.get("status", "unknown")
            db_status = data.get("database", {}).get("status", "unknown")
            ai_configured = data.get("ai", {}).get("configured", False)
            
            print(f"Jomni Health Check")
            print(f"  Status:   {status}")
            print(f"  Database: {db_status}")
            print(f"  AI:       {'configured' if ai_configured else 'not configured'}")
            
            if status != "healthy":
                sys.exit(1)
    except urllib.error.URLError as e:
        print(f"Error: Could not connect to {url}")
        print(f"  {e.reason}")
        print()
        print("Is the server running? Start it with: jomni serve")
        sys.exit(1)


def cmd_register_mcp(args):
    """Register Jomni with Claude Desktop."""
    # Find Claude Desktop config
    if sys.platform == "win32":
        config_dir = Path(os.environ.get("APPDATA", "")) / "Claude"
    elif sys.platform == "darwin":
        config_dir = Path.home() / "Library" / "Application Support" / "Claude"
    else:
        config_dir = Path.home() / ".config" / "claude"
    
    config_file = config_dir / "claude_desktop_config.json"
    
    # Load existing config or create new
    if config_file.exists():
        with open(config_file, "r") as f:
            config = json.load(f)
    else:
        config_dir.mkdir(parents=True, exist_ok=True)
        config = {}
    
    # Add/update jomni server
    if "mcpServers" not in config:
        config["mcpServers"] = {}
    
    # Determine the command based on installation
    # If installed via pip, use the entry point
    # Otherwise, use python -m
    jomni_config = {
        "command": "jomni",
        "args": ["mcp"],
    }
    
    # Check if .env exists and add env vars
    env_paths = [
        Path.cwd() / ".env",
        Path.cwd() / "backend" / ".env",
        Path.home() / ".jomni" / ".env",
    ]
    
    for env_path in env_paths:
        if env_path.exists():
            print(f"Found .env at: {env_path}")
            # Read env file and extract key vars
            env_vars = {}
            with open(env_path, "r") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        key, _, value = line.partition("=")
                        if key.startswith("JOMNI_"):
                            env_vars[key] = value
            
            if env_vars:
                jomni_config["env"] = env_vars
            break
    
    config["mcpServers"]["jomni"] = jomni_config
    
    # Write config
    with open(config_file, "w") as f:
        json.dump(config, f, indent=2)
    
    print(f"✓ Registered Jomni with Claude Desktop")
    print(f"  Config: {config_file}")
    print()
    print("Restart Claude Desktop to load the new configuration.")


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        prog="jomni",
        description="Jomni - A personal database designed to last a lifetime.",
    )
    parser.add_argument(
        "--version", "-V",
        action="version",
        version=f"%(prog)s {__version__}"
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Commands")
    
    # setup
    setup_parser = subparsers.add_parser("setup", help="Launch the setup wizard")
    setup_parser.set_defaults(func=cmd_setup)
    
    # serve
    serve_parser = subparsers.add_parser("serve", help="Start the API server")
    serve_parser.set_defaults(func=cmd_serve)
    
    # mcp
    mcp_parser = subparsers.add_parser("mcp", help="Start the MCP server")
    mcp_parser.set_defaults(func=cmd_mcp)
    
    # version
    version_parser = subparsers.add_parser("version", help="Show version info")
    version_parser.set_defaults(func=cmd_version)
    
    # health
    health_parser = subparsers.add_parser("health", help="Check server health")
    health_parser.add_argument("--host", default="localhost", help="Server host")
    health_parser.add_argument("--port", type=int, default=8000, help="Server port")
    health_parser.set_defaults(func=cmd_health)
    
    # register-mcp
    register_parser = subparsers.add_parser("register-mcp", help="Register with Claude Desktop")
    register_parser.set_defaults(func=cmd_register_mcp)
    
    args = parser.parse_args()
    
    if args.command is None:
        parser.print_help()
        sys.exit(0)
    
    args.func(args)


if __name__ == "__main__":
    main()
