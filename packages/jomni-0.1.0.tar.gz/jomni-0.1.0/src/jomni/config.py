"""
Jomni configuration management.

All configuration comes from environment variables, with sensible defaults for development.
Production deployments should set these via .env file or environment.
"""

from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


def _find_env_file() -> Path | None:
    """Find .env file by searching current dir and parent directories."""
    current = Path.cwd()
    for parent in [current] + list(current.parents):
        env_path = parent / ".env"
        if env_path.exists():
            return env_path
    return None


class Settings(BaseSettings):
    """
    Application settings loaded from environment variables.
    
    The model_config tells pydantic-settings to:
    - Look for a .env file in the project root (searches parent dirs)
    - Use 'JOMNI_' prefix for all env vars (e.g., JOMNI_SUPABASE_URL)
    - Be case-insensitive when matching env var names
    """
    
    model_config = SettingsConfigDict(
        env_file=_find_env_file() or ".env",
        env_file_encoding="utf-8",
        env_prefix="JOMNI_",
        case_sensitive=False,
    )
    
    # ==========================================================================
    # Application
    # ==========================================================================
    
    app_name: str = "Jomni"
    debug: bool = False
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"
    
    # ==========================================================================
    # Supabase (Cloud Database)
    # ==========================================================================
    
    supabase_url: str = Field(
        default="",
        description="Supabase project URL (e.g., https://xxx.supabase.co)"
    )
    supabase_anon_key: str = Field(
        default="",
        description="Supabase anonymous/public key for client-side auth"
    )
    supabase_service_key: str = Field(
        default="",
        description="Supabase service role key for server-side operations (keep secret!)"
    )
    
    # ==========================================================================
    # AI Providers
    # ==========================================================================
    
    anthropic_api_key: str = Field(
        default="",
        description="Anthropic API key for Claude"
    )
    openai_api_key: str = Field(
        default="",
        description="OpenAI API key for embeddings and fallback"
    )
    
    # Default models (can be overridden per-request)
    default_chat_model: str = "claude-sonnet-4-20250514"
    default_triage_model: str = "claude-haiku-4-5-20251001"  # Fast + cheap for classification
    default_embedding_model: str = "text-embedding-3-small"
    embedding_dimensions: int = 1536
    
    # ==========================================================================
    # Triage Configuration
    # ==========================================================================
    
    # Confidence thresholds for AI triage routing
    triage_auto_accept_threshold: float = 0.90   # Above this: auto-apply
    triage_suggest_threshold: float = 0.70       # Above this: show suggestion
    # Below suggest_threshold: ask user explicitly
    
    # ==========================================================================
    # Local Database (SQLite)
    # ==========================================================================
    
    db_mode: Literal["supabase", "sqlite", "auto"] = "auto"
    sqlite_path: str = Field(
        default="~/.jomni/jomni.db",
        description="Path to local SQLite database"
    )
    
    # ==========================================================================
    # Server
    # ==========================================================================
    
    host: str = "127.0.0.1"
    port: int = 8000
    
    # API Authentication - SECURITY CRITICAL
    # Set JOMNI_API_KEY in production to enable API authentication
    api_key: str = Field(
        default="",
        description="API key for authenticating requests. Empty = auth disabled (dev only)"
    )
    
    # CORS: Allowed origins for web clients
    # In production, set JOMNI_CORS_ORIGINS to a comma-separated list
    # e.g., JOMNI_CORS_ORIGINS="https://app.jomni.io,https://jomni.io"
    cors_origins: list[str] = Field(
        default=[
            "http://localhost:3000",      # SvelteKit dev
            "http://localhost:8080",      # Flutter web
            "http://localhost:8081",      # Flutter web alt
            "http://localhost:8082",      # Flutter web alt
            "http://localhost:8083",      # Flutter web alt
            "http://localhost:8087",      # Flutter web alt
            "http://localhost:8088",      # Flutter web alt
            "http://localhost:8089",      # Flutter web alt
            "http://localhost:8090",      # Flutter web alt
            "http://127.0.0.1:3000",
            "http://127.0.0.1:8080",
            "http://127.0.0.1:8081",
            "http://127.0.0.1:8082",
            "http://127.0.0.1:8083",
            "http://127.0.0.1:8087",
            "http://127.0.0.1:8088",
            "http://127.0.0.1:8089",
            "http://127.0.0.1:8090",
            "http://localhost:5173",      # Vite dev
        ],
        description="Allowed CORS origins. Use ['*'] only for development."
    )
    
    # ==========================================================================
    # MCP Server
    # ==========================================================================
    
    mcp_enabled: bool = True
    mcp_port: int = 8001
    
    # ==========================================================================
    # Security
    # ==========================================================================
    
    encryption_key: str = Field(
        default="",
        description="32-byte URL-safe base64-encoded key for token encryption"
    )
    
    # ==========================================================================
    # Google OAuth
    # ==========================================================================
    
    google_client_id: str = Field(
        default="",
        description="Google OAuth Client ID"
    )
    google_client_secret: str = Field(
        default="",
        description="Google OAuth Client Secret"
    )
    google_redirect_uri: str = Field(
        default="http://localhost:8000/auth/google/callback",
        description="Google OAuth Redirect URI"
    )
    
    # ==========================================================================
    # Webhooks
    # ==========================================================================
    
    tally_webhook_secret: str = Field(
        default="",
        description="Tally webhook signing secret for HMAC validation"
    )
    
    # ==========================================================================
    # Observability
    # ==========================================================================
    
    sentry_dsn: str = Field(
        default="",
        description="Sentry DSN for error tracking (leave empty to disable)"
    )
    environment: str = Field(
        default="development",
        description="Environment name for Sentry (development/staging/production)"
    )
    
    # ==========================================================================
    # Local LLM (Ollama)
    # ==========================================================================
    
    ollama_base_url: str = Field(
        default="http://localhost:11434",
        description="Ollama API base URL for local LLM fallback"
    )
    ollama_model: str = Field(
        default="llama3.2",
        description="Ollama model to use for triage fallback"
    )
    ollama_enabled: bool = Field(
        default=True,
        description="Whether to try Ollama as fallback when cloud AI fails"
    )
    
    @property
    def is_configured(self) -> bool:
        """Check if minimum required configuration is present."""
        return bool(self.supabase_url and self.supabase_anon_key)
    
    @property
    def has_ai(self) -> bool:
        """Check if AI features are available."""
        return bool(self.anthropic_api_key or self.openai_api_key)


@lru_cache
def get_settings() -> Settings:
    """
    Get cached settings instance.
    
    Using lru_cache ensures we only parse environment once,
    and the same Settings object is reused throughout the app.
    """
    return Settings()
