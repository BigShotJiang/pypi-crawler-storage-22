"""
Database module factory.

Provides access to the appropriate database client (Supabase or SQLite)
based on configuration and availability.
"""

import logging
from typing import Literal

from jomni.config import get_settings
from jomni.db.protocol import DatabaseProtocol
from jomni.db.sqlite_client import SQLiteClient
from jomni.db.supabase_client import SupabaseClient

logger = logging.getLogger(__name__)

_db_instance: DatabaseProtocol | None = None


def get_database(force_mode: Literal["supabase", "sqlite", "auto"] | None = None) -> DatabaseProtocol:
    """
    Get the configured database client.
    
    Args:
        force_mode: Override configuration (useful for testing)
        
    Returns:
        DatabaseProtocol implementation (SupabaseClient or SQLiteClient)
    """
    global _db_instance
    
    # Return cached instance if available and no force_mode
    if _db_instance and not force_mode:
        return _db_instance
        
    settings = get_settings()
    mode = force_mode or settings.db_mode
    
    logger.info(f"Initializing database in mode: {mode}")
    
    if mode == "sqlite":
        _db_instance = SQLiteClient()
        return _db_instance
        
    elif mode == "supabase":
        _db_instance = SupabaseClient()
        return _db_instance
        
    elif mode == "auto":
        try:
            # Try Supabase first
            client = SupabaseClient()
            
            # Quick health check to verify connectivity
            # We try to select 1 item (lightweight)
            # Note: SupabaseClient init doesn't actually connect until first request
            # so we need to make a request to verify
            try:
                client.client.table("items").select("id").limit(1).execute()
                logger.info("Connected to Supabase successfully")
                _db_instance = client
                return client
            except Exception as e:
                logger.warning(f"Supabase connection failed: {e}")
                raise  # Re-raise to trigger fallback
                
        except Exception as connect_err:
            # Log the actual connection error before falling back
            logger.warning(f"Falling back to SQLite (offline mode). Supabase error: {connect_err}")
            _db_instance = SQLiteClient()
            return _db_instance
            
    else:
        raise ValueError(f"Invalid database mode: {mode}")


# Export for convenience
__all__ = ["get_database", "DatabaseProtocol", "SupabaseClient", "SQLiteClient"]
