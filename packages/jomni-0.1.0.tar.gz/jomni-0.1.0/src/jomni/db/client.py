"""
Legacy database client entry point.

DEPRECATED: Use jomni.db.get_database() instead.
Kept for backward compatibility.
"""

import warnings
from jomni.db.supabase_client import SupabaseClient

# Re-export SupabaseClient as Database for backward compatibility
# This ensures existing code doing `from jomni.db.client import Database` still works
# and gets the Supabase implementation by default.
Database = SupabaseClient

def get_db():
    """Deprecated helper."""
    warnings.warn("Use jomni.db.get_database() instead", DeprecationWarning)
    from jomni.db import get_database
    return get_database()