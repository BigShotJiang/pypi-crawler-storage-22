"""
Database Protocol Interface.

Defines the contract that all database clients (Supabase, SQLite) must implement.

ARCHITECTURE NOTE - Explicit Actor Pattern:
All mutation methods require an explicit `actor` parameter rather than using
a stateful set_actor() approach. This prevents race conditions in concurrent
request handling (e.g., FastAPI async endpoints) where one request's actor
could overwrite another's before database operations complete.

The Actor type is a tuple of (ActorType, actor_id), for example:
    - (ActorType.HUMAN, "api")  - Human user via API
    - (ActorType.AI, "claude-3-5-haiku-20241022")  - AI model
    - (ActorType.SYSTEM, "scheduler")  - Background job
"""

from typing import Any, Protocol, runtime_checkable
from uuid import UUID

from jomni.models import (
    ActorType,
    EmbeddingCreate,
    Event,
    Item,
    ItemCreate,
    ItemStatus,
    ItemType,
    ItemUpdate,
    Relation,
    RelationCreate,
    Service,
    ServiceCredential,
)

# Type alias for actor identification (type, id)
Actor = tuple[ActorType, str]


@runtime_checkable
class DatabaseProtocol(Protocol):
    """
    Abstract interface for Jomni database backends.
    
    CONTEXT:
    Jomni supports multiple database backends for different environments:
    - SupabaseClient: Cloud Postgres via Supabase (production)
    - SQLiteClient: Local SQLite file (offline/development)
    
    All API endpoints depend on this protocol, not concrete implementations.
    This enables swapping backends without changing application code.
    
    HOW PYTHON PROTOCOLS WORK:
    @runtime_checkable allows isinstance() checks at runtime.
    Protocols use structural typing (duck typing)\u2014a class implements this
    protocol if it has matching method signatures, even WITHOUT explicit
    inheritance. This is different from abstract base classes.
    
    REQUIRED METHODS (Core CRUD):
    - create_item, get_item, update_item, delete_item, list_items, get_inbox
    - store_embedding, semantic_search
    - create_relation, get_related_items, get_relations_for_items
    
    REQUIRED METHODS (Auth/Services):
    - get_service, store_credentials, get_credentials
    
    OPTIONAL METHODS (may not be in all implementations):
    - get_digest_stats: Analytics (Supabase only)
    - get_similar_corrections: AI learning (Supabase only)
    
    ADDING A NEW BACKEND:
    1. Create new class in db/ folder
    2. Implement all required methods with matching signatures
    3. Add factory logic to db/__init__.py get_database()
    4. Test with: isinstance(your_client, DatabaseProtocol)
    
    COMPLEXITY: Critical
    Changes to this protocol affect ALL database implementations.
    Adding methods requires updating BOTH Supabase and SQLite clients.
    
    See Also:
    - db/supabase_client.py: Production implementation
    - db/sqlite_client.py: Offline implementation
    - db/__init__.py: Factory function get_database()
    """

    # =========================================================================
    # SESSION MANAGEMENT
    # =========================================================================

    def set_session(self, session_id: UUID) -> None:
        """Set the current session for grouping related events."""
        ...

    def new_session(self) -> UUID:
        """Start a new session and return its ID."""
        ...

    # =========================================================================
    # ITEMS
    # =========================================================================

    async def create_item(
        self,
        data: ItemCreate,
        actor: Actor = (ActorType.SYSTEM, "server"),
        reasoning: str | None = None,
        confidence: float | None = None,
    ) -> Item:
        """Create a new item with explicit actor for audit logging."""
        ...

    async def get_item(self, item_id: UUID) -> Item | None:
        """Get an item by ID."""
        ...

    async def update_item(
        self,
        item_id: UUID,
        data: ItemUpdate,
        actor: Actor = (ActorType.SYSTEM, "server"),
        reasoning: str | None = None,
        confidence: float | None = None,
    ) -> Item | None:
        """Update an item with explicit actor for audit logging."""
        ...

    async def delete_item(
        self,
        item_id: UUID,
        actor: Actor = (ActorType.SYSTEM, "server"),
        reasoning: str | None = None,
        hard_delete: bool = False,
    ) -> bool:
        """Soft delete an item with explicit actor for audit logging."""
        ...
        
    async def restore_item(
        self,
        item_id: UUID,
        actor: Actor = (ActorType.SYSTEM, "server"),
        reasoning: str | None = None,
    ) -> Item | None:
        """Restore a soft-deleted item with explicit actor for audit logging."""
        ...
    
    async def complete_item(
        self,
        item_id: UUID,
        actor: Actor = (ActorType.SYSTEM, "server"),
        reasoning: str | None = None,
    ) -> Item | None:
        """
        Mark an item as completed.
        
        Sets status to COMPLETED. Commonly used for tasks and habits.
        Actor is passed explicitly for audit trail parity.
        """
        ...
    
    async def archive_item(
        self,
        item_id: UUID,
        actor: Actor = (ActorType.SYSTEM, "server"),
        reasoning: str | None = None,
    ) -> Item | None:
        """
        Archive an item (soft removal from active views).
        
        Sets status to ARCHIVED. Item remains in database but hidden from lists.
        Actor is passed explicitly for audit trail parity.
        """
        ...

    async def list_items(
        self,
        item_type: ItemType | None = None,
        status: ItemStatus | None = None,
        parent_id: UUID | None = None,
        limit: int = 50,
        offset: int = 0,
        include_deleted: bool = False,
    ) -> list[Item]:
        """
        List items with optional filters.
        
        By default, excludes soft-deleted items (deleted_at IS NOT NULL).
        Set include_deleted=True to include them.
        """
        ...
        
    async def get_inbox(self, limit: int = 50) -> list[Item]:
        """Get all items in inbox status."""
        ...
    
    async def bulk_update_items(
        self,
        set_status: ItemStatus,
        filter_type: ItemType | None = None,
        filter_status: ItemStatus | None = None,
        limit: int = 1000,
        actor: Actor = (ActorType.SYSTEM, "server"),
        reasoning: str | None = None,
    ) -> int:
        """
        Bulk update items matching filters.
        
        Returns count of items updated.
        """
        ...

    # =========================================================================
    # TAGS
    # Tags allow flexible categorization of items.
    # =========================================================================

    async def add_tags_to_item(
        self,
        item_id: UUID,
        tags: list[str],
    ) -> None:
        """
        Add one or more tags to an item.
        
        Tags that already exist on the item are silently ignored (idempotent).
        """
        ...
    
    async def remove_tag_from_item(
        self,
        item_id: UUID,
        tag: str,
    ) -> None:
        """
        Remove a specific tag from an item.
        
        No-op if the tag doesn't exist on the item.
        """
        ...

    # =========================================================================
    # EMBEDDINGS & SEARCH
    # =========================================================================

    async def store_embedding(self, data: EmbeddingCreate) -> None:
        """Store an embedding for an item."""
        ...

    async def semantic_search(
        self,
        embedding: list[float],
        limit: int = 10,
        item_types: list[ItemType] | None = None,
        statuses: list[ItemStatus] | None = None,
    ) -> list[tuple[Item, float]]:
        """Search for similar items using vector similarity."""
        ...

    # =========================================================================
    # RELATIONS
    # =========================================================================

    async def create_relation(self, data: RelationCreate) -> Relation:
        """Create a relation between two items."""
        ...

    async def get_related_items(
        self,
        item_id: UUID,
        relation_type: str | None = None,
    ) -> list[Item]:
        """Get all items related to the given item."""
        ...

    async def get_relations_for_items(
        self,
        item_ids: list[UUID],
    ) -> dict[UUID, list[Relation]]:
        """
        Get all relations for a list of items.
        Returns a dictionary mapping item_id to list of Relations.
        """
        ...

    # =========================================================================
    # ANALYTICS & DIGEST
    # =========================================================================

    async def get_digest_stats(self) -> dict[str, Any]:
        """
        Get statistics for the daily digest.
        Returns counts by status, goal progress, etc.
        """
        ...

    async def get_events(
        self,
        item_id: UUID | None = None,
        action_type: str | None = None,
        limit: int = 50,
    ) -> list[Event]:
        """
        Get audit events, optionally filtered by item_id or action type.
        
        Args:
            item_id: Filter to events for this specific item
            action_type: Filter by action (created, updated, deleted, completed)
            limit: Maximum events to return (default 50)
            
        Returns:
            List of Event objects ordered by occurred_at descending (newest first).
            
        Note:
            Added in Phase 2 (A2) to abstract direct db.client calls from executor.py.
        """
        ...

    async def get_deleted_items(self, limit: int = 50) -> list[Item]:
        """
        Get soft-deleted items (where deleted_at IS NOT NULL).
        
        Args:
            limit: Maximum items to return (default 50)
            
        Returns:
            List of Item objects ordered by deleted_at descending.
            
        Note:
            Added in Phase 2 (A2) to abstract direct db.client calls from executor.py.
        """
        ...

    async def list_memories(
        self,
        memory_type: str | None = None,
        limit: int = 50,
    ) -> list[Item]:
        """
        List items marked as memories (metadata.memory = True).
        
        Args:
            memory_type: Filter by "explicit", "implicit", or "all" (default: all)
            limit: Maximum memories to return (default 50)
            
        Returns:
            List of Item objects representing stored memories.
            
        Note:
            Memories are regular items with metadata.memory = True.
            The memory_type is stored in content.memory_type.
        """
        ...

    async def get_job_history(self, limit: int = 20) -> list[dict[str, Any]]:
        """
        Get scheduler job run history.
        
        Args:
            limit: Maximum history entries to return (default 20)
            
        Returns:
            List of dicts with job_name, status, started_at, duration, error, etc.
            
        Note:
            Queries the job_history table populated by scheduled jobs.
        """
        ...

    # =========================================================================
    # SERVICES & AUTH
    # =========================================================================

    async def get_service(self, name: str) -> Service | None:
        """Get service status by name."""
        ...

    async def store_credentials(self, creds: ServiceCredential) -> None:
        """Store encrypted service credentials."""
        ...

    async def get_credentials(self, service_name: str) -> ServiceCredential | None:
        """Get encrypted service credentials."""
        ...

    # =========================================================================
    # CORRECTIONS
    # =========================================================================

    async def store_correction(
        self,
        item_id: UUID | None,
        input_text: str,
        ai_suggestion: dict[str, Any],
        user_correction: dict[str, Any],
        correction_type: str,
        input_embedding: list[float] | None = None,
        model_name: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        """Store a user correction for AI learning."""
        ...

    # =========================================================================
    # GOALS
    # =========================================================================

    async def create_goal(
        self,
        title: str,
        description: str | None = None,
        horizon: str = "medium",  # short, medium, long
        target_date: str | None = None,
        success_criteria: list[str] | None = None,
        tags: list[str] | None = None,
        reasoning: str | None = None,
    ) -> Item:
        """Create a new goal."""
        ...

    async def list_goals(
        self,
        horizon: str | None = None,
        status: ItemStatus | None = None,
        limit: int = 50,
    ) -> list[Item]:
        """List goals with optional filters."""
        ...

    async def link_item_to_goal(
        self,
        item_id: UUID,
        goal_id: UUID,
        reasoning: str | None = None,
    ) -> Relation:
        """Link an item to a goal as supporting it."""
        ...

    async def assess_goal(
        self,
        goal_id: UUID,
        status: ItemStatus,
        progress_notes: str,
        reasoning: str | None = None,
    ) -> Item:
        """Assess goal progress and update status."""
        ...
        
    async def update_goal(
        self,
        goal_id: UUID,
        title: str | None = None,
        description: str | None = None,
        horizon: str | None = None,
        target_date: str | None = None,
        success_criteria: list[str] | None = None,
        reasoning: str | None = None,
    ) -> Item:
        """Update goal properties."""
        ...

    # =========================================================================
    # TAGS
    # =========================================================================

    async def add_tags_to_item(
        self,
        item_id: UUID,
        tags: list[str],
        reasoning: str | None = None,
    ) -> list[str]:
        """Add tags to an item."""
        ...

    async def remove_tag_from_item(
        self,
        item_id: UUID,
        tag: str,
        reasoning: str | None = None,
    ) -> bool:
        """Remove a tag from an item."""
        ...
