"""
Database Repositories.

WHY THIS EXISTS:
The SupabaseClient is 1000+ lines mixing different concerns:
- Item CRUD
- Event logging
- Search/embeddings
- Relations
- Tags
- Goals
- Services

This repository layer provides:
1. Smaller, focused modules
2. Better testability
3. Clear separation of concerns
4. Gradual migration path

USAGE:
    # Direct repository access
    from jomni.db.repositories.items import ItemRepository
    repo = ItemRepository(client)
    item = await repo.get(item_id)
    
    # Or via aggregated RepositoryManager
    from jomni.db.repositories import RepositoryManager
    repos = RepositoryManager(client)
    item = await repos.items.get(item_id)
"""

from jomni.db.repositories.base import BaseRepository
from jomni.db.repositories.items import ItemRepository
from jomni.db.repositories.events import EventRepository
from jomni.db.repositories.embeddings import EmbeddingRepository
from jomni.db.repositories.manager import RepositoryManager

__all__ = [
    "BaseRepository",
    "ItemRepository",
    "EventRepository",
    "EmbeddingRepository",
    "RepositoryManager",
]
