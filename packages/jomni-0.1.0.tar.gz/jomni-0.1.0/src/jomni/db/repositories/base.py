"""
Base Repository.

Provides common functionality for all repositories.
"""

from typing import Any, Generic, TypeVar
from uuid import UUID
import logging

logger = logging.getLogger(__name__)

T = TypeVar("T")


class BaseRepository(Generic[T]):
    """
    Base class for all repositories.
    
    Provides:
    - Supabase client access
    - Common query patterns
    - Logging
    """
    
    # Override in subclasses
    table_name: str = ""
    
    def __init__(self, client: Any):
        """
        Initialize with Supabase client.
        
        Args:
            client: Supabase client instance
        """
        self._client = client
        self._logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")
    
    @property
    def table(self):
        """Get the table for this repository."""
        return self._client.table(self.table_name)
    
    async def get_by_id(self, id: UUID) -> T | None:
        """Get a single record by ID."""
        result = self.table.select("*").eq("id", str(id)).execute()
        if result.data:
            return self._to_model(result.data[0])
        return None
    
    async def get_all(self, limit: int = 50, offset: int = 0) -> list[T]:
        """Get all records with pagination."""
        result = self.table\
            .select("*")\
            .limit(limit)\
            .offset(offset)\
            .execute()
        return [self._to_model(r) for r in result.data]
    
    async def delete_by_id(self, id: UUID) -> bool:
        """Delete a record by ID."""
        result = self.table.delete().eq("id", str(id)).execute()
        return len(result.data) > 0
    
    def _to_model(self, data: dict) -> T:
        """Convert database row to model. Override in subclasses."""
        raise NotImplementedError
    
    def _log(self, msg: str, level: str = "info"):
        """Log a message."""
        getattr(self._logger, level)(msg)
