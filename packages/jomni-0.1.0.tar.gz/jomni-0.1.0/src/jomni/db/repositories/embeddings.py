"""
Embedding Repository.

Handles vector storage and semantic search.
"""

from typing import Any
from uuid import UUID, uuid4

from jomni.db.repositories.base import BaseRepository
from jomni.models import Embedding, EmbeddingCreate, Item, ItemType, ItemStatus
from jomni.utils.datetime import utc_now


class EmbeddingRepository(BaseRepository[Embedding]):
    """Repository for Embedding operations."""
    
    table_name = "embeddings"
    
    def _to_model(self, data: dict) -> Embedding:
        """Convert database row to Embedding model."""
        return Embedding(**data)
    
    async def store(self, data: EmbeddingCreate) -> Embedding:
        """
        Store an embedding for an item.
        
        Uses upsert to handle re-embedding when content changes.
        """
        now = utc_now()
        
        row = {
            "id": str(uuid4()),
            "item_id": str(data.item_id),
            "model_name": data.model_name,
            "model_version": data.model_version,
            "dimensions": data.dimensions,
            "embedding": data.embedding,
            "source_hash": data.source_hash,
            "created_at": now.isoformat(),
        }
        
        # Upsert on item_id to replace old embeddings
        result = self._client.table(self.table_name)\
            .upsert(row, on_conflict="item_id")\
            .execute()
            
        return Embedding(**result.data[0])
    
    async def get_for_item(self, item_id: UUID) -> Embedding | None:
        """Get the embedding for an item."""
        result = self.table\
            .select("*")\
            .eq("item_id", str(item_id))\
            .execute()
            
        if result.data:
            return Embedding(**result.data[0])
        return None
    
    async def semantic_search(
        self,
        query_embedding: list[float],
        limit: int = 10,
        item_types: list[ItemType] | None = None,
        statuses: list[ItemStatus] | None = None,
    ) -> list[tuple[Item, float]]:
        """
        Search for similar items using vector similarity.
        
        Uses Supabase's match_items RPC function which performs:
        1. Vector similarity search on embeddings
        2. Joins with items table
        3. Filters by item_type and status
        
        Args:
            query_embedding: Vector to search for
            limit: Max results
            item_types: Optional type filter
            statuses: Optional status filter
            
        Returns:
            List of (Item, similarity_score) tuples
        """
        # Build filter
        type_filter = [t.value for t in item_types] if item_types else None
        status_filter = [s.value for s in statuses] if statuses else None
        
        result = self._client.rpc("match_items", {
            "query_embedding": query_embedding,
            "match_count": limit,
            "filter_types": type_filter,
            "filter_statuses": status_filter,
        }).execute()
        
        items = []
        for row in result.data:
            similarity = row.pop("similarity", 0)
            items.append((Item(**row), similarity))
            
        return items
    
    async def check_stale(
        self,
        item_id: UUID,
        current_hash: str,
    ) -> bool:
        """
        Check if an embedding is stale.
        
        Returns True if the embedding needs to be regenerated
        (hash mismatch or no embedding exists).
        """
        embedding = await self.get_for_item(item_id)
        if not embedding:
            return True
        return embedding.source_hash != current_hash
