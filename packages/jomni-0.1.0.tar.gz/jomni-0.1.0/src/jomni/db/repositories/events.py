"""
Event Repository.

Handles event logging for audit trail.
"""

from typing import Any
from uuid import UUID, uuid4

from jomni.db.repositories.base import BaseRepository
from jomni.models import Event, EventCreate, ActorType
from jomni.utils.datetime import utc_now

Actor = tuple[ActorType, str]


class EventRepository(BaseRepository[Event]):
    """Repository for Event operations."""
    
    table_name = "events"
    
    def _to_model(self, data: dict) -> Event:
        """Convert database row to Event model."""
        return Event(**data)
    
    async def log(
        self,
        item_id: UUID,
        action: str,
        actor: Actor,
        changes: dict[str, Any] | None = None,
        reasoning: str | None = None,
        confidence: float | None = None,
        session_id: UUID | None = None,
    ) -> Event:
        """
        Log an event for an item.
        
        Args:
            item_id: Item this event relates to
            action: Event action type (e.g., "item_created", "status_changed")
            actor: Who performed the action (type, id)
            changes: What was changed
            reasoning: AI reasoning if applicable
            confidence: AI confidence if applicable
            session_id: Session ID for grouping related events
            
        Returns:
            Created Event
        """
        now = utc_now()
        event_id = uuid4()
        
        row = {
            "id": str(event_id),
            "item_id": str(item_id),
            "action": action,
            "actor_type": actor[0].value,
            "actor_id": actor[1],
            "changes": changes or {},
            "reasoning": reasoning,
            "confidence": confidence,
            "session_id": str(session_id) if session_id else None,
            "occurred_at": now.isoformat(),
        }
        
        result = self.table.insert(row).execute()
        return Event(**result.data[0])
    
    async def get_for_item(
        self,
        item_id: UUID,
        limit: int = 50,
    ) -> list[Event]:
        """
        Get all events for an item.
        
        Returns events in reverse chronological order.
        """
        result = self.table\
            .select("*")\
            .eq("item_id", str(item_id))\
            .order("occurred_at", desc=True)\
            .limit(limit)\
            .execute()
            
        return [Event(**r) for r in result.data]
    
    async def get_recent(
        self,
        limit: int = 100,
        actor_type: ActorType | None = None,
    ) -> list[Event]:
        """
        Get recent events across all items.
        
        Args:
            limit: Max events to return
            actor_type: Filter by actor type
            
        Returns:
            List of recent Events
        """
        query = self.table.select("*")
        
        if actor_type:
            query = query.eq("actor_type", actor_type.value)
            
        query = query.order("occurred_at", desc=True).limit(limit)
        result = query.execute()
        
        return [Event(**r) for r in result.data]
    
    async def get_by_session(
        self,
        session_id: UUID,
    ) -> list[Event]:
        """Get all events in a session."""
        result = self.table\
            .select("*")\
            .eq("session_id", str(session_id))\
            .order("occurred_at")\
            .execute()
            
        return [Event(**r) for r in result.data]
