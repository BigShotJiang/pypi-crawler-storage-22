"""
Item Repository.

Handles Item CRUD operations.
"""

from typing import Any
from uuid import UUID, uuid4

from jomni.db.repositories.base import BaseRepository
from jomni.models import Item, ItemCreate, ItemUpdate, ItemType, ItemStatus, ActorType
from jomni.utils.datetime import utc_now

Actor = tuple[ActorType, str]


class ItemRepository(BaseRepository[Item]):
    """Repository for Item operations."""
    
    table_name = "items"
    
    def _to_model(self, data: dict) -> Item:
        """Convert database row to Item model."""
        return Item(**data)
    
    async def get(self, item_id: UUID) -> Item | None:
        """Get an item by ID."""
        return await self.get_by_id(item_id)
    
    async def create(
        self,
        data: ItemCreate,
        actor: Actor = (ActorType.SYSTEM, "server"),
        reasoning: str | None = None,
        confidence: float | None = None,
    ) -> Item:
        """
        Create a new item.
        
        Args:
            data: Item data
            actor: Who is creating (type, id)
            reasoning: AI reasoning if applicable
            confidence: AI confidence if applicable
            
        Returns:
            Created Item
        """
        now = utc_now()
        item_id = uuid4()
        
        row = {
            "id": str(item_id),
            "item_type": data.item_type.value,
            "status": data.status.value,
            "content": data.content,
            "metadata": data.metadata or {},
            "parent_id": str(data.parent_id) if data.parent_id else None,
            "created_at": now.isoformat(),
            "updated_at": now.isoformat(),
        }
        
        result = self.table.insert(row).execute()
        return Item(**result.data[0])
    
    async def update(
        self,
        item_id: UUID,
        data: ItemUpdate,
        actor: Actor = (ActorType.SYSTEM, "server"),
        reasoning: str | None = None,
        confidence: float | None = None,
    ) -> Item | None:
        """
        Update an item.
        
        Args:
            item_id: Item to update
            data: Fields to update (None = no change)
            actor: Who is updating
            reasoning: Why this change was made
            
        Returns:
            Updated Item or None if not found
        """
        update_data: dict[str, Any] = {"updated_at": utc_now().isoformat()}
        
        if data.item_type is not None:
            update_data["item_type"] = data.item_type.value
        if data.status is not None:
            update_data["status"] = data.status.value
        if data.content is not None:
            update_data["content"] = data.content
        if data.metadata is not None:
            update_data["metadata"] = data.metadata
            
        result = self.table.update(update_data).eq("id", str(item_id)).execute()
        
        if result.data:
            return Item(**result.data[0])
        return None
    
    async def delete(
        self,
        item_id: UUID,
        actor: Actor = (ActorType.SYSTEM, "server"),
        reasoning: str | None = None,
        hard: bool = False,
    ) -> bool:
        """
        Delete an item (soft or hard).
        
        Args:
            item_id: Item to delete
            actor: Who is deleting
            reasoning: Why deleting
            hard: If True, permanently delete. If False, soft delete.
            
        Returns:
            True if deleted, False if not found
        """
        if hard:
            result = self.table.delete().eq("id", str(item_id)).execute()
        else:
            # Soft delete
            result = self.table.update({
                "deleted_at": utc_now().isoformat(),
                "updated_at": utc_now().isoformat(),
            }).eq("id", str(item_id)).execute()
            
        return len(result.data) > 0
    
    async def restore(
        self,
        item_id: UUID,
        actor: Actor = (ActorType.SYSTEM, "server"),
    ) -> Item | None:
        """
        Restore a soft-deleted item.
        
        Returns:
            Restored Item or None if not found/not deleted
        """
        result = self.table.update({
            "deleted_at": None,
            "status": ItemStatus.ACTIVE.value,
            "updated_at": utc_now().isoformat(),
        }).eq("id", str(item_id)).not_.is_("deleted_at", "null").execute()
        
        if result.data:
            return Item(**result.data[0])
        return None
    
    async def list(
        self,
        item_type: ItemType | None = None,
        status: ItemStatus | None = None,
        limit: int = 50,
        offset: int = 0,
        include_deleted: bool = False,
    ) -> list[Item]:
        """
        List items with filters.
        
        Args:
            item_type: Filter by type
            status: Filter by status
            limit: Max results
            offset: Pagination offset
            include_deleted: Include soft-deleted items
            
        Returns:
            List of Items
        """
        query = self.table.select("*")
        
        if item_type:
            query = query.eq("item_type", item_type.value)
        if status:
            query = query.eq("status", status.value)
        if not include_deleted:
            query = query.is_("deleted_at", "null")
            
        query = query.order("created_at", desc=True).limit(limit).offset(offset)
        result = query.execute()
        
        return [Item(**r) for r in result.data]
    
    async def complete(
        self,
        item_id: UUID,
        actor: Actor = (ActorType.SYSTEM, "server"),
        reasoning: str | None = None,
    ) -> Item | None:
        """Mark an item as completed."""
        return await self.update(
            item_id,
            ItemUpdate(status=ItemStatus.COMPLETED),
            actor=actor,
            reasoning=reasoning,
        )
    
    async def archive(
        self,
        item_id: UUID,
        actor: Actor = (ActorType.SYSTEM, "server"),
        reasoning: str | None = None,
    ) -> Item | None:
        """Archive an item."""
        return await self.update(
            item_id,
            ItemUpdate(status=ItemStatus.ARCHIVED),
            actor=actor,
            reasoning=reasoning,
        )
