"""
Repository Manager.

Aggregates all repositories for convenient access.
"""

from typing import Any

from jomni.db.repositories.items import ItemRepository
from jomni.db.repositories.events import EventRepository
from jomni.db.repositories.embeddings import EmbeddingRepository


class RepositoryManager:
    """
    Aggregates all repositories for convenient access.
    
    Usage:
        repos = RepositoryManager(supabase_client)
        item = await repos.items.get(item_id)
        await repos.events.log(item_id, "updated", actor)
    """
    
    def __init__(self, client: Any):
        """
        Initialize with Supabase client.
        
        Args:
            client: Supabase client instance
        """
        self._client = client
        
        # Initialize repositories
        self._items: ItemRepository | None = None
        self._events: EventRepository | None = None
        self._embeddings: EmbeddingRepository | None = None
    
    @property
    def items(self) -> ItemRepository:
        """Get the items repository."""
        if self._items is None:
            self._items = ItemRepository(self._client)
        return self._items
    
    @property
    def events(self) -> EventRepository:
        """Get the events repository."""
        if self._events is None:
            self._events = EventRepository(self._client)
        return self._events
    
    @property
    def embeddings(self) -> EmbeddingRepository:
        """Get the embeddings repository."""
        if self._embeddings is None:
            self._embeddings = EmbeddingRepository(self._client)
        return self._embeddings
