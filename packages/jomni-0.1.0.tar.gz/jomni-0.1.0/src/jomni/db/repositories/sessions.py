"""
Chat Session Repository.

Handles chat session and message persistence for multi-turn conversations.
"""

from uuid import UUID, uuid4
from typing import Any

from jomni.db.repositories.base import BaseRepository
from jomni.models import (
    ChatSession, ChatSessionCreate, ChatSessionUpdate,
    ChatMessage, ChatMessageCreate, MessageRole, SessionMode
)
from jomni.utils.datetime import utc_now


class SessionRepository(BaseRepository[ChatSession]):
    """Repository for ChatSession operations."""
    
    table_name = "chat_sessions"
    
    def _to_model(self, data: dict) -> ChatSession:
        """Convert database row to ChatSession model."""
        return ChatSession(**data)
    
    async def create(self, data: ChatSessionCreate) -> ChatSession:
        """Create a new chat session."""
        session_id = uuid4()
        now = utc_now()
        
        row = {
            "id": str(session_id),
            "mode": data.mode.value,
            "created_at": now.isoformat(),
            "updated_at": now.isoformat(),
            "last_activity": now.isoformat(),
            "summary": None,
            "inference_complete": False,
            "metadata": data.metadata or {},
        }
        
        result = self.table.insert(row).execute()
        return ChatSession(**result.data[0])
    
    async def update(self, session_id: UUID, data: ChatSessionUpdate) -> ChatSession | None:
        """Update a chat session."""
        updates = {"updated_at": utc_now().isoformat()}
        
        if data.mode is not None:
            updates["mode"] = data.mode.value
        if data.summary is not None:
            updates["summary"] = data.summary
        if data.inference_complete is not None:
            updates["inference_complete"] = data.inference_complete
        if data.metadata is not None:
            updates["metadata"] = data.metadata
        
        result = self.table.update(updates).eq("id", str(session_id)).execute()
        
        if result.data:
            return ChatSession(**result.data[0])
        return None
    
    async def get_idle_sessions(self, idle_minutes: int = 10) -> list[ChatSession]:
        """
        Get sessions that have been idle for longer than the threshold.
        Used for running end-of-session inference.
        """
        from datetime import timedelta
        
        cutoff = utc_now() - timedelta(minutes=idle_minutes)
        
        result = self.table\
            .select("*")\
            .lt("last_activity", cutoff.isoformat())\
            .eq("inference_complete", False)\
            .eq("mode", SessionMode.PERSISTENT.value)\
            .execute()
        
        return [ChatSession(**r) for r in result.data]
    
    async def touch(self, session_id: UUID) -> None:
        """Update last_activity timestamp."""
        self.table.update({
            "last_activity": utc_now().isoformat(),
            "updated_at": utc_now().isoformat()
        }).eq("id", str(session_id)).execute()


class MessageRepository(BaseRepository[ChatMessage]):
    """Repository for ChatMessage operations."""
    
    table_name = "chat_messages"
    
    def _to_model(self, data: dict) -> ChatMessage:
        """Convert database row to ChatMessage model."""
        return ChatMessage(**data)
    
    async def create(self, data: ChatMessageCreate) -> ChatMessage:
        """Create a new chat message."""
        message_id = uuid4()
        now = utc_now()
        
        row = {
            "id": str(message_id),
            "session_id": str(data.session_id),
            "role": data.role.value,
            "content": data.content,
            "linked_item_ids": [str(id) for id in data.linked_item_ids],
            "embedding_id": None,  # Will be set later if embedded
            "created_at": now.isoformat(),
        }
        
        result = self.table.insert(row).execute()
        return ChatMessage(**result.data[0])
    
    async def get_session_history(
        self,
        session_id: UUID,
        limit: int = 20,
        offset: int = 0,
    ) -> list[ChatMessage]:
        """
        Get messages for a session, ordered by creation time.
        Most recent messages first when offset=0.
        """
        result = self.table\
            .select("*")\
            .eq("session_id", str(session_id))\
            .order("created_at", desc=True)\
            .limit(limit)\
            .offset(offset)\
            .execute()
        
        # Reverse to get chronological order for context
        messages = [ChatMessage(**r) for r in result.data]
        return list(reversed(messages))
    
    async def count_session_messages(self, session_id: UUID) -> int:
        """Count messages in a session."""
        result = self.table\
            .select("id", count="exact")\
            .eq("session_id", str(session_id))\
            .execute()
        
        return result.count or 0
    
    async def set_embedding(self, message_id: UUID, embedding_id: UUID) -> None:
        """Link a message to its embedding."""
        self.table.update({
            "embedding_id": str(embedding_id)
        }).eq("id", str(message_id)).execute()
    
    async def search_by_embedding(
        self,
        session_id: UUID | None,
        embedding: list[float],
        limit: int = 10,
    ) -> list[tuple[ChatMessage, float]]:
        """
        Search messages by embedding similarity.
        
        Note: This requires a join with embeddings table.
        For now, returns empty - full RAG implementation TBD.
        """
        # TODO: Implement vector search on chat messages
        # This will need a custom RPC function in Supabase
        return []
