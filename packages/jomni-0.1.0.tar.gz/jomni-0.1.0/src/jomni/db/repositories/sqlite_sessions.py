"""
SQLite Session Repositories (Offline Chat Support).

Provides SQLite-compatible session and message repositories for offline chat.
These mirror the Supabase SessionRepository and MessageRepository APIs but use
SQLAlchemy for local SQLite storage.

Created: 2025-12 for offline-first chat support.

Why this exists:
    The main SessionRepository in db/repositories/sessions.py uses Supabase's
    .table().insert().execute() API which doesn't work with SQLite. These
    SQLite-specific repos provide the same async interface but use SQLAlchemy.

Usage:
    # In chat endpoint - auto-selects based on db type
    if isinstance(db, SQLiteClient):
        session_repo = SQLiteSessionRepository(db)
        message_repo = SQLiteMessageRepository(db)
    else:
        session_repo = SessionRepository(db.client)  # Supabase
"""

from uuid import UUID, uuid4
from typing import Any

from jomni.models import (
    ChatSession, ChatSessionCreate, ChatSessionUpdate,
    ChatMessage, ChatMessageCreate, MessageRole, SessionMode
)
from jomni.utils.datetime import utc_now


class SQLiteSessionRepository:
    """SQLite-compatible session repository."""
    
    def __init__(self, db):
        """
        Initialize with SQLiteClient.
        
        Args:
            db: SQLiteClient instance
        """
        self.db = db
    
    async def get_by_id(self, session_id: UUID) -> ChatSession | None:
        """Get a session by ID."""
        from sqlalchemy import select
        
        with self.db.engine.connect() as conn:
            stmt = select(self.db.chat_sessions).where(
                self.db.chat_sessions.c.id == str(session_id)
            )
            result = conn.execute(stmt).first()
            
            if result:
                data = dict(result._mapping)
                # Convert integer to boolean
                data["inference_complete"] = bool(data.get("inference_complete", 0))
                return ChatSession(**data)
            return None
    
    async def create(self, data: ChatSessionCreate) -> ChatSession:
        """Create a new chat session."""
        session_id = uuid4()
        now = utc_now()
        
        row = {
            "id": str(session_id),
            "mode": data.mode.value,
            "created_at": now.isoformat(),
            "updated_at": now.isoformat(),
            "last_activity": now.isoformat(),
            "summary": None,
            "inference_complete": 0,
            "metadata": data.metadata or {},
        }
        
        with self.db.engine.connect() as conn:
            conn.execute(self.db.chat_sessions.insert().values(**row))
            conn.commit()
        
        return await self.get_by_id(session_id)
    
    async def update(self, session_id: UUID, data: ChatSessionUpdate) -> ChatSession | None:
        """Update a chat session."""
        updates = {"updated_at": utc_now().isoformat()}
        
        if data.mode is not None:
            updates["mode"] = data.mode.value
        if data.summary is not None:
            updates["summary"] = data.summary
        if data.inference_complete is not None:
            updates["inference_complete"] = 1 if data.inference_complete else 0
        if data.metadata is not None:
            updates["metadata"] = data.metadata
        
        with self.db.engine.connect() as conn:
            conn.execute(
                self.db.chat_sessions.update()
                .where(self.db.chat_sessions.c.id == str(session_id))
                .values(**updates)
            )
            conn.commit()
        
        return await self.get_by_id(session_id)
    
    async def touch(self, session_id: UUID) -> None:
        """Update last_activity timestamp."""
        now = utc_now().isoformat()
        
        with self.db.engine.connect() as conn:
            conn.execute(
                self.db.chat_sessions.update()
                .where(self.db.chat_sessions.c.id == str(session_id))
                .values(last_activity=now, updated_at=now)
            )
            conn.commit()


class SQLiteMessageRepository:
    """SQLite-compatible message repository."""
    
    def __init__(self, db):
        """
        Initialize with SQLiteClient.
        
        Args:
            db: SQLiteClient instance
        """
        self.db = db
    
    async def create(self, data: ChatMessageCreate) -> ChatMessage:
        """Create a new chat message."""
        message_id = uuid4()
        now = utc_now()
        
        row = {
            "id": str(message_id),
            "session_id": str(data.session_id),
            "role": data.role.value,
            "content": data.content,
            "linked_item_ids": [str(id) for id in data.linked_item_ids],
            "embedding_id": None,
            "created_at": now.isoformat(),
        }
        
        with self.db.engine.connect() as conn:
            conn.execute(self.db.chat_messages.insert().values(**row))
            conn.commit()
        
        return await self.get_by_id(message_id)
    
    async def get_by_id(self, message_id: UUID) -> ChatMessage | None:
        """Get a message by ID."""
        from sqlalchemy import select
        
        with self.db.engine.connect() as conn:
            stmt = select(self.db.chat_messages).where(
                self.db.chat_messages.c.id == str(message_id)
            )
            result = conn.execute(stmt).first()
            
            if result:
                return ChatMessage(**result._mapping)
            return None
    
    async def get_session_history(
        self,
        session_id: UUID,
        limit: int = 20,
        offset: int = 0,
    ) -> list[ChatMessage]:
        """Get messages for a session, ordered by creation time."""
        from sqlalchemy import select
        
        with self.db.engine.connect() as conn:
            stmt = select(self.db.chat_messages)\
                .where(self.db.chat_messages.c.session_id == str(session_id))\
                .order_by(self.db.chat_messages.c.created_at.desc())\
                .limit(limit)\
                .offset(offset)
            
            results = conn.execute(stmt).fetchall()
            
            # Reverse to get chronological order for context
            messages = [ChatMessage(**r._mapping) for r in results]
            return list(reversed(messages))
