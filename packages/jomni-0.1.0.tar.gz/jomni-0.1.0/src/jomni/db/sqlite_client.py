"""
SQLite Database Client (Local Development/Offline).

Provides local database for development and offline access.
Implements full CRUD operations for items, tags, and relations.

IMPLEMENTATION STATUS:
- ✅ Items: create, read, update, delete (soft/hard), restore, complete
- ✅ Tags: add, remove
- ✅ Relations: create
- ⚠️ AI Features: embeddings, corrections, goals (graceful stubs - no-op locally)
- ✅ Services: credentials storage

NOTE: Uses explicit actor pattern (see db/protocol.py for details).
"""

import json
import logging
import os
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any
from uuid import UUID, uuid4

from sqlalchemy import (
    Column,
    create_engine,
    MetaData,
    Table,
    String,
    Integer,
    JSON,
    ForeignKey,
    text,
    select,
    and_,
    or_,
    func,
)
from sqlalchemy.dialects.sqlite import JSON as SQLiteJSON, insert

from jomni.config import get_settings
from jomni.db.protocol import DatabaseProtocol, Actor
from jomni.utils.datetime import utc_now
from jomni.models import (
    ActorType,
    EmbeddingCreate,
    Item,
    ItemCreate,
    ItemStatus,
    ItemType,
    ItemUpdate,
    Relation,
    RelationCreate,
    Service,
    ServiceCredential,
)

logger = logging.getLogger(__name__)


class SQLiteClient(DatabaseProtocol):
    """
    SQLite implementation of DatabaseProtocol.
    
    Phase 1: Read-only fallback.
    Writes raise NotImplementedError.
    """

    def __init__(self, db_path: str | None = None):
        if not db_path:
            settings = get_settings()
            db_path = settings.sqlite_path
            
        # Expand user path (e.g. ~/.jomni/local.db)
        self.db_path = Path(os.path.expanduser(db_path))
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        self.engine = create_engine(f"sqlite:///{self.db_path}")
        self.metadata = MetaData()
        
        # Define Schema
        self.items = Table(
            "items",
            self.metadata,
            Column("id", String, primary_key=True),
            Column("created_at", String, nullable=False),
            Column("updated_at", String, nullable=False),
            Column("item_type", String, nullable=False),
            Column("status", String, nullable=False),
            Column("parent_id", String, nullable=True),
            Column("schema_version", Integer, default=1),
            Column("content", JSON, nullable=False),
            Column("metadata", JSON, nullable=True),
            Column("deleted_at", String, nullable=True),
            # =========================================================================
            # SYNC COLUMNS (Phase 1 Sync Engine - Added 2025-12)
            # Enable offline-first sync between SQLite (local) and Supabase (cloud)
            # =========================================================================
            Column("sync_id", String, nullable=True),  # Cloud UUID when pushed to Supabase
            Column("local_updated_at", String, nullable=True),  # Timestamp of local change
            Column("synced_at", String, nullable=True),  # Last successful sync timestamp
            Column("sync_status", String, default="pending"),  # pending | synced | conflict
            Column("deleted_locally", Integer, default=0),  # Tombstone: 1=deleted, needs sync
        )
        
        self.relations = Table(
            "relations",
            self.metadata,
            Column("id", String, primary_key=True),
            Column("created_at", String, nullable=False),
            Column("source_id", String, ForeignKey("items.id"), nullable=False),
            Column("target_id", String, ForeignKey("items.id"), nullable=False),
            Column("relation_type", String, nullable=False),
            Column("metadata", JSON, nullable=True),
        )
        
        self.item_tags = Table(
            "item_tags",
            self.metadata,
            Column("item_id", String, ForeignKey("items.id"), primary_key=True),
            Column("tag", String, primary_key=True),
            Column("created_at", String, nullable=False),
        )
        
        self.services = Table(
            "services",
            self.metadata,
            Column("name", String, primary_key=True),
            Column("is_connected", Integer, default=0), # Boolean as Integer
            Column("connected_at", String, nullable=True),
            Column("metadata", JSON, nullable=True),
        )
        
        # =========================================================================
        # CHAT SESSION TABLES (Offline Chat Support - Added 2025-12)
        # Mirror Supabase chat_sessions/chat_messages for offline chat functionality
        # See: db/repositories/sqlite_sessions.py for repository implementation
        # =========================================================================
        self.chat_sessions = Table(
            "chat_sessions",
            self.metadata,
            Column("id", String, primary_key=True),
            Column("mode", String, nullable=False),  # ephemeral | persistent
            Column("created_at", String, nullable=False),
            Column("updated_at", String, nullable=False),
            Column("last_activity", String, nullable=False),  # For idle session detection
            Column("summary", String, nullable=True),  # AI-generated session summary
            Column("inference_complete", Integer, default=0),  # Boolean: end-of-session inference done
            Column("metadata", JSON, nullable=True),
        )
        
        self.chat_messages = Table(
            "chat_messages",
            self.metadata,
            Column("id", String, primary_key=True),
            Column("session_id", String, ForeignKey("chat_sessions.id"), nullable=False),
            Column("role", String, nullable=False),  # user | assistant | system
            Column("content", JSON, nullable=False),  # Message content/structured data
            Column("linked_item_ids", JSON, nullable=True),  # Items referenced in message
            Column("embedding_id", String, nullable=True),  # For RAG search
            Column("created_at", String, nullable=False),
        )
        
        self.service_credentials = Table(
            "service_credentials",
            self.metadata,
            Column("service_name", String, ForeignKey("services.name"), primary_key=True),
            Column("access_token", String, nullable=False),
            Column("refresh_token", String, nullable=True),
            Column("expires_at", String, nullable=True),
            Column("updated_at", String, nullable=False),
        )
        
        # =========================================================================
        # USER PREFERENCES (Privacy & Consent - Added 2025-12)
        # Stores user consent flags for GDPR/CCPA compliance.
        # Critical: AI corrections should NOT be stored without ai_training_consent=1
        # =========================================================================
        self.user_preferences = Table(
            "user_preferences",
            self.metadata,
            Column("id", String, primary_key=True),  # "default" for single-user
            Column("ai_training_consent", Integer, default=0),  # 0=no, 1=yes (OPT-IN)
            Column("analytics_consent", Integer, default=1),  # 0=no, 1=yes (OPT-OUT)
            Column("data_sync_consent", Integer, default=1),  # 0=no, 1=yes (OPT-OUT)
            Column("created_at", String, nullable=False),
            Column("updated_at", String, nullable=False),
        )
        
        # Create tables if they don't exist
        self.metadata.create_all(self.engine)
        
        self._current_session_id: UUID | None = None

    # =========================================================================
    # SESSION MANAGEMENT
    # =========================================================================

    def set_session(self, session_id: UUID) -> None:
        self._current_session_id = session_id

    def new_session(self) -> UUID:
        self._current_session_id = uuid4()
        return self._current_session_id

    # =========================================================================
    # ITEMS (READ)
    # =========================================================================

    async def get_item(self, item_id: UUID) -> Item | None:
        """Get an item by ID."""
        with self.engine.connect() as conn:
            stmt = select(self.items).where(self.items.c.id == str(item_id))
            result = conn.execute(stmt).first()
            
            if not result:
                return None
                
            return Item(**result._mapping)

    async def list_items(
        self,
        item_type: ItemType | None = None,
        status: ItemStatus | None = None,
        parent_id: UUID | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[Item]:
        """List items with optional filters."""
        with self.engine.connect() as conn:
            stmt = select(self.items).where(self.items.c.deleted_at.is_(None))
            
            if item_type:
                stmt = stmt.where(self.items.c.item_type == item_type.value)
            
            if status:
                stmt = stmt.where(self.items.c.status == status.value)
                
            if parent_id:
                stmt = stmt.where(self.items.c.parent_id == str(parent_id))
                
            stmt = stmt.order_by(self.items.c.created_at.desc()).limit(limit).offset(offset)
            
            results = conn.execute(stmt).fetchall()
            return [Item(**row._mapping) for row in results]

    async def get_inbox(self, limit: int = 50) -> list[Item]:
        """Get all items in inbox status."""
        return await self.list_items(status=ItemStatus.INBOX, limit=limit)
    
    async def bulk_update_items(
        self,
        set_status: ItemStatus,
        filter_type: ItemType | None = None,
        filter_status: ItemStatus | None = None,
        limit: int = 1000,
        actor: Actor = (ActorType.SYSTEM, "local"),
        reasoning: str | None = None,
    ) -> int:
        """
        Bulk update items matching filters.
        
        Returns count of items updated.
        """
        items = await self.list_items(
            item_type=filter_type,
            status=filter_status,
            limit=limit,
        )
        
        if not items:
            return 0
        
        updated = 0
        for item in items:
            try:
                await self.update_item(
                    item.id,
                    ItemUpdate(status=set_status),
                    actor=actor,
                    reasoning=reasoning or f"Bulk update to {set_status.value}",
                )
                updated += 1
            except Exception:
                pass
        
        return updated

    # =========================================================================
    # SEARCH (READ)
    # =========================================================================

    async def semantic_search(
        self,
        embedding: list[float],
        limit: int = 10,
        item_types: list[ItemType] | None = None,
        statuses: list[ItemStatus] | None = None,
    ) -> list[tuple[Item, float]]:
        """
        Fallback search using text matching since SQLite lacks vector search.
        Ignores the embedding vector and searches content/metadata instead.
        """
        # Note: This is a limitation of the fallback mode.
        # We return recent items matching filters as a "best effort"
        # In a real implementation, we might use FTS5 for text search
        
        logger.warning("SQLite fallback: semantic_search falling back to recent items")
        
        items = await self.list_items(limit=limit)
        
        # Filter by type/status if provided (though list_items handles single values)
        filtered = []
        for item in items:
            if item_types and item.item_type not in item_types:
                continue
            if statuses and item.status not in statuses:
                continue
            filtered.append((item, 0.0))  # 0.0 score as we can't compute similarity
            
        return filtered[:limit]

    # =========================================================================
    # RELATIONS (READ)
    # =========================================================================

    async def get_related_items(
        self,
        item_id: UUID,
        relation_type: str | None = None,
    ) -> list[Item]:
        """Get all items related to the given item."""
        with self.engine.connect() as conn:
            # Find relations where source is item_id
            stmt = select(self.relations).where(self.relations.c.source_id == str(item_id))
            
            if relation_type:
                stmt = stmt.where(self.relations.c.relation_type == relation_type)
                
            relations = conn.execute(stmt).fetchall()
            target_ids = [r.target_id for r in relations]
            
            if not target_ids:
                return []
                
            # Fetch the actual items
            stmt_items = select(self.items).where(self.items.c.id.in_(target_ids))
            results = conn.execute(stmt_items).fetchall()
            return [Item(**row._mapping) for row in results]

    async def get_relations_for_items(
        self,
        item_ids: list[UUID],
    ) -> dict[UUID, list[Relation]]:
        """
        Get all relations for a list of items.
        Returns a dictionary mapping item_id to list of Relations.
        """
        if not item_ids:
            return {}
            
        ids = [str(i) for i in item_ids]
        with self.engine.connect() as conn:
            stmt = select(self.relations).where(self.relations.c.source_id.in_(ids))
            results = conn.execute(stmt).fetchall()
            
            relations_by_item = {uid: [] for uid in item_ids}
            for row in results:
                relation = Relation(**row._mapping)
                source_uuid = relation.source_id
                if source_uuid in relations_by_item:
                    relations_by_item[source_uuid].append(relation)
                    
            return relations_by_item

    # =========================================================================
    # ANALYTICS & DIGEST
    # =========================================================================

    async def get_digest_stats(self) -> dict[str, Any]:
        """
        Get statistics for the daily digest.
        Returns counts by status, goal progress, etc.
        """
        now = utc_now()
        today_start = now.replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
        yesterday_start = (now - timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
        
        with self.engine.connect() as conn:
            # 1. Counts by status
            inbox_count = conn.execute(
                select(func.count()).select_from(self.items).where(self.items.c.status == "inbox")
            ).scalar()
            
            active_count = conn.execute(
                select(func.count()).select_from(self.items).where(self.items.c.status == "active")
            ).scalar()
            
            # 2. Completed today/yesterday
            completed_today = conn.execute(
                select(func.count()).select_from(self.items)
                .where(self.items.c.status == "completed")
                .where(self.items.c.updated_at >= today_start)
            ).scalar()
            
            completed_yesterday = conn.execute(
                select(func.count()).select_from(self.items)
                .where(self.items.c.status == "completed")
                .where(self.items.c.updated_at >= yesterday_start)
                .where(self.items.c.updated_at < today_start)
            ).scalar()
            
            # 3. Goals
            goals_result = conn.execute(
                select(self.items)
                .where(self.items.c.item_type == "goal")
                .where(self.items.c.status == "active")
            ).fetchall()
            goals = [Item(**r._mapping) for r in goals_result]
            
            # 4. Stale items
            stale_threshold = (now - timedelta(days=14)).isoformat()
            stale_items_result = conn.execute(
                select(self.items)
                .where(self.items.c.status == "active")
                .where(self.items.c.updated_at < stale_threshold)
                .limit(10)
            ).fetchall()
            stale_items = [Item(**r._mapping) for r in stale_items_result]
            
            return {
                "summary": {
                    "inbox": inbox_count,
                    "active": active_count,
                    "completed_today": completed_today,
                    "completed_yesterday": completed_yesterday,
                },
                "goals": goals,
                "stale_items": stale_items,
            }

    # =========================================================================
    # GOALS (READ)
    # =========================================================================

    async def list_goals(
        self,
        horizon: str | None = None,
        status: ItemStatus | None = None,
        limit: int = 50,
    ) -> list[Item]:
        """List goals with optional filters."""
        with self.engine.connect() as conn:
            stmt = select(self.items).where(
                and_(
                    self.items.c.item_type == ItemType.GOAL.value,
                    self.items.c.deleted_at.is_(None)
                )
            )
            
            if status:
                stmt = stmt.where(self.items.c.status == status.value)
                
            # Filter by horizon in metadata
            # SQLite JSON extraction: json_extract(metadata, '$.horizon')
            if horizon:
                stmt = stmt.where(
                    text("json_extract(metadata, '$.horizon') = :horizon").bindparams(horizon=horizon)
                )
                
            stmt = stmt.order_by(self.items.c.created_at.desc()).limit(limit)
            
            results = conn.execute(stmt).fetchall()
            return [Item(**row._mapping) for row in results]

    # =========================================================================
    # WRITE OPERATIONS (Local testing support)
    # =========================================================================

    def _raise_readonly(self):
        raise NotImplementedError("SQLite fallback is currently read-only. Connect to Supabase for write operations.")

    async def create_item(
        self,
        data: ItemCreate,
        actor: Actor = (ActorType.SYSTEM, "local"),
        reasoning: str | None = None,
        confidence: float | None = None,
    ) -> Item:
        """Create a new item in SQLite."""
        now = utc_now()
        item_id = str(uuid4())
        
        with self.engine.connect() as conn:
            conn.execute(
                self.items.insert().values(
                    id=item_id,
                    created_at=now.isoformat(),
                    updated_at=now.isoformat(),
                    item_type=data.item_type.value,
                    status=data.status.value if data.status else ItemStatus.INBOX.value,
                    parent_id=str(data.parent_id) if data.parent_id else None,
                    schema_version=1,
                    content=data.content,
                    metadata=data.metadata or {},
                    deleted_at=None,
                    # Sync columns - mark as needing sync
                    local_updated_at=now.isoformat(),
                    sync_status="pending",
                )
            )
            conn.commit()
            
        return await self.get_item(UUID(item_id))

    async def update_item(
        self,
        item_id: UUID,
        data: ItemUpdate,
        actor: Actor = (ActorType.SYSTEM, "local"),
        reasoning: str | None = None,
        confidence: float | None = None,
    ) -> Item | None:
        """Update an existing item in SQLite."""
        current = await self.get_item(item_id)
        if not current:
            return None
        
        now = utc_now().isoformat()
        updates = {
            "updated_at": now,
            # Mark as needing sync
            "local_updated_at": now,
            "sync_status": "pending",
        }
        
        if data.status is not None:
            updates["status"] = data.status.value
        if data.content is not None:
            updates["content"] = data.content
        if data.metadata is not None:
            updates["metadata"] = data.metadata
        if data.parent_id is not None:
            updates["parent_id"] = str(data.parent_id)
            
        with self.engine.connect() as conn:
            conn.execute(
                self.items.update()
                .where(self.items.c.id == str(item_id))
                .values(**updates)
            )
            conn.commit()
            
        return await self.get_item(item_id)

    async def archive_item(
        self,
        item_id: UUID,
        actor: Actor = (ActorType.SYSTEM, "local"),
        reasoning: str | None = None,
    ) -> Item | None:
        """Archive an item (soft delete)."""
        return await self.update_item(
            item_id,
            ItemUpdate(status=ItemStatus.ARCHIVED),
            actor=actor,
            reasoning=reasoning,
        )

    async def delete_item(
        self,
        item_id: UUID,
        actor: Actor = (ActorType.SYSTEM, "local"),
        reasoning: str | None = None,
        hard_delete: bool = False,
    ) -> bool:
        """
        Delete an item from the local database.
        
        Args:
            item_id: ID of the item to delete
            actor: Who is deleting (for audit trail parity with Supabase)
            reasoning: Why it was deleted (not stored locally, but API parity)
            hard_delete: If True, permanently removes; if False, sets deleted_at
            
        Returns:
            True if deleted, False if item not found
        """
        item = await self.get_item(item_id)
        if not item:
            return False
        
        now = utc_now().isoformat()
        
        with self.engine.connect() as conn:
            if hard_delete:
                # Hard delete: permanently remove from database
                # Must delete related records first (foreign key constraints)
                conn.execute(
                    self.item_tags.delete().where(self.item_tags.c.item_id == str(item_id))
                )
                conn.execute(
                    self.relations.delete().where(
                        or_(
                            self.relations.c.source_id == str(item_id),
                            self.relations.c.target_id == str(item_id)
                        )
                    )
                )
                # Finally delete the item itself
                conn.execute(
                    self.items.delete().where(self.items.c.id == str(item_id))
                )
            else:
                # Soft delete: set deleted_at timestamp (item remains in DB)
                # This allows restore_item to bring it back
                conn.execute(
                    self.items.update()
                    .where(self.items.c.id == str(item_id))
                    .values(deleted_at=now, updated_at=now)
                )
            conn.commit()
        
        return True
    
    async def restore_item(
        self,
        item_id: UUID,
        actor: Actor = (ActorType.SYSTEM, "local"),
        reasoning: str | None = None,
    ) -> Item | None:
        """
        Restore a soft-deleted item by clearing deleted_at.
        
        Only works on soft-deleted items (those with deleted_at set).
        Hard-deleted items cannot be restored.
        """
        with self.engine.connect() as conn:
            # Clear deleted_at to "un-delete" the item
            conn.execute(
                self.items.update()
                .where(self.items.c.id == str(item_id))
                .values(deleted_at=None, updated_at=utc_now().isoformat())
            )
            conn.commit()
        
        return await self.get_item(item_id)
    
    async def complete_item(
        self,
        item_id: UUID,
        actor: Actor = (ActorType.SYSTEM, "local"),
        reasoning: str | None = None,
    ) -> Item | None:
        """
        Mark an item as completed.
        
        Convenience wrapper around update_item that sets status to COMPLETED.
        Commonly used for tasks and habits.
        """
        return await self.update_item(
            item_id,
            ItemUpdate(status=ItemStatus.COMPLETED),
            actor=actor,
            reasoning=reasoning,
        )
    
    # =========================================================================
    # TAGS
    # Tags are stored in a separate item_tags table with (item_id, tag) as PK.
    # This allows many-to-many relationships and efficient tag queries.
    # =========================================================================
    
    async def add_tags_to_item(
        self,
        item_id: UUID,
        tags: list[str],
    ) -> None:
        """
        Add one or more tags to an item.
        
        Tags that already exist on the item are silently ignored.
        Uses individual inserts wrapped in try/except for idempotency.
        """
        now = utc_now().isoformat()
        
        with self.engine.connect() as conn:
            for tag in tags:
                try:
                    conn.execute(
                        self.item_tags.insert().values(
                            item_id=str(item_id),
                            tag=tag,
                            created_at=now,
                        )
                    )
                except Exception as dup_err:
                    # Tag already exists on this item - expected for idempotent upserts
                    logger.debug(f"Tag insert for {item_id}: {dup_err}")
            conn.commit()
    
    async def remove_tag_from_item(
        self,
        item_id: UUID,
        tag: str,
    ) -> None:
        """
        Remove a specific tag from an item.
        
        No-op if the tag doesn't exist on the item.
        """
        with self.engine.connect() as conn:
            conn.execute(
                self.item_tags.delete().where(
                    and_(
                        self.item_tags.c.item_id == str(item_id),
                        self.item_tags.c.tag == tag
                    )
                )
            )
            conn.commit()
    
    # =========================================================================
    # RELATIONS
    # Relations connect items to each other (e.g., task SUPPORTS goal).
    # Stored in relations table with source_id -> target_id direction.
    # =========================================================================
    
    async def create_relation(self, data: RelationCreate) -> Relation:
        """
        Create a directional relation between two items.
        
        Relations have types (SUPPORTS, BLOCKS, etc.) and are directional:
        source_id --[relation_type]--> target_id
        
        Example: Task "Write report" SUPPORTS Goal "Get promoted"
        """
        from uuid import uuid4
        
        now = utc_now().isoformat()
        relation_id = str(uuid4())
        
        with self.engine.connect() as conn:
            conn.execute(
                self.relations.insert().values(
                    id=relation_id,
                    created_at=now,
                    source_id=str(data.source_id),
                    target_id=str(data.target_id),
                    relation_type=data.relation_type.value,
                    metadata=data.metadata or {},
                )
            )
            conn.commit()
        
        # Construct and return the Relation object
        return Relation(
            id=UUID(relation_id),
            created_at=now,
            source_id=data.source_id,
            target_id=data.target_id,
            relation_type=data.relation_type,
            metadata=data.metadata or {},
        )
    
    # =========================================================================
    # AI FEATURES (graceful stubs - local mode doesn't need these)
    # These methods exist for API parity with SupabaseClient but are no-ops
    # locally since vector search and corrections require cloud infrastructure.
    # =========================================================================
    
    async def store_embedding(self, data: EmbeddingCreate) -> None:
        """Store embedding - no-op in SQLite mode (no vector search locally)."""
        logger.debug(f"SQLite: store_embedding skipped for item {data.item_id}")
    
    async def store_correction(self, **kwargs) -> None:
        """Store correction - no-op in SQLite mode (corrections sync from cloud)."""
        logger.debug("SQLite: store_correction skipped (no local corrections table)")
    
    async def create_goal(self, **kwargs):
        """
        Create goal - goals are just items with item_type=GOAL.
        
        In SQLite mode, use create_item(ItemCreate(item_type=ItemType.GOAL, ...)) instead.
        """
        logger.debug("SQLite: create_goal not implemented (use create_item with ItemType.GOAL)")
        return None
    
    async def link_item_to_goal(self, item_id: UUID, goal_id: UUID) -> None:
        """
        Link an item to a goal via SUPPORTS relation.
        
        This creates a relation: item_id --SUPPORTS--> goal_id
        """
        from jomni.models import RelationType
        await self.create_relation(RelationCreate(
            source_id=item_id,
            target_id=goal_id,
            relation_type=RelationType.SUPPORTS,
        ))
    
    async def assess_goal(self, goal_id: UUID, **kwargs):
        """Assess goal progress - no-op in SQLite mode."""
        logger.debug(f"SQLite: assess_goal skipped for {goal_id}")
        return None
    
    async def update_goal(self, goal_id: UUID, **kwargs):
        """Update goal - use update_item instead."""
        logger.debug(f"SQLite: update_goal not implemented (use update_item)")
        return None
    
    async def get_similar_corrections(
        self,
        embedding: list[float],
        correction_type: str = "classification",
        limit: int = 5,
    ) -> list[dict]:
        """
        Get similar corrections - stub in SQLite mode.
        
        Corrections are stored in Supabase with vector embeddings for
        few-shot learning. SQLite doesn't support this, so return empty list.
        """
        logger.debug("SQLite: get_similar_corrections returning empty (no vector search locally)")
        return []
    # =========================================================================
    # SERVICES & AUTH
    # =========================================================================

    async def get_service(self, name: str) -> Service | None:
        """Get service status by name."""
        with self.engine.connect() as conn:
            stmt = select(self.services).where(self.services.c.name == name)
            result = conn.execute(stmt).first()
            
            if not result:
                return None
                
            data = dict(result._mapping)
            data["is_connected"] = bool(data["is_connected"])
            return Service(**data)

    async def store_credentials(self, creds: ServiceCredential) -> None:
        """Store encrypted service credentials."""
        with self.engine.connect() as conn:
            # Upsert service
            # SQLite upsert: INSERT OR REPLACE
            conn.execute(
                insert(self.services).values(
                    name=creds.service_name,
                    is_connected=1,
                    connected_at=utc_now().isoformat(),
                    metadata={}
                ).on_conflict_do_update(
                    index_elements=["name"],
                    set_={
                        "is_connected": 1,
                        "connected_at": utc_now().isoformat()
                    }
                )
            )
            
            # Upsert credentials
            data = creds.model_dump()
            data["expires_at"] = data["expires_at"].isoformat() if data["expires_at"] else None
            data["updated_at"] = data["updated_at"].isoformat()
            
            conn.execute(
                insert(self.service_credentials).values(**data).on_conflict_do_update(
                    index_elements=["service_name"],
                    set_=data
                )
            )
            conn.commit()

    async def get_credentials(self, service_name: str) -> ServiceCredential | None:
        """Get encrypted service credentials."""
        with self.engine.connect() as conn:
            stmt = select(self.service_credentials).where(self.service_credentials.c.service_name == service_name)
            result = conn.execute(stmt).first()
            
            if not result:
                return None
                
            return ServiceCredential(**result._mapping)
