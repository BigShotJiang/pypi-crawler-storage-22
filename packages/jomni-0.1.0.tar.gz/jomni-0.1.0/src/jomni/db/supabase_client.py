"""
Jomni database client.

Handles all database operations with automatic event logging.
Every mutation creates an event—this is the core of event sourcing.

NOTE: Uses explicit actor pattern (not stateful set_actor) to avoid
race conditions. See protocol.py for detailed architecture explanation.
"""

import asyncio
import hashlib
import json
import logging
from datetime import datetime, timedelta
from typing import Any
from uuid import UUID, uuid4

from supabase import create_client, Client

from jomni.config import get_settings
from jomni.db.protocol import DatabaseProtocol, Actor
from jomni.utils.datetime import utc_now
from jomni.models import (
    Item, ItemCreate, ItemUpdate, ItemType, ItemStatus,
    Event, EventCreate, ActorType,
    Embedding, EmbeddingCreate,
    Relation, RelationCreate, RelationType,
    Service, ServiceCredential
)

logger = logging.getLogger(__name__)



class SupabaseClient(DatabaseProtocol):
    """
    Supabase database client for Jomni personal database.
    
    CONTEXT:
    Jomni stores everything as "Items" (tasks, notes, goals, events, etc.).
    This client provides the primary production database backend using Supabase
    (hosted PostgreSQL with pgvector for semantic search).
    
    Every mutation is logged to an events table for complete audit trail
    and potential replay (event sourcing pattern).
    
    ARCHITECTURE:
    - items table: Current state of all items (the "materialized view")
    - events table: Immutable log of all changes (the "source of truth")
    - embeddings table: Vector embeddings for semantic search (pgvector)
    - relations table: Graph of item relationships (parent, blocks, supports)
    - corrections table: User corrections for AI learning
    
    WARNING - ATOMICITY LIMITATIONS:
    Multi-table operations (e.g., create_item + log_event) are NOT transactional.
    Supabase-py client doesn't support client-side transactions. In rare failure
    cases, items may exist without corresponding events. For critical operations,
    consider using Supabase Edge Functions with database transactions.
    
    ENTRY POINTS BY USE CASE:
    - Item CRUD: create_item(), get_item(), update_item(), delete_item()
    - Bulk operations: list_items(), get_inbox(), delete_items()
    - Search: semantic_search() (vector), list_items() (filters)
    - Analytics: get_digest_stats()
    - Auth/Services: store_credentials(), get_credentials(), get_service()
    - AI Learning: store_correction(), get_similar_corrections()
    
    COMPLEXITY: Critical
    Core data layer. Changes affect ALL API endpoints and integrations.
    Modifications require understanding of event sourcing and pgvector.
    
    PERFORMANCE:
    - Single item operations: 20-50ms (Supabase round trip)
    - Semantic search: 100-300ms (pgvector similarity + filters)
    - list_items with filters: 30-100ms depending on result size
    - Batch operations: ~50ms per item (serialized, not parallel)
    
    See Also:
    - db/sqlite_client.py: Offline/development implementation
    - db/protocol.py: Interface contract and Actor pattern docs
    """
    
    def __init__(self):
        settings = get_settings()
        self.client: Client = create_client(
            settings.supabase_url,
            settings.supabase_service_key  # Use service key for server-side operations
        )
        self._current_session_id: UUID | None = None
    
    # =========================================================================
    # SESSION MANAGEMENT
    # =========================================================================
    
    def set_session(self, session_id: UUID) -> None:
        """Set the current session for grouping related events."""
        self._current_session_id = session_id
    
    def new_session(self) -> UUID:
        """Start a new session and return its ID."""
        self._current_session_id = uuid4()
        return self._current_session_id
    
    # =========================================================================
    # ITEMS
    # =========================================================================
    
    async def create_item(
        self,
        data: ItemCreate,
        actor: Actor = (ActorType.SYSTEM, "server"),
        reasoning: str | None = None,
        confidence: float | None = None,
    ) -> Item:
        """
        Create a new item with automatic event logging.
        
        Args:
            data: The item data to create
            actor: Who is creating (explicit, no race condition)
            reasoning: AI reasoning (if actor is AI)
            confidence: AI confidence score (if actor is AI)
            
        Returns:
            The created Item
        """
        item_id = uuid4()
        now = utc_now().isoformat()
        
        # Prepare the item record
        record = {
            "id": str(item_id),
            "created_at": now,
            "updated_at": now,
            "item_type": data.item_type.value,
            "status": data.status.value,
            "parent_id": str(data.parent_id) if data.parent_id else None,
            "schema_version": 1,
            "content": data.content,
            "metadata": data.metadata,
        }
        
        # Insert the item
        result = self.client.table("items").insert(record).execute()
        item = Item(**result.data[0])
        
        # Log the creation event
        await self._log_event(
            item_id=item_id,
            action="created",
            actor=actor,
            changes={"item": record},
            reasoning=reasoning,
            confidence=confidence,
        )
        
        # Trigger webhooks (fire and forget)
        try:
            from jomni.api.webhooks import trigger_webhooks
            import asyncio
            asyncio.create_task(trigger_webhooks("item.created", {
                "item_id": str(item.id),
                "item_type": item.item_type.value,
                "status": item.status.value,
            }, self))
        except Exception as e:
            logger.warning(f"Webhook trigger failed for item.created: {e}")
        
        return item
    
    async def get_item(self, item_id: UUID) -> Item | None:
        """
        Retrieve an item by its UUID.
        
        CONTEXT:
        Returns the item regardless of status (including soft-deleted).
        For active-only queries, use list_items() with status filter.
        
        TECHNICAL:
        Returns:
            Item if found, None if no item with that ID exists.
            Does NOT filter by deleted_at—check item.deleted_at if needed.
            
        Performance: Single row lookup by primary key, O(1), ~20-30ms.
        
        COMPLEXITY: Low
        """
        result = self.client.table("items")\
            .select("*")\
            .eq("id", str(item_id))\
            .execute()
        
        if not result.data:
            return None
        return Item(**result.data[0])
    
    async def update_item(
        self,
        item_id: UUID,
        data: ItemUpdate,
        actor: Actor = (ActorType.SYSTEM, "server"),
        reasoning: str | None = None,
        confidence: float | None = None,
    ) -> Item | None:
        """
        Update an item with automatic event logging (partial update).
        
        CONTEXT:
        Core mutation method used by all item modifications. Only fields
        explicitly set in ItemUpdate are changed—others remain untouched.
        Every update logs an event with before/after diff for audit trail.
        
        EXAMPLE:
        Update just the status: ItemUpdate(status=ItemStatus.COMPLETED)
        Update content: ItemUpdate(content={"text": "new text", "due": "...")
        
        TECHNICAL:
        Args:
            item_id: UUID of item to update
            data: ItemUpdate with fields to change (None = no change)
            actor: Who is updating (required for audit trail)
            reasoning: Why the update was made (shown in history)
            confidence: AI confidence 0.0-1.0 (if actor is AI)
            
        Returns:
            Updated Item, or None if item_id not found.
            Returns unchanged item if no fields differ.
            
        Side Effects:
            - Logs 'updated' event to events table
            - Sets updated_at to current timestamp
            
        Performance: ~50ms (read + update + event insert)
        
        COMPLEXITY: Medium
        Changes propagate to event log and affect history views.
        """
        # Get current state for diffing
        current = await self.get_item(item_id)
        if not current:
            return None
        
        # Build update dict with only provided fields
        updates: dict[str, Any] = {}
        changes: dict[str, dict[str, Any]] = {}
        
        if data.item_type is not None and data.item_type != current.item_type:
            updates["item_type"] = data.item_type.value
            changes["item_type"] = {"old": current.item_type.value, "new": data.item_type.value}
        
        if data.status is not None and data.status != current.status:
            updates["status"] = data.status.value
            changes["status"] = {"old": current.status.value, "new": data.status.value}
        
        if data.parent_id is not None:
            old_parent = str(current.parent_id) if current.parent_id else None
            new_parent = str(data.parent_id) if data.parent_id else None
            if old_parent != new_parent:
                updates["parent_id"] = new_parent
                changes["parent_id"] = {"old": old_parent, "new": new_parent}
        
        if data.content is not None:
            # MERGE content instead of replacing to prevent silent data loss
            # (AXIOM PH-1: Partial updates should preserve unmentioned fields)
            merged_content = {**current.content, **data.content}
            if merged_content != current.content:
                updates["content"] = merged_content
                changes["content"] = {"old": current.content, "new": merged_content}
        
        if data.metadata is not None:
            # Also merge metadata for consistency
            merged_metadata = {**current.metadata, **data.metadata}
            if merged_metadata != current.metadata:
                updates["metadata"] = merged_metadata
                changes["metadata"] = {"old": current.metadata, "new": merged_metadata}
        
        if not updates:
            return current  # Nothing to update
        
        updates["updated_at"] = utc_now().isoformat()
        
        # Perform update
        result = self.client.table("items")\
            .update(updates)\
            .eq("id", str(item_id))\
            .execute()
        
        if not result.data:
            return None
        
        item = Item(**result.data[0])
        
        # Log the update event
        await self._log_event(
            item_id=item_id,
            action="updated",
            actor=actor,
            changes=changes,
            reasoning=reasoning,
            confidence=confidence,
        )
        
        # Trigger webhooks (fire and forget)
        try:
            from jomni.api.webhooks import trigger_webhooks
            import asyncio
            # Use item.completed if status changed to completed
            event = "item.completed" if changes.get("status", {}).get("new") == "completed" else "item.updated"
            asyncio.create_task(trigger_webhooks(event, {
                "item_id": str(item.id),
                "item_type": item.item_type.value,
                "status": item.status.value,
                "changes": list(changes.keys()),
            }, self))
        except Exception as e:
            logger.warning(f"Webhook trigger failed for {event}: {e}")
        
        return item
    
    async def archive_item(
        self,
        item_id: UUID,
        actor: Actor = (ActorType.SYSTEM, "server"),
        reasoning: str | None = None,
    ) -> Item | None:
        """
        Move an item to archived status (NOT a deletion).
        
        CONTEXT:
        Archiving is for "filing away" items you're done with but want to keep.
        Item remains fully queryable with status=ARCHIVED filter.
        For actual removal from database, use delete_item(hard_delete=True).
        
        EXAMPLE:
        After completing a project, archive it to keep history but remove
        from active dashboards and NOW module.
        
        TECHNICAL:
        Sets status to ItemStatus.ARCHIVED via update_item().
        Item still appears in list_items() if status filter includes ARCHIVED.
        
        Returns:
            Updated Item with status=ARCHIVED, or None if not found.
            
        COMPLEXITY: Low
        Convenience wrapper around update_item().
        """
        return await self.update_item(
            item_id,
            ItemUpdate(status=ItemStatus.ARCHIVED),
            actor=actor,
            reasoning=reasoning,
        )
    
    async def complete_item(
        self,
        item_id: UUID,
        actor: Actor = (ActorType.SYSTEM, "server"),
        reasoning: str | None = None,
    ) -> Item | None:
        """Mark an item as completed."""
        return await self.update_item(
            item_id,
            ItemUpdate(status=ItemStatus.COMPLETED),
            actor=actor,
            reasoning=reasoning,
        )
    
    async def delete_item(
        self,
        item_id: UUID,
        actor: Actor = (ActorType.SYSTEM, "server"),
        reasoning: str | None = None,
        hard_delete: bool = False,
    ) -> bool:
        """
        Soft delete an item by setting deleted_at timestamp.

        Args:
            item_id: The item to delete
            actor: Who is deleting (explicit, no race condition)
            reasoning: Why it was deleted
            hard_delete: If True, permanently remove (default: soft delete)

        Returns True if deleted, False if not found.
        """
        item = await self.get_item(item_id)
        if not item:
            return False

        now = utc_now().isoformat()

        if hard_delete:
            # Log deletion event BEFORE deleting (so we have the item data)
            await self._log_event(
                item_id=item_id,
                action="hard_deleted",
                actor=actor,
                changes={"deleted_item": {
                    "item_type": item.item_type.value,
                    "status": item.status.value,
                    "content": item.content,
                }},
                reasoning=reasoning,
            )

            # Delete related embeddings first (foreign key constraint)
            self.client.table("embeddings").delete().eq("item_id", str(item_id)).execute()
            self.client.table("item_tags").delete().eq("item_id", str(item_id)).execute()

            # Delete the item
            self.client.table("items").delete().eq("id", str(item_id)).execute()
        else:
            # Soft delete: set deleted_at timestamp
            self.client.table("items")\
                .update({"deleted_at": now, "updated_at": now})\
                .eq("id", str(item_id))\
                .execute()

            await self._log_event(
                item_id=item_id,
                action="deleted",
                actor=actor,
                changes={"deleted_at": now},
                reasoning=reasoning,
            )

        # Trigger webhooks (fire and forget)
        try:
            from jomni.api.webhooks import trigger_webhooks
            import asyncio
            asyncio.create_task(trigger_webhooks("item.deleted", {
                "item_id": str(item_id),
                "hard_delete": hard_delete,
            }, self))
        except Exception as e:
            logger.warning(f"Webhook trigger failed for item.deleted: {e}")

        return True
    
    async def delete_items(
        self,
        item_ids: list[UUID],
        reasoning: str | None = None,
    ) -> int:
        """
        Permanently delete multiple items in parallel.
        
        Uses asyncio.gather for concurrent execution.
        Individual failures don't fail the entire batch.
        
        Returns count of successfully deleted items.
        """
        if not item_ids:
            return 0
        
        # Execute deletes in parallel
        tasks = [
            self.delete_item(item_id, reasoning=reasoning)
            for item_id in item_ids
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Count successes (True results, not exceptions)
        deleted = sum(
            1 for r in results 
            if r is True  # Explicit check - False or Exception doesn't count
        )
        return deleted
    
    async def bulk_update_items(
        self,
        set_status: ItemStatus,
        filter_type: ItemType | None = None,
        filter_status: ItemStatus | None = None,
        limit: int = 1000,
        actor: Actor = (ActorType.SYSTEM, "server"),
        reasoning: str | None = None,
    ) -> int:
        """
        Bulk update items matching filters.
        
        Returns count of items updated.
        Each item update is logged individually for audit trail.
        """
        # Get matching items
        items = await self.list_items(
            item_type=filter_type,
            status=filter_status,
            limit=limit,
        )
        
        if not items:
            return 0
        
        # Update each item
        updated = 0
        for item in items:
            try:
                await self.update_item(
                    item.id,
                    ItemUpdate(status=set_status),
                    actor=actor,
                    reasoning=reasoning or f"Bulk update to {set_status.value}",
                )
                updated += 1
            except Exception as e:
                logger.warning(f"Failed to update item {item.id} in bulk: {e}")
        
        return updated
    
    async def list_items(
        self,
        item_type: ItemType | None = None,
        status: ItemStatus | None = None,
        parent_id: UUID | None = None,
        limit: int = 50,
        offset: int = 0,
        include_deleted: bool = False,
    ) -> list[Item]:
        """
        List items with optional filters.
        
        By default, excludes soft-deleted items (deleted_at IS NOT NULL).
        Set include_deleted=True to include them.
        """
        query = self.client.table("items").select("*")
        
        # Exclude soft-deleted items by default
        if not include_deleted:
            query = query.is_("deleted_at", "null")
        
        if item_type:
            query = query.eq("item_type", item_type.value)
        if status:
            query = query.eq("status", status.value)
        if parent_id:
            query = query.eq("parent_id", str(parent_id))
        
        query = query.order("created_at", desc=True).range(offset, offset + limit - 1)
        result = query.execute()
        
        return [Item(**row) for row in result.data]
    
    async def get_inbox(self, limit: int = 50) -> list[Item]:
        """Get all items in inbox status."""
        return await self.list_items(status=ItemStatus.INBOX, limit=limit)
    
    # =========================================================================
    # TAGS
    # Uses normalized tags table with item_tags junction.
    # See get_or_create_tag() and add_tags_to_item() in NORMALIZED TAGS section.
    # =========================================================================
    
    async def remove_tag_from_item_legacy(
        self,
        item_id: UUID,
        tag: str,
    ) -> None:
        """
        DEPRECATED: Remove a specific tag from an item using legacy tag column.
        Use remove_tag_from_item() with normalized tags instead.
        
        No-op if the tag doesn't exist on the item.
        """
        self.client.table("item_tags")\
            .delete()\
            .eq("item_id", str(item_id))\
            .eq("tag", tag)\
            .execute()
    
    # =========================================================================
    # EVENTS
    # =========================================================================
    
    async def _log_event(
        self,
        item_id: UUID,
        action: str,
        actor: Actor,
        changes: dict[str, Any],
        reasoning: str | None = None,
        confidence: float | None = None,
    ) -> Event:
        """
        Log an event (internal method).
        Called automatically by mutation methods.
        Actor is passed explicitly to avoid race conditions.
        """
        actor_type, actor_id = actor
        
        record = {
            "item_id": str(item_id),
            "action": action,
            "changes": changes,
            "actor_type": actor_type.value,
            "actor_id": actor_id,
            "session_id": str(self._current_session_id) if self._current_session_id else None,
            "reasoning": reasoning,
            "confidence": confidence,
            "occurred_at": utc_now().isoformat(),
        }
        
        result = self.client.table("events").insert(record).execute()
        return Event(**result.data[0])
    
    async def get_item_history(self, item_id: UUID, limit: int = 50) -> list[Event]:
        """Get the event history for an item."""
        result = self.client.table("events")\
            .select("*")\
            .eq("item_id", str(item_id))\
            .order("occurred_at", desc=True)\
            .limit(limit)\
            .execute()
        
        return [Event(**row) for row in result.data]

    async def get_events(
        self,
        item_id: UUID | None = None,
        action_type: str | None = None,
        limit: int = 50,
    ) -> list[Event]:
        """
        Get audit events, optionally filtered.
        
        Args:
            item_id: Filter to events for this specific item
            action_type: Filter by action (created, updated, deleted, completed)
            limit: Maximum events to return
            
        Returns:
            List of Event objects ordered by occurred_at descending.
        """
        query = self.client.table("events")\
            .select("*")\
            .order("occurred_at", desc=True)\
            .limit(limit)
        
        if item_id:
            query = query.eq("item_id", str(item_id))
        if action_type:
            query = query.eq("action", action_type)
        
        result = query.execute()
        return [Event(**row) for row in result.data]

    async def get_deleted_items(self, limit: int = 50) -> list[Item]:
        """
        Get soft-deleted items (deleted_at IS NOT NULL).
        
        Args:
            limit: Maximum items to return
            
        Returns:
            List of Item objects ordered by deleted_at descending.
        """
        result = self.client.table("items")\
            .select("*")\
            .not_.is_("deleted_at", "null")\
            .order("deleted_at", desc=True)\
            .limit(limit)\
            .execute()
        
        return [self._row_to_item(row) for row in result.data]

    async def list_memories(
        self,
        memory_type: str | None = None,
        limit: int = 50,
    ) -> list[Item]:
        """
        List items marked as memories (metadata.memory = True).
        
        Args:
            memory_type: Filter by "explicit", "implicit", or "all"
            limit: Maximum memories to return
            
        Returns:
            List of Item objects representing stored memories.
        """
        result = self.client.table("items")\
            .select("*")\
            .contains("metadata", {"memory": True})\
            .is_("deleted_at", "null")\
            .limit(limit)\
            .execute()
        
        items = [self._row_to_item(row) for row in result.data]
        
        # Filter by memory_type if specified (done in Python since JSONB nested queries are limited)
        if memory_type and memory_type != "all":
            items = [
                item for item in items
                if item.content and item.content.get("memory_type") == memory_type
            ]
        
        return items

    async def get_job_history(self, limit: int = 20) -> list[dict[str, Any]]:
        """
        Get scheduler job run history.
        
        Args:
            limit: Maximum history entries to return
            
        Returns:
            List of dicts with job_name, status, started_at, duration, error.
        """
        result = self.client.table("job_history")\
            .select("*")\
            .order("started_at", desc=True)\
            .limit(limit)\
            .execute()
        
        return result.data
    
    # =========================================================================
    # EMBEDDINGS
    # =========================================================================
    
    async def store_embedding(self, data: EmbeddingCreate) -> Embedding:
        """Store an embedding for an item."""
        record = {
            "id": str(uuid4()),
            "item_id": str(data.item_id),
            "model_name": data.model_name,
            "model_version": data.model_version,
            "dimensions": data.dimensions,
            "embedding": data.embedding,  # pgvector handles the list
            "source_hash": data.source_hash,
            "created_at": utc_now().isoformat(),
        }
        
        # Upsert to handle re-embedding
        result = self.client.table("embeddings")\
            .upsert(record, on_conflict="item_id,model_name,model_version")\
            .execute()
        
        return Embedding(**result.data[0])
    
    async def semantic_search(
        self,
        embedding: list[float],
        limit: int = 10,
        item_types: list[ItemType] | None = None,
        statuses: list[ItemStatus] | None = None,
    ) -> list[tuple[Item, float]]:
        """
        Search for similar items using vector similarity.
        
        Returns list of (Item, similarity_score) tuples.
        """
        # Use Supabase's pgvector similarity search via RPC
        params: dict[str, Any] = {
            "query_embedding": embedding,
            "match_count": limit,
        }
        
        if item_types:
            params["filter_types"] = [t.value for t in item_types]
        if statuses:
            params["filter_statuses"] = [s.value for s in statuses]
        
        # This requires a stored function in Postgres—see schema
        result = self.client.rpc("match_items", params).execute()
        
        items_with_scores = []
        for row in result.data:
            item = Item(**{k: v for k, v in row.items() if k != "similarity"})
            items_with_scores.append((item, row["similarity"]))
        
        return items_with_scores
    
    # =========================================================================
    # RELATIONS
    # =========================================================================
    
    async def create_relation(self, data: RelationCreate) -> Relation:
        """Create a relation between two items."""
        record = {
            "id": str(uuid4()),
            "source_id": str(data.source_id),
            "target_id": str(data.target_id),
            "relation_type": data.relation_type.value,
            "metadata": data.metadata,
            "created_at": utc_now().isoformat(),
        }
        
        result = self.client.table("relations").insert(record).execute()
        return Relation(**result.data[0])
    
    async def get_related_items(
        self,
        item_id: UUID,
        relation_type: str | None = None,
    ) -> list[Item]:
        """Get all items related to the given item."""
        query = self.client.table("relations").select("*").eq("source_id", str(item_id))
        
        if relation_type:
            query = query.eq("relation_type", relation_type)
            
        relations = query.execute()
        
        if not relations.data:
            return []
            
        target_ids = [r["target_id"] for r in relations.data]
        
        items = self.client.table("items")\
            .select("*")\
            .in_("id", target_ids)\
            .execute()
            
        return [Item(**item) for item in items.data]

    async def get_relations_for_items(
        self,
        item_ids: list[UUID],
    ) -> dict[UUID, list[Relation]]:
        """
        Get all relations for a list of items.
        Returns a dictionary mapping item_id to list of Relations.
        """
        if not item_ids:
            return {}
        
        ids = [str(i) for i in item_ids]
        # Supabase allows .in_() filter
        result = self.client.table("relations")\
            .select("*")\
            .in_("source_id", ids)\
            .execute()
            
        relations_by_item = {uid: [] for uid in item_ids}
        for record in result.data:
            relation = Relation(**record)
            source_uuid = relation.source_id
            if source_uuid in relations_by_item:
                relations_by_item[source_uuid].append(relation)
            
        return relations_by_item

    # =========================================================================
    # ANALYTICS & DIGEST
    # =========================================================================

    async def get_digest_stats(self) -> dict[str, Any]:
        """
        Get statistics for the daily digest.
        Returns counts by status, goal progress, etc.
        """
        now = utc_now()
        today_start = now.replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
        yesterday_start = (now - timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
        
        # 1. Counts by status
        # Note: Supabase-py client returns 'count' property when count='exact' is used
        inbox_res = self.client.table("items").select("id", count="exact").eq("status", "inbox").execute()
        active_res = self.client.table("items").select("id", count="exact").eq("status", "active").execute()
        
        # 2. Completed today/yesterday
        completed_today_res = self.client.table("items").select("id", count="exact")\
            .eq("status", "completed")\
            .gte("updated_at", today_start)\
            .execute()
            
        completed_yesterday_res = self.client.table("items").select("id", count="exact")\
            .eq("status", "completed")\
            .gte("updated_at", yesterday_start)\
            .lt("updated_at", today_start)\
            .execute()
            
        # 3. Goals
        goals_result = self.client.table("items")\
            .select("*")\
            .eq("item_type", "goal")\
            .eq("status", "active")\
            .execute()
        goals = [Item(**r) for r in goals_result.data]
        
        # 4. Stale items (active but not updated in 14 days)
        stale_threshold = (now - timedelta(days=14)).isoformat()
        stale_items_result = self.client.table("items")\
            .select("*")\
            .eq("status", "active")\
            .lt("updated_at", stale_threshold)\
            .limit(10)\
            .execute()
        stale_items = [Item(**r) for r in stale_items_result.data]
        
        return {
            "summary": {
                "inbox": inbox_res.count,
                "active": active_res.count,
                "completed_today": completed_today_res.count,
                "completed_yesterday": completed_yesterday_res.count,
            },
            "goals": goals,
            "stale_items": stale_items,
        }

    # =========================================================================
    # SERVICES & AUTH
    # =========================================================================

    async def get_service(self, name: str) -> Service | None:
        """Get service status by name."""
        result = self.client.table("services").select("*").eq("name", name).execute()
        if not result.data:
            return None
        return Service(**result.data[0])

    async def store_credentials(self, creds: ServiceCredential) -> None:
        """
        Store encrypted service credentials.
        
        Uses delete-then-insert pattern since unique constraint may not exist.
        This is safe for single-user scenario.
        """
        # Delete existing service entry if exists, then insert
        self.client.table("services").delete().eq("name", creds.service_name).execute()
        self.client.table("services").insert({
            "name": creds.service_name,
            "display_name": creds.service_name.title(),
            "status": "connected",
            "is_connected": True,
            "metadata": {}
        }).execute()
        
        # Delete existing credentials if any, then insert fresh
        self.client.table("service_credentials").delete().eq(
            "service_name", creds.service_name
        ).execute()
        
        data = creds.model_dump()
        data["expires_at"] = data["expires_at"].isoformat() if data["expires_at"] else None
        data["updated_at"] = data["updated_at"].isoformat()
        
        self.client.table("service_credentials").insert(data).execute()

    async def get_credentials(self, service_name: str) -> ServiceCredential | None:
        """Get encrypted service credentials."""
        result = self.client.table("service_credentials").select("*").eq("service_name", service_name).execute()
        if not result.data:
            return None
        return ServiceCredential(**result.data[0])
    
    # =========================================================================
    # AI CORRECTIONS (for learning)
    # =========================================================================

    async def store_correction(
        self,
        item_id: UUID | None,
        input_text: str,
        ai_suggestion: dict[str, Any],
        user_correction: dict[str, Any],
        correction_type: str,
        input_embedding: list[float] | None = None,
        model_name: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> UUID:
        """
        Store a user correction for AI learning in the corrections table.

        Args:
            item_id: Related item (if any)
            input_text: The original input that was classified
            ai_suggestion: What AI suggested (JSONB)
            user_correction: What user corrected it to (JSONB)
            correction_type: Type of correction (classification, tags, etc.)
            input_embedding: Vector embedding of input for similarity search
            model_name: Which AI model made the suggestion
            context: Additional context at time of correction

        Returns:
            The correction ID
        """
        correction_id = uuid4()
        record = {
            "id": str(correction_id),
            "item_id": str(item_id) if item_id else None,
            "input_text": input_text,
            "input_embedding": input_embedding,  # vector(1536)
            "ai_suggestion": ai_suggestion,
            "user_correction": user_correction,
            "correction_type": correction_type,
            "model_name": model_name,
            "context": context or {},
            "created_at": utc_now().isoformat(),
        }

        self.client.table("ai_corrections").insert(record).execute()
        return correction_id

    async def get_similar_corrections(
        self,
        embedding: list[float],
        correction_type: str,
        limit: int = 5,
    ) -> list[dict[str, Any]]:
        """
        Get similar past corrections for few-shot learning.

        Used to personalize AI suggestions based on past user preferences.
        """
        result = self.client.rpc("match_corrections", {
            "query_embedding": embedding,
            "filter_type": correction_type,
            "match_count": limit,
        }).execute()

        return result.data

    # =========================================================================
    # TAGS (normalized tag system)
    # =========================================================================

    async def get_or_create_tag(self, name: str, color: str | None = None) -> UUID:
        """Get existing tag by name or create new one.
        
        Uses upsert to handle race conditions where multiple requests
        try to create the same tag simultaneously.
        """
        # Normalize tag name
        normalized = name.lower().strip()
        tag_id = uuid4()

        # Upsert: insert or do nothing on conflict (name is UNIQUE)
        # This is atomic and race-condition-safe
        try:
            self.client.table("tags").upsert(
                {
                    "id": str(tag_id),
                    "name": normalized,
                    "color": color,
                    "created_at": utc_now().isoformat(),
                    "updated_at": utc_now().isoformat(),
                },
                on_conflict="name",  # Uses the UNIQUE constraint on name
            ).execute()
        except Exception as e:
            # Log but continue - if upsert fails, try to fetch existing
            logger.debug(f"Tag upsert failed, fetching existing: {e}")

        # Always fetch to get the actual ID (could be existing or new)
        result = self.client.table("tags")\
            .select("id")\
            .eq("name", normalized)\
            .execute()

        if result.data:
            return UUID(result.data[0]["id"])

        # Fallback to the ID we generated (shouldn't reach here normally)
        return tag_id

    async def add_tags_to_item(
        self,
        item_id: UUID,
        tag_names: list[str],
    ) -> list[UUID]:
        """
        Add tags to an item using the normalized tags system.

        Creates tags if they don't exist, then links via item_tags junction.
        Returns list of tag IDs.
        """
        tag_ids = []
        for name in tag_names:
            tag_id = await self.get_or_create_tag(name)
            tag_ids.append(tag_id)

            # Insert into junction table (ignore if already exists)
            try:
                self.client.table("item_tags").insert({
                    "item_id": str(item_id),
                    "tag_id": str(tag_id),
                    "created_at": utc_now().isoformat(),
                }).execute()
            except Exception as dup_err:
                # Expected: tag already linked to item (idempotent operation)
                logger.debug(f"Tag link for {item_id}: {dup_err}")

        return tag_ids

    async def get_item_tags(self, item_id: UUID) -> list[dict[str, Any]]:
        """Get all tags for an item."""
        result = self.client.table("item_tags")\
            .select("tag_id, tags(id, name, color)")\
            .eq("item_id", str(item_id))\
            .execute()

        return [row["tags"] for row in result.data if row.get("tags")]

    async def remove_tag_from_item(self, item_id: UUID, tag_name: str) -> bool:
        """Remove a tag from an item."""
        # Find tag ID
        result = self.client.table("tags")\
            .select("id")\
            .eq("name", tag_name.lower().strip())\
            .execute()

        if not result.data:
            return False

        tag_id = result.data[0]["id"]

        # Remove from junction
        self.client.table("item_tags")\
            .delete()\
            .eq("item_id", str(item_id))\
            .eq("tag_id", tag_id)\
            .execute()

        return True

    async def search_by_tag(
        self,
        tag_name: str,
        limit: int = 50,
    ) -> list[Item]:
        """Find all items with a specific tag."""
        result = self.client.table("tags")\
            .select("id")\
            .eq("name", tag_name.lower().strip())\
            .execute()

        if not result.data:
            return []

        tag_id = result.data[0]["id"]

        # Get item IDs with this tag
        item_tags = self.client.table("item_tags")\
            .select("item_id")\
            .eq("tag_id", tag_id)\
            .limit(limit)\
            .execute()

        if not item_tags.data:
            return []

        item_ids = [row["item_id"] for row in item_tags.data]

        # Fetch items
        items_result = self.client.table("items")\
            .select("*")\
            .in_("id", item_ids)\
            .is_("deleted_at", "null")\
            .execute()

        return [Item(**row) for row in items_result.data]

    # =========================================================================
    # GOALS
    # =========================================================================

    async def create_goal(
        self,
        title: str,
        description: str | None = None,
        horizon: str = "medium",
        target_date: datetime | None = None,
        success_criteria: list[str] | None = None,
        tags: list[str] | None = None,
        reasoning: str | None = None,
    ) -> Item:
        """
        Create a goal item with structured content.

        Args:
            title: Goal title
            description: Detailed description
            horizon: Time horizon (short/medium/long)
            target_date: When to achieve by
            success_criteria: Measurable criteria for completion
            tags: Tags to apply
            reasoning: Why creating this goal

        Returns:
            The created goal Item
        """
        goal = await self.create_item(
            ItemCreate(
                item_type=ItemType.GOAL,
                status=ItemStatus.ACTIVE,
                content={
                    "text": title,
                    "title": title,
                    "description": description,
                    "success_criteria": success_criteria or [],
                    "target_date": target_date.isoformat() if target_date else None,
                    "progress": 0,
                    "assessments": [],
                },
                metadata={"horizon": horizon},
            ),
            reasoning=reasoning,
        )

        # Update horizon column directly
        self.client.table("items")\
            .update({"horizon": horizon})\
            .eq("id", str(goal.id))\
            .execute()

        # Add tags if provided
        if tags:
            await self.add_tags_to_item(goal.id, tags)

        return goal

    async def list_goals(
        self,
        status: ItemStatus | None = ItemStatus.ACTIVE,
        horizon: str | None = None,
        limit: int = 50,
    ) -> list[Item]:
        """List goals with optional filters."""
        query = self.client.table("items")\
            .select("*")\
            .eq("item_type", ItemType.GOAL.value)\
            .is_("deleted_at", "null")

        if status:
            query = query.eq("status", status.value)
        if horizon:
            query = query.eq("horizon", horizon)

        query = query.order("created_at", desc=True).limit(limit)
        result = query.execute()

        return [Item(**row) for row in result.data]

    async def link_item_to_goal(
        self,
        item_id: UUID,
        goal_id: UUID,
        reasoning: str | None = None,
    ) -> Relation:
        """Link an item to a goal as supporting it."""
        return await self.create_relation(
            RelationCreate(
                source_id=item_id,
                target_id=goal_id,
                relation_type=RelationType.SUPPORTS,
                metadata={"reasoning": reasoning} if reasoning else {},
            )
        )

    async def get_goal_items(self, goal_id: UUID) -> list[Item]:
        """Get all items linked to a goal."""
        result = self.client.table("relations")\
            .select("source_id")\
            .eq("target_id", str(goal_id))\
            .eq("relation_type", RelationType.SUPPORTS.value)\
            .execute()

        if not result.data:
            return []

        item_ids = [row["source_id"] for row in result.data]
        items_result = self.client.table("items")\
            .select("*")\
            .in_("id", item_ids)\
            .is_("deleted_at", "null")\
            .execute()

        return [Item(**row) for row in items_result.data]

    async def assess_goal(
        self,
        goal_id: UUID,
        progress: int,
        notes: str | None = None,
        blockers: list[str] | None = None,
    ) -> Item | None:
        """
        Record a goal progress assessment.

        Args:
            goal_id: The goal to assess
            progress: Progress percentage (0-100)
            notes: Assessment notes
            blockers: Current blockers

        Returns:
            Updated goal item
        """
        goal = await self.get_item(goal_id)
        if not goal or goal.item_type != ItemType.GOAL:
            return None

        # Add assessment to history
        assessments = goal.content.get("assessments", [])
        assessments.append({
            "date": utc_now().isoformat(),
            "progress": progress,
            "notes": notes,
            "blockers": blockers or [],
        })

        # Update content
        new_content = {**goal.content, "progress": progress, "assessments": assessments}

        return await self.update_item(
            goal_id,
            ItemUpdate(content=new_content),
            reasoning=f"Goal assessment: {progress}% - {notes}" if notes else f"Goal assessment: {progress}%",
        )

    async def update_goal(
        self,
        goal_id: UUID,
        title: str | None = None,
        description: str | None = None,
        horizon: str | None = None,
        target_date: datetime | None = None,
        success_criteria: list[str] | None = None,
        status: ItemStatus | None = None,
        reasoning: str | None = None,
    ) -> Item | None:
        """Update a goal's properties."""
        goal = await self.get_item(goal_id)
        if not goal or goal.item_type != ItemType.GOAL:
            return None

        # Build content updates
        new_content = {**goal.content}
        if title is not None:
            new_content["text"] = title
            new_content["title"] = title
        if description is not None:
            new_content["description"] = description
        if success_criteria is not None:
            new_content["success_criteria"] = success_criteria
        if target_date is not None:
            new_content["target_date"] = target_date.isoformat()

        # Update item
        updates = ItemUpdate(content=new_content)
        if status is not None:
            updates.status = status

        result = await self.update_item(goal_id, updates, reasoning=reasoning)

        # Update horizon column if changed
        if horizon is not None:
            self.client.table("items")\
                .update({"horizon": horizon})\
                .eq("id", str(goal_id))\
                .execute()

        return result

    async def restore_item(
        self,
        item_id: UUID,
        actor: Actor = (ActorType.SYSTEM, "server"),
        reasoning: str | None = None,
    ) -> Item | None:
        """Restore a soft-deleted item."""
        result = self.client.table("items")\
            .update({"deleted_at": None, "updated_at": utc_now().isoformat()})\
            .eq("id", str(item_id))\
            .execute()

        if not result.data:
            return None

        await self._log_event(
            item_id=item_id,
            action="restored",
            actor=actor,
            changes={"deleted_at": None},
            reasoning=reasoning,
        )

        return Item(**result.data[0])

