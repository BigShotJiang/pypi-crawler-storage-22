"""
Jomni Error Hierarchy.

Provides structured, consistent error types across the application.
All errors inherit from JomniError and can be caught by the global
exception handler in main.py.

Usage:
    from jomni.errors import ItemNotFoundError, AIError
    
    if not item:
        raise ItemNotFoundError(item_id=str(id))
    
    try:
        result = await ai.classify(text)
    except anthropic.RateLimitError:
        raise AIRateLimitError("Claude rate limited")
"""

from typing import Optional


class JomniError(Exception):
    """
    Base exception for all Jomni errors.
    
    Provides consistent error format with:
    - code: Machine-readable error code
    - message: Human-readable description
    - http_status: HTTP status code for API responses
    """
    
    code: str = "UNKNOWN_ERROR"
    http_status: int = 500
    
    def __init__(self, message: str = "An unknown error occurred", **kwargs):
        self.message = message
        self.details = kwargs
        super().__init__(message)
    
    def to_dict(self) -> dict:
        """Convert to API response format."""
        response = {
            "code": self.code,
            "message": self.message,
        }
        if self.details:
            response["details"] = self.details
        return response


# =============================================================================
# VALIDATION ERRORS (400)
# =============================================================================

class ValidationError(JomniError):
    """Invalid input data."""
    code = "VALIDATION_ERROR"
    http_status = 400


class InvalidUUIDError(ValidationError):
    """Invalid UUID format."""
    code = "INVALID_UUID"
    
    def __init__(self, value: str):
        super().__init__(f"Invalid UUID format: {value}", value=value)


class InvalidItemTypeError(ValidationError):
    """Invalid item type."""
    code = "INVALID_ITEM_TYPE"
    
    def __init__(self, value: str, valid_types: list[str]):
        super().__init__(
            f"Invalid item type: {value}. Valid types: {valid_types}",
            value=value,
            valid_types=valid_types
        )


class InvalidStatusError(ValidationError):
    """Invalid item status."""
    code = "INVALID_STATUS"


# =============================================================================
# AUTHENTICATION ERRORS (401)
# =============================================================================

class AuthenticationError(JomniError):
    """Authentication failed."""
    code = "AUTH_ERROR"
    http_status = 401


class MissingAPIKeyError(AuthenticationError):
    """API key not provided."""
    code = "MISSING_API_KEY"
    
    def __init__(self):
        super().__init__("API key required. Include X-API-Key header.")


class InvalidAPIKeyError(AuthenticationError):
    """API key invalid."""
    code = "INVALID_API_KEY"
    http_status = 403
    
    def __init__(self):
        super().__init__("Invalid API key")


class ExpiredTokenError(AuthenticationError):
    """OAuth token expired."""
    code = "TOKEN_EXPIRED"
    
    def __init__(self, service: str = "unknown"):
        super().__init__(f"Token expired for {service}", service=service)


# =============================================================================
# RESOURCE ERRORS (404, 409)
# =============================================================================

class NotFoundError(JomniError):
    """Resource not found."""
    code = "NOT_FOUND"
    http_status = 404


class ItemNotFoundError(NotFoundError):
    """Item not found."""
    code = "ITEM_NOT_FOUND"
    
    def __init__(self, item_id: str):
        super().__init__(f"Item not found: {item_id}", item_id=item_id)


class ServiceNotFoundError(NotFoundError):
    """External service configuration not found."""
    code = "SERVICE_NOT_FOUND"
    
    def __init__(self, service: str):
        super().__init__(f"Service not configured: {service}", service=service)


class ConflictError(JomniError):
    """Resource conflict."""
    code = "CONFLICT"
    http_status = 409


class DuplicateItemError(ConflictError):
    """Duplicate item detected."""
    code = "DUPLICATE_ITEM"


# =============================================================================
# RATE LIMITING (429)
# =============================================================================

class RateLimitError(JomniError):
    """Rate limit exceeded."""
    code = "RATE_LIMITED"
    http_status = 429
    
    def __init__(self, retry_after: Optional[int] = None):
        message = "Rate limit exceeded"
        if retry_after:
            message += f". Retry after {retry_after} seconds"
        super().__init__(message, retry_after=retry_after)


# =============================================================================
# AI ERRORS (500)
# =============================================================================

class AIError(JomniError):
    """AI operation failed."""
    code = "AI_ERROR"
    http_status = 500


class AIProviderError(AIError):
    """AI provider (Anthropic/OpenAI) returned error."""
    code = "AI_PROVIDER_ERROR"
    
    def __init__(self, provider: str, message: str):
        super().__init__(f"{provider} error: {message}", provider=provider)


class AITimeoutError(AIError):
    """AI request timed out."""
    code = "AI_TIMEOUT"
    
    def __init__(self, operation: str = "request"):
        super().__init__(f"AI {operation} timed out", operation=operation)


class AIRateLimitError(AIError):
    """AI provider rate limited."""
    code = "AI_RATE_LIMITED"
    http_status = 429
    
    def __init__(self, provider: str = "AI"):
        super().__init__(f"{provider} rate limit exceeded", provider=provider)


class AIContentFilterError(AIError):
    """AI content was filtered."""
    code = "AI_CONTENT_FILTERED"
    
    def __init__(self):
        super().__init__("Request was filtered by AI safety systems")


# =============================================================================
# DATABASE ERRORS (500)
# =============================================================================

class DatabaseError(JomniError):
    """Database operation failed."""
    code = "DATABASE_ERROR"
    http_status = 500


class ConnectionError(DatabaseError):
    """Database connection failed."""
    code = "DB_CONNECTION_ERROR"


class QueryError(DatabaseError):
    """Database query failed."""
    code = "DB_QUERY_ERROR"


class TransactionError(DatabaseError):
    """Database transaction failed."""
    code = "DB_TRANSACTION_ERROR"


# =============================================================================
# CONFIGURATION ERRORS (500)
# =============================================================================

class ConfigurationError(JomniError):
    """Server misconfiguration."""
    code = "CONFIG_ERROR"
    http_status = 500


class MissingConfigError(ConfigurationError):
    """Required configuration missing."""
    code = "MISSING_CONFIG"
    
    def __init__(self, setting: str):
        super().__init__(f"Missing required configuration: {setting}", setting=setting)


# =============================================================================
# EXTERNAL SERVICE ERRORS (502, 503)
# =============================================================================

class ExternalServiceError(JomniError):
    """External service error."""
    code = "EXTERNAL_SERVICE_ERROR"
    http_status = 502


class SupabaseError(ExternalServiceError):
    """Supabase error."""
    code = "SUPABASE_ERROR"


class GoogleAPIError(ExternalServiceError):
    """Google API error."""
    code = "GOOGLE_API_ERROR"


class ServiceUnavailableError(JomniError):
    """Service temporarily unavailable."""
    code = "SERVICE_UNAVAILABLE"
    http_status = 503
