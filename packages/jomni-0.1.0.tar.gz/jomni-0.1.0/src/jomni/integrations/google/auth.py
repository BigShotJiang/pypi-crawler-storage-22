"""
Google OAuth and token management.

Handles token refresh and credential management.
"""

import logging
from datetime import datetime, timedelta, timezone

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials

from jomni.db import get_database
from jomni.db.protocol import DatabaseProtocol
from jomni.models import ServiceCredential
from jomni.security import decrypt_token, encrypt_token
from jomni.utils.datetime import utc_now, ensure_aware, make_naive_utc

logger = logging.getLogger(__name__)


class GoogleAuth:
    """Manages Google OAuth tokens and refresh."""
    
    def __init__(self, db: DatabaseProtocol):
        self.db = db
    
    async def get_valid_credentials(self, service_name: str = "google") -> Credentials | None:
        """
        Get valid Google credentials, refreshing if needed.
        
        Args:
            service_name: Name of the service (default: "google")
            
        Returns:
            Valid Credentials object or None if not connected
        """
        # Get stored credentials
        creds_data = await self.db.get_credentials(service_name)
        if not creds_data:
            logger.warning(f"No credentials found for {service_name}")
            return None
        
        # Decrypt tokens
        access_token = decrypt_token(creds_data.access_token)
        refresh_token = decrypt_token(creds_data.refresh_token) if creds_data.refresh_token else None
        
        # google-auth uses datetime.utcnow() internally (naive), so we must pass naive UTC
        expiry = make_naive_utc(creds_data.expires_at)
        
        # Create Credentials object
        from jomni.config import get_settings
        settings = get_settings()
        
        creds = Credentials(
            token=access_token,
            refresh_token=refresh_token,
            token_uri="https://oauth2.googleapis.com/token",
            client_id=settings.google_client_id,
            client_secret=settings.google_client_secret,
            expiry=expiry
        )
        
        # Check if refresh needed
        if creds.expired and creds.refresh_token:
            logger.info(f"Refreshing expired token for {service_name}")
            try:
                creds.refresh(Request())
                
                # Update database with new tokens
                new_creds = ServiceCredential(
                    service_name=service_name,
                    access_token=encrypt_token(creds.token),
                    refresh_token=encrypt_token(creds.refresh_token) if creds.refresh_token else None,
                    expires_at=creds.expiry,
                    updated_at=utc_now()
                )
                await self.db.store_credentials(new_creds)
                
                logger.info(f"Token refreshed successfully for {service_name}")
            except Exception as e:
                logger.error(f"Failed to refresh token for {service_name}: {e}")
                return None
        
        return creds
    
    async def is_connected(self, service_name: str = "google") -> bool:
        """Check if service is connected with valid credentials."""
        service = await self.db.get_service(service_name)
        return service is not None and service.is_connected
    
    async def revoke_credentials(self, service_name: str = "google") -> bool:
        """
        Revoke Google credentials and disconnect service.
        
        This revokes the token with Google AND updates the database to
        mark the service as disconnected. Both operations must succeed.
        """
        creds = await self.get_valid_credentials(service_name)
        if not creds:
            return False
        
        try:
            # Revoke token with Google
            import requests
            response = requests.post(
                'https://oauth2.googleapis.com/revoke',
                params={'token': creds.token},
                headers={'content-type': 'application/x-www-form-urlencoded'}
            )
            
            # Check if revocation succeeded (or token was already invalid)
            if response.status_code not in (200, 400):
                logger.warning(f"Google revocation returned {response.status_code}")
            
            # Update database: mark service as disconnected
            self.db.client.table("services").update({
                "is_connected": False,
                "status": "disconnected",
            }).eq("name", service_name).execute()
            
            # Remove stored credentials
            self.db.client.table("service_credentials").delete().eq(
                "service_name", service_name
            ).execute()
            
            logger.info(f"Revoked and removed credentials for {service_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to revoke credentials for {service_name}: {e}")
            return False


async def get_google_auth() -> GoogleAuth:
    """Dependency helper to get GoogleAuth instance."""
    db = get_database()
    return GoogleAuth(db)
