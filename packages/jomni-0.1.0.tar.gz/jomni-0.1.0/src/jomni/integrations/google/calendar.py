"""
Google Calendar sync to Jomni.

Syncs calendar events as EVENT type items with delta sync support.
"""

import logging
import traceback
from datetime import datetime, timedelta, timezone
from uuid import UUID

from jomni.db.protocol import DatabaseProtocol
from jomni.integrations.google.auth import GoogleAuth
from jomni.integrations.google.client import GoogleClient
from jomni.models import ItemCreate, ItemType, ItemStatus, ActorType
from jomni.utils.datetime import utc_now, ensure_aware

logger = logging.getLogger(__name__)


class CalendarSync:
    """
    Syncs Google Calendar events to Jomni as EVENT type items.
    
    CONTEXT:
    Users connect their Google Calendar to see events in Jomni's dashboard.
    Events are stored as regular Items with item_type=EVENT, enabling
    unified search and AI-powered scheduling suggestions.
    
    SYNC BEHAVIOR:
    - Uses indexed lookup by google_event_id for O(1) upsert detection
    - Creates items for new events, updates existing items for changed events
    - Cancelled Google events set item status to DELETED (soft delete)
    - Generates embeddings for semantic search of event content
    
    TECHNICAL:
    Events are stored with metadata including:
    - google_event_id: For deduplication
    - source: "google-calendar"
    - html_link: Direct link to Google Calendar
    
    Actor is set to (SYSTEM, "google-calendar-sync") for audit trail.
    
    COMPLEXITY: Medium
    Integrates with external API (Google). Failures are logged but don't
    crash the sync—individual event errors are skipped.
    """
    
    def __init__(self, db: DatabaseProtocol, auth: GoogleAuth):
        self.db = db
        self.auth = auth
        # Explicit actor for audit trail (not stateful set_actor)
        self._actor = (ActorType.SYSTEM, "google-calendar-sync")
    
    async def _get_event_by_google_id(self, google_event_id: str):
        """Get an item by its Google Calendar event ID using direct indexed lookup."""
        from jomni.models import Item
        
        try:
            result = self.db.client.table("items")\
                .select("*")\
                .eq("item_type", ItemType.EVENT.value)\
                .eq("metadata->>google_event_id", google_event_id)\
                .maybeSingle()\
                .execute()
            
            if result.data:
                return Item(**result.data)
            return None
        except Exception as e:
            logger.debug(f"Direct event lookup failed: {e}")
            return None
    
    async def sync(self, days_past: int = 30, days_future: int = 90) -> dict:
        """
        Sync calendar events to Jomni.
        
        Args:
            days_past: How many days in the past to sync
            days_future: How many days in the future to sync
            
        Returns:
            Summary of sync operation
        """
        try:
            # Get valid credentials
            creds = await self.auth.get_valid_credentials()
            if not creds:
                return {"error": "Not connected to Google"}
            
            client = GoogleClient(creds)
            
            # Calculate time range (timezone-aware)
            now = utc_now()
            time_min = (now - timedelta(days=days_past)).isoformat()
            time_max = (now + timedelta(days=days_future)).isoformat()
            
            # Fetch events
            events_result = client.calendar.events().list(
                calendarId='primary',
                timeMin=time_min,
                timeMax=time_max,
                singleEvents=True,
                orderBy='startTime'
            ).execute()
            
            events = events_result.get('items', [])
            
            # Process events
            created_count = 0
            updated_count = 0
            
            for event in events:
                result = await self._process_event(event)
                if result == "created":
                    created_count += 1
                elif result == "updated":
                    updated_count += 1
            
            return {
                "success": True,
                "events_found": len(events),
                "created": created_count,
                "updated": updated_count,
                "time_range": f"{days_past} days past to {days_future} days future"
            }
            
        except Exception as e:
            logger.error(f"Calendar sync failed: {e}")
            logger.error(f"Full traceback:\n{traceback.format_exc()}")
            print(f"CALENDAR SYNC ERROR: {e}")
            print(f"FULL TRACEBACK:\n{traceback.format_exc()}")
            return {"error": str(e), "traceback": traceback.format_exc()}
    
    async def _process_event(self, event: dict) -> str:
        """
        Process a single calendar event.
        
        Returns:
            "created", "updated", or "skipped"
        """
        event_id = event.get('id')
        if not event_id:
            return "skipped"
        
        # Check if event already exists using direct indexed lookup (O(1) not O(n))
        existing = await self._get_event_by_google_id(event_id)
        
        # Extract event data
        summary = event.get('summary', 'Untitled Event')
        description = event.get('description', '')
        location = event.get('location', '')
        status = event.get('status', 'confirmed')
        
        # Handle start/end times
        start = event.get('start', {})
        end = event.get('end', {})
        start_time = start.get('dateTime') or start.get('date')
        end_time = end.get('dateTime') or end.get('date')
        
        # Map status
        item_status = ItemStatus.DELETED if status == 'cancelled' else ItemStatus.ARCHIVED
        
        # Build content
        content = {
            "title": summary,
            "text": description,
            "location": location,
            "start_time": start_time,
            "end_time": end_time,
        }
        
        # Add attendees if present
        attendees = event.get('attendees', [])
        if attendees:
            content["attendees"] = [
                {"email": a.get('email'), "response": a.get('responseStatus')}
                for a in attendees
            ]
        
        # Build metadata
        metadata = {
            "google_event_id": event_id,
            "source": "google-calendar",
            "calendar_id": event.get('calendarId', 'primary'),
            "html_link": event.get('htmlLink', ''),
            "created": event.get('created'),
            "updated": event.get('updated'),
        }
        
        if existing:
            # Update existing item with explicit actor
            from jomni.models import ItemUpdate
            await self.db.update_item(
                existing.id,
                ItemUpdate(
                    status=item_status,
                    content=content,
                    metadata=metadata
                ),
                actor=self._actor,
                reasoning="Updated from Google Calendar sync"
            )
            
            # Generate embedding for updated item
            await self._generate_embedding(existing.id, content)
            
            return "updated"
        else:
            # Create new item with explicit actor
            item = await self.db.create_item(
                ItemCreate(
                    item_type=ItemType.EVENT,
                    status=item_status,
                    content=content,
                    metadata=metadata,
                    tags=["calendar", "google"]
                ),
                actor=self._actor,
                reasoning="Imported from Google Calendar"
            )
            
            # Generate embedding for new item
            await self._generate_embedding(item.id, content)
            
            return "created"
    
    async def _generate_embedding(self, item_id, content: dict) -> None:
        """Generate embedding for event content."""
        try:
            from jomni.utils.embeddings import store_item_embedding
            
            # Build text from content
            parts = []
            if title := content.get("title"):
                parts.append(title)
            if text := content.get("text"):
                parts.append(text)
            if location := content.get("location"):
                parts.append(f"Location: {location}")
            parts.append("Type: event")
            
            text = "\n".join(parts)
            if text.strip():
                await store_item_embedding(item_id, text, self.db)
        except Exception as e:
            # Don't fail sync if embedding fails
            logger.warning(f"Failed to generate embedding for event {item_id}: {e}")

