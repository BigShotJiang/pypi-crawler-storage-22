"""
Google API client wrapper.

Provides unified interface to all Google services.
"""

import logging
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build

logger = logging.getLogger(__name__)


class GoogleClient:
    """
    Unified client for all Google API services.
    
    CONTEXT:
    Jomni integrates with Gmail, Calendar, Drive, Tasks, and People APIs.
    This client lazy-loads each API on first use to avoid initialization cost.
    All API clients share the same OAuth2 credentials.
    
    TECHNICAL:
    - Uses google-api-python-client under the hood
    - Each property creates a cached Resource object
    - Credentials must be valid (not expired) before use
    
    PERFORMANCE:
    - First access to any API: ~100-500ms (discovery document fetch)
    - Subsequent access: instant (cached)
    
    COMPLEXITY: Medium
    Central integration point. Changes affect all Google sync features.
    """
    
    def __init__(self, credentials: Credentials):
        """
        Initialize Google API clients.
        
        Args:
            credentials: Valid Google OAuth2 credentials
        """
        self.credentials = credentials
        self._calendar = None
        self._gmail = None
        self._drive = None
        self._tasks = None
        self._people = None
    
    @property
    def calendar(self):
        """Lazy-load Calendar API client (v3)."""
        if not self._calendar:
            self._calendar = build(
                'calendar', 'v3',
                credentials=self.credentials,
                cache_discovery=False,  # Avoid file system cache issues
            )
        return self._calendar
    
    @property
    def gmail(self):
        """Lazy-load Gmail API client (v1)."""
        if not self._gmail:
            self._gmail = build(
                'gmail', 'v1',
                credentials=self.credentials,
                cache_discovery=False,
            )
        return self._gmail
    
    @property
    def drive(self):
        """Lazy-load Drive API client (v3)."""
        if not self._drive:
            self._drive = build(
                'drive', 'v3',
                credentials=self.credentials,
                cache_discovery=False,
            )
        return self._drive
    
    @property
    def tasks(self):
        """Lazy-load Tasks API client (v1)."""
        if not self._tasks:
            self._tasks = build(
                'tasks', 'v1',
                credentials=self.credentials,
                cache_discovery=False,
            )
        return self._tasks
    
    @property
    def people(self):
        """Lazy-load People API client (v1)."""
        if not self._people:
            self._people = build(
                'people', 'v1',
                credentials=self.credentials,
                cache_discovery=False,
            )
        return self._people
