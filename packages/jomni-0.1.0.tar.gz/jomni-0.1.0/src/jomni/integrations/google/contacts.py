"""
Google Contacts (People API) sync for Jomni.

WHY THIS EXISTS:
People are a core entity in life management. Knowing who someone is enables:
- Email triage: "Email from important contact"
- Delegation: "Waiting on response from X"
- Context: "Meeting with Y from Z company"

SYNC STRATEGY:
- Read-only: Fetch contacts → populate people table
- Uses People API connections.list endpoint
- Stores syncToken for incremental sync
- Generates name_embedding for semantic search ("find engineers")
"""

import logging
from typing import Any
from uuid import uuid4

from jomni.db.protocol import DatabaseProtocol
from jomni.integrations.google.auth import GoogleAuth
from jomni.integrations.google.client import GoogleClient
from jomni.utils.datetime import utc_now
from jomni.ai.provider import get_ai

logger = logging.getLogger(__name__)

# Fields to request from People API
PERSON_FIELDS = "names,emailAddresses,organizations,phoneNumbers,photos"


class ContactsSync:
    """Syncs Google Contacts to Jomni people table."""
    
    def __init__(self, db: DatabaseProtocol, auth: GoogleAuth):
        self.db = db
        self.auth = auth
    
    async def sync(self, full_sync: bool = False) -> dict:
        """
        Sync Google Contacts to Jomni.
        
        Args:
            full_sync: Force full sync instead of incremental
            
        Returns:
            Summary with contacts_found, created, updated counts
        """
        try:
            # Get valid credentials
            creds = await self.auth.get_valid_credentials()
            if not creds:
                return {"error": "Not connected to Google"}
            
            client = GoogleClient(creds)
            
            # Get stored sync token
            sync_token = None
            if not full_sync:
                sync_token = await self._get_stored_sync_token()
            
            # Fetch contacts
            if sync_token:
                return await self._incremental_sync(client, sync_token)
            else:
                return await self._full_sync(client)
                
        except Exception as e:
            logger.error(f"Contacts sync failed: {e}")
            return {"error": str(e)}
    
    async def _full_sync(self, client: GoogleClient) -> dict:
        """Perform full sync of contacts."""
        created_count = 0
        updated_count = 0
        
        contacts = []
        page_token = None
        
        # Paginate through all contacts
        while True:
            params = {
                "resourceName": "people/me",
                "pageSize": 100,
                "personFields": PERSON_FIELDS,
            }
            if page_token:
                params["pageToken"] = page_token
            
            result = client.people.people().connections().list(**params).execute()
            
            contacts.extend(result.get("connections", []))
            page_token = result.get("nextPageToken")
            
            # Store sync token for incremental sync
            if sync_token := result.get("nextSyncToken"):
                await self._store_sync_token(sync_token)
            
            if not page_token:
                break
        
        # Process contacts
        for contact in contacts:
            result = await self._process_contact(contact)
            if result == "created":
                created_count += 1
            elif result == "updated":
                updated_count += 1
        
        return {
            "success": True,
            "contacts_found": len(contacts),
            "created": created_count,
            "updated": updated_count,
            "sync_type": "full"
        }
    
    async def _incremental_sync(self, client: GoogleClient, sync_token: str) -> dict:
        """Perform incremental sync using sync token."""
        try:
            result = client.people.people().connections().list(
                resourceName="people/me",
                syncToken=sync_token,
                personFields=PERSON_FIELDS,
            ).execute()
            
            # Update sync token
            if new_token := result.get("nextSyncToken"):
                await self._store_sync_token(new_token)
            
            contacts = result.get("connections", [])
            
            created_count = 0
            updated_count = 0
            
            for contact in contacts:
                result = await self._process_contact(contact)
                if result == "created":
                    created_count += 1
                elif result == "updated":
                    updated_count += 1
            
            return {
                "success": True,
                "contacts_found": len(contacts),
                "created": created_count,
                "updated": updated_count,
                "sync_type": "incremental"
            }
            
        except Exception as e:
            # Sync token expired, do full sync
            if "syncToken" in str(e).lower() or "410" in str(e):
                logger.info("Sync token expired, performing full sync")
                return await self._full_sync(client)
            raise
    
    async def _process_contact(self, contact: dict) -> str:
        """
        Process a single contact.
        
        Returns: "created", "updated", or "skipped"
        """
        resource_name = contact.get("resourceName", "")
        
        # Extract data
        names = contact.get("names", [])
        emails = contact.get("emailAddresses", [])
        orgs = contact.get("organizations", [])
        phones = contact.get("phoneNumbers", [])
        photos = contact.get("photos", [])
        
        # Skip if no name or email
        if not names and not emails:
            return "skipped"
        
        # Get primary values
        name = names[0].get("displayName", "") if names else ""
        email = emails[0].get("value", "") if emails else None
        organization = orgs[0].get("name", "") if orgs else None
        role = orgs[0].get("title", "") if orgs else None
        phone = phones[0].get("value", "") if phones else None
        photo_url = photos[0].get("url", "") if photos else None
        
        # Check if person already exists (by Google resource name)
        existing = await self._get_person_by_resource_name(resource_name)
        
        if existing:
            # Check if anything changed
            if self._person_changed(existing, name, email, organization, role, phone):
                await self._update_person(
                    existing["id"],
                    name=name,
                    email=email,
                    organization=organization,
                    role=role,
                    phone=phone,
                    photo_url=photo_url
                )
                return "updated"
            return "skipped"
        else:
            # Create new person
            await self._create_person(
                resource_name=resource_name,
                name=name,
                email=email,
                organization=organization,
                role=role,
                phone=phone,
                photo_url=photo_url
            )
            return "created"
    
    async def _create_person(
        self,
        resource_name: str,
        name: str,
        email: str | None,
        organization: str | None,
        role: str | None,
        phone: str | None,
        photo_url: str | None
    ) -> None:
        """Create a person in the database."""
        person_id = str(uuid4())
        
        # Generate name embedding for semantic search
        name_embedding = None
        try:
            ai = get_ai()
            text = f"{name}"
            if organization:
                text += f" at {organization}"
            if role:
                text += f" ({role})"
            embedding, _ = await ai.embed(text)
            name_embedding = embedding
        except Exception as e:
            logger.warning(f"Failed to generate name embedding: {e}")
        
        # Insert into people table
        self.db.client.table("people").insert({
            "id": person_id,
            "name": name,
            "email": email,
            "organization": organization,
            "role": role,
            "phone": phone,
            "photo_url": photo_url,
            "importance": 0,  # Default, user adjusts later
            "name_embedding": name_embedding,
            "metadata": {"google_resource_name": resource_name},
            "created_at": utc_now().isoformat(),
            "updated_at": utc_now().isoformat()
        }).execute()
    
    async def _update_person(
        self,
        person_id: str,
        name: str,
        email: str | None,
        organization: str | None,
        role: str | None,
        phone: str | None,
        photo_url: str | None
    ) -> None:
        """Update a person in the database."""
        # Regenerate name embedding
        name_embedding = None
        try:
            ai = get_ai()
            text = f"{name}"
            if organization:
                text += f" at {organization}"
            if role:
                text += f" ({role})"
            embedding, _ = await ai.embed(text)
            name_embedding = embedding
        except Exception as e:
            logger.warning(f"Failed to generate name embedding: {e}")
        
        update_data = {
            "name": name,
            "email": email,
            "organization": organization,
            "role": role,
            "phone": phone,
            "photo_url": photo_url,
            "updated_at": utc_now().isoformat()
        }
        if name_embedding:
            update_data["name_embedding"] = name_embedding
        
        self.db.client.table("people").update(update_data).eq("id", person_id).execute()
    
    async def _get_person_by_resource_name(self, resource_name: str) -> dict | None:
        """Get a person by Google resource name."""
        try:
            result = self.db.client.table("people").select("*").eq(
                "metadata->>google_resource_name", resource_name
            ).execute()
            
            if result.data:
                return result.data[0]
            return None
        except Exception:
            return None
    
    def _person_changed(
        self,
        existing: dict,
        name: str,
        email: str | None,
        organization: str | None,
        role: str | None,
        phone: str | None
    ) -> bool:
        """Check if person data has changed."""
        return (
            existing.get("name") != name or
            existing.get("email") != email or
            existing.get("organization") != organization or
            existing.get("role") != role or
            existing.get("phone") != phone
        )
    
    async def _get_stored_sync_token(self) -> str | None:
        """Get stored sync token from service_state_cache."""
        try:
            result = self.db.client.table("service_state_cache").select("*").eq(
                "service_name", "google_contacts"
            ).eq("state_key", "sync_token").execute()
            
            if result.data:
                return result.data[0].get("state_value")
            return None
        except Exception:
            return None
    
    async def _store_sync_token(self, sync_token: str) -> None:
        """Store sync token in service_state_cache."""
        try:
            self.db.client.table("service_state_cache").upsert({
                "service_name": "google_contacts",
                "state_key": "sync_token",
                "state_value": sync_token,
                "updated_at": utc_now().isoformat()
            }, on_conflict="service_name,state_key").execute()
        except Exception as e:
            logger.warning(f"Failed to store sync token: {e}")


async def search_people(db: DatabaseProtocol, query: str, limit: int = 10) -> list[dict]:
    """
    Semantic search for people by name/role/organization.
    
    Uses name_embedding for similarity search.
    """
    try:
        # Generate query embedding
        ai = get_ai()
        query_embedding, _ = await ai.embed(query)
        
        # Search using pgvector
        result = db.client.rpc(
            "search_people_by_embedding",
            {
                "query_embedding": query_embedding,
                "match_threshold": 0.3,
                "match_count": limit
            }
        ).execute()
        
        return result.data if result.data else []
        
    except Exception as e:
        logger.error(f"People search failed: {e}")
        # Fallback to text search
        result = db.client.table("people").select("*").ilike(
            "name", f"%{query}%"
        ).limit(limit).execute()
        
        return result.data if result.data else []
