"""
Gmail sync for Jomni.

WHY THIS EXISTS:
Email is a primary source of tasks, commitments, and context. This module
syncs Gmail messages → Jomni items with item_type='email', enabling:
- Semantic search across emails
- AI-powered email triage
- Unified inbox with tasks, ideas, and emails
- Reply drafting and sending via MCP

SYNC STRATEGY:
- Full sync: Fetch all messages from specified labels/folders
- Incremental sync: Use Gmail history API with stored historyId
- Store sync state in service_state_cache for efficiency

WRITE OPERATIONS:
- Draft replies linked to message threads
- Send emails directly
- Archive/label management
"""

import base64
import logging
import re
from datetime import datetime
from email.mime.text import MIMEText
from typing import Any
from uuid import UUID

from jomni.db.protocol import DatabaseProtocol
from jomni.integrations.google.auth import GoogleAuth
from jomni.integrations.google.client import GoogleClient
from jomni.models import ItemCreate, ItemUpdate, ItemType, ItemStatus, ActorType
from jomni.utils.datetime import utc_now, parse_iso
from jomni.utils.embeddings import store_item_embedding

logger = logging.getLogger(__name__)

# Gmail labels we care about
DEFAULT_LABELS = ["INBOX"]
MAX_RESULTS_PER_PAGE = 100


class GmailSync:
    """Syncs Gmail messages to Jomni items."""
    
    def __init__(self, db: DatabaseProtocol, auth: GoogleAuth):
        self.db = db
        self.auth = auth
    
    async def _get_item_by_gmail_id(self, gmail_message_id: str):
        """
        Get an item by its Gmail message ID using direct indexed lookup.
        
        This is O(1) compared to the previous O(n) approach of listing all emails
        and scanning linearly. Requires that metadata->>gmail_message_id is indexed.
        
        Args:
            gmail_message_id: The Gmail message ID to look up
            
        Returns:
            Item if found, None otherwise
        """
        from jomni.models import Item
        
        try:
            result = self.db.client.table("items")\
                .select("*")\
                .eq("item_type", ItemType.EMAIL.value)\
                .eq("metadata->>gmail_message_id", gmail_message_id)\
                .maybeSingle()\
                .execute()
            
            if result.data:
                return Item(**result.data)
            return None
        except Exception as e:
            # Fallback for SQLite or other backends that don't support this query
            logger.debug(f"Direct lookup failed, email may not exist: {e}")
            return None
    
    async def sync(
        self,
        labels: list[str] | None = None,
        max_results: int = 100,
        full_sync: bool = False
    ) -> dict:
        """
        Sync Gmail messages to Jomni.
        
        Args:
            labels: Labels to sync (default: INBOX)
            max_results: Maximum messages to fetch
            full_sync: Force full sync even if historyId exists
            
        Returns:
            Summary with emails_found, created, updated counts
        """
        try:
            # Get valid credentials
            creds = await self.auth.get_valid_credentials()
            if not creds:
                return {"error": "Not connected to Google"}
            
            client = GoogleClient(creds)
            labels = labels or DEFAULT_LABELS
            
            # Define actor for audit trail (explicit pattern, not stateful)
            self._actor = (ActorType.SYSTEM, "gmail-sync")
            
            # Get stored historyId for incremental sync
            history_id = None
            if not full_sync:
                history_id = await self._get_stored_history_id()
            
            if history_id:
                return await self._incremental_sync(client, history_id, max_results)
            else:
                return await self._full_sync(client, labels, max_results)
                
        except Exception as e:
            logger.error(f"Gmail sync failed: {e}")
            return {"error": str(e)}
    
    async def _full_sync(
        self,
        client: GoogleClient,
        labels: list[str],
        max_results: int
    ) -> dict:
        """Perform full sync of messages."""
        created_count = 0
        updated_count = 0
        
        # Fetch message list
        query = " OR ".join([f"label:{label}" for label in labels])
        messages_response = client.gmail.users().messages().list(
            userId='me',
            q=query,
            maxResults=max_results
        ).execute()
        
        messages = messages_response.get('messages', [])
        
        # Store historyId from profile for next incremental sync
        profile = client.gmail.users().getProfile(userId='me').execute()
        await self._store_history_id(profile.get('historyId'))
        
        # Process each message
        for msg_ref in messages:
            result = await self._process_message(client, msg_ref['id'])
            if result == "created":
                created_count += 1
            elif result == "updated":
                updated_count += 1
        
        return {
            "success": True,
            "emails_found": len(messages),
            "created": created_count,
            "updated": updated_count,
            "sync_type": "full"
        }
    
    async def _incremental_sync(
        self,
        client: GoogleClient,
        history_id: str,
        max_results: int
    ) -> dict:
        """Perform incremental sync using Gmail history API."""
        try:
            history_response = client.gmail.users().history().list(
                userId='me',
                startHistoryId=history_id,
                historyTypes=['messageAdded', 'labelAdded', 'labelRemoved']
            ).execute()
            
            # Update stored historyId
            new_history_id = history_response.get('historyId')
            if new_history_id:
                await self._store_history_id(new_history_id)
            
            # Extract message IDs from history
            message_ids = set()
            for record in history_response.get('history', []):
                for msg in record.get('messagesAdded', []):
                    message_ids.add(msg['message']['id'])
                for msg in record.get('labelsAdded', []):
                    message_ids.add(msg['message']['id'])
                for msg in record.get('labelsRemoved', []):
                    message_ids.add(msg['message']['id'])
            
            # Process changed messages
            created_count = 0
            updated_count = 0
            
            for msg_id in list(message_ids)[:max_results]:
                result = await self._process_message(client, msg_id)
                if result == "created":
                    created_count += 1
                elif result == "updated":
                    updated_count += 1
            
            return {
                "success": True,
                "emails_found": len(message_ids),
                "created": created_count,
                "updated": updated_count,
                "sync_type": "incremental"
            }
            
        except Exception as e:
            # History ID invalid (410), do full sync
            if "410" in str(e) or "historyId" in str(e).lower():
                logger.info("History ID expired, performing full sync")
                return await self._full_sync(
                    client, DEFAULT_LABELS, max_results
                )
            raise
    
    async def _process_message(self, client: GoogleClient, message_id: str) -> str:
        """
        Process a single Gmail message.
        
        Returns: "created", "updated", or "skipped"
        """
        # Fetch full message
        msg = client.gmail.users().messages().get(
            userId='me',
            id=message_id,
            format='full'
        ).execute()
        
        # Check if already exists using direct indexed lookup (O(1) instead of O(n²))
        # Previous implementation fetched up to 1000 items and scanned linearly,
        # which caused O(n²) performance and missed duplicates beyond limit.
        existing = await self._get_item_by_gmail_id(message_id)
        
        # Parse message
        content = self._parse_message(msg)
        
        # Build metadata
        metadata = {
            "gmail_message_id": message_id,
            "gmail_thread_id": msg.get('threadId'),
            "source": "gmail",
            "labels": msg.get('labelIds', []),
            "internal_date": msg.get('internalDate'),
        }
        
        if existing:
            # Check if labels changed
            if set(existing.metadata.get("labels", [])) != set(metadata["labels"]):
                await self.db.update_item(
                    existing.id,
                    ItemUpdate(metadata=metadata),
                    reasoning="Labels updated from Gmail sync"
                )
                return "updated"
            return "skipped"
        else:
            # Create new item
            item = await self.db.create_item(
                ItemCreate(
                    item_type=ItemType.EMAIL,
                    status=ItemStatus.ARCHIVED,
                    content=content,
                    metadata=metadata,
                    tags=["email", "gmail"]
                ),
                reasoning="Imported from Gmail"
            )
            
            # Generate embedding
            await self._generate_embedding(item.id, content)
            
            return "created"
    
    def _parse_message(self, msg: dict) -> dict:
        """Parse Gmail message into structured content."""
        headers = {h['name'].lower(): h['value'] 
                   for h in msg.get('payload', {}).get('headers', [])}
        
        # Parse from address
        from_raw = headers.get('from', '')
        from_parsed = self._parse_email_address(from_raw)
        
        # Parse to addresses
        to_raw = headers.get('to', '')
        to_parsed = [self._parse_email_address(addr.strip()) 
                     for addr in to_raw.split(',') if addr.strip()]
        
        # Parse cc
        cc_raw = headers.get('cc', '')
        cc_parsed = [self._parse_email_address(addr.strip()) 
                     for addr in cc_raw.split(',') if addr.strip()] if cc_raw else []
        
        # Parse date
        date_str = headers.get('date', '')
        date = parse_iso(date_str) or utc_now()
        
        # Get body
        body_plain = self._extract_body(msg.get('payload', {}))
        
        # Build content
        # IMPORTANT: Include 'text' field for unified search
        # This allows jomni:search to find emails alongside tasks/notes
        from_name = from_parsed.get("name", "")
        from_email = from_parsed.get("email", "")
        subject = headers.get('subject', '(no subject)')
        searchable_text = f"{subject} {from_name} {from_email} {body_plain[:500]}"
        
        return {
            "text": searchable_text,  # For unified search
            "message_id": msg.get('id'),
            "thread_id": msg.get('threadId'),
            "from": from_parsed,
            "to": to_parsed,
            "cc": cc_parsed,
            "subject": subject,
            "date": date.isoformat() if date else None,
            "snippet": msg.get('snippet', ''),
            "body_plain": body_plain[:10000],  # Limit body size
            "labels": msg.get('labelIds', []),
            "has_attachments": self._has_attachments(msg.get('payload', {}))
        }
    
    def _parse_email_address(self, raw: str) -> dict:
        """Parse 'Name <email@example.com>' format."""
        match = re.match(r'(.+?)\s*<(.+?)>', raw)
        if match:
            return {"name": match.group(1).strip('" '), "email": match.group(2)}
        return {"name": "", "email": raw.strip()}
    
    def _extract_body(self, payload: dict) -> str:
        """Extract plain text body from message payload."""
        if payload.get('body', {}).get('data'):
            return base64.urlsafe_b64decode(
                payload['body']['data']
            ).decode('utf-8', errors='ignore')
        
        # Check parts for multipart messages
        for part in payload.get('parts', []):
            if part.get('mimeType') == 'text/plain':
                if part.get('body', {}).get('data'):
                    return base64.urlsafe_b64decode(
                        part['body']['data']
                    ).decode('utf-8', errors='ignore')
            # Recurse into nested parts
            if part.get('parts'):
                body = self._extract_body(part)
                if body:
                    return body
        
        return ""
    
    def _has_attachments(self, payload: dict) -> bool:
        """Check if message has attachments."""
        for part in payload.get('parts', []):
            if part.get('filename'):
                return True
            if part.get('parts') and self._has_attachments(part):
                return True
        return False
    
    async def _generate_embedding(self, item_id: UUID, content: dict) -> None:
        """Generate embedding for email content."""
        try:
            # Build text for embedding
            parts = []
            if subject := content.get("subject"):
                parts.append(f"Subject: {subject}")
            if from_addr := content.get("from", {}).get("email"):
                parts.append(f"From: {from_addr}")
            if snippet := content.get("snippet"):
                parts.append(snippet)
            if body := content.get("body_plain"):
                parts.append(body[:2000])  # First 2000 chars
            parts.append("Type: email")
            
            text = "\n".join(parts)
            if text.strip():
                await store_item_embedding(item_id, text, self.db)
        except Exception as e:
            logger.warning(f"Failed to generate embedding for email {item_id}: {e}")
    
    async def _get_stored_history_id(self) -> str | None:
        """Get stored historyId from service_state_cache."""
        try:
            # Query service_state_cache table
            result = self.db.client.table("service_state_cache").select("*").eq(
                "service_name", "gmail"
            ).eq("state_key", "history_id").execute()
            
            if result.data:
                history_id = result.data[0].get("state_value")
                # LINUS-D07: Validate history ID is numeric
                if history_id and str(history_id).isdigit():
                    return history_id
                elif history_id:
                    logger.warning(f"Invalid history ID format (not numeric): {history_id[:20]}...")
            return None
        except Exception:
            return None
    
    async def _store_history_id(self, history_id: str) -> None:
        """Store historyId in service_state_cache."""
        try:
            self.db.client.table("service_state_cache").upsert({
                "service_name": "gmail",
                "state_key": "history_id",
                "state_value": history_id,
                "updated_at": utc_now().isoformat()
            }, on_conflict="service_name,state_key").execute()
        except Exception as e:
            logger.warning(f"Failed to store history ID: {e}")
    
    # =========================================================================
    # WRITE OPERATIONS
    # =========================================================================
    
    async def draft_reply(
        self,
        item_id: UUID,
        body: str,
        include_quote: bool = True
    ) -> dict:
        """
        Create a draft reply to an email.
        
        Args:
            item_id: Jomni item ID of the email to reply to
            body: Reply body text
            include_quote: Include original message in reply
            
        Returns:
            Draft info with gmail_draft_id
        """
        # Get the email item
        item = await self.db.get_item(item_id)
        if not item or item.item_type != ItemType.EMAIL:
            return {"error": "Item not found or not an email"}
        
        # Get credentials
        creds = await self.auth.get_valid_credentials()
        if not creds:
            return {"error": "Not connected to Google"}
        
        client = GoogleClient(creds)
        
        # Build reply
        content = item.content
        thread_id = item.metadata.get("gmail_thread_id")
        original_subject = content.get("subject", "")
        
        # Ensure Re: prefix
        if not original_subject.lower().startswith("re:"):
            subject = f"Re: {original_subject}"
        else:
            subject = original_subject
        
        # Build message body
        if include_quote:
            original_from = content.get("from", {})
            original_date = content.get("date", "")
            quote = f"\n\nOn {original_date}, {original_from.get('email', '')} wrote:\n> "
            quote += content.get("body_plain", "").replace("\n", "\n> ")[:2000]
            full_body = body + quote
        else:
            full_body = body
        
        # Create MIME message
        message = MIMEText(full_body)
        message['to'] = content.get("from", {}).get("email", "")
        message['subject'] = subject
        
        # Add In-Reply-To header
        original_message_id = content.get("message_id")
        if original_message_id:
            message['In-Reply-To'] = original_message_id
            message['References'] = original_message_id
        
        # Encode message
        raw = base64.urlsafe_b64encode(message.as_bytes()).decode()
        
        # Create draft
        draft = client.gmail.users().drafts().create(
            userId='me',
            body={
                'message': {
                    'raw': raw,
                    'threadId': thread_id
                }
            }
        ).execute()
        
        return {
            "success": True,
            "gmail_draft_id": draft['id'],
            "thread_id": thread_id
        }
    
    async def send_reply(
        self,
        item_id: UUID,
        body: str
    ) -> dict:
        """
        Send a reply to an email immediately.
        
        Args:
            item_id: Jomni item ID of the email to reply to
            body: Reply body text
            
        Returns:
            Sent message info
        """
        # First create draft
        draft_result = await self.draft_reply(item_id, body)
        if "error" in draft_result:
            return draft_result
        
        # Get credentials
        creds = await self.auth.get_valid_credentials()
        client = GoogleClient(creds)
        
        # Send the draft
        sent = client.gmail.users().drafts().send(
            userId='me',
            body={'id': draft_result['gmail_draft_id']}
        ).execute()
        
        return {
            "success": True,
            "gmail_message_id": sent['id'],
            "thread_id": sent.get('threadId')
        }
    
    async def archive_email(self, item_id: UUID) -> dict:
        """Remove INBOX label from email."""
        return await self._modify_labels(item_id, remove_labels=['INBOX'])
    
    async def mark_read(self, item_id: UUID) -> dict:
        """Remove UNREAD label from email."""
        return await self._modify_labels(item_id, remove_labels=['UNREAD'])
    
    async def mark_unread(self, item_id: UUID) -> dict:
        """Add UNREAD label to email."""
        return await self._modify_labels(item_id, add_labels=['UNREAD'])
    
    async def add_label(self, item_id: UUID, label: str) -> dict:
        """Add a label to email."""
        return await self._modify_labels(item_id, add_labels=[label])
    
    async def remove_label(self, item_id: UUID, label: str) -> dict:
        """Remove a label from email."""
        return await self._modify_labels(item_id, remove_labels=[label])
    
    async def _modify_labels(
        self,
        item_id: UUID,
        add_labels: list[str] | None = None,
        remove_labels: list[str] | None = None
    ) -> dict:
        """Modify labels on a Gmail message."""
        # Get the email item
        item = await self.db.get_item(item_id)
        if not item or item.item_type != ItemType.EMAIL:
            return {"error": "Item not found or not an email"}
        
        gmail_message_id = item.metadata.get("gmail_message_id")
        if not gmail_message_id:
            return {"error": "No Gmail message ID found"}
        
        # Get credentials
        creds = await self.auth.get_valid_credentials()
        if not creds:
            return {"error": "Not connected to Google"}
        
        client = GoogleClient(creds)
        
        # Modify labels
        body = {}
        if add_labels:
            body['addLabelIds'] = add_labels
        if remove_labels:
            body['removeLabelIds'] = remove_labels
        
        result = client.gmail.users().messages().modify(
            userId='me',
            id=gmail_message_id,
            body=body
        ).execute()
        
        # Update local item metadata
        new_labels = result.get('labelIds', [])
        await self.db.update_item(
            item_id,
            ItemUpdate(metadata={**item.metadata, "labels": new_labels}),
            reasoning=f"Labels modified: +{add_labels or []}, -{remove_labels or []}"
        )
        
        return {
            "success": True,
            "labels": new_labels
        }
