"""
Jomni integration for Tally form webhooks.

Receives survey responses from Tally and stores them in Supabase for analysis.
Configure webhook URL in Tally: https://your-domain.com/webhooks/tally

SECURITY: Webhooks are validated using HMAC-SHA256 signature verification.
Set JOMNI_TALLY_WEBHOOK_SECRET in your environment to enable validation.
"""

import hashlib
import hmac
import logging
from datetime import datetime, timezone
from typing import Any, Optional
from uuid import uuid4

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from jomni.config import get_settings


logger = logging.getLogger(__name__)

router = APIRouter(tags=["webhooks"])


# =============================================================================
# SIGNATURE VERIFICATION
# =============================================================================

def verify_tally_signature(payload: bytes, signature: str | None, secret: str) -> bool:
    """
    Verify Tally webhook signature using HMAC-SHA256.
    
    Tally sends a signature in the X-Tally-Signature header.
    We compute the expected signature and use constant-time comparison
    to prevent timing attacks.
    
    Args:
        payload: Raw request body bytes
        signature: Value of X-Tally-Signature header
        secret: Webhook secret from Tally dashboard
        
    Returns:
        True if signature is valid, False otherwise
    """
    if not signature:
        return False
    
    expected = hmac.new(
        secret.encode('utf-8'),
        payload,
        hashlib.sha256
    ).hexdigest()
    
    # Use constant-time comparison to prevent timing attacks
    return hmac.compare_digest(signature, expected)


# =============================================================================
# SUPABASE CLIENT (lazy init)
# =============================================================================

_supabase_client = None

def get_supabase():
    """Get or create Supabase client."""
    global _supabase_client
    if _supabase_client is None:
        try:
            from supabase import create_client
            settings = get_settings()
            if settings.is_configured:
                _supabase_client = create_client(
                    settings.supabase_url,
                    settings.supabase_service_key
                )
        except Exception as e:
            logger.warning(f"Supabase not available for survey storage: {e}")
    return _supabase_client


# =============================================================================
# MODELS
# =============================================================================

class TallyField(BaseModel):
    """Individual field from Tally form submission."""
    key: str
    label: str
    type: str
    value: Any


class TallySubmission(BaseModel):
    """Tally webhook payload for form submission."""
    eventId: str
    eventType: str  # "FORM_RESPONSE"
    createdAt: str
    data: dict  # Contains formId, formName, responseId, fields, etc.


class SurveyResponse(BaseModel):
    """Stored survey response."""
    id: str
    form_id: str
    form_name: str
    response_id: str
    submitted_at: datetime
    fields: dict[str, Any]


class SurveyResponseSummary(BaseModel):
    """Summary of survey responses for analysis."""
    total_responses: int
    responses: list[dict]


# In-memory fallback storage (used when Supabase not configured)
_survey_responses: list[dict] = []


# =============================================================================
# ENDPOINTS
# =============================================================================

@router.post("/webhooks/tally")
async def receive_tally_webhook(request: Request) -> dict:
    """
    Receive webhook from Tally form submission.
    
    SECURITY: If JOMNI_TALLY_WEBHOOK_SECRET is set, webhooks are validated
    using HMAC-SHA256 signature verification. Requests without valid
    signatures are rejected with 401.
    
    Configure in Tally:
    1. Open form settings > Integrations > Webhooks
    2. Add webhook URL: https://your-domain.com/webhooks/tally
    3. Enable "Form response" event
    4. Copy the signing secret and set it as JOMNI_TALLY_WEBHOOK_SECRET
    
    Tally sends POST with JSON payload containing form response data.
    """
    settings = get_settings()
    
    # Read raw body for signature verification (must do before .json())
    payload = await request.body()
    
    # Verify signature if secret is configured
    if settings.tally_webhook_secret:
        signature = request.headers.get("X-Tally-Signature")
        if not verify_tally_signature(payload, signature, settings.tally_webhook_secret):
            logger.warning("Tally webhook rejected: invalid or missing signature")
            raise HTTPException(status_code=401, detail="Invalid webhook signature")
    else:
        logger.warning("Tally webhook secret not configured - accepting unverified webhook")
    
    try:
        import json
        payload_json = json.loads(payload)
        logger.info(f"Received Tally webhook: {payload_json.get('eventType', 'unknown')}")
        
        # Parse the Tally payload
        event_type = payload_json.get("eventType", "")
        
        if event_type != "FORM_RESPONSE":
            logger.warning(f"Ignoring non-response event: {event_type}")
            return {"status": "ignored", "reason": f"Event type {event_type} not processed"}
        
        data = payload_json.get("data", {})
        fields_list = data.get("fields", [])
        
        # Convert fields list to dict for easier access
        fields_dict = {}
        for field in fields_list:
            key = field.get("key", field.get("label", "unknown"))
            fields_dict[key] = {
                "label": field.get("label"),
                "type": field.get("type"),
                "value": field.get("value"),
            }
        
        # Prepare record
        response_id = data.get("responseId", str(uuid4()))
        form_id = data.get("formId", "")
        form_name = data.get("formName", "")
        
        record = {
            "id": str(uuid4()),
            "form_id": form_id,
            "form_name": form_name,
            "response_id": response_id,
            "submitted_at": datetime.now(timezone.utc).isoformat(),
            "fields": fields_dict,
            "raw_payload": payload,
        }
        
        # Store in Supabase if available, otherwise fallback to memory
        supabase = get_supabase()
        if supabase:
            try:
                supabase.table("survey_responses").insert(record).execute()
                logger.info(f"Stored survey response {response_id} in Supabase")
            except Exception as e:
                logger.error(f"Supabase insert failed: {e}, falling back to memory")
                _survey_responses.append(record)
        else:
            _survey_responses.append(record)
            logger.info(f"Stored survey response {response_id} in memory (Supabase not configured)")
        
        return {
            "status": "received",
            "response_id": response_id,
            "fields_count": len(fields_dict),
            "storage": "supabase" if supabase else "memory",
        }
        
    except Exception as e:
        logger.error(f"Failed to process Tally webhook: {e}")
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/webhooks/tally/responses", response_model=SurveyResponseSummary)
async def get_survey_responses(
    form_id: Optional[str] = None,
    limit: int = 100,
) -> SurveyResponseSummary:
    """
    Get stored survey responses for analysis.
    
    Optionally filter by form_id.
    """
    supabase = get_supabase()
    
    if supabase:
        try:
            query = supabase.table("survey_responses").select("*")
            if form_id:
                query = query.eq("form_id", form_id)
            query = query.order("submitted_at", desc=True).limit(limit)
            result = query.execute()
            responses = result.data
        except Exception as e:
            logger.error(f"Supabase query failed: {e}")
            responses = _survey_responses
    else:
        responses = _survey_responses
        if form_id:
            responses = [r for r in responses if r.get("form_id") == form_id]
    
    # Format for response
    response_dicts = []
    for r in responses[:limit]:
        response_dicts.append({
            "id": r.get("id"),
            "form_name": r.get("form_name"),
            "response_id": r.get("response_id"),
            "submitted_at": r.get("submitted_at"),
            "fields": r.get("fields", {}),
        })
    
    return SurveyResponseSummary(
        total_responses=len(responses),
        responses=response_dicts,
    )


@router.get("/webhooks/tally/analysis")
async def analyze_survey_responses(form_id: Optional[str] = None) -> dict:
    """
    Basic analysis of survey responses.
    
    Returns aggregated data for key questions.
    """
    supabase = get_supabase()
    
    if supabase:
        try:
            query = supabase.table("survey_responses").select("*")
            if form_id:
                query = query.eq("form_id", form_id)
            result = query.execute()
            responses = result.data
        except Exception as e:
            logger.error(f"Supabase query failed: {e}")
            responses = _survey_responses
    else:
        responses = _survey_responses
    
    if not responses:
        return {
            "total_responses": 0,
            "message": "No responses yet",
            "storage": "supabase" if supabase else "memory",
        }
    
    # Aggregate ratings (look for 1-5 scale questions)
    feature_ratings = {}
    pricing_responses = []
    beta_interest = {"yes": 0, "maybe": 0, "no": 0}
    would_pay_8 = {"yes": 0, "maybe": 0, "probably_not": 0, "no": 0}
    
    for r in responses:
        fields = r.get("fields", {})
        for key, field in fields.items():
            value = field.get("value") if isinstance(field, dict) else field
            label = field.get("label", key) if isinstance(field, dict) else key
            
            # Collect numeric ratings (1-5)
            if isinstance(value, (int, float)) and 1 <= value <= 5:
                if label not in feature_ratings:
                    feature_ratings[label] = []
                feature_ratings[label].append(value)
            
            # Check for $8/month pricing question
            if "$8" in str(label).lower() or "would you pay" in str(label).lower():
                if isinstance(value, str):
                    v_lower = value.lower()
                    if "yes, definitely" in v_lower or v_lower == "yes":
                        would_pay_8["yes"] += 1
                    elif "maybe" in v_lower:
                        would_pay_8["maybe"] += 1
                    elif "probably not" in v_lower:
                        would_pay_8["probably_not"] += 1
                    elif "no" in v_lower:
                        would_pay_8["no"] += 1
            
            # Check for beta interest
            if "beta" in str(label).lower():
                if isinstance(value, str):
                    v_lower = value.lower()
                    if "yes" in v_lower and "sign" in v_lower:
                        beta_interest["yes"] += 1
                    elif "maybe" in v_lower:
                        beta_interest["maybe"] += 1
                    else:
                        beta_interest["no"] += 1
    
    # Calculate averages
    feature_averages = {}
    for label, ratings in feature_ratings.items():
        feature_averages[label] = round(sum(ratings) / len(ratings), 2)
    
    # Sort by average rating
    sorted_features = sorted(feature_averages.items(), key=lambda x: x[1], reverse=True)
    
    total = len(responses)
    
    return {
        "total_responses": total,
        "storage": "supabase" if supabase else "memory",
        "feature_ratings": dict(sorted_features),
        "would_pay_8_monthly": would_pay_8,
        "would_pay_percentage": round(
            (would_pay_8["yes"] + would_pay_8["maybe"]) / total * 100
        ) if total else 0,
        "beta_interest": beta_interest,
        "beta_interest_rate": round(
            (beta_interest["yes"] + beta_interest["maybe"]) / total * 100
        ) if total else 0,
    }


@router.delete("/webhooks/tally/responses")
async def clear_survey_responses() -> dict:
    """Clear all stored survey responses (for testing)."""
    global _survey_responses
    
    supabase = get_supabase()
    if supabase:
        try:
            # Delete all rows (be careful in production!)
            supabase.table("survey_responses").delete().neq("id", "").execute()
            logger.info("Cleared all survey responses from Supabase")
        except Exception as e:
            logger.error(f"Failed to clear Supabase: {e}")
    
    count = len(_survey_responses)
    _survey_responses = []
    
    return {"status": "cleared", "memory_count": count}
