"""
Jomni: A personal database designed to last a lifetime.

This is the main FastAPI application that exposes the REST API.
All endpoints are designed for both human clients and AI agents via MCP.
"""

import logging
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI, Request, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

from jomni.config import get_settings
from jomni.api import items, triage, search, capture, chat, dashboard, export, memory, metrics
from jomni.api.auth import router as auth_router
from jomni.api.sessions import router as sessions_router
from jomni.api.sync import router as sync_router
from jomni.api.preferences import router as preferences_router  # Privacy & consent
from jomni.api.user import router as user_router  # GDPR data deletion
from jomni.api.keys import router as keys_router  # Scoped API keys
from jomni.api.webhooks import router as webhooks_router  # Outbound webhooks
from jomni.integrations.tally import router as tally_router
from jomni.security.auth import require_api_key


# =============================================================================
# RATE LIMITING
# Rate limiting prevents API abuse and protects against credit burn attacks.
# =============================================================================


limiter = Limiter(key_func=get_remote_address, default_limits=["100/minute"])


# Configure structured logging (JSON in production, colored in development)
from jomni.utils.logging import configure_logging, get_logger
settings = get_settings()
configure_logging(
    json_output=settings.environment == "production",
    level=logging.DEBUG if settings.debug else logging.INFO,
)
logger = get_logger("main")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Application lifespan handler.
    
    Runs on startup and shutdown. Use for:
    - Sentry error tracking initialization
    - Database connection pooling
    - Background task initialization (scheduler)
    - Graceful shutdown
    """
    settings = get_settings()
    
    # Initialize Sentry if configured (Task 1.9)
    if settings.sentry_dsn:
        try:
            import sentry_sdk
            from sentry_sdk.integrations.fastapi import FastApiIntegration
            from sentry_sdk.integrations.starlette import StarletteIntegration
            
            sentry_sdk.init(
                dsn=settings.sentry_dsn,
                traces_sample_rate=0.1,  # 10% of requests traced
                environment=settings.environment,
                integrations=[
                    StarletteIntegration(transaction_style="endpoint"),
                    FastApiIntegration(transaction_style="endpoint"),
                ],
            )
            logger.info(f"Sentry initialized (env={settings.environment})")
        except Exception as e:
            logger.warning(f"Sentry initialization failed: {e}")
    else:
        logger.info("Sentry not configured (set JOMNI_SENTRY_DSN to enable)")
    
    # LINUS-D04: Fail fast if OAuth configured without encryption key
    # This prevents a confusing crash during OAuth callback
    if settings.google_client_id and not settings.encryption_key:
        raise RuntimeError(
            "CONFIGURATION ERROR: Google OAuth is configured (JOMNI_GOOGLE_CLIENT_ID) "
            "but JOMNI_ENCRYPTION_KEY is not set. OAuth tokens cannot be stored securely. "
            "Generate a key with: python -c \"from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())\""
        )
    
    # Startup
    logger.info(f"Starting Jomni v0.1.0")
    logger.info(f"Debug mode: {settings.debug}")
    logger.info(f"Supabase configured: {settings.is_configured}")
    logger.info(f"AI configured: {settings.has_ai}")
    logger.info(f"API auth: {'enabled' if settings.api_key else 'DISABLED (dev mode)'}")
    
    # Start background scheduler
    try:
        from jomni.scheduler import start_scheduler, stop_scheduler
        await start_scheduler()
        logger.info("Background scheduler started")
    except Exception as e:
        logger.warning(f"Scheduler failed to start: {e}")
    
    yield
    
    # Shutdown
    try:
        from jomni.scheduler import stop_scheduler
        await stop_scheduler()
        logger.info("Background scheduler stopped")
    except Exception as e:
        logger.warning(f"Scheduler failed to stop: {e}")
    
    logger.info("Shutting down Jomni")


# Create the FastAPI application
app = FastAPI(
    title="Jomni",
    description="A personal database designed to last a lifetime. AI-native, local-first, future-proof.",
    version="0.1.0",
    lifespan=lifespan,
)

# Attach rate limiter to app
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)


# CORS middleware for web clients
# Origins controlled via JOMNI_CORS_ORIGINS env var
_settings = get_settings()
app.add_middleware(
    CORSMiddleware,
    allow_origins=_settings.cors_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "X-Request-ID", "X-API-Key"],
)

# Request ID middleware for request tracing (Task 1.10)
# Adds X-Request-ID header to all responses for log correlation
from jomni.middleware.request_id import RequestIDMiddleware
app.add_middleware(RequestIDMiddleware)


# =============================================================================
# PROTECTED API ROUTES (require authentication)
# =============================================================================

# Apply require_api_key dependency to all protected routes
api_auth_dependency = [Depends(require_api_key)]

app.include_router(capture.router, dependencies=api_auth_dependency)
app.include_router(items.router, prefix="/api/v1", dependencies=api_auth_dependency)
app.include_router(triage.router, prefix="/api/v1", dependencies=api_auth_dependency)
app.include_router(search.router, prefix="/api/v1", dependencies=api_auth_dependency)
app.include_router(chat.router, prefix="/api/v1", dependencies=api_auth_dependency)
app.include_router(dashboard.router, prefix="/api/v1", dependencies=api_auth_dependency)
app.include_router(export.router, prefix="/api/v1", dependencies=api_auth_dependency)
app.include_router(memory.router, prefix="/api/v1", dependencies=api_auth_dependency)
app.include_router(sessions_router, prefix="/api/v1", dependencies=api_auth_dependency)
app.include_router(sync_router, prefix="/api/v1", dependencies=api_auth_dependency)
app.include_router(preferences_router, prefix="/api/v1", dependencies=api_auth_dependency)  # Privacy & consent
app.include_router(user_router, prefix="/api/v1", dependencies=api_auth_dependency)  # GDPR data deletion
app.include_router(keys_router, dependencies=api_auth_dependency)  # Scoped API keys
app.include_router(webhooks_router, dependencies=api_auth_dependency)  # Outbound webhooks

# =============================================================================
# PUBLIC ROUTES (no authentication required)
# =============================================================================

# OAuth flow must be public (user authenticates via Google, not API key)
app.include_router(auth_router, prefix="/auth/google", tags=["auth"])

# Webhooks have their own authentication (signature validation)
app.include_router(tally_router, tags=["webhooks"])

# Metrics endpoint for Prometheus (monitoring systems need unauthenticated access)
app.include_router(metrics.router, tags=["monitoring"])



# =============================================================================
# ROOT ENDPOINTS
# =============================================================================

@app.get("/")
async def root():
    """
    Root endpoint with API information.
    
    This is what llms.txt and similar discovery mechanisms should point to.
    """
    return {
        "name": "Jomni",
        "version": "0.1.0",
        "description": "A personal database designed to last a lifetime",
        "docs": "/docs",
        "openapi": "/openapi.json",
        "endpoints": {
            "items": "/api/v1/items",
            "triage": "/api/v1/triage",
            "search": "/api/v1/search",
        },
    }


@app.get("/health")
async def health():
    """Health check endpoint with dependency verification.
    
    Unlike simple config checks, this verifies:
    - Database: Actually queries Supabase
    - AI: Checks if API keys are configured
    - Scheduler: Reports job status
    """
    settings = get_settings()
    
    # Check database connectivity
    db_status = "unknown"
    db_error = None
    try:
        from jomni.db import get_database
        db = get_database()
        # Simple query to verify connection
        result = db.client.table("items").select("id", count="exact").limit(1).execute()
        db_status = "connected"
    except Exception as e:
        db_status = "error"
        db_error = str(e)
    
    # Check scheduler status
    scheduler_status = "unknown"
    job_count = 0
    try:
        from jomni.scheduler import scheduler
        if scheduler.running:
            scheduler_status = "running"
            job_count = len(scheduler.get_jobs())
        else:
            scheduler_status = "stopped"
    except Exception as e:
        scheduler_status = "unavailable"
        logger.warning(f"Scheduler status check failed: {e}")
    
    return {
        "status": "healthy" if db_status == "connected" else "degraded",
        "database": {
            "status": db_status,
            "error": db_error,
            "configured": settings.is_configured,
        },
        "ai": {
            "configured": settings.has_ai,
            "anthropic": bool(settings.anthropic_api_key),
            "openai": bool(settings.openai_api_key),
            "ollama_enabled": settings.ollama_enabled,
        },
        "scheduler": {
            "status": scheduler_status,
            "jobs": job_count,
        },
    }


# =============================================================================
# ERROR HANDLERS
# =============================================================================

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """
    Global exception handler.
    
    Logs the error and returns a structured response.
    SECURITY: Never expose internal error details to clients, even in debug mode.
    Details are logged server-side only for debugging.
    """
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    
    return JSONResponse(
        status_code=500,
        content={
            "error": {
                "code": "INTERNAL_ERROR",
                "message": "An unexpected error occurred",
                # SECURITY: Internal details logged server-side only, never exposed
            }
        },
    )


# =============================================================================
# ENTRY POINT
# =============================================================================

def run():
    """Run the application using uvicorn."""
    settings = get_settings()
    
    uvicorn.run(
        "jomni.main:app",
        host=settings.host,
        port=settings.port,
        reload=settings.debug,
        log_level=settings.log_level.lower(),
    )


if __name__ == "__main__":
    run()
