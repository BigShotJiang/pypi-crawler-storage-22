"""
MCP Response Helpers.

Provides standardized response formatting for MCP tool calls.
Ensures consistent structure across all 40+ tools.
"""

import json
from typing import Any
from mcp.types import TextContent


def success(data: dict[str, Any]) -> list[TextContent]:
    """
    Return a successful MCP response.
    
    Standard format:
        {"success": true, ...data}
    
    Example:
        return success({"item_id": "abc123", "message": "Created"})
    """
    response = {"success": True, **data}
    return [TextContent(type="text", text=json.dumps(response, indent=2, default=str))]


def error(message: str, code: str | None = None, details: dict | None = None) -> list[TextContent]:
    """
    Return an error MCP response.
    
    Standard format:
        {"error": "message", "code": "ERROR_CODE", "details": {...}}
    
    Example:
        return error("Item not found", code="NOT_FOUND")
    """
    response: dict[str, Any] = {"error": message}
    if code:
        response["code"] = code
    if details:
        response["details"] = details
    return [TextContent(type="text", text=json.dumps(response, indent=2, default=str))]


def data(items: list | dict, count: int | None = None, metadata: dict | None = None) -> list[TextContent]:
    """
    Return data collection MCP response.
    
    Standard format:
        {"results": [...], "count": N, ...metadata}
    
    Example:
        return data(items=[...], count=5, metadata={"query": "foo"})
    """
    if isinstance(items, list):
        response: dict[str, Any] = {"results": items}
        if count is not None:
            response["count"] = count
        else:
            response["count"] = len(items)
    else:
        response = items  # Already a dict
        
    if metadata:
        response.update(metadata)
        
    return [TextContent(type="text", text=json.dumps(response, indent=2, default=str))]


def suggestion(
    item_type: str,
    confidence: float,
    reasoning: str,
    suggested_tags: list[str] | None = None,
    alternatives: list | None = None,
    auto_accepted: bool = False,
    item_id: str | None = None,
    item: dict | None = None,
) -> list[TextContent]:
    """
    Return a triage suggestion MCP response.
    
    Standard format for AI classification results.
    """
    response: dict[str, Any] = {
        "item_type": item_type,
        "confidence": confidence,
        "reasoning": reasoning,
        "suggested_tags": suggested_tags or [],
        "alternatives": alternatives or [],
        "auto_accepted": auto_accepted,
    }
    if item_id:
        response["item_id"] = item_id
    if item:
        response["item"] = item
    return [TextContent(type="text", text=json.dumps(response, indent=2, default=str))]


# Error code constants for consistency
class ErrorCodes:
    NOT_FOUND = "NOT_FOUND"
    INVALID_INPUT = "INVALID_INPUT"
    AI_FAILURE = "AI_FAILURE"
    DATABASE_ERROR = "DATABASE_ERROR"
    PERMISSION_DENIED = "PERMISSION_DENIED"
    RATE_LIMITED = "RATE_LIMITED"
    NOT_CONNECTED = "NOT_CONNECTED"
