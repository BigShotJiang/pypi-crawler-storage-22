"""
Jomni MCP Server.

Exposes Jomni's capabilities as tools that any MCP-compatible AI can use.
This is how Claude, GPT, or any future AI interacts with your data.

Architecture:
- Tool definitions live in mcp/tools/definitions.py
- Tool handlers live in tools/{category}.py modules
- This file is a thin dispatcher that routes calls to handlers

NOTE: All mutations use explicit actor parameter. The actor tuple is
created once in call_tool() and passed to handlers to ensure consistent
audit trail without race conditions. See db/protocol.py for details.
"""

import json
import logging
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

from jomni.ai.provider import get_ai
from jomni.config import get_settings
from jomni.db.client import get_db
from jomni.mcp.tools.definitions import ALL_TOOLS
from jomni.models import ActorType
from jomni.tools import TOOL_HANDLERS, ToolContext, load_all_handlers


# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("jomni.mcp")


# Create the MCP server
server = Server("jomni")


# Load all tool handlers into the registry
load_all_handlers()


# =============================================================================
# TOOL DEFINITIONS
# =============================================================================

@server.list_tools()
async def list_tools() -> list[Tool]:
    """
    List all available tools.
    
    Returns all tool definitions from definitions.py.
    Each tool has a name, description, and JSON schema for its parameters.
    """
    return ALL_TOOLS


# =============================================================================
# TOOL DISPATCH
# =============================================================================

@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    """
    Handle tool calls from AI models.
    
    Routes to the appropriate handler based on tool name.
    Each tool call is logged with the AI as the actor,
    providing full audit trail and accountability.
    """
    db = get_db()
    ai = get_ai()
    
    # Define actor for all MCP operations
    settings = get_settings()
    mcp_actor = (ActorType.AI, f"mcp:{settings.default_chat_model}")
    
    # Create context for handlers
    ctx = ToolContext(db=db, ai=ai, actor=mcp_actor)
    
    try:
        # Look up handler
        handler = TOOL_HANDLERS.get(name)
        
        if handler is None:
            result = {"error": f"Unknown tool: {name}"}
        else:
            result = await handler(ctx, arguments)
        
        return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]
    
    except Exception as e:
        # LINUS-D01: Log details server-side, return generic error to AI client
        logger.error(f"MCP tool '{name}' failed: {e}", exc_info=True)
        return [TextContent(
            type="text",
            text=json.dumps({"error": "Tool execution failed. Check server logs for details."}, indent=2),
        )]


# =============================================================================
# SERVER ENTRY POINT
# =============================================================================

async def run_server():
    """Run the MCP server."""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )


def run():
    """Entry point for the MCP server."""
    import asyncio
    asyncio.run(run_server())


if __name__ == "__main__":
    run()
