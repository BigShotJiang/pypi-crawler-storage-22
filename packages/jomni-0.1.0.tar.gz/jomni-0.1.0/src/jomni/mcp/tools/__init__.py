"""
MCP tool definitions and handlers.

This package organizes MCP tools into logical groups:
- capture: Quick capture and triage
- items: CRUD operations on items
- search: Semantic and keyword search
- goals: Goal management
- tags: Tag operations
- insights: what_now, digest, context
- integrations: Google services (calendar, gmail, contacts)
- people: Contact management
- scheduler: Background job control
"""

from .definitions import ALL_TOOLS
from .handlers import HANDLERS

__all__ = ["ALL_TOOLS", "HANDLERS"]
