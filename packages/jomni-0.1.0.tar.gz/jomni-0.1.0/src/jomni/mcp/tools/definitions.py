"""
MCP tool definitions (schemas only).

Tool definitions are separated from handlers for cleaner organization.
Each tool specifies name, description, and JSON schema.

NOTE: Core tools are also defined in jomni/tools/schemas.py for cross-API compatibility.
Chat API imports from the unified schema. MCP uses native mcp.types.Tool format here.
Extended tools (People, Recurring, Scheduler) are MCP-specific.

To add a new tool available to both MCP and Chat API:
1. Add to jomni/tools/schemas.py using ToolSchema
2. Update Chat API via get_anthropic_tools()
3. Add here using native Tool() format for MCP
"""

from mcp.types import Tool


# =============================================================================
# CAPTURE & TRIAGE TOOLS
# =============================================================================

CAPTURE_TOOLS = [
    Tool(
        name="capture",
        description=(
            "Add a new item to the inbox for later triage. "
            "Use this for quick capture of tasks, ideas, notes, or anything else. "
            "The item will be classified and organized later."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "text": {
                    "type": "string",
                    "description": "The text content to capture",
                },
                "context": {
                    "type": "object",
                    "description": "Optional context hints (e.g., source, related_to)",
                    "additionalProperties": True,
                },
            },
            "required": ["text"],
        },
    ),
    Tool(
        name="triage",
        description=(
            "Classify a capture into the appropriate type (task, idea, note, etc.) "
            "with a confidence score. High confidence items are auto-accepted; "
            "lower confidence items need user review. "
            "If item_id is provided, updates the existing item instead of creating a new one."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "text": {
                    "type": "string",
                    "description": "The text to classify (optional if item_id provided)",
                },
                "item_id": {
                    "type": "string",
                    "description": "Optional ID of existing inbox item to classify in-place",
                },
                "context": {
                    "type": "object",
                    "description": "Optional context for better classification",
                    "additionalProperties": True,
                },
            },
            "required": [],
        },
    ),
    Tool(
        name="accept_triage",
        description=(
            "Accept a triage suggestion and create the item. "
            "Use this after triage returns a suggestion that wasn't auto-accepted."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "text": {
                    "type": "string",
                    "description": "The original text that was triaged",
                },
                "item_type": {
                    "type": "string",
                    "description": "The item type to create: task, idea, note, habit, goal, project, reference",
                },
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Optional tags to apply",
                },
            },
            "required": ["text", "item_type"],
        },
    ),
    Tool(
        name="bulk_capture",
        description=(
            "Capture multiple items in one call. Use for imports and batch ingestion. "
            "If auto_triage=true, also classifies each item (high confidence auto-accepts). "
            "Returns summary with created count and item IDs."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "items": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "text": {"type": "string", "description": "The text content"},
                            "context": {"type": "object", "description": "Optional context hints"},
                        },
                        "required": ["text"],
                    },
                    "description": "List of items to capture",
                },
                "auto_triage": {
                    "type": "boolean",
                    "description": "If true, automatically triage each captured item",
                    "default": False,
                },
            },
            "required": ["items"],
        },
    ),
    Tool(
        name="triage_inbox",
        description=(
            "Process pending inbox items through AI triage. "
            "High confidence items are auto-classified; others await review. "
            "Use for batch processing after bulk import."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "limit": {
                    "type": "integer",
                    "description": "Max items to process (default: 10)",
                    "default": 10,
                },
                "auto_accept_above": {
                    "type": "number",
                    "description": "Auto-accept items with confidence above this threshold (default: 0.9)",
                    "default": 0.9,
                },
            },
            "required": [],
        },
    ),
]


# =============================================================================
# ITEM CRUD TOOLS
# =============================================================================

ITEM_TOOLS = [
    Tool(
        name="list_inbox",
        description=(
            "List all items in the inbox awaiting triage. "
            "Use this to see raw captures that need classification. "
            "Does not require embeddings - just returns items with inbox status."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of items to return (default 50)",
                    "default": 50,
                },
            },
        },
    ),
    Tool(
        name="list_items",
        description=(
            "List items with optional filters. No search query required. "
            "Use this to browse items by type or status - e.g., 'show all active tasks' "
            "or 'list completed items from this week'."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "item_type": {
                    "type": "string",
                    "enum": ["task", "idea", "note", "email", "event", "goal", "habit", "person", "reference", "project"],
                    "description": "Filter by item type",
                },
                "status": {
                    "type": "string",
                    "enum": ["inbox", "active", "stale", "archived", "completed", "waiting"],
                    "description": "Filter by status",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum items to return (default 50)",
                    "default": 50,
                },
                "offset": {
                    "type": "integer",
                    "description": "Offset for pagination (default 0)",
                    "default": 0,
                },
            },
        },
    ),
    Tool(
        name="complete_item",
        description="Mark an item as completed.",
        inputSchema={
            "type": "object",
            "properties": {
                "item_id": {
                    "type": "string",
                    "description": "UUID of the item to complete",
                },
                "reasoning": {
                    "type": "string",
                    "description": "Optional reason for completion",
                },
            },
            "required": ["item_id"],
        },
    ),
    Tool(
        name="update_item",
        description=(
            "Update an existing item's properties. Can modify text, title, "
            "status, due date, and other fields."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "item_id": {
                    "type": "string",
                    "description": "UUID of the item to update",
                },
                "text": {
                    "type": "string",
                    "description": "New text content",
                },
                "title": {
                    "type": "string",
                    "description": "New title",
                },
                "status": {
                    "type": "string",
                    "enum": ["inbox", "active", "stale", "archived", "completed"],
                    "description": "New status",
                },
                "due_at": {
                    "type": "string",
                    "format": "date-time",
                    "description": "New due date (ISO format)",
                },
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Replace tags with these values",
                },
            },
            "required": ["item_id"],
        },
    ),
    Tool(
        name="delete_item",
        description=(
            "Soft delete a single item by ID. Sets deleted_at timestamp. "
            "Item can be restored later with restore_item."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "item_id": {
                    "type": "string",
                    "description": "UUID of the item to delete",
                },
            },
            "required": ["item_id"],
        },
    ),
    Tool(
        name="delete_items",
        description=(
            "Soft delete multiple items. Sets deleted_at timestamp. "
            "Items can be restored later."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "item_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of UUIDs to delete",
                },
            },
            "required": ["item_ids"],
        },
    ),
    Tool(
        name="bulk_update_items",
        description=(
            "Bulk update items matching filters. Use for operations like "
            "'archive all active emails' or 'complete all tasks with tag X'. "
            "Returns count of items affected."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "filter_type": {
                    "type": "string",
                    "enum": ["task", "email", "note", "idea", "goal", "habit", "event", "person", "reference", "project"],
                    "description": "Filter by item type",
                },
                "filter_status": {
                    "type": "string",
                    "enum": ["inbox", "active", "stale", "archived", "completed", "waiting"],
                    "description": "Filter by current status",
                },
                "set_status": {
                    "type": "string",
                    "enum": ["inbox", "active", "stale", "archived", "completed", "waiting"],
                    "description": "New status to set on matching items",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum items to update (default 1000, safety cap)",
                    "default": 1000,
                },
                "reasoning": {
                    "type": "string",
                    "description": "Reason for the bulk update (logged for audit)",
                },
            },
            "required": ["set_status"],
        },
    ),
    Tool(
        name="restore_item",
        description="Restore a soft-deleted item by clearing its deleted_at timestamp.",
        inputSchema={
            "type": "object",
            "properties": {
                "item_id": {
                    "type": "string",
                    "description": "UUID of the item to restore",
                },
            },
            "required": ["item_id"],
        },
    ),
    Tool(
        name="record_correction",
        description=(
            "Record a user correction to an AI suggestion. "
            "This helps the AI learn and improve future suggestions."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "item_id": {
                    "type": "string",
                    "description": "UUID of the item that was corrected",
                },
                "original_type": {
                    "type": "string",
                    "description": "The type AI originally suggested",
                },
                "corrected_type": {
                    "type": "string",
                    "description": "The type user corrected it to",
                },
            },
            "required": ["item_id", "original_type", "corrected_type"],
        },
    ),
]


# =============================================================================
# SEARCH & CONTEXT TOOLS
# =============================================================================

SEARCH_TOOLS = [
    Tool(
        name="search",
        description=(
            "Search for items using hybrid semantic and keyword matching. "
            "Finds items by meaning, not just exact text matches. "
            "Can filter by type (task, idea, etc.) and status (active, archived, etc.)."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The search query",
                },
                "item_types": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Filter by item types: task, idea, note, habit, goal, project, reference",
                },
                "statuses": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Filter by status: inbox, active, stale, archived, completed",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of results (default 10)",
                    "default": 10,
                },
            },
            "required": ["query"],
        },
    ),
    Tool(
        name="get_context",
        description=(
            "Get current context: active goals, recent items, patterns. "
            "Useful for understanding what the user is working on before suggesting actions."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "include_goals": {
                    "type": "boolean",
                    "description": "Include active goals",
                    "default": True,
                },
                "include_recent": {
                    "type": "boolean",
                    "description": "Include recently touched items",
                    "default": True,
                },
                "recent_limit": {
                    "type": "integer",
                    "description": "How many recent items to include",
                    "default": 10,
                },
            },
        },
    ),
]


# =============================================================================
# INSIGHT TOOLS
# =============================================================================

INSIGHT_TOOLS = [
    Tool(
        name="what_now",
        description=(
            "Returns a prioritized list of what to do right now. "
            "Scores items based on goal alignment, due dates, and age. "
            "Also lists blocked or waiting items separately."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "limit": {
                    "type": "integer",
                    "description": "Number of items to return (default 5)",
                    "default": 5,
                },
            },
        },
    ),
    Tool(
        name="generate_digest",
        description=(
            "Returns a morning summary of the current state. "
            "Includes item counts, goal progress, drifting goals, and stale items."
        ),
        inputSchema={
            "type": "object",
            "properties": {},
        },
    ),
]


# =============================================================================
# GOAL TOOLS
# =============================================================================

GOAL_TOOLS = [
    Tool(
        name="create_goal",
        description=(
            "Create a new goal with structured content. "
            "Goals are high-level objectives that other items can support."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "title": {
                    "type": "string",
                    "description": "Goal title",
                },
                "description": {
                    "type": "string",
                    "description": "Detailed description of the goal",
                },
                "horizon": {
                    "type": "string",
                    "enum": ["short", "medium", "long"],
                    "description": "Time horizon: short (days/weeks), medium (months), long (years)",
                    "default": "medium",
                },
                "target_date": {
                    "type": "string",
                    "format": "date",
                    "description": "Target completion date (ISO format)",
                },
                "success_criteria": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Measurable criteria for goal completion",
                },
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Tags to apply to the goal",
                },
            },
            "required": ["title"],
        },
    ),
    Tool(
        name="list_goals",
        description="List goals with optional filters by status and time horizon.",
        inputSchema={
            "type": "object",
            "properties": {
                "status": {
                    "type": "string",
                    "enum": ["active", "completed", "archived"],
                    "description": "Filter by status (default: active)",
                },
                "horizon": {
                    "type": "string",
                    "enum": ["short", "medium", "long"],
                    "description": "Filter by time horizon",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of goals to return (default 20)",
                    "default": 20,
                },
            },
        },
    ),
    Tool(
        name="link_to_goal",
        description=(
            "Link an item (task, idea, etc.) to a goal as supporting it. "
            "This creates a 'supports' relationship for tracking goal progress."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "item_id": {
                    "type": "string",
                    "description": "UUID of the item to link",
                },
                "goal_id": {
                    "type": "string",
                    "description": "UUID of the goal to link to",
                },
                "reasoning": {
                    "type": "string",
                    "description": "Why this item supports the goal",
                },
            },
            "required": ["item_id", "goal_id"],
        },
    ),
    Tool(
        name="assess_goal",
        description=(
            "Record a progress assessment for a goal. "
            "Tracks progress percentage, notes, and blockers over time."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "goal_id": {
                    "type": "string",
                    "description": "UUID of the goal to assess",
                },
                "progress": {
                    "type": "integer",
                    "minimum": 0,
                    "maximum": 100,
                    "description": "Progress percentage (0-100)",
                },
                "notes": {
                    "type": "string",
                    "description": "Assessment notes",
                },
                "blockers": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Current blockers preventing progress",
                },
            },
            "required": ["goal_id", "progress"],
        },
    ),
    Tool(
        name="update_goal",
        description="Update a goal's properties (title, description, horizon, etc.).",
        inputSchema={
            "type": "object",
            "properties": {
                "goal_id": {
                    "type": "string",
                    "description": "UUID of the goal to update",
                },
                "title": {
                    "type": "string",
                    "description": "New title",
                },
                "description": {
                    "type": "string",
                    "description": "New description",
                },
                "horizon": {
                    "type": "string",
                    "enum": ["short", "medium", "long"],
                    "description": "New time horizon",
                },
                "target_date": {
                    "type": "string",
                    "format": "date",
                    "description": "New target date (ISO format)",
                },
                "success_criteria": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "New success criteria",
                },
                "status": {
                    "type": "string",
                    "enum": ["active", "completed", "archived"],
                    "description": "New status",
                },
            },
            "required": ["goal_id"],
        },
    ),
]


# =============================================================================
# TAG TOOLS
# =============================================================================

TAG_TOOLS = [
    Tool(
        name="add_tags",
        description=(
            "Add tags to an item using the normalized tag system. "
            "Creates tags if they don't exist."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "item_id": {
                    "type": "string",
                    "description": "UUID of the item to tag",
                },
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of tag names to add",
                },
            },
            "required": ["item_id", "tags"],
        },
    ),
    Tool(
        name="remove_tag",
        description="Remove a tag from an item.",
        inputSchema={
            "type": "object",
            "properties": {
                "item_id": {
                    "type": "string",
                    "description": "UUID of the item",
                },
                "tag": {
                    "type": "string",
                    "description": "Tag name to remove",
                },
            },
            "required": ["item_id", "tag"],
        },
    ),
]


# =============================================================================
# GOOGLE INTEGRATION TOOLS
# =============================================================================

INTEGRATION_TOOLS = [
    Tool(
        name="connect_google",
        description=(
            "Connect to Google services (Calendar, Gmail, Contacts). "
            "Returns a URL for the user to visit to authorize access."
        ),
        inputSchema={
            "type": "object",
            "properties": {},
        },
    ),
    Tool(
        name="sync_calendar",
        description=(
            "Sync Google Calendar events to Jomni as EVENT items. "
            "Requires Google account to be connected first via connect_google."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "days_past": {
                    "type": "integer",
                    "description": "How many days in the past to sync (default: 30)",
                },
                "days_future": {
                    "type": "integer",
                    "description": "How many days in the future to sync (default: 90)",
                },
            },
        },
    ),
    Tool(
        name="sync_gmail",
        description=(
            "Sync emails from Gmail to Jomni. Fetches messages and creates "
            "item entries with type='email' for semantic search and AI triage."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "labels": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Gmail labels to sync (default: INBOX)",
                },
                "max_results": {
                    "type": "integer",
                    "description": "Maximum emails to fetch (default: 100)",
                },
                "full_sync": {
                    "type": "boolean",
                    "description": "Force full sync instead of incremental",
                },
            },
        },
    ),
    Tool(
        name="list_emails",
        description="List synced emails from the database with optional filters.",
        inputSchema={
            "type": "object",
            "properties": {
                "limit": {
                    "type": "integer",
                    "description": "Maximum emails to return (default: 20)",
                },
                "unread_only": {
                    "type": "boolean",
                    "description": "Only show unread emails",
                },
                "label": {
                    "type": "string",
                    "description": "Filter by Gmail label",
                },
            },
        },
    ),
    Tool(
        name="draft_reply",
        description="Create a draft reply to an email. Does not send.",
        inputSchema={
            "type": "object",
            "properties": {
                "item_id": {
                    "type": "string",
                    "description": "UUID of the email item to reply to",
                },
                "body": {
                    "type": "string",
                    "description": "Reply text content",
                },
                "include_quote": {
                    "type": "boolean",
                    "description": "Include original email in reply (default: true)",
                },
            },
            "required": ["item_id", "body"],
        },
    ),
    Tool(
        name="send_reply",
        description="Send a reply to an email immediately.",
        inputSchema={
            "type": "object",
            "properties": {
                "item_id": {
                    "type": "string",
                    "description": "UUID of the email item to reply to",
                },
                "body": {
                    "type": "string",
                    "description": "Reply text content",
                },
            },
            "required": ["item_id", "body"],
        },
    ),
    Tool(
        name="archive_email",
        description="Archive an email (remove from INBOX in Gmail).",
        inputSchema={
            "type": "object",
            "properties": {
                "item_id": {
                    "type": "string",
                    "description": "UUID of the email item to archive",
                },
            },
            "required": ["item_id"],
        },
    ),
    Tool(
        name="sync_contacts",
        description=(
            "Sync contacts from Google Contacts to Jomni's people table. "
            "Creates name embeddings for semantic search."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "full_sync": {
                    "type": "boolean",
                    "description": "Force full sync instead of incremental",
                },
            },
        },
    ),
]


# =============================================================================
# PEOPLE TOOLS
# =============================================================================

PEOPLE_TOOLS = [
    Tool(
        name="list_people",
        description="List people from the database, optionally sorted by importance.",
        inputSchema={
            "type": "object",
            "properties": {
                "limit": {
                    "type": "integer",
                    "description": "Maximum people to return (default: 20)",
                },
                "sort_by_importance": {
                    "type": "boolean",
                    "description": "Sort by importance descending",
                },
            },
        },
    ),
    Tool(
        name="search_people",
        description="Semantic search for people by name, role, or organization.",
        inputSchema={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query (e.g., 'engineers at Google')",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum results (default: 10)",
                },
            },
            "required": ["query"],
        },
    ),
    Tool(
        name="create_person",
        description="Create a new person in the database.",
        inputSchema={
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "Person's name",
                },
                "email": {
                    "type": "string",
                    "description": "Person's email address",
                },
                "importance": {
                    "type": "integer",
                    "description": "Importance score (default: 0)",
                },
            },
            "required": ["name"],
        },
    ),
    Tool(
        name="get_person",
        description="Get a person by ID.",
        inputSchema={
            "type": "object",
            "properties": {
                "person_id": {
                    "type": "string",
                    "description": "UUID of the person",
                },
            },
            "required": ["person_id"],
        },
    ),
    Tool(
        name="set_importance",
        description="Set the importance level of a person.",
        inputSchema={
            "type": "object",
            "properties": {
                "person_id": {
                    "type": "string",
                    "description": "UUID of the person",
                },
                "importance": {
                    "type": "integer",
                    "description": "New importance score",
                },
            },
            "required": ["person_id", "importance"],
        },
    ),
    Tool(
        name="delegate_item",
        description="Delegate an item to a person and track for follow-up.",
        inputSchema={
            "type": "object",
            "properties": {
                "item_id": {
                    "type": "string",
                    "description": "UUID of the item to delegate",
                },
                "person_id": {
                    "type": "string",
                    "description": "UUID of the person to delegate to",
                },
                "due_at": {
                    "type": "string",
                    "format": "date-time",
                    "description": "When the delegation is due (ISO format)",
                },
            },
            "required": ["item_id", "person_id"],
        },
    ),
    Tool(
        name="list_delegations",
        description="List items delegated to others.",
        inputSchema={
            "type": "object",
            "properties": {
                "status": {
                    "type": "string",
                    "enum": ["pending", "completed", "all"],
                    "description": "Filter by delegation status",
                },
            },
        },
    ),
    Tool(
        name="complete_delegation",
        description="Mark a delegated item as completed.",
        inputSchema={
            "type": "object",
            "properties": {
                "item_id": {
                    "type": "string",
                    "description": "UUID of the delegated item",
                },
            },
            "required": ["item_id"],
        },
    ),
]


# =============================================================================
# RECURRING/HABIT TOOLS
# =============================================================================

RECURRING_TOOLS = [
    Tool(
        name="create_recurring",
        description="Create a recurring item (habit, routine).",
        inputSchema={
            "type": "object",
            "properties": {
                "title": {
                    "type": "string",
                    "description": "Title of the recurring item",
                },
                "frequency": {
                    "type": "string",
                    "enum": ["daily", "weekly", "monthly"],
                    "description": "How often it recurs",
                },
            },
            "required": ["title", "frequency"],
        },
    ),
    Tool(
        name="list_habits",
        description="List recurring habits/items.",
        inputSchema={
            "type": "object",
            "properties": {
                "limit": {
                    "type": "integer",
                    "description": "Maximum to return",
                },
            },
        },
    ),
    Tool(
        name="complete_recurring",
        description="Complete today's instance of a recurring item.",
        inputSchema={
            "type": "object",
            "properties": {
                "item_id": {
                    "type": "string",
                    "description": "UUID of the recurring item",
                },
            },
            "required": ["item_id"],
        },
    ),
]


# =============================================================================
# SCHEDULER TOOLS
# =============================================================================

SCHEDULER_TOOLS = [
    Tool(
        name="list_scheduled_jobs",
        description="List all scheduled background jobs and their status.",
        inputSchema={
            "type": "object",
            "properties": {},
        },
    ),
    Tool(
        name="run_job_now",
        description="Manually trigger a scheduled job immediately.",
        inputSchema={
            "type": "object",
            "properties": {
                "job_id": {
                    "type": "string",
                    "description": "ID of the job to run (e.g., sync_gmail, sync_calendar)",
                },
            },
            "required": ["job_id"],
        },
    ),
    Tool(
        name="list_job_history",
        description="List recent job execution history.",
        inputSchema={
            "type": "object",
            "properties": {
                "limit": {
                    "type": "integer",
                    "description": "Maximum history items to return",
                },
            },
        },
    ),
]


# =============================================================================
# EXPORT ALL TOOLS
# =============================================================================

ALL_TOOLS: list[Tool] = (
    CAPTURE_TOOLS
    + ITEM_TOOLS
    + SEARCH_TOOLS
    + INSIGHT_TOOLS
    + GOAL_TOOLS
    + TAG_TOOLS
    + INTEGRATION_TOOLS
    + PEOPLE_TOOLS
    + RECURRING_TOOLS
    + SCHEDULER_TOOLS
)
