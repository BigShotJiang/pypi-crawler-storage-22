"""
Handler registry for MCP tools.

Maps tool names to their handler functions imported from the main server.
This enables the cleaner dispatch pattern while keeping handler logic in one place.

NOTE: Handler implementations remain in server.py for now.
This file provides the registry interface that server.py uses for dispatch.
A future refactor can move handlers to individual modules.
"""

from typing import Any, Callable, Awaitable

# Type for handler functions
HandlerFunc = Callable[..., Awaitable[dict[str, Any]]]


# Handler registry - populated by server.py at import time
# This allows the modular structure without copying 1500 lines of handler code
HANDLERS: dict[str, HandlerFunc] = {}


def register_handler(name: str, handler: HandlerFunc) -> HandlerFunc:
    """Decorator to register a handler function."""
    HANDLERS[name] = handler
    return handler


def get_handler(name: str) -> HandlerFunc | None:
    """Get a handler by tool name."""
    return HANDLERS.get(name)
