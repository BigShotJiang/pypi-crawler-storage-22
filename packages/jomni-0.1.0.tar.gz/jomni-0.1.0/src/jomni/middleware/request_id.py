"""
Request ID Middleware for request tracing and correlation.

Generates a unique ID for each request, making it possible to trace
a single request across all logs, services, and Sentry reports.

Usage in logs:
    from jomni.middleware.request_id import get_request_id
    logger.info(f"[{get_request_id()}] Processing item")

The middleware:
- Uses incoming X-Request-ID header if present (for distributed tracing)
- Generates UUID if no header present
- Adds X-Request-ID to response headers
- Stores request ID in a ContextVar for thread-safe access
"""

from contextvars import ContextVar
from uuid import uuid4

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response


# ContextVar for thread-safe request ID storage across async contexts
request_id_ctx: ContextVar[str] = ContextVar("request_id", default="")


class RequestIDMiddleware(BaseHTTPMiddleware):
    """
    Middleware that assigns/propagates request IDs.
    
    If the incoming request has an X-Request-ID header, we use it
    (for distributed tracing across services). Otherwise, we generate
    a new UUID.
    
    The request ID is:
    1. Stored in a ContextVar for access anywhere in the request lifecycle
    2. Added to the response X-Request-ID header
    """
    
    async def dispatch(self, request: Request, call_next) -> Response:
        # Get existing request ID or generate new one
        request_id = request.headers.get("X-Request-ID")
        if not request_id:
            request_id = str(uuid4())
        
        # Store in context for access throughout request handling
        request_id_ctx.set(request_id)
        
        # Process request
        response = await call_next(request)
        
        # Add request ID to response headers
        response.headers["X-Request-ID"] = request_id
        
        return response


def get_request_id() -> str:
    """
    Get the current request ID.
    
    Returns empty string if called outside of a request context.
    Safe to call from anywhere in async code during request handling.
    """
    return request_id_ctx.get()
