"""
Jomni domain models.

Core principle: Everything is an Item. 
Types (task, idea, note, etc.) are classification labels stored in item_type,
not separate Python classes. This keeps the model stable while allowing
infinite type expansion through the content JSONB field.
"""

from datetime import datetime, timezone
from enum import Enum
from typing import Any, Literal
from uuid import UUID, uuid4

from pydantic import BaseModel, Field, field_validator


# Timezone-aware UTC datetime factory (avoids circular import with utils.datetime)
def utc_now() -> datetime:
    """Get current time as timezone-aware UTC datetime."""
    return datetime.now(timezone.utc)


# =============================================================================
# ENUMS
# =============================================================================

class ItemType(str, Enum):
    """
    Classification of items. This list can grow over time.
    New types don't require schema changes—just add to this enum
    and handle in application logic.
    """
    CAPTURE = "capture"      # Raw input, not yet classified
    TASK = "task"            # Something to do
    IDEA = "idea"            # Something to explore
    NOTE = "note"            # Reference information
    HABIT = "habit"          # Recurring behavior to track
    GOAL = "goal"            # Desired outcome
    PROJECT = "project"      # Container for related items
    REFERENCE = "reference"  # Static information to store
    EVENT = "event"          # Calendar event
    EMAIL = "email"          # Email message from Gmail
    PERSON = "person"        # A person/contact


class ItemStatus(str, Enum):
    """
    Lifecycle status of an item.
    """
    INBOX = "inbox"                  # Awaiting triage
    PENDING_REVIEW = "pending_review"  # AI failed, needs human triage
    ACTIVE = "active"                # Currently relevant
    WAITING = "waiting"              # Waiting on someone (delegation)
    STALE = "stale"                  # Untouched, fading
    ARCHIVED = "archived"            # Done or dismissed
    COMPLETED = "completed"          # Successfully finished (for tasks/habits)
    DELETED = "deleted"              # Soft-deleted (has deleted_at timestamp)


class ActorType(str, Enum):
    """
    Who performed an action.
    """
    HUMAN = "human"
    AI = "ai"
    SYSTEM = "system"


class RelationType(str, Enum):
    """
    Types of relationships between items.
    """
    PARENT = "parent"          # Hierarchical containment
    RELATED = "related"        # Loose topical connection
    BLOCKS = "blocks"          # Dependency: source blocks target
    SUPPORTS = "supports"      # Goal alignment: source supports target
    DERIVED_FROM = "derived_from"  # Origin tracking


# =============================================================================
# CONTENT SCHEMAS
# =============================================================================
# These define the expected structure inside the `content` JSONB field
# for different item types. They're documentation + validation, not storage.

class TaskContent(BaseModel):
    """Content structure for task items."""
    text: str
    title: str | None = None
    due: datetime | None = None
    scheduled: datetime | None = None
    priority: Literal[1, 2, 3, 4] | None = None  # 1 = highest
    tags: list[str] = Field(default_factory=list)
    checklist: list[dict[str, Any]] | None = None


class IdeaContent(BaseModel):
    """Content structure for idea items."""
    text: str
    title: str | None = None
    tags: list[str] = Field(default_factory=list)
    questions: list[str] = Field(default_factory=list)  # What to explore
    related_to: list[str] = Field(default_factory=list)  # Free-text references


class NoteContent(BaseModel):
    """Content structure for note/reference items."""
    text: str
    title: str | None = None
    tags: list[str] = Field(default_factory=list)
    source: str | None = None  # Where this came from


# =============================================================================
# CORE MODELS
# =============================================================================

class ItemBase(BaseModel):
    """
    Base fields for creating/updating items.
    Does not include server-generated fields like id, created_at.
    """
    item_type: ItemType = ItemType.CAPTURE
    status: ItemStatus = ItemStatus.INBOX
    parent_id: UUID | None = None
    content: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)


class ItemCreate(ItemBase):
    """
    Schema for creating a new item.
    Inherits all base fields, can add creation-specific validation.
    """
    pass


class ItemUpdate(BaseModel):
    """
    Schema for updating an item.
    All fields optional—only provided fields are updated.
    """
    item_type: ItemType | None = None
    status: ItemStatus | None = None
    parent_id: UUID | None = None
    content: dict[str, Any] | None = None
    metadata: dict[str, Any] | None = None


class Item(ItemBase):
    """
    Complete item as stored in database.
    Includes all server-generated fields.
    """
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=utc_now)
    updated_at: datetime = Field(default_factory=utc_now)
    schema_version: int = 1

    class Config:
        from_attributes = True  # Enable ORM mode for SQLAlchemy


# =============================================================================
# EVENT MODELS
# =============================================================================

class EventBase(BaseModel):
    """Base fields for an event."""
    item_id: UUID
    action: str
    changes: dict[str, Any] = Field(default_factory=dict)
    actor_type: ActorType
    actor_id: str | None = None
    session_id: UUID | None = None
    reasoning: str | None = None
    confidence: float | None = Field(None, ge=0.0, le=1.0)


class EventCreate(EventBase):
    """Schema for creating an event."""
    pass


class Event(EventBase):
    """Complete event as stored in database."""
    id: int
    occurred_at: datetime = Field(default_factory=utc_now)

    class Config:
        from_attributes = True


# =============================================================================
# EMBEDDING MODELS
# =============================================================================

class EmbeddingCreate(BaseModel):
    """Schema for creating an embedding."""
    item_id: UUID
    model_name: str
    model_version: str
    dimensions: int
    embedding: list[float]
    source_hash: str


class Embedding(EmbeddingCreate):
    """Complete embedding as stored in database."""
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=utc_now)

    class Config:
        from_attributes = True
    
    @field_validator('embedding', mode='before')
    @classmethod
    def parse_embedding(cls, v):
        """Parse embedding from pgvector string format if needed."""
        if isinstance(v, str):
            # pgvector returns strings like "[-0.038,0.012,...]"
            import json
            return json.loads(v)
        return v

# =============================================================================
# RELATION MODELS
# =============================================================================

class RelationCreate(BaseModel):
    """Schema for creating a relation."""
    source_id: UUID
    target_id: UUID
    relation_type: RelationType
    metadata: dict[str, Any] = Field(default_factory=dict)


class Relation(RelationCreate):
    """Complete relation as stored in database."""
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=utc_now)

    class Config:
        from_attributes = True


# =============================================================================
# AI TRIAGE MODELS
# =============================================================================

class TriageRequest(BaseModel):
    """Request to triage a capture."""
    # LINUS-D05: Limit input size to prevent AI credit burn attacks
    text: str = Field(..., max_length=50000)  # 50KB max
    context: dict[str, Any] = Field(default_factory=dict)  # Optional hints


class TriageSuggestion(BaseModel):
    """AI suggestion for how to classify a capture."""
    item_type: ItemType
    confidence: float = Field(ge=0.0, le=1.0)
    suggested_parent: UUID | None = None
    suggested_tags: list[str] = Field(default_factory=list)
    reasoning: str
    alternatives: list[dict[str, Any]] = Field(default_factory=list)


class TriageResponse(BaseModel):
    """Complete triage response."""
    suggestion: TriageSuggestion
    auto_accepted: bool  # True if confidence exceeded auto-accept threshold
    item: Item | None = None  # The created item if auto-accepted


# =============================================================================
# SEARCH MODELS
# =============================================================================

class SearchRequest(BaseModel):
    """Request to search items."""
    # LINUS-D05: Limit query size to prevent abuse
    query: str = Field(..., max_length=10000)  # 10KB max
    item_types: list[ItemType] | None = None
    statuses: list[ItemStatus] | None = None
    limit: int = Field(default=20, le=100)
    semantic: bool = True  # Use vector similarity
    keyword: bool = True   # Use keyword matching


class SearchResult(BaseModel):
    """A single search result."""
    item: Item
    score: float  # Combined relevance score
    highlights: dict[str, str] = Field(default_factory=dict)  # Matched snippets


class SearchResponse(BaseModel):
    """Complete search response."""
    results: list[SearchResult]
    total: int
    query: str


# =============================================================================
# SERVICE MODELS (OAuth)
# =============================================================================

class Service(BaseModel):
    """A connected external service (e.g. 'google')."""
    name: str
    is_connected: bool = False
    connected_at: datetime | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

class ServiceCredential(BaseModel):
    """
    Encrypted credentials for a service.
    Note: Tokens are stored ENCRYPTED. Decrypt before use.
    """
    service_name: str
    access_token: str  # Encrypted
    refresh_token: str | None = None  # Encrypted
    expires_at: datetime | None = None
    updated_at: datetime = Field(default_factory=utc_now)


# =============================================================================
# CHAT SESSION MODELS
# =============================================================================

class SessionMode(str, Enum):
    """Chat session modes."""
    PERSISTENT = "persistent"  # Messages stored, memory active
    EPHEMERAL = "ephemeral"    # Messages not stored, no memory


class ChatSessionCreate(BaseModel):
    """Schema for creating a chat session."""
    mode: SessionMode = SessionMode.PERSISTENT
    metadata: dict[str, Any] = Field(default_factory=dict)


class ChatSessionUpdate(BaseModel):
    """Schema for updating a chat session."""
    mode: SessionMode | None = None
    summary: str | None = None
    inference_complete: bool | None = None
    metadata: dict[str, Any] | None = None


class ChatSession(BaseModel):
    """Complete chat session as stored in database."""
    id: UUID = Field(default_factory=uuid4)
    mode: SessionMode = SessionMode.PERSISTENT
    created_at: datetime = Field(default_factory=utc_now)
    updated_at: datetime = Field(default_factory=utc_now)
    last_activity: datetime = Field(default_factory=utc_now)
    summary: str | None = None
    inference_complete: bool = False
    metadata: dict[str, Any] = Field(default_factory=dict)

    class Config:
        from_attributes = True


class MessageRole(str, Enum):
    """Role of a chat message."""
    USER = "user"
    ASSISTANT = "assistant"
    TOOL_USE = "tool_use"
    TOOL_RESULT = "tool_result"


class ChatMessageCreate(BaseModel):
    """Schema for creating a chat message."""
    session_id: UUID
    role: MessageRole
    content: dict[str, Any]  # Structured content (text, tool calls, etc.)
    linked_item_ids: list[UUID] = Field(default_factory=list)


class ChatMessage(ChatMessageCreate):
    """Complete chat message as stored in database."""
    id: UUID = Field(default_factory=uuid4)
    embedding_id: UUID | None = None  # Reference to embeddings table
    created_at: datetime = Field(default_factory=utc_now)

    class Config:
        from_attributes = True


# =============================================================================
# MEMORY MODELS
# =============================================================================

class MemoryType(str, Enum):
    """Types of memories."""
    EXPLICIT = "explicit"  # User-created ("remember X")
    IMPLICIT = "implicit"  # Claude-inferred at end of session


class Memory(BaseModel):
    """A memory item (explicit or implicit)."""
    id: UUID
    memory_type: MemoryType
    content: str
    confidence: float | None = None  # For implicit memories
    source_session_id: UUID | None = None  # Session that created this
    evidence: str | None = None  # Supporting reasoning
    created_at: datetime
