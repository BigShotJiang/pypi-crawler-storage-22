"""
Jomni background scheduler.

WHY THIS EXISTS:
Automated syncs and maintenance tasks need to run on schedules:
- Gmail sync every 5 minutes (near real-time inbox)
- Calendar sync every 15 minutes (event updates)
- Contacts sync daily (people rarely change)
- Daily digest at 6 AM (morning briefing)
- Stale item checks daily (cleanup)
- Recurring item creation at midnight

Uses APScheduler with AsyncIOScheduler for non-blocking execution.
"""

from jomni.scheduler.jobs import scheduler, start_scheduler, stop_scheduler
from jomni.scheduler.context import JobContext, create_test_context

__all__ = [
    "scheduler",
    "start_scheduler",
    "stop_scheduler",
    "JobContext",
    "create_test_context",
]

