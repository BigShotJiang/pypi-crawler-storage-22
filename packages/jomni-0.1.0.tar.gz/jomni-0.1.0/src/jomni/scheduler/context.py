"""
Job Context for Scheduler Dependency Injection.

WHY THIS EXISTS:
Scheduler jobs often need database access, AI providers, and logging.
Instead of importing these as global singletons inside each job function,
we inject them via a context object. This makes jobs:

1. Testable - Inject mock dependencies
2. Explicit - Clear what each job needs
3. Decoupled - Jobs don't know about DI container

USAGE:
    async def job_sync_gmail(ctx: JobContext) -> dict:
        emails = await ctx.db.list_items(item_type=ItemType.EMAIL)
        ...
"""

from dataclasses import dataclass, field
from typing import Any, Protocol
from datetime import datetime

from jomni.utils.datetime import utc_now


class LoggerProtocol(Protocol):
    """Protocol for logging interface."""
    def info(self, msg: str, *args: Any, **kwargs: Any) -> None: ...
    def warning(self, msg: str, *args: Any, **kwargs: Any) -> None: ...
    def error(self, msg: str, *args: Any, **kwargs: Any) -> None: ...
    def debug(self, msg: str, *args: Any, **kwargs: Any) -> None: ...


@dataclass
class JobContext:
    """
    Context object passed to scheduled jobs.
    
    Contains all dependencies a job might need:
    - Database access
    - AI provider (optional)
    - Logger
    - Job metadata
    
    Example:
        ctx = JobContext.create("sync_gmail")
        result = await job_sync_gmail(ctx)
        await ctx.log_result(result)
    """
    
    job_name: str
    started_at: datetime = field(default_factory=utc_now)
    
    # Dependencies (lazy loaded if not provided)
    _db: Any = None
    _ai: Any = None
    _logger: Any = None
    
    @property
    def db(self) -> Any:
        """Get database client, lazy loading if needed."""
        if self._db is None:
            from jomni.db import get_database
            self._db = get_database()
        return self._db
    
    @property
    def ai(self) -> Any:
        """Get AI provider, lazy loading if needed."""
        if self._ai is None:
            from jomni.ai import get_ai
            self._ai = get_ai()
        return self._ai
    
    @property
    def logger(self) -> Any:
        """Get logger for this job."""
        if self._logger is None:
            import logging
            self._logger = logging.getLogger(f"jomni.scheduler.{self.job_name}")
        return self._logger
    
    @classmethod
    def create(
        cls,
        job_name: str,
        db: Any = None,
        ai: Any = None,
        logger: Any = None,
    ) -> "JobContext":
        """
        Factory method to create a job context.
        
        Args:
            job_name: Name of the job (for logging)
            db: Optional database client (uses global if not provided)
            ai: Optional AI provider (uses global if not provided)
            logger: Optional logger (creates one if not provided)
        """
        return cls(
            job_name=job_name,
            _db=db,
            _ai=ai,
            _logger=logger,
        )
    
    async def log_result(
        self,
        status: str,
        result: dict | None = None,
        error: str | None = None,
    ) -> None:
        """
        Log job execution result to database.
        
        Args:
            status: "success" or "error"
            result: Optional result data
            error: Optional error message
        """
        try:
            self.db.client.table("agent_actions").insert({
                "action_type": "scheduled_job",
                "action_name": self.job_name,
                "status": status,
                "result": result,
                "error_message": error,
                "created_at": utc_now().isoformat(),
                "duration_ms": int((utc_now() - self.started_at).total_seconds() * 1000),
            }).execute()
        except Exception as e:
            self.logger.warning(f"Failed to log job result: {e}")
    
    def info(self, msg: str) -> None:
        """Log info message."""
        self.logger.info(f"[{self.job_name}] {msg}")
    
    def error(self, msg: str) -> None:
        """Log error message."""
        self.logger.error(f"[{self.job_name}] {msg}")
    
    def elapsed_ms(self) -> int:
        """Get elapsed time since job started."""
        return int((utc_now() - self.started_at).total_seconds() * 1000)


# =============================================================================
# MOCK CONTEXT FOR TESTING
# =============================================================================

def create_test_context(
    job_name: str = "test_job",
    mock_db: Any = None,
    mock_ai: Any = None,
) -> JobContext:
    """
    Create a JobContext with mock dependencies for testing.
    
    Example:
        ctx = create_test_context("sync_gmail", mock_db=MagicMock())
        result = await job_sync_gmail(ctx)
        assert result["synced"] == 5
    """
    from unittest.mock import MagicMock
    import logging
    
    return JobContext(
        job_name=job_name,
        _db=mock_db or MagicMock(),
        _ai=mock_ai or MagicMock(),
        _logger=logging.getLogger(f"test.{job_name}"),
    )
