"""
Background job definitions for Jomni.

WHY THIS EXISTS:
Automated syncs keep data fresh without manual intervention.
Scheduled jobs run Gmail/Calendar/Contacts sync, generate daily digest,
check for stale items, and spawn recurring item instances.

Jobs are registered with APScheduler and run in the background.
Job results are logged to agent_actions table for debugging.
"""

import logging
from datetime import datetime, timedelta
from typing import Any

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.interval import IntervalTrigger

from jomni.utils.datetime import utc_now

logger = logging.getLogger(__name__)

# Create global scheduler instance
scheduler = AsyncIOScheduler()

# Job configuration (can be overridden via environment variables)
JOB_CONFIG = {
    "sync_gmail": {
        "trigger": IntervalTrigger(minutes=5),
        "enabled": True,
        "description": "Sync emails from Gmail",
    },
    "sync_calendar": {
        "trigger": IntervalTrigger(minutes=15),
        "enabled": True,
        "description": "Sync events from Google Calendar",
    },
    "sync_contacts": {
        "trigger": CronTrigger(hour=3, minute=0),
        "enabled": True,
        "description": "Sync contacts from Google (daily at 3 AM)",
    },
    "daily_digest": {
        "trigger": CronTrigger(hour=6, minute=0),
        "enabled": True,
        "description": "Generate daily digest (6 AM)",
    },
    "check_stale": {
        "trigger": CronTrigger(hour=2, minute=0),
        "enabled": True,
        "description": "Mark stale items (2 AM)",
    },
    "check_recurring": {
        "trigger": CronTrigger(hour=0, minute=5),
        "enabled": True,
        "description": "Create due recurring instances (midnight)",
    },
    "session_inference": {
        "trigger": IntervalTrigger(minutes=5),
        "enabled": True,
        "description": "Run inference on idle sessions (every 5 min)",
    },
    "check_snoozed": {
        "trigger": IntervalTrigger(minutes=15),
        "enabled": True,
        "description": "Wake snoozed items (every 15 min)",
    },
}



async def log_job_result(
    job_name: str,
    status: str,
    result: dict | None = None,
    error: str | None = None
) -> None:
    """Log job execution to agent_actions table."""
    try:
        from jomni.db import get_database
        db = get_database()
        
        db.client.table("agent_actions").insert({
            "action_type": "scheduled_job",
            "action_name": job_name,
            "status": status,
            "result": result,
            "error_message": error,
            "created_at": utc_now().isoformat(),
        }).execute()
    except Exception as e:
        logger.warning(f"Failed to log job result: {e}")


# =============================================================================
# JOB FUNCTIONS
# =============================================================================

async def job_sync_gmail() -> None:
    """Sync Gmail messages."""
    logger.info("Running scheduled Gmail sync...")
    try:
        from jomni.db import get_database
        from jomni.integrations.google.auth import GoogleAuth
        from jomni.integrations.google.gmail import GmailSync
        
        db = get_database()
        auth = GoogleAuth(db)
        
        if not await auth.is_connected():
            logger.debug("Gmail sync skipped: not connected")
            return
        
        gmail_sync = GmailSync(db, auth)
        result = await gmail_sync.sync(max_results=50)
        
        await log_job_result("sync_gmail", "success", result)
        logger.info(f"Gmail sync complete: {result}")
        
    except Exception as e:
        logger.error(f"Gmail sync failed: {e}")
        await log_job_result("sync_gmail", "error", error=str(e))


async def job_sync_calendar() -> None:
    """Sync Google Calendar events."""
    logger.info("Running scheduled Calendar sync...")
    try:
        from jomni.db import get_database
        from jomni.integrations.google.auth import GoogleAuth
        from jomni.integrations.google.calendar import CalendarSync
        
        db = get_database()
        auth = GoogleAuth(db)
        
        if not await auth.is_connected():
            logger.debug("Calendar sync skipped: not connected")
            return
        
        calendar_sync = CalendarSync(db, auth)
        result = await calendar_sync.sync()
        
        await log_job_result("sync_calendar", "success", result)
        logger.info(f"Calendar sync complete: {result}")
        
    except Exception as e:
        logger.error(f"Calendar sync failed: {e}")
        await log_job_result("sync_calendar", "error", error=str(e))


async def job_sync_contacts() -> None:
    """Sync Google Contacts."""
    logger.info("Running scheduled Contacts sync...")
    try:
        from jomni.db import get_database
        from jomni.integrations.google.auth import GoogleAuth
        from jomni.integrations.google.contacts import ContactsSync
        
        db = get_database()
        auth = GoogleAuth(db)
        
        if not await auth.is_connected():
            logger.debug("Contacts sync skipped: not connected")
            return
        
        contacts_sync = ContactsSync(db, auth)
        result = await contacts_sync.sync()
        
        await log_job_result("sync_contacts", "success", result)
        logger.info(f"Contacts sync complete: {result}")
        
    except Exception as e:
        logger.error(f"Contacts sync failed: {e}")
        await log_job_result("sync_contacts", "error", error=str(e))


async def job_daily_digest() -> None:
    """Generate daily digest."""
    logger.info("Running daily digest generation...")
    try:
        from jomni.db import get_database
        
        db = get_database()
        stats = await db.get_digest_stats()
        
        # For now, just log. Future: push notification, email
        await log_job_result("daily_digest", "success", stats)
        logger.info(f"Daily digest generated: {stats}")
        
    except Exception as e:
        logger.error(f"Daily digest failed: {e}")
        await log_job_result("daily_digest", "error", error=str(e))


async def job_check_stale() -> None:
    """Mark items untouched for 14+ days as stale.
    
    Uses db.update_item() for each item to ensure events are logged properly.
    This is slower than bulk update but maintains full audit trail.
    """
    logger.info("Running stale item check...")
    try:
        from jomni.db import get_database
        from jomni.models import ItemStatus, ItemUpdate, ActorType
        
        db = get_database()
        stale_threshold = utc_now() - timedelta(days=14)
        
        # Get stale candidates - items that are active and haven't been updated in 14+ days
        stale_candidates = db.client.table("items").select("id, updated_at").eq(
            "status", ItemStatus.ACTIVE.value
        ).is_("deleted_at", "null").lt(
            "updated_at", stale_threshold.isoformat()
        ).limit(500).execute()
        
        stale_count = 0
        actor = (ActorType.SYSTEM, "job:check_stale")
        
        # Update each item individually to ensure events are logged
        for item_data in stale_candidates.data:
            try:
                await db.update_item(
                    item_id=item_data["id"],
                    data=ItemUpdate(status=ItemStatus.STALE),
                    actor=actor,
                    reasoning=f"Item untouched for 14+ days (last updated: {item_data['updated_at']})"
                )
                stale_count += 1
            except Exception as e:
                logger.error(f"Failed to mark item {item_data['id']} as stale: {e}")
        
        await log_job_result("check_stale", "success", {"marked_stale": stale_count})
        logger.info(f"Marked {stale_count} items as stale")
        
    except Exception as e:
        logger.error(f"Stale check failed: {e}")
        await log_job_result("check_stale", "error", error=str(e))


async def job_check_recurring() -> None:
    """Create instances of recurring items that are due.
    
    Queries recurrence_rules where next_due_at <= now() and creates
    child items based on the parent template. Updates next_due_at
    after each instance is created.
    """
    logger.info("Running recurring item check...")
    try:
        from jomni.db import get_database
        from jomni.models import ItemCreate, ItemStatus, ItemType, ActorType
        
        db = get_database()
        now = utc_now()
        
        # Find recurrence rules that need new instances
        result = db.client.table("recurrence_rules").select(
            "*, items!inner(*)"
        ).is_("paused_at", "null").execute()
        
        created_count = 0
        actor = (ActorType.SYSTEM, "job:check_recurring")
        
        for rule in result.data:
            next_due = rule.get("next_due_at")
            if not next_due or next_due > now.isoformat():
                continue
            
            parent_item = rule.get("items")
            if not parent_item:
                logger.warning(f"Recurrence rule {rule['id']} has no parent item")
                continue
            
            try:
                # Create child instance from parent template
                parent_content = parent_item.get("content", {})
                parent_metadata = parent_item.get("metadata", {})
                
                child = await db.create_item(
                    ItemCreate(
                        item_type=ItemType(parent_item["item_type"]),
                        status=ItemStatus.INBOX,
                        parent_id=parent_item["id"],
                        content={
                            **parent_content,
                            "recurring_instance": True,
                            "instance_date": now.isoformat(),
                        },
                        metadata={
                            **parent_metadata,
                            "source": "recurring",
                            "recurrence_rule_id": rule["id"],
                        },
                    ),
                    actor=actor,
                    reasoning=f"Recurring instance created from rule {rule['id']}"
                )
                created_count += 1
                logger.debug(f"Created recurring instance {child.id} from rule {rule['id']}")
                
                # Calculate and update next_due_at based on frequency
                frequency = rule.get("frequency", "daily")
                interval = rule.get("interval", 1)
                
                if frequency == "daily":
                    next_due_dt = now + timedelta(days=interval)
                elif frequency == "weekly":
                    next_due_dt = now + timedelta(weeks=interval)
                elif frequency == "monthly":
                    next_due_dt = now + timedelta(days=30 * interval)
                elif frequency == "yearly":
                    next_due_dt = now + timedelta(days=365 * interval)
                else:
                    next_due_dt = now + timedelta(days=1)
                
                db.client.table("recurrence_rules").update({
                    "next_due_at": next_due_dt.isoformat(),
                    "last_triggered_at": now.isoformat(),
                }).eq("id", rule["id"]).execute()
                
            except Exception as e:
                logger.error(f"Failed to create recurring instance for rule {rule['id']}: {e}")
        
        await log_job_result("check_recurring", "success", {"created_instances": created_count})
        if created_count > 0:
            logger.info(f"Created {created_count} recurring instances")
        
    except Exception as e:
        logger.error(f"Recurring check failed: {e}")
        await log_job_result("check_recurring", "error", error=str(e))


async def job_session_inference() -> None:
    """Run inference on idle chat sessions.
    
    Checks for sessions with no activity for 10+ minutes and runs
    end-of-session inference to extract implicit memories.
    """
    logger.info("Running session inference check...")
    try:
        from jomni.db import get_database
        from jomni.api.session_inference import check_idle_sessions_and_run_inference
        
        db = get_database()
        processed = await check_idle_sessions_and_run_inference(db, idle_minutes=10)
        
        await log_job_result("session_inference", "success", {"processed": processed})
        if processed > 0:
            logger.info(f"Session inference complete: {processed} sessions processed")
        
    except Exception as e:
        logger.error(f"Session inference failed: {e}")
        await log_job_result("session_inference", "error", error=str(e))


async def job_check_snoozed() -> None:
    """Wake items whose snooze period has expired.
    
    Queries items with metadata.snoozed_until < now() and sets their
    status back to ACTIVE.
    """
    logger.info("Running snoozed item check...")
    try:
        from jomni.db import get_database
        from jomni.models import ItemStatus, ItemUpdate, ActorType
        from dateutil.parser import parse
        from datetime import timezone
        
        db = get_database()
        now = utc_now()
        
        # Find items that might have snoozed_until set
        # We query all non-deleted items and filter in Python since
        # Supabase's JSONB querying for nested fields is limited
        result = db.client.table("items").select("id, metadata, status").eq(
            "status", ItemStatus.STALE.value  # Snoozed items are set to STALE
        ).is_("deleted_at", "null").execute()
        
        woke_count = 0
        actor = (ActorType.SYSTEM, "job:check_snoozed")
        
        for item_data in result.data:
            metadata = item_data.get("metadata") or {}
            snoozed_until_str = metadata.get("snoozed_until")
            if not snoozed_until_str:
                continue
            
            try:
                snoozed_until = parse(snoozed_until_str)
                if snoozed_until.tzinfo is None:
                    snoozed_until = snoozed_until.replace(tzinfo=timezone.utc)
                
                if snoozed_until <= now:
                    # Wake the item - remove snoozed_until and set to ACTIVE
                    new_metadata = {k: v for k, v in metadata.items() if k != "snoozed_until"}
                    
                    await db.update_item(
                        item_id=item_data["id"],
                        data=ItemUpdate(status=ItemStatus.ACTIVE, metadata=new_metadata),
                        actor=actor,
                        reasoning=f"Snooze expired at {snoozed_until_str}"
                    )
                    woke_count += 1
                    logger.debug(f"Woke snoozed item {item_data['id']}")
            except Exception as e:
                logger.error(f"Failed to wake snoozed item {item_data['id']}: {e}")
        
        await log_job_result("check_snoozed", "success", {"woke_items": woke_count})
        if woke_count > 0:
            logger.info(f"Woke {woke_count} snoozed items")
        
    except Exception as e:
        logger.error(f"Snoozed check failed: {e}")
        await log_job_result("check_snoozed", "error", error=str(e))


# =============================================================================
# SCHEDULER MANAGEMENT
# =============================================================================

def register_jobs() -> None:
    """Register all scheduled jobs."""
    job_functions = {
        "sync_gmail": job_sync_gmail,
        "sync_calendar": job_sync_calendar,
        "sync_contacts": job_sync_contacts,
        "daily_digest": job_daily_digest,
        "check_stale": job_check_stale,
        "check_recurring": job_check_recurring,
        "session_inference": job_session_inference,
        "check_snoozed": job_check_snoozed,
    }
    
    for job_name, config in JOB_CONFIG.items():
        if not config.get("enabled", True):
            continue
        
        job_func = job_functions.get(job_name)
        if not job_func:
            continue
        
        scheduler.add_job(
            job_func,
            trigger=config["trigger"],
            id=job_name,
            name=config.get("description", job_name),
            replace_existing=True,
        )
        logger.info(f"Registered job: {job_name}")


async def start_scheduler() -> None:
    """Start the scheduler with registered jobs."""
    register_jobs()
    scheduler.start()
    logger.info("Scheduler started with %d jobs", len(scheduler.get_jobs()))


async def stop_scheduler() -> None:
    """Stop the scheduler gracefully."""
    scheduler.shutdown(wait=True)
    logger.info("Scheduler stopped")


def get_job_info() -> list[dict[str, Any]]:
    """Get information about all scheduled jobs."""
    jobs = []
    for job in scheduler.get_jobs():
        jobs.append({
            "id": job.id,
            "name": job.name,
            "next_run": job.next_run_time.isoformat() if job.next_run_time else None,
            "trigger": str(job.trigger),
        })
    return jobs


async def run_job_now(job_id: str) -> dict:
    """Manually trigger a job immediately."""
    job = scheduler.get_job(job_id)
    if not job:
        return {"error": f"Job not found: {job_id}"}
    
    try:
        # Run the job function directly
        await job.func()
        return {"success": True, "job": job_id, "message": "Job executed"}
    except Exception as e:
        return {"error": str(e)}


async def get_job_history(limit: int = 20) -> list[dict]:
    """Get recent job execution history from agent_actions."""
    try:
        from jomni.db import get_database
        db = get_database()
        
        result = db.client.table("agent_actions").select("*").eq(
            "action_type", "scheduled_job"
        ).order("created_at", desc=True).limit(limit).execute()
        
        return result.data
    except Exception:
        return []
