"""
Security utilities for Jomni.
Handles encryption of sensitive data (like OAuth tokens) at rest.
"""

from cryptography.fernet import Fernet
from jomni.config import get_settings

def get_fernet() -> Fernet:
    """Get Fernet instance with current encryption key."""
    settings = get_settings()
    if not settings.encryption_key:
        raise ValueError("JOMNI_ENCRYPTION_KEY is not set. Cannot perform encryption.")
    return Fernet(settings.encryption_key.encode())

def encrypt_token(token: str) -> str:
    """Encrypt a token string."""
    if not token:
        return ""
    f = get_fernet()
    return f.encrypt(token.encode()).decode()

def decrypt_token(encrypted_token: str) -> str:
    """Decrypt a token string."""
    if not encrypted_token:
        return ""
    f = get_fernet()
    return f.decrypt(encrypted_token.encode()).decode()
