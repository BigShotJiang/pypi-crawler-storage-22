"""
Security module for Jomni.

Provides authentication, authorization, and encryption utilities.

Submodules:
- auth: API key authentication dependencies
- encryption: Token encryption for OAuth credentials (from legacy security.py)

Usage:
    from jomni.security import encrypt_token, decrypt_token  # Encryption
    from jomni.security import require_api_key               # API auth
"""

# Re-export encryption functions from the legacy module
# This maintains backward compatibility with existing imports
import sys
import os

# Import from older security.py (now renamed to encryption.py in this folder)
# For backward compat, we import from the parent directory's security.py
# and re-export here
_parent = os.path.dirname(os.path.dirname(__file__))
_legacy_security = os.path.join(_parent, "security.py")

# Since Python's import system found this folder first, we need to 
# manually load the old module. Instead, let's just move the functions here.

from cryptography.fernet import Fernet
from jomni.config import get_settings


def get_fernet() -> Fernet:
    """Get Fernet instance with current encryption key."""
    settings = get_settings()
    if not settings.encryption_key:
        raise ValueError("JOMNI_ENCRYPTION_KEY is not set. Cannot perform encryption.")
    return Fernet(settings.encryption_key.encode())


def encrypt_token(token: str) -> str:
    """Encrypt a token string."""
    if not token:
        return ""
    f = get_fernet()
    return f.encrypt(token.encode()).decode()


def decrypt_token(encrypted_token: str) -> str:
    """Decrypt a token string."""
    if not encrypted_token:
        return ""
    f = get_fernet()
    return f.decrypt(encrypted_token.encode()).decode()


# Export auth functions
from jomni.security.auth import require_api_key, optional_api_key, is_public_path

__all__ = [
    # Encryption (backward compat)
    "encrypt_token",
    "decrypt_token",
    "get_fernet",
    # Authentication (new)
    "require_api_key",
    "optional_api_key",
    "is_public_path",
]
