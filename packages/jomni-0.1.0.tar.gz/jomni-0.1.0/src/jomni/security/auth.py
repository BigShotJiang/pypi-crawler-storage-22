"""
Security middleware and authentication dependencies.

SECURITY CRITICAL: This module provides API authentication to prevent
unauthorized access to the Jomni backend.

Usage:
    from jomni.security.auth import require_api_key
    
    @app.get("/protected")
    async def protected_endpoint(api_key: str = Depends(require_api_key)):
        ...

Configuration:
    Set JOMNI_API_KEY in environment or Fly.io secrets.
    API clients must include X-API-Key header.
"""

import logging
from typing import Optional

from fastapi import HTTPException, Security, Depends
from fastapi.security import APIKeyHeader

from jomni.config import get_settings

logger = logging.getLogger(__name__)


# =============================================================================
# API KEY AUTHENTICATION
# =============================================================================

# Header-based API key (most common for API authentication)
api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


async def require_api_key(
    api_key: Optional[str] = Security(api_key_header),
) -> str:
    """
    Dependency that validates the API key from X-API-Key header.
    
    SECURITY BEHAVIOR:
    - Production (JOMNI_API_KEY set): Validates key, returns 401/403 on failure
    - Development (no key configured + debug=true): Skips validation
    - Misconfigured (no key + debug=false): Returns 500 to fail closed
    
    Returns the validated API key on success, or None in debug-skip mode.
    """
    settings = get_settings()
    
    # Check if API key is configured
    if not settings.api_key:
        if settings.debug:
            # Development mode - skip auth but don't log any key value
            # This is intentional for local development only
            return None  # type: ignore  # Safe in dev mode
        else:
            # FAIL CLOSED: Production must have API key configured
            logger.error("SECURITY: API key not configured in production!")
            raise HTTPException(
                status_code=500,
                detail="Server misconfiguration",
            )
    
    # Validate the provided key
    if not api_key:
        raise HTTPException(
            status_code=401,
            detail="Missing API key. Include X-API-Key header.",
            headers={"WWW-Authenticate": "ApiKey"},
        )
    
    if api_key != settings.api_key:
        # Don't log the attempted key value for security
        logger.warning("Invalid API key attempt")
        raise HTTPException(
            status_code=403,
            detail="Invalid API key",
        )
    
    return api_key


async def optional_api_key(
    api_key: Optional[str] = Security(api_key_header),
) -> Optional[str]:
    """
    Optional API key validation for public endpoints.
    
    Returns the API key if valid, None if not provided.
    Raises HTTPException 403 only if key is provided but invalid.
    
    Use for endpoints that work for both authenticated and anonymous users.
    """
    settings = get_settings()
    
    if not api_key:
        return None
    
    if settings.api_key and api_key != settings.api_key:
        raise HTTPException(
            status_code=403,
            detail="Invalid API key",
        )
    
    return api_key


# =============================================================================
# PUBLIC ENDPOINTS LIST
# =============================================================================

# Endpoints that should NOT require authentication
PUBLIC_PATHS = [
    "/",                    # Root info
    "/health",              # Health check
    "/docs",                # OpenAPI docs
    "/openapi.json",        # OpenAPI spec
    "/auth/google/login",   # OAuth initiation
    "/auth/google/callback",# OAuth callback
    "/tally/webhook",       # Webhook (has own signature validation)
]

def is_public_path(path: str) -> bool:
    """
    Check if a path should be publicly accessible.
    
    BUG FIX (2025-12): Previously used `any(path.startswith(p) for p in PUBLIC_PATHS)`
    which caused ALL paths to match because "/" is in PUBLIC_PATHS and every
    path starts with "/". Now "/" requires exact match.
    
    Args:
        path: The request path to check
        
    Returns:
        True if the path is in PUBLIC_PATHS and doesn't require auth
    """
    for public_path in PUBLIC_PATHS:
        if public_path == "/":
            # FIX: Root path must be exact match to avoid matching all paths
            if path == "/":
                return True
        elif path.startswith(public_path):
            return True
    return False
