"""Jomni setup module."""
