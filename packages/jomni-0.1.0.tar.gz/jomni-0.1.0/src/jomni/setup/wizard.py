#!/usr/bin/env python3
"""
Jomni Setup Wizard - Cross-platform GUI

A simple tkinter wizard to configure Jomni API keys and test the connection.
Integrates with Claude Desktop for MCP server registration.
"""

import json
import os
import sys
import threading
from pathlib import Path
from datetime import datetime

import tkinter as tk
from tkinter import ttk, messagebox

try:
    import httpx
    HAS_HTTPX = True
except ImportError:
    HAS_HTTPX = False


class JomniSetupWizard:
    """Main wizard window."""
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Jomni Setup Wizard")
        self.root.geometry("520x650")
        self.root.resizable(False, False)
        
        # Dark theme colors
        self.bg_color = "#1e1e23"
        self.fg_color = "#ffffff"
        self.input_bg = "#2d2d35"
        self.accent_color = "#4CAF50"
        self.error_color = "#ff6b6b"
        self.warning_color = "#ffd93d"
        self.muted_color = "#888888"
        
        self.root.configure(bg=self.bg_color)
        
        # Find config location
        self.config_dir = self._get_config_dir()
        self.env_path = self.config_dir / ".env"
        
        self._create_widgets()
        self._load_existing_config()
        self._center_window()
    
    def _get_config_dir(self) -> Path:
        """Get the Jomni config directory."""
        # Check for existing .jomni dir
        jomni_dir = Path.home() / ".jomni"
        if jomni_dir.exists():
            return jomni_dir
        
        # Check current directory (for development)
        cwd = Path.cwd()
        if (cwd / "backend" / "pyproject.toml").exists():
            return cwd / "backend"
        if (cwd / "pyproject.toml").exists():
            return cwd
        
        # Default to ~/.jomni
        jomni_dir.mkdir(parents=True, exist_ok=True)
        return jomni_dir
    
    def _center_window(self):
        """Center the window on screen."""
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f"{width}x{height}+{x}+{y}")
    
    def _create_widgets(self):
        """Create all UI widgets."""
        # Main container with padding
        main_frame = tk.Frame(self.root, bg=self.bg_color, padx=25, pady=20)
        main_frame.pack(fill="both", expand=True)
        
        # Title
        title = tk.Label(
            main_frame,
            text="🧠 Jomni Setup",
            font=("Segoe UI", 20, "bold"),
            bg=self.bg_color,
            fg=self.fg_color
        )
        title.pack(anchor="w")
        
        subtitle = tk.Label(
            main_frame,
            text="Configure your personal database",
            font=("Segoe UI", 10),
            bg=self.bg_color,
            fg=self.muted_color
        )
        subtitle.pack(anchor="w", pady=(0, 20))
        
        # Form fields
        fields_frame = tk.Frame(main_frame, bg=self.bg_color)
        fields_frame.pack(fill="x")
        
        # Supabase URL
        self.supabase_url = self._create_field(
            fields_frame, "Supabase URL *", 
            placeholder="https://your-project.supabase.co"
        )
        
        # Supabase Service Key
        self.supabase_key = self._create_field(
            fields_frame, "Supabase Service Key *",
            show="•"
        )
        
        # Anthropic API Key
        self.anthropic_key = self._create_field(
            fields_frame, "Anthropic API Key (for Claude)",
            show="•"
        )
        
        # OpenAI API Key
        self.openai_key = self._create_field(
            fields_frame, "OpenAI API Key (for embeddings)",
            show="•"
        )
        
        # Separator
        sep = tk.Frame(main_frame, bg="#3d3d45", height=1)
        sep.pack(fill="x", pady=15)
        
        # Claude Desktop integration checkbox
        self.register_claude_var = tk.BooleanVar(value=True)
        claude_check = tk.Checkbutton(
            main_frame,
            text="Register with Claude Desktop (MCP)",
            variable=self.register_claude_var,
            font=("Segoe UI", 10),
            bg=self.bg_color,
            fg=self.fg_color,
            activebackground=self.bg_color,
            activeforeground=self.fg_color,
            selectcolor=self.input_bg
        )
        claude_check.pack(anchor="w")
        
        claude_hint = tk.Label(
            main_frame,
            text="Allows Claude Desktop to use Jomni as a tool",
            font=("Segoe UI", 9),
            bg=self.bg_color,
            fg=self.muted_color
        )
        claude_hint.pack(anchor="w", padx=(20, 0))
        
        # Status area
        self.status_var = tk.StringVar(value="")
        self.status_label = tk.Label(
            main_frame,
            textvariable=self.status_var,
            font=("Segoe UI", 9),
            bg=self.bg_color,
            fg=self.fg_color,
            wraplength=460,
            justify="left"
        )
        self.status_label.pack(anchor="w", pady=(15, 10), fill="x")
        
        # Buttons
        button_frame = tk.Frame(main_frame, bg=self.bg_color)
        button_frame.pack(fill="x", pady=(10, 0))
        
        # Test Connection button
        self.test_btn = tk.Button(
            button_frame,
            text="Test Connection",
            font=("Segoe UI", 10),
            bg="#3d3d45",
            fg=self.fg_color,
            activebackground="#4d4d55",
            activeforeground=self.fg_color,
            relief="flat",
            padx=20,
            pady=8,
            command=self._test_connection
        )
        self.test_btn.pack(side="left")
        
        # Save button
        self.save_btn = tk.Button(
            button_frame,
            text="Save & Continue",
            font=("Segoe UI", 10, "bold"),
            bg=self.accent_color,
            fg=self.fg_color,
            activebackground="#45a049",
            activeforeground=self.fg_color,
            relief="flat",
            padx=20,
            pady=8,
            command=self._save_config
        )
        self.save_btn.pack(side="right")
        
        # Footer
        footer = tk.Label(
            main_frame,
            text=f"Config: {self.env_path}",
            font=("Segoe UI", 8),
            bg=self.bg_color,
            fg="#666666"
        )
        footer.pack(side="bottom", pady=(20, 0))
        
        links = tk.Label(
            main_frame,
            text="supabase.com | console.anthropic.com | platform.openai.com",
            font=("Segoe UI", 8),
            bg=self.bg_color,
            fg="#666666"
        )
        links.pack(side="bottom", pady=(5, 0))
    
    def _create_field(self, parent, label_text, placeholder="", show=None) -> tk.Entry:
        """Create a labeled input field."""
        frame = tk.Frame(parent, bg=self.bg_color)
        frame.pack(fill="x", pady=(0, 12))
        
        label = tk.Label(
            frame,
            text=label_text,
            font=("Segoe UI", 9),
            bg=self.bg_color,
            fg=self.fg_color
        )
        label.pack(anchor="w")
        
        entry = tk.Entry(
            frame,
            font=("Consolas", 10),
            bg=self.input_bg,
            fg=self.fg_color,
            insertbackground=self.fg_color,
            relief="flat",
            show=show
        )
        entry.pack(fill="x", ipady=6, pady=(3, 0))
        
        # Placeholder behavior
        if placeholder and not show:
            entry.insert(0, placeholder)
            entry.config(fg=self.muted_color)
            
            def on_focus_in(e):
                if entry.get() == placeholder:
                    entry.delete(0, tk.END)
                    entry.config(fg=self.fg_color)
            
            def on_focus_out(e):
                if not entry.get():
                    entry.insert(0, placeholder)
                    entry.config(fg=self.muted_color)
            
            entry.bind("<FocusIn>", on_focus_in)
            entry.bind("<FocusOut>", on_focus_out)
        
        return entry
    
    def _load_existing_config(self):
        """Load existing configuration if present."""
        if not self.env_path.exists():
            return
        
        try:
            with open(self.env_path, "r") as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    
                    if "=" not in line:
                        continue
                    
                    key, _, value = line.partition("=")
                    key = key.strip()
                    value = value.strip()
                    
                    if key == "JOMNI_SUPABASE_URL":
                        self.supabase_url.delete(0, tk.END)
                        self.supabase_url.insert(0, value)
                        self.supabase_url.config(fg=self.fg_color)
                    elif key == "JOMNI_SUPABASE_SERVICE_KEY":
                        self.supabase_key.delete(0, tk.END)
                        self.supabase_key.insert(0, value)
                    elif key == "JOMNI_ANTHROPIC_API_KEY":
                        self.anthropic_key.delete(0, tk.END)
                        self.anthropic_key.insert(0, value)
                    elif key == "JOMNI_OPENAI_API_KEY":
                        self.openai_key.delete(0, tk.END)
                        self.openai_key.insert(0, value)
            
            self._set_status("Loaded existing configuration", self.muted_color)
        except Exception as e:
            self._set_status(f"Could not load config: {e}", self.warning_color)
    
    def _set_status(self, message: str, color: str = None):
        """Update the status message."""
        self.status_var.set(message)
        self.status_label.configure(fg=color or self.fg_color)
    
    def _get_field_value(self, entry: tk.Entry, placeholder: str = "") -> str:
        """Get entry value, ignoring placeholder text."""
        value = entry.get().strip()
        if value == placeholder:
            return ""
        return value
    
    def _test_connection(self):
        """Test the Supabase connection."""
        url = self._get_field_value(self.supabase_url, "https://your-project.supabase.co")
        key = self.supabase_key.get().strip()
        
        if not url or not key:
            self._set_status("✗ Supabase URL and Service Key are required", self.error_color)
            return
        
        url = url.rstrip("/")
        self._set_status("Testing connection...", self.warning_color)
        self.root.update()
        
        def test():
            try:
                if HAS_HTTPX:
                    import httpx
                    response = httpx.get(
                        f"{url}/rest/v1/",
                        headers={"apikey": key},
                        timeout=10
                    )
                    if response.status_code < 400:
                        self._set_status("✓ Connected to Supabase successfully!", self.accent_color)
                    else:
                        self._set_status(f"✗ Connection failed: HTTP {response.status_code}", self.error_color)
                else:
                    import urllib.request
                    req = urllib.request.Request(
                        f"{url}/rest/v1/",
                        headers={"apikey": key}
                    )
                    urllib.request.urlopen(req, timeout=10)
                    self._set_status("✓ Connected to Supabase successfully!", self.accent_color)
            except Exception as e:
                self._set_status(f"✗ Connection failed: {str(e)[:100]}", self.error_color)
        
        threading.Thread(target=test, daemon=True).start()
    
    def _save_config(self):
        """Save the configuration to .env file."""
        url = self._get_field_value(self.supabase_url, "https://your-project.supabase.co")
        key = self.supabase_key.get().strip()
        anthropic = self.anthropic_key.get().strip()
        openai = self.openai_key.get().strip()
        
        # Validate
        if not url or not key:
            self._set_status("✗ Supabase URL and Service Key are required", self.error_color)
            return
        
        if not anthropic and not openai:
            self._set_status("✗ At least one AI provider key is required", self.error_color)
            return
        
        # Build .env content
        env_content = f"""# Jomni Configuration
# Generated by setup wizard on {datetime.now().strftime("%Y-%m-%d %H:%M")}

# Database (required)
JOMNI_SUPABASE_URL={url}
JOMNI_SUPABASE_SERVICE_KEY={key}

# AI Providers
JOMNI_ANTHROPIC_API_KEY={anthropic}
JOMNI_OPENAI_API_KEY={openai}

# Server
JOMNI_DEBUG=true
JOMNI_HOST=127.0.0.1
JOMNI_PORT=8000
"""
        
        # Write file
        try:
            self.config_dir.mkdir(parents=True, exist_ok=True)
            self.env_path.write_text(env_content, encoding="utf-8")
            self._set_status("✓ Configuration saved!", self.accent_color)
        except Exception as e:
            self._set_status(f"✗ Failed to write .env: {e}", self.error_color)
            return
        
        # Register with Claude Desktop if requested
        if self.register_claude_var.get():
            try:
                self._register_claude_desktop()
            except Exception as e:
                self._set_status(f"✓ Config saved, but Claude registration failed: {e}", self.warning_color)
                return
        
        # Show success dialog
        messagebox.showinfo(
            "Setup Complete",
            f"Configuration saved to:\n{self.env_path}\n\n"
            "Start Jomni with:\n"
            "  jomni serve\n\n"
            "Or start the MCP server for Claude:\n"
            "  jomni mcp"
        )
        
        self.root.quit()
    
    def _register_claude_desktop(self):
        """Register Jomni with Claude Desktop."""
        # Find Claude Desktop config
        if sys.platform == "win32":
            config_dir = Path(os.environ.get("APPDATA", "")) / "Claude"
        elif sys.platform == "darwin":
            config_dir = Path.home() / "Library" / "Application Support" / "Claude"
        else:
            config_dir = Path.home() / ".config" / "claude"
        
        config_file = config_dir / "claude_desktop_config.json"
        
        # Load existing config or create new
        if config_file.exists():
            with open(config_file, "r") as f:
                config = json.load(f)
        else:
            config_dir.mkdir(parents=True, exist_ok=True)
            config = {}
        
        # Add/update jomni server
        if "mcpServers" not in config:
            config["mcpServers"] = {}
        
        # Read env vars for the MCP config
        env_vars = {}
        if self.env_path.exists():
            with open(self.env_path, "r") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        k, _, v = line.partition("=")
                        if k.startswith("JOMNI_"):
                            env_vars[k] = v
        
        jomni_config = {
            "command": "jomni",
            "args": ["mcp"],
        }
        
        if env_vars:
            jomni_config["env"] = env_vars
        
        config["mcpServers"]["jomni"] = jomni_config
        
        # Write config
        with open(config_file, "w") as f:
            json.dump(config, f, indent=2)
    
    def run(self):
        """Start the wizard."""
        self.root.mainloop()


def main():
    """Entry point for the setup wizard."""
    wizard = JomniSetupWizard()
    wizard.run()


if __name__ == "__main__":
    main()
