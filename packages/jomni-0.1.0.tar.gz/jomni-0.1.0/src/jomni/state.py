"""
Application State Management.

WHY THIS EXISTS:
Global singletons are problematic:
- Hard to test (can't inject mocks)
- Hidden dependencies
- Thread safety concerns

This module provides app.state-compatible state management that:
1. Works with FastAPI's dependency injection
2. Allows easy mocking in tests
3. Makes dependencies explicit

USAGE:
    # In main.py
    from jomni.state import AppState
    app.state.jomni = AppState.create()
    
    # In endpoints (via Depends)
    def get_state() -> AppState:
        return request.app.state.jomni
        
    @app.get("/items")
    def list_items(state: AppState = Depends(get_state)):
        return state.db.list_items()
"""

from dataclasses import dataclass, field
from typing import Any
import logging

logger = logging.getLogger(__name__)


@dataclass
class AppState:
    """
    Application state container.
    
    Holds all shared resources that would otherwise be global singletons.
    Designed to be attached to FastAPI's app.state for dependency injection.
    """
    
    # Database
    _db: Any = None
    
    # AI Provider
    _ai: Any = None
    
    # Settings (cached)
    _settings: Any = None
    
    @property
    def db(self) -> Any:
        """Get database client, creating if needed."""
        if self._db is None:
            from jomni.db import get_database
            self._db = get_database()
        return self._db
    
    @property
    def ai(self) -> Any:
        """Get AI provider, creating if needed."""
        if self._ai is None:
            from jomni.ai import get_ai
            self._ai = get_ai()
        return self._ai
    
    @property
    def settings(self) -> Any:
        """Get application settings."""
        if self._settings is None:
            from jomni.config import get_settings
            self._settings = get_settings()
        return self._settings
    
    @classmethod
    def create(
        cls,
        db: Any = None,
        ai: Any = None,
        settings: Any = None,
    ) -> "AppState":
        """
        Create application state with optional dependency injection.
        
        Args:
            db: Optional database client (for testing)
            ai: Optional AI provider (for testing)
            settings: Optional settings (for testing)
        """
        return cls(_db=db, _ai=ai, _settings=settings)
    
    def reset(self) -> None:
        """Reset all cached dependencies. Useful for testing."""
        self._db = None
        self._ai = None
        self._settings = None


# =============================================================================
# FASTAPI DEPENDENCY
# =============================================================================

_global_state: AppState | None = None


def get_app_state() -> AppState:
    """
    Get the global application state.
    
    This is a fallback for when FastAPI request context isn't available
    (e.g., in background jobs). Prefer using request.app.state.jomni when
    in a request context.
    """
    global _global_state
    if _global_state is None:
        _global_state = AppState.create()
    return _global_state


def set_app_state(state: AppState) -> None:
    """
    Set the global application state.
    
    Call this in main.py lifespan to override the default state.
    Useful for setting up test fixtures.
    """
    global _global_state
    _global_state = state


def reset_app_state() -> None:
    """Reset global state. Use in test teardown."""
    global _global_state
    _global_state = None


# =============================================================================
# TEST UTILITIES
# =============================================================================

def create_test_state(
    mock_db: Any = None,
    mock_ai: Any = None,
) -> AppState:
    """
    Create an AppState with mock dependencies for testing.
    
    Example:
        state = create_test_state(mock_db=MagicMock())
        set_app_state(state)
        # Tests run with mock database
        reset_app_state()
    """
    from unittest.mock import MagicMock
    
    return AppState(
        _db=mock_db or MagicMock(),
        _ai=mock_ai or MagicMock(),
        _settings=MagicMock(),
    )
