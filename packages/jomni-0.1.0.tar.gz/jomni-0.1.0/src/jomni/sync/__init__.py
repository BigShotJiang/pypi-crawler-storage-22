"""
Jomni Sync Engine.

Provides offline-first sync between SQLite (local) and Supabase (cloud).

Modules:
- tracker: Track local changes
- pusher: Push local changes to cloud
- puller: Pull cloud changes to local
- resolver: Handle conflicts
- realtime: Live sync via Supabase Realtime

Usage:
    from jomni.sync import SyncManager
    
    sync = SyncManager(db)
    await sync.sync_all()
"""

from jomni.sync.manager import SyncManager
from jomni.sync.tracker import ChangeTracker
from jomni.sync.pusher import SyncPusher
from jomni.sync.puller import SyncPuller
from jomni.sync.resolver import ConflictResolver
from jomni.sync.realtime import RealtimeSync, NetworkMonitor

__all__ = [
    "SyncManager",
    "ChangeTracker",
    "SyncPusher",
    "SyncPuller",
    "ConflictResolver",
    "RealtimeSync",
    "NetworkMonitor",
]
