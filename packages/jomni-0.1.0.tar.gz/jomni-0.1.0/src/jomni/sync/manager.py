"""
Sync Manager.

High-level orchestration of sync operations.
Coordinates tracker, pusher, and puller.
"""

import logging
from typing import Any

from jomni.sync.tracker import ChangeTracker
from jomni.sync.pusher import SyncPusher
from jomni.sync.puller import SyncPuller
from jomni.utils.datetime import utc_now

logger = logging.getLogger(__name__)


class SyncManager:
    """
    Main sync orchestrator.
    
    Usage:
        sync = SyncManager(sqlite_db, supabase_client)
        await sync.sync_all()
    """
    
    def __init__(self, local_db, cloud_client=None):
        """
        Initialize sync manager.
        
        Args:
            local_db: SQLiteClient instance
            cloud_client: Supabase client (optional - will be lazy loaded)
        """
        self.local_db = local_db
        self._cloud_client = cloud_client
        self._last_sync_time: str | None = None
        
        self.tracker = ChangeTracker(local_db)
        self._pusher: SyncPusher | None = None
        self._puller: SyncPuller | None = None
    
    @property
    def cloud_client(self):
        """Lazy load cloud client if not provided."""
        if self._cloud_client is None:
            from jomni.db import get_database
            from jomni.db.supabase_client import SupabaseClient
            
            db = get_database(force_mode="supabase")
            if isinstance(db, SupabaseClient):
                self._cloud_client = db.client
            else:
                raise RuntimeError("Cannot sync - Supabase not configured")
        return self._cloud_client
    
    @property
    def pusher(self) -> SyncPusher:
        """Get pusher instance."""
        if self._pusher is None:
            self._pusher = SyncPusher(self.local_db, self.cloud_client)
        return self._pusher
    
    @property
    def puller(self) -> SyncPuller:
        """Get puller instance."""
        if self._puller is None:
            self._puller = SyncPuller(self.local_db, self.cloud_client)
        return self._puller
    
    async def sync_all(self) -> dict[str, Any]:
        """
        Perform full sync: pull then push.
        
        Order matters:
        1. Pull cloud changes first (to detect conflicts)
        2. Push local changes
        
        Returns:
            Combined stats from pull and push
        """
        logger.info("Starting full sync...")
        
        # Pull first
        pull_stats = await self.puller.pull_changes(since=self._last_sync_time)
        
        # Then push
        push_stats = await self.pusher.push_all_pending()
        
        # Update last sync time
        self._last_sync_time = utc_now().isoformat()
        
        return {
            "pull": pull_stats,
            "push": push_stats,
            "last_sync": self._last_sync_time,
        }
    
    async def push_only(self) -> dict[str, int]:
        """Push pending changes without pulling."""
        return await self.pusher.push_all_pending()
    
    async def pull_only(self, since: str | None = None) -> dict[str, int]:
        """Pull changes without pushing."""
        return await self.puller.pull_changes(since=since or self._last_sync_time)
    
    def get_pending_count(self) -> int:
        """Get count of items waiting to sync."""
        return len(self.tracker.get_pending_items())
    
    def get_conflict_count(self) -> int:
        """Get count of items with conflicts."""
        return len(self.tracker.get_conflict_items())
    
    def get_conflicts(self) -> list[dict]:
        """Get all items with sync conflicts."""
        return self.tracker.get_conflict_items()
    
    async def resolve_conflict(
        self,
        item_id: str,
        strategy: str = "local_wins"
    ) -> bool:
        """
        Resolve a sync conflict using specified strategy.
        
        Args:
            item_id: ID of conflicting item
            strategy: Resolution strategy:
                - 'local_wins': Keep local version
                - 'cloud_wins': Use cloud version
                - 'last_write_wins': Newer timestamp wins
                - 'field_merge': Merge non-conflicting fields
            
        Returns:
            True if resolved successfully
        """
        from sqlalchemy import select
        from jomni.sync.resolver import ConflictResolver
        
        # Get local item
        with self.local_db.engine.connect() as conn:
            stmt = select(self.local_db.items).where(
                self.local_db.items.c.id == item_id
            )
            local_item = conn.execute(stmt).first()
        
        if not local_item:
            return False
        
        local_data = dict(local_item._mapping)
        sync_id = local_data.get("sync_id")
        
        # Get cloud version for comparison
        cloud_data = None
        if sync_id:
            try:
                result = self.cloud_client.table("items").select("*").eq("id", sync_id).single().execute()
                cloud_data = result.data
            except Exception as e:
                logger.warning(f"Could not fetch cloud version: {e}")
        
        # Use resolver
        resolver = ConflictResolver(default_strategy=strategy)
        
        if strategy in ("local_wins", "local"):
            # Keep local - force push to cloud
            self.tracker.mark_changed(item_id)
            await self.pusher._push_item(local_data)
            self.tracker.mark_synced(item_id)
            
        elif strategy in ("cloud_wins", "cloud"):
            # Use cloud version
            if cloud_data:
                await self.puller._update_from_cloud(item_id, cloud_data)
            else:
                logger.error(f"Cannot use cloud_wins - no cloud data for {item_id}")
                return False
                
        elif strategy == "last_write_wins":
            if cloud_data:
                resolved = resolver.resolve(local_data, cloud_data, "last_write_wins")
                if resolved.get("_resolution") == "local_wins":
                    # Local was newer - push
                    self.tracker.mark_changed(item_id)
                    await self.pusher._push_item(local_data)
                    self.tracker.mark_synced(item_id)
                else:
                    # Cloud was newer - pull
                    await self.puller._update_from_cloud(item_id, cloud_data)
            else:
                # No cloud data - use local
                self.tracker.mark_synced(item_id)
                
        elif strategy == "field_merge":
            if cloud_data:
                resolved = resolver.resolve(local_data, cloud_data, "field_merge")
                # Apply merged content
                await self._apply_merged_item(item_id, resolved)
            else:
                self.tracker.mark_synced(item_id)
        
        logger.info(f"Resolved conflict for {item_id} using {strategy}")
        return True
    
    async def _apply_merged_item(self, item_id: str, merged: dict) -> None:
        """Apply a merged item to local and push to cloud."""
        now = utc_now().isoformat()
        
        update_data = {
            "status": merged.get("status"),
            "content": merged.get("content"),
            "metadata": merged.get("metadata"),
            "parent_id": merged.get("parent_id"),
            "updated_at": now,
            "local_updated_at": now,
            "sync_status": "pending",
        }
        
        with self.local_db.engine.connect() as conn:
            conn.execute(
                self.local_db.items.update()
                .where(self.local_db.items.c.id == item_id)
                .values(**{k: v for k, v in update_data.items() if v is not None})
            )
            conn.commit()
        
        # Push merged version
        from sqlalchemy import select
        with self.local_db.engine.connect() as conn:
            stmt = select(self.local_db.items).where(self.local_db.items.c.id == item_id)
            updated_item = conn.execute(stmt).first()
            if updated_item:
                await self.pusher._push_item(dict(updated_item._mapping))
                self.tracker.mark_synced(item_id)

