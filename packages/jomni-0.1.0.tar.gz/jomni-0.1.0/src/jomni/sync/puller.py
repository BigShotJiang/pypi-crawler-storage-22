"""
Sync Puller.

Pulls changes from Supabase (cloud) to local SQLite.
"""

import logging
from datetime import datetime
from typing import Any

from jomni.utils.datetime import utc_now

logger = logging.getLogger(__name__)


class SyncPuller:
    """
    Pulls cloud changes to local database.
    
    Fetches items from Supabase that have been updated since last sync.
    """
    
    def __init__(self, local_db, cloud_client):
        """
        Initialize puller.
        
        Args:
            local_db: SQLiteClient instance
            cloud_client: Supabase client for cloud operations
        """
        self.local_db = local_db
        self.cloud = cloud_client
    
    async def pull_changes(self, since: str | None = None) -> dict[str, int]:
        """
        Pull all changes from cloud since given timestamp.
        
        Args:
            since: ISO timestamp - only pull items updated after this time.
                   If None, pulls all items (initial sync).
        
        Returns:
            Stats dict with 'pulled', 'skipped', 'conflicts' counts
        """
        stats = {"pulled": 0, "skipped": 0, "conflicts": 0}
        
        try:
            # Build query
            query = self.cloud.table("items").select("*")
            
            if since:
                query = query.gt("updated_at", since)
            
            # Fetch from cloud
            result = query.order("updated_at", desc=False).execute()
            
            for cloud_item in result.data:
                outcome = await self._merge_item(cloud_item)
                stats[outcome] += 1
            
            logger.info(f"Sync pull complete: {stats}")
            return stats
            
        except Exception as e:
            logger.error(f"Pull failed: {e}")
            raise
    
    async def _merge_item(self, cloud_item: dict) -> str:
        """
        Merge a cloud item into local database.
        
        Args:
            cloud_item: Item dict from Supabase
            
        Returns:
            'pulled', 'skipped', or 'conflicts'
        """
        from sqlalchemy import select
        
        cloud_id = cloud_item["id"]
        
        # Check if we have this item locally
        with self.local_db.engine.connect() as conn:
            stmt = select(self.local_db.items).where(
                self.local_db.items.c.sync_id == cloud_id
            )
            local_item = conn.execute(stmt).first()
        
        if not local_item:
            # New item from cloud - insert locally
            await self._insert_from_cloud(cloud_item)
            return "pulled"
        
        local_data = dict(local_item._mapping)
        
        # Check for conflict
        local_updated = local_data.get("local_updated_at")
        local_synced = local_data.get("synced_at")
        cloud_updated = cloud_item.get("updated_at")
        
        # Conflict: local changed AND cloud changed since last sync
        if local_updated and local_synced and local_updated > local_synced:
            if cloud_updated > local_synced:
                # Both changed - conflict!
                self._mark_conflict(local_data["id"])
                return "conflicts"
        
        # No conflict - update local with cloud data
        await self._update_from_cloud(local_data["id"], cloud_item)
        return "pulled"
    
    async def _insert_from_cloud(self, cloud_item: dict) -> None:
        """Insert a new item from cloud into local database."""
        from uuid import uuid4
        
        now = utc_now().isoformat()
        
        local_data = {
            "id": str(uuid4()),  # New local ID
            "sync_id": cloud_item["id"],  # Cloud ID for sync
            "created_at": cloud_item.get("created_at", now),
            "updated_at": cloud_item.get("updated_at", now),
            "item_type": cloud_item["item_type"],
            "status": cloud_item["status"],
            "content": cloud_item["content"],
            "metadata": cloud_item.get("metadata", {}),
            "parent_id": cloud_item.get("parent_id"),
            "schema_version": 1,
            "synced_at": now,
            "sync_status": "synced",
        }
        
        with self.local_db.engine.connect() as conn:
            conn.execute(self.local_db.items.insert().values(**local_data))
            conn.commit()
        
        logger.debug(f"Inserted cloud item {cloud_item['id']} as local {local_data['id']}")
    
    async def _update_from_cloud(self, local_id: str, cloud_item: dict) -> None:
        """Update local item with cloud data."""
        now = utc_now().isoformat()
        
        update_data = {
            "updated_at": cloud_item.get("updated_at", now),
            "item_type": cloud_item["item_type"],
            "status": cloud_item["status"],
            "content": cloud_item["content"],
            "metadata": cloud_item.get("metadata", {}),
            "parent_id": cloud_item.get("parent_id"),
            "synced_at": now,
            "sync_status": "synced",
            "local_updated_at": None,  # Clear local changes flag
        }
        
        with self.local_db.engine.connect() as conn:
            conn.execute(
                self.local_db.items.update()
                .where(self.local_db.items.c.id == local_id)
                .values(**update_data)
            )
            conn.commit()
        
        logger.debug(f"Updated local item {local_id} from cloud")
    
    def _mark_conflict(self, local_id: str) -> None:
        """Mark item as having a sync conflict."""
        with self.local_db.engine.connect() as conn:
            conn.execute(
                self.local_db.items.update()
                .where(self.local_db.items.c.id == local_id)
                .values(sync_status="conflict")
            )
            conn.commit()
        
        logger.warning(f"Marked item {local_id} as conflict")
