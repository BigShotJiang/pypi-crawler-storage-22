"""
Sync Pusher.

Pushes pending local changes to Supabase (cloud).
"""

import logging
from typing import Any
from uuid import UUID, uuid4

from jomni.utils.datetime import utc_now

logger = logging.getLogger(__name__)


class SyncPusher:
    """
    Pushes local changes to the cloud.
    
    Finds items with sync_status='pending' and uploads them to Supabase.
    """
    
    def __init__(self, local_db, cloud_client):
        """
        Initialize pusher.
        
        Args:
            local_db: SQLiteClient instance
            cloud_client: Supabase client for cloud operations
        """
        self.local_db = local_db
        self.cloud = cloud_client
    
    async def push_all_pending(self) -> dict[str, int]:
        """
        Push all pending items to cloud.
        
        Returns:
            Stats dict with 'pushed', 'failed', 'conflicts' counts
        """
        from jomni.sync.tracker import ChangeTracker
        
        tracker = ChangeTracker(self.local_db)
        pending = tracker.get_pending_items()
        
        stats = {"pushed": 0, "failed": 0, "conflicts": 0}
        
        for item in pending:
            try:
                result = await self._push_item(item)
                if result == "success":
                    tracker.mark_synced(item["id"])
                    stats["pushed"] += 1
                elif result == "conflict":
                    tracker.mark_conflict(item["id"])
                    stats["conflicts"] += 1
                else:
                    stats["failed"] += 1
            except Exception as e:
                logger.error(f"Failed to push item {item['id']}: {e}")
                stats["failed"] += 1
        
        logger.info(f"Sync push complete: {stats}")
        return stats
    
    async def _push_item(self, item: dict) -> str:
        """
        Push a single item to cloud.
        
        Args:
            item: Item dict from local database
            
        Returns:
            'success', 'conflict', or 'failed'
        """
        item_id = item["id"]
        sync_id = item.get("sync_id")
        
        # Prepare data for cloud (remove local-only fields)
        cloud_data = {
            "id": sync_id or str(uuid4()),  # Use existing sync_id or generate new
            "item_type": item["item_type"],
            "status": item["status"],
            "content": item["content"],
            "metadata": item.get("metadata", {}),
            "parent_id": item.get("parent_id"),
            "created_at": item["created_at"],
            "updated_at": item.get("local_updated_at") or item["updated_at"],
        }
        
        try:
            if sync_id:
                # Item exists in cloud - check for conflicts
                cloud_item = self.cloud.table("items").select("*").eq("id", sync_id).single().execute()
                
                if cloud_item.data:
                    cloud_updated = cloud_item.data.get("updated_at", "")
                    local_synced = item.get("synced_at", "")
                    
                    # Conflict: cloud changed since our last sync
                    if cloud_updated > local_synced:
                        return "conflict"
                
                # No conflict - update cloud
                self.cloud.table("items").update(cloud_data).eq("id", sync_id).execute()
            else:
                # New item - insert to cloud
                result = self.cloud.table("items").insert(cloud_data).execute()
                
                # Store the sync_id locally for future syncs
                if result.data:
                    self._update_sync_id(item_id, cloud_data["id"])
            
            return "success"
            
        except Exception as e:
            logger.error(f"Push failed for {item_id}: {e}")
            return "failed"
    
    def _update_sync_id(self, local_id: str, sync_id: str) -> None:
        """Store the cloud ID for a locally-created item."""
        with self.local_db.engine.connect() as conn:
            conn.execute(
                self.local_db.items.update()
                .where(self.local_db.items.c.id == local_id)
                .values(sync_id=sync_id)
            )
            conn.commit()
