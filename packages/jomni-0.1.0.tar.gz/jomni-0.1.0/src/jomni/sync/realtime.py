"""
Realtime Sync (Phase 3).

Integrates with Supabase Realtime to receive live updates.
Automatically syncs changes when network reconnects.
"""

import asyncio
import logging
from typing import Any, Callable

from jomni.utils.datetime import utc_now

logger = logging.getLogger(__name__)


class RealtimeSync:
    """
    Supabase Realtime integration for live sync.
    
    Subscribes to table changes and automatically updates local SQLite.
    
    Usage:
        realtime = RealtimeSync(sync_manager)
        await realtime.start()
        # ... app runs ...
        await realtime.stop()
    """
    
    def __init__(self, sync_manager):
        """
        Initialize realtime sync.
        
        Args:
            sync_manager: SyncManager instance
        """
        self.sync = sync_manager
        self._channel = None
        self._running = False
        self._on_change_callbacks: list[Callable] = []
    
    async def start(self) -> bool:
        """
        Start listening to realtime changes.
        
        Returns:
            True if started successfully
        """
        if self._running:
            logger.warning("Realtime sync already running")
            return True
        
        try:
            # Get realtime client from Supabase
            # The supabase-py client has built-in realtime support
            client = self.sync.cloud_client
            
            # Subscribe to items table changes
            self._channel = client.channel("items_changes")
            
            # Listen for all change types
            self._channel.on_postgres_changes(
                event="*",  # INSERT, UPDATE, DELETE
                schema="public",
                table="items",
                callback=self._handle_change
            )
            
            await self._channel.subscribe()
            self._running = True
            
            logger.info("Realtime sync started - listening for cloud changes")
            return True
            
        except Exception as e:
            logger.error(f"Failed to start realtime sync: {e}")
            return False
    
    async def stop(self) -> None:
        """Stop listening to realtime changes."""
        if self._channel:
            try:
                await self._channel.unsubscribe()
            except Exception as e:
                logger.warning(f"Error unsubscribing: {e}")
        
        self._running = False
        logger.info("Realtime sync stopped")
    
    def _handle_change(self, payload: dict) -> None:
        """
        Handle incoming change from Supabase Realtime.
        
        Args:
            payload: Change payload with event type and data
        """
        try:
            event_type = payload.get("type", "")
            new_record = payload.get("new", {})
            old_record = payload.get("old", {})
            
            logger.info(f"Realtime: received {event_type} for item {new_record.get('id', old_record.get('id'))}")
            
            # Schedule async update
            asyncio.create_task(self._apply_change(event_type, new_record, old_record))
            
            # Notify callbacks
            for callback in self._on_change_callbacks:
                try:
                    callback(event_type, new_record, old_record)
                except Exception as cb_err:
                    logger.error(f"Callback error: {cb_err}")
                    
        except Exception as e:
            logger.error(f"Error handling realtime change: {e}")
    
    async def _apply_change(self, event_type: str, new_record: dict, old_record: dict) -> None:
        """Apply a realtime change to local database."""
        cloud_id = new_record.get("id") or old_record.get("id")
        if not cloud_id:
            return
        
        if event_type in ("INSERT", "UPDATE"):
            # Pull this specific item from cloud
            try:
                await self.sync.puller._insert_from_cloud(new_record)
                logger.debug(f"Applied realtime {event_type} for {cloud_id}")
            except Exception as e:
                # Item might already exist, try update
                try:
                    from sqlalchemy import select
                    with self.sync.local_db.engine.connect() as conn:
                        stmt = select(self.sync.local_db.items).where(
                            self.sync.local_db.items.c.sync_id == cloud_id
                        )
                        local = conn.execute(stmt).first()
                        if local:
                            await self.sync.puller._update_from_cloud(local._mapping["id"], new_record)
                except Exception as e2:
                    logger.error(f"Failed to apply realtime change: {e2}")
                    
        elif event_type == "DELETE":
            # Mark local item as deleted
            from sqlalchemy import select, update
            try:
                with self.sync.local_db.engine.connect() as conn:
                    stmt = select(self.sync.local_db.items).where(
                        self.sync.local_db.items.c.sync_id == cloud_id
                    )
                    local = conn.execute(stmt).first()
                    if local:
                        now = utc_now().isoformat()
                        conn.execute(
                            self.sync.local_db.items.update()
                            .where(self.sync.local_db.items.c.id == local._mapping["id"])
                            .values(deleted_at=now, sync_status="synced")
                        )
                        conn.commit()
                        logger.debug(f"Applied realtime DELETE for {cloud_id}")
            except Exception as e:
                logger.error(f"Failed to apply realtime delete: {e}")
    
    def on_change(self, callback: Callable[[str, dict, dict], None]) -> None:
        """
        Register a callback for change events.
        
        Args:
            callback: Function called with (event_type, new_record, old_record)
        """
        self._on_change_callbacks.append(callback)
    
    @property
    def is_running(self) -> bool:
        """Check if realtime sync is active."""
        return self._running


class NetworkMonitor:
    """
    Monitor network connectivity and trigger sync on reconnect.
    
    Usage:
        monitor = NetworkMonitor(sync_manager)
        await monitor.start()
    """
    
    def __init__(self, sync_manager, check_interval: int = 30):
        """
        Initialize network monitor.
        
        Args:
            sync_manager: SyncManager instance
            check_interval: Seconds between connectivity checks
        """
        self.sync = sync_manager
        self.check_interval = check_interval
        self._running = False
        self._was_offline = False
        self._task = None
    
    async def start(self) -> None:
        """Start monitoring network connectivity."""
        self._running = True
        self._task = asyncio.create_task(self._monitor_loop())
        logger.info("Network monitor started")
    
    async def stop(self) -> None:
        """Stop monitoring."""
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        logger.info("Network monitor stopped")
    
    async def _monitor_loop(self) -> None:
        """Main monitoring loop."""
        while self._running:
            try:
                is_online = await self._check_connectivity()
                
                if is_online and self._was_offline:
                    # Just came back online - trigger sync
                    logger.info("Network restored - triggering sync")
                    await self._on_reconnect()
                
                self._was_offline = not is_online
                
            except Exception as e:
                logger.error(f"Network check error: {e}")
            
            await asyncio.sleep(self.check_interval)
    
    async def _check_connectivity(self) -> bool:
        """
        Check if we can reach Supabase.
        
        Returns:
            True if online
        """
        try:
            # Try a simple query
            self.sync.cloud_client.table("items").select("id").limit(1).execute()
            return True
        except Exception:
            return False
    
    async def _on_reconnect(self) -> None:
        """Handle network reconnection."""
        try:
            # Perform full sync
            result = await self.sync.sync_all()
            logger.info(f"Reconnect sync complete: {result}")
        except Exception as e:
            logger.error(f"Reconnect sync failed: {e}")
