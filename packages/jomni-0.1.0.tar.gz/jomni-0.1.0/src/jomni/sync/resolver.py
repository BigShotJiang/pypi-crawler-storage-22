"""
Conflict Resolver.

Handles sync conflicts when both local and cloud have changes.
Supports multiple resolution strategies:
- last_write_wins: Newer timestamp wins
- local_wins: Always keep local version
- cloud_wins: Always use cloud version
- field_merge: Merge non-conflicting fields
"""

import logging
from datetime import datetime
from typing import Any, Literal

from jomni.utils.datetime import utc_now

logger = logging.getLogger(__name__)


ResolutionStrategy = Literal["last_write_wins", "local_wins", "cloud_wins", "field_merge"]


class ConflictResolver:
    """
    Resolves sync conflicts between local and cloud versions.
    
    Usage:
        resolver = ConflictResolver()
        result = resolver.resolve(local_item, cloud_item, strategy="last_write_wins")
    """
    
    def __init__(self, default_strategy: ResolutionStrategy = "last_write_wins"):
        """
        Initialize resolver.
        
        Args:
            default_strategy: Default resolution strategy to use
        """
        self.default_strategy = default_strategy
    
    def detect_conflict(
        self,
        local_item: dict,
        cloud_item: dict,
    ) -> bool:
        """
        Detect if there's a conflict between local and cloud versions.
        
        Conflict exists when:
        - Local changed since last sync (local_updated_at > synced_at)
        - Cloud changed since last sync (cloud.updated_at > synced_at)
        
        Args:
            local_item: Item dict from SQLite
            cloud_item: Item dict from Supabase
            
        Returns:
            True if conflict exists
        """
        local_synced = local_item.get("synced_at")
        local_updated = local_item.get("local_updated_at")
        cloud_updated = cloud_item.get("updated_at")
        
        # No prior sync - not a conflict, just new
        if not local_synced:
            return False
        
        # Check if both have changes since last sync
        local_changed = local_updated and local_updated > local_synced
        cloud_changed = cloud_updated and cloud_updated > local_synced
        
        return local_changed and cloud_changed
    
    def resolve(
        self,
        local_item: dict,
        cloud_item: dict,
        strategy: ResolutionStrategy | None = None,
    ) -> dict:
        """
        Resolve conflict and return winning version.
        
        Args:
            local_item: Item dict from SQLite
            cloud_item: Item dict from Supabase
            strategy: Resolution strategy (uses default if None)
            
        Returns:
            Merged/winning item dict
        """
        strategy = strategy or self.default_strategy
        
        if strategy == "local_wins":
            return self._use_local(local_item)
        elif strategy == "cloud_wins":
            return self._use_cloud(cloud_item)
        elif strategy == "last_write_wins":
            return self._last_write_wins(local_item, cloud_item)
        elif strategy == "field_merge":
            return self._field_merge(local_item, cloud_item)
        else:
            raise ValueError(f"Unknown strategy: {strategy}")
    
    def _use_local(self, local_item: dict) -> dict:
        """Keep local version."""
        return {
            **local_item,
            "sync_status": "pending",  # Push to cloud
            "_resolution": "local_wins",
        }
    
    def _use_cloud(self, cloud_item: dict) -> dict:
        """Use cloud version."""
        return {
            **cloud_item,
            "sync_status": "synced",
            "local_updated_at": None,
            "_resolution": "cloud_wins",
        }
    
    def _last_write_wins(self, local_item: dict, cloud_item: dict) -> dict:
        """
        Newer timestamp wins.
        
        Compares local_updated_at with cloud updated_at.
        """
        local_time = local_item.get("local_updated_at", "")
        cloud_time = cloud_item.get("updated_at", "")
        
        if local_time >= cloud_time:
            logger.info(f"Last-write-wins: local ({local_time}) beats cloud ({cloud_time})")
            return self._use_local(local_item)
        else:
            logger.info(f"Last-write-wins: cloud ({cloud_time}) beats local ({local_time})")
            return self._use_cloud(cloud_item)
    
    def _field_merge(self, local_item: dict, cloud_item: dict) -> dict:
        """
        Merge non-conflicting fields.
        
        If a field only changed in local, use local.
        If a field only changed in cloud, use cloud.
        If both changed, use newer timestamp.
        """
        # Start with cloud as base
        merged = {**cloud_item}
        
        # Fields to consider for merging
        merge_fields = ["status", "content", "metadata", "parent_id"]
        
        # Use synced_at as baseline for what was "original"
        synced_at = local_item.get("synced_at", "")
        
        for field in merge_fields:
            local_val = local_item.get(field)
            cloud_val = cloud_item.get(field)
            
            # If values are same, no conflict
            if local_val == cloud_val:
                continue
            
            # If we have local changes but cloud didn't change this field
            # (simplified: use local if local is "newer" overall)
            local_time = local_item.get("local_updated_at", "")
            cloud_time = cloud_item.get("updated_at", "")
            
            if local_time >= cloud_time:
                merged[field] = local_val
        
        merged["_resolution"] = "field_merge"
        merged["sync_status"] = "pending"  # Need to push merged version
        
        return merged
    
    def get_diff(self, local_item: dict, cloud_item: dict) -> dict:
        """
        Get a diff of changes between local and cloud.
        
        Useful for displaying conflicts to users.
        
        Returns:
            Dict with 'local_only', 'cloud_only', 'both_changed' keys
        """
        diff = {
            "local_only": {},
            "cloud_only": {},
            "both_changed": {},
        }
        
        compare_fields = ["status", "content", "metadata", "parent_id", "item_type"]
        
        for field in compare_fields:
            local_val = local_item.get(field)
            cloud_val = cloud_item.get(field)
            
            if local_val != cloud_val:
                diff["both_changed"][field] = {
                    "local": local_val,
                    "cloud": cloud_val,
                }
        
        return diff
