"""
Change Tracker.

Intercepts write operations to mark items as needing sync.
Sets sync_status='pending' and local_updated_at on changes.
"""

import logging
from datetime import datetime
from typing import Any
from uuid import UUID

from jomni.utils.datetime import utc_now

logger = logging.getLogger(__name__)


class ChangeTracker:
    """
    Tracks local changes for sync.
    
    Call mark_changed() after any local write operation to flag
    the item as needing sync to the cloud.
    """
    
    def __init__(self, db):
        """
        Initialize tracker with database connection.
        
        Args:
            db: SQLiteClient instance
        """
        self.db = db
    
    def mark_changed(self, item_id: str | UUID) -> None:
        """
        Mark an item as changed locally and needing sync.
        
        Sets:
        - local_updated_at = now
        - sync_status = 'pending'
        
        Args:
            item_id: ID of the changed item
        """
        now = utc_now().isoformat()
        item_id_str = str(item_id)
        
        with self.db.engine.connect() as conn:
            conn.execute(
                self.db.items.update()
                .where(self.db.items.c.id == item_id_str)
                .values(
                    local_updated_at=now,
                    sync_status="pending",
                )
            )
            conn.commit()
        
        logger.debug(f"Marked item {item_id_str} as pending sync")
    
    def mark_synced(self, item_id: str | UUID) -> None:
        """
        Mark an item as successfully synced.
        
        Sets:
        - synced_at = now
        - sync_status = 'synced'
        
        Args:
            item_id: ID of the synced item
        """
        now = utc_now().isoformat()
        item_id_str = str(item_id)
        
        with self.db.engine.connect() as conn:
            conn.execute(
                self.db.items.update()
                .where(self.db.items.c.id == item_id_str)
                .values(
                    synced_at=now,
                    sync_status="synced",
                )
            )
            conn.commit()
        
        logger.debug(f"Marked item {item_id_str} as synced")
    
    def mark_conflict(self, item_id: str | UUID) -> None:
        """
        Mark an item as having a sync conflict.
        
        This happens when both local and cloud have changes since last sync.
        
        Args:
            item_id: ID of the conflicting item
        """
        item_id_str = str(item_id)
        
        with self.db.engine.connect() as conn:
            conn.execute(
                self.db.items.update()
                .where(self.db.items.c.id == item_id_str)
                .values(sync_status="conflict")
            )
            conn.commit()
        
        logger.warning(f"Marked item {item_id_str} as conflict")
    
    def get_pending_items(self, limit: int = 100) -> list[dict]:
        """
        Get all items that need to be synced.
        
        Returns items where sync_status='pending'.
        
        Args:
            limit: Maximum number of items to return
            
        Returns:
            List of item dictionaries
        """
        from sqlalchemy import select
        
        with self.db.engine.connect() as conn:
            stmt = select(self.db.items).where(
                self.db.items.c.sync_status == "pending"
            ).limit(limit)
            
            results = conn.execute(stmt).fetchall()
            return [dict(row._mapping) for row in results]
    
    def get_conflict_items(self) -> list[dict]:
        """
        Get all items with sync conflicts.
        
        Returns items where sync_status='conflict'.
        
        Returns:
            List of item dictionaries with conflicts
        """
        from sqlalchemy import select
        
        with self.db.engine.connect() as conn:
            stmt = select(self.db.items).where(
                self.db.items.c.sync_status == "conflict"
            )
            
            results = conn.execute(stmt).fetchall()
            return [dict(row._mapping) for row in results]
