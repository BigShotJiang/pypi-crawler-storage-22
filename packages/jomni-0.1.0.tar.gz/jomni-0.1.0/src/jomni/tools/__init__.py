"""
Jomni shared tools module.

Contains:
- Registry-based handler dispatch system
- Unified handler implementations used by MCP server and Chat executor
- Unified schema definitions with converters for MCP and Anthropic formats

Handler modules register themselves on import via @register_handler decorator.
Call load_all_handlers() to populate the registry before using TOOL_HANDLERS.
"""

from jomni.tools.registry import (
    TOOL_HANDLERS,
    ToolContext,
    register_handler,
    register_handlers,
)

from jomni.tools.handlers import (
    handle_capture,
    handle_complete_item,
    handle_delete_item,
    handle_restore_item,
    handle_search,
    handle_create_goal,
)

from jomni.tools.schemas import (
    get_mcp_tools,
    get_anthropic_tools,
    get_tool_names,
    CORE_TOOLS,
    ToolSchema,
    ToolParam,
)


def load_all_handlers():
    """
    Import all handler modules to populate the registry.
    
    Call this before using TOOL_HANDLERS to ensure all handlers are registered.
    Safe to call multiple times - imports are cached.
    """
    from jomni.tools import (
        capture,
        items,
        search,
        insights,
        goals,
        tags,
        integrations,
        people,
        recurring,
        scheduler,
    )


__all__ = [
    # Registry
    "TOOL_HANDLERS",
    "ToolContext",
    "register_handler",
    "register_handlers",
    "load_all_handlers",
    # Core handlers (for direct use)
    "handle_capture",
    "handle_complete_item",
    "handle_delete_item",
    "handle_restore_item",
    "handle_search",
    "handle_create_goal",
    # Schemas
    "get_mcp_tools",
    "get_anthropic_tools",
    "get_tool_names",
    "CORE_TOOLS",
    "ToolSchema",
    "ToolParam",
]
