"""
Capture & Triage tool handlers.

Handles: capture, triage, accept_triage, bulk_capture, triage_inbox
"""

import logging
from typing import Any
from uuid import UUID

from jomni.models import (
    ItemCreate, ItemUpdate, ItemType, ItemStatus,
    TriageRequest,
)
from jomni.tools.registry import ToolContext, register_handler
from jomni.tools.handlers import handle_capture as _handle_capture_core

logger = logging.getLogger(__name__)


# =============================================================================
# CAPTURE
# =============================================================================

@register_handler("capture")
async def handle_capture(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Add a new item to the inbox for later triage."""
    return await _handle_capture_core(
        ctx.db, ctx.actor,
        text=args.get("text", ""),
        context=args.get("context"),
        source="mcp",
    )


# =============================================================================
# TRIAGE
# =============================================================================

@register_handler("triage")
async def handle_triage(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """
    Classify a capture into the appropriate type.
    
    If item_id is provided, classifies an existing inbox item in-place.
    Otherwise, creates a new item from text (legacy behavior).
    """
    text = args.get("text", "")
    context = args.get("context", {})
    item_id = args.get("item_id")
    
    # If item_id provided, get existing item's text
    existing_item = None
    if item_id:
        existing_item = await ctx.db.get_item(UUID(item_id))
        if not existing_item:
            return {"error": f"Item {item_id} not found"}
        text = text or existing_item.content.get("text", "")
    
    if not text:
        return {"error": "Either text or item_id with text content is required"}
    
    # Get AI triage suggestion
    request = TriageRequest(text=text, context=context)
    suggestion = await ctx.ai.triage(request)
    
    result = {
        "item_type": suggestion.item_type.value,
        "confidence": suggestion.confidence,
        "reasoning": suggestion.reasoning,
        "suggested_tags": suggestion.suggested_tags,
        "alternatives": suggestion.alternatives,
    }
    
    # Auto-accept if high confidence
    if suggestion.confidence >= ctx.ai.auto_accept_threshold:
        if item_id and existing_item:
            # Update existing item instead of creating new
            await ctx.db.update_item(
                UUID(item_id),
                ItemUpdate(
                    item_type=suggestion.item_type,
                    status=ItemStatus.ACTIVE,
                    content={"text": text, "tags": suggestion.suggested_tags},
                ),
                actor=ctx.actor,
                reasoning=suggestion.reasoning,
                confidence=suggestion.confidence,
            )
            result["auto_accepted"] = True
            result["item_id"] = item_id
            result["updated_existing"] = True
        else:
            # Create new item (legacy behavior)
            item = await ctx.db.create_item(
                ItemCreate(
                    item_type=suggestion.item_type,
                    status=ItemStatus.ACTIVE,
                    content={"text": text, "tags": suggestion.suggested_tags},
                ),
                actor=ctx.actor,
                reasoning=suggestion.reasoning,
                confidence=suggestion.confidence,
            )
            result["auto_accepted"] = True
            result["item_id"] = str(item.id)
    else:
        result["auto_accepted"] = False
        result["message"] = "Confidence below threshold - awaiting user confirmation"
        if item_id:
            result["item_id"] = item_id
    
    return result


# =============================================================================
# ACCEPT TRIAGE
# =============================================================================

@register_handler("accept_triage")
async def handle_accept_triage(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Accept a triage suggestion and create the item."""
    text = args.get("text", "")
    item_type = ItemType(args.get("item_type"))
    tags = args.get("tags", [])
    
    # Create the item
    item = await ctx.db.create_item(
        ItemCreate(
            item_type=item_type,
            status=ItemStatus.ACTIVE,
            content={"text": text, "tags": tags},
        ),
        actor=ctx.actor,
        reasoning="User accepted triage suggestion via MCP",
    )
    
    # Store embedding for search
    embedding, source_hash = await ctx.ai.embed(text)
    from jomni.models import EmbeddingCreate
    await ctx.db.store_embedding(EmbeddingCreate(
        item_id=item.id,
        model_name=ctx.ai.embedding_model,
        model_version="v1",
        dimensions=ctx.ai.embedding_dimensions,
        embedding=embedding,
        source_hash=source_hash,
    ))
    
    return {
        "success": True,
        "item_id": str(item.id),
        "item_type": item_type.value,
        "message": f"Created {item_type.value}: '{text[:50]}...'",
    }


# =============================================================================
# BULK CAPTURE
# =============================================================================

@register_handler("bulk_capture")
async def handle_bulk_capture(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Capture multiple items in one call."""
    items_to_capture = args.get("items", [])
    auto_triage = args.get("auto_triage", False)
    
    if not items_to_capture:
        return {"error": "items list is required"}
    
    created_ids = []
    triaged_count = 0
    failed_count = 0
    
    for item_data in items_to_capture:
        try:
            capture_result = await _handle_capture_core(
                ctx.db, ctx.actor,
                text=item_data.get("text", ""),
                context=item_data.get("context"),
                source="mcp-bulk",
            )
            if capture_result.get("success") and capture_result.get("item_id"):
                created_ids.append(capture_result["item_id"])
                
                # If auto_triage, classify the item in-place
                if auto_triage:
                    triage_result = await handle_triage(ctx, {
                        "text": item_data.get("text", ""),
                        "item_id": capture_result["item_id"],
                        "context": item_data.get("context", {}),
                    })
                    if triage_result.get("auto_accepted"):
                        triaged_count += 1
            else:
                failed_count += 1
        except Exception as e:
            logger.warning(f"Bulk capture item failed: {e}")
            failed_count += 1
    
    result = {
        "success": True,
        "created": len(created_ids),
        "failed": failed_count,
        "ids": created_ids,
    }
    if auto_triage:
        result["triaged"] = triaged_count
        result["pending_review"] = len(created_ids) - triaged_count
    
    return result


# =============================================================================
# TRIAGE INBOX
# =============================================================================

@register_handler("triage_inbox")
async def handle_triage_inbox(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Process pending inbox items through AI triage."""
    limit = args.get("limit", 10)
    
    inbox_items = await ctx.db.get_inbox(limit=limit)
    results = []
    auto_accepted = 0
    needs_review = 0
    
    for item in inbox_items:
        text = item.content.get("text", "")
        triage_result = await handle_triage(ctx, {
            "text": text,
            "item_id": str(item.id),
        })
        
        if triage_result.get("auto_accepted"):
            auto_accepted += 1
        else:
            needs_review += 1
        
        results.append({
            "item_id": str(item.id),
            "item_type": triage_result.get("item_type"),
            "confidence": triage_result.get("confidence"),
            "auto_accepted": triage_result.get("auto_accepted", False),
        })
    
    return {
        "success": True,
        "processed": len(results),
        "auto_accepted": auto_accepted,
        "needs_review": needs_review,
        "items": results,
    }
