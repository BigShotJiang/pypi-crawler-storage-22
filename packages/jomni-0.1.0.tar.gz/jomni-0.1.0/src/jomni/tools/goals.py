"""
Goal tool handlers.

Handles: create_goal, list_goals, link_to_goal, assess_goal, update_goal
"""

from typing import Any
from uuid import UUID

from jomni.models import ItemType, ItemStatus, ItemUpdate
from jomni.tools.registry import ToolContext, register_handler
from jomni.tools.handlers import handle_create_goal as _handle_create_goal_core
from jomni.utils.datetime import utc_now


# =============================================================================
# CREATE GOAL
# =============================================================================

@register_handler("create_goal")
async def handle_create_goal(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Create a new goal with structured content."""
    return await _handle_create_goal_core(
        ctx.db, ctx.actor,
        title=args.get("title", ""),
        description=args.get("description"),
        horizon=args.get("horizon", "medium"),
        target_date=args.get("target_date"),
        success_criteria=args.get("success_criteria"),
        tags=args.get("tags"),
        source="mcp",
    )


# =============================================================================
# LIST GOALS
# =============================================================================

@register_handler("list_goals")
async def handle_list_goals(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """List goals with optional filters by status and time horizon."""
    status = args.get("status", "active")
    horizon = args.get("horizon")
    limit = args.get("limit", 20)
    
    goals = await ctx.db.list_items(
        item_type=ItemType.GOAL,
        status=ItemStatus(status) if status else None,
        limit=limit,
    )
    
    # Filter by horizon if specified
    if horizon:
        goals = [g for g in goals if g.metadata.get("horizon") == horizon]
    
    return {
        "count": len(goals),
        "goals": [
            {
                "id": str(g.id),
                "title": g.content.get("text", "")[:100],
                "horizon": g.metadata.get("horizon", "medium") if g.metadata else "medium",
                "progress": g.metadata.get("progress", 0) if g.metadata else 0,
                "target_date": g.content.get("target_date") if g.content else None,
                "status": g.status.value,
            }
            for g in goals
        ],
    }


# =============================================================================
# LINK TO GOAL
# =============================================================================

@register_handler("link_to_goal")
async def handle_link_to_goal(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Link an item to a goal as supporting it."""
    item_id = UUID(args.get("item_id"))
    goal_id = UUID(args.get("goal_id"))
    reasoning = args.get("reasoning", "")
    
    # Verify both items exist
    item = await ctx.db.get_item(item_id)
    goal = await ctx.db.get_item(goal_id)
    
    if not item:
        return {"success": False, "error": "Item not found"}
    if not goal:
        return {"success": False, "error": "Goal not found"}
    if goal.item_type != ItemType.GOAL:
        return {"success": False, "error": "Target is not a goal"}
    
    # Link by setting parent_id
    await ctx.db.update_item(
        item_id,
        ItemUpdate(parent_id=goal_id, metadata={
            **(item.metadata or {}),
            "linked_to_goal": str(goal_id),
            "link_reasoning": reasoning,
        }),
        actor=ctx.actor,
        reasoning=f"Linked to goal: {reasoning[:50] if reasoning else 'via MCP'}",
    )
    
    return {
        "success": True,
        "message": f"Linked item to goal '{goal.content.get('text', '')[:30]}'"
    }


# =============================================================================
# ASSESS GOAL
# =============================================================================

@register_handler("assess_goal")
async def handle_assess_goal(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Record a progress assessment for a goal."""
    goal_id = args.get("goal_id")
    progress = args.get("progress")
    notes = args.get("notes", "")
    blockers = args.get("blockers", [])
    
    if not goal_id or progress is None:
        return {"error": "goal_id and progress are required"}
    
    goal = await ctx.db.get_item(UUID(goal_id))
    if not goal:
        return {"error": "Goal not found"}
    
    new_metadata = {**(goal.metadata or {})}
    new_metadata["progress"] = progress
    new_metadata["last_assessment"] = utc_now().isoformat()
    if notes:
        new_metadata["last_notes"] = notes
    if blockers:
        new_metadata["blockers"] = blockers
    
    await ctx.db.update_item(
        UUID(goal_id),
        ItemUpdate(metadata=new_metadata),
        actor=ctx.actor,
        reasoning=f"Goal assessment: {progress}% progress",
    )
    
    return {"success": True, "goal_id": goal_id, "progress": progress}


# =============================================================================
# UPDATE GOAL
# =============================================================================

@register_handler("update_goal")
async def handle_update_goal(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Update a goal's properties."""
    goal_id = args.get("goal_id")
    if not goal_id:
        return {"error": "goal_id is required"}
    
    goal = await ctx.db.get_item(UUID(goal_id))
    if not goal:
        return {"error": "Goal not found"}
    
    updates = {}
    content = {**goal.content}
    metadata = {**(goal.metadata or {})}
    
    if "title" in args:
        content["text"] = args["title"]
    if "description" in args:
        content["description"] = args["description"]
    if "horizon" in args:
        metadata["horizon"] = args["horizon"]
    if "target_date" in args:
        updates["due_at"] = args["target_date"]
    if "success_criteria" in args:
        metadata["success_criteria"] = args["success_criteria"]
    if "status" in args:
        updates["status"] = ItemStatus(args["status"])
    
    updates["content"] = content
    updates["metadata"] = metadata
    
    await ctx.db.update_item(
        UUID(goal_id),
        ItemUpdate(**updates),
        actor=ctx.actor,
        reasoning="Goal updated via MCP",
    )
    
    return {"success": True, "goal_id": goal_id}
