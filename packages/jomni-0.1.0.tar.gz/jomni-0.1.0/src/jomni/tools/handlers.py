"""
Shared tool handlers for Jomni.

These handlers are used by both the MCP server and the Chat executor,
eliminating code duplication and ensuring consistent behavior.

Usage:
    from jomni.tools.handlers import handle_capture, handle_search, ...
"""

import logging
from typing import Any, Optional
from uuid import UUID

from jomni.db.protocol import DatabaseProtocol
from jomni.ai.provider import AIProvider
from jomni.models import (
    ItemType, ItemStatus, ItemCreate, ItemUpdate,
)

logger = logging.getLogger(__name__)


# =============================================================================
# CAPTURE
# =============================================================================

async def handle_capture(
    db: DatabaseProtocol,
    actor: tuple,
    text: str,
    item_type: Optional[ItemType] = None,
    context: Optional[dict] = None,
    source: str = "unknown",
) -> dict[str, Any]:
    """
    Create a new item in the inbox.
    
    Args:
        db: Database client
        actor: Tuple of (ActorType, actor_id) for audit trail
        text: The text content to capture
        item_type: Item type (default: CAPTURE for inbox triage)
        context: Optional additional context to store
        source: Source identifier (e.g., "mcp", "chat")
    
    Returns:
        Dict with success status, item_id, and message
    """
    effective_type = item_type or ItemType.CAPTURE
    content = {"text": text}
    if context:
        content.update(context)
    
    item = await db.create_item(
        ItemCreate(
            item_type=effective_type,
            status=ItemStatus.INBOX,
            content=content,
            metadata={"source": source},
        ),
        actor=actor,
        reasoning=f"Captured via {source}",
    )
    
    return {
        "success": True,
        "item_id": str(item.id),
        "message": f"Created {effective_type.value}: '{text[:50]}'",
    }


# =============================================================================
# COMPLETE ITEM
# =============================================================================

async def handle_complete_item(
    db: DatabaseProtocol,
    actor: tuple,
    item_id: str | UUID,
    reasoning: Optional[str] = None,
) -> dict[str, Any]:
    """
    Mark an item as completed.
    
    Args:
        db: Database client
        actor: Tuple of (ActorType, actor_id) for audit trail
        item_id: UUID of the item to complete
        reasoning: Optional reason for completion
    
    Returns:
        Dict with success status and message
    """
    if isinstance(item_id, str):
        item_id = UUID(item_id)
    
    item = await db.get_item(item_id)
    if not item:
        return {"success": False, "error": "Item not found"}
    
    item_text = item.content.get("text", "")[:50] if item.content else ""
    await db.complete_item(item_id, actor=actor, reasoning=reasoning)
    
    return {
        "success": True,
        "item_id": str(item_id),
        "message": f"Completed: '{item_text}'",
    }


# =============================================================================
# DELETE ITEM
# =============================================================================

async def handle_delete_item(
    db: DatabaseProtocol,
    actor: tuple,
    item_id: str | UUID,
    reasoning: Optional[str] = None,
) -> dict[str, Any]:
    """
    Soft delete an item (can be restored later).
    
    Args:
        db: Database client
        actor: Tuple of (ActorType, actor_id) for audit trail
        item_id: UUID of the item to delete
        reasoning: Optional reason for deletion
    
    Returns:
        Dict with success status and message
    """
    if isinstance(item_id, str):
        item_id = UUID(item_id)
    
    # Get item text before deletion for message (and verify it exists)
    item = await db.get_item(item_id)
    if not item:
        return {"success": False, "error": "Item not found"}
    
    item_text = item.content.get("text", "")[:50] if item.content else ""
    
    success = await db.delete_item(item_id, actor=actor, reasoning=reasoning)
    
    if not success:
        return {"success": False, "error": "Item not found"}
    
    return {
        "success": True,
        "item_id": str(item_id),
        "message": f"Deleted: '{item_text}'" if item_text else "Item deleted (can be restored)",
    }


# =============================================================================
# RESTORE ITEM
# =============================================================================

async def handle_restore_item(
    db: DatabaseProtocol,
    actor: tuple,
    item_id: str | UUID,
) -> dict[str, Any]:
    """
    Restore a previously deleted item.
    
    Args:
        db: Database client
        actor: Tuple of (ActorType, actor_id) for audit trail
        item_id: UUID of the item to restore
    
    Returns:
        Dict with success status and message
    """
    if isinstance(item_id, str):
        item_id = UUID(item_id)
    
    item = await db.restore_item(item_id, actor=actor)
    
    if not item:
        return {"success": False, "error": "Item not found or not deleted"}
    
    item_text = item.content.get("text", "")[:50] if item.content else ""
    return {
        "success": True,
        "item_id": str(item.id),
        "message": f"Restored: '{item_text}'",
    }


# =============================================================================
# SEARCH
# =============================================================================

async def handle_search(
    db: DatabaseProtocol,
    ai: AIProvider,
    query: str = "",
    item_types: Optional[list[str]] = None,
    statuses: Optional[list[str]] = None,
    sort_by: str = "similarity",
    limit: int = 10,
) -> dict[str, Any]:
    """
    Hybrid semantic and keyword search for items.
    
    Args:
        db: Database client
        ai: AI provider for embeddings
        query: Search query (optional for date-sorted listing)
        item_types: Filter by item types (task, idea, note, etc.)
        statuses: Filter by statuses (inbox, active, stale, etc.)
        sort_by: Sort order - "similarity", "date_desc", "date_asc"
        limit: Maximum results to return
    
    Returns:
        Dict with query, sort_by, count, and results list
    """
    # Convert string types to enums
    type_enums = [ItemType(t) for t in item_types] if item_types else None
    status_enums = [ItemStatus(s) for s in statuses] if statuses else None
    
    # Smart default: empty query should use date sort (listing, not searching)
    effective_sort = sort_by
    if not query or not query.strip():
        effective_sort = "date_desc" if sort_by == "similarity" else sort_by
    
    # Get results based on sort type
    if effective_sort == "similarity" and query.strip():
        # Semantic search: embed query, find by similarity
        query_embedding, _ = await ai.embed(query)
        results = await db.semantic_search(
            embedding=query_embedding,
            limit=limit,
            item_types=type_enums,
            statuses=status_enums,
        )
    else:
        # Date-sorted: list items with optional type/status filter
        if query.strip():
            # Semantic filter, then temporal sort
            query_embedding, _ = await ai.embed(query)
            semantic_results = await db.semantic_search(
                embedding=query_embedding,
                limit=limit * 3,  # Get more to sort
                item_types=type_enums,
                statuses=status_enums,
            )
            # Re-sort by date
            results = sorted(
                semantic_results,
                key=lambda x: x[0].updated_at or x[0].created_at or "",
                reverse=(effective_sort == "date_desc"),
            )[:limit]
        else:
            # Pure date list, no semantic filter
            items = await db.list_items(
                item_type=type_enums[0] if type_enums and len(type_enums) == 1 else None,
                limit=limit,
                include_deleted=False,
            )
            # Sort by date
            items = sorted(
                items,
                key=lambda x: x.updated_at or x.created_at or "",
                reverse=(effective_sort == "date_desc"),
            )
            # Convert to (item, score) format for consistency
            results = [(item, 0.0) for item in items]
    
    return {
        "success": True,
        "query": query,
        "sort_by": effective_sort,
        "count": len(results),
        "results": [
            _format_search_result(item, score)
            for item, score in results
        ],
    }


def _format_search_result(item, score: float) -> dict[str, Any]:
    """Format a search result for response."""
    content = item.content or {}
    
    # Smart text extraction based on item type
    if item.item_type == ItemType.EMAIL:
        subject = content.get("subject", "(no subject)")
        sender = content.get("from", {})
        if isinstance(sender, dict):
            sender_str = sender.get("email", sender.get("name", "unknown"))
        else:
            sender_str = str(sender)
        body = content.get("body", content.get("body_text", ""))[:100]
        text = f"[EMAIL] {subject} - From: {sender_str} - {body}..."
    else:
        text = content.get("text", "")[:200]
    
    return {
        "id": str(item.id),
        "type": item.item_type.value,
        "status": item.status.value,
        "text": text,
        "similarity": round(score, 3),
    }


# =============================================================================
# CREATE GOAL
# =============================================================================

async def handle_create_goal(
    db: DatabaseProtocol,
    actor: tuple,
    title: str,
    description: Optional[str] = None,
    horizon: str = "medium",
    target_date: Optional[str] = None,
    success_criteria: Optional[list[str]] = None,
    tags: Optional[list[str]] = None,
    source: str = "unknown",
) -> dict[str, Any]:
    """
    Create a new goal item.
    
    Args:
        db: Database client
        actor: Tuple of (ActorType, actor_id) for audit trail
        title: Goal title/text
        description: Optional detailed description
        horizon: Time horizon - "short", "medium", "long"
        target_date: Optional target date (ISO format)
        success_criteria: List of success criteria
        tags: Tags to apply to the goal
        source: Source identifier (e.g., "mcp", "chat")
    
    Returns:
        Dict with success status, goal_id, and message
    """
    content = {
        "text": title,
        "description": description or "",
        "horizon": horizon,
        "success_criteria": success_criteria or [],
    }
    
    if target_date:
        content["target_date"] = target_date
    
    item = await db.create_item(
        ItemCreate(
            item_type=ItemType.GOAL,
            status=ItemStatus.ACTIVE,
            content=content,
            metadata={"source": source, "tags": tags or []},
        ),
        actor=actor,
        reasoning=f"Created goal via {source}: {title[:50]}",
    )
    
    return {
        "success": True,
        "goal_id": str(item.id),
        "message": f"Created {horizon} goal: '{title[:50]}'",
    }
