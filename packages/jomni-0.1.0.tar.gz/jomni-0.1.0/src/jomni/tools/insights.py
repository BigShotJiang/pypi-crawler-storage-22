"""
Insight tool handlers.

Handles: what_now, generate_digest
"""

from datetime import timedelta
from typing import Any

from jomni.models import ItemType, ItemStatus
from jomni.tools.registry import ToolContext, register_handler
from jomni.utils.datetime import utc_now


# =============================================================================
# WHAT NOW
# =============================================================================

@register_handler("what_now")
async def handle_what_now(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """
    Get prioritized items for "what to do now".
    
    Scoring factors:
    - Due date urgency: overdue (+100), today (+50), this week (+20)
    - Goal alignment: items linked to goals (+25)
    - Item type: tasks (+15), habits (+10), ideas (+5)
    - Priority: P1 (+40), P2 (+25), P3 (+10), P4 (+0)
    - Staleness: items needing attention get BONUS not penalty
    """
    limit = args.get("limit", 5)
    
    # Get active items
    active_items = await ctx.db.list_items(status=ItemStatus.ACTIVE, limit=100)
    
    # Score items
    scored_items = []
    now = utc_now()
    
    for item in active_items:
        score = 0
        why = []
        
        # Get due date from content
        due_at = None
        if item.content:
            due_str = item.content.get("due") or item.content.get("due_date")
            if due_str:
                try:
                    from dateutil.parser import parse
                    due_at = parse(due_str)
                    if due_at.tzinfo is None:
                        from datetime import timezone as tz
                        due_at = due_at.replace(tzinfo=tz.utc)
                except (ValueError, TypeError):
                    pass
        
        # Due date urgency
        if due_at:
            if due_at < now:
                score += 100
                why.append("OVERDUE")
            elif due_at.date() == now.date():
                score += 50
                why.append("due today")
            elif due_at < now + timedelta(days=3):
                score += 30
                why.append("due in 3 days")
            elif due_at < now + timedelta(days=7):
                score += 20
                why.append("due this week")
        
        # Goal alignment
        if item.metadata:
            if item.metadata.get("linked_to_goal"):
                score += 25
                why.append("supports goal")
        
        if item.parent_id:
            score += 10
            why.append("linked")
        
        # Item type weighting
        if item.item_type == ItemType.TASK:
            score += 15
            why.append("task")
        elif item.item_type == ItemType.HABIT:
            score += 10
            why.append("habit")
        elif item.item_type == ItemType.IDEA:
            score += 5
            why.append("idea")
        elif item.item_type == ItemType.PROJECT:
            score += 8
            why.append("project")
        
        # Priority from content
        if item.content:
            priority = item.content.get("priority")
            if priority == 1:
                score += 40
                why.append("P1!")
            elif priority == 2:
                score += 25
                why.append("P2")
            elif priority == 3:
                score += 10
                why.append("P3")
        
        # Staleness - items untouched need MORE attention
        days_since_update = 0
        if item.updated_at:
            try:
                updated = item.updated_at
                if updated.tzinfo is None:
                    from datetime import timezone
                    updated = updated.replace(tzinfo=timezone.utc)
                days_since_update = (now - updated).days
            except (TypeError, AttributeError):
                pass
        
        if days_since_update > 14:
            score += 20
            why.append("needs attention (14+ days)")
        elif days_since_update > 7:
            score += 10
            why.append("getting stale")
        elif days_since_update <= 1:
            score += 5
            why.append("recent")
        
        scored_items.append({
            "id": str(item.id),
            "text": item.content.get("text", "")[:100] if item.content else "",
            "item_type": item.item_type.value,
            "score": score,
            "why": ", ".join(why) if why else "active item",
        })
    
    # Sort by score descending
    scored_items.sort(key=lambda x: x["score"], reverse=True)
    
    # Get blocked items (status=waiting)
    waiting_items = await ctx.db.list_items(status=ItemStatus.WAITING, limit=20)
    blocked = [
        {
            "id": str(item.id),
            "text": item.content.get("text", "")[:100] if item.content else "",
            "item_type": item.item_type.value,
            "why": "waiting",
        }
        for item in waiting_items
    ]
    
    return {
        "focus": scored_items[:limit],
        "blocked": blocked[:5],
    }


# =============================================================================
# GENERATE DIGEST
# =============================================================================

@register_handler("generate_digest")
async def handle_generate_digest(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Generate a daily digest with item counts and status."""
    now = utc_now()
    
    # Helper to safely compare datetimes
    def safe_compare(dt, threshold, less_than=True):
        if not dt:
            return False
        try:
            if dt.tzinfo is None:
                from datetime import timezone
                dt = dt.replace(tzinfo=timezone.utc)
            return dt < threshold if less_than else dt > threshold
        except (TypeError, AttributeError):
            return False
    
    def safe_date_compare(dt, target_date):
        if not dt:
            return False
        try:
            return dt.date() == target_date
        except (TypeError, AttributeError):
            return False
    
    def get_due_date(item):
        if not item.content:
            return None
        due_str = item.content.get("due") or item.content.get("due_date")
        if due_str:
            try:
                from dateutil.parser import parse
                return parse(due_str)
            except (ValueError, TypeError):
                pass
        return None
    
    # Get counts
    inbox = await ctx.db.get_inbox(limit=100)
    active = await ctx.db.list_items(status=ItemStatus.ACTIVE, limit=500)
    goals = await ctx.db.list_items(item_type=ItemType.GOAL, status=ItemStatus.ACTIVE, limit=50)
    stale = await ctx.db.list_items(status=ItemStatus.STALE, limit=50)
    
    # Calculate stale items (updated > 14 days ago)
    stale_threshold = now - timedelta(days=14)
    stale_count = len([i for i in active if safe_compare(i.updated_at, stale_threshold, less_than=True)])
    
    # Goal progress summary
    goal_summary = [
        {
            "title": goal.content.get("text", "")[:50],
            "progress": goal.metadata.get("progress", 0) if goal.metadata else 0,
            "horizon": goal.metadata.get("horizon", "medium") if goal.metadata else "medium",
        }
        for goal in goals
    ]
    
    # Due today
    due_today = [
        item for item in active
        if safe_date_compare(get_due_date(item), now.date())
    ]
    
    # Count overdue
    overdue_count = len([
        i for i in active
        if safe_compare(get_due_date(i), now, less_than=True)
    ])
    
    return {
        "date": now.date().isoformat(),
        "counts": {
            "inbox": len(inbox),
            "active": len(active),
            "goals": len(goals),
            "stale": len(stale) + stale_count,
            "due_today": len(due_today),
        },
        "goals": goal_summary,
        "attention_needed": {
            "overdue": overdue_count,
            "stale_items": stale_count,
        },
        # Legacy summary key used by test
        "summary": {
            "active": len(active),
            "inbox": len(inbox),
            "completed_today": 0,
        },
    }
