"""
Integration tool handlers (Google, etc.).

Handles: connect_google, sync_calendar, sync_gmail, sync_emails, list_emails,
         draft_reply, send_reply, archive_email, sync_contacts
"""

import logging
from typing import Any
from uuid import UUID

from jomni.config import get_settings
from jomni.models import ItemType
from jomni.tools.registry import ToolContext, register_handler

logger = logging.getLogger(__name__)


# =============================================================================
# CONNECT GOOGLE
# =============================================================================

@register_handler("connect_google")
async def handle_connect_google(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Connect to Google services (Calendar, Gmail, Contacts)."""
    try:
        from jomni.api.auth import get_google_flow
        
        settings = get_settings()
        if not settings.google_client_id or not settings.google_client_secret:
            return {
                "error": "Google OAuth not configured",
                "action": "Set JOMNI_GOOGLE_CLIENT_ID and JOMNI_GOOGLE_CLIENT_SECRET in environment"
            }
        
        flow = get_google_flow()
        auth_url, _ = flow.authorization_url(
            access_type="offline",
            prompt="consent"
        )
        return {
            "auth_url": auth_url,
            "message": "Visit this URL in a browser to authorize Google access",
        }
    except Exception as e:
        error_msg = str(e) or repr(e) or type(e).__name__
        logger.error(f"connect_google failed: {type(e).__name__}: {e}")
        return {"error": f"Failed to generate auth URL: {error_msg}"}


# =============================================================================
# SYNC CALENDAR
# =============================================================================

@register_handler("sync_calendar")
async def handle_sync_calendar(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Sync Google Calendar events to Jomni."""
    days_past = args.get("days_past", 30)
    days_future = args.get("days_future", 90)
    
    try:
        from jomni.integrations.google.auth import GoogleAuth
        from jomni.integrations.google.calendar import CalendarSync
        
        auth = GoogleAuth(ctx.db)
        
        if not await auth.is_connected():
            return {
                "error": "Not connected to Google",
                "action": "Visit /auth/google/start to authenticate",
            }
        
        creds = await auth.get_valid_credentials()
        if not creds:
            return {
                "error": "OAuth token expired and refresh failed",
                "action": "Visit /auth/google/start to re-authenticate",
            }
        
        calendar_sync = CalendarSync(ctx.db, auth)
        return await calendar_sync.sync(days_past=days_past, days_future=days_future)
        
    except Exception as e:
        error_msg = str(e) or repr(e) or type(e).__name__
        logger.error(f"Calendar sync failed: {type(e).__name__}: {e}")
        return {"error": f"Calendar sync failed: {error_msg}"}


# =============================================================================
# SYNC GMAIL / SYNC EMAILS
# =============================================================================

@register_handler("sync_gmail")
@register_handler("sync_emails")
async def handle_sync_emails(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Sync emails from Gmail to Jomni."""
    max_results = min(args.get("max_results", 50), 500)  # Cap at 500
    
    try:
        from jomni.integrations.google.auth import GoogleAuth
        from jomni.integrations.google.gmail import GmailSync
        
        auth = GoogleAuth(ctx.db)
        
        if not await auth.is_connected():
            return {
                "error": "Not connected to Google",
                "action": "Visit /auth/google/start to authenticate",
            }
        
        creds = await auth.get_valid_credentials()
        if not creds:
            return {
                "error": "OAuth token expired and refresh failed",
                "action": "Visit /auth/google/start to re-authenticate",
            }
        
        gmail_sync = GmailSync(ctx.db, auth)
        return await gmail_sync.sync(max_results=max_results)
        
    except Exception as e:
        error_msg = str(e) or repr(e) or type(e).__name__
        logger.error(f"Gmail sync failed: {type(e).__name__}: {e}")
        return {"error": f"Gmail sync failed: {error_msg}"}


# =============================================================================
# LIST EMAILS
# =============================================================================

@register_handler("list_emails")
async def handle_list_emails(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """List synced emails from the database."""
    limit = args.get("limit", 20)
    unread_only = args.get("unread_only", False)
    
    emails = await ctx.db.list_items(item_type=ItemType.EMAIL, limit=limit)
    
    if unread_only:
        emails = [e for e in emails if e.metadata.get("unread", False)]
    
    return {
        "count": len(emails),
        "emails": [
            {
                "id": str(e.id),
                "subject": e.content.get("subject", ""),
                "from": e.content.get("from", ""),
                "date": str(e.content.get("date", "")),
                "unread": e.metadata.get("unread", False),
            }
            for e in emails
        ],
    }


# =============================================================================
# DRAFT REPLY
# =============================================================================

@register_handler("draft_reply")
async def handle_draft_reply(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Create a draft reply to an email."""
    item_id = args.get("item_id")
    body = args.get("body", "")
    include_quote = args.get("include_quote", True)
    
    if not item_id or not body:
        return {"error": "item_id and body are required"}
    
    try:
        from jomni.integrations.google.auth import GoogleAuth
        from jomni.integrations.google.gmail import GmailSync
        
        auth = GoogleAuth(ctx.db)
        if not await auth.is_connected():
            return {"error": "Not connected to Google"}
        
        gmail_sync = GmailSync(ctx.db, auth)
        return await gmail_sync.draft_reply(UUID(item_id), body, include_quote)
        
    except Exception as e:
        error_msg = str(e) or repr(e) or type(e).__name__
        logger.error(f"Draft reply failed: {type(e).__name__}: {e}")
        return {"error": f"Draft reply failed: {error_msg}"}


# =============================================================================
# SEND REPLY
# =============================================================================

@register_handler("send_reply")
async def handle_send_reply(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Send a reply to an email immediately."""
    item_id = args.get("item_id")
    body = args.get("body", "")
    
    if not item_id or not body:
        return {"error": "item_id and body are required"}
    
    try:
        from jomni.integrations.google.auth import GoogleAuth
        from jomni.integrations.google.gmail import GmailSync
        
        auth = GoogleAuth(ctx.db)
        if not await auth.is_connected():
            return {"error": "Not connected to Google"}
        
        gmail_sync = GmailSync(ctx.db, auth)
        return await gmail_sync.send_reply(UUID(item_id), body)
        
    except Exception as e:
        logger.error(f"Send reply failed: {e}")
        return {"error": str(e)}


# =============================================================================
# ARCHIVE EMAIL
# =============================================================================

@register_handler("archive_email")
async def handle_archive_email(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Archive an email (remove from INBOX in Gmail)."""
    item_id = args.get("item_id")
    
    if not item_id:
        return {"error": "item_id is required"}
    
    try:
        from jomni.integrations.google.auth import GoogleAuth
        from jomni.integrations.google.gmail import GmailSync
        
        auth = GoogleAuth(ctx.db)
        if not await auth.is_connected():
            return {"error": "Not connected to Google"}
        
        gmail_sync = GmailSync(ctx.db, auth)
        await gmail_sync.archive_email(UUID(item_id))
        
        return {"success": True, "item_id": item_id, "message": "Email archived"}
        
    except Exception as e:
        error_msg = str(e) or repr(e) or type(e).__name__
        logger.error(f"Archive email failed: {type(e).__name__}: {e}")
        return {"error": f"Archive email failed: {error_msg}"}


# =============================================================================
# SYNC CONTACTS
# =============================================================================

@register_handler("sync_contacts")
async def handle_sync_contacts(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Sync contacts from Google Contacts to Jomni."""
    full_sync = args.get("full_sync", False)
    
    try:
        from jomni.integrations.google.auth import GoogleAuth
        from jomni.integrations.google.contacts import ContactsSync
        
        auth = GoogleAuth(ctx.db)
        
        if not await auth.is_connected():
            return {
                "error": "Not connected to Google",
                "action": "Visit /auth/google/start to authenticate",
            }
        
        creds = await auth.get_valid_credentials()
        if not creds:
            return {
                "error": "OAuth token expired and refresh failed",
                "action": "Visit /auth/google/start to re-authenticate",
            }
        
        contacts_sync = ContactsSync(ctx.db, auth)
        return await contacts_sync.sync(full_sync=full_sync)
        
    except Exception as e:
        error_msg = str(e) or repr(e) or type(e).__name__
        logger.error(f"Contacts sync failed: {type(e).__name__}: {e}")
        return {"error": f"Contacts sync failed: {error_msg}"}
