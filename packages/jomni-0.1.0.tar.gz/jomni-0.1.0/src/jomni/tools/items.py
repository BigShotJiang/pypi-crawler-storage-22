"""
Item CRUD tool handlers.

Handles: list_inbox, list_items, update_item, delete_item, delete_items,
         bulk_update_items, complete_item, restore_item, record_correction
"""

import logging
from typing import Any
from uuid import UUID

from jomni.models import ItemType, ItemStatus, ItemUpdate
from jomni.tools.registry import ToolContext, register_handler
from jomni.tools.handlers import (
    handle_complete_item as _handle_complete_core,
    handle_delete_item as _handle_delete_core,
    handle_restore_item as _handle_restore_core,
)

logger = logging.getLogger(__name__)


# =============================================================================
# LIST INBOX
# =============================================================================

@register_handler("list_inbox")
async def handle_list_inbox(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """List all items in the inbox awaiting triage."""
    limit = args.get("limit", 50)
    inbox_items = await ctx.db.get_inbox(limit=limit)
    
    return {
        "count": len(inbox_items),
        "items": [
            {
                "id": str(item.id),
                "text": item.content.get("text", "")[:200],
                "created_at": str(item.created_at),
            }
            for item in inbox_items
        ],
    }


# =============================================================================
# LIST ITEMS
# =============================================================================

@register_handler("list_items")
async def handle_list_items(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """List items with optional filters."""
    item_type = args.get("item_type")
    status = args.get("status")
    limit = args.get("limit", 50)
    offset = args.get("offset", 0)
    
    items = await ctx.db.list_items(
        item_type=ItemType(item_type) if item_type else None,
        status=ItemStatus(status) if status else None,
        limit=limit,
        offset=offset,
    )
    
    return {
        "count": len(items),
        "items": [
            {
                "id": str(item.id),
                "type": item.item_type.value,
                "status": item.status.value,
                "text": (item.content.get("text", "") or item.content.get("title", ""))[:200] if item.content else "",
                "created_at": str(item.created_at),
            }
            for item in items
        ],
    }


# =============================================================================
# UPDATE ITEM
# =============================================================================

@register_handler("update_item")
async def handle_update_item(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Update an existing item's properties."""
    item_id = args.get("item_id")
    if not item_id:
        return {"error": "item_id is required"}
    
    updates = {}
    if "text" in args:
        updates["content"] = {"text": args["text"]}
    if "title" in args:
        updates["title"] = args["title"]
    if "status" in args:
        updates["status"] = ItemStatus(args["status"])
    if "due_at" in args:
        updates["due_at"] = args["due_at"]
    if "tags" in args:
        updates["tags"] = args["tags"]
    
    await ctx.db.update_item(
        UUID(item_id),
        ItemUpdate(**updates),
        actor=ctx.actor,
        reasoning=args.get("reasoning", "Updated via MCP"),
    )
    
    return {"success": True, "item_id": item_id}


# =============================================================================
# COMPLETE ITEM
# =============================================================================

@register_handler("complete_item")
async def handle_complete_item(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Mark an item as completed."""
    return await _handle_complete_core(
        ctx.db, ctx.actor,
        item_id=args.get("item_id"),
        reasoning=args.get("reasoning"),
    )


# =============================================================================
# DELETE ITEM
# =============================================================================

@register_handler("delete_item")
async def handle_delete_item(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Soft delete a single item."""
    return await _handle_delete_core(
        ctx.db, ctx.actor,
        item_id=args.get("item_id"),
        reasoning=args.get("reasoning"),
    )


# =============================================================================
# DELETE ITEMS (BULK)
# =============================================================================

@register_handler("delete_items")
async def handle_delete_items(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Soft delete multiple items."""
    item_ids = args.get("item_ids", [])
    if not item_ids:
        return {"error": "item_ids is required"}
    
    deleted_count = 0
    for item_id in item_ids:
        try:
            await ctx.db.delete_item(
                UUID(item_id),
                actor=ctx.actor,
                reasoning="Deleted via MCP bulk operation",
            )
            deleted_count += 1
        except Exception as e:
            logger.warning(f"Failed to delete {item_id}: {e}")
    
    return {"success": True, "deleted_count": deleted_count}


# =============================================================================
# BULK UPDATE ITEMS
# =============================================================================

@register_handler("bulk_update_items")
async def handle_bulk_update_items(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Bulk update items matching filters."""
    set_status = args.get("set_status")
    if not set_status:
        return {"error": "set_status is required"}
    
    filter_type = args.get("filter_type")
    filter_status = args.get("filter_status")
    limit = args.get("limit", 1000)
    reasoning = args.get("reasoning", "Bulk update via MCP")
    
    updated_count = await ctx.db.bulk_update_items(
        set_status=ItemStatus(set_status),
        filter_type=ItemType(filter_type) if filter_type else None,
        filter_status=ItemStatus(filter_status) if filter_status else None,
        limit=limit,
        actor=ctx.actor,
        reasoning=reasoning,
    )
    
    return {
        "success": True,
        "updated_count": updated_count,
        "set_status": set_status,
    }


# =============================================================================
# RESTORE ITEM
# =============================================================================

@register_handler("restore_item")
async def handle_restore_item(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Restore a soft-deleted item."""
    return await _handle_restore_core(
        ctx.db, ctx.actor,
        item_id=args.get("item_id"),
    )


# =============================================================================
# RECORD CORRECTION
# =============================================================================

@register_handler("record_correction")
async def handle_record_correction(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Record a user correction to an AI suggestion."""
    item_id = UUID(args.get("item_id"))
    original_type = args.get("original_type")
    corrected_type = args.get("corrected_type")
    
    # Get the item to store the correction
    item = await ctx.db.get_item(item_id)
    if not item:
        return {"success": False, "error": "Item not found"}
    
    # Embed the input for future similarity matching
    text = item.content.get("text", "")
    embedding, _ = await ctx.ai.embed(text) if text else (None, None)
    
    # ╔═══════════════════════════════════════════════════════════════════════╗
    # ║ CRITICAL: AI TRAINING CONSENT CHECK (GDPR Requirement)                ║
    # ║                                                                       ║
    # ║ DO NOT store corrections without consent.                             ║
    # ║ DO NOT bypass this check for any reason.                              ║
    # ║ See: backend/PRIVACY.md for full documentation.                       ║
    # ╚═══════════════════════════════════════════════════════════════════════╝
    from jomni.api.preferences import has_ai_training_consent
    
    # has_ai_training_consent() is FAIL-CLOSED: errors = no consent
    if await has_ai_training_consent(ctx.db):
        logger.info(f"Storing MCP correction for item {item_id} (consent granted)")
        await ctx.db.store_correction(
            item_id=item_id,
            input_text=text,
            ai_suggestion={"item_type": original_type},
            user_correction={"item_type": corrected_type},
            correction_type="classification",
            input_embedding=embedding,
        )
    else:
        logger.debug(f"Skipped MCP correction storage for {item_id} (no consent)")
    
    # Update the item
    await ctx.db.update_item(
        item_id,
        ItemUpdate(item_type=ItemType(corrected_type)),
        actor=ctx.actor,
        reasoning=f"User corrected from {original_type} to {corrected_type}",
    )
    
    return {
        "success": True,
        "message": f"Recorded correction: {original_type} → {corrected_type}",
    }
