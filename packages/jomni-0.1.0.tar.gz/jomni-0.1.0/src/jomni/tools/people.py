"""
People & Delegation tool handlers.

Handles: list_people, search_people, create_person, get_person, set_importance,
         delegate_item, list_delegations, complete_delegation
"""

from typing import Any
from uuid import UUID

from jomni.models import ItemType, ItemStatus, ItemCreate, ItemUpdate
from jomni.tools.registry import ToolContext, register_handler
from jomni.tools.handlers import handle_search as _handle_search_core
from jomni.utils.datetime import utc_now


# =============================================================================
# LIST PEOPLE
# =============================================================================

@register_handler("list_people")
async def handle_list_people(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """List people from the database."""
    limit = args.get("limit", 20)
    sort_by_importance = args.get("sort_by_importance", False)
    
    people = await ctx.db.list_items(item_type=ItemType.PERSON, limit=limit)
    
    if sort_by_importance:
        people = sorted(people, key=lambda p: p.metadata.get("importance", 0), reverse=True)
    
    return {
        "count": len(people),
        "people": [
            {
                "id": str(p.id),
                "name": p.content.get("name", ""),
                "email": p.content.get("email", ""),
                "importance": p.metadata.get("importance", 0),
            }
            for p in people
        ],
    }


# =============================================================================
# SEARCH PEOPLE
# =============================================================================

@register_handler("search_people")
async def handle_search_people(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Semantic search for people by name, role, or organization."""
    return await _handle_search_core(
        ctx.db, ctx.ai,
        query=args.get("query", ""),
        item_types=["person"],
        limit=args.get("limit", 10),
    )


# =============================================================================
# CREATE PERSON
# =============================================================================

@register_handler("create_person")
async def handle_create_person(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Create a new person in the database."""
    name_val = args.get("name", "")
    email = args.get("email", "")
    importance = args.get("importance", 0)
    
    item = await ctx.db.create_item(
        ItemCreate(
            item_type=ItemType.PERSON,
            status=ItemStatus.ACTIVE,
            content={"name": name_val, "email": email, "text": name_val},
            metadata={"importance": importance},
        ),
        actor=ctx.actor,
        reasoning="Person created via MCP",
    )
    
    return {"success": True, "person_id": str(item.id)}


# =============================================================================
# GET PERSON
# =============================================================================

@register_handler("get_person")
async def handle_get_person(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Get a person by ID."""
    person_id = args.get("person_id")
    if not person_id:
        return {"error": "person_id is required"}
    
    person = await ctx.db.get_item(UUID(person_id))
    if not person:
        return {"error": "Person not found"}
    
    return {
        "id": str(person.id),
        "name": person.content.get("name", ""),
        "email": person.content.get("email", ""),
        "importance": person.metadata.get("importance", 0),
        "metadata": person.metadata,
    }


# =============================================================================
# SET IMPORTANCE
# =============================================================================

@register_handler("set_importance")
async def handle_set_importance(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Set the importance level of a person."""
    person_id = args.get("person_id")
    importance = args.get("importance")
    
    if not person_id or importance is None:
        return {"error": "person_id and importance are required"}
    
    person = await ctx.db.get_item(UUID(person_id))
    if not person:
        return {"error": "Person not found"}
    
    new_meta = {**(person.metadata or {}), "importance": importance}
    await ctx.db.update_item(
        UUID(person_id),
        ItemUpdate(metadata=new_meta),
        actor=ctx.actor,
        reasoning=f"Set importance to {importance}",
    )
    
    return {"success": True, "person_id": person_id, "importance": importance}


# =============================================================================
# DELEGATE ITEM
# =============================================================================

@register_handler("delegate_item")
async def handle_delegate_item(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Delegate an item to a person and track for follow-up."""
    item_id = args.get("item_id")
    person_id = args.get("person_id")
    due_at = args.get("due_at")
    
    if not item_id or not person_id:
        return {"error": "item_id and person_id are required"}
    
    item = await ctx.db.get_item(UUID(item_id))
    if not item:
        return {"error": "Item not found"}
    
    new_meta = {
        **(item.metadata or {}),
        "delegated_to": person_id,
        "delegated_at": utc_now().isoformat(),
    }
    updates = {
        "status": ItemStatus.WAITING,
        "metadata": new_meta,
    }
    if due_at:
        updates["due_at"] = due_at
    
    await ctx.db.update_item(
        UUID(item_id),
        ItemUpdate(**updates),
        actor=ctx.actor,
        reasoning=f"Delegated to {person_id}",
    )
    
    return {"success": True, "item_id": item_id, "delegated_to": person_id}


# =============================================================================
# LIST DELEGATIONS
# =============================================================================

@register_handler("list_delegations")
async def handle_list_delegations(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """List items delegated to others."""
    status_filter = args.get("status", "pending")
    
    waiting_items = await ctx.db.list_items(status=ItemStatus.WAITING, limit=100)
    delegations = [
        item for item in waiting_items
        if item.metadata and item.metadata.get("delegated_to")
    ]
    
    if status_filter == "completed":
        delegations = [d for d in delegations if d.metadata.get("delegation_completed")]
    elif status_filter == "pending":
        delegations = [d for d in delegations if not d.metadata.get("delegation_completed")]
    
    return {
        "count": len(delegations),
        "delegations": [
            {
                "id": str(d.id),
                "text": d.content.get("text", "")[:100],
                "delegated_to": d.metadata.get("delegated_to"),
                "delegated_at": d.metadata.get("delegated_at"),
                "due_at": d.content.get("due") or d.metadata.get("due_at") if d.content else None,
            }
            for d in delegations
        ],
    }


# =============================================================================
# COMPLETE DELEGATION
# =============================================================================

@register_handler("complete_delegation")
async def handle_complete_delegation(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Mark a delegated item as completed."""
    item_id = args.get("item_id")
    if not item_id:
        return {"error": "item_id is required"}
    
    item = await ctx.db.get_item(UUID(item_id))
    if not item:
        return {"error": "Item not found"}
    
    new_meta = {
        **(item.metadata or {}),
        "delegation_completed": True,
        "completed_at": utc_now().isoformat(),
    }
    await ctx.db.update_item(
        UUID(item_id),
        ItemUpdate(status=ItemStatus.COMPLETED, metadata=new_meta),
        actor=ctx.actor,
        reasoning="Delegation completed",
    )
    
    return {"success": True, "item_id": item_id}
