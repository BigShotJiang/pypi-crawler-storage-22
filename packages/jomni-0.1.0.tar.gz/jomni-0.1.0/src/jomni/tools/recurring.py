"""
Recurring/Habit tool handlers.

Handles: create_recurring, list_habits, complete_recurring
"""

from typing import Any
from uuid import UUID

from jomni.models import ItemType, ItemStatus, ItemCreate, ItemUpdate
from jomni.tools.registry import ToolContext, register_handler
from jomni.utils.datetime import utc_now


# =============================================================================
# CREATE RECURRING
# =============================================================================

@register_handler("create_recurring")
async def handle_create_recurring(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Create a recurring item (habit, routine)."""
    title = args.get("title", "")
    frequency = args.get("frequency", "daily")
    
    item = await ctx.db.create_item(
        ItemCreate(
            item_type=ItemType.HABIT,
            status=ItemStatus.ACTIVE,
            content={"text": title},
            metadata={"frequency": frequency, "completions": []},
        ),
        actor=ctx.actor,
        reasoning="Recurring item created via MCP",
    )
    
    return {"success": True, "item_id": str(item.id), "frequency": frequency}


# =============================================================================
# LIST HABITS
# =============================================================================

@register_handler("list_habits")
async def handle_list_habits(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """List recurring habits/items."""
    limit = args.get("limit", 50)
    
    habits = await ctx.db.list_items(item_type=ItemType.HABIT, limit=limit)
    
    return {
        "count": len(habits),
        "habits": [
            {
                "id": str(h.id),
                "title": h.content.get("text", ""),
                "frequency": h.metadata.get("frequency", "daily"),
                "completions_count": len(h.metadata.get("completions", [])),
            }
            for h in habits
        ],
    }


# =============================================================================
# COMPLETE RECURRING
# =============================================================================

@register_handler("complete_recurring")
async def handle_complete_recurring(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Complete today's instance of a recurring item."""
    item_id = args.get("item_id")
    if not item_id:
        return {"error": "item_id is required"}
    
    item = await ctx.db.get_item(UUID(item_id))
    if not item:
        return {"error": "Item not found"}
    
    completions = item.metadata.get("completions", [])
    completions.append({"completed_at": utc_now().isoformat()})
    new_meta = {**(item.metadata or {}), "completions": completions}
    
    await ctx.db.update_item(
        UUID(item_id),
        ItemUpdate(metadata=new_meta),
        actor=ctx.actor,
        reasoning="Recurring item completed",
    )
    
    return {
        "success": True,
        "item_id": item_id,
        "total_completions": len(completions),
    }
