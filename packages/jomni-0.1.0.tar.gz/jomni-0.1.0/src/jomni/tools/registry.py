"""
Tool handler registry.

Maps tool names to their handler functions.
Handlers are registered from category modules on import.

Usage:
    from jomni.tools.registry import TOOL_HANDLERS, register_handler
    
    # Register a handler
    @register_handler("my_tool")
    async def handle_my_tool(ctx: ToolContext, args: dict) -> dict:
        ...
    
    # Or register manually
    register_handler("my_tool", handle_my_tool)
    
    # Look up and call
    handler = TOOL_HANDLERS.get("capture")
    result = await handler(ctx, args)
"""

from dataclasses import dataclass
from typing import Any, Callable, Awaitable, Optional

from jomni.db.protocol import DatabaseProtocol
from jomni.ai.provider import AIProvider


@dataclass
class ToolContext:
    """
    Context passed to all tool handlers.
    
    Bundles db, ai, and actor so handlers have a consistent interface
    and we don't have to pass 3+ args to every function.
    """
    db: DatabaseProtocol
    ai: AIProvider
    actor: tuple  # (ActorType, actor_id)


# Type alias for handler functions
ToolHandler = Callable[[ToolContext, dict[str, Any]], Awaitable[dict[str, Any]]]

# The registry - maps tool name -> handler function
TOOL_HANDLERS: dict[str, ToolHandler] = {}


def register_handler(name: str, handler: Optional[ToolHandler] = None):
    """
    Register a tool handler.
    
    Can be used as a decorator or called directly:
    
        @register_handler("capture")
        async def handle_capture(ctx, args):
            ...
        
        # OR
        
        register_handler("capture", handle_capture)
    """
    def decorator(fn: ToolHandler) -> ToolHandler:
        TOOL_HANDLERS[name] = fn
        return fn
    
    if handler is not None:
        # Called as register_handler("name", fn)
        TOOL_HANDLERS[name] = handler
        return handler
    
    # Called as @register_handler("name")
    return decorator


def register_handlers(handlers: dict[str, ToolHandler]):
    """Bulk register multiple handlers."""
    TOOL_HANDLERS.update(handlers)


# =============================================================================
# Import all handler modules to trigger registration
# =============================================================================
# These imports have side effects - they register handlers on import.
# Order doesn't matter since each module is independent.

def _load_all_handlers():
    """Load all handler modules to populate the registry."""
    # Import here to avoid circular imports and ensure registry exists first
    from jomni.tools import (
        capture,
        items,
        search,
        insights,
        goals,
        tags,
        integrations,
        people,
        recurring,
        scheduler,
    )


# Don't auto-load on import - let server.py control when to load
# This avoids import errors during testing when not all deps are available
