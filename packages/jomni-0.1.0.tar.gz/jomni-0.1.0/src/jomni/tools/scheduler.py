"""
Scheduler tool handlers.

Handles: list_scheduled_jobs, run_job_now, list_job_history
"""

from typing import Any

from jomni.tools.registry import ToolContext, register_handler


# =============================================================================
# LIST SCHEDULED JOBS
# =============================================================================

@register_handler("list_scheduled_jobs")
async def handle_list_scheduled_jobs(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """List all scheduled background jobs and their status."""
    from jomni.scheduler.jobs import get_job_info
    
    jobs = get_job_info()
    return {"jobs": jobs}


# =============================================================================
# RUN JOB NOW
# =============================================================================

@register_handler("run_job_now")
async def handle_run_job_now(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Manually trigger a scheduled job immediately."""
    job_id = args.get("job_id")
    if not job_id:
        return {"error": "job_id is required"}
    
    from jomni.scheduler.jobs import run_job_now as trigger_job
    
    return await trigger_job(job_id)


# =============================================================================
# LIST JOB HISTORY
# =============================================================================

@register_handler("list_job_history")
async def handle_list_job_history(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """List recent job execution history."""
    limit = args.get("limit", 20)
    
    from jomni.scheduler.jobs import get_job_history
    
    history = await get_job_history(limit)
    return {"history": history}
