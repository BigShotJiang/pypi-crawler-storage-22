"""
Unified tool schema definitions for Jomni.

Single source of truth for all tool schemas. Provides converters
to generate both MCP (mcp.types.Tool) and Anthropic (dict) formats.

ARCHITECTURE:
    This module eliminates duplication between MCP and Chat API tool definitions.
    Both APIs now reference these schemas, ensuring consistent tool signatures.
    
    Flow:
        ToolSchema → to_mcp()      → MCP server (stdio)
        ToolSchema → to_anthropic() → Chat API (HTTP)

USAGE:
    # For MCP server (mcp/server.py)
    from jomni.tools.schemas import get_mcp_tools
    tools = get_mcp_tools()  # Returns list[mcp.types.Tool]
    
    # For Chat API (api/chat/tools.py)  
    from jomni.tools.schemas import get_anthropic_tools
    tools = get_anthropic_tools()  # Returns list[dict] with input_schema

ADDING NEW TOOLS:
    1. Create a ToolSchema instance with ToolParam definitions
    2. Add it to CORE_TOOLS list at the bottom
    3. Both MCP and Chat API will automatically include it
    
    For API-specific tools (e.g., Google integration), add them in:
    - MCP: mcp/tools/definitions.py
    - Chat: api/chat/tools.py (EXTENDED_TOOLS list)

See Also:
    - jomni/tools/handlers.py: Shared handler implementations
    - jomni/mcp/server.py: MCP server using get_mcp_tools()
    - jomni/api/chat/tools.py: Chat API using get_anthropic_tools()
"""

from typing import Any
from dataclasses import dataclass, field


@dataclass
class ToolParam:
    """
    A single tool parameter definition.
    
    Attributes:
        name: Parameter name (used as JSON key)
        type: JSON Schema type: "string", "integer", "boolean", "array", "object"
        description: Human-readable description for AI context
        required: If True, parameter must be provided
        enum: Optional list of allowed values
        default: Default value if not provided
        items: For array types, schema of array items
        properties: For object types, nested property schemas
        additional_properties: If True, object allows extra keys
    """
    name: str
    type: str  # "string", "integer", "boolean", "array", "object"
    description: str
    required: bool = False
    enum: list[str] | None = None
    default: Any = None
    items: dict[str, Any] | None = None  # For array types
    properties: dict[str, Any] | None = None  # For object types
    additional_properties: bool = False


@dataclass  
class ToolSchema:
    """
    Format-agnostic tool definition that converts to MCP or Anthropic format.
    
    This is the single source of truth for tool schemas. Define tools once here,
    then use to_mcp() or to_anthropic() to generate the appropriate format.
    
    Attributes:
        name: Unique tool identifier (snake_case, e.g., "capture", "delete_item")
        description: What the tool does (shown to AI for tool selection)
        params: List of ToolParam definitions
        
    Example:
        >>> tool = ToolSchema(
        ...     name="capture",
        ...     description="Add a new item to the inbox.",
        ...     params=[ToolParam("text", "string", "Content to capture", required=True)]
        ... )
        >>> mcp_tool = tool.to_mcp()      # mcp.types.Tool
        >>> anthropic_tool = tool.to_anthropic()  # dict with input_schema
    """
    name: str
    description: str
    params: list[ToolParam] = field(default_factory=list)
    
    def to_mcp(self) -> "Tool":
        """Convert to MCP Tool format."""
        from mcp.types import Tool
        
        properties = {}
        required = []
        
        for param in self.params:
            prop: dict[str, Any] = {
                "type": param.type,
                "description": param.description,
            }
            if param.enum:
                prop["enum"] = param.enum
            if param.default is not None:
                prop["default"] = param.default
            if param.items:
                prop["items"] = param.items
            if param.properties:
                prop["properties"] = param.properties
            if param.additional_properties:
                prop["additionalProperties"] = True
            
            properties[param.name] = prop
            if param.required:
                required.append(param.name)
        
        schema: dict[str, Any] = {
            "type": "object",
            "properties": properties,
        }
        if required:
            schema["required"] = required
        
        return Tool(
            name=self.name,
            description=self.description,
            inputSchema=schema,
        )
    
    def to_anthropic(self) -> dict[str, Any]:
        """Convert to Anthropic tool format."""
        properties = {}
        required = []
        
        for param in self.params:
            prop: dict[str, Any] = {
                "type": param.type,
                "description": param.description,
            }
            if param.enum:
                prop["enum"] = param.enum
            if param.default is not None:
                prop["default"] = param.default
            if param.items:
                prop["items"] = param.items
            if param.properties:
                prop["properties"] = param.properties
            if param.additional_properties:
                prop["additionalProperties"] = True
            
            properties[param.name] = prop
            if param.required:
                required.append(param.name)
        
        input_schema: dict[str, Any] = {
            "type": "object",
            "properties": properties,
        }
        if required:
            input_schema["required"] = required
        
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": input_schema,
        }


# =============================================================================
# TOOL DEFINITIONS
# =============================================================================

# Capture & Triage
CAPTURE = ToolSchema(
    name="capture",
    description="Add a new item to the inbox for later triage. Use for quick capture of tasks, ideas, notes, or anything else.",
    params=[
        ToolParam("text", "string", "The text content to capture", required=True),
        ToolParam("context", "object", "Optional context hints (e.g., source, related_to)", additional_properties=True),
    ]
)

TRIAGE = ToolSchema(
    name="triage",
    description="Classify a capture into the appropriate type (task, idea, note, etc.) with a confidence score.",
    params=[
        ToolParam("text", "string", "The text to classify", required=True),
        ToolParam("context", "object", "Optional context for better classification", additional_properties=True),
    ]
)

ACCEPT_TRIAGE = ToolSchema(
    name="accept_triage",
    description="Accept a triage suggestion and create the item.",
    params=[
        ToolParam("text", "string", "The item text", required=True),
        ToolParam("item_type", "string", "The accepted type", required=True,
                  enum=["task", "idea", "note", "habit", "goal", "project", "reference", "event"]),
        ToolParam("tags", "array", "Optional tags to apply", items={"type": "string"}),
    ]
)

BULK_CAPTURE = ToolSchema(
    name="bulk_capture",
    description="Capture multiple items in one call. Use for imports and batch ingestion.",
    params=[
        ToolParam("items", "array", "List of items to capture", required=True,
                  items={"type": "object", "properties": {"text": {"type": "string"}, "context": {"type": "object"}}, "required": ["text"]}),
    ]
)

# Item CRUD
LIST_INBOX = ToolSchema(
    name="list_inbox",
    description="List all items in the inbox awaiting triage.",
    params=[
        ToolParam("limit", "integer", "Maximum number of items to return", default=50),
    ]
)

LIST_ITEMS = ToolSchema(
    name="list_items",
    description="List items with optional filters. Use to browse items by type or status.",
    params=[
        ToolParam("item_type", "string", "Filter by type",
                  enum=["task", "idea", "note", "habit", "goal", "project", "reference", "event", "email", "person", "capture"]),
        ToolParam("status", "string", "Filter by status",
                  enum=["inbox", "active", "waiting", "stale", "archived", "completed", "deleted"]),
        ToolParam("limit", "integer", "Maximum items to return", default=50),
        ToolParam("offset", "integer", "Offset for pagination", default=0),
    ]
)

COMPLETE_ITEM = ToolSchema(
    name="complete_item",
    description="Mark an item as completed.",
    params=[
        ToolParam("item_id", "string", "The UUID of the item to complete", required=True),
        ToolParam("reasoning", "string", "Optional reason for completion"),
    ]
)

UPDATE_ITEM = ToolSchema(
    name="update_item",
    description="Update an existing item's properties.",
    params=[
        ToolParam("item_id", "string", "The UUID of the item to update", required=True),
        ToolParam("text", "string", "New text content"),
        ToolParam("title", "string", "New title"),
        ToolParam("status", "string", "New status",
                  enum=["active", "waiting", "stale", "archived", "completed"]),
        ToolParam("due", "string", "Due date in ISO format or natural language"),
        ToolParam("priority", "integer", "Priority 1-4 (1=highest)"),
        ToolParam("tags", "array", "Replace tags with these values", items={"type": "string"}),
    ]
)

DELETE_ITEM = ToolSchema(
    name="delete_item",
    description="Soft delete an item by ID. Sets deleted_at timestamp.",
    params=[
        ToolParam("item_id", "string", "The UUID of the item to delete", required=True),
        ToolParam("reasoning", "string", "Optional reason for deletion"),
    ]
)

DELETE_MULTIPLE = ToolSchema(
    name="delete_multiple_items",
    description="Delete multiple items at once. Use for bulk cleanup.",
    params=[
        ToolParam("item_ids", "array", "List of UUIDs to delete", required=True, items={"type": "string"}),
        ToolParam("reasoning", "string", "Reason for deletion"),
    ]
)

RESTORE_ITEM = ToolSchema(
    name="restore_item",
    description="Restore a soft-deleted item.",
    params=[
        ToolParam("item_id", "string", "The UUID of the item to restore", required=True),
    ]
)

ARCHIVE_ITEM = ToolSchema(
    name="archive_item",
    description="Archive an item (soft removal from active views).",
    params=[
        ToolParam("item_id", "string", "The UUID of the item to archive", required=True),
    ]
)

BULK_UPDATE = ToolSchema(
    name="bulk_update_items",
    description="Bulk update items matching filters. Use for operations like 'archive all active emails'.",
    params=[
        ToolParam("set_status", "string", "Status to set on matching items", required=True,
                  enum=["active", "archived", "completed", "stale"]),
        ToolParam("filter_type", "string", "Only update items of this type",
                  enum=["task", "idea", "note", "email", "event"]),
        ToolParam("filter_status", "string", "Only update items in this status",
                  enum=["inbox", "active", "waiting", "stale"]),
        ToolParam("limit", "integer", "Max items to update", default=100),
        ToolParam("reasoning", "string", "Reason for the bulk update"),
    ]
)

# Search
SEARCH = ToolSchema(
    name="search",
    description="Semantic search across all items using natural language query.",
    params=[
        ToolParam("query", "string", "Natural language search query", required=True),
        ToolParam("limit", "integer", "Maximum results", default=10),
        ToolParam("item_types", "array", "Filter by types", items={"type": "string"}),
        ToolParam("statuses", "array", "Filter by statuses", items={"type": "string"}),
    ]
)

# Events & History
GET_EVENTS = ToolSchema(
    name="get_events",
    description="Get recent events (audit log). Shows what changed and when.",
    params=[
        ToolParam("limit", "integer", "Maximum events to return", default=20),
        ToolParam("action_type", "string", "Filter by action type",
                  enum=["created", "updated", "deleted", "completed", "archived"]),
    ]
)

GET_DELETED = ToolSchema(
    name="get_deleted_items",
    description="Show items that have been deleted. Use for restore operations.",
    params=[
        ToolParam("limit", "integer", "Maximum items to return", default=20),
    ]
)

# Snooze
SNOOZE = ToolSchema(
    name="snooze_item",
    description="Snooze an item until a specific time.",
    params=[
        ToolParam("item_id", "string", "The UUID of the item to snooze", required=True),
        ToolParam("until", "string", "When to wake the item (natural language or ISO date)", required=True),
    ]
)

# Memory
REMEMBER = ToolSchema(
    name="remember",
    description="Store a memory or preference about the user.",
    params=[
        ToolParam("content", "string", "The fact or preference to remember", required=True),
    ]
)

LIST_MEMORIES = ToolSchema(
    name="list_memories",
    description="List stored memories about the user.",
    params=[
        ToolParam("memory_type", "string", "Filter by type", enum=["explicit", "implicit", "all"], default="all"),
        ToolParam("limit", "integer", "Maximum memories to return", default=20),
    ]
)

DELETE_MEMORY = ToolSchema(
    name="delete_memory",
    description="Delete a stored memory (forget something).",
    params=[
        ToolParam("memory_id", "string", "The UUID of the memory to delete", required=True),
        ToolParam("cascade", "boolean", "Also delete related implicit memories", default=False),
    ]
)

# Goals
CREATE_GOAL = ToolSchema(
    name="create_goal",
    description="Create a new goal. Goals are high-level objectives that tasks can support.",
    params=[
        ToolParam("title", "string", "Goal title", required=True),
        ToolParam("description", "string", "Detailed description"),
        ToolParam("horizon", "string", "Time horizon", enum=["short", "medium", "long"], default="medium"),
    ]
)

LIST_GOALS = ToolSchema(
    name="list_goals",
    description="List all goals.",
    params=[
        ToolParam("horizon", "string", "Filter by horizon", enum=["short", "medium", "long"]),
        ToolParam("status", "string", "Filter by status", enum=["active", "completed", "archived"]),
    ]
)

LINK_TO_GOAL = ToolSchema(
    name="link_to_goal",
    description="Link an item to a goal.",
    params=[
        ToolParam("item_id", "string", "Item to link", required=True),
        ToolParam("goal_id", "string", "Goal to link to", required=True),
        ToolParam("reasoning", "string", "Why this item supports the goal"),
    ]
)

ASSESS_GOAL = ToolSchema(
    name="assess_goal",
    description="Record progress assessment for a goal.",
    params=[
        ToolParam("goal_id", "string", "UUID of goal to assess", required=True),
        ToolParam("progress", "integer", "Progress 0-100", required=True),
        ToolParam("notes", "string", "Assessment notes"),
        ToolParam("blockers", "array", "Current blockers", items={"type": "string"}),
    ]
)

UPDATE_GOAL = ToolSchema(
    name="update_goal",
    description="Update goal properties.",
    params=[
        ToolParam("goal_id", "string", "UUID of goal", required=True),
        ToolParam("title", "string", "New title"),
        ToolParam("horizon", "string", "New horizon", enum=["short", "medium", "long"]),
        ToolParam("target_date", "string", "New target date (ISO format)"),
    ]
)

# Insights
WHAT_NOW = ToolSchema(
    name="what_now",
    description="Get prioritized items for 'what should I do now'. Returns scored items.",
    params=[
        ToolParam("limit", "integer", "Maximum items to return", default=5),
    ]
)

GET_CONTEXT = ToolSchema(
    name="get_context",
    description="Get user context including active goals and recent items.",
    params=[
        ToolParam("include_goals", "boolean", "Include active goals", default=True),
        ToolParam("include_recent", "boolean", "Include recent items", default=True),
        ToolParam("recent_limit", "integer", "How many recent items", default=10),
    ]
)

DIGEST = ToolSchema(
    name="generate_digest",
    description="Generate a daily digest with counts and status summary.",
    params=[]
)

# =============================================================================
# PEOPLE TOOLS
# =============================================================================

LIST_PEOPLE = ToolSchema(
    name="list_people",
    description="List people from the database.",
    params=[
        ToolParam("limit", "integer", "Maximum to return", default=20),
        ToolParam("sort_by_importance", "boolean", "Sort by importance"),
    ]
)

SEARCH_PEOPLE = ToolSchema(
    name="search_people",
    description="Semantic search for people by name, role, or organization.",
    params=[
        ToolParam("query", "string", "Search query", required=True),
        ToolParam("limit", "integer", "Maximum results", default=10),
    ]
)

CREATE_PERSON = ToolSchema(
    name="create_person",
    description="Create a new person in the database.",
    params=[
        ToolParam("name", "string", "Person's name", required=True),
        ToolParam("email", "string", "Person's email"),
        ToolParam("importance", "integer", "Importance score", default=0),
    ]
)

DELEGATE_ITEM = ToolSchema(
    name="delegate_item",
    description="Delegate an item to a person.",
    params=[
        ToolParam("item_id", "string", "UUID of item", required=True),
        ToolParam("person_id", "string", "UUID of person", required=True),
        ToolParam("due_at", "string", "Due date (ISO format)"),
    ]
)

LIST_DELEGATIONS = ToolSchema(
    name="list_delegations",
    description="List items delegated to others.",
    params=[
        ToolParam("status", "string", "Filter status", enum=["pending", "completed", "all"]),
    ]
)

# =============================================================================
# RECURRING TOOLS
# =============================================================================

CREATE_RECURRING = ToolSchema(
    name="create_recurring",
    description="Create a recurring item (habit, routine).",
    params=[
        ToolParam("title", "string", "Title", required=True),
        ToolParam("frequency", "string", "How often", required=True, enum=["daily", "weekly", "monthly"]),
    ]
)

LIST_HABITS = ToolSchema(
    name="list_habits",
    description="List recurring habits/items.",
    params=[
        ToolParam("limit", "integer", "Maximum to return", default=20),
    ]
)

COMPLETE_RECURRING = ToolSchema(
    name="complete_recurring",
    description="Complete today's instance of a recurring item.",
    params=[
        ToolParam("item_id", "string", "UUID of recurring item", required=True),
    ]
)

# =============================================================================
# SCHEDULER TOOLS
# =============================================================================

LIST_SCHEDULED_JOBS = ToolSchema(
    name="list_scheduled_jobs",
    description="List all scheduled background jobs and their status.",
    params=[]
)

RUN_JOB_NOW = ToolSchema(
    name="run_job_now",
    description="Manually trigger a scheduled job immediately.",
    params=[
        ToolParam("job_id", "string", "ID of job to run", required=True),
    ]
)

LIST_JOB_HISTORY = ToolSchema(
    name="list_job_history",
    description="List recent job execution history.",
    params=[
        ToolParam("limit", "integer", "Maximum history items", default=20),
    ]
)

# =============================================================================
# INTEGRATION TOOLS
# =============================================================================

CONNECT_GOOGLE = ToolSchema(
    name="connect_google",
    description="Connect to Google services. Returns authorization URL.",
    params=[]
)

SYNC_GMAIL = ToolSchema(
    name="sync_gmail",
    description="Sync emails from Gmail.",
    params=[
        ToolParam("max_results", "integer", "Max emails to sync", default=100),
        ToolParam("full_sync", "boolean", "Force full sync"),
    ]
)

SYNC_CALENDAR = ToolSchema(
    name="sync_calendar",
    description="Sync events from Google Calendar.",
    params=[
        ToolParam("days_past", "integer", "Days in past", default=30),
        ToolParam("days_future", "integer", "Days in future", default=90),
    ]
)

SYNC_CONTACTS = ToolSchema(
    name="sync_contacts",
    description="Sync contacts from Google Contacts.",
    params=[
        ToolParam("full_sync", "boolean", "Force full sync"),
    ]
)

LIST_EMAILS = ToolSchema(
    name="list_emails",
    description="List synced emails from the database.",
    params=[
        ToolParam("limit", "integer", "Maximum emails to return", default=20),
        ToolParam("unread_only", "boolean", "Only show unread"),
    ]
)

ARCHIVE_EMAIL = ToolSchema(
    name="archive_email",
    description="Archive an email (remove from INBOX).",
    params=[
        ToolParam("item_id", "string", "UUID of email item", required=True),
    ]
)

# =============================================================================
# TAG TOOLS
# =============================================================================

ADD_TAGS = ToolSchema(
    name="add_tags",
    description="Add tags to an item.",
    params=[
        ToolParam("item_id", "string", "UUID of item", required=True),
        ToolParam("tags", "array", "Tags to add", required=True, items={"type": "string"}),
    ]
)

REMOVE_TAG = ToolSchema(
    name="remove_tag",
    description="Remove a tag from an item.",
    params=[
        ToolParam("item_id", "string", "UUID of item", required=True),
        ToolParam("tag", "string", "Tag to remove", required=True),
    ]
)


# =============================================================================
# TOOL COLLECTIONS
# =============================================================================

# Core tools used by both MCP and Chat
CORE_TOOLS = [
    # Capture & Triage
    CAPTURE, TRIAGE, ACCEPT_TRIAGE, BULK_CAPTURE,
    # Item CRUD
    LIST_INBOX, LIST_ITEMS, COMPLETE_ITEM, UPDATE_ITEM,
    DELETE_ITEM, DELETE_MULTIPLE, RESTORE_ITEM, ARCHIVE_ITEM, BULK_UPDATE,
    # Search
    SEARCH,
    # Events & History
    GET_EVENTS, GET_DELETED,
    # Scheduling
    SNOOZE,
    # Memory
    REMEMBER, LIST_MEMORIES, DELETE_MEMORY,
    # Goals
    CREATE_GOAL, LIST_GOALS, LINK_TO_GOAL, ASSESS_GOAL, UPDATE_GOAL,
    # Insights
    WHAT_NOW, GET_CONTEXT, DIGEST,
    # People
    LIST_PEOPLE, SEARCH_PEOPLE, CREATE_PERSON, DELEGATE_ITEM, LIST_DELEGATIONS,
    # Recurring
    CREATE_RECURRING, LIST_HABITS, COMPLETE_RECURRING,
    # Scheduler
    LIST_SCHEDULED_JOBS, RUN_JOB_NOW, LIST_JOB_HISTORY,
    # Integrations
    CONNECT_GOOGLE, SYNC_GMAIL, SYNC_CALENDAR, SYNC_CONTACTS, LIST_EMAILS, ARCHIVE_EMAIL,
    # Tags
    ADD_TAGS, REMOVE_TAG,
]


def get_mcp_tools() -> list:
    """Get all tools in MCP format."""
    return [tool.to_mcp() for tool in CORE_TOOLS]


def get_anthropic_tools() -> list[dict[str, Any]]:
    """Get all tools in Anthropic format."""
    return [tool.to_anthropic() for tool in CORE_TOOLS]


def get_tool_names() -> list[str]:
    """Get all tool names."""
    return [tool.name for tool in CORE_TOOLS]

