"""
Search & Context tool handlers.

Handles: search, get_context
"""

from typing import Any

from jomni.models import ItemType, ItemStatus
from jomni.tools.registry import ToolContext, register_handler
from jomni.tools.handlers import handle_search as _handle_search_core


# =============================================================================
# SEARCH
# =============================================================================

@register_handler("search")
async def handle_search(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Search for items using hybrid semantic and keyword matching."""
    return await _handle_search_core(
        ctx.db, ctx.ai,
        query=args.get("query", ""),
        item_types=args.get("item_types"),
        statuses=args.get("statuses"),
        sort_by=args.get("sort_by", "similarity"),
        limit=args.get("limit", 10),
    )


# =============================================================================
# GET CONTEXT
# =============================================================================

@register_handler("get_context")
async def handle_get_context(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Get current context: active goals, recent items, patterns."""
    include_goals = args.get("include_goals", True)
    include_recent = args.get("include_recent", True)
    recent_limit = args.get("recent_limit", 10)
    
    context: dict[str, Any] = {}
    
    if include_goals:
        goals = await ctx.db.list_items(
            item_type=ItemType.GOAL,
            status=ItemStatus.ACTIVE,
            limit=10,
        )
        context["active_goals"] = [
            {
                "id": str(g.id),
                "text": g.content.get("text", "")[:100],
            }
            for g in goals
        ]
    
    if include_recent:
        recent = await ctx.db.list_items(
            status=ItemStatus.ACTIVE,
            limit=recent_limit,
        )
        context["recent_items"] = [
            {
                "id": str(item.id),
                "type": item.item_type.value,
                "text": item.content.get("text", "")[:100],
                "updated": str(item.updated_at),
            }
            for item in recent
        ]
    
    # Inbox count
    inbox = await ctx.db.get_inbox(limit=100)
    context["inbox_count"] = len(inbox)
    
    return context
