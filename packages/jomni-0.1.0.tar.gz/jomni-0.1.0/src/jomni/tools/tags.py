"""
Tag tool handlers.

Handles: add_tags, remove_tag, list_tags
"""

from typing import Any
from uuid import UUID

from jomni.tools.registry import ToolContext, register_handler


# =============================================================================
# ADD TAGS
# =============================================================================

@register_handler("add_tags")
async def handle_add_tags(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Add tags to an item using the normalized tag system."""
    item_id = args.get("item_id")
    tags = args.get("tags", [])
    
    if not item_id or not tags:
        return {"error": "item_id and tags are required"}
    
    await ctx.db.add_tags_to_item(UUID(item_id), tags)
    return {"success": True, "item_id": item_id, "tags_added": tags}


# =============================================================================
# REMOVE TAG
# =============================================================================

@register_handler("remove_tag")
async def handle_remove_tag(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """Remove a tag from an item."""
    item_id = args.get("item_id")
    tag = args.get("tag")
    
    if not item_id or not tag:
        return {"error": "item_id and tag are required"}
    
    await ctx.db.remove_tag_from_item(UUID(item_id), tag)
    return {"success": True, "item_id": item_id, "tag_removed": tag}


# =============================================================================
# LIST TAGS
# =============================================================================

@register_handler("list_tags")
async def handle_list_tags(ctx: ToolContext, args: dict[str, Any]) -> dict[str, Any]:
    """List all available tags."""
    tags_result = ctx.db.client.table("tags").select("name, color, description").execute()
    return {"tags": tags_result.data}
