"""
Datetime utilities for consistent timezone-aware datetime handling.

WHY THIS EXISTS:
Python's datetime is a minefield. There are two types of datetimes:
- Naive: No timezone info (datetime.now(), datetime.utcnow())
- Aware: Has timezone info (datetime.now(timezone.utc))

You CANNOT compare naive and aware datetimes - you get:
    "can't compare offset-naive and offset-aware datetimes"

This module ensures ALL datetimes in Jomni are timezone-aware UTC.

USAGE:
- Replace datetime.now() → utc_now()
- Replace datetime.utcnow() → utc_now()
- Wrap external datetimes → ensure_aware(dt)
- Parse ISO strings → parse_iso(s)
- For google-auth (uses naive) → make_naive_utc(dt)
"""

from datetime import datetime, timezone


def utc_now() -> datetime:
    """
    Get current time as timezone-aware UTC datetime.
    
    USE THIS instead of:
    - datetime.now() (returns local time, naive)
    - datetime.utcnow() (returns UTC, but still naive!)
    """
    return datetime.now(timezone.utc)


def ensure_aware(dt: datetime | None) -> datetime | None:
    """
    Convert naive datetime to UTC-aware. Pass through if already aware.
    
    USE THIS when receiving datetimes from external sources (database, API)
    that might be naive. Assumes naive datetimes are already in UTC.
    """
    if dt is None:
        return None
    if dt.tzinfo is None:
        # Assume naive datetime is UTC and add timezone info
        return dt.replace(tzinfo=timezone.utc)
    return dt


def make_naive_utc(dt: datetime | None) -> datetime | None:
    """
    Convert datetime to naive UTC for libraries that expect naive datetimes.
    
    WHY THIS EXISTS:
    google-auth library internally uses datetime.utcnow() (naive) for
    token expiry checks. If you pass an aware datetime, you get:
        "can't compare offset-naive and offset-aware datetimes"
    
    This converts aware → naive by stripping timezone after converting to UTC.
    """
    if dt is None:
        return None
    if dt.tzinfo is not None:
        # Convert to UTC, then strip timezone info
        return dt.astimezone(timezone.utc).replace(tzinfo=None)
    return dt


def parse_iso(s: str | None) -> datetime | None:
    """
    Parse ISO timestamp string, always returns timezone-aware datetime.
    
    Handles various ISO formats:
    - 2025-12-04T18:00:00Z
    - 2025-12-04T18:00:00+00:00
    - 2025-12-04T18:00:00 (assumed UTC)
    
    Uses dateutil.parser which is more lenient than datetime.fromisoformat().
    """
    if s is None:
        return None
    try:
        from dateutil.parser import parse
        dt = parse(s)
        return ensure_aware(dt)
    except Exception:
        return None


