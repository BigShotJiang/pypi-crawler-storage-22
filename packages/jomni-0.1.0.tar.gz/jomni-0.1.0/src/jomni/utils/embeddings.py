"""
Embedding utilities for generating and storing item embeddings.

WHY THIS EXISTS:
Semantic search requires vector embeddings. Every Item needs an embedding
so users can search by meaning, not just keywords.

The problem: Not all code paths generate embeddings:
- Triage flow: ✅ Generates embedding after classification
- Calendar sync: ❌ Was missing (now fixed)
- Direct API creates: ❌ May be missing

This module provides shared functions so ANY code path can easily
generate embeddings, and backfill_embeddings.py catches any gaps.

EMBEDDING MODEL:
- Model: text-embedding-3-small (OpenAI) 
- Dimensions: 512 (smaller = faster, good quality tradeoff)
- Storage: pgvector in Supabase

USAGE:
    from jomni.utils.embeddings import embed_item
    await embed_item(item, db)
"""

import hashlib
import logging
from uuid import UUID

from jomni.ai.provider import get_ai
from jomni.db.protocol import DatabaseProtocol
from jomni.models import EmbeddingCreate

logger = logging.getLogger(__name__)

# Model configuration (match ai/provider.py)
EMBEDDING_MODEL = "text-embedding-3-small"
EMBEDDING_DIMENSIONS = 512
MODEL_VERSION = "1.0"


def get_item_text(item) -> str:
    """Extract text content from an item for embedding."""
    content = item.content or {}
    parts = []
    
    # Title/summary
    if title := content.get("title"):
        parts.append(title)
    
    # Main text
    if text := content.get("text"):
        parts.append(text)
    
    # Description (for events)
    if desc := content.get("description"):
        parts.append(desc)
    
    # Location (for events)
    if location := content.get("location"):
        parts.append(f"Location: {location}")
    
    # Tags (safely access)
    tags = getattr(item, 'tags', None) or content.get('tags', [])
    if tags:
        parts.append(f"Tags: {', '.join(tags)}")
    
    # Item type context
    item_type = getattr(item, 'item_type', None)
    if item_type:
        type_val = item_type.value if hasattr(item_type, 'value') else str(item_type)
        parts.append(f"Type: {type_val}")
    
    return "\n".join(parts)


async def generate_embedding(text: str) -> tuple[list[float], str]:
    """
    Generate embedding for text using OpenAI.
    
    Returns:
        Tuple of (embedding vector, source hash)
    """
    ai = get_ai()
    return await ai.embed(text)


async def store_item_embedding(
    item_id: UUID,
    text: str,
    db: DatabaseProtocol
) -> None:
    """
    Generate and store embedding for an item.
    
    Args:
        item_id: The item's UUID
        text: Text content to embed
        db: Database client
    """
    if not text or not text.strip():
        logger.warning(f"Skipping embedding for item {item_id}: empty text")
        return
    
    try:
        embedding, source_hash = await generate_embedding(text)
        
        await db.store_embedding(EmbeddingCreate(
            item_id=item_id,
            model_name=EMBEDDING_MODEL,
            model_version=MODEL_VERSION,
            dimensions=EMBEDDING_DIMENSIONS,
            embedding=embedding,
            source_hash=source_hash
        ))
        
        logger.debug(f"Stored embedding for item {item_id}")
        
    except Exception as e:
        logger.error(f"Failed to generate embedding for item {item_id}: {e}")
        raise


async def embed_item(item, db: DatabaseProtocol) -> None:
    """
    Generate and store embedding for an Item object.
    
    Convenience wrapper that extracts text from item.
    """
    text = get_item_text(item)
    await store_item_embedding(item.id, text, db)
