"""
Structured JSON logging configuration for Jomni.

WHY THIS EXISTS:
Plain text logs are hard to parse in production. JSON logs enable:
- Easy parsing by log aggregators (Datadog, Loki, etc.)
- Structured queries (filter by request_id, user, etc.)
- Consistent format across all services

USAGE:
- Import configure_logging at app startup
- Use standard logging calls, they'll output JSON in production
- In development, falls back to human-readable format
"""

import json
import logging
import sys
from datetime import datetime
from typing import Any

from jomni.middleware.request_id import get_request_id


class JSONFormatter(logging.Formatter):
    """Format log records as JSON for production environments."""
    
    def format(self, record: logging.LogRecord) -> str:
        log_data: dict[str, Any] = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        
        # Add request ID if available (from middleware context)
        request_id = get_request_id()
        if request_id:
            log_data["request_id"] = request_id
        
        # Add exception info if present
        if record.exc_info:
            log_data["exception"] = self.formatException(record.exc_info)
        
        # Add any extra fields passed to the logger
        if hasattr(record, "extra"):
            log_data["extra"] = record.extra
        
        # Add standard fields
        log_data["module"] = record.module
        log_data["function"] = record.funcName
        log_data["line"] = record.lineno
        
        return json.dumps(log_data)


class DevelopmentFormatter(logging.Formatter):
    """Human-readable format for development with colors."""
    
    COLORS = {
        "DEBUG": "\033[36m",     # Cyan
        "INFO": "\033[32m",      # Green
        "WARNING": "\033[33m",   # Yellow
        "ERROR": "\033[31m",     # Red
        "CRITICAL": "\033[35m",  # Magenta
    }
    RESET = "\033[0m"
    
    def format(self, record: logging.LogRecord) -> str:
        color = self.COLORS.get(record.levelname, "")
        
        # Include request ID if available
        request_id = get_request_id()
        rid_part = f"[{request_id[:8]}] " if request_id else ""
        
        return (
            f"{color}%(asctime)s{self.RESET} "
            f"{color}%(levelname)-8s{self.RESET} "
            f"{rid_part}"
            f"%(name)s: %(message)s"
        ) % {
            "asctime": self.formatTime(record),
            "levelname": record.levelname,
            "name": record.name,
            "message": record.getMessage(),
        }


def configure_logging(
    json_output: bool = False,
    level: int = logging.INFO,
) -> None:
    """
    Configure logging for the application.
    
    Args:
        json_output: If True, use JSON format. If False, use human-readable.
                     Typically True in production, False in development.
        level: Logging level (default INFO).
    """
    root_logger = logging.getLogger()
    root_logger.setLevel(level)
    
    # Remove existing handlers
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)
    
    # Create console handler
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(level)
    
    # Choose formatter based on environment
    if json_output:
        handler.setFormatter(JSONFormatter())
    else:
        handler.setFormatter(DevelopmentFormatter())
    
    root_logger.addHandler(handler)
    
    # Reduce noise from third-party libraries
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)
    logging.getLogger("apscheduler").setLevel(logging.WARNING)


def get_logger(name: str) -> logging.Logger:
    """
    Get a logger with the standard Jomni prefix.
    
    Usage:
        logger = get_logger(__name__)
        logger.info("Something happened", extra={"user_id": "123"})
    """
    return logging.getLogger(f"jomni.{name}")
