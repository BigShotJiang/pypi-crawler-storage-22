joop.flask.flask\_view
======================

.. automodule:: joop.flask.flask_view

   
   .. rubric:: Classes

   .. autosummary::
   
      FlaskView
   