joop.http.methods
=================

.. automodule:: joop.http.methods

   
   .. rubric:: Classes

   .. autosummary::
   
      HttpMethod
   