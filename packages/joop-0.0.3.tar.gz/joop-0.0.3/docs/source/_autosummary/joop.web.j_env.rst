joop.web.j\_env
===============

.. automodule:: joop.web.j_env

   
   .. rubric:: Functions

   .. autosummary::
   
      get_joop_env
      set_joop_env
   