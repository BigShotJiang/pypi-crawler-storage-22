# Jotbot

Push-to-talk voice dictation for macOS. Hold a hotkey combo to record, release to transcribe and paste at your cursor.

Built for use with Claude Code and other CLI tools.

## Features

- **Real-time streaming** with Deepgram Nova-2 (recommended)
- **Batch transcription** with OpenAI Whisper (fallback)
- **Code-aware formatting** with Claude Haiku (optional)
- **Clipboard preservation** - your clipboard is restored after pasting

## Hotkeys

| Combo | Action |
|-------|--------|
| `Ctrl+Option` | Record and transcribe (raw) |
| `Cmd+Ctrl+Option` | Record, transcribe, and format with Haiku (hold Cmd first) |

## Installation

```bash
pip install jotbot
```

Or with [pipx](https://pipx.pypa.io/) (recommended):

```bash
pipx install jotbot
```

## Setup

Run the interactive setup to configure your API keys:

```bash
jotbot --setup
```

This will prompt you to choose a transcription backend and enter your API keys:

- **Deepgram** (recommended): Real-time streaming, ~$0.0077/min - [Get key](https://console.deepgram.com)
- **OpenAI Whisper**: Batch processing, ~$0.006/min - [Get key](https://platform.openai.com)
- **Anthropic** (optional): For Haiku formatting mode - [Get key](https://console.anthropic.com)

Config is saved to `~/.config/jotbot/.env`.

### macOS Permissions

Your terminal app needs **Input Monitoring** permission:

System Settings → Privacy & Security → Input Monitoring → Enable your terminal (Warp, iTerm2, Terminal.app, etc.)

## Usage

```bash
jotbot
```

Then in any app:
1. Hold `Ctrl+Option` (or `Cmd+Ctrl+Option` for formatted output)
2. Speak
3. Release to transcribe and paste

## How it works

- **Audio**: Records via `sounddevice` at 16kHz mono
- **Transcription**:
  - Deepgram Nova-2 (streaming, low latency) - recommended
  - OpenAI Whisper (batch, higher latency) - fallback
- **Formatting** (optional): Claude Haiku cleans up text, adds backticks for code identifiers
- **Output**: Copies to clipboard, simulates Cmd+V, restores original clipboard

## Backends

### Deepgram (Recommended)

- Real-time streaming transcription
- Persistent WebSocket connection (instant start)
- ~$0.0077/min

### Whisper

- Batch transcription after recording ends
- Higher latency but very accurate
- ~$0.006/min

## Development

```bash
git clone https://github.com/isaacgor216/jotbot.git
cd jotbot
python -m venv .venv
source .venv/bin/activate
pip install -e .
```

## License

MIT
