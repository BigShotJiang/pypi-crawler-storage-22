#!/usr/bin/env python3
"""
jot - Simple, extensible interactive CLI task list
"""

import csv
import io
import json
import os
import platform
import re
import readline
import select
import shlex
import shutil
import subprocess
import sys
import tarfile
import tempfile
import termios
import time
import tty
import urllib.parse
import uuid
import webbrowser
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path

# File locking for concurrent access protection
try:
    from filelock import FileLock

    FILELOCK_AVAILABLE = True
except ImportError:
    FILELOCK_AVAILABLE = False
    FileLock = None

# Google Calendar API imports (optional - only used if enabled)
try:
    from google.auth.transport.requests import Request
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from googleapiclient.discovery import build
    from googleapiclient.errors import HttpError

    GCAL_AVAILABLE = True
except ImportError:
    GCAL_AVAILABLE = False

# Text-to-Speech library (optional - cross-platform TTS)
try:
    import pyttsx3

    TTS_AVAILABLE = True
except ImportError:
    TTS_AVAILABLE = False

# Mode constants
MODE_QUICK_ADD = 'quick_add'
MODE_COMMAND = 'command'
MODE_MULTISELECT = 'multiselect'
MODE_FUZZY_SEARCH = 'fuzzy_search'
MODE_ALL_CATEGORIES = 'all_categories'

# Day of week colors
DAY_COLORS = {
    'Monday': '\033[91m',  # Red
    'Tuesday': '\033[38;5;208m',  # Orange
    'Wednesday': '\033[93m',  # Yellow
    'Thursday': '\033[92m',  # Green
    'Friday': '\033[94m',  # Blue
    'Saturday': '\033[95m',  # Magenta
    'Sunday': '\033[96m',  # Cyan
}

DAY_ABBREVIATIONS = {
    'Monday': 'Mon',
    'Tuesday': 'Tue',
    'Wednesday': 'Wed',
    'Thursday': 'Thu',
    'Friday': 'Fri',
    'Saturday': 'Sat',
    'Sunday': 'Sun',
}


def input_with_prefill(prompt, prefill=''):
    """Get input with pre-filled text that user can edit"""

    def hook():
        readline.insert_text(prefill)
        readline.redisplay()

    readline.set_startup_hook(hook)
    try:
        return input(prompt)
    finally:
        readline.set_startup_hook()


def get_today_day_name():
    """Get the current day of the week"""
    return datetime.now().strftime('%A')  # Returns full day name like "Monday"


def sort_tasks_by_day(tasks):
    """Sort tasks by day of week (Sunday-Saturday)

    Args:
        tasks: List of task dictionaries

    Returns:
        Sorted list: tasks with days (Sun-Sat order) + tasks without days
    """
    days_order = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    day_index = {day: i for i, day in enumerate(days_order)}

    # Separate tasks with and without days
    with_day = [t for t in tasks if t.get('day')]
    without_day = [t for t in tasks if not t.get('day')]

    # Sort tasks with days by day order
    with_day.sort(key=lambda t: day_index.get(t.get('day'), 999))

    # Return: tasks with day (sorted Sun-Sat) + tasks without day
    return with_day + without_day


def filter_today_tasks(tasks, today):
    """Filter tasks to only show those assigned to today

    Args:
        tasks: List of task dictionaries
        today: String name of today's day (e.g., "Monday")

    Returns:
        List of tasks assigned to today
    """
    return [t for t in tasks if t.get('day') == today]


def extract_urls(text):
    """Extract URLs from text

    Args:
        text: String to search for URLs

    Returns:
        List of URLs found in text
    """
    # URL regex pattern - matches http://, https://, and www. URLs
    url_pattern = r'https?://[^\s]+|www\.[^\s]+'

    urls = re.findall(url_pattern, text)

    # Ensure www. URLs have http:// prefix for webbrowser
    normalized_urls = []
    for url in urls:
        if url.startswith('www.'):
            normalized_urls.append('http://' + url)
        else:
            normalized_urls.append(url)

    return normalized_urls


def round_to_15_minutes(dt):
    """Round datetime to nearest 15 minutes

    Args:
        dt: datetime object

    Returns:
        datetime rounded to nearest 15 minutes
    """
    minute = dt.minute
    # Round to nearest 15: 0, 15, 30, 45
    rounded_minute = round(minute / 15) * 15

    if rounded_minute == 60:
        # Roll over to next hour
        dt = dt.replace(minute=0, second=0, microsecond=0)
        dt = dt + timedelta(hours=1)
    else:
        dt = dt.replace(minute=rounded_minute, second=0, microsecond=0)

    return dt


def validate_safe_name(name, name_type="name"):
    """
    Validate category/project names for path traversal attacks.

    Security: Prevents directory traversal attacks by rejecting:
    - Path separators (/, \\)
    - Parent directory references (..)
    - Absolute paths
    - Non-alphanumeric characters (except dash and underscore)

    Args:
        name: Name to validate (category, project, etc.)
        name_type: Type of name for error messages (default: "name")

    Returns:
        str: Validated name (unchanged if valid)

    Raises:
        ValueError: If name contains dangerous characters or patterns

    Examples:
        >>> validate_safe_name("my-project")
        'my-project'
        >>> validate_safe_name("../etc/passwd")
        ValueError: Invalid name: ../etc/passwd (no path separators allowed)
    """
    if not name or not isinstance(name, str):
        raise ValueError(f"Invalid {name_type}: must be a non-empty string")

    # Reject path traversal attempts
    if '/' in name or '\\' in name:
        raise ValueError(f"Invalid {name_type}: {name} (no path separators allowed)")

    # Reject parent directory references
    if '..' in name:
        raise ValueError(f"Invalid {name_type}: {name} (no parent directory references allowed)")

    # Reject absolute paths
    if os.path.isabs(name):
        raise ValueError(f"Invalid {name_type}: {name} (absolute paths not allowed)")

    # Only allow alphanumeric, dash, underscore, dot
    if not re.match(r'^[a-zA-Z0-9_.-]+$', name):
        raise ValueError(
            f"Invalid {name_type}: {name} (only alphanumeric, dash, underscore, and dot allowed)"
        )

    # Reject names starting with dot (hidden files) except special cases
    if name.startswith('.') and name not in ['.jot', '.jot.json']:
        raise ValueError(f"Invalid {name_type}: {name} (names cannot start with dot)")

    return name


class GoogleCalendarAccountManager:
    """Manage multiple Google Calendar accounts"""

    ACCOUNTS_DIR = Path.home() / '.jot' / 'gcal-accounts'

    def __init__(self):
        """Initialize account manager"""
        # Ensure accounts directory exists
        self.ACCOUNTS_DIR.mkdir(parents=True, exist_ok=True)

    def discover_accounts(self):
        """Discover all configured Google Calendar accounts

        Returns:
            list: Account names (subdirectories with credentials.json)
        """
        if not self.ACCOUNTS_DIR.exists():
            return []

        accounts = []
        for path in self.ACCOUNTS_DIR.iterdir():
            if path.is_dir() and (path / 'credentials.json').exists():
                accounts.append(path.name)

        return sorted(accounts)

    def get_account_path(self, account_name):
        """Get path to account directory

        Args:
            account_name: Name of the account

        Returns:
            Path: Path to account directory
        """
        return self.ACCOUNTS_DIR / account_name

    def account_exists(self, account_name):
        """Check if account is configured

        Args:
            account_name: Name of the account

        Returns:
            bool: True if account directory exists with credentials.json
        """
        account_path = self.get_account_path(account_name)
        return account_path.exists() and (account_path / 'credentials.json').exists()

    def create_account(self, account_name):
        """Create new account directory

        Args:
            account_name: Name of the account

        Returns:
            Path: Path to created account directory
        """
        account_path = self.get_account_path(account_name)
        account_path.mkdir(parents=True, exist_ok=True)
        return account_path


class GoogleCalendarAuth:
    """Handle Google Calendar OAuth authentication"""

    SCOPES = ['https://www.googleapis.com/auth/calendar']

    def __init__(self, account_name='default'):
        """Initialize with account-specific credentials directory

        Args:
            account_name: Name of the Google Calendar account (default: 'default')
        """
        self.account_name = account_name
        account_manager = GoogleCalendarAccountManager()

        # Check for legacy credentials and migrate if needed
        self._migrate_legacy_credentials_if_needed(account_manager)

        # Use account-specific directory
        self.creds_dir = account_manager.get_account_path(account_name)
        self.creds_file = self.creds_dir / 'credentials.json'
        self.token_file = self.creds_dir / 'token.json'

        # Ensure directory exists
        self.creds_dir.mkdir(parents=True, exist_ok=True)

    def _migrate_legacy_credentials_if_needed(self, account_manager):
        """Migrate legacy single-account credentials to new multi-account structure

        Args:
            account_manager: GoogleCalendarAccountManager instance
        """
        # Only migrate if using 'default' account and legacy files exist
        if self.account_name != 'default':
            return

        legacy_dir = Path.home() / '.jot'
        legacy_creds = legacy_dir / 'credentials.json'
        legacy_token = legacy_dir / 'token.json'

        # Check if legacy files exist and haven't been migrated yet
        default_account_path = account_manager.get_account_path('default')
        if (legacy_creds.exists() or legacy_token.exists()) and not account_manager.account_exists(
            'default'
        ):
            # Create default account directory
            account_manager.create_account('default')

            # Migrate credentials.json if it exists
            if legacy_creds.exists():
                shutil.copy2(legacy_creds, default_account_path / 'credentials.json')

            # Migrate token.json if it exists
            if legacy_token.exists():
                shutil.copy2(legacy_token, default_account_path / 'token.json')

            print(f"\n✓ Migrated legacy Google Calendar credentials to 'default' account")
            print(f"  Location: {default_account_path}\n")

    def get_credentials(self):
        """Get or refresh OAuth credentials

        Returns:
            Credentials object

        Raises:
            FileNotFoundError: If credentials.json not found
        """
        if not GCAL_AVAILABLE:
            raise ImportError(
                "Google Calendar API libraries not installed. "
                "Run: pip install google-auth google-auth-oauthlib "
                "google-auth-httplib2 google-api-python-client"
            )

        if not self.creds_file.exists():
            raise FileNotFoundError(
                f"Credentials file not found: {self.creds_file}\n"
                "Please download credentials.json from Google Cloud Console:\n"
                "https://developers.google.com/workspace/calendar/api/quickstart/python"
            )

        creds = None

        # Load token if it exists
        if self.token_file.exists():
            creds = Credentials.from_authorized_user_file(str(self.token_file), self.SCOPES)

        # If no valid credentials, authenticate
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                try:
                    # Try to refresh expired token
                    creds.refresh(Request())
                except Exception:
                    # Refresh failed (token revoked or expired)
                    # Delete invalid token and re-authenticate
                    if self.token_file.exists():
                        self.token_file.unlink()
                    print(f"\n⚠️  Token expired or revoked. Re-authenticating...")
                    # Run OAuth flow
                    flow = InstalledAppFlow.from_client_secrets_file(
                        str(self.creds_file), self.SCOPES
                    )
                    creds = flow.run_local_server(port=0)
            else:
                # Run OAuth flow
                flow = InstalledAppFlow.from_client_secrets_file(str(self.creds_file), self.SCOPES)
                creds = flow.run_local_server(port=0)

            # Save credentials for future use with restrictive permissions
            # Security: Set umask to create file with 0o600 (user read/write only)
            old_umask = os.umask(0o077)  # Temporarily restrict permissions
            try:
                with open(self.token_file, 'w') as token:
                    token.write(creds.to_json())
            finally:
                os.umask(old_umask)  # Restore original umask

            # Double-check permissions are set correctly (defensive)
            os.chmod(self.token_file, 0o600)

        return creds

    def get_service(self):
        """Build and return Google Calendar service

        Returns:
            Google Calendar API service object
        """
        creds = self.get_credentials()
        return build('calendar', 'v3', credentials=creds)


def create_gcal_event(service, task_text):
    """Create a Google Calendar event from task text

    Args:
        service: Google Calendar API service object
        task_text: Task text to use as event summary

    Returns:
        Event link (htmlLink) or None if failed

    Raises:
        HttpError: If API call fails
    """
    # Get current time with timezone and round to nearest 15 minutes
    now = datetime.now().astimezone()
    start_time = round_to_15_minutes(now)
    end_time = start_time + timedelta(minutes=15)

    # Build event (isoformat() includes timezone when datetime is timezone-aware)
    event = {
        'summary': task_text,
        'start': {
            'dateTime': start_time.isoformat(),
        },
        'end': {
            'dateTime': end_time.isoformat(),
        },
        'description': 'Created from jot task',
    }

    # Insert event
    result = service.events().insert(calendarId='primary', body=event).execute()
    return result.get('htmlLink')


def fetch_gcal_events(service, date=None):
    """Fetch events from Google Calendar for a specific date

    Args:
        service: Google Calendar API service object
        date: datetime.date object (default: today)

    Returns:
        List of dicts with {'summary': str, 'start': datetime/None, 'end': datetime/None, 'all_day': bool}
        Returns empty list if no events found

    Raises:
        HttpError: If API call fails
    """
    if date is None:
        date = datetime.now().date()

    # Set time range for the full day in local timezone
    start_of_day = datetime.combine(date, datetime.min.time()).astimezone()
    end_of_day = datetime.combine(date, datetime.max.time()).astimezone()

    # Fetch events from primary calendar
    events_result = (
        service.events()
        .list(
            calendarId='primary',
            timeMin=start_of_day.isoformat(),
            timeMax=end_of_day.isoformat(),
            singleEvents=True,
            orderBy='startTime',
        )
        .execute()
    )

    events = events_result.get('items', [])

    # Parse events into simplified format
    parsed_events = []
    for event in events:
        summary = event.get('summary', '(No title)')

        # Check if all-day event
        start = event['start'].get('dateTime')
        end = event['end'].get('dateTime')

        if start:
            # Timed event
            start_dt = datetime.fromisoformat(start.replace('Z', '+00:00'))
            end_dt = datetime.fromisoformat(end.replace('Z', '+00:00'))
            parsed_events.append(
                {'summary': summary, 'start': start_dt, 'end': end_dt, 'all_day': False}
            )
        else:
            # All-day event
            parsed_events.append({'summary': summary, 'start': None, 'end': None, 'all_day': True})

    return parsed_events


class KeywordHandler:
    """Manages keyword detection and action routing for task automation"""

    MAX_KEYWORD_LENGTH = 50  # Security: Prevent excessively long keywords

    def __init__(self):
        """Initialize keyword handler with built-in handlers"""
        self.handlers = {}  # keyword -> handler function
        self.config = {}  # keyword -> config dict
        self.aliases = {}  # alias -> keyword mapping
        self._register_builtin_handlers()
        self._load_config()

    def extract_keyword(self, task_text):
        """
        Extract keyword from task text if present.

        Keyword format: "keyword: rest of task text"
        - First word must end with ':'
        - Keyword must be alphanumeric + hyphens/underscores
        - Case-insensitive (normalized to lowercase)

        Args:
            task_text: Full task text

        Returns:
            tuple: (keyword, original_text) or (None, original_text)
                   keyword is lowercase or None
                   original_text is unchanged (keeps "keyword: text" format)

        Examples:
            "gcal: Team meeting" -> ("gcal", "gcal: Team meeting")
            "bullet: Focus session" -> ("bullet", "bullet: Focus session")
            "Regular task" -> (None, "Regular task")
            "@invalid: task" -> (None, "@invalid: task")
        """
        if ':' not in task_text:
            return None, task_text

        # Split on first colon only
        parts = task_text.split(':', 1)
        if len(parts) != 2:
            return None, task_text

        first_word = parts[0].strip()

        # Validate keyword length (security: prevent DOS via very long keywords)
        if len(first_word) > self.MAX_KEYWORD_LENGTH:
            return None, task_text

        # Validate keyword: alphanumeric + hyphens/underscores only
        # This prevents @mentions, #hashtags, etc. from being treated as keywords
        if first_word and first_word.replace('-', '').replace('_', '').isalnum():
            # Valid keyword - normalize to lowercase
            keyword = first_word.lower()
            return keyword, task_text  # Return original text unchanged
        else:
            # Invalid keyword format
            return None, task_text

    def register(self, keyword, handler_func, auto_trigger=False, description=""):
        """
        Register a keyword action handler.

        Args:
            keyword: Keyword string (will be normalized to lowercase)
            handler_func: Callable that takes (task_dict) and returns result message
            auto_trigger: Whether to auto-execute when task is created
            description: Human-readable description of what this keyword does
        """
        keyword = keyword.lower()
        self.handlers[keyword] = handler_func
        self.config[keyword] = {'auto_trigger': auto_trigger, 'description': description}

    def handle(self, keyword, task):
        """
        Execute handler for detected keyword.

        Args:
            keyword: Keyword to execute (may be an alias)
            task: Task dictionary

        Returns:
            str: Result message from handler, or None if keyword not registered
        """
        # Resolve alias if present
        actual_keyword = keyword
        if hasattr(self, 'aliases') and keyword in self.aliases:
            actual_keyword = self.aliases[keyword]

        if actual_keyword in self.handlers:
            try:
                return self.handlers[actual_keyword](task)
            except Exception as e:
                return f"Error executing {keyword}: {str(e)}"
        else:
            # Unknown keyword - no action, no warning (per user preference)
            return None

    def get_config(self, keyword):
        """Get configuration for a keyword"""
        return self.config.get(keyword.lower())

    def list_keywords(self):
        """List all registered keywords with their configurations"""
        return {k: v for k, v in self.config.items()}

    def _load_config(self):
        """Load user configuration from ~/.jot-keywords.json"""

        config_file = Path.home() / '.jot-keywords.json'

        if not config_file.exists():
            # Create default config on first run
            self._create_default_config(config_file)
            return

        try:
            with open(config_file, 'r') as f:
                user_config = json.load(f)

            # Update config from file
            keywords = user_config.get('keywords', {})
            for keyword, settings in keywords.items():
                if keyword.lower() in self.config:
                    # Update existing keyword config
                    self.config[keyword.lower()].update(settings)
                # Note: Don't register unknown keywords from config
                # They'll be stored silently but won't have handlers

            # Load aliases
            self.aliases = user_config.get('aliases', {})

        except (json.JSONDecodeError, IOError) as e:
            print(f"Warning: Failed to load keyword config: {e}")

    def _create_default_config(self, config_file):
        """Create default keyword configuration file"""

        default_config = {
            "_comment": "Jot Keyword Configuration - See README.org for full documentation",
            "_note": "This file configures EXISTING keywords only. To add NEW keywords, you must edit jot.py",
            "keywords": {
                "bullet": {"auto_trigger": True, "description": "Start bullet priority timer"},
                "gcal": {"auto_trigger": True, "description": "Export task to Google Calendar"},
                "ai": {"auto_trigger": True, "description": "Mark task for AI/agent assistance"},
                "remind": {
                    "auto_trigger": False,
                    "description": "Set system notification (manual trigger with Shift+E)",
                },
                "analyze": {
                    "auto_trigger": True,
                    "description": "Analyze task with Claude Code AI (creates .jot.analysis.{id}.org file)",
                },
            },
            "aliases": {
                "_comment": "Aliases create shortcuts to existing keywords (e.g., 'timer:' -> 'bullet:')",
                "timer": "bullet",
                "cal": "gcal",
                "claude": "ai",
            },
            "_usage": {
                "auto_trigger": "Set to true to execute keyword action automatically when task is created",
                "aliases": "Map shortcut names to existing keywords for convenience",
                "custom_keywords": "To add custom keywords, edit jot.py and add a handler function - see README.org",
            },
        }

        try:
            with open(config_file, 'w') as f:
                json.dump(default_config, f, indent=2)
        except IOError as e:
            print(f"Warning: Failed to create keyword config: {e}")

    def _register_builtin_handlers(self):
        """Register built-in keyword handlers"""
        self.register(
            'bullet',
            self._handle_bullet,
            auto_trigger=True,
            description="Start bullet priority timer",
        )

        self.register(
            'gcal', self._handle_gcal, auto_trigger=True, description="Export to Google Calendar"
        )

        self.register('ai', self._handle_ai, auto_trigger=True, description="Mark as AI/agent task")

        self.register(
            'remind', self._handle_remind, auto_trigger=False, description="Set system notification"
        )

        self.register(
            'analyze',
            self._handle_analyze,
            auto_trigger=True,
            description="Analyze task with Claude Code AI",
        )

    def _handle_bullet(self, task):
        """Start bullet priority timer automatically"""

        try:
            subprocess.Popen(
                ['bullet', 'priority'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
            )
            return "Started bullet priority timer"
        except FileNotFoundError:
            return "bullet command not found (install: cd ~/projects/bullet && npm link)"

    def _handle_gcal(self, task):
        """Export task to Google Calendar automatically"""
        if not GCAL_AVAILABLE:
            return "Google Calendar API not available (install google-auth packages)"

        try:
            # Use GoogleCalendarAccountManager to discover accounts
            account_manager = GoogleCalendarAccountManager()
            accounts = account_manager.discover_accounts()

            if not accounts:
                return "No Google Calendar accounts configured (use Shift+G to set up)"

            # Use first available account
            account_name = accounts[0]

            # Initialize auth and get service
            auth = GoogleCalendarAuth(account_name)
            service = auth.get_service()

            # Create event
            create_gcal_event(service, task['text'])

            return f"Created Google Calendar event ({account_name})"

        except FileNotFoundError:
            return "Google Calendar credentials not found (use Shift+G to set up)"
        except Exception as e:
            return f"Failed to create calendar event: {str(e)}"

    def _handle_ai(self, task):
        """Mark task as AI/agent task"""
        task['agent_task'] = True
        return "Marked as AI/agent task"

    def _handle_remind(self, task):
        """Set system notification (macOS)"""

        if platform.system() != 'Darwin':
            return "Reminders only supported on macOS"

        try:
            # Use JSON escaping for robust string handling (prevents injection)
            # json.dumps() properly escapes quotes, backslashes, newlines, etc.
            task_text_safe = json.dumps(task['text'])[1:-1]  # Remove surrounding quotes

            script = f'''
                display notification "{task_text_safe}" with title "Jot Reminder" sound name "Ping"
            '''

            subprocess.run(
                ['osascript', '-e', script],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=True,
            )

            return "System notification displayed"

        except subprocess.CalledProcessError:
            return "Failed to display notification"
        except Exception as e:
            return f"Notification error: {str(e)}"

    def _handle_analyze(self, task):
        """Analyze task with Claude Code in planning mode"""

        # Remove keyword prefix from task text
        task_text = task['text']
        if task_text.lower().startswith('analyze:'):
            task_text = task_text[8:].strip()

        # Get task notes if they exist
        notes = task.get('notes', '')
        notes_section = f"\n\nTask Notes:\n{notes}" if notes else ""

        # Build analysis prompt
        prompt = f"""Analyze this task and provide a structured implementation plan in org-mode format.

Task: {task_text}{notes_section}

Please create an org-mode document with the following sections:

* Task Analysis
** Overview
Brief description of what needs to be done

** Task Breakdown
- [ ] Subtask 1
- [ ] Subtask 2
- [ ] Subtask 3

** Technical Approach
Key technical decisions and implementation strategy

** Acceptance Criteria
- Criterion 1
- Criterion 2
- Criterion 3

** Complexity Estimate
Simple / Medium / Complex (with justification)

** Potential Risks
Any challenges or unknowns to consider

Format the entire response as a well-structured org-mode document."""

        try:
            # Check if claude CLI is available
            check_result = subprocess.run(['claude', '--version'], capture_output=True, timeout=5)

            if check_result.returncode != 0:
                return "⚠️ Claude CLI not found. Install: https://claude.com/claude-code"

        except (FileNotFoundError, subprocess.TimeoutExpired):
            return "⚠️ Claude CLI not found. Install: https://claude.com/claude-code"

        try:
            # Invoke Claude in plan mode with JSON output
            result = subprocess.run(
                [
                    'claude',
                    '--print',
                    '--permission-mode',
                    'plan',
                    '--output-format',
                    'json',
                    '--max-turns',
                    '5',
                ],
                input=prompt,
                capture_output=True,
                text=True,
                timeout=120,  # 2 minute timeout
            )

            if result.returncode != 0:
                # Check for common errors
                stderr_lower = result.stderr.lower()

                if 'authentication' in stderr_lower or 'login' in stderr_lower:
                    return "⚠️ Claude auth expired. Run: claude login"
                elif 'network' in stderr_lower or 'connection' in stderr_lower:
                    return "⚠️ Network error. Check connection and try again"
                else:
                    # Return first 100 chars of error
                    error_msg = result.stderr[:100] if result.stderr else "Unknown error"
                    return f"⚠️ Claude failed: {error_msg}"

            # Parse JSON response
            try:
                response = json.loads(result.stdout)
                analysis_text = response.get('result', '')

                if not analysis_text:
                    return "⚠️ Empty response from Claude"

            except json.JSONDecodeError:
                return "⚠️ Failed to parse Claude response"

            # Save to .jot.analysis.{id}.org file

            output_file = Path.cwd() / f".jot.analysis.{task['id']}.org"

            try:
                with open(output_file, 'w') as f:
                    f.write(f"#+TITLE: Analysis for Task {task['id']}\n")
                    f.write(f"#+DATE: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
                    f.write(f"#+TASK: {task_text}\n\n")
                    f.write(analysis_text)

                # Store analysis file reference in task
                task['analysis_file'] = str(output_file)

                # Get cost from response if available
                cost = response.get('total_cost_usd', 0)
                cost_str = f" (${cost:.3f})" if cost > 0 else ""

                return f"✓ Analysis saved to {output_file.name}{cost_str}"

            except IOError as e:
                return f"⚠️ Failed to save analysis: {str(e)}"

        except subprocess.TimeoutExpired:
            return "⚠️ Analysis timed out (120s). Task may be too complex or network slow"
        except Exception as e:
            return f"⚠️ Analysis error: {str(e)}"


class ProjectRegistry:
    """Manages project name → directory path mappings"""

    def __init__(self, registry_file='~/.jot-projects.json'):
        self.registry_file = Path(registry_file).expanduser()
        self.projects = {}
        self._load_registry()

    def _load_registry(self):
        """Load project registry from JSON file"""
        if self.registry_file.exists():
            try:
                with open(self.registry_file, 'r') as f:
                    self.projects = json.load(f)
            except json.JSONDecodeError:
                self.projects = {}
        else:
            # Auto-discover projects on first run
            self._auto_discover()

    def _save_registry(self):
        """Save project registry to JSON file"""
        self.registry_file.parent.mkdir(parents=True, exist_ok=True)
        with open(self.registry_file, 'w') as f:
            json.dump(self.projects, f, indent=2)

    def _auto_discover(self):
        """Auto-discover projects with .jot.json files"""
        projects_dir = Path.home() / 'projects'
        if projects_dir.exists():
            for item in projects_dir.iterdir():
                if item.is_dir():
                    jot_file = item / '.jot.json'
                    if jot_file.exists():
                        self.projects[item.name] = str(item)
            self._save_registry()

    def register_project(self, name, path):
        """Register a project

        Args:
            name: Project name (validated for safety)
            path: Project directory path

        Raises:
            ValueError: If name contains dangerous characters
        """
        # Validate project name for security
        name = validate_safe_name(name, "project name")
        self.projects[name] = str(Path(path).expanduser().resolve())
        self._save_registry()

    def unregister_project(self, name):
        """Unregister a project"""
        if name in self.projects:
            del self.projects[name]
            self._save_registry()
            return True
        return False

    def get_project_path(self, name):
        """Get path for a project name"""
        return self.projects.get(name)

    def list_projects(self):
        """Return all registered projects"""
        return self.projects

    def refresh(self):
        """Re-run auto-discovery"""
        self._auto_discover()


class CategoryManager:
    """Manages categories within a project directory and globally"""

    MAX_CATEGORIES = 12
    GLOBAL_CATEGORIES_DIR = Path.home() / '.jot-categories'

    def __init__(self, project_dir=None):
        """Initialize category manager for a project directory"""
        self.project_dir = Path(project_dir) if project_dir else Path.cwd()

    def discover_categories(self):
        """
        Find all category files in .jot-categories/ directory.
        Returns list of category names (without .json suffix).
        """
        categories = []

        # Check if .jot-categories directory exists
        categories_dir = self.project_dir / '.jot-categories'
        if not categories_dir.exists():
            return categories

        # Find all .json files in .jot-categories/
        for file in categories_dir.glob('*.json'):
            # Extract category name from filename
            # features.json -> features
            category = file.stem  # Get filename without extension
            categories.append(category)

        return sorted(categories)

    def count_categories(self):
        """Count existing categories in the project"""
        return len(self.discover_categories())

    def can_create_category(self, category_name):
        """
        Check if a new category can be created.
        Returns (can_create: bool, message: str)
        """
        existing = self.discover_categories()

        # Category already exists
        if category_name in existing:
            return True, None

        # Check limit
        if len(existing) >= self.MAX_CATEGORIES:
            return (
                False,
                f"Category limit reached ({self.MAX_CATEGORIES} max). Existing: {', '.join(existing)}",
            )

        return True, None

    def get_warning_message(self, category_name):
        """
        Get warning message if approaching category limit.
        Returns None if no warning needed.
        """
        existing = self.discover_categories()

        # No warning if category already exists
        if category_name in existing:
            return None

        count = len(existing)

        if count == 10:
            return f"Warning: Approaching category limit ({count + 1}/12 categories)"
        elif count == 11:
            return f"Warning: Near category limit ({count + 1}/12 categories)"
        elif count >= 12:
            return f"Error: Category limit reached ({self.MAX_CATEGORIES} max)"

        return None

    def discover_global_categories(self):
        """
        Find all global category files in ~/.jot-categories/
        Returns list of category names (without .json suffix).
        Excludes special files like ids, archive, etc.
        """
        # Return empty list if global directory doesn't exist
        if not self.GLOBAL_CATEGORIES_DIR.exists():
            return []

        categories = []
        reserved_names = {'ids', 'archive', 'index', 'config'}

        # Find all *.json files in global categories directory
        for file in self.GLOBAL_CATEGORIES_DIR.glob('*.json'):
            category = file.stem  # filename without .json

            # Skip reserved names and special files
            if category not in reserved_names and not category.endswith('.ids'):
                categories.append(category)

        return sorted(categories)

    def category_exists_locally(self, category_name):
        """Check if category exists locally in project"""
        categories_dir = self.project_dir / '.jot-categories'
        local_file = categories_dir / f'{category_name}.json'
        return local_file.exists()

    def category_exists_globally(self, category_name):
        """Check if category exists globally"""
        global_file = self.GLOBAL_CATEGORIES_DIR / f'{category_name}.json'
        return global_file.exists()

    def resolve_category_location(self, category_name):
        """
        Determine if category is local, global, or new.
        Returns: 'local', 'global', or 'new'
        """
        if self.category_exists_locally(category_name):
            return 'local'
        elif self.category_exists_globally(category_name):
            return 'global'
        else:
            return 'new'

    def get_category_file_path(self, category_name, is_global=False):
        """
        Get the full path for a category file.

        Args:
            category_name: Name of the category
            is_global: If True, return global path; if False, return local path

        Returns:
            Path object for the category file
        """
        if is_global:
            return self.GLOBAL_CATEGORIES_DIR / f'{category_name}.json'
        else:
            # Local categories are stored in .jot-categories/ directory
            categories_dir = self.project_dir / '.jot-categories'
            categories_dir.mkdir(exist_ok=True)
            return categories_dir / f'{category_name}.json'


class CategoryConfig:
    """Manages category colors and configuration"""

    # ANSI color codes
    COLORS = {
        'red': '\033[91m',
        'green': '\033[92m',
        'yellow': '\033[93m',
        'blue': '\033[94m',
        'magenta': '\033[95m',
        'cyan': '\033[96m',
        'white': '\033[97m',
        'orange': '\033[38;5;208m',
        'purple': '\033[38;5;141m',
        'pink': '\033[38;5;213m',
        'teal': '\033[38;5;44m',
        'lime': '\033[38;5;154m',
    }

    # Default color assignments for common categories
    DEFAULT_COLORS = {
        'default': 'white',
        'features': 'green',
        'bugs': 'red',
        'testing': 'yellow',
        'docs': 'blue',
        'backlog': 'cyan',
        'ideas': 'purple',
        'work': 'teal',
        'personal': 'pink',
        'bills': 'orange',
        'health': 'lime',
    }

    def __init__(self, project_dir=None):
        """Initialize category config"""
        self.project_dir = Path(project_dir) if project_dir else Path.cwd()
        self.config_file = self.project_dir / '.jot.config.json'
        self.config = self._load_config()

    def _load_config(self):
        """Load config from .jot.config.json"""
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                return {}
        return {}

    def _save_config(self):
        """Save config to .jot.config.json"""
        self.config_file.parent.mkdir(parents=True, exist_ok=True)
        with open(self.config_file, 'w') as f:
            json.dump(self.config, indent=2, fp=f)

    def get_color(self, category_name, for_global=False):
        """Get ANSI color code for a category"""
        # Check custom colors first
        if 'colors' in self.config and category_name in self.config['colors']:
            color_name = self.config['colors'][category_name]
            return self.COLORS.get(color_name, '\033[96m')  # Default to cyan

        # Use default color for known categories
        if category_name in self.DEFAULT_COLORS:
            return self.COLORS[self.DEFAULT_COLORS[category_name]]

        # Global categories get magenta by default
        if for_global:
            return self.COLORS['magenta']

        # Unknown local categories get cyan
        return self.COLORS['cyan']

    def set_color(self, category_name, color_name):
        """Set color for a category"""
        if color_name not in self.COLORS:
            return False, f"Invalid color. Available: {', '.join(sorted(self.COLORS.keys()))}"

        if 'colors' not in self.config:
            self.config['colors'] = {}

        self.config['colors'][category_name] = color_name
        self._save_config()
        return True, f"Set {category_name} color to {color_name}"

    def get_all_colors(self):
        """Get all configured colors"""
        return self.config.get('colors', {})

    def reset_colors(self):
        """Reset all colors to defaults"""
        if 'colors' in self.config:
            del self.config['colors']
            self._save_config()
        return True

    def list_available_colors(self):
        """List all available color names"""
        return sorted(self.COLORS.keys())

    def get_tts_config(self):
        """Get TTS configuration settings"""
        default_tts = {
            'enabled': True,
            'rate': 150,  # Words per minute
            'volume': 0.9,  # 0.0 to 1.0
            'voice': None,  # None = system default
        }
        return self.config.get('tts', default_tts)

    def set_tts_config(self, **kwargs):
        """Set TTS configuration settings"""
        if 'tts' not in self.config:
            self.config['tts'] = {
                'enabled': True,
                'rate': 150,
                'volume': 0.9,
                'voice': None,
            }

        for key, value in kwargs.items():
            if key in ['enabled', 'rate', 'volume', 'voice']:
                self.config['tts'][key] = value

        self._save_config()
        return True


class CategoryTemplates:
    """Manages category templates for quick project setup"""

    TEMPLATES = {
        'software-dev': {
            'name': 'Software Development',
            'description': 'Standard software project categories',
            'categories': ['features', 'bugs', 'testing', 'docs'],
            'sample_tasks': {
                'features': ['Plan next sprint', 'Review backlog'],
                'bugs': ['Triage bug reports'],
                'testing': ['Run test suite', 'Update test coverage'],
                'docs': ['Update README', 'Write API docs'],
            },
        },
        'personal': {
            'name': 'Personal Tasks',
            'description': 'Personal life management categories',
            'categories': ['work', 'home', 'bills', 'health'],
            'sample_tasks': {
                'work': ['Check email', 'Weekly planning'],
                'home': ['Grocery shopping', 'Clean house'],
                'bills': ['Pay rent', 'Review budget'],
                'health': ['Exercise', 'Doctor appointment'],
            },
        },
        'creative': {
            'name': 'Creative Project',
            'description': 'Creative and content creation categories',
            'categories': ['ideas', 'drafts', 'editing', 'publishing'],
            'sample_tasks': {
                'ideas': ['Brainstorm topics', 'Research inspiration'],
                'drafts': ['Write first draft'],
                'editing': ['Review and revise'],
                'publishing': ['Format and publish'],
            },
        },
        'business': {
            'name': 'Business Management',
            'description': 'Business and client work categories',
            'categories': ['leads', 'clients', 'invoicing', 'marketing'],
            'sample_tasks': {
                'leads': ['Follow up prospects', 'Update CRM'],
                'clients': ['Client meetings', 'Project deliverables'],
                'invoicing': ['Send invoices', 'Track payments'],
                'marketing': ['Social media posts', 'Email campaign'],
            },
        },
        'academic': {
            'name': 'Academic/Research',
            'description': 'Academic and research project categories',
            'categories': ['reading', 'research', 'writing', 'teaching'],
            'sample_tasks': {
                'reading': ['Literature review', 'Paper analysis'],
                'research': ['Experiment design', 'Data collection'],
                'writing': ['Draft paper', 'Revise manuscript'],
                'teaching': ['Prepare lecture', 'Grade assignments'],
            },
        },
    }

    def __init__(self, project_dir=None):
        """Initialize templates manager"""
        self.project_dir = Path(project_dir) if project_dir else Path.cwd()
        self.cat_manager = CategoryManager(project_dir=self.project_dir)
        self.cat_config = CategoryConfig(project_dir=self.project_dir)

    def list_templates(self):
        """List all available templates"""
        return self.TEMPLATES

    def apply_template(self, template_name, with_samples=False):
        """Apply a template to create categories"""
        if template_name not in self.TEMPLATES:
            return False, f"Template '{template_name}' not found"

        template = self.TEMPLATES[template_name]
        categories_to_create = template['categories']

        # Check category limit
        existing_categories = self.cat_manager.discover_categories()
        total_after = len(existing_categories) + len(categories_to_create)

        if total_after > CategoryManager.MAX_CATEGORIES:
            return (
                False,
                f"Cannot create {len(categories_to_create)} categories. Would exceed limit ({CategoryManager.MAX_CATEGORIES} max)",
            )

        # Check for conflicts
        conflicts = [cat for cat in categories_to_create if cat in existing_categories]
        if conflicts:
            return False, f"Categories already exist: {', '.join(conflicts)}"

        # Create categories
        created = []
        for category in categories_to_create:
            # Create category file with optional sample tasks
            tm = TaskManager(directory=self.project_dir, category=category, is_global=False)

            if with_samples and category in template.get('sample_tasks', {}):
                for task_text in template['sample_tasks'][category]:
                    tm.add_task(task_text)

            created.append(category)

        return True, f"Created {len(created)} categories: {', '.join(created)}"

    def get_template_info(self, template_name):
        """Get detailed information about a template"""
        if template_name not in self.TEMPLATES:
            return None
        return self.TEMPLATES[template_name]


class ProjectBackup:
    """Manages project backup and restoration"""

    def __init__(self, project_dir=None):
        """Initialize backup manager"""
        self.project_dir = Path(project_dir) if project_dir else Path.cwd()

    def get_backup_files(self):
        """Get list of all jot files to backup"""
        files = []

        # All .jot.*.json files (categories, config, ids, archive)
        for file in self.project_dir.glob('.jot.*.json'):
            files.append(file)

        # Main .jot.json file
        main_file = self.project_dir / '.jot.json'
        if main_file.exists():
            files.append(main_file)

        return sorted(files)

    def create_backup(self, output_file=None):
        """Create a backup tarball of all jot files"""
        files_to_backup = self.get_backup_files()

        if not files_to_backup:
            return False, "No jot files found to backup"

        # Generate default filename if not provided
        if output_file is None:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            project_name = self.project_dir.name
            output_file = self.project_dir / f'jot-backup-{project_name}-{timestamp}.tar.gz'
        else:
            output_file = Path(output_file)

        # Create tarball
        try:
            with tarfile.open(output_file, 'w:gz') as tar:
                for file in files_to_backup:
                    # Add file with just its name (not full path)
                    tar.add(file, arcname=file.name)

            return True, f"Backup created: {output_file} ({len(files_to_backup)} files)"
        except Exception as e:
            return False, f"Backup failed: {str(e)}"

    def restore_backup(self, backup_file, force=False):
        """Restore from a backup tarball"""
        backup_path = Path(backup_file)

        if not backup_path.exists():
            return False, f"Backup file not found: {backup_file}"

        # Check for existing files
        if not force:
            existing_files = self.get_backup_files()
            if existing_files:
                return False, f"Project already has jot files. Use --force to overwrite."

        # Extract tarball
        try:
            with tarfile.open(backup_path, 'r:gz') as tar:
                # Verify all files are .jot files (security check)
                members = tar.getmembers()
                for member in members:
                    if not member.name.startswith('.jot'):
                        return False, f"Invalid backup: contains non-jot file '{member.name}'"

                # Extract to project directory
                tar.extractall(self.project_dir)

            return True, f"Restored {len(members)} files from {backup_file}"
        except Exception as e:
            return False, f"Restore failed: {str(e)}"

    def list_backup_contents(self, backup_file):
        """List contents of a backup file"""
        backup_path = Path(backup_file)

        if not backup_path.exists():
            return False, f"Backup file not found: {backup_file}"

        try:
            with tarfile.open(backup_path, 'r:gz') as tar:
                members = tar.getmembers()
                file_list = [m.name for m in members]
            return True, file_list
        except Exception as e:
            return False, f"Failed to read backup: {str(e)}"


class IDManager:
    """Manages unique task IDs across all categories in a project"""

    def __init__(self, project_dir=None):
        """Initialize ID manager for a project directory"""
        self.project_dir = Path(project_dir) if project_dir else Path.cwd()
        self.ids_file = self.project_dir / '.jot.ids.json'
        self.lock_file = self.project_dir / '.jot.ids.json.lock'
        self.next_id = 1
        self.allocated = []
        self._load_ids()

    def _load_ids(self):
        """Load ID tracking from .jot.ids.json"""
        if self.ids_file.exists():
            try:
                if FILELOCK_AVAILABLE:
                    # Use file locking for concurrent access protection
                    with FileLock(str(self.lock_file), timeout=10):
                        with open(self.ids_file, 'r') as f:
                            data = json.load(f)
                            self.next_id = data.get('next_id', 1)
                            self.allocated = data.get('allocated', [])
                else:
                    # Fallback without locking if filelock not available
                    with open(self.ids_file, 'r') as f:
                        data = json.load(f)
                        self.next_id = data.get('next_id', 1)
                        self.allocated = data.get('allocated', [])
            except json.JSONDecodeError:
                self.next_id = 1
                self.allocated = []

    def _save_ids(self):
        """Save ID tracking to .jot.ids.json"""
        # Ensure parent directory exists
        self.ids_file.parent.mkdir(parents=True, exist_ok=True)

        if FILELOCK_AVAILABLE:
            # Use file locking for concurrent access protection
            with FileLock(str(self.lock_file), timeout=10):
                with open(self.ids_file, 'w') as f:
                    json.dump(
                        {'next_id': self.next_id, 'allocated': sorted(self.allocated)}, f, indent=2
                    )
        else:
            # Fallback without locking if filelock not available
            with open(self.ids_file, 'w') as f:
                json.dump(
                    {'next_id': self.next_id, 'allocated': sorted(self.allocated)}, f, indent=2
                )

    def allocate_id(self):
        """Allocate a new unique ID with atomic file locking"""
        if FILELOCK_AVAILABLE:
            # Use file locking to prevent race conditions
            with FileLock(str(self.lock_file), timeout=10):
                # Reload from disk to catch any concurrent changes
                self._load_ids_without_lock()

                # Allocate new ID
                new_id = self.next_id
                self.allocated.append(new_id)
                self.next_id += 1

                # Save atomically while holding lock
                self._save_ids_without_lock()
                return new_id
        else:
            # Fallback without locking (best effort)
            new_id = self.next_id
            self.allocated.append(new_id)
            self.next_id += 1
            self._save_ids()
            return new_id

    def _load_ids_without_lock(self):
        """Load ID tracking without acquiring lock (internal use only)"""
        if self.ids_file.exists():
            try:
                with open(self.ids_file, 'r') as f:
                    data = json.load(f)
                    self.next_id = data.get('next_id', 1)
                    self.allocated = data.get('allocated', [])
            except json.JSONDecodeError:
                self.next_id = 1
                self.allocated = []

    def _save_ids_without_lock(self):
        """Save ID tracking without acquiring lock (internal use only)"""
        # Ensure parent directory exists
        self.ids_file.parent.mkdir(parents=True, exist_ok=True)

        with open(self.ids_file, 'w') as f:
            json.dump({'next_id': self.next_id, 'allocated': sorted(self.allocated)}, f, indent=2)

    def release_id(self, task_id):
        """Release an ID (when task is deleted)"""
        if task_id in self.allocated:
            self.allocated.remove(task_id)
            self._save_ids()

    def migrate_from_existing_ids(self, existing_ids):
        """
        Migrate from existing task IDs found in category files.
        Sets next_id to max(existing_ids) + 1 and marks all as allocated.
        """
        if not existing_ids:
            return

        # Find maximum existing ID
        max_id = max(existing_ids)

        # Update next_id and allocated list
        self.next_id = max_id + 1
        self.allocated = sorted(set(existing_ids))
        self._save_ids()

    def get_stats(self):
        """Get ID allocation statistics"""
        return {
            'next_id': self.next_id,
            'allocated_count': len(self.allocated),
            'allocated_ids': self.allocated,
        }


class ArchiveManager:
    """Manages archived tasks: compress, export, prune"""

    def __init__(self, project_dir=None):
        """Initialize ArchiveManager for a project directory"""
        self.project_dir = Path(project_dir) if project_dir else Path.cwd()
        self.config = self._load_config()

    def _load_config(self):
        """Load archive configuration"""
        config_file = self.project_dir / '.jot.config.json'
        defaults = {
            'archive': {
                'keep_in_main': 20,
                'compress_by': 'month',
                'auto_compress': False,
                'auto_prune_months': None,
            }
        }

        if config_file.exists():
            try:
                with open(config_file) as f:
                    user_config = json.load(f)
                    # Merge with defaults
                    if 'archive' in user_config:
                        defaults['archive'].update(user_config['archive'])
            except (json.JSONDecodeError, OSError):
                pass

        return defaults['archive']

    def _get_archive_files(self):
        """Find all archive files (.jot.archive.*.tar.gz)"""
        pattern = '.jot.archive.*.tar.gz'
        return sorted(self.project_dir.glob(pattern))

    def _read_task_manager_archives(self, category=None):
        """Read archived tasks from TaskManager files"""
        all_archived = []

        if category:
            # Read specific category
            if category == 'default':
                storage_file = self.project_dir / '.jot.json'
            else:
                storage_file = self.project_dir / f'.jot.{category}.json'

            if storage_file.exists():
                with open(storage_file) as f:
                    data = json.load(f)
                    all_archived.extend(data.get('archived', []))
        else:
            # Read all categories
            cat_mgr = CategoryManager(self.project_dir)

            # Default category
            default_file = self.project_dir / '.jot.json'
            if default_file.exists():
                with open(default_file) as f:
                    data = json.load(f)
                    all_archived.extend(data.get('archived', []))

            # Other categories
            for cat in cat_mgr.discover_categories():
                cat_file = self.project_dir / f'.jot.{cat}.json'
                if cat_file.exists():
                    with open(cat_file) as f:
                        data = json.load(f)
                        all_archived.extend(data.get('archived', []))

        return all_archived

    def _read_compressed_archive(self, archive_file):
        """Read tasks from a compressed archive file"""
        try:
            with tarfile.open(archive_file, 'r:gz') as tar:
                # Extract archive.json
                member = tar.getmember('archive.json')
                f = tar.extractfile(member)
                if f:
                    data = json.load(f)
                    return data.get('tasks', [])
        except (tarfile.TarError, KeyError, json.JSONDecodeError):
            return []

        return []

    def compress_archives(self, keep_n=None, category=None):
        """
        Compress old archived tasks into timestamped tar.gz files.

        Args:
            keep_n: Number of recent archived tasks to keep in main file
            category: Specific category to compress (or None for default)

        Returns:
            dict with compression results
        """
        if keep_n is None:
            keep_n = self.config['keep_in_main']

        # Determine storage file
        if category and category != 'default':
            storage_file = self.project_dir / f'.jot.{category}.json'
        else:
            storage_file = self.project_dir / '.jot.json'

        if not storage_file.exists():
            return {'error': f'File not found: {storage_file}'}

        # Read current data
        with open(storage_file) as f:
            data = json.load(f)

        archived = data.get('archived', [])

        if len(archived) <= keep_n:
            return {'message': f'Only {len(archived)} archived tasks, no compression needed'}

        # Keep recent N, compress the rest
        to_keep = archived[-keep_n:]
        to_compress = archived[:-keep_n]

        # Group by month
        by_month = {}
        for task in to_compress:
            # Try to determine month from task data
            month = None

            # Check for created_at or updated_at timestamp
            for field in ['updated_at', 'created_at']:
                if field in task:
                    try:
                        dt = datetime.fromisoformat(task[field].replace('Z', '+00:00'))
                        month = dt.strftime('%Y-%m')
                        break
                    except (ValueError, AttributeError):
                        pass

            # Fallback to current month if no timestamp
            if not month:
                month = datetime.now().strftime('%Y-%m')

            if month not in by_month:
                by_month[month] = []
            by_month[month].append(task)

        # Create compressed archives
        compressed_count = 0
        for month, tasks in by_month.items():
            archive_file = self.project_dir / f'.jot.archive.{month}.tar.gz'

            # If archive already exists, merge tasks
            existing_tasks = []
            if archive_file.exists():
                existing_tasks = self._read_compressed_archive(archive_file)

            # Combine and deduplicate by ID
            all_tasks = existing_tasks + tasks
            task_dict = {t['id']: t for t in all_tasks}
            final_tasks = list(task_dict.values())

            # Create archive data
            archive_data = {
                'month': month,
                'created_at': datetime.now().isoformat(),
                'tasks': final_tasks,
            }

            # Write to tar.gz

            json_data = json.dumps(archive_data, indent=2).encode('utf-8')
            json_file = io.BytesIO(json_data)

            with tarfile.open(archive_file, 'w:gz') as tar:
                tarinfo = tarfile.TarInfo(name='archive.json')
                tarinfo.size = len(json_data)
                tar.addfile(tarinfo, json_file)

            compressed_count += len(tasks)

        # Update storage file with only recent archives
        data['archived'] = to_keep
        with open(storage_file, 'w') as f:
            json.dump(data, f, indent=2)

        return {
            'compressed': compressed_count,
            'kept_in_main': len(to_keep),
            'archive_files_created': len(by_month),
        }

    def export_archives(self, format='json', output=None, include_compressed=True, category=None):
        """
        Export archived tasks to various formats.

        Args:
            format: 'json', 'csv', 'markdown', or 'text'
            output: Output file path (or None for stdout)
            include_compressed: Include tasks from compressed archives
            category: Export specific category only

        Returns:
            dict with export results
        """
        # Collect all archived tasks
        archived_tasks = self._read_task_manager_archives(category)

        # Add tasks from compressed archives if requested
        if include_compressed:
            for archive_file in self._get_archive_files():
                archived_tasks.extend(self._read_compressed_archive(archive_file))

        if not archived_tasks:
            return {'error': 'No archived tasks found'}

        # Determine output destination
        if output:
            output_path = Path(output)
        else:
            # Default output names
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            output_path = self.project_dir / f'jot_archive_export_{timestamp}.{format}'

        # Export based on format
        if format == 'json':
            self._export_json(archived_tasks, output_path)
        elif format == 'csv':
            self._export_csv(archived_tasks, output_path)
        elif format == 'markdown':
            self._export_markdown(archived_tasks, output_path)
        elif format == 'text':
            self._export_text(archived_tasks, output_path)
        else:
            return {'error': f'Unknown format: {format}'}

        return {
            'exported': len(archived_tasks),
            'format': format,
            'output': str(output_path),
        }

    def _export_json(self, tasks, output_path):
        """Export to JSON format"""
        export_data = {
            'exported_at': datetime.now().isoformat(),
            'task_count': len(tasks),
            'tasks': tasks,
        }
        with open(output_path, 'w') as f:
            json.dump(export_data, f, indent=2)

    def _export_csv(self, tasks, output_path):
        """Export to CSV format"""
        # Determine all possible fields
        fieldnames = [
            'id',
            'text',
            'done',
            'current',
            'day',
            'priority',
            'status',
            'tally',
            'time_spent',
        ]

        with open(output_path, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction='ignore')
            writer.writeheader()
            for task in tasks:
                writer.writerow(task)

    def _export_markdown(self, tasks, output_path):
        """Export to Markdown format"""
        with open(output_path, 'w') as f:
            f.write('# Archived Tasks\n\n')
            f.write(f'Exported: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n\n')
            f.write(f'Total tasks: {len(tasks)}\n\n')
            f.write('---\n\n')

            for task in tasks:
                f.write(f'## Task #{task["id"]}\n\n')
                f.write(f'**Text:** {task["text"]}\n\n')

                if task.get('done'):
                    f.write(f'**Status:** ✓ Done\n\n')

                if task.get('day'):
                    f.write(f'**Day:** {task["day"]}\n\n')

                if task.get('priority') and task['priority'] != 'none':
                    f.write(f'**Priority:** {task["priority"]}\n\n')

                if task.get('tally', 0) > 0:
                    f.write(f'**Tally:** {task["tally"]}\n\n')

                if task.get('time_spent'):
                    f.write(f'**Time Spent:** {task["time_spent"]}\n\n')

                f.write('---\n\n')

    def _export_text(self, tasks, output_path):
        """Export to plain text format"""
        with open(output_path, 'w') as f:
            f.write('ARCHIVED TASKS\n')
            f.write('=' * 60 + '\n\n')
            f.write(f'Exported: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n')
            f.write(f'Total tasks: {len(tasks)}\n\n')

            for i, task in enumerate(tasks, 1):
                f.write(f'{i}. [{task["id"]}] {task["text"]}\n')

                details = []
                if task.get('done'):
                    details.append('✓ Done')
                if task.get('day'):
                    details.append(f'Day: {task["day"]}')
                if task.get('priority') and task['priority'] != 'none':
                    details.append(f'Priority: {task["priority"]}')
                if task.get('tally', 0) > 0:
                    details.append(f'Tally: {task["tally"]}')

                if details:
                    f.write(f'   {" | ".join(details)}\n')

                f.write('\n')

    def prune_archives(self, strategy='older_than', value=None, interactive=False):
        """
        Remove old archived tasks.

        Args:
            strategy: 'older_than' (months), 'keep_last' (count), or 'file' (specific file)
            value: Strategy-specific value (e.g., 6 for 6 months, 100 for 100 tasks)
            interactive: Show confirmation dialog

        Returns:
            dict with prune results
        """
        archive_files = self._get_archive_files()

        if not archive_files:
            return {'message': 'No compressed archive files found'}

        files_to_delete = []

        if strategy == 'older_than' and value:
            # Delete archives older than N months
            cutoff_date = datetime.now() - timedelta(days=value * 30)

            for archive_file in archive_files:
                # Extract date from filename: .jot.archive.2025-11.tar.gz
                match = re.search(r'\.jot\.archive\.(\d{4}-\d{2})\.tar\.gz', archive_file.name)
                if match:
                    archive_month = match.group(1)
                    try:
                        archive_date = datetime.strptime(archive_month, '%Y-%m')
                        if archive_date < cutoff_date:
                            files_to_delete.append(archive_file)
                    except ValueError:
                        pass

        elif strategy == 'file' and value:
            # Delete specific file
            target_file = self.project_dir / value
            if target_file.exists():
                files_to_delete.append(target_file)

        if not files_to_delete:
            return {'message': 'No archives match prune criteria'}

        # Show confirmation if interactive
        if interactive:
            print(f'\nFiles to delete:')
            for f in files_to_delete:
                size = f.stat().st_size
                print(f'  - {f.name} ({size} bytes)')
            print(f'\nTotal: {len(files_to_delete)} files')

            response = input('\nProceed with deletion? (y/N): ').strip().lower()
            if response != 'y':
                return {'cancelled': True}

        # Delete files
        deleted_count = 0
        for file_path in files_to_delete:
            try:
                file_path.unlink()
                deleted_count += 1
            except OSError as e:
                print(f'Error deleting {file_path}: {e}')

        return {
            'deleted': deleted_count,
            'files': [f.name for f in files_to_delete],
        }

    def get_archive_stats(self):
        """Get statistics about archives"""
        # Count archives in main files
        archived_in_main = self._read_task_manager_archives()

        # Count archives in compressed files
        archive_files = self._get_archive_files()
        archived_in_compressed = []
        for archive_file in archive_files:
            archived_in_compressed.extend(self._read_compressed_archive(archive_file))

        # Calculate sizes
        total_size = sum(f.stat().st_size for f in archive_files)

        # Find date range
        all_tasks = archived_in_main + archived_in_compressed
        dates = []
        for task in all_tasks:
            for field in ['updated_at', 'created_at']:
                if field in task:
                    try:
                        dt = datetime.fromisoformat(task[field].replace('Z', '+00:00'))
                        dates.append(dt)
                        break
                    except (ValueError, AttributeError):
                        pass

        oldest = min(dates) if dates else None
        newest = max(dates) if dates else None

        return {
            'total_archived': len(all_tasks),
            'in_main_files': len(archived_in_main),
            'in_compressed': len(archived_in_compressed),
            'compressed_files': len(archive_files),
            'total_size_bytes': total_size,
            'oldest_task': oldest.strftime('%Y-%m-%d') if oldest else None,
            'newest_task': newest.strftime('%Y-%m-%d') if newest else None,
            'archive_files': [f.name for f in archive_files],
        }


class TaskManager:
    """Handles task storage and retrieval"""

    def __init__(
        self,
        storage_file='.jot.json',
        directory=None,
        id_manager=None,
        category=None,
        is_global=False,
    ):
        """
        Initialize TaskManager

        Args:
            storage_file: Base filename (used only if category is None and not global)
            directory: Project directory (ignored if is_global=True)
            id_manager: Shared IDManager instance
            category: Category name (validated for path traversal safety)
            is_global: If True, use global category storage in ~/.jot-categories/

        Raises:
            ValueError: If category name contains dangerous characters
        """
        # Validate category name for security (prevent path traversal)
        if category and category != 'default':
            category = validate_safe_name(category, "category name")

        # Store category and global flag
        self.category = category
        self.is_global = is_global

        # Set up directory and file path
        if is_global:
            # Global category: ~/.jot-categories/ (use CategoryManager's constant)
            global_dir = CategoryManager.GLOBAL_CATEGORIES_DIR
            global_dir.mkdir(parents=True, exist_ok=True)
            self.project_dir = global_dir

            # Build filename for global category
            if category:
                filename = f'{category}.json'
            else:
                filename = 'default.json'

            self.storage_file = self.project_dir / filename

            # Use global ID manager for this category
            if id_manager:
                self.id_manager = id_manager
            else:
                # Global categories get their own ID manager per category
                ids_file = self.project_dir / f'{category or "default"}.ids.json'
                self.id_manager = IDManager(project_dir=self.project_dir)
                # Override the ids_file to be category-specific
                self.id_manager.ids_file = ids_file
                self.id_manager._load_ids()
        else:
            # Local category: project directory
            if directory:
                self.project_dir = Path(directory)
            else:
                self.project_dir = Path.cwd()

            # Build filename based on category
            if category:
                # Category-specific file: .jot-categories/{category}.json
                categories_dir = self.project_dir / '.jot-categories'
                categories_dir.mkdir(exist_ok=True)
                self.storage_file = categories_dir / f'{category}.json'
            else:
                # Default file: .jot.json (or custom storage_file)
                self.storage_file = self.project_dir / storage_file

            # Use provided ID manager or create new one
            self.id_manager = id_manager if id_manager else IDManager(self.project_dir)

        self.tasks = []
        self.archived = []
        self._load_tasks()

        # Migrate existing IDs to IDManager if needed
        self._migrate_ids_if_needed()

        # Initialize keyword handler for automation
        self.keyword_handler = KeywordHandler()

    def _load_tasks(self):
        """Load tasks from JSON file"""
        if self.storage_file.exists():
            try:
                with open(self.storage_file, 'r') as f:
                    data = json.load(f)
                    # Handle old format (list) and new format (dict)
                    if isinstance(data, list):
                        self.tasks = data
                        self.archived = []
                    else:
                        self.tasks = data.get('tasks', [])
                        self.archived = data.get('archived', [])
            except json.JSONDecodeError:
                self.tasks = []
                self.archived = []
        else:
            self.tasks = []
            self.archived = []

    def _save_tasks(self):
        """Save tasks to JSON file"""
        # Ensure parent directory exists
        self.storage_file.parent.mkdir(parents=True, exist_ok=True)

        with open(self.storage_file, 'w') as f:
            json.dump({'tasks': self.tasks, 'archived': self.archived}, f, indent=2)

    def _migrate_ids_if_needed(self):
        """Migrate existing task IDs to IDManager on first load"""
        # Collect all existing IDs from tasks and archived
        existing_ids = []
        for task in self.tasks + self.archived:
            if 'id' in task:
                existing_ids.append(task['id'])

        if not existing_ids:
            return

        # Always ensure existing IDs are tracked in IDManager
        # This prevents duplicate allocation even if next_id > 1
        max_existing = max(existing_ids)

        # Ensure next_id is at least max_existing + 1
        if self.id_manager.next_id <= max_existing:
            self.id_manager.next_id = max_existing + 1

        # Add any missing IDs to allocated list
        existing_set = set(existing_ids)
        allocated_set = set(self.id_manager.allocated)
        missing_ids = existing_set - allocated_set

        if missing_ids:
            # Add missing IDs and save
            self.id_manager.allocated.extend(sorted(missing_ids))
            self.id_manager.allocated = sorted(set(self.id_manager.allocated))
            self.id_manager._save_ids()

        # Auto-fix any duplicate IDs after migration
        self._autofix_duplicate_ids()

    def _autofix_duplicate_ids(self):
        """
        Detect and automatically fix duplicate task IDs.
        Creates backup before fixing and shows warning to user.
        """
        all_tasks = self.tasks + self.archived
        ids = [task['id'] for task in all_tasks if 'id' in task]

        # Check for duplicates

        id_counts = Counter(ids)
        duplicates = {task_id: count for task_id, count in id_counts.items() if count > 1}

        if not duplicates:
            return  # No duplicates, nothing to fix

        # Create backup before fixing
        now = datetime.now()
        timestamp = now.strftime("%Y%m%d_%H%M%S")
        year_month = now.strftime("%Y-%m")

        # Create backup directory structure
        backup_dir = self.storage_file.parent / '.jot-backups' / year_month
        backup_dir.mkdir(parents=True, exist_ok=True)

        # Create backup file in organized structure
        backup_file = backup_dir / f'{timestamp}.json'
        with open(self.storage_file, 'r') as f:
            backup_data = f.read()
        with open(backup_file, 'w') as f:
            f.write(backup_data)

        # Build list of tasks that need new IDs
        # Strategy: Keep first occurrence, reassign subsequent duplicates
        seen_ids = set()
        tasks_to_fix = []  # List of (task, list_name, index) tuples

        for idx, task in enumerate(self.tasks):
            task_id = task.get('id')
            if task_id in duplicates:
                if task_id in seen_ids:
                    # This is a duplicate, needs new ID
                    tasks_to_fix.append((task, 'tasks', idx))
                else:
                    # First occurrence, keep it
                    seen_ids.add(task_id)

        for idx, task in enumerate(self.archived):
            task_id = task.get('id')
            if task_id in duplicates:
                if task_id in seen_ids:
                    # This is a duplicate, needs new ID
                    tasks_to_fix.append((task, 'archived', idx))
                else:
                    # First occurrence, keep it
                    seen_ids.add(task_id)

        # Reassign IDs for duplicate tasks
        old_to_new = {}  # Map old ID -> new ID for reporting
        for task, list_name, idx in tasks_to_fix:
            old_id = task['id']
            new_id = self.id_manager.allocate_id()
            task['id'] = new_id

            if old_id not in old_to_new:
                old_to_new[old_id] = []
            old_to_new[old_id].append(new_id)

        # Save fixed data
        self._save_tasks()

        # Show warning message
        YELLOW = '\033[93m'
        RESET = '\033[0m'
        DIM = '\033[2m'

        print(f"\n{YELLOW}⚠ Auto-fixed duplicate task IDs{RESET}")
        print(f"  Backup: {DIM}{backup_file}{RESET}")
        changes = []
        for old_id, new_ids in sorted(old_to_new.items()):
            changes.append(f"{old_id} → {', '.join(map(str, new_ids))}")
        print(f"  Changed: {', '.join(changes)}")
        print()

    def _get_next_id(self):
        """
        DEPRECATED: Use id_manager.allocate_id() instead.
        Get next available ID by finding max across tasks and archive.
        """
        max_id = 0
        for task in self.tasks + self.archived:
            if task.get('id', 0) > max_id:
                max_id = task['id']
        return max_id + 1

    def add_task(self, task_text, priority='none', status='todo', labels=None, effort=None):
        """
        Add a new task with guaranteed unique ID from IDManager

        Args:
            task_text: Task description
            priority: Task priority ('none', 'low', 'medium', 'high')
            status: Task status ('todo', 'in-progress', 'blocked', 'done')
            labels: List of labels (e.g., ['bug', 'feature', 'tech-debt'])
            effort: Effort estimation (1-5 points or None)
        """

        now = datetime.now(timezone.utc).isoformat()

        # Extract keyword from task text
        keyword, task_text = self.keyword_handler.extract_keyword(task_text)

        # Allocate unique ID
        new_id = self.id_manager.allocate_id()

        # Validate ID uniqueness before creating task (safety check)
        existing_ids = {task['id'] for task in self.tasks + self.archived if 'id' in task}
        if new_id in existing_ids:
            # This should never happen with proper file locking, but if it does,
            # log error and auto-fix by requesting a new ID

            print(
                f"WARNING: Duplicate ID {new_id} detected during task creation. "
                f"This indicates a concurrency issue. Auto-fixing...",
                file=sys.stderr,
            )
            # Try to get a fresh ID by reloading state
            self.id_manager._load_ids()
            new_id = self.id_manager.allocate_id()

            # If still duplicate, something is very wrong
            if new_id in existing_ids:
                raise ValueError(
                    f"Critical error: Unable to allocate unique ID. "
                    f"ID {new_id} already exists. Please check .jot.ids.json"
                )

        # Create task object
        task = {
            'id': new_id,
            'text': task_text,
            'done': False,
            'current': False,
            'day': None,
            'tally': 0,
            'agent_task': False,  # Mark if Claude Code is working on this
            # Backlog grooming metadata
            'priority': priority,
            'status': status,
            'created_at': now,
            'updated_at': now,
            'labels': labels if labels is not None else [],
            'effort': effort,
            'blocked_by': [],
            'notes': '',  # Additional notes for the task
            'keyword': keyword,  # Automation keyword (e.g., 'bullet', 'gcal')
        }

        self.tasks.append(task)
        self._save_tasks()

        # Trigger keyword action if auto-trigger is enabled
        if keyword:
            result = self.keyword_handler.handle(keyword, task)
            if result:
                # Save task again if handler modified it (e.g., ai: sets agent_task)
                self._save_tasks()

    def migrate_backlog_schema(self):
        """
        Migrate existing tasks to include backlog grooming metadata.
        Adds missing fields with sensible defaults:
        - priority: 'none'
        - status: 'todo' (or 'done' if task.done == True)
        - created_at: current timestamp (best effort for existing tasks)
        - updated_at: current timestamp
        - labels: [] (empty list)
        - effort: None
        - blocked_by: [] (empty list)

        Returns:
            dict: Migration statistics
        """

        now = datetime.now(timezone.utc).isoformat()
        migrated_count = 0
        already_migrated = 0

        for task in self.tasks + self.archived:
            # Check if task already has new schema
            has_new_fields = (
                'priority' in task
                and 'status' in task
                and 'created_at' in task
                and 'updated_at' in task
                and 'labels' in task
                and 'effort' in task
                and 'blocked_by' in task
                and 'notes' in task
                and 'keyword' in task
            )

            if has_new_fields:
                already_migrated += 1
                continue

            # Add missing fields with defaults
            if 'priority' not in task:
                task['priority'] = 'none'

            if 'status' not in task:
                # Infer status from existing 'done' field
                task['status'] = 'done' if task.get('done', False) else 'todo'

            if 'created_at' not in task:
                task['created_at'] = now

            if 'updated_at' not in task:
                task['updated_at'] = now

            if 'labels' not in task:
                task['labels'] = []

            if 'effort' not in task:
                task['effort'] = None

            if 'blocked_by' not in task:
                task['blocked_by'] = []

            if 'notes' not in task:
                task['notes'] = ''

            if 'keyword' not in task:
                task['keyword'] = None

            migrated_count += 1

        # Save updated tasks
        if migrated_count > 0:
            self._save_tasks()

        return {
            'migrated': migrated_count,
            'already_migrated': already_migrated,
            'total': migrated_count + already_migrated,
        }

    def ensure_default_task(self):
        """Create default 'take a break' task if no tasks exist"""
        if not self.tasks and not self.archived:
            self.add_task("take a break")

    def set_current(self, task_id):
        """Mark a task as current (only one task can be current)

        If the task is archived, it will be automatically unarchived.
        """
        # Clear all current flags in active tasks
        for task in self.tasks:
            task['current'] = False

        # Check if task is in active tasks
        for task in self.tasks:
            if task['id'] == task_id:
                task['current'] = True
                self._save_tasks()
                return True

        # Check if task is archived - if so, unarchive it and set as current
        for i, task in enumerate(self.archived):
            if task['id'] == task_id:
                # Remove from archived
                archived_task = self.archived.pop(i)
                # Add to active tasks
                archived_task['current'] = True
                self.tasks.append(archived_task)
                self._save_tasks()
                return True

        return False

    def set_agent_task(self, task_id=None):
        """
        Mark a task as agent_task (Claude Code is working on it).
        Only one task can be marked as agent_task at a time.

        Args:
            task_id: Task ID to mark as agent_task. If None, uses current task.
                    If task_id is already agent_task, it will be unmarked.

        Returns:
            True if successful, False if task not found
        """
        # If no task_id provided, use current task
        if task_id is None:
            current = self.get_current_task()
            if not current:
                return False
            task_id = current['id']

        # Check if this task is already marked as agent_task (toggle behavior)
        target_task = None
        for task in self.tasks:
            if task['id'] == task_id:
                target_task = task
                break

        if not target_task:
            return False

        # Toggle: if already agent_task, unmark it
        if target_task.get('agent_task', False):
            target_task['agent_task'] = False
            self._save_tasks()
            return True

        # Otherwise, clear all agent_task flags and set the target
        for task in self.tasks:
            task['agent_task'] = False

        target_task['agent_task'] = True
        self._save_tasks()
        return True

    def get_tasks(self):
        """Return all tasks"""
        return self.tasks

    def get_current_task(self):
        """Get the currently selected task"""
        for task in self.tasks:
            if task.get('current', False):
                return task
        return None

    def move_task_up(self):
        """Move the current task up in the list"""
        if not self.tasks or len(self.tasks) < 2:
            return False

        current_idx = -1
        for i, task in enumerate(self.tasks):
            if task.get('current', False):
                current_idx = i
                break

        if current_idx <= 0:
            # Already at top or no current task
            return False

        # Swap with previous task
        self.tasks[current_idx], self.tasks[current_idx - 1] = (
            self.tasks[current_idx - 1],
            self.tasks[current_idx],
        )
        self._save_tasks()
        return True

    def move_task_down(self):
        """Move the current task down in the list"""
        if not self.tasks or len(self.tasks) < 2:
            return False

        current_idx = -1
        for i, task in enumerate(self.tasks):
            if task.get('current', False):
                current_idx = i
                break

        if current_idx == -1 or current_idx >= len(self.tasks) - 1:
            # No current task or already at bottom
            return False

        # Swap with next task
        self.tasks[current_idx], self.tasks[current_idx + 1] = (
            self.tasks[current_idx + 1],
            self.tasks[current_idx],
        )
        self._save_tasks()
        return True

    def remove_task(self, task_id):
        """Archive a task by ID and set previous task as current"""
        # Save notes to org file before archiving (if task has notes)
        org_file = self.save_notes_to_org_file(task_id)
        if org_file:
            filename = os.path.basename(org_file)
            print(f"\n✓ Notes saved to {filename}")

        task_to_archive = None
        task_index = -1

        # Find the task and its index
        for i, task in enumerate(self.tasks):
            if task['id'] == task_id:
                task_to_archive = task
                task_index = i
                break

        if task_to_archive:
            # Remove from active tasks
            self.tasks = [task for task in self.tasks if task['id'] != task_id]
            # Add to archived tasks
            self.archived.append(task_to_archive)

            # Set previous task as current (if any tasks remain)
            if self.tasks:
                # Clear all current flags first
                for task in self.tasks:
                    task['current'] = False

                # Determine which task should be current
                if task_index == 0:
                    # Deleted first task, make new first task current
                    self.tasks[0]['current'] = True
                else:
                    # Make previous task current (index is now one less due to deletion)
                    new_index = min(task_index - 1, len(self.tasks) - 1)
                    self.tasks[new_index]['current'] = True

            self._save_tasks()
            return True
        return False

    def delete_task_permanently(self, task_id):
        """Permanently delete a task by ID (from both active and archived lists)
        and release its ID for reuse"""
        # Save notes to org file before permanent deletion (if task has notes)
        org_file = self.save_notes_to_org_file(task_id)
        if org_file:
            filename = os.path.basename(org_file)
            print(f"\n✓ Notes saved to {filename}")

        deleted = False

        # Remove from active tasks
        original_count = len(self.tasks)
        self.tasks = [task for task in self.tasks if task['id'] != task_id]
        if len(self.tasks) < original_count:
            deleted = True

        # Remove from archived tasks
        original_archived_count = len(self.archived)
        self.archived = [task for task in self.archived if task['id'] != task_id]
        if len(self.archived) < original_archived_count:
            deleted = True

        if deleted:
            # Release the ID for reuse
            self.id_manager.release_id(task_id)
            self._save_tasks()
            return True
        return False

    def archive_task(self, task_id):
        """Archive a task by ID (wrapper around remove_task for consistency)"""
        return self.remove_task(task_id)

    def edit_task(self, task_id, new_text):
        """Edit a task's text by ID"""
        for task in self.tasks:
            if task['id'] == task_id:
                task['text'] = new_text
                self._save_tasks()
                return True
        return False

    def set_task_day(self, task_id, day):
        """Assign a day of the week to a task

        Args:
            task_id: ID of task to update
            day: Day name (Monday-Sunday) or None to clear
        """
        for task in self.tasks:
            if task['id'] == task_id:
                task['day'] = day
                self._save_tasks()
                return True
        return False

    def set_task_priority(self, task_id, priority):
        """Set priority for a task

        Args:
            task_id: ID of task to update
            priority: Priority level ('none', 'low', 'medium', 'high')
        """

        valid_priorities = ['none', 'low', 'medium', 'high']
        if priority not in valid_priorities:
            raise ValueError(f"Priority must be one of: {', '.join(valid_priorities)}")

        for task in self.tasks:
            if task['id'] == task_id:
                task['priority'] = priority
                task['updated_at'] = datetime.now(timezone.utc).isoformat()
                self._save_tasks()
                return True
        return False

    def set_task_status(self, task_id, status):
        """Set status for a task

        Args:
            task_id: ID of task to update
            status: Status ('todo', 'in-progress', 'blocked', 'done')
        """

        valid_statuses = ['todo', 'in-progress', 'blocked', 'done']
        if status not in valid_statuses:
            raise ValueError(f"Status must be one of: {', '.join(valid_statuses)}")

        for task in self.tasks:
            if task['id'] == task_id:
                task['status'] = status
                task['updated_at'] = datetime.now(timezone.utc).isoformat()
                # Auto-update 'done' field based on status
                if status == 'done':
                    task['done'] = True
                elif task.get('done', False):
                    # If status is changing from done to something else, unmark done
                    task['done'] = False
                self._save_tasks()
                return True
        return False

    def get_task_notes(self, task_id):
        """Get notes for a task

        Args:
            task_id: ID of task

        Returns:
            str: Notes text (empty string if no notes)
        """
        for task in self.tasks:
            if task['id'] == task_id:
                return task.get('notes', '')
        return ''

    def set_task_notes(self, task_id, notes_text):
        """Set notes for a task

        Args:
            task_id: ID of task to update
            notes_text: Notes text (can be multi-line)

        Returns:
            bool: True if task found and updated, False otherwise
        """

        for task in self.tasks:
            if task['id'] == task_id:
                task['notes'] = notes_text
                task['updated_at'] = datetime.now(timezone.utc).isoformat()
                self._save_tasks()
                return True
        return False

    def save_notes_to_org_file(self, task_id):
        """Save task notes to an org file before deletion.
        Only creates file if task has non-empty notes.

        Args:
            task_id: ID of task to save notes from

        Returns:
            str: Path to created org file, or None if no notes
        """

        # Get the task from either active or archived list
        task = None
        for t in self.tasks:
            if t['id'] == task_id:
                task = t
                break
        if not task:
            for t in self.archived:
                if t['id'] == task_id:
                    task = t
                    break

        if not task:
            return None

        # Check if task has notes
        notes = task.get('notes', '').strip()
        if not notes:
            return None

        # Create org file content with proper formatting
        timestamp = datetime.now().strftime('%Y-%m-%d')
        created_at = task.get('created_at', 'unknown')
        if created_at != 'unknown':
            try:
                # Try to format ISO timestamp to readable format
                created_dt = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
                created_at = created_dt.strftime('%Y-%m-%d %H:%M:%S')
            except Exception:
                pass

        org_content = f'''#+TITLE: Task #{task_id} Notes (Deleted)
#+DATE: {timestamp}

* Task Information
  - ID: {task_id}
  - Text: {task['text']}
  - Status: {task.get('status', 'todo')}
  - Priority: {task.get('priority', 'none')}
  - Created: {created_at}

* Notes
{notes}

* Metadata
  - Deleted: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
  - Original file: {self.storage_file.name}
'''

        # Create filename with timestamp to avoid conflicts
        file_timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f'TASK-{task_id}-notes-{file_timestamp}.org'
        org_file_path = self.project_dir / filename

        # Write file
        try:
            with open(org_file_path, 'w') as f:
                f.write(org_content)
            return str(org_file_path)
        except Exception as e:
            print(f"Warning: Could not save notes to org file: {e}")
            return None

    def get_task_age_days(self, task):
        """Calculate age of task in days since last update

        Args:
            task: Task dictionary

        Returns:
            int: Number of days since last update, or None if no timestamp
        """

        updated_at = task.get('updated_at')
        if not updated_at:
            return None

        try:
            # Parse ISO 8601 timestamp
            updated_dt = datetime.fromisoformat(updated_at.replace('Z', '+00:00'))
            now = datetime.now(timezone.utc)

            # Calculate days since last update
            age = (now - updated_dt).days
            return age
        except (ValueError, AttributeError):
            return None

    def is_task_stale(self, task, stale_threshold_days=7):
        """Check if a task is considered stale

        Args:
            task: Task dictionary
            stale_threshold_days: Number of days after which task is stale

        Returns:
            bool: True if task is stale, False otherwise
        """
        # Done tasks are not considered stale
        if task.get('done', False) or task.get('status') == 'done':
            return False

        age = self.get_task_age_days(task)
        if age is None:
            return False

        return age >= stale_threshold_days

    def increment_tally(self):
        """Increment the tally counter for the current task"""
        for task in self.tasks:
            if task.get('current', False):
                # Initialize tally if not present (backward compatibility)
                if 'tally' not in task:
                    task['tally'] = 0
                task['tally'] += 1
                self._save_tasks()
                return task['tally']
        return None

    def set_next_current(self):
        """Set the next task as current"""
        if not self.tasks:
            return False

        current_idx = -1
        for i, task in enumerate(self.tasks):
            if task.get('current', False):
                current_idx = i
                break

        # Clear all current flags
        for task in self.tasks:
            task['current'] = False

        # Set next task as current (wrap around)
        if current_idx == -1:
            # No current task, set first one
            self.tasks[0]['current'] = True
        else:
            next_idx = (current_idx + 1) % len(self.tasks)
            self.tasks[next_idx]['current'] = True

        self._save_tasks()
        return True

    def set_prev_current(self):
        """Set the previous task as current"""
        if not self.tasks:
            return False

        current_idx = -1
        for i, task in enumerate(self.tasks):
            if task.get('current', False):
                current_idx = i
                break

        # Clear all current flags
        for task in self.tasks:
            task['current'] = False

        # Set previous task as current (wrap around)
        if current_idx == -1:
            # No current task, set last one
            self.tasks[-1]['current'] = True
        else:
            prev_idx = (current_idx - 1) % len(self.tasks)
            self.tasks[prev_idx]['current'] = True

        self._save_tasks()
        return True

    def refresh(self):
        """Reload tasks from file"""
        self._load_tasks()


class CommandHandler:
    """Extensible command system"""

    def __init__(self, task_manager, registry=None):
        self.task_manager = task_manager
        self.registry = registry
        self.commands = {
            'a': self.add_task,
            'c': self.set_current,
            'd': self.delete_task,
            'D': self.delete_current,
            'e': self.edit_task,
            'E': self.edit_current,
            'M': self.move_task_to_project,
            'r': self.refresh,
            'q': self.quit,
            'h': self.help,
        }

    @staticmethod
    def safe_launch_editor(file_path):
        """
        Safely launch editor with file_path, avoiding command injection.

        Security: Uses shlex.split() to safely parse $EDITOR which may contain
        arguments (e.g., "emacs -nw"), then calls subprocess without shell=True
        to prevent command injection attacks.

        Args:
            file_path: Path to file to edit (str or Path)

        Returns:
            True if editor launched successfully, False otherwise

        Raises:
            FileNotFoundError: If editor command not found
        """

        # Get editor from environment
        editor = os.environ.get('EDITOR', os.environ.get('VISUAL', 'nano'))

        # Parse editor command safely (handles editors with args like "emacs -nw")
        try:
            editor_parts = shlex.split(editor)
        except ValueError:
            # Invalid shell syntax in $EDITOR - use safe default
            print(f"\n⚠️  Invalid $EDITOR value: {editor}")
            print("   Using nano instead")
            editor_parts = ['nano']

        # Add file path to command
        editor_parts.append(str(file_path))

        # Execute without shell=True (prevents command injection)
        try:
            result = subprocess.call(editor_parts)
            return result == 0
        except FileNotFoundError:
            raise FileNotFoundError(f"Editor not found: {editor_parts[0]}")

    def add_task(self):
        """Add a new task"""
        print("\nEnter task: ", end='', flush=True)
        task_text = input().strip()
        if task_text:
            self.task_manager.add_task(task_text)
            print(f"✓ Added: {task_text}")
        return True

    def quit(self):
        """Quit the application"""
        print("\nGoodbye!")
        return False

    def set_current(self):
        """Mark a task as current"""
        print("\nTask ID to mark as current: ", end='', flush=True)
        try:
            task_id = int(input().strip())
            if self.task_manager.set_current(task_id):
                print(f"✓ Task {task_id} marked as current")
            else:
                print(f"✗ Task {task_id} not found")
        except ValueError:
            print("✗ Invalid task ID")
        return True

    def set_agent_task(self):
        """Mark current task as agent task (Claude Code is working on it)"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            return True

        task_id = current_task['id']
        is_currently_agent = current_task.get('agent_task', False)

        if self.task_manager.set_agent_task(task_id):
            MAGENTA = '\033[95m'
            RESET = '\033[0m'
            if is_currently_agent:
                # Was unmarked
                print(f"\n✓ Task {task_id} unmarked as agent task")
            else:
                # Was marked
                print(f"\n{MAGENTA}✓ Task {task_id} marked as agent task 🤖{RESET}")
        else:
            print(f"\n✗ Failed to mark task")
        return True

    def fix_duplicate_ids_interactive(self):
        """Check for and fix duplicate task IDs (Shift+1)"""

        GREEN = '\033[92m'
        YELLOW = '\033[93m'
        RESET = '\033[0m'
        DIM = '\033[2m'
        BOLD = '\033[1m'

        # Check for duplicates
        all_tasks = self.task_manager.tasks + self.task_manager.archived
        ids = [task['id'] for task in all_tasks if 'id' in task]

        id_counts = Counter(ids)
        duplicates = {task_id: count for task_id, count in id_counts.items() if count > 1}

        if not duplicates:
            print(f"\n{GREEN}✓ No duplicate IDs found{RESET}")
            print(f"  {DIM}All task IDs are unique{RESET}")
            return True

        # Show what we found
        print(f"\n{YELLOW}🔧 Found duplicate IDs:{RESET}")
        for task_id, count in sorted(duplicates.items()):
            print(f"  ID {BOLD}{task_id}{RESET}: {count} occurrences")

        # Create backup before fixing
        now = datetime.now()
        timestamp = now.strftime("%Y%m%d_%H%M%S")
        year_month = now.strftime("%Y-%m")

        backup_dir = self.task_manager.storage_file.parent / '.jot-backups' / year_month
        backup_dir.mkdir(parents=True, exist_ok=True)

        backup_file = backup_dir / f'{timestamp}.json'
        with open(self.task_manager.storage_file, 'r') as f:
            backup_data = f.read()
        with open(backup_file, 'w') as f:
            f.write(backup_data)

        # Build list of tasks that need new IDs
        seen_ids = set()
        tasks_to_fix = []

        for idx, task in enumerate(self.task_manager.tasks):
            task_id = task.get('id')
            if task_id in duplicates:
                if task_id in seen_ids:
                    tasks_to_fix.append((task, 'tasks', idx))
                else:
                    seen_ids.add(task_id)

        for idx, task in enumerate(self.task_manager.archived):
            task_id = task.get('id')
            if task_id in duplicates:
                if task_id in seen_ids:
                    tasks_to_fix.append((task, 'archived', idx))
                else:
                    seen_ids.add(task_id)

        # Reassign IDs
        old_to_new = {}
        for task, list_name, idx in tasks_to_fix:
            old_id = task['id']
            new_id = self.task_manager.id_manager.allocate_id()
            task['id'] = new_id

            if old_id not in old_to_new:
                old_to_new[old_id] = []
            old_to_new[old_id].append(new_id)

        # Save fixed data
        self.task_manager._save_tasks()

        # Show success message
        print(f"\n{GREEN}✓ Fixed {len(tasks_to_fix)} duplicate ID(s){RESET}")
        print(f"  {DIM}Backup: {backup_file.name}{RESET}")

        changes = []
        for old_id, new_ids in sorted(old_to_new.items()):
            changes.append(f"{old_id} → {', '.join(map(str, new_ids))}")
        if changes:
            print(f"  {DIM}Changes: {', '.join(changes)}{RESET}")

        return True

    def delete_task(self):
        """Delete a task by ID"""
        print("\nTask ID to delete: ", end='', flush=True)
        try:
            task_id = int(input().strip())
            if self.task_manager.remove_task(task_id):
                print(f"✓ Task {task_id} deleted")
            else:
                print(f"✗ Task {task_id} not found")
        except ValueError:
            print("✗ Invalid task ID")
        return True

    def delete_current(self):
        """Delete the current task"""
        current_task = self.task_manager.get_current_task()
        if current_task:
            task_id = current_task['id']
            if self.task_manager.remove_task(task_id):
                print(f"\n✓ Current task deleted")
            else:
                print(f"\n✗ Failed to delete task")
        else:
            print("\n✗ No current task selected")
        return True

    def edit_task(self):
        """Edit a task's text"""
        print("\nTask ID to edit: ", end='', flush=True)
        try:
            task_id = int(input().strip())

            # Find the task to get current text
            task = None
            for t in self.task_manager.tasks:
                if t['id'] == task_id:
                    task = t
                    break

            if not task:
                print(f"✗ Task {task_id} not found")
                return True

            print(f"Editing task {task_id}:")
            try:
                new_text = input_with_prefill("", prefill=task['text']).strip()
                if new_text:
                    if self.task_manager.edit_task(task_id, new_text):
                        print(f"✓ Task {task_id} updated")
                    else:
                        print(f"✗ Failed to update task")
                else:
                    print("✗ Task text cannot be empty")
            except (EOFError, KeyboardInterrupt):
                print("\n✗ Edit cancelled")
        except ValueError:
            print("✗ Invalid task ID")
        return True

    def edit_current(self):
        """Edit the current task"""
        current_task = self.task_manager.get_current_task()
        if current_task:
            task_id = current_task['id']
            current_text = current_task['text']
            print(f"\nEditing task {task_id}:")
            try:
                new_text = input_with_prefill("", prefill=current_text).strip()
                if new_text:
                    if self.task_manager.edit_task(task_id, new_text):
                        print(f"✓ Task updated")
                    else:
                        print(f"✗ Failed to update task")
                else:
                    print("✗ Task text cannot be empty")
            except (EOFError, KeyboardInterrupt):
                print("\n✗ Edit cancelled")
        else:
            print("\n✗ No current task selected")
        return True

    def move_task_to_project(self):
        """Move current task to a different project"""
        if not self.registry:
            print("\n✗ Project registry not available")
            return True

        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            return True

        # Extract all task metadata for preservation
        task_id = current_task['id']
        task_text = current_task['text']
        task_priority = current_task.get('priority', 'none')
        task_status = current_task.get('status', 'todo')
        task_labels = current_task.get('labels', [])
        task_effort = current_task.get('effort', None)
        task_notes = current_task.get('notes', '')
        task_agent = current_task.get('agent_task', False)
        task_keyword = current_task.get('keyword', None)
        task_created = current_task.get('created_at', None)
        task_day = current_task.get('day', None)

        # Get list of projects
        projects = self.registry.list_projects()
        if not projects:
            print("\n✗ No registered projects available")
            return True

        # Get current project directory to exclude it
        current_dir = str(self.task_manager.project_dir.resolve())
        available_projects = {
            name: path
            for name, path in projects.items()
            if str(Path(path).resolve()) != current_dir
        }

        if not available_projects:
            print("\n✗ No other projects available")
            return True

        # Display available projects
        print(f"\nMove task '{task_text}' to:")
        project_list = sorted(available_projects.keys())
        for i, name in enumerate(project_list, 1):
            print(f"  {i}. {name}")

        print("\nEnter project number or name (ESC to cancel): ", end='', flush=True)

        # Get user input
        try:
            user_input = input().strip()

            # Check if ESC or empty
            if not user_input or user_input == '\x1b':
                print("✗ Cancelled")
                return True

            # Try as number first
            try:
                project_index = int(user_input) - 1
                if 0 <= project_index < len(project_list):
                    target_project = project_list[project_index]
                else:
                    print("✗ Invalid project number")
                    return True
            except ValueError:
                # Try as project name
                if user_input in available_projects:
                    target_project = user_input
                else:
                    print(f"✗ Project '{user_input}' not found")
                    return True

            # Get target project path
            target_path = available_projects[target_project]

            # Check if we should preserve the category
            current_category = self.task_manager.category
            target_category = None
            category_preserved = False

            if current_category:
                # Check if target project has the same category
                target_cat_manager = CategoryManager(project_dir=target_path)
                if target_cat_manager.category_exists_locally(current_category):
                    target_category = current_category
                    category_preserved = True

            # Add task to target project (with or without category)
            target_tm = TaskManager(directory=target_path, category=target_category)
            target_tm.add_task(
                task_text,
                priority=task_priority,
                status=task_status,
                labels=task_labels,
                effort=task_effort,
            )

            # Get the newly created task to set additional metadata
            new_task = target_tm.tasks[-1]  # Last added task

            # Set fields not supported by add_task parameters
            new_task['notes'] = task_notes
            new_task['agent_task'] = task_agent
            new_task['keyword'] = task_keyword
            new_task['day'] = task_day

            # Preserve original creation time if available
            if task_created:
                new_task['created_at'] = task_created

            # Save the target task manager to persist all changes
            target_tm._save_tasks()

            # Remove from current project
            self.task_manager.remove_task(task_id)

            # Show result with category info
            if category_preserved:
                print(f"✓ Moved task to {target_project} (kept in '{current_category}' category)")
            elif current_category:
                print(
                    f"✓ Moved task to {target_project} (category '{current_category}' not available, added to default)"
                )
            else:
                print(f"✓ Moved task to {target_project}")
            return True

        except KeyboardInterrupt:
            print("\n✗ Cancelled")
            return True

    def transfer_task_to_category(self):
        """Transfer current task to a different category within the same project"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            return True

        task_text = current_task['text']
        task_id = current_task['id']
        task_done = current_task.get('done', False)

        # Get current project directory
        project_dir = (
            self.task_manager.project_dir if not self.task_manager.is_global else Path.cwd()
        )
        current_category = self.task_manager.category

        # Discover available categories
        cat_manager = CategoryManager(project_dir=project_dir)
        local_categories = cat_manager.discover_categories()
        global_categories = cat_manager.discover_global_categories()

        # Build category list (excluding current category)
        categories = []

        # Add default if we're not already in it
        if current_category is not None:
            categories.append(("default", None, False))

        # Add local categories (excluding current)
        for cat in local_categories:
            if cat != current_category:
                categories.append((cat, cat, False))

        # Add global categories (excluding current, and avoiding duplicates with local)
        for cat in global_categories:
            if cat != current_category and cat not in local_categories:
                categories.append((cat, cat, True))

        if not categories:
            print("\n✗ No other categories available")
            return True

        # Display available categories
        RESET = '\033[0m'

        # Get category config for colors
        cat_config = CategoryConfig(project_dir=project_dir)

        print(f"\nTransfer task '{task_text}' to:")
        for i, (display_name, cat_name, is_global) in enumerate(categories, 1):
            if display_name == "default":
                cat_color = cat_config.get_color('default')
                print(f"  {i}. {cat_color}default (no category){RESET}")
            else:
                cat_color = cat_config.get_color(cat_name, for_global=is_global)
                if is_global:
                    print(f"  {i}. {cat_color}{cat_name} [global]{RESET}")
                else:
                    print(f"  {i}. {cat_color}{cat_name} [local]{RESET}")

        print("\nEnter number or name (ESC to cancel): ", end='', flush=True)

        # Restore terminal to normal mode and flush any pending input
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        termios.tcflush(fd, termios.TCIFLUSH)

        # Get user input
        try:
            user_input = input().strip()

            # Check if ESC or empty
            if not user_input or user_input == '\x1b':
                print("✗ Cancelled")
                return True

            # Try as number first
            selected_category = None
            selected_is_global = False

            try:
                choice_index = int(user_input) - 1
                if 0 <= choice_index < len(categories):
                    display_name, cat_name, is_global = categories[choice_index]
                    selected_category = cat_name
                    selected_is_global = is_global
                else:
                    print("✗ Invalid number")
                    return True
            except ValueError:
                # Try as category name
                found = False
                for display_name, cat_name, is_global in categories:
                    if cat_name == user_input or display_name == user_input:
                        selected_category = cat_name
                        selected_is_global = is_global
                        found = True
                        break

                if not found:
                    print(f"✗ Category '{user_input}' not found")
                    return True

            # Add task to destination category
            if selected_is_global:
                dest_tm = TaskManager(category=selected_category, is_global=True)
            else:
                dest_tm = TaskManager(
                    directory=project_dir, category=selected_category, is_global=False
                )

            dest_tm.add_task(task_text)

            # Mark as done if original was done
            if task_done:
                new_task_id = dest_tm.tasks[-1]['id']  # Get the ID of newly added task
                dest_tm.set_task_status(new_task_id, 'done')

            # Remove from current category
            self.task_manager.remove_task(task_id)

            # Show result
            dest_name = selected_category or 'default'
            if selected_is_global:
                print(f"✓ Transferred task to global:{dest_name}")
            else:
                print(f"✓ Transferred task to {dest_name}")

            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        except KeyboardInterrupt:
            print("\n✗ Cancelled")
            return True

    def web_search(self):
        """Open a web search with the current task text"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            return True

        task_text = current_task['text']

        # URL-encode the task text
        query = urllib.parse.quote_plus(task_text)

        # Build Google search URL
        search_url = f"https://www.google.com/search?q={query}"

        try:
            # Open URL in default browser
            webbrowser.open(search_url)
            print(f"\n✓ Opened web search for: {task_text}")
        except Exception as e:
            print(f"\n✗ Failed to open browser: {e}")

        return True

    def open_url(self):
        """Open URL(s) from current task text in browser"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            return True

        task_text = current_task['text']

        # Extract URLs from task text
        urls = extract_urls(task_text)

        if not urls:
            print(f"\n✗ No URLs found in task: {task_text}")
            return True

        if len(urls) == 1:
            # Single URL - open it directly
            url = urls[0]
            try:
                webbrowser.open(url)
                print(f"\n✓ Opened URL: {url}")
            except Exception as e:
                print(f"\n✗ Failed to open browser: {e}")
        else:
            # Multiple URLs - show menu
            print(f"\nFound {len(urls)} URLs in task:")
            for i, url in enumerate(urls, 1):
                print(f"  {i}. {url}")

            print(
                "\nSelect URL to open (1-{}, or Enter to cancel): ".format(len(urls)),
                end='',
                flush=True,
            )
            try:
                choice = input().strip()
                if not choice:
                    print("✗ Cancelled")
                    return True

                index = int(choice) - 1
                if 0 <= index < len(urls):
                    url = urls[index]
                    webbrowser.open(url)
                    print(f"✓ Opened URL: {url}")
                else:
                    print("✗ Invalid selection")
            except (ValueError, KeyboardInterrupt):
                print("\n✗ Cancelled")

        return True

    def assign_day(self):
        """Assign a day of the week to the current task"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            return True

        task_text = current_task['text']
        task_id = current_task['id']
        current_day = current_task.get('day')

        # Display menu
        RESET = '\033[0m'
        BOLD = '\033[1m'
        CYAN = '\033[96m'

        print(f"\n{BOLD}Assign day to task:{RESET} {task_text}")
        if current_day:
            day_color = DAY_COLORS.get(current_day, CYAN)
            print(f"Current: {day_color}{current_day}{RESET}\n")
        else:
            print("Current: (none)\n")

        # Get today's day of week (0=Monday, 6=Sunday)
        today_weekday = datetime.now().weekday()
        days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        today_index = today_weekday  # 0-6
        today_menu_number = today_index + 1  # 1-7
        today_name = days[today_index]

        # Show day options with colors, highlighting today
        for i, day in enumerate(days, 1):
            day_color = DAY_COLORS[day]
            abbrev = DAY_ABBREVIATIONS[day]
            if i == today_menu_number:
                # Highlight today with > indicator
                print(
                    f"  {BOLD}>{RESET} {i}. {day_color}{abbrev}{RESET} {day} {BOLD}(Today){RESET}"
                )
            else:
                print(f"    {i}. {day_color}{abbrev}{RESET} {day}")

        print(f"\n  {BOLD}c{RESET}. Clear day")
        print(f"  {BOLD}ESC{RESET}. Cancel\n")

        # Show default in prompt
        default_day_color = DAY_COLORS[today_name]
        default_abbrev = DAY_ABBREVIATIONS[today_name]
        print(
            f"Choice (default: {default_day_color}{default_abbrev}{RESET} {today_name}): ",
            end='',
            flush=True,
        )

        # Restore terminal and get input
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        termios.tcflush(fd, termios.TCIFLUSH)

        try:
            user_input = input().strip().lower()

            # Handle empty input - use today as default
            if not user_input:
                selected_day = today_name
                self.task_manager.set_task_day(task_id, selected_day)
                day_color = DAY_COLORS[selected_day]
                abbrev = DAY_ABBREVIATIONS[selected_day]
                print(f"✓ Day set to {day_color}{abbrev}{RESET} {selected_day}")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            # Handle ESC
            if user_input == '\x1b':
                print("✗ Cancelled")
                return True

            # Handle clear option
            if user_input == 'c':
                self.task_manager.set_task_day(task_id, None)
                print("✓ Day cleared")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            # Handle numeric selection
            try:
                choice = int(user_input)
                if 1 <= choice <= 7:
                    selected_day = days[choice - 1]
                    self.task_manager.set_task_day(task_id, selected_day)
                    day_color = DAY_COLORS[selected_day]
                    abbrev = DAY_ABBREVIATIONS[selected_day]
                    print(f"✓ Day set to {day_color}{abbrev}{RESET} {selected_day}")
                    print("\nPress Enter to continue...", end='', flush=True)
                    input()
                else:
                    print("✗ Invalid choice")
            except ValueError:
                print("✗ Invalid input")

        except KeyboardInterrupt:
            print("\n✗ Cancelled")

        return True

    def set_priority(self):
        """Set priority for the current task"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        task_text = current_task['text']
        task_id = current_task['id']
        current_priority = current_task.get('priority', 'none')

        # Priority colors and symbols
        PRIORITY_COLORS = {
            'none': '\033[2m',  # DIM
            'low': '\033[94m',  # BLUE
            'medium': '\033[93m',  # YELLOW
            'high': '\033[91m',  # RED
        }
        PRIORITY_SYMBOLS = {
            'none': '○',
            'low': '◔',
            'medium': '◑',
            'high': '●',
        }

        # Display menu
        RESET = '\033[0m'
        BOLD = '\033[1m'

        print(f"\n{BOLD}Set priority for task:{RESET} {task_text}")
        priority_color = PRIORITY_COLORS[current_priority]
        priority_symbol = PRIORITY_SYMBOLS[current_priority]
        print(f"Current: {priority_color}{priority_symbol} {current_priority}{RESET}\n")

        # Show priority options
        priorities = ['none', 'low', 'medium', 'high']
        for i, priority in enumerate(priorities, 1):
            color = PRIORITY_COLORS[priority]
            symbol = PRIORITY_SYMBOLS[priority]
            print(f"  {i}. {color}{symbol} {priority}{RESET}")

        print(f"\n  {BOLD}ESC{RESET}. Cancel\n")
        print("Choice: ", end='', flush=True)

        # Restore terminal and get input
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        termios.tcflush(fd, termios.TCIFLUSH)

        try:
            user_input = input().strip().lower()

            if not user_input or user_input == '\x1b':
                print("✗ Cancelled")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            # Handle numeric selection
            try:
                choice = int(user_input)
                if 1 <= choice <= 4:
                    selected_priority = priorities[choice - 1]
                    self.task_manager.set_task_priority(task_id, selected_priority)
                    priority_color = PRIORITY_COLORS[selected_priority]
                    priority_symbol = PRIORITY_SYMBOLS[selected_priority]
                    print(
                        f"✓ Priority set to {priority_color}{priority_symbol} {selected_priority}{RESET}"
                    )
                    print("\nPress Enter to continue...", end='', flush=True)
                    input()
                else:
                    print("✗ Invalid choice")
                    print("\nPress Enter to continue...", end='', flush=True)
                    input()
            except ValueError:
                print("✗ Invalid input")
                print("\nPress Enter to continue...", end='', flush=True)
                input()

        except KeyboardInterrupt:
            print("\n✗ Cancelled")
            print("\nPress Enter to continue...", end='', flush=True)
            input()

        return True

    def set_priority_high(self):
        """Quickly set current task priority to high (shortcut)"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            # Silently return if no task - don't interrupt flow
            return True

        task_id = current_task['id']

        # Set priority to high
        self.task_manager.set_task_priority(task_id, 'high')

        # Show brief confirmation (no "Press Enter" prompt)
        RESET = '\033[0m'
        GREEN = '\033[92m'
        RED = '\033[91m'  # High priority color

        print(f"\n{GREEN}✓{RESET} Priority set to {RED}● high{RESET}")

        return True

    def set_status(self):
        """Set status for the current task"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        task_text = current_task['text']
        task_id = current_task['id']
        current_status = current_task.get('status', 'todo')

        # Status colors and symbols
        STATUS_COLORS = {
            'todo': '\033[2m',  # DIM
            'in-progress': '\033[96m',  # CYAN
            'blocked': '\033[91m',  # RED
            'done': '\033[92m',  # GREEN
        }
        STATUS_SYMBOLS = {
            'todo': '☐',
            'in-progress': '▶',
            'blocked': '⚠',
            'done': '✓',
        }

        # Display menu
        RESET = '\033[0m'
        BOLD = '\033[1m'

        print(f"\n{BOLD}Set status for task:{RESET} {task_text}")
        status_color = STATUS_COLORS[current_status]
        status_symbol = STATUS_SYMBOLS[current_status]
        print(f"Current: {status_color}{status_symbol} {current_status}{RESET}\n")

        # Show status options
        statuses = ['todo', 'in-progress', 'blocked', 'done']
        for i, status in enumerate(statuses, 1):
            color = STATUS_COLORS[status]
            symbol = STATUS_SYMBOLS[status]
            print(f"  {i}. {color}{symbol} {status}{RESET}")

        print(f"\n  {BOLD}ESC{RESET}. Cancel\n")
        print("Choice: ", end='', flush=True)

        # Restore terminal and get input
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        termios.tcflush(fd, termios.TCIFLUSH)

        try:
            user_input = input().strip().lower()

            if not user_input or user_input == '\x1b':
                print("✗ Cancelled")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            # Handle numeric selection
            try:
                choice = int(user_input)
                if 1 <= choice <= 4:
                    selected_status = statuses[choice - 1]
                    self.task_manager.set_task_status(task_id, selected_status)
                    status_color = STATUS_COLORS[selected_status]
                    status_symbol = STATUS_SYMBOLS[selected_status]
                    print(f"✓ Status set to {status_color}{status_symbol} {selected_status}{RESET}")
                    print("\nPress Enter to continue...", end='', flush=True)
                    input()
                else:
                    print("✗ Invalid choice")
                    print("\nPress Enter to continue...", end='', flush=True)
                    input()
            except ValueError:
                print("✗ Invalid input")
                print("\nPress Enter to continue...", end='', flush=True)
                input()

        except KeyboardInterrupt:
            print("\n✗ Cancelled")
            print("\nPress Enter to continue...", end='', flush=True)
            input()

        return True

    def select_gcal_account(self):
        """Select Google Calendar account for import/export

        Returns:
            str: Selected account name, or None if cancelled
        """
        # Discover available accounts
        account_manager = GoogleCalendarAccountManager()
        accounts = account_manager.discover_accounts()

        # ANSI color codes
        CYAN = '\033[96m'
        BOLD = '\033[1m'
        GREEN = '\033[92m'
        YELLOW = '\033[93m'
        RESET = '\033[0m'

        # If no accounts exist, guide user to create one
        if not accounts:
            print(f"\n{YELLOW}No Google Calendar accounts configured yet.{RESET}")
            print(f"\nWould you like to set up an account? (y/N): ", end='', flush=True)

            # Restore terminal
            fd = sys.stdin.fileno()
            old_settings = termios.tcgetattr(fd)
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
            termios.tcflush(fd, termios.TCIFLUSH)

            try:
                response = input().strip().lower()
                if response != 'y':
                    return None

                # Prompt for account name
                print(f"\nEnter account name (e.g., 'work', 'personal'): ", end='', flush=True)
                account_name = input().strip()

                if not account_name:
                    print("✗ Cancelled")
                    return None

                # Create account directory
                account_path = account_manager.create_account(account_name)

                # Provide instructions
                print(f"\n{GREEN}✓{RESET} Created account: {account_name}")
                print(f"\n{CYAN}{BOLD}Setup Instructions:{RESET}")
                print(f"1. Download credentials.json from Google Cloud Console:")
                print(f"   https://developers.google.com/workspace/calendar/api/quickstart/python")
                print(f"2. Save it to: {account_path / 'credentials.json'}")
                print(f"3. Run this command again to authenticate")

                return None

            except (KeyboardInterrupt, EOFError):
                print("\n✗ Cancelled")
                return None

        # Display account selection menu
        print(f"\n{CYAN}{BOLD}Select Google Calendar account:{RESET}")
        for i, account in enumerate(accounts, 1):
            print(f"  {i}. {account}")

        print(f"\n  {GREEN}[n]{RESET} Add new account")
        print(f"  {BOLD}ESC{RESET} Cancel\n")
        print("Choice: ", end='', flush=True)

        # Restore terminal
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        termios.tcflush(fd, termios.TCIFLUSH)

        # Get user input
        try:
            user_input = input().strip().lower()

            # Check for cancel
            if not user_input or user_input == '\x1b':
                print("✗ Cancelled")
                return None

            # Check for new account
            if user_input == 'n':
                print(f"\nEnter account name (e.g., 'work', 'personal'): ", end='', flush=True)
                account_name = input().strip()

                if not account_name:
                    print("✗ Cancelled")
                    return None

                # Create account directory
                account_path = account_manager.create_account(account_name)

                # Provide instructions
                print(f"\n{GREEN}✓{RESET} Created account: {account_name}")
                print(f"\n{CYAN}{BOLD}Setup Instructions:{RESET}")
                print(f"1. Download credentials.json from Google Cloud Console:")
                print(f"   https://developers.google.com/workspace/calendar/api/quickstart/python")
                print(f"2. Save it to: {account_path / 'credentials.json'}")
                print(f"3. Run this command again to authenticate")

                return None

            # Try as number
            try:
                choice_index = int(user_input) - 1
                if 0 <= choice_index < len(accounts):
                    return accounts[choice_index]
                else:
                    print("✗ Invalid number")
                    return None
            except ValueError:
                # Try as account name
                if user_input in accounts:
                    return user_input
                else:
                    print(f"✗ Account '{user_input}' not found")
                    return None

        except (KeyboardInterrupt, EOFError):
            print("\n✗ Cancelled")
            return None

    def export_to_gcal(self):
        """Export current task to Google Calendar"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        task_text = current_task['text']

        # Check if Google Calendar API is available
        if not GCAL_AVAILABLE:
            print("\n✗ Google Calendar API not available")
            print("   Install with: pip install google-auth google-auth-oauthlib")
            print("                  google-auth-httplib2 google-api-python-client")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        try:
            # Select Google Calendar account
            account_name = self.select_gcal_account()
            if not account_name:
                # User cancelled or needs to set up credentials
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            # Initialize auth and get service
            auth = GoogleCalendarAuth(account_name)
            service = auth.get_service()

            # Create event
            event_link = create_gcal_event(service, task_text)

            # Get start time for display (use timezone-aware datetime)
            now = datetime.now().astimezone()
            start_time = round_to_15_minutes(now)
            end_time = start_time + timedelta(minutes=15)

            # Display success
            RESET = '\033[0m'
            BOLD = '\033[1m'
            GREEN = '\033[92m'
            DIM = '\033[2m'

            print(f"\n{GREEN}✓{RESET} Event created: {BOLD}{task_text}{RESET}")
            print(f"   Account: {DIM}{account_name}{RESET}")
            print(f"   {start_time.strftime('%-I:%M %p')} - " f"{end_time.strftime('%-I:%M %p')}")
            if event_link:
                print(f"   {event_link}")

        except FileNotFoundError as e:
            print(f"\n✗ {e}")
        except ImportError as e:
            print(f"\n✗ {e}")
        except HttpError as e:
            print(f"\n✗ Google Calendar API error: {e}")
        except Exception as e:
            print(f"\n✗ Failed to create event: {e}")

        print("\nPress Enter to continue...", end='', flush=True)
        input()
        return True

    def import_from_gcal(self):
        """Import today's Google Calendar events as tasks"""
        # Check if Google Calendar API is available
        if not GCAL_AVAILABLE:
            print("\n✗ Google Calendar API not available")
            print("   Install with: pip install google-auth google-auth-oauthlib")
            print("                  google-auth-httplib2 google-api-python-client")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        try:
            # Select Google Calendar account
            account_name = self.select_gcal_account()
            if not account_name:
                # User cancelled or needs to set up credentials
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            # Initialize auth and get service
            auth = GoogleCalendarAuth(account_name)
            service = auth.get_service()

            # Fetch today's events
            events = fetch_gcal_events(service)

            if not events:
                print(f"\n📅 No events found for today (account: {account_name})")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            # Display events and confirm import
            RESET = '\033[0m'
            BOLD = '\033[1m'
            GREEN = '\033[92m'
            CYAN = '\033[96m'
            DIM = '\033[2m'

            print(
                f"\n{CYAN}{BOLD}Found {len(events)} event(s) for today:{RESET} {DIM}({account_name}){RESET}\n"
            )

            for i, event in enumerate(events, 1):
                if event['all_day']:
                    print(f"  {i}. 📅 {event['summary']}")
                else:
                    start_time = event['start'].strftime('%-I:%M %p')
                    end_time = event['end'].strftime('%-I:%M %p')
                    print(f"  {i}. {start_time} - {end_time}: {event['summary']}")

            print(f"\n{BOLD}Import all as tasks?{RESET} (y/N): ", end='', flush=True)

            fd = sys.stdin.fileno()
            old_settings = termios.tcgetattr(fd)
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
            termios.tcflush(fd, termios.TCIFLUSH)

            try:
                confirmation = input().strip().lower()

                if confirmation == 'y':
                    # Import each event as a task
                    imported_count = 0
                    for event in events:
                        if event['all_day']:
                            # All-day event: use emoji prefix
                            task_text = f"📅 {event['summary']}"
                        else:
                            # Timed event: include time range
                            start_time = event['start'].strftime('%-I:%M %p')
                            end_time = event['end'].strftime('%-I:%M %p')
                            task_text = f"{start_time} - {end_time}: {event['summary']}"

                        self.task_manager.add_task(task_text)
                        imported_count += 1

                    print(f"\n{GREEN}✓{RESET} Imported {imported_count} event(s) as tasks")
                else:
                    print("\n✗ Import cancelled")

            except (KeyboardInterrupt, EOFError):
                print("\n✗ Import cancelled")

        except FileNotFoundError as e:
            print(f"\n✗ {e}")
        except ImportError as e:
            print(f"\n✗ {e}")
        except HttpError as e:
            print(f"\n✗ Google Calendar API error: {e}")
        except Exception as e:
            print(f"\n✗ Failed to fetch events: {e}")

        print("\nPress Enter to continue...", end='', flush=True)
        input()
        return True

    def start_priority_timer(self):
        """Launch bullet priority timer for current task"""

        current_task = self.task_manager.get_current_task()

        # Display info message
        RESET = '\033[0m'
        BOLD = '\033[1m'
        YELLOW = '\033[93m'

        if current_task:
            task_text = current_task['text']
            print(f"\n{YELLOW}🔥 Starting priority timer for:{RESET} {BOLD}{task_text}{RESET}")
        else:
            print(f"\n{YELLOW}🔥 Starting priority timer...{RESET}")

        print("Duration: 12 minutes (default)")
        print("\nPress Enter to continue...", end='', flush=True)
        input()

        # Launch bullet priority timer in background
        try:
            subprocess.Popen(
                ['bullet', 'priority'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
            )
            print("\n✓ Priority timer started")
        except FileNotFoundError:
            print("\n✗ bullet command not found")
            print("   Install: cd ~/projects/bullet && npm link")
        except Exception as e:
            print(f"\n✗ Failed to start timer: {e}")

        print("\nPress Enter to continue...", end='', flush=True)
        input()
        return True

    def copy_to_clipboard(self):
        """Copy current task text to clipboard"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        task_text = current_task['text']

        # Copy to clipboard using pbcopy (macOS) or xclip/xsel (Linux)

        try:
            system = platform.system()
            if system == 'Darwin':  # macOS
                process = subprocess.Popen(
                    ['pbcopy'], stdin=subprocess.PIPE, stdout=subprocess.DEVNULL
                )
                process.communicate(task_text.encode('utf-8'))
            elif system == 'Linux':
                # Try xclip first, then xsel
                try:
                    process = subprocess.Popen(
                        ['xclip', '-selection', 'clipboard'],
                        stdin=subprocess.PIPE,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                    )
                    process.communicate(task_text.encode('utf-8'))
                except FileNotFoundError:
                    process = subprocess.Popen(
                        ['xsel', '--clipboard', '--input'],
                        stdin=subprocess.PIPE,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                    )
                    process.communicate(task_text.encode('utf-8'))
            else:
                print(f"\n✗ Clipboard not supported on {system}")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            # Success message
            CYAN = '\033[96m'
            RESET = '\033[0m'
            DIM = '\033[2m'

            # Truncate long text for display
            display_text = task_text if len(task_text) <= 60 else task_text[:57] + '...'

            print(f"\n{CYAN}✓ Copied to clipboard:{RESET}")
            print(f"  {DIM}{display_text}{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()

        except FileNotFoundError as e:
            print(f"\n✗ Clipboard tool not found: {e}")
            print("   Install xclip or xsel on Linux")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
        except Exception as e:
            print(f"\n✗ Failed to copy to clipboard: {e}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()

        return True

    def trigger_keyword_action(self):
        """Manually trigger keyword action for current task"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        keyword = current_task.get('keyword')
        if not keyword:
            print("\n✗ Current task has no keyword")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        # ANSI color codes
        CYAN = '\033[96m'
        RESET = '\033[0m'
        DIM = '\033[2m'

        # Trigger the keyword action
        result = self.task_manager.keyword_handler.handle(keyword, current_task)

        if result:
            # Save task if handler modified it
            self.task_manager._save_tasks()

            print(f"\n{CYAN}✓ Executed keyword action:{RESET}")
            print(f"  {DIM}Keyword: {keyword}{RESET}")
            print(f"  {DIM}{result}{RESET}")
        else:
            print(f"\n✗ Unknown keyword: {keyword}")

        print("\nPress Enter to continue...", end='', flush=True)
        input()
        return True

    def get_notes_file_extension(self, editor):
        """Determine file extension based on editor

        Args:
            editor: Editor command string from $EDITOR

        Returns:
            File extension string (e.g., '.org', '.txt')
        """
        editor_lower = editor.lower()

        # Detect Emacs variants (emacs, emacsclient, etc.) -> org-mode
        if 'emacs' in editor_lower:
            return '.org'
        # Default to plain text for other editors
        else:
            return '.txt'

    def edit_task_notes(self):
        """Edit notes for the current task using $EDITOR"""

        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        task_id = current_task['id']
        task_text = current_task['text']

        # Get current notes
        current_notes = self.task_manager.get_task_notes(task_id)

        # Determine editor to use
        editor = os.environ.get('EDITOR', os.environ.get('VISUAL', 'nano'))

        # Determine file extension based on editor
        file_extension = self.get_notes_file_extension(editor)
        is_org_mode = file_extension == '.org'

        # Create temporary file with current notes
        with tempfile.NamedTemporaryFile(mode='w+', suffix=file_extension, delete=False) as tf:
            temp_file = tf.name
            # Write help header with appropriate comment syntax
            if is_org_mode:
                tf.write(f"#+TITLE: Notes for task: {task_text}\n")
                tf.write("#+COMMENT: Lines starting with #+COMMENT will be ignored\n")
                tf.write("\n")
            else:
                tf.write(f"# Notes for task: {task_text}\n")
                tf.write("# Lines starting with # will be ignored\n")
                tf.write("#\n")
            if current_notes:
                tf.write(current_notes)

        try:
            # Launch editor safely (no command injection)
            self.safe_launch_editor(temp_file)

            # Read edited content
            with open(temp_file, 'r') as f:
                lines = f.readlines()

            # Filter out comment lines based on file type
            if is_org_mode:
                # For org-mode, filter out #+TITLE, #+COMMENT, and other #+directives
                edited_notes = ''.join(
                    line for line in lines if not line.strip().startswith('#+')
                ).strip()
            else:
                # For plain text, filter out # comments
                edited_notes = ''.join(
                    line for line in lines if not line.strip().startswith('#')
                ).strip()

            # Save notes
            self.task_manager.set_task_notes(task_id, edited_notes)

            # Show confirmation
            CYAN = '\033[96m'
            RESET = '\033[0m'
            DIM = '\033[2m'

            if edited_notes:
                # Show preview of notes (first 3 lines)
                note_lines = edited_notes.split('\n')
                preview = '\n  '.join(note_lines[:3])
                if len(note_lines) > 3:
                    preview += f"\n  {DIM}... ({len(note_lines)} lines total){RESET}"

                print(f"\n{CYAN}✓ Notes saved:{RESET}")
                print(f"  {DIM}{preview}{RESET}")
            else:
                print(f"\n{CYAN}✓ Notes cleared{RESET}")

            print("\nPress Enter to continue...", end='', flush=True)
            input()

        except FileNotFoundError:
            print(f"\n✗ Editor not found: {editor}")
            print(f"   Set $EDITOR environment variable or install nano")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
        except Exception as e:
            print(f"\n✗ Failed to edit notes: {e}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
        finally:
            # Clean up temp file
            try:
                os.unlink(temp_file)
            except Exception:
                pass

        return True

    def ultrathink_task(self):
        """Analyze current task with Claude Code (Shift+U)"""

        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        task_id = current_task['id']
        task_text = current_task['text']
        notes = current_task.get('notes', '')

        # Check if analysis already exists
        existing_analysis = Path.cwd() / f".jot.analysis.{task_id}.org"
        if existing_analysis.exists():
            # Ask if user wants to re-analyze
            print(f"\n⚠️  Analysis already exists: {existing_analysis.name}")
            print("\nOptions:")
            print("  [Enter] - View existing analysis")
            print("  [r]     - Re-analyze (overwrite)")
            print("  [c]     - Custom prompt re-analysis")
            print("  [q]     - Cancel")
            choice = input("\nChoice: ").strip().lower()

            if choice == 'q' or choice == '':
                if choice == '':
                    # View existing analysis
                    self.safe_launch_editor(existing_analysis)
                return True
            elif choice not in ['r', 'c']:
                return True

            if choice == 'c':
                # Get custom prompt
                print("\nEnter custom analysis focus (or press Enter for default):")
                print(
                    "Examples: 'security implications', 'performance optimization', 'test coverage'"
                )
                custom_focus = input("Focus: ").strip()
            else:
                custom_focus = None
        else:
            # New analysis - ask if user wants custom prompt
            print(f"\n🤔 Analyze: {task_text[:60]}{'...' if len(task_text) > 60 else ''}")
            print("\nOptions:")
            print("  [Enter] - Standard analysis")
            print("  [c]     - Custom analysis prompt")
            print("  [q]     - Cancel")
            choice = input("\nChoice: ").strip().lower()

            if choice == 'q':
                return True
            elif choice == 'c':
                print("\nEnter custom analysis focus:")
                print(
                    "Examples: 'security implications', 'performance optimization', 'test coverage'"
                )
                custom_focus = input("Focus: ").strip()
                if not custom_focus:
                    custom_focus = None
            else:
                custom_focus = None

        # Build analysis prompt
        notes_section = f"\n\nTask Notes:\n{notes}" if notes else ""

        if custom_focus:
            prompt = f"""Analyze this task with a focus on: {custom_focus}

Task: {task_text}{notes_section}

Please provide a detailed analysis in org-mode format, specifically addressing {custom_focus}.

Include relevant sections such as:
* Task Analysis
* {custom_focus.title()}
* Implementation Approach
* Acceptance Criteria
* Potential Risks

Format as a well-structured org-mode document."""
        else:
            # Default prompt (same as keyword handler)
            prompt = f"""Analyze this task and provide a structured implementation plan in org-mode format.

Task: {task_text}{notes_section}

Please create an org-mode document with the following sections:

* Task Analysis
** Overview
Brief description of what needs to be done

** Task Breakdown
- [ ] Subtask 1
- [ ] Subtask 2
- [ ] Subtask 3

** Technical Approach
Key technical decisions and implementation strategy

** Acceptance Criteria
- Criterion 1
- Criterion 2
- Criterion 3

** Complexity Estimate
Simple / Medium / Complex (with justification)

** Potential Risks
Any challenges or unknowns to consider

Format the entire response as a well-structured org-mode document."""

        # Show loading indicator
        CYAN = '\033[96m'
        RESET = '\033[0m'
        DIM = '\033[2m'
        GREEN = '\033[92m'
        YELLOW = '\033[93m'

        print(f"\n{CYAN}⏳ Analyzing with Claude Code...{RESET}")
        print(f"{DIM}This may take 10-15 seconds...{RESET}\n")

        try:
            # Check if claude CLI is available
            check_result = subprocess.run(['claude', '--version'], capture_output=True, timeout=5)

            if check_result.returncode != 0:
                print(f"{YELLOW}⚠️ Claude CLI not found.{RESET}")
                print("Install: https://claude.com/claude-code")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

        except (FileNotFoundError, subprocess.TimeoutExpired):
            print(f"{YELLOW}⚠️ Claude CLI not found.{RESET}")
            print("Install: https://claude.com/claude-code")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        try:
            # Invoke Claude in plan mode with JSON output
            result = subprocess.run(
                [
                    'claude',
                    '--print',
                    '--permission-mode',
                    'plan',
                    '--output-format',
                    'json',
                    '--max-turns',
                    '5',
                ],
                input=prompt,
                capture_output=True,
                text=True,
                timeout=120,  # 2 minute timeout
            )

            if result.returncode != 0:
                # Check for common errors
                stderr_lower = result.stderr.lower()

                if 'authentication' in stderr_lower or 'login' in stderr_lower:
                    print(f"{YELLOW}⚠️ Claude auth expired.{RESET}")
                    print("Run: claude login")
                elif 'network' in stderr_lower or 'connection' in stderr_lower:
                    print(f"{YELLOW}⚠️ Network error.{RESET}")
                    print("Check connection and try again")
                else:
                    error_msg = result.stderr[:100] if result.stderr else "Unknown error"
                    print(f"{YELLOW}⚠️ Claude failed: {error_msg}{RESET}")

                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            # Parse JSON response
            try:
                response = json.loads(result.stdout)
                analysis_text = response.get('result', '')

                if not analysis_text:
                    print(f"{YELLOW}⚠️ Empty response from Claude{RESET}")
                    print("\nPress Enter to continue...", end='', flush=True)
                    input()
                    return True

            except json.JSONDecodeError:
                print(f"{YELLOW}⚠️ Failed to parse Claude response{RESET}")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            # Save to .jot.analysis.{id}.org file
            output_file = Path.cwd() / f".jot.analysis.{task_id}.org"

            try:
                with open(output_file, 'w') as f:
                    f.write(f"#+TITLE: Analysis for Task {task_id}\n")
                    f.write(f"#+DATE: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
                    f.write(f"#+TASK: {task_text}\n")
                    if custom_focus:
                        f.write(f"#+FOCUS: {custom_focus}\n")
                    f.write("\n")
                    f.write(analysis_text)

                # Store analysis file reference in task
                current_task['analysis_file'] = str(output_file)
                self.task_manager._save_tasks()

                # Get cost from response
                cost = response.get('total_cost_usd', 0)
                cost_str = f" (${cost:.3f})" if cost > 0 else ""

                print(f"{GREEN}✓ Analysis saved to {output_file.name}{cost_str}{RESET}\n")

                # Ask if user wants to open in editor
                print("Open analysis in editor? [Y/n]: ", end='', flush=True)
                open_choice = input().strip().lower()

                if open_choice != 'n':
                    self.safe_launch_editor(output_file)

            except IOError as e:
                print(f"{YELLOW}⚠️ Failed to save analysis: {e}{RESET}")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

        except subprocess.TimeoutExpired:
            print(f"{YELLOW}⚠️ Analysis timed out (120s).{RESET}")
            print("Task may be too complex or network slow")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True
        except Exception as e:
            print(f"{YELLOW}⚠️ Analysis error: {e}{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        return True

    def execute_analysis_task(self):
        """Execute analysis plan with Claude Code (Shift+0)"""

        CYAN = '\033[96m'
        RESET = '\033[0m'
        GREEN = '\033[92m'
        YELLOW = '\033[93m'
        DIM = '\033[2m'

        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        task_id = current_task['id']
        task_text = current_task['text']

        # Check if analysis file exists
        analysis_file = Path.cwd() / f".jot.analysis.{task_id}.org"
        if not analysis_file.exists():
            print(f"\n{YELLOW}⚠️  No analysis found for this task{RESET}")
            print(f"\n{DIM}Tip: Press Shift+9 to analyze first, then Shift+0 to execute{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        # Read analysis file
        try:
            with open(analysis_file, 'r') as f:
                analysis_content = f.read()
        except IOError as e:
            print(f"\n{YELLOW}⚠️  Failed to read analysis file: {e}{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        # Generate session UUID from task ID (deterministic)
        session_uuid = str(uuid.uuid5(uuid.NAMESPACE_DNS, f"jot.task.{task_id}"))

        # Check for existing execution
        execution_history = current_task.get('execution_history', [])
        if execution_history:
            last_execution = execution_history[-1]
            print(f"\n{CYAN}Previous execution found:{RESET}")
            print(f"  Started: {last_execution.get('started_at', 'unknown')}")
            print(f"  Status: {last_execution.get('status', 'unknown')}")
            print("\nOptions:")
            print("  [Enter] - Resume existing session")
            print("  [n]     - Start new execution")
            print("  [q]     - Cancel")
            choice = input("\nChoice: ").strip().lower()

            if choice == 'q':
                return True
            elif choice == 'n':
                # Generate new session ID
                session_uuid = str(uuid.uuid4())

        # Build system prompt with analysis
        system_prompt = f"""You are implementing a task from the jot task manager.

TASK: {task_text}

ANALYSIS PLAN:
{analysis_content}

Follow the implementation plan above. Execute it step by step, making commits as appropriate.
When complete, mark the jot task as done if appropriate."""

        # Prepare Terminal command
        # Use AppleScript on macOS to open new Terminal window

        system = platform.system()

        print(f"\n{CYAN}🚀 Launching Claude Code...{RESET}")
        print(f"{DIM}Task ID: {task_id}{RESET}")
        print(f"{DIM}Session: {session_uuid[:8]}...{RESET}")
        print(f"{DIM}Analysis: {analysis_file.name}{RESET}\n")

        # Store execution metadata
        execution_record = {
            'session_id': session_uuid,
            'started_at': datetime.now().isoformat(),
            'status': 'in_progress',
            'analysis_file': str(analysis_file),
        }

        if 'execution_history' not in current_task:
            current_task['execution_history'] = []
        current_task['execution_history'].append(execution_record)

        # Mark as agent task
        if 'agent_task' not in current_task or not current_task['agent_task']:
            current_task['agent_task'] = True

        self.task_manager._save_tasks()

        try:
            if system == 'Darwin':  # macOS
                # Write system prompt to temp file for easier passing

                with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as tf:
                    tf.write(system_prompt)
                    temp_prompt_file = tf.name

                # AppleScript to open new Terminal with claude command
                applescript = f'''
                tell application "Terminal"
                    activate
                    do script "claude --session-id {session_uuid} --system-prompt \\"$(cat {temp_prompt_file})\\" && rm {temp_prompt_file}"
                end tell
                '''

                subprocess.run(['osascript', '-e', applescript], check=True)

                print(f"{GREEN}✓ Terminal launched{RESET}")
                print(f"\n{DIM}Claude Code is running in a new Terminal window{RESET}")
                print(f"{DIM}Session ID: {session_uuid}{RESET}")

            elif system == 'Linux':
                # Try common Linux terminal emulators
                terminals = ['gnome-terminal', 'konsole', 'xterm']
                launched = False

                for terminal in terminals:
                    try:
                        if terminal == 'gnome-terminal':
                            subprocess.Popen(
                                [
                                    terminal,
                                    '--',
                                    'bash',
                                    '-c',
                                    f'claude --session-id {session_uuid} --system-prompt "{system_prompt}"; exec bash',
                                ]
                            )
                        else:
                            subprocess.Popen(
                                [
                                    terminal,
                                    '-e',
                                    f'claude --session-id {session_uuid} --system-prompt "{system_prompt}"',
                                ]
                            )
                        launched = True
                        print(f"{GREEN}✓ Terminal launched ({terminal}){RESET}")
                        break
                    except FileNotFoundError:
                        continue

                if not launched:
                    print(f"{YELLOW}⚠️  Could not find terminal emulator{RESET}")
                    print(f"\n{DIM}Run this command manually:{RESET}")
                    print(
                        f'claude --session-id {session_uuid} --system-prompt "$(cat {analysis_file})"'
                    )

            else:
                # Windows or other
                print(f"{YELLOW}⚠️  Auto-launch not supported on {system}{RESET}")
                print(f"\n{DIM}Run this command manually:{RESET}")
                print(
                    f'claude --session-id {session_uuid} --system-prompt "$(cat {analysis_file})"'
                )

        except Exception as e:
            print(f"{YELLOW}⚠️  Failed to launch Terminal: {e}{RESET}")
            print(f"\n{DIM}Run this command manually:{RESET}")
            print(f'claude --session-id {session_uuid} --system-prompt "$(cat {analysis_file})"')

        print("\nPress Enter to continue...", end='', flush=True)
        input()
        return True

    def read_tasks_aloud(self):
        """Read all tasks in current category aloud using TTS (Shift+2)"""
        GREEN = '\033[92m'
        YELLOW = '\033[93m'
        CYAN = '\033[96m'
        RESET = '\033[0m'
        DIM = '\033[2m'

        # Check if TTS is available
        if not TTS_AVAILABLE:
            print(f"\n{YELLOW}⚠️  Text-to-speech not available{RESET}")
            print(f"{DIM}Install pyttsx3: pip install pyttsx3{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        # Get TTS configuration
        cat_config = CategoryConfig(project_dir=self.task_manager.project_dir)
        tts_config = cat_config.get_tts_config()

        if not tts_config.get('enabled', True):
            print(f"\n{YELLOW}⚠️  Text-to-speech is disabled in configuration{RESET}")
            print(f"{DIM}Edit .jot.config.json to enable{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        # Get tasks to read
        tasks = self.task_manager.tasks
        if not tasks:
            print(f"\n{YELLOW}⚠️  No tasks to read{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        # Initialize TTS engine
        try:
            engine = pyttsx3.init()

            # Apply configuration
            engine.setProperty('rate', tts_config.get('rate', 150))
            engine.setProperty('volume', tts_config.get('volume', 0.9))

            # Set voice if specified
            voice_name = tts_config.get('voice')
            if voice_name:
                voices = engine.getProperty('voices')
                for voice in voices:
                    if voice_name in voice.name:
                        engine.setProperty('voice', voice.id)
                        break

        except Exception as e:
            print(f"\n{YELLOW}⚠️  Failed to initialize TTS: {e}{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        # Read category name if set
        category_name = self.task_manager.category or "default"
        print(f"\n{CYAN}🔊 Reading {len(tasks)} tasks from {category_name} category...{RESET}\n")

        try:
            # Queue all tasks first, then speak
            for i, task in enumerate(tasks, 1):
                task_text = task['text']
                print(f"{DIM}{i}. {task_text}{RESET}")
                # Queue the speech
                engine.say(f"Task {i}. {task_text}")

            # Now speak all queued tasks
            engine.runAndWait()

            print(f"\n{GREEN}✓ Finished reading {len(tasks)} tasks{RESET}")

        except KeyboardInterrupt:
            print(f"\n{YELLOW}⚠️  Reading interrupted{RESET}")
            engine.stop()
        except Exception as e:
            print(f"\n{YELLOW}⚠️  Error during reading: {e}{RESET}")
        finally:
            try:
                engine.stop()
            except Exception:
                pass

        print("\nPress Enter to continue...", end='', flush=True)
        input()
        return True

    def switch_category(self):
        """Switch to a different category (local or global)"""
        # Get current project directory
        project_dir = (
            self.task_manager.project_dir if not self.task_manager.is_global else Path.cwd()
        )

        # Discover available categories
        cat_manager = CategoryManager(project_dir=project_dir)
        local_categories = cat_manager.discover_categories()
        global_categories = cat_manager.discover_global_categories()

        # Build category list with type indicators
        categories = []

        # Add "default" option (no category)
        categories.append(("default", None, False))

        # Add local categories
        for cat in local_categories:
            categories.append((cat, cat, False))

        # Add global categories
        for cat in global_categories:
            # Skip if already exists locally (avoid duplicates)
            if cat not in local_categories:
                categories.append((cat, cat, True))

        # Always show picker - even with just default, user can create new categories
        # if not categories:  # This should never happen as we always add default
        #     print("\n✗ No categories available")
        #     return True

        # Display available categories
        CYAN = '\033[96m'
        BOLD = '\033[1m'
        RESET = '\033[0m'

        # Get category config for colors
        cat_config = CategoryConfig(project_dir=project_dir)

        print(f"\n{CYAN}{BOLD}Switch to category:{RESET}")
        for i, (display_name, cat_name, is_global) in enumerate(categories, 1):
            if display_name == "default":
                cat_color = cat_config.get_color('default')
                print(f"  {i}. {cat_color}default (no category){RESET}")
            else:
                cat_color = cat_config.get_color(cat_name, for_global=is_global)
                if is_global:
                    print(f"  {i}. {cat_color}{cat_name} [global]{RESET}")
                else:
                    print(f"  {i}. {cat_color}{cat_name} [local]{RESET}")

        print("\nEnter number or name (ESC to cancel): ", end='', flush=True)

        # Restore terminal to normal mode and flush any pending input
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        termios.tcflush(fd, termios.TCIFLUSH)  # Flush input buffer

        # Get user input
        try:
            user_input = input().strip()

            # Check if ESC or empty
            if not user_input or user_input == '\x1b':
                print("✗ Cancelled")
                return True

            # Try as number first
            selected_category = None
            selected_is_global = False

            try:
                choice_index = int(user_input) - 1
                if 0 <= choice_index < len(categories):
                    display_name, cat_name, is_global = categories[choice_index]
                    selected_category = cat_name
                    selected_is_global = is_global
                else:
                    print("✗ Invalid number")
                    return True
            except ValueError:
                # Try as category name
                found = False
                for display_name, cat_name, is_global in categories:
                    if cat_name == user_input or display_name == user_input:
                        selected_category = cat_name
                        selected_is_global = is_global
                        found = True
                        break

                if not found:
                    # Category doesn't exist - offer to create it
                    YELLOW = '\033[93m'
                    RESET = '\033[0m'
                    print(f"\n{YELLOW}Category '{user_input}' doesn't exist yet.{RESET}")
                    print("Create as:")
                    print("  1. Local (this project only)")
                    print("  2. Global (available in all projects)")
                    print("\nChoice (1/2, ESC to cancel): ", end='', flush=True)

                    try:
                        choice = input().strip()
                        if not choice or choice == '\x1b':
                            print("✗ Cancelled")
                            return True

                        if choice == '1' or choice.lower() == 'local':
                            # Check local category limit
                            can_create, error_msg = cat_manager.can_create_category(user_input)
                            if not can_create:
                                print(f"✗ {error_msg}")
                                return True

                            # Show warning if approaching limit
                            warning_msg = cat_manager.get_warning_message(user_input)
                            if warning_msg:
                                print(warning_msg)

                            selected_category = user_input
                            selected_is_global = False
                        elif choice == '2' or choice.lower() == 'global':
                            selected_category = user_input
                            selected_is_global = True
                        else:
                            print("✗ Invalid choice")
                            return True
                    except KeyboardInterrupt:
                        print("\n✗ Cancelled")
                        return True

            # Return the selected category info to trigger reload
            # We'll need to modify the main loop to handle this
            return ('switch_category', selected_category, selected_is_global)

        except KeyboardInterrupt:
            print("\n✗ Cancelled")
            return True

    def switch_project(self):
        """Switch to a different registered project"""
        # Get all registered projects
        all_projects = self.registry.list_projects()

        if not all_projects:
            print("\n✗ No projects registered")
            print("Run 'jott --refresh' to discover projects or '--register' to add one manually")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        # Get current project path to exclude it from the list
        current_project_path = str(self.task_manager.project_dir)

        # Build list of projects excluding current one
        available_projects = {}
        for name, path in all_projects.items():
            if path != current_project_path:
                available_projects[name] = path

        if not available_projects:
            print("\n✗ No other projects available")
            print("You are in the only registered project")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        # Display available projects
        CYAN = '\033[96m'
        BOLD = '\033[1m'
        RESET = '\033[0m'
        DIM = '\033[2m'

        print(f"\n{CYAN}{BOLD}Switch to project:{RESET}")
        project_list = sorted(available_projects.keys())
        for i, name in enumerate(project_list, 1):
            path = available_projects[name]
            print(f"  {i}. {BOLD}{name}{RESET} {DIM}→ {path}{RESET}")

        print("\nEnter number or name (ESC to cancel): ", end='', flush=True)

        # Restore terminal to normal mode and flush any pending input
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        termios.tcflush(fd, termios.TCIFLUSH)  # Flush input buffer

        # Get user input
        try:
            user_input = input().strip()

            # Check if ESC or empty
            if not user_input or user_input == '\x1b':
                print("✗ Cancelled")
                return True

            # Try as number first
            selected_project_name = None
            selected_project_path = None

            try:
                choice_index = int(user_input) - 1
                if 0 <= choice_index < len(project_list):
                    selected_project_name = project_list[choice_index]
                    selected_project_path = available_projects[selected_project_name]
                else:
                    print("✗ Invalid number")
                    return True
            except ValueError:
                # Try as project name
                if user_input in available_projects:
                    selected_project_name = user_input
                    selected_project_path = available_projects[user_input]
                else:
                    print(f"✗ Project '{user_input}' not found")
                    return True

            # Return the selected project info to trigger reload
            return ('switch_project', selected_project_name, selected_project_path)

        except KeyboardInterrupt:
            print("\n✗ Cancelled")
            return True

    def register_current_project(self):
        """Register the current project in the global project registry"""
        CYAN = '\033[96m'
        BOLD = '\033[1m'
        RESET = '\033[0m'
        DIM = '\033[2m'
        YELLOW = '\033[93m'

        # Get current project directory
        current_dir = self.task_manager.project_dir

        # Check if .jot.json exists
        jot_file = current_dir / '.jot.json'
        if not jot_file.exists():
            print(f"\n✗ No .jot.json file found in {current_dir}")
            print("Cannot register a directory without a .jot.json file")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        # Suggest project name based on directory name
        suggested_name = current_dir.name

        # Check if current directory is already registered
        all_projects = self.registry.list_projects()
        current_path_str = str(current_dir)
        already_registered_as = None
        for name, path in all_projects.items():
            if path == current_path_str:
                already_registered_as = name
                break

        print(f"\n{CYAN}{BOLD}Register Current Project{RESET}")
        print(f"Directory: {DIM}{current_dir}{RESET}")

        if already_registered_as:
            print(f"{YELLOW}⚠ Already registered as: {BOLD}{already_registered_as}{RESET}")
            print(f"\nEnter new name to re-register or press Enter to cancel: ", end='', flush=True)
        else:
            print(f"\nProject name [{suggested_name}]: ", end='', flush=True)

        # Restore terminal to normal mode and flush any pending input
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        termios.tcflush(fd, termios.TCIFLUSH)  # Flush input buffer

        # Get user input
        try:
            project_name = input().strip()

            # If empty and already registered, cancel
            if not project_name and already_registered_as:
                print("✗ Cancelled")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            # If empty and not already registered, use suggested name
            if not project_name:
                project_name = suggested_name

            # Check if project name already exists (pointing to different directory)
            if project_name in all_projects and all_projects[project_name] != current_path_str:
                existing_path = all_projects[project_name]
                print(f"{YELLOW}⚠ Project '{project_name}' already exists → {existing_path}{RESET}")
                print(f"Overwrite? (y/N): ", end='', flush=True)
                overwrite = input().strip().lower()
                if overwrite != 'y':
                    print("✗ Cancelled")
                    print("\nPress Enter to continue...", end='', flush=True)
                    input()
                    return True

            # Register the project
            self.registry.register_project(project_name, current_path_str)
            print(
                f"\n✓ Registered project '{BOLD}{project_name}{RESET}' → {DIM}{current_dir}{RESET}"
            )
            print(f"\nYou can now access it with: {CYAN}jott {project_name}{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        except KeyboardInterrupt:
            print("\n✗ Cancelled")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

    def collect_all_category_tasks(self, project_dir, show_archived=False):
        """Collect tasks from all categories (default + local + global)

        Args:
            project_dir: Project directory path
            show_archived: Whether to include archived tasks

        Returns:
            list: List of tuples (category_name, is_global, tasks, archived_tasks)
        """
        all_categories = []
        cat_manager = CategoryManager(project_dir=project_dir)

        # Default category
        try:
            tm_default = TaskManager(directory=project_dir)
            tasks = tm_default.tasks if not show_archived else tm_default.tasks
            archived = tm_default.archived if show_archived else []
            if tasks or archived:  # Only include if has tasks
                all_categories.append(('default', False, tasks, archived))
        except Exception:
            pass  # Skip if default doesn't exist

        # Local categories
        for cat in cat_manager.discover_categories():
            try:
                tm = TaskManager(directory=project_dir, category=cat)
                tasks = tm.tasks if not show_archived else tm.tasks
                archived = tm.archived if show_archived else []
                if tasks or archived:  # Only include if has tasks
                    all_categories.append((cat, False, tasks, archived))
            except Exception:
                pass  # Skip problematic categories

        # Global categories
        for cat in cat_manager.discover_global_categories():
            try:
                tm = TaskManager(category=cat, is_global=True)
                tasks = tm.tasks if not show_archived else tm.tasks
                archived = tm.archived if show_archived else []
                if tasks or archived:  # Only include if has tasks
                    all_categories.append((cat, True, tasks, archived))
            except Exception:
                pass  # Skip problematic categories

        return all_categories

    def toggle_all_categories_view(self, current_mode):
        """Toggle between normal view and all-categories view

        Args:
            current_mode: Current mode to return indication

        Returns:
            tuple: (should_toggle, new_mode)
        """
        if current_mode == MODE_ALL_CATEGORIES:
            # Exit all-categories view, return to quick-add
            return (True, MODE_QUICK_ADD)
        else:
            # Enter all-categories view
            return (True, MODE_ALL_CATEGORIES)

    def refresh(self):
        """Refresh task list from file"""
        self.task_manager.refresh()
        print("\n✓ Refreshed task list")
        return True

    def help(self):
        """Show help message"""
        print("\nCommands:")
        print("  a - Add a task")
        print("  c - Mark task as current")
        print("  d - Delete task by ID")
        print("  D - Delete current task")
        print("  e - Edit task by ID")
        print("  E - Edit current task")
        print("  M - Move current task to different project")
        print("  r - Refresh task list")
        print("  h - Show this help")
        print("  q - Quit")
        print("\nNavigation:")
        print("  ↑/Ctrl+p - Previous task")
        print("  ↓/Ctrl+n - Next task")
        print("  Shift+↑ - Move current task up")
        print("  Shift+↓ - Move current task down")
        print("\nQuick-Add Mode Shortcuts:")
        print("  ? - Toggle shortcuts display (press '?' to show/hide categorized shortcuts)")
        print("  Shift+F - Toggle inline notes display")
        print("  Shift+N - Edit task notes (📝)")
        print("  Shift+J - Mark current task as agent task (Claude Code working on it)")
        print("  Shift+C - Switch to different category")
        print("  Shift+Z - Switch to different project")
        print("  Shift+R - Register current project in global registry")
        print("  Shift+T - Transfer current task to different category")
        print("  Shift+M - Move current task to different project")
        print("  Shift+Q - Quit")
        print("\nNote: Press '?' in Quick-Add mode to see all shortcuts organized by category")
        print("\nCommand Mode (press ESC):")
        print("  r - Refresh task list")
        print("\nFor full CLI documentation, run: jott --help")
        return True

    def bulk_actions_menu(self, selected_task_ids):
        """Show bulk actions menu and return selected action

        Args:
            selected_task_ids: Set of task IDs to operate on

        Returns:
            str: Action to perform ('priority', 'status', 'delete', 'archive', 'cancel', None)
        """
        if not selected_task_ids:
            print("\n✗ No tasks selected")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return None

        CYAN = '\033[96m'
        BOLD = '\033[1m'
        RESET = '\033[0m'

        print(f"\n{CYAN}{BOLD}Bulk Actions{RESET} ({len(selected_task_ids)} tasks selected)")
        print("-" * 50)
        print("  1. Set priority for all selected")
        print("  2. Set status for all selected")
        print("  3. Delete all selected")
        print("  4. Archive all selected")
        print("  5. Cancel")
        print("\nChoice: ", end='', flush=True)

        # Restore terminal

        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        termios.tcflush(fd, termios.TCIFLUSH)

        try:
            choice = input().strip()

            if choice == '1':
                return 'priority'
            elif choice == '2':
                return 'status'
            elif choice == '3':
                return 'delete'
            elif choice == '4':
                return 'archive'
            else:
                return 'cancel'

        except (KeyboardInterrupt, EOFError):
            return 'cancel'

    def bulk_set_priority(self, task_ids):
        """Set priority for multiple tasks

        Args:
            task_ids: Set of task IDs to update

        Returns:
            bool: True if operation completed
        """
        BOLD = '\033[1m'
        RESET = '\033[0m'
        YELLOW = '\033[93m'
        DIM = '\033[2m'

        # Priority colors and symbols
        PRIORITY_COLORS = {
            'none': DIM,
            'low': '\033[94m',  # BLUE
            'medium': YELLOW,
            'high': '\033[91m',  # RED
        }
        PRIORITY_SYMBOLS = {
            'none': '○',
            'low': '◔',
            'medium': '◑',
            'high': '●',
        }

        print(f"\n{BOLD}Set priority for {len(task_ids)} tasks:{RESET}")
        priorities = ['none', 'low', 'medium', 'high']
        for i, priority in enumerate(priorities, 1):
            color = PRIORITY_COLORS[priority]
            symbol = PRIORITY_SYMBOLS[priority]
            print(f"  {i}. {color}{symbol} {priority}{RESET}")

        print(f"\n  {BOLD}ESC{RESET}. Cancel\n")
        print("Choice: ", end='', flush=True)

        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        termios.tcflush(fd, termios.TCIFLUSH)

        try:
            user_input = input().strip()

            if not user_input or user_input == '\x1b':
                print("✗ Cancelled")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            choice = int(user_input)
            if 1 <= choice <= 4:
                selected_priority = priorities[choice - 1]
                count = 0
                for task_id in task_ids:
                    if self.task_manager.set_task_priority(task_id, selected_priority):
                        count += 1

                priority_color = PRIORITY_COLORS[selected_priority]
                priority_symbol = PRIORITY_SYMBOLS[selected_priority]
                print(
                    f"✓ Set priority to {priority_color}{priority_symbol} {selected_priority}{RESET} for {count} tasks"
                )
                print("\nPress Enter to continue...", end='', flush=True)
                input()
            else:
                print("✗ Invalid choice")
                print("\nPress Enter to continue...", end='', flush=True)
                input()

        except (ValueError, KeyboardInterrupt, EOFError):
            print("\n✗ Cancelled")
            print("\nPress Enter to continue...", end='', flush=True)
            input()

        return True

    def bulk_set_status(self, task_ids):
        """Set status for multiple tasks

        Args:
            task_ids: Set of task IDs to update

        Returns:
            bool: True if operation completed
        """
        CYAN = '\033[96m'
        BOLD = '\033[1m'
        RESET = '\033[0m'
        GREEN = '\033[92m'
        DIM = '\033[2m'

        # Status colors and symbols
        STATUS_COLORS = {
            'todo': DIM,
            'in-progress': CYAN,
            'blocked': '\033[91m',  # RED
            'done': GREEN,
        }
        STATUS_SYMBOLS = {
            'todo': '☐',
            'in-progress': '▶',
            'blocked': '⚠',
            'done': '✓',
        }

        print(f"\n{BOLD}Set status for {len(task_ids)} tasks:{RESET}")
        statuses = ['todo', 'in-progress', 'blocked', 'done']
        for i, status in enumerate(statuses, 1):
            color = STATUS_COLORS[status]
            symbol = STATUS_SYMBOLS[status]
            print(f"  {i}. {color}{symbol} {status}{RESET}")

        print(f"\n  {BOLD}ESC{RESET}. Cancel\n")
        print("Choice: ", end='', flush=True)

        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        termios.tcflush(fd, termios.TCIFLUSH)

        try:
            user_input = input().strip()

            if not user_input or user_input == '\x1b':
                print("✗ Cancelled")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            choice = int(user_input)
            if 1 <= choice <= 4:
                selected_status = statuses[choice - 1]
                count = 0
                for task_id in task_ids:
                    if self.task_manager.set_task_status(task_id, selected_status):
                        count += 1

                status_color = STATUS_COLORS[selected_status]
                status_symbol = STATUS_SYMBOLS[selected_status]
                print(
                    f"✓ Set status to {status_color}{status_symbol} {selected_status}{RESET} for {count} tasks"
                )
                print("\nPress Enter to continue...", end='', flush=True)
                input()
            else:
                print("✗ Invalid choice")
                print("\nPress Enter to continue...", end='', flush=True)
                input()

        except (ValueError, KeyboardInterrupt, EOFError):
            print("\n✗ Cancelled")
            print("\nPress Enter to continue...", end='', flush=True)
            input()

        return True

    def bulk_delete(self, task_ids):
        """Delete multiple tasks

        Args:
            task_ids: Set of task IDs to delete

        Returns:
            bool: True if operation completed
        """
        BOLD = '\033[1m'
        RESET = '\033[0m'
        YELLOW = '\033[93m'

        print(f"\n{YELLOW}{BOLD}⚠  WARNING{RESET}")
        print(f"About to delete {len(task_ids)} tasks. This cannot be undone.\n")
        print("Confirm deletion? (y/N): ", end='', flush=True)

        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        termios.tcflush(fd, termios.TCIFLUSH)

        try:
            confirmation = input().strip().lower()

            if confirmation == 'y':
                count = 0
                for task_id in task_ids:
                    if self.task_manager.delete_task_permanently(task_id):
                        count += 1

                print(f"✓ Deleted {count} tasks")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
            else:
                print("✗ Deletion cancelled")
                print("\nPress Enter to continue...", end='', flush=True)
                input()

        except (KeyboardInterrupt, EOFError):
            print("\n✗ Deletion cancelled")
            print("\nPress Enter to continue...", end='', flush=True)
            input()

        return True

    def bulk_archive(self, task_ids):
        """Archive multiple tasks

        Args:
            task_ids: Set of task IDs to archive

        Returns:
            bool: True if operation completed
        """
        BOLD = '\033[1m'
        RESET = '\033[0m'

        print(f"\n{BOLD}Archive {len(task_ids)} tasks?{RESET} (y/N): ", end='', flush=True)

        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        termios.tcflush(fd, termios.TCIFLUSH)

        try:
            confirmation = input().strip().lower()

            if confirmation == 'y':
                count = 0
                for task_id in task_ids:
                    if self.task_manager.archive_task(task_id):
                        count += 1

                print(f"✓ Archived {count} tasks")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
            else:
                print("✗ Archive cancelled")
                print("\nPress Enter to continue...", end='', flush=True)
                input()

        except (KeyboardInterrupt, EOFError):
            print("\n✗ Archive cancelled")
            print("\nPress Enter to continue...", end='', flush=True)
            input()

        return True

    def handle(self, command):
        """Handle a command"""
        # Check for exact match first (for case-sensitive commands like 'D')
        handler = self.commands.get(command)
        if not handler:
            # Fall back to lowercase
            handler = self.commands.get(command.lower())

        if handler:
            return handler()
        else:
            print(f"\nUnknown command: {command}. Press 'h' for help.")
            return True


def display_all_projects(registry, show_categories=False):
    """Display all projects with their tasks grouped by project"""
    # ANSI color codes
    CYAN = '\033[96m'
    RESET = '\033[0m'
    BOLD = '\033[1m'
    GREEN = '\033[92m'
    DIM = '\033[2m'

    projects = registry.list_projects()

    if not projects:
        print("\nNo registered projects. Run jot to auto-discover projects in ~/projects/")
        return

    print("\n" + "=" * 60)
    if show_categories:
        print(f"{BOLD}ALL PROJECTS OVERVIEW (with categories){RESET}")
    else:
        print(f"{BOLD}ALL PROJECTS OVERVIEW{RESET}")
    print("=" * 60)

    for project_name in sorted(projects.keys()):
        project_path = projects[project_name]

        # Load tasks for this project
        try:
            if show_categories:
                # Display with category breakdown
                cat_manager = CategoryManager(project_dir=project_path)
                local_categories = cat_manager.discover_categories()

                # Load default category
                tm_default = TaskManager(directory=project_path)
                default_count = len(tm_default.tasks)
                archived_count = len(tm_default.archived)

                # Count total tasks across all categories
                total_tasks = default_count
                category_counts = {}

                for cat in local_categories:
                    tm_cat = TaskManager(directory=project_path, category=cat)
                    cat_task_count = len(tm_cat.tasks)
                    total_tasks += cat_task_count
                    category_counts[cat] = cat_task_count

                # Project header
                print(
                    f"\n📁 {BOLD}{project_name}{RESET} ({total_tasks} tasks total, {archived_count} archived)"
                )
                print(f"{DIM}   {project_path}{RESET}")

                # Display default category
                if default_count > 0:
                    print(f"\n  {DIM}default{RESET} ({default_count} tasks)")
                    for i, task in enumerate(tm_default.tasks[:5]):
                        status = "✓" if task.get('done', False) else " "
                        is_current = task.get('current', False)
                        task_text = task['text']
                        if len(task_text) > 50:
                            task_text = task_text[:47] + "..."

                        if is_current:
                            print(
                                f"    {CYAN}{BOLD}→ [{status}] {task['id']}. ✨ {task_text}{RESET}"
                            )
                        else:
                            print(f"      [{status}] {task['id']}. {task_text}")

                    if default_count > 5:
                        print(f"    {DIM}... and {default_count - 5} more{RESET}")

                # Display each category
                for cat in sorted(local_categories):
                    tm_cat = TaskManager(directory=project_path, category=cat)
                    cat_count = len(tm_cat.tasks)

                    print(f"\n  {CYAN}{BOLD}{cat}{RESET} ({cat_count} tasks)")

                    for i, task in enumerate(tm_cat.tasks[:5]):
                        status = "✓" if task.get('done', False) else " "
                        is_current = task.get('current', False)
                        task_text = task['text']
                        if len(task_text) > 50:
                            task_text = task_text[:47] + "..."

                        if is_current:
                            print(
                                f"    {CYAN}{BOLD}→ [{status}] {task['id']}. ✨ {task_text}{RESET}"
                            )
                        else:
                            print(f"      [{status}] {task['id']}. {task_text}")

                    if cat_count > 5:
                        print(f"    {DIM}... and {cat_count - 5} more{RESET}")

                if total_tasks == 0:
                    print(f"   {DIM}No active tasks{RESET}")

            else:
                # Original display without categories
                tm = TaskManager(directory=project_path)
                task_count = len(tm.tasks)
                archived_count = len(tm.archived)

                # Project header
                print(
                    f"\n📁 {BOLD}{project_name}{RESET} ({task_count} tasks, {archived_count} archived)"
                )
                print(f"{DIM}   {project_path}{RESET}")

                if not tm.tasks:
                    print(f"   {DIM}No active tasks{RESET}")
                else:
                    # Display tasks (max 10 per project)
                    for i, task in enumerate(tm.tasks[:10]):
                        status = "✓" if task.get('done', False) else " "
                        is_current = task.get('current', False)
                        is_break_task = 'break' in task['text'].lower()

                        # Truncate long task text
                        task_text = task['text']
                        if len(task_text) > 60:
                            task_text = task_text[:57] + "..."

                        if is_current:
                            if is_break_task:
                                print(
                                    f"  {GREEN}{BOLD}→ [{status}] {task['id']}. 🌿 {task_text}{RESET}"
                                )
                            else:
                                print(
                                    f"  {CYAN}{BOLD}→ [{status}] {task['id']}. ✨ {task_text}{RESET}"
                                )
                        else:
                            print(f"    [{status}] {task['id']}. {task_text}")

                    # Show if there are more tasks
                    if len(tm.tasks) > 10:
                        remaining = len(tm.tasks) - 10
                        print(f"   {DIM}... and {remaining} more tasks{RESET}")

        except Exception as e:
            print(f"   {DIM}Error loading project: {e}{RESET}")

    print("\n" + "=" * 60)
    print(f"{DIM}Use 'jot <project-name>' to work on a specific project{RESET}")
    if show_categories:
        print(f"{DIM}Use 'jot --all-projects' to hide categories{RESET}")
    else:
        print(f"{DIM}Use 'jot --all-projects --show-categories' to see category breakdown{RESET}")
    print("=" * 60 + "\n")


def display_category_stats(project_dir):
    """Display statistics and analytics for all categories"""
    # ANSI color codes
    CYAN = '\033[96m'
    RESET = '\033[0m'
    BOLD = '\033[1m'
    YELLOW = '\033[93m'
    DIM = '\033[2m'
    MAGENTA = '\033[95m'

    print("\n" + "=" * 60)
    print(f"{BOLD}CATEGORY STATISTICS{RESET}")
    print("=" * 60)

    # Get all categories
    cat_manager = CategoryManager(project_dir=project_dir)
    local_categories = cat_manager.discover_categories()
    global_categories = cat_manager.discover_global_categories()

    # Collect stats
    category_stats = []

    # Default category
    tm_default = TaskManager(directory=project_dir)
    category_stats.append(
        {
            'name': 'default',
            'type': 'local',
            'tasks': len(tm_default.tasks),
            'done': sum(1 for t in tm_default.tasks if t.get('done', False)),
            'archived': len(tm_default.archived),
        }
    )

    # Local categories
    for cat in local_categories:
        tm_cat = TaskManager(directory=project_dir, category=cat)
        category_stats.append(
            {
                'name': cat,
                'type': 'local',
                'tasks': len(tm_cat.tasks),
                'done': sum(1 for t in tm_cat.tasks if t.get('done', False)),
                'archived': len(tm_cat.archived),
            }
        )

    # Global categories
    for cat in global_categories:
        # Skip if already exists locally
        if cat not in local_categories and cat != 'default':
            tm_cat = TaskManager(category=cat, is_global=True)
            category_stats.append(
                {
                    'name': cat,
                    'type': 'global',
                    'tasks': len(tm_cat.tasks),
                    'done': sum(1 for t in tm_cat.tasks if t.get('done', False)),
                    'archived': len(tm_cat.archived),
                }
            )

    # Display stats
    print(f"\n{'Category':<20} {'Type':<10} {'Active':<8} {'Done':<8} {'Archived':<10}")
    print("-" * 60)

    for stat in sorted(category_stats, key=lambda x: x['name']):
        name = stat['name']
        cat_type = stat['type']
        tasks = stat['tasks']
        done = stat['done']
        archived = stat['archived']

        # Color code by type
        if cat_type == 'global':
            name_display = f"{MAGENTA}{name}{RESET}"
            type_display = f"{MAGENTA}global{RESET}"
        elif name == 'default':
            name_display = f"{DIM}{name}{RESET}"
            type_display = f"{DIM}local{RESET}"
        else:
            name_display = f"{CYAN}{name}{RESET}"
            type_display = f"{CYAN}local{RESET}"

        # Calculate completion percentage
        if tasks > 0:
            done_pct = (done / tasks) * 100
            done_display = f"{done} ({done_pct:.0f}%)"
        else:
            done_display = f"{done}"

        print(f"{name_display:<29} {type_display:<19} {tasks:<8} {done_display:<8} {archived:<10}")

    # Summary
    total_tasks = sum(s['tasks'] for s in category_stats)
    total_done = sum(s['done'] for s in category_stats)
    total_archived = sum(s['archived'] for s in category_stats)
    total_categories = len(category_stats)

    print("\n" + "-" * 60)
    print(f"{BOLD}SUMMARY{RESET}")
    print(f"  Total categories: {total_categories}")
    print(f"  Total active tasks: {total_tasks}")
    print(f"  Total completed: {total_done}")
    print(f"  Total archived: {total_archived}")

    # Category limit warning
    local_count = len(
        [s for s in category_stats if s['type'] == 'local' and s['name'] != 'default']
    )
    if local_count >= 10:
        print(
            f"\n{YELLOW}⚠  Local categories: {local_count}/{CategoryManager.MAX_CATEGORIES}{RESET}"
        )

    print("\n" + "=" * 60 + "\n")


def display_archive(project_dir, filter_category=None):
    """Display archived tasks, optionally filtered by category"""
    # ANSI color codes
    CYAN = '\033[96m'
    RESET = '\033[0m'
    BOLD = '\033[1m'
    YELLOW = '\033[93m'
    DIM = '\033[2m'

    print("\n" + "=" * 60)
    if filter_category:
        print(f"{BOLD}ARCHIVED TASKS - Category: {CYAN}{filter_category}{RESET}")
    else:
        print(f"{BOLD}ARCHIVED TASKS - All Categories{RESET}")
    print("=" * 60)

    # Get all categories
    cat_manager = CategoryManager(project_dir=project_dir)
    local_categories = cat_manager.discover_categories()

    # Collect archived tasks
    all_archived = []

    # Check default category
    if not filter_category or filter_category == 'default':
        tm_default = TaskManager(directory=project_dir)
        if tm_default.archived:
            for task in tm_default.archived:
                all_archived.append(('default', task))

    # Check each category
    for cat in local_categories:
        if not filter_category or filter_category == cat:
            tm_cat = TaskManager(directory=project_dir, category=cat)
            if tm_cat.archived:
                for task in tm_cat.archived:
                    all_archived.append((cat, task))

    if not all_archived:
        if filter_category:
            print(f"\n{DIM}No archived tasks in category '{filter_category}'{RESET}")
        else:
            print(f"\n{DIM}No archived tasks{RESET}")
    else:
        # Display archived tasks grouped by category
        current_category = None
        for cat_name, task in all_archived:
            if cat_name != current_category:
                current_category = cat_name
                if cat_name == 'default':
                    print(f"\n{DIM}default{RESET}")
                else:
                    print(f"\n{CYAN}{BOLD}{cat_name}{RESET}")

            status = "✓" if task.get('done', False) else " "
            task_text = task.get('text', '')
            task_id = task.get('id', '?')

            # Truncate long task text
            if len(task_text) > 70:
                task_text = task_text[:67] + "..."

            print(f"  [{status}] {task_id}. {task_text}")

        print(f"\n{YELLOW}Total archived: {len(all_archived)}{RESET}")

    print("\n" + "=" * 60)
    if not filter_category:
        print(f"{DIM}Use 'jot --archive <category>' to filter by category{RESET}")
    else:
        print(f"{DIM}Use 'jot --archive' to see all archived tasks{RESET}")
    print("=" * 60 + "\n")


def format_inline_notes(notes, max_lines=3, max_width=70):
    """Format notes for inline display below task.

    Args:
        notes: The notes text to format
        max_lines: Maximum number of lines to show before truncating
        max_width: Maximum width of each line before truncating

    Returns:
        List of formatted note lines with indentation and box characters
    """
    if not notes or not notes.strip():
        return []

    DIM = '\033[2m'
    RESET = '\033[0m'

    lines = notes.strip().split('\n')
    formatted = []

    # Show up to max_lines
    displayed_lines = lines[:max_lines]
    remaining = len(lines) - len(displayed_lines)

    for i, line in enumerate(displayed_lines):
        # Truncate long lines
        if len(line) > max_width:
            line = line[: max_width - 3] + "..."

        # First line uses ┌, middle lines use │, last uses └
        if i == 0 and len(displayed_lines) == 1:
            # Single line
            formatted.append(f"{DIM}      └─ {line}{RESET}")
        elif i == 0:
            # First of multiple
            formatted.append(f"{DIM}      ├─ {line}{RESET}")
        elif i == len(displayed_lines) - 1 and remaining == 0:
            # Last line, no truncation
            formatted.append(f"{DIM}      └─ {line}{RESET}")
        else:
            # Middle lines
            formatted.append(f"{DIM}      │  {line}{RESET}")

    # Add truncation indicator if needed
    if remaining > 0:
        formatted.append(
            f"{DIM}      └─ ... ({remaining} more line{'s' if remaining != 1 else ''}){RESET}"
        )

    return formatted


def format_category_badges(category_manager, cat_config, current_category, is_global_current):
    """Format category badges for display in header.

    Shows all categories that have tasks, with colored backgrounds and black text.
    Current category is highlighted with brighter/bold styling.

    Args:
        category_manager: CategoryManager instance
        cat_config: CategoryConfig instance
        current_category: Name of currently active category (or None)
        is_global_current: Whether current category is global

    Returns:
        str: Formatted badge string, or empty string if no categories
    """
    # Discover all categories
    local_categories = category_manager.discover_categories()
    global_categories = category_manager.discover_global_categories()

    # Filter to only categories with tasks
    categories_with_tasks = []

    for cat in local_categories:
        cat_file = category_manager.project_dir / f'.jot.{cat}.json'
        if cat_file.exists():
            try:
                with open(cat_file) as f:
                    data = json.load(f)
                    if data.get('tasks'):  # Has at least one task
                        categories_with_tasks.append(('local', cat))
            except Exception:
                pass

    for cat in global_categories:
        cat_file = Path.home() / '.jot-categories' / f'{cat}.json'
        if cat_file.exists():
            try:
                with open(cat_file) as f:
                    data = json.load(f)
                    if data.get('tasks'):  # Has at least one task
                        categories_with_tasks.append(('global', cat))
            except Exception:
                pass

    if not categories_with_tasks:
        return ""

    # ANSI color codes for background + black text
    BLACK_TEXT = '\033[30m'
    BOLD = '\033[1m'
    RESET = '\033[0m'

    # Background color codes (standard 8 colors + 256-color palette)
    BG_COLORS = {
        'red': '\033[41m',  # Bright red bg
        'green': '\033[42m',  # Bright green bg
        'yellow': '\033[43m',  # Bright yellow bg
        'blue': '\033[44m',  # Bright blue bg
        'magenta': '\033[45m',  # Bright magenta bg
        'cyan': '\033[46m',  # Bright cyan bg
        'white': '\033[47m',  # White bg
        'orange': '\033[48;5;208m',  # Orange bg (256-color)
        'purple': '\033[48;5;141m',  # Purple bg (256-color)
        'pink': '\033[48;5;213m',  # Pink bg (256-color)
        'teal': '\033[48;5;44m',  # Teal bg (256-color)
        'lime': '\033[48;5;154m',  # Lime bg (256-color)
    }

    badges = []
    for cat_type, cat_name in categories_with_tasks:
        # Get color for this category
        is_global = cat_type == 'global'
        color_name = cat_config.get_color(cat_name, for_global=is_global)
        bg_color = BG_COLORS.get(color_name, BG_COLORS['cyan'])

        # Check if this is the current category
        is_current = cat_name == current_category and is_global == is_global_current

        # Format badge
        if is_global:
            label = f" global:{cat_name} "
        else:
            label = f" {cat_name} "

        if is_current:
            # Current category: BOLD + bright background
            badge = f"{bg_color}{BLACK_TEXT}{BOLD}{label}{RESET}"
        else:
            # Regular category: just background + black text
            badge = f"{bg_color}{BLACK_TEXT}{label}{RESET}"

        badges.append(badge)

    return ' '.join(badges)


def display_tasks(
    tasks,
    mode=MODE_QUICK_ADD,
    input_buffer="",
    project_name=None,
    category=None,
    is_global=False,
    show_archived=False,
    archived_tasks=None,
    selected_tasks=None,
    search_buffer="",
    archived_task_ids=None,
    include_archived_in_search=True,
    show_shortcuts=False,
    show_notes_inline=False,
):
    """Display current task list with mode indicator

    Args:
        tasks: Active tasks to display
        mode: Current mode (quick-add, command, or multiselect)
        input_buffer: Current input text
        project_name: Name of project
        category: Category name
        is_global: Whether category is global
        show_archived: Whether to show archived tasks below active tasks
        archived_tasks: List of archived tasks (only used if show_archived=True)
        selected_tasks: Set of task IDs that are selected (for multi-select mode)
        search_buffer: Current fuzzy search query
        archived_task_ids: Set of task IDs that are archived (for fuzzy search)
        include_archived_in_search: Whether archived tasks are included in search
    """
    # ANSI color codes
    CYAN = '\033[96m'
    RESET = '\033[0m'
    BOLD = '\033[1m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    DIM = '\033[2m'

    # Import Path at the top to avoid UnboundLocalError

    # Get category color
    cat_config = CategoryConfig()
    if category:
        cat_color = cat_config.get_color(category, for_global=is_global)
    else:
        cat_color = CYAN

    # ASCII art header
    print(f"\n{CYAN}{BOLD}")
    print("       ██╗ ██████╗ ████████╗")
    print("       ██║██╔═══██╗╚══██╔══╝")
    print("       ██║██║   ██║   ██║")
    print("  ██   ██║██║   ██║   ██║")
    print("  ╚█████╔╝╚██████╔╝   ██║")
    print("   ╚════╝  ╚═════╝    ╚═╝")
    print(f"{RESET}")

    # Find current task
    current_task_text = None
    for task in tasks:
        if task.get('current', False):
            current_task_text = task.get('text', '')
            # Truncate if too long
            if len(current_task_text) > 40:
                current_task_text = current_task_text[:37] + "..."
            break

    # Display project name with category
    if project_name:
        print(f"  {YELLOW}{BOLD}{project_name}{RESET} {DIM}({Path.cwd().name}){RESET}", end='')
    else:
        print(f"  {YELLOW}{BOLD}{Path.cwd().name}{RESET}", end='')

    # Display category if present with configured color
    if category:
        if is_global:
            print(f" {cat_color}{BOLD}[global:{category}]{RESET}", end='')
        else:
            print(f" {cat_color}{BOLD}[{category}]{RESET}", end='')

    # Display current task text in header if present
    if current_task_text:
        print(f" {DIM}→{RESET} {GREEN}{current_task_text}{RESET}")
    else:
        print()  # Newline if no current task

    # Display category badges
    try:
        project_dir = Path.cwd()
        cat_manager = CategoryManager(project_dir)
        badge_cat_config = CategoryConfig(project_dir)

        badges = format_category_badges(cat_manager, badge_cat_config, category, is_global)
        if badges:
            print(f"  {badges}")
    except Exception:
        pass  # Silently skip if category badges can't be displayed

    print("-" * 50)

    if not tasks:
        print("\n  No tasks yet. Start typing to add one!")
    else:
        # Initialize selected_tasks and archived_task_ids if None
        if selected_tasks is None:
            selected_tasks = set()
        if archived_task_ids is None:
            archived_task_ids = set()

        # Priority colors and symbols
        PRIORITY_COLORS = {
            'none': DIM,
            'low': '\033[94m',  # BLUE
            'medium': YELLOW,
            'high': '\033[91m',  # RED
        }
        PRIORITY_SYMBOLS = {
            'none': '',
            'low': '◔',
            'medium': '◑',
            'high': '●',
        }
        # Status colors and symbols
        STATUS_COLORS = {
            'todo': DIM,
            'in-progress': CYAN,
            'blocked': '\033[91m',  # RED
            'done': GREEN,
        }
        STATUS_SYMBOLS = {
            'todo': '',
            'in-progress': '▶',
            'blocked': '⚠',
            'done': '✓',
        }
        # Archive indicator
        ARCHIVE_SYMBOL = '📦'
        ARCHIVE_COLOR = DIM

        for task in tasks:
            status = "✓" if task.get('done', False) else " "
            is_current = task.get('current', False)
            is_selected = task['id'] in selected_tasks
            is_break_task = 'break' in task['text'].lower()
            is_agent_task = task.get('agent_task', False)
            has_notes = bool(task.get('notes', '').strip())
            day = task.get('day')
            tally = task.get('tally', 0)
            priority = task.get('priority', 'none')
            task_status = task.get('status', 'todo')

            # Build priority prefix if present
            priority_prefix = ""
            if priority and priority != 'none':
                priority_color = PRIORITY_COLORS.get(priority, DIM)
                priority_symbol = PRIORITY_SYMBOLS.get(priority, '')
                priority_prefix = f"{priority_color}{priority_symbol}{RESET} "

            # Build status prefix if present
            status_prefix = ""
            if task_status and task_status not in ['todo', 'done']:
                status_color = STATUS_COLORS.get(task_status, DIM)
                status_symbol = STATUS_SYMBOLS.get(task_status, '')
                status_prefix = f"{status_color}{status_symbol}{RESET} "

            # Build day prefix if present
            day_prefix = ""
            if day:
                day_color = DAY_COLORS.get(day, CYAN)
                day_abbrev = DAY_ABBREVIATIONS.get(day, day[:3])
                day_prefix = f"{day_color}[{day_abbrev}]{RESET} "

            # Build tally suffix if present
            tally_suffix = ""
            if tally > 0:
                tally_suffix = f" {DIM}(×{tally}){RESET}"

            # Build stale warning if task is old
            stale_warning = ""
            updated_at = task.get('updated_at')
            if updated_at and not task.get('done', False) and task_status != 'done':
                try:
                    updated_dt = datetime.fromisoformat(updated_at.replace('Z', '+00:00'))
                    now = datetime.now(timezone.utc)
                    age_days = (now - updated_dt).days

                    if age_days >= 14:  # 2+ weeks old
                        stale_warning = f" {DIM}⏰{age_days}d{RESET}"
                    elif age_days >= 7:  # 1+ week old
                        stale_warning = f" {DIM}⏰{age_days}d{RESET}"
                except (ValueError, AttributeError):
                    pass

            # Build selection checkbox if in multi-select mode
            selection_box = ""
            if mode == MODE_MULTISELECT:
                if is_selected:
                    selection_box = f"{GREEN}[✓]{RESET} "
                else:
                    selection_box = "[ ] "

            # Build archive indicator if task is archived (in fuzzy search results)
            archive_prefix = ""
            is_archived = task['id'] in archived_task_ids
            if is_archived:
                archive_prefix = f"{ARCHIVE_COLOR}{ARCHIVE_SYMBOL}{RESET} "

            # Build notes indicator if task has notes
            notes_prefix = ""
            if has_notes:
                notes_prefix = "📝 "

            # Build analysis indicator if task has analysis file
            analysis_prefix = ""
            analysis_file = Path.cwd() / f".jot.analysis.{task['id']}.org"
            if analysis_file.exists():
                analysis_prefix = "📋 "

            # Combine all prefixes
            all_prefixes = (
                selection_box
                + archive_prefix
                + notes_prefix
                + analysis_prefix
                + priority_prefix
                + status_prefix
                + day_prefix
            )

            if is_agent_task:
                # Agent task styling - Claude Code is working on this
                MAGENTA = '\033[95m'  # Bright purple/magenta
                if is_current:
                    # Agent task that is also current
                    print(
                        f"{MAGENTA}{BOLD}→ [{status}] {task['id']}. {all_prefixes}🤖 {task['text']}{RESET}{tally_suffix}{stale_warning}"
                    )
                else:
                    # Agent task but not current
                    print(
                        f"{MAGENTA}  [{status}] {task['id']}. {all_prefixes}🤖 {task['text']}{RESET}{tally_suffix}{stale_warning}"
                    )
            elif is_current:
                if is_break_task:
                    # Special styling for "take a break" when current
                    print(
                        f"{GREEN}{BOLD}→ [{status}] {task['id']}. {all_prefixes}🌿 {task['text']}{RESET}{tally_suffix}{stale_warning}"
                    )
                else:
                    # Regular current task styling
                    print(
                        f"{CYAN}{BOLD}→ [{status}] {task['id']}. {all_prefixes}✨ {task['text']}{RESET}{tally_suffix}{stale_warning}"
                    )
            else:
                print(
                    f"  [{status}] {task['id']}. {all_prefixes}{task['text']}{tally_suffix}{stale_warning}"
                )

            # Display inline notes if toggle is on and task has notes
            if show_notes_inline and has_notes:
                note_lines = format_inline_notes(task.get('notes', ''))
                for line in note_lines:
                    print(line)

    print("\n" + "-" * 50)

    # Display archived tasks if toggle is on
    if show_archived and archived_tasks:
        print(f"\n{DIM}{BOLD}--- ARCHIVED ({len(archived_tasks)}) ---{RESET}")
        for task in archived_tasks:
            status = "✓" if task.get('done', False) else " "
            day = task.get('day')
            tally = task.get('tally', 0)

            # Build day prefix if present
            day_prefix = ""
            if day:
                day_color = DAY_COLORS.get(day, CYAN)
                day_abbrev = DAY_ABBREVIATIONS.get(day, day[:3])
                day_prefix = f"{day_color}[{day_abbrev}]{RESET} "

            # Build tally suffix if present
            tally_suffix = ""
            if tally > 0:
                tally_suffix = f" {DIM}(×{tally}){RESET}"

            # Display archived task in dimmed color
            print(
                f"{DIM}  [{status}] {task['id']}. {day_prefix}{task['text']}{tally_suffix}{RESET}"
            )

        print(f"{DIM}-" * 50 + RESET)

    # Display mode-specific footer
    if mode == MODE_QUICK_ADD:
        print(
            f"{GREEN}[QUICK ADD]{RESET} Type task, {BOLD}Enter{RESET} to save | {BOLD}/{RESET}: search | {BOLD}ESC{RESET}: commands | {BOLD}Shift+V{RESET}: multi-select | {BOLD}?{RESET}: shortcuts"
        )
        if show_shortcuts:
            display_categorized_shortcuts()
        print(f"→ {input_buffer}█", end='', flush=True)
    elif mode == MODE_MULTISELECT:
        selected_count = len(selected_tasks) if selected_tasks else 0
        print(
            f"{CYAN}{BOLD}[MULTI-SELECT]{RESET} {selected_count} selected | {BOLD}Space{RESET}: toggle | {BOLD}B{RESET}: bulk actions | {BOLD}ESC{RESET}: exit"
        )
        print(
            f"{CYAN}Navigation:{RESET} {BOLD}↑/↓{RESET}: move | {BOLD}Shift+↑/↓{RESET}: select while moving | {BOLD}A{RESET}: select all | {BOLD}N{RESET}: select none"
        )
        print("-" * 50)
    elif mode == MODE_FUZZY_SEARCH:
        # Display search prompt with result counts and toggle status
        # Count active and archived results
        active_count = sum(1 for task in tasks if task['id'] not in (archived_task_ids or set()))
        archived_count = len(archived_task_ids or set())

        # Build toggle status indicator
        toggle_status = (
            f"{GREEN}with archives{RESET}"
            if include_archived_in_search
            else f"{DIM}active only{RESET}"
        )

        # Show search query with counts
        if search_buffer:
            count_info = f" {DIM}({active_count} active"
            if archived_count > 0:
                count_info += f", {archived_count} archived"
            count_info += f"){RESET}"
        else:
            count_info = ""

        print(f"{CYAN}{BOLD}[FUZZY SEARCH]{RESET} {toggle_status} {search_buffer}█{count_info}")
        print(
            f"{CYAN}Keys:{RESET} Type to filter | {BOLD}↑/↓{RESET}: navigate | {BOLD}Enter{RESET}: select | {BOLD}Ctrl+A{RESET}: toggle archives | {BOLD}ESC{RESET}: cancel"
        )
        print("-" * 50)
    else:  # MODE_COMMAND
        print(
            f"{YELLOW}[COMMAND]{RESET} Press {BOLD}'a'{RESET} for quick-add | {BOLD}'h'{RESET} for help | {BOLD}'q'{RESET} to quit"
        )
        print(
            f"Commands: {BOLD}(a){RESET}dd | {BOLD}(c){RESET}urrent | {BOLD}(d){RESET}elete | {BOLD}(e){RESET}dit | {BOLD}(M){RESET}ove | {BOLD}(r){RESET}efresh | {BOLD}(h){RESET}elp | {BOLD}(q){RESET}uit"
        )
        print("-" * 50)
        print("Command: ", end='', flush=True)


def display_categorized_shortcuts():
    """Display shortcuts organized by category in multi-line format"""
    RESET = '\033[0m'
    BOLD = '\033[1m'
    CYAN = '\033[96m'
    DIM = '\033[2m'

    # Box drawing characters for visual appeal
    print(f"\n{DIM}╭─ {BOLD}SHORTCUTS{RESET}{DIM} {'─' * 56}╮{RESET}")

    # Task Management
    print(
        f"{DIM}│{RESET} {CYAN}Task:{RESET}      {BOLD}Shift+N{RESET}: notes   {BOLD}Shift+F{RESET}: inline notes  {BOLD}Shift+D{RESET}: delete {DIM}│{RESET}"
    )
    print(
        f"{DIM}│{RESET}            {BOLD}Shift+K{RESET}: copy    {BOLD}Shift+A{RESET}: archive                        {DIM}│{RESET}"
    )

    # Scheduling
    print(
        f"{DIM}│{RESET} {CYAN}Schedule:{RESET}  {BOLD}Shift+W{RESET}: day     {BOLD}Shift+Y{RESET}: today filter  {BOLD}Shift+O{RESET}: sort   {DIM}│{RESET}"
    )

    # Priority & Status
    print(
        f"{DIM}│{RESET} {CYAN}Priority:{RESET}  {BOLD}Shift+P{RESET}: priority  {BOLD}Shift+H{RESET}: high  {BOLD}Shift+X{RESET}: status        {DIM}│{RESET}"
    )

    # Projects & Categories
    print(
        f"{DIM}│{RESET} {CYAN}Projects:{RESET}  {BOLD}Shift+C{RESET}: category  {BOLD}Shift+Z{RESET}: switch  {BOLD}Shift+M{RESET}: move        {DIM}│{RESET}"
    )
    print(
        f"{DIM}│{RESET}            {BOLD}Shift+T{RESET}: transfer  {BOLD}Shift+R{RESET}: register  {BOLD}Shift+L{RESET}: list all  {DIM}│{RESET}"
    )

    # Actions
    print(
        f"{DIM}│{RESET} {CYAN}Actions:{RESET}   {BOLD}Shift+E{RESET}: execute   {BOLD}Shift+S{RESET}: search  {BOLD}Shift+U{RESET}: open URLs   {DIM}│{RESET}"
    )
    print(
        f"{DIM}│{RESET}            {BOLD}Shift+9{RESET}: analyze (AI)  {BOLD}Shift+0{RESET}: execute analysis         {DIM}│{RESET}"
    )

    # Integrations
    print(
        f"{DIM}│{RESET} {CYAN}Integrations:{RESET} {BOLD}Shift+G{RESET}: gcal export  {BOLD}Shift+I{RESET}: gcal import            {DIM}│{RESET}"
    )
    print(
        f"{DIM}│{RESET}               {BOLD}Shift+B{RESET}: bullet timer  {BOLD}Shift+J{RESET}: agent task            {DIM}│{RESET}"
    )

    # Other
    print(
        f"{DIM}│{RESET} {CYAN}Other:{RESET}     {BOLD}Shift+1{RESET}: fix IDs  {BOLD}Shift+2{RESET}: TTS read  {BOLD}?{RESET}: hide  {BOLD}h{RESET}: help  {BOLD}Shift+Q{RESET}: quit {DIM}│{RESET}"
    )

    print(f"{DIM}╰{'─' * 68}╯{RESET}\n")


def display_help():
    """Display comprehensive help for all jott commands and options"""
    RESET = '\033[0m'
    BOLD = '\033[1m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'

    print(f"\n{BOLD}jott{RESET} - Simple, extensible interactive CLI task list\n")

    print(f"{BOLD}USAGE:{RESET}")
    print(f"  {GREEN}jott{RESET}                                  Launch interactive mode")
    print(f"  {GREEN}jott{RESET} {CYAN}\"task text\"{RESET}                      Add task and exit")
    print(
        f"  {GREEN}jott{RESET} {CYAN}<project>{RESET} {CYAN}\"task text\"{RESET}           Add task to specific project"
    )
    print(f"  {GREEN}jott{RESET} {CYAN}[OPTIONS]{RESET}                        Run CLI commands\n")

    print(f"{BOLD}INTERACTIVE MODE:{RESET}")
    print(f"  {YELLOW}Quick-Add Mode (Default):{RESET}")
    print(f"    Type task text, press {BOLD}Enter{RESET} to save")
    print(f"    {BOLD}ESC{RESET} - Switch to command mode")
    print(f"    {BOLD}↑/↓{RESET}, {BOLD}Ctrl+N/P{RESET} - Navigate tasks")
    print(f"    {BOLD}Shift+↑/↓{RESET} - Reorder tasks\n")

    print(f"  {YELLOW}Quick-Add Shortcuts:{RESET}")
    print(f"    {BOLD}{CYAN}Shift+J{RESET} - Mark current task as agent task (Claude Code) 🤖")
    print(f"    {BOLD}{CYAN}Shift+G{RESET} - Export task to Google Calendar")
    print(f"    {BOLD}{CYAN}Shift+I{RESET} - Import today's events from Google Calendar")
    print(f"    {BOLD}{CYAN}Shift+E{RESET} - Execute keyword action for current task")
    print(f"    {BOLD}{CYAN}Shift+K{RESET} - Copy task text to clipboard")
    print(f"    {BOLD}{CYAN}Shift+B{RESET} - Start priority timer (12m focus session)")
    print(f"    {BOLD}{CYAN}Shift+W{RESET} - Assign day of week")
    print(f"    {BOLD}{CYAN}Shift+P{RESET} - Set task priority (menu)")
    print(f"    {BOLD}{CYAN}Shift+H{RESET} - Set priority to high (quick)")
    print(f"    {BOLD}{CYAN}Shift+X{RESET} - Set task status")
    print(f"    {BOLD}{CYAN}Shift+D{RESET} - Delete current task")
    print(f"    {BOLD}{CYAN}Shift+M{RESET} - Move task to different project")
    print(f"    {BOLD}{CYAN}Shift+T{RESET} - Transfer task to category")
    print(f"    {BOLD}{CYAN}Shift+C{RESET} - Switch category")
    print(f"    {BOLD}{CYAN}Shift+Z{RESET} - Switch project")
    print(f"    {BOLD}{CYAN}Shift+R{RESET} - Register current project")
    print(f"    {BOLD}{CYAN}Shift+L{RESET} - View all categories (toggle)")
    print(f"    {BOLD}{CYAN}Shift+S{RESET} - Web search with task text")
    print(f"    {BOLD}{CYAN}Shift+U{RESET} - Open URLs in task text")
    print(f"    {BOLD}{CYAN}Shift+9{RESET} - Analyze task with Claude Code AI (plan mode)")
    print(
        f"    {BOLD}{CYAN}Shift+0{RESET} - Execute analysis plan with Claude Code (full implementation)"
    )
    print(f"    {BOLD}{CYAN}Shift+A{RESET} - Toggle archived tasks display")
    print(f"    {BOLD}{CYAN}Shift+O{RESET} - Toggle day-of-week sorting")
    print(f"    {BOLD}{CYAN}Shift+Y{RESET} - Toggle today-only filter")
    print(f"    {BOLD}{CYAN}Shift+1{RESET} - Fix duplicate task IDs (verify data integrity)")
    print(f"    {BOLD}{CYAN}Shift+2{RESET} - Read all tasks aloud (text-to-speech)")
    print(f"    {BOLD}{CYAN}Shift+Q{RESET} - Quit\n")

    print(f"  {YELLOW}Command Mode:{RESET}")
    print(f"    {BOLD}{CYAN}a{RESET} - Add task        {BOLD}{CYAN}d{RESET} - Delete by ID")
    print(f"    {BOLD}{CYAN}c{RESET} - Set current     {BOLD}{CYAN}D{RESET} - Delete current")
    print(f"    {BOLD}{CYAN}e{RESET} - Edit by ID      {BOLD}{CYAN}E{RESET} - Edit current")
    print(f"    {BOLD}{CYAN}M{RESET} - Move to project {BOLD}{CYAN}r{RESET} - Refresh")
    print(f"    {BOLD}{CYAN}h{RESET} - Help            {BOLD}{CYAN}q{RESET} - Quit\n")

    print(f"  {YELLOW}Fuzzy Search Mode:{RESET}")
    print(f"    {BOLD}{CYAN}/{RESET} - Enter fuzzy search from quick-add mode")
    print(f"    Type to filter tasks by fuzzy matching")
    print(f"    {BOLD}{CYAN}↑/↓{RESET} - Navigate filtered results")
    print(f"    {BOLD}{CYAN}Enter{RESET} - Select task and return to quick-add")
    print(f"    {BOLD}{CYAN}ESC{RESET} - Cancel and return to quick-add\n")

    print(f"{BOLD}KEYWORD AUTOMATION:{RESET}")
    print(f"  Keywords automate actions when tasks are created.")
    print(f"  Format: {CYAN}keyword: task text{RESET}")
    print(f"  Example: {CYAN}gcal: Team meeting{RESET}\n")
    print(f"  {YELLOW}Built-in Keywords:{RESET}")
    print(f"    {CYAN}bullet:{RESET}   Start priority timer automatically")
    print(f"    {CYAN}gcal:{RESET}     Export task to Google Calendar")
    print(f"    {CYAN}ai:{RESET}       Mark task for AI/agent assistance (🤖)")
    print(
        f"    {CYAN}analyze:{RESET}  Analyze task with Claude Code AI (creates .jot.analysis.{{id}}.org)"
    )
    print(f"    {CYAN}remind:{RESET}   Display system notification (manual trigger)\n")
    print(f"  {YELLOW}Manual Trigger:{RESET}")
    print(f"    Use {CYAN}Shift+E{RESET} to manually execute keyword action")
    print(f"    Useful for keywords with auto_trigger: false\n")
    print(f"  {YELLOW}Configuration:{RESET}")
    print(f"    Config file: {CYAN}~/.jot-keywords.json{RESET}")
    print(f"    Customize auto-trigger, create aliases for existing keywords")
    print(f"    Add custom keywords: edit jot.py (see README.org)\n")

    print(f"{BOLD}PROJECT MANAGEMENT:{RESET}")
    print(f"  --list-projects                       List all registered projects")
    print(f"  --all-projects                        View all project tasks")
    print(f"  --register <name> <path>              Register a project")
    print(f"  --unregister <name>                   Unregister a project")
    print(f"  --refresh                             Refresh project registry")
    print(f"  --fix-duplicates                      Fix duplicate task IDs\n")

    print(f"{BOLD}CATEGORY MANAGEMENT:{RESET}")
    print(f"  --stats                               Show category statistics")
    print(f"  --archive [category]                  View archived tasks")
    print(f"  --colors                              Show available colors")
    print(f"  --set-color <category> <color>        Set category color")
    print(f"  --list-colors                         List configured colors")
    print(f"  --reset-colors                        Reset colors to defaults")
    print(f"  --list-templates                      List category templates")
    print(f"  --template <name> [--with-samples]    Apply category template\n")

    print(f"{BOLD}ARCHIVE MANAGEMENT:{RESET}")
    print(f"  --archive-compress [--keep N]         Compress old archives (keep N recent)")
    print(f"  --archive-export [--format FORMAT]    Export archives (json/csv/markdown/text)")
    print(f"                   [--output FILE]")
    print(f"  --archive-prune --older-than N        Delete archives older than N months")
    print(f"                  [--interactive]")
    print(f"  --archive-prune --file FILENAME       Delete specific archive file")
    print(f"  --archive-stats                       Show archive statistics\n")

    print(f"{BOLD}BACKUP & RESTORE:{RESET}")
    print(f"  --backup [--output <file>]            Create backup of all data")
    print(f"  --restore <file> [--force]            Restore from backup")
    print(f"  --list-backup <file>                  List backup contents")
    print(f"  --migrate-backlog-schema              Add grooming fields to tasks\n")

    print(f"{BOLD}DAY FILTERING:{RESET}")
    print(f"  --day <day>                           Filter by day (Monday-Sunday)")
    print(f"  --today                               Show today's tasks")
    print(f"  --week                                Show week's tasks by day\n")

    print(f"{BOLD}FLAGS:{RESET}")
    print(f"  --global                              Use global tasks")
    print(f"  --category <name>, -c <name>          Use specific category")
    print(f"  --help, -h                            Show this help message\n")

    print(f"{BOLD}EXAMPLES:{RESET}")
    print(f"  {GREEN}jott{RESET}                                  Launch interactive mode")
    print(f"  {GREEN}jott{RESET} {CYAN}\"buy groceries\"{RESET}                  Quick task add")
    print(
        f"  {GREEN}jott{RESET} {CYAN}myproject{RESET} {CYAN}\"fix bug #42\"{RESET}          Add to specific project"
    )
    print(f"  {GREEN}jott{RESET} {CYAN}--today{RESET}                          Show today's tasks")
    print(f"  {GREEN}jott{RESET} {CYAN}--all-projects{RESET}                   View all projects")
    print(f"  {GREEN}jott{RESET} {CYAN}--backup{RESET}                         Create backup\n")

    print(f"For more info: {CYAN}https://github.com/son1112/jot{RESET}\n")


def fuzzy_match(query, text):
    """
    Fuzzy match query against text.

    Returns:
        (is_match, score, match_positions) where:
        - is_match: bool indicating if all query chars found in text in order
        - score: int score (higher is better match)
        - match_positions: list of indices in text where query chars matched
    """
    if not query:
        return (True, 0, [])

    query_lower = query.lower()
    text_lower = text.lower()

    # Find all query characters in text in order
    match_positions = []
    text_idx = 0

    for query_char in query_lower:
        # Find next occurrence of query char in text
        found = False
        while text_idx < len(text_lower):
            if text_lower[text_idx] == query_char:
                match_positions.append(text_idx)
                text_idx += 1
                found = True
                break
            text_idx += 1

        if not found:
            return (False, 0, [])  # Query char not found

    # Calculate score based on match quality
    score = 0

    # Bonus for consecutive character runs
    consecutive_run = 1
    for i in range(1, len(match_positions)):
        if match_positions[i] == match_positions[i - 1] + 1:
            consecutive_run += 1
            score += 10 * consecutive_run  # Exponential bonus for longer runs
        else:
            consecutive_run = 1

    # Bonus for word boundary matches
    for pos in match_positions:
        if pos == 0 or text[pos - 1] in ' -_./':
            score += 5

    # Penalty for character gaps
    if len(match_positions) > 1:
        total_gap = match_positions[-1] - match_positions[0]
        gap_penalty = total_gap - len(match_positions)
        score -= gap_penalty

    # Bonus for exact case matches
    for i, pos in enumerate(match_positions):
        if query[i] == text[pos]:
            score += 2

    # Bonus for matching at start
    if match_positions and match_positions[0] == 0:
        score += 15

    return (True, score, match_positions)


def get_key(timeout=1.0):
    """Read a single keypress with timeout, including arrow keys and shift combinations

    Args:
        timeout: Seconds to wait for input before returning None

    Returns:
        Key character/code, tuple for paste ('PASTE', text), or None on timeout
    """
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)

        # Use select to wait for input with timeout
        ready, _, _ = select.select([sys.stdin], [], [], timeout)
        if not ready:
            return None  # Timeout - no input available

        ch = sys.stdin.read(1)

        # Check if more characters are immediately available (paste detection)
        # Use a very short timeout (0.001 seconds) to detect rapid input
        more_ready, _, _ = select.select([sys.stdin], [], [], 0.001)
        if more_ready:
            # Multiple characters available - this is likely a paste
            pasted_text = ch
            # Read all available characters
            while True:
                chunk_ready, _, _ = select.select([sys.stdin], [], [], 0.001)
                if not chunk_ready:
                    break
                pasted_text += sys.stdin.read(1)
            return ('PASTE', pasted_text)

        # Handle Ctrl+n (next/down) and Ctrl+p (previous/up)
        if ch == '\x0e':  # Ctrl+n
            return 'DOWN'
        elif ch == '\x10':  # Ctrl+p
            return 'UP'

        # Handle escape sequences (arrow keys)
        if ch == '\x1b':  # ESC
            ch2 = sys.stdin.read(1)
            if ch2 == '[':
                ch3 = sys.stdin.read(1)
                # Check for standard arrow keys
                if ch3 == 'A':
                    return 'UP'
                elif ch3 == 'B':
                    return 'DOWN'
                # Check for shift+arrow keys (1;2A = Shift+Up, 1;2B = Shift+Down)
                elif ch3 == '1':
                    ch4 = sys.stdin.read(1)
                    if ch4 == ';':
                        ch5 = sys.stdin.read(1)
                        if ch5 == '2':
                            ch6 = sys.stdin.read(1)
                            if ch6 == 'A':
                                return 'SHIFT_UP'
                            elif ch6 == 'B':
                                return 'SHIFT_DOWN'

        return ch
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)


def main():
    """Main application loop with dual-mode support and project routing"""
    registry = ProjectRegistry()

    # Parse flags
    category = None
    explicit_global = False
    args = sys.argv[1:]  # Skip program name

    # Handle --help / -h flag (check first to ensure it always works)
    if '--help' in args or '-h' in args:
        display_help()
        return

    # Check for --global flag
    if '--global' in args:
        explicit_global = True
        args.remove('--global')

    # Check for --category / -c flag
    if '--category' in args:
        idx = args.index('--category')
        if idx + 1 < len(args):
            category = args[idx + 1]
            # Remove flag and value from args
            args = args[:idx] + args[idx + 2 :]
    elif '-c' in args:
        idx = args.index('-c')
        if idx + 1 < len(args):
            category = args[idx + 1]
            # Remove flag and value from args
            args = args[:idx] + args[idx + 2 :]

    # Handle project management commands
    if len(args) > 0:
        if args[0] == '--list-projects':
            projects = registry.list_projects()
            if projects:
                print("\nRegistered Projects:")
                for name, path in sorted(projects.items()):
                    print(f"  {name:20} → {path}")
            else:
                print("\nNo registered projects. Run jot to auto-discover projects in ~/projects/")
            return

        elif args[0] == '--register' and len(args) == 3:
            name, path = args[1], args[2]
            registry.register_project(name, path)
            print(f"✓ Registered project '{name}' → {path}")
            return

        elif args[0] == '--unregister' and len(args) == 2:
            name = args[1]
            if registry.unregister_project(name):
                print(f"✓ Unregistered project '{name}'")
            else:
                print(f"✗ Project '{name}' not found")
            return

        elif args[0] == '--refresh':
            registry.refresh()
            print("✓ Project registry refreshed")
            return

        elif args[0] == '--all-projects':
            # Check if --show-categories flag is also present
            show_categories = '--show-categories' in args
            display_all_projects(registry, show_categories=show_categories)
            return

        elif args[0] == '--fix-duplicates':
            # Fix duplicate task IDs in current directory

            jot_file = Path.cwd() / '.jot.json'

            if not jot_file.exists():
                print(f"✗ No .jot.json found in {Path.cwd()}")
                return

            print(f"\n🔧 Fixing duplicate IDs in {jot_file}...")

            # Get path to fix-duplicate-ids.py (same directory as jot.py)
            fix_script = Path(__file__).parent / 'fix-duplicate-ids.py'

            if not fix_script.exists():
                print(f"✗ fix-duplicate-ids.py not found at {fix_script}")
                print(f"   Please run manually: python3 fix-duplicate-ids.py {jot_file}")
                return

            try:
                # Run the fixer
                result = subprocess.run(
                    ['python3', str(fix_script), str(jot_file)],
                    capture_output=True,
                    text=True,
                    check=True,
                )

                # Print output
                print(result.stdout)

                if result.returncode == 0:
                    print("\n✓ Duplicate IDs fixed! You can now run jott again.")
                else:
                    print(f"\n✗ Fix failed with exit code {result.returncode}")
                    if result.stderr:
                        print(f"Error: {result.stderr}")

            except subprocess.CalledProcessError as e:
                print(f"✗ Fix failed: {e}")
                if e.stderr:
                    print(f"Error: {e.stderr}")

            return

        elif args[0] == '--archive':
            # Display archived tasks, optionally filtered by category
            filter_category = None
            if len(args) > 1 and not args[1].startswith('--'):
                filter_category = args[1]
            display_archive(Path.cwd(), filter_category)
            return

        elif args[0] == '--archive-compress':
            # Compress archives
            archive_mgr = ArchiveManager(Path.cwd())
            keep_n = None
            if '--keep' in args:
                idx = args.index('--keep')
                if idx + 1 < len(args):
                    try:
                        keep_n = int(args[idx + 1])
                    except ValueError:
                        print("✗ --keep requires a number")
                        return

            result = archive_mgr.compress_archives(keep_n=keep_n, category=category)

            if 'error' in result:
                print(f"✗ {result['error']}")
            elif 'message' in result:
                print(f"ℹ {result['message']}")
            else:
                print(f"✓ Compressed {result['compressed']} archived tasks")
                print(f"  Kept {result['kept_in_main']} in main file")
                print(f"  Created {result['archive_files_created']} archive files")
            return

        elif args[0] == '--archive-export':
            # Export archives
            archive_mgr = ArchiveManager(Path.cwd())
            format = 'json'
            output = None

            if '--format' in args:
                idx = args.index('--format')
                if idx + 1 < len(args):
                    format = args[idx + 1]

            if '--output' in args:
                idx = args.index('--output')
                if idx + 1 < len(args):
                    output = args[idx + 1]

            result = archive_mgr.export_archives(
                format=format, output=output, include_compressed=True, category=category
            )

            if 'error' in result:
                print(f"✗ {result['error']}")
            else:
                print(f"✓ Exported {result['exported']} archived tasks")
                print(f"  Format: {result['format']}")
                print(f"  Output: {result['output']}")
            return

        elif args[0] == '--archive-prune':
            # Prune archives
            archive_mgr = ArchiveManager(Path.cwd())
            strategy = 'older_than'
            value = None
            interactive = '--interactive' in args

            if '--older-than' in args:
                idx = args.index('--older-than')
                if idx + 1 < len(args):
                    try:
                        value = int(args[idx + 1])
                        strategy = 'older_than'
                    except ValueError:
                        print("✗ --older-than requires a number (months)")
                        return

            if '--file' in args:
                idx = args.index('--file')
                if idx + 1 < len(args):
                    value = args[idx + 1]
                    strategy = 'file'

            result = archive_mgr.prune_archives(
                strategy=strategy, value=value, interactive=interactive
            )

            if 'error' in result:
                print(f"✗ {result['error']}")
            elif 'message' in result:
                print(f"ℹ {result['message']}")
            elif 'cancelled' in result:
                print("✗ Pruning cancelled")
            else:
                print(f"✓ Deleted {result['deleted']} archive files")
                for filename in result['files']:
                    print(f"  - {filename}")
            return

        elif args[0] == '--archive-stats':
            # Show archive statistics
            archive_mgr = ArchiveManager(Path.cwd())
            stats = archive_mgr.get_archive_stats()

            BOLD = '\033[1m'
            CYAN = '\033[96m'
            RESET = '\033[0m'

            print(f"\n{BOLD}Archive Statistics{RESET}")
            print("-" * 60)
            print(f"Total archived tasks:     {CYAN}{stats['total_archived']}{RESET}")
            print(f"  In main files:          {stats['in_main_files']}")
            print(f"  In compressed files:    {stats['in_compressed']}")
            print()
            print(f"Compressed files:         {stats['compressed_files']}")
            print(f"Total size:               {stats['total_size_bytes']} bytes")

            if stats['oldest_task']:
                print(f"Oldest task:              {stats['oldest_task']}")
            if stats['newest_task']:
                print(f"Newest task:              {stats['newest_task']}")

            if stats['archive_files']:
                print(f"\n{BOLD}Archive Files:{RESET}")
                for filename in stats['archive_files']:
                    print(f"  - {filename}")

            print()
            return

        elif args[0] == '--stats':
            # Display category statistics
            display_category_stats(Path.cwd())
            return

        elif args[0] == '--colors':
            # Show available colors with examples
            cat_config = CategoryConfig()
            colors = cat_config.list_available_colors()
            RESET = '\033[0m'
            BOLD = '\033[1m'

            print(f"\n{BOLD}Available Colors:{RESET}")
            print("-" * 40)
            for color_name in colors:
                color_code = CategoryConfig.COLORS[color_name]
                print(f"  {color_code}{color_name:12}{RESET} - {color_code}■■■{RESET} Example text")
            print("-" * 40)
            print(f"\n{BOLD}Usage:{RESET}")
            print(f"  jot --set-color <category> <color>")
            print(f"  jot --list-colors")
            print(f"  jot --reset-colors")
            print()
            return

        elif args[0] == '--set-color' and len(args) >= 3:
            # Set color for a category
            category_name = args[1]
            color_name = args[2]
            cat_config = CategoryConfig()
            success, message = cat_config.set_color(category_name, color_name)
            if success:
                color_code = CategoryConfig.COLORS[color_name]
                RESET = '\033[0m'
                print(f"✓ {message}")
                print(f"  Preview: {color_code}{category_name}{RESET}")
            else:
                print(f"✗ {message}")
            return

        elif args[0] == '--list-colors':
            # List configured colors
            cat_config = CategoryConfig()
            custom_colors = cat_config.get_all_colors()
            RESET = '\033[0m'
            BOLD = '\033[1m'

            print(f"\n{BOLD}Configured Category Colors:{RESET}")
            print("-" * 40)

            if not custom_colors:
                print("  No custom colors configured.")
                print("  Using default colors.")
            else:
                for cat_name, color_name in sorted(custom_colors.items()):
                    color_code = CategoryConfig.COLORS.get(color_name, '\033[96m')
                    print(f"  {color_code}{cat_name:20}{RESET} → {color_name}")

            print("-" * 40)
            print(f"\n{BOLD}Default Colors:{RESET}")
            for cat_name, color_name in sorted(CategoryConfig.DEFAULT_COLORS.items()):
                if cat_name not in custom_colors:
                    color_code = CategoryConfig.COLORS[color_name]
                    print(f"  {color_code}{cat_name:20}{RESET} → {color_name}")
            print()
            return

        elif args[0] == '--reset-colors':
            # Reset all colors to defaults
            cat_config = CategoryConfig()
            cat_config.reset_colors()
            print("✓ Reset all colors to defaults")
            return

        elif args[0] == '--list-templates':
            # List available templates
            templates_manager = CategoryTemplates()
            templates = templates_manager.list_templates()
            RESET = '\033[0m'
            BOLD = '\033[1m'
            CYAN = '\033[96m'
            DIM = '\033[2m'

            print(f"\n{BOLD}Available Category Templates:{RESET}")
            print("=" * 60)

            for template_id, template in sorted(templates.items()):
                print(f"\n{CYAN}{BOLD}{template_id}{RESET}")
                print(f"  {template['name']}")
                print(f"  {DIM}{template['description']}{RESET}")
                print(f"  Categories: {', '.join(template['categories'])}")

            print("\n" + "=" * 60)
            print(f"\n{BOLD}Usage:{RESET}")
            print(f"  jot --template <name>              # Apply template")
            print(f"  jot --template <name> --with-samples  # Include sample tasks")
            print()
            return

        elif args[0] == '--template' and len(args) >= 2:
            # Apply a template
            template_name = args[1]
            with_samples = '--with-samples' in args

            templates_manager = CategoryTemplates()
            success, message = templates_manager.apply_template(
                template_name, with_samples=with_samples
            )

            if success:
                print(f"✓ {message}")
                if with_samples:
                    print("  Sample tasks added to each category")
                print("\n  Use Shift+C to switch between categories")
            else:
                print(f"✗ {message}")
            return

        elif args[0] == '--backup':
            # Create backup of all jot files
            output_file = None
            if '--output' in args:
                idx = args.index('--output')
                if idx + 1 < len(args):
                    output_file = args[idx + 1]

            backup = ProjectBackup()
            success, message = backup.create_backup(output_file)

            if success:
                print(f"✓ {message}")
            else:
                print(f"✗ {message}")
            return

        elif args[0] == '--restore' and len(args) >= 2:
            # Restore from backup
            backup_file = args[1]
            force = '--force' in args

            backup = ProjectBackup()
            success, message = backup.restore_backup(backup_file, force=force)

            if success:
                print(f"✓ {message}")
            else:
                print(f"✗ {message}")
            return

        elif args[0] == '--list-backup' and len(args) >= 2:
            # List contents of a backup
            backup_file = args[1]

            backup = ProjectBackup()
            success, message = backup.list_backup_contents(backup_file)

            if success:
                print(message)
            else:
                print(f"✗ {message}")
            return

        elif args[0] == '--migrate-backlog-schema':
            # Migrate existing tasks to include backlog grooming metadata
            print("\n🔄 Migrating tasks to backlog grooming schema...")
            print(
                "This will add priority, status, labels, timestamps, effort, and blocked_by fields.\n"
            )

            # Confirm with user
            response = input("Proceed with migration? (y/N): ").strip().lower()
            if response != 'y':
                print("✗ Migration cancelled")
                return

            # Create backup before migration
            print("\n📦 Creating backup before migration...")
            backup = ProjectBackup()
            backup_success, backup_msg = backup.create_backup()

            if not backup_success:
                print(f"✗ Backup failed: {backup_msg}")
                print("Migration aborted for safety.")
                return

            print(f"✓ {backup_msg}\n")

            # Run migration on current project
            task_manager = TaskManager(
                storage_file='.jot.json',
                directory=Path.cwd(),
                category=category,
                is_global=explicit_global,
            )

            stats = task_manager.migrate_backlog_schema()

            # Display results
            print("✓ Migration complete!")
            print(f"\n  Migrated: {stats['migrated']} tasks")
            print(f"  Already migrated: {stats['already_migrated']} tasks")
            print(f"  Total tasks: {stats['total']} tasks\n")

            if stats['migrated'] > 0:
                print("New fields added:")
                print("  • priority: 'none' (default)")
                print("  • status: 'todo' or 'done' (based on existing done field)")
                print("  • created_at: current timestamp")
                print("  • updated_at: current timestamp")
                print("  • labels: [] (empty)")
                print("  • effort: null")
                print("  • blocked_by: [] (empty)\n")

            return

        elif args[0] == '--day' and len(args) >= 2:
            # Filter tasks by specific day
            day_filter = args[1].capitalize()

            # Validate day name
            valid_days = [
                'Monday',
                'Tuesday',
                'Wednesday',
                'Thursday',
                'Friday',
                'Saturday',
                'Sunday',
            ]
            if day_filter not in valid_days:
                print(f"✗ Invalid day: {day_filter}")
                print(f"Valid days: {', '.join(valid_days)}")
                return

            # Load tasks and filter by day
            task_manager = TaskManager()
            all_tasks = task_manager.get_tasks()
            filtered_tasks = [t for t in all_tasks if t.get('day') == day_filter]

            # Display filtered tasks
            RESET = '\033[0m'
            BOLD = '\033[1m'
            day_color = DAY_COLORS[day_filter]
            day_abbrev = DAY_ABBREVIATIONS[day_filter]

            print(f"\n{BOLD}Tasks for {day_color}{day_abbrev}{RESET} {BOLD}{day_filter}:{RESET}")
            print("=" * 50)

            if not filtered_tasks:
                print(f"\nNo tasks scheduled for {day_filter}")
            else:
                for task in filtered_tasks:
                    status = "✓" if task.get('done', False) else " "
                    is_current = "✨ " if task.get('current', False) else ""
                    print(f"  [{status}] {task['id']}. {is_current}{task['text']}")
                print(f"\nTotal: {len(filtered_tasks)} tasks")

            print("=" * 50 + "\n")
            return

        elif args[0] == '--today':
            # Show today's tasks
            today = get_today_day_name()

            # Load tasks and filter by today
            task_manager = TaskManager()
            all_tasks = task_manager.get_tasks()
            filtered_tasks = [t for t in all_tasks if t.get('day') == today]

            # Display tasks
            RESET = '\033[0m'
            BOLD = '\033[1m'
            day_color = DAY_COLORS[today]
            day_abbrev = DAY_ABBREVIATIONS[today]

            print(f"\n{BOLD}Today's Tasks ({day_color}{day_abbrev}{RESET} {BOLD}{today}):{RESET}")
            print("=" * 50)

            if not filtered_tasks:
                print(f"\nNo tasks scheduled for today")
            else:
                for task in filtered_tasks:
                    status = "✓" if task.get('done', False) else " "
                    is_current = "✨ " if task.get('current', False) else ""
                    print(f"  [{status}] {task['id']}. {is_current}{task['text']}")
                print(f"\nTotal: {len(filtered_tasks)} tasks")

            print("=" * 50 + "\n")
            return

        elif args[0] == '--week':
            # Show this week's tasks sorted by day
            task_manager = TaskManager()
            all_tasks = task_manager.get_tasks()

            # Group tasks by day (Sunday through Saturday)
            days_order = [
                'Sunday',
                'Monday',
                'Tuesday',
                'Wednesday',
                'Thursday',
                'Friday',
                'Saturday',
            ]
            tasks_by_day = {day: [] for day in days_order}
            tasks_no_day = []

            for task in all_tasks:
                day = task.get('day')
                if day and day in tasks_by_day:
                    tasks_by_day[day].append(task)
                elif not day:
                    tasks_no_day.append(task)

            # Display
            RESET = '\033[0m'
            BOLD = '\033[1m'
            today = get_today_day_name()

            print(f"\n{BOLD}This Week's Tasks:{RESET}")
            print("=" * 50)

            total_count = 0
            for day in days_order:
                day_tasks = tasks_by_day[day]
                if day_tasks:
                    day_color = DAY_COLORS[day]
                    day_abbrev = DAY_ABBREVIATIONS[day]
                    today_marker = " (Today)" if day == today else ""
                    print(
                        f"\n{day_color}{BOLD}{day_abbrev}{RESET} {BOLD}{day}{today_marker}:{RESET}"
                    )
                    for task in day_tasks:
                        status = "✓" if task.get('done', False) else " "
                        is_current = "✨ " if task.get('current', False) else ""
                        print(f"  [{status}] {task['id']}. {is_current}{task['text']}")
                        total_count += 1

            if tasks_no_day:
                print(f"\n{BOLD}No Day Assigned:{RESET}")
                for task in tasks_no_day:
                    status = "✓" if task.get('done', False) else " "
                    is_current = "✨ " if task.get('current', False) else ""
                    print(f"  [{status}] {task['id']}. {is_current}{task['text']}")

            print(f"\n{BOLD}Total:{RESET} {total_count} tasks with days assigned")
            print("=" * 50 + "\n")
            return

    # Determine target directory and project name
    target_dir = None
    project_name = None
    initial_task = None

    if len(args) > 0:
        # Check if first argument is a project name
        potential_project = args[0]
        project_path = registry.get_project_path(potential_project)

        if project_path:
            # Project routing mode
            target_dir = project_path
            project_name = potential_project
            if len(args) > 1:
                initial_task = ' '.join(args[1:])
        else:
            # Regular mode: all args are task text
            initial_task = ' '.join(args)

    # Determine if we should use global category
    is_global = False
    if category:
        cat_manager = CategoryManager(project_dir=target_dir or Path.cwd())

        if explicit_global:
            # User explicitly requested global
            is_global = True
        else:
            # Resolve category location: local → global → new
            location = cat_manager.resolve_category_location(category)

            if location == 'global':
                # Category exists globally, use it
                is_global = True
            elif location == 'local':
                # Category exists locally, use it
                is_global = False
            else:
                # New category - create locally by default
                is_global = False

                # Check local category limit
                can_create, error_msg = cat_manager.can_create_category(category)
                if not can_create:
                    print(f"✗ {error_msg}")
                    return

                # Show warning if approaching limit
                warning_msg = cat_manager.get_warning_message(category)
                if warning_msg:
                    print(warning_msg)

    # Initialize task manager with appropriate directory and category
    task_manager = TaskManager(directory=target_dir, category=category, is_global=is_global)
    command_handler = CommandHandler(task_manager, registry)

    # Ensure default "take a break" task exists if no tasks present
    task_manager.ensure_default_task()

    # Add initial task if provided
    if initial_task:
        task_manager.add_task(initial_task)
        location = project_name or Path.cwd().name

        if is_global and category:
            print(f"✓ Added task to global ({category}): {initial_task}")
        elif category:
            print(f"✓ Added task to {location} ({category}): {initial_task}")
        else:
            print(f"✓ Added task to {location}: {initial_task}")
        return

    # Mode state
    mode = MODE_QUICK_ADD  # Start in quick-add mode
    input_buffer = ""
    show_archived = False  # Toggle for showing archived tasks
    sort_by_day = False  # Toggle for sorting tasks by day of week
    show_today_only = False  # Toggle for showing only today's tasks
    include_archived_in_search = True  # Toggle for including archived tasks in fuzzy search
    show_shortcuts = False  # Toggle for showing shortcuts helper text (default: hidden)
    show_notes_inline = False  # Toggle for showing notes indented below tasks

    # Track file modification time for auto-refresh
    last_mtime = (
        os.path.getmtime(task_manager.storage_file) if task_manager.storage_file.exists() else 0
    )

    running = True
    selected_tasks = set()  # Track selected tasks for multi-select mode
    search_buffer = ""  # Track search query for fuzzy search mode
    filtered_tasks = []  # Track filtered/scored tasks for fuzzy search mode
    archived_task_ids = set()  # Track which tasks in display are archived

    while running:
        # Clear screen (works on Unix/Linux/macOS)
        os.system('clear' if os.name != 'nt' else 'cls')

        # Get tasks and optionally filter/sort
        tasks_to_display = task_manager.get_tasks()
        if show_today_only:
            today = get_today_day_name()
            tasks_to_display = filter_today_tasks(tasks_to_display, today)
        if sort_by_day:
            tasks_to_display = sort_tasks_by_day(tasks_to_display)

        # In fuzzy search mode, filter and sort by match score
        if mode == MODE_FUZZY_SEARCH and search_buffer:
            filtered_tasks = []
            archived_task_ids = set()

            # Search active tasks
            for task in tasks_to_display:
                is_match, score, positions = fuzzy_match(search_buffer, task.get('text', ''))
                if is_match:
                    filtered_tasks.append((task, score, positions))

            # Also search archived tasks if enabled
            if include_archived_in_search:
                for task in task_manager.archived:
                    is_match, score, positions = fuzzy_match(search_buffer, task.get('text', ''))
                    if is_match:
                        filtered_tasks.append((task, score, positions))
                        archived_task_ids.add(task['id'])

            # Sort by score (highest first)
            filtered_tasks.sort(key=lambda x: x[1], reverse=True)
            # Extract just the tasks for display
            tasks_to_display = [t[0] for t in filtered_tasks]
            # Set first task as current if available
            if filtered_tasks:
                task_manager.set_current(filtered_tasks[0][0]['id'])
        elif mode == MODE_FUZZY_SEARCH:
            # Fuzzy search mode but no search buffer yet - clear archived tracking
            archived_task_ids = set()

        # Display tasks with current mode, project name, and category
        if mode == MODE_ALL_CATEGORIES:
            # All categories view - display tasks from all categories grouped
            all_cat_data = command_handler.collect_all_category_tasks(
                task_manager.project_dir if not task_manager.is_global else Path.cwd(),
                show_archived=show_archived,
            )

            # Simple display for all categories
            CYAN = '\033[96m'
            BOLD = '\033[1m'
            RESET = '\033[0m'
            DIM = '\033[2m'

            print(f"\n{CYAN}{BOLD}ALL CATEGORIES VIEW{RESET}")
            print("-" * 50)

            cat_config = CategoryConfig(project_dir=task_manager.project_dir)
            task_num = 1
            total_tasks = 0

            for cat_name, is_global, tasks, archived in all_cat_data:
                # Count tasks
                display_tasks_list = tasks + (archived if show_archived else [])
                if not display_tasks_list:
                    continue

                total_tasks += len(display_tasks_list)

                # Category header
                cat_color = cat_config.get_color(cat_name, for_global=is_global)
                global_indicator = (
                    f" {DIM}[global]{RESET}" if is_global else f" {DIM}[local]{RESET}"
                )
                print(
                    f"\n{cat_color}{BOLD}[{cat_name}]{RESET}{global_indicator} ({len(display_tasks_list)} tasks)"
                )

                # Display tasks
                for task in display_tasks_list:
                    status = "✓" if task.get('done', False) else " "
                    is_current = task.get('current', False)
                    marker = "→" if is_current else " "
                    print(f"  {marker} [{status}] {task_num}. {task.get('text', '')}")
                    task_num += 1

            print(f"\n{DIM}Total: {total_tasks} tasks across {len(all_cat_data)} categories{RESET}")
            print("-" * 50)
            print(f"{CYAN}Press Shift+L or ESC to return to single category view{RESET}")
        else:
            display_tasks(
                tasks_to_display,
                mode,
                input_buffer,
                project_name,
                category=task_manager.category,
                is_global=task_manager.is_global,
                show_archived=show_archived,
                archived_tasks=task_manager.archived,
                selected_tasks=selected_tasks,
                search_buffer=search_buffer,
                archived_task_ids=archived_task_ids,
                include_archived_in_search=include_archived_in_search,
                show_shortcuts=show_shortcuts,
                show_notes_inline=show_notes_inline,
            )

        try:
            key = get_key()

            # Auto-refresh: check if file was modified externally
            if key is None:
                # Timeout occurred, check if file changed
                if task_manager.storage_file.exists():
                    current_mtime = os.path.getmtime(task_manager.storage_file)
                    if current_mtime != last_mtime:
                        # File changed externally, reload tasks
                        task_manager._load_tasks()
                        last_mtime = current_mtime
                continue  # Redraw screen with updated tasks

            # Handle paste events (before processing individual keys)
            if isinstance(key, tuple) and key[0] == 'PASTE':
                pasted_text = key[1]
                if mode == MODE_QUICK_ADD:
                    # Add all pasted text to input buffer at once
                    # Filter out any newlines/returns to prevent accidental submission
                    pasted_text = pasted_text.replace('\r', '').replace('\n', '')
                    input_buffer += pasted_text
                continue  # Redraw with updated buffer

            if mode == MODE_QUICK_ADD:
                # Quick-add mode: direct text input
                if key == '\r' or key == '\n':  # Enter
                    if input_buffer.strip():
                        task_manager.add_task(input_buffer.strip())
                        input_buffer = ""
                    else:
                        # No text: increment tally on current task
                        tally_count = task_manager.increment_tally()
                        if tally_count:
                            # Brief visual feedback
                            CYAN = '\033[96m'
                            RESET = '\033[0m'
                            print(f"\n{CYAN}✓ Tally: ×{tally_count}{RESET}")

                            time.sleep(0.3)  # Brief pause to show message
                elif key == '\x1b':  # ESC
                    mode = MODE_COMMAND
                    input_buffer = ""
                elif key == '\x7f':  # Backspace/Delete
                    input_buffer = input_buffer[:-1]
                # Quick shortcuts in quick-add mode (must be before printable char handler)
                elif key == 'C':  # Shift+C: Switch category
                    result = command_handler.switch_category()
                    if isinstance(result, tuple) and result[0] == 'switch_category':
                        # Reload task manager with new category
                        _, new_category, new_is_global = result
                        if new_is_global:
                            task_manager = TaskManager(category=new_category, is_global=True)
                        else:
                            task_manager = TaskManager(
                                directory=target_dir, category=new_category, is_global=False
                            )
                        command_handler = CommandHandler(task_manager, registry)
                        print(f"✓ Switched to category: {new_category or 'default'}")
                        print("\nPress Enter to continue...", end='', flush=True)
                        input()  # Wait for user acknowledgment
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'R':  # Shift+R: Register current project
                    command_handler.register_current_project()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'Z':  # Shift+Z: Switch project
                    result = command_handler.switch_project()
                    if isinstance(result, tuple) and result[0] == 'switch_project':
                        # Reload task manager with new project
                        _, project_name, project_path = result
                        target_dir = project_path
                        task_manager = TaskManager(
                            directory=target_dir, category=None, is_global=False
                        )
                        command_handler = CommandHandler(task_manager, registry)
                        print(f"✓ Switched to project: {project_name}")
                        print("\nPress Enter to continue...", end='', flush=True)
                        input()  # Wait for user acknowledgment
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'L':  # Shift+L: Toggle all categories view
                    should_toggle, new_mode = command_handler.toggle_all_categories_view(mode)
                    if should_toggle:
                        mode = new_mode
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'M':  # Shift+M: Move to project
                    command_handler.move_task_to_project()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'T':  # Shift+T: Transfer to category
                    command_handler.transfer_task_to_category()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'S':  # Shift+S: Web search
                    command_handler.web_search()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'D':  # Shift+D: Delete current task
                    command_handler.delete_current()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'W':  # Shift+W: Assign day
                    command_handler.assign_day()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'P':  # Shift+P: Set priority
                    command_handler.set_priority()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'H':  # Shift+H: Set priority to high (quick shortcut)
                    command_handler.set_priority_high()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'X':  # Shift+X: Set status
                    command_handler.set_status()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'G':  # Shift+G: Export to Google Calendar
                    command_handler.export_to_gcal()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'I':  # Shift+I: Import from Google Calendar
                    command_handler.import_from_gcal()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'K':  # Shift+K: Copy to clipboard
                    command_handler.copy_to_clipboard()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'E':  # Shift+E: Execute keyword action
                    command_handler.trigger_keyword_action()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'N':  # Shift+N: Edit task notes
                    command_handler.edit_task_notes()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'U':  # Shift+U: Open URLs
                    command_handler.open_url()
                    input_buffer = ""  # Clear buffer after operation
                elif key == '(':  # Shift+9: Ultrathink (analyze with Claude)
                    command_handler.ultrathink_task()
                    input_buffer = ""  # Clear buffer after operation
                elif key == ')':  # Shift+0: Execute analysis with Claude
                    command_handler.execute_analysis_task()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'J':  # Shift+J: Mark as agent task
                    command_handler.set_agent_task()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'B':  # Shift+B: Start priority timer
                    command_handler.start_priority_timer()
                    input_buffer = ""  # Clear buffer after operation
                elif key == '!':  # Shift+1: Fix duplicate IDs
                    command_handler.fix_duplicate_ids_interactive()
                    input_buffer = ""  # Clear buffer after operation
                elif key == '@':  # Shift+2: Read tasks aloud (TTS)
                    command_handler.read_tasks_aloud()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'A':  # Shift+A: Toggle archived display
                    show_archived = not show_archived
                    CYAN = '\033[96m'
                    RESET = '\033[0m'
                    status_msg = "Showing" if show_archived else "Hiding"
                    print(f"\n{CYAN}✓ {status_msg} archived tasks{RESET}")

                    time.sleep(0.3)  # Brief pause to show message
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'O':  # Shift+O: Toggle day sorting
                    sort_by_day = not sort_by_day
                    CYAN = '\033[96m'
                    RESET = '\033[0m'
                    status_msg = "Sorting by day" if sort_by_day else "Normal order"
                    print(f"\n{CYAN}✓ {status_msg}{RESET}")

                    time.sleep(0.3)  # Brief pause to show message
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'Y':  # Shift+Y: Toggle today filter
                    show_today_only = not show_today_only
                    CYAN = '\033[96m'
                    RESET = '\033[0m'
                    today = get_today_day_name()
                    status_msg = (
                        f"Showing only {today} tasks" if show_today_only else "Showing all tasks"
                    )
                    print(f"\n{CYAN}✓ {status_msg}{RESET}")

                    time.sleep(0.3)  # Brief pause to show message
                    input_buffer = ""  # Clear buffer after operation
                # Note: Shift+R is now used for "Register current project" (earlier in the code)
                # Refresh is available via command mode 'r' (ESC then r)
                elif key == 'V':  # Shift+V: Enter multi-select mode
                    mode = MODE_MULTISELECT
                    selected_tasks.clear()  # Clear any previous selections
                    input_buffer = ""  # Clear buffer when switching modes
                elif key == '/':  # /: Enter fuzzy search mode
                    mode = MODE_FUZZY_SEARCH
                    search_buffer = ""  # Initialize search buffer
                    filtered_tasks = []  # Will be populated on first keystroke
                    input_buffer = ""  # Clear buffer when switching modes
                elif key == 'Q':  # Shift+Q: Quit
                    print("\n\nGoodbye!")
                    running = False
                elif key == 'F':  # Shift+F: Toggle inline notes display
                    show_notes_inline = not show_notes_inline
                    CYAN = '\033[96m'
                    RESET = '\033[0m'
                    status_msg = "Showing" if show_notes_inline else "Hiding"
                    print(f"\n{CYAN}✓ {status_msg} inline notes{RESET}")

                    time.sleep(0.3)  # Brief pause to show message
                    input_buffer = ""  # Clear buffer after operation
                elif key == '?':  # ?: Toggle shortcuts display
                    show_shortcuts = not show_shortcuts
                    CYAN = '\033[96m'
                    RESET = '\033[0m'
                    status_msg = "Showing" if show_shortcuts else "Hiding"
                    print(f"\n{CYAN}✓ {status_msg} shortcuts{RESET}")

                    time.sleep(0.3)  # Brief pause to show message
                    input_buffer = ""  # Clear buffer after operation
                # Allow navigation in quick-add mode
                elif key == 'UP':
                    task_manager.set_prev_current()
                elif key == 'DOWN':
                    task_manager.set_next_current()
                elif key == 'SHIFT_UP':
                    task_manager.move_task_up()
                elif key == 'SHIFT_DOWN':
                    task_manager.move_task_down()
                # Printable characters add to input buffer (must be last)
                elif len(key) == 1 and key.isprintable():
                    input_buffer += key

            elif mode == MODE_MULTISELECT:
                # Multi-select mode: selection and bulk operations
                if key == '\x1b':  # ESC - Exit multi-select mode
                    mode = MODE_QUICK_ADD
                    selected_tasks.clear()
                elif key == ' ':  # Space - Toggle selection of current task
                    current_task = task_manager.get_current_task()
                    if current_task:
                        task_id = current_task['id']
                        if task_id in selected_tasks:
                            selected_tasks.remove(task_id)
                        else:
                            selected_tasks.add(task_id)
                elif key == 'A':  # Shift+A - Select all
                    for task in task_manager.tasks:
                        selected_tasks.add(task['id'])
                elif key == 'N':  # Shift+N - Select none
                    selected_tasks.clear()
                elif key == 'UP':
                    task_manager.set_prev_current()
                elif key == 'DOWN':
                    task_manager.set_next_current()
                elif key == 'SHIFT_UP':
                    # Navigate up and select
                    task_manager.set_prev_current()
                    current_task = task_manager.get_current_task()
                    if current_task:
                        selected_tasks.add(current_task['id'])
                elif key == 'SHIFT_DOWN':
                    # Navigate down and select
                    task_manager.set_next_current()
                    current_task = task_manager.get_current_task()
                    if current_task:
                        selected_tasks.add(current_task['id'])
                elif key == 'B':  # Shift+B - Bulk actions menu
                    if selected_tasks:
                        action = command_handler.bulk_actions_menu(selected_tasks)

                        if action == 'priority':
                            command_handler.bulk_set_priority(selected_tasks)
                            selected_tasks.clear()  # Clear selection after operation
                        elif action == 'status':
                            command_handler.bulk_set_status(selected_tasks)
                            selected_tasks.clear()
                        elif action == 'delete':
                            command_handler.bulk_delete(selected_tasks)
                            selected_tasks.clear()
                        elif action == 'archive':
                            command_handler.bulk_archive(selected_tasks)
                            selected_tasks.clear()
                        # If action is 'cancel' or None, do nothing (keep selections)

            elif mode == MODE_FUZZY_SEARCH:
                # Fuzzy search mode: filter tasks and navigate results
                if key == '\x1b':  # ESC - Exit without selecting
                    mode = MODE_QUICK_ADD
                    search_buffer = ""
                elif key == '\r' or key == '\n':  # Enter - Select current and exit
                    current_task = task_manager.get_current_task()
                    if current_task:
                        # Already set as current, just exit mode
                        mode = MODE_QUICK_ADD
                        search_buffer = ""
                elif key == '\x7f':  # Backspace/Delete
                    if search_buffer:
                        search_buffer = search_buffer[:-1]
                        # Filtering will be handled by main loop on next iteration
                elif key == '\x01':  # Ctrl+A - Toggle archived tasks in search
                    include_archived_in_search = not include_archived_in_search
                    # Re-filter with new setting will happen on next loop iteration
                elif key == 'UP':
                    # Navigate to previous task in filtered results
                    if filtered_tasks:
                        current_task = task_manager.get_current_task()
                        if current_task:
                            current_id = current_task['id']
                            # Find current in filtered list
                            filtered_ids = [t[0]['id'] for t in filtered_tasks]
                            if current_id in filtered_ids:
                                current_idx = filtered_ids.index(current_id)
                                if current_idx > 0:
                                    prev_task = filtered_tasks[current_idx - 1][0]
                                    task_manager.set_current(prev_task['id'])
                elif key == 'DOWN':
                    # Navigate to next task in filtered results
                    if filtered_tasks:
                        current_task = task_manager.get_current_task()
                        if current_task:
                            current_id = current_task['id']
                            # Find current in filtered list
                            filtered_ids = [t[0]['id'] for t in filtered_tasks]
                            if current_id in filtered_ids:
                                current_idx = filtered_ids.index(current_id)
                                if current_idx < len(filtered_tasks) - 1:
                                    next_task = filtered_tasks[current_idx + 1][0]
                                    task_manager.set_current(next_task['id'])
                # Printable characters add to search buffer
                elif len(key) == 1 and key.isprintable():
                    search_buffer += key
                    # Filtering will be handled by main loop on next iteration

            elif mode == MODE_ALL_CATEGORIES:
                # All categories view mode: minimal key handling
                if key == '\x1b' or key == 'L':  # ESC or Shift+L - Exit all categories view
                    mode = MODE_QUICK_ADD
                elif key == 'UP':
                    task_manager.set_prev_current()
                elif key == 'DOWN':
                    task_manager.set_next_current()
                # Most other keys ignored in this read-only view

            else:  # MODE_COMMAND
                # Command mode: existing command system
                if key == 'a':
                    # Switch to quick-add mode
                    mode = MODE_QUICK_ADD
                    input_buffer = ""
                elif key == 'UP':
                    task_manager.set_prev_current()
                elif key == 'DOWN':
                    task_manager.set_next_current()
                elif key == 'SHIFT_UP':
                    task_manager.move_task_up()
                elif key == 'SHIFT_DOWN':
                    task_manager.move_task_down()
                elif key == '\r' or key == '\n':
                    # Enter key in command mode: increment tally on current task
                    tally_count = task_manager.increment_tally()
                    if tally_count:
                        # Brief visual feedback
                        CYAN = '\033[96m'
                        RESET = '\033[0m'
                        print(f"\n{CYAN}✓ Tally: ×{tally_count}{RESET}")

                        time.sleep(0.3)  # Brief pause to show message
                elif key == 'A':  # Shift+A: Toggle archived display
                    show_archived = not show_archived
                    CYAN = '\033[96m'
                    RESET = '\033[0m'
                    status_msg = "Showing" if show_archived else "Hiding"
                    print(f"\n{CYAN}✓ {status_msg} archived tasks{RESET}")

                    time.sleep(0.3)  # Brief pause to show message
                elif key == 'O':  # Shift+O: Toggle day sorting
                    sort_by_day = not sort_by_day
                    CYAN = '\033[96m'
                    RESET = '\033[0m'
                    status_msg = "Sorting by day" if sort_by_day else "Normal order"
                    print(f"\n{CYAN}✓ {status_msg}{RESET}")

                    time.sleep(0.3)  # Brief pause to show message
                elif key == 'Y':  # Shift+Y: Toggle today filter
                    show_today_only = not show_today_only
                    CYAN = '\033[96m'
                    RESET = '\033[0m'
                    today = get_today_day_name()
                    status_msg = (
                        f"Showing only {today} tasks" if show_today_only else "Showing all tasks"
                    )
                    print(f"\n{CYAN}✓ {status_msg}{RESET}")

                    time.sleep(0.3)  # Brief pause to show message
                elif key:
                    running = command_handler.handle(key)

        except (KeyboardInterrupt, EOFError):
            print("\n\nGoodbye!")
            break


if __name__ == '__main__':
    main()
