"""CLI"""

from japan_fiscal.cli.main import app

__all__ = ["app"]
