"""MCPサーバー"""

from japan_fiscal.mcp.server import create_server

__all__ = ["create_server"]
