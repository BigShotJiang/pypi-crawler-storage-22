"""MCPサーバー"""

from japan_fiscal_simulator.mcp.server import create_server

__all__ = ["create_server"]
