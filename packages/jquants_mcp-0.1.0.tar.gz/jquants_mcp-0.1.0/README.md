# J-Quants MCP

[![CI](https://github.com/ajtgjmdjp/jquants-mcp/actions/workflows/ci.yml/badge.svg)](https://github.com/ajtgjmdjp/jquants-mcp/actions/workflows/ci.yml)
[![PyPI version](https://badge.fury.io/py/jquants-mcp.svg)](https://pypi.org/project/jquants-mcp/)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: Apache-2.0](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)

MCP (Model Context Protocol) server for J-Quants API - JPX official stock market data.

## Important Notice

**This tool is for personal use only.**

Data retrieved through the J-Quants API is subject to the [J-Quants Terms of Service](https://jpx-jquants.com/termsofservice). Redistribution of data is prohibited. Each user must use their own API credentials.

## Features

- **4 MCP Tools**: search_stocks, get_stock_price, get_financials, get_earnings_calendar
- **Authentication**: Environment variable based (JQUANTS_MAIL_ADDRESS, JQUANTS_PASSWORD)
- **Data**: Daily OHLCV prices, financial summaries, earnings calendar

## Installation

```bash
pip install jquants-mcp
```

## Configuration

Set your J-Quants credentials as environment variables:

```bash
export JQUANTS_MAIL_ADDRESS="your-email@example.com"
export JQUANTS_PASSWORD="your-password"
```

Or in Claude Desktop config:

```json
{
  "mcpServers": {
    "jquants": {
      "command": "uvx",
      "args": ["jquants-mcp", "serve"],
      "env": {
        "JQUANTS_MAIL_ADDRESS": "your-email@example.com",
        "JQUANTS_PASSWORD": "your-password"
      }
    }
  }
}
```

## CLI Usage

```bash
# Test API connection
jquants-mcp test

# Search for stocks
jquants-mcp search "7203"
jquants-mcp search "トヨタ"

# Get stock prices
jquants-mcp price 7203 --start-date 2024-01-01 --end-date 2024-01-31

# Get financial data
jquants-mcp financials 7203

# Get earnings calendar
jquants-mcp calendar --start-date 2024-01-01 --end-date 2024-03-31

# Start MCP server
jquants-mcp serve
```

## MCP Tools

### search_stocks
Search for stocks by code or company name.

Parameters:
- `query`: Stock code (4 digits) or company name keyword
- `limit`: Maximum results (1-50, default: 20)

### get_stock_price
Get daily OHLCV price data.

Parameters:
- `code`: 4-digit stock code
- `start_date`: Start date (YYYY-MM-DD, default: 30 days ago)
- `end_date`: End date (YYYY-MM-DD, default: today)

### get_financials
Get financial summary data.

Parameters:
- `code`: 4-digit stock code

### get_earnings_calendar
Get earnings announcement calendar.

Parameters:
- `start_date`: Start date (YYYY-MM-DD, default: today)
- `end_date`: End date (YYYY-MM-DD, default: 30 days from start)

## Terms of Service

By using this tool, you agree to the [J-Quants Terms of Service](https://jpx-jquants.com/termsofservice).

## License

Apache-2.0
