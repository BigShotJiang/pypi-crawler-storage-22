"""CLI for jquants-mcp."""

from __future__ import annotations

import asyncio
import json
import sys
from datetime import date

import click
from loguru import logger

from jquants_mcp import __version__
from jquants_mcp.client import JQuantsAuthError, JQuantsClient


@click.group()
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose logging")
def cli(verbose: bool) -> None:
    """J-Quants MCP - JPX stock data API client."""
    if verbose:
        logger.remove()
        logger.add(sys.stderr, level="DEBUG")
    else:
        logger.remove()
        logger.add(sys.stderr, level="WARNING")


@cli.command()
def version() -> None:
    """Show version information."""
    click.echo(f"jquants-mcp {__version__}")


@cli.command()
@click.argument("query")
@click.option("--limit", "-l", default=20, help="Maximum results (default: 20)")
@click.option("--json-output", "-j", is_flag=True, help="Output as JSON")
def search(query: str, limit: int, json_output: bool) -> None:
    """Search for stocks by code or name."""

    async def _search() -> None:
        client = JQuantsClient()
        try:
            result = await client.search_stocks(query, limit=limit)

            if json_output:
                click.echo(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
            else:
                click.echo(f"Search results for: {query}")
                click.echo(f"Found {result.total_count} stocks\n")

                for s in result.stocks:
                    click.echo(f"  {s.code}: {s.name}")
                    if s.sector:
                        click.echo(f"    Sector: {s.sector}")
                    if s.market:
                        click.echo(f"    Market: {s.market}")
                    click.echo()
        except JQuantsAuthError as e:
            click.echo(f"Authentication error: {e}", err=True)
            sys.exit(1)
        finally:
            await client.close()

    asyncio.run(_search())


@cli.command()
@click.argument("code")
@click.option("--start-date", "-s", help="Start date (YYYY-MM-DD)")
@click.option("--end-date", "-e", help="End date (YYYY-MM-DD)")
@click.option("--json-output", "-j", is_flag=True, help="Output as JSON")
def price(code: str, start_date: str | None, end_date: str | None, json_output: bool) -> None:
    """Get daily stock prices (OHLCV)."""

    async def _price() -> None:
        client = JQuantsClient()
        try:
            # Parse dates
            start: date | None = None
            end: date | None = None

            if start_date:
                start = date.fromisoformat(start_date)
            if end_date:
                end = date.fromisoformat(end_date)

            result = await client.get_stock_price(code, start_date=start, end_date=end)

            if json_output:
                click.echo(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
            else:
                click.echo(f"Stock prices for {code}")
                click.echo(f"Period: {result.start_date} to {result.end_date}")
                click.echo(f"Total days: {len(result.prices)}\n")

                for p in result.prices[:10]:  # Show first 10
                    click.echo(
                        f"  {p.date}: "
                        f"O={p.open:,.0f} "
                        f"H={p.high:,.0f} "
                        f"L={p.low:,.0f} "
                        f"C={p.close:,.0f} "
                        f"V={p.volume:,}"
                    )

                if len(result.prices) > 10:
                    click.echo(f"  ... and {len(result.prices) - 10} more days")
        except JQuantsAuthError as e:
            click.echo(f"Authentication error: {e}", err=True)
            sys.exit(1)
        finally:
            await client.close()

    asyncio.run(_price())


@cli.command()
@click.argument("code")
@click.option("--json-output", "-j", is_flag=True, help="Output as JSON")
def financials(code: str, json_output: bool) -> None:
    """Get financial summary data."""

    async def _financials() -> None:
        client = JQuantsClient()
        try:
            result = await client.get_financials(code)

            if json_output:
                click.echo(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
            else:
                click.echo(f"Financial data for {code}")
                click.echo(f"Available periods: {len(result.financials)}\n")

                for f in result.financials[:5]:  # Show first 5
                    click.echo(f"  FY{f.fiscal_year}:")
                    if f.revenue:
                        click.echo(f"    Revenue: {f.revenue:,.0f}M JPY")
                    if f.operating_profit:
                        click.echo(f"    Operating Profit: {f.operating_profit:,.0f}M JPY")
                    if f.eps:
                        click.echo(f"    EPS: {f.eps:.2f}")
                    if f.roe:
                        click.echo(f"    ROE: {f.roe:.2f}%")
                    click.echo()
        except JQuantsAuthError as e:
            click.echo(f"Authentication error: {e}", err=True)
            sys.exit(1)
        finally:
            await client.close()

    asyncio.run(_financials())


@cli.command()
@click.option("--start-date", "-s", help="Start date (YYYY-MM-DD)")
@click.option("--end-date", "-e", help="End date (YYYY-MM-DD)")
@click.option("--json-output", "-j", is_flag=True, help="Output as JSON")
def calendar(start_date: str | None, end_date: str | None, json_output: bool) -> None:
    """Get earnings announcement calendar."""

    async def _calendar() -> None:
        client = JQuantsClient()
        try:
            # Parse dates
            start: date | None = None
            end: date | None = None

            if start_date:
                start = date.fromisoformat(start_date)
            if end_date:
                end = date.fromisoformat(end_date)

            result = await client.get_earnings_calendar(start_date=start, end_date=end)

            if json_output:
                click.echo(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
            else:
                click.echo("Earnings Calendar")
                click.echo(f"Period: {result.start_date} to {result.end_date}")
                click.echo(f"Total events: {len(result.events)}\n")

                for e in result.events[:20]:  # Show first 20
                    click.echo(f"  {e.announcement_date}: {e.code} - {e.company_name}")
                    if e.fiscal_period:
                        click.echo(f"    Period: {e.fiscal_period}")

                if len(result.events) > 20:
                    click.echo(f"  ... and {len(result.events) - 20} more events")
        except JQuantsAuthError as e:
            click.echo(f"Authentication error: {e}", err=True)
            sys.exit(1)
        finally:
            await client.close()

    asyncio.run(_calendar())


@cli.command()
def test() -> None:
    """Test J-Quants API connection."""

    async def _test() -> None:
        client = JQuantsClient()
        try:
            click.echo("Testing J-Quants API connection...")

            if await client.test_connection():
                click.echo(click.style("✓ Connection successful!", fg="green"))
            else:
                click.echo(click.style("✗ Connection failed", fg="red"))
                sys.exit(1)
        finally:
            await client.close()

    asyncio.run(_test())


@cli.command()
@click.option("--transport", "-t", default="stdio", help="Transport type (stdio or sse)")
@click.option("--port", "-p", default=8000, help="Port for SSE transport")
def serve(transport: str, port: int) -> None:
    """Start the MCP server."""
    from jquants_mcp.server import mcp

    if transport == "sse":
        mcp.run(transport="sse", port=port)
    else:
        mcp.run()


if __name__ == "__main__":
    cli()
