"""Domain models for jquants-mcp."""

from __future__ import annotations

from datetime import date  # noqa: TC003
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class StockInfo(BaseModel):
    """Stock basic information.

    Attributes:
        code: Stock code (4-digit).
        name: Company name.
        sector: Industry sector.
        market: Market segment (e.g., "TSE Prime").
    """

    code: str = Field(..., pattern=r"^\d{4}$", description="4-digit stock code")
    name: str = Field(..., max_length=100)
    sector: str = Field(default="", max_length=100)
    market: str = Field(default="", max_length=50)

    model_config = ConfigDict(frozen=True)


class StockPrice(BaseModel):
    """Stock daily price data (OHLCV).

    Attributes:
        code: Stock code.
        date: Trading date.
        open: Opening price.
        high: High price.
        low: Low price.
        close: Closing price.
        volume: Trading volume.
    """

    code: str = Field(..., pattern=r"^\d{4}$")
    date: date
    open: float = Field(..., ge=0)
    high: float = Field(..., ge=0)
    low: float = Field(..., ge=0)
    close: float = Field(..., ge=0)
    volume: int = Field(..., ge=0)

    model_config = ConfigDict(frozen=True)


class FinancialSummary(BaseModel):
    """Financial summary data.

    Attributes:
        code: Stock code.
        fiscal_year: Fiscal year.
        revenue: Revenue (in millions JPY).
        operating_profit: Operating profit.
        net_profit: Net profit.
        eps: Earnings per share.
        bps: Book value per share.
        roe: Return on equity (%).
    """

    code: str = Field(..., pattern=r"^\d{4}$")
    fiscal_year: int
    revenue: float | None = Field(None, ge=0)
    operating_profit: float | None = Field(None)
    net_profit: float | None = Field(None)
    eps: float | None = Field(None)
    bps: float | None = Field(None)
    roe: float | None = Field(None)

    model_config = ConfigDict(frozen=True)


class EarningsEvent(BaseModel):
    """Earnings announcement event.

    Attributes:
        code: Stock code.
        company_name: Company name.
        announcement_date: Expected announcement date.
        fiscal_period: Fiscal period (e.g., "Q1", "Q2", "Q3", "FY").
    """

    code: str = Field(..., pattern=r"^\d{4}$")
    company_name: str = Field(..., max_length=100)
    announcement_date: date
    fiscal_period: str = Field(..., max_length=10)

    model_config = ConfigDict(frozen=True)


class SearchResult(BaseModel):
    """Stock search result.

    Attributes:
        query: Search query.
        stocks: List of matching stocks.
        total_count: Total number of matches.
    """

    query: str = Field(..., max_length=100)
    stocks: list[StockInfo] = Field(default_factory=list)
    total_count: int = Field(0, ge=0)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "query": self.query,
            "total_count": self.total_count,
            "stocks": [
                {
                    "code": s.code,
                    "name": s.name,
                    "sector": s.sector,
                    "market": s.market,
                }
                for s in self.stocks
            ],
        }


class PriceResult(BaseModel):
    """Stock price query result.

    Attributes:
        code: Stock code.
        start_date: Start date of the range.
        end_date: End date of the range.
        prices: List of daily prices.
    """

    code: str = Field(..., pattern=r"^\d{4}$")
    start_date: date
    end_date: date
    prices: list[StockPrice] = Field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "code": self.code,
            "start_date": self.start_date.isoformat(),
            "end_date": self.end_date.isoformat(),
            "total_days": len(self.prices),
            "prices": [
                {
                    "date": p.date.isoformat(),
                    "open": p.open,
                    "high": p.high,
                    "low": p.low,
                    "close": p.close,
                    "volume": p.volume,
                }
                for p in self.prices
            ],
        }


class FinancialsResult(BaseModel):
    """Financial data query result.

    Attributes:
        code: Stock code.
        financials: List of financial summaries.
    """

    code: str = Field(..., pattern=r"^\d{4}$")
    financials: list[FinancialSummary] = Field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "code": self.code,
            "total_periods": len(self.financials),
            "financials": [
                {
                    "fiscal_year": f.fiscal_year,
                    "revenue": f.revenue,
                    "operating_profit": f.operating_profit,
                    "net_profit": f.net_profit,
                    "eps": f.eps,
                    "bps": f.bps,
                    "roe": f.roe,
                }
                for f in self.financials
            ],
        }


class CalendarResult(BaseModel):
    """Earnings calendar query result.

    Attributes:
        start_date: Start date of the range.
        end_date: End date of the range.
        events: List of earnings events.
    """

    start_date: date
    end_date: date
    events: list[EarningsEvent] = Field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "start_date": self.start_date.isoformat(),
            "end_date": self.end_date.isoformat(),
            "total_events": len(self.events),
            "events": [
                {
                    "code": e.code,
                    "company_name": e.company_name,
                    "announcement_date": e.announcement_date.isoformat(),
                    "fiscal_period": e.fiscal_period,
                }
                for e in self.events
            ],
        }
