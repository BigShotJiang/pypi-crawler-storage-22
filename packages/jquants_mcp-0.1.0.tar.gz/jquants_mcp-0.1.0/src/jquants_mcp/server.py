"""MCP server exposing J-Quants tools to LLMs via FastMCP.

Usage with Claude Desktop (add to ``claude_desktop_config.json``)::

    {
      "mcpServers": {
        "jquants": {
          "command": "uvx",
          "args": ["jquants-mcp", "serve"],
          "env": {
            "JQUANTS_MAIL_ADDRESS": "your-email@example.com",
            "JQUANTS_PASSWORD": "your-password"
          }
        }
      }
    }

Note: Data retrieved through this API is for personal use only
and redistribution is prohibited by J-Quants Terms of Service.
https://jpx-jquants.com/termsofservice
"""

from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from datetime import date
from typing import TYPE_CHECKING, Annotated, Any

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

from fastmcp import FastMCP
from pydantic import Field

from jquants_mcp.client import JQuantsClient

# Lazily initialized client
_client: JQuantsClient | None = None
_client_lock = asyncio.Lock()


async def _get_client() -> JQuantsClient:
    """Return the shared JQuantsClient, creating it on first call."""
    global _client
    if _client is not None:
        return _client
    async with _client_lock:
        if _client is None:
            _client = JQuantsClient()
    return _client


@asynccontextmanager
async def _lifespan(server: FastMCP[dict[str, Any]]) -> AsyncIterator[dict[str, Any]]:
    """Manage JQuantsClient lifecycle."""
    global _client
    yield {}
    if _client is not None:
        await _client.close()
        _client = None


mcp = FastMCP(
    name="J-Quants",
    lifespan=_lifespan,
    instructions=(
        "J-Quants MCP server provides tools for accessing JPX stock market data "
        "through the J-Quants API.\n\n"
        "Available tools:\n"
        "- search_stocks: Find stocks by code or company name\n"
        "- get_stock_price: Get daily OHLCV price data\n"
        "- get_financials: Get financial summary data\n"
        "- get_earnings_calendar: Get earnings announcement calendar\n\n"
        "Important: This tool is for personal use only. "
        "Data redistribution is prohibited by J-Quants Terms of Service.\n"
        "https://jpx-jquants.com/termsofservice"
    ),
)


@mcp.tool()
async def search_stocks(
    query: Annotated[
        str,
        Field(
            description="Search query (stock code 4 digits or company name)",
            max_length=50,
            pattern=r"^[a-zA-Z0-9\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FAF\s]+$",
        ),
    ],
    limit: Annotated[
        int,
        Field(description="Maximum results (default: 20)", ge=1, le=50),
    ] = 20,
) -> dict[str, Any]:
    """Search for stocks by code or company name.

    Searches the J-Quants listed stocks database for matches.
    Query can be a 4-digit stock code (e.g., "7203") or
    a company name keyword (e.g., "トヨタ").

    Args:
        query: Stock code or company name keyword.
        limit: Maximum number of results to return.

    Returns:
        Dictionary with matching stocks including code, name, sector, and market.
    """
    client = await _get_client()
    result = await client.search_stocks(query, limit=limit)
    return result.to_dict()


@mcp.tool()
async def get_stock_price(
    code: Annotated[
        str,
        Field(
            description="4-digit stock code (e.g., '7203' for Toyota)",
            pattern=r"^\d{4}$",
            max_length=4,
        ),
    ],
    start_date: Annotated[
        str | None,
        Field(
            description="Start date (YYYY-MM-DD). Default: 30 days ago",
            max_length=10,
        ),
    ] = None,
    end_date: Annotated[
        str | None,
        Field(
            description="End date (YYYY-MM-DD). Default: today",
            max_length=10,
        ),
    ] = None,
) -> dict[str, Any]:
    """Get daily stock price data (OHLCV).

    Retrieves daily open, high, low, close prices and volume
    for the specified stock and date range.

    Args:
        code: 4-digit stock code.
        start_date: Start date (YYYY-MM-DD format).
        end_date: End date (YYYY-MM-DD format).

    Returns:
        Dictionary with daily price data including OHLCV values.
    """
    client = await _get_client()

    # Parse dates
    start: date | None = None
    end: date | None = None

    if start_date:
        start = date.fromisoformat(start_date)
    if end_date:
        end = date.fromisoformat(end_date)

    result = await client.get_stock_price(code, start_date=start, end_date=end)
    return result.to_dict()


@mcp.tool()
async def get_financials(
    code: Annotated[
        str,
        Field(
            description="4-digit stock code (e.g., '7203' for Toyota)",
            pattern=r"^\d{4}$",
            max_length=4,
        ),
    ],
) -> dict[str, Any]:
    """Get financial summary data for a stock.

    Retrieves financial statements including revenue, profit,
    EPS, BPS, and ROE for the specified stock.

    Args:
        code: 4-digit stock code.

    Returns:
        Dictionary with financial data by fiscal year.
    """
    client = await _get_client()
    result = await client.get_financials(code)
    return result.to_dict()


@mcp.tool()
async def get_earnings_calendar(
    start_date: Annotated[
        str | None,
        Field(
            description="Start date (YYYY-MM-DD). Default: today",
            max_length=10,
        ),
    ] = None,
    end_date: Annotated[
        str | None,
        Field(
            description="End date (YYYY-MM-DD). Default: 30 days from start",
            max_length=10,
        ),
    ] = None,
) -> dict[str, Any]:
    """Get earnings announcement calendar.

    Retrieves scheduled earnings announcement dates for companies.

    Args:
        start_date: Start date (YYYY-MM-DD format).
        end_date: End date (YYYY-MM-DD format).

    Returns:
        Dictionary with earnings events including dates and fiscal periods.
    """
    client = await _get_client()

    # Parse dates
    start: date | None = None
    end: date | None = None

    if start_date:
        start = date.fromisoformat(start_date)
    if end_date:
        end = date.fromisoformat(end_date)

    result = await client.get_earnings_calendar(start_date=start, end_date=end)
    return result.to_dict()
