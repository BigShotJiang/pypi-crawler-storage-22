"""Tests for jquants-mcp CLI."""

from datetime import date
from unittest.mock import AsyncMock, Mock, patch

from click.testing import CliRunner

from jquants_mcp import __version__
from jquants_mcp.cli import cli
from jquants_mcp.client import JQuantsAuthError


class TestCliVersion:
    """Test version command."""

    def test_version(self) -> None:
        """Test version command output."""
        runner = CliRunner()
        result = runner.invoke(cli, ["version"])

        assert result.exit_code == 0
        assert __version__ in result.output


class TestCliSearch:
    """Test search command."""

    def test_search_success(self) -> None:
        """Test successful search."""
        runner = CliRunner()

        with patch("jquants_mcp.cli.JQuantsClient") as mock_class:
            mock_client = Mock()
            mock_client.search_stocks = AsyncMock(
                return_value=Mock(
                    total_count=1,
                    stocks=[Mock(code="7203", name="トヨタ", sector="自動車", market="TSE")],
                    to_dict=lambda: {"total_count": 1},
                )
            )
            mock_client.close = AsyncMock()
            mock_class.return_value = mock_client

            result = runner.invoke(cli, ["search", "7203"])

            assert result.exit_code == 0
            assert "7203" in result.output

    def test_search_auth_error(self) -> None:
        """Test search with auth error."""
        runner = CliRunner()

        with patch("jquants_mcp.cli.JQuantsClient") as mock_class:
            mock_client = Mock()
            mock_client.search_stocks = AsyncMock(
                side_effect=JQuantsAuthError("Not authenticated")
            )
            mock_client.close = AsyncMock()
            mock_class.return_value = mock_client

            result = runner.invoke(cli, ["search", "7203"])

            assert result.exit_code == 1
            assert "Authentication error" in result.output


class TestCliPrice:
    """Test price command."""

    def test_price_success(self) -> None:
        """Test successful price fetch."""
        runner = CliRunner()

        with patch("jquants_mcp.cli.JQuantsClient") as mock_class:
            mock_client = Mock()
            mock_client.get_stock_price = AsyncMock(
                return_value=Mock(
                    code="7203",
                    start_date=date(2024, 1, 1),
                    end_date=date(2024, 1, 31),
                    prices=[
                        Mock(
                            date=date(2024, 1, 15),
                            open=2500.0,
                            high=2550.0,
                            low=2480.0,
                            close=2520.0,
                            volume=1000000,
                        )
                    ],
                    to_dict=lambda: {"code": "7203"},
                )
            )
            mock_client.close = AsyncMock()
            mock_class.return_value = mock_client

            result = runner.invoke(cli, ["price", "7203"])

            assert result.exit_code == 0
            assert "7203" in result.output


class TestCliFinancials:
    """Test financials command."""

    def test_financials_success(self) -> None:
        """Test successful financials fetch."""
        runner = CliRunner()

        with patch("jquants_mcp.cli.JQuantsClient") as mock_class:
            mock_client = Mock()
            mock_client.get_financials = AsyncMock(
                return_value=Mock(
                    code="7203",
                    financials=[
                        Mock(
                            fiscal_year=2024,
                            revenue=1000000.0,
                            operating_profit=100000.0,
                            net_profit=80000.0,
                            eps=50.0,
                            bps=500.0,
                            roe=10.0,
                        )
                    ],
                    to_dict=lambda: {"code": "7203"},
                )
            )
            mock_client.close = AsyncMock()
            mock_class.return_value = mock_client

            result = runner.invoke(cli, ["financials", "7203"])

            assert result.exit_code == 0
            assert "7203" in result.output


class TestCliCalendar:
    """Test calendar command."""

    def test_calendar_success(self) -> None:
        """Test successful calendar fetch."""
        runner = CliRunner()

        with patch("jquants_mcp.cli.JQuantsClient") as mock_class:
            mock_client = Mock()
            mock_client.get_earnings_calendar = AsyncMock(
                return_value=Mock(
                    start_date=date(2024, 1, 1),
                    end_date=date(2024, 3, 31),
                    events=[
                        Mock(
                            code="7203",
                            company_name="トヨタ",
                            announcement_date=date(2024, 5, 10),
                            fiscal_period="FY2024",
                        )
                    ],
                    to_dict=lambda: {"total_events": 1},
                )
            )
            mock_client.close = AsyncMock()
            mock_class.return_value = mock_client

            result = runner.invoke(cli, ["calendar"])

            assert result.exit_code == 0
            assert "Calendar" in result.output


class TestCliTest:
    """Test test command."""

    def test_test_success(self) -> None:
        """Test successful connection test."""
        runner = CliRunner()

        with patch("jquants_mcp.cli.JQuantsClient") as mock_class:
            mock_client = Mock()
            mock_client.test_connection = AsyncMock(return_value=True)
            mock_client.close = AsyncMock()
            mock_class.return_value = mock_client

            result = runner.invoke(cli, ["test"])

            assert result.exit_code == 0
            assert "successful" in result.output

    def test_test_failure(self) -> None:
        """Test failed connection test."""
        runner = CliRunner()

        with patch("jquants_mcp.cli.JQuantsClient") as mock_class:
            mock_client = Mock()
            mock_client.test_connection = AsyncMock(return_value=False)
            mock_client.close = AsyncMock()
            mock_class.return_value = mock_client

            result = runner.invoke(cli, ["test"])

            assert result.exit_code == 1
            assert "failed" in result.output


class TestCliJsonOutput:
    """Test JSON output option."""

    def test_search_json_output(self) -> None:
        """Test search with JSON output."""
        runner = CliRunner()

        with patch("jquants_mcp.cli.JQuantsClient") as mock_class:
            mock_client = Mock()
            mock_client.search_stocks = AsyncMock(
                return_value=Mock(to_dict=lambda: {"query": "7203", "total_count": 1})
            )
            mock_client.close = AsyncMock()
            mock_class.return_value = mock_client

            result = runner.invoke(cli, ["search", "7203", "--json-output"])

            assert result.exit_code == 0
            assert '"query"' in result.output
            assert '"total_count"' in result.output
