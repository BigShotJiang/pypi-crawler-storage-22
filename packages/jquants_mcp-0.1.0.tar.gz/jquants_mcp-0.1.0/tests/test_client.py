"""Tests for jquants-mcp client."""

from datetime import date, timedelta

import httpx
import pytest
import respx

from jquants_mcp.client import (
    JQuantsAPIError,
    JQuantsAuthError,
    JQuantsClient,
)


class TestJQuantsClientInit:
    """Test JQuantsClient initialization."""

    def test_default_init(self) -> None:
        """Test default initialization."""
        client = JQuantsClient()

        assert client.timeout == 30.0
        assert client._client is None

    def test_custom_timeout(self) -> None:
        """Test initialization with custom timeout."""
        client = JQuantsClient(timeout=60.0)

        assert client.timeout == 60.0

    def test_loads_credentials_from_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test loading credentials from environment."""
        monkeypatch.setenv("JQUANTS_MAIL_ADDRESS", "test@example.com")
        monkeypatch.setenv("JQUANTS_PASSWORD", "testpass")

        client = JQuantsClient()

        assert client._email == "test@example.com"
        assert client._password == "testpass"

    def test_missing_credentials(self) -> None:
        """Test behavior when credentials are missing."""
        client = JQuantsClient()

        # Should not raise on init, only when trying to auth
        assert client._email == ""
        assert client._password == ""


class TestJQuantsClientAuth:
    """Test JQuantsClient authentication."""

    @respx.mock
    async def test_get_refresh_token_success(self) -> None:
        """Test successful refresh token fetch."""
        client = JQuantsClient()
        client._email = "test@example.com"
        client._password = "testpass"

        # Mock token endpoint
        route = respx.post("https://api.jpx-jquants.com/v1/token/auth_user").mock(
            return_value=httpx.Response(200, json={"refreshToken": "test_refresh_token"})
        )

        token = await client._get_refresh_token()

        assert token == "test_refresh_token"
        assert route.called

    @respx.mock
    async def test_get_refresh_token_failure(self) -> None:
        """Test failed refresh token fetch."""
        client = JQuantsClient()
        client._email = "test@example.com"
        client._password = "wrongpass"

        respx.post("https://api.jpx-jquants.com/v1/token/auth_user").mock(
            return_value=httpx.Response(401, json={"message": "Unauthorized"})
        )

        with pytest.raises(JQuantsAuthError):
            await client._get_refresh_token()

    @respx.mock
    async def test_get_id_token_success(self) -> None:
        """Test successful ID token fetch."""
        client = JQuantsClient()
        client._refresh_token = "test_refresh"

        respx.post("https://api.jpx-jquants.com/v1/token/auth_refresh").mock(
            return_value=httpx.Response(200, json={"idToken": "test_id_token"})
        )

        token = await client._get_id_token()

        assert token == "test_id_token"
        assert client._id_token_expiry is not None

    def test_check_credentials_missing(self) -> None:
        """Test credential check with missing credentials."""
        client = JQuantsClient()

        with pytest.raises(JQuantsAuthError) as exc_info:
            client._check_credentials()

        assert "not configured" in str(exc_info.value)


class TestJQuantsClientSearch:
    """Test JQuantsClient search functionality."""

    @respx.mock
    async def test_search_stocks_by_code(self) -> None:
        """Test searching stocks by code."""
        from datetime import datetime

        client = JQuantsClient()

        # Mock auth
        client._id_token = "test_token"
        client._id_token_expiry = datetime.now() + timedelta(hours=1)

        # Mock listed info endpoint
        respx.get("https://api.jpx-jquants.com/v1/listed/info").mock(
            return_value=httpx.Response(
                200,
                json={
                    "info": [
                        {
                            "Code": "72030",
                            "CompanyName": "トヨタ自動車",
                            "Sector17": "自動車",
                            "MarketCodeName": "TSE Prime",
                        }
                    ]
                },
            )
        )

        result = await client.search_stocks("7203")

        assert result.total_count == 1
        assert result.stocks[0].code == "7203"
        assert result.stocks[0].name == "トヨタ自動車"

    @respx.mock
    async def test_search_stocks_by_name(self) -> None:
        """Test searching stocks by name."""
        from datetime import datetime

        client = JQuantsClient()
        client._id_token = "test_token"
        client._id_token_expiry = datetime.now() + timedelta(hours=1)

        respx.get("https://api.jpx-jquants.com/v1/listed/info").mock(
            return_value=httpx.Response(
                200,
                json={
                    "info": [
                        {"Code": "72030", "CompanyName": "トヨタ自動車"},
                        {"Code": "67580", "CompanyName": "ソニーグループ"},
                    ]
                },
            )
        )

        result = await client.search_stocks("トヨタ")

        assert result.total_count == 1
        assert result.stocks[0].name == "トヨタ自動車"

    @respx.mock
    async def test_search_stocks_limit(self) -> None:
        """Test search limit."""
        from datetime import datetime

        client = JQuantsClient()
        client._id_token = "test_token"
        client._id_token_expiry = datetime.now() + timedelta(hours=1)

        respx.get("https://api.jpx-jquants.com/v1/listed/info").mock(
            return_value=httpx.Response(
                200,
                json={
                    "info": [
                        {"Code": f"{i:05d}", "CompanyName": f"Company{i}"} for i in range(100)
                    ]
                },
            )
        )

        result = await client.search_stocks("Company", limit=10)

        assert result.total_count == 10


class TestJQuantsClientPrices:
    """Test JQuantsClient price functionality."""

    @respx.mock
    async def test_get_stock_price_success(self) -> None:
        """Test getting stock prices."""
        from datetime import datetime

        client = JQuantsClient()
        client._id_token = "test_token"
        client._id_token_expiry = datetime.now() + timedelta(hours=1)

        respx.get("https://api.jpx-jquants.com/v1/prices/daily_quotes").mock(
            return_value=httpx.Response(
                200,
                json={
                    "daily_quotes": [
                        {
                            "Date": "2024-01-15",
                            "Open": "2500.0",
                            "High": "2550.0",
                            "Low": "2480.0",
                            "Close": "2520.0",
                            "Volume": "1000000",
                        }
                    ]
                },
            )
        )

        result = await client.get_stock_price("7203")

        assert result.code == "7203"
        assert len(result.prices) == 1
        assert result.prices[0].close == 2520.0

    @respx.mock
    async def test_get_stock_price_invalid_code(self) -> None:
        """Test getting prices with invalid code."""
        client = JQuantsClient()

        with pytest.raises(ValueError, match="4 digits"):
            await client.get_stock_price("72030")

    @respx.mock
    async def test_get_stock_price_date_range(self) -> None:
        """Test getting prices with date range."""
        from datetime import datetime

        client = JQuantsClient()
        client._id_token = "test_token"
        client._id_token_expiry = datetime.now() + timedelta(hours=1)

        respx.get("https://api.jpx-jquants.com/v1/prices/daily_quotes").mock(
            return_value=httpx.Response(200, json={"daily_quotes": []})
        )

        start = date(2024, 1, 1)
        end = date(2024, 1, 31)
        result = await client.get_stock_price("7203", start_date=start, end_date=end)

        assert result.start_date == start
        assert result.end_date == end


class TestJQuantsClientFinancials:
    """Test JQuantsClient financials functionality."""

    @respx.mock
    async def test_get_financials_success(self) -> None:
        """Test getting financial data."""
        from datetime import datetime

        client = JQuantsClient()
        client._id_token = "test_token"
        client._id_token_expiry = datetime.now() + timedelta(hours=1)

        respx.get("https://api.jpx-jquants.com/v1/fins/statements").mock(
            return_value=httpx.Response(
                200,
                json={
                    "statements": [
                        {
                            "FiscalYear": "2024",
                            "NetSales": "1000000.0",
                            "OperatingProfit": "100000.0",
                            "Profit": "80000.0",
                            "EarningsPerShare": "50.0",
                            "BookValuePerShare": "500.0",
                            "ReturnOnEquity": "10.0",
                        }
                    ]
                },
            )
        )

        result = await client.get_financials("7203")

        assert result.code == "7203"
        assert len(result.financials) == 1
        assert result.financials[0].fiscal_year == 2024

    @respx.mock
    async def test_get_financials_invalid_code(self) -> None:
        """Test getting financials with invalid code."""
        client = JQuantsClient()

        with pytest.raises(ValueError, match="4 digits"):
            await client.get_financials("ABC")


class TestJQuantsClientCalendar:
    """Test JQuantsClient calendar functionality."""

    @respx.mock
    async def test_get_earnings_calendar_success(self) -> None:
        """Test getting earnings calendar."""
        from datetime import datetime

        client = JQuantsClient()
        client._id_token = "test_token"
        client._id_token_expiry = datetime.now() + timedelta(hours=1)

        respx.get("https://api.jpx-jquants.com/v1/fins/calendar").mock(
            return_value=httpx.Response(
                200,
                json={
                    "calendar": [
                        {
                            "Code": "72030",
                            "CompanyName": "トヨタ自動車",
                            "Date": "2024-05-10",
                            "FiscalPeriod": "FY2024",
                        }
                    ]
                },
            )
        )

        result = await client.get_earnings_calendar()

        assert len(result.events) == 1
        assert result.events[0].code == "7203"
        assert result.events[0].company_name == "トヨタ自動車"


class TestJQuantsClientTestConnection:
    """Test JQuantsClient test_connection."""

    @respx.mock
    async def test_test_connection_success(self) -> None:
        """Test successful connection test."""
        client = JQuantsClient()
        client._email = "test@example.com"
        client._password = "testpass"

        respx.post("https://api.jpx-jquants.com/v1/token/auth_user").mock(
            return_value=httpx.Response(200, json={"refreshToken": "test"})
        )

        result = await client.test_connection()

        assert result is True

    @respx.mock
    async def test_test_connection_failure(self) -> None:
        """Test failed connection test."""
        client = JQuantsClient()

        result = await client.test_connection()

        assert result is False


class TestJQuantsClientLifecycle:
    """Test JQuantsClient lifecycle."""

    async def test_client_close(self) -> None:
        """Test closing the client."""
        client = JQuantsClient()

        # Create client
        http_client = client._get_http_client()
        assert http_client is not None

        # Close should clean up
        await client.close()
        assert client._client is None

    async def test_client_multiple_closes(self) -> None:
        """Test that multiple closes don't raise errors."""
        client = JQuantsClient()

        await client.close()
        await client.close()  # Should not raise


class TestJQuantsExceptions:
    """Test J-Quants exceptions."""

    def test_auth_error(self) -> None:
        """Test JQuantsAuthError."""
        error = JQuantsAuthError("Test auth error")

        assert str(error) == "Test auth error"
        assert isinstance(error, Exception)

    def test_api_error(self) -> None:
        """Test JQuantsAPIError."""
        error = JQuantsAPIError("Test API error")

        assert str(error) == "Test API error"
        assert isinstance(error, Exception)
