"""Integration tests for jquants-mcp."""

import pytest

from jquants_mcp.client import JQuantsClient


class TestClientLifecycle:
    """Test client lifecycle."""

    @pytest.mark.asyncio
    async def test_client_close(self) -> None:
        """Test closing the client."""
        client = JQuantsClient()

        # Get HTTP client (creates it)
        http_client = client._get_http_client()
        assert http_client is not None

        # Close should clean up
        await client.close()
        assert client._client is None

    @pytest.mark.asyncio
    async def test_client_multiple_closes(self) -> None:
        """Test that multiple closes don't raise errors."""
        client = JQuantsClient()

        await client.close()
        await client.close()  # Should not raise


class TestClientCredentials:
    """Test client credential handling."""

    def test_credentials_from_environment(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test loading credentials from environment."""
        monkeypatch.setenv("JQUANTS_MAIL_ADDRESS", "user@test.com")
        monkeypatch.setenv("JQUANTS_PASSWORD", "secret123")

        client = JQuantsClient()

        assert client._email == "user@test.com"
        assert client._password == "secret123"

    def test_check_credentials_raises_when_missing(self) -> None:
        """Test that credential check raises when missing."""
        client = JQuantsClient()

        from jquants_mcp.client import JQuantsAuthError

        with pytest.raises(JQuantsAuthError) as exc_info:
            client._check_credentials()

        assert "not configured" in str(exc_info.value)


class TestTokenManagement:
    """Test token management."""

    @pytest.mark.asyncio
    async def test_token_caching(self) -> None:
        """Test that tokens are cached."""
        client = JQuantsClient()
        client._refresh_token = "cached_token"

        # Should return cached token without API call
        token = await client._get_refresh_token()

        assert token == "cached_token"

    @pytest.mark.asyncio
    async def test_id_token_expiry_check(self) -> None:
        """Test ID token expiry check."""
        from datetime import datetime, timedelta

        client = JQuantsClient()
        client._id_token = "valid_token"
        client._id_token_expiry = datetime.now() + timedelta(hours=1)

        # Should return cached token (not expired)
        token = await client._get_id_token()

        assert token == "valid_token"


@pytest.mark.integration
class TestRealAPI:
    """Tests that require real J-Quants API credentials."""

    @pytest.mark.asyncio
    async def test_real_connection(self) -> None:
        """Test real API connection (requires credentials)."""
        import os

        if not os.environ.get("JQUANTS_MAIL_ADDRESS"):
            pytest.skip("J-Quants credentials not configured")

        client = JQuantsClient()
        try:
            result = await client.test_connection()
            assert result is True
        finally:
            await client.close()
