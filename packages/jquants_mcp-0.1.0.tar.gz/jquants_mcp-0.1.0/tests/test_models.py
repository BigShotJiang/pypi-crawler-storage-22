"""Tests for jquants-mcp models."""

from datetime import date

import pytest
from pydantic import ValidationError

from jquants_mcp.models import (
    CalendarResult,
    EarningsEvent,
    FinancialsResult,
    FinancialSummary,
    PriceResult,
    SearchResult,
    StockInfo,
    StockPrice,
)


class TestStockInfo:
    """Test StockInfo model."""

    def test_create_valid(self) -> None:
        """Test creating valid StockInfo."""
        info = StockInfo(code="7203", name="トヨタ自動車")

        assert info.code == "7203"
        assert info.name == "トヨタ自動車"
        assert info.sector == ""
        assert info.market == ""

    def test_create_with_all_fields(self) -> None:
        """Test creating StockInfo with all fields."""
        info = StockInfo(
            code="7203",
            name="トヨタ自動車",
            sector="自動車",
            market="TSE Prime",
        )

        assert info.sector == "自動車"
        assert info.market == "TSE Prime"

    def test_invalid_code_too_short(self) -> None:
        """Test validation for short code."""
        with pytest.raises(ValidationError):
            StockInfo(code="720", name="Test")

    def test_invalid_code_too_long(self) -> None:
        """Test validation for long code."""
        with pytest.raises(ValidationError):
            StockInfo(code="72030", name="Test")

    def test_invalid_code_non_digit(self) -> None:
        """Test validation for non-digit code."""
        with pytest.raises(ValidationError):
            StockInfo(code="ABCD", name="Test")

    def test_immutable(self) -> None:
        """Test that StockInfo is immutable."""
        info = StockInfo(code="7203", name="Test")

        with pytest.raises(ValidationError):
            info.name = "Changed"


class TestStockPrice:
    """Test StockPrice model."""

    def test_create_valid(self) -> None:
        """Test creating valid StockPrice."""
        price = StockPrice(
            code="7203",
            date=date(2024, 1, 15),
            open=2500.0,
            high=2550.0,
            low=2480.0,
            close=2520.0,
            volume=1000000,
        )

        assert price.code == "7203"
        assert price.close == 2520.0

    def test_invalid_negative_price(self) -> None:
        """Test validation for negative price."""
        with pytest.raises(ValidationError):
            StockPrice(
                code="7203",
                date=date(2024, 1, 15),
                open=-100.0,
                high=100.0,
                low=100.0,
                close=100.0,
                volume=1000,
            )

    def test_invalid_negative_volume(self) -> None:
        """Test validation for negative volume."""
        with pytest.raises(ValidationError):
            StockPrice(
                code="7203",
                date=date(2024, 1, 15),
                open=100.0,
                high=100.0,
                low=100.0,
                close=100.0,
                volume=-1000,
            )


class TestFinancialSummary:
    """Test FinancialSummary model."""

    def test_create_valid(self) -> None:
        """Test creating valid FinancialSummary."""
        fin = FinancialSummary(
            code="7203",
            fiscal_year=2024,
            revenue=1000000.0,
            operating_profit=100000.0,
            net_profit=80000.0,
            eps=50.0,
            bps=500.0,
            roe=10.0,
        )

        assert fin.code == "7203"
        assert fin.fiscal_year == 2024
        assert fin.revenue == 1000000.0

    def test_optional_fields_none(self) -> None:
        """Test creating with optional fields as None."""
        fin = FinancialSummary(code="7203", fiscal_year=2024)

        assert fin.revenue is None
        assert fin.eps is None

    def test_invalid_negative_revenue(self) -> None:
        """Test validation for negative revenue."""
        with pytest.raises(ValidationError):
            FinancialSummary(code="7203", fiscal_year=2024, revenue=-1000.0)


class TestEarningsEvent:
    """Test EarningsEvent model."""

    def test_create_valid(self) -> None:
        """Test creating valid EarningsEvent."""
        event = EarningsEvent(
            code="7203",
            company_name="トヨタ自動車",
            announcement_date=date(2024, 5, 10),
            fiscal_period="FY2024",
        )

        assert event.code == "7203"
        assert event.fiscal_period == "FY2024"


class TestSearchResult:
    """Test SearchResult model."""

    def test_create_empty(self) -> None:
        """Test creating empty SearchResult."""
        result = SearchResult(query="test")

        assert result.query == "test"
        assert result.stocks == []
        assert result.total_count == 0

    def test_create_with_stocks(self) -> None:
        """Test creating SearchResult with stocks."""
        stocks = [StockInfo(code="7203", name="トヨタ")]
        result = SearchResult(query="トヨタ", stocks=stocks, total_count=1)

        assert result.total_count == 1
        assert len(result.stocks) == 1

    def test_to_dict(self) -> None:
        """Test conversion to dictionary."""
        stocks = [StockInfo(code="7203", name="トヨタ", sector="自動車")]
        result = SearchResult(query="トヨタ", stocks=stocks, total_count=1)

        data = result.to_dict()

        assert data["query"] == "トヨタ"
        assert data["total_count"] == 1
        assert len(data["stocks"]) == 1
        assert data["stocks"][0]["code"] == "7203"


class TestPriceResult:
    """Test PriceResult model."""

    def test_create_empty(self) -> None:
        """Test creating empty PriceResult."""
        result = PriceResult(
            code="7203",
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
        )

        assert result.code == "7203"
        assert result.prices == []

    def test_to_dict(self) -> None:
        """Test conversion to dictionary."""
        prices = [
            StockPrice(
                code="7203",
                date=date(2024, 1, 15),
                open=2500.0,
                high=2550.0,
                low=2480.0,
                close=2520.0,
                volume=1000000,
            )
        ]
        result = PriceResult(
            code="7203",
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
            prices=prices,
        )

        data = result.to_dict()

        assert data["code"] == "7203"
        assert data["total_days"] == 1
        assert data["prices"][0]["close"] == 2520.0


class TestFinancialsResult:
    """Test FinancialsResult model."""

    def test_create_empty(self) -> None:
        """Test creating empty FinancialsResult."""
        result = FinancialsResult(code="7203")

        assert result.code == "7203"
        assert result.financials == []

    def test_to_dict(self) -> None:
        """Test conversion to dictionary."""
        financials = [FinancialSummary(code="7203", fiscal_year=2024, revenue=1000000.0)]
        result = FinancialsResult(code="7203", financials=financials)

        data = result.to_dict()

        assert data["code"] == "7203"
        assert data["total_periods"] == 1
        assert data["financials"][0]["fiscal_year"] == 2024


class TestCalendarResult:
    """Test CalendarResult model."""

    def test_create_empty(self) -> None:
        """Test creating empty CalendarResult."""
        result = CalendarResult(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 3, 31),
        )

        assert result.events == []

    def test_to_dict(self) -> None:
        """Test conversion to dictionary."""
        events = [
            EarningsEvent(
                code="7203",
                company_name="トヨタ",
                announcement_date=date(2024, 5, 10),
                fiscal_period="FY2024",
            )
        ]
        result = CalendarResult(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 3, 31),
            events=events,
        )

        data = result.to_dict()

        assert data["total_events"] == 1
        assert data["events"][0]["code"] == "7203"
