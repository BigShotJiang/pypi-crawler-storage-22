"""Tests for jquants-mcp server."""

from datetime import date
from unittest.mock import AsyncMock, Mock, patch

import pytest

import jquants_mcp.server as server_module
from jquants_mcp.models import (
    CalendarResult,
    EarningsEvent,
    FinancialsResult,
    FinancialSummary,
    PriceResult,
    SearchResult,
    StockInfo,
    StockPrice,
)


class TestServerTools:
    """Test MCP server tools."""

    @pytest.mark.asyncio
    async def test_search_stocks_logic(self) -> None:
        """Test search_stocks tool logic."""
        client = Mock()
        client.search_stocks = AsyncMock(
            return_value=SearchResult(
                query="7203",
                stocks=[StockInfo(code="7203", name="トヨタ")],
                total_count=1,
            )
        )

        result = await client.search_stocks("7203", limit=20)

        assert result.total_count == 1
        assert result.stocks[0].code == "7203"

    @pytest.mark.asyncio
    async def test_get_stock_price_logic(self) -> None:
        """Test get_stock_price tool logic."""
        client = Mock()
        client.get_stock_price = AsyncMock(
            return_value=PriceResult(
                code="7203",
                start_date=date(2024, 1, 1),
                end_date=date(2024, 1, 31),
                prices=[
                    StockPrice(
                        code="7203",
                        date=date(2024, 1, 15),
                        open=2500.0,
                        high=2550.0,
                        low=2480.0,
                        close=2520.0,
                        volume=1000000,
                    )
                ],
            )
        )

        result = await client.get_stock_price("7203")

        assert result.code == "7203"
        assert len(result.prices) == 1
        assert result.prices[0].close == 2520.0

    @pytest.mark.asyncio
    async def test_get_financials_logic(self) -> None:
        """Test get_financials tool logic."""
        client = Mock()
        client.get_financials = AsyncMock(
            return_value=FinancialsResult(
                code="7203",
                financials=[FinancialSummary(code="7203", fiscal_year=2024, revenue=1000000.0)],
            )
        )

        result = await client.get_financials("7203")

        assert result.code == "7203"
        assert len(result.financials) == 1

    @pytest.mark.asyncio
    async def test_get_earnings_calendar_logic(self) -> None:
        """Test get_earnings_calendar tool logic."""
        client = Mock()
        client.get_earnings_calendar = AsyncMock(
            return_value=CalendarResult(
                start_date=date(2024, 1, 1),
                end_date=date(2024, 3, 31),
                events=[
                    EarningsEvent(
                        code="7203",
                        company_name="トヨタ",
                        announcement_date=date(2024, 5, 10),
                        fiscal_period="FY2024",
                    )
                ],
            )
        )

        result = await client.get_earnings_calendar()

        assert len(result.events) == 1
        assert result.events[0].code == "7203"


class TestServerHelpers:
    """Test server helper functions."""

    @pytest.mark.asyncio
    async def test_get_client_creates_client(self) -> None:
        """Test that _get_client creates a client."""
        with (
            patch.object(server_module, "_client", None),
            patch("jquants_mcp.server.JQuantsClient") as mock_class,
        ):
            mock_instance = Mock()
            mock_class.return_value = mock_instance

            client = await server_module._get_client()

            assert client is mock_instance

    @pytest.mark.asyncio
    async def test_get_client_returns_existing(self) -> None:
        """Test that _get_client returns existing client."""
        existing = Mock()
        with patch.object(server_module, "_client", existing):
            client = await server_module._get_client()

            assert client is existing


class TestServerInputValidation:
    """Test server input validation patterns."""

    def test_valid_stock_code_pattern(self) -> None:
        """Test valid stock code pattern."""
        import re

        pattern = r"^\d{4}$"

        assert re.match(pattern, "7203")
        assert re.match(pattern, "0001")
        assert not re.match(pattern, "72030")
        assert not re.match(pattern, "ABC")
        assert not re.match(pattern, "720")

    def test_valid_date_pattern(self) -> None:
        """Test valid date pattern."""
        import re

        pattern = r"^\d{4}-\d{2}-\d{2}$"

        assert re.match(pattern, "2024-01-15")
        assert not re.match(pattern, "2024/01/15")
        assert not re.match(pattern, "24-01-15")


class TestServerResultConversion:
    """Test server result conversion."""

    def test_search_result_to_dict(self) -> None:
        """Test search result conversion to dict."""
        result = SearchResult(
            query="test",
            stocks=[StockInfo(code="7203", name="トヨタ", sector="自動車")],
            total_count=1,
        )

        data = result.to_dict()

        assert "query" in data
        assert "total_count" in data
        assert "stocks" in data
        assert data["total_count"] == 1

    def test_price_result_to_dict(self) -> None:
        """Test price result conversion to dict."""
        result = PriceResult(
            code="7203",
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
            prices=[
                StockPrice(
                    code="7203",
                    date=date(2024, 1, 15),
                    open=2500.0,
                    high=2550.0,
                    low=2480.0,
                    close=2520.0,
                    volume=1000000,
                )
            ],
        )

        data = result.to_dict()

        assert data["code"] == "7203"
        assert data["total_days"] == 1
        assert "prices" in data

    def test_financials_result_to_dict(self) -> None:
        """Test financials result conversion to dict."""
        result = FinancialsResult(
            code="7203",
            financials=[FinancialSummary(code="7203", fiscal_year=2024, revenue=1000000.0)],
        )

        data = result.to_dict()

        assert data["code"] == "7203"
        assert data["total_periods"] == 1
        assert "financials" in data

    def test_calendar_result_to_dict(self) -> None:
        """Test calendar result conversion to dict."""
        result = CalendarResult(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 3, 31),
            events=[
                EarningsEvent(
                    code="7203",
                    company_name="トヨタ",
                    announcement_date=date(2024, 5, 10),
                    fiscal_period="FY2024",
                )
            ],
        )

        data = result.to_dict()

        assert "start_date" in data
        assert "end_date" in data
        assert data["total_events"] == 1
        assert "events" in data
