"""J-Quants API client for jquants-mcp."""

from __future__ import annotations

import asyncio
import os
import re
from datetime import date, datetime, timedelta
from typing import Any, cast

import httpx
from pydantic import ValidationError

from jquants_mcp.models import (
    CalendarResult,
    EarningsEvent,
    FinancialsResult,
    FinancialSummary,
    PriceResult,
    SearchResult,
    StockInfo,
    StockPrice,
)


class JQuantsAuthError(Exception):
    """Authentication error for J-Quants API."""

    pass


class JQuantsAPIError(Exception):
    """API error for J-Quants."""

    pass


# Retryable HTTP status codes
_RETRYABLE_STATUS = {429, 500, 502, 503, 504}
# Non-retryable HTTP status codes — raise immediately
_NON_RETRYABLE_STATUS = {401, 403, 404}
_MAX_RETRIES = 3
_DATE_PATTERN = re.compile(r"^\d{4}-\d{2}-\d{2}$")


class JQuantsClient:
    """Client for J-Quants API.

    This client uses the J-Quants API (v2.0) to fetch stock data.
    Authentication requires JQUANTS_MAIL_ADDRESS and JQUANTS_PASSWORD
    environment variables.

    Note: Data retrieved through this API is for personal use only
    and redistribution is prohibited by J-Quants Terms of Service.
    """

    BASE_URL = "https://api.jpx-jquants.com/v1"

    def __init__(self, timeout: float = 30.0) -> None:
        """Initialize the client.

        Args:
            timeout: HTTP request timeout in seconds.
        """
        self.timeout = timeout
        self._client: httpx.AsyncClient | None = None
        self._refresh_token: str | None = None
        self._id_token: str | None = None
        self._id_token_expiry: datetime | None = None

        # Load credentials from environment
        self._email = os.environ.get("JQUANTS_MAIL_ADDRESS", "")
        self._password = os.environ.get("JQUANTS_PASSWORD", "")

    async def __aenter__(self) -> JQuantsClient:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    def _get_http_client(self) -> httpx.AsyncClient:
        """Get or create the HTTP client."""
        if self._client is None:
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(self.timeout),
                base_url=self.BASE_URL,
            )
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    def _check_credentials(self) -> None:
        """Check if credentials are configured."""
        if not self._email or not self._password:
            raise JQuantsAuthError(
                "J-Quants credentials not configured. "
                "Set JQUANTS_MAIL_ADDRESS and JQUANTS_PASSWORD environment variables."
            )

    async def _get_refresh_token(self) -> str:
        """Get or fetch refresh token."""
        if self._refresh_token:
            return self._refresh_token

        self._check_credentials()
        client = self._get_http_client()

        try:
            resp = await client.post(
                "/token/auth_user",
                json={"mailaddress": self._email, "password": self._password},
            )
            resp.raise_for_status()
            data = resp.json()
            self._refresh_token = data.get("refreshToken", "")
            if not self._refresh_token:
                raise JQuantsAuthError("Failed to obtain refresh token")
            return self._refresh_token
        except httpx.HTTPStatusError as e:
            raise JQuantsAuthError(f"Authentication failed: {e}") from e

    async def _get_id_token(self) -> str:
        """Get or fetch ID token."""
        # Check if token is still valid (with 5 min buffer)
        if (
            self._id_token
            and self._id_token_expiry
            and datetime.now() < self._id_token_expiry - timedelta(minutes=5)
        ):
            return self._id_token

        refresh_token = await self._get_refresh_token()
        client = self._get_http_client()

        try:
            resp = await client.post(
                "/token/auth_refresh",
                json={"refreshToken": refresh_token},
            )
            resp.raise_for_status()
            data = resp.json()
            self._id_token = data.get("idToken", "")
            if not self._id_token:
                raise JQuantsAuthError("Failed to obtain ID token")
            # ID token expires in 24 hours
            self._id_token_expiry = datetime.now() + timedelta(hours=24)
            return self._id_token
        except httpx.HTTPStatusError as e:
            raise JQuantsAuthError(f"Token refresh failed: {e}") from e

    async def _api_request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        """Make authenticated API request with retry.

        Args:
            method: HTTP method.
            path: API path.
            **kwargs: Additional request arguments.

        Returns:
            Response JSON data.
        """
        id_token = await self._get_id_token()
        client = self._get_http_client()

        headers = kwargs.pop("headers", {})
        headers["Authorization"] = f"Bearer {id_token}"

        last_exc: BaseException | None = None
        for attempt in range(_MAX_RETRIES):
            try:
                resp = await client.request(method, path, headers=headers, **kwargs)
                if resp.status_code in _NON_RETRYABLE_STATUS:
                    raise JQuantsAPIError(f"HTTP {resp.status_code} for {path}: non-retryable")
                if resp.status_code in _RETRYABLE_STATUS:
                    last_exc = JQuantsAPIError(f"HTTP {resp.status_code} for {path}")
                else:
                    resp.raise_for_status()
                    return cast("dict[str, Any]", resp.json())
            except httpx.TimeoutException as e:
                last_exc = JQuantsAPIError(f"Request timeout for {path}: {e}")
            except httpx.HTTPStatusError as e:
                raise JQuantsAPIError(f"API request failed: {e}") from e
            except JQuantsAPIError:
                raise

            if attempt < _MAX_RETRIES - 1:
                delay = 2**attempt
                await asyncio.sleep(delay)

        raise last_exc  # type: ignore[misc]

    async def search_stocks(
        self,
        query: str,
        limit: int = 20,
    ) -> SearchResult:
        """Search for stocks by code or name.

        Args:
            query: Search query (stock code or company name).
            limit: Maximum results.

        Returns:
            Search results.
        """
        # Fetch listed stocks from J-Quants
        data = await self._api_request("GET", "/listed/info")

        stocks: list[StockInfo] = []
        query_lower = query.lower()

        for item in data.get("info", []):
            try:
                code = item.get("Code", "")
                name = item.get("CompanyName", "")
                code_4digit = code[:4]  # Remove market suffix

                # Match by code (4-digit) or name (partial)
                if query == code_4digit or query_lower in name.lower():
                    stocks.append(
                        StockInfo(
                            code=code_4digit,
                            name=name,
                            sector=item.get("Sector17", ""),
                            market=item.get("MarketCodeName", ""),
                        )
                    )

                    if len(stocks) >= limit:
                        break
            except ValidationError:
                continue

        return SearchResult(
            query=query,
            stocks=stocks,
            total_count=len(stocks),
        )

    async def get_stock_price(
        self,
        code: str,
        start_date: date | None = None,
        end_date: date | None = None,
    ) -> PriceResult:
        """Get daily stock prices (OHLCV).

        Args:
            code: 4-digit stock code.
            start_date: Start date (default: 30 days ago).
            end_date: End date (default: today).

        Returns:
            Price data.
        """
        if end_date is None:
            end_date = date.today()
        if start_date is None:
            start_date = end_date - timedelta(days=30)

        # Validate code format
        if not code.isdigit() or len(code) != 4:
            raise ValueError("Stock code must be 4 digits")

        params = {
            "code": code,
            "from": start_date.strftime("%Y-%m-%d"),
            "to": end_date.strftime("%Y-%m-%d"),
        }

        data = await self._api_request("GET", "/prices/daily_quotes", params=params)

        prices: list[StockPrice] = []
        for item in data.get("daily_quotes", []):
            try:
                prices.append(
                    StockPrice(
                        code=code,
                        date=datetime.strptime(item.get("Date", ""), "%Y-%m-%d").date(),
                        open=float(item.get("Open", 0)),
                        high=float(item.get("High", 0)),
                        low=float(item.get("Low", 0)),
                        close=float(item.get("Close", 0)),
                        volume=int(item.get("Volume", 0)),
                    )
                )
            except (ValidationError, ValueError):
                continue

        # Sort by date
        prices.sort(key=lambda p: p.date)

        return PriceResult(
            code=code,
            start_date=start_date,
            end_date=end_date,
            prices=prices,
        )

    async def get_financials(
        self,
        code: str,
    ) -> FinancialsResult:
        """Get financial summary data.

        Args:
            code: 4-digit stock code.

        Returns:
            Financial data.
        """
        if not code.isdigit() or len(code) != 4:
            raise ValueError("Stock code must be 4 digits")

        # Note: J-Quants financial data endpoint
        params = {"code": code}
        data = await self._api_request("GET", "/fins/statements", params=params)

        financials: list[FinancialSummary] = []
        for item in data.get("statements", []):
            try:
                ns = item.get("NetSales")
                op = item.get("OperatingProfit")
                profit = item.get("Profit")
                eps = item.get("EarningsPerShare")
                bps = item.get("BookValuePerShare")
                roe = item.get("ReturnOnEquity")
                financials.append(
                    FinancialSummary(
                        code=code,
                        fiscal_year=int(item.get("FiscalYear", 0)),
                        revenue=float(ns) if ns else None,
                        operating_profit=float(op) if op else None,
                        net_profit=float(profit) if profit else None,
                        eps=float(eps) if eps else None,
                        bps=float(bps) if bps else None,
                        roe=float(roe) if roe else None,
                    )
                )
            except (ValidationError, ValueError):
                continue

        # Sort by fiscal year descending
        financials.sort(key=lambda f: f.fiscal_year, reverse=True)

        return FinancialsResult(
            code=code,
            financials=financials,
        )

    async def get_earnings_calendar(
        self,
        start_date: date | None = None,
        end_date: date | None = None,
    ) -> CalendarResult:
        """Get earnings announcement calendar.

        Args:
            start_date: Start date.
            end_date: End date.

        Returns:
            Calendar data.
        """
        if end_date is None:
            end_date = date.today() + timedelta(days=30)
        if start_date is None:
            start_date = date.today()

        # Fetch from J-Quants calendar endpoint
        params = {
            "from": start_date.strftime("%Y-%m-%d"),
            "to": end_date.strftime("%Y-%m-%d"),
        }

        data = await self._api_request("GET", "/fins/calendar", params=params)

        events: list[EarningsEvent] = []
        for item in data.get("calendar", []):
            try:
                events.append(
                    EarningsEvent(
                        code=item.get("Code", "")[:4],
                        company_name=item.get("CompanyName", ""),
                        announcement_date=datetime.strptime(
                            item.get("Date", ""), "%Y-%m-%d"
                        ).date(),
                        fiscal_period=item.get("FiscalPeriod", ""),
                    )
                )
            except (ValidationError, ValueError):
                continue

        # Sort by date
        events.sort(key=lambda e: e.announcement_date)

        return CalendarResult(
            start_date=start_date,
            end_date=end_date,
            events=events,
        )

    async def test_connection(self) -> bool:
        """Test API connection.

        Returns:
            True if connection successful.
        """
        try:
            self._check_credentials()
            await self._get_refresh_token()
            return True
        except JQuantsAuthError:
            return False
