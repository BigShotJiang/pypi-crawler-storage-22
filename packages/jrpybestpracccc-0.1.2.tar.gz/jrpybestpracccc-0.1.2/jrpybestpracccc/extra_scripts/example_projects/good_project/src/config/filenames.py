"""Commonly used filenames and filepaths"""

DATA_PATH = "data"
