import matplotlib.pyplot as plt
import plotly.graph_objects as go
import plotly.io as pio
from cycler import cycler

Colors = {
    "vibrant purple": "#7041FF",
    "orange": "#FFAC00",
    "aubergine": "#280049",
    "lavender": "#8C57CC",
    "purple 4": "#AB6B99",
    "purple 5": "#CA7880",
    "red": "#FF2200",
    "yellow": "#FFFF4B",
    "green": "#A2D800",
    "forest green": "#1A5F31",
    "sea green": "#369992",
    "sky blue": "#AEC5EB",
}

# set default colours to use
plt.rcParams["axes.prop_cycle"] = cycler(color=list(Colors.values()))

# style plots to match CCC branding
plt.rcParams["figure.figsize"] = [6, 3]
plt.rcParams["figure.constrained_layout.use"] = True
plt.rcParams["figure.dpi"] = 120
plt.rcParams["axes.grid"] = True
plt.rcParams["axes.grid.axis"] = "y"
plt.rcParams["axes.labelweight"] = "bold"
plt.rcParams["axes.titlecolor"] = Colors["vibrant purple"]
plt.rcParams["axes.titleweight"] = "bold"
plt.rcParams["axes.labelcolor"] = Colors["vibrant purple"]
plt.rcParams["axes.edgecolor"] = Colors["vibrant purple"]
plt.rcParams["axes.spines.left"] = False
plt.rcParams["axes.spines.right"] = False
plt.rcParams["axes.spines.top"] = False
plt.rcParams["grid.linewidth"] = 0.4
plt.rcParams["grid.color"] = "silver"
plt.rcParams["xtick.color"] = Colors["vibrant purple"]
plt.rcParams["ytick.color"] = Colors["vibrant purple"]
plt.rcParams["ytick.left"] = False
plt.rcParams["legend.frameon"] = False
plt.rcParams["legend.labelcolor"] = Colors["vibrant purple"]
plt.rcParams["font.family"] = "century gothic"

SCENARIO_COLORS = {
    "Baseline": Colors["orange"],
    "Pathway": Colors["vibrant purple"],
    "Historical": Colors["aubergine"],
}

# Plotly template
ccc_template = go.layout.Template(
    layout=go.Layout(
        width=720,
        height=472,
        
        font=dict(
            family="Century Gothic, sans-serif",
            size=12,
            color=Colors["vibrant purple"]
        ),
        
        title=dict(
            font=dict(
                family="Century Gothic, sans-serif",
                size=14,
                color=Colors["vibrant purple"]
            ),
            x=0.5,
            xanchor="center"
        ),
        
        plot_bgcolor="white",
        paper_bgcolor="white",
        
        xaxis=dict(
            showgrid=False,
            showline=True,
            linewidth=1,
            linecolor=Colors["vibrant purple"],
            tickcolor=Colors["vibrant purple"],
            title_font=dict(
                family="Century Gothic, sans-serif",
                size=14,
                color=Colors["vibrant purple"]
            ),
            tickfont=dict(
                family="Century Gothic, sans-serif",
                size=12,
                color=Colors["vibrant purple"]
            ),
            mirror=False,
            zeroline=False
        ),
        
        yaxis=dict(
            showgrid=True,
            gridwidth=0.4,
            gridcolor="silver",
            showline=False,
            zeroline=False,
            tickcolor=Colors["vibrant purple"],
            ticks="",
            title_font=dict(
                family="Century Gothic, sans-serif",
                size=14,
                color=Colors["vibrant purple"]
            ),
            tickfont=dict(
                family="Century Gothic, sans-serif",
                size=12,
                color=Colors["vibrant purple"]
            )
        ),
        
        legend=dict(
            bgcolor="rgba(0,0,0,0)",
            bordercolor="rgba(0,0,0,0)",
            font=dict(
                family="Century Gothic, sans-serif",
                color=Colors["vibrant purple"]
            ),
            orientation="v",
            yanchor="top",
            y=1,
            xanchor="left",
            x=0.01
        ),
        
        colorway=list(Colors.values()),
        
        hoverlabel=dict(
            bgcolor="white",
            font_size=12,
            font_family="Century Gothic, sans-serif",
            bordercolor=Colors["vibrant purple"]
        ),
        
        margin=dict(l=60, r=20, t=60, b=50)
    )
)

# Register and set as default
pio.templates["ccc"] = ccc_template
pio.templates.default = "ccc"
