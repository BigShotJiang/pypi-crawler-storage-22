"""Functions for dealing with data preprocessing, including cleaning, scaling and
one-hot encoding
"""

import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from ..config.filenames import DATA_PATH


def clean_data(data):
    """Remove missing values and clean up variable names

    :parameters:
    data: pd.DataFrame
      Pandas DataFrame with the data to be cleaned

    :returns:
    pd.DataFrame object with the tidy data
    """
    data.dropna(inplace=True)
    data = data.clean_names()
    return data


def join_on_archetypes(
    df: pd.DataFrame, archetype_df: pd.DataFrame
) -> pd.DataFrame:

    """
    This function handles the joining of the two capex datasets with the
    archetypes dataset.

    Args
    ------
    df: the capex DataFrame to join with.
    archetype_df: the archetype DataFrame.

    Returns
    ------

    df: the new DataFrame with the archetype data joined on.

    """

    df = df.merge(archetype_df,
                  left_on="Heating system",
                  right_on="Heating system",
                  how="inner")

    return df


def get_size_scaled_capex(capex_by_power_df: pd.DataFrame) -> pd.DataFrame:
    """
    This function handles the scaling of the capex amounts by
    heating size for the capex by power data.

    Args
    -----
    capex_by_power_df: the capex by power DataFrame.

    Returns
    ------
    capex_by_power_df: the scaled capex DataFrame.
    """

    year_cols = [
        col for col in capex_by_power_df.columns if col.startswith("20")
    ]

    capex_by_power_df[year_cols] = (
        capex_by_power_df[year_cols]
        .multiply(capex_by_power_df["Heating system size"], axis=0)
    )

    return capex_by_power_df


def concatenate_dfs(
    capex_by_power_df: pd.DataFrame,
    fixed_capex_df: pd.DataFrame,
) -> pd.DataFrame:

    """
    Concatenates the capex by power DataFrame and the fixed capex DataFrame
    into a single DataFrame.

    Args
    -----
    capex_by_power_df: DataFrame containing capex data scaled by power.
    fixed_capex_df: DataFrame containing fixed capex data.

    Returns
    ------
    all_capex_df: The concatenated DataFrame containing all capex data.
    """

    all_capex_df = pd.concat([capex_by_power_df, fixed_capex_df])

    return all_capex_df


def adjust_prices(all_capex_df: pd.DataFrame) -> pd.DataFrame:

    """
    Adjusts the capex values in the DataFrame for each year by multiplying
    them with the corresponding price index.

    Args
    -----
    all_capex_df: DataFrame containing capex data with year columns and a
    'Price index' column.

    Returns
    ------
    all_capex_df: DataFrame with year columns adjusted by the price index.
    """

    year_cols = [col for col in all_capex_df.columns if col.startswith("20")]
    all_capex_df[year_cols] = (
        all_capex_df[year_cols]
        .multiply(all_capex_df["Price index"], axis=0)
    )

    return all_capex_df


def get_grouped_total_capex(all_capex_df: pd.DataFrame) -> pd.DataFrame:

    """
    Groups the capex DataFrame by 'Constrained archetype number' and sums the
    capex values for each year.

    Args
    -----
    all_capex_df: DataFrame containing capex data with year columns and a
    'Constrained archetype number' column.

    Returns
    ------
    all_capex_df: DataFrame with summed capex values for each 'Constrained
    archetype number' and year.
    """

    year_cols = [col for col in all_capex_df.columns if col.startswith("20")]
    agg_dict = {
        col: 'first' for col in all_capex_df.columns if col not in year_cols
    }
    agg_dict.update({col: 'sum' for col in year_cols})

    summed_capex_df = (
        all_capex_df
        .groupby(by="Constrained archetype number", as_index=False)
        .agg(agg_dict)
    )

    return summed_capex_df


def drop_and_add_columns(
    all_capex_df: pd.DataFrame,
    columns_to_drop=["Cost type variant", "Assumptions", "Heating system"],
) -> pd.DataFrame:

    """
    Drops specified columns from the DataFrame, removes duplicate rows, and
    adds two new columns.

    -----
    all_capex_df: DataFrame from which columns will be dropped.
    columns_to_drop: List of column names to be dropped from the DataFrame
    (default: ["Cost type variant", "Assumptions", "Heating system"]).

    Returns
    ------
    all_capex_df: DataFrame with specified columns dropped, new columns added,
    and duplicates removed.
    """

    all_capex_df = all_capex_df.drop(columns=columns_to_drop)

    all_capex_df["Variable unit"] = "£"
    all_capex_df["Data name"] = "Baseline capex per home by renewal year"

    return all_capex_df


def create_output(
    all_capex_df: pd.DataFrame,
    output_filename="Baseline heating system capex.csv",
    output_path=DATA_PATH,
):

    """
    Writes the provided DataFrame to a CSV file at the specified output path.

    Args
    -----
    all_capex_df: DataFrame to be written to CSV.
    output_filename: Name of the output CSV file (default: "Baseline heating
    system capex.csv").
    output_path: Path where the CSV file will be saved (default: DATA_PATH).

    Returns
    ------
    None
    """

    all_capex_df.to_csv(output_path/output_filename, index=False)

    return


def create_long_format(df: pd.DataFrame, index: int = -31):
    """
    Converts an input DataFrame into long format

    parameters
    ----------
    df: pd.DataFrame
      The data should initially have capex columns for the years
      "2020" to "2050". These typically span index -31 to the end of
      the DataFrame.
    index: int (default -31)
      Index of the "2020" capex column

    returns
    -------
    pd.DataFrame
      Long-format version of the data with a "Year" column and
      "Capex" column
    """
    columns = list(df.columns)
    return df.melt(
        id_vars=columns[:index],
        value_vars=columns[index:],
        var_name="Year",
        value_name="Capex",
    )


def preprocess(
    archetype_df: pd.DataFrame,
    fixed_capex_df: pd.DataFrame,
    capex_by_power_df: pd.DataFrame,
    long_format: bool = False,
    index: int = -31,
) -> pd.DataFrame:
    """
    Run all of the preprocessing steps on the input data

    Args
    -----
    archetype_df: The archetype DataFrame.
    fixed_capex_df: The fixed capex DataFrame.
    capex_by_power_df: The capex by power.
    long_format: If True, convert the output data into long
      format with "Year" and "Capex" columns (False by default)
    index: The index of the "2020" column in the preprocessed
      data (-31 by default)

    Returns
    ------
    pd.DataFrame
      Preprocessed DataFrame
    """

    fixed_capex_df = join_on_archetypes(
        df=fixed_capex_df, archetype_df=archetype_df
    )
    capex_by_power_df = join_on_archetypes(
        df=capex_by_power_df, archetype_df=archetype_df
    )

    capex_by_power_df = get_size_scaled_capex(
        capex_by_power_df=capex_by_power_df
    )

    all_capex_df = concatenate_dfs(
        capex_by_power_df=capex_by_power_df,
        fixed_capex_df=fixed_capex_df,
    )
    all_capex_df = get_grouped_total_capex(all_capex_df=all_capex_df)
    all_capex_df = drop_and_add_columns(all_capex_df=all_capex_df)

    if long_format:
        return create_long_format(
            df=all_capex_df,
            index=index,
        )

    return all_capex_df


def calibrate_transformer(
    data: pd.DataFrame,
    numerical_features: list,
    categorical_features: list,
):
    """Calibrate a data transformer using the input data

    :parameters:
    data: pd.DataFrame
      Input data used for calibrating the transformer
    numerical_features: list
      List of the numerical variables to be transformed
    categorical_features: list
      List of the categorical variables to be transformed

    :returns:
    sklearn ColumnTransformer object for applying consistent scaling
    and encoding to the data
    """
    transformer = ColumnTransformer(
        [
            ("num", StandardScaler(), numerical_features),
            ("cat", OneHotEncoder(drop="first"), categorical_features),
        ]
    )
    transformer.fit(data)
    return transformer


def transform_data(
    data: pd.DataFrame,
    transformer: ColumnTransformer,
):
    """ Scale and encode data using a pre-calibrated transformer

    :parameters:
    data: pd.DataFrame
      Data to be preprocessed
    transformer: sklearn ColumnTransformer
      Pre-calibrated transformer for scaling and encoding the data

    :returns:
    pd.DataFrame object with transformed data
    """
    return transformer.transform(data)
