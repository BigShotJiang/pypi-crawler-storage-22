"""Functions for managing direct interactions with the raw data"""

import os
import pandas as pd

from ..config.filenames import DATA_PATH


def construct_data_filepath(filename="raw_data"):
    """
    Construct filepath to data CSV file

    Args
    ----

        filename: str (default: "raw_data")
          Filename of the data (without the .csv extension)

    Returns
    -------
        string with the full filepath for loading and writing the data
    """
    file = f"{filename}.csv"
    return os.path.join(DATA_PATH, file)


def load_csv(filename: str, header_height: int = 4):
    """
    Loads a CSV file from the project data folder

    parameters
    ----------
    filename: str
      Name of the CSV file to load

    header_height: int
      Number of rows to skip at the top of the CSV
      (4 by default)

    returns
    -------
    pd.DataFrame
    """
    filepath = construct_data_filepath(filename)
    return pd.read_csv(filepath, skiprows=header_height)


def load_data() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:

    """
    Reads in the three CSV files used in the workflow.

    returns
    -------

        archetype_df: DataFrame containing the archetypes data.
        fixed_capex_df: DataFrame containing the fixed capex data.
        capex_by_power_df: DataFrame containing the capex by power data.

    """

    archetype_df = load_csv(
        filename="Baseline archetype properties",
        header_height=0,
    )

    # Skip the first 4 rows as they contain metadata or headers not relevant
    # to the DataFrame
    fixed_capex_df = load_csv(
        filename="Input Baseline capex fixed",
        header_height=4,
    )
    # Skip the first 4 rows as they contain metadata or headers not relevant
    # to the DataFrame
    capex_by_power_df = load_csv(
        filename="Input Baseline capex by power",
        header_height=4,
    )

    return archetype_df, fixed_capex_df, capex_by_power_df


def save_data(data, output_filename="raw_data.csv"):
    """
    Save data to a CSV file in the project data folder

    parameters
    ----------
    data: pd.DataFrame
      Pandas DataFrame containing the data to be saved
    output: str
      Output filename (without extension) for the CSV data

    returns
    -------
    None
    """
    filepath = construct_data_filepath(output_filename)
    data.to_csv(filepath, index=False)
