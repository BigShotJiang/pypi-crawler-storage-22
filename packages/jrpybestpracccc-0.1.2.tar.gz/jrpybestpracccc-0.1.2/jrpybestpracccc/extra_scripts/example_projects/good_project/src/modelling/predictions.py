"""
Functions involved in generating model predictions using the sklearn model
"""


def model_predict(model, data):
    """Get predictions from model

    :parameters:
    model: sklearn model or pipeline object
      Trained sklearn model or pipeline ready for predictions
    data: 2-D data structure
      Untransformed input data for predictions

    :returns:
    1-D data structure with the model predictions
    """
    return model.predict(data)
