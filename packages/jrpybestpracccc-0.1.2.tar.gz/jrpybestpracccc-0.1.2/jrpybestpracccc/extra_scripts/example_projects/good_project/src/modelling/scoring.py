"""Scoring functions for model testing"""

from sklearn.metrics import mean_absolute_error


def score_model(y_true, y_pred):
    """Scoring function for the mean absolute error

    :parameters:
    y_true: 1-D data structure
      True values of the target variable
    y_pred: 1-D data structure
      Predicted values of the target variable

    :returns:
    Maximum absolute error
    """
    return mean_absolute_error(y_true, y_pred)
