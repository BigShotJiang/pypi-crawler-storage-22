"""Functions associated with training the model"""

from sklearn.model_selection import train_test_split


def train_model(model, x, y):
    """Train the model using the training data

    :parameters:
    model: sklearn model or pipeline object
      Model or pipeline for training
    x: 2-D data structure
      Covariates for training
    y: 1-D data structure
      Target variable to predict

    :returns:
    Sklearn model or pipeline object after training
    """
    model.fit(x, y)
    return model


def create_test_data(x, y, test_size=0.2):
    """
    Split up the data into a training set and (unseen) test set

    parameters
    ----------
    x: pd.DataFrame
      DataFrame with the covariates (predictors)
    y: pd.Series | np.array | list
      Array-like object with the response (target) variable
    test_size: float
      Proportion of data to allocate to the test set

    returns
    -------
    (x_train, x_test, y_train, y_test)
      pd.DataFrame objects with the split data
    """
    return train_test_split(x, y, test_size=test_size)
