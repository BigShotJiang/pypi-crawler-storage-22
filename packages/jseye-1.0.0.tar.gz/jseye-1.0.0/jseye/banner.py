"""
JSEye Banner Display
"""

from rich.console import Console
from rich.text import Text
from rich.align import Align

console = Console()

def show_banner():
    """Display the JSEye banner with proper alignment"""
    banner = """
                                        
   ▄▄▄▄▄▄  ▄▄▄▄▄     ▄▄▄▄▄▄▄            
  █▀ ██   ██▀▀▀▀█▄  █▀██▀▀▀             
     ██   ▀██▄  ▄▀    ██                
     ██     ▀██▄▄     ████   ██ ██ ▄█▀█▄
     ██   ▄   ▀██▄    ██     ██▄██ ██▄█▀
     ██   ▀██████▀    ▀█████▄▄▀██▀▄▀█▄▄▄
 ▄   ██                        ██       
 ▀████▀                      ▀▀▀        
"""
    
    # Display banner in cyan, centered
    banner_text = Text(banner.strip(), style="cyan bold")
    console.print(Align.center(banner_text))
    console.print()
    
    # Tagline and author info, centered
    tagline = Text("JSEye — See What JavaScript Hides", style="green bold")
    console.print(Align.center(tagline))
    
    author = Text("Author: Lakshmikanthan K (letchupkt)", style="purple")
    console.print(Align.center(author))
    
    console.print()