=======
Credits
=======

Development Lead
----------------

* Vinit Kumar <mail@vinitkumar.me>

Contributors
------------

Valueable contributions were made by these contributors.

https://github.com/vinitkumar/json2xml/graphs/contributors
