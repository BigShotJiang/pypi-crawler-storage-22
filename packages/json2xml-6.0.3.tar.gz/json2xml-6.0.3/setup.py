#!/usr/bin/env python

"""The setup script."""

from setuptools import setup

setup()

