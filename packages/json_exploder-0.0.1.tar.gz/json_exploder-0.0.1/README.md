# json-exploder
Explode a nested JSON into a flattened tabular structure
