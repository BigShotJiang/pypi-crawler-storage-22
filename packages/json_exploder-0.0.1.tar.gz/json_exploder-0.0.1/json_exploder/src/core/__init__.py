"""Core module which has the exploder logic"""
