"""Core module which has the exploder logic"""

from typing import Dict, List, Union
from datetime import datetime, date

from dataclasses import dataclass


@dataclass
class ColumnInfo:
    """Data class to hold the column information for each column in the json data"""

    ultimate_parent: str
    column_path: str
    child_elements: List[str]
    is_explodable: bool
    column: str


def find_explodable_columns(json_data: Union[Dict, List], prefix: str = "$"):
    """Explode a given Dict find the list of all column paths and also the list of explodable column paths.
    A column is explodable if it is a list of dicts.
    :param json_data: input json data as a dict
    :param prefix: Initial prefix for the column path, initially will set to empty
    :return:
    1. Set of all column paths
    2. List of explodable column paths in the format of
        (
            ultimate_parent,
            column_path which can be exploded from the ultimate parent,
            list of child elements that you can access if you explode this column
        )
    """
    if isinstance(json_data, list):
        return __get_explodable_columns(json_data=json_data[0], prefix=prefix)
    elif isinstance(json_data, dict):
        return __get_explodable_columns(json_data=json_data, prefix=prefix)
    else:
        raise ValueError(f"Unsupported data type {type(json_data)} for the input json data")


def __get_explodable_columns(json_data: Dict, prefix: str = "$", has_explodable_parent: bool = False):
    """Explode a given Dict find the list of all column paths and also the list of explodable column paths.
    A column is explodable if it is a list of dicts.
    :param json_data: input json data as a dict
    :param prefix: Initial prefix for the column path, initially will set to empty
    :return:
    """
    _all_columns = []

    if not isinstance(json_data, dict):
        return _all_columns

    for og_column, value in json_data.items():
        column = f"{prefix}.{og_column}" if prefix != "$" else og_column

        if prefix == "$" and has_explodable_parent:
            column_path = f"$[*].{column}"
        elif prefix == "$" and not has_explodable_parent:
            column_path = column
        elif prefix != "$" and has_explodable_parent:
            column_path = f"$.{column}"
        else:
            column_path = f"$.{column}"

        if column_path.count(".") > 1 and column_path.split(".")[1].endswith("[*]"):
            ultimate_parent = column_path.split(".")[1].replace("[*]", "")
        elif column_path.count(".") > 1 and not column_path.split(".")[1].endswith("[*]"):
            ultimate_parent = column_path.split(".")[1]
        else:
            ultimate_parent = ""

        if isinstance(value, (str, int, float, bool, type(None), datetime, date)):
            _all_columns.append(
                ColumnInfo(
                    ultimate_parent=ultimate_parent,
                    column_path=column_path
                    if ultimate_parent == ""
                    else column_path.replace(f".{ultimate_parent}", ""),
                    child_elements=[],
                    is_explodable=False,
                    column=og_column,
                )
            )

        elif isinstance(value, dict):
            all_inner_columns = __get_explodable_columns(json_data=value, prefix=column)
            _all_columns.extend(all_inner_columns)

        elif isinstance(value, list):
            # send the first element to the recursive function
            # we are assuming that all the elements in the list have the same structure
            all_inner_columns = __get_explodable_columns(
                json_data=value[0], prefix=f"{column}[*]", has_explodable_parent=True
            )

            _all_columns.extend(all_inner_columns)
            _all_columns.append(
                ColumnInfo(
                    ultimate_parent=ultimate_parent,
                    column_path=column_path
                    if ultimate_parent == ""
                    else column_path.replace(f".{ultimate_parent}", ""),
                    child_elements=[child_col.column_path for child_col in all_inner_columns],
                    is_explodable=True,
                    column=og_column,
                )
            )

        else:
            raise ValueError(f"Unsupported data type {type(value)} for column {column}")

    # return _all_columns, _can_explode_column
    return _all_columns
