"""This module contains functions to generate SQL queries ."""

from typing import List, Tuple
from src.utilities.common import get_uuid
from src.utilities.duckdb import DuckDBConnection
from pyarrow import Table


def create_child_table_for(item, all_columns, expand_exploded_dicts: bool, src_table_name: str) -> str:
    """Creates a child table for the given item by generating
    an appropriate SQL query to explode the specified JSON column.
    """
    child_table_name = get_uuid(item, prefix="cht")
    explode_inner_table_sql = f"CREATE TABLE IF NOT EXISTS '{child_table_name}' AS \nSELECT parent_row_id,"

    ultimate_parent, item_path = item.split("|")
    ultimate_parent = ultimate_parent.strip()
    item_path = item_path.strip()

    if expand_exploded_dicts:
        for each_exp_col in all_columns:
            if ultimate_parent == each_exp_col.ultimate_parent or item_path == each_exp_col.column_path:
                for child_col in each_exp_col.child_elements:
                    if ultimate_parent == "":
                        ultimate_parent = each_exp_col.column_path
                    explode_inner_table_sql += f"\nUNNEST(json_extract({ultimate_parent}, '{child_col}')) AS '{ultimate_parent} | {child_col}',"
            else:
                continue

    else:
        explode_inner_table_sql += f"""\nUNNEST(json_extract({ultimate_parent}, '{item_path}')) AS '{item}',"""

    explode_inner_table_sql += f"\nFROM {src_table_name}"

    with DuckDBConnection("json_exploder.db") as duck:
        duck.conn.execute(explode_inner_table_sql).fetch_arrow_table()

    return explode_inner_table_sql


def get_explode_table(
    selected_items: List[str], src_table_name: str, remove_exploded_column: bool
) -> Tuple[str, Table]:
    """Generates an SQL query to create an exploded table based on the selected items
    and retrieves the resulting table as a PyArrow Table.
    """
    exploded_table_sql = "SELECT "
    if remove_exploded_column:
        columns_to_remove = []
        for item in selected_items:
            parent, path = item.split("|")
            columns_to_remove.append(parent.strip() if parent.strip() != "" else path.strip())

        exploded_table_sql += " * EXCLUDE (parent_row_id, " + ",".join(columns_to_remove) + "), "
    else:
        exploded_table_sql += " * EXCLUDE(parent_row_id), "

    exploded_table_sql += f"\nFROM {src_table_name} root  "
    for item in selected_items:
        child_table_name = get_uuid(item, prefix="cht")
        exploded_table_sql += f"\nJOIN {child_table_name} \n\tON root.parent_row_id = {child_table_name}.parent_row_id "

    with DuckDBConnection("json_exploder.db") as duck:
        exploded_table = duck.conn.execute(exploded_table_sql).fetch_arrow_table()

    return exploded_table_sql, exploded_table
