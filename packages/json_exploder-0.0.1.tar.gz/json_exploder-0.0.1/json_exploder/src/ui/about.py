"""About Page in the JSON Exploder UI"""

import streamlit as st

st.write("""
### About JSON Exploder
""")
