"""Config Generator Page in the JSON Exploder UI"""

import os
import tempfile
import streamlit as st

from src.core.exploder import find_explodable_columns
from src.utilities.duckdb import DuckDBConnection
from src.utilities.common import get_uuid
from src.core.sql_generator import create_child_table_for, get_explode_table

st.set_page_config(page_title="JSON Exploder", layout="wide")

st.markdown("<br>Upload a JSON file", unsafe_allow_html=True)
uploaded_file = st.file_uploader("", type=["json"], accept_multiple_files=False, width=400)
exploded_table = None

top_col_left, dummy, top_col_right = st.columns([3, 1, 1], gap="medium")
bottom_col_left, bottom_col_right = st.columns([3, 1], gap="medium")

with top_col_left:
    if uploaded_file is not None:
        temp_dir = tempfile.mkdtemp()

        # 2. Create the full path for the file in the temp directory
        abs_file_path = os.path.join(temp_dir, uploaded_file.name)

        # 3. Write the file to disk
        with open(abs_file_path, "wb") as f:
            f.write(uploaded_file.getbuffer())

        table_name = get_uuid(uploaded_file.name, prefix="t_")

        try:
            with DuckDBConnection("json_exploder.db") as duck:
                duck.conn.execute(
                    f"""
                    CREATE OR REPLACE TABLE {table_name} AS
                    SELECT *, row_number() over() as parent_row_id
                    FROM read_json_auto('{abs_file_path}')
                    """
                )

        except Exception as e:
            st.error(f"Error loading JSON file to duckdb: {e}")

        finally:
            os.remove(abs_file_path)

        with DuckDBConnection("json_exploder.db") as duck:
            py_table = duck.conn.execute(f"SELECT * FROM {table_name} limit 10").fetch_arrow_table()

        with st.container():
            st.markdown(
                "<br>Successfully Loaded JSON file, here's a preview of sample data",
                unsafe_allow_html=True,
            )
            st.dataframe(py_table, width="stretch", height="auto")

        all_columns = find_explodable_columns(py_table.to_pylist()[0])

        st.divider()

        with top_col_right:
            with st.container():
                st.text("Settings")
                expand_exploded_dicts = st.checkbox("Exploded dictionaries into individual columns", value=True)
                show_sql = st.checkbox("Show SQL statements for the exploded table", value=True)
                remove_exploded_column = st.checkbox("Remove exploded column in result table", value=True)

        st.markdown(
            "Select one or more columns to see how the table would look like after explosion <br><br>",
            unsafe_allow_html=True,
        )

        selected_items = []
        for item in [f"{col.ultimate_parent} | {col.column_path}" for col in all_columns if col.is_explodable]:
            is_checked = st.checkbox(item, key=get_uuid(item, prefix="check"))
            if is_checked:
                selected_items.append(item)

        # st.text(f"{selected_items}")

        if selected_items:
            for item in selected_items:
                explode_inner_table_sql = create_child_table_for(
                    item=item,
                    all_columns=all_columns,
                    expand_exploded_dicts=expand_exploded_dicts,
                    src_table_name=table_name,
                )
                if show_sql:
                    with bottom_col_right:
                        st.markdown(f"TEMP table for: {item}", unsafe_allow_html=True)
                        st.code(explode_inner_table_sql.strip())

            exploded_table_sql, exploded_table = get_explode_table(
                selected_items=selected_items,
                src_table_name=table_name,
                remove_exploded_column=remove_exploded_column,
            )

            if show_sql:
                with bottom_col_right:
                    st.markdown("<br>Final SQL Statement", unsafe_allow_html=True)
                    st.code(exploded_table_sql.strip())

        else:
            st.markdown("<br><br>", unsafe_allow_html=True)
            st.info("Select one or more columns to see the exploded results")


if exploded_table:
    with bottom_col_left:
        st.markdown("<br>Exploded Results:", unsafe_allow_html=True)
        st.dataframe(exploded_table, width="stretch", height="auto")
