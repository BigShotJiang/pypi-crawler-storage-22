"""Example Page in the JSON Exploder UI"""

import streamlit as st

st.write("""
### Here are some sample JSON files you can use to test the JSON Exploder
""")
