"""Home page of the JSON Exploder UI"""

import streamlit as st

st.write("""
# Welcome to the JSON Exploder!
""")

pg = st.navigation(
    [
        st.Page("config_generator.py", title="Configuration Generator", default=True),
        st.Page("examples.py", title="Examples"),
        st.Page("about.py", title="About"),
    ]
)
pg.run()
