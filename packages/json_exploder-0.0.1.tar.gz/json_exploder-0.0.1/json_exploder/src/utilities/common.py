"""Common Utilities for JSON Exploder."""

import uuid


def get_uuid(input_str, prefix=""):
    """Generates a UUID based on the input string and an optional prefix.
    The resulting UUID is then formatted as a string with the prefix and all hyphens removed.
    """
    return f"{prefix}{uuid.uuid5(uuid.NAMESPACE_DNS, input_str)}".replace("-", "")
