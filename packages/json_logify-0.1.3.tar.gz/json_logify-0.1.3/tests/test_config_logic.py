"""Tests for configuration logic."""

from logify.core import configure_core, get_config_value


class TestConfigurationLogic:
    """Test configuration logic including merge and replace strategies."""

    def setup_method(self):
        """Reset configuration before each test."""
        # Reset to known state.
        # Note: We can't easily "reset" global state perfectly without private access,
        # but we can set it to a known state using replace_sensitive_defaults=True.
        configure_core(sensitive_fields=["password", "token"], replace_sensitive_defaults=True, max_string_length=100)

    def test_default_merge_behavior(self):
        """Test that sensitive fields are merged by default."""
        # Setup initial state
        configure_core(sensitive_fields=["initial"], replace_sensitive_defaults=True)
        assert "initial" in get_config_value("SENSITIVE_FIELDS")

        # Test merge (default)
        configure_core(sensitive_fields=["new_field"])

        fields = get_config_value("SENSITIVE_FIELDS")
        assert "initial" in fields
        assert "new_field" in fields
        assert len(fields) >= 2

    def test_explicit_replace_behavior(self):
        """Test that sensitive fields are replaced when requested."""
        # Setup initial state
        configure_core(sensitive_fields=["initial"], replace_sensitive_defaults=True)

        # Test replace
        configure_core(sensitive_fields=["replaced"], replace_sensitive_defaults=True)

        fields = get_config_value("SENSITIVE_FIELDS")
        assert "initial" not in fields
        assert "replaced" in fields
        assert len(fields) == 1

    def test_max_string_length_update(self):
        """Test max string length update."""
        configure_core(max_string_length=500)
        assert get_config_value("MAX_STRING_LENGTH") == 500

        configure_core(max_string_length=10)
        assert get_config_value("MAX_STRING_LENGTH") == 10

    def test_clearing_fields_with_replace(self):
        """Test clearing all sensitive fields."""
        configure_core(sensitive_fields=[], replace_sensitive_defaults=True)
        assert len(get_config_value("SENSITIVE_FIELDS")) == 0
