"""Tests for security masking logic."""


from logify.core import configure_core, mask_sensitive_fields


class TestSecurityMasking:
    """Test security masking including raw string scrubbing."""

    def setup_method(self):
        """Set up sensitive fields."""
        configure_core(sensitive_fields=["password", "token", "secret", "key"], replace_sensitive_defaults=True)

    def test_recursive_dict_masking(self):
        """Test standard recursive dictionary masking."""
        event = {
            "user": "baha",
            "password": "supersecret",
            "nested": {"token": "12345", "safe": "data"},
            "list": [{"key": "private_key", "value": "check"}],
        }

        masked = mask_sensitive_fields(None, None, event)

        assert masked["password"] == "***"
        assert masked["nested"]["token"] == "***"
        assert masked["nested"]["safe"] == "data"
        assert masked["list"][0]["key"] == "***"

    def test_raw_string_scrubbing_basic(self):
        """Test scrubbing of raw strings with key=value patterns."""
        event = {"body": "username=admin&password=secret123&other=value"}

        masked = mask_sensitive_fields(None, None, event)

        assert "password=***" in masked["body"]
        assert "secret123" not in masked["body"]
        assert "username=admin" in masked["body"]

    def test_raw_string_scrubbing_multiple(self):
        """Test scrubbing multiple sensitive fields in one string."""
        event = {"data": "api_key=12345&secret=ABCDE&public=yes"}
        # Note: api_key is not in our setup list above, let's add it to be safe or rely on substring match
        # Wait, 'key' is in the list. 'api_key' contains 'key'.

        masked = mask_sensitive_fields(None, None, event)

        assert "api_key=***" in masked["data"]
        assert "secret=***" in masked["data"]
        assert "12345" not in masked["data"]
        assert "ABCDE" not in masked["data"]

    def test_raw_string_edge_cases(self):
        """Test edge cases for string scrubbing."""
        # Empty value
        event = {"empty": "password="}
        masked = mask_sensitive_fields(None, None, event)
        # Should simple remain password= or password=***?
        # Logic says: parts.split("=", 1).
        # We assume value is empty string.
        # Logic: if any(s in k_lower): new_parts.append(f"{k}=***")
        # So even empty password gets masked to ***. This is acceptable/safer.
        assert masked["empty"] == "password=***"

        # No sensitive data
        event = {"safe": "user=admin&role=editor"}
        masked = mask_sensitive_fields(None, None, event)
        assert masked["safe"] == "user=admin&role=editor"

        # Malformed but suspicious
        event = {"weird": "password=secret=token"}
        # split by &, then each by =.
        # Here only one part? "password=secret=token"
        # k="password", v="secret=token".
        # Should become "password=***".
        masked = mask_sensitive_fields(None, None, event)
        assert masked["weird"] == "password=***"

    def test_scrubbing_inside_lists(self):
        """Test scrubbing strings inside lists."""
        event = {"history": ["path=/login?password=secret", "normal_string"]}

        masked = mask_sensitive_fields(None, None, event)

        assert "password=***" in masked["history"][0]
        assert "secret" not in masked["history"][0]
