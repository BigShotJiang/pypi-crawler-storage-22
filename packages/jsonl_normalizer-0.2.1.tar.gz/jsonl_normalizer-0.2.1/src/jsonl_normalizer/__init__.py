"""
jsonl_normalizer
=================
Tiny helper library to normalize JSON / JSONL into a clean dict-only JSONL stream.
Public API
----------
- ``normalize_jsonl``:
    Core function that accepts JSONL *or* classic JSON (dict / list),
    optional de-duplication, and flexible I/O (paths or file-like objects).
- ``NormalizationStats``:
    Dataclass summarizing what happened during a normalization run.
- ``convert_json_dir_to_jsonl``:
    Batch convert a directory of .json files to .jsonl.
- ``concat_jsonl``:
    Concatenate multiple normalized_*.jsonl files into one.
Typical usage
-------------
.. code-block:: python

    from pathlib import Path
    from jsonl_normalizer import normalize_jsonl, convert_json_dir_to_jsonl, concat_jsonl

    # Normalize a single file
    stats = normalize_jsonl(
        "input.jsonl",
        "output.normalized.jsonl",
        "discarded.jsonl",
        dedupe=True,
    )

    # Batch convert a directory of .json files
    results = convert_json_dir_to_jsonl(
        source_dir=Path("./raw_jsons"),
        output_dir=Path("./converted_jsonls"),
        dedupe=True
    )

    # Concatenate normalized files
    concat_jsonl(
        source_dir=Path("./norm_jsonl"),
        output_file=Path("combined.jsonl"),
        pattern="*.jsonl",
        dedupe=True
    )
"""
from __future__ import annotations
from .core import NormalizationStats, normalize_jsonl
from .tools.json_to_jsonl import convert_json_dir_to_jsonl
from .tools.concat_jsonl import concat_jsonl
try:  # Python 3.8+
    from importlib.metadata import PackageNotFoundError, version
except ImportError:  # pragma: no cover - for very old Python only
    from importlib_metadata import PackageNotFoundError, version  # type: ignore[assignment]

try:
    # When installed as a package, this will reflect the version in pyproject.toml
    __version__ = version("jsonl_normalizer")
except PackageNotFoundError:  # pragma: no cover - during local dev without install
    # Fallback for editable / source-only usage
    __version__ = "0.2.1"
__all__ = [
    "normalize_jsonl",
    "convert_json_dir_to_jsonl",
    "concat_jsonl",
    "NormalizationStats",
    "__version__",
]
