from __future__ import annotations

import argparse
import logging
from pathlib import Path

from .core import normalize_jsonl

logger = logging.getLogger(__name__)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Normalize mixed JSONL (dicts/lists) into dict-only JSONL. "
            "Optionally deduplicate records using SHA-256 over canonical JSON."
        )
    )
    parser.add_argument(
        "input",
        type=Path,
        help="Input JSONL file (mixed types).",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("normalized.jsonl"),
        help="Output JSONL file with dict-only records (default: normalized.jsonl).",
    )
    parser.add_argument(
        "--discarded",
        type=Path,
        default=Path("discarded.jsonl"),
        help="JSONL file for discarded non-dict/malformed content (default: discarded.jsonl).",
    )
    parser.add_argument(
        "--dedupe",
        action="store_true",
        help="Enable SHA-256-based deduplication of normalized records.",
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Disable verbose output.",
    )
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    # Configure logging
    log_level = logging.WARNING if args.quiet else logging.INFO
    logging.basicConfig(
        level=log_level,
        format="%(message)s",
    )

    if not args.quiet:
        logger.info(f"Input file          : {args.input}")
        logger.info(f"Output file         : {args.output}")
        logger.info(f"Discarded file      : {args.discarded}")
        logger.info(f"Deduplication       : {'enabled' if args.dedupe else 'disabled'}")

    stats = normalize_jsonl(
        input_path=args.input,
        output_path=args.output,
        discarded_path=args.discarded,
        dedupe=args.dedupe,
    )

    # Simple human-readable summary
    if not args.quiet:
        logger.info("RESULT:")
        if args.dedupe:
            logger.info(f"  Records read   : {stats.normalized_seen}")
            logger.info(f"  Records written: {stats.written}")
            logger.info(f"  Duplicates     : {stats.duplicates_skipped}")
        else:
            logger.info(f"  Records written: {stats.written}")
        logger.info(f"  Discarded      : {stats.discarded_count}")
        logger.info(f"  Output path    : {args.output.resolve()}")
