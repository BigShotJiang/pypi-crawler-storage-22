#!/usr/bin/env python3
"""
JSONL Concatenator for jsonl-normalizer.

Usage examples:
    jsonl-concat
    jsonl-concat norm_jsonl/
    jsonl-concat norm_jsonl/ out.jsonl
    jsonl-concat --no-dedupe
    jsonl-concat --quiet
"""

import argparse
import io
import json
import logging
from pathlib import Path
from jsonl_normalizer.core import normalize_jsonl, stable_hash

logger = logging.getLogger(__name__)


def concat_jsonl(
        source_dir: Path,
        output_file: Path,
        pattern: str | None = None,
        dedupe: bool = True,
        verbose: bool = True,
) -> None:
    if pattern:
        files = sorted(source_dir.glob(pattern))
    else:
        # Try both extensions simultaneously if no pattern is specified
        files = sorted(set(source_dir.glob("*.jsonl")) | set(source_dir.glob("*.json")))

    if not files:
        if pattern:
            logger.warning(f"No files matching '{pattern}' found in {source_dir}")
        else:
            logger.warning(f"No *.jsonl or *.json files found in {source_dir}")
        return

    if verbose:
        logger.info(f"Input directory     : {source_dir}")
        logger.info(f"Output file         : {output_file}")
        if pattern:
            logger.info(f"Pattern             : {pattern}")
        logger.info(f"Files detected      : {len(files)}")

    count_in = 0
    count_out = 0
    seen_hashes: set[str] = set()
    dummy_discarded = io.StringIO()

    with output_file.open("w", encoding="utf-8") as fout:
        for fp in files:
            if verbose:
                logger.info(f"Processing: {fp.name}")
            # We use normalize_jsonl to process each file into a memory buffer
            # so we can handle cross-file deduplication and count accurately.
            buf = io.StringIO()
            stats = normalize_jsonl(
                input_path=fp,
                output_path=buf,
                discarded_path=dummy_discarded,
                dedupe=False,  # We handle dedupe ourselves for cross-file consistency
            )
            
            count_in += stats.normalized_seen
            
            buf.seek(0)
            file_written = 0
            for line in buf:
                line = line.strip()
                if not line:
                    continue
                
                if dedupe:
                    rec = json.loads(line)
                    h = stable_hash(rec)
                    if h in seen_hashes:
                        continue
                    seen_hashes.add(h)
                
                fout.write(line + "\n")
                file_written += 1
                count_out += 1
            
            if verbose:
                logger.info(f"  -> {file_written} records added")

    if verbose:
        logger.info("RESULT:")
        logger.info(f"  Records read   : {count_in}")
        logger.info(f"  Records written: {count_out}")
        if dedupe:
            logger.info(f"  Duplicates     : {count_in - count_out}")
        logger.info(f"  Dedupe         : {dedupe}")
        logger.info(f"  Output path    : {output_file.resolve()}")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="jsonl-concat",
        description="Concatenate JSONL files into a single multi-line JSONL (BigQuery-friendly).",
    )

    p.add_argument(
        "source_dir",
        nargs="?",
        default="norm_jsonl",
        help="Directory containing JSONL files (default: norm_jsonl).",
    )
    p.add_argument(
        "output_file",
        nargs="?",
        default="combined.jsonl",
        help="Output JSONL file path (default: combined.jsonl).",
    )
    p.add_argument(
        "--pattern",
        default=None,
        help="File pattern to match (default: *.jsonl, or *.json if no .jsonl found).",
    )
    p.add_argument(
        "--no-dedupe",
        action="store_true",
        help="Disable deduplication (default: dedupe enabled).",
    )
    p.add_argument(
        "--quiet",
        action="store_true",
        help="Disable verbose output.",
    )

    return p


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    # Configure logging
    log_level = logging.WARNING if args.quiet else logging.INFO
    logging.basicConfig(
        level=log_level,
        format="%(message)s",
    )

    source_dir = Path(args.source_dir)
    output_file = Path(args.output_file)
    pattern = args.pattern
    dedupe = not args.no_dedupe
    verbose = not args.quiet

    if verbose and output_file.suffix.lower() not in {".jsonl", ".ndjson"}:
        logger.warning(f"Output file '{output_file.name}' does not use .jsonl or .ndjson. Continuing.")

    concat_jsonl(
        source_dir=source_dir,
        output_file=output_file,
        pattern=pattern,
        dedupe=dedupe,
        verbose=verbose,
    )

    if __name__ == "__main__":
        main()


if __name__ == "__main__":
    main()
