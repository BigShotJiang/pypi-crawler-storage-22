#!/usr/bin/env python3
"""
JSON to JSONL converter for jsonl-normalizer.
Converts classic JSON files in a directory to JSONL format.
"""

import argparse
import logging
from pathlib import Path
from jsonl_normalizer.core import normalize_jsonl, NormalizationStats

logger = logging.getLogger(__name__)


def convert_json_dir_to_jsonl(
    source_dir: Path,
    output_dir: Path,
    discarded_dir: Path | None = None,
    *,
    dedupe: bool = False,
    encoding: str = "utf-8",
    verbose: bool = True,
) -> dict[str, NormalizationStats]:
    """
    Convert all .json files in source_dir to .jsonl in output_dir.
    """
    if not source_dir.is_dir():
        raise NotADirectoryError(f"Source directory not found: {source_dir}")

    if discarded_dir is None:
        discarded_dir = Path("discarded_json")

    output_dir.mkdir(parents=True, exist_ok=True)
    discarded_dir.mkdir(parents=True, exist_ok=True)

    json_files = sorted(source_dir.glob("*.json"))
    if not json_files:
        if verbose:
            logger.warning(f"No .json files found in {source_dir}")
        return {}

    if verbose:
        logger.info(f"Source directory    : {source_dir}")
        logger.info(f"Output directory    : {output_dir}")
        if discarded_dir:
            logger.info(f"Discarded directory : {discarded_dir}")
        logger.info(f"Files detected      : {len(json_files)}")

    results: dict[str, NormalizationStats] = {}

    for json_file in json_files:
        output_file = output_dir / (json_file.stem + ".jsonl")
        discarded_file = discarded_dir / (json_file.stem + "_discarded.jsonl")

        if verbose:
            logger.info(f"Converting: {json_file.name}")

        stats = normalize_jsonl(
            json_file,
            output_file,
            discarded_file,
            dedupe=dedupe,
            encoding=encoding
        )
        results[json_file.name] = stats
        
        if verbose:
            logger.info(f"  -> {output_file.name} (written: {stats.written}, discarded: {stats.discarded_count})")

    return results


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="json-to-jsonl",
        description="Convert classic JSON files in a directory to JSONL format.",
    )
    p.add_argument(
        "source_dir",
        help="Directory containing .json files.",
    )
    p.add_argument(
        "output_dir",
        help="Directory to save converted .jsonl files.",
    )
    p.add_argument(
        "--discarded-dir",
        help="Directory to save discarded items (optional).",
    )
    p.add_argument(
        "--dedupe",
        action="store_true",
        help="Enable deduplication during conversion.",
    )
    p.add_argument(
        "--quiet",
        action="store_true",
        help="Disable verbose output.",
    )
    return p


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    # Configure logging
    log_level = logging.WARNING if args.quiet else logging.INFO
    logging.basicConfig(
        level=log_level,
        format="%(message)s",
    )

    source_dir = Path(args.source_dir)
    output_dir = Path(args.output_dir)
    discarded_dir = Path(args.discarded_dir) if args.discarded_dir else None
    verbose = not args.quiet

    try:
        convert_json_dir_to_jsonl(
            source_dir=source_dir,
            output_dir=output_dir,
            discarded_dir=discarded_dir,
            dedupe=args.dedupe,
            verbose=verbose,
        )
    except Exception as e:
        logger.error(f"{e}")
        exit(1)


if __name__ == "__main__":
    main()
