import json
from jsonl_normalizer import concat_jsonl

def test_concat_simple(tmp_path):
    # Prepare a fake norm_jsonl directory with two different JSONL files
    src_dir = tmp_path / "norm_jsonl"
    src_dir.mkdir()

    f1 = src_dir / "a.jsonl"
    f2 = src_dir / "b.jsonl"

    obj1 = {"id": 1, "value": "foo"}
    obj2 = {"id": 2, "value": "bar"}

    f1.write_text(json.dumps(obj1, ensure_ascii=False) + "\n", encoding="utf-8")
    f2.write_text(json.dumps(obj2, ensure_ascii=False) + "\n", encoding="utf-8")

    out_file = tmp_path / "combined.jsonl"

    concat_jsonl(source_dir=src_dir, output_file=out_file, dedupe=True, verbose=False)

    assert out_file.is_file()

    lines = out_file.read_text(encoding="utf-8").strip().splitlines()
    assert len(lines) == 2

    parsed = [json.loads(line) for line in lines]
    assert obj1 in parsed
    assert obj2 in parsed


def test_concat_dedupe(tmp_path):
    # Two files with the same JSON content -> should dedupe to one line
    src_dir = tmp_path / "norm_jsonl"
    src_dir.mkdir()

    obj = {"id": 1, "value": "dup"}

    for name in ("a.jsonl", "b.jsonl"):
        (src_dir / name).write_text(json.dumps(obj, ensure_ascii=False) + "\n", encoding="utf-8")

    out_file = tmp_path / "combined.jsonl"

    concat_jsonl(source_dir=src_dir, output_file=out_file, dedupe=True, verbose=False)

    lines = out_file.read_text(encoding="utf-8").strip().splitlines()
    assert len(lines) == 1
    assert json.loads(lines[0]) == obj


def test_concat_no_files(tmp_path, caplog):
    # Empty directory: should warn and not crash
    src_dir = tmp_path / "norm_jsonl"
    src_dir.mkdir()

    out_file = tmp_path / "combined.jsonl"

    import logging
    with caplog.at_level(logging.WARNING):
        concat_jsonl(source_dir=src_dir, output_file=out_file, dedupe=True, verbose=True)
    
    # We expect a warning about no files
    assert "No *.jsonl or *.json files found" in caplog.text

    # Output file may or may not exist, but should not contain data
    if out_file.exists():
        assert out_file.read_text(encoding="utf-8").strip() == ""


import sys
from jsonl_normalizer.tools import concat_jsonl as concat_mod


def test_main_suffix_warn(tmp_path, caplog, monkeypatch):
    src_dir = tmp_path / "norm_jsonl"
    src_dir.mkdir()
    # one simple file
    f = src_dir / "a.jsonl"
    f.write_text('{"id": 1}\n', encoding="utf-8")

    out_file = tmp_path / "out.json"  # intentionally non-.jsonl
    argv = ["jsonl-concat", str(src_dir), str(out_file)]
    monkeypatch.setattr(sys, "argv", argv)

    import logging
    with caplog.at_level(logging.WARNING):
        concat_mod.main()

    # Check that the warning was logged
    assert "does not use .jsonl or .ndjson" in caplog.text

    # And the file was still created and contains one line
    lines = out_file.read_text(encoding="utf-8").strip().splitlines()
    assert len(lines) == 1

def test_concat_multiline(tmp_path):
    src_dir = tmp_path / "norm_jsonl"
    src_dir.mkdir()

    f1 = src_dir / "a.jsonl"
    f1.write_text('{"id": 1}\n{"id": 2}\n', encoding="utf-8")

    f2 = src_dir / "b.jsonl"
    f2.write_text('{"id": 2}\n{"id": 3}\n', encoding="utf-8")

    out_file = tmp_path / "combined.jsonl"

    # With dedupe
    concat_jsonl(source_dir=src_dir, output_file=out_file, dedupe=True, verbose=False)
    lines = out_file.read_text(encoding="utf-8").strip().splitlines()
    assert len(lines) == 3
    ids = [json.loads(line)["id"] for line in lines]
    assert sorted(ids) == [1, 2, 3]

    # Without dedupe
    concat_jsonl(source_dir=src_dir, output_file=out_file, dedupe=False, verbose=False)
    lines = out_file.read_text(encoding="utf-8").strip().splitlines()
    assert len(lines) == 4

def test_concat_pattern_fallback(tmp_path):
    src_dir = tmp_path / "jsons"
    src_dir.mkdir()

    (src_dir / "a.json").write_text('{"id": 1}\n', encoding="utf-8")

    out_file = tmp_path / "combined.jsonl"

    # Default pattern should find *.json since no *.jsonl exist
    concat_jsonl(source_dir=src_dir, output_file=out_file, verbose=False)
    lines = out_file.read_text(encoding="utf-8").strip().splitlines()
    assert len(lines) == 1
    assert json.loads(lines[0])["id"] == 1

def test_concat_pattern_explicit(tmp_path):
    src_dir = tmp_path / "jsons"
    src_dir.mkdir()

    (src_dir / "a.json").write_text('{"id": 1}\n', encoding="utf-8")
    (src_dir / "b.jsonl").write_text('{"id": 2}\n', encoding="utf-8")

    out_file = tmp_path / "combined.jsonl"

    # Default pattern should find BOTH *.json and *.jsonl if they exist
    concat_jsonl(source_dir=src_dir, output_file=out_file, verbose=False)
    lines = out_file.read_text(encoding="utf-8").strip().splitlines()
    assert len(lines) == 2
    ids = sorted([json.loads(line)["id"] for line in lines])
    assert ids == [1, 2]

    # Custom pattern (*.json)
    concat_jsonl(source_dir=src_dir, output_file=out_file, pattern="*.json", verbose=False)
    lines = out_file.read_text(encoding="utf-8").strip().splitlines()
    assert len(lines) == 1
    assert json.loads(lines[0])["id"] == 1
