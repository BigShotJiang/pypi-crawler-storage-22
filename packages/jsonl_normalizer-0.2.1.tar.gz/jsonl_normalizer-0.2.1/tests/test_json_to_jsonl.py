import json

import pytest

from jsonl_normalizer.tools.json_to_jsonl import convert_json_dir_to_jsonl


def test_convert_json_dir_to_jsonl_simple(tmp_path):
    # Prepare source directory with two JSON files
    src_dir = tmp_path / "source"
    src_dir.mkdir()

    out_dir = tmp_path / "output"

    json_a = src_dir / "a.json"
    json_b = src_dir / "b.json"

    obj_a = {"id": 1, "name": "Alice"}
    obj_b = [{"id": 2, "name": "Bob"}, {"id": 3, "name": "Charlie"}]

    json_a.write_text(json.dumps(obj_a), encoding="utf-8")
    json_b.write_text(json.dumps(obj_b), encoding="utf-8")

    results = convert_json_dir_to_jsonl(
        source_dir=src_dir,
        output_dir=out_dir,
        verbose=False
    )

    # Assertions
    assert out_dir.is_dir()
    assert (out_dir / "a.jsonl").is_file()
    assert (out_dir / "b.jsonl").is_file()

    assert len(results) == 2
    assert "a.json" in results
    assert "b.json" in results

    # Check content of a.jsonl
    lines_a = (out_dir / "a.jsonl").read_text(encoding="utf-8").strip().splitlines()
    assert len(lines_a) == 1
    assert json.loads(lines_a[0]) == obj_a

    # Check content of b.jsonl
    lines_b = (out_dir / "b.jsonl").read_text(encoding="utf-8").strip().splitlines()
    assert len(lines_b) == 2
    assert json.loads(lines_b[0]) == obj_b[0]
    assert json.loads(lines_b[1]) == obj_b[1]

    # Check stats
    assert results["a.json"].written == 1
    assert results["b.json"].written == 2


def test_convert_json_dir_to_jsonl_dedupe(tmp_path):
    src_dir = tmp_path / "source"
    src_dir.mkdir()
    out_dir = tmp_path / "output"

    json_file = src_dir / "dup.json"
    # A list with duplicate objects
    data = [
        {"id": 1, "val": "x"},
        {"id": 1, "val": "x"},
        {"id": 2, "val": "y"}
    ]
    json_file.write_text(json.dumps(data), encoding="utf-8")

    # Test without dedupe
    results_no_dedupe = convert_json_dir_to_jsonl(
        source_dir=src_dir,
        output_dir=out_dir,
        dedupe=False,
        verbose=False
    )
    assert results_no_dedupe["dup.json"].written == 3

    # Test with dedupe
    out_dir_dedupe = tmp_path / "output_dedupe"
    results_dedupe = convert_json_dir_to_jsonl(
        source_dir=src_dir,
        output_dir=out_dir_dedupe,
        dedupe=True,
        verbose=False
    )
    assert results_dedupe["dup.json"].written == 2
    assert results_dedupe["dup.json"].duplicates_skipped == 1


def test_convert_json_dir_to_jsonl_no_files(tmp_path, caplog):
    src_dir = tmp_path / "empty_source"
    src_dir.mkdir()
    out_dir = tmp_path / "output"

    import logging
    with caplog.at_level(logging.WARNING):
        results = convert_json_dir_to_jsonl(
            source_dir=src_dir,
            output_dir=out_dir,
            verbose=True
        )

    assert results == {}
    assert "No .json files found" in caplog.text


def test_convert_json_dir_to_jsonl_missing_dir(tmp_path):
    src_dir = tmp_path / "non_existent"
    out_dir = tmp_path / "output"

    with pytest.raises(NotADirectoryError, match="Source directory not found"):
        convert_json_dir_to_jsonl(
            source_dir=src_dir,
            output_dir=out_dir
        )


def test_convert_json_dir_to_jsonl_with_discarded(tmp_path):
    src_dir = tmp_path / "source"
    src_dir.mkdir()
    out_dir = tmp_path / "output"
    discard_dir = tmp_path / "discarded"

    json_file = src_dir / "mixed.json"
    # Classic JSON with something that might be discarded if normalize_line handles it
    # For now let's just use something that works
    data = [{"id": 1}, "not a dict"]
    json_file.write_text(json.dumps(data), encoding="utf-8")

    results = convert_json_dir_to_jsonl(
        source_dir=src_dir,
        output_dir=out_dir,
        discarded_dir=discard_dir,
        verbose=False
    )

    assert discard_dir.is_dir()
    discard_file = discard_dir / "mixed_discarded.jsonl"
    assert discard_file.is_file()

    assert results["mixed.json"].written == 1
    assert results["mixed.json"].discarded_count == 1

    discard_lines = discard_file.read_text(encoding="utf-8").strip().splitlines()
    assert len(discard_lines) == 1
    discard_obj = json.loads(discard_lines[0])
    assert discard_obj["reason"] == "non-dict element in list"


def test_convert_json_dir_to_jsonl_no_discard_if_none(tmp_path):
    src_dir = tmp_path / "source"
    src_dir.mkdir()
    out_dir = tmp_path / "output"
    discard_dir = tmp_path / "discarded"

    json_file = src_dir / "pure.json"
    data = {"id": 1}
    json_file.write_text(json.dumps(data), encoding="utf-8")

    convert_json_dir_to_jsonl(
        source_dir=src_dir,
        output_dir=out_dir,
        discarded_dir=discard_dir,
        verbose=False
    )

    discard_file = discard_dir / "pure_discarded.jsonl"
    assert not discard_file.exists(), "Discarded file should not be created if no items are discarded"
