# JSONLibraryLite

A dependency-free Robot Framework library for JSON operations with a safe, minimal JSONPath-like path engine (no `jsonpath-ng`).

## Install

```bash
pip install jsonlibrarylite