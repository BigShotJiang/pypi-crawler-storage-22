# jsonx - JSON Query & Transform CLI

## Quick Reference

| Command | Purpose |
|---------|---------|
| `jsonx get .path file` | Extract value |
| `jsonx set .path value file` | Set value |
| `jsonx del .path file` | Delete value |
| `jsonx keys file` | List keys |
| `jsonx flatten file` | Flatten to dot notation |
| `jsonx merge a.json b.json` | Merge files |
| `jsonx diff a.json b.json` | Show differences |
| `jsonx format file` | Pretty print |
| `jsonx minify file` | Compact output |
| `jsonx validate file schema` | Validate schema |

## Path Syntax

```
.key          → object property
.a.b.c        → nested property
[0]           → array index
[-1]          → last item
[*]           → all items (returns array)
[0:3]         → slice (items 0, 1, 2)
```

## Common Tasks

### Extract nested value
```bash
jsonx get .config.database.host config.json
```

### Get all items from array
```bash
jsonx get .users[*].email data.json
# ["alice@x.com", "bob@x.com"]
```

### Set value in place
```bash
jsonx set .debug true config.json -i
```

### Merge configs
```bash
jsonx merge defaults.json overrides.json > merged.json
```

### Compare files
```bash
jsonx diff old.json new.json --json
```

### Flatten for easier processing
```bash
jsonx flatten nested.json
# {"users[0].name": "Alice", "config.timeout": 30}
```

### Iterate array with template
```bash
jsonx each data.json -p .users -t '{.id}: {.name}'
# 1: Alice
# 2: Bob
```

## JSON Output

Most commands output JSON by default. For scalar values, use `--raw` to strip quotes:

```bash
jsonx get .name data.json        # "Alice"
jsonx get .name data.json --raw  # Alice
```

## Stdin Support

All commands accept stdin:
```bash
curl api/endpoint | jsonx get .results
cat data.json | jsonx set .updated true
```

## Error Handling

- Missing key: exits 1, prints "Key not found: keyname"
- Invalid JSON: exits 1, prints "Invalid JSON: ..."
- Type mismatch: exits 1, prints "Cannot index/get key from type"

Always check exit code in scripts.

## Schema Validation

Requires `pip install jsonx-cli[schema]`:
```bash
jsonx validate data.json schema.json
# ✓ Valid  (exit 0)
# ✗ Invalid: message (exit 1)
```
