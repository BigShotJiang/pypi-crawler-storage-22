"""jsonx - JSON query and transform CLI"""

__version__ = "0.1.0"
