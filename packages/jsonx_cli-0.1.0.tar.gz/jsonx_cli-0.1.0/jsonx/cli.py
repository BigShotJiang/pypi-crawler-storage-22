"""jsonx CLI - JSON query and transform tool."""

import json
import sys
from typing import Optional

import click

from . import __version__
from .path import (
    get_value, set_value, delete_value, flatten, unflatten,
    keys, merge, diff
)


def load_json(source: Optional[str]) -> dict:
    """Load JSON from file or stdin."""
    if source is None or source == '-':
        data = sys.stdin.read()
    else:
        with open(source, 'r') as f:
            data = f.read()
    
    return json.loads(data)


def output(data, json_output: bool = False, pretty: bool = True):
    """Output data appropriately."""
    if isinstance(data, (dict, list)):
        if pretty:
            click.echo(json.dumps(data, indent=2, ensure_ascii=False))
        else:
            click.echo(json.dumps(data, ensure_ascii=False))
    elif isinstance(data, bool):
        # JSON booleans are lowercase
        click.echo(json.dumps(data))
    elif data is None:
        click.echo("null")
    elif json_output:
        click.echo(json.dumps(data, ensure_ascii=False))
    else:
        click.echo(data)


@click.group()
@click.version_option(version=__version__)
def main():
    """JSON query and transform CLI - simpler than jq.
    
    Examples:
    
        # Get nested value
        jsonx get .users[0].name data.json
        
        # Query from stdin
        cat data.json | jsonx get .config.debug
        
        # Set value and output
        jsonx set .config.debug true data.json
        
        # List keys
        jsonx keys data.json
        
        # Flatten nested structure
        jsonx flatten data.json
    """
    pass


@main.command()
@click.argument('path', default='.')
@click.argument('source', required=False)
@click.option('--json', 'json_out', is_flag=True, help='Force JSON output')
@click.option('--raw', '-r', is_flag=True, help='Raw output (no quotes for strings)')
def get(path: str, source: Optional[str], json_out: bool, raw: bool):
    """Get value at path.
    
    PATH uses dot notation:
    
        .key           - object key
        .key.nested    - nested key
        [0]            - array index
        [*]            - all array items
        [0:3]          - array slice
    
    Examples:
    
        jsonx get .name data.json
        jsonx get .users[0].email data.json
        jsonx get .users[*].name data.json
        cat data.json | jsonx get .config
    """
    try:
        data = load_json(source)
        result = get_value(data, path)
        
        if raw and isinstance(result, str):
            click.echo(result)
        else:
            output(result, json_out)
    
    except (KeyError, IndexError, TypeError) as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except json.JSONDecodeError as e:
        click.echo(f"Invalid JSON: {e}", err=True)
        sys.exit(1)
    except FileNotFoundError:
        click.echo(f"File not found: {source}", err=True)
        sys.exit(1)


@main.command()
@click.argument('path')
@click.argument('value')
@click.argument('source', required=False)
@click.option('--in-place', '-i', is_flag=True, help='Modify file in place')
@click.option('--output', '-o', 'outfile', help='Write to file')
@click.option('--compact', '-c', is_flag=True, help='Compact output')
def set(path: str, value: str, source: Optional[str], in_place: bool, outfile: Optional[str], compact: bool):
    """Set value at path.
    
    VALUE is parsed as JSON. Use quotes for strings.
    
    Examples:
    
        jsonx set .debug true data.json
        jsonx set .name '"Alice"' data.json
        jsonx set .tags '["a","b"]' data.json
        jsonx set .config.timeout 30 data.json -i
    """
    try:
        data = load_json(source)
        
        # Parse value as JSON
        try:
            parsed_value = json.loads(value)
        except json.JSONDecodeError:
            # Treat as string if not valid JSON
            parsed_value = value
        
        result = set_value(data, path, parsed_value)
        
        if in_place and source and source != '-':
            with open(source, 'w') as f:
                json.dump(result, f, indent=2 if not compact else None, ensure_ascii=False)
                f.write('\n')
        elif outfile:
            with open(outfile, 'w') as f:
                json.dump(result, f, indent=2 if not compact else None, ensure_ascii=False)
                f.write('\n')
        else:
            output(result, pretty=not compact)
    
    except (KeyError, TypeError) as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except json.JSONDecodeError as e:
        click.echo(f"Invalid JSON: {e}", err=True)
        sys.exit(1)


@main.command('del')
@click.argument('path')
@click.argument('source', required=False)
@click.option('--in-place', '-i', is_flag=True, help='Modify file in place')
@click.option('--output', '-o', 'outfile', help='Write to file')
def delete(path: str, source: Optional[str], in_place: bool, outfile: Optional[str]):
    """Delete value at path.
    
    Examples:
    
        jsonx del .temp data.json
        jsonx del .users[0] data.json -i
    """
    try:
        data = load_json(source)
        result = delete_value(data, path)
        
        if in_place and source and source != '-':
            with open(source, 'w') as f:
                json.dump(result, f, indent=2, ensure_ascii=False)
                f.write('\n')
        elif outfile:
            with open(outfile, 'w') as f:
                json.dump(result, f, indent=2, ensure_ascii=False)
                f.write('\n')
        else:
            output(result)
    
    except (KeyError, IndexError, TypeError) as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
@click.argument('source', required=False)
@click.option('--recursive', '-r', is_flag=True, help='Show all nested keys with paths')
@click.option('--json', 'json_out', is_flag=True, help='JSON output')
def keys(source: Optional[str], recursive: bool, json_out: bool):
    """List keys in JSON object.
    
    Examples:
    
        jsonx keys data.json
        jsonx keys data.json -r   # All nested keys
    """
    try:
        from .path import keys as get_keys
        
        data = load_json(source)
        result = get_keys(data, recursive=recursive)
        
        if json_out:
            click.echo(json.dumps(result, indent=2))
        else:
            for key in result:
                click.echo(key)
    
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
@click.argument('source', required=False)
@click.option('--sep', default='.', help='Key separator')
def flatten(source: Optional[str], sep: str):
    """Flatten nested JSON to dot-notation keys.
    
    Examples:
    
        jsonx flatten data.json
        # {"users[0].name": "Alice", "config.debug": true}
    """
    try:
        from .path import flatten as do_flatten
        
        data = load_json(source)
        result = do_flatten(data, sep=sep)
        output(result)
    
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
@click.argument('source', required=False)
@click.option('--sep', default='.', help='Key separator')
def unflatten(source: Optional[str], sep: str):
    """Unflatten dot-notation keys to nested structure.
    
    Examples:
    
        echo '{"user.name": "Alice"}' | jsonx unflatten
        # {"user": {"name": "Alice"}}
    """
    try:
        from .path import unflatten as do_unflatten
        
        data = load_json(source)
        result = do_unflatten(data, sep=sep)
        output(result)
    
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
@click.argument('files', nargs=-1, required=True)
@click.option('--deep/--shallow', default=True, help='Deep merge nested objects')
def merge(files: tuple, deep: bool):
    """Merge multiple JSON files.
    
    Later files override earlier ones.
    
    Examples:
    
        jsonx merge base.json override.json
        jsonx merge a.json b.json c.json
    """
    try:
        from .path import merge as do_merge
        
        if len(files) < 2:
            click.echo("Need at least 2 files to merge", err=True)
            sys.exit(1)
        
        result = load_json(files[0])
        for f in files[1:]:
            overlay = load_json(f)
            result = do_merge(result, overlay, deep=deep)
        
        output(result)
    
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
@click.argument('file1')
@click.argument('file2')
@click.option('--json', 'json_out', is_flag=True, help='JSON output')
def diff(file1: str, file2: str, json_out: bool):
    """Show differences between two JSON files.
    
    Examples:
    
        jsonx diff old.json new.json
    """
    try:
        from .path import diff as do_diff
        
        a = load_json(file1)
        b = load_json(file2)
        differences = do_diff(a, b)
        
        if not differences:
            click.echo("No differences")
            return
        
        if json_out:
            click.echo(json.dumps(differences, indent=2))
        else:
            for d in differences:
                path = d['path']
                dtype = d['type']
                
                if dtype == 'added':
                    click.echo(click.style(f"+ {path}: {json.dumps(d['value'])}", fg='green'))
                elif dtype == 'removed':
                    click.echo(click.style(f"- {path}: {json.dumps(d['value'])}", fg='red'))
                elif dtype == 'changed':
                    click.echo(click.style(f"~ {path}: {json.dumps(d['old'])} → {json.dumps(d['new'])}", fg='yellow'))
                elif dtype == 'type_change':
                    click.echo(click.style(f"! {path}: type changed {json.dumps(d['old'])} → {json.dumps(d['new'])}", fg='magenta'))
    
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
@click.argument('source', required=False)
@click.option('--indent', '-i', default=2, type=int, help='Indentation level')
@click.option('--sort-keys', '-s', is_flag=True, help='Sort object keys')
def format(source: Optional[str], indent: int, sort_keys: bool):
    """Pretty print JSON.
    
    Examples:
    
        jsonx format data.json
        cat data.json | jsonx format --indent 4
    """
    try:
        data = load_json(source)
        click.echo(json.dumps(data, indent=indent, sort_keys=sort_keys, ensure_ascii=False))
    
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
@click.argument('source', required=False)
def minify(source: Optional[str]):
    """Minify JSON (compact format).
    
    Examples:
    
        jsonx minify data.json
        jsonx minify data.json > data.min.json
    """
    try:
        data = load_json(source)
        click.echo(json.dumps(data, separators=(',', ':'), ensure_ascii=False))
    
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
@click.argument('source', required=False)
@click.argument('schema')
def validate(source: Optional[str], schema: str):
    """Validate JSON against a JSON Schema.
    
    Requires: pip install jsonx-cli[schema]
    
    Examples:
    
        jsonx validate data.json schema.json
    """
    try:
        import jsonschema
    except ImportError:
        click.echo("jsonschema not installed. Run: pip install jsonx-cli[schema]", err=True)
        sys.exit(1)
    
    try:
        data = load_json(source)
        schema_data = load_json(schema)
        
        jsonschema.validate(data, schema_data)
        click.echo(click.style("✓ Valid", fg='green'))
    
    except jsonschema.ValidationError as e:
        click.echo(click.style(f"✗ Invalid: {e.message}", fg='red'), err=True)
        click.echo(f"  Path: {'.'.join(str(p) for p in e.absolute_path)}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
@click.argument('source', required=False)
def type(source: Optional[str]):
    """Show the type of JSON value.
    
    Examples:
    
        echo '[]' | jsonx type     # array
        echo '{}' | jsonx type     # object
        echo '42' | jsonx type     # number
    """
    try:
        data = load_json(source)
        
        if isinstance(data, dict):
            click.echo("object")
        elif isinstance(data, list):
            click.echo("array")
        elif isinstance(data, str):
            click.echo("string")
        elif isinstance(data, bool):
            click.echo("boolean")
        elif isinstance(data, int):
            click.echo("integer")
        elif isinstance(data, float):
            click.echo("number")
        elif data is None:
            click.echo("null")
        else:
            click.echo("unknown")
    
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
@click.argument('source', required=False)
def count(source: Optional[str]):
    """Count items in array or keys in object.
    
    Examples:
    
        jsonx count data.json           # Count top-level
        jsonx get .users data.json | jsonx count  # Count users
    """
    try:
        data = load_json(source)
        
        if isinstance(data, (list, dict)):
            click.echo(len(data))
        else:
            click.echo("1")
    
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command('each')
@click.argument('source', required=False)
@click.option('--path', '-p', default='.', help='Path to array')
@click.option('--template', '-t', help='Output template (use {.key} for values)')
def each(source: Optional[str], path: str, template: Optional[str]):
    """Iterate over array items.
    
    Examples:
    
        jsonx each data.json -p .users -t '{.name}: {.email}'
        jsonx get .items data.json | jsonx each -t '{.id}'
    """
    try:
        data = load_json(source)
        items = get_value(data, path)
        
        if not isinstance(items, list):
            click.echo("Path must point to an array", err=True)
            sys.exit(1)
        
        for item in items:
            if template:
                # Simple template expansion
                result = template
                # Find all {.path} patterns
                import re
                for match in re.finditer(r'\{(\.[^}]+)\}', template):
                    item_path = match.group(1)
                    try:
                        val = get_value(item, item_path)
                        result = result.replace(match.group(0), str(val))
                    except (KeyError, TypeError):
                        result = result.replace(match.group(0), '')
                click.echo(result)
            else:
                click.echo(json.dumps(item, ensure_ascii=False))
    
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


if __name__ == '__main__':
    main()
