"""JSON path query engine with simple dot notation."""

import re
from typing import Any, List, Tuple, Union

# Path segment patterns
ARRAY_INDEX = re.compile(r'\[(-?\d+)\]')
ARRAY_SLICE = re.compile(r'\[(\d*):(\d*)\]')
ARRAY_WILDCARD = re.compile(r'\[\*\]')


def parse_path(path: str) -> List[Union[str, int, Tuple[int, int], None]]:
    """
    Parse a dot-notation path into segments.
    
    Examples:
        ".users[0].name" -> ["users", 0, "name"]
        ".data[*].id" -> ["data", None, "id"]  (None = wildcard)
        ".items[1:3]" -> ["items", (1, 3)]
    """
    if not path or path == '.':
        return []
    
    # Remove leading dot
    if path.startswith('.'):
        path = path[1:]
    
    segments = []
    current = ""
    i = 0
    
    while i < len(path):
        char = path[i]
        
        if char == '.':
            if current:
                segments.append(current)
                current = ""
            i += 1
        elif char == '[':
            if current:
                segments.append(current)
                current = ""
            
            # Find matching bracket
            end = path.find(']', i)
            if end == -1:
                raise ValueError(f"Unclosed bracket in path: {path}")
            
            bracket_content = path[i:end+1]
            
            # Check for wildcard
            if bracket_content == '[*]':
                segments.append(None)  # None represents wildcard
            # Check for slice
            elif ':' in bracket_content:
                match = ARRAY_SLICE.match(bracket_content)
                if match:
                    start = int(match.group(1)) if match.group(1) else 0
                    end_idx = int(match.group(2)) if match.group(2) else None
                    segments.append((start, end_idx))
            # Check for index
            else:
                match = ARRAY_INDEX.match(bracket_content)
                if match:
                    segments.append(int(match.group(1)))
                else:
                    # Treat as string key (for object keys with special chars)
                    key = bracket_content[1:-1].strip('"\'')
                    segments.append(key)
            
            i = end + 1
        else:
            current += char
            i += 1
    
    if current:
        segments.append(current)
    
    return segments


def get_value(data: Any, path: str) -> Any:
    """
    Get value at path from JSON data.
    
    Args:
        data: JSON data (dict, list, or primitive)
        path: Dot-notation path (e.g., ".users[0].name")
    
    Returns:
        Value at path, or list of values for wildcards
    
    Raises:
        KeyError: If path doesn't exist
        IndexError: If array index out of bounds
    """
    if not path or path == '.':
        return data
    
    segments = parse_path(path)
    return _get_by_segments(data, segments)


def _get_by_segments(data: Any, segments: List) -> Any:
    """Navigate data using parsed segments."""
    if not segments:
        return data
    
    current = data
    remaining_segments = list(segments)
    
    while remaining_segments:
        segment = remaining_segments.pop(0)
        
        if segment is None:
            # Wildcard - apply remaining path to each element
            if not isinstance(current, list):
                raise TypeError(f"Wildcard [*] requires array, got {type(current).__name__}")
            
            if not remaining_segments:
                return current
            
            return [_get_by_segments(item, remaining_segments) for item in current]
        
        elif isinstance(segment, tuple):
            # Slice
            if not isinstance(current, list):
                raise TypeError(f"Slice requires array, got {type(current).__name__}")
            
            start, end = segment
            sliced = current[start:end]
            
            if not remaining_segments:
                return sliced
            
            return [_get_by_segments(item, remaining_segments) for item in sliced]
        
        elif isinstance(segment, int):
            # Array index
            if isinstance(current, list):
                current = current[segment]
            elif isinstance(current, dict):
                # Some dicts use int keys (rare but possible)
                current = current[segment]
            else:
                raise TypeError(f"Cannot index {type(current).__name__}")
        
        else:
            # String key
            if isinstance(current, dict):
                if segment not in current:
                    raise KeyError(f"Key not found: {segment}")
                current = current[segment]
            elif isinstance(current, list):
                # Maybe trying to get key from objects in list?
                raise TypeError(f"Cannot get key '{segment}' from array. Use [*].{segment} for all items.")
            else:
                raise TypeError(f"Cannot get key from {type(current).__name__}")
    
    return current


def set_value(data: Any, path: str, value: Any) -> Any:
    """
    Set value at path in JSON data (returns modified copy).
    
    Args:
        data: JSON data
        path: Dot-notation path
        value: Value to set
    
    Returns:
        Modified copy of data
    """
    if not path or path == '.':
        return value
    
    segments = parse_path(path)
    return _set_by_segments(data, segments, value)


def _set_by_segments(data: Any, segments: List, value: Any) -> Any:
    """Set value using parsed segments."""
    if not segments:
        return value
    
    segment = segments[0]
    remaining = segments[1:]
    
    if isinstance(segment, int):
        # Array index
        if data is None:
            data = []
        if not isinstance(data, list):
            raise TypeError(f"Cannot index {type(data).__name__}")
        
        # Extend list if needed
        while len(data) <= segment:
            data.append(None)
        
        result = list(data)
        result[segment] = _set_by_segments(result[segment], remaining, value)
        return result
    
    elif isinstance(segment, str):
        # Object key
        if data is None:
            data = {}
        if not isinstance(data, dict):
            raise TypeError(f"Cannot set key on {type(data).__name__}")
        
        result = dict(data)
        result[segment] = _set_by_segments(result.get(segment), remaining, value)
        return result
    
    else:
        raise ValueError(f"Cannot set value with wildcard or slice in path")


def delete_value(data: Any, path: str) -> Any:
    """
    Delete value at path (returns modified copy).
    
    Args:
        data: JSON data
        path: Dot-notation path
    
    Returns:
        Modified copy with value removed
    """
    if not path or path == '.':
        return None
    
    segments = parse_path(path)
    return _delete_by_segments(data, segments)


def _delete_by_segments(data: Any, segments: List) -> Any:
    """Delete value using parsed segments."""
    if not segments:
        return None
    
    if len(segments) == 1:
        segment = segments[0]
        if isinstance(segment, int) and isinstance(data, list):
            result = list(data)
            del result[segment]
            return result
        elif isinstance(segment, str) and isinstance(data, dict):
            result = dict(data)
            del result[segment]
            return result
        else:
            raise TypeError(f"Cannot delete from {type(data).__name__}")
    
    segment = segments[0]
    remaining = segments[1:]
    
    if isinstance(segment, int) and isinstance(data, list):
        result = list(data)
        result[segment] = _delete_by_segments(result[segment], remaining)
        return result
    elif isinstance(segment, str) and isinstance(data, dict):
        result = dict(data)
        result[segment] = _delete_by_segments(result.get(segment), remaining)
        return result
    else:
        raise TypeError(f"Cannot navigate {type(data).__name__}")


def flatten(data: Any, prefix: str = "", sep: str = ".") -> dict:
    """
    Flatten nested JSON to dot-notation keys.
    
    Args:
        data: JSON data
        prefix: Current path prefix
        sep: Separator (default ".")
    
    Returns:
        Flat dict with dot-notation keys
    """
    result = {}
    
    if isinstance(data, dict):
        for key, value in data.items():
            new_key = f"{prefix}{sep}{key}" if prefix else key
            if isinstance(value, (dict, list)):
                result.update(flatten(value, new_key, sep))
            else:
                result[new_key] = value
    
    elif isinstance(data, list):
        for i, item in enumerate(data):
            new_key = f"{prefix}[{i}]"
            if isinstance(item, (dict, list)):
                result.update(flatten(item, new_key, sep))
            else:
                result[new_key] = item
    
    else:
        result[prefix] = data
    
    return result


def unflatten(data: dict, sep: str = ".") -> Any:
    """
    Unflatten dot-notation keys back to nested structure.
    
    Args:
        data: Flat dict with dot-notation keys
        sep: Separator (default ".")
    
    Returns:
        Nested JSON structure
    """
    result = {}
    
    for key, value in data.items():
        parts = key.replace('[', sep + '[').split(sep)
        current = result
        
        for i, part in enumerate(parts[:-1]):
            # Handle array indices
            if part.startswith('[') and part.endswith(']'):
                idx = int(part[1:-1])
                while len(current) <= idx:
                    current.append(None)
                if current[idx] is None:
                    # Peek ahead to determine type
                    next_part = parts[i + 1]
                    current[idx] = [] if next_part.startswith('[') else {}
                current = current[idx]
            else:
                if part not in current:
                    # Peek ahead to determine type
                    next_part = parts[i + 1]
                    current[part] = [] if next_part.startswith('[') else {}
                current = current[part]
        
        # Set final value
        last = parts[-1]
        if last.startswith('[') and last.endswith(']'):
            idx = int(last[1:-1])
            while len(current) <= idx:
                current.append(None)
            current[idx] = value
        else:
            current[last] = value
    
    return result


def keys(data: Any, recursive: bool = False) -> List[str]:
    """
    Get all keys from JSON data.
    
    Args:
        data: JSON data
        recursive: If True, return all nested keys with paths
    
    Returns:
        List of keys (or paths if recursive)
    """
    if not isinstance(data, dict):
        return []
    
    if not recursive:
        return list(data.keys())
    
    return list(flatten(data).keys())


def merge(base: Any, overlay: Any, deep: bool = True) -> Any:
    """
    Merge two JSON structures.
    
    Args:
        base: Base data
        overlay: Data to merge on top
        deep: If True, merge nested dicts recursively
    
    Returns:
        Merged data
    """
    if not isinstance(base, dict) or not isinstance(overlay, dict):
        return overlay
    
    result = dict(base)
    
    for key, value in overlay.items():
        if deep and key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = merge(result[key], value, deep)
        else:
            result[key] = value
    
    return result


def diff(a: Any, b: Any, path: str = "") -> List[dict]:
    """
    Find differences between two JSON structures.
    
    Args:
        a: First JSON data
        b: Second JSON data
        path: Current path (internal)
    
    Returns:
        List of difference objects with path, type, and values
    """
    differences = []
    
    if type(a) != type(b):
        return [{"path": path or ".", "type": "type_change", "old": a, "new": b}]
    
    if isinstance(a, dict):
        all_keys = set(a.keys()) | set(b.keys())
        for key in all_keys:
            new_path = f"{path}.{key}" if path else key
            if key not in a:
                differences.append({"path": new_path, "type": "added", "value": b[key]})
            elif key not in b:
                differences.append({"path": new_path, "type": "removed", "value": a[key]})
            else:
                differences.extend(diff(a[key], b[key], new_path))
    
    elif isinstance(a, list):
        max_len = max(len(a), len(b))
        for i in range(max_len):
            new_path = f"{path}[{i}]"
            if i >= len(a):
                differences.append({"path": new_path, "type": "added", "value": b[i]})
            elif i >= len(b):
                differences.append({"path": new_path, "type": "removed", "value": a[i]})
            else:
                differences.extend(diff(a[i], b[i], new_path))
    
    else:
        if a != b:
            differences.append({"path": path or ".", "type": "changed", "old": a, "new": b})
    
    return differences
