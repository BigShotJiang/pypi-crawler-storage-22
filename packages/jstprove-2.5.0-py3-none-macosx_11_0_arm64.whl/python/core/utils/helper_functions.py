from __future__ import annotations

import atexit
import contextlib
import functools
import json
import logging
import os
import re
import shutil
import socket
import struct
import subprocess
import sys
import tempfile
import threading
import urllib.error
import urllib.request
from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum
from importlib.metadata import version as get_version
from pathlib import Path
from time import sleep, time
from typing import Any, TypeVar

try:
    import tomllib  # Python 3.11+
except ModuleNotFoundError:
    import tomli as tomllib

from python.core import PACKAGE_NAME
from python.core.utils.benchmarking_helpers import (
    end_memory_collection,
    start_memory_collection,
)
from python.core.utils.errors import (
    FileCacheError,
    MissingFileError,
    ProofBackendError,
    ProofSystemNotImplementedError,
)

F = TypeVar("F", bound=Callable[..., Any])
logger = logging.getLogger(__name__)


def _prepare_subprocess_env(env: dict[str, str]) -> dict[str, str]:
    env.setdefault("OMPI_MCA_mca_base_component_show_load_errors", "0")
    env.setdefault("PRTE_MCA_prte_silence_shared_fs", "1")
    return env


class RunType(Enum):
    END_TO_END = "end_to_end"
    COMPILE_CIRCUIT = "run_compile_circuit"
    GEN_WITNESS = "run_gen_witness"
    PROVE_WITNESS = "run_prove_witness"
    GEN_VERIFY = "run_gen_verify"


class ZKProofSystems(Enum):
    Expander = "Expander"


class ExpanderMode(Enum):
    PROVE = "prove"
    VERIFY = "verify"


@dataclass
class CircuitExecutionConfig:
    """Configuration for circuit execution operations."""

    run_type: RunType = RunType.END_TO_END
    witness_file: str | None = None
    input_file: str | None = None
    proof_file: str | None = None
    public_path: str | None = None
    verification_key: str | None = None
    circuit_name: str | None = None
    metadata_path: str | None = None
    architecture_path: str | None = None
    w_and_b_path: str | None = None
    output_file: str | None = None
    proof_system: ZKProofSystems = ZKProofSystems.Expander
    circuit_path: str | None = None
    quantized_path: str | None = None
    ecc: bool = True
    dev_mode: bool = False
    write_json: bool = False
    bench: bool = False
    compress: bool = True


def filter_expander_output(stderr: str) -> str:
    """Keep Rust panic + MPI exit summary, drop system stack traces and notes."""
    lines = stderr.splitlines()
    filtered = []
    rust_panic_started = False

    for line in lines:
        # Start capturing Rust panic/assertion
        if "panicked at" in line or "assertion" in line.lower():
            rust_panic_started = True
            filtered.append(line)
            continue

        # Keep lines following Rust panic that are relevant
        if rust_panic_started:
            # Stop at system stack traces or abort messages
            if (
                re.match(r"\[\s*\d+\]", line)
                or "*** Process received signal ***" in line
            ):
                rust_panic_started = False
                continue
            filtered.append(line)

        # Always keep MPI exit summary
        if line.startswith("prterun noticed that process rank"):
            filtered.append(line)

    return "\n".join(filtered)


def extract_rust_error(stderr: str) -> str:
    """
    Extracts the Rust error message from stderr,
    handling both panics and normal error prints.
    """
    lines = stderr.splitlines()
    error_lines = []

    # Case 1: Rust panic
    capture = False
    for line in lines:
        if re.match(r"thread '.*' panicked at", line):
            capture = True
            continue
        if capture:
            if "stack backtrace:" in line.lower():
                break
            error_lines.append(line)
    if error_lines:
        return "\n".join(error_lines).strip()

    # Case 2: Non-panic error (just "Error: ...")
    for line in lines:
        if line.strip().startswith("Error:"):
            return line.strip()

    return ""


# Decorator to compute outputs once and store in temp folder
def compute_and_store_output(func: Callable) -> Callable:
    """Decorator that computes outputs once
    per circuit instance and stores in temp folder.
    Instead of using in-memory cache, uses files in temp folder.

    Args:
        func (Callable): Method that computes outputs to be cached.

    Returns:
        Callable: Wrapped function that reads/writes a caches.
    """

    @functools.wraps(func)
    def wrapper(self: object, *args: tuple, **kwargs: dict) -> object:
        # Define paths for storing outputs in temp folder
        temp_folder = getattr(self, "temp_folder", "temp")
        try:
            Path(temp_folder).mkdir(parents=True, exist_ok=True)
        except OSError as e:
            msg = f"Could not create temp folder {temp_folder}: {e}"
            logger.exception(msg)
            raise FileCacheError(msg) from e

        output_cache_path = Path(temp_folder) / f"{self.name}_output_cache.json"

        # Check if cached output exists
        if output_cache_path.exists():
            msg = f"Loading cached outputs for {self.name} from {output_cache_path}"
            logger.info(msg)
            try:
                with output_cache_path.open() as f:
                    return json.load(f)
            except (OSError, json.JSONDecodeError) as e:
                msg = f"Error loading cached output: {e}"
                logger.warning(msg)
                # Continue to compute if loading fails

        # Compute outputs and cache them
        msg = f"Computing outputs for {self.name}..."
        logger.info(msg)
        output = func(self, *args, **kwargs)

        # Store output in temp folder
        try:
            with Path(output_cache_path).open("w") as f:
                json.dump(output, f)
            msg = f"Stored outputs in {output_cache_path}"
            logger.info(msg)
        except OSError as e:
            msg = f"Warning: Could not cache output to file: {e}"
            logger.warning(msg)

        return output

    return wrapper


# Decorator to prepare input/output files
def prepare_io_files(func: Callable) -> Callable:
    """Decorator that prepares input and output files.
    This allows the function to be called independently.

    Args:
        func (Callable): The function requiring prepared file paths.

    Returns:
        Callable: Wrapped function with prepared file paths injected into its arguments.
    """

    @functools.wraps(func)
    def wrapper(
        self: object,
        exec_config: CircuitExecutionConfig,
        *args: tuple,
        **kwargs: dict,
    ) -> object:

        def resolve_folder(
            key: str,
            file_attr: str | None = None,
            default: str = "",
        ) -> str:
            if getattr(exec_config, key, None):
                return getattr(exec_config, key)
            if file_attr and getattr(exec_config, file_attr, None):
                return str(Path(getattr(exec_config, file_attr)).parent)
            return getattr(self, key, default)

        input_folder = resolve_folder(
            "input_folder",
            "input_file",
            default="python/models/inputs",
        )
        output_folder = resolve_folder(
            "output_folder",
            "output_file",
            default="python/models/output",
        )
        proof_folder = resolve_folder(
            "proof_folder",
            "proof_file",
            default="python/models/proofs",
        )
        quantized_model_folder = resolve_folder(
            "quantized_folder",
            "quantized_path",
            default="python/models/quantized_model_folder",
        )
        weights_folder = resolve_folder(
            "weights_folder",
            default="python/models/weights",
        )
        circuit_folder = resolve_folder("circuit_folder", default="python/models/")

        proof_system = exec_config.proof_system or getattr(
            self,
            "proof_system",
            ZKProofSystems.Expander,
        )

        files = get_files(
            self.name,
            proof_system,
            {
                "input": input_folder,
                "proof": proof_folder,
                "circuit": circuit_folder,
                "weights": weights_folder,
                "output": output_folder,
                "quantized_model": quantized_model_folder,
            },
        )
        # Fill in any missing fields in exec_config with defaults from `files`
        exec_config.witness_file = exec_config.witness_file or files["witness_file"]
        exec_config.input_file = exec_config.input_file or files["input_file"]
        exec_config.proof_file = exec_config.proof_file or files["proof_path"]
        exec_config.public_path = exec_config.public_path or files["public_path"]
        exec_config.circuit_name = exec_config.circuit_name or files["circuit_name"]
        exec_config.metadata_path = exec_config.metadata_path or files["metadata_path"]
        exec_config.architecture_path = (
            exec_config.architecture_path or files["architecture_path"]
        )
        exec_config.w_and_b_path = exec_config.w_and_b_path or files["w_and_b_path"]
        exec_config.output_file = exec_config.output_file or files["output_file"]

        if exec_config.circuit_path:
            circuit_dir = Path(exec_config.circuit_path).parent
            name = Path(exec_config.circuit_path).stem
            exec_config.quantized_path = str(
                circuit_dir / f"{name}_quantized_model.onnx",
            )
            exec_config.metadata_path = str(
                circuit_dir / f"{name}_metadata.json",
            )
            exec_config.architecture_path = str(
                circuit_dir / f"{name}_architecture.json",
            )
            exec_config.w_and_b_path = str(
                circuit_dir / f"{name}_wandb.json",
            )
        else:
            exec_config.quantized_path = None

        # Store paths and data for use in the decorated function
        self._file_info = {
            "witness_file": exec_config.witness_file,
            "input_file": exec_config.input_file,
            "proof_file": exec_config.proof_file,
            "public_path": exec_config.public_path,
            "circuit_name": exec_config.circuit_name,
            "metadata_path": exec_config.metadata_path,
            "architecture_path": exec_config.architecture_path,
            "w_and_b_path": exec_config.w_and_b_path,
            "output_file": exec_config.output_file,
            "inputs": exec_config.input_file,
            "weights": exec_config.w_and_b_path,  # Changed to w_and_b_path
            "outputs": exec_config.output_file,
            "output": exec_config.output_file,
            "proof_system": exec_config.proof_system or proof_system,
            "model_path": getattr(exec_config, "model_path", None),
            "quantized_model_path": exec_config.quantized_path,
        }

        # Call the original function with the populated exec_config
        return func(self, exec_config, *args, **kwargs)

    return wrapper


def ensure_parent_dir(path: str) -> None:
    """Create parent directories for a given path if they don't exist.

    Args:
        path (str): Path for which to create parent directories.
    """
    Path(path).parent.mkdir(parents=True, exist_ok=True)


def run_subprocess(cmd: list[str]) -> None:
    """Run a subprocess command and raise RuntimeError if it fails.

    Args:
        cmd (list[str]): The command to execute.

    Raises:
        RuntimeError: If the command exits with a non-zero return code.
    """
    env = os.environ.copy()
    env.setdefault("PYTHONUNBUFFERED", "1")
    _prepare_subprocess_env(env)
    proc = subprocess.run(cmd, text=True, env=env, check=False)
    if proc.returncode != 0:
        msg = f"Command failed with exit code {proc.returncode}"
        raise RuntimeError(msg)


def to_json(inputs: dict[str, Any], path: str) -> None:
    """Write data to a JSON file.

    Args:
        inputs (dict[str, Any]): Data to be serialized.
        path (str): Path where the JSON file will be written.
    """
    ensure_parent_dir(path)
    with Path(path).open("w") as outfile:
        json.dump(inputs, outfile)


def read_from_json(public_path: str) -> dict[str, Any]:
    """Read data from a JSON file.

    Args:
        public_path (str): Path to the JSON file to read.

    Returns:
        dict[str, Any]: The data read from the JSON file.
    """
    with Path(public_path).open() as json_data:
        return json.load(json_data)


def run_cargo_command(
    binary_name: str,
    command_type: str,
    args: dict[str, str] | None = None,
    *,
    dev_mode: bool = False,
    bench: bool = False,
) -> subprocess.CompletedProcess[str]:
    """Run a cargo command with the correct format based on the command type.

    Args:
        binary_name (str): Name of the Cargo binary.
        command_type (str): Command type (e.g., 'run_proof', 'run_compile_circuit').
        args (dict[str, str], optional): dictionary of CLI arguments. Defaults to None.
        circuit_path (str, optional):
            Path to the circuit file, used for copying the binary.
        dev_mode (bool, optional):
            If True, run with `cargo run --release` instead of prebuilt binary.
            Defaults to False.
        bench (bool, optional):
            If True, measure execution time and memory usage. Defaults to False.

    Raises:
        subprocess.CalledProcessError: If the Cargo command fails.

    Returns:
        subprocess.CompletedProcess[str]: Exit message from the subprocess.
    """
    binary_path, binary_name = _resolve_binary(binary_name)
    cmd = _build_command(
        binary_path=binary_path,
        command_type=command_type,
        args=args,
        dev_mode=dev_mode,
        binary_name=binary_name,
    )
    env = os.environ.copy()
    env["RUST_BACKTRACE"] = "1"
    _prepare_subprocess_env(env)

    msg = f"Running cargo command: {' '.join(cmd)}"
    print(msg)  # noqa: T201
    logger.info(msg)

    try:
        result = _run_subprocess_with_bench(
            cmd=cmd,
            env=env,
            bench=bench,
            binary_name=binary_name,
        )
        _handle_result(result=result, cmd=cmd)
    except OSError as e:
        msg = f"Failed to execute proof backend command '{cmd}': {e}"
        logger.exception(msg)
        raise ProofBackendError(msg) from e
    except subprocess.CalledProcessError as e:
        msg = f"Cargo command failed (return code {e.returncode}): {e.stderr}"
        logger.exception(msg)
        rust_error = extract_rust_error(e.stderr)
        msg = f"Rust backend error '{rust_error}'"
        raise ProofBackendError(msg, cmd) from e
    else:
        return result


def _resolve_binary(binary_name: str) -> tuple[str, str]:
    try:
        version = get_version(PACKAGE_NAME)
        binary_name = binary_name + f"_{version}".replace(".", "-")
    except Exception:
        try:
            pyproject = tomllib.loads(Path("pyproject.toml").read_text())
            version = pyproject["project"]["version"]
            binary_name = binary_name + f"_{version}".replace(".", "-")
        except (FileNotFoundError, KeyError, tomllib.TOMLDecodeError):
            pass

    possible_paths = [
        f"./target/release/{binary_name}",
        Path(__file__).parent.parent / "binaries" / binary_name,
        Path(sys.prefix) / "bin" / binary_name,
    ]

    for path in possible_paths:
        if Path(path).exists():
            return str(path), binary_name

    return f"./target/release/{binary_name}", binary_name


def run_cargo_command_piped(
    binary_name: str,
    command_type: str,
    payload: bytes,
    args: dict[str, str] | None = None,
    *,
    dev_mode: bool = False,
) -> subprocess.CompletedProcess[bytes]:
    binary_path, binary_name = _resolve_binary(binary_name)
    cmd = _build_command(
        binary_path=binary_path,
        command_type=command_type,
        args=args,
        dev_mode=dev_mode,
        binary_name=binary_name,
    )
    env = os.environ.copy()
    env["RUST_BACKTRACE"] = "1"

    msg = f"Running piped cargo command: {' '.join(cmd)}"
    logger.info(msg)

    try:
        result = subprocess.run(
            cmd,
            input=payload,
            capture_output=True,
            env=env,
            check=False,
        )
        if result.returncode != 0:
            stderr_text = result.stderr.decode("utf-8", errors="replace")
            rust_error = extract_rust_error(stderr_text)
            msg = f"Piped cargo command failed (code {result.returncode}): {rust_error}"
            raise ProofBackendError(msg, cmd)
    except OSError as e:
        msg = f"Failed to execute piped proof backend command '{cmd}': {e}"
        logger.exception(msg)
        raise ProofBackendError(msg) from e
    else:
        return result


def run_msgpack_command(
    binary_name: str,
    command_type: str,
    payload: bytes,
    args: dict[str, str] | None = None,
    *,
    dev_mode: bool = False,
) -> bytes:
    """Run a msgpack-based command via stdin/stdout.

    Args:
        binary_name: Name of the binary to run.
        command_type: The msgpack command (e.g., msgpack_prove_stdin).
        payload: MessagePack-encoded request bytes.
        args: Optional CLI arguments (e.g., metadata path).
        dev_mode: If True, use cargo run instead of the binary.

    Returns:
        Raw stdout bytes (msgpack-encoded response).

    Raises:
        ProofBackendError: If the command fails.
    """
    binary_path, binary_name = _resolve_binary(binary_name)
    cmd = _build_command(
        binary_path=binary_path,
        command_type=command_type,
        args=args,
        dev_mode=dev_mode,
        binary_name=binary_name,
    )
    env = os.environ.copy()
    env["RUST_BACKTRACE"] = "1"
    _prepare_subprocess_env(env)

    logger.info("Running msgpack command: %s", " ".join(cmd))

    try:
        result = subprocess.run(
            cmd,
            input=payload,
            capture_output=True,
            env=env,
            check=False,
        )
        if result.returncode != 0:
            stderr_text = result.stderr.decode("utf-8", errors="replace")
            rust_error = extract_rust_error(stderr_text)
            msg = f"Msgpack command failed (code {result.returncode}): {rust_error}"
            raise ProofBackendError(msg, cmd)
    except OSError as e:
        msg = f"Failed to execute msgpack command '{cmd}': {e}"
        logger.exception(msg)
        raise ProofBackendError(msg) from e
    return result.stdout


def _build_command(
    binary_path: str,
    command_type: str,
    args: dict[str, str] | None,
    *,
    dev_mode: bool,
    binary_name: str,
) -> list[str]:
    """Build the command list for subprocess."""
    cmd = (
        ["cargo", "run", "--bin", binary_name, "--release"]
        if dev_mode
        else [binary_path]
    )
    cmd.append(command_type)
    if args:
        for key, value in args.items():
            prefix = "--" if len(key) > 1 else "-"
            cmd.append(f"{prefix}{key}")
            if not (isinstance(value, bool) and value):
                cmd.append(str(value))
    return cmd


def _run_subprocess_with_bench(
    cmd: list[str],
    env: dict[str, str],
    binary_name: str,
    *,
    bench: bool,
) -> subprocess.CompletedProcess[str]:
    """Run the subprocess with optional benchmarking."""
    if bench:
        stop_event, monitor_thread, monitor_results = start_memory_collection(
            binary_name,
        )
    start_time = time()
    result = subprocess.run(
        cmd,
        check=True,
        capture_output=True,
        text=True,
        env=env,
    )
    end_time = time()
    print("\n--- BENCHMARK RESULTS ---")  # noqa: T201
    print(f"Rust time taken: {end_time - start_time:.4f} seconds")  # noqa: T201
    msg = f"Rust command completed in {end_time - start_time:.4f} seconds"
    logger.info(msg)

    if bench:
        memory = end_memory_collection(stop_event, monitor_thread, monitor_results)
        msg = f"Rust subprocess memory: {memory['total']:.2f} MB"
        print(msg)  # noqa: T201
        logger.info(msg)

    print(result.stdout)  # noqa: T201
    logger.info(result.stdout)
    return result


def _handle_result(result: subprocess.CompletedProcess[str], cmd: list[str]) -> None:
    """Handle the subprocess result and raise errors if needed."""
    if result.returncode != 0:
        msg = f"Proving Backend failed (code {result.returncode}):\n{result.stderr}"
        logger.error(msg)
        msg = (
            f"Proving Backend command '{' '.join(cmd)}'"
            f" failed with code {result.returncode}:\n"
            f"STDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}"
        )
        raise ProofBackendError(msg)


def get_expander_file_paths(circuit_name: str) -> dict[str, str]:
    """Generate standard file paths for an Expander circuit.

    Args:
        circuit_name (str): The base name of the circuit.

    Returns:
        dict[str, str]:
            dictionary containing file paths with keys:
                circuit_file, witness_file, proof_file
    """
    return {
        "circuit_file": circuit_path(circuit_name),
        "witness_file": witness_path(circuit_name),
        "proof_file": proof_path(circuit_name),
    }


ZSTD_MAGIC = b"\x28\xb5\x2f\xfd"
ARTIFACT_EXT = ".bin"


def circuit_path(base: str) -> str:
    return f"{base}_circuit{ARTIFACT_EXT}"


def witness_path(base: str) -> str:
    return f"{base}_witness{ARTIFACT_EXT}"


def proof_path(base: str) -> str:
    return f"{base}_proof{ARTIFACT_EXT}"


def _maybe_decompress(src: str, tmp_dir: str) -> str:
    with Path(src).open("rb") as f:
        magic = f.read(4)
    if magic != ZSTD_MAGIC:
        return src
    import zstandard  # noqa: PLC0415

    dst = str(Path(tmp_dir) / Path(src).name)
    dctx = zstandard.ZstdDecompressor()
    with Path(src).open("rb") as fin, Path(dst).open("wb") as fout:
        dctx.copy_stream(fin, fout)
    return dst


_circuit_cache_lock = threading.Lock()
_circuit_cache: dict[str, str] = {}
_circuit_cache_dir: str | None = None


def _get_circuit_cache_dir() -> str:
    global _circuit_cache_dir  # noqa: PLW0603
    if _circuit_cache_dir is None:
        _circuit_cache_dir = tempfile.mkdtemp(prefix="jstprove_circuit_cache_")
        atexit.register(shutil.rmtree, _circuit_cache_dir, ignore_errors=True)
    return _circuit_cache_dir


def _decompress_circuit_cached(src: str) -> str:
    src = str(Path(src).resolve())
    with _circuit_cache_lock:
        if src in _circuit_cache:
            cached = _circuit_cache[src]
            if Path(cached).exists():
                return cached
            del _circuit_cache[src]

        with Path(src).open("rb") as f:
            magic = f.read(4)
        if magic != ZSTD_MAGIC:
            _circuit_cache[src] = src
            return src

        import zstandard  # noqa: PLC0415

        cache_dir = _get_circuit_cache_dir()
        fd, dst = tempfile.mkstemp(dir=cache_dir, suffix=".bin")
        os.close(fd)
        dctx = zstandard.ZstdDecompressor()
        with Path(src).open("rb") as fin, Path(dst).open("wb") as fout:
            dctx.copy_stream(fin, fout)
        _circuit_cache[src] = dst
        return dst


@dataclass
class _ExpanderDaemon:
    process: subprocess.Popen
    port: int
    circuit_file: str


_daemon_lock = threading.Lock()
_daemon_registry: dict[str, _ExpanderDaemon] = {}

_EXPANDER_BINARY_PATHS = [
    "./Expander/target/release/expander-exec",
    Path(__file__).parent.parent / "binaries" / "expander-exec",
    Path(sys.prefix) / "bin" / "expander-exec",
]


def _find_expander_binary() -> str | None:
    for path in _EXPANDER_BINARY_PATHS:
        if Path(path).exists():
            return str(path)
    return None


def _find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))
        return s.getsockname()[1]


def _start_daemon(circuit_file: str, pcs_type: str) -> _ExpanderDaemon | None:
    binary = _find_expander_binary()
    if binary is None:
        return None
    port = _find_free_port()
    env = os.environ.copy()
    env["RUSTFLAGS"] = "-C target-cpu=native"
    _prepare_subprocess_env(env)
    try:
        process = subprocess.Popen(
            [
                binary,
                "-p",
                pcs_type,
                "serve",
                "--circuit-file",
                circuit_file,
                "--host-ip",
                "127.0.0.1",
                "--port",
                str(port),
            ],
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except OSError:
        logger.exception("Failed to start expander daemon")
        return None

    url = f"http://127.0.0.1:{port}/ready"
    for _ in range(300):
        if process.poll() is not None:
            logger.warning("Expander daemon exited during startup")
            return None
        try:
            with urllib.request.urlopen(url, timeout=1) as resp:  # noqa: S310
                if resp.status == 200:  # noqa: PLR2004
                    logger.info(
                        "Expander daemon ready on port %d for %s",
                        port,
                        circuit_file,
                    )
                    return _ExpanderDaemon(
                        process=process,
                        port=port,
                        circuit_file=circuit_file,
                    )
        except (urllib.error.URLError, OSError, TimeoutError):
            pass
        sleep(0.1)

    logger.warning("Expander daemon failed to become ready within 30s")
    process.terminate()
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait()
    return None


def _get_daemon(circuit_file: str, pcs_type: str) -> _ExpanderDaemon | None:
    with _daemon_lock:
        daemon = _daemon_registry.get(circuit_file)
        if daemon is not None:
            if daemon.process.poll() is None:
                return daemon
            del _daemon_registry[circuit_file]

    daemon = _start_daemon(circuit_file, pcs_type)
    if daemon is None:
        return None

    with _daemon_lock:
        existing = _daemon_registry.get(circuit_file)
        if existing is not None and existing.process.poll() is None:
            daemon.process.terminate()
            with contextlib.suppress(OSError, subprocess.TimeoutExpired):
                daemon.process.wait(timeout=5)
            if daemon.process.poll() is None:
                with contextlib.suppress(OSError):
                    daemon.process.kill()
            return existing
        _daemon_registry[circuit_file] = daemon
    return daemon


def _verify_via_daemon(
    daemon: _ExpanderDaemon,
    witness_file: str,
    proof_file: str,
) -> subprocess.CompletedProcess[str] | None:
    try:
        witness_bytes = Path(witness_file).read_bytes()
        proof_bytes = Path(proof_file).read_bytes()
    except OSError:
        return None

    payload = (
        struct.pack("<QQ", len(witness_bytes), len(proof_bytes))
        + witness_bytes
        + proof_bytes
    )

    url = f"http://127.0.0.1:{daemon.port}/verify"
    req = urllib.request.Request(url, data=payload, method="POST")  # noqa: S310
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:  # noqa: S310
            body = resp.read().decode()
    except (urllib.error.URLError, OSError, TimeoutError):
        return None

    if body.strip() != "success":
        logger.warning("Expander daemon verification returned: %s", body.strip())
        return None

    return subprocess.CompletedProcess(
        args=[],
        returncode=0,
        stdout=body,
        stderr="",
    )


def _shutdown_daemons() -> None:
    with _daemon_lock:
        daemons = list(_daemon_registry.values())
        _daemon_registry.clear()
    for daemon in daemons:
        try:
            daemon.process.terminate()
            daemon.process.wait(timeout=5)
        except (OSError, subprocess.TimeoutExpired):
            with contextlib.suppress(OSError):
                daemon.process.kill()


atexit.register(_shutdown_daemons)


def run_expander_raw(  # noqa: PLR0913, PLR0912, PLR0915, C901
    mode: ExpanderMode,
    circuit_file: str,
    witness_file: str,
    proof_file: str,
    pcs_type: str = "Hyrax",
    *,
    bench: bool = False,
) -> subprocess.CompletedProcess[str]:
    """Run the Expander executable directly using Cargo.

    Args:
        mode (ExpanderMode): Operation mode (PROVE or VERIFY).
        circuit_file (str): Path to the circuit definition file.
        witness_file (str): Path to the witness file.
        proof_file (str): Path to the proof file (input for verification,
                          output for proving).
        pcs_type (str, optional):
            Polynomial commitment scheme type ("Hyrax" or "Raw").
            Defaults to "Hyrax".
        bench (bool, optional):
            If True, collect runtime and memory benchmark data. Defaults to False.

    Returns:
        subprocess.CompletedProcess[str]: Exit message from the subprocess.
    """
    for file_path, label in [
        (circuit_file, "circuit_file"),
        (witness_file, "witness_file"),
        # For VERIFY mode, the proof_file is an input, not just an output
        (proof_file, "proof_file") if mode == ExpanderMode.VERIFY else (None, None),
    ]:
        if file_path and not Path(file_path).exists():
            msg = f"Missing file required for {label}"
            raise MissingFileError(msg, file_path)

    circuit_file = _decompress_circuit_cached(circuit_file)

    if mode == ExpanderMode.VERIFY:
        try:
            daemon = _get_daemon(circuit_file, pcs_type)
            if daemon is not None:
                result = _verify_via_daemon(daemon, witness_file, proof_file)
                if result is not None:
                    return result
                logger.warning("Daemon verify failed, falling back to subprocess")
        except Exception:
            logger.exception("Daemon path error, falling back to subprocess")

    env = os.environ.copy()
    env["RUSTFLAGS"] = "-C target-cpu=native"
    _prepare_subprocess_env(env)
    time_measure = "/usr/bin/time"

    expander_binary_path = _find_expander_binary()
    if not expander_binary_path:
        msg = (
            "Binary 'expander-exec' not found. Install JSTprove with "
            "'uv tool install .' or build with 'cargo build --release "
            "--manifest-path Expander/Cargo.toml --bin expander-exec'."
        )
        raise ProofBackendError(msg)
    args: list[str] = []
    tmp_dir = tempfile.mkdtemp(prefix="jstprove_expander_")
    try:
        witness_file = _maybe_decompress(witness_file, tmp_dir)

        args = [
            time_measure,
            expander_binary_path,
            "-p",
            pcs_type,
        ]
        if mode == ExpanderMode.PROVE:
            args.append(mode.value)
            proof_command = "-o"
        else:
            args.append(mode.value)
            proof_command = "-i"
            proof_file = _maybe_decompress(proof_file, tmp_dir)

        args.extend(["-c", circuit_file])
        args.extend(["-w", witness_file])
        args.extend([proof_command, proof_file])

        if bench:
            stop_event, monitor_thread, monitor_results = start_memory_collection(
                "expander-exec",
            )
        start_time = time()
        result = subprocess.run(
            args,
            env=env,
            capture_output=True,
            text=True,
            check=False,
        )
        end_time = time()

        print("\n--- BENCHMARK RESULTS ---")  # noqa: T201
        print(f"Rust time taken: {end_time - start_time:.4f} seconds")  # noqa: T201

        if bench:
            memory = end_memory_collection(stop_event, monitor_thread, monitor_results)
            print(f"Rust subprocess memory: {memory['total']:.2f} MB")  # noqa: T201

        if result.returncode != 0:
            clean_stderr = filter_expander_output(result.stderr)
            msg = f"Expander {mode.value} failed:\n{clean_stderr}"
            logger.warning(msg)
            msg = f"Expander {mode.value} failed"
            raise ProofBackendError(
                msg,
                command=args,
                returncode=result.returncode,
                stdout=result.stdout,
                stderr=clean_stderr,
            )

        print(  # noqa: T201
            f"✅ expander-exec {mode.value} succeeded:\n{result.stdout}",
        )

        print(f"Time taken: {end_time - start_time:.4f} seconds")  # noqa: T201
    except OSError as e:
        msg = f"Failed to execute Expander {mode.value}: {e}"
        logger.exception(msg)
        raise ProofBackendError(
            msg,
            command=args,
        ) from e
    else:
        return result
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


def compile_circuit(  # noqa: PLR0913
    circuit_name: str,
    circuit_path: str,
    metadata_path: str,
    architecture_path: str,
    w_and_b_path: str,
    proof_system: ZKProofSystems = ZKProofSystems.Expander,
    *,
    dev_mode: bool = True,
    bench: bool = False,
    compress: bool = True,
) -> subprocess.CompletedProcess[str]:
    """Compile a model into zk circuit

    Args:
        circuit_name (str): Name of the circuit.
        circuit_path (str):  Path to the circuit source file.
        proof_system (ZKProofSystems, optional):
            Proof system to use. Defaults to ZKProofSystems.Expander.
        dev_mode (bool, optional):
            If True, recompiles the rust binary (run in development mode).
            Defaults to True.
        bench (bool, optional):
            Whether or not to run benchmarking metrics. Defaults to False.

    Raises:
        NotImplementedError: If proof system is not supported.
    Returns:
        subprocess.CompletedProcess[str]: Exit message from the subprocess.
    """
    if proof_system == ZKProofSystems.Expander:
        # Extract the binary name from the circuit path
        binary_name = Path(circuit_name).name

        # Prepare arguments
        args = {
            "n": circuit_name,
            "c": circuit_path,
            "m": metadata_path,
            "a": architecture_path,
            "b": w_and_b_path,
        }
        if not compress:
            args["no-compress"] = True
        try:
            return run_cargo_command(
                binary_name=binary_name,
                command_type=RunType.COMPILE_CIRCUIT.value,
                args=args,
                dev_mode=dev_mode,
                bench=bench,
            )
        except ProofBackendError as e:
            warning = f"Warning: Compile operation failed: {e}."
            warning2 = f" Using binary: {binary_name}"
            logger.warning(warning)
            logger.warning(warning2)
            raise

    else:
        msg = f"Proof system {proof_system} not implemented"
        raise ProofSystemNotImplementedError(msg)


def generate_witness(  # noqa: PLR0913
    circuit_name: str,
    circuit_path: str,
    witness_file: str,
    input_file: str,
    output_file: str,
    metadata_path: str,
    proof_system: ZKProofSystems = ZKProofSystems.Expander,
    *,
    w_and_b_path: str | None = None,
    dev_mode: bool = False,
    bench: bool = False,
    compress: bool = True,
) -> subprocess.CompletedProcess[str]:
    """Generate a witness file for a circuit.

    Args:
        circuit_name (str): Name of the circuit.
        circuit_path (str): Path to the circuit definition.
        witness_file (str): Path to the output witness file.
        input_file (str): Path to the input JSON file with private inputs.
        output_file (str): Path to the output JSON file with computed outputs.
        proof_system (ZKProofSystems, optional): Proof system to use.
            Defaults to ZKProofSystems.Expander.
        dev_mode (bool, optional):
            If True, recompiles the rust binary (run in development mode).
            Defaults to False.
        bench (bool, optional):
            If True, enable benchmarking. Defaults to False.

    Raises:
        NotImplementedError: If proof system is not supported.

    Returns:
        subprocess.CompletedProcess[str]: Exit message from the subprocess.
    """
    if proof_system == ZKProofSystems.Expander:
        # Extract the binary name from the circuit path
        binary_name = Path(circuit_name).name

        # Prepare arguments
        args = {
            "n": circuit_name,
            "c": circuit_path,
            "i": input_file,
            "o": output_file,
            "w": witness_file,
            "m": metadata_path,
        }
        if w_and_b_path:
            args["b"] = w_and_b_path
        if not compress:
            args["no-compress"] = True
        try:
            return run_cargo_command(
                binary_name=binary_name,
                command_type=RunType.GEN_WITNESS.value,
                args=args,
                dev_mode=dev_mode,
                bench=bench,
            )
        except ProofBackendError as e:
            warning = f"Warning: Witness generation failed: {e}"
            logger.warning(warning)
            raise
    else:
        msg = f"Proof system {proof_system} not implemented"
        raise ProofSystemNotImplementedError(msg)


def generate_proof(  # noqa: PLR0913
    circuit_name: str,
    circuit_path: str,
    witness_file: str,
    proof_file: str,
    metadata_path: str,
    proof_system: ZKProofSystems = ZKProofSystems.Expander,
    *,
    dev_mode: bool = False,
    ecc: bool = True,
    bench: bool = False,
    compress: bool = True,
) -> subprocess.CompletedProcess[str]:
    """Generate proof for the witness.

    Args:
        circuit_name (str): Name of the circuit.
        circuit_path (str): Path to the circuit definition.
        witness_file (str): Path to the witness file.
        proof_file (str): Path to the output proof file.
        proof_system (ZKProofSystems, optional): Proof system to use.
            Defaults to ZKProofSystems.Expander.
        dev_mode (bool, optional):
            If True, recompiles the rust binary (run in development mode).
            Defaults to False.
        ecc (bool, optional):
            If true, run proof using ECC api, otherwise run directly through Expander.
            Defaults to True.
        bench (bool, optional):
            If True, enable benchmarking. Defaults to False.

    Raises:
        NotImplementedError: If proof system is not supported.

    Returns:
        subprocess.CompletedProcess[str]: Exit message from the subprocess.
    """
    if proof_system == ZKProofSystems.Expander:
        if ecc:
            # Extract the binary name from the circuit path
            binary_name = Path(circuit_name).name

            # Prepare arguments
            args = {
                "n": circuit_name,
                "c": circuit_path,
                "w": witness_file,
                "p": proof_file,
                "m": metadata_path,
            }
            if not compress:
                args["no-compress"] = True

            try:
                return run_cargo_command(
                    binary_name=binary_name,
                    command_type=RunType.PROVE_WITNESS.value,
                    args=args,
                    dev_mode=dev_mode,
                    bench=bench,
                )
            except ProofBackendError as e:
                warning = f"Warning: Proof generation failed: {e}"
                logger.warning(warning)
                raise
        else:
            return run_expander_raw(
                mode=ExpanderMode.PROVE,
                circuit_file=circuit_path,
                witness_file=witness_file,
                proof_file=proof_file,
                bench=bench,
            )
    else:
        msg = f"Proof system {proof_system} not implemented"
        raise ProofSystemNotImplementedError(msg)


def generate_verification(  # noqa: PLR0913
    circuit_name: str,
    circuit_path: str,
    input_file: str,
    output_file: str,
    witness_file: str,
    proof_file: str,
    metadata_path: str,
    proof_system: ZKProofSystems = ZKProofSystems.Expander,
    *,
    dev_mode: bool = False,
    ecc: bool = True,
    bench: bool = False,
) -> subprocess.CompletedProcess[str]:
    """Verify a given proof.

    Args:
        circuit_name (str): Name of the circuit.
        circuit_path (str): Path to the circuit definition.
        input_file (str): Path to the input JSON file with public inputs.
        output_file (str): Path to the output JSON file with expected outputs.
        witness_file (str): Path to the witness file.
        proof_file (str): Path to the output proof file.
        proof_system (ZKProofSystems, optional): Proof system to use.
            Defaults to ZKProofSystems.Expander.
        dev_mode (bool, optional):
            If True, recompiles the rust binary (run in development mode).
            Defaults to False.
        ecc (bool, optional):
            If true, run proof using ECC api, otherwise run directly through Expander.
            Defaults to True.
        bench (bool, optional):
            If True, enable benchmarking. Defaults to False.

    Raises:
        NotImplementedError: If proof system is not supported.

    Returns:
        subprocess.CompletedProcess[str]: Exit message from the subprocess.
    """
    if proof_system == ZKProofSystems.Expander:
        if ecc:
            # Extract the binary name from the circuit path
            binary_name = Path(circuit_name).name

            # Prepare arguments
            args = {
                "n": circuit_name,
                "c": circuit_path,
                "i": input_file,
                "o": output_file,
                "w": witness_file,
                "p": proof_file,
                "m": metadata_path,
            }
            # Run the command
            try:
                return run_cargo_command(
                    binary_name=binary_name,
                    command_type=RunType.GEN_VERIFY.value,
                    args=args,
                    dev_mode=dev_mode,
                    bench=bench,
                )
            except ProofBackendError as e:
                warning = f"Warning: Verification generation failed: {e}"
                logger.warning(warning)
                raise
        else:
            return run_expander_raw(
                mode=ExpanderMode.VERIFY,
                circuit_file=circuit_path,
                witness_file=witness_file,
                proof_file=proof_file,
                bench=bench,
            )
    else:
        msg = f"Proof system {proof_system} not implemented"
        raise ProofSystemNotImplementedError(msg)


def run_end_to_end(  # noqa: PLR0913
    circuit_name: str,
    circuit_path: str,
    input_file: str,
    output_file: str,
    proof_system: ZKProofSystems = ZKProofSystems.Expander,
    *,
    demo: bool = False,
    dev_mode: bool = False,
    ecc: bool = True,
    compress: bool = True,
) -> int:
    """Run the full pipeline for proving and verifying a circuit.

    Steps:
        1. Compile the circuit.
        2. Generate a witness from inputs.
        3. Produce a proof from the witness.
        4. Verify the proof against inputs and outputs.

    Args:
        circuit_name (str): Name of the circuit.
        circuit_path (str): Path to the circuit definition.
        input_file (str): Path to the input JSON file with public inputs.
        output_file (str): Path to the output JSON file with expected outputs.
        proof_system (ZKProofSystems, optional):
            Proof system to use. Defaults to ZKProofSystems.Expander.
        demo (bool, optional):
            Run Demo mode, which limits prints, to clean only. Defaults to False.
        dev_mode (bool, optional):
            If True, recompiles the rust binary (run in development mode).
            Defaults to False.
        ecc (bool, optional):
            If true, run proof using ECC api, otherwise run directly through Expander.
            Defaults to True.

    Raises:
        NotImplementedError: If proof system is not supported.

    Returns:
        int: Exit code from the verification step (0 = success, non-zero = failure).
    """
    _ = demo
    if proof_system == ZKProofSystems.Expander:
        path = Path(circuit_path)
        base = str(path.with_suffix(""))

        witness_file = witness_path(base)
        proof_file = proof_path(base)
        compile_circuit(
            circuit_name,
            circuit_path,
            f"{base}_metadata.json",
            f"{base}_architecture.json",
            f"{base}_wandb.json",
            proof_system,
            dev_mode=dev_mode,
            compress=compress,
        )
        generate_witness(
            circuit_name,
            circuit_path,
            witness_file,
            input_file,
            output_file,
            f"{base}_metadata.json",
            proof_system,
            w_and_b_path=f"{base}_wandb.json",
            dev_mode=dev_mode,
            compress=compress,
        )
        generate_proof(
            circuit_name,
            circuit_path,
            witness_file,
            proof_file,
            f"{base}_metadata.json",
            proof_system,
            dev_mode=dev_mode,
            ecc=ecc,
            compress=compress,
        )
        return generate_verification(
            circuit_name,
            circuit_path,
            input_file,
            output_file,
            witness_file,
            proof_file,
            f"{base}_metadata.json",
            proof_system,
            dev_mode=dev_mode,
            ecc=ecc,
        )
    msg = f"Proof system {proof_system} not implemented"
    raise ProofSystemNotImplementedError(msg)


def get_files(
    name: str,
    proof_system: ZKProofSystems,
    folders: dict[str, str],
) -> dict[str, str]:
    """
    Generate file paths ensuring folders exist.

    Args:
        name (str): The base name for all generated files.
        proof_system (ZKProofSystems): The ZK proof system being used.
        folders (dict[str, str]):
            dictionary containing required folder paths with keys like:
            'input', 'proof', 'temp', 'circuit', 'weights', 'output', 'quantized_model'.

    Raises:
        NotImplementedError: If not implemented proof system is tried

    Returns:
        dict[str, str]: A dictionary mapping descriptive keys to file paths.
    """
    # Common file paths
    paths = {
        "input_file": str(Path(folders["input"]) / f"{name}_input.json"),
        "public_path": str(Path(folders["proof"]) / f"{name}_public.json"),
        "metadata_path": str(Path(folders["weights"]) / f"{name}_metadata.json"),
        "architecture_path": str(
            Path(folders["weights"]) / f"{name}_architecture.json",
        ),
        "w_and_b_path": str(Path(folders["weights"]) / f"{name}_w_and_b.json"),
        "output_file": str(Path(folders["output"]) / f"{name}_output.json"),
    }

    # Proof-system-specific files
    if proof_system == ZKProofSystems.Expander:
        paths.update(
            {
                "circuit_name": name,
                "witness_file": str(
                    Path(folders["input"]) / witness_path(name),
                ),
                "proof_path": str(
                    Path(folders["proof"]) / proof_path(name),
                ),
            },
        )
    else:
        msg = f"Proof system {proof_system} not implemented"
        raise ProofSystemNotImplementedError(msg)

    return paths
