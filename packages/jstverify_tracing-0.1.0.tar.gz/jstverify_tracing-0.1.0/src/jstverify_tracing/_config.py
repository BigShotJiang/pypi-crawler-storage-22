"""JstVerifyTracing singleton — holds global configuration and references."""

import atexit
import logging
from typing import Optional

from ._buffer import SpanBuffer
from ._transport import Transport

logger = logging.getLogger("jstverify_tracing")

_VALID_TRANSPORTS = ("direct", "relay")


class JstVerifyTracing:
    _instance: Optional["JstVerifyTracing"] = None

    def __init__(
        self,
        api_key: str,
        service_name: str,
        endpoint: str = "",
        service_type: str = "http",
        flush_interval: float = 5.0,
        max_queue_size: int = 200,
        max_batch_size: int = 50,
        debug: bool = False,
        patch_requests: bool = True,
        transport: str = "direct",
    ):
        if transport not in _VALID_TRANSPORTS:
            raise ValueError(
                f"Invalid transport {transport!r}, must be one of {_VALID_TRANSPORTS}"
            )

        self.api_key = api_key
        self.endpoint = endpoint
        self.service_name = service_name
        self.service_type = service_type
        self.debug = debug
        self.patch_requests = patch_requests
        self.transport = transport

        if debug:
            logging.getLogger("jstverify_tracing").setLevel(logging.DEBUG)

        if self.is_relay:
            self._transport = None
            self._buffer = None
        else:
            if not endpoint:
                raise ValueError("endpoint is required for direct transport mode")
            self._transport = Transport(endpoint=endpoint, api_key=api_key)
            self._buffer = SpanBuffer(
                transport=self._transport,
                flush_interval=flush_interval,
                max_queue_size=max_queue_size,
                max_batch_size=max_batch_size,
            )
            self._buffer.start()
            atexit.register(self.shutdown)

    @property
    def is_relay(self) -> bool:
        return self.transport == "relay"

    def flush(self) -> None:
        """Synchronously flush all buffered spans. Call at end of Lambda invocations."""
        if self._buffer is not None:
            self._buffer.flush_all()

    def shutdown(self) -> None:
        if self._buffer is not None:
            self._buffer.stop()

    @classmethod
    def get_instance(cls) -> Optional["JstVerifyTracing"]:
        return cls._instance

    @classmethod
    def initialize(cls, **kwargs) -> "JstVerifyTracing":
        if cls._instance is not None:
            logger.warning("jstverify-tracing: already initialized, ignoring re-init")
            return cls._instance
        cls._instance = cls(**kwargs)
        if cls._instance.patch_requests:
            from ._requests_patch import patch_requests
            patch_requests()
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """Reset singleton (for testing)."""
        if cls._instance is not None:
            cls._instance.shutdown()
            cls._instance = None
