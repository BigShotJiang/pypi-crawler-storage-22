from typing import Optional
from typing_extensions import TypedDict


class SpanData(TypedDict, total=False):
    traceId: str
    spanId: str
    parentSpanId: Optional[str]
    operationName: str
    serviceName: str
    serviceType: str  # "frontend" | "lambda" | "dynamodb" | "http"
    startTime: int  # epoch milliseconds
    endTime: int  # epoch milliseconds
    duration: int  # milliseconds
    statusCode: Optional[int]
    statusMessage: Optional[str]
    httpMethod: Optional[str]
    httpUrl: Optional[str]
    httpStatusCode: Optional[int]
