"""AWS Lambda middleware for JstVerify distributed tracing."""

import logging
import time
import uuid
from functools import wraps

from .._context import set_root_context, pop_context, clear_context
from .._config import JstVerifyTracing

logger = logging.getLogger("jstverify_tracing")


class JstVerifyTracingMiddleware:
    """Decorator for Lambda handler functions. Extracts trace context from
    incoming request headers, creates a root span, and flushes synchronously
    before returning.

    Usage:
        from jstverify_tracing.integrations.awslambda import JstVerifyTracingMiddleware

        @JstVerifyTracingMiddleware
        def lambda_handler(event, context):
            ...
    """

    def __init__(self, func):
        self._func = func
        wraps(func)(self)

    def __call__(self, event, context):
        instance = JstVerifyTracing.get_instance()
        if instance is None:
            return self._func(event, context)

        if instance.is_relay:
            logger.warning(
                "jstverify-tracing: relay transport is not recommended for Lambda — "
                "spans will be attached to response headers only if the result is a dict"
            )

        trace_id, parent_span_id = _extract_trace_context(event)
        ctx = set_root_context(trace_id, parent_span_id)
        start_time = int(time.time() * 1000)

        status_code = 200
        status_message = None
        result = None
        try:
            result = self._func(event, context)
            if isinstance(result, dict) and "statusCode" in result:
                status_code = result["statusCode"]
            return result
        except Exception as e:
            status_code = 500
            status_message = str(e)
            raise
        finally:
            end_time = int(time.time() * 1000)
            operation = getattr(self._func, "__name__", "handler")
            span = {
                "traceId": ctx.trace_id,
                "spanId": ctx.span_id,
                "parentSpanId": ctx.parent_span_id,
                "operationName": operation,
                "serviceName": instance.service_name,
                "serviceType": instance.service_type,
                "startTime": start_time,
                "endTime": end_time,
                "duration": end_time - start_time,
                "statusCode": status_code,
                "statusMessage": status_message,
            }

            if instance.is_relay:
                from .._relay_buffer import (
                    enqueue_relay_span, drain_relay_spans,
                    encode_relay_header, HEADER_NAME,
                )
                enqueue_relay_span(span)
                spans = drain_relay_spans()
                header_value = encode_relay_header(spans)
                if (
                    header_value is not None
                    and isinstance(result, dict)
                ):
                    result.setdefault("headers", {})[HEADER_NAME] = header_value
            else:
                instance._buffer.enqueue(span)
                instance.flush()

            pop_context()
            clear_context()


def _extract_trace_context(event):
    """Extract trace ID and parent span ID from Lambda event headers."""
    headers = event.get("headers") or {}
    # Normalize to lowercase for case-insensitive matching
    normalized = {k.lower(): v for k, v in headers.items()}
    trace_id = normalized.get("x-jstverify-trace-id") or str(uuid.uuid4())
    parent_span_id = normalized.get("x-jstverify-parent-span-id")
    return trace_id, parent_span_id
