# juba-mcp

Servidor MCP para buscar en [JUBA](https://juba.scba.gov.ar/) (Jurisprudencia de Buenos Aires), la base de datos de sumarios de fallos de la Suprema Corte de la Provincia de Buenos Aires.

Permite que cualquier cliente de IA (Claude Desktop, Cursor, Windsurf, VS Code, Claude Code, etc.) busque sumarios y acceda al texto completo de fallos de jurisprudencia bonaerense.

## Instalación rápida

Hacé click en el botón de tu editor:

[<img src="https://img.shields.io/badge/VS_Code-Instalar_MCP-0098FF?style=for-the-badge&logo=visualstudiocode&logoColor=ffffff" alt="Instalar en VS Code">](https://insiders.vscode.dev/redirect/mcp/install?name=juba&config=%7B%22command%22%3A%22uvx%22%2C%22args%22%3A%5B%22juba-mcp%22%5D%7D)
[<img src="https://img.shields.io/badge/Cursor-Instalar_MCP-F14A2D?style=for-the-badge&logo=cursor&logoColor=ffffff" alt="Instalar en Cursor">](cursor://anysphere.cursor-deeplink/mcp/install?name=juba&config=%7B%22command%22%3A%22uvx%22%2C%22args%22%3A%5B%22juba-mcp%22%5D%7D)

### Claude Code

```bash
claude mcp add juba -- uvx juba-mcp
```

### Claude Desktop

Agregar a `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "juba": {
      "command": "uvx",
      "args": ["juba-mcp"]
    }
  }
}
```

### pip / uvx

```bash
pip install juba-mcp    # instalar globalmente
uvx juba-mcp            # ejecutar sin instalar
```

> Requiere [uv](https://docs.astral.sh/uv/getting-started/installation/) para `uvx`, o Python 3.10+ para `pip`.

## Herramientas

| Herramienta | Descripción |
|-------------|-------------|
| `juba_search` | Búsqueda rápida por palabras clave en sumarios |
| `juba_advanced_search` | Búsqueda avanzada con filtros por campo, tipo de fallo, fecha |
| `juba_get_fallo` | Obtener el texto completo de un fallo por su ID numérico |

## Ejemplos de uso

Una vez configurado, tu cliente de IA puede:

- **"Buscame jurisprudencia sobre prescripción en consumo"** — busca sumarios en materia civil
- **"Jurisprudencia laboral sobre despido sin causa"** — busca en materia laboral
- **"Fallos sobre phishing bancario en Buenos Aires"** — busca responsabilidad bancaria
- **"Buscá sentencias definitivas sobre daño moral desde 2020"** — usa filtros avanzados
- **"Dame el texto completo del fallo 191298"** — descarga el fallo íntegro

### Materias disponibles

| Materia | Clave |
|---------|-------|
| Civil y Comercial | `civil` (default) |
| Laboral | `laboral` |
| Penal | `penal` |
| Contencioso Administrativa | `contencioso` |
| Inconstitucionalidad | `inconstitucionalidad` |
| Conflicto de Poderes | `conflicto` |
| Enjuiciamiento de Magistrados | `enjuiciamiento` |
| Todos | `todos` |

### Campos de búsqueda avanzada

| Campo | Descripción |
|-------|-------------|
| `texto_sumario` | Texto del sumario (default) |
| `voces` | Descriptores temáticos |
| `caratula` | Carátula de la causa |
| `texto_completo` | Texto completo del fallo |
| `tribunal_emisor` | Tribunal que emitió el fallo |
| `juez_voto` | Juez del voto |
| `codigo_norma` | Código de la norma citada |
| `nro_norma` | Número de la norma |

### Datos por resultado

Cada sumario incluye:
- **ID**: Código único del sumario (ej. B4501004)
- **id_fallo**: ID numérico del fallo (usar con `juba_get_fallo` para texto completo)
- **Voces**: Descriptores temáticos jerárquicos
- **Texto**: Texto completo del sumario
- **Normas**: Artículos y leyes citadas
- **Fallo**: Tribunal, fecha, tipo (sentencia/interlocutoria), carátula, magistrados

### Texto completo del fallo

Usando el `id_fallo` de los resultados de búsqueda, se puede obtener el texto íntegro del fallo judicial (típicamente 30-100K caracteres), incluyendo:
- Metadata: tribunal, carátula, fecha, tipo, magistrados, tribunal de origen
- Texto completo de la sentencia con todos los votos

## Cómo funciona

JUBA es una aplicación ASP.NET WebForms sin API JSON pública. Este servidor realiza scraping HTTP estructurado: obtiene tokens de sesión (ViewState), envía búsquedas vía POST, y parsea las respuestas HTML para extraer los datos.

No se usa browser automation — el scraping es directo vía HTTP, lo que lo hace rápido y liviano.

## Limitaciones

- **Máximo ~20 resultados por búsqueda** — JUBA devuelve los primeros 20 sumarios por página.
- **Dependiente del HTML** — cambios en el diseño de JUBA pueden romper el parser. Si esto pasa, reportar un issue.

## Licencia

MIT

<!-- mcp-name: io.github.hernan-cc/juba-mcp -->
