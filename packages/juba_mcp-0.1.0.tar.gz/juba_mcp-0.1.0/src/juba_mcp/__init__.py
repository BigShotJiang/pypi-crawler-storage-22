"""JUBA MCP Server — Search Buenos Aires Province jurisprudence from any AI client."""

__version__ = "0.1.0"
