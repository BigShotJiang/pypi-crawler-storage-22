"""JUBA API client — zero dependencies beyond stdlib.

Scrapes juba.scba.gov.ar (ASP.NET WebForms) via HTTP POST with ViewState tokens.
No browser automation needed.
"""

from __future__ import annotations

import re
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

BASE_URL = "https://juba.scba.gov.ar"
SEARCH_URL = f"{BASE_URL}/Buscar.aspx"
ADVANCED_URL = f"{BASE_URL}/Busquedas.aspx"
FALLO_URL = f"{BASE_URL}/VerTextoCompleto.aspx"

MATERIAS = {
    "civil": "Civil y Comercial",
    "laboral": "Laboral",
    "penal": "Penal",
    "contencioso": "Contencioso administrativa",
    "inconstitucionalidad": "Inconstitucionalidad",
    "conflicto": "Conflicto de Poderes",
    "enjuiciamiento": "Enjuiciamiento de Magistrados",
    "todos": "Todos",
}

VALID_MATERIAS = list(MATERIAS.keys())

SEARCH_FIELDS = [
    "materia", "voces", "nro_causa", "caratula", "texto_sumario",
    "juez_voto", "codigo_norma", "nro_norma", "anio_norma",
    "texto_completo", "tribunal_emisor",
]

_FIELD_MAP = {
    "materia": "chkMateria",
    "voces": "chkVoces",
    "nro_causa": "chkNroCausa",
    "caratula": "chkCaratula",
    "texto_sumario": "chkTextoSumario",
    "juez_voto": "chklJuezVoto",
    "codigo_norma": "chkCodigoNorma",
    "nro_norma": "chkNroNorma",
    "anio_norma": "chkAnioNorma",
    "texto_completo": "chkTextoCompleto",
    "tribunal_emisor": "chkTribunalEmisor",
}


class JUBAError(Exception):
    """Error communicating with JUBA."""


def _fetch(url: str, data: dict[str, str] | None = None, cookies: str = "") -> tuple[str, str]:
    headers = {"User-Agent": "Mozilla/5.0 (compatible; juba-mcp/0.1)"}
    if cookies:
        headers["Cookie"] = cookies
    if data is not None:
        body = urllib.parse.urlencode(data).encode("utf-8")
        headers["Content-Type"] = "application/x-www-form-urlencoded"
        req = urllib.request.Request(url, data=body, headers=headers)
    else:
        req = urllib.request.Request(url, headers=headers)
    try:
        resp = urllib.request.urlopen(req, timeout=30)
        html = resp.read().decode("utf-8")
        new_cookies = resp.headers.get("Set-Cookie", "")
        cookie_str = (
            "; ".join(
                c.split(";")[0]
                for c in new_cookies.split(", ")
                if "=" in c.split(";")[0]
            )
            if new_cookies
            else cookies
        )
        return html, cookie_str
    except urllib.error.HTTPError as e:
        raise JUBAError(f"HTTP {e.code} from {url}") from e
    except urllib.error.URLError as e:
        raise JUBAError(f"Connection error: {e.reason}") from e


def _extract_tokens(html: str) -> dict[str, str]:
    tokens = {}
    for field in ("__VIEWSTATE", "__VIEWSTATEGENERATOR", "__EVENTVALIDATION"):
        m = re.search(rf'id="{field}"\s+value="([^"]*)"', html)
        if m:
            tokens[field] = m.group(1)
    return tokens


def _clean(text: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", text)).strip()


def _parse_fallo_info(text: str) -> dict[str, str]:
    info: dict[str, str] = {}
    m = re.match(r"(\S+\s+\S+)\s+(\S+\s+\S+)\s+([SI])\s+(\d{2}/\d{2}/\d{4})", text)
    if m:
        info["tribunal"] = m.group(1)
        info["causa"] = m.group(2)
        info["tipo"] = "Sentencia" if m.group(3) == "S" else "Interlocutoria"
        info["fecha"] = m.group(4)
    juez = re.search(r"Juez\s+(\S+(?:\s+\([^)]+\))?)", text)
    if juez:
        info["juez"] = juez.group(1)
    caratula = re.search(r"Carátula:\s*(.+?)(?:\s*Magistrados Votantes:|$)", text)
    if caratula:
        info["caratula"] = caratula.group(1).strip()
    magistrados = re.search(r"Magistrados Votantes:\s*(.+?)(?:\s*Tribunal Origen:|$)", text)
    if magistrados:
        info["magistrados"] = magistrados.group(1).strip()
    origen = re.search(r"Tribunal Origen:\s*(.+?)$", text)
    if origen:
        info["tribunal_origen"] = origen.group(1).strip()
    return info


def _parse_results(html: str) -> list[dict[str, Any]]:
    parts = re.split(r"(?=Resultado:\s*\d+\s*de\s*\d+)", html)
    result_parts = [p for p in parts if p.startswith("Resultado:")]
    results = []
    for block in result_parts:
        m = re.match(r"Resultado:\s*(\d+)\s*de\s*(\d+)", block)
        if not m:
            continue
        paragraphs = [
            _clean(p)
            for p in re.findall(r"<p[^>]*>(.*?)</p>", block, re.S)
            if _clean(p)
        ]
        if len(paragraphs) < 3:
            continue
        result: dict[str, Any] = {
            "id": paragraphs[0],
            "voces": paragraphs[1].rstrip(" |"),
            "texto": paragraphs[2],
        }
        if len(paragraphs) > 3:
            normas_text = paragraphs[3]
            if re.search(r"(?:Art\.|LEY|CON|CCI|DEC|CCCN)", normas_text):
                normas = [n.strip() for n in normas_text.split("|") if n.strip()]
                normas = [n for n in normas if n not in ("Ver Norma", "Ver")]
                if normas:
                    result["normas"] = normas
        fallo_match = re.search(
            r"((?:SCBA|CC|CAL|CA|CAP|JC|JCC|TF|TO|TC)\w*\s+\w+.*?"
            r"Carátula:\s*.*?)(?:</p>|$)",
            block, re.S,
        )
        if fallo_match:
            result["fallo"] = _parse_fallo_info(_clean(fallo_match.group(1)))
        id_fallo_match = re.search(r"idFallo=(\d+)", block)
        if id_fallo_match:
            result["id_fallo"] = int(id_fallo_match.group(1))
        results.append(result)
    return results


def _get_total(html: str) -> int:
    m = re.search(r"Resultado:\s*\d+\s*de\s*(\d+)", html)
    return int(m.group(1)) if m else 0


def _get_tab_counts(html: str) -> dict[str, int]:
    counts = {}
    for m in re.finditer(r"en (Texto del Sumario|voces|Texto del Fallo)\s*\((\d+)\)", html):
        counts[m.group(1).lower().replace(" ", "_")] = int(m.group(2))
    return counts


def search(
    query: str,
    materia: str = "civil",
    limit: int = 15,
) -> dict[str, Any]:
    """
    Quick search on JUBA.

    Args:
        query: Search terms.
        materia: One of civil, laboral, penal, contencioso, inconstitucionalidad,
                 conflicto, enjuiciamiento, todos.
        limit: Max results (server returns up to 15 per page).
    """
    materia_value = MATERIAS.get(materia.lower(), materia)
    if materia_value not in MATERIAS.values():
        raise JUBAError(f"Invalid materia: {materia}. Valid: {', '.join(MATERIAS.keys())}")

    html, cookies = _fetch(SEARCH_URL)
    tokens = _extract_tokens(html)

    data = {
        **tokens,
        "__EVENTTARGET": "",
        "__EVENTARGUMENT": "",
        "ctl00$cphMainContent$txtExpresionBusquedaRapida": query,
        "ctl00$cphMainContent$ddlMateria": materia_value,
        "ctl00$cphMainContent$btnUnicaBusqueda": "Buscar",
        "ctl00$cphMainContent$txtPrimeraCarga": "SI",
        "ctl00$cphMainContent$solapaMostrada": "",
    }

    result_html, _ = _fetch(SEARCH_URL, data, cookies)
    total = _get_total(result_html)
    tab_counts = _get_tab_counts(result_html)
    results = _parse_results(result_html)

    if limit < len(results):
        results = results[:limit]

    return {
        "total": total,
        "query": query,
        "materia": materia_value,
        "tab_counts": tab_counts,
        "results": results,
    }


def search_advanced(
    query: str,
    fields: list[str] | None = None,
    tipo_fallo: str | None = None,
    fecha_desde: str | None = None,
    fecha_hasta: str | None = None,
    tribunal: str | None = None,
) -> dict[str, Any]:
    """
    Advanced integral search on JUBA.

    Args:
        query: Search terms (supports etiquetas like Caratula:, TipoFallo:).
        fields: Fields to search in. Default: ["texto_sumario"].
                Options: materia, voces, nro_causa, caratula, texto_sumario,
                         juez_voto, codigo_norma, nro_norma, anio_norma,
                         texto_completo, tribunal_emisor.
        tipo_fallo: S=Definitiva, I=Interlocutoria, P=Plenario.
        fecha_desde: DD/MM/YYYY format.
        fecha_hasta: DD/MM/YYYY format.
        tribunal: Tribunal ID (numeric, from dropdown).
    """
    if fields is None:
        fields = ["texto_sumario"]

    html, cookies = _fetch(ADVANCED_URL)
    tokens = _extract_tokens(html)

    data = {
        **tokens,
        "__EVENTTARGET": "",
        "__EVENTARGUMENT": "",
        "ctl00$cphMainContent$TipoBusqueda": "rdbBusquedaIntegral",
        "ctl00$cphMainContent$txtExpresionBusquedaIntegral": query,
        "ctl00$cphMainContent$btnRealizarBusqueda": "Buscar",
        "ctl00$cphMainContent$txtPrimeraCarga": "SI",
        "ctl00$cphMainContent$txtBusquedaAsistidaGenerada": "",
        "ctl00$cphMainContent$txtCondicion": "",
        "ctl00$cphMainContent$CollapsiblePanelExtender1_ClientState": "true",
        "ctl00$cphMainContent$CollapsiblePanelExtender2_ClientState": "true",
        "ctl00$cphMainContent$CollapsiblePanelExtender3_ClientState": "true",
        "ctl00$cphMainContent$ddlLocalidades": "Seleccione...",
        "ctl00$cphMainContent$ddlTipoFallo": tipo_fallo or "Seleccione...",
        "ctl00$cphMainContent$ddlVotos": "Seleccione...",
        "ctl00$cphMainContent$ddlPublicaciones": "Seleccione...",
        "ctl00$cphMainContent$ddlMagistradosVotantes": "Seleccione...",
        "ctl00$cphMainContent$ddlTribunalOrigen": tribunal or "-1",
    }

    for field in fields:
        if field in _FIELD_MAP:
            data[f"ctl00$cphMainContent${_FIELD_MAP[field]}"] = "on"

    if fecha_desde:
        data["ctl00$cphMainContent$txtFechaFalloDesde"] = fecha_desde
    if fecha_hasta:
        data["ctl00$cphMainContent$txtFechaFalloHasta"] = fecha_hasta

    result_html, _ = _fetch(ADVANCED_URL, data, cookies)
    total = _get_total(result_html)
    tab_counts = _get_tab_counts(result_html)
    results = _parse_results(result_html)

    return {
        "total": total,
        "query": query,
        "fields": fields,
        "tab_counts": tab_counts,
        "results": results,
    }


def _parse_fallo_completo(html: str) -> dict[str, Any]:
    """Parse the full ruling text page."""
    import html as html_mod

    info: dict[str, Any] = {}

    # Extract metadata from span elements with known IDs
    span_fields = {
        "Materia": "materia",
        "TipoDeFallo": "tipo",
        "TribunalEmisor": "tribunal",
        "Causa": "causa",
        "Fecha": "fecha",
        "CaratulaPublica": "caratula",
        "TribunalOrigen": "tribunal_origen",
        "MagistradosVotantes": "magistrados",
    }
    for span_id, key in span_fields.items():
        m = re.search(rf'{span_id}">(.*?)</span>', html, re.S)
        if m:
            val = html_mod.unescape(re.sub(r"<[^>]+>", "", m.group(1))).strip()
            if val:
                info[key] = val

    # Extract all paragraphs as the ruling text
    paragraphs = re.findall(r"<p[^>]*>(.*?)</p>", html, re.S)
    text_parts = []
    for p in paragraphs:
        clean = html_mod.unescape(re.sub(r"<[^>]+>", "", p)).strip()
        if clean:
            text_parts.append(clean)

    # Skip metadata paragraphs (first few are labels like "DATOS DEL FALLO", "Materia:", etc.)
    # Find where actual ruling text starts
    start_idx = 0
    for i, part in enumerate(text_parts):
        if len(part) > 200:
            start_idx = i
            break

    ruling_parts = text_parts[start_idx:]
    info["texto"] = "\n\n".join(ruling_parts)
    info["paragraphs"] = len(ruling_parts)

    return info


def get_fallo(id_fallo: int) -> dict[str, Any]:
    """
    Retrieve the full text of a court ruling by its ID.

    Args:
        id_fallo: Numeric fallo ID (obtained from search results).

    Returns:
        Dict with metadata (tribunal, caratula, fecha, etc.) and full texto.
    """
    url = f"{FALLO_URL}?idFallo={id_fallo}"
    html, _ = _fetch(url)

    if "No se encontraron resultados" in html or len(html) < 500:
        raise JUBAError(f"Fallo {id_fallo} not found")

    result = _parse_fallo_completo(html)
    result["id_fallo"] = id_fallo
    result["url"] = url
    return result
