"""JUBA MCP Server — Buenos Aires Province jurisprudence search."""

from __future__ import annotations

import json

from mcp.server.fastmcp import FastMCP

from .client import (
    SEARCH_FIELDS,
    VALID_MATERIAS,
    JUBAError,
    get_fallo,
    search,
    search_advanced,
)

mcp = FastMCP(
    "juba",
    instructions=(
        "Search and retrieve jurisprudence from JUBA (Jurisprudencia de Buenos Aires) — "
        "the Supreme Court of Buenos Aires Province legal database. "
        "Access court decision summaries, legal topics (voces), cited norms, and case metadata."
    ),
)


@mcp.tool()
def juba_search(
    query: str,
    materia: str = "civil",
    limit: int = 15,
) -> str:
    """Search JUBA for court decision summaries (sumarios) by keyword.

    Args:
        query: Search terms (e.g., "consumidor vicio", "prescripción laboral").
        materia: Legal subject area. Options: civil, laboral, penal, contencioso,
                 inconstitucionalidad, conflicto, enjuiciamiento, todos.
                 Default: civil.
        limit: Maximum results to return (up to 15 per page).

    Returns:
        JSON with total count, tab counts (text vs voces vs full text matches),
        and result list. Each result has: id, voces (legal topics), texto (summary text),
        normas (cited statutes), and fallo metadata (tribunal, fecha, caratula, magistrados).
    """
    try:
        result = search(query, materia=materia, limit=limit)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except JUBAError as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
def juba_advanced_search(
    query: str,
    fields: list[str] | None = None,
    tipo_fallo: str | None = None,
    fecha_desde: str | None = None,
    fecha_hasta: str | None = None,
) -> str:
    """Advanced search on JUBA with field-specific filtering.

    Searches across specific fields like summary text, voces (legal topics),
    case caption (caratula), full ruling text, or cited norms.

    Args:
        query: Search terms. Supports etiquetas like "Caratula:Garcia" or "TipoFallo:S".
        fields: Which fields to search in. Default: ["texto_sumario"].
                Options: materia, voces, nro_causa, caratula, texto_sumario,
                juez_voto, codigo_norma, nro_norma, anio_norma,
                texto_completo, tribunal_emisor.
        tipo_fallo: Filter by ruling type. S=Definitiva, I=Interlocutoria, P=Plenario.
        fecha_desde: Start date filter (DD/MM/YYYY).
        fecha_hasta: End date filter (DD/MM/YYYY).

    Returns:
        JSON with total count and result list with same structure as juba_search.
    """
    try:
        result = search_advanced(
            query,
            fields=fields,
            tipo_fallo=tipo_fallo,
            fecha_desde=fecha_desde,
            fecha_hasta=fecha_hasta,
        )
        return json.dumps(result, ensure_ascii=False, indent=2)
    except JUBAError as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
def juba_get_fallo(id_fallo: int) -> str:
    """Retrieve the full text of a court ruling by its numeric ID.

    Use id_fallo values from search results to get the complete ruling text,
    including the full judicial reasoning, not just the summary.

    Args:
        id_fallo: Numeric ruling ID from search results (e.g., 191298).

    Returns:
        JSON with metadata (tribunal, caratula, fecha) and full ruling text.
    """
    try:
        result = get_fallo(id_fallo)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except JUBAError as e:
        return json.dumps({"error": str(e)})


def main():
    mcp.run()


if __name__ == "__main__":
    main()
