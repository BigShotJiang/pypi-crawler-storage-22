"""MCP server for JusCABA — Buenos Aires City judicial system public API."""

__version__ = "0.1.0"
