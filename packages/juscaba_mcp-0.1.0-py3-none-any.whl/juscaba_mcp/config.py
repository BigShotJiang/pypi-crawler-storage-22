"""Configuration constants for JusCABA API."""

BASE_URL = "https://eje.juscaba.gob.ar/iol-api/api/public"

# Self-imposed rate limiting (seconds between requests)
REQUEST_DELAY = 0.1

# httpx timeout (seconds)
REQUEST_TIMEOUT = 30.0

# PDF download directory
DOWNLOAD_DIR = "/tmp/juscaba-downloads"
