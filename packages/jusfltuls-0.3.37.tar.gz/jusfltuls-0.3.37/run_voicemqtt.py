#!/usr/bin/env python3
"""Wrapper to run voicemqtt with correct PYTHONPATH."""
import sys
sys.path.insert(0, '/home/coder/02_GIT/GITLAB/jusfltuls/external/voicemqqt/src')

from voicemqtt.cli import main

if __name__ == '__main__':
    main()
