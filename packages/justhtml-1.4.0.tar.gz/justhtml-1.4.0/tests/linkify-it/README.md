# linkify-it fixtures

This directory vendors the upstream test fixtures from the `linkify-it` project:

- Source: https://github.com/markdown-it/linkify-it
- Fixtures: `test/fixtures/links.txt`, `test/fixtures/not_links.txt`
- License: MIT, see `tests/linkify-it/LICENSE.txt`

These files are used to validate JustHTML's internal Linkify implementation.
