// math_utils.c - Implementation of math utilities
#include "math_utils.h"

long long add_ints(long long a, long long b) {
    return a + b;
}

double multiply_doubles(double a, double b) {
    return a * b;
}
