"""
此文件主要用于向后兼容旧版本的 pip。
"""

from setuptools import setup

# 配置已在 pyproject.toml 中定义
setup()
