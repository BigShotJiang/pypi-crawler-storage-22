import datetime
import platform
import time

import unittest

import k_ctds as ctds

class TestTdsTime(unittest.TestCase):

    def test_time(self):
        val = ctds.Time(0, 0, 0)
        self.assertEqual(val, datetime.time(0, 0, 0))

        val = ctds.Time(23, 59, 59)
        self.assertEqual(val, datetime.time(23, 59, 59))

    def test_fromticks(self):
        cases = [
            86400,
            123456789,
            time.time()
        ]
        if platform.system() != 'Windows': # pragma: nobranch
            cases += [-1, 0]

        for case in cases:
            self.assertEqual(
                ctds.TimeFromTicks(case),
                datetime.datetime.fromtimestamp(case).time()
            )

    def test_fromticks_typeerror(self):
        for case in (None, '', b''):
            self.assertRaises(TypeError, ctds.TimeFromTicks, case)

    def test_typeerror(self):
        for args in (
                (),
                (1,),
                (1, 2),
                (None, None, None),
                ('', 1, 2),
                (1, '', 2),
                (1, 1, ''),
        ):
            self.assertRaises(TypeError, ctds.Time, *args)

    def test_valueerror(self):
        for args, part in (
                ((24, 0, 0), 'hour'),
                ((23, 60, 0), 'minute'),
                ((23, 59, 60), 'second'),
                ((-1, 0, 0), 'hour'),
                ((0, -1, 0), 'minute'),
                ((0, 0, -1), 'second'),
        ):
            try:
                ctds.Time(*args)
            except ValueError as ex:
                self.assertEqual(str(ex), '{0} is out of range'.format(part))
            else:
                self.fail('.Time() did not fail as expected') # pragma: nocover
