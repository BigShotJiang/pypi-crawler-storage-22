#!/usr/bin/env python3
"""
Kabyle Corpus Toolkit

Tools for downloading, processing, and normalizing Kabyle and Occitan 
language corpora from Tatoeba and other sources.

Example:
    >>> from kabyle_corpus_toolkit import normalize, tokenize_kabyle
    >>> text = "εɛ γɣ"
    >>> normalize(text, lang="kab", fix=True)
    'ɛɛ ɣɣ'
"""

__version__ = "2.0.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

# Core exports
from .kab_charset import (
    normalize,
    find_disallowed,
    is_valid,
    strip_non_kabyle,
    tokenize_kabyle,
)

from .lang_profiles import (
    get_profile,
    get_charset,
    get_fixes,
    LanguageProfile,
)

__all__ = [
    # Version
    "__version__",
    # Core functions
    "normalize",
    "find_disallowed",
    "is_valid",
    "strip_non_kabyle",
    "tokenize_kabyle",
    # Profile functions
    "get_profile",
    "get_charset",
    "get_fixes",
    "LanguageProfile",
]
