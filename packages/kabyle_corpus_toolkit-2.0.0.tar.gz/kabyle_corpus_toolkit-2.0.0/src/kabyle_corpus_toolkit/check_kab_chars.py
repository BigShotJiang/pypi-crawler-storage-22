#!/usr/bin/env python3
"""
Check and fix Kabyle text for non-standard characters.
"""

import os
import json
import logging
import time
from collections import Counter
from typing import Dict, Optional, Set
from contextlib import ExitStack

from .kab_charset import normalize, find_disallowed, strip_non_kabyle, get_charset, get_fixes

logger = logging.getLogger(__name__)


class InteractiveLearner:
    """Manages learned character replacements across sessions."""
    
    def __init__(self, learned_file: Optional[str] = None):
        self.learned: Dict[str, str] = {}
        self.learned_file = learned_file
        self.modified = False
        
        if learned_file and os.path.exists(learned_file):
            self._load()
    
    def _load(self):
        """Load learned replacements from file."""
        with open(self.learned_file, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.rstrip('\n')
                if not line or line.startswith('#'):
                    continue
                bad, _, repl = line.partition('\t')
                self.learned[bad] = repl if repl != "<delete>" else ""
        logger.info(f"Loaded {len(self.learned)} learned replacements")
    
    def save(self):
        """Append new learned replacements to file."""
        if not self.modified or not self.learned_file:
            return
        
        with open(self.learned_file, 'a', encoding='utf-8') as f:
            f.write(f"\n# Session: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            for k, v in self.learned.items():
                f.write(f"{k}\t{v if v != '' else '<delete>'}\n")
        logger.info(f"Saved learned replacements to {self.learned_file}")
    
    def get_replacement(self, char: str, line: str, pos: int) -> Optional[str]:
        """Get replacement for a character (from memory or user)."""
        if char in self.learned:
            return self.learned[char]
        
        print("\n" + "-" * 60)
        print(f"Line: {line[:80]}{'...' if len(line) > 80 else ''}")
        print(" " * (6 + pos) + "↑")
        print(f"Unknown: U+{ord(char):04X} {char!r}")
        
        while True:
            ans = input("Replace with (ENTER=delete, s=skip line, ?=help): ").strip()
            
            if ans == '?':
                print("  ENTER: delete this character")
                print("  s: skip entire line")
                print("  <text>: use <text> as replacement")
                continue
            elif ans.lower() == 's':
                return None
            else:
                self.learned[char] = ans
                self.modified = True
                return ans


def analyze_bad_chars(file_path: str, n: int = 30) -> None:
    """Print ranked list of most frequent disallowed characters."""
    counts = Counter()
    total_chars = 0
    
    with open(file_path, encoding='utf-8') as f:
        for line in f:
            for ch in line:
                total_chars += 1
                if ch.isalpha() and ch not in get_charset("kab"):
                    counts[ch] += 1
    
    if not counts:
        print("No disallowed characters found.")
        return
    
    print(f"\nTop {n} most frequent problematic characters")
    print(f"Total characters scanned: {total_chars:,}")
    print("-" * 50)
    print(f"{'Char':>6} {'Unicode':>10} {'Count':>10} {'% of bad':>10}")
    print("-" * 50)
    
    total_bad = sum(counts.values())
    for ch, freq in counts.most_common(n):
        pct_of_bad = (freq / total_bad) * 100 if total_bad > 0 else 0
        print(f"{ch!r:>6} U+{ord(ch):04X} {freq:>10,} {pct_of_bad:>9.2f}%")
    
    print("-" * 50)
    print(f"Unique bad characters: {len(counts)}")
    print(f"Total bad occurrences: {total_bad:,} ({100*total_bad/total_chars:.3f}% of all chars)")


def process_file(
    input_path: str,
    output_path: Optional[str],
    *,
    interactive: bool = False,
    learner: Optional[InteractiveLearner] = None,
    strip_non_kab: bool = False,
    strict: bool = False
) -> dict:
    """Process file with normalization and optional interactive fixing."""
    stats = {
        'total_lines': 0,
        'modified_lines': 0,
        'skipped_lines': 0,
        'chars_fixed': 0,
        'chars_stripped': 0
    }
    
    with ExitStack() as stack:
        infile = stack.enter_context(open(input_path, 'r', encoding='utf-8'))
        
        if output_path:
            outfile = stack.enter_context(open(output_path, 'w', encoding='utf-8'))
        else:
            import sys
            outfile = sys.stdout
        
        for line in infile:
            raw = line.rstrip('\n')
            if not raw:
                outfile.write('\n')
                continue
            
            stats['total_lines'] += 1
            
            # Normalize and auto-fix
            processed = normalize(raw, fix=True, nfc=True)
            
            # Strip non-Kabyle if requested
            if strip_non_kab:
                stripped = strip_non_kabyle(processed)
                stats['chars_stripped'] += len(processed) - len(stripped)
                processed = stripped
            
            # Interactive fixing
            if interactive:
                while True:
                    bad = find_disallowed(processed)
                    if not bad:
                        break
                    
                    ch = next(iter(bad))
                    repl = learner.get_replacement(ch, processed, processed.find(ch))
                    
                    if repl is None:
                        stats['skipped_lines'] += 1
                        processed = None
                        break
                    
                    processed = processed.replace(ch, repl)
                    stats['chars_fixed'] += 1
            
            if processed is None:
                continue
            
            # Final validation
            remaining_bad = find_disallowed(processed)
            if remaining_bad and strict:
                logger.error(f"Line still has bad chars: {processed[:50]}...")
                continue
            
            outfile.write(processed + '\n')
            
            if processed != raw:
                stats['modified_lines'] += 1
    
    return stats
