"""
Command-line interface modules for Kabyle Corpus Toolkit.
"""
