#!/usr/bin/env python3
"""
CLI for creating corpus via French chain translations.
"""

import argparse
import logging
import os
from collections import defaultdict
from typing import Dict, Set, Tuple

from ..extractor import iter_sentences, iter_links

logger = logging.getLogger(__name__)


def build_chained_pairs(sentences_tar: str, links_tar: str):
    """Build English-Kabyle pairs via French chain."""
    logger.info("Loading sentences...")
    id_to_lang = {}
    id_to_text = {}
    
    for sid, lang, text in iter_sentences(sentences_tar):
        id_to_lang[sid] = lang
        id_to_text[sid] = text
    
    logger.info("Building link graph...")
    links = defaultdict(set)
    for a, b in iter_links(links_tar):
        links[a].add(b)
        links[b].add(a)
    
    # Find direct pairs
    logger.info("Finding direct English-Kabyle pairs...")
    direct_pairs = set()
    kab_to_eng_direct = {}
    
    for sid in id_to_lang:
        if id_to_lang[sid] == 'kab':
            for linked in links[sid]:
                if id_to_lang.get(linked) == 'eng':
                    direct_pairs.add(tuple(sorted([sid, linked])))
                    kab_to_eng_direct[sid] = linked
    
    # Find chained pairs
    logger.info("Finding Kabyle→French→English chains...")
    chained_pairs = {}
    chain_details = []
    
    for kab_id in id_to_lang:
        if id_to_lang.get(kab_id) != 'kab':
            continue
        if kab_id in kab_to_eng_direct:
            continue
        
        for fra_id in links.get(kab_id, []):
            if id_to_lang.get(fra_id) != 'fra':
                continue
            for eng_id in links.get(fra_id, []):
                if id_to_lang.get(eng_id) != 'eng':
                    continue
                chained_pairs[kab_id] = eng_id
                chain_details.append({
                    'kab_id': kab_id,
                    'kab_text': id_to_text.get(kab_id, ''),
                    'fra_id': fra_id,
                    'fra_text': id_to_text.get(fra_id, ''),
                    'eng_id': eng_id,
                    'eng_text': id_to_text.get(eng_id, '')
                })
                break
            if kab_id in chained_pairs:
                break
    
    # Combine
    all_pairs = {}
    for kab_id, eng_id in kab_to_eng_direct.items():
        all_pairs[kab_id] = {
            'eng_id': eng_id,
            'eng_text': id_to_text.get(eng_id, ''),
            'kab_text': id_to_text.get(kab_id, ''),
            'type': 'direct'
        }
    for kab_id, eng_id in chained_pairs.items():
        all_pairs[kab_id] = {
            'eng_id': eng_id,
            'eng_text': id_to_text.get(eng_id, ''),
            'kab_text': id_to_text.get(kab_id, ''),
            'type': 'chained'
        }
    
    logger.info(f"Direct pairs: {len(direct_pairs)}")
    logger.info(f"Chained pairs (new): {len(chained_pairs)}")
    logger.info(f"Total unique pairs: {len(all_pairs)}")
    
    return all_pairs, len(direct_pairs), len(chained_pairs), chain_details


def write_corpus(pairs: Dict, output_tsv: str, source_txt: str, target_txt: str) -> None:
    """Write corpus to files."""
    import csv
    import json
    
    with open(output_tsv, 'w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f, delimiter='\t')
        writer.writerow(['English', 'Kabyle', 'Type'])
        for kab_id, data in pairs.items():
            writer.writerow([data['eng_text'], data['kab_text'], data['type']])
    
    with open(source_txt, 'w', encoding='utf-8') as f_eng, \
         open(target_txt, 'w', encoding='utf-8') as f_kab:
        for kab_id, data in pairs.items():
            f_eng.write(data['eng_text'] + '\n')
            f_kab.write(data['kab_text'] + '\n')
    
    logger.info(f"Wrote {len(pairs)} pairs to {output_tsv}")


def main():
    parser = argparse.ArgumentParser(description="Create English-Kabyle corpus via French chains")
    parser.add_argument("--sentences-tar", default="sentences.tar.bz2",
                       help="Path to sentences.tar.bz2")
    parser.add_argument("--links-tar", default="links.tar.bz2",
                       help="Path to links.tar.bz2")
    parser.add_argument("--output-dir", default="corpus_chained",
                       help="Output directory")
    parser.add_argument("--save-chains", action="store_true",
                       help="Save detailed chain information")
    parser.add_argument("-v", "--verbose", action="store_true")
    
    args = parser.parse_args()
    
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    
    os.makedirs(args.output_dir, exist_ok=True)
    
    pairs, direct_count, chained_count, chain_details = build_chained_pairs(
        args.sentences_tar, args.links_tar
    )
    
    output_tsv = os.path.join(args.output_dir, "eng_kab_all_pairs.tsv")
    source_txt = os.path.join(args.output_dir, "eng_all.txt")
    target_txt = os.path.join(args.output_dir, "kab_all.txt")
    
    write_corpus(pairs, output_tsv, source_txt, target_txt)
    
    if args.save_chains:
        import json
        chains_json = os.path.join(args.output_dir, "chain_details.json")
        with open(chains_json, 'w', encoding='utf-8') as f:
            json.dump(chain_details, f, indent=2, ensure_ascii=False)
        logger.info(f"Wrote chain details to {chains_json}")
    
    increase = (chained_count / direct_count * 100) if direct_count > 0 else 0
    print(f"\n{'='*60}")
    print("CHAINED CORPUS SUMMARY")
    print(f"{'='*60}")
    print(f"Direct English-Kabyle pairs:     {direct_count:,}")
    print(f"New via French chain:              {chained_count:,}")
    print(f"Total pairs:                       {len(pairs):,}")
    print(f"Increase:                          +{increase:.1f}%")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
