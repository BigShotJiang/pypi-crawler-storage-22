#!/usr/bin/env python3
"""
CLI for checking and fixing characters.
"""

import argparse
import json
import logging
import sys
from ..check_kab_chars import analyze_bad_chars, process_file, InteractiveLearner

logger = logging.getLogger(__name__)


def main():
    parser = argparse.ArgumentParser(
        description="Check and fix Kabyle text files.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Check only (read-only)
  %(prog)s -i kab.txt
  
  # Auto-fix and save
  %(prog)s -i kab.txt -o kab_fixed.txt --fix
  
  # Interactive fixing with learning
  %(prog)s -i kab.txt -o kab_fixed.txt --interactive --learned learned.txt
        """
    )
    
    parser.add_argument("-i", "--input", required=True, help="Input file")
    parser.add_argument("-o", "--output", help="Output file (default: stdout)")
    parser.add_argument("--fix", action="store_true", help="Apply automatic fixes")
    parser.add_argument("--interactive", action="store_true",
                       help="Interactive mode for unknown chars")
    parser.add_argument("--learned", metavar="FILE",
                       help="Load/save learned replacements")
    parser.add_argument("--strip-non-kab", action="store_true",
                       help="Remove non-Kabyle characters")
    parser.add_argument("--top-bad", metavar="N", type=int, default=0,
                       help="Only analyze bad characters and exit")
    parser.add_argument("--strict", action="store_true",
                       help="Fail on lines that can't be fully fixed")
    parser.add_argument("-v", "--verbose", action="store_true")
    parser.add_argument("--save-stats", metavar="FILE",
                       help="Save processing stats to JSON file")
    
    args = parser.parse_args()
    
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format='%(levelname)s: %(message)s'
    )
    
    if args.top_bad > 0:
        analyze_bad_chars(args.input, args.top_bad)
        return
    
    if args.interactive:
        args.fix = True
    
    if not args.fix:
        from ..kab_charset import find_disallowed
        total = 0
        problematic = 0
        bad_examples = []
        
        with open(args.input, 'r', encoding='utf-8') as f:
            for nr, line in enumerate(f, 1):
                line = line.rstrip('\n')
                if not line:
                    continue
                total += 1
                bad = find_disallowed(line)
                if bad:
                    problematic += 1
                    if len(bad_examples) < 5:
                        bad_examples.append((nr, line, bad))
        
        print(f"Checked {total} lines, {problematic} problematic.")
        if bad_examples:
            print("\nFirst 5 examples:")
            for nr, line, bad in bad_examples:
                print(f"  Line {nr}: {line[:60]}")
                print(f"    Bad: {', '.join(sorted(bad))}")
        return
    
    learner = None
    if args.interactive:
        learner = InteractiveLearner(args.learned)
    
    stats = process_file(
        args.input,
        args.output,
        interactive=args.interactive,
        learner=learner,
        strip_non_kab=args.strip_non_kab,
        strict=args.strict
    )
    
    print(f"\nProcessing complete:")
    print(f"  Total lines: {stats['total_lines']}")
    print(f"  Modified: {stats['modified_lines']}")
    print(f"  Skipped: {stats['skipped_lines']}")
    if stats['chars_fixed']:
        print(f"  Characters fixed interactively: {stats['chars_fixed']}")
    if stats['chars_stripped']:
        print(f"  Characters stripped: {stats['chars_stripped']}")
    
    if learner:
        learner.save()
        if learner.learned:
            print(f"\nLearned {len(learner.learned)} new replacements")
    
    if args.save_stats:
        with open(args.save_stats, 'w') as f:
            json.dump(stats, f, indent=2)
        print(f"Stats saved to: {args.save_stats}")


if __name__ == "__main__":
    main()
