#!/usr/bin/env python3
"""
CLI for fixing text files.
"""

import argparse
import logging
from typing import Tuple

from ..kab_charset import normalize

logger = logging.getLogger(__name__)


def fix_file(input_file: str, output_file: str, lang: str = "kab") -> Tuple[int, int]:
    """Fix entire file line by line."""
    total = 0
    changed = 0
    
    with open(input_file, "r", encoding="utf-8") as infile, \
         open(output_file, "w", encoding="utf-8") as outfile:
        for line in infile:
            total += 1
            fixed_line = normalize(line, lang=lang, fix=True)
            if fixed_line != line:
                changed += 1
            outfile.write(fixed_line)
    
    logger.info(f"Processed {total} lines, fixed {changed} lines for {lang}")
    return total, changed


def main():
    parser = argparse.ArgumentParser(description="Fix text files with language-aware normalization.")
    parser.add_argument("-i", "--input", required=True, help="Input text file")
    parser.add_argument("-o", "--output", required=True, help="Output text file")
    parser.add_argument("-l", "--lang", default="kab", choices=["kab", "oci"],
                       help="Target language")
    parser.add_argument("-v", "--verbose", action="store_true")
    
    args = parser.parse_args()
    
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format='%(levelname)s: %(message)s'
    )
    
    total, changed = fix_file(args.input, args.output, lang=args.lang)
    print(f"Fixed {changed}/{total} lines for language '{args.lang}'")


if __name__ == "__main__":
    main()
