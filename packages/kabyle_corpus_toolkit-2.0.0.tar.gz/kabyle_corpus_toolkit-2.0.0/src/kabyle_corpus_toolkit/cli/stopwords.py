#!/usr/bin/env python3
"""
CLI for generating stopwords.
"""

import argparse
import logging
from ..kab_stopwords import create_stopwords, show_top_words

logger = logging.getLogger(__name__)


def main():
    parser = argparse.ArgumentParser(description="Generate stopwords from corpus")
    parser.add_argument("input", help="Input text file (UTF-8)")
    parser.add_argument("output", nargs="?", help="Output stopwords file")
    parser.add_argument("--rel-cutoff", type=float, default=0.005,
                       help="Relative frequency cutoff (default: 0.005 = 0.5%%)")
    parser.add_argument("--min-count", type=int, default=5,
                       help="Absolute frequency cutoff")
    parser.add_argument("--max-words", type=int, default=None,
                       help="Maximum stopwords to keep")
    parser.add_argument("--exclude-file", help="File with words to exclude")
    parser.add_argument("--show-top", type=int, metavar="N",
                       help="Show top N words and exit")
    parser.add_argument("-v", "--verbose", action="store_true")
    
    args = parser.parse_args()
    
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format='%(levelname)s: %(message)s'
    )
    
    # Load exclusions
    exclude = {"mary", "john", "paul", "jesus"}
    if args.exclude_file:
        with open(args.exclude_file, 'r', encoding='utf-8') as f:
            file_excludes = {line.strip().lower() for line in f if line.strip()}
            exclude.update(file_excludes)
        logger.info(f"Loaded {len(file_excludes)} exclusions from {args.exclude_file}")
    
    if args.show_top:
        show_top_words(args.input, args.show_top, exclude)
        return
    
    if not args.output:
        parser.error("output file required (or use --show-top)")
    
    stopwords = create_stopwords(
        args.input,
        args.output,
        rel_cutoff=args.rel_cutoff,
        min_count=args.min_count,
        max_words=args.max_words,
        exclude=exclude
    )
    
    print(f"\nGenerated {len(stopwords)} stopwords")
    print(f"Saved to: {args.output}")


if __name__ == "__main__":
    main()
