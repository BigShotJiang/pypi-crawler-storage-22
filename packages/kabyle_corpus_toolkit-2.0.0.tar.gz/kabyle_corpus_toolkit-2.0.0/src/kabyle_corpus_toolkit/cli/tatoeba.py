#!/usr/bin/env python3
"""
CLI for downloading and processing Tatoeba parallel corpus.
"""

import os
import sys
import json
import logging
import argparse
from datetime import datetime
from typing import Dict, Any, Tuple, Set
from collections import defaultdict

try:
    from yaspin import yaspin
    HAS_YASPIN = True
except ImportError:
    HAS_YASPIN = False
    class yaspin:
        def __init__(self, text="", color=None):
            self.text = text
        def __enter__(self):
            print(f"Starting: {self.text}")
            return self
        def __exit__(self, *args):
            pass
        def ok(self, msg):
            print(f"Done: {self.text} {msg}")

from ..downloader import download_file, ensure_directory
from ..extractor import iter_sentences, iter_links, TatoebaExtractError
from ..pairing import (
    build_sentence_dict, 
    build_candidate_ids,
    build_sentence_dict_from_ids,
    write_sentence_pairs
)
from ..kab_charset import normalize

logger = logging.getLogger(__name__)

SENTENCES_URL = "https://downloads.tatoeba.org/exports/sentences.tar.bz2"
LINKS_URL = "https://downloads.tatoeba.org/exports/links.tar.bz2"
SUPPORTED_LANGS = ["kab", "oci"]


def split_tsv_to_text(tsv_filename: str, source_out: str, target_out: str,
                      source_header: str = "Source", target_header: str = "Target") -> Tuple[int, int]:
    """Split TSV pair file into separate monolingual files."""
    import csv
    
    source_lines = 0
    target_lines = 0
    
    with open(tsv_filename, "r", encoding="utf-8") as infile:
        reader = csv.DictReader(infile, delimiter="\t")
        with open(source_out, "w", encoding="utf-8") as src_file, \
             open(target_out, "w", encoding="utf-8") as tgt_file:
            for row in reader:
                source = row.get(source_header, "").strip()
                target = row.get(target_header, "").strip()
                if source:
                    src_file.write(source + "\n")
                    source_lines += 1
                if target:
                    tgt_file.write(target + "\n")
                    target_lines += 1
    
    logger.info(f"Created {source_out} ({source_lines} lines) and {target_out} ({target_lines} lines)")
    return source_lines, target_lines


def build_chained_pairs(sentences_tar: str, links_tar: str,
                        source_lang: str = "eng", target_lang: str = "kab",
                        bridge_lang: str = "fra") -> Tuple[Dict, int, int]:
    """Build pairs including chain translations via bridge language."""
    logger.info(f"Building translation pairs with {bridge_lang} bridge...")
    
    id_to_lang = {}
    id_to_text = {}
    
    for sid, lang, text in iter_sentences(sentences_tar):
        id_to_lang[sid] = lang
        id_to_text[sid] = text
    
    links = defaultdict(set)
    for a, b in iter_links(links_tar):
        links[a].add(b)
        links[b].add(a)
    
    # Find direct pairs
    direct_pairs = {}
    for sid in id_to_lang:
        if id_to_lang[sid] == target_lang:
            for linked in links[sid]:
                if id_to_lang.get(linked) == source_lang:
                    direct_pairs[sid] = (id_to_text[sid], id_to_text[linked], 'direct')
    
    # Find chained pairs
    chained_pairs = {}
    for sid in id_to_lang:
        if id_to_lang[sid] != target_lang:
            continue
        if sid in direct_pairs:
            continue
        
        for bridge_id in links.get(sid, []):
            if id_to_lang.get(bridge_id) != bridge_lang:
                continue
            for source_id in links.get(bridge_id, []):
                if id_to_lang.get(source_id) != source_lang:
                    continue
                chained_pairs[sid] = (id_to_text[sid], id_to_text[source_id], 'chained')
                break
            if sid in chained_pairs:
                break
    
    all_pairs = {**direct_pairs, **chained_pairs}
    return all_pairs, len(direct_pairs), len(chained_pairs)


def write_combined_pairs(pairs: Dict, output_filename: str,
                         source_name: str = "Source", target_name: str = "Target") -> int:
    """Write pairs to TSV with type annotation."""
    import csv
    
    count = 0
    with open(output_filename, "w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f, delimiter="\t")
        writer.writerow([target_name, source_name, "Type"])
        for tid, (ttext, stext, ptype) in pairs.items():
            writer.writerow([ttext, stext, ptype])
            count += 1
    
    logger.info(f"Wrote {count} pairs to {output_filename}")
    return count


def generate_stopwords(input_file: str, output_file: str, lang: str,
                       rel_cutoff: float = 0.005, min_count: int = 5,
                       max_words: int = 500) -> int:
    """Generate stopwords from processed text."""
    import re
    from collections import Counter
    
    if lang == "kab":
        pattern = re.compile(r"[a-zA-ZčḍɛǧɣḥṛṣṭẓČḌƐǦƔḤṚṢṬẒ]+")
    else:
        pattern = re.compile(r"[a-zA-ZáàäâéèëêíìïîóòöôúùüûçñÁÀÄÂÉÈËÊÍÌÏÎÓÒÖÔÚÙÜÛÇÑ]+")
    
    logger.info(f"Reading {input_file} for stopword generation...")
    
    with open(input_file, "r", encoding="utf-8") as f:
        text = f.read()
    
    text = normalize(text, lang=lang, fix=True)
    tokens = pattern.findall(text.lower())
    freq = Counter(tokens)
    total_tokens = sum(freq.values())
    
    logger.info(f"Total tokens: {total_tokens:,}, unique: {len(freq):,}")
    
    candidates = []
    for word, count in freq.most_common():
        meets_rel = (count / total_tokens) >= rel_cutoff
        meets_abs = count >= min_count
        if meets_rel or meets_abs:
            candidates.append(word)
        if len(candidates) >= max_words:
            break
    
    with open(output_file, "w", encoding="utf-8") as f:
        for word in candidates:
            f.write(word + "\n")
    
    logger.info(f"Wrote {len(candidates)} stopwords to {output_file}")
    return len(candidates)


def generate_manifest(output_dir: str, stats: Dict[str, Any],
                      source_lang: str, target_lang: str) -> None:
    """Generate processing manifest."""
    manifest = {
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "source": "tatoeba.org",
        "source_lang": source_lang,
        "target_lang": target_lang,
        "statistics": stats,
        "files": {
            "pairs": f"{source_lang}_{target_lang}_sentence_pairs.tsv",
            "source_raw": f"{source_lang}.txt",
            "target_raw": f"{target_lang}.txt",
            "target_fixed": f"{target_lang}_fixed.txt",
            "stopwords": f"{target_lang}_stopwords.txt"
        }
    }
    
    manifest_path = os.path.join(output_dir, "manifest.json")
    with open(manifest_path, 'w', encoding='utf-8') as f:
        json.dump(manifest, f, indent=2)
    logger.info(f"Manifest saved to {manifest_path}")


def main():
    parser = argparse.ArgumentParser(
        description="Download and process Tatoeba parallel corpus (Kabyle/Occitan only)",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    
    parser.add_argument("--source", "-s", required=True,
                       help="Source language ISO code (eng recommended)")
    parser.add_argument("--target", "-t", required=True, choices=SUPPORTED_LANGS,
                       help="Target language: kab (Kabyle) or oci (Occitan)")
    parser.add_argument("--output-dir", "-o", default="corpus",
                       help="Output directory")
    parser.add_argument("--cache-dir", default=".",
                       help="Directory for downloaded archives")
    parser.add_argument("--skip-download", action="store_true",
                       help="Use existing archives in cache-dir")
    parser.add_argument("--skip-fix", action="store_true",
                       help="Skip character fixing for target language")
    parser.add_argument("--skip-stopwords", action="store_true",
                       help="Skip stopword generation")
    parser.add_argument("--skip-chains", action="store_true",
                       help="Skip French-chain translations (direct only)")
    parser.add_argument("--bridge-lang", default="fra",
                       help="Bridge language for chain translations")
    parser.add_argument("--rel-cutoff", type=float, default=0.005,
                       help="Relative frequency cutoff for stopwords")
    parser.add_argument("--min-count", type=int, default=5,
                       help="Absolute frequency cutoff for stopwords")
    parser.add_argument("--max-words", type=int, default=500,
                       help="Maximum stopwords to generate")
    parser.add_argument("-v", "--verbose", action="store_true")
    parser.add_argument("--log-file", help="Log to file")
    
    args = parser.parse_args()
    
    log_level = logging.DEBUG if args.verbose else logging.INFO
    handlers = [logging.StreamHandler()]
    if args.log_file:
        handlers.append(logging.FileHandler(args.log_file))
    
    logging.basicConfig(
        level=log_level,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=handlers
    )
    
    ensure_directory(args.output_dir)
    ensure_directory(args.cache_dir)
    
    sentences_tar = os.path.join(args.cache_dir, "sentences.tar.bz2")
    links_tar = os.path.join(args.cache_dir, "links.tar.bz2")
    
    output_tsv = os.path.join(args.output_dir, f"{args.source}_{args.target}_sentence_pairs.tsv")
    source_txt = os.path.join(args.output_dir, f"{args.source}.txt")
    target_txt = os.path.join(args.output_dir, f"{args.target}.txt")
    target_fixed = os.path.join(args.output_dir, f"{args.target}_fixed.txt")
    stopwords_out = os.path.join(args.output_dir, f"{args.target}_stopwords.txt")
    
    stats = {"download": {}, "extraction": {}, "fixing": {}, "stopwords": {}}
    
    try:
        # Download
        if not args.skip_download:
            with yaspin(text="Downloading sentences archive...", color="cyan") as spinner:
                downloaded = download_file(SENTENCES_URL, sentences_tar)
                stats["download"]["sentences"] = "downloaded" if downloaded else "cached"
                spinner.ok("\u2714")
            
            with yaspin(text="Downloading links archive...", color="cyan") as spinner:
                downloaded = download_file(LINKS_URL, links_tar)
                stats["download"]["links"] = "downloaded" if downloaded else "cached"
                spinner.ok("\u2714")
        else:
            logger.info("Skipping downloads, using cached files")
            stats["download"]["sentences"] = "skipped"
            stats["download"]["links"] = "skipped"
        
        # Build pairs
        if args.skip_chains:
            with yaspin(text=f"Building {args.target} sentence dictionary...", color="cyan") as spinner:
                target_sentences = build_sentence_dict(sentences_tar, args.target)
                stats["extraction"]["target_sentences"] = len(target_sentences)
                spinner.ok("\u2714")
            
            if not target_sentences:
                logger.error(f"No sentences found for target language '{args.target}'")
                sys.exit(1)
            
            with yaspin(text=f"Finding {args.source} candidates...", color="cyan") as spinner:
                source_ids = build_candidate_ids(links_tar, target_sentences, args.source)
                stats["extraction"]["source_candidates"] = len(source_ids)
                spinner.ok("\u2714")
            
            with yaspin(text=f"Building {args.source} sentence dictionary...", color="cyan") as spinner:
                source_sentences = build_sentence_dict_from_ids(sentences_tar, args.source, source_ids)
                stats["extraction"]["source_sentences"] = len(source_sentences)
                spinner.ok("\u2714")
            
            with yaspin(text="Writing sentence pairs...", color="cyan") as spinner:
                pairs_written = write_sentence_pairs(
                    links_tar, source_sentences, target_sentences, output_tsv,
                    a_first=True, lang_a_name=args.source, lang_b_name=args.target
                )
                stats["extraction"]["pairs_written"] = pairs_written
                spinner.ok("\u2714")
        else:
            with yaspin(text=f"Building pairs (direct + {args.bridge_lang} chain)...", color="cyan") as spinner:
                pairs, direct_count, chained_count = build_chained_pairs(
                    sentences_tar, links_tar, args.source, args.target, args.bridge_lang
                )
                stats["extraction"]["direct_pairs"] = direct_count
                stats["extraction"]["chained_pairs"] = chained_count
                stats["extraction"]["total_pairs"] = len(pairs)
                stats["extraction"]["bridge_language"] = args.bridge_lang
                pairs_written = write_combined_pairs(pairs, output_tsv, args.source, args.target)
                spinner.ok("\u2714")
        
        # Split to monolingual files
        with yaspin(text="Splitting to monolingual files...", color="cyan") as spinner:
            src_count, tgt_count = split_tsv_to_text(
                output_tsv, source_txt, target_txt, args.source, args.target
            )
            stats["extraction"]["source_lines"] = src_count
            stats["extraction"]["target_lines"] = tgt_count
            spinner.ok("\u2714")
        
        # Fix target language text
        if not args.skip_fix:
            with yaspin(text=f"Fixing {args.target} text...", color="cyan") as spinner:
                with open(target_txt, 'r', encoding='utf-8') as infile, \
                     open(target_fixed, 'w', encoding='utf-8') as outfile:
                    changed = 0
                    total = 0
                    for line in infile:
                        total += 1
                        fixed = normalize(line, lang=args.target, fix=True)
                        if fixed != line:
                            changed += 1
                        outfile.write(fixed)
                stats["fixing"] = {"total_lines": total, "changed_lines": changed, "language": args.target}
                spinner.ok("\u2714")
                logger.info(f"Fixed {changed}/{total} lines for {args.target}")
        else:
            target_fixed = target_txt
            stats["fixing"] = "skipped"
        
        # Generate stopwords
        if not args.skip_stopwords:
            with yaspin(text=f"Generating {args.target} stopwords...", color="cyan") as spinner:
                stopword_count = generate_stopwords(
                    target_fixed, stopwords_out, lang=args.target,
                    rel_cutoff=args.rel_cutoff, min_count=args.min_count, max_words=args.max_words
                )
                stats["stopwords"]["count"] = stopword_count
                stats["stopwords"]["cutoff_relative"] = args.rel_cutoff
                stats["stopwords"]["cutoff_absolute"] = args.min_count
                spinner.ok("\u2714")
        else:
            stats["stopwords"] = "skipped"
        
        generate_manifest(args.output_dir, stats, args.source, args.target)
        
        # Final summary
        print(f"\n{'='*60}")
        print("Processing complete!")
        print(f"Output directory: {os.path.abspath(args.output_dir)}")
        print(f"Language pair: {args.source}-{args.target}")
        
        if args.skip_chains:
            print(f"Sentence pairs: {pairs_written:,} (direct only)")
        else:
            direct = stats["extraction"].get("direct_pairs", 0)
            chained = stats["extraction"].get("chained_pairs", 0)
            total = stats["extraction"].get("total_pairs", 0)
            increase = (chained / direct * 100) if direct > 0 else 0
            print(f"Sentence pairs: {total:,}")
            print(f"  - Direct:     {direct:,}")
            print(f"  - Via French: {chained:,} (+{increase:.1f}%)")
        
        if not args.skip_fix and isinstance(stats["fixing"], dict):
            changed = stats["fixing"]["changed_lines"]
            total = stats["fixing"]["total_lines"]
            print(f"Lines fixed: {changed:,}/{total:,} ({100*changed/total:.2f}%)")
        
        if not args.skip_stopwords and isinstance(stats["stopwords"], dict):
            print(f"Stopwords: {stats['stopwords']['count']}")
        
        print(f"{'='*60}")
        
    except TatoebaExtractError as e:
        logger.error(f"Extraction failed: {e}")
        sys.exit(1)
    except Exception as e:
        logger.exception("Processing failed")
        sys.exit(1)


if __name__ == "__main__":
    main()
