#!/usr/bin/env python3
"""
CLI for validating Kabyle/Occitan sentences using GlotLID.
"""

import argparse
import json
from ..validation import validate_file, print_report


def main():
    parser = argparse.ArgumentParser(
        description="Validate Kabyle or Occitan sentences with GlotLID"
    )
    parser.add_argument("input_file", help="Text file to validate")
    parser.add_argument("-l", "--lang", required=True, choices=["kab", "oci"],
                       help="Expected language")
    parser.add_argument("-t", "--threshold", type=float, default=0.70,
                       help="Confidence threshold")
    parser.add_argument("-o", "--output", help="Output JSON report file")
    parser.add_argument("-s", "--sample-size", type=int, default=100,
                       help="Number of example sentences to capture")
    
    args = parser.parse_args()
    
    report = validate_file(
        args.input_file,
        lang=args.lang,
        confidence_threshold=args.threshold,
        sample_size=args.sample_size
    )
    
    print_report(report)
    
    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
        print(f"\nReport saved to: {args.output}")


if __name__ == "__main__":
    main()
