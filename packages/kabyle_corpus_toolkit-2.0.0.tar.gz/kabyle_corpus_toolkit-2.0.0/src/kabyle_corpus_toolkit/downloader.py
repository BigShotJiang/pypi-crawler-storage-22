#!/usr/bin/env python3
"""
Robust file downloader with resume support and timeouts.
"""

import os
import requests
import logging
from typing import Optional

logger = logging.getLogger(__name__)

DEFAULT_TIMEOUT = (30, 300)


def get_remote_file_size(url: str, timeout: tuple = DEFAULT_TIMEOUT) -> int:
    """Get remote file size using HEAD request."""
    try:
        response = requests.head(url, timeout=timeout, allow_redirects=True)
        response.raise_for_status()
        size = response.headers.get('Content-Length')
        return int(size) if size else 0
    except requests.RequestException as e:
        logger.error(f"Failed to get file size for {url}: {e}")
        raise


def download_file(
    url: str, 
    filename: str, 
    timeout: tuple = DEFAULT_TIMEOUT,
    chunk_size: int = 8192,
    force: bool = False
) -> bool:
    """
    Download file from URL if it doesn't exist or size differs.
    
    Args:
        url: Remote file URL
        filename: Local filename
        timeout: Request timeout tuple (connect, read)
        chunk_size: Download chunk size
        force: Re-download even if file exists
        
    Returns:
        True if download was performed, False if skipped
    """
    remote_size = get_remote_file_size(url, timeout)
    
    if os.path.exists(filename) and not force:
        local_size = os.path.getsize(filename)
        if local_size == remote_size or remote_size == 0:
            logger.info(f"{filename} already exists ({local_size} bytes), skipping.")
            return False
        else:
            logger.info(f"Size differs (local: {local_size}, remote: {remote_size}). Re-downloading.")
    
    logger.info(f"Downloading {filename} from {url}...")
    
    try:
        response = requests.get(url, stream=True, timeout=timeout)
        response.raise_for_status()
        
        temp_filename = filename + ".tmp"
        
        with open(temp_filename, "wb") as f:
            downloaded = 0
            for chunk in response.iter_content(chunk_size=chunk_size):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
        
        os.replace(temp_filename, filename)
        logger.info(f"Downloaded {filename} ({downloaded} bytes).")
        return True
        
    except Exception:
        if os.path.exists(temp_filename):
            os.remove(temp_filename)
        raise


def ensure_directory(path: str) -> None:
    """Create directory if it doesn't exist."""
    os.makedirs(path, exist_ok=True)
