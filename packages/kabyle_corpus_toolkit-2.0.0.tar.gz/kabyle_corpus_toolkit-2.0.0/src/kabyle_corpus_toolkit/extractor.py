#!/usr/bin/env python3
"""
Streaming extractor for Tatoeba tar.bz2 archives.
"""

import tarfile
import logging
from typing import Iterator, Tuple, Optional

logger = logging.getLogger(__name__)


class TatoebaExtractError(Exception):
    """Custom exception for extraction errors."""
    pass


def iter_sentences(
    tar_filename: str,
    lang_filter: Optional[str] = None
) -> Iterator[Tuple[str, str, str]]:
    """
    Generator yielding (sentence_id, lang, text) from sentences.tar.bz2.
    
    Args:
        tar_filename: Path to sentences.tar.bz2
        lang_filter: If provided, only yield sentences in this language
        
    Yields:
        Tuples of (sentence_id, language_code, text)
    """
    with tarfile.open(tar_filename, "r:bz2") as tar:
        member = None
        for m in tar.getmembers():
            if m.name.split("/")[-1].startswith("sentences"):
                member = m
                break
        
        if member is None:
            raise TatoebaExtractError(f"Could not find sentences file in {tar_filename}")
        
        f = tar.extractfile(member)
        if f is None:
            raise TatoebaExtractError(f"Could not extract sentences file")
        
        for line in f:
            try:
                decoded = line.decode('utf-8').rstrip("\n")
                parts = decoded.split("\t")
                
                if len(parts) < 3:
                    continue
                
                sid, lang, text = parts[0], parts[1], parts[2]
                
                if lang_filter and lang != lang_filter:
                    continue
                    
                yield sid, lang, text
                
            except UnicodeDecodeError:
                continue


def iter_links(tar_filename: str) -> Iterator[Tuple[str, str]]:
    """
    Generator yielding (sentence_id, translation_id) from links.tar.bz2.
    
    Args:
        tar_filename: Path to links.tar.bz2
        
    Yields:
        Tuples of (sentence_id, translation_id)
    """
    with tarfile.open(tar_filename, "r:bz2") as tar:
        member = None
        for m in tar.getmembers():
            if m.name.split("/")[-1].startswith("links"):
                member = m
                break
        
        if member is None:
            raise TatoebaExtractError(f"Could not find links file in {tar_filename}")
        
        f = tar.extractfile(member)
        if f is None:
            raise TatoebaExtractError(f"Could not extract links file")
        
        for line in f:
            try:
                decoded = line.decode('utf-8').rstrip("\n")
                parts = decoded.split("\t")
                
                if len(parts) >= 2:
                    yield parts[0], parts[1]
                    
            except UnicodeDecodeError:
                continue


def count_sentences_by_lang(tar_filename: str) -> dict:
    """Get sentence counts per language."""
    counts = {}
    for sid, lang, text in iter_sentences(tar_filename):
        counts[lang] = counts.get(lang, 0) + 1
    return counts
