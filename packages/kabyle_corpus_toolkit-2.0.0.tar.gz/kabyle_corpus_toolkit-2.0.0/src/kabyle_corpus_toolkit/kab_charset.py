#!/usr/bin/env python3
"""
Character normalization for Kabyle and Occitan.
"""

import unicodedata
import re
from typing import Set, Dict, Optional

from .lang_profiles import get_profile, get_charset, get_fixes


def normalize(text: str, lang: str = "kab", fix: bool = True, nfc: bool = True) -> str:
    """
    Normalize text for specific language.
    
    Args:
        text: Input text
        lang: Language code ('kab' or 'oci')
        fix: Apply character substitutions
        nfc: Apply NFC normalization
        
    Returns:
        Normalized text
        
    Example:
        >>> normalize("εɛ", lang="kab", fix=True)
        'ɛɛ'
    """
    if nfc:
        text = unicodedata.normalize("NFC", text)
    
    if fix:
        fixes = get_fixes(lang)
        # Sort by length (longest first) to avoid partial replacements
        for key in sorted(fixes, key=len, reverse=True):
            text = text.replace(key, fixes[key])
        if nfc:
            text = unicodedata.normalize("NFC", text)
    
    return text


def find_disallowed(text: str, lang: str = "kab") -> Set[str]:
    """
    Find characters not allowed in target language.
    
    Args:
        text: Input text
        lang: Language code
        
    Returns:
        Set of disallowed alphabetic characters
        
    Example:
        >>> find_disallowed("Hello ε", lang="kab")
        {'H', 'e', 'l', 'o', 'ε'}
    """
    allowed = get_charset(lang)
    return {
        ch for ch in text 
        if ch.isalpha() and ch not in allowed
    }


def is_valid(text: str, lang: str = "kab") -> bool:
    """
    Check if text contains only valid characters for language.
    
    Args:
        text: Input text
        lang: Language code
        
    Returns:
        True if all characters are valid
        
    Example:
        >>> is_valid("Axxam", lang="kab")
        True
    """
    return len(find_disallowed(text, lang)) == 0


def strip_non_kabyle(text: str, lang: str = "kab") -> str:
    """
    Remove characters not valid for the target language.
    Preserves whitespace and basic punctuation.
    
    Args:
        text: Input text
        lang: Language code
        
    Returns:
        Text with invalid characters removed
    """
    allowed = get_charset(lang)
    allowed = allowed | set(" .,!?;:-_()[]{}\"'/\n\t")
    
    result = []
    for ch in text:
        if ch in allowed or not ch.isalpha():
            result.append(ch)
    return ''.join(result)


def tokenize_kabyle(text: str, lower: bool = True) -> list:
    """
    Tokenize text using Kabyle/Occitan-aware regex.
    
    Args:
        text: Input text
        lower: Convert to lowercase
        
    Returns:
        List of tokens
        
    Example:
        >>> tokenize_kabyle("Axxam-iw d ameṛṛan.", lower=True)
        ['axxam', 'iw', 'd', 'ameṛṛan']
    """
    if lower:
        text = text.lower()
    
    pattern = re.compile(r"[a-zA-Záàäâéèëêíìïîóòöôúùüûçñčḍɛǧɣḥṛṣṭẓ]+")
    return pattern.findall(text)


# Backwards compatibility
ALLOWED_CHARS = get_charset("kab")
CHARACTER_FIXES = get_fixes("kab")
KABYLE_WORD_PATTERN = re.compile(
    rf"[{re.escape('abcčdḍeɛfgǧɣhḥijklmnpqrṛsṣtṭuwxyzẓ')}]*",
    re.IGNORECASE
)
